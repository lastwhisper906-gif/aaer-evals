# LITE notes — 0001628280-24-046443


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001628280-24-046443:notes:1]
[same as prior period, unchanged from 0001628280-24-020767:notes:1]

[0001628280-24-046443:notes:2]
[same as prior period, unchanged from 0001628280-24-020767:notes:2]

[0001628280-24-046443:notes:3]
Lumentum Holdings Inc. (“we,” “us,” “our,” “Lumentum” or the “Company”) is an industry-leading provider of optical and photonic products essential to a range of cloud, artificial intelligence and machine learning (“AI/ML”), telecommunications, consumer, and industrial end-market applications. We operate in two end-market focused reportable segments, Cloud & Networking and Industrial Tech.

[0001628280-24-046443:notes:4]
Our Cloud & Networking products include a comprehensive portfolio of optical and photonic chips, modules, and subsystems supplied to cloud data center operator, AI/ML infrastructure provider, and network equipment manufacturer customers who are building cloud data center and network infrastructures. Our products enable high-capacity optical data links in cloud, AI/ML, and data center interconnect (“DCI”) applications, and communications service provider networks, including in access (local), metro (intracity), long-haul (city-to-city and worldwide), and submarine (undersea) network infrastructure. Our Cloud & Networking products also support network equipment manufacturers building enterprise network infrastructure, including storage-area networks (“SANs”), local-area networks (“LANs”) and wide-area networks (“WANs”). Demand for our Cloud & Networking products is driven by the continual growth in network capacity required for cloud computing and services, including for AI/ML, streaming video and video conferencing, wireless and mobile devices, and internet of things (“IoT”).

[0001628280-24-046443:notes:5]
Our Industrial Tech products include short pulse solid-state lasers, kilowatt-class fiber lasers, diode lasers, and gas lasers, which address applications in numerous end-markets. In the consumer end-market, our laser light sources are integrated into our customers’ 3D sensing cameras, which are used in mobile devices, payment kiosks, and other consumer electronics devices to enable applications including biometric identification, computational photography and virtual and augmented reality. In the automotive end-market, our lasers are used in our customers’ LiDAR and other optical sensor devices, which are increasingly being used in advanced driver assistance systems (“ADAS”) and in-cabin driver and occupant monitoring systems. In the industrial manufacturing end-market, our lasers are incorporated into our customers’ manufacturing machine tools used for the precision processing of materials in a range of industries including semiconductor device and microelectronics fabrication, electric vehicle and battery production, metal cutting and welding, and advanced manufacturing. Our products can also be used in the industrial end-market in imaging and sensing systems for process feedback and control, quality assurance, and waste reduction. Adoption of our products in the industrial end-market is driven by the needs of customers to advance semiconductor and microelectronics industry roadmaps, and by Industry 4.0/5.0 trends, including increasing manufacturing precision and flexibility and reducing waste and environmental impact. Demand for our products in the industrial end-market is driven by end-customer investments in manufacturing capacity. Our lasers also address certain semiconductor inspection and life-science applications.

[0001628280-24-046443:notes:6]
[same as prior period, unchanged from 0001628280-24-020767:notes:6]

[0001628280-24-046443:notes:7]
[same as prior period, unchanged from 0001628280-24-020767:notes:7]

[0001628280-24-046443:notes:8]
[same as prior period, unchanged from 0001628280-24-020767:notes:9]

[0001628280-24-046443:notes:9]
We are continuously monitoring both the current developments in the ongoing Russia-Ukraine war including the related export controls and resulting sanctions imposed on Russia and Belarus by the U.S. and other countries, and the ongoing conflicts in the Middle East. Additional factors, such as increased inflation, escalating energy prices and the related cost increases, could continue to impact the global economy and our business. Although the global implications of these wars are difficult to predict at this time, we do not presently foresee direct material adverse effects on our business.

[0001628280-24-046443:notes:10]
[same as prior period, unchanged from 0001628280-24-020767:notes:11]

[0001628280-24-046443:notes:11]
On November 7, 2023, we completed the acquisition of Cloud Light Technology Limited (“Cloud Light”). We have applied the acquisition method of accounting to account for this transaction in accordance with ASC Topic 805, Business Combinations. Our condensed consolidated financial statements include the operating results of the acquired entities from the acquisition close date. Refer to “Note 4. Business Combinations” for further discussions of this transaction.

[0001628280-24-046443:notes:12]
[same as prior period, unchanged from 0001628280-24-020767:notes:13]

[0001628280-24-046443:notes:13]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Every fifth or sixth fiscal year will have a 53-week period. The additional week in a 53-week year is added to the third quarter, making such quarter consist of 14 weeks. Our fiscal 2025 is a 52-week year ending on June 28, 2025, with the quarter ended September 28, 2024 being a 13-week quarterly period. Our fiscal 2024 was a 52-week year that ended on June 29, 2024, with the quarter ended September 30, 2023 being a 13-week quarterly period.

[0001628280-24-046443:notes:14]
[same as prior period, unchanged from 0001628280-24-020767:notes:15]

[0001628280-24-046443:notes:15]
[same as prior period, unchanged from 0001628280-24-020767:notes:16]

[0001628280-24-046443:notes:16]
Accounting Policies
The condensed consolidated financial statements and accompanying notes should be read in conjunction with the audited consolidated financial statements and accompanying notes included in our Annual Report on Form 10-K for the fiscal year ended June 29, 2024. There were no significant changes to our accounting policies during the three months ended September 28, 2024


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001628280-24-046443:notes:17]
Note 2. Recently Issued Accounting Pronouncements

[0001628280-24-046443:notes:18]
In March 2024, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) No. 2024-02: Codification Improvements - Amendments to Remove References to the Concepts Statements, which contains amendments to the Codification that remove references to various FASB Concepts Statements.  ASU 2024-02 is effective for fiscal years beginning after December 15, 2024, with early adoption permitted. We do not expect this ASU to have a material impact on our consolidated financial statements and disclosures.

[0001628280-24-046443:notes:19]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures, which requires disaggregated information about a reporting entity’s effective tax rate reconciliation as well as information on income tax paid. ASU 2023-09 is effective for fiscal years beginning after December 15, 2024, with early adoption permitted. We are currently evaluating the impact of this ASU on our income tax disclosures within the consolidated financial statements.

[0001628280-24-046443:notes:20]
In November 2023, the FASB issued ASU 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures, which updates reportable segment disclosure requirements primarily through enhanced disclosures about significant segment expenses. ASU 2023-07 does not change how a public entity identifies its operating segments, aggregates those operating segments, or applies quantitative thresholds to determine its reportable segments. The update is effective for fiscal years beginning after December 15, 2023 and interim periods within fiscal years beginning after December 15, 2024, with early adoption permitted. The amendments should be applied retrospectively to all prior periods presented in the financial statements. We plan to adopt ASU 2023-07 in the fiscal fourth quarter of 2025. We are currently evaluating the impact of adopting this ASU on our consolidated financial statements and disclosures.


## us-gaap:EarningsPerShareTextBlock

[0001628280-24-046443:notes:21]
[same as prior period, unchanged from 0001628280-24-020767:notes:22]

[0001628280-24-046443:notes:22]
[same as prior period, unchanged from 0001628280-24-020767:notes:23]

[0001628280-24-046443:notes:23]
|  | Three Months Ended |  |  |
|  | September 28, 2024 |  | September 30, 2023 |  |  |  |  |
| Numerator: |  |  |  |  |  |  |  |
| Net loss - basic and diluted | $ | (82.4) |  |  | $ | (67.9) |  |  |  |  |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted average common shares outstanding - basic and diluted | 68.3 |  |  | 66.7 |  |  |  |  |  |
| Net loss per share: |  |  |  |  |  |  |  |
| Basic | $ | (1.21) |  |  | $ | (1.02) |  |  |  |  |  |
| Diluted | $ | (1.21) |  |  | $ | (1.02) |  |  |  |  |  |

[0001628280-24-046443:notes:24]
Anti-dilutive shares excluded from the calculation of diluted net loss per share for the three months ended September 28, 2024 include 4.8 million shares issuable under restricted stock units (“RSUs”) and performance stock units (“PSUs”), 0.1 million shares issuable under the Employee Stock Purchase Plan (the “2015 Purchase Plan”), and 1.0 million shares outstanding related to stock options. Refer to “Note 13. Equity.”

[0001628280-24-046443:notes:25]
Anti-dilutive shares excluded from the calculation of diluted net loss per share for the three months ended September 30, 2023 include 31.2 million shares related to convertible notes, 4.6 million shares issuable under RSUs and PSUs, and 0.2 million shares issuable under the 2015 Purchase Plan. 
Potentially dilutive common shares issuable upon conversion of our outstanding convertible notes are determined using the if-converted method.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001628280-24-046443:notes:26]
[same as prior period, unchanged from 0001628280-24-020767:notes:28]

[0001628280-24-046443:notes:27]
[same as prior period, unchanged from 0001628280-24-020767:notes:29]

[0001628280-24-046443:notes:28]
On October 29, 2023, we entered into a definitive merger agreement (the “Merger Agreement”) with Cloud Light. On November 7, 2023 (the “Cloud Light Closing Date”), we completed the acquisition of Cloud Light. Cloud Light designs, markets, and manufactures advanced optical modules for data center interconnect applications. The acquisition enables us to be well-positioned to serve the growing needs of cloud & networking customers, particularly those customers focused on optimizing their data center infrastructure for the demands of AI/ML.

[0001628280-24-046443:notes:29]
We have applied the acquisition method of accounting in accordance with ASC 805 Business Combinations, with respect to the fair value of purchase price consideration and the identifiable assets and liabilities of Cloud Light, which have been measured at estimated fair value as of the Cloud Light Closing Date. The following tables summarize the purchase price consideration (in millions):

[0001628280-24-046443:notes:30]
[same as prior period, unchanged from 0001628280-24-020767:notes:32]

[0001628280-24-046443:notes:31]
(1) Under the terms of the Merger Agreement, Cloud Light stockholders received $1.69 per share after adjusting for applicable withholding taxes, escrow fund and expense fund contributions, for each of the 409.4 million of shares outstanding at the Cloud Light Closing Date. As a result, we transferred $691.7 million of cash consideration on the Cloud Light Closing Date. Additionally, each of Cloud Light’s outstanding options was exchanged for a combination of up-front cash consideration and newly issued options (the “replacement options”). As a result, we transferred $13.3 million of cash consideration on the Cloud Light Closing Date.

[0001628280-24-046443:notes:32]
(2) The  replacement options have a total fair value of $38.9 million as of the Cloud Light Closing Date, of which $23.5 million attributed to pre-acquisition service is recorded as part of the purchase price consideration and the remaining $15.4 million is recorded as post-acquisition stock-based compensation expense over the vesting period of three years from the Cloud Light Closing Date. In general, these options expire within 10 years from the Cloud Light Closing Date. Refer to “Note 13. Equity”.

[0001628280-24-046443:notes:33]
The cash consideration of $705.0 million, which was funded by the cash balances of Lumentum, includes $75.8 million of cash held in an escrow fund to support Cloud Light’s indemnification obligations under the Merger Agreement and customary adjustment for working capital.  Since the the measurement period expired, any future adjustments will be included in our earnings.  As of the date of this filing, no amount of the escrow funds have been released.

[0001628280-24-046443:notes:34]
We incurred a total of $9.6 million of acquisition-related costs in fiscal year 2024, of which $2.4 million was incurred during the three months ended September 30, 2023, representing professional and other direct acquisition costs, which are recorded as selling, general and administrative expense in the condensed consolidated statement of operations when incurred.

[0001628280-24-046443:notes:35]
We allocated the fair value of the purchase price consideration to the assets acquired and liabilities assumed as of the Cloud Light Closing Date based on their estimated fair values. The excess of purchase price consideration over the fair value of net assets acquired is recorded as goodwill. Our final allocation of the purchase price consideration to the assets acquired and liabilities assumed as of the Cloud Light Closing Date is as follows (in millions):

[0001628280-24-046443:notes:36]
|  | Fair Value |
| Total purchase price consideration | $ | 728.5 |  |
| Assets acquired |  |
| Cash and cash equivalents | 4.1 |  |
| Short-term investments | 1.0 |  |
| Accounts receivable, net | 20.9 |  |
| Inventories | 72.8 |  |
| Prepayments and other current assets | 14.2 |  |
| Property, plant and equipment, net | 62.5 |  |
| Operating lease right-of-use assets, net | 3.7 |  |
| Other intangible assets, net (1) | 333.0 |  |
| Other non-current assets | 0.3 |  |
| Total assets | 512.5 |  |
| Liabilities assumed |  |
| Accounts payable | 45.5 |  |
| Accrued payroll and related expenses | 5.6 |  |
| Accrued expenses | 7.9 |  |
| Operating lease liabilities, current | 1.8 |  |
| Other current liabilities | 10.3 |  |
| Operating lease liabilities, non-current | 1.9 |  |
| Deferred tax liability | 60.6 |  |
| Other non-current liabilities | 16.2 |  |
| Total liabilities | 149.8 |  |
| Goodwill | $ | 365.8 |  |

[0001628280-24-046443:notes:37]
[same as prior period, unchanged from 0001628280-24-020767:notes:39]

[0001628280-24-046443:notes:38]
Goodwill from the Cloud Light acquisition has been assigned to the Cloud & Networking segment. The goodwill of $365.8 million arising from the acquisition is attributed to the expected revenue growth and synergies, including future cost efficiencies and other benefits that are expected to be generated by combining Lumentum and Cloud Light. None of the goodwill is expected to be deductible for local tax purposes. Refer to “Note 8. Goodwill and Other Intangible Assets.”

[0001628280-24-046443:notes:39]
Cloud Light contributed $38.2 million of our consolidated net revenue for the three months ended September 28, 2024. Due to the continued integration of the combined businesses, as well as our corporate structure and the allocation of selling, general and administrative costs, it is impracticable to determine Cloud Light’s contribution to our earnings the three months ended September 28, 2024.

[0001628280-24-046443:notes:40]
[same as prior period, unchanged from 0001628280-24-020767:notes:43]

[0001628280-24-046443:notes:41]
The following supplemental pro forma information presents the combined results of operations for the three months ended September 28, 2024 and September 30, 2023, as if the acquisition was completed on July 3, 2022, the first day of the fiscal year 2023. The supplemental pro forma financial information presented below is not necessarily indicative of the financial position or results of operations that would have been realized if the acquisition had been completed on the date indicated. The supplemental pro forma financial information does not reflect synergies that might have been achieved, nor is it indicative of future operating results or financial position.

[0001628280-24-046443:notes:42]
[same as prior period, unchanged from 0001628280-24-020767:notes:45]

[0001628280-24-046443:notes:43]
[same as prior period, unchanged from 0001628280-24-020767:notes:46]

[0001628280-24-046443:notes:44]
|  | Three Months Ended |  |  |
|  | September 28, 2024 |  | September 30, 2023 |  |  |  |  |
| Net revenue | $ | 336.9 |  |  | $ | 386.6 |  |  |  |  |  |
| Net loss | $ | (78.9) |  |  | $ | (63.6) |  |  |  |  |  |


## us-gaap:CashCashEquivalentsAndShortTermInvestmentsTextBlock

[0001628280-24-046443:notes:45]
[same as prior period, unchanged from 0001628280-24-020767:notes:58]

[0001628280-24-046443:notes:46]
[same as prior period, unchanged from 0001628280-24-020767:notes:59]

[0001628280-24-046443:notes:47]
|  | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| September 28, 2024: |  |  |  |  |  |  |  |
| Cash | $ | 284.9 |  |  | $ | — |  |  | $ | — |  |  | $ | 284.9 |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | 7.5 |  |  | — |  |  | — |  |  | 7.5 |  |
| Money market funds | 184.8 |  |  | — |  |  | — |  |  | 184.8 |  |
| U.S. Treasury securities | 12.0 |  |  | — |  |  | — |  |  | 12.0 |  |
| Total cash and cash equivalents | $ | 489.2 |  |  | $ | — |  |  | $ | — |  |  | $ | 489.2 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 0.8 |  |  | $ | — |  |  | $ | — |  |  | $ | 0.8 |  |
| Commercial paper | 11.5 |  |  | — |  |  | — |  |  | 11.5 |  |
| Corporate debt securities | 234.1 |  |  | 0.9 |  |  | (0.1) |  |  | 234.9 |  |
| U.S. Agency securities | 66.4 |  |  | 0.1 |  |  | — |  |  | 66.5 |  |
| U.S. Treasury securities | 113.3 |  |  | — |  |  | (0.1) |  |  | 113.2 |  |
| Total short-term investments | $ | 426.1 |  |  | $ | 1.0 |  |  | $ | (0.2) |  |  | $ | 426.9 |  |
| June 29, 2024: |  |  |  |  |  |  |  |
| Cash | $ | 196.9 |  |  | $ | — |  |  | $ | — |  |  | $ | 196.9 |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | 15.9 |  |  | — |  |  | — |  |  | 15.9 |  |
| Money market funds | 223.9 |  |  | — |  |  | — |  |  | 223.9 |  |
| Total cash and cash equivalents | $ | 436.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 436.7 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 0.8 |  |  | $ | — |  |  | $ | — |  |  | $ | 0.8 |  |
| Commercial paper | 12.6 |  |  | — |  |  | — |  |  | 12.6 |  |
| Corporate debt securities | 244.5 |  |  | — |  |  | (0.6) |  |  | 243.9 |  |
| U.S. Agency securities | 81.2 |  |  | — |  |  | (0.3) |  |  | 80.9 |  |
| U.S. Treasury securities | 112.6 |  |  | — |  |  | (0.5) |  |  | 112.1 |  |
| Total short-term investments | $ | 451.7 |  |  | $ | — |  |  | $ | (1.4) |  |  | $ | 450.3 |  |

[0001628280-24-046443:notes:48]
[same as prior period, unchanged from 0001628280-24-020767:notes:61]

[0001628280-24-046443:notes:49]
We use the specific-identification method to determine any realized gains or losses from the sale of our short-term investments classified as available-for-sale. During the three months ended September 28, 2024 and September 30, 2023, we did not realize significant gains or losses on a gross level from the sale of our short-term investments classified as available-for-sale.

[0001628280-24-046443:notes:50]
During the three months ended September 28, 2024 and September 30, 2023, our other income, net was $8.7 million and $21.2 million, respectively, which includes interest and investment income on cash equivalents and short-term investments of $9.4 million and $21.7 million, respectively.

[0001628280-24-046443:notes:51]
As of September 28, 2024 and June 29, 2024, we recorded interest receivables of $5.8 million and $5.8 million, respectively, in prepayments and other current assets within the condensed consolidated balance sheets. We did not recognize an allowance for credit losses against interest receivables in any of the periods presented, as there were no such losses.

[0001628280-24-046443:notes:52]
[same as prior period, unchanged from 0001628280-24-020767:notes:65]

[0001628280-24-046443:notes:53]
|  | Continuous Loss Position for More Than 12 Months |  | Continuous Loss Position for Less Than 12 Months |  | Gross Unrealized Losses |  |  |  |  |  |  |  |  |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  |  |  |  |  |  |  |  |  |
| September 28, 2024: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | 44.6 |  |  | $ | — |  |  | $ | 4.0 |  |  | $ | — |  |  | $ | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | — |  |  | — |  |  | 7.5 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 67.1 |  |  | (0.1) |  |  | 18.0 |  |  | — |  |  | (0.1) |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 68.4 |  |  | (0.1) |  |  | 22.5 |  |  | — |  |  | (0.1) |  |  |  |  |  |  |  |  |  |
| Total | $ | 180.1 |  |  | $ | (0.2) |  |  | $ | 52.0 |  |  | $ | — |  |  | $ | (0.2) |  |  |  |  |  |  |  |  |  |
| June 29, 2024: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | 62.3 |  |  | $ | (0.3) |  |  | $ | 12.6 |  |  | $ | — |  |  | $ | (0.3) |  |  |  |  |  |  |  |  |  |
| Commercial paper | — |  |  | — |  |  | 28.6 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 133.7 |  |  | (0.5) |  |  | 90.6 |  |  | (0.2) |  |  | (0.7) |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 72.3 |  |  | (0.4) |  |  | 39.7 |  |  | (0.1) |  |  | (0.5) |  |  |  |  |  |  |  |  |  |
| Total | $ | 268.3 |  |  | $ | (1.2) |  |  | $ | 171.5 |  |  | $ | (0.3) |  |  | $ | (1.5) |  |  |  |  |  |  |  |  |  |

[0001628280-24-046443:notes:54]
[same as prior period, unchanged from 0001628280-24-020767:notes:67]

[0001628280-24-046443:notes:55]
|  | September 28, 2024 |  | June 29, 2024 |
|  | Amortized Cost |  | Fair Value |  | Amortized Cost |  | Fair Value |
| Due within 1 year | $ | 346.1 |  |  | $ | 346.3 |  |  | $ | 405.5 |  |  | $ | 404.1 |  |
| Due in 1 year to 5 years | 80.0 |  |  | 80.6 |  |  | 46.2 |  |  | 46.2 |  |
| Total | $ | 426.1 |  |  | $ | 426.9 |  |  | $ | 451.7 |  |  | $ | 450.3 |  |

[0001628280-24-046443:notes:56]
[same as prior period, unchanged from 0001628280-24-020767:notes:69]


## us-gaap:FairValueDisclosuresTextBlock

[0001628280-24-046443:notes:57]
[same as prior period, unchanged from 0001628280-24-020767:notes:70]

[0001628280-24-046443:notes:58]
[same as prior period, unchanged from 0001628280-24-020767:notes:71]

[0001628280-24-046443:notes:59]
[same as prior period, unchanged from 0001628280-24-020767:notes:72]

[0001628280-24-046443:notes:60]
[same as prior period, unchanged from 0001628280-24-020767:notes:73]

[0001628280-24-046443:notes:61]
[same as prior period, unchanged from 0001628280-24-020767:notes:74]

[0001628280-24-046443:notes:62]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| September 28, 2024: (1) |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | — |  |  | $ | 7.5 |  |  | $ | — |  |  | $ | 7.5 |  |
| Money market funds | 184.8 |  |  | — |  |  | — |  |  | 184.8 |  |
| U.S. Treasury securities | 12.0 |  |  | — |  |  | — |  |  | 12.0 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | 0.8 |  |  | — |  |  | 0.8 |  |
| Commercial paper | — |  |  | 11.5 |  |  | — |  |  | 11.5 |  |
| Corporate debt securities | — |  |  | 234.9 |  |  | — |  |  | 234.9 |  |
| U.S. Agency securities | — |  |  | 66.5 |  |  | — |  |  | 66.5 |  |
| U.S. Treasury securities | 113.2 |  |  | — |  |  | — |  |  | 113.2 |  |
| Total assets | $ | 310.0 |  |  | $ | 321.2 |  |  | $ | — |  |  | $ | 631.2 |  |

[0001628280-24-046443:notes:63]
(1)  Excludes $284.9 million in cash held in our bank accounts as of September 28, 2024.

[0001628280-24-046443:notes:64]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| June 29, 2024 (1) |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | — |  |  | $ | 15.9 |  |  | $ | — |  |  | $ | 15.9 |  |
| Money market funds | 223.9 |  |  | — |  |  | — |  |  | 223.9 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | 0.8 |  |  | — |  |  | 0.8 |  |
| Commercial paper | — |  |  | 12.6 |  |  | — |  |  | 12.6 |  |
| Corporate debt securities | — |  |  | 243.9 |  |  | — |  |  | 243.9 |  |
| U.S. Agency securities | — |  |  | 80.9 |  |  | — |  |  | 80.9 |  |
| U.S. Treasury securities | 112.1 |  |  | — |  |  | — |  |  | 112.1 |  |
| Total assets | $ | 336.0 |  |  | $ | 354.1 |  |  | $ | — |  |  | $ | 690.1 |  |

[0001628280-24-046443:notes:65]
(1)  Excludes $196.9 million in cash held in our bank accounts as of June 29, 2024.

[0001628280-24-046443:notes:66]
[same as prior period, unchanged from 0001628280-24-020767:notes:79]

[0001628280-24-046443:notes:67]
[same as prior period, unchanged from 0001628280-24-020767:notes:80]

[0001628280-24-046443:notes:68]
[same as prior period, unchanged from 0001628280-24-020767:notes:81]

[0001628280-24-046443:notes:69]
|  | September 28, 2024 |  | June 29, 2024 |
|  | Carrying Amount |  | Estimated Fair Value |  | Carrying Amount |  | Estimated Fair Value |
| 2029 Notes | $ | 599.6 |  |  | $ | 706.2 |  |  | $ | 599.4 |  |  | $ | 588.8 |  |
| 2028 Notes | 856.9 |  |  | 748.9 |  |  | 856.6 |  |  | 680.2 |  |
| 2026 Notes | 1,047.4 |  |  | 1,034.6 |  |  | 1,047.2 |  |  | 948.3 |  |
|  | $ | 2,503.9 |  |  | $ | 2,489.7 |  |  | $ | 2,503.2 |  |  | $ | 2,217.3 |  |

[0001628280-24-046443:notes:70]
[same as prior period, unchanged from 0001628280-24-020767:notes:83]

[0001628280-24-046443:notes:71]
[same as prior period, unchanged from 0001628280-24-020767:notes:84]

[0001628280-24-046443:notes:72]
Management utilizes various valuation methods, including an income approach, a market approach and a cost approach, to estimate the fair value of intangibles and other long-lived assets. During the annual impairment testing performed in the fourth quarter of fiscal 2024, we concluded that there was no impairment of our intangible and other long-lived assets. We review our intangible and other long-lived assets for impairment at least annually in the fourth quarter of each fiscal year, absent any interim indicators of impairment. There were no indicators of impairment during the three months ended September 28, 2024.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001628280-24-046443:notes:73]
[same as prior period, unchanged from 0001628280-24-020767:notes:86]

[0001628280-24-046443:notes:74]
[same as prior period, unchanged from 0001628280-24-020767:notes:87]

[0001628280-24-046443:notes:75]
We did not have any allowance for credit losses other than our allowance for uncollectible accounts receivable. As of September 28, 2024 and June 29, 2024, the allowance for credit losses on our trade receivables was $0.2 million and $0.2 million, respectively.

[0001628280-24-046443:notes:76]
[same as prior period, unchanged from 0001628280-24-020767:notes:89]

[0001628280-24-046443:notes:77]
[same as prior period, unchanged from 0001628280-24-020767:notes:90]

[0001628280-24-046443:notes:78]
|  | September 28, 2024 |  | June 29, 2024 |
| Raw materials and purchased parts | $ | 206.0 |  |  | $ | 196.9 |  |
| Work in process | 119.1 |  |  | 101.6 |  |
| Finished goods | 78.2 |  |  | 99.9 |  |
| Inventories | $ | 403.3 |  |  | $ | 398.4 |  |

[0001628280-24-046443:notes:79]
In connection with the Cloud Light acquisition, we recorded $72.8 million of inventory as of the Cloud Light Closing Date. As of June 29, 2024, the entire $8.0 million of fair value step-up of inventory acquired from Cloud Light was amortized and recognized as cost of sales in our condensed consolidated statements of operations.

[0001628280-24-046443:notes:80]
[same as prior period, unchanged from 0001628280-24-020767:notes:93]

[0001628280-24-046443:notes:81]
[same as prior period, unchanged from 0001628280-24-020767:notes:94]

[0001628280-24-046443:notes:82]
|  | September 28, 2024 |  | June 29, 2024 |
| Land | $ | 108.6 |  |  | $ | 75.2 |  |
| Buildings and improvements | 258.8 |  |  | 215.1 |  |
| Machinery and equipment | 778.9 |  |  | 772.1 |  |
| Computer equipment and software | 44.9 |  |  | 44.9 |  |
| Furniture and fixtures | 13.9 |  |  | 14.3 |  |
| Leasehold improvements | 44.8 |  |  | 47.5 |  |
| Construction in progress | 81.6 |  |  | 71.1 |  |
|  | 1,331.5 |  |  | 1,240.2 |  |
| Less: Accumulated depreciation | (693.1) |  |  | (667.7) |  |
| Property, plant and equipment, net | $ | 638.4 |  |  | $ | 572.5 |  |

[0001628280-24-046443:notes:83]
In connection with the Cloud Light acquisition, we assumed $62.5 million of property, plant and equipment, net, as of the acquisition Cloud Light Closing Date.

[0001628280-24-046443:notes:84]
[same as prior period, unchanged from 0001628280-24-020767:notes:97]

[0001628280-24-046443:notes:85]
In July 2024, we purchased the land and building of our wafer fabrication facility located in Sagamihara, Japan for a total transaction price of $42.2 million including $1.3 million of incremental direct costs for fees paid to third parties that were capitalized. We also recorded a $16.3 million increase in the carrying value of buildings purchased related to the termination of leases for the purchased building. The total carrying value of assets purchased was $58.5 million at the purchase date, of which $33.4 million was allocated to the land and $25.1 million to the building.

[0001628280-24-046443:notes:86]
[same as prior period, unchanged from 0001628280-24-020767:notes:98]

[0001628280-24-046443:notes:87]
During the three months ended September 28, 2024 and September 30, 2023, we recorded depreciation expense of $27.0 million and $28.2 million, respectively.

[0001628280-24-046443:notes:88]
[same as prior period, unchanged from 0001628280-24-020767:notes:100]

[0001628280-24-046443:notes:89]
[same as prior period, unchanged from 0001628280-24-020767:notes:101]

[0001628280-24-046443:notes:90]
|  | September 28, 2024 |  | June 29, 2024 |
| Operating lease right-of-use assets | $ | 66.1 |  |  | $ | 112.3 |  |
| Less: accumulated amortization | (30.4) |  |  | (39.5) |  |
| Operating lease right-of-use assets, net | $ | 35.7 |  |  | $ | 72.8 |  |

[0001628280-24-046443:notes:91]
In connection with our integration efforts to consolidate our sites, we recorded restructuring charges for various sites and reduced our operating lease right-of-use assets by $5.3 million during the three months ended September 28, 2024.

[0001628280-24-046443:notes:92]
In connection with the Cloud Light acquisition, we acquired $3.7 million of right-of-use assets related to leases of real estate properties used as our manufacturing and office premises.  We accounted for these leases as operating leases and have the remaining lease term ranging from 1.5 to 2.6 years at the Cloud Light Closing Date.

[0001628280-24-046443:notes:93]
In connection with the purchase of land and building in Sagamihara, Japan in July 2024, we terminated our leases for the related facilities and recorded a $16.3 million increase in the carrying value of building purchased, as a result of derecognizing $32.0 million of net operating lease right-of-use asset, $1.6 million of operating lease liabilities, current, and $14.1 million of operating lease liabilities, non-current.

[0001628280-24-046443:notes:94]
In connection with the purchase of land and buildings in the United Kingdom in August 2023, we terminated our leases for the related facilities and recorded a $0.3 million of reduction in the carrying value of buildings purchased, as a result of derecognizing $4.8 million of net operating lease right-of-use asset, $2.4 million of operating lease liabilities, current, and $2.7 million of operating lease liabilities, non-current.

[0001628280-24-046443:notes:95]
[same as prior period, unchanged from 0001628280-24-020767:notes:105]

[0001628280-24-046443:notes:96]
[same as prior period, unchanged from 0001628280-24-020767:notes:106]

[0001628280-24-046443:notes:97]
|  | September 28, 2024 |  | June 29, 2024 |
| Restructuring accrual and related charges (1) | $ | 6.3 |  |  | $ | 11.1 |  |
| Warranty reserve (2) | 13.2 |  |  | 13.2 |  |
| Deferred revenue and customer deposits | 0.6 |  |  | 0.6 |  |
| Income tax payable (3) | 11.9 |  |  | 13.2 |  |
| Other current liabilities | 5.6 |  |  | 3.0 |  |
| Other current liabilities | $ | 37.6 |  |  | $ | 41.1 |  |

[0001628280-24-046443:notes:98]
[same as prior period, unchanged from 0001628280-24-020767:notes:108]

[0001628280-24-046443:notes:99]
(2) Refer to “Note 14. Commitments and Contingencies.”

[0001628280-24-046443:notes:100]
[same as prior period, unchanged from 0001628280-24-020767:notes:110]

[0001628280-24-046443:notes:101]
[same as prior period, unchanged from 0001628280-24-020767:notes:111]

[0001628280-24-046443:notes:102]
[same as prior period, unchanged from 0001628280-24-020767:notes:112]

[0001628280-24-046443:notes:103]
|  | September 28, 2024 |  | June 29, 2024 |
| Asset retirement obligations | $ | 7.0 |  |  | $ | 7.5 |  |
| Pension and related accruals (1) | 8.6 |  |  | 7.5 |  |
| Unrecognized tax benefit | 94.4 |  |  | 83.0 |  |
| Other non-current liabilities | 6.2 |  |  | 5.4 |  |
| Other non-current liabilities | $ | 116.2 |  |  | $ | 103.4 |  |

[0001628280-24-046443:notes:104]
(1) We have defined benefit pension plans in Japan, Switzerland, and Thailand. Pension and related accrual of $8.6 million as of September 28, 2024 represents $9.5 million of non-current portion of benefit obligation, offset by $0.9 million of funding for the pension plan in Switzerland. Pension and related accrual of $7.5 million as of June 29, 2024 relates to $8.6 million of non-current portion of benefit obligation, offset by $1.2 million of funding for the pension plan in Switzerland. We typically re-evaluate the assumptions related to the fair value of our defined benefit obligations annually in the fiscal fourth quarter and make any updates as necessary


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001628280-24-046443:notes:105]
[same as prior period, unchanged from 0001628280-24-020767:notes:115]

[0001628280-24-046443:notes:106]
[same as prior period, unchanged from 0001628280-24-020767:notes:116]

[0001628280-24-046443:notes:107]
In November 2023, we completed the acquisition of Cloud Light. We recognized goodwill of $365.8 million, which was allocated to the Cloud & Networking segment.

[0001628280-24-046443:notes:108]
The following table presents goodwill by reportable segments as of September 28, 2024 and June 29, 2024 (in millions):

[0001628280-24-046443:notes:109]
|  | Cloud & Networking |  | Industrial Tech |  | Total |
| Balances as of June 29, 2024 | $ | 1,044.6 |  |  | $ | 11.2 |  |  | $ | 1,055.8 |  |
| Acquisition of Cloud Light (1) | 5.1 |  |  | — |  |  | 5.1 |  |
| Balances as of September 28, 2024 | $ | 1,049.7 |  |  | $ | 11.2 |  |  | $ | 1,060.9 |  |

[0001628280-24-046443:notes:110]
(1) During the three months ended September 28, 2024, we adjusted the purchase price allocation and recorded a $5.1 million increase to goodwill. The primary adjustment to the opening balance sheet relates to income tax liabilities which were not known in previous periods.

[0001628280-24-046443:notes:111]
[same as prior period, unchanged from 0001628280-24-020767:notes:121]

[0001628280-24-046443:notes:112]
We review goodwill for impairment during the fourth quarter of each fiscal year or more frequently if events or circumstances indicate that an impairment loss may have occurred. In the fourth quarter of fiscal 2024, we completed the annual impairment test of goodwill, which indicated there was no goodwill impairment. There were no indicators of goodwill impairment during the three months ended September 28, 2024.

[0001628280-24-046443:notes:113]
[same as prior period, unchanged from 0001628280-24-020767:notes:123]

[0001628280-24-046443:notes:114]
[same as prior period, unchanged from 0001628280-24-020767:notes:124]

[0001628280-24-046443:notes:115]
[same as prior period, unchanged from 0001628280-24-020767:notes:125]

[0001628280-24-046443:notes:116]
During the annual impairment testing performed in the fourth quarter of fiscal 2024, we concluded that our intangible and other long-lived assets were not impaired at the asset group level. We review our intangible and other long-lived assets for impairment at least annually in the fourth quarter of each fiscal year, absent any interim indicators of impairment. There were no indicators of impairment at the asset group level during the three months ended September 28, 2024.

[0001628280-24-046443:notes:117]
[same as prior period, unchanged from 0001628280-24-020767:notes:127]

[0001628280-24-046443:notes:118]
[same as prior period, unchanged from 0001628280-24-020767:notes:128]

[0001628280-24-046443:notes:119]
Refer to “Note 4. Business Combinations” for the acquisitions of Cloud Light.

[0001628280-24-046443:notes:120]
[same as prior period, unchanged from 0001628280-24-020767:notes:132]

[0001628280-24-046443:notes:121]
| September 28, 2024 | Gross Carrying Amounts |  | Accumulated Amortization |  | Net Carrying Amounts |  | Weighted Average Remaining Amortization Period (Years) |
| Acquired developed technologies | $ | 818.2 |  |  | $ | (496.4) |  |  | $ | 321.8 |  |  | 4.6 |
| Customer relationships | 419.8 |  |  | (183.7) |  |  | 236.1 |  |  | 4.7 |
| In-process research and development | 13.6 |  |  | — |  |  | 13.6 |  |  | n/a |
| Order backlog | 14.0 |  |  | (12.4) |  |  | 1.6 |  |  | 0.1 |
| Trade name and trademarks | 3.0 |  |  | (2.2) |  |  | 0.8 |  |  | 0.3 |
| Total intangible assets | $ | 1,268.6 |  |  | $ | (694.7) |  |  | $ | 573.9 |  |  |  |

[0001628280-24-046443:notes:122]
| June 29, 2024 | Gross Carrying Amounts |  | Accumulated Amortization |  | Net Carrying Amounts |  | Weighted Average Remaining Amortization Period (Years) |
| Acquired developed technologies | $ | 818.1 |  |  | $ | (473.0) |  |  | $ | 345.1 |  |  | 4.8 |
| Customer relationships | 419.8 |  |  | (169.4) |  |  | 250.4 |  |  | 4.9 |
| In-process research and development | 15.5 |  |  | — |  |  | 15.5 |  |  | n/a |
| Order backlog | 14.0 |  |  | (8.9) |  |  | 5.1 |  |  | 0.4 |
| Trade name and trademarks | 3.0 |  |  | (1.6) |  |  | 1.4 |  |  | 0.6 |
| Total intangible assets | $ | 1,270.4 |  |  | $ | (652.9) |  |  | $ | 617.5 |  |  |  |

[0001628280-24-046443:notes:123]
[same as prior period, unchanged from 0001628280-24-020767:notes:135]

[0001628280-24-046443:notes:124]
|  | Three Months Ended |  |  |
|  | September 28, 2024 |  | September 30, 2023 |  |  |  |  |
| Cost of sales | $ | 22.5 |  |  | $ | 18.0 |  |  |  |  |  |
| Research and development | 0.4 |  |  | 0.3 |  |  |  |  |  |
| Selling, general and administrative | 18.8 |  |  | 10.7 |  |  |  |  |  |
| Total amortization of intangibles | $ | 41.7 |  |  | $ | 29.0 |  |  |  |  |  |

[0001628280-24-046443:notes:125]
Based on the carrying amount of our acquired intangible assets except in-process research and development as of September 28, 2024, and assuming no future impairment of the underlying assets, the estimated future amortization is as follows (in millions):

[0001628280-24-046443:notes:126]
| Fiscal Years |  |
| Remainder of 2025 | $ | 107.6 |  |
| 2026 | 133.3 |  |
| 2027 | 121.0 |  |
| 2028 | 81.5 |  |
| 2029 | 51.8 |  |
| Thereafter | 65.1 |  |
| Total future amortization | $ | 560.3 |  |


## us-gaap:ScheduleOfFiniteLivedIntangibleAssetsTableTextBlock

[0001628280-24-046443:notes:127]
[same as prior period, unchanged from 0001628280-24-020767:notes:139]


## us-gaap:DebtDisclosureTextBlock

[0001628280-24-046443:notes:128]
Note 9. Debt

[0001628280-24-046443:notes:129]
Convertible Notes

[0001628280-24-046443:notes:130]
2029 Notes

[0001628280-24-046443:notes:131]
On June 16, 2023, we issued $603.7 million in aggregate principal amount of 1.50% Convertible Senior Notes due in 2029 (“2029 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act of 1933, as amended. The 2029 Notes are governed by an indenture between the Company and U.S. Bank Trust Company, National Association, (as successor in interest to U.S. Bank National Association), as a trustee (the “2029 Indenture”). The 2029 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001628280-24-046443:notes:132]
The net proceeds from the sale of the 2029 Notes was $599.4 million, after deducting $4.3 million of net issuance costs. In addition, we incurred $0.8 million of professional fees directly related to this transaction. Concurrent with the issuance of the 2029 Notes, we used $132.8 million of the net proceeds to repurchase $125.0 million aggregate principal amount of the 2024 Notes and $125.0 million of the net proceeds to repurchase our common stock in privately negotiated transactions. We intend to use the remaining net proceeds for general corporate purposes, which may include the repayment of our indebtedness, including any of our existing convertible notes, capital expenditures, working capital and potential acquisitions.

[0001628280-24-046443:notes:133]
The 2029 Notes bear interest at a rate of 1.50% per year, payable semi-annually in arrears on June 15 and December 15 of each year. The 2029 Notes will mature on December 15, 2029, unless earlier redeemed, repurchased by us, or converted pursuant to their terms.

[0001628280-24-046443:notes:134]
The initial conversion rate is 14.3808 shares of common stock per $1,000 principal amount of the 2029 Notes (which is equivalent to an initial conversion price of approximately $69.54 per share). The conversion rate is subject to adjustment upon the occurrence of certain events specified in the 2029 Indenture but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert the 2029 Notes in connection with such make-whole fundamental change or notice of redemption.

[0001628280-24-046443:notes:135]
Prior to the close of business on the business day immediately preceding September 15, 2029, holders of the 2029 Notes may convert their 2029 Notes only under the following circumstances:

[0001628280-24-046443:notes:136]
•during any fiscal quarter commencing after September 30, 2023 (and only during such fiscal quarter), if the last reported sale price of the common stock for at least 20 trading days (whether or not consecutive) during the period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% if the applicable conversion price on each applicable trading day;

[0001628280-24-046443:notes:137]
•during the five consecutive business day period after any five consecutive trading day period (the “2029 measurement period”) in which the trading price per $1,000 principal amount of 2029 Notes for each trading day of the 2029 measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate on each such trading day;

[0001628280-24-046443:notes:138]
•if we call any or all of the 2029 Notes for redemption, at any time prior to the close of business on the second business day immediately preceding the redemption date; or

[0001628280-24-046443:notes:139]
•upon the occurrence of specified corporate events as specified in the 2029 Indenture.

[0001628280-24-046443:notes:140]
On or after September 15, 2029 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their 2029 Notes at any time. Following our irrevocable settlement method election made on September 25, 2024, upon conversion, we are required to satisfy our conversion obligation with respect to such converted 2029 Notes by delivering cash equal to the principal amount of such converted 2029 Notes and cash, shares of common stock or a combination of cash and shares of common stock, at our election, with respect to any conversion value in excess thereof.

[0001628280-24-046443:notes:141]
We may redeem for cash all or any portion of the 2029 Notes, at our option (subject to the partial redemption limitation set forth in the 2029 Indenture), on or after June 22, 2026, if the last reported sale price of our  common stock has been at least 130% of the conversion price then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading-day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which we provide notice of redemption at a redemption price equal to 100% of the principal amount of the 2029 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. No sinking fund is provided for the 2029 Notes. If we elect to redeem fewer than all of the outstanding 2029 Notes, at least $100.0 million aggregate principal amount of the 2029 Notes must be outstanding and not subject to redemption as of the redemption notice date. Upon the occurrence of a fundamental change (as defined in the 2029 Indenture), holders may require us to repurchase all or a portion of their 2029 Notes for cash at a price equal to 100% of the principal amount of the 2029 Notes to be repurchased, plus any accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

[0001628280-24-046443:notes:142]
The entire 2029 Notes are recorded as convertible notes, non-current in our consolidated balance sheets as of September 28, 2024 and June 29, 2024, measured at amortized cost.

[0001628280-24-046443:notes:143]
2028 Notes

[0001628280-24-046443:notes:144]
In March 2022, we issued $861.0 million in aggregate principal amount of 0.50% Convertible Senior Notes due in 2028 (the “2028 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act of 1933, as amended (the “Securities Act”). The 2028 Notes are governed by an indenture between the Company and U.S. Bank Trust Company, National Association (as successor in interest to U.S. Bank National Association), as trustee (the “2028 Indenture”). The 2028 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001628280-24-046443:notes:145]
The net proceeds from the sale of the 2028 Notes was $854.8 million, after deducting $6.2 million in issuance costs. In addition, we incurred $0.7 million in professional fees in connection with this transaction. Concurrent with the issuance of the 2028 Notes, we used $200.0 million of the net proceeds to repurchase our common stock in privately negotiated transactions.

[0001628280-24-046443:notes:146]
The 2028 Notes bear interest at a rate of 0.50% per year, payable semi-annually in arrears on June 15 and December 15 of each year. The 2028 Notes will mature on June 15, 2028, unless earlier redeemed, repurchased by us, or converted pursuant to their terms.

[0001628280-24-046443:notes:147]
The initial conversion rate is 7.6319 shares of common stock per $1,000 principal amount of the 2028 Notes (which is equivalent to an initial conversion price of approximately $131.03 per share). The conversion rate is subject to adjustment upon the occurrence of certain specified events, but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change (as defined in the 2028 Indenture) or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert the 2028 Notes in connection with such make-whole fundamental change or notice of redemption.

[0001628280-24-046443:notes:148]
Prior to the close of business on the business day immediately preceding March 15, 2028, holders of the 2028 Notes may convert their 2028 Notes only under the following circumstances:

[0001628280-24-046443:notes:149]
•during any fiscal quarter (and only during such fiscal quarter), if the last reported sale price of the Company’s common stock for at least 20 trading days (whether or not consecutive) during the 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price, or $170.34, on each applicable trading day;

[0001628280-24-046443:notes:150]
•during the five consecutive business day period after any five consecutive trading day period (the “measurement period”) in which the trading price per $1,000 principal amount of the 2028 Notes for each trading day of such

[0001628280-24-046443:notes:151]
measurement period was less than 98% of the product of the last reported sale price of the Company’s common stock and the applicable conversion rate on each such trading day;

[0001628280-24-046443:notes:152]
•if the Company calls any or all of the 2028 Notes for redemption, at any time prior to the close of business on the second business day immediately preceding the redemption date; or

[0001628280-24-046443:notes:153]
•upon the occurrence of specified corporate events, as specified in the 2028 Indenture.

[0001628280-24-046443:notes:154]
On or after March 15, 2028 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their 2028 Notes at any time. Following our irrevocable settlement method election made on September 25, 2024, upon conversion, we are required to satisfy our conversion obligation with respect to such converted 2028 Notes by delivering cash equal to the principal amount of such converted 2028 Notes and cash, shares of common stock or a combination of cash and shares of common stock, at our election, with respect to any conversion value in excess thereof.

[0001628280-24-046443:notes:155]
We may redeem for cash all or any portion of the 2028 Notes, at our option (subject to the partial redemption limitation set forth in the 2028 Indenture), on or after June 20, 2025, if the last reported sale price of its common stock has been at least 130% of the conversion price then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading-day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which the Company provides notice of redemption at a redemption price equal to 100% of the principal amount of the 2028 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. No sinking fund is provided for the 2028 Notes. If we elect to redeem fewer than all of the outstanding 2028 Notes, at least $100.0 million aggregate principal amount of the 2028 Notes must be outstanding and not subject to redemption as of the redemption notice date. Upon the occurrence of a fundamental change (as defined in the 2028 Indenture), holders may require the Company to repurchase all or a portion of their 2028 Notes for cash at a price equal to 100% of the principal amount of the 2028 Notes to be repurchased, plus any accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

[0001628280-24-046443:notes:156]
We initially bifurcated the principal amount of the 2028 Notes into liability and equity components. The liability component of the 2028 Notes was initially valued at $629.8 million based on the contractual cash flow discounted at an appropriate comparable market on non-convertible debt borrowing rate at the date of issuance, which was 5.7%, with the equity component representing the residual amount of the proceeds of $231.2 million, which was recorded as a debt discount. Upon adoption of ASU 2020-06 in the first quarter of fiscal 2023, our 2028 Notes were accounted for as a single liability measured at amortized cost. The entire 2028 Notes are recorded as convertible notes, non-current in our consolidated balance sheets as of September 28, 2024 and June 29, 2024, measured at amortized cost.

[0001628280-24-046443:notes:157]
2026 Notes

[0001628280-24-046443:notes:158]
In December 2019, we issued $1,050.0 million in aggregate principal amount of 0.50% Convertible Senior Notes due in 2026 (the “2026 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act. The 2026 Notes are governed by an indenture between the Company and U.S. Bank Trust Company, National Association (as successor in interest to U.S. Bank National Association, as trustee (as supplemented by the First Supplemental Indenture, dated as of September 25, 2024, the “2026 Indenture”). We used approximately $196.0 million of the net proceeds of the offering to repay in full all amounts outstanding under our term loan credit facility, and a portion of the net proceeds of the offering to purchase approximately $200.0 million of our common stock concurrently with the pricing of the offering in privately negotiated transactions. The 2026 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001628280-24-046443:notes:159]
The 2026 Notes bear interest at a rate of 0.50% per year, payable semi-annually in arrears on June 15 and December 15 of each year. The 2026 Notes will mature on December 15, 2026, unless earlier redeemed, repurchased by us, or converted pursuant to their terms.

[0001628280-24-046443:notes:160]
The initial conversion rate is 10.0711 shares of common stock per $1,000 principal amount of the 2026 Notes (which is equivalent to an initial conversion price of approximately $99.29 per share). The conversion rate is subject to adjustment upon the occurrence of certain events specified in the 2026 Indenture but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change (as defined in the 2026 Indenture) or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares set forth in the 2026 Indenture or a holder that elects to convert the 2026 Notes in connection with such make-whole fundamental change or notice of redemption.

[0001628280-24-046443:notes:161]
Prior to the close of business on the business day immediately preceding September 15, 2026, holders of the 2026 Notes may convert their 2026 Notes only under the following circumstances:

[0001628280-24-046443:notes:162]
•during any fiscal quarter (and only during such fiscal quarter), if the last reported sale price of the common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price of the 2026 Notes, or $129.08 on each applicable trading day;

[0001628280-24-046443:notes:163]
•during the five consecutive business day period after any five consecutive trading day period (the “2026 measurement period”) in which the trading price per $1,000 principal amount of the 2026 Notes for each trading day of the 2026 measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate for the 2026 Notes on each such trading day;

[0001628280-24-046443:notes:164]
•if we call any or all of the 2026 Notes for redemption, at any time prior to the close of business on the second business day immediately preceding the relevant redemption date; or

[0001628280-24-046443:notes:165]
•upon the occurrence of specified corporate events.

[0001628280-24-046443:notes:166]
On or after September 15, 2026 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their 2026 Notes at any time. Following our entry into the First Supplemental Indenture, dated as of September 25, 2024, to the 2026 Indenture, upon conversion, we are required to satisfy our conversion obligation with respect to such converted 2026 Notes by delivering cash equal to the principal amount of such converted 2026 Notes and cash, shares of common stock or a combination of cash and shares of common stock, at our election, with respect to any conversion value in excess thereof.

[0001628280-24-046443:notes:167]
We may redeem for cash, all or any portion of the 2026 Notes, at our option, on or after December 20, 2023, if the last reported sale price of its common stock has been at least 130% of the conversion price then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading-day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which we provide a notice of redemption at a redemption price equal to 100% of the principal amount of the 2026 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. No sinking fund is provided for the 2026 Notes. Upon the occurrence of a fundamental change (as defined in the 2026 Indenture), holders may require us to repurchase all or a portion of the 2026 Notes for cash at a price equal to 100% of the principal amount of the 2026 Notes to be repurchased, plus any accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

[0001628280-24-046443:notes:168]
We initially bifurcated the principal amount of the 2026 Notes into liability and equity components. The liability component of the 2026 Notes was initially valued at $734.8 million based on the contractual cash flows discounted at an appropriate comparable market non-convertible debt borrowing rate at the date of issuance of 5.8% with the equity component representing the residual amount of the proceeds of $315.2 million, which was recorded as a debt discount. Upon adoption of ASU 2020-06 in the first quarter of fiscal 2023, our 2026 Notes were accounted for as a single liability measured at amortized cost. The entire 2026 Notes are recorded as convertible notes, non-current in our consolidated balance sheets as of September 28, 2024 and June 29, 2024, measured at amortized cost.

[0001628280-24-046443:notes:169]
2024 Notes

[0001628280-24-046443:notes:170]
In March 2017, we issued $450.0 million in aggregate principal amount of 0.25% convertible senior notes due in 2024 (the “2024 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act. The 2024 Notes were governed by an indenture between the Company, as the issuer, and U.S. Bank Trust Company National Association (as successor in interest to U.S. Bank National Association), as trustee (the “2024 Indenture”). The 2024 Notes were unsecured and did not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001628280-24-046443:notes:171]
The 2024 Notes bore interest at a rate of 0.25% per year. Interest on the 2024 Notes was payable semi-annually in arrears on March 15 and September 15 of each year. The 2024 Notes matured on March 15, 2024.

[0001628280-24-046443:notes:172]
The initial conversion rate of the 2024 Notes was 16.4965 shares of common stock per $1,000 principal amount of 2024 Notes, which was equivalent to an initial conversion price of approximately $60.62 per share. The conversion rate was subject to adjustment upon the occurrence of certain specified events but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change (as defined in the 2024 Indenture) or our issuance of a notice of redemption, we were required to, in certain circumstances, increase the conversion rate by a number of additional

[0001628280-24-046443:notes:173]
shares for a holder that elected to convert the 2024 Notes in connection with such make-whole fundamental change or notice of redemption.

[0001628280-24-046443:notes:174]
Prior to the close of business on the business day immediately preceding December 15, 2023, each holder of the 2024 Notes was able to convert their 2024 Notes only under the following circumstances:

[0001628280-24-046443:notes:175]
•during any fiscal quarter (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during the period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter was greater than or equal to 130% of the applicable conversion price, or $78.80 on each applicable trading day;

[0001628280-24-046443:notes:176]
•during the five consecutive business day period after any five consecutive trading day period (the “2024 measurement period”) in which the trading price per $1,000 principal amount of 2024 Notes for each trading day of such 2024 measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate for the 2024 Notes on each such trading day; or

[0001628280-24-046443:notes:177]
On or after December 15, 2023 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders could convert their 2024 Notes at any time. In addition, upon the occurrence of a make-whole fundamental change (as defined in the 2024 Indenture), we were required to, in certain circumstances, increase the conversion rate by a number of additional shares set forth in the 2024 Indenture for a holder that elected to convert 2024 Notes in connection with such make-whole fundamental change.

[0001628280-24-046443:notes:178]
We could not redeem the 2024 Notes prior to their maturity date and no sinking fund was provided for the 2024 Notes. Upon the occurrence of a fundamental change (as defined in the 2024 Indenture), holders could require us to repurchase all or a portion of their 2024 Notes for cash at a price equal to 100% of the principal amount of the 2024 Notes to be repurchased, plus any accrued and unpaid interest.

[0001628280-24-046443:notes:179]
We considered the features embedded in the 2024 Notes other than the conversion feature, including the holders’ put feature, our call feature, and the make-whole feature, and concluded that they are not required to be bifurcated and accounted for separately from the host debt instrument.

[0001628280-24-046443:notes:180]
Prior to the Tax Matters Agreement settlement condition (“TMA settlement condition”), because we could only settle the 2024 Notes in cash, we determined that the conversion feature met the definition of a derivative liability. We separated the derivative liability from the host debt instrument based on the fair value of the derivative liability. As of the issuance date, March 8, 2017, the derivative liability fair value of $129.9 million was calculated using the binomial valuation approach. The residual principal amount of the 2024 Notes of $320.1 million before issuance costs was allocated to the debt component. We incurred approximately $7.7 million in transaction costs in connection with the issuance of the 2024 Notes. These costs were allocated to the debt component and recognized as a debt discount. We amortized the debt discount, including both the initial value of the derivative liability and the transaction costs, over the term of the 2024 Notes using the effective interest method. The effective interest rate of the 2024 Notes was 5.4% per year.

[0001628280-24-046443:notes:181]
During fiscal 2017, we satisfied the TMA settlement condition. As such, the value of the conversion option was no longer marked-to-market and was reclassified to additional paid-in capital within stockholders’ equity on our condensed consolidated balance sheets. The value of the conversion option at the time of issuance was treated as an original issue discount for purposes of accounting for the debt component of the 2024 Notes. The debt component accreted up to the original amount over the term of the debt. The adoption of ASU 2020-06 did not change the presentation of the 2024 Notes, as the conversion feature associated with the 2024 Notes was classified within stockholders’ equity.

[0001628280-24-046443:notes:182]
Concurrent with the issuance of the 2029 Notes in June 2023, we used $132.8 million of the net proceeds to repurchase $125.0 million aggregate principal amount of the 2024 Notes, which we accounted for as an extinguishment of liability. $13.5 million of the $132.8 million repurchase price was allocated to the conversion feature of the repurchased 2024 Notes, representing the fair value of the conversion feature at the date of the repurchase, and was recognized as a reduction of the stockholders’ equity. Additionally, since issuing the 2024 Notes, we converted a total of approximately $1.9 million of principal amount of the 2024 Notes, with less than $0.1 million of principle amount converted during the three months ended September 28, 2024.

[0001628280-24-046443:notes:183]
On March 15, 2024, the 2024 Notes maturity date, we fully repaid the remaining principal amount of $323.1 million. The

[0001628280-24-046443:notes:184]
conversion feature previously classified within stockholder’s equity was fully amortized as of the maturity date.

[0001628280-24-046443:notes:185]
Convertible Notes - Additional Disclosures

[0001628280-24-046443:notes:186]
On September 25, 2024, Lumentum entered into the First Supplemental Indenture to the 2029 Indenture, 2028 Indenture and 2026 Indenture, pursuant to which we irrevocably elected to settle the principal amounts of the 2029 Notes, 2028 Notes and 2026 Notes in cash. Any amounts due above the principal may be settled in cash, equity, or any combination thereof at the election of the Company.

[0001628280-24-046443:notes:187]
Our convertible notes consisted of the following components as of the periods presented (in millions):

[0001628280-24-046443:notes:188]
| September 28, 2024 |  |  | 2026 Notes (1) |  | 2028 Notes (2) |  | 2029 Notes (3) |  | Total |  |  |  |  |  |
| Principal |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |  | $ | 603.7 |  |  | $ | 2,514.7 |  |  |  |  |  |  |
| Unamortized debt discount and debt issuance costs |  |  | (2.6) |  |  | (4.1) |  |  | (4.1) |  |  | (10.8) |  |  |  |  |  |  |
| Net carrying amount of the liability component |  |  | $ | 1,047.4 |  |  | $ | 856.9 |  |  | $ | 599.6 |  |  | $ | 2,503.9 |  |  |  |  |  |  |

[0001628280-24-046443:notes:189]
| June 29, 2024 |  |  | 2026 Notes (1) |  | 2028 Notes (2) |  | 2029 Notes (3) |  | Total |
| Principal |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |  | $ | 603.7 |  |  | $ | 2,514.7 |  |
| Unamortized debt discount and debt issuance costs |  |  | (2.8) |  |  | (4.4) |  |  | (4.3) |  |  | (11.5) |  |
| Net carrying amount of the liability component |  |  | $ | 1,047.2 |  |  | $ | 856.6 |  |  | $ | 599.4 |  |  | $ | 2,503.2 |  |

[0001628280-24-046443:notes:190]
(1) If the closing price of our stock exceeds $129.08 (or 130% of the conversion price of $99.29) for 20 of the last 30 trading days of any future fiscal quarter, our 2026 Notes would become convertible at the option of the holders during the subsequent fiscal quarter and the debt would be reclassified to current liabilities in our condensed consolidated balance sheet.

[0001628280-24-046443:notes:191]
(2) If the closing price of our stock exceeds $170.34 (or 130% of the conversion price of $131.03) for 20 of the last 30 trading days of any future fiscal quarter, our 2028 Notes would become convertible at the option of the holders during the subsequent fiscal quarter and the debt would be reclassified to current liabilities in our condensed consolidated balance sheet.

[0001628280-24-046443:notes:192]
(3) If the closing price of our stock exceeds $90.40 (or 130% of the conversion price of $69.54) for 20 of the last 30 trading days of any future quarter, the 2029 Notes would become convertible at the option of the holders during the subsequent fiscal quarter and the debt would be reclassified to current liabilities in our consolidated balance sheets.

[0001628280-24-046443:notes:193]
The following table sets forth interest expense information related to the convertible notes for the periods presented (in millions):

[0001628280-24-046443:notes:194]
|  | Three Months Ended |  |  |
|  | September 28, 2024 |  | September 30, 2023 |  |  |  |  |
| Contractual interest expense | $ | 4.7 |  |  | $ | 4.8 |  |  |  |  |  |
| Amortization of the debt discount and debt issuance costs | 0.7 |  |  | 4.9 |  |  |  |  |  |
| Total interest expense | $ | 5.4 |  |  | $ | 9.7 |  |  |  |  |  |

[0001628280-24-046443:notes:195]
The future interest and principal payments related to our convertible notes are as follows as of September 28, 2024 (in millions):

[0001628280-24-046443:notes:196]
| Fiscal Years |  |  | 2026 Notes |  | 2028 Notes |  | 2029 Notes |  | Total |
| 2025 |  |  | $ | 5.3 |  |  | $ | 4.3 |  |  | $ | 9.1 |  |  | $ | 18.7 |  |
| 2026 |  |  | 5.3 |  |  | 4.3 |  |  | 9.1 |  |  | 18.7 |  |
| 2027 |  |  | 1,052.5 |  |  | 4.3 |  |  | 9.1 |  |  | 1,065.9 |  |
| 2028 |  |  | — |  |  | 865.3 |  |  | 9.1 |  |  | 874.4 |  |
| 2029 |  |  | — |  |  | — |  |  | 617.1 |  |  | 617.1 |  |
| Total payments |  |  | $ | 1,063.1 |  |  | $ | 878.2 |  |  | $ | 653.5 |  |  | $ | 2,594.8 |  |

[0001628280-24-046443:notes:197]
The principal balances of our convertible notes are reflected in the payment periods in the table above based on their respective contractual maturities.

[0001628280-24-046443:notes:198]
Term Loans

[0001628280-24-046443:notes:199]
SMBC Term Loan

[0001628280-24-046443:notes:200]
On August 9, 2024, the Company entered into a term loan agreement with Sumitomo Mitsui Banking Corporation (“SMBC”). The SMBC term loan provides an aggregate principal amount of 6.4 billion Japanese yen (“JPY”). The loan requires monthly payments of the principal amounting to approximately 53.3 million JPY, which commenced on August 31, 2024 totaling approximately 3.1 billion JPY and interest based on a fixed annual interest rate of 0.88%, with the remaining principal of approximately 3.3 billion JPY due on the loan maturity date of July 31, 2029. Under the loan agreement, the Company cannot prepay the outstanding loan without SMBC’s approval.  In the event the Company prepays the outstanding loan with SMBC’s approval, the Company shall pay SMBC settlement money pursuant to the loan agreement. The term loan is secured by the real estate owned in Sagamihara, Japan.

[0001628280-24-046443:notes:201]
As of September 28, 2024, the Company has $44.5 million in principal amount outstanding, of which the short-term portion of $4.5 million is recorded as current liabilities while the long-term portion of $40.0 million is recorded as long-term debt in the Company’s condensed consolidated balance sheets.

[0001628280-24-046443:notes:202]
Mizuho Term Loan

[0001628280-24-046443:notes:203]
On September 20, 2024, the Company entered into a loan agreement with Mizuho Bank, Ltd. (the “Mizuho Term Loan”), in order to finance our planned manufacturing expansions. The Mizuho Term Loan provides for borrowings of 4.5 billion JPY with a 5-year term from the funding date September 20, 2024. The loan requires quarterly principal payments of approximately 225.0 million JPY commencing on December 20, 2024 with the final payment on September 20, 2029. The Mizuho Term Loan bears a fixed annual interest rate of 0.90%. The term loan is secured by the real estate assets owned by NeoPhotonics Semiconductor GK. The Mizuho Term Loan agreement requires that the Company and certain domestic subsidiaries comply with covenants relating to customary matters, including obtaining prior approval from lender in case of transferring, creating a security interest, or disposing the collateral assets; obtaining prior approval from lender in case of business transfer, business acquisition, corporate reorganization or changes as mergers, company splits, share exchanges or share transfers or capital structure changes; obtaining prior approval of the lender in case Lumentum Holdings Inc. changes its indirect ownership in Lumentum Japan, Inc; and obtaining prior approval from the lender in case Lumentum Japan, Inc. distributes dividends to its shareholders.

[0001628280-24-046443:notes:204]
As of September 28, 2024, the Company has $31.6 million in principal amount outstanding, of which the short-term portion of $6.3 million is recorded as current liabilities while the long-term portion of $25.3 million is recorded as long-term debt in the Company’s condensed consolidated balance sheets.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001628280-24-046443:notes:205]
[same as prior period, unchanged from 0001628280-24-020767:notes:209]

[0001628280-24-046443:notes:206]
[same as prior period, unchanged from 0001628280-24-020767:notes:210]

[0001628280-24-046443:notes:207]
[same as prior period, unchanged from 0001628280-24-020767:notes:211]

[0001628280-24-046443:notes:208]
|  | Foreign Currency Translation Adjustments, Net of Tax (1) |  | Defined Benefit Obligations, Net of Tax (2) |  | Unrealized Gain (Loss) on Available-for-Sale Securities, Net of Tax (3) |  |  |  | Total |
| Beginning balance as of June 29, 2024 | $ | 9.8 |  |  | $ | 0.7 |  |  | $ | (1.2) |  |  |  |  | $ | 9.3 |  |
| Other comprehensive gain (loss), net | — |  |  | — |  |  | 2.3 |  |  |  |  | 2.3 |  |
| Ending balance as of September 28, 2024 | $ | 9.8 |  |  | $ | 0.7 |  |  | $ | 1.1 |  |  |  |  | $ | 11.6 |  |
|  | Foreign Currency Translation Adjustments, Net of Tax (1) |  | Defined Benefit Obligations, Net of Tax (2) |  | Unrealized Gain (Loss) on Available-for-Sale Securities, Net of Tax (3) |  |  |  | Total |
| Beginning balance as of July 1, 2023 | $ | 10.4 |  |  | $ | (0.4) |  |  | $ | (5.9) |  |  |  |  | $ | 4.1 |  |
| Other comprehensive gain (loss), net | (0.2) |  |  | — |  |  | 1.3 |  |  |  |  | 1.1 |  |
| Ending balance as of September 30, 2023 | $ | 10.2 |  |  | $ | (0.4) |  |  | $ | (4.6) |  |  |  |  | $ | 5.2 |  |

[0001628280-24-046443:notes:209]
[same as prior period, unchanged from 0001628280-24-020767:notes:213]

[0001628280-24-046443:notes:210]
[same as prior period, unchanged from 0001628280-24-020767:notes:214]

[0001628280-24-046443:notes:211]
(3) For the three months ended September 28, 2024, our unrealized loss on available-for-sale securities is presented net of tax of  nil.

[0001628280-24-046443:notes:212]
For the three months ended September 30, 2023, our unrealized loss on available-for-sale securities is presented net of tax of  $0.4 million.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001628280-24-046443:notes:213]
[same as prior period, unchanged from 0001628280-24-020767:notes:217]

[0001628280-24-046443:notes:214]
[same as prior period, unchanged from 0001628280-24-020767:notes:218]

[0001628280-24-046443:notes:215]
[same as prior period, unchanged from 0001628280-24-020767:notes:219]

[0001628280-24-046443:notes:216]
|  | Three Months Ended |  |  |
|  | September 28, 2024 |  | September 30, 2023 |  |  |  |  |
| Balance as of beginning of period | $ | 11.1 |  |  | $ | 5.0 |  |  |  |  |  |
| Charges | 9.7 |  |  | 11.0 |  |  |  |  |  |
| Payments and other adjustments | (14.5) |  |  | (6.7) |  |  |  |  |  |
| Balance as of end of period | $ | 6.3 |  |  | $ | 9.3 |  |  |  |  |  |

[0001628280-24-046443:notes:217]
During the three months ended September 28, 2024, we recorded restructuring and related charges of $9.7 million, which includes $6.0 million of asset write-offs primarily due to integration efforts to consolidate our sites, $3.0 million of charges related to the discontinuation of our in-house development of coherent DSPs and RFICs and the remaining restructuring charges due to company-wide cost reduction initiatives.

[0001628280-24-046443:notes:218]
During the three months ended September 30, 2023, we recorded restructuring and related charges of $11.0 million in our

[0001628280-24-046443:notes:219]
condensed consolidated statements of operations, which were primarily due to company-wide cost reduction initiatives, as well as our integration efforts as a result of the merger with NeoPhotonics.

[0001628280-24-046443:notes:220]
[same as prior period, unchanged from 0001628280-24-020767:notes:223]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-24-046443:notes:221]
[same as prior period, unchanged from 0001628280-24-020767:notes:224]

[0001628280-24-046443:notes:222]
Our tax provision for interim periods has generally been determined using an estimate of our annual effective tax rate, adjusted for discrete items, if any, that arise during the period.  However, when a reliable estimate cannot be made, the actual tax or benefit applicable may be reported as a discrete item in the interim period. For the three months ended September 28, 2024, we concluded that the use of the cut-off tax rate method was more appropriate than the annual effective tax rate method, because the estimated annual effective tax rate is not reliable due to its sensitivity to minimal changes in forecasted annual pre-tax earnings.  As a result, we have computed our tax provision using the discrete method as though the three-month period was the annual period.

[0001628280-24-046443:notes:223]
We recorded a tax provision of $3.2 million for the three months ended September 28, 2024. Our tax provision for the three months ended September 28, 2024 is primarily related to the tax expense associated with interest on uncertain tax positions, partially offset by the tax benefit from currency re-measurements.

[0001628280-24-046443:notes:224]
We recorded a tax benefit of $1.4 million for the three months ended September 30, 2023. Our tax provision for the three months ended September 30, 2023 includes a discrete tax benefit of $1.8 million primarily related to the tax benefit from changes in prior year uncertain tax positions, partially offset by the tax expenses related to a shortfall in connection with stock-based compensation vested during the quarter and foreign return to provision differences.

[0001628280-24-046443:notes:225]
Our estimated effective tax rate for the three months ended September 28, 2024 differs from the 21% U.S. statutory rate primarily due to the income tax expense from foreign rate differential, non-deductible stock-based compensation, uncertain tax positions, and current year valuation allowance changes, partially offset by the income tax benefit from various income tax credits.

[0001628280-24-046443:notes:226]
We regularly assess our ability to realize our deferred tax assets on a quarterly basis and will establish a valuation allowance if it is more-likely-than-not that some portion of the deferred tax assets will not be realized. As of September 28, 2024, we maintain a full valuation allowance on U.S. federal and state and certain foreign deferred tax assets. We will continue to assess the need for a valuation allowance against our remaining deferred tax assets and may increase or decrease our valuation allowance materially in the future.

[0001628280-24-046443:notes:227]
As of September 28, 2024, we had $94.4 million of unrecognized tax benefits, which, if recognized, would affect the effective tax rate. We are subject to examination of income tax returns by various domestic and foreign tax authorities. The timing of resolution and closure of these tax examinations is highly unpredictable. Although it is possible that certain ongoing tax examinations may be concluded within the next 12 months, we cannot reasonably estimate the impact to tax expense and net income from tax examinations that could be resolved or closed within the next 12 months. Subject to audit timing and uncertainty, we expect the amount of unrecognized tax benefit that would become recognized due to expiration of the statute of limitations and affect the effective tax rate to decrease by $3.7 million over the next 12 months.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001628280-24-046443:notes:228]
[same as prior period, unchanged from 0001628280-24-020767:notes:231]

[0001628280-24-046443:notes:229]
[same as prior period, unchanged from 0001628280-24-020767:notes:232]

[0001628280-24-046443:notes:230]
[same as prior period, unchanged from 0001628280-24-020767:notes:233]

[0001628280-24-046443:notes:231]
[same as prior period, unchanged from 0001628280-24-020767:notes:234]

[0001628280-24-046443:notes:232]
As of September 28, 2024, we had 5.8 million shares subject to stock options, restricted stock units, restricted stock awards, and performance stock units issued and outstanding under the 2015 Plan. Restricted stock units, restricted stock awards, and performance stock units are performance-based, time-based or a combination of both and are expected to vest within four years. The fair value of these grants is based on the closing market price of our common stock on the date of grant. The exercise price for stock options is equal to the fair value of the underlying stock at the date of grant. We issue new shares of common stock upon exercise of stock options. Options generally have vesting period of three years. As of September 28, 2024, 2.1 million shares of common stock under the 2015 Plan were available for grant.

[0001628280-24-046443:notes:233]
[same as prior period, unchanged from 0001628280-24-020767:notes:236]

[0001628280-24-046443:notes:234]
[same as prior period, unchanged from 0001628280-24-020767:notes:237]

[0001628280-24-046443:notes:235]
[same as prior period, unchanged from 0001628280-24-020767:notes:238]

[0001628280-24-046443:notes:236]
[same as prior period, unchanged from 0001628280-24-020767:notes:239]

[0001628280-24-046443:notes:237]
[same as prior period, unchanged from 0001628280-24-020767:notes:240]

[0001628280-24-046443:notes:238]
[same as prior period, unchanged from 0001628280-24-020767:notes:241]

[0001628280-24-046443:notes:239]
[same as prior period, unchanged from 0001628280-24-020767:notes:242]

[0001628280-24-046443:notes:240]
During the three months ended September 28, 2024, our board of directors approved grants of 1.5 million RSUs, which primarily vest over three years.

[0001628280-24-046443:notes:241]
[same as prior period, unchanged from 0001628280-24-020767:notes:245]

[0001628280-24-046443:notes:242]
[same as prior period, unchanged from 0001628280-24-020767:notes:246]

[0001628280-24-046443:notes:243]
During the three months ended September 28, 2024, we granted 0.7 million PSUs with an aggregate grant date fair value of $39.8 million to executive and non-executive employees as part of our revised Annual Incentive Plan. These PSUs are subject to performance targets and service conditions, with a vesting period of one year. We also granted 0.3 million PSUs with an aggregate grant date fair value of $19.1 million to certain executive officers and senior management. These PSUs will vest subject to the achievement of revenue targets and certain non-financial performance measurements, as well as service conditions, over three years.

[0001628280-24-046443:notes:244]
[same as prior period, unchanged from 0001628280-24-020767:notes:248]

[0001628280-24-046443:notes:245]
Our 2015 Purchase Plan provides eligible employees with the opportunity to acquire an ownership interest in the Company through periodic payroll deductions and provides a 15% purchase price discount as well as a 6-month look-back period. The 2015 Purchase Plan is structured as a qualified employee stock purchase plan under Section 423 of the Internal Revenue Code of 1986, as amended. The 2015 Purchase Plan will terminate upon the date on which all shares available for issuance have been sold. Of the 3.0 million shares authorized under the 2015 Purchase Plan, 0.7 million shares remained available for issuance as of September 28, 2024.

[0001628280-24-046443:notes:246]
[same as prior period, unchanged from 0001628280-24-020767:notes:250]

[0001628280-24-046443:notes:247]
[same as prior period, unchanged from 0001628280-24-020767:notes:251]

[0001628280-24-046443:notes:248]
|  | Three Months Ended |  |  |
|  | September 28, 2024 |  | September 30, 2023 |  |  |  |  |
| Cost of sales | $ | 9.7 |  |  | $ | 6.0 |  |  |  |  |  |
| Research and development | 9.3 |  |  | 10.3 |  |  |  |  |  |
| Selling, general and administrative | 16.6 |  |  | 15.8 |  |  |  |  |  |
| Total stock-based compensation | $ | 35.6 |  |  | $ | 32.1 |  |  |  |  |  |

[0001628280-24-046443:notes:249]
During the three months ended September 28, 2024 and September 30, 2023, we recorded $7.3 million and $4.7 million of stock-based compensation related to PSUs, respectively. The amount of stock-based compensation expense recognized in any one period related to PSUs can vary based on the achievement or anticipated achievement of the performance conditions. If the performance conditions are not met or not expected to be met, no compensation cost would be recognized on the underlying PSUs, and any previously recognized compensation expense related to those PSUs would be reversed.

[0001628280-24-046443:notes:250]
[same as prior period, unchanged from 0001628280-24-020767:notes:255]

[0001628280-24-046443:notes:251]
|  | Three Months Ended |  |  |
|  | September 28, 2024 |  | September 30, 2023 |  |  |  |  |
| Income tax benefit associated with stock-based compensation | $ | 1.4 |  |  | $ | 1.9 |  |  |  |  |  |

[0001628280-24-046443:notes:252]
Approximately $12.7 million and $14.4 million of stock-based compensation was capitalized to inventory as of September 28, 2024 and June 29, 2024, respectively.

[0001628280-24-046443:notes:253]
As of September 28, 2024, $177.6 million of stock-based compensation cost related to RSU awards remains to be amortized, which is expected to be recognized over an estimated amortization period of 2.0 years.

[0001628280-24-046443:notes:254]
[same as prior period, unchanged from 0001628280-24-020767:notes:259]

[0001628280-24-046443:notes:255]
The following table summarizes our award activities for the three months ended September 28, 2024 (in millions):

[0001628280-24-046443:notes:256]
|  | Stock Options |  | Restricted Stock Units |  | Performance Stock Units |  |  |  |  |
|  | Number of Shares |  | Weighted-Average Exercise Price per Share |  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |  |  |  |  |
| Balance as of June 29, 2024 | 1.1 |  |  | $ | 34.6 |  |  | 2.7 |  |  | $ | 62.5 |  |  | 0.9 |  |  | $ | 65.5 |  |  |  |  |  |
| Granted | — |  |  | — |  |  | 1.5 |  |  | 56.3 |  |  | 1.0 |  |  | 56.4 |  |  |  |  |  |
| Vested/Exercised | (0.1) |  |  | 7.7 |  |  | (0.8) |  |  | 65.1 |  |  | (0.1) |  |  | 85.8 |  |  |  |  |  |
| Canceled | — |  |  | — |  |  | (0.1) |  |  | 63.2 |  |  | (0.3) |  |  | 61.7 |  |  |  |  |  |
| Balance as of September 28, 2024 | 1.0 |  |  | $ | 34.6 |  |  | 3.3 |  |  | $ | 58.9 |  |  | 1.5 |  |  | $ | 59.6 |  |  |  |  |  |

[0001628280-24-046443:notes:257]
[same as prior period, unchanged from 0001628280-24-020767:notes:263]

[0001628280-24-046443:notes:258]
|  | Awards Available for Grant |
| Balance as of June 29, 2024 | 4.3 |  |
| Authorized | — |  |
| Granted | (2.6) |  |
| Canceled | 0.4 |  |
| Balance as of September 28, 2024 | 2.1 |  |

[0001628280-24-046443:notes:259]
[same as prior period, unchanged from 0001628280-24-020767:notes:265]

[0001628280-24-046443:notes:260]
The 2015 Purchase Plan expense for the three months ended September 28, 2024 was $1.2 million. The 2015 Purchase Plan expense for the three months ended September 30, 2023 was $1.2 million. The expense related to the 2015 Purchase Plan is recorded on a straight-line basis over the relevant subscription period.

[0001628280-24-046443:notes:261]
During the three months ended September 28, 2024 and the three months ended September 30, 2023, there were no shares issued to employees through the 2015 Purchase Plan.

[0001628280-24-046443:notes:262]
[same as prior period, unchanged from 0001628280-24-020767:notes:268]

[0001628280-24-046443:notes:263]
[same as prior period, unchanged from 0001628280-24-020767:notes:269]

[0001628280-24-046443:notes:264]
We have a share buyback program that authorizes us to utilize up to an aggregate amount of $1.2 billion to purchase our own shares of common stock through May 2025. During the three months ended September 28, 2024 and September 30, 2023, we did not repurchase any shares of our common stock. Since the board of directors initially approved the share buyback program, we have repurchased 7.7 million shares in aggregate at an average price of $81.66 per share for a total purchase price of $630.4 million. We recorded the $630.4 million aggregate purchase price as a reduction of retained earnings within our condensed consolidated balance sheet and immediately retired all repurchased shares. As of September 28, 2024, we have $569.6 million remaining under the share buyback program.

[0001628280-24-046443:notes:265]
[same as prior period, unchanged from 0001628280-24-020767:notes:271]


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0001628280-24-046443:notes:266]
Note 14. Commitments and Contingencies

[0001628280-24-046443:notes:267]
Purchase Obligations

[0001628280-24-046443:notes:268]
Our purchase obligations of $589.2 million as of September 28, 2024 represent legally binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule and

[0001628280-24-046443:notes:269]
adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

[0001628280-24-046443:notes:270]
We depend on a limited number of contract manufacturers, subcontractors and suppliers for raw materials, packages and standard components. We generally purchase these single or limited source products through standard purchase orders or one-year supply agreements and have no significant long-term guaranteed supply agreements with these vendors. While we seek to maintain a sufficient safety stock of such products and maintain on-going communications with our suppliers to guard against interruptions or cessation of supply, our business and results of operations could be adversely affected by a stoppage or delay of supply, substitution of more expensive or less reliable products, receipt of defective parts or contaminated materials, increases in the price of such supplies, or our inability to obtain reduced pricing from our suppliers in response to competitive pressures.

[0001628280-24-046443:notes:271]
Product Warranties

[0001628280-24-046443:notes:272]
We provide reserves for the estimated costs of product warranties at the time revenue is recognized. We typically offer a twelve-month warranty for most of our products. However, in some instances depending upon the product, product components or application of our products by the end customer, our warranties can vary and generally range from six months to five years. We estimate the costs of our warranty obligations on an annualized basis based on our historical experience of known product failure rates, use of materials to repair or replace defective products, and service delivery costs incurred in correcting product failures. In addition, from time-to-time, specific warranty accruals may be made if unforeseen technical problems arise with specific products. We assess the adequacy of our recorded warranty liabilities and adjust the amounts as necessary.

[0001628280-24-046443:notes:273]
The following table presents the changes in our warranty reserve for the periods presented (in millions):

[0001628280-24-046443:notes:274]
|  | Three Months Ended |  |  |
|  | September 28, 2024 |  | September 30, 2023 |  |  |  |  |
| Balance as of beginning of period | $ | 13.2 |  |  | $ | 6.8 |  |  |  |  |  |
| Warranties assumed in Cloud Light acquisition | 0.8 |  |  | — |  |  |  |  |  |
| Provision for warranty | 2.4 |  |  | 0.2 |  |  |  |  |  |
| Utilization of reserve, net | (3.2) |  |  | (1.5) |  |  |  |  |  |
| Balance as of end of period | $ | 13.2 |  |  | $ | 5.5 |  |  |  |  |  |

[0001628280-24-046443:notes:275]
Environmental Liabilities

[0001628280-24-046443:notes:276]
Our research and development, manufacturing and distribution operations involve the use of hazardous substances and are regulated under international, federal, state and local laws governing health and safety and the environment. We apply strict standards for protection of the environment and occupational health and safety to sites inside and outside the United States, even if not subject to regulations imposed by foreign governments. We believe that our properties and operations at our facilities comply in all material respects with applicable environmental laws and occupational health and safety laws. However, the risk of environmental liabilities cannot be completely eliminated and there can be no assurance that the application of environmental and health and safety laws will not require us to incur significant expenditures. We are also regulated under a number of international, federal, state and local laws regarding recycling, product packaging and product content requirements. The environmental and product content/disposal and recycling laws are gradually becoming more stringent and may cause us to incur significant expenditures in the future.

[0001628280-24-046443:notes:277]
Legal Proceedings

[0001628280-24-046443:notes:278]
We are subject to a variety of claims and suits that arise from time-to-time in the ordinary course of our business. While management currently believes that resolving claims against us, individually or in the aggregate, will not have a material adverse impact on our financial position, results of operations or statements of cash flows, these matters are subject to inherent uncertainties and management’s view of these matters may change in the future. We accrue for loss contingencies when it is both probable that we will incur the loss and when we can reasonably estimate the amount of the loss or range of loss. During the year ended June 29, 2024, we recorded $7.8 million with respect to the pending settlement of certain non-ordinary course litigation matters which has been settled as of September 28, 2024.

[0001628280-24-046443:notes:279]
Oclaro Merger Litigation

[0001628280-24-046443:notes:280]
In connection with our acquisition of Oclaro in 2018, seven lawsuits were filed by purported stockholders of Oclaro challenging the proposed merger (the “Merger”). All but one was voluntarily dismissed after the Oclaro Merger closed. The remaining lawsuit, SaiSravan B. Karri v. Oclaro, Inc., et al., No. 3:18-cv-03435-JD (the “Karri Lawsuit”), was filed in the United States District Court for the Northern District of California and was styled as a class action.

[0001628280-24-046443:notes:281]
The Karri Lawsuit alleged, among other things, that Oclaro and its directors violated Section 14(a) of the Securities Exchange Act of 1934, as amended (the “Exchange Act”), and Rule 14a-9 promulgated thereunder by disseminating an incomplete and misleading Form S-4, including proxy statement/prospectus. The Karri Lawsuit further alleged that Oclaro’s directors violated Section 20(a) of the Exchange Act by failing to exercise proper control over the person(s) who violated Section 14(a) of the Exchange Act. The plaintiff in the Karri Lawsuit sought, among other things, damages to be awarded to the plaintiff and any class, if a class is certified, and litigation costs, including attorneys’ fees.

[0001628280-24-046443:notes:282]
The case proceeded through fact and expert discovery and the parties subsequently reached an agreement for a class-wide settlement of the Karri Lawsuit that provided for a payment of $15.3 million to the members of the class. On August 17, 2023, the court preliminarily approved the settlement. In March 2024, the court finally approved the settlement.

[0001628280-24-046443:notes:283]
We recorded the court approved settlement amount of $15.3 million as accrued expenses in our condensed consolidated balance sheet as of June 29, 2024, of which $7.5 million represents the amount to be reimbursed by insurance and was recorded as prepayments and other current assets. As of September 28, 2024, this litigation matter has been settled.

[0001628280-24-046443:notes:284]
Regulatory Matters

[0001628280-24-046443:notes:285]
In August 2024, the Company received inquiries from the Bureau of Industry and Security of the U.S. Department of Commerce (“BIS”) and Department of Justice (“DOJ”) following the Company’s voluntary disclosure to BIS in December 2023, and supplemented in April 2024. The Company continues to cooperate with both agencies on this matter.  The Company is unable to predict the likely outcome of these matters.

[0001628280-24-046443:notes:286]
Indemnifications

[0001628280-24-046443:notes:287]
In the normal course of business, we enter into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown, because claims may be made against us in the future, and we may record charges in the future as a result of these indemnification obligations. As of September 28, 2024, we did not have any material indemnification claims that were probable or reasonably possible.

[0001628280-24-046443:notes:288]
Audit Proceedings

[0001628280-24-046443:notes:289]
We are under audit by various domestic and foreign tax authorities with regards to income tax and indirect tax matters. In some, although not all cases, we have reserved for potential adjustments to our provision for income taxes and accrual of indirect taxes that may result from examinations by these tax authorities or final outcomes in judicial proceedings, and we believe that the final outcome of these examinations, agreements or judicial proceedings will not have a material effect on our results of operations. If events occur which indicate payment of these amounts is unnecessary, the reversal of the liabilities would result in the recognition of benefits in the period when we determine the liabilities are no longer necessary. If our estimates of the federal, state, and foreign income tax liabilities and indirect tax liabilities are less than the ultimate assessment, it could result in a further charge to expense.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001628280-24-046443:notes:290]
[same as prior period, unchanged from 0001628280-24-020767:notes:294]

[0001628280-24-046443:notes:291]
Our chief executive officer is our Chief Operating Decision Maker (“CODM”). The CODM allocates resources to the segments based on their business prospects, competitive factors, segment net revenue and segment profit. The CODM regularly reviews operating results to make decisions about resources to be allocated to the segments and to assess their performance.

[0001628280-24-046443:notes:292]
Segment profit includes operating expenses directly managed by operating segments, including research and development, and direct sales and marketing expenses. Segment profit does not include stock-based compensation, acquisition or integration related costs, amortization and impairment of acquisition-related intangible assets, restructuring and related charges, and certain other charges. Additionally, we do not allocate corporate marketing and strategic marketing expenses and general and administrative expenses, as these expenses are not directly attributable to our operating segments.

[0001628280-24-046443:notes:293]
[same as prior period, unchanged from 0001628280-24-020767:notes:298]

[0001628280-24-046443:notes:294]
[same as prior period, unchanged from 0001628280-24-020767:notes:299]

[0001628280-24-046443:notes:295]
Our Cloud & Networking products include comprehensive portfolio of optical and photonic chips, components, modules, and subsystems supplied to cloud data center operator, AI/ML infrastructure provider, and network equipment manufacturer customers who are building cloud data center and network infrastructures. Our products enable high-capacity optical links in cloud, AI/ML and DCI applications, and communications service provider networks, including products for access (local), metro (intracity), long-haul (city-to-city and worldwide) and submarine (undersea) network infrastructure. Our Cloud & Networking products also support network equipment manufacturers building enterprise network infrastructure, including SANs, LANs, and WANs. These products enable the transmission and transport of data, video, and audio over high-capacity fiber-optic cables. We maintain leading positions in these fast-growing cloud and networking markets through our extensive product portfolio, including high-speed optical components and transceivers, reconfigurable optical add/drop multiplexers (“ROADMs”), coherent dense wavelength division multiplexing (“DWDM”) pluggable transceivers, and tunable small form-factor pluggable transceivers. Demand for our Cloud & Networking products is driven by the continual growth in network capacity required for cloud computing and services, including for AI/ML, streaming video and video conferencing, wireless and mobile services, and IoT.

[0001628280-24-046443:notes:296]
[same as prior period, unchanged from 0001628280-24-020767:notes:301]

[0001628280-24-046443:notes:297]
Our Industrial Tech products include short pulse solid-state lasers, kilowatt-class fiber lasers, ultrafast lasers, diode lasers, and gas lasers,  which address applications in numerous end-markets. In the consumer end-market, our laser light sources are integrated into our customers’ 3D sensing cameras, which are used in mobile devices, payment kiosks, and other consumer electronics devices to enable applications including biometric identification, computational photography and virtual and augmented reality. In the automotive end-market, our lasers are used in our customers’ LiDAR and other optical sensor devices, which are increasingly being used in advanced driver assistance systems (“ADAS”) and in-cabin driver and occupant monitoring systems. In the industrial manufacturing end-market, our lasers are incorporated into our customers’ manufacturing machine tools used for the precision processing of materials in a range of industries including semiconductor device and microelectronics fabrication, electric vehicle and battery production, metal cutting and welding, and advanced manufacturing. Our products can also be used in the industrial end-market in imaging and sensing systems for process feedback and control, quality assurance, and waste reduction. Adoption of our products in the industrial end-market is driven by the needs of customers to advance semiconductor and microelectronics industry roadmaps, and by Industry 4.0/5.0 trends, including increasing manufacturing precision and flexibility and reducing waste and environmental impact. Demand for our products in the industrial end-market is driven by end-customer investments in manufacturing capacity. Our lasers also address certain semiconductor inspection and life-science applications.

[0001628280-24-046443:notes:298]
[same as prior period, unchanged from 0001628280-24-020767:notes:304]

[0001628280-24-046443:notes:299]
The two operating segments, Cloud & Networking and Industrial Tech, also represent our two reportable segments. Our CODM allocates resources and evaluates segment performance based on segment revenue and segment profit. The following table summarizes segment profit and a reconciliation to the consolidated income (loss) before income taxes for the periods presented (in millions):

[0001628280-24-046443:notes:300]
|  | Three Months Ended |  |  |
|  | September 28, 2024 |  | September 30, 2023 |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |
| Cloud & Networking | $ | 282.3 |  |  | 229.7 |  |  |  |  |  |
| Industrial Tech | 54.6 |  |  | 87.9 |  |  |  |  |  |
| Net revenue | $ | 336.9 |  |  | $ | 317.6 |  |  |  |  |  |
| Segment profit (loss): |  |  |  |  |  |  |  |
| Cloud & Networking | $ | 36.5 |  |  | 23.9 |  |  |  |  |  |
| Industrial Tech | 2.2 |  |  | 15.3 |  |  |  |  |  |
| Total segment profit | 38.7 |  |  | 39.2 |  |  |  |  |  |
| Unallocated corporate items: |  |  |  |  |  |  |  |
| Selling, general and administrative (1) | (28.7) |  |  | (28.6) |  |  |  |  |  |
| Stock-based compensation | (35.6) |  |  | (32.1) |  |  |  |  |  |
| Amortization of acquired intangibles | (41.7) |  |  | (29.0) |  |  |  |  |  |
| Acquisition related costs | — |  |  | (4.0) |  |  |  |  |  |
| Integration related costs | (3.4) |  |  | (11.3) |  |  |  |  |  |
| Restructuring and related charges | (9.7) |  |  | (11.0) |  |  |  |  |  |
| Intangible asset write-off | (1.9) |  |  | — |  |  |  |  |  |
| Other charges, net | (0.1) |  |  | (4.0) |  |  |  |  |  |
| Interest expense | (5.5) |  |  | (9.7) |  |  |  |  |  |
| Other income, net (2) | 8.7 |  |  | 21.2 |  |  |  |  |  |
| Consolidated loss before income taxes | $ | (79.2) |  |  | $ | (69.3) |  |  |  |  |  |

[0001628280-24-046443:notes:301]
[same as prior period, unchanged from 0001628280-24-020767:notes:307]

[0001628280-24-046443:notes:302]
(2) Other income, net for the three months ended September 28, 2024 includes interest and investment income of $9.4 million, offset by foreign exchange and other gains, net of $0.7 million.

[0001628280-24-046443:notes:303]
Other income, net for the three months ended September 30, 2023 includes $21.7 million of interest and investment income, offset by $0.5 million of net foreign exchange losses.

[0001628280-24-046443:notes:304]
[same as prior period, unchanged from 0001628280-24-020767:notes:315]

[0001628280-24-046443:notes:305]
[same as prior period, unchanged from 0001628280-24-020767:notes:316]

[0001628280-24-046443:notes:306]
[same as prior period, unchanged from 0001628280-24-020767:notes:317]

[0001628280-24-046443:notes:307]
|  | Three Months Ended |  |  |
|  | September 28, 2024 |  | September 30, 2023 |  |  |  |  |
|  | Amount |  | % of Total |  | Amount |  | % of Total |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States | $ | 65.4 |  |  | 19.4 | % |  | $ | 41.1 |  |  | 12.9 | % |  |  |  |  |  |  |  |  |
| Mexico | 33.9 |  |  | 10.0 |  |  | 23.7 |  |  | 7.5 |  |  |  |  |  |  |  |  |  |
| Other Americas | 2.9 |  |  | 0.9 |  |  | 1.2 |  |  | 0.4 |  |  |  |  |  |  |  |  |  |
| Total Americas | $ | 102.2 |  |  | 30.3 | % |  | $ | 66.0 |  |  | 20.8 | % |  |  |  |  |  |  |  |  |
| Asia-Pacific: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Hong Kong | $ | 88.7 |  |  | 26.4 | % |  | $ | 64.9 |  |  | 20.4 | % |  |  |  |  |  |  |  |  |
| South Korea | 8.8 |  |  | 2.6 |  |  | 25.0 |  |  | 7.9 |  |  |  |  |  |  |  |  |  |
| Japan | 16.9 |  |  | 5.0 |  |  | 25.4 |  |  | 8.0 |  |  |  |  |  |  |  |  |  |
| Thailand | 52.5 |  |  | 15.6 |  |  | 64.2 |  |  | 20.2 |  |  |  |  |  |  |  |  |  |
| Other Asia-Pacific | 37.2 |  |  | 11.0 |  |  | 39.5 |  |  | 12.4 |  |  |  |  |  |  |  |  |  |
| Total Asia-Pacific | $ | 204.1 |  |  | 60.6 | % |  | $ | 219.0 |  |  | 68.9 | % |  |  |  |  |  |  |  |  |
| EMEA | $ | 30.6 |  |  | 9.1 | % |  | $ | 32.6 |  |  | 10.3 | % |  |  |  |  |  |  |  |  |
| Total net revenue | $ | 336.9 |  |  | 100.0 | % |  | $ | 317.6 |  |  | 100.0 | % |  |  |  |  |  |  |  |  |

[0001628280-24-046443:notes:308]
During the three months ended September 28, 2024, two customers individually accounted for 15% and 12% of our total revenue, respectively. During the three months ended September 30, 2023, three customers individually accounted for 15%, 13% and 10% of our total net revenue, respectively. We had no other customers that represented 10% or greater of our total net revenue.

[0001628280-24-046443:notes:309]
As of September 28, 2024, two customers individually accounted for 11% and 11% of gross accounts receivable, respectively. As of June 29, 2024, one customer individually accounted for 13% of gross accounts receivable. We had no other customers that represented 10% or greater of our gross accounts receivable.

[0001628280-24-046443:notes:310]
[same as prior period, unchanged from 0001628280-24-020767:notes:323]

[0001628280-24-046443:notes:311]
|  | September 28, 2024 |  | June 29, 2024 |
| Property, plant and equipment, net |  |  |  |
| United States | $ | 126.5 |  |  | $ | 131.0 |  |
| Thailand | 147.2 |  |  | 141.0 |  |
| Japan | 129.8 |  |  | 75.7 |  |
| United Kingdom | 88.0 |  |  | 83.8 |  |
| China | 90.3 |  |  | 85.7 |  |
| Other countries | 56.6 |  |  | 55.3 |  |
| Total property, plant and equipment, net | $ | 638.4 |  |  | $ | 572.5 |  |

[0001628280-24-046443:notes:312]
We purchase a portion of our inventory from contract manufacturers that are located primarily in Thailand, Taiwan, and Malaysia. During the three months ended September 28, 2024, our net inventory purchases from a single contract manufacturer that represented 10% or greater of our total net inventory purchases were concentrated with one contract manufacturer, who accounted for 27% of the total net inventory purchases. During the three months ended September 30, 2023, our net inventory purchases from a single contract manufacturer that represented 10% or greater of our total net inventory purchases were concentrated with one contract manufacturer, who accounted for 45% of the total net inventory purchases.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001628280-24-046443:notes:313]
[same as prior period, unchanged from 0001628280-24-020767:notes:327]

[0001628280-24-046443:notes:314]
[same as prior period, unchanged from 0001628280-24-020767:notes:328]

[0001628280-24-046443:notes:315]
[same as prior period, unchanged from 0001628280-24-020767:notes:329]

[0001628280-24-046443:notes:316]
[same as prior period, unchanged from 0001628280-24-020767:notes:330]

[0001628280-24-046443:notes:317]
|  | Three Months Ended |  |  |
|  | September 28, 2024 |  | September 30, 2023 |  |  |  |  |
|  | Amount |  | % of Total |  | Amount |  | % of Total |  |  |  |  |  |  |  |  |
| Cloud & Networking | $ | 282.3 |  |  | 83.8 | % |  | 229.7 |  |  | 72.3 | % |  |  |  |  |  |  |  |  |
| Industrial Tech | 54.6 |  |  | 16.2 | % |  | 87.9 |  |  | 27.7 | % |  |  |  |  |  |  |  |  |
| Net revenue | $ | 336.9 |  |  | 100.0 | % |  | $ | 317.6 |  |  | 100.0 | % |  |  |  |  |  |  |  |  |

[0001628280-24-046443:notes:318]
[same as prior period, unchanged from 0001628280-24-020767:notes:332]

[0001628280-24-046443:notes:319]
[same as prior period, unchanged from 0001628280-24-020767:notes:333]

[0001628280-24-046443:notes:320]
| Contract balances |  | Balance sheet location |  | September 28, 2024 |  | June 29, 2024 |  | Change |  | Percentage Change |
| Accounts receivable, net |  | Accounts receivable, net |  | $ | 198.5 |  |  | $ | 194.7 |  |  | $ | 3.8 |  |  | 2.0 | % |
| Deferred revenue and customer deposits |  | Other current liabilities |  | $ | 0.6 |  |  | $ | 0.6 |  |  | $ | — |  |  | — | % |


## ecd:MtrlTermsOfTrdArrTextBlock

[0001628280-24-046443:notes:321]
On August 22, 2024, Julie Johnson, a member of our board of directors, adopted a Rule 10b5-1 trading arrangement providing for the sale from time to time of an aggregate of up to 2,058 shares of our common stock. The trading arrangement is intended to satisfy the affirmative defense in Rule 10b5-1(c). The duration of the trading arrangement is until August 22, 2025, or earlier if all transactions under the trading arrangement are completed.

[0001628280-24-046443:notes:322]
On August 26, 2024, Vince Retort, our President, Industrial Tech and Chief Business Officer, adopted a Rule 10b5-1 trading arrangement providing for the sale from time to time of an aggregate of up to 152,147 shares of our common stock. The actual number of shares sold under the trading arrangement will depend on achievement of performance targets applicable to the performance stock units (“PSUs”) subject to the trading arrangement and be net of shares withheld for taxes upon vesting and settlement of the PSUs subject to the trading arrangement. The trading arrangement is intended to satisfy the affirmative defense in Rule 10b5-1(c). The duration of the trading arrangement is until August 29, 2025, or earlier if all transactions under the trading arrangement are completed.

[0001628280-24-046443:notes:323]
On August 30, 2024, Wajid Ali, our Chief Financial Officer, adopted a Rule 10b5-1 trading arrangement providing for the sale from time to time of an aggregate of up to 67,118 shares of our common stock. The actual number of shares sold under the trading arrangement will depend on achievement of performance targets applicable to the PSUs subject to the trading arrangement and be net of shares withheld for taxes upon vesting and settlement of the PSUs subject to the trading arrangement. The trading arrangement is intended to satisfy the affirmative defense in Rule 10b5-1(c). The duration of the trading arrangement is until September 26, 2025, or earlier if all transactions under the trading arrangement are completed.

[0001628280-24-046443:notes:324]
On May 20, 2024, Penny Herscher, a member of our board of directors, adopted a Rule 10b5-1 trading arrangement providing for the sale from time to time of an aggregate up to 2,167 shares of our common stock. The trading arrangement is intended to satisfy the affirmative defense in Rule 10b5-1(c). The duration of the trading arrangement is until May 20, 2025, or earlier if all transactions  under the trading arrangement are completed.
