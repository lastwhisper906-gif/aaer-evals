# LITE 8-K — 0001628280-24-046302 filed 2024-11-07

## item codes, every 8-K on or before 2024-11-08

- 2024-11-07 0001628280-24-046302 — 2.02, 9.01
- 2024-08-21 0001628280-24-037938 — 2.02, 9.01 — amendment of 0001628280-24-037191
- 2024-08-14 0001628280-24-037191 — 2.02, 9.01
- 2024-05-06 0001628280-24-020640 — 2.02, 9.01
- 2024-02-27 0001628280-24-006936 — 5.02
- 2024-02-08 0001628280-24-003789 — 2.02, 9.01
- 2024-01-18 0001628280-24-001551 — 9.01 — amendment of 0001193125-23-272452
- 2023-11-21 0001628280-23-039654 — 5.02, 5.07
- 2023-11-08 0001628280-23-037563 — 2.02, 9.01
- 2023-11-07 0001193125-23-272452 — 2.01, 8.01, 9.01
- 2023-10-30 0001193125-23-265658 — 1.01, 2.02, 9.01
- 2023-08-17 0001628280-23-029741 — 2.02, 9.01
- 2023-06-16 0001193125-23-168966 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2023-05-09 0001628280-23-016629 — 2.02, 9.01
- 2023-04-06 0001628280-23-010935 — 2.02, 8.01, 9.01
- 2023-02-24 0001193125-23-048742 — 5.02, 9.01
- 2023-02-09 0001628280-23-002866 — 2.02, 9.01
- 2022-11-21 0001628280-22-030473 — 5.02, 5.07, 9.01
- 2022-11-08 0001628280-22-028758 — 2.02, 9.01
- 2022-08-16 0001628280-22-022980 — 2.02, 9.01
- 2022-08-03 0001193125-22-210674 — 2.01, 8.01, 9.01
- 2022-07-29 0001193125-22-206587 — 8.01, 9.01
- 2022-05-04 0001628280-22-012145 — 2.02, 9.01
- 2022-03-08 0001193125-22-069350 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2022-02-03 0001628280-22-001736 — 2.02, 9.01
- 2022-01-21 0001193125-22-014413 — 8.01, 9.01
- 2021-11-23 0001628280-21-024070 — 5.02, 5.07
- 2021-11-05 0001193125-21-321796 — 1.01, 9.01
- 2021-11-04 0001628280-21-021618 — 2.02, 9.01
- 2021-11-04 0001193125-21-319601 — 8.01, 9.01
- 2021-08-18 0001628280-21-017219 — 2.02, 9.01
- 2021-06-08 0001633978-21-000030 — 5.02, 9.01
- 2021-05-12 0001633978-21-000008 — 2.02, 9.01
- 2021-03-10 0001193125-21-075438 — 1.01, 8.01, 9.01
- 2021-02-02 0001633978-21-000002 — 2.02, 9.01
- 2021-01-19 0001104659-21-005024 — 1.01, 2.02, 8.01, 9.01
- 2020-11-24 0001193125-20-302557 — 5.02, 5.07
- 2020-11-02 0001633978-20-000017 — 2.02, 9.01
- 2020-09-18 0001633978-20-000012 — 5.02, 9.01
- 2020-08-11 0001633978-20-000010 — 2.02, 9.01
- 2020-05-05 0001628280-20-006358 — 2.02, 9.01
- 2020-02-04 0001633978-20-000002 — 2.02, 9.01
- 2019-12-12 0001193125-19-312875 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2019-12-04 0001633978-19-000075 — 8.01
- 2019-11-20 0001633978-19-000074 — 5.07
- 2019-10-31 0001633978-19-000070 — 2.02, 9.01
- 2019-08-08 0001633978-19-000068 — 2.02, 9.01
- 2019-05-08 0001633978-19-000031 — 1.01
- 2019-05-07 0001633978-19-000029 — 2.02, 9.01
- 2019-02-15 0001633978-19-000005 — 9.01 — amendment of 0001193125-18-346211
- 2019-02-08 0001193125-19-031591 — 5.02, 9.01
- 2019-02-05 0001633978-19-000001 — 2.02, 9.01
- 2018-12-10 0001193125-18-346211 — 1.01, 2.01, 2.03, 5.02, 8.01, 9.01
- 2018-12-06 0001633978-18-000150 — 8.01
- 2018-11-14 0001633978-18-000139 — 5.07
- 2018-11-13 0001633978-18-000136 — 3.02
- 2018-11-13 0001633978-18-000132 — 7.01, 9.01
- 2018-11-01 0001628280-18-013238 — 2.02, 9.01
- 2018-08-08 0001633978-18-000056 — 2.02, 9.01
- 2018-06-08 0001193125-18-188241 — 5.02, 9.01
- 2018-05-02 0001633978-18-000029 — 2.02, 9.01
- 2018-03-12 0001193125-18-078154 — 1.01, 2.01, 8.01, 9.01
- 2018-02-06 0001628280-18-001082 — 2.02, 9.01
- 2017-11-08 0001633978-17-000133 — 5.02, 9.01
- 2017-11-07 0001633978-17-000131 — 5.07
- 2017-11-01 0001633978-17-000117 — 2.02, 9.01
- 2017-08-09 0001633978-17-000058 — 2.02, 9.01
- 2017-05-04 0001633978-17-000035 — 2.02, 9.01
- 2017-03-08 0001193125-17-074740 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2017-03-02 0001193125-17-066769 — 8.01, 9.01
- 2017-02-07 0001633978-17-000005 — 2.02, 9.01
- 2017-01-03 0001628280-17-000018 — 4.01, 9.01
- 2016-11-09 0001628280-16-021143 — 5.02, 5.07, 9.01
- 2016-10-27 0001628280-16-020382 — 2.02, 9.01
- 2016-08-09 0001628280-16-018811 — 2.02, 9.01
- 2016-06-21 0001628280-16-017201 — 8.01
- 2016-05-04 0001628280-16-015501 — 2.02, 9.01
- 2016-02-16 0001628280-16-011261 — 5.02, 9.01
- 2016-02-04 0001628280-16-010758 — 5.02, 9.01
- 2016-02-04 0001628280-16-010755 — 2.02, 9.01
- 2015-11-17 0001193125-15-378953 — 7.01
- 2015-11-10 0001628280-15-008606 — 2.02, 9.01
- 2015-09-28 0001193125-15-329665 — 8.01, 9.01
- 2015-08-11 0001193125-15-286405 — 7.01, 9.01
- 2015-08-06 0001193125-15-281219 — 1.01, 5.02, 5.03, 5.05, 8.01, 9.01
- 2015-08-03 0001193125-15-274808 — 5.03, 9.01

## late-filing notifications on or before 2024-11-08

- 2015-11-10 0001628280-15-008612 — NT 10-Q, for the period ended 2015-09-26
- 2015-09-28 0001193125-15-329672 — NT 10-K, for the period ended 2015-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001628280-24-046302:8k_2_02:1]
EX-99.1
2
lite_ex991xq1fy25.htm
EX-99.1

[0001628280-24-046302:8k_2_02:2]
Document

[0001628280-24-046302:8k_2_02:3]
NEWS RELEASE

[0001628280-24-046302:8k_2_02:4]
LUMENTUM ANNOUNCES FISCAL FIRST QUARTER 2025 FINANCIAL RESULTS

[0001628280-24-046302:8k_2_02:5]
•Net revenue of $336.9 million

[0001628280-24-046302:8k_2_02:6]
•GAAP gross margin of 23.1%; Non-GAAP gross margin of 32.8%

[0001628280-24-046302:8k_2_02:7]
•GAAP operating loss of 24.5%; Non-GAAP operating margin of 3.0%

[0001628280-24-046302:8k_2_02:8]
•GAAP diluted net loss per share of $1.21; Non-GAAP diluted net income per share of $0.18

[0001628280-24-046302:8k_2_02:9]
San Jose, Calif., November 7, 2024 – Lumentum Holdings Inc. (“Lumentum” or the “Company”) today reported results for its fiscal first quarter ended September 28, 2024.

[0001628280-24-046302:8k_2_02:10]
“In the first quarter, we exceeded the high end of our guidance for both revenue and earnings per share,” said Alan Lowe, President and CEO. “We set a new record for datacom laser chip orders, including substantial 200G EML orders, reflecting strong demand from multiple customers, including an AI infrastructure customer. Based on expanding cloud demand and improving trends in the broader networking market, we expect double-digit sequential revenue growth in the second quarter.”

[0001628280-24-046302:8k_2_02:11]
Mr. Lowe added, “We advanced our strategy to expand and diversify our cloud and AI business. We secured an additional hyperscale transceiver customer with a new qualification and initial volume order. This is beyond the new award we highlighted last quarter. We expect to start shipping volume production against these new orders in the first half of calendar 2025, and they will ramp through the year, consistent with the revenue target we set out previously.”

[0001628280-24-046302:8k_2_02:12]
Fiscal First  Quarter Highlights:

[0001628280-24-046302:8k_2_02:13]
Net revenue for the fiscal first quarter of 2025 was $336.9 million, with GAAP net loss of $82.4 million, or $1.21 per diluted share. Net revenue for the fiscal fourth quarter of 2024 was $308.3 million, with GAAP net loss of $252.5 million, or $3.72 per diluted share. Net revenue for the fiscal first quarter of 2024 was $317.6 million, with GAAP net loss of $67.9 million, or $1.02 per diluted share.

[0001628280-24-046302:8k_2_02:14]
Non-GAAP net income for the fiscal first quarter of 2025 was $12.2 million, or $0.18 per diluted share. Non-GAAP net loss for fiscal fourth quarter of 2024 was $8.9 million, or $0.13 per diluted share. Non-GAAP net income for the first quarter of 2024 was $16.1 million, or $0.24 per diluted share(1).

[0001628280-24-046302:8k_2_02:15]
The Company held $916.1 million in total cash, cash equivalents, and short-term investments at the end of the fiscal first quarter of 2025, up $29.1 million from the end of the fiscal fourth quarter of 2024.

[0001628280-24-046302:8k_2_02:16]
Financial Overview – Fiscal First Quarter Ended September 28, 2024

[0001628280-24-046302:8k_2_02:17]
|  | GAAP Results ($ in millions) |
|  | Q1 |  | Q4 |  | Q1 |  | Change |
|  | FY 2025 |  | FY 2024 |  | FY 2024 |  | Q/Q |  | Y/Y |
| Net revenue | $ | 336.9 |  |  | $ | 308.3 |  |  | $317.6 |  | 9.3% |  | 6.1% |
| GAAP gross margin | 23.1 | % |  | 16.6 | % |  | 24.1% |  | 650 | bps |  | (100) | bps |
| GAAP operating loss | (24.5) | % |  | (43.3) | % |  | (25.4)% |  | 1,880 | bps |  | 90 | bps |
|  | Non-GAAP Results ($ in millions) |
|  | Q1 |  | Q4 |  | Q1 |  | Change |
|  | FY 2025 |  | FY 2024 (1) |  | FY 2024 (1) |  | Q/Q |  | Y/Y |
| Net revenue | $ | 336.9 |  |  | $ | 308.3 |  |  | $317.6 |  | 9.3% |  | 6.1% |
| Non-GAAP gross margin | 32.8 | % |  | 27.8 | % |  | 32.8% |  | 500 | bps |  | — | bps |
| Non-GAAP operating margin | 3.0 | % |  | (5.1) | % |  | 0.6% |  | 810 | bps |  | 240 | bps |

[0001628280-24-046302:8k_2_02:18]
|  | Net Revenue by Segment ($ in millions) |  |  |  |  |
|  | Q1 |  | % of |  | Q4 |  | Q1 |  | Change |  |  |  |  |
|  | FY 2025 |  | Net Revenue |  | FY 2024 |  | FY 2024 |  | Q/Q |  | Y/Y |  |  |  |  |
| Cloud & Networking | $ | 282.3 |  |  | 83.8 | % |  | $ | 254.7 |  |  | $ | 229.7 |  |  | 10.8% |  | 22.9% |  |  |  |  |
| Industrial Tech | 54.6 |  |  | 16.2 | % |  | 53.6 |  |  | 87.9 |  |  | 1.9% |  | (37.9)% |  |  |  |  |
| Total | $ | 336.9 |  |  | 100.0 | % |  | $ | 308.3 |  |  | $ | 317.6 |  |  | 9.3% |  | 6.1% |  |  |  |  |

[0001628280-24-046302:8k_2_02:19]
(1) During the first fiscal quarter of 2025, the Company refined its methodology to report non-GAAP measures.  The change does not impact the Company’s financial position, cash flows, or GAAP consolidated results of operations. Prior period non-GAAP financial measures presented in this press release have been recast to conform to the current presentation.

[0001628280-24-046302:8k_2_02:20]
The tables above provide comparisons of quarterly results to prior periods, including sequential quarterly and year-over-year changes. A reconciliation between GAAP and non-GAAP measures is contained in this release under the section titled “Use of Non-GAAP Financial Measures.”

[0001628280-24-046302:8k_2_02:21]
Business Outlook

[0001628280-24-046302:8k_2_02:22]
Lumentum expects the following for the fiscal second quarter 2025:

[0001628280-24-046302:8k_2_02:23]
•Net revenue in the range of $380 million to $400 million

[0001628280-24-046302:8k_2_02:24]
•Non-GAAP operating margin of 5.5% to 7.5%

[0001628280-24-046302:8k_2_02:25]
•Non-GAAP diluted earnings per share of $0.30 to $0.40

[0001628280-24-046302:8k_2_02:26]
We have not provided reconciliations from GAAP to non-GAAP measures or the equivalent GAAP measure for non-GAAP measures in our outlook, as they cannot be provided without unreasonable effort. A large portion of non-GAAP adjustments, such as restructuring charges, stock-based compensation, non-GAAP income tax reconciling adjustments, acquisition related costs, and other costs and contingencies unrelated to current and future operations are by their nature highly volatile and we have low visibility as to the range that may be incurred in the future.

[0001628280-24-046302:8k_2_02:27]
Related Announcement and Conference Call

[0001628280-24-046302:8k_2_02:28]
Lumentum will host a conference call today, November 7, 2024, at 2:00 pm PT / 5:00 pm ET to discuss its fiscal first quarter results. A live webcast of the call will be available in the Investors section of the Lumentum website at http://investor.lumentum.com. To listen to the live conference call, dial (833) 470-1428 or (404) 975-4839 and reference the conference ID 013162. Supporting materials outlining the Company’s latest financial results will be posted on http://investor.lumentum.com under the “Events and Presentations” section concurrently with this earnings press release. Lumentum has used, and intends to continue to use, its Investor Relations website as means of disclosing material nonpublic information and for complying with its disclosure obligations under Regulation FD. This press release is being furnished as an exhibit to a Current Report on Form 8-K filed with the Securities and Exchange Commission and will be available at http://www.sec.gov/.

[0001628280-24-046302:8k_2_02:29]
About Lumentum

[0001628280-24-046302:8k_2_02:30]
Lumentum (NASDAQ: LITE) is a market-leading designer and manufacturer of innovative optical and photonic products enabling optical networking and laser applications worldwide. Lumentum optical components and subsystems are part of virtually every type of telecom, enterprise, and data center network. Lumentum lasers enable advanced manufacturing techniques and diverse applications including next-generation imaging and sensing capabilities. Lumentum is headquartered in San Jose, California with R&D, manufacturing, and sales offices worldwide. For more information, visit www.lumentum.com and follow Lumentum on LinkedIn, X (formerly known as Twitter), Facebook, Instagram and YouTube.

[0001628280-24-046302:8k_2_02:31]
Forward-Looking Statements

[0001628280-24-046302:8k_2_02:32]
Contact Information

[0001628280-24-046302:8k_2_02:33]
Investors:    Kathy Ta, (408) 750-3853; investor.relations@lumentum.com

[0001628280-24-046302:8k_2_02:34]
Media:        Noël Bilodeau, 408-439-2140; noel.bilodeau@lumentum.com

[0001628280-24-046302:8k_2_02:35]
Category:    Financial

[0001628280-24-046302:8k_2_02:36]
The following financial tables are presented in accordance with GAAP, unless otherwise specified.

[0001628280-24-046302:8k_2_02:37]
LUMENTUM HOLDINGS INC.

[0001628280-24-046302:8k_2_02:38]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001628280-24-046302:8k_2_02:39]
(in millions, except per share data)

[0001628280-24-046302:8k_2_02:40]
(unaudited)

[0001628280-24-046302:8k_2_02:41]
|  | Three Months Ended |  |  |
|  | September 28, 2024 |  | September 30, 2023 |  |  |  |  |
| Net revenue | $ | 336.9 |  |  | $ | 317.6 |  |  |  |  |  |
| Cost of sales | 236.5 |  |  | 222.9 |  |  |  |  |  |
| Amortization of acquired developed intangibles | 22.5 |  |  | 18.0 |  |  |  |  |  |
| Gross profit | 77.9 |  |  | 76.7 |  |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 74.3 |  |  | 73.5 |  |  |  |  |  |
| Selling, general and administrative | 76.3 |  |  | 73.0 |  |  |  |  |  |
| Restructuring and related charges | 9.7 |  |  | 11.0 |  |  |  |  |  |
| Total operating expenses | 160.3 |  |  | 157.5 |  |  |  |  |  |
| Loss from operations | (82.4) |  |  | (80.8) |  |  |  |  |  |
| Interest expense | (5.5) |  |  | (9.7) |  |  |  |  |  |
| Other income, net | 8.7 |  |  | 21.2 |  |  |  |  |  |
| Loss before income taxes | (79.2) |  |  | (69.3) |  |  |  |  |  |
| Income tax provision (benefit) | 3.2 |  |  | (1.4) |  |  |  |  |  |
| Net loss | $ | (82.4) |  |  | $ | (67.9) |  |  |  |  |  |
| Net loss per share: |  |  |  |  |  |  |  |
| Basic | $ | (1.21) |  |  | $ | (1.02) |  |  |  |  |  |
| Diluted | $ | (1.21) |  |  | $ | (1.02) |  |  |  |  |  |
| Shares used to compute net loss per share: |  |  |  |  |  |  |  |
| Basic | 68.3 |  |  | 66.7 |  |  |  |  |  |
| Diluted | 68.3 |  |  | 66.7 |  |  |  |  |  |

[0001628280-24-046302:8k_2_02:42]
LUMENTUM HOLDINGS INC.

[0001628280-24-046302:8k_2_02:43]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001628280-24-046302:8k_2_02:44]
(in millions, except per share data)

[0001628280-24-046302:8k_2_02:45]
(unaudited)

[0001628280-24-046302:8k_2_02:46]
|  | September 28, 2024 |  | June 29, 2024 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 489.2 |  |  | $ | 436.7 |  |
| Short-term investments | 426.9 |  |  | 450.3 |  |
| Accounts receivable, net | 198.5 |  |  | 194.7 |  |
| Inventories | 403.3 |  |  | 398.4 |  |
| Prepayments and other current assets | 118.3 |  |  | 110.0 |  |
| Total current assets | 1,636.2 |  |  | 1,590.1 |  |
| Property, plant and equipment, net | 638.4 |  |  | 572.5 |  |
| Operating lease right-of-use assets, net | 35.7 |  |  | 72.8 |  |
| Goodwill | 1,060.9 |  |  | 1,055.8 |  |
| Other intangible assets, net | 573.9 |  |  | 617.5 |  |
| Deferred tax asset | 12.5 |  |  | 10.7 |  |
| Other non-current assets | 12.0 |  |  | 12.5 |  |
| Total assets | $ | 3,969.6 |  |  | $ | 3,931.9 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 163.1 |  |  | $ | 126.3 |  |
| Accrued payroll and related expenses | 42.0 |  |  | 36.1 |  |
| Accrued expenses | 39.7 |  |  | 52.4 |  |
| Current portion of long-term debt | 10.8 |  |  | — |  |
| Operating lease liabilities, current | 11.9 |  |  | 13.4 |  |
| Other current liabilities | 37.6 |  |  | 41.1 |  |
| Total current liabilities | 305.1 |  |  | 269.3 |  |
| Long-term debt | 2,569.2 |  |  | 2,503.2 |  |
| Operating lease liabilities, non-current | 29.8 |  |  | 43.0 |  |
| Deferred tax liability | 53.4 |  |  | 55.7 |  |
| Other non-current liabilities | 116.2 |  |  | 103.4 |  |
| Total liabilities | 3,073.7 |  |  | 2,974.6 |  |
| Stockholders’ equity: |  |  |  |
| Common stock, $0.001 par value, 990 authorized shares, 68.6 and 67.9 shares issued and outstanding as of September 28, 2024 and June 29, 2024, respectively | 0.1 |  |  | 0.1 |  |
| Additional paid-in capital | 1,853.7 |  |  | 1,835.0 |  |
| Accumulated deficit | (969.5) |  |  | (887.1) |  |
| Accumulated other comprehensive income | 11.6 |  |  | 9.3 |  |
| Total stockholders’ equity | 895.9 |  |  | 957.3 |  |
| Total liabilities and stockholders’ equity | $ | 3,969.6 |  |  | $ | 3,931.9 |  |

[0001628280-24-046302:8k_2_02:47]
Use of Non-GAAP Financial Measures

[0001628280-24-046302:8k_2_02:48]
In this press release, Lumentum provides investors with certain non-GAAP financial measures: gross profit, gross margin, research and development expense, selling, general and administrative expense, operating margin, income from operations, interest and other income (expense), net, income before income taxes, provision for income taxes, net income (loss), and net income (loss) per share on a non-GAAP basis, as well as the non-GAAP measures of EBITDA and Adjusted EBITDA. Lumentum believes this non-GAAP financial information provides additional insight into the Company’s on-going business operations and results, and has therefore chosen to provide this information to investors for a more consistent basis of comparison and to help them evaluate the results of the Company’s on-going operations and enable more meaningful period to period comparisons. In addition, the Company believes that providing certain of these measures allows investors to better understand the Company’s operating performance and importantly, to evaluate the methodology and information used by management to monitor, manage, evaluate and measure the Company’s business and results of operations. However, these measures may be different from non-GAAP measures used by other companies, limiting their usefulness for comparison purposes. The non-GAAP financial measures used in this press release should not be considered in isolation from measures of financial performance prepared in accordance with GAAP. Investors are cautioned that there are material limitations associated with the use of non-GAAP financial measures as an analytical tool. In particular, many of the adjustments to our GAAP financial measures reflect the exclusion of items that are recurring and will be reflected in our financial results for the foreseeable future. Further, these non-GAAP financial measures may not be comparable to similarly titled measurements reported by other companies.

[0001628280-24-046302:8k_2_02:49]
Our non-GAAP measures used in this press release exclude (i) stock-based compensation, (ii) acquisition related stock-based compensation, (iii) acquisition related costs, (iv) amortization of acquired intangibles, (v) restructuring and related charges, (vi) foreign exchange (gains) losses, net, (vii) non-cash interest expense on convertible notes, (viii) intangible assets write-off, (ix) integration related costs, (x) non-GAAP income tax reconciling adjustments, and (xi) other charges or income related to non-recurring activities.

[0001628280-24-046302:8k_2_02:50]
We utilize a long-term projected non-GAAP tax rate to compute our non-GAAP income tax provision. The long-term projected non-GAAP tax rate is based on a multi-year projection of our estimated annual GAAP income tax forecast, adjusted to account for the tax effect of non-GAAP pretax adjustments as well as the effects of significant non-recurring and period specific tax items. Our non-GAAP tax provision for the fiscal first quarter of 2025 is 16.5%. The difference between our GAAP income tax provision and our non-GAAP income tax provision is presented as non-GAAP income tax reconciling adjustments.

[0001628280-24-046302:8k_2_02:51]
A quantitative reconciliation between GAAP and non-GAAP financial data with respect to historical periods is included in the supplemental financial table attached to this press release.

[0001628280-24-046302:8k_2_02:52]
LUMENTUM HOLDINGS INC.

[0001628280-24-046302:8k_2_02:53]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001628280-24-046302:8k_2_02:54]
(in millions, except per share data)

[0001628280-24-046302:8k_2_02:55]
(unaudited)

[0001628280-24-046302:8k_2_02:56]
|  | Three Months Ended |  |  |  |
|  | September 28, 2024 |  | June 29, 2024 (1) |  | September 30, 2023 (1) |  |  |  |  |  |
| Gross profit on GAAP basis | $ | 77.9 |  |  | $ | 51.3 |  |  | $ | 76.7 |  |  |  |  |  |  |
| Stock-based compensation | 9.7 |  |  | 8.2 |  |  | 6.0 |  |  |  |  |  |  |
| Amortization of acquired intangibles | 22.5 |  |  | 22.1 |  |  | 18.0 |  |  |  |  |  |  |
| Integration related costs | 1.2 |  |  | 1.9 |  |  | 3.3 |  |  |  |  |  |  |
| Other charges (income), net | (0.9) |  |  | 2.1 |  |  | 0.3 |  |  |  |  |  |  |
| Gross profit on non-GAAP basis | $ | 110.4 |  |  | $ | 85.6 |  |  | $ | 104.3 |  |  |  |  |  |  |
| Gross margin on non-GAAP basis | 32.8 | % |  | 27.8 | % |  | 32.8 | % |  |  |  |  |  |
| Research and development on GAAP basis | $ | 74.3 |  |  | $ | 73.2 |  |  | $ | 73.5 |  |  |  |  |  |  |
| Stock-based compensation | (9.3) |  |  | (8.0) |  |  | (10.3) |  |  |  |  |  |  |
| Amortization of acquired intangibles | (0.4) |  |  | (0.4) |  |  | (0.3) |  |  |  |  |  |  |
| Acquisition related costs | — |  |  | — |  |  | (0.3) |  |  |  |  |  |  |
| Integration related costs (reversal) | — |  |  | — |  |  | (0.4) |  |  |  |  |  |  |
| Intangible asset write-off | (1.9) |  |  | — |  |  | — |  |  |  |  |  |  |
| Other income (charges), net | — |  |  | 0.1 |  |  | (0.7) |  |  |  |  |  |  |
| Research and development on non-GAAP basis | $ | 62.7 |  |  | $ | 64.9 |  |  | $ | 61.5 |  |  |  |  |  |  |
| Selling, general and administrative on GAAP basis | $ | 76.3 |  |  | $ | 74.9 |  |  | $ | 73.0 |  |  |  |  |  |  |
| Stock-based compensation | (16.6) |  |  | (14.3) |  |  | (15.8) |  |  |  |  |  |  |
| Amortization of acquired intangibles | (18.8) |  |  | (19.4) |  |  | (10.7) |  |  |  |  |  |  |
| Acquisition related costs | — |  |  | 0.2 |  |  | (3.7) |  |  |  |  |  |  |
| Integration related costs | (2.2) |  |  | (2.2) |  |  | (2.3) |  |  |  |  |  |  |
| Other (charges) income, net | (1.0) |  |  | (2.7) |  |  | 0.3 |  |  |  |  |  |  |
| Selling, general and administrative on non-GAAP basis | $ | 37.7 |  |  | $ | 36.5 |  |  | $ | 40.8 |  |  |  |  |  |  |
| Loss from operations on GAAP basis | $ | (82.4) |  |  | $ | (133.4) |  |  | $ | (80.8) |  |  |  |  |  |  |
| Stock-based compensation | 35.6 |  |  | 30.5 |  |  | 32.1 |  |  |  |  |  |  |
| Amortization of acquired intangibles | 41.7 |  |  | 41.9 |  |  | 29.0 |  |  |  |  |  |  |
| Acquisition related costs | — |  |  | (0.2) |  |  | 4.0 |  |  |  |  |  |  |
| Integration related costs | 3.4 |  |  | 4.1 |  |  | 6.0 |  |  |  |  |  |  |
| Restructuring and related charges | 9.7 |  |  | 36.6 |  |  | 11.0 |  |  |  |  |  |  |
| Intangible asset write-off | 1.9 |  |  | — |  |  | — |  |  |  |  |  |  |
| Other charges, net | 0.1 |  |  | 4.7 |  |  | 0.7 |  |  |  |  |  |  |
| Income from operations on non-GAAP basis | $ | 10.0 |  |  | $ | (15.8) |  |  | $ | 2.0 |  |  |  |  |  |  |
| Operating margin on non-GAAP basis | 3.0 | % |  | (5.1) | % |  | 0.6 | % |  |  |  |  |  |
| Interest and other income, net on GAAP basis | $ | 3.2 |  |  | $ | 5.9 |  |  | $ | 11.5 |  |  |  |  |  |  |
| Foreign exchange (gains) losses, net | 0.7 |  |  | (1.2) |  |  | 0.4 |  |  |  |  |  |  |
| Non-cash interest expense on convertible notes and other income and expenses, net | 0.7 |  |  | 0.7 |  |  | 4.9 |  |  |  |  |  |  |
| Interest and other income, net on non-GAAP basis | $ | 4.6 |  |  | $ | 5.4 |  |  | $ | 16.8 |  |  |  |  |  |  |
| Loss before income taxes on GAAP basis | $ | (79.2) |  |  | $ | (127.5) |  |  | $ | (69.3) |  |  |  |  |  |  |

[0001628280-24-046302:8k_2_02:57]
| Stock-based compensation | 35.6 |  |  | 30.5 |  |  | 32.1 |  |  |  |  |  |  |
| Acquisition related costs | — |  |  | (0.2) |  |  | 4.0 |  |  |  |  |  |  |
| Integration related costs | 3.4 |  |  | 4.1 |  |  | 6.0 |  |  |  |  |  |  |
| Amortization of acquired intangibles | 41.7 |  |  | 41.9 |  |  | 29.0 |  |  |  |  |  |  |
| Restructuring and related charges | 9.7 |  |  | 36.6 |  |  | 11.0 |  |  |  |  |  |  |
| Intangible asset write-off | 1.9 |  |  | — |  |  | — |  |  |  |  |  |  |
| Foreign exchange (gains) losses, net | 0.7 |  |  | (1.2) |  |  | 0.4 |  |  |  |  |  |  |
| Non-cash interest expense on convertible notes and other income and expenses, net | 0.7 |  |  | 0.7 |  |  | 4.9 |  |  |  |  |  |  |
| Other charges, net | 0.1 |  |  | 4.7 |  |  | 0.7 |  |  |  |  |  |  |
| Income (Loss) before income taxes on non-GAAP basis | $ | 14.6 |  |  | $ | (10.4) |  |  | $ | 18.8 |  |  |  |  |  |  |
| Income tax provision (benefit) on GAAP basis | $ | 3.2 |  |  | $ | 125.0 |  |  | $ | (1.4) |  |  |  |  |  |  |
| Non-GAAP income tax reconciling adjustments | (0.8) |  |  | (126.5) |  |  | 4.1 |  |  |  |  |  |  |
| Income tax provision (benefit) on non-GAAP basis | $ | 2.4 |  |  | $ | (1.5) |  |  | $ | 2.7 |  |  |  |  |  |  |
| Net loss on GAAP basis | $ | (82.4) |  |  | $ | (252.5) |  |  | $ | (67.9) |  |  |  |  |  |  |
| Stock-based compensation | 35.6 |  |  | 30.5 |  |  | 32.1 |  |  |  |  |  |  |
| Acquisition related costs | — |  |  | (0.2) |  |  | 4.0 |  |  |  |  |  |  |
| Integration related costs | 3.4 |  |  | 4.1 |  |  | 6.0 |  |  |  |  |  |  |
| Amortization of acquired intangibles | 41.7 |  |  | 41.9 |  |  | 29.0 |  |  |  |  |  |  |
| Restructuring and related charges | 9.7 |  |  | 36.6 |  |  | 11.0 |  |  |  |  |  |  |
| Intangible asset write-off | 1.9 |  |  | — |  |  | — |  |  |  |  |  |  |
| Foreign exchange (gains) losses, net | 0.7 |  |  | (1.2) |  |  | 0.4 |  |  |  |  |  |  |
| Non-cash interest expense on convertible notes and other income and expenses, net | 0.7 |  |  | 0.7 |  |  | 4.9 |  |  |  |  |  |  |
| Non-GAAP income tax reconciling adjustments | 0.8 |  |  | 126.5 |  |  | (4.1) |  |  |  |  |  |  |
| Other charges, net | 0.1 |  |  | 4.7 |  |  | 0.7 |  |  |  |  |  |  |
| Net income (loss) on non-GAAP basis | $ | 12.2 |  |  | $ | (8.9) |  |  | $ | 16.1 |  |  |  |  |  |  |
| Net income (loss) per share on non-GAAP basis | $ | 0.18 |  |  | $ | (0.13) |  |  | $ | 0.24 |  |  |  |  |  |  |
| Shares used in per share calculation - diluted on GAAP basis | 68.3 |  |  | 67.8 |  |  | 66.7 |  |  |  |  |  |  |
| Non-GAAP adjustment (2) | 0.8 |  |  | — |  |  | 0.3 |  |  |  |  |  |  |
| Shares used in per share calculation - diluted on non-GAAP basis | 69.1 |  |  | 67.8 |  |  | 67.0 |  |  |  |  |  |  |

[0001628280-24-046302:8k_2_02:58]
(1) During the first fiscal quarter of 2025, the Company refined its methodology to report non-GAAP measures.  The change does not impact the Company’s financial position, cash flows, or GAAP consolidated results of operations. Prior period non-GAAP financial measures and the associated GAAP to non-GAAP reconciliations presented in this press release have been recast to conform to the current presentation.

[0001628280-24-046302:8k_2_02:59]
(2) Shares used for net income per share on non-GAAP basis represent the diluted share count that would have been used for GAAP purposes if GAAP results were in a profit position. Therefore, the adjustment represents the net incremental dilutive shares from employee equity programs in accordance with the treasury stock method. In September 2024, we modified our outstanding convertible debt instruments by irrevocably electing to settle the face value in cash. Therefore, notwithstanding the fact that we had net income on a non-GAAP basis, there is no dilution in our non-GAAP diluted share count from our convertible debt instruments under the if-converted method, as the conversion rate exceeded the average market value of our stock.

[0001628280-24-046302:8k_2_02:60]
LUMENTUM HOLDINGS INC.

[0001628280-24-046302:8k_2_02:61]
RECONCILIATION OF GAAP NET INCOME TO ADJUSTED EBITDA

[0001628280-24-046302:8k_2_02:62]
(in millions, except per share data)

[0001628280-24-046302:8k_2_02:63]
(unaudited)

[0001628280-24-046302:8k_2_02:64]
|  | Three Months Ended |  |  |  |  |
|  | September 28, 2024 |  |  |  | June 29, 2024 (1) |  | September 30, 2023 (1) |  |  |  |  |  |  |  |  |
| GAAP net loss | $ | (82.4) |  |  |  |  | $ | (252.5) |  |  | $ | (67.9) |  |  |  |  |  |  |  |  |  |
| Interest and other expense, net | (3.2) |  |  |  |  | (5.9) |  |  | (11.5) |  |  |  |  |  |  |  |  |  |
| Income tax provision (benefit) | 3.2 |  |  |  |  | 125.0 |  |  | (1.4) |  |  |  |  |  |  |  |  |  |
| Depreciation | 27.0 |  |  |  |  | 28.2 |  |  | 28.2 |  |  |  |  |  |  |  |  |  |
| Amortization of acquired intangibles | 41.7 |  |  |  |  | 41.9 |  |  | 29.0 |  |  |  |  |  |  |  |  |  |
| EBITDA | (13.7) |  |  |  |  | (63.3) |  |  | (23.6) |  |  |  |  |  |  |  |  |  |
| Restructuring and related charges | 9.7 |  |  |  |  | 36.6 |  |  | 11.0 |  |  |  |  |  |  |  |  |  |
| Stock-based compensation | 35.6 |  |  |  |  | 30.5 |  |  | 32.1 |  |  |  |  |  |  |  |  |  |
| Acquisition related costs | — |  |  |  |  | (0.2) |  |  | 4.0 |  |  |  |  |  |  |  |  |  |
| Integration related costs | 3.4 |  |  |  |  | 4.1 |  |  | 6.0 |  |  |  |  |  |  |  |  |  |
| Intangible asset write-off | 1.9 |  |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Other charges (gains), net | 0.1 |  |  |  |  | 3.2 |  |  | (3.5) |  |  |  |  |  |  |  |  |  |
| Adjusted EBITDA | $ | 37.0 |  |  |  |  | $ | 10.9 |  |  | $ | 26.0 |  |  |  |  |  |  |  |  |  |

[0001628280-24-046302:8k_2_02:65]
(1) During the first fiscal quarter of 2025, the Company refined its methodology to report non-GAAP measures.  The change does not impact the Company’s financial position, cash flows, or GAAP consolidated results of operations. Prior period non-GAAP financial measures and the associated GAAP to non-GAAP reconciliations presented in this press release have been recast to conform to the current presentation.
