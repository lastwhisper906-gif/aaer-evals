# LITE MD&A — 0001628280-23-002880


## mdna

[0001628280-23-002880:mdna:1]
[same as prior period, unchanged from 0001628280-22-028783:mdna:1]

[0001628280-23-002880:mdna:2]
[same as prior period, unchanged from 0001628280-22-028783:mdna:2]

[0001628280-23-002880:mdna:3]
[same as prior period, unchanged from 0001628280-22-028783:mdna:3]

[0001628280-23-002880:mdna:4]
[same as prior period, unchanged from 0001628280-22-028783:mdna:4]

[0001628280-23-002880:mdna:5]
[same as prior period, unchanged from 0001628280-22-028783:mdna:5]

[0001628280-23-002880:mdna:6]
[same as prior period, unchanged from 0001628280-22-028783:mdna:6]

[0001628280-23-002880:mdna:7]
[same as prior period, unchanged from 0001628280-22-028783:mdna:7]

[0001628280-23-002880:mdna:8]
[same as prior period, unchanged from 0001628280-22-028783:mdna:8]

[0001628280-23-002880:mdna:9]
41

[0001628280-23-002880:mdna:10]
[same as prior period, unchanged from 0001628280-22-028783:mdna:10]

[0001628280-23-002880:mdna:11]
NeoPhotonics Merger

[0001628280-23-002880:mdna:12]
On August 3, 2022 (the “Closing date”), we completed our merger with NeoPhotonics Corporation (“NeoPhotonics”). The addition of NeoPhotonics expands our opportunities in some of the fastest growing markets for optical components used in cloud and telecom network infrastructure. We expect the integrated company to be better positioned to serve the needs of a global customer base who are increasingly utilizing photonics to accelerate the shift to digital and virtual approaches to work and life, the proliferation of IoT, 5G, and next-generation mobile networks, and the transition to advanced cloud computing architectures.

[0001628280-23-002880:mdna:13]
Under the terms of the Merger Agreement, NeoPhotonics stockholders received $16.00 per share for each of the NeoPhotonics common stock they own at the Closing date. As a result, we paid $867.3 million of cash consideration to shareholders of NeoPhotonics on the Closing date.

[0001628280-23-002880:mdna:14]
[same as prior period, unchanged from 0001628280-22-028783:mdna:14]

[0001628280-23-002880:mdna:15]
[same as prior period, unchanged from 0001628280-22-028783:mdna:15]

[0001628280-23-002880:mdna:16]
The total transaction consideration of $934.4 million was funded by the cash balances of the combined company. We also recorded $22.1 million of merger-related costs, representing professional and other direct acquisition costs. Of the $22.1 million of merger-related costs, $8.3 million was incurred in fiscal year 2022, and $1.2 million and $13.8 million was incurred during the three and six months ended December 31, 2022, respectively, which was recorded as selling, general and administrative expense in the consolidated statement of operations.

[0001628280-23-002880:mdna:17]
[same as prior period, unchanged from 0001628280-22-028783:mdna:17]

[0001628280-23-002880:mdna:18]
[same as prior period, unchanged from 0001628280-22-028783:mdna:18]

[0001628280-23-002880:mdna:19]
On August 15, 2022, we completed a transaction to acquire IPG Photonics’ telecom transmission product lines (“IPG product lines”) that develop and market products for use in telecommunications and datacenter infrastructure, including Digital Signal Processors (DSPs), ASICs and optical transceivers. This acquisition will enable us to expand our business in the OpComms segment. The total purchase price is $55.9 million, which was paid in cash. Refer to “Note 4. Business Combinations” in the notes to condensed consolidated financial statements for additional information regarding the acquisition of these product lines.

[0001628280-23-002880:mdna:20]
[same as prior period, unchanged from 0001628280-22-028783:mdna:20]

[0001628280-23-002880:mdna:21]
[same as prior period, unchanged from 0001628280-22-028783:mdna:21]

[0001628280-23-002880:mdna:22]
Since February 2020, the COVID-19 pandemic has caused public health officials to recommend, and governments to enact, precautions to mitigate the spread of the virus, including travel restrictions and bans, extensive social distancing guidelines, closure or restrictions on business and quarantine or other types of “shelter-in-place” orders in many regions of the world. While the impact of the COVID-19 pandemic is lessening, and these related responses continue to cause a global slowdown of economic activity (including a decrease in demand for a broad variety of goods and services), disruptions in global supply chains, labor shortages, and significant volatility and potential disruption of financial markets.

[0001628280-23-002880:mdna:23]
[same as prior period, unchanged from 0001628280-22-028783:mdna:24]

[0001628280-23-002880:mdna:24]
[same as prior period, unchanged from 0001628280-22-028783:mdna:25]

[0001628280-23-002880:mdna:25]
Our primary strategic focus is technology and product leadership combined with close customer relationships in long-term healthy and growing markets. We believe there are long-term opportunities, as the world’s experience with COVID-19 could drive an increasingly digital and virtual world, touching all aspects of life and work, that increasingly emphasizes the importance of communications systems, cloud services, augmented and virtual reality, and enhanced security. Additionally, ever advancing electronic devices are needed to consume, produce, and communicate digital and virtual content. All these trends could drive the need for higher volumes of higher performing optical devices that we could supply. As such, we expect to continue to invest strongly in new products, technology and customer programs.

[0001628280-23-002880:mdna:26]
[same as prior period, unchanged from 0001628280-22-028783:mdna:27]

[0001628280-23-002880:mdna:27]
43

[0001628280-23-002880:mdna:28]
[same as prior period, unchanged from 0001628280-22-028783:mdna:28]

[0001628280-23-002880:mdna:29]
Our business and our customers’ businesses have been negatively impacted by worldwide logistics and supply chain issues, including constraints on available cargo capabilities and limited availability of once broadly available supplies of both raw materials and finished components. COVID-19 has also created dynamics in the semiconductor component supply chains that have led to shortages of the types of components we and our customers require in our products. These shortages have impacted our ability to meet demand and generate revenue from certain products in fiscal 2022 and, they continue to impact our ability to meet demand today. If our ability to procure needed semiconductor components does not improve, our ability to supply our products to our customers will be impacted and our revenue and profit margin may be reduced. In addition, if our customers are unable to procure needed semiconductor components, this could reduce their demand for our products and reduce our revenue. The impact of semiconductor component shortages may continue in the near term as supplier and customer buffer inventories and safety stocks are exhausted. Due to the global supply chain constraints, we have had to incur incremental supply and procurement costs in order to increase our ability to fulfill demands from our customers. As of December 31, 2022, our inventory balance includes $18.0 million of incremental supply and procurement costs. These costs may decrease our gross margin in the near term. Although the supply shortage we experienced in fiscal 2022 was partially relieved, we expect component supply to be a challenge in the remaining fiscal 2023.

[0001628280-23-002880:mdna:30]
[same as prior period, unchanged from 0001628280-22-028783:mdna:30]

[0001628280-23-002880:mdna:31]
[same as prior period, unchanged from 0001628280-22-028783:mdna:31]

[0001628280-23-002880:mdna:32]
[same as prior period, unchanged from 0001628280-22-028783:mdna:32]

[0001628280-23-002880:mdna:33]
[same as prior period, unchanged from 0001628280-22-028783:mdna:33]

[0001628280-23-002880:mdna:34]
[same as prior period, unchanged from 0001628280-22-028783:mdna:34]

[0001628280-23-002880:mdna:35]
[same as prior period, unchanged from 0001628280-22-028783:mdna:35]

[0001628280-23-002880:mdna:36]
[same as prior period, unchanged from 0001628280-22-028783:mdna:36]

[0001628280-23-002880:mdna:37]
[same as prior period, unchanged from 0001628280-22-028783:mdna:37]

[0001628280-23-002880:mdna:38]
Management’s Discussion and Analysis of Financial Condition and Results of Operations contained in Part II, Item 7 of our Annual Report on Form 10-K for our fiscal year ended July 2, 2022 provides a complete discussion of our critical accounting policies and estimates. There have been no changes to these policies during the three and six months ended December 31, 2022.

[0001628280-23-002880:mdna:39]
Recently Issued Accounting Pronouncements

[0001628280-23-002880:mdna:40]
Refer to “Note 2. Recently Issued Accounting Pronouncements” in the notes to condensed consolidated financial statements.

[0001628280-23-002880:mdna:41]
[same as prior period, unchanged from 0001628280-22-028783:mdna:41]

[0001628280-23-002880:mdna:42]
[same as prior period, unchanged from 0001628280-22-028783:mdna:42]

[0001628280-23-002880:mdna:43]
|  | Three Months Ended |  | Six Months Ended |
|  | December 31, 2022 |  | January 1, 2022 |  | December 31, 2022 |  | January 1, 2022 |
| Segment net revenue: |  |  |  |  |  |  |  |
| OpComms | 88.7 | % |  | 89.0 | % |  | 89.1 | % |  | 89.8 | % |
| Lasers | 11.3 |  |  | 11.0 |  |  | 10.9 |  |  | 10.2 |  |
| Net revenue | 100.0 |  |  | 100.0 |  |  | 100.0 |  |  | 100.0 |  |
| Cost of sales | 62.3 |  |  | 50.0 |  |  | 59.0 |  |  | 47.3 |  |
| Amortization of acquired developed intangibles | 4.9 |  |  | 3.6 |  |  | 4.7 |  |  | 3.5 |  |
| Gross profit | 32.8 |  |  | 46.5 |  |  | 36.3 |  |  | 49.1 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 15.0 |  |  | 11.9 |  |  | 14.7 |  |  | 12.0 |  |
| Selling, general and administrative | 19.4 |  |  | 15.4 |  |  | 20.2 |  |  | 14.8 |  |
| Restructuring and related charges | 2.7 |  |  | — |  |  | 2.3 |  |  | (0.1) |  |
| Total operating expenses | 37.2 |  |  | 27.4 |  |  | 37.1 |  |  | 26.7 |  |
| Income (loss) from operations | (4.3) |  |  | 19.1 |  |  | (0.8) |  |  | 22.5 |  |
| Interest expense | (1.8) |  |  | (3.8) |  |  | (1.7) |  |  | (3.8) |  |
| Other income, net | 0.7 |  |  | 0.2 |  |  | 1.7 |  |  | 0.2 |  |
| Income (loss) before income taxes | (5.4) |  |  | 15.5 |  |  | (0.8) |  |  | 18.8 |  |
| Provision for income taxes | 0.9 |  |  | 2.8 |  |  | 2.3 |  |  | 3.4 |  |
| Net income (loss) | (6.3) | % |  | 12.7 | % |  | (3.2) | % |  | 15.4 | % |

[0001628280-23-002880:mdna:44]
45

[0001628280-23-002880:mdna:45]
Financial Data for the three and six months ended December 31, 2022

[0001628280-23-002880:mdna:46]
[same as prior period, unchanged from 0001628280-22-028783:mdna:46]

[0001628280-23-002880:mdna:47]
|  | Three Months Ended |  |  |  |  |  | Six Months Ended |  |  |  |  |
|  | December 31, 2022 |  | January 1, 2022 |  | Change |  | Percentage Change |  | December 31, 2022 |  | January 1, 2022 |  | Change |  | Percentage Change |
| Segment net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| OpComms | $ | 448.8 |  |  | $ | 397.4 |  |  | $ | 51.4 |  |  | 12.9 | % |  | $ | 902.2 |  |  | $ | 803.4 |  |  | $ | 98.8 |  |  | 12.3 | % |
| Lasers | 57.2 |  |  | 49.3 |  |  | 7.9 |  |  | 16.0 | % |  | 110.6 |  |  | 91.7 |  |  | 18.9 |  |  | 20.6 | % |
| Net revenue | $ | 506.0 |  |  | $ | 446.7 |  |  | $ | 59.3 |  |  | 13.3 | % |  | $ | 1,012.8 |  |  | $ | 895.1 |  |  | $ | 117.7 |  |  | 13.1 | % |
| Gross profit | $ | 166.2 |  |  | $ | 207.5 |  |  | $ | (41.3) |  |  | (19.9) | % |  | $ | 367.4 |  |  | $ | 439.7 |  |  | $ | (72.3) |  |  | (16.4) | % |
| Gross margin | 32.8 | % |  | 46.5 | % |  |  |  |  |  | 36.3 | % |  | 49.1 | % |  |  |  |  |
| Research and development | $ | 75.8 |  |  | $ | 53.2 |  |  | $ | 22.6 |  |  | 42.5 | % |  | $ | 148.5 |  |  | $ | 107.3 |  |  | $ | 41.2 |  |  | 38.4 | % |
| Percentage of net revenue | 15.0 | % |  | 11.9 | % |  |  |  |  |  | 14.7 | % |  | 12.0 | % |  |  |  |  |
| Selling, general and administrative | $ | 98.4 |  |  | $ | 69.0 |  |  | $ | 29.4 |  |  | 42.6 | % |  | $ | 204.1 |  |  | $ | 132.3 |  |  | $ | 71.8 |  |  | 54.3 | % |
| Percentage of net revenue | 19.4 | % |  | 15.4 | % |  |  |  |  |  | 20.2 | % |  | 14.8 | % |  |  |  |  |
| Restructuring and related charges | $ | 13.9 |  |  | $ | 0.1 |  |  | $ | 13.8 |  |  | N/A |  | $ | 23.2 |  |  | $ | (1.0) |  |  | $ | 24.2 |  |  | N/A |
| Percentage of net revenue | 2.7 | % |  | — | % |  |  |  |  |  | 2.3 | % |  | (0.1) | % |  |  |  |  |

[0001628280-23-002880:mdna:48]
[same as prior period, unchanged from 0001628280-22-028783:mdna:48]

[0001628280-23-002880:mdna:49]
Net revenue increased by $59.3 million, or 13.3%, during the three months ended December 31, 2022 compared to the three months ended January 1, 2022, due to a $51.4 million increase in OpComms revenue and a $7.9 million increase in Lasers revenue.

[0001628280-23-002880:mdna:50]
OpComms net revenue increased by $51.4 million, or 12.9%, during the three months ended December 31, 2022 compared to the three months ended January 1, 2022. Within OpComms, Telecom and Datacom increased by $117.1 million, primarily due to $104.6 million of revenue generated by NeoPhotonics. Additionally, the supply shortage we experienced in fiscal 2022 was partially relieved, allowing us to meet more customer demand during the second quarter of fiscal year 2023. Industrial and Consumer net revenue decreased by $65.7 million primarily due to higher market competition and reflects share normalization in the market.

[0001628280-23-002880:mdna:51]
Lasers net revenue increased by $7.9 million, or 16.0%, during the three months ended December 31, 2022 compared to the three months ended January 1, 2022, primarily due to a return in customer demand for our kilowatt class fiber lasers following a recovery in industrial production.

[0001628280-23-002880:mdna:52]
Net revenue increased by $117.7 million, or 13.1%, during the six months ended December 31, 2022 compared to the six months ended January 1, 2022, due to a $98.8 million increase in OpComms revenue and a $18.9 million increase in Lasers revenue.

[0001628280-23-002880:mdna:53]
OpComms net revenue increased by $98.8 million, or 12.3%, during the six months ended December 31, 2022 compared to the six months ended January 1, 2022. Within OpComms, Telecom and Datacom increased by $261.2 million, primarily due to $177.4 million of revenue attributable to the NeoPhotonics acquisition. Additionally, the supply shortage in fiscal 2022 was partially relieved, allowing us to meet more customer demand during the first half of fiscal year 2023. Industrial and Consumer net revenue decreased by $162.4 million primarily due to higher market competition and reflects share normalization in the market.

[0001628280-23-002880:mdna:54]
Lasers net revenue increased by $18.9 million, or 20.6%, during the six months ended December 31, 2022 compared to the six months ended January 1, 2022, primarily due to a return in customer demand for our kilowatt class fiber lasers following a recovery in industrial production.

[0001628280-23-002880:mdna:55]
During the three and six months ended December 31, 2022, our net revenue from a single customer, which represented 10% or greater of the total net revenue, was concentrated with two customers, who collectively accounted for 31% and 33% of our total net revenue, respectively.

[0001628280-23-002880:mdna:56]
During the three and six months ended January 1, 2022, our net revenue from a single customer, which represented 10% or greater of total net revenue was concentrated with two customers, who accounted for 41% and 46% of our total net revenue, respectively.

[0001628280-23-002880:mdna:57]
[same as prior period, unchanged from 0001628280-22-028783:mdna:54]

[0001628280-23-002880:mdna:58]
[same as prior period, unchanged from 0001628280-22-028783:mdna:55]

[0001628280-23-002880:mdna:59]
|  | Three Months Ended |  | Six Months Ended |
|  | December 31, 2022 |  | January 1, 2022 |  | December 31, 2022 |  | January 1, 2022 |
|  | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States | $ | 65.5 |  |  | 12.9 | % |  | $ | 51.0 |  |  | 11.4 | % |  | $ | 127.7 |  |  | 12.6 | % |  | $ | 79.1 |  |  | 8.8 | % |
| Mexico | 59.5 |  |  | 11.8 |  |  | 38.3 |  |  | 8.6 |  |  | 117.0 |  |  | 11.6 |  |  | 71.3 |  |  | 8.0 |  |
| Other Americas | 3.8 |  |  | 0.8 |  |  | 2.7 |  |  | 0.6 |  |  | 6.1 |  |  | 0.6 |  |  | 4.7 |  |  | 0.5 |  |
| Total Americas | $ | 128.8 |  |  | 25.5 | % |  | $ | 92.0 |  |  | 20.6 | % |  | $ | 250.8 |  |  | 24.8 | % |  | $ | 155.1 |  |  | 17.3 | % |
| Asia-Pacific: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Hong Kong | $ | 65.9 |  |  | 13.0 | % |  | $ | 115.0 |  |  | 25.8 | % |  | $ | 143.5 |  |  | 14.2 | % |  | $ | 257.3 |  |  | 28.8 | % |
| South Korea | 52.0 |  |  | 10.3 |  |  | 77.9 |  |  | 17.4 |  |  | 119.7 |  |  | 11.8 |  |  | 183.0 |  |  | 20.4 |  |
| Thailand | 77.9 |  |  | 15.4 |  |  | 26.2 |  |  | 5.9 |  |  | 135.4 |  |  | 13.4 |  |  | 43.3 |  |  | 4.8 |  |
| Japan | 50.8 |  |  | 10.0 |  |  | 46.7 |  |  | 10.5 |  |  | 95.6 |  |  | 9.4 |  |  | 92.8 |  |  | 10.4 |  |
| Other Asia-Pacific | 84.7 |  |  | 16.7 |  |  | 59.7 |  |  | 13.4 |  |  | 173.6 |  |  | 17.1 |  |  | 108.6 |  |  | 12.1 |  |
| Total Asia-Pacific | $ | 331.3 |  |  | 65.4 | % |  | $ | 325.5 |  |  | 73.0 | % |  | $ | 667.8 |  |  | 65.9 | % |  | $ | 685.0 |  |  | 76.4 | % |
| EMEA | $ | 45.9 |  |  | 9.1 | % |  | $ | 29.2 |  |  | 6.5 | % |  | $ | 94.2 |  |  | 9.3 | % |  | $ | 55.0 |  |  | 6.1 | % |
| Total net revenue | $ | 506.0 |  |  |  |  | $ | 446.7 |  |  |  |  | $ | 1,012.8 |  |  |  |  | $ | 895.1 |  |  |  |

[0001628280-23-002880:mdna:60]
For the three and six months ended December 31, 2022, net revenue from customers outside the United States, based on customer shipping location, represented 87.1% and 87.4% of net revenue, respectively.  For the three and six months ended January 1, 2022, net revenue from customers outside the United States, based on customer shipping location, represented 88.6% and 91.2% of net revenue, respectively.

[0001628280-23-002880:mdna:61]
[same as prior period, unchanged from 0001628280-22-028783:mdna:58]

[0001628280-23-002880:mdna:62]
[same as prior period, unchanged from 0001628280-22-028783:mdna:59]

[0001628280-23-002880:mdna:63]
[same as prior period, unchanged from 0001628280-22-028783:mdna:60]

[0001628280-23-002880:mdna:64]
|  | Three Months Ended |  | Six Months Ended |
|  | Gross Profit |  | Gross Margin |  | Gross Profit |  | Gross Margin |
|  | December 31, 2022 |  | January 1, 2022 |  | December 31, 2022 |  | January 1, 2022 |  | December 31, 2022 |  | January 1, 2022 |  | December 31, 2022 |  | January 1, 2022 |
| OpComms | $ | 197.0 |  |  | $ | 201.8 |  |  | 43.9 | % |  | 50.8 | % |  | $ | 413.0 |  |  | $ | 427.7 |  |  | 45.8 | % |  | 53.2 | % |
| Lasers | 30.0 |  |  | 26.2 |  |  | 52.4 | % |  | 53.1 | % |  | 58.1 |  |  | 47.0 |  |  | 52.5 | % |  | 51.3 | % |
| Segment total | $ | 227.0 |  |  | $ | 228.0 |  |  | 44.9 | % |  | 51.0 | % |  | $ | 471.1 |  |  | $ | 474.7 |  |  | 46.5 | % |  | 53.0 | % |
| Unallocated corporate items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation | (6.7) |  |  | (5.2) |  |  |  |  |  |  | (12.2) |  |  | (9.8) |  |  |  |  |  |
| Amortization of acquired intangibles | (24.8) |  |  | (15.9) |  |  |  |  |  |  | (47.7) |  |  | (31.7) |  |  |  |  |  |
| Amortization of acquired inventory fair value adjustments | (9.6) |  |  | — |  |  |  |  |  |  | (14.2) |  |  | — |  |  |  |  |  |
| Integration related costs | (2.8) |  |  | — |  |  |  |  |  |  | (2.8) |  |  | — |  |  |  |  |  |
| Inventory and fixed asset write down due to product line exits | — |  |  | (0.1) |  |  |  |  |  |  | — |  |  | (0.1) |  |  |  |  |  |
| Other (charges) gains, net (1) | (16.9) |  |  | 0.7 |  |  |  |  |  |  | (26.8) |  |  | 6.6 |  |  |  |  |  |
| Total | $ | 166.2 |  |  | $ | 207.5 |  |  | 32.8 | % |  | 46.5 | % |  | $ | 367.4 |  |  | $ | 439.7 |  |  | 36.3 | % |  | 49.1 | % |

[0001628280-23-002880:mdna:65]
(1) Other (charges) gains of unallocated corporate items for  the three and six months ended December 31, 2022 primarily relate to $11.7 million and $19.0 million of charges to acquire components from various brokers to satisfy customer demand.

[0001628280-23-002880:mdna:66]
Other (charges) gains of unallocated corporate items for the six months ended January 1, 2022 relate to $5.9 million of gain as a result of selling equipment that was no longer needed after we transferred certain product lines to new production facilities in fiscal 2021.

[0001628280-23-002880:mdna:67]
The unallocated corporate items for the periods presented include the effects of amortization of acquired developed technologies and other intangibles, amortization of acquired inventory fair value adjustments, stock-based compensation and certain other charges. We do not allocate these items to the gross margin for each segment because management does not include such information in measuring the performance of the operating segments.

[0001628280-23-002880:mdna:68]
[same as prior period, unchanged from 0001628280-22-028783:mdna:65]

[0001628280-23-002880:mdna:69]
Gross margin for the three months ended December 31, 2022 decreased to 32.8% from 46.5% for the three months ended January 1, 2022. The decrease was primarily driven by lower gross margin from our OpComms segment, as discussed further below. The lower gross margin was also a result of $11.7 million of charges to acquire components from various brokers to satisfy customer demand, $9.6 million of amortization of acquired inventory, and an aggregate $8.9 million higher amortization of intangible assets due to  the NeoPhotonics merger and the acquisition of IPG product lines.

[0001628280-23-002880:mdna:70]
Gross margin for the six months ended December 31, 2022 decreased to 36.3% from 49.1% for the six months ended January 1, 2022. The decrease was primarily driven by lower gross margin from our OpComms segment. The lower gross margin was also a result of  $19.0 million of charges to acquire components from various brokers to satisfy customer demand, an aggregate $16.0 million higher amortization of intangible assets acquired in the NeoPhotonics merger and the acquisition of IPG product lines, and $14.2 million of amortization of acquired inventory.

[0001628280-23-002880:mdna:71]
The market in which we sell products are consolidating, undergoing product, architectural and business model transitions, have high customer concentrations, are highly competitive, are price sensitive and/or are affected by customer seasonal and have variant buying patterns. We expect these factors will result in variability of our gross margin.

[0001628280-23-002880:mdna:72]
Due to global supply chain constraints, we have had to incur incremental supply and procurement costs in order to increase our ability to fulfill demands from our customers. As of December 31, 2022, our inventory balance includes $18.0 million of incremental supply and procurement costs.

[0001628280-23-002880:mdna:73]
[same as prior period, unchanged from 0001628280-22-028783:mdna:69]

[0001628280-23-002880:mdna:74]
[same as prior period, unchanged from 0001628280-22-028783:mdna:70]

[0001628280-23-002880:mdna:75]
OpComms gross margin for the three months ended December 31, 2022 decreased to 43.9% from 50.8% for the three months ended January 1, 2022. The decrease was primarily due to a less profitable mix of products, including lower sales of higher margin imaging and sensing products, as well as higher sales of telecom products due to the merger with NeoPhotonics, which have lower margins than our average OpComms margins.

[0001628280-23-002880:mdna:76]
OpComms gross margin for the six months ended December 31, 2022 decreased to 45.8% from 53.2% for the six months ended January 1, 2022. The decrease was primarily due to a less profitable mix of products, including lower sales of higher margin imaging and sensing products, as well as higher sales of telecom products due to the merger with NeoPhotonics, which have lower margins than our average OpComms margins.

[0001628280-23-002880:mdna:77]
[same as prior period, unchanged from 0001628280-22-028783:mdna:72]

[0001628280-23-002880:mdna:78]
Lasers gross margin for the three months ended December 31, 2022 decreased to 52.4% from 53.1% for the three months ended January 1, 2022. The decrease was primarily due to lower revenue from high margin solid state lasers.

[0001628280-23-002880:mdna:79]
Lasers gross margin for the six months ended December 31, 2022 increased to 52.5% from 51.3% for the six months ended January 1, 2022. The increase was primarily due to the higher manufacturing levels and improved factory utilization as a result of return in customer demand for our kilowatt class fiber products following the recent recovery in industrial production.

[0001628280-23-002880:mdna:80]
[same as prior period, unchanged from 0001628280-22-028783:mdna:74]

[0001628280-23-002880:mdna:81]
R&D expense increased by $22.6 million, or 42.5%, for the three months ended December 31, 2022 compared to the three months ended January 1, 2022. The increase in R&D expense for the three months ended December 31, 2022 was primarily driven by an increase in payroll, stock-based compensation and other compensation related expenses due to additional headcount from the merger with NeoPhotonics and the acquisition of IPG product lines.

[0001628280-23-002880:mdna:82]
R&D expense increased by $41.2 million, or 38.4%, for the six months ended December 31, 2022 compared to the six months ended January 1, 2022. The increase in R&D expense for the six months ended December 31, 2022 was primarily driven by an increase in payroll, stock-based compensation and other compensation related expenses due to additional headcount from the merger with NeoPhotonics and the acquisition of IPG product lines.

[0001628280-23-002880:mdna:83]
[same as prior period, unchanged from 0001628280-22-028783:mdna:76]

[0001628280-23-002880:mdna:84]
[same as prior period, unchanged from 0001628280-22-028783:mdna:77]

[0001628280-23-002880:mdna:85]
SG&A expense increased by $29.4 million, or 42.6%, during the three months ended December 31, 2022 compared to the three months ended January 1, 2022. The increase in SG&A expense for the three months ended December 31, 2022 was primarily driven by an increase in payroll and employee compensation related expenses due to additional headcount from the merger with NeoPhotonics, $7.8 million expense with respect to the settlement of certain non-ordinary course litigation matters and $6.5 million of amortization of intangibles acquired as part of the NeoPhotonics merger and the acquisition of IPG product lines. For a description of our material pending legal proceedings, refer to “Note 14. Commitments and Contingencies” of the notes to condensed consolidated financial statements included in Part I, Item 1 of this Form 10-Q.

[0001628280-23-002880:mdna:86]
SG&A expense increased by $71.8 million, or 54.3%, during the six months ended December 31, 2022 compared to the six months ended January 1, 2022. The increase in SG&A expense for the six months ended December 31, 2022 was primarily driven by an increase in payroll and employee compensation related expenses due to additional headcount from the merger with NeoPhotonics and higher stock-based compensation. In connection with the NeoPhotonics merger, certain equity awards for NeoPhotonics employees were accelerated. We recognized $11.9 million of stock-based compensation associated with the acceleration during the first quarter of fiscal year 2023. In addition, we recognized $16.2 million merger and acquisition related costs, primarily professional service fees and retention expenses related to the NeoPhotonics merger and the acquisition of IPG product lines, $10.4 million of amortization of intangibles acquired as part of these acquisitions, and $7.8 million expense with respect to the settlement of certain non-ordinary course litigation matters.  For a description of our material pending legal proceedings, refer to “Note 14. Commitments and Contingencies” of the notes to condensed consolidated financial statements included in Part I, Item 1 of this Form 10-Q.

[0001628280-23-002880:mdna:87]
From time to time, we incur expenses that are not part of our ordinary operations, such as mergers and acquisition-related and litigation expenses, which generally increase our SG&A expenses and potentially impact our profitability expectations in any particular quarter.

[0001628280-23-002880:mdna:88]
[same as prior period, unchanged from 0001628280-22-028783:mdna:81]

[0001628280-23-002880:mdna:89]
[same as prior period, unchanged from 0001628280-22-028783:mdna:82]

[0001628280-23-002880:mdna:90]
During the three months ended December 31, 2022, we recorded restructuring and related charges of $13.9 million in our condensed consolidated statements of operations, which was primarily due to company-wide integration efforts as a result of the merger with NeoPhotonics, as well as our cost reduction initiatives.

[0001628280-23-002880:mdna:91]
During the six months ended December 31, 2022, we recorded restructuring and related charges of $23.2 million in our condensed consolidated statements of operations, which was primarily attributable to company-wide integration efforts as a result of the merger with NeoPhotonics, our cost reduction initiatives, as well as severance and employee-related benefits associated with NeoPhotonics’ executive severance and retention agreements. These agreements provide for payments and benefits upon an involuntary termination of employment under certain circumstances.

[0001628280-23-002880:mdna:92]
In addition to the restructuring and related charges, during the three months ended December 31, 2022, we also recorded $1.5 million stock-based compensation in connection with our restructuring activities during the period.

[0001628280-23-002880:mdna:93]
During the six months ended January 1, 2022, we recorded a net reversal to our restructuring and related charges of $1.0 million, which was attributable to lower than anticipated employee severance charges primarily as a result of retaining and re-assigning certain employees.

[0001628280-23-002880:mdna:94]
[same as prior period, unchanged from 0001628280-22-028783:mdna:85]

[0001628280-23-002880:mdna:95]
For the three months ended December 31, 2022 and January 1, 2022, we recorded interest expense of $8.9 million and $17.1 million, respectively. For the six months ended December 31, 2022 and January 1, 2022, we recorded interest expense of $17.4 million and $34.0 million, respectively. Interest expense was driven primarily by the amortization of the debt discount and issuance costs of our convertible notes.  The decrease in interest expense for the three and six months ended December 31, 2022 is primarily a result of the adoption of ASU 2020-06 in our first quarter of fiscal 2023, which requires us to treat our 2026 Notes and 2028 Notes as a single liability measured at amortized cost, eliminating the interest expense associated with the debt discount.

[0001628280-23-002880:mdna:96]
Other Income, Net

[0001628280-23-002880:mdna:97]
[same as prior period, unchanged from 0001628280-22-028783:mdna:88]

[0001628280-23-002880:mdna:98]
|  | Three Months Ended |  | Six Months Ended |  |  |
|  | December 31, 2022 |  | January 1, 2022 |  | December 31, 2022 |  | January 1, 2022 |  |  |
| Foreign exchange gains (losses), net | $ | (4.1) |  |  | $ | 0.7 |  |  | $ | 4.9 |  |  | $ | 0.6 |  |  |  |
| Interest and investment income | 7.7 |  |  | 0.6 |  |  | 12.5 |  |  | 1.2 |  |  |  |
| Other income (expense), net | 0.1 |  |  | (0.3) |  |  | 0.1 |  |  | (0.2) |  |  |  |
| Total other income, net | $ | 3.7 |  |  | $ | 1.0 |  |  | $ | 17.5 |  |  | $ | 1.6 |  |  |  |

[0001628280-23-002880:mdna:99]
For the three months ended December 31, 2022, other income, net increased by $2.7 million, primarily due to an increase in interest and investment income of $7.1 million driven by an increase in interest rates on our fixed income securities, offset by $4.8 million net foreign exchange losses as a result of the strengthening of other foreign currencies relative to the U.S. dollar.

[0001628280-23-002880:mdna:100]
For the six months ended December 31, 2022, other income, net increased by $15.9 million, primarily due to an increase in interest and investment income of $11.3 million driven by an increase in interest rates on our fixed income securities and $4.3 million increase in foreign exchange gains as a result of the strengthening of U.S. dollar relative to other foreign currencies.

[0001628280-23-002880:mdna:101]
[same as prior period, unchanged from 0001628280-22-028783:mdna:91]

[0001628280-23-002880:mdna:102]
| (in millions) | Three Months Ended |  | Six Months Ended |
|  | December 31, 2022 |  | January 1, 2022 |  | December 31, 2022 |  | January 1, 2022 |
| Provision for income taxes | $ | 4.6 |  |  | $ | 12.4 |  |  | $ | 23.8 |  |  | $ | 30.5 |  |

[0001628280-23-002880:mdna:103]
We recorded a tax provision of $4.6 million and $23.8 million for the three and six months ended December 31, 2022, respectively. Our tax provision for the three months ended December 31, 2022 includes a discrete tax expense of $4.0 million, primarily related to the U.S. return to provision differences for transaction costs, currency remeasurements, and shortfall in connection with stock-based compensation vested during the quarter.

[0001628280-23-002880:mdna:104]
We recorded a tax provision of $12.4 million and $30.5 million for the three and six months ended January 1, 2022, respectively. Our tax provision for the three months ended January 1, 2022  includes a discrete tax benefit of $2.2 million, primarily related to currency re-measurement of certain tax related accounts and excess tax benefit related to stock-based compensation that vested during the quarter.

[0001628280-23-002880:mdna:105]
Our estimated effective tax rate for fiscal 2023 also differs from the 21% U.S. statutory rate primarily due to the income tax expense from the tax effect of Global Intangible Low-Taxed Income (“GILTI”), net of benefit for foreign tax credits, subpart F inclusion and non-deductible stock-based compensation, partially offset by the income tax benefit from U.S. federal R&D tax credits.

[0001628280-23-002880:mdna:106]
The Organization for Economic Cooperation and Development (OECD) announced that it has reached agreement, also known as Pillar Two, among its 136-member countries that certain multinational enterprises will be subject to a minimum 15% tax rate.  Many countries are expected to issue laws and regulations to conform with this guidance.  We will continue to monitor the pertinent law changes and regulations to determine the impact it would have on our operating and financial results.

[0001628280-23-002880:mdna:107]
[same as prior period, unchanged from 0001628280-22-028783:mdna:97]

[0001628280-23-002880:mdna:108]
[same as prior period, unchanged from 0001628280-22-028783:mdna:98]

[0001628280-23-002880:mdna:109]
As of December 31, 2022 and July 2, 2022, our cash and cash equivalents were $592.1 million and $1,290.2 million, respectively. As of December 31, 2022 and July 2, 2022, our short-term investments of $1,088.3 million and $1,258.8 million, respectively, were all held in the United States. Cash equivalents and short-term investments are primarily comprised of money market funds, treasuries, agencies, high quality investment grade fixed income securities, certificates of deposit and commercial paper. Our investment policy and strategy is focused on the preservation of capital and supporting our liquidity requirements.

[0001628280-23-002880:mdna:110]
The total amount of cash held by the non-United States entities as of December 31, 2022 and July 2, 2022 was $366.5 million and $216.1 million, respectively, which was primarily held by entities incorporated in the United Kingdom, the British Virgin Islands, Japan, Hong Kong, China, Switzerland, Cayman, and Thailand. Although the cash currently held in the United States, as well as the cash generated in the United States from future operations, is expected to cover our normal operating requirements, a substantial amount of additional cash could be required for other purposes, such as capital expenditures to support our business and growth, including costs associated with increasing internal manufacturing capabilities, particularly in our Thailand facility, strategic transactions and partnerships, and future acquisitions.

[0001628280-23-002880:mdna:111]
Our intent is to indefinitely reinvest funds held outside the United States and, except for the funds held in the Cayman Islands, the British Virgin Islands, Japan and Hong Kong, our current plans do not demonstrate a need to repatriate them to fund our domestic operations. However, if in the future, we encounter a significant need for liquidity domestically or at a particular location that we cannot fulfill through borrowings, equity offerings, or other internal or external sources, or the cost to bring back the money is not significant from a tax perspective, we may determine that cash repatriations are necessary or desirable. Repatriation could result in additional material taxes. These factors may cause us to have an overall tax rate higher than other

[0001628280-23-002880:mdna:112]
companies or higher than our tax rates have been in the past. Additionally, if conditions warrant, we may seek to obtain additional financing through debt or equity sources. To the extent we issue additional shares, it may create dilution to our existing stockholders. However, any such financing may not be available on terms favorable to us, or may not be available at all.

[0001628280-23-002880:mdna:113]
Beginning in fiscal 2023, the Tax Cuts and Jobs Act of 2017 requires taxpayers to capitalize research and development expenditures and amortize domestic expenditures over five years and foreign expenditures over fifteen years. This will delay deductibility of these expenses and potentially increase the amount of cash taxes we pay in the next several years.

[0001628280-23-002880:mdna:114]
[same as prior period, unchanged from 0001628280-22-028783:mdna:103]

[0001628280-23-002880:mdna:115]
We believe that our cash and cash equivalents as of December 31, 2022 and cash flows from our operating activities will be sufficient to meet our liquidity and capital spending requirements for at least the next 12 months.

[0001628280-23-002880:mdna:116]
[same as prior period, unchanged from 0001628280-22-028783:mdna:105]

[0001628280-23-002880:mdna:117]
[same as prior period, unchanged from 0001628280-22-028783:mdna:106]

[0001628280-23-002880:mdna:118]
[same as prior period, unchanged from 0001628280-22-028783:mdna:107]

[0001628280-23-002880:mdna:119]
[same as prior period, unchanged from 0001628280-22-028783:mdna:108]

[0001628280-23-002880:mdna:120]
[same as prior period, unchanged from 0001628280-22-028783:mdna:109]

[0001628280-23-002880:mdna:121]
[same as prior period, unchanged from 0001628280-22-028783:mdna:110]

[0001628280-23-002880:mdna:122]
[same as prior period, unchanged from 0001628280-22-028783:mdna:111]

[0001628280-23-002880:mdna:123]
[same as prior period, unchanged from 0001628280-22-028783:mdna:112]

[0001628280-23-002880:mdna:124]
[same as prior period, unchanged from 0001628280-22-028783:mdna:113]

[0001628280-23-002880:mdna:125]
[same as prior period, unchanged from 0001628280-22-028783:mdna:114]

[0001628280-23-002880:mdna:126]
[same as prior period, unchanged from 0001628280-22-028783:mdna:115]

[0001628280-23-002880:mdna:127]
[same as prior period, unchanged from 0001628280-22-028783:mdna:116]

[0001628280-23-002880:mdna:128]
[same as prior period, unchanged from 0001628280-22-028783:mdna:117]

[0001628280-23-002880:mdna:129]
[same as prior period, unchanged from 0001628280-22-028783:mdna:118]

[0001628280-23-002880:mdna:130]
[same as prior period, unchanged from 0001628280-22-028783:mdna:119]

[0001628280-23-002880:mdna:131]
[same as prior period, unchanged from 0001628280-22-028783:mdna:120]

[0001628280-23-002880:mdna:132]
The following table summarizes certain of our contractual obligations as of December 31, 2022, and the effect such obligations are expected to have on our liquidity and cash flow over the next five years (in millions):

[0001628280-23-002880:mdna:133]
|  | Payments due by period |
|  | Total |  | Less than 1 year |  | More than 1 year |  |  |  |  |
| Contractual Obligations |  |  |  |  |  |  |  |  |  |
| Asset retirement obligations | $ | 8.1 |  |  | $ | 0.5 |  |  | $ | 7.6 |  |  |  |  |  |
| Operating lease liabilities, including imputed interest (1) | 78.6 |  |  | 14.4 |  |  | 64.2 |  |  |  |  |  |
| Pension plan contributions (2) | 1.4 |  |  | 1.4 |  |  | — |  |  |  |  |  |
| Purchase obligations (3) | 391.5 |  |  | 361.0 |  |  | 30.5 |  |  |  |  |  |
| Convertible notes - principal (4) | 2,359.1 |  |  | — |  |  | 2,359.1 |  |  |  |  |  |
| Convertible notes - interest (4) | 46.3 |  |  | 10.7 |  |  | 35.6 |  |  |  |  |  |
| Total | $ | 2,885.0 |  |  | $ | 388.0 |  |  | $ | 2,497.0 |  |  |  |  |  |

[0001628280-23-002880:mdna:134]
(1) The amounts of operating lease liabilities in the table above do not include any sublease income amounts nor do they include payments for short-term leases or variable lease payments. As of December 31, 2022, we expect to receive sublease income of approximately $3.9 million over the sublease periods.

[0001628280-23-002880:mdna:135]
[same as prior period, unchanged from 0001628280-22-028783:mdna:124]

[0001628280-23-002880:mdna:136]
(3) Purchase obligations represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Refer to “Note 14. Commitments and Contingencies” in the notes to condensed consolidated financial statements.

[0001628280-23-002880:mdna:137]
(4) The amount includes principal and interest payment in cash on our 0.25% convertible notes due in 2024 (the “2024 Notes”), 0.50% convertible notes due in 2026 (the “2026 Notes”), and 0.50% convertible notes due in 2028 (the “2028 Notes”). The 2024 Notes have a maturity date of March 15, 2024, the 2026 Notes have a maturity date of December 15, 2026, and the 2028 Notes have a maturity date of June 15, 2028. The principal balances of our convertible notes are reflected in the payment periods in the table above based on their respective contractual maturities assuming no conversion. Refer to “Note 9. Debt” in the notes to condensed consolidated financial statements.

[0001628280-23-002880:mdna:138]
[same as prior period, unchanged from 0001628280-22-028783:mdna:127]

[0001628280-23-002880:mdna:139]
[same as prior period, unchanged from 0001628280-22-028783:mdna:128]

[0001628280-23-002880:mdna:140]
As of December 31, 2022, our 2024 Notes of $420.7 million (which have an aggregate principal amount of $448.1 million outstanding that matures in 2024) is presented in current liabilities in our condensed consolidated balance sheets. While the 2024 Notes will not be convertible during the third quarter of fiscal 2023 as our stock price did not exceed $78.80 for 20 of the last 30 trading days of the quarter ended December 31, 2022, we continue to classify the debt in current liabilities, as holders may convert their 2024 Notes at any time on or after December 15, 2023 until the close of business on the second scheduled trading day immediately preceding the maturity date. During the three and six months ended December 31, 2022, we received conversion requests of less than $0.1 million principal amount of the 2024 Notes, which we settled with cash in accordance with the 2024 Indenture. Since issuing the 2024 Notes, we have converted a total of approximately $1.9 million principal amount of the 2024 Notes. The remaining principal amount of the 2024 Notes as of December 31, 2022 was $448.1 million.

[0001628280-23-002880:mdna:141]
As of December 31, 2022, our 2026 Notes of $1,045.3 million (which have an aggregate principal amount of $1,050.0 million outstanding that matures in 2026) is presented in non-current liabilities in our condensed consolidated balance sheets. If the closing price of our stock exceeds $129.08 for 20 of the last 30 trading days of any future quarter, our 2026 Notes would also become convertible at the option of the holders and the debt would be reclassified to current liabilities in our condensed consolidated balance sheet.

[0001628280-23-002880:mdna:142]
As of December 31, 2022, our 2028 Notes of $855.0 million (which have an aggregate principal amount of $861.0 million outstanding that matures in 2028) is presented in non-current liabilities in our condensed consolidated balance sheets. If the closing price of our stock exceeds $170.34 for 20 of the last 30 trading days of any future quarter, our 2028 Notes would also become convertible at the option of the holders and the debt would be reclassified to current liabilities in our condensed consolidated balance sheet.

[0001628280-23-002880:mdna:143]
As of December 31, 2022, we paid all of the outstanding term loans that we assumed in connection with our merger with NeoPhotonics for $5.9 million.

[0001628280-23-002880:mdna:144]
[same as prior period, unchanged from 0001628280-22-028783:mdna:133]

[0001628280-23-002880:mdna:145]
[same as prior period, unchanged from 0001628280-22-028783:mdna:134]

[0001628280-23-002880:mdna:146]
During the six months ended December 31, 2022, we repurchased 0.3 million shares of our common stock at an average price of $89.80 per share for an aggregate purchase price of $25.7 million.

[0001628280-23-002880:mdna:147]
Since the share buyback program was initially approved by the board of directors, we have repurchased 7.4 million shares in aggregate at an average price of $83.38 per share for a total purchase price of $615.5 million. We recorded the $615.5 million aggregate purchase price as a reduction of retained earnings within our condensed consolidated balance sheet. All repurchased shares were retired immediately.

[0001628280-23-002880:mdna:148]
[same as prior period, unchanged from 0001628280-22-028783:mdna:137]

[0001628280-23-002880:mdna:149]
[same as prior period, unchanged from 0001628280-22-028783:mdna:138]

[0001628280-23-002880:mdna:150]
As of December 31, 2022, our other non-current liabilities also include $52.1 million of unrecognized tax benefit for uncertain tax positions. We are unable to reliably estimate the timing of future payments related to uncertain tax positions.

[0001628280-23-002880:mdna:151]
[same as prior period, unchanged from 0001628280-22-028783:mdna:140]

[0001628280-23-002880:mdna:152]
Our balance of cash and cash equivalents decreased by $698.1 million, from $1,290.2 million as of July 2, 2022 to $592.1 million as of December 31, 2022. The decrease in cash and cash equivalents during the six months ended December 31, 2022 was due to cash used in investing activities of $751.1 million and financing activities of $62.7 million, partially offset by cash provided by operating activities of $115.7 million.

[0001628280-23-002880:mdna:153]
[same as prior period, unchanged from 0001628280-22-028783:mdna:143]

[0001628280-23-002880:mdna:154]
Cash provided by operating activities was $115.7 million during the six months ended December 31, 2022, which reflects a net loss of $32.1 million and non-cash items of $240.2 million for the six months ended December 31, 2022, offset by $92.4 million changes in our operating assets and liabilities.  Changes in our operating assets and liabilities related primarily to an increase in inventories of $36.4 million and a decrease in accounts payable of $45.0 million, offset by an increase in accrued expenses and other current and non-current liabilities of $37.1 million.

[0001628280-23-002880:mdna:155]
Cash provided by operating activities was $268.4 million during the six months ended January 1, 2022, which reflects net income of $138.2 million and non-cash items of $168.4 million for the six months ended January 1, 2022, offset by $38.2 million change in operating assets and liabilities. Changes in our operating assets and liabilities related primarily to an increase in accounts receivable of $26.4 million, and an increase in inventories of $11.0 million.

[0001628280-23-002880:mdna:156]
[same as prior period, unchanged from 0001628280-22-028783:mdna:146]

[0001628280-23-002880:mdna:157]
Cash used in investing activities of $751.1 million during the six months ended December 31, 2022 was attributable to the acquisition of NeoPhotonics and IPG product lines in the amount of $861.6 million, net of cash acquired, and capital expenditures of $62.8 million, partially offset by net proceeds from sales or maturities of short-term investments of $173.2 million.

[0001628280-23-002880:mdna:158]
Cash used in investing activities of $345.8 million during the six months ended January 1, 2022 was attributable to purchases of short-term investments, net of sales and maturities of $307.8 million, and capital expenditures of $44.0 million,  offset by proceeds from the sales of property, plant and equipment of $6.0 million.

[0001628280-23-002880:mdna:159]
[same as prior period, unchanged from 0001628280-22-028783:mdna:149]

[0001628280-23-002880:mdna:160]
Cash used in financing activities of $62.7 million during the six months ended December 31, 2022 was driven by the repurchase of shares of our common stock of $35.8 million, tax payments related to net share settlement of restricted stock of $26.7 million, and $5.9 million payments of all the term loans that we assumed in connection with our merger with NeoPhotonics offset by $5.7 million proceeds from employee stock plans.

[0001628280-23-002880:mdna:161]
Cash used in financing activities of $144.9 million during the six months ended January 1, 2022 resulted from the repurchase of shares of our common stock of $126.6 million and tax payments related to net share settlement of restricted stock of $24.9 million, offset by proceeds from employee stock plans of $6.6 million.
