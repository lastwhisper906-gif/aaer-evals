# LITE notes — 0001628280-23-002880


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001628280-23-002880:notes:1]
[same as prior period, unchanged from 0001628280-22-028783:notes:1]

[0001628280-23-002880:notes:2]
[same as prior period, unchanged from 0001628280-22-028783:notes:2]

[0001628280-23-002880:notes:3]
Lumentum Holdings Inc. (“we,” “us,” “our”, “Lumentum” or the “Company”) is an industry-leading provider of optical and photonic products addressing a range of end market applications including Optical Communications (“OpComms”) and Commercial Lasers (“Lasers”) for manufacturing, inspection and life-science applications. We seek to use our core optical and photonic technology, and our volume manufacturing capability, to expand into attractive emerging markets that benefit from advantages that optical or photonics-based solutions provide, including imaging and sensing for consumer electronics and diode light sources for a variety of consumer and industrial applications. The majority of our customers have historically been, and are currently, original equipment manufacturers (“OEMs”) that incorporate our products into their products which then address end-market applications. For example, we sell fiber optic components that network equipment manufacturers (“NEMs”) assemble into communications networking systems, which they sell to communications service providers, hyperscale cloud operators, and enterprises with their own networks. Similarly, many of our Lasers products customers incorporate our products into tools they produce, which are used for manufacturing processes by their customers. For imaging and sensing, we sell diode lasers to manufacturers of consumer electronics products for mobile, personal computing, gaming, and other applications, including to the automotive industry, who then integrate our devices within their products, for eventual resale to consumers and also into other industrial applications.

[0001628280-23-002880:notes:4]
[same as prior period, unchanged from 0001628280-22-028783:notes:4]

[0001628280-23-002880:notes:5]
The accompanying condensed consolidated financial statements have been prepared in accordance with U.S. generally accepted accounting principles (“GAAP”), which requires management to make estimates and assumptions that affect the amounts reported in our condensed consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact us in the future, actual results may be different from the estimates. Operating results for the quarter ended December 31, 2022 are not necessarily indicative of the results that may be expected for the fiscal year ending July 1, 2023. In the opinion of the Company’s management, the information presented herein reflects all normal and recurring adjustments necessary for a fair presentation of our results of operations, financial position, stockholders’ equity and cash flows. Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are inventory valuation, revenue recognition, income taxes, goodwill and business combinations.

[0001628280-23-002880:notes:6]
Our business and operating results depend significantly on general market and economic conditions. The current global macroeconomic environment is volatile and continues to be significantly and adversely impacted by the COVID-19 pandemic, global supply chain constraints, inflation, and a dynamic demand environment. Additionally, instability in the global credit markets, the impact of uncertainty regarding global central bank monetary policy, capital expenditure reductions, unemployment and other labor issues, decline in stock markets, the instability in the geopolitical environment in many parts of the world and the current economic challenges in China continue to put pressure on global economic conditions and our business and operating results.

[0001628280-23-002880:notes:7]
While the impact of the COVID-19 pandemic is lessening, the duration and severity of the impact of the pandemic on our business and results of operations in future periods remain uncertain. The extent of the impact of COVID-19 on our operational and financial performance will depend on certain developments, including but not limited to the duration and spread of the pandemic and its variants, implementation and duration of local, state and federal issued public health orders in each jurisdiction where we operate or in which our customers and suppliers operate, impact on our customers and our sales cycles, impact on our supply chain and manufacturing partners, impact on our employees and impact on regional and worldwide economies and financial markets in general, all of which are uncertain and not predictable. We assessed the potential impact that this pandemic has on our estimates as of December 31, 2022 and determined that there were no material impacts. However, due to the global supply chain constraint, we have had to incur incremental supply and procurement costs in order to fulfill demand from our customers.  As of December 31, 2022, our inventory balance includes $18.0 million of incremental supply and procurement costs.

[0001628280-23-002880:notes:8]
We are also continuously monitoring the current developments in the ongoing war between Russia and Ukraine including the related export controls and resulting sanctions imposed on Russia by the U.S. and other countries. Additional factors such as increased inflation, escalating energy costs, constrained raw material availability, and related cost increases could impact the global economy. Although the global implications of the Russian/Ukraine war are difficult to predict at this time, we do not presently foresee direct material adverse effects upon our business.

[0001628280-23-002880:notes:9]
[same as prior period, unchanged from 0001628280-22-028783:notes:8]

[0001628280-23-002880:notes:10]
On August 3, 2022, we completed a merger with NeoPhotonics Corporation (“NeoPhotonics”). Our condensed consolidated financial statements include the operating results of NeoPhotonics for the period from the date of the closing of the merger through December 31, 2022. We have applied the acquisition method of accounting in accordance with Accounting Standards Codification (“ASC”) Topic 805, Business Combinations to account for this transaction. Refer to “Note 4. Business Combinations” for further discussion of the merger.

[0001628280-23-002880:notes:11]
On August 15, 2022, we completed a transaction to acquire IPG Photonics’ telecom transmission product lines. Our condensed consolidated financial statements include the operating results of this business unit for the period from the date of the acquisition through December 31, 2022. We have applied the acquisition method of accounting in accordance with ASC Topic 805, Business Combinations to account for this transaction. Refer to “Note 4. Business Combinations” for further discussion of this acquisition.

[0001628280-23-002880:notes:12]
[same as prior period, unchanged from 0001628280-22-028783:notes:11]

[0001628280-23-002880:notes:13]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Every fifth or sixth fiscal year will have a 53-week period. The additional week in a 53-week year is added to the third quarter, making such quarter consist of 14 weeks. Our fiscal 2023 is a 52-week year ending on July 1, 2023, with the quarter ended December 31, 2022 being a 13-week quarterly period. Our fiscal 2022 was a 52-week year that ended on July 2, 2022, with the quarter ended January 1, 2022 being a 13-week quarterly period.

[0001628280-23-002880:notes:14]
[same as prior period, unchanged from 0001628280-22-028783:notes:13]

[0001628280-23-002880:notes:15]
[same as prior period, unchanged from 0001628280-22-028783:notes:14]

[0001628280-23-002880:notes:16]
[same as prior period, unchanged from 0001628280-22-028783:notes:15]

[0001628280-23-002880:notes:17]
[same as prior period, unchanged from 0001628280-22-028783:notes:16]

[0001628280-23-002880:notes:18]
The condensed consolidated financial statements and accompanying related notes should be read in conjunction with the audited consolidated financial statements and related notes included in our Annual Report on Form 10-K for the fiscal year ended July 2, 2022. 
Except for the accounting policies for convertible instruments as a result of our adoption of Accounting Standards Update (“ASU”) 2020-06, Debt—Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging—Contracts in Entity’s Own Equity (Subtopic 815-40): Accounting for Convertible Instruments and Contracts in an Entity’s Own Equity, described in “Note 2. Recently Issued Accounting Pronouncements”, there have been no significant changes to our accounting policies during the six months ended December 31, 2022.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001628280-23-002880:notes:19]
Note 2. Recently Issued Accounting Pronouncements

[0001628280-23-002880:notes:20]
Accounting Pronouncements Recently Adopted

[0001628280-23-002880:notes:21]
In October 2021, the Financial Accounting Standards Board (“FASB”) issued ASU 2021-08, Business Combinations (Topic 805)—Accounting for Contract Assets and Contract Liabilities from Contracts with Customers. This ASU clarifies that an acquirer of a business should recognize and measure contract assets and contract liabilities in a business combination in accordance with ASC Topic 606, Revenue from Contracts with Customers. This ASU is expected to improve comparability for both the recognition and measurement of acquired revenue contracts with customers at the date of and after a business combination. The new guidance is effective for fiscal years beginning after December 15, 2022, with early adoption permitted. We early adopted the new standard in the first quarter of fiscal 2023 in connection with the merger with NeoPhotonics. There was no material impact to our condensed consolidated financial statements as of and for the three and six months period ended December 31, 2022.

[0001628280-23-002880:notes:22]
In August 2020, the FASB issued ASU 2020-06, Debt—Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging—Contracts in Entity’s Own Equity (Subtopic 815-40): Accounting for Convertible Instruments and Contracts in an Entity’s Own Equity, which simplifies the accounting for convertible instruments by removing the separation models for (i) convertible debt with a cash conversion feature and (ii) convertible instruments with a beneficial conversion feature. As a result, a convertible debt instrument is accounted for as a single liability measured at its amortized cost. ASU 2020-06 also requires the application of the if-converted method for calculating diluted earnings per share. We adopted the standard as of July 3, 2022, using the modified retrospective approach. Upon adoption, our 2026 Notes and 2028 Notes were accounted for as a single liability measured at amortized cost, resulting in: (i) an increase to the convertible notes liability balance of $433.0 million to reflect the full principal amount of the convertible notes outstanding, net of issuance costs; (ii) a reduction to additional paid-in capital, net of estimated income tax effects, of $426.5 million, to remove the equity component separately recorded for the conversion features associated with the convertible notes; (iii) an increase to deferred tax assets, net of $92.1 million; and (iv) a cumulative-effect adjustment of $85.6 million, net of estimated income tax effects, to decrease the accumulated deficit. In addition, the adoption requires the use of the if-converted method for all convertible notes in the diluted net income per share calculation and the inclusion of the effect of potential share settlement of the convertible notes, if the effect is more dilutive. There was no impact to diluted earnings per share for the three and six months ended December 31, 2022, as the inclusion of potential shares of common stock related to the convertible notes was anti-dilutive. Refer to “Note 9. Debt” for further information.

[0001628280-23-002880:notes:23]
The following table sets forth the impact upon adoption of ASU 2020-06 as of July 3, 2022 (in millions):

[0001628280-23-002880:notes:24]
|  |  | Short Term Debt - 2024 Notes |  | Long Term Debt - 2026 Notes |  | Long Term Debt - 2028 Notes |  | Additional Paid-In Capital |  | Accumulated Deficit |  | Deferred Tax Asset (Liability), net |
| Balances pre-adoption of ASC 2020-06 |  | $ | 409.9 |  |  | $ | 831.4 |  |  | $ | 634.7 |  |  | $ | 2,003.6 |  |  | $ | 129.1 |  |  | $ | 12.9 |  |
| Reclassify amounts from equity to debt |  | — |  |  | 312.9 |  |  | 229.3 |  |  | (542.2) |  |  | — |  |  | — |  |
| Adjustment for interest accretion |  | — |  |  | (99.5) |  |  | (9.7) |  |  | — |  |  | (109.2) |  |  | — |  |
| Tax effect |  | — |  |  | — |  |  | — |  |  | 115.7 |  |  | 23.6 |  |  | 92.1 |  |
| Balances upon adoption of ASC 2020-06 |  | $ | 409.9 |  |  | $ | 1,044.8 |  |  | $ | 854.3 |  |  | $ | 1,577.1 |  |  | $ | 43.5 |  |  | $ | 105.0 |  |


## us-gaap:EarningsPerShareTextBlock

[0001628280-23-002880:notes:25]
[same as prior period, unchanged from 0001628280-22-028783:notes:24]

[0001628280-23-002880:notes:26]
[same as prior period, unchanged from 0001628280-22-028783:notes:25]

[0001628280-23-002880:notes:27]
|  | Three Months Ended |  | Six Months Ended |
|  | December 31, 2022 |  | January 1, 2022 |  | December 31, 2022 |  | January 1, 2022 |
| Numerator: |  |  |  |  |  |  |  |
| Net income (loss) - basic and diluted | $ | (31.7) |  |  | $ | 56.7 |  |  | $ | (32.1) |  |  | $ | 138.2 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted average common shares outstanding - basic | 68.3 |  |  | 72.3 |  |  | 68.2 |  |  | 72.5 |  |
| Effect of dilutive securities from stock-based benefit plans | — |  |  | 0.5 |  |  | — |  |  | 0.6 |  |
| Shares issuable assuming conversion of the convertible notes | — |  |  | 2.5 |  |  | — |  |  | 2.3 |  |
| Weighted average common shares outstanding - diluted | 68.3 |  |  | 75.3 |  |  | 68.2 |  |  | 75.4 |  |
| Net income (loss) per share: |  |  |  |  |  |  |  |
| Basic | $ | (0.46) |  |  | $ | 0.78 |  |  | $ | (0.47) |  |  | $ | 1.91 |  |
| Diluted | $ | (0.46) |  |  | $ | 0.75 |  |  | $ | (0.47) |  |  | $ | 1.83 |  |

[0001628280-23-002880:notes:28]
Shares from stock-based benefit plans and shares issuable assuming conversion of our convertible notes are anti-dilutive for the three and six months ended December 31, 2022 and are therefore excluded from the calculation of diluted net income (loss) per share as the Company had a net loss for both periods.  Anti-dilutive shares excluded from the calculation of diluted net income (loss) per share for the three months ended December 31, 2022 mainly include 24.5 million shares related to convertible notes, 3.8 million shares issuable under restricted stock units (“RSUs”) and performance stock units (“PSUs”), and 0.2 million shares issuable under the Employee Stock Purchase Plan (the “2015 Purchase Plan”). Average anti-dilutive shares excluded from the calculation of diluted net income (loss) per share for the six months ended December 31, 2022 include 24.5 million shares related to convertible notes, 3.9 million shares issuable under RSUs and PSUs, and 0.1 million shares issuable under the 2015 Purchase Plan. Refer to “Note 13. Equity.”

[0001628280-23-002880:notes:29]
As a result of our adoption of ASU 2020-06 in the first quarter of fiscal 2023, potentially dilutive common shares issuable upon conversion of our outstanding 2024 Notes, 2026 Notes and 2028 Notes (collectively referred to as the “convertible notes”)  are determined using the if-converted method.

[0001628280-23-002880:notes:30]
For periods prior to the adoption of ASU 2020-06, which includes the three and six months ended January 1, 2022, our potentially dilutive common shares issuable upon conversion of our outstanding convertible notes are determined using the treasury stock method. Anti-dilutive shares excluded from the calculation of diluted earnings per share were less than 0.1 million and 0.4 million for the three and six months ended January 1, 2022, respectively.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001628280-23-002880:notes:31]
[same as prior period, unchanged from 0001628280-22-028783:notes:29]

[0001628280-23-002880:notes:32]
[same as prior period, unchanged from 0001628280-22-028783:notes:30]

[0001628280-23-002880:notes:33]
[same as prior period, unchanged from 0001628280-22-028783:notes:31]

[0001628280-23-002880:notes:34]
We have applied the acquisition method of accounting in accordance with ASC Topic 805, Business Combinations, with respect to the fair value of purchase price consideration and the identifiable assets and liabilities of NeoPhotonics, which have been measured at estimated fair value as of the Closing date. The following tables summarize the total purchase price consideration (in millions):

[0001628280-23-002880:notes:35]
|  | Fair Value |
| Cash consideration for outstanding NeoPhotonics common stock (1) | $ | 867.3 |  |
| Settlement of pre-existing relationship (loan to NeoPhotonics) (2) | 50.0 |  |
| Stock-based compensation (3) | 17.1 |  |
| Total purchase price consideration | $ | 934.4 |  |

[0001628280-23-002880:notes:36]
(1) Under the terms of the Merger Agreement, NeoPhotonics stockholders received $16.00 per share for each of the 54.2 million NeoPhotonics common stock outstanding at the Closing date. As a result, we paid $867.3 million of cash consideration to shareholders of NeoPhotonics on the Closing date.

[0001628280-23-002880:notes:37]
(2) As contemplated by the Merger Agreement, on January 14, 2022, Lumentum and NeoPhotonics entered into a credit agreement where Lumentum agreed to make term loans (“loans”) to NeoPhotonics in an aggregate principal amount not to exceed $50.0 million to help fund capital expenditures and increase working capital associated with NeoPhotonics’ growth plans. During fiscal 2022, the Company funded a $30.0 million loan to NeoPhotonics. On August 1, 2022, we funded an additional $20.0 million loan to NeoPhotonics. The interest was payable monthly in arrears on the first day of each month. The loans would have matured on January 14, 2024 unless earlier repaid or accelerated. The $50.0 million loans in aggregate were included as part of the total purchase price consideration.

[0001628280-23-002880:notes:38]
[same as prior period, unchanged from 0001628280-22-028783:notes:36]

[0001628280-23-002880:notes:39]
The total transaction consideration of $934.4 million was funded by the cash balances of the combined company. We also recorded $22.1 million of merger-related costs, representing professional and other direct acquisition costs. Of the $22.1 million of merger-related costs, $8.3 million was incurred in fiscal year 2022, and $1.2 million and $13.8 million was incurred during the three and six months ended December 31, 2022, respectively, which was recorded as selling, general and administrative expense in the condensed consolidated statements of operations.

[0001628280-23-002880:notes:40]
[same as prior period, unchanged from 0001628280-22-028783:notes:38]

[0001628280-23-002880:notes:41]
|  | Fair Value |
| Total purchase price consideration | $ | 934.4 |  |
| Assets acquired |  |
| Cash and cash equivalents | $ | 92.9 |  |
| Accounts receivable, net | 66.5 |  |
| Inventories | 84.3 |  |
| Prepayments and other current assets | 24.2 |  |
| Property, plant and equipment, net | 106.1 |  |
| Operating lease right-of-use assets, net | 16.9 |  |
| Other intangible assets, net (1) | 412.5 |  |
| Deferred tax asset | 0.1 |  |
| Other non-current assets | 1.9 |  |
| Total assets | 805.4 |  |
| Liabilities assumed |  |
| Accounts payable | 79.6 |  |
| Accrued payroll and related expenses | 11.1 |  |
| Accrued expenses | 4.1 |  |
| Other current liabilities | 10.6 |  |
| Operating lease liabilities, current | 2.8 |  |
| Operating lease liabilities, non-current | 13.2 |  |
| Deferred tax liability | 39.8 |  |
| Other non-current liabilities | 28.2 |  |
| Total liabilities | 189.4 |  |
| Goodwill | $ | 318.4 |  |

[0001628280-23-002880:notes:42]
[same as prior period, unchanged from 0001628280-22-028783:notes:40]

[0001628280-23-002880:notes:43]
[same as prior period, unchanged from 0001628280-22-028783:notes:41]

[0001628280-23-002880:notes:44]
Goodwill has been assigned to the OpComms segment. The preliminary goodwill of $318.4 million arising from the acquisition is attributed to the expected synergies, including future cost efficiencies and other benefits that are expected to be generated by combining Lumentum and NeoPhotonics. None of the goodwill is expected to be deductible for local tax purposes.  Refer to “Note 8. Goodwill and Other Intangible Assets.”

[0001628280-23-002880:notes:45]
From the Closing date, NeoPhotonics contributed $104.6 million and $177.4 million of our consolidated net revenue for the three and six months ended December 31, 2022, respectively. Due to the continued integration of the combined businesses, as well as our corporate structure and the allocation of selling, general and administrative costs, it is impracticable to determine NeoPhotonics’ contribution to our earnings.

[0001628280-23-002880:notes:46]
[same as prior period, unchanged from 0001628280-22-028783:notes:44]

[0001628280-23-002880:notes:47]
The following supplemental pro forma information presents the combined results of operations for the three and six months ended December 31, 2022 and January 1, 2022, as if the merger was completed at the first day of fiscal 2022. The supplemental pro forma financial information presented below is not necessarily indicative of the financial position or results of operations that would have been realized if the acquisition had been completed on the date indicated. The supplemental pro forma financial information does not reflect synergies that might have been achieved, nor is it indicative of future operating results or financial position.

[0001628280-23-002880:notes:48]
The pro forma financial information includes adjustments for: (i) additional amortization expense that would have been recognized related to the acquired intangible assets, (ii) additional depreciation expense that would have been recognized related to the acquired property, plant, and equipment, (iii) additional cost of sales related to the inventory valuation adjustment, (iv) acquisition related costs, such as third party transaction costs and restructuring costs, (v) stock-based compensation expense and (vi) the estimated income tax effect on the pro forma adjustments.

[0001628280-23-002880:notes:49]
[same as prior period, unchanged from 0001628280-22-028783:notes:47]

[0001628280-23-002880:notes:50]
|  | Three Months Ended |  | Six Months Ended |
|  | December 31, 2022 |  | January 1, 2022 |  | December 31, 2022 |  | January 1, 2022 |
| Net revenue | $ | 506.0 |  |  | $ | 527.3 |  |  | $ | 1,036.7 |  |  | $ | 1,059.4 |  |
| Net income (loss) | (25.8) |  |  | 22.8 |  |  | 6.6 |  |  | 45.0 |  |

[0001628280-23-002880:notes:51]
[same as prior period, unchanged from 0001628280-22-028783:notes:49]

[0001628280-23-002880:notes:52]
On August 15, 2022 (“IPG Closing date”), we completed a transaction to acquire IPG Photonics’ telecom transmission product lines that are used to develop and market products for use in telecommunications and datacenter infrastructure, including Digital Signal Processors (DSPs), ASICs and optical transceivers (“IPG product lines”). This acquisition enables us to expand our business in the OpComms segment.

[0001628280-23-002880:notes:53]
We have applied the acquisition method of accounting in accordance with ASC Topic 805, Business Combinations to account for this transaction. The total purchase price is $55.9 million, which was paid in cash. Our preliminary allocation of the purchase price consideration includes $29.1 million of in process research and development (“IPR&D”), $8.6 million of developed technology, $2.3 million of customer relationships, and $5.0 million of other net assets and liabilities, resulting in preliminary goodwill of $10.9 million. The allocation of the purchase price to the assets acquired and liabilities assumed, including the residual amount allocated to goodwill, is based upon preliminary information and adjustments may result before the end of the measurement period, which ends one year from the IPG Closing date.

[0001628280-23-002880:notes:54]
We incurred $0.1 million and $1.5 million of transaction costs, respectively, during the three and six months ended December 31, 2022, which was recorded as selling, general and administrative expense in the condensed consolidated statements of operations.

[0001628280-23-002880:notes:55]
The pro forma financial information from the acquisition of the IPG product lines, assuming the acquisition had occurred as of the first day of the fiscal year prior to the fiscal year of the acquisition, as well as revenue and earnings generated during the current fiscal year, were not material for disclosure purposes.


## us-gaap:CashCashEquivalentsAndShortTermInvestmentsTextBlock

[0001628280-23-002880:notes:56]
[same as prior period, unchanged from 0001628280-22-028783:notes:54]

[0001628280-23-002880:notes:57]
[same as prior period, unchanged from 0001628280-22-028783:notes:55]

[0001628280-23-002880:notes:58]
|  | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| December 31, 2022: |  |  |  |  |  |  |  |
| Cash | $ | 383.3 |  |  | $ | — |  |  | $ | — |  |  | $ | 383.3 |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | 4.8 |  |  | — |  |  | — |  |  | 4.8 |  |
| Money market funds | 180.1 |  |  | — |  |  | — |  |  | 180.1 |  |
| U.S. Treasury securities | 23.9 |  |  | — |  |  | — |  |  | 23.9 |  |
| Total cash and cash equivalents | $ | 592.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 592.1 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 27.6 |  |  | $ | — |  |  | $ | — |  |  | $ | 27.6 |  |
| Commercial paper | 88.0 |  |  | — |  |  | (0.2) |  |  | 87.8 |  |
| Corporate debt securities | 504.2 |  |  | 0.1 |  |  | (4.8) |  |  | 499.5 |  |
| Municipal bonds | 1.0 |  |  | — |  |  | — |  |  | 1.0 |  |
| Foreign government bonds | 1.4 |  |  | — |  |  | — |  |  | 1.4 |  |
| U.S. Agency securities | 130.5 |  |  | — |  |  | (1.6) |  |  | 128.9 |  |
| U.S. Treasury securities | 344.9 |  |  | — |  |  | (2.8) |  |  | 342.1 |  |
| Total short-term investments | $ | 1,097.6 |  |  | $ | 0.1 |  |  | $ | (9.4) |  |  | $ | 1,088.3 |  |
| July 2, 2022: |  |  |  |  |  |  |  |
| Cash | $ | 235.9 |  |  | $ | — |  |  | $ | — |  |  | $ | 235.9 |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | 23.6 |  |  | — |  |  | — |  |  | 23.6 |  |
| Money market funds | 1,000.2 |  |  | — |  |  | — |  |  | 1,000.2 |  |
| U.S. Agency securities | 8.0 |  |  | — |  |  | — |  |  | 8.0 |  |
| U.S. Treasury securities | 22.5 |  |  |  |  | — |  |  | 22.5 |  |
| Total cash and cash equivalents | $ | 1,290.2 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,290.2 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 28.3 |  |  | $ | — |  |  | $ | — |  |  | $ | 28.3 |  |
| Commercial paper | 107.4 |  |  | — |  |  | (0.4) |  |  | 107.0 |  |
| Corporate debt securities | 539.9 |  |  |  |  | (7.4) |  |  | 532.5 |  |
| Municipal bonds | 1.0 |  |  | — |  |  | — |  |  | 1.0 |  |
| U.S. Agency securities | 67.1 |  |  | — |  |  | (1.4) |  |  | 65.7 |  |
| U.S. Treasury securities | 528.2 |  |  | 0.3 |  |  | (4.2) |  |  | 524.3 |  |
| Total short-term investments | $ | 1,271.9 |  |  | $ | 0.3 |  |  | $ | (13.4) |  |  | $ | 1,258.8 |  |

[0001628280-23-002880:notes:59]
We review our investment portfolio to identify and evaluate investments that have indicators of possible impairment. Factors considered in determining whether a loss is other-than-temporary include, but are not limited to, the length of time and extent a security’s fair value has been below its cost, the financial condition and near-term prospects of the investee, the credit quality of the security’s issuer, likelihood of recovery and our intent and ability to hold the security for a period of time sufficient to allow for any anticipated recovery in value. For the debt instruments we own, we also evaluate whether we have the intent to sell the security or whether it is more likely than not that we will be required to sell the security before recovery of its cost basis. We have not recorded our unrealized losses on our short-term investments into income because we do not intend to sell nor is it more likely than not that we will be required to sell these investments prior to recovery of their amortized cost basis.

[0001628280-23-002880:notes:60]
We use the specific-identification method to determine any realized gains or losses from the sale of our short-term investments classified as available-for-sale. During the three and six months ended December 31, 2022, we did not realize significant gains or losses on a gross level from the sale of our short-term investments classified as available-for-sale.

[0001628280-23-002880:notes:61]
During the three and six months ended December 31, 2022, our other income (expense), net was $3.7 million income and $17.5 million income, respectively, which includes interest and investment income on cash equivalents and short-term investments of $7.7 million and $12.5 million, respectively. During the three and six months ended January 1, 2022, our other income (expense), net was $1.0 million income and $1.6 million income, respectively, which includes interest and investment income on cash equivalents and short-term investments of $0.6 million and $1.2 million, respectively.

[0001628280-23-002880:notes:62]
As of December 31, 2022 and July 2, 2022, we recorded interest receivables of $5.3 million and $3.9 million, respectively, in prepayments and other current assets within the condensed consolidated balance sheets. We did not recognize an allowance for credit losses against interest receivables in any of the periods presented as there were no such losses.

[0001628280-23-002880:notes:63]
The following table summarizes unrealized losses on our cash equivalents and short-term investments by category that have been in a continuous unrealized loss position for more than 12 months and  less than 12 months as of the periods presented, respectively (in millions):

[0001628280-23-002880:notes:64]
|  | Continuous Loss Position For More Than 12 Months |  | Continuous Loss Position For Less Than 12 Months |  | Gross Unrealized Losses |  |  |  |  |  |  |  |  |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  |  |  |  |  |  |  |  |  |
| December 31, 2022: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | 45.9 |  |  | $ | (1.1) |  |  | $ | 83.0 |  |  | $ | (0.5) |  |  | $ | (1.6) |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | — |  |  | 5.7 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | — |  |  | — |  |  | 73.4 |  |  | (0.2) |  |  | (0.2) |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 283.9 |  |  | (3.0) |  |  | 176.2 |  |  | (1.8) |  |  | (4.8) |  |  |  |  |  |  |  |  |  |
| Municipal bonds | 1.0 |  |  | — |  |  | — |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Foreign government bonds | — |  |  | — |  |  | 1.4 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 148.1 |  |  | (2.4) |  |  | 98.2 |  |  | (0.4) |  |  | (2.8) |  |  |  |  |  |  |  |  |  |
| Total | $ | 478.9 |  |  | $ | (6.5) |  |  | $ | 437.9 |  |  | $ | (2.9) |  |  | $ | (9.4) |  |  |  |  |  |  |  |  |  |
| July 2, 2022: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | — |  |  | $ | — |  |  | $ | 73.7 |  |  | $ | (1.4) |  |  | $ | (1.4) |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | — |  |  | 16.2 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | — |  |  | — |  |  | 130.7 |  |  | (0.4) |  |  | (0.4) |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 57.4 |  |  | (0.9) |  |  | 473.2 |  |  | (6.5) |  |  | (7.4) |  |  |  |  |  |  |  |  |  |
| Municipal bonds | — |  |  | — |  |  | 1.0 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | — |  |  | — |  |  | 366.0 |  |  | (4.2) |  |  | (4.2) |  |  |  |  |  |  |  |  |  |
| Total | $ | 57.4 |  |  | $ | (0.9) |  |  | $ | 1,060.8 |  |  | $ | (12.5) |  |  | $ | (13.4) |  |  |  |  |  |  |  |  |  |

[0001628280-23-002880:notes:65]
The following table classifies our short-term investments by remaining maturities (in millions):

[0001628280-23-002880:notes:66]
|  | December 31, 2022 |  | July 2, 2022 |
|  | Amortized Cost |  | Fair Value |  | Amortized Cost |  | Fair Value |
| Due in 1 year | $ | 879.5 |  |  | $ | 871.6 |  |  | $ | 1,010.9 |  |  | $ | 1,002.2 |  |
| Due in 1 year through 5 years | 218.1 |  |  | 216.7 |  |  | 261.0 |  |  | 256.6 |  |
|  | $ | 1,097.6 |  |  | $ | 1,088.3 |  |  | $ | 1,271.9 |  |  | $ | 1,258.8 |  |

[0001628280-23-002880:notes:67]
[same as prior period, unchanged from 0001628280-22-028783:notes:66]


## us-gaap:FairValueDisclosuresTextBlock

[0001628280-23-002880:notes:68]
[same as prior period, unchanged from 0001628280-22-028783:notes:67]

[0001628280-23-002880:notes:69]
[same as prior period, unchanged from 0001628280-22-028783:notes:68]

[0001628280-23-002880:notes:70]
[same as prior period, unchanged from 0001628280-22-028783:notes:69]

[0001628280-23-002880:notes:71]
[same as prior period, unchanged from 0001628280-22-028783:notes:70]

[0001628280-23-002880:notes:72]
[same as prior period, unchanged from 0001628280-22-028783:notes:71]

[0001628280-23-002880:notes:73]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| December 31, 2022: (1) |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | — |  |  | $ | 4.8 |  |  | $ | — |  |  | $ | 4.8 |  |
| Money market funds | 180.1 |  |  | — |  |  | — |  |  | 180.1 |  |
| U.S. Treasury securities | 23.9 |  |  | — |  |  | — |  |  | 23.9 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | 27.6 |  |  | — |  |  | 27.6 |  |
| Commercial paper | — |  |  | 87.8 |  |  | — |  |  | 87.8 |  |
| Corporate debt securities | — |  |  | 499.5 |  |  | — |  |  | 499.5 |  |
| Municipal bonds | — |  |  | 1.0 |  |  | — |  |  | 1.0 |  |
| Foreign government bonds | — |  |  | 1.4 |  |  | — |  |  | 1.4 |  |
| U.S. Agency securities | — |  |  | 128.9 |  |  | — |  |  | 128.9 |  |
| U.S. Treasury securities | 342.1 |  |  | — |  |  | — |  |  | 342.1 |  |
| Total assets | $ | 546.1 |  |  | $ | 751.0 |  |  | $ | — |  |  | $ | 1,297.1 |  |

[0001628280-23-002880:notes:74]
(1)  Excludes $383.3 million in cash held in our bank accounts as of December 31, 2022.

[0001628280-23-002880:notes:75]
[same as prior period, unchanged from 0001628280-22-028783:notes:74]

[0001628280-23-002880:notes:76]
[same as prior period, unchanged from 0001628280-22-028783:notes:75]

[0001628280-23-002880:notes:77]
[same as prior period, unchanged from 0001628280-22-028783:notes:76]

[0001628280-23-002880:notes:78]
[same as prior period, unchanged from 0001628280-22-028783:notes:77]

[0001628280-23-002880:notes:79]
[same as prior period, unchanged from 0001628280-22-028783:notes:78]

[0001628280-23-002880:notes:80]
|  | December 31, 2022 |  | July 2, 2022 |
|  | Carrying Amount |  | Estimated Fair Value |  | Carrying Amount |  | Estimated Fair Value |
| 2028 Notes | $ | 855.0 |  |  | $ | 659.7 |  |  | $ | 634.7 |  |  | $ | 735.7 |  |
| 2026 Notes | 1,045.3 |  |  | 907.4 |  |  | 831.4 |  |  | 1,065.0 |  |
| 2024 Notes | 420.7 |  |  | 473.2 |  |  | 409.9 |  |  | 614.2 |  |
|  | $ | 2,321.0 |  |  | $ | 2,040.3 |  |  | $ | 1,876.0 |  |  | $ | 2,414.9 |  |

[0001628280-23-002880:notes:81]
[same as prior period, unchanged from 0001628280-22-028783:notes:80]

[0001628280-23-002880:notes:82]
[same as prior period, unchanged from 0001628280-22-028783:notes:81]

[0001628280-23-002880:notes:83]
Management utilizes various valuation methods, including an income approach, a market approach and a cost approach, to estimate the fair value of intangibles and other long-lived assets. During the annual impairment testing performed in the fourth quarter of fiscal 2022, we concluded that our intangible and other long-lived assets were not impaired. We review our intangible and other long-lived assets for impairment at least annually in the fourth quarter of each fiscal year, absent any interim indicators of impairment.  There were no indicators of impairment during the three and six months ended December 31, 2022.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001628280-23-002880:notes:84]
[same as prior period, unchanged from 0001628280-22-028783:notes:83]

[0001628280-23-002880:notes:85]
[same as prior period, unchanged from 0001628280-22-028783:notes:84]

[0001628280-23-002880:notes:86]
We did not have any allowance for credit losses other than our allowance for uncollectible accounts receivable. As of December 31, 2022 and July 2, 2022, the allowance for credit losses on our trade receivables was less than $0.1 million for both periods.

[0001628280-23-002880:notes:87]
[same as prior period, unchanged from 0001628280-22-028783:notes:86]

[0001628280-23-002880:notes:88]
[same as prior period, unchanged from 0001628280-22-028783:notes:87]

[0001628280-23-002880:notes:89]
|  | December 31, 2022 |  | July 2, 2022 |
| Raw materials and purchased parts | $ | 166.2 |  |  | $ | 98.9 |  |
| Work in process | 118.9 |  |  | 92.2 |  |
| Finished goods | 81.8 |  |  | 59.0 |  |
| Inventories | $ | 366.9 |  |  | $ | 250.1 |  |

[0001628280-23-002880:notes:90]
In connection with the NeoPhotonics merger, we recorded $17.8 million of inventory fair value step-up as of the merger Closing date. During the three and six months ended December 31, 2022, we recorded an amortization of fair value step-up of $9.6 million and $14.2 million, respectively. As of December 31, 2022, the remaining fair value step-up is $3.6 million.

[0001628280-23-002880:notes:91]
[same as prior period, unchanged from 0001628280-22-028783:notes:90]

[0001628280-23-002880:notes:92]
[same as prior period, unchanged from 0001628280-22-028783:notes:91]

[0001628280-23-002880:notes:93]
|  | December 31, 2022 |  | July 2, 2022 |
| Operating lease right-of-use assets | $ | 119.1 |  |  | $ | 102.1 |  |
| Less: accumulated amortization | (34.2) |  |  | (28.5) |  |
| Operating lease right-of-use assets, net | $ | 84.9 |  |  | $ | 73.6 |  |

[0001628280-23-002880:notes:94]
In connection with the NeoPhotonics merger, we acquired $16.9 million right-of-use assets as of the merger Closing date,  related to leases of real estate properties used as our manufacturing and R&D premises. These leases are accounted for as operating leases and have the remaining lease term ranging from 3.8 to 6.4 years at the Closing date.

[0001628280-23-002880:notes:95]
[same as prior period, unchanged from 0001628280-22-028783:notes:94]

[0001628280-23-002880:notes:96]
[same as prior period, unchanged from 0001628280-22-028783:notes:95]

[0001628280-23-002880:notes:97]
|  | December 31, 2022 |  | July 2, 2022 |
| Land | $ | 63.3 |  |  | $ | 49.7 |  |
| Buildings and improvements | 146.6 |  |  | 105.3 |  |
| Machinery and equipment | 632.6 |  |  | 548.8 |  |
| Computer equipment and software | 36.1 |  |  | 31.3 |  |
| Furniture and fixtures | 10.1 |  |  | 8.9 |  |
| Leasehold improvements | 45.9 |  |  | 35.7 |  |
| Construction in progress | 75.9 |  |  | 47.0 |  |
|  | 1,010.5 |  |  | 826.7 |  |
| Less: Accumulated depreciation | (522.8) |  |  | (466.2) |  |
| Property, plant and equipment, net | $ | 487.7 |  |  | $ | 360.5 |  |

[0001628280-23-002880:notes:98]
In connection with our merger with NeoPhotonics, we assumed $106.1 million of property, plant and equipment, net, as of the Closing date.

[0001628280-23-002880:notes:99]
[same as prior period, unchanged from 0001628280-22-028783:notes:98]

[0001628280-23-002880:notes:100]
During the three and six months ended December 31, 2022, we recorded depreciation expense of $26.4 million and $50.9 million, respectively. During the three and six months ended January 1, 2022, we recorded depreciation expense of $20.6 million and $41.0 million, respectively.

[0001628280-23-002880:notes:101]
[same as prior period, unchanged from 0001628280-22-028783:notes:100]

[0001628280-23-002880:notes:102]
[same as prior period, unchanged from 0001628280-22-028783:notes:101]

[0001628280-23-002880:notes:103]
|  | December 31, 2022 |  | July 2, 2022 |
| Restructuring accrual and related charges (1) | $ | 14.1 |  |  | $ | — |  |
| Warranty accrual | 8.4 |  |  | 10.0 |  |
| Income tax payable (2) | 20.5 |  |  | 26.0 |  |
| Other current liabilities | 8.2 |  |  | 3.4 |  |
| Other current liabilities | $ | 51.2 |  |  | $ | 39.4 |  |

[0001628280-23-002880:notes:104]
[same as prior period, unchanged from 0001628280-22-028783:notes:103]

[0001628280-23-002880:notes:105]
[same as prior period, unchanged from 0001628280-22-028783:notes:104]

[0001628280-23-002880:notes:106]
[same as prior period, unchanged from 0001628280-22-028783:notes:105]

[0001628280-23-002880:notes:107]
[same as prior period, unchanged from 0001628280-22-028783:notes:106]

[0001628280-23-002880:notes:108]
|  | December 31, 2022 |  | July 2, 2022 |
| Asset retirement obligations | $ | 8.1 |  |  | $ | 4.6 |  |
| Pension and related accruals (1) | 9.0 |  |  | 7.7 |  |
| Unrecognized tax benefit | 52.1 |  |  | 30.5 |  |
| Other non-current liabilities | 7.9 |  |  | 0.1 |  |
| Other non-current liabilities | $ | 77.1 |  |  | $ | 42.9 |  |

[0001628280-23-002880:notes:109]
(1) We have defined benefit pension plans in Japan, Switzerland, and Thailand. In connection with our merger with NeoPhotonics, we assumed an additional defined benefit plan covering employees in Japan. As of December 31, 2022, pension and related accruals in Japan, Switzerland and Thailand were $4.7 million, $0.4 million and $3.9 million, respectively. As of July 2, 2022, pension and related accruals in Japan, Switzerland and Thailand were $2.6 million, $1.7 million and $3.4 million, respectively. We typically re-evaluate the assumptions related to the fair value of our defined benefit obligations annually and make any updates as necessary.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001628280-23-002880:notes:110]
[same as prior period, unchanged from 0001628280-22-028783:notes:109]

[0001628280-23-002880:notes:111]
[same as prior period, unchanged from 0001628280-22-028783:notes:110]

[0001628280-23-002880:notes:112]
In the first quarter of fiscal 2023, we completed two acquisitions, our merger with NeoPhotonics and the acquisition of IPG product lines. We recognized goodwill in the amount of $318.4 million related to the NeoPhotonics merger and $10.9 million related to the acquisition of the IPG product lines. We allocated the entire goodwill amount in connection with the two acquisitions to the OpComms segment.

[0001628280-23-002880:notes:113]
The following table presents the changes in goodwill by reportable segments during the six months ended December 31, 2022 (in millions):

[0001628280-23-002880:notes:114]
|  | Optical Communications |  | Commercial Lasers |  | Total |
| Balance as of July 2, 2022 | $ | 363.5 |  |  | $ | 5.4 |  |  | $ | 368.9 |  |
| Acquisition of NeoPhotonics (1) | 318.4 |  |  | — |  |  | 318.4 |  |
| Acquisition of IPG product lines (2) | 10.9 |  |  | — |  |  | 10.9 |  |
| Balance as of December 31, 2022 | $ | 692.8 |  |  | $ | 5.4 |  |  | $ | 698.2 |  |

[0001628280-23-002880:notes:115]
(1) We recorded $318.3 million of goodwill as of the acquisition date and $0.1 million of measurement period adjustments to goodwill during the second quarter of fiscal 2023.

[0001628280-23-002880:notes:116]
(2)  We recorded $6.5 million of goodwill as of the acquisition date and $4.4 million of measurement period adjustments to goodwill during the second quarter of fiscal 2023.

[0001628280-23-002880:notes:117]
[same as prior period, unchanged from 0001628280-22-028783:notes:114]

[0001628280-23-002880:notes:118]
We review goodwill for impairment during the fourth quarter of each fiscal year or more frequently if events or circumstances indicate that an impairment loss may have occurred. In the fourth quarter of fiscal 2022, we completed the annual impairment test of goodwill, which indicated there was no goodwill impairment. During the second quarter of fiscal 2023, we evaluated the current economic uncertainties due to threats of a recession, increasing inflation, decline in our share prices, and rising interest rates, and determined based on the qualitative assessment that it is not more likely than not that the carrying value of goodwill is impaired. No goodwill impairment existed during the three and six months ended December 31, 2022.

[0001628280-23-002880:notes:119]
[same as prior period, unchanged from 0001628280-22-028783:notes:116]

[0001628280-23-002880:notes:120]
The intangible assets are amortized on a straight-line basis over the estimated useful lives, except for customer relationships, which are amortized using an accelerated method of amortization over the expected customer lives, more accurately reflecting the pattern of realization of economic benefits we expect to derive. Acquired developed technologies are amortized to cost of sales and customer relationships are amortized to selling, general and administrative expenses in the consolidated statement of operations.

[0001628280-23-002880:notes:121]
IPR&D is initially capitalized at fair value as an intangible asset with an indefinite life and assessed for impairment thereafter. When an IPR&D project is completed, the IPR&D is reclassified as an amortizable purchased intangible asset and amortized over the asset’s estimated useful life.

[0001628280-23-002880:notes:122]
As of December 31, 2022, we recorded the preliminary fair value of acquired intangible assets of $412.5 million related to the merger with NeoPhotonics and $40.0 million related to the acquisition of the IPG product lines. Refer to “Note 4. Business Combinations.”

[0001628280-23-002880:notes:123]
During the annual impairment testing performed in the fourth quarter of fiscal 2022, we concluded that our intangible and other long-lived assets were not impaired. We review our intangible and other long-lived assets for impairment at least annually in the fourth quarter of each fiscal year, absent any interim indicators of impairment.  There were no indicators of impairment during the three and six months ended December 31, 2022.

[0001628280-23-002880:notes:124]
The intangible assets acquired from the acquisitions were as follows as of the acquisition date (in millions, except for weighted average amortization periods):

[0001628280-23-002880:notes:125]
|  | Preliminary fair value at the acquisition date |  | Weighted average amortization period(in years) |
|  | NeoPhotonics |  | IPG product lines |  | Total acquired |  |
| Acquired developed technologies | $ | 220.0 |  |  | $ | 8.6 |  |  | $ | 228.6 |  |  | 5.2 |
| Customer relationships | 144.5 |  |  | 2.3 |  |  | 146.8 |  |  | 5.9 |
| In-process research and development | 48.0 |  |  | 29.1 |  |  | 77.1 |  |  | n/a |
| Total intangible assets | $ | 412.5 |  |  | $ | 40.0 |  |  | $ | 452.5 |  |  |  |

[0001628280-23-002880:notes:126]
[same as prior period, unchanged from 0001628280-22-028783:notes:122]

[0001628280-23-002880:notes:127]
| December 31, 2022 | Gross Carrying Amounts |  | Accumulated Amortization |  | Net Carrying Amounts |  | Weighted average remaining amortization period (years) |
| Acquired developed technologies | $ | 618.9 |  |  | $ | (352.3) |  |  | $ | 266.6 |  |  | 4.3 |
| Customer relationships | 291.8 |  |  | (95.6) |  |  | 196.2 |  |  | 5.1 |
| In-process research and development | 77.1 |  |  | — |  |  | 77.1 |  |  | n/a |
| Total intangible assets | $ | 987.8 |  |  | $ | (447.9) |  |  | $ | 539.9 |  |  |  |

[0001628280-23-002880:notes:128]
[same as prior period, unchanged from 0001628280-22-028783:notes:124]

[0001628280-23-002880:notes:129]
[same as prior period, unchanged from 0001628280-22-028783:notes:125]

[0001628280-23-002880:notes:130]
|  | Three Months Ended |  | Six Months Ended |
|  | December 31, 2022 |  | January 1, 2022 |  | December 31, 2022 |  | January 1, 2022 |
| Cost of sales | $ | 24.8 |  |  | $ | 15.9 |  |  | $ | 47.7 |  |  | $ | 31.7 |  |
| Selling, general and administrative | 11.3 |  |  | 5.6 |  |  | 20.6 |  |  | 11.2 |  |
| Total amortization of intangibles | $ | 36.1 |  |  | $ | 21.5 |  |  | $ | 68.3 |  |  | $ | 42.9 |  |

[0001628280-23-002880:notes:131]
Based on the carrying amount of our acquired developed technologies and customer relationships as of December 31, 2022, and assuming no future impairment of the underlying assets, the estimated future amortization is as follows (in millions):

[0001628280-23-002880:notes:132]
| Fiscal Years |  |
| Remainder of 2023 | $ | 57.5 |  |
| 2024 | 110.2 |  |
| 2025 | 97.3 |  |
| 2026 | 84.9 |  |
| 2027 | 73.0 |  |
| Thereafter | 39.9 |  |
| Total future amortization | $ | 462.8 |  |


## us-gaap:DebtDisclosureTextBlock

[0001628280-23-002880:notes:133]
Note 9. Debt

[0001628280-23-002880:notes:134]
Convertible Notes

[0001628280-23-002880:notes:135]
2028 Notes

[0001628280-23-002880:notes:136]
In March 2022, we issued $861.0 million in aggregate principal amount of 0.50% convertible notes due in 2028 (the “2028 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act of 1933, as amended (the “Securities Act”). The 2028 Notes are governed by an indenture between the Company and U.S. Bank Trust Company National Association (as successor in interest to U.S. Bank National Association), as a trustee (the “2028 Indenture”). The 2028 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001628280-23-002880:notes:137]
The net proceeds from the sale of the 2028 Notes was $854.8 million, after deducting $6.2 million in issuance costs. In addition, we incurred $0.7 million in professional fees in connection with this transaction. Concurrent with the issuance of the 2028 Notes, we used $200.0 million of the net proceeds to repurchase our common stock in privately negotiated transactions. We intend to use the remaining net proceeds for general corporate purposes, which may include capital expenditures and working capital.

[0001628280-23-002880:notes:138]
The 2028 Notes bear interest at a rate of 0.50% per year, payable semi-annually in arrears on June 15 and December 15 of each year, beginning on June 15, 2022. The 2028 Notes will mature on June 15, 2028, unless earlier redeemed, repurchased by us, or converted pursuant to their terms.

[0001628280-23-002880:notes:139]
The initial conversion rate is 7.6319 shares of common stock per $1,000 principal amount of the 2028 Notes (which is equivalent to an initial conversion price of approximately $131.03 per share). The conversion rate is subject to adjustment upon the occurrence of certain specified events, but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change (as defined in the 2028 Indenture) or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert the 2028 Notes in connection with such make-whole fundamental change or notice of redemption.

[0001628280-23-002880:notes:140]
Prior to the close of business on the business day immediately preceding March 15, 2028, holders of the 2028 Notes may convert their 2028 Notes only under the following circumstances:

[0001628280-23-002880:notes:141]
•during any fiscal quarter (and only during such fiscal quarter), if the last reported sale price of the Company’s common stock for at least 20 trading days (whether or not consecutive) during the 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price, or $170.34, on each applicable trading day;

[0001628280-23-002880:notes:142]
•during the five consecutive business day period after any five consecutive trading day period (the “measurement period”) in which the trading price per $1,000 principal amount of the 2028 Notes for each trading day of such measurement period was less than 98% of the product of the last reported sale price of the Company’s common stock and the applicable conversion rate on each such trading day;

[0001628280-23-002880:notes:143]
•if the Company calls any or all of the 2028 Notes for redemption, at any time prior to the close of business on the second business day immediately preceding the redemption date; or

[0001628280-23-002880:notes:144]
•upon the occurrence of specified corporate events, as specified in the 2028 Indentures.

[0001628280-23-002880:notes:145]
On or after March 15, 2028 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their 2028 Notes at any time. Upon conversion, we may satisfy our conversion obligation in cash, shares of common stock or a combination of cash and shares of common stock, at our election.

[0001628280-23-002880:notes:146]
We may redeem for cash all or any portion of the 2028 Notes, at our option (subject to the partial redemption limitation set forth in the 2028 Indenture), on or after June 20, 2025, if the last reported sale price of its common stock has been at least 130% of the conversion price then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading-day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which the Company provides notice of redemption at a redemption price equal to 100% of the principal amount of the 2028 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. No sinking fund is provided for the 2028 Notes. If we elect to redeem fewer than all of the outstanding 2028 Notes, at least $100.0 million aggregate principal amount of the 2028 Notes must be outstanding and not subject to redemption as of the redemption notice date. Upon the occurrence of a fundamental change (as defined in the 2028 Indenture), holders may require the Company to repurchase all or a portion of their 2028 Notes for cash at a price equal to 100% of the principal amount of the 2028 Notes to be repurchased, plus any accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

[0001628280-23-002880:notes:147]
We initially bifurcated the principal amount of the 2028 Notes into liability and equity components. The liability component of the 2028 Notes was initially valued at $629.8 million based on the contractual cash flow discounted at an appropriate comparable market on non-convertible debt borrowing rate at the date of issuance, which was 5.7%, with the equity component representing the residual amount of the proceeds of $231.2 million, which was recorded as a debt discount. Upon adoption of ASU 2020-06 in the first quarter of fiscal 2023, our 2028 Notes were accounted for as a single liability measured at amortized cost. Refer to “Note 2. Recently Issued Accounting Pronouncement” for the detailed adoption impact.

[0001628280-23-002880:notes:148]
2026 Notes

[0001628280-23-002880:notes:149]
In December 2019, we issued $1,050.0 million in aggregate principal amount of 0.50% convertible notes due in 2026 (the “2026 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act. The 2026 Notes are governed by an indenture between the Company and U.S. Bank Trust Company National Association (as successor in interest to U.S. Bank National Association, as a trustee (the “2026 Indenture”). We used approximately $196.0 million of the net proceeds of the offering to repay in full all amounts outstanding under our term loan credit facility, and a portion of the net proceeds of the offering to purchase approximately $200.0 million of our common stock concurrently with the pricing of the offering in privately negotiated transactions. The 2026 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001628280-23-002880:notes:150]
The 2026 Notes bear interest at a rate of 0.50% per year, payable semi-annually in arrears on June 15 and December 15 of each year, beginning on June 15, 2020. The 2026 Notes will mature on December 15, 2026, unless earlier redeemed, repurchased by us, or converted pursuant to their terms.

[0001628280-23-002880:notes:151]
The initial conversion rate is 10.0711 shares of common stock per $1,000 principal amount of the 2026 Notes (which is equivalent to an initial conversion price of approximately $99.29 per share). The conversion rate is subject to adjustment upon the occurrence of certain events specified in the 2026 Indenture but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change (as defined in the 2026 Indenture) or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares set forth in the 2026 Indenture or a holder that elects to convert the 2026 Notes in connection with such make-whole fundamental change or notice of redemption.

[0001628280-23-002880:notes:152]
Prior to the close of business on the business day immediately preceding September 15, 2026, holders of the 2026 Notes may convert their 2026 Notes only under the following circumstances:

[0001628280-23-002880:notes:153]
•during any fiscal quarter (and only during such fiscal quarter), if the last reported sale price of the common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price of the 2026 Notes, or $129.08 on each applicable trading day;

[0001628280-23-002880:notes:154]
•during the five consecutive business day period after any five consecutive trading day period (the "2026 measurement period") in which the trading price per $1,000 principal amount of the 2026 Notes for each trading day of the 2026 measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate for the 2026 Notes on each such trading day;

[0001628280-23-002880:notes:155]
•if we call any or all of the 2026 Notes for redemption, at any time prior to the close of business on the second business day immediately preceding the relevant redemption date; or

[0001628280-23-002880:notes:156]
•upon the occurrence of specified corporate events.

[0001628280-23-002880:notes:157]
On or after September 15, 2026 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their 2026 Notes at any time. Upon conversion, we may satisfy our conversion obligation in cash, shares of common stock or a combination of cash and shares of common stock, at our election.

[0001628280-23-002880:notes:158]
We may redeem for cash, all or any portion of the 2026 Notes, at our option, on or after December 20, 2023, if the last reported sale price of its common stock has been at least 130% of the conversion price then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading-day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which we provide a notice of redemption at a redemption price equal to 100% of the principal amount of the 2026 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. No sinking fund is provided for the 2026 Notes. Upon the occurrence of a fundamental change (as defined in the 2026 Indenture), holders may require us to repurchase all or a portion of the 2026 Notes for cash at a price equal to 100% of the principal amount of the 2026 Notes to be repurchased, plus any accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

[0001628280-23-002880:notes:159]
We initially bifurcated the principal amount of the 2026 Notes into liability and equity components. The liability component of the 2026 Notes was initially valued at $734.8 million based on the contractual cash flows discounted at an appropriate comparable market non-convertible debt borrowing rate at the date of issuance of 5.8% with the equity component representing the residual amount of the proceeds of $315.2 million, which was recorded as a debt discount. Upon adoption of ASU 2020-06 in the first quarter of fiscal 2023, our 2026 Notes were accounted for as a single liability measured at amortized cost.  Refer to “Note 2. Recently Issued Accounting Pronouncement” for the detailed adoption impact.

[0001628280-23-002880:notes:160]
2024 Notes

[0001628280-23-002880:notes:161]
In March 2017, we issued $450.0 million in aggregate principal amount 2024 Notes of 0.25% convertible notes due in 2024 (the “2024 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act. The 2024 Notes are governed by an indenture between the Company, as the issuer, and U.S. Bank Trust Company National Association (as successor in interest to U.S. Bank National Association), as trustee (the “2024 Indenture”). The 2024 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001628280-23-002880:notes:162]
The 2024 Notes bear interest at a rate of 0.25% per year. Interest on the 2024 Notes is payable semi-annually in arrears on March 15 and September 15 of each year, beginning on September 15, 2017. The 2024 Notes will mature on March 15, 2024, unless earlier repurchased by us or converted pursuant to their terms.

[0001628280-23-002880:notes:163]
The initial conversion rate of the 2024 Notes is 16.4965 shares of common stock per $1,000 principal amount of 2024 Notes, which is equivalent to an initial conversion price of approximately $60.62 per share. The conversion rate is subject to adjustment upon the occurrence of certain specified events but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change (as defined in the 2024 Indenture) or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert the 2024 Notes in connection with such make-whole fundamental change or notice of redemption.

[0001628280-23-002880:notes:164]
Prior to the close of business on the business day immediately preceding December 15, 2023, each holder of the 2024 Notes may convert their 2024 Notes only under the following circumstances:

[0001628280-23-002880:notes:165]
•during any fiscal quarter (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during the period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price, or $78.80 on each applicable trading day;

[0001628280-23-002880:notes:166]
•during the five consecutive business day period after any five consecutive trading day period (the “2024 measurement period”) in which the trading price per $1,000 principal amount of 2024 Notes for each trading day of such 2024 measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate for the 2024 Notes on each such trading day;

[0001628280-23-002880:notes:167]
On or after December 15, 2023 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their 2024 Notes at any time. In addition, upon the occurrence of a make-whole fundamental change (as defined in the 2024 Indenture), we will, in certain circumstances, increase the conversion rate by a number of additional shares set forth in the 2024 Indenture for a holder that elects to convert 2024 Notes in connection with such make-whole fundamental change.

[0001628280-23-002880:notes:168]
We may not redeem the 2024 Notes prior to their maturity date and no sinking fund is provided for the 2024 Notes. Upon the occurrence of a fundamental change (as defined in the 2024 Indenture), holders may require us to repurchase all or a portion of their 2024 Notes for cash at a price equal to 100% of the principal amount of the 2024 Notes to be repurchased, plus any accrued and unpaid interest.

[0001628280-23-002880:notes:169]
During the three and six months ended December 31, 2022 we received conversion requests of less than $0.1 million principal amount of the 2024 Notes, which we settled with cash in accordance with the 2024 Indenture. Since issuing the 2024 Notes, we have converted a total of approximately $1.9 million principal amount of the 2024 Notes. The remaining principal amount of the 2024 Notes as of December 31, 2022 was $448.1 million.

[0001628280-23-002880:notes:170]
We considered the features embedded in the 2024 Notes other than the conversion feature, including the holders’ put feature, our call feature, and the make-whole feature, and concluded that they are not required to be bifurcated and accounted for separately from the host debt instrument. Prior to the Tax Matters Agreement settlement condition (“TMA settlement condition”), because we could only settle the 2024 Notes in cash, we determined that the conversion feature met the definition of a derivative liability. We separated the derivative liability from the host debt instrument based on the fair value of the derivative liability. During fiscal 2017, we satisfied the TMA settlement condition. As such, the value of the conversion option is no longer marked-to-market and was reclassified to additional paid-in capital within stockholders’ equity on our condensed consolidated balance sheets. The adoption of ASU 2020-06 did not change the presentation of the 2024 Notes, as the conversion feature associated with the 2024 Notes continues to be classified within stockholders’ equity.

[0001628280-23-002880:notes:171]
Convertible Notes - Additional Disclosures

[0001628280-23-002880:notes:172]
Our convertible notes consisted of the following components as of the periods presented (in millions):

[0001628280-23-002880:notes:173]
| Liability component: | December 31, 2022 |  | July 2, 2022 |
|  | 2024 Notes (1) |  | 2026 Notes (2) |  | 2028 Notes (3) |  | 2024 Notes (1) |  | 2026 Notes (2) |  | 2028 Notes (3) |
| Principal | $ | 448.1 |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |  | $ | 448.1 |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |
| Unamortized debt discount and issuance costs | (27.4) |  |  | (4.7) |  |  | (6.0) |  |  | (38.2) |  |  | (218.6) |  |  | (226.3) |  |
| Net carrying amount of the liability component | $ | 420.7 |  |  | $ | 1,045.3 |  |  | $ | 855.0 |  |  | $ | 409.9 |  |  | $ | 831.4 |  |  | $ | 634.7 |  |

[0001628280-23-002880:notes:174]
(1) If the closing price of our stock exceeds $78.80 (or 130% of the conversion price of $60.62) for 20 of the last 30 trading days of any future fiscal quarter, our 2024 Notes would become convertible at the option of the holders during the next fiscal quarter. During the fourth quarter of fiscal 2022, the 2024 Notes were convertible at the option of the holders and therefore, the debt component of our 2024 Notes was classified as current liabilities in our condensed consolidated balance sheet. Although the 2024 Notes will not be convertible during the third quarter of fiscal 2023 due to our stock price not exceeding $78.80 for 20 of the last 30 trading days of the quarter ended December 31, 2022, we continue to classify the 2024 Notes in current liabilities, as holders may convert their 2024 Notes at any time on or after December 15, 2023 until the close of business on the second scheduled trading day immediately preceding the maturity date.

[0001628280-23-002880:notes:175]
(2) If the closing price of our stock exceeds $129.08 (or 130% of the conversion price of $99.29) for 20 of the last 30 trading days of any future fiscal quarter, our 2026 Notes would become convertible at the option of the holders during the subsequent fiscal quarter and the debt would be reclassified to current liabilities in our condensed consolidated balance sheet.

[0001628280-23-002880:notes:176]
(3) If the closing price of our stock exceeds $170.34 (or 130% of the conversion price of $131.03) for 20 of the last 30 trading days of any future fiscal quarter, our 2028 Notes would become convertible at the option of the holders during the subsequent fiscal quarter and the debt would be reclassified to current liabilities in our condensed consolidated balance sheet.

[0001628280-23-002880:notes:177]
The following table sets forth interest expense information related to the convertible notes for the periods presented (in millions):

[0001628280-23-002880:notes:178]
|  | Three Months Ended |  | Six Months Ended |
|  | December 31, 2022 |  | January 1, 2022 |  | December 31, 2022 |  | January 1, 2022 |
| Contractual interest expense | $ | 2.7 |  |  | $ | 1.6 |  |  | $ | 5.4 |  |  | $ | 3.2 |  |
| Amortization of the debt discount and debt issuance costs | 6.2 |  |  | 15.5 |  |  | 11.9 |  |  | 30.8 |  |
| Total interest expense | $ | 8.9 |  |  | $ | 17.1 |  |  | $ | 17.3 |  |  | $ | 34.0 |  |

[0001628280-23-002880:notes:179]
The future interest and principal payments related to our convertible notes are as follows as of December 31, 2022 (in millions):

[0001628280-23-002880:notes:180]
| Fiscal Years | 2024 Notes |  | 2026 Notes |  | 2028 Notes |  | Total |
| Remainder of 2023 | $ | 0.6 |  |  | $ | 2.6 |  |  | $ | 2.2 |  |  | $ | 5.4 |  |
| 2024 | 449.2 |  |  | 5.3 |  |  | 4.3 |  |  | 458.8 |  |
| 2025 | — |  |  | 5.3 |  |  | 4.3 |  |  | 9.6 |  |
| 2026 | — |  |  | 5.3 |  |  | 4.3 |  |  | 9.6 |  |
| 2027 and thereafter | — |  |  | 1,052.4 |  |  | 869.6 |  |  | 1,922.0 |  |
| Total convertible notes payments | $ | 449.8 |  |  | $ | 1,070.9 |  |  | $ | 884.7 |  |  | $ | 2,405.4 |  |

[0001628280-23-002880:notes:181]
The principal balances of our convertible notes are reflected in the payment periods in the table above based on their respective contractual maturities.

[0001628280-23-002880:notes:182]
Mitsubishi Bank Loans

[0001628280-23-002880:notes:183]
In connection with our merger of NeoPhotonics, we assumed several loan agreements with MUFG Bank, Ltd. (the “Mitsubishi Bank Loans”) for an aggregate fair value of approximately $5.9 million, approximately $0.9 million of which was paid in the fiscal first quarter of 2023.  In October 2022, we fully paid the remaining outstanding amount of the Mitsubishi Bank Loans of approximately $5.0 million. We recorded $0.1 million of interest expense related to the Mitsubishi Bank Loans for both the three and six months ended December 31, 2022.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001628280-23-002880:notes:184]
[same as prior period, unchanged from 0001628280-22-028783:notes:187]

[0001628280-23-002880:notes:185]
[same as prior period, unchanged from 0001628280-22-028783:notes:188]

[0001628280-23-002880:notes:186]
[same as prior period, unchanged from 0001628280-22-028783:notes:189]

[0001628280-23-002880:notes:187]
|  | Foreign currency translation adjustments, net of tax (1) |  | Defined benefit obligations, net of tax (2) |  | Unrealized gain (loss) on available-for-sale securities, net of tax |  |  |  | Total |
| Beginning balance as of July 2, 2022 | $ | 9.7 |  |  | $ | 1.0 |  |  | $ | (10.3) |  |  |  |  | $ | 0.4 |  |
| Other comprehensive loss | — |  |  | — |  |  | (0.6) |  |  |  |  | (0.6) |  |
| Ending balance as of October 1, 2022 | 9.7 |  |  | 1.0 |  |  | (10.9) |  |  |  |  | (0.2) |  |
| Other comprehensive gain | — |  |  | — |  |  | 3.6 |  |  |  |  | 3.6 |  |
| Ending balance as of December 31, 2022 | $ | 9.7 |  |  | $ | 1.0 |  |  | $ | (7.3) |  |  |  |  | $ | 3.4 |  |
|  | Foreign currency translation adjustments, net of tax (1) |  | Defined benefit obligations, net of tax (2) |  | Unrealized gain (loss) on available-for-sale securities, net of tax |  |  |  | Total |
| Beginning balance as of July 3, 2021 | $ | 9.7 |  |  | $ | (1.4) |  |  | $ | (0.1) |  |  |  |  | $ | 8.2 |  |
| Other comprehensive income | — |  |  | — |  |  | 0.3 |  |  |  |  | 0.3 |  |
| Ending balance as of October 2, 2021 | 9.7 |  |  | (1.4) |  |  | 0.2 |  |  |  |  | 8.5 |  |
| Other comprehensive loss | — |  |  | — |  |  | (2.3) |  |  |  |  | (2.3) |  |
| Ending balance as of January 1, 2022 | $ | 9.7 |  |  | $ | (1.4) |  |  | $ | (2.1) |  |  |  |  | $ | 6.2 |  |

[0001628280-23-002880:notes:188]
[same as prior period, unchanged from 0001628280-22-028783:notes:191]

[0001628280-23-002880:notes:189]
[same as prior period, unchanged from 0001628280-22-028783:notes:192]


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001628280-23-002880:notes:190]
[same as prior period, unchanged from 0001628280-22-028783:notes:193]

[0001628280-23-002880:notes:191]
We have initiated various strategic restructuring actions primarily to reduce costs, consolidate our operations, rationalize the manufacturing of our products and align our business in response to market conditions and as a result of our acquisitions in the first quarter of fiscal 2023.

[0001628280-23-002880:notes:192]
[same as prior period, unchanged from 0001628280-22-028783:notes:195]

[0001628280-23-002880:notes:193]
|  | Three Months Ended |  | Six Months Ended |
|  | December 31, 2022 |  | January 1, 2022 |  | December 31, 2022 |  | January 1, 2022 |
| Balance as of beginning of period | $ | 3.1 |  |  | $ | 0.8 |  |  | $ | — |  |  | $ | 5.7 |  |
| Charges (reversals), net | 13.9 |  |  | 0.1 |  |  | 23.2 |  |  | (1.0) |  |
| Payments | (2.9) |  |  | (0.6) |  |  | (9.1) |  |  | (4.4) |  |
| Balance as of end of period | $ | 14.1 |  |  | $ | 0.3 |  |  | $ | 14.1 |  |  | $ | 0.3 |  |

[0001628280-23-002880:notes:194]
During the three months ended December 31, 2022, we recorded restructuring and related charges of $13.9 million in our condensed consolidated statements of operations, which was primarily due to company-wide integration efforts as a result of the merger with NeoPhotonics, as well as our cost reduction initiatives.

[0001628280-23-002880:notes:195]
During the six months ended December 31, 2022, we recorded restructuring and related charges of $23.2 million in our condensed consolidated statements of operations, which was primarily attributable to company-wide integration efforts as a result of the merger with NeoPhotonics, our cost reduction initiatives, as well as severance and employee-related benefits associated with NeoPhotonics’ executive severance and retention agreements. These agreements provide for payments and benefits upon an involuntary termination of employment under certain circumstances.

[0001628280-23-002880:notes:196]
We made $2.9 million and $9.1 million of restructuring payments during the three and six months ended December 31, 2022, respectively. In addition, we recorded $1.5 million of incremental stock-based compensation during the three months ended December 31, 2022 in connection with our restructuring activities during the period.

[0001628280-23-002880:notes:197]
During the three and six months ended January 1, 2022, we recorded a net reversal to our restructuring and related charges of $1.0 million in our condensed consolidated statements of operations, which was attributable to lower than anticipated employee severance charges primarily as a result of retaining and re-assigning certain employees.

[0001628280-23-002880:notes:198]
[same as prior period, unchanged from 0001628280-22-028783:notes:199]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-23-002880:notes:199]
[same as prior period, unchanged from 0001628280-22-028783:notes:200]

[0001628280-23-002880:notes:200]
[same as prior period, unchanged from 0001628280-22-028783:notes:201]

[0001628280-23-002880:notes:201]
We recorded a tax provision of $4.6 million and $23.8 million for the three and six months ended December 31, 2022, respectively. Our tax provision for the three months ended December 31, 2022 includes a discrete tax expense of $4.0 million, primarily related to the U.S. return to provision differences for transaction costs, currency re-measurements, and shortfall in connection with stock-based compensation vested during the quarter. Our estimated effective tax rate for fiscal 2023 also differs from the 21% U.S. statutory rate primarily due to the income tax expense from the tax effect of Global Intangible Low-Taxed Income (“GILTI”), net of benefit for foreign tax credits, subpart F inclusion and non-deductible stock-based compensation, partially offset by the income tax benefit from U.S. federal R&D tax credits.

[0001628280-23-002880:notes:202]
As of December 31, 2022, we had $52.1 million of unrecognized tax benefits, which, if recognized, would affect the effective tax rate. We are subject to examination of income tax returns by various domestic and foreign tax authorities. The timing of resolution and closure of these tax examinations is highly unpredictable. Although it is possible that certain ongoing tax examinations may be concluded within the next 12 months, we cannot reasonably estimate the impact to tax expense and net income from tax exams that could be resolved or closed within the next 12 months. Subject to audit timing and uncertainty, we expect the amount of unrecognized tax benefit that would become recognized due to expiration of the statute of limitations and affect the effective tax rate to decrease by $12.0 million over the next 12 months.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001628280-23-002880:notes:203]
[same as prior period, unchanged from 0001628280-22-028783:notes:204]

[0001628280-23-002880:notes:204]
[same as prior period, unchanged from 0001628280-22-028783:notes:205]

[0001628280-23-002880:notes:205]
[same as prior period, unchanged from 0001628280-22-028783:notes:206]

[0001628280-23-002880:notes:206]
On November 16, 2022, our stockholders approved amendments to the Amended and Restated Equity Incentive Plan (the “2015 Plan”) to (i) increase the number of shares of common stock reserved for issuance by an additional 0.9 million shares and (ii) to make certain other changes to reflect good corporate governance practices.

[0001628280-23-002880:notes:207]
As of December 31, 2022, we had 3.8 million shares subject to restricted stock units, restricted stock awards, and performance stock units issued and outstanding under the 2015 Plan. These grants are performance-based, time-based or a combination of both and are expected to vest over one to four years. The fair value of these grants is based on the closing market price of our common stock on the date of grant. As of December 31, 2022, 2.8 million shares of common stock under the 2015 Plan were available for grant.

[0001628280-23-002880:notes:208]
[same as prior period, unchanged from 0001628280-22-028783:notes:208]

[0001628280-23-002880:notes:209]
In connection with the merger with NeoPhotonics, we issued equity awards to certain NeoPhotonics employees, consisting of restricted stock units (the “Replacement Awards”) in exchange for their NeoPhotonics equity awards. The terms of these Replacement Awards are substantially similar to the original NeoPhotonics equity awards. The Replacement Awards consisted of 0.4 million restricted stock units with a grant date fair value of $93.4 per share, which represents our closing stock price on the Closing date. The total fair value of these Replacement Awards is $40.2 million, $3.5 million of which is attributable to employee services rendered through August 3, 2022, the merger Closing date, and was recognized as a component of the merger consideration and stock-based compensation in the consolidated statements of stockholders’ equity. The remaining fair value of the Replacement Awards is recorded as stock-based compensation over the remaining vesting period. Refer to “Note 4. Business Combinations.”

[0001628280-23-002880:notes:210]
[same as prior period, unchanged from 0001628280-22-028783:notes:210]

[0001628280-23-002880:notes:211]
[same as prior period, unchanged from 0001628280-22-028783:notes:211]

[0001628280-23-002880:notes:212]
During the six months ended December 31, 2022, our board of directors approved grants of 1.6 million RSUs which primarily vest over three years. In addition, we issued 0.4 million RSUs that were issued as part of the Replacement Awards in connection with the merger with NeoPhotonics as described above.

[0001628280-23-002880:notes:213]
[same as prior period, unchanged from 0001628280-22-028783:notes:213]

[0001628280-23-002880:notes:214]
[same as prior period, unchanged from 0001628280-22-028783:notes:214]

[0001628280-23-002880:notes:215]
During the six months ended December 31, 2022, 0.3 million PSUs were issued to executive and certain non-executive employees as part of our revised Annual Incentive Plan. These PSUs have an aggregate grant date fair value of $26.0 million and are subject to performance targets and service conditions, and vest over a one-year period. The board of directors also approved a grant of 0.2 million PSUs with an aggregate grant date fair value of $22.6 million to certain executive officers and senior management. These PSUs will vest subject to the achievement of revenue targets and certain non-financial performance measurement, as well as service conditions, over three years.

[0001628280-23-002880:notes:216]
[same as prior period, unchanged from 0001628280-22-028783:notes:216]

[0001628280-23-002880:notes:217]
Our 2015 Employee Stock Purchase Plan (the “2015 Purchase Plan”) provides eligible employees with the opportunity to acquire an ownership interest in the Company through periodic payroll deductions and provides a 15% purchase price discount as well as a 6-month look-back period. The 2015 Purchase Plan is structured as a qualified employee stock purchase plan under Section 423 of the Internal Revenue Code of 1986, as amended. The 2015 Purchase Plan will terminate upon the date on which all shares available for issuance have been sold. Of the 3.0 million shares authorized under the 2015 Purchase Plan, 1.3 million shares remained available for issuance as of December 31, 2022.

[0001628280-23-002880:notes:218]
[same as prior period, unchanged from 0001628280-22-028783:notes:218]

[0001628280-23-002880:notes:219]
[same as prior period, unchanged from 0001628280-22-028783:notes:219]

[0001628280-23-002880:notes:220]
|  | Three Months Ended |  | Six Months Ended |
|  | December 31, 2022 |  | January 1, 2022 |  | December 31, 2022 |  | January 1, 2022 |
| Cost of sales | $ | 6.7 |  |  | $ | 5.2 |  |  | $ | 12.2 |  |  | $ | 9.8 |  |
| Research and development | 10.6 |  |  | 5.4 |  |  | 20.2 |  |  | 10.4 |  |
| Selling, general and administrative | 19.3 |  |  | 16.7 |  |  | 50.8 |  |  | 31.9 |  |
| Total stock-based compensation | $ | 36.6 |  |  | $ | 27.3 |  |  | $ | 83.2 |  |  | $ | 52.1 |  |

[0001628280-23-002880:notes:221]
In connection with the NeoPhotonics merger, we issued replacement equity awards (the “Replacement Awards”) in settlement of certain NeoPhotonics equity awards at the merger Closing date, with the total fair value of $40.2 million based on our closing stock price on the Closing date. The portion of Replacement Awards attributed to pre-merger service is $3.5 million, which was accounted for as part of the consideration transferred and was recorded under stock-based compensation in our consolidated statements of stockholders’ equity as of December 31, 2022.  Additionally, certain equity awards for NeoPhotonics employees were accelerated. The total stock-based compensation associated with the acceleration was $11.9 million, of which $9.0 million was settled in cash. We recorded the $11.9 million for the accelerated awards in our consolidated statements of operations during the first quarter of fiscal year 2023.  Refer to “Note 4. Business Combinations.”

[0001628280-23-002880:notes:222]
Included in stock-based compensation for the three and six months ended December 31, 2022, is $6.2 million and $15.0 million of stock-based compensation costs related to PSUs, respectively. The amount of stock-based compensation expense recognized in any one period related to PSUs can vary based on the achievement or anticipated achievement of the performance conditions. If the performance conditions are not met or not expected to be met, no compensation cost would be recognized on the underlying PSUs, and any previously recognized compensation expense related to those PSUs would be reversed.

[0001628280-23-002880:notes:223]
During the three months ended December 31, 2022, we recorded $1.5 million of stock-based compensation in connection with our restructuring activities during the period. Refer to “Note 11. Restructuring and Related Charges”.

[0001628280-23-002880:notes:224]
[same as prior period, unchanged from 0001628280-22-028783:notes:223]

[0001628280-23-002880:notes:225]
|  | Three Months Ended |  | Six Months Ended |
|  | December 31, 2022 |  | January 1, 2022 |  | December 31, 2022 |  | January 1, 2022 |
| Income tax benefit associated with stock-based compensation | $ | 6.4 |  |  | $ | 4.2 |  |  | $ | 11.5 |  |  | $ | 8.2 |  |

[0001628280-23-002880:notes:226]
Approximately $14.1 million and $6.4 million of stock-based compensation was capitalized to inventory as of December 31, 2022 and July 2, 2022, respectively.

[0001628280-23-002880:notes:227]
As of December 31, 2022, $224.7 million of stock-based compensation cost related to RSU awards remains to be amortized. That RSU cost is expected to be recognized over an estimated amortization period of 2.1 years.

[0001628280-23-002880:notes:228]
[same as prior period, unchanged from 0001628280-22-028783:notes:227]

[0001628280-23-002880:notes:229]
The following table summarizes our award activity for the three and six months ended December 31, 2022 (in millions, except per share amounts):

[0001628280-23-002880:notes:230]
|  |  |  |  |  | Restricted Stock Units |  | Performance Stock Units |
|  |  |  |  |  |  |  |  |  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |
| Balance as of July 2, 2022 |  |  |  |  |  |  |  |  | 2.0 |  |  | $ | 85.9 |  |  | 0.3 |  |  | $ | 81.9 |  |
| Replacement Awards Issued |  |  |  |  |  |  |  |  | 0.4 |  |  | 93.4 |  |  | — |  |  | — |  |
| Granted |  |  |  |  |  |  |  |  | 1.6 |  |  | 86.9 |  |  | 0.6 |  |  | 88.2 |  |
| Vested |  |  |  |  |  |  |  |  | (0.7) |  |  | 83.9 |  |  | (0.1) |  |  | 70.5 |  |
| Canceled |  |  |  |  |  |  |  |  | (0.2) |  |  | 88.1 |  |  | (0.1) |  |  | 88.6 |  |
| Balance as of December 31, 2022 |  |  |  |  |  |  |  |  | 3.1 |  |  | $ | 87.8 |  |  | 0.7 |  |  | $ | 89.3 |  |

[0001628280-23-002880:notes:231]
[same as prior period, unchanged from 0001628280-22-028783:notes:230]

[0001628280-23-002880:notes:232]
|  | Awards Available for Grant |
| Balance as of July 2, 2022 | 3.8 |  |
| Assumed in connection with NeoPhotonics merger | 0.4 |  |
| Replacement Awards | (0.4) |  |
| Authorized | 0.9 |  |
| Granted | (2.2) |  |
| Canceled | 0.3 |  |
| Balance as of December 31, 2022 | 2.8 |  |

[0001628280-23-002880:notes:233]
[same as prior period, unchanged from 0001628280-22-028783:notes:232]

[0001628280-23-002880:notes:234]
The 2015 Purchase Plan expense for the three and six months ended December 31, 2022 was $0.8 million and $2.0 million, respectively. The 2015 Purchase Plan expense for the three and six months ended January 1, 2022 was $0.9 million and $2.1 million, respectively. The expense related to the 2015 Purchase Plan is recorded on a straight-line basis over the relevant subscription period.

[0001628280-23-002880:notes:235]
During the six months ended December 31, 2022, there were 0.1 million shares issued to employees through the 2015 Purchase Plan. During the six months ended January 1, 2022, there were 0.1 million shares issued to employees through the 2015 Purchase Plan.

[0001628280-23-002880:notes:236]
[same as prior period, unchanged from 0001628280-22-028783:notes:234]

[0001628280-23-002880:notes:237]
On May 7, 2021, our board of directors approved the 2021 share buyback program, which authorizes us to utilize up to $700.0 million to purchase our own shares of common stock. On March 3, 2022, our board of directors approved an increase in our share buyback program, which authorizes us to utilize up to an aggregate amount of $1.0 billion (an increase from $700.0 million) to purchase our own shares of common stock through May 2024, but may be suspended or terminated by the board of directors at any time.

[0001628280-23-002880:notes:238]
During the six months ended December 31, 2022, we repurchased 0.3 million shares of our common stock at an average price of $89.80 per share for an aggregate purchase price of $25.7 million.

[0001628280-23-002880:notes:239]
Since the board of directors approved the share buyback program, we have repurchased 7.4 million shares in aggregate at an average price of $83.38 per share for a total purchase price of $615.5 million. We recorded the $615.5 million aggregate purchase price as a reduction of retained earnings within our condensed consolidated balance sheet. All repurchased shares were retired immediately. 
The price, timing, amount, and method of future repurchases will be determined based on the valuation of market conditions and other factors, at prices determined to be attractive and in the best interests of both the Company and our stockholders.


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0001628280-23-002880:notes:240]
Note 14. Commitments and Contingencies

[0001628280-23-002880:notes:241]
Purchase Obligations

[0001628280-23-002880:notes:242]
Purchase obligations of $391.5 million as of December 31, 2022, represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. In addition, we assumed certain purchase orders in connection with our merger with NeoPhotonics for the purchase of inventory and other items in the ordinary course of its business.  Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule and adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

[0001628280-23-002880:notes:243]
We depend on a limited number of contract manufacturers, subcontractors and suppliers for raw materials, packages and standard components. We generally purchase these single or limited source products through standard purchase orders or one-year supply agreements and have no significant long-term guaranteed supply agreements with such vendors. While we seek to maintain a sufficient safety stock of such products and maintain on-going communications with our suppliers to guard against interruptions or cessation of supply, our business and results of operations could be adversely affected by a stoppage or delay of supply, substitution of more expensive or less reliable products, receipt of defective parts or contaminated materials, increases in the price of such supplies, or our inability to obtain reduced pricing from our suppliers in response to competitive pressures.

[0001628280-23-002880:notes:244]
Product Warranties

[0001628280-23-002880:notes:245]
We provide reserves for the estimated costs of product warranties at the time revenue is recognized. We typically offer a twelve month warranty for most of our products. However, in some instances depending upon the product, product components or application of our products by the end customer, our warranties can vary and generally range from six months to five years. We estimate the costs of our warranty obligations on an annualized basis based on our historical experience of known product failure rates, use of materials to repair or replace defective products and service delivery costs incurred in correcting product failures. In addition, from time to time, specific warranty accruals may be made if unforeseen technical problems arise with specific products. We assess the adequacy of our recorded warranty liabilities and adjust the amounts as necessary.

[0001628280-23-002880:notes:246]
The following table presents the changes in our warranty reserve for the periods presented (in millions):

[0001628280-23-002880:notes:247]
|  | Three Months Ended |  | Six Months Ended |
|  | December 31, 2022 |  | January 1, 2022 |  | December 31, 2022 |  | January 1, 2022 |
| Balance as of beginning of period | $ | 10.1 |  |  | $ | 5.1 |  |  | $ | 10.0 |  |  | $ | 5.0 |  |
| Warranties assumed in NeoPhotonics merger | — |  |  | — |  |  | 0.7 |  |  | — |  |
| Provision for warranty | 2.8 |  |  | 3.8 |  |  | 4.3 |  |  | 5.5 |  |
| Utilization of reserve | (4.5) |  |  | (0.3) |  |  | (6.6) |  |  | (1.9) |  |
| Balance as of end of period | $ | 8.4 |  |  | $ | 8.6 |  |  | $ | 8.4 |  |  | $ | 8.6 |  |

[0001628280-23-002880:notes:248]
Environmental Liabilities

[0001628280-23-002880:notes:249]
Our research and development, manufacturing and distribution operations involve the use of hazardous substances and are regulated under international, federal, state and local laws governing health and safety and the environment. We apply strict standards for protection of the environment and occupational health and safety to sites inside and outside the United States, even if not subject to regulations imposed by foreign governments. We believe that our properties and operations at our facilities comply in all material respects with applicable environmental laws and occupational health and safety laws. However, the risk of environmental liabilities cannot be completely eliminated and there can be no assurance that the application of environmental and health and safety laws will not require us to incur significant expenditures. We are also regulated under a number of international, federal, state and local laws regarding recycling, product packaging and product content requirements. The environmental, product content/disposal and recycling laws are gradually becoming more stringent and may cause us to incur significant expenditures in the future.

[0001628280-23-002880:notes:250]
Legal Proceedings

[0001628280-23-002880:notes:251]
We are subject to a variety of claims and suits that arise from time to time in the ordinary course of our business. While management currently believes that resolving claims against us, individually or in the aggregate, will not have a material adverse impact on our financial position, results of operations or statements of cash flows, these matters are subject to inherent uncertainties and management’s view of these matters may change in the future. We accrue for loss contingencies when it is both probable that we will incur the loss and when we can reasonably estimate the amount of the loss or range of loss.  We have recorded $7.8 million with respect to the settlement of certain non-ordinary course litigation matters under accrued expenses in our condensed consolidated balance sheet as of December 31, 2022.

[0001628280-23-002880:notes:252]
Oclaro Merger Litigation

[0001628280-23-002880:notes:253]
In connection with our acquisition of Oclaro in 2018, seven lawsuits were filed by purported stockholders of Oclaro challenging the proposed merger (the “Merger”). All but one was voluntarily dismissed after the Oclaro Merger closed.  The remaining lawsuit, SaiSravan B. Karri v. Oclaro, Inc., et al., No. 3:18-cv-03435-JD (the “Karri Lawsuit”), was filed in the United States District Court for the Northern District of California and is styled as a class action.

[0001628280-23-002880:notes:254]
The Karri Lawsuit alleges, among other things, that Oclaro and its directors violated Section 14(a) of the Securities Exchange Act of 1934, as amended (the “Exchange Act”), and Rule 14a-9 promulgated thereunder by disseminating an incomplete and misleading Form S-4, including proxy statement/prospectus. The Karri Lawsuit further alleged that Oclaro’s directors violated Section 20(a) of the Exchange Act by failing to exercise proper control over the person(s) who violated Section 14(a) of the Exchange Act. The plaintiff in the Karri Lawsuit seeks, among other things, damages to be awarded to the plaintiff and any class, if a class is certified, and litigation costs, including attorneys’ fees.

[0001628280-23-002880:notes:255]
After the plaintiff in the Karri Lawsuit was appointed as lead plaintiff and his counsel as lead counsel, the plaintiff filed a first amended complaint on April 15, 2019.  The first amended complaint, also named Lumentum as a defendant but Lumentum has since been dismissed from the action.  On October 8, 2020, the court granted in part and denied in part the defendant’s motion to dismiss the first amended complaint. On December 1, 2020, defendants answered the first amended complaint. On September 17, 2021, lead plaintiff filed a second amended complaint. Defendants moved to stay discovery in light of the second amended complaint. On January 11, 2022 the Court struck the second amended complaint as untimely, terminated defendants’ motions to dismiss as moot, and lifted the stay. The case proceeded through fact and expert discovery.

[0001628280-23-002880:notes:256]
On August 16, 2022, Plaintiff moved for class certification and to be appointed class representative.  Defendants opposed the motion. The action subsequently was stayed while the parties participated in a mediation.  On January 18, 2023, the plaintiff filed a Notice of Settlement informing the court of an agreement in principle between the parties for a class-wide settlement of the Karri Lawsuit.  On January 24, 2023, in light of the potential settlement, the court vacated all pretrial and trial dates and ordered the plaintiff to file a motion for preliminary approval of the settlement by March 17, 2023. In the event that the settlement does not go forward for any reason, Defendants intend to continue to defend the Karri Lawsuit vigorously.

[0001628280-23-002880:notes:257]
NeoPhotonics Merger Litigation

[0001628280-23-002880:notes:258]
In connection with our planned acquisition of NeoPhotonics Corporation (“NeoPhotonics”) announced in November 2021, ten lawsuits (the “NeoPhotonics Lawsuits”) were filed by purported stockholders of NeoPhotonics challenging the proposed merger (the “NeoPhotonics Merger”). All of the NeoPhotonics Lawsuits have been dismissed.

[0001628280-23-002880:notes:259]
Indemnifications

[0001628280-23-002880:notes:260]
In the normal course of business, we enter into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown because claims may be made against us in the future, and we may record charges in the future as a result of these indemnification obligations. As of December 31, 2022, we did not have any material indemnification claims that were probable or reasonably possible.

[0001628280-23-002880:notes:261]
Audit Proceedings

[0001628280-23-002880:notes:262]
We are under audit by various domestic and foreign tax authorities with regards to income tax and indirect tax matters. In some, although not all cases, we have reserved for potential adjustments to our provision for income taxes and accrual of indirect taxes that may result from examinations by these tax authorities or final outcomes in judicial proceedings, and we believe that the final outcome of these examinations, agreements or judicial proceedings will not have a material effect on our results of operations. If events occur which indicate payment of these amounts is unnecessary, the reversal of the liabilities would result in the recognition of benefits in the period we determine the liabilities are no longer necessary. If our estimates of the federal, state, and foreign income tax liabilities and indirect tax liabilities are less than the ultimate assessment, it could result in a further charge to expense.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001628280-23-002880:notes:263]
[same as prior period, unchanged from 0001628280-22-028783:notes:263]

[0001628280-23-002880:notes:264]
[same as prior period, unchanged from 0001628280-22-028783:notes:264]

[0001628280-23-002880:notes:265]
We are an industry leading provider of optical and photonic products defined by revenue and market share addressing a range of end-market applications including optical communications and commercial lasers. We have two operating segments, Optical Communications, which we refer to as OpComms, and Commercial Lasers, which we refer to as Lasers. Our OpComms products address the following markets: telecommunications and data communications (“Telecom and Datacom”), and consumer and industrial (“Consumer and Industrial”), and include product lines from the recent merger of NeoPhotonics and the acquisition of IPG product lines. The two operating segments were primarily determined based on how the CODM views and evaluates our operations. The CODM regularly reviews operating results to make decisions about resources to be allocated to the segments and to assess their performance. Other factors, including market separation and customer specific applications, go-to-market channels, products and manufacturing, are considered in determining the formation of these operating segments.

[0001628280-23-002880:notes:266]
[same as prior period, unchanged from 0001628280-22-028783:notes:266]

[0001628280-23-002880:notes:267]
[same as prior period, unchanged from 0001628280-22-028783:notes:267]

[0001628280-23-002880:notes:268]
[same as prior period, unchanged from 0001628280-22-028783:notes:268]

[0001628280-23-002880:notes:269]
[same as prior period, unchanged from 0001628280-22-028783:notes:269]

[0001628280-23-002880:notes:270]
[same as prior period, unchanged from 0001628280-22-028783:notes:270]

[0001628280-23-002880:notes:271]
[same as prior period, unchanged from 0001628280-22-028783:notes:271]

[0001628280-23-002880:notes:272]
[same as prior period, unchanged from 0001628280-22-028783:notes:272]

[0001628280-23-002880:notes:273]
[same as prior period, unchanged from 0001628280-22-028783:notes:273]

[0001628280-23-002880:notes:274]
[same as prior period, unchanged from 0001628280-22-028783:notes:274]

[0001628280-23-002880:notes:275]
[same as prior period, unchanged from 0001628280-22-028783:notes:275]

[0001628280-23-002880:notes:276]
|  | Three Months Ended |  | Six Months Ended |
|  | December 31, 2022 |  | January 1, 2022 |  | December 31, 2022 |  | January 1, 2022 |
| Net revenue: |  |  |  |  |  |  |  |
| OpComms | $ | 448.8 |  |  | $ | 397.4 |  |  | $ | 902.2 |  |  | $ | 803.4 |  |
| Lasers | 57.2 |  |  | 49.3 |  |  | 110.6 |  |  | 91.7 |  |
| Net revenue | $ | 506.0 |  |  | $ | 446.7 |  |  | $ | 1,012.8 |  |  | $ | 895.1 |  |
| Gross profit: |  |  |  |  |  |  |  |
| OpComms | $ | 197.0 |  |  | $ | 201.8 |  |  | $ | 413.0 |  |  | $ | 427.7 |  |
| Lasers | 30.0 |  |  | 26.2 |  |  | 58.1 |  |  | 47.0 |  |
| Total segment gross profit | 227.0 |  |  | 228.0 |  |  | 471.1 |  |  | 474.7 |  |
| Unallocated corporate items: |  |  |  |  |  |  |  |
| Stock-based compensation | (6.7) |  |  | (5.2) |  |  | (12.2) |  |  | (9.8) |  |
| Amortization of acquired intangibles | (24.8) |  |  | (15.9) |  |  | (47.7) |  |  | (31.7) |  |
| Amortization of acquired inventory fair value adjustments | (9.6) |  |  | — |  |  | (14.2) |  |  | — |  |
| Inventory and fixed asset write down due to product line exits | — |  |  | (0.1) |  |  | — |  |  | (0.1) |  |
| Integration related costs | (2.8) |  |  | — |  |  | (2.8) |  |  | — |  |
| Other (charges) gains, net (1) | (16.9) |  |  | 0.7 |  |  | (26.8) |  |  | 6.6 |  |
| Gross profit | $ | 166.2 |  |  | $ | 207.5 |  |  | $ | 367.4 |  |  | $ | 439.7 |  |

[0001628280-23-002880:notes:277]
(1)   Other (charges) gains of unallocated corporate items for  the three and six months ended December 31, 2022 primarily relate to $11.7 million and $19.0 million of charges to acquire components from various brokers to satisfy customer demand.

[0001628280-23-002880:notes:278]
Other (charges) gains of unallocated corporate items for the six months ended January 1, 2022 primarily relate to $5.9 million of gain as a result of selling equipment that was no longer needed after we transferred certain product lines to new production facilities in fiscal 2021.

[0001628280-23-002880:notes:279]
[same as prior period, unchanged from 0001628280-22-028783:notes:279]

[0001628280-23-002880:notes:280]
[same as prior period, unchanged from 0001628280-22-028783:notes:280]

[0001628280-23-002880:notes:281]
|  | Three Months Ended |  | Six Months Ended |
|  | December 31, 2022 |  | January 1, 2022 |  | December 31, 2022 |  | January 1, 2022 |
|  | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States | $ | 65.5 |  |  | 12.9 | % |  | $ | 51.0 |  |  | 11.4 | % |  | $ | 127.7 |  |  | 12.6 | % |  | $ | 79.1 |  |  | 8.8 | % |
| Mexico | 59.5 |  |  | 11.8 |  |  | 38.3 |  |  | 8.6 |  |  | 117.0 |  |  | 11.6 |  |  | 71.3 |  |  | 8.0 |  |
| Other Americas | 3.8 |  |  | 0.8 |  |  | 2.7 |  |  | 0.6 |  |  | 6.1 |  |  | 0.6 |  |  | 4.7 |  |  | 0.5 |  |
| Total Americas | $ | 128.8 |  |  | 25.5 | % |  | $ | 92.0 |  |  | 20.6 | % |  | $ | 250.8 |  |  | 24.8 | % |  | $ | 155.1 |  |  | 17.3 | % |
| Asia-Pacific: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Hong Kong | $ | 65.9 |  |  | 13.0 | % |  | $ | 115.0 |  |  | 25.8 | % |  | $ | 143.5 |  |  | 14.2 | % |  | $ | 257.3 |  |  | 28.8 | % |
| South Korea | 52.0 |  |  | 10.3 |  |  | 77.9 |  |  | 17.4 |  |  | 119.7 |  |  | 11.8 |  |  | 183.0 |  |  | 20.4 |  |
| Japan | 50.8 |  |  | 10.0 |  |  | 46.7 |  |  | 10.5 |  |  | 95.6 |  |  | 9.4 |  |  | 92.8 |  |  | 10.4 |  |
| Thailand | 77.9 |  |  | 15.4 |  |  | 26.2 |  |  | 5.9 |  |  | 135.4 |  |  | 13.4 |  |  | 43.3 |  |  | 4.8 |  |
| Other Asia-Pacific | 84.7 |  |  | 16.7 |  |  | 59.7 |  |  | 13.4 |  |  | 173.6 |  |  | 17.1 |  |  | 108.6 |  |  | 12.1 |  |
| Total Asia-Pacific | $ | 331.3 |  |  | 65.4 | % |  | $ | 325.5 |  |  | 73.0 | % |  | $ | 667.8 |  |  | 65.9 | % |  | $ | 685.0 |  |  | 76.4 | % |
| EMEA | $ | 45.9 |  |  | 9.1 | % |  | $ | 29.2 |  |  | 6.5 | % |  | $ | 94.2 |  |  | 9.3 | % |  | $ | 55.0 |  |  | 6.1 | % |
| Total net revenue | $ | 506.0 |  |  |  |  | $ | 446.7 |  |  |  |  | $ | 1,012.8 |  |  |  |  | $ | 895.1 |  |  |  |

[0001628280-23-002880:notes:282]
During the three and six months ended December 31, 2022, our net revenue from a single customer, which represented 10% or greater of the total net revenue, was concentrated with two customers, who collectively accounted for 31% and 33% of our total net revenue, respectively. During the three and six months ended January 1, 2022, our net revenue from a single customer, which represented 10% or greater of total net revenue was concentrated with two customers, who accounted for 41% and 46% of our total net revenue, respectively.

[0001628280-23-002880:notes:283]
As of December 31, 2022, our accounts receivable from a single customer, which represented 10% or greater of the total accounts receivable, was concentrated with one customer, which represented 14% of gross accounts receivable. As of July 2, 2022, our accounts receivable from a single customer, which represented 10% or greater of the total accounts receivable, was concentrated with two customers, which individually represented 10% and 10% of gross accounts receivable, respectively.

[0001628280-23-002880:notes:284]
[same as prior period, unchanged from 0001628280-22-028783:notes:284]

[0001628280-23-002880:notes:285]
|  | December 31, 2022 |  | July 2, 2022 |
| Property, plant and equipment, net |  |  |  |
| United States | $ | 131.2 |  |  | $ | 107.8 |  |
| Thailand | 131.7 |  |  | 107.6 |  |
| Japan | 94.2 |  |  | 38.9 |  |
| China | 52.2 |  |  | 32.7 |  |
| Other countries | 78.4 |  |  | 73.5 |  |
| Total property, plant and equipment, net | $ | 487.7 |  |  | $ | 360.5 |  |

[0001628280-23-002880:notes:286]
We purchase a portion of our inventory from contract manufacturers and vendors located primarily in Taiwan, Thailand and Malaysia. During the three and six months ended December 31, 2022, our net inventory purchases from a single contract manufacturer, which represented 10% or greater of our total net inventory purchases, were concentrated with one and two contract manufacturers, who collectively accounted for43% and 52% of total net inventory purchases, respectively. During the three and six months ended January 1, 2022, our net inventory purchases from a single contract manufacturer, which represented 10% or greater of our total net inventory purchases, were concentrated with two contract manufacturers, who collectively accounted for 58% and 61% of total net inventory purchases, respectively.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001628280-23-002880:notes:287]
[same as prior period, unchanged from 0001628280-22-028783:notes:287]

[0001628280-23-002880:notes:288]
[same as prior period, unchanged from 0001628280-22-028783:notes:288]

[0001628280-23-002880:notes:289]
[same as prior period, unchanged from 0001628280-22-028783:notes:289]

[0001628280-23-002880:notes:290]
The table below discloses our total net revenue attributable to each of our two reportable segments. In addition, the table sets forth the percentage of our total net revenue attributable to our product offerings that serve Telecom and Datacom, and Consumer and Industrial markets, which accounted for 10% or more of our total net revenue during the periods presented (in millions, except percentage data):

[0001628280-23-002880:notes:291]
|  | Three Months Ended |  | Six Months Ended |
|  | December 31, 2022 |  | January 1, 2022 |  | December 31, 2022 |  | January 1, 2022 |
| OpComms: |  |  |  |  |  |  |  |  |  |  |  |
| Telecom and Datacom | $ | 384.2 |  | 75.9 | % |  | $ | 267.1 |  | 59.8 | % |  | $ | 744.3 |  | 73.5 | % |  | $ | 483.1 |  | 54.0 | % |
| Industrial and Consumer | 64.6 |  | 12.8 | % |  | 130.3 |  | 29.2 | % |  | 157.9 |  | 15.6 | % |  | 320.3 |  | 35.8 | % |
| Total OpComms | $ | 448.8 |  | 88.7 | % |  | $ | 397.4 |  | 89.0 | % |  | $ | 902.2 |  | 89.1 | % |  | $ | 803.4 |  | 89.8 | % |
| Lasers | 57.2 |  | 11.3 | % |  | 49.3 |  | 11.0 | % |  | 110.6 |  | 10.9 | % |  | 91.7 |  | 10.2 | % |
| Net Revenue | $ | 506.0 |  |  |  | $ | 446.7 |  |  |  | $ | 1,012.8 |  |  |  | $ | 895.1 |  |  |

[0001628280-23-002880:notes:292]
[same as prior period, unchanged from 0001628280-22-028783:notes:292]

[0001628280-23-002880:notes:293]
[same as prior period, unchanged from 0001628280-22-028783:notes:293]

[0001628280-23-002880:notes:294]
| Contract balances |  | Balance sheet location |  | December 31, 2022 |  | July 2, 2022 |  | Change |  | Percentage Change |
| Accounts receivable, net |  | Accounts receivable, net |  | $ | 330.5 |  |  | $ | 262.0 |  |  | $ | 68.5 |  |  | 26.1 | % |
| Deferred revenue and customer deposits |  | Other current liabilities |  | $ | 1.3 |  |  | $ | — |  |  | $ | 1.3 |  |  | n/a |
