# LITE note change history — 0001628280-22-028783 → 0001628280-23-002880


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-02-09):
[0001628280-23-002880:note_history:1]
Purchase obligations of $391.5 million as of December 31, 2022, represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. In addition, we assumed certain purchase orders in connection with our merger with NeoPhotonics for the purchase of inventory and other items in the ordinary course of its business.  Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule and adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.
  (was, 2022-11-08, similarity 0.994):
[0001628280-22-028783:note_history:1]
Purchase obligations of $416.2 million as of October 1, 2022, represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. In addition, we assumed certain purchase orders in connection with our merger with NeoPhotonics for the purchase of inventory and other items in the ordinary course of its business.  Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule and adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

- changed (2023-02-09):
[0001628280-23-002880:note_history:2]
|  | Three Months Ended |  | Six Months Ended |
|  | December 31, 2022 |  | January 1, 2022 |  | December 31, 2022 |  | January 1, 2022 |
| Balance as of beginning of period | $ | 10.1 |  |  | $ | 5.1 |  |  | $ | 10.0 |  |  | $ | 5.0 |  |
| Warranties assumed in NeoPhotonics merger | — |  |  | — |  |  | 0.7 |  |  | — |  |
| Provision for warranty | 2.8 |  |  | 3.8 |  |  | 4.3 |  |  | 5.5 |  |
| Utilization of reserve | (4.5) |  |  | (0.3) |  |  | (6.6) |  |  | (1.9) |  |
| Balance as of end of period | $ | 8.4 |  |  | $ | 8.6 |  |  | $ | 8.4 |  |  | $ | 8.6 |  |
  (was, 2022-11-08, similarity 0.7402):
[0001628280-22-028783:note_history:2]
|  | Three Months Ended |  |  |
|  | October 1, 2022 |  | October 2, 2021 |  |  |  |  |
| Balance as of beginning of period | $ | 10.0 |  |  | $ | 5.0 |  |  |  |  |  |
| Warranties assumed in NeoPhotonics merger | 0.7 |  |  | — |  |  |  |  |  |
| Provision for warranty | 1.5 |  |  | 1.7 |  |  |  |  |  |
| Utilization of reserve | (2.1) |  |  | (1.6) |  |  |  |  |  |
| Balance as of end of period | $ | 10.1 |  |  | $ | 5.1 |  |  |  |  |  |

- changed (2023-02-09):
[0001628280-23-002880:note_history:3]
We are subject to a variety of claims and suits that arise from time to time in the ordinary course of our business. While management currently believes that resolving claims against us, individually or in the aggregate, will not have a material adverse impact on our financial position, results of operations or statements of cash flows, these matters are subject to inherent uncertainties and management’s view of these matters may change in the future. We accrue for loss contingencies when it is both probable that we will incur the loss and when we can reasonably estimate the amount of the loss or range of loss.  We have recorded $7.8 million with respect to the settlement of certain non-ordinary course litigation matters under accrued expenses in our condensed consolidated balance sheet as of December 31, 2022.
  (was, 2022-11-08, similarity 0.6325):
[0001628280-22-028783:note_history:3]
We are subject to a variety of claims and suits that arise from time to time in the ordinary course of our business. While management currently believes that resolving claims against us, individually or in the aggregate, will not have a material adverse impact on our financial position, results of operations or statements of cash flows, these matters are subject to inherent

- changed (2023-02-09):
[0001628280-23-002880:note_history:4]
After the plaintiff in the Karri Lawsuit was appointed as lead plaintiff and his counsel as lead counsel, the plaintiff filed a first amended complaint on April 15, 2019.  The first amended complaint, also named Lumentum as a defendant but Lumentum has since been dismissed from the action.  On October 8, 2020, the court granted in part and denied in part the defendant’s motion to dismiss the first amended complaint. On December 1, 2020, defendants answered the first amended complaint. On September 17, 2021, lead plaintiff filed a second amended complaint. Defendants moved to stay discovery in light of the second amended complaint. On January 11, 2022 the Court struck the second amended complaint as untimely, terminated defendants’ motions to dismiss as moot, and lifted the stay. The case proceeded through fact and expert discovery.
  (was, 2022-11-08, similarity 0.9657):
[0001628280-22-028783:note_history:4]
After the plaintiff in the Karri Lawsuit was appointed as lead plaintiff and his counsel as lead counsel, the plaintiff filed a first amended complaint on April 15, 2019.  The first amended complaint, also named Lumentum as a defendant but Lumentum has since been dismissed from the action.  On October 8, 2020, the court granted in part and denied in part the defendant’s motion to dismiss the first amended complaint. On December 1, 2020, defendants answered the first amended complaint. On September 17, 2021, lead plaintiff filed a second amended complaint. Defendants moved to stay discovery in light of the second amended complaint. On January 11, 2022 the Court struck the second amended complaint as untimely, terminated defendants’ motions to dismiss as moot, and lifted the stay.

- added (2023-02-09):
[0001628280-23-002880:note_history:5]
On August 16, 2022, Plaintiff moved for class certification and to be appointed class representative.  Defendants opposed the motion. The action subsequently was stayed while the parties participated in a mediation.  On January 18, 2023, the plaintiff filed a Notice of Settlement informing the court of an agreement in principle between the parties for a class-wide settlement of the Karri Lawsuit.  On January 24, 2023, in light of the potential settlement, the court vacated all pretrial and trial dates and ordered the plaintiff to file a motion for preliminary approval of the settlement by March 17, 2023. In the event that the settlement does not go forward for any reason, Defendants intend to continue to defend the Karri Lawsuit vigorously.

- changed (2023-02-09):
[0001628280-23-002880:note_history:6]
In the normal course of business, we enter into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown because claims may be made against us in the future, and we may record charges in the future as a result of these indemnification obligations. As of December 31, 2022, we did not have any material indemnification claims that were probable or reasonably possible.
  (was, 2022-11-08, similarity 0.9901):
[0001628280-22-028783:note_history:6]
In the normal course of business, we enter into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown because claims may be made against us in the future, and we may record charges in the future as a result of these indemnification obligations. As of October 1, 2022, we did not have any material indemnification claims that were probable or reasonably possible.

- removed (2023-02-09):
[0001628280-22-028783:note_history:7]
uncertainties and management’s view of these matters may change in the future. We accrue for loss contingencies when it is both probable that we will incur the loss and when we can reasonably estimate the amount of the loss or range of loss.

- removed (2023-02-09):
[0001628280-22-028783:note_history:8]
On August 16, 2022, Plaintiff moved for class certification and to be appointed class representative.  Defendants opposed the motion.  A hearing on the motion is scheduled for November 17, 2022.  Defendants intend to continue to defend the Karri Lawsuit vigorously.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2023-02-09):
[0001628280-23-002880:note_history:9]
Lumentum Holdings Inc. (“we,” “us,” “our”, “Lumentum” or the “Company”) is an industry-leading provider of optical and photonic products addressing a range of end market applications including Optical Communications (“OpComms”) and Commercial Lasers (“Lasers”) for manufacturing, inspection and life-science applications. We seek to use our core optical and photonic technology, and our volume manufacturing capability, to expand into attractive emerging markets that benefit from advantages that optical or photonics-based solutions provide, including imaging and sensing for consumer electronics and diode light sources for a variety of consumer and industrial applications. The majority of our customers have historically been, and are currently, original equipment manufacturers (“OEMs”) that incorporate our products into their products which then address end-market applications. For example, we sell fiber optic components that network equipment manufacturers (“NEMs”) assemble into communications networking systems, which they sell to communications service providers, hyperscale cloud operators, and enterprises with their own networks. Similarly, many of our Lasers products customers incorporate our products into tools they produce, which are used for manufacturing processes by their customers. For imaging and sensing, we sell diode lasers to manufacturers of consumer electronics products for mobile, personal computing, gaming, and other applications, including to the automotive industry, who then integrate our devices within their products, for eventual resale to consumers and also into other industrial applications.
  (was, 2022-11-08, similarity 0.9614):
[0001628280-22-028783:note_history:9]
Lumentum Holdings Inc. (“we,” “us,” “our”, “Lumentum” or the “Company”) is an industry-leading provider of optical and photonic products defined by revenue and market share addressing a range of end market applications including Optical Communications (“OpComms”) and Commercial Lasers (“Lasers”) for manufacturing, inspection and life-science applications. We seek to use our core optical and photonic technology, and our volume manufacturing capability, to expand into attractive emerging markets that benefit from advantages that optical or photonics-based solutions provide, including 3D sensing for consumer electronics and diode light sources for a variety of consumer and industrial applications. The majority of our customers are currently as well as historically original equipment manufacturers (“OEMs”) that incorporate our products into their products which then address end-market applications. For example, we sell fiber optic components that network equipment manufacturers (“NEMs”) assemble into communications networking systems, which they sell to communications service providers, hyperscale cloud operators, and enterprises with their own networks. Similarly, many of our Lasers products customers incorporate our products into tools they produce, which are used for manufacturing processes by their customers. For 3D sensing, we sell diode lasers to manufacturers of consumer electronics products for mobile, personal computing, gaming, and other applications, including to the automotive industry, who then integrate our devices within their products, for eventual resale to consumers and also into other industrial applications.

- changed (2023-02-09):
[0001628280-23-002880:note_history:10]
The accompanying condensed consolidated financial statements have been prepared in accordance with U.S. generally accepted accounting principles (“GAAP”), which requires management to make estimates and assumptions that affect the amounts reported in our condensed consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact us in the future, actual results may be different from the estimates. Operating results for the quarter ended December 31, 2022 are not necessarily indicative of the results that may be expected for the fiscal year ending July 1, 2023. In the opinion of the Company’s management, the information presented herein reflects all normal and recurring adjustments necessary for a fair presentation of our results of operations, financial position, stockholders’ equity and cash flows. Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are inventory valuation, revenue recognition, income taxes, goodwill and business combinations.
  (was, 2022-11-08, similarity 0.9965):
[0001628280-22-028783:note_history:10]
The accompanying condensed consolidated financial statements have been prepared in accordance with U.S. generally accepted accounting principles (“GAAP”), which requires management to make estimates and assumptions that affect the amounts reported in our condensed consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact us in the future, actual results may be different from the estimates. Operating results for the quarter ended October 1, 2022 are not necessarily indicative of the results that may be expected for the fiscal year ending July 1, 2023. In the opinion of the Company’s management, the information presented herein reflects all normal and recurring adjustments necessary for a fair presentation of our results of operations, financial position, stockholders’ equity and cash flows. Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are inventory valuation, revenue recognition, income taxes, goodwill and business combinations.

- added (2023-02-09):
[0001628280-23-002880:note_history:11]
Our business and operating results depend significantly on general market and economic conditions. The current global macroeconomic environment is volatile and continues to be significantly and adversely impacted by the COVID-19 pandemic, global supply chain constraints, inflation, and a dynamic demand environment. Additionally, instability in the global credit markets, the impact of uncertainty regarding global central bank monetary policy, capital expenditure reductions, unemployment and other labor issues, decline in stock markets, the instability in the geopolitical environment in many parts of the world and the current economic challenges in China continue to put pressure on global economic conditions and our business and operating results.

- changed (2023-02-09):
[0001628280-23-002880:note_history:12]
While the impact of the COVID-19 pandemic is lessening, the duration and severity of the impact of the pandemic on our business and results of operations in future periods remain uncertain. The extent of the impact of COVID-19 on our operational and financial performance will depend on certain developments, including but not limited to the duration and spread of the pandemic and its variants, implementation and duration of local, state and federal issued public health orders in each jurisdiction where we operate or in which our customers and suppliers operate, impact on our customers and our sales cycles, impact on our supply chain and manufacturing partners, impact on our employees and impact on regional and worldwide economies and financial markets in general, all of which are uncertain and not predictable. We assessed the potential impact that this pandemic has on our estimates as of December 31, 2022 and determined that there were no material impacts. However, due to the global supply chain constraint, we have had to incur incremental supply and procurement costs in order to fulfill demand from our customers.  As of December 31, 2022, our inventory balance includes $18.0 million of incremental supply and procurement costs.
  (was, 2022-11-08, similarity 0.9763):
[0001628280-22-028783:note_history:12]
While the impact of COVID-19 pandemic is lessening, the duration and severity of the impact of the pandemic on our business and results of operations in future periods remain uncertain. The extent of the impact of COVID-19 on our operational and financial performance will depend on certain developments, including but not limited to the duration and spread of the pandemic and its variants, implementation and duration of local, state and federal issued public health orders in each jurisdiction where we operate or in which our customers and suppliers operate, impact on our customers and our sales cycles, impact on our supply chain and manufacturing partners, impact on our employees and impact on regional and worldwide economies and financial markets in general, all of which are uncertain and cannot be predicted. We assessed the potential impact that this pandemic has on our estimates as of October 1, 2022 and determined that there were no material impacts. However, due to the global supply chain constraint, we have had to incur incremental supply and procurement costs in order to fulfill demand from our customers.  As of October 1, 2022, our inventory balance includes $21.9 million of incremental supply procurement costs.

- changed (2023-02-09):
[0001628280-23-002880:note_history:13]
We are also continuously monitoring the current developments in the ongoing war between Russia and Ukraine including the related export controls and resulting sanctions imposed on Russia by the U.S. and other countries. Additional factors such as increased inflation, escalating energy costs, constrained raw material availability, and related cost increases could impact the global economy. Although the global implications of the Russian/Ukraine war are difficult to predict at this time, we do not presently foresee direct material adverse effects upon our business.
  (was, 2022-11-08, similarity 0.8634):
[0001628280-22-028783:note_history:13]
We are also continuously monitoring developments in the ongoing conflict between Russia and Ukraine including the related export controls and resulting sanctions imposed on Russia by the U.S. and other countries. Additional factors such as increased inflation, escalating energy costs, constrained raw material availability, and thus increasing costs could impact the global economy. Although the global implications of the Russian/Ukraine conflict are difficult to predict at this time, we do not presently foresee direct material adverse effects upon our business.

- changed (2023-02-09):
[0001628280-23-002880:note_history:14]
On August 3, 2022, we completed a merger with NeoPhotonics Corporation (“NeoPhotonics”). Our condensed consolidated financial statements include the operating results of NeoPhotonics for the period from the date of the closing of the merger through December 31, 2022. We have applied the acquisition method of accounting in accordance with Accounting Standards Codification (“ASC”) Topic 805, Business Combinations to account for this transaction. Refer to “Note 4. Business Combinations” for further discussion of the merger.
  (was, 2022-11-08, similarity 0.6714):
[0001628280-22-028783:note_history:14]
On August 3, 2022, we completed a merger with NeoPhotonics Corporation (“NeoPhotonics”). Our condensed consolidated financial statements include the operating results of NeoPhotonics for the period from the date of the closing of the merger through October 1, 2022. We have applied the acquisition method of accounting in accordance with ASC 805 Business Combinations to account for this transaction. Refer to “Note 4. Business Combinations” for further discussion of the merger.

- changed (2023-02-09):
[0001628280-23-002880:note_history:15]
On August 15, 2022, we completed a transaction to acquire IPG Photonics’ telecom transmission product lines. Our condensed consolidated financial statements include the operating results of this business unit for the period from the date of the acquisition through December 31, 2022. We have applied the acquisition method of accounting in accordance with ASC Topic 805, Business Combinations to account for this transaction. Refer to “Note 4. Business Combinations” for further discussion of this acquisition.
  (was, 2022-11-08, similarity 0.9847):
[0001628280-22-028783:note_history:15]
On August 15, 2022, we completed a transaction to acquire IPG Photonics’ telecom transmission product lines. Our condensed consolidated financial statements include the operating results of this business unit for the period from the date of the acquisition through October 1, 2022. We have applied the acquisition method of accounting in accordance with ASC 805 Business Combinations to account for this transaction. Refer to “Note 4. Business Combinations” for further discussion of this acquisition.

- changed (2023-02-09):
[0001628280-23-002880:note_history:16]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Every fifth or sixth fiscal year will have a 53-week period. The additional week in a 53-week year is added to the third quarter, making such quarter consist of 14 weeks. Our fiscal 2023 is a 52-week year ending on July 1, 2023, with the quarter ended December 31, 2022 being a 13-week quarterly period. Our fiscal 2022 was a 52-week year that ended on July 2, 2022, with the quarter ended January 1, 2022 being a 13-week quarterly period.
  (was, 2022-11-08, similarity 0.9659):
[0001628280-22-028783:note_history:16]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Every fifth or sixth fiscal year will have a 53-week period. The additional week in a 53-week year is added to the third quarter, making such quarter consist of 14 weeks. Our fiscal 2023 is a 52-week year ending on July 1, 2023, with the quarter ended October 1, 2022 being a 13-week quarterly period. Our fiscal 2022 was a 52-week year that ended on July 2, 2022, with the quarter ended October 2, 2021 being a 13-week quarterly period.

- changed (2023-02-09):
[0001628280-23-002880:note_history:17]
The condensed consolidated financial statements and accompanying related notes should be read in conjunction with the audited consolidated financial statements and related notes included in our Annual Report on Form 10-K for the fiscal year ended July 2, 2022. 
Except for the accounting policies for convertible instruments as a result of our adoption of Accounting Standards Update (“ASU”) 2020-06, Debt—Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging—Contracts in Entity’s Own Equity (Subtopic 815-40): Accounting for Convertible Instruments and Contracts in an Entity’s Own Equity, described in “Note 2. Recently Issued Accounting Pronouncements”, there have been no significant changes to our accounting policies during the six months ended December 31, 2022.
  (was, 2022-11-08, similarity 0.8145):
[0001628280-22-028783:note_history:17]
The condensed consolidated financial statements and accompanying related notes should be read in conjunction with the audited consolidated financial statements and related notes included in our Annual Report on Form 10-K for the fiscal year ended July 2, 2022. 
Except for the accounting policies for convertible instruments as a result of our adoption of Accounting Standards Update (“ASU”) 2020-06, Debt—Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging—Contracts in Entity’s Own Equity (Subtopic 815-40): Accounting for Convertible Instruments and Contracts in an Entity’s Own Equity, there have been no significant changes to our accounting policies during the three months ended October 1, 2022.


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-02-09):
[0001628280-23-002880:note_history:18]
| Liability component: | December 31, 2022 |  | July 2, 2022 |
|  | 2024 Notes (1) |  | 2026 Notes (2) |  | 2028 Notes (3) |  | 2024 Notes (1) |  | 2026 Notes (2) |  | 2028 Notes (3) |
| Principal | $ | 448.1 |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |  | $ | 448.1 |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |
| Unamortized debt discount and issuance costs | (27.4) |  |  | (4.7) |  |  | (6.0) |  |  | (38.2) |  |  | (218.6) |  |  | (226.3) |  |
| Net carrying amount of the liability component | $ | 420.7 |  |  | $ | 1,045.3 |  |  | $ | 855.0 |  |  | $ | 409.9 |  |  | $ | 831.4 |  |  | $ | 634.7 |  |
  (was, 2022-11-08, similarity 0.9902):
[0001628280-22-028783:note_history:18]
| Liability component: | October 1, 2022 |  | July 2, 2022 |
|  | 2024 Notes (1) |  | 2026 Notes (2) |  | 2028 Notes (3) |  | 2024 Notes (1) |  | 2026 Notes (2) |  | 2028 Notes (3) |
| Principal | $ | 448.1 |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |  | $ | 448.1 |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |
| Unamortized debt discount and issuance costs | (32.9) |  |  | (5.0) |  |  | (6.5) |  |  | (38.2) |  |  | (218.6) |  |  | (226.3) |  |
| Net carrying amount of the liability component | $ | 415.2 |  |  | $ | 1,045.0 |  |  | $ | 854.5 |  |  | $ | 409.9 |  |  | $ | 831.4 |  |  | $ | 634.7 |  |

- added (2023-02-09):
[0001628280-23-002880:note_history:19]
(1) If the closing price of our stock exceeds $78.80 (or 130% of the conversion price of $60.62) for 20 of the last 30 trading days of any future fiscal quarter, our 2024 Notes would become convertible at the option of the holders during the next fiscal quarter. During the fourth quarter of fiscal 2022, the 2024 Notes were convertible at the option of the holders and therefore, the debt component of our 2024 Notes was classified as current liabilities in our condensed consolidated balance sheet. Although the 2024 Notes will not be convertible during the third quarter of fiscal 2023 due to our stock price not exceeding $78.80 for 20 of the last 30 trading days of the quarter ended December 31, 2022, we continue to classify the 2024 Notes in current liabilities, as holders may convert their 2024 Notes at any time on or after December 15, 2023 until the close of business on the second scheduled trading day immediately preceding the maturity date.

- changed (2023-02-09):
[0001628280-23-002880:note_history:20]
(2) If the closing price of our stock exceeds $129.08 (or 130% of the conversion price of $99.29) for 20 of the last 30 trading days of any future fiscal quarter, our 2026 Notes would become convertible at the option of the holders during the subsequent fiscal quarter and the debt would be reclassified to current liabilities in our condensed consolidated balance sheet.
  (was, 2022-11-08, similarity 0.9339):
[0001628280-22-028783:note_history:20]
(2) If the closing price of our stock exceeds $129.08 (or 130% of the conversion price of $99.29) for 20 of the last 30 trading days of any future quarter, our 2026 Notes would become convertible at the option of the holders and the debt would be reclassified to current liabilities in our condensed consolidated balance sheet.

- changed (2023-02-09):
[0001628280-23-002880:note_history:21]
(3) If the closing price of our stock exceeds $170.34 (or 130% of the conversion price of $131.03) for 20 of the last 30 trading days of any future fiscal quarter, our 2028 Notes would become convertible at the option of the holders during the subsequent fiscal quarter and the debt would be reclassified to current liabilities in our condensed consolidated balance sheet.
  (was, 2022-11-08, similarity 0.9121):
[0001628280-22-028783:note_history:21]
(3) If the closing price of our stock exceeds $170.34 (or 130% of the conversion price of $131.03) for 20 of the last 30 trading days of such quarter, our 2028 Notes would become convertible at the option of the holders and the debt would be reclassified to current liabilities in our condensed consolidated balance sheet.

- removed (2023-02-09):
[0001628280-22-028783:note_history:22]
(1) If the closing price of our stock exceeds $78.80 (or 130% of the conversion price of $60.62) for 20 of the last 30 trading days of any future quarter, our 2024 Notes would become convertible at the option of the holders. During the fourth quarter of fiscal 2022, the 2024 Notes were convertible at the option of the holders and therefore, the debt component of our 2024 Notes was classified as current liabilities in our condensed consolidated balance sheet. While the 2024 Notes will not be convertible during the second quarter of fiscal 2023, as our stock price did not exceed $78.80 for 20 of the last 30 trading days of the quarter ended October 1, 2022, we continue to classify the 2024 Notes in current liabilities as this presentation provides consistency and better comparability with our prior periods.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-02-09):
[0001628280-23-002880:note_history:23]
The 2028 Notes bear interest at a rate of 0.50% per year, payable semi-annually in arrears on June 15 and December 15 of each year, beginning on June 15, 2022. The 2028 Notes will mature on June 15, 2028, unless earlier redeemed, repurchased by us, or converted pursuant to their terms.
  (was, 2022-11-08, similarity 0.9962):
[0001628280-22-028783:note_history:23]
The 2028 Notes bear interest at a rate of 0.50% per year, payable semi-annually in arrears on June 15 and December 15 of each year, beginning on June 15, 2022. The 2028 Notes will mature on June 15, 2028, unless earlier redeemed, repurchased by us, or converted pursuant to the terms.

- changed (2023-02-09):
[0001628280-23-002880:note_history:24]
The initial conversion rate is 7.6319 shares of common stock per $1,000 principal amount of the 2028 Notes (which is equivalent to an initial conversion price of approximately $131.03 per share). The conversion rate is subject to adjustment upon the occurrence of certain specified events, but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change (as defined in the 2028 Indenture) or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert the 2028 Notes in connection with such make-whole fundamental change or notice of redemption.
  (was, 2022-11-08, similarity 0.9765):
[0001628280-22-028783:note_history:24]
The initial conversion rate is 7.6319 shares of common stock per $1,000 principal amount of the 2028 Notes (which is equivalent to an initial conversion price of approximately $131.03 per share). The conversion rate is subject to adjustment upon the occurrence of certain specified events, but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert the 2028 Notes in connection with such make-whole fundamental change or notice of redemption.

- changed (2023-02-09):
[0001628280-23-002880:note_history:25]
•during any fiscal quarter (and only during such fiscal quarter), if the last reported sale price of the Company’s common stock for at least 20 trading days (whether or not consecutive) during the 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price, or $170.34, on each applicable trading day;
  (was, 2022-11-08, similarity 0.9687):
[0001628280-22-028783:note_history:25]
•during any fiscal quarter commencing after July 2, 2022 (and only during such fiscal quarter), if the last reported sale price of the Company’s common stock for at least 20 trading days (whether or not consecutive) during the 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price, or $170.34, on each applicable trading day;

- changed (2023-02-09):
[0001628280-23-002880:note_history:26]
•during the five consecutive business day period after any five consecutive trading day period (the “measurement period”) in which the trading price per $1,000 principal amount of the 2028 Notes for each trading day of such measurement period was less than 98% of the product of the last reported sale price of the Company’s common stock and the applicable conversion rate on each such trading day;
  (was, 2022-11-08, similarity 0.9909):
[0001628280-22-028783:note_history:26]
•during the five consecutive business day period after any five consecutive trading day period (the “measurement period”) in which the trading price per $1,000 principal amount of the 2028 Notes for each trading day of such measurement was less than 98% of the product of the last reported sale price of the Company’s common stock and the applicable conversion rate on each such trading day;

- changed (2023-02-09):
[0001628280-23-002880:note_history:27]
We may redeem for cash all or any portion of the 2028 Notes, at our option (subject to the partial redemption limitation set forth in the 2028 Indenture), on or after June 20, 2025, if the last reported sale price of its common stock has been at least 130% of the conversion price then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading-day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which the Company provides notice of redemption at a redemption price equal to 100% of the principal amount of the 2028 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. No sinking fund is provided for the 2028 Notes. If we elect to redeem fewer than all of the outstanding 2028 Notes, at least $100.0 million aggregate principal amount of the 2028 Notes must be outstanding and not subject to redemption as of the redemption notice date. Upon the occurrence of a fundamental change (as defined in the 2028 Indenture), holders may require the Company to repurchase all or a portion of their 2028 Notes for cash at a price equal to 100% of the principal amount of the 2028 Notes to be repurchased, plus any accrued and unpaid interest to, but excluding, the fundamental change repurchase date.
  (was, 2022-11-08, similarity 0.9):
[0001628280-22-028783:note_history:27]
We may redeem for cash all or any of the 2028 Notes, at our option (subject to the partial redemption limitation set forth in the 2028 Indenture), on or after June 20, 2025, if the last reported sale price of its common stock has been at least 130% of the conversion price then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading-day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which the Company provides notice of redemption at a redemption price equal to 100% of the principal amount of the 2028 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. No sinking fund is provided for the 2028 Notes. If we elect to redeem fewer than all of the outstanding 2028 Notes, at least $100.0 million aggregate principal amount of the 2028 Notes must be outstanding and not subject to redemption as of the redemption notice date. Upon the occurrence of a fundamental change (as defined in the 2028 Indenture), holders may require the Company to

- changed (2023-02-09):
[0001628280-23-002880:note_history:28]
The initial conversion rate is 10.0711 shares of common stock per $1,000 principal amount of the 2026 Notes (which is equivalent to an initial conversion price of approximately $99.29 per share). The conversion rate is subject to adjustment upon the occurrence of certain events specified in the 2026 Indenture but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change (as defined in the 2026 Indenture) or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares set forth in the 2026 Indenture or a holder that elects to convert the 2026 Notes in connection with such make-whole fundamental change or notice of redemption.
  (was, 2022-11-08, similarity 0.978):
[0001628280-22-028783:note_history:28]
The initial conversion rate is 10.0711 shares of common stock per $1,000 principal amount of the 2026 Notes (which is equivalent to an initial conversion price of approximately $99.29 per share). The conversion rate is subject to adjustment upon the occurrence of certain events specified in the 2026 Indenture but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares set forth in the 2026 Indenture or a holder that elects to convert the 2026 Notes in connection with such make-whole fundamental change or notice of redemption.

- changed (2023-02-09):
[0001628280-23-002880:note_history:29]
•during the five consecutive business day period after any five consecutive trading day period (the "2026 measurement period") in which the trading price per $1,000 principal amount of the 2026 Notes for each trading day of the 2026 measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate for the 2026 Notes on each such trading day;
  (was, 2022-11-08, similarity 0.9703):
[0001628280-22-028783:note_history:29]
•during the five business day period after any five consecutive trading day period (the "2026 measurement period") in which the trading price per $1,000 principal amount of the 2026 Notes for each trading day of the 2026 measurement period was less than 98% of the product of the last reported sale price of our common stock and the conversion rate for the 2026 Notes on each such trading day;

- changed (2023-02-09):
[0001628280-23-002880:note_history:30]
On or after September 15, 2026 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their 2026 Notes at any time. Upon conversion, we may satisfy our conversion obligation in cash, shares of common stock or a combination of cash and shares of common stock, at our election.
  (was, 2022-11-08, similarity 0.997):
[0001628280-22-028783:note_history:30]
On or after September 15, 2026 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert the 2026 Notes at any time. Upon conversion, we may satisfy our conversion obligation in cash, shares of common stock or a combination of cash and shares of common stock, at our election.

- changed (2023-02-09):
[0001628280-23-002880:note_history:31]
We may redeem for cash, all or any portion of the 2026 Notes, at our option, on or after December 20, 2023, if the last reported sale price of its common stock has been at least 130% of the conversion price then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading-day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which we provide a notice of redemption at a redemption price equal to 100% of the principal amount of the 2026 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. No sinking fund is provided for the 2026 Notes. Upon the occurrence of a fundamental change (as defined in the 2026 Indenture), holders may require us to repurchase all or a portion of the 2026 Notes for cash at a price equal to 100% of the principal amount of the 2026 Notes to be repurchased, plus any accrued and unpaid interest to, but excluding, the fundamental change repurchase date.
  (was, 2022-11-08, similarity 0.9054):
[0001628280-22-028783:note_history:31]
We may redeem for cash, for all or any portion of the 2026 Notes, at our option, on or after December 20, 2023, if the last reported sale price of its common stock has been at least 130% of the conversion price then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading-day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which we provide a notice of redemption at a redemption price equal to 100% of the principal amount of the 2026 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. No sinking fund is provided for the 2026 Notes. Upon the occurrence of a fundamental change (as defined in the 2026 Indenture), holders may require us to repurchase all or a portion of the 2026 Notes for cash at a

- added (2023-02-09):
[0001628280-23-002880:note_history:32]
In March 2017, we issued $450.0 million in aggregate principal amount 2024 Notes of 0.25% convertible notes due in 2024 (the “2024 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act. The 2024 Notes are governed by an indenture between the Company, as the issuer, and U.S. Bank Trust Company National Association (as successor in interest to U.S. Bank National Association), as trustee (the “2024 Indenture”). The 2024 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

- added (2023-02-09):
[0001628280-23-002880:note_history:33]
The initial conversion rate of the 2024 Notes is 16.4965 shares of common stock per $1,000 principal amount of 2024 Notes, which is equivalent to an initial conversion price of approximately $60.62 per share. The conversion rate is subject to adjustment upon the occurrence of certain specified events but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change (as defined in the 2024 Indenture) or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert the 2024 Notes in connection with such make-whole fundamental change or notice of redemption.

- added (2023-02-09):
[0001628280-23-002880:note_history:34]
Prior to the close of business on the business day immediately preceding December 15, 2023, each holder of the 2024 Notes may convert their 2024 Notes only under the following circumstances:

- changed (2023-02-09):
[0001628280-23-002880:note_history:35]
•during the five consecutive business day period after any five consecutive trading day period (the “2024 measurement period”) in which the trading price per $1,000 principal amount of 2024 Notes for each trading day of such 2024 measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate for the 2024 Notes on each such trading day;
  (was, 2022-11-08, similarity 0.9794):
[0001628280-22-028783:note_history:35]
•during the five consecutive business day period after any five consecutive trading day period (the “2024 measurement period”) in which the trading price per $1,000 principal amount of 2024 Notes for each trading day of such 2024 measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate on each such trading day;

- changed (2023-02-09):
[0001628280-23-002880:note_history:36]
We may not redeem the 2024 Notes prior to their maturity date and no sinking fund is provided for the 2024 Notes. Upon the occurrence of a fundamental change (as defined in the 2024 Indenture), holders may require us to repurchase all or a portion of their 2024 Notes for cash at a price equal to 100% of the principal amount of the 2024 Notes to be repurchased, plus any accrued and unpaid interest.
  (was, 2022-11-08, similarity 0.9564):
[0001628280-22-028783:note_history:36]
We may not redeem the 2024 Notes prior to their maturity date and no sinking fund is provided for the 2024 Notes. Upon the occurrence of a fundamental change, holders may require us to repurchase all or a portion of their 2024 Notes for cash at a price equal to 100% of the principal amount of the 2024 Notes to be repurchased, plus any accrued and unpaid interest.

- added (2023-02-09):
[0001628280-23-002880:note_history:37]
During the three and six months ended December 31, 2022 we received conversion requests of less than $0.1 million principal amount of the 2024 Notes, which we settled with cash in accordance with the 2024 Indenture. Since issuing the 2024 Notes, we have converted a total of approximately $1.9 million principal amount of the 2024 Notes. The remaining principal amount of the 2024 Notes as of December 31, 2022 was $448.1 million.

- changed (2023-02-09):
[0001628280-23-002880:note_history:38]
We considered the features embedded in the 2024 Notes other than the conversion feature, including the holders’ put feature, our call feature, and the make-whole feature, and concluded that they are not required to be bifurcated and accounted for separately from the host debt instrument. Prior to the Tax Matters Agreement settlement condition (“TMA settlement condition”), because we could only settle the 2024 Notes in cash, we determined that the conversion feature met the definition of a derivative liability. We separated the derivative liability from the host debt instrument based on the fair value of the derivative liability. During fiscal 2017, we satisfied the TMA settlement condition. As such, the value of the conversion option is no longer marked-to-market and was reclassified to additional paid-in capital within stockholders’ equity on our condensed consolidated balance sheets. The adoption of ASU 2020-06 did not change the presentation of the 2024 Notes, as the conversion feature associated with the 2024 Notes continues to be classified within stockholders’ equity.
  (was, 2022-11-08, similarity 0.8131):
[0001628280-22-028783:note_history:38]
We considered the features embedded in the 2024 Notes other than the conversion feature, including the holders’ put feature, our call feature, and the make-whole feature, and concluded that they are not required to be bifurcated and accounted for separately from the host debt instrument. Prior to the Tax Matters Agreement settlement condition (“TMA settlement condition”), because we could only settle the 2024 Notes in cash, we determined that the conversion feature met the definition of a derivative liability. We separated the derivative liability from the host debt instrument based on the fair value of the derivative liability. During fiscal 2017, we satisfied the TMA settlement condition. As such, the value of the conversion option

- changed (2023-02-09):
[0001628280-23-002880:note_history:39]
| Liability component: | December 31, 2022 |  | July 2, 2022 |
|  | 2024 Notes (1) |  | 2026 Notes (2) |  | 2028 Notes (3) |  | 2024 Notes (1) |  | 2026 Notes (2) |  | 2028 Notes (3) |
| Principal | $ | 448.1 |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |  | $ | 448.1 |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |
| Unamortized debt discount and issuance costs | (27.4) |  |  | (4.7) |  |  | (6.0) |  |  | (38.2) |  |  | (218.6) |  |  | (226.3) |  |
| Net carrying amount of the liability component | $ | 420.7 |  |  | $ | 1,045.3 |  |  | $ | 855.0 |  |  | $ | 409.9 |  |  | $ | 831.4 |  |  | $ | 634.7 |  |
  (was, 2022-11-08, similarity 0.9902):
[0001628280-22-028783:note_history:39]
| Liability component: | October 1, 2022 |  | July 2, 2022 |
|  | 2024 Notes (1) |  | 2026 Notes (2) |  | 2028 Notes (3) |  | 2024 Notes (1) |  | 2026 Notes (2) |  | 2028 Notes (3) |
| Principal | $ | 448.1 |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |  | $ | 448.1 |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |
| Unamortized debt discount and issuance costs | (32.9) |  |  | (5.0) |  |  | (6.5) |  |  | (38.2) |  |  | (218.6) |  |  | (226.3) |  |
| Net carrying amount of the liability component | $ | 415.2 |  |  | $ | 1,045.0 |  |  | $ | 854.5 |  |  | $ | 409.9 |  |  | $ | 831.4 |  |  | $ | 634.7 |  |

- added (2023-02-09):
[0001628280-23-002880:note_history:40]
(1) If the closing price of our stock exceeds $78.80 (or 130% of the conversion price of $60.62) for 20 of the last 30 trading days of any future fiscal quarter, our 2024 Notes would become convertible at the option of the holders during the next fiscal quarter. During the fourth quarter of fiscal 2022, the 2024 Notes were convertible at the option of the holders and therefore, the debt component of our 2024 Notes was classified as current liabilities in our condensed consolidated balance sheet. Although the 2024 Notes will not be convertible during the third quarter of fiscal 2023 due to our stock price not exceeding $78.80 for 20 of the last 30 trading days of the quarter ended December 31, 2022, we continue to classify the 2024 Notes in current liabilities, as holders may convert their 2024 Notes at any time on or after December 15, 2023 until the close of business on the second scheduled trading day immediately preceding the maturity date.

- changed (2023-02-09):
[0001628280-23-002880:note_history:41]
(2) If the closing price of our stock exceeds $129.08 (or 130% of the conversion price of $99.29) for 20 of the last 30 trading days of any future fiscal quarter, our 2026 Notes would become convertible at the option of the holders during the subsequent fiscal quarter and the debt would be reclassified to current liabilities in our condensed consolidated balance sheet.
  (was, 2022-11-08, similarity 0.9339):
[0001628280-22-028783:note_history:41]
(2) If the closing price of our stock exceeds $129.08 (or 130% of the conversion price of $99.29) for 20 of the last 30 trading days of any future quarter, our 2026 Notes would become convertible at the option of the holders and the debt would be reclassified to current liabilities in our condensed consolidated balance sheet.

- changed (2023-02-09):
[0001628280-23-002880:note_history:42]
(3) If the closing price of our stock exceeds $170.34 (or 130% of the conversion price of $131.03) for 20 of the last 30 trading days of any future fiscal quarter, our 2028 Notes would become convertible at the option of the holders during the subsequent fiscal quarter and the debt would be reclassified to current liabilities in our condensed consolidated balance sheet.
  (was, 2022-11-08, similarity 0.9121):
[0001628280-22-028783:note_history:42]
(3) If the closing price of our stock exceeds $170.34 (or 130% of the conversion price of $131.03) for 20 of the last 30 trading days of such quarter, our 2028 Notes would become convertible at the option of the holders and the debt would be reclassified to current liabilities in our condensed consolidated balance sheet.

- changed (2023-02-09):
[0001628280-23-002880:note_history:43]
|  | Three Months Ended |  | Six Months Ended |
|  | December 31, 2022 |  | January 1, 2022 |  | December 31, 2022 |  | January 1, 2022 |
| Contractual interest expense | $ | 2.7 |  |  | $ | 1.6 |  |  | $ | 5.4 |  |  | $ | 3.2 |  |
| Amortization of the debt discount and debt issuance costs | 6.2 |  |  | 15.5 |  |  | 11.9 |  |  | 30.8 |  |
| Total interest expense | $ | 8.9 |  |  | $ | 17.1 |  |  | $ | 17.3 |  |  | $ | 34.0 |  |
  (was, 2022-11-08, similarity 0.7163):
[0001628280-22-028783:note_history:43]
|  | Three Months Ended |  |  |
|  | October 1, 2022 |  | October 2, 2021 |  |  |  |  |
| Contractual interest expense | $ | 2.7 |  |  | $ | 1.6 |  |  |  |  |  |
| Amortization of the debt discount and debt issuance costs | 5.7 |  |  | 15.3 |  |  |  |  |  |
| Total interest expense | $ | 8.4 |  |  | $ | 16.9 |  |  |  |  |  |

- changed (2023-02-09):
[0001628280-23-002880:note_history:44]
The future interest and principal payments related to our convertible notes are as follows as of December 31, 2022 (in millions):
  (was, 2022-11-08, similarity 0.9717):
[0001628280-22-028783:note_history:44]
The future interest and principal payments related to our convertible notes are as follows as of October 1, 2022 (in millions):

- changed (2023-02-09):
[0001628280-23-002880:note_history:45]
| Fiscal Years | 2024 Notes |  | 2026 Notes |  | 2028 Notes |  | Total |
| Remainder of 2023 | $ | 0.6 |  |  | $ | 2.6 |  |  | $ | 2.2 |  |  | $ | 5.4 |  |
| 2024 | 449.2 |  |  | 5.3 |  |  | 4.3 |  |  | 458.8 |  |
| 2025 | — |  |  | 5.3 |  |  | 4.3 |  |  | 9.6 |  |
| 2026 | — |  |  | 5.3 |  |  | 4.3 |  |  | 9.6 |  |
| 2027 and thereafter | — |  |  | 1,052.4 |  |  | 869.6 |  |  | 1,922.0 |  |
| Total convertible notes payments | $ | 449.8 |  |  | $ | 1,070.9 |  |  | $ | 884.7 |  |  | $ | 2,405.4 |  |
  (was, 2022-11-08, similarity 0.9791):
[0001628280-22-028783:note_history:45]
| Fiscal Years | 2024 Notes |  | 2026 Notes |  | 2028 Notes |  | Total |
| Remainder of 2023 | $ | 0.6 |  |  | $ | 5.3 |  |  | $ | 4.3 |  |  | $ | 10.2 |  |
| 2024 | 449.2 |  |  | 5.3 |  |  | 4.3 |  |  | 458.8 |  |
| 2025 | — |  |  | 5.3 |  |  | 4.3 |  |  | 9.6 |  |
| 2026 | — |  |  | 5.3 |  |  | 4.3 |  |  | 9.6 |  |
| 2027 | — |  |  | 1,052.4 |  |  | 869.6 |  |  | 1,922.0 |  |
| Total convertible notes payments | $ | 449.8 |  |  | $ | 1,073.6 |  |  | $ | 886.8 |  |  | $ | 2,410.2 |  |

- added (2023-02-09):
[0001628280-23-002880:note_history:46]
In connection with our merger of NeoPhotonics, we assumed several loan agreements with MUFG Bank, Ltd. (the “Mitsubishi Bank Loans”) for an aggregate fair value of approximately $5.9 million, approximately $0.9 million of which was paid in the fiscal first quarter of 2023.  In October 2022, we fully paid the remaining outstanding amount of the Mitsubishi Bank Loans of approximately $5.0 million. We recorded $0.1 million of interest expense related to the Mitsubishi Bank Loans for both the three and six months ended December 31, 2022.

- removed (2023-02-09):
[0001628280-22-028783:note_history:47]
repurchase all or a portion of their 2028 Notes for cash at a price equal to 100% of the principal amount of the 2028 Notes to be repurchased, plus any accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

- removed (2023-02-09):
[0001628280-22-028783:note_history:48]
price equal to 100% of the principal amount of the 2026 Notes to be repurchased, plus any accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

- removed (2023-02-09):
[0001628280-22-028783:note_history:49]
In March 2017, we issued $450.0 million in aggregate principal amount 2024 Notes in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act. The 2024 Notes are governed by an indenture between the Company, as the issuer, and U.S. Bank Trust Company National Association (as successor in interest to U.S. Bank National Association), as trustee (the “2024 Indenture”). The 2024 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

- removed (2023-02-09):
[0001628280-22-028783:note_history:50]
The initial conversion rate of the 2024 Notes is 16.4965 shares of common stock per $1,000 principal amount of 2024 Notes, which is equivalent to an initial conversion price of approximately $60.62 per share, a 132.5% premium to the fair market value at the date of issuance.  Prior to the close of business on the business day immediately preceding December 15, 2023, each holder of the 2024 Notes may convert their 2024 Notes only under the following circumstances:

- removed (2023-02-09):
[0001628280-22-028783:note_history:51]
During the three months ended October 1, 2022, we received conversion requests of less than $0.1 million principal amount of the 2024 Notes, which we settled with cash in accordance with the 2024 Indenture. Since issuing the 2024 Notes, we have converted a total of approximately $1.9 million principal amount of the 2024 Notes. The remaining principal amount of the 2024 Notes as of October 1, 2022 was $448.1 million.

- removed (2023-02-09):
[0001628280-22-028783:note_history:52]
is no longer marked-to-market and was reclassified to additional paid-in capital within stockholders’ equity on our condensed consolidated balance sheets. The adoption of ASU 2020-06 did not change the presentation of the 2024 Notes, as the conversion feature associated with the 2024 Notes continues to be classified within stockholders’ equity.

- removed (2023-02-09):
[0001628280-22-028783:note_history:53]
(1) If the closing price of our stock exceeds $78.80 (or 130% of the conversion price of $60.62) for 20 of the last 30 trading days of any future quarter, our 2024 Notes would become convertible at the option of the holders. During the fourth quarter of fiscal 2022, the 2024 Notes were convertible at the option of the holders and therefore, the debt component of our 2024 Notes was classified as current liabilities in our condensed consolidated balance sheet. While the 2024 Notes will not be convertible during the second quarter of fiscal 2023, as our stock price did not exceed $78.80 for 20 of the last 30 trading days of the quarter ended October 1, 2022, we continue to classify the 2024 Notes in current liabilities as this presentation provides consistency and better comparability with our prior periods.

- removed (2023-02-09):
[0001628280-22-028783:note_history:54]
In connection with our merger of NeoPhotonics, we assumed several loan agreements with MUFG Bank, Ltd. (the “Mitsubishi Bank”).

- removed (2023-02-09):
[0001628280-22-028783:note_history:55]
In February 2015, NeoPhotonics entered into a loan agreement with Mitsubishi Bank, that provided for a term loan in the aggregate principal amount of 1.0 billion JPY (approximately $6.9 million based on the exchange rate on October 1, 2022) (the “2015 Mitsubishi Bank Loan”). The 2015 Mitsubishi Bank Loan is secured by a mortgage on certain real property and buildings owned by NeoPhotonic’s Japanese subsidiary. The 2015 Mitsubishi Bank Loan accrues interest and is paid monthly based upon the annual rate of the monthly Tokyo Interbank Offer Rate ("TIBOR") plus 1.40%.  The term loan requires equal monthly payments of principal equal to 8.3 million JPY (approximately $0.1 million based on the exchange rate on October 1, 2022) until the maturity date of February 25, 2025, with a lump sum payment of the balance of 8.4 million JPY (approximately $0.1 million based on the exchange rate on October 1, 2022) on the maturity date.  The outstanding principal balance for the 2015 Mitsubishi Bank Loan was 241.7 million JPY (approximately $1.6 million) as of October 1, 2022.

- removed (2023-02-09):
[0001628280-22-028783:note_history:56]
In March 2017, NeoPhotonics entered into a loan agreement with Mitsubishi Bank for a term loan of 690.0 million JPY (approximately $4.8 million based on the exchange rate on October 1, 2022) (the “2017 Mitsubishi Bank Loan”) to acquire manufacturing equipment for its Japanese subsidiary. This loan is secured by the manufacturing equipment owned by the NeoPhotonics' subsidiary in Japan. Interest on the 2017 Mitsubishi Bank Loan is based on the annual rate of the monthly TIBOR rate plus 1.00%. The 2017 Mitsubishi Bank Loan matures on March 29, 2024 and requires monthly interest and principal payments over 72 months commencing in April 2018. The outstanding principal balance for the 2017 Mitsubishi Bank Loan was 172.5 million JPY (approximately $1.3 million) as of October 1, 2022.

- removed (2023-02-09):
[0001628280-22-028783:note_history:57]
In January 2018, NeoPhotonics entered into a term loan agreement with Mitsubishi Bank and The Yamanashi Chuo Bank, Ltd. for a term loan in the aggregate principal amount of 850.0 million JPY (approximately $5.9 million based on the exchange rate on October 1, 2022) (the “2018 Mitsubishi Bank Loan”). The purpose of this term loan was to obtain machinery for the core parts of the manufacturing line and payments for related expenses by NeoPhotonics' subsidiary in Japan. This term loan requires no additional security. Interest on the term loan is based upon the annual rate of the three months TIBOR rate plus 1.00%. The term loan requires quarterly interest payments, along with the principal payments, over 82 months commencing in April 2018. The outstanding principal balance for the 2018 Mitsubishi Bank Loan was approximately 303.6 million JPY (approximately $2.1 million) as of October 1, 2022.

- removed (2023-02-09):
[0001628280-22-028783:note_history:58]
All of these term loans contain customary representations and warranties, and customary affirmative and negative covenants applicable to NeoPhotonics’ Japanese subsidiary, including, among other things, restrictions on cessation in business, management, mergers or acquisitions. These term loans contain customary covenants relating to minimum net assets, maximum ordinary loss and a coverage ratio covenant. We are in compliance with the related covenants for all these term loans as of October 1, 2022.

- removed (2023-02-09):
[0001628280-22-028783:note_history:59]
We intend to repay all amounts outstanding under the 2015 Mitsubishi Bank Loan, 2017 Mitsubishi Bank Loan and 2018 Mitsubishi Bank Loan during fiscal year 2023. As such, we presented these term loans within short term debt in our condensed consolidated balance sheet.


## us-gaap:DebtSecuritiesAvailableForSaleUnrealizedLossPositionFairValueTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-02-09):
[0001628280-23-002880:note_history:60]
The following table summarizes unrealized losses on our cash equivalents and short-term investments by category that have been in a continuous unrealized loss position for more than 12 months and  less than 12 months as of the periods presented, respectively (in millions):
  (was, 2022-11-08, similarity 0.9105):
[0001628280-22-028783:note_history:60]
The following table summarizes unrealized losses on our cash equivalents and short-term investments by category that have been in a continuous unrealized loss position for less than 12 months as of the periods presented (in millions):

- added (2023-02-09):
[0001628280-23-002880:note_history:61]
|  | Continuous Loss Position For More Than 12 Months |  | Continuous Loss Position For Less Than 12 Months |  | Gross Unrealized Losses |  |  |  |  |  |  |  |  |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  |  |  |  |  |  |  |  |  |
| December 31, 2022: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | 45.9 |  |  | $ | (1.1) |  |  | $ | 83.0 |  |  | $ | (0.5) |  |  | $ | (1.6) |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | — |  |  | 5.7 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | — |  |  | — |  |  | 73.4 |  |  | (0.2) |  |  | (0.2) |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 283.9 |  |  | (3.0) |  |  | 176.2 |  |  | (1.8) |  |  | (4.8) |  |  |  |  |  |  |  |  |  |
| Municipal bonds | 1.0 |  |  | — |  |  | — |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Foreign government bonds | — |  |  | — |  |  | 1.4 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 148.1 |  |  | (2.4) |  |  | 98.2 |  |  | (0.4) |  |  | (2.8) |  |  |  |  |  |  |  |  |  |
| Total | $ | 478.9 |  |  | $ | (6.5) |  |  | $ | 437.9 |  |  | $ | (2.9) |  |  | $ | (9.4) |  |  |  |  |  |  |  |  |  |
| July 2, 2022: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | — |  |  | $ | — |  |  | $ | 73.7 |  |  | $ | (1.4) |  |  | $ | (1.4) |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | — |  |  | 16.2 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | — |  |  | — |  |  | 130.7 |  |  | (0.4) |  |  | (0.4) |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 57.4 |  |  | (0.9) |  |  | 473.2 |  |  | (6.5) |  |  | (7.4) |  |  |  |  |  |  |  |  |  |
| Municipal bonds | — |  |  | — |  |  | 1.0 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | — |  |  | — |  |  | 366.0 |  |  | (4.2) |  |  | (4.2) |  |  |  |  |  |  |  |  |  |
| Total | $ | 57.4 |  |  | $ | (0.9) |  |  | $ | 1,060.8 |  |  | $ | (12.5) |  |  | $ | (13.4) |  |  |  |  |  |  |  |  |  |

- removed (2023-02-09):
[0001628280-22-028783:note_history:62]
|  | Fair Value |  | Unrealized Losses |  |  |  |  |  |  |  |  |
| October 1, 2022: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | 86.4 |  |  | (1.8) |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | 6.4 |  |  | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | 90.2 |  |  | (0.4) |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 334.4 |  |  | (5.0) |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 262.5 |  |  | (3.7) |  |  |  |  |  |  |  |  |  |
| Total | $ | 779.9 |  |  | $ | (10.9) |  |  |  |  |  |  |  |  |  |
| July 2, 2022: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | 73.7 |  |  | $ | (1.4) |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | 16.2 |  |  | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | 130.7 |  |  | (0.4) |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 473.2 |  |  | (6.5) |  |  |  |  |  |  |  |  |  |
| Municipal bonds | 1.0 |  |  | — |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 366.0 |  |  | (4.2) |  |  |  |  |  |  |  |  |  |
| Total | $ | 1,060.8 |  |  | $ | (12.5) |  |  |  |  |  |  |  |  |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-02-09):
[0001628280-23-002880:note_history:63]
The future interest and principal payments related to our convertible notes are as follows as of December 31, 2022 (in millions):
  (was, 2022-11-08, similarity 0.9717):
[0001628280-22-028783:note_history:63]
The future interest and principal payments related to our convertible notes are as follows as of October 1, 2022 (in millions):

- changed (2023-02-09):
[0001628280-23-002880:note_history:64]
| Fiscal Years | 2024 Notes |  | 2026 Notes |  | 2028 Notes |  | Total |
| Remainder of 2023 | $ | 0.6 |  |  | $ | 2.6 |  |  | $ | 2.2 |  |  | $ | 5.4 |  |
| 2024 | 449.2 |  |  | 5.3 |  |  | 4.3 |  |  | 458.8 |  |
| 2025 | — |  |  | 5.3 |  |  | 4.3 |  |  | 9.6 |  |
| 2026 | — |  |  | 5.3 |  |  | 4.3 |  |  | 9.6 |  |
| 2027 and thereafter | — |  |  | 1,052.4 |  |  | 869.6 |  |  | 1,922.0 |  |
| Total convertible notes payments | $ | 449.8 |  |  | $ | 1,070.9 |  |  | $ | 884.7 |  |  | $ | 2,405.4 |  |
  (was, 2022-11-08, similarity 0.9791):
[0001628280-22-028783:note_history:64]
| Fiscal Years | 2024 Notes |  | 2026 Notes |  | 2028 Notes |  | Total |
| Remainder of 2023 | $ | 0.6 |  |  | $ | 5.3 |  |  | $ | 4.3 |  |  | $ | 10.2 |  |
| 2024 | 449.2 |  |  | 5.3 |  |  | 4.3 |  |  | 458.8 |  |
| 2025 | — |  |  | 5.3 |  |  | 4.3 |  |  | 9.6 |  |
| 2026 | — |  |  | 5.3 |  |  | 4.3 |  |  | 9.6 |  |
| 2027 | — |  |  | 1,052.4 |  |  | 869.6 |  |  | 1,922.0 |  |
| Total convertible notes payments | $ | 449.8 |  |  | $ | 1,073.6 |  |  | $ | 886.8 |  |  | $ | 2,410.2 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-02-09):
[0001628280-23-002880:note_history:65]
The table below discloses our total net revenue attributable to each of our two reportable segments. In addition, the table sets forth the percentage of our total net revenue attributable to our product offerings that serve Telecom and Datacom, and Consumer and Industrial markets, which accounted for 10% or more of our total net revenue during the periods presented (in millions, except percentage data):
  (was, 2022-11-08, similarity 0.9913):
[0001628280-22-028783:note_history:65]
The table below discloses our total net revenue attributable to each of our two reportable segments. In addition, the table sets forth the percentage of our total net revenue attributable to our product offerings that serve Telecom and Datacom, and Consumer and Industrial markets  accounted for 10% or more of our total net revenue during the periods presented (in millions, except percentage data):

- added (2023-02-09):
[0001628280-23-002880:note_history:66]
|  | Three Months Ended |  | Six Months Ended |
|  | December 31, 2022 |  | January 1, 2022 |  | December 31, 2022 |  | January 1, 2022 |
| OpComms: |  |  |  |  |  |  |  |  |  |  |  |
| Telecom and Datacom | $ | 384.2 |  | 75.9 | % |  | $ | 267.1 |  | 59.8 | % |  | $ | 744.3 |  | 73.5 | % |  | $ | 483.1 |  | 54.0 | % |
| Industrial and Consumer | 64.6 |  | 12.8 | % |  | 130.3 |  | 29.2 | % |  | 157.9 |  | 15.6 | % |  | 320.3 |  | 35.8 | % |
| Total OpComms | $ | 448.8 |  | 88.7 | % |  | $ | 397.4 |  | 89.0 | % |  | $ | 902.2 |  | 89.1 | % |  | $ | 803.4 |  | 89.8 | % |
| Lasers | 57.2 |  | 11.3 | % |  | 49.3 |  | 11.0 | % |  | 110.6 |  | 10.9 | % |  | 91.7 |  | 10.2 | % |
| Net Revenue | $ | 506.0 |  |  |  | $ | 446.7 |  |  |  | $ | 1,012.8 |  |  |  | $ | 895.1 |  |  |

- added (2023-02-09):
[0001628280-23-002880:note_history:67]
| Contract balances |  | Balance sheet location |  | December 31, 2022 |  | July 2, 2022 |  | Change |  | Percentage Change |
| Accounts receivable, net |  | Accounts receivable, net |  | $ | 330.5 |  |  | $ | 262.0 |  |  | $ | 68.5 |  |  | 26.1 | % |
| Deferred revenue and customer deposits |  | Other current liabilities |  | $ | 1.3 |  |  | $ | — |  |  | $ | 1.3 |  |  | n/a |

- removed (2023-02-09):
[0001628280-22-028783:note_history:68]
|  | Three Months Ended |  |  |
|  | October 1, 2022 |  | October 2, 2021 |  |  |  |  |
| OpComms: |  |  |  |  |  |  |  |  |  |  |  |
| Telecom and Datacom | $ | 360.1 |  | 71.1 | % |  | $ | 216.0 |  | 48.2 | % |  |  |  |  |  |  |
| Industrial and Consumer | 93.3 |  | 18.4 |  |  | 190.0 |  | 42.3 | % |  |  |  |  |  |  |
| Total OpComms | $ | 453.4 |  | 89.5 | % |  | $ | 406.0 |  | 90.5 | % |  |  |  |  |  |  |
| Lasers | 53.4 |  | 10.5 | % |  | 42.4 |  | 9.5 | % |  |  |  |  |  |  |
| Net Revenue | $ | 506.8 |  |  |  | $ | 448.4 |  |  |  |  |  |  |  |  |

- removed (2023-02-09):
[0001628280-22-028783:note_history:69]
| Contract balances |  | Balance sheet location |  | October 1, 2022 |  | July 2, 2022 |  | Change |  | Percentage Change |
| Accounts receivable, net |  | Accounts receivable, net |  | $ | 340.5 |  |  | $ | 262.0 |  |  | $ | 78.5 |  |  | 30.0 | % |
| Deferred revenue and customer deposits |  | Other current liabilities |  | $ | 1.1 |  |  | $ | — |  |  | $ | 1.1 |  |  | n/a |
