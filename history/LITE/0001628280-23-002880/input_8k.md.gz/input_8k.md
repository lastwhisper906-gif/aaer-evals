# LITE 8-K — 0001628280-23-002866 filed 2023-02-09

## item codes, every 8-K on or before 2023-02-09

- 2023-02-09 0001628280-23-002866 — 2.02, 9.01
- 2022-11-21 0001628280-22-030473 — 5.02, 5.07, 9.01
- 2022-11-08 0001628280-22-028758 — 2.02, 9.01
- 2022-08-16 0001628280-22-022980 — 2.02, 9.01
- 2022-08-03 0001193125-22-210674 — 2.01, 8.01, 9.01
- 2022-07-29 0001193125-22-206587 — 8.01, 9.01
- 2022-05-04 0001628280-22-012145 — 2.02, 9.01
- 2022-03-08 0001193125-22-069350 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2022-02-03 0001628280-22-001736 — 2.02, 9.01
- 2022-01-21 0001193125-22-014413 — 8.01, 9.01
- 2021-11-23 0001628280-21-024070 — 5.02, 5.07
- 2021-11-05 0001193125-21-321796 — 1.01, 9.01
- 2021-11-04 0001628280-21-021618 — 2.02, 9.01
- 2021-11-04 0001193125-21-319601 — 8.01, 9.01
- 2021-08-18 0001628280-21-017219 — 2.02, 9.01
- 2021-06-08 0001633978-21-000030 — 5.02, 9.01
- 2021-05-12 0001633978-21-000008 — 2.02, 9.01
- 2021-03-10 0001193125-21-075438 — 1.01, 8.01, 9.01
- 2021-02-02 0001633978-21-000002 — 2.02, 9.01
- 2021-01-19 0001104659-21-005024 — 1.01, 2.02, 8.01, 9.01
- 2020-11-24 0001193125-20-302557 — 5.02, 5.07
- 2020-11-02 0001633978-20-000017 — 2.02, 9.01
- 2020-09-18 0001633978-20-000012 — 5.02, 9.01
- 2020-08-11 0001633978-20-000010 — 2.02, 9.01
- 2020-05-05 0001628280-20-006358 — 2.02, 9.01
- 2020-02-04 0001633978-20-000002 — 2.02, 9.01
- 2019-12-12 0001193125-19-312875 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2019-12-04 0001633978-19-000075 — 8.01
- 2019-11-20 0001633978-19-000074 — 5.07
- 2019-10-31 0001633978-19-000070 — 2.02, 9.01
- 2019-08-08 0001633978-19-000068 — 2.02, 9.01
- 2019-05-08 0001633978-19-000031 — 1.01
- 2019-05-07 0001633978-19-000029 — 2.02, 9.01
- 2019-02-15 0001633978-19-000005 — 9.01 — amendment of 0001193125-18-346211
- 2019-02-08 0001193125-19-031591 — 5.02, 9.01
- 2019-02-05 0001633978-19-000001 — 2.02, 9.01
- 2018-12-10 0001193125-18-346211 — 1.01, 2.01, 2.03, 5.02, 8.01, 9.01
- 2018-12-06 0001633978-18-000150 — 8.01
- 2018-11-14 0001633978-18-000139 — 5.07
- 2018-11-13 0001633978-18-000136 — 3.02
- 2018-11-13 0001633978-18-000132 — 7.01, 9.01
- 2018-11-01 0001628280-18-013238 — 2.02, 9.01
- 2018-08-08 0001633978-18-000056 — 2.02, 9.01
- 2018-06-08 0001193125-18-188241 — 5.02, 9.01
- 2018-05-02 0001633978-18-000029 — 2.02, 9.01
- 2018-03-12 0001193125-18-078154 — 1.01, 2.01, 8.01, 9.01
- 2018-02-06 0001628280-18-001082 — 2.02, 9.01
- 2017-11-08 0001633978-17-000133 — 5.02, 9.01
- 2017-11-07 0001633978-17-000131 — 5.07
- 2017-11-01 0001633978-17-000117 — 2.02, 9.01
- 2017-08-09 0001633978-17-000058 — 2.02, 9.01
- 2017-05-04 0001633978-17-000035 — 2.02, 9.01
- 2017-03-08 0001193125-17-074740 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2017-03-02 0001193125-17-066769 — 8.01, 9.01
- 2017-02-07 0001633978-17-000005 — 2.02, 9.01
- 2017-01-03 0001628280-17-000018 — 4.01, 9.01
- 2016-11-09 0001628280-16-021143 — 5.02, 5.07, 9.01
- 2016-10-27 0001628280-16-020382 — 2.02, 9.01
- 2016-08-09 0001628280-16-018811 — 2.02, 9.01
- 2016-06-21 0001628280-16-017201 — 8.01
- 2016-05-04 0001628280-16-015501 — 2.02, 9.01
- 2016-02-16 0001628280-16-011261 — 5.02, 9.01
- 2016-02-04 0001628280-16-010758 — 5.02, 9.01
- 2016-02-04 0001628280-16-010755 — 2.02, 9.01
- 2015-11-17 0001193125-15-378953 — 7.01
- 2015-11-10 0001628280-15-008606 — 2.02, 9.01
- 2015-09-28 0001193125-15-329665 — 8.01, 9.01
- 2015-08-11 0001193125-15-286405 — 7.01, 9.01
- 2015-08-06 0001193125-15-281219 — 1.01, 5.02, 5.03, 5.05, 8.01, 9.01
- 2015-08-03 0001193125-15-274808 — 5.03, 9.01

## late-filing notifications on or before 2023-02-09

- 2015-11-10 0001628280-15-008612 — NT 10-Q, for the period ended 2015-09-26
- 2015-09-28 0001193125-15-329672 — NT 10-K, for the period ended 2015-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001628280-23-002866:8k_2_02:1]
EX-99.1
2
lite_ex991xq2fy23.htm
EX-99.1

[0001628280-23-002866:8k_2_02:2]
Document

[0001628280-23-002866:8k_2_02:3]
NEWS RELEASE

[0001628280-23-002866:8k_2_02:4]
LUMENTUM ANNOUNCES FISCAL SECOND QUARTER 2023 FINANCIAL RESULTS

[0001628280-23-002866:8k_2_02:5]
•Net revenue of $506.0 million

[0001628280-23-002866:8k_2_02:6]
•GAAP gross margin of 32.8%; Non-GAAP gross margin of 44.9%

[0001628280-23-002866:8k_2_02:7]
•GAAP operating loss of 4.3%; Non-GAAP operating margin of 23.1%

[0001628280-23-002866:8k_2_02:8]
•GAAP diluted net loss per share of $0.46; Non-GAAP diluted net income per share of $1.52

[0001628280-23-002866:8k_2_02:9]
San Jose, Calif., February 9, 2023 – Lumentum Holdings Inc. (“Lumentum” or the “Company”) today reported results for its fiscal second quarter ended December 31, 2022.

[0001628280-23-002866:8k_2_02:10]
“Our second quarter financial and operational performance was very strong, led by robust demand from our Telecom and Commercial Lasers customers. Non-GAAP operating margin and Non-GAAP earnings per share were both above the high end of our guidance range with revenue above the midpoint,” said Alan Lowe, President and CEO. “These results reflect structural improvement in the long-term operating costs of the company, as we continue to execute on our synergy plan.”

[0001628280-23-002866:8k_2_02:11]
Fiscal Second Quarter Highlights:

[0001628280-23-002866:8k_2_02:12]
Net revenue for the fiscal second quarter of 2023 was $506.0 million, with GAAP net loss of $31.7 million, or $0.46 loss per diluted share. Net revenue for the fiscal first quarter of 2023 was $506.8 million, with GAAP net loss of $0.4 million, or $0.01 loss per diluted share. Net revenue for the fiscal second quarter of 2022 was $446.7 million, with GAAP net income of $56.7 million, or $0.75 per diluted share.

[0001628280-23-002866:8k_2_02:13]
Non-GAAP net income for the fiscal second quarter of 2023 was $104.1 million, or $1.52 per diluted share. Non-GAAP net income for fiscal first quarter of 2023 was $119.2 million, or $1.69 per diluted share. Non-GAAP net income for the fiscal second quarter of 2022 was $120.2 million, or $1.60 per diluted share.

[0001628280-23-002866:8k_2_02:14]
The Company held $1,680.4 million in total cash, cash equivalents, and short-term investments at the end of the fiscal second quarter of 2023, up $55.5 million from the end of the fiscal first quarter of 2023.

[0001628280-23-002866:8k_2_02:15]
Financial Overview – Fiscal Second Quarter Ended December 31, 2022

[0001628280-23-002866:8k_2_02:16]
|  | GAAP Results ($ in millions) |
|  | Q2 |  | Q1 |  | Q2 |  | Change |
|  | FY 2023 |  | FY 2023 |  | FY 2022 |  | Q/Q |  | Y/Y |
| Net revenue | $506.0 |  | $506.8 |  | $446.7 |  | (0.2)% |  | 13.3% |
| Gross margin | 32.8% |  | 39.7% |  | 46.5% |  | (690)bps |  | (1,370)bps |
| Operating margin | (4.3)% |  | 2.7% |  | 19.1% |  | (700)bps |  | (2,340)bps |
|  | Non-GAAP Results ($ in millions) |
|  | Q2 |  | Q1 |  | Q2 |  | Change |
|  | FY 2023 |  | FY 2023 |  | FY 2022 |  | Q/Q |  | Y/Y |
| Net revenue | $506.0 |  | $506.8 |  | $446.7 |  | (0.2)% |  | 13.3% |
| Gross margin | 44.9% |  | 48.2% |  | 51.0% |  | (330)bps |  | (610)bps |
| Operating margin | 23.1% |  | 27.1% |  | 31.7% |  | (400)bps |  | (860)bps |

[0001628280-23-002866:8k_2_02:17]
|  | Net Revenue by Segment ($ in millions) |
|  | Q2 |  | % of |  | Q1 |  | Q2 |  | Change |
|  | FY 2023 |  | Net Revenue |  | FY 2023 |  | FY 2022 |  | Q/Q |  | Y/Y |
| Optical Communications | $ | 448.8 |  |  | 88.7 | % |  | $ | 453.4 |  |  | $ | 397.4 |  |  | (1.0) | % |  | 12.9 | % |
| Lasers | 57.2 |  |  | 11.3 | % |  | 53.4 |  |  | 49.3 |  |  | 7.1 | % |  | 16.0 | % |
| Total | $ | 506.0 |  |  | 100.0 | % |  | $ | 506.8 |  |  | $ | 446.7 |  |  | (0.2) | % |  | 13.3 | % |

[0001628280-23-002866:8k_2_02:18]
The tables above provide comparisons of quarterly results to prior periods, including sequential quarterly and year-over-year changes. A reconciliation between GAAP and non-GAAP measures is contained in this release under the section titled “Use of Non-GAAP Financial Measures.”

[0001628280-23-002866:8k_2_02:19]
Business Outlook

[0001628280-23-002866:8k_2_02:20]
Lumentum expects the following for the fiscal third quarter 2023:

[0001628280-23-002866:8k_2_02:21]
•Net revenue in the range of $430 million to $460 million

[0001628280-23-002866:8k_2_02:22]
•Non-GAAP operating margin of 17% to 19%

[0001628280-23-002866:8k_2_02:23]
•Non-GAAP diluted earnings per share of $1.00 to $1.15

[0001628280-23-002866:8k_2_02:24]
We have not provided reconciliations from GAAP to non-GAAP measures for our outlook. A large portion of non-GAAP adjustments, such as restructuring charges, stock-based compensation, non-GAAP income tax reconciling adjustments, acquisition related costs, and other costs and contingencies unrelated to current and future operations are by their nature highly volatile and we have low visibility as to the range that may be incurred in the future.

[0001628280-23-002866:8k_2_02:25]
Related Announcement and Conference Call

[0001628280-23-002866:8k_2_02:26]
Lumentum will host a conference call today, February 9, 2023, at 5:30 am PT / 8:30 am ET to discuss its fiscal second quarter results.  A live webcast of the call and the replay will be available in the Investors section of the Lumentum website at http://investor.lumentum.com through February 16, 2023, at 9:00 pm PT / 12:00 am ET. To listen to the live conference call, dial (844) 200-6205 or (929) 526-1599 and reference the passcode 440258. To access the replay, dial (866) 813-9403 or (929) 458-6194 and reference the passcode 369158. Supporting materials outlining the Company’s latest financial results will be posted on http://investor.lumentum.com under the “Events and Presentations” section concurrently with this earnings press release. Lumentum has used, and intends to continue to use, its Investor Relations website as means of disclosing material nonpublic information and for complying with its disclosure obligations under Regulation FD. This press release is being furnished as an exhibit to a Current Report on Form 8-K filed with the Securities and Exchange Commission and will be available at http://www.sec.gov/.

[0001628280-23-002866:8k_2_02:27]
About Lumentum

[0001628280-23-002866:8k_2_02:28]
Lumentum (NASDAQ: LITE) is a market-leading designer and manufacturer of innovative optical and photonic products enabling optical networking and laser applications worldwide. Lumentum optical components and subsystems are part of virtually every type of telecom, enterprise, and data center network. Lumentum lasers enable advanced manufacturing techniques and diverse applications including next-generation imaging and sensing capabilities. Lumentum is headquartered in San Jose, California with R&D, manufacturing, and sales offices worldwide. For more information, visit www.lumentum.com and follow Lumentum on LinkedIn, Twitter, Facebook, Instagram and YouTube.

[0001628280-23-002866:8k_2_02:29]
Forward-Looking Statements

[0001628280-23-002866:8k_2_02:30]
Contact Information

[0001628280-23-002866:8k_2_02:31]
Investors:    Kathy Ta, 408-750-3853; investor.relations@lumentum.com

[0001628280-23-002866:8k_2_02:32]
Media:        Christina Itzkowitz, 781-929-0565; media@lumentum.com

[0001628280-23-002866:8k_2_02:33]
Category:    Financial

[0001628280-23-002866:8k_2_02:34]
The following financial tables are presented in accordance with GAAP, unless otherwise specified.

[0001628280-23-002866:8k_2_02:35]
LUMENTUM HOLDINGS INC.

[0001628280-23-002866:8k_2_02:36]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001628280-23-002866:8k_2_02:37]
(in millions, except per share data)

[0001628280-23-002866:8k_2_02:38]
(unaudited)

[0001628280-23-002866:8k_2_02:39]
|  | Three Months Ended |  | Six Months Ended |
|  | December 31, 2022 |  | January 1, 2022 |  | December 31, 2022 |  | January 1, 2022 |
| Net revenue | $ | 506.0 |  |  | $ | 446.7 |  |  | $ | 1,012.8 |  |  | $ | 895.1 |  |
| Cost of sales | 315.1 |  |  | 223.3 |  |  | 597.7 |  |  | 423.7 |  |
| Amortization of acquired developed intangibles | 24.7 |  |  | 15.9 |  |  | 47.7 |  |  | 31.7 |  |
| Gross profit | 166.2 |  |  | 207.5 |  |  | 367.4 |  |  | 439.7 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 75.8 |  |  | 53.2 |  |  | 148.5 |  |  | 107.3 |  |
| Selling, general and administrative | 98.4 |  |  | 69.0 |  |  | 204.1 |  |  | 132.3 |  |
| Restructuring and related charges | 13.9 |  |  | 0.1 |  |  | 23.2 |  |  | (1.0) |  |
| Total operating expenses | 188.1 |  |  | 122.3 |  |  | 375.8 |  |  | 238.6 |  |
| Income (loss) from operations | (21.9) |  |  | 85.2 |  |  | (8.4) |  |  | 201.1 |  |
| Interest expense | (8.9) |  |  | (17.1) |  |  | (17.4) |  |  | (34.0) |  |
| Other income, net | 3.7 |  |  | 1.0 |  |  | 17.5 |  |  | 1.6 |  |
| Income (loss) before income taxes | (27.1) |  |  | 69.1 |  |  | (8.3) |  |  | 168.7 |  |
| Provision for income taxes | 4.6 |  |  | 12.4 |  |  | 23.8 |  |  | 30.5 |  |
| Net income (loss) | $ | (31.7) |  |  | $ | 56.7 |  |  | $ | (32.1) |  |  | $ | 138.2 |  |
| Net income (loss) per share: |  |  |  |  |  |  |  |
| Basic | $ | (0.46) |  |  | $ | 0.78 |  |  | $ | (0.47) |  |  | $ | 1.91 |  |
| Diluted | $ | (0.46) |  |  | $ | 0.75 |  |  | $ | (0.47) |  |  | $ | 1.83 |  |
| Shares used to compute net income (loss) per share: |  |  |  |  |  |  |  |
| Basic | 68.3 |  |  | 72.3 |  |  | 68.2 |  |  | 72.5 |  |
| Diluted | 68.3 |  |  | 75.3 |  |  | 68.2 |  |  | 75.4 |  |

[0001628280-23-002866:8k_2_02:40]
LUMENTUM HOLDINGS INC.

[0001628280-23-002866:8k_2_02:41]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001628280-23-002866:8k_2_02:42]
(in millions, except per share data)

[0001628280-23-002866:8k_2_02:43]
(unaudited)

[0001628280-23-002866:8k_2_02:44]
|  | December 31, 2022 |  | July 2, 2022 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 592.1 |  |  | $ | 1,290.2 |  |
| Short-term investments | 1,088.3 |  |  | 1,258.8 |  |
| Accounts receivable, net | 330.5 |  |  | 262.0 |  |
| Inventories | 366.9 |  |  | 250.1 |  |
| Prepayments and other current assets | 114.8 |  |  | 78.1 |  |
| Total current assets | 2,492.6 |  |  | 3,139.2 |  |
| Property, plant and equipment, net | 487.7 |  |  | 360.5 |  |
| Operating lease right-of-use assets, net | 84.9 |  |  | 73.6 |  |
| Goodwill | 698.2 |  |  | 368.9 |  |
| Other intangible assets, net | 539.9 |  |  | 155.7 |  |
| Deferred tax asset | 100.1 |  |  | 27.0 |  |
| Other non-current assets | 14.7 |  |  | 37.3 |  |
| Total assets | $ | 4,418.1 |  |  | $ | 4,162.2 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 205.6 |  |  | $ | 156.7 |  |
| Accrued payroll and related expenses | 60.7 |  |  | 54.6 |  |
| Accrued expenses | 62.1 |  |  | 44.7 |  |
| Short-term debt | 420.7 |  |  | 409.9 |  |
| Operating lease liabilities, current | 14.0 |  |  | 11.2 |  |
| Other current liabilities | 51.2 |  |  | 39.4 |  |
| Total current liabilities | 814.3 |  |  | 716.5 |  |
| Long-term debt | 1,900.3 |  |  | 1,466.1 |  |
| Operating lease liabilities, non-current | 57.0 |  |  | 48.8 |  |
| Deferred tax liability | 25.8 |  |  | 12.9 |  |
| Other non-current liabilities | 77.1 |  |  | 42.9 |  |
| Total liabilities | 2,874.5 |  |  | 2,287.2 |  |
| Stockholders’ equity: |  |  |  |
| Common stock, $0.001 par value, 990 authorized shares, 68.4 and 68.0 shares issued and outstanding as of December 31, 2022 and July 2, 2022, respectively | 0.1 |  |  | 0.1 |  |
| Additional paid-in capital | 1,641.4 |  |  | 2,003.6 |  |
| Accumulated deficit | (101.3) |  |  | (129.1) |  |
| Accumulated other comprehensive income | 3.4 |  |  | 0.4 |  |
| Total stockholders’ equity | 1,543.6 |  |  | 1,875.0 |  |
| Total liabilities and stockholders’ equity | $ | 4,418.1 |  |  | $ | 4,162.2 |  |

[0001628280-23-002866:8k_2_02:45]
Use of Non-GAAP Financial Measures

[0001628280-23-002866:8k_2_02:46]
In this press release, Lumentum provides investors with certain non-GAAP financial measures: gross profit, gross margin, research and development expense, selling, general and administrative expense, operating margin, income from operations, interest and other income (expense), net, income before income taxes, provision for income taxes, net income (loss), and net income (loss) per share on a non-GAAP basis, as well as the non-GAAP measures of EBITDA and Adjusted EBITDA. Lumentum believes this non-GAAP financial information provides additional insight into the Company’s ongoing business operations and results, as well as cash generation, and has therefore chosen to provide this information to investors for a more consistent basis of comparison and to help them evaluate the results of the Company’s ongoing operations and enable more meaningful period to period comparisons. In addition, the Company believes that providing certain of these measures allows investors to better understand the Company’s cash flows and, importantly, to evaluate the efficacy of the methodology and information used by management to evaluate and measure such cash flows. However, these measures may be different from non-GAAP measures used by other companies, limiting their usefulness for comparison purposes. The non-GAAP financial measures used in this press release should not be considered in isolation from measures of financial performance prepared in accordance with GAAP. Investors are cautioned that there are material limitations associated with the use of non-GAAP financial measures as an analytical tool. In particular, many of the adjustments to our GAAP financial measures reflect the exclusion of items that are recurring and will be reflected in our financial results for the foreseeable future. Further, these non-GAAP financial measures may not be comparable to similarly titled measurements reported by other companies.

[0001628280-23-002866:8k_2_02:47]
Our non-GAAP measures used in this press release exclude (i) stock-based compensation, (ii) acquisition related costs,  (iii) amortization of acquired intangibles, (iv) amortization of acquired inventory fair value adjustments, (v) restructuring and related charges, (vi) foreign exchange (gains) losses, net, (vii) non-cash interest expense on convertible notes and other expenses, (viii) non-recurring expenses related to litigation matters, (ix) inventory and fixed assets write down due to product line exits, (x) integration related costs, (xi) non-GAAP income tax reconciling adjustments, and (xii) other (gains) charges related to non-recurring activities.

[0001628280-23-002866:8k_2_02:48]
A quantitative reconciliation between GAAP and non-GAAP financial data with respect to historical periods is included in the supplemental financial table attached to this press release.

[0001628280-23-002866:8k_2_02:49]
LUMENTUM HOLDINGS INC.

[0001628280-23-002866:8k_2_02:50]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001628280-23-002866:8k_2_02:51]
(in millions, except per share data)

[0001628280-23-002866:8k_2_02:52]
(unaudited)

[0001628280-23-002866:8k_2_02:53]
|  | Three Months Ended |  | Six Months Ended |  |
|  | December 31, 2022 |  | October 1, 2022 |  | January 1, 2022 |  | December 31, 2022 |  | January 1, 2022 |  |
| Gross profit on GAAP basis | $ | 166.2 |  |  | $ | 201.2 |  |  | $ | 207.5 |  |  | $ | 367.4 |  |  | $ | 439.7 |  |  |
| Stock-based compensation | 6.7 |  |  | 5.5 |  |  | 5.2 |  |  | 12.2 |  |  | 9.8 |  |  |
| Amortization of acquired intangibles | 24.8 |  |  | 22.9 |  |  | 15.9 |  |  | 47.7 |  |  | 31.7 |  |  |
| Amortization of acquired inventory fair value adjustments | 9.6 |  |  | 4.6 |  |  | — |  |  | 14.2 |  |  | — |  |  |
| Integration related costs | 2.8 |  |  | — |  |  | — |  |  | 2.8 |  |  | — |  |  |
| Inventory and fixed asset write down due to product line exits | — |  |  | — |  |  | 0.1 |  |  | — |  |  | 0.1 |  |  |
| Other (gains) charges, net (1) | 16.9 |  |  | 9.9 |  |  | (0.7) |  |  | 26.8 |  |  | (6.6) |  |  |
| Gross profit on non-GAAP basis | $ | 227.0 |  |  | $ | 244.1 |  |  | $ | 228.0 |  |  | $ | 471.1 |  |  | $ | 474.7 |  |  |
| Gross margin on non-GAAP basis | 44.9 | % |  | 48.2 | % |  | 51.0 | % |  | 46.5 | % |  | 53.0 | % |  |
| Research and development on GAAP basis | $ | 75.8 |  |  | $ | 72.7 |  |  | $ | 53.2 |  |  | $ | 148.5 |  |  | $ | 107.3 |  |  |
| Stock-based compensation | (10.6) |  |  | (9.6) |  |  | (5.4) |  |  | (20.2) |  |  | (10.4) |  |  |
| Integration related costs | (0.8) |  |  | — |  |  | — |  |  | (0.8) |  |  | — |  |  |
| Other charges | — |  |  | (2.3) |  |  | — |  |  | (2.3) |  |  | (0.1) |  |  |
| Research and development on non-GAAP basis | $ | 64.4 |  |  | $ | 60.8 |  |  | $ | 47.8 |  |  | $ | 125.2 |  |  | $ | 96.8 |  |  |
| Selling, general and administrative on GAAP basis | $ | 98.4 |  |  | $ | 105.7 |  |  | $ | 69.0 |  |  | $ | 204.1 |  |  | $ | 132.3 |  |  |
| Stock-based compensation | (19.3) |  |  | (19.6) |  |  | (16.7) |  |  | (38.9) |  |  | (31.9) |  |  |
| Stock-based compensation - acquisition related (2) | — |  |  | (11.9) |  |  | — |  |  | (11.9) |  |  | — |  |  |
| Amortization of acquired intangibles | (11.3) |  |  | (9.3) |  |  | (5.6) |  |  | (20.6) |  |  | (11.2) |  |  |
| Acquisition related costs (3) | — |  |  | (16.2) |  |  | — |  |  | (16.2) |  |  | — |  |  |
| Integration related costs | (4.4) |  |  | (0.6) |  |  | — |  |  | (5.0) |  |  | — |  |  |
| Litigation matters (5) | (7.8) |  |  | — |  |  | — |  |  | (7.8) |  |  | — |  |  |
| Other charges, net | (9.7) |  |  | (2.2) |  |  | (8.1) |  |  | (11.9) |  |  | (11.8) |  |  |
| Selling, general and administrative on non-GAAP basis | $ | 45.9 |  |  | $ | 45.9 |  |  | $ | 38.6 |  |  | $ | 91.8 |  |  | $ | 77.4 |  |  |
| Income from operations on GAAP basis | $ | (21.9) |  |  | $ | 13.5 |  |  | $ | 85.2 |  |  | $ | (8.4) |  |  | $ | 201.1 |  |  |
| Stock-based compensation | 36.6 |  |  | 34.7 |  |  | 27.3 |  |  | 71.3 |  |  | 52.1 |  |  |
| Stock-based compensation - acquisition related (2) | — |  |  | 11.9 |  |  | — |  |  | 11.9 |  |  | — |  |  |
| Amortization of acquired intangibles | 36.1 |  |  | 32.2 |  |  | 21.5 |  |  | 68.3 |  |  | 42.9 |  |  |
| Amortization of acquired inventory fair value adjustments | 9.6 |  |  | 4.6 |  |  | — |  |  | 14.2 |  |  | — |  |  |
| Acquisition related costs (3) | — |  |  | 16.2 |  |  | — |  |  | 16.2 |  |  | — |  |  |
| Integration related costs | 8.0 |  |  | 0.6 |  |  |  |  | 8.6 |  |  | — |  |  |
| Restructuring and related charges (4) | 13.9 |  |  | 9.3 |  |  | 0.1 |  |  | 23.2 |  |  | (1.0) |  |  |
| Litigation matters (5) | 7.8 |  |  | — |  |  | — |  |  | 7.8 |  |  | — |  |  |
| Inventory and fixed asset write down due to product line exits | — |  |  | — |  |  | 0.1 |  |  | — |  |  | 0.1 |  |  |

[0001628280-23-002866:8k_2_02:54]
| Other charges, net | 26.6 |  |  | 14.4 |  |  | 7.4 |  |  | 41.0 |  |  | 5.3 |  |  |
| Income from operations on non-GAAP basis | $ | 116.7 |  |  | $ | 137.4 |  |  | $ | 141.6 |  |  | $ | 254.1 |  |  | $ | 300.5 |  |  |
| Operating margin on non-GAAP basis | 23.1 | % |  | 27.1 | % |  | 31.7 | % |  | 25.1 | % |  | 33.6 | % |  |
| Interest and other income (expense), net on GAAP basis | $ | (5.2) |  |  | $ | 5.3 |  |  | $ | (16.1) |  |  | $ | 0.1 |  |  | $ | (32.4) |  |  |
| Foreign exchange (gains) losses, net | 4.1 |  |  | (9.0) |  |  | (0.7) |  |  | (4.9) |  |  | (0.6) |  |  |
| Non-cash interest expense on convertible notes and other expenses | 6.2 |  |  | 5.7 |  |  | 15.8 |  |  | 11.9 |  |  | 31.1 |  |  |
| Interest and other income (expense), net on non-GAAP basis | $ | 5.1 |  |  | $ | 2.0 |  |  | $ | (1.0) |  |  | $ | 7.1 |  |  | $ | (1.9) |  |  |
| Income before income taxes on GAAP basis | $ | (27.1) |  |  | $ | 18.8 |  |  | $ | 69.1 |  |  | $ | (8.3) |  |  | $ | 168.7 |  |  |
| Stock-based compensation | 36.6 |  |  | 34.7 |  |  | 27.3 |  |  | 71.3 |  |  | 52.1 |  |  |
| Stock-based compensation - acquisition related (2) | — |  |  | 11.9 |  |  | — |  |  | 11.9 |  |  | — |  |  |
| Acquisition related costs (3) | — |  |  | 16.2 |  |  | — |  |  | 16.2 |  |  | — |  |  |
| Integration related costs | 8.0 |  |  | 0.6 |  |  | — |  |  | 8.6 |  |  | — |  |  |
| Amortization of acquired intangibles | 36.1 |  |  | 32.2 |  |  | 21.5 |  |  | 68.3 |  |  | 42.9 |  |  |
| Amortization of acquired inventory fair value adjustments | 9.6 |  |  | 4.6 |  |  | — |  |  | 14.2 |  |  | — |  |  |
| Restructuring and related charges (4) | 13.9 |  |  | 9.3 |  |  | 0.1 |  |  | 23.2 |  |  | (1.0) |  |  |
| Litigation matters (5) | 7.8 |  |  | — |  |  | — |  |  | 7.8 |  |  | — |  |  |
| Foreign exchange (gains) losses, net | 4.1 |  |  | (9.0) |  |  | (0.7) |  |  | (4.9) |  |  | (0.6) |  |  |
| Non-cash interest expense on convertible notes and other expenses | 6.2 |  |  | 5.7 |  |  | 15.8 |  |  | 11.9 |  |  | 31.1 |  |  |
| Inventory and fixed asset write down due to product line exits | — |  |  | — |  |  | 0.1 |  |  | — |  |  | 0.1 |  |  |
| Other charges, net | 26.6 |  |  | 14.4 |  |  | 7.4 |  |  | 41.0 |  |  | 5.3 |  |  |
| Income before income taxes on non-GAAP basis | $ | 121.8 |  |  | $ | 139.4 |  |  | $ | 140.6 |  |  | $ | 261.2 |  |  | $ | 298.6 |  |  |
| Provision for income taxes on GAAP basis | $ | 4.6 |  |  | $ | 19.2 |  |  | $ | 12.4 |  |  | $ | 23.8 |  |  | $ | 30.5 |  |  |
| Non-GAAP income tax reconciling adjustments | 13.1 |  |  | 1.0 |  |  | 8.0 |  |  | 14.1 |  |  | 12.8 |  |  |
| Provision for income taxes on non-GAAP basis | $ | 17.7 |  |  | $ | 20.2 |  |  | $ | 20.4 |  |  | $ | 37.9 |  |  | $ | 43.3 |  |  |
| Net income (loss) on GAAP basis | $ | (31.7) |  |  | $ | (0.4) |  |  | $ | 56.7 |  |  | $ | (32.1) |  |  | $ | 138.2 |  |  |
| Stock-based compensation | 36.6 |  |  | 34.7 |  |  | 27.3 |  |  | 71.3 |  |  | 52.1 |  |  |
| Stock-based compensation - acquisition related (2) | — |  |  | 11.9 |  |  | — |  |  | 11.9 |  |  | — |  |  |
| Inventory and fixed asset write down due to product line exits | — |  |  | — |  |  | 0.1 |  |  | — |  |  | 0.1 |  |  |
| Acquisition related costs (3) | — |  |  | 16.2 |  |  | — |  |  | 16.2 |  |  | — |  |  |
| Integration related costs | 8.0 |  |  | 0.6 |  |  | — |  |  | 8.6 |  |  | — |  |  |
| Amortization of acquired intangibles | 36.1 |  |  | 32.2 |  |  | 21.5 |  |  | 68.3 |  |  | 42.9 |  |  |
| Amortization of acquired inventory fair value adjustments | 9.6 |  |  | 4.6 |  |  | — |  |  | 14.2 |  |  | — |  |  |
| Restructuring and related charges (4) | 13.9 |  |  | 9.3 |  |  | 0.1 |  |  | 23.2 |  |  | (1.0) |  |  |
| Litigation matters (5) | 7.8 |  |  | — |  |  | — |  |  | 7.8 |  |  | — |  |  |
| Foreign exchange (gains) losses, net | 4.1 |  |  | (9.0) |  |  | (0.7) |  |  | (4.9) |  |  | (0.6) |  |  |
| Non-cash interest expense on convertible notes and other expenses | 6.2 |  |  | 5.7 |  |  | 15.8 |  |  | 11.9 |  |  | 31.1 |  |  |
| Non-GAAP income tax reconciling adjustments | (13.1) |  |  | (1.0) |  |  | (8.0) |  |  | (14.1) |  |  | (12.8) |  |  |

[0001628280-23-002866:8k_2_02:55]
| Other charges, net | 26.6 |  |  | 14.4 |  |  | 7.4 |  |  | 41.0 |  |  | 5.3 |  |  |
| Net income on non-GAAP basis | $ | 104.1 |  |  | $ | 119.2 |  |  | $ | 120.2 |  |  | $ | 223.3 |  |  | $ | 255.3 |  |  |
| Net income per share on non-GAAP basis | $ | 1.52 |  |  | $ | 1.69 |  |  | $ | 1.60 |  |  | $ | 3.20 |  |  | $ | 3.39 |  |  |
| Shares used in per share calculation - diluted on GAAP basis | 68.3 |  |  | 68.1 |  |  | 75.3 |  |  | 68.2 |  |  | 75.4 |  |  |
| Non-GAAP adjustment (6) | 0.3 |  |  | 2.5 |  |  | — |  |  | 1.5 |  |  | — |  |  |
| Shares used in per share calculation - diluted on non-GAAP basis | 68.6 |  |  | 70.6 |  |  | 75.3 |  |  | 69.7 |  |  | 75.4 |  |  |

[0001628280-23-002866:8k_2_02:56]
(1) Other gains (charges) excluded in deriving non-GAAP gross profit for the three and six months ended December 31, 2022 primarily relate to $11.7 million and $19.0 million, respectively, of incremental charges to acquire components from various brokers to satisfy customer demand.

[0001628280-23-002866:8k_2_02:57]
(2) In connection with the NeoPhotonics merger, certain equity awards for NeoPhotonics employees were accelerated. The total stock-based compensation associated with the acceleration was $11.9 million for the six months ended December 31, 2022, of which $9.0 million was settled in cash.

[0001628280-23-002866:8k_2_02:58]
(3) Acquisition related costs of $16.2 million during the six months ended December 31, 2022 mainly include professional, advisory and legal service fees related to the merger with NeoPhotonics and the acquisition of IPG Photonics’ telecom transmission product lines during the fiscal first quarter of 2023.

[0001628280-23-002866:8k_2_02:59]
(4) During the three months ended December 31, 2022, we recorded restructuring and related charges of $13.9 million in our condensed consolidated statements of operations, which was primarily due to company-wide integration efforts as a result of the merger with NeoPhotonics, as well as our cost reduction initiatives.

[0001628280-23-002866:8k_2_02:60]
During the six months ended December 31, 2022, we recorded restructuring and related charges of $23.2 million in our condensed consolidated statements of operations, which was primarily attributable to company-wide integration efforts as a result of the merger with NeoPhotonics, our cost reduction initiatives, as well as severance and employee-related benefits associated with NeoPhotonics’ executive severance and retention agreements. These agreements provide for payments and benefits upon an involuntary termination of employment under certain circumstances.

[0001628280-23-002866:8k_2_02:61]
(5) During the three months ended December 31, 2022, we recorded a charge of $7.8 million with respect to the settlement of  certain non-ordinary course litigation matters.

[0001628280-23-002866:8k_2_02:62]
(6) Shares used for net income per share on non-GAAP basis include incremental dilutive shares that would occur upon conversion of our convertible notes assuming we settle the face value of the notes in cash as the Company intends, and shares related to restricted stock units (“RSUs”) and shares issuable under our Employee Stock Purchase Plan that are anti-dilutive on GAAP basis.

[0001628280-23-002866:8k_2_02:63]
LUMENTUM HOLDINGS INC.

[0001628280-23-002866:8k_2_02:64]
RECONCILIATION OF GAAP NET INCOME TO ADJUSTED EBITDA

[0001628280-23-002866:8k_2_02:65]
(in millions, except per share data)

[0001628280-23-002866:8k_2_02:66]
(unaudited)

[0001628280-23-002866:8k_2_02:67]
|  | Three Months Ended |  |  |  | Six Months Ended |
|  | December 31, 2022 |  |  |  | October 1, 2022 |  | January 1, 2022 |  |  |  |  |  | December 31, 2022 |  | January 1, 2022 |
| GAAP net income (loss) | $ | (31.7) |  |  |  |  | $ | (0.4) |  |  | $ | 56.7 |  |  |  |  |  |  | $ | (32.1) |  |  | $ | 138.2 |  |
| Interest and other expense, net | 5.2 |  |  |  |  | (5.3) |  |  | 16.1 |  |  |  |  |  |  | (0.1) |  |  | 32.4 |  |
| Provision for income taxes | 4.6 |  |  |  |  | 19.2 |  |  | 12.4 |  |  |  |  |  |  | 23.8 |  |  | 30.5 |  |
| Depreciation | 26.4 |  |  |  |  | 24.5 |  |  | 20.6 |  |  |  |  |  |  | 50.9 |  |  | 41.0 |  |
| Amortization of acquired intangibles | 36.1 |  |  |  |  | 32.2 |  |  | 21.5 |  |  |  |  |  |  | 68.3 |  |  | 42.9 |  |
| EBITDA | 40.6 |  |  |  |  | 70.2 |  |  | 127.3 |  |  |  |  |  |  | 110.8 |  |  | 285.0 |  |
| Amortization of inventory fair value adjustments | 9.6 |  |  |  |  | 4.6 |  |  | — |  |  |  |  |  |  | 14.2 |  |  | — |  |
| Restructuring and related charges | 13.9 |  |  |  |  | 9.3 |  |  | 0.1 |  |  |  |  |  |  | 23.2 |  |  | (1.0) |  |
| Stock-based compensation | 36.6 |  |  |  |  | 46.6 |  |  | 27.3 |  |  |  |  |  |  | 83.2 |  |  | 52.1 |  |
| Acquisition related costs | — |  |  |  |  | 16.2 |  |  | — |  |  |  |  |  |  | 16.2 |  |  | — |  |
| Inventory and fixed asset write down due to product line exits | — |  |  |  |  | — |  |  | 0.1 |  |  |  |  |  |  | — |  |  | 0.1 |  |
| Integration related costs | 8.0 |  |  |  |  | 0.6 |  |  | — |  |  |  |  |  |  | 8.6 |  |  | — |  |
| Other charges, net | 24.7 |  |  |  |  | 14.4 |  |  | 7.6 |  |  |  |  |  |  | 39.1 |  |  | 5.7 |  |
| Adjusted EBITDA | $ | 133.4 |  |  |  |  | $ | 161.9 |  |  | $ | 162.4 |  |  |  |  |  |  | $ | 295.3 |  |  | $ | 341.9 |  |
