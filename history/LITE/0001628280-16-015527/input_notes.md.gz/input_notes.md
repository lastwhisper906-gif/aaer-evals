# LITE notes — 0001628280-16-015527


## lite:PropertyPlantandEquipmentNetTableTextBlock

[0001628280-16-015527:notes:1]
[same as prior period, unchanged from 0001628280-16-010773:notes:1]

[0001628280-16-015527:notes:2]
|  | April 2, 2016 |  | June 27, 2015 |
| Land | $ | 5.9 |  |  | $ | 5.9 |  |
| Buildings and improvement | 28.8 |  |  | 28.6 |  |
| Machinery and equipment | 340.3 |  |  | 326.4 |  |
| Furniture and fixtures and software | 31.8 |  |  | 8.0 |  |
| Leasehold improvements | 27.9 |  |  | 20.5 |  |
| Construction in progress | 56.1 |  |  | 26.8 |  |
|  | 490.8 |  |  | 416.2 |  |
| Less: Accumulated depreciation | (322.7 | ) |  | (273.0 | ) |
| Property, plant and equipment, net | $ | 168.1 |  |  | $ | 143.2 |  |


## lite:ScheduleOfOtherLiabilitiesCurrentTableTextBlock

[0001628280-16-015527:notes:3]
[same as prior period, unchanged from 0001628280-16-010773:notes:3]

[0001628280-16-015527:notes:4]
|  | April 2, 2016 |  | June 27, 2015 |
| Restructuring accrual and related charges | $ | 3.8 |  |  | $ | 3.2 |  |
| Warranty accrual | 1.8 |  |  | 2.8 |  |
| Others | 4.2 |  |  | 5.4 |  |
| Other current liabilities | $ | 9.8 |  |  | $ | 11.4 |  |


## lite:ScheduleOfOtherLiabilitiesNoncurrentTableTextBlock

[0001628280-16-015527:notes:5]
[same as prior period, unchanged from 0001628280-16-010773:notes:5]

[0001628280-16-015527:notes:6]
|  | April 2, 2016 |  | June 27, 2015 |
| Asset retirement obligation | 2.3 |  |  | 1.8 |  |
| Pension and related accruals | 2.3 |  |  | 2.1 |  |
| Deferred rent | 1.8 |  |  | 1.7 |  |
| Restructuring accrual and related charges | — |  |  | 1.7 |  |
| Other non-current liabilities | 2.3 |  |  | 2.5 |  |
| Other non-current liabilities | $ | 8.7 |  |  | $ | 9.8 |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001628280-16-015527:notes:7]
[same as prior period, unchanged from 0001628280-16-010773:notes:7]

[0001628280-16-015527:notes:8]
[same as prior period, unchanged from 0001628280-16-010773:notes:8]

[0001628280-16-015527:notes:9]
As of April 2, 2016, our accounts receivable allowance was $1.1 million. Our accounts receivable allowance as of June 27, 2015 was 1.2 million.

[0001628280-16-015527:notes:10]
[same as prior period, unchanged from 0001628280-16-010773:notes:10]

[0001628280-16-015527:notes:11]
[same as prior period, unchanged from 0001628280-16-010773:notes:11]

[0001628280-16-015527:notes:12]
|  | April 2, 2016 |  | June 27, 2015 |
| Finished goods | $ | 51.3 |  |  | $ | 60.1 |  |
| Work in process | 24.8 |  |  | 23.4 |  |
| Raw materials and purchased parts | 31.1 |  |  | 16.2 |  |
| Inventories | $ | 107.2 |  |  | $ | 99.7 |  |

[0001628280-16-015527:notes:13]
During the three and nine months ended April 2, 2016, we wrote off $9.6 million and $10.7 million of inventory, respectively.

[0001628280-16-015527:notes:14]
During the three and nine months ended March 28, 2015, we wrote off $1.4 million and $3.4 million of inventory, respectively.

[0001628280-16-015527:notes:15]
[same as prior period, unchanged from 0001628280-16-010773:notes:15]

[0001628280-16-015527:notes:16]
[same as prior period, unchanged from 0001628280-16-010773:notes:16]

[0001628280-16-015527:notes:17]
|  | April 2, 2016 |  | June 27, 2015 |
| Prepayments | $ | 29.7 |  |  | $ | 20.4 |  |
| Advances to contract manufacturers | 8.2 |  |  | 9.5 |  |
| Due from Viavi, net | 3.3 |  |  | — |  |
| Other current assets | 17.5 |  |  | 16.2 |  |
| Prepayments and other current assets | $ | 58.7 |  |  | $ | 46.1 |  |

[0001628280-16-015527:notes:18]
[same as prior period, unchanged from 0001628280-16-010773:notes:18]

[0001628280-16-015527:notes:19]
[same as prior period, unchanged from 0001628280-16-010773:notes:19]

[0001628280-16-015527:notes:20]
[same as prior period, unchanged from 0001628280-16-010773:notes:20]

[0001628280-16-015527:notes:21]
[same as prior period, unchanged from 0001628280-16-010773:notes:21]


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001628280-16-015527:notes:22]
[same as prior period, unchanged from 0001628280-16-010773:notes:22]

[0001628280-16-015527:notes:23]
[same as prior period, unchanged from 0001628280-16-010773:notes:23]

[0001628280-16-015527:notes:24]
On July 31, 2015, prior to the Separation, Viavi transferred substantially all of the assets and liabilities and operations of the CCOP segment and WaveReady product lines to Lumentum (the “Capitalization"). Financial statements for periods prior to the Capitalization were prepared on a stand-alone basis and were derived from Viavi’s consolidated financial statements and accounting records. For the period from June 28, 2015 to August 1, 2015, expenses were allocated to us using estimates that we consider to be a reasonable reflection of the utilization of services provided to, or benefits received by, us.

[0001628280-16-015527:notes:25]
The preparation of the consolidated financial statements in accordance with GAAP in the United States requires management to make estimates and assumptions that affect the amounts reported in our consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact the company in the future, actual results may be different from the estimates. Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are revenue recognition, inventory valuation, allocation methods and allocated expenses from Viavi, valuation of goodwill and other intangible assets, share-based compensation, retirement and post-retirement plan assumptions, restructuring, warranty and accounting for income taxes.

[0001628280-16-015527:notes:26]
See "Note 3. Related Party Transactions" in the consolidated financial statements for further information regarding the relationships we had with Viavi and other Viavi entities.

[0001628280-16-015527:notes:27]
[same as prior period, unchanged from 0001628280-16-010773:notes:27]


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001628280-16-015527:notes:28]
[same as prior period, unchanged from 0001628280-16-010773:notes:28]

[0001628280-16-015527:notes:29]
[same as prior period, unchanged from 0001628280-16-010773:notes:29]

[0001628280-16-015527:notes:30]
On January 27, 2014 ("Time-Bandwidth Closing Date"), we completed the acquisition of Time-Bandwidth Products, Inc. ("Time-Bandwidth"), a privately-held company headquartered in Switzerland. Time-Bandwidth is a provider of high-powered and ultrafast lasers for industrial and scientific markets. We acquired all outstanding shares of Time-Bandwidth for a purchase price consideration of $15.0 million in cash, including a holdback amount of approximately $2.3 million which had been withheld to satisfy potential breaches of representations and warranties. During the first quarter of fiscal 2016, and after the separation from Viavi, we released the holdback amount of $2.3 million following the eighteen-month anniversary of the Time-Bandwidth Closing Date. The payment is classified as a financing activity within the consolidated statements of cash flows for the nine months ended   April 2, 2016.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001628280-16-015527:notes:31]
[same as prior period, unchanged from 0001628280-16-010773:notes:31]

[0001628280-16-015527:notes:32]
[same as prior period, unchanged from 0001628280-16-010773:notes:32]

[0001628280-16-015527:notes:33]
[same as prior period, unchanged from 0001628280-16-010773:notes:33]

[0001628280-16-015527:notes:34]
[same as prior period, unchanged from 0001628280-16-010773:notes:34]

[0001628280-16-015527:notes:35]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Our fiscal 2016 is a 53-week year ending on July 2, 2016 and our third quarter of fiscal 2016 included one additional week. Our fiscal 2015 ended on June 27, 2015 and was a 52-week year.

[0001628280-16-015527:notes:36]
Principles of Consolidation

[0001628280-16-015527:notes:37]
[same as prior period, unchanged from 0001628280-16-010773:notes:37]

[0001628280-16-015527:notes:38]
[same as prior period, unchanged from 0001628280-16-010773:notes:38]

[0001628280-16-015527:notes:39]
The preparation of our consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amount of assets and liabilities at the date of the financial statements, the reported amount of net revenue and expenses and the disclosure of commitments and contingencies during the reporting periods. We base estimates on historical experience and on various assumptions about the future believed to be reasonable based on available information. Our reported financial position or results of operations may be materially different under changed conditions or when using different estimates and assumptions, particularly with respect to significant accounting policies. If estimates or assumptions differ from actual results, subsequent periods are adjusted to reflect more current information.

[0001628280-16-015527:notes:40]
[same as prior period, unchanged from 0001628280-16-010773:notes:40]

[0001628280-16-015527:notes:41]
There have been no material changes in our significant accounting policies during the nine months ended April 2, 2016 compared to the significant accounting policies described in our Annual Report on Form 10-K/A for the fiscal year ended June 27, 2015. The accompanying unaudited interim consolidated financial statements and accompanying related notes should be read in conjunction with the consolidated financial statements and related notes included in our Annual Report on Form 10-K/A for the fiscal year ended June 27, 2015.

[0001628280-16-015527:notes:42]
[same as prior period, unchanged from 0001628280-16-010773:notes:42]

[0001628280-16-015527:notes:43]
During the three months ended April 2, 2016, we identified an error relating to stock-based compensation expense for the three months ended December 26, 2015 in which stock-based compensation expense of $1.0 million was excluded for a specific restricted stock grant. Additionally, we identified an error relating to the overstatement of sales and use tax accrual of $0.2 million and $0.3 million for the three months ended September 26, 2015 and December 26, 2015, respectively. During the three months ended December 26, 2015, we identified an error relating to the determination of the accretion amount of Series A preferred stock for the three months ended September 26, 2015 in which the accretion of the discount related to issuance cost of $2.0 million was excluded. As a result, our net loss attributable to common stockholders and basic and diluted net loss per share attributable to common stockholders included in our quarterly report on Form 10-Q ("Form 10-Q") for the three months ended September 26, 2015 was understated by $1.8 million and $0.03 per basic and diluted share, respectively. Our net income attributable to common stockholders and basic and diluted net income per share attributable to common stockholders included in Form 10-Q for the three months ended December 26, 2015 was understated by $1.3 million and $0.02 per basic and diluted share, respectively. The correction of the errors identified in the three months ended April 2, 2016 resulted in an overstatement of net loss per share attributable to common stockholders by $0.5 million and $0.01 per basic and diluted share.

[0001628280-16-015527:notes:44]
We assessed the materiality of these errors and determined that the above errors were not material to our unaudited consolidated financial statements as of each of the periods mentioned above.


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0001628280-16-015527:notes:45]
Note 13. Commitments and Contingencies

[0001628280-16-015527:notes:46]
Operating Leases

[0001628280-16-015527:notes:47]
We lease certain real and personal property from unrelated third parties under non-cancellable operating leases that expire at various dates through fiscal 2026. Certain leases require us to pay property taxes, insurance and routine maintenance, and include escalation clauses. As of April 2, 2016 the future minimum annual lease payments under non-cancellable operating leases were as follows (in millions):

[0001628280-16-015527:notes:48]
| Remainder of 2016 | $ | 1.7 |  |
| 2017 | 6.8 |  |
| 2018 | 5.6 |  |
| 2019 | 3.9 |  |
| 2020 | 2.8 |  |
| Thereafter | 5.7 |  |
| Total minimum operating lease payments | $ | 26.5 |  |

[0001628280-16-015527:notes:49]
Included in the future minimum lease payments table above is $0.7 million related to lease commitments in connection with our restructuring and related activities. Refer to "Note 10. Restructuring and Related Charges" for more information.

[0001628280-16-015527:notes:50]
Purchase Obligations

[0001628280-16-015527:notes:51]
Purchase obligations of $164.4 million as of April 2, 2016, represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule and adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

[0001628280-16-015527:notes:52]
We depend on a limited number of contract manufacturers, subcontractors and suppliers for raw materials, packages and standard components. We generally purchase these single or limited source products through standard purchase orders or one-year supply agreements and have no significant long-term guaranteed supply agreements with such vendors. While we seek to maintain a sufficient safety stock of such products and maintain on-going communications with our suppliers to guard against interruptions or cessation of supply, our business and results of operations could be adversely affected by a stoppage or delay of supply, substitution of more expensive or less reliable products, receipt of defective parts or contaminated materials, increases in the price of such supplies, or our inability to obtain reduced pricing from our suppliers in response to competitive pressures.

[0001628280-16-015527:notes:53]
Product Warranties

[0001628280-16-015527:notes:54]
We provide reserves for the estimated costs of product warranties at the time revenue is recognized. We typically offer a twelve month warranty for most of our products. However, in some instances depending upon the product, product component or application of our products by the end customer, our warranties can vary and generally range from six to thirty-six months. We estimate the costs of our warranty obligations on an annualized basis based on our historical experience of known product failure rates, use of materials to repair or replace defective products and service delivery costs incurred in correcting product failures. In addition, from time to time, specific warranty accruals may be made if unforeseen technical problems arise with specific products. We assess the adequacy of our recorded warranty liabilities and adjust the amounts as necessary.

[0001628280-16-015527:notes:55]
The following table presents the changes in our warranty reserve during the three and nine months ended April 2, 2016 and March 28, 2015 (in millions):

[0001628280-16-015527:notes:56]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 2, 2016 |  | March 28, 2015 |  | April 2, 2016 |  | March 28, 2015 |
| Balance as of beginning of period | $ | 3.1 |  |  | $ | 2.0 |  |  | $ | 2.8 |  |  | $ | 2.7 |  |
| Provision for warranty | 0.8 |  |  | 0.8 |  |  | 2.5 |  |  | 2.3 |  |
| Utilization of reserve | (0.8 | ) |  | (0.7 | ) |  | (2.3 | ) |  | (2.8 | ) |
| Adjustments related to pre-existing warranties (including changes in estimates) | (1.3 | ) |  | (0.3 | ) |  | (1.2 | ) |  | (0.4 | ) |
| Balance as of end of period | $ | 1.8 |  |  | $ | 1.8 |  |  | $ | 1.8 |  |  | $ | 1.8 |  |

[0001628280-16-015527:notes:57]
Environmental Liabilities

[0001628280-16-015527:notes:58]
Our R&D, manufacturing and distribution operations involve the use of hazardous substances and are regulated under international, federal, state and local laws governing health and safety and the environment. We apply strict standards for protection of the environment and occupational health and safety to sites inside and outside the United States, even if not subject to regulations imposed by foreign governments. We believe that our properties and operations at our facilities comply in all material respects with applicable environmental laws and occupational health and safety laws. However, the risk of environmental liabilities cannot be completely eliminated and there can be no assurance that the application of environmental and health and safety laws will not require us to incur significant expenditures. We are also regulated under a number of international, federal, state and local laws regarding recycling, product packaging and product content requirements. The environmental, product content/disposal and recycling laws are gradually becoming more stringent and may cause us to incur significant expenditures in the future.

[0001628280-16-015527:notes:59]
In connection with the Separation, we agreed to indemnify Viavi for any liability associated with contamination from past operations at all properties transferred to us from Viavi, to the extent the resulting issues primarily related to our business.

[0001628280-16-015527:notes:60]
Legal Proceedings

[0001628280-16-015527:notes:61]
We are subject to a variety of claims and suits that arise from time to time in the ordinary course of our business. While management currently believes that resolving claims against us, individually or in the aggregate, will not have a material adverse impact on our financial position, results of operations or statement of cash flows, these matters are subject to inherent uncertainties and management's view of these matters may change in the future. Were an unfavorable final outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the effect becomes reasonably estimable.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001628280-16-015527:notes:62]
[same as prior period, unchanged from 0001628280-16-010773:notes:61]

[0001628280-16-015527:notes:63]
[same as prior period, unchanged from 0001628280-16-010773:notes:62]

[0001628280-16-015527:notes:64]
At April 2, 2016 and June 27, 2015, balances for the components of accumulated other comprehensive income were as follows (in millions):

[0001628280-16-015527:notes:65]
|  | Foreign currency translation adjustments |  | Defined benefit obligation, net of tax |  | Total |
| Beginning balance as of June 27, 2015 | $ | 13.7 |  |  | $ | (1.2 | ) |  | $ | 12.5 |  |
| Other comprehensive loss | (3.2 | ) |  | — |  |  | (3.2 | ) |
| Ending balance as of April 2, 2016 | $ | 10.5 |  |  | $ | (1.2 | ) |  | $ | 9.3 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001628280-16-015527:notes:66]
[same as prior period, unchanged from 0001628280-16-010773:notes:65]

[0001628280-16-015527:notes:67]
We estimate the fair value of the embedded derivative for the Series A Preferred Stock using the binomial lattice model. We applied the binomial lattice model to value the embedded derivative using a "with-and-without method," where the value of the Series A Preferred Stock including the embedded derivative, is defined as the "with", and the value of the Series A Preferred Stock excluding the embedded derivative, is defined as the "without". This method estimates the value of the embedded derivative by looking at the difference in the values between the Series A Preferred Stock with the embedded derivative and the value of the Series A Preferred Stock without the embedded derivative. The lattice model requires the following inputs: (i) the Company's common stock price; (ii) conversion price; (iii) term; (iv) yield; (v) recovery rate; (vi) estimated stock volatility; and (vii) risk-free rate. The fair value of the embedded derivative was determined using level 3 inputs under the fair value hierarchy (unobservable inputs). Changes in the inputs into this valuation model have a significant impact in the estimated fair value of the embedded derivative. For example, a decrease (increase) in the stock price results in a decrease (increase) in the estimated fair value of the embedded derivative. The changes in the fair value of the bifurcated embedded derivative of $4.8 million and $5.0 million for the three and nine months ended April 2, 2016, respectively, is primarily related to the change in the price of the Company's underlying common stock and is reflected in the consolidated statements of operations as "Unrealized loss on derivative liability".

[0001628280-16-015527:notes:68]
The following table provides a reconciliation of the fair value of the embedded derivative for the Series A Preferred Stock measured by significant unobservable inputs (Level 3) for the three and nine months ended April 2, 2016:

[0001628280-16-015527:notes:69]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 2, 2016 |  | March 28, 2015 |  | April 2, 2016 |  | March 28, 2015 |
| Balance as of beginning of period | $ | 9.9 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Fair value of the embedded derivative for the Series A Preferred Stock at issuance | — |  |  | — |  |  | 9.7 |  |  | — |  |
| Unrealized loss included in net income | 4.8 |  |  | — |  |  | 5.0 |  |  | — |  |
| Balance as of end of period | $ | 14.7 |  |  | $ | — |  |  | $ | 14.7 |  |  | $ | — |  |

[0001628280-16-015527:notes:70]
The following table summarizes the assumptions used to determine the fair value of the embedded derivative:

[0001628280-16-015527:notes:71]
|  | April 2, 2016 |
| Stock price | $ | 26.58 |  |
| Conversion price | $ | 24.63 |  |
| Expected term (years) | 4.36 |  |
| Expected annual volatility | 40.00 | % |
| Risk-free rate | 1.25 | % |
| Expected common dividend yield | — | % |
| Preferred yield | 9.12 | % |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001628280-16-015527:notes:72]
[same as prior period, unchanged from 0001628280-16-010773:notes:67]

[0001628280-16-015527:notes:73]
[same as prior period, unchanged from 0001628280-16-010773:notes:68]

[0001628280-16-015527:notes:74]
[same as prior period, unchanged from 0001628280-16-010773:notes:69]

[0001628280-16-015527:notes:75]
The impact on our results of operations of recording stock-based compensation by function for the three and nine months ended April 2, 2016 and March 28, 2015 was as follows (in millions):

[0001628280-16-015527:notes:76]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 2, 2016 |  | March 28, 2015 |  | April 2, 2016 |  | March 28, 2015 |
| Cost of sales | $ | 2.2 |  |  | $ | 1.2 |  |  | $ | 4.9 |  |  | $ | 3.8 |  |
| Research and development | 2.5 |  |  | 1.9 |  |  | 6.7 |  |  | 5.6 |  |
| Selling, general and administrative | 3.5 |  |  | 4.3 |  |  | 9.4 |  |  | 11.6 |  |
|  | $ | 8.2 |  |  | $ | 7.4 |  |  | $ | 21.0 |  |  | $ | 21.0 |  |

[0001628280-16-015527:notes:77]
Approximately $0.9 million of stock-based compensation was capitalized in inventory at April 2, 2016. The table above includes allocated stock-based compensation from Viavi of $2.9 million for the three months ended March 28, 2015, and $0.5 million and $6.8 million for the nine months ended April 2, 2016 and March 28, 2015, respectively.

[0001628280-16-015527:notes:78]
[same as prior period, unchanged from 0001628280-16-010773:notes:73]

[0001628280-16-015527:notes:79]
We granted no stock options during fiscal 2016 and 2015. The total intrinsic value of options exercised by our employees during the three and nine months ended April 2, 2016 was $0.7 million.

[0001628280-16-015527:notes:80]
[same as prior period, unchanged from 0001628280-16-010773:notes:75]

[0001628280-16-015527:notes:81]
During the nine months ended April 2, 2016, we granted 1.9 million RSUs, of which 41,000 also have performance conditions. The aggregate grant-date fair value of time-based RSUs and performance-based RSUs are $37.7 million and $0.8 million, respectively. The majority of the time-based RSUs vest over three years, with 33.3% vesting after one year and the balance vesting quarterly over the remaining two years. The vesting of the performance based RSUs is over three years and contingent upon the achievement of specific revenue targets and the employee’s continued service. The performance based RSU shares have a target number of shares, and the actual number of shares awarded upon vesting may be higher or lower depending upon the level of achievement of the performance conditions.

[0001628280-16-015527:notes:82]
A summary of the status of our outstanding RSUs as of April 2, 2016 and changes during the nine months ended April 2, 2016 is presented below (amount in millions):

[0001628280-16-015527:notes:83]
|  | Full Value Awards |
|  | Time-based shares |  | Performance-based shares |  | Total number of shares |
| Outstanding at June 27, 2015, as converted | 1.5 |  |  | 0.2 |  |  | 1.7 |  |
| Awards granted | 1.9 |  |  | — |  |  | 1.9 |  |
| Awards vested | (0.6 | ) |  | (0.1 | ) |  | (0.7 | ) |
| Awards cancelled | (0.2 | ) |  | — |  |  | (0.2 | ) |
| Outstanding at April 2, 2016 | 2.6 |  |  | 0.1 |  |  | 2.7 |  |

[0001628280-16-015527:notes:84]
As of April 2, 2016, $42.4 million of unrecognized stock-based compensation cost related to RSUs remains to be amortized. That cost is expected to be recognized over an estimated amortization period of 2.1 years.

[0001628280-16-015527:notes:85]
RSUs are converted into shares upon vesting. Shares equivalent in value to the minimum statutory withholding tax on the vested shares are withheld by the Company at the employees discretion for the payment of such taxes. During the nine months ended April 2, 2016 and March 28, 2015, the Company paid $5.2 million and $6.5 million for employee withholding taxes, respectively, and classified the payments as operating cash outflows in the consolidated statements of cash flows.

[0001628280-16-015527:notes:86]
[same as prior period, unchanged from 0001628280-16-010773:notes:81]

[0001628280-16-015527:notes:87]
In June 2015, the Company adopted the 2015 Employee Stock Purchase Plan (the “Plan”). The Plan, which became effective June 23, 2015, provides eligible employees of the Company and one or more of its parent or subsidiary companies with the opportunity to acquire a proprietary interest in the Company through participation in a plan designed to qualify as an employee stock purchase plan under Section 423 of the Internal Revenue Code. The Plan will terminate on the date on which all shares available for issuance have been sold. The first offering period is from November 17, 2015 to May 15, 2016. The Plan provides a 15% discount on the lesser of (i) the fair market value of a share on the date of purchase or (ii) the fair market value of a share on the commencement date of the purchase period.


## us-gaap:EarningsPerShareTextBlock

[0001628280-16-015527:notes:88]
[same as prior period, unchanged from 0001628280-16-010773:notes:83]

[0001628280-16-015527:notes:89]
[same as prior period, unchanged from 0001628280-16-010773:notes:84]

[0001628280-16-015527:notes:90]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 2, 2016 |  | March 28, 2015 |  | April 2, 2016 |  | March 28, 2015 |
| Numerator: |  |  |  |  |  |  |  |  |
| Net income (loss) | $ | (7.6 | ) |  | $ | 12.2 |  |  | $ | (5.0 | ) |  | $ | 12.4 |  |
| Less: Cumulative dividends on Series A Preferred Stock | (0.3 | ) |  | — |  |  | (0.6 | ) |  | — |  |
| Less: Accretion of Series A Preferred Stock | — |  |  | — |  |  | (11.7 | ) |  | — |  |
| Net income (loss) available to common stockholders | $ | (7.9 | ) |  | $ | 12.2 |  |  | $ | (17.3 | ) |  | $ | 12.4 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average number of common shares outstanding |  |  |  |  |  |  |  |
| Basic | 59.2 |  |  | 58.8 |  |  | 59.0 |  |  | 58.8 |  |
| Effect of dilutive securities from stock-based benefit plans | — |  |  | — |  |  | — |  |  | — |  |
| Diluted | 59.2 |  |  | 58.8 |  |  | 59.0 |  |  | 58.8 |  |
| Net income (loss) per share attributable to common stockholders: |  |  |  |  |  |  |  |
| Basic | $ | (0.13 | ) |  | $ | 0.21 |  |  | $ | (0.29 | ) |  | $ | 0.21 |  |
| Diluted | $ | (0.13 | ) |  | $ | 0.21 |  |  | $ | (0.29 | ) |  | $ | 0.21 |  |

[0001628280-16-015527:notes:91]
On August 1, 2015, JDS Uniphase Corporation (“JDSU”) distributed 47.1 million shares, or 80.1% of the outstanding shares of common stock of Lumentum Holdings Inc. (“we”, “our” or “Lumentum”) to existing holders of JDSU common stock. JDSU was renamed Viavi Solutions Inc. (“Viavi”) and at the time of the distribution, retained 11.7 million shares, or 19.9% of Lumentum's outstanding shares. The weighted average number of common shares outstanding is calculated as the number of shares of common stock outstanding immediately following the Separation, and the weighted average number of shares outstanding following the Separation through April 2, 2016. Diluted earnings per share is calculated by dividing net income for the period by the weighted average number of shares of common stock and potentially dilutive common stock outstanding for the period beginning after the Separation. Basic and diluted net income per share for the three and nine months ended March 28, 2015 is calculated using the shares of Lumentum common stock outstanding on August 1, 2015, as if such shares were outstanding for the entire period.

[0001628280-16-015527:notes:92]
[same as prior period, unchanged from 0001628280-16-010773:notes:87]

[0001628280-16-015527:notes:93]
The dilutive effect of the redeemable convertible preferred stock is reflected in diluted earnings per share by the application of the if-converted method. The number of shares is increased for the assumed conversion of the instrument. Additionally, cumulative dividends and accretion from measuring the instrument at its redemption value are added back to net income (loss).

[0001628280-16-015527:notes:94]
[same as prior period, unchanged from 0001628280-16-010773:notes:89]

[0001628280-16-015527:notes:95]
[same as prior period, unchanged from 0001628280-16-010773:notes:90]

[0001628280-16-015527:notes:96]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 2, 2016 |  | April 2, 2016 |
| Restricted stock units | 0.7 |  |  | 0.5 |  |
| Redeemable convertible preferred stock | 1.5 |  |  | 1.3 |  |
| Stock options and employee stock purchase plan | 0.1 |  |  | 0.1 |  |
| Total potentially dilutive securities | 2.3 |  |  | 1.9 |  |


## us-gaap:FiniteLivedIntangibleAssetsAmortizationExpenseTableTextBlock

[0001628280-16-015527:notes:97]
[same as prior period, unchanged from 0001628280-16-010773:notes:92]

[0001628280-16-015527:notes:98]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 2, 2016 |  | March 28, 2015 |  | April 2, 2016 |  | March 28, 2015 |
| Cost of sales | $ | 1.7 |  |  | $ | 1.9 |  |  | $ | 5.1 |  |  | $ | 5.7 |  |
| Operating expense | 0.1 |  |  | 0.1 |  |  | 0.3 |  |  | 0.3 |  |
| Total | $ | 1.8 |  |  | $ | 2.0 |  |  | $ | 5.4 |  |  | $ | 6.0 |  |


## us-gaap:GoodwillDisclosureTextBlock

[0001628280-16-015527:notes:99]
[same as prior period, unchanged from 0001628280-16-010773:notes:94]

[0001628280-16-015527:notes:100]
[same as prior period, unchanged from 0001628280-16-010773:notes:95]

[0001628280-16-015527:notes:101]
The following table presents the changes in goodwill allocated to the Lasers reportable segment during the nine months ended April 2, 2016 (in millions):

[0001628280-16-015527:notes:102]
|  | Lasers |  | Total |
| Balance as of June 27, 2015 | $ | 5.6 |  |  | $ | 5.6 |  |
| Currency translation and other adjustments | (0.1 | ) |  | (0.1 | ) |
| Balance as of April 2, 2016 | $ | 5.5 |  |  | $ | 5.5 |  |

[0001628280-16-015527:notes:103]
We review goodwill for impairment during the fourth quarter of each fiscal year or more frequently if events or circumstances indicate that an impairment loss may have occurred. In the fourth quarter of fiscal 2015, we completed the annual impairment test of goodwill, which indicated there was no goodwill impairment. During the nine months ended April 2, 2016, there have been no events or circumstances that have required us to perform an interim assessment of goodwill for impairment.

[0001628280-16-015527:notes:104]
[same as prior period, unchanged from 0001628280-16-010773:notes:99]

[0001628280-16-015527:notes:105]
[same as prior period, unchanged from 0001628280-16-010773:notes:100]

[0001628280-16-015527:notes:106]
| As of April 2, 2016 | Gross Carrying Amount |  | Accumulated Amortization |  | Net |
| Acquired developed technology | $ | 103.1 |  |  | $ | (87.2 | ) |  | $ | 15.9 |  |
| Other | 9.4 |  |  | (8.9 | ) |  | 0.5 |  |
| Total Intangibles | $ | 112.5 |  |  | $ | (96.1 | ) |  | $ | 16.4 |  |

[0001628280-16-015527:notes:107]
[same as prior period, unchanged from 0001628280-16-010773:notes:102]

[0001628280-16-015527:notes:108]
During the three and nine months ended April 2, 2016, the Company recorded $1.8 million and $5.4 million, respectively, of amortization expense relating to acquired developed technology and other intangibles.

[0001628280-16-015527:notes:109]
During the three and nine months ended March 28, 2015, the Company recorded $2.0 million and $6.0 million, respectively, of amortization expense relating to acquired developed technology and other intangibles.

[0001628280-16-015527:notes:110]
Based on the carrying amount of acquired developed technology and other intangibles as of April 2, 2016, and assuming no future impairment of the underlying assets, the estimated future amortization is as follows (in millions):

[0001628280-16-015527:notes:111]
| Fiscal Years |  |
| Remainder of 2016 | $ | 1.8 |  |
| 2017 | 6.7 |  |
| 2018 | 2.8 |  |
| 2019 | 2.6 |  |
| 2020 | 1.0 |  |
| Thereafter | 1.5 |  |
| Total amortization | $ | 16.4 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-16-015527:notes:112]
[same as prior period, unchanged from 0001628280-16-010773:notes:107]

[0001628280-16-015527:notes:113]
The Company recorded a tax provision of $0.1 million and $0.3 million for the three and nine months ended April 2, 2016, respectively. The Company recorded a tax benefit of $23.4 million and $22.0 million for the three and nine months ended March 28, 2015. The quarterly provision for income taxes is based on the estimated annual effective tax rate, plus any discrete items for the respective year. During the nine months ended April 2, 2016, we recognized a net benefit of $0.3 million related to deferred tax  adjustments for our foreign jurisdictions.

[0001628280-16-015527:notes:114]
The Company updates its estimated annual effective tax rate at the end of each quarterly period. The estimate takes into account the estimates for annual pre-tax income, the geographic mix of pre-tax income and interpretations of tax laws. The difference between the provision for income taxes that would be derived by applying the statutory rate to the Company’s income (loss) before income taxes and the provision for income taxes recorded for the three and nine months ended April 2, 2016 and March 28, 2015 was primarily attributable to the difference in foreign tax rates, utilization of U.S. tax attributes that were subject to a full valuation allowance, and certain Canadian tax incentives.

[0001628280-16-015527:notes:115]
In November 2015, the FASB issued ASU 2015-17, “Balance Sheet Classification of Deferred Taxes”, which simplifies the presentation of deferred income taxes. This ASU requires that deferred tax assets and liabilities be classified as non-current in a statement of financial position. We early adopted ASU 2015-17 effective December 26, 2015 on a prospective basis. Adoption of this ASU resulted in the reclassification of our net current deferred tax asset of $0.1 million to the net non-current deferred tax asset, and the current deferred tax liability of $0.5 million to the non-current deferred tax liability on our Consolidated Balance Sheet as of December 26, 2015. No prior periods were retrospectively adjusted.

[0001628280-16-015527:notes:116]
The Company’s net deferred tax assets relate predominantly to the Canadian tax jurisdiction and the Company has a partial valuation allowance against these deferred tax assets. The Company weighed both positive and negative evidence and determined that due to the limited carryover period of certain tax attributes in Canada, there is a continued need for a partial valuation allowance against these deferred tax assets as of April 2, 2016. Should the Company determine that it needs to adjust the valuation allowance, the adjustment may have a material impact to net income in the period such determination is made.

[0001628280-16-015527:notes:117]
The Company also evaluates the realizability of its U.S. net deferred tax assets based on all available evidence, both positive and negative, on a quarterly basis. The realization of net deferred tax assets is dependent on the Company’s ability to generate sufficient future taxable income during periods prior to the expiration of tax attributes to fully utilize these assets. The Company weighed both positive and negative evidence and determined that due to cumulative losses in the United States, there is a continued need for a full valuation allowance against the U.S. deferred tax assets as of April 2, 2016.

[0001628280-16-015527:notes:118]
[same as prior period, unchanged from 0001628280-16-010773:notes:113]

[0001628280-16-015527:notes:119]
[same as prior period, unchanged from 0001628280-16-010773:notes:114]


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001628280-16-015527:notes:120]
In March 2016, the Financial Accounting Standards Board (“FASB”) issued guidance to clarify the two aspects of authoritative guidance related to the new revenue recognition guidance issued in May 2014: identifying performance obligations and the licensing implementation guidance. The effective date and transition requirements for the amendments in the guidance are the same as the effective date and transition requirements in the new revenue recognition guidance issued in May 2014. We are evaluating the impact of adopting this new accounting guidance on our consolidated financial statements.

[0001628280-16-015527:notes:121]
In March 2016, the FASB issued guidance related to Compensation - Stock Compensation (“Topic 718”). This guidance makes several modifications to Topic 718 related to the accounting for forfeitures, employer tax withholding on share-based compensation and the financial statement presentation of excess tax benefits or deficiencies. It also clarifies the statement of cash flows presentation for certain components of share-based awards. The guidance is effective for us in the first quarter of fiscal 2017. Early adoption is permitted. We are evaluating the impact of adopting this new accounting guidance on our consolidated financial statements.

[0001628280-16-015527:notes:122]
In February 2016, the FASB issued guidance, requiring lessees to recognize a right-of-use asset and a lease liability on the balance sheet for all leases with the exception of short-term leases. For lessees, leases will continue to be classified as either operating or finance leases in the income statement. Lessor accounting is similar to the current model but updated to align with certain changes to the lessee model. Lessors will continue to classify leases as operating, direct financing or sales-type leases. The guidance is effective for us in the first quarter of fiscal 2019. Early adoption is permitted. The new standard must be adopted using a modified retrospective transition and requires application of the new guidance at the beginning of the earliest comparative period presented. We are evaluating the impact of adopting this new accounting guidance on our consolidated financial statements.

[0001628280-16-015527:notes:123]
In January 2016, the FASB issued guidance related to recognition and measurement of financial assets and financial liabilities. This guidance addresses certain aspects of recognition, measurement, presentation, and disclosure of financial statements. The guidance is effective for us in the first quarter of fiscal 2019. We are evaluating the impact of adopting this new accounting guidance on our consolidated financial statements.

[0001628280-16-015527:notes:124]
In November 2015, the FASB issued guidance related to balance sheet classification of deferred taxes. This guidance will require that deferred tax liabilities and assets be classified as noncurrent in a classified statement of financial position. The guidance is effective for us in the first quarter of fiscal 2018. Earlier application is permitted as of the beginning of an interim or annual reporting period. We early adopted this guidance effective December 26, 2015 on a prospective basis. No prior periods were retrospectively adjusted. Refer to "Note 11. Income Taxes" for more information.

[0001628280-16-015527:notes:125]
In July 2015, the FASB issued guidance to change the subsequent measurement of inventory from lower of cost or market to lower of cost and net realizable value. The guidance is effective for us in the first quarter of fiscal 2018. Earlier application is permitted as of the beginning of an interim or annual reporting period. We are evaluating the impact of adopting this new accounting guidance on our consolidated financial statements.

[0001628280-16-015527:notes:126]
In May 2015, the FASB issued guidance to remove the requirement to categorize within the fair value hierarchy all investments for which fair value is measured using a net asset value per share practical expedient. The guidance is effective for us in the first quarter of fiscal 2017 and may apply to certain pension assets. The guidance will be applied retrospectively and earlier adoption is permitted. We are evaluating the impact of adopting this new accounting guidance on our consolidated financial statements.

[0001628280-16-015527:notes:127]
In April 2015, the FASB issued new authoritative guidance to provide a practical expedient that permits the entity to measure defined benefit plan assets and obligations using the month-end that is closest to the entity’s fiscal year-end and apply that practical expedient consistently from year to year. This guidance is effective for us in the first quarter of fiscal 2017. Prospective application is required, and early adoption is permitted. We are evaluating the impact of adopting this new accounting guidance on our consolidated financial statements.

[0001628280-16-015527:notes:128]
In May 2014, the FASB issued new authoritative guidance related to revenue recognition. This guidance will replace current U.S. GAAP guidance on this topic and eliminate industry-specific guidance. The new revenue recognition guidance provides a unified model to determine when and how revenue is recognized. The core principle is that a company should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration for which the entity expects to be entitled in exchange for those goods or services. This guidance allows for either full retrospective adoption or modified retrospective adoption. The FASB deferred the effective date for this guidance by one year to December 15, 2017 for annual reporting periods beginning after that. Earlier application of this guidance is permitted but not before the original date of December 15, 2016. We are evaluating the impact that this new accounting guidance will have on our consolidated financial statements and the related disclosures.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001628280-16-015527:notes:129]
Note 3. Related Party Transactions

[0001628280-16-015527:notes:130]
Transactions with Viavi

[0001628280-16-015527:notes:131]
Agreements with Viavi

[0001628280-16-015527:notes:132]
On July 31, 2015, the Company entered into a Supply Agreement with Viavi providing that each party will supply certain products at pre-determined prices, and providing Viavi with research and development services at cost plus a specified markup. The Company also agreed to supply office space via a sublease agreement to Viavi. The sublease income and research and development cost reimbursements are each recorded as contra operating expenses in the Consolidated Statements of Operations for the three and nine months ended April 2, 2016.

[0001628280-16-015527:notes:133]
The Supply Agreement contains a $15.0 million purchase commitment with Viavi for certain products, and for the three and nine months ended April 2, 2016, the Company purchased $6.8 million and $13.3 million, respectively, in product from Viavi against the $15.0 million purchase commitment. During the three and nine months ended April 2, 2016, the Company recognized revenue of $0.9 million and  $2.4 million, respectively, from products sold to Viavi. For the three and nine months ended April 2, 2016, the Company recorded $0.5 million and $1.7 million, respectively, in research and development cost reimbursement and $0.2 million and $0.5 million, respectively, in sublease rental income. As of April 2, 2016, the Company had $0.4 million in accounts receivable due from Viavi.

[0001628280-16-015527:notes:134]
On July 31, 2015, the Company also entered into the following agreements with Viavi:

[0001628280-16-015527:notes:135]
| a) | Contribution Agreement which identifies the assets to be transferred, the liabilities to be assumed and the contracts to be assigned and it provides for when and how these transfers, assumptions and assignments will occur. |

[0001628280-16-015527:notes:136]
| b) | Separation and Distribution Agreement which governs the separation of the Lumentum business and other matters related to Lumentum’s relationship with Viavi. |

[0001628280-16-015527:notes:137]
| c) | Tax Matters Agreement which governs the respective rights, responsibilities and obligations of Lumentum and Viavi with respect to tax liabilities and benefits, attributes, proceedings, returns and certain other tax matters. |

[0001628280-16-015527:notes:138]
| d) | Employee Matters Agreement which governs the compensation and employee benefit obligations with respect to the current and former employees of Lumentum and Viavi, the treatment of equity based compensation and generally allocates liabilities and responsibilities relating to employee compensation, benefit plans and programs. The Employee Matters Agreement provides that employees of Lumentum will participate in benefit plans sponsored or maintained by Lumentum. |

[0001628280-16-015527:notes:139]
| e) | Securities Purchase Agreement, which also includes Amada Holdings Co., Ltd. (“Amada”) as a party, which sets forth the terms for the sale by Viavi to Amada of shares of Series A Preferred Stock (the "Series A Preferred Stock") of Lumentum Inc., our wholly-owned subsidiary, following the Separation. |

[0001628280-16-015527:notes:140]
| f) | Intellectual Property Matters Agreement which outlines the intellectual property rights of Lumentum and Viavi following the Separation, as well as non-compete restrictions between Viavi and Lumentum. |

[0001628280-16-015527:notes:141]
Allocated Costs

[0001628280-16-015527:notes:142]
Through and up to August 1, 2015, the separation date, the consolidated statements of operations included our direct expenses for cost of sales, research and development, sales and marketing, and administration as well as allocations of expenses arising from shared services and infrastructure provided by Viavi to us. These allocated expenses include costs of information technology, human resources, accounting, legal, real estate and facilities, corporate marketing, insurance, treasury and other corporate and infrastructure services. In addition, other costs allocated to us include restructuring and stock-based compensation related to Viavi’s corporate and shared services employees and are included in the table below. These expenses were allocated to us using estimates that we consider to be a reasonable reflection of the utilization of services or benefits received by our business. The allocation methods include revenue, headcount, square footage, actual consumption and usage of services and others.

[0001628280-16-015527:notes:143]
Allocated costs included in the accompanying consolidated statements of operations are as follows (in millions):

[0001628280-16-015527:notes:144]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 2, 2016 |  | March 28, 2015 |  | April 2, 2016 |  | March 28, 2015 |
| Research and development | $ | — |  |  | $ | 0.2 |  |  | $ | — |  |  | $ | 0.2 |  |
| Selling, general and administrative | — |  |  | 20.0 |  |  | 11.7 |  |  | 56.6 |  |
| Restructuring and related charges | — |  |  | 0.6 |  |  | — |  |  | 3.8 |  |
| Interest and other (income) expenses, net | — |  |  | 0.1 |  |  | (0.1 | ) |  | 0.1 |  |
| Interest expense | — |  |  | 0.3 |  |  | 0.1 |  |  | 0.7 |  |
| Total allocated costs | $ | — |  |  | $ | 21.2 |  |  | $ | 11.7 |  |  | $ | 61.4 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001628280-16-015527:notes:145]
[same as prior period, unchanged from 0001628280-16-010773:notes:137]

[0001628280-16-015527:notes:146]
We have initiated various strategic restructuring events primarily intended to reduce costs and align our business in response to the market conditions. As of April 2, 2016 and June 27, 2015, our total restructuring and related charges accrual was $3.8 million and $4.9 million, respectively. During the three and nine months ended April 2, 2016, we recorded $1.8 million and $3.9 million, respectively, in restructuring and related charges in the consolidated statements of operations. During the three and nine months ended March 28, 2015, we recorded $1.1 million and $6.7 million, respectively, in restructuring and related charges in the consolidated statements of operations. Our restructuring charges include severance and benefit costs to eliminate a specified number of positions, facilities and equipment costs to vacate facilities and consolidate operations, and lease termination costs. The timing of associated cash payments is dependent upon the type of restructuring charge and can extend over multiple periods.

[0001628280-16-015527:notes:147]
[same as prior period, unchanged from 0001628280-16-010773:notes:139]

[0001628280-16-015527:notes:148]
The adjustments to the accrued restructuring expenses related to all of our restructuring plans described below for the nine months ended April 2, 2016, were as follows (in millions):

[0001628280-16-015527:notes:149]
|  | Balance June 27,2015 |  | Accrued |  | Cash Settlements |  | BalanceApril 2,2016 |
| Fiscal 2015 Plans |  |  |  |  |  |  |  |
| Separation Restructuring Plan (Workforce Reduction) | $ | 4.6 |  |  | $ | 0.7 |  |  | $ | (1.7 | ) |  | $ | 3.6 |  |
| Fiscal 2013 Plans |  |  |  |  |  |  |  |
| Other Plans | 0.3 |  |  | 0.1 |  |  | (0.2 | ) |  | 0.2 |  |
| Total | $ | 4.9 |  |  | $ | 0.8 |  |  | $ | (1.9 | ) |  | $ | 3.8 |  |

[0001628280-16-015527:notes:150]
As of April 2, 2016, all of the $3.8 million accrual was included in other current liabilities on the consolidated balance sheets. As of June 27, 2015, $3.2 million was included in other current liabilities, and $1.7 million was included in other non-current liabilities on the consolidated balance sheets.

[0001628280-16-015527:notes:151]
[same as prior period, unchanged from 0001628280-16-010773:notes:143]

[0001628280-16-015527:notes:152]
[same as prior period, unchanged from 0001628280-16-010773:notes:144]

[0001628280-16-015527:notes:153]
During the second and fourth quarter of fiscal 2015, management approved restructuring plans impacting our Optical Communications (“OpComms”) segment to optimize manufacturing operations and gain efficiencies which include closing the Bloomfield, Connecticut site and consolidating roles and responsibilities across functions as we move forward with our separation plan. As a result, approximately 200 employees in manufacturing, R&D and SG&A functions located in North America, Europe and Asia will be impacted. For the three and nine months ended April 2, 2016, the Company recorded no expenses related to the fiscal year 2015 restructuring plans. For the nine months ended April 2, 2016, the Company recorded $0.7 million of expenses for severance and retention activity related to the restructuring plan implemented in the fourth quarter of 2015. Payments related to the remaining severance and benefits accrual are expected to be paid through fiscal year 2017.

[0001628280-16-015527:notes:154]
[same as prior period, unchanged from 0001628280-16-010773:notes:146]

[0001628280-16-015527:notes:155]
During fiscal 2008, we recorded lease exit charges, net of assumed sub-lease income related to our Ottawa facility which was included in selling, general and administrative expenses as the space was never occupied and we had no need for the space in the foreseeable future due to changes in business requirements.  For the three and nine months ended April 2, 2016, we had cash settlements of $0.1 million and $0.4 million, respectively. The fair value of the remaining contractual obligations, net of sublease income is $0.7 million and $1.1 million as of April 2, 2016 and June 27, 2015, respectively. As of April 2, 2016 and June 27, 2015, $0.4 million and $0.6 million was included in other current liabilities, and $0.3 million and $0.5 million in other non-current liabilities, respectively, on the consolidated balance sheets. The payments related to these lease costs are expected to be paid by the end of the third quarter of fiscal 2018.


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001628280-16-015527:notes:156]
[same as prior period, unchanged from 0001628280-16-010773:notes:148]

[0001628280-16-015527:notes:157]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 2, 2016 |  | March 28, 2015 |  | April 2, 2016 |  | March 28, 2015 |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States | $ | 28.8 |  |  | 12.5 | % |  | $ | 42.2 |  |  | 21.2 | % |  | $ | 91.3 |  |  | 13.8 | % |  | $ | 125.7 |  |  | 20.0 | % |
| Mexico | 34.4 |  |  | 14.9 |  |  | 30.9 |  |  | 15.6 |  |  | 112.7 |  |  | 17.0 |  |  | 81.0 |  |  | 12.9 |  |
| Other Americas | 5.1 |  |  | 2.2 |  |  | 9.1 |  |  | 4.6 |  |  | 17.9 |  |  | 2.7 |  |  | 22.9 |  |  | 3.6 |  |
| Total Americas | $ | 68.3 |  |  | 29.6 | % |  | $ | 82.2 |  |  | 41.4 | % |  | $ | 221.9 |  |  | 33.5 | % |  | $ | 229.6 |  |  | 36.5 | % |
| Asia-Pacific: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Hong Kong | $ | 67.9 |  |  | 29.5 | % |  | $ | 24.3 |  |  | 12.2 | % |  | $ | 150.5 |  |  | 22.7 | % |  | $ | 87.0 |  |  | 13.9 | % |
| Japan | 19.8 |  |  | 8.6 |  |  | 12.9 |  |  | 6.5 |  |  | 65.8 |  |  | 10.0 |  |  | 83.7 |  |  | 13.3 |  |
| Thailand | 20.5 |  |  | 8.9 |  |  | 13.7 |  |  | 6.9 |  |  | 64.5 |  |  | 9.8 |  |  | 43.4 |  |  | 6.9 |  |
| Other Asia-Pacific | 27.0 |  |  | 11.7 |  |  | 36.1 |  |  | 18.2 |  |  | 69.3 |  |  | 10.5 |  |  | 86.1 |  |  | 13.7 |  |
| Total Asia-Pacific | $ | 135.2 |  |  | 58.7 | % |  | $ | 87.0 |  |  | 43.8 | % |  | $ | 350.1 |  |  | 53.0 | % |  | $ | 300.2 |  |  | 47.8 | % |
| EMEA | $ | 26.9 |  |  | 11.7 | % |  | $ | 29.5 |  |  | 14.8 | % |  | $ | 89.3 |  |  | 13.5 | % |  | $ | 98.4 |  |  | 15.7 | % |
| Total net revenue | $ | 230.4 |  |  |  |  | $ | 198.7 |  |  |  |  | $ | 661.3 |  |  |  |  | $ | 628.2 |  |  |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001628280-16-015527:notes:158]
[same as prior period, unchanged from 0001628280-16-010773:notes:150]

[0001628280-16-015527:notes:159]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 2, 2016 |  | March 28, 2015 |  | April 2, 2016 |  | March 28, 2015 |
| Net revenue: |  |  |  |  |  |  |  |
| OpComms | $ | 197.2 |  |  | $ | 167.2 |  |  | $ | 560.1 |  |  | $ | 515.2 |  |
| Lasers | 33.2 |  |  | 31.5 |  |  | 101.2 |  |  | 113.0 |  |
| Net revenue | $ | 230.4 |  |  | $ | 198.7 |  |  | $ | 661.3 |  |  | $ | 628.2 |  |
| Gross profit: |  |  |  |  |  |  |  |
| OpComms | 58.7 |  |  | 47.1 |  |  | 171.4 |  |  | 150.3 |  |
| Lasers | 15.5 |  |  | 13.6 |  |  | 43.9 |  |  | 55.0 |  |
| Total segment gross profit | 74.2 |  |  | 60.7 |  |  | 215.3 |  |  | 205.3 |  |
| Unallocated amounts: |  |  |  |  |  |  |  |
| Stock-based compensation | (2.2 | ) |  | (1.3 | ) |  | (4.9 | ) |  | (3.9 | ) |
| Amortization of intangibles | (1.7 | ) |  | (1.9 | ) |  | (5.1 | ) |  | (5.7 | ) |
| Other charges related to non-recurring activities | (7.5 | ) |  | (0.4 | ) |  | (7.5 | ) |  | (1.4 | ) |
| Gross profit | $ | 62.8 |  |  | $ | 57.1 |  |  | $ | 197.8 |  |  | $ | 194.3 |  |


## us-gaap:SchedulesOfConcentrationOfRiskByRiskFactorTextBlock

[0001628280-16-015527:notes:160]
The table below discloses the percentage of our total net revenue attributable to each of our two reportable segments. In addition, the table discloses the percentage of our total net revenue attributable to our product offerings which serve the Telecom, Datacom and consumer and industrial ("Consumer and Industrial"):

[0001628280-16-015527:notes:161]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 2, 2016 |  | March 28, 2015 |  | April 2, 2016 |  | March 28, 2015 |
| Optical Communications: | 85.6 | % |  | 84.1 | % |  | 84.7 | % |  | 82.0 | % |
| Telecom | 60.7 | % |  | 60.2 | % |  | 62.0 | % |  | 60.7 | % |
| Datacom | 19.8 | % |  | 19.3 | % |  | 17.6 | % |  | 16.5 | % |
| Consumer and Industrial | 5.1 | % |  | 4.6 | % |  | 5.1 | % |  | 4.8 | % |
| Lasers | 14.4 | % |  | 15.9 | % |  | 15.3 | % |  | 18.0 | % |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001628280-16-015527:notes:162]
[same as prior period, unchanged from 0001628280-16-010773:notes:154]

[0001628280-16-015527:notes:163]
[same as prior period, unchanged from 0001628280-16-010773:notes:155]

[0001628280-16-015527:notes:164]
[same as prior period, unchanged from 0001628280-16-010773:notes:156]

[0001628280-16-015527:notes:165]
[same as prior period, unchanged from 0001628280-16-010773:notes:157]

[0001628280-16-015527:notes:166]
| (i) | OpComms: Our OpComms portfolio includes products used by Telecom and Datacom NEMs and both traditional and cloud/data center service providers. These products enable the transmission and transport of video, audio and text data over high-capacity fiber optic cables. Transmission products primarily consist of optical transceivers, optical transponders, and their supporting components such as modulators and source lasers, including innovative products such as the Tunable Small Form-factor Pluggable Plus transceiver. Transport products primarily consist of modules or sub-systems containing optical amplifiers, reconfigurable optical add/drop multiplexers (“ROADMs”) or Wavelength Selective Switches, Optical Channel Monitors and their supporting components. Our products for 3-D sensing applications, formerly referred to as our gesture recognition products, include light source products. Customer solutions containing our 3-D sensing products let a person control electronic or computer devices with natural body or hand gestures instead of using a remote, mouse or other device. |

[0001628280-16-015527:notes:167]
[same as prior period, unchanged from 0001628280-16-010773:notes:159]

[0001628280-16-015527:notes:168]
The CODM evaluates segment performance to make financial decisions and allocate resources based on gross margin. We do not allocate research and development, sales and marketing, or general and administrative expenses to our segments because management does not include the information in its measurement of the performance of the operating segments. In addition, we do not allocate amortization and impairment of acquisition-related intangible assets, stock-based compensation and certain other non-recurring charges impacting the gross margin of each segment because management does not include this information in its measurement of the performance of the operating segments.

[0001628280-16-015527:notes:169]
[same as prior period, unchanged from 0001628280-16-010773:notes:161]

[0001628280-16-015527:notes:170]
During the nine months ended April 2, 2016 and March 28, 2015, net revenue from customers outside the United States, based on customer shipping location, represented 86.2% and 80.0% of net revenue, respectively. During the three months ended April 2, 2016 and March 28, 2015, net revenue from customers outside the United States, based on customer shipping location, represented 87.5% and 78.8% of net revenue, respectively. Our net revenue is primarily denominated in U.S. dollars, including our net revenue from customers outside the United States as presented above.
