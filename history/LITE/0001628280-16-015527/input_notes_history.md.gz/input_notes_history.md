# LITE note change history — 0001628280-16-010773 → 0001628280-16-015527


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2016-05-04):
[0001628280-16-015527:note_history:1]
We lease certain real and personal property from unrelated third parties under non-cancellable operating leases that expire at various dates through fiscal 2026. Certain leases require us to pay property taxes, insurance and routine maintenance, and include escalation clauses. As of April 2, 2016 the future minimum annual lease payments under non-cancellable operating leases were as follows (in millions):
  (was, 2016-02-04, similarity 0.9838):
[0001628280-16-010773:note_history:1]
We lease certain real and personal property from unrelated third parties under non-cancellable operating leases that expire at various dates through fiscal 2026. Certain leases require us to pay property taxes, insurance and routine maintenance, and include escalation clauses. As of December 26, 2015 the future minimum annual lease payments under non-cancellable operating leases were as follows (in millions):

- changed (2016-05-04):
[0001628280-16-015527:note_history:2]
Purchase obligations of $164.4 million as of April 2, 2016, represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule and adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.
  (was, 2016-02-04, similarity 0.9886):
[0001628280-16-010773:note_history:2]
Purchase obligations of $145.5 million as of December 26, 2015, represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule and adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

- changed (2016-05-04):
[0001628280-16-015527:note_history:3]
The following table presents the changes in our warranty reserve during the three and nine months ended April 2, 2016 and March 28, 2015 (in millions):
  (was, 2016-02-04, similarity 0.9135):
[0001628280-16-010773:note_history:3]
The following table presents the changes in our warranty reserve during the three and six months ended December 26, 2015 and December 27, 2014 (in millions):

- changed (2016-05-04):
[0001628280-16-015527:note_history:4]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 2, 2016 |  | March 28, 2015 |  | April 2, 2016 |  | March 28, 2015 |
| Balance as of beginning of period | $ | 3.1 |  |  | $ | 2.0 |  |  | $ | 2.8 |  |  | $ | 2.7 |  |
| Provision for warranty | 0.8 |  |  | 0.8 |  |  | 2.5 |  |  | 2.3 |  |
| Utilization of reserve | (0.8 | ) |  | (0.7 | ) |  | (2.3 | ) |  | (2.8 | ) |
| Adjustments related to pre-existing warranties (including changes in estimates) | (1.3 | ) |  | (0.3 | ) |  | (1.2 | ) |  | (0.4 | ) |
| Balance as of end of period | $ | 1.8 |  |  | $ | 1.8 |  |  | $ | 1.8 |  |  | $ | 1.8 |  |
  (was, 2016-02-04, similarity 0.8434):
[0001628280-16-010773:note_history:4]
|  | Three Months Ended |  | Six Months Ended |
|  | December 26, 2015 |  | December 27, 2014 |  | December 26, 2015 |  | December 27, 2014 |
| Balance as of beginning of period | $ | 2.5 |  |  | $ | 2.4 |  |  | $ | 2.8 |  |  | $ | 2.7 |  |
| Provision for warranty | 0.8 |  |  | 0.9 |  |  | 1.7 |  |  | 1.5 |  |
| Utilization of reserve | (0.3 | ) |  | (1.2 | ) |  | (1.5 | ) |  | (2.1 | ) |
| Adjustments related to pre-existing warranties (including changes in estimates) | 0.1 |  |  | (0.1 | ) |  | 0.1 |  |  | (0.1 | ) |
| Balance as of end of period | $ | 3.1 |  |  | $ | 2.0 |  |  | $ | 3.1 |  |  | $ | 2.0 |  |

- changed (2016-05-04):
[0001628280-16-015527:note_history:5]
Our R&D, manufacturing and distribution operations involve the use of hazardous substances and are regulated under international, federal, state and local laws governing health and safety and the environment. We apply strict standards for protection of the environment and occupational health and safety to sites inside and outside the United States, even if not subject to regulations imposed by foreign governments. We believe that our properties and operations at our facilities comply in all material respects with applicable environmental laws and occupational health and safety laws. However, the risk of environmental liabilities cannot be completely eliminated and there can be no assurance that the application of environmental and health and safety laws will not require us to incur significant expenditures. We are also regulated under a number of international, federal, state and local laws regarding recycling, product packaging and product content requirements. The environmental, product content/disposal and recycling laws are gradually becoming more stringent and may cause us to incur significant expenditures in the future.
  (was, 2016-02-04, similarity 0.9996):
[0001628280-16-010773:note_history:5]
Our R&D, manufacturing and distribution operations involve the use of hazardous substances and are regulated under international, federal, state and local laws governing health and safety and the environment. We apply strict standards for protection of the environment and occupational health and safety to sites inside and outside the United States, even if not subject to regulation imposed by foreign governments. We believe that our properties and operations at our facilities comply in all material respects with applicable environmental laws and occupational health and safety laws. However, the risk of environmental liabilities cannot be completely eliminated and there can be no assurance that the application of environmental and health and safety laws will not require us to incur significant expenditures. We are also regulated under a number of international, federal, state and local laws regarding recycling, product packaging and product content requirements. The environmental, product content/disposal and recycling laws are gradually becoming more stringent and may cause us to incur significant expenditures in the future.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2016-05-04):
[0001628280-16-015527:note_history:6]
On July 31, 2015, prior to the Separation, Viavi transferred substantially all of the assets and liabilities and operations of the CCOP segment and WaveReady product lines to Lumentum (the “Capitalization"). Financial statements for periods prior to the Capitalization were prepared on a stand-alone basis and were derived from Viavi’s consolidated financial statements and accounting records. For the period from June 28, 2015 to August 1, 2015, expenses were allocated to us using estimates that we consider to be a reasonable reflection of the utilization of services provided to, or benefits received by, us.
  (was, 2016-02-04, similarity 0.9456):
[0001628280-16-010773:note_history:6]
On July 31, 2015, prior to the Separation, Viavi transferred substantially all of the assets and liabilities and operations of the communications and commercial optical products (“CCOP”) segment and WaveReady product lines to Lumentum (the “Capitalization"). Combined financial statements for periods prior to the Capitalization were prepared on a stand-alone basis and were derived from Viavi’s consolidated financial statements and accounting records. For the period from June 28, 2015 to August 1, 2015, expenses were allocated to us using estimates that we consider to be a reasonable reflection of the utilization of services provided to or benefits received by us.

- changed (2016-05-04):
[0001628280-16-015527:note_history:7]
The preparation of the consolidated financial statements in accordance with GAAP in the United States requires management to make estimates and assumptions that affect the amounts reported in our consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact the company in the future, actual results may be different from the estimates. Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are revenue recognition, inventory valuation, allocation methods and allocated expenses from Viavi, valuation of goodwill and other intangible assets, share-based compensation, retirement and post-retirement plan assumptions, restructuring, warranty and accounting for income taxes.
  (was, 2016-02-04, similarity 0.9926):
[0001628280-16-010773:note_history:7]
The preparation of the consolidated financial statements in accordance with GAAP in the U.S. requires management to make estimates and assumptions that affect the amounts reported in our consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact the company in the future, actual results may be different from the estimates. Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are revenue recognition, inventory valuation, allocation methods and allocated expenses from Viavi, valuation of goodwill and other intangible assets, share-based compensation, retirement and post-retirement plan assumptions, restructuring, warranty and accounting for income taxes.

- changed (2016-05-04):
[0001628280-16-015527:note_history:8]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Our fiscal 2016 is a 53-week year ending on July 2, 2016 and our third quarter of fiscal 2016 included one additional week. Our fiscal 2015 ended on June 27, 2015 and was a 52-week year.
  (was, 2016-02-04, similarity 0.9593):
[0001628280-16-010773:note_history:8]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Our fiscal 2016 is a 53-week year ending on July 2, 2016 and our third quarter of fiscal 2016 will include one additional week. Our fiscal 2015 ended on June 27, 2015 and was a 52-week year.

- changed (2016-05-04):
[0001628280-16-015527:note_history:9]
Principles of Consolidation
  (was, 2016-02-04, similarity 0.7714):
[0001628280-16-010773:note_history:9]
Principles of Combination and Consolidation

- changed (2016-05-04):
[0001628280-16-015527:note_history:10]
There have been no material changes in our significant accounting policies during the nine months ended April 2, 2016 compared to the significant accounting policies described in our Annual Report on Form 10-K/A for the fiscal year ended June 27, 2015. The accompanying unaudited interim consolidated financial statements and accompanying related notes should be read in conjunction with the consolidated financial statements and related notes included in our Annual Report on Form 10-K/A for the fiscal year ended June 27, 2015.
  (was, 2016-02-04, similarity 0.9531):
[0001628280-16-010773:note_history:10]
There have been no material changes in our significant accounting policies during the six months ended December 26, 2015 compared to the significant accounting policies described in our Annual Report on Form 10-K/A for the fiscal year ended June 27, 2015. The accompanying unaudited interim consolidated financial statements and accompanying related notes should be read in conjunction with the consolidated financial statements and related notes included in our Annual Report on Form 10-K/A for the fiscal year ended June 27, 2015.

- added (2016-05-04):
[0001628280-16-015527:note_history:11]
During the three months ended April 2, 2016, we identified an error relating to stock-based compensation expense for the three months ended December 26, 2015 in which stock-based compensation expense of $1.0 million was excluded for a specific restricted stock grant. Additionally, we identified an error relating to the overstatement of sales and use tax accrual of $0.2 million and $0.3 million for the three months ended September 26, 2015 and December 26, 2015, respectively. During the three months ended December 26, 2015, we identified an error relating to the determination of the accretion amount of Series A preferred stock for the three months ended September 26, 2015 in which the accretion of the discount related to issuance cost of $2.0 million was excluded. As a result, our net loss attributable to common stockholders and basic and diluted net loss per share attributable to common stockholders included in our quarterly report on Form 10-Q ("Form 10-Q") for the three months ended September 26, 2015 was understated by $1.8 million and $0.03 per basic and diluted share, respectively. Our net income attributable to common stockholders and basic and diluted net income per share attributable to common stockholders included in Form 10-Q for the three months ended December 26, 2015 was understated by $1.3 million and $0.02 per basic and diluted share, respectively. The correction of the errors identified in the three months ended April 2, 2016 resulted in an overstatement of net loss per share attributable to common stockholders by $0.5 million and $0.01 per basic and diluted share.

- added (2016-05-04):
[0001628280-16-015527:note_history:12]
We assessed the materiality of these errors and determined that the above errors were not material to our unaudited consolidated financial statements as of each of the periods mentioned above.

- removed (2016-05-04):
[0001628280-16-010773:note_history:13]
During the three and six months ended December 26, 2015, we identified an error relating to the determination of the accretion amount of Series A preferred stock for the three months ended September 26, 2015 in which the accretion of the discount related to issuance cost of $2.0 million was excluded. As a result, our net loss attributable to common stockholders and basic and diluted net loss per share attributable to common stockholders included in our quarterly report on Form 10-Q ("Form 10-Q") for the three months ended September 26, 2015 was understated by $2.0 million and $0.03 per basic and diluted share, respectively, and the correction of the error in the three months ended December 26, 2015 was an understatement of net income per share attributable to common stockholders by $2.0 million and $0.03 per basic and diluted share. In addition, this error resulted in an understatement of our mezzanine equity and an overstatement of our stockholders' equity by $2.0 million as of September 26, 2015 as included in the Form 10-Q. This error did not impact any annual or other interim periods and has no impact to the net income. We assessed the materiality of this error on the three and six months ended December 26, 2015 and as of September 26, 2015 and the three months ended September 26, 2015 unaudited consolidated financial statements in accordance with the SEC's Staff Accounting Bulletin No.99 and No.108, based on an analysis of quantitative and qualitative factors, determined that this error was not material to our unaudited consolidated financial statements as of September 30, 2015 and for the three months ended September 26, 2015 and the three and six months ended December 26, 2015. Therefore, our unaudited consolidated financial statements as of September 26, 2015 and for the three months ended September 26, 2015 can continue to be relied upon and an amendment of our previously filed Form 10-Q is not required. However, for comparability, the corrected amounts will be revised in the fiscal 2017 Form 10-Qs that will contain such financial information.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2016-05-04):
[0001628280-16-015527:note_history:14]
On July 31, 2015, the Company entered into a Supply Agreement with Viavi providing that each party will supply certain products at pre-determined prices, and providing Viavi with research and development services at cost plus a specified markup. The Company also agreed to supply office space via a sublease agreement to Viavi. The sublease income and research and development cost reimbursements are each recorded as contra operating expenses in the Consolidated Statements of Operations for the three and nine months ended April 2, 2016.
  (was, 2016-02-04, similarity 0.9411):
[0001628280-16-010773:note_history:14]
On July 31, 2015, the Company entered into a Supply Agreement with Viavi providing that each party will supply certain products at pre-determined prices, and providing Viavi with research and development services at cost plus a specified markup. The Company has also agreed to supply office space via a sublease agreement to Viavi. The sublease income and research and development cost reimbursements are each recorded as contra operating expenses in the Consolidated Statements of Operations for the six months ended December 26, 2015.

- added (2016-05-04):
[0001628280-16-015527:note_history:15]
The Supply Agreement contains a $15.0 million purchase commitment with Viavi for certain products, and for the three and nine months ended April 2, 2016, the Company purchased $6.8 million and $13.3 million, respectively, in product from Viavi against the $15.0 million purchase commitment. During the three and nine months ended April 2, 2016, the Company recognized revenue of $0.9 million and  $2.4 million, respectively, from products sold to Viavi. For the three and nine months ended April 2, 2016, the Company recorded $0.5 million and $1.7 million, respectively, in research and development cost reimbursement and $0.2 million and $0.5 million, respectively, in sublease rental income. As of April 2, 2016, the Company had $0.4 million in accounts receivable due from Viavi.

- changed (2016-05-04):
[0001628280-16-015527:note_history:16]
| e) | Securities Purchase Agreement, which also includes Amada Holdings Co., Ltd. (“Amada”) as a party, which sets forth the terms for the sale by Viavi to Amada of shares of Series A Preferred Stock (the "Series A Preferred Stock") of Lumentum Inc., our wholly-owned subsidiary, following the Separation. |
  (was, 2016-02-04, similarity 0.9434):
[0001628280-16-010773:note_history:16]
| e) | Securities Purchase Agreement, which also includes Amada Holdings Co., Ltd. (“Amada”) as a party, which sets forth the terms for the sale by Viavi to Amada of shares of Series A Preferred Stock of Lumentum Inc., our wholly-owned subsidiary, following the Separation. |

- changed (2016-05-04):
[0001628280-16-015527:note_history:17]
Through and up to August 1, 2015, the separation date, the consolidated statements of operations included our direct expenses for cost of sales, research and development, sales and marketing, and administration as well as allocations of expenses arising from shared services and infrastructure provided by Viavi to us. These allocated expenses include costs of information technology, human resources, accounting, legal, real estate and facilities, corporate marketing, insurance, treasury and other corporate and infrastructure services. In addition, other costs allocated to us include restructuring and stock-based compensation related to Viavi’s corporate and shared services employees and are included in the table below. These expenses were allocated to us using estimates that we consider to be a reasonable reflection of the utilization of services or benefits received by our business. The allocation methods include revenue, headcount, square footage, actual consumption and usage of services and others.
  (was, 2016-02-04, similarity 0.9243):
[0001628280-16-010773:note_history:17]
The consolidated statements of operations includes our direct expenses for cost of sales, research and development, sales and marketing, and administration as well as allocations of expenses arising from shared services and infrastructure provided by Viavi to us. These allocated expenses include costs of information technology, human resources, accounting, legal, real estate and facilities, corporate marketing, insurance, treasury and other corporate and infrastructure services. In addition, other costs allocated to us include restructuring and stock-based compensation related to Viavi’s corporate and shared services employees and are included in the table below. These expenses are allocated to us using estimates that we consider to be a reasonable reflection of the utilization of services or benefits received by our business. The allocation methods include revenue, headcount, square footage, actual consumption and usage of services and others.

- changed (2016-05-04):
[0001628280-16-015527:note_history:18]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 2, 2016 |  | March 28, 2015 |  | April 2, 2016 |  | March 28, 2015 |
| Research and development | $ | — |  |  | $ | 0.2 |  |  | $ | — |  |  | $ | 0.2 |  |
| Selling, general and administrative | — |  |  | 20.0 |  |  | 11.7 |  |  | 56.6 |  |
| Restructuring and related charges | — |  |  | 0.6 |  |  | — |  |  | 3.8 |  |
| Interest and other (income) expenses, net | — |  |  | 0.1 |  |  | (0.1 | ) |  | 0.1 |  |
| Interest expense | — |  |  | 0.3 |  |  | 0.1 |  |  | 0.7 |  |
| Total allocated costs | $ | — |  |  | $ | 21.2 |  |  | $ | 11.7 |  |  | $ | 61.4 |  |
  (was, 2016-02-04, similarity 0.7231):
[0001628280-16-010773:note_history:18]
|  | Three Months Ended |  | Six Months Ended |
|  | December 26, 2015 |  | December 27, 2014 |  | December 26, 2015 |  | December 27, 2014 |
| Selling, general and administrative | $ | — |  |  | $ | 19.8 |  |  | $ | 11.7 |  |  | $ | 36.6 |  |
| Restructuring and related charges | — |  |  | 3.2 |  |  | — |  |  | 3.2 |  |
| Interest and other (income) expenses, net | — |  |  | (0.1 | ) |  | (0.1 | ) |  | — |  |
| Interest expense | — |  |  | 0.2 |  |  | 0.1 |  |  | 0.4 |  |
| Total allocated costs | $ | — |  |  | $ | 23.1 |  |  | $ | 11.7 |  |  | $ | 40.2 |  |

- removed (2016-05-04):
[0001628280-16-010773:note_history:19]
The Supply Agreement contains a $15.0 million purchase commitment with Viavi for certain products, and for the three and six months ended December 26, 2015, the Company purchased $6.5 million in product from Viavi against the $15.0 million purchase commitment. During the three and six months ended December 26, 2015, the Company recognized revenue of $0.7 million and  $1.5 million, respectively, due to products sold to Viavi. For the three and six months ended December 26, 2015, the Company recorded $0.7 million and $1.2 million, respectively, in research and development cost reimbursement and $0.2 million and $0.3 million, respectively, in sublease rental income. As of December 26, 2015, the Company had $1.0 million in accounts receivable due from Viavi.


## us-gaap:ScheduleOfRelatedPartyTransactionsTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2016-05-04):
[0001628280-16-015527:note_history:20]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 2, 2016 |  | March 28, 2015 |  | April 2, 2016 |  | March 28, 2015 |
| Research and development | $ | — |  |  | $ | 0.2 |  |  | $ | — |  |  | $ | 0.2 |  |
| Selling, general and administrative | — |  |  | 20.0 |  |  | 11.7 |  |  | 56.6 |  |
| Restructuring and related charges | — |  |  | 0.6 |  |  | — |  |  | 3.8 |  |
| Interest and other (income) expenses, net | — |  |  | 0.1 |  |  | (0.1 | ) |  | 0.1 |  |
| Interest expense | — |  |  | 0.3 |  |  | 0.1 |  |  | 0.7 |  |
| Total allocated costs | $ | — |  |  | $ | 21.2 |  |  | $ | 11.7 |  |  | $ | 61.4 |  |
  (was, 2016-02-04, similarity 0.7231):
[0001628280-16-010773:note_history:20]
|  | Three Months Ended |  | Six Months Ended |
|  | December 26, 2015 |  | December 27, 2014 |  | December 26, 2015 |  | December 27, 2014 |
| Selling, general and administrative | $ | — |  |  | $ | 19.8 |  |  | $ | 11.7 |  |  | $ | 36.6 |  |
| Restructuring and related charges | — |  |  | 3.2 |  |  | — |  |  | 3.2 |  |
| Interest and other (income) expenses, net | — |  |  | (0.1 | ) |  | (0.1 | ) |  | — |  |
| Interest expense | — |  |  | 0.2 |  |  | 0.1 |  |  | 0.4 |  |
| Total allocated costs | $ | — |  |  | $ | 23.1 |  |  | $ | 11.7 |  |  | $ | 40.2 |  |
