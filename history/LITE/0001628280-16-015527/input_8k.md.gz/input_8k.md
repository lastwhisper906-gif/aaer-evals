# LITE 8-K — 0001628280-16-015501 filed 2016-05-04

## item codes, every 8-K on or before 2016-05-04

- 2016-05-04 0001628280-16-015501 — 2.02, 9.01
- 2016-02-16 0001628280-16-011261 — 5.02, 9.01
- 2016-02-04 0001628280-16-010758 — 5.02, 9.01
- 2016-02-04 0001628280-16-010755 — 2.02, 9.01
- 2015-11-17 0001193125-15-378953 — 7.01
- 2015-11-10 0001628280-15-008606 — 2.02, 9.01
- 2015-09-28 0001193125-15-329665 — 8.01, 9.01
- 2015-08-11 0001193125-15-286405 — 7.01, 9.01
- 2015-08-06 0001193125-15-281219 — 1.01, 5.02, 5.03, 5.05, 8.01, 9.01
- 2015-08-03 0001193125-15-274808 — 5.03, 9.01

## late-filing notifications on or before 2016-05-04

- 2015-11-10 0001628280-15-008612 — NT 10-Q, for the period ended 2015-09-26
- 2015-09-28 0001193125-15-329672 — NT 10-K, for the period ended 2015-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001628280-16-015501:8k_2_02:1]
EX-99.1
2
lite_ex991xq3fy16.htm
EXHIBIT 99.1

[0001628280-16-015501:8k_2_02:2]
Exhibit

[0001628280-16-015501:8k_2_02:3]
Exhibit 99.1

[0001628280-16-015501:8k_2_02:4]
NEWS RELEASE

[0001628280-16-015501:8k_2_02:5]
LUMENTUM ANNOUNCES FISCAL THIRD QUARTER 2016 RESULTS

[0001628280-16-015501:8k_2_02:6]
| • | Net Revenue of $230.4 million exceeded mid-point of guidance |

[0001628280-16-015501:8k_2_02:7]
| • | Non-GAAP Operating margin of 8.8% at mid-point of guidance; GAAP Operating margin of (1.0)% |

[0001628280-16-015501:8k_2_02:8]
| • | Non-GAAP Net income per share of $0.32 exceeded mid-point of guidance; GAAP Net income per share of $(0.13)(a) |

[0001628280-16-015501:8k_2_02:9]
Milpitas, Calif., May 4, 2016 – Lumentum Holdings Inc. (“Lumentum” or the “Company”) today reported results for its fiscal third quarter ended April 2, 2016.

[0001628280-16-015501:8k_2_02:10]
Net revenue for the fiscal third quarter 2016 was $230.4 million, with GAAP net loss of $(7.6) million, or $(0.13) per share. Net revenue for fiscal second quarter 2016 was $218.3 million, with GAAP net income of $2.8 million, or $0.05 per share. Net revenue for the fiscal third quarter 2015 was $198.7 million, with GAAP net income of $12.2 million, or $0.21 per share.

[0001628280-16-015501:8k_2_02:11]
Non-GAAP net income for the fiscal third quarter 2016 was $19.7 million or $0.32 per share. Non-GAAP net income for fiscal second quarter 2016 was $19.1 million, or $0.31 per share. Non-GAAP net income for the fiscal third quarter 2015 was $6.2 million, or $0.11 per share. The Company held $157.2 million in total cash at the end of the fiscal third quarter 2016, which decreased by $4.7 million sequentially, and the Company remains debt-free.

[0001628280-16-015501:8k_2_02:12]
“We again executed on our plan in the fiscal third quarter and delivered record revenues that grew 16% over the same period last year,” said Alan Lowe, president and CEO. “Datacom revenue grew 30% sequentially, achieving record revenues, driven by a more than 140% sequential increase in 100G related revenues. TrueFlexTM ROADM revenue grew approximately 30% sequentially and more than tripled from last year. Bookings were robust during the quarter, with a book-to-bill ratio greater than one, as the North America metro deployment is poised to ramp, hyperscale data centers ready themselves for the shift to 100G, and China demand remains strong.”

[0001628280-16-015501:8k_2_02:13]
Financial Overview – Fiscal Third Quarter Ended April 2, 2016

[0001628280-16-015501:8k_2_02:14]
|  | GAAP Results ($ in millions) |
|  | Q3 |  | Q2 |  | Q3 |  | Change |
|  | FY 2016 |  | FY 2016 |  | FY2015 |  | Q/Q |  | Y/Y |
| Net revenue | $ | 230.4 |  |  | $ | 218.3 |  |  | $ | 198.7 |  |  | 5.5 | % |  | 16.0 | % |
| Gross margin | 27.3 | % |  | 31.2 | % |  | 28.7 | % |  | (390)bps |  |  | (140)bps |  |
| Operating margin | (1.0 | )% |  | 2.8 | % |  | (5.4 | )% |  | (380)bps |  |  | 440bps |  |
|  | Non-GAAP Results ($ in millions) |
|  | Q3 |  | Q2 |  | Q3 |  | Change |
|  | FY 2016 |  | FY 2016 |  | FY2015 |  | Q/Q |  | Y/Y |
| Net revenue | $ | 230.4 |  |  | $ | 218.3 |  |  | $ | 198.7 |  |  | 5.5 | % |  | 16.0 | % |
| Gross margin | 32.2 | % |  | 32.7 | % |  | 30.5 | % |  | (50)bps |  |  | 170bps |  |
| Operating margin | 8.8 | % |  | 9.0 | % |  | 2.7 | % |  | (20)bps |  |  | 610bps |  |

[0001628280-16-015501:8k_2_02:15]
|  | Net Revenue by Segment |
|  | Q3 |  | % of |  | Q2 |  | Q3 |  | Change |
|  | FY 2016 |  | Net Revenue |  | FY 2016 |  | FY 2015 |  | Q/Q |  | Y/Y |
| Optical Communications | $ | 197.2 |  |  | 85.6 | % |  | $ | 185.8 |  |  | $ | 167.2 |  |  | 6.1 | % |  | 17.9 | % |
| Lasers | 33.2 |  |  | 14.4 | % |  | 32.5 |  |  | 31.5 |  |  | 2.2 | % |  | 5.4 | % |
| Total | $ | 230.4 |  |  | 100.0 | % |  | $ | 218.3 |  |  | $ | 198.7 |  |  | 5.5 | % |  | 16.0 | % |

[0001628280-16-015501:8k_2_02:16]
The tables above provide comparisons of quarterly results to prior periods, including sequential quarterly and year-over-year changes. A reconciliation between GAAP and non-GAAP measures is contained in this release under the section titled “Use of Non-GAAP Financial Measures.”

[0001628280-16-015501:8k_2_02:17]
Business Outlook

[0001628280-16-015501:8k_2_02:18]
For the fiscal fourth quarter 2016, the Company expects net revenue to be in the range of $232 million to $242 million, non-GAAP operating margin to be 8.5% to 10.0%, and non-GAAP earnings per share to be $0.32 to $0.38 per share, based on approximately 62 million shares on a fully diluted basis. These estimates are based upon a thirteen week fiscal quarter compared with fourteen weeks for the fiscal third quarter 2016.

[0001628280-16-015501:8k_2_02:19]
Conference Call

[0001628280-16-015501:8k_2_02:20]
Lumentum will host a conference call on May 4, 2016 at 1:30pm PT/4:30pm ET. A live webcast of the call and the replay will be available on the Lumentum website at http://investor.lumentum.com. Supporting materials outlining the Company’s latest financial results will be posted on http://investor.lumentum.com under the “Events and Presentations” section concurrently with this earnings press release. This press release is being furnished as a Current Report on Form 8-K with the Securities and Exchange Commission and will be available at http://www.sec.gov/.

[0001628280-16-015501:8k_2_02:21]
About Lumentum

[0001628280-16-015501:8k_2_02:22]
Lumentum (NASDAQ: LITE) is a market-leading manufacturer of innovative optical and photonic products enabling optical networking and commercial laser customers worldwide. Lumentum’s optical components and subsystems are part of virtually every type of telecom, enterprise, and data center network. Lumentum’s commercial lasers enable advanced manufacturing techniques and diverse applications including next-generation 3D sensing capabilities. Lumentum is headquartered in Milpitas, California with R&D, manufacturing, and sales offices worldwide.  For more information, visit https://www.lumentum.com/en.

[0001628280-16-015501:8k_2_02:23]
Forward-Looking Statements

[0001628280-16-015501:8k_2_02:24]
Contact Information

[0001628280-16-015501:8k_2_02:25]
Investors: Chris Coldren, 408-404-0606; investor.relations@lumentum.com

[0001628280-16-015501:8k_2_02:26]
Press: Greg Kaufman, 408-546-4235; media@lumentum.com

[0001628280-16-015501:8k_2_02:27]
The following financial tables are presented in accordance with GAAP, unless otherwise specified.

[0001628280-16-015501:8k_2_02:28]
LUMENTUM HOLDINGS INC.

[0001628280-16-015501:8k_2_02:29]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0001628280-16-015501:8k_2_02:30]
(in millions, except per share data)

[0001628280-16-015501:8k_2_02:31]
(unaudited)

[0001628280-16-015501:8k_2_02:32]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 2, 2016 |  | March 28, 2015 |  | April 2, 2016 |  | March 28, 2015 |
| Net revenue | $ | 230.4 |  |  | $ | 198.7 |  |  | $ | 661.3 |  |  | $ | 628.2 |  |
| Cost of sales | 165.9 |  |  | 139.7 |  |  | 458.4 |  |  | 428.2 |  |
| Amortization of acquired technologies | 1.7 |  |  | 1.9 |  |  | 5.1 |  |  | 5.7 |  |
| Gross profit | 62.8 |  |  | 57.1 |  |  | 197.8 |  |  | 194.3 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 35.3 |  |  | 35.0 |  |  | 104.7 |  |  | 105.1 |  |
| Selling, general and administrative | 28.0 |  |  | 31.8 |  |  | 87.8 |  |  | 91.3 |  |
| Restructuring and related charges | 1.8 |  |  | 1.1 |  |  | 3.9 |  |  | 6.7 |  |
| Total operating expenses | 65.1 |  |  | 67.9 |  |  | 196.4 |  |  | 203.1 |  |
| Income (loss) from operations | (2.3 | ) |  | (10.8 | ) |  | 1.4 |  |  | (8.8 | ) |
| Unrealized loss on derivative liability | (4.8 | ) |  | — |  |  | (5.0 | ) |  | — |  |
| Interest and other (expense) income, net | (0.4 | ) |  | (0.4 | ) |  | (1.1 | ) |  | (0.8 | ) |
| Income (loss) before income taxes | (7.5 | ) |  | (11.2 | ) |  | (4.7 | ) |  | (9.6 | ) |
| Provision for (benefit from) income taxes | 0.1 |  |  | (23.4 | ) |  | 0.3 |  |  | (22.0 | ) |
| Net income (loss) | (7.6 | ) |  | 12.2 |  |  | (5.0 | ) |  | 12.4 |  |
| Net income (loss) per share:(a) |  |  |  |  |  |  |  |
| Basic | $ | (0.13 | ) |  | $ | 0.21 |  |  | $ | (0.08 | ) |  | $ | 0.21 |  |
| Diluted | $ | (0.13 | ) |  | $ | 0.21 |  |  | $ | (0.08 | ) |  | $ | 0.21 |  |
| Items reconciling net income (loss) to net income (loss) available to common shareholders: |  |  |  |  |  |  |  |
| Cumulative dividends on Series A preferred stock | (0.3 | ) |  | — |  |  | (0.6 | ) |  | — |  |
| Adjustment for Series A preferred stock redemption value | — |  |  | — |  |  | (11.7 | ) |  | — |  |
| Net income (loss) available to common shareholders | $ | (7.9 | ) |  | $ | 12.2 |  |  | $ | (17.3 | ) |  | $ | 12.4 |  |
| Net income (loss) available to common shareholders per share: |  |  |  |  |  |  |  |
| Basic | $ | (0.13 | ) |  | $ | 0.21 |  |  | $ | (0.29 | ) |  | $ | 0.21 |  |
| Diluted | $ | (0.13 | ) |  | $ | 0.21 |  |  | $ | (0.29 | ) |  | $ | 0.21 |  |
| Shares used in per share calculation:(a) |  |  |  |  |  |  |  |
| Basic | 59.2 |  |  | 58.8 |  |  | 59.0 |  |  | 58.8 |  |
| Diluted | 59.2 |  |  | 58.8 |  |  | 59.0 |  |  | 58.8 |  |

[0001628280-16-015501:8k_2_02:33]
| (a) | On August 1, 2015, JDSU distributed 47.1 million shares, or 80.1% of the outstanding shares of common stock of Lumentum to existing holders of JDSU common stock. JDSU was renamed Viavi Solutions Inc. and at the time of the distribution, retained 11.7 million shares, or 19.9% of Lumentum’s outstanding shares. Basic and diluted net income (loss) per share for the three and nine months ended March 28, 2015 are calculated using the shares of Lumentum common stock outstanding on August 1, 2015. |

[0001628280-16-015501:8k_2_02:34]
LUMENTUM HOLDINGS INC.

[0001628280-16-015501:8k_2_02:35]
CONSOLIDATED BALANCE SHEETS

[0001628280-16-015501:8k_2_02:36]
(in millions, except share and per share data)

[0001628280-16-015501:8k_2_02:37]
(unaudited)

[0001628280-16-015501:8k_2_02:38]
|  | April 2, 2016 |  | June 27, 2015 |
| ASSETS |  |  |  |  |  |
| Current assets: |  |  |  |  |  |
| Cash and cash equivalents | $ | 157.2 |  |  | $ | 14.5 |  |
| Accounts receivable, net | 160.2 |  |  | 150.5 |  |
| Inventories | 107.2 |  |  | 99.7 |  |
| Prepayments and other current assets | 58.7 |  |  | 46.1 |  |
| Total current assets | 483.3 |  |  | 310.8 |  |
| Property, plant and equipment, net | 168.1 |  |  | 143.2 |  |
| Goodwill and intangibles, net | 21.9 |  |  | 27.4 |  |
| Deferred income taxes, net | 30.1 |  |  | 30.3 |  |
| Other non-current assets | 1.5 |  |  | 0.9 |  |
| Total assets | $ | 704.9 |  |  | 512.6 |  |
| LIABILITIES, MEZZANINE EQUITY AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 111.7 |  |  | $ | 77.9 |  |
| Accrued payroll and related expenses | 27.3 |  |  | 17.7 |  |
| Income taxes payable | 2.0 |  |  | 3.7 |  |
| Accrued expenses | 18.2 |  |  | 11.5 |  |
| Other current liabilities | 9.8 |  |  | 11.4 |  |
| Total current liabilities | 169.0 |  |  | 122.2 |  |
| Derivative liability | 14.7 |  |  | — |  |
| Other non-current liabilities | 8.7 |  |  | 9.8 |  |
| Total liabilities | 192.4 |  |  | 132.0 |  |
| Mezzanine equity: |  |  |  |
| Non-controlling Interest Redeemable convertible Series A preferred stock, $0.001 par value, 10,000,000 authorized shares; 35,805 shares issued and outstanding as of April 2, 2016, and no shares issued and outstanding as of June 27, 2015 | 35.8 |  |  | — |  |
| Total mezzanine equity | 35.8 |  |  | — |  |
| Stockholders’ equity: |  |  |  |
| Viavi net investment | — |  |  | 368.1 |  |
| Common stock, $0.001 par value, 990,000,000 authorized shares, 59,244,599 shares issued and outstanding as of April 2, 2016, and no shares issued and outstanding as of June 27, 2015 | 0.1 |  |  | — |  |
| Additional paid-in capital | 461.1 |  |  | — |  |
| Retained earnings | 6.2 |  |  | — |  |
| Accumulated other comprehensive income | 9.3 |  |  | 12.5 |  |
| Total stockholders’ equity | 476.7 |  |  | 380.6 |  |
| Total liabilities, mezzanine equity and stockholders’ equity | $ | 704.9 |  |  | $ | 512.6 |  |

[0001628280-16-015501:8k_2_02:39]
Use of Non-GAAP Financial Measures

[0001628280-16-015501:8k_2_02:40]
In this press release, Lumentum provides investors with gross margin, operating margin, net income, and net income (loss) per share on a non-GAAP basis. Lumentum believes this non-GAAP financial information provides additional insight into the Company's on-going performance and has therefore chosen to provide this information to investors for a more consistent basis of comparison and to help them evaluate the results of the Company's on-going operations and enable more meaningful period to period comparisons. Specifically, the Company believes that providing this information allows investors to better understand the Company’s financial performance and, importantly, to evaluate the efficacy of the methodology and information used by management to evaluate and measure such operating performance.  However, these measures may be different from non-GAAP measures used by other companies, limiting their usefulness for comparison purposes. The non-GAAP financial measures used in this press release should not be considered in isolation from measures of financial performance prepared in accordance with GAAP. Investors are cautioned that there are material limitations associated with the use of non-GAAP financial measures as an analytical tool. In particular, many of the adjustments to our GAAP financial measures reflect the exclusion of items that are recurring and will be reflected in our financial results for the foreseeable future.

[0001628280-16-015501:8k_2_02:41]
Non-GAAP gross margin, non-GAAP operating margin, non-GAAP net income (loss), and non-GAAP net income (loss) per share, and Adjusted EBITDA exclude (i) workforce related charges such as severance, retention bonuses and employee relocation costs related to formal restructuring plans, (ii) costs for facilities not required for ongoing operations, and costs related to the relocation of certain equipment from these facilities and/or contract manufacturer facilities, (iii) stock-based compensation, (iv) amortization of intangibles, and (v) other non-recurring charges comprising mainly of one-time provision for excess and obsolete inventory, acquisition, integration, litigation and other costs and contingencies unrelated to current and future operations including post-separation activities such as small site consolidations, reorganizations, insourcing or outsourcing of activities, severance related costs and transition related costs for the separation from Viavi. Beginning in the third fiscal quarter 2016, we began to exclude unrealized gain or loss on derivative liability for the Series A Preferred Stock to Adjusted EBITDA and prior periods have been adjusted. Management does not believe that these items are reflective of the Company's underlying operating performance. The presentation of these and other similar items in Lumentum's non-GAAP financial results should not be interpreted as implying that these items are non-recurring, infrequent or unusual.

[0001628280-16-015501:8k_2_02:42]
A quantitative reconciliation between GAAP and non-GAAP financial data with respect to historical periods is included in the supplemental financial table attached to this press release. The Company has not reconciled its projections of non-GAAP earnings per share.  As items that impact net loss are out of the Company's control and/or cannot be reasonably predicted, Lumentum has determined that a quantitative reconciliation of forward-looking non-GAAP financial measures to their most directly comparable GAAP financial measures cannot be provided without unreasonable efforts.

[0001628280-16-015501:8k_2_02:43]
LUMENTUM HOLDINGS INC.

[0001628280-16-015501:8k_2_02:44]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001628280-16-015501:8k_2_02:45]
(in millions, except per share data)

[0001628280-16-015501:8k_2_02:46]
(unaudited)

[0001628280-16-015501:8k_2_02:47]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 2, 2016 |  | March 28, 2015 |  | April 2, 2016 |  | March 28, 2015 |
| Gross profit on GAAP basis | $ | 62.8 |  |  | $ | 57.1 |  |  | $ | 197.8 |  |  | $ | 194.3 |  |
| Stock-based compensation | 2.2 |  |  | 1.3 |  |  | 4.9 |  |  | 3.9 |  |
| Other charges related to non-recurring activities (b) | 7.5 |  |  | 0.4 |  |  | 7.5 |  |  | 1.4 |  |
| Amortization of acquired developed technologies | 1.7 |  |  | 1.9 |  |  | 5.1 |  |  | 5.7 |  |
| Gross profit on non-GAAP basis | $ | 74.2 |  |  | $ | 60.7 |  |  | $ | 215.3 |  |  | $ | 205.3 |  |
| Research and development on GAAP basis | $ | 35.3 |  |  | $ | 35.0 |  |  | $ | 104.7 |  |  | $ | 105.1 |  |
| Stock-based compensation | (2.5 | ) |  | (1.9 | ) |  | (6.7 | ) |  | (5.6 | ) |
| Other charges related to non-recurring activities | — |  |  | (0.2 | ) |  | (0.6 | ) |  | (0.2 | ) |
| Research and development on non-GAAP basis | $ | 32.8 |  |  | $ | 32.9 |  |  | $ | 97.4 |  |  | $ | 99.3 |  |
| Selling, general and administrative on GAAP basis | $ | 28.0 |  |  | $ | 31.8 |  |  | $ | 87.8 |  |  | $ | 91.3 |  |
| Stock-based compensation | (3.4 | ) |  | (4.3 | ) |  | (9.3 | ) |  | (11.6 | ) |
| Other charges related to non-recurring activities | (3.4 | ) |  | (4.9 | ) |  | (15.4 | ) |  | (9.3 | ) |
| Amortization of intangibles | (0.1 | ) |  | (0.1 | ) |  | (0.3 | ) |  | (0.3 | ) |
| Selling, general and administrative on non-GAAP basis | $ | 21.1 |  |  | $ | 22.5 |  |  | $ | 62.8 |  |  | $ | 70.1 |  |
| Restructuring and related charges on GAAP basis | $ | 1.8 |  |  | $ | 1.1 |  |  | $ | 3.9 |  |  | $ | 6.7 |  |
| Restructuring and related charges | (1.8 | ) |  | (1.1 | ) |  | (3.9 | ) |  | (6.7 | ) |
| Restructuring and related charges on non-GAAP basis | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Income (loss) from operations on GAAP basis | $ | (2.3 | ) |  | $ | (10.8 | ) |  | $ | 1.4 |  |  | $ | (8.8 | ) |
| Stock-based compensation | 8.1 |  |  | 7.5 |  |  | 20.9 |  |  | 21.1 |  |
| Other charges related to non-recurring activities | 10.9 |  |  | 5.5 |  |  | 23.5 |  |  | 10.9 |  |
| Amortization of intangibles | 1.8 |  |  | 2.0 |  |  | 5.4 |  |  | 6.0 |  |
| Restructuring and related charges | 1.8 |  |  | 1.1 |  |  | 3.9 |  |  | 6.7 |  |
| Income (loss) from operations on non-GAAP basis | $ | 20.3 |  |  | $ | 5.3 |  |  | $ | 55.1 |  |  | $ | 35.9 |  |
| Unrealized loss on derivative liability on GAAP basis | $ | (4.8 | ) |  | $ | — |  |  | $ | (5.0 | ) |  | $ | — |  |
| Unrealized loss on derivative liability | 4.8 |  |  | — |  |  | 5.0 |  |  | — |  |
| Unrealized loss on derivative liability on non-GAAP basis | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Income (loss) before income taxes on GAAP basis | $ | (7.5 | ) |  | $ | (11.2 | ) |  | $ | (4.7 | ) |  | $ | (9.6 | ) |
| Stock-based compensation | 8.1 |  |  | 7.5 |  |  | 20.9 |  |  | 21.1 |  |
| Other charges related to non-recurring activities | 10.9 |  |  | 5.5 |  |  | 23.5 |  |  | 10.9 |  |
| Amortization of intangibles | 1.8 |  |  | 2.0 |  |  | 5.4 |  |  | 6.0 |  |
| Restructuring and related charges | 1.8 |  |  | 1.1 |  |  | 3.9 |  |  | 6.7 |  |
| Unrealized loss on derivative liability | 4.8 |  |  | — |  |  | 5.0 |  |  | — |  |

[0001628280-16-015501:8k_2_02:48]
| Income (loss) before income taxes on non-GAAP basis | $ | 19.9 |  |  | $ | 4.9 |  |  | $ | 54.0 |  |  | $ | 35.1 |  |
| Provision for income taxes on GAAP basis | $ | 0.1 |  |  | $ | (23.4 | ) |  | $ | 0.3 |  |  | $ | (22.0 | ) |
| Non-cash income tax (benefit) expense | 0.1 |  |  | 22.1 |  |  | 0.1 |  |  | 20.3 |  |
| Provision (benefit) for income taxes on non-GAAP basis | $ | 0.2 |  |  | $ | (1.3 | ) |  | $ | 0.4 |  |  | $ | (1.7 | ) |
| Net income (loss) on GAAP basis | $ | (7.6 | ) |  | $ | 12.2 |  |  | $ | (5.0 | ) |  | $ | 12.4 |  |
| Stock-based compensation | 8.1 |  |  | 7.5 |  |  | 20.9 |  |  | 21.1 |  |
| Other charges related to non-recurring activities | 10.9 |  |  | 5.5 |  |  | 23.5 |  |  | 10.9 |  |
| Amortization of intangibles | 1.8 |  |  | 2.0 |  |  | 5.4 |  |  | 6.0 |  |
| Restructuring and related charges | 1.8 |  |  | 1.1 |  |  | 3.9 |  |  | 6.7 |  |
| Unrealized loss on derivative liability | 4.8 |  |  | — |  |  | 5.0 |  |  | — |  |
| Non-cash income tax (benefit) expense | (0.1 | ) |  | (22.1 | ) |  | (0.1 | ) |  | (20.3 | ) |
| Net income on non-GAAP basis | $ | 19.7 |  |  | $ | 6.2 |  |  | $ | 53.6 |  |  | $ | 36.8 |  |
| Net income per share on non-GAAP basis | $ | 0.32 |  |  | $ | 0.11 |  |  | $ | 0.88 |  |  | $ | 0.63 |  |
| Shares used in per share calculation - diluted on GAAP basis | 59.2 |  |  | 58.8 |  |  | 59.0 |  |  | 58.8 |  |
| Non-GAAP adjustment (c) | 2.3 |  |  | — |  |  | 1.9 |  |  | — |  |
| Shares used in per share calculation - diluted on non-GAAP basis | 61.5 |  |  | 58.8 |  |  | 60.9 |  |  | 58.8 |  |

[0001628280-16-015501:8k_2_02:49]
| (b) | Other charges related to non-recurring activities for the three and nine months ended April 2, 2016 include $7.2 million of provision for excess and obsolete inventory relating to certain 3D sensing products. |

[0001628280-16-015501:8k_2_02:50]
| (c) | This adjustment represents weighted-average potentially dilutive securities excluded from the computation of diluted net loss per share attributable to common stockholders on GAAP basis because the effect would have been anti-dilutive. This adjustment amount is added for the computation of diluted net income per share on non-GAAP basis as we had a net income on non-GAAP basis for the three and nine months ended April 2, 2016. |

[0001628280-16-015501:8k_2_02:51]
LUMENTUM HOLDINGS INC.

[0001628280-16-015501:8k_2_02:52]
RECONCILIATION OF GAAP NET INCOME (LOSS) TO ADJUSTED EBITDA

[0001628280-16-015501:8k_2_02:53]
(in millions)

[0001628280-16-015501:8k_2_02:54]
(unaudited)

[0001628280-16-015501:8k_2_02:55]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 2, 2016 |  | March 28, 2015 |  | April 2, 2016 |  | March 28, 2015 |
| GAAP net income (loss) | $ | (7.6 | ) |  | $ | 12.2 |  |  | $ | (5.0 | ) |  | $ | 12.4 |  |
| Interest and other (expense) income, net | 0.4 |  |  | 0.4 |  |  | 1.1 |  |  | 0.8 |  |
| Provision for income taxes | 0.1 |  |  | (23.4 | ) |  | 0.3 |  |  | (22.0 | ) |
| Depreciation | 11.3 |  |  | 10.9 |  |  | 35.1 |  |  | 32.1 |  |
| Amortization | 1.8 |  |  | 2.0 |  |  | 5.4 |  |  | 6.0 |  |
| EBITDA | 6.0 |  |  | 2.1 |  |  | 36.9 |  |  | 29.3 |  |
| Costs related to restructuring and related charges | 1.8 |  |  | 1.1 |  |  | 3.9 |  |  | 6.7 |  |
| Costs related to stock-based compensation | 8.1 |  |  | 7.5 |  |  | 20.9 |  |  | 21.1 |  |
| Costs related to other non-recurring activities | 10.9 |  |  | 5.5 |  |  | 23.5 |  |  | 10.9 |  |
| Unrealized loss on derivative liability | 4.8 |  |  | — |  |  | 5.0 |  |  | — |  |
| Adjusted EBITDA | $ | 31.6 |  |  | $ | 16.2 |  |  | $ | 90.2 |  |  | $ | 68.0 |  |
