# LITE MD&A — 0001628280-16-015527


## mdna

[0001628280-16-015527:mdna:1]
[same as prior period, unchanged from 0001628280-16-010773:mdna:1]

[0001628280-16-015527:mdna:2]
[same as prior period, unchanged from 0001628280-16-010773:mdna:2]

[0001628280-16-015527:mdna:3]
[same as prior period, unchanged from 0001628280-16-010773:mdna:3]

[0001628280-16-015527:mdna:4]
[same as prior period, unchanged from 0001628280-16-010773:mdna:4]

[0001628280-16-015527:mdna:5]
[same as prior period, unchanged from 0001628280-16-010773:mdna:5]

[0001628280-16-015527:mdna:6]
[same as prior period, unchanged from 0001628280-16-010773:mdna:6]

[0001628280-16-015527:mdna:7]
| • | expectations regarding our expenses and cost structure, the timing of payment of lease costs and other contractual obligations, future tax rates and the timing of recognition of stock-based compensation and other expenses; |

[0001628280-16-015527:mdna:8]
| • | financial projections and expectations, including profitability of certain business units, plans to reduce costs and improve efficiencies, the effects of seasonality on certain business units, continued reliance on key customers for a significant portion of our revenue, future sources of revenue, competition and pricing pressures, future revenue from international customers, our future liquidity and cash flow requirements, the future impact of certain accounting pronouncements and our estimation of the potential impact and materiality of litigation; |

[0001628280-16-015527:mdna:9]
[same as prior period, unchanged from 0001628280-16-010773:mdna:9]

[0001628280-16-015527:mdna:10]
[same as prior period, unchanged from 0001628280-16-010773:mdna:10]

[0001628280-16-015527:mdna:11]
[same as prior period, unchanged from 0001628280-16-010773:mdna:11]

[0001628280-16-015527:mdna:12]
[same as prior period, unchanged from 0001628280-16-010773:mdna:12]

[0001628280-16-015527:mdna:13]
[same as prior period, unchanged from 0001628280-16-010773:mdna:13]

[0001628280-16-015527:mdna:14]
[same as prior period, unchanged from 0001628280-16-010773:mdna:14]

[0001628280-16-015527:mdna:15]
[same as prior period, unchanged from 0001628280-16-010773:mdna:15]

[0001628280-16-015527:mdna:16]
[same as prior period, unchanged from 0001628280-16-010773:mdna:16]

[0001628280-16-015527:mdna:17]
[same as prior period, unchanged from 0001628280-16-010773:mdna:17]

[0001628280-16-015527:mdna:18]
[same as prior period, unchanged from 0001628280-16-010773:mdna:18]

[0001628280-16-015527:mdna:19]
On July 31, 2015, prior to the Separation, Viavi transferred substantially all of the assets and liabilities and operations of the communications and commercial optical products (“CCOP”) segment and WaveReady product lines to Lumentum (the “Capitalization”). Our financial statements for periods prior to the Capitalization were prepared on a stand-alone basis and were derived from Viavi’s consolidated financial statements and accounting records. For the period from June 28, 2015 to August 1, 2015, expenses were allocated to us using estimates that we consider to be a reasonable reflection of the utilization of services provided to or benefits received by us.

[0001628280-16-015527:mdna:20]
The consolidated financial statements include certain assets and liabilities that were historically held at the Viavi level but which were transferred to us in the Capitalization. Viavi’s debt and related interest expense were not attributed or allocated to us for the periods presented since we are not the legal obligor of the debt and Viavi’s borrowings were not directly attributable to us. Certain intercompany transactions between us and Viavi were considered to be effectively settled in the consolidated financial statements at the time the transactions were recorded. The total net effect of the settlement of these intercompany transactions is reflected in our consolidated statements of cash flows as a financing activity and on the consolidated balance sheets as Viavi net investment.

[0001628280-16-015527:mdna:21]
[same as prior period, unchanged from 0001628280-16-010773:mdna:21]

[0001628280-16-015527:mdna:22]
[same as prior period, unchanged from 0001628280-16-010773:mdna:22]

[0001628280-16-015527:mdna:23]
[same as prior period, unchanged from 0001628280-16-010773:mdna:23]

[0001628280-16-015527:mdna:24]
[same as prior period, unchanged from 0001628280-16-010773:mdna:24]

[0001628280-16-015527:mdna:25]
[same as prior period, unchanged from 0001628280-16-010773:mdna:25]

[0001628280-16-015527:mdna:26]
[same as prior period, unchanged from 0001628280-16-010773:mdna:26]

[0001628280-16-015527:mdna:27]
[same as prior period, unchanged from 0001628280-16-010773:mdna:27]

[0001628280-16-015527:mdna:28]
[same as prior period, unchanged from 0001628280-16-010773:mdna:28]

[0001628280-16-015527:mdna:29]
[same as prior period, unchanged from 0001628280-16-010773:mdna:29]

[0001628280-16-015527:mdna:30]
[same as prior period, unchanged from 0001628280-16-010773:mdna:30]

[0001628280-16-015527:mdna:31]
[same as prior period, unchanged from 0001628280-16-010773:mdna:31]

[0001628280-16-015527:mdna:32]
[same as prior period, unchanged from 0001628280-16-010773:mdna:32]

[0001628280-16-015527:mdna:33]
[same as prior period, unchanged from 0001628280-16-010773:mdna:33]

[0001628280-16-015527:mdna:34]
[same as prior period, unchanged from 0001628280-16-010773:mdna:34]

[0001628280-16-015527:mdna:35]
[same as prior period, unchanged from 0001628280-16-010773:mdna:35]

[0001628280-16-015527:mdna:36]
[same as prior period, unchanged from 0001628280-16-010773:mdna:36]

[0001628280-16-015527:mdna:37]
[same as prior period, unchanged from 0001628280-16-010773:mdna:37]

[0001628280-16-015527:mdna:38]
[same as prior period, unchanged from 0001628280-16-010773:mdna:38]

[0001628280-16-015527:mdna:39]
[same as prior period, unchanged from 0001628280-16-010773:mdna:39]

[0001628280-16-015527:mdna:40]
In the opinion of management, the consolidated financial statements included in this Form 10-Q contain all normal recurring adjustments necessary to state fairly our consolidated balance sheet as of April 2, 2016, our consolidated statements of operations and consolidated statements of comprehensive income (loss) for the three and nine months ended April 2, 2016 and March 28, 2015, and our consolidated statements of cash flows for the nine months ended April 2, 2016 and March 28, 2015.

[0001628280-16-015527:mdna:41]
The preparation of the consolidated financial statements in accordance with GAAP in the United States requires management to make estimates and assumptions that affect the amounts reported in our consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact us in the future, actual results may be different from the estimates. Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are revenue recognition, inventory valuation, allocation methods and allocated expenses from Viavi, valuation of goodwill and other intangible assets, share-based compensation, retirement and post-retirement plan assumptions, restructuring, warranty and accounting for income taxes.

[0001628280-16-015527:mdna:42]
[same as prior period, unchanged from 0001628280-16-010773:mdna:42]

[0001628280-16-015527:mdna:43]
Recently Issued Accounting Pronouncements

[0001628280-16-015527:mdna:44]
Refer to “Note 2. Recently Issued Accounting Pronouncements" to the consolidated financial statements included in this Form 10-Q regarding the effect of certain recent accounting pronouncements on our consolidated financial statements.

[0001628280-16-015527:mdna:45]
[same as prior period, unchanged from 0001628280-16-010773:mdna:45]

[0001628280-16-015527:mdna:46]
[same as prior period, unchanged from 0001628280-16-010773:mdna:46]

[0001628280-16-015527:mdna:47]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 2, 2016 |  | March 28, 2015 |  | April 2, 2016 |  | March 28, 2015 |
| Segment net revenue: |  |  |  |  |  |  |  |
| OpComms | 85.6 | % |  | 84.1 | % |  | 84.7 | % |  | 82.0 | % |
| Lasers | 14.4 |  |  | 15.9 |  |  | 15.3 |  |  | 18.0 |  |
| Net revenue | 100.0 |  |  | 100.0 |  |  | 100.0 |  |  | 100.0 |  |
| Cost of sales | 72.0 |  |  | 70.3 |  |  | 69.3 |  |  | 68.2 |  |
| Amortization of acquired technologies | 0.7 |  |  | 1.0 |  |  | 0.8 |  |  | 0.9 |  |
| Gross profit | 27.3 |  |  | 28.7 |  |  | 29.9 |  |  | 30.9 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 15.3 |  |  | 17.6 |  |  | 15.8 |  |  | 16.7 |  |
| Selling, general and administrative | 12.2 |  |  | 16.0 |  |  | 13.3 |  |  | 14.5 |  |
| Restructuring and related charges | 0.8 |  |  | 0.6 |  |  | 0.6 |  |  | 1.1 |  |
| Total operating expenses | 28.3 |  |  | 34.2 |  |  | 29.7 |  |  | 32.3 |  |
| Income (loss) from operations | (1.0 | ) |  | (5.4 | ) |  | 0.2 |  |  | (1.4 | ) |
| Unrealized loss on derivative liability | (2.1 | ) |  | — |  |  | (0.8 | ) |  | — |  |
| Interest and other (expense) income, net | (0.2 | ) |  | (0.2 | ) |  | (0.2 | ) |  | (0.1 | ) |
| Income (loss) before taxes | (3.3 | ) |  | (5.6 | ) |  | (0.7 | ) |  | (1.5 | ) |
| Provision for income taxes | — |  |  | (11.8 | ) |  | — |  |  | (3.5 | ) |
| Net income (loss) | (3.3 | )% |  | 6.1 | % |  | (0.8 | )% |  | 2.0 | % |

[0001628280-16-015527:mdna:48]
26

[0001628280-16-015527:mdna:49]
Financial Data for the three and nine months ended April 2, 2016 and March 28, 2015

[0001628280-16-015527:mdna:50]
[same as prior period, unchanged from 0001628280-16-010773:mdna:50]

[0001628280-16-015527:mdna:51]
|  | Three Months Ended |  |  |  |  |  | Nine Months Ended |  |  |  |  |
|  | April 2, 2016 |  | March 28, 2015 |  | Change |  | Percentage Change |  | April 2, 2016 |  | March 28, 2015 |  | Change |  | Percentage Change |
| Segment net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| OpComms | $ | 197.2 |  |  | $ | 167.2 |  |  | $ | 30.0 |  |  | 17.9 | % |  | $ | 560.1 |  |  | $ | 515.2 |  |  | $ | 44.9 |  |  | 8.7 | % |
| Lasers | 33.2 |  |  | 31.5 |  |  | 1.7 |  |  | 5.4 | % |  | 101.2 |  |  | 113.0 |  |  | (11.8 | ) |  | (10.4 | ) |
| Net revenue | $ | 230.4 |  |  | $ | 198.7 |  |  | $ | 31.7 |  |  | 16.0 | % |  | $ | 661.3 |  |  | $ | 628.2 |  |  | $ | 33.1 |  |  | 5.3 | % |
| Gross profit | $ | 62.8 |  |  | $ | 57.1 |  |  | $ | 5.7 |  |  | 10.0 | % |  | $ | 197.8 |  |  | $ | 194.3 |  |  | $ | 3.5 |  |  | 1.8 | % |
| Gross margin | 27.3 | % |  | 28.7 | % |  |  |  |  |  | 29.9 | % |  | 30.9 | % |  |  |  |  |
| Research and development | 35.3 |  |  | 35.0 |  |  | 0.3 |  |  | 0.9 | % |  | 104.7 |  |  | 105.1 |  |  | (0.4 | ) |  | (0.4 | )% |
| Percentage of net revenue | 15.3 | % |  | 17.6 | % |  |  |  |  |  | 15.8 | % |  | 16.7 | % |  |  |  |  |
| Selling, general and administrative | 28.0 |  |  | 31.8 |  |  | (3.8 | ) |  | (11.9 | )% |  | 87.8 |  |  | 91.3 |  |  | (3.5 | ) |  | (3.8 | )% |
| Percentage of net revenue | 12.2 | % |  | 16.0 | % |  |  |  |  |  | 13.3 | % |  | 14.5 | % |  |  |  |  |
| Restructuring and related charges | 1.8 |  |  | 1.1 |  |  | 0.7 |  |  | 63.6 | % |  | 3.9 |  |  | 6.7 |  |  | (2.8 | ) |  | (41.8 | )% |
| Percentage of net revenue | 0.8 | % |  | 0.6 | % |  |  |  |  |  | 0.6 | % |  | 1.1 | % |  |  |  |  |

[0001628280-16-015527:mdna:52]
[same as prior period, unchanged from 0001628280-16-010773:mdna:52]

[0001628280-16-015527:mdna:53]
Net revenue increased by $31.7 million, or 16.0%, during the three months ended April 2, 2016 compared to the same period a year ago. This increase was primarily due to an increase in net revenue from our OpComms segment.

[0001628280-16-015527:mdna:54]
OpComms net revenue increased $30.0 million, or 17.9%, during the three months ended April 2, 2016 compared to the same period a year ago. This increase was primarily driven by an increase in net revenue from our telecom products.

[0001628280-16-015527:mdna:55]
Lasers net revenue increased $1.7 million, or 5.4%, during the three months ended April 2, 2016 compared to the same period a year ago. This increase was primarily due to an increase in net revenue from our solid-state laser products.

[0001628280-16-015527:mdna:56]
Net revenue increased by $33.1 million, or 5.3%, during the nine months ended April 2, 2016 compared to the same period a year ago. This increase was primarily due to an increase in net revenue from our OpComms segment, partially offset by a decrease in net revenue from our Lasers segment.

[0001628280-16-015527:mdna:57]
OpComms net revenue increased $44.9 million, or 8.7%, during the nine months ended April 2, 2016 compared to the same period a year ago. This increase was driven by an increase in net revenue from our telecom and datacom products.

[0001628280-16-015527:mdna:58]
Lasers net revenue decreased $11.8 million, or 10.4%, during the nine months ended April 2, 2016 compared to the same period a year ago. This decrease was primarily due to lower market demand and component quality issues for solid-state and fiber laser products.

[0001628280-16-015527:mdna:59]
[same as prior period, unchanged from 0001628280-16-010773:mdna:59]

[0001628280-16-015527:mdna:60]
[same as prior period, unchanged from 0001628280-16-010773:mdna:60]

[0001628280-16-015527:mdna:61]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 2, 2016 |  | March 28, 2015 |  | April 2, 2016 |  | March 28, 2015 |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States | $ | 28.8 |  |  | 12.5 | % |  | $ | 42.2 |  |  | 21.2 | % |  | $ | 91.3 |  |  | 13.8 | % |  | $ | 125.7 |  |  | 20.0 | % |
| Mexico | 34.4 |  |  | 14.9 |  |  | 30.9 |  |  | 15.6 |  |  | 112.7 |  |  | 17.0 |  |  | 81.0 |  |  | 12.9 |  |
| Other Americas | 5.1 |  |  | 2.2 |  |  | 9.1 |  |  | 4.6 |  |  | 17.9 |  |  | 2.7 |  |  | 22.9 |  |  | 3.6 |  |
| Total Americas | $ | 68.3 |  |  | 29.6 | % |  | $ | 82.2 |  |  | 41.4 | % |  | $ | 221.9 |  |  | 33.5 | % |  | $ | 229.6 |  |  | 36.5 | % |
| Asia-Pacific: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Hong Kong | $ | 67.9 |  |  | 29.5 | % |  | $ | 24.3 |  |  | 12.2 | % |  | $ | 150.5 |  |  | 22.7 | % |  | $ | 87.0 |  |  | 13.9 | % |
| Japan | 19.8 |  |  | 8.6 |  |  | 12.9 |  |  | 6.5 |  |  | 65.8 |  |  | 10.0 |  |  | 83.7 |  |  | 13.3 |  |
| Thailand | 20.5 |  |  | 8.9 |  |  | 13.7 |  |  | 6.9 |  |  | 64.5 |  |  | 9.8 |  |  | 43.4 |  |  | 6.9 |  |
| Other Asia-Pacific | 27.0 |  |  | 11.7 |  |  | 36.1 |  |  | 18.2 |  |  | 69.3 |  |  | 10.5 |  |  | 86.1 |  |  | 13.7 |  |
| Total Asia-Pacific | $ | 135.2 |  |  | 58.7 | % |  | $ | 87.0 |  |  | 43.8 | % |  | $ | 350.1 |  |  | 53.0 | % |  | $ | 300.2 |  |  | 47.8 | % |
| EMEA | $ | 26.9 |  |  | 11.7 | % |  | $ | 29.5 |  |  | 14.8 | % |  | $ | 89.3 |  |  | 13.5 | % |  | $ | 98.4 |  |  | 15.7 | % |
| Total net revenue | $ | 230.4 |  |  |  |  | $ | 198.7 |  |  |  |  | $ | 661.3 |  |  |  |  | $ | 628.2 |  |  |  |

[0001628280-16-015527:mdna:62]
Net revenue from customers outside the United States, based on customer shipping location, during the three months ended  April 2, 2016 and March 28, 2015, represented 87.5% and 78.8% of net revenue, respectively. Net revenue from customers outside the United States, based on customer shipping location, during the nine months ended April 2, 2016 and March 28, 2015, represented 86.2% and 80.0% of net revenue, respectively. Our net revenue is primarily denominated in U.S. dollars, including our net revenue from customers outside the United States as presented above. We expect revenue from customers outside of the United States to continue to be an important part of our overall net revenue and an increasing focus for net revenue growth opportunities.

[0001628280-16-015527:mdna:63]
[same as prior period, unchanged from 0001628280-16-010773:mdna:63]

[0001628280-16-015527:mdna:64]
The following table summarizes segment gross margin and combined gross margin for the three and nine months ended April 2, 2016 and March 28, 2015 (in millions, except for percentages):

[0001628280-16-015527:mdna:65]
|  | Gross Profit |  | Gross Margin |  | Gross Profit |  | Gross Margin |
|  | Three Months Ended |  | Three Months Ended |  | Nine Months Ended |  | Nine Months Ended |
|  | April 2, 2016 |  | March 28, 2015 |  | April 2, 2016 |  | March 28, 2015 |  | April 2, 2016 |  | March 28, 2015 |  | April 2, 2016 |  | March 28, 2015 |
| OpComms | $ | 58.7 |  |  | $ | 47.1 |  |  | 29.8 | % |  | 28.2 | % |  | $ | 171.4 |  |  | $ | 150.3 |  |  | 30.6 | % |  | 29.2 | % |
| Lasers | 15.5 |  |  | 13.6 |  |  | 46.7 | % |  | 43.2 | % |  | 43.9 |  |  | 55.0 |  |  | 43.4 | % |  | 48.7 | % |
| Segment total | $ | 74.2 |  |  | $ | 60.7 |  |  | 32.2 | % |  | 30.5 | % |  | $ | 215.3 |  |  | $ | 205.3 |  |  | 32.6 | % |  | 32.7 | % |
| Unallocated corporate items (1) | (11.4 | ) |  | (3.6 | ) |  |  |  |  |  | (17.5 | ) |  | (11.0 | ) |  |  |  |  |
| Total | $ | 62.8 |  |  | $ | 57.1 |  |  | 27.3 | % |  | 28.7 | % |  | $ | 197.8 |  |  | $ | 194.3 |  |  | 29.9 | % |  | 30.9 | % |

[0001628280-16-015527:mdna:66]
| (1) | The unallocated corporate items for the periods presented include the effects of amortization of acquired developed technology, intangible assets, share-based compensation and certain other charges related to non-recurring activities. We do not allocate these items to the gross margin for each segment because management does not include such information in measuring the performance of the operating segments. |

[0001628280-16-015527:mdna:67]
[same as prior period, unchanged from 0001628280-16-010773:mdna:67]

[0001628280-16-015527:mdna:68]
Gross margin decreased 1.4 percentage points from 28.7% in the same period a year ago to 27.3% in the three months ended April 2, 2016. This decrease was primarily due to an inventory write-off related to our 3-D sensing product, partially offset by

[0001628280-16-015527:mdna:69]
28

[0001628280-16-015527:mdna:70]
increases in OpComms and Lasers gross margins.

[0001628280-16-015527:mdna:71]
Gross margin decreased 1.0 percentage points from 30.9% in the same period a year ago to 29.9% in the nine months ended April 2, 2016. This decrease was primarily due to lower Lasers gross margins, partially offset by an increase in OpComms gross margins.

[0001628280-16-015527:mdna:72]
[same as prior period, unchanged from 0001628280-16-010773:mdna:72]

[0001628280-16-015527:mdna:73]
[same as prior period, unchanged from 0001628280-16-010773:mdna:73]

[0001628280-16-015527:mdna:74]
[same as prior period, unchanged from 0001628280-16-010773:mdna:74]

[0001628280-16-015527:mdna:75]
OpComms gross margin increased 1.6 percentage points to 29.8% in the three months ended April 2, 2016 from 28.2% in the same period a year ago. This increase was primarily due to higher revenue volume and cost reductions, partially offset by an inventory write-off related to our 3-D sensing product.

[0001628280-16-015527:mdna:76]
OpComms gross margin increased 1.4 percentage points to 30.6% in the nine months ended April 2, 2016 from 29.2% in the same period a year ago. This increase was primarily due to higher revenue volume and cost reductions.

[0001628280-16-015527:mdna:77]
[same as prior period, unchanged from 0001628280-16-010773:mdna:77]

[0001628280-16-015527:mdna:78]
Lasers gross margin increased 3.5 percentage points to 46.7% in the three months ended April 2, 2016 from 43.2% in the same period a year ago. This increase was primarily due to higher revenue volume and product mix.

[0001628280-16-015527:mdna:79]
Lasers gross margin decreased 5.3 percentage points to 43.4% in the nine months ended April 2, 2016 from 48.7% in the same period a year ago. This decrease was primarily due to lower revenue volume and product mix.

[0001628280-16-015527:mdna:80]
[same as prior period, unchanged from 0001628280-16-010773:mdna:80]

[0001628280-16-015527:mdna:81]
R&D expense increased $0.3 million, or 0.9%, for the three months ended April 2, 2016 compared to the same period a year ago. The increase was primarily due to higher spending on materials to support ongoing R&D efforts and labor and benefits expenses for one additional week in the three months ended April 2, 2016. This was partially offset by higher R&D credits.

[0001628280-16-015527:mdna:82]
R&D expense decreased $0.4 million, or 0.4%, for the nine months ended April 2, 2016 compared to the same period a year ago. The decrease was primarily due to higher R&D credits and a decrease in employee-related costs resulting from the lower headcount from the closure of the Serangoon office in Singapore and a reduction of employees in North America. This was partially offset by labor and benefits expenses for one additional week in the three months ended April 2, 2016.

[0001628280-16-015527:mdna:83]
[same as prior period, unchanged from 0001628280-16-010773:mdna:83]

[0001628280-16-015527:mdna:84]
[same as prior period, unchanged from 0001628280-16-010773:mdna:84]

[0001628280-16-015527:mdna:85]
SG&A expense decreased by $3.8 million, or 11.9%, in the three months ended April 2, 2016 compared to the same period a year ago. This decrease was primarily driven by lower stand-alone SG&A costs during the three months ended April 2, 2016 compared to higher SG&A allocation from Viavi for the three months ended March 28, 2015. This was partially offset by higher labor and benefits expenses for one additional week in the three months ended April 2, 2016.

[0001628280-16-015527:mdna:86]
SG&A expense decreased by $3.5 million, or 3.8%, in the nine months ended April 2, 2016 compared to the same period  a year ago. This decrease was primarily driven by lower stand-alone SG&A expense during the nine months ended April 2, 2016 compared to higher SG&A allocation from Viavi for the nine months ended March 28, 2015. This was partially offset by higher labor and benefits expenses for one additional week in the nine months ended April 2, 2016.

[0001628280-16-015527:mdna:87]
We intend to continue to focus on reducing our SG&A expenses as a percentage of net revenue. However, we may incur additional SG&A expenses in the future, including to support additional SEC reporting requirements that we will become subject to when we no longer qualify as an "emerging growth company" as defined in the JOBS Act, as well as certain non-core expenses, such as mergers and acquisitions-related expenses and litigation expenses, which could increase our SG&A expenses and potentially impact our profitability expectations in any particular quarter.

[0001628280-16-015527:mdna:88]
[same as prior period, unchanged from 0001628280-16-010773:mdna:88]

[0001628280-16-015527:mdna:89]
[same as prior period, unchanged from 0001628280-16-010773:mdna:89]

[0001628280-16-015527:mdna:90]
As of April 2, 2016, our total restructuring accrual was $3.8 million. During the three and nine months ended April 2, 2016, we recorded $1.8 million and $3.9 million, respectively, in restructuring charges. These charges are primarily due to a previously announced restructuring plan for our Bloomfield, Connecticut site for severance and benefits. Refer to “Note 10. Restructuring and Related Charges” to the consolidated financial statements included in this Form 10-Q for more information.

[0001628280-16-015527:mdna:91]
During the three and nine months ended March 28, 2015, we recorded $1.1 million and $6.7 million, respectively, in restructuring and related charges. The charges are primarily due to the allocated costs of restructuring and other charges related to Viavi's corporate and shared services employees and the severance and benefit costs for Robbinsville Closure Plan approved in the first quarter of fiscal 2015.

[0001628280-16-015527:mdna:92]
Our Ottawa lease obligation is net of sublease income of approximately $0.7 million. Our ability to generate sublease income, as well as our ability to terminate lease obligations and recognize the anticipated related savings, is highly dependent upon economic conditions, particularly commercial real estate market conditions in certain geographies, at the time we negotiate the lease termination and sublease arrangements with third parties, as well as the performances by such third parties of their respective obligations. While the amount we have accrued represents the best estimate of the remaining obligations we expect to incur in connection with these plans, estimates are subject to change. Routine adjustments may be required in the future as conditions and facts change through the implementation period. If macroeconomic conditions decline, particularly as they pertain to the commercial real estate market, or if, for any reason, tenants under subleases fail to perform their obligations, we may be required to reduce estimated future sublease income and adjust the estimated amounts of future settlement agreements, and accordingly, increase estimated costs to exit certain facilities. Amounts related to the lease expense, net of anticipated sublease proceeds, will be paid over the respective lease terms through the third quarter of fiscal 2018.

[0001628280-16-015527:mdna:93]
[same as prior period, unchanged from 0001628280-16-010773:mdna:93]

[0001628280-16-015527:mdna:94]
The Series A Preferred Stock includes a conversion feature that was bifurcated and separately accounted for as a derivative liability measured at fair value upon inception with subsequent changes in fair value recognized in earnings. The proceeds from issuance was allocated first to the separated conversion feature based on its fair value, with the residual proceeds allocated to the Series A Preferred Stock. The unrealized loss on derivative liability relates to the subsequent changes in the fair value of the derivative liability. During the three and nine months ended April 2, 2016, the unrealized loss was $4.8 million and $5.0 million, respectively, and is reflected in our consolidated statements of operations.

[0001628280-16-015527:mdna:95]
[same as prior period, unchanged from 0001628280-16-010773:mdna:95]

[0001628280-16-015527:mdna:96]
[same as prior period, unchanged from 0001628280-16-010773:mdna:96]

[0001628280-16-015527:mdna:97]
Interest and other income (expense), net was $(0.4) million during each of the three months ended April 2, 2016 and March 28, 2015.

[0001628280-16-015527:mdna:98]
Interest and other income (expense), net was $(1.1) million during the nine months ended April 2, 2016 as compared to $(0.8) million during the same period a year ago.

[0001628280-16-015527:mdna:99]
[same as prior period, unchanged from 0001628280-16-010773:mdna:99]

[0001628280-16-015527:mdna:100]
We recorded a tax provision of $0.1 million and $0.3 million for the three and nine months ended April 2, 2016, respectively. We recorded a tax benefit of $23.4 million and $22.0 million for the three and nine months ended March 28, 2015.  The quarterly provision for income taxes is based on the estimated annual effective tax rate, plus any discrete items for the respective year. During the nine months ended April 2, 2016, we recognized a net benefit of $0.3 million related to deferred tax adjustments related to our operations in foreign jurisdictions.

[0001628280-16-015527:mdna:101]
[same as prior period, unchanged from 0001628280-16-010773:mdna:101]

[0001628280-16-015527:mdna:102]
[same as prior period, unchanged from 0001628280-16-010773:mdna:102]

[0001628280-16-015527:mdna:103]
The following table summarizes our contractual obligations at April 2, 2016, and the effect such obligations are expected to have on our liquidity and cash flow over the next five years (in millions):

[0001628280-16-015527:mdna:104]
|  | Payments due by period |
|  | Total |  | Less than 1 year |  | 1 - 3 years |  | 3 - 5 years |  | More than 5 years |
| Contractual Obligations |  |  |  |  |  |  |  |  |  |
| Asset retirement obligations—expected cash payments | $ | 2.3 |  |  | $ | — |  |  | $ | 0.6 |  |  | $ | 0.5 |  |  | $ | 1.2 |  |
| Purchase obligations (1) | 164.4 |  |  | 139.2 |  |  | 24.1 |  |  | 1.1 |  |  | — |  |
| Operating lease obligations (1) | 26.5 |  |  | 1.7 |  |  | 12.4 |  |  | 6.7 |  |  | 5.7 |  |
| Pension and post-retirement benefit payments | 2.3 |  |  | — |  |  | 0.1 |  |  | 0.1 |  |  | 2.1 |  |
| Total | $ | 195.5 |  |  | $ | 140.9 |  |  | $ | 37.2 |  |  | $ | 8.4 |  |  | $ | 9.0 |  |

[0001628280-16-015527:mdna:105]
(1) Refer to “Note 13. Commitments and Contingencies” to the consolidated financial statements included in this Form 10-Q for more information.

[0001628280-16-015527:mdna:106]
As of April 2, 2016, other current liabilities and other non-current liabilities on the consolidated balance sheets includes $0.4 million and $0.3 million, respectively, for restructuring and related activities in connection with our operating lease obligations disclosed above.

[0001628280-16-015527:mdna:107]
Purchase obligations represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Of the $164.4 million of purchase obligations as of April 2, 2016, $81.6 million are related to inventory and the other $82.8 million are non-inventory items of which $2.0 million is committed to Viavi.

[0001628280-16-015527:mdna:108]
As of April 2, 2016, our other non-current liabilities primarily relate to asset retirement obligations and pension which are presented in various lines in the preceding table.

[0001628280-16-015527:mdna:109]
[same as prior period, unchanged from 0001628280-16-010773:mdna:109]

[0001628280-16-015527:mdna:110]
[same as prior period, unchanged from 0001628280-16-010773:mdna:110]

[0001628280-16-015527:mdna:111]
[same as prior period, unchanged from 0001628280-16-010773:mdna:111]

[0001628280-16-015527:mdna:112]
[same as prior period, unchanged from 0001628280-16-010773:mdna:112]

[0001628280-16-015527:mdna:113]
As of April 2, 2016 and June 27, 2015, our cash and cash equivalents of $157.2 million and $14.5 million, respectively, were held predominantly in the United States, Cayman Islands, Canada, China and Japan. Although the cash generated in the United States from future operations is expected to cover our normal operating requirements, a substantial amount of additional cash could be required for other purposes, such as dividends that may be declared, future stock repurchase programs or acquisitions. Our intent is to indefinitely reinvest these funds outside the United States and our current plans do not demonstrate a need to repatriate them to fund our domestic operations. However, if in the future, we encounter a significant need for liquidity domestically or at a particular location that we cannot fulfill through borrowings, equity offerings, or other internal or external sources, we may determine that cash repatriations are necessary. Repatriation could result in additional material U.S. federal and state income tax payments in future years. Such adverse consequences would occur, for example, if the transfer of cash into the United States is taxed and no foreign tax credit is available to offset the U.S. tax liability, resulting in higher taxes. These factors may cause us to have an overall tax rate higher than other companies or higher than our tax rates have been in the past.

[0001628280-16-015527:mdna:114]
As of April 2, 2016, our consolidated balance of cash and cash equivalents increased by $142.7 million, to $157.2 million from $14.5 million as of June 27, 2015. The increase in cash and cash equivalents was a result of the initial capitalization from Viavi and cash generated from operations.

[0001628280-16-015527:mdna:115]
[same as prior period, unchanged from 0001628280-16-010773:mdna:115]

[0001628280-16-015527:mdna:116]
Cash provided by operating activities was $73.5 million during the nine months ended April 2, 2016, primarily resulting from $5.0 million of net loss and $66.6 million of non-cash items such as depreciation, stock-based compensation, amortization of acquired technologies and other intangibles, and unrealized loss on derivative liability, and changes in operating assets and liabilities of $11.9 million. Changes in our operating assets and liabilities related primarily to an increase in accounts payable of $32.7 million, an increase in accrued payroll and related expenses of $9.7 million, an increase  in accrued expenses and other current and non-current liabilities of $3.5 million, an increase in accounts receivable of $11.6 million, an increase in inventories of $9.6 million, and an increase in other current and non-current assets of $11.0 million.

[0001628280-16-015527:mdna:117]
Cash used in operating activities was $3.7 million during the nine months ended March 28, 2015, primarily resulting from $12.4 million of net income and $51.1 million of non-cash items such as depreciation, stock-based compensation, and amortization of acquired technologies and other intangibles, offset by changes in operating assets and liabilities of $67.2 million. Changes in our operating assets and liabilities related primarily to an increase in accounts receivable of $22.8 million, a decrease in accrued expenses and other current and non-current liabilities of $15.7 million, a decrease in income tax payable of $12.9 million, an increase in other current and non-currents assets of $11.4 million, a decrease in accrued payroll and related expenses of $4.7 million and an increase in inventories of $3.2 million, partially offset by an increase in deferred taxes of $4.0 million.

[0001628280-16-015527:mdna:118]
[same as prior period, unchanged from 0001628280-16-010773:mdna:118]

[0001628280-16-015527:mdna:119]
Cash used in investing activities was primarily for capital expenditures of $63.4 million and $35.3 million during the nine months ended April 2, 2016 and March 28, 2015, respectively.

[0001628280-16-015527:mdna:120]
[same as prior period, unchanged from 0001628280-16-010773:mdna:120]

[0001628280-16-015527:mdna:121]
Cash provided by financing activities was $131.4 million during the nine months ended April 2, 2016 resulting primarily from net transfers from Viavi.

[0001628280-16-015527:mdna:122]
Cash provided by financing activities was $31.8 million during the nine months ended March 28, 2015 resulting primarily from net transfers from Viavi.

[0001628280-16-015527:mdna:123]
[same as prior period, unchanged from 0001628280-16-010773:mdna:123]

[0001628280-16-015527:mdna:124]
We believe that the cash on hand of $157.2 million as of April 2, 2016, combined with expected cash flows from our operating activities, will be sufficient to meet our liquidity and capital spending requirements for at least the next 12 months. However, there are a number of factors that could positively or negatively impact our liquidity position, including:

[0001628280-16-015527:mdna:125]
[same as prior period, unchanged from 0001628280-16-010773:mdna:125]

[0001628280-16-015527:mdna:126]
[same as prior period, unchanged from 0001628280-16-010773:mdna:126]

[0001628280-16-015527:mdna:127]
[same as prior period, unchanged from 0001628280-16-010773:mdna:127]

[0001628280-16-015527:mdna:128]
[same as prior period, unchanged from 0001628280-16-010773:mdna:128]

[0001628280-16-015527:mdna:129]
[same as prior period, unchanged from 0001628280-16-010773:mdna:129]

[0001628280-16-015527:mdna:130]
[same as prior period, unchanged from 0001628280-16-010773:mdna:130]

[0001628280-16-015527:mdna:131]
| • | volatility in capital markets, fixed income and credit which impact the liquidity and valuation of our investment portfolios; |

[0001628280-16-015527:mdna:132]
[same as prior period, unchanged from 0001628280-16-010773:mdna:132]

[0001628280-16-015527:mdna:133]
[same as prior period, unchanged from 0001628280-16-010773:mdna:133]

[0001628280-16-015527:mdna:134]
[same as prior period, unchanged from 0001628280-16-010773:mdna:134]

[0001628280-16-015527:mdna:135]
[same as prior period, unchanged from 0001628280-16-010773:mdna:135]
