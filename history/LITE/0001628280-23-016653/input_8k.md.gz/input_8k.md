# LITE 8-K — 0001628280-23-016629 filed 2023-05-09

## item codes, every 8-K on or before 2023-05-09

- 2023-05-09 0001628280-23-016629 — 2.02, 9.01
- 2023-04-06 0001628280-23-010935 — 2.02, 8.01, 9.01
- 2023-02-24 0001193125-23-048742 — 5.02, 9.01
- 2023-02-09 0001628280-23-002866 — 2.02, 9.01
- 2022-11-21 0001628280-22-030473 — 5.02, 5.07, 9.01
- 2022-11-08 0001628280-22-028758 — 2.02, 9.01
- 2022-08-16 0001628280-22-022980 — 2.02, 9.01
- 2022-08-03 0001193125-22-210674 — 2.01, 8.01, 9.01
- 2022-07-29 0001193125-22-206587 — 8.01, 9.01
- 2022-05-04 0001628280-22-012145 — 2.02, 9.01
- 2022-03-08 0001193125-22-069350 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2022-02-03 0001628280-22-001736 — 2.02, 9.01
- 2022-01-21 0001193125-22-014413 — 8.01, 9.01
- 2021-11-23 0001628280-21-024070 — 5.02, 5.07
- 2021-11-05 0001193125-21-321796 — 1.01, 9.01
- 2021-11-04 0001628280-21-021618 — 2.02, 9.01
- 2021-11-04 0001193125-21-319601 — 8.01, 9.01
- 2021-08-18 0001628280-21-017219 — 2.02, 9.01
- 2021-06-08 0001633978-21-000030 — 5.02, 9.01
- 2021-05-12 0001633978-21-000008 — 2.02, 9.01
- 2021-03-10 0001193125-21-075438 — 1.01, 8.01, 9.01
- 2021-02-02 0001633978-21-000002 — 2.02, 9.01
- 2021-01-19 0001104659-21-005024 — 1.01, 2.02, 8.01, 9.01
- 2020-11-24 0001193125-20-302557 — 5.02, 5.07
- 2020-11-02 0001633978-20-000017 — 2.02, 9.01
- 2020-09-18 0001633978-20-000012 — 5.02, 9.01
- 2020-08-11 0001633978-20-000010 — 2.02, 9.01
- 2020-05-05 0001628280-20-006358 — 2.02, 9.01
- 2020-02-04 0001633978-20-000002 — 2.02, 9.01
- 2019-12-12 0001193125-19-312875 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2019-12-04 0001633978-19-000075 — 8.01
- 2019-11-20 0001633978-19-000074 — 5.07
- 2019-10-31 0001633978-19-000070 — 2.02, 9.01
- 2019-08-08 0001633978-19-000068 — 2.02, 9.01
- 2019-05-08 0001633978-19-000031 — 1.01
- 2019-05-07 0001633978-19-000029 — 2.02, 9.01
- 2019-02-15 0001633978-19-000005 — 9.01 — amendment of 0001193125-18-346211
- 2019-02-08 0001193125-19-031591 — 5.02, 9.01
- 2019-02-05 0001633978-19-000001 — 2.02, 9.01
- 2018-12-10 0001193125-18-346211 — 1.01, 2.01, 2.03, 5.02, 8.01, 9.01
- 2018-12-06 0001633978-18-000150 — 8.01
- 2018-11-14 0001633978-18-000139 — 5.07
- 2018-11-13 0001633978-18-000136 — 3.02
- 2018-11-13 0001633978-18-000132 — 7.01, 9.01
- 2018-11-01 0001628280-18-013238 — 2.02, 9.01
- 2018-08-08 0001633978-18-000056 — 2.02, 9.01
- 2018-06-08 0001193125-18-188241 — 5.02, 9.01
- 2018-05-02 0001633978-18-000029 — 2.02, 9.01
- 2018-03-12 0001193125-18-078154 — 1.01, 2.01, 8.01, 9.01
- 2018-02-06 0001628280-18-001082 — 2.02, 9.01
- 2017-11-08 0001633978-17-000133 — 5.02, 9.01
- 2017-11-07 0001633978-17-000131 — 5.07
- 2017-11-01 0001633978-17-000117 — 2.02, 9.01
- 2017-08-09 0001633978-17-000058 — 2.02, 9.01
- 2017-05-04 0001633978-17-000035 — 2.02, 9.01
- 2017-03-08 0001193125-17-074740 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2017-03-02 0001193125-17-066769 — 8.01, 9.01
- 2017-02-07 0001633978-17-000005 — 2.02, 9.01
- 2017-01-03 0001628280-17-000018 — 4.01, 9.01
- 2016-11-09 0001628280-16-021143 — 5.02, 5.07, 9.01
- 2016-10-27 0001628280-16-020382 — 2.02, 9.01
- 2016-08-09 0001628280-16-018811 — 2.02, 9.01
- 2016-06-21 0001628280-16-017201 — 8.01
- 2016-05-04 0001628280-16-015501 — 2.02, 9.01
- 2016-02-16 0001628280-16-011261 — 5.02, 9.01
- 2016-02-04 0001628280-16-010758 — 5.02, 9.01
- 2016-02-04 0001628280-16-010755 — 2.02, 9.01
- 2015-11-17 0001193125-15-378953 — 7.01
- 2015-11-10 0001628280-15-008606 — 2.02, 9.01
- 2015-09-28 0001193125-15-329665 — 8.01, 9.01
- 2015-08-11 0001193125-15-286405 — 7.01, 9.01
- 2015-08-06 0001193125-15-281219 — 1.01, 5.02, 5.03, 5.05, 8.01, 9.01
- 2015-08-03 0001193125-15-274808 — 5.03, 9.01

## late-filing notifications on or before 2023-05-09

- 2015-11-10 0001628280-15-008612 — NT 10-Q, for the period ended 2015-09-26
- 2015-09-28 0001193125-15-329672 — NT 10-K, for the period ended 2015-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001628280-23-016629:8k_2_02:1]
EX-99.1
2
lite_ex991xq3fy23.htm
EX-99.1

[0001628280-23-016629:8k_2_02:2]
Document

[0001628280-23-016629:8k_2_02:3]
NEWS RELEASE

[0001628280-23-016629:8k_2_02:4]
LUMENTUM ANNOUNCES FISCAL THIRD QUARTER 2023 FINANCIAL RESULTS

[0001628280-23-016629:8k_2_02:5]
•Net revenue of $383.4 million

[0001628280-23-016629:8k_2_02:6]
•GAAP gross margin of 29.2%; Non-GAAP gross margin of 40.8%

[0001628280-23-016629:8k_2_02:7]
•GAAP operating loss of 13.4%; Non-GAAP operating margin of 13.4%

[0001628280-23-016629:8k_2_02:8]
•GAAP diluted net loss per share of $0.57; Non-GAAP diluted net income per share of $0.75

[0001628280-23-016629:8k_2_02:9]
San Jose, Calif., May 9, 2023 – Lumentum Holdings Inc. (“Lumentum” or the “Company”) today reported results for its fiscal third quarter ended April 1, 2023.

[0001628280-23-016629:8k_2_02:10]
“Our third quarter results reflect the impact of customer inventory digestion, and we believe we are currently under-shipping end-market demand across our business,” said Alan Lowe, President and CEO. “I am confident about our overall competitiveness and market share positions in our optical communications and commercial lasers segments and believe that mid- to long-term demand drivers are very favorable. As we navigate current demand, we are prioritizing expense controls, accelerated attainment of acquisition synergies, and cash generation, while we continue to deliver on our new product and technology roadmaps and customer satisfaction.”

[0001628280-23-016629:8k_2_02:11]
Fiscal Third Quarter Highlights:

[0001628280-23-016629:8k_2_02:12]
Net revenue for the fiscal third quarter of 2023 was $383.4 million, with GAAP net loss of $39.3 million, or $0.57 loss per diluted share. Net revenue for the fiscal second quarter of 2023 was $506.0 million, with GAAP net loss of $31.7 million, or $0.46 loss per diluted share. Net revenue for the fiscal third quarter of 2022 was $395.4 million, with GAAP net income of $26.0 million, or $0.35 per diluted share.

[0001628280-23-016629:8k_2_02:13]
Non-GAAP net income for the fiscal third quarter of 2023 was $51.8 million, or $0.75 per diluted share. Non-GAAP net income for the fiscal second quarter of 2023 was $104.1 million, or $1.52 per diluted share. Non-GAAP net income for the fiscal third quarter of 2022 was $88.9 million, or $1.19 per diluted share.

[0001628280-23-016629:8k_2_02:14]
The Company held $1,667.2 million in total cash, cash equivalents, and short-term investments at the end of the fiscal third quarter of 2023, down $13.2 million from the end of the fiscal second quarter of 2023.

[0001628280-23-016629:8k_2_02:15]
Financial Overview – Fiscal Third Quarter Ended April 1, 2023

[0001628280-23-016629:8k_2_02:16]
|  | GAAP Results ($ in millions) |
|  | Q3 |  | Q2 |  | Q3 |  | Change |
|  | FY 2023 |  | FY 2023 |  | FY 2022 |  | Q/Q |  | Y/Y |
| Net revenue | $383.4 |  | $506.0 |  | $395.4 |  | (24.2)% |  | (3.0)% |
| Gross margin | 29.2% |  | 32.8% |  | 42.3% |  | (360)bps |  | (1,310)bps |
| Operating margin (loss) | (13.4)% |  | (4.3)% |  | 11.8% |  | (910)bps |  | (2,520)bps |
|  | Non-GAAP Results ($ in millions) |
|  | Q3 |  | Q2 |  | Q3 |  | Change |
|  | FY 2023 |  | FY 2023 |  | FY 2022 |  | Q/Q |  | Y/Y |
| Net revenue | $383.4 |  | $506.0 |  | $395.4 |  | (24.2)% |  | (3.0)% |
| Gross margin | 40.8% |  | 44.9% |  | 49.5% |  | (410)bps |  | (870)bps |
| Operating margin | 13.4% |  | 23.1% |  | 26.5% |  | (970)bps |  | (1,310)bps |

[0001628280-23-016629:8k_2_02:17]
|  | Net Revenue by Segment ($ in millions) |
|  | Q3 |  | % of |  | Q2 |  | Q3 |  | Change |
|  | FY 2023 |  | Net Revenue |  | FY 2023 |  | FY 2022 |  | Q/Q |  | Y/Y |
| Optical Communications | $ | 335.1 |  |  | 87.4 | % |  | $ | 448.8 |  |  | $ | 344.2 |  |  | (25.3) | % |  | (2.6) | % |
| Lasers | 48.3 |  |  | 12.6 | % |  | 57.2 |  |  | 51.2 |  |  | (15.6) | % |  | (5.7) | % |
| Total | $ | 383.4 |  |  | 100.0 | % |  | $ | 506.0 |  |  | $ | 395.4 |  |  | (24.2) | % |  | (3.0) | % |

[0001628280-23-016629:8k_2_02:18]
The tables above provide comparisons of quarterly results to prior periods, including sequential quarterly and year-over-year changes. A reconciliation between GAAP and non-GAAP measures is contained in this release under the section titled “Use of Non-GAAP Financial Measures.”

[0001628280-23-016629:8k_2_02:19]
Business Outlook

[0001628280-23-016629:8k_2_02:20]
Lumentum expects the following for the fiscal  fourth quarter 2023:

[0001628280-23-016629:8k_2_02:21]
•Net revenue in the range of $350 million to $380 million

[0001628280-23-016629:8k_2_02:22]
•Non-GAAP operating margin of 8.5% to 11.5%

[0001628280-23-016629:8k_2_02:23]
•Non-GAAP diluted earnings per share of $0.45 to $0.65

[0001628280-23-016629:8k_2_02:24]
We have not provided reconciliations from GAAP to non-GAAP measures for our outlook. A large portion of non-GAAP adjustments, such as restructuring charges, stock-based compensation, non-GAAP income tax reconciling adjustments, acquisition related costs, and other costs and contingencies unrelated to current and future operations are by their nature highly volatile and we have low visibility as to the range that may be incurred in the future.

[0001628280-23-016629:8k_2_02:25]
Related Announcement and Conference Call

[0001628280-23-016629:8k_2_02:26]
Lumentum will host a conference call today, May 9, 2023, at 5:30 am PT / 8:30 am ET to discuss its fiscal third quarter results.  A live webcast of the call and the replay will be available in the Investors section of the Lumentum website at http://investor.lumentum.com through May 16, 2023, at 9:00 pm PT / 12:00 am ET. To listen to the live conference call, dial (833) 470-1428 or (404) 975-4839 and reference the passcode 439858. To access the replay, dial (866) 813-9403 or (929) 458-6194 and reference the passcode 850715. Supporting materials outlining the Company’s latest financial results will be posted on http://investor.lumentum.com under the “Events and Presentations” section concurrently with this earnings press release. Lumentum has used, and intends to continue to use, its Investor Relations website as means of disclosing material nonpublic information and for complying with its disclosure obligations under Regulation FD. This press release is being furnished as an exhibit to a Current Report on Form 8-K filed with the Securities and Exchange Commission and will be available at http://www.sec.gov/.

[0001628280-23-016629:8k_2_02:27]
About Lumentum

[0001628280-23-016629:8k_2_02:28]
Lumentum (NASDAQ: LITE) is a market-leading designer and manufacturer of innovative optical and photonic products enabling optical networking and laser applications worldwide. Lumentum optical components and subsystems are part of virtually every type of telecom, enterprise, and data center network. Lumentum lasers enable advanced manufacturing techniques and diverse applications including next-generation imaging and sensing capabilities. Lumentum is headquartered in San Jose, California with R&D, manufacturing, and sales offices worldwide. For more information, visit www.lumentum.com and follow Lumentum on LinkedIn, Twitter, Facebook, Instagram and YouTube.

[0001628280-23-016629:8k_2_02:29]
Forward-Looking Statements

[0001628280-23-016629:8k_2_02:30]
measures due to the broad gross margin ranges across our portfolio; (c) decline of average selling prices across our businesses or increase in costs, either of which will also decrease our margins; (d) effects of seasonality; (e) the ability of our suppliers and contract manufacturers to meet production, quality, and delivery requirements for our forecasted demand and the effect of ongoing supply chain constraints, particularly in semiconductors; (f) changes in customer demand, including due to changes in inventory practices and end-customer demand; (g) our ability to attract and retain new customers, particularly in the imaging and sensing market; and (h) the risk that Lumentum’s financing or operating strategies will not be successful. For more information on these risks, please refer to the "Risk Factors" section included in the Company’s Quarterly Report on Form 10-Q for the quarter ended April 1, 2023 to be filed with the Securities and Exchange Commission.  In addition, the results contained in this presentation are valid only as of today’s date except where otherwise noted. The forward-looking statements contained in this presentation are made as of the date hereof and the Company assumes no obligation to update such statements, except as required by applicable law.

[0001628280-23-016629:8k_2_02:31]
Contact Information

[0001628280-23-016629:8k_2_02:32]
Investors:    Kathy Ta, (408) 750-3853; investor.relations@lumentum.com

[0001628280-23-016629:8k_2_02:33]
Media:        Caroline Pan, (650) 267-4180; media@lumentum.com

[0001628280-23-016629:8k_2_02:34]
Category:    Financial

[0001628280-23-016629:8k_2_02:35]
The following financial tables are presented in accordance with GAAP, unless otherwise specified.

[0001628280-23-016629:8k_2_02:36]
LUMENTUM HOLDINGS INC.

[0001628280-23-016629:8k_2_02:37]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001628280-23-016629:8k_2_02:38]
(in millions, except per share data)

[0001628280-23-016629:8k_2_02:39]
(unaudited)

[0001628280-23-016629:8k_2_02:40]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 1, 2023 |  | April 2, 2022 |  | April 1, 2023 |  | April 2, 2022 |
| Net revenue | $ | 383.4 |  |  | $ | 395.4 |  |  | $ | 1,396.2 |  |  | $ | 1,290.5 |  |
| Cost of sales | 252.7 |  |  | 212.6 |  |  | 850.4 |  |  | 636.3 |  |
| Amortization of acquired developed intangibles | 18.7 |  |  | 15.6 |  |  | 66.4 |  |  | 47.3 |  |
| Gross profit | 112.0 |  |  | 167.2 |  |  | 479.4 |  |  | 606.9 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 85.4 |  |  | 56.7 |  |  | 233.9 |  |  | 164.0 |  |
| Selling, general and administrative | 76.4 |  |  | 63.8 |  |  | 280.5 |  |  | 196.1 |  |
| Restructuring and related charges | 1.6 |  |  | (0.1) |  |  | 24.8 |  |  | (1.1) |  |
| Total operating expenses | 163.4 |  |  | 120.4 |  |  | 539.2 |  |  | 359.0 |  |
| Income (loss) from operations | (51.4) |  |  | 46.8 |  |  | (59.8) |  |  | 247.9 |  |
| Interest expense | (8.7) |  |  | (19.7) |  |  | (26.1) |  |  | (53.7) |  |
| Other income, net | 11.4 |  |  | 2.2 |  |  | 28.9 |  |  | 3.8 |  |
| Income (loss) before income taxes | (48.7) |  |  | 29.3 |  |  | (57.0) |  |  | 198.0 |  |
| Income tax provision (benefit) | (9.4) |  |  | 3.3 |  |  | 14.4 |  |  | 33.8 |  |
| Net income (loss) | $ | (39.3) |  |  | $ | 26.0 |  |  | $ | (71.4) |  |  | $ | 164.2 |  |
| Net income (loss) per share: |  |  |  |  |  |  |  |
| Basic | $ | (0.57) |  |  | $ | 0.37 |  |  | $ | (1.05) |  |  | $ | 2.28 |  |
| Diluted | $ | (0.57) |  |  | $ | 0.35 |  |  | $ | (1.05) |  |  | $ | 2.19 |  |
| Shares used to compute net income (loss) per share: |  |  |  |  |  |  |  |
| Basic | 68.6 |  |  | 71.0 |  |  | 68.3 |  |  | 72.0 |  |
| Diluted | 68.6 |  |  | 74.5 |  |  | 68.3 |  |  | 75.1 |  |

[0001628280-23-016629:8k_2_02:41]
LUMENTUM HOLDINGS INC.

[0001628280-23-016629:8k_2_02:42]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001628280-23-016629:8k_2_02:43]
(in millions, except per share data)

[0001628280-23-016629:8k_2_02:44]
(unaudited)

[0001628280-23-016629:8k_2_02:45]
|  | April 1, 2023 |  | July 2, 2022 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 549.2 |  |  | $ | 1,290.2 |  |
| Short-term investments | 1,118.0 |  |  | 1,258.8 |  |
| Accounts receivable, net | 278.0 |  |  | 262.0 |  |
| Inventories | 410.2 |  |  | 250.1 |  |
| Prepayments and other current assets | 108.2 |  |  | 78.1 |  |
| Total current assets | 2,463.6 |  |  | 3,139.2 |  |
| Property, plant and equipment, net | 482.9 |  |  | 360.5 |  |
| Operating lease right-of-use assets, net | 81.5 |  |  | 73.6 |  |
| Goodwill | 696.2 |  |  | 368.9 |  |
| Other intangible assets, net | 498.4 |  |  | 155.7 |  |
| Deferred tax asset | 116.2 |  |  | 27.0 |  |
| Other non-current assets | 15.2 |  |  | 37.3 |  |
| Total assets | $ | 4,354.0 |  |  | $ | 4,162.2 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 198.7 |  |  | $ | 156.7 |  |
| Accrued payroll and related expenses | 41.1 |  |  | 54.6 |  |
| Accrued expenses | 59.5 |  |  | 44.7 |  |
| Short-term debt | 426.2 |  |  | 409.9 |  |
| Operating lease liabilities, current | 14.4 |  |  | 11.2 |  |
| Other current liabilities | 29.0 |  |  | 39.4 |  |
| Total current liabilities | 768.9 |  |  | 716.5 |  |
| Long-term debt | 1,900.8 |  |  | 1,466.1 |  |
| Operating lease liabilities, non-current | 53.1 |  |  | 48.8 |  |
| Deferred tax liability | 17.5 |  |  | 12.9 |  |
| Other non-current liabilities | 75.7 |  |  | 42.9 |  |
| Total liabilities | 2,816.0 |  |  | 2,287.2 |  |
| Stockholders’ equity: |  |  |  |
| Common stock, $0.001 par value, 990 authorized shares, 68.7 and 68.0 shares issued and outstanding as of April 1, 2023 and July 2, 2022, respectively | 0.1 |  |  | 0.1 |  |
| Additional paid-in capital | 1,671.4 |  |  | 2,003.6 |  |
| Accumulated deficit | (140.6) |  |  | (129.1) |  |
| Accumulated other comprehensive income | 7.1 |  |  | 0.4 |  |
| Total stockholders’ equity | 1,538.0 |  |  | 1,875.0 |  |
| Total liabilities and stockholders’ equity | $ | 4,354.0 |  |  | $ | 4,162.2 |  |

[0001628280-23-016629:8k_2_02:46]
Use of Non-GAAP Financial Measures

[0001628280-23-016629:8k_2_02:47]
In this press release, Lumentum provides investors with certain non-GAAP financial measures: gross profit, gross margin, research and development expense, selling, general and administrative expense, operating margin, income from operations, interest and other income (expense), net, income before income taxes, provision for income taxes, net income (loss), and net income (loss) per share on a non-GAAP basis, as well as the non-GAAP measures of EBITDA and Adjusted EBITDA. Lumentum believes this non-GAAP financial information provides additional insight into the Company’s ongoing business operations and results, as well as cash generation, and has therefore chosen to provide this information to investors for a more consistent basis of comparison and to help them evaluate the results of the Company’s ongoing operations and enable more meaningful period to period comparisons. In addition, the Company believes that providing certain of these measures allows investors to better understand the Company’s operating performance and cash flows and, importantly, to evaluate the methodology and information used by management to monitor, manage, evaluate and measure the Company’s business, results of operations, and cash flows. However, these measures may be different from non-GAAP measures used by other companies, limiting their usefulness for comparison purposes. The non-GAAP financial measures used in this press release should not be considered in isolation from measures of financial performance prepared in accordance with GAAP. Investors are cautioned that there are material limitations associated with the use of non-GAAP financial measures as an analytical tool. In particular, many of the adjustments to our GAAP financial measures reflect the exclusion of items that are recurring and will be reflected in our financial results for the foreseeable future. Further, these non-GAAP financial measures may not be comparable to similarly titled measurements reported by other companies.

[0001628280-23-016629:8k_2_02:48]
Our non-GAAP measures used in this press release exclude (i) stock-based compensation, (ii) acquisition related stock-based compensation, (iii) acquisition related costs, (iv) amortization of acquired intangibles, (v) amortization of acquired inventory fair value adjustments, (vi) restructuring and related charges, (vii) foreign exchange (gains) losses, net, (viii) non-cash interest expense on convertible notes, (ix) non-recurring expenses related to litigation matters, (x) intangible assets write-off, (xi) integration related costs, (xii) non-GAAP income tax reconciling adjustments, and (xiii) other (gains) charges related to non-recurring activities.

[0001628280-23-016629:8k_2_02:49]
A quantitative reconciliation between GAAP and non-GAAP financial data with respect to historical periods is included in the supplemental financial table attached to this press release.

[0001628280-23-016629:8k_2_02:50]
LUMENTUM HOLDINGS INC.

[0001628280-23-016629:8k_2_02:51]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001628280-23-016629:8k_2_02:52]
(in millions, except per share data)

[0001628280-23-016629:8k_2_02:53]
(unaudited)

[0001628280-23-016629:8k_2_02:54]
|  | Three Months Ended |  | Nine Months Ended |  |
|  | April 1, 2023 |  | December 31, 2022 |  | April 2, 2022 |  | April 1, 2023 |  | April 2, 2022 |  |
| Gross profit on GAAP basis | $ | 112.0 |  |  | $ | 166.2 |  |  | $ | 167.2 |  |  | $ | 479.4 |  |  | $ | 606.9 |  |  |
| Stock-based compensation | 6.9 |  |  | 6.7 |  |  | 5.4 |  |  | 19.1 |  |  | 15.2 |  |  |
| Amortization of acquired intangibles | 18.7 |  |  | 24.8 |  |  | 15.6 |  |  | 66.4 |  |  | 47.3 |  |  |
| Amortization of acquired inventory fair value adjustments | 3.6 |  |  | 9.6 |  |  | — |  |  | 17.8 |  |  | — |  |  |
| Integration related costs | 6.7 |  |  | 2.8 |  |  | — |  |  | 9.5 |  |  | — |  |  |
| Other (gains) charges, net (1) | 8.4 |  |  | 16.9 |  |  | 7.4 |  |  | 35.2 |  |  | 0.9 |  |  |
| Gross profit on non-GAAP basis | $ | 156.3 |  |  | $ | 227.0 |  |  | $ | 195.6 |  |  | $ | 627.4 |  |  | $ | 670.3 |  |  |
| Gross margin on non-GAAP basis | 40.8 | % |  | 44.9 | % |  | 49.5 | % |  | 44.9 | % |  | 51.9 | % |  |
| Research and development on GAAP basis | $ | 85.4 |  |  | $ | 75.8 |  |  | $ | 56.7 |  |  | $ | 233.9 |  |  | 164.0 |  |  |
| Stock-based compensation | (11.0) |  |  | (10.6) |  |  | (5.4) |  |  | (31.2) |  |  | (15.8) |  |  |
| Integration related costs | (0.5) |  |  | (0.8) |  |  | — |  |  | (1.3) |  |  | — |  |  |
| Write-off of in-process research and development intangible assets (2) | (11.5) |  |  | — |  |  | — |  |  | (11.5) |  |  | — |  |  |
| Other charges | (0.3) |  |  | — |  |  | (0.6) |  |  | (2.6) |  |  | (0.7) |  |  |
| Research and development on non-GAAP basis | $ | 62.1 |  |  | $ | 64.4 |  |  | $ | 50.7 |  |  | $ | 187.3 |  |  | $ | 147.5 |  |  |
| Selling, general and administrative on GAAP basis | $ | 76.4 |  |  | $ | 98.4 |  |  | $ | 63.8 |  |  | $ | 280.5 |  |  | $ | 196.1 |  |  |
| Stock-based compensation | (15.2) |  |  | (19.3) |  |  | (12.5) |  |  | (54.1) |  |  | (44.4) |  |  |
| Stock-based compensation - acquisition related (3) | — |  |  | — |  |  | — |  |  | (11.9) |  |  | — |  |  |
| Amortization of acquired intangibles | (11.3) |  |  | (11.3) |  |  | (5.8) |  |  | (31.9) |  |  | (17.0) |  |  |
| Acquisition related costs (4) | — |  |  | — |  |  | — |  |  | (16.2) |  |  | — |  |  |
| Integration related costs | (3.4) |  |  | (4.4) |  |  | — |  |  | (8.4) |  |  | — |  |  |
| Litigation matters (5) | — |  |  | (7.8) |  |  | — |  |  | (7.8) |  |  | — |  |  |
| Other charges, net | (3.7) |  |  | (9.7) |  |  | (5.5) |  |  | (15.6) |  |  | (17.3) |  |  |
| Selling, general and administrative on non-GAAP basis | $ | 42.8 |  |  | $ | 45.9 |  |  | $ | 40.0 |  |  | $ | 134.6 |  |  | $ | 117.4 |  |  |
| Income (Loss) from operations on GAAP basis | $ | (51.4) |  |  | $ | (21.9) |  |  | $ | 46.8 |  |  | $ | (59.8) |  |  | $ | 247.9 |  |  |
| Stock-based compensation | 33.1 |  |  | 36.6 |  |  | 23.3 |  |  | 104.4 |  |  | 75.4 |  |  |
| Stock-based compensation - acquisition related (3) | — |  |  | — |  |  | — |  |  | 11.9 |  |  | — |  |  |
| Amortization of acquired intangibles | 30.0 |  |  | 36.1 |  |  | 21.4 |  |  | 98.3 |  |  | 64.3 |  |  |
| Amortization of acquired inventory fair value adjustments | 3.6 |  |  | 9.6 |  |  | — |  |  | 17.8 |  |  | — |  |  |
| Acquisition related costs (4) | — |  |  | — |  |  | — |  |  | 16.2 |  |  | — |  |  |
| Integration related costs | 10.6 |  |  | 8.0 |  |  | — |  |  | 19.2 |  |  | — |  |  |
| Restructuring and related charges (6) | 1.6 |  |  | 13.9 |  |  | (0.1) |  |  | 24.8 |  |  | (1.1) |  |  |
| Write-off of in-process research and development intangible assets (2) | 11.5 |  |  | — |  |  | — |  |  | 11.5 |  |  | — |  |  |
| Litigation matters (5) | — |  |  | 7.8 |  |  | — |  |  | 7.8 |  |  | — |  |  |

[0001628280-23-016629:8k_2_02:55]
| Other charges, net | 12.4 |  |  | 26.6 |  |  | 13.5 |  |  | 53.4 |  |  | 18.9 |  |  |
| Income from operations on non-GAAP basis | $ | 51.4 |  |  | $ | 116.7 |  |  | $ | 104.9 |  |  | $ | 305.5 |  |  | $ | 405.4 |  |  |
| Operating margin on non-GAAP basis | 13.4 | % |  | 23.1 | % |  | 26.5 | % |  | 21.9 | % |  | 31.4 | % |  |
| Interest and other income (expense), net on GAAP basis | $ | 2.7 |  |  | $ | (5.2) |  |  | $ | (17.5) |  |  | $ | 2.8 |  |  | $ | (49.9) |  |  |
| Foreign exchange (gains) losses, net | 0.5 |  |  | 4.1 |  |  | (1.1) |  |  | (4.4) |  |  | (1.7) |  |  |
| Non-cash interest expense on convertible notes | 6.0 |  |  | 6.2 |  |  | 17.7 |  |  | 17.9 |  |  | 48.8 |  |  |
| Interest and other income (expense), net on non-GAAP basis | $ | 9.2 |  |  | $ | 5.1 |  |  | $ | (0.9) |  |  | $ | 16.3 |  |  | $ | (2.8) |  |  |
| Income (Loss) before income taxes on GAAP basis | $ | (48.7) |  |  | $ | (27.1) |  |  | $ | 29.3 |  |  | $ | (57.0) |  |  | $ | 198.0 |  |  |
| Stock-based compensation | 33.1 |  |  | 36.6 |  |  | 23.3 |  |  | 104.4 |  |  | 75.4 |  |  |
| Stock-based compensation - acquisition related (3) | — |  |  | — |  |  | — |  |  | 11.9 |  |  | — |  |  |
| Acquisition related costs (4) | — |  |  | — |  |  | — |  |  | 16.2 |  |  | — |  |  |
| Integration related costs | 10.6 |  |  | 8.0 |  |  | — |  |  | 19.2 |  |  | — |  |  |
| Amortization of acquired intangibles | 30.0 |  |  | 36.1 |  |  | 21.4 |  |  | 98.3 |  |  | 64.3 |  |  |
| Amortization of acquired inventory fair value adjustments | 3.6 |  |  | 9.6 |  |  | — |  |  | 17.8 |  |  | — |  |  |
| Restructuring and related charges (6) | 1.6 |  |  | 13.9 |  |  | (0.1) |  |  | 24.8 |  |  | (1.1) |  |  |
| Litigation matters (5) | — |  |  | 7.8 |  |  | — |  |  | 7.8 |  |  | — |  |  |
| Write-off of in-process research and development intangible assets (2) | 11.5 |  |  | — |  |  | — |  |  | 11.5 |  |  | — |  |  |
| Foreign exchange (gains) losses, net | 0.5 |  |  | 4.1 |  |  | (1.1) |  |  | (4.4) |  |  | (1.7) |  |  |
| Non-cash interest expense on convertible notes | 6.0 |  |  | 6.2 |  |  | 17.7 |  |  | 17.9 |  |  | 48.8 |  |  |
| Other charges, net | 12.4 |  |  | 26.6 |  |  | 13.5 |  |  | 53.4 |  |  | 18.9 |  |  |
| Income before income taxes on non-GAAP basis | $ | 60.6 |  |  | $ | 121.8 |  |  | $ | 104.0 |  |  | $ | 321.8 |  |  | $ | 402.6 |  |  |
| Income tax provision (benefit) on GAAP basis | $ | (9.4) |  |  | $ | 4.6 |  |  | $ | 3.3 |  |  | $ | 14.4 |  |  | $ | 33.8 |  |  |
| Non-GAAP income tax reconciling adjustments | 18.2 |  |  | 13.1 |  |  | 11.8 |  |  | 32.3 |  |  | 24.6 |  |  |
| Income tax provision on non-GAAP basis | $ | 8.8 |  |  | $ | 17.7 |  |  | $ | 15.1 |  |  | $ | 46.7 |  |  | $ | 58.4 |  |  |
| Net income (loss) on GAAP basis | $ | (39.3) |  |  | $ | (31.7) |  |  | $ | 26.0 |  |  | $ | (71.4) |  |  | $ | 164.2 |  |  |
| Stock-based compensation | 33.1 |  |  | 36.6 |  |  | 23.3 |  |  | 104.4 |  |  | 75.4 |  |  |
| Stock-based compensation - acquisition related (3) | — |  |  | — |  |  | — |  |  | 11.9 |  |  | — |  |  |
| Acquisition related costs (4) | — |  |  | — |  |  | — |  |  | 16.2 |  |  | — |  |  |
| Integration related costs | 10.6 |  |  | 8.0 |  |  | — |  |  | 19.2 |  |  | — |  |  |
| Amortization of acquired intangibles | 30.0 |  |  | 36.1 |  |  | 21.4 |  |  | 98.3 |  |  | 64.3 |  |  |
| Amortization of acquired inventory fair value adjustments | 3.6 |  |  | 9.6 |  |  | — |  |  | 17.8 |  |  | — |  |  |
| Restructuring and related charges (6) | 1.6 |  |  | 13.9 |  |  | (0.1) |  |  | 24.8 |  |  | (1.1) |  |  |
| Write-off of in-process research and development intangible assets (2) | 11.5 |  |  | — |  |  | — |  |  | 11.5 |  |  | — |  |  |
| Litigation matters (5) | — |  |  | 7.8 |  |  | — |  |  | 7.8 |  |  | — |  |  |
| Foreign exchange (gains) losses, net | 0.5 |  |  | 4.1 |  |  | (1.1) |  |  | (4.4) |  |  | (1.7) |  |  |
| Non-cash interest expense on convertible notes | 6.0 |  |  | 6.2 |  |  | 17.7 |  |  | 17.9 |  |  | 48.8 |  |  |
| Non-GAAP income tax reconciling adjustments | (18.2) |  |  | (13.1) |  |  | (11.8) |  |  | (32.3) |  |  | (24.6) |  |  |
| Other charges, net | 12.4 |  |  | 26.6 |  |  | 13.5 |  |  | 53.4 |  |  | 18.9 |  |  |

[0001628280-23-016629:8k_2_02:56]
| Net income on non-GAAP basis | $ | 51.8 |  |  | $ | 104.1 |  |  | $ | 88.9 |  |  | $ | 275.1 |  |  | $ | 344.2 |  |  |
| Net income per share on non-GAAP basis | $ | 0.75 |  |  | $ | 1.52 |  |  | $ | 1.19 |  |  | $ | 3.97 |  |  | $ | 4.58 |  |  |
| Shares used in per share calculation - diluted on GAAP basis | 68.6 |  |  | 68.3 |  |  | 74.5 |  |  | 68.3 |  |  | 75.1 |  |  |
| Non-GAAP adjustment (7) | 0.1 |  |  | 0.3 |  |  | — |  |  | 1.0 |  |  | — |  |  |
| Shares used in per share calculation - diluted on non-GAAP basis | 68.7 |  |  | 68.6 |  |  | 74.5 |  |  | 69.3 |  |  | 75.1 |  |  |

[0001628280-23-016629:8k_2_02:57]
(1) Other gains (charges) excluded in deriving non-GAAP gross profit for the three and nine months ended April 1, 2023 primarily relate to $8.0 million and $27.0 million, respectively, of incremental costs of sales related to components previously acquired from various brokers to satisfy customer demand.

[0001628280-23-016629:8k_2_02:58]
(2) During the three and nine months ended April 1, 2023 we recorded a charge of $11.5 million attributable to a write-off of in-process research and development intangible assets acquired from NeoPhotonics related to projects that we subsequently decided not to pursue.

[0001628280-23-016629:8k_2_02:59]
(3) In connection with the NeoPhotonics merger, certain equity awards for NeoPhotonics employees were accelerated. The total stock-based compensation associated with the acceleration was $11.9 million for the nine months ended April 1, 2023, of which $9.0 million was settled in cash.

[0001628280-23-016629:8k_2_02:60]
(4) Acquisition related costs of $16.2 million during the nine months ended April 1, 2023 mainly include professional, advisory and legal service fees related to the merger with NeoPhotonics and the acquisition of IPG Photonics’ telecom transmission product lines during the fiscal first quarter of 2023.

[0001628280-23-016629:8k_2_02:61]
(5) During the nine months ended April 1, 2023, we recorded a charge of $7.8 million with respect to the pending settlement of  certain non-ordinary course litigation matters.

[0001628280-23-016629:8k_2_02:62]
(6) During the three months ended April 1, 2023, we recorded restructuring and related charges of $1.6 million in our condensed consolidated statements of operations, which was primarily due to company-wide integration efforts as a result of the merger with NeoPhotonics, as well as our cost reduction initiatives.

[0001628280-23-016629:8k_2_02:63]
During the nine months ended April 1, 2023, we recorded restructuring and related charges of $24.8 million in our condensed consolidated statements of operations, which was primarily attributable to company-wide integration efforts as a result of the merger with NeoPhotonics, our cost reduction initiatives, as well as severance and employee-related benefits associated with NeoPhotonics’ executive severance and retention agreements. These agreements provide for payments and benefits upon an involuntary termination of employment under certain circumstances.

[0001628280-23-016629:8k_2_02:64]
(7) Shares used for net income per share on non-GAAP basis include incremental dilutive shares that would occur upon conversion of our convertible notes assuming we settle the face value of the notes in cash as the Company intends, and shares related to restricted stock units (“RSUs”) and shares issuable under our Employee Stock Purchase Plan that are anti-dilutive on GAAP basis.

[0001628280-23-016629:8k_2_02:65]
LUMENTUM HOLDINGS INC.

[0001628280-23-016629:8k_2_02:66]
RECONCILIATION OF GAAP NET INCOME TO ADJUSTED EBITDA

[0001628280-23-016629:8k_2_02:67]
(in millions, except per share data)

[0001628280-23-016629:8k_2_02:68]
(unaudited)

[0001628280-23-016629:8k_2_02:69]
|  | Three Months Ended |  |  |  | Nine Months Ended |
|  | April 1, 2023 |  |  |  | December 31, 2022 |  | April 2, 2022 |  |  |  |  |  | April 1, 2023 |  | April 2, 2022 |
| GAAP net income (loss) | $ | (39.3) |  |  |  |  | $ | (31.7) |  |  | $ | 26.0 |  |  |  |  |  |  | $ | (71.4) |  |  | $ | 164.2 |  |
| Interest and other expense, net | (2.7) |  |  |  |  | 5.2 |  |  | 17.5 |  |  |  |  |  |  | (2.8) |  |  | 49.9 |  |
| Income tax provision (benefit) | (9.4) |  |  |  |  | 4.6 |  |  | 3.3 |  |  |  |  |  |  | 14.4 |  |  | 33.8 |  |
| Depreciation | 27.7 |  |  |  |  | 26.4 |  |  | 20.2 |  |  |  |  |  |  | 78.6 |  |  | 61.2 |  |
| Amortization of acquired intangibles | 30.0 |  |  |  |  | 36.1 |  |  | 21.4 |  |  |  |  |  |  | 98.3 |  |  | 64.3 |  |
| EBITDA | 6.3 |  |  |  |  | 40.6 |  |  | 88.4 |  |  |  |  |  |  | 117.1 |  |  | 373.4 |  |
| Amortization of inventory fair value adjustments | 3.6 |  |  |  |  | 9.6 |  |  | — |  |  |  |  |  |  | 17.8 |  |  | — |  |
| Restructuring and related charges | 1.6 |  |  |  |  | 13.9 |  |  | (0.1) |  |  |  |  |  |  | 24.8 |  |  | (1.1) |  |
| Stock-based compensation | 33.1 |  |  |  |  | 36.6 |  |  | 23.3 |  |  |  |  |  |  | 116.3 |  |  | 75.4 |  |
| Acquisition related costs | — |  |  |  |  | — |  |  | — |  |  |  |  |  |  | 16.2 |  |  | — |  |
| Integration related costs | 10.6 |  |  |  |  | 8.0 |  |  | — |  |  |  |  |  |  | 19.2 |  |  | — |  |
| Write-off of in-process research and development intangible assets | 11.5 |  |  |  |  | — |  |  | — |  |  |  |  |  |  | 11.5 |  |  | — |  |
| Other charges, net | 10.3 |  |  |  |  | 24.7 |  |  | 13.5 |  |  |  |  |  |  | 49.4 |  |  | 18.9 |  |
| Adjusted EBITDA | $ | 77.0 |  |  |  |  | $ | 133.4 |  |  | $ | 125.1 |  |  |  |  |  |  | $ | 372.3 |  |  | $ | 466.6 |  |
