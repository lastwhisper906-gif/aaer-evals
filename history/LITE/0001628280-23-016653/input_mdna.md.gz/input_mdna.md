# LITE MD&A — 0001628280-23-016653


## mdna

[0001628280-23-016653:mdna:1]
[same as prior period, unchanged from 0001628280-23-002880:mdna:1]

[0001628280-23-016653:mdna:2]
[same as prior period, unchanged from 0001628280-23-002880:mdna:2]

[0001628280-23-016653:mdna:3]
[same as prior period, unchanged from 0001628280-23-002880:mdna:3]

[0001628280-23-016653:mdna:4]
[same as prior period, unchanged from 0001628280-23-002880:mdna:4]

[0001628280-23-016653:mdna:5]
[same as prior period, unchanged from 0001628280-23-002880:mdna:5]

[0001628280-23-016653:mdna:6]
[same as prior period, unchanged from 0001628280-23-002880:mdna:6]

[0001628280-23-016653:mdna:7]
We believe the global markets in which Lumentum participates have fundamentally robust, long-term trends that will increase the need for our photonics products and technologies. We believe the world is becoming more reliant on ever-increasing amounts of data flowing through optical networks and data centers. Lumentum’s products and technology enable the scaling of these optical networks and data centers to higher capacities. We expect that the accelerating shift to digital and virtual approaches to all aspects of work and life will continue into the future. Virtual meetings, video calls, and hybrid in-person and virtual environments for work and other aspects of life will continue to drive strong needs for bandwidth growth and present dynamic new challenges that our technology addresses. As manufacturers demand higher levels of precision, new materials, and factory and energy efficiency, suppliers of manufacturing tools globally are turning to laser-based approaches, including the types of lasers Lumentum supplies. Laser-based 3D sensing and LiDAR for security, industrial and automotive applications are rapidly developing markets. The technology enables computer vision applications that enhance security, safety, and new functionality in the electronic devices that people rely on every day. The use of LiDAR and in-cabin 3D sensing in automobile and delivery vehicles over time significantly adds to our long-term market opportunity. Frictionless and contactless biometric security and access control is of increasing focus globally given the world’s experience with the COVID-19 pandemic. Additionally, we expect 3D-enabled machine vision solutions to expand significantly in industrial applications in the coming years.

[0001628280-23-016653:mdna:8]
[same as prior period, unchanged from 0001628280-23-002880:mdna:8]

[0001628280-23-016653:mdna:9]
[same as prior period, unchanged from 0001628280-23-002880:mdna:10]

[0001628280-23-016653:mdna:10]
[same as prior period, unchanged from 0001628280-23-002880:mdna:11]

[0001628280-23-016653:mdna:11]
[same as prior period, unchanged from 0001628280-23-002880:mdna:12]

[0001628280-23-016653:mdna:12]
[same as prior period, unchanged from 0001628280-23-002880:mdna:13]

[0001628280-23-016653:mdna:13]
[same as prior period, unchanged from 0001628280-23-002880:mdna:14]

[0001628280-23-016653:mdna:14]
[same as prior period, unchanged from 0001628280-23-002880:mdna:15]

[0001628280-23-016653:mdna:15]
The total transaction consideration of $934.4 million was funded by the cash balances of the combined company. We also recorded $24.2 million of merger-related costs, representing professional and other direct acquisition costs. Of the $24.2 million of merger-related costs, $8.3 million was incurred in fiscal year 2022, and $2.1 million and $15.9 million was incurred during the three and nine months ended April 1, 2023, respectively, which was recorded as selling, general and administrative expense in the consolidated statement of operations.

[0001628280-23-016653:mdna:16]
[same as prior period, unchanged from 0001628280-23-002880:mdna:17]

[0001628280-23-016653:mdna:17]
[same as prior period, unchanged from 0001628280-23-002880:mdna:18]

[0001628280-23-016653:mdna:18]
On August 15, 2022, we completed a transaction to acquire IPG Photonics’ telecom transmission product lines (“IPG product lines”) that develop and market products for use in telecommunications and datacenter infrastructure, including Digital Signal Processors (DSPs), ASICs and optical transceivers. This acquisition will enable us to expand our business in the OpComms segment. The total purchase price of $55.9 million was paid in cash. Refer to “Note 4. Business Combinations” in the notes to condensed consolidated financial statements for additional information regarding the acquisition of these product lines.

[0001628280-23-016653:mdna:19]
[same as prior period, unchanged from 0001628280-23-002880:mdna:20]

[0001628280-23-016653:mdna:20]
[same as prior period, unchanged from 0001628280-23-002880:mdna:21]

[0001628280-23-016653:mdna:21]
[same as prior period, unchanged from 0001628280-23-002880:mdna:23]

[0001628280-23-016653:mdna:22]
In the geographies where we have operations, we have, in general and where applicable, been deemed an essential business and been permitted to continue manufacturing and conducting new product development operations in a more limited capacity during the pandemic. This stems from our critical role in global supply chains for the world’s communications and health-care systems. While the impact of the COVID-19 pandemic is lessening, there has been a global slowdown of economic activity (including a decrease in demand for a broad variety of goods and services), disruptions in global supply chains, labor shortages, and significant volatility and potential disruption of financial markets.  Given the continually evolving situation, particularly in light of the potential emergence of new variants, it is difficult to predict the magnitude and duration of the impact of the COVID-19 pandemic to our markets, its effects, or precisely when our ability to supply our products will return to full capacity. We are continuing to actively monitor the situation and may take further actions altering our business operations that we determine are in the best interests of our employees, customers, communities, business partners, suppliers and stockholders, or as required by federal, state, or local authorities. It is not clear what the potential effects any such alterations or modifications may have on our business, including the effects on our customers, employees and prospects, or on our financial results for the future.

[0001628280-23-016653:mdna:23]
Our primary strategic focus is technology and product leadership combined with close customer relationships in long-term healthy and growing markets. We believe there are long-term opportunities, as the world’s experience with COVID-19 could drive an increasingly digital and virtual world, touching all aspects of life and work, which increasingly emphasizes the importance of communications systems, cloud services, augmented and virtual reality, and enhanced security. Additionally, ever advancing electronic devices are needed to consume, produce, and communicate digital and virtual content. All these trends could drive the need for higher volumes of higher performing optical devices that we could supply. As such, we expect to continue to invest strongly in new products, technology and customer programs.

[0001628280-23-016653:mdna:24]
[same as prior period, unchanged from 0001628280-23-002880:mdna:26]

[0001628280-23-016653:mdna:25]
[same as prior period, unchanged from 0001628280-23-002880:mdna:28]

[0001628280-23-016653:mdna:26]
Our business and our customers’ businesses have been negatively impacted by worldwide logistics and supply chain issues, including constraints on available cargo capabilities and limited availability of once broadly available supplies of both raw materials and finished components. COVID-19 has also created dynamics in the semiconductor component supply chains that have led to shortages of the types of components we and our customers require in our products. These shortages have impacted our ability to meet demand and generate revenue from certain products in fiscal 2022 and, they continue to impact our ability to meet demand in fiscal 2023. If our ability to procure needed semiconductor components does not improve, our ability to supply our products to our customers will be impacted and our revenue and profit margin may be reduced. In addition, if our customers are unable to procure needed semiconductor components, this could reduce their demand for our products and reduce our revenue. The impact of semiconductor component shortages may continue in the near term as supplier and customer buffer inventories and safety stocks are exhausted. Due to the global supply chain constraints, we have had to incur incremental supply and procurement costs in order to increase our ability to fulfill demands from our customers. As of April 1, 2023, our inventory balance includes  $10.8 million of incremental supply and procurement costs. These costs may decrease our gross margin in the near term. Although the supply shortage we experienced in fiscal 2022 was partially relieved, we expect component supply to be a challenge in the remaining fiscal 2023.

[0001628280-23-016653:mdna:27]
In addition, in response to component shortages, certain of our customers accumulated inventory that they are now managing down as supply conditions improve.  Accordingly, ordering patterns are difficult to predict and have declined from recent periods. For example, in our fiscal 2023 third quarter, a network equipment manufacturer who represented more than 10 percent of our fiscal second quarter revenue informed us that due to their inventory management, they would not take the shipments we had originally projected for the quarter.

[0001628280-23-016653:mdna:28]
[same as prior period, unchanged from 0001628280-23-002880:mdna:30]

[0001628280-23-016653:mdna:29]
[same as prior period, unchanged from 0001628280-23-002880:mdna:31]

[0001628280-23-016653:mdna:30]
Our condensed consolidated financial statements are prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) as set forth in the Financial Accounting Standards Board’s Accounting Standards Codification (“ASC”), and we consider the various staff accounting bulletins and other applicable guidance issued by the United States Securities and Exchange Commission (“SEC”). GAAP, as set forth within the ASC, requires us to make certain estimates, judgments and assumptions. We believe that the estimates, judgments and assumptions upon which we rely are reasonable based upon information available to us at the time that these estimates, judgments and assumptions are made. These estimates, judgments and assumptions can affect the reported amounts of assets and liabilities as of the date of the financial statements as well as the reported amounts of revenues and expenses during the periods presented. To the extent there are differences between these estimates, judgments or assumptions and actual results, our financial statements will be affected. The accounting policies that reflect our more significant estimates, judgments and assumptions and that we believe are the most critical to aid in fully understanding and evaluating our reported financial results include the following:

[0001628280-23-016653:mdna:31]
[same as prior period, unchanged from 0001628280-23-002880:mdna:33]

[0001628280-23-016653:mdna:32]
[same as prior period, unchanged from 0001628280-23-002880:mdna:34]

[0001628280-23-016653:mdna:33]
[same as prior period, unchanged from 0001628280-23-002880:mdna:35]

[0001628280-23-016653:mdna:34]
[same as prior period, unchanged from 0001628280-23-002880:mdna:36]

[0001628280-23-016653:mdna:35]
[same as prior period, unchanged from 0001628280-23-002880:mdna:37]

[0001628280-23-016653:mdna:36]
Management’s Discussion and Analysis of Financial Condition and Results of Operations contained in Part II, Item 7 of our Annual Report on Form 10-K for our fiscal year ended July 2, 2022 provides a complete discussion of our critical accounting policies and estimates. There have been no changes to these policies during the three and nine months ended April 1, 2023.

[0001628280-23-016653:mdna:37]
Recently Issued Accounting Pronouncements

[0001628280-23-016653:mdna:38]
Refer to “Note 2. Recently Issued Accounting Pronouncements” in the notes to condensed consolidated financial statements.

[0001628280-23-016653:mdna:39]
[same as prior period, unchanged from 0001628280-23-002880:mdna:41]

[0001628280-23-016653:mdna:40]
[same as prior period, unchanged from 0001628280-23-002880:mdna:42]

[0001628280-23-016653:mdna:41]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 1, 2023 |  | April 2, 2022 |  | April 1, 2023 |  | April 2, 2022 |
| Segment net revenue: |  |  |  |  |  |  |  |
| OpComms | 87.4 | % |  | 87.1 | % |  | 88.6 | % |  | 88.9 | % |
| Lasers | 12.6 |  |  | 12.9 |  |  | 11.4 |  |  | 11.1 |  |
| Net revenue | 100.0 |  |  | 100.0 |  |  | 100.0 |  |  | 100.0 |  |
| Cost of sales | 65.9 |  |  | 53.8 |  |  | 60.9 |  |  | 49.3 |  |
| Amortization of acquired developed intangibles | 4.9 |  |  | 3.9 |  |  | 4.8 |  |  | 3.7 |  |
| Gross profit | 29.2 |  |  | 42.3 |  |  | 34.3 |  |  | 47.0 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 22.3 |  |  | 14.3 |  |  | 16.8 |  |  | 12.7 |  |
| Selling, general and administrative | 19.9 |  |  | 16.1 |  |  | 20.1 |  |  | 15.2 |  |
| Restructuring and related charges | 0.4 |  |  | — |  |  | 1.8 |  |  | (0.1) |  |
| Total operating expenses | 42.6 |  |  | 30.5 |  |  | 38.6 |  |  | 27.8 |  |
| Income (loss) from operations | (13.4) |  |  | 11.8 |  |  | (4.3) |  |  | 19.2 |  |
| Interest expense | (2.3) |  |  | (5.0) |  |  | (1.9) |  |  | (4.2) |  |
| Other income, net | 3.0 |  |  | 0.6 |  |  | 2.1 |  |  | 0.3 |  |
| Income (loss) before income taxes | (12.7) |  |  | 7.4 |  |  | (4.1) |  |  | 15.3 |  |
| Income tax provision (benefit) | (2.5) |  |  | 0.8 |  |  | 1.0 |  |  | 2.6 |  |
| Net income (loss) | (10.3) | % |  | 6.6 | % |  | (5.1) | % |  | 12.7 | % |

[0001628280-23-016653:mdna:42]
46

[0001628280-23-016653:mdna:43]
Financial data for the three and nine months ended April 1, 2023 and April 2, 2022

[0001628280-23-016653:mdna:44]
The following table summarizes selected unaudited condensed consolidated statements of operations items for the periods presented (in millions, except for percentages):

[0001628280-23-016653:mdna:45]
|  | Three Months Ended |  |  |  |  |  | Nine Months Ended |  |  |  |  |
|  | April 1, 2023 |  | April 2, 2022 |  | Change |  | Percentage Change |  | April 1, 2023 |  | April 2, 2022 |  | Change |  | Percentage Change |
| Segment net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| OpComms | $ | 335.1 |  |  | $ | 344.2 |  |  | $ | (9.1) |  |  | (2.6) | % |  | $ | 1,237.3 |  |  | $ | 1,147.6 |  |  | $ | 89.7 |  |  | 7.8 | % |
| Lasers | 48.3 |  |  | 51.2 |  |  | (2.9) |  |  | (5.7) | % |  | 158.9 |  |  | 142.9 |  |  | 16.0 |  |  | 11.2 | % |
| Net revenue | $ | 383.4 |  |  | $ | 395.4 |  |  | $ | (12.0) |  |  | (3.0) | % |  | $ | 1,396.2 |  |  | $ | 1,290.5 |  |  | $ | 105.7 |  |  | 8.2 | % |
| Gross profit | $ | 112.0 |  |  | $ | 167.2 |  |  | $ | (55.2) |  |  | (33.0) | % |  | $ | 479.4 |  |  | $ | 606.9 |  |  | $ | (127.5) |  |  | (21.0) | % |
| Gross margin | 29.2 | % |  | 42.3 | % |  |  |  |  |  | 34.3 | % |  | 47.0 | % |  |  |  |  |
| Research and development | $ | 85.4 |  |  | $ | 56.7 |  |  | $ | 28.7 |  |  | 50.6 | % |  | $ | 233.9 |  |  | $ | 164.0 |  |  | $ | 69.9 |  |  | 42.6 | % |
| Percentage of net revenue | 22.3 | % |  | 14.3 | % |  |  |  |  |  | 16.8 | % |  | 12.7 | % |  |  |  |  |
| Selling, general and administrative | $ | 76.4 |  |  | $ | 63.8 |  |  | $ | 12.6 |  |  | 19.7 | % |  | $ | 280.5 |  |  | $ | 196.1 |  |  | $ | 84.4 |  |  | 43.0 | % |
| Percentage of net revenue | 19.9 | % |  | 16.1 | % |  |  |  |  |  | 20.1 | % |  | 15.2 | % |  |  |  |  |
| Restructuring and related charges | $ | 1.6 |  |  | $ | (0.1) |  |  | $ | 1.7 |  |  | N/A |  | $ | 24.8 |  |  | $ | (1.1) |  |  | $ | 25.9 |  |  | N/A |
| Percentage of net revenue | 0.4 | % |  | — | % |  |  |  |  |  | 1.8 | % |  | (0.1) | % |  |  |  |  |

[0001628280-23-016653:mdna:46]
[same as prior period, unchanged from 0001628280-23-002880:mdna:48]

[0001628280-23-016653:mdna:47]
Net revenue decreased by $12.0 million, or 3.0%, during the three months ended April 1, 2023 compared to the three months ended April 2, 2022, due to a $9.1 million decrease in OpComms revenue and a $2.9 million decrease in Lasers revenue.

[0001628280-23-016653:mdna:48]
OpComms net revenue decreased by $9.1 million, or 2.6%, during the three months ended April 1, 2023 compared to the three months ended April 2, 2022. Within OpComms, Telecom and Datacom increased by $49.8 million primarily due to $73.0 million of revenue attributable to the NeoPhotonics acquisition. The increase was offset by $28.3 million decrease in Datacom due to reduction in demand associated with inventory management and build up at our customers and slowing of cloud data center customer capital spending. Industrial and Consumer net revenue decreased by $58.9 million primarily due to higher market competition and reflects share normalization in the market.

[0001628280-23-016653:mdna:49]
Lasers net revenue decreased by $2.9 million, or 5.7%, during the three months ended April 1, 2023 compared to the three months ended April 2, 2022, primarily due to lower customer demand for our kilowatt class fiber laser products.

[0001628280-23-016653:mdna:50]
Net revenue increased by $105.7 million, or 8.2%, during the nine months ended April 1, 2023 compared to the nine months ended April 2, 2022, due to a $89.7 million increase in OpComms revenue and a $16.0 million increase in Lasers revenue.

[0001628280-23-016653:mdna:51]
OpComms net revenue increased by $89.7 million, or 7.8%, during the nine months ended April 1, 2023 compared to the nine months ended April 2, 2022. Within OpComms, Telecom and Datacom increased by $311.0 million, primarily due to $250.4 million of revenue attributable to the NeoPhotonics acquisition. Additionally, the supply chain shortage in fiscal year 2022 was partially relieved, allowing us to meet more customer demand during the period compared to the period in the prior year. Industrial and Consumer net revenue decreased by $221.3 million primarily due to higher market competition and reflects share normalization in the market.

[0001628280-23-016653:mdna:52]
Lasers net revenue increased by $16.0 million, or 11.2%, during the nine months ended April 1, 2023 compared to the nine months ended April 2, 2022, primarily due to a return in customer demand for our kilowatt class fiber laser products following a recovery in industrial production earlier in the fiscal year 2023.

[0001628280-23-016653:mdna:53]
During the three and nine months ended April 1, 2023, our net revenue from a single customer, which represented 10% or greater of the total net revenue, was concentrated with two customers, who collectively accounted for 23% and 29% of our total net revenue, respectively.

[0001628280-23-016653:mdna:54]
During the three and nine months ended April 2, 2022, our net revenue from a single customer, which represented 10% or greater of total net revenue was concentrated with two customers, who collectively accounted for 38% and 43% of our total net revenue, respectively.

[0001628280-23-016653:mdna:55]
[same as prior period, unchanged from 0001628280-23-002880:mdna:57]

[0001628280-23-016653:mdna:56]
[same as prior period, unchanged from 0001628280-23-002880:mdna:58]

[0001628280-23-016653:mdna:57]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 1, 2023 |  | April 2, 2022 |  | April 1, 2023 |  | April 2, 2022 |
|  | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States | $ | 68.3 |  |  | 17.8 | % |  | $ | 36.3 |  |  | 9.2 | % |  | $ | 196.0 |  |  | 14.0 | % |  | $ | 115.4 |  |  | 8.9 | % |
| Mexico | 20.5 |  |  | 5.4 |  |  | 42.3 |  |  | 10.7 |  |  | 137.5 |  |  | 9.8 |  |  | 113.6 |  |  | 8.8 |  |
| Other Americas | 1.9 |  |  | 0.5 |  |  | 3.0 |  |  | 0.7 |  |  | 8.0 |  |  | 0.6 |  |  | 7.7 |  |  | 0.6 |  |
| Total Americas | $ | 90.7 |  |  | 23.7 | % |  | $ | 81.6 |  |  | 20.6 | % |  | $ | 341.5 |  |  | 24.4 | % |  | $ | 236.7 |  |  | 18.3 | % |
| Asia-Pacific: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Hong Kong | $ | 46.5 |  |  | 12.1 | % |  | $ | 109.2 |  |  | 27.6 | % |  | $ | 190.0 |  |  | 13.6 | % |  | $ | 366.5 |  |  | 28.4 | % |
| South Korea | 28.5 |  |  | 7.4 |  |  | 50.3 |  |  | 12.7 |  |  | 148.2 |  |  | 10.6 |  |  | 233.3 |  |  | 18.1 |  |
| Thailand | 67.8 |  |  | 17.7 |  |  | 28.2 |  |  | 7.1 |  |  | 203.2 |  |  | 14.6 |  |  | 71.5 |  |  | 5.6 |  |
| Japan | 41.8 |  |  | 10.9 |  |  | 44.5 |  |  | 11.3 |  |  | 137.4 |  |  | 9.8 |  |  | 137.3 |  |  | 10.6 |  |
| Other Asia-Pacific | 61.5 |  |  | 16.0 |  |  | 53.2 |  |  | 13.5 |  |  | 235.1 |  |  | 16.8 |  |  | 161.8 |  |  | 12.5 |  |
| Total Asia-Pacific | $ | 246.1 |  |  | 64.1 | % |  | $ | 285.4 |  |  | 72.2 | % |  | $ | 913.9 |  |  | 65.5 | % |  | $ | 970.4 |  |  | 75.2 | % |
| EMEA | $ | 46.6 |  |  | 12.2 | % |  | $ | 28.4 |  |  | 7.2 | % |  | $ | 140.8 |  |  | 10.1 | % |  | $ | 83.4 |  |  | 6.5 | % |
| Total net revenue | $ | 383.4 |  |  |  |  | $ | 395.4 |  |  |  |  | $ | 1,396.2 |  |  |  |  | $ | 1,290.5 |  |  |  |

[0001628280-23-016653:mdna:58]
For the three and nine months ended April 1, 2023, net revenue from customers outside the United States, based on customer shipping location, represented 82.2% and 86.0% of net revenue, respectively.  For the three and nine months ended April 2, 2022, net revenue from customers outside the United States, based on customer shipping location, represented 90.8% and 91.1% of net revenue, respectively.

[0001628280-23-016653:mdna:59]
[same as prior period, unchanged from 0001628280-23-002880:mdna:61]

[0001628280-23-016653:mdna:60]
[same as prior period, unchanged from 0001628280-23-002880:mdna:62]

[0001628280-23-016653:mdna:61]
[same as prior period, unchanged from 0001628280-23-002880:mdna:63]

[0001628280-23-016653:mdna:62]
|  | Three Months Ended |  | Nine Months Ended |
|  | Gross Profit |  | Gross Margin |  | Gross Profit |  | Gross Margin |
|  | April 1, 2023 |  | April 2, 2022 |  | April 1, 2023 |  | April 2, 2022 |  | April 1, 2023 |  | April 2, 2022 |  | April 1, 2023 |  | April 2, 2022 |
| OpComms | $ | 136.8 |  |  | $ | 168.5 |  |  | 40.8 | % |  | 49.0 | % |  | $ | 549.8 |  |  | $ | 596.2 |  |  | 44.4 | % |  | 52.0 | % |
| Lasers | 19.5 |  |  | 27.1 |  |  | 40.4 | % |  | 52.9 | % |  | 77.6 |  |  | 74.1 |  |  | 48.8 | % |  | 51.9 | % |
| Segment total | $ | 156.3 |  |  | $ | 195.6 |  |  | 40.8 | % |  | 49.5 | % |  | $ | 627.4 |  |  | $ | 670.3 |  |  | 44.9 | % |  | 51.9 | % |
| Unallocated corporate items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation | (6.9) |  |  | (5.4) |  |  |  |  |  |  | (19.1) |  |  | (15.2) |  |  |  |  |  |
| Amortization of acquired intangibles | (18.7) |  |  | (15.6) |  |  |  |  |  |  | (66.4) |  |  | (47.3) |  |  |  |  |  |
| Amortization of acquired inventory fair value adjustments | (3.6) |  |  | — |  |  |  |  |  |  | (17.8) |  |  | — |  |  |  |  |  |
| Integration related costs | (6.7) |  |  | — |  |  |  |  |  |  | (9.5) |  |  | — |  |  |  |  |  |
| Other charges, net (1) | (8.4) |  |  | (7.4) |  |  |  |  |  |  | (35.2) |  |  | (0.9) |  |  |  |  |  |
| Total | $ | 112.0 |  |  | $ | 167.2 |  |  | 29.2 | % |  | 42.3 | % |  | $ | 479.4 |  |  | $ | 606.9 |  |  | 34.3 | % |  | 47.0 | % |

[0001628280-23-016653:mdna:63]
(1) Other (charges) gains of unallocated corporate items for  the three and nine months ended April 1, 2023 primarily relate to $8.0 million and $27.0 million, respectively, of incremental cost of sales related to components previously acquired from various brokers to satisfy customer demand.

[0001628280-23-016653:mdna:64]
Other (charges) gains of unallocated corporate items for the three months ended April 2, 2022 relate to $5.8 million of incremental cost of sales related to components previously acquired from various brokers to satisfy customer demand. Other (charges) gains of unallocated corporate items for the nine months ended April 2, 2022 primarily relate to $5.8 million of incremental cost of sales related to components previously acquired from various brokers to satisfy customer demand, offset by a $5.9 million gain as a result of selling equipment that was no longer needed after we transferred certain product lines to new production facilities in fiscal 2021.

[0001628280-23-016653:mdna:65]
[same as prior period, unchanged from 0001628280-23-002880:mdna:67]

[0001628280-23-016653:mdna:66]
[same as prior period, unchanged from 0001628280-23-002880:mdna:68]

[0001628280-23-016653:mdna:67]
Gross margin for the three months ended April 1, 2023 decreased to 29.2% from 42.3% for the three months ended April 2, 2022. The decrease was primarily driven by lower gross margin from our OpComms segment, as discussed further below. The lower gross margin was also driven by $7.7 million higher inventory excess and obsolete charges due to company-wide integration efforts as a result of the NeoPhotonics merger and transitions to the next generation of products, $3.6 million of amortization of acquired inventory, an aggregate $3.1 million higher amortization of intangible assets due to the NeoPhotonics merger and the acquisition of IPG product lines, and $2.2 million higher incremental cost of sales related to components previously acquired from various brokers to satisfy customer demand.

[0001628280-23-016653:mdna:68]
Gross margin for the nine months ended April 1, 2023 decreased to 34.3% from 47.0% for the nine months ended April 2, 2022. The decrease was primarily driven by lower gross margin from our OpComms segment. The lower gross margin was also driven by $21.2 million higher incremental cost of sales related to components previously acquired from various brokers to satisfy customer demand, an aggregate $19.1 million higher amortization of intangible assets due to the NeoPhotonics merger and the acquisition of IPG product lines, $17.8 million of amortization of acquired inventory, and $13.7 million higher inventory excess and obsolete charges due to company-wide integration efforts as a result of the NeoPhotonics merger and transitions to the next generation of products.

[0001628280-23-016653:mdna:69]
The market in which we sell products are consolidating, undergoing product, architectural and business model transitions, have high customer concentrations, are highly competitive, are price sensitive and/or are affected by customer seasonal and have variant buying patterns. We expect these factors to result in variability of our gross margin.

[0001628280-23-016653:mdna:70]
Due to global supply chain constraints, we have had to incur incremental supply and procurement costs in order to increase our ability to fulfill demands from our customers. As of April 1, 2023, our inventory balance includes $10.8 million of incremental supply and procurement costs.

[0001628280-23-016653:mdna:71]
[same as prior period, unchanged from 0001628280-23-002880:mdna:73]

[0001628280-23-016653:mdna:72]
[same as prior period, unchanged from 0001628280-23-002880:mdna:74]

[0001628280-23-016653:mdna:73]
OpComms gross margin for the three months ended April 1, 2023 decreased to 40.8% from 49.0% for the three months ended April 2, 2022. The decrease was primarily due to a less profitable mix of products, including lower sales of higher margin imaging and sensing products, as well as higher sales of telecom products due to the merger with NeoPhotonics, which have lower margins than our average OpComms margins.

[0001628280-23-016653:mdna:74]
OpComms gross margin for the nine months ended April 1, 2023 decreased to 44.4% from 52.0% for the nine months ended April 2, 2022. The decrease was primarily due to a less profitable mix of products, including lower sales of higher margin imaging and sensing products, as well as higher sales of telecom products due to the merger with NeoPhotonics, which have lower margins than our average OpComms margins.

[0001628280-23-016653:mdna:75]
[same as prior period, unchanged from 0001628280-23-002880:mdna:77]

[0001628280-23-016653:mdna:76]
Lasers gross margin for the three months ended April 1, 2023 decreased to 40.4% from 52.9% for the three months ended April 2, 2022. The decrease was primarily due to lower revenue from high margin solid state lasers, as well as increased excess and obsolete charges due to transitions to the next generation of products.

[0001628280-23-016653:mdna:77]
Lasers gross margin for the nine months ended April 1, 2023 decreased to 48.8% from 51.9% for the nine months ended April 2, 2022. The decrease was primarily due to lower revenue from high margin solid state lasers, as well as increased excess and obsolete charges due to transitions to the next generation of products.

[0001628280-23-016653:mdna:78]
[same as prior period, unchanged from 0001628280-23-002880:mdna:80]

[0001628280-23-016653:mdna:79]
R&D expense increased by $28.7 million, or 50.6%, for the three months ended April 1, 2023 compared to the three months ended April 2, 2022. The increase in R&D expense for the three months ended April 1, 2023 was primarily driven by an $11.5 million write-off of in-process research and development intangible assets associated with NeoPhotonics acquisition for projects that we will no longer pursue. The increase is also attributable to an increase in payroll and employee compensation related expenses due to additional headcount from the merger with NeoPhotonics and the acquisition of IPG product lines.

[0001628280-23-016653:mdna:80]
R&D expense increased by $69.9 million, or 42.6%, for the nine months ended April 1, 2023 compared to the nine months ended April 2, 2022. The increase in R&D expense for the nine months ended April 1, 2023 was primarily driven by an $11.5 million write-off of in-process research and development intangible assets associated with NeoPhotonics acquisition for projects that we will no longer pursue. The increase is also attributable to an increase in payroll and employee compensation related expenses due to additional headcount from the merger with NeoPhotonics and the acquisition of IPG product lines.

[0001628280-23-016653:mdna:81]
We believe that continuing our investments in R&D is critical to attaining our strategic objectives. Despite signs of a weaker macroeconomic environment, we plan to continue to invest in R&D and new products that we believe will further differentiate us in the marketplace and we expect to continue to invest significant R&D spending in the future.

[0001628280-23-016653:mdna:82]
[same as prior period, unchanged from 0001628280-23-002880:mdna:84]

[0001628280-23-016653:mdna:83]
SG&A expense increased by $12.6 million, or 19.7%, during the three months ended April 1, 2023 compared to the three months ended April 2, 2022. The increase in SG&A expense for the three months ended April 1, 2023 was primarily driven by an increase in payroll and employee compensation related expenses due to additional headcount from the merger with NeoPhotonics. The increase was also attributable to incremental facility costs and $5.5 million of incremental amortization of intangibles due to the NeoPhotonics merger and the acquisition of IPG product lines.

[0001628280-23-016653:mdna:84]
SG&A expense increased by $84.4 million, or 43.0%, during the nine months ended April 1, 2023 compared to the nine months ended April 2, 2022. The increase in SG&A expense for the nine months ended April 1, 2023 was primarily driven by an increase in payroll and employee compensation related expenses due to additional headcount from the merger with NeoPhotonics and higher stock-based compensation. The increase was also attributable to incremental facility costs and $14.9 million of incremental amortization of intangibles due to the NeoPhotonics merger and the acquisition of IPG product lines.  In connection with the NeoPhotonics merger, certain equity awards for NeoPhotonics employees were accelerated. We recognized $11.9 million of stock-based compensation associated with the acceleration during the first quarter of fiscal year 2023. We also recognized $16.2 million merger and acquisition related costs, primarily professional service fees and retention expenses related to the NeoPhotonics merger and the acquisition of IPG product lines and $7.8 million expense with respect to the pending settlement of certain non-ordinary course litigation matters. For a description of our material pending legal proceedings, refer to “Note 14. Commitments and Contingencies” of the notes to condensed consolidated financial statements included in Part I, Item 1 of this Form 10-Q.

[0001628280-23-016653:mdna:85]
From time to time, we incur expenses that are not part of our ordinary operations, such as mergers and acquisition-related and litigation expenses, which generally increase our SG&A expenses and potentially impact our profitability expectations in any particular quarter.

[0001628280-23-016653:mdna:86]
[same as prior period, unchanged from 0001628280-23-002880:mdna:88]

[0001628280-23-016653:mdna:87]
We have initiated various strategic restructuring events primarily intended to reduce costs, consolidate our operations, rationalize the manufacturing of our products, and align our business in response to market conditions and as a result of our merger with NeoPhotonics on August 3, 2022.

[0001628280-23-016653:mdna:88]
During the three months ended April 1, 2023, we recorded restructuring and related charges of $1.6 million in our condensed consolidated statements of operations, which was primarily due to company-wide integration efforts as a result of the merger with NeoPhotonics, as well as our cost reduction initiatives.

[0001628280-23-016653:mdna:89]
During the nine months ended April 1, 2023, we recorded restructuring and related charges of $24.8 million in our condensed consolidated statements of operations, which was primarily attributable to company-wide integration efforts as a result of the merger with NeoPhotonics, our cost reduction initiatives, as well as severance and employee-related benefits associated with NeoPhotonics’ executive severance and retention agreements. These agreements provide for payments and benefits upon an involuntary termination of employment under certain circumstances.

[0001628280-23-016653:mdna:90]
During the nine months ended April 2, 2022, we recorded a net reversal to our restructuring and related charges of $1.1 million, which was attributable to lower than anticipated employee severance charges primarily as a result of retaining and re-assigning certain employees.

[0001628280-23-016653:mdna:91]
[same as prior period, unchanged from 0001628280-23-002880:mdna:94]

[0001628280-23-016653:mdna:92]
For the three months ended April 1, 2023 and April 2, 2022, we recorded interest expense of $8.7 million and $19.7 million, respectively. For the nine months ended April 1, 2023 and April 2, 2022, we recorded interest expense of $26.1 million and $53.7 million, respectively. Interest expense was driven primarily by the amortization of the debt discount and issuance costs of our convertible notes.  The decrease in interest expense for the three and nine months ended April 1, 2023 is primarily a result of the adoption of ASU 2020-06 in our first quarter of fiscal 2023, which requires us to record each of our 2026 Notes and 2028 Notes as single liabilities, measured at amortized cost, eliminating the interest expense associated with the debt discount.

[0001628280-23-016653:mdna:93]
[same as prior period, unchanged from 0001628280-23-002880:mdna:96]

[0001628280-23-016653:mdna:94]
The components of other income, net are as follows (in millions):

[0001628280-23-016653:mdna:95]
|  | Three Months Ended |  | Nine Months Ended |  |  |
|  | April 1, 2023 |  | April 2, 2022 |  | April 1, 2023 |  | April 2, 2022 |  |  |
| Foreign exchange gains (losses), net | $ | (0.5) |  |  | $ | 1.1 |  |  | $ | 4.4 |  |  | $ | 1.7 |  |  |  |
| Interest and investment income | 11.9 |  |  | 1.1 |  |  | 24.4 |  |  | 2.3 |  |  |  |
| Other income (expense), net | — |  |  | — |  |  | 0.1 |  |  | (0.2) |  |  |  |
| Total other income, net | $ | 11.4 |  |  | $ | 2.2 |  |  | $ | 28.9 |  |  | $ | 3.8 |  |  |  |

[0001628280-23-016653:mdna:96]
For the three months ended April 1, 2023, other income, net increased by $9.2 million as compared to the three months ended April 2, 2022, primarily due to an increase in interest and investment income of $10.8 million driven by an increase in interest rates on our fixed income securities, offset by net foreign exchange losses of $1.6 million as a result of the strengthening of other foreign currencies relative to the U.S. dollar.

[0001628280-23-016653:mdna:97]
For the nine months ended April 1, 2023, other income, net increased by $25.1 million, primarily due to an increase in interest and investment income of $22.1 million driven by an increase in interest rates on our fixed income securities and net foreign exchange gain of  $2.7 million as a result of the strengthening of the U.S. dollar relative to other foreign currencies.

[0001628280-23-016653:mdna:98]
[same as prior period, unchanged from 0001628280-23-002880:mdna:101]

[0001628280-23-016653:mdna:99]
| (in millions) | Three Months Ended |  | Nine Months Ended |
|  | April 1, 2023 |  | April 2, 2022 |  | April 1, 2023 |  | April 2, 2022 |
| Income tax provision (benefit) | $ | (9.4) |  |  | $ | 3.3 |  |  | $ | 14.4 |  |  | $ | 33.8 |  |

[0001628280-23-016653:mdna:100]
We recorded a tax benefit of $9.4 million and a tax provision of $14.4 million for the three and nine months ended April 1, 2023, respectively.  Our tax benefit for the three months ended April 1, 2023 includes a discrete tax expense of $9.8 million, primarily related to a tax planning action that was implemented during the current quarter relating to fiscal year 2022 and changes in prior year uncertain tax positions, partially offset by a shortfall in connection with stock-based compensation vested during the quarter.  Our tax provision for the nine months ended April 1, 2023 includes a discrete tax expense of $7.2 million, primarily related to the international restructuring, partially offset by the tax benefits from tax rate changes, a tax planning action that was implemented during the current quarter relating to fiscal year 2022, and changes in prior year uncertain tax positions.

[0001628280-23-016653:mdna:101]
We recorded a tax provision of $3.3 million and $33.8 million for the three and nine months ended April 2, 2022, respectively. Our tax provision for the three months ended April 2, 2022 includes a discrete tax benefit of $2.0 million, primarily related to currency re-measurement of certain tax related accounts and excess tax benefit related to stock-based compensation that vested during the period.  Our tax provision for the nine months ended April 2, 2022 includes a discrete tax benefit of $3.2 million, primarily related to currency re-measurement of certain tax related accounts and excess tax benefit related to stock-based compensation vested during the period.

[0001628280-23-016653:mdna:102]
Our estimated effective tax rate for fiscal 2023 also differs from the 21% U.S. statutory rate primarily due to the income tax expense from the tax effect of Global Intangible Low-Taxed Income (“GILTI”), net of benefit for foreign tax credits, subpart F inclusion, foreign rate differential and non-deductible stock-based compensation, partially offset by the income tax benefit from U.S. federal R&D tax credits.

[0001628280-23-016653:mdna:103]
[same as prior period, unchanged from 0001628280-23-002880:mdna:106]

[0001628280-23-016653:mdna:104]
[same as prior period, unchanged from 0001628280-23-002880:mdna:107]

[0001628280-23-016653:mdna:105]
[same as prior period, unchanged from 0001628280-23-002880:mdna:108]

[0001628280-23-016653:mdna:106]
As of April 1, 2023 and July 2, 2022, our cash and cash equivalents were $549.2 million and $1,290.2 million, respectively. As of April 1, 2023 and July 2, 2022, our short-term investments of $1,118.0 million and $1,258.8 million, respectively, were all held in the United States. Cash equivalents and short-term investments are primarily comprised of money market funds, treasuries, agencies, high quality investment grade fixed income securities, certificates of deposit and commercial paper. Our investment policy and strategy provides for diversification of investments and is focused on the preservation of capital and supporting our liquidity requirements.

[0001628280-23-016653:mdna:107]
The total amount of cash held by the non-United States entities as of April 1, 2023 and July 2, 2022 was $323.6 million and $216.1 million, respectively, which was primarily held by entities incorporated in the United Kingdom, the British Virgin Islands, Japan, Hong Kong, China, Switzerland, Cayman, and Thailand. Although the cash currently held in the United States, as well as the cash generated in the United States from future operations, is expected to cover our normal operating requirements, a substantial amount of additional cash could be required for other purposes, such as capital expenditures to support our business and growth, including costs associated with increasing internal manufacturing capabilities, particularly in our Thailand facility, strategic transactions and partnerships, and future acquisitions.

[0001628280-23-016653:mdna:108]
Our intent is to indefinitely reinvest funds held outside the United States and, except for the funds held in the Cayman Islands, the British Virgin Islands, Japan and Hong Kong, our current plans do not demonstrate a need to repatriate them to fund our domestic operations. However, if in the future, we encounter a significant need for liquidity domestically or at a particular location that we cannot fulfill through borrowings, equity offerings, or other internal or external sources, or the cost to bring back the money is not significant from a tax perspective, we may determine that cash repatriations are necessary or desirable. Repatriation could result in additional material taxes. These factors may cause us to have an overall tax rate higher than other companies or higher than our tax rates in the past. Additionally, if conditions warrant, we may seek to obtain additional financing through debt or equity sources. To the extent we issue additional shares, it may create dilution to our existing stockholders. However, any such financing may not be available on terms favorable to us, or may not be available at all.

[0001628280-23-016653:mdna:109]
[same as prior period, unchanged from 0001628280-23-002880:mdna:113]

[0001628280-23-016653:mdna:110]
[same as prior period, unchanged from 0001628280-23-002880:mdna:114]

[0001628280-23-016653:mdna:111]
We believe that our cash and cash equivalents as of April 1, 2023 and cash flows from our operating activities will be sufficient to meet our liquidity and capital spending requirements for at least the next 12 months.

[0001628280-23-016653:mdna:112]
[same as prior period, unchanged from 0001628280-23-002880:mdna:116]

[0001628280-23-016653:mdna:113]
•global economic conditions which affect demand for our products and services and impact the financial stability of our suppliers and customers, including the impact of uncertainty in the banking and financial services industries as well as COVID-19;

[0001628280-23-016653:mdna:114]
[same as prior period, unchanged from 0001628280-23-002880:mdna:118]

[0001628280-23-016653:mdna:115]
[same as prior period, unchanged from 0001628280-23-002880:mdna:119]

[0001628280-23-016653:mdna:116]
[same as prior period, unchanged from 0001628280-23-002880:mdna:120]

[0001628280-23-016653:mdna:117]
[same as prior period, unchanged from 0001628280-23-002880:mdna:121]

[0001628280-23-016653:mdna:118]
[same as prior period, unchanged from 0001628280-23-002880:mdna:122]

[0001628280-23-016653:mdna:119]
[same as prior period, unchanged from 0001628280-23-002880:mdna:123]

[0001628280-23-016653:mdna:120]
•cost and availability of credit, which may impact available financing for us, our customers or others with whom we do business;

[0001628280-23-016653:mdna:121]
[same as prior period, unchanged from 0001628280-23-002880:mdna:124]

[0001628280-23-016653:mdna:122]
[same as prior period, unchanged from 0001628280-23-002880:mdna:125]

[0001628280-23-016653:mdna:123]
[same as prior period, unchanged from 0001628280-23-002880:mdna:126]

[0001628280-23-016653:mdna:124]
[same as prior period, unchanged from 0001628280-23-002880:mdna:127]

[0001628280-23-016653:mdna:125]
[same as prior period, unchanged from 0001628280-23-002880:mdna:128]

[0001628280-23-016653:mdna:126]
[same as prior period, unchanged from 0001628280-23-002880:mdna:129]

[0001628280-23-016653:mdna:127]
•common stock repurchases under the share buyback program.

[0001628280-23-016653:mdna:128]
[same as prior period, unchanged from 0001628280-23-002880:mdna:131]

[0001628280-23-016653:mdna:129]
The following table summarizes certain of our contractual obligations as of April 1, 2023, and the effect such obligations are expected to have on our liquidity and cash flow over the next five years (in millions):

[0001628280-23-016653:mdna:130]
|  | Payments due by period |
|  | Total |  | Less than 1 year |  | More than 1 year |  |  |  |  |
| Contractual Obligations |  |  |  |  |  |  |  |  |  |
| Asset retirement obligations | $ | 8.2 |  |  | $ | — |  |  | $ | 8.2 |  |  |  |  |  |
| Operating lease liabilities, including imputed interest (1) | 74.4 |  |  | 16.4 |  |  | 58.0 |  |  |  |  |  |
| Pension plan contributions (2) | 1.4 |  |  | 1.4 |  |  | — |  |  |  |  |  |
| Purchase obligations (3) | 379.2 |  |  | 352.1 |  |  | 27.1 |  |  |  |  |  |
| Convertible notes - principal (4) | 2,359.1 |  |  | 448.1 |  |  | 1,911.0 |  |  |  |  |  |
| Convertible notes - interest (4) | 45.9 |  |  | 10.8 |  |  | 35.1 |  |  |  |  |  |
| Total | $ | 2,868.2 |  |  | $ | 828.8 |  |  | $ | 2,039.4 |  |  |  |  |  |

[0001628280-23-016653:mdna:131]
(1) The amounts of operating lease liabilities in the table above do not include any sublease income amounts nor do they include payments for short-term leases or variable lease payments. As of April 1, 2023, we expect to receive sublease income of approximately $4.5 million over the sublease periods.

[0001628280-23-016653:mdna:132]
[same as prior period, unchanged from 0001628280-23-002880:mdna:135]

[0001628280-23-016653:mdna:133]
(3) Purchase obligations represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Refer to “Note 14. Commitments and Contingencies” in the notes to condensed consolidated financial statements.

[0001628280-23-016653:mdna:134]
[same as prior period, unchanged from 0001628280-23-002880:mdna:137]

[0001628280-23-016653:mdna:135]
We do not have any off-balance sheet arrangements, as such term is defined in rules promulgated by the SEC, which have or are reasonably likely to have a current or future effect on our liquidity or capital resources that are material to investors.

[0001628280-23-016653:mdna:136]
[same as prior period, unchanged from 0001628280-23-002880:mdna:139]

[0001628280-23-016653:mdna:137]
As of April 1, 2023, our 2024 Notes of $426.2 million (which have an aggregate principal amount of $448.1 million outstanding that matures in 2024) is presented in current liabilities in our condensed consolidated balance sheets, as the debt will mature on March 15, 2024. During the three and nine months ended April 1, 2023, we received conversion requests of less than $0.1 million principal amount of the 2024 Notes, which we settled with cash in accordance with the 2024 Indenture. Since issuing the 2024 Notes, we have converted a total of approximately $1.9 million principal amount of the 2024 Notes.

[0001628280-23-016653:mdna:138]
As of April 1, 2023, our 2026 Notes of $1,045.6 million (which have an aggregate principal amount of $1,050.0 million outstanding that matures in 2026) is presented in non-current liabilities in our condensed consolidated balance sheets. If the closing price of our stock exceeds $129.08 for 20 of the last 30 trading days of any future quarter, our 2026 Notes would become convertible at the option of the holders during the subsequent fiscal quarter and the debt would be reclassified to current liabilities in our condensed consolidated balance sheet.

[0001628280-23-016653:mdna:139]
As of April 1, 2023, our 2028 Notes of $855.2 million (which have an aggregate principal amount of $861.0 million outstanding that matures in 2028) is presented in non-current liabilities in our condensed consolidated balance sheets. If the closing price of our stock exceeds $170.34 for 20 of the last 30 trading days of any future quarter, our 2028 Notes would become convertible at the option of the holders during the subsequent fiscal quarter and the debt would be reclassified to current liabilities in our condensed consolidated balance sheet.

[0001628280-23-016653:mdna:140]
As of April 1, 2023, we paid all of the outstanding term loans that we assumed in connection with our merger with NeoPhotonics for $5.9 million.

[0001628280-23-016653:mdna:141]
[same as prior period, unchanged from 0001628280-23-002880:mdna:144]

[0001628280-23-016653:mdna:142]
On May 7, 2021, our board of directors approved the 2021 share buyback program, which authorizes us to use up to $700.0 million to purchase our own shares of common stock. On March 3, 2022, our board of directors approved an increase in our share buyback program, which authorizes us to use up to an aggregate amount of $1.0 billion (an increase from $700.0 million) to purchase our own shares of common stock through May 2024.  On April 5, 2023, our board of directors approved a further increase in our share buyback program, which authorizes us to utilize up to an aggregate amount of  $1.2 billion (an increase from $1.0 billion) to purchase our own shares of common stock through May 2025 but may be suspended or terminated by the board of directors at any time.

[0001628280-23-016653:mdna:143]
During the nine months ended April 1, 2023, we repurchased 0.3 million shares of our common stock at an average price of $89.80 per share for an aggregate purchase price of $25.7 million.

[0001628280-23-016653:mdna:144]
[same as prior period, unchanged from 0001628280-23-002880:mdna:147]

[0001628280-23-016653:mdna:145]
[same as prior period, unchanged from 0001628280-23-002880:mdna:148]

[0001628280-23-016653:mdna:146]
[same as prior period, unchanged from 0001628280-23-002880:mdna:149]

[0001628280-23-016653:mdna:147]
As of April 1, 2023, our other non-current liabilities also include $50.4 million of unrecognized tax benefit for uncertain tax positions. We are unable to reliably estimate the timing of future payments related to uncertain tax positions.

[0001628280-23-016653:mdna:148]
[same as prior period, unchanged from 0001628280-23-002880:mdna:151]

[0001628280-23-016653:mdna:149]
Our balance of cash and cash equivalents decreased by $741.0 million, from $1,290.2 million as of July 2, 2022 to $549.2 million as of April 1, 2023. The decrease in cash and cash equivalents during the nine months ended April 1, 2023 was due to cash used in investing activities of $803.1 million and financing activities of $68.5 million, partially offset by cash provided by operating activities of $130.6 million.

[0001628280-23-016653:mdna:150]
[same as prior period, unchanged from 0001628280-23-002880:mdna:153]

[0001628280-23-016653:mdna:151]
Cash provided by operating activities was $130.6 million during the nine months ended April 1, 2023, which reflects a net loss of $71.4 million and non-cash items of $346.5 million for the nine months ended April 1, 2023, offset by $144.5 million changes in our operating assets and liabilities. Changes in our operating assets and liabilities is mainly driven an increase in inventories of $80.6 million, a decrease in accounts payable of $44.3 million, offset by a decrease in accounts receivable of $51.0 million.

[0001628280-23-016653:mdna:152]
Cash provided by operating activities was $345.0 million during the nine months ended April 2, 2022, which reflects net income of $164.2 million and non-cash items of $254.7 million for the nine months ended April 2, 2022, offset by $73.9 million change in operating assets and liabilities. Changes in our operating assets and liabilities related primarily to an increase in accounts receivable of $29.4 million, an increase in inventories of $26.5 million, and a decrease in income tax, net of $20.2 million.

[0001628280-23-016653:mdna:153]
[same as prior period, unchanged from 0001628280-23-002880:mdna:156]

[0001628280-23-016653:mdna:154]
Cash used in investing activities of $803.1 million during the nine months ended April 1, 2023 was attributable to the acquisition of NeoPhotonics and IPG product lines in the amount of $861.6 million, net of cash acquired, and capital expenditures of $92.2 million, partially offset by net proceeds from sales or maturities of short-term investments of $150.6 million.

[0001628280-23-016653:mdna:155]
Cash used in investing activities of $369.0 million during the nine months ended April 2, 2022 was attributable to purchases of short-term investments, net of sales and maturities of $282.8 million, capital expenditures of $62.6 million, and a $30.0 million term loan provided to NeoPhotonics to support their on-going growth plans through the anticipated merger completion, partially offset by proceeds from the sales of property, plant and equipment of $6.4 million. The term loan to NeoPhotonics is described in “Note 4. Business Combinations”.

[0001628280-23-016653:mdna:156]
[same as prior period, unchanged from 0001628280-23-002880:mdna:159]

[0001628280-23-016653:mdna:157]
Cash used in financing activities of $68.5 million during the nine months ended April 1, 2023 was driven by the repurchase of shares of our common stock of $35.8 million, tax payments related to net share settlement of restricted stock of $33.4 million, and $5.9 million repayments for all the term loans that we assumed in connection with our merger with NeoPhotonics, offset by $6.6 million proceeds from employee stock plans.

[0001628280-23-016653:mdna:158]
Cash provided by financing activities of $380.0 million during the nine months ended April 2, 2022 resulted from the proceeds from the issuance of the 2028 Notes, net of issuance costs of $854.8 million and proceeds from employee stock plans of $6.6 million, partially offset by the repurchase of shares of our common stock of $448.6 million and tax payments related to net share settlement of restricted stock of $32.8 million.
