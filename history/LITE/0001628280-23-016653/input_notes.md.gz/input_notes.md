# LITE notes — 0001628280-23-016653


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001628280-23-016653:notes:1]
[same as prior period, unchanged from 0001628280-23-002880:notes:1]

[0001628280-23-016653:notes:2]
[same as prior period, unchanged from 0001628280-23-002880:notes:2]

[0001628280-23-016653:notes:3]
Lumentum Holdings Inc. (“we,” “us,” “our”, “Lumentum” or the “Company”) is an industry-leading provider of optical and photonic products addressing a range of end market applications including Optical Communications (“OpComms”) and Commercial Lasers (“Lasers”) for manufacturing, inspection, and life-science applications. We seek to use our core optical and photonic technology and our volume manufacturing capability to expand into attractive emerging markets that benefit from advantages that optical or photonics-based solutions provide, including imaging and sensing for consumer electronics and diode light sources for a variety of consumer and industrial applications. The majority of our customers have historically been, and are currently, original equipment manufacturers (“OEMs”) that incorporate our products into their products, which then address end-market applications. For example, we sell fiber optic components that network equipment manufacturers (“NEMs”) assemble into communications networking systems, which they sell to communications service providers, hyperscale cloud operators, and enterprises with their own networks. Similarly, many of our Lasers products customers incorporate our products into tools they produce, which are used for manufacturing processes by their customers. For imaging and sensing, we sell diode lasers to manufacturers of consumer electronics products for mobile, personal computing, gaming, and other applications, including to the automotive industry, who then integrate our devices within their products, for eventual resale to consumers and also into other industrial applications.

[0001628280-23-016653:notes:4]
[same as prior period, unchanged from 0001628280-23-002880:notes:4]

[0001628280-23-016653:notes:5]
We have prepared the accompanying condensed consolidated financial statements in accordance with U.S. generally accepted accounting principles (“GAAP”), which requires management to make estimates and assumptions that affect the amounts reported in our condensed consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact us in the future, actual results may be different from the estimates. Our interim period operating results do not necessarily indicate the results that may be expected for any other interim period or for the full fiscal year.  In the opinion of the Company’s management, the information presented herein reflects all normal and recurring adjustments necessary for a fair presentation of our results of operations, financial position, stockholders’ equity, and cash flows. Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective, or complex judgments by management. Those policies are inventory valuation, revenue recognition, income taxes, goodwill, and business combinations.

[0001628280-23-016653:notes:6]
Our business and operating results depend significantly on general market and economic conditions. The current global macroeconomic environment is volatile and continues to be adversely impacted by inflation, and a dynamic supply chain and demand environment, and signs of a weaker macroeconomic environment impacting capital expenditures across our served markets. Additionally, instability in the global credit markets, the impact of uncertainty regarding global central bank monetary policy, capital expenditure reductions, unemployment and other labor issues, decline in stock markets, the instability in the geopolitical environment in many parts of the world, and the current global economic challenges continue to put pressure on our business and operating results.

[0001628280-23-016653:notes:7]
While the impact of the COVID-19 pandemic is lessening, the duration and severity of the impact of the pandemic on our business and results of operations in future periods remain uncertain. The extent of the impact of COVID-19 on our operational and financial performance will depend on certain developments, including but not limited to the duration and spread of the pandemic and its variants in geographies where we do business, implementation and duration of local, state and federal issued public health orders in each jurisdiction where we operate or our customers and suppliers operate, impact on our customers and our sales cycles, impact on our supply chain and manufacturing partners, impact on our employees, and impact on regional and worldwide economies and financial markets in general, all of which are uncertain and not predictable. We assessed the potential impact that this pandemic has on our estimates as of April 1, 2023 and determined that there were no material impacts. However, due to the global supply chain constraint, we have had to incur incremental supply and procurement costs in order to fulfill demand from our customers.  As of April 1, 2023, our inventory balance includes $10.8 million of incremental supply and procurement costs.

[0001628280-23-016653:notes:8]
We are also continuously monitoring the current developments in the ongoing war between Russia and Ukraine including the related export controls and resulting sanctions imposed on Russia by the U.S. and other countries. Additional factors such as increased inflation, escalating energy costs, constrained raw material availability, and related cost increases could continue to impact the global economy and our business. Although the global implications of the Russian and Ukraine war are difficult to predict at this time, we do not presently foresee direct material adverse effects on our business.

[0001628280-23-016653:notes:9]
[same as prior period, unchanged from 0001628280-23-002880:notes:9]

[0001628280-23-016653:notes:10]
On August 3, 2022, we completed a merger with NeoPhotonics Corporation (“NeoPhotonics”). Our condensed consolidated financial statements include the operating results of NeoPhotonics for the period from the date of the closing of the merger through April 1, 2023. We have applied the acquisition method of accounting in accordance with Accounting Standards Codification (“ASC”) Topic 805, Business Combinations to account for this transaction. Refer to “Note 4. Business Combinations” for further discussion of the merger.

[0001628280-23-016653:notes:11]
On August 15, 2022, we completed a transaction to acquire IPG Photonics’ telecom transmission product lines. Our condensed consolidated financial statements include the operating results of this business unit for the period from the date of the acquisition through April 1, 2023. We have applied the acquisition method of accounting in accordance with ASC Topic 805, Business Combinations to account for this transaction. Refer to “Note 4. Business Combinations” for further discussion of this acquisition.

[0001628280-23-016653:notes:12]
[same as prior period, unchanged from 0001628280-23-002880:notes:12]

[0001628280-23-016653:notes:13]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Every fifth or sixth fiscal year will have a 53-week period. The additional week in a 53-week year is added to the third quarter, making such quarter consist of 14 weeks. Our fiscal 2023 is a 52-week year ending on July 1, 2023, with the quarter ended April 1, 2023 being a 13-week quarterly period. Our fiscal 2022 was a 52-week year that ended on July 2, 2022, with the quarter ended April 2, 2022 being a 13-week quarterly period.

[0001628280-23-016653:notes:14]
[same as prior period, unchanged from 0001628280-23-002880:notes:14]

[0001628280-23-016653:notes:15]
The condensed consolidated financial statements include the accounts of Lumentum Holdings Inc. and its wholly-owned subsidiaries. All inter-company transactions and balances are eliminated in consolidation.

[0001628280-23-016653:notes:16]
[same as prior period, unchanged from 0001628280-23-002880:notes:17]

[0001628280-23-016653:notes:17]
The condensed consolidated financial statements and accompanying notes should be read in conjunction with the audited consolidated financial statements and accompanying notes included in our Annual Report on Form 10-K for the fiscal year ended July 2, 2022. 
Except for the accounting policies for convertible instruments as a result of our adoption of Accounting Standards Update (“ASU”) 2020-06, Debt—Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging—Contracts in Entity’s Own Equity (Subtopic 815-40): Accounting for Convertible Instruments and Contracts in an Entity’s Own Equity, described in “Note 2. Recently Issued Accounting Pronouncements”, there have been no significant changes to our accounting policies during the three and nine months ended April 1, 2023.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001628280-23-016653:notes:18]
Note 2. Recently Issued Accounting Pronouncements

[0001628280-23-016653:notes:19]
Accounting Pronouncements Recently Adopted

[0001628280-23-016653:notes:20]
In October 2021, the Financial Accounting Standards Board (“FASB”) issued ASU 2021-08, Business Combinations (Topic 805)—Accounting for Contract Assets and Contract Liabilities from Contracts with Customers. This ASU clarifies that an acquirer of a business should recognize and measure contract assets and contract liabilities in a business combination in accordance with ASC Topic 606, Revenue from Contracts with Customers. This ASU is expected to improve comparability for both recognition and measurement of acquired revenue contracts with customers at the date of and after a business combination. The new guidance is effective for fiscal years beginning after December 15, 2022, with early adoption permitted. We early adopted the new standard in the first quarter of fiscal 2023 in connection with the merger with NeoPhotonics. There was no material impact to our condensed consolidated financial statements as of and for the three and nine months ended April 1, 2023 .

[0001628280-23-016653:notes:21]
In August 2020, the FASB issued ASU 2020-06, Debt—Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging—Contracts in Entity’s Own Equity (Subtopic 815-40): Accounting for Convertible Instruments and Contracts in an Entity’s Own Equity, which simplifies the accounting for convertible instruments by removing the separation models for (i) convertible debt with a cash conversion feature and (ii) convertible instruments with a beneficial conversion feature. As a result, a convertible debt instrument is accounted for as a single liability measured at its amortized cost. ASU 2020-06 also requires the application of the if-converted method for calculating diluted earnings per share. We adopted the standard as of July 3, 2022, using the modified retrospective approach. Upon adoption, our 2026 Notes and 2028 Notes were accounted for as a single liability measured at amortized cost, resulting in: (i) an increase to the convertible notes liability balance of $433.0 million to reflect the full principal amount of the convertible notes outstanding, net of issuance costs; (ii) a reduction to additional paid-in capital, net of estimated income tax effects, of $426.5 million, to remove the equity component separately recorded for the conversion features associated with the convertible notes; (iii) an increase to deferred tax assets, net of $92.1 million; and (iv) a cumulative-effect adjustment of $85.6 million, net of estimated income tax effects, to decrease the accumulated deficit. In addition, the adoption requires the use of the if-converted method for all convertible notes in the diluted net income per share calculation and the inclusion of the effect of potential share settlement of the convertible notes, if the effect is more dilutive. There was no impact to diluted earnings per share for the three and nine months ended April 1, 2023, as the inclusion of potential shares of common stock related to the convertible notes was anti-dilutive. Refer to “Note 9. Debt” for further information.

[0001628280-23-016653:notes:22]
The following table sets forth the impact upon adoption of ASU 2020-06 as of July 3, 2022 (in millions):

[0001628280-23-016653:notes:23]
|  |  | Short Term Debt - 2024 Notes |  | Long Term Debt - 2026 Notes |  | Long Term Debt - 2028 Notes |  | Additional Paid-In Capital |  | Accumulated Deficit |  | Deferred Tax Asset (Liability), net |
| Balances pre-adoption of ASC 2020-06 |  | $ | 409.9 |  |  | $ | 831.4 |  |  | $ | 634.7 |  |  | $ | 2,003.6 |  |  | $ | 129.1 |  |  | $ | 12.9 |  |
| Reclassify amounts from equity to debt |  | — |  |  | 312.9 |  |  | 229.3 |  |  | (542.2) |  |  | — |  |  | — |  |
| Adjustment for interest accretion |  | — |  |  | (99.5) |  |  | (9.7) |  |  | — |  |  | (109.2) |  |  | — |  |
| Tax effect |  | — |  |  | — |  |  | — |  |  | 115.7 |  |  | 23.6 |  |  | 92.1 |  |
| Balances upon adoption of ASC 2020-06 |  | $ | 409.9 |  |  | $ | 1,044.8 |  |  | $ | 854.3 |  |  | $ | 1,577.1 |  |  | $ | 43.5 |  |  | $ | 105.0 |  |


## us-gaap:EarningsPerShareTextBlock

[0001628280-23-016653:notes:24]
[same as prior period, unchanged from 0001628280-23-002880:notes:25]

[0001628280-23-016653:notes:25]
[same as prior period, unchanged from 0001628280-23-002880:notes:26]

[0001628280-23-016653:notes:26]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 1, 2023 |  | April 2, 2022 |  | April 1, 2023 |  | April 2, 2022 |
| Numerator: |  |  |  |  |  |  |  |
| Net income (loss) - basic and diluted | $ | (39.3) |  |  | $ | 26.0 |  |  | $ | (71.4) |  |  | $ | 164.2 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted average common shares outstanding - basic | 68.6 |  |  | 71.0 |  |  | 68.3 |  |  | 72.0 |  |
| Effect of dilutive securities from stock-based benefit plans | — |  |  | 0.7 |  |  | — |  |  | 0.6 |  |
| Shares issuable assuming conversion of the convertible notes | — |  |  | 2.8 |  |  | — |  |  | 2.5 |  |
| Weighted average common shares outstanding - diluted | 68.6 |  |  | 74.5 |  |  | 68.3 |  |  | 75.1 |  |
| Net income (loss) per share: |  |  |  |  |  |  |  |
| Basic | $ | (0.57) |  |  | $ | 0.37 |  |  | $ | (1.05) |  |  | $ | 2.28 |  |
| Diluted | $ | (0.57) |  |  | $ | 0.35 |  |  | $ | (1.05) |  |  | $ | 2.19 |  |

[0001628280-23-016653:notes:27]
Shares from stock-based benefit plans and shares issuable assuming conversion of our convertible notes are anti-dilutive for the three and nine months ended April 1, 2023 and are therefore excluded from the calculation of diluted net income (loss) per share as the Company had a net loss for both periods.

[0001628280-23-016653:notes:28]
Anti-dilutive shares excluded from the calculation of diluted net income (loss) per share for the three months ended April 1, 2023 mainly include 24.5 million shares related to the convertible notes, 3.5 million shares issuable under restricted stock units (“RSUs”) and performance stock units (“PSUs”), and 0.1 million shares issuable under the Employee Stock Purchase Plan (the “2015 Purchase Plan”). Average anti-dilutive shares excluded from the calculation of diluted net income (loss) per share for the nine months ended April 1, 2023 include 24.5 million shares related to the convertible notes, 3.8 million shares issuable under RSUs and PSUs, and 0.1 million shares issuable under the 2015 Purchase Plan. Refer to “Note 13. Equity.”

[0001628280-23-016653:notes:29]
Anti-dilutive shares excluded from the calculation of diluted net income (loss) per share were less than 0.1 million for each of the three and nine months ended April 2, 2022, respectively.

[0001628280-23-016653:notes:30]
As a result of our adoption of ASU 2020-06 in the first quarter of fiscal 2023, potentially dilutive common shares issuable upon conversion of our outstanding 2024 Notes, 2026 Notes and 2028 Notes (collectively referred to as the “convertible notes”)  are determined using the if-converted method. For periods prior to the adoption of ASU 2020-06, which include the three and nine months ended April 2, 2022, our potentially dilutive common shares issuable upon conversion of our outstanding convertible notes are determined using the treasury stock method.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001628280-23-016653:notes:31]
[same as prior period, unchanged from 0001628280-23-002880:notes:31]

[0001628280-23-016653:notes:32]
[same as prior period, unchanged from 0001628280-23-002880:notes:32]

[0001628280-23-016653:notes:33]
[same as prior period, unchanged from 0001628280-23-002880:notes:33]

[0001628280-23-016653:notes:34]
[same as prior period, unchanged from 0001628280-23-002880:notes:34]

[0001628280-23-016653:notes:35]
[same as prior period, unchanged from 0001628280-23-002880:notes:35]

[0001628280-23-016653:notes:36]
[same as prior period, unchanged from 0001628280-23-002880:notes:36]

[0001628280-23-016653:notes:37]
[same as prior period, unchanged from 0001628280-23-002880:notes:37]

[0001628280-23-016653:notes:38]
[same as prior period, unchanged from 0001628280-23-002880:notes:38]

[0001628280-23-016653:notes:39]
The total transaction consideration of $934.4 million was funded by the cash balances of the combined company. We also recorded $24.2 million of merger-related costs, representing professional and other direct acquisition costs. Of the $24.2 million of merger-related costs, $8.3 million was incurred in fiscal year 2022, and $2.1 million and $15.9 million was incurred during the three and nine months ended April 1, 2023, respectively, which was recorded as selling, general and administrative expense in the condensed consolidated statements of operations.

[0001628280-23-016653:notes:40]
[same as prior period, unchanged from 0001628280-23-002880:notes:40]

[0001628280-23-016653:notes:41]
|  | Fair Value |
| Total purchase price consideration | $ | 934.4 |  |
| Assets acquired |  |
| Cash and cash equivalents | $ | 92.9 |  |
| Accounts receivable, net | 66.8 |  |
| Inventories | 84.3 |  |
| Prepayments and other current assets | 24.2 |  |
| Property, plant and equipment, net | 106.1 |  |
| Operating lease right-of-use assets, net | 16.9 |  |
| Other intangible assets, net (1) | 412.5 |  |
| Other non-current assets | 1.9 |  |
| Total assets | 805.6 |  |
| Liabilities assumed |  |
| Accounts payable | 79.6 |  |
| Accrued payroll and related expenses | 11.1 |  |
| Accrued expenses | 3.8 |  |
| Other current liabilities | 10.6 |  |
| Operating lease liabilities, current | 2.8 |  |
| Operating lease liabilities, non-current | 13.2 |  |
| Deferred tax liability | 38.3 |  |
| Other non-current liabilities | 28.2 |  |
| Total liabilities | 187.6 |  |
| Goodwill | $ | 316.4 |  |

[0001628280-23-016653:notes:42]
[same as prior period, unchanged from 0001628280-23-002880:notes:42]

[0001628280-23-016653:notes:43]
[same as prior period, unchanged from 0001628280-23-002880:notes:43]

[0001628280-23-016653:notes:44]
Goodwill has been assigned to the OpComms segment. The preliminary goodwill of $316.4 million arising from the acquisition is attributed to the expected synergies, including future cost efficiencies and other benefits that are expected to be generated by combining Lumentum and NeoPhotonics. None of the goodwill is expected to be deductible for local tax purposes.  Refer to “Note 8. Goodwill and Other Intangible Assets.”

[0001628280-23-016653:notes:45]
From the Closing date, NeoPhotonics contributed $73.0 million and $250.4 million of our consolidated net revenue for the three and nine months ended April 1, 2023, respectively. Due to the continued integration of the combined businesses, as well as our corporate structure and the allocation of selling, general and administrative costs, it is impracticable to determine NeoPhotonics’ contribution to our earnings.

[0001628280-23-016653:notes:46]
[same as prior period, unchanged from 0001628280-23-002880:notes:46]

[0001628280-23-016653:notes:47]
The following supplemental pro forma information presents the combined results of operations for the three and nine months ended April 1, 2023 and April 2, 2022, respectively, as if the merger was completed at the first day of fiscal 2022. The supplemental pro forma financial information presented below is not necessarily indicative of the financial position or results of operations that would have been realized if the acquisition had been completed on the date indicated. The supplemental pro forma financial information does not reflect synergies that might have been achieved, nor is it indicative of future operating results or financial position.

[0001628280-23-016653:notes:48]
[same as prior period, unchanged from 0001628280-23-002880:notes:48]

[0001628280-23-016653:notes:49]
[same as prior period, unchanged from 0001628280-23-002880:notes:49]

[0001628280-23-016653:notes:50]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 1, 2023 |  | April 2, 2022 |  | April 1, 2023 |  | April 2, 2022 |
| Net revenue | $ | 383.4 |  |  | $ | 484.7 |  |  | $ | 1,420.1 |  |  | $ | 1,544.1 |  |
| Net income (loss) | (35.9) |  |  | 3.6 |  |  | (29.3) |  |  | 48.6 |  |

[0001628280-23-016653:notes:51]
[same as prior period, unchanged from 0001628280-23-002880:notes:51]

[0001628280-23-016653:notes:52]
[same as prior period, unchanged from 0001628280-23-002880:notes:52]

[0001628280-23-016653:notes:53]
We have applied the acquisition method of accounting in accordance with ASC Topic 805, Business Combinations to account for this transaction. The total purchase price of $55.9 million was paid in cash. Our preliminary allocation of the purchase price consideration includes $29.1 million of in process research and development (“IPR&D”), $8.6 million of developed technology, $2.3 million of customer relationships, and $5.0 million of other net assets and liabilities, resulting in preliminary goodwill of $10.9 million. The allocation of the purchase price to the assets acquired and liabilities assumed, including the residual amount allocated to goodwill, is based upon preliminary information and adjustments may result before the end of the measurement period, which ends one year from the IPG Closing date.

[0001628280-23-016653:notes:54]
We incurred $0.1 million and $1.6 million of transaction costs, respectively, during the three and nine months ended April 1, 2023, which was recorded as selling, general and administrative expense in the condensed consolidated statements of operations.

[0001628280-23-016653:notes:55]
[same as prior period, unchanged from 0001628280-23-002880:notes:55]


## us-gaap:CashCashEquivalentsAndShortTermInvestmentsTextBlock

[0001628280-23-016653:notes:56]
[same as prior period, unchanged from 0001628280-23-002880:notes:56]

[0001628280-23-016653:notes:57]
[same as prior period, unchanged from 0001628280-23-002880:notes:57]

[0001628280-23-016653:notes:58]
|  | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| April 1, 2023: |  |  |  |  |  |  |  |
| Cash | $ | 257.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 257.5 |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | 17.6 |  |  | — |  |  | — |  |  | 17.6 |  |
| Money market funds | 246.1 |  |  | — |  |  | — |  |  | 246.1 |  |
| U.S. Treasury securities | 28.0 |  |  | — |  |  | — |  |  | 28.0 |  |
| Total cash and cash equivalents | $ | 549.2 |  |  | $ | — |  |  | $ | — |  |  | $ | 549.2 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 28.9 |  |  | $ | — |  |  | $ | — |  |  | $ | 28.9 |  |
| Commercial paper | 112.9 |  |  | — |  |  | (0.2) |  |  | 112.7 |  |
| Corporate debt securities | 429.7 |  |  | 0.2 |  |  | (3.0) |  |  | 426.9 |  |
| Foreign government bonds | 1.4 |  |  | — |  |  | — |  |  | 1.4 |  |
| U.S. Agency securities | 204.9 |  |  | 0.1 |  |  | (1.0) |  |  | 204.0 |  |
| U.S. Treasury securities | 345.1 |  |  | 0.3 |  |  | (1.3) |  |  | 344.1 |  |
| Total short-term investments | $ | 1,122.9 |  |  | $ | 0.6 |  |  | $ | (5.5) |  |  | $ | 1,118.0 |  |
| July 2, 2022: |  |  |  |  |  |  |  |
| Cash | $ | 235.9 |  |  | $ | — |  |  | $ | — |  |  | $ | 235.9 |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | 23.6 |  |  | — |  |  | — |  |  | 23.6 |  |
| Money market funds | 1,000.2 |  |  | — |  |  | — |  |  | 1,000.2 |  |
| U.S. Agency securities | 8.0 |  |  | — |  |  | — |  |  | 8.0 |  |
| U.S. Treasury securities | 22.5 |  |  |  |  | — |  |  | 22.5 |  |
| Total cash and cash equivalents | $ | 1,290.2 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,290.2 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 28.3 |  |  | $ | — |  |  | $ | — |  |  | $ | 28.3 |  |
| Commercial paper | 107.4 |  |  | — |  |  | (0.4) |  |  | 107.0 |  |
| Corporate debt securities | 539.9 |  |  |  |  | (7.4) |  |  | 532.5 |  |
| Municipal bonds | 1.0 |  |  | — |  |  | — |  |  | 1.0 |  |
| U.S. Agency securities | 67.1 |  |  | — |  |  | (1.4) |  |  | 65.7 |  |
| U.S. Treasury securities | 528.2 |  |  | 0.3 |  |  | (4.2) |  |  | 524.3 |  |
| Total short-term investments | $ | 1,271.9 |  |  | $ | 0.3 |  |  | $ | (13.4) |  |  | $ | 1,258.8 |  |

[0001628280-23-016653:notes:59]
We review our investment portfolio to identify and evaluate investments that have indicators of possible impairment. Factors considered in determining whether a loss is other-than-temporary include, but are not limited to, the length of time and extent a security’s fair value has been below its cost, the financial condition and near-term prospects of the investee, the credit quality of the security’s issuer, likelihood of recovery, and our intent and ability to hold the security for a period of time sufficient to allow for any anticipated recovery in value. For the debt instruments we own, we also evaluate whether we have the intent to sell the security or whether it is more likely than not that we will be required to sell the security before recovery of its cost basis. We have not recorded our unrealized losses on our short-term investments into income because we do not intend to sell nor is it more likely than not that we will be required to sell these investments prior to recovery of their amortized cost basis.

[0001628280-23-016653:notes:60]
We use the specific-identification method to determine any realized gains or losses from the sale of our short-term investments classified as available-for-sale. During the three and nine months ended April 1, 2023, we did not realize significant gains or losses on a gross level from the sale of our short-term investments classified as available-for-sale.

[0001628280-23-016653:notes:61]
During the three and nine months ended April 1, 2023, our other income, net was $11.4 million and $28.9 million, respectively, which includes interest and investment income on cash equivalents and short-term investments of $11.9 million and $24.4 million, respectively. During the three and nine months ended April 2, 2022, our other income, net was $2.2 million and $3.8 million, respectively, which includes interest and investment income on cash equivalents and short-term investments of $1.1 million and $2.3 million, respectively.

[0001628280-23-016653:notes:62]
As of April 1, 2023 and July 2, 2022, we recorded interest receivables of $6.6 million and $3.9 million, respectively, in prepayments and other current assets within the condensed consolidated balance sheets. We did not recognize an allowance for credit losses against interest receivables in any of the periods presented as there were no such losses.

[0001628280-23-016653:notes:63]
The following table summarizes unrealized losses on our cash equivalents and short-term investments by category that have been in a continuous unrealized loss position for more than 12 months and less than 12 months as of the periods presented, respectively (in millions):

[0001628280-23-016653:notes:64]
|  | Continuous Loss Position For More Than 12 Months |  | Continuous Loss Position For Less Than 12 Months |  | Gross Unrealized Losses |  |  |  |  |  |  |  |  |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  |  |  |  |  |  |  |  |  |
| April 1, 2023: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | 42.2 |  |  | $ | (0.8) |  |  | $ | 82.9 |  |  | $ | (0.2) |  |  | $ | (1.0) |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | — |  |  | 12.7 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | — |  |  | — |  |  | 112.5 |  |  | (0.2) |  |  | (0.2) |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 153.7 |  |  | (1.8) |  |  | 192.8 |  |  | (1.2) |  |  | (3.0) |  |  |  |  |  |  |  |  |  |
| Foreign government bonds | — |  |  | — |  |  | 1.4 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 90.8 |  |  | (1.0) |  |  | 124.6 |  |  | (0.3) |  |  | (1.3) |  |  |  |  |  |  |  |  |  |
| Total | $ | 286.7 |  |  | $ | (3.6) |  |  | $ | 526.9 |  |  | $ | (1.9) |  |  | $ | (5.5) |  |  |  |  |  |  |  |  |  |
| July 2, 2022: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | — |  |  | $ | — |  |  | $ | 73.7 |  |  | $ | (1.4) |  |  | $ | (1.4) |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | — |  |  | 16.2 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | — |  |  | — |  |  | 130.7 |  |  | (0.4) |  |  | (0.4) |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 57.4 |  |  | (0.9) |  |  | 473.2 |  |  | (6.5) |  |  | (7.4) |  |  |  |  |  |  |  |  |  |
| Municipal bonds | — |  |  | — |  |  | 1.0 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | — |  |  | — |  |  | 366.0 |  |  | (4.2) |  |  | (4.2) |  |  |  |  |  |  |  |  |  |
| Total | $ | 57.4 |  |  | $ | (0.9) |  |  | $ | 1,060.8 |  |  | $ | (12.5) |  |  | $ | (13.4) |  |  |  |  |  |  |  |  |  |

[0001628280-23-016653:notes:65]
[same as prior period, unchanged from 0001628280-23-002880:notes:65]

[0001628280-23-016653:notes:66]
|  | April 1, 2023 |  | July 2, 2022 |
|  | Amortized Cost |  | Fair Value |  | Amortized Cost |  | Fair Value |
| Due in 1 year | $ | 826.2 |  |  | $ | 821.4 |  |  | $ | 1,010.9 |  |  | $ | 1,002.2 |  |
| Due in 1 year through 5 years | 296.7 |  |  | 296.6 |  |  | 261.0 |  |  | 256.6 |  |
|  | $ | 1,122.9 |  |  | $ | 1,118.0 |  |  | $ | 1,271.9 |  |  | $ | 1,258.8 |  |

[0001628280-23-016653:notes:67]
[same as prior period, unchanged from 0001628280-23-002880:notes:67]


## us-gaap:FairValueDisclosuresTextBlock

[0001628280-23-016653:notes:68]
[same as prior period, unchanged from 0001628280-23-002880:notes:68]

[0001628280-23-016653:notes:69]
[same as prior period, unchanged from 0001628280-23-002880:notes:69]

[0001628280-23-016653:notes:70]
[same as prior period, unchanged from 0001628280-23-002880:notes:70]

[0001628280-23-016653:notes:71]
[same as prior period, unchanged from 0001628280-23-002880:notes:71]

[0001628280-23-016653:notes:72]
[same as prior period, unchanged from 0001628280-23-002880:notes:72]

[0001628280-23-016653:notes:73]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| April 1, 2023: (1) |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | — |  |  | $ | 17.6 |  |  | $ | — |  |  | $ | 17.6 |  |
| Money market funds | 246.1 |  |  | — |  |  | — |  |  | 246.1 |  |
| U.S. Treasury securities | 28.0 |  |  | — |  |  | — |  |  | 28.0 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | 28.9 |  |  | — |  |  | 28.9 |  |
| Commercial paper | — |  |  | 112.7 |  |  | — |  |  | 112.7 |  |
| Corporate debt securities | — |  |  | 426.9 |  |  | — |  |  | 426.9 |  |
| Foreign government bonds | — |  |  | 1.4 |  |  | — |  |  | 1.4 |  |
| U.S. Agency securities | — |  |  | 204.0 |  |  | — |  |  | 204.0 |  |
| U.S. Treasury securities | 344.1 |  |  | — |  |  | — |  |  | 344.1 |  |
| Total assets | $ | 618.2 |  |  | $ | 791.5 |  |  | $ | — |  |  | $ | 1,409.7 |  |

[0001628280-23-016653:notes:74]
(1)  Excludes $257.5 million in cash held in our bank accounts as of April 1, 2023.

[0001628280-23-016653:notes:75]
[same as prior period, unchanged from 0001628280-23-002880:notes:75]

[0001628280-23-016653:notes:76]
[same as prior period, unchanged from 0001628280-23-002880:notes:76]

[0001628280-23-016653:notes:77]
[same as prior period, unchanged from 0001628280-23-002880:notes:77]

[0001628280-23-016653:notes:78]
We report our financial instruments at fair value with the exception of the 2028 Notes, 2026 Notes and 2024 Notes. The estimated fair value of the convertible notes was determined based on the trading price of the convertible notes as of the last day of trading for the period. We consider the fair value of the convertible notes to be a Level 2 measurement as they are not actively traded in markets.

[0001628280-23-016653:notes:79]
[same as prior period, unchanged from 0001628280-23-002880:notes:79]

[0001628280-23-016653:notes:80]
|  | April 1, 2023 |  | July 2, 2022 |
|  | Carrying Amount |  | Estimated Fair Value |  | Carrying Amount |  | Estimated Fair Value |
| 2028 Notes | $ | 855.2 |  |  | $ | 660.1 |  |  | $ | 634.7 |  |  | $ | 735.7 |  |
| 2026 Notes | 1,045.6 |  |  | 918.3 |  |  | 831.4 |  |  | 1,065.0 |  |
| 2024 Notes | 426.2 |  |  | 460.5 |  |  | 409.9 |  |  | 614.2 |  |
|  | $ | 2,327.0 |  |  | $ | 2,038.9 |  |  | $ | 1,876.0 |  |  | $ | 2,414.9 |  |

[0001628280-23-016653:notes:81]
[same as prior period, unchanged from 0001628280-23-002880:notes:81]

[0001628280-23-016653:notes:82]
[same as prior period, unchanged from 0001628280-23-002880:notes:82]

[0001628280-23-016653:notes:83]
Management utilizes various valuation methods, including an income approach, a market approach and a cost approach, to estimate the fair value of intangibles and other long-lived assets. During the annual impairment testing performed in the fourth quarter of fiscal 2022, we concluded that our intangible and other long-lived assets were not impaired. We review our intangible and other long-lived assets for impairment at least annually in the fourth quarter of each fiscal year, absent any interim indicators of impairment.  There were no indicators of impairment during the three and nine months ended April 1, 2023.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001628280-23-016653:notes:84]
[same as prior period, unchanged from 0001628280-23-002880:notes:84]

[0001628280-23-016653:notes:85]
[same as prior period, unchanged from 0001628280-23-002880:notes:85]

[0001628280-23-016653:notes:86]
We did not have any allowance for credit losses other than our allowance for uncollectible accounts receivable. As of April 1, 2023 and July 2, 2022, the allowance for credit losses on our trade receivables was less than $0.1 million for both periods.

[0001628280-23-016653:notes:87]
[same as prior period, unchanged from 0001628280-23-002880:notes:87]

[0001628280-23-016653:notes:88]
[same as prior period, unchanged from 0001628280-23-002880:notes:88]

[0001628280-23-016653:notes:89]
|  | April 1, 2023 |  | July 2, 2022 |
| Raw materials and purchased parts | $ | 168.4 |  |  | $ | 98.9 |  |
| Work in process | 122.2 |  |  | 92.2 |  |
| Finished goods | 119.6 |  |  | 59.0 |  |
| Inventories | $ | 410.2 |  |  | $ | 250.1 |  |

[0001628280-23-016653:notes:90]
In connection with the NeoPhotonics merger, we recorded $17.8 million of inventory fair value step-up as of the merger Closing date. During the three and nine months ended April 1, 2023, we recorded an amortization of fair value step-up of $3.6 million and $17.8 million, respectively. As of April 1, 2023, the fair value step-up is fully amortized.

[0001628280-23-016653:notes:91]
[same as prior period, unchanged from 0001628280-23-002880:notes:91]

[0001628280-23-016653:notes:92]
[same as prior period, unchanged from 0001628280-23-002880:notes:92]

[0001628280-23-016653:notes:93]
|  | April 1, 2023 |  | July 2, 2022 |
| Operating lease right-of-use assets | $ | 117.6 |  |  | $ | 102.1 |  |
| Less: accumulated amortization | (36.1) |  |  | (28.5) |  |
| Operating lease right-of-use assets, net | $ | 81.5 |  |  | $ | 73.6 |  |

[0001628280-23-016653:notes:94]
[same as prior period, unchanged from 0001628280-23-002880:notes:94]

[0001628280-23-016653:notes:95]
[same as prior period, unchanged from 0001628280-23-002880:notes:95]

[0001628280-23-016653:notes:96]
[same as prior period, unchanged from 0001628280-23-002880:notes:96]

[0001628280-23-016653:notes:97]
|  | April 1, 2023 |  | July 2, 2022 |
| Land | $ | 63.1 |  |  | $ | 49.7 |  |
| Buildings and improvements | 163.8 |  |  | 105.3 |  |
| Machinery and equipment | 648.2 |  |  | 548.8 |  |
| Computer equipment and software | 40.7 |  |  | 31.3 |  |
| Furniture and fixtures | 10.1 |  |  | 8.9 |  |
| Leasehold improvements | 46.6 |  |  | 35.7 |  |
| Construction in progress | 59.3 |  |  | 47.0 |  |
|  | 1,031.8 |  |  | 826.7 |  |
| Less: Accumulated depreciation | (548.9) |  |  | (466.2) |  |
| Property, plant and equipment, net | $ | 482.9 |  |  | $ | 360.5 |  |

[0001628280-23-016653:notes:98]
[same as prior period, unchanged from 0001628280-23-002880:notes:98]

[0001628280-23-016653:notes:99]
[same as prior period, unchanged from 0001628280-23-002880:notes:99]

[0001628280-23-016653:notes:100]
During the three and nine months ended April 1, 2023, we recorded depreciation expense of $27.7 million and $78.6 million, respectively. During the three and nine months ended April 2, 2022, we recorded depreciation expense of $20.2 million and $61.2 million, respectively.

[0001628280-23-016653:notes:101]
[same as prior period, unchanged from 0001628280-23-002880:notes:101]

[0001628280-23-016653:notes:102]
[same as prior period, unchanged from 0001628280-23-002880:notes:102]

[0001628280-23-016653:notes:103]
|  | April 1, 2023 |  | July 2, 2022 |
| Restructuring accrual and related charges (1) | $ | 4.2 |  |  | $ | — |  |
| Warranty accrual | 6.8 |  |  | 10.0 |  |
| Deferred revenue and customer deposits | 3.4 |  |  | — |  |
| Income tax payable (2) | 7.6 |  |  | 26.0 |  |
| Other current liabilities | 7.0 |  |  | 3.4 |  |
| Other current liabilities | $ | 29.0 |  |  | $ | 39.4 |  |

[0001628280-23-016653:notes:104]
[same as prior period, unchanged from 0001628280-23-002880:notes:104]

[0001628280-23-016653:notes:105]
[same as prior period, unchanged from 0001628280-23-002880:notes:105]

[0001628280-23-016653:notes:106]
[same as prior period, unchanged from 0001628280-23-002880:notes:106]

[0001628280-23-016653:notes:107]
[same as prior period, unchanged from 0001628280-23-002880:notes:107]

[0001628280-23-016653:notes:108]
|  | April 1, 2023 |  | July 2, 2022 |
| Asset retirement obligations | $ | 8.2 |  |  | $ | 4.6 |  |
| Pension and related accruals (1) | 9.7 |  |  | 7.7 |  |
| Unrecognized tax benefit | 50.4 |  |  | 30.5 |  |
| Other non-current liabilities | 7.4 |  |  | 0.1 |  |
| Other non-current liabilities | $ | 75.7 |  |  | $ | 42.9 |  |

[0001628280-23-016653:notes:109]
(1) We have defined benefit pension plans in Japan, Switzerland, and Thailand. In connection with our merger with NeoPhotonics, we assumed an additional defined benefit plan covering employees in Japan. As of April 1, 2023, pension and related accruals in Japan, Switzerland and Thailand were $4.5 million, $0.9 million and $4.3 million, respectively. As of July 2, 2022, pension and related accruals in Japan, Switzerland and Thailand were $2.6 million, $1.7 million and $3.4 million, respectively. We typically re-evaluate the assumptions related to the fair value of our defined benefit obligations annually and make any updates as necessary.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001628280-23-016653:notes:110]
[same as prior period, unchanged from 0001628280-23-002880:notes:110]

[0001628280-23-016653:notes:111]
[same as prior period, unchanged from 0001628280-23-002880:notes:111]

[0001628280-23-016653:notes:112]
In the first quarter of fiscal 2023, we completed two acquisitions, our merger with NeoPhotonics and the acquisition of IPG product lines. We recognized goodwill of $316.4 million related to the NeoPhotonics merger and $10.9 million related to the acquisition of the IPG product lines as of April 1, 2023. We allocated the entire goodwill amount in connection with these two acquisitions to the OpComms segment.

[0001628280-23-016653:notes:113]
The following table presents the changes in goodwill by reportable segments during the nine months ended April 1, 2023 (in millions):

[0001628280-23-016653:notes:114]
|  | Optical Communications |  | Commercial Lasers |  | Total |
| Balance as of July 2, 2022 | $ | 363.5 |  |  | $ | 5.4 |  |  | $ | 368.9 |  |
| Acquisition of NeoPhotonics (1) | 316.4 |  |  | — |  |  | 316.4 |  |
| Acquisition of IPG product lines (2) | 10.9 |  |  | — |  |  | 10.9 |  |
| Balance as of April 1, 2023 | $ | 690.8 |  |  | $ | 5.4 |  |  | $ | 696.2 |  |

[0001628280-23-016653:notes:115]
(1) We recorded $318.3 million of goodwill as of the acquisition date, and $2.0 million and $1.9 million of measurement period adjustments to goodwill during the three and nine months ended April 1, 2023, respectively.

[0001628280-23-016653:notes:116]
(2)  We recorded $6.5 million of goodwill as of the acquisition date, and $4.4 million and $4.4 million of measurement period adjustments to goodwill during the three and nine months ended April 1, 2023, respectively.

[0001628280-23-016653:notes:117]
[same as prior period, unchanged from 0001628280-23-002880:notes:117]

[0001628280-23-016653:notes:118]
We review goodwill for impairment during the fourth quarter of each fiscal year or more frequently if events or circumstances indicate that an impairment loss may have occurred. In the fourth quarter of fiscal 2022, we completed the annual impairment test of goodwill, which indicated there was no goodwill impairment. During the second and third quarter of fiscal 2023, we evaluated the economic uncertainties due to threats of a recession, increasing inflation, decline in our share prices, and rising interest rates, and determined based on the qualitative assessment that it is not more likely than not that the carrying value of goodwill is impaired. No goodwill impairment existed during the three and nine months ended April 1, 2023.

[0001628280-23-016653:notes:119]
[same as prior period, unchanged from 0001628280-23-002880:notes:119]

[0001628280-23-016653:notes:120]
[same as prior period, unchanged from 0001628280-23-002880:notes:120]

[0001628280-23-016653:notes:121]
In-process research and development (“IPR&D”) is initially capitalized at fair value as an intangible asset with an indefinite life and assessed for impairment thereafter. When an IPR&D project is completed, the IPR&D is reclassified as an amortizable purchased intangible asset and amortized over the asset’s estimated useful life.

[0001628280-23-016653:notes:122]
During the annual impairment testing performed in the fourth quarter of fiscal 2022, we concluded that our intangible and other long-lived assets were not impaired. We review our intangible and other long-lived assets for impairment at least annually in the fourth quarter of each fiscal year, absent any interim indicators of impairment.  There were no indicators of impairment at the asset group level during the three and nine months ended April 1, 2023.

[0001628280-23-016653:notes:123]
In connection with the merger with NeoPhotonics and the acquisition of the IPG product lines, we recorded $452.5 million of intangible assets. Refer to “Note 4. Business Combinations”. The intangible assets acquired from the acquisitions were as follows as of the acquisition date (in millions, except for weighted average amortization period):

[0001628280-23-016653:notes:124]
[same as prior period, unchanged from 0001628280-23-002880:notes:125]

[0001628280-23-016653:notes:125]
As of April 1, 2023, we reclassified $23.3 million of IPR&D intangible assets acquired from NeoPhotonics to acquired developed technologies for IPR&D projects that were completed during the period. We recorded $1.3 million of related amortization expense in our condensed consolidated statements of operations during the three months ended April 1, 2023.

[0001628280-23-016653:notes:126]
During the three months ended April 1, 2023, we recorded $11.5 million of research and development expense related to a write-off of certain IPR&D projects acquired from NeoPhotonics that we subsequently decided not to pursue.

[0001628280-23-016653:notes:127]
The following tables present details of all of our intangibles, including those acquired in connection with our acquisitions in the first quarter of fiscal 2023, as of the periods presented (in millions, except for weighted average remaining amortization period):

[0001628280-23-016653:notes:128]
| April 1, 2023 | Gross Carrying Amounts |  | Accumulated Amortization |  | Net Carrying Amounts |  | Weighted average remaining amortization period (years) |
| Acquired developed technologies | $ | 642.2 |  |  | $ | (371.5) |  |  | $ | 270.7 |  |  | 4.4 |
| Customer relationships | 291.8 |  |  | (106.4) |  |  | 185.4 |  |  | 4.8 |
| In-process research and development | 42.3 |  |  | — |  |  | 42.3 |  |  | n/a |
| Total intangible assets | $ | 976.3 |  |  | $ | (477.9) |  |  | $ | 498.4 |  |  |  |

[0001628280-23-016653:notes:129]
[same as prior period, unchanged from 0001628280-23-002880:notes:128]

[0001628280-23-016653:notes:130]
[same as prior period, unchanged from 0001628280-23-002880:notes:129]

[0001628280-23-016653:notes:131]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 1, 2023 |  | April 2, 2022 |  | April 1, 2023 |  | April 2, 2022 |
| Cost of sales | $ | 18.7 |  |  | $ | 15.6 |  |  | $ | 66.4 |  |  | $ | 47.3 |  |
| Selling, general and administrative | 11.3 |  |  | 5.8 |  |  | 31.9 |  |  | 17.0 |  |
| Total amortization of intangibles | $ | 30.0 |  |  | $ | 21.4 |  |  | $ | 98.3 |  |  | $ | 64.3 |  |

[0001628280-23-016653:notes:132]
Based on the carrying amount of our acquired developed technologies and customer relationships as of April 1, 2023, and assuming no future impairment of the underlying assets, the estimated future amortization is as follows (in millions):

[0001628280-23-016653:notes:133]
| Fiscal Years |  |
| Remainder of 2023 | $ | 30.0 |  |
| 2024 | 114.3 |  |
| 2025 | 100.3 |  |
| 2026 | 87.9 |  |
| 2027 | 76.0 |  |
| Thereafter | 47.6 |  |
| Total future amortization | $ | 456.1 |  |


## us-gaap:ScheduleOfFiniteLivedIntangibleAssetsTableTextBlock

[0001628280-23-016653:notes:134]
The intangible assets acquired from the acquisitions were as follows as of the acquisition date (in millions, except for weighted average amortization period):


## us-gaap:DebtDisclosureTextBlock

[0001628280-23-016653:notes:135]
Note 9. Debt

[0001628280-23-016653:notes:136]
Convertible Notes

[0001628280-23-016653:notes:137]
2028 Notes

[0001628280-23-016653:notes:138]
In March 2022, we issued $861.0 million in aggregate principal amount of 0.50% convertible notes due in 2028 (the “2028 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act of 1933, as amended (the “Securities Act”). The 2028 Notes are governed by an indenture between the Company and U.S. Bank Trust Company National Association (as successor in interest to U.S. Bank National Association), as trustee (the “2028 Indenture”). The 2028 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001628280-23-016653:notes:139]
The net proceeds from the sale of the 2028 Notes was $854.8 million, after deducting $6.2 million in issuance costs. In addition, we incurred $0.7 million in professional fees in connection with this transaction. Concurrent with the issuance of the 2028 Notes, we used $200.0 million of the net proceeds to repurchase our common stock in privately negotiated transactions.

[0001628280-23-016653:notes:140]
The 2028 Notes bear interest at a rate of 0.50% per year, payable semi-annually in arrears on June 15 and December 15 of each year, beginning on June 15, 2022. The 2028 Notes will mature on June 15, 2028, unless earlier redeemed, repurchased by us, or converted pursuant to their terms.

[0001628280-23-016653:notes:141]
The initial conversion rate is 7.6319 shares of common stock per $1,000 principal amount of the 2028 Notes (which is equivalent to an initial conversion price of approximately $131.03 per share). The conversion rate is subject to adjustment upon the occurrence of certain specified events, but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change (as defined in the 2028 Indenture) or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert the 2028 Notes in connection with such make-whole fundamental change or notice of redemption.

[0001628280-23-016653:notes:142]
Prior to the close of business on the business day immediately preceding March 15, 2028, holders of the 2028 Notes may convert their 2028 Notes only under the following circumstances:

[0001628280-23-016653:notes:143]
•during any fiscal quarter (and only during such fiscal quarter), if the last reported sale price of the Company’s common stock for at least 20 trading days (whether or not consecutive) during the 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price, or $170.34, on each applicable trading day;

[0001628280-23-016653:notes:144]
•during the five consecutive business day period after any five consecutive trading day period (the “measurement period”) in which the trading price per $1,000 principal amount of the 2028 Notes for each trading day of such measurement period was less than 98% of the product of the last reported sale price of the Company’s common stock and the applicable conversion rate on each such trading day;

[0001628280-23-016653:notes:145]
•if the Company calls any or all of the 2028 Notes for redemption, at any time prior to the close of business on the second business day immediately preceding the redemption date; or

[0001628280-23-016653:notes:146]
•upon the occurrence of specified corporate events, as specified in the 2028 Indentures

[0001628280-23-016653:notes:147]
On or after March 15, 2028 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their 2028 Notes at any time. Upon conversion, we may satisfy our conversion obligation in cash, shares of common stock or a combination of cash and shares of common stock, at our election.

[0001628280-23-016653:notes:148]
We may redeem for cash all or any portion of the 2028 Notes, at our option (subject to the partial redemption limitation set forth in the 2028 Indenture), on or after June 20, 2025, if the last reported sale price of its common stock has been at least 130% of the conversion price then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading-day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which the Company provides notice of redemption at a redemption price equal to 100% of the principal amount of the 2028 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. No sinking fund is provided for the 2028 Notes. If we elect to redeem fewer than all of the outstanding 2028 Notes, at least $100.0 million aggregate principal amount of the 2028 Notes must be outstanding and not subject to redemption as of the redemption notice date. Upon the occurrence of a fundamental change (as defined in the 2028 Indenture), holders may require the Company to repurchase all or a portion of their 2028 Notes for cash at a price equal to 100% of the principal amount of the 2028 Notes to be repurchased, plus any accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

[0001628280-23-016653:notes:149]
We initially bifurcated the principal amount of the 2028 Notes into liability and equity components. The liability component of the 2028 Notes was initially valued at $629.8 million based on the contractual cash flow discounted at an appropriate comparable market on non-convertible debt borrowing rate at the date of issuance, which was 5.7%, with the equity component representing the residual amount of the proceeds of $231.2 million, which was recorded as a debt discount. Upon adoption of ASU 2020-06 in the first quarter of fiscal 2023, our 2028 Notes were accounted for as a single liability measured at amortized cost. Refer to “Note 2. Recently Issued Accounting Pronouncement” for the detailed adoption impact.

[0001628280-23-016653:notes:150]
2026 Notes

[0001628280-23-016653:notes:151]
In December 2019, we issued $1,050.0 million in aggregate principal amount of 0.50% convertible notes due in 2026 (the “2026 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act. The 2026 Notes are governed by an indenture between the Company and U.S. Bank Trust Company National Association (as successor in interest to U.S. Bank National Association, as trustee (the “2026 Indenture”). We used approximately $196.0 million of the net proceeds of the offering to repay in full all amounts outstanding under our term loan credit facility, and a portion of the net proceeds of the offering to purchase approximately $200.0 million of our common stock concurrently with the pricing of the offering in privately negotiated transactions. The 2026 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001628280-23-016653:notes:152]
The 2026 Notes bear interest at a rate of 0.50% per year, payable semi-annually in arrears on June 15 and December 15 of each year, beginning on June 15, 2020. The 2026 Notes will mature on December 15, 2026, unless earlier redeemed, repurchased by us, or converted pursuant to their terms.

[0001628280-23-016653:notes:153]
The initial conversion rate is 10.0711 shares of common stock per $1,000 principal amount of the 2026 Notes (which is equivalent to an initial conversion price of approximately $99.29 per share). The conversion rate is subject to adjustment upon the occurrence of certain events specified in the 2026 Indenture but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change (as defined in the 2026 Indenture) or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares set forth in the 2026 Indenture or a holder that elects to convert the 2026 Notes in connection with such make-whole fundamental change or notice of redemption.

[0001628280-23-016653:notes:154]
Prior to the close of business on the business day immediately preceding September 15, 2026, holders of the 2026 Notes may convert their 2026 Notes only under the following circumstances:

[0001628280-23-016653:notes:155]
•during any fiscal quarter (and only during such fiscal quarter), if the last reported sale price of the common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price of the 2026 Notes, or $129.08 on each applicable trading day;

[0001628280-23-016653:notes:156]
•during the five consecutive business day period after any five consecutive trading day period (the “2026 measurement period”) in which the trading price per $1,000 principal amount of the 2026 Notes for each trading day of the 2026 measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate for the 2026 Notes on each such trading day;

[0001628280-23-016653:notes:157]
•if we call any or all of the 2026 Notes for redemption, at any time prior to the close of business on the second business day immediately preceding the relevant redemption date; or

[0001628280-23-016653:notes:158]
•upon the occurrence of specified corporate events.

[0001628280-23-016653:notes:159]
On or after September 15, 2026 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their 2026 Notes at any time. Upon conversion, we may satisfy our conversion obligation in cash, shares of common stock or a combination of cash and shares of common stock, at our election.

[0001628280-23-016653:notes:160]
We may redeem for cash, all or any portion of the 2026 Notes, at our option, on or after December 20, 2023, if the last reported sale price of its common stock has been at least 130% of the conversion price then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading-day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which we provide a notice of redemption at a redemption price equal to 100% of the principal amount of the 2026 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. No sinking fund is provided for the 2026 Notes. Upon the occurrence of a fundamental change (as defined in the 2026 Indenture), holders may require us to repurchase all or a portion of the 2026 Notes for cash at a price equal to 100% of the principal amount of the 2026 Notes to be repurchased, plus any accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

[0001628280-23-016653:notes:161]
We initially bifurcated the principal amount of the 2026 Notes into liability and equity components. The liability component of the 2026 Notes was initially valued at $734.8 million based on the contractual cash flows discounted at an appropriate comparable market non-convertible debt borrowing rate at the date of issuance of 5.8% with the equity component representing the residual amount of the proceeds of $315.2 million, which was recorded as a debt discount. Upon adoption of ASU 2020-06 in the first quarter of fiscal 2023, our 2026 Notes were accounted for as a single liability measured at amortized cost.  Refer to “Note 2. Recently Issued Accounting Pronouncement” for the detailed adoption impact.

[0001628280-23-016653:notes:162]
2024 Notes

[0001628280-23-016653:notes:163]
In March 2017, we issued $450.0 million in aggregate principal amount of 0.25% convertible notes due in 2024 (the “2024 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act. The 2024 Notes are governed by an indenture between the Company, as the issuer, and U.S. Bank Trust Company National Association (as successor in interest to U.S. Bank National Association), as trustee (the “2024 Indenture”). The 2024 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001628280-23-016653:notes:164]
The 2024 Notes bear interest at a rate of 0.25% per year. Interest on the 2024 Notes is payable semi-annually in arrears on March 15 and September 15 of each year, beginning on September 15, 2017. The 2024 Notes will mature on March 15, 2024, unless earlier repurchased by us or converted pursuant to their terms.

[0001628280-23-016653:notes:165]
The initial conversion rate of the 2024 Notes is 16.4965 shares of common stock per $1,000 principal amount of 2024 Notes, which is equivalent to an initial conversion price of approximately $60.62 per share. The conversion rate is subject to adjustment upon the occurrence of certain specified events but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change (as defined in the 2024 Indenture) or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert the 2024 Notes in connection with such make-whole fundamental change or notice of redemption.

[0001628280-23-016653:notes:166]
Prior to the close of business on the business day immediately preceding December 15, 2023, each holder of the 2024 Notes may convert their 2024 Notes only under the following circumstances:

[0001628280-23-016653:notes:167]
•during any fiscal quarter (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during the period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price, or $78.80 on each applicable trading day;

[0001628280-23-016653:notes:168]
•during the five consecutive business day period after any five consecutive trading day period (the “2024 measurement period”) in which the trading price per $1,000 principal amount of 2024 Notes for each trading day of such 2024 measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate for the 2024 Notes on each such trading day; or

[0001628280-23-016653:notes:169]
On or after December 15, 2023 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their 2024 Notes at any time. In addition, upon the occurrence of a make-whole fundamental change (as defined in the 2024 Indenture), we will, in certain circumstances, increase the conversion rate by a number of additional shares set forth in the 2024 Indenture for a holder that elects to convert 2024 Notes in connection with such make-whole fundamental change.

[0001628280-23-016653:notes:170]
We may not redeem the 2024 Notes prior to their maturity date and no sinking fund is provided for the 2024 Notes. Upon the occurrence of a fundamental change (as defined in the 2024 Indenture), holders may require us to repurchase all or a portion of their 2024 Notes for cash at a price equal to 100% of the principal amount of the 2024 Notes to be repurchased, plus any accrued and unpaid interest.

[0001628280-23-016653:notes:171]
During the three and nine months ended April 1, 2023, we received conversion requests of less than $0.1 million principal amount of the 2024 Notes, which we settled with cash in accordance with the 2024 Indenture. Since issuing the 2024 Notes, we have converted a total of approximately $1.9 million principal amount of the 2024 Notes. The remaining principal amount of the 2024 Notes as of April 1, 2023 was $448.1 million.

[0001628280-23-016653:notes:172]
We considered the features embedded in the 2024 Notes other than the conversion feature, including the holders’ put feature, our call feature, and the make-whole feature, and concluded that they are not required to be bifurcated and accounted for separately from the host debt instrument. Prior to the Tax Matters Agreement settlement condition (“TMA settlement condition”), because we could only settle the 2024 Notes in cash, we determined that the conversion feature met the definition of a derivative liability. We separated the derivative liability from the host debt instrument based on the fair value of the derivative liability. During fiscal 2017, we satisfied the TMA settlement condition. As such, the value of the conversion option is no longer marked-to-market and was reclassified to additional paid-in capital within stockholders’ equity on our condensed consolidated balance sheets. The adoption of ASU 2020-06 did not change the presentation of the 2024 Notes, as the conversion feature associated with the 2024 Notes continues to be classified within stockholders’ equity.

[0001628280-23-016653:notes:173]
Convertible Notes - Additional Disclosures

[0001628280-23-016653:notes:174]
Our convertible notes consisted of the following components as of the periods presented (in millions):

[0001628280-23-016653:notes:175]
| Liability component: | April 1, 2023 |  | July 2, 2022 |
|  | 2024 Notes (1) |  | 2026 Notes (2) |  | 2028 Notes (3) |  | 2024 Notes (1) |  | 2026 Notes (2) |  | 2028 Notes (3) |
| Principal | $ | 448.1 |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |  | $ | 448.1 |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |
| Unamortized debt discount | (20.7) |  |  | — |  |  | — |  |  | (36.1) |  |  | (214.9) |  |  | (221.4) |  |
| Unamortized issuance costs | (1.2) |  |  | (4.4) |  |  | (5.8) |  |  | (2.1) |  |  | (3.7) |  |  | (4.9) |  |
| Net carrying amount of the liability component | $ | 426.2 |  |  | $ | 1,045.6 |  |  | $ | 855.2 |  |  | $ | 409.9 |  |  | $ | 831.4 |  |  | $ | 634.7 |  |

[0001628280-23-016653:notes:176]
(1) If the closing price of our stock exceeds $78.80 (or 130% of the conversion price of $60.62) for 20 of the last 30 trading days of any future fiscal quarter, our 2024 Notes would become convertible at the option of the holders during the next fiscal quarter. The 2024 Notes are classified as current liabilities as the debt will mature on March 15, 2024.

[0001628280-23-016653:notes:177]
(2) If the closing price of our stock exceeds $129.08 (or 130% of the conversion price of $99.29) for 20 of the last 30 trading days of any future fiscal quarter, our 2026 Notes would become convertible at the option of the holders during the subsequent fiscal quarter and the debt would be reclassified to current liabilities in our condensed consolidated balance sheet.

[0001628280-23-016653:notes:178]
(3) If the closing price of our stock exceeds $170.34 (or 130% of the conversion price of $131.03) for 20 of the last 30 trading days of any future fiscal quarter, our 2028 Notes would become convertible at the option of the holders during the subsequent fiscal quarter and the debt would be reclassified to current liabilities in our condensed consolidated balance sheet.

[0001628280-23-016653:notes:179]
The following table sets forth interest expense information related to the convertible notes for the periods presented (in millions):

[0001628280-23-016653:notes:180]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 1, 2023 |  | April 2, 2022 |  | April 1, 2023 |  | April 2, 2022 |
| Contractual interest expense | $ | 2.7 |  |  | $ | 1.9 |  |  | $ | 8.1 |  |  | $ | 5.1 |  |
| Amortization of the debt discount and debt issuance costs | 6.0 |  |  | 17.8 |  |  | 17.9 |  |  | 48.6 |  |
| Total interest expense | $ | 8.7 |  |  | $ | 19.7 |  |  | $ | 26.0 |  |  | $ | 53.7 |  |

[0001628280-23-016653:notes:181]
The future interest and principal payments related to our convertible notes are as follows as of April 1, 2023 (in millions):

[0001628280-23-016653:notes:182]
| Fiscal Years | 2024 Notes |  | 2026 Notes |  | 2028 Notes |  | Total |
| Remainder of 2023 | $ | — |  |  | $ | 2.6 |  |  | $ | 2.2 |  |  | $ | 4.8 |  |
| 2024 | 449.3 |  |  | 5.3 |  |  | 4.3 |  |  | 458.9 |  |
| 2025 | — |  |  | 5.3 |  |  | 4.3 |  |  | 9.6 |  |
| 2026 | — |  |  | 5.3 |  |  | 4.3 |  |  | 9.6 |  |
| 2027 and thereafter | — |  |  | 1,052.5 |  |  | 869.6 |  |  | 1,922.1 |  |
| Total convertible notes payments | $ | 449.3 |  |  | $ | 1,071.0 |  |  | $ | 884.7 |  |  | $ | 2,405.0 |  |

[0001628280-23-016653:notes:183]
The principal balances of our convertible notes are reflected in the payment periods in the table above based on their respective contractual maturities.

[0001628280-23-016653:notes:184]
Mitsubishi Bank Loans

[0001628280-23-016653:notes:185]
In connection with our merger of NeoPhotonics, we assumed several loan agreements with MUFG Bank, Ltd. (the “Mitsubishi Bank Loans”) for an aggregate fair value of approximately $5.9 million, approximately $0.9 million of which was paid in the fiscal first quarter of 2023.  In October 2022, we fully paid the remaining outstanding amount of the Mitsubishi Bank Loans of approximately $5.0 million. We recorded $0.1 million of interest expense related to the Mitsubishi Bank Loans for the nine months ended April 1, 2023.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001628280-23-016653:notes:186]
[same as prior period, unchanged from 0001628280-23-002880:notes:184]

[0001628280-23-016653:notes:187]
Our accumulated other comprehensive income (loss), net of tax, consists of the accumulated net unrealized gains or losses on foreign currency translation adjustments, the defined benefit obligations and available-for-sale securities.

[0001628280-23-016653:notes:188]
The changes in accumulated other comprehensive income (loss), net of tax, were as follows for the periods as presented (in millions):

[0001628280-23-016653:notes:189]
|  | Foreign currency translation adjustments, net of tax (1) |  | Defined benefit obligations, net of tax (2) |  | Unrealized gain (loss) on available-for-sale securities, net of tax (3) |  |  |  | Total |
| Beginning balance as of July 2, 2022 | $ | 9.7 |  |  | $ | 1.0 |  |  | $ | (10.3) |  |  |  |  | $ | 0.4 |  |
| Other comprehensive loss | — |  |  | — |  |  | (0.6) |  |  |  |  | (0.6) |  |
| Ending balance as of October 1, 2022 | 9.7 |  |  | 1.0 |  |  | (10.9) |  |  |  |  | (0.2) |  |
| Other comprehensive income | — |  |  | — |  |  | 3.6 |  |  |  |  | 3.6 |  |
| Ending balance as of December 31, 2022 | $ | 9.7 |  |  | $ | 1.0 |  |  | $ | (7.3) |  |  |  |  | $ | 3.4 |  |
| Other comprehensive income | 0.3 |  |  | — |  |  | 3.4 |  |  |  |  | 3.7 |  |
| Ending balance as of April 1, 2023 | $ | 10.0 |  |  | $ | 1.0 |  |  | $ | (3.9) |  |  |  |  | $ | 7.1 |  |
|  | Foreign currency translation adjustments, net of tax (1) |  | Defined benefit obligations, net of tax (2) |  | Unrealized gain (loss) on available-for-sale securities, net of tax (3) |  |  |  | Total |
| Beginning balance as of July 3, 2021 | $ | 9.7 |  |  | $ | (1.4) |  |  | $ | (0.1) |  |  |  |  | $ | 8.2 |  |
| Other comprehensive income | — |  |  | — |  |  | 0.3 |  |  |  |  | 0.3 |  |
| Ending balance as of October 2, 2021 | 9.7 |  |  | (1.4) |  |  | 0.2 |  |  |  |  | 8.5 |  |
| Other comprehensive loss | — |  |  | — |  |  | (2.3) |  |  |  |  | (2.3) |  |
| Ending balance as of January 1, 2022 | $ | 9.7 |  |  | $ | (1.4) |  |  | $ | (2.1) |  |  |  |  | $ | 6.2 |  |
| Other comprehensive loss | — |  |  | (0.5) |  |  | (6.9) |  |  |  |  | (7.4) |  |
| Ending balance as of April 2, 2022 | $ | 9.7 |  |  | $ | (1.9) |  |  | $ | (9.0) |  |  |  |  | $ | (1.2) |  |

[0001628280-23-016653:notes:190]
(1) In fiscal 2019, we established the functional currency for our worldwide operations as the U.S. dollar. Translation adjustments reported prior to December 10, 2018 remain as a component of accumulated other comprehensive income (loss) in our condensed consolidated balance sheets, until all or a part of the investment in the subsidiaries is sold or liquidated. In fiscal 2023, we acquired IPG Photonics’ telecom transmission product lines. The functional currency of the Brazilian entities acquired as part of this acquisition is the local currency. In the three months ended April 1, 2023, we recorded $0.3 million of foreign currency translation adjustments.

[0001628280-23-016653:notes:191]
[same as prior period, unchanged from 0001628280-23-002880:notes:189]

[0001628280-23-016653:notes:192]
(3) For the three months ended April 1, 2023, December 31, 2022 and October 1, 2022, our unrealized gain (loss) on available-for-sale securities is presented net of tax of $1.0 million, $1.0 million and $(0.2) million, respectively. 
For the three months ended April 2, 2022, and January 1, 2022 and October 2, 2021, our unrealized gain (loss) on available-for-sale securities is presented net of tax of $(1.9) million, $(0.5) million and $0 million  respectively.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001628280-23-016653:notes:193]
[same as prior period, unchanged from 0001628280-23-002880:notes:190]

[0001628280-23-016653:notes:194]
[same as prior period, unchanged from 0001628280-23-002880:notes:191]

[0001628280-23-016653:notes:195]
The following table summarizes activities of restructuring and related charges for the periods as presented (in millions):

[0001628280-23-016653:notes:196]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 1, 2023 |  | April 2, 2022 |  | April 1, 2023 |  | April 2, 2022 |
| Balance as of beginning of period | $ | 14.1 |  |  | $ | 0.3 |  |  | $ | — |  |  | $ | 5.7 |  |
| Charges (reversals), net | 1.6 |  |  | (0.1) |  |  | 24.8 |  |  | (1.1) |  |
| Payments | (11.5) |  |  | (0.1) |  |  | (20.6) |  |  | (4.5) |  |
| Balance as of end of period | $ | 4.2 |  |  | $ | 0.1 |  |  | $ | 4.2 |  |  | $ | 0.1 |  |

[0001628280-23-016653:notes:197]
During the three months ended April 1, 2023, we recorded restructuring and related charges of $1.6 million in our condensed consolidated statements of operations, which was primarily due to company-wide integration efforts as a result of the merger with NeoPhotonics, as well as our cost reduction initiatives.

[0001628280-23-016653:notes:198]
During the nine months ended April 1, 2023, we recorded restructuring and related charges of $24.8 million in our condensed consolidated statements of operations, which was primarily attributable to company-wide integration efforts as a result of the merger with NeoPhotonics, our cost reduction initiatives, as well as severance and employee-related benefits associated with NeoPhotonics’ executive severance and retention agreements. These agreements provide for payments and benefits upon an involuntary termination of employment under certain circumstances.

[0001628280-23-016653:notes:199]
We made $11.5 million and $20.6 million of restructuring payments during the three and nine months ended April 1, 2023, respectively.

[0001628280-23-016653:notes:200]
During the three and nine months ended April 2, 2022, we recorded a net reversal to our restructuring and related charges of $1.1 million in our condensed consolidated statements of operations, which was attributable to lower than anticipated employee severance charges primarily as a result of retaining and re-assigning certain employees.

[0001628280-23-016653:notes:201]
[same as prior period, unchanged from 0001628280-23-002880:notes:198]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-23-016653:notes:202]
[same as prior period, unchanged from 0001628280-23-002880:notes:199]

[0001628280-23-016653:notes:203]
[same as prior period, unchanged from 0001628280-23-002880:notes:200]

[0001628280-23-016653:notes:204]
We recorded a tax benefit of $9.4 million and a tax provision of $14.4 million for the three and nine months ended April 1, 2023, respectively. Our tax provision for the three months ended April 1, 2023 includes a discrete tax benefit of $9.8 million primarily related to a tax planning action that was implemented during the current quarter relating to fiscal year 2022 and changes in prior year uncertain tax positions, partially offset by a shortfall in connection with stock-based compensation vested during the quarter. Our tax provision for the nine months ended April 1, 2023 includes a discrete tax expense of $7.2 million, primarily related to the international restructuring, partially offset by the tax benefits from tax rate changes, a tax planning action that was implemented during the current quarter relating to fiscal year 2022, and changes in prior year uncertain tax positions.

[0001628280-23-016653:notes:205]
Our estimated effective tax rate for fiscal 2023 also differs from the 21% U.S. statutory rate primarily due to the income tax expense from the tax effect of Global Intangible Low-Taxed Income (“GILTI”), net of benefit for foreign tax credits, subpart F inclusion, foreign rate differential and non-deductible stock-based compensation, partially offset by the income tax benefit from U.S. federal R&D tax credits.
As of April 1, 2023, we had $50.4 million of unrecognized tax benefits, which, if recognized, would affect the effective tax rate. We are subject to examination of income tax returns by various domestic and foreign tax authorities. The timing of resolution and closure of these tax examinations is highly unpredictable. Although it is possible that certain ongoing tax examinations may be concluded within the next 12 months, we cannot reasonably estimate the impact to tax expense and net income from tax exams that could be resolved or closed within the next 12 months. Subject to audit timing and uncertainty, we expect the amount of unrecognized tax benefit that would become recognized due to expiration of the statute of limitations and affect the effective tax rate to decrease by $10.3 million over the next 12 months.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001628280-23-016653:notes:206]
[same as prior period, unchanged from 0001628280-23-002880:notes:203]

[0001628280-23-016653:notes:207]
[same as prior period, unchanged from 0001628280-23-002880:notes:204]

[0001628280-23-016653:notes:208]
[same as prior period, unchanged from 0001628280-23-002880:notes:205]

[0001628280-23-016653:notes:209]
[same as prior period, unchanged from 0001628280-23-002880:notes:206]

[0001628280-23-016653:notes:210]
As of April 1, 2023, we had 3.4 million shares subject to restricted stock units, restricted stock awards, and performance stock units issued and outstanding under the 2015 Plan. These grants are performance-based, time-based or a combination of both and are expected to vest over within four years. The fair value of these grants is based on the closing market price of our common stock on the date of grant. As of April 1, 2023, 2.7 million shares of common stock under the 2015 Plan were available for grant.

[0001628280-23-016653:notes:211]
[same as prior period, unchanged from 0001628280-23-002880:notes:208]

[0001628280-23-016653:notes:212]
[same as prior period, unchanged from 0001628280-23-002880:notes:209]

[0001628280-23-016653:notes:213]
[same as prior period, unchanged from 0001628280-23-002880:notes:210]

[0001628280-23-016653:notes:214]
[same as prior period, unchanged from 0001628280-23-002880:notes:211]

[0001628280-23-016653:notes:215]
During the nine months ended April 1, 2023, our board of directors approved grants of 1.8 million RSUs, which primarily vest over three years. In addition, we issued 0.4 million RSUs that were issued as part of the Replacement Awards in connection with the merger with NeoPhotonics as described above.

[0001628280-23-016653:notes:216]
[same as prior period, unchanged from 0001628280-23-002880:notes:213]

[0001628280-23-016653:notes:217]
[same as prior period, unchanged from 0001628280-23-002880:notes:214]

[0001628280-23-016653:notes:218]
During the nine months ended April 1, 2023, 0.3 million PSUs were issued to executive and certain non-executive employees as part of our revised Annual Incentive Plan. These PSUs have an aggregate grant date fair value of $26.0 million and are subject to performance targets and service conditions, with a vesting period of one year. The board of directors also approved a grant of 0.3 million PSUs with an aggregate grant date fair value of $23.0 million to certain executive officers and senior management. These PSUs will vest subject to the achievement of revenue targets and certain non-financial performance measurements, as well as service conditions, over three years.

[0001628280-23-016653:notes:219]
[same as prior period, unchanged from 0001628280-23-002880:notes:216]

[0001628280-23-016653:notes:220]
Our 2015 Employee Stock Purchase Plan (the “2015 Purchase Plan”) provides eligible employees with the opportunity to acquire an ownership interest in the Company through periodic payroll deductions and provides a 15% purchase price discount as well as a 6-month look-back period. The 2015 Purchase Plan is structured as a qualified employee stock purchase plan under Section 423 of the Internal Revenue Code of 1986, as amended. The 2015 Purchase Plan will terminate upon the date on which all shares available for issuance have been sold. Of the 3.0 million shares authorized under the 2015 Purchase Plan, 1.3 million shares remained available for issuance as of April 1, 2023.

[0001628280-23-016653:notes:221]
[same as prior period, unchanged from 0001628280-23-002880:notes:218]

[0001628280-23-016653:notes:222]
[same as prior period, unchanged from 0001628280-23-002880:notes:219]

[0001628280-23-016653:notes:223]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 1, 2023 |  | April 2, 2022 |  | April 1, 2023 |  | April 2, 2022 |
| Cost of sales | $ | 6.9 |  |  | $ | 5.4 |  |  | $ | 19.1 |  |  | $ | 15.2 |  |
| Research and development | 11.0 |  |  | 5.4 |  |  | 31.2 |  |  | 15.8 |  |
| Selling, general and administrative | 15.2 |  |  | 12.5 |  |  | 66.0 |  |  | 44.4 |  |
| Total stock-based compensation | $ | 33.1 |  |  | $ | 23.3 |  |  | $ | 116.3 |  |  | $ | 75.4 |  |

[0001628280-23-016653:notes:224]
In connection with the NeoPhotonics merger, we issued replacement equity awards (the “Replacement Awards”) in settlement of certain NeoPhotonics equity awards at the merger Closing date, with the total fair value of $40.2 million based on our closing stock price on the Closing date. The portion of Replacement Awards attributed to pre-merger service is $3.5 million, which was accounted for as part of the consideration transferred and was recorded under stock-based compensation in our consolidated statements of stockholders’ equity as of April 1, 2023.  Additionally, certain equity awards for NeoPhotonics employees were accelerated. The total stock-based compensation associated with the acceleration was $11.9 million, of which $9.0 million was settled in cash. We recorded the $11.9 million for the accelerated awards in our consolidated statements of operations during the first quarter of fiscal year 2023.  Refer to “Note 4. Business Combinations.”

[0001628280-23-016653:notes:225]
Included in stock-based compensation for the three and nine months ended April 1, 2023, is $3.5 million and $17.0 million of stock-based compensation costs related to PSUs, respectively. Included in stock-based compensation for the three and nine months ended April 2, 2022, is $2.2 million and $11.5 million, respectively, of stock-based compensation costs related to PSUs. The amount of stock-based compensation expense recognized in any one period related to PSUs can vary based on the achievement or anticipated achievement of the performance conditions. If the performance conditions are not met or not expected to be met, no compensation cost would be recognized on the underlying PSUs, and any previously recognized compensation expense related to those PSUs would be reversed.

[0001628280-23-016653:notes:226]
Total income tax benefit associated with stock-based compensation recognized in our condensed consolidated statements of operations during the periods presented was as follows (in millions):

[0001628280-23-016653:notes:227]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 1, 2023 |  | April 2, 2022 |  | April 1, 2023 |  | April 2, 2022 |
| Income tax benefit associated with stock-based compensation | $ | 3.3 |  |  | $ | 2.7 |  |  | $ | 9.7 |  |  | $ | 10.9 |  |

[0001628280-23-016653:notes:228]
Approximately $16.8 million and $6.4 million of stock-based compensation was capitalized to inventory as of April 1, 2023 and July 2, 2022, respectively.

[0001628280-23-016653:notes:229]
As of April 1, 2023, $192.3 million of stock-based compensation cost related to RSU awards remains to be amortized, which is expected to be recognized over an estimated amortization period of 2.0 years.

[0001628280-23-016653:notes:230]
[same as prior period, unchanged from 0001628280-23-002880:notes:228]

[0001628280-23-016653:notes:231]
The following table summarizes our award activities for the nine months ended April 1, 2023 (in millions, except per share amounts):

[0001628280-23-016653:notes:232]
|  |  |  |  |  | Restricted Stock Units |  | Performance Stock Units |
|  |  |  |  |  |  |  |  |  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |
| Balance as of July 2, 2022 |  |  |  |  |  |  |  |  | 2.0 |  |  | $ | 85.9 |  |  | 0.3 |  |  | $ | 81.9 |  |
| Replacement Awards issued |  |  |  |  |  |  |  |  | 0.4 |  |  | 93.4 |  |  | — |  |  | — |  |
| Granted |  |  |  |  |  |  |  |  | 1.8 |  |  | 85.9 |  |  | 0.6 |  |  | 87.9 |  |
| Vested |  |  |  |  |  |  |  |  | (1.1) |  |  | 85.2 |  |  | (0.2) |  |  | 72.4 |  |
| Canceled |  |  |  |  |  |  |  |  | (0.3) |  |  | 88.0 |  |  | (0.1) |  |  | 89.0 |  |
| Balance as of April 1, 2023 |  |  |  |  |  |  |  |  | 2.8 |  |  | $ | 86.0 |  |  | 0.6 |  |  | $ | 89.1 |  |

[0001628280-23-016653:notes:233]
[same as prior period, unchanged from 0001628280-23-002880:notes:231]

[0001628280-23-016653:notes:234]
|  | Awards Available for Grant |
| Balance as of July 2, 2022 | 3.8 |  |
| Assumed in connection with NeoPhotonics merger | 0.4 |  |
| Replacement Awards | (0.4) |  |
| Authorized | 0.9 |  |
| Granted | (2.4) |  |
| Canceled | 0.4 |  |
| Balance as of April 1, 2023 | 2.7 |  |

[0001628280-23-016653:notes:235]
[same as prior period, unchanged from 0001628280-23-002880:notes:233]

[0001628280-23-016653:notes:236]
The 2015 Purchase Plan expense for the three and nine months ended April 1, 2023 was $1.7 million and $3.7 million, respectively. The 2015 Purchase Plan expense for the three and nine months ended April 2, 2022 was $1.0 million and $3.1 million, respectively. The expense related to the 2015 Purchase Plan is recorded on a straight-line basis over the relevant subscription period.

[0001628280-23-016653:notes:237]
During the nine months ended April 1, 2023, there were 0.1 million shares issued to employees through the 2015 Purchase Plan. During the nine months ended April 2, 2022, there were 0.1 million shares issued to employees through the 2015 Purchase Plan.

[0001628280-23-016653:notes:238]
[same as prior period, unchanged from 0001628280-23-002880:notes:236]

[0001628280-23-016653:notes:239]
On May 7, 2021, our board of directors approved the 2021 share buyback program, which authorizes us to utilize up to $700.0 million to purchase our own shares of common stock. On March 3, 2022, our board of directors approved an increase in our share buyback program to authorize us to utilize up to an aggregate amount of $1.0 billion (an increase from $700.0 million) to purchase our own shares of common stock through May 2024.  On April 5, 2023, our board of directors approved a further increase in our share buyback program to authorize us to utilize up to an aggregate amount of  $1.2 billion (an increase from $1.0 billion) to purchase our own shares of common stock through May 2025.

[0001628280-23-016653:notes:240]
During the nine months ended April 1, 2023, we repurchased 0.3 million shares of our common stock at an average price of $89.80 per share for an aggregate purchase price of $25.7 million.

[0001628280-23-016653:notes:241]
Since the board of directors initially approved the share buyback program, we have repurchased 7.4 million shares in aggregate at an average price of $83.38 per share for a total purchase price of $615.5 million. We recorded the $615.5 million aggregate purchase price as a reduction of retained earnings within our condensed consolidated balance sheet. All repurchased shares were retired immediately.

[0001628280-23-016653:notes:242]
The price, timing, amount, and method of future repurchases will be determined based on the valuation of market conditions and other factors, at prices determined to be attractive and in the best interests of both the Company and our stockholders. The stock repurchase program may be suspended or terminated at any time.


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0001628280-23-016653:notes:243]
Note 14. Commitments and Contingencies

[0001628280-23-016653:notes:244]
Purchase Obligations

[0001628280-23-016653:notes:245]
Our purchase obligations of $379.2 million as of April 1, 2023 represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet our operational requirements. In addition, we assumed certain purchase orders in connection with our merger with NeoPhotonics for the purchase of inventory and other items in the ordinary course of its business.  Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule, and adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

[0001628280-23-016653:notes:246]
We depend on a limited number of contract manufacturers, subcontractors and suppliers for raw materials, packages and standard components. We generally purchase these single or limited source products through standard purchase orders or one-year supply agreements and have no significant long-term guaranteed supply agreements with such vendors. While we seek to maintain a sufficient safety stock of such products and maintain on-going communications with our suppliers to guard against interruptions or cessation of supply, our business and results of operations could be adversely affected by a stoppage or delay of supply, substitution of more expensive or less reliable products, receipt of defective parts or contaminated materials, increases in the price of such supplies, or our inability to obtain reduced pricing from our suppliers in response to competitive pressures.

[0001628280-23-016653:notes:247]
Product Warranties

[0001628280-23-016653:notes:248]
We provide reserves for the estimated costs of product warranties at the time revenue is recognized. We typically offer a twelve-month warranty for most of our products. However, in some instances depending upon the product, product components or application of our products by the end customer, our warranties can vary and generally range from six months to five years. We estimate the costs of our warranty obligations on an annualized basis based on our historical experience of known product failure rates, use of materials to repair or replace defective products, and service delivery costs incurred in correcting product failures. In addition, from time to time, specific warranty accruals may be made if unforeseen technical problems arise with specific products. We assess the adequacy of our recorded warranty liabilities and adjust the amounts as necessary.

[0001628280-23-016653:notes:249]
The following table presents the changes in our warranty reserve for the periods presented (in millions):

[0001628280-23-016653:notes:250]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 1, 2023 |  | April 2, 2022 |  | April 1, 2023 |  | April 2, 2022 |
| Balance as of beginning of period | $ | 8.4 |  |  | $ | 8.6 |  |  | $ | 10.0 |  |  | $ | 5.0 |  |
| Warranties assumed in NeoPhotonics merger | — |  |  | — |  |  | 0.7 |  |  | — |  |
| Provision for warranty | 1.1 |  |  | 1.5 |  |  | 5.4 |  |  | 7.0 |  |
| Utilization of reserve | (2.7) |  |  | (1.0) |  |  | (9.3) |  |  | (2.9) |  |
| Balance as of end of period | $ | 6.8 |  |  | $ | 9.1 |  |  | $ | 6.8 |  |  | $ | 9.1 |  |

[0001628280-23-016653:notes:251]
Environmental Liabilities

[0001628280-23-016653:notes:252]
Our research and development, manufacturing and distribution operations involve the use of hazardous substances and are regulated under international, federal, state and local laws governing health and safety and the environment. We apply strict standards for protection of the environment and occupational health and safety to sites inside and outside the United States, even if not subject to regulations imposed by foreign governments. We believe that our properties and operations at our facilities comply in all material respects with applicable environmental laws and occupational health and safety laws. However, the risk of environmental liabilities cannot be completely eliminated and there can be no assurance that the application of environmental and health and safety laws will not require us to incur significant expenditures. We are also regulated under a number of international, federal, state and local laws regarding recycling, product packaging and product content requirements. The environmental and product content/disposal and recycling laws are gradually becoming more stringent and may cause us to incur significant expenditures in the future.

[0001628280-23-016653:notes:253]
Legal Proceedings

[0001628280-23-016653:notes:254]
We are subject to a variety of claims and suits that arise from time to time in the ordinary course of our business. While management currently believes that resolving claims against us, individually or in the aggregate, will not have a material adverse impact on our financial position, results of operations or statements of cash flows, these matters are subject to inherent uncertainties and management’s view of these matters may change in the future. We accrue for loss contingencies when it is both probable that we will incur the loss and when we can reasonably estimate the amount of the loss or range of loss.  We have recorded $7.8 million with respect to the pending settlement of certain non-ordinary course litigation matters under accrued expenses in our condensed consolidated balance sheet as of April 1, 2023.

[0001628280-23-016653:notes:255]
Oclaro Merger Litigation

[0001628280-23-016653:notes:256]
In connection with our acquisition of Oclaro in 2018, seven lawsuits were filed by purported stockholders of Oclaro challenging the proposed merger (the “Merger”). All but one was voluntarily dismissed after the Oclaro Merger closed.  The remaining lawsuit, SaiSravan B. Karri v. Oclaro, Inc., et al., No. 3:18-cv-03435-JD (the “Karri Lawsuit”), was filed in the United States District Court for the Northern District of California and is styled as a class action.

[0001628280-23-016653:notes:257]
The Karri Lawsuit alleges, among other things, that Oclaro and its directors violated Section 14(a) of the Securities Exchange Act of 1934, as amended (the “Exchange Act”), and Rule 14a-9 promulgated thereunder by disseminating an incomplete and misleading Form S-4, including proxy statement/prospectus. The Karri Lawsuit further alleged that Oclaro’s directors violated Section 20(a) of the Exchange Act by failing to exercise proper control over the person(s) who violated Section 14(a) of the Exchange Act. The plaintiff in the Karri Lawsuit seeks, among other things, damages to be awarded to the plaintiff and any class, if a class is certified, and litigation costs, including attorneys’ fees.

[0001628280-23-016653:notes:258]
After the plaintiff in the Karri Lawsuit was appointed as lead plaintiff and his counsel as lead counsel, the plaintiff filed a first amended complaint on April 15, 2019.  The first amended complaint, also named Lumentum as a defendant but Lumentum has since been dismissed from the action.  On October 8, 2020, the court granted in part and denied in part the defendant’s motion to dismiss the first amended complaint. On December 1, 2020, defendants answered the first amended complaint. On September 17, 2021, lead plaintiff filed a second amended complaint. Defendants moved to stay discovery in light of the second amended complaint. On January 11, 2022, the Court struck the second amended complaint as untimely, terminated defendants’ motions to dismiss as moot, and lifted the stay. The case proceeded through fact and expert discovery.

[0001628280-23-016653:notes:259]
On August 16, 2022, the lead plaintiff moved for class certification and to be appointed class representative. Defendants opposed the motion. The action subsequently was stayed while the parties participated in a mediation. On January 18, 2023, the lead plaintiff filed a Notice of Settlement informing the court of an agreement in principle between the parties for a class-wide settlement of the Karri Lawsuit. On January 24, 2023, in light of the potential settlement, the court vacated all pretrial and trial dates and ordered the lead plaintiff to file a motion for preliminary approval of the settlement by March 17, 2023. The lead plaintiff filed his motion for preliminary approval of the settlement on March 16, 2023, and defendants filed a statement of non-opposition on March 30, 2023.  On April 20, 2023, the court held a hearing on lead plaintiff’s motion for preliminary approval of the settlement.  The court declined to grant lead plaintiff’s motion for preliminary approval and ordered lead plaintiff to file a revised motion by May 22, 2023.  In the event that the settlement does not go forward for any reason, the defendants intend to continue to defend the Karri Lawsuit vigorously.

[0001628280-23-016653:notes:260]
NeoPhotonics Merger Litigation

[0001628280-23-016653:notes:261]
In connection with our acquisition of NeoPhotonics Corporation (“NeoPhotonics”) announced in November 2021, ten lawsuits (the “NeoPhotonics Lawsuits”) were filed by purported stockholders of NeoPhotonics challenging the proposed merger (the “NeoPhotonics Merger”). All of the NeoPhotonics Lawsuits have been dismissed.

[0001628280-23-016653:notes:262]
Indemnifications

[0001628280-23-016653:notes:263]
In the normal course of business, we enter into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown, because claims may be made against us in the future and we may record charges in the future as a result of these indemnification obligations. As of April 1, 2023, we did not have any material indemnification claims that were probable or reasonably possible.

[0001628280-23-016653:notes:264]
Audit Proceedings

[0001628280-23-016653:notes:265]
We are under audit by various domestic and foreign tax authorities with regards to income tax and indirect tax matters. In some, although not all cases, we have reserved for potential adjustments to our provision for income taxes and accrual of indirect taxes that may result from examinations by these tax authorities or final outcomes in judicial proceedings, and we believe that the final outcome of these examinations, agreements or judicial proceedings will not have a material effect on our results of operations. If events occur which indicate payment of these amounts is unnecessary, the reversal of the liabilities would result in the recognition of benefits in the period when we determine the liabilities are no longer necessary. If our estimates of the federal, state, and foreign income tax liabilities and indirect tax liabilities are less than the ultimate assessment, it could result in a further charge to expense.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001628280-23-016653:notes:266]
[same as prior period, unchanged from 0001628280-23-002880:notes:263]

[0001628280-23-016653:notes:267]
[same as prior period, unchanged from 0001628280-23-002880:notes:264]

[0001628280-23-016653:notes:268]
[same as prior period, unchanged from 0001628280-23-002880:notes:265]

[0001628280-23-016653:notes:269]
[same as prior period, unchanged from 0001628280-23-002880:notes:266]

[0001628280-23-016653:notes:270]
[same as prior period, unchanged from 0001628280-23-002880:notes:267]

[0001628280-23-016653:notes:271]
[same as prior period, unchanged from 0001628280-23-002880:notes:268]

[0001628280-23-016653:notes:272]
[same as prior period, unchanged from 0001628280-23-002880:notes:269]

[0001628280-23-016653:notes:273]
[same as prior period, unchanged from 0001628280-23-002880:notes:270]

[0001628280-23-016653:notes:274]
[same as prior period, unchanged from 0001628280-23-002880:notes:271]

[0001628280-23-016653:notes:275]
[same as prior period, unchanged from 0001628280-23-002880:notes:272]

[0001628280-23-016653:notes:276]
[same as prior period, unchanged from 0001628280-23-002880:notes:273]

[0001628280-23-016653:notes:277]
[same as prior period, unchanged from 0001628280-23-002880:notes:274]

[0001628280-23-016653:notes:278]
[same as prior period, unchanged from 0001628280-23-002880:notes:275]

[0001628280-23-016653:notes:279]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 1, 2023 |  | April 2, 2022 |  | April 1, 2023 |  | April 2, 2022 |
| Net revenue: |  |  |  |  |  |  |  |
| OpComms | $ | 335.1 |  |  | $ | 344.2 |  |  | $ | 1,237.3 |  |  | $ | 1,147.6 |  |
| Lasers | 48.3 |  |  | 51.2 |  |  | 158.9 |  |  | 142.9 |  |
| Net revenue | $ | 383.4 |  |  | $ | 395.4 |  |  | $ | 1,396.2 |  |  | $ | 1,290.5 |  |
| Gross profit: |  |  |  |  |  |  |  |
| OpComms | $ | 136.8 |  |  | $ | 168.5 |  |  | $ | 549.8 |  |  | $ | 596.2 |  |
| Lasers | 19.5 |  |  | 27.1 |  |  | 77.6 |  |  | 74.1 |  |
| Total segment gross profit | 156.3 |  |  | 195.6 |  |  | 627.4 |  |  | 670.3 |  |
| Unallocated corporate items: |  |  |  |  |  |  |  |
| Stock-based compensation | (6.9) |  |  | (5.4) |  |  | (19.1) |  |  | (15.2) |  |
| Amortization of acquired intangibles | (18.7) |  |  | (15.6) |  |  | (66.4) |  |  | (47.3) |  |
| Amortization of acquired inventory fair value adjustments | (3.6) |  |  | — |  |  | (17.8) |  |  | — |  |
| Integration related costs | (6.7) |  |  | — |  |  | (9.5) |  |  | — |  |
| Other charges, net (1) | (8.4) |  |  | (7.4) |  |  | (35.2) |  |  | (0.9) |  |
| Gross profit | $ | 112.0 |  |  | $ | 167.2 |  |  | $ | 479.4 |  |  | $ | 606.9 |  |

[0001628280-23-016653:notes:280]
(1)   Other (charges) gains of unallocated corporate items for  the three and nine months ended April 1, 2023 primarily relate to $8.0 million and $27.0 million, respectively, of incremental costs of sales related to components previously acquired from various brokers to satisfy customer demand.

[0001628280-23-016653:notes:281]
Other (charges) gains of unallocated corporate items for the three months ended April 2, 2022 primarily relate to $5.8 million of incremental costs of sales related to components previously acquired from various brokers to satisfy customer demand. Other (charges) gains of unallocated corporate items for the nine months ended April 2, 2022 primarily relate to $5.8 million of incremental cost of sales related to components previously acquired from various brokers to satisfy customer demand, offset by a $5.9 million gain as a result of selling equipment that was no longer needed after we transferred certain product lines to new production facilities in fiscal 2021.

[0001628280-23-016653:notes:282]
[same as prior period, unchanged from 0001628280-23-002880:notes:279]

[0001628280-23-016653:notes:283]
[same as prior period, unchanged from 0001628280-23-002880:notes:280]

[0001628280-23-016653:notes:284]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 1, 2023 |  | April 2, 2022 |  | April 1, 2023 |  | April 2, 2022 |
|  | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States | $ | 68.3 |  |  | 17.8 | % |  | $ | 36.3 |  |  | 9.2 | % |  | $ | 196.0 |  |  | 14.0 | % |  | $ | 115.4 |  |  | 8.9 | % |
| Mexico | 20.5 |  |  | 5.4 |  |  | 42.3 |  |  | 10.7 |  |  | 137.5 |  |  | 9.8 |  |  | 113.6 |  |  | 8.8 |  |
| Other Americas | 1.9 |  |  | 0.5 |  |  | 3.0 |  |  | 0.7 |  |  | 8.0 |  |  | 0.6 |  |  | 7.7 |  |  | 0.6 |  |
| Total Americas | $ | 90.7 |  |  | 23.7 | % |  | $ | 81.6 |  |  | 20.6 | % |  | $ | 341.5 |  |  | 24.4 | % |  | $ | 236.7 |  |  | 18.3 | % |
| Asia-Pacific: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Hong Kong | $ | 46.5 |  |  | 12.1 | % |  | $ | 109.2 |  |  | 27.6 | % |  | $ | 190.0 |  |  | 13.6 | % |  | $ | 366.5 |  |  | 28.4 | % |
| South Korea | 28.5 |  |  | 7.4 |  |  | 50.3 |  |  | 12.7 |  |  | 148.2 |  |  | 10.6 |  |  | 233.3 |  |  | 18.1 |  |
| Japan | 41.8 |  |  | 10.9 |  |  | 44.5 |  |  | 11.3 |  |  | 137.4 |  |  | 9.8 |  |  | 137.3 |  |  | 10.6 |  |
| Thailand | 67.8 |  |  | 17.7 |  |  | 28.2 |  |  | 7.1 |  |  | 203.2 |  |  | 14.6 |  |  | 71.5 |  |  | 5.6 |  |
| Other Asia-Pacific | 61.5 |  |  | 16.0 |  |  | 53.2 |  |  | 13.5 |  |  | 235.1 |  |  | 16.8 |  |  | 161.8 |  |  | 12.5 |  |
| Total Asia-Pacific | $ | 246.1 |  |  | 64.1 | % |  | $ | 285.4 |  |  | 72.2 | % |  | $ | 913.9 |  |  | 65.5 | % |  | $ | 970.4 |  |  | 75.2 | % |
| EMEA | $ | 46.6 |  |  | 12.2 | % |  | $ | 28.4 |  |  | 7.2 | % |  | $ | 140.8 |  |  | 10.1 | % |  | $ | 83.4 |  |  | 6.5 | % |
| Total net revenue | $ | 383.4 |  |  |  |  | $ | 395.4 |  |  |  |  | $ | 1,396.2 |  |  |  |  | $ | 1,290.5 |  |  |  |

[0001628280-23-016653:notes:285]
During the three and nine months ended April 1, 2023, our net revenue from a single customer, which represented 10% or greater of the total net revenue, was concentrated with two customers, who collectively accounted for 23% and 29% of our total net revenue, respectively. During the three and nine months ended April 2, 2022, our net revenue from a single customer, which represented 10% or greater of total net revenue, was concentrated with two customers, who collectively accounted for 38% and 43% of our total net revenue, respectively.

[0001628280-23-016653:notes:286]
As of April 1, 2023, our accounts receivable from a single customer, which represented 10% or greater of the total accounts receivable, was concentrated with two customers, which individually represented 12% and 11% of gross accounts receivable, respectively. As of July 2, 2022, our accounts receivable from a single customer, which represented 10% or greater of the total accounts receivable, was concentrated with two customers, which individually represented 10% and 10% of gross accounts receivable, respectively.

[0001628280-23-016653:notes:287]
[same as prior period, unchanged from 0001628280-23-002880:notes:284]

[0001628280-23-016653:notes:288]
|  | April 1, 2023 |  | July 2, 2022 |
| Property, plant and equipment, net |  |  |  |
| United States | $ | 128.9 |  |  | $ | 107.8 |  |
| Thailand | 134.2 |  |  | 107.6 |  |
| Japan | 93.9 |  |  | 38.9 |  |
| China | 46.5 |  |  | 32.7 |  |
| Other countries | 79.4 |  |  | 73.5 |  |
| Total property, plant and equipment, net | $ | 482.9 |  |  | $ | 360.5 |  |

[0001628280-23-016653:notes:289]
We purchase a portion of our inventory from contract manufacturers and vendors located primarily in Taiwan, Thailand and Malaysia. During the three and nine months ended April 1, 2023, our net inventory purchases from a single contract manufacturer, which represented 10% or greater of our total net inventory purchases, were concentrated with one contract manufacturer, who accounted for 44% and 42% of total net inventory purchases, respectively. During the three and nine months ended April 2, 2022, our net inventory purchases from a single contract manufacturer, which represented 10% or greater of our total net inventory purchases, were concentrated with two contract manufacturers, who collectively accounted for 52% and 58% of total net inventory purchases, respectively.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001628280-23-016653:notes:290]
[same as prior period, unchanged from 0001628280-23-002880:notes:287]

[0001628280-23-016653:notes:291]
[same as prior period, unchanged from 0001628280-23-002880:notes:288]

[0001628280-23-016653:notes:292]
[same as prior period, unchanged from 0001628280-23-002880:notes:289]

[0001628280-23-016653:notes:293]
[same as prior period, unchanged from 0001628280-23-002880:notes:290]

[0001628280-23-016653:notes:294]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 1, 2023 |  | April 2, 2022 |  | April 1, 2023 |  | April 2, 2022 |
| OpComms: |  |  |  |  |  |  |  |  |  |  |  |
| Telecom and Datacom | $ | 293.3 |  | 76.5 | % |  | $ | 243.5 |  | 61.6 | % |  | $ | 1,037.6 |  | 74.3 | % |  | $ | 726.6 |  | 56.3 | % |
| Industrial and Consumer | 41.8 |  | 10.9 | % |  | 100.7 |  | 25.5 | % |  | 199.7 |  | 14.3 | % |  | 421.0 |  | 32.6 | % |
| Total OpComms | $ | 335.1 |  | 87.4 | % |  | $ | 344.2 |  | 87.1 | % |  | $ | 1,237.3 |  | 88.6 | % |  | $ | 1,147.6 |  | 88.9 | % |
| Lasers | 48.3 |  | 12.6 | % |  | 51.2 |  | 12.9 | % |  | 158.9 |  | 11.4 | % |  | 142.9 |  | 11.1 | % |
| Net Revenue | $ | 383.4 |  |  |  | $ | 395.4 |  |  |  | $ | 1,396.2 |  |  |  | $ | 1,290.5 |  |  |

[0001628280-23-016653:notes:295]
[same as prior period, unchanged from 0001628280-23-002880:notes:292]

[0001628280-23-016653:notes:296]
[same as prior period, unchanged from 0001628280-23-002880:notes:293]

[0001628280-23-016653:notes:297]
| Contract balances |  | Balance sheet location |  | April 1, 2023 |  | July 2, 2022 |  | Change |  | Percentage Change |
| Accounts receivable, net |  | Accounts receivable, net |  | $ | 278.0 |  |  | $ | 262.0 |  |  | $ | 16.0 |  |  | 6.1 | % |
| Deferred revenue and customer deposits |  | Other current liabilities |  | $ | 3.4 |  |  | $ | — |  |  | $ | 3.4 |  |  | n/a |
