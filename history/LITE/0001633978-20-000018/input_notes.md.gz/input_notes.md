# LITE notes — 0001633978-20-000018


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001633978-20-000018:notes:1]
[same as prior period, unchanged from 0001633978-20-000008:notes:1]

[0001633978-20-000018:notes:2]
[same as prior period, unchanged from 0001633978-20-000008:notes:2]

[0001633978-20-000018:notes:3]
Lumentum Holdings Inc. (“we,” “us,” “our”, “Lumentum” or the “Company”) is an industry-leading provider of optical and photonic products defined by revenue and market share addressing a range of end market applications including Optical Communications (“OpComms”) and Commercial Lasers (“Lasers”) for manufacturing, inspection and life-science applications. We seek to use our core optical and photonic technology, and our volume manufacturing capability, to expand into attractive emerging markets that benefit from advantages that optical or photonics-based solutions provide, including 3D sensing for consumer electronics and diode light sources for a variety of consumer and industrial applications. The majority of our customers tend to be original equipment manufacturers (“OEMs”) that incorporate our products into their products which then address end-market applications. For example, we sell fiber optic components that network equipment manufacturers (“NEMs”) assemble into communications networking systems, which they sell to network service providers, operators or enterprises with their own networks. Similarly, many of our customers for our Lasers products incorporate our products into tools they produce, which are used for manufacturing processes by their customers. For 3D sensing, we sell diode lasers to manufacturers of consumer electronics products for mobile, personal computing, gaming, and other applications who then integrate our devices within their products, for eventual resale to consumers and also into other industrial applications.

[0001633978-20-000018:notes:4]
[same as prior period, unchanged from 0001633978-20-000008:notes:4]

[0001633978-20-000018:notes:5]
The preparation of the condensed consolidated financial statements in accordance with U.S. generally accepted accounting principles (“GAAP”) requires management to make estimates and assumptions that affect the amounts reported in our condensed consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates. Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are inventory valuation, revenue recognition, income taxes, and goodwill.

[0001633978-20-000018:notes:6]
[same as prior period, unchanged from 0001633978-20-000008:notes:7]

[0001633978-20-000018:notes:7]
[same as prior period, unchanged from 0001633978-20-000008:notes:8]

[0001633978-20-000018:notes:8]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Every fifth or sixth fiscal year will have a 53-week period. The additional week in a 53-week year is added to the third quarter, making such quarter consist of 14 weeks. Our fiscal 2021 is a 53-week year ending on July 3, 2021, with the quarter ended September 26, 2020 being a 13-week quarterly period. Our fiscal 2020 was a 52-week year that ended on June 27, 2020, with the quarter ended September 28, 2019 being a 13-week quarterly period.

[0001633978-20-000018:notes:9]
[same as prior period, unchanged from 0001633978-20-000008:notes:10]

[0001633978-20-000018:notes:10]
[same as prior period, unchanged from 0001633978-20-000008:notes:11]

[0001633978-20-000018:notes:11]
[same as prior period, unchanged from 0001633978-20-000008:notes:13]

[0001633978-20-000018:notes:12]
The accompanying condensed consolidated financial statements and accompanying related notes should be read in conjunction with the audited consolidated financial statements and related notes included in our Annual Report on Form 10-K for the fiscal year ended June 27, 2020. There have been no significant changes to these policies during the three months ended September 26, 2020, except for the removal of the long-lived asset valuation policy and the updates resulting from the adoption of Topic 326, as discussed in “Note 2. Recently Issued Accounting Pronouncements”.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001633978-20-000018:notes:13]
Accounting Pronouncements Recently Adopted

[0001633978-20-000018:notes:14]
In August 2018, FASB issued ASU 2018-13, Fair Value Measurement (Topic 820): Disclosure Framework-Changes to the Disclosure Requirements for Fair Value Measurement. ASU 2018-13 modifies the disclosure requirements on transfers between Level 1 and Level 2, valuation processes of Level 3 fair value measurements, and the categorization by level for items that are not measured at fair value, but for which the fair value is required to be disclosed. We adopted ASU 2018-13 in the first quarter of fiscal 2021 with no impact to our condensed consolidated financial statements.

[0001633978-20-000018:notes:15]
In August 2018, FASB issued ASU 2018-15, Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40): Customer's Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract. This standard requires capitalization of the implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software. Further, the standard also requires the Company to expense the capitalized implementation costs of a hosting arrangement over the term of the hosting arrangement. We adopted ASU 2018-15 in the first quarter of fiscal 2021 with no impact to our condensed consolidated financial statements.

[0001633978-20-000018:notes:16]
In June 2016, FASB issued ASU 2016-13, Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments and a subsequent amendment, ASU 2018-19 (collectively, Topic 326). Topic 326 requires measurement and recognition of expected credit losses for financial assets held. We adopted ASU 2016-13 using the modified-retrospective approach in the first quarter of fiscal 2021 with no material impact to our condensed consolidated financial statements.

[0001633978-20-000018:notes:17]
With the adoption of Topic 326, we are now assessing whether unrealized losses have resulted from a credit loss or other factors. We believe none of our unrealized losses on available-for-sale investments were other-than temporary or were attributable to credit losses as of September 26, 2020 and June 27, 2020. We review our available-for-sale investments on a quarterly basis to identify a potential other-than-temporary impairment. The investments with unrealized losses consisted primarily of corporate debt securities, and given the extent of the unrealized loss positions, the issuers' high credit ratings and the near-term market conditions, we believe our unrealized losses are temporary. We also do not have an intent to sell our investments and would not be required to sell them before they recover.

[0001633978-20-000018:notes:18]
The adoption of Topic 326 did not significantly change our approach to the valuation of trade receivables. We determine whether there is an expected loss on our accounts receivable by reviewing all available data, including our customers' latest available financial statements, their credit standing and historical collection experience, as well as current and future market and economic conditions. As of September 26, 2020 and June 27, 2020, the allowance for credit losses on our trade receivables was $1.8 million for each period presented.

[0001633978-20-000018:notes:19]
Accounting Pronouncements Not Yet Effective

[0001633978-20-000018:notes:20]
In August 2020, FASB issued ASU 2020-06, Debt—Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging—Contracts in Entity’s Own Equity (Subtopic 815-40): Accounting for Convertible Instruments and Contracts in an Entity’s Own Equity, which simplifies the accounting for convertible instruments by removing the separation models for (1) convertible debt with a cash conversion feature and (2) convertible instruments with a beneficial conversion feature. As a result, a convertible debt instrument will be accounted for as a single liability measured at its amortized cost. These changes will reduce reported interest expense and increase reported net income for entities that have issued a convertible instrument that was bifurcated according to previously existing rules. Also, ASU 2020-06 requires the application of the if-converted method for calculating diluted earnings per share and the treasury stock method will be no longer available. The new guidance is effective for fiscal years beginning after December 15, 2021, with early adoption permitted no earlier than fiscal years beginning after December 15, 2020. ASU 2020-06 is effective for us in our first quarter of fiscal year 2023. We are currently evaluating the impact of ASU 2020-06 on our condensed consolidated financial statements.

[0001633978-20-000018:notes:21]
In December 2019, FASB issued ASU 2019-12, Simplifying the Accounting for Income Taxes (Topic 740), which is intended to simplify various aspects related to accounting for income taxes by removing certain exceptions to the general principles in Topic 740 and which also clarifies and amends existing guidance to improve consistent application. ASU 2019-12 is effective for us at the beginning of fiscal year 2022, including interim periods within that reporting period, although early adoption is permitted. We are currently evaluating the impact of ASU 2019-12 on our condensed consolidated financial statements. 
In August 2018, FASB issued ASU 2018-14, Compensation-Retirement Benefits-Defined Benefit Plans-General (Topic 715-20): Disclosure Framework-Changes to the Disclosure Requirements for Defined Benefit Plans. ASU 2018-14 modifies the disclosure requirements for defined benefit pension plans and other post-retirement benefit plans. The new guidance is effective for fiscal years ending after December 15, 2020, with early adoption permitted. ASU 2018-14 should be applied retrospectively to all periods presented and is effective for us in our fourth quarter of fiscal year 2021 as ASU 2018-14 does not amend the interim disclosure requirements.


## us-gaap:EarningsPerShareTextBlock

[0001633978-20-000018:notes:22]
[same as prior period, unchanged from 0001633978-20-000008:notes:35]

[0001633978-20-000018:notes:23]
The following table sets forth the computation of basic and diluted net income per share (in millions, except per share data):

[0001633978-20-000018:notes:24]
|  | Three Months Ended |
|  | September 26, 2020 |  | September 28, 2019 |
| Numerator: |  |  |  |  |  |
| Net income | $ | 67.1 |  |  | $ | 47.6 |  |
| Denominator: |  |  |  |
| Basic weighted average common shares outstanding | 75.3 |  |  | 76.9 |  |
| Effect of dilutive securities from stock-based benefit plans | 0.9 |  |  | 0.7 |  |
| Shares issuable assuming conversion of the 2024 Notes | 2.0 |  |  | — |  |
| Diluted weighted average common shares outstanding | 78.2 |  |  | 77.6 |  |
| Net income per share: |  |  |  |
| Basic | $ | 0.89 |  |  | $ | 0.62 |  |
| Diluted | $ | 0.86 |  |  | $ | 0.61 |  |

[0001633978-20-000018:notes:25]
Potentially dilutive common shares result from the assumed exercise of outstanding stock options, assumed vesting of outstanding equity awards, assumed issuance of stock under the employee stock purchase plan, and assumed conversion of our outstanding convertible notes, all using the treasury stock method.

[0001633978-20-000018:notes:26]
We have the ability and intent to settle the face value of our convertible notes in cash. Therefore, we use the treasury stock method for calculating the dilutive impact of the convertible notes. The 2026 Notes (as defined in Note 9) will have no impact on diluted earnings per share until the average price of our common stock exceeds the conversion price of $99.29. The potentially dilutive shares resulting from the 2024 Notes (as defined in Note 9) were included in the calculation of diluted income per share for the three months ended September 26, 2020 since the average price of our common stock exceeded the conversion price of $60.62. Refer to “Note 9. Debt” for further discussion.

[0001633978-20-000018:notes:27]
Anti-dilutive potential shares are excluded from the calculation of diluted earnings per share if their exercise price exceeded the average market price during the period or the share-based awards were determined to be anti-dilutive based on applying the treasury stock method. Anti-dilutive shares excluded from the calculation of diluted earnings per share were 0.5 million shares and 0.4 million shares for the three months ended September 26, 2020 and September 28, 2019, respectively.


## us-gaap:CashCashEquivalentsAndShortTermInvestmentsTextBlock

[0001633978-20-000018:notes:28]
Note 4. Cash, Cash Equivalents and Short-term Investments

[0001633978-20-000018:notes:29]
[same as prior period, unchanged from 0001633978-20-000008:notes:62]

[0001633978-20-000018:notes:30]
|  | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| September 26, 2020: |  |  |  |  |  |  |  |
| Cash | $ | 135.6 |  |  | $ | — |  |  | $ | — |  |  | $ | 135.6 |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Corporate debt securities | 2.0 |  |  | — |  |  | — |  |  | 2.0 |  |
| Money market funds | 111.2 |  |  | — |  |  | — |  |  | 111.2 |  |
| U.S. Treasury securities | 20.7 |  |  | — |  |  | — |  |  | 20.7 |  |
| Total cash and cash equivalents | $ | 269.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 269.5 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 4.9 |  |  | $ | — |  |  | $ | — |  |  | $ | 4.9 |  |
| Commercial paper | 154.9 |  |  | 0.1 |  |  | — |  |  | 155.0 |  |
| Corporate debt securities | 481.6 |  |  | 1.0 |  |  | (0.2 | ) |  | 482.4 |  |
| U.S. Agency securities | 60.3 |  |  | — |  |  | — |  |  | 60.3 |  |
| U.S. Treasury securities | 638.1 |  |  | 0.5 |  |  | — |  |  | 638.6 |  |
| Total short-term investments | $ | 1,339.8 |  |  | $ | 1.6 |  |  | $ | (0.2 | ) |  | $ | 1,341.2 |  |
| June 27, 2020: |  |  |  |  |  |  |  |
| Cash | $ | 114.2 |  |  | $ | — |  |  | $ | — |  |  | $ | 114.2 |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Money market funds | 159.6 |  |  | — |  |  | — |  |  | 159.6 |  |
| U.S. Treasury securities | 24.2 |  |  | — |  |  | — |  |  | 24.2 |  |
| Total cash and cash equivalents | $ | 298.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 298.0 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 12.9 |  |  | $ | — |  |  | $ | — |  |  | $ | 12.9 |  |
| Commercial paper | 179.9 |  |  | 0.3 |  |  | — |  |  | 180.2 |  |
| Corporate debt securities | 435.0 |  |  | 1.7 |  |  | (0.1 | ) |  | 436.6 |  |
| Foreign government bonds | 1.7 |  |  | — |  |  | — |  |  | 1.7 |  |
| U.S. Agency securities | 59.5 |  |  | — |  |  | — |  |  | 59.5 |  |
| U.S. Treasury securities | 563.9 |  |  | 1.0 |  |  | — |  |  | 564.9 |  |
| Total short-term investments | $ | 1,252.9 |  |  | $ | 3.0 |  |  | $ | (0.1 | ) |  | $ | 1,255.8 |  |

[0001633978-20-000018:notes:31]
We use the specific-identification method to determine any realized gains or losses from the sale of our short-term investments classified as available-for-sale. During the three months ended September 26, 2020 and September 28, 2019, we did not realize significant gains or losses on a gross level from the sale of our short-term investments classified as available-for-sale.

[0001633978-20-000018:notes:32]
During the three months ended September 26, 2020 and September 28, 2019, our other income (expense), net was $0.6 million and $5.0 million, respectively, and includes interest income on cash equivalents and short-term investments of $2.4 million and $4.0 million, respectively.

[0001633978-20-000018:notes:33]
[same as prior period, unchanged from 0001633978-20-000008:notes:66]

[0001633978-20-000018:notes:34]
|  | Less than 12 months |  | 12 Months or Greater |  | Total |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| September 26, 2020: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | 43.3 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 43.3 |  |  | $ | — |  |
| Commercial paper | 37.2 |  |  | — |  |  | — |  |  | — |  |  | 37.2 |  |  | — |  |
| Corporate debt securities | 167.6 |  |  | (0.2 | ) |  | — |  |  | — |  |  | 167.6 |  |  | (0.2 | ) |
| U.S. government bonds | 99.9 |  |  | — |  |  | — |  |  | — |  |  | 99.9 |  |  | — |  |
| Total | $ | 348.0 |  |  | $ | (0.2 | ) |  | $ | — |  |  | $ | — |  |  | $ | 348.0 |  |  | $ | (0.2 | ) |
| June 27, 2020: |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 3.1 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 3.1 |  |  | $ | — |  |
| Commercial paper | 51.1 |  |  | — |  |  | — |  |  | — |  |  | 51.1 |  |  | — |  |
| Corporate debt securities | 96.5 |  |  | (0.1 | ) |  | — |  |  | — |  |  | 96.5 |  |  | (0.1 | ) |
| Foreign government bonds | 1.7 |  |  | — |  |  | — |  |  | — |  |  | 1.7 |  |  | — |  |
| U.S. Agency securities | 47.0 |  |  | — |  |  | — |  |  | — |  |  | 47.0 |  |  | — |  |
| U.S. government bonds | 159.8 |  |  | — |  |  | — |  |  | — |  |  | 159.8 |  |  | — |  |
| Total | $ | 359.2 |  |  | $ | (0.1 | ) |  | $ | — |  |  | $ | — |  |  | $ | 359.2 |  |  | $ | (0.1 | ) |

[0001633978-20-000018:notes:35]
[same as prior period, unchanged from 0001633978-20-000008:notes:68]

[0001633978-20-000018:notes:36]
|  | September 26, 2020 |  | June 27, 2020 |
|  | Amortized Cost |  | Fair Value |  | Amortized Cost |  | Fair Value |
| Due in 1 year | $ | 1,245.9 |  |  | $ | 1,247.1 |  |  | $ | 1,237.4 |  |  | $ | 1,239.9 |  |
| Due in 1 year through 5 years | 93.9 |  |  | 94.1 |  |  | 15.5 |  |  | 15.9 |  |
|  | $ | 1,339.8 |  |  | $ | 1,341.2 |  |  | $ | 1,252.9 |  |  | $ | 1,255.8 |  |

[0001633978-20-000018:notes:37]
[same as prior period, unchanged from 0001633978-20-000008:notes:70]


## us-gaap:FairValueDisclosuresTextBlock

[0001633978-20-000018:notes:38]
Note 5. Fair Value Measurements

[0001633978-20-000018:notes:39]
[same as prior period, unchanged from 0001633978-20-000008:notes:72]

[0001633978-20-000018:notes:40]
[same as prior period, unchanged from 0001633978-20-000008:notes:73]

[0001633978-20-000018:notes:41]
The fair value of our Level 1 financial instruments, such as money market funds and U.S. Treasury securities, which are traded in active markets, is based on quoted market prices for identical instruments. The fair value of our Level 2 fixed income securities

[0001633978-20-000018:notes:42]
is obtained from an independent pricing service, which may use quoted market prices for identical or comparable instruments or model driven valuations using observable market data or inputs corroborated by observable market data. Our marketable securities are held by custodians who obtain investment prices from a third-party pricing provider that incorporates standard inputs in various asset price models. Our procedures include controls to ensure that appropriate fair values are recorded, including comparing the fair values obtained from our pricing service against fair values obtained from another independent source.

[0001633978-20-000018:notes:43]
Financial assets measured at fair value on a recurring basis are summarized below (in millions):

[0001633978-20-000018:notes:44]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| September 26, 2020: (1) |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Corporate debt securities | $ | — |  |  | $ | 2.0 |  |  | $ | — |  |  | $ | 2.0 |  |
| Money market funds | 111.2 |  |  | — |  |  | — |  |  | 111.2 |  |
| U.S. Treasury securities | 20.7 |  |  | — |  |  | — |  |  | 20.7 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | 4.9 |  |  | — |  |  | 4.9 |  |
| Commercial paper | — |  |  | 155.0 |  |  | — |  |  | 155.0 |  |
| Corporate debt securities | — |  |  | 482.4 |  |  | — |  |  | 482.4 |  |
| U.S. Agency securities | — |  |  | 60.3 |  |  | — |  |  | 60.3 |  |
| U.S. Treasury securities | 638.6 |  |  | — |  |  | — |  |  | 638.6 |  |
| Total assets | $ | 770.5 |  |  | $ | 704.6 |  |  | $ | — |  |  | $ | 1,475.1 |  |

[0001633978-20-000018:notes:45]
(1)  Excludes $135.6 million in cash held in our bank accounts at September 26, 2020.

[0001633978-20-000018:notes:46]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| June 27, 2020: (1) |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Money market funds | $ | 159.6 |  |  | $ | — |  |  | $ | — |  |  | $ | 159.6 |  |
| U.S. Treasury securities | 24.2 |  |  | — |  |  | — |  |  | 24.2 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | 12.9 |  |  | — |  |  | 12.9 |  |
| Commercial paper | — |  |  | 180.2 |  |  | — |  |  | 180.2 |  |
| Corporate debt securities | — |  |  | 436.6 |  |  | — |  |  | 436.6 |  |
| Foreign government bonds | — |  |  | 1.7 |  |  | — |  |  | 1.7 |  |
| U.S. Agency securities | — |  |  | 59.5 |  |  | — |  |  | 59.5 |  |
| U.S. Treasury securities | 564.9 |  |  | — |  |  | — |  |  | 564.9 |  |
| Total assets | $ | 748.7 |  |  | $ | 690.9 |  |  | $ | — |  |  | $ | 1,439.6 |  |

[0001633978-20-000018:notes:47]
(1)  Excludes $114.2 million in cash held in our bank accounts as of June 27, 2020.

[0001633978-20-000018:notes:48]
Financial Instruments Not Recorded at Fair Value on a Recurring Basis

[0001633978-20-000018:notes:49]
We report our financial instruments at fair value with the exception of the 2026 Notes and the 2024 Notes. The estimated fair value of the notes was determined based on the trading price of the notes as of the last day of trading for the period. We consider the fair value of the notes to be a Level 2 measurement as they are not actively traded in markets.

[0001633978-20-000018:notes:50]
The carrying amounts and estimated fair values of the 2026 Notes and the 2024 Notes are as follows for the periods presented (in millions):

[0001633978-20-000018:notes:51]
|  | September 26, 2020 |  | June 27, 2020 |
|  | Carrying Amount |  | Estimated Fair Value |  | Carrying Amount |  | Estimated Fair Value |
| 2026 Notes | $ | 759.3 |  |  | $ | 1,114.6 |  |  | $ | 749.7 |  |  | $ | 1,070.2 |  |
| 2024 Notes | 375.4 |  |  | 624.3 |  |  | 370.6 |  |  | 620.0 |  |
|  | $ | 1,134.7 |  |  | $ | 1,738.9 |  |  | $ | 1,120.3 |  |  | $ | 1,690.2 |  |

[0001633978-20-000018:notes:52]
[same as prior period, unchanged from 0001633978-20-000008:notes:81]

[0001633978-20-000018:notes:53]
[same as prior period, unchanged from 0001633978-20-000008:notes:82]

[0001633978-20-000018:notes:54]
Management utilizes various valuation methods, including an income approach, a market approach and a cost approach, to estimate the fair value of intangibles and other long-lived assets. During the annual impairment testing performed in the fourth quarter of fiscal 2020, we concluded that our intangible and other long-lived assets were not impaired. We review our intangible and other long-lived assets for impairment at least annually in the fourth quarter of each fiscal year, absent any interim indicators of impairment.


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0001633978-20-000018:notes:55]
We periodically review our intangible and other long-lived assets for impairment whenever events or changes in circumstances indicate that the carrying amount of such assets may not be recoverable. Determination of recoverability is based on the lowest level of identifiable estimated undiscounted cash flows resulting from use of the asset and its eventual disposition. If not recoverable, an impairment loss would be calculated based on the excess of the carrying amount over the fair value.
Management utilizes various valuation methods, including an income approach, a market approach and a cost approach, to estimate the fair value of intangibles and other long-lived assets.
We determine fair value based on the fair value hierarchy, which requires an entity to maximize the use of observable inputs and minimize the use of unobservable inputs when measuring fair value. Fair value is defined as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. The fair value assumes that the transaction to sell the asset or transfer the liability occurs in the principal or most advantageous market for the asset or liability and establishes that the fair value of an asset or liability shall be determined based on the assumptions that market participants would use in pricing the asset or liability. The classification of a financial asset or liability within the hierarchy is based upon the lowest level input that is significant to the fair value measurement. The fair value hierarchy prioritizes the inputs into three levels that may be used to measure fair value:


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001633978-20-000018:notes:56]
Note 6. Balance Sheet Details

[0001633978-20-000018:notes:57]
Allowance for current expected credit losses

[0001633978-20-000018:notes:58]
We did not have any allowance for credit losses other than our allowance for uncollectible accounts receivable. As of September 26, 2020 and June 27, 2020, the allowance for credit losses on our trade receivables was $1.8 million for each period presented.

[0001633978-20-000018:notes:59]
[same as prior period, unchanged from 0001633978-20-000008:notes:89]

[0001633978-20-000018:notes:60]
[same as prior period, unchanged from 0001633978-20-000008:notes:90]

[0001633978-20-000018:notes:61]
|  | September 26, 2020 |  | June 27, 2020 |
| Raw materials and purchased parts | $ | 56.7 |  |  | $ | 57.9 |  |
| Work in process | 70.6 |  |  | 67.6 |  |
| Finished goods | 85.3 |  |  | 63.4 |  |
| Inventories | $ | 212.6 |  |  | $ | 188.9 |  |

[0001633978-20-000018:notes:62]
[same as prior period, unchanged from 0001633978-20-000008:notes:96]

[0001633978-20-000018:notes:63]
[same as prior period, unchanged from 0001633978-20-000008:notes:97]

[0001633978-20-000018:notes:64]
|  | September 26, 2020 |  | June 27, 2020 |
| Operating lease right-of-use assets | $ | 88.7 |  |  | $ | 90.3 |  |
| Less: accumulated amortization | (14.0 | ) |  | (11.6 | ) |
| Operating lease right-of-use assets, net | $ | 74.7 |  |  | $ | 78.7 |  |

[0001633978-20-000018:notes:65]
[same as prior period, unchanged from 0001633978-20-000008:notes:99]

[0001633978-20-000018:notes:66]
[same as prior period, unchanged from 0001633978-20-000008:notes:100]

[0001633978-20-000018:notes:67]
|  | September 26, 2020 |  | June 27, 2020 |
| Land | $ | 44.1 |  |  | $ | 44.1 |  |
| Buildings and improvement | 117.7 |  |  | 114.8 |  |
| Machinery and equipment | 494.7 |  |  | 487.0 |  |
| Computer equipment and software | 28.1 |  |  | 27.5 |  |
| Furniture and fixtures | 8.2 |  |  | 7.2 |  |
| Leasehold improvements | 28.6 |  |  | 27.8 |  |
| Finance lease right-of-use assets | 28.1 |  |  | 28.1 |  |
| Construction in progress | 51.4 |  |  | 54.7 |  |
|  | 800.9 |  |  | 791.2 |  |
| Less: Accumulated depreciation | (407.5 | ) |  | (398.2 | ) |
| Property, plant and equipment, net | $ | 393.4 |  |  | $ | 393.0 |  |

[0001633978-20-000018:notes:68]
During the three months ended September 26, 2020 and September 28, 2019, we recorded depreciation expense of $23.8 million and $31.6 million, respectively. Included in these amounts were depreciation expense for equipment acquired under finance leases in the amount of $0.2 million and $3.9 million for the three months ended September 26, 2020 and September 28, 2019, respectively.

[0001633978-20-000018:notes:69]
[same as prior period, unchanged from 0001633978-20-000008:notes:106]

[0001633978-20-000018:notes:70]
[same as prior period, unchanged from 0001633978-20-000008:notes:107]

[0001633978-20-000018:notes:71]
[same as prior period, unchanged from 0001633978-20-000008:notes:108]

[0001633978-20-000018:notes:72]
|  | September 26, 2020 |  | June 27, 2020 |
| Restructuring accrual and related charges (1) | $ | 4.4 |  |  | $ | 5.2 |  |
| Warranty accrual (2) | 7.6 |  |  | 5.0 |  |
| Deferred revenue and customer deposits | 2.0 |  |  | 1.9 |  |
| Finance lease liabilities, current | 0.4 |  |  | 0.6 |  |
| Income tax payable (3) | 41.1 |  |  | 28.8 |  |
| Other current liabilities | 2.9 |  |  | 2.8 |  |
| Other current liabilities | $ | 58.4 |  |  | $ | 44.3 |  |

[0001633978-20-000018:notes:73]
(1) Refer to “Note 11. Restructuring and Related Charges.”

[0001633978-20-000018:notes:74]
(2) Refer to “Note 14. Commitments and Contingencies.”

[0001633978-20-000018:notes:75]
(3) Refer to “Note 12. Income Taxes.”

[0001633978-20-000018:notes:76]
[same as prior period, unchanged from 0001633978-20-000008:notes:113]

[0001633978-20-000018:notes:77]
[same as prior period, unchanged from 0001633978-20-000008:notes:114]

[0001633978-20-000018:notes:78]
|  | September 26, 2020 |  | June 27, 2020 |
| Asset retirement obligations | $ | 4.6 |  |  | $ | 4.6 |  |
| Pension accrual | 12.4 |  |  | 11.8 |  |
| Unrecognized tax benefit | 18.2 |  |  | 17.3 |  |
| Other non-current liabilities | 3.6 |  |  | 2.3 |  |
| Other non-current liabilities | $ | 38.8 |  |  | $ | 36.0 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0001633978-20-000018:notes:79]
Note 7. Leases

[0001633978-20-000018:notes:80]
[same as prior period, unchanged from 0001633978-20-000008:notes:118]

[0001633978-20-000018:notes:81]
[same as prior period, unchanged from 0001633978-20-000008:notes:119]

[0001633978-20-000018:notes:82]
As of September 26, 2020, we sublease certain floors of our offices in the United Kingdom, the United States, Canada, and Japan. These subleases will expire at various dates by fiscal year 2023. We anticipate receiving approximately $5.0 million in sublease income over the next three years.

[0001633978-20-000018:notes:83]
[same as prior period, unchanged from 0001633978-20-000008:notes:121]

[0001633978-20-000018:notes:84]
|  | Three Months Ended |
|  | September 26, 2020 |  | September 28, 2019 |
| Finance lease cost (in millions): |  |  |  |
| Amortization of right-of-use assets | $ | 0.2 |  |  | $ | 3.9 |  |
| Interest | — |  |  | 0.1 |  |
| Operating lease cost | 3.6 |  |  | 4.0 |  |
| Variable lease cost | 0.4 |  |  | 0.6 |  |
| Short-term lease cost | 0.7 |  |  | 0.5 |  |
| Sublease income | (0.7 | ) |  | (0.6 | ) |
| Total lease cost | $ | 4.2 |  |  | $ | 8.5 |  |
| Weighted average remaining lease term (in years): |  |  |  |
| Operating leases | 8.2 |  |  | 9.1 |  |
| Finance leases | 0.8 |  |  | 1.1 |  |
| Weighted average discount rate: |  |  |  |
| Operating leases | 3.5 | % |  | 3.5 | % |
| Finance leases | 4.4 | % |  | 4.4 | % |

[0001633978-20-000018:notes:85]
As of September 26, 2020, maturities of our operating and finance lease liabilities, which do not include short-term leases and variable lease payments, were as follows (in millions):

[0001633978-20-000018:notes:86]
| Fiscal Years |  | Operating Leases (1) |  | Finance Leases |  | Total |
| Remainder of 2021 |  | $ | 10.0 |  |  | $ | 0.4 |  |  | $ | 10.4 |  |
| 2022 |  | 12.6 |  |  | — |  |  | 12.6 |  |
| 2023 |  | 11.4 |  |  | — |  |  | 11.4 |  |
| 2024 |  | 9.7 |  |  | — |  |  | 9.7 |  |
| 2025 |  | 6.4 |  |  | — |  |  | 6.4 |  |
| Thereafter |  | 25.8 |  |  | — |  |  | 25.8 |  |
| Total minimum lease payments |  | $ | 75.9 |  |  | $ | 0.4 |  |  | $ | 76.3 |  |
| Less: amount representing interest |  | (9.1 | ) |  | — |  |  | (9.1 | ) |
| Present value of total lease liabilities |  | $ | 66.8 |  |  | $ | 0.4 |  |  | $ | 67.2 |  |

[0001633978-20-000018:notes:87]
(1) Non-cancellable sublease proceeds for the remainder of fiscal 2021, fiscal 2022 and 2023 of $2.1 million, $2.3 million, and $0.6 million, respectively, are not included in the table above.


## us-gaap:GoodwillDisclosureTextBlock

[0001633978-20-000018:notes:88]
Note 8. Goodwill and Other Intangible Assets

[0001633978-20-000018:notes:89]
[same as prior period, unchanged from 0001633978-20-000008:notes:129]

[0001633978-20-000018:notes:90]
The following table presents our goodwill balance by the reportable segments as of September 26, 2020 and June 27, 2020 (in millions):

[0001633978-20-000018:notes:91]
|  | Optical Communications |  | Commercial Lasers |  | Total |
| Balance as of September 26, 2020 and June 27, 2020 | $ | 363.5 |  |  | $ | 5.4 |  |  | $ | 368.9 |  |

[0001633978-20-000018:notes:92]
[same as prior period, unchanged from 0001633978-20-000008:notes:132]

[0001633978-20-000018:notes:93]
We review goodwill for impairment during the fourth quarter of each fiscal year or more frequently if events or circumstances indicate that an impairment loss may have occurred. In the fourth quarter of fiscal 2020, we completed the annual impairment test of goodwill, which indicated there was no goodwill impairment.

[0001633978-20-000018:notes:94]
[same as prior period, unchanged from 0001633978-20-000008:notes:135]

[0001633978-20-000018:notes:95]
[same as prior period, unchanged from 0001633978-20-000008:notes:137]

[0001633978-20-000018:notes:96]
[same as prior period, unchanged from 0001633978-20-000008:notes:138]

[0001633978-20-000018:notes:97]
| September 26, 2020 | Gross Carrying Amounts |  | Accumulated Amortization |  | Net Carrying Amounts |  | Weighted average remaining amortization period (years) |
| Acquired developed technologies | $ | 371.5 |  |  | $ | (191.9 | ) |  | $ | 179.6 |  |  | 3.5 |
| Customer relationships | 149.3 |  |  | (42.8 | ) |  | 106.5 |  |  | 6.2 |
| In-process research and development | 10.0 |  |  | — |  |  | 10.0 |  |  | n/a |
| Order backlog | 22.0 |  |  | (22.0 | ) |  | — |  |  | — |
| Other intangibles | 2.7 |  |  | (2.7 | ) |  | — |  |  | — |
| Total intangible assets | $ | 555.5 |  |  | $ | (259.4 | ) |  | $ | 296.1 |  |  |  |

[0001633978-20-000018:notes:98]
| June 27, 2020 | Gross Carrying Amounts |  | Accumulated Amortization |  | Net Carrying Amounts |  | Weighted average remaining amortization period (years) |
| Acquired developed technologies | $ | 371.5 |  |  | $ | (176.9 | ) |  | $ | 194.6 |  |  | 3.7 |
| Customer relationships | 149.3 |  |  | (37.1 | ) |  | 112.2 |  |  | 6.5 |
| In-process research and development | 10.0 |  |  | — |  |  | 10.0 |  |  | n/a |
| Order backlog | 22.0 |  |  | (22.0 | ) |  | — |  |  | — |
| Other intangibles | 2.7 |  |  | (2.7 | ) |  | — |  |  | — |
| Total intangible assets | $ | 555.5 |  |  | $ | (238.7 | ) |  | $ | 316.8 |  |  |  |

[0001633978-20-000018:notes:99]
[same as prior period, unchanged from 0001633978-20-000008:notes:142]

[0001633978-20-000018:notes:100]
|  | Three Months Ended |
|  | September 26, 2020 |  | September 28, 2019 |
| Cost of sales | $ | 15.0 |  |  | $ | 12.5 |  |
| Selling, general and administrative | 5.7 |  |  | 6.3 |  |
| Total amortization of intangibles | $ | 20.7 |  |  | $ | 18.8 |  |

[0001633978-20-000018:notes:101]
Based on the carrying amount of our acquired developed technologies and other intangibles, excluding IPR&D, as of September 26, 2020, and assuming no future impairment of the underlying assets, the estimated future amortization is as follows (in millions):

[0001633978-20-000018:notes:102]
| Fiscal Years |  |
| Remainder of 2021 | $ | 62.0 |  |
| 2022 | 80.1 |  |
| 2023 | 56.6 |  |
| 2024 | 36.8 |  |
| 2025 | 25.7 |  |
| Thereafter | 24.9 |  |
| Total future amortization | $ | 286.1 |  |


## us-gaap:DebtDisclosureTextBlock

[0001633978-20-000018:notes:103]
Note 9. Debt

[0001633978-20-000018:notes:104]
Convertible Notes

[0001633978-20-000018:notes:105]
2026 Notes

[0001633978-20-000018:notes:106]
In December 2019, we issued $1,050.0 million in aggregate principal amount of the 2026 Notes in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act of 1933, as amended (the “Securities Act”). The 2026 Notes are governed by an indenture between the Company and U.S. Bank National Association (the “2026 Indenture”). We used approximately $196 million of the net proceeds of the offering to repay in full all amounts outstanding under our term loan credit facility, and a portion of the net proceeds of the offering to purchase approximately $200 million of our common stock concurrently with the pricing of the offering in privately negotiated transactions. The 2026 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001633978-20-000018:notes:107]
The 2026 Notes will bear interest at a rate of 0.50% per year, payable semi-annually in arrears on June 15 and December 15 of each year, beginning on June 15, 2020. The 2026 Notes will mature on December 15, 2026, unless earlier redeemed, repurchased by us, or converted pursuant to their terms.

[0001633978-20-000018:notes:108]
The initial conversion rate is 10.0711 shares of common stock per $1,000 principal amount of the 2026 Notes (which is equivalent to an initial conversion price of approximately $99.29 per share). The conversion rate is subject to adjustment upon the occurrence of certain specified events but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert the 2026 Notes in connection with such make-whole fundamental change or notice of redemption.

[0001633978-20-000018:notes:109]
Prior to the close of business on the business day immediately preceding September 15, 2026, holders of the 2026 Notes may convert their 2026 Notes only under the following circumstances:

[0001633978-20-000018:notes:110]
| • | during any fiscal quarter commencing after the fiscal quarter ended on March 28, 2020 (and only during such fiscal quarter), if the last reported sale price of the common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price of the 2026 Notes, or $129.08 on each applicable trading day; |

[0001633978-20-000018:notes:111]
| • | during the five business day period after any five consecutive trading day period (the "2026 measurement period") in which the trading price per $1,000 principal amount of the 2026 Notes for each trading day of the 2026 measurement period was less than 98% of the product of the last reported sale price of our common stock and the conversion rate for the notes on each such trading day; |

[0001633978-20-000018:notes:112]
| • | if we call any or all of the 2026 Notes for redemption, at any time prior to the close of business on the second business day immediately preceding the relevant redemption date; or |

[0001633978-20-000018:notes:113]
| • | upon the occurrence of specified corporate events, as specified in each indenture governing the 2026 Notes. |

[0001633978-20-000018:notes:114]
On or after September 15, 2026 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert the 2026 Notes at any time. Upon conversion, we may satisfy our conversion obligation in cash, shares of common stock or a combination of cash and shares of common stock, at our election.

[0001633978-20-000018:notes:115]
We may redeem for cash, stock or combination of both for all or any portion of the 2026 Notes, at our option, on or after December 20, 2023, if the last reported sale price of its common stock has been at least 130% of the conversion price then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading-day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which we provide a notice of redemption at a redemption price equal to 100% of the principal amount of the 2026 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. No sinking fund is provided for the 2026 Notes. Upon the occurrence of a fundamental change (as defined in the 2026 Indenture), holders may require us to repurchase all or a portion of the 2026 Notes for cash at a price equal to 100% of the principal amount of the 2026 Notes to be repurchased, plus any accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

[0001633978-20-000018:notes:116]
In accordance with accounting for debt with conversions and other options, we bifurcated the principal amount of the 2026 Notes into liability and equity components. The liability component of the 2026 Notes was valued at $734.8 million based on the contractual cash flows discounted at an appropriate comparable market non-convertible debt borrowing rate at the date of issuance of 5.8% with the equity component representing the residual amount of the proceeds of $315.2 million, which was recorded as a debt discount.

[0001633978-20-000018:notes:117]
We incurred approximately $7.8 million in transaction costs in connection with the issuance of the 2026 Notes and these costs were allocated pro rata based on the relative carrying amounts of the liability and equity components. The debt discount and debt issuance costs attributable to the liability component will be amortized to interest expense using an effective interest rate of 5.8% over the expected life of the 2026 Notes. Debt issuance costs attributable to the equity component are netted with the equity component in stockholders’ equity, and the equity component is not remeasured as long as it continues to meet the conditions for equity classification.

[0001633978-20-000018:notes:118]
2024 Notes

[0001633978-20-000018:notes:119]
In March 2017, we issued $450.0 million of the 2024 Notes in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act. The 2024 Notes are governed by an indenture between the Company, as the issuer, and U.S. Bank National Association, as trustee (the “2024 Indenture”). The 2024 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001633978-20-000018:notes:120]
The 2024 Notes bear interest at a rate of 0.25% per year. Interest on the 2024 Notes is payable semi-annually in arrears on March 15 and September 15 of each year, beginning on September 15, 2017. The 2024 Notes will mature on March 15, 2024, unless earlier repurchased by us or converted pursuant to their terms.

[0001633978-20-000018:notes:121]
The initial conversion rate of the 2024 Notes is 16.4965 shares of common stock per $1,000 principal amount of 2024 Notes, which is equivalent to an initial conversion price of approximately $60.62 per share, a 132.5% premium to the fair market value at the date of issuance.  Prior to the close of business on the business day immediately preceding December 15, 2023, each holder of the 2024 Notes may convert their 2024 Notes only under the following circumstances:

[0001633978-20-000018:notes:122]
| • | during any fiscal quarter (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during the period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price, or $78.80 on each applicable trading day; |

[0001633978-20-000018:notes:123]
| • | during the five consecutive business day period after any five consecutive trading day period (the “measurement period”) in which the trading price per $1,000 principal amount of notes for each trading day of such measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate on each such trading day; |

[0001633978-20-000018:notes:124]
| • | upon the occurrence of specified corporate events. |

[0001633978-20-000018:notes:125]
On or after December 15, 2023 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their 2024 Notes at any time. In addition, upon the occurrence of a make-whole fundamental change (as defined in the 2024 Indenture), we will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert 2024 Notes in connection with such make-whole fundamental change.

[0001633978-20-000018:notes:126]
We may not redeem the 2024 Notes prior to their maturity date and no sinking fund is provided for the 2024 Notes. Upon the occurrence of a fundamental change, holders may require us to repurchase all or a portion of their 2024 Notes for cash at a price equal to 100% of the principal amount of the 2024 Notes to be repurchased, plus any accrued and unpaid interest.

[0001633978-20-000018:notes:127]
We considered the features embedded in the 2024 Notes other than the conversion feature, including the holders’ put feature, our call feature, and the make-whole feature, and concluded that they are not required to be bifurcated and accounted for separately from the host debt instrument.

[0001633978-20-000018:notes:128]
Prior to the Tax Matters Agreement settlement condition (“TMA settlement condition”), because we could only settle the 2024 Notes in cash, we determined that the conversion feature met the definition of a derivative liability. We separated the derivative liability from the host debt instrument based on the fair value of the derivative liability. As of the issuance date, March 8, 2017, the derivative liability fair value of $129.9 million was calculated using the binomial valuation approach. The residual principal amount of the 2024 Notes of $320.1 million before issuance costs was allocated to the debt component. We incurred approximately $7.7 million in transaction costs in connection with the issuance of the 2024 Notes. These costs were allocated to the debt component and recognized as a debt discount. We amortize the debt discount, including both the initial value of the derivative liability and the transaction costs, over the term of the 2024 Notes using the effective interest method. The effective interest rate of the 2024 Notes is 5.4% per year.

[0001633978-20-000018:notes:129]
During the fiscal year ended July 1, 2017, we satisfied the TMA settlement condition. As such, the value of the conversion option will no longer be marked to market and was reclassified to additional paid-in capital within stockholders’ equity on our condensed consolidated balance sheet. The value of the conversion option at the time of issuance will be treated as an original issue discount for purposes of accounting for the debt component of the notes. The debt component will accrete up to the principal amount over the expected term of the debt.

[0001633978-20-000018:notes:130]
Our convertible notes consisted of the following components as of the periods presented (in millions):

[0001633978-20-000018:notes:131]
| Liability component: | September 26, 2020 |  | June 27, 2020 |
|  | 2024 Notes |  | 2026 Notes |  | 2024 Notes | 2026 Notes |
| Principal | $ | 450.0 |  |  | $ | 1,050.0 |  |  | $ | 450.0 |  | $ | 1,050.0 |  |
| Unamortized debt discount and debt issuance costs | (74.6 | ) |  | (290.7 | ) |  | (79.4 | ) | (300.3 | ) |
| Net carrying amount of the liability component | $ | 375.4 |  |  | $ | 759.3 |  |  | $ | 370.6 |  | $ | 749.7 |  |

[0001633978-20-000018:notes:132]
During all periods presented, the debt component of our 2024 Notes was recorded in long-term liabilities. However, if the closing price of our stock exceeds $78.80 for 20 of the last 30 trading days of the second quarter of fiscal 2021, the 2024 Notes would become convertible at the option of the holders. Therefore, the debt component of our 2024 Notes (approximately $375 million as of September 26, 2020) would be reclassified to current liabilities in our condensed consolidated balance sheet.

[0001633978-20-000018:notes:133]
The following table sets forth interest expense information related to the convertible notes for the periods presented (in millions):

[0001633978-20-000018:notes:134]
|  | Three Months Ended |
|  | September 26, 2020 |  | September 28, 2019 |
| Contractual interest expense | $ | 1.6 |  |  | $ | 0.3 |  |
| Amortization of the debt discount and debt issuance costs | 14.4 |  |  | 4.6 |  |
| Total interest expense | $ | 16.0 |  |  | $ | 4.9 |  |

[0001633978-20-000018:notes:135]
The future interest and principal payments related to our convertible notes are as follows as of September 26, 2020 (in millions):

[0001633978-20-000018:notes:136]
| Fiscal Years | 2024 Notes |  | 2026 Notes |  | Total |
| Remainder of 2021 | $ | 0.6 |  |  | $ | 5.3 |  |  | $ | 5.9 |  |
| 2022 | 1.1 |  |  | 5.3 |  |  | 6.4 |  |
| 2023 | 1.1 |  |  | 5.3 |  |  | 6.4 |  |
| 2024 | 451.1 |  |  | 5.3 |  |  | 456.4 |  |
| 2025 | — |  |  | 5.3 |  |  | 5.3 |  |
| Thereafter | — |  |  | 1,057.7 |  |  | 1,057.7 |  |
| Total convertible notes payments | $ | 453.9 |  |  | $ | 1,084.2 |  |  | $ | 1,538.1 |  |

[0001633978-20-000018:notes:137]
Term Loan Facility

[0001633978-20-000018:notes:138]
In December 2018, concurrent with the closing of the Oclaro merger, we entered into a credit agreement providing for a term loan facility (the “Term Loan Facility”) in an aggregate principal amount of $500.0 million and we drew in full the term loans available under the Term Loan Facility on the closing date of the Oclaro merger. In fiscal 2020, we repaid, in full, all amounts outstanding under our Term Loan Facility. During the three months ended September 28, 2019, we incurred $6.4 million interest expense on this Term Loan Facility.

[0001633978-20-000018:notes:139]
During the three months ended September 28, 2019, we recorded $0.1 million interest expense related to our finance leases.  Refer to “Note 7. Leases”.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001633978-20-000018:notes:140]
Note 10. Accumulated Other Comprehensive Income (Loss)

[0001633978-20-000018:notes:141]
[same as prior period, unchanged from 0001633978-20-000008:notes:200]

[0001633978-20-000018:notes:142]
The changes in accumulated other comprehensive income (loss) were as follows for the periods as presented (in millions):

[0001633978-20-000018:notes:143]
|  | Foreign currency translation adjustments, net of tax (1) |  | Defined benefit obligations, net of tax (2) |  | Unrealized gain (loss) on available-for-sale securities, net of tax |  | Total |
| Beginning balance as of June 27, 2020 | $ | 9.7 |  |  | $ | (4.2 | ) |  | $ | 2.4 |  |  | $ | 7.9 |  |
| Other comprehensive loss | — |  |  | — |  |  | (1.5 | ) |  | (1.5 | ) |
| Ending balance as of September 26, 2020 | $ | 9.7 |  |  | $ | (4.2 | ) |  | $ | 0.9 |  |  | $ | 6.4 |  |
| Beginning balance as of June 29, 2019 | $ | 9.7 |  |  | $ | (3.5 | ) |  | $ | 0.9 |  |  | $ | 7.1 |  |
| Other comprehensive income | — |  |  | — |  |  | 0.1 |  |  | 0.1 |  |
| Ending balance as of September 28, 2019 | $ | 9.7 |  |  | $ | (3.5 | ) |  | $ | 1.0 |  |  | $ | 7.2 |  |

[0001633978-20-000018:notes:144]
[same as prior period, unchanged from 0001633978-20-000008:notes:203]

[0001633978-20-000018:notes:145]
(2) We evaluate the assumptions over the fair value of our defined benefit obligations annually and make changes as necessary.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001633978-20-000018:notes:146]
Note 11. Restructuring and Related Charges

[0001633978-20-000018:notes:147]
In previous years we have initiated various strategic restructuring actions primarily intended to reduce costs, consolidate our operations, rationalize the manufacturing of our products and align our business in response to market conditions and as a result of our acquisition of Oclaro in fiscal 2019.

[0001633978-20-000018:notes:148]
The following table summarizes the activity of restructuring and related charges during the three months ended September 26, 2020 and September 28, 2019 (in millions):

[0001633978-20-000018:notes:149]
|  | Three Months Ended |
|  | September 26, 2020 |  | September 28, 2019 |
| Balance as of beginning of period | $ | 5.2 |  |  | $ | 14.6 |  |
| Charges | — |  |  | 1.3 |  |
| Payments | (0.8 | ) |  | (5.2 | ) |
| Balance as of end of period | $ | 4.4 |  |  | $ | 10.7 |  |

[0001633978-20-000018:notes:150]
During the three months ended September 26, 2020, we did not record any restructuring and related charges in our condensed consolidated statements of operations. The payments of $0.8 million during the three months ended September 26, 2020 were mainly attributable to previously recognized severance charges associated with the decision to move certain manufacturing from San Jose, California to our facility in Thailand and other third party vendors.

[0001633978-20-000018:notes:151]
During the three months ended September 28, 2019, we recorded restructuring and related charges of $1.3 million attributable to severance charges associated with ongoing acquisition related synergies.

[0001633978-20-000018:notes:152]
[same as prior period, unchanged from 0001633978-20-000008:notes:212]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001633978-20-000018:notes:153]
Note 12. Income Taxes

[0001633978-20-000018:notes:154]
[same as prior period, unchanged from 0001633978-20-000008:notes:214]

[0001633978-20-000018:notes:155]
We recorded a tax provision of $16.5 million and $5.8 million for the three months ended September 26, 2020 and September 28, 2019, respectively. Our tax provision for the three months ended September 26, 2020 includes a discrete tax benefit of $0.9 million mainly from the excess benefit related to certain stock based compensation that vested during the quarter. Our estimated effective tax rate for fiscal 2021 differs from the 21% U.S. statutory rate primarily due to the earnings of our foreign subsidiaries being taxed at rates that differ from the U.S. statutory rate as well as the U.S. federal R&D tax credits, partially offset by the income tax expense from non-deductible stock-based compensation and the tax effect of Global Intangible Low-Taxed Income (“GILTI”), net of a benefit for foreign tax credits, Base Erosion and Anti-Abuse Tax (“BEAT”), and subpart F inclusion.

[0001633978-20-000018:notes:156]
As of September 26, 2020, we had $27.9 million of unrecognized tax benefits, which, if recognized, would affect the effective tax rate. We are subject to examination of income tax returns by various domestic and foreign tax authorities. The timing of commencement, resolution and closure of tax audits is highly unpredictable. Although it is possible that certain ongoing tax audits may be concluded within the next 12 months, we cannot reasonably estimate the impact to tax expense and net income from tax exams that could be resolved or closed within the next 12 months. Subject to audit timing and uncertainty, we expect our unrecognized tax benefit amount that could affect the effective tax rate to decrease by $5.1 million over the next 12 months.

[0001633978-20-000018:notes:157]
[same as prior period, unchanged from 0001633978-20-000008:notes:217]


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001633978-20-000018:notes:158]
Note 13. Equity

[0001633978-20-000018:notes:159]
Description of Lumentum Stock-Based Benefit Plans

[0001633978-20-000018:notes:160]
Equity Incentive Plan

[0001633978-20-000018:notes:161]
As of September 26, 2020, we had 2.6 million shares subject to restricted stock units and performance stock units issued and outstanding under the 2015 Equity Incentive Plan (the “2015 Plan”). Restricted stock units and performance stock units are performance-based, time-based or a combination of both. The fair value of these grants is based on the closing market price of our common stock on the date of award.

[0001633978-20-000018:notes:162]
As of September 26, 2020, 2.3 million shares of common stock under the 2015 Plan were available for grant.

[0001633978-20-000018:notes:163]
Replacement Awards

[0001633978-20-000018:notes:164]
In connection with the acquisition of Oclaro, we issued equity awards to Oclaro employees (“replacement awards”) in exchange for their Oclaro equity awards. As of September 26, 2020, we had 0.2 million of unvested shares subject to restricted stock units under the replacement awards.

[0001633978-20-000018:notes:165]
Restricted Stock Units

[0001633978-20-000018:notes:166]
Restricted stock units (“RSUs”) under the 2015 Plan are grants of shares of our common stock, the vesting of which is based on the requisite service requirement. Generally, our RSUs are subject to forfeiture and are expected to vest over one to four years. For annual refresh grants, RSUs generally vest ratably on an annual, or combination of annual and quarterly, basis over three years.

[0001633978-20-000018:notes:167]
Performance Stock Units

[0001633978-20-000018:notes:168]
Performance stock units (“PSUs”) under the 2015 Plan are grants of shares of our common stock that vest upon the achievement of certain performance and service conditions. We begin recognizing compensation expense when we conclude that it is probable that the performance conditions will be achieved. We reassess the probability of vesting at each reporting period and adjust our compensation cost based on this probability assessment. Our PSUs are subject to risk of forfeiture until performance and service conditions are satisfied and generally vest over three years.

[0001633978-20-000018:notes:169]
Employee Stock Purchase Plan

[0001633978-20-000018:notes:170]
Our 2015 Employee Stock Purchase Plan (the “2015 Purchase Plan”) provides eligible employees with the opportunity to acquire an ownership interest in the Company through periodic payroll deductions and provides a 15% purchase price discount as well as a six-month look-back period. The 2015 Purchase Plan is structured as a qualified employee stock purchase plan under Section 423 of the Internal Revenue Code of 1986, as amended. The 2015 Purchase Plan will terminate upon the date on which all shares available for issuance have been sold. Of the 3.0 million shares authorized under the 2015 Purchase Plan, 1.8 million shares remained available for issuance as of September 26, 2020.

[0001633978-20-000018:notes:171]
Stock-Based Compensation

[0001633978-20-000018:notes:172]
The impact on our results of operations of recording stock-based compensation by function for the three months ended September 26, 2020 and September 28, 2019 was as follows (in millions):

[0001633978-20-000018:notes:173]
|  | Three Months Ended |
|  | September 26, 2020 |  | September 28, 2019 |
| Cost of sales | $ | 3.7 |  |  | $ | 4.2 |  |
| Research and development | 4.4 |  |  | 3.8 |  |
| Selling, general and administrative | 11.4 |  |  | 8.7 |  |
| Total stock-based compensation | $ | 19.5 |  |  | $ | 16.7 |  |

[0001633978-20-000018:notes:174]
Total income tax benefit associated with stock-based compensation recognized in our consolidated statements of operations during the years presented was as follows (in millions):

[0001633978-20-000018:notes:175]
|  | Three Months Ended |
|  | September 26, 2020 |  | September 28, 2019 |
| Income tax benefit associated with stock-based compensation | $ | 5.3 |  |  | $ | 2.8 |  |

[0001633978-20-000018:notes:176]
Approximately $4.4 million and $3.6 million of stock-based compensation was capitalized to inventory as of September 26, 2020 and June 27, 2020, respectively.

[0001633978-20-000018:notes:177]
Stock Award Activity

[0001633978-20-000018:notes:178]
The following table summarizes our awards activity for the three months ended September 26, 2020 (in millions, except per share amounts):

[0001633978-20-000018:notes:179]
|  |  | Restricted Stock Units |  | Performance Stock Units |
|  |  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |
| Balance as of June 27, 2020 |  | 1.9 |  |  | $ | 56.6 |  |  | 0.3 |  |  | $ | 60.6 |  |
| Granted |  | 1.0 |  |  | 86.8 |  |  | 0.2 |  |  | 86.7 |  |
| Vested |  | (0.5 | ) |  | 55.6 |  |  | (0.1 | ) |  | 57.5 |  |
| Canceled (1) |  | — |  |  | 60.2 |  |  | — |  |  | 58.7 |  |
| Balance as of September 26, 2020 |  | 2.4 |  |  | $ | 70.1 |  |  | 0.4 |  |  | $ | 72.4 |  |

[0001633978-20-000018:notes:180]
(1) Less than 0.05 million shares were canceled for the period presented.

[0001633978-20-000018:notes:181]
As of September 26, 2020, we also have less than 0.01 million shares of outstanding options, which are not presented in the table above.

[0001633978-20-000018:notes:182]
As of September 26, 2020, $186.0 million of stock-based compensation cost related to awards granted to our employees remains to be amortized. That cost is expected to be recognized over an estimated amortization period of 2.2 years.

[0001633978-20-000018:notes:183]
A summary of awards available for grant is as follows (in millions):

[0001633978-20-000018:notes:184]
|  | Awards Available for Grant |
| Balance as of June 27, 2020 | 3.5 |  |
| Granted | (1.2 | ) |
| Balance as of September 26, 2020 | 2.3 |  |

[0001633978-20-000018:notes:185]
Employee Stock Purchase Plan Activity
The 2015 Purchase Plan expense for each of the three months ended September 26, 2020 and September 28, 2019 was $1.1 million and $0.9 million, respectively. The expense related to the 2015 Purchase Plan is recorded on a straight-line basis over the relevant subscription period. During the three months ended September 26, 2020 and September 28, 2019, there were no shares issued to employees through the 2015 Purchase Plan.


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0001633978-20-000018:notes:186]
Note 14. Commitments and Contingencies

[0001633978-20-000018:notes:187]
Purchase Obligations

[0001633978-20-000018:notes:188]
Purchase obligations of $257.9 million as of September 26, 2020, represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements.

[0001633978-20-000018:notes:189]
Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule and adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

[0001633978-20-000018:notes:190]
We depend on a limited number of contract manufacturers, subcontractors and suppliers for raw materials, packages and standard components. We generally purchase these single or limited source products through standard purchase orders or one-year supply agreements and have no significant long-term guaranteed supply agreements with such vendors. While we seek to maintain a sufficient safety stock of such products and maintain on-going communications with our suppliers to guard against interruptions or cessation of supply, our business and results of operations could be adversely affected by a stoppage or delay of supply, substitution of more expensive or less reliable products, receipt of defective parts or contaminated materials, increases in the price of such supplies, or our inability to obtain reduced pricing from our suppliers in response to competitive pressures.

[0001633978-20-000018:notes:191]
Product Warranties

[0001633978-20-000018:notes:192]
We provide reserves for the estimated costs of product warranties at the time revenue is recognized. We typically offer a twelve month warranty for most of our products. However, in some instances depending upon the product, product components or application of our products by the end customer, our warranties can vary and generally range from six months to five years. We estimate the costs of our warranty obligations on an annualized basis based on our historical experience of known product failure rates, use of materials to repair or replace defective products and service delivery costs incurred in correcting product failures. In addition, from time to time, specific warranty accruals may be made if unforeseen technical problems arise with specific products. We assess the adequacy of our recorded warranty liabilities and adjust the amounts as necessary.

[0001633978-20-000018:notes:193]
The following table presents the changes in our warranty reserve during the three months ended September 26, 2020 and September 28, 2019 (in millions):

[0001633978-20-000018:notes:194]
|  | Three Months Ended |
|  | September 26, 2020 |  | September 28, 2019 |
| Balance as of beginning of period | $ | 5.0 |  |  | $ | 7.5 |  |
| Provision for warranty | 3.9 |  |  | 1.2 |  |
| Utilization of reserve | (1.3 | ) |  | (1.7 | ) |
| Balance as of end of period | $ | 7.6 |  |  | $ | 7.0 |  |

[0001633978-20-000018:notes:195]
Environmental Liabilities

[0001633978-20-000018:notes:196]
Our research and development (“R&D”), manufacturing and distribution operations involve the use of hazardous substances and are regulated under international, federal, state and local laws governing health and safety and the environment. We apply strict standards for protection of the environment and occupational health and safety to sites inside and outside the United States, even if not subject to regulations imposed by foreign governments. We believe that our properties and operations at our facilities comply in all material respects with applicable environmental laws and occupational health and safety laws. However, the risk of environmental liabilities cannot be completely eliminated and there can be no assurance that the application of environmental and health and safety laws will not require us to incur significant expenditures. We are also regulated under a number of international, federal, state and local laws regarding recycling, product packaging and product content requirements. The environmental, product content/disposal and recycling laws are gradually becoming more stringent and may cause us to incur significant expenditures in the future.

[0001633978-20-000018:notes:197]
Legal Proceedings

[0001633978-20-000018:notes:198]
We are subject to a variety of claims and suits that arise from time to time in the ordinary course of our business. While management currently believes that resolving claims against us, individually or in the aggregate, will not have a material adverse impact on our financial position, results of operations or statements of cash flows, these matters are subject to inherent uncertainties and management’s view of these matters may change in the future. We accrue for loss contingencies when it is both probable that we will incur the loss and when we can reasonably estimate the amount of the loss or range of loss.

[0001633978-20-000018:notes:199]
Merger Litigation

[0001633978-20-000018:notes:200]
In connection with our acquisition of Oclaro, seven lawsuits were filed by purported stockholders of Oclaro challenging the proposed merger (the “Merger”). Two of the seven suits were putative class actions filed against Oclaro, its directors, Lumentum, Prota Merger Sub, Inc. and Prota Merger, LLC: Nicholas Neinast v. Oclaro, Inc., et al., No. 3:18-cv-03112-VC, in the United States District Court for the Northern District of California (filed May 24, 2018) (the “Neinast Lawsuit”); and Adam Franchi v. Oclaro, Inc., et al., No. 1:18-cv-00817-GMS, in the United States District Court for the District of Delaware (filed June 9, 2018) (the “Franchi Lawsuit”). Both the Neinstat Lawsuit and the Franchi Lawsuit were voluntarily dismissed with prejudice.

[0001633978-20-000018:notes:201]
The other five suits, styled as Gerald F. Wordehoff v. Oclaro, Inc., et al., No. 5:18-cv-03148-NC (the “Wordehoff Lawsuit”), Walter Ryan v. Oclaro, Inc., et al., No. 3:18-cv-03174-VC (the “Ryan Lawsuit”), Jayme Walker v. Oclaro, Inc., et al., No. 5:18-cv-03203-EJD (the “Walker Lawsuit”), Kevin Garcia v. Oclaro, Inc., et al., No. 5:18-cv-03262-VKD (the “Garcia Lawsuit”), and SaiSravan B. Karri v. Oclaro, Inc., et al., No. 3:18-cv-03435-JD (the “Karri Lawsuit” and, together with the other six lawsuits, the “Lawsuits”), were filed in the United States District Court for the Northern District of California on May 25, 2018, May 29, 2018, May 30, 2018, May 31, 2018, and June 9, 2018, respectively. These five Lawsuits named Oclaro and its directors as defendants only and did not name Lumentum. The Wordehoff, Ryan, Walker, and Garcia Lawsuits have been voluntarily dismissed, and the Wordehoff, Ryan, and Walker dismissals were with prejudice. The Karri Lawsuit has not yet been dismissed. The Ryan Lawsuit was, and the Karri Lawsuit is, a putative class action.

[0001633978-20-000018:notes:202]
The Lawsuits generally alleged, among other things, that Oclaro and its directors violated Section 14(a) of the Securities Exchange Act of 1934, as amended (the “Exchange Act”), and Rule 14a-9 promulgated thereunder by disseminating an incomplete and misleading Form S-4, including proxy statement/prospectus. The Lawsuits further alleged that Oclaro’s directors violated Section 20(a) of the Exchange Act by failing to exercise proper control over the person(s) who violated Section 14(a) of the Exchange Act.

[0001633978-20-000018:notes:203]
The remaining Lawsuit (the Karri Lawsuit) currently purports to seek, among other things, damages to be awarded to the plaintiff and any class, if a class is certified, and litigation costs, including attorneys’ fees.  A lead plaintiff and counsel has been selected, and an amended complaint was filed on April 15, 2019, which also names Lumentum as a defendant. A motion to dismiss the amended complaint was granted in part and denied in part by the court on October 8, 2020. The Karri Lawsuit remains pending, and the court ordered the parties to submit a joint proposed schedule by October 30, 2020. Defendants intend to defend the Karri Lawsuit vigorously.

[0001633978-20-000018:notes:204]
Indemnifications

[0001633978-20-000018:notes:205]
In the normal course of business, we enter into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown because claims may be made against us in the future and we may record charges in the future as a result of these indemnification obligations. As of September 26, 2020, we did not have any material indemnification claims that were probable or reasonably possible.

[0001633978-20-000018:notes:206]
Audit Proceedings

[0001633978-20-000018:notes:207]
We are under audit by various domestic and foreign tax authorities with regards to income tax and indirect tax matters. In some, although not all cases, we have reserved for potential adjustments to our provision for income taxes and accrual of indirect taxes that may result from examinations by these tax authorities or final outcomes in judicial proceedings, and we believe that the final outcome of these examinations, agreements or judicial proceedings will not have a material effect on our results of operations. If events occur which indicate payment of these amounts is unnecessary, the reversal of the liabilities would result in the recognition of benefits in the period we determine the liabilities are no longer necessary. If our estimates of the federal, state, and foreign income tax liabilities and indirect tax liabilities are less than the ultimate assessment, it could result in a further charge to expense.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001633978-20-000018:notes:208]
Note 15. Operating Segments and Geographic Information

[0001633978-20-000018:notes:209]
[same as prior period, unchanged from 0001633978-20-000008:notes:276]

[0001633978-20-000018:notes:210]
We are an industry leading provider of optical and photonic products defined by revenue and market share addressing a range of end-market applications including optical communications and commercial lasers. We have two operating segments, Optical Communications, which we refer to as OpComms, and Commercial Lasers, which we refer to as Lasers. Our OpComms products address the following markets: telecommunications and data communications (“Telecom and Datacom”), and consumer and industrial (“Consumer and Industrial”), and include product lines from the acquisition of Oclaro. The two operating segments were primarily determined based on how the CODM views and evaluates our operations. Operating results are regularly reviewed by the CODM to make decisions about resources to be allocated to the segments and to assess their performance. Other factors, including market separation and customer specific applications, go-to-market channels, products and manufacturing, are considered in determining the formation of these operating segments.

[0001633978-20-000018:notes:211]
OpComms

[0001633978-20-000018:notes:212]
Our OpComms products include a wide range of components, modules and subsystems to support customers including carrier networks for access (local), metro (intracity), long-haul (city-to-city and worldwide) and submarine (undersea) applications. Additionally, our products address enterprise, cloud, and data center applications, including storage-access networks (“SANs”), local-area networks (“LANs”) and wide-area networks (“WANs”). These products enable the transmission and transport of video, audio and data over high-capacity fiber-optic cables. We maintain leading positions in these fast growing OpComms markets through our extensive product portfolio, including reconfigurable optical add/drop multiplexers (“ROADMs”), coherent dense wavelength division multiplexing (“DWDM”) pluggable transceivers, and tunable small form-factor pluggable transceivers. We also sell laser chips for use in the manufacture of high-speed Datacom transceivers.

[0001633978-20-000018:notes:213]
In the Consumer and Industrial market, our OpComms diode laser products include vertical cavity surface emitting lasers (“VCSELs”) and edge emitting lasers. In the Consumer end-market, our laser light sources are integrated into 3D sensing cameras which are used in applications in mobile devices, gaming, payment kiosks, computers, and other consumer electronics devices. Applications include biometric identification, computational photography, virtual and augmented reality, and natural user interfaces. Emerging applications for our lasers include automotive safety systems, LiDAR for advanced driver assistance systems in automobiles and autonomous vehicles, self-navigating robotics and drones in industrial applications, and 3D capture of objects coupled with 3D imaging or printing. In the Industrial end-market, our diode lasers are used primarily as pump sources for pulsed and kilowatt class fiber lasers.

[0001633978-20-000018:notes:214]
Lasers

[0001633978-20-000018:notes:215]
Our Lasers products serve our customers in markets and applications such as sheet metal processing, general manufacturing, biotechnology, graphics and imaging, remote sensing, and precision machining such as drilling in printed circuit boards, wafer singulation, glass cutting and solar cell scribing.

[0001633978-20-000018:notes:216]
Our Lasers products are used in a variety of OEM applications including diode-pumped solid-state, fiber, diode, direct-diode and gas lasers such as argon-ion and helium-neon lasers. Fiber lasers provide kW-class output powers combined with excellent beam quality and are used in sheet metal processing and metal welding applications. Diode-pumped solid-state lasers provide excellent beam quality, low noise and exceptional reliability and are used in biotechnology, graphics and imaging, remote sensing, materials processing and precision machining applications. Diode and direct-diode lasers address a wide variety of applications, including laser pumping, thermal exposure, illumination, ophthalmology, image recording, printing, plastic welding and selective soldering. Gas lasers such as argon-ion and helium-neon lasers provide a stable, low-cost and reliable solution over a wide range of operating conditions, making them well-suited for complex, high-resolution OEM applications such as flow cytometry, DNA sequencing, graphics and imaging and semiconductor inspection.

[0001633978-20-000018:notes:217]
We also provide high-powered and ultrafast lasers for the industrial and scientific markets. Manufacturers use high-power, ultrafast lasers to create micro parts for consumer electronics and to process semiconductor, LED, and other types of chips. Use of ultrafast lasers for micromachining applications is being driven primarily by the increasing use of consumer electronics and connected devices globally.

[0001633978-20-000018:notes:218]
[same as prior period, unchanged from 0001633978-20-000008:notes:278]

[0001633978-20-000018:notes:219]
[same as prior period, unchanged from 0001633978-20-000008:notes:279]

[0001633978-20-000018:notes:220]
|  | Three Months Ended |
|  | September 26, 2020 |  | September 28, 2019 |
| Net revenue: |  |  |  |
| OpComms | $ | 428.5 |  |  | $ | 416.1 |  |
| Lasers | 23.9 |  |  | 33.8 |  |
| Net revenue | $ | 452.4 |  |  | $ | 449.9 |  |
| Gross profit: |  |  |  |
| OpComms | $ | 224.8 |  |  | $ | 191.9 |  |
| Lasers | 10.4 |  |  | 14.2 |  |
| Total segment gross profit | 235.2 |  |  | 206.1 |  |
| Unallocated corporate items: |  |  |  |
| Stock-based compensation | (3.7 | ) |  | (4.2 | ) |
| Amortization of acquired intangibles | (15.0 | ) |  | (12.5 | ) |
| Amortization of fair value adjustments | — |  |  | (2.2 | ) |
| Inventory and fixed asset write down due to product lines exit | (0.3 | ) |  | (1.1 | ) |
| Integration related costs | — |  |  | (3.4 | ) |
| Other charges (1) | (10.5 | ) |  | (15.0 | ) |
| Gross profit | $ | 205.7 |  |  | $ | 167.7 |  |

[0001633978-20-000018:notes:221]
(1) “Other charges” of unallocated corporate items for the three months ended September 26, 2020 and September 28, 2019 primarily include costs of transferring product lines to new production facilities, including Thailand of $2.1 million and $4.8 million, respectively. We also incurred excess and obsolete inventory charges driven by U.S. trade restrictions and the related decline in demand from Huawei of $5.9 million and $6.7 million during the three months ended September 26, 2020 and September 28, 2019, respectively.

[0001633978-20-000018:notes:222]
[same as prior period, unchanged from 0001633978-20-000008:notes:283]

[0001633978-20-000018:notes:223]
[same as prior period, unchanged from 0001633978-20-000008:notes:284]

[0001633978-20-000018:notes:224]
The table below discloses our total net revenue attributable to each of our two reportable segments. In addition, the table sets forth the percentage of our total net revenue attributable to our product offerings which serve Telecom and Datacom, and Consumer and Industrial markets which accounted for 10% or more of our total net revenue during the periods presented (in millions, except percentage data):

[0001633978-20-000018:notes:225]
|  | Three Months Ended |
|  | September 26, 2020 |  | September 28, 2019 |
| OpComms: |  |  |  |  |  |
| Telecom and Datacom | $ | 261.3 |  | 57.7 | % |  | $ | 248.1 |  | 55.2 | % |
| Consumer and Industrial | 167.2 |  | 37.0 |  |  | 168.0 |  | 37.3 |  |
| Total OpComms | $ | 428.5 |  | 94.7 | % |  | $ | 416.1 |  | 92.5 | % |
| Lasers | 23.9 |  | 5.3 |  |  | 33.8 |  | 7.5 |  |
| Total Revenue | $ | 452.4 |  |  |  |  | $ | 449.9 |  |  |

[0001633978-20-000018:notes:226]
[same as prior period, unchanged from 0001633978-20-000008:notes:287]

[0001633978-20-000018:notes:227]
|  | Three Months Ended |
|  | September 26, 2020 |  | September 28, 2019 |
| Net revenue: | Amount |  | % of Total |  | Amount |  | % of Total |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |
| United States | $ | 20.3 |  |  | 4.5 | % |  | $ | 36.9 |  |  | 8.3 | % |
| Mexico | 39.8 |  |  | 8.8 |  |  | 28.9 |  |  | 6.4 |  |
| Other Americas | 2.8 |  |  | 0.6 |  |  | 1.1 |  |  | 0.2 |  |
| Total Americas | $ | 62.9 |  |  | 13.9 | % |  | $ | 66.9 |  |  | 14.9 | % |
| Asia-Pacific: |  |  |  |  |  |  |  |  |  |  |  |
| Hong Kong | $ | 144.4 |  |  | 31.9 | % |  | $ | 133.8 |  |  | 29.7 | % |
| Philippines | 62.8 |  |  | 13.9 |  |  | 25.0 |  |  | 5.6 |  |
| South Korea | 56.0 |  |  | 12.4 |  |  | 91.6 |  |  | 20.4 |  |
| Other Asia-Pacific | 91.6 |  |  | 20.2 |  |  | 100.3 |  |  | 22.2 |  |
| Total Asia-Pacific | $ | 354.8 |  |  | 78.4 | % |  | $ | 350.7 |  |  | 77.9 | % |
| EMEA | $ | 34.7 |  |  | 7.7 | % |  | $ | 32.3 |  |  | 7.2 | % |
| Total net revenue | $ | 452.4 |  |  |  |  |  | $ | 449.9 |  |  |  |  |

[0001633978-20-000018:notes:228]
During the three months ended September 26, 2020 compared to the three months ended September 28, 2019, our net revenue from the Philippines grew due to an introduction of a new product to one of our large customers, while our net revenue from South Korea declined due to a change in shipment destination for some shipments to one of our large customers.

[0001633978-20-000018:notes:229]
[same as prior period, unchanged from 0001633978-20-000008:notes:292]

[0001633978-20-000018:notes:230]
The following table includes estimated revenue expected to be recognized in the future for backlog related performance obligations that are unsatisfied as of September 26, 2020 (in millions):

[0001633978-20-000018:notes:231]
|  | Less than 1 year | 1-2 years | Greater than 2 years | Total |
| Performance obligations | $542.5 | $43.4 | $— | $585.9 |

[0001633978-20-000018:notes:232]
[same as prior period, unchanged from 0001633978-20-000008:notes:295]

[0001633978-20-000018:notes:233]
The following table reflects the changes in contract balances as of September 26, 2020 (in millions, except percentages):

[0001633978-20-000018:notes:234]
| Contract balances | Balance sheet location | September 26, 2020 |  | June 27, 2020 |  | Change |  | Percentage Change |
| Accounts receivable, net | Accounts receivable, net | $263.6 |  | $233.5 |  | $30.1 |  | 12.9% |
| Deferred revenue and customer deposits | Other current liabilities | $2.0 |  | $1.9 |  | $0.1 |  | 5.3% |

[0001633978-20-000018:notes:235]
During the three months ended September 26, 2020, our net revenue from a single customer, which represented 10% or greater of total net revenue was concentrated with one customer, who accounted for 35% of our total net revenue.

[0001633978-20-000018:notes:236]
During the three months ended September 28, 2019, our net revenue from a single customer, which represented 10% or greater of total net revenue was concentrated with three customers, who collectively accounted for 58% of our total net revenue.

[0001633978-20-000018:notes:237]
As of September 26, 2020, our accounts receivable balance was concentrated with three customers, which individually represented 10% or greater of gross accounts receivable and collectively accounted for 38% of the balance. As of June 27, 2020, one customer represented 10% or greater of gross accounts receivable and accounted for 14% of the balance.

[0001633978-20-000018:notes:238]
[same as prior period, unchanged from 0001633978-20-000008:notes:301]

[0001633978-20-000018:notes:239]
|  | September 26, 2020 |  | June 27, 2020 |
| Property, plant and equipment, net |  |  |  |
| United States | $ | 139.6 |  |  | $ | 139.1 |  |
| Thailand | 118.6 |  |  | 122.6 |  |
| China | 42.7 |  |  | 43.2 |  |
| Japan | 34.0 |  |  | 32.3 |  |
| Other countries | 58.5 |  |  | 55.8 |  |
| Total long-lived assets | $ | 393.4 |  |  | $ | 393.0 |  |

[0001633978-20-000018:notes:240]
We purchase a substantial portion of our inventory from contract manufacturers and vendors located primarily in Taiwan, Thailand, and Malaysia. During the three months ended September 26, 2020 and September 28, 2019, our net inventory purchases from a single contract manufacturer, which represented 10% or greater of total net purchases, were concentrated with two contract manufacturers, who collectively accounted for 65% and 79% of total net inventory purchases, respectively.


## us-gaap:SubsequentEventsTextBlock

[0001633978-20-000018:notes:241]
Note 16. Subsequent Event

[0001633978-20-000018:notes:242]
On October 29, 2020, we closed a transaction to acquire intellectual property and certain other photonics technology assets for a total consideration of $10.0 million.
