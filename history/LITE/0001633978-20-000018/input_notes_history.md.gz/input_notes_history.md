# LITE note change history — 0001633978-20-000008 → 0001633978-20-000018


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-11-02):
[0001633978-20-000018:note_history:1]
Purchase obligations of $257.9 million as of September 26, 2020, represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements.
  (was, 2020-05-05, similarity 0.966):
[0001633978-20-000008:note_history:1]
Purchase obligations of $257.2 million as of March 28, 2020, represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements.

- changed (2020-11-02):
[0001633978-20-000018:note_history:2]
The following table presents the changes in our warranty reserve during the three months ended September 26, 2020 and September 28, 2019 (in millions):
  (was, 2020-05-05, similarity 0.8975):
[0001633978-20-000008:note_history:2]
The following table presents the changes in our warranty reserve during the three and nine months ended March 28, 2020 and March 30, 2019 (in millions):

- added (2020-11-02):
[0001633978-20-000018:note_history:3]
|  | Three Months Ended |
|  | September 26, 2020 |  | September 28, 2019 |
| Balance as of beginning of period | $ | 5.0 |  |  | $ | 7.5 |  |
| Provision for warranty | 3.9 |  |  | 1.2 |  |
| Utilization of reserve | (1.3 | ) |  | (1.7 | ) |
| Balance as of end of period | $ | 7.6 |  |  | $ | 7.0 |  |

- added (2020-11-02):
[0001633978-20-000018:note_history:4]
We are subject to a variety of claims and suits that arise from time to time in the ordinary course of our business. While management currently believes that resolving claims against us, individually or in the aggregate, will not have a material adverse impact on our financial position, results of operations or statements of cash flows, these matters are subject to inherent uncertainties and management’s view of these matters may change in the future. We accrue for loss contingencies when it is both probable that we will incur the loss and when we can reasonably estimate the amount of the loss or range of loss.

- changed (2020-11-02):
[0001633978-20-000018:note_history:5]
The remaining Lawsuit (the Karri Lawsuit) currently purports to seek, among other things, damages to be awarded to the plaintiff and any class, if a class is certified, and litigation costs, including attorneys’ fees.  A lead plaintiff and counsel has been selected, and an amended complaint was filed on April 15, 2019, which also names Lumentum as a defendant. A motion to dismiss the amended complaint was granted in part and denied in part by the court on October 8, 2020. The Karri Lawsuit remains pending, and the court ordered the parties to submit a joint proposed schedule by October 30, 2020. Defendants intend to defend the Karri Lawsuit vigorously.
  (was, 2020-05-05, similarity 0.8052):
[0001633978-20-000008:note_history:5]
The remaining Lawsuit (the Karri Lawsuit) currently purports to seek, among other things, damages to be awarded to the plaintiff and any class, if a class is certified, and litigation costs, including attorneys’ fees.  A lead plaintiff and counsel has been selected, and an amended complaint was filed on April 15, 2019, which also names Lumentum as a defendant.  A motion to dismiss the amended complaint has been fully briefed and is currently pending, and defendants intend to defend the Karri Lawsuit vigorously.

- changed (2020-11-02):
[0001633978-20-000018:note_history:6]
In the normal course of business, we enter into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown because claims may be made against us in the future and we may record charges in the future as a result of these indemnification obligations. As of September 26, 2020, we did not have any material indemnification claims that were probable or reasonably possible.
  (was, 2020-05-05, similarity 0.793):
[0001633978-20-000008:note_history:6]
In the normal course of business, we enter into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown because claims may be made against us in the future and we may record charges in the future as a result of these indemnification obligations. As of March 28, 2020, we did not have any material indemnification claims that were probable or reasonably possible.

- changed (2020-11-02):
[0001633978-20-000018:note_history:7]
We are under audit by various domestic and foreign tax authorities with regards to income tax and indirect tax matters. In some, although not all cases, we have reserved for potential adjustments to our provision for income taxes and accrual of indirect taxes that may result from examinations by these tax authorities or final outcomes in judicial proceedings, and we believe that the final outcome of these examinations, agreements or judicial proceedings will not have a material effect on our results of operations. If events occur which indicate payment of these amounts is unnecessary, the reversal of the liabilities would result in the recognition of benefits in the period we determine the liabilities are no longer necessary. If our estimates of the federal, state, and foreign income tax liabilities and indirect tax liabilities are less than the ultimate assessment, it could result in a further charge to expense.
  (was, 2020-05-05, similarity 0.7831):
[0001633978-20-000008:note_history:7]
We are under audit by various domestic and foreign tax authorities with regards to income tax and indirect tax matters. In some, although not all cases, we have reserved for potential adjustments to our provision for income taxes and accrual of indirect taxes that may result from examinations by these tax authorities or final outcomes in judicial proceedings, and we believe that the final outcome of these examinations, agreements or judicial proceedings will not have a material effect on our results of operations. If events occur which indicate payment of these amounts is unnecessary, the reversal of the liabilities would result in the recognition of benefits in the period we determine the liabilities are no longer necessary. If our estimates of the federal, state, and foreign income tax liabilities and indirect tax liabilities are less than the ultimate assessment, it could result in a further charge to expense.
In connection with our acquisition of Oclaro, we recorded $1.1 million in Malaysia Goods and Services Tax (“GST”) refund claims within prepaid expenses and other current assets in our condensed consolidated balance sheet. The refund claim represents an initial claim of $2.5 million of GST, net of reserves, that was previously denied by the Malaysian tax authorities in 2016. During the nine months ended March 28, 2020, we were able to favorably resolve this audit and received refunds for all of our outstanding GST claims.

- removed (2020-11-02):
[0001633978-20-000008:note_history:8]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 28, 2020 |  | March 30, 2019 |  | March 28, 2020 |  | March 30, 2019 |
| Balance as of beginning of period | $ | 6.8 |  |  | $ | 9.7 |  |  | $ | 7.5 |  |  | $ | 6.6 |  |
| Warranties assumed in Oclaro acquisition | — |  |  | — |  |  | — |  |  | 3.8 |  |
| Provision for warranty | 0.7 |  |  | 1.5 |  |  | 2.5 |  |  | 3.4 |  |
| Utilization of reserve | (2.1 | ) |  | (1.4 | ) |  | (4.6 | ) |  | (4.0 | ) |
| Balance as of end of period | $ | 5.4 |  |  | $ | 9.8 |  |  | $ | 5.4 |  |  | $ | 9.8 |  |

- removed (2020-11-02):
[0001633978-20-000008:note_history:9]
We are subject to a variety of claims and suits that arise from time to time in the ordinary course of our business. While management currently believes that resolving claims against us, individually or in the aggregate, will not have a material adverse

- removed (2020-11-02):
[0001633978-20-000008:note_history:10]
impact on our financial position, results of operations or statements of cash flows, these matters are subject to inherent uncertainties and management’s view of these matters may change in the future. We accrue for loss contingencies when it is both probable that we will incur the loss and when we can reasonably estimate the amount of the loss or range of loss. We have recorded $1.0 million of litigation contingency in other current liabilities on the condensed consolidated balance sheet as of March 28, 2020.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2020-11-02):
[0001633978-20-000018:note_history:11]
Lumentum Holdings Inc. (“we,” “us,” “our”, “Lumentum” or the “Company”) is an industry-leading provider of optical and photonic products defined by revenue and market share addressing a range of end market applications including Optical Communications (“OpComms”) and Commercial Lasers (“Lasers”) for manufacturing, inspection and life-science applications. We seek to use our core optical and photonic technology, and our volume manufacturing capability, to expand into attractive emerging markets that benefit from advantages that optical or photonics-based solutions provide, including 3D sensing for consumer electronics and diode light sources for a variety of consumer and industrial applications. The majority of our customers tend to be original equipment manufacturers (“OEMs”) that incorporate our products into their products which then address end-market applications. For example, we sell fiber optic components that network equipment manufacturers (“NEMs”) assemble into communications networking systems, which they sell to network service providers, operators or enterprises with their own networks. Similarly, many of our customers for our Lasers products incorporate our products into tools they produce, which are used for manufacturing processes by their customers. For 3D sensing, we sell diode lasers to manufacturers of consumer electronics products for mobile, personal computing, gaming, and other applications who then integrate our devices within their products, for eventual resale to consumers and also into other industrial applications.

- changed (2020-11-02):
[0001633978-20-000018:note_history:12]
The preparation of the condensed consolidated financial statements in accordance with U.S. generally accepted accounting principles (“GAAP”) requires management to make estimates and assumptions that affect the amounts reported in our condensed consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates. Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are inventory valuation, revenue recognition, income taxes, and goodwill.
  (was, 2020-05-05, similarity 0.9716):
[0001633978-20-000008:note_history:12]
The preparation of the condensed consolidated financial statements in accordance with U.S. generally accepted accounting principles (“GAAP”) requires management to make estimates and assumptions that affect the amounts reported in our condensed consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates. Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are inventory valuation, revenue recognition, income taxes, long-lived asset valuation, business combinations and goodwill.

- changed (2020-11-02):
[0001633978-20-000018:note_history:13]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Every fifth or sixth fiscal year will have a 53-week period. The additional week in a 53-week year is added to the third quarter, making such quarter consist of 14 weeks. Our fiscal 2021 is a 53-week year ending on July 3, 2021, with the quarter ended September 26, 2020 being a 13-week quarterly period. Our fiscal 2020 was a 52-week year that ended on June 27, 2020, with the quarter ended September 28, 2019 being a 13-week quarterly period.
  (was, 2020-05-05, similarity 0.6972):
[0001633978-20-000008:note_history:13]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Every fifth or sixth fiscal year will have a 53-week period. The additional week in a 53-week year is added to the third quarter, making such quarter consist of 14 weeks. Our fiscal 2021 will be a 53-week year. Our fiscal 2020 is a 52-week year ending on June 27, 2020, with the quarter ended March 28, 2020 being a 13-week quarterly period. Our fiscal 2019 was a 52-week year that ended on June 29, 2019, with the quarter ended March 30, 2019 being a 13-week quarterly period.

- changed (2020-11-02):
[0001633978-20-000018:note_history:14]
The accompanying condensed consolidated financial statements and accompanying related notes should be read in conjunction with the audited consolidated financial statements and related notes included in our Annual Report on Form 10-K for the fiscal year ended June 27, 2020. There have been no significant changes to these policies during the three months ended September 26, 2020, except for the removal of the long-lived asset valuation policy and the updates resulting from the adoption of Topic 326, as discussed in “Note 2. Recently Issued Accounting Pronouncements”.
  (was, 2020-05-05, similarity 0.6496):
[0001633978-20-000008:note_history:14]
The accompanying condensed consolidated financial statements and accompanying related notes should be read in conjunction with the audited consolidated financial statements and related notes included in our Annual Report on Form 10-K for the fiscal year ended June 29, 2019.

- removed (2020-11-02):
[0001633978-20-000008:note_history:15]
Lumentum (“we,” “us,” “our” or the “Company”) is an industry-leading provider of optical and photonic products defined by revenue and market share addressing a range of end market applications including Optical Communications (“OpComms”) and Lasers for manufacturing, inspection and life-science applications. We seek to use our core optical and photonic technology and our volume manufacturing capability to expand into attractive emerging markets that benefit from advantages that optical or photonics based solutions provide, including 3D sensing for consumer electronics and diode light sources for a variety of consumer and industrial applications. The majority of our customers tend to be Original Equipment Manufacturers (“OEMs”) that incorporate our products into their products which then address end-market applications. For example, we sell fiber optic components that Network Equipment Manufacturers’ (“NEMs”) customers assemble into communications networking systems, which they sell to network service providers or enterprises with their own networks. Similarly, many of our customers for our Lasers products incorporate our products into tools they produce, which are used for manufacturing processes by their customers. For 3D sensing, we sell diode lasers to manufacturers of consumer electronics products for mobile, personal computing, gaming, and other applications who then integrate our devices within their products, for eventual resale to consumers and also into other industrial applications. Further, we have begun shipping prototype units of diode lasers and optical subassemblies containing diode lasers and other optical devices to automotive customers for sensing and LiDAR applications.

- removed (2020-11-02):
[0001633978-20-000008:note_history:16]
On December 10, 2018, we completed our merger with Oclaro, Inc. (“Oclaro”), a provider of optical components and modules for the long-haul, metro and data center markets. Our condensed consolidated financial statements include the operating results of Oclaro beginning from the date of acquisition. Refer to “Note 4. Business Combinations” for further discussion of the merger.

- removed (2020-11-02):
[0001633978-20-000008:note_history:17]
Certain prior period amounts have been reclassified to conform to the current period presentation, including the reclassification of capital lease obligations that existed as of June 29, 2019 to finance lease liabilities within other current liabilities and other non-current liabilities in our condensed consolidated balance sheets, as a result of the adoption of the new accounting guidance for leases. Refer to “Note 2. Recently Issued Accounting Pronouncements” for details. The reclassification of the prior period amounts did not impact previously reported condensed consolidated financial statements.

- removed (2020-11-02):
[0001633978-20-000008:note_history:18]
Except for the accounting policies for lease accounting as a result of the adoption of Accounting Standards Update (“ASU”) 2016-02, Leases (Topic 842), there have been no significant changes to our significant accounting policies as of and for the three months ended March 28, 2020, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the year ended June 29, 2019.

- removed (2020-11-02):
[0001633978-20-000008:note_history:19]
Adoption of Leases (Topic 842)

- removed (2020-11-02):
[0001633978-20-000008:note_history:20]
On June 30, 2019, the first day of fiscal year 2020, we adopted Topic 842, using the modified retrospective transition approach. Refer to “Note 2. Recently Issued Accounting Pronouncements” regarding the impact of adoption.

- removed (2020-11-02):
[0001633978-20-000008:note_history:21]
We determine if an arrangement is a lease at inception for arrangements with an initial term of more than 12 months, and classify it as either finance or operating.

- removed (2020-11-02):
[0001633978-20-000008:note_history:22]
Finance leases are generally those that allow us to substantially utilize or pay for the entire asset over its estimated useful life. Finance leases are recorded in property, plant and equipment, net, and finance lease liabilities within other current and other non-current liabilities on our condensed consolidated balance sheets. We have lease arrangements with lease and non-lease components, and the non-lease components for our finance leases are accounted for separately, based on estimated stand-alone values, and are not included in the initial measurement of our finance lease assets and corresponding liabilities. Finance lease assets are amortized in operating expenses on a straight-line basis over the shorter of the estimated useful lives of the assets or the lease term, with the interest component included in interest expense and recognized using the effective interest method over the lease term.

- removed (2020-11-02):
[0001633978-20-000008:note_history:23]
Operating leases are recorded in operating lease right-of-use assets, net, and operating lease liabilities, current and non-current on our condensed consolidated balance sheets. For operating leases of buildings, we account for non-lease components, such as common area maintenance, as a component of the lease, and include it in the initial measurement of our operating lease assets and corresponding liabilities. Operating lease assets are amortized on a straight-line basis in operating expenses over the lease term.

- removed (2020-11-02):
[0001633978-20-000008:note_history:24]
Our lease liabilities are recognized based on the present value of the remaining fixed lease payments, over the lease term, using a discount rate of similarly secured borrowings available to us. For the purpose of lease liability measurement, we consider only payments that are fixed and determinable at the time of commencement. Any variable payments that depend on an index or rate are expensed as incurred. Our lease terms may include options to extend when it is reasonably certain that we will exercise that option. Our lease assets also include any lease payments made and exclude any lease incentives received prior to commencement. Our lease assets are tested for impairment in the same manner as long-lived assets used in operations. We generally recognize sublease income on a straight-line basis over the sublease term.


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2020-11-02):
[0001633978-20-000018:note_history:25]
| Liability component: | September 26, 2020 |  | June 27, 2020 |
|  | 2024 Notes |  | 2026 Notes |  | 2024 Notes | 2026 Notes |
| Principal | $ | 450.0 |  |  | $ | 1,050.0 |  |  | $ | 450.0 |  | $ | 1,050.0 |  |
| Unamortized debt discount and debt issuance costs | (74.6 | ) |  | (290.7 | ) |  | (79.4 | ) | (300.3 | ) |
| Net carrying amount of the liability component | $ | 375.4 |  |  | $ | 759.3 |  |  | $ | 370.6 |  | $ | 749.7 |  |

- removed (2020-11-02):
[0001633978-20-000008:note_history:26]
| Liability component: | March 28, 2020 |  | June 29, 2019 |
|  | 2024 Notes |  | 2026 Notes |  | 2024 Notes |
| Principal | $ | 450.0 |  |  | $ | 1,050.0 |  |  | $ | 450.0 |  |
| Unamortized debt discount and debt issuance costs | (84.2 | ) |  | (309.8 | ) |  | (98.1 | ) |
| Net carrying amount of the liability component | $ | 365.8 |  |  | $ | 740.2 |  |  | $ | 351.9 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-11-02):
[0001633978-20-000018:note_history:27]
| • | during any fiscal quarter commencing after the fiscal quarter ended on March 28, 2020 (and only during such fiscal quarter), if the last reported sale price of the common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price of the 2026 Notes, or $129.08 on each applicable trading day; |
  (was, 2020-05-05, similarity 0.9924):
[0001633978-20-000008:note_history:27]
| • | during any fiscal quarter commencing after the fiscal quarter ended on March 28, 2020 (and only during such fiscal quarter), if the last reported sale price of the common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price of the 2026 Notes on each applicable trading day; |

- added (2020-11-02):
[0001633978-20-000018:note_history:28]
We may redeem for cash, stock or combination of both for all or any portion of the 2026 Notes, at our option, on or after December 20, 2023, if the last reported sale price of its common stock has been at least 130% of the conversion price then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading-day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which we provide a notice of redemption at a redemption price equal to 100% of the principal amount of the 2026 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. No sinking fund is provided for the 2026 Notes. Upon the occurrence of a fundamental change (as defined in the 2026 Indenture), holders may require us to repurchase all or a portion of the 2026 Notes for cash at a price equal to 100% of the principal amount of the 2026 Notes to be repurchased, plus any accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

- changed (2020-11-02):
[0001633978-20-000018:note_history:29]
The initial conversion rate of the 2024 Notes is 16.4965 shares of common stock per $1,000 principal amount of 2024 Notes, which is equivalent to an initial conversion price of approximately $60.62 per share, a 132.5% premium to the fair market value at the date of issuance.  Prior to the close of business on the business day immediately preceding December 15, 2023, each holder of the 2024 Notes may convert their 2024 Notes only under the following circumstances:
  (was, 2020-05-05, similarity 0.7372):
[0001633978-20-000008:note_history:29]
The initial conversion rate of the 2024 Notes is 16.4965 shares of common stock per $1,000 principal amount of 2024 Notes, which is equivalent to an initial conversion price of approximately $60.62 per share, a 132.5% premium to the fair market value at the date of issuance.

- changed (2020-11-02):
[0001633978-20-000018:note_history:30]
| • | during the five consecutive business day period after any five consecutive trading day period (the “measurement period”) in which the trading price per $1,000 principal amount of notes for each trading day of such measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate on each such trading day; |
  (was, 2020-05-05, similarity 0.9961):
[0001633978-20-000008:note_history:30]
| • | during the five consecutive business day period after any five consecutive trading day period (the “measurement period”) in which the trading price per $1,000 principal amount of notes for each trading day of such measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate on each such trading day; or |

- changed (2020-11-02):
[0001633978-20-000018:note_history:31]
During the fiscal year ended July 1, 2017, we satisfied the TMA settlement condition. As such, the value of the conversion option will no longer be marked to market and was reclassified to additional paid-in capital within stockholders’ equity on our condensed consolidated balance sheet. The value of the conversion option at the time of issuance will be treated as an original issue discount for purposes of accounting for the debt component of the notes. The debt component will accrete up to the principal amount over the expected term of the debt.
  (was, 2020-05-05, similarity 0.9982):
[0001633978-20-000008:note_history:31]
During the fiscal year ended July 1, 2017, we satisfied the TMA settlement condition. As such, the value of the conversion option will no longer be marked to market and was reclassified to additional paid-in capital within stockholders’ equity on our condensed consolidated balance sheet. The value of the conversion option at the time of issuance will be treated as an original issue discount for purposes of accounting for the debt component of the 2024 Notes. The debt component will accrete up to the principal amount over the expected term of the debt.

- added (2020-11-02):
[0001633978-20-000018:note_history:32]
| Liability component: | September 26, 2020 |  | June 27, 2020 |
|  | 2024 Notes |  | 2026 Notes |  | 2024 Notes | 2026 Notes |
| Principal | $ | 450.0 |  |  | $ | 1,050.0 |  |  | $ | 450.0 |  | $ | 1,050.0 |  |
| Unamortized debt discount and debt issuance costs | (74.6 | ) |  | (290.7 | ) |  | (79.4 | ) | (300.3 | ) |
| Net carrying amount of the liability component | $ | 375.4 |  |  | $ | 759.3 |  |  | $ | 370.6 |  | $ | 749.7 |  |

- added (2020-11-02):
[0001633978-20-000018:note_history:33]
During all periods presented, the debt component of our 2024 Notes was recorded in long-term liabilities. However, if the closing price of our stock exceeds $78.80 for 20 of the last 30 trading days of the second quarter of fiscal 2021, the 2024 Notes would become convertible at the option of the holders. Therefore, the debt component of our 2024 Notes (approximately $375 million as of September 26, 2020) would be reclassified to current liabilities in our condensed consolidated balance sheet.

- changed (2020-11-02):
[0001633978-20-000018:note_history:34]
|  | Three Months Ended |
|  | September 26, 2020 |  | September 28, 2019 |
| Contractual interest expense | $ | 1.6 |  |  | $ | 0.3 |  |
| Amortization of the debt discount and debt issuance costs | 14.4 |  |  | 4.6 |  |
| Total interest expense | $ | 16.0 |  |  | $ | 4.9 |  |
  (was, 2020-05-05, similarity 0.722):
[0001633978-20-000008:note_history:34]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 28, 2020 |  | March 30, 2019 |  | March 28, 2020 |  | March 30, 2019 |
| Contractual interest expense | $ | 1.6 |  |  | $ | 0.3 |  |  | $ | 2.3 |  |  | $ | 0.9 |  |
| Amortization of the debt discount and debt issuance costs | 14.0 |  |  | 4.5 |  |  | 24.8 |  |  | 13.2 |  |
| Total interest expense | $ | 15.6 |  |  | $ | 4.8 |  |  | $ | 27.1 |  |  | $ | 14.1 |  |

- changed (2020-11-02):
[0001633978-20-000018:note_history:35]
The future interest and principal payments related to our convertible notes are as follows as of September 26, 2020 (in millions):
  (was, 2020-05-05, similarity 0.9593):
[0001633978-20-000008:note_history:35]
The future interest and principal payments related to our convertible notes are as follows as of March 28, 2020 (in millions):

- changed (2020-11-02):
[0001633978-20-000018:note_history:36]
| Fiscal Years | 2024 Notes |  | 2026 Notes |  | Total |
| Remainder of 2021 | $ | 0.6 |  |  | $ | 5.3 |  |  | $ | 5.9 |  |
| 2022 | 1.1 |  |  | 5.3 |  |  | 6.4 |  |
| 2023 | 1.1 |  |  | 5.3 |  |  | 6.4 |  |
| 2024 | 451.1 |  |  | 5.3 |  |  | 456.4 |  |
| 2025 | — |  |  | 5.3 |  |  | 5.3 |  |
| Thereafter | — |  |  | 1,057.7 |  |  | 1,057.7 |  |
| Total convertible notes payments | $ | 453.9 |  |  | $ | 1,084.2 |  |  | $ | 1,538.1 |  |
  (was, 2020-05-05, similarity 0.6262):
[0001633978-20-000008:note_history:36]
| Fiscal Years | 2024 Notes |  | 2026 Notes |  | Total |
| Remainder of 2020 | $ | — |  |  | $ | 2.7 |  |  | $ | 2.7 |  |
| 2021 | 1.1 |  |  | 5.2 |  |  | 6.3 |  |
| 2022 | 1.1 |  |  | 5.3 |  |  | 6.4 |  |
| 2023 | 1.1 |  |  | 5.2 |  |  | 6.3 |  |
| 2024 | 451.2 |  |  | 5.3 |  |  | 456.5 |  |
| Thereafter | — |  |  | 1,063.1 |  |  | 1,063.1 |  |
| Total convertible notes payments | $ | 454.5 |  |  | $ | 1,086.8 |  |  | $ | 1,541.3 |  |

- added (2020-11-02):
[0001633978-20-000018:note_history:37]
In December 2018, concurrent with the closing of the Oclaro merger, we entered into a credit agreement providing for a term loan facility (the “Term Loan Facility”) in an aggregate principal amount of $500.0 million and we drew in full the term loans available under the Term Loan Facility on the closing date of the Oclaro merger. In fiscal 2020, we repaid, in full, all amounts outstanding under our Term Loan Facility. During the three months ended September 28, 2019, we incurred $6.4 million interest expense on this Term Loan Facility.

- changed (2020-11-02):
[0001633978-20-000018:note_history:38]
During the three months ended September 28, 2019, we recorded $0.1 million interest expense related to our finance leases.  Refer to “Note 7. Leases”.
  (was, 2020-05-05, similarity 0.7809):
[0001633978-20-000008:note_history:38]
For the nine months ended March 28, 2020, we also recorded $0.1 million interest expense related to our finance leases.

- removed (2020-11-02):
[0001633978-20-000008:note_history:39]
We may redeem for cash, stock or combination of both for all or any portion of the 2026 Notes, at our option, on or after December 20, 2023, if the last reported sale price of its common stock has been at least 130% of the conversion price then in effect

- removed (2020-11-02):
[0001633978-20-000008:note_history:40]
for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading-day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which we provide a notice of redemption at a redemption price equal to 100% of the principal amount of the 2026 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. No sinking fund is provided for the 2026 Notes. Upon the occurrence of a fundamental change (as defined in the 2026 Indenture), holders may require us to repurchase all or a portion of the 2026 Notes for cash at a price equal to 100% of the principal amount of the 2026 Notes to be repurchased, plus any accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

- removed (2020-11-02):
[0001633978-20-000008:note_history:41]
Prior to the close of business on the business day immediately preceding December 15, 2023, each holder of the 2024 Notes may convert their 2024 Notes only under the following circumstances:

- removed (2020-11-02):
[0001633978-20-000008:note_history:42]
| Liability component: | March 28, 2020 |  | June 29, 2019 |
|  | 2024 Notes |  | 2026 Notes |  | 2024 Notes |
| Principal | $ | 450.0 |  |  | $ | 1,050.0 |  |  | $ | 450.0 |  |
| Unamortized debt discount and debt issuance costs | (84.2 | ) |  | (309.8 | ) |  | (98.1 | ) |
| Net carrying amount of the liability component | $ | 365.8 |  |  | $ | 740.2 |  |  | $ | 351.9 |  |

- removed (2020-11-02):
[0001633978-20-000008:note_history:43]
On December 10, 2018 (the “Closing Date”), concurrent with the closing of the Oclaro merger, we entered into a Credit and Guarantee Agreement (the “Credit Agreement”), by and among us, certain of our subsidiaries, the lenders party thereto, and

- removed (2020-11-02):
[0001633978-20-000008:note_history:44]
Deutsche Bank, as administrative agent and collateral agent for the lenders. The Credit Agreement provides for a senior secured term loan facility (the “Term Loan Facility”) in an aggregate principal amount of $500.0 million. The term loans available under the Term Loan Facility were fully drawn on the Closing Date and the proceeds of the term loans were used to consummate the merger and pay fees and expenses in connection with the merger and the Term Loan Facility.

- removed (2020-11-02):
[0001633978-20-000008:note_history:45]
In fiscal 2019, we incurred $9.3 million of debt issuance costs in connection with the Term Loan Facility which were capitalized and recorded as a contra liability in our condensed consolidated balance sheet. These costs were amortized to interest expense using the effective interest rate method from the issuance date of December 10, 2018.

- removed (2020-11-02):
[0001633978-20-000008:note_history:46]
In fiscal 2020, we repaid, in full, all amounts outstanding under our Term Loan Facility. During the nine months ended March 28, 2020, we incurred an $8.0 million loss for the unamortized debt issuance costs as a result of this full repayment.

- removed (2020-11-02):
[0001633978-20-000008:note_history:47]
The following table sets forth interest expense information related to the term loan for the periods presented (in millions):

- removed (2020-11-02):
[0001633978-20-000008:note_history:48]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 28, 2020 |  | March 30, 2019 |  | March 28, 2020 |  | March 30, 2019 |
| Contractual interest expense | $ | — |  |  | $ | 6.2 |  |  | $ | 9.6 |  |  | $ | 10.2 |  |
| Amortization of the debt issuance costs | — |  |  | 0.4 |  |  | 0.5 |  |  | 0.5 |  |
| Loss on early extinguishment of debt | — |  |  | — |  |  | 8.0 |  |  | — |  |
| Total interest expense | $ | — |  |  | $ | 6.6 |  |  | $ | 18.1 |  |  | $ | 10.7 |  |

- removed (2020-11-02):
[0001633978-20-000008:note_history:49]
The following table sets forth balance sheet information related to the term loan as of the periods presented (in millions):

- removed (2020-11-02):
[0001633978-20-000008:note_history:50]
|  | March 28, 2020 |  | June 29, 2019 |
| Principal | $ | 497.5 |  |  | $ | 500.0 |  |
| Repayment of principal | (497.5 | ) |  | (2.5 | ) |
| Unamortized value of the debt issuance costs | — |  |  | (8.5 | ) |
| Net carrying value | $ | — |  |  | $ | 489.0 |  |
| Term loan, current | $ | — |  |  | $ | 5.0 |  |
| Term loan, non-current | $ | — |  |  | $ | 484.0 |  |


## us-gaap:DebtSecuritiesAvailableForSaleUnrealizedLossPositionFairValueTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2020-11-02):
[0001633978-20-000018:note_history:51]
|  | Less than 12 months |  | 12 Months or Greater |  | Total |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| September 26, 2020: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | 43.3 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 43.3 |  |  | $ | — |  |
| Commercial paper | 37.2 |  |  | — |  |  | — |  |  | — |  |  | 37.2 |  |  | — |  |
| Corporate debt securities | 167.6 |  |  | (0.2 | ) |  | — |  |  | — |  |  | 167.6 |  |  | (0.2 | ) |
| U.S. government bonds | 99.9 |  |  | — |  |  | — |  |  | — |  |  | 99.9 |  |  | — |  |
| Total | $ | 348.0 |  |  | $ | (0.2 | ) |  | $ | — |  |  | $ | — |  |  | $ | 348.0 |  |  | $ | (0.2 | ) |
| June 27, 2020: |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 3.1 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 3.1 |  |  | $ | — |  |
| Commercial paper | 51.1 |  |  | — |  |  | — |  |  | — |  |  | 51.1 |  |  | — |  |
| Corporate debt securities | 96.5 |  |  | (0.1 | ) |  | — |  |  | — |  |  | 96.5 |  |  | (0.1 | ) |
| Foreign government bonds | 1.7 |  |  | — |  |  | — |  |  | — |  |  | 1.7 |  |  | — |  |
| U.S. Agency securities | 47.0 |  |  | — |  |  | — |  |  | — |  |  | 47.0 |  |  | — |  |
| U.S. government bonds | 159.8 |  |  | — |  |  | — |  |  | — |  |  | 159.8 |  |  | — |  |
| Total | $ | 359.2 |  |  | $ | (0.1 | ) |  | $ | — |  |  | $ | — |  |  | $ | 359.2 |  |  | $ | (0.1 | ) |

- removed (2020-11-02):
[0001633978-20-000008:note_history:52]
|  | Less than 12 months |  | 12 Months or Greater |  | Total |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| March 28, 2020: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | 8.0 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 8.0 |  |  | $ | — |  |
| Certificates of deposit | 2.5 |  |  | — |  |  | — |  |  | — |  |  | 2.5 |  |  | — |  |
| Commercial paper | 55.2 |  |  | — |  |  | — |  |  | — |  |  | 55.2 |  |  | — |  |
| Corporate debt securities | 301.1 |  |  | (2.5 | ) |  | — |  |  | — |  |  | 301.1 |  |  | (2.5 | ) |
| Total | $ | 366.8 |  |  | $ | (2.5 | ) |  | $ | — |  |  | $ | — |  |  | $ | 366.8 |  |  | $ | (2.5 | ) |
| June 29, 2019: |  |  |  |  |  |  |  |  |  |  |  |
| Asset-backed securities | $ | 4.2 |  |  | $ | — |  |  | $ | 5.9 |  |  | $ | — |  |  | $ | 10.1 |  |  | $ | — |  |
| Corporate debt securities | 9.6 |  |  | — |  |  | 35.9 |  |  | (0.1 | ) |  | 45.5 |  |  | (0.1 | ) |
| Foreign government bonds | — |  |  | — |  |  | 2.1 |  |  | — |  |  | 2.1 |  |  | — |  |
| U.S. government bonds | 6.9 |  |  | — |  |  | — |  |  | — |  |  | 6.9 |  |  | — |  |
| Total | $ | 20.7 |  |  | $ | — |  |  | $ | 43.9 |  |  | $ | (0.1 | ) |  | $ | 64.6 |  |  | $ | (0.1 | ) |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2020-11-02):
[0001633978-20-000008:note_history:53]
The following table sets forth balance sheet information related to the term loan as of the periods presented (in millions):

- removed (2020-11-02):
[0001633978-20-000008:note_history:54]
|  | March 28, 2020 |  | June 29, 2019 |
| Principal | $ | 497.5 |  |  | $ | 500.0 |  |
| Repayment of principal | (497.5 | ) |  | (2.5 | ) |
| Unamortized value of the debt issuance costs | — |  |  | (8.5 | ) |
| Net carrying value | $ | — |  |  | $ | 489.0 |  |
| Term loan, current | $ | — |  |  | $ | 5.0 |  |
| Term loan, non-current | $ | — |  |  | $ | 484.0 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-11-02):
[0001633978-20-000018:note_history:55]
The future interest and principal payments related to our convertible notes are as follows as of September 26, 2020 (in millions):
  (was, 2020-05-05, similarity 0.9593):
[0001633978-20-000008:note_history:55]
The future interest and principal payments related to our convertible notes are as follows as of March 28, 2020 (in millions):

- changed (2020-11-02):
[0001633978-20-000018:note_history:56]
| Fiscal Years | 2024 Notes |  | 2026 Notes |  | Total |
| Remainder of 2021 | $ | 0.6 |  |  | $ | 5.3 |  |  | $ | 5.9 |  |
| 2022 | 1.1 |  |  | 5.3 |  |  | 6.4 |  |
| 2023 | 1.1 |  |  | 5.3 |  |  | 6.4 |  |
| 2024 | 451.1 |  |  | 5.3 |  |  | 456.4 |  |
| 2025 | — |  |  | 5.3 |  |  | 5.3 |  |
| Thereafter | — |  |  | 1,057.7 |  |  | 1,057.7 |  |
| Total convertible notes payments | $ | 453.9 |  |  | $ | 1,084.2 |  |  | $ | 1,538.1 |  |
  (was, 2020-05-05, similarity 0.6262):
[0001633978-20-000008:note_history:56]
| Fiscal Years | 2024 Notes |  | 2026 Notes |  | Total |
| Remainder of 2020 | $ | — |  |  | $ | 2.7 |  |  | $ | 2.7 |  |
| 2021 | 1.1 |  |  | 5.2 |  |  | 6.3 |  |
| 2022 | 1.1 |  |  | 5.3 |  |  | 6.4 |  |
| 2023 | 1.1 |  |  | 5.2 |  |  | 6.3 |  |
| 2024 | 451.2 |  |  | 5.3 |  |  | 456.5 |  |
| Thereafter | — |  |  | 1,063.1 |  |  | 1,063.1 |  |
| Total convertible notes payments | $ | 454.5 |  |  | $ | 1,086.8 |  |  | $ | 1,541.3 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2020-11-02):
[0001633978-20-000018:note_history:57]
Note 16. Subsequent Event

- added (2020-11-02):
[0001633978-20-000018:note_history:58]
On October 29, 2020, we closed a transaction to acquire intellectual property and certain other photonics technology assets for a total consideration of $10.0 million.
