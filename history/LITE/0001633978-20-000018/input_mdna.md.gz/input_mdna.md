# LITE MD&A — 0001633978-20-000018


## mdna

[0001633978-20-000018:mdna:1]
[same as prior period, unchanged from 0001633978-20-000008:mdna:1]

[0001633978-20-000018:mdna:2]
[same as prior period, unchanged from 0001633978-20-000008:mdna:2]

[0001633978-20-000018:mdna:3]
[same as prior period, unchanged from 0001633978-20-000008:mdna:3]

[0001633978-20-000018:mdna:4]
[same as prior period, unchanged from 0001633978-20-000008:mdna:4]

[0001633978-20-000018:mdna:5]
We are an industry-leading provider of optical and photonic products, defined by revenue and market share, addressing a range of end-market applications including Optical Communications, which we refer to as OpComms, and Lasers for manufacturing, inspection and life-science applications. We seek to use our core optical and photonic technology and our volume manufacturing capability to expand into attractive emerging markets that benefit from advantages that optical or photonics-based solutions provide, including 3D sensing for consumer electronics and diode light sources for a variety of consumer and industrial applications. We have two operating segments, OpComms and Lasers. The two operating segments were primarily determined based on how the Chief Operating Decision Maker (“CODM”) views and evaluates our operations. Operating results are regularly reviewed by the CODM to make decisions about resources to be allocated to the segments and to assess their performance. Other factors, including market separation and customer specific applications, go-to-market channels, products and manufacturing, are considered in determining the formation of these operating segments.

[0001633978-20-000018:mdna:6]
We believe the world is becoming more reliant on ever-increasing amounts of data flowing through optical networks and data centers, which require new networks and data centers to satisfy this demand. As manufacturers demand higher levels of precision, new materials, and factory and energy efficiency, suppliers of manufacturing tools globally are turning to laser based approaches, including the types of lasers Lumentum supplies. Laser based 3D sensing is a rapidly developing market. The technology enables computer vision applications that enhance security, safety, and new functionality in the electronic devices that people rely on every day. We believe the global markets in which Lumentum participates have fundamentally robust, long-term trends that increase the need for our photonics products and technologies.

[0001633978-20-000018:mdna:7]
[same as prior period, unchanged from 0001633978-20-000008:mdna:10]

[0001633978-20-000018:mdna:8]
[same as prior period, unchanged from 0001633978-20-000008:mdna:11]

[0001633978-20-000018:mdna:9]
In the geographies we have operations, we have in general been deemed an essential business and been permitted to continue manufacturing and new product development operations in a more limited capacity during the pandemic. This stems from our critical role in global supply chains for the world’s communications and health-care systems. Given the rapidly evolving situation, it is difficult to predict precisely when our ability to supply our products will improve or the magnitude and duration of the impact of the COVID-19 pandemic to our markets. We will continue to actively monitor the situation and may take further actions altering our business operations that we determine are in the best interests of our employees, customers, communities, business partners, suppliers, and stockholders, or as required by federal, state, or local authorities. It is not clear what the potential effects any such alterations or modifications may have on our business, including the effects on our customers, employees, and prospects, or on our financial results for fiscal year 2021.

[0001633978-20-000018:mdna:10]
While the recent outbreak of the COVID-19 did not have a material adverse effect on our reported results for our first quarter of fiscal 2021, we are actively monitoring the impact of the coronavirus outbreak. The extent to which our operations will be impacted by the outbreak will depend largely on future developments, which are highly uncertain and cannot be accurately predicted, including new information which may emerge concerning the severity of the outbreak and actions by government authorities and private businesses to contain the outbreak or recover from its impact, among other things.

[0001633978-20-000018:mdna:11]
Our primary strategic focus for several years has been technology and product leadership combined with close customer relationships in long-term healthy and growing markets. We believe this strategy is even more apt, and our long-term opportunity is not diminished, with COVID-19. We believe there may be long-term opportunities, as the world’s experience with COVID-19 could drive an increasingly digital and virtual world touching all aspects of life and work that increasingly emphasizes communications systems, cloud services, augmented and virtual reality, and enhanced security. Additionally, ever advancing electronic devices are needed to consume, produce, and communicate digital and virtual content. All these trends could drive the need for higher volumes of higher performing optical devices that we could supply. As such, we expect to continue to invest strongly in new products, technology, and customer programs.

[0001633978-20-000018:mdna:12]
In addition, regulatory and enforcement actions by the United States and other governmental agencies, as well as changes in tax and trade policies and tariffs, have impacted and may continue to impact net revenue from customers outside the United States.

[0001633978-20-000018:mdna:13]
For more information on risks associated with the COVID-19 outbreak and regulatory actions, see the section titled “Risk Factors” in Item 1A of Part II.

[0001633978-20-000018:mdna:14]
[same as prior period, unchanged from 0001633978-20-000008:mdna:17]

[0001633978-20-000018:mdna:15]
Our condensed consolidated financial statements are prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) as set forth in the Financial Accounting Standards Board’s Accounting Standards Codification (“ASC”), and we consider the various staff accounting bulletins and other applicable guidance issued by the United States Securities and Exchange Commission (“SEC”). GAAP, as set forth within the ASC, requires us to make certain estimates, judgments and assumptions. We believe that the estimates, judgments and assumptions upon which we rely are reasonable based upon information available to us at the time that these estimates, judgments and assumptions are made. These estimates, judgments and assumptions can affect the reported amounts of assets and liabilities as of the date of the financial statements as well as the reported amounts of revenues and expenses during the periods presented. To the extent there are differences between these estimates, judgments or assumptions and actual results, our financial statements will be affected. The accounting policies that reflect our more significant estimates, judgments and assumptions and which we believe are the most critical to aid in fully understanding and evaluating our reported financial results include the following:

[0001633978-20-000018:mdna:16]
[same as prior period, unchanged from 0001633978-20-000008:mdna:19]

[0001633978-20-000018:mdna:17]
[same as prior period, unchanged from 0001633978-20-000008:mdna:20]

[0001633978-20-000018:mdna:18]
[same as prior period, unchanged from 0001633978-20-000008:mdna:21]

[0001633978-20-000018:mdna:19]
[same as prior period, unchanged from 0001633978-20-000008:mdna:24]

[0001633978-20-000018:mdna:20]
Management’s Discussion and Analysis of Financial Condition and Results of Operations contained in Part II, Item 7 of our Annual Report on Form 10-K for our fiscal year ended June 27, 2020 provides a more complete discussion of our critical accounting policies and estimates. There have been no significant changes to these policies during the three months ended September 26, 2020, except for the removal of the long-lived asset valuation policy and the updates resulting from the adoption of Topic 326, as discussed in “Note 2. Recently Issued Accounting Pronouncements”.

[0001633978-20-000018:mdna:21]
Recently Issued Accounting Pronouncements

[0001633978-20-000018:mdna:22]
Refer to “Note 2. Recently Issued Accounting Pronouncements” in the notes to condensed consolidated financial statements.

[0001633978-20-000018:mdna:23]
[same as prior period, unchanged from 0001633978-20-000008:mdna:28]

[0001633978-20-000018:mdna:24]
[same as prior period, unchanged from 0001633978-20-000008:mdna:29]

[0001633978-20-000018:mdna:25]
|  | Three Months Ended |
|  | September 26, 2020 |  | September 28, 2019 |
| Segment net revenue: |  |  |  |
| OpComms | 94.7 | % |  | 92.5 | % |
| Lasers | 5.3 |  |  | 7.5 |  |
| Net revenue | 100.0 |  |  | 100.0 |  |
| Cost of sales | 51.2 |  |  | 59.9 |  |
| Amortization of acquired developed intangibles | 3.3 |  |  | 2.8 |  |
| Gross profit | 45.5 |  |  | 37.3 |  |
| Operating expenses: |  |  |  |
| Research and development | 11.1 |  |  | 11.1 |  |
| Selling, general and administrative | 12.4 |  |  | 12.6 |  |
| Restructuring and related charges | — |  |  | 0.3 |  |
| Total operating expenses | 23.6 |  |  | 24.0 |  |
| Income from operations | 21.9 |  |  | 13.3 |  |
| Interest expense | (3.5 | ) |  | (2.5 | ) |
| Other income (expense), net | 0.1 |  |  | 1.1 |  |
| Income before income taxes | 18.5 |  |  | 11.9 |  |
| Provision for income taxes | 3.6 |  |  | 1.3 |  |
| Net income | 14.8 | % |  | 10.6 | % |

[0001633978-20-000018:mdna:26]
33

[0001633978-20-000018:mdna:27]
Financial Data for the three months ended September 26, 2020 and September 28, 2019

[0001633978-20-000018:mdna:28]
[same as prior period, unchanged from 0001633978-20-000008:mdna:33]

[0001633978-20-000018:mdna:29]
|  | Three Months Ended |  |  |  |  |
|  | September 26, 2020 |  | September 28, 2019 |  | Change |  | Percentage Change |
| Segment net revenue: |  |  |  |  |  |  |  |
| OpComms | $ | 428.5 |  |  | $ | 416.1 |  |  | $ | 12.4 |  |  | 3.0 | % |
| Lasers | 23.9 |  |  | 33.8 |  |  | (9.9 | ) |  | (29.3 | ) |
| Net revenue | $ | 452.4 |  |  | $ | 449.9 |  |  | $ | 2.5 |  |  | 0.6 | % |
| Gross profit | $ | 205.7 |  |  | $ | 167.7 |  |  | $ | 38.0 |  |  | 22.7 | % |
| Gross margin | 45.5 | % |  | 37.3 | % |  |  |  |  |
| Research and development | $ | 50.4 |  |  | $ | 49.9 |  |  | $ | 0.5 |  |  | 1.0 | % |
| Percentage of net revenue | 11.1 | % |  | 11.1 | % |  |  |  |  |
| Selling, general and administrative | $ | 56.3 |  |  | $ | 56.7 |  |  | $ | (0.4 | ) |  | (0.7 | )% |
| Percentage of net revenue | 12.4 | % |  | 12.6 | % |  |  |  |  |
| Restructuring and related charges | $ | — |  |  | $ | 1.3 |  |  | $ | (1.3 | ) |  | (100.0 | )% |
| Percentage of net revenue | — | % |  | 0.3 | % |  |  |  |  |

[0001633978-20-000018:mdna:30]
[same as prior period, unchanged from 0001633978-20-000008:mdna:35]

[0001633978-20-000018:mdna:31]
Net revenue increased by $2.5 million, or 0.6%, during the three months ended September 26, 2020 compared to the three months ended September 28, 2019. This increase was primarily due to the increased sales of Telecom and Datacom of $13.2 million offset by decreased sales of Lasers of $9.9 million.

[0001633978-20-000018:mdna:32]
OpComms net revenue increased by $12.4 million, or 3.0%, during the three months ended September 26, 2020 compared to the three months ended September 28, 2019. This increase was primarily due to increased sales of Datacom products, particularly Datacom chips, offset by lower sales of Datacom transceiver modules.

[0001633978-20-000018:mdna:33]
Lasers net revenue decreased by $9.9 million, or 29.3%, during the three months ended September 26, 2020 compared to the three months ended September 28, 2019, primarily due to lower revenue from kilowatt class fiber lasers.

[0001633978-20-000018:mdna:34]
During the three months ended September 26, 2020, our net revenue from a single customer which represented 10% or greater of total net revenue was concentrated with one customer, who accounted for 35% of our total net revenue.

[0001633978-20-000018:mdna:35]
During the three months ended September 28, 2019, our net revenue from a single customer which represented 10% or greater of total net revenue was concentrated with three customers, who collectively accounted for 58% of our total net revenue.

[0001633978-20-000018:mdna:36]
[same as prior period, unchanged from 0001633978-20-000008:mdna:45]

[0001633978-20-000018:mdna:37]
[same as prior period, unchanged from 0001633978-20-000008:mdna:46]

[0001633978-20-000018:mdna:38]
|  | Three Months Ended |
|  | September 26, 2020 |  | September 28, 2019 |
| Net revenue: | Amount |  | % of Total |  | Amount |  | % of Total |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |
| United States | $ | 20.3 |  |  | 4.5 | % |  | $ | 36.9 |  |  | 8.3 | % |
| Mexico | 39.8 |  |  | 8.8 |  |  | 28.9 |  |  | 6.4 |  |
| Other Americas | 2.8 |  |  | 0.6 |  |  | 1.1 |  |  | 0.2 |  |
| Total Americas | $ | 62.9 |  |  | 13.9 | % |  | $ | 66.9 |  |  | 14.9 | % |
| Asia-Pacific: |  |  |  |  |  |  |  |  |  |  |  |
| Hong Kong | $ | 144.4 |  |  | 31.9 | % |  | $ | 133.8 |  |  | 29.7 | % |
| Philippines | 62.8 |  |  | 13.9 |  |  | 25.0 |  |  | 5.6 |  |
| South Korea | 56.0 |  |  | 12.4 |  |  | 91.6 |  |  | 20.4 |  |
| Other Asia-Pacific | 91.6 |  |  | 20.2 |  |  | 100.3 |  |  | 22.2 |  |
| Total Asia-Pacific | $ | 354.8 |  |  | 78.4 | % |  | $ | 350.7 |  |  | 77.9 | % |
| EMEA | $ | 34.7 |  |  | 7.7 | % |  | $ | 32.3 |  |  | 7.2 | % |
| Total net revenue | $ | 452.4 |  |  |  |  |  | $ | 449.9 |  |  |  |  |

[0001633978-20-000018:mdna:39]
For the three months ended September 26, 2020 and September 28, 2019, net revenue from customers outside the United States, based on customer shipping location, represented 95.5% and 91.7% of net revenue, respectively.

[0001633978-20-000018:mdna:40]
During the three months ended September 26, 2020 compared to the three months ended September 28, 2019, our net revenue from the Philippines grew due to an introduction of a new product to one of our large customers, while our net revenue from South Korea declined due to a change in shipment destination for some shipments to one of our large customers.

[0001633978-20-000018:mdna:41]
[same as prior period, unchanged from 0001633978-20-000008:mdna:51]

[0001633978-20-000018:mdna:42]
35

[0001633978-20-000018:mdna:43]
[same as prior period, unchanged from 0001633978-20-000008:mdna:52]

[0001633978-20-000018:mdna:44]
The following table summarizes segment gross margin for the three months ended September 26, 2020 and September 28, 2019 (in millions, except for percentages):

[0001633978-20-000018:mdna:45]
|  | Three Months Ended |
|  | Gross Profit |  | Gross Margin |
|  | September 26, 2020 |  | September 28, 2019 |  | September 26, 2020 |  | September 28, 2019 |
| OpComms | $ | 224.8 |  |  | $ | 191.9 |  |  | 52.5 | % |  | 46.1 | % |
| Lasers | 10.4 |  |  | 14.2 |  |  | 43.5 | % |  | 42.0 | % |
| Segment total | $ | 235.2 |  |  | $ | 206.1 |  |  | 52.0 | % |  | 45.8 | % |
| Unallocated corporate items: |  |  |  |  |  |  |  |
| Stock-based compensation | (3.7 | ) |  | (4.2 | ) |  |  |  |  |
| Amortization of acquired intangibles | (15.0 | ) |  | (12.5 | ) |  |  |  |  |
| Amortization of fair value adjustments | — |  |  | (2.2 | ) |  |  |  |  |
| Inventory and fixed asset write down due to product lines exit | (0.3 | ) |  | (1.1 | ) |  |  |  |  |
| Integration related costs | — |  |  | (3.4 | ) |  |  |  |  |
| Other charges (1) | (10.5 | ) |  | (15.0 | ) |  |  |  |  |
| Total | $ | 205.7 |  |  | $ | 167.7 |  |  | 45.5 | % |  | 37.3 | % |

[0001633978-20-000018:mdna:46]
(1) “Other charges” of unallocated corporate items for the three months ended September 26, 2020 and September 28, 2019 primarily include costs of transferring product lines to new production facilities, including Thailand of $2.1 million and $4.8 million, respectively.  We also incurred excess and obsolete inventory charges driven by U.S. trade restrictions and the related decline in demand from Huawei of $5.9 million and $6.7 million during the three months ended September 26, 2020 and September 28, 2019, respectively.

[0001633978-20-000018:mdna:47]
[same as prior period, unchanged from 0001633978-20-000008:mdna:56]

[0001633978-20-000018:mdna:48]
[same as prior period, unchanged from 0001633978-20-000008:mdna:57]

[0001633978-20-000018:mdna:49]
Gross margin for the three months ended September 26, 2020 increased to 45.5% from 37.3% for the three months ended September 28, 2019. The increase was primarily driven by improved gross margins within Datacom, due to the sale of our Datacom transceiver module business, which had lower than average gross margins, and increased revenue from our higher margin Datacom chip products, which have higher than average gross margins. Although we sold our Datacom transceiver module business in March 2019, we retained and continued to sell transceivers inventory at low gross margin percentages during fiscal year 2020.  During the three months ended September 26, 2020, Datacom revenue was primarily from higher margin Datacom chip products.

[0001633978-20-000018:mdna:50]
[same as prior period, unchanged from 0001633978-20-000008:mdna:61]

[0001633978-20-000018:mdna:51]
Although the magnitude of the impact of COVID-19 on our business operations remains uncertain and difficult to predict, and this remains a highly dynamic situation, we have experienced, and we expect that we may continue to experience in subsequent periods, disruptions to our and our customers’ businesses that will adversely impact our business, financial condition and results of operations.

[0001633978-20-000018:mdna:52]
[same as prior period, unchanged from 0001633978-20-000008:mdna:63]

[0001633978-20-000018:mdna:53]
[same as prior period, unchanged from 0001633978-20-000008:mdna:64]

[0001633978-20-000018:mdna:54]
OpComms gross margin for the three months ended September 26, 2020 increased to 52.5% from 46.1% for the three months ended September 28, 2019. The increase was primarily driven by improved gross margins within Datacom, due to the sale of our Datacom transceiver module business in March 2019, which had lower than average gross margins, and increased revenue from our higher margin Datacom chip products, which have higher than average gross margins.

[0001633978-20-000018:mdna:55]
[same as prior period, unchanged from 0001633978-20-000008:mdna:67]

[0001633978-20-000018:mdna:56]
Lasers gross margin for the three months ended September 26, 2020 increased to 43.5% from 42.0% for the three months ended September 28, 2019. This increase was primarily driven by the streamlining of our manufacturing supply chain related to our kilowatt class fiber products over the past year, offset by the impacts of reduced manufacturing levels due to the slowdown in demand for kilowatt class fiber products.

[0001633978-20-000018:mdna:57]
[same as prior period, unchanged from 0001633978-20-000008:mdna:70]

[0001633978-20-000018:mdna:58]
R&D expense increased by $0.5 million, or 1.0%, for the three months ended September 26, 2020 compared to the three months ended September 28, 2019. The increase in R&D expense was primarily due to the increase in payroll related expense of $2.7 million, offset by the decrease in R&D materials, as well as a reduction in discretionary travel, primarily due to COVID-19 restrictions.

[0001633978-20-000018:mdna:59]
We believe that continuing our investments in R&D is critical to attaining our strategic objectives. Despite the uncertainty related to COVID-19 and the global economic outlook, we plan to continue to invest in R&D and new products that we believe will further differentiate us in the marketplace and expect our investment in R&D to increase in absolute dollars in future quarters.

[0001633978-20-000018:mdna:60]
[same as prior period, unchanged from 0001633978-20-000008:mdna:74]

[0001633978-20-000018:mdna:61]
SG&A expense decreased by $0.4 million, or 0.7%, during the three months ended September 26, 2020 compared to the three months ended September 28, 2019. The decrease in SG&A expense was primarily due to lower discretionary travel and trade shows of $1.6 million, primarily due to COVID-19 restrictions, offset by the increase in payroll related expense of $1.7 million, due to incremental headcount.

[0001633978-20-000018:mdna:62]
From time to time, we expect to incur non-core expenses, such as mergers and acquisition-related expenses and litigation expenses, which will likely increase our SG&A expenses and potentially impact our profitability expectations in any particular quarter.

[0001633978-20-000018:mdna:63]
[same as prior period, unchanged from 0001633978-20-000008:mdna:78]

[0001633978-20-000018:mdna:64]
We have initiated various strategic restructuring events primarily intended to reduce costs, consolidate our operations, rationalize the manufacturing of our products and align our business in response to market conditions and as a result of our acquisition of Oclaro in fiscal 2019.

[0001633978-20-000018:mdna:65]
During the three months ended September 26, 2020, we did not record any restructuring and related charges in our condensed consolidated statements of operations. During the three months ended September 28, 2019, we recorded restructuring and related charges of $1.3 million attributable to severance charges associated with ongoing acquisition related synergies.

[0001633978-20-000018:mdna:66]
[same as prior period, unchanged from 0001633978-20-000008:mdna:86]

[0001633978-20-000018:mdna:67]
For the three months ended September 26, 2020 and September 28, 2019, we recorded interest expense of $16.0 million and $11.4 million, respectively. The increase in interest expense during the three months ended September 26, 2020 as compared to the three months ended September 28, 2019 was mainly driven by the increase in amortization of the debt discount and contractual interest expense of $11.1 million due to the issuance of our 0.50% Convertible Notes due in 2026 (the “2026 Notes”) in the second quarter of fiscal 2020, offset by the decrease in contractual interest expense on our term loan facility of $6.4 million, which was fully repaid in the second quarter of fiscal 2020.

[0001633978-20-000018:mdna:68]
[same as prior period, unchanged from 0001633978-20-000008:mdna:89]

[0001633978-20-000018:mdna:69]
[same as prior period, unchanged from 0001633978-20-000008:mdna:90]

[0001633978-20-000018:mdna:70]
|  | Three Months Ended |
|  | September 26, 2020 |  | September 28, 2019 |
| Foreign exchange gains (losses), net | $ | (2.3 | ) |  | $ | 1.1 |  |
| Interest income | 2.4 |  |  | 4.0 |  |
| Other income (expense), net | 0.5 |  |  | (0.1 | ) |
| Total other income (expense), net | $ | 0.6 |  |  | $ | 5.0 |  |

[0001633978-20-000018:mdna:71]
For the three months ended September 26, 2020, other income (expense), net decreased by $4.4 million in income as compared to the three months ended September 28, 2019, mainly driven by foreign exchange losses related to the revaluation of non-functional currency denominated balances in our China, United Kingdom, and Japan subsidiaries, as well as lower interest income on our cash equivalents and short-term investments.

[0001633978-20-000018:mdna:72]
[same as prior period, unchanged from 0001633978-20-000008:mdna:95]

[0001633978-20-000018:mdna:73]
| (in millions) | Three Months Ended |
|  | September 26, 2020 |  | September 28, 2019 |
| Provision for income taxes | $ | 16.5 |  |  | $ | 5.8 |  |

[0001633978-20-000018:mdna:74]
We recorded a tax provision of $16.5 million and $5.8 million for the three months ended September 26, 2020 and September 28, 2019, respectively. Our tax provision for the three months ended September 26, 2020 includes a discrete tax benefit of $0.9 million mainly from the excess benefit related to certain stock based compensation that vested during the quarter and is greater than the tax provision for the three months ended September 28, 2019 mainly due to a significant increase in the projected effective tax rate from higher foreign taxes and higher year-to-date income before taxes. Our estimated effective tax rate for fiscal 2021 differs from the 21% U.S. statutory rate primarily due to the earnings of our foreign subsidiaries being taxed at rates that differ from the U.S. statutory rate as well as the U.S. federal R&D tax credits, partially offset by the income tax expense from non-deductible stock-based compensation and the tax effect of Global Intangible Low-Taxed Income (“GILTI”), net of a benefit for foreign tax credits, Base Erosion and Anti-Abuse Tax (“BEAT”), and subpart F inclusion.

[0001633978-20-000018:mdna:75]
[same as prior period, unchanged from 0001633978-20-000008:mdna:98]

[0001633978-20-000018:mdna:76]
The following table summarizes our contractual obligations as of September 26, 2020, and the effect such obligations are expected to have on our liquidity and cash flow over the next five years (in millions):

[0001633978-20-000018:mdna:77]
|  | Payments due by period |
|  | Total |  | Less than 1 year |  | 1 - 3 years |  | 3 - 5 years |  | More than 5 years |
| Contractual Obligations |  |  |  |  |  |  |  |  |  |
| Asset retirement obligations | $ | 4.9 |  |  | $ | 0.3 |  |  | $ | 1.0 |  |  | $ | 1.5 |  |  | $ | 2.1 |  |
| Finance lease liabilities, including imputed interest | 0.4 |  |  | 0.4 |  |  | — |  |  | — |  |  | — |  |
| Operating lease liabilities, including imputed interest (1) | 75.9 |  |  | 13.2 |  |  | 23.3 |  |  | 15.1 |  |  | 24.3 |  |
| Pension plan contributions (2) | 0.5 |  |  | 0.5 |  |  | — |  |  | — |  |  | — |  |
| Purchase obligations (3) | 257.9 |  |  | 254.7 |  |  | 2.9 |  |  | 0.3 |  |  | — |  |
| Convertible notes - principal (4) | 1,500.0 |  |  | — |  |  | — |  |  | 450.0 |  |  | 1,050.0 |  |
| Convertible notes - interest (4) | 38.1 |  |  | 6.4 |  |  | 12.7 |  |  | 11.1 |  |  | 7.9 |  |
| Total | $ | 1,877.7 |  |  | $ | 275.5 |  |  | $ | 39.9 |  |  | $ | 478.0 |  |  | $ | 1,084.3 |  |

[0001633978-20-000018:mdna:78]
(1) The amounts of operating lease liabilities in the table above do not include any sublease income amounts nor do they include payments for short-term leases or variable lease payments. As of September 26, 2020, we expect to receive sublease income of approximately $5.0 million over the next three years.  Refer to “Note 7. Leases” in the notes to condensed consolidated financial statements.

[0001633978-20-000018:mdna:79]
[same as prior period, unchanged from 0001633978-20-000008:mdna:102]

[0001633978-20-000018:mdna:80]
(3) Purchase obligations represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Refer to “Note 14. Commitments and Contingencies” in the notes to condensed consolidated financial statements.

[0001633978-20-000018:mdna:81]
(4) Includes principal and interest on our 0.25% Convertible Notes due in 2024 (the “2024 Notes” and together with the 2026 Notes, the “Notes”) through March 2024, and principal and interest on our 0.50% 2026 Notes through December 2026. We have the right to redeem the 2024 Notes and the 2026 Notes in whole or in part at any time on or after March 15, 2024 and on or after December 15, 2026, respectively. Refer to “Note 9. Debt” in the notes to condensed consolidated financial statements.

[0001633978-20-000018:mdna:82]
As of September 26, 2020, our other non-current liabilities also include $18.2 million of unrecognized tax benefit for uncertain tax positions. We are unable to reliably estimate the timing of future payments related to uncertain tax positions and therefore have excluded them from the preceding table.

[0001633978-20-000018:mdna:83]
[same as prior period, unchanged from 0001633978-20-000008:mdna:106]

[0001633978-20-000018:mdna:84]
[same as prior period, unchanged from 0001633978-20-000008:mdna:107]

[0001633978-20-000018:mdna:85]
[same as prior period, unchanged from 0001633978-20-000008:mdna:108]

[0001633978-20-000018:mdna:86]
[same as prior period, unchanged from 0001633978-20-000008:mdna:109]

[0001633978-20-000018:mdna:87]
As of September 26, 2020 and June 27, 2020, our cash and cash equivalents of $269.5 million and $298.0 million, respectively, were largely held in the United States. As of September 26, 2020 and June 27, 2020, our short-term investments of $1,341.2 million and $1,255.8 million, respectively, were all held in the United States. Cash equivalents and short-term investments are primarily comprised of money market funds, treasuries, highly liquid investment grade fixed income securities, and commercial paper. Our investment policy and strategy is focused on the preservation of capital and supporting our liquidity requirements.

[0001633978-20-000018:mdna:88]
The total amount of cash and cash equivalents outside the United States as of September 26, 2020 was $129.8 million, which was primarily held by entities incorporated in the British Virgin Islands, China, Hong Kong, Japan, Thailand, and the United Kingdom. Although the cash currently held in the United States as well as the cash generated in the United States from future operations is expected to cover our normal operating requirements, a substantial amount of additional cash could be required for other purposes, such as capital expenditures to support our business and growth, including costs associated with increasing internal manufacturing capabilities, particularly in our Thailand facility, strategic transactions and partnerships, and future acquisitions.

[0001633978-20-000018:mdna:89]
Our intent is to indefinitely reinvest funds held outside the United States, except for the funds held in the Cayman Islands, Japan and Hong Kong, and our current plans do not demonstrate a need to repatriate them to fund our domestic operations. However, if in the future, we encounter a significant need for liquidity domestically or at a particular location that we cannot fulfill through borrowings, equity offerings, or other internal or external sources, or the cost to bring back the money is insignificant from a tax perspective, we may determine that cash repatriations are necessary or desirable. Repatriation could result in additional material taxes. These factors may cause us to have an overall tax rate higher than other companies or higher than our tax rates have been in the past. If conditions warrant, we may seek to obtain additional financing through debt or equity sources. To the extent we issue additional shares, our existing stockholders may be diluted. However, any such financing may not be available on terms favorable to us, or may not be available at all.

[0001633978-20-000018:mdna:90]
As of September 26, 2020 and June 27, 2020, the debt component of our 2024 Notes was recorded in long-term liabilities. However, if our stock price exceeds $78.80 for 20 of the last 30 trading days of the second quarter of fiscal 2021, the 2024 Notes would become convertible at the option of the holders. Therefore, the debt component of our 2024 Notes (approximately $375 million as of September 26, 2020) would be reclassified to current liabilities in our condensed consolidated balance sheet.

[0001633978-20-000018:mdna:91]
As of September 26, 2020, our condensed consolidated balance of cash and cash equivalents decreased by $28.5 million, to $269.5 million from $298.0 million as of June 27, 2020. The decrease in cash and cash equivalents was mainly due to cash used in investing activities of $114.0 million and cash used in financing activities of $19.2 million, offset by cash provided by operating activities of $104.7 million during the three months ended September 26, 2020.

[0001633978-20-000018:mdna:92]
[same as prior period, unchanged from 0001633978-20-000008:mdna:113]

[0001633978-20-000018:mdna:93]
Cash provided by operating activities was $104.7 million during the three months ended September 26, 2020. Our net income was $67.1 million for the three months ended September 26, 2020. Cash provided by operating activities was generated primarily from $80.3 million of non-cash items (such as depreciation, stock-based compensation, amortization of intangibles, amortization of debt discount and debt issuance costs on our convertible notes, and other non-cash charges), offset by $42.7 million of changes in our operating assets and liabilities. Changes in our operating assets and liabilities related primarily to an increase in accounts receivable of $30.3 million and inventories of $22.9 million, offset by an increase in accrued expenses and other current and non-current liabilities of $16.3 million.

[0001633978-20-000018:mdna:94]
Cash provided by operating activities was $87.5 million during the three months ended September 28, 2019. Our net income was $47.6 million for the three months ended September 28, 2019. Cash provided by operating activities was generated primarily from $75.7 million of non-cash items (such as depreciation, stock-based compensation, amortization of intangibles, amortization of debt discount and debt issuance costs on our term loans and 2024 Notes, and other non-cash charges), offset by $35.8 million of changes in our operating assets and liabilities. Changes in our operating assets and liabilities related primarily to an increase in accounts receivable of $54.8 million offset by a decrease in inventories of $23.5 million.

[0001633978-20-000018:mdna:95]
[same as prior period, unchanged from 0001633978-20-000008:mdna:117]

[0001633978-20-000018:mdna:96]
Cash used in investing activities of $114.0 million during the three months ended September 26, 2020 was primarily attributable to purchases of short-term investments, net of sales and maturities of $88.2 million and capital expenditures of $26.3 million.

[0001633978-20-000018:mdna:97]
Cash provided by investing activities of $21.7 million during the three months ended September 28, 2019 was primarily attributable to sales of short-term investments, net of purchases of $44.4 million, offset by capital expenditures of $21.7 million and payment for asset acquisition of $1.0 million.

[0001633978-20-000018:mdna:98]
[same as prior period, unchanged from 0001633978-20-000008:mdna:120]

[0001633978-20-000018:mdna:99]
Cash used in financing activities of $19.2 million during the three months ended September 26, 2020 resulted primarily from tax payments related to restricted stock $19.1 million.

[0001633978-20-000018:mdna:100]
Cash used in financing activities of $2.8 million during the three months ended September 28, 2019 resulted from the repayment of principal on our finance leases.

[0001633978-20-000018:mdna:101]
[same as prior period, unchanged from 0001633978-20-000008:mdna:123]

[0001633978-20-000018:mdna:102]
We believe that our cash and cash equivalents as of September 26, 2020 and cash flows from our operating activities will be sufficient to meet our liquidity and capital spending requirements for at least the next 12 months. However, if market conditions are favorable, we may evaluate alternatives to opportunistically pursue additional financing.

[0001633978-20-000018:mdna:103]
[same as prior period, unchanged from 0001633978-20-000008:mdna:125]

[0001633978-20-000018:mdna:104]
[same as prior period, unchanged from 0001633978-20-000008:mdna:126]

[0001633978-20-000018:mdna:105]
[same as prior period, unchanged from 0001633978-20-000008:mdna:127]

[0001633978-20-000018:mdna:106]
[same as prior period, unchanged from 0001633978-20-000008:mdna:128]

[0001633978-20-000018:mdna:107]
[same as prior period, unchanged from 0001633978-20-000008:mdna:129]

[0001633978-20-000018:mdna:108]
[same as prior period, unchanged from 0001633978-20-000008:mdna:130]

[0001633978-20-000018:mdna:109]
[same as prior period, unchanged from 0001633978-20-000008:mdna:131]

[0001633978-20-000018:mdna:110]
[same as prior period, unchanged from 0001633978-20-000008:mdna:132]

[0001633978-20-000018:mdna:111]
[same as prior period, unchanged from 0001633978-20-000008:mdna:133]

[0001633978-20-000018:mdna:112]
[same as prior period, unchanged from 0001633978-20-000008:mdna:134]

[0001633978-20-000018:mdna:113]
[same as prior period, unchanged from 0001633978-20-000008:mdna:135]

[0001633978-20-000018:mdna:114]
[same as prior period, unchanged from 0001633978-20-000008:mdna:136]

[0001633978-20-000018:mdna:115]
[same as prior period, unchanged from 0001633978-20-000008:mdna:137]

[0001633978-20-000018:mdna:116]
[same as prior period, unchanged from 0001633978-20-000008:mdna:138]

[0001633978-20-000018:mdna:117]
41
