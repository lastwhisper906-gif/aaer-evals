# LITE 8-K — 0001633978-20-000017 filed 2020-11-02

## item codes, every 8-K on or before 2020-11-02

- 2020-11-02 0001633978-20-000017 — 2.02, 9.01
- 2020-09-18 0001633978-20-000012 — 5.02, 9.01
- 2020-08-11 0001633978-20-000010 — 2.02, 9.01
- 2020-05-05 0001628280-20-006358 — 2.02, 9.01
- 2020-02-04 0001633978-20-000002 — 2.02, 9.01
- 2019-12-12 0001193125-19-312875 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2019-12-04 0001633978-19-000075 — 8.01
- 2019-11-20 0001633978-19-000074 — 5.07
- 2019-10-31 0001633978-19-000070 — 2.02, 9.01
- 2019-08-08 0001633978-19-000068 — 2.02, 9.01
- 2019-05-08 0001633978-19-000031 — 1.01
- 2019-05-07 0001633978-19-000029 — 2.02, 9.01
- 2019-02-15 0001633978-19-000005 — 9.01 — amendment of 0001193125-18-346211
- 2019-02-08 0001193125-19-031591 — 5.02, 9.01
- 2019-02-05 0001633978-19-000001 — 2.02, 9.01
- 2018-12-10 0001193125-18-346211 — 1.01, 2.01, 2.03, 5.02, 8.01, 9.01
- 2018-12-06 0001633978-18-000150 — 8.01
- 2018-11-14 0001633978-18-000139 — 5.07
- 2018-11-13 0001633978-18-000136 — 3.02
- 2018-11-13 0001633978-18-000132 — 7.01, 9.01
- 2018-11-01 0001628280-18-013238 — 2.02, 9.01
- 2018-08-08 0001633978-18-000056 — 2.02, 9.01
- 2018-06-08 0001193125-18-188241 — 5.02, 9.01
- 2018-05-02 0001633978-18-000029 — 2.02, 9.01
- 2018-03-12 0001193125-18-078154 — 1.01, 2.01, 8.01, 9.01
- 2018-02-06 0001628280-18-001082 — 2.02, 9.01
- 2017-11-08 0001633978-17-000133 — 5.02, 9.01
- 2017-11-07 0001633978-17-000131 — 5.07
- 2017-11-01 0001633978-17-000117 — 2.02, 9.01
- 2017-08-09 0001633978-17-000058 — 2.02, 9.01
- 2017-05-04 0001633978-17-000035 — 2.02, 9.01
- 2017-03-08 0001193125-17-074740 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2017-03-02 0001193125-17-066769 — 8.01, 9.01
- 2017-02-07 0001633978-17-000005 — 2.02, 9.01
- 2017-01-03 0001628280-17-000018 — 4.01, 9.01
- 2016-11-09 0001628280-16-021143 — 5.02, 5.07, 9.01
- 2016-10-27 0001628280-16-020382 — 2.02, 9.01
- 2016-08-09 0001628280-16-018811 — 2.02, 9.01
- 2016-06-21 0001628280-16-017201 — 8.01
- 2016-05-04 0001628280-16-015501 — 2.02, 9.01
- 2016-02-16 0001628280-16-011261 — 5.02, 9.01
- 2016-02-04 0001628280-16-010758 — 5.02, 9.01
- 2016-02-04 0001628280-16-010755 — 2.02, 9.01
- 2015-11-17 0001193125-15-378953 — 7.01
- 2015-11-10 0001628280-15-008606 — 2.02, 9.01
- 2015-09-28 0001193125-15-329665 — 8.01, 9.01
- 2015-08-11 0001193125-15-286405 — 7.01, 9.01
- 2015-08-06 0001193125-15-281219 — 1.01, 5.02, 5.03, 5.05, 8.01, 9.01
- 2015-08-03 0001193125-15-274808 — 5.03, 9.01

## late-filing notifications on or before 2020-11-02

- 2015-11-10 0001628280-15-008612 — NT 10-Q, for the period ended 2015-09-26
- 2015-09-28 0001193125-15-329672 — NT 10-K, for the period ended 2015-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001633978-20-000017:8k_2_02:1]
EX-99.1
2
liteex991q1fy21.htm
EXHIBIT 99.1

[0001633978-20-000017:8k_2_02:2]
Exhibit

[0001633978-20-000017:8k_2_02:3]
NEWS RELEASE

[0001633978-20-000017:8k_2_02:4]
LUMENTUM ANNOUNCES FISCAL FIRST QUARTER 2021 FINANCIAL RESULTS

[0001633978-20-000017:8k_2_02:5]
| • | Net revenue of $452.4 million |

[0001633978-20-000017:8k_2_02:6]
| • | GAAP gross margin of 45.5%; Non-GAAP gross margin of 52.0% |

[0001633978-20-000017:8k_2_02:7]
| • | GAAP operating margin of 21.9%; Non-GAAP operating margin of 33.7% |

[0001633978-20-000017:8k_2_02:8]
| • | GAAP diluted net income per share of $0.86; Non-GAAP diluted net income per share of $1.78 |

[0001633978-20-000017:8k_2_02:9]
San Jose, Calif., November 2, 2020 – Lumentum Holdings Inc. (“Lumentum” or the “Company”) today reported results for its fiscal first quarter of 2021 ended September 26, 2020.

[0001633978-20-000017:8k_2_02:10]
Net revenue for the fiscal first quarter of 2021 was $452.4 million, with GAAP net income of $67.1 million, or $0.86 per diluted share. Net revenue for the fiscal fourth quarter of 2020 was $368.1 million, with GAAP net loss of $(4.6) million, or $(0.06) per diluted share. Net revenue for the fiscal first quarter of 2020 was $449.9 million, with GAAP net income of $47.6 million, or $0.61 per diluted share.

[0001633978-20-000017:8k_2_02:11]
Non-GAAP net income for the fiscal first quarter of 2021 was $139.2 million, or $1.78 per diluted share. Non-GAAP net income for the fiscal fourth quarter of 2020 was $91.7 million, or $1.18 per diluted share. Non-GAAP net income for the fiscal first quarter of 2020 was $111.4 million, or $1.44 per diluted share.

[0001633978-20-000017:8k_2_02:12]
The Company held $1,610.7 million in total cash and short-term investments at the end of the fiscal first quarter of 2021, up $56.9 million compared to the fiscal fourth quarter of 2020.

[0001633978-20-000017:8k_2_02:13]
“We started fiscal 2021 on a strong note, achieving record non-GAAP gross margin, operating margin and earnings per share in the first quarter. We expect the strong momentum to continue into the second quarter,” said Alan Lowe, President and CEO. “Long-term market trends are very favorable, as the world is increasingly shifting to digital and virtual approaches to work, education, and life, which drives increasing demand for our differentiated products and technologies.”

[0001633978-20-000017:8k_2_02:14]
Financial Overview – Fiscal First Quarter Ended September 26, 2020

[0001633978-20-000017:8k_2_02:15]
|  | GAAP Results ($ in millions) |
|  | Q1 |  | Q4 |  | Q1 |  | Change |
|  | FY 2021 |  | FY 2020 |  | FY 2020 |  | Q/Q |  | Y/Y |
| Net revenue | $452.4 |  | $368.1 |  | $449.9 |  | 22.9% |  | 0.6% |
| Gross margin | 45.5% |  | 36.9% |  | 37.3% |  | 860bps |  | 820bps |
| Operating margin | 21.9% |  | 7.3% |  | 13.3% |  | 1,460bps |  | 860bps |
|  | Non-GAAP Results ($ in millions) |
|  | Q1 |  | Q4 |  | Q1 |  | Change |
|  | FY 2021 |  | FY 2020 |  | FY 2020 |  | Q/Q |  | Y/Y |
| Net revenue | $452.4 |  | $368.1 |  | $449.9 |  | 22.9% |  | 0.6% |
| Gross margin | 52.0% |  | 47.2% |  | 45.8% |  | 480bps |  | 620bps |
| Operating margin | 33.7% |  | 24.8% |  | 27.3% |  | 890bps |  | 640bps |

[0001633978-20-000017:8k_2_02:16]
|  | Net Revenue by Segment ($ in millions) |
|  | Q1 |  | % of |  | Q4 |  | Q1 |  | Change |
|  | FY 2021 |  | Net Revenue |  | FY 2020 |  | FY 2020 |  | Q/Q |  | Y/Y |
| Optical Communications | $ | 428.5 |  |  | 94.7 | % |  | $ | 330.3 |  |  | $ | 416.1 |  |  | 29.7 | % |  | 3.0 | % |
| Lasers | 23.9 |  |  | 5.3 | % |  | 37.8 |  |  | 33.8 |  |  | (36.8 | )% |  | (29.3 | )% |
| Total | $ | 452.4 |  |  | 100.0 | % |  | $ | 368.1 |  |  | $ | 449.9 |  |  | 22.9 | % |  | 0.6 | % |

[0001633978-20-000017:8k_2_02:17]
The tables above provide comparisons of quarterly results to prior periods, including sequential quarterly and year-over-year changes. A reconciliation between GAAP and non-GAAP measures is contained in this release under the section titled “Use of Non-GAAP Financial Measures.”

[0001633978-20-000017:8k_2_02:18]
Business Outlook

[0001633978-20-000017:8k_2_02:19]
Lumentum expects the following for the fiscal second quarter 2021:

[0001633978-20-000017:8k_2_02:20]
| • | Net revenue in the range of $465 million to $485 million |

[0001633978-20-000017:8k_2_02:21]
| • | Non-GAAP operating margin of 32.0% to 34.0% |

[0001633978-20-000017:8k_2_02:22]
| • | Non-GAAP diluted earnings per share of $1.70 to $1.90 |

[0001633978-20-000017:8k_2_02:23]
We have not provided reconciliations from GAAP to non-GAAP measures for our outlook. A large portion of non-GAAP adjustments, such as restructuring charges, stock-based compensation, non-cash income tax expense and credits, integration related costs, inventory write down due to plans to exit certain product lines and other costs and contingencies unrelated to current and future operations are by their nature highly volatile and we have low visibility as to the range that may be incurred in the future.

[0001633978-20-000017:8k_2_02:24]
Conference Call

[0001633978-20-000017:8k_2_02:25]
Lumentum will host a conference call today, November 2, 2020, at 5:30 am PT/8:30 am ET. A live webcast of the call and the replay will be available on the Lumentum website at http://investor.lumentum.com through November 9, 2020, at 11:59 pm ET. To listen to the live conference call, dial (866) 270-1533 or (412) 317-0797 and reference the passcode 10149182. To access the replay, dial (877) 344-7529 or (412) 317-0088 and reference the passcode 10149182. Supporting materials outlining the Company’s latest financial results will be posted on http://investor.lumentum.com under the “Events and Presentations” section concurrently with this earnings press release. Lumentum has used, and intends to continue to use, its Investor Relations website as means of disclosing material nonpublic information and for complying with its disclosure obligations under Regulation FD. This press release is being furnished as an exhibit to a Current Report on Form 8-K filed with the Securities and Exchange Commission and will be available at http://www.sec.gov/.

[0001633978-20-000017:8k_2_02:26]
About Lumentum

[0001633978-20-000017:8k_2_02:27]
Lumentum (NASDAQ: LITE) is a market-leading designer and manufacturer of innovative optical and photonic products enabling optical networking and laser applications worldwide. Lumentum optical components and subsystems are part of virtually every type of telecom, enterprise, and data center network. Lumentum lasers enable advanced manufacturing techniques and diverse applications including next-generation 3D sensing capabilities. Lumentum is headquartered in San Jose, California with R&D, manufacturing, and sales offices worldwide. For more information, visit www.lumentum.com.

[0001633978-20-000017:8k_2_02:28]
Forward-Looking Statements

[0001633978-20-000017:8k_2_02:29]
Contact Information

[0001633978-20-000017:8k_2_02:30]
Investors:            Jim Fanucchi, 408-404-5400; investor.relations@lumentum.com

[0001633978-20-000017:8k_2_02:31]
Media:         Sean Ogarrio, 408-546-5405; media@lumentum.com

[0001633978-20-000017:8k_2_02:32]
The following financial tables are presented in accordance with GAAP, unless otherwise specified.

[0001633978-20-000017:8k_2_02:33]
LUMENTUM HOLDINGS INC.

[0001633978-20-000017:8k_2_02:34]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001633978-20-000017:8k_2_02:35]
(in millions, except per share data)

[0001633978-20-000017:8k_2_02:36]
(unaudited)

[0001633978-20-000017:8k_2_02:37]
|  | Three Months Ended |
|  | September 26, 2020 |  | September 28, 2019 |
| Net revenue | $ | 452.4 |  |  | $ | 449.9 |  |
| Cost of sales | 231.7 |  |  | 269.7 |  |
| Amortization of acquired developed intangibles | 15.0 |  |  | 12.5 |  |
| Gross profit | 205.7 |  |  | 167.7 |  |
| Operating expenses: |  |  |  |
| Research and development | 50.4 |  |  | 49.9 |  |
| Selling, general and administrative | 56.3 |  |  | 56.7 |  |
| Restructuring and related charges | — |  |  | 1.3 |  |
| Total operating expenses | 106.7 |  |  | 107.9 |  |
| Income from operations | 99.0 |  |  | 59.8 |  |
| Interest expense | (16.0 | ) |  | (11.4 | ) |
| Other income (expense), net | 0.6 |  |  | 5.0 |  |
| Income before income taxes | 83.6 |  |  | 53.4 |  |
| Provision for income taxes | 16.5 |  |  | 5.8 |  |
| Net income | $ | 67.1 |  |  | $ | 47.6 |  |
| Net income per share: |  |  |  |
| Basic | $ | 0.89 |  |  | $ | 0.62 |  |
| Diluted | $ | 0.86 |  |  | $ | 0.61 |  |
| Shares used to compute net income per share: |  |  |  |
| Basic | 75.3 |  |  | 76.9 |  |
| Diluted | 78.2 |  |  | 77.6 |  |

[0001633978-20-000017:8k_2_02:38]
LUMENTUM HOLDINGS INC.

[0001633978-20-000017:8k_2_02:39]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001633978-20-000017:8k_2_02:40]
(in millions, except share and per share data)

[0001633978-20-000017:8k_2_02:41]
|  | September 26, 2020 |  | June 27, 2020 |
| ASSETS |  |  |  |  |  |
| Current assets: |  |  |  |  |  |
| Cash and cash equivalents | $ | 269.5 |  |  | $ | 298.0 |  |
| Short-term investments | 1,341.2 |  |  | 1,255.8 |  |
| Accounts receivable, net | 263.6 |  |  | 233.5 |  |
| Inventories | 212.6 |  |  | 188.9 |  |
| Prepayments and other current assets | 79.8 |  |  | 73.8 |  |
| Total current assets | 2,166.7 |  |  | 2,050.0 |  |
| Property, plant and equipment, net | 393.4 |  |  | 393.0 |  |
| Operating lease right-of-use assets, net | 74.7 |  |  | 78.7 |  |
| Goodwill | 368.9 |  |  | 368.9 |  |
| Other intangible assets, net | 296.1 |  |  | 316.8 |  |
| Deferred income taxes | 81.6 |  |  | 81.2 |  |
| Other non-current assets | 6.0 |  |  | 4.0 |  |
| Total assets | $ | 3,387.4 |  |  | $ | 3,292.6 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 146.0 |  |  | $ | 150.8 |  |
| Accrued payroll and related expenses | 43.9 |  |  | 53.4 |  |
| Accrued expenses | 34.3 |  |  | 23.7 |  |
| Operating lease liabilities, current | 10.8 |  |  | 10.8 |  |
| Other current liabilities | 58.4 |  |  | 44.3 |  |
| Total current liabilities | 293.4 |  |  | 283.0 |  |
| Convertible notes | 1,134.7 |  |  | 1,120.3 |  |
| Operating lease liabilities, non-current | 56.0 |  |  | 57.6 |  |
| Deferred tax liability | 48.4 |  |  | 46.5 |  |
| Other non-current liabilities | 38.8 |  |  | 36.0 |  |
| Total liabilities | 1,571.3 |  |  | 1,543.4 |  |
| Commitments and contingencies |  |  |  |
| Stockholders’ equity: |  |  |  |
| Common stock, $0.001 par value, 990,000,000 authorized shares, 75,461,945 and 75,100,664 shares issued and outstanding as of September 26, 2020 and June 27, 2020, respectively | 0.1 |  |  | 0.1 |  |
| Additional paid-in capital | 1,677.9 |  |  | 1,676.6 |  |
| Retained earnings | 131.7 |  |  | 64.6 |  |
| Accumulated other comprehensive income | 6.4 |  |  | 7.9 |  |
| Total stockholders’ equity | 1,816.1 |  |  | 1,749.2 |  |
| Total liabilities and stockholders’ equity | $ | 3,387.4 |  |  | $ | 3,292.6 |  |

[0001633978-20-000017:8k_2_02:42]
Use of Non-GAAP Financial Measures

[0001633978-20-000017:8k_2_02:43]
In this press release, Lumentum provides investors with gross margin, gross profit, research and development expense, selling, general and administrative expense, operating margin, operating income, interest and other income (expense), net, income before income taxes, provision for taxes, net income, and net income per share on a non-GAAP basis as well as the non-GAAP measures of EBITDA and Adjusted EBITDA. Lumentum believes this non-GAAP financial information provides additional insight into the Company’s on-going business operations and results, as well as cash generation, and has therefore chosen to provide this information to investors for a more consistent basis of comparison and to help them evaluate the results of the Company’s on-going operations and enable more meaningful period to period comparisons. In addition, the Company believes that providing certain of these measures allow investors to better understand the Company’s cash flows and, importantly, to evaluate the efficacy of the methodology and information used by management to evaluate and measure such cash flows. However, these measures may be different from non-GAAP measures used by other companies, limiting their usefulness for comparison purposes. The non-GAAP financial measures used in this press release should not be considered in isolation from measures of financial performance prepared in accordance with GAAP. Investors are cautioned that there are material limitations associated with the use of non-GAAP financial measures as an analytical tool. In particular, many of the adjustments to our GAAP financial measures reflect the exclusion of items that are recurring and will be reflected in our financial results for the foreseeable future. Further, these non-GAAP financial measures may not be comparable to similarly titled measurements reported by other companies.

[0001633978-20-000017:8k_2_02:44]
Non-GAAP gross margin, non-GAAP gross profit, non-GAAP expenses, non-GAAP operating margin, non-GAAP operating income, non-GAAP income before income taxes, non-GAAP net income, and non-GAAP net income per share and Adjusted EBITDA exclude (i) stock-based compensation, (ii) inventory write-downs and fixed asset impairment due to cancelled programs, plans to exit certain lines of business and other costs and contingencies unrelated to current and future operations, (iii) acquisition and disposition related costs, (iv) integration related costs, (v) amortization of acquired intangibles, (vi) amortization of fair value adjustments, (vii) restructuring and related charges, (viii) non-cash interest expense, (ix) foreign exchange (gains) losses, net, (x) impairment charges, (xi) transferring product lines to Thailand, (xii) excess and obsolete inventory charges driven by U.S. trade restrictions and the related decline in demand from Huawei, (xiii) certain expenses related to the COVID-19 outbreak, and (xiv) non-cash income tax impacts. The presentation of these and other similar items in Lumentum’s non-GAAP financial results should not be interpreted as implying that these items are non-recurring, infrequent or unusual.

[0001633978-20-000017:8k_2_02:45]
A quantitative reconciliation between GAAP and non-GAAP financial data with respect to historical periods is included in the supplemental financial table attached to this press release.

[0001633978-20-000017:8k_2_02:46]
LUMENTUM HOLDINGS INC.

[0001633978-20-000017:8k_2_02:47]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001633978-20-000017:8k_2_02:48]
(in millions, except per share data)

[0001633978-20-000017:8k_2_02:49]
(unaudited)

[0001633978-20-000017:8k_2_02:50]
|  | Three Months Ended |
|  | September 26, 2020 |  | June 27, 2020 |  | September 28, 2019 |
| Gross profit on GAAP basis | $ | 205.7 |  |  | $ | 135.7 |  |  | $ | 167.7 |  |
| Stock-based compensation | 3.7 |  |  | 3.5 |  |  | 4.2 |  |
| Inventory and fixed asset write down due to product lines exit (1) | 0.3 |  |  | 1.0 |  |  | 1.1 |  |
| Integration related costs | — |  |  | 1.8 |  |  | 3.4 |  |
| Amortization of acquired intangibles | 15.0 |  |  | 15.0 |  |  | 12.5 |  |
| Amortization of fair value adjustments | — |  |  | — |  |  | 2.2 |  |
| Expenses related to COVID-19 outbreak (2) | — |  |  | 5.0 |  |  | — |  |
| Other charges (3) | 10.5 |  |  | 11.9 |  |  | 15.0 |  |
| Gross profit on non-GAAP basis | $ | 235.2 |  |  | $ | 173.9 |  |  | $ | 206.1 |  |
| Gross margin on non-GAAP basis | 52.0 | % |  | 47.2 | % |  | 45.8 | % |
| Research and development on GAAP basis | $ | 50.4 |  |  | $ | 49.0 |  |  | $ | 49.9 |  |
| Stock-based compensation | (4.4 | ) |  | (3.8 | ) |  | (3.8 | ) |
| Expenses related to COVID-19 outbreak (2) | — |  |  | (0.5 | ) |  | — |  |
| Other charges | (0.1 | ) |  | 1.2 |  |  | 0.2 |  |
| Research and development on non-GAAP basis | $ | 45.9 |  |  | $ | 45.9 |  |  | $ | 46.3 |  |
| Selling, general and administrative on GAAP basis | $ | 56.3 |  |  | $ | 54.8 |  |  | $ | 56.7 |  |
| Stock-based compensation | (11.4 | ) |  | (9.8 | ) |  | (8.7 | ) |
| Integration related costs | (0.3 | ) |  | (1.1 | ) |  | (3.2 | ) |
| Amortization of acquired intangibles | (5.7 | ) |  | (6.2 | ) |  | (6.3 | ) |
| Other charges | (2.1 | ) |  | (1.1 | ) |  | (1.4 | ) |
| Selling, general and administrative on non-GAAP basis | $ | 36.8 |  |  | $ | 36.6 |  |  | $ | 37.1 |  |
| Income from operations on GAAP basis | $ | 99.0 |  |  | $ | 27.0 |  |  | $ | 59.8 |  |
| Stock-based compensation | 19.5 |  |  | 17.1 |  |  | 16.7 |  |
| Inventory and fixed asset write down due to product lines exit (1) | 0.3 |  |  | 1.0 |  |  | 1.1 |  |
| Integration related costs | 0.3 |  |  | 2.9 |  |  | 6.6 |  |
| Amortization of acquired intangibles | 20.7 |  |  | 21.2 |  |  | 18.8 |  |
| Amortization of fair value adjustments | — |  |  | — |  |  | 2.2 |  |
| Restructuring and related charges | — |  |  | 3.1 |  |  | 1.3 |  |
| Expenses related to COVID-19 outbreak (2) | — |  |  | 5.5 |  |  | — |  |
| Impairment charges (4) | — |  |  | 1.8 |  |  | — |  |
| Other charges | 12.7 |  |  | 11.8 |  |  | 16.2 |  |
| Income from operations on non-GAAP basis | $ | 152.5 |  |  | $ | 91.4 |  |  | $ | 122.7 |  |
| Operating margin on non-GAAP basis | 33.7 | % |  | 24.8 | % |  | 27.3 | % |
| Interest and other income (expense), net on GAAP basis | $ | (15.4 | ) |  | $ | (12.4 | ) |  | $ | (6.4 | ) |
| Gain on sale of product lines | (0.4 | ) |  | (0.7 | ) |  | — |  |

[0001633978-20-000017:8k_2_02:51]
| Foreign exchange (gains) losses, net | 2.3 |  |  | 1.1 |  |  | (1.1 | ) |
| Non-cash interest expense on convertible notes and term loan | 14.4 |  |  | 14.3 |  |  | 4.9 |  |
| Interest and other income (expense), net on non-GAAP basis | $ | 0.9 |  |  | $ | 2.3 |  |  | $ | (2.6 | ) |
| Income before income taxes on GAAP basis | $ | 83.6 |  |  | $ | 14.6 |  |  | $ | 53.4 |  |
| Stock-based compensation | 19.5 |  |  | 17.1 |  |  | 16.7 |  |
| Inventory and fixed asset write down due to product lines exit (1) | 0.3 |  |  | 1.0 |  |  | 1.1 |  |
| Integration related costs | 0.3 |  |  | 2.9 |  |  | 6.6 |  |
| Amortization of acquired intangibles | 20.7 |  |  | 21.2 |  |  | 18.8 |  |
| Amortization of fair value adjustments | — |  |  | — |  |  | 2.2 |  |
| Restructuring and related charges | — |  |  | 3.1 |  |  | 1.3 |  |
| Expenses related to COVID-19 outbreak (2) | — |  |  | 5.5 |  |  | — |  |
| Impairment charges (4) | — |  |  | 1.8 |  |  | — |  |
| Gain on sale of product lines | (0.4 | ) |  | (0.7 | ) |  | — |  |
| Foreign exchange (gains) losses, net | 2.3 |  |  | 1.1 |  |  | (1.1 | ) |
| Non-cash interest expense on convertible notes and term loan | 14.4 |  |  | 14.3 |  |  | 4.9 |  |
| Other charges | 12.7 |  |  | 11.8 |  |  | 16.2 |  |
| Income before income taxes on non-GAAP basis | $ | 153.4 |  |  | $ | 93.7 |  |  | $ | 120.1 |  |
| Provision for income taxes on GAAP basis | $ | 16.5 |  |  | $ | 19.2 |  |  | $ | 5.8 |  |
| Income tax adjustments | (2.3 | ) |  | (17.2 | ) |  | 2.9 |  |
| Provision for income taxes on non-GAAP basis | $ | 14.2 |  |  | $ | 2.0 |  |  | $ | 8.7 |  |
| Net income (loss) on GAAP basis | $ | 67.1 |  |  | $ | (4.6 | ) |  | $ | 47.6 |  |
| Stock-based compensation | 19.5 |  |  | 17.1 |  |  | 16.7 |  |
| Inventory and fixed asset write down due to product lines exit (1) | 0.3 |  |  | 1.0 |  |  | 1.1 |  |
| Integration related costs | 0.3 |  |  | 2.9 |  |  | 6.6 |  |
| Amortization of acquired intangibles | 20.7 |  |  | 21.2 |  |  | 18.8 |  |
| Amortization of fair value adjustments | — |  |  | — |  |  | 2.2 |  |
| Restructuring and related charges | — |  |  | 3.1 |  |  | 1.3 |  |
| Expenses related to COVID-19 outbreak (2) | — |  |  | 5.5 |  |  | — |  |
| Impairment charges (4) | — |  |  | 1.8 |  |  | — |  |
| Gain on sale of product lines | (0.4 | ) |  | (0.7 | ) |  | — |  |
| Foreign exchange (gains) losses, net | 2.3 |  |  | 1.1 |  |  | (1.1 | ) |
| Non-cash interest expense on convertible notes and term loan | 14.4 |  |  | 14.3 |  |  | 4.9 |  |
| Income tax adjustments | 2.3 |  |  | 17.2 |  |  | (2.9 | ) |
| Other charges | 12.7 |  |  | 11.8 |  |  | 16.2 |  |
| Net income on non-GAAP basis | $ | 139.2 |  |  | $ | 91.7 |  |  | $ | 111.4 |  |
| Net income per share on non-GAAP basis | $ | 1.78 |  |  | $ | 1.18 |  |  | $ | 1.44 |  |
| Shares used in per share calculation - diluted on GAAP basis | 78.2 |  |  | 75.0 |  |  | 77.6 |  |
| Non-GAAP adjustment (5) | — |  |  | 2.5 |  |  | — |  |
| Shares used in per share calculation - diluted on non-GAAP basis | 78.2 |  |  | 77.5 |  |  | 77.6 |  |

[0001633978-20-000017:8k_2_02:52]
(1) For the three months ended September 26, 2020, June 27, 2020 and September 28, 2019, we recorded inventory and fixed asset write down charges of $0.3 million, $1.0 million and $1.1 million, respectively, related to the decision to exit the Datacom module and Lithium Niobate product lines.

[0001633978-20-000017:8k_2_02:53]
(2) During the three months ended June 27, 2020, we recorded expenses of $5.5 million related to the COVID-19 outbreak, which included incremental costs for payroll expense such as overtime pay, pay for employees who are not working, facilities costs such as gloves, masks and temperature gauges, and under-utilized capacity at certain facilities, in which manufacturing output was impacted. These COVID-19 related costs were partially offset by benefits realized from government credits for employers’ payroll tax.

[0001633978-20-000017:8k_2_02:54]
(3) Other charges excluded from gross profit on non-GAAP basis for September 26, 2020, June 27, 2020 and September 28, 2019, primarily include costs of transferring product lines to new production facilities, including Thailand of $2.1 million, $3.0 million, and $4.8 million, respectively. We also incurred excess and obsolete inventory charges driven by U.S. trade restrictions and the related decline in demand from Huawei of $5.9 million and $6.7 million during the three months ended September 26, 2020 and September 28, 2019, respectively. In addition, during the three months ended June 27, 2020, we incurred $6.2 million impairment charges associated with excess capacity related to our Fiber laser business.

[0001633978-20-000017:8k_2_02:55]
(4) For the three months ended June 27, 2020, we recorded impairment charges of $1.8 million in property, plant and equipment related to the decision to exit the Datacom module product line.

[0001633978-20-000017:8k_2_02:56]
(5) This adjustment represents weighted-average potentially dilutive securities from our stock-based benefit plans excluded from the computation of diluted net loss per share attributable to common stockholders on a GAAP basis because the effect would have been anti-dilutive. This adjustment amount is added for the computation of diluted net income per share on a non-GAAP basis as we had a net income on a non-GAAP basis.

[0001633978-20-000017:8k_2_02:57]
LUMENTUM HOLDINGS INC.

[0001633978-20-000017:8k_2_02:58]
RECONCILIATION OF GAAP NET INCOME (LOSS) TO ADJUSTED EBITDA

[0001633978-20-000017:8k_2_02:59]
(in millions, except per share data)

[0001633978-20-000017:8k_2_02:60]
(unaudited)

[0001633978-20-000017:8k_2_02:61]
|  | Three Months Ended |
|  | September 26, 2020 |  | June 27, 2020 |  | September 28, 2019 |
| GAAP Net income (loss) | $ | 67.1 |  |  | $ | (4.6 | ) |  | $ | 47.6 |  |
| Interest and other expense (income), net | 15.4 |  |  | 12.4 |  |  | 6.4 |  |
| Provision for income taxes | 16.5 |  |  | 19.2 |  |  | 5.8 |  |
| Depreciation | 23.8 |  |  | 25.5 |  |  | 31.6 |  |
| Amortization of acquired intangibles | 20.7 |  |  | 21.2 |  |  | 18.8 |  |
| EBITDA | 143.5 |  |  | 73.7 |  |  | 110.2 |  |
| Amortization of fair value adjustments | — |  |  | — |  |  | 2.2 |  |
| Restructuring and related charges | — |  |  | 3.1 |  |  | 1.3 |  |
| Stock-based compensation | 19.5 |  |  | 17.1 |  |  | 16.7 |  |
| Inventory and fixed asset write down due to product lines exit | 0.3 |  |  | 1.0 |  |  | 1.1 |  |
| Integration related costs | 0.3 |  |  | 2.9 |  |  | 6.6 |  |
| Impairment charges | — |  |  | 1.8 |  |  | — |  |
| Expenses related to COVID-19 outbreak | — |  |  | 5.5 |  |  | — |  |
| Other charges | 12.7 |  |  | 11.8 |  |  | 16.2 |  |
| Adjusted EBITDA | $ | 176.3 |  |  | $ | 116.9 |  |  | $ | 154.3 |  |
