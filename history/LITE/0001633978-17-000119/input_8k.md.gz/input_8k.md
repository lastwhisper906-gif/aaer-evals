# LITE 8-K — 0001633978-17-000117 filed 2017-11-01

## item codes, every 8-K on or before 2017-11-01

- 2017-11-01 0001633978-17-000117 — 2.02, 9.01
- 2017-08-09 0001633978-17-000058 — 2.02, 9.01
- 2017-05-04 0001633978-17-000035 — 2.02, 9.01
- 2017-03-08 0001193125-17-074740 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2017-03-02 0001193125-17-066769 — 8.01, 9.01
- 2017-02-07 0001633978-17-000005 — 2.02, 9.01
- 2017-01-03 0001628280-17-000018 — 4.01, 9.01
- 2016-11-09 0001628280-16-021143 — 5.02, 5.07, 9.01
- 2016-10-27 0001628280-16-020382 — 2.02, 9.01
- 2016-08-09 0001628280-16-018811 — 2.02, 9.01
- 2016-06-21 0001628280-16-017201 — 8.01
- 2016-05-04 0001628280-16-015501 — 2.02, 9.01
- 2016-02-16 0001628280-16-011261 — 5.02, 9.01
- 2016-02-04 0001628280-16-010758 — 5.02, 9.01
- 2016-02-04 0001628280-16-010755 — 2.02, 9.01
- 2015-11-17 0001193125-15-378953 — 7.01
- 2015-11-10 0001628280-15-008606 — 2.02, 9.01
- 2015-09-28 0001193125-15-329665 — 8.01, 9.01
- 2015-08-11 0001193125-15-286405 — 7.01, 9.01
- 2015-08-06 0001193125-15-281219 — 1.01, 5.02, 5.03, 5.05, 8.01, 9.01
- 2015-08-03 0001193125-15-274808 — 5.03, 9.01

## late-filing notifications on or before 2017-11-01

- 2015-11-10 0001628280-15-008612 — NT 10-Q, for the period ended 2015-09-26
- 2015-09-28 0001193125-15-329672 — NT 10-K, for the period ended 2015-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001633978-17-000117:8k_2_02:1]
EX-99.1
2
lite_ex991xq1fy18.htm
EXHIBIT 99.1

[0001633978-17-000117:8k_2_02:2]
Exhibit

[0001633978-17-000117:8k_2_02:3]
NEWS RELEASE

[0001633978-17-000117:8k_2_02:4]
LUMENTUM ANNOUNCES FISCAL FIRST QUARTER 2018 RESULTS

[0001633978-17-000117:8k_2_02:5]
Fiscal First Quarter Highlights

[0001633978-17-000117:8k_2_02:6]
| • | Net Revenue of $243.2 million |

[0001633978-17-000117:8k_2_02:7]
| • | GAAP Operating margin of 1.1%; Non-GAAP Operating margin of 11.8% |

[0001633978-17-000117:8k_2_02:8]
| • | GAAP diluted Net income per share of $0.11; Non-GAAP diluted Net income per share of $0.43 |

[0001633978-17-000117:8k_2_02:9]
Milpitas, Calif., November 1, 2017 – Lumentum Holdings Inc. (“Lumentum” or the “Company”) today reported results for its fiscal first quarter ended September 30, 2017.

[0001633978-17-000117:8k_2_02:10]
Net revenue for the fiscal first quarter of 2018 was $243.2 million, with GAAP net income of $7.1 million, or $0.11 per diluted share.  Net revenue for fiscal fourth quarter of 2017 was $222.7 million, with GAAP net loss of $(54.9) million, or $(0.90) per diluted share. Net revenue for the fiscal first quarter of 2017 was $258.1 million, with GAAP net loss of $(3.4) million, or $(0.06) per diluted share.

[0001633978-17-000117:8k_2_02:11]
Non-GAAP net income for the fiscal first quarter of 2018 was $27.8 million or $0.43 per diluted share. Non-GAAP net income for fiscal fourth quarter of 2017 was $25.0 million, or $0.39 per diluted share. Non-GAAP net income for the fiscal first quarter of 2017 was $30.7 million, or $0.49 per diluted share. The Company held $532.5 million in total cash and short-term investments at the end of the fiscal first quarter of 2018.

[0001633978-17-000117:8k_2_02:12]
“Despite first quarter headwinds in the telecom and datacom markets, we returned to solid growth driven by a ramp in our 3D sensing business, which will accelerate significantly in the second quarter,” said Alan Lowe, President and CEO. “We continue to make good progress on our strategic initiatives, and our pipeline of new products and design wins position us well in the markets in which we participate.”

[0001633978-17-000117:8k_2_02:13]
Financial Overview – Fiscal First Quarter Ended September 30, 2017

[0001633978-17-000117:8k_2_02:14]
|  | GAAP Results ($ in millions) |
|  | Q1 |  | Q4 |  | Q1 |  | Change |
|  | FY 2018 |  | FY 2017 |  | FY 2017 |  | Q/Q |  | Y/Y |
| Net revenue | $243.2 |  | $222.7 |  | $258.1 |  | 9.2% |  | (5.8)% |
| Gross margin | 28.2% |  | 30.2% |  | 31.7% |  | (200)bps |  | (350)bps |
| Operating margin | 1.1% |  | 1.8% |  | 6.5% |  | (70)bps |  | (540)bps |
|  | Non-GAAP Results ($ in millions) |
|  | Q1 |  | Q4 |  | Q1 |  | Change |
|  | FY 2018 |  | FY 2017 |  | FY 2017 |  | Q/Q |  | Y/Y |
| Net revenue | $243.2 |  | $222.7 |  | $258.1 |  | 9.2% |  | (5.8)% |
| Gross margin | 34.0% |  | 32.9% |  | 34.2% |  | 110bps |  | (20)bps |
| Operating margin | 11.8% |  | 9.2% |  | 12.7% |  | 260bps |  | (90)bps |

[0001633978-17-000117:8k_2_02:15]
|  | Net Revenue by Segment ($ in millions) |
|  | Q1 |  | % of |  | Q4 |  | Q1 |  | Change |
|  | FY 2018 |  | Net Revenue |  | FY 2017 |  | FY 2017 |  | Q/Q |  | Y/Y |
| Optical Communications | $207.9 |  | 85.5% |  | $186.8 |  | $218.3 |  | 11.3% |  | (4.8)% |
| Lasers | 35.3 |  | 14.5% |  | 35.9 |  | 39.8 |  | (1.7)% |  | (11.3)% |
| Total | $243.2 |  | 100.0% |  | $222.7 |  | $258.1 |  | 9.2% |  | (5.8)% |

[0001633978-17-000117:8k_2_02:16]
The tables above provide comparisons of quarterly results to prior periods, including sequential quarterly and year-over-year changes. A reconciliation between GAAP and non-GAAP measures is contained in this release under the section titled “Use of Non-GAAP Financial Measures.”

[0001633978-17-000117:8k_2_02:17]
Business Outlook

[0001633978-17-000117:8k_2_02:18]
The Company expects the following for the fiscal second quarter 2018:

[0001633978-17-000117:8k_2_02:19]
•Net Revenue to be in the range of $345 million to $375 million

[0001633978-17-000117:8k_2_02:20]
•Non-GAAP Operating margin of 21.0% to 23.0%

[0001633978-17-000117:8k_2_02:21]
•Non-GAAP diluted earnings per share of $1.05 to $1.25;

[0001633978-17-000117:8k_2_02:22]
Note:  Earnings per share based on approximately 65.3 million shares outstanding on a fully diluted basis

[0001633978-17-000117:8k_2_02:23]
Our projection of 65.3 million shares outstanding does not include the potentially dilutive effect of the convertible notes, as we intend to settle the face value in cash. The notes will have an impact on our non-GAAP diluted EPS when the average price of our common stock exceeds the conversion price of $60.62.

[0001633978-17-000117:8k_2_02:24]
We have not provided reconciliations from GAAP to non-GAAP measures for our outlook. A large portion of non-GAAP adjustments, such as derivative liability adjustments, restructuring, stock-based compensation, litigation, and other costs and contingencies unrelated to current and future operations are by their nature highly volatile and we have low visibility as to the range that may be incurred in the future. For example, the unrealized gain (loss) on the derivative liability for Series A Preferred Stock in our fiscal first quarter of 2018 was a gain of $4.2 million, as compared to a loss of $(5.5) million in the fiscal fourth quarter of 2017. The Series A Preferred Stock derivative liability is revalued based on the fair market value of our common stock on the last day of each fiscal quarter, which is difficult to predict and subject to change. On June 29, 2017, we met the requirements to account for the conversion option of the Convertible Senior Notes as equity and the conversion option will no longer be marked to market.

[0001633978-17-000117:8k_2_02:25]
Conference Call

[0001633978-17-000117:8k_2_02:26]
Lumentum will host a conference call on November 1, 2017 at 5:30am PT/8:30am ET. A live webcast of the call and the replay will be available on the Lumentum website at http://investor.lumentum.com through November 8, 2017 at 8:30am PT/11:30am ET. Supporting materials outlining the Company’s latest financial results will be posted on http://investor.lumentum.com under the “Events and Presentations” section concurrently with this earnings press release. This press release is being furnished as an exhibit to a Current Report on Form 8-K with the Securities and Exchange Commission and will be available at http://www.sec.gov/.

[0001633978-17-000117:8k_2_02:27]
About Lumentum

[0001633978-17-000117:8k_2_02:28]
Lumentum (NASDAQ: LITE) is a market-leading manufacturer of innovative optical and photonic products enabling optical networking and commercial laser customers worldwide. Lumentum’s optical components and subsystems are part of virtually every type of telecom, enterprise, and data center network. Lumentum’s commercial lasers enable advanced manufacturing techniques and diverse applications including next-generation 3D sensing capabilities. Lumentum is headquartered in Milpitas, California with R&D, manufacturing, and sales offices worldwide.  For more information, visit https://www.lumentum.com/en.

[0001633978-17-000117:8k_2_02:29]
Forward-Looking Statements

[0001633978-17-000117:8k_2_02:30]
release are made as of the date hereof and the Company assumes no obligation to update such statements, except as required by applicable law.

[0001633978-17-000117:8k_2_02:31]
Contact Information

[0001633978-17-000117:8k_2_02:32]
Investors: Chris Coldren, 408-404-0606; investor.relations@lumentum.com

[0001633978-17-000117:8k_2_02:33]
Press: Greg Kaufman, 408-546-4593; media@lumentum.com

[0001633978-17-000117:8k_2_02:34]
The following financial tables are presented in accordance with GAAP, unless otherwise specified.

[0001633978-17-000117:8k_2_02:35]
LUMENTUM HOLDINGS INC.

[0001633978-17-000117:8k_2_02:36]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0001633978-17-000117:8k_2_02:37]
(in millions, except per share data)

[0001633978-17-000117:8k_2_02:38]
(unaudited)

[0001633978-17-000117:8k_2_02:39]
|  | Three Months Ended |  |
|  | September 30, 2017 |  | October 1, 2016 |  |
| Net revenue | $ | 243.2 |  |  | $ | 258.1 |  |  |
| Cost of sales | 173.9 |  |  | 174.7 |  |  |
| Amortization of acquired developed technologies | 0.8 |  |  | 1.7 |  |  |
| Gross profit | 68.5 |  |  | 81.7 |  |  |
| Operating expenses: |  |  |  |  |
| Research and development | 36.3 |  |  | 36.9 |  |  |
| Selling, general and administrative | 26.6 |  |  | 25.1 |  |  |
| Restructuring and related charges | 2.9 |  |  | 2.9 |  |  |
| Total operating expenses | 65.8 |  |  | 64.9 |  |  |
| Income from operations | 2.7 |  |  | 16.8 |  |  |
| Unrealized gain (loss) on derivative liability | 4.2 |  |  | (22.7 | ) |  |
| Interest and other (expense) income, net | (3.4 | ) |  | 0.2 |  |  |
| Income (loss) before income taxes | 3.5 |  |  | (5.7 | ) |  |
| Benefit from income tax | (3.6 | ) |  | (2.3 | ) |  |
| Net income (loss) | 7.1 |  |  | (3.4 | ) |  |
| Net income (loss) per share: |  |  |  |  |
| Basic | $ | 0.12 |  |  | $ | (0.06 | ) |  |
| Diluted | $ | 0.11 |  |  | $ | (0.06 | ) |  |
| Items reconciling net income (loss) to net income (loss) available to common stockholders: |  |  |  |  |
| Cumulative dividends on Series A preferred stock | (0.2 | ) |  | (0.2 | ) |  |
| Net income (loss) available to common stockholders | $ | 6.9 |  |  | $ | (3.6 | ) |  |
| Net income (loss) available to common stockholders per share: |  |  |  |  |
| Basic | $ | 0.11 |  |  | $ | (0.06 | ) |  |
| Diluted | $ | 0.11 |  |  | $ | (0.06 | ) |  |
| Shares used in per share calculation: |  |  |  |  |
| Basic | 61.7 |  |  | 59.9 |  |  |
| Diluted | 64.5 |  |  | 59.9 |  |  |
| Diluted shares available to common stockholders | 63.0 |  |  | 59.9 |  |  |

[0001633978-17-000117:8k_2_02:40]
LUMENTUM HOLDINGS INC.

[0001633978-17-000117:8k_2_02:41]
CONSOLIDATED BALANCE SHEETS

[0001633978-17-000117:8k_2_02:42]
(in millions, except share and per share data)

[0001633978-17-000117:8k_2_02:43]
(unaudited)

[0001633978-17-000117:8k_2_02:44]
|  | September 30, 2017 |  | July 1, 2017 |
| ASSETS |  |  |  |  |  |
| Current assets: |  |  |  |  |  |
| Cash and cash equivalents | $ | 150.8 |  |  | $ | 272.9 |  |
| Short-term investments | 381.7 |  |  | 282.4 |  |
| Accounts receivable, net | 173.8 |  |  | 166.3 |  |
| Inventories | 147.2 |  |  | 145.2 |  |
| Prepayments and other current assets | 69.0 |  |  | 63.5 |  |
| Total current assets | 922.5 |  |  | 930.3 |  |
| Property, plant and equipment, net | 293.7 |  |  | 273.5 |  |
| Goodwill and intangibles, net | 21.0 |  |  | 21.5 |  |
| Deferred income taxes, net | 7.6 |  |  | 3.9 |  |
| Other non-current assets | 3.6 |  |  | 3.7 |  |
| Total assets | $ | 1,248.4 |  |  | $ | 1,232.9 |  |
| LIABILITIES, REDEEMABLE CONVERTIBLE PREFERRED STOCK, AND EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 111.6 |  |  | $ | 114.8 |  |
| Accrued payroll and related expenses | 25.1 |  |  | 27.5 |  |
| Income taxes payable | 0.5 |  |  | 0.7 |  |
| Accrued expenses | 18.0 |  |  | 19.3 |  |
| Other current liabilities | 22.0 |  |  | 21.9 |  |
| Total current liabilities | 177.2 |  |  | 184.2 |  |
| Convertible note | 321.6 |  |  | 317.5 |  |
| Derivative liability | 47.4 |  |  | 51.6 |  |
| Other non-current liabilities | 25.3 |  |  | 25.0 |  |
| Total liabilities | 571.5 |  |  | 578.3 |  |
| Redeemable convertible preferred stock: |  |  |  |
| Non-controlling interest redeemable convertible Series A preferred stock, $0.001 par value, 10,000,000 authorized shares; 35,805 shares issued and outstanding as of September 30, 2017 and July 1, 2017 | 35.8 |  |  | 35.8 |  |
| Total redeemable convertible preferred stock | 35.8 |  |  | 35.8 |  |
| Stockholders’ equity: |  |  |  |
| Common stock, $0.001 par value, 990,000,000 authorized shares, 62,006,405 and 61,476,103 shares issued and outstanding as of September 30, 2017 and July 1, 2017, respectively | 0.1 |  |  | 0.1 |  |
| Additional paid-in capital | 705.7 |  |  | 694.5 |  |
| Retained earnings | (73.9 | ) |  | (83.2 | ) |
| Accumulated other comprehensive income | 9.2 |  |  | 7.4 |  |
| Total stockholders’ equity | 641.1 |  |  | 618.8 |  |
| Total liabilities, redeemable convertible preferred stock, and stockholders’ equity | $ | 1,248.4 |  |  | $ | 1,232.9 |  |

[0001633978-17-000117:8k_2_02:45]
Use of Non-GAAP Financial Measures

[0001633978-17-000117:8k_2_02:46]
In this press release, Lumentum provides investors with gross margin, operating margin, net income, and net income (loss) per share on a non-GAAP basis. Lumentum believes this non-GAAP financial information provides additional insight into the Company’s on-going performance and has therefore chosen to provide this information to investors for a more consistent basis of comparison and to help them evaluate the results of the Company’s on-going operations and enable more meaningful period to period comparisons. Specifically, the Company believes that providing this information allows investors to better understand the Company’s financial performance and, importantly, to evaluate the efficacy of the methodology and information used by management to evaluate and measure such operating performance.  However, these measures may be different from non-GAAP measures used by other companies, limiting their usefulness for comparison purposes. The non-GAAP financial measures used in this press release should not be considered in isolation from measures of financial performance prepared in accordance with GAAP. Investors are cautioned that there are material limitations associated with the use of non-GAAP financial measures as an analytical tool. In particular, many of the adjustments to our GAAP financial measures reflect the exclusion of items that are recurring and will be reflected in our financial results for the foreseeable future. Further, these non-GAAP financial measures may not be comparable to similarly titled measurements reported by other companies.

[0001633978-17-000117:8k_2_02:47]
Non-GAAP gross margin, non-GAAP operating margin, non-GAAP net income, and non-GAAP net income per share, Adjusted EBITDA, non-GAAP gross profit, non-GAAP operating income, non-GAAP income (loss) before income taxes and non-GAAP expenses exclude (i) workforce related charges such as severance, retention bonuses and employee relocation costs related to formal restructuring plans, (ii) costs for facilities not required for ongoing operations, and costs related to the relocation of certain equipment from these facilities and/or contract manufacturer facilities, (iii) stock-based compensation, (iv) amortization of intangibles, (v) amortization of acquired developed technologies, (vi) non-cash interest expense, (vii) unrealized loss on derivative liability, (viii) warranty charges related to our vendor quality issues with expected future recoveries and (ix) other charges comprising mainly of inventory write-downs due to cancelled programs, as well as, acquisition, integration, litigation and other costs and contingencies unrelated to current and future operations including post-separation activities such as small site consolidations, reorganizations, insourcing or outsourcing of activities, severance related costs and transition related costs for the separation from Viavi Solutions Inc. (formerly JDS Uniphase Corporation) on July 31, 2015. Management does not believe that these non-GAAP items are reflective of the Company’s underlying operating performance. The presentation of these and other similar items in Lumentum’s non-GAAP financial results should not be interpreted as implying that these items are non-recurring, infrequent or unusual.

[0001633978-17-000117:8k_2_02:48]
A quantitative reconciliation between GAAP and non-GAAP financial data with respect to historical periods is included in the supplemental financial table attached to this press release.

[0001633978-17-000117:8k_2_02:49]
LUMENTUM HOLDINGS INC.

[0001633978-17-000117:8k_2_02:50]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001633978-17-000117:8k_2_02:51]
(in millions, except per share data)

[0001633978-17-000117:8k_2_02:52]
(unaudited)

[0001633978-17-000117:8k_2_02:53]
|  | Three Months Ended |  |
|  | September 30, 2017 |  | October 1, 2016 |  |
| Gross profit on GAAP basis | $ | 68.5 |  |  | $ | 81.7 |  |  |
| Stock-based compensation | 2.7 |  |  | 2.0 |  |  |
| Other charges related to non-recurring activities (a) | 10.7 |  |  | 2.8 |  |  |
| Amortization of acquired developed technologies | 0.8 |  |  | 1.7 |  |  |
| Gross profit on non-GAAP basis | $ | 82.7 |  |  | $ | 88.2 |  |  |
| Research and development on GAAP basis | $ | 36.3 |  |  | $ | 36.9 |  |  |
| Stock-based compensation | (3.1 | ) |  | (2.8 | ) |  |
| Other charges related to non-recurring activities | (0.7 | ) |  | (0.3 | ) |  |
| Research and development on non-GAAP basis | $ | 32.5 |  |  | $ | 33.8 |  |  |
| Selling, general and administrative on GAAP basis | $ | 26.6 |  |  | $ | 25.1 |  |  |
| Stock-based compensation | (3.5 | ) |  | (2.9 | ) |  |
| Other charges related to non-recurring activities | (1.5 | ) |  | (0.4 | ) |  |
| Amortization of acquired developed technologies | — |  |  | (0.1 | ) |  |
| Selling, general and administrative on non-GAAP basis | $ | 21.6 |  |  | $ | 21.7 |  |  |
| Income from operations on GAAP basis | $ | 2.7 |  |  | $ | 16.8 |  |  |
| Stock-based compensation | 9.3 |  |  | 7.7 |  |  |
| Other charges related to non-recurring activities (a) | 12.9 |  |  | 3.5 |  |  |
| Amortization of acquired developed technologies | 0.8 |  |  | 1.8 |  |  |
| Restructuring and related charges | 2.9 |  |  | 2.9 |  |  |
| Income from operations on non-GAAP basis | $ | 28.6 |  |  | $ | 32.7 |  |  |
| Interest and other (expense) income, net on GAAP basis | $ | (3.4 | ) |  | $ | 0.2 |  |  |
| Effective interest expense on convertible note | 4.1 |  |  | — |  |  |
| Interest and other income, net on non-GAAP basis | $ | 0.7 |  |  | $ | 0.2 |  |  |
| Income (loss) before income taxes on GAAP basis | $ | 3.5 |  |  | $ | (5.7 | ) |  |
| Stock-based compensation | 9.3 |  |  | 7.7 |  |  |
| Other charges related to non-recurring activities (a) | 12.9 |  |  | 3.5 |  |  |
| Amortization of acquired developed technologies | 0.8 |  |  | 1.8 |  |  |
| Restructuring and related charges | 2.9 |  |  | 2.9 |  |  |
| Effective interest expense on convertible note | 4.1 |  |  | — |  |  |
| Unrealized (gain) loss on derivative liability | (4.2 | ) |  | 22.7 |  |  |
| Income before income taxes on non-GAAP basis | $ | 29.3 |  |  | $ | 32.9 |  |  |
| Benefit from income taxes on GAAP basis | $ | (3.6 | ) |  | $ | (2.3 | ) |  |

[0001633978-17-000117:8k_2_02:54]
| Impact of non-GAAP income tax expense | 5.1 |  |  | 4.5 |  |  |
| Provision for income taxes on non-GAAP basis | $ | 1.5 |  |  | $ | 2.2 |  |  |
| Net income (loss) on GAAP basis | $ | 7.1 |  |  | $ | (3.4 | ) |  |
| Stock-based compensation | 9.3 |  |  | 7.7 |  |  |
| Other charges related to non-recurring activities (a) | 12.9 |  |  | 3.5 |  |  |
| Amortization of acquired developed technologies | 0.8 |  |  | 1.8 |  |  |
| Restructuring and related charges | 2.9 |  |  | 2.9 |  |  |
| Effective interest expense on convertible note | 4.1 |  |  | — |  |  |
| Unrealized (gain) loss on derivative liability | (4.2 | ) |  | 22.7 |  |  |
| Impact of non-GAAP income tax expense | (5.1 | ) |  | (4.5 | ) |  |
| Net income on non-GAAP basis | $ | 27.8 |  |  | $ | 30.7 |  |  |
| Net income per share on non-GAAP basis | $ | 0.43 |  |  | $ | 0.49 |  |  |
| Shares used in per share calculation - diluted on GAAP basis | 64.5 |  |  | 59.9 |  |  |
| Non-GAAP adjustment (b) | — |  |  | 2.5 |  |  |
| Shares used in per share calculation - diluted on non-GAAP basis | 64.5 |  |  | 62.4 |  |  |

[0001633978-17-000117:8k_2_02:55]
(a) The increase related primarily to inventory write-downs due to cancelled programs.

[0001633978-17-000117:8k_2_02:56]
(b) This adjustment represents weighted-average potentially dilutive securities excluded from the computation of diluted net loss per share attributable to common stockholders on a GAAP basis because the effect would have been antidilutive. This adjustment amount is added for the computation of diluted net income per share on a non-GAAP basis as we had net income on a non-GAAP basis for all periods presented.

[0001633978-17-000117:8k_2_02:57]
LUMENTUM HOLDINGS INC.

[0001633978-17-000117:8k_2_02:58]
RECONCILIATION OF GAAP NET INCOME (LOSS) TO ADJUSTED EBITDA

[0001633978-17-000117:8k_2_02:59]
(in millions)

[0001633978-17-000117:8k_2_02:60]
(unaudited)

[0001633978-17-000117:8k_2_02:61]
|  | Three Months Ended |  |
|  | September 30, 2017 |  | October 1, 2016 |  |
| GAAP net income (loss) | $ | 7.1 |  |  | $ | (3.4 | ) |  |
| Interest and other expense (income), net | 3.4 |  |  | (0.2 | ) |  |
| Benefit from income taxes | (3.6 | ) |  | (2.3 | ) |  |
| Depreciation | 16.7 |  |  | 11.9 |  |  |
| Amortization | 0.8 |  |  | 1.8 |  |  |
| EBITDA | 24.4 |  |  | 7.8 |  |  |
| Restructuring and related charges | 2.9 |  |  | 2.9 |  |  |
| Stock-based compensation | 9.3 |  |  | 7.7 |  |  |
| Other charges related to non-recurring activities (a) | 12.9 |  |  | 3.5 |  |  |
| Unrealized (gain) loss on derivative liability | (4.2 | ) |  | 22.7 |  |  |
| Adjusted EBITDA | $ | 45.3 |  |  | $ | 44.6 |  |  |

[0001633978-17-000117:8k_2_02:62]
(a) The increase related primarily to inventory write-downs due to cancelled programs.
