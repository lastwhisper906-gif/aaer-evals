# LITE notes — 0001633978-17-000119


## lite:PropertyPlantandEquipmentNetTableTextBlock

[0001633978-17-000119:notes:1]
[same as prior period, unchanged from 0001633978-17-000037:notes:1]

[0001633978-17-000119:notes:2]
|  | September 30, 2017 |  | July 1, 2017 |
| Land | $ | 10.6 |  |  | $ | 10.6 |  |
| Buildings and improvement | 40.8 |  |  | 37.3 |  |
| Machinery and equipment (1) | 484.7 |  |  | 461.1 |  |
| Furniture and fixtures and software | 39.8 |  |  | 35.8 |  |
| Leasehold improvements | 30.8 |  |  | 30.5 |  |
| Construction in progress | 90.9 |  |  | 84.6 |  |
|  | 697.6 |  |  | 659.9 |  |
| Less: Accumulated depreciation | (403.9 | ) |  | (386.4 | ) |
| Property, plant and equipment, net | $ | 293.7 |  |  | $ | 273.5 |  |

[0001633978-17-000119:notes:3]
(1) In the first quarter of fiscal 2018, we started leasing equipment under a capital lease. Included in the table above is our capital lease asset of $7.4 million, net of depreciation expense of $1.1 million.


## lite:ScheduleOfOtherLiabilitiesCurrentTableTextBlock

[0001633978-17-000119:notes:4]
[same as prior period, unchanged from 0001633978-17-000037:notes:3]

[0001633978-17-000119:notes:5]
|  | September 30, 2017 |  | July 1, 2017 |
| Warranty accrual (1) | $ | 9.4 |  |  | $ | 9.7 |  |
| Restructuring accrual and related charges (2) | 1.3 |  |  | 3.8 |  |
| Deferred revenue and customer deposits | 4.9 |  |  | 6.9 |  |
| Capital lease obligation (1) | 4.9 |  |  | — |  |
| Other current liabilities | 1.5 |  |  | 1.5 |  |
| Other current liabilities | $ | 22.0 |  |  | $ | 21.9 |  |

[0001633978-17-000119:notes:6]
(1) Refer to “Note 16. Commitments and Contingencies” in the Notes to Unaudited Condensed Consolidated Financial Statements.

[0001633978-17-000119:notes:7]
(2) Refer to “Note 13. Restructuring and Related Charges” in the Notes to Unaudited Condensed Consolidated Financial Statements.


## lite:ScheduleOfOtherLiabilitiesNoncurrentTableTextBlock

[0001633978-17-000119:notes:8]
[same as prior period, unchanged from 0001633978-17-000037:notes:5]

[0001633978-17-000119:notes:9]
|  | September 30, 2017 |  | July 1, 2017 |
| Asset retirement obligation | $ | 2.5 |  |  | $ | 2.5 |  |
| Pension and related accrual | 4.2 |  |  | 3.9 |  |
| Deferred rent | 3.5 |  |  | 3.3 |  |
| Unrecognized tax benefit | 7.9 |  |  | 10.5 |  |
| Capital lease obligation (1) | 2.4 |  |  | — |  |
| Other non-current liabilities | 4.8 |  |  | 4.8 |  |
| Other non-current liabilities | $ | 25.3 |  |  | $ | 25.0 |  |


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001633978-17-000119:notes:10]
The following table summarizes our short-term investments by category (in millions) as of September 30, 2017:

[0001633978-17-000119:notes:11]
|  | As of September 30, 2017 |
|  | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Certificate of deposit | $ | 113.2 |  |  | $ | — |  |  | $ | — |  |  | $ | 113.2 |  |
| Commercial paper | 23.5 |  |  | — |  |  | — |  |  | 23.5 |  |
| Asset-backed securities | 66.0 |  |  | — |  |  | — |  |  | 66.0 |  |
| Corporate debt securities | 171.0 |  |  | 0.1 |  |  | (0.2 | ) |  | 170.9 |  |
| Municipal bonds | 5.1 |  |  | — |  |  | — |  |  | 5.1 |  |
| Mortgage-backed securities | 1.1 |  |  | — |  |  | — |  |  | 1.1 |  |
| U.S. Treasury | 1.9 |  |  | — |  |  | — |  |  | 1.9 |  |
| Total short-term investments | $ | 381.8 |  |  | $ | 0.1 |  |  | $ | (0.2 | ) |  | $ | 381.7 |  |

[0001633978-17-000119:notes:12]
The following table summarizes our short-term investments by category (in millions) as of July 1, 2017:

[0001633978-17-000119:notes:13]
|  | As of July 1, 2017 |
|  | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Certificates of deposit | $ | 202.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 202.1 |  |
| Asset-backed securities | 26.1 |  |  | — |  |  | — |  |  | 26.1 |  |
| Corporate debt securities | 46.4 |  |  | — |  |  | — |  |  | 46.4 |  |
| Municipal bonds | 4.9 |  |  | — |  |  | — |  |  | 4.9 |  |
| Foreign government bonds | 1.0 |  |  | — |  |  | — |  |  | 1.0 |  |
| U.S. Treasury | 1.9 |  |  | — |  |  | — |  |  | 1.9 |  |
| Total short-term investments | $ | 282.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 282.4 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001633978-17-000119:notes:14]
[same as prior period, unchanged from 0001633978-17-000037:notes:19]

[0001633978-17-000119:notes:15]
The preparation of the condensed consolidated financial statements in accordance with GAAP in the United States requires management to make estimates and assumptions that affect the amounts reported in our condensed consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates. Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are revenue recognition, inventory valuation, valuation of derivative liability, long-lived asset valuation, warranty and accounting for income taxes.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001633978-17-000119:notes:16]
Note 5. Mergers and Acquisitions

[0001633978-17-000119:notes:17]
In February 2017, we completed the acquisition of a privately held company to enhance our manufacturing and vertical integration capabilities. We acquired all of the outstanding shares of the company. In connection with the acquisition, we paid upfront cash consideration of $5.1 million, incurred liabilities of $2.7 million contingent upon the achievement of certain production targets being achieved within 36 months following the acquisition date, and retained $0.9 million of the purchase price as security for the seller’s indemnification obligations under the purchase agreement. This resulted in total purchase consideration of $8.7 million.

[0001633978-17-000119:notes:18]
The Company estimated the acquisition date fair value of the contingent consideration as the present value of the expected contingent payments, determined using a probabilistic approach and recorded the fair value of such contingent consideration in accrued liabilities on the condensed consolidated balance sheet at the date of acquisition. The Company is required to reassess the fair value of contingent payments on a periodic basis. As of September 30, 2017, the Company estimated the likelihood of meeting the production targets at 90%. There was no change in the fair value of our contingent consideration during the three months ended September 30, 2017. This contingent consideration will result in a cash payment of $3.0 million, if and when the production targets are achieved.

[0001633978-17-000119:notes:19]
[same as prior period, unchanged from 0001633978-17-000037:notes:27]

[0001633978-17-000119:notes:20]
[same as prior period, unchanged from 0001633978-17-000037:notes:28]

[0001633978-17-000119:notes:21]
As of the acquisition date, developed technology of the acquired business had an estimated useful life of six years. The goodwill is primarily attributed to the synergies expected to be realized following the acquisition and the assembled workforce. Goodwill has been assigned to the Optical Communications segment and is not deductible for tax purposes.

[0001633978-17-000119:notes:22]
Results of operations of the business acquired have been included in our condensed consolidated financial statements subsequent to the date of acquisition. Pro forma statements have not been presented because they are not material to our consolidated results of operations. The revenue and net income earned by the business acquired following the acquisition are not material to our consolidated results of operations.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001633978-17-000119:notes:23]
[same as prior period, unchanged from 0001633978-17-000037:notes:31]

[0001633978-17-000119:notes:24]
[same as prior period, unchanged from 0001633978-17-000037:notes:32]

[0001633978-17-000119:notes:25]
Lumentum (we, us, our or the Company) is an industry-leading provider of optical and photonic products defined by revenue and market share addressing a range of end market applications including data communications (“Datacom”) and telecommunications (“Telecom”) networking and commercial lasers (“Commercial Lasers”) for manufacturing, inspection and life-science applications. We are using our core optical and photonic technology and our volume manufacturing capability to expand into attractive emerging markets that benefit from advantages that optical or photonics-based solutions provide, including 3D sensing for consumer electronics and diode light sources for a variety of consumer and industrial applications. The majority of our customers tend to be original equipment manufacturers (“OEMs”) that incorporate our products into their products which then address end-market applications. For example, we sell fiber optic components that our network equipment manufacturer (“NEM”) customers assemble into communications networking systems, which they sell to network service providers or enterprises with their own networks. Similarly, many of our customers for our Lasers products incorporate our products into tools they produce, which are used for manufacturing processes by their customers. For 3D sensing, we sell diode lasers to manufacturers of consumer electronics products for mobile, personal computing, gaming, and other applications, who then integrate our devices within their products, for eventual resale to consumers.

[0001633978-17-000119:notes:26]
[same as prior period, unchanged from 0001633978-17-000037:notes:36]

[0001633978-17-000119:notes:27]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Our fiscal 2018 is a 52-week year ending on June 30, 2018. Our fiscal 2017 was a 52-week year and ended on July 1, 2017.

[0001633978-17-000119:notes:28]
[same as prior period, unchanged from 0001633978-17-000037:notes:38]

[0001633978-17-000119:notes:29]
These interim unaudited condensed consolidated financial statements include the accounts of the Company and its wholly-owned subsidiaries. All intra-company transactions within our business were eliminated.

[0001633978-17-000119:notes:30]
[same as prior period, unchanged from 0001633978-17-000037:notes:42]

[0001633978-17-000119:notes:31]
The accompanying interim unaudited condensed consolidated financial statements and accompanying related notes should be read in conjunction with the condensed consolidated financial statements and related notes included in our Annual Report on Form 10-K for the fiscal year ended July 1, 2017.

[0001633978-17-000119:notes:32]
The Company adopted ASU 2016-09, Stock Compensation ASU 718 - Improvements to Employee Share-Based Payment Accounting at the beginning of the first quarter of fiscal year 2018. As a result of the adoption, in the first quarter of fiscal year 2018, the Company recorded on a modified retrospective basis a $2.6 million cumulative-effect adjustment to retained earnings for the recognition of excess tax benefits generated by the settlement of share-based awards in prior periods. The Company elected to account for forfeitures of equity awards when they occur. The change was applied on a modified retrospective basis with a cumulative-effect adjustment of approximately $0.2 million to retained earnings in the first quarter of fiscal year 2018.

[0001633978-17-000119:notes:33]
All excess tax benefits and deficiencies are recognized in the income tax provision in the Condensed Consolidated Statements of Operations prospectively, rather than in additional paid-in-capital in the condensed consolidated balance sheets. In addition, the standard eliminates the requirement to defer recognition of excess tax benefits until they are realized through a reduction to income taxes payable. The Company presents excess tax benefits as an operating activity in the Condensed Consolidated Statements of Cash Flows on a prospective basis.


## us-gaap:CashCashEquivalentsAndShortTermInvestmentsTextBlock

[0001633978-17-000119:notes:34]
Note 7. Cash, Cash Equivalents, and Short-term Investments

[0001633978-17-000119:notes:35]
Cash, cash equivalents and short-term investments

[0001633978-17-000119:notes:36]
The following table summarizes our cash and cash equivalents by category (in millions):

[0001633978-17-000119:notes:37]
|  | September 30, 2017 |  | July 1, 2017 |
| Cash and cash equivalents: |  |  |  |
| Cash | $ | 81.5 |  |  | $ | 201.3 |  |
| Certificates of deposit | 11.0 |  |  | 52.1 |  |
| Commercial paper | 33.9 |  |  | 14.7 |  |
| Corporate debt securities | 3.2 |  |  | — |  |
| Money market funds | 1.3 |  |  | 4.8 |  |
| Municipal bonds | 1.0 |  |  | — |  |
| U.S. Treasury | 18.9 |  |  | — |  |
| Total cash and cash equivalents | $ | 150.8 |  |  | $ | 272.9 |  |

[0001633978-17-000119:notes:38]
We use the specific-identification method to determine any realized gains or losses from the sale of our short-term investments classified as available-for-sale. As of September 30, 2017, we did not realize significant gross gains or losses from the sale of our short-term investments classified as available-for-sale.

[0001633978-17-000119:notes:39]
The fair value of our short-term investments that have been in unrealized loss position less than 12 months was $193.8 million as of September 30, 2017. There were no investments in unrealized loss position greater than 12 months as of September 30, 2017.

[0001633978-17-000119:notes:40]
The following table classifies our investments in debt securities by contractual maturities (in millions):

[0001633978-17-000119:notes:41]
|  | As of September 30, 2017 |
|  | Amortized Cost |  | Fair Value |
| Due in 1 year | $ | 214.9 |  |  | $ | 214.8 |  |
| Due in 1 year through 5 years | 156.8 |  |  | 156.7 |  |
| Due in 5 years through 10 years | 4.8 |  |  | 4.8 |  |
| Due after 10 years | 5.3 |  |  | 5.4 |  |
|  | $ | 381.8 |  |  | $ | 381.7 |  |

[0001633978-17-000119:notes:42]
All available-for-sale securities have been classified as current, based on management’s intent and ability to use the funds in current operations.


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0001633978-17-000119:notes:43]
Note 16. Commitments and Contingencies

[0001633978-17-000119:notes:44]
Operating Leases

[0001633978-17-000119:notes:45]
We lease certain real and personal property from unrelated third parties under non-cancellable operating leases that expire at various dates through fiscal 2026. Certain leases require us to pay property taxes, insurance and routine maintenance, and include escalation clauses. As of September 30, 2017 the future minimum annual lease payments under non-cancellable operating leases were as follows (in millions):

[0001633978-17-000119:notes:46]
| Remainder of 2018 | $ | 8.6 |  |
| 2019 | 11.4 |  |
| 2020 | 8.5 |  |
| 2021 | 4.7 |  |
| 2022 | 3.1 |  |
| Thereafter | 4.0 |  |
| Total minimum operating lease payments | $ | 40.3 |  |

[0001633978-17-000119:notes:47]
Included in the future minimum lease payments table above is $0.2 million related to lease commitments in connection with our restructuring and related activities. Refer to “Note 13. Restructuring and Related Charges” in the Notes to Unaudited Condensed Consolidated Financial Statements.

[0001633978-17-000119:notes:48]
Rental expense relating to building and equipment was $3.4 million, and $2.2 million for the three months ended September 30, 2017 and October 1, 2016, respectively.

[0001633978-17-000119:notes:49]
Capital Lease

[0001633978-17-000119:notes:50]
In the first quarter of fiscal 2018, we started leasing equipment under a capital lease. Our capital lease asset is included in property, plant and equipment, net in our condensed consolidated balance sheets as of September 30, 2017. Amortization expense on this capital lease asset is recorded as depreciation expense and is included in cost of sales in our condensed consolidated statements of operations for the three months ended September 30, 2017. Our capital lease obligation is recorded at the lesser of the estimated fair market value of the leased property or the net present value of the aggregate future minimum lease payments and is included in other current liabilities and other non-current liabilities in our condensed consolidated balance sheets as of September 30, 2017. Refer to “Note 6. Balance Sheet Details” for further details. Interest on these obligations is included in interest expense in our condensed consolidated statements of operations.

[0001633978-17-000119:notes:51]
As of September 30, 2017 the future minimum annual lease payments under our capital lease were as follows (in millions):

[0001633978-17-000119:notes:52]
| Remainder of 2018 | $ | 3.7 |  |
| 2019 | 3.8 |  |
| Total minimum capital lease payments | $ | 7.5 |  |

[0001633978-17-000119:notes:53]
Acquisition Contingencies

[0001633978-17-000119:notes:54]
The Company incurred liabilities in the amount of $3.6 million in connection with the fiscal 2017 acquisition. The amount of $2.7 million is payable in 36 months following the acquisition date contingent upon meeting certain production targets. The Company retained $0.9 million of the purchase price to cover any potential liabilities under the representations, warranties and indemnifications included in the purchase agreement, the amount is payable at the 15 month anniversary of the close date. Refer to “Note 5. Mergers and Acquisitions”.

[0001633978-17-000119:notes:55]
0.25% Convertible Senior Notes due 2024

[0001633978-17-000119:notes:56]
The future interest and principal payments related to the 2024 Notes are as follows as of September 30, 2017:

[0001633978-17-000119:notes:57]
| Remainder of 2018 | $ | 0.6 |  |
| 2019 | 1.1 |  |
| 2020 | 1.1 |  |
| 2021 | 1.1 |  |
| 2022 | 1.1 |  |
| Thereafter | 451.7 |  |
| Total 2024 Notes payments | $ | 456.7 |  |

[0001633978-17-000119:notes:58]
Purchase Obligations

[0001633978-17-000119:notes:59]
Purchase obligations of $184.6 million as of September 30, 2017, represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule and adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

[0001633978-17-000119:notes:60]
We depend on a limited number of contract manufacturers, subcontractors and suppliers for raw materials, packages and standard components. We generally purchase these single or limited source products through standard purchase orders or one-year supply agreements and have no significant long-term guaranteed supply agreements with such vendors. While we seek to maintain a sufficient safety stock of such products and maintain on-going communications with our suppliers to guard against interruptions or cessation of supply, our business and results of operations could be adversely affected by a stoppage or delay of supply, substitution of more expensive or less reliable products, receipt of defective parts or contaminated materials, increases in the price of such supplies, or our inability to obtain reduced pricing from our suppliers in response to competitive pressures.

[0001633978-17-000119:notes:61]
Product Warranties

[0001633978-17-000119:notes:62]
We provide reserves for the estimated costs of product warranties at the time revenue is recognized. We typically offer a twelve month warranty for most of our products. However, in some instances depending upon the product, product component or application of our products by the end customer, our warranties can vary and generally range from six months to five years. We estimate the costs of our warranty obligations on an annualized basis based on our historical experience of known product failure rates, use of materials to repair or replace defective products and service delivery costs incurred in correcting product failures. In addition, from time to time, specific warranty accruals may be made if unforeseen technical problems arise with specific products. We assess the adequacy of our recorded warranty liabilities and adjust the amounts as necessary.

[0001633978-17-000119:notes:63]
The following table presents the changes in our warranty reserve during the three months ended September 30, 2017 and October 1, 2016 (in millions):

[0001633978-17-000119:notes:64]
|  | Three Months Ended |
|  | September 30, 2017 |  | October 1, 2016 |
| Balance as of July 1, 2017 | $ | 9.7 |  |  | $ | 2.8 |  |
| Provision for warranty | 1.0 |  |  | 3.8 |  |
| Utilization of reserve | (1.3 | ) |  | (1.2 | ) |
| Balance as of September 30, 2017 | $ | 9.4 |  |  | $ | 5.4 |  |

[0001633978-17-000119:notes:65]
Environmental Liabilities

[0001633978-17-000119:notes:66]
Our research and development (“R&D”), manufacturing and distribution operations involve the use of hazardous substances and are regulated under international, federal, state and local laws governing health and safety and the environment. We apply strict standards for protection of the environment and occupational health and safety to sites inside and outside the United States, even if not subject to regulations imposed by foreign governments. We believe that our properties and operations at our facilities comply in all material respects with applicable environmental laws and occupational health and safety laws. However, the risk of environmental liabilities cannot be completely eliminated and there can be no assurance that the application of environmental and health and safety laws will not require us to incur significant expenditures. We are also regulated under a number of international, federal, state and local laws regarding recycling, product packaging and product content requirements. The environmental, product content/disposal and recycling laws are gradually becoming more stringent and may cause us to incur significant expenditures in the future.

[0001633978-17-000119:notes:67]
In connection with the Separation, we agreed to indemnify Viavi for any liability associated with contamination from past operations at all properties transferred to us from Viavi, to the extent the resulting issues primarily related to our business.

[0001633978-17-000119:notes:68]
Legal Proceedings

[0001633978-17-000119:notes:69]
We are subject to a variety of claims and suits that arise from time to time in the ordinary course of our business. While management currently believes that resolving claims against us, individually or in the aggregate, will not have a material adverse impact on our financial position, results of operations or statements of cash flows, these matters are subject to inherent uncertainties and management’s view of these matters may change in the future. Were an unfavorable final outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the effect becomes reasonably estimable.

[0001633978-17-000119:notes:70]
Indemnifications

[0001633978-17-000119:notes:71]
In the normal course of business, the Company enters into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown because claims may be made against the Company in the future and the Company may record charges in the future as a result of these indemnification obligations. As of September 30, 2017, the Company did not have any material indemnification claims that were probable or reasonably possible.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001633978-17-000119:notes:72]
Note 4. Accumulated Other Comprehensive Income (Loss)

[0001633978-17-000119:notes:73]
Our accumulated other comprehensive income (loss) consists of the accumulated net unrealized gains or losses on foreign currency translation adjustments, the defined benefit obligation, and available-for-sale securities.

[0001633978-17-000119:notes:74]
As of September 30, 2017 and July 1, 2017, balances for the components of accumulated other comprehensive income (loss) were as follows (in millions):

[0001633978-17-000119:notes:75]
|  | Foreign currency translation adjustments, net of tax |  | Defined benefit obligation, net of tax |  | Unrealized gain (loss) on available-for-sale securities, net of tax |  | Total |
| Beginning balance as of July 1, 2017 | $ | 10.5 |  |  | $ | (3.1 | ) |  | $ | — |  |  | $ | 7.4 |  |
| Other comprehensive income (loss) | 1.9 |  |  | — |  |  | (0.1 | ) |  | 1.8 |  |
| Ending balance as of September 30, 2017 | $ | 12.4 |  |  | $ | (3.1 | ) |  | $ | (0.1 | ) |  | $ | 9.2 |  |

[0001633978-17-000119:notes:76]
[same as prior period, unchanged from 0001633978-17-000037:notes:70]


## us-gaap:ConvertibleDebtTableTextBlock

[0001633978-17-000119:notes:77]
As of September 30, 2017, the 2024 Notes consisted of the following (in millions):

[0001633978-17-000119:notes:78]
| Liability component: | September 30, 2017 |  | July 1, 2017 |
| Principal | $ | 450.0 |  |  | $ | 450.0 |  |
| Unamortized debt discount | (128.4 | ) |  | (132.5 | ) |
| Net carrying amount of the liability component | $ | 321.6 |  |  | $ | 317.5 |  |


## us-gaap:DebtDisclosureTextBlock

[0001633978-17-000119:notes:79]
Note 10. Convertible Senior Notes

[0001633978-17-000119:notes:80]
In March 2017, the Company issued the 2024 Notes in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act of 1933, as amended (the “Securities Act”). The 2024 Notes are governed by an indenture between the Company, as the issuer, and U.S. Bank National Association, as trustee (the “Indenture”). The 2024 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by the Company.

[0001633978-17-000119:notes:81]
The 2024 Notes bear interest at a rate of 0.25% per year. Interest on the 2024 Notes is payable semi-annually in arrears on March 15 and September 15 of each year, beginning on September 15, 2017. The 2024 Notes will mature on March 15, 2024, unless earlier repurchased by the Company or converted pursuant to their terms.

[0001633978-17-000119:notes:82]
The initial conversion rate of the 2024 Notes is 16.4965 shares of common stock per $1,000 principal amount of 2024 Notes, which is equivalent to an initial conversion price of approximately $60.62 per share, a 132.5% premium to the fair market value at the date of issuance. Prior to the close of business on the business day immediately preceding December 15, 2023, the 2024 Notes will be convertible only under the following circumstances: (1) during any fiscal quarter (and only during such fiscal quarter), if the last reported sale price of the Company’s common stock for at least 20 trading days (whether or not consecutive) during the period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price on each applicable trading day; (2) during the five consecutive business day period after any five consecutive trading day period (the “measurement period”) in which the trading price per $1,000 principal amount of notes for each trading day of such measurement period was less than 98% of the product of the last reported sale price of the Company’s common stock and the applicable conversion rate on each such trading day; or (3) upon the occurrence of specified corporate events. On or after December 15, 2023 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their notes at any time. In addition, upon the occurrence of a make-whole fundamental change, the Company will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert its 2024 Notes in connection with such make-whole fundamental change.

[0001633978-17-000119:notes:83]
The Company may not redeem the 2024 Notes prior to their maturity date and no sinking fund is provided for the 2024 Notes. Upon the occurrence of a fundamental change, holders may require the Company to repurchase all or a portion of their 2024 Notes for cash at a price equal to 100% of the principal amount of the 2024 Notes to be repurchased, plus any accrued and unpaid interest.

[0001633978-17-000119:notes:84]
The Company considered the features embedded in the 2024 Notes other than the conversion feature, including the holders’ put feature, the Company’s call feature, and the make-whole feature, and concluded that they are not required to be bifurcated and accounted for separately from the host debt instrument.

[0001633978-17-000119:notes:85]
Prior to the Tax Matters Agreement settlement condition (“TMA settlement condition”), because the Company could only settle the 2024 Notes in cash, the Company determined that the conversion feature met the definition of a derivative liability. The Company separated the derivative liability from the host debt instrument based on the fair value of the derivative liability. As of the issuance date, March 8, 2017, the derivative liability fair value of $129.9 million was calculated using the binomial valuation approach. The residual principal amount of the 2024 Notes of $320.1 million before issuance costs was allocated to the debt component. The Company incurred approximately $7.7 million in transaction costs in connection with the issuance of the 2024 Notes. These costs were allocated to the debt component and recognized as a debt discount. The Company amortizes the debt discount, including both the initial value of the derivative liability and the transaction costs, over the term of the 2024 Notes using the effective interest method. The effective interest rate of the 2024 Notes is 5.4% per year. As of September 30, 2017, the remaining debt discount amortization period was 77 months.

[0001633978-17-000119:notes:86]
During year ended July 1, 2017, the Company satisfied the TMA settlement conditions. As such, the value of the conversion option is no longer be marked to market and was reclassified to additional paid-in capital within stockholders’ equity on our condensed consolidated balance sheet. The value of the conversion option at the time of issuance will be treated as an original issue discount for purposes of accounting for the debt component of the notes. The debt component will accrete up to the principal amount over the expected term of the debt. These accounting standards do not affect the actual amount we are required to repay, and the amount shown in the table below for the notes is the aggregate principal amount of the notes and does not reflect the debt discount we will be required to recognize.

[0001633978-17-000119:notes:87]
The following table sets forth interest expense information related to the 2024 Notes:

[0001633978-17-000119:notes:88]
| (in millions, except percentages) | September 30, 2017 |
| Contractual interest expense | $ | 0.3 |  |
| Amortization of the debt discount | 4.1 |  |
| Total interest cost | $ | 4.4 |  |
| Effective interest rate on the liability component | 5.4 | % |

[0001633978-17-000119:notes:89]
The Company has the ability and intent to settle the $450 million face value of the debt in cash. Therefore, the Company will use the treasury stock method for calculating the dilutive impact of the debt. The 2024 Notes will have no impact to diluted earnings per share until the average price of our common stock exceeds the conversion price. The Notes are required to be excluded from the calculation of diluted earnings per share, as they would be anti-dilutive.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001633978-17-000119:notes:90]
Note 11. Derivative Liability

[0001633978-17-000119:notes:91]
We estimate the fair value of the embedded derivative for the Series A Preferred Stock using the binomial lattice model. We applied the lattice model to value the embedded derivative using a "with-and-without method," where the value of the Series A Preferred Stock, including the embedded derivative, is defined as the "with", and the value of the Series A Preferred Stock, excluding the embedded derivative, is defined as the "without". The lattice model requires the following inputs: (i) the Company's common stock price; (ii) conversion price; (iii) term; (iv) yield; (v) recovery rate for the Series A Preferred Stock; (vi) estimated stock volatility; and (vii) risk-free rate. The fair value of the embedded derivative was determined using level 3 inputs under the fair value hierarchy (unobservable inputs). Changes in the inputs into this valuation model have a material impact in the estimated fair value of the embedded derivative. For example, a decrease (increase) in the stock price and the volatility results in a decrease (increase) in the estimated fair value of the embedded derivative. The changes in the fair value of the bifurcated embedded derivative for the Series A Preferred Stock are primarily related to the change in the price of the Company's underlying common stock and are reflected in the condensed consolidated statements of operations as "Unrealized gain (loss) on derivative liability". Unrealized gain (loss) on derivative liability amounted to $4.2 million and $(22.7) million for the three months ended September 30, 2017 and October 1, 2016, respectively.

[0001633978-17-000119:notes:92]
The following table provides a reconciliation of the fair value of the embedded derivative for the Series A Preferred Stock measured by significant unobservable inputs (Level 3) for the three months ended September 30, 2017 and October 1, 2016:

[0001633978-17-000119:notes:93]
|  | Three months ended |
| (in millions) | September 30, 2017 |  | October 1, 2016 |
| Balance as of beginning of period | $ | 51.6 |  |  | $ | 10.3 |  |
| Unrealized (gain) loss on the Series A Preferred Stock derivative liability | (4.2 | ) |  | 22.7 |  |
| Balance as of end of period | $ | 47.4 |  |  | $ | 33.0 |  |

[0001633978-17-000119:notes:94]
[same as prior period, unchanged from 0001633978-17-000037:notes:92]

[0001633978-17-000119:notes:95]
|  | September 30, 2017 |  | July 1, 2017 |
| Stock price | $ | 54.35 |  |  | $ | 57.05 |  |
| Conversion price | $ | 24.63 |  |  | $ | 24.63 |  |
| Expected term (years) | 2.86 |  |  | 3.11 |  |
| Expected annual volatility | 47.5 | % |  | 47.5 | % |
| Risk-free rate | 1.60 | % |  | 1.57 | % |
| Preferred yield | 7.41 | % |  | 7.56 | % |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001633978-17-000119:notes:96]
Note 15. Stock-Based Compensation and Stock Plans

[0001633978-17-000119:notes:97]
[same as prior period, unchanged from 0001633978-17-000037:notes:95]

[0001633978-17-000119:notes:98]
[same as prior period, unchanged from 0001633978-17-000037:notes:96]

[0001633978-17-000119:notes:99]
On June 23, 2015, we adopted, and the board of directors of JDS Uniphase Corporation (“JDSU” and, now, Viavi Solutions Inc.) approved, the 2015 Equity Incentive Plan (the “2015 Plan”) under which 8.5 million shares of our Common Stock were authorized for issuance, which was ratified by the Company’s board of directors in August 2015. In connection with our Separation from JDSU on July 31, 2015, outstanding JDSU equity-based awards held by service providers continuing in service after the Separation were converted into equity-based awards under the 2015 Plan reducing the number of shares remaining available for grant under the 2015 Plan. Immediately following our Separation from JDSU, 2.1 million shares of our Common Stock were reserved pursuant to outstanding equity-based awards under the 2015 Plan that were converted from JDSU equity-based awards.

[0001633978-17-000119:notes:100]
[same as prior period, unchanged from 0001633978-17-000037:notes:98]

[0001633978-17-000119:notes:101]
As of September 30, 2017, the Company had 2.2 million shares of stock options, restricted stock awards, and restricted stock units issued and outstanding to employees and directors under the 2015 Plan. Restricted stock awards and restricted stock units are performance-based, time-based or a combination of both and are expected to vest over one to four years. The fair value of the time-based restricted stock award or restricted stock unit is based on the closing market price of our common stock on the date of award.

[0001633978-17-000119:notes:102]
The exercise price for stock options is equal to the fair value of the underlying stock at the date of grant. The Company issues new shares of common stock upon exercise of stock options. Options generally become exercisable over a three-year or four-year period and, if not exercised, expire from five to ten years after the date of grant.

[0001633978-17-000119:notes:103]
As of September 30, 2017, 6.1 million shares of common stock under the 2015 Plan were available for grant.

[0001633978-17-000119:notes:104]
[same as prior period, unchanged from 0001633978-17-000037:notes:101]

[0001633978-17-000119:notes:105]
On June 23, 2015, we adopted, and the board of directors of JDSU approved, the 2015 Employee Stock Purchase Plan (the “2015 Purchase Plan”) under which 3.0 million shares of our Common Stock were authorized for issuance, which was ratified by our board of directors in August 2015. The 2015 Purchase Plan provides eligible employees with the opportunity to acquire an ownership interest in the Company through periodic payroll deductions and provides a 15% purchase price discount as well as a six-month look-back period. The 2015 Purchase Plan is structured as a qualified employee stock purchase plan under Section 423 of the Internal Revenue Code of 1986. However, the 2015 Purchase Plan is not intended to be a qualified pension, profit sharing or stock bonus plan under Section 401(a) of the Internal Revenue Code of 1986 and is not subject to the provisions of the Employee Retirement Income Security Act of 1974. The 2015 Purchase Plan will terminate upon the date on which all shares available for issuance have been sold. Of the 3.0 million shares authorized under the 2015 Purchase Plan, 2.5 million shares remained available for issuance as of September 30, 2017.

[0001633978-17-000119:notes:106]
[same as prior period, unchanged from 0001633978-17-000037:notes:103]

[0001633978-17-000119:notes:107]
Restricted stock units (“RSUs”) under the 2015 Plan are grants of shares of our common stock valued at fair value based on the closing price of our common stock on the date of grant. RSUs result in a payment to a holder if any performance goals or other vesting criteria are achieved or the awards otherwise vest. Generally, our RSUs have service conditions, performance conditions, or a combination of both and are expected to vest over one to four years. The fair value of the time-based RSUs is based on the closing market price of the common stock on the date of award.

[0001633978-17-000119:notes:108]
[same as prior period, unchanged from 0001633978-17-000037:notes:106]

[0001633978-17-000119:notes:109]
Restricted stock awards (“RSAs”) under the 2015 Plan are grants of shares of our common stock that are subject to various restrictions, including restrictions on transferability and forfeiture provisions. RSAs are expected to vest over one to four years, and the shares acquired may not be transferred by the holder until the vesting conditions (if any) are satisfied.

[0001633978-17-000119:notes:110]
[same as prior period, unchanged from 0001633978-17-000037:notes:108]

[0001633978-17-000119:notes:111]
The impact on our results of operations of recording stock-based compensation by function for the three months ended September 30, 2017 and October 1, 2016 was as follows (in millions):

[0001633978-17-000119:notes:112]
|  | Three Months Ended |  |
|  | September 30, 2017 |  | October 1, 2016 |  |
| Cost of sales | $ | 2.7 |  |  | $ | 1.9 |  |  |
| Research and development | 3.1 |  |  | 2.8 |  |  |
| Selling, general and administrative | 3.5 |  |  | 3.0 |  |  |
|  | $ | 9.3 |  |  | $ | 7.7 |  |  |

[0001633978-17-000119:notes:113]
Approximately $1.8 million and $1.8 million of stock-based compensation was capitalized to inventory as of September 30, 2017 and July 1, 2017.

[0001633978-17-000119:notes:114]
Stock Option and Restricted Stock Units Activity

[0001633978-17-000119:notes:115]
We did not grant any stock options during the three months ended September 30, 2017 and October 1, 2016. During the three months ended September 30, 2017, there were 40,270 options exercised. As of September 30, 2017, 4,514 options were outstanding under the 2015 Plan. During the three months ended September 30, 2017 and October 1, 2016, the total intrinsic value of options exercised by our employees was $0.7 million and $3.1 million, respectively.

[0001633978-17-000119:notes:116]
During the three months ended October 1, 2016, the tax benefit realized in connection with these exercises was immaterial due to the fact that Lumentum has no material tax benefit in foreign jurisdictions and a full valuation allowance on its domestic deferred tax assets. During the three months ended September 30, 2017, due to adoption of ASU 2016-09, all excess tax benefits and deficiencies will be recognized in the income tax provision in the Condensed Consolidated Statements of Operations prospectively, rather than in additional paid-in-capital in the condensed consolidated balance sheets. Refer to “Note 1. Description of Business and Summary of Significant Accounting Policies” in the Notes to Unaudited Condensed Consolidated Financial Statements for further discussion on the impact of ASU 2016-09 adoption.

[0001633978-17-000119:notes:117]
As of September 30, 2017, $66.7 million of stock-based compensation cost related to RSUs and RSAs granted to our employees remains to be amortized. That cost is expected to be recognized over an estimated amortization period of 2.0 years.

[0001633978-17-000119:notes:118]
The following table summarizes our stock option, RSA, and RSU activities in September 30, 2017 (amount in millions except per share amounts):

[0001633978-17-000119:notes:119]
|  |  |  | Restricted Stock Units/Awards Outstanding |
|  | Available for Grant |  | Number of Shares (PSU) |  | Number of Shares(RSU/RSA) |  | Weighted-Average Grant Date Fair Value |
| Outstanding as of July 1, 2017 | 6.6 |  |  | — |  |  | 2.2 |  |  | $ | 28.51 |  |
| Authorized | — |  |  |  |  |  |  |  |
| Granted | (0.6 | ) |  | — |  |  | 0.6 |  |  | 52.62 |  |
| Exercised / Vested | — |  |  | — |  |  | (0.5 | ) |  | 27.62 |  |
| Canceled | 0.1 |  |  | — |  |  | (0.1 | ) |  | 38.02 |  |
| Outstanding as of September 30, 2017 | 6.1 |  |  | — |  |  | 2.2 |  |  | $ | 34.86 |  |
| Vested and expected to vest |  |  | — |  |  | 2.2 |  |  | $ | 34.86 |  |

[0001633978-17-000119:notes:120]
[same as prior period, unchanged from 0001633978-17-000037:notes:118]

[0001633978-17-000119:notes:121]
The ESPP expense for the three months ended September 30, 2017 and October 1, 2016 was $0.8 million and $0.5 million, respectively. The expense related to the ESPP is recorded on a straight-line basis over the relevant subscription period. During the three months ended September 30, 2017 and October 1, 2016 , there were no shares issued to employees through the ESPP program.

[0001633978-17-000119:notes:122]
We estimate the fair value of ESPP shares on the date of grant using the Black-Scholes option-pricing model. The assumptions used to estimate the fair value of ESPP shares to be issued during the three months ended September 30, 2017 and October 1, 2016 were as follows:

[0001633978-17-000119:notes:123]
|  | Three months ended |
|  | September 30, 2017 |  | October 1, 2016 |
| Expected term (years) | 0.5 |  | 0.5 |
| Expected volatility | 53.0 | % |  | 36.6 | % |
| Risk-free interest rate | 1.02 | % |  | 0.35 | % |
| Dividend yield | — | % |  | — | % |


## us-gaap:EarningsPerShareTextBlock

[0001633978-17-000119:notes:124]
Note 3. Earnings Per Share

[0001633978-17-000119:notes:125]
[same as prior period, unchanged from 0001633978-17-000037:notes:122]

[0001633978-17-000119:notes:126]
|  | Three Months Ended |
|  | September 30, 2017 |  | October 1, 2016 |  |
| Numerator: |  |  |  |  |  |  |
| Net income (loss) | $ | 7.1 |  |  | $ | (3.4 | ) |  |
| Less: Cumulative dividends on Series A Preferred Stock | (0.2 | ) |  | (0.2 | ) |  |
| Net income (loss) attributable to common stockholders | $ | 6.9 |  |  | $ | (3.6 | ) |  |
| Denominator: |  |  |  |  |
| Weighted-average number of common shares outstanding |  |  |  |  |
| Basic | 61.7 |  |  | 59.9 |  |  |
| Effect of dilutive securities from stock-based benefit plans | 1.3 |  |  | — |  |  |
| Diluted shares available to common stockholders | 63.0 |  |  | 59.9 |  |  |
| Net income (loss) per share attributable to common stockholders: |  |  |  |  |
| Basic | $ | 0.11 |  |  | $ | (0.06 | ) |  |
| Diluted | $ | 0.11 |  |  | $ | (0.06 | ) |  |

[0001633978-17-000119:notes:127]
The dilutive effect of stock-based awards is reflected in diluted earnings per share by application of the treasury stock method, which includes consideration of unamortized share-based compensation expense and the dilutive effect of in-the-money options and non-vested restricted stock units. Under the treasury stock method, the amount the employee must pay for exercising stock options and unamortized share-based compensation expense collectively are assumed proceeds to be used to repurchase hypothetical shares. An increase in the fair value of the Company’s common stock can result in a greater dilutive effect from potentially dilutive awards.

[0001633978-17-000119:notes:128]
The dilutive effect of the redeemable convertible preferred stock is reflected in diluted earnings per share by the application of the if-converted method. The number of shares is increased for the assumed conversion of the instrument. For the three months ended September 30, 2017 and October 1, 2016, 1.5 million shares related to the potential conversion of the Series A Preferred Stock were excluded from the calculation of diluted shares available to the common stockholders because their inclusion would have been antidilutive.

[0001633978-17-000119:notes:129]
In March 2017, the Company issued $450 million in aggregate principal amount of 0.25% Convertible Senior Notes due in 2024 (the “2024 Notes”). The Company has the ability and intent to settle the $450 million face value of the 2024 Notes in cash. Therefore, the Company will use the treasury stock method for calculating the dilutive impact of the 2024 Notes. The 2024 Notes will have no impact to diluted earnings per share until the average price of our common stock exceeds the conversion price. Refer to “Note 10. Convertible Senior Notes” for further discussion.

[0001633978-17-000119:notes:130]
For the three months ended September 30, 2017, 7.4 million shares related to the potential conversion of the 2024 Notes were excluded from the calculation of diluted shares because their inclusion would have been antidilutive. There was no impact to diluted earnings per share for the three months ended October 1, 2016 as the 2024 Notes were issued in the third quarter of fiscal 2017.

[0001633978-17-000119:notes:131]
For the three months ended September 30, 2017, the number of shares related to our stock-based benefit plans that were excluded from the calculation of diluted shares was not material. For the three months ended October 1, 2016, 1.1 million shares related to our stock-based benefit plans were excluded from the calculation of diluted shares because their inclusion would have been antidilutive.


## us-gaap:FairValueDisclosuresTextBlock

[0001633978-17-000119:notes:132]
Note 8. Fair Value Measurements

[0001633978-17-000119:notes:133]
We determine fair value based on the fair value hierarchy, which requires an entity to maximize the use of observable inputs and minimize the use of unobservable inputs when measuring fair value. Fair value is defined as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. The fair value assumes that the transaction to sell the asset or transfer the liability occurs in the principal or most advantageous market for the asset or liability and establishes that the fair value of an asset or liability shall be determined based on the assumptions that market participants would use in pricing the asset or liability. The classification of a financial asset or liability within the hierarchy is based upon the lowest level input that is significant to the fair value measurement. The fair value hierarchy prioritizes the inputs into three levels that may be used to measure fair value:

[0001633978-17-000119:notes:134]
| Level 1: | Inputs are unadjusted quoted prices in active markets for identical assets or liabilities. |
| Level 2: | Inputs are quoted prices for similar assets and liabilities in active markets or inputs that are observable for the asset or liability, either directly or indirectly through market corroboration, for substantially the full term of the financial instrument. |
| Level 3: | Inputs are unobservable inputs based on our assumptions. |

[0001633978-17-000119:notes:135]
The fair value of the Company’s Level 1 financial instruments, such as money market funds, which are traded in active markets, is based on quoted market prices for identical instruments. The fair value of the Company’s Level 2 fixed income securities is obtained from an independent pricing service, which may use quoted market prices for identical or comparable instruments or model driven valuations using observable market data or inputs corroborated by observable market data. Our marketable securities are held by custodians who obtain investment prices from a third-party pricing provider that incorporates standard inputs in various asset price models. The Company’s procedures include controls to ensure that appropriate fair values are recorded, including comparing the fair values obtained from the Company’s pricing service against fair values obtained from another independent source.

[0001633978-17-000119:notes:136]
We estimate the fair value of the embedded derivative for the Series A Preferred Stock using the binomial lattice model. The lattice model requires the various assumptions to be made to determine the fair value of the embedded derivatives. These assumptions represent Level 3 inputs. Refer to “Note 11. Derivative Liability” in the Notes to Unaudited Condensed Consolidated Financial Statements.

[0001633978-17-000119:notes:137]
We estimated the acquisition date fair value of our Level 3 contingent consideration as the present value of the expected contingent payments, determined using a probabilistic approach. We are required to reassess the fair value of contingent payments on a periodic basis. In the fiscal first quarter of 2018, we estimated the likelihood of meeting the production targets at 90 percent. There was no change in the fair value of our contingent consideration during the three months ended September 30, 2017. The fair value of such contingent consideration is recorded in accrued liabilities on the condensed consolidated balance sheet as of September 30, 2017. This contingent consideration will result in a cash payment of $3.0 million, if and when the production targets are achieved. Refer to “Note 5. Mergers and Acquisitions” in the Notes to Unaudited Condensed Consolidated Financial Statements.

[0001633978-17-000119:notes:138]
Our pension assets consist of multiple institutional funds (“pension funds”) of which the fair values are based on the quoted prices of the underlying funds. Pension funds are classified as Level 2 assets since such funds are not directly traded in active markets.

[0001633978-17-000119:notes:139]
Financial assets and liabilities measured at fair value on a recurring basis are summarized below (in millions):

[0001633978-17-000119:notes:140]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificate of deposit | $ | — |  |  | $ | 11.0 |  |  | $ | — |  |  | $ | 11.0 |  |
| Commercial paper | — |  |  | 33.9 |  |  | — |  |  | 33.9 |  |
| Corporate debt securities | — |  |  | 3.2 |  |  | — |  |  | 3.2 |  |
| Money market funds | 1.3 |  |  | — |  |  | — |  |  | 1.3 |  |
| Municipal bonds | — |  |  | 1.0 |  |  | — |  |  | 1.0 |  |
| U.S. Treasury | 18.9 |  |  | — |  |  | — |  |  | 18.9 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificate of deposit | — |  |  | 113.2 |  |  | — |  |  | 113.2 |  |
| Commercial paper | — |  |  | 23.5 |  |  | — |  |  | 23.5 |  |
| Asset-backed securities | — |  |  | 66.0 |  |  | — |  |  | 66.0 |  |
| Corporate debt securities | — |  |  | 170.9 |  |  | — |  |  | 170.9 |  |
| Municipal bonds | — |  |  | 5.1 |  |  | — |  |  | 5.1 |  |
| Mortgage-backed securities | — |  |  | 1.1 |  |  | — |  |  | 1.1 |  |
| U.S. Treasury | 1.9 |  |  | — |  |  | — |  |  | 1.9 |  |
| Total Assets | $ | 22.1 |  |  | $ | 428.9 |  |  | $ | — |  |  | $ | 451.0 |  |
| Other accrued liabilities: |  |  |  |  |  |  |  |
| Derivative liability | $ | — |  |  | $ | — |  |  | $ | 47.4 |  |  | $ | 47.4 |  |
| Acquisition contingencies | — |  |  | — |  |  | 2.7 |  |  | 2.7 |  |
| Pension and post-retirement benefit accrual | — |  |  | 4.2 |  |  | — |  |  | 4.2 |  |
| Total other accrued liabilities | $ | — |  |  | $ | 4.2 |  |  | $ | 50.1 |  |  | $ | 54.3 |  |

[0001633978-17-000119:notes:141]
Assets Measured at Fair Value on a Non-Recurring Basis

[0001633978-17-000119:notes:142]
We periodically review our intangible and other long-lived assets for impairment whenever events or changes in circumstances indicate that the carrying amount of such assets may not be recoverable. Determination of recoverability is based on the lowest level of identifiable estimated undiscounted cash flows resulting from use of the asset and its eventual disposition. If not recoverable, an impairment loss would be calculated based on the excess of the carrying amount over the fair value.

[0001633978-17-000119:notes:143]
Management utilizes various valuation methods, including an income approach, a market approach and a cost approach, to estimate the fair value of intangible and other long-lived assets. During the annual impairment testing performed in fiscal 2017, all our intangible and other long-lived assets passed Step 1. No impairment charges were recorded in fiscal 2017 or 2016. Refer to “Note 12. Goodwill and Other Intangible Assets”.

[0001633978-17-000119:notes:144]
Additionally, we have a restructuring liability related to certain real estate facilities which was calculated based on the present value of future lease payments, less estimated sublease income, discounted at a rate commensurate with our current cost of financing. This non-recurring fair value measurement is considered to be a Level 3 measurement due to the use of significant unobservable inputs. To the extent that actual sublease income or the timing of subleasing these facilities is different than initial estimates, we will adjust the restructuring liability in the period during which such information becomes known. Refer to “Note 13. Restructuring and Related Charges”.


## us-gaap:FiniteLivedIntangibleAssetsAmortizationExpenseTableTextBlock

[0001633978-17-000119:notes:145]
[same as prior period, unchanged from 0001633978-17-000037:notes:128]

[0001633978-17-000119:notes:146]
|  | Three Months Ended |  |
|  | September 30, 2017 |  | October 1, 2016 |  |
| Cost of sales | $ | 0.8 |  |  | $ | 1.7 |  |  |
| Operating expense | — |  |  | 0.1 |  |  |
| Total | $ | 0.8 |  |  | $ | 1.8 |  |  |


## us-gaap:GoodwillDisclosureTextBlock

[0001633978-17-000119:notes:147]
Note 12. Goodwill and Other Intangible Assets

[0001633978-17-000119:notes:148]
[same as prior period, unchanged from 0001633978-17-000037:notes:131]

[0001633978-17-000119:notes:149]
The following table presents the changes in goodwill by operating segments during the three months ended September 30, 2017 (in millions):

[0001633978-17-000119:notes:150]
|  |  | Optical Communications |  | Commercial Lasers |  | Total |
| Balance as of July 1, 2017 | $ | 5.9 |  |  | $ | 5.5 |  |  | $ | 11.4 |  |
|  | Acquisition of a business | — |  |  | — |  |  | — |  |
|  | Currency translation | 0.2 |  |  | (0.1 | ) |  | 0.1 |  |
| Balance as of September 30, 2017 | $ | 6.1 |  |  | $ | 5.4 |  |  | $ | 11.5 |  |

[0001633978-17-000119:notes:151]
[same as prior period, unchanged from 0001633978-17-000037:notes:134]

[0001633978-17-000119:notes:152]
We review goodwill for impairment during the fourth quarter of each fiscal year or more frequently if events or circumstances indicate that an impairment loss may have occurred. In the fourth quarter of fiscal 2017, we completed the annual impairment test of goodwill, which indicated there was no goodwill impairment. During the three months ended September 30, 2017, there have been no events or circumstances that have required us to perform an interim assessment of goodwill for impairment.

[0001633978-17-000119:notes:153]
[same as prior period, unchanged from 0001633978-17-000037:notes:136]

[0001633978-17-000119:notes:154]
In fiscal 2017, we completed the acquisition of a privately held company to enhance our manufacturing processes with $2.4 million acquired developed technology which was allocated to Optical Communications operating segment. The following tables present details of our acquired developed technology and other intangibles (in millions):

[0001633978-17-000119:notes:155]
| As of September 30, 2017 | Gross Carrying Amount |  | Accumulated Amortization |  | Net |
| Acquired developed technology | $ | 105.7 |  |  | $ | (96.2 | ) |  | $ | 9.5 |  |
| Other | 9.4 |  |  | (9.4 | ) |  | — |  |
| Total Intangibles | $ | 115.1 |  |  | $ | (105.6 | ) |  | $ | 9.5 |  |

[0001633978-17-000119:notes:156]
| As of July 1, 2017 | Gross Carrying Amount |  | Accumulated Amortization |  | Net |
| Acquired developed technology | $ | 105.5 |  |  | $ | (95.4 | ) |  | $ | 10.1 |  |
| Other | 9.4 |  |  | (9.4 | ) |  | — |  |
| Total Intangibles | $ | 114.9 |  |  | $ | (104.8 | ) |  | $ | 10.1 |  |

[0001633978-17-000119:notes:157]
During the three months ended September 30, 2017 and October 1, 2016, we recorded $0.8 million and $1.8 million, respectively, of amortization related to acquired developed technology and other intangibles. The following table presents details of our amortization (in millions):

[0001633978-17-000119:notes:158]
Based on the carrying amount of acquired developed technology and other intangibles as of September 30, 2017, and assuming no future impairment of the underlying assets, the estimated future amortization is as follows (in millions):

[0001633978-17-000119:notes:159]
| Fiscal Years |  |
| Remainder of 2018 | $ | 2.4 |  |
| 2019 | 3.0 |  |
| 2020 | 2.9 |  |
| Thereafter | 1.2 |  |
| Total amortization | $ | 9.5 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001633978-17-000119:notes:160]
Note 14. Income Taxes

[0001633978-17-000119:notes:161]
Our tax provision for interim periods is determined using an estimate of our annual effective tax rate, adjusted for discrete items, if any, that arise during the period. Each quarter, we update our estimate of the annual effective tax rate, and if the estimated annual effective tax rate changes, we make a cumulative adjustment in such period.

[0001633978-17-000119:notes:162]
Our quarterly tax provision, and estimate of our annual effective tax rate, is subject to variation due to several factors, including variability in pre-tax income (or loss), the mix of jurisdictions to which such income relates, changes in how we do business, and tax law developments. Our estimated effective tax rate for the year differs from the U.S. statutory rate of 35% primarily due to the benefit of earnings of our subsidiaries being taxed at rates lower than the U.S. statutory rate, non-deductible stock-based compensation, and unrecognized tax benefits.

[0001633978-17-000119:notes:163]
We recorded a tax benefit of $(3.6) million and $(2.3) million for the three months ended September 30, 2017 and October 1, 2016, respectively. Our tax benefit for the three months ended September 30, 2017, was primarily due to the tax benefit from excess stock-based compensation deductions, as well as the non-taxable unrealized gain from the embedded derivatives for the Series A Preferred Stock. The benefit for income tax for the three months ended October 1, 2016 was primarily due to an increase of profit in jurisdictions with lower tax rates, utilization of U.S. tax attributes that were subject to a full valuation allowance, certain Canadian tax incentives, and a net benefit of $0.5 million of true-up adjustments in our foreign jurisdictions.

[0001633978-17-000119:notes:164]
We assess our ability to realize our U.S. net deferred tax assets on a quarterly basis and establish a valuation allowance if it is more-likely-than-not that some portion of the deferred tax assets will not be realized. We weigh all available positive and negative evidence, including our earnings history and results of recent operations, scheduled reversals of deferred tax liabilities, projected future taxable income, and tax planning strategies. Due to the weight of objectively verifiable negative evidence, including our history of losses in certain jurisdictions, we believe that it is more likely than not that our U.S. federal, state, and Canadian deferred tax assets will not be realized as of September 30, 2017. Accordingly, we have maintained a valuation allowance on such deferred tax assets.

[0001633978-17-000119:notes:165]
The amount of the deferred tax asset considered realizable, however, could be adjusted if estimates of future taxable income during the carryforward period are reduced or increased or if objective negative evidence in the form of cumulative losses is no longer present and additional weight may be given to subjective evidence such as our projections for growth. In the event we determine that we will be able to realize all or part of its net deferred tax assets in the future, the valuation allowance against deferred tax assets will be reversed in the period in which we make such determination. The release of a valuation allowance against deferred tax assets may cause greater volatility in the effective tax rate in the periods in which the valuation allowance is released. It is reasonably possible that significant positive evidence may become available to reach a conclusion that a significant portion of the valuation allowance will no longer be needed, and as such, we may release a significant portion of our valuation allowance in the next 12 months.

[0001633978-17-000119:notes:166]
As of September 30, 2017, we had $7.9 million in our liability for unrecognized tax benefits, which, if recognized, would affect the effective tax rate. We are subject to the continuous examination of income tax returns by various foreign tax authorities. The timing of resolutions and closures of tax audits is highly unpredictable. Given the uncertainty, it is reasonably possible that certain tax audits may be concluded within the next 12 months that could materially impact the balance of our gross unrecognized tax benefits. An estimate of the range of increase or decrease that could occur in the next twelve months cannot be made. However, the estimated impact to tax expense and net income from the resolution and closure of tax exams is not expected to be significant within the next 12 months.


## us-gaap:MinorityInterestDisclosureTextBlock

[0001633978-17-000119:notes:167]
Note 9. Non-Controlling Interest Redeemable Convertible Preferred Stock

[0001633978-17-000119:notes:168]
[same as prior period, unchanged from 0001633978-17-000037:notes:154]

[0001633978-17-000119:notes:169]
The Series A Preferred Stock is redeemable at the option of Amada after five years and classified as non-controlling interest redeemable convertible preferred stock in our condensed consolidated balance sheet. The Series A Preferred Stock is measured at its redemption value. The Series A Preferred Stock value of $35.8 million as of September 30, 2017 has not changed from prior year.

[0001633978-17-000119:notes:170]
The Series A Preferred Stock conversion feature is bifurcated from the Series A Preferred Stock and accounted for separately as a derivative liability. The derivative liability is measured at fair value each reporting period with the change in fair value recorded in the condensed consolidated statements of operations. Refer to “Note 11. Derivative Liability”.

[0001633978-17-000119:notes:171]
[same as prior period, unchanged from 0001633978-17-000037:notes:156]

[0001633978-17-000119:notes:172]
[same as prior period, unchanged from 0001633978-17-000037:notes:157]

[0001633978-17-000119:notes:173]
The Series A Preferred Stock is convertible, at the option of the holder, into shares of our common stock commencing on the second anniversary of the closing of the securities purchase (absent a change of control of us or similar event) using a conversion price of $24.63, which is equal to 125% of the volume weighted average price per share of our common stock in the five “regular-way” trading days following our separation from JDS Uniphase Corporation in August 2015 (the “Separation”).

[0001633978-17-000119:notes:174]
[same as prior period, unchanged from 0001633978-17-000037:notes:159]

[0001633978-17-000119:notes:175]
[same as prior period, unchanged from 0001633978-17-000037:notes:160]

[0001633978-17-000119:notes:176]
[same as prior period, unchanged from 0001633978-17-000037:notes:161]

[0001633978-17-000119:notes:177]
[same as prior period, unchanged from 0001633978-17-000037:notes:162]

[0001633978-17-000119:notes:178]
The Series A Preferred Stock have no voting rights except as follows:

[0001633978-17-000119:notes:179]
[same as prior period, unchanged from 0001633978-17-000037:notes:164]

[0001633978-17-000119:notes:180]
[same as prior period, unchanged from 0001633978-17-000037:notes:165]

[0001633978-17-000119:notes:181]
[same as prior period, unchanged from 0001633978-17-000037:notes:166]

[0001633978-17-000119:notes:182]
[same as prior period, unchanged from 0001633978-17-000037:notes:167]

[0001633978-17-000119:notes:183]
[same as prior period, unchanged from 0001633978-17-000037:notes:168]

[0001633978-17-000119:notes:184]
The accrued dividend as of September 30, 2017 and October 1, 2016 is $0.2 million and $0.2 million, respectively.

[0001633978-17-000119:notes:185]
[same as prior period, unchanged from 0001633978-17-000037:notes:170]

[0001633978-17-000119:notes:186]
[same as prior period, unchanged from 0001633978-17-000037:notes:171]

[0001633978-17-000119:notes:187]
[same as prior period, unchanged from 0001633978-17-000037:notes:172]

[0001633978-17-000119:notes:188]
[same as prior period, unchanged from 0001633978-17-000037:notes:173]

[0001633978-17-000119:notes:189]
[same as prior period, unchanged from 0001633978-17-000037:notes:174]


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001633978-17-000119:notes:190]
In October 2016, the Financial Accounting Standards Board (“FASB”) issued ASU 2016-16, Accounting for Income Taxes: Intra-Entity Asset Transfers of Assets other than Inventory. The new guidance removes the prohibition in ASC 740 against the immediate recognition of the current and deferred income tax effects of intra-entity transfers of assets other than inventory. The new guidance will be effective for us in our first quarter of fiscal 2019. We do not believe that the adoption of this standard will have a material impact to our condensed financial statements.

[0001633978-17-000119:notes:191]
In August 2016, FASB issued ASU 2016-15, Statement of Cash Flows (Topic 230): Classification of Certain Cash Receipts and Cash Payments, which clarifies how companies present and classify certain cash receipts and cash payments in the statement of cash flows. ASU 2016-15 is effective for us in our first quarter of fiscal 2019 and earlier adoption is permitted. We are currently evaluating the impact of our pending adoption of ASU 2016-15 on our condensed consolidated financial statements.

[0001633978-17-000119:notes:192]
In February 2016, FASB issued ASU 2016-02, Leases. The new guidance generally requires an entity to recognize on its balance sheet operating and financing lease liabilities and corresponding right-of-use assets. The standard is effective for us in our first quarter of fiscal 2020 and early adoption is permitted. The Company is currently evaluating the impact of the adoption of ASU 2016-02 on its condensed consolidated financial statements.

[0001633978-17-000119:notes:193]
In May 2014, FASB issued ASU 2014-09, Revenue from Contracts with Customers, which amended the existing accounting standards for revenue recognition. ASU 2014-09 establishes principles for recognizing revenue upon the transfer of promised goods or services to customers, in an amount that reflects the consideration expected to be received in exchange for those goods or services. The new standard requires that reporting companies disclose the nature, amount, timing and uncertainty of revenue and cash flows arising from contracts with customers. On July 9, 2015, FASB agreed to delay the effective date by one year and, accordingly, the new standard is effective for the Company beginning in the first quarter of fiscal 2019. Early adoption is permitted, but not before the original effective date of the standard.

[0001633978-17-000119:notes:194]
The guidance permits two methods of adoption: retrospectively to each prior reporting period presented (full retrospective method), or retrospectively with the cumulative effect of initially applying the guidance recognized at the date of initial application (modified retrospective method). The Company anticipates adopting the standard using the modified retrospective method. The Company is currently evaluating the impact of the adoption of ASU 2014-09 on its condensed consolidated financial statements.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001633978-17-000119:notes:195]
Note 13. Restructuring and Related Charges

[0001633978-17-000119:notes:196]
We have initiated various strategic restructuring events primarily intended to reduce costs, consolidate our operations, rationalize the manufacturing of our products and align our business in response to the market conditions. As of September 30, 2017 and July 1, 2017, our total restructuring accrual was $1.3 million and $3.8 million, respectively.

[0001633978-17-000119:notes:197]
During the three months ended September 30, 2017, we recorded $2.9 million in restructuring and related charges in the condensed consolidated statements of operations, of which $(0.1) million was severance costs and $3.0 million related to cost to vacate facilities, lease termination costs, and temporary labor, payroll tax, and other related costs connected with employee benefits, materials used in set up and production activities. During the three months ended October 1, 2016, we recorded $2.9 million in restructuring and related charges in the condensed consolidated statements of operations, of which $0.4 million was severance costs and $2.5 million related to cost to vacate facilities, lease termination costs, and temporary labor, payroll tax, and other related costs connected with employee benefits, materials used in set up and production activities.

[0001633978-17-000119:notes:198]
[same as prior period, unchanged from 0001633978-17-000037:notes:204]

[0001633978-17-000119:notes:199]
The adjustments to the restructuring accrual related to all of our restructuring plans described below as of September 30, 2017, were as follows (in millions):

[0001633978-17-000119:notes:200]
|  | FY 2015 Restructuring charges |  |  |
|  | Restructuring Charges |  | Exit Costs |  | Other Charges |  | Total |
| Liability as of July 1, 2017 | $ | 3.4 |  |  | $ | 0.4 |  |  | $ | — |  |  | $ | 3.8 |  |
| Charges | (0.1 | ) |  | — |  |  | 3.0 |  |  | 2.9 |  |
| Payments | (2.3 | ) |  | (0.1 | ) |  | (3.0 | ) |  | (5.4 | ) |
| Liability as of September 30, 2017 | $ | 1.0 |  |  | $ | 0.3 |  |  | $ | — |  |  | $ | 1.3 |  |

[0001633978-17-000119:notes:201]
As of September 30, 2017, our restructuring liability includes $1.3 million in other current liabilities. There are no non-current liabilities related to restructuring on our condensed consolidated balance sheet as of September 30, 2017.

[0001633978-17-000119:notes:202]
As of July 1, 2017, our restructuring liability includes $3.8 million in other current liabilities. There are no non-current liabilities related to restructuring on our condensed consolidated balance sheet as of July 1, 2017.


## us-gaap:ScheduleOfEntityWideDisclosureOnGeographicAreasLongLivedAssetsInIndividualForeignCountriesByCountryTextBlock

[0001633978-17-000119:notes:203]
[same as prior period, unchanged from 0001633978-17-000037:notes:209]

[0001633978-17-000119:notes:204]
|  | As of |
|  | September 30, 2017 |  | July 1, 2017 |
| Property, Plant and Equipment, net |  |  |  |
| United States | $ | 94.4 |  |  | $ | 88.2 |  |
| China | 84.2 |  |  | 82.5 |  |
| Thailand | 86.8 |  |  | 85.3 |  |
| Other countries | 28.3 |  |  | 17.5 |  |
| Total long-lived assets | $ | 293.7 |  |  | $ | 273.5 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001633978-17-000119:notes:205]
The components of inventories were as follows (in millions):

[0001633978-17-000119:notes:206]
|  | September 30, 2017 |  | July 1, 2017 |
| Finished goods | $ | 78.7 |  |  | $ | 71.7 |  |
| Work in process | 41.1 |  |  | 49.4 |  |
| Raw materials and purchased parts | 27.4 |  |  | 24.1 |  |
| Inventories | $ | 147.2 |  |  | $ | 145.2 |  |


## us-gaap:ScheduleOfOtherCurrentAssetsTableTextBlock

[0001633978-17-000119:notes:207]
The components of prepayments and other current assets were as follows (in millions):

[0001633978-17-000119:notes:208]
|  | September 30, 2017 |  | July 1, 2017 |
| Capitalized manufacturing overhead | $ | 27.2 |  |  | $ | 30.1 |  |
| Prepayments | 14.6 |  |  | 12.3 |  |
| Advances to contract manufacturers | 13.4 |  |  | 10.5 |  |
| Other current assets | 13.8 |  |  | 10.6 |  |
| Prepayments and other current assets | $ | 69.0 |  |  | $ | 63.5 |  |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001633978-17-000119:notes:209]
[same as prior period, unchanged from 0001633978-17-000037:notes:211]

[0001633978-17-000119:notes:210]
|  | Three Months Ended |
|  | September 30, 2017 |  | October 1, 2016 |
| Net revenue: |  |  |  |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |
| United States | $ | 33.6 |  |  | 13.8 | % |  | $ | 35.9 |  |  | 13.9 | % |
| Mexico | 24.8 |  |  | 10.3 |  |  | 39.8 |  |  | 15.4 |  |
| Other Americas | 2.2 |  |  | 0.9 |  |  | 4.0 |  |  | 1.5 |  |
| Total Americas | $ | 60.6 |  |  | 25.0 | % |  | $ | 79.7 |  |  | 30.8 | % |
| Asia-Pacific: |  |  |  |  |  |  |  |
| Hong Kong | $ | 48.9 |  |  | 20.1 | % |  | $ | 58.3 |  |  | 22.6 | % |
| Japan | 34.1 |  |  | 14.0 |  |  | 31.3 |  |  | 12.1 |  |
| Other Asia-Pacific | 74.2 |  |  | 30.5 |  |  | 65.4 |  |  | 25.3 |  |
| Total Asia-Pacific | $ | 157.2 |  |  | 64.6 | % |  | $ | 155.0 |  |  | 60.0 | % |
| EMEA | $ | 25.4 |  |  | 10.4 | % |  | $ | 23.4 |  |  | 9.2 | % |
| Total net revenue | $ | 243.2 |  |  |  |  | $ | 258.1 |  |  |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001633978-17-000119:notes:211]
[same as prior period, unchanged from 0001633978-17-000037:notes:213]

[0001633978-17-000119:notes:212]
|  | Three Months Ended |
|  | September 30, 2017 |  | October 1, 2016 |
| Net revenue: |  |  |  |
| OpComms | $ | 207.9 |  |  | $ | 218.3 |  |
| Lasers | 35.3 |  |  | 39.8 |  |
| Net revenue | $ | 243.2 |  |  | $ | 258.1 |  |
| Gross profit: |  |  |  |
| OpComms | 72.1 |  |  | 71.0 |  |
| Lasers | 10.6 |  |  | 17.2 |  |
| Total segment gross profit | 82.7 |  |  | 88.2 |  |
| Unallocated amounts: |  |  |  |
| Stock-based compensation | (2.7 | ) |  | (2.0 | ) |
| Amortization of intangibles | (0.8 | ) |  | (1.7 | ) |
| Other charges (1) | (10.7 | ) |  | (2.8 | ) |
| Gross profit | $ | 68.5 |  |  | $ | 81.7 |  |

[0001633978-17-000119:notes:213]
(1) The increase in unallocated corporate items primarily relates to inventory write-downs due to canceled programs which were not allocated to the segments.


## us-gaap:SchedulesOfConcentrationOfRiskByRiskFactorTextBlock

[0001633978-17-000119:notes:214]
The table below discloses the percentage of our total net revenue attributable to each of our two reportable segments. In addition, it discloses the percentage of our total net revenue attributable to our product offerings which serve the Telecom, Datacom and consumer and industrial (“Consumer and Industrial”) markets which accounted for more than 10% or more of our total net revenue during the last three fiscal years:

[0001633978-17-000119:notes:215]
|  | Three Months Ended |
|  |  | September 30, 2017 |  | October 1, 2016 |
| OpComms: |  | 85.5 | % |  | 84.6 | % |
| Telecom |  | 45.4 | % |  | 64.2 | % |
| Datacom |  | 18.6 | % |  | 17.1 | % |
| Consumer and Industrial |  | 21.5 | % |  | 3.3 | % |
| Lasers |  | 14.5 | % |  | 15.4 | % |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001633978-17-000119:notes:216]
Note 17. Operating Segments and Geographic Information

[0001633978-17-000119:notes:217]
Our chief executive officer is our Chief Operating Decision Maker (“CODM”). The CODM allocates resources to the segments based on their business prospects, competitive factors, net revenue and gross margin.

[0001633978-17-000119:notes:218]
[same as prior period, unchanged from 0001633978-17-000037:notes:219]

[0001633978-17-000119:notes:219]
We do not allocate research and development, sales and marketing, or general and administrative expenses to our segments because management does not include the information in its measurement of the performance of the operating segments. In addition, we do not allocate amortization and impairment of acquisition-related intangible assets, stock-based compensation and certain other charges impacting the gross margin of each segment because management does not include this information in its measurement of the performance of the operating segments.

[0001633978-17-000119:notes:220]
We operate in three geographic regions: Americas, Asia-Pacific, and EMEA (Europe, Middle East, and Africa). Net revenue is assigned to the geographic region and country where our product is initially shipped. For example, certain customers may request shipment of our product to a contract manufacturer in one country, which may differ from the location of their end customers. The following table presents net revenue by the three geographic regions we operate in and net revenue from countries that exceeded 10% of our total net revenue (in millions, except percentage data):

[0001633978-17-000119:notes:221]
In March 2017, we completed the purchase of a property in Thailand for approximately $9.9 million in cash. This property will provide additional manufacturing capacity for future growth. The building was valued at $5.5 million and the land was valued at $4.4 million.

[0001633978-17-000119:notes:222]
We purchase a substantial portion of our inventory from contract manufacturers and vendors located primarily in Thailand and China. As of September 30, 2017, 45% total inventory was purchased from a single contract manufacturer, and 26% and 11%, respectively, were purchased from two other contract manufacturers.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001633978-17-000119:notes:223]
Note 6. Balance Sheet Details

[0001633978-17-000119:notes:224]
Accounts receivable allowances

[0001633978-17-000119:notes:225]
As of September 30, 2017 and July 1, 2017, our accounts receivable allowance balance was $1.8 million and $1.8 million, respectively.

[0001633978-17-000119:notes:226]
Inventories

[0001633978-17-000119:notes:227]
Prepayments and other current assets

[0001633978-17-000119:notes:228]
Property, plant and equipment, net

[0001633978-17-000119:notes:229]
During the three months ended September 30, 2017 and October 1, 2016, we recorded a depreciation expense of $16.7 million and $11.9 million, respectively. Our construction in progress includes primarily machinery and equipment that was purchased to increase our manufacturing capacity. We expect to place these assets in service in the next 12 months.

[0001633978-17-000119:notes:230]
Other current liabilities

[0001633978-17-000119:notes:231]
Other non-current liabilities
