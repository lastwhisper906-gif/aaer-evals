# LITE MD&A — 0001633978-17-000119


## mdna

[0001633978-17-000119:mdna:1]
[same as prior period, unchanged from 0001633978-17-000037:mdna:1]

[0001633978-17-000119:mdna:2]
You should read the following discussion in conjunction with the unaudited condensed consolidated financial statements and the corresponding notes included elsewhere in this Quarterly Report on Form 10-Q (this “Quarterly Report”). This Management’s Discussion and Analysis of Financial Condition and Results of Operations contains forward-looking statements. The matters discussed in these forward-looking statements are subject to risk, uncertainties and other factors that could cause actual results

[0001633978-17-000119:mdna:3]
to differ materially from those made, projected or implied in the forward-looking statements. Please see “Risk Factors” and “Forward-Looking Statements” for a discussion of the uncertainties, risks and assumptions associated with these statements.

[0001633978-17-000119:mdna:4]
[same as prior period, unchanged from 0001633978-17-000037:mdna:3]

[0001633978-17-000119:mdna:5]
28

[0001633978-17-000119:mdna:6]
[same as prior period, unchanged from 0001633978-17-000037:mdna:4]

[0001633978-17-000119:mdna:7]
We are an industry leading provider of optical and photonic products defined by revenue and market share addressing a range of end-market applications including optical communications and commercial lasers. We have two operating segments, Optical Communications, which we refer to as OpComms, and Commercial Lasers, which we refer to as Lasers. The two operating segments were primarily determined based on how the Chief Operating Decision Maker (“CODM”) views and evaluates our operations. Operating results are regularly reviewed by the CODM to make decisions about resources to be allocated to the segments and to assess their performance. Other factors, including market separation and customer specific applications, go-to-market channels, products and manufacturing, are considered in determining the formation of these operating segments.

[0001633978-17-000119:mdna:8]
[same as prior period, unchanged from 0001633978-17-000037:mdna:16]

[0001633978-17-000119:mdna:9]
Our condensed consolidated financial statements are prepared in accordance with U.S. generally accepted accounting principles ("GAAP") as set forth in the Financial Accounting Standards Board’s Accounting Standards Codification ("ASC"), and we consider the various staff accounting bulletins and other applicable guidance issued by the United States Securities and Exchange Commission. GAAP, as set forth within the ASC, requires us to make certain estimates, judgments and assumptions. We believe that the estimates, judgments and assumptions upon which we rely are reasonable based upon information available to us at the time that these estimates, judgments and assumptions are made. These estimates, judgments and assumptions can affect the reported amounts of assets and liabilities as of the date of the financial statements as well as the reported amounts of revenues and expenses during the periods presented. To the extent there are differences between these estimates, judgments or assumptions and actual results, our financial statements will be affected. The accounting policies that reflect our more significant estimates, judgments and assumptions and which we believe are the most critical to aid in fully understanding and evaluating our reported financial results include the following:

[0001633978-17-000119:mdna:10]
• Inventory Valuation

[0001633978-17-000119:mdna:11]
• Revenue Recognition

[0001633978-17-000119:mdna:12]
• Income Taxes

[0001633978-17-000119:mdna:13]
• Long-lived Asset Valuation

[0001633978-17-000119:mdna:14]
• Warranty

[0001633978-17-000119:mdna:15]
• Derivative Liability

[0001633978-17-000119:mdna:16]
During the first quarter of fiscal 2018, the Company removed the following policies from the list of critical accounting policies and estimates:

[0001633978-17-000119:mdna:17]
• Stock-based Compensation

[0001633978-17-000119:mdna:18]
• Restructuring

[0001633978-17-000119:mdna:19]
• Business Combinations

[0001633978-17-000119:mdna:20]
• Goodwill and Intangibles

[0001633978-17-000119:mdna:21]
• Short-term Investments

[0001633978-17-000119:mdna:22]
• Impairment of Marketable and Non-Marketable Securities

[0001633978-17-000119:mdna:23]
Management’s Discussion and Analysis of Financial Condition and Results of Operations contained in Part II, Item 7 of our Annual Report on Form 10-K for our fiscal year ended July 1, 2017 provides a more complete discussion of our critical accounting policies and estimates.

[0001633978-17-000119:mdna:24]
Recently Issued Accounting Pronouncements

[0001633978-17-000119:mdna:25]
Refer to “Note 2. Recently Issued Accounting Pronouncements” in the Notes to Unaudited Condensed Consolidated Financial Statements.

[0001633978-17-000119:mdna:26]
[same as prior period, unchanged from 0001633978-17-000037:mdna:35]

[0001633978-17-000119:mdna:27]
The results of operations for the periods presented are not necessarily indicative of results to be expected for future periods. The following table summarizes selected Unaudited Condensed Consolidated Statements of Operations items as a percentage of net revenue:

[0001633978-17-000119:mdna:28]
|  | Three Months Ended |
|  | September 30, 2017 |  | October 1, 2016 |
| Segment net revenue: |  |  |  |
| OpComms | 85.5 | % |  | 84.6 | % |
| Lasers | 14.5 |  |  | 15.4 |  |
| Net revenue | 100.0 |  |  | 100.0 |  |
| Cost of sales | 71.5 |  |  | 67.7 |  |
| Amortization of acquired developed technologies | 0.3 |  |  | 0.6 |  |
| Gross profit | 28.2 |  |  | 31.7 |  |
| Operating expenses: |  |  |  |
| Research and development | 14.9 |  |  | 14.3 |  |
| Selling, general and administrative | 10.9 |  |  | 9.7 |  |
| Restructuring and related charges | 1.2 |  |  | 1.1 |  |
| Total operating expenses | 27.0 |  |  | 25.1 |  |
| Income from operations | 1.2 |  |  | 6.5 |  |
| Unrealized gain (loss) on derivative liability | 1.7 |  |  | (8.8 | ) |
| Interest and other income (expense), net | (1.4 | ) |  | 0.1 |  |
| Income (loss) before income taxes | 1.5 |  |  | (2.2 | ) |
| Benefit from income tax | (1.4 | ) |  | (0.9 | ) |
| Net income (loss) | 2.9 | % |  | (1.3 | )% |

[0001633978-17-000119:mdna:29]
Financial Data for the three months ended September 30, 2017 and October 1, 2016

[0001633978-17-000119:mdna:30]
The following table summarizes selected Unaudited Condensed Consolidated Statements of Operations items (in millions, except for percentages):

[0001633978-17-000119:mdna:31]
30

[0001633978-17-000119:mdna:32]
|  | Three months ended |  |  |  |  |
|  | September 30, 2017 |  | October 1, 2016 |  | Change |  | Percentage Change |
| Segment net revenue: |  |  |  |  |  |  |  |
| OpComms | $ | 207.9 |  |  | $ | 218.3 |  |  | $ | (10.4 | ) |  | (4.8 | )% |
| Lasers | 35.3 |  |  | 39.8 |  |  | (4.5 | ) |  | (11.3 | ) |
| Net revenue | $ | 243.2 |  |  | $ | 258.1 |  |  | $ | (14.9 | ) |  | (5.8 | )% |
| Gross profit | $ | 68.5 |  |  | $ | 81.7 |  |  | $ | (13.2 | ) |  | (16.2 | )% |
| Gross margin | 28.2 | % |  | 31.7 | % |  |  |  |  |
| Research and development | $ | 36.3 |  |  | $ | 36.9 |  |  | $ | (0.6 | ) |  | (1.6 | )% |
| Percentage of net revenue | 14.9 | % |  | 14.3 | % |  |  |  |  |
| Selling, general and administrative | $ | 26.6 |  |  | $ | 25.1 |  |  | $ | 1.5 |  |  | 6.0 | % |
| Percentage of net revenue | 10.9 | % |  | 9.7 | % |  |  |  |  |
| Restructuring and related charges | $ | 2.9 |  |  | $ | 2.9 |  |  | $ | — |  |  | — | % |
| Percentage of net revenue | 1.2 | % |  | 1.1 | % |  |  |  |  |

[0001633978-17-000119:mdna:33]
[same as prior period, unchanged from 0001633978-17-000037:mdna:42]

[0001633978-17-000119:mdna:34]
Net revenue decreased by $14.9 million, or 5.8% during the three months ended September 30, 2017 compared to the same period ended October 1, 2016. OpComms net revenue decreased $10.4 million, or 4.8%, during the three months ended September 30, 2017 compared to the three months ended October 1, 2016, driven by decreases from Telecom SuperTransport Blade and modulator products, partially offset by increased sales of 3D sensing products. Lasers net revenue decreased $4.5 million, or 11.3%, in the three months ended September 30, 2017 compared to the same period a year ago due to decreased sales of kilowatt fiber laser products.

[0001633978-17-000119:mdna:35]
[same as prior period, unchanged from 0001633978-17-000037:mdna:49]

[0001633978-17-000119:mdna:36]
We operate in three geographic regions: Americas, Asia-Pacific and EMEA. Net revenue is assigned to the geographic region and country where our product is initially shipped. For example, certain customers may request shipment of our product to a contract manufacturer in one country, however, the location of the end customers may differ. The following table presents net revenue by the three geographic regions we operate in and net revenue from countries that exceeded 10% or more of our total net revenue (in millions, except for percentages):

[0001633978-17-000119:mdna:37]
|  | Three Months Ended |
|  | September 30, 2017 |  | October 1, 2016 |
| Net revenue: |  |  |  |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |
| United States | $ | 33.6 |  |  | 13.8 | % |  | $ | 35.9 |  |  | 13.9 | % |
| Mexico | 24.8 |  |  | 10.3 |  |  | 39.8 |  |  | 15.4 |  |
| Other Americas | 2.2 |  |  | 0.9 |  |  | 4.0 |  |  | 1.5 |  |
| Total Americas | $ | 60.6 |  |  | 25.0 | % |  | $ | 79.7 |  |  | 30.8 | % |
| Asia-Pacific: |  |  |  |  |  |  |  |
| Hong Kong | $ | 48.9 |  |  | 20.1 | % |  | $ | 58.3 |  |  | 22.6 | % |
| Japan | 34.1 |  |  | 14.0 |  |  | 31.3 |  |  | 12.1 |  |
| Other Asia-Pacific | 74.2 |  |  | 30.5 |  |  | 65.4 |  |  | 25.3 |  |
| Total Asia-Pacific | $ | 157.2 |  |  | 64.6 | % |  | $ | 155.0 |  |  | 60.0 | % |
| EMEA | $ | 25.4 |  |  | 10.4 | % |  | $ | 23.4 |  |  | 9.2 | % |
| Total net revenue | $ | 243.2 |  |  |  |  | $ | 258.1 |  |  |  |

[0001633978-17-000119:mdna:38]
During the three months ended September 30, 2017 and October 1, 2016, net revenue from customers outside the United States, based on customer shipping location, represented 86.2%, and 86.1% of net revenue, respectively. Our net revenue is primarily denominated in U.S. dollars, including our net revenue from customers outside the United States as presented above. We expect revenue from customers outside of the United States to continue to be an important part of our overall net revenue and an increasing focus for net revenue growth opportunities.

[0001633978-17-000119:mdna:39]
[same as prior period, unchanged from 0001633978-17-000037:mdna:53]

[0001633978-17-000119:mdna:40]
The following table summarizes segment gross margin for the three months ended September 30, 2017 and October 1, 2016 (in millions, except for percentages):

[0001633978-17-000119:mdna:41]
|  | Gross Profit |  | Gross Margin |
|  | Three months ended |  | Three months ended |
|  | September 30, 2017 |  | October 1, 2016 |  | September 30, 2017 |  | October 1, 2016 |
| OpComms | $ | 72.1 |  |  | $ | 71.0 |  |  | 34.7 | % |  | 32.5 | % |
| Lasers | 10.6 |  |  | 17.2 |  |  | 30.0 | % |  | 43.2 | % |
| Segment total | $ | 82.7 |  |  | $ | 88.2 |  |  | 34.0 | % |  | 34.2 | % |
| Unallocated corporate items (1) | (14.2 | ) |  | (6.5 | ) |  |  |  |  |
| Total | $ | 68.5 |  |  | $ | 81.7 |  |  | 28.2 | % |  | 31.7 | % |

[0001633978-17-000119:mdna:42]
(1) The unallocated corporate items for the years presented include the effects of amortization of acquired developed technology intangible assets, share-based compensation and certain other charges. We do not allocate these items to the gross margin for each segment because management does not include such information in measuring the performance of the operating segments. The increase in unallocated corporate items primarily relates to inventory write-downs due to canceled programs which were not allocated to the segments.

[0001633978-17-000119:mdna:43]
[same as prior period, unchanged from 0001633978-17-000037:mdna:57]

[0001633978-17-000119:mdna:44]
Gross margin during the three months ended September 30, 2017 decreased by 3.5% to 28.2% from 31.7% in the same period a year ago. This decrease was primarily due to a decrease in Lasers gross margins partially offset by an increase in OpComms. In addition, there was increase in unallocated corporate items, primarily related to inventory write-downs due to canceled programs which were not allocated to the segments.

[0001633978-17-000119:mdna:45]
We sell products in certain markets that are consolidating, undergoing product, architectural and business model transitions, have high customer concentrations, are highly competitive (increasingly due to competition), are price sensitive and/or are affected by customer seasonal and mix variant buying patterns. We expect these factors to continue to result in variability of our gross margin.

[0001633978-17-000119:mdna:46]
[same as prior period, unchanged from 0001633978-17-000037:mdna:59]

[0001633978-17-000119:mdna:47]
[same as prior period, unchanged from 0001633978-17-000037:mdna:6]

[0001633978-17-000119:mdna:48]
OpComms gross margin during the three months ended September 30, 2017 increased by 2.2% to 34.7% from 32.5% in the same period a year ago. This increase was primarily due to increased sales of our 3D sensing products, offset partially by underutilization of manufacturing capacity for our Telecom and Datacom products.

[0001633978-17-000119:mdna:49]
[same as prior period, unchanged from 0001633978-17-000037:mdna:11]

[0001633978-17-000119:mdna:50]
Lasers gross margin in the three months ended September 30, 2017 decreased by 13.2% to 30.0% from 43.2% in the same period a year ago. This decrease was primarily due to unfavorable product mix and a write-down of inventory.

[0001633978-17-000119:mdna:51]
Research and Development

[0001633978-17-000119:mdna:52]
R&D expense decreased by $0.6 million, or 1.6%, for the three months ended September 30, 2017 compared to the same period a year ago. The decrease in R&D expense was primarily due to higher partner reimbursements for the development expenses of $0.9 million. This was partially offset by an increase of stock-based compensation of $0.4 million.

[0001633978-17-000119:mdna:53]
[same as prior period, unchanged from 0001633978-17-000037:mdna:69]

[0001633978-17-000119:mdna:54]
Selling, General and Administrative

[0001633978-17-000119:mdna:55]
SG&A expense increased by $1.5 million, or 6.0%, during the three months ended September 30, 2017 compared to the same period ended October 1, 2016. The increase was primarily a result of an increase in payroll related expense of $1.5 million.

[0001633978-17-000119:mdna:56]
We may experience in the future, certain non-core expenses, such as mergers and acquisitions-related expenses and litigation expenses, which could increase our SG&A expenses and potentially impact our profitability expectations in any particular quarter.

[0001633978-17-000119:mdna:57]
[same as prior period, unchanged from 0001633978-17-000037:mdna:74]

[0001633978-17-000119:mdna:58]
We have reduced costs through targeted restructuring efforts intended to consolidate our operations, rationalize the manufacturing of our products and align our business in response to market conditions. Refer to “Note 13. Restructuring and Related Charges” in the Notes to Unaudited Condensed Consolidated Financial Statements.

[0001633978-17-000119:mdna:59]
As of September 30, 2017, our total restructuring accrual was $1.3 million. During the three months ended September 30, 2017, we recorded $2.9 million in restructuring and related charges mainly related to cost to vacate facilities, lease termination costs, and temporary labor, payroll tax, and other related costs connected with employee benefits, materials used in set up and production activities.

[0001633978-17-000119:mdna:60]
[same as prior period, unchanged from 0001633978-17-000037:mdna:79]

[0001633978-17-000119:mdna:61]
Interest and other income (expense), net is comprised substantially of amortization of the debt discount on the 2024 Notes, interest income (expense) on our short-term investments and foreign exchange gains (losses). See “Note 10. Convertible Senior Notes” in the Notes to the Unaudited Condensed Consolidated Financial Statements for additional information on the 2024 Notes.

[0001633978-17-000119:mdna:62]
Interest and other income (expense), net was $(3.4) million during the three months ended September 30, 2017 as compared to $0.2 million for the three months ended October 1, 2016. The change was primarily due to interest expense related to the 2024 Notes and interest income related to the short-term investments during the three months ended September 30, 2017.

[0001633978-17-000119:mdna:63]
The components of interest and other income (expense), net were as follows (in millions):

[0001633978-17-000119:mdna:64]
|  | Three Months Ended |
|  | September 30, 2017 |  | October 1, 2016 |
| Interest expense | $ | (4.4 | ) |  | $ | — |  |
| Foreign exchange gains (losses), net | (0.4 | ) |  | 0.2 |  |
| Other income (expense), net | 1.4 |  |  | — |  |
| Interest and other income (expense), net | $ | (3.4 | ) |  | $ | 0.2 |  |

[0001633978-17-000119:mdna:65]
Unrealized gain (loss) on derivative liability

[0001633978-17-000119:mdna:66]
Unrealized gain (loss) on Series A Preferred Stock derivative liability amounted to $4.2 million and $(22.7) million for the three months ended September 30, 2017 and October 1, 2016, respectively. The change is primarily related to the change in the price of our underlying common stock and is reflected in the condensed consolidated statements of operations as “Unrealized gain (loss) on derivative liability”.

[0001633978-17-000119:mdna:67]
For further discussion of our derivative liability, see “Note 11. Derivative Liability” in the Notes to Unaudited Condensed Consolidated Financial Statements.

[0001633978-17-000119:mdna:68]
Provision for (Benefit from) Income Taxes (in millions)

[0001633978-17-000119:mdna:69]
|  | Three months ended |
|  | September 30, 2017 |  | October 1, 2016 |
| Benefit from income taxes | $ | (3.6 | ) |  | $ | (2.3 | ) |

[0001633978-17-000119:mdna:70]
Our tax provision for interim periods is determined using an estimate of our annual effective tax rate, adjusted for discrete items, if any, that arise during the period. Each quarter, we update our estimate of the annual effective tax rate, and if the estimated annual effective tax rate changes, we make a cumulative adjustment in such period.

[0001633978-17-000119:mdna:71]
Our quarterly tax provision, and estimate of our annual effective tax rate, is subject to variation due to several factors, including variability in pre-tax income (or loss), the mix of jurisdictions to which such income relates, changes in how we do business, and tax law developments. Our estimated effective tax rate for the year differs from the U.S. statutory rate of 35% primarily due to the benefit of earnings of our subsidiaries being taxed at rates lower than the U.S. statutory rate, non-deductible stock-based compensation, and unrecognized tax benefits.

[0001633978-17-000119:mdna:72]
We recorded a tax benefit of $(3.6) million and $(2.3) million for the three months ended September 30, 2017 and October 1, 2016, respectively. Our tax benefit for the three months ended September 30, 2017, was primarily due to the tax benefit from excess stock-based compensation deductions, as well as the non-taxable unrealized gain from the embedded derivatives for the Series A Preferred Stock. The benefit for income tax for the three months ended October 1, 2016 was primarily due to an increase of profit in jurisdictions with lower tax rates, utilization of U.S. tax attributes that were subject to a full valuation allowance, certain Canadian tax incentives, and a net benefit of $0.5 million of true-up adjustments in our foreign jurisdictions.

[0001633978-17-000119:mdna:73]
While we believe our current valuation allowance is sufficient, we assess the need for an adjustment to the valuation allowance on a quarterly basis. The assessment is based on our estimates of future sources of taxable income for the jurisdictions in which we operate and the periods over which our deferred tax assets will be realizable. In the event we determine that we will be able to realize all or part of our net deferred tax assets in the future, the valuation allowance will be reversed in the period in which we make such determination. The release of a valuation allowance against deferred tax assets may cause greater volatility in the effective tax rate in the periods in which it is reversed. It is reasonably possible that significant positive evidence may become available to reach a conclusion that a significant portion of the valuation allowance will no longer be needed, and as such, we may release a significant portion of our valuation allowance in the next 12 months. Such a release would result in the recognition of certain deferred tax assets and a decrease in the income tax expense for the period in which the release is recorded.

[0001633978-17-000119:mdna:74]
The income and non-income tax regimes we are subject to or operate under are unsettled and may be subject to significant change. Changes in tax laws or tax rulings, or changes in interpretations of existing laws, could materially affect our financial position and results of operations. Many countries in Europe, as well as a number of other countries and organizations, have recently proposed or recommended changes to existing tax laws or have enacted new laws that could significantly increase our tax obligations in many countries where we do business or require us to change the manner in which we operate our business. The Organization for Economic Cooperation and Development has been working on a Base Erosion and Profit Sharing Project, which was issued in 2015, and is expected to continue to be revised, includes guidelines and proposals that may change various aspects of the existing framework under which our tax obligations are determined in many of the countries in which we do business. The European Commission has conducted investigations in multiple countries focusing on whether local country tax rulings or tax legislation provides preferential tax treatment that violates European Union state aid rules and concluded that certain countries. These investigations may result in changes to the tax treatment of our foreign operations. In addition, the current U.S. administration and key members of Congress have made public statements indicating that tax reform is a priority. Certain changes to U.S. tax laws, including limitations on the ability to defer U.S. taxation on earnings outside of the United States until those earnings are repatriated to the United States, could affect the tax treatment of our foreign earnings. Due to our expanding international business activities, many of these types of changes to the taxation of our activities could increase our worldwide effective tax rate and harm our financial position and results of operations.

[0001633978-17-000119:mdna:75]
For further discussion of our income tax provision, see “Note 14. Income Taxes” in the Notes to Unaudited Condensed Consolidated Financial Statements.

[0001633978-17-000119:mdna:76]
[same as prior period, unchanged from 0001633978-17-000037:mdna:91]

[0001633978-17-000119:mdna:77]
The following table summarizes our contractual obligations at September 30, 2017, and the effect such obligations are expected to have on our liquidity and cash flow over the next five years (in millions):

[0001633978-17-000119:mdna:78]
|  | Payments due by period |
|  | Total |  | Less than 1 year |  | 1 - 3 years |  | 3 - 5 years |  | More than 5 years |
| Contractual Obligations |  |  |  |  |  |  |  |  |  |
| Asset retirement obligations | $ | 2.8 |  |  | $ | 0.3 |  |  | $ | 0.4 |  |  | $ | 0.5 |  |  | $ | 1.6 |  |
| Purchase obligations (1) | 184.6 |  |  | 179.8 |  |  | 4.8 |  |  | — |  |  | — |  |
| Operating lease obligations (1) | 40.3 |  |  | 11.4 |  |  | 18.3 |  |  | 7.4 |  |  | 3.2 |  |
| Capital lease obligation (1) | 7.5 |  |  | 3.7 |  |  | 3.8 |  |  | — |  |  | — |  |
| Pension and post-retirement benefit payments | 4.2 |  |  | 0.5 |  |  | 0.2 |  |  | 0.2 |  |  | 3.3 |  |
| 0.25% Convertible Senior Notes due 2024 | 450.0 |  |  | — |  |  | — |  |  | — |  |  | 450.0 |  |
| Interest on 2024 Notes (2) | 6.7 |  |  | 1.1 |  |  | 2.2 |  |  | 2.3 |  |  | 1.1 |  |
| Acquisition contingencies (3) | 2.7 |  |  | — |  |  | 2.7 |  |  | — |  |  | — |  |
| Total | $ | 698.8 |  |  | $ | 196.8 |  |  | $ | 32.4 |  |  | $ | 10.4 |  |  | $ | 459.2 |  |

[0001633978-17-000119:mdna:79]
(1) Refer to “Note 16. Commitments and Contingencies” in the Notes to Unaudited Condensed Consolidated Financial Statements.

[0001633978-17-000119:mdna:80]
(2) Includes interest on our 0.25% Convertible Senior Notes due 2024 through September 2023 as we have the right to redeem the 2024 Notes in whole or in part at any time on or after March 15, 2024.

[0001633978-17-000119:mdna:81]
(3) Refer to “Note 5. Mergers and Acquisitions” in the Notes to Unaudited Condensed Consolidated Financial Statements.

[0001633978-17-000119:mdna:82]
[same as prior period, unchanged from 0001633978-17-000037:mdna:97]

[0001633978-17-000119:mdna:83]
As of September 30, 2017, other current liabilities on the condensed consolidated balance sheet include $0.3 million and $0.2 million of asset retirement obligations and operating lease obligations, respectively, in connection with restructuring and related activities, disclosed in the preceding table.

[0001633978-17-000119:mdna:84]
As of September 30, 2017, our other non-current liabilities primarily relate to asset retirement obligations and pension which are presented in various lines in the preceding table.

[0001633978-17-000119:mdna:85]
As of September 30, 2017, our other non-current liabilities on the condensed consolidated balance sheet include $7.9 million of unrecognized tax benefit for uncertain tax positions. We are unable to reliably estimate the timing of future payments related to uncertain tax positions and therefore have excluded them from the preceding table.

[0001633978-17-000119:mdna:86]
[same as prior period, unchanged from 0001633978-17-000037:mdna:99]

[0001633978-17-000119:mdna:87]
[same as prior period, unchanged from 0001633978-17-000037:mdna:100]

[0001633978-17-000119:mdna:88]
[same as prior period, unchanged from 0001633978-17-000037:mdna:101]

[0001633978-17-000119:mdna:89]
[same as prior period, unchanged from 0001633978-17-000037:mdna:102]

[0001633978-17-000119:mdna:90]
[same as prior period, unchanged from 0001633978-17-000037:mdna:103]

[0001633978-17-000119:mdna:91]
As of September 30, 2017 and July 1, 2017, our cash and cash equivalents of $150.8 million and $272.9 million, respectively, were held predominantly in the United States. The total amount of cash outside the United States as of September 30, 2017 is $33.9 million, which is primarily held in Cayman Islands, Thailand, Canada, Switzerland, China and Japan. Although the cash currently held in the United States as well as the cash generated in the United States from future operations is expected to cover our normal operating requirements, a substantial amount of additional cash could be required for other purposes, such as capital expenditures to support our business and growth, including costs associated with increasing internal manufacturing capabilities, such as our new Thailand facility, strategic transactions and partnerships, and acquisitions. Our intent is to indefinitely reinvest funds held outside the United States and our current plans do not demonstrate a need to repatriate them to fund our domestic operations. However, if in the future, we encounter a significant need for liquidity domestically or at a particular location that we cannot fulfill through borrowings, equity offerings, or other internal or external sources, we may determine that cash repatriations are necessary. Repatriation could result in additional material U.S. federal and state income tax payments in future years. Such adverse consequences would occur, for example, if the transfer of cash into the United States is taxed and no foreign tax credit is available to offset the U.S. tax liability, resulting in higher taxes. These factors may cause us to have an overall tax rate higher than other companies or higher than our tax rates have been in the past. If conditions warrant, we may seek to obtain additional financing through debt or equity sources. To the extent we issue additional shares, our existing stockholders may be diluted. However, any such financing may not be available on terms favorable to us, or may not be available at all.

[0001633978-17-000119:mdna:92]
As of September 30, 2017, our consolidated balance of cash and cash equivalents decreased by $122.1 million, to $150.8 million from $272.9 million as of July 1, 2017. The decrease in cash and cash equivalents was mainly due to purchases of short-term investments, net of sales of $99.5 million and capital expenditures of $33.0 million during the fiscal first quarter of 2018.

[0001633978-17-000119:mdna:93]
[same as prior period, unchanged from 0001633978-17-000037:mdna:107]

[0001633978-17-000119:mdna:94]
Cash provided by operating activities was $9.7 million during the three months ended September 30, 2017, primarily resulting from $7.1 million of net income, $26.8 million of non-cash items such as depreciation, stock-based compensation, amortization of intangibles, amortization of discount on the 2024 Notes, offset by the unrealized gain on derivative liability, and changes in our operating assets and liabilities of $24.2 million. Changes in our operating assets and liabilities of $24.2 million related primarily to an increase in accounts receivable of $7.5 million and an increase in prepayments and other current and non-currents assets of $5.8 million, offset by an increase in accrued expenses and other current and non-current liabilities.

[0001633978-17-000119:mdna:95]
Cash provided by operating activities was $36.3 million during the three months ended October 1, 2016, primarily resulting from $3.4 million of net loss and $44.1 million of non-cash items such as depreciation, stock-based compensation, amortization of intangibles and unrealized loss on derivative liability, offset by changes in operating assets and liabilities of $4.4 million. Changes in our operating assets and liabilities related primarily to a decrease in accounts receivable of $14.0 million due to an increase in billings as well as the timing of payments from these customers, a decrease in accrued expenses and other current and non-current liabilities of $1.6 million is due to the timing of invoices and payments to vendors, offset by an increase in accounts payable of$14.2 million related to the growth in our business, an increase in inventories of $3.0 million, and an increase in income tax payable of $1.3 million.

[0001633978-17-000119:mdna:96]
[same as prior period, unchanged from 0001633978-17-000037:mdna:110]

[0001633978-17-000119:mdna:97]
Cash used in investing activities was $132.5 million, mainly consisted of capital expenditures of $33.0 million, and purchases of short-term investments, net of sales $99.5 million, respectively, for the three months ended September 30, 2017.

[0001633978-17-000119:mdna:98]
Cash used in investing activities was for capital expenditures of $28.9 million during the three months ended October 1, 2016.

[0001633978-17-000119:mdna:99]
[same as prior period, unchanged from 0001633978-17-000037:mdna:112]

[0001633978-17-000119:mdna:100]
Cash provided by financing activities was $0.3 million and primarily due to proceeds from the exercise of stock options of $1.7 million for the three months ended September 30, 2017 offset by a repayment of a capital lease obligation of $1.2 million.

[0001633978-17-000119:mdna:101]
Cash provided by financing activities was $2.3 million during the three months ended October 1, 2016 resulting primarily from proceeds of stock option exercises.

[0001633978-17-000119:mdna:102]
[same as prior period, unchanged from 0001633978-17-000037:mdna:115]

[0001633978-17-000119:mdna:103]
We believe that our cash and cash equivalents as of September 30, 2017, and cash flows from our operating activities will be sufficient to meet our liquidity and capital spending requirements for at least the next 12 months. However, if market conditions are favorable, we may evaluate alternatives to opportunistically pursue additional financing.

[0001633978-17-000119:mdna:104]
[same as prior period, unchanged from 0001633978-17-000037:mdna:117]

[0001633978-17-000119:mdna:105]
[same as prior period, unchanged from 0001633978-17-000037:mdna:118]

[0001633978-17-000119:mdna:106]
| • | changes in accounts receivable, inventory or other operating assets and liabilities, which affect our working capital; |

[0001633978-17-000119:mdna:107]
[same as prior period, unchanged from 0001633978-17-000037:mdna:120]

[0001633978-17-000119:mdna:108]
[same as prior period, unchanged from 0001633978-17-000037:mdna:121]

[0001633978-17-000119:mdna:109]
[same as prior period, unchanged from 0001633978-17-000037:mdna:122]

[0001633978-17-000119:mdna:110]
[same as prior period, unchanged from 0001633978-17-000037:mdna:123]

[0001633978-17-000119:mdna:111]
| • | volatility in fixed income and credit, which impact the liquidity and valuation of our investment portfolios; |

[0001633978-17-000119:mdna:112]
| • | volatility in foreign exchange markets, which impacts our financial results; |

[0001633978-17-000119:mdna:113]
[same as prior period, unchanged from 0001633978-17-000037:mdna:126]

[0001633978-17-000119:mdna:114]
[same as prior period, unchanged from 0001633978-17-000037:mdna:127]

[0001633978-17-000119:mdna:115]
[same as prior period, unchanged from 0001633978-17-000037:mdna:128]

[0001633978-17-000119:mdna:116]
| • | the settlement of any conversion or redemption of the 2024 Notes in cash. |
