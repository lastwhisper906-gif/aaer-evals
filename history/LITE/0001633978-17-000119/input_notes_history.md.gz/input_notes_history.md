# LITE note change history — 0001633978-17-000037 → 0001633978-17-000119


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2017-11-01):
[0001633978-17-000119:note_history:1]
We lease certain real and personal property from unrelated third parties under non-cancellable operating leases that expire at various dates through fiscal 2026. Certain leases require us to pay property taxes, insurance and routine maintenance, and include escalation clauses. As of September 30, 2017 the future minimum annual lease payments under non-cancellable operating leases were as follows (in millions):
  (was, 2017-05-04, similarity 0.9826):
[0001633978-17-000037:note_history:1]
We lease certain real and personal property from unrelated third parties under non-cancellable operating leases that expire at various dates through fiscal 2026. Certain leases require us to pay property taxes, insurance and routine maintenance, and include escalation clauses. As of April 1, 2017, the future minimum annual lease payments under non-cancellable operating leases were as follows (in millions):

- changed (2017-11-01):
[0001633978-17-000119:note_history:2]
Included in the future minimum lease payments table above is $0.2 million related to lease commitments in connection with our restructuring and related activities. Refer to “Note 13. Restructuring and Related Charges” in the Notes to Unaudited Condensed Consolidated Financial Statements.
  (was, 2017-05-04, similarity 0.8889):
[0001633978-17-000037:note_history:2]
Included in the future minimum lease payments table above is $0.5 million related to lease commitments in connection with our restructuring and related activities. Refer to "Note 12. Restructuring and Related Charges" in the Notes to Unaudited  Consolidated Financial Statements.

- added (2017-11-01):
[0001633978-17-000119:note_history:3]
Rental expense relating to building and equipment was $3.4 million, and $2.2 million for the three months ended September 30, 2017 and October 1, 2016, respectively.

- added (2017-11-01):
[0001633978-17-000119:note_history:4]
Capital Lease

- added (2017-11-01):
[0001633978-17-000119:note_history:5]
In the first quarter of fiscal 2018, we started leasing equipment under a capital lease. Our capital lease asset is included in property, plant and equipment, net in our condensed consolidated balance sheets as of September 30, 2017. Amortization expense on this capital lease asset is recorded as depreciation expense and is included in cost of sales in our condensed consolidated statements of operations for the three months ended September 30, 2017. Our capital lease obligation is recorded at the lesser of the estimated fair market value of the leased property or the net present value of the aggregate future minimum lease payments and is included in other current liabilities and other non-current liabilities in our condensed consolidated balance sheets as of September 30, 2017. Refer to “Note 6. Balance Sheet Details” for further details. Interest on these obligations is included in interest expense in our condensed consolidated statements of operations.

- added (2017-11-01):
[0001633978-17-000119:note_history:6]
As of September 30, 2017 the future minimum annual lease payments under our capital lease were as follows (in millions):

- changed (2017-11-01):
[0001633978-17-000119:note_history:7]
| Remainder of 2018 | $ | 3.7 |  |
| 2019 | 3.8 |  |
| Total minimum capital lease payments | $ | 7.5 |  |
  (was, 2017-05-04, similarity 0.6637):
[0001633978-17-000037:note_history:7]
| Remainder of 2017 | $ | — |  |
| 2018 | 1.2 |  |
| 2019 | 1.1 |  |
| 2020 | 1.1 |  |
| 2021 | 1.1 |  |
| Thereafter | 452.8 |  |
| Total Notes payments | $ | 457.3 |  |

- changed (2017-11-01):
[0001633978-17-000119:note_history:8]
The Company incurred liabilities in the amount of $3.6 million in connection with the fiscal 2017 acquisition. The amount of $2.7 million is payable in 36 months following the acquisition date contingent upon meeting certain production targets. The Company retained $0.9 million of the purchase price to cover any potential liabilities under the representations, warranties and indemnifications included in the purchase agreement, the amount is payable at the 15 month anniversary of the close date. Refer to “Note 5. Mergers and Acquisitions”.
  (was, 2017-05-04, similarity 0.9749):
[0001633978-17-000037:note_history:8]
The Company incurred contingent liabilities in the amount of $3.6 million in connection with the February 2017 acquisition. The amount of $2.7 million is payable in 36 months following the acquisition date contingent upon meeting certain production targets. The Company retained $0.9 million of the purchase price to cover any potential liabilities under the representations, warranties and indemnifications included in the purchase agreement, the amount is payable at the 15 month anniversary of the close date. Refer to "Note 6. Mergers and Acquisitions".

- changed (2017-11-01):
[0001633978-17-000119:note_history:9]
The future interest and principal payments related to the 2024 Notes are as follows as of September 30, 2017:
  (was, 2017-05-04, similarity 0.9388):
[0001633978-17-000037:note_history:9]
The future interest and principal payments related to the Notes are as follows as of April 1, 2017:

- added (2017-11-01):
[0001633978-17-000119:note_history:10]
| Remainder of 2018 | $ | 0.6 |  |
| 2019 | 1.1 |  |
| 2020 | 1.1 |  |
| 2021 | 1.1 |  |
| 2022 | 1.1 |  |
| Thereafter | 451.7 |  |
| Total 2024 Notes payments | $ | 456.7 |  |

- changed (2017-11-01):
[0001633978-17-000119:note_history:11]
Purchase obligations of $184.6 million as of September 30, 2017, represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule and adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.
  (was, 2017-05-04, similarity 0.9877):
[0001633978-17-000037:note_history:11]
Purchase obligations of $110.5 million as of April 1, 2017, represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule and adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

- changed (2017-11-01):
[0001633978-17-000119:note_history:12]
The following table presents the changes in our warranty reserve during the three months ended September 30, 2017 and October 1, 2016 (in millions):
  (was, 2017-05-04, similarity 0.8968):
[0001633978-17-000037:note_history:12]
The following table presents the changes in our warranty reserve during the three and nine months ended April 1, 2017 and April 2, 2016 (in millions):

- added (2017-11-01):
[0001633978-17-000119:note_history:13]
|  | Three Months Ended |
|  | September 30, 2017 |  | October 1, 2016 |
| Balance as of July 1, 2017 | $ | 9.7 |  |  | $ | 2.8 |  |
| Provision for warranty | 1.0 |  |  | 3.8 |  |
| Utilization of reserve | (1.3 | ) |  | (1.2 | ) |
| Balance as of September 30, 2017 | $ | 9.4 |  |  | $ | 5.4 |  |

- changed (2017-11-01):
[0001633978-17-000119:note_history:14]
Our research and development (“R&D”), manufacturing and distribution operations involve the use of hazardous substances and are regulated under international, federal, state and local laws governing health and safety and the environment. We apply strict standards for protection of the environment and occupational health and safety to sites inside and outside the United States, even if not subject to regulations imposed by foreign governments. We believe that our properties and operations at our facilities comply in all material respects with applicable environmental laws and occupational health and safety laws. However, the risk of environmental liabilities cannot be completely eliminated and there can be no assurance that the application of environmental and health and safety laws will not require us to incur significant expenditures. We are also regulated under a number of international, federal, state and local laws regarding recycling, product packaging and product content requirements. The environmental, product content/disposal and recycling laws are gradually becoming more stringent and may cause us to incur significant expenditures in the future.
  (was, 2017-05-04, similarity 0.9983):
[0001633978-17-000037:note_history:14]
Our research and development ("R&D"), manufacturing and distribution operations involve the use of hazardous substances and are regulated under international, federal, state and local laws governing health and safety and the environment. We apply strict standards for protection of the environment and occupational health and safety to sites inside and outside the United States, even if not subject to regulations imposed by foreign governments. We believe that our properties and operations at our facilities comply in all material respects with applicable environmental laws and occupational health and safety laws. However, the risk of environmental liabilities cannot be completely eliminated and there can be no assurance that the application of environmental and health and safety laws will not require us to incur significant expenditures. We are also regulated under a number of international, federal, state and local laws regarding recycling, product packaging and product content requirements. The environmental, product content/disposal and recycling laws are gradually becoming more stringent and may cause us to incur significant expenditures in the future.

- added (2017-11-01):
[0001633978-17-000119:note_history:15]
In connection with the Separation, we agreed to indemnify Viavi for any liability associated with contamination from past operations at all properties transferred to us from Viavi, to the extent the resulting issues primarily related to our business.

- changed (2017-11-01):
[0001633978-17-000119:note_history:16]
We are subject to a variety of claims and suits that arise from time to time in the ordinary course of our business. While management currently believes that resolving claims against us, individually or in the aggregate, will not have a material adverse impact on our financial position, results of operations or statements of cash flows, these matters are subject to inherent uncertainties and management’s view of these matters may change in the future. Were an unfavorable final outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the effect becomes reasonably estimable.
  (was, 2017-05-04, similarity 0.9985):
[0001633978-17-000037:note_history:16]
We are subject to a variety of claims and suits that arise from time to time in the ordinary course of our business. While management currently believes that resolving claims against us, individually or in the aggregate, will not have a material adverse impact on our financial position, results of operations or statements of cash flows, these matters are subject to inherent uncertainties and management's view of these matters may change in the future. Were an unfavorable final outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the effect becomes reasonably estimable.

- added (2017-11-01):
[0001633978-17-000119:note_history:17]
Indemnifications

- added (2017-11-01):
[0001633978-17-000119:note_history:18]
In the normal course of business, the Company enters into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown because claims may be made against the Company in the future and the Company may record charges in the future as a result of these indemnification obligations. As of September 30, 2017, the Company did not have any material indemnification claims that were probable or reasonably possible.

- removed (2017-11-01):
[0001633978-17-000037:note_history:19]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 1, 2017 |  | April 2, 2016 |  | April 1, 2017 |  | April 2, 2016 |
| Balance as of beginning of period | $ | 8.7 |  |  | $ | 3.1 |  |  | $ | 2.8 |  |  | $ | 2.8 |  |
| Provision for warranty | 0.6 |  |  | 0.8 |  |  | 9.3 |  |  | 2.5 |  |
| Utilization of reserve | (1.2 | ) |  | (0.8 | ) |  | (4.0 | ) |  | (2.3 | ) |
| Adjustments related to pre-existing warranties (includingchanges in estimates) | — |  |  | (1.3 | ) |  | — |  |  | (1.2 | ) |
| Balance as of period end | $ | 8.1 |  |  | $ | 1.8 |  |  | $ | 8.1 |  |  | $ | 1.8 |  |


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2017-11-01):
[0001633978-17-000119:note_history:20]
Lumentum (we, us, our or the Company) is an industry-leading provider of optical and photonic products defined by revenue and market share addressing a range of end market applications including data communications (“Datacom”) and telecommunications (“Telecom”) networking and commercial lasers (“Commercial Lasers”) for manufacturing, inspection and life-science applications. We are using our core optical and photonic technology and our volume manufacturing capability to expand into attractive emerging markets that benefit from advantages that optical or photonics-based solutions provide, including 3D sensing for consumer electronics and diode light sources for a variety of consumer and industrial applications. The majority of our customers tend to be original equipment manufacturers (“OEMs”) that incorporate our products into their products which then address end-market applications. For example, we sell fiber optic components that our network equipment manufacturer (“NEM”) customers assemble into communications networking systems, which they sell to network service providers or enterprises with their own networks. Similarly, many of our customers for our Lasers products incorporate our products into tools they produce, which are used for manufacturing processes by their customers. For 3D sensing, we sell diode lasers to manufacturers of consumer electronics products for mobile, personal computing, gaming, and other applications, who then integrate our devices within their products, for eventual resale to consumers.
  (was, 2017-05-04, similarity 0.8602):
[0001633978-17-000037:note_history:20]
Lumentum Holdings Inc. ("we", "our", "Lumentum" or the "Company") is an industry leading provider of optical and photonic products defined by revenue and market share addressing a range of end market applications including data communications ("Datacom") and telecommunications ("Telecom") networking and commercial lasers ("Commercial Lasers") for manufacturing, inspection and life-science applications. We are using our core optical and photonic technology and our volume manufacturing capability to expand into attractive emerging markets that benefit from advantages that optical or photonics-based solutions provide, including 3-D sensing for consumer electronics and diode light sources for a variety of consumer and industrial applications. The majority of our customers tend to be original equipment manufacturers ("OEMs") that incorporate our products into their products which then address end-market applications. For example, we sell fiber optic components that our network equipment manufacturer ("NEM") customers assemble into communications networking systems, which they sell to network service providers or enterprises with their own networks. Similarly, many of our customers for our Commercial Lasers products incorporate our products into tools they produce, which are used for manufacturing processes by their customers.

- added (2017-11-01):
[0001633978-17-000119:note_history:21]
The preparation of the condensed consolidated financial statements in accordance with GAAP in the United States requires management to make estimates and assumptions that affect the amounts reported in our condensed consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates. Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are revenue recognition, inventory valuation, valuation of derivative liability, long-lived asset valuation, warranty and accounting for income taxes.

- changed (2017-11-01):
[0001633978-17-000119:note_history:22]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Our fiscal 2018 is a 52-week year ending on June 30, 2018. Our fiscal 2017 was a 52-week year and ended on July 1, 2017.
  (was, 2017-05-04, similarity 0.9667):
[0001633978-17-000037:note_history:22]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Our fiscal 2017 is a 52-week year ending on July 1, 2017, while fiscal 2016 was a 53-week year and ended on July 2, 2016.

- added (2017-11-01):
[0001633978-17-000119:note_history:23]
These interim unaudited condensed consolidated financial statements include the accounts of the Company and its wholly-owned subsidiaries. All intra-company transactions within our business were eliminated.

- added (2017-11-01):
[0001633978-17-000119:note_history:24]
The accompanying interim unaudited condensed consolidated financial statements and accompanying related notes should be read in conjunction with the condensed consolidated financial statements and related notes included in our Annual Report on Form 10-K for the fiscal year ended July 1, 2017.

- added (2017-11-01):
[0001633978-17-000119:note_history:25]
The Company adopted ASU 2016-09, Stock Compensation ASU 718 - Improvements to Employee Share-Based Payment Accounting at the beginning of the first quarter of fiscal year 2018. As a result of the adoption, in the first quarter of fiscal year 2018, the Company recorded on a modified retrospective basis a $2.6 million cumulative-effect adjustment to retained earnings for the recognition of excess tax benefits generated by the settlement of share-based awards in prior periods. The Company elected to account for forfeitures of equity awards when they occur. The change was applied on a modified retrospective basis with a cumulative-effect adjustment of approximately $0.2 million to retained earnings in the first quarter of fiscal year 2018.

- added (2017-11-01):
[0001633978-17-000119:note_history:26]
All excess tax benefits and deficiencies are recognized in the income tax provision in the Condensed Consolidated Statements of Operations prospectively, rather than in additional paid-in-capital in the condensed consolidated balance sheets. In addition, the standard eliminates the requirement to defer recognition of excess tax benefits until they are realized through a reduction to income taxes payable. The Company presents excess tax benefits as an operating activity in the Condensed Consolidated Statements of Cash Flows on a prospective basis.

- removed (2017-11-01):
[0001633978-17-000037:note_history:27]
Lumentum was incorporated in Delaware as a wholly owned subsidiary of JDS Uniphase Corporation ("JDSU") on February 10, 2015 and is comprised of the former communications and commercial optical products (“CCOP”) segment and WaveReady product lines of JDSU.

- removed (2017-11-01):
[0001633978-17-000037:note_history:28]
On July 31, 2015, prior to the Separation (as described below), JDSU transferred substantially all of the assets and liabilities and operations of the CCOP segment and WaveReady product lines to Lumentum. Financial statements for periods prior to the Separation were prepared on a stand-alone basis and were derived from JDSU’s consolidated financial statements and accounting records. The Company prepared consolidated financial statements for the period from June 28, 2015 to August 1, 2015 where expenses were allocated to the Company using estimates that it considers to be a reasonable reflection of the utilization of services provided to, or benefits received by, the Company. Since August 1, 2015, the Company has prepared consolidated financial statements as an independent stand-alone basis pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (SEC) and are in conformity with generally accepted accounting principles in the United States (GAAP). In the opinion of management, these consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments, which are necessary for a fair statement of the consolidated financial statements for the periods shown. The results of operations for such periods are not necessarily indicative of the results expected for the full year or for any future periods.

- removed (2017-11-01):
[0001633978-17-000037:note_history:29]
On August 1, 2015, Lumentum became an independent publicly-traded company through the distribution by JDSU to its stockholders of 80.1% of our outstanding common stock (the “Separation”). Each JDSU stockholder of record as of the close of business on July 27, 2015 received one share of Lumentum common stock for every five shares of JDSU common stock held on the record date. JDSU was renamed Viavi Solutions Inc. ("Viavi") and at the time of the distribution retained ownership of 19.9% of Lumentum’s outstanding shares. Lumentum’s Registration Statement on Form 10 was declared effective by the SEC on July 16, 2015. Lumentum’s common stock began trading “regular-way” under the ticker “LITE” on the NASDAQ stock market on August 4, 2015.

- removed (2017-11-01):
[0001633978-17-000037:note_history:30]
As of April 1, 2017, Viavi held a total of 0.4 million shares of our common stock, which is under 1% of our total shares outstanding.

- removed (2017-11-01):
[0001633978-17-000037:note_history:31]
See "Note 3. Related Party Transactions" in the Notes to Unaudited Consolidated Financial Statements regarding the relationships we have with Viavi.

- removed (2017-11-01):
[0001633978-17-000037:note_history:32]
These unaudited interim consolidated financial statements include the accounts of the Company and its wholly-owned subsidiaries. All intra-company transactions and balances within our business were eliminated. All material transactions between us and other businesses of Viavi prior to Separation were reflected as net transfers to and from Viavi as a component of financing activities in the consolidated statements of cash flows.

- removed (2017-11-01):
[0001633978-17-000037:note_history:33]
Use of Estimates

- removed (2017-11-01):
[0001633978-17-000037:note_history:34]
The preparation of our consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amount of assets and liabilities at the date of the financial statements, the reported amount of net revenue and expenses and the disclosure of commitments and contingencies during the reporting periods. We base estimates on historical experience and on various assumptions about the future believed to be reasonable based on available information. On an ongoing basis, the Company evaluates its estimates, including those related to revenue recognition, inventory valuation, allocation methods and allocated expenses from Viavi, valuation of goodwill and other intangible assets, stock-based compensation, retirement and post-retirement plan assumptions, restructuring, warranty, valuation of derivative liabilities, and accounting for income taxes. Our reported financial position or results of operations may be materially different under changed conditions or when using different estimates and assumptions, particularly with respect to significant accounting policies. If estimates or assumptions differ from actual results, subsequent periods are adjusted to reflect more current information.

- removed (2017-11-01):
[0001633978-17-000037:note_history:35]
Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are revenue recognition, inventory valuation, allocation methods and allocated expenses from Viavi, valuation of goodwill and other intangible assets, stock-based compensation, retirement and post-retirement plan assumptions, restructuring, warranty, valuation of derivative liabilities, and accounting for income taxes.

- removed (2017-11-01):
[0001633978-17-000037:note_history:36]
There have been no material changes in our significant accounting policies during the nine months ended April 1, 2017 compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 2, 2016. The accompanying unaudited interim consolidated financial statements and accompanying related notes should be read in conjunction with the consolidated financial statements and related notes included in our Annual Report on Form 10-K for the fiscal year ended July 2, 2016.


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-11-01):
[0001633978-17-000119:note_history:37]
As of September 30, 2017, the 2024 Notes consisted of the following (in millions):
  (was, 2017-05-04, similarity 0.9143):
[0001633978-17-000037:note_history:37]
As of April 1, 2017, the Notes consisted of the following (in millions):

- added (2017-11-01):
[0001633978-17-000119:note_history:38]
| Liability component: | September 30, 2017 |  | July 1, 2017 |
| Principal | $ | 450.0 |  |  | $ | 450.0 |  |
| Unamortized debt discount | (128.4 | ) |  | (132.5 | ) |
| Net carrying amount of the liability component | $ | 321.6 |  |  | $ | 317.5 |  |

- removed (2017-11-01):
[0001633978-17-000037:note_history:39]
| Liability component: | April 1, 2017 |
| Principal | $ | 450.0 |  |
| Unamortized debt discount | (136.6 | ) |
| Net carrying amount of the liability component | $ | 313.4 |  |
| Carrying amount of the embedded derivative liability | $ | 168.6 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-11-01):
[0001633978-17-000119:note_history:40]
In March 2017, the Company issued the 2024 Notes in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act of 1933, as amended (the “Securities Act”). The 2024 Notes are governed by an indenture between the Company, as the issuer, and U.S. Bank National Association, as trustee (the “Indenture”). The 2024 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by the Company.
  (was, 2017-05-04, similarity 0.9088):
[0001633978-17-000037:note_history:40]
On March 8, 2017, the Company issued $450.0 million aggregate principal amount of 0.25% Convertible Senior Notes due 2024 (the “Notes”), in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act of 1933, as amended (the “Securities Act”). The Notes are governed by an indenture between the Company, as the issuer, and U.S. Bank National Association, as trustee (the “Indenture”).  The Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by the Company.

- changed (2017-11-01):
[0001633978-17-000119:note_history:41]
The 2024 Notes bear interest at a rate of 0.25% per year. Interest on the 2024 Notes is payable semi-annually in arrears on March 15 and September 15 of each year, beginning on September 15, 2017. The 2024 Notes will mature on March 15, 2024, unless earlier repurchased by the Company or converted pursuant to their terms.
  (was, 2017-05-04, similarity 0.9645):
[0001633978-17-000037:note_history:41]
The Notes will bear interest at a rate of 0.25% per year.  Interest on the Notes is payable semi-annually in arrears on March 15 and September 15 of each year, beginning on September 15, 2017. The Notes will mature on March 15, 2024, unless earlier repurchased by the Company or converted pursuant to their terms.

- changed (2017-11-01):
[0001633978-17-000119:note_history:42]
The initial conversion rate of the 2024 Notes is 16.4965 shares of common stock per $1,000 principal amount of 2024 Notes, which is equivalent to an initial conversion price of approximately $60.62 per share, a 132.5% premium to the fair market value at the date of issuance. Prior to the close of business on the business day immediately preceding December 15, 2023, the 2024 Notes will be convertible only under the following circumstances: (1) during any fiscal quarter (and only during such fiscal quarter), if the last reported sale price of the Company’s common stock for at least 20 trading days (whether or not consecutive) during the period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price on each applicable trading day; (2) during the five consecutive business day period after any five consecutive trading day period (the “measurement period”) in which the trading price per $1,000 principal amount of notes for each trading day of such measurement period was less than 98% of the product of the last reported sale price of the Company’s common stock and the applicable conversion rate on each such trading day; or (3) upon the occurrence of specified corporate events. On or after December 15, 2023 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their notes at any time. In addition, upon the occurrence of a make-whole fundamental change, the Company will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert its 2024 Notes in connection with such make-whole fundamental change.
  (was, 2017-05-04, similarity 0.9902):
[0001633978-17-000037:note_history:42]
The initial conversion rate of the Notes is 16.4965 shares of common stock per $1,000 principal amount of Notes, which is equivalent to an initial conversion price of approximately $60.62 per share, a 132.5% premium to the fair market value at the date of issuance. Prior to the close of business on the business day immediately preceding December 15, 2023, the Notes will be convertible only under the following circumstances: (1) during any fiscal quarter commencing after July 1, 2017 (and only during such fiscal quarter), if the last reported sale price of the Company’s common stock for at least 20 trading days (whether or not consecutive) during the period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price on each applicable trading day; (2) during the five consecutive business day period after any five consecutive trading day period (the “measurement period”) in which the trading price per $1,000 principal amount of notes for each trading day of such measurement period was less than 98% of the product of the last reported sale price of the Company’s common stock and the applicable conversion rate on each such trading day; or (3) upon the occurrence of specified corporate events. On or after December 15, 2023 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their notes at any time. In addition, upon the occurrence of a make-whole fundamental change, the Company will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert its Notes in connection with such make-whole fundamental change.

- changed (2017-11-01):
[0001633978-17-000119:note_history:43]
The Company may not redeem the 2024 Notes prior to their maturity date and no sinking fund is provided for the 2024 Notes. Upon the occurrence of a fundamental change, holders may require the Company to repurchase all or a portion of their 2024 Notes for cash at a price equal to 100% of the principal amount of the 2024 Notes to be repurchased, plus any accrued and unpaid interest.
  (was, 2017-05-04, similarity 0.989):
[0001633978-17-000037:note_history:43]
The Company may not redeem the Notes prior to their maturity date and no sinking fund is provided for the Notes. Upon the occurrence of a fundamental change, holders may require the Company to repurchase all or a portion of their Notes for cash at a price equal to 100% of the principal amount of the Notes to be repurchased, plus any accrued and unpaid interest.

- changed (2017-11-01):
[0001633978-17-000119:note_history:44]
The Company considered the features embedded in the 2024 Notes other than the conversion feature, including the holders’ put feature, the Company’s call feature, and the make-whole feature, and concluded that they are not required to be bifurcated and accounted for separately from the host debt instrument.
  (was, 2017-05-04, similarity 0.9901):
[0001633978-17-000037:note_history:44]
The Company considered the features embedded in the notes other than the conversion feature, including the holders' put feature, the Company's call feature, and the make-whole feature, and concluded that they are not required to be bifurcated and accounted for separately from the host debt instrument.

- changed (2017-11-01):
[0001633978-17-000119:note_history:45]
Prior to the Tax Matters Agreement settlement condition (“TMA settlement condition”), because the Company could only settle the 2024 Notes in cash, the Company determined that the conversion feature met the definition of a derivative liability. The Company separated the derivative liability from the host debt instrument based on the fair value of the derivative liability. As of the issuance date, March 8, 2017, the derivative liability fair value of $129.9 million was calculated using the binomial valuation approach. The residual principal amount of the 2024 Notes of $320.1 million before issuance costs was allocated to the debt component. The Company incurred approximately $7.7 million in transaction costs in connection with the issuance of the 2024 Notes. These costs were allocated to the debt component and recognized as a debt discount. The Company amortizes the debt discount, including both the initial value of the derivative liability and the transaction costs, over the term of the 2024 Notes using the effective interest method. The effective interest rate of the 2024 Notes is 5.4% per year. As of September 30, 2017, the remaining debt discount amortization period was 77 months.
  (was, 2017-05-04, similarity 0.8369):
[0001633978-17-000037:note_history:45]
Because the Company can only settle the notes in cash until the TMA settlement condition is met, the Company determined that the conversion feature meets the definition of a derivative liability.  The Company separated the derivative liability from the host debt instrument based on the fair value of the derivative liability. As of the issuance date, March 8, 2017, the derivative liability fair value of $129.9 million was calculated using the binomial valuation approach. The residual principal amount of the notes of $320.1 million before issuance costs was allocated to the debt component. The Company incurred approximately $7.7 million in transaction costs in connection with the issuance of the notes. These costs were allocated to the debt component and recognized as a debt discount. The Company amortizes the debt discount, including both the initial value of the derivative liability and the transaction costs, over the term of the Notes using the effective interest method. The effective interest rate of the Notes is 5.4% per year. As of April 1, 2017, the remaining debt discount amortization period was 83 months.

- added (2017-11-01):
[0001633978-17-000119:note_history:46]
During year ended July 1, 2017, the Company satisfied the TMA settlement conditions. As such, the value of the conversion option is no longer be marked to market and was reclassified to additional paid-in capital within stockholders’ equity on our condensed consolidated balance sheet. The value of the conversion option at the time of issuance will be treated as an original issue discount for purposes of accounting for the debt component of the notes. The debt component will accrete up to the principal amount over the expected term of the debt. These accounting standards do not affect the actual amount we are required to repay, and the amount shown in the table below for the notes is the aggregate principal amount of the notes and does not reflect the debt discount we will be required to recognize.

- changed (2017-11-01):
[0001633978-17-000119:note_history:47]
As of September 30, 2017, the 2024 Notes consisted of the following (in millions):
  (was, 2017-05-04, similarity 0.9143):
[0001633978-17-000037:note_history:47]
As of April 1, 2017, the Notes consisted of the following (in millions):

- added (2017-11-01):
[0001633978-17-000119:note_history:48]
| Liability component: | September 30, 2017 |  | July 1, 2017 |
| Principal | $ | 450.0 |  |  | $ | 450.0 |  |
| Unamortized debt discount | (128.4 | ) |  | (132.5 | ) |
| Net carrying amount of the liability component | $ | 321.6 |  |  | $ | 317.5 |  |

- added (2017-11-01):
[0001633978-17-000119:note_history:49]
| (in millions, except percentages) | September 30, 2017 |
| Contractual interest expense | $ | 0.3 |  |
| Amortization of the debt discount | 4.1 |  |
| Total interest cost | $ | 4.4 |  |
| Effective interest rate on the liability component | 5.4 | % |

- added (2017-11-01):
[0001633978-17-000119:note_history:50]
The Company has the ability and intent to settle the $450 million face value of the debt in cash. Therefore, the Company will use the treasury stock method for calculating the dilutive impact of the debt. The 2024 Notes will have no impact to diluted earnings per share until the average price of our common stock exceeds the conversion price. The Notes are required to be excluded from the calculation of diluted earnings per share, as they would be anti-dilutive.

- removed (2017-11-01):
[0001633978-17-000037:note_history:51]
Until such time as the Company satisfies the Tax Matters Agreement settlement condition (“TMA settlement condition”, as described below), the Company is required to satisfy its conversion obligation solely in cash.  However, if the Company has satisfied the TMA share settlement condition, the Company may satisfy its conversion obligation in cash, shares of the Company’s common stock or a combination of cash and shares of the Company’s common stock, at the Company’s election.

- removed (2017-11-01):
[0001633978-17-000037:note_history:52]
The TMA settlement condition can be met by the Company either receiving (i) an opinion of a nationally recognized accounting firm selected by the Company and Viavi by mutual consent to the effect that the issuance of the Notes and the shares of Common Stock upon conversion of the Notes (assuming for each such purpose that Physical Settlement applies and the maximum number of Additional Shares have been added to the Conversion Rate) does not result in the imposition or incurrence of certain taxes upon Viavi, the Company, their respective Affiliates or any third party to which any of Viavi, the Company or their respective Affiliates is or may become liable in connection with the failure of the Separation to qualify as a transaction in which no income, gain or loss is recognized under Section 355 and Section 368(A)(1)(D) of the Internal Revenue Code of 1986, as amended (the “Code”) (including any tax resulting from the application of Section 355(d) or Section 355(e) of the Code to the Separation but only to the extent such tax is not reduced by a tax asset) or (ii) the consent of Viavi to the issuance of the Notes and the shares of Common Stock upon conversion of the Notes (assuming for each such purpose that Physical Settlement applies and the maximum number of Additional Shares have been added to the Conversion Rate), in each case, in a manner that the Company has determined satisfies the requirements of the Tax Matters Agreement with Viavi. All capitalized terms not previously defined have the definitions set forth in the Indenture.

- removed (2017-11-01):
[0001633978-17-000037:note_history:53]
| Liability component: | April 1, 2017 |
| Principal | $ | 450.0 |  |
| Unamortized debt discount | (136.6 | ) |
| Net carrying amount of the liability component | $ | 313.4 |  |
| Carrying amount of the embedded derivative liability | $ | 168.6 |  |

- removed (2017-11-01):
[0001633978-17-000037:note_history:54]
The carrying value of the derivative liability related to the Notes as of April 1, 2017 was $168.6 million. Refer to "Note 10. Derivative Liabilities".

- removed (2017-11-01):
[0001633978-17-000037:note_history:55]
|  | Three Months Ended |  | Nine Months Ended |
| (in millions, except percentages) | April 1, 2017 |  | April 2, 2016 |  | April 1, 2017 |  | April 2, 2016 |
| Contractual interest expense | $ | 0.1 |  |  | — |  |  | $ | 0.1 |  |  | — |  |
| Amortization of the debt discount | 1.0 |  |  | — |  |  | 1.0 |  |  | — |  |
| Total interest cost | $ | 1.1 |  |  | — |  |  | $ | 1.1 |  |  | — |  |
| Effective interest rate on the liability component | 5.4 | % |  | — | % |  | 5.4 | % |  | — | % |

- removed (2017-11-01):
[0001633978-17-000037:note_history:56]
The Notes  have no impact to diluted earnings per share during the three and nine months ended April 1, 2017, as the Company has to settle the Notes in cash until the TMA settlement condition is met. If the TMA settlement condition is met, we intend to apply the treasury stock method to determine the potential dilutive effect of the Notes as a result of the Company’s intent and ability to settle the principal amount of the Notes in cash.


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2017-11-01):
[0001633978-17-000119:note_history:57]
The future interest and principal payments related to the 2024 Notes are as follows as of September 30, 2017:

- added (2017-11-01):
[0001633978-17-000119:note_history:58]
| Remainder of 2018 | $ | 0.6 |  |
| 2019 | 1.1 |  |
| 2020 | 1.1 |  |
| 2021 | 1.1 |  |
| 2022 | 1.1 |  |
| Thereafter | 451.7 |  |
| Total 2024 Notes payments | $ | 456.7 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: no_current_note, score: 0.0

- removed (2017-11-01):
[0001633978-17-000037:note_history:59]
Note 3. Related Party Transactions

- removed (2017-11-01):
[0001633978-17-000037:note_history:60]
Transactions with Viavi

- removed (2017-11-01):
[0001633978-17-000037:note_history:61]
During the three and nine months ended April 1, 2017, the Company recognized revenue of $1.0 million and $2.5 million, respectively, from products sold to Viavi. During the three and nine months ended April 2, 2016, the Company recognized revenue of $0.9 million and $2.4 million, respectively, for products sold to Viavi.

- removed (2017-11-01):
[0001633978-17-000037:note_history:62]
During the three and nine months ended April 1, 2017, the Company recorded $0.1 million and $0.5 million, respectively, in research and development cost reimbursement from Viavi. For the three and nine months ended April 2, 2016, the Company recorded $0.5 million and $1.7 million, respectively, in research and development cost reimbursement.

- removed (2017-11-01):
[0001633978-17-000037:note_history:63]
During the three and nine months ended April 1, 2017, the Company recorded $0.2 million and $0.6 million, respectively, in sublease rental income from Viavi. For the three and nine months ended April 2, 2016, the Company recorded and $0.2 million and $0.5 million, respectively, in sublease rental income from Viavi.

- removed (2017-11-01):
[0001633978-17-000037:note_history:64]
As of April 1, 2017 and July 2, 2016, the Company had $0.5 million and $1.1 million, respectively, in trade accounts receivable due from Viavi. The Company did not have any trade payables due to Viavi as of  April 1, 2017 or July 2, 2016.

- removed (2017-11-01):
[0001633978-17-000037:note_history:65]
As of April 1, 2017, the Company had $0.1 million in other payables due to Viavi. As of July 2, 2016, the Company had $2.0 million in other receivables from Viavi. The Company had no other receivables from Viavi as of April 1, 2017 or other payables due to Viavi as of July 2, 2016.

- removed (2017-11-01):
[0001633978-17-000037:note_history:66]
On July 31, 2015, the Company also entered into the following agreements with Viavi:

- removed (2017-11-01):
[0001633978-17-000037:note_history:67]
| a) | Contribution Agreement which identified the assets transferred, the liabilities assumed and the contracts assigned and which provided for when and how these transfers, assumptions and assignments would occur. |

- removed (2017-11-01):
[0001633978-17-000037:note_history:68]
| b) | Separation and Distribution Agreement which governs the Separation of the Lumentum business and other matters related to Lumentum’s relationship with Viavi. |

- removed (2017-11-01):
[0001633978-17-000037:note_history:69]
| c) | Tax Matters Agreement which governs the respective rights, responsibilities and obligations of Lumentum and Viavi with respect to tax liabilities and benefits, attributes, proceedings, returns and certain other tax matters. |

- removed (2017-11-01):
[0001633978-17-000037:note_history:70]
| d) | Employee Matters Agreement which governs the compensation and employee benefit obligations with respect to the current and former employees of Lumentum and Viavi, the treatment of equity based compensation and generally allocates liabilities and responsibilities relating to employee compensation, benefit plans and programs. The Employee Matters Agreement provides that employees of Lumentum will participate in benefit plans sponsored or maintained by Lumentum. |

- removed (2017-11-01):
[0001633978-17-000037:note_history:71]
| e) | Securities Purchase Agreement, which also includes Amada Holdings Co., Ltd. (“Amada”) as a party, which sets forth the terms for the sale by Viavi to Amada of shares of Series A Preferred Stock (the "Series A Preferred Stock") of Lumentum Inc., our wholly-owned subsidiary, following the Separation. |

- removed (2017-11-01):
[0001633978-17-000037:note_history:72]
| f) | Intellectual Property Matters Agreement which outlines the intellectual property rights of Lumentum and Viavi following the Separation, as well as non-compete restrictions between Viavi and Lumentum. |

- removed (2017-11-01):
[0001633978-17-000037:note_history:73]
Allocated Costs

- removed (2017-11-01):
[0001633978-17-000037:note_history:74]
From June 28, 2015 to August 1, 2015, the effective date of the Separation, the consolidated statements of operations included the Company's direct expenses for cost of sales, research and development, sales and marketing, and administration as well as allocations of expenses arising from shared services and infrastructure provided by Viavi to the Company. These allocated expenses include costs of information technology, human resources, accounting, legal, real estate and facilities, corporate marketing, insurance, treasury and other corporate and infrastructure services. In addition, other costs allocated to the Company include restructuring and stock-based compensation related to Viavi’s corporate and shared services employees and are included in the table below. These expenses were allocated to the Company using estimates that we consider to be a reasonable reflection of the utilization of services or benefits received by our business. The allocation methods include revenue, headcount, square footage, actual consumption and usage of services and others.

- removed (2017-11-01):
[0001633978-17-000037:note_history:75]
There were no allocations of expenses from Viavi for the three and nine months ended April 1, 2017, and the three months ended April 2, 2016. During the nine months ended April 2, 2016, allocated costs from Viavi included in the accompanying consolidated statements of operations were as follows (in millions):

- removed (2017-11-01):
[0001633978-17-000037:note_history:76]
|  | Nine Months Ended |
|  | April 2, 2016 |
| Selling, general and administrative expenses | $ | 11.7 |  |
| Interest and other (income) expenses, net | (0.1 | ) |
| Interest expense | 0.1 |  |
| Total allocated expenses | $ | 11.7 |  |


## us-gaap:ScheduleOfRelatedPartyTransactionsTableTextBlock (related_parties) — matched_by: no_current_note, score: 0.0

- removed (2017-11-01):
[0001633978-17-000037:note_history:77]
During the nine months ended April 2, 2016, allocated costs from Viavi included in the accompanying consolidated statements of operations were as follows (in millions):

- removed (2017-11-01):
[0001633978-17-000037:note_history:78]
|  | Nine Months Ended |
|  | April 2, 2016 |
| Selling, general and administrative expenses | $ | 11.7 |  |
| Interest and other (income) expenses, net | (0.1 | ) |
| Interest expense | 0.1 |  |
| Total allocated expenses | $ | 11.7 |  |
