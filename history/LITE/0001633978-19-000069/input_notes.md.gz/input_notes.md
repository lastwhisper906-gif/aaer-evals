# LITE notes — 0001633978-19-000069


## lite:AssetAcquisitionDisclosureTextBlock

[0001633978-19-000069:notes:1]
Note 8. Asset Acquisition

[0001633978-19-000069:notes:2]
On March 30, 2018, we entered into a Transition Services Agreement (“TSA”) with one of our contract manufacturers to wind down the production of our products at their facility in China and to facilitate an orderly transition of manufacturing to either our manufacturing facility in Thailand or our third party contract manufacturers, including the purchase of the manufacturing equipment. Under the terms of the TSA, we are required to pay $5.3 million in cash upon completion of certain milestones related to the purchase of equipment. During the year ended June 29, 2019, we paid $1.3 million and accrued $4.0 million for the manufacturing equipment acquired under this TSA. Entire contract consideration of $5.3 million is included in machinery and equipment within property, plant and equipment in our consolidated balance sheet as of June 29, 2019.

[0001633978-19-000069:notes:3]
We are also required to share cost of retention and severance, and to reimburse for certain other direct and indirect costs incurred by our contract manufacturer for transition services provided. These costs are expensed as incurred. We have now fully exited from operations with this contract manufacturer.


## lite:ConcentrationOfCreditAndOtherRisksAndAllowanceForDoubtfulAccountsPolicyTextBlock

[0001633978-19-000069:notes:4]
Concentration of Credit and Other Risks

[0001633978-19-000069:notes:5]
Financial instruments that potentially subject our business to concentration of credit risk consist primarily of cash and cash equivalents and trade receivables. We perform credit evaluations of our customers’ financial condition and generally do not require collateral from our customers. These evaluations require significant judgment and are based on a variety of factors including, but not limited to, current economic trends, payment history, bad debt write-off experience, and financial review of the customer.

[0001633978-19-000069:notes:6]
Although the Company deposits its cash with financial institutions that management believes are of high credit quality, its deposits, at times, may exceed federally insured limits. The Company’s investment portfolio consists of investment grade securities diversified amongst security types, industries, and issuers. The Company’s investment policy limits the amount of credit exposure in the investment portfolio to a maximum of 5% to any one issuer, except for Treasury and Government Agencies securities, and the Company believes no significant concentration risk exists with respect to these investments.

[0001633978-19-000069:notes:7]
We maintain an allowance for doubtful accounts for estimated losses resulting from the inability of our customers to make required payments. When we become aware that a specific customer is unable to meet their financial obligations, we record a specific allowance to reflect the level of credit risk in the customer’s outstanding receivable balance. In addition, we record additional allowances based on certain percentages of aged receivable balances. These percentages take into account a variety of factors including, but not limited to, current economic trends, payment history and bad debt write-off experience. We classify bad debt expenses as selling, general and administrative (“SG&A”) expense.

[0001633978-19-000069:notes:8]
We have significant trade receivables concentrated in the telecommunications industry. While our allowance for doubtful accounts balance is based on historical loss experience along with anticipated economic trends, unanticipated financial instability in the telecommunications industry could lead to higher than anticipated losses.

[0001633978-19-000069:notes:9]
During fiscal 2019, 2018 and 2017, several customers generated more than 10% of total net revenue. Refer to “Note 20. Operating Segments and Geographic Information” in the Notes to Consolidated Financial Statements.

[0001633978-19-000069:notes:10]
Our accounts receivable was concentrated with three customers as of June 29, 2019, who represented 17%,  17% and 10% of gross accounts receivable, respectively, compared with two customers as of June 30, 2018, who represented 11% and 10% of gross accounts receivable, respectively.

[0001633978-19-000069:notes:11]
We rely on a limited number of suppliers for a number of key components contained in our products. We also rely on a limited number of significant independent contract manufacturers for the production of certain key components and subassemblies contained in our products.

[0001633978-19-000069:notes:12]
We generally use a rolling twelve months forecast based on anticipated product orders, customer forecasts, product order history and backlog to determine our materials requirements. Lead times for the parts and components that we order vary significantly and depend on factors such as the specific supplier, contract terms and demand for a component at a given time. If the forecast does not meet or if it exceeds actual demand, we may have excess or shortfalls of some materials and components, as well as excess inventory purchase commitments. We could experience reduced or delayed product shipments or incur additional inventory write-downs and cancellation charges or penalties, which would increase costs and could have a material adverse impact on our results of operations.


## lite:NoncontrollingInterestAndDerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001633978-19-000069:notes:13]
Note 12. Non-Controlling Interest Redeemable Convertible Preferred Stock and Derivative Liability

[0001633978-19-000069:notes:14]
On July 31, 2015, our wholly-owned subsidiary, Lumentum Inc., issued 40,000 shares of its Series A Preferred Stock to Viavi Solutions Inc. (“Viavi”). Pursuant to a securities purchase agreement between us, Viavi and Amada Holdings Co., Ltd. (“Amada”), 35,805 shares of Series A Preferred Stock were sold by Viavi to Amada in August 2015. The remaining 4,195 shares of the Series A Preferred Stock were canceled.

[0001633978-19-000069:notes:15]
As of June 30, 2018, the Series A Preferred Stock was referred to as our Non-Controlling Interest Redeemable Convertible Preferred Stock within these consolidated financial statements, and was recorded at $35.8 million.

[0001633978-19-000069:notes:16]
On October 15, 2018, we issued a 30-day notice of intent to the holders of Series A Preferred Stock to convert all shares of Series A Preferred Stock at a conversion price equal to the Issuance Value divided by $24.63 plus the accrued and unpaid dividends on each share and any past due dividends, whether or not authorized or declared. On November 2, 2018, we received notice from Amada of their intent to convert the Series A Preferred Stock. Upon the conversion of the 35,805 shares of Series A Preferred Stock, we issued 1.5 million shares of our common stock to Amada and recorded $79.4 million in additional paid in capital in the consolidated balance sheet.

[0001633978-19-000069:notes:17]
Up through the date of conversion, the Series A Preferred Stock conversion feature is bifurcated from the Series A Preferred Stock and accounted for separately as a derivative liability. The derivative liability is measured at fair value each reporting period, and at the date of conversion, with the change in fair value recorded in the consolidated statements of operations. We estimated the fair value of the embedded derivative using the binomial lattice model. We applied the binomial lattice model to value the embedded derivative using a “with-and-without method,” where the value of the Series A Preferred Stock, including the embedded derivative, is defined as the “with”, and the value of the Series A Preferred Stock, excluding the embedded derivative, is defined as the “without”. The binomial lattice model requires the following inputs: (i) the Company's common stock price; (ii) conversion price; (iii) term; (iv) yield; (v) recovery rate for the Series A Preferred Stock; (vi) estimated stock volatility; and (vii) risk-free rate. The fair value of the embedded derivative was determined using Level 3 inputs under the fair value hierarchy (unobservable inputs). Changes in the inputs into this valuation model have a material impact in the estimated fair value of the embedded derivative. For example, a decrease (increase) in the stock price and the volatility results in a decrease (increase) in the estimated fair value of the embedded derivative. The changes in the fair value of the bifurcated embedded derivative for the Series A Preferred Stock are primarily related to the change in the price of our common stock and are reflected in the consolidated statements of operations as “Unrealized gain (loss) on derivative liability.”

[0001633978-19-000069:notes:18]
Up through the date of conversion, holders of Series A Preferred Stock, in preference to holders of common stock or any other class or series of our outstanding capital stock ranking in any such event junior to the Series A Preferred Stock, were entitled to receive, when and as declared by the board of directors, quarterly cumulative cash dividends at the annual rate of 2.5% of the Issuance Value per share on each outstanding share of Series A Preferred Stock. The accrued dividends were payable on March 31, June 30, September 30 and December 31 of each year commencing on September 30, 2015. The accrued dividends as of November 2, 2018, the effective date of the conversion of all outstanding Series A Preferred Stock, and June 30, 2018 were $0.3 million and $0.4 million, respectively.

[0001633978-19-000069:notes:19]
During the years ended June 29, 2019, June 30, 2018, and July 1, 2017, we paid $0.7 million, $0.7 million, and $0.9 million, respectively, in dividends to the holders of Series A Preferred Stock.

[0001633978-19-000069:notes:20]
Prior to the conversion of the Series A Preferred Stock on November 2, 2018, we marked to market the embedded derivative, resulting in a gain of $8.8 million in our fiscal 2019.

[0001633978-19-000069:notes:21]
The following table provides a reconciliation of the fair value of the embedded derivative for the Series A Preferred Stock for the years ended June 29, 2019, June 30, 2018, and July 1, 2017 (in millions):

[0001633978-19-000069:notes:22]
|  | Years Ended |
|  | June 29, 2019 |  | June 30, 2018 |  | July 1, 2017 |
| Balance as of beginning of period | $ | 52.4 |  |  | $ | 51.6 |  |  | $ | 10.3 |  |
| Unrealized (gain) loss on the Series A Preferred Stock derivative liability up through the conversion date | (8.8 | ) |  | 0.8 |  |  | 41.3 |  |
| Settlement of the derivative liability upon conversion of Series A Preferred Stock | (43.6 | ) |  | — |  |  | — |  |
| Balance as of end of period | $ | — |  |  | $ | 52.4 |  |  | $ | 51.6 |  |


## lite:ScheduleOfAssetImpairmentChargesTableTextBlock

[0001633978-19-000069:notes:23]
The following table summarizes the activity of  impairment charges during the years ended June 29, 2019, June 30, 2018, and July 1, 2017 (in millions):

[0001633978-19-000069:notes:24]
|  | Years Ended |
|  | June 29, 2019 |  | June 30, 2018 |  | July 1, 2017 |
| Impairment charges | $ | 30.7 |  |  | $ | — |  |  | $ | — |  |


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001633978-19-000069:notes:25]
SCHEDULE II - VALUATION AND QUALIFYING ACCOUNTS

[0001633978-19-000069:notes:26]
|  | (in millions) |
|  | Balance atBeginningof Period |  | Assumed in Oclaro Acquisition |  | Increase (decrease) toIncome Statement |  | WriteOffs and Other Adjustments |  | Balanceat End ofPeriod |
| Accounts receivable allowance: |  |  |  |  |  |  |  |  |  |
| Fiscal year ended June 29, 2019 | $ | 2.6 |  |  | $ | 3.3 |  |  | $ | (0.2 | ) |  | $ | (1.2 | ) |  | $ | 4.5 |  |
| Fiscal year ended June 30, 2018 | $ | 1.8 |  |  | $ | — |  |  | $ | 0.9 |  |  | $ | (0.1 | ) |  | $ | 2.6 |  |
| Fiscal year ended July 1, 2017 | $ | 0.9 |  |  | $ | — |  |  | $ | 1.0 |  |  | $ | (0.1 | ) |  | $ | 1.8 |  |

[0001633978-19-000069:notes:27]
|  |  | (in millions) |
| Description |  | Balance at Beginning of Period |  | Additions Charged to Expenses or Other Accounts* |  | Deductions Credited to Expenses or Other Accounts** |  | Balance at End of Period |
| Deferred tax valuation allowance: |  |  |  |  |  |  |  |  |
| Fiscal year ended June 29, 2019 |  | $ | 99.4 |  |  | $ | 153.9 |  |  | $ | (63.0 | ) |  | $ | 190.3 |  |
| Fiscal year ended June 30, 2018 |  | $ | 296.4 |  |  | $ | 234.1 |  |  | $ | (431.1 | ) |  | $ | 99.4 |  |
| Fiscal year ended July 1, 2017 |  | $ | 321.4 |  |  | $ | 16.7 |  |  | $ | (41.7 | ) |  | $ | 296.4 |  |

[0001633978-19-000069:notes:28]
*    Additions include current year additions charged to expenses and current year build due to increases in net deferred tax assets, return to provision true-ups, other adjustments to deferred taxes.

[0001633978-19-000069:notes:29]
**    Deductions include current year releases credited to expenses and current year reductions due to decreases in net deferred tax assets, return to provision true-ups, other adjustments to deferred taxes.


## us-gaap:AssetImpairmentChargesTextBlock

[0001633978-19-000069:notes:30]
Note 15. Impairment Charges

[0001633978-19-000069:notes:31]
As was previously discussed in “Note 14. Restructuring and Related Charges”, we have announced plans to discontinue the development and manufacturing of future Datacom transceiver products. As a result of these actions we recorded an impairment charge of $30.7 million to our Long-lived assets that were not deemed to be useful, were retired from active use and classified as assets held-for-sale. These assets were valued at fair value less cost to sell. We classified the assets within Level 3 of the fair value hierarchy.

[0001633978-19-000069:notes:32]
In fiscal 2019, we also recorded inventory write down charges of $20.8 million related to the decision to exit the Datacom module and Lithium Niobate product lines in our cost of goods sold of consolidated statements of operations.

[0001633978-19-000069:notes:33]
These actions do not qualify as discontinued operations for disclosure purposes as they do not represent a strategic shift having a major effect on an entity’s operations and financial results.

[0001633978-19-000069:notes:34]
Refer to “Note 5. Business Combination”, “Note 9. Balance Sheet Details”, “Note 11. Fair Value Measurements” and “Note 14. Restructuring and Related Charges” for details.


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001633978-19-000069:notes:35]
Basis of Presentation

[0001633978-19-000069:notes:36]
The preparation of the consolidated financial statements in accordance with U.S. generally accepted accounting principles (“GAAP”) requires management to make estimates and assumptions that affect the amounts reported in our consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates. Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are inventory valuation, revenue recognition, income taxes, long-lived asset valuation, business combinations, and goodwill.

[0001633978-19-000069:notes:37]
On December 10, 2018, we completed our merger with Oclaro, Inc. (“Oclaro”), a provider of optical components and modules for the long-haul, metro and data center markets. Our consolidated financial statements include the operating results of Oclaro for the period from the date of acquisition through June 29, 2019. Refer to “Note 5. Business Combination” for further discussion of the merger.


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0001633978-19-000069:notes:38]
The unaudited supplemental pro forma financial information for the periods presented is as follows (in millions):

[0001633978-19-000069:notes:39]
|  | Years Ended |
|  | June 29, 2019 |  | June 30, 2018 |
| Net revenue | $ | 1,779.4 |  |  | $ | 1,790.9 |  |
| Net income | 21.5 |  |  | 156.2 |  |


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001633978-19-000069:notes:40]
Note 1. Description of Business and Summary of Significant Accounting Policies

[0001633978-19-000069:notes:41]
Description of Business

[0001633978-19-000069:notes:42]
Lumentum (“we,” “us,” “our” or the “Company”) is an industry-leading provider of optical and photonic products defined by revenue and market share addressing a range of end market applications including Optical Communications (“OpComms”) and Lasers for manufacturing, inspection and life-science applications. We seek to use our core optical and photonic technology and our volume manufacturing capability to expand into attractive emerging markets that benefit from advantages that optical or photonics based solutions provide, including 3D sensing for consumer electronics and diode light sources for a variety of consumer and industrial applications. The majority of our customers tend to be Original Equipment Manufacturers (“OEMs”) that incorporate our products into their products which then address end-market applications. For example, we sell fiber optic components that Network Equipment Manufacturers’ (“NEMs”) customers assemble into communications networking systems, which they sell to network service providers or enterprises with their own networks. Similarly, many of our customers for our Lasers products incorporate our products into tools they produce, which are used for manufacturing processes by their customers. For 3D sensing, we sell diode lasers to manufacturers of consumer electronics products for mobile, personal computing, and gaming who then integrate our devices within their products, for eventual resale to consumers and also into other industrial applications.

[0001633978-19-000069:notes:43]
Fiscal Years

[0001633978-19-000069:notes:44]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Our fiscal 2019 and 2018 ended on June 29, 2019 and June 30, 2018, respectively, and were 52-week years. Our fiscal 2017 ended on July 1, 2017 and was a 53-week year.

[0001633978-19-000069:notes:45]
Principles of Consolidation

[0001633978-19-000069:notes:46]
The preparation of the consolidated financial statements in accordance with GAAP in the United States requires management to make estimates and assumptions that affect the amounts reported in our consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates.

[0001633978-19-000069:notes:47]
Certain prior period amounts have been reclassified to conform to the current year presentation. For fiscal 2018, we have reclassified $20.5 million of capitalized manufacturing overhead from prepayments and other current assets to inventory work in process to conform to current period presentation. Refer to “Note 9. Balance Sheet Details”.

[0001633978-19-000069:notes:48]
Related Party Transactions

[0001633978-19-000069:notes:49]
Since October 2017, all transactions with Viavi were no longer related party transactions, as Viavi held less than 5% of our total shares outstanding. During fiscal year 2017, we recognized revenue of $3.6 million from products sold to Viavi, recorded $0.5 million in research and development cost reimbursement, and $0.7 million in sublease rental income. During fiscal year 2017, we also recorded $0.6 million in other income, which resulted from a tax indemnification agreement between Lumentum and Viavi.

[0001633978-19-000069:notes:50]
Summary of Significant Accounting Policies

[0001633978-19-000069:notes:51]
Our significant accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. We believe that of our significant accounting policies described below, certain accounting policies involve a greater degree of judgment and complexity and are the most critical to aid in fully understanding and evaluating our consolidated financial statements. These policies are inventory valuation, revenue recognition, income taxes, long-lived asset valuation, business combinations, and goodwill. During fiscal year 2019, we removed valuation of derivative liability from the list of critical accounting policies and estimates due to the conversion of the Series A Preferred Stock to common stock on November 2, 2018. Refer to “Note 12. Non-Controlling Interest Redeemable Convertible Preferred Stock and Derivative Liability” for more details. For a description of our critical accounting policies, also refer to “Management’s Discussion and Analysis of Financial Condition and Results of Operations”, Critical Accounting Policies and Estimates.

[0001633978-19-000069:notes:52]
Cash and Cash Equivalents

[0001633978-19-000069:notes:53]
We consider highly-liquid fixed income securities with original maturities of three months or less at the time of purchase to be cash equivalents. As of fiscal year ended June 29, 2019, cash and cash equivalents mainly consist of commercial papers, money market funds, and U.S. Treasury securities. As of fiscal year ended June 30, 2018, our cash and cash equivalents did not include any investments with original maturities of three months or less.

[0001633978-19-000069:notes:54]
Short-term Investments

[0001633978-19-000069:notes:55]
We classify our investments in debt as available-for-sale and record these investments at fair value. Investments with an original maturity of three months or less at the date of purchase are considered cash equivalents, while all other investments are classified as short-term based on management’s intent and ability to use the funds in current operations. Unrealized gains and losses are reported as a component of other comprehensive loss. Realized gains and losses are determined based on the specific identification method, and are reflected as interest and other income (expense), net in our Consolidated Statements of Operations. We regularly review our investment portfolio to identify and evaluate investments that have indicators of possible impairment. Factors considered in determining whether a loss is other-than-temporary include, but are not limited to: the length of time and extent a security’s fair value has been below its cost, the financial condition and near-term prospects of the investee, the credit quality of the security’s issuer, likelihood of recovery and our intent and ability to hold the security for a period of time sufficient to allow for any anticipated recovery in value. For our debt instruments, we also evaluate whether we have the intent to sell the security or it is more likely than not that we will be required to sell the security before recovery of its cost basis.

[0001633978-19-000069:notes:56]
Impairment of Marketable and Non-Marketable Securities

[0001633978-19-000069:notes:57]
We periodically review our marketable and non-marketable securities for impairment. If we conclude that any of these investments are impaired, we determine whether such impairment is other-than-temporary. We consider factors such as the duration, severity and the reason for the decline in value, the potential recovery period and whether we intend to sell. For marketable debt securities, we also consider whether (i) it is more likely than not that we will be required to sell the debt securities before recovery of their amortized cost basis, and (ii) the amortized cost basis cannot be recovered as a result of credit losses. If any impairment is considered other-than-temporary, we will write-down the security to its fair value.

[0001633978-19-000069:notes:58]
Fair Value of Financial Instruments

[0001633978-19-000069:notes:59]
We define fair value as the price that would be received from selling an asset, or paid to transfer a liability, in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities which are required to be recorded at fair value, we consider the principal or most advantageous market in which to transact and the market-based risk. We apply fair value accounting for all financial assets and liabilities that are recognized or disclosed at fair value in the financial statements on a recurring basis. The carrying amounts reported in the consolidated financial statements approximate the fair value for cash and cash equivalents, accounts receivable, accounts payable and accrued liabilities due to their short-term nature.

[0001633978-19-000069:notes:60]
Basic and Diluted Net Income (Loss) per Common Share

[0001633978-19-000069:notes:61]
Basic income (loss) per share is computed by dividing net income (loss) available to common stockholders by the weighted average number of common shares outstanding during the reporting period. The weighted average number of shares is calculated by taking the number of shares outstanding and weighting them by the amount of time that they were outstanding.  Diluted earnings per share reflects the potential dilution that could occur if stock options, preferred stock, and other commitments to issue common stock were exercised or equity awards vest resulting in the issuance of common stock that could share in the earnings of the Company.

[0001633978-19-000069:notes:62]
Diluted loss per share is the same as basic loss per share during periods where net losses are incurred since the inclusion of the potential common stock equivalents would be anti-dilutive as a result of the net loss.

[0001633978-19-000069:notes:63]
Our Series A Preferred Stock was considered a participating security where the holders of Series A Preferred Stock had the right to participate in undistributed earnings with holders of common stock.  On November 2, 2018, the remaining 35,805 shares of our Series A Preferred Stock were converted into 1.5 million shares of our common stock. Refer to “Note 12. Non-Controlling Interest Redeemable Convertible Preferred Stock and Derivative Liability” for further discussion. Prior to conversion, the holders of our Series A Preferred Stock were entitled to share in dividends, on an as-converted basis, if the holders of our common stock were to receive dividends. Up through the date of conversion, we used the two-class method to compute earnings per share. The two-class method is an earnings allocation formula that determines earnings per share for each class of common stock and participating security according to dividends declared (or accumulated) and participation rights in undistributed earnings. In determining the amount of net earnings to allocate to common stockholders, earnings are allocated to both common and participating securities based on their respective weighted-average shares outstanding during the period. Diluted earnings per common share is calculated similar to basic earnings per common share except that it gives effect to all potentially dilutive common stock equivalents outstanding for the period, using the treasury stock method.

[0001633978-19-000069:notes:64]
In March 2017, we issued $450 million in aggregate principal amount of 0.25% Convertible Senior Notes due in 2024 (the “2024 Notes”). We have the ability and intent to settle the $450 million face value of the 2024 Notes in cash. Therefore, we use the treasury stock method for calculating the dilutive impact of the 2024 Notes. The 2024 Notes will have no impact to diluted earnings per share until the average price of our common stock exceeds the conversion price of $60.62. Refer to “Note 13. Convertible Notes” for details.

[0001633978-19-000069:notes:65]
The dilutive effect of securities from the 2015 Equity Incentive Plan is reflected in diluted earnings per share by application of the treasury stock method, which includes consideration of unamortized share-based compensation expense and the dilutive effect of in-the-money options and non-vested restricted stock units. Under the treasury stock method, the amount the employee must pay for exercising stock options and the amount of unamortized share-based compensation expense are collectively assumed to be used to repurchase hypothetical shares. An increase in the fair value of our common stock can result in a greater dilutive effect from potentially dilutive awards.

[0001633978-19-000069:notes:66]
Anti-dilutive potential shares from 2015 Equity Incentive Plan are excluded from the calculation of diluted earnings per share if their exercise price exceeded the average market price during the period or the share-based awards were determined to be anti-dilutive based on applying the treasury stock method.

[0001633978-19-000069:notes:67]
Inventory Valuation

[0001633978-19-000069:notes:68]
Inventory is valued at standard cost, which approximates actual cost computed on a first-in, first-out basis, not in excess of net realizable value. We assess the value of our inventory on a quarterly basis and write down those inventories which are obsolete or in excess of our forecasted usage to the lower of their cost or estimated net realizable value. Our estimates of realizable value are based upon our analysis and assumptions including, but not limited to, forecasted sales levels and historical usage by product, expected product lifecycle, product development plans and future demand requirements. Our product line management personnel play a key role in our excess review process by providing updated sales forecasts, managing product transitions and working with manufacturing to minimize excess inventory. If actual market conditions are less favorable than our forecasts or actual demand from our customers is lower than our estimates, we may be required to record additional inventory write-downs. If actual market conditions are more favorable than anticipated, inventory previously written down may be sold, resulting in lower cost of sales and higher income from operations than expected in that period.

[0001633978-19-000069:notes:69]
Revenue Recognition

[0001633978-19-000069:notes:70]
Adoption of Topic 606

[0001633978-19-000069:notes:71]
Pursuant to Topic 606, our revenues are recognized upon the application of the following steps:

[0001633978-19-000069:notes:72]
| • | identification of the contract, or contracts, with a customer; |

[0001633978-19-000069:notes:73]
| • | identification of the performance obligations in the contract; |

[0001633978-19-000069:notes:74]
| • | determination of the transaction price; |

[0001633978-19-000069:notes:75]
| • | allocation of the transaction price to the performance obligations in the contract; and |

[0001633978-19-000069:notes:76]
| • | recognition of revenues when, or as, the contractual performance obligations are satisfied. |

[0001633978-19-000069:notes:77]
The majority of our revenue comes from product sales, consisting of sales of Lasers and OpComms hardware products to our customers. Our revenue contracts generally include only one performance obligation. Revenues are recognized at a point in time when control of the promised goods or services are transferred to our customers upon shipment or delivery, in an amount that reflects the consideration we expect to be entitled to in exchange for those goods or services. We have entered into vendor managed inventory (“VMI”) programs with our customers. Under these arrangements, we receive purchase orders from our customers, and the inventory is shipped to the VMI location upon receipt of the purchase order. The customer then pulls the inventory from the VMI hub based on its production needs. Revenue under VMI programs is recognized when control transfers to the customer, which is generally once the customer pulls the inventory from the hub.

[0001633978-19-000069:notes:78]
Revenue from all sales types is recognized at the transaction price. The transaction price is determined based on the consideration to which we will be entitled in exchange for transferring goods or services to the customer adjusted for estimated variable consideration, if any. We typically estimate the impact on the transaction price for discounts offered to the customers for early payments on receivables or net of accruals for estimated sales returns. These estimates are based on historical returns, analysis of credit memo data and other known factors. Actual returns could differ from these estimates. We allocate the transaction price to each distinct product based on its relative standalone selling price. The product price as specified on the purchase order is considered the standalone selling price as it is an observable input that depicts the price as if sold to a similar customer in similar circumstances.

[0001633978-19-000069:notes:79]
Taxes assessed by a governmental authority that are both imposed on and concurrent with a specific revenue-producing transaction, that are collected by us from a customer and deposited with the relevant government authority, are excluded from revenue. Our revenue arrangements do not contain significant financing components as our standard payment terms are less than one year.

[0001633978-19-000069:notes:80]
If a customer pays consideration, or the Company has a right to an amount of consideration that is unconditional before we transfer a good or service to the customer, those amounts are classified as deferred revenue or deposits received from customers which are included in other current liabilities or other long-term liabilities when the payment is made or it is due, whichever is earlier.

[0001633978-19-000069:notes:81]
Transaction Price Allocated to the Remaining Performance Obligations

[0001633978-19-000069:notes:82]
Remaining performance obligations represent the transaction price allocated to performances obligations that are unsatisfied or partially unsatisfied as of the end of the reporting period. Unsatisfied and partially unsatisfied performance obligations consist of contract liabilities and non-cancellable backlog. Non-cancellable backlog includes goods and services for which customer purchase orders have been accepted that are scheduled or in the process of being scheduled for shipment. A portion of our revenue arises from vendor managed inventory arrangements where the timing and volume of customer utilization is difficult to predict.

[0001633978-19-000069:notes:83]
The following table includes estimated revenue expected to be recognized in the future for backlog related performance obligations that are unsatisfied as of June 29, 2019 (in millions):

[0001633978-19-000069:notes:84]
|  | Less than 1 year | 1-2 years | Greater than 2 years | Total |
| Performance Obligations | $446.1 | $7.0 | $— | $453.1 |

[0001633978-19-000069:notes:85]
Warranty

[0001633978-19-000069:notes:86]
Hardware products regularly include warranties to the end customers such that the product continues to function according to published specifications. We typically offer a twelve month warranty for most of our products. However, in some instances depending upon the product, specific market, product line and geography in which we operate, and what is common in the industry, our warranties can vary and range from six months to five years. These standard warranties are assurance type warranties and do not offer any services in addition to the assurance that the product will continue working as specified. Therefore, warranties are not considered separate performance obligations in the arrangement. Instead, the expected cost of warranty is accrued as expense in accordance with authoritative guidance.

[0001633978-19-000069:notes:87]
We provide reserves for the estimated costs of product warranties at the time revenue is recognized. We estimate the costs of our warranty obligations based on our historical experience of known product failure rates, use of materials to repair or replace defective products and service delivery costs incurred in correcting product failures. In addition, from time to time, specific warranty accruals may be made if unforeseen technical problems arise.

[0001633978-19-000069:notes:88]
Shipping and Handling Costs

[0001633978-19-000069:notes:89]
We record shipping and handling costs related to revenue transactions within cost of sales as a period cost.

[0001633978-19-000069:notes:90]
Contract Costs

[0001633978-19-000069:notes:91]
The Company recognizes the incremental direct costs of obtaining a contract, which consist of sales commissions, when control over the products they relate to transfers to the customer. Applying the practical expedient, the Company recognizes commissions as expense when incurred, as the amortization period of the commission asset the Company would have otherwise recognized is less than one year.

[0001633978-19-000069:notes:92]
Contract Balances

[0001633978-19-000069:notes:93]
The Company records accounts receivable when it has an unconditional right to consideration. Contract liabilities are recorded when cash payments are received or due in advance of performance. Contract liabilities consist of advance payments and deferred revenue, where the Company has unsatisfied performance obligations. Contract liabilities are classified as deferred revenue and customer deposits, and are included in other current liabilities within our consolidated balance sheet. Payment terms vary by customer. The time between invoicing and when payment is due is not significant.

[0001633978-19-000069:notes:94]
The following table reflects the changes in contract balances as of June 29, 2019 (in millions, except percentages):

[0001633978-19-000069:notes:95]
| Contract balances | Balance sheet location | June 29, 2019 |  | June 30, 2018 |  | Change |  | Percentage Change |
| Accounts receivable, net | Accounts receivable, net | $238.0 |  | $197.1 |  | $40.9 |  | 20.8% |
| Deferred revenue and customer deposits | Other current liabilities | $2.9 |  | $2.8 |  | $0.1 |  | 3.6% |

[0001633978-19-000069:notes:96]
Disaggregation of Revenue

[0001633978-19-000069:notes:97]
We disaggregate revenue by geography and by product. Refer to “Note 20. Operating Segments and Geographic Information” for a presentation of disaggregated revenue. We do not present other levels of disaggregation, such as by type of products, customer, markets, contracts, duration of contracts, timing of transfer of control and sales channels, as this information is not used by our Chief Operating Decision Maker to manage the business.

[0001633978-19-000069:notes:98]
Income Taxes

[0001633978-19-000069:notes:99]
In accordance with the authoritative guidance on accounting for income taxes, we recognize income taxes using an asset and liability approach. This approach requires the recognition of taxes payable or refundable for the current year and deferred tax liabilities and assets for the future tax consequences of events that have been recognized in our consolidated financial statements or tax returns. The measurement of current and deferred taxes is based on provisions of the enacted tax law, and the effects of future changes in tax laws or rates are not anticipated.

[0001633978-19-000069:notes:100]
The authoritative guidance provides for recognition of deferred tax assets if the realization of such deferred tax assets is more likely than not to occur based on an evaluation of both positive and negative evidence and the relative weight of the evidence. We consider future growth, forecasted earnings, future taxable income, the mix of earnings in the jurisdictions in which we operate, historical earnings, taxable income in prior years, if carryback is permitted under the law, and prudent and feasible tax planning strategies in determining the need for a valuation allowance. In the event we were to determine that we would not be able to realize all or part of our net deferred tax assets in the future, an adjustment to the deferred tax assets valuation allowance would be charged to earnings in the period in which we make such a determination, or goodwill would be adjusted at our final determination of the valuation allowance related to an acquisition within the measurement period. If we later determine that it is more likely than not that the net deferred tax assets would be realized, we would reverse the applicable portion of the previously provided valuation allowance as an adjustment to earnings at such time.

[0001633978-19-000069:notes:101]
We are subject to income tax audits by the respective tax authorities of the jurisdictions in which we operate. The determination of our income tax liabilities in each of these jurisdictions requires the interpretation and application of complex, and sometimes uncertain, tax laws and regulations. The authoritative guidance on accounting for income taxes prescribes both recognition and measurement criteria that must be met for the benefit of a tax position to be recognized in the financial statements.  If a tax position taken, or expected to be taken, in a tax return does not meet such recognition or measurement criteria, an unrecognized tax benefit liability is recorded.  If we ultimately determine that an unrecognized tax benefit liability is no longer necessary, we reverse the liability and recognize a tax benefit in the period in which it is determined that the unrecognized tax benefit liability is no longer necessary.

[0001633978-19-000069:notes:102]
The recognition and measurement of current taxes payable or refundable and deferred tax assets and liabilities requires that we make certain estimates and judgments. Changes to these estimates or a change in judgment may have a material impact on our tax provision in a future period.

[0001633978-19-000069:notes:103]
Property, Plant and Equipment

[0001633978-19-000069:notes:104]
Property, plant and equipment are stated at cost. Depreciation is computed by the straight-line method generally over the following estimated useful lives of the assets: 10 to 40 years for building and improvements, 3 to 5 years for machinery and equipment, and 2 to 5 years for furniture, fixtures, software and office equipment. Leasehold improvements are amortized using the straight-line method over the shorter of the estimated useful lives of the assets or the term of the lease.

[0001633978-19-000069:notes:105]
Goodwill

[0001633978-19-000069:notes:106]
Goodwill represents the excess of the purchase price of an acquired business over the fair value of the identifiable assets acquired and liabilities assumed. We test for impairment of goodwill on an annual basis in the fourth quarter and at any other time when events occur or circumstances indicate that the carrying amount of goodwill may not be recoverable.

[0001633978-19-000069:notes:107]
An entity has the option to first assess qualitative factors to determine whether it is necessary to perform the two-step quantitative goodwill impairment test. If an entity determines that as a result of the qualitative assessment that it is more likely than not (i.e., greater than 50% likelihood) that the fair value of a reporting unit is less than its carrying amount, then the quantitative test is required. Otherwise, no further testing is required. The two-step quantitative goodwill impairment test requires us to estimate the fair value of our reporting units. If the carrying value of a reporting unit exceeds its fair value, the goodwill of that reporting unit is potentially impaired and we proceed to step two of the impairment analysis. In step two of the analysis, we measure and record an impairment loss equal to the excess of the carrying value of the reporting unit’s goodwill over its implied fair value, if any.

[0001633978-19-000069:notes:108]
Application of the goodwill impairment test requires judgments, including: identification of the reporting units, assigning assets and liabilities to reporting units, assigning goodwill to reporting units, a qualitative assessment to determine whether there are any impairment indicators, and determining the fair value of each reporting unit. We estimate the fair value of a reporting unit using market approach, income approach or a combination of market and income approach. Significant estimates in the market approach include: identifying similar companies with comparable business factors such as size, growth, profitability, risk and return on investment, and assessing comparable revenue and operating income multiples in estimating the fair value of the reporting unit. Significant estimates in the income approach include: future cash flows, discount rates.

[0001633978-19-000069:notes:109]
We base our estimates on historical experience and on various assumptions about the future that we believe are reasonable based on available information. Unanticipated events and circumstances may occur that affect the accuracy of our assumptions, estimates and judgments. For example, if the price of our common stock were to significantly decrease combined with other adverse changes in market conditions, thus indicating that the underlying fair value of our reporting units may have decreased, we might be required to reassess the value of our goodwill in the period such circumstances were identified.

[0001633978-19-000069:notes:110]
Based on the impairment analysis performed in the fourth quarter of each year presented, the fair value of our reporting unit substantially exceeded the carrying value; as such, our annual qualitative assessment did not indicate that a more detailed quantitative analysis was necessary.

[0001633978-19-000069:notes:111]
Intangible Assets

[0001633978-19-000069:notes:112]
Intangible assets consist primarily of intangible assets purchased through acquisitions. Purchased intangible assets include acquired developed technologies (developed and core technology), customer relationships, in-process research and development, and order backlog. Intangible assets, with the exception of customer relationships and order backlog, are amortized using the straight-line method over the estimated economic useful lives of the assets, which is the period during which expected cash flows support the fair value of such intangible assets. Customer relationships and order backlog are amortized using an accelerated method of amortization over the expected customer lives, which more accurately reflects the pattern of realization of economic benefits expected to be obtained.

[0001633978-19-000069:notes:113]
Long-lived Asset Valuation

[0001633978-19-000069:notes:114]
We test long-lived assets for recoverability, at the asset group level, when events or changes in circumstances indicate that their carrying amount may not be recoverable. Circumstances which could trigger a review include, but are not limited to: significant decreases in the market price of the asset, significant adverse changes in the business climate or legal factors, accumulation of costs significantly in excess of the amount originally expected for the acquisition or construction of the asset, current period cash flow or operating losses combined with a history of losses or a forecast of continuing losses associated with the use of the asset, or current expectation that the asset will more likely than not be sold or disposed significantly before the end of its estimated useful life.

[0001633978-19-000069:notes:115]
Recoverability is assessed based on the difference between the carrying amount of the asset and the sum of the undiscounted cash flows expected to result from the use and the eventual disposal of the asset. An impairment loss is recognized when the carrying amount is not recoverable and exceeds fair value.

[0001633978-19-000069:notes:116]
Pension Benefits

[0001633978-19-000069:notes:117]
The funded status of our retirement-related benefit plan is measured as the difference between the fair value of plan assets and the benefit obligation at fiscal year end, the measurement date. The funded status of an underfunded benefit plan, of which the fair value of plan assets is less than the benefit obligation, is recognized as a non-current net pension liability in the consolidated balance sheets unless the fair value of plan assets is not sufficient to cover the expected payments to be made over the next year (or operating cycle, if longer) from the measurement date. For defined benefit pension plans, the benefit obligation is the projected benefit obligation (“PBO”) which represents the actuarial present value of benefits expected to be paid upon retirement.

[0001633978-19-000069:notes:118]
Net periodic pension cost (income) (“NPPC”) is recorded in the consolidated statements of operations and includes service cost, interest cost, expected return on plan assets, amortization of prior service cost and (gains) losses previously recognized as a component of accumulated other comprehensive income. Service cost represents the actuarial present value of participant benefits attributed to services rendered by employees in the current year. Interest cost represents the time value of money cost associated with the passage of time. (Gains) losses arise as a result of differences between actual experience and assumptions or as a result of changes in actuarial assumptions. Prior service cost (credit) represents the cost of benefit improvements attributable to prior service granted in plan amendments. (Gains) losses and prior service cost (credit) that arise during the current year are first recognized as a component of accumulated other comprehensive income in the consolidated balances sheets, net of tax. Prior service cost is amortized as a component of NPPC over the average remaining service period of active plan participants starting at the date the plan amendment is adopted. Deferred actuarial (gains) losses are subsequently recognized as a component of NPPC if they exceed the greater of 10% of PBO or the fair value of plan assets, with the excess amortized over the average remaining service period of active plan participants.

[0001633978-19-000069:notes:119]
The measurement of the benefit obligation and NPPC is based on our estimates and actuarial valuations, provided by third-party actuaries, which are approved by management. These valuations reflect the terms of the plans and use participant-specific information such as compensation, age and years of service, as well as certain assumptions, including estimates of discount rates, expected return on plan assets, rate of compensation increases, and mortality rates. We evaluate these assumptions annually at a minimum. In estimating the expected return on plan assets, we consider historical returns on plan assets, adjusted for forward-looking considerations, inflation assumptions and the impact of the active management of the plan’s invested assets.

[0001633978-19-000069:notes:120]
Foreign Currency Translation

[0001633978-19-000069:notes:121]
Concurrent with the acquisition of Oclaro on December 10, 2018, we established the functional currency for our worldwide operations as the U.S. dollar. The change in our functional currency is a result of significant changes in economic facts and circumstances, primarily the acquisition of Oclaro, a U.S. dollar-denominated functional currency company. The combined business, which requires the integration of our supply chain, manufacturing operations and sales organization, will predominantly use the U.S. dollar, including when negotiating customer and major supplier contracts.

[0001633978-19-000069:notes:122]
Translation adjustments reported prior to December 10, 2018, remain as a component of accumulated other comprehensive income in our consolidated balance sheet. The translated values for any non-monetary assets and liabilities as of December 10, 2018 become the new accounting basis for those assets. Accordingly, monetary assets and liabilities denominated in foreign currencies have been remeasured into U.S. dollars using the exchange rates in effect at the balance sheet date. Foreign currency re-measurement gains (losses) are included in interest and other income (expense), net.

[0001633978-19-000069:notes:123]
Stock-based Compensation

[0001633978-19-000069:notes:124]
Compensation expense related to stock-based transactions is measured and recognized in the financial statements based on fair value at the grant date.

[0001633978-19-000069:notes:125]
Restricted stock units (“RSUs”) are grants of shares of our common stock, the vesting of which is based on the requisite service requirement. Generally, our RSUs are subject to forfeiture and expected to vest over one to four years. For new-hire grants, RSUs generally vest ratably on an annual basis over four years. For annual refresh grants, RSUs generally vest ratably on an annual, or combination of annual and quarterly, basis over three years.

[0001633978-19-000069:notes:126]
Restricted stock awards (“RSAs”) are grants of shares of our common stock that are subject to various restrictions, including restrictions on transferability and forfeiture provisions. RSAs are expected to vest over one to four years, and the shares acquired may not be transferred by the holder until the vesting conditions (if any) are satisfied.

[0001633978-19-000069:notes:127]
Performance stock units (“PSUs”) are grants of shares of our common stock that vest upon the achievement of certain performance and service conditions. We account for the fair value of PSUs using the closing market price of our common stock on the date of grant. We begin recognizing compensation expense when we conclude that it is probable that the performance conditions will be achieved. We reassess the probability of vesting at each reporting period and adjust our compensation cost based on this probability assessment. Our PSUs are subject to risk of forfeiture until performance and service conditions are satisfied and generally vest over three years.

[0001633978-19-000069:notes:128]
We estimate the fair value of the rights to acquire stock under our 2015 Employee Stock Purchase Plan (the “2015 Purchase Plan”) using the Black-Scholes option pricing formula. Our 2015 Purchase Plan provides for consecutive six-month offering periods. We recognize such compensation expense on a straight-line basis over the requisite service period. We calculate the volatility factor based on our historical stock prices.

[0001633978-19-000069:notes:129]
Restructuring Accrual

[0001633978-19-000069:notes:130]
Costs associated with restructuring activities are recognized when they are obligated. However, in the case of leases, the expense is estimated and accrued when the property is vacated. Given the significance of, and the timing of the execution of such activities, this process is complex and involves periodic reassessments of estimates made from the time the property was vacated, including evaluating real estate market conditions for expected vacancy periods and sub-lease income. We recognize a liability for post-employment benefits for workforce reductions related to restructuring activities when payment is probable and the amount is reasonably estimable. We continually evaluate the adequacy of the remaining liabilities under our restructuring initiatives. Although we believe that these estimates accurately reflect the costs of our restructuring plans, actual results may differ, thereby requiring us to record additional provisions or reverse a portion of such provisions. Refer to “Note 14. Restructuring and Related Charges” in the Notes to Consolidated Financial Statements.

[0001633978-19-000069:notes:131]
Business Combinations

[0001633978-19-000069:notes:132]
In accordance with the guidance for business combinations, we determine whether a transaction or other event is a business combination, which requires that the assets acquired and liabilities assumed constitute a business. Each business combination is then accounted for by applying the acquisition method. If the assets acquired are not a business, we account for the transaction or other event as an asset acquisition. Under both methods, we recognize the identifiable assets acquired, the liabilities assumed, and any noncontrolling interest in the acquired entity. We capitalize acquisition-related costs and fees associated with asset acquisitions and immediately expense acquisition-related costs and fees associated with business combinations.

[0001633978-19-000069:notes:133]
We allocate the fair value of purchase consideration to the tangible assets acquired, liabilities assumed and intangible assets acquired based on their estimated fair values. The excess of the fair value of purchase consideration over the fair values of these identifiable assets and liabilities is recorded as goodwill. When determining the fair values of assets acquired and liabilities assumed, we make significant estimates and assumptions, especially with respect to intangible assets. Critical estimates in valuing certain intangible assets include, but are not limited to, future expected cash flows from customer relationships and acquired developed technology and discount rates. Our estimates of fair value are based upon assumptions believed to be reasonable, but which are inherently uncertain and unpredictable and, as a result, actual results may differ materially from estimates. Other estimates associated with the accounting for acquisitions may change as additional information becomes available regarding the assets acquired and liabilities assumed. Any change in facts and circumstances that existed as of the acquisition date and impacts our preliminary estimates is recorded to goodwill if identified within the measurement period. Subsequent to the measurement period or our final determination of fair value of assets and liabilities whichever is earlier the adjustments will affect our earnings.

[0001633978-19-000069:notes:134]
In addition, we estimate the economic lives of certain acquired assets and these lives are used to calculate depreciation and amortization expense. If our estimates of the economic lives change, depreciation or amortization expenses could be accelerated or slowed.

[0001633978-19-000069:notes:135]
Research and Development (“R&D”) Expense

[0001633978-19-000069:notes:136]
Costs related to R&D, which primarily consists of labor and benefits, supplies, facilities, consulting and outside service fees, are charged to expense as incurred.

[0001633978-19-000069:notes:137]
Loss Contingencies

[0001633978-19-000069:notes:138]
We are subject to the possibility of various loss contingencies arising in the ordinary course of business. We consider the likelihood of loss or impairment of an asset or the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss in determining loss contingencies. An estimated loss is accrued when it is probable that an asset has been impaired or a liability has been incurred and the amount of loss can be reasonably estimated. We regularly evaluate current information available to determine whether such accruals should be adjusted and whether new accruals are required.

[0001633978-19-000069:notes:139]
Asset Retirement Obligations (“ARO”)

[0001633978-19-000069:notes:140]
Our ARO are legal obligations associated with the retirement of long-lived assets pertaining to leasehold improvements. These liabilities are initially recorded at fair value and the related asset retirement costs are capitalized by increasing the carrying amount of the related assets by the same amount as the liability. Asset retirement costs are subsequently depreciated over the useful lives of the related assets. Subsequent to initial recognition, we record period-to-period changes in the ARO liability resulting from the passage of time and revisions to either the timing or the amount of the original estimate of undiscounted cash flows. We derecognize ARO liabilities when the related obligations are settled.


## us-gaap:CashCashEquivalentsAndShortTermInvestmentsTextBlock

[0001633978-19-000069:notes:141]
Note 10. Cash, Cash Equivalents and Short-term Investments

[0001633978-19-000069:notes:142]
The following table summarizes our cash, cash equivalents and short-term investments by category for the periods presented (in millions):

[0001633978-19-000069:notes:143]
|  | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| June 29, 2019: |  |  |  |  |  |  |  |
| Cash | $ | 213.8 |  |  | $ | — |  |  | $ | — |  |  | $ | 213.8 |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | 37.4 |  |  | — |  |  | — |  |  | 37.4 |  |
| Money market funds | 168.1 |  |  | — |  |  | — |  |  | 168.1 |  |
| U.S. Treasury securities | 13.3 |  |  | — |  |  | — |  |  | 13.3 |  |
| Total cash and cash equivalents | $ | 432.6 |  |  | $ | — |  |  | $ | — |  |  | $ | 432.6 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 1.9 |  |  | $ | — |  |  | $ | — |  |  | $ | 1.9 |  |
| Commercial paper | 22.3 |  |  | — |  |  | — |  |  | 22.3 |  |
| Asset-backed securities | 54.9 |  |  | 0.2 |  |  | — |  |  | 55.1 |  |
| Corporate debt securities | 207.6 |  |  | 0.9 |  |  | (0.1 | ) |  | 208.4 |  |
| Municipal bonds | 1.3 |  |  | — |  |  | — |  |  | 1.3 |  |
| Mortgage-backed securities | 6.6 |  |  | — |  |  | — |  |  | 6.6 |  |
| Foreign government bonds | 6.2 |  |  | — |  |  | — |  |  | 6.2 |  |
| U.S. Agency securities | 4.6 |  |  | — |  |  | — |  |  | 4.6 |  |
| U.S. Treasury securities | 29.4 |  |  | 0.1 |  |  | — |  |  | 29.5 |  |
| Total short-term investments | $ | 334.8 |  |  | $ | 1.2 |  |  | $ | (0.1 | ) |  | $ | 335.9 |  |
| June 30, 2018: |  |  |  |  |  |  |  |
| Cash | $ | 103.6 |  |  | $ | — |  |  | $ | — |  |  | $ | 103.6 |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | 3.0 |  |  | — |  |  | — |  |  | 3.0 |  |
| Commercial paper | 112.1 |  |  | — |  |  | — |  |  | 112.1 |  |
| Money market funds | 0.8 |  |  | — |  |  | — |  |  | 0.8 |  |
| U.S. Treasury securities | 143.6 |  |  | — |  |  | — |  |  | 143.6 |  |
| U.S. Agency securities | 34.2 |  |  | — |  |  | — |  |  | 34.2 |  |
| Total cash and cash equivalents | $ | 397.3 |  |  | $ | — |  |  | $ | — |  |  | $ | 397.3 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 7.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 7.5 |  |
| Commercial paper | 10.5 |  |  | — |  |  | — |  |  | 10.5 |  |
| Asset-backed securities | 68.0 |  |  | — |  |  | (0.2 | ) |  | 67.8 |  |
| Corporate debt securities | 220.6 |  |  | 0.1 |  |  | (1.5 | ) |  | 219.2 |  |
| Municipal bonds | 1.6 |  |  | — |  |  | — |  |  | 1.6 |  |
| Mortgage-backed securities | 4.2 |  |  | — |  |  | — |  |  | 4.2 |  |
| Foreign government bonds | 3.4 |  |  | — |  |  | — |  |  | 3.4 |  |
| Total short-term investments | $ | 315.8 |  |  | $ | 0.1 |  |  | $ | (1.7 | ) |  | $ | 314.2 |  |

[0001633978-19-000069:notes:144]
We use the specific-identification method to determine any realized gains or losses from the sale of our short-term investments classified as available-for-sale. During fiscal 2019, 2018 and 2017, we did not realize significant gains or losses on a gross level from the sale of our short-term investments classified as available-for-sale.

[0001633978-19-000069:notes:145]
During fiscal 2019, 2018 and 2017, our other income (expense), net was $15.8 million, $8.5 million, and $2.3 million, respectively, and includes interest income on cash equivalents and short-term investments of $13.9 million, $8.5 million, and $1.1 million, respectively.

[0001633978-19-000069:notes:146]
The components of other income (expense), net are as follows for the years presented (in millions):

[0001633978-19-000069:notes:147]
|  | Years Ended |
|  | June 29, 2019 |  | June 30, 2018 |  | July 1, 2017 |
| Foreign exchange gains (losses), net | (0.6 | ) |  | (0.3 | ) |  | 0.6 |  |
| Interest income | 13.9 |  |  | 8.5 |  |  | 1.1 |  |
| Other income (expense), net | 2.5 |  |  | 0.3 |  |  | 0.6 |  |
| Total other income (expense), net | $ | 15.8 |  |  | $ | 8.5 |  |  | $ | 2.3 |  |

[0001633978-19-000069:notes:148]
The following table summarizes unrealized losses on our cash equivalents and short-term investments by category and length of time the investment has been in a continuous unrealized loss position as of the periods presented (in millions):

[0001633978-19-000069:notes:149]
|  | Less than 12 months |  | 12 Months or Greater |  | Total |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| June 29, 2019: |  |  |  |  |  |  |  |  |  |  |  |
| Commercial paper | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Asset-backed securities | 4.2 |  |  | — |  |  | 5.9 |  |  | — |  |  | 10.1 |  |  | — |  |
| Corporate debt securities | 9.6 |  |  | — |  |  | 35.9 |  |  | (0.1 | ) |  | 45.5 |  |  | (0.1 | ) |
| Foreign government bonds | — |  |  | — |  |  | 2.1 |  |  | — |  |  | 2.1 |  |  | — |  |
| U.S. government bonds | 6.9 |  |  | — |  |  | — |  |  | — |  |  | 6.9 |  |  | — |  |
| Total | $ | 20.7 |  |  | $ | — |  |  | $ | 43.9 |  |  | $ | (0.1 | ) |  | $ | 64.6 |  |  | $ | (0.1 | ) |
| June 30, 2018: |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 5.4 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 5.4 |  |  | $ | — |  |
| Commercial paper | 8.5 |  |  | — |  |  | — |  |  | — |  |  | 8.5 |  |  | — |  |
| Asset-backed securities | 66.6 |  |  | (0.2 | ) |  | 0.3 |  |  | — |  |  | 66.9 |  |  | (0.2 | ) |
| Corporate debt securities | 188.6 |  |  | (1.5 | ) |  | 2.0 |  |  | — |  |  | 190.6 |  |  | (1.5 | ) |
| Municipal bonds | 0.6 |  |  | — |  |  | — |  |  | — |  |  | 0.6 |  |  | — |  |
| U.S. Agency securities | 4.0 |  |  | — |  |  | — |  |  | — |  |  | 4.0 |  |  | — |  |
| Foreign government bonds | 3.4 |  |  | — |  |  | — |  |  | — |  |  | 3.4 |  |  | — |  |
| Total | $ | 277.1 |  |  | $ | (1.7 | ) |  | $ | 2.3 |  |  | $ | — |  |  | $ | 279.4 |  |  | $ | (1.7 | ) |

[0001633978-19-000069:notes:150]
The following table classifies our short-term investments by contractual maturities (in millions):

[0001633978-19-000069:notes:151]
|  | June 29, 2019 |  | June 30, 2018 |
|  | Amortized Cost |  | Fair Value |  | Amortized Cost |  | Fair Value |
| Due in 1 year | $ | 178.9 |  |  | $ | 179.1 |  |  | $ | 150.1 |  |  | $ | 149.6 |  |
| Due in 1 year through 5 years | 148.1 |  |  | 149.0 |  |  | 157.2 |  |  | 156.1 |  |
| Due in 5 years through 10 years | 6.0 |  |  | 6.0 |  |  | 6.1 |  |  | 6.1 |  |
| Due after 10 years | 1.8 |  |  | 1.8 |  |  | 2.4 |  |  | 2.4 |  |
|  | $ | 334.8 |  |  | $ | 335.9 |  |  | $ | 315.8 |  |  | $ | 314.2 |  |

[0001633978-19-000069:notes:152]
All available-for-sale securities have been classified as current, based on management’s intent and ability to use the funds in current operations.


## us-gaap:CashProceedsReceivedAndTaxBenefitFromShareBasedPaymentAwardsTableTextBlock

[0001633978-19-000069:notes:153]
Total income tax benefit associated with stock-based compensation recognized in our consolidated statements of operations during the years presented was as follows (in millions):

[0001633978-19-000069:notes:154]
|  | Years Ended |
|  | June 29, 2019 |  | June 30, 2018 |  | July 1, 2017 |
| Income tax benefit associated with stock-based compensation | $ | (8.9 | ) |  | $ | (16.6 | ) |  | $ | (13.1 | ) |


## us-gaap:ChangesInProjectedBenefitObligationsFairValueOfPlanAssetsAndFundedStatusOfPlanTableTextBlock

[0001633978-19-000069:notes:155]
The change in the benefit obligations and plan assets of the Switzerland Plan were as follows (in millions):

[0001633978-19-000069:notes:156]
|  | 2019 |  | 2018 |
| Change in projected benefit obligation: |  |  |  |
| Benefit obligation at beginning of year | $ | 12.1 |  |  | $ | 11.0 |  |
| Service cost | 0.9 |  |  | 0.9 |  |
| Interest cost | 0.1 |  |  | 0.1 |  |
| Plan participants’ contribution | 0.5 |  |  | 0.5 |  |
| Actuarial (gains)/losses | 1.1 |  |  | (0.3 | ) |
| Benefits paid | (1.0 | ) |  | 0.4 |  |
| Plan amendments | (0.6 | ) |  | — |  |
| Foreign exchange impact | 0.2 |  |  | (0.5 | ) |
| Benefit obligation at end of year | $ | 13.3 |  |  | $ | 12.1 |  |
| Change in plan assets: |  |  |  |
| Fair value of plan assets at beginning of year | $ | 8.6 |  |  | $ | 7.1 |  |
| Actual return on plan assets | (0.3 | ) |  | 0.3 |  |
| Employer contribution | 0.4 |  |  | 0.5 |  |
| Plan participants’ contribution | 0.4 |  |  | 0.5 |  |
| Benefits paid | (1.0 | ) |  | 0.4 |  |
| Foreign exchange impact | 0.2 |  |  | (0.2 | ) |
| Fair value of plan assets at end of year | $ | 8.3 |  |  | $ | 8.6 |  |
| Funded status (1) | $ | (5.0 | ) |  | $ | (3.5 | ) |
| Changes in benefit obligations and plan assets recognized in other comprehensive income (loss): |  |  |  |
| Prior service cost | $ | (0.6 | ) |  | $ | — |  |
| Amortization of accumulated net actuarial gain (loss) | (0.1 | ) |  | (0.2 | ) |
| Net actuarial (gain) loss | 1.9 |  |  | (0.4 | ) |
|  | $ | 1.2 |  |  | $ | (0.6 | ) |
| Accumulated benefit obligation | $ | 11.6 |  |  | $ | 11.0 |  |

[0001633978-19-000069:notes:157]
(1) As of June 29, 2019 and June 30, 2018, $5.0 million and $3.5 million was recorded in other non-current liabilities on our consolidated balance sheets to account for the PBO under the Switzerland Plan. Refer to “Note 9. Balance Sheet Details” in the Notes to Consolidated Financial Statements.

[0001633978-19-000069:notes:158]
The change in the benefit obligations of the Japan Plan were as follows (in millions):

[0001633978-19-000069:notes:159]
|  | 2019 |
| Change in projected benefit obligation: |  |
| Benefit obligation at beginning of year | $ | — |  |
| Assumed pension liability in connection with Oclaro acquisition | 7.2 |  |
| Service cost | 0.3 |  |
| Actuarial losses | 0.1 |  |
| Benefits paid | (0.1 | ) |
| Transfer of benefit obligation in connection with sale of net assets | (4.9 | ) |
| Foreign exchange impact | 0.2 |  |
| Benefit obligation at end of year | $ | 2.8 |  |
| Changes in benefit obligations recognized in other comprehensive income (loss): |  |
| Net actuarial loss | $ | 0.2 |  |
| Accumulated benefit obligation at end of year | $ | 2.8 |  |


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0001633978-19-000069:notes:160]
Note 19. Commitments and Contingencies

[0001633978-19-000069:notes:161]
Operating Leases

[0001633978-19-000069:notes:162]
We lease certain real and personal property from unrelated third parties under non-cancellable operating leases that expire at various dates through fiscal 2033. Certain leases require us to pay property taxes, insurance and routine maintenance, and include escalation clauses.

[0001633978-19-000069:notes:163]
As of June 29, 2019, the total future minimum annual lease payments under non-cancellable operating leases, net of sublease income, were as follows (in millions):

[0001633978-19-000069:notes:164]
| Fiscal Years |  |
| 2020 | $ | 13.9 |  |
| 2021 | 12.1 |  |
| 2022 | 11.2 |  |
| 2023 | 11.3 |  |
| 2024 | 9.8 |  |
| Thereafter | 31.7 |  |
| Total minimum operating lease payments (1) | $ | 90.0 |  |

[0001633978-19-000069:notes:165]
(1) As of June 29, 2019, we sublease a floor of office space in our Ottawa location that is not fully utilized. Under this sublease, we will receive approximately $2.1 million in sublease income over the next four years. In addition, as part of our sale to CIG (refer to “Note 5. Business Combination”), we sublease certain portions of the building until fiscal 2022, which will result in $4.5 million in sublease income over the contract term. The amounts set forth in the table above are net of these sublease income amounts.

[0001633978-19-000069:notes:166]
In fiscal 2019, 2018 and 2017, rental expense relating to building and equipment was $15.8 million, $12.1 million and $10.1 million, respectively. Non-cancellable sublease proceeds from our subleases were approximately $1.0 million, $0.7 million, and $0.7 million, respectively, during the fiscal years 2019, 2018, and 2017. The amounts of our rental expense for the years presented are net of these sublease income amounts.

[0001633978-19-000069:notes:167]
Capital Leases

[0001633978-19-000069:notes:168]
As of June 29, 2019, equipment acquired under capital lease agreements, including those assumed as part of the Oclaro acquisition, was $16.0 million. Our capital lease assets are included in property, plant and equipment, net in our consolidated balance sheets as of June 29, 2019. Amortization expense on these capital lease assets are recorded as depreciation expense and is included in cost of sales in our consolidated statements of operations for fiscal 2019, 2018, and 2017. Our capital lease obligations are recorded at the lesser of the estimated fair market value of the leased property or the net present value of the aggregate future minimum lease payments and is included in other current liabilities and other non-current liabilities in our consolidated balance sheets as of June 29, 2019. Refer to “Note 9. Balance Sheet Details” for capital lease obligation amounts in other current liabilities and other non-current liabilities. Interest on these obligations is included in interest expense in our consolidated statements of operations.

[0001633978-19-000069:notes:169]
As of June 29, 2019, the future minimum annual lease payments under our capital leases were $0.8 million, which we expect to pay within the following fiscal year.

[0001633978-19-000069:notes:170]
Acquisition Contingencies

[0001633978-19-000069:notes:171]
In February 2017, we incurred liabilities in the amount of $3.6 million related to an acquisition of a privately held company. The amount of up to $3.0 million is expected to be paid within the following 12 months contingent upon meeting certain production targets. We estimated the likelihood of meeting the production targets at 90 percent and recorded $2.7 million as fair value of contingent consideration in other current liabilities on the consolidated balance sheet as of June 29, 2019.

[0001633978-19-000069:notes:172]
We also retained $0.9 million of the purchase price as security for any potential liabilities of the seller under the representations, warranties and indemnifications included in the purchase agreement, which resulted in the cash payment of $1.0 million to the seller during fiscal 2019 (based on exchange rate at the date of transaction).

[0001633978-19-000069:notes:173]
Term Loan

[0001633978-19-000069:notes:174]
The estimated future interest and principal payments related to the term loan are as follows as of June 29, 2019:

[0001633978-19-000069:notes:175]
| Fiscal Years |  |
| 2020 | $ | 29.2 |  |
| 2021 | 29.0 |  |
| 2022 | 28.7 |  |
| 2023 | 28.6 |  |
| 2024 | 28.2 |  |
| Thereafter | 505.6 |  |
| Total term loan payments | $ | 649.3 |  |

[0001633978-19-000069:notes:176]
0.25% Convertible Notes due 2024

[0001633978-19-000069:notes:177]
The future interest and principal payments related to the 2024 Notes are as follows as of June 29, 2019:

[0001633978-19-000069:notes:178]
| Fiscal Years |  |
| 2020 | $ | 1.1 |  |
| 2021 | 1.1 |  |
| 2022 | 1.1 |  |
| 2023 | 1.1 |  |
| 2024 | 451.2 |  |
| Thereafter | — |  |
| Total 2024 Notes payments | $ | 455.6 |  |

[0001633978-19-000069:notes:179]
Purchase Obligations

[0001633978-19-000069:notes:180]
Purchase obligations of $216.4 million as of June 29, 2019, represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements.

[0001633978-19-000069:notes:181]
Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule and adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

[0001633978-19-000069:notes:182]
We depend on a limited number of contract manufacturers, subcontractors and suppliers for raw materials, packages and standard components. We generally purchase these single or limited source products through standard purchase orders or one-year supply agreements and have no significant long-term guaranteed supply agreements with such vendors. While we seek to maintain a sufficient safety stock of such products and maintain on-going communications with our suppliers to guard against interruptions or cessation of supply, our business and results of operations could be adversely affected by a stoppage or delay of supply, substitution of more expensive or less reliable products, receipt of defective parts or contaminated materials, increases in the price of such supplies, or our inability to obtain reduced pricing from our suppliers in response to competitive pressures.

[0001633978-19-000069:notes:183]
Product Warranties

[0001633978-19-000069:notes:184]
We provide reserves for the estimated costs of product warranties at the time revenue is recognized. We typically offer a twelve month warranty for most of our products. However, in some instances depending upon the product, product component or application of our products by the end customer, our warranties can vary and generally range from six months to five years. We estimate the costs of our warranty obligations on an annualized basis based on our historical experience of known product failure rates, use of materials to repair or replace defective products and service delivery costs incurred in correcting product failures. In addition, from time to time, specific warranty accruals may be made if unforeseen technical problems arise with specific products. We assess the adequacy of our recorded warranty liabilities and adjust the amounts as necessary.

[0001633978-19-000069:notes:185]
The following table presents the changes in our warranty reserve during fiscal 2019 and 2018 (in millions):

[0001633978-19-000069:notes:186]
|  | Years Ended |
|  | June 29, 2019 |  | June 30, 2018 |
| Balance as of beginning of period | $ | 6.6 |  |  | $ | 9.7 |  |
| Warranties assumed in Oclaro acquisition (1) | 1.8 |  |  | — |  |
| Provision for warranty (2) | 5.9 |  |  | 5.0 |  |
| Utilization of reserve | (6.8 | ) |  | (8.1 | ) |
| Balance as of end of period | $ | 7.5 |  |  | $ | 6.6 |  |

[0001633978-19-000069:notes:187]
(1) The amount is reduced by $2.0 million measurement period adjustment recorded in other current liabilities on our consolidated balance sheet in the fourth quarter of fiscal 2019. Refer to “Note 5. Business Combination”.

[0001633978-19-000069:notes:188]
(2) In fiscal 2018, the provision for warranty does not include a settlement payment of $5.1 million received from a vendor for a quality issue.

[0001633978-19-000069:notes:189]
Environmental Liabilities

[0001633978-19-000069:notes:190]
Our research and development (“R&D”), manufacturing and distribution operations involve the use of hazardous substances and are regulated under international, federal, state and local laws governing health and safety and the environment. We apply strict standards for protection of the environment and occupational health and safety to sites inside and outside the United States, even if not subject to regulations imposed by foreign governments. We believe that our properties and operations at our facilities comply in all material respects with applicable environmental laws and occupational health and safety laws. However, the risk of environmental liabilities cannot be completely eliminated and there can be no assurance that the application of environmental and health and safety laws will not require us to incur significant expenditures. We are also regulated under a number of international, federal, state and local laws regarding recycling, product packaging and product content requirements. The environmental, product content/disposal and recycling laws are gradually becoming more stringent and may cause us to incur significant expenditures in the future.

[0001633978-19-000069:notes:191]
Legal Proceedings

[0001633978-19-000069:notes:192]
We are subject to a variety of claims and suits that arise from time to time in the ordinary course of our business. While management currently believes that resolving claims against us, individually or in the aggregate, will not have a material adverse impact on our financial position, results of operations or statements of cash flows, these matters are subject to inherent uncertainties and management’s view of these matters may change in the future. We accrue for loss contingencies when it is both probable that we will incur the loss and when we can reasonably estimate the amount of the loss or range of loss. As of June 29, 2019, we did not have any material claims or proceedings that were probable or reasonably possible.

[0001633978-19-000069:notes:193]
Merger Litigation

[0001633978-19-000069:notes:194]
In connection with our acquisition of Oclaro, seven lawsuits were filed by purported stockholders of Oclaro challenging the proposed merger (the “Merger”). Two of the seven suits were putative class actions filed against Oclaro, its directors, Lumentum, Prota Merger Sub, Inc. and Prota Merger, LLC: Nicholas Neinast v. Oclaro, Inc., et al., No. 3:18-cv-03112-VC, in the United States District Court for the Northern District of California (filed May 24, 2018) (the “Neinast Lawsuit”); and Adam Franchi v. Oclaro, Inc., et al., No. 1:18-cv-00817-GMS, in the United States District Court for the District of Delaware (filed June 9, 2018) (the “Franchi Lawsuit). Both the Neinast Lawsuit and the Franchi Lawsuit were voluntarily dismissed with prejudice.

[0001633978-19-000069:notes:195]
The other five suits, styled as Gerald F. Wordehoff v. Oclaro, Inc., et al., No. 5:18-cv-03148-NC (the “Wordehoff Lawsuit”), Walter Ryan v. Oclaro, Inc., et al., No. 3:18-cv-03174-VC (the “Ryan Lawsuit”), Jayme Walker v. Oclaro, Inc., et al., No. 5:18-cv-03203-EJD (the “Walker Lawsuit”), Kevin Garcia v. Oclaro, Inc., et al., No. 5:18-cv-03262-VKD (the “Garcia Lawsuit”), and SaiSravan B. Karri v. Oclaro, Inc., et al., No. 3:18-cv-03435-JD (the “Karri Lawsuit” and, together with the other six lawsuits, the “Lawsuits”), were filed in the United States District Court for the Northern District of California on May 25, 2018, May 29, 2018, May 30, 2018, May 31, 2018, and June 9, 2018, respectively. These five Lawsuits named Oclaro and its directors as defendants only and did not name Lumentum. The Wordehoff, Ryan, Walker, and Garcia Lawsuits have been voluntarily dismissed, and the Wordehoff, Ryan, and Walker dismissals were with prejudice. The Karri Lawsuit has not yet been dismissed. The Ryan Lawsuit was, and the Karri Lawsuit is, a putative class action.

[0001633978-19-000069:notes:196]
The Lawsuits generally alleged, among other things, that Oclaro and its directors violated Section 14(a) of the Securities Exchange Act of 1934, as amended (the “Exchange Act”), and Rule 14a-9 promulgated thereunder by disseminating an incomplete and misleading Form S-4, including proxy statement/prospectus. The Lawsuits further alleged that Oclaro’s directors violated Section 20(a) of the Exchange Act by failing to exercise proper control over the person(s) who violated Section 14(a) of the Exchange Act.

[0001633978-19-000069:notes:197]
The remaining Lawsuit (the Karri Lawsuit) currently purports to seek, among other things, damages to be awarded to the plaintiff and any class if the Merger is consummated, and litigation costs, including attorneys’ fees. The defendants intend to defend the Karri Lawsuit vigorously.

[0001633978-19-000069:notes:198]
Indemnifications

[0001633978-19-000069:notes:199]
In the normal course of business, we enter into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown because claims may be made against us in the future and we may record charges in the future as a result of these indemnification obligations. As of June 29, 2019, we did not have any material indemnification claims that were probable or reasonably possible.

[0001633978-19-000069:notes:200]
Audit Proceedings

[0001633978-19-000069:notes:201]
We are under audit by various domestic and foreign tax authorities with regards to income tax and indirect tax matters. In some, although not all cases, we have reserved for potential adjustments to our provision for income taxes and accrual of indirect taxes that may result from examinations by these tax authorities or final outcomes in judicial proceedings, and we believe that the final outcome of these examinations, agreements or judicial proceedings will not have a material effect on our results of operations. If events occur which indicate payment of these amounts is unnecessary, the reversal of the liabilities would result in the recognition of benefits in the period we determine the liabilities are no longer necessary. If our estimates of the federal, state, and foreign income tax liabilities and indirect tax liabilities are less than the ultimate assessment, it could result in a further charge to expense.

[0001633978-19-000069:notes:202]
In connection with our acquisition of Oclaro, we recorded $1.1 million in Malaysia Goods and Services Tax (“GST”) refund claims within prepaid expenses and other current assets in our consolidated balance sheet at June 29, 2019. The refund claim represents an initial claim of $2.5 million of GST, net of reserves, that were previously denied by the Malaysian tax authorities in 2016. We are currently appealing the denial of these claims, and believe that additional options may be available to us if we do not obtain a favorable resolution. Although we have taken action to minimize the impact of the GST with respect to our ongoing operations, we believe it is reasonably possible that, ultimately, we may not be able to recover some of these GST amounts.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001633978-19-000069:notes:203]
Note 4. Accumulated Other Comprehensive Income (Loss)

[0001633978-19-000069:notes:204]
Our accumulated other comprehensive income (loss) consists of the accumulated net unrealized gains or losses on foreign currency translation adjustments, the defined benefit obligations, and available-for-sale securities.

[0001633978-19-000069:notes:205]
As of June 29, 2019 and June 30, 2018, balances for the components of accumulated other comprehensive income (loss) were as follows (in millions):

[0001633978-19-000069:notes:206]
|  | Foreign currency translation adjustments, net of tax |  | Defined benefit obligations, net of tax (1) |  | Unrealized gain (loss) on available-for-sale securities, net of tax |  | Total |
| Beginning balance as of July 2, 2016 | $ | 11.7 |  |  | $ | (2.3 | ) |  | $ | — |  |  | $ | 9.4 |  |
| Other comprehensive income (loss) | (1.2 | ) |  | (0.8 | ) |  | — |  |  | (2.0 | ) |
| Beginning balance as of July 1, 2017 | 10.5 |  |  | (3.1 | ) |  | — |  |  | 7.4 |  |
| Other comprehensive income (loss) | (0.2 | ) |  | 0.8 |  |  | (1.6 | ) |  | (1.0 | ) |
| Ending balance as of June 30, 2018 | 10.3 |  |  | (2.3 | ) |  | (1.6 | ) |  | 6.4 |  |
| Other comprehensive income (loss) | (0.6 | ) |  | (1.2 | ) |  | 2.5 |  |  | 0.7 |  |
| Ending balance as of June 29, 2019 | $ | 9.7 |  |  | $ | (3.5 | ) |  | $ | 0.9 |  |  | $ | 7.1 |  |

[0001633978-19-000069:notes:207]
(1) Refer to “Note 18. Employee Benefit Plans” in the Notes to Consolidated Financial Statements on the computation of net periodic cost for pension plans.


## us-gaap:ConvertibleDebtTableTextBlock

[0001633978-19-000069:notes:208]
The 2024 Notes consisted of the following components as of the periods presented (in millions):

[0001633978-19-000069:notes:209]
| Liability component: | June 29, 2019 |  | June 30, 2018 |
| Principal | $ | 450.0 |  |  | $ | 450.0 |  |
| Unamortized debt discount | (98.1 | ) |  | (115.8 | ) |
| Net carrying amount of the liability component | $ | 351.9 |  |  | $ | 334.2 |  |


## us-gaap:DebtDisclosureTextBlock

[0001633978-19-000069:notes:210]
Note 13. Convertible Notes

[0001633978-19-000069:notes:211]
In March 2017, we issued the 2024 Notes in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act of 1933, as amended (the “Securities Act”). The 2024 Notes are governed by an indenture between the Company, as the issuer, and U.S. Bank National Association, as trustee (the “Indenture”). The 2024 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001633978-19-000069:notes:212]
The 2024 Notes bear interest at a rate of 0.25% per year. Interest on the 2024 Notes is payable semi-annually in arrears on March 15 and September 15 of each year, beginning on September 15, 2017. The 2024 Notes will mature on March 15, 2024, unless earlier repurchased by us or converted pursuant to their terms.

[0001633978-19-000069:notes:213]
The initial conversion rate of the 2024 Notes is 16.4965 shares of common stock per $1,000 principal amount of 2024 Notes, which is equivalent to an initial conversion price of approximately $60.62 per share, a 132.5% premium to the fair market value at the date of issuance. Prior to the close of business on the business day immediately preceding December 15, 2023, the 2024 Notes will be convertible only under the following circumstances: (1) during any fiscal quarter (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during the period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price, or $78.80 on each applicable trading day; (2) during the five consecutive business day period after any five consecutive trading day period (the “measurement period”) in which the trading price per $1,000 principal amount of notes for each trading day of such measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate on each such trading day; or (3) upon the occurrence of specified corporate events. On or after December 15, 2023 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their notes at any time. In addition, upon the occurrence of a make-whole fundamental change, we will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert 2024 Notes in connection with such make-whole fundamental change.

[0001633978-19-000069:notes:214]
We may not redeem the 2024 Notes prior to their maturity date and no sinking fund is provided for the 2024 Notes. Upon the occurrence of a fundamental change, holders may require us to repurchase all or a portion of their 2024 Notes for cash at a price equal to 100% of the principal amount of the 2024 Notes to be repurchased, plus any accrued and unpaid interest.

[0001633978-19-000069:notes:215]
We considered the features embedded in the 2024 Notes other than the conversion feature, including the holders’ put feature, our call feature, and the make-whole feature, and concluded that they are not required to be bifurcated and accounted for separately from the host debt instrument.

[0001633978-19-000069:notes:216]
Prior to the Tax Matters Agreement settlement condition (“TMA settlement condition”), because we could only settle the 2024 Notes in cash, we determined that the conversion feature met the definition of a derivative liability. We separated the derivative liability from the host debt instrument based on the fair value of the derivative liability. As of the issuance date, March 8, 2017, the derivative liability fair value of $129.9 million was calculated using the binomial valuation approach. The residual principal amount of the 2024 Notes of $320.1 million before issuance costs was allocated to the debt component. We incurred approximately $7.7 million in transaction costs in connection with the issuance of the 2024 Notes. These costs were allocated to the debt component and recognized as a debt discount. We amortize the debt discount, including both the initial value of the derivative liability and the transaction costs, over the term of the 2024 Notes using the effective interest method. The effective interest rate of the 2024 Notes is 5.4% per year. As of June 29, 2019, the remaining debt discount amortization period was 56 months.

[0001633978-19-000069:notes:217]
During the year ended July 1, 2017, we satisfied the TMA settlement condition. As such, the value of the conversion option will no longer be marked to market and was reclassified to additional paid-in capital within stockholders’ equity on our consolidated balance sheet. The value of the conversion option at the time of issuance will be treated as an original issue discount for purposes of accounting for the debt component of the notes. The debt component will accrete up to the principal amount over the expected term of the debt. These accounting standards do not affect the actual amount we are required to repay, and the amount shown in the table below for the notes is the aggregate principal amount of the notes and does not reflect the debt discount we will be required to recognize.

[0001633978-19-000069:notes:218]
The following table sets forth interest expense information related to the 2024 Notes for the periods presented (in millions, except percentages):

[0001633978-19-000069:notes:219]
|  | June 29, 2019 |  | June 30, 2018 |  | July 1, 2017 |
| Contractual interest expense | $ | 1.1 |  |  | $ | 1.2 |  |  | $ | 0.4 |  |
| Amortization of the debt discount | 17.7 |  |  | 16.7 |  |  | 5.1 |  |
| Total interest expense | $ | 18.8 |  |  | $ | 17.9 |  |  | $ | 5.5 |  |
| Effective interest rate on the liability component | 5.4 | % |  | 5.4 | % |  | 5.4 | % |

[0001633978-19-000069:notes:220]
We have the ability and intent to settle the $450 million face value of the debt in cash. Therefore, we use the treasury stock method for calculating the dilutive impact of the debt. The 2024 Notes will have no impact to diluted earnings per share until the average price of our common stock exceeds the conversion price of $60.62.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001633978-19-000069:notes:221]
Note 17. Stock-Based Compensation and Stock Plans

[0001633978-19-000069:notes:222]
Description of Lumentum Stock-Based Benefit Plans

[0001633978-19-000069:notes:223]
Equity Incentive Plan

[0001633978-19-000069:notes:224]
As of June 29, 2019, we had 2.4 million shares subject to stock options, restricted stock units, restricted stock awards, and performance stock units issued and outstanding under the 2015 Equity Incentive Plan (the “2015 Plan”).

[0001633978-19-000069:notes:225]
Restricted stock units, restricted stock awards, and performance stock units are performance-based, time-based or a combination of both and are expected to vest over one to four years. The fair value of these grants is based on the closing market price of our common stock on the date of award. The exercise price for stock options is equal to the fair value of the underlying stock at the date of grant. We issue new shares of common stock upon exercise of stock options. Options generally become exercisable over a three-year or four-year period and, if not exercised, expire from five to ten years after the date of grant.

[0001633978-19-000069:notes:226]
As of June 29, 2019, 3.9 million shares of common stock under the 2015 Plan were available for grant.

[0001633978-19-000069:notes:227]
Replacement Awards

[0001633978-19-000069:notes:228]
In connection with the acquisition of Oclaro, we issued equity awards to Oclaro employees, consisting of stock options and restricted stock units (“replacement awards”) in exchange for their Oclaro equity awards. The replacement awards consisted of less than 0.1 million stock options with a weighted average grant date fair value of $34.34, and 1.0 million restricted stock units with a weighted average grant date fair value of $41.80. The terms of these replacement awards are substantially similar to the original Oclaro equity awards. The fair value of the replacement awards for services rendered through December 10, 2018, the acquisition date, was recognized as a component of the merger consideration, with the remaining fair value of the replacement awards related to the post-combination services recorded as stock-based compensation over the remaining vesting period.

[0001633978-19-000069:notes:229]
Restricted Stock Units

[0001633978-19-000069:notes:230]
Restricted stock units (“RSUs”) under the 2015 Plan are grants of shares of our common stock, the vesting of which is based on the requisite service requirement. Generally, our RSUs are subject to forfeiture and expected to vest over one to four years. For annual refresh grants, RSUs generally vest ratably on an annual, or combination of annual and quarterly, basis over three years.

[0001633978-19-000069:notes:231]
Restricted Stock Awards

[0001633978-19-000069:notes:232]
Restricted stock awards (“RSAs”) under the 2015 Plan are grants of shares of our common stock that are subject to various restrictions, including restrictions on transferability and forfeiture provisions. RSAs are expected to vest over one to four years, and the shares acquired may not be transferred by the holder until the vesting conditions (if any) are satisfied.

[0001633978-19-000069:notes:233]
Performance Stock Units

[0001633978-19-000069:notes:234]
Performance stock units (“PSUs”) under the 2015 Plan are grants of shares of our common stock that vest upon the achievement of certain performance and service conditions. We begin recognizing compensation expense when we conclude that it is probable that the performance conditions will be achieved. We reassess the probability of vesting at each reporting period and adjust our compensation cost based on this probability assessment. Our PSUs are subject to risk of forfeiture until performance and service conditions are satisfied and generally vest over three years.

[0001633978-19-000069:notes:235]
In November 2018, our board of directors approved the grant of 0.2 million PSUs to senior members of our management team. At the beginning of fiscal 2019, we determined that the achievement of the performance conditions was probable, and as such, began recording stock-based compensation associated with these PSUs. Based on performance conditions actually achieved in fiscal 2019, we recorded $2.0 million expense related to these grants.

[0001633978-19-000069:notes:236]
Employee Stock Purchase Plan

[0001633978-19-000069:notes:237]
Our 2015 Employee Stock Purchase Plan (the “2015 Purchase Plan”)  provides eligible employees with the opportunity to acquire an ownership interest in the Company through periodic payroll deductions and provides a 15% purchase price discount as well as a six-month look-back period. The 2015 Purchase Plan is structured as a qualified employee stock purchase plan under Section 423 of the Internal Revenue Code of 1986. However, the 2015 Purchase Plan is not intended to be a qualified pension, profit sharing or stock bonus plan under Section 401(a) of the Internal Revenue Code of 1986 and is not subject to the provisions of the Employee Retirement Income Security Act of 1974. The 2015 Purchase Plan will terminate upon the date on which all shares available for issuance have been sold. Of the 3.0 million shares authorized under the 2015 Purchase Plan, 2.0 million shares remained available for issuance as of June 29, 2019.

[0001633978-19-000069:notes:238]
Stock-Based Compensation

[0001633978-19-000069:notes:239]
The impact on our results of operations of recording stock-based compensation by function during fiscal 2019, 2018, and 2017 was as follows (in millions):

[0001633978-19-000069:notes:240]
|  | Years Ended |
|  | June 29, 2019 |  | June 30, 2018 |  | July 1, 2017 |
| Cost of sales | $ | 15.1 |  |  | $ | 12.6 |  |  | $ | 7.5 |  |
| Research and development | 13.8 |  |  | 14.2 |  |  | 11.6 |  |
| Selling, general and administrative | 41.8 |  |  | 20.0 |  |  | 13.6 |  |
|  | $ | 70.7 |  |  | $ | 46.8 |  |  | $ | 32.7 |  |

[0001633978-19-000069:notes:241]
Approximately $3.5 million and $2.6 million of stock-based compensation was capitalized to inventory as of June 29, 2019 and June 30, 2018, respectively.

[0001633978-19-000069:notes:242]
In connection with the acquisition of Oclaro, we accelerated certain equity awards for Oclaro employees. The total stock-based compensation expense associated with the acceleration of equity awards was $15.2 million, out of which $10.0 million was settled in cash in our second quarter of fiscal 2019. Refer to “Note 5. Business Combination.”

[0001633978-19-000069:notes:243]
Stock Option and Stock Award Activity

[0001633978-19-000069:notes:244]
We did not grant any stock options during fiscal 2019, 2018, or 2017, other than those assumed in connection with the Oclaro merger. As of June 29, 2019, there were less than 0.05 million stock options outstanding under the 2015 Plan, all of which were replacement awards issued in connection with the Oclaro acquisition.

[0001633978-19-000069:notes:245]
The following table summarizes our awards activity in fiscal 2019, 2018, and 2017 (in millions, except per share amounts):

[0001633978-19-000069:notes:246]
|  | Stock Options |  | Restricted Stock Units |  | Restricted Stock Awards |  | Performance Stock Units |
|  | Number of Shares |  | Weighted-Average Exercise Price |  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |  | Number of Shares (1) |  | Weighted-Average Grant Date Fair Value per Share |
| Balance as of July 2, 2016 | 0.3 |  |  | $ | 17.8 |  |  | 2.5 |  |  | $ | 21.3 |  |  | — |  |  | $ | — |  |  | 0.1 |  |  | $ | 14.4 |  |
| Granted | — |  |  | — |  |  | 1.0 |  |  | 35.6 |  |  | 0.3 |  |  | 32.5 |  |  | — |  |  | — |  |
| Vested/Exercised | (0.3 | ) |  | 14.3 |  |  | (1.4 | ) |  | 22.3 |  |  | — |  |  | — |  |  | (0.1 | ) |  | 14.4 |  |
| Canceled | — |  |  | — |  |  | (0.2 | ) |  | 23.8 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Balance as of July 1, 2017 | — |  |  | $ | — |  |  | 1.9 |  |  | $ | 27.9 |  |  | 0.3 |  |  | $ | 32.5 |  |  | — |  |  | $ | — |  |
| Granted | — |  |  | — |  |  | 1.1 |  |  | 54.5 |  |  | — |  |  | — |  |  | 0.1 |  |  | 52.0 |  |
| Vested/Exercised | — |  |  | — |  |  | (1.1 | ) |  | 26.6 |  |  | (0.2 | ) |  | 32.5 |  |  | — |  |  | — |  |
| Canceled | — |  |  | — |  |  | (0.2 | ) |  | 38.8 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Balance as of June 30, 2018 | — |  |  | $ | — |  |  | 1.7 |  |  | $ | 43.1 |  |  | 0.1 |  |  | $ | 32.5 |  |  | 0.1 |  |  | $ | 52.0 |  |
| Assumed in Oclaro merger | * |  |  | 34.3 |  |  | 1.0 |  |  | 41.8 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Granted | — |  |  | — |  |  | 1.0 |  |  | 60.3 |  |  | — |  |  | — |  |  | 0.2 |  |  | 55.9 |  |
| Vested/Exercised | * |  |  | 26.2 |  |  | (1.0 | ) |  | 41.5 |  |  | (0.1 | ) |  | 32.5 |  |  | (0.1 | ) |  | 49.0 |  |
| Canceled | — |  |  | — |  |  | (0.5 | ) |  | 50.2 |  |  | * |  |  | 32.8 |  |  | * |  |  | 53.8 |  |
| Balance as of June 29, 2019 | * |  |  | $ | 38.8 |  |  | 2.2 |  |  | $ | 52.4 |  |  | * |  |  | $ | 32.5 |  |  | 0.2 |  |  | $ | 56.0 |  |

[0001633978-19-000069:notes:247]
* Less than 0.05 million

[0001633978-19-000069:notes:248]
(1) In fiscal 2018, we granted 0.1 million PSUs to senior members of our management team subject to revenue performance condition. The number of awards granted in fiscal 2018 represented 100% of target goal; under the terms of the awards, the recipient could earn between 0% and 200% of the original grant. The performance condition was achieved in fiscal 2018. In first quarter of fiscal 2019, our board of directors approved an increase in the original number of PSUs based on the actual achievement.

[0001633978-19-000069:notes:249]
As of June 29, 2019, $96.8 million of stock-based compensation cost related to awards granted to our employees remains to be amortized. That cost is expected to be recognized over an estimated amortization period of 2.0 years.

[0001633978-19-000069:notes:250]
A summary of awards available for grant is as follows (in millions):

[0001633978-19-000069:notes:251]
|  | Awards Available for Grant |
| Balance as of July 2, 2016 | 4.7 |  |
| Authorized | 3.0 |  |
| Granted | (1.3 | ) |
| Canceled | 0.2 |  |
| Balance as of July 1, 2017 | 6.6 |  |
| Authorized | — |  |
| Granted | (1.2 | ) |
| Canceled | 0.2 |  |
| Balance as of June 30, 2018 | 5.6 |  |
| Replacement awards in connection with Oclaro acquisition | (1.0 | ) |
| Granted | (1.2 | ) |
| Canceled | 0.5 |  |
| Balance as of June 29, 2019 | 3.9 |  |

[0001633978-19-000069:notes:252]
Employee Stock Purchase Plan Activity

[0001633978-19-000069:notes:253]
The 2015 Purchase Plan expense for fiscal 2019, 2018, and 2017 were $3.6 million, $3.3 million, and $2.7 million, respectively. The expense related to the 2015 Purchase Plan is recorded on a straight-line basis over the relevant subscription period. During fiscal 2019, 2018, and 2017, there were 0.3 million, 0.2 million, and 0.3 million shares issued to employees through the 2015 Purchase Plan.

[0001633978-19-000069:notes:254]
We estimate the fair value of the 2015 Purchase Plan shares on the date of grant using the Black-Scholes option-pricing model. The assumptions used to estimate the fair value of the 2015 Purchase Plan shares to be issued during the periods presented were as follows:

[0001633978-19-000069:notes:255]
|  | June 29, 2019 |  | June 30, 2018 |
| Expected term (years) | 0.5 |  |  | 0.5 |  |
| Expected volatility | 60.1 | % |  | 58.8 | % |
| Risk-free interest rate | 2.47 | % |  | 2.02 | % |
| Dividend yield | — | % |  | — | % |


## us-gaap:EarningsPerShareTextBlock

[0001633978-19-000069:notes:256]
Note 3. Earnings Per Share

[0001633978-19-000069:notes:257]
The following table sets forth the computation of basic and diluted net income attributable to common stockholders per share (in millions, except per share data):

[0001633978-19-000069:notes:258]
|  | Years Ended |
|  | June 29, 2019 |  | June 30, 2018 |  | July 1, 2017 |
| Basic Earnings per Common Share |  |  |  |  |  |  |  |
| Net income/(loss) | $ | (36.4 | ) |  | $ | 248.1 |  |  | $ | (102.5 | ) |
| Less: Cumulative dividends on Series A Preferred Stock | (0.3 | ) |  | (0.9 | ) |  | (0.9 | ) |
| Less: Earnings allocated to Series A Preferred Stock | (1.2 | ) |  | (5.7 | ) |  | — |  |
| Net income/(loss) attributable to common stockholders - Basic | $ | (37.9 | ) |  | $ | 241.5 |  |  | $ | (103.4 | ) |
| Weighted average common shares outstanding including Series A Preferred Stock | 70.7 |  |  | 63.8 |  |  | 62.1 |  |
| Less: Weighted average Series A Preferred Stock | — |  |  | (1.5 | ) |  | (1.5 | ) |
| Basic weighted average common shares outstanding | 70.7 |  |  | 62.3 |  |  | 60.6 |  |
| Net income/(loss) per share attributable to common stockholders - Basic | $ | (0.54 | ) |  | $ | 3.88 |  |  | $ | (1.71 | ) |
| Diluted Earnings per Common Share |  |  |  |  |  |
| Net income/(loss) attributable to common stockholders - Basic | $ | (37.9 | ) |  | $ | 241.5 |  |  | $ | (103.4 | ) |
| Net income/(loss) attributable to common stockholders - Diluted | $ | (37.9 | ) |  | $ | 241.5 |  |  | $ | (103.4 | ) |
| Weighted average common shares outstanding for basic earnings per common share | 70.7 |  |  | 62.3 |  |  | 60.6 |  |
| Effect of dilutive securities from 2015 Equity Incentive Plan | — |  |  | 1.0 |  |  | — |  |
| Effect of dilutive securities from Series A Preferred Stock | — |  |  | — |  |  | — |  |
| Diluted weighted average common shares outstanding | 70.7 |  |  | 63.3 |  |  | 60.6 |  |
| Net income/(loss) per share attributable to common stockholders - Diluted | $ | (0.54 | ) |  | $ | 3.82 |  |  | $ | (1.71 | ) |

[0001633978-19-000069:notes:259]
For the years ended June 29, 2019 and July 1, 2017, our diluted earnings per share attributable to common stockholders is the same as basic EPS as we are in net loss position. For the year ended June 30, 2018, our diluted earnings per share attributable to common stockholders is calculated using the “treasury stock” method because it is more dilutive than the “if-converted” method.

[0001633978-19-000069:notes:260]
Our Series A Preferred Stock was considered a participating security where the holders of Series A Preferred Stock had the right to participate in undistributed earnings with holders of common stock.  On November 2, 2018, the remaining 35,805 shares of our Series A Preferred Stock were converted into 1.5 million shares of our common stock. Refer to “Note 12. Non-Controlling Interest Redeemable Convertible Preferred Stock and Derivative Liability” for further discussion. Prior to conversion, the holders of our Series A Preferred Stock were entitled to share in dividends, on an as-converted basis, if the holders of our common stock were to receive dividends. Up through the date of conversion, we used the two-class method to compute earnings per share. The two-class method is an earnings allocation formula that determines earnings per share for each class of common stock and participating security according to dividends declared (or accumulated) and participation rights in undistributed earnings. In determining the amount of net earnings to allocate to common stockholders, earnings are allocated to both common and participating securities based on their respective weighted-average shares outstanding during the period. Diluted earnings per common share is calculated similar to basic earnings per common share except that it gives effect to all potentially dilutive common stock equivalents outstanding for the period, using the treasury stock method. Diluted earnings per common share is computed using the more dilutive of the treasury stock method or the if-converted method.

[0001633978-19-000069:notes:261]
Potentially dilutive common shares result from the assumed exercise of outstanding stock options, assumed vesting of outstanding equity awards, assumed issuance of stock under the employee stock purchase plan, and assumed conversion of our outstanding $450 million in aggregate principal amount of 0.25% Convertible Notes due in 2024 (the “2024 Notes”), all using the treasury stock method. We have the ability and intent to settle the $450 million face value of the 2024 Notes in cash. Therefore, we use the treasury stock method for calculating the dilutive impact of the 2024 Notes. The 2024 Notes will have no impact on diluted earnings per share until the average price of our common stock exceeds the conversion price of $60.62. Refer to “Note 13. Convertible Notes” for further discussion.

[0001633978-19-000069:notes:262]
Anti-dilutive potential shares from the 2015 Equity Incentive Plan are excluded from the calculation of diluted earnings per share if their exercise price exceeded the average market price during the period or the share-based awards were determined to be anti-dilutive based on applying the treasury stock method.


## us-gaap:FairValueDisclosuresTextBlock

[0001633978-19-000069:notes:263]
Note 11. Fair Value Measurements

[0001633978-19-000069:notes:264]
We determine fair value based on the fair value hierarchy, which requires an entity to maximize the use of observable inputs and minimize the use of unobservable inputs when measuring fair value. Fair value is defined as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. The fair value assumes that the transaction to sell the asset or transfer the liability occurs in the principal or most advantageous market for the asset or liability and establishes that the fair value of an asset or liability shall be determined based on the assumptions that market participants would use in pricing the asset or liability. The classification of a financial asset or liability within the hierarchy is based upon the lowest level input that is significant to the fair value measurement. The fair value hierarchy prioritizes the inputs into three levels that may be used to measure fair value:

[0001633978-19-000069:notes:265]
| Level 1: | Inputs are unadjusted quoted prices in active markets for identical assets or liabilities. |
| Level 2: | Inputs are quoted prices for similar assets and liabilities in active markets or inputs that are observable for the asset or liability, either directly or indirectly through market corroboration, for substantially the full term of the financial instrument. |
| Level 3: | Inputs are unobservable inputs based on our assumptions. |

[0001633978-19-000069:notes:266]
The fair value of our Level 1 financial instruments, such as money market funds, which are traded in active markets, is based on quoted market prices for identical instruments. The fair value of our Level 2 fixed income securities is obtained from an independent pricing service, which may use quoted market prices for identical or comparable instruments or model driven valuations using observable market data or inputs corroborated by observable market data. Our marketable securities are held by custodians who obtain investment prices from a third-party pricing provider that incorporates standard inputs in various asset price models. Our procedures include controls to ensure that appropriate fair values are recorded, including comparing the fair values obtained from our pricing service against fair values obtained from another independent source.

[0001633978-19-000069:notes:267]
Prior to the conversion of the Series A Preferred Stock in the second quarter of fiscal 2019, we estimated the fair value of the embedded derivative for the Series A Preferred Stock using the binomial lattice model. The binomial lattice model requires various assumptions to be made to determine the fair value of the embedded derivatives. These assumptions represent Level 3 inputs. Refer to “Note 12. Non-Controlling Interest Redeemable Convertible Preferred Stock and Derivative Liability.”

[0001633978-19-000069:notes:268]
In February 2017, we completed the acquisition of a privately held company to enhance our manufacturing and vertical integration capabilities for a total purchase consideration of $8.7 million. We estimated the fair value of our Level 3 contingent consideration related to this acquisition at the present value of the expected contingent payments, determined using a probabilistic approach. We estimated the likelihood of meeting the production targets at 90 percent and recorded $2.7 million as fair value of such contingent consideration in other current liabilities on the consolidated balance sheet as of June 29, 2019. This contingent consideration will result in a cash payment of $3.0 million (based on the exchange rate as of the acquisition date), if and when the production targets are achieved, which we expect to occur within the following 12 months. We are required to reassess the fair value of contingent payments on a periodic basis. There was no change in the fair value of our contingent consideration during fiscal 2019, 2018 or 2017.

[0001633978-19-000069:notes:269]
Our pension assets consist of multiple institutional funds (“pension funds”) of which the fair values are based on the quoted prices of the underlying funds. Pension funds are mainly classified as Level 2 assets since such funds are not directly traded in active markets. Refer to “Note 18. Employee Benefit Plans.”

[0001633978-19-000069:notes:270]
Based on quoted market prices as of June 29, 2019, the fair value of the Convertible Notes (“Note 13. Convertible Notes”) was approximately $527.0 million, determined using Level 2 inputs as they are not actively traded in markets.

[0001633978-19-000069:notes:271]
Financial assets and liabilities measured at fair value on a recurring basis are summarized below (in millions):

[0001633978-19-000069:notes:272]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| June 29, 2019 (1) |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | — |  |  | $ | 37.4 |  |  | $ | — |  |  | $ | 37.4 |  |
| Money market funds | 168.1 |  |  | — |  |  | — |  |  | 168.1 |  |
| U.S. Treasury securities | 13.3 |  |  | — |  |  | — |  |  | 13.3 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | 1.9 |  |  | — |  |  | 1.9 |  |
| Commercial paper | — |  |  | 22.3 |  |  | — |  |  | 22.3 |  |
| Asset-backed securities | — |  |  | 55.1 |  |  | — |  |  | 55.1 |  |
| Corporate debt securities | — |  |  | 208.4 |  |  | — |  |  | 208.4 |  |
| Municipal bonds | — |  |  | 1.3 |  |  | — |  |  | 1.3 |  |
| Mortgage-backed securities | — |  |  | 6.6 |  |  | — |  |  | 6.6 |  |
| Foreign government bonds | — |  |  | 6.2 |  |  | — |  |  | 6.2 |  |
| U.S. Agency securities | — |  |  | 4.6 |  |  | — |  |  | 4.6 |  |
| U.S. Treasury securities | 29.5 |  |  | — |  |  | — |  |  | 29.5 |  |
| Total assets | $ | 210.9 |  |  | $ | 343.8 |  |  | $ | — |  |  | $ | 554.7 |  |
| Other accrued liabilities: |  |  |  |  |  |  |  |
| Acquisition contingencies | $ | — |  |  | $ | — |  |  | $ | 2.7 |  |  | $ | 2.7 |  |
| Total other accrued liabilities | $ | — |  |  | $ | — |  |  | $ | 2.7 |  |  | $ | 2.7 |  |

[0001633978-19-000069:notes:273]
(1)  Excludes $213.8 million in cash held in our bank accounts as of June 29, 2019.

[0001633978-19-000069:notes:274]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| June 30, 2018: (1) |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | — |  |  | $ | 3.0 |  |  | $ | — |  |  | $ | 3.0 |  |
| Commercial paper | — |  |  | 112.1 |  |  | — |  |  | 112.1 |  |
| Money market funds | 0.8 |  |  | — |  |  | — |  |  | 0.8 |  |
| U.S. Treasury securities | 143.6 |  |  | — |  |  | — |  |  | 143.6 |  |
| U.S. Agency securities | — |  |  | 34.2 |  |  | — |  |  | 34.2 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | 7.5 |  |  | — |  |  | 7.5 |  |
| Commercial paper | — |  |  | 10.5 |  |  | — |  |  | 10.5 |  |
| Asset-backed securities | — |  |  | 67.8 |  |  | — |  |  | 67.8 |  |
| Corporate debt securities | — |  |  | 219.2 |  |  | — |  |  | 219.2 |  |
| Municipal bonds | — |  |  | 1.6 |  |  | — |  |  | 1.6 |  |
| Mortgage-backed securities | — |  |  | 4.2 |  |  | — |  |  | 4.2 |  |
| Foreign government bonds | — |  |  | 3.4 |  |  | — |  |  | 3.4 |  |
| Total assets | $ | 144.4 |  |  | $ | 463.5 |  |  | $ | — |  |  | $ | 607.9 |  |
| Other accrued liabilities: |  |  |  |  |  |  |  |
| Derivative liability | $ | — |  |  | $ | — |  |  | $ | 52.4 |  |  | $ | 52.4 |  |
| Acquisition contingencies | — |  |  | — |  |  | 2.7 |  |  | 2.7 |  |
| Total other accrued liabilities | $ | — |  |  | $ | — |  |  | $ | 55.1 |  |  | $ | 55.1 |  |

[0001633978-19-000069:notes:275]
(1)  Excludes $103.6 million in cash held in our bank accounts as of June 30, 2018.

[0001633978-19-000069:notes:276]
Assets Measured at Fair Value on a Non-Recurring Basis

[0001633978-19-000069:notes:277]
We periodically review our intangible and other long-lived assets for impairment whenever events or changes in circumstances indicate that the carrying amount of such assets may not be recoverable. Determination of recoverability is based on the lowest level of identifiable estimated undiscounted cash flows resulting from use of the asset and its eventual disposition. If not recoverable, an impairment loss would be calculated based on the excess of the carrying amount over the fair value. During the annual impairment testing performed in fiscal 2019, we concluded that our intangible assets were not impaired.

[0001633978-19-000069:notes:278]
We also valued certain long-lived assets at fair value on a non-recurring basis as of June 29, 2019 as part of our long-lived asset impairment testing and recorded an impairment charge of $30.7 million during fiscal 2019. Fair value was determined by utilizing a market approach incorporating both observable and unobservable inputs, and are deemed to be Level 3 fair value inputs. Refer to “Note 5. Business Combination” and “Note 15. Impairment Charges.”


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0001633978-19-000069:notes:279]
We periodically review our intangible and other long-lived assets for impairment whenever events or changes in circumstances indicate that the carrying amount of such assets may not be recoverable. Determination of recoverability is based on the lowest level of identifiable estimated undiscounted cash flows resulting from use of the asset and its eventual disposition. If not recoverable, an impairment loss would be calculated based on the excess of the carrying amount over the fair value.


## us-gaap:FiniteLivedIntangibleAssetsAmortizationExpenseTableTextBlock

[0001633978-19-000069:notes:280]
The following table presents details of amortization for the periods presented (in millions):

[0001633978-19-000069:notes:281]
|  | Years ended |
|  | June 29, 2019 |  | June 30, 2018 |  | July 1, 2017 |
| Cost of sales | $ | 46.6 |  |  | $ | 3.2 |  |  | $ | 6.5 |  |
| Selling, general and administrative | 8.0 |  |  | — |  |  | 0.3 |  |
| Total | $ | 54.6 |  |  | $ | 3.2 |  |  | $ | 6.8 |  |


## us-gaap:GoodwillDisclosureTextBlock

[0001633978-19-000069:notes:282]
Note 6. Goodwill and Other Intangible Assets

[0001633978-19-000069:notes:283]
On December 10, 2018, we completed the merger with Oclaro. We recognized goodwill in the amount of $357.6 million for the acquisition of Oclaro and allocated it to our OpComms segment. The following table presents the changes in goodwill by our reportable segments during the years ended June 29, 2019 and June 30, 2018 (in millions):

[0001633978-19-000069:notes:284]
|  |  | Optical Communications |  | Commercial Lasers |  | Total |
| Balance as of July 1, 2017 | $ | 5.9 |  |  | $ | 5.5 |  |  | $ | 11.4 |  |
|  | Foreign currency translation adjustment | — |  |  | (0.1 | ) |  | (0.1 | ) |
| Balance as of June 30, 2018 | $ | 5.9 |  |  | $ | 5.4 |  |  | $ | 11.3 |  |
|  | Acquisition of Oclaro | 333.4 |  |  | — |  |  | 333.4 |  |
|  | Measurement period adjustments (1) | 24.2 |  |  | — |  |  | 24.2 |  |
| Balance as of June 29, 2019 | $ | 363.5 |  |  | $ | 5.4 |  |  | $ | 368.9 |  |

[0001633978-19-000069:notes:285]
(1) Refer to “Note 5. Business Combination” for details of these measurement period adjustments.

[0001633978-19-000069:notes:286]
Impairment of Goodwill

[0001633978-19-000069:notes:287]
We review goodwill for impairment during the fourth quarter of each fiscal year or more frequently if events or circumstances indicate that an impairment loss may have occurred. Based on the impairment analysis performed in the fourth quarter of each year presented, the fair value of our reporting unit substantially exceeded the carrying value; as such, our annual qualitative assessment did not indicate that a more detailed quantitative analysis was necessary.

[0001633978-19-000069:notes:288]
Other Intangible Assets

[0001633978-19-000069:notes:289]
In connection with our acquisition of Oclaro on December 10, 2018, we recorded $443.0 million as our preliminary estimate of the fair value of the acquired developed technologies and other intangible assets. The intangible assets acquired from Oclaro consist of the following:

[0001633978-19-000069:notes:290]
| Intangible assets |  | Fair value(in millions) |  | Weighted average amortization period(in years) |
| Acquired developed technologies |  | $ | 182.0 |  |  | 4.4 years |
| Customer relationships |  | 145.0 |  |  | 8 years |
| In-process research and development (1) |  | 94.0 |  |  | n/a |
| Order backlog |  | 22.0 |  |  | 1 year |
| Total intangible assets (1) |  | $ | 443.0 |  |  |  |

[0001633978-19-000069:notes:291]
(1) The intangible assets as of June 29, 2019 exclude $1.0 million In-process research and development assets subsequently sold to CIG. Refer to “Note 5. Business Combination”.

[0001633978-19-000069:notes:292]
The intangible assets are amortized on a straight-line basis over the estimated useful lives, except for customer relationships and order backlog, which are amortized using an accelerated method of amortization over the expected customer lives, which more accurately reflects the pattern of realization of economic benefits expected to be obtained. Acquired developed technologies and order backlog are amortized to cost of sales and customer relationships is amortized to selling, general and administrative. IPR&D is initially capitalized at fair value as an intangible asset with an indefinite life and assessed for impairment thereafter. When an IPR&D project is completed, the IPR&D is reclassified as an amortizable purchased intangible asset and amortized over the asset’s estimated useful life expected to range between 4 to 9 years.

[0001633978-19-000069:notes:293]
The following tables present details of our other intangibles, including those acquired in connection with the Oclaro acquisition, as of the periods presented (in millions):

[0001633978-19-000069:notes:294]
| June 29, 2019 | Gross Carrying Amount |  | Accumulated Amortization |  | Net |
| Acquired developed technologies | $ | 287.5 |  |  | $ | (125.2 | ) |  | $ | 162.3 |  |
| Customer relationships and order backlog | 171.3 |  |  | (32.2 | ) |  | 139.1 |  |
| In-process research and development | 94.0 |  |  | — |  |  | 94.0 |  |
| Other intangibles | 2.7 |  |  | (2.7 | ) |  | — |  |
| Total intangible assets | $ | 555.5 |  |  | $ | (160.1 | ) |  | $ | 395.4 |  |

[0001633978-19-000069:notes:295]
| June 30, 2018 | Gross Carrying Amount |  | Accumulated Amortization |  | Net |
| Acquired developed technologies | $ | 105.5 |  |  | $ | (98.5 | ) |  | $ | 7.0 |  |
| Customer relationships | 4.3 |  |  | (4.3 | ) |  | — |  |
| Other intangibles | 2.7 |  |  | (2.7 | ) |  | — |  |
| Total intangible assets | $ | 112.5 |  |  | $ | (105.5 | ) |  | $ | 7.0 |  |

[0001633978-19-000069:notes:296]
The amounts in the tables above include cumulative foreign currency translation adjustments, reflecting movement in the currencies of the underlying intangibles.

[0001633978-19-000069:notes:297]
During fiscal 2019, 2018, and 2017, we recorded $54.6 million, $3.2 million, and $6.8 million, respectively, of amortization related to intangibles assets.

[0001633978-19-000069:notes:298]
Based on the carrying amount of our acquired developed technologies and other intangibles, excluding IPR&D, as of June 29, 2019, and assuming no future impairment of the underlying assets, the estimated future amortization is as follows (in millions):

[0001633978-19-000069:notes:299]
| Fiscal Years |  |
| 2020 | $ | 71.9 |  |
| 2021 | 66.3 |  |
| 2022 | 63.6 |  |
| 2023 | 40.6 |  |
| 2024 | 21.8 |  |
| Thereafter | 37.2 |  |
| Total | $ | 301.4 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001633978-19-000069:notes:300]
Note 16. Income Taxes

[0001633978-19-000069:notes:301]
Our income (loss) before income taxes consisted of the following (in millions):

[0001633978-19-000069:notes:302]
|  | Years Ended |
|  | June 29, 2019 |  | June 30, 2018 |  | July 1, 2017 |
| Domestic | $ | (21.9 | ) |  | $ | 37.8 |  |  | $ | (78.4 | ) |
| Foreign | (11.4 | ) |  | 91.6 |  |  | 18.6 |  |
| Income (loss) before income taxes | $ | (33.3 | ) |  | $ | 129.4 |  |  | $ | (59.8 | ) |

[0001633978-19-000069:notes:303]
Our income tax (benefit) expense consisted of the following (in millions):

[0001633978-19-000069:notes:304]
|  | Years Ended |
|  | June 29, 2019 |  | June 30, 2018 |  | July 1, 2017 |
| Federal: |  |  |  |  |  |
| Current | $ | 13.8 |  |  | $ | 1.2 |  |  | $ | 13.7 |  |
| Deferred | (0.1 | ) |  | (120.4 | ) |  | — |  |
|  | 13.7 |  |  | (119.2 | ) |  | 13.7 |  |
| State: |  |  |  |  |  |
| Current | 0.1 |  |  | 1.0 |  |  | 0.1 |  |
| Deferred | 0.4 |  |  | (1.3 | ) |  | — |  |
|  | 0.5 |  |  | (0.3 | ) |  | 0.1 |  |
| Foreign: |  |  |  |  |  |
| Current | 10.3 |  |  | 1.2 |  |  | 2.1 |  |
| Deferred | (21.4 | ) |  | (0.4 | ) |  | 26.8 |  |
|  | (11.1 | ) |  | 0.8 |  |  | 28.9 |  |
| Total income tax (benefit) expense | $ | 3.1 |  |  | $ | (118.7 | ) |  | $ | 42.7 |  |

[0001633978-19-000069:notes:305]
The comparability of our operating results of fiscal 2019 compared to the corresponding prior year was impacted by the U.S. Tax Cuts and Jobs Act of 2017 (the “Tax Act”), which was enacted on December 22, 2017. The Tax Act introduced significant changes to U.S. income tax law including reducing the U.S. federal statutory tax rate from 35% to 21% and imposing new taxes on certain foreign-sourced earnings and certain intercompany payments. Due to the timing of the enactment and the complexity involved in applying the provisions of the Tax Act, we made reasonable estimates of the effects and recorded provisional amounts in our financial statements as of fiscal 2018 in accordance with SEC Staff Accounting Bulletin No. 118 (“SAB 118”). During the period ended December 29, 2018, we completed our accounting for the Tax Act with no material adjustment to our provisional estimates recorded.

[0001633978-19-000069:notes:306]
The provision for income taxes differs from the amount computed by applying the U.S. Federal statutory income tax rate to our income before provision for income taxes as follows (in millions):

[0001633978-19-000069:notes:307]
|  | Years Ended |
|  | June 29, 2019 |  | June 30, 2018 |  | July 1, 2017 |
| Income tax (benefit) expense computed at federal statutory rate | $ | (7.0 | ) |  | $ | 36.3 |  |  | $ | (20.9 | ) |
| State taxes, net of federal benefit | 0.7 |  |  | (0.5 | ) |  | 0.1 |  |
| Foreign rate differential | (17.8 | ) |  | (24.3 | ) |  | (4.7 | ) |
| Change in valuation allowance | 7.4 |  |  | (206.0 | ) |  | 21.5 |  |
| Tax Act - tax rate change | — |  |  | 80.5 |  |  | — |  |
| Tax credits | (7.1 | ) |  | (11.0 | ) |  | (2.9 | ) |
| Permanent items | (0.6 | ) |  | (0.8 | ) |  | 0.3 |  |
| Stock-based compensation | 5.9 |  |  | (1.0 | ) |  | 4.9 |  |
| Fair value adjustment | 0.5 |  |  | 0.2 |  |  | 36.5 |  |
| Subpart F and GILTI | 13.4 |  |  | 2.0 |  |  | — |  |
| Unrecognized tax benefits | 4.8 |  |  | 7.9 |  |  | 8.4 |  |
| Prior year true-up | (0.3 | ) |  | (1.8 | ) |  | (0.1 | ) |
| Other | 0.2 |  |  | (0.2 | ) |  | (0.4 | ) |
| Audit settlement | 3.0 |  |  | — |  |  | — |  |
| Total income tax (benefit) expense | $ | 3.1 |  |  | $ | (118.7 | ) |  | $ | 42.7 |  |

[0001633978-19-000069:notes:308]
Our provision for income taxes for fiscal 2019 increased compared to fiscal 2018 primarily as a result of $206.0 million of income tax benefit related to the release of valuation allowance against our U.S. federal and certain state deferred tax assets and $80.5 million of income tax expense related to the remeasurement of our net deferred tax assets as a result of reduction in the U.S. federal corporate tax rate, both of which were recognized during fiscal 2018. Our provision for income taxes was also impacted by the benefit of our foreign income being taxed at lower rates than the U.S. statutory rate, as well as the benefit of research and development tax credits.

[0001633978-19-000069:notes:309]
The components of our net deferred taxes consisted of the following (in millions):

[0001633978-19-000069:notes:310]
|  | Years Ended |
|  | June 29, 2019 |  | June 30, 2018 |
| Gross deferred tax assets: |  |  |  |
| Intangibles | $ | 111.7 |  |  | $ | 123.3 |  |
| Tax credit carryforwards | 66.5 |  |  | 47.1 |  |
| Net operating loss carryforwards | 134.6 |  |  | 7.1 |  |
| Inventories | 11.3 |  |  | 12.4 |  |
| Accruals and reserves | 19.6 |  |  | 7.2 |  |
| Fixed assets | 32.3 |  |  | 10.1 |  |
| Capital loss carryforwards | 12.1 |  |  | 12.3 |  |
| Unclaimed research and experimental development expenditure | 25.6 |  |  | 25.6 |  |
| Stock-based compensation | 3.4 |  |  | 3.5 |  |
| Other | — |  |  | 0.5 |  |
| Gross deferred tax assets | 417.1 |  |  | 249.1 |  |
| Valuation allowance | (190.3 | ) |  | (99.4 | ) |
| Deferred tax assets | 226.8 |  |  | 149.7 |  |
| Gross deferred tax liabilities: |  |  |  |
| Intangible amortization | (90.8 | ) |  | (0.8 | ) |
| Convertible notes | (20.1 | ) |  | (23.6 | ) |
| Other | (2.2 | ) |  | — |  |
| Deferred tax liabilities | (113.1 | ) |  | (24.4 | ) |
| Total net deferred tax assets | $ | 113.7 |  |  | $ | 125.3 |  |

[0001633978-19-000069:notes:311]
We assess our ability to realize the deferred tax assets on a quarterly basis and establish a valuation allowance if the deferred tax assets are not more-likely-than-not to be realized. We weigh all available positive and negative evidence, including our earnings history and results of recent operations, reversals of deferred tax liabilities, projected future taxable income, and tax planning strategies.

[0001633978-19-000069:notes:312]
As of each reporting date, we consider new evidence, both positive and negative, that could affect our view of the future realization of deferred tax assets. During fiscal 2018, we determined that there is sufficient positive evidence to conclude that it is more-likely-than-not that the U.S. federal and certain states deferred tax assets are realizable. We, therefore, released the valuation allowance against our U.S. federal and certain states resulting in an income tax benefit of $207.2 million.

[0001633978-19-000069:notes:313]
Due to the weight of negative evidence, we continue to maintain a full valuation allowance on our California, Thailand, and the U.K. deferred tax assets and partial valuation allowance on our Canadian deferred tax assets. In the event the Company determines that it will be able to realize all or part of the U.K., California, or Canada deferred tax assets in the future, the valuation allowance will be reversed in the period in which the Company makes such determination. Based on the information currently available, we do not believe that a significant portion of our valuation allowance for the U.K., Thailand, California, and Canada will be released in the next 12 months. Such a release would result in the recognition of certain deferred tax assets and a decrease in the income tax expense for the period in which the release is recorded.

[0001633978-19-000069:notes:314]
As a result of meeting certain capital funding, capital investments and hiring requirements, income from operations in Thailand was exempt from income tax in fiscal 2019 and fiscal 2018.

[0001633978-19-000069:notes:315]
As of June 29, 2019, the Company had federal and foreign net operating loss carryforwards of $181.4 million and $562.0 million, respectively. These carryforwards will begin to expire in the fiscal years ending 2020 and 2025, respectively. The federal and foreign tax attributes carried forward are subject to various rules which impose limitations on the utilization.

[0001633978-19-000069:notes:316]
Additionally, the Company has federal, state, and foreign research and other tax credit carryforwards of $11.8 million, $36.7 million, and $49.2 million, respectively. The federal credits will begin to expire in the fiscal year ending 2033 and California credits can be carried forward indefinitely. The foreign tax credits will begin to expire in the fiscal year ending 2020.

[0001633978-19-000069:notes:317]
The Tax Act generally provides greater flexibility for us to access and utilize our cash held by certain of our foreign subsidiaries and we intend to repatriate all or some of the earnings of our subsidiaries in the Cayman Islands, Japan and Hong Kong. As to all other foreign subsidiaries, we intend to reinvest these earnings indefinitely outside of the U.S. As a result, U.S. income and foreign withholding taxes associated with the repatriation of $27.2 million of undistributed earnings of foreign subsidiaries, other than the Cayman Islands, Japan and Hong Kong subsidiaries, have not been provided for. We estimate that an additional $1.8 million of foreign withholding taxes would have to be provided if these earnings were repatriated back to the U.S.

[0001633978-19-000069:notes:318]
The aggregate changes in the balance of our unrecognized tax benefits between July 2, 2016 and June 29, 2019 are as follows (in millions):

[0001633978-19-000069:notes:319]
| Balance at July 1, 2017 | $ | 13.3 |  |
| Additions based on the tax positions related to the prior year | 1.2 |  |
| Additions based on tax positions related to current year | 11.3 |  |
| Balance at June 30, 2018 | $ | 25.8 |  |
| Additions based on the tax positions related to the prior year | 3.7 |  |
| Decreases related to settlement with Tax Authorities | (0.7 | ) |
| Additions based on tax positions related to current year | 29.2 |  |
| Balance at June 29, 2019 | $ | 58.0 |  |

[0001633978-19-000069:notes:320]
As of June 29, 2019, we had $18.7 million of unrecognized tax benefits, which, if recognized, would affect the effective tax rate. We are subject to examination of income tax returns by various domestic and foreign tax authorities. The timing of resolutions and closures of tax audits is highly unpredictable. Although it is possible that certain tax audits may be concluded within the next 12 months, we cannot reasonably estimate the impact to tax expense and net income from tax exams that could be resolved or closed within next 12 months. However, we believe that we have adequately provided under GAAP for potential audit outcomes. Subject to audit timing and uncertainty, we expect the amount of unrecognized tax benefit that would become recognized due to expiration of the statute of limitations and affect the effective tax rate to be $1.9 million over the next 12 months. During the three months ended March 30, 2019, we settled the Canadian income tax examination for fiscal years 2000 and 2001, which resulted in a $1.5 million decrease in unrecognized tax benefit.

[0001633978-19-000069:notes:321]
Our policy is to recognize accrued interest and penalties related to unrecognized tax benefits within the income tax provision. The amount of interest and penalties accrued as of June 29, 2019 and June 30, 2018 were $1.0 million and $0.9 million, respectively.

[0001633978-19-000069:notes:322]
The major tax jurisdictions where we file tax returns are the U.S. federal government, the state of California, Japan, the United Kingdom, Thailand, China and Canada. As of June 29, 2019, our fiscal 2009 to 2019 tax returns are open to potential examination in one or more jurisdictions. In addition, certain net operating loss and credit carryforwards may extend the ability of the tax authorities to examine our tax returns beyond the regular limits.

[0001633978-19-000069:notes:323]
On June 7, 2019, the Ninth Circuit Court of Appeals, reversing a previous decision of the U.S. Tax Court, held that the U.S. Treasury Department’s regulations requiring the inclusion of stock-based compensation expense in a taxpayer’s cost-sharing calculations were valid. Our financial statements have been prepared consistent with this outcome, but we will continue to monitor any ongoing developments, including the possibility of rehearing or appeal to the U.S. Supreme Court, to determine if future changes are required.


## us-gaap:InterestIncomeAndInterestExpenseDisclosureTableTextBlock

[0001633978-19-000069:notes:324]
The following table sets forth interest expense information related to the term loan, including interest expense associated with the ticking fee, for the periods presented (in millions):

[0001633978-19-000069:notes:325]
|  | Years Ended |
|  | June 29, 2019 |
| Contractual interest expense | $ | 13.8 |  |
| Ticking fee | 2.7 |  |
| Amortization of the debt issuance costs | 0.8 |  |
| Total interest expense | $ | 17.3 |  |


## us-gaap:LongTermDebtTextBlock

[0001633978-19-000069:notes:326]
Note 7. Term Loan Facility

[0001633978-19-000069:notes:327]
On March 11, 2018, in connection with the Oclaro merger, Lumentum entered into a commitment letter with Deutsche Bank Securities Inc. and Deutsche Bank AG New York Branch (“Deutsche Bank”), pursuant to which, Deutsche Bank committed to provide a senior secured term loan facility to finance the merger.

[0001633978-19-000069:notes:328]
On December 10, 2018 (the “Closing Date”), concurrent with the closing of the Oclaro merger, Lumentum entered into a Credit and Guarantee Agreement (the “Credit Agreement”), by and among Lumentum, certain subsidiaries of Lumentum, the lenders party thereto, and Deutsche Bank, as administrative agent and collateral agent for the lenders. The Credit Agreement provides for a senior secured term loan facility (the “Term Loan Facility”) in an aggregate principal amount of $500.0 million. The term loans available under the Term Loan Facility were fully drawn on the Closing Date and the proceeds of the term loans were used to consummate the merger and pay fees and expenses in connection with the merger and the Term Loan Facility.

[0001633978-19-000069:notes:329]
The term loans will mature on the seventh anniversary of the Closing Date, at which time all outstanding principal and accrued and unpaid interest on the term loans must be repaid.  Commencing on the last business day of the first full fiscal quarter after the Closing Date, the term loans will amortize in equal quarterly installments equal to 0.25% of the original principal amount of the Term Loans, with the balance payable due on December 10, 2025, the maturity date. We are required to make mandatory prepayments of the outstanding principal amount of term loans with the net cash proceeds from the disposition of certain assets and the receipt of insurance proceeds upon certain casualty and condemnation events, in each case, to the extent in excess of the certain threshold amounts and to the extent not reinvested within a specified time period. We are also required to make mandatory prepayments of the outstanding principal amount of term loans from the incurrence of certain types of indebtedness and from any excess cash flow beyond stated threshold amounts. We have the right to prepay the term loans, in whole or in part, at any time without premium or penalty, subject to certain limitations and a 1.00% soft call premium applicable during the first six months following the Closing Date.

[0001633978-19-000069:notes:330]
The term loans bear interest at a rate equal to an applicable margin plus, at our option, either (a) a base rate equal to the highest of (i) the prime rate then in effect, (ii) the federal funds rate, plus 0.50% and (iii) an adjusted LIBOR rate determined on the basis of a one-month interest period, plus 1.0%, subject to a floor of 0.0%, or (b) an adjusted LIBOR rate, subject to a floor of 0.0%. The applicable margin with respect to the initial term loans is equal to 2.50% in the case of LIBOR rate loans and 1.50% in the case of base rate loans. The applicable margin is adjusted following the first full fiscal quarter after the Closing Date, if our first lien net leverage ratio is equal to or less than 0.50:1.00, to 2.25% in the case of LIBOR rate loans and 1.25% in the case of base rate loans. During the year ended June 29, 2019, we recorded and paid a contractual interest expense of $13.8 million related to the term loans, this amount is included in interest and other income (expense), net in our consolidated statements of operations.

[0001633978-19-000069:notes:331]
The commitment letter with Deutsche Bank required payment of a ticking fee. During the year ended June 29, 2019, we recorded a total ticking fee of $2.7 million. This ticking fee is included in interest and other income (expense), net in our consolidated statements of operations. During the year ended June 29, 2019, we paid $2.5 million of principal on the term loan.

[0001633978-19-000069:notes:332]
The Credit Agreement permits us to add one or more incremental term loan facilities. Incremental loans are subject to certain additional conditions, including, without limitation, obtaining additional commitments from the lenders then party to the Credit Agreement or from new lenders.

[0001633978-19-000069:notes:333]
Our obligations under the Credit Agreement are required to be guaranteed by certain of our domestic subsidiaries meeting materiality thresholds set forth in the Credit Agreement. Such obligations, including the guaranties, are secured by substantially all of the assets of Lumentum and Lumentum’s subsidiary guarantors (other than customarily excluded assets) pursuant to a Pledge and Security Agreement, dated as of December 10, 2018, by and among Lumentum and Deutsche Bank.

[0001633978-19-000069:notes:334]
The Credit Agreement contains customary affirmative and negative covenants, including covenants limiting the ability of Lumentum and its restricted subsidiaries to, among other things, incur debt, grant liens, undergo certain fundamental changes, make investments, make certain restricted payments, dispose of assets, and enter into transactions with affiliates, in each case, subject to limitations and exceptions set forth in the Credit Agreement. The Credit Agreement also contains customary events of default that include, among other things, certain payment defaults, cross defaults to other indebtedness, covenant defaults, change of control defaults, judgment defaults, and bankruptcy and insolvency defaults. If an event of default exists, the lenders may require the immediate payment of all obligations under the Credit Agreement, and may exercise certain other rights and remedies provided for under the Credit Agreement, the other loan documents and applicable law. As of June 29, 2019, we were in compliance with all of the covenants.

[0001633978-19-000069:notes:335]
We incurred $9.3 million of debt issuance costs in connection with the Term Loan Facility which were capitalized and recorded as a contra liability in our consolidated balance sheet. These costs will be amortized to interest expense using the effective interest rate method from the issuance date of December 10, 2018, through the end of the term of the loan. As of June 29, 2019, the effective interest rate is 5.20% and the stated interest rate is 4.94%.

[0001633978-19-000069:notes:336]
The following table sets forth balance sheet information related to the term loan as of June 29, 2019 (in millions):

[0001633978-19-000069:notes:337]
|  | June 29, 2019 |
| Principal | $ | 500.0 |  |
| Repayment of principal | (2.5 | ) |
| Unamortized value of the debt issuance costs | (8.5 | ) |
| Net carrying value | $ | 489.0 |  |
| Term loan, current | $ | 5.0 |  |
| Term loan, non-current | 484.0 |  |


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0001633978-19-000069:notes:338]
Note 5. Business Combination

[0001633978-19-000069:notes:339]
On December 10, 2018, we acquired all of the outstanding common stock of Oclaro, a provider of optical components and modules for the long-haul, metro and data center markets. Oclaro’s products provide differentiated solutions for optical networks and high-speed interconnects driving the next wave of streaming video, cloud computing, application virtualization and other bandwidth-intensive and high-speed applications. This acquisition strengthens our product portfolio, including gaining Oclaro’s indium phosphide laser and photonic integrated circuit and coherent component and module capabilities; broadens our revenue mix; and positions us strongly to meet the future needs of our customers.

[0001633978-19-000069:notes:340]
Pursuant to the merger agreement, Prota Merger Sub, Inc., a Delaware corporation and a wholly owned subsidiary of Lumentum (“Merger Sub”), merged with and into Oclaro (the “Merger”), with Oclaro surviving the Merger. Each outstanding share of Oclaro common stock, par value $0.01 per share, was automatically converted into the right to receive the following consideration (collectively, the “Merger Consideration”), without interest:

[0001633978-19-000069:notes:341]
•$5.60 in cash (the “Cash Consideration”) and;

[0001633978-19-000069:notes:342]
| • | 0.0636 of a share of Lumentum common stock, par value $0.001 per share (the “Exchange Ratio”). |

[0001633978-19-000069:notes:343]
The total fair value of consideration given in connection with the acquisition of Oclaro consisted of the following:

[0001633978-19-000069:notes:344]
|  | Shares | Per Share | Total Consideration(in millions) |
| Cash paid for outstanding Oclaro common stock |  |  | $ | 964.8 |  |
| Lumentum common shares issued to Oclaro stockholders | 10,941,436 |  | $ | 41.80 |  | 457.4 |  |
| Replacement equity awards for Oclaro equity awards |  |  | 2.7 |  |
| Total consideration |  |  | $ | 1,424.9 |  |

[0001633978-19-000069:notes:345]
Each Oclaro restricted stock unit award (“Oclaro RSU”) that did not become vested at the close of the transaction was converted into a Lumentum restricted stock unit award (a “Lumentum RSU”) with similar terms and conditions, including vesting, that were applicable to such Oclaro RSU, at a ratio of one Oclaro share to 0.1933 shares of Lumentum common stock. The 0.1933 ratio was determined based on the sum of (i) the 0.0636 shares of common stock received by Oclaro common stockholders for every one share of Oclaro common stock, plus (ii) the $5.60 per share received by Oclaro common stockholders, divided by $43.189 (Lumentum’s average closing price for the 10 trading days ending on December 4, 2018, the third trading day prior to the Closing Date).

[0001633978-19-000069:notes:346]
Each Oclaro stock option (“Oclaro Option”), whether vested or unvested, was converted into a Lumentum stock option (“Lumentum Option”) with similar terms and conditions, including vesting, that were applicable to such Oclaro Option, except that (i) the number of shares subject to the Lumentum Option equals the number of Oclaro shares subject to such Oclaro Option multiplied by 0.1933 and (ii) the exercise price of the Lumentum Option equals the exercise price per share of the Oclaro Option divided by 0.1933. Any Oclaro Option that was held by non-employees was cancelled and converted into the right to receive the Merger Consideration for each net option share covered by such Oclaro Option, subject to applicable withholding taxes.

[0001633978-19-000069:notes:347]
In addition, each Oclaro restricted stock award (“Oclaro Restricted Stock Award”) and Oclaro RSU that became vested with the close of the transaction was converted into the right to receive the Merger Consideration.

[0001633978-19-000069:notes:348]
The total transaction consideration was $1.4 billion, which was funded by the issuance of Lumentum common stock, new debt, and cash balances of the combined company. We also recorded $18.3 million in acquisition-related costs in the year ended June 29, 2019, representing professional and other direct acquisition costs. These costs are recorded within selling, general and administrative operating expense and within interest and other income (expense), net in our consolidated statements of operations. The Company also incurred $9.3 million of debt financing costs which has been recorded as a contra liability. “Refer to Note 7. Term Loan Facility.”

[0001633978-19-000069:notes:349]
From the acquisition date, Oclaro contributed $250.1 million of our consolidated net revenue for the year ended June 29, 2019. Due to the continued integration of the combined businesses, it is impractical to determine Oclaro’s contribution to our net income.

[0001633978-19-000069:notes:350]
We allocated the fair value of the purchase consideration to the tangible assets, liabilities and intangible assets acquired, including in-process research and development, or IPR&D, generally based on their estimated fair values. The excess purchase price over those fair values is recorded as goodwill. IPR&D is initially capitalized at fair value as an intangible asset with an indefinite life  and assessed for impairment thereafter. When an IPR&D project is completed, the IPR&D is reclassified as an amortizable purchased intangible asset and amortized over the asset’s estimated useful life.  Our valuation assumptions of acquired assets and assumed liabilities require significant estimates, especially with respect to intangible assets. Our preliminary allocation of the purchase price of Oclaro, based on the estimated fair values of the assets acquired and liabilities assumed as of the acquisition date, is as follows (in millions):

[0001633978-19-000069:notes:351]
|  | Purchase Price Allocation |
|  | Previously ReportedDecember 10, 2018 (Provisional) | Measurement Period Adjustments | As AdjustedJune 29, 2019 |
| Cash and cash equivalents | $ | 345.0 |  | $ | — |  | $ | 345.0 |  |
| Accounts receivable, net | 68.0 |  | — |  | 68.0 |  |
| Inventories | 153.2 |  | 1.8 |  | 155.0 |  |
| Prepayments and other current assets | 33.7 |  | — |  | 33.7 |  |
| Property, plant and equipment, net | 128.6 |  | 6.1 |  | 134.7 |  |
| Intangibles | 444.0 |  | — |  | 444.0 |  |
| Deferred income tax asset | 54.1 |  | (11.5 | ) | 42.6 |  |
| Other non-current assets | 16.6 |  | — |  | 16.6 |  |
| Accounts payable | (57.8 | ) | — |  | (57.8 | ) |
| Accrued payroll and related expenses | (11.4 | ) | — |  | (11.4 | ) |
| Accrued expenses | (8.3 | ) | — |  | (8.3 | ) |
| Other current liabilities | (8.1 | ) | 2.0 |  | (6.1 | ) |
| Deferred tax liability | (55.8 | ) | (20.0 | ) | (75.8 | ) |
| Other non-current liabilities | (10.3 | ) | (2.6 | ) | (12.9 | ) |
| Goodwill | 333.4 |  | 24.2 |  | 357.6 |  |
| Total purchase price | $ | 1,424.9 |  | $ | — |  | $ | 1,424.9 |  |

[0001633978-19-000069:notes:352]
The provisional amounts presented in the table above pertained to the preliminary purchase price allocation reported in our Form 10-Q for the quarter ended December 29, 2018. The measurement period adjustments were primarily related to the sale of several product lines within our Datacom business based in Sagamihara, Japan and the transfer of related employees to Cambridge Industries Group (“CIG”). This business was acquired on December 10, 2018 as part of the acquisition of Oclaro. These assets and liabilities were recorded at fair value less cost to sell and the adjustments to fair value were recorded as measurement period adjustments. The measurement period adjustments also included tax  adjustment of $31.5 million upon the completion of additional analysis involving refining the amount of Oclaro’s tax attributes that may be utilizable going forward, deferred tax asset valuation allowances, and the effects of the Tax Act.

[0001633978-19-000069:notes:353]
The merger consideration allocation set forth herein is preliminary and may be revised as additional information becomes available during the measurement period which could be up to 12 months from the closing date of the acquisition. Any such revisions or changes may be material.

[0001633978-19-000069:notes:354]
We do not believe that the measurement period adjustments had a material impact on our consolidated statements of operations, balance sheets or cash flows in any periods previously reported.

[0001633978-19-000069:notes:355]
Goodwill and intangibles have been assigned to the OpComms segment. The preliminary goodwill of $357.6 million arising from the acquisition is attributed to the expected synergies, including future cost efficiencies, and other benefits that are expected to be generated by combining Lumentum and Oclaro. Substantially all of the goodwill recognized is not expected to be deductible for tax purposes. See “Note 6. Goodwill and Other Intangible Assets” for more information on goodwill and IPR&D.

[0001633978-19-000069:notes:356]
During the second quarter of fiscal 2019, we recorded $20.9 million in restructuring and stock-based compensation expense in our consolidated statements of operations, attributable to severance and employee related benefits associated with Oclaro’s executive severance and retention agreements. These retention agreements provide, under certain circumstances, for payments and benefits upon an involuntary termination of employment, including following a change in control of Oclaro. The payments and benefits payable under these arrangements in the event of a change in control of Oclaro are subject to a “double trigger,” meaning that both a change in control of Oclaro and a subsequent involuntary termination of employment by Lumentum are required.  In other words, the change in control of Oclaro does not by itself trigger any payments or benefits. Instead, payments and benefits are paid only if the employment of the employee is subsequently terminated without “cause” (or the employee resigns for “good reason”) during a specified period following the change in control. We incurred total expense of $20.9 million during the second quarter of fiscal 2019, of which $5.7 million relates to cash severance as part of our restructuring expense which is recorded within restructuring and related charges in our consolidated statements of operations (refer to “Note 14. Restructuring and Related Charges”) and $15.2 million relates to the acceleration of equity awards which is recorded within both cost of sales and selling, general and administrative expense, in our consolidated statements of operations (refer to “Note 17. Stock-Based Compensation and Stock Plans”).

[0001633978-19-000069:notes:357]
We continually evaluate our existing portfolio of businesses to maximize long-term shareholder value. As discussed above, we sold several product lines within our Datacom business based in Sagamihara, Japan along with the transfer of the related employees to CIG for $25.5 million in net cash. The disposition was completed on April 18, 2019. This business did not meet the criteria for assets held-for-sale under the relevant accounting guidance as of December 10, 2018, the date of our acquisition of Oclaro, in our purchase price allocation. The assets and liabilities transferred to CIG were $33.5 million and $7.0 million, respectively.

[0001633978-19-000069:notes:358]
Assets and liabilities transferred as a result of this disposition on April 18, 2019 were as follows (in millions):

[0001633978-19-000069:notes:359]
| Assets: |  |
| Cash | $ | 1.0 |  |
| Inventories | 4.8 |  |
| Other Intangible assets | 1.0 |  |
| Property, plant and equipment, net | 26.7 |  |
| Total | $ | 33.5 |  |
| Liabilities: |  |
| Retirement obligation | $ | 4.9 |  |
| Capital lease obligation | 0.8 |
| Other liabilities | 1.3 |
| Total | $ | 7.0 |  |
| Net | $ | 26.5 |  |

[0001633978-19-000069:notes:360]
As part of the transaction, we will also provide transition services to CIG for a period of up to 24 months and the cost of these services will be reimbursed to us by CIG. The purpose of these services is to provide short-term assistance to the buyer in assuming the operations of the purchased business.

[0001633978-19-000069:notes:361]
Supplemental Pro Forma Information

[0001633978-19-000069:notes:362]
The supplemental pro forma financial information presented below is for illustrative purposes only and is not necessarily indicative of the financial position or results of operations that would have been realized if the acquisition had been completed on the date indicated, does not reflect synergies that might have been achieved, nor is it indicative of future operating results or financial position. The pro forma adjustments are based upon currently available information and certain assumptions we believe are reasonable under the circumstances.

[0001633978-19-000069:notes:363]
The following supplemental pro forma information presents the combined results of operations for the years ended June 29, 2019 and June 30, 2018, as if Oclaro had been acquired as of the beginning of fiscal year 2018. The supplemental pro forma information includes adjustments to amortization and depreciation for acquired intangible assets and property and equipment, adjustments to share-based compensation expense, the fair value adjustments on the inventories acquired, transaction costs, interest expense and amortization of the term loan debt issuance costs. For fiscal year 2018, nonrecurring pro forma adjustments directly attributable to the Oclaro acquisition included (i) restructuring and stock-based compensation expense of $20.9 million, (ii) the purchase accounting effect of inventories acquired of $60.3 million and (iii) transaction costs of $25.5 million.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001633978-19-000069:notes:364]
Accounting Pronouncements Recently Adopted

[0001633978-19-000069:notes:365]
In May 2014, the Financial Accounting Standards Board (“FASB”) issued ASU 2014-09 (Topic 606), which amended the existing accounting standards for revenue recognition. Topic 606 outlines a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers. The guidance is effective for annual reporting periods including interim reporting periods beginning after December 15, 2017. On July 1, 2018, we adopted Topic 606 using the modified retrospective method applied to all contracts that are not completed contracts at the date of initial adoption (i.e., July 1, 2018). Results for reporting periods after July 1, 2018 are presented under Topic 606, while prior period amounts are not adjusted and continue to be reported in accordance with our historical accounting under Topic 605. The adoption of Topic 606 did not have a material impact on the nature and timing of our revenues, consolidated statements of operations, cash flows and balance sheets and therefore, we do not present results for the year ended June 29, 2019 under Topic 605. Refer to “Note 1. Description of Business and Summary of Significant Accounting Policies” for the changes in our accounting policies due to adoption of Topic 606.

[0001633978-19-000069:notes:366]
Select consolidated balance sheet line items, as if we had adopted Topic 606 prior to July 1, 2018 are summarized below as of the periods presented (in millions):

[0001633978-19-000069:notes:367]
|  | June 30, 2018 |  | Adjustments |  | July 1, 2018 |
| Assets: |  |  |  |  |  |
| Accounts receivable, net | $ | 197.1 |  |  | $ | 0.6 |  |  | $ | 197.7 |  |
| Inventories | 174.1 |  |  | (1.2 | ) |  | 172.9 |  |
| Stockholders’ equity: |  |  |  |  |  |
| Retained earnings | $ | 166.4 |  |  | $ | (0.6 | ) |  | $ | 165.8 |  |

[0001633978-19-000069:notes:368]
In August 2016, FASB issued ASU 2016-15, Statement of Cash Flows (Topic 230): Classification of Certain Cash Receipts and Cash Payments, which clarifies how companies present and classify certain cash receipts and cash payments in the statement of cash flows. The amendments contained in ASU 2016-15 are effective for interim and annual periods beginning after December 15, 2017. We adopted ASU 2016-15 on July 1, 2018 on a prospective basis. The application of ASU 2016-15 will have a material impact on our consolidated financial statements if we elect to settle the principal amounts of our 2024 Notes (refer to “Note 13. Convertible Notes”) in cash, and upon the repayment of the term loan (refer to “Note 7. Term Loan Facility”). The principal repayment will be bifurcated between (i) cash outflows for operating activities of $146.9 million for the portion related to accreted interest attributable to debt discount, and (ii) financing activities for the remainder of $803.1 million.

[0001633978-19-000069:notes:369]
In January 2017, FASB issued ASU 2017-01, Business Combinations (Topic 805), which clarifies the definition of a business. For accounting and financial reporting purposes, businesses are generally comprised of three elements: inputs, processes, and outputs. Integrated sets of assets and activities capable of providing these three elements may not always be considered a business, and the lack of one of the three elements does not always disqualify the set from being a business. The issuance of ASU 2017-01 provides a clarifying test to determine when a set of assets and activities is not a business. Primarily, the test requires that when substantially all of the fair value of the gross assets acquired is concentrated in a single identifiable asset or group of similar identifiable assets, the set is not a business. The amendments contained in ASU 2017-01 are effective for annual periods beginning after December 15, 2017, including interim periods within those periods. We adopted ASU 2017-01 on July 1, 2018 on a prospective basis. The implementation of ASU 2017-01 did not have an impact on our consolidated financial statements.

[0001633978-19-000069:notes:370]
In October 2016, FASB issued ASU 2016-16, Accounting for Income Taxes: Intra-Entity Asset Transfers of Assets other than Inventory. The new guidance removes the prohibition against the immediate recognition of the current and deferred income tax effects of intra-entity transfers of assets other than inventory. The new guidance became effective for us in the first quarter of our fiscal 2019. The adoption of ASU 2016-16 did not have a material impact on our consolidated financial statements.

[0001633978-19-000069:notes:371]
In August 2018, FASB issued ASU 2018-15, Intangibles-Goodwill and Other-Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract. ASU 2018-15 requires an entity in a hosting arrangement that is a service contract to follow the guidance in Subtopic 350-40 to determine which implementation costs to capitalize as an asset related to the service contract and which costs to expense. Implementation costs capitalized must be expensed over the term of the hosting arrangement, including the period covered by an option to extend the arrangement. The standard is effective for fiscal years beginning after December 15, 2019, and interim periods within those fiscal years, and should be applied either retrospectively or prospectively to all implementation costs incurred after the date of adoption. Early adoption is permitted, including adoption in any interim period, for all entities. We early adopted ASU 2018-15, which did not have a material impact on our consolidated financial statements.

[0001633978-19-000069:notes:372]
In August 2018, the Securities and Exchange Commission (“SEC”) adopted amendments to certain disclosure requirements in Securities Act Release No. 33-10532, Disclosure Update and Simplification. Among the amendments is the requirement to present the changes in stockholders’ equity in the interim financial statements (either in a separate statement or footnote) in quarterly reports on Form 10-Q. The analysis should present a reconciliation of the beginning balance to the ending balance of each period for which a consolidated statement of operations is required to be filed. The final rule was effective on November 5, 2018. The Company adopted the final rule in our third quarter of fiscal 2019, and has included a reconciliation of the changes in statements of redeemable convertible preferred stock and stockholders' equity in the Form 10-Q for the fiscal quarter ended March 30, 2019 filed with the Securities and Exchange Commission.

[0001633978-19-000069:notes:373]
Accounting Pronouncements Not Yet Effective

[0001633978-19-000069:notes:374]
In August 2018, FASB issued ASU 2018-14, Compensation-Retirement Benefits-Defined Benefit Plans-General (Topic 715-20): Disclosure Framework-Changes to the Disclosure Requirements for Defined Benefit Plans. ASU 2018-14 modifies the disclosure requirements for defined benefit pension plans and other postretirement benefit plans. The new guidance is effective for fiscal years ending after December 15, 2020 and early adoption is permitted. ASU 2018-14 should be applied retrospectively to all periods presented and is effective for us in our fiscal 2021. We are currently evaluating the impact of ASU 2018-14 on our consolidated financial statements and related disclosures.

[0001633978-19-000069:notes:375]
In August 2018, FASB issued ASU 2018-13, Fair Value Measurement (Topic 820): Disclosure Framework-Changes to the Disclosure Requirements for Fair Value Measurement. ASU 2018-13 modifies the disclosure requirements for fair value measurements. The new guidance is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019 and early adoption is permitted. ASU 2018-13 requires that certain of the amendments be applied prospectively, while other amendments should be applied retrospectively to all periods presented. ASU 2018-13 is effective for us in our first quarter of fiscal 2021. We are currently evaluating the impact of ASU 2018-13 on our consolidated financial statements and related disclosures.

[0001633978-19-000069:notes:376]
In February 2018, FASB issued ASU 2018-02, Income Statement-Reporting Comprehensive Income (Topic 220): Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income, which allows companies to reclassify stranded tax effects resulting from the Tax Act, from accumulated other comprehensive income to retained earnings. The guidance also requires certain new disclosures regardless of the election. The amendments in ASU 2018-02 are effective for all entities for fiscal years beginning after December 15, 2018, and interim periods within those fiscal years. Early adoption is permitted. ASU 2018-02 is effective for us in the first quarter of fiscal 2020. The implementation of ASU 2018-02 will not have a material impact on our consolidated financial statements and related disclosures.

[0001633978-19-000069:notes:377]
In January 2017, FASB issued ASU 2017-04, Intangibles - Goodwill and Other (Topic 350): Simplifying the Accounting for Goodwill Impairment. ASU 2017-04 removes the requirement to perform a hypothetical purchase price allocation to measure goodwill impairment. A goodwill impairment charge will be the amount by which a reporting unit's carrying value exceeds its fair value, not to exceed the carrying amount of goodwill. The amendments contained in ASU 2017-04 are effective for interim and annual periods beginning after December 15, 2019, with early adoption permitted, which should be applied prospectively. ASU 2017-14 is effective for us in our first quarter of fiscal 2020. The implementation of ASU 2017-04 will not have a material impact on our consolidated financial statements and related disclosures.

[0001633978-19-000069:notes:378]
In June 2016, FASB issued ASU 2016-13, Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments and subsequent amendments, ASU 2018-19, ASU 2019-04 and ASU 2019-05 (collectively, Topic 326). Topic 326 requires measurement and recognition of expected credit losses for financial assets held. Topic 326 is effective for annual periods beginning after December 15, 2019, including interim periods within those periods, with early adoption permitted. ASU 2016-13 is effective for us in our fiscal 2021. We are currently evaluating the impact of the adoption of Topic 326 on our consolidated financial statements and related disclosures.

[0001633978-19-000069:notes:379]
In February 2016, FASB issued ASU 2016-02, Leases (Topic 842) and subsequent amendments to the initial guidance: ASU 2017-13, ASU 2018-10, ASU 2018-11, ASU 2018-20 and ASU 2019-01 (collectively, Topic 842). The new guidance generally requires an entity to recognize on its balance sheet operating and financing lease liabilities and corresponding right-of-use assets. The new guidance contained in Topic 842 is effective for annual periods beginning after December 15, 2018, including interim periods within those periods, with early adoption permitted. The standard is effective for us in our first quarter of fiscal 2020 and provides an optional transition method that allows entities to apply the standard prospectively, with any cumulative-effect adjustment recorded to opening retained earnings in the period of adoption. We will adopt the new standard using this optional transition method.  We have elected the practical expedients to not reassess prior conclusions related to contracts containing leases, lease classification, and initial direct costs for contracts that existed prior to adoption date. We have also elected to combine lease and non-lease components and to keep leases with an initial term of 12 months or less off the balance sheet and recognize the associated lease payments in the consolidated statements of operations on a straight-line basis over the lease term. We expect to recognize operating lease right-of-use assets between $90.0 million to $100.0 million and operating lease liabilities between $80.0 million to $90.0 million on our condensed consolidated balance sheet as of the date of adoption, June 30, 2019. The difference between the operating lease right-of-use assets and operating lease liabilities primarily represents the existing asset recognized in relation to the favorable terms of an operating lease acquired through a business combination offset by our deferred rent balances. Our accounting for finance leases is not expected to change substantially from the legacy Topic 840. Other than disclosed, we do not expect the new standard to have a material impact on our remaining consolidated financial statements.


## us-gaap:OtherCurrentLiabilitiesTableTextBlock

[0001633978-19-000069:notes:380]
The components of other current liabilities were as follows (in millions):

[0001633978-19-000069:notes:381]
|  | June 29, 2019 |  | June 30, 2018 |
| Warranty accrual (1) | $ | 7.5 |  |  | $ | 6.6 |  |
| Restructuring accrual and related charges (2) | 14.6 |  |  | 1.9 |  |
| Deferred revenue and customer deposits | 2.9 |  |  | 2.8 |  |
| Capital lease obligation (3) | 0.4 |  |  | 7.3 |  |
| Income tax payable (4) | 8.7 |  |  | 0.7 |  |
| Other current liabilities | 5.1 |  |  | 2.8 |  |
| Other current liabilities | $ | 39.2 |  |  | $ | 22.1 |  |

[0001633978-19-000069:notes:382]
(1) Refer to “Note 19. Commitments and Contingencies.”

[0001633978-19-000069:notes:383]
(2) Refer to “Note 14. Restructuring and Related Charges.”

[0001633978-19-000069:notes:384]
(3) In addition to the $0.4 million of capital lease obligations recorded within other current liabilities, we also recorded $0.4 million within accounts payable in the consolidated balance sheet as of June 29, 2019. Refer to “Note 19. Commitments and Contingencies”

[0001633978-19-000069:notes:385]
(4) Refer to “Note 16. Income Taxes.”


## us-gaap:OtherNoncurrentLiabilitiesTableTextBlock

[0001633978-19-000069:notes:386]
The components of other non-current liabilities were as follows (in millions):

[0001633978-19-000069:notes:387]
|  | June 29, 2019 |  | June 30, 2018 |
| Asset retirement obligation | $ | 4.5 |  |  | $ | 2.7 |  |
| Pension and related accruals (1) | 7.9 |  |  | 3.5 |  |
| Deferred rent | 2.2 |  |  | 2.6 |  |
| Unrecognized tax benefit | 18.7 |  |  | 6.1 |  |
| Capital lease obligation | — |  |  | 0.4 |  |
| Other non-current liabilities | 0.4 |  |  | 3.4 |  |
| Other non-current liabilities | $ | 33.7 |  |  | $ | 18.7 |  |

[0001633978-19-000069:notes:388]
(1) In connection with our acquisitions of Oclaro in fiscal 2019 and Time-Bandwidth in fiscal 2014, we assumed defined benefit plans for Japan and Switzerland employees, respectively. As of June 29, 2019, the projected benefit obligations for Japanese and Swiss employees were $2.8 million and $5.0 million, respectively, and were included in other non-current liabilities in our consolidated balance sheet. Refer to “Note 18. Employee Benefit Plans” for more details. Pension and related accruals as of June 29, 2019 also include $0.1 million attributable to post-retirement benefits for executives.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001633978-19-000069:notes:389]
Note 18. Employee Benefit Plans

[0001633978-19-000069:notes:390]
401(k) Plan

[0001633978-19-000069:notes:391]
In the United States, the Company sponsors the Lumentum 401(k) Retirement Plan (the “401(k) Plan”), a defined contribution plan under ERISA, which provides retirement benefits for its eligible employees through tax deferred salary deductions. The 401(k) Plan allows employees to contribute up to 50% of their annual compensation, with contributions limited to $19,000 in calendar year 2019 as set by the Internal Revenue Service.

[0001633978-19-000069:notes:392]
Employees are eligible for matching contributions after completing 180 days of service. The Company’s match is contributed on a per-pay-period basis and is based on employees’ before-tax contributions and compensation each pay period. All matching contributions are made in cash and vest immediately under the 401(k) Plan. In fiscal 2019 and 2018, we made matching contributions to the 401(k) Plan in the amount of $3.7 million and $3.4 million, respectively.

[0001633978-19-000069:notes:393]
Canada Retirement Plans

[0001633978-19-000069:notes:394]
In Canada, the Company sponsors the Group Registered Retirement Savings Plan (the “RRSP”) and Deferred Profit Sharing Plan (the “DPSP”), defined contribution plans which provide retirement benefits for eligible employees through tax deferred salary deductions.

[0001633978-19-000069:notes:395]
The RRSP allows employees to contribute up to 5% of their eligible earnings in a pay period, with contributions limited to C$26,500 ($20,250 based on the applicable exchange rate as of June 29, 2019) in calendar year 2019 as set by the Canada Revenue Agency. Based on the employee’s contribution to the RRSP, the Company makes a matching contribution to the DPSP. The Company makes a 100% matching contribution on the first 3% of the employees’ before-tax contributions and a 50% matching contribution on the following 2% of the employees’ before-tax contributions, up to an annual maximum of C$4,000.

[0001633978-19-000069:notes:396]
The Company’s match is contributed on a per-pay-period basis and is based on employees’ before-tax contributions and compensation each pay period. Employees are eligible for matching contributions after completing 180 days of service. In fiscal 2019 and 2018, we made matching contributions in the amount of $1.0 million and $1.3 million into the DPSP.

[0001633978-19-000069:notes:397]
U.K. Defined Contribution Plan

[0001633978-19-000069:notes:398]
In connection with the acquisition of Oclaro in December 2018, we assumed a defined contribution plan which provides retirement benefits to employees in the U.K. Contributions under this plan from the acquisition date were $0.9 million in fiscal 2019.

[0001633978-19-000069:notes:399]
Japan Defined Contribution Plan

[0001633978-19-000069:notes:400]
In connection with the acquisition of Oclaro in December 2018, we assumed a defined contribution plan which provides retirement benefits to employees in Japan. Under the defined contribution plan, contributions are provided based on grade level and totaled $0.2 million for period from the acquisition date through June 29, 2019. Employees can elect to receive the benefit as additional salary or contribute the benefit to the plan on a tax-deferred basis.

[0001633978-19-000069:notes:401]
Switzerland Defined Benefit Plan

[0001633978-19-000069:notes:402]
In connection with the acquisition of Time-Bandwidth during fiscal 2014, we assumed a defined benefit plan which covers certain employees in Switzerland (the “Switzerland Plan”). The Switzerland Plan is open to new participants. Benefits are generally based upon an employee’s age and compensation. As of June 29, 2019, the Switzerland Plan was partially funded. Our policy for partially funded plans is to make contributions equal to or greater than the requirements prescribed by law or regulation; however, at our discretion, we can elect to make additional contributions to the plan.

[0001633978-19-000069:notes:403]
We account for our obligations under the Switzerland Plan in accordance with the authoritative guidance which requires us to record our obligation to the participants, as well as the corresponding net periodic cost. We determine our obligation to the participants and our net periodic cost principally using actuarial valuations provided by third-party actuaries. The net obligation of $5.0 million as of June 29, 2019 is recorded in our consolidated balance sheets as non-current liabilities and is reflective of the total projected benefit obligation (“PBO”) less the fair value of plan assets.

[0001633978-19-000069:notes:404]
Net periodic pension cost associated with the Switzerland Plan in fiscal 2019, 2018 and 2017 include the following components:

[0001633978-19-000069:notes:405]
|  | 2019 |  | 2018 |  | 2017 |
| Service cost | $ | 0.9 |  |  | $ | 0.9 |  |  | $ | 0.6 |  |
| Interest cost | 0.1 |  |  | 0.1 |  |  | — |  |
| Expected return on plan assets | (0.3 | ) |  | (0.2 | ) |  | (0.1 | ) |
| Amortization of net (gain) loss | 0.1 |  |  | 0.2 |  |  | 0.2 |  |
| Net periodic pension cost | $ | 0.8 |  |  | $ | 1.0 |  |  | $ | 0.7 |  |

[0001633978-19-000069:notes:406]
Assumptions

[0001633978-19-000069:notes:407]
Underlying both the calculation of the PBO and net periodic cost are actuarial valuations. These valuations use participant-specific information such as salary, age and assumptions about interest rates, compensation increases and other factors. At a minimum, we evaluate these assumptions annually and make changes as necessary.

[0001633978-19-000069:notes:408]
The discount rate reflects the estimated rate at which the pension benefits could be effectively settled. In developing the discount rate, we consider the yield available on an appropriate AA or AAA corporate bond index, adjusted to reflect the term of the plan’s liabilities.

[0001633978-19-000069:notes:409]
The expected return on assets was estimated by using the weighted average of the real expected long-term return (net of inflation) on the relevant classes of assets based on the target asset mix and adding the chosen inflation assumption.

[0001633978-19-000069:notes:410]
The following table summarizes the assumptions used to determine net periodic cost and benefit obligation for the Switzerland Plan:

[0001633978-19-000069:notes:411]
|  | Pension Benefit Plans |
|  | 2019 |  | 2018 |
| Assumptions used to determine net periodic cost: |  |  |  |
| Discount rate | 0.5 | % |  | 0.7 | % |
| Expected long-term return on plan assets | 3.2 | % |  | 2.8 | % |
| Salary increase rate | 2.3 | % |  | 2.3 | % |
| Assumptions used to determine benefit obligation at end of year: |  |  |  |
| Discount rate | 0.5 | % |  | 1.0 | % |
| Salary increase rate | 2.3 | % |  | 2.3 | % |

[0001633978-19-000069:notes:412]
Fair Value Measurement of Plan Assets

[0001633978-19-000069:notes:413]
The following table sets forth the plan’s assets at fair value and the percentage of assets allocations as of June 29, 2019 (in millions, except percentage data):

[0001633978-19-000069:notes:414]
|  |  |  |  |  |  | Fair value measurement as of June 29, 2019 |
|  | Target Allocation | Total |  | Percentage of Plan Asset |  | Quoted Prices in Active Markets for Identical Assets(Level 1) |  | Significant Other Observable Inputs (Level 2) |
| Assets: |  |  |  |  |  |  |  |  |  |
| Global equity | 28 | % |  | $ | 2.3 |  |  | 28 | % |  | $ | — |  |  | $ | 2.3 |  |
| Fixed income | 30 | % |  | 2.6 |  |  | 31 | % |  | — |  |  | 2.6 |  |
| Alternative investment | 21 | % |  | 1.3 |  |  | 16 | % |  | — |  |  | 1.3 |  |
| Cash | 1 | % |  | 0.3 |  |  | 3 | % |  | 0.3 |  |  | — |  |
| Other | 20 | % |  | 1.8 |  |  | 22 | % |  | — |  |  | 1.8 |  |
| Total Assets | 100 | % |  | $ | 8.3 |  |  | 100 | % |  | $ | 0.3 |  |  | $ | 8.0 |  |

[0001633978-19-000069:notes:415]
The following table sets forth the plan’s assets at fair value and the percentage of assets allocations as of June 30, 2018 (in millions, except percentage data):

[0001633978-19-000069:notes:416]
|  |  |  |  |  |  | Fair value measurement as of June 30, 2018 |
|  | Target Allocation | Total |  | Percentage of Plan Asset |  | Quoted Prices in Active Markets for Identical Assets |  | Significant Other Observable Inputs (Level 2) |
| Assets: |  |  |  |  |  |  |  |  |  |
| Global equity | 28 | % |  | $ | 2.4 |  |  | 28 | % |  | $ | — |  |  | $ | 2.4 |  |
| Fixed income | 30 | % |  | 2.8 |  |  | 33 | % |  | — |  |  | 2.8 |  |
| Alternative investment | 18 | % |  | 1.5 |  |  | 17 | % |  | — |  |  | 1.5 |  |
| Cash | 1 | % |  | 0.2 |  |  | 1 | % |  | 0.2 |  |  | — |  |
| Other | 23 | % |  | 1.7 |  |  | 21 | % |  | — |  |  | 1.7 |  |
| Total Assets |  |  | $ | 8.6 |  |  | 100 | % |  | $ | 0.2 |  |  | $ | 8.4 |  |

[0001633978-19-000069:notes:417]
Our pension assets consist of multiple institutional funds (“pension funds”) of which the fair values are based on the quoted prices of the underlying funds. Pension funds are classified as Level 2 assets since such funds are not directly traded in active markets. Global equity consists of several funds that invest primarily in Swiss and foreign equities; fixed income consists of several funds that invest primarily in investment grade domestic and overseas bonds; Other consists of several funds that primarily invest in hedge fund, private equity, global real estate and infrastructure funds.

[0001633978-19-000069:notes:418]
Future Benefit Payments

[0001633978-19-000069:notes:419]
We estimate our expected benefit payments to defined benefit pension plan participants based on the same assumptions used to measure our PBO at year end which includes benefits attributable to estimated future compensation increases. Based on this approach, we expect future benefit payments to be $0.6 million during the 10 year period between fiscal 2020 and fiscal 2029 and the remaining $4.4 million of payments in fiscal years subsequent to fiscal 2029.

[0001633978-19-000069:notes:420]
Japan Defined Benefit Plan

[0001633978-19-000069:notes:421]
In connection with the acquisition of Oclaro in December 2018, we assumed a defined benefit plan which provides benefits to employees in Japan (the “Japan Plan”). The Japan Plan is open to new participants. Benefits are generally based upon an employee’s individual grade level and years of service. Employees are entitled to a lump sum benefit upon retirement or upon certain instances of termination. As of June 29, 2019, there were no Japan Plan assets.

[0001633978-19-000069:notes:422]
We account for our obligations under the Japan Plan in accordance with the authoritative guidance which requires us to record our obligation to the participants, as well as the corresponding net periodic cost. We determine our obligation to the participants and our net periodic cost principally using actuarial valuations provided by third-party actuaries. The net obligation of $2.8 million as of June 29, 2019 is recorded in our consolidated balance sheets as non-current liabilities and is reflective of the total PBO.

[0001633978-19-000069:notes:423]
Net periodic pension cost associated with the Japan Plan in fiscal 2019 includes the following components:

[0001633978-19-000069:notes:424]
|  | 2019 |
| Service cost | $ | 0.3 |  |
| Interest cost | * |  |
| Net periodic pension cost | $ | 0.3 |  |

[0001633978-19-000069:notes:425]
*  Less than $0.05 million

[0001633978-19-000069:notes:426]
Underlying both the calculation of the PBO and the net periodic cost are actuarial valuations. These valuations use participant-specific information such as salary, age and assumptions about interest rates, compensation increases and other factors. At a minimum, we evaluate these assumptions annually and make changes as necessary.

[0001633978-19-000069:notes:427]
The discount rate reflects the estimated rate at which the pension benefits could be effectively settled. In calculating the discount rate, we consider the yield available on an appropriate rates of fixed income governmental bonds, adjusted to reflect the term of the plan’s liabilities.

[0001633978-19-000069:notes:428]
The following table summarizes the assumptions used to determine the net pension cost and benefit obligation for the Japan Plan:

[0001633978-19-000069:notes:429]
|  | 2019 |
| Assumptions used to determine net periodic cost: |  |
| Discount rate | 0.3 | % |
| Salary increase rate | 2.1 | % |
| Assumptions used to determine benefit obligation at end of year: |  |
| Discount rate | 0.1 | % |
| Salary increase rate | 2.0 | % |

[0001633978-19-000069:notes:430]
We estimate our expected benefit payments to the Japan Plan participants based on the same assumptions used to measure our PBO at year end which includes benefits attributable to estimated future compensation increases. Based on this approach, we expect future benefit payments to be $1.9 million during the 10 year period between fiscal 2020 and fiscal 2029 and the remaining $0.9 million of payments in fiscal years subsequent to fiscal 2029.


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001633978-19-000069:notes:431]
The components of property, plant and equipment, net were as follows (in millions):

[0001633978-19-000069:notes:432]
|  | June 29, 2019 |  | June 30, 2018 |
| Land | $ | 44.2 |  |  | $ | 10.6 |  |
| Buildings and improvement | 103.7 |  |  | 55.1 |  |
| Machinery and equipment (1) | 516.5 |  |  | 463.6 |  |
| Computer equipment and software | 25.4 |  |  | 26.3 |  |
| Furniture and fixtures | 4.9 |  |  | 2.2 |  |
| Leasehold improvements | 31.2 |  |  | 25.8 |  |
| Construction in progress | 46.8 |  |  | 52.6 |  |
|  | 772.7 |  |  | 636.2 |  |
| Less: Accumulated depreciation (1) | (339.4 | ) |  | (329.3 | ) |
| Property, plant and equipment, net | $ | 433.3 |  |  | $ | 306.9 |  |

[0001633978-19-000069:notes:433]
(1) Included in the table above are our capital lease assets of $16.0 million, gross and $11.2 million in accumulated depreciation as of June 29, 2019, and $15.6 million, gross and $5.2 million in accumulated depreciation as of June 30, 2018.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001633978-19-000069:notes:434]
Note 21. Quarterly Financial Information (Unaudited)

[0001633978-19-000069:notes:435]
The following table presents our quarterly consolidated statements of operations for fiscal 2019 and 2018 (in millions, except per share data):

[0001633978-19-000069:notes:436]
|  | June 29, 2019 |  | March 30, 2019 |  | December 29, 2018 |  | September 29, 2018 |  | June 30, 2018 |  | March 31, 2018 |  | December 30, 2017 |  | September 30, 2017 |
| Net revenue | $ | 404.6 |  |  | $ | 432.9 |  |  | $ | 373.7 |  |  | $ | 354.1 |  |  | $ | 301.1 |  |  | $ | 298.8 |  |  | $ | 404.6 |  |  | $ | 243.2 |  |
| Cost of sales | 304.6 |  |  | 316.5 |  |  | 244.5 |  |  | 227.3 |  |  | 204.8 |  |  | 201.0 |  |  | 232.7 |  |  | 173.9 |  |
| Amortization of acquired intangibles | 13.2 |  |  | 28.1 |  |  | 4.4 |  |  | 0.8 |  |  | 0.8 |  |  | 0.8 |  |  | 0.8 |  |  | 0.8 |  |
| Gross profit | 86.8 |  |  | 88.3 |  |  | 124.8 |  |  | 126.0 |  |  | 95.5 |  |  | 97.0 |  |  | 171.1 |  |  | 68.5 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 49.5 |  |  | 57.7 |  |  | 42.8 |  |  | 34.6 |  |  | 38.5 |  |  | 38.2 |  |  | 43.8 |  |  | 36.3 |  |
| Selling, general and administrative | 49.4 |  |  | 55.2 |  |  | 62.7 |  |  | 33.0 |  |  | 32.7 |  |  | 33.2 |  |  | 35.7 |  |  | 26.6 |  |
| Restructuring and related charges | 1.7 |  |  | 21.1 |  |  | 7.8 |  |  | 1.3 |  |  | 3.4 |  |  | 0.1 |  |  | 0.8 |  |  | 2.9 |  |
| Impairment charges | — |  |  | 30.7 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total operating expenses | 100.6 |  |  | 164.7 |  |  | 113.3 |  |  | 68.9 |  |  | 74.6 |  |  | 71.5 |  |  | 80.3 |  |  | 65.8 |  |

[0001633978-19-000069:notes:437]
| Income/(loss) from operations | (13.8 | ) |  | (76.4 | ) |  | 11.5 |  |  | 57.1 |  |  | 20.9 |  |  | 25.5 |  |  | 90.8 |  |  | 2.7 |  |
| Unrealized gain (loss) on derivative liability | — |  |  | — |  |  | 10.9 |  |  | (2.1 | ) |  | 7.8 |  |  | (20.7 | ) |  | 7.9 |  |  | 4.2 |  |
| Interest and other income (expense), net | (7.3 | ) |  | (6.1 | ) |  | (4.7 | ) |  | (2.4 | ) |  | (1.0 | ) |  | (2.1 | ) |  | (3.2 | ) |  | (3.4 | ) |
| Income/(loss) before income taxes | (21.1 | ) |  | (82.5 | ) |  | 17.7 |  |  | 52.6 |  |  | 27.7 |  |  | 2.7 |  |  | 95.5 |  |  | 3.5 |  |
| Provision for (benefit from) income taxes | 4.7 |  |  | (8.2 | ) |  | 1.4 |  |  | 5.2 |  |  | (5.8 | ) |  | — |  |  | (109.3 | ) |  | (3.6 | ) |
| Net income/(loss) | $ | (25.8 | ) |  | $ | (74.3 | ) |  | $ | 16.3 |  |  | $ | 47.4 |  |  | $ | 33.5 |  |  | $ | 2.7 |  |  | $ | 204.8 |  |  | $ | 7.1 |  |
| Net income/(loss) attributable to common stockholders - Basic | $ | (25.8 | ) |  | $ | (74.3 | ) |  | $ | 16.1 |  |  | $ | 46.1 |  |  | 32.5 |  |  | 2.4 |  |  | 199.8 |  |  | 6.7 |  |
| Net income/(loss) attributable to common stockholders - Diluted | $ | (25.8 | ) |  | $ | (74.3 | ) |  | $ | 5.4 |  |  | $ | 46.1 |  |  | 25.7 |  |  | 2.4 |  |  | 196.9 |  |  | 2.9 |  |
| Net income/(loss) per share attributable to common stockholders: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic | $ | (0.34 | ) |  | $ | (0.98 | ) |  | $ | 0.24 |  |  | $ | 0.73 |  |  | $ | 0.52 |  |  | $ | 0.04 |  |  | $ | 3.21 |  |  | $ | 0.11 |  |
| Diluted | $ | (0.34 | ) |  | $ | (0.98 | ) |  | $ | 0.08 |  |  | $ | 0.72 |  |  | $ | 0.40 |  |  | $ | 0.04 |  |  | $ | 3.05 |  |  | $ | 0.04 |  |
| Shares used to compute net income/(loss) per share attributable to common stockholders: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic | 76.5 |  |  | 76.2 |  |  | 66.8 |  |  | 63.1 |  |  | 62.7 |  |  | 62.4 |  |  | 62.2 |  |  | 61.7 |  |
| Diluted | 76.5 |  |  | 76.2 |  |  | 67.8 |  |  | 63.9 |  |  | 65.0 |  |  | 63.3 |  |  | 64.6 |  |  | 64.5 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001633978-19-000069:notes:438]
Note 14. Restructuring and Related Charges

[0001633978-19-000069:notes:439]
We have initiated various strategic restructuring actions primarily intended to reduce costs, consolidate our operations, rationalize the manufacturing of our products and align our business in response to market conditions and as a result of our acquisition of Oclaro on December 10, 2018.

[0001633978-19-000069:notes:440]
The following table summarizes the activity of restructuring and related charges during the years ended June 29, 2019 and June 30, 2018 (in millions):

[0001633978-19-000069:notes:441]
|  | Years Ended |
|  | June 29, 2019 |  | June 30, 2018 |  | July 1, 2017 |
| Balance as of beginning of period | $ | 1.9 |  |  | $ | 3.8 |  |  | $ | 5.7 |  |
| Charges | 31.9 |  |  | 7.2 |  |  | 12.0 |  |
| Payments | (19.2 | ) |  | (9.1 | ) |  | (13.9 | ) |
| Balance as of end of period | $ | 14.6 |  |  | $ | 1.9 |  |  | $ | 3.8 |  |

[0001633978-19-000069:notes:442]
In our effort to continually maximize long-term shareholder value, following our acquisition of Oclaro, on March 5, 2019, we announced our plan to discontinue development and manufacturing of Lithium Niobate modulators. A plan to wind down operations over the next couple of quarters was announced to employees in San Donato, Italy. Development and manufacturing will also be discontinued in our San Jose, California manufacturing locations within the next few quarters in order to facilitate our customers’ transition to new products.

[0001633978-19-000069:notes:443]
We also announced our plan to discontinue the development and manufacturing of future Datacom transceiver products which impacted our Milpitas and Shenzhen Datacom module teams. While we expect strong growth in Datacom volumes in the future, the market at the transceiver level is gross margin challenged due to extreme competition.  Following the Oclaro acquisition, we have a differentiated leadership position across a range of photonic chips on which the Datacom, wireless, and access markets critically rely.

[0001633978-19-000069:notes:444]
In connection with the restructuring plan and our plans to consolidate our operations, the Company calculated the fair value of the facilities-related charges of $1.6 million based on estimated future discounted cash flows which included the amount and timing of estimated sublease rental receipts that the Company could reasonably obtain over the remaining lease term and the discount rate.

[0001633978-19-000069:notes:445]
During fiscal 2019, we recorded $31.9 million in restructuring and related charges in our consolidated statements of operations.

[0001633978-19-000069:notes:446]
•During the first quarter of 2019, we recorded $1.3 million of severance costs primarily due to an internal re-organization in order to extend our market leadership position by strengthening product quality, to develop new enabling technologies required to support a winning long-term portfolio roadmap, and to develop commercial proposals and new product introduction (“NPI”) priorities to maintain and grow our position while driving new customer and eco-system partner engagements.

[0001633978-19-000069:notes:447]
•During the second quarter of 2019, we recorded $5.7 million primarily attributable to severance and employee related benefits associated with Oclaro’s executive severance and retention agreements. These retention agreements provide, under certain circumstances, for payments and benefits upon an involuntary termination of employment.

[0001633978-19-000069:notes:448]
•During the third quarter of 2019, we recorded $21.1 million primarily attributable to severance and employee related benefits associated with the wind down of operations for Lithium Niobate modulators and Datacom modules. We also recorded an additional $1.6 million of lease restructuring charges for the former Oclaro corporate headquarters.

[0001633978-19-000069:notes:449]
During fiscal 2018, we recorded $7.2 million in restructuring and related charges in the consolidated statements of operations.

[0001633978-19-000069:notes:450]
| • | During the fourth quarter of fiscal 2018, we initiated a new restructuring plan in order to realign the organization and enable further investment in key priority areas. As a result, a restructuring charge of $3.4 million was recorded for severance costs and employee benefits. In total, 52 employees in manufacturing, R&D and SG&A functions were terminated in connection with this new restructuring plan. |

[0001633978-19-000069:notes:451]
| • | We also incurred restructuring and related charges of $3.8 million from restructuring plans approved prior to fiscal 2016 primarily related to the shut down of our manufacturing facility in Bloomfield, Connecticut as a result of the transfer of certain production processes into existing sites in the United States or to contract manufacturers. |

[0001633978-19-000069:notes:452]
During fiscal 2017, we recorded $12.0 million in restructuring and related charges. Of the $12.0 million charge recorded during fiscal 2017, $2.1 million related to severance, retention and employee benefits.

[0001633978-19-000069:notes:453]
Any changes in the estimates of executing our restructuring activities will be reflected in our future results of operations.


## us-gaap:ScheduleOfBusinessAcquisitionsByAcquisitionTextBlock

[0001633978-19-000069:notes:454]
Our preliminary allocation of the purchase price of Oclaro, based on the estimated fair values of the assets acquired and liabilities assumed as of the acquisition date, is as follows (in millions):


## us-gaap:ScheduleOfEntityWideDisclosureOnGeographicAreasLongLivedAssetsInIndividualForeignCountriesByCountryTextBlock

[0001633978-19-000069:notes:455]
Long-lived assets, namely net property, plant and equipment, net, were identified based on the physical location of the assets in the corresponding geographic areas as of the periods indicated (in millions):

[0001633978-19-000069:notes:456]
|  | June 29, 2019 |  | June 30, 2018 |
| Property, Plant and Equipment, net |  |  |  |
| Thailand | $ | 157.1 |  |  | $ | 107.4 |  |
| United States | 156.2 |  |  | 97.6 |  |
| China | 33.5 |  |  | 70.0 |  |
| Japan | 28.3 |  |  | 0.5 |  |
| Other countries | 58.2 |  |  | 31.4 |  |
| Total long-lived assets | $ | 433.3 |  |  | $ | 306.9 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001633978-19-000069:notes:457]
The components of inventories were as follows (in millions):

[0001633978-19-000069:notes:458]
|  | June 29, 2019 |  | June 30, 2018 |
| Raw materials and purchased parts | $ | 78.3 |  |  | $ | 20.9 |  |
| Work in process (1) | 72.5 |  |  | 55.0 |  |
| Finished goods | 78.0 |  |  | 98.2 |  |
| Inventories (2) | $ | 228.8 |  |  | $ | 174.1 |  |

[0001633978-19-000069:notes:459]
(1) For fiscal 2018, we have reclassified $20.5 million of capitalized manufacturing overhead from prepayments and other current assets to inventory work in process to conform to current period presentation.

[0001633978-19-000069:notes:460]
(2) The inventory balance as of June 29, 2019 includes $5.7 million, net of amortization, related to the inventory step-up adjustment from the Oclaro acquisition.


## us-gaap:ScheduleOfOtherCurrentAssetsTableTextBlock

[0001633978-19-000069:notes:461]
The components of prepayments and other current assets were as follows (in millions):

[0001633978-19-000069:notes:462]
|  | June 29, 2019 |  | June 30, 2018 |
| Prepayments | $ | 32.4 |  |  | $ | 19.5 |  |
| Advances to contract manufacturers | 8.7 |  |  | 14.0 |  |
| Value added tax receivable | 11.9 |  |  | 4.0 |  |
| Vendor receivable | 36.3 |  |  | 4.3 |  |
| Assets held-for-sale | 4.9 |  |  | — |  |
| Other current assets | 3.3 |  |  | 2.7 |  |
| Prepayments and other current assets | $ | 97.5 |  |  | $ | 44.5 |  |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001633978-19-000069:notes:463]
The following table presents net revenue by the three geographic regions we operate in and net revenue from countries that represented 10% or more of our total net revenue (in millions, except percentage data):

[0001633978-19-000069:notes:464]
|  | Years Ended |
|  | June 29, 2019 |  | June 30, 2018 |  | July 1, 2017 |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |
| United States | $ | 100.9 |  |  | 6.4 | % |  | $ | 115.1 |  |  | 9.2 | % |  | $ | 147.9 |  |  | 14.8 | % |
| Mexico | 214.9 |  |  | 13.7 |  |  | 145.8 |  |  | 11.7 |  |  | 185.1 |  |  | 18.5 |  |
| Other Americas | 4.3 |  |  | 0.3 |  |  | 7.0 |  |  | 0.6 |  |  | 9.2 |  |  | 0.9 |  |
| Total Americas | $ | 320.1 |  |  | 20.4 | % |  | $ | 267.9 |  |  | 21.5 | % |  | $ | 342.2 |  |  | 34.2 | % |
| Asia-Pacific: |  |  |  |  |  |  |  |  |  |  |  |
| Hong Kong | $ | 387.9 |  |  | 24.8 | % |  | $ | 183.0 |  |  | 14.7 | % |  | $ | 226.7 |  |  | 22.6 | % |
| Japan | 176.0 |  |  | 11.2 |  |  | 194.7 |  |  | 15.6 |  |  | 99.2 |  |  | 9.9 |  |
| South Korea | 162.4 |  |  | 10.4 |  |  | 146.1 |  |  | 11.7 |  |  | 4.9 |  |  | 0.5 |  |
| Other Asia-Pacific | 356.1 |  |  | 22.7 |  |  | 354.2 |  |  | 28.3 |  |  | 220.5 |  |  | 22.0 |  |
| Total Asia-Pacific | $ | 1,082.4 |  |  | 69.1 | % |  | $ | 878.0 |  |  | 70.3 | % |  | $ | 551.3 |  |  | 55.0 | % |
| EMEA | $ | 162.8 |  |  | 10.5 | % |  | $ | 101.8 |  |  | 8.2 | % |  | $ | 108.1 |  |  | 10.8 | % |
| Total net revenue | $ | 1,565.3 |  |  |  |  | $ | 1,247.7 |  |  |  |  | $ | 1,001.6 |  |  |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001633978-19-000069:notes:465]
Information on reportable segments utilized by our CODM is as follows (in millions):

[0001633978-19-000069:notes:466]
|  | Years Ended |
|  | June 29, 2019 |  | June 30, 2018 |  | July 1, 2017 |
| Net revenue: |  |  |  |  |  |
| OpComms | $ | 1,370.2 |  |  | $ | 1,059.2 |  |  | $ | 857.8 |  |
| Lasers | 195.1 |  |  | 188.5 |  |  | 143.8 |  |
| Net revenue | $ | 1,565.3 |  |  | $ | 1,247.7 |  |  | $ | 1,001.6 |  |
| Gross profit: |  |  |  |  |  |
| OpComms | $ | 534.1 |  |  | $ | 402.3 |  |  | $ | 287.3 |  |
| Lasers | 84.4 |  |  | 82.8 |  |  | 59.9 |  |
| Total segment gross profit | 618.5 |  |  | 485.1 |  |  | 347.2 |  |
| Unallocated corporate items: |  |  |  |  |  |
| Stock-based compensation | (15.1 | ) |  | (12.6 | ) |  | (7.5 | ) |
| Amortization of intangibles | (46.6 | ) |  | (3.2 | ) |  | (6.5 | ) |
| Amortization of inventory step up | (54.6 | ) |  | — |  |  | — |  |
| Inventory write down due to product lines exit | (20.8 | ) |  | — |  |  | — |  |
| Integration related costs | (6.6 | ) |  | — |  |  | — |  |
| Other charges (1) | (48.9 | ) |  | (37.2 | ) |  | (15.1 | ) |
| Gross profit | $ | 425.9 |  |  | $ | 432.1 |  |  | $ | 318.1 |  |

[0001633978-19-000069:notes:467]
(1) The increase in “other charges” of unallocated corporate items for fiscal 2019 compared to fiscal 2018, primarily relates to set-up costs of our facility in Thailand, including costs of transferring the manufacturing of product lines to Thailand of $45.8 million in our fiscal 2019 compared to $27.0 million in fiscal 2018.

[0001633978-19-000069:notes:468]
The increase in “other charges” of unallocated corporate items for fiscal 2018 compared to fiscal 2017, primarily relates to set-up costs of our facility in Thailand, including costs of transferring the manufacturing of product lines to Thailand of $27.0 million in our fiscal 2018 compared to $1.8 million in fiscal 2017.


## us-gaap:SchedulesOfConcentrationOfRiskByRiskFactorTextBlock

[0001633978-19-000069:notes:469]
During the years ended June 29, 2019, June 30, 2018, and July 1, 2017, net revenue generated from a single customer which represented 10% or greater of total net revenue is summarized as follows:

[0001633978-19-000069:notes:470]
|  | Years Ended |
|  | June 29, 2019 |  | June 30, 2018 |  | July 1, 2017 |
| Customer A | 21.0 | % |  | 30.0 | % |  | * |  |
| Customer B | 15.2 | % |  | 11.0 | % |  | 16.7 | % |
| Customer C | 13.7 | % |  | 11.0 | % |  | 18.5 | % |
| Customer D | * |  |  | * |  |  | 12.4 | % |
| *Represents less than 10% of total net revenue |  |  |  |  |  |

[0001633978-19-000069:notes:471]
The table below discloses our total net revenue attributable to each of our two reportable segments. In addition, it discloses the percentage of our total net revenue attributable to our product offerings which serve the Telecom, Datacom, and Consumer and Industrial markets which accounted for 10% or more of our total net revenue during the periods presented (in millions, except percentage data):

[0001633978-19-000069:notes:472]
|  | Years Ended |
|  | June 29, 2019 |  | June 30, 2018 |  | July 1, 2017 |
| OpComms: |  |  |  |  |  |  |  |  |
| Telecom | $ | 786.5 |  | 50.2 | % |  | $ | 476.3 |  | 38.1 | % |  | $ | 610.7 |  | 61.0 | % |
| Datacom | 166.4 |  | 10.6 | % |  | 150.4 |  | 12.1 | % |  | 201.3 |  | 20.0 | % |
| Consumer and Industrial | 417.3 |  | 26.7 | % |  | 432.5 |  | 34.7 | % |  | 45.8 |  | 4.6 | % |
| Total OpComms | $ | 1,370.2 |  | 87.5 | % |  | $ | 1,059.2 |  | 84.9 | % |  | $ | 857.8 |  | 85.6 | % |
| Lasers | 195.1 |  | 12.5 | % |  | 188.5 |  | 15.1 | % |  | 143.8 |  | 14.4 | % |
| Total Revenue | $ | 1,565.3 |  |  |  | $ | 1,247.7 |  |  |  | $ | 1,001.6 |  |  |

[0001633978-19-000069:notes:473]
During fiscal 2019, 2018 and 2017, net inventory purchased from a single contract manufacturer which represented 10% or greater of total net purchases is summarized as follows:

[0001633978-19-000069:notes:474]
|  | Years Ended |
|  | June 29, 2019 |  | June 30, 2018 |  | July 1, 2017 |
| Vendor A | 47 | % |  | 44 | % |  | 50 | % |
| Vendor B | 17 | % |  | 20 | % |  | 27 | % |
| Vendor C | 11 | % |  | 21 | % |  | * |  |
| Vendor D | * |  |  | * |  |  | 14 | % |
| *Represents less than 10% of total net purchases |  |  |  |  |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001633978-19-000069:notes:475]
Note 20. Operating Segments and Geographic Information

[0001633978-19-000069:notes:476]
Our chief executive officer is our CODM. The CODM allocates resources to the segments based on their business prospects, competitive factors, net revenue and gross margin. We do not track all of our property, plant and equipment by operating segments. The geographic identification of these assets is set forth below.

[0001633978-19-000069:notes:477]
We are an industry leading provider of optical and photonic products defined by revenue and market share addressing a range of end-market applications including optical communications and commercial lasers. We have two operating segments, Optical Communications, which we refer to as OpComms, and Commercial Lasers, which we refer to as Lasers. Our OpComms products address the following markets: telecommunications (“Telecom”), data communications (“Datacom”), and consumer and industrial (“Consumer and Industrial”), and include product lines from the acquisition of Oclaro. The two operating segments were primarily determined based on how the CODM views and evaluates our operations. Operating results are regularly reviewed by the CODM to make decisions about resources to be allocated to the segments and to assess their performance. Other factors, including market separation and customer specific applications, go-to-market channels, products and manufacturing, are considered in determining the formation of these operating segments.

[0001633978-19-000069:notes:478]
OpComms

[0001633978-19-000069:notes:479]
Our OpComms products address the following markets: Telecom, Datacom and Consumer and Industrial.

[0001633978-19-000069:notes:480]
Our OpComms products include a wide range of components, modules and subsystems to support customers including carrier networks of access (local), metro (intracity), long-haul (city-to-city and worldwide) and submarine (undersea) applications. Additionally, our products address enterprise, cloud, and data center applications, including storage-access networks (“SANs”), local-area networks (“LANs”) and wide-area networks (“WANs”). These products enable the transmission and transport of video, audio and text data over high-capacity fiber-optic cables. We maintain leading positions in these fast growing OpComms markets through our extensive product portfolio, including reconfigurable optical add/drop multiplexers (“ROADMs”), coherent DWDM pluggable transceivers, and tunable small form-factor pluggable transceivers. We also sell laser chips for use in the manufacture of high-speed Datacom transceivers.

[0001633978-19-000069:notes:481]
In the Consumer and Industrial market, our OpComms products include laser light sources, which are integrated into 3D sensing platforms being used in applications for mobile devices, gaming, computers, and other consumer electronics devices. New emerging applications include virtual and augmented reality, as well as automotive and industrial segments. Our products include vertical cavity surface emitting lasers (“VCSELs”) and edge emitting lasers which are used in 3D sensing depth imaging systems. These systems simplify the way people interact with technology by enabling the use of natural user interfaces. Systems are used for biometric identification, surveillance, and process efficiency, among numerous other application spaces. Emerging applications for this technology include various mobile device applications, autonomous vehicles, self-navigating robotics and drones in industrial applications and 3D capture of objects coupled with 3D printing. In addition, our industrial diode lasers are used primarily as pump sources for pulsed and kilowatt class fiber lasers.

[0001633978-19-000069:notes:482]
Lasers

[0001633978-19-000069:notes:483]
Our Lasers products serve our customers in markets and applications such as sheet metal processing, general manufacturing, biotechnology, graphics and imaging, remote sensing, and precision machining such as drilling in printed circuit boards, wafer singulation, glass cutting and solar cell scribing.

[0001633978-19-000069:notes:484]
Our Lasers products are used in a variety of OEM applications including diode-pumped solid-state, fiber, diode, direct-diode and gas lasers such as argon-ion and helium-neon lasers. Fiber lasers provide kW-class output powers combined with excellent beam quality and are used in sheet metal processing and metal welding applications. Diode-pumped solid-state lasers provide excellent beam quality, low noise and exceptional reliability and are used in biotechnology, graphics and imaging, remote sensing, materials processing and precision machining applications. Diode and direct-diode lasers address a wide variety of applications, including laser pumping, thermal exposure, illumination, ophthalmology, image recording, printing, plastic welding and selective soldering. Gas lasers such as argon-ion and helium-neon lasers provide a stable, low-cost and reliable solution over a wide range of operating conditions, making them well suited for complex, high-resolution OEM applications such as flow cytometry, DNA sequencing, graphics and imaging and semiconductor inspection.

[0001633978-19-000069:notes:485]
We also provide high-powered and ultrafast lasers for the industrial and scientific markets. Manufacturers use high-power, ultrafast lasers to create micro parts for consumer electronics and to process semiconductor, LED, and other types of chips. Use of ultrafast lasers for micromachining applications is being driven primarily by the increasing use of consumer electronics and connected devices globally.

[0001633978-19-000069:notes:486]
We do not allocate research and development, sales and marketing, or general and administrative expenses to our segments because management does not include the information in its measurement of the performance of the operating segments. In addition, we do not allocate amortization and impairment of acquisition-related intangible assets, stock-based compensation and certain other charges impacting the gross margin of each segment because management does not include this information in its measurement of the performance of the operating segments.

[0001633978-19-000069:notes:487]
We operate in three geographic regions: Americas, Asia-Pacific, and EMEA (Europe, Middle East, and Africa). Net revenue is assigned to the geographic region and country where our product is initially shipped. For example, certain customers may request shipment of our product to a contract manufacturer in one country, which may differ from the location of their end customers. The following table presents net revenue by the three geographic regions we operate in and net revenue from countries that represented 10% or more of our total net revenue (in millions, except percentage data):

[0001633978-19-000069:notes:488]
During fiscal 2019, 2018 and 2017, net revenue from customers outside the United States, based on customer shipping location, represented 93.6%, 90.8% and 85.2% of net revenue, respectively. Our net revenue from Mexico increased in fiscal 2019 compared to 2018 due to increased demand for our ROADM products from one of our large customers who manufactures in Mexico, while net revenue from Hong Kong grew due to a change in shipment destination of a large portion of our 3D sensing products for mobile devices.

[0001633978-19-000069:notes:489]
Our accounts receivable was concentrated with three customers as of June 29, 2019, who represented 17%, 17% and 10% of gross accounts receivable, respectively, compared with two customers as of June 30, 2018, who represented 11% and 10% of gross accounts receivable, respectively.

[0001633978-19-000069:notes:490]
We purchase a substantial portion of our inventory from contract manufacturers and vendors located primarily in Taiwan, Thailand, and Malaysia. During fiscal 2019, 2018 and 2017, net inventory purchased from a single contract manufacturer which represented 10% or greater of total net purchases is summarized as follows:


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001633978-19-000069:notes:491]
Note 9. Balance Sheet Details

[0001633978-19-000069:notes:492]
Accounts receivable allowances

[0001633978-19-000069:notes:493]
As of June 29, 2019 and June 30, 2018, our accounts receivable allowance balance was $4.5 million and $2.6 million respectively.

[0001633978-19-000069:notes:494]
Inventories

[0001633978-19-000069:notes:495]
Prepayments and other current assets

[0001633978-19-000069:notes:496]
Property, plant and equipment, net

[0001633978-19-000069:notes:497]
In fiscal 2019, we purchased a property in San Jose, California for $54.6 million settled in cash. We plan to relocate our corporate headquarters to this new San Jose location by the end of the calendar year 2019. The preliminary allocations of value were $21.7 million to buildings and improvements and $32.9 million to the land. The total amount of $54.6 million is included in our property, plant and equipment, gross as of June 29, 2019.

[0001633978-19-000069:notes:498]
During fiscal 2019, 2018 and 2017, we recorded depreciation expense of $102.9 million, $74.0 million, and $54.2 million, respectively.

[0001633978-19-000069:notes:499]
Our construction in progress primarily includes machinery and equipment which we expect to place in service in the next 12 months.

[0001633978-19-000069:notes:500]
Other current liabilities

[0001633978-19-000069:notes:501]
Other non-current liabilities
