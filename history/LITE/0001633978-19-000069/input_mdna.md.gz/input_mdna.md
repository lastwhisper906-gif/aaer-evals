# LITE MD&A — 0001633978-19-000069


## mdna

[0001633978-19-000069:mdna:1]
ITEM 7.    MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0001633978-19-000069:mdna:2]
You should read the following discussion in conjunction with the audited consolidated financial statements and the corresponding notes included elsewhere in this Annual Report. This Management’s Discussion and Analysis of Financial Condition and Results of Operations contains forward-looking statements. The matters discussed in these forward-looking statements are subject to risk, uncertainties and other factors that could cause actual results to differ materially from those made, projected or implied in the forward-looking statements. Please see “Risk Factors” and “Forward-Looking Statements” for a discussion of the uncertainties, risks and assumptions associated with these statements.

[0001633978-19-000069:mdna:3]
Overview

[0001633978-19-000069:mdna:4]
We are an industry-leading provider of optical and photonic products defined by revenue and market share addressing a range of end-market applications including Optical Communications, which we refer to as OpComms, and Lasers for manufacturing, inspection and life-science applications. We seek to use our core optical and photonic technology and our volume manufacturing capability to expand into attractive emerging markets that benefit from advantages that optical or photonics-based solutions provide, including 3D sensing for consumer electronics and diode light sources for a variety of consumer and industrial applications. We have two operating segments, OpComms and Lasers. The two operating segments were primarily determined based on how our CODM views and evaluates our operations. Operating results are regularly reviewed by our CODM to make decisions about resources to be allocated to the segments and to assess their performance. Other factors, including market separation and customer specific applications, go-to-market channels, products and manufacturing, are considered in determining the formation of these operating segments.

[0001633978-19-000069:mdna:5]
We see the world as becoming more reliant on ever-increasing amounts of data flowing through optical networks and data centers, which demand new networks and data centers to be built to satisfy this insatiable demand for data. As higher levels of precision, new materials, factory and energy efficiency are being demanded by manufacturers, suppliers of manufacturing tools globally are turning more and more to laser based approaches, including the types of lasers Lumentum supplies. Laser based 3D sensing is a rapidly developing market. The technology enables computer vision applications that enhance security, safety, and new functionality in the electronic devices that people rely on every day. We believe the global markets in which Lumentum participates have fundamentally robust, long-term trends that increase the need for our photonics products and technologies.

[0001633978-19-000069:mdna:6]
On December 10, 2018, we completed the acquisition of Oclaro, a provider of optical components and modules for the long-haul, metro and data center markets. In accordance with the terms of the Merger Agreement, each issued and outstanding share of Oclaro common stock was automatically converted into the right to receive (i) $5.60 in cash and (ii) 0.0636 of a share of Lumentum common stock. The total transaction consideration was $1.4 billion, which was funded through the issuance of Lumentum common stock, new debt (refer to “Note 7. Term Loan Facility”), and cash balances of the combined company. Refer to “Note 5. Business Combination” in the notes to consolidated financial statements for further discussion of the merger.

[0001633978-19-000069:mdna:7]
During our fiscal 2019, we recorded $20.9 million in restructuring and related charges in our consolidated statements of operations, attributable to severance and employee related benefits associated with Oclaro’s executive severance and retention agreements. These retention agreements provide, under certain circumstances, for payments and benefits upon an involuntary termination of employment, including following a change in control of Oclaro. The payments and benefits payable under these arrangements in the event of a change in control of Oclaro are subject to a “double trigger,” meaning that both a change in control of Oclaro and a subsequent involuntary termination of employment are required. In other words, the change in control of Oclaro does not by itself trigger any payments or benefits. Instead, payments and benefits are paid only if the employment of the employee is subsequently terminated without “cause” (or the employee resigns for “good reason”) during a specified period following the change in control. We incurred total expense of $20.9 million, of which $5.7 million relates to cash severance as part of our restructuring expense, refer to “Note 14. Restructuring and Related Charges” and $15.2 million relates to acceleration of equity awards, refer to “Note 17. Stock-Based Compensation and Stock Plans.”

[0001633978-19-000069:mdna:8]
OpComms

[0001633978-19-000069:mdna:9]
Our OpComms products address the following markets: Telecom, Datacom and Consumer and Industrial.

[0001633978-19-000069:mdna:10]
Our OpComms products include a wide range of components, modules and subsystems to support customers including carrier networks of access (local), metro (intracity), long-haul (city-to-city and worldwide) and submarine (undersea) applications. Additionally, our products address enterprise, cloud, and data center applications, including storage-access networks (“SANs”), local-area networks (“LANs”) and wide-area networks (“WANs”). These products enable the transmission and transport of video, audio and text data over high-capacity fiber-optic cables. We maintain leading positions in these fast growing OpComms markets through our extensive product portfolio, including reconfigurable optical add/drop multiplexers (“ROADMs”), coherent DWDM

[0001633978-19-000069:mdna:11]
pluggable transceivers, and tunable small form-factor pluggable transceivers. We also sell laser chips for use in the manufacture of high-speed Datacom transceivers.

[0001633978-19-000069:mdna:12]
In the Consumer and Industrial market, our OpComms products include laser light sources, which are integrated into 3D sensing platforms being used in applications for mobile devices, gaming, computers, and other consumer electronics devices. New emerging applications include virtual and augmented reality, as well as automotive and industrial segments. Our products include vertical cavity surface emitting lasers (“VCSELs”) and edge emitting lasers which are used in 3D sensing depth imaging systems. These systems simplify the way people interact with technology by enabling the use of natural user interfaces. Systems are used for biometric identification, surveillance, and process efficiency, among numerous other application spaces. Emerging applications for this technology include various mobile device applications, autonomous vehicles, self-navigating robotics and drones in industrial applications and 3D capture of objects coupled with 3D printing. In addition, our industrial diode lasers are used primarily as pump sources for pulsed and kilowatt class fiber lasers.

[0001633978-19-000069:mdna:13]
Our OpComms customers include Alphabet, Apple, Ciena, Cisco Systems (which recently announced the acquisition of Acacia Communications, another customer of ours), Huawei Technologies (including HiSilicon), Infinera, Innolight, Nokia Networks (including Alcatel-Lucent International), O-Net, and ZTE.

[0001633978-19-000069:mdna:14]
Following the acquisition of Oclaro, during our fiscal 2019, we made several strategic changes to our OpComms business as follows:

[0001633978-19-000069:mdna:15]
First, for overlapping products as a result of the acquisition, we are transitioning to a common lower cost design and manufacturing platform, which we expect will result in gross margin improvement over time. In addition, we are discontinuing certain Telecom product lines that we believe have muted growth and profitability trends that are inconsistent with our long term model. We expect that these transitions will be completed in our fiscal 2021. For the Telecom product lines we are exiting, we do not expect significant revenue declines until fiscal 2021 as in fiscal 2020 we are continuing to satisfy customers’ product needs with respect to these product lines.

[0001633978-19-000069:mdna:16]
Second, we announced our plan to discontinue development and manufacturing of Lithium Niobate modulators, and we plan to wind down these operations in San Donato, Italy during fiscal year 2020. Development and manufacturing will also be discontinued in our San Jose, California manufacturing locations within the next few quarters in order to facilitate our customers’ transition to new products. We expect our Indium Phosphide photonic integrated circuits will replace Lithium Niobate modulators over time.

[0001633978-19-000069:mdna:17]
Third, we announced the sale of many of our Datacom transceiver module products to Cambridge Industries Group (“CIG”). This transaction closed on April 18, 2019. For further information regarding this transaction, refer to “Note 5. Business Combination”. We expect Datacom transceiver sales to ramp down to zero during fiscal year 2020. We are investing in new Datacom chip development and expect sales of these chips to customers serving the Datacom and 5G wireless markets will grow over time. With the exit from the business of selling Datacom transceivers, we recorded an impairment charge of $30.7 million to our Long-lived assets that were not deemed to be useful, as they were retired from active use and classified as held-for-sale. These assets were valued at fair value less cost to sell. We also recorded inventory write down charges of $20.8 million related to the decision to exit the Datacom module and Lithium Niobate product lines in our cost of goods sold of consolidated statements of operations. These actions do not qualify as discontinued operations for disclosure purposes as they do not represent a strategic shift having a major effect on an entity’s operations and financial results. For additional information, refer to “Note 15. Impairment Charges”.

[0001633978-19-000069:mdna:18]
Lasers

[0001633978-19-000069:mdna:19]
Our Lasers products serve our customers in markets and applications such as sheet metal processing, general manufacturing, biotechnology, graphics and imaging, remote sensing, and precision machining such as drilling in printed circuit boards, wafer singulation, glass cutting and solar cell scribing.

[0001633978-19-000069:mdna:20]
Our Lasers products are used in a variety of OEM applications including diode-pumped solid-state, fiber, diode, direct-diode and gas lasers such as argon-ion and helium-neon lasers. Fiber lasers provide kW-class output powers combined with excellent beam quality and are used in sheet metal processing and metal welding applications. Diode-pumped solid-state lasers provide excellent beam quality, low noise and exceptional reliability and are used in biotechnology, graphics and imaging, remote sensing, materials processing and precision machining applications. Diode and direct-diode lasers address a wide variety of applications, including laser pumping, thermal exposure, illumination, ophthalmology, image recording, printing, plastic welding and selective soldering. Gas lasers such as argon-ion and helium-neon lasers provide a stable, low-cost and reliable solution over a wide range of operating conditions, making them well suited for complex, high-resolution OEM applications such as flow cytometry, DNA sequencing, graphics and imaging and semiconductor inspection.

[0001633978-19-000069:mdna:21]
We also provide high-powered and ultrafast lasers for the industrial and scientific markets. Manufacturers use high-power, ultrafast lasers to create micro parts for consumer electronics and to process semiconductor, LED, and other types of chips. Use of ultrafast lasers for micromachining applications is being driven primarily by the increasing use of consumer electronics and connected devices globally.

[0001633978-19-000069:mdna:22]
Our Lasers customers include Amada, ASML Holding, Beckman Coulter, DISCO, Electro Scientific Industries (recently acquired by MKS Instruments, a competitor of ours), Han’s Laser Technology, KLA-Tencor, Lasertec, Life Technologies, and NR Electric.

[0001633978-19-000069:mdna:23]
Critical Accounting Policies and Estimates

[0001633978-19-000069:mdna:24]
Our consolidated financial statements are prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) as set forth in the Financial Accounting Standards Board’s Accounting Standards Codification (“ASC”), and we consider the various staff accounting bulletins and other applicable guidance issued by the United States Securities and Exchange Commission (“SEC”). GAAP, as set forth within the ASC, requires us to make certain estimates, judgments and assumptions. We believe that the estimates, judgments and assumptions upon which we rely are reasonable based upon information available to us at the time that these estimates, judgments and assumptions are made. These estimates, judgments and assumptions can affect the reported amounts of assets and liabilities as of the date of the financial statements as well as the reported amounts of revenues and expenses during the periods presented. To the extent there are differences between these estimates, judgments or assumptions and actual results, our financial statements will be affected. The accounting policies that reflect our more significant estimates, judgments and assumptions and which we believe are the most critical to aid in fully understanding and evaluating our reported financial results include the following:

[0001633978-19-000069:mdna:25]
• Inventory Valuation

[0001633978-19-000069:mdna:26]
• Revenue Recognition

[0001633978-19-000069:mdna:27]
• Income Taxes

[0001633978-19-000069:mdna:28]
• Long-lived Asset Valuation

[0001633978-19-000069:mdna:29]
• Business Combinations

[0001633978-19-000069:mdna:30]
• Goodwill

[0001633978-19-000069:mdna:31]
During fiscal year 2019, we removed valuation of derivative liability from the list of critical accounting policies and estimates due to the conversion of the Series A Preferred Stock to common stock on November 2, 2018. Refer to “Note 12. Non-Controlling Interest Redeemable Convertible Preferred Stock and Derivative Liability” for additional information.

[0001633978-19-000069:mdna:32]
Inventory Valuation

[0001633978-19-000069:mdna:33]
Inventory is valued at standard cost, which approximates actual cost computed on a first-in, first-out basis, not in excess of net realizable value. We assess the value of our inventory on a quarterly basis and write down those inventories which are obsolete or in excess of our forecasted usage to the lower of their cost or estimated net realizable value. Our estimates of realizable value are based upon our analysis and assumptions including, but not limited to, forecasted sales levels and historical usage by product, expected product lifecycle, product development plans and future demand requirements. Our product line management personnel play a key role in our excess review process by providing updated sales forecasts, managing product transitions and working with manufacturing to minimize excess inventory. If actual market conditions are less favorable than our forecasts or actual demand from our customers is lower than our estimates, we may be required to record additional inventory write-downs. If actual market conditions are more favorable than anticipated, inventory previously written down may be sold, resulting in lower cost of sales and higher income from operations than expected in that period.

[0001633978-19-000069:mdna:34]
Revenue Recognition

[0001633978-19-000069:mdna:35]
Adoption of Topic 606

[0001633978-19-000069:mdna:36]
Pursuant to Topic 606, our revenues are recognized upon the application of the following steps:

[0001633978-19-000069:mdna:37]
| • | identification of the contract, or contracts, with a customer; |

[0001633978-19-000069:mdna:38]
| • | identification of the performance obligations in the contract; |

[0001633978-19-000069:mdna:39]
| • | determination of the transaction price; |

[0001633978-19-000069:mdna:40]
| • | allocation of the transaction price to the performance obligations in the contract; and |

[0001633978-19-000069:mdna:41]
| • | recognition of revenues when, or as, the contractual performance obligations are satisfied. |

[0001633978-19-000069:mdna:42]
The majority of our revenue comes from product sales, consisting of sales of Lasers and OpComms hardware products to our customers. Our revenue contracts generally include only one performance obligation. Revenues are recognized at a point in time when control of the promised goods or services are transferred to our customers upon shipment or delivery, in an amount that reflects the consideration we expect to be entitled to in exchange for those goods or services. We have entered into vendor managed inventory (“VMI”) programs with our customers. Under these arrangements, we receive purchase orders from our customers, and the inventory is shipped to the VMI location upon receipt of the purchase order. The customer then pulls the inventory from the VMI hub based on its production needs. Revenue under VMI programs is recognized when control transfers to the customer, which is generally once the customer pulls the inventory from the hub.

[0001633978-19-000069:mdna:43]
Revenue from all sales types is recognized at the transaction price. The transaction price is determined based on the consideration to which we will be entitled in exchange for transferring goods or services to the customer, adjusted for estimated variable consideration, if any. We typically estimate the impact on the transaction price for discounts offered to the customer for early payments on receivables or net of accruals for estimated sales returns. These estimates are based on historical returns, analysis of credit memo data and other known factors. Actual returns could differ from these estimates. We allocate the transaction price to each distinct product based on its relative standalone selling price. The product price as specified on the purchase order is considered the standalone selling price as it is an observable input that depicts the price as if sold to a similar customer in similar circumstances.

[0001633978-19-000069:mdna:44]
Taxes assessed by a governmental authority that are both imposed on and concurrent with a specific revenue-producing transaction, that are collected by us from a customer and deposited with the relevant government authority, are excluded from revenue. Our revenue arrangements do not contain significant financing components as our standard payment terms are less than one year.

[0001633978-19-000069:mdna:45]
If a customer pays consideration, or if we have a right to an amount of consideration that is unconditional before we transfer a good or service to the customer, those amounts are classified as deferred revenue or deposits received from customers which are included in other current liabilities or other long-term liabilities when the payment is made or when it is due, whichever is earlier.

[0001633978-19-000069:mdna:46]
Transaction Price Allocated to the Remaining Performance Obligations

[0001633978-19-000069:mdna:47]
Remaining performance obligations represent the transaction price allocated to performance obligations that are unsatisfied or partially unsatisfied as of the end of the reporting period. Unsatisfied and partially unsatisfied performance obligations consist of contract liabilities and non-cancellable backlog. Non-cancellable backlog includes goods and services for which customer purchase orders have been accepted that are scheduled or in the process of being scheduled for shipment. A portion of our revenue arises from vendor-managed inventory arrangements where the timing and volume of customer utilization is difficult to predict.

[0001633978-19-000069:mdna:48]
The following table includes estimated revenue expected to be recognized in the future for backlog related performance obligations that are unsatisfied as of June 29, 2019 (in millions):

[0001633978-19-000069:mdna:49]
|  | Less than 1 year | 1-2 years | Greater than 2 years | Total |
| Performance Obligations | $446.1 | $7.0 | $— | $453.1 |

[0001633978-19-000069:mdna:50]
Warranty

[0001633978-19-000069:mdna:51]
Hardware products regularly include warranties to the end customers such that the product continues to function according to published specifications. We typically offer a twelve-month warranty for most of our products. However, in some instances depending upon the product, specific market, product line and geography in which we operate, and what is common in the industry, our warranties can vary and range from six months to five years. These standard warranties are assurance type warranties and do not offer any services in addition to the assurance that the product will continue working as specified. Therefore, warranties are not considered separate performance obligations in the arrangement. Instead, the expected cost of the warranty is accrued as expense in accordance with authoritative guidance.

[0001633978-19-000069:mdna:52]
We provide reserves for the estimated costs of product warranties at the time revenue is recognized. We estimate the costs of our warranty obligations based on our historical experience of known product failure rates, use of materials to repair or replace defective products and service delivery costs incurred in correcting product failures. In addition, from time to time, specific warranty accruals may be made if unforeseen technical problems arise.

[0001633978-19-000069:mdna:53]
Shipping and Handling Costs

[0001633978-19-000069:mdna:54]
We record shipping and handling costs related to revenue transactions within cost of sales as a period cost.

[0001633978-19-000069:mdna:55]
Contract Costs

[0001633978-19-000069:mdna:56]
We recognize the incremental direct costs of obtaining a contract, which consist of sales commissions, when control over the products they relate to transfers to the customer. Applying the practical expedient, we recognize commissions as expense when incurred, as the amortization period of the commission asset we would have otherwise recognized is less than one year.

[0001633978-19-000069:mdna:57]
Contract Balances

[0001633978-19-000069:mdna:58]
We record accounts receivable when we have an unconditional right to consideration. Contract liabilities are recorded when cash payments are received or due in advance of performance. Contract liabilities consist of advance payments and deferred revenue, where we have unsatisfied performance obligations. Contract liabilities are classified as deferred revenue and customer deposits, and are included in other current liabilities within our consolidated balance sheet. Payment terms vary by customer. The time between invoicing and when payment is due is not significant.

[0001633978-19-000069:mdna:59]
The following table reflects the changes in contract balances as of June 29, 2019 (in millions, except percentages):

[0001633978-19-000069:mdna:60]
| Contract balances | Balance sheet location | June 29, 2019 |  | June 30, 2018 |  | Change |  | Percentage Change |
| Accounts receivable, net | Accounts receivable, net | $238.0 |  | $197.1 |  | $40.9 |  | 20.8% |
| Deferred revenue and customer deposits | Other current liabilities | $2.9 |  | $2.8 |  | $0.1 |  | 3.6% |

[0001633978-19-000069:mdna:61]
Disaggregation of Revenue

[0001633978-19-000069:mdna:62]
We disaggregate revenue by geography and by product. Refer to “Note 20. Operating Segments and Geographic Information” for a presentation of disaggregated revenue. We do not present other levels of disaggregation, such as by type of products, customer, markets, contracts, duration of contracts, timing of transfer of control and sales channels, as this information is not used by our CODM to manage the business.

[0001633978-19-000069:mdna:63]
Income Taxes

[0001633978-19-000069:mdna:64]
In accordance with the authoritative guidance on accounting for income taxes, we recognize income taxes using an asset and liability approach. This approach requires the recognition of taxes payable or refundable for the current year and deferred tax liabilities and assets for the future tax consequences of events that have been recognized in our consolidated financial statements or tax returns. The measurement of current and deferred taxes is based on provisions of the enacted tax law, and the effects of future changes in tax laws or rates are not anticipated.

[0001633978-19-000069:mdna:65]
The authoritative guidance provides for recognition of deferred tax assets if the realization of such deferred tax assets is more likely than not to occur based on an evaluation of both positive and negative evidence and the relative weight of the evidence. We consider future growth, forecasted earnings, future taxable income, the mix of earnings in the jurisdictions in which we operate, historical earnings, taxable income in prior years, if carryback is permitted under the law, and prudent and feasible tax planning strategies in determining the need for a valuation allowance. In the event we were to determine that we would not be able to realize all or part of our net deferred tax assets in the future, an adjustment to the deferred tax assets valuation allowance would be charged to earnings in the period in which we make such a determination, or goodwill would be adjusted at our final determination of the valuation allowance related to an acquisition within the measurement period. If we later determine that it is more likely than not that the net deferred tax assets would be realized, we would reverse the applicable portion of the previously provided valuation allowance as an adjustment to earnings at such time.

[0001633978-19-000069:mdna:66]
We are subject to income tax audits by the respective tax authorities of the jurisdictions in which we operate. The determination of our income tax liabilities in each of these jurisdictions requires the interpretation and application of complex, and sometimes uncertain, tax laws and regulations. The authoritative guidance on accounting for income taxes prescribes both recognition and measurement criteria that must be met for the benefit of a tax position to be recognized in the financial statements.  If a tax position taken, or expected to be taken, in a tax return does not meet such recognition or measurement criteria, an unrecognized tax benefit liability is recorded.  If we ultimately determine that an unrecognized tax benefit liability is no longer necessary, we reverse the liability and recognize a tax benefit in the period in which it is determined that the unrecognized tax benefit liability is no longer necessary.

[0001633978-19-000069:mdna:67]
The recognition and measurement of current taxes payable or refundable and deferred tax assets and liabilities requires that we make certain estimates and judgments. Changes to these estimates or a change in judgment may have a material impact on our tax provision in a future period.

[0001633978-19-000069:mdna:68]
Long-lived Asset Valuation

[0001633978-19-000069:mdna:69]
We test long-lived assets for recoverability, at the asset group level, when events or changes in circumstances indicate that their carrying amount may not be recoverable. Circumstances which could trigger a review include, but are not limited to: significant decreases in the market price of the asset, significant adverse changes in the business climate or legal factors, accumulation of costs significantly in excess of the amount originally expected for the acquisition or construction of the asset, current period cash flow or operating losses combined with a history of losses or a forecast of continuing losses associated with the use of the asset, or current expectation that the asset will more likely than not be sold or disposed significantly before the end of its estimated useful life.

[0001633978-19-000069:mdna:70]
Recoverability is assessed based on the difference between the carrying amount of the asset and the sum of the undiscounted cash flows expected to result from the use and the eventual disposal of the asset. An impairment loss is recognized when the carrying amount is not recoverable and exceeds fair value.

[0001633978-19-000069:mdna:71]
Business Combinations

[0001633978-19-000069:mdna:72]
In accordance with the guidance for business combinations, we determine whether a transaction or other event is a business combination, which requires that the assets acquired and liabilities assumed constitute a business. Each business combination is then accounted for by applying the acquisition method. If the assets acquired are not a business, we account for the transaction or other event as an asset acquisition. Under both methods, we recognize the identifiable assets acquired, the liabilities assumed, and any noncontrolling interest in the acquired entity. We capitalize acquisition-related costs and fees associated with asset acquisitions and immediately expense acquisition-related costs and fees associated with business combinations.

[0001633978-19-000069:mdna:73]
We allocate the fair value of purchase consideration to the tangible assets acquired, liabilities assumed and intangible assets acquired based on their estimated fair values. The excess of the fair value of purchase consideration over the fair values of these identifiable assets and liabilities is recorded as goodwill. When determining the fair values of assets acquired and liabilities assumed, we make significant estimates and assumptions, especially with respect to intangible assets. Critical estimates in valuing certain intangible assets include, but are not limited to, future expected cash flows from customer relationships and acquired developed technology and discount rates. Our estimates of fair value are based upon assumptions believed to be reasonable, but which are inherently uncertain and unpredictable and, as a result, actual results may differ materially from estimates. Other estimates associated with the accounting for acquisitions may change as additional information becomes available regarding the assets acquired and liabilities assumed. Any change in facts and circumstances that existed as of the acquisition date and impacts our preliminary estimates is recorded to goodwill if identified within the measurement period. Subsequent to the measurement period or our final determination of fair value of assets and liabilities whichever is earlier the adjustments will affect our earnings.

[0001633978-19-000069:mdna:74]
In addition, we estimate the economic lives of certain acquired assets and these lives are used to calculate depreciation and amortization expense. If our estimates of the economic lives change, depreciation or amortization expenses could be accelerated or slowed.

[0001633978-19-000069:mdna:75]
Goodwill

[0001633978-19-000069:mdna:76]
Goodwill represents the excess of the purchase price of an acquired business over the fair value of the identifiable assets acquired and liabilities assumed. We test for impairment of goodwill on an annual basis in the fourth quarter and at any other time when events occur or circumstances indicate that the carrying amount of goodwill may not be recoverable.

[0001633978-19-000069:mdna:77]
An entity has the option to first assess qualitative factors to determine whether it is necessary to perform the two-step quantitative goodwill impairment test. If an entity determines that as a result of the qualitative assessment that it is more likely than not (i.e., greater than 50% likelihood) that the fair value of a reporting unit is less than its carrying amount, then the quantitative test is required. Otherwise, no further testing is required. The two-step quantitative goodwill impairment test requires us to estimate the fair value of our reporting units. If the carrying value of a reporting unit exceeds its fair value, the goodwill of that reporting unit is potentially impaired and we proceed to step two of the impairment analysis. In step two of the analysis, we measure and record an impairment loss equal to the excess of the carrying value of the reporting unit’s goodwill over its implied fair value, if any.

[0001633978-19-000069:mdna:78]
Application of the goodwill impairment test requires judgments, including: identification of the reporting units, assigning assets and liabilities to reporting units, assigning goodwill to reporting units, a qualitative assessment to determine whether there are any impairment indicators, and determining the fair value of each reporting unit. We estimate the fair value of a reporting unit using market approach, income approach or a combination of market and income approach. Significant estimates in the market approach include: identifying similar companies with comparable business factors such as size, growth, profitability, risk and return on investment, and assessing comparable revenue and operating income multiples in estimating the fair value of the reporting unit. Significant estimates in the income approach include: future cash flows, discount rates.

[0001633978-19-000069:mdna:79]
We base our estimates on historical experience and on various assumptions about the future that we believe are reasonable based on available information. Unanticipated events and circumstances may occur that affect the accuracy of our assumptions, estimates and judgments. For example, if the price of our common stock were to significantly decrease combined with other adverse changes in market conditions, thus indicating that the underlying fair value of our reporting units may have decreased, we might be required to reassess the value of our goodwill in the period such circumstances were identified.

[0001633978-19-000069:mdna:80]
Based on the impairment analysis performed in the fourth quarter of each year presented, the fair value of our reporting unit substantially exceeded the carrying value; as such, our annual qualitative assessment did not indicate that a more detailed quantitative analysis was necessary.

[0001633978-19-000069:mdna:81]
In many cases, the accounting treatment of a particular transaction is specifically dictated by GAAP and does not require management’s judgment in its application. There are also areas in which management’s judgment in selecting among available alternatives would not produce a materially different result. Our senior management has reviewed our critical accounting policies and related disclosures with the Audit Committee of our board of directors.

[0001633978-19-000069:mdna:82]
Recently Issued Accounting Pronouncements

[0001633978-19-000069:mdna:83]
Refer to “Note 2. Recently Issued Accounting Pronouncements” in the notes to consolidated financial statements.

[0001633978-19-000069:mdna:84]
Results of Operations

[0001633978-19-000069:mdna:85]
The results of operations for the periods presented are not necessarily indicative of results to be expected for future periods. The following table summarizes selected consolidated statements of operations items as a percentage of net revenue:

[0001633978-19-000069:mdna:86]
|  | Years Ended |
|  | June 29, 2019 |  | June 30, 2018 |  | July 1, 2017 |
| Segment net revenue: |  |  |  |  |  |
| OpComms | 87.5 | % |  | 84.9 | % |  | 85.6 | % |
| Lasers | 12.5 |  |  | 15.1 |  |  | 14.4 |  |
| Net revenue | 100.0 |  |  | 100.0 |  |  | 100.0 |  |
| Cost of sales | 69.8 |  |  | 65.1 |  |  | 67.6 |  |
| Amortization of acquired intangibles | 3.0 |  |  | 0.3 |  |  | 0.6 |  |
| Gross profit | 27.2 |  |  | 34.6 |  |  | 31.8 |  |
| Operating expenses: |  |  |  |  |  |
| Research and development | 11.8 |  |  | 12.6 |  |  | 14.8 |  |
| Selling, general and administrative | 12.8 |  |  | 10.3 |  |  | 11.0 |  |
| Restructuring and related charges | 2.0 |  |  | 0.6 |  |  | 1.2 |  |
| Impairment charge | 2.0 |  |  | — |  |  | — |  |
| Total operating expenses | 28.6 |  |  | 23.4 |  |  | 27.0 |  |
| Income/(loss) from operations | (1.4 | ) |  | 11.2 |  |  | 4.8 |  |
| Unrealized gain (loss) on derivative liability | 0.6 |  |  | (0.1 | ) |  | (10.4 | ) |
| Interest and other income (expense), net | (1.3 | ) |  | (0.8 | ) |  | (0.3 | ) |
| Income/(loss) before income taxes | (2.1 | ) |  | 10.4 |  |  | (6.0 | ) |
| Provision for (benefit from) income taxes | 0.2 |  |  | (9.5 | ) |  | 4.3 |  |
| Net income/(loss) | (2.3 | )% |  | 19.9 | % |  | (10.2 | )% |

[0001633978-19-000069:mdna:87]
Financial Data for Fiscal 2019, 2018 and 2017

[0001633978-19-000069:mdna:88]
The following table summarizes selected consolidated statements of operations items (in millions, except for percentages):

[0001633978-19-000069:mdna:89]
|  | 2019 |  | 2018 |  | Change |  | Percentage Change |  | 2018 |  | 2017 |  | Change |  | Percentage Change |
| Segment net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| OpComms | $ | 1,370.2 |  |  | $ | 1,059.2 |  |  | $ | 311.0 |  |  | 29.4 | % |  | $ | 1,059.2 |  |  | $ | 857.8 |  |  | $ | 201.4 |  |  | 23.5 | % |
| Lasers | 195.1 |  |  | 188.5 |  |  | 6.6 |  |  | 3.5 |  |  | 188.5 |  |  | 143.8 |  |  | 44.7 |  |  | 31.1 |  |
| Net revenue | $ | 1,565.3 |  |  | $ | 1,247.7 |  |  | $ | 317.6 |  |  | 25.5 | % |  | $ | 1,247.7 |  |  | $ | 1,001.6 |  |  | $ | 246.1 |  |  | 24.6 | % |
| Gross profit | $ | 425.9 |  |  | $ | 432.1 |  |  | $ | (6.2 | ) |  | (1.4 | )% |  | $ | 432.1 |  |  | $ | 318.1 |  |  | $ | 114.0 |  |  | 35.8 | % |
| Gross margin | 27.2 | % |  | 34.6 | % |  |  |  |  |  | 34.6 | % |  | 31.8 | % |  |  |  |  |
| Research and development | $ | 184.6 |  |  | $ | 156.8 |  |  | $ | 27.8 |  |  | 17.7 | % |  | $ | 156.8 |  |  | $ | 148.3 |  |  | $ | 8.5 |  |  | 5.7 | % |
| Percentage of net revenue | 11.8 | % |  | 12.6 | % |  |  |  |  |  | 12.6 | % |  | 14.8 | % |  |  |  |  |
| Selling, general and administrative | $ | 200.3 |  |  | $ | 128.2 |  |  | $ | 72.1 |  |  | 56.2 | % |  | $ | 128.2 |  |  | $ | 110.2 |  |  | $ | 18.0 |  |  | 16.3 | % |
| Percentage of net revenue | 12.8 | % |  | 10.3 | % |  |  |  |  |  | 10.3 | % |  | 11.0 | % |  |  |  |  |
| Restructuring and related charges | $ | 31.9 |  |  | $ | 7.2 |  |  | $ | 24.7 |  |  | 343.1 | % |  | $ | 7.2 |  |  | $ | 12.0 |  |  | $ | (4.8 | ) |  | (40.0 | )% |
| Percentage of net revenue | 2.0 | % |  | 0.6 | % |  |  |  |  |  | 0.6 | % |  | 1.2 | % |  |  |  |  |
| Impairment charge | $ | 30.7 |  |  | $ | — |  |  | $ | 30.7 |  |  | 100.0 | % |  | — |  |  | — |  |  | $ | — |  |  | — | % |
| Percentage of net revenue | 2.0 | % |  | — | % |  |  |  |  |  | — | % |  | — | % |  |  |  |  |

[0001633978-19-000069:mdna:90]
Net Revenue

[0001633978-19-000069:mdna:91]
Net revenue increased by $317.6 million, or 25.5%, during fiscal 2019 compared to fiscal 2018. This increase was primarily due to the acquisition of Oclaro, which closed in December 2018, and organic growth in our Telecom business.

[0001633978-19-000069:mdna:92]
OpComms net revenue increased by $311.0 million, or 29.4%, during fiscal 2019 compared to fiscal 2018, primarily driven by increased sales of  Telecom Products of $310.2 million, specifically ROADM products of $165.3 million. OpComms net revenue in fiscal 2019 includes $250.1 million from the acquisition of Oclaro from the date of closing.

[0001633978-19-000069:mdna:93]
Lasers net revenue increased by $6.6 million, or 3.5%, during fiscal 2019 compared to fiscal 2018, primarily due to increased sales of our kilowatt class fiber lasers, offset by lower sales of our solid state lasers products.

[0001633978-19-000069:mdna:94]
Net revenue increased by $246.1 million, or 24.6%, during fiscal 2018 compared to fiscal 2017. This increase was primarily due to record revenues in 3D sensing, TrueFlex® ROADMs, commercial lasers, and industrial diode lasers.

[0001633978-19-000069:mdna:95]
OpComms net revenue increased $201.4 million, or 23.5%, during fiscal 2018 compared to fiscal 2017, driven by increased sales of Consumer and Industrial products of $386.7 million, primarily in 3D sensing for mobile devices and engage numerous customers globally, partially offset by decreased sales of Telecom and Datacom products.

[0001633978-19-000069:mdna:96]
Lasers net revenue increased $44.7 million, or 31.1%, in fiscal 2018 compared to fiscal 2017, primarily due to increased sales of our kilowatt class fiber lasers. Growth was driven by strong demand from customers in both the micro and macro material processing markets.

[0001633978-19-000069:mdna:97]
During our fiscal 2019, 2018, and 2017, net revenue generated from a single customer which represented 10% or greater of total net revenue is summarized as follows:

[0001633978-19-000069:mdna:98]
|  | Years Ended |
|  | June 29, 2019 |  | June 30, 2018 |  | July 1, 2017 |
| Apple | 21.0 | % |  | 30.0 | % |  | * |  |
| Huawei | 15.2 | % |  | 11.0 | % |  | 16.7 | % |
| Ciena | 13.7 | % |  | 11.0 | % |  | 18.5 | % |
| Cisco | * |  |  | * |  |  | 12.4 | % |
| *Represents less than 10% of total net revenue |  |  |  |  |  |

[0001633978-19-000069:mdna:99]
Revenue by Region

[0001633978-19-000069:mdna:100]
We operate in three geographic regions: Americas, Asia-Pacific and EMEA. Net revenue is assigned to the geographic region and country where our product is initially shipped. For example, certain customers may request shipment of our product to a contract manufacturer in one country, however, the location of the end customers may differ. The following table presents net revenue by the three geographic regions we operate in and net revenue from countries within those regions that represented 10% or more of our total net revenue (in millions, except for percentages):

[0001633978-19-000069:mdna:101]
|  | Years Ended |
|  | June 29, 2019 |  | June 30, 2018 |  | July 1, 2017 |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |
| United States | $ | 100.9 |  |  | 6.4 | % |  | $ | 115.1 |  |  | 9.2 | % |  | $ | 147.9 |  |  | 14.8 | % |
| Mexico | 214.9 |  |  | 13.7 |  |  | 145.8 |  |  | 11.7 |  |  | 185.1 |  |  | 18.5 |  |
| Other Americas | 4.3 |  |  | 0.3 |  |  | 7.0 |  |  | 0.6 |  |  | 9.2 |  |  | 0.9 |  |
| Total Americas | $ | 320.1 |  |  | 20.4 | % |  | $ | 267.9 |  |  | 21.5 | % |  | $ | 342.2 |  |  | 34.2 | % |
| Asia-Pacific: |  |  |  |  |  |  |  |  |  |  |  |
| Hong Kong | $ | 387.9 |  |  | 24.8 | % |  | $ | 183.0 |  |  | 14.7 | % |  | $ | 226.7 |  |  | 22.6 | % |
| Japan | 176.0 |  |  | 11.2 |  |  | 194.7 |  |  | 15.6 |  |  | 99.2 |  |  | 9.9 |  |
| South Korea | 162.4 |  |  | 10.4 |  |  | 146.1 |  |  | 11.7 |  |  | 4.9 |  |  | 0.5 |  |
| Other Asia-Pacific | 356.1 |  |  | 22.7 |  |  | 354.2 |  |  | 28.3 |  |  | 220.5 |  |  | 22.0 |  |
| Total Asia-Pacific | $ | 1,082.4 |  |  | 69.1 | % |  | $ | 878.0 |  |  | 70.3 | % |  | $ | 551.3 |  |  | 55.0 | % |
| EMEA | $ | 162.8 |  |  | 10.5 | % |  | $ | 101.8 |  |  | 8.2 | % |  | $ | 108.1 |  |  | 10.8 | % |
| Total net revenue | $ | 1,565.3 |  |  |  |  | $ | 1,247.7 |  |  |  |  | $ | 1,001.6 |  |  |  |

[0001633978-19-000069:mdna:102]
During fiscal 2019, 2018 and 2017, net revenue from customers outside the United States, based on customer shipping location, represented 93.6%, 90.8% and 85.2% of net revenue, respectively. Our net revenue from Mexico increased in fiscal 2019 compared to 2018 due to increased demand for our ROADM products from one of our large customers who manufactures in Mexico, while net revenue from Hong Kong grew due to a change in shipment destination of a large portion of our 3D sensing products for mobile devices.

[0001633978-19-000069:mdna:103]
Our net revenue is primarily denominated in U.S. dollars, including our net revenue from customers outside the United States as presented above. We expect revenue from customers outside of the United States to continue to be an important part of our overall net revenue and an increasing focus for net revenue growth opportunities. However, regulatory and enforcement actions by U.S. and other governmental agencies, as well as changes in tax and trade policies and tariffs, may impact net revenue from customers outside the United States in future periods.

[0001633978-19-000069:mdna:104]
Gross Margin and Segment Gross Margin

[0001633978-19-000069:mdna:105]
The following table summarizes segment gross margin for fiscal 2019, 2018 and 2017 (in millions, except for percentages):

[0001633978-19-000069:mdna:106]
|  | Gross Profit |  | Gross Margin |
|  | Years Ended |  | Years Ended |
|  | 2019 |  | 2018 |  | 2017 |  | 2019 |  | 2018 |  | 2017 |
| OpComms | $ | 534.1 |  |  | $ | 402.3 |  |  | $ | 287.3 |  |  | 39.0 | % |  | 38.0 | % |  | 33.5 | % |
| Lasers | 84.4 |  |  | 82.8 |  |  | 59.9 |  |  | 43.3 | % |  | 43.9 | % |  | 41.7 | % |
| Segment total | $ | 618.5 |  |  | $ | 485.1 |  |  | $ | 347.2 |  |  | 39.5 | % |  | 38.9 | % |  | 34.7 | % |
| Unallocated corporate items: |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation | (15.1 | ) |  | (12.6 | ) |  | (7.5 | ) |  |  |  |  |  |  |
| Amortization of intangibles | (46.6 | ) |  | (3.2 | ) |  | (6.5 | ) |  |  |  |  |  |  |
| Amortization of inventory step up | (54.6 | ) |  | — |  |  | — |  |  |  |  |  |  |  |
| Inventory write down due to product lines exit | (20.8 | ) |  | — |  |  | — |  |  |  |  |  |  |  |
| Integration related costs | (6.6 | ) |  | — |  |  | — |  |  |  |  |  |  |  |
| Other charges (1) | (48.9 | ) |  | (37.2 | ) |  | (15.1 | ) |  |  |  |  |  |  |
| Total | $ | 425.9 |  |  | $ | 432.1 |  |  | $ | 318.1 |  |  | 27.2 | % |  | 34.6 | % |  | 31.8 | % |

[0001633978-19-000069:mdna:107]
The unallocated corporate items for the periods presented include the effects of amortization of acquired developed technologies and other intangibles, share-based compensation and certain other charges. We do not allocate these items to the gross margin for each segment because management does not include such information in measuring the performance of the operating segments.

[0001633978-19-000069:mdna:108]
(1) The increase in “other charges” of unallocated corporate items for fiscal 2019 compared to fiscal 2018 primarily relates to set-up costs of our facility in Thailand, including costs of transferring the manufacturing of product lines to Thailand of $45.8 million in fiscal 2019 compared to $27.0 million in fiscal 2018.

[0001633978-19-000069:mdna:109]
The increase in “other charges” of unallocated corporate items for fiscal 2018 compared to fiscal 2017 primarily relates to set-up costs of our facility in Thailand, including costs of transferring the manufacturing of product lines to Thailand of $27.0 million in fiscal 2018 compared to $1.8 million in fiscal 2017.

[0001633978-19-000069:mdna:110]
Gross Margin

[0001633978-19-000069:mdna:111]
Gross margin in fiscal 2019 decreased to 27.2% from 34.6% in fiscal 2018. The decrease was primarily due to amortization of intangibles and amortization of inventory step up related to the acquisition of Oclaro, as well as inventory write down charges of $20.8 million due to our exit of Datacom module and Lithium Niobate product lines.

[0001633978-19-000069:mdna:112]
Gross margin in fiscal 2018 increased to 34.6% from 31.8% in fiscal 2017. The increase was primarily due to increased sales in our 3D sensing and lasers products, which have higher gross margins than the average for the Company. The increase was partially offset by underutilized capacity costs due to the decline in Telecom and Datacom demand, higher write-downs of excess and obsolete inventory of $1.2 million, as well as set-up costs of our facility in Thailand, including costs of transferring product lines to Thailand of $27.0 million in our fiscal 2018 compared to $1.8 million in fiscal 2017.

[0001633978-19-000069:mdna:113]
We sell products in certain markets that are consolidating, undergoing product, architectural and business model transitions, have high customer concentrations, are highly competitive, are price sensitive and/or are affected by customer seasonal and mix variant buying patterns. We expect these factors to continue to result in variability of our gross margin.

[0001633978-19-000069:mdna:114]
Segment Gross Margin

[0001633978-19-000069:mdna:115]
OpComms

[0001633978-19-000069:mdna:116]
OpComms gross margin in fiscal 2019 increased to 39.0% from 38.0% in fiscal 2018. This increase was primarily due to increased sales of our ROADM products, which have higher gross margins than the average for the segment as well as increased sales of our transmission products due to the acquisition of Oclaro which have higher gross margins than legacy transmission products. This was partially offset by decreased sales of our 3D sensing products which have higher gross margins than the average for this segment.

[0001633978-19-000069:mdna:117]
OpComms gross margin in fiscal 2018 increased to 38.0% from 33.5% in fiscal 2017. This increase was primarily due to increased sales of our 3D sensing products, which have higher gross margins than the average for the segment. The increase was partially offset by underutilized capacity costs due to the decline in Telecom and Datacom demand.

[0001633978-19-000069:mdna:118]
Lasers

[0001633978-19-000069:mdna:119]
Lasers gross margin in fiscal 2019 decreased to 43.3% from 43.9% in fiscal 2018. This decrease was primarily due to decreased sales of our solid state products which have higher gross margins than the average for the segment. This was partially offset by increased revenue and manufacturing utilization for our kilowatt class fiber products.

[0001633978-19-000069:mdna:120]
Lasers gross margin in fiscal 2018 increased to 43.9% from 41.7% in fiscal 2017. This increase was primarily due to increased sales of solid state lasers products, which have higher gross margins than the average for the segment.

[0001633978-19-000069:mdna:121]
Research and Development (“R&D”)

[0001633978-19-000069:mdna:122]
R&D expense increased by $27.8 million, or 17.7%, in fiscal 2019 compared to fiscal 2018. The increase in R&D expense was primarily due to the increase in investments in key product lines and R&D materials. In addition, we had an increase in payroll related expense of $10.1 million as a result of our acquisition of Oclaro.

[0001633978-19-000069:mdna:123]
R&D expense increased by $8.5 million, or 5.7%, in fiscal 2018 compared to fiscal 2017. The increase in R&D expense was primarily due to the increase in stock-based compensation of $2.6 million and payroll related expense of $4.1 million, which includes an increase in variable incentive compensation of $2.9 million.

[0001633978-19-000069:mdna:124]
We believe that continuing our investments in R&D is critical to attaining our strategic objectives. We plan to continue to invest in R&D and new products that we believe will further differentiate us in the marketplace and expect our investment in R&D to increase in absolute dollars in future quarters.

[0001633978-19-000069:mdna:125]
Selling, General and Administrative (“SG&A”)

[0001633978-19-000069:mdna:126]
SG&A expense increased by $72.1 million, or 56.2%, in fiscal 2019 compared to fiscal 2018. The increase was primarily attributable to additional costs from our acquisition of Oclaro, including $14.6 million of payroll related expense, $2.4 million of facility related expense, $13.3 million in charges related to the acceleration of equity awards under certain Oclaro executive severance and retention agreements, $9.0 million related to the success fee on the closing of the Oclaro transaction, $8.0 million related to the amortization of acquired intangibles, and $3.1 million related to the incremental stock-based compensation expense of Oclaro awards. The remainder of the increase was primarily driven by higher payroll related expense and stock-based compensation.

[0001633978-19-000069:mdna:127]
SG&A expense increased by $18.0 million, or 16.3%, in fiscal 2018 compared to fiscal 2017. The increase was primarily attributable to increases in stock-based compensation of $6.4 million and payroll related expense of $10.5 million, which includes an increase in variable incentive compensation of $3.8 million. We also incurred $4.8 million of costs related to the planned acquisition of Oclaro during our fiscal 2018.

[0001633978-19-000069:mdna:128]
We expect to experience in the future certain non-core expenses, such as mergers and acquisition-related expenses and litigation expenses, which will likely increase our SG&A expenses and potentially impact our profitability expectations in any particular quarter.

[0001633978-19-000069:mdna:129]
Restructuring and Related Charges

[0001633978-19-000069:mdna:130]
We have initiated various strategic restructuring events primarily intended to reduce costs, consolidate our operations, rationalize the manufacturing of our products and align our business in response to market conditions and as a result of our acquisition of Oclaro.

[0001633978-19-000069:mdna:131]
During fiscal 2019, we recorded $31.9 million in restructuring and related charges in our consolidated statements of operations.

[0001633978-19-000069:mdna:132]
•During the first quarter  of 2019, we recorded $1.3 million of severance costs primarily due to an internal re-organization in order to extend our market leadership position by strengthening product quality, to develop new enabling technologies required to support a winning long-term portfolio roadmap, and to develop commercial proposals and new product introduction (“NPI”) priorities to maintain and grow our position while driving new customer and eco-system partner engagements.

[0001633978-19-000069:mdna:133]
•During the second quarter of 2019, we recorded $5.7 million primarily attributable to severance and employee related benefits associated with Oclaro’s executive severance and retention agreements. These retention agreements provide, under certain circumstances, for payments and benefits upon an involuntary termination of employment.

[0001633978-19-000069:mdna:134]
•During the third quarter of 2019, we recorded $21.1 million primarily attributable to severance and employee related benefits associated with the wind down of operations for Lithium Niobate modulators and Datacom modules. We also recorded an additional $1.6 million of lease restructuring charges for the former Oclaro corporate headquarters.

[0001633978-19-000069:mdna:135]
Refer to “Note 14. Restructuring and Related Charges” in the notes to consolidated financial statements.

[0001633978-19-000069:mdna:136]
During fiscal 2018, we recorded $7.2 million in restructuring and related charges in the consolidated statements of operations.

[0001633978-19-000069:mdna:137]
| • | During the fourth quarter of fiscal 2018, we initiated a new restructuring plan in order to realign the organization and enable further investment in key priority areas. As a result, a restructuring charge of $3.4 million was recorded for severance costs and employee benefits. In total, 52 employees in manufacturing, R&D and SG&A functions were terminated in connection with this new restructuring plan. |

[0001633978-19-000069:mdna:138]
| • | We also incurred restructuring and related charges of $3.8 million from restructuring plans approved prior to fiscal 2016 primarily related to the shut down of our manufacturing facility in Bloomfield, Connecticut as a result of the transfer of certain production processes into existing sites in the United States or to contract manufacturers. |

[0001633978-19-000069:mdna:139]
During fiscal 2017, we recorded $12.0 million in restructuring and related charges. Of the $12.0 million charge recorded during fiscal 2017, $2.1 million related to severance, retention and employee benefits.

[0001633978-19-000069:mdna:140]
Impairment Charges

[0001633978-19-000069:mdna:141]
In fiscal 2019,  we announced our plan to discontinue the development and manufacturing of future Datacom transceiver products which impacted the Milpitas and Shenzhen Datacom module teams. While we expect strong growth in Datacom volumes in the future, the market at the transceiver level is gross margin challenged due to extreme competition. Following the Oclaro acquisition, we have a differentiated leadership position across a range of photonic chips on which the Datacom, wireless, and access markets critically rely.

[0001633978-19-000069:mdna:142]
In fiscal 2019, we recorded $30.7 million in long lived asset impairment charges in connection with the above plan. Refer to “Note 9. Balance Sheet Details” and “Note 15. Impairment Charges” in the notes to consolidated financial statements for additional information.

[0001633978-19-000069:mdna:143]
Interest and Other Income (Expense), Net

[0001633978-19-000069:mdna:144]
The components of interest and other income (expense), net are as follows for the years presented (in millions):

[0001633978-19-000069:mdna:145]
|  | Years Ended |
|  | June 29, 2019 |  | June 30, 2018 |  | July 1, 2017 |
| Interest expense | $ | (36.3 | ) |  | $ | (18.2 | ) |  | $ | (5.5 | ) |
| Foreign exchange gains (losses), net | (0.6 | ) |  | (0.3 | ) |  | 0.6 |  |
| Interest income | 13.9 |  |  | 8.5 |  |  | 1.1 |  |
| Other income (expense), net | 2.5 |  |  | 0.3 |  |  | 0.6 |  |
| Total other income (expense), net | $ | 15.8 |  |  | $ | 8.5 |  |  | $ | 2.3 |  |

[0001633978-19-000069:mdna:146]
During fiscal 2019, interest and other income (expense), net increased by $10.8 million in expense as compared to fiscal 2018, mainly driven by interest expense on our term loan and ticking fees, partially offset by higher interest income due to high interest rates owned on our investment portfolio.

[0001633978-19-000069:mdna:147]
During fiscal 2018, interest and other income (expense), net increased by $6.5 million in expense as compared to fiscal 2017, mainly driven by amortization of the debt discount on the 2024 Notes of $16.7 million in our fiscal 2018 compared to $5.1 million in fiscal 2017, partially offset by interest income on the short-term investments and cash equivalents of $8.5 million in our fiscal 2018 compared to $1.1 million in fiscal 2017.

[0001633978-19-000069:mdna:148]
Unrealized Gain (Loss) on Derivative Liability

[0001633978-19-000069:mdna:149]
Unrealized gain (loss) on Series A Preferred Stock derivative liability amounted to $8.8 million and $(0.8) million in fiscal 2019 and 2018, respectively. The change was primarily related to the change in the price of our underlying common stock and reflected in the consolidated statements of operations as “unrealized gain (loss) on derivative liability”. On November 2, 2018, all 35,805 shares of our Series A Preferred Stock were converted to common stock with the outstanding balance of the embedded derivative liability reclassed to additional paid in capital. There will be no further adjustments to “unrealized gain (loss) on derivative liability” due to this conversion.

[0001633978-19-000069:mdna:150]
For further discussion of our derivative liability, see “Note 12. Non-Controlling Interest Redeemable Convertible Preferred Stock and Derivative Liability” in the notes to consolidated financial statements.

[0001633978-19-000069:mdna:151]
Provision for (Benefit from) Income Taxes (in millions):

[0001633978-19-000069:mdna:152]
|  |  | Years Ended |
|  |  | June 29, 2019 |  | June 30, 2018 |  | July 1, 2017 |
| Provision for (benefit from) income taxes |  | $ | 3.1 |  |  | $ | (118.7 | ) |  | $ | 42.7 |  |

[0001633978-19-000069:mdna:153]
The comparability of our operating results for fiscal 2019 compared to the corresponding prior years was impacted by the U.S. Tax Cuts and Jobs Act of 2017 (the “Tax Act”), which was enacted on December 22, 2017. The Tax Act introduced significant changes to U.S. income tax law including reducing the U.S. federal statutory tax rate from 35% to 21% and imposing new taxes on certain foreign-sourced earnings and certain intercompany payments. Due to the timing of the enactment and the complexity involved in applying the provisions of the Tax Act, we made reasonable estimates of the effects and recorded provisional amounts in our financial statements as of fiscal 2018 in accordance with SEC Staff Accounting Bulletin No. 118 (“SAB 118”). During the period ended December 29, 2018, we completed our accounting for the Tax Act with no material adjustment to our provisional estimates recorded.

[0001633978-19-000069:mdna:154]
Our provision for income taxes for fiscal 2019 differs from the 21% U.S. statutory rate primarily due to the income tax expense from non-deductible stock-based compensation and the tax effect of increased valuation allowance in the U.K. and Thailand, Global Intangible Low-Taxed Income (“GILTI”), Base Erosion and Anti-Abuse Tax (“BEAT”) and subpart F inclusion, partially offset by the income tax benefit of the earnings of our foreign subsidiaries being taxed at rates that differ from the U.S. statutory rate as well as the U.S. federal R&D tax credit.

[0001633978-19-000069:mdna:155]
Our provision for income taxes for fiscal 2018 differed from the tax provision based on the U.S. statutory federal income tax rate of approximately 28% as a result of $207.2 million of income tax benefit related to the release of valuation allowance against

[0001633978-19-000069:mdna:156]
our U.S. federal and certain state deferred tax assets, partially offset by $80.5 million of income tax expense related to the remeasurement of our net deferred tax assets as a result of reduction in the U.S. federal corporate tax rate. Our provision for income taxes was also impacted by the benefit our foreign income being taxed at lower rates than the U.S. statutory rate, as well as the benefit of research and development tax credits.

[0001633978-19-000069:mdna:157]
Our provision for income taxes for fiscal 2017 differed from the tax provision based on the then-U.S. statutory federal income tax rate of 35% primarily as a result of $36.5 million of income tax expense related to the non-deductible unrealized losses associated with the embedded derivatives for the Series A Preferred Stock and the 2024 Notes, as well as $8.4 million of unrecognized tax benefits, $4.9 million of non-deductible stock-based compensation, and $21.5 million of changes in the valuation allowance against our deferred tax assets. Our provision for income taxes was also impacted by the benefit of our foreign income being taxed at lower rates than the U.S. statutory rate, as well as the income tax benefit of research and development tax credits.

[0001633978-19-000069:mdna:158]
Contractual Obligations

[0001633978-19-000069:mdna:159]
The following table summarizes our contractual obligations as of June 29, 2019, and the effect such obligations are expected to have on our liquidity and cash flow over the next five years (in millions):

[0001633978-19-000069:mdna:160]
|  | Payments due by period |
|  | Total |  | Less than 1 year |  | 1 - 3 years |  | 3 - 5 years |  | More than 5 years |
| Contractual Obligations |  |  |  |  |  |  |  |  |  |
| Acquisition contingencies (1) | $ | 2.7 |  |  | $ | 2.7 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Asset retirement obligations | 5.5 |  |  | 1.0 |  |  | 0.8 |  |  | 0.6 |  |  | 3.1 |  |
| Capital lease obligations (2) | 0.8 |  |  | 0.8 |  |  | — |  |  | — |  |  | — |  |
| Operating lease obligations (2) | 90.0 |  |  | 13.9 |  |  | 23.3 |  |  | 21.1 |  |  | 31.7 |  |
| Pension plan contributions (3) | 0.5 |  |  | 0.5 |  |  | — |  |  | — |  |  | — |  |
| Purchase obligations (4) | 216.4 |  |  | 209.7 |  |  | 6.6 |  |  | 0.1 |  |  | — |  |
| Term loan - principal (5) | 497.5 |  |  | 5.0 |  |  | 10.0 |  |  | 10.0 |  |  | 472.5 |  |
| Term loan - interest (5) | 151.8 |  |  | 24.2 |  |  | 47.7 |  |  | 46.8 |  |  | 33.1 |  |
| Convertible notes - principal (6) | 450.0 |  |  | — |  |  | — |  |  | 450.0 |  |  | — |  |
| Convertible notes - interest (7) | 5.6 |  |  | 1.1 |  |  | 2.2 |  |  | 2.3 |  |  | — |  |
| Total | $ | 1,420.8 |  |  | $ | 258.9 |  |  | $ | 90.6 |  |  | $ | 530.9 |  |  | $ | 540.4 |  |

[0001633978-19-000069:mdna:161]
(1) Refer to “Note 11. Fair Value Measurements” in the notes to consolidated financial statements.

[0001633978-19-000069:mdna:162]
(2) Refer to “Note 19. Commitments and Contingencies” in the notes to consolidated financial statements. The amounts of operating lease obligations in the table above are net of our sublease income amounts.

[0001633978-19-000069:mdna:163]
In fiscal 2019, 2018 and 2017, rental expense relating to building and equipment was $15.8 million, $12.1 million and $10.1 million, respectively. Non-cancellable sublease proceeds from our subleases were approximately $1.0 million, $0.7 million, and $0.7 million, respectively, during fiscal years 2019, 2018, and 2017. The amounts of our rental expense for the years presented are net of these sublease income amounts.

[0001633978-19-000069:mdna:164]
(3) In connection with our acquisitions of Oclaro in fiscal 2019 and Time-Bandwidth in fiscal 2014, we assumed defined benefit plans for Japan and Switzerland employees, respectively. The Switzerland Plan is partially funded. The Japan Plan is unfunded. The amount in the preceding table represents planned contributions to our defined benefit plans. Although additional future contributions will be required, the amount and timing of these contributions will be affected by actuarial assumptions, the actual rate of returns on plan assets, the level of market interest rates, legislative changes, and the amount of voluntary contributions to the plan. Any contributions for the following fiscal year and later will depend on the value of the plan assets in the future and thus are uncertain. As such, we have not included any amounts beyond 1 year in the table above. Refer to “Note 18. Employee Benefit Plans”  in the notes to consolidated financial statements.

[0001633978-19-000069:mdna:165]
(4) Purchase obligations represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Refer to “Note 19. Commitments and Contingencies” in the notes to consolidated financial statements.

[0001633978-19-000069:mdna:166]
(5) We incurred indebtedness in an aggregate principal amount of $500.0 million pursuant to a senior secured Term Loan Facility that we entered into in connection with the closing of the Oclaro acquisition on December 10, 2018. The amounts of interest included in the table above is based on current interest rates. Refer to “Note 7. Term Loan Facility” in the notes to consolidated financial statements.

[0001633978-19-000069:mdna:167]
(6) Refer to “Note 13. Convertible Notes” in the notes to consolidated financial statements.

[0001633978-19-000069:mdna:168]
(7) Includes interest on our 0.25% Convertible Notes due in 2024 through March 2024 as we have the right to redeem the 2024 Notes in whole or in part at any time on or after March 15, 2024. Refer to “Note 13. Convertible Notes” in the notes to consolidated financial statements.

[0001633978-19-000069:mdna:169]
As of June 29, 2019, our other non-current liabilities also include $18.7 million of unrecognized tax benefit for uncertain tax positions. We are unable to reliably estimate the timing of future payments related to uncertain tax positions and therefore have excluded them from the preceding table.

[0001633978-19-000069:mdna:170]
Off-Balance Sheet Arrangements

[0001633978-19-000069:mdna:171]
We do not have any off-balance sheet arrangements, as such term is defined in rules promulgated by the SEC, that have or are reasonably likely to have a current or future effect on our financial condition, changes in financial condition, revenues or expenses, results of operations, liquidity, capital expenditures or capital resources that are material to investors.

[0001633978-19-000069:mdna:172]
Defined Benefit Plans

[0001633978-19-000069:mdna:173]
As a result of acquiring Time-Bandwidth in January 2014, we have a pension plan for our employees in Switzerland. This plan is open to new participants and additional service costs are being accrued. The Switzerland Plan is partially funded. As of June 29, 2019, our pension plan was under funded by $5.0 million since the projected benefit obligation (“PBO”) exceeded the fair value of the plan assets.

[0001633978-19-000069:mdna:174]
In connection with the acquisition of Oclaro in December 2018, we assumed a defined benefit plan which provides benefits to our employees in Japan. This plan is open to new participants. Benefits are generally based upon an employee’s individual grade level and years of service. Employees are entitled to a lump sum benefit upon retirement or upon certain instances of termination. As of June 29, 2019, there were no Japan Plan assets. The net obligation of $2.8 million as of June 29, 2019 is recorded in our consolidated balance sheets as non-current liabilities and is reflective of the total PBO.

[0001633978-19-000069:mdna:175]
A key actuarial assumption in calculating the net periodic cost and the PBO is the discount rate. Changes in the discount rate impact the interest cost component of the net periodic benefit cost calculation and PBO due to the fact that the PBO is calculated on a net present value basis. Decreases in the discount rate will generally increase pre-tax cost, recognized expense and the PBO. Increases in the discount rate tend to have the opposite effect. We estimate a 50 basis point decrease or increase in the discount rate would cause a corresponding increase or decrease, respectively, in the PBO of $1.4 million or $(1.3) million, based upon data as of June 29, 2019.

[0001633978-19-000069:mdna:176]
We expect to contribute $0.5 million to our Japan and Switzerland pension plans in fiscal 2020.

[0001633978-19-000069:mdna:177]
Financial Condition

[0001633978-19-000069:mdna:178]
Liquidity and Capital Resources

[0001633978-19-000069:mdna:179]
As of June 29, 2019 and June 30, 2018, our cash and cash equivalents of $432.6 million and $397.3 million, respectively, were largely held in the United States. The total amount of cash outside the United States as of June 29, 2019 was $100.5 million, which was primarily held by entities incorporated in Japan, the United Kingdom, Thailand, the British Virgin Islands, China, and the Netherlands.  Although the cash currently held in the United States as well as the cash generated in the United States from future operations is expected to cover our normal operating requirements, a substantial amount of additional cash could be required for other purposes, such as capital expenditures to support our business and growth, including costs associated with increasing internal manufacturing capabilities, such as our new Thailand facility, strategic transactions and partnerships, and future acquisitions. Except for the cash and cash equivalents held in the Cayman Islands, Japan and Hong Kong, our intent is to indefinitely reinvest the cash and cash equivalents held outside the United States since our current plans do not demonstrate a need to repatriate them to fund our domestic operations. However, if in the future, we encounter a significant need for liquidity domestically or at a particular location that we cannot fulfill through borrowings, equity offerings, or other internal or external sources, or the cost to bring back the money is insignificant from a tax perspective, we may determine that cash repatriations are necessary or desirable. Repatriation could result in material additional taxes. These factors may cause us to have an overall tax rate higher than other

[0001633978-19-000069:mdna:180]
companies or higher than our tax rates have been in the past. If conditions warrant, we may seek to obtain additional financing through debt or equity sources. To the extent we issue additional shares, our existing stockholders may be diluted. However, any such financing may not be available on terms favorable to us, or may not be available at all.

[0001633978-19-000069:mdna:181]
Fiscal 2019

[0001633978-19-000069:mdna:182]
As of June 29, 2019, our consolidated balance of cash and cash equivalents increased by $35.3 million, to $432.6 million from $397.3 million as of June 30, 2018. The increase in cash and cash equivalents was mainly due to cash provided by financing activities of $485.1 million, primarily related to $490.8 million in proceeds from a term loan, net of debt issuance costs, used to fund the Oclaro acquisition, and cash provided by operating activities of $330.1 million during the year ended June 29, 2019; which was offset by cash used in investing activities of $779.7 million, principally related to net cash of $619.8 million paid to acquire Oclaro.

[0001633978-19-000069:mdna:183]
Cash provided by operating activities of $330.1 million during the year ended June 29, 2019, primarily resulted from $314.4 million of non-cash items (such as depreciation, stock-based compensation, amortization of intangibles, amortization of discount on the 2024 Notes, amortization of the debt issuance costs on the term loan, amortization of fair value adjustment in connection with the acquisition of Oclaro, impairment charges, net of unrealized gain on derivative liability and other non-cash items) and $52.1 million of changes in our operating assets and liabilities, offset by our net loss of $36.4 million.

[0001633978-19-000069:mdna:184]
Cash used in investing activities of $779.7 million during the year ended June 29, 2019, was primarily attributable to $619.8 million paid to acquire all outstanding shares of common stock of Oclaro, net of cash received through the acquisition of Oclaro. In addition, we had capital expenditures of $166.0 million (mainly attributable to the purchase of the property for $54.6 million), payment for asset acquisition of $1.3 million, purchases of short-term investments, net of sales of $18.1 million, offset by proceeds from sales of product lines of $25.5 million.

[0001633978-19-000069:mdna:185]
Cash provided by financing activities of $485.1 million during the year ended June 29, 2019, primarily resulted from $490.8 million of proceeds from a term loan, net of debt issuance costs, used to partially finance the Oclaro acquisition, offset by the repayment of a term loan of $2.5 million. In addition, we received $9.3 million from the issuance of common stock under our employee stock plan, offset by the repayment of capital lease obligations of $8.8 million, tax payments related to restricted stock of $2.4 million, a payment of an acquisition related holdback of $1.0 million, and dividend payments on our Series A Preferred Stock of $0.7 million.

[0001633978-19-000069:mdna:186]
Fiscal 2018

[0001633978-19-000069:mdna:187]
As of June 30, 2018, our consolidated balance of cash and cash equivalents increased by $124.4 million, to $397.3 million from $272.9 million as of July 1, 2017. The increase in cash and cash equivalents was mainly due to cash provided by operating activities of $247.5 million during fiscal 2018 offset by purchases of short-term investments, net of sales of $33.8 million and capital expenditures of $93.2 million.

[0001633978-19-000069:mdna:188]
Cash provided by operating activities was $247.5 million for the year ended June 30, 2018, primarily resulting from $248.1 million of net income and $18.5 million of non-cash items (such as depreciation, stock-based compensation, amortization of intangibles, amortization of discount on the 2024 Notes, net of the release of the valuation allowance), offset by $19.1 million of changes in our operating assets and liabilities. Changes in our operating assets and liabilities related primarily to an increase in accounts receivable of $30.8 million, offset by an increase in accrued expenses and other current and non-current liabilities of $11.9 million.

[0001633978-19-000069:mdna:189]
Cash used in investing activities of $127.0 million for the year ended June 30, 2018, was primarily attributable to capital expenditures of $93.2 million and purchases of short-term investments, net of sales of $33.8 million.

[0001633978-19-000069:mdna:190]
Cash provided by financing activities was $3.8 million for the year ended June 30, 2018, resulting primarily from the issuance of common stock under the 2015 Employee Stock Purchase Plan of $9.2 million offset by repayment of capital lease obligation of $6.4 million.

[0001633978-19-000069:mdna:191]
Fiscal 2017

[0001633978-19-000069:mdna:192]
As of July 1, 2017, our consolidated balance of cash and cash equivalents increased by $115.8 million, to $272.9 million from $157.1 million as of July 2, 2016. The increase in cash and cash equivalents was mainly due to proceeds from the issuance of the 2024 Notes during fiscal 2017, offset by the purchases of short-term investments and property, plant and equipment.

[0001633978-19-000069:mdna:193]
Cash provided by operating activities was $85.0 million for the year ended July 1, 2017, primarily resulting from $102.5 million of net loss and $199.4 million of non-cash items such as depreciation, stock-based compensation, amortization of intangibles and unrealized loss on derivative liabilities, the impact of which was offset by changes in excess tax benefit associated with stock-

[0001633978-19-000069:mdna:194]
based compensation. In addition, changes in our operating assets and liabilities of $11.9 million related primarily to an increase in inventories of $41.7 million and a decrease in accounts payable of $16.9 million related to non-cash items such as $10.0 million unpaid property, plant and equipment, offset by a decrease in income taxes, net of $42.7 million.

[0001633978-19-000069:mdna:195]
Cash used in investing activities was mainly for capital expenditures and purchases of short-term investments, net of sales of $138.1 million and $282.5 million, respectively, for the year ended July 1, 2017. Changes in investing cash flow in fiscal 2017 also related to the acquisition of a business for $5.1 million.

[0001633978-19-000069:mdna:196]
Cash provided by financing activities was $456.7 million for the year ended July 1, 2017, resulting primarily from proceeds of $442.3 million from the issuance of the 2024 Notes.

[0001633978-19-000069:mdna:197]
Liquidity and Capital Resources Requirements

[0001633978-19-000069:mdna:198]
We believe that our cash and cash equivalents as of June 29, 2019, and cash flows from our operating activities will be sufficient to meet our liquidity and capital spending requirements for at least the next 12 months. However, if market conditions are favorable, we may evaluate alternatives to opportunistically pursue additional financing.

[0001633978-19-000069:mdna:199]
There are a number of factors that could positively or negatively impact our liquidity position, including:

[0001633978-19-000069:mdna:200]
| • | global economic conditions which affect demand for our products and services and impact the financial stability of our suppliers and customers; |

[0001633978-19-000069:mdna:201]
| • | changes in accounts receivable, inventory or other operating assets and liabilities, which affect our working capital; |

[0001633978-19-000069:mdna:202]
| • | increase in capital expenditures to support our business and growth; |

[0001633978-19-000069:mdna:203]
| • | the tendency of customers to delay payments or to negotiate favorable payment terms to manage their own liquidity positions; |

[0001633978-19-000069:mdna:204]
| • | timing of payments to our suppliers; |

[0001633978-19-000069:mdna:205]
| • | factoring or sale of accounts receivable; |

[0001633978-19-000069:mdna:206]
| • | volatility in fixed income and credit, which impact the liquidity and valuation of our investment portfolios; |

[0001633978-19-000069:mdna:207]
| • | volatility in foreign exchange markets, which impacts our financial results; |

[0001633978-19-000069:mdna:208]
| • | possible investments or acquisitions of complementary businesses, products or technologies, or other strategic transactions or partnerships; |

[0001633978-19-000069:mdna:209]
| • | issuance of debt or equity securities, or other financing transactions, including bank debt; |

[0001633978-19-000069:mdna:210]
| • | potential funding of pension liabilities either voluntarily or as required by law or regulation; and |

[0001633978-19-000069:mdna:211]
| • | the settlement of any conversion or redemption of the 2024 Notes in cash. |

[0001633978-19-000069:mdna:212]
In March 2018, we entered into the Merger Agreement with Oclaro. On December 10, 2018, we completed the merger. In accordance with the terms of the Merger Agreement, each issued and outstanding share of Oclaro common stock was automatically converted into the right to receive (i) $5.60 in cash and (ii) 0.0636 of a share of Lumentum common stock. The total transaction consideration was $1.4 billion, funded through a combination of the issuance of Lumentum common stock, new debt obtained through the Term Loan facility, and cash balances of the combined company.
