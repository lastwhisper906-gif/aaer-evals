# LITE 8-K — 0001633978-19-000068 filed 2019-08-08

## item codes, every 8-K on or before 2019-08-27

- 2019-08-08 0001633978-19-000068 — 2.02, 9.01
- 2019-05-08 0001633978-19-000031 — 1.01
- 2019-05-07 0001633978-19-000029 — 2.02, 9.01
- 2019-02-15 0001633978-19-000005 — 9.01 — amendment of 0001193125-18-346211
- 2019-02-08 0001193125-19-031591 — 5.02, 9.01
- 2019-02-05 0001633978-19-000001 — 2.02, 9.01
- 2018-12-10 0001193125-18-346211 — 1.01, 2.01, 2.03, 5.02, 8.01, 9.01
- 2018-12-06 0001633978-18-000150 — 8.01
- 2018-11-14 0001633978-18-000139 — 5.07
- 2018-11-13 0001633978-18-000136 — 3.02
- 2018-11-13 0001633978-18-000132 — 7.01, 9.01
- 2018-11-01 0001628280-18-013238 — 2.02, 9.01
- 2018-08-08 0001633978-18-000056 — 2.02, 9.01
- 2018-06-08 0001193125-18-188241 — 5.02, 9.01
- 2018-05-02 0001633978-18-000029 — 2.02, 9.01
- 2018-03-12 0001193125-18-078154 — 1.01, 2.01, 8.01, 9.01
- 2018-02-06 0001628280-18-001082 — 2.02, 9.01
- 2017-11-08 0001633978-17-000133 — 5.02, 9.01
- 2017-11-07 0001633978-17-000131 — 5.07
- 2017-11-01 0001633978-17-000117 — 2.02, 9.01
- 2017-08-09 0001633978-17-000058 — 2.02, 9.01
- 2017-05-04 0001633978-17-000035 — 2.02, 9.01
- 2017-03-08 0001193125-17-074740 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2017-03-02 0001193125-17-066769 — 8.01, 9.01
- 2017-02-07 0001633978-17-000005 — 2.02, 9.01
- 2017-01-03 0001628280-17-000018 — 4.01, 9.01
- 2016-11-09 0001628280-16-021143 — 5.02, 5.07, 9.01
- 2016-10-27 0001628280-16-020382 — 2.02, 9.01
- 2016-08-09 0001628280-16-018811 — 2.02, 9.01
- 2016-06-21 0001628280-16-017201 — 8.01
- 2016-05-04 0001628280-16-015501 — 2.02, 9.01
- 2016-02-16 0001628280-16-011261 — 5.02, 9.01
- 2016-02-04 0001628280-16-010758 — 5.02, 9.01
- 2016-02-04 0001628280-16-010755 — 2.02, 9.01
- 2015-11-17 0001193125-15-378953 — 7.01
- 2015-11-10 0001628280-15-008606 — 2.02, 9.01
- 2015-09-28 0001193125-15-329665 — 8.01, 9.01
- 2015-08-11 0001193125-15-286405 — 7.01, 9.01
- 2015-08-06 0001193125-15-281219 — 1.01, 5.02, 5.03, 5.05, 8.01, 9.01
- 2015-08-03 0001193125-15-274808 — 5.03, 9.01

## late-filing notifications on or before 2019-08-27

- 2015-11-10 0001628280-15-008612 — NT 10-Q, for the period ended 2015-09-26
- 2015-09-28 0001193125-15-329672 — NT 10-K, for the period ended 2015-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001633978-19-000068:8k_2_02:1]
EX-99.1
2
lite_ex991xq4fy19.htm
EXHIBIT 99.1

[0001633978-19-000068:8k_2_02:2]
Exhibit

[0001633978-19-000068:8k_2_02:3]
NEWS RELEASE

[0001633978-19-000068:8k_2_02:4]
LUMENTUM ANNOUNCES FISCAL FOURTH QUARTER AND FULL YEAR 2019 RESULTS

[0001633978-19-000068:8k_2_02:5]
Achieved record Net revenue of $1.57 billion for fiscal year 2019, up 25% relative to the prior year

[0001633978-19-000068:8k_2_02:6]
Fiscal Fourth Quarter Highlights:

[0001633978-19-000068:8k_2_02:7]
| • | Net revenue of $404.6 million |

[0001633978-19-000068:8k_2_02:8]
| • | GAAP operating loss of (3.4)%; Non-GAAP operating margin of 19.0% |

[0001633978-19-000068:8k_2_02:9]
| • | GAAP diluted net loss per share of $(0.34); Non-GAAP diluted net income per share of $0.92 |

[0001633978-19-000068:8k_2_02:10]
Milpitas, Calif., August 8, 2019 – Lumentum Holdings Inc. (“Lumentum” or the “Company”) today reported results for its fiscal fourth quarter and full year ended June 29, 2019.

[0001633978-19-000068:8k_2_02:11]
“An eventful fourth quarter capped off an exciting fiscal 2019 during which we made significant progress against our strategic goals and achieved record results with revenue increasing 25% to more than $1.5 billion and operating margin expanding to more than 20%,” said Alan Lowe, President and CEO. “With market leading positions in the growing telecom and 3D sensing markets, a datacom strategy that profitably benefits from growth in cloud and 5G wireless network deployments, a commercial lasers business that bucked market trends and grew to record levels, and a more profitable business model driven by the increased scale and synergies from the Oclaro acquisition, we are well positioned for fiscal 2020 and beyond.”

[0001633978-19-000068:8k_2_02:12]
Full Fiscal Year 2019 Highlights:

[0001633978-19-000068:8k_2_02:13]
Net revenue for fiscal year 2019 was $1,565.3 million, with GAAP net loss attributable to common stockholders of $(37.9) million, or $(0.54) per diluted share. Net revenue for fiscal year 2018 was $1,247.7 million, with GAAP net income attributable to common stockholders of $241.5 million, or $3.82 per diluted share. GAAP results for fiscal year 2019 include the impact of the Oclaro acquisition starting from December 10, 2018, as well as related restructuring, write-downs, amortization of intangibles and other charges.

[0001633978-19-000068:8k_2_02:14]
Non-GAAP net income for fiscal year 2019 was $304.8 million, or $4.25 per diluted share. Non-GAAP net income for fiscal year 2018 was $247.8 million, or $3.82 per diluted share.

[0001633978-19-000068:8k_2_02:15]
Fiscal Fourth Quarter Highlights:

[0001633978-19-000068:8k_2_02:16]
Net revenue for the fiscal fourth quarter of 2019 was $404.6 million, with GAAP net loss attributable to common stockholders of $(25.8) million, or $(0.34) per diluted share. Net revenue for the fiscal third quarter of 2019 was $432.9 million, with GAAP net loss attributable to common stockholders of $(74.3) million, or $(0.98) per diluted share. Net revenue for the fiscal fourth quarter of 2018 was $301.1 million, with GAAP net income attributable to common stockholders of $25.7 million, or $0.40 per diluted share. GAAP results for fiscal year 2019 include the impact of the Oclaro acquisition starting from December 10, 2018, as well as related restructuring, write-downs, amortization of intangibles and other charges.

[0001633978-19-000068:8k_2_02:17]
Non-GAAP net income for the fiscal fourth quarter of 2019 was $70.8 million, or $0.92 per diluted share. Non-GAAP net income for the fiscal third quarter of 2019 was $69.9 million, or $0.91 per diluted share.  Non-GAAP net income for the fiscal fourth quarter of 2018 was $61.6 million, or $0.95 per diluted share.

[0001633978-19-000068:8k_2_02:18]
The Company held $768.5 million in total cash and short-term investments at the end of the fiscal fourth quarter of 2019, up $71 million from third quarter of 2019.

[0001633978-19-000068:8k_2_02:19]
Financial Overview – Fiscal Fourth Quarter Ended June 29, 2019

[0001633978-19-000068:8k_2_02:20]
|  | GAAP Results ($ in millions) |
|  | Q4 |  | Q3 |  | Q4 |  | Change |
|  | FY 2019 |  | FY 2019 |  | FY 2018 |  | Q/Q |  | Y/Y |
| Net revenue | $ | 404.6 |  |  | $ | 432.9 |  |  | $ | 301.1 |  |  | (6.5)% |  | 34.4% |
| Gross margin | 21.5 | % |  | 20.4 | % |  | 31.7 | % |  | 110bps |  | (1,020)bps |
| Operating margin (loss) | (3.4 | )% |  | (17.6 | )% |  | 6.9 | % |  | 1,420bps |  | (1,030)bps |
|  | Non-GAAP Results ($ in millions) |
|  | Q4 |  | Q3 |  | Q4 |  | Change |
|  | FY 2019 |  | FY 2019 |  | FY 2018 |  | Q/Q |  | Y/Y |
| Net revenue | $ | 404.6 |  |  | $ | 432.9 |  |  | $ | 301.1 |  |  | (6.5)% |  | 34.4% |
| Gross margin | 38.9 | % |  | 39.0 | % |  | 37.2 | % |  | (10)bps |  | 170bps |
| Operating margin | 19.0 | % |  | 17.8 | % |  | 17.8 | % |  | 120bps |  | 120bps |

[0001633978-19-000068:8k_2_02:21]
|  | Net Revenue by Segment ($ in millions) |
|  | Q4 |  | % of |  | Q3 |  | Q4 |  | Change |
|  | FY 2019 |  | Net Revenue |  | FY 2019 |  | FY 2018 |  | Q/Q |  | Y/Y |
| Optical Communications | $ | 356.8 |  |  | 88.2 | % |  | $ | 377.9 |  |  | $ | 244.9 |  |  | (5.6)% |  | 45.7% |
| Lasers | 47.8 |  |  | 11.8 | % |  | 55.0 |  |  | 56.2 |  |  | (13.1)% |  | (14.9)% |
| Total | $ | 404.6 |  |  | 100.0 | % |  | $ | 432.9 |  |  | $ | 301.1 |  |  | (6.5)% |  | 34.4% |

[0001633978-19-000068:8k_2_02:22]
Financial Overview – Fiscal Year Ended June 29, 2019

[0001633978-19-000068:8k_2_02:23]
|  | GAAP Results ($ in millions) |
|  | FY 2019 |  | FY 2018 |  | Change Y/Y |  |
| Net revenue | $ | 1,565.3 |  |  | $ | 1,247.7 |  |  | 25.5% |  |
| Gross margin | 27.2 | % |  | 34.6 | % |  | (740)bps |  |
| Operating margin | (1.4 | )% |  | 11.2 | % |  | (1,260)bps |  |

[0001633978-19-000068:8k_2_02:24]
|  | Non-GAAP Results ($ in millions) |
|  | FY 2019 |  | FY 2018 |  | Change Y/Y |  |
| Net revenue | $ | 1,565.3 |  |  | $ | 1,247.7 |  |  | 25.5% |  |
| Gross margin | 39.5 | % |  | 38.9 | % |  | 60bps |  |
| Operating margin | 20.5 | % |  | 19.7 | % |  | 80bps |  |

[0001633978-19-000068:8k_2_02:25]
|  | Net Revenue by Segment ($ in millions) |
|  | FY 2019 |  | FY 2018 |  | Change Y/Y |  |
| Optical Communications | $ | 1,370.2 |  |  | $ | 1,059.2 |  |  | 29.4% |  |
| Lasers | 195.1 |  |  | 188.5 |  |  | 3.5% |  |
| Total | $ | 1,565.3 |  |  | $ | 1,247.7 |  |  | 25.5% |  |

[0001633978-19-000068:8k_2_02:26]
The tables above provide comparisons of quarterly and annual results relative to prior periods, including sequential quarterly and year-over-year changes. A reconciliation between GAAP and non-GAAP measures is contained in this release under the section titled “Use of Non-GAAP Financial Measures.” GAAP results for fiscal year 2019 include the impact of the Oclaro acquisition starting from December 10, 2018, as well as related restructuring, write-downs, amortization of intangibles and other charges.

[0001633978-19-000068:8k_2_02:27]
On July 1, 2018, we adopted Accounting Standards Update (ASU) 2014-09, Revenue from Contracts with Customers (Topic 606) using the modified retrospective method applied to all contracts that are not completed contracts at the date of initial adoption (i.e., July 1, 2018). Results for reporting periods after July 1, 2018 are presented under Topic 606, while prior period amounts are not adjusted and continue to be reported in accordance with our historic accounting under Topic 605. The adoption of Topic 606

[0001633978-19-000068:8k_2_02:28]
did not have a material impact on the nature and timing of our revenues, consolidated statements of operations, cash flows, and balance sheet and therefore, we do not present results for the three months and full year ended June 29, 2019 under Topic 605.

[0001633978-19-000068:8k_2_02:29]
Business Outlook

[0001633978-19-000068:8k_2_02:30]
Lumentum expects the following for the fiscal first quarter 2020:

[0001633978-19-000068:8k_2_02:31]
•Net revenue in the range of $435 million to $455 million

[0001633978-19-000068:8k_2_02:32]
•Non-GAAP operating margin of 22.5% to 24.5%

[0001633978-19-000068:8k_2_02:33]
•Non-GAAP diluted earnings per share of $1.12 to $1.26

[0001633978-19-000068:8k_2_02:34]
We have not provided reconciliations from GAAP to non-GAAP measures for our outlook. A large portion of non-GAAP adjustments, such as stock-based compensation, inventory write down due to plans to exit certain product lines, acquisition related costs, integration related costs, amortization of acquired intangibles, amortization of fair value adjustments, restructuring charges,  impairment charges, derivative liability adjustments, transferring product lines to Thailand, non-cash income tax expense and credits, and other costs and contingencies unrelated to current and future operations are by their nature highly volatile and we have low visibility as to the range that may be incurred in the future.

[0001633978-19-000068:8k_2_02:35]
Conference Call

[0001633978-19-000068:8k_2_02:36]
Lumentum will host a conference call on August 8, 2019, at 5:30 am PT/8:30 am ET. A live webcast of the call and the replay will be available on the Lumentum website at http://investor.lumentum.com through August 15, 2019. Supporting materials outlining the Company’s latest financial results will be posted on http://investor.lumentum.com under the “Events and Presentations” section concurrently with this earnings press release. This press release is being furnished as an exhibit to a Current Report on Form 8-K filed with the Securities and Exchange Commission and will be available at http://www.sec.gov/.

[0001633978-19-000068:8k_2_02:37]
About Lumentum

[0001633978-19-000068:8k_2_02:38]
Lumentum (NASDAQ: LITE) is a market-leading designer and manufacturer of innovative optical and photonic products enabling optical networking and laser applications worldwide. Lumentum optical components and subsystems are part of virtually every type of telecom, enterprise, and data center network. Lumentum lasers enable advanced manufacturing techniques and diverse applications including next-generation 3D sensing capabilities. Lumentum is headquartered in Milpitas, California with R&D, manufacturing, and sales offices worldwide. For more information, visit www.lumentum.com.

[0001633978-19-000068:8k_2_02:39]
Forward-Looking Statements

[0001633978-19-000068:8k_2_02:40]
Contact Information

[0001633978-19-000068:8k_2_02:41]
Investors:     Chris Coldren, 408-404-0606; investor.relations@lumentum.com

[0001633978-19-000068:8k_2_02:42]
Jim Fanucchi, 408-404-5400; investor.relations@lumentum.com

[0001633978-19-000068:8k_2_02:43]
Media:         Sean Ogarrio, 408-404-5400; media@lumentum.com

[0001633978-19-000068:8k_2_02:44]
The following financial tables are presented in accordance with GAAP, unless otherwise specified.

[0001633978-19-000068:8k_2_02:45]
LUMENTUM HOLDINGS INC.

[0001633978-19-000068:8k_2_02:46]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001633978-19-000068:8k_2_02:47]
(in millions, except per share data)

[0001633978-19-000068:8k_2_02:48]
(unaudited)

[0001633978-19-000068:8k_2_02:49]
|  | Three Months Ended |  | Twelve Months Ended |
|  | June 29, 2019 |  | June 30, 2018 |  | June 29, 2019 |  | June 30, 2018 |
| Net revenue | $ | 404.6 |  |  | $ | 301.1 |  |  | $ | 1,565.3 |  |  | $ | 1,247.7 |  |
| Cost of sales | 304.6 |  |  | 204.8 |  |  | 1,092.9 |  |  | 812.4 |  |
| Amortization of acquired intangibles | 13.2 |  |  | 0.8 |  |  | 46.5 |  |  | 3.2 |  |
| Gross profit | 86.8 |  |  | 95.5 |  |  | 425.9 |  |  | 432.1 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 49.5 |  |  | 38.5 |  |  | 184.6 |  |  | 156.8 |  |
| Selling, general and administrative | 49.4 |  |  | 32.7 |  |  | 200.3 |  |  | 128.2 |  |
| Restructuring and related charges | 1.7 |  |  | 3.4 |  |  | 31.9 |  |  | 7.2 |  |
| Impairment charges | — |  |  | — |  |  | 30.7 |  |  | — |  |
| Total operating expenses | 100.6 |  |  | 74.6 |  |  | 447.5 |  |  | 292.2 |  |
| Income/(loss) from operations | (13.8 | ) |  | 20.9 |  |  | (21.6 | ) |  | 139.9 |  |
| Unrealized gain (loss) on derivative liability | — |  |  | 7.8 |  |  | 8.8 |  |  | (0.8 | ) |
| Interest and other income (expense), net | (7.3 | ) |  | (1.0 | ) |  | (20.5 | ) |  | (9.7 | ) |
| Income/(loss) before income taxes | (21.1 | ) |  | 27.7 |  |  | (33.3 | ) |  | 129.4 |  |
| Provision for (benefit from) income taxes | 4.7 |  |  | (5.8 | ) |  | 3.1 |  |  | (118.7 | ) |
| Net income/(loss) | (25.8 | ) |  | 33.5 |  |  | (36.4 | ) |  | 248.1 |  |
| Items reconciling net income/(loss) to net income/(loss) attributable to common stockholders: |  |  |  |  |  |  |  |
| Less: Cumulative dividends on Series A Preferred Stock | — |  |  | (0.2 | ) |  | (0.3 | ) |  | (0.9 | ) |
| Less: Earnings allocated to Series A Preferred Stock | — |  |  | (0.8 | ) |  | (1.2 | ) |  | (5.7 | ) |
| Net income/(loss) attributable to common stockholders - Basic | $ | (25.8 | ) |  | $ | 32.5 |  |  | $ | (37.9 | ) |  | $ | 241.5 |  |
| Add: Earnings allocated to Series A Preferred Stock | — |  |  | 0.8 |  |  | — |  |  | — |  |
| Add/Less: Unrealized (gain) loss on derivative liability on Series A Preferred Stock | — |  |  | (7.8 | ) |  | — |  |  | — |  |
| Add: Cumulative dividends on Series A Preferred Stock | — |  |  | 0.2 |  |  | — |  |  | — |  |
| Net income/(loss) attributable to common stockholders - Diluted | $ | (25.8 | ) |  | $ | 25.7 |  |  | $ | (37.9 | ) |  | $ | 241.5 |  |
| Net income/(loss) per share attributable to common stockholders: |  |  |  |  |  |  |  |
| Basic | $ | (0.34 | ) |  | $ | 0.52 |  |  | $ | (0.54 | ) |  | $ | 3.88 |  |
| Diluted | $ | (0.34 | ) |  | $ | 0.40 |  |  | $ | (0.54 | ) |  | $ | 3.82 |  |
| Shares used to compute net income/(loss) per share attributable to common stockholders: |  |  |  |  |  |  |  |
| Basic | 76.5 |  |  | 62.7 |  |  | 70.7 |  |  | 62.3 |  |
| Diluted | 76.5 |  |  | 65.0 |  |  | 70.7 |  |  | 63.3 |  |

[0001633978-19-000068:8k_2_02:50]
(a)  For the three and twelve months ended June 29, 2019, our diluted earnings per share attributable to common stockholders is the same as basic EPS as we are in net loss position. For the three months ended June 30, 2018, our diluted earnings per share attributable to common stockholders is calculated using the “if-converted” method because it is more dilutive, whereas for the twelve months ended June 30, 2018, our diluted earnings per share attributable to common stockholders is calculated using the  “treasury stock” method.

[0001633978-19-000068:8k_2_02:51]
LUMENTUM HOLDINGS INC.

[0001633978-19-000068:8k_2_02:52]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001633978-19-000068:8k_2_02:53]
(in millions, except share and per share data)

[0001633978-19-000068:8k_2_02:54]
(unaudited)

[0001633978-19-000068:8k_2_02:55]
|  | June 29, 2019 |  | June 30, 2018 |
| ASSETS |  |  |  |  |  |
| Current assets: |  |  |  |  |  |
| Cash and cash equivalents | $ | 432.6 |  |  | $ | 397.3 |  |
| Short-term investments | 335.9 |  |  | 314.2 |  |
| Accounts receivable, net | 238.0 |  |  | 197.1 |  |
| Inventories | 228.8 |  |  | 174.1 |  |
| Prepayments and other current assets | 97.5 |  |  | 44.5 |  |
| Total current assets | 1,332.8 |  |  | 1,127.2 |  |
| Property, plant and equipment, net | 433.3 |  |  | 306.9 |  |
| Goodwill | 368.9 |  |  | 11.3 |  |
| Other intangible assets, net | 395.4 |  |  | 7.0 |  |
| Deferred income taxes | 169.6 |  |  | 125.6 |  |
| Other non-current assets | 16.6 |  |  | 3.5 |  |
| Total assets | $ | 2,716.6 |  |  | $ | 1,581.5 |  |
| LIABILITIES, REDEEMABLE CONVERTIBLE PREFERRED STOCK AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 160.8 |  |  | $ | 126.5 |  |
| Accrued payroll and related expenses | 42.3 |  |  | 31.5 |  |
| Accrued expenses | 46.7 |  |  | 33.9 |  |
| Term loan, current | 5.0 |  |  | — |  |
| Other current liabilities | 39.2 |  |  | 22.1 |  |
| Total current liabilities | 294.0 |  |  | 214.0 |  |
| Convertible notes | 351.9 |  |  | 334.2 |  |
| Term loan, non-current | 484.0 |  |  | — |  |
| Derivative liability | — |  |  | 52.4 |  |
| Deferred tax liability | 55.9 |  |  | 0.3 |  |
| Other non-current liabilities | 33.7 |  |  | 18.7 |  |
| Total liabilities | 1,219.5 |  |  | 619.6 |  |
| Redeemable convertible preferred stock: |  |  |  |
| Non-controlling interest redeemable convertible Series A Preferred Stock, $0.001 par value, 10,000,000 authorized shares; zero and 35,805 shares issued and outstanding as of June 29, 2019 and June 30, 2018, respectively | — |  |  | 35.8 |  |
| Total redeemable convertible preferred stock | — |  |  | 35.8 |  |
| Stockholders’ equity: |  |  |  |
| Common stock, $0.001 par value, 990,000,000 authorized shares, 76,653,478 and 62,790,087 shares issued and outstanding as of June 29, 2019 and June 30, 2018, respectively | 0.1 |  |  | 0.1 |  |
| Additional paid-in capital | 1,360.8 |  |  | 753.2 |  |
| Retained earnings | 129.1 |  |  | 166.4 |  |
| Accumulated other comprehensive income | 7.1 |  |  | 6.4 |  |
| Total stockholders’ equity | 1,497.1 |  |  | 926.1 |  |
| Total liabilities, redeemable convertible preferred stock, and stockholders’ equity | $ | 2,716.6 |  |  | $ | 1,581.5 |  |

[0001633978-19-000068:8k_2_02:56]
Use of Non-GAAP Financial Measures

[0001633978-19-000068:8k_2_02:57]
In this press release, Lumentum provides investors with gross margin, gross profit, operating margin (loss), operating income (loss), income (loss) before income taxes and certain expenses, net income (loss), and net income (loss) per share on a non-GAAP basis. Lumentum believes this non-GAAP financial information provides additional insight into the Company’s on-going cash generation and has therefore chosen to provide this information to investors for a more consistent basis of comparison and to help them evaluate the results of the Company’s on-going operations and enable more meaningful period to period comparisons. Specifically, the Company believes that providing this information allows investors to better understand the Company’s cash flows and, importantly, to evaluate the efficacy of the methodology and information used by management to evaluate and measure such cash flows. However, these measures may be different from non-GAAP measures used by other companies, limiting their usefulness for comparison purposes. The non-GAAP financial measures used in this press release should not be considered in isolation from measures of financial performance prepared in accordance with GAAP. Investors are cautioned that there are material limitations associated with the use of non-GAAP financial measures as an analytical tool. In particular, many of the adjustments to our GAAP financial measures reflect the exclusion of items that are recurring and will be reflected in our financial results for the foreseeable future. Further, these non-GAAP financial measures may not be comparable to similarly titled measurements reported by other companies.

[0001633978-19-000068:8k_2_02:58]
Non-GAAP gross margin, non-GAAP gross profit, non-GAAP expenses, non-GAAP operating margin, non-GAAP operating income, non-GAAP income before income taxes, non-GAAP net income, and non-GAAP net income per share exclude (i) stock-based compensation, (ii) inventory write-downs due to cancelled programs, plans to exit certain lines of business and other costs and contingencies unrelated to current and future operations, (iii) acquisition related costs, (iv) integration related costs, (v) amortization of acquired intangibles, (vi) amortization of fair value adjustments, (vii) restructuring and related charges, (viii) impairment charges, (ix) non-cash interest expense, (x) unrealized gain (loss) on derivative liability, (xi) transferring product lines to Thailand, and (xii) non-cash income tax provision impacts, for example, a release of a U.S. valuation allowance, and the write down of deferred tax assets due to the 2017 Tax Cuts and Jobs Act. The presentation of these and other similar items in Lumentum’s non-GAAP financial results should not be interpreted as implying that these items are non-recurring, infrequent or unusual.

[0001633978-19-000068:8k_2_02:59]
A quantitative reconciliation between GAAP and non-GAAP financial data with respect to historical periods is included in the supplemental financial table attached to this press release.

[0001633978-19-000068:8k_2_02:60]
LUMENTUM HOLDINGS INC.

[0001633978-19-000068:8k_2_02:61]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001633978-19-000068:8k_2_02:62]
(in millions, except per share data)

[0001633978-19-000068:8k_2_02:63]
(unaudited)

[0001633978-19-000068:8k_2_02:64]
|  | Three Months Ended |  | Twelve Months Ended |
|  | June 29, 2019 |  | March 30, 2019 |  | June 30, 2018 |  | June 29, 2019 |  | June 30, 2018 |
| Gross profit on GAAP basis | $ | 86.8 |  |  | $ | 88.3 |  |  | $ | 95.5 |  |  | $ | 425.9 |  |  | $ | 432.1 |  |
| Stock-based compensation (3) | 3.4 |  |  | 3.2 |  |  | 3.1 |  |  | 15.1 |  |  | 12.6 |  |
| Inventory write down due to product lines exit (7) | 1.4 |  |  | 19.4 |  |  | — |  |  | 20.8 |  |  | 7.0 |  |
| Integration related costs | 3.8 |  |  | 2.8 |  |  | — |  |  | 6.6 |  |  | — |  |
| Amortization of acquired intangibles | 13.3 |  |  | 28.1 |  |  | 0.8 |  |  | 46.6 |  |  | 3.2 |  |
| Amortization of fair value adjustments (4) | 38.8 |  |  | 14.5 |  |  | — |  |  | 54.6 |  |  | — |  |
| Other charges (1) | 9.9 |  |  | 12.5 |  |  | 12.7 |  |  | 48.9 |  |  | 30.2 |  |
| Gross profit on non-GAAP basis | $ | 157.4 |  |  | $ | 168.8 |  |  | $ | 112.1 |  |  | $ | 618.5 |  |  | $ | 485.1 |  |
| Gross margin on non-GAAP basis | 38.9 | % |  | 39.0 | % |  | 37.2 | % |  | 39.5 | % |  | 38.9 | % |
| Research and development on GAAP basis | $ | 49.5 |  |  | $ | 57.7 |  |  | $ | 38.5 |  |  | $ | 184.6 |  |  | $ | 156.8 |  |
| Stock-based compensation (3) | (3.1 | ) |  | (4.5 | ) |  | (3.7 | ) |  | (13.8 | ) |  | (14.2 | ) |
| Other charges | — |  |  | (0.4 | ) |  | (0.6 | ) |  | (0.7 | ) |  | (2.0 | ) |
| Research and development on non-GAAP basis | $ | 46.4 |  |  | $ | 52.8 |  |  | $ | 34.2 |  |  | $ | 170.1 |  |  | $ | 140.6 |  |
| Selling, general and administrative on GAAP basis | $ | 49.4 |  |  | $ | 55.2 |  |  | $ | 32.7 |  |  | $ | 200.3 |  |  | $ | 128.2 |  |
| Stock-based compensation (3) | (7.7 | ) |  | (8.3 | ) |  | (4.9 | ) |  | (41.8 | ) |  | (20.0 | ) |
| Acquisition related costs | (0.3 | ) |  | (2.2 | ) |  | (2.1 | ) |  | (15.6 | ) |  | (4.8 | ) |
| Integration related costs | (1.7 | ) |  | (1.3 | ) |  | — |  |  | (3.0 | ) |  | — |  |
| Amortization of acquired intangibles | (3.6 | ) |  | (3.6 | ) |  | — |  |  | (8.0 | ) |  | — |  |
| Other charges | (1.8 | ) |  | (0.8 | ) |  | (1.4 | ) |  | (4.1 | ) |  | (5.1 | ) |
| Selling, general and administrative on non-GAAP basis | $ | 34.3 |  |  | $ | 39.0 |  |  | $ | 24.3 |  |  | $ | 127.8 |  |  | $ | 98.3 |  |
| Income/(loss) from operations on GAAP basis | $ | (13.8 | ) |  | $ | (76.4 | ) |  | $ | 20.9 |  |  | $ | (21.6 | ) |  | $ | 139.9 |  |
| Stock-based compensation (3) | 14.2 |  |  | 16.0 |  |  | 11.7 |  |  | 70.7 |  |  | 46.8 |  |
| Inventory write down due to product lines exit (7) | 1.4 |  |  | 19.4 |  |  | — |  |  | 20.8 |  |  | 7.0 |  |
| Acquisition related costs | 0.3 |  |  | 2.2 |  |  | 2.1 |  |  | 15.6 |  |  | 4.8 |  |
| Integration related costs | 5.5 |  |  | 4.1 |  |  | — |  |  | 9.6 |  |  | — |  |
| Amortization of acquired intangibles | 16.9 |  |  | 31.7 |  |  | 0.8 |  |  | 54.6 |  |  | 3.2 |  |
| Amortization of fair value adjustments (4) | 38.8 |  |  | 14.5 |  |  | — |  |  | 54.6 |  |  | — |  |
| Restructuring and related charges (2) | 1.7 |  |  | 21.1 |  |  | 3.4 |  |  | 31.9 |  |  | 7.2 |  |
| Impairment charge (6) | — |  |  | 30.7 |  |  | — |  |  | 30.7 |  |  | — |  |
| Other charges (1) | 11.7 |  |  | 13.7 |  |  | 14.7 |  |  | 53.7 |  |  | 37.3 |  |
| Income from operations on non-GAAP basis | $ | 76.7 |  |  | $ | 77.0 |  |  | $ | 53.6 |  |  | $ | 320.6 |  |  | $ | 246.2 |  |
| Operating margin on non-GAAP basis | 19.0 | % |  | 17.8 | % |  | 17.8 | % |  | 20.5 | % |  | 19.7 | % |
| Interest and other (expense) income, net on GAAP basis | $ | (7.3 | ) |  | $ | (6.1 | ) |  | $ | (1.0 | ) |  | $ | (20.5 | ) |  | $ | (9.7 | ) |
| Other interest and (income) expense adjustments (5) | — |  |  | (2.5 | ) |  | — |  |  | (0.5 | ) |  | (0.1 | ) |
| Non-cash interest expense on convertible notes and term loan | 4.9 |  |  | 4.8 |  |  | 4.3 |  |  | 18.5 |  |  | 16.7 |  |

[0001633978-19-000068:8k_2_02:65]
| Interest and other (expense) income, net on non-GAAP basis | $ | (2.4 | ) |  | $ | (3.8 | ) |  | $ | 3.3 |  |  | $ | (2.5 | ) |  | $ | 6.9 |  |
| Income/(loss) before income taxes on GAAP basis | $ | (21.1 | ) |  | $ | (82.5 | ) |  | $ | 27.7 |  |  | $ | (33.3 | ) |  | $ | 129.4 |  |
| Stock-based compensation (3) | 14.2 |  |  | 16.0 |  |  | 11.7 |  |  | 70.7 |  |  | 46.8 |  |
| Inventory write down due to product lines exit (7) | 1.4 |  |  | 19.4 |  |  | — |  |  | 20.8 |  |  | 7.0 |  |
| Acquisition related costs | 0.3 |  |  | 2.2 |  |  | 2.1 |  |  | 15.6 |  |  | 4.8 |  |
| Integration related costs | 5.5 |  |  | 4.1 |  |  | — |  |  | 9.6 |  |  | — |  |
| Amortization of acquired intangibles | 16.9 |  |  | 31.7 |  |  | 0.8 |  |  | 54.6 |  |  | 3.2 |  |
| Amortization of fair value adjustments (4) | 38.8 |  |  | 14.5 |  |  | — |  |  | 54.6 |  |  | — |  |
| Restructuring and related charges (2) | 1.7 |  |  | 21.1 |  |  | 3.4 |  |  | 31.9 |  |  | 7.2 |  |
| Impairment charge (6) | — |  |  | 30.7 |  |  | — |  |  | 30.7 |  |  | — |  |
| Other interest and (income) expense adjustments (5) | — |  |  | (2.5 | ) |  | — |  |  | (0.5 | ) |  | (0.1 | ) |
| Non-cash interest expense on convertible notes and term loan | 4.9 |  |  | 4.8 |  |  | 4.3 |  |  | 18.5 |  |  | 16.7 |  |
| Unrealized (gain) loss on derivative liability | — |  |  | — |  |  | (7.8 | ) |  | (8.8 | ) |  | 0.8 |  |
| Other charges (1) | 11.7 |  |  | 13.7 |  |  | 14.7 |  |  | 53.7 |  |  | 37.3 |  |
| Income before income taxes on non-GAAP basis | $ | 74.3 |  |  | $ | 73.2 |  |  | $ | 56.9 |  |  | $ | 318.1 |  |  | $ | 253.1 |  |
| Provision for (benefit from) income taxes on GAAP basis | $ | 4.7 |  |  | $ | (8.2 | ) |  | $ | (5.8 | ) |  | $ | 3.1 |  |  | $ | (118.7 | ) |
| Income tax adjustments | (1.2 | ) |  | 11.5 |  |  | 1.1 |  |  | 10.2 |  |  | 124.0 |  |
| Provision for (benefit from) income taxes on non-GAAP basis | $ | 3.5 |  |  | $ | 3.3 |  |  | $ | (4.7 | ) |  | $ | 13.3 |  |  | $ | 5.3 |  |
| Net income/(loss) on GAAP basis | $ | (25.8 | ) |  | $ | (74.3 | ) |  | $ | 33.5 |  |  | $ | (36.4 | ) |  | $ | 248.1 |  |
| Stock-based compensation (3) | 14.2 |  |  | 16.0 |  |  | 11.7 |  |  | 70.7 |  |  | 46.8 |  |
| Inventory write down due to product lines exit (7) | 1.4 |  |  | 19.4 |  |  | — |  |  | 20.8 |  |  | 7.0 |  |
| Acquisition related costs | 0.3 |  |  | 2.2 |  |  | 2.1 |  |  | 15.6 |  |  | 4.8 |  |
| Integration related costs | 5.5 |  |  | 4.1 |  |  | — |  |  | 9.6 |  |  | — |  |
| Amortization of acquired intangibles | 16.9 |  |  | 31.7 |  |  | 0.8 |  |  | 54.6 |  |  | 3.2 |  |
| Amortization of fair value adjustments (4) | 38.8 |  |  | 14.5 |  |  | — |  |  | 54.6 |  |  | — |  |
| Restructuring and related charges (2) | 1.7 |  |  | 21.1 |  |  | 3.4 |  |  | 31.9 |  |  | 7.2 |  |
| Impairment charge (6) | — |  |  | 30.7 |  |  | — |  |  | 30.7 |  |  | — |  |
| Other interest and (income) expense adjustments (5) | — |  |  | (2.5 | ) |  | — |  |  | (0.5 | ) |  | (0.1 | ) |
| Non-cash interest expense on convertible notes and term loan | 4.9 |  |  | 4.8 |  |  | 4.3 |  |  | 18.5 |  |  | 16.7 |  |
| Unrealized (gain) loss on derivative liability | — |  |  | — |  |  | (7.8 | ) |  | (8.8 | ) |  | 0.8 |  |
| Other charges (1) | 11.7 |  |  | 13.7 |  |  | 14.7 |  |  | 53.7 |  |  | 37.3 |  |
| Income tax adjustments | 1.2 |  |  | (11.5 | ) |  | (1.1 | ) |  | (10.2 | ) |  | (124.0 | ) |
| Net income on non-GAAP basis | $ | 70.8 |  |  | $ | 69.9 |  |  | $ | 61.6 |  |  | $ | 304.8 |  |  | $ | 247.8 |  |
| Net income per share on non-GAAP basis | $ | 0.92 |  |  | $ | 0.91 |  |  | $ | 0.95 |  |  | $ | 4.25 |  |  | $ | 3.82 |  |
| Shares used in per share calculation - diluted on GAAP basis | 76.5 |  |  | 76.2 |  |  | 65.0 |  |  | 70.7 |  |  | 63.3 |  |
| Non-GAAP adjustment (8) | 0.6 |  |  | 0.5 |  |  | — |  |  | 0.6 |  |  | — |  |
| Effect of diluted securities from Series A Preferred Stock (9) | — |  |  | — |  |  | — |  |  | 0.5 |  |  | 1.5 |  |
| Shares used in per share calculation - diluted on non-GAAP basis | 77.1 |  |  | 76.7 |  |  | 65.0 |  |  | 71.8 |  |  | 64.8 |  |

[0001633978-19-000068:8k_2_02:66]
(1) Other charges for the three and twelve months ended June 29, 2019, primarily include costs of transferring product lines to Thailand of $7.9 million and $48.7 million, respectively. Other charges for the three and twelve months ended June 30, 2018 primarily relate to set-up costs of our Thailand facility, including costs of transferring product lines to Thailand of $12.7 million and $30.5 million, respectively.

[0001633978-19-000068:8k_2_02:67]
(2) During the twelve months ended June 29, 2019, we recorded restructuring and related charges of $31.9 million, primarily in connection with the decision to exit Lithium Niobate and Datacom module product lines as well as employee related benefits associated with Oclaro’s executive severance and retention agreements.

[0001633978-19-000068:8k_2_02:68]
(3) During the fiscal second quarter of 2019, we recorded one-time stock-based compensation of $15.2 million attributable to severance and employee related benefits associated with Oclaro’s executive severance and retention agreements.

[0001633978-19-000068:8k_2_02:69]
(4) In connection with the acquisition of Oclaro, we recorded a fair value adjustment of $60.3 million to inventory, resulting in $38.8 million and $54.6 million of amortization expense of the fair value adjustment during the three and twelve months ended June 29, 2019, respectively.

[0001633978-19-000068:8k_2_02:70]
(5) During the twelve months ended June 29, 2019, interest and other (expense) income includes a one-time benefit of $2.5 million related to a non-trade reimbursement, offset by a one-time charge of $2.7 million, related to a ticking fee to Deutsche bank.

[0001633978-19-000068:8k_2_02:71]
(6) During the twelve months ended June 29, 2019, we recorded an impairment charge of $30.7 million in Property Plant and Equipment, related to the decision to exit the Datacom module product line.

[0001633978-19-000068:8k_2_02:72]
(7) During the three and twelve months ended June 29, 2019, we recorded an inventory write down charge of $1.4 million and $20.8 million, respectively, related to the decision to exit the Datacom module and Lithium Niobate product lines.

[0001633978-19-000068:8k_2_02:73]
(8) This adjustment represents weighted-average potentially dilutive securities from our stock-based benefit plans excluded from the computation of diluted net loss per share attributable to common stockholders on a GAAP basis because the effect would have been anti-dilutive. This adjustment amount is added for the computation of diluted net income per share on a non-GAAP basis as we had a net income on a non-GAAP basis.

[0001633978-19-000068:8k_2_02:74]
(9) During the twelve months ended June 30, 2018, 1.5 million shares related to the potential conversion of the Series A Preferred Stock were added to the calculation of diluted shares available on a non-GAAP basis because their inclusion results in more dilutive earnings per share.

[0001633978-19-000068:8k_2_02:75]
LUMENTUM HOLDINGS INC.

[0001633978-19-000068:8k_2_02:76]
RECONCILIATION OF GAAP NET INCOME (LOSS) TO EBITDA

[0001633978-19-000068:8k_2_02:77]
(in millions, except per share data)

[0001633978-19-000068:8k_2_02:78]
(unaudited)

[0001633978-19-000068:8k_2_02:79]
|  | Three Months Ended |  | Twelve Months Ended |
|  | June 29, 2019 |  | March 30, 2019 |  | June 30, 2018 |  | June 29, 2019 |  | June 30, 2018 |
| GAAP Net income/(loss) | $ | (25.8 | ) |  | $ | (74.3 | ) |  | $ | 33.5 |  |  | $ | (36.4 | ) |  | $ | 248.1 |  |
| Interest and other expense (income), net | 7.3 |  |  | 6.1 |  |  | 1.0 |  |  | 20.5 |  |  | 9.7 |  |
| Provision for (benefit from) income taxes | 4.7 |  |  | (8.2 | ) |  | (5.8 | ) |  | 3.1 |  |  | (118.7 | ) |
| Depreciation | 28.2 |  |  | 29.0 |  |  | 20.7 |  |  | 102.9 |  |  | 74.0 |  |
| Amortization of acquired intangibles | 16.9 |  |  | 31.7 |  |  | 0.8 |  |  | 54.6 |  |  | 3.2 |  |
| EBITDA | 31.3 |  |  | (15.7 | ) |  | 50.2 |  |  | 144.7 |  |  | 216.3 |  |
| Amortization of fair value adjustments | 38.8 |  |  | 14.5 |  |  | — |  |  | 54.6 |  |  | — |  |
| Restructuring and related charges | 1.7 |  |  | 21.1 |  |  | 3.4 |  |  | 31.9 |  |  | 7.2 |  |
| Stock-based compensation | 14.2 |  |  | 16.0 |  |  | 11.7 |  |  | 70.7 |  |  | 46.8 |  |
| Acquisition related costs | 0.3 |  |  | 2.2 |  |  | 2.1 |  |  | 15.6 |  |  | 4.8 |  |
| Other charges | 11.7 |  |  | 13.7 |  |  | 14.7 |  |  | 53.7 |  |  | 36.6 |  |
| Unrealized gain/(loss) on derivative liabilities | — |  |  | — |  |  | (7.8 | ) |  | (8.8 | ) |  | 0.8 |  |
| Inventory write down due to product lines exit | 1.4 |  |  | 19.4 |  |  | — |  |  | 20.8 |  |  | 7.7 |  |
| Integration related costs | 5.5 |  |  | 4.1 |  |  | — |  |  | 9.6 |  |  | — |  |
| Impairment charges | — |  |  | 30.7 |  |  | — |  |  | 30.7 |  |  | — |  |
| Adjusted EBITDA | $ | 104.9 |  |  | $ | 106.0 |  |  | $ | 74.3 |  |  | $ | 423.5 |  |  | $ | 320.2 |  |
