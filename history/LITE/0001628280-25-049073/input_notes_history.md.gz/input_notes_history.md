# LITE note change history — 0001628280-25-022788 → 0001628280-25-049073


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-11-05):
[0001628280-25-049073:note_history:1]
Our purchase obligations of $875.3 million as of September 27, 2025 represent legally binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule and adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.
  (was, 2025-05-07, similarity 0.9878):
[0001628280-25-022788:note_history:1]
Our purchase obligations of $635.3 million as of March 29, 2025 represent legally binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule and adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

- changed (2025-11-05):
[0001628280-25-049073:note_history:2]
We depend on a limited number of contract manufacturers, subcontractors and suppliers for raw materials, packages and standard components. We generally purchase these single or limited source products through standard purchase orders or one-year supply agreements and have no significant long-term guaranteed supply agreements with these vendors. While we seek to maintain a sufficient safety stock of such products and maintain on-going communications with our suppliers to guard against interruptions or cessation of supply, our business and results of operations could be adversely affected by a stoppage or delay of supply, substitution of more expensive or less reliable products, receipt of defective parts or contaminated materials, increases in the price of such supplies, or our inability to obtain reduced pricing from our suppliers in response to competitive pressures. In addition, the imposition of tariffs on certain imported goods and materials may increase our costs and place upward pressure on the cost of sales.
  (was, 2025-05-07, similarity 0.9927):
[0001628280-25-022788:note_history:2]
We depend on a limited number of contract manufacturers, subcontractors and suppliers for raw materials, packages and standard components. We generally purchase these single or limited source products through standard purchase orders or one-year supply agreements and have no significant long-term guaranteed supply agreements with these vendors. While we seek to maintain a sufficient safety stock of such products and maintain on-going communications with our suppliers to guard against interruptions or cessation of supply, our business and results of operations could be adversely affected by a stoppage or delay of supply, substitution of more expensive or less reliable products, receipt of defective parts or contaminated materials, increases in the price of such supplies, or our inability to obtain reduced pricing from our suppliers in response to competitive pressures. In addition, the imposition of tariffs on certain imported goods and materials may increase our costs and place upward pressure on the cost of goods sold.

- added (2025-11-05):
[0001628280-25-049073:note_history:3]
|  | Three Months Ended |  |  |
|  | September 27, 2025 |  | September 28, 2024 |  |  |  |  |
| Balance as of beginning of period | $ | 14.4 |  |  | $ | 13.2 |  |  |  |  |  |
| Measurement period adjustment | — |  |  | 0.8 |  |  |  |  |  |
| Provision for warranty | 2.8 |  |  | 2.4 |  |  |  |  |  |
| Utilization of reserve, net | (4.1) |  |  | (3.2) |  |  |  |  |  |
| Balance as of end of period | $ | 13.1 |  |  | $ | 13.2 |  |  |  |  |  |

- changed (2025-11-05):
[0001628280-25-049073:note_history:4]
We are subject to a variety of claims and suits that arise from time-to-time in the ordinary course of our business. While management currently believes that resolving claims against us, individually or in the aggregate, will not have a material adverse impact on our financial position, results of operations or statements of cash flows, these matters are subject to inherent uncertainties and management’s view of these matters may change in the future. We accrue for loss contingencies when it is both probable that we will incur the loss and when we can reasonably estimate the amount of the loss or range of loss. As of September 27, 2025, the accrual for expected settlement of litigation matters was not material.
  (was, 2025-05-07, similarity 0.9902):
[0001628280-25-022788:note_history:4]
We are subject to a variety of claims and suits that arise from time-to-time in the ordinary course of our business. While management currently believes that resolving claims against us, individually or in the aggregate, will not have a material adverse impact on our financial position, results of operations or statements of cash flows, these matters are subject to inherent uncertainties and management’s view of these matters may change in the future. We accrue for loss contingencies when it is both probable that we will incur the loss and when we can reasonably estimate the amount of the loss or range of loss. As of March 29, 2025, the accrual for expected settlement of litigation matters was not material.

- added (2025-11-05):
[0001628280-25-049073:note_history:5]
In the normal course of business, we enter into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown, because claims may be made against us in the future, and we may record charges in the future as a result of these indemnification obligations.

- added (2025-11-05):
[0001628280-25-049073:note_history:6]
On March 5, 2025, we completed a sale of net assets located in an entity in Shenzhen, China.  The Company has reclassified a $21.4 million unrecognized tax position to other non-current liabilities in the condensed consolidated balance sheets as of June 28, 2025 for an indemnification liability related to the sale of certain assets. This does not impact our results of operations for the year ended June 28, 2025. We did not have any other material indemnification claims that were probable or reasonably possible.

- added (2025-11-05):
[0001628280-25-049073:note_history:7]
On November 7, 2023, we completed the acquisition of Cloud Light. In accordance with the Merger Agreement, cash consideration included $75.8 million of cash held in an escrow fund to support Cloud Light’s indemnification obligations and customary adjustment for working capital.  Since the measurement period expired, any future adjustments will be included in our earnings. No amount of escrow funds have been released as the parties have not mutually agreed on the indemnification obligation and working capital adjustment.

- removed (2025-11-05):
[0001628280-25-022788:note_history:8]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 29, 2025 |  | March 30, 2024 |  | March 29, 2025 |  | March 30, 2024 |
| Balance as of beginning of period | $ | 12.8 |  |  | $ | 10.1 |  |  | $ | 13.2 |  |  | $ | 6.8 |  |
| Warranties assumed in Cloud Light acquisition | — |  |  | 3.0 |  |  | 0.8 |  |  | 8.2 |  |
| Provision for warranty | 1.8 |  |  | 2.6 |  |  | 6.2 |  |  | 3.6 |  |
| Utilization of reserve, net | (1.6) |  |  | (2.2) |  |  | (7.2) |  |  | (5.1) |  |
| Balance as of end of period | $ | 13.0 |  |  | $ | 13.5 |  |  | $ | 13.0 |  |  | $ | 13.5 |  |

- removed (2025-11-05):
[0001628280-25-022788:note_history:9]
Oclaro Merger Litigation

- removed (2025-11-05):
[0001628280-25-022788:note_history:10]
In connection with our acquisition of Oclaro in 2018, seven lawsuits were filed by purported stockholders of Oclaro challenging the proposed merger (the “Merger”). All but one was voluntarily dismissed after the Oclaro Merger closed. The remaining lawsuit, SaiSravan B. Karri v. Oclaro, Inc., et al., No. 3:18-cv-03435-JD (the “Karri Lawsuit”), was filed in the United States District Court for the Northern District of California and was styled as a class action.

- removed (2025-11-05):
[0001628280-25-022788:note_history:11]
The Karri Lawsuit alleged, among other things, that Oclaro and its directors violated Section 14(a) of the Securities Exchange Act of 1934, as amended (the “Exchange Act”), and Rule 14a-9 promulgated thereunder by disseminating an incomplete and misleading Form S-4, including proxy statement/prospectus. The Karri Lawsuit further alleged that Oclaro’s directors violated Section 20(a) of the Exchange Act by failing to exercise proper control over the person(s) who violated Section 14(a) of the Exchange Act. The plaintiff in the Karri Lawsuit sought, among other things, damages to be awarded to the plaintiff and any class, if a class is certified, and litigation costs, including attorneys’ fees.

- removed (2025-11-05):
[0001628280-25-022788:note_history:12]
The case proceeded through fact and expert discovery and the parties subsequently reached an agreement for a class-wide settlement of the Karri Lawsuit that provided for a payment of $15.3 million to the members of the class. On August 17, 2023, the court preliminarily approved the settlement. In March 2024, the court finally approved the settlement.

- removed (2025-11-05):
[0001628280-25-022788:note_history:13]
We recorded the court approved settlement amount of $15.3 million as accrued expenses in our condensed consolidated balance sheet as of June 29, 2024, of which $7.5 million represents the amount to be reimbursed by insurance and was recorded as prepayments and other current assets. As of September 28, 2024, this litigation matter was settled and all amounts were paid.

- removed (2025-11-05):
[0001628280-25-022788:note_history:14]
In the normal course of business, we enter into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown, because claims may be made against us in the future, and we may record charges in the future as a result of these indemnification obligations. On March 5, 2025, we completed a sale of assets located in an entity in Shenzhen, China.  The Company has reclassified a $21.4 million unrecognized tax position to other non-current liabilities in the condensed consolidated balance sheets as of March 29, 2025 for an indemnification liability related to the sale of certain assets. This does not impact our results of operations for the three months ended March 29, 2025. We did not have any other material indemnification claims that were probable or reasonably possible.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2025-11-05):
[0001628280-25-049073:note_history:15]
Lumentum Holdings Inc. (“we,” “us,” “our”, “Lumentum” or the “Company”) is a leading provider of optical and photonic products and is recognized as an industry leader based on revenue and market share. Our products are essential to a range of cloud, artificial intelligence and machine learning (“AI/ML”), telecommunications, consumer, and industrial end-market applications. The Company operates in one reportable segment.

- added (2025-11-05):
[0001628280-25-049073:note_history:16]
We disaggregate revenue by type of product, which are Components and Systems, and by geography. A Components product is defined as one of the individual building blocks that goes into creating a larger solution. It is typically not a complete product on its own but rather a specialized element that enables system functionality. This includes semiconductor laser chips, laser sub-assemblies, line subsystems and wavelength management systems. These are supplied to customers who then integrate them into their own full system solutions. Components represent foundational parts that support or enable that system’s operation and include a comprehensive portfolio of optical and photonic chips, components, laser light sources that are integrated into smartphones, subsystems supplied to cloud data center operators, AI/ML infrastructure providers, and network equipment manufacturer customers who are building cloud data center and network infrastructures.

- added (2025-11-05):
[0001628280-25-049073:note_history:17]
A Systems product is defined as a complete, stand-alone product that delivers full functionality to the end customer. It is typically self-contained and ready to operate within a customer’s network or application environment. This includes optical modules, optical circuit switches, and industrial lasers such as short-pulse solid-state lasers and kilowatt-class fiber lasers. These products integrate multiple technologies and subsystems into a finished solution that directly addresses a customer’s needs. A system represents the end-product that can be deployed and used independently.

- added (2025-11-05):
[0001628280-25-049073:note_history:18]
Our products enable high-capacity optical links for cloud computing, AI/ML workloads, and data center interconnect (“DCI”) applications, as well as for communications service provider networks. Our offerings support access (local), metro (intracity), long-haul (intercity and global), and submarine (undersea) network infrastructure. Our products serve enterprise network infrastructure needs, including storage area networks (“SANs”), local area networks (“LANs”), and wide area networks (“WANs”). Demand for our products is fueled by the ongoing expansion of network capacity required to support cloud services, AI/ML processing, streaming video, video conferencing, wireless and mobile connectivity, and the internet of things (“IoT”). In addition, our industrial laser products are used for precision material processing across diverse industries, including semiconductor and microelectronics fabrication, electric vehicle and battery production, metal cutting and welding, and advanced manufacturing that emphasize greater manufacturing precision, flexibility, and sustainability.

- changed (2025-11-05):
[0001628280-25-049073:note_history:19]
We have prepared the condensed consolidated financial statements in accordance with U.S. generally accepted accounting principles (“GAAP”), which requires management to make estimates and assumptions that affect the amounts reported in our condensed consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates. Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. These policies are inventory valuation, revenue recognition, income taxes, goodwill and business combinations.
  (was, 2025-05-07, similarity 0.8017):
[0001628280-25-022788:note_history:19]
We have prepared the accompanying condensed consolidated financial statements in accordance with U.S. generally accepted accounting principles (“GAAP”), which requires management to make estimates and assumptions that affect the amounts reported in our condensed consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact us in the future, actual results may be different from the estimates. Our interim period operating results do not necessarily indicate the results that may be expected for any other interim period or for the full fiscal year. In the opinion of the Company’s management, the information presented herein reflects all normal and recurring adjustments necessary for a fair presentation of our results of operations, financial position, stockholders’ equity, and cash flows. Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective, or complex judgments by management. Those policies are inventory valuation, revenue recognition, income taxes, goodwill, and business combinations.

- added (2025-11-05):
[0001628280-25-049073:note_history:20]
Prior to fiscal year 2026, we operated in two reportable segments consisting of Cloud & Networking and Industrial Tech. During the first quarter of fiscal year 2026, the Company implemented a re-organization, under which it will be managed as a single, integrated enterprise, with a unified management team overseeing operations across the entire company, rather than through discrete operating segments. The chief operating decision maker (“CODM”) is the Company’s Chief Executive Officer, who reviews financial information presented as a single enterprise for purposes of allocating resources and evaluating financial performance. Accordingly, we determined we operate in a single reporting segment. Comparative prior period segment information has been updated to reflect the new segment structure and measures. The changes in our operating segments had no impact on our previously reported consolidated results of operations, financial position or cash flows. Refer to “Note 14. Operating Segments and Geographic Information” for more details.

- changed (2025-11-05):
[0001628280-25-049073:note_history:21]
Our business and operating results depend significantly on general market and economic conditions. The current global macroeconomic environment is volatile and continues to be adversely impacted by many factors including inflation, a dynamic supply chain and demand environment, changes in trade policies, including heightened, scheduled, or threatened tariffs, trade restrictions including for certain rare earth minerals, and signs of a fluctuating macroeconomic environment.
  (was, 2025-05-07, similarity 0.6294):
[0001628280-25-022788:note_history:21]
Our business and operating results depend significantly on general market and economic conditions. The current global macroeconomic environment is volatile and continues to be adversely impacted by many factors including inflation, a dynamic supply chain and demand environment, trade wars, including heightened, scheduled, or threatened tariffs, trade restrictions including for certain rare earth minerals, and signs of a weaker macroeconomic environment impacting capital expenditures across our served markets. Additionally, instability in the global credit markets, capital expenditure reductions, unemployment and other labor issues, decline in stock markets, the instability in the geopolitical environment in many parts of the world, and the current global economic challenges continue to put pressure on our business and operating results.

- changed (2025-11-05):
[0001628280-25-049073:note_history:22]
The Company is actively monitoring and assessing the ongoing global trade environment, particularly with respect to recent changes in trade restrictions and tariff regulations. We have assessed the potential impacts of heightened restrictions and tariffs on our allowance for credit losses, the carrying value of our goodwill and other long-lived assets, inventory valuation, and revenue recognition.  While we have determined there was not a material impact to our condensed consolidated financial statements as of September 27, 2025 and for the quarter ended September 27, 2025, import tariffs implemented by the U.S. and other countries, as currently in effect and/or proposed, could have a material impact on our results for the remainder of fiscal year 2026 and in the future. The impact of tariffs is dependent upon negotiations with customers and suppliers and other mitigation efforts and potential further changes in global trade policies, including higher tariffs in the U.S. or other countries.
  (was, 2025-05-07, similarity 0.9675):
[0001628280-25-022788:note_history:22]
The Company is actively monitoring and assessing the ongoing global trade environment, particularly with respect to recent changes in tariff regulations. We have assessed the potential impacts of heightened restrictions and tariffs on our allowance for credit losses, the carrying value of our goodwill and other long-lived assets, inventory valuation, and revenue recognition.  While we have determined there was not a material impact to our condensed consolidated financial statements as of March 29, 2025 and for the quarter ended March 29, 2025, import tariffs implemented by the U.S. and other countries, as currently in effect and/or proposed, could have a material impact on our results for the remainder of 2025 and in the future. The impact of tariffs is dependent upon negotiations with customers and suppliers and other mitigation efforts and potential further changes in global trade policies, including higher tariffs in the U.S. or other countries.

- changed (2025-11-05):
[0001628280-25-049073:note_history:23]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Every fifth or sixth fiscal year will have a 53-week period. The additional week in a 53-week year is added to the third quarter, making such quarter consist of 14 weeks. Our fiscal 2026 is a 52-week year ending on June 27, 2026, with the quarter ended September 27, 2025 being a 13-week quarterly period. Our fiscal 2025 was a 52-week year that ended on June 28, 2025, with the quarter ended September 28, 2024 being a 13-week quarterly period.
  (was, 2025-05-07, similarity 0.7273):
[0001628280-25-022788:note_history:23]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Every fifth or sixth fiscal year will have a 53-week period. The additional week in a 53-week year is added to the third quarter, making such quarter consist of 14 weeks. Our fiscal 2025 is a 52-week year ending on June 28, 2025, with the quarter ended March 29, 2025 being a 13-week quarterly period. Our fiscal 2024 was a 52-week year that ended on June 29, 2024, with the quarter ended March 30, 2024 being a 13-week quarterly period.

- added (2025-11-05):
[0001628280-25-049073:note_history:24]
The condensed consolidated financial statements are prepared in accordance with GAAP and includes the accounts of Lumentum Holdings Inc. and its wholly owned subsidiaries. All inter-company transactions and balances are eliminated in consolidation.

- changed (2025-11-05):
[0001628280-25-049073:note_history:25]
The condensed consolidated financial statements and accompanying notes should be read in conjunction with the audited consolidated financial statements and accompanying notes included in our Annual Report on Form 10-K for the fiscal year ended June 28, 2025. There were no significant changes to our accounting policies during the three months ended September 27, 2025, except as noted below:
  (was, 2025-05-07, similarity 0.8877):
[0001628280-25-022788:note_history:25]
The condensed consolidated financial statements and accompanying notes should be read in conjunction with the audited consolidated financial statements and accompanying notes included in our Annual Report on Form 10-K for the fiscal year ended June 29, 2024. There were no significant changes to our accounting policies during the nine months ended March 29, 2025.

- added (2025-11-05):
[0001628280-25-049073:note_history:26]
Income Taxes

- added (2025-11-05):
[0001628280-25-049073:note_history:27]
In accordance with the authoritative guidance on accounting for income taxes, we recognize income taxes using an asset and liability approach. This approach requires the recognition of taxes payable or refundable for the current year and deferred tax liabilities and assets for the future tax consequences of events that have been recognized in our consolidated financial statements or tax returns. The measurement of current and deferred taxes is based on provisions of the enacted tax law, and the effects of future changes in tax laws or rates are not anticipated.

- added (2025-11-05):
[0001628280-25-049073:note_history:28]
The authoritative guidance provides for recognition of deferred tax assets if the realization of such deferred tax assets is more likely than not to occur based on an evaluation of both positive and negative evidence and the relative weight of the evidence. We consider future growth, forecasted earnings, future taxable income, the mix of earnings in the jurisdictions in which we operate, historical earnings, taxable income in prior years, if carry-back is permitted under the law, and prudent and feasible tax planning strategies in determining the need for a valuation allowance.

- added (2025-11-05):
[0001628280-25-049073:note_history:29]
In the event we determine that we would not be able to realize all or part of our net deferred tax assets in the future, an adjustment to the deferred tax assets valuation allowance would be charged to earnings in the period in which we make such a determination, or goodwill would be adjusted at our final determination of the valuation allowance related to an acquisition within the measurement period. Conversely, if we later determine that it is more likely than not that all or a portion of the net deferred tax assets will be realized, we would reverse the applicable portion of the previously established valuation allowance. A release of valuation allowance decreases income tax expense in the period of release, increases net income, and reduces our effective tax rate. Such releases may be material to our financial statements depending on the size of the deferred tax assets involved.

- added (2025-11-05):
[0001628280-25-049073:note_history:30]
In the fourth quarter of fiscal 2025, we released $153.1 million of valuation allowances on our UK deferred tax assets after we considered all available positive and negative evidence related to our UK subsidiary.  We analyzed the UK subsidiary’s historical operating results, projected future taxable income, tax planning strategies, and reversals of deferred tax liabilities, and determined that the weight of available objectively verifiable positive evidence supported the realizability of the UK deferred tax assets. In weighing the available evidence, more weight was placed upon our forecasts of future taxable income than on the history of pre-tax losses as such losses were generated under our prior UK business operating model which will no longer be in effect beginning with fiscal year 2026, and the guarantee of a positive operating margin as we effectuated an internal restructuring at the end of fiscal year 2025. Further, the most significant deferred tax asset in the UK is the net operating loss carryforward. Under UK tax law, net operating losses may be carried forward indefinitely, and we have considered the indefinite carryforward period to be positive evidence.

- added (2025-11-05):
[0001628280-25-049073:note_history:31]
We are subject to income tax audits by the respective tax authorities of the jurisdictions in which we operate. The determination of our income tax liabilities in each of these jurisdictions requires the interpretation and application of complex, and sometimes uncertain, tax laws and regulations. The authoritative guidance on accounting for income taxes prescribes both recognition and measurement criteria that must be met for the benefit of a tax position to be recognized in the financial statements. If a tax position taken, or expected to be taken, in a tax return does not meet such recognition or measurement criteria, an unrecognized tax benefit liability is recorded. If we ultimately determine that an unrecognized tax benefit liability is no longer necessary, we reverse the liability and recognize a tax benefit in the period in which it is determined that the unrecognized tax benefit liability is no longer necessary.

- added (2025-11-05):
[0001628280-25-049073:note_history:32]
Our income tax provision is highly dependent on the geographic distribution of our worldwide earnings or losses, tax laws and regulations in various jurisdictions, tax incentives, the availability of tax credits and loss carryforwards, and the effectiveness of our tax planning strategies. The application of tax laws and regulations is subject to legal and factual interpretation, judgment and uncertainty. Tax laws themselves are subject to change as a result of changes in fiscal policy, changes in legislation, and the evolution of regulations and court rulings and tax audits.

- added (2025-11-05):
[0001628280-25-049073:note_history:33]
The recognition and measurement of current taxes payable or refundable and deferred tax assets and liabilities requires that we make certain estimates and judgments. Changes to these estimates, including changes in judgment regarding the realizability of deferred tax assets and the need for or release of valuation allowances, may have a material impact on our tax provision, net income, and effective tax rate in a future period.

- removed (2025-11-05):
[0001628280-25-022788:note_history:34]
Lumentum Holdings Inc. (“we,” “us,” “our,” “Lumentum” or the “Company”) is an industry-leading provider of optical and photonic products essential to a range of cloud, artificial intelligence and machine learning (“AI/ML”), telecommunications, consumer, and industrial end-market applications. We operate in two end-market focused reportable segments, Cloud & Networking and Industrial Tech.

- removed (2025-11-05):
[0001628280-25-022788:note_history:35]
Our Cloud & Networking products include a comprehensive portfolio of optical and photonic chips, modules, and subsystems supplied to cloud data center operator, AI/ML infrastructure provider, and network equipment manufacturer customers who are building cloud data center and network infrastructures. Our products enable high-capacity optical data links in cloud, AI/ML, and data center interconnect (“DCI”) applications, and communications service provider networks, including in access (local), metro (intracity), long-haul (city-to-city and worldwide), and submarine (undersea) network infrastructure. Our Cloud & Networking products also support network equipment manufacturers building enterprise network infrastructure, including storage-area networks (“SANs”), local-area networks (“LANs”) and wide-area networks (“WANs”). Demand for our Cloud & Networking products is driven by the continual growth in network capacity required for cloud computing and services, including for AI/ML, streaming video and video conferencing, wireless and mobile devices, and internet of things (“IoT”).

- removed (2025-11-05):
[0001628280-25-022788:note_history:36]
Our Industrial Tech products include short pulse solid-state lasers, kilowatt-class fiber lasers, diode lasers, and gas lasers, which address applications in numerous end-markets. In the consumer end-market, our laser light sources are integrated into our customers’ 3D sensing cameras, which are used in mobile devices, payment kiosks, and other consumer electronics devices to enable applications including biometric identification, computational photography and virtual and augmented reality. In the automotive end-market, our lasers are used in our customers’ LiDAR and other optical sensor devices, which are increasingly being used in advanced driver assistance systems (“ADAS”) and in-cabin driver and occupant monitoring systems. In the industrial manufacturing end-market, our lasers are incorporated into our customers’ manufacturing machine tools used for the precision processing of materials in a range of industries including semiconductor device and microelectronics fabrication, electric vehicle and battery production, metal cutting and welding, and advanced manufacturing. Our products can also be used in the industrial end-market in imaging and sensing systems for process feedback and control, quality assurance, and waste reduction. Adoption of our products in the industrial end-market is driven by the needs of customers to advance semiconductor and microelectronics industry roadmaps, and by Industry 4.0/5.0 trends, including increasing manufacturing precision and flexibility and reducing waste and environmental impact. Demand for our products in the industrial end-market is driven by end-customer investments in manufacturing capacity. Our lasers also address certain semiconductor inspection and life-science applications.

- removed (2025-11-05):
[0001628280-25-022788:note_history:37]
Business Combinations

- removed (2025-11-05):
[0001628280-25-022788:note_history:38]
On November 7, 2023, we completed the acquisition of Cloud Light Technology Limited (“Cloud Light”). We have applied the acquisition method of accounting to account for this transaction in accordance with ASC Topic 805, Business Combinations. Our condensed consolidated financial statements include the operating results of the acquired entities from the acquisition close date. Refer to “Note 4. Business Combinations” for further discussions of this transaction.

- removed (2025-11-05):
[0001628280-25-022788:note_history:39]
The condensed consolidated financial statements include the accounts of Lumentum Holdings Inc. and its wholly owned subsidiaries. All inter-company transactions and balances are eliminated in consolidation.


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2025-11-05):
[0001628280-25-049073:note_history:40]
| September 27, 2025 | 2026 Notes (1) |  | 2028 Notes (2) |  | 2029 Notes (3) |  | 2032 Notes (4) |  | Total |  |  |  |  |  |
| Principal | $ | 468.9 |  |  | $ | 861.0 |  |  | $ | 603.7 |  |  | $ | 1,265.0 |  |  | $ | 3,198.6 |  |  |  |  |  |  |
| Unamortized debt discount and debt issuance costs | (0.6) |  |  | (3.0) |  |  | (3.3) |  |  | (10.4) |  |  | (17.3) |  |  |  |  |  |  |
| Net carrying amount of the liability component | $ | 468.3 |  |  | $ | 858.0 |  |  | $ | 600.4 |  |  | $ | 1,254.6 |  |  | $ | 3,181.3 |  |  |  |  |  |  |

- changed (2025-11-05):
[0001628280-25-049073:note_history:41]
(1) If the closing price of our stock exceeds $129.08 (or 130% of the conversion price of $99.29) for 20 of the last 30 trading days of any future fiscal quarter, our 2026 Notes would become convertible at the option of the holders during the subsequent fiscal quarter, which was the case as of the end of the first quarter of fiscal year 2026, and therefore, the debt was reclassified to current liabilities in our condensed consolidated balance sheets.
  (was, 2025-05-07, similarity 0.6464):
[0001628280-25-022788:note_history:41]
(1) If the closing price of our stock exceeds $129.08 (or 130% of the conversion price of $99.29) for 20 of the last 30 trading days of any future fiscal quarter, our 2026 Notes would become convertible at the option of the holders during the subsequent fiscal quarter and the debt would be reclassified to current liabilities in our condensed consolidated balance sheet.

- changed (2025-11-05):
[0001628280-25-049073:note_history:42]
(2) If the closing price of our stock exceeds $170.34 (or 130% of the conversion price of $131.03) for 20 of the last 30 trading days of any future fiscal quarter, our 2028 Notes would become convertible at the option of the holders during the subsequent fiscal quarter and the debt would be reclassified to current liabilities in our condensed consolidated balance sheets.
  (was, 2025-05-07, similarity 0.9986):
[0001628280-25-022788:note_history:42]
(2) If the closing price of our stock exceeds $170.34 (or 130% of the conversion price of $131.03) for 20 of the last 30 trading days of any future fiscal quarter, our 2028 Notes would become convertible at the option of the holders during the subsequent fiscal quarter and the debt would be reclassified to current liabilities in our condensed consolidated balance sheet.

- added (2025-11-05):
[0001628280-25-049073:note_history:43]
(3) If the closing price of our stock exceeds $90.40 (or 130% of the conversion price of $69.54) for 20 of the last 30 trading days of any future quarter, our 2029 Notes would become convertible at the option of the holders during the subsequent fiscal quarter, which was the case as of the end of the first quarter of fiscal year 2026, and therefore, the debt was reclassified to current liabilities in our consolidated balance sheets.

- removed (2025-11-05):
[0001628280-25-022788:note_history:44]
| March 29, 2025 |  |  | 2026 Notes (1) |  | 2028 Notes (2) |  | 2029 Notes (3) |  | Total |  |  |  |  |  |
| Principal |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |  | $ | 603.7 |  |  | $ | 2,514.7 |  |  |  |  |  |  |
| Unamortized debt discount and debt issuance costs |  |  | (2.0) |  |  | (3.6) |  |  | (3.6) |  |  | (9.2) |  |  |  |  |  |  |
| Net carrying amount of the liability component |  |  | $ | 1,048.0 |  |  | $ | 857.4 |  |  | $ | 600.1 |  |  | $ | 2,505.5 |  |  |  |  |  |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-11-05):
[0001628280-25-049073:note_history:45]
|  | September 27, 2025 |  | June 28, 2025 |
|  | Short-term |  | Long-term |  | Total |  | Short-term |  | Long-term |  | Total |
| Convertible notes | $ | 1,068.7 |  |  | $ | 2,112.6 |  |  | $ | 3,181.3 |  |  | $ | — |  |  | $ | 2,506.2 |  |  | $ | 2,506.2 |  |
| Term loans | 10.3 |  |  | 51.9 |  |  | 62.2 |  |  | 10.6 |  |  | 56.4 |  |  | 67.0 |  |
| Total | $ | 1,079.0 |  |  | $ | 2,164.5 |  |  | $ | 3,243.5 |  |  | $ | 10.6 |  |  | $ | 2,562.6 |  |  | $ | 2,573.2 |  |
  (was, 2025-05-07, similarity 0.6822):
[0001628280-25-022788:note_history:45]
|  | March 29, 2025 |  | June 29, 2024 |
|  | Short-term |  | Long-term |  | Total |  | Short-term |  | Long-term |  | Total |
| Convertible notes | $ | — |  |  | $ | 2,505.5 |  |  | $ | 2,505.5 |  |  | $ | — |  |  | $ | 2,503.2 |  |  | $ | 2,503.2 |  |
| Term loans | 10.3 |  |  | 56.9 |  |  | 67.2 |  |  | — |  |  | — |  |  | — |  |
| Total | $ | 10.3 |  |  | $ | 2,562.4 |  |  | $ | 2,572.7 |  |  | $ | — |  |  | $ | 2,503.2 |  |  | $ | 2,503.2 |  |

- added (2025-11-05):
[0001628280-25-049073:note_history:46]
On September 8, 2025, we issued $1,265.0 million in aggregate principal amount of 0.375% Convertible Senior Notes due in 2032 (“2032 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act of 1933, as amended. The 2032 Notes are governed by an indenture between the Company and U.S. Bank Trust Company, National Association, as trustee (the “2032 Indenture”). The 2032 Notes are unsecured, rank equally with all of the Company’s existing senior unsecured indebtedness, including the Company’s outstanding 0.50% Convertible Senior Notes due 2026, 0.50% Convertible Senior Notes due 2028, and 1.50% Convertible Senior Notes due 2029, and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

- added (2025-11-05):
[0001628280-25-049073:note_history:47]
The net proceeds from the sale of the 2032 Notes was approximately $1,255.7 million, after deducting $9.3 million of net issuance costs. In addition, we incurred $1.1 million of professional fees directly related to this transaction, which was recorded as part of accrued expenses in our condensed consolidated balance sheets as of September 27, 2025. Concurrent with the issuance of the 2032 Notes, we used $843.1 million of the net proceeds to repurchase $581.1 million aggregate principal amount of the 0.50% Convertible Senior Notes due in 2026 and $102.0 million of the net proceeds to pay the cost of the 2032 Capped Call Options. We intend to use the remaining net proceeds for general corporate purposes, which may include the repayment or repurchase of our indebtedness, including any of our existing convertible notes, capital expenditures, working capital and potential acquisitions.

- changed (2025-11-05):
[0001628280-25-049073:note_history:48]
The  2032 Notes bear interest at a rate of 0.375% per year, payable semi-annually in arrears on March 15 and September 15 of each year, beginning on March 15, 2026. The 2032 Notes will mature on March 15, 2032, unless earlier redeemed, repurchased by us, or converted pursuant to their terms.
  (was, 2025-05-07, similarity 0.6049):
[0001628280-25-022788:note_history:48]
The 2024 Notes bore interest at a rate of 0.25% per year. Interest on the 2024 Notes was payable semi-annually in arrears on March 15 and September 15 of each year. The 2024 Notes matured on March 15, 2024.

- changed (2025-11-05):
[0001628280-25-049073:note_history:49]
The initial conversion rate is 5.3257 shares of common stock per $1,000 principal amount of the 2032 Notes (which is equivalent to an initial conversion price of approximately $187.77 per share). The conversion rate is subject to adjustment upon the occurrence of certain events specified in the 2032 Indenture but will not be adjusted for any accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change (as defined in the 2032 Indenture) or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert the 2032 Notes in connection with such make-whole fundamental change or notice of redemption.
  (was, 2025-05-07, similarity 0.9743):
[0001628280-25-022788:note_history:49]
The initial conversion rate is 14.3808 shares of common stock per $1,000 principal amount of the 2029 Notes (which is equivalent to an initial conversion price of approximately $69.54 per share). The conversion rate is subject to adjustment upon the occurrence of certain events specified in the 2029 Indenture but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert the 2029 Notes in connection with such make-whole fundamental change or notice of redemption.

- added (2025-11-05):
[0001628280-25-049073:note_history:50]
Prior to the close of business on the business day immediately preceding December 15, 2031, holders of the 2032 Notes may convert their 2032 Notes only under the following circumstances:

- changed (2025-11-05):
[0001628280-25-049073:note_history:51]
•during any fiscal quarter commencing after December 27, 2025 (and only during such fiscal quarter), if the last reported sale price of the common stock for at least 20 trading days (whether or not consecutive) during the period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price of the 2032 Notes, or $244.10, on each applicable trading day;
  (was, 2025-05-07, similarity 0.9922):
[0001628280-25-022788:note_history:51]
•during any fiscal quarter commencing after September 30, 2023 (and only during such fiscal quarter), if the last reported sale price of the common stock for at least 20 trading days (whether or not consecutive) during the period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price of the 2029 Notes, or $90.40, on each applicable trading day;

- added (2025-11-05):
[0001628280-25-049073:note_history:52]
•if we call any or all of the 2032 Notes for redemption, at any time prior to the close of business on the second scheduled trading day immediately preceding the redemption date; or

- changed (2025-11-05):
[0001628280-25-049073:note_history:53]
On or after December 15, 2031 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their 2032 Notes at any time. Upon conversion, we are required to satisfy our conversion obligation with respect to such converted 2032 Notes by paying cash equal to the principal amount of such converted 2032 Notes and paying or delivering, as the case may be, cash, shares of common stock or a combination of cash and shares of common stock, at our election, with respect to any conversion value in excess thereof, if any.
  (was, 2025-05-07, similarity 0.8303):
[0001628280-25-022788:note_history:53]
On or after September 15, 2026 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their 2026 Notes at any time. Following our entry into the First Supplemental Indenture, dated as of September 25, 2024, to the 2026 Indenture, upon conversion, we are required to satisfy our conversion obligation with respect to such converted 2026 Notes by delivering cash equal to the principal amount of such converted 2026 Notes and cash, shares of common stock or a combination of cash and shares of common stock, at our election, with respect to any conversion value in excess thereof.

- added (2025-11-05):
[0001628280-25-049073:note_history:54]
We may redeem for cash all or any portion of the 2032 Notes, at our option (subject to the partial redemption limitation set forth in the 2032 Indenture), on or after March 20, 2029, if the last reported sale price of our common stock has been at least 130% of the conversion price then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading-day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which we provide notice of redemption at a redemption price equal to 100% of the principal amount of the 2032 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. No sinking fund is provided for the 2032 Notes. If we elect to redeem fewer than all of the outstanding 2032 Notes, at least $100.0 million aggregate principal amount of the 2032 Notes must be outstanding and not subject to redemption as of the redemption notice date. Upon the occurrence of a fundamental change (as defined in the 2032 Indenture), holders may require us to repurchase all or a portion of their 2032 Notes for cash at a price equal to 100% of the principal amount of the 2032 Notes to be repurchased, plus any accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

- changed (2025-11-05):
[0001628280-25-049073:note_history:55]
The entirety of the 2032 Notes are recorded as convertible notes, non-current in our consolidated balance sheets as of September 27, 2025, measured at amortized cost.
  (was, 2025-05-07, similarity 0.8917):
[0001628280-25-022788:note_history:55]
The entire 2029 Notes are recorded as convertible notes, non-current in our consolidated balance sheets as of March 29, 2025 and June 29, 2024, measured at amortized cost.

- added (2025-11-05):
[0001628280-25-049073:note_history:56]
2032 Capped Call Options

- added (2025-11-05):
[0001628280-25-049073:note_history:57]
In September 2025, in connection with the issuances of the 2032 Notes, the Company entered into privately negotiated capped call transactions (the “2032 Capped Call Options”) with certain financial institutions (the “2032 Capped Call Counterparties”). The 2032 Capped Call Options cover, subject to anti-dilution adjustments substantially similar to those applicable to the 2032 Notes, the number of shares of our common stock that initially underlie the 2032 Notes and are generally expected to reduce potential dilution to the Company’s common stock upon any conversion of 2032 Notes and/or offset any cash payments the Company would be required to make in excess of the principal amount of converted 2032 Notes, as the case may be, with such reduction and/or offset subject to a cap. The cap price of the 2032 Capped Call Options was initially $268.24 per share, and is subject to certain adjustments under the terms of the 2032 Capped Call Options. If the market price per share of our common stock, as measured under the terms of the 2032 Capped Call Options, exceeds the cap price of the 2032 Capped Call Options, there would be dilution and/or there would not be an offset of any potential cash payments in excess of the principal amount of converted 2032 Notes, in each case, to the extent that such market price exceeds the cap price of the 2032 Capped Call Options.

- added (2025-11-05):
[0001628280-25-049073:note_history:58]
Each of the 2032 Capped Call Options was executed pursuant to a separate agreement entered into by the Company and each of the 2032 Capped Call Counterparties. The 2032 Capped Call Options are not part of the terms of the 2032 Notes and will not affect any holder’s rights under the 2032 Notes. Holders of the 2032 Notes will not have any rights with respect to the 2032 Capped Call Options. The Company concluded that the 2032 Capped Call Options met the criteria for equity classification because they were indexed to the Company’s common stock and the Company has the discretion to settle the 2032 Capped Call Options in shares or cash. As a result, the $102.0 million amount paid was recorded as a reduction to additional paid-in capital within the Company’s condensed consolidated balance sheets as of September 27, 2025, along with the offsetting associated current tax impact of $0.2 million.

- added (2025-11-05):
[0001628280-25-049073:note_history:59]
The Company made a tax election to integrate the 2032 Notes and the 2032 Capped Call Options for federal income tax purposes pursuant to applicable U.S. Treasury Regulations. Accordingly, the $102.0 million gross cost of the purchased 2032 Capped Call Options will be deductible for income tax purposes as original issue discount interest over the term of the 2032 Notes. As a result, the Company established a deferred income tax asset of $21.4 million at inception, with a corresponding valuation allowance as it is not more-likely-than-not that our U.S. deferred tax assets are realizable in the future. As of September 27, 2025, we have recognized a current tax impact of  $0.2 million at issuance, which is recorded as an increase to additional paid-in capital within the Company’s condensed consolidated balance sheets.

- changed (2025-11-05):
[0001628280-25-049073:note_history:60]
On June 16, 2023, we issued $603.7 million in aggregate principal amount of 1.50% Convertible Senior Notes due in 2029 (“2029 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act of 1933, as amended. The 2029 Notes are governed by an indenture between the Company and U.S. Bank Trust Company, National Association, as trustee (the “2029 Indenture”). The 2029 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.
  (was, 2025-05-07, similarity 0.9439):
[0001628280-25-022788:note_history:60]
On June 16, 2023, we issued $603.7 million in aggregate principal amount of 1.50% Convertible Senior Notes due in 2029 (“2029 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act of 1933, as amended. The 2029 Notes are governed by an indenture between the Company and U.S. Bank Trust Company, National Association, (as successor in interest to U.S. Bank National Association), as a trustee (the “2029 Indenture”). The 2029 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

- added (2025-11-05):
[0001628280-25-049073:note_history:61]
The initial conversion rate is 14.3808 shares of common stock per $1,000 principal amount of the 2029 Notes (which is equivalent to an initial conversion price of approximately $69.54 per share). The conversion rate is subject to adjustment upon the occurrence of certain events specified in the 2029 Indenture but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change (as defined in the 2029 Indenture) or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert the 2029 Notes in connection with such make-whole fundamental change or notice of redemption.

- added (2025-11-05):
[0001628280-25-049073:note_history:62]
•during any fiscal quarter (and only during such fiscal quarter), if the last reported sale price of the common stock for at least 20 trading days (whether or not consecutive) during the period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price of the 2029 Notes, or $90.40, on each applicable trading day;

- added (2025-11-05):
[0001628280-25-049073:note_history:63]
•during the five consecutive business day period after any five consecutive trading day period (the “2029 measurement period”) in which the trading price per $1,000 principal amount of 2029 Notes for each trading day of the 2029 measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate on each such trading day;

- added (2025-11-05):
[0001628280-25-049073:note_history:64]
•upon the occurrence of specified corporate events as specified in the 2029 Indenture.

- added (2025-11-05):
[0001628280-25-049073:note_history:65]
Since the closing price of our stock exceeded $90.40 (or 130% of the conversion price of $69.54) for 20 of the last 30 trading days of our first quarter of fiscal year 2026, our 2029 Notes became convertible at the option of the holders during the second quarter of fiscal year 2026, thus, the entire 2029 Notes are recorded as short-term debt, which is presented as current liabilities in our consolidated balance sheets as of September 27, 2025, measured at amortized cost, while the entire 2029 Notes are recorded as convertible notes, non-current in our consolidated balance sheets as of June 28, 2025, measured at amortized cost.

- changed (2025-11-05):
[0001628280-25-049073:note_history:66]
In March 2022, we issued $861.0 million in aggregate principal amount of 0.50% Convertible Senior Notes due in 2028 (the “2028 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act of 1933, as amended (the “Securities Act”). The 2028 Notes are governed by an indenture between the Company and U.S. Bank Trust Company, National Association, as trustee (the “2028 Indenture”). The 2028 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.
  (was, 2025-05-07, similarity 0.9516):
[0001628280-25-022788:note_history:66]
In March 2022, we issued $861.0 million in aggregate principal amount of 0.50% Convertible Senior Notes due in 2028 (the “2028 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act of 1933, as amended (the “Securities Act”). The 2028 Notes are governed by an indenture between the Company and U.S. Bank Trust Company, National Association (as successor in interest to U.S. Bank National Association), as trustee (the “2028 Indenture”). The 2028 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

- changed (2025-11-05):
[0001628280-25-049073:note_history:67]
On or after March 15, 2028 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their 2028 Notes at any time. Following our irrevocable settlement method election made on September 25, 2024, upon conversion, we are required to satisfy our conversion obligation with respect to such converted 2028 Notes by paying cash equal to the principal amount of such converted 2028 Notes and paying or delivering, as the case may be, cash, shares of common stock or a combination of cash and shares of common stock, at our election, with respect to any conversion value in excess thereof,if any.
  (was, 2025-05-07, similarity 0.9519):
[0001628280-25-022788:note_history:67]
On or after March 15, 2028 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their 2028 Notes at any time. Following our irrevocable settlement method election made on September 25, 2024, upon conversion, we are required to satisfy our conversion obligation with respect to such converted 2028 Notes by delivering cash equal to the principal amount of such converted 2028 Notes and cash, shares of common stock or a combination of cash and shares of common stock, at our election, with respect to any conversion value in excess thereof.

- changed (2025-11-05):
[0001628280-25-049073:note_history:68]
We initially bifurcated the principal amount of the 2028 Notes into liability and equity components. The liability component of the 2028 Notes was initially valued at $629.8 million based on the contractual cash flow discounted at an appropriate comparable market on non-convertible debt borrowing rate at the date of issuance, which was 5.7%, with the equity component representing the residual amount of the proceeds of $231.2 million, which was recorded as a debt discount. Upon adoption of ASU 2020-06 in the first quarter of fiscal 2023, our 2028 Notes were accounted for as a single liability measured at amortized cost. The entire 2028 Notes are recorded as convertible notes, non-current in our consolidated balance sheets as of September 27, 2025 and June 28, 2025, measured at amortized cost.
  (was, 2025-05-07, similarity 0.9908):
[0001628280-25-022788:note_history:68]
We initially bifurcated the principal amount of the 2028 Notes into liability and equity components. The liability component of the 2028 Notes was initially valued at $629.8 million based on the contractual cash flow discounted at an appropriate comparable market on non-convertible debt borrowing rate at the date of issuance, which was 5.7%, with the equity component representing the residual amount of the proceeds of $231.2 million, which was recorded as a debt discount. Upon adoption of ASU 2020-06 in the first quarter of fiscal 2023, our 2028 Notes were accounted for as a single liability measured at amortized cost. The entire 2028 Notes are recorded as convertible notes, non-current in our consolidated balance sheets as of March 29, 2025 and June 29, 2024, measured at amortized cost.

- changed (2025-11-05):
[0001628280-25-049073:note_history:69]
In December 2019, we issued $1,050.0 million in aggregate principal amount of 0.50% Convertible Senior Notes due in 2026 (the “2026 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act. The 2026 Notes are governed by an indenture between the Company and U.S. Bank Trust Company, National Association (as successor in interest to U.S. Bank National Association), as trustee (as supplemented by the First Supplemental Indenture, dated as of September 25, 2024, the “2026 Indenture”). The 2026 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.
  (was, 2025-05-07, similarity 0.8467):
[0001628280-25-022788:note_history:69]
In March 2017, we issued $450.0 million in aggregate principal amount of 0.25% convertible senior notes due in 2024 (the “2024 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act. The 2024 Notes were governed by an indenture between the Company, as the issuer, and U.S. Bank Trust Company National Association (as successor in interest to U.S. Bank National Association), as trustee (the “2024 Indenture”). The 2024 Notes were unsecured and did not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

- added (2025-11-05):
[0001628280-25-049073:note_history:70]
On or after September 15, 2026 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their 2026 Notes at any time. Following our entry into the First Supplemental Indenture, dated as of September 25, 2024, to the 2026 Indenture, upon conversion, we are required to satisfy our conversion obligation with respect to such converted 2026 Notes by paying cash equal to the principal amount of such converted 2026 Notes and paying or delivering, as the case may be, cash, shares of common stock or a combination of cash and shares of common stock, at our election, with respect to any conversion value in excess thereof, if any.

- changed (2025-11-05):
[0001628280-25-049073:note_history:71]
We initially bifurcated the principal amount of the 2026 Notes into liability and equity components. The liability component of the 2026 Notes was initially valued at $734.8 million based on the contractual cash flows discounted at an appropriate comparable market non-convertible debt borrowing rate at the date of issuance of 5.8% with the equity component representing the residual amount of the proceeds of $315.2 million, which was recorded as a debt discount. Upon adoption of ASU 2020-06 in the first quarter of fiscal 2023, our 2026 Notes were accounted for as a single liability measured at amortized cost.
  (was, 2025-05-07, similarity 0.8816):
[0001628280-25-022788:note_history:71]
We initially bifurcated the principal amount of the 2026 Notes into liability and equity components. The liability component of the 2026 Notes was initially valued at $734.8 million based on the contractual cash flows discounted at an appropriate comparable market non-convertible debt borrowing rate at the date of issuance of 5.8% with the equity component representing the residual amount of the proceeds of $315.2 million, which was recorded as a debt discount. Upon adoption of ASU 2020-06 in the first quarter of fiscal 2023, our 2026 Notes were accounted for as a single liability measured at amortized cost. The entire 2026 Notes are recorded as convertible notes, non-current in our consolidated balance sheets as of March 29, 2025 and June 29, 2024, measured at amortized cost.

- added (2025-11-05):
[0001628280-25-049073:note_history:72]
Concurrent with the issuance of the 2032 Notes, we used approximately $843.1 million of the net proceeds to repurchase $581.1 million aggregate principal amount of the 2026 Notes. We also paid $0.7 million of the related accrued interest. We have adopted and applied ASU 2024-04, Debt with Conversion and Other Options: Induced Conversions of Convertible Debt Instruments. We determined that this transaction met the requirements for the settlement of debt as an induced conversion. Accordingly, we recorded $256.9 million, which represents the fair value increase in the fair value of the debt, as a reduction to additional paid-in capital within the Company’s consolidated Balance Sheets as of September 27, 2025, and recognized an inducement expense of $5.9 million in our consolidated statements of operations during the three months ended September 27, 2025, which represents the excess of fair value of the total consideration over the fair value of securities issuable pursuant to the original conversion terms.

- added (2025-11-05):
[0001628280-25-049073:note_history:73]
Since the closing price of our stock exceeded $129.08 (or 130% of the conversion price of $99.29) for 20 of the last 30 trading days of our first quarter of fiscal year, our 2026 Notes became convertible at the option of the holders during the second quarter of fiscal year 2026, thus, the remaining 2026 Notes outstanding are recorded as short-term debt, which is presented as current liabilities in our consolidated balance sheets as of September 27, 2025, measured at amortized cost. The entire 2026 Notes are recorded as convertible notes, non-current in our consolidated balance sheets as of June 28, 2025, measured at amortized cost.

- added (2025-11-05):
[0001628280-25-049073:note_history:74]
| September 27, 2025 | 2026 Notes (1) |  | 2028 Notes (2) |  | 2029 Notes (3) |  | 2032 Notes (4) |  | Total |  |  |  |  |  |
| Principal | $ | 468.9 |  |  | $ | 861.0 |  |  | $ | 603.7 |  |  | $ | 1,265.0 |  |  | $ | 3,198.6 |  |  |  |  |  |  |
| Unamortized debt discount and debt issuance costs | (0.6) |  |  | (3.0) |  |  | (3.3) |  |  | (10.4) |  |  | (17.3) |  |  |  |  |  |  |
| Net carrying amount of the liability component | $ | 468.3 |  |  | $ | 858.0 |  |  | $ | 600.4 |  |  | $ | 1,254.6 |  |  | $ | 3,181.3 |  |  |  |  |  |  |

- changed (2025-11-05):
[0001628280-25-049073:note_history:75]
(1) If the closing price of our stock exceeds $129.08 (or 130% of the conversion price of $99.29) for 20 of the last 30 trading days of any future fiscal quarter, our 2026 Notes would become convertible at the option of the holders during the subsequent fiscal quarter, which was the case as of the end of the first quarter of fiscal year 2026, and therefore, the debt was reclassified to current liabilities in our condensed consolidated balance sheets.
  (was, 2025-05-07, similarity 0.6464):
[0001628280-25-022788:note_history:75]
(1) If the closing price of our stock exceeds $129.08 (or 130% of the conversion price of $99.29) for 20 of the last 30 trading days of any future fiscal quarter, our 2026 Notes would become convertible at the option of the holders during the subsequent fiscal quarter and the debt would be reclassified to current liabilities in our condensed consolidated balance sheet.

- changed (2025-11-05):
[0001628280-25-049073:note_history:76]
(2) If the closing price of our stock exceeds $170.34 (or 130% of the conversion price of $131.03) for 20 of the last 30 trading days of any future fiscal quarter, our 2028 Notes would become convertible at the option of the holders during the subsequent fiscal quarter and the debt would be reclassified to current liabilities in our condensed consolidated balance sheets.
  (was, 2025-05-07, similarity 0.9986):
[0001628280-25-022788:note_history:76]
(2) If the closing price of our stock exceeds $170.34 (or 130% of the conversion price of $131.03) for 20 of the last 30 trading days of any future fiscal quarter, our 2028 Notes would become convertible at the option of the holders during the subsequent fiscal quarter and the debt would be reclassified to current liabilities in our condensed consolidated balance sheet.

- added (2025-11-05):
[0001628280-25-049073:note_history:77]
(3) If the closing price of our stock exceeds $90.40 (or 130% of the conversion price of $69.54) for 20 of the last 30 trading days of any future quarter, our 2029 Notes would become convertible at the option of the holders during the subsequent fiscal quarter, which was the case as of the end of the first quarter of fiscal year 2026, and therefore, the debt was reclassified to current liabilities in our consolidated balance sheets.

- changed (2025-11-05):
[0001628280-25-049073:note_history:78]
|  | Three Months Ended |  |  |
|  | September 27, 2025 |  | September 28, 2024 |  |  |  |  |
| Contractual interest expense | $ | 4.7 |  |  | $ | 4.7 |  |  |  |  |  |
| Amortization of the debt discount and debt issuance costs | 0.8 |  |  | 0.7 |  |  |  |  |  |
| Total interest expense | $ | 5.5 |  |  | $ | 5.4 |  |  |  |  |  |
  (was, 2025-05-07, similarity 0.722):
[0001628280-25-022788:note_history:78]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 29, 2025 |  | March 30, 2024 |  | March 29, 2025 |  | March 30, 2024 |
| Contractual interest expense | $ | 4.7 |  |  | $ | 4.9 |  |  | $ | 14.0 |  |  | $ | 14.6 |  |
| Amortization of the debt discount and debt issuance costs | 0.8 |  |  | 4.1 |  |  | 2.3 |  |  | 13.8 |  |
| Total interest expense | $ | 5.5 |  |  | $ | 9.0 |  |  | $ | 16.3 |  |  | $ | 28.4 |  |

- changed (2025-11-05):
[0001628280-25-049073:note_history:79]
The future interest and principal payments related to our convertible notes are as follows as of September 27, 2025 (in millions):
  (was, 2025-05-07, similarity 0.9593):
[0001628280-25-022788:note_history:79]
The future interest and principal payments related to our convertible notes are as follows as of March 29, 2025 (in millions):

- added (2025-11-05):
[0001628280-25-049073:note_history:80]
| Fiscal Years | 2026 Notes |  | 2028 Notes |  | 2029 Notes |  | 2032 Notes |  | Total |
| 2026 | $ | 3.0 |  |  | $ | 4.3 |  |  | $ | 9.1 |  |  | $ | 2.4 |  |  | $ | 18.8 |  |
| 2027 | 470.1 |  |  | 4.3 |  |  | 9.1 |  |  | 4.7 |  |  | 488.2 |  |
| 2028 | — |  |  | 865.3 |  |  | 9.1 |  |  | 4.7 |  |  | 879.1 |  |
| 2029 | — |  |  | — |  |  | 9.1 |  |  | 4.7 |  |  | 13.8 |  |
| 2030 | — |  |  | — |  |  | 608.1 |  |  | 4.7 |  |  | 612.8 |  |
| Thereafter | — |  |  | — |  |  | — |  |  | 1,274.7 |  |  | 1,274.7 |  |
| Total payments | $ | 473.1 |  |  | $ | 873.9 |  |  | $ | 644.5 |  |  | $ | 1,295.9 |  |  | $ | 3,287.4 |  |

- changed (2025-11-05):
[0001628280-25-049073:note_history:81]
As of September 27, 2025, the Company had $38.2 million in principal amount outstanding, of which the short-term portion of $4.3 million is recorded as current liabilities while the long-term portion of $33.9 million is recorded as long-term debt in the Company’s condensed consolidated balance sheets.
  (was, 2025-05-07, similarity 0.9755):
[0001628280-25-022788:note_history:81]
As of March 29, 2025, the Company had $40.2 million in principal amount outstanding, of which the short-term portion of $4.3 million is recorded as current liabilities while the long-term portion of $35.9 million is recorded as long-term debt in the Company’s condensed consolidated balance sheets.

- changed (2025-11-05):
[0001628280-25-049073:note_history:82]
As of September 27, 2025, the Company had $24.0 million in principal amount outstanding, of which the short-term portion of $6.0 million is recorded as current liabilities while the long-term portion of $18.0 million is recorded as long-term debt in the Company’s condensed consolidated balance sheets.
The SMBC Term Loan and the Mizuho Term Loan are collectively referred to as Japan Term Loans.
  (was, 2025-05-07, similarity 0.9816):
[0001628280-25-022788:note_history:82]
As of March 29, 2025, the Company had $27.0 million in principal amount outstanding, of which the short-term portion of $6.0 million is recorded as current liabilities while the long-term portion of $21.0 million is recorded as long-term debt in the Company’s condensed consolidated balance sheets.
The SMBC Term Loan and the Mizuho Term Loan are collectively referred to as Japan Term Loans.

- removed (2025-11-05):
[0001628280-25-022788:note_history:83]
The net proceeds from the sale of the 2029 Notes was $599.4 million, after deducting $4.3 million of net issuance costs. In addition, we incurred $0.8 million of professional fees directly related to this transaction. Concurrent with the issuance of the 2029 Notes, we used $132.8 million of the net proceeds to repurchase $125.0 million aggregate principal amount of the 0.25% convertible senior notes due in 2024 and $125.0 million of the net proceeds to repurchase our common stock in privately negotiated transactions. We intend to use the remaining net proceeds for general corporate purposes, which may include the repayment of our indebtedness, including any of our existing convertible notes, capital expenditures, working capital and potential acquisitions.

- removed (2025-11-05):
[0001628280-25-022788:note_history:84]
The net proceeds from the sale of the 2028 Notes was $854.8 million, after deducting $6.2 million in issuance costs. In addition, we incurred $0.7 million in professional fees in connection with this transaction. Concurrent with the issuance of the 2028 Notes, we used $200.0 million of the net proceeds to repurchase our common stock in privately negotiated transactions.

- removed (2025-11-05):
[0001628280-25-022788:note_history:85]
In December 2019, we issued $1,050.0 million in aggregate principal amount of 0.50% Convertible Senior Notes due in 2026 (the “2026 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act. The 2026 Notes are governed by an indenture between the Company and U.S. Bank Trust Company, National Association as successor in interest to U.S. Bank National Association, as trustee (as supplemented by the First Supplemental Indenture, dated as of September 25, 2024, the “2026 Indenture”). We used approximately $196.0 million of the net proceeds of the offering to repay in full all amounts outstanding under our term loan credit facility, and a portion of the net proceeds of the offering to purchase approximately $200.0 million of our common stock concurrently with the pricing of the offering in privately negotiated transactions. The 2026 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

- removed (2025-11-05):
[0001628280-25-022788:note_history:86]
Concurrent with the issuance of the 2029 Notes in June 2023, we used $132.8 million of the net proceeds to repurchase $125.0 million aggregate principal amount of the 2024 Notes, which we accounted for as an extinguishment of liability. $13.5 million of the $132.8 million repurchase price was allocated to the conversion feature of the repurchased 2024 Notes, representing the fair value of the conversion feature at the date of the repurchase, and was recognized as a reduction of the stockholders’ equity. Additionally, since issuing the 2024 Notes, we converted a total of approximately $1.9 million of principal amount of the 2024 Notes, with less than $0.1 million of principle amount converted during the three and nine months ended March 29, 2025.

- removed (2025-11-05):
[0001628280-25-022788:note_history:87]
On March 15, 2024, the 2024 Notes maturity date, we fully repaid the remaining principal amount of $323.1 million. The conversion feature previously classified within stockholder’s equity was fully amortized as of the maturity date.

- removed (2025-11-05):
[0001628280-25-022788:note_history:88]
| March 29, 2025 |  |  | 2026 Notes (1) |  | 2028 Notes (2) |  | 2029 Notes (3) |  | Total |  |  |  |  |  |
| Principal |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |  | $ | 603.7 |  |  | $ | 2,514.7 |  |  |  |  |  |  |
| Unamortized debt discount and debt issuance costs |  |  | (2.0) |  |  | (3.6) |  |  | (3.6) |  |  | (9.2) |  |  |  |  |  |  |
| Net carrying amount of the liability component |  |  | $ | 1,048.0 |  |  | $ | 857.4 |  |  | $ | 600.1 |  |  | $ | 2,505.5 |  |  |  |  |  |  |

- removed (2025-11-05):
[0001628280-25-022788:note_history:89]
| Fiscal Years |  |  | 2026 Notes |  | 2028 Notes |  | 2029 Notes |  | Total |
| 2025 |  |  | $ | 2.7 |  |  | $ | 2.2 |  |  | $ | 4.6 |  |  | $ | 9.5 |  |
| 2026 |  |  | 5.3 |  |  | 4.3 |  |  | 9.1 |  |  | 18.7 |  |
| 2027 |  |  | 1,052.5 |  |  | 4.3 |  |  | 9.1 |  |  | 1,065.9 |  |
| 2028 |  |  | — |  |  | 865.3 |  |  | 9.1 |  |  | 874.4 |  |
| 2029 |  |  | — |  |  | — |  |  | 617.1 |  |  | 617.1 |  |
| Total payments |  |  | $ | 1,060.5 |  |  | $ | 876.1 |  |  | $ | 649.0 |  |  | $ | 2,585.6 |  |


## us-gaap:DebtSecuritiesAvailableForSaleUnrealizedLossPositionFairValueTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-11-05):
[0001628280-25-049073:note_history:90]
|  | Continuous Loss Position for More Than 12 Months |  | Continuous Loss Position for Less Than 12 Months |  | Gross Unrealized Losses |  |  |  |  |  |  |  |  |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  |  |  |  |  |  |  |  |  |
| September 27, 2025: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | 16.0 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | 2.7 |  |  | — |  |  | — |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 32.5 |  |  | (0.1) |  |  | 3.0 |  |  | — |  |  | (0.1) |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 20.0 |  |  | — |  |  | — |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Total | $ | 71.2 |  |  | $ | (0.1) |  |  | $ | 3.0 |  |  | $ | — |  |  | $ | (0.1) |  |  |  |  |  |  |  |  |  |
| June 28, 2025: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | — |  |  | $ | — |  |  | $ | 24.5 |  |  | $ | — |  |  | $ | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | — |  |  | — |  |  | 5.2 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | — |  |  | — |  |  | 73.8 |  |  | (0.1) |  |  | (0.1) |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | — |  |  | — |  |  | 35.3 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Total | $ | — |  |  | $ | — |  |  | $ | 138.8 |  |  | $ | (0.1) |  |  | $ | (0.1) |  |  |  |  |  |  |  |  |  |
  (was, 2025-05-07, similarity 0.6867):
[0001628280-25-022788:note_history:90]
|  | Continuous Loss Position for More Than 12 Months |  | Continuous Loss Position for Less Than 12 Months |  | Gross Unrealized Losses |  |  |  |  |  |  |  |  |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  |  |  |  |  |  |  |  |  |
| March 29, 2025: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | — |  |  | $ | — |  |  | $ | 26.2 |  |  | $ | — |  |  | $ | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | — |  |  | — |  |  | 2.3 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 4.3 |  |  | — |  |  | 72.3 |  |  | (0.1) |  |  | (0.1) |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | — |  |  | — |  |  | 29.8 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Total | $ | 4.3 |  |  | $ | — |  |  | $ | 130.6 |  |  | $ | (0.1) |  |  | $ | (0.1) |  |  |  |  |  |  |  |  |  |
| June 29, 2024: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | 62.3 |  |  | $ | (0.3) |  |  | $ | 12.6 |  |  | $ | — |  |  | $ | (0.3) |  |  |  |  |  |  |  |  |  |
| Commercial paper | — |  |  | — |  |  | 28.6 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 133.7 |  |  | (0.5) |  |  | 90.6 |  |  | (0.2) |  |  | (0.7) |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 72.3 |  |  | (0.4) |  |  | 39.7 |  |  | (0.1) |  |  | (0.5) |  |  |  |  |  |  |  |  |  |
| Total | $ | 268.3 |  |  | $ | (1.2) |  |  | $ | 171.5 |  |  | $ | (0.3) |  |  | $ | (1.5) |  |  |  |  |  |  |  |  |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-11-05):
[0001628280-25-049073:note_history:91]
|  | September 27, 2025 |  | June 28, 2025 |
|  | Short-term |  | Long-term |  | Total |  | Short-term |  | Long-term |  | Total |
| Convertible notes | $ | 1,068.7 |  |  | $ | 2,112.6 |  |  | $ | 3,181.3 |  |  | $ | — |  |  | $ | 2,506.2 |  |  | $ | 2,506.2 |  |
| Term loans | 10.3 |  |  | 51.9 |  |  | 62.2 |  |  | 10.6 |  |  | 56.4 |  |  | 67.0 |  |
| Total | $ | 1,079.0 |  |  | $ | 2,164.5 |  |  | $ | 3,243.5 |  |  | $ | 10.6 |  |  | $ | 2,562.6 |  |  | $ | 2,573.2 |  |
  (was, 2025-05-07, similarity 0.6822):
[0001628280-25-022788:note_history:91]
|  | March 29, 2025 |  | June 29, 2024 |
|  | Short-term |  | Long-term |  | Total |  | Short-term |  | Long-term |  | Total |
| Convertible notes | $ | — |  |  | $ | 2,505.5 |  |  | $ | 2,505.5 |  |  | $ | — |  |  | $ | 2,503.2 |  |  | $ | 2,503.2 |  |
| Term loans | 10.3 |  |  | 56.9 |  |  | 67.2 |  |  | — |  |  | — |  |  | — |  |
| Total | $ | 10.3 |  |  | $ | 2,562.4 |  |  | $ | 2,572.7 |  |  | $ | — |  |  | $ | 2,503.2 |  |  | $ | 2,503.2 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-11-05):
[0001628280-25-049073:note_history:92]
The future interest and principal payments related to our convertible notes are as follows as of September 27, 2025 (in millions):
  (was, 2025-05-07, similarity 0.9593):
[0001628280-25-022788:note_history:92]
The future interest and principal payments related to our convertible notes are as follows as of March 29, 2025 (in millions):

- added (2025-11-05):
[0001628280-25-049073:note_history:93]
| Fiscal Years | 2026 Notes |  | 2028 Notes |  | 2029 Notes |  | 2032 Notes |  | Total |
| 2026 | $ | 3.0 |  |  | $ | 4.3 |  |  | $ | 9.1 |  |  | $ | 2.4 |  |  | $ | 18.8 |  |
| 2027 | 470.1 |  |  | 4.3 |  |  | 9.1 |  |  | 4.7 |  |  | 488.2 |  |
| 2028 | — |  |  | 865.3 |  |  | 9.1 |  |  | 4.7 |  |  | 879.1 |  |
| 2029 | — |  |  | — |  |  | 9.1 |  |  | 4.7 |  |  | 13.8 |  |
| 2030 | — |  |  | — |  |  | 608.1 |  |  | 4.7 |  |  | 612.8 |  |
| Thereafter | — |  |  | — |  |  | — |  |  | 1,274.7 |  |  | 1,274.7 |  |
| Total payments | $ | 473.1 |  |  | $ | 873.9 |  |  | $ | 644.5 |  |  | $ | 1,295.9 |  |  | $ | 3,287.4 |  |

- removed (2025-11-05):
[0001628280-25-022788:note_history:94]
| Fiscal Years |  |  | 2026 Notes |  | 2028 Notes |  | 2029 Notes |  | Total |
| 2025 |  |  | $ | 2.7 |  |  | $ | 2.2 |  |  | $ | 4.6 |  |  | $ | 9.5 |  |
| 2026 |  |  | 5.3 |  |  | 4.3 |  |  | 9.1 |  |  | 18.7 |  |
| 2027 |  |  | 1,052.5 |  |  | 4.3 |  |  | 9.1 |  |  | 1,065.9 |  |
| 2028 |  |  | — |  |  | 865.3 |  |  | 9.1 |  |  | 874.4 |  |
| 2029 |  |  | — |  |  | — |  |  | 617.1 |  |  | 617.1 |  |
| Total payments |  |  | $ | 1,060.5 |  |  | $ | 876.1 |  |  | $ | 649.0 |  |  | $ | 2,585.6 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2025-11-05):
[0001628280-25-049073:note_history:95]
We disaggregate revenue by type of products and by geography. We do not present other levels of disaggregation, such as by customer, markets, contracts, duration of contracts, timing of transfer of control and sales channels, as this information is not used by our CODM to manage the business.

- changed (2025-11-05):
[0001628280-25-049073:note_history:96]
The table below discloses our total net revenue by type of product (in millions, except percentage data):
  (was, 2025-05-07, similarity 0.8066):
[0001628280-25-022788:note_history:96]
The table below discloses our total net revenue attributable to each of our two reportable segments (in millions, except percentage data):

- added (2025-11-05):
[0001628280-25-049073:note_history:97]
|  | Three Months Ended |  |  |
|  | September 27, 2025 |  | September 28, 2024 |  |  |  |  |
|  | Amount |  | % of Total |  | Amount |  | % of Total |  |  |  |  |  |  |  |  |
| Components | 379.2 |  |  | 71.0 | % |  | 231.4 |  |  | 68.7 | % |  |  |  |  |  |  |  |  |
| Systems | 154.6 |  |  | 29.0 | % |  | 105.5 |  |  | 31.3 | % |  |  |  |  |  |  |  |  |
| Net revenue | $ | 533.8 |  |  | 100.0 | % |  | $ | 336.9 |  |  | 100.0 | % |  |  |  |  |  |  |  |  |

- added (2025-11-05):
[0001628280-25-049073:note_history:98]
Refer to “Note 14. Operating Segments and Geographic Information” for a presentation of disaggregated revenue by geography.

- added (2025-11-05):
[0001628280-25-049073:note_history:99]
We record accounts receivable when we have an unconditional right to consideration. Contract liabilities are recorded when cash payments are received or due in advance of performance. Contract liabilities consist of advance payments and deferred revenue, where we have unsatisfied performance obligations. Contract liabilities are classified as deferred revenue and customer deposits and are included in other current liabilities within our condensed consolidated balance sheets. Payment terms vary by customer. The time between invoicing and when payment is due is not significant.

- added (2025-11-05):
[0001628280-25-049073:note_history:100]
| Contract balances |  | Balance sheet location |  | September 27, 2025 |  | June 28, 2025 |  | Change |  | Percentage Change |
| Accounts receivable, net |  | Accounts receivable, net |  | $ | 307.0 |  |  | $ | 250.0 |  |  | $ | 57.0 |  |  | 22.8 | % |
| Deferred revenue and customer deposits |  | Other current liabilities |  | $ | 2.7 |  |  | $ | 0.7 |  |  | $ | 2.0 |  |  | 285.7 | % |

- removed (2025-11-05):
[0001628280-25-022788:note_history:101]
We disaggregate revenue by segment and by geography. We do not present other levels of disaggregation, such as by type of products, customer, markets, contracts, duration of contracts, timing of transfer of control and sales channels, as this information is not used by our CODM to manage the business.

- removed (2025-11-05):
[0001628280-25-022788:note_history:102]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 29, 2025 |  | March 30, 2024 |  | March 29, 2025 |  | March 30, 2024 |
|  | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |
| Cloud & Networking | $ | 365.2 |  |  | 85.9 | % |  | 313.8 |  |  | 85.6 | % |  | $ | 986.7 |  |  | 84.7 | % |  | $ | 830.2 |  |  | 79.0 | % |
| Industrial Tech | 60.0 |  |  | 14.1 | % |  | 52.7 |  |  | 14.4 | % |  | 177.6 |  |  | 15.3 | % |  | 220.7 |  |  | 21.0 | % |
| Net revenue | $ | 425.2 |  |  | 100.0 | % |  | $ | 366.5 |  |  | 100.0 | % |  | $ | 1,164.3 |  |  | 100.0 | % |  | $ | 1,050.9 |  |  | 100.0 | % |

- removed (2025-11-05):
[0001628280-25-022788:note_history:103]
| Contract balances |  | Balance sheet location |  | March 29, 2025 |  | June 29, 2024 |  | Change |  | Percentage Change |
| Accounts receivable, net |  | Accounts receivable, net |  | $ | 255.7 |  |  | $ | 194.7 |  |  | $ | 61.0 |  |  | 31.3 | % |
| Deferred revenue and customer deposits |  | Other current liabilities |  | $ | 0.7 |  |  | $ | 0.6 |  |  | $ | 0.1 |  |  | 16.7 | % |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2025-11-05):
[0001628280-25-049073:note_history:104]
TBD.

- removed (2025-11-05):
[0001628280-25-022788:note_history:105]
Subsequent to the end of the reporting period, the Company initiated a restructuring plan to reduce headcount and spending in order to focus on other market opportunities including cloud and AI markets. We recognized a charge of approximately $7.1 million during the three months ended March 29, 2025, which is included in the restructuring and related charges in our condensed consolidated statements of operations. These charges primarily consist of $5.7 million of write-off of assets including property, plant and equipment, prepayments and other current assets as well as $1.4 million of charges for other contractual commitments associated with the related site closures. The Company expects to incur further restructuring charges in the fourth quarter of fiscal year 2025 for employee severance and other personnel-related costs as a result of these actions, which we estimate to be about $5.0 million.
