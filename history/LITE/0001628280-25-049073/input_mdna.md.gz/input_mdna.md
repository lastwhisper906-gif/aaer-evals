# LITE MD&A — 0001628280-25-049073


## mdna

[0001628280-25-049073:mdna:1]
[same as prior period, unchanged from 0001628280-25-022788:mdna:1]

[0001628280-25-049073:mdna:2]
[same as prior period, unchanged from 0001628280-25-022788:mdna:2]

[0001628280-25-049073:mdna:3]
[same as prior period, unchanged from 0001628280-25-022788:mdna:3]

[0001628280-25-049073:mdna:4]
39

[0001628280-25-049073:mdna:5]
[same as prior period, unchanged from 0001628280-25-022788:mdna:5]

[0001628280-25-049073:mdna:6]
[same as prior period, unchanged from 0001628280-25-022788:mdna:6]

[0001628280-25-049073:mdna:7]
We believe the global markets in which Lumentum participates have fundamentally robust, long-term trends that will increase the need for our photonics products and technologies. We believe the world is becoming more reliant on ever-increasing amounts of data flowing through optical networks and data centers. Lumentum’s products and technology enable the scaling of these optical networks and data centers to higher capacities. AI/ML has caused a dramatic surge in the growing demands on data networking in cloud data centers and accelerated the usage of optical components and modules. We expect that the accelerating shift to digital and virtual approaches to many aspects of work and life will continue into the future. Virtual meetings, video calls, and hybrid in-person and virtual environments for work and other aspects of life will continue to drive strong needs for bandwidth growth and present dynamic new challenges that our technologies address. As manufacturers demand higher levels of precision, new materials, and factory and energy efficiency, suppliers of manufacturing tools globally are turning to laser-based approaches, including the types of lasers Lumentum supplies. Laser-based 3D sensing and LiDAR for security, industrial and automotive applications are rapidly developing markets. The technology enables computer vision applications that enhance security, safety, and new functionality in the electronic devices that people rely on every day. The use of LiDAR and in-cabin 3D sensing in automobile and delivery vehicles over time significantly adds to our long-term market opportunity. Additionally, we expect 3D-enabled machine vision solutions to expand significantly in industrial applications in the coming years.

[0001628280-25-049073:mdna:8]
[same as prior period, unchanged from 0001628280-25-022788:mdna:9]

[0001628280-25-049073:mdna:9]
We disaggregate revenue by type of product, which are Components and Systems, and by geography. A Components product is defined as one of the individual building blocks that goes into creating a larger solution. It is typically not a complete product on its own but rather a specialized element that enables system functionality. This includes semiconductor laser chips, laser sub-assemblies, line subsystems and wavelength management systems. These are supplied to customers who then integrate them into their own full system solutions. Components represent foundational parts that support or enable that system’s operation and include a comprehensive portfolio of optical and photonic chips, components, laser light sources that are integrated into smartphones, subsystems supplied to cloud data center operators, AI/ML infrastructure providers, and network equipment manufacturer customers who are building cloud data center and network infrastructures.

[0001628280-25-049073:mdna:10]
A Systems product is defined as a complete, stand-alone product that delivers full functionality to the end customer. It is typically self-contained and ready to operate within a customer’s network or application environment. This includes optical modules, optical circuit switches, and industrial lasers such as short-pulse solid-state lasers and kilowatt-class fiber lasers. These products integrate multiple technologies and subsystems into a finished solution that directly addresses a customer’s needs. A system represents the end-product that can be deployed and used independently.

[0001628280-25-049073:mdna:11]
Our products enable high-capacity optical links for cloud computing, AI/ML workloads, and data center interconnect (“DCI”) applications, as well as for communications service provider networks. Our offerings support access (local), metro (intracity), long-haul (intercity and global), and submarine (undersea) network infrastructure. Our products serve enterprise network infrastructure needs, including storage area networks (“SANs”), local area networks (“LANs”), and wide area networks (“WANs”). Demand for our products is fueled by the ongoing expansion of network capacity required to support cloud services, AI/ML processing, streaming video, video conferencing, wireless and mobile connectivity, and the internet of things (“IoT”). In addition, our industrial laser products are used for precision material processing across diverse industries, including semiconductor and microelectronics fabrication, electric vehicle and battery production, metal cutting and welding, and advanced manufacturing that emphasize greater manufacturing precision, flexibility, and sustainability.

[0001628280-25-049073:mdna:12]
Operating Segment Information

[0001628280-25-049073:mdna:13]
Prior to fiscal year 2026, we operated in two reportable segments consisting of Cloud & Networking and Industrial Tech. During the first quarter of fiscal year 2026, the Company implemented a re-organization, under which it will be managed as a single, integrated enterprise, with a unified management team overseeing operations across the entire company, rather than through discrete operating segments. The chief operating decision maker (“CODM”) is the Company’s Chief Executive Officer, who reviews financial information presented as a single enterprise for purposes of allocating resources and evaluating financial performance.

[0001628280-25-049073:mdna:14]
The CODM assesses the performance of the single segment and allocates resources based on consolidated net income (loss) included in the Company’s condensed consolidated statements of operations. The CODM uses consolidated net income to set budgets, evaluate performance, review actual results and in deciding whether to reinvest profits into our business, pursue acquisitions, or make any other capital management decisions. The significant segment expenses are reflected in the Company’s condensed consolidated statements of operations and the condensed consolidated statements of cash flows. The measure of the single segment assets is the consolidated assets included in the condensed consolidated balance sheets. Accordingly, we determined we operate in a single reporting segment. Comparative prior period segment information has been updated to reflect the new segment structure and measures. The changes in our operating segments had no impact on our previously reported consolidated results of operations, financial position or cash flows.

[0001628280-25-049073:mdna:15]
Industry Conditions

[0001628280-25-049073:mdna:16]
Our supply chain is complex, and we need to manage supply of certain components required to build our products while confronted with fluctuating demand from our customers. From time to time, we experience logistics and supply chain issues and shortages of the types of components we and our customers require in our products, and we have had to incur incremental supply and procurement costs in order to increase our ability to fulfill demands from our customers.

[0001628280-25-049073:mdna:17]
Through fiscal year 2024, we experienced significant fluctuations in demand as customers delayed projected shipments or built up inventory in response to supply shortages and then brought down inventories as supply chain constraints eased. Our revenue fluctuated in response to these changes in demand and our margins were adversely impacted as we were not been able to fully recover costs, such as underutilized manufacturing capacity. However, beginning in the first quarter of fiscal year 2025, network equipment manufacturers normalized inventory levels and we have seen increasing demand from AI and cloud customers as they continue to expand their data centers.

[0001628280-25-049073:mdna:18]
Due to worldwide operations, we and our customers are also subject to risks relating to the global trade environment. The Company is actively monitoring and assessing the global trade environment, particularly with respect to recent changes and proposed changes in tariff regulations and trade restrictions. The ongoing uncertainty surrounding trading policies, including the potential for additional tariffs, restrictions related to our customers and retaliatory measures by non-U.S. governments, continues to create a volatile environment that could disrupt our operations. The imposition of tariffs on certain imported goods and materials and export controls on critical components may increase our costs and place upward pressure on the cost of goods sold, which, in turn, may reduce our gross margins if we are unable to pass these costs onto customers through price increases.

[0001628280-25-049073:mdna:19]
If these tariff-related and restriction-related cost increases persist or escalate, our financial results could be adversely affected, including lower profitability. Additionally, changes in the global trade landscape could result in reduced market competitiveness and a slowdown in consumer demand as well as disruptions to our supply chain, including longer lead times, higher shipping costs, or limited availability of key inputs. This may constrain our ability to meet customer demand in a timely manner, potentially affecting our revenue growth and operational efficiency. The impact of tariffs on our business is hard to predict, as it is dependent on negotiations with customers and suppliers and other mitigation efforts and potential further changes in global trade policies, including higher tariffs or trade restrictions in the U.S. or other countries.

[0001628280-25-049073:mdna:20]
[same as prior period, unchanged from 0001628280-25-022788:mdna:22]

[0001628280-25-049073:mdna:21]
[same as prior period, unchanged from 0001628280-25-022788:mdna:23]

[0001628280-25-049073:mdna:22]
Our condensed consolidated financial statements are prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) as set forth in the Financial Accounting Standards Board’s Accounting Standards Codification (“ASC”). We also consider the various staff accounting bulletins and other applicable guidance issued by the United States Securities and Exchange Commission (“SEC”). GAAP, as set forth within the ASC, requires us to make certain estimates, judgments and assumptions. We believe that the estimates, judgments and assumptions upon which we rely are reasonable based upon information available to us at the time that these estimates, judgments and assumptions are made. These estimates, judgments and assumptions can affect the reported amounts of assets and liabilities as of the date of the financial statements as well as the reported amounts of revenues and expenses during the periods presented. To the extent there are differences between these estimates, judgments or assumptions and actual results, our financial statements will be affected. The accounting policies that reflect our more significant estimates, judgments and assumptions and which we believe are the most critical to aid in fully understanding and evaluating our reported financial results include the following:

[0001628280-25-049073:mdna:23]
[same as prior period, unchanged from 0001628280-25-022788:mdna:25]

[0001628280-25-049073:mdna:24]
[same as prior period, unchanged from 0001628280-25-022788:mdna:26]

[0001628280-25-049073:mdna:25]
[same as prior period, unchanged from 0001628280-25-022788:mdna:27]

[0001628280-25-049073:mdna:26]
[same as prior period, unchanged from 0001628280-25-022788:mdna:28]

[0001628280-25-049073:mdna:27]
[same as prior period, unchanged from 0001628280-25-022788:mdna:29]

[0001628280-25-049073:mdna:28]
Management’s Discussion and Analysis of Financial Condition and Results of Operations contained in Part II, Item 7 of our Annual Report on Form 10-K for our fiscal year ended June 28, 2025 provides a complete discussion of our critical accounting policies and estimates. There have been no changes to these policies during the three months ended September 27, 2025, except as noted below:

[0001628280-25-049073:mdna:29]
Income Taxes

[0001628280-25-049073:mdna:30]
In accordance with the authoritative guidance on accounting for income taxes, we recognize income taxes using an asset and liability approach. This approach requires the recognition of taxes payable or refundable for the current year and deferred tax liabilities and assets for the future tax consequences of events that have been recognized in our consolidated financial statements or tax returns. The measurement of current and deferred taxes is based on provisions of the enacted tax law, and the effects of future changes in tax laws or rates are not anticipated.

[0001628280-25-049073:mdna:31]
The authoritative guidance provides for recognition of deferred tax assets if the realization of such deferred tax assets is more likely than not to occur based on an evaluation of both positive and negative evidence and the relative weight of the evidence. We consider future growth, forecasted earnings, future taxable income, the mix of earnings in the jurisdictions in which we operate, historical earnings, taxable income in prior years, if carry-back is permitted under the law, and prudent and feasible tax planning strategies in determining the need for a valuation allowance.

[0001628280-25-049073:mdna:32]
In the event we determine that we would not be able to realize all or part of our net deferred tax assets in the future, an adjustment to the deferred tax assets valuation allowance would be charged to earnings in the period in which we make such a determination, or goodwill would be adjusted at our final determination of the valuation allowance related to an acquisition within the measurement period. Conversely, if we later determine that it is more likely than not that all or a portion of the net deferred tax assets will be realized, we would reverse the applicable portion of the previously established valuation allowance. A release of valuation allowance decreases income tax expense in the period of release, increases net income, and reduces our effective tax rate. Such releases may be material to our financial statements depending on the size of the deferred tax assets involved.

[0001628280-25-049073:mdna:33]
In the fourth quarter of fiscal 2025, we released $153.1 million of valuation allowances on our UK deferred tax assets after we considered all available positive and negative evidence related to our UK subsidiary.  We analyzed the UK subsidiary’s historical operating results, projected future taxable income, tax planning strategies, and reversals of deferred tax liabilities, and determined that the weight of available objectively verifiable positive evidence supported the realizability of the UK deferred tax assets. In weighing the available evidence, more weight was placed upon our forecasts of future taxable income than on the history of pre-tax losses as such losses were generated under our prior UK business operating model which will no longer be in effect beginning with fiscal year 2026, and the guarantee of a positive operating margin as we effectuated an internal restructuring at the end of fiscal year 2025. Further, the most significant deferred tax asset in the UK is the net operating loss carryforward. Under UK tax law, net operating losses may be carried forward indefinitely, and we have considered the indefinite carryforward period to be positive evidence.

[0001628280-25-049073:mdna:34]
We are subject to income tax audits by the respective tax authorities of the jurisdictions in which we operate. The determination of our income tax liabilities in each of these jurisdictions requires the interpretation and application of complex, and sometimes uncertain, tax laws and regulations. The authoritative guidance on accounting for income taxes prescribes both recognition and measurement criteria that must be met for the benefit of a tax position to be recognized in the financial statements. If a tax position taken, or expected to be taken, in a tax return does not meet such recognition or measurement criteria, an unrecognized tax benefit liability is recorded. If we ultimately determine that an unrecognized tax benefit liability is no longer necessary, we reverse the liability and recognize a tax benefit in the period in which it is determined that the unrecognized tax benefit liability is no longer necessary.

[0001628280-25-049073:mdna:35]
Our income tax provision is highly dependent on the geographic distribution of our worldwide earnings or losses, tax laws and regulations in various jurisdictions, tax incentives, the availability of tax credits and loss carryforwards, and the effectiveness of our tax planning strategies. The application of tax laws and regulations is subject to legal and factual interpretation, judgment and uncertainty. Tax laws themselves are subject to change as a result of changes in fiscal policy, changes in legislation, and the evolution of regulations and court rulings and tax audits.

[0001628280-25-049073:mdna:36]
The recognition and measurement of current taxes payable or refundable and deferred tax assets and liabilities requires that we make certain estimates and judgments. Changes to these estimates, including changes in judgment regarding the realizability of deferred tax assets and the need for or release of valuation allowances, may have a material impact on our tax provision, net income, and effective tax rate in a future period.

[0001628280-25-049073:mdna:37]
Recently Issued Accounting Pronouncements

[0001628280-25-049073:mdna:38]
Refer to “Note 2. Recently Issued Accounting Pronouncements” in the notes to condensed consolidated financial statements.

[0001628280-25-049073:mdna:39]
[same as prior period, unchanged from 0001628280-25-022788:mdna:33]

[0001628280-25-049073:mdna:40]
[same as prior period, unchanged from 0001628280-25-022788:mdna:34]

[0001628280-25-049073:mdna:41]
|  | Three Months Ended |  |  |
|  | September 27, 2025 |  | September 28, 2024 |  |  |  |  |
| Net revenue by type of products: |  |  |  |  |  |  |  |
| Components | 71.0 | % |  | 69.0 | % |  |  |  |  |
| Systems | 29.0 |  |  | 31.0 |  |  |  |  |  |
| Net revenue | 100.0 |  |  | 100.0 |  |  |  |  |  |
| Cost of sales | 62.3 |  |  | 70.2 |  |  |  |  |  |
| Amortization of acquired developed intangibles | 3.7 |  |  | 6.7 |  |  |  |  |  |
| Gross profit | 34.0 |  |  | 23.1 |  |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 15.2 |  |  | 22.1 |  |  |  |  |  |
| Selling, general and administrative | 15.9 |  |  | 22.6 |  |  |  |  |  |
| Restructuring and related charges | 1.6 |  |  | 2.9 |  |  |  |  |  |
| Total operating expenses | 32.7 |  |  | 47.6 |  |  |  |  |  |
| Income (loss) from operations | 1.3 |  |  | (24.5) |  |  |  |  |  |
| Interest expense | (1.1) |  |  | (1.6) |  |  |  |  |  |
| Other income, net | 0.8 |  |  | 2.6 |  |  |  |  |  |
| Income (loss) before income taxes | 1.0 |  |  | (23.5) |  |  |  |  |  |
| Income tax provision | 0.2 |  |  | 0.9 |  |  |  |  |  |
| Net income (loss) | 0.8 | % |  | (24.5) | % |  |  |  |  |

[0001628280-25-049073:mdna:42]
Financial data for the three months ended September 27, 2025

[0001628280-25-049073:mdna:43]
[same as prior period, unchanged from 0001628280-25-022788:mdna:38]

[0001628280-25-049073:mdna:44]
|  | Three Months Ended |  |  |
|  | September 27, 2025 |  | September 28, 2024 |  | Change |  | Percentage Change |  |  |  |  |  |  |  |  |
| Net revenue by type of products: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Components | 379.2 |  |  | 231.4 |  |  | $ | 147.8 |  |  | 63.9 | % |  |  |  |  |  |  |  |  |
| System | 154.6 |  |  | 105.5 |  |  | 49.1 |  |  | 46.5 | % |  |  |  |  |  |  |  |  |
| Net revenue | $ | 533.8 |  |  | $ | 336.9 |  |  | $ | 196.9 |  |  | 58.4 | % |  |  |  |  |  |  |  |  |
| Gross profit | $ | 181.5 |  |  | $ | 77.9 |  |  | $ | 103.6 |  |  | 133.0 | % |  |  |  |  |  |  |  |  |
| Gross margin | 34.0 | % |  | 23.1 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 81.4 |  |  | $ | 74.3 |  |  | $ | 7.1 |  |  | 9.6 | % |  |  |  |  |  |  |  |  |
| Percentage of net revenue | 15.2 | % |  | 22.1 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative | $ | 85.1 |  |  | $ | 76.3 |  |  | $ | 8.8 |  |  | 11.5 | % |  |  |  |  |  |  |  |  |
| Percentage of net revenue | 15.9 | % |  | 22.6 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring and related charges | $ | 8.3 |  |  | $ | 9.7 |  |  | $ | (1.4) |  |  | (14.4) | % |  |  |  |  |  |  |  |  |
| Percentage of net revenue | 1.6 | % |  | 2.9 | % |  |  |  |  |  |  |  |  |  |  |  |  |

[0001628280-25-049073:mdna:45]
44

[0001628280-25-049073:mdna:46]
[same as prior period, unchanged from 0001628280-25-022788:mdna:41]

[0001628280-25-049073:mdna:47]
Net revenue increased by $196.9 million, or 58.4%, during the three months ended September 27, 2025 compared to the three months ended September 28, 2024, driven by a $147.8 million increase in Components products and a $49.1 million increase in Systems products. Approximately three-quarters of the increase in Components products relates to our ramp of laser chip and laser assembly product shipments to support strong, broad-based demand across intra-data center, data center interconnect and long-haul applications.  The average selling prices of these laser chip and laser assembly products remained relatively flat compared to prior period. The remaining approximately one-quarter of Components revenue growth was due to an increase in shipment volume of data transport products, encompassing line subsystems solutions for long-haul terrestrial networks and charge pump products used in sub-sea network installations.

[0001628280-25-049073:mdna:48]
Nearly all of the increase in our System products was driven by our cloud transceiver product lines due to an increase in shipment volume, which was partially offset by lower pricing across multiple transceiver lines. We also began an initial phase of optical circuit switch shipments and we remain on track for manufacturing expansion over the coming quarters to support future growth.

[0001628280-25-049073:mdna:49]
During the three months ended September 27, 2025, two customers individually accounted for 22%, and 21% of our total revenue, respectively. During the three months ended September 28, 2024, two customers individually accounted for 15% and 12% of our total revenue, respectively.

[0001628280-25-049073:mdna:50]
[same as prior period, unchanged from 0001628280-25-022788:mdna:46]

[0001628280-25-049073:mdna:51]
[same as prior period, unchanged from 0001628280-25-022788:mdna:47]

[0001628280-25-049073:mdna:52]
[same as prior period, unchanged from 0001628280-25-022788:mdna:48]

[0001628280-25-049073:mdna:53]
|  | Three Months Ended |  |  |
|  | September 27, 2025 |  | September 28, 2024 |  |  |  |  |
|  | Amount |  | % of Total |  | Amount |  | % of Total |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States | $ | 93.7 |  |  | 17.6 | % |  | $ | 65.4 |  |  | 19.4 | % |  |  |  |  |  |  |  |  |
| Mexico | 73.6 |  |  | 13.8 |  |  | 33.9 |  |  | 10.0 |  |  |  |  |  |  |  |  |  |
| Other Americas | 8.6 |  |  | 1.6 |  |  | 2.9 |  |  | 0.9 |  |  |  |  |  |  |  |  |  |
| Total Americas | $ | 175.9 |  |  | 33.0 | % |  | $ | 102.2 |  |  | 30.3 | % |  |  |  |  |  |  |  |  |
| Asia-Pacific: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Hong Kong | $ | 92.9 |  |  | 17.4 | % |  | $ | 88.7 |  |  | 26.4 | % |  |  |  |  |  |  |  |  |
| Thailand | 109.1 |  |  | 20.4 |  |  | 52.5 |  |  | 15.6 |  |  |  |  |  |  |  |  |  |
| China | 49.3 |  |  | 9.2 |  |  | 14.6 |  |  | 4.3 |  |  |  |  |  |  |  |  |  |
| Japan | 21.0 |  |  | 3.9 |  |  | 16.9 |  |  | 5.0 |  |  |  |  |  |  |  |  |  |
| Other Asia-Pacific | 49.4 |  |  | 9.3 |  |  | 31.4 |  |  | 9.3 |  |  |  |  |  |  |  |  |  |
| Total Asia-Pacific | $ | 321.7 |  |  | 60.2 | % |  | $ | 204.1 |  |  | 60.6 | % |  |  |  |  |  |  |  |  |
| EMEA | $ | 36.2 |  |  | 6.8 | % |  | $ | 30.6 |  |  | 9.1 | % |  |  |  |  |  |  |  |  |
| Total net revenue | $ | 533.8 |  |  | 100.0 | % |  | $ | 336.9 |  |  | 100.0 | % |  |  |  |  |  |  |  |  |

[0001628280-25-049073:mdna:54]
For the three months ended September 27, 2025 and September 28, 2024, net revenue from customers outside the United States, based on customer shipping location, represented 82.4% and 80.6% of net revenue, respectively.

[0001628280-25-049073:mdna:55]
Our net revenue is primarily denominated in U.S. dollars, including our net revenue from customers outside the United States as presented above. We expect revenue from customers outside of the United States to continue to be an important part of our overall net revenue and an increasing focus for net revenue growth opportunities. However, regulatory and enforcement actions by the United States and other governmental agencies, as well as changes in tax and trade policies and tariffs, have impacted and may continue to negatively impact net revenue from customers outside the United States.

[0001628280-25-049073:mdna:56]
[same as prior period, unchanged from 0001628280-25-022788:mdna:53]

[0001628280-25-049073:mdna:57]
Gross margin for the three months ended September 27, 2025 increased to 34.0% from 23.1% for the three months ended September 28, 2024, primarily driven by the positive impact of higher revenue from our laser chip, laser assembly and data transport products. Approximately two-thirds of the gross margin increase was driven by lower manufacturing costs as a percentage of revenue, primarily due to higher internal factory utilization. The remaining approximately one-third of the gross margin increase was driven by improved product mix of our higher-margin laser chip and laser assembly products.

[0001628280-25-049073:mdna:58]
The markets in which we sell products are undergoing product, architectural and business model transitions driven in part by the deployment of AI, have high customer concentrations, are highly competitive, are price sensitive and/or are affected by customer seasonal and variants in buying patterns. We expect these factors to result in variability of our gross margin and our gross margin may be subject to increasing downward pressure due to these factors.

[0001628280-25-049073:mdna:59]
[same as prior period, unchanged from 0001628280-25-022788:mdna:63]

[0001628280-25-049073:mdna:60]
R&D expense increased by $7.1 million, or 9.6% for the three months ended September 27, 2025 compared to the three months ended September 28, 2024, primarily due to a $5.3 million increase in our cash incentive compensation due to higher revenue and profit levels.

[0001628280-25-049073:mdna:61]
[same as prior period, unchanged from 0001628280-25-022788:mdna:66]

[0001628280-25-049073:mdna:62]
[same as prior period, unchanged from 0001628280-25-022788:mdna:67]

[0001628280-25-049073:mdna:63]
SG&A expense increased by $8.8 million, or 11.5%, during the three months ended September 27, 2025 compared to the three months ended September 28, 2024, primarily due to a $5.7 million increase in our cash incentive compensation due to higher revenue and profit levels, as well as a $7.0 million increase in stock-based compensation and a $3.7 million increase in  legal fees. This was offset by a $4.3 million decrease in amortization of acquired intangibles as certain assets were fully amortized as well as a $1.6 million gain from sale of our Brazilian entities.

[0001628280-25-049073:mdna:64]
From time-to-time, we incur expenses that are not part of our ordinary operations, such as mergers and acquisition-related and litigation expenses, which generally increase our SG&A expenses and potentially impact our profitability expectations in any particular period.

[0001628280-25-049073:mdna:65]
[same as prior period, unchanged from 0001628280-25-022788:mdna:71]

[0001628280-25-049073:mdna:66]
[same as prior period, unchanged from 0001628280-25-022788:mdna:72]

[0001628280-25-049073:mdna:67]
During the three months ended September 27, 2025, we recorded restructuring and related charges of $8.3 million related to a reduction in force during the period in order to enhance operational efficiency and realign our investments toward the most critical initiatives.

[0001628280-25-049073:mdna:68]
During the three months ended September 28, 2024, we recorded restructuring and related charges of $9.7 million, which includes $6.0 million of asset write-offs primarily due to integration efforts to consolidate our sites, $3.0 million of charges related to the discontinuation of our in-house development of coherent DSPs and RFICs and the remaining restructuring charges due to company-wide cost reduction initiatives.

[0001628280-25-049073:mdna:69]
[same as prior period, unchanged from 0001628280-25-022788:mdna:78]

[0001628280-25-049073:mdna:70]
For the three months ended September 27, 2025 and September 28, 2024, we recorded interest expense of $5.7 million and $5.5 million, respectively. The slight increase in interest expense for the three months ended September 27, 2025 is mainly due to the issuance of the 2032 Notes in September 2025.

[0001628280-25-049073:mdna:71]
[same as prior period, unchanged from 0001628280-25-022788:mdna:80]

[0001628280-25-049073:mdna:72]
[same as prior period, unchanged from 0001628280-25-022788:mdna:81]

[0001628280-25-049073:mdna:73]
|  | Three Months Ended |  |  |  |  |
|  | September 27, 2025 |  | September 28, 2024 |  |  |  |  |  |  |
| Foreign exchange and other gains (losses), net | $ | 1.5 |  |  | $ | (0.7) |  |  |  |  |  |  |  |
| Interest and investment income, net | 8.6 |  |  | 9.4 |  |  |  |  |  |  |  |
| Inducement expense | (5.9) |  |  | — |  |  |  |  |  |  |  |
| Total other income, net | $ | 4.2 |  |  | $ | 8.7 |  |  |  |  |  |  |  |

[0001628280-25-049073:mdna:74]
Other income, net for the three months ended September 27, 2025 decreased by $4.5 million compared to the three months ended September 28, 2024 primarily due to a $5.9 million inducement expense related to the partial repurchase of 2026 Notes offset by an increase in net foreign exchange gains of $2.2 million as the U.S. dollar strengthened against the Japanese Yen, which is the underlying currency for our term loans. Interest and investment income, net slightly decreased by $0.8 million compared to the three months ended September 28, 2024 due to slightly lower short term investment balances.

[0001628280-25-049073:mdna:75]
[same as prior period, unchanged from 0001628280-25-022788:mdna:85]

[0001628280-25-049073:mdna:76]
[same as prior period, unchanged from 0001628280-25-022788:mdna:86]

[0001628280-25-049073:mdna:77]
|  | Three Months Ended |  |  |
|  | September 27, 2025 |  | September 28, 2024 |  |  |  |  |
| Income tax provision | $ | 1.0 |  |  | $ | 3.2 |  |  |  |  |  |

[0001628280-25-049073:mdna:78]
We recorded a tax provision of $1.0 million and $3.2 for the three months ended September 27, 2025 and September 28, 2024, respectively. Our tax provision for the three months ended September 27, 2025 includes a discrete tax benefit of 0.6 million primarily related to the tax benefit from a windfall in connection with stock-based compensation vested during the quarter and foreign return to provision differences, partially offset by the tax expense from currency re-measurement of certain tax related accounts. Our tax provision for the three months ended September 28, 2024 is primarily related to the tax expense associated with interest on uncertain tax positions, partially offset by the tax benefit from currency re-measurements.

[0001628280-25-049073:mdna:79]
Our estimated effective tax rate for the three months ended September 27, 2025 differs from the 21% U.S. statutory rate primarily due to the income tax expense from foreign income inclusions in the U.S., current year valuation allowance change, and non-deductible stock-based compensation, partially offset by the income tax benefit from foreign rate differential,and various income tax credits.

[0001628280-25-049073:mdna:80]
We regularly assess our ability to realize our deferred tax assets on a quarterly basis and will establish a valuation allowance if it is more-likely-than-not that some portion of the deferred tax assets will not be realized. As of September 27, 2025, we maintain a full valuation allowance on U.S. federal and state and certain foreign deferred tax assets. We will continue to assess the need for a valuation allowance against our remaining deferred tax assets and may increase or decrease our valuation allowance materially in the future.

[0001628280-25-049073:mdna:81]
[same as prior period, unchanged from 0001628280-25-022788:mdna:92]

[0001628280-25-049073:mdna:82]
[same as prior period, unchanged from 0001628280-25-022788:mdna:93]

[0001628280-25-049073:mdna:83]
[same as prior period, unchanged from 0001628280-25-022788:mdna:94]

[0001628280-25-049073:mdna:84]
[same as prior period, unchanged from 0001628280-25-022788:mdna:95]

[0001628280-25-049073:mdna:85]
As of September 27, 2025 and June 28, 2025, our cash and cash equivalents were $772.9 million and $520.7 million, respectively. As of September 27, 2025 and June 28, 2025, our short-term investments of $348.9 million and $356.4 million, respectively, were all held in the United States. Cash equivalents and short-term investments are primarily comprised of money market funds, treasuries, agencies, high quality investment grade fixed income securities, certificates of deposit and commercial paper. Our investment policy and strategy provide for diversification of investments and is focused on the preservation of capital and supporting our liquidity requirements.

[0001628280-25-049073:mdna:86]
The total amount of cash held by the non-United States entities as of September 27, 2025 and June 28, 2025 was $343.8 million and $398.3 million, respectively, which was primarily held by entities incorporated in the United Kingdom, Japan, Hong Kong, China, Switzerland, China and Thailand. Although cash currently held in the United States, as well as cash generated in the United States from future operations, is expected to cover our normal operating requirements, a substantial amount of additional cash could be required for other purposes, such as capital expenditures to support our business and growth, including costs associated with increasing internal manufacturing capabilities, strategic transactions and partnerships, and future acquisitions.

[0001628280-25-049073:mdna:87]
Our intent is to indefinitely reinvest funds held outside the United States. Except for the funds held in the Cayman Islands, the British Virgin Islands, Hong Kong and Japan, our current plans do not demonstrate a need to repatriate them to fund our domestic operations. However, if in the future, we encounter a significant need for liquidity domestically or at a particular location that we cannot fulfill through borrowings, equity offerings, or other internal or external sources, or the cost to bring back the money is not significant from a tax perspective, we may determine that cash repatriations are necessary or desirable. Repatriation could result in additional material taxes. These factors may cause us to have an overall tax rate higher than other companies or higher than our tax rates in the past. Additionally, if conditions warrant, we may seek to obtain additional financing through debt or equity sources. To the extent we issue additional shares, it may create dilution to our existing stockholders. However, any such financing may not be available on terms favorable to us or may not be available at all.

[0001628280-25-049073:mdna:88]
Beginning in fiscal year 2023, the Tax Cuts and Jobs Act of 2017 requires taxpayers to capitalize research and development expenditures and amortize domestic expenditures over five years and foreign expenditures over fifteen years. The One Big Beautiful Bill Act (“OBBBA”) enacted in July 2025 eliminates capitalization of domestic research and development expenditures for taxable years beginning on or after January 1, 2025, but retains the requirement to amortize foreign research and development expenditures over 15 years. In addition, the OBBBA permits all taxpayers who paid or incurred domestic research and development expenses in tax years beginning on or after January 1, 2022 and before January 1, 2025 to elect to deduct any remaining unamortized amount over a one-year period or ratably over a two-year period (at the taxpayer’s election), accelerating the benefit of such expenses. We have evaluated these changes in the first quarter of fiscal year 2026, and the impact to our tax provision for this period is not material.

[0001628280-25-049073:mdna:89]
[same as prior period, unchanged from 0001628280-25-022788:mdna:99]

[0001628280-25-049073:mdna:90]
We believe that our cash and cash equivalents as of September 27, 2025 and cash flows from our operating activities will be sufficient to meet our liquidity and capital spending requirements for at least the next 12 months.

[0001628280-25-049073:mdna:91]
[same as prior period, unchanged from 0001628280-25-022788:mdna:101]

[0001628280-25-049073:mdna:92]
•global economic conditions which affect demand for our products and services and impact the financial stability of our suppliers and customers, including the impact of uncertainty in the banking and financial services industries;

[0001628280-25-049073:mdna:93]
[same as prior period, unchanged from 0001628280-25-022788:mdna:103]

[0001628280-25-049073:mdna:94]
[same as prior period, unchanged from 0001628280-25-022788:mdna:104]

[0001628280-25-049073:mdna:95]
[same as prior period, unchanged from 0001628280-25-022788:mdna:105]

[0001628280-25-049073:mdna:96]
[same as prior period, unchanged from 0001628280-25-022788:mdna:106]

[0001628280-25-049073:mdna:97]
[same as prior period, unchanged from 0001628280-25-022788:mdna:107]

[0001628280-25-049073:mdna:98]
[same as prior period, unchanged from 0001628280-25-022788:mdna:108]

[0001628280-25-049073:mdna:99]
[same as prior period, unchanged from 0001628280-25-022788:mdna:109]

[0001628280-25-049073:mdna:100]
[same as prior period, unchanged from 0001628280-25-022788:mdna:110]

[0001628280-25-049073:mdna:101]
[same as prior period, unchanged from 0001628280-25-022788:mdna:111]

[0001628280-25-049073:mdna:102]
[same as prior period, unchanged from 0001628280-25-022788:mdna:112]

[0001628280-25-049073:mdna:103]
[same as prior period, unchanged from 0001628280-25-022788:mdna:113]

[0001628280-25-049073:mdna:104]
•acquisitions or strategic transactions; and

[0001628280-25-049073:mdna:105]
•the settlement of any conversion or redemption of our convertible notes in cash.

[0001628280-25-049073:mdna:106]
[same as prior period, unchanged from 0001628280-25-022788:mdna:118]

[0001628280-25-049073:mdna:107]
The following table summarizes our contractual obligations as of September 27, 2025, and the effect such obligations are expected to have on our liquidity and cash flow (in millions):

[0001628280-25-049073:mdna:108]
|  | Payments Due |
|  | Total |  | Less Than 1 Year |  | More Than 1 Year |  |  |  |  |
| Contractual Obligations |  |  |  |  |  |  |  |  |  |
| Asset retirement obligations | $ | 7.1 |  |  | $ | — |  |  | $ | 7.1 |  |  |  |  |  |
| Operating lease liabilities, including imputed interest (1) | 39.4 |  |  | 13.6 |  |  | 25.8 |  |  |  |  |  |
| Pension plan contributions (2) | 2.0 |  |  | 2.0 |  |  | — |  |  |  |  |  |
| Purchase obligations (3) | 875.3 |  |  | 834.5 |  |  | 40.8 |  |  |  |  |  |
| Term loans - principal (5) | 62.2 |  |  | 10.3 |  |  | 51.9 |  |  |  |  |  |
| Term loans - interest (5) | 1.5 |  |  | 0.5 |  |  | 1.0 |  |  |  |  |  |
| Convertible notes - principal (4) | 3,198.6 |  |  | — |  |  | 3,198.6 |  |  |  |  |  |
| Convertible notes - interest (4) | 88.8 |  |  | 21.2 |  |  | 67.6 |  |  |  |  |  |
| Total | $ | 4,274.9 |  |  | $ | 882.1 |  |  | $ | 3,392.8 |  |  |  |  |  |

[0001628280-25-049073:mdna:109]
(1) The amounts of operating lease liabilities do not include any sublease income amounts nor do they include payments for short-term leases or variable lease payments. As of September 27, 2025, we expect to receive sublease income of approximately $2.1 million over the sublease periods.

[0001628280-25-049073:mdna:110]
[same as prior period, unchanged from 0001628280-25-022788:mdna:122]

[0001628280-25-049073:mdna:111]
(3) Purchase obligations represent legally binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Refer to “Note 13. Commitments and Contingencies” in the notes to condensed consolidated financial statements.

[0001628280-25-049073:mdna:112]
(4) The amounts related to convertible notes include principal and interest on our 0.50% Convertible Senior Notes due 2026 (the “2026 Notes”), principal and interest on our 0.50% Convertible Senior Notes due 2028 (the “2028 Notes”), principal and interest on our 1.50% Convertible Senior Notes due 2029 (the “2029 Notes”), and principal and interest on our 0.375% Convertible Senior Notes due 2032 (the “2032 Notes”). The 2026 Notes have a maturity date of December 15, 2026, the 2028 Notes have a maturity date of June 15, 2028, the 2029 Notes have a maturity date of December 15, 2029, and the 2032 Notes have a maturity date of March 15, 2032. The principal balances of our convertible notes are reflected in the payment periods in the table above based on their respective contractual maturities, which may be accelerated if the holders elect to convert the notes prior to maturity. As the principal amounts of all of our outstanding convertible notes must be settled in cash, the actual cash settlement may be higher if we decide to settle the conversion value in excess of the principal amounts in cash, rather than issuing shares of common stock.

[0001628280-25-049073:mdna:113]
[same as prior period, unchanged from 0001628280-25-022788:mdna:125]

[0001628280-25-049073:mdna:114]
[same as prior period, unchanged from 0001628280-25-022788:mdna:126]

[0001628280-25-049073:mdna:115]
[same as prior period, unchanged from 0001628280-25-022788:mdna:127]

[0001628280-25-049073:mdna:116]
As of September 27, 2025, the net carrying amount of our 2032 Notes of $1,254.6 million (principal balance of $1,265.0 million maturing in 2032) is presented in non-current liabilities in our condensed consolidated balance sheets. If the closing price of our stock exceeds $244.10 (or 130% of the conversion price of $187.77) for 20 of the last 30 trading days of any future quarter, our 2032 Notes would become convertible at the option of the holders during the subsequent fiscal quarter and the debt would be reclassified to current liabilities in our consolidated balance sheets.

[0001628280-25-049073:mdna:117]
As of September 27, 2025, the net carrying amount of our 2029 Notes of $600.4 million (principal balance of $603.7 million maturing in 2029) is presented in current liabilities in our condensed consolidated balance sheets. If the closing price of our stock exceeds $90.40 (or 130% of the conversion price of $69.54) for 20 of the last 30 trading days of any future quarter, our 2029 Notes would become convertible at the option of the holders during the subsequent fiscal quarter, which was the case as of the end of the first quarter of fiscal year 2026, and therefore, the debt was reclassified to current liabilities in our consolidated balance sheets.

[0001628280-25-049073:mdna:118]
As of September 27, 2025, the net carrying amount of our 2028 Notes of $858.0 million (which have an aggregate principal amount of $861.0 million outstanding that matures in 2028) is presented in non-current liabilities in our condensed consolidated balance sheets. If the closing price of our stock exceeds $170.34 (or 130% of the conversion price of $131.03) for 20 of the last 30 trading days of any future fiscal quarter, our 2028 Notes would become convertible at the option of the holders during the subsequent fiscal quarter and the debt would be reclassified to current liabilities in our condensed consolidated balance sheets.

[0001628280-25-049073:mdna:119]
As of September 27, 2025, the net carrying amount of our 2026 Notes of $468.3 million (which have an aggregate principal amount of $468.9 million outstanding that matures in 2026) is presented in non-current liabilities in our condensed consolidated balance sheets. If the closing price of our stock exceeds $129.08 (or 130% of the conversion price of $99.29) for 20 of the last 30 trading days of any future fiscal quarter, our 2026 Notes would become convertible at the option of the holders during the subsequent fiscal quarter, which was the case as of the end of the first quarter of fiscal year 2026, and therefore, the debt was reclassified to current liabilities in our condensed consolidated balance sheets.

[0001628280-25-049073:mdna:120]
As of September 27, 2025, the Company had $38.2 million in principal amount outstanding on our SMBC term loan, of which the short-term portion of $4.3 million is recorded as current liabilities while the long-term portion of $33.9 million is recorded as long-term debt in the Company’s condensed consolidated balance sheets.

[0001628280-25-049073:mdna:121]
As of September 27, 2025, the Company had $24.0 million in principal amount outstanding on our Mizuho term loan, of which the short-term portion of $6.0 million is recorded as current liabilities while the long-term portion of $18.0 million is recorded as long-term debt in the Company’s condensed consolidated balance sheets.

[0001628280-25-049073:mdna:122]
[same as prior period, unchanged from 0001628280-25-022788:mdna:136]

[0001628280-25-049073:mdna:123]
As of September 27, 2025 and June 28, 2025, our other non-current liabilities include unrecognized tax benefit for uncertain tax positions of $57.0 million and $55.6 million, respectively. We are unable to reliably estimate the timing of future payments related to uncertain tax positions.

[0001628280-25-049073:mdna:124]
[same as prior period, unchanged from 0001628280-25-022788:mdna:138]

[0001628280-25-049073:mdna:125]
Our balance of cash and cash equivalents increased by $252.2 million from $520.7 million as of June 28, 2025 to $772.9 million as of September 27, 2025. The increase in cash and cash equivalents during the three months ended September 27, 2025 was due to cash from operating activities of $57.9 million and cash from financing activities of $262.1 million, offset by cash used in investing activities of $67.8 million.

[0001628280-25-049073:mdna:126]
[same as prior period, unchanged from 0001628280-25-022788:mdna:140]

[0001628280-25-049073:mdna:127]
Cash from operating activities was $57.9 million during the three months ended September 27, 2025, which reflects a net income of $4.2 million and non-cash items of $108.3 million, offset by changes in operating assets and liabilities of $54.6 million. Changes in operating assets and liabilities were primarily driven by an increase in accounts payable of $28.8 million primarily due to higher inventory purchases and capital expenditures, an increase of $11.4 million in accrued payroll and related expenses mainly driven by our accrual on employee cash bonuses, outstanding payroll taxes related to stock-based compensation and ESPP contribution, and an increase of $24.8 million in accrued expenses and other current and non-current liabilities driven by contractual liabilities, accrued interest on convertible notes and provision for non-cancellable commitments, offset by an increase in accounts receivable of $56.9 million mainly driven by higher revenue, and an increase of $57.5 million in inventories driven by inventory builds to support market demand.

[0001628280-25-049073:mdna:128]
Cash from operating activities was $39.6 million during the three months ended September 28, 2024, which reflects a net loss of $82.4 million, offset by non-cash items of $112.1 million and changes in operating assets and liabilities of $9.9 million. Changes in operating assets and liabilities were primarily driven by an increase in accounts payable of $32.6 million primarily due to higher inventory purchases and capital expenditures and an increase in income tax liabilities of $7.2 million primarily due to income tax provision for the three months ended September 28, 2024, offset by an increase of $16.6 million in prepayments and other current and non-current assets related mainly to value-added-tax receivables driven by higher recent capital expenditures and inventory purchases, and a decrease of $9.7 million in accrued expenses and other current and non-current liabilities primarily due to payment of the net settlement amount of the Oclaro merger litigation.

[0001628280-25-049073:mdna:129]
[same as prior period, unchanged from 0001628280-25-022788:mdna:143]

[0001628280-25-049073:mdna:130]
Cash used in investing activities of $67.8 million during the three months ended September 27, 2025 was attributable to capital expenditures of $76.2 million, offset by net proceeds from sales or maturities of short-term investments of $8.4 million.

[0001628280-25-049073:mdna:131]
Cash used in investing activities of $47.1 million during the three months ended September 28, 2024 was attributable to capital expenditures of $74.1 million, offset by net proceeds from sales or maturities of short-term investments of $26.8 million and proceeds from sales of property and equipment of $0.2 million.

[0001628280-25-049073:mdna:132]
[same as prior period, unchanged from 0001628280-25-022788:mdna:146]

[0001628280-25-049073:mdna:133]
Cash from financing activities of $262.1 million during the three months ended September 27, 2025 was attributable to $1,255.7 million of net proceeds from the issuance of 2032 Notes and $1.5 million of proceeds from employee stock plans, offset by payments for partial repurchase of the 2026 Notes of approximately $843.1 million, payments for the 2032 Capped Call Options of $102.0 million, tax payments related to net share settlement of restricted stock of $47.4 million, and $2.6 million of principal payments on term loans.

[0001628280-25-049073:mdna:134]
Cash used in financing activities of $60.0 million during the three months ended September 28, 2024 was attributable to $76.5 million of proceeds from SMBC and Mizuho term loans and $0.9 million of proceeds from the exercise of stock options, offset by tax payments related to net share settlement of restricted stock of $16.0 million, payment for an intangible asset acquisition holdback of $1.0 million and $0.4 million of principal payments on term loans.
