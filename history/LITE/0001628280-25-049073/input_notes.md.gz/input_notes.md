# LITE notes — 0001628280-25-049073


## us-gaap:SubsequentEventsTextBlock

[0001628280-25-049073:notes:1]
Note 16. Subsequent Event

[0001628280-25-049073:notes:2]
TBD.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001628280-25-049073:notes:3]
[same as prior period, unchanged from 0001628280-25-022788:notes:1]

[0001628280-25-049073:notes:4]
[same as prior period, unchanged from 0001628280-25-022788:notes:2]

[0001628280-25-049073:notes:5]
Lumentum Holdings Inc. (“we,” “us,” “our”, “Lumentum” or the “Company”) is a leading provider of optical and photonic products and is recognized as an industry leader based on revenue and market share. Our products are essential to a range of cloud, artificial intelligence and machine learning (“AI/ML”), telecommunications, consumer, and industrial end-market applications. The Company operates in one reportable segment.

[0001628280-25-049073:notes:6]
We disaggregate revenue by type of product, which are Components and Systems, and by geography. A Components product is defined as one of the individual building blocks that goes into creating a larger solution. It is typically not a complete product on its own but rather a specialized element that enables system functionality. This includes semiconductor laser chips, laser sub-assemblies, line subsystems and wavelength management systems. These are supplied to customers who then integrate them into their own full system solutions. Components represent foundational parts that support or enable that system’s operation and include a comprehensive portfolio of optical and photonic chips, components, laser light sources that are integrated into smartphones, subsystems supplied to cloud data center operators, AI/ML infrastructure providers, and network equipment manufacturer customers who are building cloud data center and network infrastructures.

[0001628280-25-049073:notes:7]
A Systems product is defined as a complete, stand-alone product that delivers full functionality to the end customer. It is typically self-contained and ready to operate within a customer’s network or application environment. This includes optical modules, optical circuit switches, and industrial lasers such as short-pulse solid-state lasers and kilowatt-class fiber lasers. These products integrate multiple technologies and subsystems into a finished solution that directly addresses a customer’s needs. A system represents the end-product that can be deployed and used independently.

[0001628280-25-049073:notes:8]
Our products enable high-capacity optical links for cloud computing, AI/ML workloads, and data center interconnect (“DCI”) applications, as well as for communications service provider networks. Our offerings support access (local), metro (intracity), long-haul (intercity and global), and submarine (undersea) network infrastructure. Our products serve enterprise network infrastructure needs, including storage area networks (“SANs”), local area networks (“LANs”), and wide area networks (“WANs”). Demand for our products is fueled by the ongoing expansion of network capacity required to support cloud services, AI/ML processing, streaming video, video conferencing, wireless and mobile connectivity, and the internet of things (“IoT”). In addition, our industrial laser products are used for precision material processing across diverse industries, including semiconductor and microelectronics fabrication, electric vehicle and battery production, metal cutting and welding, and advanced manufacturing that emphasize greater manufacturing precision, flexibility, and sustainability.

[0001628280-25-049073:notes:9]
[same as prior period, unchanged from 0001628280-25-022788:notes:6]

[0001628280-25-049073:notes:10]
We have prepared the condensed consolidated financial statements in accordance with U.S. generally accepted accounting principles (“GAAP”), which requires management to make estimates and assumptions that affect the amounts reported in our condensed consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates. Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. These policies are inventory valuation, revenue recognition, income taxes, goodwill and business combinations.

[0001628280-25-049073:notes:11]
Prior to fiscal year 2026, we operated in two reportable segments consisting of Cloud & Networking and Industrial Tech. During the first quarter of fiscal year 2026, the Company implemented a re-organization, under which it will be managed as a single, integrated enterprise, with a unified management team overseeing operations across the entire company, rather than through discrete operating segments. The chief operating decision maker (“CODM”) is the Company’s Chief Executive Officer, who reviews financial information presented as a single enterprise for purposes of allocating resources and evaluating financial performance. Accordingly, we determined we operate in a single reporting segment. Comparative prior period segment information has been updated to reflect the new segment structure and measures. The changes in our operating segments had no impact on our previously reported consolidated results of operations, financial position or cash flows. Refer to “Note 14. Operating Segments and Geographic Information” for more details.

[0001628280-25-049073:notes:12]
Our business and operating results depend significantly on general market and economic conditions. The current global macroeconomic environment is volatile and continues to be adversely impacted by many factors including inflation, a dynamic supply chain and demand environment, changes in trade policies, including heightened, scheduled, or threatened tariffs, trade restrictions including for certain rare earth minerals, and signs of a fluctuating macroeconomic environment.

[0001628280-25-049073:notes:13]
The Company is actively monitoring and assessing the ongoing global trade environment, particularly with respect to recent changes in trade restrictions and tariff regulations. We have assessed the potential impacts of heightened restrictions and tariffs on our allowance for credit losses, the carrying value of our goodwill and other long-lived assets, inventory valuation, and revenue recognition.  While we have determined there was not a material impact to our condensed consolidated financial statements as of September 27, 2025 and for the quarter ended September 27, 2025, import tariffs implemented by the U.S. and other countries, as currently in effect and/or proposed, could have a material impact on our results for the remainder of fiscal year 2026 and in the future. The impact of tariffs is dependent upon negotiations with customers and suppliers and other mitigation efforts and potential further changes in global trade policies, including higher tariffs in the U.S. or other countries.

[0001628280-25-049073:notes:14]
[same as prior period, unchanged from 0001628280-25-022788:notes:12]

[0001628280-25-049073:notes:15]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Every fifth or sixth fiscal year will have a 53-week period. The additional week in a 53-week year is added to the third quarter, making such quarter consist of 14 weeks. Our fiscal 2026 is a 52-week year ending on June 27, 2026, with the quarter ended September 27, 2025 being a 13-week quarterly period. Our fiscal 2025 was a 52-week year that ended on June 28, 2025, with the quarter ended September 28, 2024 being a 13-week quarterly period.

[0001628280-25-049073:notes:16]
[same as prior period, unchanged from 0001628280-25-022788:notes:14]

[0001628280-25-049073:notes:17]
The condensed consolidated financial statements are prepared in accordance with GAAP and includes the accounts of Lumentum Holdings Inc. and its wholly owned subsidiaries. All inter-company transactions and balances are eliminated in consolidation.

[0001628280-25-049073:notes:18]
[same as prior period, unchanged from 0001628280-25-022788:notes:16]

[0001628280-25-049073:notes:19]
The condensed consolidated financial statements and accompanying notes should be read in conjunction with the audited consolidated financial statements and accompanying notes included in our Annual Report on Form 10-K for the fiscal year ended June 28, 2025. There were no significant changes to our accounting policies during the three months ended September 27, 2025, except as noted below:

[0001628280-25-049073:notes:20]
Income Taxes

[0001628280-25-049073:notes:21]
In accordance with the authoritative guidance on accounting for income taxes, we recognize income taxes using an asset and liability approach. This approach requires the recognition of taxes payable or refundable for the current year and deferred tax liabilities and assets for the future tax consequences of events that have been recognized in our consolidated financial statements or tax returns. The measurement of current and deferred taxes is based on provisions of the enacted tax law, and the effects of future changes in tax laws or rates are not anticipated.

[0001628280-25-049073:notes:22]
The authoritative guidance provides for recognition of deferred tax assets if the realization of such deferred tax assets is more likely than not to occur based on an evaluation of both positive and negative evidence and the relative weight of the evidence. We consider future growth, forecasted earnings, future taxable income, the mix of earnings in the jurisdictions in which we operate, historical earnings, taxable income in prior years, if carry-back is permitted under the law, and prudent and feasible tax planning strategies in determining the need for a valuation allowance.

[0001628280-25-049073:notes:23]
In the event we determine that we would not be able to realize all or part of our net deferred tax assets in the future, an adjustment to the deferred tax assets valuation allowance would be charged to earnings in the period in which we make such a determination, or goodwill would be adjusted at our final determination of the valuation allowance related to an acquisition within the measurement period. Conversely, if we later determine that it is more likely than not that all or a portion of the net deferred tax assets will be realized, we would reverse the applicable portion of the previously established valuation allowance. A release of valuation allowance decreases income tax expense in the period of release, increases net income, and reduces our effective tax rate. Such releases may be material to our financial statements depending on the size of the deferred tax assets involved.

[0001628280-25-049073:notes:24]
In the fourth quarter of fiscal 2025, we released $153.1 million of valuation allowances on our UK deferred tax assets after we considered all available positive and negative evidence related to our UK subsidiary.  We analyzed the UK subsidiary’s historical operating results, projected future taxable income, tax planning strategies, and reversals of deferred tax liabilities, and determined that the weight of available objectively verifiable positive evidence supported the realizability of the UK deferred tax assets. In weighing the available evidence, more weight was placed upon our forecasts of future taxable income than on the history of pre-tax losses as such losses were generated under our prior UK business operating model which will no longer be in effect beginning with fiscal year 2026, and the guarantee of a positive operating margin as we effectuated an internal restructuring at the end of fiscal year 2025. Further, the most significant deferred tax asset in the UK is the net operating loss carryforward. Under UK tax law, net operating losses may be carried forward indefinitely, and we have considered the indefinite carryforward period to be positive evidence.

[0001628280-25-049073:notes:25]
We are subject to income tax audits by the respective tax authorities of the jurisdictions in which we operate. The determination of our income tax liabilities in each of these jurisdictions requires the interpretation and application of complex, and sometimes uncertain, tax laws and regulations. The authoritative guidance on accounting for income taxes prescribes both recognition and measurement criteria that must be met for the benefit of a tax position to be recognized in the financial statements. If a tax position taken, or expected to be taken, in a tax return does not meet such recognition or measurement criteria, an unrecognized tax benefit liability is recorded. If we ultimately determine that an unrecognized tax benefit liability is no longer necessary, we reverse the liability and recognize a tax benefit in the period in which it is determined that the unrecognized tax benefit liability is no longer necessary.

[0001628280-25-049073:notes:26]
Our income tax provision is highly dependent on the geographic distribution of our worldwide earnings or losses, tax laws and regulations in various jurisdictions, tax incentives, the availability of tax credits and loss carryforwards, and the effectiveness of our tax planning strategies. The application of tax laws and regulations is subject to legal and factual interpretation, judgment and uncertainty. Tax laws themselves are subject to change as a result of changes in fiscal policy, changes in legislation, and the evolution of regulations and court rulings and tax audits.

[0001628280-25-049073:notes:27]
The recognition and measurement of current taxes payable or refundable and deferred tax assets and liabilities requires that we make certain estimates and judgments. Changes to these estimates, including changes in judgment regarding the realizability of deferred tax assets and the need for or release of valuation allowances, may have a material impact on our tax provision, net income, and effective tax rate in a future period.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001628280-25-049073:notes:28]
Note 2. Recently Issued Accounting Pronouncements

[0001628280-25-049073:notes:29]
Accounting Pronouncements Recently Adopted

[0001628280-25-049073:notes:30]
In November 2024, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) No. 2024-04, Debt with Conversion and Other Options (Subtopic 470-20): Induced Conversions of Convertible Debt Instruments, which clarifies the requirements related to accounting for the settlement of a debt as an induced conversion. ASU No. 2024-04 is intended to improve the relevance and consistency in application of the induced conversion guidance in Subtopic 470-20 for convertible debt instruments with cash conversion features and debt instruments that are not currently convertible, when the the face value of the debt is settled in cash. We have early adopted ASU No. 2024-04 in the first quarter of fiscal year 2026 and applied the accounting in the partial repurchase of our 2026 Notes in September 2026. Refer to “Note 8. Debt” for detailed discussion of this transaction.

[0001628280-25-049073:notes:31]
In December 2023, the FASB issued ASU No. 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures, which requires disaggregated information about a reporting entity’s effective tax rate reconciliation as well as information on income tax paid. We have adopted ASU No. 2023-09 beginning in fiscal year 2026; however, it has no material impact on our condensed consolidated financial statements and disclosures for the first quarter of fiscal year 2026.

[0001628280-25-049073:notes:32]
In March 2024, the FASB issued ASU No. 2024-02: Codification Improvements - Amendments to Remove References to the Concepts Statements, which contains amendments to the Codification that remove references to various FASB Concepts Statements. We have adopted ASU No. 2024-02 in the first quarter of fiscal year 2026 and it did not have a material impact on our condensed consolidated financial statements and disclosures as a result of the adoption.

[0001628280-25-049073:notes:33]
Accounting Pronouncements Not Yet Effective

[0001628280-25-049073:notes:34]
In September 2025, the FASB issued ASU No. 2025-06, Intangibles—Goodwill and Other—Internal-Use Software (Sub-topic 350-40), Targeted Improvements to the Accounting for Internal-Use Software, which amends certain aspects of the accounting for and disclosure of software costs under ASC 350-40. The amendments also supersede the guidance on Web site development costs in ASC 350-50 and relocate that guidance, along with the recognition requirements for development costs specific to Web sites, to ASC 350-40. ASU No. 2025-06 is effective for fiscal years beginning after December 15, 2027, with early adoption permitted. We plan to adopt ASU No. 2025-06 in the first quarter of fiscal year 2029. We are currently evaluating the impact of this ASU on our financial statements and disclosures.

[0001628280-25-049073:notes:35]
In July 2025, the FASB issued ASU No. 2025-05, Financial Instruments - Credit Losses (Topic 326), Measurement of Credit Losses for Accounts Receivable and Contract Assets, which amends ASC 326-20 to provide a practical expedient for all entities, related to the estimation of expected credit losses for current accounts receivable and current contract assets that arise from transactions accounted for under ASC 606. ASU No. 2025-05 is effective for fiscal years beginning after December 15, 2025, with early adoption permitted. We plan to adopt ASU No. 2025-05 in the first quarter of fiscal year 2027. We are currently evaluating the impact of this ASU on our financial statements and disclosures.

[0001628280-25-049073:notes:36]
In May 2025, the FASB issued ASU No. 2025-04, Compensation - Stock Compensation (Topic 718) and Revenue from Contracts with Customers (Topic 606), which is intended to reduce diversity in practice and improve existing guidance, primarily by revising the definition of a “performance condition” and eliminating forfeiture policy election for service conditions associated with share-based consideration payable to a customer. In addition, ASU No. 2025-04 clarifies that the guidance in ASC 606 on the variable consideration constraints does not apply to share-based consideration payable to a customer regardless of whether an award’s grant date has occurred (as determined under ASC 718). ASU No. 2025-04 is effective for fiscal years beginning after December 15, 2026, with early adoption permitted. We plan to adopt ASU No. 2025-04 in the first quarter of fiscal year 2028. We are currently evaluating the impact of this ASU on our financial statements and disclosures.

[0001628280-25-049073:notes:37]
In May 2025, the FASB issued ASU No. 2025-03, Business Combinations (Topic 805) and Consolidation (Topic 810), which revises the guidance in ASC 805 to clarify that, in determining the accounting acquirer in a business combination that is effected primarily by exchanging equity interests in which a VIE is acquired, an entity would be required to consider the factors in ASC 805-10-55-12 through 55-15. Previously, the accounting acquirer in such transactions was always the primarily beneficiary. ASU No. 2025-03 is effective for fiscal years beginning after December 15, 2026, with early adoption permitted. We plan to adopt ASU No. 2025-04 in the first quarter of fiscal year 2028. We are currently evaluating the impact of this ASU on our financial statements and disclosures.

[0001628280-25-049073:notes:38]
In November 2024, the FASB issued ASU No. 2024-03, Reporting Comprehensive Income - Expense Disaggregation Disclosures (Subtopic 220-40), which requires disaggregation of certain expense captions into specified categories in disclosures within the footnotes to the financial statements. In January 2025, the FASB issued ASU No. 2025-01, which revises the effective date of ASU No. 2024-03, to clarify that all public business entities are required to adopt the guidance in annual reporting periods beginning after December 15, 2026, and interim periods within annual reporting periods beginning after December 15, 2027, with early adoption permitted.  We plan to adopt ASU No. 2024-04 in the first quarter of fiscal year 2028. We are currently evaluating the impact of this ASU on our financial statements and disclosures.


## us-gaap:EarningsPerShareTextBlock

[0001628280-25-049073:notes:39]
[same as prior period, unchanged from 0001628280-25-022788:notes:24]

[0001628280-25-049073:notes:40]
The following table sets forth the computation of basic and diluted net income (loss) per share (in millions, except per share data):

[0001628280-25-049073:notes:41]
|  | Three Months Ended |  |  |
|  | September 27, 2025 |  | September 28, 2024 |  |  |  |  |
| Numerator: |  |  |  |  |  |  |  |
| Net income (loss) - basic and diluted | $ | 4.2 |  |  | $ | (82.4) |  |  |  |  |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted average common shares outstanding - basic | 70.3 |  |  | 68.3 |  |  |  |  |  |
| Effect of dilutive securities from ESPP | 0.1 |  |  | — |  |  |  |  |  |
| Effect of dilutive securities from stock options | 0.4 |  |  |  |  |  |  |  |
| Effect of dilutive securities from RSUs and PSUs | 1.9 |  |  | — |  |  |  |  |  |
| Shares issuable assuming conversion of the convertible notes | 5.6 |  |  | — |  |  |  |  |  |
| Weighted average common shares outstanding - diluted | 78.3 |  |  | 68.3 |  |  |  |  |  |
| Net income (loss) per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.06 |  |  | $ | (1.21) |  |  |  |  |  |
| Diluted | $ | 0.05 |  |  | $ | (1.21) |  |  |  |  |  |

[0001628280-25-049073:notes:42]
Potentially dilutive common shares result from the assumed exercise of outstanding stock options, assumed vesting of equity awards, and assumed issuance of stock under the ESPP, all using the treasury stock method.

[0001628280-25-049073:notes:43]
Potentially dilutive common shares issuable upon conversion of our outstanding convertible notes are determined using the if-converted method.

[0001628280-25-049073:notes:44]
There were no anti-dilutive shares excluded from the calculation of diluted net income per share during the three months ended September 27, 2025. Anti-dilutive shares excluded from the calculation of diluted net loss per share for the three months ended September 28, 2024 include 4.8 million shares issuable under restricted stock units (“RSUs”) and performance stock units (“PSUs”), 0.1 million shares issuable under the Employee Stock Purchase Plan (the “ESPP”), and 1.0 million shares outstanding related to stock options. Refer to “Note 12. Equity.


## us-gaap:CashCashEquivalentsAndShortTermInvestmentsTextBlock

[0001628280-25-049073:notes:45]
Note 4. Cash, Cash Equivalents and Short-term Investments

[0001628280-25-049073:notes:46]
[same as prior period, unchanged from 0001628280-25-022788:notes:49]

[0001628280-25-049073:notes:47]
|  | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| September 27, 2025: |  |  |  |  |  |  |  |
| Cash | $ | 347.6 |  |  | $ | — |  |  | $ | — |  |  | $ | 347.6 |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Money market funds | 125.6 |  |  | — |  |  | — |  |  | 125.6 |  |
| U.S. Treasury securities | 299.7 |  |  | — |  |  | — |  |  | 299.7 |  |
| Total cash and cash equivalents | $ | 772.9 |  |  | $ | — |  |  | $ | — |  |  | $ | 772.9 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Commercial paper | 2.7 |  |  | — |  |  | — |  |  | 2.7 |  |
| Corporate debt securities | 205.1 |  |  | 0.6 |  |  | (0.1) |  |  | 205.6 |  |
| U.S. Agency securities | 77.1 |  |  | 0.1 |  |  | — |  |  | 77.2 |  |
| U.S. Treasury securities | 63.2 |  |  | 0.2 |  |  | — |  |  | 63.4 |  |
| Total short-term investments | $ | 348.1 |  |  | $ | 0.9 |  |  | $ | (0.1) |  |  | $ | 348.9 |  |
| June 28, 2025: |  |  |  |  |  |  |  |
| Cash | $ | 349.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 349.5 |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | 2.5 |  |  | — |  |  | — |  |  | 2.5 |  |
| Money market funds | 161.7 |  |  | — |  |  | — |  |  | 161.7 |  |
| U.S. Treasury securities | 7.0 |  |  | — |  |  | — |  |  | 7.0 |  |
| Total cash and cash equivalents | $ | 520.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 520.7 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Commercial paper | $ | 2.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 2.7 |  |
| Corporate debt securities | 210.9 |  |  | 0.3 |  |  | (0.1) |  |  | 211.1 |  |
| U.S. Agency securities | 67.6 |  |  | 0.1 |  |  | — |  |  | 67.7 |  |
| U.S. Treasury securities | 74.8 |  |  | 0.1 |  |  | — |  |  | 74.9 |  |
| Total short-term investments | $ | 356.0 |  |  | $ | 0.5 |  |  | $ | (0.1) |  |  | $ | 356.4 |  |

[0001628280-25-049073:notes:48]
[same as prior period, unchanged from 0001628280-25-022788:notes:51]

[0001628280-25-049073:notes:49]
We use the specific-identification method to determine any realized gains or losses from the sale of our short-term investments classified as available-for-sale. During the three months ended September 27, 2025 and September 28, 2024, we did not realize significant gains or losses on a gross level from the sale of our short-term investments classified as available-for-sale.

[0001628280-25-049073:notes:50]
During the three months ended September 27, 2025 and September 28, 2024, our other income, net was $4.2 million and $8.7 million, respectively, which includes interest and investment income on cash equivalents and short-term investments of $8.6 million and $9.4 million, respectively.

[0001628280-25-049073:notes:51]
As of September 27, 2025 and June 28, 2025, we recorded interest receivables of $4.9 million and $5.2 million, respectively, in prepayments and other current assets within the condensed consolidated balance sheets. We did not recognize an allowance for credit losses against interest receivables in any of the periods presented.

[0001628280-25-049073:notes:52]
[same as prior period, unchanged from 0001628280-25-022788:notes:56]

[0001628280-25-049073:notes:53]
|  | Continuous Loss Position for More Than 12 Months |  | Continuous Loss Position for Less Than 12 Months |  | Gross Unrealized Losses |  |  |  |  |  |  |  |  |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  |  |  |  |  |  |  |  |  |
| September 27, 2025: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | 16.0 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | 2.7 |  |  | — |  |  | — |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 32.5 |  |  | (0.1) |  |  | 3.0 |  |  | — |  |  | (0.1) |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 20.0 |  |  | — |  |  | — |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Total | $ | 71.2 |  |  | $ | (0.1) |  |  | $ | 3.0 |  |  | $ | — |  |  | $ | (0.1) |  |  |  |  |  |  |  |  |  |
| June 28, 2025: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | — |  |  | $ | — |  |  | $ | 24.5 |  |  | $ | — |  |  | $ | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | — |  |  | — |  |  | 5.2 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | — |  |  | — |  |  | 73.8 |  |  | (0.1) |  |  | (0.1) |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | — |  |  | — |  |  | 35.3 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Total | $ | — |  |  | $ | — |  |  | $ | 138.8 |  |  | $ | (0.1) |  |  | $ | (0.1) |  |  |  |  |  |  |  |  |  |

[0001628280-25-049073:notes:54]
[same as prior period, unchanged from 0001628280-25-022788:notes:58]

[0001628280-25-049073:notes:55]
|  | September 27, 2025 |  | June 28, 2025 |
|  | Amortized Cost |  | Fair Value |  | Amortized Cost |  | Fair Value |
| Due within 1 year | $ | 123.7 |  |  | $ | 123.9 |  |  | $ | 139.9 |  |  | $ | 140.0 |  |
| Due in 1 year to 5 years | 224.4 |  |  | 225.0 |  |  | 216.1 |  |  | 216.4 |  |
| Total | $ | 348.1 |  |  | $ | 348.9 |  |  | $ | 356.0 |  |  | $ | 356.4 |  |

[0001628280-25-049073:notes:56]
[same as prior period, unchanged from 0001628280-25-022788:notes:60]


## us-gaap:FairValueDisclosuresTextBlock

[0001628280-25-049073:notes:57]
Note 5. Fair Value Measurements

[0001628280-25-049073:notes:58]
[same as prior period, unchanged from 0001628280-25-022788:notes:62]

[0001628280-25-049073:notes:59]
[same as prior period, unchanged from 0001628280-25-022788:notes:63]

[0001628280-25-049073:notes:60]
[same as prior period, unchanged from 0001628280-25-022788:notes:64]

[0001628280-25-049073:notes:61]
[same as prior period, unchanged from 0001628280-25-022788:notes:65]

[0001628280-25-049073:notes:62]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| September 27, 2025: (1) |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Money market funds | $ | 125.6 |  |  | $ | — |  |  | $ | — |  |  | $ | 125.6 |  |
| U.S. Treasury securities | 299.7 |  |  | — |  |  | — |  |  | 299.7 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Commercial paper | — |  |  | 2.7 |  |  | — |  |  | 2.7 |  |
| Corporate debt securities | — |  |  | 205.6 |  |  | — |  |  | 205.6 |  |
| U.S. Agency securities | — |  |  | 77.2 |  |  | — |  |  | 77.2 |  |
| U.S. Treasury securities | 63.4 |  |  | — |  |  | — |  |  | 63.4 |  |
| Total assets | $ | 488.7 |  |  | $ | 285.5 |  |  | $ | — |  |  | $ | 774.2 |  |

[0001628280-25-049073:notes:63]
(1)  Excludes $347.6 million in cash held in our bank accounts as of September 27, 2025.

[0001628280-25-049073:notes:64]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| June 28, 2025 (1) |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | — |  |  | $ | 2.5 |  |  | $ | — |  |  | $ | 2.5 |  |
| Money market funds | 161.7 |  |  | — |  |  | — |  |  | 161.7 |  |
| U.S. Treasury securities | 7.0 |  |  | — |  |  | — |  |  | 7.0 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Commercial paper | — |  |  | 2.7 |  |  | — |  |  | 2.7 |  |
| Corporate debt securities | — |  |  | 211.1 |  |  | — |  |  | 211.1 |  |
| U.S. Agency securities | — |  |  | 67.7 |  |  | — |  |  | 67.7 |  |
| U.S. Treasury securities | 74.9 |  |  | — |  |  | — |  |  | 74.9 |  |
| Total assets | $ | 243.6 |  |  | $ | 284.0 |  |  | $ | — |  |  | $ | 527.6 |  |

[0001628280-25-049073:notes:65]
(1)  Excludes $349.5 million in cash held in our bank accounts as of June 28, 2025.

[0001628280-25-049073:notes:66]
[same as prior period, unchanged from 0001628280-25-022788:notes:70]

[0001628280-25-049073:notes:67]
We report our financial instruments at fair value with the exception of our convertible notes, refer to “Note 8. Debt”. The estimated fair value of the convertible notes was determined based on the trading price of the convertible notes as of the last day of trading for the period. We consider the fair value of the convertible notes to be a Level 2 measurement as they are not actively traded in markets.

[0001628280-25-049073:notes:68]
[same as prior period, unchanged from 0001628280-25-022788:notes:72]

[0001628280-25-049073:notes:69]
|  | September 27, 2025 |  | June 28, 2025 |
|  | Carrying Amount |  | Estimated Fair Value |  | Carrying Amount |  | Estimated Fair Value |
| 2032 Notes | $ | 1,254.6 |  |  | $ | 1,444.3 |  |  | $ | — |  |  | $ | — |  |
| 2029 Notes | 600.4 |  |  | 1,442.8 |  |  | 600.2 |  |  | 925.5 |  |
| 2028 Notes | 858.0 |  |  | 1,195.1 |  |  | 857.7 |  |  | 890.2 |  |
| 2026 Notes | 468.3 |  |  | 782.3 |  |  | 1,048.3 |  |  | 1,233.3 |  |
|  | $ | 3,181.3 |  |  | $ | 4,864.5 |  |  | $ | 2,506.2 |  |  | $ | 3,049.0 |  |

[0001628280-25-049073:notes:70]
As of September 27, 2025, the carrying amount of our term loans is not significantly different from its fair value.

[0001628280-25-049073:notes:71]
[same as prior period, unchanged from 0001628280-25-022788:notes:74]

[0001628280-25-049073:notes:72]
[same as prior period, unchanged from 0001628280-25-022788:notes:75]

[0001628280-25-049073:notes:73]
Management utilizes various valuation methods, including an income approach, a market approach and a cost approach, to estimate the fair value of intangibles and other long-lived assets. During the annual impairment testing performed in the fourth quarter of fiscal 2025, we concluded that there was no impairment of our intangible and other long-lived assets. We review our intangible and other long-lived assets for impairment at least annually in the fourth quarter of each fiscal year, absent any interim indicators of impairment. There were no indicators of impairment during the three months ended September 27, 2025.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001628280-25-049073:notes:74]
Note 6. Balance Sheet Details

[0001628280-25-049073:notes:75]
[same as prior period, unchanged from 0001628280-25-022788:notes:78]

[0001628280-25-049073:notes:76]
We did not have any allowance for credit losses other than our allowance for uncollectible accounts receivable. As of September 27, 2025 and June 28, 2025, the allowance for credit losses on our trade receivables was $3.4 million and $3.5 million, respectively.

[0001628280-25-049073:notes:77]
[same as prior period, unchanged from 0001628280-25-022788:notes:80]

[0001628280-25-049073:notes:78]
[same as prior period, unchanged from 0001628280-25-022788:notes:81]

[0001628280-25-049073:notes:79]
|  | September 27, 2025 |  | June 28, 2025 |
| Raw materials and purchased parts | $ | 245.2 |  |  | $ | 253.2 |  |
| Work in process | 230.5 |  |  | 159.1 |  |
| Finished goods | 55.9 |  |  | 57.8 |  |
| Inventories | $ | 531.6 |  |  | $ | 470.1 |  |

[0001628280-25-049073:notes:80]
[same as prior period, unchanged from 0001628280-25-022788:notes:83]

[0001628280-25-049073:notes:81]
[same as prior period, unchanged from 0001628280-25-022788:notes:84]

[0001628280-25-049073:notes:82]
|  | September 27, 2025 |  | June 28, 2025 |
| Land | $ | 105.8 |  |  | $ | 108.6 |  |
| Buildings and improvements | 293.4 |  |  | 270.4 |  |
| Machinery and equipment | 895.2 |  |  | 848.8 |  |
| Computer equipment and software | 40.7 |  |  | 39.1 |  |
| Furniture and fixtures | 13.9 |  |  | 14.7 |  |
| Leasehold improvements | 45.9 |  |  | 45.9 |  |
| Construction in progress | 174.3 |  |  | 152.3 |  |
|  | 1,569.2 |  |  | 1,479.8 |  |
| Less: Accumulated depreciation | (774.4) |  |  | (753.4) |  |
| Property, plant and equipment, net | $ | 794.8 |  |  | $ | 726.4 |  |

[0001628280-25-049073:notes:83]
Our construction in progress primarily includes building improvements and machinery and equipment that we expect to place in service in the next 12 months.

[0001628280-25-049073:notes:84]
On December 17, 2024, we entered into an agreement to sell our net assets in an entity in Shenzhen, China. On March 5, 2025, we completed the sale and received net proceeds of $47.8 million, which was net of cash of $17.6 million and direct selling costs of $1.1 million. The net assets sold consist primarily of building, building improvements and land rights as of December 17, 2024 with a net carrying value of $12.9 million, and were used for manufacturing and research and development activities. As a result, we recognized a gain on sale of facility of $34.9 million, which was recorded in our condensed consolidated statements of operations for the year ended June 28, 2025. We paid $4.4 million of withholding taxes on this sale transaction, which is recorded as part of the income tax provision for the year ended June 28, 2025. We also incurred $0.7 million of indirect selling expenses related to this transaction, which was recorded as part of selling, general and administrative expenses in our condensed consolidated statements of operations for the year ended June 28, 2025.

[0001628280-25-049073:notes:85]
[same as prior period, unchanged from 0001628280-25-022788:notes:88]

[0001628280-25-049073:notes:86]
In addition, in connection with the sale of our Brazilian entities, we recorded a gain on sale of approximately $1.6 million recorded in selling, general and administrative expenses in our condensed consolidated statements of operations during the three months ended September 27, 2025.

[0001628280-25-049073:notes:87]
During the three months ended September 27, 2025 and September 28, 2024, we recorded depreciation expense of $27.8 million and $27.0 million, respectively.

[0001628280-25-049073:notes:88]
[same as prior period, unchanged from 0001628280-25-022788:notes:91]

[0001628280-25-049073:notes:89]
[same as prior period, unchanged from 0001628280-25-022788:notes:92]

[0001628280-25-049073:notes:90]
|  | September 27, 2025 |  | June 28, 2025 |
| Operating lease right-of-use assets | $ | 57.8 |  |  | $ | 54.4 |  |
| Less: accumulated amortization | (27.3) |  |  | (26.5) |  |
| Operating lease right-of-use assets, net | $ | 30.5 |  |  | $ | 27.9 |  |

[0001628280-25-049073:notes:91]
[same as prior period, unchanged from 0001628280-25-022788:notes:96]

[0001628280-25-049073:notes:92]
[same as prior period, unchanged from 0001628280-25-022788:notes:98]

[0001628280-25-049073:notes:93]
[same as prior period, unchanged from 0001628280-25-022788:notes:99]

[0001628280-25-049073:notes:94]
|  | September 27, 2025 |  | June 28, 2025 |
| Restructuring accrual and related charges (1) | $ | 5.9 |  |  | $ | 2.5 |  |
| Warranty reserve (2) | 13.1 |  |  | 14.4 |  |
| Deferred revenue and customer deposits | 2.7 |  |  | 0.7 |  |
| Income tax payable (3) | 15.6 |  |  | 29.1 |  |
| Other current liabilities | 4.3 |  |  | 6.4 |  |
| Other current liabilities | $ | 41.6 |  |  | $ | 53.1 |  |

[0001628280-25-049073:notes:95]
(1) Refer to “Note 10. Restructuring and Related Charges.”

[0001628280-25-049073:notes:96]
(2) Refer to “Note 13. Commitments and Contingencies.”

[0001628280-25-049073:notes:97]
(3) Refer to “Note 11. Income Taxes.”

[0001628280-25-049073:notes:98]
[same as prior period, unchanged from 0001628280-25-022788:notes:104]

[0001628280-25-049073:notes:99]
[same as prior period, unchanged from 0001628280-25-022788:notes:105]

[0001628280-25-049073:notes:100]
|  | September 27, 2025 |  | June 28, 2025 |
| Asset retirement obligations | $ | 7.1 |  |  | $ | 7.1 |  |
| Pension and related accruals (1) | 10.5 |  |  | 9.7 |  |
| Unrecognized tax benefit (2) | 57.0 |  |  | 55.6 |  |
| Other non-current liabilities (2) | 36.5 |  |  | 25.4 |  |
| Other non-current liabilities | $ | 111.1 |  |  | $ | 97.8 |  |

[0001628280-25-049073:notes:101]
(1) We have defined benefit pension plans in Japan, Switzerland, and Thailand. Pension and related accrual of $10.5 million as of September 27, 2025 represents $11.4 million of non-current portion of benefit obligation, offset by $0.9 million of funding for the pension plan in Switzerland. Pension and related accrual of $9.7 million as of June 28, 2025 relates to $11.0 million of non-current portion of benefit obligation, offset by $1.3 million of funding for the pension plan in Switzerland. We typically re-evaluate the assumptions related to the fair value of our defined benefit obligations annually in the fiscal fourth quarter and make any updates as necessary. During the three months ended September 27, 2025 and September 28, 2024, our contribution expense to the 401(k) Plan in the United States was $0.7 million and $0.7 million, respectively. Our contribution expense to all defined contribution plans outside the United States was $2.7 million and $1.9 million during the three months ended September 27, 2025 and September 28, 2024, respectively.
 (2) The Company has reclassified a $21.4 million unrecognized tax position to other non-current liabilities in the condensed consolidated balance sheets as of the year ended June 28, 2025 for an indemnification liability related to the sale of certain assets. This does not impact our results of operations for the year ended June 28, 2025.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001628280-25-049073:notes:102]
Note 7. Goodwill and Other Intangible Assets

[0001628280-25-049073:notes:103]
[same as prior period, unchanged from 0001628280-25-022788:notes:114]

[0001628280-25-049073:notes:104]
We review goodwill for impairment during the fourth quarter of each fiscal year or more frequently if events or circumstances indicate that an impairment loss may have occurred. In the fourth quarter of fiscal 2025, we completed the annual impairment test of goodwill, which indicated there was no goodwill impairment. There were no indicators of goodwill impairment during the three months ended September 27, 2025.

[0001628280-25-049073:notes:105]
[same as prior period, unchanged from 0001628280-25-022788:notes:116]

[0001628280-25-049073:notes:106]
[same as prior period, unchanged from 0001628280-25-022788:notes:117]

[0001628280-25-049073:notes:107]
[same as prior period, unchanged from 0001628280-25-022788:notes:118]

[0001628280-25-049073:notes:108]
During the annual impairment testing performed in the fourth quarter of fiscal 2025, we concluded that our intangible and other long-lived assets were not impaired at the asset group level. We review our intangible and other long-lived assets for impairment at least annually in the fourth quarter of each fiscal year, absent any interim indicators of impairment. There were no indicators of impairment at the asset group level during the three months ended September 27, 2025.

[0001628280-25-049073:notes:109]
[same as prior period, unchanged from 0001628280-25-022788:notes:123]

[0001628280-25-049073:notes:110]
| September 27, 2025 | Gross Carrying Amounts |  | Accumulated Amortization |  | Net Carrying Amounts |  | Weighted Average Remaining Amortization Period (Years) |
| Acquired developed technologies | $ | 826.4 |  |  | $ | (579.3) |  |  | $ | 247.1 |  |  | 3.9 |
| Customer relationships | 419.5 |  |  | (240.4) |  |  | 179.1 |  |  | 3.9 |
| In-process research and development | 4.5 |  |  | — |  |  | 4.5 |  |  | n/a |
| Order backlog | 14.0 |  |  | (14.0) |  |  | — |  |  | — |
| Trade name and trademarks | 3.0 |  |  | (3.0) |  |  | — |  |  | — |
| Total intangible assets | $ | 1,267.4 |  |  | $ | (836.7) |  |  | $ | 430.7 |  |  |  |

[0001628280-25-049073:notes:111]
| June 28, 2025 | Gross Carrying Amounts |  | Accumulated Amortization |  | Net Carrying Amounts |  | Weighted Average Remaining Amortization Period (Years) |
| Acquired developed technologies | $ | 822.4 |  |  | $ | (559.0) |  |  | $ | 263.4 |  |  | 4.1 |
| Customer relationships | 419.8 |  |  | (226.6) |  |  | 193.2 |  |  | 4.1 |
| In-process research and development | 8.5 |  |  | — |  |  | 8.5 |  |  | n/a |
| Order backlog | 14.0 |  |  | (14.0) |  |  | — |  |  | — |
| Trade name and trademarks | 3.0 |  |  | (3.0) |  |  | — |  |  | — |
| Total intangible assets | $ | 1,267.7 |  |  | $ | (802.6) |  |  | $ | 465.1 |  |  |  |

[0001628280-25-049073:notes:112]
[same as prior period, unchanged from 0001628280-25-022788:notes:126]

[0001628280-25-049073:notes:113]
|  | Three Months Ended |  |  |
|  | September 27, 2025 |  | September 28, 2024 |  |  |  |  |
| Cost of sales | $ | 19.5 |  |  | $ | 22.5 |  |  |  |  |  |
| Research and development | 0.4 |  |  | 0.4 |  |  |  |  |  |
| Selling, general and administrative | 14.5 |  |  | 18.8 |  |  |  |  |  |
| Total amortization of intangibles | $ | 34.4 |  |  | $ | 41.7 |  |  |  |  |  |

[0001628280-25-049073:notes:114]
Based on the carrying amount of our acquired intangible assets except in-process research and development as of September 27, 2025, and assuming no future impairment of the underlying assets, the estimated future amortization is as follows (in millions):

[0001628280-25-049073:notes:115]
| Fiscal Years |  |
| Remainder of 2026 | $ | 101.1 |  |
| 2027 | 123.1 |  |
| 2028 | 82.6 |  |
| 2029 | 52.3 |  |
| 2030 | 46.3 |  |
| Thereafter | 20.8 |  |
| Total future amortization | $ | 426.2 |  |


## us-gaap:DebtDisclosureTextBlock

[0001628280-25-049073:notes:116]
Note 8. Debt

[0001628280-25-049073:notes:117]
Our debt consists of the following:

[0001628280-25-049073:notes:118]
|  | September 27, 2025 |  | June 28, 2025 |
|  | Short-term |  | Long-term |  | Total |  | Short-term |  | Long-term |  | Total |
| Convertible notes | $ | 1,068.7 |  |  | $ | 2,112.6 |  |  | $ | 3,181.3 |  |  | $ | — |  |  | $ | 2,506.2 |  |  | $ | 2,506.2 |  |
| Term loans | 10.3 |  |  | 51.9 |  |  | 62.2 |  |  | 10.6 |  |  | 56.4 |  |  | 67.0 |  |
| Total | $ | 1,079.0 |  |  | $ | 2,164.5 |  |  | $ | 3,243.5 |  |  | $ | 10.6 |  |  | $ | 2,562.6 |  |  | $ | 2,573.2 |  |

[0001628280-25-049073:notes:119]
Convertible Notes

[0001628280-25-049073:notes:120]
2032 Notes

[0001628280-25-049073:notes:121]
On September 8, 2025, we issued $1,265.0 million in aggregate principal amount of 0.375% Convertible Senior Notes due in 2032 (“2032 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act of 1933, as amended. The 2032 Notes are governed by an indenture between the Company and U.S. Bank Trust Company, National Association, as trustee (the “2032 Indenture”). The 2032 Notes are unsecured, rank equally with all of the Company’s existing senior unsecured indebtedness, including the Company’s outstanding 0.50% Convertible Senior Notes due 2026, 0.50% Convertible Senior Notes due 2028, and 1.50% Convertible Senior Notes due 2029, and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001628280-25-049073:notes:122]
The net proceeds from the sale of the 2032 Notes was approximately $1,255.7 million, after deducting $9.3 million of net issuance costs. In addition, we incurred $1.1 million of professional fees directly related to this transaction, which was recorded as part of accrued expenses in our condensed consolidated balance sheets as of September 27, 2025. Concurrent with the issuance of the 2032 Notes, we used $843.1 million of the net proceeds to repurchase $581.1 million aggregate principal amount of the 0.50% Convertible Senior Notes due in 2026 and $102.0 million of the net proceeds to pay the cost of the 2032 Capped Call Options. We intend to use the remaining net proceeds for general corporate purposes, which may include the repayment or repurchase of our indebtedness, including any of our existing convertible notes, capital expenditures, working capital and potential acquisitions.

[0001628280-25-049073:notes:123]
The  2032 Notes bear interest at a rate of 0.375% per year, payable semi-annually in arrears on March 15 and September 15 of each year, beginning on March 15, 2026. The 2032 Notes will mature on March 15, 2032, unless earlier redeemed, repurchased by us, or converted pursuant to their terms.

[0001628280-25-049073:notes:124]
The initial conversion rate is 5.3257 shares of common stock per $1,000 principal amount of the 2032 Notes (which is equivalent to an initial conversion price of approximately $187.77 per share). The conversion rate is subject to adjustment upon the occurrence of certain events specified in the 2032 Indenture but will not be adjusted for any accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change (as defined in the 2032 Indenture) or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert the 2032 Notes in connection with such make-whole fundamental change or notice of redemption.

[0001628280-25-049073:notes:125]
Prior to the close of business on the business day immediately preceding December 15, 2031, holders of the 2032 Notes may convert their 2032 Notes only under the following circumstances:

[0001628280-25-049073:notes:126]
•during any fiscal quarter commencing after December 27, 2025 (and only during such fiscal quarter), if the last reported sale price of the common stock for at least 20 trading days (whether or not consecutive) during the period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price of the 2032 Notes, or $244.10, on each applicable trading day;

[0001628280-25-049073:notes:127]
•during the five consecutive business day period after any five  consecutive trading day period (the “2032 measurement period”) in which the trading price per $1,000 principal amount of 2032 Notes for each trading day of the 2032 measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate on each such trading day;

[0001628280-25-049073:notes:128]
•if we call any or all of the 2032 Notes for redemption, at any time prior to the close of business on the second scheduled trading day immediately preceding the redemption date; or

[0001628280-25-049073:notes:129]
•upon the occurrence of specified corporate events as specified in the 2032 Indenture.

[0001628280-25-049073:notes:130]
On or after December 15, 2031 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their 2032 Notes at any time. Upon conversion, we are required to satisfy our conversion obligation with respect to such converted 2032 Notes by paying cash equal to the principal amount of such converted 2032 Notes and paying or delivering, as the case may be, cash, shares of common stock or a combination of cash and shares of common stock, at our election, with respect to any conversion value in excess thereof, if any.

[0001628280-25-049073:notes:131]
We may redeem for cash all or any portion of the 2032 Notes, at our option (subject to the partial redemption limitation set forth in the 2032 Indenture), on or after March 20, 2029, if the last reported sale price of our common stock has been at least 130% of the conversion price then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading-day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which we provide notice of redemption at a redemption price equal to 100% of the principal amount of the 2032 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. No sinking fund is provided for the 2032 Notes. If we elect to redeem fewer than all of the outstanding 2032 Notes, at least $100.0 million aggregate principal amount of the 2032 Notes must be outstanding and not subject to redemption as of the redemption notice date. Upon the occurrence of a fundamental change (as defined in the 2032 Indenture), holders may require us to repurchase all or a portion of their 2032 Notes for cash at a price equal to 100% of the principal amount of the 2032 Notes to be repurchased, plus any accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

[0001628280-25-049073:notes:132]
The entirety of the 2032 Notes are recorded as convertible notes, non-current in our consolidated balance sheets as of September 27, 2025, measured at amortized cost.

[0001628280-25-049073:notes:133]
2032 Capped Call Options

[0001628280-25-049073:notes:134]
In September 2025, in connection with the issuances of the 2032 Notes, the Company entered into privately negotiated capped call transactions (the “2032 Capped Call Options”) with certain financial institutions (the “2032 Capped Call Counterparties”). The 2032 Capped Call Options cover, subject to anti-dilution adjustments substantially similar to those applicable to the 2032 Notes, the number of shares of our common stock that initially underlie the 2032 Notes and are generally expected to reduce potential dilution to the Company’s common stock upon any conversion of 2032 Notes and/or offset any cash payments the Company would be required to make in excess of the principal amount of converted 2032 Notes, as the case may be, with such reduction and/or offset subject to a cap. The cap price of the 2032 Capped Call Options was initially $268.24 per share, and is subject to certain adjustments under the terms of the 2032 Capped Call Options. If the market price per share of our common stock, as measured under the terms of the 2032 Capped Call Options, exceeds the cap price of the 2032 Capped Call Options, there would be dilution and/or there would not be an offset of any potential cash payments in excess of the principal amount of converted 2032 Notes, in each case, to the extent that such market price exceeds the cap price of the 2032 Capped Call Options.

[0001628280-25-049073:notes:135]
Each of the 2032 Capped Call Options was executed pursuant to a separate agreement entered into by the Company and each of the 2032 Capped Call Counterparties. The 2032 Capped Call Options are not part of the terms of the 2032 Notes and will not affect any holder’s rights under the 2032 Notes. Holders of the 2032 Notes will not have any rights with respect to the 2032 Capped Call Options. The Company concluded that the 2032 Capped Call Options met the criteria for equity classification because they were indexed to the Company’s common stock and the Company has the discretion to settle the 2032 Capped Call Options in shares or cash. As a result, the $102.0 million amount paid was recorded as a reduction to additional paid-in capital within the Company’s condensed consolidated balance sheets as of September 27, 2025, along with the offsetting associated current tax impact of $0.2 million.

[0001628280-25-049073:notes:136]
The Company made a tax election to integrate the 2032 Notes and the 2032 Capped Call Options for federal income tax purposes pursuant to applicable U.S. Treasury Regulations. Accordingly, the $102.0 million gross cost of the purchased 2032 Capped Call Options will be deductible for income tax purposes as original issue discount interest over the term of the 2032 Notes. As a result, the Company established a deferred income tax asset of $21.4 million at inception, with a corresponding valuation allowance as it is not more-likely-than-not that our U.S. deferred tax assets are realizable in the future. As of September 27, 2025, we have recognized a current tax impact of  $0.2 million at issuance, which is recorded as an increase to additional paid-in capital within the Company’s condensed consolidated balance sheets.

[0001628280-25-049073:notes:137]
2029 Notes

[0001628280-25-049073:notes:138]
On June 16, 2023, we issued $603.7 million in aggregate principal amount of 1.50% Convertible Senior Notes due in 2029 (“2029 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act of 1933, as amended. The 2029 Notes are governed by an indenture between the Company and U.S. Bank Trust Company, National Association, as trustee (the “2029 Indenture”). The 2029 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001628280-25-049073:notes:139]
The 2029 Notes bear interest at a rate of 1.50% per year, payable semi-annually in arrears on June 15 and December 15 of each year. The 2029 Notes will mature on December 15, 2029, unless earlier redeemed, repurchased by us, or converted pursuant to their terms.

[0001628280-25-049073:notes:140]
The initial conversion rate is 14.3808 shares of common stock per $1,000 principal amount of the 2029 Notes (which is equivalent to an initial conversion price of approximately $69.54 per share). The conversion rate is subject to adjustment upon the occurrence of certain events specified in the 2029 Indenture but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change (as defined in the 2029 Indenture) or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert the 2029 Notes in connection with such make-whole fundamental change or notice of redemption.

[0001628280-25-049073:notes:141]
Prior to the close of business on the business day immediately preceding September 15, 2029, holders of the 2029 Notes may convert their 2029 Notes only under the following circumstances:

[0001628280-25-049073:notes:142]
•during any fiscal quarter (and only during such fiscal quarter), if the last reported sale price of the common stock for at least 20 trading days (whether or not consecutive) during the period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price of the 2029 Notes, or $90.40, on each applicable trading day;

[0001628280-25-049073:notes:143]
•during the five consecutive business day period after any five consecutive trading day period (the “2029 measurement period”) in which the trading price per $1,000 principal amount of 2029 Notes for each trading day of the 2029 measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate on each such trading day;

[0001628280-25-049073:notes:144]
•if we call any or all of the 2029 Notes for redemption, at any time prior to the close of business on the second business day immediately preceding the redemption date; or

[0001628280-25-049073:notes:145]
•upon the occurrence of specified corporate events as specified in the 2029 Indenture.

[0001628280-25-049073:notes:146]
On or after September 15, 2029 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their 2029 Notes at any time. Following our irrevocable settlement method election made on September 25, 2024, upon conversion, we are required to satisfy our conversion obligation with respect to such converted 2029 Notes by delivering cash equal to the principal amount of such converted 2029 Notes and cash, shares of common stock or a combination of cash and shares of common stock, at our election, with respect to any conversion value in excess thereof.

[0001628280-25-049073:notes:147]
We may redeem for cash all or any portion of the 2029 Notes, at our option (subject to the partial redemption limitation set forth in the 2029 Indenture), on or after June 22, 2026, if the last reported sale price of our common stock has been at least 130% of the conversion price then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading-day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which we provide notice of redemption at a redemption price equal to 100% of the principal amount of the 2029 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. No sinking fund is provided for the 2029 Notes. If we elect to redeem fewer than all of the outstanding 2029 Notes, at least $100.0 million aggregate principal amount of the 2029 Notes must be outstanding and not subject to redemption as of the redemption notice date. Upon the occurrence of a fundamental change (as defined in the 2029 Indenture), holders may require us to repurchase all or a portion of their 2029 Notes for cash at a price equal to 100% of the principal amount of the 2029 Notes to be repurchased, plus any accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

[0001628280-25-049073:notes:148]
Since the closing price of our stock exceeded $90.40 (or 130% of the conversion price of $69.54) for 20 of the last 30 trading days of our first quarter of fiscal year 2026, our 2029 Notes became convertible at the option of the holders during the second quarter of fiscal year 2026, thus, the entire 2029 Notes are recorded as short-term debt, which is presented as current liabilities in our consolidated balance sheets as of September 27, 2025, measured at amortized cost, while the entire 2029 Notes are recorded as convertible notes, non-current in our consolidated balance sheets as of June 28, 2025, measured at amortized cost.

[0001628280-25-049073:notes:149]
2028 Notes

[0001628280-25-049073:notes:150]
In March 2022, we issued $861.0 million in aggregate principal amount of 0.50% Convertible Senior Notes due in 2028 (the “2028 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act of 1933, as amended (the “Securities Act”). The 2028 Notes are governed by an indenture between the Company and U.S. Bank Trust Company, National Association, as trustee (the “2028 Indenture”). The 2028 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001628280-25-049073:notes:151]
The 2028 Notes bear interest at a rate of 0.50% per year, payable semi-annually in arrears on June 15 and December 15 of each year. The 2028 Notes will mature on June 15, 2028, unless earlier redeemed, repurchased by us, or converted pursuant to their terms.

[0001628280-25-049073:notes:152]
The initial conversion rate is 7.6319 shares of common stock per $1,000 principal amount of the 2028 Notes (which is equivalent to an initial conversion price of approximately $131.03 per share). The conversion rate is subject to adjustment upon the occurrence of certain specified events, but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change (as defined in the 2028 Indenture) or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert the 2028 Notes in connection with such make-whole fundamental change or notice of redemption.

[0001628280-25-049073:notes:153]
Prior to the close of business on the business day immediately preceding March 15, 2028, holders of the 2028 Notes may convert their 2028 Notes only under the following circumstances:

[0001628280-25-049073:notes:154]
•during any fiscal quarter (and only during such fiscal quarter), if the last reported sale price of the Company’s common stock for at least 20 trading days (whether or not consecutive) during the 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price, or $170.34, on each applicable trading day;

[0001628280-25-049073:notes:155]
•during the five consecutive business day period after any five consecutive trading day period (the “measurement period”) in which the trading price per $1,000 principal amount of the 2028 Notes for each trading day of such measurement period was less than 98% of the product of the last reported sale price of the Company’s common stock and the applicable conversion rate on each such trading day;

[0001628280-25-049073:notes:156]
•if the Company calls any or all of the 2028 Notes for redemption, at any time prior to the close of business on the second business day immediately preceding the redemption date; or

[0001628280-25-049073:notes:157]
•upon the occurrence of specified corporate events, as specified in the 2028 Indenture.

[0001628280-25-049073:notes:158]
On or after March 15, 2028 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their 2028 Notes at any time. Following our irrevocable settlement method election made on September 25, 2024, upon conversion, we are required to satisfy our conversion obligation with respect to such converted 2028 Notes by paying cash equal to the principal amount of such converted 2028 Notes and paying or delivering, as the case may be, cash, shares of common stock or a combination of cash and shares of common stock, at our election, with respect to any conversion value in excess thereof,if any.

[0001628280-25-049073:notes:159]
We may redeem for cash all or any portion of the 2028 Notes, at our option (subject to the partial redemption limitation set forth in the 2028 Indenture), on or after June 20, 2025, if the last reported sale price of its common stock has been at least 130% of the conversion price then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading-day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which the Company provides notice of redemption at a redemption price equal to 100% of the principal amount of the 2028 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. No sinking fund is provided for the 2028 Notes. If we elect to redeem fewer than all of the outstanding 2028 Notes, at least $100.0 million aggregate principal amount of the 2028 Notes must be outstanding and not subject to redemption as of the redemption notice date. Upon the occurrence of a fundamental change (as defined in the 2028 Indenture), holders may require the Company to repurchase all or a portion of their 2028 Notes for cash at a price equal to 100% of the principal amount of the 2028 Notes to be repurchased, plus any accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

[0001628280-25-049073:notes:160]
We initially bifurcated the principal amount of the 2028 Notes into liability and equity components. The liability component of the 2028 Notes was initially valued at $629.8 million based on the contractual cash flow discounted at an appropriate comparable market on non-convertible debt borrowing rate at the date of issuance, which was 5.7%, with the equity component representing the residual amount of the proceeds of $231.2 million, which was recorded as a debt discount. Upon adoption of ASU 2020-06 in the first quarter of fiscal 2023, our 2028 Notes were accounted for as a single liability measured at amortized cost. The entire 2028 Notes are recorded as convertible notes, non-current in our consolidated balance sheets as of September 27, 2025 and June 28, 2025, measured at amortized cost.

[0001628280-25-049073:notes:161]
2026 Notes

[0001628280-25-049073:notes:162]
In December 2019, we issued $1,050.0 million in aggregate principal amount of 0.50% Convertible Senior Notes due in 2026 (the “2026 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act. The 2026 Notes are governed by an indenture between the Company and U.S. Bank Trust Company, National Association (as successor in interest to U.S. Bank National Association), as trustee (as supplemented by the First Supplemental Indenture, dated as of September 25, 2024, the “2026 Indenture”). The 2026 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001628280-25-049073:notes:163]
The 2026 Notes bear interest at a rate of 0.50% per year, payable semi-annually in arrears on June 15 and December 15 of each year. The 2026 Notes will mature on December 15, 2026, unless earlier redeemed, repurchased by us, or converted pursuant to their terms.

[0001628280-25-049073:notes:164]
The initial conversion rate is 10.0711 shares of common stock per $1,000 principal amount of the 2026 Notes (which is equivalent to an initial conversion price of approximately $99.29 per share). The conversion rate is subject to adjustment upon the occurrence of certain events specified in the 2026 Indenture but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change (as defined in the 2026 Indenture) or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares set forth in the 2026 Indenture or a holder that elects to convert the 2026 Notes in connection with such make-whole fundamental change or notice of redemption.

[0001628280-25-049073:notes:165]
Prior to the close of business on the business day immediately preceding September 15, 2026, holders of the 2026 Notes may convert their 2026 Notes only under the following circumstances:

[0001628280-25-049073:notes:166]
•during any fiscal quarter (and only during such fiscal quarter), if the last reported sale price of the common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price of the 2026 Notes, or $129.08 on each applicable trading day;

[0001628280-25-049073:notes:167]
•during the five consecutive business day period after any five consecutive trading day period (the “2026 measurement period”) in which the trading price per $1,000 principal amount of the 2026 Notes for each trading day of the 2026 measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate for the 2026 Notes on each such trading day;

[0001628280-25-049073:notes:168]
•if we call any or all of the 2026 Notes for redemption, at any time prior to the close of business on the second business day immediately preceding the relevant redemption date; or

[0001628280-25-049073:notes:169]
•upon the occurrence of specified corporate events.

[0001628280-25-049073:notes:170]
On or after September 15, 2026 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their 2026 Notes at any time. Following our entry into the First Supplemental Indenture, dated as of September 25, 2024, to the 2026 Indenture, upon conversion, we are required to satisfy our conversion obligation with respect to such converted 2026 Notes by paying cash equal to the principal amount of such converted 2026 Notes and paying or delivering, as the case may be, cash, shares of common stock or a combination of cash and shares of common stock, at our election, with respect to any conversion value in excess thereof, if any.

[0001628280-25-049073:notes:171]
We may redeem for cash, all or any portion of the 2026 Notes, at our option, on or after December 20, 2023, if the last reported sale price of its common stock has been at least 130% of the conversion price then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading-day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which we provide a notice of redemption at a redemption price equal to 100% of the principal amount of the 2026 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. No sinking fund is provided for the 2026 Notes. Upon the occurrence of a fundamental change (as defined in the 2026 Indenture), holders may require us to repurchase all or a portion of the 2026 Notes for cash at a price equal to 100% of the principal amount of the 2026 Notes to be repurchased, plus any accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

[0001628280-25-049073:notes:172]
We initially bifurcated the principal amount of the 2026 Notes into liability and equity components. The liability component of the 2026 Notes was initially valued at $734.8 million based on the contractual cash flows discounted at an appropriate comparable market non-convertible debt borrowing rate at the date of issuance of 5.8% with the equity component representing the residual amount of the proceeds of $315.2 million, which was recorded as a debt discount. Upon adoption of ASU 2020-06 in the first quarter of fiscal 2023, our 2026 Notes were accounted for as a single liability measured at amortized cost.

[0001628280-25-049073:notes:173]
Concurrent with the issuance of the 2032 Notes, we used approximately $843.1 million of the net proceeds to repurchase $581.1 million aggregate principal amount of the 2026 Notes. We also paid $0.7 million of the related accrued interest. We have adopted and applied ASU 2024-04, Debt with Conversion and Other Options: Induced Conversions of Convertible Debt Instruments. We determined that this transaction met the requirements for the settlement of debt as an induced conversion. Accordingly, we recorded $256.9 million, which represents the fair value increase in the fair value of the debt, as a reduction to additional paid-in capital within the Company’s consolidated Balance Sheets as of September 27, 2025, and recognized an inducement expense of $5.9 million in our consolidated statements of operations during the three months ended September 27, 2025, which represents the excess of fair value of the total consideration over the fair value of securities issuable pursuant to the original conversion terms.

[0001628280-25-049073:notes:174]
Since the closing price of our stock exceeded $129.08 (or 130% of the conversion price of $99.29) for 20 of the last 30 trading days of our first quarter of fiscal year, our 2026 Notes became convertible at the option of the holders during the second quarter of fiscal year 2026, thus, the remaining 2026 Notes outstanding are recorded as short-term debt, which is presented as current liabilities in our consolidated balance sheets as of September 27, 2025, measured at amortized cost. The entire 2026 Notes are recorded as convertible notes, non-current in our consolidated balance sheets as of June 28, 2025, measured at amortized cost.

[0001628280-25-049073:notes:175]
Our convertible notes consisted of the following components as of the periods presented (in millions):

[0001628280-25-049073:notes:176]
| September 27, 2025 | 2026 Notes (1) |  | 2028 Notes (2) |  | 2029 Notes (3) |  | 2032 Notes (4) |  | Total |  |  |  |  |  |
| Principal | $ | 468.9 |  |  | $ | 861.0 |  |  | $ | 603.7 |  |  | $ | 1,265.0 |  |  | $ | 3,198.6 |  |  |  |  |  |  |
| Unamortized debt discount and debt issuance costs | (0.6) |  |  | (3.0) |  |  | (3.3) |  |  | (10.4) |  |  | (17.3) |  |  |  |  |  |  |
| Net carrying amount of the liability component | $ | 468.3 |  |  | $ | 858.0 |  |  | $ | 600.4 |  |  | $ | 1,254.6 |  |  | $ | 3,181.3 |  |  |  |  |  |  |

[0001628280-25-049073:notes:177]
| June 28, 2025 |  |  | 2026 Notes (1) |  | 2028 Notes (2) |  | 2029 Notes (3) |  | Total |
| Principal |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |  | $ | 603.7 |  |  | $ | 2,514.7 |  |
| Unamortized debt discount and debt issuance costs |  |  | (1.7) |  |  | (3.3) |  |  | (3.5) |  |  | (8.5) |  |
| Net carrying amount of the liability component |  |  | $ | 1,048.3 |  |  | $ | 857.7 |  |  | $ | 600.2 |  |  | $ | 2,506.2 |  |

[0001628280-25-049073:notes:178]
(1) If the closing price of our stock exceeds $129.08 (or 130% of the conversion price of $99.29) for 20 of the last 30 trading days of any future fiscal quarter, our 2026 Notes would become convertible at the option of the holders during the subsequent fiscal quarter, which was the case as of the end of the first quarter of fiscal year 2026, and therefore, the debt was reclassified to current liabilities in our condensed consolidated balance sheets.

[0001628280-25-049073:notes:179]
(2) If the closing price of our stock exceeds $170.34 (or 130% of the conversion price of $131.03) for 20 of the last 30 trading days of any future fiscal quarter, our 2028 Notes would become convertible at the option of the holders during the subsequent fiscal quarter and the debt would be reclassified to current liabilities in our condensed consolidated balance sheets.

[0001628280-25-049073:notes:180]
(3) If the closing price of our stock exceeds $90.40 (or 130% of the conversion price of $69.54) for 20 of the last 30 trading days of any future quarter, our 2029 Notes would become convertible at the option of the holders during the subsequent fiscal quarter, which was the case as of the end of the first quarter of fiscal year 2026, and therefore, the debt was reclassified to current liabilities in our consolidated balance sheets.

[0001628280-25-049073:notes:181]
(4) If the closing price of our stock exceeds $244.10 (or 130% of the conversion price of $187.77) for 20 of the last 30 trading days of any future quarter, our 2032 Notes would become convertible at the option of the holders during the subsequent fiscal quarter and the debt would be reclassified to current liabilities in our consolidated balance sheets.

[0001628280-25-049073:notes:182]
The following table sets forth interest expense information related to the convertible notes for the periods presented (in millions):

[0001628280-25-049073:notes:183]
|  | Three Months Ended |  |  |
|  | September 27, 2025 |  | September 28, 2024 |  |  |  |  |
| Contractual interest expense | $ | 4.7 |  |  | $ | 4.7 |  |  |  |  |  |
| Amortization of the debt discount and debt issuance costs | 0.8 |  |  | 0.7 |  |  |  |  |  |
| Total interest expense | $ | 5.5 |  |  | $ | 5.4 |  |  |  |  |  |

[0001628280-25-049073:notes:184]
The future interest and principal payments related to our convertible notes are as follows as of September 27, 2025 (in millions):

[0001628280-25-049073:notes:185]
| Fiscal Years | 2026 Notes |  | 2028 Notes |  | 2029 Notes |  | 2032 Notes |  | Total |
| 2026 | $ | 3.0 |  |  | $ | 4.3 |  |  | $ | 9.1 |  |  | $ | 2.4 |  |  | $ | 18.8 |  |
| 2027 | 470.1 |  |  | 4.3 |  |  | 9.1 |  |  | 4.7 |  |  | 488.2 |  |
| 2028 | — |  |  | 865.3 |  |  | 9.1 |  |  | 4.7 |  |  | 879.1 |  |
| 2029 | — |  |  | — |  |  | 9.1 |  |  | 4.7 |  |  | 13.8 |  |
| 2030 | — |  |  | — |  |  | 608.1 |  |  | 4.7 |  |  | 612.8 |  |
| Thereafter | — |  |  | — |  |  | — |  |  | 1,274.7 |  |  | 1,274.7 |  |
| Total payments | $ | 473.1 |  |  | $ | 873.9 |  |  | $ | 644.5 |  |  | $ | 1,295.9 |  |  | $ | 3,287.4 |  |

[0001628280-25-049073:notes:186]
The principal balances of our convertible notes are reflected in the payment periods in the table above based on their respective contractual maturities.

[0001628280-25-049073:notes:187]
Term Loans

[0001628280-25-049073:notes:188]
SMBC Term Loan

[0001628280-25-049073:notes:189]
On August 9, 2024, the Company entered into a term loan agreement (the “SMBC Term Loan”) with Sumitomo Mitsui Banking Corporation (“SMBC”). The SMBC Term Loan provides an aggregate principal amount of 6.4 billion Japanese yen (“JPY”). The loan requires monthly principal payments of approximately 53.3 million JPY, from August 31, 2024 to June 30, 2029 and interest based on a fixed annual interest rate of 0.88%, with the remaining principal of approximately 3.3 billion JPY due on the loan maturity date of July 31, 2029. Under the loan agreement, the Company cannot prepay the outstanding loan without SMBC’s approval.  In the event the Company prepays the outstanding loan with SMBC’s approval, the Company shall pay SMBC a settlement amount calculated pursuant to the terms of the loan agreement. The SMBC Term Loan is secured by the real estate owned in Sagamihara, Japan.

[0001628280-25-049073:notes:190]
As of September 27, 2025, the Company had $38.2 million in principal amount outstanding, of which the short-term portion of $4.3 million is recorded as current liabilities while the long-term portion of $33.9 million is recorded as long-term debt in the Company’s condensed consolidated balance sheets.

[0001628280-25-049073:notes:191]
Mizuho Term Loan

[0001628280-25-049073:notes:192]
On September 20, 2024, the Company entered into a term loan agreement (the “Mizuho Term Loan”) with Mizuho Bank, Ltd. (“Mizuho”), in order to finance our planned manufacturing expansions. The Mizuho Term Loan provides for borrowings of 4.5 billion JPY with a 5-year term from the funding date September 20, 2024. The loan requires quarterly principal payments of approximately 225.0 million JPY commencing on December 20, 2024 with the final payment on September 20, 2029. The Mizuho Term Loan bears interest at a fixed annual rate of 0.90%. The Mizuho Term Loan is secured by the real estate assets owned by NeoPhotonics Semiconductor GK. The Mizuho Term Loan agreement requires that the Company and certain domestic subsidiaries comply with covenants relating to customary matters, including obtaining approval from Mizuho prior to transferring, creating a security interest, or disposing of the collateral assets; obtaining approval from Mizuho prior to a business transfer, business acquisition, corporate reorganization or changes such as mergers, company splits, share exchanges or share transfers or capital structure changes; obtaining approval from Mizuho prior to changing the Company’s indirect ownership in Lumentum Japan, Inc; and obtaining approval from Mizuho prior to a distribution of dividends by Lumentum Japan, Inc. to its shareholders.

[0001628280-25-049073:notes:193]
As of September 27, 2025, the Company had $24.0 million in principal amount outstanding, of which the short-term portion of $6.0 million is recorded as current liabilities while the long-term portion of $18.0 million is recorded as long-term debt in the Company’s condensed consolidated balance sheets.
The SMBC Term Loan and the Mizuho Term Loan are collectively referred to as Japan Term Loans.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001628280-25-049073:notes:194]
Note 9. Accumulated Other Comprehensive Income (Loss)

[0001628280-25-049073:notes:195]
[same as prior period, unchanged from 0001628280-25-022788:notes:197]

[0001628280-25-049073:notes:196]
[same as prior period, unchanged from 0001628280-25-022788:notes:198]

[0001628280-25-049073:notes:197]
|  | Foreign Currency Translation Adjustments, Net of Tax (1) |  | Defined Benefit Obligations, Net of Tax (2) |  | Unrealized Gain (Loss) on Available-for-Sale Securities, Net of Tax (3) |  |  |  | Total |
| Beginning balance as of June 28, 2025 | $ | 9.9 |  |  | $ | (1.6) |  |  | $ | 0.7 |  |  |  |  | $ | 9.0 |  |
| Other comprehensive gain, net | (0.3) |  |  | — |  |  | 0.4 |  |  |  |  | 0.1 |  |
| Ending balance as of September 27, 2025 | $ | 9.6 |  |  | $ | (1.6) |  |  | $ | 1.1 |  |  |  |  | $ | 9.1 |  |
|  | Foreign Currency Translation Adjustments, Net of Tax (1) |  | Defined Benefit Obligations, Net of Tax (2) |  | Unrealized Gain (Loss) on Available-for-Sale Securities, Net of Tax (3) |  |  |  | Total |
| Beginning balance as of June 29, 2024 | $ | 9.8 |  |  | $ | 0.7 |  |  | $ | (1.2) |  |  |  |  | $ | 9.3 |  |
| Other comprehensive gain, net | — |  |  | — |  |  | 2.3 |  |  |  |  | 2.3 |  |
| Ending balance as of September 28, 2024 | $ | 9.8 |  |  | $ | 0.7 |  |  | $ | 1.1 |  |  |  |  | $ | 11.6 |  |

[0001628280-25-049073:notes:198]
(1) In fiscal 2019, we established the functional currency for our worldwide operations as the U.S. dollar. Translation adjustments reported prior to December 2018 remain as a component of accumulated other comprehensive income (loss) in our condensed consolidated balance sheets, until all or a part of the investment in the subsidiaries is sold or liquidated.

[0001628280-25-049073:notes:199]
(2) We re-evaluate the assumptions related to the fair value of our defined benefit obligations annually in the fiscal fourth quarter and make any updates as necessary.
(3) For the three months ended September 27, 2025 and September 28, 2024, our unrealized loss on available-for-sale securities is presented net of tax of nil for both periods


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001628280-25-049073:notes:200]
Note 10. Restructuring and Related Charges

[0001628280-25-049073:notes:201]
[same as prior period, unchanged from 0001628280-25-022788:notes:205]

[0001628280-25-049073:notes:202]
[same as prior period, unchanged from 0001628280-25-022788:notes:206]

[0001628280-25-049073:notes:203]
|  | Three Months Ended |  |  |
|  | September 27, 2025 |  | September 28, 2024 |  |  |  |  |
| Balance as of beginning of period | $ | 2.5 |  |  | $ | 11.1 |  |  |  |  |  |
| Charges | 8.3 |  |  | 9.7 |  |  |  |  |  |
| Payments and other adjustments | (4.9) |  |  | (14.5) |  |  |  |  |  |
| Balance as of end of period | $ | 5.9 |  |  | $ | 6.3 |  |  |  |  |  |

[0001628280-25-049073:notes:204]
During the three months ended September 27, 2025, we recorded restructuring and related charges of $8.3 million related to a reduction in force during the period in order to enhance operational efficiency and realign our investments toward the most critical initiatives.

[0001628280-25-049073:notes:205]
During the three months ended September 28, 2024, we recorded restructuring and related charges of $9.7 million, which includes $6.0 million of asset write-offs primarily due to integration efforts to consolidate our sites, $3.0 million of charges related to the discontinuation of our in-house development of coherent DSPs and RFICs and the remaining restructuring charges due to company-wide cost reduction initiatives.

[0001628280-25-049073:notes:206]
[same as prior period, unchanged from 0001628280-25-022788:notes:211]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-25-049073:notes:207]
Note 11. Income Taxes

[0001628280-25-049073:notes:208]
Our tax provision for interim periods has generally been determined using an estimate of our annual effective tax rate, adjusted for discrete items, if any, that arise during the period.  Each quarter, we update our estimate of the annual effective tax rate, and if the estimated annual effective tax rate changes, we make a cumulative adjustment in such period. Our quarterly tax provision and estimate of our annual effective tax rate are subject to variation due to several factors, including variability in pre-tax income (or loss), the mix of jurisdictions to which such income relates, changes in how we do business, and tax law developments.

[0001628280-25-049073:notes:209]
We recorded a tax provision of $1.0 million for the three months ended September 27, 2025. Our tax provision for the three months ended September 27, 2025 includes a discrete tax benefit of 0.6 million primarily related to the tax benefit from a windfall in connection with stock-based compensation vested during the quarter and foreign return to provision differences, partially offset by the tax expense from currency re-measurement of certain tax related accounts.

[0001628280-25-049073:notes:210]
We recorded a tax provision of $3.2 million for the three months ended September 28, 2024. Our tax provision for the three months ended September 28, 2024 is primarily related to the tax expense associated with interest on uncertain tax positions, partially offset by the tax benefit from currency re-measurements.

[0001628280-25-049073:notes:211]
Our estimated effective tax rate for the three months ended September 27, 2025 differs from the 21% U.S. statutory rate primarily due to the income tax expense from foreign income inclusions in the U.S., current year valuation allowance change, and non-deductible stock-based compensation, partially offset by the income tax benefit from foreign rate differential,and various income tax credits.

[0001628280-25-049073:notes:212]
We regularly assess our ability to realize our deferred tax assets on a quarterly basis and will establish a valuation allowance if it is more-likely-than-not that some portion of the deferred tax assets will not be realized. As of September 27, 2025, we maintain a full valuation allowance on U.S. federal and state and certain foreign deferred tax assets. We will continue to assess the need for a valuation allowance against our remaining deferred tax assets and may increase or decrease our valuation allowance materially in the future.

[0001628280-25-049073:notes:213]
As of September 27, 2025, we had $59.5 million of unrecognized tax benefits, which, if recognized, would affect the effective tax rate. We are subject to examination of income tax returns by various domestic and foreign tax authorities. The timing of resolution and closure of these tax examinations is highly unpredictable. Although it is possible that certain ongoing tax examinations may be concluded within the next 12 months, we cannot reasonably estimate the impact to tax expense and net income from tax examinations that could be resolved or closed within the next 12 months. Subject to audit timing and uncertainty, we expect the amount of unrecognized tax benefit that would become recognized due to expiration of the statute of limitations and affect the effective tax rate to decrease by $3.3 million over the next 12 months.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001628280-25-049073:notes:214]
Note 12. Equity

[0001628280-25-049073:notes:215]
[same as prior period, unchanged from 0001628280-25-022788:notes:220]

[0001628280-25-049073:notes:216]
[same as prior period, unchanged from 0001628280-25-022788:notes:221]

[0001628280-25-049073:notes:217]
[same as prior period, unchanged from 0001628280-25-022788:notes:222]

[0001628280-25-049073:notes:218]
In February 2025, our board of directors approved the 2025 Inducement Equity Incentive Plan (the “Inducement Plan”) in accordance with Listing Rule 5635(c)(4) of the corporate governance rules of the Nasdaq Stock Market, which became effective in February 2025. The Inducement Plan has substantially the same terms and conditions as the 2015 Plan, however, the Inducement Plan may only be used for grants to new employees and not for existing employees, executives, directors or consultants.

[0001628280-25-049073:notes:219]
As of September 27, 2025, we had 4.2 million shares subject to stock options, restricted stock units, restricted stock awards, and performance stock units issued and outstanding under the 2015 Plan. Restricted stock units and performance stock units are performance-based, market-based and time-based or any combination thereof and are expected to vest within four years. As of September 27, 2025, 1.6 million shares of common stock under the 2015 Plan were available for grant.

[0001628280-25-049073:notes:220]
[same as prior period, unchanged from 0001628280-25-022788:notes:225]

[0001628280-25-049073:notes:221]
The Company granted certain employees with stock options, the vesting of which is based on the requisite service requirement and expected to vest within three years. The Company calculates the fair value of stock options using the Black-Scholes option-pricing model, which requires the Company to make estimates of assumptions such as expected volatility, expected term, risk-free interest rate, expected dividend yield, and forfeiture rates. We issue new shares of common stock upon exercise of stock options.

[0001628280-25-049073:notes:222]
[same as prior period, unchanged from 0001628280-25-022788:notes:229]

[0001628280-25-049073:notes:223]
Restricted stock units (“RSUs”) under the 2015 Plan and the Inducement Plan are grants of shares of our common stock, the vesting of which is based on the requisite service requirement. The fair value of these grants is based on the closing market price of our common stock on the date of grant. Generally, our RSUs are subject to forfeiture and are expected to vest within four years. For annual grants to existing employees, RSUs generally vest ratably on an annual basis, or combination of annual and quarterly basis, over three years.

[0001628280-25-049073:notes:224]
During the three months ended September 27, 2025, our board of directors approved grants of 1.0 million RSUs, which primarily vest over three years. The fair value of these grants is based on the closing market price of our common stock on the grant date.

[0001628280-25-049073:notes:225]
[same as prior period, unchanged from 0001628280-25-022788:notes:232]

[0001628280-25-049073:notes:226]
Performance stock units (“PSUs”) under the 2015 Plan and the Inducement Plan are grants of shares of our common stock that vest upon the achievement of certain performance and service conditions. For PSUs with performance-based conditions, the fair value of these grants is based on the closing market price of our common stock on the date of grant, and we begin recognizing compensation expense when we conclude that it is probable that the performance conditions will be achieved. We reassess the probability of vesting at each reporting period and adjust our compensation cost based on this probability assessment. For PSUs with market-based conditions, the fair value of these grants is estimated using a Monte-Carlo simulation model, and the compensation expense is recognized ratably over the requisite service period regardless of whether or not the market condition is satisfied, provided the requisite service is rendered. Our PSUs are subject to risk of forfeiture until performance and service conditions are satisfied and generally vest within three years.

[0001628280-25-049073:notes:227]
During the three months ended September 27, 2025, our board of directors granted 0.1 million PSUs with an aggregate grant date fair value of $13.7 million to certain executive officers and senior management. These PSUs will vest subject to the achievement of earnings per share targets, as well as service conditions, over three years. The number of shares may be increased or decreased based on the results of these measurement targets ranging between 0% and 200% in accordance with the terms established at the date of grant. In addition, the board of directors also approved a grant of 0.1 million PSUs with an aggregate grant date fair value of $33.0 million to certain executive officers and senior management. These PSUs will vest subject to the achievement of the Company’s total shareholder return (or “TSR”) relative to specified peer group, as well as service conditions, over three years. The number of shares may be increased or decreased based on the results of these measurement targets ranging between 0% and 200% in accordance with the terms established at the date of grant. The Company estimated the grant date fair value of these PSU awards using a Monte-Carlo simulation model, which was calculated at $282.85 per share. Accordingly, stock-based compensation expense related to PSUs are categorized as AIP PSUs, TSR PSUs and Other PSUs. AIP PSUs relates to the shares granted to executive and non-executive employees as part of our Annual Incentive Plan (“AIP PSUs”) during fiscal year 2025, which were subject to performance targets and service conditions and vested in August 2025. TSR PSUs relate to shares granted to certain executive officers and senior management, which will vest subject to the achievement of the Company’s TSR relative to specified peer group while Other PSUs relate to shares granted to certain executive officers and senior management, which are subject to financial performance targets (such as Revenue and EPS) and service conditions. Refer to the table below for a presentation of stock-based compensation expense by equity awards for more details.

[0001628280-25-049073:notes:228]
[same as prior period, unchanged from 0001628280-25-022788:notes:235]

[0001628280-25-049073:notes:229]
Our ESPP provides eligible employees with the opportunity to acquire an ownership interest in the Company through periodic payroll deductions and provides a 15% purchase price discount as well as a 6-month look-back period. The ESPP is structured as a qualified employee stock purchase plan under Section 423 of the Internal Revenue Code of 1986, as amended. The ESPP will terminate upon the date on which all shares available for issuance have been sold. We estimate the fair value of the ESPP shares on the date of grant using the Black-Scholes option-pricing model. Of the 3.0 million shares authorized under the ESPP, 0.4 million shares remained available for issuance as of September 27, 2025.

[0001628280-25-049073:notes:230]
[same as prior period, unchanged from 0001628280-25-022788:notes:237]

[0001628280-25-049073:notes:231]
[same as prior period, unchanged from 0001628280-25-022788:notes:238]

[0001628280-25-049073:notes:232]
|  | Three Months Ended |  |  |
|  | September 27, 2025 |  | September 28, 2024 |  |  |  |  |
| Cost of sales | $ | 8.5 |  |  | $ | 9.7 |  |  |  |  |  |
| Research and development | 10.3 |  |  | 9.3 |  |  |  |  |  |
| Selling, general and administrative | 23.6 |  |  | 16.6 |  |  |  |  |  |
| Total stock-based compensation | $ | 42.4 |  |  | $ | 35.6 |  |  |  |  |  |

[0001628280-25-049073:notes:233]
[same as prior period, unchanged from 0001628280-25-022788:notes:240]

[0001628280-25-049073:notes:234]
|  | Three Months Ended |  |  |
|  | September 27, 2025 |  | September 28, 2024 |  |  |  |  |
| RSUs | $ | 25.6 |  |  | $ | 24.0 |  |  |  |  |  |
| AIP PSUs | 4.8 |  |  | 4.1 |  |  |  |  |  |
| TSR PSUs | 2.9 |  |  | 0.2 |  |  |  |  |  |
| Other PSUs | 9.9 |  |  | 3.0 |  |  |  |  |  |
| Total PSUs | 17.6 |  |  | 7.3 |  |  |  |  |  |
| Options | 1.6 |  |  | 1.3 |  |  |  |  |  |
| ESPP | 1.6 |  |  | 1.2 |  |  |  |  |  |
| Sub-total | 46.4 |  |  | 33.8 |  |  |  |  |  |
| Change in stock-based compensation capitalized to inventory | (4.0) |  |  | 1.8 |  |  |  |  |  |
| Total stock-based compensation | $ | 42.4 |  |  | $ | 35.6 |  |  |  |  |  |

[0001628280-25-049073:notes:235]
During the three months ended September 27, 2025 and September 28, 2024, we recorded $17.6 million and $7.3 million of stock-based compensation related to PSUs, respectively. The amount of stock-based compensation expense recognized in any one period related to PSUs with performance-based conditions can vary based on the achievement or anticipated achievement of the performance conditions. If the performance conditions are not met or not expected to be met, no compensation expense would be recognized on the underlying PSUs, and any previously recognized compensation expense related to those PSUs would be reversed.

[0001628280-25-049073:notes:236]
[same as prior period, unchanged from 0001628280-25-022788:notes:244]

[0001628280-25-049073:notes:237]
|  | Three Months Ended |  |  |
|  | September 27, 2025 |  | September 28, 2024 |  |  |  |  |
| Income tax benefit associated with stock-based compensation | $ | 8.0 |  |  | $ | 1.4 |  |  |  |  |  |

[0001628280-25-049073:notes:238]
Approximately $18.6 million and $14.6 million of stock-based compensation was capitalized to inventory as of September 27, 2025 and June 28, 2025, respectively.

[0001628280-25-049073:notes:239]
The table below summarizes the unrecognized stock-based compensation cost related to unvested shares and the weighted-average period over which it is expected to be recognized as of September 27, 2025:

[0001628280-25-049073:notes:240]
|  | Unrecognized stock-based compensation (in millions) |  | Weighted-average period(in years) |
| RSUs | $ | 197.7 |  |  | 2.1 |
| PSUs | 102.7 |  |  | 2.6 |
| Stock options | 4.8 |  |  | 1.1 |
| ESPP | 0.9 |  |  | 0.1 |

[0001628280-25-049073:notes:241]
[same as prior period, unchanged from 0001628280-25-022788:notes:248]

[0001628280-25-049073:notes:242]
The following table summarizes our award activities for the three months ended September 27, 2025 (in millions):

[0001628280-25-049073:notes:243]
|  | Stock Options |  | Restricted Stock Units |  | Performance Stock Units |  |  |  |  |
|  | Number of Shares |  | Weighted-Average Exercise Price per Share |  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |  |  |  |  |
| Balance as of June 28, 2025 | 0.6 |  |  | $ | 8.1 |  |  | 2.6 |  |  | $ | 59.9 |  |  | 1.6 |  |  | $ | 61.0 |  |  |  |  |  |
| Granted | — |  |  | — |  |  | 1.0 |  |  | 118.6 |  |  | 0.2 |  |  | 118.0 |  |  |  |  |  |
| Vested/Exercised | (0.2) |  |  | 7.9 |  |  | (0.7) |  |  | 60.9 |  |  | (0.7) |  |  | 57.8 |  |  |  |  |  |
| Canceled | — |  |  | — |  |  | (0.1) |  |  | 61.2 |  |  | (0.1) |  |  | 87.1 |  |  |  |  |  |
| Balance as of September 27, 2025 | 0.4 |  |  | $ | 8.1 |  |  | 2.8 |  |  | $ | 79.4 |  |  | 1.0 |  |  | $ | 75.3 |  |  |  |  |  |

[0001628280-25-049073:notes:244]
[same as prior period, unchanged from 0001628280-25-022788:notes:251]

[0001628280-25-049073:notes:245]
|  | Awards Available for Grant |
| Balance as of June 28, 2025 | 2.6 |  |
| Granted | (1.2) |  |
| Canceled | 0.2 |  |
| Balance as of September 27, 2025 | 1.6 |  |

[0001628280-25-049073:notes:246]
[same as prior period, unchanged from 0001628280-25-022788:notes:253]

[0001628280-25-049073:notes:247]
The ESPP expense for the three months ended September 27, 2025 and September 28, 2024 was $1.6 million and $1.2 million, respectively. The expense related to the ESPP is recorded on a straight-line basis over the relevant subscription period.

[0001628280-25-049073:notes:248]
During the three months ended September 27, 2025 and September 28, 2024, there were no shares issued to employees through the ESPP.


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0001628280-25-049073:notes:249]
Note 13. Commitments and Contingencies

[0001628280-25-049073:notes:250]
Purchase Obligations

[0001628280-25-049073:notes:251]
Our purchase obligations of $875.3 million as of September 27, 2025 represent legally binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule and adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

[0001628280-25-049073:notes:252]
We depend on a limited number of contract manufacturers, subcontractors and suppliers for raw materials, packages and standard components. We generally purchase these single or limited source products through standard purchase orders or one-year supply agreements and have no significant long-term guaranteed supply agreements with these vendors. While we seek to maintain a sufficient safety stock of such products and maintain on-going communications with our suppliers to guard against interruptions or cessation of supply, our business and results of operations could be adversely affected by a stoppage or delay of supply, substitution of more expensive or less reliable products, receipt of defective parts or contaminated materials, increases in the price of such supplies, or our inability to obtain reduced pricing from our suppliers in response to competitive pressures. In addition, the imposition of tariffs on certain imported goods and materials may increase our costs and place upward pressure on the cost of sales.

[0001628280-25-049073:notes:253]
Product Warranties

[0001628280-25-049073:notes:254]
We provide reserves for the estimated costs of product warranties at the time revenue is recognized. We typically offer a twelve-month warranty for most of our products. However, in some instances depending upon the product, product components or application of our products by the end customer, our warranties can vary and generally range from six months to five years. We estimate the costs of our warranty obligations on an annualized basis based on our historical experience of known product failure rates, use of materials to repair or replace defective products, and service delivery costs incurred in correcting product failures. In addition, from time-to-time, specific warranty accruals may be made if unforeseen technical problems arise with specific products. We assess the adequacy of our recorded warranty liabilities and adjust the amounts as necessary.

[0001628280-25-049073:notes:255]
The following table presents the changes in our warranty reserve for the periods presented (in millions):

[0001628280-25-049073:notes:256]
|  | Three Months Ended |  |  |
|  | September 27, 2025 |  | September 28, 2024 |  |  |  |  |
| Balance as of beginning of period | $ | 14.4 |  |  | $ | 13.2 |  |  |  |  |  |
| Measurement period adjustment | — |  |  | 0.8 |  |  |  |  |  |
| Provision for warranty | 2.8 |  |  | 2.4 |  |  |  |  |  |
| Utilization of reserve, net | (4.1) |  |  | (3.2) |  |  |  |  |  |
| Balance as of end of period | $ | 13.1 |  |  | $ | 13.2 |  |  |  |  |  |

[0001628280-25-049073:notes:257]
Environmental Liabilities

[0001628280-25-049073:notes:258]
Our research and development, manufacturing and distribution operations involve the use of hazardous substances and are regulated under international, federal, state and local laws governing health and safety and the environment. We apply strict standards for protection of the environment and occupational health and safety to sites inside and outside the United States, even if not subject to regulations imposed by foreign governments. We believe that our properties and operations at our facilities comply in all material respects with applicable environmental laws and occupational health and safety laws. However, the risk of environmental liabilities cannot be completely eliminated and there can be no assurance that the application of environmental and health and safety laws will not require us to incur significant expenditures. We are also regulated under a number of international, federal, state and local laws regarding recycling, product packaging and product content requirements. The environmental and product content/disposal and recycling laws are gradually becoming more stringent and may cause us to incur significant expenditures in the future.

[0001628280-25-049073:notes:259]
Legal Proceedings

[0001628280-25-049073:notes:260]
We are subject to a variety of claims and suits that arise from time-to-time in the ordinary course of our business. While management currently believes that resolving claims against us, individually or in the aggregate, will not have a material adverse impact on our financial position, results of operations or statements of cash flows, these matters are subject to inherent uncertainties and management’s view of these matters may change in the future. We accrue for loss contingencies when it is both probable that we will incur the loss and when we can reasonably estimate the amount of the loss or range of loss. As of September 27, 2025, the accrual for expected settlement of litigation matters was not material.

[0001628280-25-049073:notes:261]
Regulatory Matters

[0001628280-25-049073:notes:262]
In August 2024, the Company received inquiries from the Bureau of Industry and Security of the U.S. Department of Commerce (“BIS”) and Department of Justice (“DOJ”) following the Company’s voluntary disclosure to BIS in December 2023, and supplemented in April 2024. The Company continues to cooperate with both agencies on this matter.  The Company is unable to predict the likely outcome of these matters.

[0001628280-25-049073:notes:263]
Indemnifications

[0001628280-25-049073:notes:264]
In the normal course of business, we enter into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown, because claims may be made against us in the future, and we may record charges in the future as a result of these indemnification obligations.

[0001628280-25-049073:notes:265]
On March 5, 2025, we completed a sale of net assets located in an entity in Shenzhen, China.  The Company has reclassified a $21.4 million unrecognized tax position to other non-current liabilities in the condensed consolidated balance sheets as of June 28, 2025 for an indemnification liability related to the sale of certain assets. This does not impact our results of operations for the year ended June 28, 2025. We did not have any other material indemnification claims that were probable or reasonably possible.

[0001628280-25-049073:notes:266]
On November 7, 2023, we completed the acquisition of Cloud Light. In accordance with the Merger Agreement, cash consideration included $75.8 million of cash held in an escrow fund to support Cloud Light’s indemnification obligations and customary adjustment for working capital.  Since the measurement period expired, any future adjustments will be included in our earnings. No amount of escrow funds have been released as the parties have not mutually agreed on the indemnification obligation and working capital adjustment.

[0001628280-25-049073:notes:267]
Audit Proceedings

[0001628280-25-049073:notes:268]
We are under audit by various domestic and foreign tax authorities with regards to income tax and indirect tax matters. In some, although not all cases, we have reserved for potential adjustments to our provision for income taxes and accrual of indirect taxes that may result from examinations by these tax authorities or final outcomes in judicial proceedings, and we believe that the final outcome of these examinations, agreements or judicial proceedings will not have a material effect on our results of operations. If events occur which indicate payment of these amounts is unnecessary, the reversal of the liabilities would result in the recognition of benefits in the period when we determine the liabilities are no longer necessary. If our estimates of the federal, state, and foreign income tax liabilities and indirect tax liabilities are less than the ultimate assessment, it could result in a further charge to expense.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001628280-25-049073:notes:269]
Note 14. Operating Segments and Geographic Information

[0001628280-25-049073:notes:270]
Prior to fiscal year 2026, we operated in two reportable segments consisting of Cloud & Networking and Industrial Tech. During the first quarter of fiscal year 2026, the Company implemented a re-organization, under which it will be managed as a single, integrated enterprise, with a unified management team overseeing operations across the entire company, rather than through discrete operating segments. The chief operating decision maker (“CODM”) is the Company’s Chief Executive Officer, who reviews financial information presented as a single enterprise for purposes of allocating resources and evaluating financial performance.

[0001628280-25-049073:notes:271]
The CODM assesses the performance of the single segment and allocates resources based on consolidated net income (loss) included in the Company’s condensed consolidated statements of operations. The CODM uses consolidated net income to set budgets, evaluate performance, review actual results and in deciding whether to reinvest profits into our business, pursue acquisitions, or make any other capital management decisions. The significant segment expenses are reflected in the Company’s condensed consolidated statements of operations and the condensed consolidated statements of cash flows. The measure of the single segment assets is the consolidated assets included in the condensed consolidated balance sheets. Accordingly, we determined we operate in a single reporting segment. Comparative prior period segment information has been updated to reflect the new segment structure and measures. The changes in our operating segments had no impact on our previously reported consolidated results of operations, financial position or cash flows.

[0001628280-25-049073:notes:272]
Refer to “Note 15. Revenue Recognition” for a presentation of disaggregated revenue by type of product.

[0001628280-25-049073:notes:273]
[same as prior period, unchanged from 0001628280-25-022788:notes:298]

[0001628280-25-049073:notes:274]
[same as prior period, unchanged from 0001628280-25-022788:notes:299]

[0001628280-25-049073:notes:275]
[same as prior period, unchanged from 0001628280-25-022788:notes:300]

[0001628280-25-049073:notes:276]
|  | Three Months Ended |  |  |
|  | September 27, 2025 |  | September 28, 2024 |  |  |  |  |
|  | Amount |  | % of Total |  | Amount |  | % of Total |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States | $ | 93.7 |  |  | 17.6 | % |  | $ | 65.4 |  |  | 19.4 | % |  |  |  |  |  |  |  |  |
| Mexico | 73.6 |  |  | 13.8 |  |  | 33.9 |  |  | 10.0 |  |  |  |  |  |  |  |  |  |
| Other Americas | 8.6 |  |  | 1.6 |  |  | 2.9 |  |  | 0.9 |  |  |  |  |  |  |  |  |  |
| Total Americas | $ | 175.9 |  |  | 33.0 | % |  | $ | 102.2 |  |  | 30.3 | % |  |  |  |  |  |  |  |  |
| Asia-Pacific: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Hong Kong | $ | 92.9 |  |  | 17.4 | % |  | $ | 88.7 |  |  | 26.4 | % |  |  |  |  |  |  |  |  |
| Thailand | 109.1 |  |  | 20.4 |  |  | 52.5 |  |  | 15.6 |  |  |  |  |  |  |  |  |  |
| China | 49.3 |  |  | 9.2 |  |  | 14.6 |  |  | 4.3 |  |  |  |  |  |  |  |  |  |
| Japan | 21.0 |  |  | 3.9 |  |  | 16.9 |  |  | 5.0 |  |  |  |  |  |  |  |  |  |
| Other Asia-Pacific | 49.4 |  |  | 9.3 |  |  | 31.4 |  |  | 9.3 |  |  |  |  |  |  |  |  |  |
| Total Asia-Pacific | $ | 321.7 |  |  | 60.2 | % |  | $ | 204.1 |  |  | 60.6 | % |  |  |  |  |  |  |  |  |
| EMEA | $ | 36.2 |  |  | 6.8 | % |  | $ | 30.6 |  |  | 9.1 | % |  |  |  |  |  |  |  |  |
| Total net revenue | $ | 533.8 |  |  | 100.0 | % |  | $ | 336.9 |  |  | 100.0 | % |  |  |  |  |  |  |  |  |

[0001628280-25-049073:notes:277]
During the three months ended September 27, 2025, two customers individually accounted for 22%, and 21% of our total revenue, respectively. During the three months ended September 28, 2024, two customers individually accounted for 15% and 12% of our total revenue, respectively.

[0001628280-25-049073:notes:278]
As of September 27, 2025, three customers individually accounted for 16%, 14% and 10% of gross accounts receivable, respectively. As of June 28, 2025, two customers individually accounted for 13% and 11% of gross accounts receivable, respectively. We had no other customers that represented 10% or greater of our gross accounts receivable.

[0001628280-25-049073:notes:279]
The measure of segment assets is reported on the condensed consolidated balance sheets as total assets. We do not present assets at a level other than that presented in the accompanying condensed consolidated balance sheets. Long-lived assets, namely property, plant and equipment, net, were identified based on the physical location of the assets in the corresponding geographic areas as of the periods indicated (in millions):

[0001628280-25-049073:notes:280]
|  | September 27, 2025 |  | June 28, 2025 |
| Property, plant and equipment, net |  |  |  |
| United States | $ | 124.8 |  |  | $ | 123.0 |  |
| Thailand | 240.4 |  |  | 218.6 |  |
| Japan | 164.5 |  |  | 144.3 |  |
| United Kingdom | 119.1 |  |  | 109.4 |  |
| China | 90.9 |  |  | 76.8 |  |
| Other countries | 55.1 |  |  | 54.3 |  |
| Total property, plant and equipment, net | $ | 794.8 |  |  | $ | 726.4 |  |

[0001628280-25-049073:notes:281]
We purchase a portion of our inventory from contract manufacturers that are located primarily in Thailand, Taiwan, and Malaysia. During the three months ended September 27, 2025, our net inventory purchases from a single contract manufacturer that represented 10% or greater of our total net inventory purchases were concentrated with one contract manufacturer, who accounted for 20% of the total net inventory purchases. During the three months ended September 28, 2024, our net inventory purchases from a single contract manufacturer that represented 10% or greater of our total net inventory purchases were concentrated with one contract manufacturer, who accounted for 27% of the total net inventory purchases.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001628280-25-049073:notes:282]
Note 15. Revenue Recognition

[0001628280-25-049073:notes:283]
[same as prior period, unchanged from 0001628280-25-022788:notes:309]

[0001628280-25-049073:notes:284]
We disaggregate revenue by type of products and by geography. We do not present other levels of disaggregation, such as by customer, markets, contracts, duration of contracts, timing of transfer of control and sales channels, as this information is not used by our CODM to manage the business.

[0001628280-25-049073:notes:285]
The table below discloses our total net revenue by type of product (in millions, except percentage data):

[0001628280-25-049073:notes:286]
|  | Three Months Ended |  |  |
|  | September 27, 2025 |  | September 28, 2024 |  |  |  |  |
|  | Amount |  | % of Total |  | Amount |  | % of Total |  |  |  |  |  |  |  |  |
| Components | 379.2 |  |  | 71.0 | % |  | 231.4 |  |  | 68.7 | % |  |  |  |  |  |  |  |  |
| Systems | 154.6 |  |  | 29.0 | % |  | 105.5 |  |  | 31.3 | % |  |  |  |  |  |  |  |  |
| Net revenue | $ | 533.8 |  |  | 100.0 | % |  | $ | 336.9 |  |  | 100.0 | % |  |  |  |  |  |  |  |  |

[0001628280-25-049073:notes:287]
Refer to “Note 14. Operating Segments and Geographic Information” for a presentation of disaggregated revenue by geography.

[0001628280-25-049073:notes:288]
[same as prior period, unchanged from 0001628280-25-022788:notes:313]

[0001628280-25-049073:notes:289]
We record accounts receivable when we have an unconditional right to consideration. Contract liabilities are recorded when cash payments are received or due in advance of performance. Contract liabilities consist of advance payments and deferred revenue, where we have unsatisfied performance obligations. Contract liabilities are classified as deferred revenue and customer deposits and are included in other current liabilities within our condensed consolidated balance sheets. Payment terms vary by customer. The time between invoicing and when payment is due is not significant.

[0001628280-25-049073:notes:290]
[same as prior period, unchanged from 0001628280-25-022788:notes:314]

[0001628280-25-049073:notes:291]
| Contract balances |  | Balance sheet location |  | September 27, 2025 |  | June 28, 2025 |  | Change |  | Percentage Change |
| Accounts receivable, net |  | Accounts receivable, net |  | $ | 307.0 |  |  | $ | 250.0 |  |  | $ | 57.0 |  |  | 22.8 | % |
| Deferred revenue and customer deposits |  | Other current liabilities |  | $ | 2.7 |  |  | $ | 0.7 |  |  | $ | 2.0 |  |  | 285.7 | % |
