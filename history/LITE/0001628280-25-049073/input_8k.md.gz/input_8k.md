# LITE 8-K — 0001628280-25-048860 filed 2025-11-04

## item codes, every 8-K on or before 2025-11-05

- 2025-11-04 0001628280-25-048860 — 2.02, 9.01
- 2025-09-08 0001193125-25-198329 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2025-08-12 0001628280-25-039896 — 2.02, 9.01
- 2025-06-03 0001628280-25-029086 — 7.01, 9.01
- 2025-05-06 0001628280-25-022709 — 2.02, 9.01
- 2025-02-06 0001628280-25-004265 — 2.02, 9.01
- 2025-02-03 0001193125-25-019371 — 2.02, 5.02, 9.01
- 2024-12-12 0001193125-24-277338 — 5.02, 9.01
- 2024-11-22 0001628280-24-048886 — 5.02, 5.07, 9.01
- 2024-11-07 0001628280-24-046302 — 2.02, 9.01
- 2024-08-21 0001628280-24-037938 — 2.02, 9.01 — amendment of 0001628280-24-037191
- 2024-08-14 0001628280-24-037191 — 2.02, 9.01
- 2024-05-06 0001628280-24-020640 — 2.02, 9.01
- 2024-02-27 0001628280-24-006936 — 5.02
- 2024-02-08 0001628280-24-003789 — 2.02, 9.01
- 2024-01-18 0001628280-24-001551 — 9.01 — amendment of 0001193125-23-272452
- 2023-11-21 0001628280-23-039654 — 5.02, 5.07
- 2023-11-08 0001628280-23-037563 — 2.02, 9.01
- 2023-11-07 0001193125-23-272452 — 2.01, 8.01, 9.01
- 2023-10-30 0001193125-23-265658 — 1.01, 2.02, 9.01
- 2023-08-17 0001628280-23-029741 — 2.02, 9.01
- 2023-06-16 0001193125-23-168966 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2023-05-09 0001628280-23-016629 — 2.02, 9.01
- 2023-04-06 0001628280-23-010935 — 2.02, 8.01, 9.01
- 2023-02-24 0001193125-23-048742 — 5.02, 9.01
- 2023-02-09 0001628280-23-002866 — 2.02, 9.01
- 2022-11-21 0001628280-22-030473 — 5.02, 5.07, 9.01
- 2022-11-08 0001628280-22-028758 — 2.02, 9.01
- 2022-08-16 0001628280-22-022980 — 2.02, 9.01
- 2022-08-03 0001193125-22-210674 — 2.01, 8.01, 9.01
- 2022-07-29 0001193125-22-206587 — 8.01, 9.01
- 2022-05-04 0001628280-22-012145 — 2.02, 9.01
- 2022-03-08 0001193125-22-069350 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2022-02-03 0001628280-22-001736 — 2.02, 9.01
- 2022-01-21 0001193125-22-014413 — 8.01, 9.01
- 2021-11-23 0001628280-21-024070 — 5.02, 5.07
- 2021-11-05 0001193125-21-321796 — 1.01, 9.01
- 2021-11-04 0001628280-21-021618 — 2.02, 9.01
- 2021-11-04 0001193125-21-319601 — 8.01, 9.01
- 2021-08-18 0001628280-21-017219 — 2.02, 9.01
- 2021-06-08 0001633978-21-000030 — 5.02, 9.01
- 2021-05-12 0001633978-21-000008 — 2.02, 9.01
- 2021-03-10 0001193125-21-075438 — 1.01, 8.01, 9.01
- 2021-02-02 0001633978-21-000002 — 2.02, 9.01
- 2021-01-19 0001104659-21-005024 — 1.01, 2.02, 8.01, 9.01
- 2020-11-24 0001193125-20-302557 — 5.02, 5.07
- 2020-11-02 0001633978-20-000017 — 2.02, 9.01
- 2020-09-18 0001633978-20-000012 — 5.02, 9.01
- 2020-08-11 0001633978-20-000010 — 2.02, 9.01
- 2020-05-05 0001628280-20-006358 — 2.02, 9.01
- 2020-02-04 0001633978-20-000002 — 2.02, 9.01
- 2019-12-12 0001193125-19-312875 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2019-12-04 0001633978-19-000075 — 8.01
- 2019-11-20 0001633978-19-000074 — 5.07
- 2019-10-31 0001633978-19-000070 — 2.02, 9.01
- 2019-08-08 0001633978-19-000068 — 2.02, 9.01
- 2019-05-08 0001633978-19-000031 — 1.01
- 2019-05-07 0001633978-19-000029 — 2.02, 9.01
- 2019-02-15 0001633978-19-000005 — 9.01 — amendment of 0001193125-18-346211
- 2019-02-08 0001193125-19-031591 — 5.02, 9.01
- 2019-02-05 0001633978-19-000001 — 2.02, 9.01
- 2018-12-10 0001193125-18-346211 — 1.01, 2.01, 2.03, 5.02, 8.01, 9.01
- 2018-12-06 0001633978-18-000150 — 8.01
- 2018-11-14 0001633978-18-000139 — 5.07
- 2018-11-13 0001633978-18-000136 — 3.02
- 2018-11-13 0001633978-18-000132 — 7.01, 9.01
- 2018-11-01 0001628280-18-013238 — 2.02, 9.01
- 2018-08-08 0001633978-18-000056 — 2.02, 9.01
- 2018-06-08 0001193125-18-188241 — 5.02, 9.01
- 2018-05-02 0001633978-18-000029 — 2.02, 9.01
- 2018-03-12 0001193125-18-078154 — 1.01, 2.01, 8.01, 9.01
- 2018-02-06 0001628280-18-001082 — 2.02, 9.01
- 2017-11-08 0001633978-17-000133 — 5.02, 9.01
- 2017-11-07 0001633978-17-000131 — 5.07
- 2017-11-01 0001633978-17-000117 — 2.02, 9.01
- 2017-08-09 0001633978-17-000058 — 2.02, 9.01
- 2017-05-04 0001633978-17-000035 — 2.02, 9.01
- 2017-03-08 0001193125-17-074740 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2017-03-02 0001193125-17-066769 — 8.01, 9.01
- 2017-02-07 0001633978-17-000005 — 2.02, 9.01
- 2017-01-03 0001628280-17-000018 — 4.01, 9.01
- 2016-11-09 0001628280-16-021143 — 5.02, 5.07, 9.01
- 2016-10-27 0001628280-16-020382 — 2.02, 9.01
- 2016-08-09 0001628280-16-018811 — 2.02, 9.01
- 2016-06-21 0001628280-16-017201 — 8.01
- 2016-05-04 0001628280-16-015501 — 2.02, 9.01
- 2016-02-16 0001628280-16-011261 — 5.02, 9.01
- 2016-02-04 0001628280-16-010758 — 5.02, 9.01
- 2016-02-04 0001628280-16-010755 — 2.02, 9.01
- 2015-11-17 0001193125-15-378953 — 7.01
- 2015-11-10 0001628280-15-008606 — 2.02, 9.01
- 2015-09-28 0001193125-15-329665 — 8.01, 9.01
- 2015-08-11 0001193125-15-286405 — 7.01, 9.01
- 2015-08-06 0001193125-15-281219 — 1.01, 5.02, 5.03, 5.05, 8.01, 9.01
- 2015-08-03 0001193125-15-274808 — 5.03, 9.01

## late-filing notifications on or before 2025-11-05

- 2015-11-10 0001628280-15-008612 — NT 10-Q, for the period ended 2015-09-26
- 2015-09-28 0001193125-15-329672 — NT 10-K, for the period ended 2015-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001628280-25-048860:8k_2_02:1]
EX-99.1
2
lite_ex991xq1fy26.htm
EX-99.1

[0001628280-25-048860:8k_2_02:2]
Document

[0001628280-25-048860:8k_2_02:3]
NEWS RELEASE

[0001628280-25-048860:8k_2_02:4]
LUMENTUM ANNOUNCES FIRST QUARTER OF FISCAL YEAR 2026 FINANCIAL RESULTS

[0001628280-25-048860:8k_2_02:5]
•Net revenue of $533.8 million

[0001628280-25-048860:8k_2_02:6]
•GAAP gross margin of 34.0%; Non-GAAP gross margin of 39.4%

[0001628280-25-048860:8k_2_02:7]
•GAAP operating margin of 1.3%; Non-GAAP operating margin of 18.7%

[0001628280-25-048860:8k_2_02:8]
•GAAP diluted net income per share of $0.05; Non-GAAP diluted net income per share of $1.10

[0001628280-25-048860:8k_2_02:9]
San Jose, Calif., November 4, 2025 – Lumentum Holdings Inc. (“Lumentum” or the “Company”) today reported results for its fiscal first quarter ended September 27, 2025.

[0001628280-25-048860:8k_2_02:10]
“In our fiscal first quarter, we saw year-over-year revenue growth of 58 percent and operating margin expansion of over 1,500 basis points on a non-GAAP basis.  Revenue, operating margin, and earnings per share all came in at the high end of our guidance ranges,” said Michael Hurlston, Lumentum President and CEO.

[0001628280-25-048860:8k_2_02:11]
“Our first-quarter results and forward guidance underscore our strong momentum across data center, data center interconnect, and long-haul markets. Our guidance indicates we expect more than 20 percent sequential revenue growth, even before meaningful contributions from two of our next major growth engines—optical circuit switches and co-packaged optics.  Our third driver, cloud transceivers, is expected to grow in our second quarter and should now be on a sustainable upward path.  With our broad optical portfolio, we are well positioned to support the rapid expansion of AI compute.”

[0001628280-25-048860:8k_2_02:12]
Fiscal First Quarter Highlights:

[0001628280-25-048860:8k_2_02:13]
Net revenue for the first quarter of fiscal year 2026 was $533.8 million, with GAAP net income of $4.2 million, or $0.05 per diluted share. Net revenue for the fourth quarter of fiscal year 2025 was $480.7 million, with GAAP net income of $213.3 million, or $2.96 per diluted share. Net revenue for the first quarter of fiscal year 2025 was $336.9 million, with GAAP net loss of $82.4 million, or $1.21 per diluted share.

[0001628280-25-048860:8k_2_02:14]
Non-GAAP net income for the first quarter of fiscal year 2026 was $86.4 million, or $1.10 per diluted share. Non-GAAP net income for the fourth quarter of fiscal year 2025 was $63.3 million, or $0.88 per diluted share. Non-GAAP net income for the first quarter of fiscal year 2025 was $12.2 million, or $0.18 per diluted share.

[0001628280-25-048860:8k_2_02:15]
The Company held $1,121.8 million in total cash, cash equivalents, and short-term investments at the end of the first quarter of fiscal year 2026, up $244.7 million from the end of the fourth quarter of fiscal year 2025.

[0001628280-25-048860:8k_2_02:16]
Financial Overview – Fiscal First Quarter Ended September 27, 2025

[0001628280-25-048860:8k_2_02:17]
|  | GAAP Results ($ in millions) |
|  | Q1 |  | Q4 |  | Q1 |  | Change |
|  | FY 2026 |  | FY 2025 |  | FY 2025 |  | Q/Q |  | Y/Y |
| Net revenue | $ | 533.8 |  |  | $ | 480.7 |  |  | $ | 336.9 |  |  | 11.0% |  | 58.4% |
| GAAP gross margin | 34.0 | % |  | 33.3 | % |  | 23.1 | % |  | 70 | bps |  | 1,090 | bps |
| GAAP operating margin (loss) | 1.3 | % |  | (1.7) | % |  | (24.5) | % |  | 300 | bps |  | 2,580 | bps |
|  | Non-GAAP Results ($ in millions) |
|  | Q1 |  | Q4 |  | Q1 |  | Change |
|  | FY 2026 |  | FY 2025 |  | FY 2025 (1) |  | Q/Q |  | Y/Y |
| Net revenue | $ | 533.8 |  |  | $ | 480.7 |  |  | $ | 336.9 |  |  | 11.0% |  | 58.4% |
| Non-GAAP gross margin | 39.4 | % |  | 37.8 | % |  | 32.8 | % |  | 160 | bps |  | 660 | bps |
| Non-GAAP operating margin | 18.7 | % |  | 15.0 | % |  | 3.0 | % |  | 370 | bps |  | 1,570 | bps |

[0001628280-25-048860:8k_2_02:18]
|  | Net Revenue by Product Type ($ in millions) |  |  |  |  |
|  | Q1 |  | % of |  | Q4 |  | Q1 |  | Change |  |  |  |  |
|  | FY 2026 |  | Net Revenue |  | FY 2025 |  | FY 2025 |  | Q/Q |  | Y/Y |  |  |  |  |
| Components | $ | 379.2 |  |  | 71.0 | % |  | $ | 320.3 |  |  | $ | 231.4 |  |  | 18.4% |  | 63.9% |  |  |  |  |
| Systems | 154.6 |  |  | 29.0 | % |  | 160.4 |  |  | 105.5 |  |  | (3.6)% |  | 46.5% |  |  |  |  |
| Total | $ | 533.8 |  |  | 100.0 | % |  | $ | 480.7 |  |  | $ | 336.9 |  |  | 11.0% |  | 58.4% |  |  |  |  |

[0001628280-25-048860:8k_2_02:19]
The tables above provide comparisons of quarterly results to prior periods, including sequential quarterly and year-over-year changes. A reconciliation between GAAP and non-GAAP measures is contained in this release under the section titled “Use of Non-GAAP Financial Measures.”

[0001628280-25-048860:8k_2_02:20]
Business Outlook

[0001628280-25-048860:8k_2_02:21]
Lumentum expects the following for the second quarter of fiscal year 2026:

[0001628280-25-048860:8k_2_02:22]
•Net revenue in the range of $630 million to $670 million

[0001628280-25-048860:8k_2_02:23]
•Non-GAAP operating margin of 20.0% to 22.0%

[0001628280-25-048860:8k_2_02:24]
•Non-GAAP diluted earnings per share of $1.30 to $1.50

[0001628280-25-048860:8k_2_02:25]
We have not provided reconciliations from GAAP to non-GAAP financial measures or the equivalent GAAP measure for non-GAAP financial measures in our outlook, as they cannot be provided without unreasonable effort. A large portion of non-GAAP adjustments, such as stock-based compensation, acquisition related costs, integration related costs, restructuring and related charges, non-GAAP income tax reconciling adjustments, and other costs and contingencies unrelated to current and future operations are by their nature highly volatile and we have low visibility as to the range that may be incurred in the future.

[0001628280-25-048860:8k_2_02:26]
Related Announcement and Conference Call

[0001628280-25-048860:8k_2_02:27]
Lumentum will host a conference call today, November 4, 2025, at 2:00 pm PT / 5:00 pm ET to discuss its first quarter of fiscal year 2026 results. A live webcast of the call and replay will be available in the Investors section of the Lumentum website at http://investor.lumentum.com. The earnings press release will be posted at http://investor.lumentum.com under the “Financial News Releases” section. Supporting materials outlining the Company’s latest financial results will be posted on http://investor.lumentum.com under the “Events and Presentations” section concurrently with this earnings press release. Lumentum has used, and intends to continue to use, its Investor Relations website as means of disclosing material nonpublic information and for complying with its disclosure obligations under Regulation FD. This press release is being furnished as an exhibit to a Current Report on Form 8-K filed with the Securities and Exchange Commission and will be available at http://www.sec.gov/.

[0001628280-25-048860:8k_2_02:28]
About Lumentum

[0001628280-25-048860:8k_2_02:29]
Lumentum (NASDAQ: LITE) is a market-leading designer and manufacturer of innovative optical and photonic products enabling optical networking and laser applications worldwide. Lumentum optical components and subsystems are part of virtually every type of telecom, enterprise, and data center network. Lumentum lasers enable advanced manufacturing techniques and diverse applications including next-generation imaging and sensing capabilities. The Company is headquartered in San Jose, California with R&D, manufacturing, and sales offices worldwide. For more information, visit www.lumentum.com.

[0001628280-25-048860:8k_2_02:30]
Forward-Looking Statements

[0001628280-25-048860:8k_2_02:31]
Contact Information

[0001628280-25-048860:8k_2_02:32]
Investors:    Kathy Ta, +1.408.750.3853; investor.relations@lumentum.com

[0001628280-25-048860:8k_2_02:33]
Media:        Victoria McDonald, +408.404.0636; media@lumentum.com

[0001628280-25-048860:8k_2_02:34]
Category:    Financial

[0001628280-25-048860:8k_2_02:35]
The following financial tables are presented in accordance with GAAP, unless otherwise specified.

[0001628280-25-048860:8k_2_02:36]
LUMENTUM HOLDINGS INC.

[0001628280-25-048860:8k_2_02:37]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001628280-25-048860:8k_2_02:38]
(in millions, except per share data)

[0001628280-25-048860:8k_2_02:39]
(unaudited)

[0001628280-25-048860:8k_2_02:40]
|  | Three Months Ended |  |  |
|  | September 27, 2025 |  | September 28, 2024 |  |  |  |  |
| Net revenue | $ | 533.8 |  |  | $ | 336.9 |  |  |  |  |  |
| Cost of sales | 332.8 |  |  | 236.5 |  |  |  |  |  |
| Amortization of acquired developed intangibles | 19.5 |  |  | 22.5 |  |  |  |  |  |
| Gross profit | 181.5 |  |  | 77.9 |  |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 81.4 |  |  | 74.3 |  |  |  |  |  |
| Selling, general and administrative | 85.1 |  |  | 76.3 |  |  |  |  |  |
| Restructuring and related charges | 8.3 |  |  | 9.7 |  |  |  |  |  |
| Total operating expenses | 174.8 |  |  | 160.3 |  |  |  |  |  |
| Income (loss) from operations | 6.7 |  |  | (82.4) |  |  |  |  |  |
| Other income (expense), net: |  |  |  |  |  |  |  |
| Interest expense | (5.7) |  |  | (5.5) |  |  |  |  |  |
| Other income, net | 4.2 |  |  | 8.7 |  |  |  |  |  |
| Total other income (expense), net | (1.5) |  |  | 3.2 |  |  |  |  |  |
| Income (loss) before income taxes | 5.2 |  |  | (79.2) |  |  |  |  |  |
| Income tax provision | 1.0 |  |  | 3.2 |  |  |  |  |  |
| Net income (loss) | $ | 4.2 |  |  | $ | (82.4) |  |  |  |  |  |
| Net income (loss) per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.06 |  |  | $ | (1.21) |  |  |  |  |  |
| Diluted | $ | 0.05 |  |  | $ | (1.21) |  |  |  |  |  |
| Shares used to compute net income (loss) per share: |  |  |  |  |  |  |  |
| Basic | 70.3 |  |  | 68.3 |  |  |  |  |  |
| Diluted | 78.3 |  |  | 68.3 |  |  |  |  |  |

[0001628280-25-048860:8k_2_02:41]
LUMENTUM HOLDINGS INC.

[0001628280-25-048860:8k_2_02:42]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001628280-25-048860:8k_2_02:43]
(in millions, except per share data)

[0001628280-25-048860:8k_2_02:44]
(unaudited)

[0001628280-25-048860:8k_2_02:45]
|  | September 27, 2025 |  | June 28, 2025 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 772.9 |  |  | $ | 520.7 |  |
| Short-term investments | 348.9 |  |  | 356.4 |  |
| Accounts receivable, net | 307.0 |  |  | 250.0 |  |
| Inventories | 531.6 |  |  | 470.1 |  |
| Prepayments and other current assets | 125.2 |  |  | 120.1 |  |
| Total current assets | 2,085.6 |  |  | 1,717.3 |  |
| Property, plant and equipment, net | 794.8 |  |  | 726.4 |  |
| Operating lease right-of-use assets, net | 30.5 |  |  | 27.9 |  |
| Goodwill | 1,060.9 |  |  | 1,060.9 |  |
| Other intangible assets, net | 430.7 |  |  | 465.1 |  |
| Deferred tax asset | 204.6 |  |  | 210.3 |  |
| Other non-current assets | 6.0 |  |  | 10.8 |  |
| Total assets | $ | 4,613.1 |  |  | $ | 4,218.7 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 278.6 |  |  | $ | 225.2 |  |
| Accrued payroll and related expenses | 69.3 |  |  | 57.9 |  |
| Accrued expenses | 45.5 |  |  | 34.6 |  |
| Current portion of long-term debt | 1,079.0 |  |  | 10.6 |  |
| Operating lease liabilities, current | 12.2 |  |  | 11.4 |  |
| Other current liabilities | 41.6 |  |  | 53.1 |  |
| Total current liabilities | 1,526.2 |  |  | 392.8 |  |
| Long-term debt | 2,164.5 |  |  | 2,562.6 |  |
| Operating lease liabilities, non-current | 24.5 |  |  | 23.6 |  |
| Deferred tax liability | 6.0 |  |  | 7.2 |  |
| Other non-current liabilities | 111.1 |  |  | 97.8 |  |
| Total liabilities | 3,832.3 |  |  | 3,084.0 |  |
| Stockholders’ equity: |  |  |  |
| Common stock, $0.001 par value, 990 authorized shares, 70.9 and 69.8 shares issued and outstanding as of September 27, 2025 and June 28, 2025, respectively | 0.1 |  |  | 0.1 |  |
| Additional paid-in capital | 1,628.6 |  |  | 1,986.8 |  |
| Accumulated deficit | (857.0) |  |  | (861.2) |  |
| Accumulated other comprehensive income | 9.1 |  |  | 9.0 |  |
| Total stockholders’ equity | 780.8 |  |  | 1,134.7 |  |
| Total liabilities and stockholders’ equity | $ | 4,613.1 |  |  | $ | 4,218.7 |  |

[0001628280-25-048860:8k_2_02:46]
Use of Non-GAAP Financial Measures

[0001628280-25-048860:8k_2_02:47]
In this press release, Lumentum provides investors with certain non-GAAP financial measures: gross profit, gross margin, research and development expense, selling, general and administrative expense, operating margin, income (loss) from operations, interest and other income (expense), net, income before income taxes, provision for income taxes, net income (loss), and net income (loss) per share on a non-GAAP basis, as well as the non-GAAP measures of EBITDA and Adjusted EBITDA. Lumentum believes this non-GAAP financial information provides additional insight into the Company’s on-going business operations and results, and has therefore chosen to provide this information to investors for a more consistent basis of comparison and to help them evaluate the results of the Company’s on-going operations and enable more meaningful period to period comparisons. In addition, the Company believes that providing certain of these measures allows investors to better understand the Company’s operating performance and importantly, to evaluate the methodology and information used by management to monitor, manage, evaluate and measure the Company’s business and results of operations. However, investors are cautioned that there are material limitations associated with the use of non-GAAP financial measures as an analytical tool. In particular, many of the adjustments to our GAAP financial measures reflect the exclusion of items that are recurring and will be reflected in our financial results for the foreseeable future. Moreover, the non-GAAP financial measures we present may be different from non-GAAP financial measures used by other companies or may not be comparable to similarly titled measurements reported by other companies, limiting their usefulness for comparison purposes. We do not consider non-GAAP financial measures to be a substitute for, or superior to, the information provided by GAAP financial measures, and the non-GAAP financial measures used in this press release should not be considered in isolation from measures of financial performance prepared in accordance with GAAP.

[0001628280-25-048860:8k_2_02:48]
Our non-GAAP measures used in this press release exclude (i) stock-based compensation and related payroll taxes, (ii) acquisition related costs, (iii) integration related costs, (iv) amortization of acquired intangibles, (v) restructuring and related charges, (vi) foreign exchange (gains) losses, net, (vii) non-cash interest expense on convertible notes, (viii) intangible assets write-off, (ix) inducement expense on partial repurchase of 2026 Notes, (x) non-GAAP income tax reconciling adjustments, and (xi) other charges or income related to non-recurring activities.

[0001628280-25-048860:8k_2_02:49]
We utilize a long-term projected non-GAAP tax rate to compute our non-GAAP income tax provision. The long-term projected non-GAAP tax rate is based on a multi-year projection of our estimated annual GAAP income tax forecast, adjusted to account for the tax effect of non-GAAP pretax adjustments as well as the effects of significant non-recurring and period specific tax items. Our non-GAAP tax provision for fiscal year 2026 is 16.5%. The difference between our GAAP income tax provision and our non-GAAP income tax provision is presented as non-GAAP income tax reconciling adjustments.

[0001628280-25-048860:8k_2_02:50]
A quantitative reconciliation between GAAP and non-GAAP financial data with respect to historical periods is included in the supplemental financial table attached to this press release.

[0001628280-25-048860:8k_2_02:51]
LUMENTUM HOLDINGS INC.

[0001628280-25-048860:8k_2_02:52]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001628280-25-048860:8k_2_02:53]
(in millions, except per share data)

[0001628280-25-048860:8k_2_02:54]
(unaudited)

[0001628280-25-048860:8k_2_02:55]
|  | Three Months Ended |  |  |  |
|  | September 27, 2025 |  | June 28, 2025 |  | September 28, 2024 |  |  |  |  |  |
| Gross profit on GAAP basis | $ | 181.5 |  |  | $ | 159.9 |  |  | $ | 77.9 |  |  |  |  |  |  |
| Stock-based compensation and related payroll taxes (1) | 9.7 |  |  | 8.8 |  |  | 9.7 |  |  |  |  |  |  |
| Amortization of acquired intangibles | 19.5 |  |  | 19.3 |  |  | 22.5 |  |  |  |  |  |  |
| Integration related costs | — |  |  | 0.6 |  |  | 1.2 |  |  |  |  |  |  |
| Other charges (income), net | (0.4) |  |  | (7.0) |  |  | (0.9) |  |  |  |  |  |  |
| Gross profit on non-GAAP basis | $ | 210.3 |  |  | $ | 181.6 |  |  | $ | 110.4 |  |  |  |  |  |  |
| Gross margin on non-GAAP basis | 39.4 | % |  | 37.8 | % |  | 32.8 | % |  |  |  |  |  |
| Research and development on GAAP basis | $ | 81.4 |  |  | $ | 79.5 |  |  | $ | 74.3 |  |  |  |  |  |  |
| Stock-based compensation and related payroll taxes (1) | (12.0) |  |  | (11.4) |  |  | (9.3) |  |  |  |  |  |  |
| Amortization of acquired intangibles | (0.4) |  |  | (0.4) |  |  | (0.4) |  |  |  |  |  |  |
| Intangible asset write-off | — |  |  | (0.1) |  |  | (1.9) |  |  |  |  |  |  |
| Research and development on non-GAAP basis | $ | 69.0 |  |  | $ | 67.6 |  |  | $ | 62.7 |  |  |  |  |  |  |
| Selling, general and administrative on GAAP basis | $ | 85.1 |  |  | $ | 83.6 |  |  | $ | 76.3 |  |  |  |  |  |  |
| Stock-based compensation and related payroll taxes (1) | (24.8) |  |  | (19.8) |  |  | (16.6) |  |  |  |  |  |  |
| Amortization of acquired intangibles | (14.5) |  |  | (14.9) |  |  | (18.8) |  |  |  |  |  |  |
| Acquisition related costs | (1.3) |  |  | (0.7) |  |  | — |  |  |  |  |  |  |
| Integration related costs | 0.8 |  |  | (0.7) |  |  | (2.2) |  |  |  |  |  |  |
| Other charges (income), net (4) | (3.8) |  |  | (5.8) |  |  | (1.0) |  |  |  |  |  |  |
| Selling, general and administrative on non-GAAP basis | $ | 41.5 |  |  | $ | 41.7 |  |  | $ | 37.7 |  |  |  |  |  |  |
| Income (loss) from operations on GAAP basis | $ | 6.7 |  |  | $ | (8.4) |  |  | $ | (82.4) |  |  |  |  |  |  |
| Stock-based compensation and related payroll taxes (1) | 46.5 |  |  | 40.0 |  |  | 35.6 |  |  |  |  |  |  |
| Amortization of acquired intangibles | 34.4 |  |  | 34.6 |  |  | 41.7 |  |  |  |  |  |  |
| Acquisition related costs | 1.3 |  |  | 0.7 |  |  | — |  |  |  |  |  |  |
| Integration related costs | (0.8) |  |  | 1.3 |  |  | 3.4 |  |  |  |  |  |  |
| Restructuring and related charges (2) | 8.3 |  |  | 5.2 |  |  | 9.7 |  |  |  |  |  |  |
| Intangible asset write-off | — |  |  | 0.1 |  |  | 1.9 |  |  |  |  |  |  |
| Other charges (income), net (4) | 3.4 |  |  | (1.2) |  |  | 0.1 |  |  |  |  |  |  |
| Income from operations on non-GAAP basis | $ | 99.8 |  |  | $ | 72.3 |  |  | $ | 10.0 |  |  |  |  |  |  |
| Operating margin on non-GAAP basis | 18.7 | % |  | 15.0 | % |  | 3.0 | % |  |  |  |  |  |
| Other income (expense), net on GAAP basis | $ | (1.5) |  |  | $ | (3.0) |  |  | $ | 3.2 |  |  |  |  |  |  |
| Inducement expense (3) | 5.9 |  |  | — |  |  | — |  |  |  |  |  |  |
| Foreign exchange (gains) losses, net | (1.5) |  |  | 5.8 |  |  | 0.7 |  |  |  |  |  |  |
| Non-cash interest expense on convertible notes | 0.8 |  |  | 0.7 |  |  | 0.7 |  |  |  |  |  |  |
| Other income, net on non-GAAP basis | $ | 3.7 |  |  | $ | 3.5 |  |  | $ | 4.6 |  |  |  |  |  |  |
| Income (loss) before income taxes on GAAP basis | $ | 5.2 |  |  | $ | (11.4) |  |  | $ | (79.2) |  |  |  |  |  |  |
| Stock-based compensation and related payroll taxes (1) | 46.5 |  |  | 40.0 |  |  | 35.6 |  |  |  |  |  |  |
| Acquisition related costs | 1.3 |  |  | 0.7 |  |  | — |  |  |  |  |  |  |
| Integration related costs | (0.8) |  |  | 1.3 |  |  | 3.4 |  |  |  |  |  |  |

[0001628280-25-048860:8k_2_02:56]
| Amortization of acquired intangibles | 34.4 |  |  | 34.6 |  |  | 41.7 |  |  |  |  |  |  |
| Restructuring and related charges (2) | 8.3 |  |  | 5.2 |  |  | 9.7 |  |  |  |  |  |  |
| Inducement expense (3) | 5.9 |  |  | — |  |  | — |  |  |  |  |  |  |
| Intangible asset write-off | — |  |  | 0.1 |  |  | 1.9 |  |  |  |  |  |  |
| Foreign exchange (gains) losses, net | (1.5) |  |  | 5.8 |  |  | 0.7 |  |  |  |  |  |  |
| Non-cash interest expense on convertible notes | 0.8 |  |  | 0.7 |  |  | 0.7 |  |  |  |  |  |  |
| Other charges (income), net (4) | 3.4 |  |  | (1.2) |  |  | 0.1 |  |  |  |  |  |  |
| Income before income taxes on non-GAAP basis | $ | 103.5 |  |  | $ | 75.8 |  |  | $ | 14.6 |  |  |  |  |  |  |
| Income tax provision (benefit) on GAAP basis | $ | 1.0 |  |  | $ | (224.7) |  |  | $ | 3.2 |  |  |  |  |  |  |
| Non-GAAP income tax reconciling adjustments | 16.1 |  |  | 237.2 |  |  | (0.8) |  |  |  |  |  |  |
| Income tax provision on non-GAAP basis | $ | 17.1 |  |  | $ | 12.5 |  |  | $ | 2.4 |  |  |  |  |  |  |
| Net income (loss) on GAAP basis | $ | 4.2 |  |  | $ | 213.3 |  |  | $ | (82.4) |  |  |  |  |  |  |
| Stock-based compensation and related payroll taxes (1) | 46.5 |  |  | 40.0 |  |  | 35.6 |  |  |  |  |  |  |
| Acquisition related costs | 1.3 |  |  | 0.7 |  |  | — |  |  |  |  |  |  |
| Integration related costs | (0.8) |  |  | 1.3 |  |  | 3.4 |  |  |  |  |  |  |
| Amortization of acquired intangibles | 34.4 |  |  | 34.6 |  |  | 41.7 |  |  |  |  |  |  |
| Restructuring and related charges (2) | 8.3 |  |  | 5.2 |  |  | 9.7 |  |  |  |  |  |  |
| Intangible asset write-off | — |  |  | 0.1 |  |  | 1.9 |  |  |  |  |  |  |
| Inducement expense (3) | 5.9 |  |  | — |  |  | — |  |  |  |  |  |  |
| Foreign exchange (gains) losses, net | (1.5) |  |  | 5.8 |  |  | 0.7 |  |  |  |  |  |  |
| Non-cash interest expense on convertible notes | 0.8 |  |  | 0.7 |  |  | 0.7 |  |  |  |  |  |  |
| Non-GAAP income tax reconciling adjustments | (16.1) |  |  | (237.2) |  |  | 0.8 |  |  |  |  |  |  |
| Other charges (income), net (4) | 3.4 |  |  | (1.2) |  |  | 0.1 |  |  |  |  |  |  |
| Net income on non-GAAP basis | $ | 86.4 |  |  | $ | 63.3 |  |  | $ | 12.2 |  |  |  |  |  |  |
| Net income per share on non-GAAP basis | $ | 1.10 |  |  | $ | 0.88 |  |  | $ | 0.18 |  |  |  |  |  |  |
| Shares used in per share calculation - diluted on GAAP basis | 78.3 |  |  | 72.0 |  |  | 68.3 |  |  |  |  |  |  |
| Non-GAAP adjustment (5) | — |  |  | — |  |  | 0.8 |  |  |  |  |  |  |
| Shares used in per share calculation - diluted on non-GAAP basis | 78.3 |  |  | 72.0 |  |  | 69.1 |  |  |  |  |  |  |

[0001628280-25-048860:8k_2_02:57]
(1) Stock-based compensation and related payroll taxes for the three months ended September 27, 2025 includes $4.1 million of payroll taxes on stock-based compensation.

[0001628280-25-048860:8k_2_02:58]
(2) Restructuring charges for the three months ended September 27, 2025 primarily relate to reduction in force during the period in order to enhance operational efficiency and realign our investments toward the most critical initiatives.

[0001628280-25-048860:8k_2_02:59]
(3) Inducement expense on the partial repurchase of our 2026 Notes for the three months ended September 27, 2025 represents the excess of fair value of the total consideration over the fair value of securities issuable pursuant to the original conversion terms.

[0001628280-25-048860:8k_2_02:60]
(4) Other charges, net for the three months ended September 27, 2025 mainly includes $3.7 million of legal and professional fees primarily related to non-ordinary course legal matters.

[0001628280-25-048860:8k_2_02:61]
(5) The adjustment represents the dilutive impact of equity-based compensation awards in accordance with the treasury stock method and dilutive shares from our convertible debt instruments under the if-converted method.

[0001628280-25-048860:8k_2_02:62]
LUMENTUM HOLDINGS INC.

[0001628280-25-048860:8k_2_02:63]
RECONCILIATION OF GAAP NET INCOME TO ADJUSTED EBITDA

[0001628280-25-048860:8k_2_02:64]
(in millions, except per share data)

[0001628280-25-048860:8k_2_02:65]
(unaudited)

[0001628280-25-048860:8k_2_02:66]
|  | Three Months Ended |  |  |  |  |
|  | September 27, 2025 |  |  |  | June 28, 2025 |  | September 28, 2024 |  |  |  |  |  |  |  |  |
| GAAP net income (loss) | $ | 4.2 |  |  |  |  | $ | 213.3 |  |  | $ | (82.4) |  |  |  |  |  |  |  |  |  |
| Other income (expense), net | 1.5 |  |  |  |  | 3.0 |  |  | (3.2) |  |  |  |  |  |  |  |  |  |
| Income tax provision | 1.0 |  |  |  |  | (224.7) |  |  | 3.2 |  |  |  |  |  |  |  |  |  |
| Depreciation | 27.8 |  |  |  |  | 26.4 |  |  | 27.0 |  |  |  |  |  |  |  |  |  |
| Amortization of acquired intangibles | 34.4 |  |  |  |  | 34.6 |  |  | 41.7 |  |  |  |  |  |  |  |  |  |
| EBITDA | 68.9 |  |  |  |  | 52.6 |  |  | (13.7) |  |  |  |  |  |  |  |  |  |
| Restructuring and related charges | 8.3 |  |  |  |  | 5.2 |  |  | 9.7 |  |  |  |  |  |  |  |  |  |
| Stock-based compensation and related payroll taxes | 46.5 |  |  |  |  | 40.0 |  |  | 35.6 |  |  |  |  |  |  |  |  |  |
| Acquisition related costs | 1.3 |  |  |  |  | 0.7 |  |  | — |  |  |  |  |  |  |  |  |  |
| Integration related costs | (0.8) |  |  |  |  | 1.3 |  |  | 3.4 |  |  |  |  |  |  |  |  |  |
| Intangible asset write-off | — |  |  |  |  | 0.1 |  |  | 1.9 |  |  |  |  |  |  |  |  |
| Other charges (income), net | 3.4 |  |  |  |  | (1.2) |  |  | 0.1 |  |  |  |  |  |  |  |  |  |
| Adjusted EBITDA | $ | 127.6 |  |  |  |  | $ | 98.7 |  |  | $ | 37.0 |  |  |  |  |  |  |  |  |  |
