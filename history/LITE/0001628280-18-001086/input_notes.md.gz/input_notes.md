# LITE notes — 0001628280-18-001086


## lite:PropertyPlantandEquipmentNetTableTextBlock

[0001628280-18-001086:notes:1]
[same as prior period, unchanged from 0001633978-17-000119:notes:1]

[0001628280-18-001086:notes:2]
|  | December 30, 2017 |  | July 1, 2017 |
| Land | $ | 10.6 |  |  | $ | 10.6 |  |
| Buildings and improvement | 44.7 |  |  | 37.3 |  |
| Machinery and equipment (1) | 526.3 |  |  | 461.1 |  |
| Furniture and fixtures and software | 42.9 |  |  | 35.8 |  |
| Leasehold improvements | 29.9 |  |  | 30.5 |  |
| Construction in progress | 66.0 |  |  | 84.6 |  |
|  | 720.4 |  |  | 659.9 |  |
| Less: Accumulated depreciation | (419.1 | ) |  | (386.4 | ) |
| Property, plant and equipment, net | $ | 301.3 |  |  | $ | 273.5 |  |

[0001628280-18-001086:notes:3]
(1) In the first quarter of fiscal 2018, we started leasing equipment under a capital lease. Included in the table above is our capital lease asset of $13.4 million, net of depreciation expense of $2.2 million as of December 30, 2017.


## lite:ScheduleOfOtherLiabilitiesCurrentTableTextBlock

[0001628280-18-001086:notes:4]
[same as prior period, unchanged from 0001633978-17-000119:notes:4]

[0001628280-18-001086:notes:5]
|  | December 30, 2017 |  | July 1, 2017 |
| Warranty accrual (3) | $ | 9.9 |  |  | $ | 9.7 |  |
| Restructuring accrual and related charges (2) | 0.4 |  |  | 3.8 |  |
| Deferred revenue and customer deposits | 6.6 |  |  | 6.9 |  |
| Capital lease obligation (1) | 9.1 |  |  | — |  |
| Other current liabilities | 3.4 |  |  | 1.5 |  |
| Other current liabilities | $ | 29.4 |  |  | $ | 21.9 |  |

[0001628280-18-001086:notes:6]
(1) As of December 30, 2017, the amount of $2.3 million related to a capital lease was recorded in the accounts payable on the condensed consolidated balance sheet. Refer to “Note 15. Commitments and Contingencies” in the Notes to Unaudited Condensed Consolidated Financial Statements.

[0001628280-18-001086:notes:7]
(2) Refer to “Note 12. Restructuring and Related Charges” in the Notes to Unaudited Condensed Consolidated Financial Statements.

[0001628280-18-001086:notes:8]
(3) Refer to “Note 15. Commitments and Contingencies” in the Notes to Unaudited Condensed Consolidated Financial Statements.


## lite:ScheduleOfOtherLiabilitiesNoncurrentTableTextBlock

[0001628280-18-001086:notes:9]
[same as prior period, unchanged from 0001633978-17-000119:notes:8]

[0001628280-18-001086:notes:10]
|  | December 30, 2017 |  | July 1, 2017 |
| Asset retirement obligation | $ | 2.5 |  |  | $ | 2.5 |  |
| Pension and related accrual | 4.3 |  |  | 3.9 |  |
| Deferred rent | 3.3 |  |  | 3.3 |  |
| Unrecognized tax benefit | 7.2 |  |  | 10.5 |  |
| Capital lease obligation (1) | 3.1 |  |  | — |  |
| Other non-current liabilities | 4.0 |  |  | 4.8 |  |
| Other non-current liabilities | $ | 24.4 |  |  | $ | 25.0 |  |

[0001628280-18-001086:notes:11]
(1) Refer to “Note 15. Commitments and Contingencies” in the Notes to Unaudited Condensed Consolidated Financial Statements.


## lite:SharebasedCompensationArrangementbySharebasedPaymentAwardNumberofSharesAvailableforGrantTableTextBlock

[0001628280-18-001086:notes:12]
A summary of awards available for grant is as follows (in millions):

[0001628280-18-001086:notes:13]
|  | Awards Available for Grant |
| Balance as of beginning of period | 6.6 |  |
| Granted | (1.1 | ) |
| Canceled | 0.2 |  |
| Balance as of end of period | 5.7 |  |


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001628280-18-001086:notes:14]
The following table summarizes our short-term investments by category (in millions) as of December 30, 2017:

[0001628280-18-001086:notes:15]
|  | As of December 30, 2017 |
|  | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| Certificates of deposit | $ | 23.2 |  |  | $ | — |  |  | $ | — |  |  | $ | 23.2 |  |
| Commercial paper | 35.3 |  |  | — |  |  | — |  |  | 35.3 |  |
| Asset-backed securities | 89.1 |  |  | — |  |  | (0.1 | ) |  | 89.0 |  |
| Corporate debt securities | 263.1 |  |  | 0.1 |  |  | (0.7 | ) |  | 262.5 |  |
| Municipal bonds | 5.8 |  |  | — |  |  | — |  |  | 5.8 |  |
| Mortgage-backed securities | 1.0 |  |  | — |  |  | — |  |  | 1.0 |  |
| Foreign government bonds | 5.6 |  |  | — |  |  | — |  |  | 5.6 |  |
| Total short-term investments | $ | 423.1 |  |  | $ | 0.1 |  |  | $ | (0.8 | ) |  | $ | 422.4 |  |

[0001628280-18-001086:notes:16]
[same as prior period, unchanged from 0001633978-17-000119:notes:12]

[0001628280-18-001086:notes:17]
[same as prior period, unchanged from 0001633978-17-000119:notes:13]


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001628280-18-001086:notes:18]
[same as prior period, unchanged from 0001633978-17-000119:notes:14]

[0001628280-18-001086:notes:19]
The preparation of the condensed consolidated financial statements in accordance with U.S. generally accepted accounting principles (“GAAP”) requires management to make estimates and assumptions that affect the amounts reported in our condensed consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates. Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are revenue recognition, inventory valuation, derivative liability valuation, long-lived asset valuation, warranty and accounting for income taxes.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001628280-18-001086:notes:20]
[same as prior period, unchanged from 0001633978-17-000119:notes:23]

[0001628280-18-001086:notes:21]
[same as prior period, unchanged from 0001633978-17-000119:notes:24]

[0001628280-18-001086:notes:22]
Lumentum (we, us, our or the Company) is an industry-leading provider of optical and photonic products defined by revenue and market share addressing a range of end market applications including Optical Communications (“OpComms”) and Commercial Lasers (“Lasers”) for manufacturing, inspection and life-science applications. We seek to use our core optical and photonic technology and our volume manufacturing capability to expand into attractive emerging markets that benefit from advantages that optical or photonics-based solutions provide, including 3D sensing for consumer electronics and diode light sources for a variety of consumer and industrial applications. The majority of our customers tend to be original equipment manufacturers (“OEMs”) that incorporate our products into their products which then address end-market applications. For example, we sell fiber optic components that our network equipment manufacturer (“NEM”) customers assemble into communications networking systems, which they sell to network service providers or enterprises with their own networks. Similarly, many of our customers for our Lasers products incorporate our products into tools they produce, which are used for manufacturing processes by their customers. For 3D sensing, we sell diode lasers to manufacturers of consumer electronics products for mobile, personal computing, gaming, and other applications, who then integrate our devices within their products, for eventual resale to consumers.

[0001628280-18-001086:notes:23]
[same as prior period, unchanged from 0001633978-17-000119:notes:26]

[0001628280-18-001086:notes:24]
[same as prior period, unchanged from 0001633978-17-000119:notes:27]

[0001628280-18-001086:notes:25]
[same as prior period, unchanged from 0001633978-17-000119:notes:28]

[0001628280-18-001086:notes:26]
[same as prior period, unchanged from 0001633978-17-000119:notes:29]

[0001628280-18-001086:notes:27]
[same as prior period, unchanged from 0001633978-17-000119:notes:30]

[0001628280-18-001086:notes:28]
[same as prior period, unchanged from 0001633978-17-000119:notes:31]

[0001628280-18-001086:notes:29]
Effective July 2, 2017, we adopted Accounting Standards Update (“ASU”) 2016-09, Stock Compensation ASU 718 - Improvements to Employee Share-Based Payment Accounting. As a result of the adoption, in the first quarter of fiscal year 2018, we recorded on a modified retrospective basis a $2.6 million cumulative-effect adjustment to retained earnings for the recognition of excess tax benefits generated by the settlement of share-based awards in prior periods. We elected to account for forfeitures of equity awards when they occur. The change was applied on a modified retrospective basis with a cumulative-effect adjustment of approximately $0.2 million to retained earnings in the fiscal first quarter of 2018.

[0001628280-18-001086:notes:30]
All excess tax benefits and deficiencies are recognized in the income tax provision in the condensed consolidated statements of operations prospectively, rather than in additional paid-in-capital in the condensed consolidated balance sheets. In addition, the standard eliminates the requirement to defer recognition of excess tax benefits until they are realized through a reduction to income taxes payable. We present excess tax benefits as an operating activity in the condensed consolidated statements of cash flows on a prospective basis.


## us-gaap:CashCashEquivalentsAndShortTermInvestmentsTextBlock

[0001628280-18-001086:notes:31]
Note 6. Cash, Cash Equivalents, and Short-term Investments

[0001628280-18-001086:notes:32]
[same as prior period, unchanged from 0001633978-17-000119:notes:35]

[0001628280-18-001086:notes:33]
[same as prior period, unchanged from 0001633978-17-000119:notes:36]

[0001628280-18-001086:notes:34]
|  | December 30, 2017 |  | July 1, 2017 |
| Cash and cash equivalents: |  |  |  |
| Cash | $ | 133.2 |  |  | $ | 201.3 |  |
| Certificates of deposit | 6.2 |  |  | 52.1 |  |
| Commercial paper | 41.9 |  |  | 14.7 |  |
| Corporate debt securities | 2.7 |  |  | — |  |
| Money market funds | 3.0 |  |  | 4.8 |  |
| U.S. Treasury | 13.5 |  |  | — |  |
| Asset-backed securities | 1.6 |  |  | — |  |
| Total cash and cash equivalents | $ | 202.1 |  |  | $ | 272.9 |  |

[0001628280-18-001086:notes:35]
During the three and six months ended December 30, 2017, we did not have significant unrealized gains or losses on our cash equivalents.

[0001628280-18-001086:notes:36]
We use the specific-identification method to determine any realized gains or losses from the sale of our short-term investments classified as available-for-sale. During the three and six months ended December 30, 2017, we did not realize significant gains or losses on a gross level from the sale of our short-term investments classified as available-for-sale.

[0001628280-18-001086:notes:37]
As of December 30, 2017, the fair value of our short-term investments and cash equivalents that have been in unrealized loss position for a period of less than 12 months was $373.0 million. As of December 30, 2017, we had no short-term investments or cash equivalents that had been in unrealized loss positions for a period of greater than 12 months.

[0001628280-18-001086:notes:38]
[same as prior period, unchanged from 0001633978-17-000119:notes:40]

[0001628280-18-001086:notes:39]
|  | As of December 30, 2017 |
|  | Amortized Cost |  | Fair Value |
| Due in 1 year | $ | 184.1 |  |  | $ | 184.0 |  |
| Due in 1 year through 5 years | 226.1 |  |  | 225.4 |  |
| Due in 5 years through 10 years | 4.5 |  |  | 4.5 |  |
| Due after 10 years | 8.4 |  |  | 8.5 |  |
|  | $ | 423.1 |  |  | $ | 422.4 |  |

[0001628280-18-001086:notes:40]
[same as prior period, unchanged from 0001633978-17-000119:notes:42]


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0001628280-18-001086:notes:41]
Note 15. Commitments and Contingencies

[0001628280-18-001086:notes:42]
Operating Leases

[0001628280-18-001086:notes:43]
We lease certain real and personal property from unrelated third parties under non-cancellable operating leases that expire at various dates through fiscal 2026. Certain leases require us to pay property taxes, insurance and routine maintenance, and include escalation clauses. As of December 30, 2017, the future minimum annual lease payments under non-cancellable operating leases were as follows (in millions):

[0001628280-18-001086:notes:44]
| Fiscal Years |  |
| Remainder of 2018 | $ | 5.6 |  |
| 2019 | 11.3 |  |
| 2020 | 8.5 |  |
| 2021 | 4.7 |  |
| 2022 | 3.1 |  |
| Thereafter | 4.0 |  |
| Total minimum operating lease payments | $ | 37.2 |  |

[0001628280-18-001086:notes:45]
During the three and six months ended December 30, 2017, rental expense relating to building and equipment was $3.0 million and $6.4 million, respectively. During the three and six months ended December 31, 2016, rental expense relating to building and equipment was $2.2 million and $4.4 million, respectively.

[0001628280-18-001086:notes:46]
Capital Lease

[0001628280-18-001086:notes:47]
As of December 30, 2017, equipment acquired under a capital lease agreement was $15.6 million. Our capital lease asset is included in property, plant and equipment, net in our condensed consolidated balance sheets as of December 30, 2017. Amortization expense on this capital lease asset is recorded as depreciation expense and is included in cost of sales in our condensed consolidated statements of operations for the three and six months ended December 30, 2017. Our capital lease obligation is recorded at the lesser of the estimated fair market value of the leased property or the net present value of the aggregate future minimum lease payments and is included in other current liabilities and other non-current liabilities in our condensed consolidated balance sheets as of December 30, 2017. Refer to “Note 5. Balance Sheet Details” for further details. Interest on these obligations is included in interest expense in our condensed consolidated statements of operations.

[0001628280-18-001086:notes:48]
As of December 30, 2017 the future minimum annual lease payments under our capital lease were as follows (in millions):

[0001628280-18-001086:notes:49]
| Fiscal Years |  |
| Remainder of 2018 | $ | 7.0 |  |
| 2019 | 7.5 |  |
| 2020 | 0.4 |  |
| Thereafter | — |  |
| Total minimum capital lease payments | $ | 14.9 |  |
| Less: amount representing interest | $ | (0.4 | ) |
| Present value of capital lease obligation | $ | 14.5 |  |

[0001628280-18-001086:notes:50]
Acquisition Contingencies

[0001628280-18-001086:notes:51]
We incurred liabilities in the amount of $3.6 million in connection with the fiscal 2017 acquisition. The amount of $2.7 million is payable 36 months following the acquisition date contingent upon meeting certain production targets. We retained $0.9 million of the purchase price as security for any potential liabilities of the seller under the representations, warranties and indemnifications included in the purchase agreement, which amount less any amounts required to cover seller’s indemnification obligations is payable to the seller at the 15 month anniversary of the close date.

[0001628280-18-001086:notes:52]
0.25% Convertible Senior Notes due 2024

[0001628280-18-001086:notes:53]
The future interest and principal payments related to the 2024 Notes are as follows as of December 30, 2017:

[0001628280-18-001086:notes:54]
| Fiscal Years |  |
| Remainder of 2018 | $ | 0.6 |  |
| 2019 | 1.1 |  |
| 2020 | 1.1 |  |
| 2021 | 1.1 |  |
| 2022 | 1.1 |  |
| Thereafter | 451.7 |  |
| Total 2024 Notes payments | $ | 456.7 |  |

[0001628280-18-001086:notes:55]
Purchase Obligations

[0001628280-18-001086:notes:56]
Purchase obligations of $187.4 million as of December 30, 2017, represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule and adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

[0001628280-18-001086:notes:57]
We depend on a limited number of contract manufacturers, subcontractors and suppliers for raw materials, packages and standard components. We generally purchase these single or limited source products through standard purchase orders or one-year supply agreements and have no significant long-term guaranteed supply agreements with such vendors. While we seek to maintain a sufficient safety stock of such products and maintain on-going communications with our suppliers to guard against interruptions or cessation of supply, our business and results of operations could be adversely affected by a stoppage or delay of supply, substitution of more expensive or less reliable products, receipt of defective parts or contaminated materials, increases in the price of such supplies, or our inability to obtain reduced pricing from our suppliers in response to competitive pressures.

[0001628280-18-001086:notes:58]
Product Warranties

[0001628280-18-001086:notes:59]
We provide reserves for the estimated costs of product warranties at the time revenue is recognized. We typically offer a twelve month warranty for most of our products. However, in some instances depending upon the product, product component or application of our products by the end customer, our warranties can vary and generally range from six months to five years. We estimate the costs of our warranty obligations on an annualized basis based on our historical experience of known product failure rates, use of materials to repair or replace defective products and service delivery costs incurred in correcting product failures. In addition, from time to time, specific warranty accruals may be made if unforeseen technical problems arise with specific products. We assess the adequacy of our recorded warranty liabilities and adjust the amounts as necessary.

[0001628280-18-001086:notes:60]
The following table presents the changes in our warranty reserve during the three and six months ended December 30, 2017 and December 31, 2016 (in millions):

[0001628280-18-001086:notes:61]
|  | Three Months Ended |  | Six Months Ended |
|  | December 30, 2017 |  | December 31, 2016 |  | December 30, 2017 |  | December 31, 2016 |
| Balance as of beginning of period | $ | 9.4 |  |  | $ | 5.4 |  |  | $ | 9.7 |  |  | $ | 2.8 |  |
| Provision for warranty | 1.9 |  |  | 4.9 |  |  | 2.9 |  |  | 8.7 |  |
| Utilization of reserve | (1.4 | ) |  | (1.6 | ) |  | (2.7 | ) |  | (2.8 | ) |
| Balance as of end of period | $ | 9.9 |  |  | $ | 8.7 |  |  | $ | 9.9 |  |  | $ | 8.7 |  |

[0001628280-18-001086:notes:62]
Environmental Liabilities

[0001628280-18-001086:notes:63]
Our research and development (“R&D”), manufacturing and distribution operations involve the use of hazardous substances and are regulated under international, federal, state and local laws governing health and safety and the environment. We apply strict standards for protection of the environment and occupational health and safety to sites inside and outside the United States, even if not subject to regulations imposed by foreign governments. We believe that our properties and operations at our facilities comply in all material respects with applicable environmental laws and occupational health and safety laws. However, the risk of environmental liabilities cannot be completely eliminated and there can be no assurance that the application of environmental and health and safety laws will not require us to incur significant expenditures. We are also regulated under a number of international, federal, state and local laws regarding recycling, product packaging and product content requirements. The environmental, product content/disposal and recycling laws are gradually becoming more stringent and may cause us to incur significant expenditures in the future.

[0001628280-18-001086:notes:64]
In connection with the Separation, we agreed to indemnify Viavi for any liability associated with contamination from past operations at all properties transferred to us from Viavi, to the extent the resulting issues primarily related to our business.

[0001628280-18-001086:notes:65]
Legal Proceedings

[0001628280-18-001086:notes:66]
We are subject to a variety of claims and suits that arise from time to time in the ordinary course of our business. While management currently believes that resolving claims against us, individually or in the aggregate, will not have a material adverse impact on our financial position, results of operations or statements of cash flows, these matters are subject to inherent uncertainties and management’s view of these matters may change in the future. Were an unfavorable final outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the effect becomes reasonably estimable.

[0001628280-18-001086:notes:67]
Indemnifications

[0001628280-18-001086:notes:68]
In the normal course of business, we enter into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown because claims may be made against us in the future and we may record charges in the future as a result of these indemnification obligations. As of December 30, 2017, we did not have any material indemnification claims that were probable or reasonably possible.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001628280-18-001086:notes:69]
[same as prior period, unchanged from 0001633978-17-000119:notes:72]

[0001628280-18-001086:notes:70]
[same as prior period, unchanged from 0001633978-17-000119:notes:73]

[0001628280-18-001086:notes:71]
As of December 30, 2017 and July 1, 2017, balances for the components of accumulated other comprehensive income (loss) were as follows (in millions):

[0001628280-18-001086:notes:72]
|  | Foreign currency translation adjustments, net of tax |  | Defined benefit obligation, net of tax |  | Unrealized gain (loss) on available-for-sale securities, net of tax |  | Total |
| Beginning balance as of July 1, 2017 | $ | 10.5 |  |  | $ | (3.1 | ) |  | $ | — |  |  | $ | 7.4 |  |
| Other comprehensive income (loss) | 1.9 |  |  | — |  |  | (0.1 | ) |  | 1.8 |  |
| Ending balance as of September 30, 2017 | 12.4 |  |  | (3.1 | ) |  | (0.1 | ) |  | 9.2 |  |
| Other comprehensive income (loss) | 0.1 |  |  | — |  |  | (0.6 | ) |  | (0.5 | ) |
| Ending balance as of December 30, 2017 | $ | 12.5 |  |  | $ | (3.1 | ) |  | $ | (0.7 | ) |  | $ | 8.7 |  |

[0001628280-18-001086:notes:73]
We evaluate the assumptions over the fair value of our defined benefit obligation annually and make changes as necessary.


## us-gaap:ConvertibleDebtTableTextBlock

[0001628280-18-001086:notes:74]
As of December 30, 2017, the 2024 Notes consisted of the following (in millions):

[0001628280-18-001086:notes:75]
| Liability component: | December 30, 2017 |  | July 1, 2017 |
| Principal | $ | 450.0 |  |  | $ | 450.0 |  |
| Unamortized debt discount | (124.3 | ) |  | (132.5 | ) |
| Net carrying amount of the liability component | $ | 325.7 |  |  | $ | 317.5 |  |


## us-gaap:DebtDisclosureTextBlock

[0001628280-18-001086:notes:76]
Note 9. Convertible Senior Notes

[0001628280-18-001086:notes:77]
In March 2017, we issued the 2024 Notes in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act of 1933, as amended (the “Securities Act”). The 2024 Notes are governed by an indenture between the Company, as the issuer, and U.S. Bank National Association, as trustee (the “Indenture”). The 2024 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001628280-18-001086:notes:78]
The 2024 Notes bear interest at a rate of 0.25% per year. Interest on the 2024 Notes is payable semi-annually in arrears on March 15 and September 15 of each year, beginning on September 15, 2017. The 2024 Notes will mature on March 15, 2024, unless earlier repurchased by us or converted pursuant to their terms.

[0001628280-18-001086:notes:79]
The initial conversion rate of the 2024 Notes is 16.4965 shares of common stock per $1,000 principal amount of 2024 Notes, which is equivalent to an initial conversion price of approximately $60.62 per share, a 132.5% premium to the fair market value at the date of issuance. Prior to the close of business on the business day immediately preceding December 15, 2023, the 2024 Notes will be convertible only under the following circumstances: (1) during any fiscal quarter (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during the period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price on each applicable trading day; (2) during the five consecutive business day period after any five consecutive trading day period (the “measurement period”) in which the trading price per $1,000 principal amount of notes for each trading day of such measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate on each such trading day; or (3) upon the occurrence of specified corporate events. On or after December 15, 2023 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their notes at any time. In addition, upon the occurrence of a make-whole fundamental change, we will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert 2024 Notes in connection with such make-whole fundamental change.

[0001628280-18-001086:notes:80]
We may not redeem the 2024 Notes prior to their maturity date and no sinking fund is provided for the 2024 Notes. Upon the occurrence of a fundamental change, holders may require us to repurchase all or a portion of their 2024 Notes for cash at a price equal to 100% of the principal amount of the 2024 Notes to be repurchased, plus any accrued and unpaid interest.

[0001628280-18-001086:notes:81]
We considered the features embedded in the 2024 Notes other than the conversion feature, including the holders’ put feature, our call feature, and the make-whole feature, and concluded that they are not required to be bifurcated and accounted for separately from the host debt instrument.

[0001628280-18-001086:notes:82]
Prior to the Tax Matters Agreement settlement condition (“TMA settlement condition”), because we could only settle the 2024 Notes in cash, we determined that the conversion feature met the definition of a derivative liability. We separated the derivative liability from the host debt instrument based on the fair value of the derivative liability. As of the issuance date, March 8, 2017, the derivative liability fair value of $129.9 million was calculated using the binomial valuation approach. The residual principal amount of the 2024 Notes of $320.1 million before issuance costs was allocated to the debt component. We incurred approximately $7.7 million in transaction costs in connection with the issuance of the 2024 Notes. These costs were allocated to the debt component and recognized as a debt discount. We amortize the debt discount, including both the initial value of the derivative liability and the transaction costs, over the term of the 2024 Notes using the effective interest method. The effective interest rate of the 2024 Notes is 5.4% per year. As of December 30, 2017, the remaining debt discount amortization period was 74 months.

[0001628280-18-001086:notes:83]
During the year ended July 1, 2017, we satisfied the TMA settlement conditions. As such, the value of the conversion option will no longer be marked to market and was reclassified to additional paid-in capital within stockholders’ equity on our condensed consolidated balance sheet. The value of the conversion option at the time of issuance will be treated as an original issue discount for purposes of accounting for the debt component of the notes. The debt component will accrete up to the principal amount over the expected term of the debt. These accounting standards do not affect the actual amount we are required to repay, and the amount shown in the table below for the notes is the aggregate principal amount of the notes and does not reflect the debt discount we will be required to recognize.

[0001628280-18-001086:notes:84]
The following table sets forth interest expense information related to the 2024 Notes for the three and six months ended December 30, 2017:

[0001628280-18-001086:notes:85]
|  | December 30, 2017 |
| (in millions, except percentages) | Three Months Ended |  | Six Months Ended |
| Contractual interest expense | $ | 0.3 |  |  | $ | 0.6 |  |
| Amortization of the debt discount | 4.1 |  |  | 8.2 |  |
| Total interest expense | $ | 4.4 |  |  | $ | 8.8 |  |
| Effective interest rate on the liability component | 5.4 | % |  | 5.4 | % |

[0001628280-18-001086:notes:86]
We have the ability and intent to settle the $450 million face value of the debt in cash. Therefore, we use the treasury stock method for calculating the dilutive impact of the debt. The 2024 Notes will have no impact to diluted earnings per share until the average price of our common stock exceeds the conversion price.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001628280-18-001086:notes:87]
Note 10. Derivative Liability

[0001628280-18-001086:notes:88]
We estimate the fair value of the embedded derivative for the Series A Preferred Stock using the binomial lattice model. We applied the lattice model to value the embedded derivative using a “with-and-without method,” where the value of the Series A Preferred Stock, including the embedded derivative, is defined as the “with”, and the value of the Series A Preferred Stock, excluding the embedded derivative, is defined as the “without”. The lattice model requires the following inputs: (i) the Company's common stock price; (ii) conversion price; (iii) term; (iv) yield; (v) recovery rate for the Series A Preferred Stock; (vi) estimated stock volatility; and (vii) risk-free rate. The fair value of the embedded derivative was determined using Level 3 inputs under the fair value hierarchy (unobservable inputs). Changes in the inputs into this valuation model have a material impact in the estimated fair value of the embedded derivative. For example, a decrease (increase) in the stock price and the volatility results in a decrease (increase) in the estimated fair value of the embedded derivative. The changes in the fair value of the bifurcated embedded derivative for the Series A Preferred Stock are primarily related to the change in the price of our common stock and are reflected in the condensed consolidated statements of operations as “Unrealized gain (loss) on derivative liability”. Unrealized gain (loss) on derivative liability amounted to $7.9 million and $12.1 million for the three and six months ended December 30, 2017, respectively, and $4.8 million and $(17.9) million for the three and six months ended December 31, 2016, respectively.

[0001628280-18-001086:notes:89]
The following table provides a reconciliation of the fair value of the embedded derivative for the Series A Preferred Stock measured by significant unobservable inputs (Level 3) for the three and six months ended December 30, 2017 and December 31, 2016 (in millions):

[0001628280-18-001086:notes:90]
|  | Three Months Ended |  | Six Months Ended |
|  | December 30, 2017 |  | December 31, 2016 |  | December 30, 2017 |  | December 31, 2016 |
| Balance as of beginning of period | $ | (47.4 | ) |  | $ | (33.0 | ) |  | $ | (51.6 | ) |  | $ | (10.3 | ) |
| Unrealized gain (loss) on the Series A Preferred Stock derivative liability | 7.9 |  |  | 4.8 |  |  | 12.1 |  |  | (17.9 | ) |
| Balance as of end of period | $ | (39.5 | ) |  | $ | (28.2 | ) |  | $ | (39.5 | ) |  | $ | (28.2 | ) |

[0001628280-18-001086:notes:91]
[same as prior period, unchanged from 0001633978-17-000119:notes:94]

[0001628280-18-001086:notes:92]
|  | December 30, 2017 |  | July 1, 2017 |
| Stock price | $ | 48.90 |  |  | $ | 57.05 |  |
| Conversion price | $ | 24.63 |  |  | $ | 24.63 |  |
| Expected term (years) | 2.61 |  |  | 3.11 |  |
| Expected annual volatility | 50.0 | % |  | 47.5 | % |
| Risk-free rate | 1.95 | % |  | 1.57 | % |
| Preferred yield | 7.97 | % |  | 7.56 | % |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001628280-18-001086:notes:93]
Note 14. Stock-Based Compensation and Stock Plans

[0001628280-18-001086:notes:94]
[same as prior period, unchanged from 0001633978-17-000119:notes:97]

[0001628280-18-001086:notes:95]
[same as prior period, unchanged from 0001633978-17-000119:notes:98]

[0001628280-18-001086:notes:96]
On June 23, 2015, we adopted, and the board of directors of JDSU approved, the 2015 Equity Incentive Plan (the “2015 Plan”) under which 8.5 million shares of our common stock were authorized for issuance, which was ratified by our board of directors in August 2015. In connection with our Separation from JDSU on July 31, 2015, outstanding JDSU equity-based awards held by service providers continuing in service after the Separation were converted into equity-based awards under the 2015 Plan reducing the number of shares remaining available for grant under the 2015 Plan. Immediately following our Separation from JDSU, 2.1 million shares of our common stock were reserved pursuant to outstanding equity-based awards under the 2015 Plan that were converted from JDSU equity-based awards.

[0001628280-18-001086:notes:97]
On November 4, 2016, our stockholders approved an amendment to increase the number of shares that may be issued under the 2015 Plan by 3.0 million shares, and the material terms of the 2015 Plan.

[0001628280-18-001086:notes:98]
As of December 30, 2017, we had 2.3 million shares subject to stock options, restricted stock units, restricted stock awards, and performance stock units issued and outstanding under the 2015 Plan. Restricted stock units, restricted stock awards, and performance stock units are performance-based, time-based or a combination of both and are expected to vest over one to four years. The fair value of these grants is based on the closing market price of our common stock on the date of award.

[0001628280-18-001086:notes:99]
The exercise price for stock options is equal to the fair value of the underlying stock at the date of grant. We issue new shares of common stock upon exercise of stock options. Options generally become exercisable over a three-year or four-year period and, if not exercised, expire from five to ten years after the date of grant.

[0001628280-18-001086:notes:100]
As of December 30, 2017, 5.7 million shares of common stock under the 2015 Plan were available for grant.

[0001628280-18-001086:notes:101]
[same as prior period, unchanged from 0001633978-17-000119:notes:104]

[0001628280-18-001086:notes:102]
On June 23, 2015, we adopted, and the board of directors of JDSU approved, the 2015 Employee Stock Purchase Plan (the “2015 Purchase Plan”) under which 3.0 million shares of our common stock were authorized for issuance, which was ratified by our board of directors in August 2015. The 2015 Purchase Plan provides eligible employees with the opportunity to acquire an ownership interest in the Company through periodic payroll deductions and provides a 15% purchase price discount as well as a six-month look-back period. The 2015 Purchase Plan is structured as a qualified employee stock purchase plan under Section 423 of the Internal Revenue Code of 1986. However, the 2015 Purchase Plan is not intended to be a qualified pension, profit sharing or stock bonus plan under Section 401(a) of the Internal Revenue Code of 1986 and is not subject to the provisions of the Employee Retirement Income Security Act of 1974. The 2015 Purchase Plan will terminate upon the date on which all shares available for issuance have been sold. Of the 3.0 million shares authorized under the 2015 Purchase Plan, 2.4 million shares remained available for issuance as of December 30, 2017.

[0001628280-18-001086:notes:103]
[same as prior period, unchanged from 0001633978-17-000119:notes:106]

[0001628280-18-001086:notes:104]
Restricted stock units (“RSUs”) under the 2015 Plan are grants of shares of our common stock valued at fair value based on the closing price of our common stock on the date of grant. RSUs result in a payment to a holder if any performance goals or other vesting criteria are achieved or the awards otherwise vest. Generally, our RSUs have service conditions, performance conditions, or a combination of both and are expected to vest over one to four years.

[0001628280-18-001086:notes:105]
[same as prior period, unchanged from 0001633978-17-000119:notes:108]

[0001628280-18-001086:notes:106]
[same as prior period, unchanged from 0001633978-17-000119:notes:109]

[0001628280-18-001086:notes:107]
Performance Stock Units

[0001628280-18-001086:notes:108]
Performance stock units (“PSUs”) under the 2015 Plan are grants of shares of our common stock that vest upon the achievement of certain performance conditions. We begin recognizing compensation expense when we conclude that it is probable that the performance conditions will be achieved. We reassess the probability of vesting at each reporting period and adjust our compensation cost based on this probability assessment. Our PSUs are subject to risk of forfeiture until a performance condition is satisfied and generally vest over three years.

[0001628280-18-001086:notes:109]
During the six months ended December 30, 2017, we granted 116,788 PSUs to senior members of our management team and recorded $1.2 million expense related to these grants based on the revenue performance condition that is expected to be achieved.

[0001628280-18-001086:notes:110]
[same as prior period, unchanged from 0001633978-17-000119:notes:110]

[0001628280-18-001086:notes:111]
The impact on our results of operations of recording stock-based compensation by function for the three and six months ended December 30, 2017 and December 31, 2016 was as follows (in millions):

[0001628280-18-001086:notes:112]
|  | Three Months Ended |  | Six Months Ended |
|  | December 30, 2017 |  | December 31, 2016 |  | December 30, 2017 |  | December 31, 2016 |
| Cost of sales | $ | 4.4 |  |  | $ | 2.1 |  |  | $ | 7.1 |  |  | $ | 4.1 |  |
| Research and development | 3.8 |  |  | 3.0 |  |  | 6.9 |  |  | 5.8 |  |
| Selling, general and administrative | 6.6 |  |  | 4.0 |  |  | 10.1 |  |  | 7.0 |  |
|  | $ | 14.8 |  |  | $ | 9.1 |  |  | $ | 24.1 |  |  | $ | 16.9 |  |

[0001628280-18-001086:notes:113]
Approximately $1.7 million and $1.8 million of stock-based compensation was capitalized to inventory as of December 30, 2017 and July 1, 2017, respectively.

[0001628280-18-001086:notes:114]
Stock Option and Stock Award Activity

[0001628280-18-001086:notes:115]
We did not grant any stock options during the three and six months ended December 30, 2017 and December 31, 2016. During the three and six months ended December 30, 2017, there were 1,457 options and 41,727 options exercised, respectively. As of December 30, 2017, 3,057 options were outstanding under the 2015 Plan. During the three and six months ended December 30, 2017, the total intrinsic value of options exercised by our employees was $0.1 million and $0.8 million, respectively. The total intrinsic value of options exercised by our employees during the three and six months ended December 31, 2016 was $0.5 million and $3.6 million, respectively.

[0001628280-18-001086:notes:116]
In connection with these exercises, the tax benefit realized during the three and six months ended December 31, 2016 was $2.9 million. During the three and six months ended December 30, 2017, due to adoption of ASU 2016-09, all excess tax benefits and deficiencies were recognized in the income tax provision in the condensed consolidated statements of operations, rather than in additional paid-in-capital in the condensed consolidated balance sheets. Refer to “Note 1. Description of Business and Summary of Significant Accounting Policies” in the Notes to Unaudited Condensed Consolidated Financial Statements for further discussion on the impact of the adoption of ASU 2016-09.

[0001628280-18-001086:notes:117]
As of December 30, 2017, $82.6 million of stock-based compensation cost related to awards granted to our employees remains to be amortized. That cost is expected to be recognized over an estimated amortization period of 2.0 years.

[0001628280-18-001086:notes:118]
The following table summarizes our awards activity for the six months ended December 30, 2017 (in millions, except per share amounts):

[0001628280-18-001086:notes:119]
|  | Restricted Stock Units |  | Restricted Stock Awards |  | Performance Stock Units |
|  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |
| Unvested balance as of beginning of period | 1.9 |  |  | $ | 28.04 |  |  | 0.3 |  |  | $ | 32.51 |  |  | — |  |  | $ | — |  |
| Granted | 1.0 |  |  | 53.13 |  |  | — |  |  | — |  |  | 0.1 |  |  | 52.00 |  |
| Exercised / Vested | (0.7 | ) |  | 26.23 |  |  | (0.1 | ) |  | 32.51 |  |  | — |  |  | — |  |
| Canceled | (0.2 | ) |  | 38.64 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Unvested balance as of end of period | 2.0 |  |  | $ | 37.56 |  |  | 0.2 |  |  | $ | 32.51 |  |  | 0.1 |  |  | $ | 52.00 |  |

[0001628280-18-001086:notes:120]
Employee Stock Purchase Plan Activity

[0001628280-18-001086:notes:121]
The 2015 Purchase Plan expense for the three and six months ended December 30, 2017 was $0.8 million and $1.6 million, respectively. The expense related to the 2015 Purchase Plan is recorded on a straight-line basis over the relevant subscription period. During the three and six months ended December 30, 2017, there were 93,044 shares issued to employees through the 2015 Purchase Plan in one offering period from May 16, 2017 to November 15, 2017.

[0001628280-18-001086:notes:122]
The 2015 Purchase Plan expense for the three and six months ended December 31, 2016 was $0.7 million and $1.2 million, respectively. During the three and six months ended December 31, 2016, there were 188,864 shares issued to employees through the 2015 Purchase Plan in one offering period from May 16, 2016 to November 15, 2016.

[0001628280-18-001086:notes:123]
We estimate the fair value of the 2015 Purchase Plan shares on the date of grant using the Black-Scholes option-pricing model. The assumptions used to estimate the fair value of the 2015 Purchase Plan shares to be issued during the three and six months ended December 30, 2017 and December 31, 2016 were as follows:

[0001628280-18-001086:notes:124]
|  | December 30, 2017 |  | December 31, 2016 |
| Expected term (years) | 0.5 |  |  | 0.5 |  |
| Expected volatility | 49.9 | % |  | 46.0 | % |
| Risk-free interest rate | 1.42 | % |  | 0.62 | % |
| Dividend yield | — | % |  | — | % |


## us-gaap:EarningsPerShareTextBlock

[0001628280-18-001086:notes:125]
[same as prior period, unchanged from 0001633978-17-000119:notes:124]

[0001628280-18-001086:notes:126]
[same as prior period, unchanged from 0001633978-17-000119:notes:125]

[0001628280-18-001086:notes:127]
|  | Three Months Ended |  | Six Months Ended |
|  | December 30, 2017 |  | December 31, 2016 |  | December 30, 2017 |  | December 31, 2016 |
| Numerator: |  |  |  |  |  |  |  |  |  |  |
| Net income | $ | 204.8 |  |  | $ | 11.8 |  |  | $ | 211.9 |  |  | $ | 8.4 |  |
| Less: Cumulative dividends on Series A Preferred Stock (a) | (0.3 | ) |  | (0.2 | ) |  | (0.5 | ) |  | (0.4 | ) |
| Net income attributable to common stockholders - basic | $ | 204.5 |  |  | $ | 11.6 |  |  | $ | 211.4 |  |  | $ | 8.0 |  |
| Net income attributable to common stockholders - diluted | $ | 204.8 |  |  | $ | 11.8 |  |  | $ | 211.9 |  |  | $ | 8.0 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average number of common shares outstanding |  |  |  |  |  |  |  |
| Basic | 62.2 |  |  | 60.3 |  |  | 61.9 |  |  | 60.1 |  |
| Effect of dilutive securities from stock-based benefit plans | 0.9 |  |  | 0.9 |  |  | 1.1 |  |  | 1.0 |  |
| Effect of diluted securities from Series A Preferred Stock | 1.5 |  |  | 1.5 |  |  | 1.5 |  |  | — |  |
| Diluted shares attributable to common stockholders | 64.6 |  |  | 62.7 |  |  | 64.5 |  |  | 61.1 |  |
| Net income per share attributable to common stockholders: |  |  |  |  |  |  |  |
| Basic | $ | 3.29 |  |  | $ | 0.19 |  |  | $ | 3.42 |  |  | $ | 0.13 |  |
| Diluted | $ | 3.17 |  |  | $ | 0.19 |  |  | $ | 3.29 |  |  | $ | 0.13 |  |

[0001628280-18-001086:notes:128]
(a) Dividends on our redeemable convertible Series A Preferred Stock were declared during all periods presented. However, cumulative dividends are added back to net income in accordance with the assumed conversion under the if-converted method.

[0001628280-18-001086:notes:129]
The dilutive effect of stock-based awards is reflected in diluted earnings per share by application of the treasury stock method, which includes consideration of unamortized share-based compensation expense and the dilutive effect of in-the-money options and non-vested restricted stock units. Under the treasury stock method, the amount the employee must pay for exercising stock options and unamortized share-based compensation expense collectively are assumed proceeds to be used to repurchase hypothetical shares. An increase in the fair value of our common stock can result in a greater dilutive effect from potentially dilutive awards.

[0001628280-18-001086:notes:130]
The dilutive effect of our Series A Preferred Stock is reflected in diluted earnings per share by the application of the if-converted method. The number of shares is increased for the assumed conversion of the instrument. Additionally, cumulative dividends are added back to net income. For the six months ended December 31, 2016, 1.5 million shares related to the potential conversion of the Series A Preferred Stock were excluded from the calculation of diluted shares available to the common stockholders because their inclusion would have been antidilutive.

[0001628280-18-001086:notes:131]
In March 2017, we issued $450 million in aggregate principal amount of 0.25% Convertible Senior Notes due in 2024 (the “2024 Notes”). We have the ability and intent to settle the $450 million face value of the 2024 Notes in cash. Therefore, we use the treasury stock method for calculating the dilutive impact of the 2024 Notes. The 2024 Notes will have no impact to diluted earnings per share until the average price of our common stock exceeds the conversion price. Refer to “Note 9. Convertible Senior Notes” for further discussion.

[0001628280-18-001086:notes:132]
For the three and six months ended December 30, 2017 and December 31, 2016, the number of shares related to our stock-based benefit plans that were excluded from the calculation of diluted shares was not material.


## us-gaap:FairValueDisclosuresTextBlock

[0001628280-18-001086:notes:133]
Note 7. Fair Value Measurements

[0001628280-18-001086:notes:134]
[same as prior period, unchanged from 0001633978-17-000119:notes:133]

[0001628280-18-001086:notes:135]
[same as prior period, unchanged from 0001633978-17-000119:notes:134]

[0001628280-18-001086:notes:136]
[same as prior period, unchanged from 0001633978-17-000119:notes:135]

[0001628280-18-001086:notes:137]
We estimate the fair value of the embedded derivative for the Series A Preferred Stock using the binomial lattice model. The lattice model requires the various assumptions to be made to determine the fair value of the embedded derivatives. These assumptions represent Level 3 inputs. Refer to “Note 10. Derivative Liability” in the Notes to Unaudited Condensed Consolidated Financial Statements.

[0001628280-18-001086:notes:138]
In February 2017, we completed the acquisition of a privately held company to enhance our manufacturing and vertical integration capabilities for a total purchase consideration of $8.7 million. We estimated the fair value of our Level 3 contingent consideration related to this acquisition as the present value of the expected contingent payments, determined using a probabilistic approach. We are required to reassess the fair value of contingent payments on a periodic basis. During the three months ended December 30, 2017, we estimated the likelihood of meeting the production targets at 90 percent. There was no change in the fair value of our contingent consideration during the three and six months ended December 30, 2017. The fair value of such contingent consideration is recorded in accrued liabilities on the condensed consolidated balance sheet as of December 30, 2017. This contingent consideration will result in a cash payment of $3.0 million, if and when the production targets are achieved.

[0001628280-18-001086:notes:139]
[same as prior period, unchanged from 0001633978-17-000119:notes:138]

[0001628280-18-001086:notes:140]
[same as prior period, unchanged from 0001633978-17-000119:notes:139]

[0001628280-18-001086:notes:141]
|  | As of December 30, 2017 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | — |  |  | $ | 6.2 |  |  | $ | — |  |  | $ | 6.2 |  |
| Commercial paper | — |  |  | 41.9 |  |  | — |  |  | 41.9 |  |
| Corporate debt securities | — |  |  | 2.7 |  |  | — |  |  | 2.7 |  |
| Money market funds | 3.0 |  |  | — |  |  | — |  |  | 3.0 |  |
| U.S. Treasury | 13.5 |  |  | — |  |  | — |  |  | 13.5 |  |
| Asset-backed securities | — |  |  | 1.6 |  |  | — |  |  | 1.6 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | 23.2 |  |  | — |  |  | 23.2 |  |
| Commercial paper | — |  |  | 35.3 |  |  | — |  |  | 35.3 |  |
| Asset-backed securities | — |  |  | 89.0 |  |  | — |  |  | 89.0 |  |
| Corporate debt securities | — |  |  | 262.5 |  |  | — |  |  | 262.5 |  |
| Municipal bonds | — |  |  | 5.8 |  |  | — |  |  | 5.8 |  |
| Mortgage-backed securities | — |  |  | 1.0 |  |  | — |  |  | 1.0 |  |
| Foreign government bonds | — |  |  | 5.6 |  |  | — |  |  | 5.6 |  |
| Total assets | $ | 16.5 |  |  | $ | 474.8 |  |  | $ | — |  |  | $ | 491.3 |  |
| Other accrued liabilities: |  |  |  |  |  |  |  |
| Derivative liability | $ | — |  |  | $ | — |  |  | $ | 39.5 |  |  | $ | 39.5 |  |
| Acquisition contingencies | — |  |  | — |  |  | 2.7 |  |  | 2.7 |  |
| Pension and post-retirement benefit accrual | — |  |  | 4.3 |  |  | — |  |  | 4.3 |  |
| Total other accrued liabilities | $ | — |  |  | $ | 4.3 |  |  | $ | 42.2 |  |  | $ | 46.5 |  |

[0001628280-18-001086:notes:142]
[same as prior period, unchanged from 0001633978-17-000119:notes:141]

[0001628280-18-001086:notes:143]
[same as prior period, unchanged from 0001633978-17-000119:notes:142]

[0001628280-18-001086:notes:144]
Management utilizes various valuation methods, including an income approach, a market approach and a cost approach, to estimate the fair value of intangible and other long-lived assets. During the annual impairment testing performed in fiscal 2017, all our intangible and other long-lived assets passed Step 1. No impairment charges were recorded in fiscal 2017 or 2016. Refer to “Note 11. Goodwill and Other Intangible Assets”.

[0001628280-18-001086:notes:145]
Additionally, we have a restructuring liability related to certain real estate facilities which was calculated based on the present value of future lease payments, less estimated sublease income, discounted at a rate commensurate with our current cost of financing. This non-recurring fair value measurement is considered to be a Level 3 measurement due to the use of significant unobservable inputs. To the extent that actual sublease income or the timing of subleasing these facilities is different than initial estimates, we will adjust the restructuring liability in the period during which such information becomes known. Refer to “Note 12. Restructuring and Related Charges”.


## us-gaap:FiniteLivedIntangibleAssetsAmortizationExpenseTableTextBlock

[0001628280-18-001086:notes:146]
[same as prior period, unchanged from 0001633978-17-000119:notes:145]

[0001628280-18-001086:notes:147]
|  | Three Months Ended |  | Six Months Ended |
|  | December 30, 2017 |  | December 31, 2016 |  | December 30, 2017 |  | December 31, 2016 |
| Cost of sales | $ | 0.8 |  |  | $ | 1.7 |  |  | $ | 1.6 |  |  | $ | 3.4 |  |
| Operating expenses | — |  |  | 0.1 |  |  | — |  |  | 0.2 |  |
| Total | $ | 0.8 |  |  | $ | 1.8 |  |  | $ | 1.6 |  |  | $ | 3.6 |  |


## us-gaap:GoodwillDisclosureTextBlock

[0001628280-18-001086:notes:148]
Note 11. Goodwill and Other Intangible Assets

[0001628280-18-001086:notes:149]
[same as prior period, unchanged from 0001633978-17-000119:notes:148]

[0001628280-18-001086:notes:150]
In February 2017, we completed the acquisition of a privately held company to enhance our manufacturing and vertical integration capabilities. As of the acquisition date, we recognized goodwill in the amount of $5.6 million and allocated it to OpComms. The following table presents the changes in goodwill by operating segments during the six months ended December 30, 2017 (in millions):

[0001628280-18-001086:notes:151]
|  | Optical Communications |  | Commercial Lasers |  | Total |
| Balance as of beginning of period | $ | 5.9 |  |  | $ | 5.5 |  |  | $ | 11.4 |  |
| Currency translation | 0.3 |  |  | (0.1 | ) |  | 0.2 |  |
| Balance as of end of period | $ | 6.2 |  |  | $ | 5.4 |  |  | $ | 11.6 |  |

[0001628280-18-001086:notes:152]
[same as prior period, unchanged from 0001633978-17-000119:notes:151]

[0001628280-18-001086:notes:153]
We review goodwill for impairment during the fourth quarter of each fiscal year or more frequently if events or circumstances indicate that an impairment loss may have occurred. In the fourth quarter of fiscal 2017, we completed the annual impairment test of goodwill, which indicated there was no goodwill impairment. During the three and six months ended December 30, 2017, there have been no events or circumstances that have required us to perform an interim assessment of goodwill for impairment.

[0001628280-18-001086:notes:154]
[same as prior period, unchanged from 0001633978-17-000119:notes:153]

[0001628280-18-001086:notes:155]
In connection with the acquisition described above, we recorded $2.4 million to acquired developed technology in OpComms. The following tables present details of our acquired developed technology and other intangibles (in millions):

[0001628280-18-001086:notes:156]
| As of December 30, 2017 | Gross Carrying Amount |  | Accumulated Amortization |  | Net |
| Acquired developed technology | $ | 105.6 |  |  | $ | (96.8 | ) |  | $ | 8.8 |  |
| Other | 9.4 |  |  | (9.4 | ) |  | — |  |
| Total Intangibles | $ | 115.0 |  |  | $ | (106.2 | ) |  | $ | 8.8 |  |

[0001628280-18-001086:notes:157]
[same as prior period, unchanged from 0001633978-17-000119:notes:156]

[0001628280-18-001086:notes:158]
During the three and six months ended December 30, 2017, we recorded $0.8 million and $1.6 million, respectively, of amortization related to acquired developed technology and other intangibles.

[0001628280-18-001086:notes:159]
During the three and six months ended December 31, 2016, we recorded $1.8 million and $3.6 million, respectively, of amortization related to acquired developed technology and other intangibles.

[0001628280-18-001086:notes:160]
Based on the carrying amount of acquired developed technology and other intangibles as of December 30, 2017, and assuming no future impairment of the underlying assets, the estimated future amortization is as follows (in millions):

[0001628280-18-001086:notes:161]
| Fiscal Years |  |
| Remainder of 2018 | $ | 1.6 |  |
| 2019 | 3.0 |  |
| 2020 | 2.9 |  |
| Thereafter | 1.3 |  |
| Total amortization | $ | 8.8 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-18-001086:notes:162]
Note 13. Income Taxes

[0001628280-18-001086:notes:163]
[same as prior period, unchanged from 0001633978-17-000119:notes:161]

[0001628280-18-001086:notes:164]
Our quarterly tax provision, and estimate of our annual effective tax rate, is subject to variation due to several factors, including variability in pre-tax income (or loss), the mix of jurisdictions to which such income relates, changes in how we do business, and tax law developments. Our estimated effective tax rate for the year differs from the U.S. statutory rate primarily due to the benefit of foreign earnings of our subsidiaries being taxed at rates lower than the U.S. statutory rate.

[0001628280-18-001086:notes:165]
We recorded a tax benefit of $(109.3) million and $(112.9) million for the three and six months ended December 30, 2017, respectively. Our tax benefit for the three and six months ended December 30, 2017 was primarily due to the release of our U.S. federal and certain state valuation allowances.  The benefit of this valuation allowance release was partially offset by a non-cash deferred expense associated with the change in the U.S. statutory rate as a result of the Tax Act (discussed further below) which was enacted during the three-month period ended December 30, 2017.

[0001628280-18-001086:notes:166]
We recorded a tax provision of $6.1 million and $3.8 million for the three and six months ended December 31, 2016, respectively. Our tax provision for the three and six months ended December 31, 2016 was primarily due to the tax effect of our operating profits, non-deductible stock-based compensation, and unrecognized tax benefits, partially offset by benefit from the utilization of U.S. deferred tax assets that were subject to a full valuation allowance.

[0001628280-18-001086:notes:167]
We assess our ability to realize the deferred tax assets on a quarterly basis and establish a valuation allowance if the deferred tax assets are not more-likely-than-not to be realized. We weigh all available positive and negative evidence, including our earnings history and results of recent operations, reversals of deferred tax liabilities, projected future taxable income, and tax planning strategies.

[0001628280-18-001086:notes:168]
As of each reporting date, we consider new evidence, both positive and negative, that could affect our view of the future realization of deferred tax assets. As of December 30, 2017, we determined that there is sufficient positive evidence to conclude that it is more-likely-than-not that the deferred tax assets are realizable. We, therefore, released the valuation allowance for the U.S. federal and states (except California) and recognized a tax benefit of $207 million as a discrete item for the fiscal second quarter of 2018. Due to the weight of negative evidence, we continue to maintain a full valuation allowance on the California deferred tax assets.

[0001628280-18-001086:notes:169]
On December 22, 2017, the U.S. government enacted comprehensive tax legislation commonly referred to as the Tax Cuts and Jobs Act (the “Tax Act”). The Tax Act makes broad and complex changes to the U.S. tax code that will affect our fiscal year ending June 30, 2018, including, but not limited to, (1) a reduction in the U.S. federal corporate tax rate; (2) a transition tax on certain deferred income of foreign subsidiaries that, if the taxpayer so elects, is payable over eight years; and (3) bonus depreciation that allows full expensing of qualified property. The Tax Act reduces the federal corporate tax rate to 21 percent in the fiscal year ending June 30, 2018. Section 15 of the Internal Revenue Code stipulates that our fiscal year ending June 30, 2018 will have a blended corporate tax rate of 28 percent, which is based on the applicable tax rates before and after the Tax Act and the number of days in each period.

[0001628280-18-001086:notes:170]
The Tax Act also establishes new tax laws that will affect our fiscal year ending June 30, 2019, including, but not limited to, (1) reduction of the U.S. federal corporate tax rate; (2) elimination of the corporate alternative minimum tax; (3) the creation of the base erosion anti-abuse tax (“BEAT”), a new minimum tax on taxable income adjusted for certain base erosion payments; (4) a general elimination of U.S. federal income taxes on dividends from foreign subsidiaries; (5) a new provision designed to currently tax certain global intangible low-taxed income (“GILTI”) of controlled foreign corporations, which allows for the possibility of using foreign tax credits (“FTCs”) and a deduction of up to 50 percent to reduce this income tax liability (subject to some limitations); (6) a new limitation on deductible interest expense; (7) the repeal of the domestic production activity deduction; (8) limitations on the deductibility of certain executive compensation; (9) limitations on the use of FTCs to reduce the U.S. income tax liability; and (10) limitations on net operating losses generated in the taxable years beginning after December 31, 2017, to 80 percent of taxable income.

[0001628280-18-001086:notes:171]
The SEC staff issued SAB 118, which provides guidance on accounting for the tax effects of the Tax Act. SAB 118 provides a measurement period that should not extend beyond one year from the Tax Act enactment date for companies to complete the accounting under ASC 740. In accordance with SAB 118, a company must reflect the income tax effects of those aspects of the Tax Act for which the accounting under ASC 740 is complete. To the extent that a company’s accounting for certain income tax effects of the Tax Act is incomplete but it is able to determine a reasonable estimate, it must record a provisional estimate in the financial statements. If a company cannot determine a provisional estimate to be included in the financial statements, it should continue to apply ASC 740 on the basis of the provisions of the tax laws that were in effect immediately before the enactment of the Tax Act.

[0001628280-18-001086:notes:172]
In connection with our initial analysis of the impact of the Tax Act, we have recorded a provisional tax expense of $83 million as a result of the rate decrease, which was accounted for as discrete item in the tax provision for the second quarter of fiscal year 2018. We are required to recognize the effect of this rate change on our deferred tax assets and liabilities and deferred tax asset valuation allowances in the period the tax rate change was enacted.

[0001628280-18-001086:notes:173]
The reduction in the U.S. federal statutory rate is expected to positively impact our federal cash tax liability.  However, the ultimate impact is subject to the effect of other complex provisions in the Act (including the BEAT and GILTI), which we are currently reviewing, and it is possible that any impact of BEAT and GILTI could significantly reduce the benefit of the reduction in the U.S. federal statutory rate. Due to the uncertain practical and technical application of many of these provisions, it is currently not possible to reliably estimate whether BEAT and GILTI will apply and, if so, how it would impact us. We will continue to analyze the Tax Act to assess the full effects on our financial results for the June 30, 2018 fiscal year-end.

[0001628280-18-001086:notes:174]
Our accounting for the following elements of the Tax Act is incomplete. However, we were able to make reasonable estimates of certain effects and, therefore, recorded provisional adjustments as follows:

[0001628280-18-001086:notes:175]
•The Tax Act reduces the corporate tax rate to 21 percent, effective January 1, 2018. For certain of our deferred tax assets and deferred tax liabilities, we have recorded a provisional net decrease of deferred tax assets by $83 million, with a corresponding net adjustment to deferred income tax expense of $83 million, which was accounted for as discrete item in the tax provision for the second quarter of fiscal year 2018. While we are able to make a reasonable estimate of the impact of the reduction in corporate rate, it may be affected by other analyses related to the Tax Act, including, but not limited to, our calculation of deemed repatriation of deferred foreign income and the state tax effect of adjustments made to federal temporary differences.

[0001628280-18-001086:notes:176]
•The Deemed Repatriation Transition Tax (“Transition Tax”) is a tax on previously untaxed accumulated and current earnings and profits (“E&P”) of certain of our foreign subsidiaries. To determine the amount of the Transition Tax, we must determine, in addition to other factors, the amount of post-1986 E&P of the relevant subsidiaries, as well as the amount of non-U.S. income taxes paid on such earnings.  We are continuing to gather additional information to more precisely compute the amount of the Transition Tax.

[0001628280-18-001086:notes:177]
•Due to complexity of the new GILTI tax rules, we are continuing to evaluate this provision of the Tax Act and the application of ASC 740. Under U.S. GAAP, we are allowed to make an accounting policy choice of either (1) treating taxes due on future U.S. inclusions in taxable income related to GILTI as a current-period expense when incurred (the “period cost method”) or (2) factoring such amounts into a company’s measurement of its deferred taxes (the “deferred method”). Our selection of an accounting policy with respect to the new GILTI tax rules will depend, in part, on analyzing our global income to determine whether we expect to have future U.S. inclusions in taxable income related to GILTI and, if so, what the impact is expected to be. Whether we expect to have future U.S. inclusions in taxable income related to GILTI depends not only on our current structure and estimated future results of global operations but also on our intent and ability to modify our structure and/or our business; as such, we are not yet able to reasonably estimate the effect of this provision of the Tax Act. Therefore, we have not made any adjustments related to potential GILTI tax in our financial statements and have not made a policy decision regarding whether to record deferred taxes on GILTI.

[0001628280-18-001086:notes:178]
As of December 30, 2017, we had $7.2 million of unrecognized tax benefits, which, if recognized, would affect the effective tax rate. We are subject to examination of income tax returns by various domestic and foreign tax authorities. The timing of resolutions and closures of tax audits is highly unpredictable. Given the uncertainty, it is reasonably possible that certain tax audits may be concluded within the next 12 months that could materially impact the balance of our gross unrecognized tax benefits. An estimate of the range of increase or decrease that could occur in the next twelve months cannot be made. However, the estimated impact to tax expense and net income from the resolution and closure of tax exams is not expected to be significant within the next 12 months.


## us-gaap:MinorityInterestDisclosureTextBlock

[0001628280-18-001086:notes:179]
Note 8. Non-Controlling Interest Redeemable Convertible Preferred Stock

[0001628280-18-001086:notes:180]
On July 31, 2015, our wholly-owned subsidiary, Lumentum Inc., issued 40,000 shares of its Series A Preferred Stock to Viavi Solutions Inc. (“Viavi”). Pursuant to a securities purchase agreement between the Company, Viavi and Amada Holdings Co., Ltd. (“Amada”), 35,805 shares of Series A Preferred Stock were sold by Viavi to Amada in August 2015. The remaining 4,195 shares of the Series A Preferred Stock were canceled. The Series A Preferred Stock is referred to as our Non-Controlling Interest Redeemable Convertible Preferred Stock within these condensed consolidated financial statements.

[0001628280-18-001086:notes:181]
The Series A Preferred Stock is redeemable at the option of Amada after five years and classified as non-controlling interest redeemable convertible preferred stock in our condensed consolidated balance sheet. The Series A Preferred Stock is measured at its redemption value. The Series A Preferred Stock value of $35.8 million as of December 30, 2017 has not changed from the prior year.

[0001628280-18-001086:notes:182]
The Series A Preferred Stock conversion feature is bifurcated from the Series A Preferred Stock and accounted for separately as a derivative liability. The derivative liability is measured at fair value each reporting period with the change in fair value recorded in the condensed consolidated statements of operations. Refer to “Note 10. Derivative Liability”.

[0001628280-18-001086:notes:183]
[same as prior period, unchanged from 0001633978-17-000119:notes:171]

[0001628280-18-001086:notes:184]
[same as prior period, unchanged from 0001633978-17-000119:notes:172]

[0001628280-18-001086:notes:185]
The Series A Preferred Stock is convertible, at the option of the holder, into shares of our common stock commencing on the second anniversary of the closing of the securities purchase (absent a change of control of us or similar event) using a conversion price of $24.63, which is equal to 125% of the volume weighted average price per share of our common stock in the five “regular-way” trading days following our separation from JDS Uniphase Corporation (“JDSU” and now, Viavi) in August 2015 (the “Separation”).

[0001628280-18-001086:notes:186]
[same as prior period, unchanged from 0001633978-17-000119:notes:174]

[0001628280-18-001086:notes:187]
[same as prior period, unchanged from 0001633978-17-000119:notes:175]

[0001628280-18-001086:notes:188]
[same as prior period, unchanged from 0001633978-17-000119:notes:176]

[0001628280-18-001086:notes:189]
[same as prior period, unchanged from 0001633978-17-000119:notes:177]

[0001628280-18-001086:notes:190]
The shares of Series A Preferred Stock have no voting rights except as follows:

[0001628280-18-001086:notes:191]
[same as prior period, unchanged from 0001633978-17-000119:notes:179]

[0001628280-18-001086:notes:192]
[same as prior period, unchanged from 0001633978-17-000119:notes:180]

[0001628280-18-001086:notes:193]
[same as prior period, unchanged from 0001633978-17-000119:notes:181]

[0001628280-18-001086:notes:194]
[same as prior period, unchanged from 0001633978-17-000119:notes:182]

[0001628280-18-001086:notes:195]
[same as prior period, unchanged from 0001633978-17-000119:notes:183]

[0001628280-18-001086:notes:196]
The accrued dividends as of December 30, 2017 and July 1, 2017 were $0.5 million and $0.2 million, respectively. No dividends were paid during the three months ended December 30, 2017. Dividends paid during the six months ended December 30, 2017 were $0.2 million.

[0001628280-18-001086:notes:197]
[same as prior period, unchanged from 0001633978-17-000119:notes:185]

[0001628280-18-001086:notes:198]
[same as prior period, unchanged from 0001633978-17-000119:notes:186]

[0001628280-18-001086:notes:199]
[same as prior period, unchanged from 0001633978-17-000119:notes:187]

[0001628280-18-001086:notes:200]
[same as prior period, unchanged from 0001633978-17-000119:notes:188]

[0001628280-18-001086:notes:201]
Commencing on the fifth anniversary of the Issuance Date of the Series A Preferred Stock, each holder of Series A Preferred Stock may cause the Company to redeem for cash any number of shares of Series A Preferred Stock on any date at a redemption price for share redeemed equal to the Issuance Value plus the accrued and unpaid dividends on each share and any past due dividends, whether or not authorized or declared.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001628280-18-001086:notes:202]
In October 2016, FASB issued ASU 2016-16, Accounting for Income Taxes: Intra-Entity Asset Transfers of Assets other than Inventory. The new guidance removes the prohibition in Accounting Standards Codification ASC 740, Income Taxes, against the immediate recognition of the current and deferred income tax effects of intra-entity transfers of assets other than inventory. The new guidance will be effective for us in our first quarter of fiscal 2019. We are currently evaluating the impact of the adoption of ASU 2016-16 on our condensed consolidated financial statements.

[0001628280-18-001086:notes:203]
In February 2016, FASB issued ASU 2016-02, Leases. The new guidance generally requires an entity to recognize on its balance sheet operating and financing lease liabilities and corresponding right-of-use assets. The standard is effective for us in our first quarter of fiscal 2020 and early adoption is permitted. We are currently evaluating the impact of the adoption of ASU 2016-02 on our condensed consolidated financial statements.

[0001628280-18-001086:notes:204]
In May 2014, FASB issued ASU 2014-09, Revenue from Contracts with Customers (“ASU 2014-09”), which amended the existing accounting standards for revenue recognition. ASU 2014-09 establishes principles for recognizing revenue upon the transfer of promised goods or services to customers, in an amount that reflects the consideration expected to be received in exchange for those goods or services. The new standard requires that reporting companies disclose the nature, amount, timing and uncertainty of revenue and cash flows arising from contracts with customers. On July 9, 2015, FASB agreed to delay the effective date by one year, and accordingly, the new standard is effective for us at the beginning of the first quarter of fiscal 2019. We do not expect to early adopt ASU 2014-09.

[0001628280-18-001086:notes:205]
The guidance to ASU 2014-09 permits two methods of adoption: retrospectively to each prior reporting period presented (full retrospective method), or retrospectively with the cumulative effect of initially applying the guidance recognized at the date of initial application (modified retrospective method). We anticipate adopting the standard using the modified retrospective method


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001628280-18-001086:notes:206]
Note 12. Restructuring and Related Charges

[0001628280-18-001086:notes:207]
The following table summarizes the activity of restructuring and related charges during the three and six months ended December 30, 2017 and December 31, 2016 (in millions):

[0001628280-18-001086:notes:208]
|  | Three Months Ended |  | Six Months Ended |
|  | December 30, 2017 |  | December 31, 2016 |  | December 30, 2017 |  | December 31, 2016 |
| Balance as of beginning of period | $ | 1.3 |  |  | $ | 5.3 |  |  | $ | 3.8 |  |  | $ | 5.7 |  |
| Charges | 0.8 |  |  | 4.0 |  |  | 3.7 |  |  | 6.9 |  |
| Payments | (1.7 | ) |  | (3.3 | ) |  | (7.1 | ) |  | (6.6 | ) |
| Balance as of end of period | $ | 0.4 |  |  | $ | 6.0 |  |  | $ | 0.4 |  |  | $ | 6.0 |  |

[0001628280-18-001086:notes:209]
We have initiated various strategic restructuring events primarily intended to reduce costs, consolidate our operations, rationalize the manufacturing of our products and align our business in response to the market conditions.

[0001628280-18-001086:notes:210]
During the three and six months ended December 30, 2017, we recorded $0.8 million and $3.7 million, respectively, in restructuring and related charges in the condensed consolidated statements of operations, primarily attributable to costs to vacate facilities, temporary labor and employee related benefits, as well as costs for materials used in set up and production activities. We incurred no additional costs related to severance for the same periods.

[0001628280-18-001086:notes:211]
During the three and six months ended December 31, 2016, we recorded $4.0 million and $6.9 million, respectively, in restructuring and related charges in the condensed consolidated statements of operations. Of the $4.0 million and $6.9 million charges recorded during the three and six months ended December 31, 2016, $1.3 million and $1.7 million, respectively, was related to severance, retention, and employee benefits; $2.7 million and $5.2 million, respectively, was related to other restructuring related charges which include relocation costs, temporary labor and employee related benefits, as well as costs for materials used in set up and production activities.

[0001628280-18-001086:notes:212]
Refer to “Note 5. Balance Sheet Details” in the Notes to Unaudited Condensed Consolidated Financial Statements for details of restructuring accrual and related charges balances.


## us-gaap:ScheduleOfEntityWideDisclosureOnGeographicAreasLongLivedAssetsInIndividualForeignCountriesByCountryTextBlock

[0001628280-18-001086:notes:213]
[same as prior period, unchanged from 0001633978-17-000119:notes:203]

[0001628280-18-001086:notes:214]
|  | As of |
|  | December 30, 2017 |  | July 1, 2017 |
| Property, Plant and Equipment, net |  |  |  |
| United States | $ | 98.4 |  |  | $ | 88.2 |  |
| China | 80.7 |  |  | 82.5 |  |
| Thailand | 87.3 |  |  | 85.3 |  |
| Other countries | 34.9 |  |  | 17.5 |  |
| Total long-lived assets | $ | 301.3 |  |  | $ | 273.5 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001628280-18-001086:notes:215]
[same as prior period, unchanged from 0001633978-17-000119:notes:205]

[0001628280-18-001086:notes:216]
|  | December 30, 2017 |  | July 1, 2017 |
| Finished goods | $ | 99.5 |  |  | $ | 71.7 |  |
| Work in process | 26.5 |  |  | 49.4 |  |
| Raw materials and purchased parts | 21.3 |  |  | 24.1 |  |
| Inventories | $ | 147.3 |  |  | $ | 145.2 |  |


## us-gaap:ScheduleOfOtherCurrentAssetsTableTextBlock

[0001628280-18-001086:notes:217]
[same as prior period, unchanged from 0001633978-17-000119:notes:207]

[0001628280-18-001086:notes:218]
|  | December 30, 2017 |  | July 1, 2017 |
| Capitalized manufacturing overhead | $ | 26.3 |  |  | $ | 30.1 |  |
| Prepayments | 6.4 |  |  | 12.3 |  |
| Advances to contract manufacturers | 15.1 |  |  | 10.5 |  |
| Other current assets | 12.1 |  |  | 10.6 |  |
| Prepayments and other current assets | $ | 59.9 |  |  | $ | 63.5 |  |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001628280-18-001086:notes:219]
[same as prior period, unchanged from 0001633978-17-000119:notes:209]

[0001628280-18-001086:notes:220]
|  | Three Months Ended |  | Six Months Ended |
|  | December 30, 2017 |  | December 31, 2016 |  | December 30, 2017 |  | December 31, 2016 |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States | $ | 25.9 |  |  | 6.4 | % |  | $ | 35.6 |  |  | 13.4 | % |  | $ | 59.5 |  |  | 9.2 | % |  | $ | 71.5 |  |  | 13.7 | % |
| Mexico | 30.6 |  |  | 7.6 |  |  | 48.7 |  |  | 18.4 |  |  | 55.4 |  |  | 8.6 |  |  | 88.5 |  |  | 16.9 |  |
| Other Americas | 2.0 |  |  | 0.5 |  |  | 1.9 |  |  | 0.7 |  |  | 4.2 |  |  | 0.6 |  |  | 5.9 |  |  | 1.1 |  |
| Total Americas | $ | 58.5 |  |  | 14.5 | % |  | $ | 86.2 |  |  | 32.5 | % |  | $ | 119.1 |  |  | 18.4 | % |  | $ | 165.9 |  |  | 31.7 | % |
| Asia-Pacific: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Hong Kong | $ | 45.7 |  |  | 11.3 | % |  | $ | 75.7 |  |  | 28.6 | % |  | $ | 94.6 |  |  | 14.6 | % |  | $ | 134.0 |  |  | 25.6 | % |
| Japan | 89.5 |  |  | 22.1 |  |  | 21.3 |  |  | 8.0 |  |  | 123.6 |  |  | 19.1 |  |  | 52.6 |  |  | 10.1 |  |
| South Korea | 86.5 |  |  | 21.4 |  |  | 1.0 |  |  | 0.4 |  |  | 97.4 |  |  | 15.0 |  |  | 2.7 |  |  | 0.5 |  |
| Philippines | 48.4 |  |  | 12.0 |  |  | 0.1 |  |  | — |  |  | 63.4 |  |  | 9.8 |  |  | 0.1 |  |  | — |  |
| Other Asia-Pacific | 50.5 |  |  | 12.5 |  |  | 51.9 |  |  | 19.6 |  |  | 98.8 |  |  | 15.3 |  |  | 115.6 |  |  | 22.1 |  |
| Total Asia-Pacific | $ | 320.6 |  |  | 79.3 | % |  | $ | 150.0 |  |  | 56.6 | % |  | $ | 477.8 |  |  | 73.8 | % |  | $ | 305.0 |  |  | 58.3 | % |
| EMEA | $ | 25.5 |  |  | 6.3 | % |  | $ | 28.8 |  |  | 10.9 | % |  | $ | 50.9 |  |  | 7.9 | % |  | $ | 52.2 |  |  | 10.0 | % |
| Total net revenue | $ | 404.6 |  |  |  |  | $ | 265.0 |  |  |  |  | $ | 647.8 |  |  |  |  | $ | 523.1 |  |  |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001628280-18-001086:notes:221]
[same as prior period, unchanged from 0001633978-17-000119:notes:211]

[0001628280-18-001086:notes:222]
|  | Three Months Ended |  | Six Months Ended |
|  | December 30, 2017 |  | December 31, 2016 |  | December 30, 2017 |  | December 31, 2016 |
| Net revenue: |  |  |  |  |  |  |  |
| OpComms | $ | 360.1 |  |  | $ | 236.6 |  |  | $ | 568.0 |  |  | $ | 454.9 |  |
| Lasers | 44.5 |  |  | 28.4 |  |  | 79.8 |  |  | 68.2 |  |
| Net revenue | $ | 404.6 |  |  | $ | 265.0 |  |  | $ | 647.8 |  |  | $ | 523.1 |  |
| Gross profit: |  |  |  |  |  |  |  |
| OpComms | 161.9 |  |  | 86.7 |  |  | 234.0 |  |  | 157.7 |  |
| Lasers | 19.9 |  |  | 11.2 |  |  | 30.5 |  |  | 28.4 |  |
| Total segment gross profit | 181.8 |  |  | 97.9 |  |  | 264.5 |  |  | 186.1 |  |
| Unallocated corporate items: |  |  |  |  |  |  |  |
| Stock-based compensation | (4.4 | ) |  | (2.1 | ) |  | (7.1 | ) |  | (4.1 | ) |
| Amortization of intangibles | (0.8 | ) |  | (1.7 | ) |  | (1.6 | ) |  | (3.4 | ) |
| Other charges (1) | (5.5 | ) |  | (7.1 | ) |  | (16.2 | ) |  | (9.9 | ) |
| Gross profit | $ | 171.1 |  |  | $ | 87.0 |  |  | $ | 239.6 |  |  | $ | 168.7 |  |

[0001628280-18-001086:notes:223]
(1) The increase in unallocated corporate items during the six months ended December 30, 2017 compared to the six months ended December 31, 2016 primarily relates to inventory write-downs due to canceled programs included in “Other charges” which were not allocated to the segments.


## us-gaap:SchedulesOfConcentrationOfRiskByRiskFactorTextBlock

[0001628280-18-001086:notes:224]
During the three and six months ended December 30, 2017 and December 31, 2016, net revenue generated from a single end customer which represented 10% or greater of total net revenue is summarized as follows:

[0001628280-18-001086:notes:225]
|  | Three Months Ended |  | Six Months Ended |
|  | December 30, 2017 |  | December 31, 2016 |  | December 30, 2017 |  | December 31, 2016 |
| Customer A | 49.8 | % |  | * |  |  | 37.2 | % |  | * |  |
| Customer B | * |  |  | 24.7 | % |  | 10.5 | % |  | 20.0 | % |
| Customer C | * |  |  | 17.5 | % |  | * |  |  | 16.6 | % |
| Customer D | * |  |  | * |  |  | * |  |  | 14.2 | % |
| *Represents less than 10% of total net revenue |  |  |  |  |  |  |  |

[0001628280-18-001086:notes:226]
During the three and six months ended December 30, 2017 and December 31, 2016, net inventory purchased from a single contract manufacturer which represented 10% or greater of total net purchases is summarized as follows:

[0001628280-18-001086:notes:227]
|  | Three Months Ended |  | Six Months Ended |
|  | December 30, 2017 |  | December 31, 2016 |  | December 30, 2017 |  | December 31, 2016 |
| Vendor A | 36.0 | % |  | 53.0 | % |  | 40.0 | % |  | 53.0 | % |
| Vendor B | 36.0 | % |  | * |  |  | 25.0 | % |  | * |  |
| Vendor C | 14.0 | % |  | 26.0 | % |  | 19.0 | % |  | 26.0 | % |
| Vendor D | * |  |  | 14.0 | % |  | * |  |  | 13.0 | % |
| *Represents less than 10% of total net purchases |  |  |  |  |  |  |  |

[0001628280-18-001086:notes:228]
The table below discloses the percentage of our total net revenue attributable to each of our two reportable segments. In addition, it discloses the percentage of our total net revenue attributable to our product offerings which serve the Telecom, Datacom and Consumer and Industrial markets which accounted for 10% or more of our total net revenue during the last three fiscal years:

[0001628280-18-001086:notes:229]
|  | Three Months Ended |  | Six Months Ended |
|  | December 30, 2017 |  | December 31, 2016 |  | December 30, 2017 |  | December 31, 2016 |
| OpComms: | 89.0 | % |  | 89.4 | % |  | 87.7 | % |  | 86.9 | % |
| Telecom | 27.2 | % |  | 60.5 | % |  | 34.1 | % |  | 62.3 | % |
| Datacom | 8.5 | % |  | 25.7 | % |  | 12.3 | % |  | 21.4 | % |
| Consumer and Industrial | 53.3 | % |  | 3.2 | % |  | 41.3 | % |  | 3.2 | % |
| Lasers | 11.0 | % |  | 10.6 | % |  | 12.3 | % |  | 13.1 | % |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001628280-18-001086:notes:230]
Note 16. Operating Segments and Geographic Information

[0001628280-18-001086:notes:231]
[same as prior period, unchanged from 0001633978-17-000119:notes:217]

[0001628280-18-001086:notes:232]
We have two operating segments, Optical Communications, which we refer to as OpComms, and Commercial Lasers, which we refer to as Lasers. Our OpComms products address the following markets: telecommunications (“Telecom”), data communications (“Datacom”), and consumer and industrial (“Consumer and Industrial”). The two operating segments were primarily determined based on how the CODM views and evaluates our operations. Operating results are regularly reviewed by the CODM to make decisions about resources to be allocated to the segments and to assess their performance. Other factors, including market separation and customer specific applications, go-to-market channels, products and manufacturing, are considered in determining the formation of these operating segments.

[0001628280-18-001086:notes:233]
[same as prior period, unchanged from 0001633978-17-000119:notes:219]

[0001628280-18-001086:notes:234]
[same as prior period, unchanged from 0001633978-17-000119:notes:220]

[0001628280-18-001086:notes:235]
We purchase a substantial portion of our inventory from contract manufacturers and vendors located primarily in Taiwan, Thailand, and China.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001628280-18-001086:notes:236]
Note 5. Balance Sheet Details

[0001628280-18-001086:notes:237]
[same as prior period, unchanged from 0001633978-17-000119:notes:224]

[0001628280-18-001086:notes:238]
As of December 30, 2017 and July 1, 2017, our accounts receivable allowance balance was $1.6 million and $1.8 million, respectively.

[0001628280-18-001086:notes:239]
[same as prior period, unchanged from 0001633978-17-000119:notes:226]

[0001628280-18-001086:notes:240]
[same as prior period, unchanged from 0001633978-17-000119:notes:227]

[0001628280-18-001086:notes:241]
[same as prior period, unchanged from 0001633978-17-000119:notes:228]

[0001628280-18-001086:notes:242]
During the three and six months ended December 30, 2017, we recorded a depreciation expense of $18.2 million and $34.9 million, respectively. During the three and six months ended December 31, 2016, we recorded a depreciation expense of $13.1 million and $25.0 million, respectively.

[0001628280-18-001086:notes:243]
Our construction in progress primarily includes machinery and equipment that were purchased to increase our manufacturing capacity. We expect to place these assets in service in the next 12 months.

[0001628280-18-001086:notes:244]
[same as prior period, unchanged from 0001633978-17-000119:notes:230]

[0001628280-18-001086:notes:245]
[same as prior period, unchanged from 0001633978-17-000119:notes:231]
