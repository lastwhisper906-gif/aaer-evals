# LITE note change history — 0001633978-17-000119 → 0001628280-18-001086


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2018-02-06):
[0001628280-18-001086:note_history:1]
We lease certain real and personal property from unrelated third parties under non-cancellable operating leases that expire at various dates through fiscal 2026. Certain leases require us to pay property taxes, insurance and routine maintenance, and include escalation clauses. As of December 30, 2017, the future minimum annual lease payments under non-cancellable operating leases were as follows (in millions):
  (was, 2017-11-01, similarity 0.9913):
[0001633978-17-000119:note_history:1]
We lease certain real and personal property from unrelated third parties under non-cancellable operating leases that expire at various dates through fiscal 2026. Certain leases require us to pay property taxes, insurance and routine maintenance, and include escalation clauses. As of September 30, 2017 the future minimum annual lease payments under non-cancellable operating leases were as follows (in millions):

- changed (2018-02-06):
[0001628280-18-001086:note_history:2]
| Fiscal Years |  |
| Remainder of 2018 | $ | 5.6 |  |
| 2019 | 11.3 |  |
| 2020 | 8.5 |  |
| 2021 | 4.7 |  |
| 2022 | 3.1 |  |
| Thereafter | 4.0 |  |
| Total minimum operating lease payments | $ | 37.2 |  |
  (was, 2017-11-01, similarity 0.9404):
[0001633978-17-000119:note_history:2]
| Remainder of 2018 | $ | 8.6 |  |
| 2019 | 11.4 |  |
| 2020 | 8.5 |  |
| 2021 | 4.7 |  |
| 2022 | 3.1 |  |
| Thereafter | 4.0 |  |
| Total minimum operating lease payments | $ | 40.3 |  |

- added (2018-02-06):
[0001628280-18-001086:note_history:3]
During the three and six months ended December 30, 2017, rental expense relating to building and equipment was $3.0 million and $6.4 million, respectively. During the three and six months ended December 31, 2016, rental expense relating to building and equipment was $2.2 million and $4.4 million, respectively.

- changed (2018-02-06):
[0001628280-18-001086:note_history:4]
As of December 30, 2017, equipment acquired under a capital lease agreement was $15.6 million. Our capital lease asset is included in property, plant and equipment, net in our condensed consolidated balance sheets as of December 30, 2017. Amortization expense on this capital lease asset is recorded as depreciation expense and is included in cost of sales in our condensed consolidated statements of operations for the three and six months ended December 30, 2017. Our capital lease obligation is recorded at the lesser of the estimated fair market value of the leased property or the net present value of the aggregate future minimum lease payments and is included in other current liabilities and other non-current liabilities in our condensed consolidated balance sheets as of December 30, 2017. Refer to “Note 5. Balance Sheet Details” for further details. Interest on these obligations is included in interest expense in our condensed consolidated statements of operations.
  (was, 2017-11-01, similarity 0.8977):
[0001633978-17-000119:note_history:4]
In the first quarter of fiscal 2018, we started leasing equipment under a capital lease. Our capital lease asset is included in property, plant and equipment, net in our condensed consolidated balance sheets as of September 30, 2017. Amortization expense on this capital lease asset is recorded as depreciation expense and is included in cost of sales in our condensed consolidated statements of operations for the three months ended September 30, 2017. Our capital lease obligation is recorded at the lesser of the estimated fair market value of the leased property or the net present value of the aggregate future minimum lease payments and is included in other current liabilities and other non-current liabilities in our condensed consolidated balance sheets as of September 30, 2017. Refer to “Note 6. Balance Sheet Details” for further details. Interest on these obligations is included in interest expense in our condensed consolidated statements of operations.

- changed (2018-02-06):
[0001628280-18-001086:note_history:5]
As of December 30, 2017 the future minimum annual lease payments under our capital lease were as follows (in millions):
  (was, 2017-11-01, similarity 0.9782):
[0001633978-17-000119:note_history:5]
As of September 30, 2017 the future minimum annual lease payments under our capital lease were as follows (in millions):

- added (2018-02-06):
[0001628280-18-001086:note_history:6]
| Fiscal Years |  |
| Remainder of 2018 | $ | 7.0 |  |
| 2019 | 7.5 |  |
| 2020 | 0.4 |  |
| Thereafter | — |  |
| Total minimum capital lease payments | $ | 14.9 |  |
| Less: amount representing interest | $ | (0.4 | ) |
| Present value of capital lease obligation | $ | 14.5 |  |

- added (2018-02-06):
[0001628280-18-001086:note_history:7]
We incurred liabilities in the amount of $3.6 million in connection with the fiscal 2017 acquisition. The amount of $2.7 million is payable 36 months following the acquisition date contingent upon meeting certain production targets. We retained $0.9 million of the purchase price as security for any potential liabilities of the seller under the representations, warranties and indemnifications included in the purchase agreement, which amount less any amounts required to cover seller’s indemnification obligations is payable to the seller at the 15 month anniversary of the close date.

- changed (2018-02-06):
[0001628280-18-001086:note_history:8]
The future interest and principal payments related to the 2024 Notes are as follows as of December 30, 2017:
  (was, 2017-11-01, similarity 0.9751):
[0001633978-17-000119:note_history:8]
The future interest and principal payments related to the 2024 Notes are as follows as of September 30, 2017:

- changed (2018-02-06):
[0001628280-18-001086:note_history:9]
| Fiscal Years |  |
| Remainder of 2018 | $ | 0.6 |  |
| 2019 | 1.1 |  |
| 2020 | 1.1 |  |
| 2021 | 1.1 |  |
| 2022 | 1.1 |  |
| Thereafter | 451.7 |  |
| Total 2024 Notes payments | $ | 456.7 |  |
  (was, 2017-11-01, similarity 0.9338):
[0001633978-17-000119:note_history:9]
| Remainder of 2018 | $ | 0.6 |  |
| 2019 | 1.1 |  |
| 2020 | 1.1 |  |
| 2021 | 1.1 |  |
| 2022 | 1.1 |  |
| Thereafter | 451.7 |  |
| Total 2024 Notes payments | $ | 456.7 |  |

- changed (2018-02-06):
[0001628280-18-001086:note_history:10]
Purchase obligations of $187.4 million as of December 30, 2017, represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule and adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.
  (was, 2017-11-01, similarity 0.9939):
[0001633978-17-000119:note_history:10]
Purchase obligations of $184.6 million as of September 30, 2017, represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule and adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

- changed (2018-02-06):
[0001628280-18-001086:note_history:11]
The following table presents the changes in our warranty reserve during the three and six months ended December 30, 2017 and December 31, 2016 (in millions):
  (was, 2017-11-01, similarity 0.9301):
[0001633978-17-000119:note_history:11]
The following table presents the changes in our warranty reserve during the three months ended September 30, 2017 and October 1, 2016 (in millions):

- added (2018-02-06):
[0001628280-18-001086:note_history:12]
|  | Three Months Ended |  | Six Months Ended |
|  | December 30, 2017 |  | December 31, 2016 |  | December 30, 2017 |  | December 31, 2016 |
| Balance as of beginning of period | $ | 9.4 |  |  | $ | 5.4 |  |  | $ | 9.7 |  |  | $ | 2.8 |  |
| Provision for warranty | 1.9 |  |  | 4.9 |  |  | 2.9 |  |  | 8.7 |  |
| Utilization of reserve | (1.4 | ) |  | (1.6 | ) |  | (2.7 | ) |  | (2.8 | ) |
| Balance as of end of period | $ | 9.9 |  |  | $ | 8.7 |  |  | $ | 9.9 |  |  | $ | 8.7 |  |

- added (2018-02-06):
[0001628280-18-001086:note_history:13]
In the normal course of business, we enter into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown because claims may be made against us in the future and we may record charges in the future as a result of these indemnification obligations. As of December 30, 2017, we did not have any material indemnification claims that were probable or reasonably possible.

- removed (2018-02-06):
[0001633978-17-000119:note_history:14]
Included in the future minimum lease payments table above is $0.2 million related to lease commitments in connection with our restructuring and related activities. Refer to “Note 13. Restructuring and Related Charges” in the Notes to Unaudited Condensed Consolidated Financial Statements.

- removed (2018-02-06):
[0001633978-17-000119:note_history:15]
Rental expense relating to building and equipment was $3.4 million, and $2.2 million for the three months ended September 30, 2017 and October 1, 2016, respectively.

- removed (2018-02-06):
[0001633978-17-000119:note_history:16]
| Remainder of 2018 | $ | 3.7 |  |
| 2019 | 3.8 |  |
| Total minimum capital lease payments | $ | 7.5 |  |

- removed (2018-02-06):
[0001633978-17-000119:note_history:17]
The Company incurred liabilities in the amount of $3.6 million in connection with the fiscal 2017 acquisition. The amount of $2.7 million is payable in 36 months following the acquisition date contingent upon meeting certain production targets. The Company retained $0.9 million of the purchase price to cover any potential liabilities under the representations, warranties and indemnifications included in the purchase agreement, the amount is payable at the 15 month anniversary of the close date. Refer to “Note 5. Mergers and Acquisitions”.

- removed (2018-02-06):
[0001633978-17-000119:note_history:18]
|  | Three Months Ended |
|  | September 30, 2017 |  | October 1, 2016 |
| Balance as of July 1, 2017 | $ | 9.7 |  |  | $ | 2.8 |  |
| Provision for warranty | 1.0 |  |  | 3.8 |  |
| Utilization of reserve | (1.3 | ) |  | (1.2 | ) |
| Balance as of September 30, 2017 | $ | 9.4 |  |  | $ | 5.4 |  |

- removed (2018-02-06):
[0001633978-17-000119:note_history:19]
In the normal course of business, the Company enters into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown because claims may be made against the Company in the future and the Company may record charges in the future as a result of these indemnification obligations. As of September 30, 2017, the Company did not have any material indemnification claims that were probable or reasonably possible.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2018-02-06):
[0001628280-18-001086:note_history:20]
Lumentum (we, us, our or the Company) is an industry-leading provider of optical and photonic products defined by revenue and market share addressing a range of end market applications including Optical Communications (“OpComms”) and Commercial Lasers (“Lasers”) for manufacturing, inspection and life-science applications. We seek to use our core optical and photonic technology and our volume manufacturing capability to expand into attractive emerging markets that benefit from advantages that optical or photonics-based solutions provide, including 3D sensing for consumer electronics and diode light sources for a variety of consumer and industrial applications. The majority of our customers tend to be original equipment manufacturers (“OEMs”) that incorporate our products into their products which then address end-market applications. For example, we sell fiber optic components that our network equipment manufacturer (“NEM”) customers assemble into communications networking systems, which they sell to network service providers or enterprises with their own networks. Similarly, many of our customers for our Lasers products incorporate our products into tools they produce, which are used for manufacturing processes by their customers. For 3D sensing, we sell diode lasers to manufacturers of consumer electronics products for mobile, personal computing, gaming, and other applications, who then integrate our devices within their products, for eventual resale to consumers.
  (was, 2017-11-01, similarity 0.9518):
[0001633978-17-000119:note_history:20]
Lumentum (we, us, our or the Company) is an industry-leading provider of optical and photonic products defined by revenue and market share addressing a range of end market applications including data communications (“Datacom”) and telecommunications (“Telecom”) networking and commercial lasers (“Commercial Lasers”) for manufacturing, inspection and life-science applications. We are using our core optical and photonic technology and our volume manufacturing capability to expand into attractive emerging markets that benefit from advantages that optical or photonics-based solutions provide, including 3D sensing for consumer electronics and diode light sources for a variety of consumer and industrial applications. The majority of our customers tend to be original equipment manufacturers (“OEMs”) that incorporate our products into their products which then address end-market applications. For example, we sell fiber optic components that our network equipment manufacturer (“NEM”) customers assemble into communications networking systems, which they sell to network service providers or enterprises with their own networks. Similarly, many of our customers for our Lasers products incorporate our products into tools they produce, which are used for manufacturing processes by their customers. For 3D sensing, we sell diode lasers to manufacturers of consumer electronics products for mobile, personal computing, gaming, and other applications, who then integrate our devices within their products, for eventual resale to consumers.

- changed (2018-02-06):
[0001628280-18-001086:note_history:21]
The preparation of the condensed consolidated financial statements in accordance with U.S. generally accepted accounting principles (“GAAP”) requires management to make estimates and assumptions that affect the amounts reported in our condensed consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates. Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are revenue recognition, inventory valuation, derivative liability valuation, long-lived asset valuation, warranty and accounting for income taxes.
  (was, 2017-11-01, similarity 0.9444):
[0001633978-17-000119:note_history:21]
The preparation of the condensed consolidated financial statements in accordance with GAAP in the United States requires management to make estimates and assumptions that affect the amounts reported in our condensed consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates. Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are revenue recognition, inventory valuation, valuation of derivative liability, long-lived asset valuation, warranty and accounting for income taxes.

- changed (2018-02-06):
[0001628280-18-001086:note_history:22]
Effective July 2, 2017, we adopted Accounting Standards Update (“ASU”) 2016-09, Stock Compensation ASU 718 - Improvements to Employee Share-Based Payment Accounting. As a result of the adoption, in the first quarter of fiscal year 2018, we recorded on a modified retrospective basis a $2.6 million cumulative-effect adjustment to retained earnings for the recognition of excess tax benefits generated by the settlement of share-based awards in prior periods. We elected to account for forfeitures of equity awards when they occur. The change was applied on a modified retrospective basis with a cumulative-effect adjustment of approximately $0.2 million to retained earnings in the fiscal first quarter of 2018.
  (was, 2017-11-01, similarity 0.8659):
[0001633978-17-000119:note_history:22]
The Company adopted ASU 2016-09, Stock Compensation ASU 718 - Improvements to Employee Share-Based Payment Accounting at the beginning of the first quarter of fiscal year 2018. As a result of the adoption, in the first quarter of fiscal year 2018, the Company recorded on a modified retrospective basis a $2.6 million cumulative-effect adjustment to retained earnings for the recognition of excess tax benefits generated by the settlement of share-based awards in prior periods. The Company elected to account for forfeitures of equity awards when they occur. The change was applied on a modified retrospective basis with a cumulative-effect adjustment of approximately $0.2 million to retained earnings in the first quarter of fiscal year 2018.

- changed (2018-02-06):
[0001628280-18-001086:note_history:23]
All excess tax benefits and deficiencies are recognized in the income tax provision in the condensed consolidated statements of operations prospectively, rather than in additional paid-in-capital in the condensed consolidated balance sheets. In addition, the standard eliminates the requirement to defer recognition of excess tax benefits until they are realized through a reduction to income taxes payable. We present excess tax benefits as an operating activity in the condensed consolidated statements of cash flows on a prospective basis.
  (was, 2017-11-01, similarity 0.7605):
[0001633978-17-000119:note_history:23]
All excess tax benefits and deficiencies are recognized in the income tax provision in the Condensed Consolidated Statements of Operations prospectively, rather than in additional paid-in-capital in the condensed consolidated balance sheets. In addition, the standard eliminates the requirement to defer recognition of excess tax benefits until they are realized through a reduction to income taxes payable. The Company presents excess tax benefits as an operating activity in the Condensed Consolidated Statements of Cash Flows on a prospective basis.


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-02-06):
[0001628280-18-001086:note_history:24]
As of December 30, 2017, the 2024 Notes consisted of the following (in millions):
  (was, 2017-11-01, similarity 0.9655):
[0001633978-17-000119:note_history:24]
As of September 30, 2017, the 2024 Notes consisted of the following (in millions):

- changed (2018-02-06):
[0001628280-18-001086:note_history:25]
| Liability component: | December 30, 2017 |  | July 1, 2017 |
| Principal | $ | 450.0 |  |  | $ | 450.0 |  |
| Unamortized debt discount | (124.3 | ) |  | (132.5 | ) |
| Net carrying amount of the liability component | $ | 325.7 |  |  | $ | 317.5 |  |
  (was, 2017-11-01, similarity 0.6194):
[0001633978-17-000119:note_history:25]
| Liability component: | September 30, 2017 |  | July 1, 2017 |
| Principal | $ | 450.0 |  |  | $ | 450.0 |  |
| Unamortized debt discount | (128.4 | ) |  | (132.5 | ) |
| Net carrying amount of the liability component | $ | 321.6 |  |  | $ | 317.5 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-02-06):
[0001628280-18-001086:note_history:26]
In March 2017, we issued the 2024 Notes in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act of 1933, as amended (the “Securities Act”). The 2024 Notes are governed by an indenture between the Company, as the issuer, and U.S. Bank National Association, as trustee (the “Indenture”). The 2024 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.
  (was, 2017-11-01, similarity 0.9751):
[0001633978-17-000119:note_history:26]
In March 2017, the Company issued the 2024 Notes in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act of 1933, as amended (the “Securities Act”). The 2024 Notes are governed by an indenture between the Company, as the issuer, and U.S. Bank National Association, as trustee (the “Indenture”). The 2024 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by the Company.

- changed (2018-02-06):
[0001628280-18-001086:note_history:27]
The 2024 Notes bear interest at a rate of 0.25% per year. Interest on the 2024 Notes is payable semi-annually in arrears on March 15 and September 15 of each year, beginning on September 15, 2017. The 2024 Notes will mature on March 15, 2024, unless earlier repurchased by us or converted pursuant to their terms.
  (was, 2017-11-01, similarity 0.9777):
[0001633978-17-000119:note_history:27]
The 2024 Notes bear interest at a rate of 0.25% per year. Interest on the 2024 Notes is payable semi-annually in arrears on March 15 and September 15 of each year, beginning on September 15, 2017. The 2024 Notes will mature on March 15, 2024, unless earlier repurchased by the Company or converted pursuant to their terms.

- changed (2018-02-06):
[0001628280-18-001086:note_history:28]
The initial conversion rate of the 2024 Notes is 16.4965 shares of common stock per $1,000 principal amount of 2024 Notes, which is equivalent to an initial conversion price of approximately $60.62 per share, a 132.5% premium to the fair market value at the date of issuance. Prior to the close of business on the business day immediately preceding December 15, 2023, the 2024 Notes will be convertible only under the following circumstances: (1) during any fiscal quarter (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during the period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price on each applicable trading day; (2) during the five consecutive business day period after any five consecutive trading day period (the “measurement period”) in which the trading price per $1,000 principal amount of notes for each trading day of such measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate on each such trading day; or (3) upon the occurrence of specified corporate events. On or after December 15, 2023 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their notes at any time. In addition, upon the occurrence of a make-whole fundamental change, we will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert 2024 Notes in connection with such make-whole fundamental change.
  (was, 2017-11-01, similarity 0.985):
[0001633978-17-000119:note_history:28]
The initial conversion rate of the 2024 Notes is 16.4965 shares of common stock per $1,000 principal amount of 2024 Notes, which is equivalent to an initial conversion price of approximately $60.62 per share, a 132.5% premium to the fair market value at the date of issuance. Prior to the close of business on the business day immediately preceding December 15, 2023, the 2024 Notes will be convertible only under the following circumstances: (1) during any fiscal quarter (and only during such fiscal quarter), if the last reported sale price of the Company’s common stock for at least 20 trading days (whether or not consecutive) during the period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price on each applicable trading day; (2) during the five consecutive business day period after any five consecutive trading day period (the “measurement period”) in which the trading price per $1,000 principal amount of notes for each trading day of such measurement period was less than 98% of the product of the last reported sale price of the Company’s common stock and the applicable conversion rate on each such trading day; or (3) upon the occurrence of specified corporate events. On or after December 15, 2023 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their notes at any time. In addition, upon the occurrence of a make-whole fundamental change, the Company will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert its 2024 Notes in connection with such make-whole fundamental change.

- changed (2018-02-06):
[0001628280-18-001086:note_history:29]
We may not redeem the 2024 Notes prior to their maturity date and no sinking fund is provided for the 2024 Notes. Upon the occurrence of a fundamental change, holders may require us to repurchase all or a portion of their 2024 Notes for cash at a price equal to 100% of the principal amount of the 2024 Notes to be repurchased, plus any accrued and unpaid interest.
  (was, 2017-11-01, similarity 0.9639):
[0001633978-17-000119:note_history:29]
The Company may not redeem the 2024 Notes prior to their maturity date and no sinking fund is provided for the 2024 Notes. Upon the occurrence of a fundamental change, holders may require the Company to repurchase all or a portion of their 2024 Notes for cash at a price equal to 100% of the principal amount of the 2024 Notes to be repurchased, plus any accrued and unpaid interest.

- changed (2018-02-06):
[0001628280-18-001086:note_history:30]
We considered the features embedded in the 2024 Notes other than the conversion feature, including the holders’ put feature, our call feature, and the make-whole feature, and concluded that they are not required to be bifurcated and accounted for separately from the host debt instrument.
  (was, 2017-11-01, similarity 0.9508):
[0001633978-17-000119:note_history:30]
The Company considered the features embedded in the 2024 Notes other than the conversion feature, including the holders’ put feature, the Company’s call feature, and the make-whole feature, and concluded that they are not required to be bifurcated and accounted for separately from the host debt instrument.

- added (2018-02-06):
[0001628280-18-001086:note_history:31]
Prior to the Tax Matters Agreement settlement condition (“TMA settlement condition”), because we could only settle the 2024 Notes in cash, we determined that the conversion feature met the definition of a derivative liability. We separated the derivative liability from the host debt instrument based on the fair value of the derivative liability. As of the issuance date, March 8, 2017, the derivative liability fair value of $129.9 million was calculated using the binomial valuation approach. The residual principal amount of the 2024 Notes of $320.1 million before issuance costs was allocated to the debt component. We incurred approximately $7.7 million in transaction costs in connection with the issuance of the 2024 Notes. These costs were allocated to the debt component and recognized as a debt discount. We amortize the debt discount, including both the initial value of the derivative liability and the transaction costs, over the term of the 2024 Notes using the effective interest method. The effective interest rate of the 2024 Notes is 5.4% per year. As of December 30, 2017, the remaining debt discount amortization period was 74 months.

- changed (2018-02-06):
[0001628280-18-001086:note_history:32]
During the year ended July 1, 2017, we satisfied the TMA settlement conditions. As such, the value of the conversion option will no longer be marked to market and was reclassified to additional paid-in capital within stockholders’ equity on our condensed consolidated balance sheet. The value of the conversion option at the time of issuance will be treated as an original issue discount for purposes of accounting for the debt component of the notes. The debt component will accrete up to the principal amount over the expected term of the debt. These accounting standards do not affect the actual amount we are required to repay, and the amount shown in the table below for the notes is the aggregate principal amount of the notes and does not reflect the debt discount we will be required to recognize.
  (was, 2017-11-01, similarity 0.9857):
[0001633978-17-000119:note_history:32]
During year ended July 1, 2017, the Company satisfied the TMA settlement conditions. As such, the value of the conversion option is no longer be marked to market and was reclassified to additional paid-in capital within stockholders’ equity on our condensed consolidated balance sheet. The value of the conversion option at the time of issuance will be treated as an original issue discount for purposes of accounting for the debt component of the notes. The debt component will accrete up to the principal amount over the expected term of the debt. These accounting standards do not affect the actual amount we are required to repay, and the amount shown in the table below for the notes is the aggregate principal amount of the notes and does not reflect the debt discount we will be required to recognize.

- changed (2018-02-06):
[0001628280-18-001086:note_history:33]
As of December 30, 2017, the 2024 Notes consisted of the following (in millions):
  (was, 2017-11-01, similarity 0.9655):
[0001633978-17-000119:note_history:33]
As of September 30, 2017, the 2024 Notes consisted of the following (in millions):

- changed (2018-02-06):
[0001628280-18-001086:note_history:34]
| Liability component: | December 30, 2017 |  | July 1, 2017 |
| Principal | $ | 450.0 |  |  | $ | 450.0 |  |
| Unamortized debt discount | (124.3 | ) |  | (132.5 | ) |
| Net carrying amount of the liability component | $ | 325.7 |  |  | $ | 317.5 |  |
  (was, 2017-11-01, similarity 0.6194):
[0001633978-17-000119:note_history:34]
| Liability component: | September 30, 2017 |  | July 1, 2017 |
| Principal | $ | 450.0 |  |  | $ | 450.0 |  |
| Unamortized debt discount | (128.4 | ) |  | (132.5 | ) |
| Net carrying amount of the liability component | $ | 321.6 |  |  | $ | 317.5 |  |

- changed (2018-02-06):
[0001628280-18-001086:note_history:35]
The following table sets forth interest expense information related to the 2024 Notes for the three and six months ended December 30, 2017:
  (was, 2017-11-01, similarity 0.7757):
[0001633978-17-000119:note_history:35]
The following table sets forth interest expense information related to the 2024 Notes:

- added (2018-02-06):
[0001628280-18-001086:note_history:36]
|  | December 30, 2017 |
| (in millions, except percentages) | Three Months Ended |  | Six Months Ended |
| Contractual interest expense | $ | 0.3 |  |  | $ | 0.6 |  |
| Amortization of the debt discount | 4.1 |  |  | 8.2 |  |
| Total interest expense | $ | 4.4 |  |  | $ | 8.8 |  |
| Effective interest rate on the liability component | 5.4 | % |  | 5.4 | % |

- changed (2018-02-06):
[0001628280-18-001086:note_history:37]
We have the ability and intent to settle the $450 million face value of the debt in cash. Therefore, we use the treasury stock method for calculating the dilutive impact of the debt. The 2024 Notes will have no impact to diluted earnings per share until the average price of our common stock exceeds the conversion price.
  (was, 2017-11-01, similarity 0.7938):
[0001633978-17-000119:note_history:37]
The Company has the ability and intent to settle the $450 million face value of the debt in cash. Therefore, the Company will use the treasury stock method for calculating the dilutive impact of the debt. The 2024 Notes will have no impact to diluted earnings per share until the average price of our common stock exceeds the conversion price. The Notes are required to be excluded from the calculation of diluted earnings per share, as they would be anti-dilutive.

- removed (2018-02-06):
[0001633978-17-000119:note_history:38]
Prior to the Tax Matters Agreement settlement condition (“TMA settlement condition”), because the Company could only settle the 2024 Notes in cash, the Company determined that the conversion feature met the definition of a derivative liability. The Company separated the derivative liability from the host debt instrument based on the fair value of the derivative liability. As of the issuance date, March 8, 2017, the derivative liability fair value of $129.9 million was calculated using the binomial valuation approach. The residual principal amount of the 2024 Notes of $320.1 million before issuance costs was allocated to the debt component. The Company incurred approximately $7.7 million in transaction costs in connection with the issuance of the 2024 Notes. These costs were allocated to the debt component and recognized as a debt discount. The Company amortizes the debt discount, including both the initial value of the derivative liability and the transaction costs, over the term of the 2024 Notes using the effective interest method. The effective interest rate of the 2024 Notes is 5.4% per year. As of September 30, 2017, the remaining debt discount amortization period was 77 months.

- removed (2018-02-06):
[0001633978-17-000119:note_history:39]
| (in millions, except percentages) | September 30, 2017 |
| Contractual interest expense | $ | 0.3 |  |
| Amortization of the debt discount | 4.1 |  |
| Total interest cost | $ | 4.4 |  |
| Effective interest rate on the liability component | 5.4 | % |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-02-06):
[0001628280-18-001086:note_history:40]
The future interest and principal payments related to the 2024 Notes are as follows as of December 30, 2017:
  (was, 2017-11-01, similarity 0.9751):
[0001633978-17-000119:note_history:40]
The future interest and principal payments related to the 2024 Notes are as follows as of September 30, 2017:

- changed (2018-02-06):
[0001628280-18-001086:note_history:41]
| Fiscal Years |  |
| Remainder of 2018 | $ | 0.6 |  |
| 2019 | 1.1 |  |
| 2020 | 1.1 |  |
| 2021 | 1.1 |  |
| 2022 | 1.1 |  |
| Thereafter | 451.7 |  |
| Total 2024 Notes payments | $ | 456.7 |  |
  (was, 2017-11-01, similarity 0.9338):
[0001633978-17-000119:note_history:41]
| Remainder of 2018 | $ | 0.6 |  |
| 2019 | 1.1 |  |
| 2020 | 1.1 |  |
| 2021 | 1.1 |  |
| 2022 | 1.1 |  |
| Thereafter | 451.7 |  |
| Total 2024 Notes payments | $ | 456.7 |  |
