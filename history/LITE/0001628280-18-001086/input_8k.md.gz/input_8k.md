# LITE 8-K — 0001628280-18-001082 filed 2018-02-06

## item codes, every 8-K on or before 2018-02-06

- 2018-02-06 0001628280-18-001082 — 2.02, 9.01
- 2017-11-08 0001633978-17-000133 — 5.02, 9.01
- 2017-11-07 0001633978-17-000131 — 5.07
- 2017-11-01 0001633978-17-000117 — 2.02, 9.01
- 2017-08-09 0001633978-17-000058 — 2.02, 9.01
- 2017-05-04 0001633978-17-000035 — 2.02, 9.01
- 2017-03-08 0001193125-17-074740 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2017-03-02 0001193125-17-066769 — 8.01, 9.01
- 2017-02-07 0001633978-17-000005 — 2.02, 9.01
- 2017-01-03 0001628280-17-000018 — 4.01, 9.01
- 2016-11-09 0001628280-16-021143 — 5.02, 5.07, 9.01
- 2016-10-27 0001628280-16-020382 — 2.02, 9.01
- 2016-08-09 0001628280-16-018811 — 2.02, 9.01
- 2016-06-21 0001628280-16-017201 — 8.01
- 2016-05-04 0001628280-16-015501 — 2.02, 9.01
- 2016-02-16 0001628280-16-011261 — 5.02, 9.01
- 2016-02-04 0001628280-16-010758 — 5.02, 9.01
- 2016-02-04 0001628280-16-010755 — 2.02, 9.01
- 2015-11-17 0001193125-15-378953 — 7.01
- 2015-11-10 0001628280-15-008606 — 2.02, 9.01
- 2015-09-28 0001193125-15-329665 — 8.01, 9.01
- 2015-08-11 0001193125-15-286405 — 7.01, 9.01
- 2015-08-06 0001193125-15-281219 — 1.01, 5.02, 5.03, 5.05, 8.01, 9.01
- 2015-08-03 0001193125-15-274808 — 5.03, 9.01

## late-filing notifications on or before 2018-02-06

- 2015-11-10 0001628280-15-008612 — NT 10-Q, for the period ended 2015-09-26
- 2015-09-28 0001193125-15-329672 — NT 10-K, for the period ended 2015-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001628280-18-001082:8k_2_02:1]
EX-99.1
2
lite_ex991xq2fy18.htm
EXHIBIT 99.1

[0001628280-18-001082:8k_2_02:2]
Exhibit

[0001628280-18-001082:8k_2_02:3]
NEWS RELEASE

[0001628280-18-001082:8k_2_02:4]
LUMENTUM ANNOUNCES FISCAL SECOND QUARTER 2018 RESULTS

[0001628280-18-001082:8k_2_02:5]
Fiscal Second Quarter Highlights

[0001628280-18-001082:8k_2_02:6]
| • | Lumentum achieved record quarterly revenue, gross margin, operating margin, and earnings per share; all exceeded the high-end of guidance |

[0001628280-18-001082:8k_2_02:7]
| • | Net Revenue of $404.6 million |

[0001628280-18-001082:8k_2_02:8]
| • | GAAP Operating margin of 22.4%; Non-GAAP Operating margin of 28.3% |

[0001628280-18-001082:8k_2_02:9]
| • | GAAP diluted Net income per share of $3.17; Non-GAAP diluted Net income per share of $1.67 |

[0001628280-18-001082:8k_2_02:10]
Milpitas, Calif., February 6, 2018 – Lumentum Holdings Inc. (“Lumentum” or the “Company”) today reported results for its fiscal second quarter ended December 30, 2017.

[0001628280-18-001082:8k_2_02:11]
Net revenue for the fiscal second quarter of 2018 was $404.6 million, with GAAP net income of $204.8 million, or $3.17 per diluted share.  Net revenue for fiscal first quarter of 2018 was $243.2 million, with GAAP net income of $7.1 million, or $0.11 per diluted share. Net revenue for the fiscal second quarter of 2017 was $265.0 million, with GAAP net income of $11.8 million, or $0.19 per diluted share.

[0001628280-18-001082:8k_2_02:12]
Non-GAAP net income for the fiscal second quarter of 2018 was $107.8 million, or $1.67 per diluted share. Non-GAAP net income for fiscal first quarter of 2018 was $27.8 million, or $0.43 per diluted share. Non-GAAP net income for the fiscal second quarter of 2017 was $35.9 million, or $0.57 per diluted share. The Company held $624.5 million in total cash and short-term investments at the end of the fiscal second quarter of 2018.

[0001628280-18-001082:8k_2_02:13]
“We achieved record revenue and profitability and exceeded our guidance for the second quarter driven by strong demand and execution in our 3D sensing, ROADM, industrial and telecom pump laser businesses. Our performance demonstrates the power of Lumentum’s proprietary capabilities, which leverage many years of experience across multiple end markets,” said Alan Lowe, President and CEO. “Our proven capabilities position us well for the future as demand for our industrial lasers and ROADMs is strengthening, and 3D sensing opportunities are broadening to more customers and end markets.”

[0001628280-18-001082:8k_2_02:14]
Financial Overview – Fiscal Second Quarter Ended December 30, 2017

[0001628280-18-001082:8k_2_02:15]
|  | GAAP Results ($ in millions) |
|  | Q2 |  | Q1 |  | Q2 |  | Change |
|  | FY 2018 |  | FY 2018 |  | FY 2017 |  | Q/Q |  | Y/Y |
| Net revenue | $404.6 |  | $243.2 |  | $265.0 |  | 66.4% |  | 52.7% |
| Gross margin | 42.3% |  | 28.2% |  | 32.8% |  | 1,410bps |  | 950bps |
| Operating margin | 22.4% |  | 1.1% |  | 5.0% |  | 2,130bps |  | 1,740bps |
|  | Non-GAAP Results ($ in millions) |
|  | Q2 |  | Q1 |  | Q2 |  | Change |
|  | FY 2018 |  | FY 2018 |  | FY 2017 |  | Q/Q |  | Y/Y |
| Net revenue | $404.6 |  | $243.2 |  | $265.0 |  | 66.4% |  | 52.7% |
| Gross margin | 44.9% |  | 34.0% |  | 36.9% |  | 1,090bps |  | 800bps |
| Operating margin | 28.3% |  | 11.8% |  | 14.7% |  | 1,650bps |  | 1,360bps |

[0001628280-18-001082:8k_2_02:16]
|  | Net Revenue by Segment ($ in millions) |
|  | Q2 |  | % of |  | Q1 |  | Q2 |  | Change |
|  | FY 2018 |  | Net Revenue |  | FY 2018 |  | FY 2017 |  | Q/Q |  | Y/Y |
| Optical Communications | $360.1 |  | 89.0% |  | $207.9 |  | $236.6 |  | 73.2% |  | 52.2% |
| Lasers | 44.5 |  | 11.0% |  | 35.3 |  | 28.4 |  | 26.1% |  | 56.7% |
| Total | $404.6 |  | 100.0% |  | $243.2 |  | $265.0 |  | 66.4% |  | 52.7% |

[0001628280-18-001082:8k_2_02:17]
The tables above provide comparisons of quarterly results to prior periods, including sequential quarterly and year-over-year changes. A reconciliation between GAAP and non-GAAP measures is contained in this release under the section titled “Use of Non-GAAP Financial Measures.”

[0001628280-18-001082:8k_2_02:18]
Business Outlook

[0001628280-18-001082:8k_2_02:19]
The Company expects the following for the fiscal third quarter 2018:

[0001628280-18-001082:8k_2_02:20]
•Net Revenue to be in the range of $280 million to $305 million

[0001628280-18-001082:8k_2_02:21]
•Non-GAAP Operating margin of 15.5% to 18.0%

[0001628280-18-001082:8k_2_02:22]
•Non-GAAP diluted earnings per share of $0.65 to $0.80;

[0001628280-18-001082:8k_2_02:23]
Note:  Earnings per share based on approximately 65 million shares outstanding on a fully diluted basis

[0001628280-18-001082:8k_2_02:24]
Our projection of 65 million shares outstanding does not include the potentially dilutive effect of the convertible notes, as we have the ability and intent to settle the face value in cash; and therefore, we use the treasury stock method for calculating the dilutive impact of the 2024 Notes. The notes will have an impact on our non-GAAP diluted earnings per share when the average price of our common stock exceeds the conversion price of $60.62.

[0001628280-18-001082:8k_2_02:25]
We have not provided reconciliations from GAAP to non-GAAP measures for our outlook. A large portion of non-GAAP adjustments, such as derivative liability adjustments, restructuring charges, stock-based compensation, litigation, non-cash income tax expense and credits, and other costs and contingencies unrelated to current and future operations are by their nature highly volatile and we have low visibility as to the range that may be incurred in the future. For example, in the fiscal second quarter of 2018, we had a credit of $207.0 million primarily related to a release of a U.S. valuation allowance, which was offset by a write down of deferred tax assets in the amount of $83.0 million due to the lower corporate tax rate enacted under 2017 “Tax Cuts and Jobs Act” reform.

[0001628280-18-001082:8k_2_02:26]
Conference Call

[0001628280-18-001082:8k_2_02:27]
Lumentum will host a conference call on February 6, 2018 at 5:30am PT/8:30am ET. A live webcast of the call and the replay will be available on the Lumentum website at http://investor.lumentum.com through February 13, 2018, 8:59pm PT/11:59pm ET. Supporting materials outlining the Company’s latest financial results will be posted on http://investor.lumentum.com under the “Events and Presentations” section concurrently with this earnings press release. This press release is being furnished as an exhibit to a Current Report on Form 8-K filed with the Securities and Exchange Commission and will be available at http://www.sec.gov/.

[0001628280-18-001082:8k_2_02:28]
About Lumentum

[0001628280-18-001082:8k_2_02:29]
Lumentum (NASDAQ: LITE) is a market-leading manufacturer of innovative optical and photonic products enabling optical networking and commercial laser customers worldwide. Lumentum’s optical components and subsystems are part of virtually every type of telecom, enterprise, and data center network. Lumentum’s commercial lasers enable advanced manufacturing techniques and diverse applications including next-generation 3D sensing capabilities. Lumentum is headquartered in Milpitas, California with R&D, manufacturing, and sales offices worldwide.  For more information, visit https://www.lumentum.com/en.

[0001628280-18-001082:8k_2_02:30]
Forward-Looking Statements

[0001628280-18-001082:8k_2_02:31]
involve risks and uncertainties that could cause actual results to differ materially from those projected. Among the factors that could cause actual results to differ from those contemplated are: (a) quarter-over-quarter product mix fluctuations which can materially impact profitability measures due to the broad gross margin ranges across our portfolio; (b) continued decline of average selling prices across our businesses; (c) effects of seasonality; (d) the ability of our suppliers and contract manufacturers to meet production and delivery requirements to our forecasted demand; (e) inherent uncertainty related to global markets and the effect of such markets on demand for our products; (f) changes in customer demand; and (g) our ability to attract and retain new customers, particularly in the 3D sensing market. For more information on these and other risks, please refer to the “Risk Factors” section included in the Company’s Quarterly Report on Form 10-Q for the fiscal second quarter ended December 30, 2017 filed with the Securities and Exchange Commission, and the Company’s other filings with the Securities and Exchange Commission. The forward-looking statements and preliminary financial results contained in this press release are made as of the date hereof and the Company assumes no obligation to update such statements, except as required by applicable law.

[0001628280-18-001082:8k_2_02:32]
Contact Information

[0001628280-18-001082:8k_2_02:33]
Investors: Chris Coldren, 408-404-0606; investor.relations@lumentum.com

[0001628280-18-001082:8k_2_02:34]
Press: Greg Kaufman, 408-546-4593; media@lumentum.com

[0001628280-18-001082:8k_2_02:35]
The following financial tables are presented in accordance with GAAP, unless otherwise specified.

[0001628280-18-001082:8k_2_02:36]
LUMENTUM HOLDINGS INC.

[0001628280-18-001082:8k_2_02:37]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0001628280-18-001082:8k_2_02:38]
(in millions, except per share data)

[0001628280-18-001082:8k_2_02:39]
(unaudited)

[0001628280-18-001082:8k_2_02:40]
|  | Three Months Ended |  | Six Months Ended |
|  | December 30, 2017 |  | December 31, 2016 |  | December 30, 2017 |  | December 31, 2016 |
| Net revenue | $ | 404.6 |  |  | $ | 265.0 |  |  | $ | 647.8 |  |  | $ | 523.1 |  |
| Cost of sales | 232.7 |  |  | 176.3 |  |  | 406.6 |  |  | 351.0 |  |
| Amortization of acquired developed technologies | 0.8 |  |  | 1.7 |  |  | 1.6 |  |  | 3.4 |  |
| Gross profit | 171.1 |  |  | 87.0 |  |  | 239.6 |  |  | 168.7 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 43.8 |  |  | 38.7 |  |  | 80.1 |  |  | 75.6 |  |
| Selling, general and administrative | 35.7 |  |  | 31.0 |  |  | 62.3 |  |  | 56.1 |  |
| Restructuring and related charges | 0.8 |  |  | 4.0 |  |  | 3.7 |  |  | 6.9 |  |
| Total operating expenses | 80.3 |  |  | 73.7 |  |  | 146.1 |  |  | 138.6 |  |
| Income from operations | 90.8 |  |  | 13.3 |  |  | 93.5 |  |  | 30.1 |  |
| Unrealized gain (loss) on derivative liability | 7.9 |  |  | 4.8 |  |  | 12.1 |  |  | (17.9 | ) |
| Interest and other income (expense), net | (3.2 | ) |  | (0.2 | ) |  | (6.6 | ) |  | — |  |
| Income before income taxes | 95.5 |  |  | 17.9 |  |  | 99.0 |  |  | 12.2 |  |
| Provision for (benefit from) income taxes | (109.3 | ) |  | 6.1 |  |  | (112.9 | ) |  | 3.8 |  |
| Net income | 204.8 |  |  | 11.8 |  |  | 211.9 |  |  | 8.4 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic | $ | 3.29 |  |  | $ | 0.20 |  |  | $ | 3.42 |  |  | $ | 0.14 |  |
| Diluted | $ | 3.17 |  |  | $ | 0.19 |  |  | $ | 3.29 |  |  | $ | 0.13 |  |
| Items reconciling net income to net income attributable to common stockholders: |  |  |  |  |  |  |  |
| Cumulative dividends on Series A Preferred Stock | (0.3 | ) |  | (0.2 | ) |  | (0.5 | ) |  | (0.4 | ) |
| Net income attributable to common stockholders | $ | 204.5 |  |  | $ | 11.6 |  |  | $ | 211.4 |  |  | $ | 8.0 |  |
| Net income per share attributable to common stockholders: |  |  |  |  |  |  |  |
| Basic | $ | 3.29 |  |  | $ | 0.19 |  |  | $ | 3.42 |  |  | $ | 0.13 |  |
| Diluted | $ | 3.17 |  |  | $ | 0.19 |  |  | $ | 3.29 |  |  | $ | 0.13 |  |
| Shares used in per share calculation: |  |  |  |  |  |  |  |
| Basic | 62.2 |  |  | 60.3 |  |  | 61.9 |  |  | 60.1 |  |
| Diluted | 64.6 |  |  | 62.7 |  |  | 64.5 |  |  | 62.6 |  |
| Diluted shares attributable to common stockholders | 64.6 |  |  | 62.7 |  |  | 64.5 |  |  | 61.1 |  |

[0001628280-18-001082:8k_2_02:41]
LUMENTUM HOLDINGS INC.

[0001628280-18-001082:8k_2_02:42]
CONSOLIDATED BALANCE SHEETS

[0001628280-18-001082:8k_2_02:43]
(in millions, except share and per share data)

[0001628280-18-001082:8k_2_02:44]
(unaudited)

[0001628280-18-001082:8k_2_02:45]
|  | December 30, 2017 |  | July 1, 2017 |
| ASSETS |  |  |  |  |  |
| Current assets: |  |  |  |  |  |
| Cash and cash equivalents | $ | 202.1 |  |  | $ | 272.9 |  |
| Short-term investments | 422.4 |  |  | 282.4 |  |
| Accounts receivable, net | 222.1 |  |  | 166.3 |  |
| Inventories | 147.3 |  |  | 145.2 |  |
| Prepayments and other current assets | 59.9 |  |  | 63.5 |  |
| Total current assets | 1,053.8 |  |  | 930.3 |  |
| Property, plant and equipment, net | 301.3 |  |  | 273.5 |  |
| Goodwill and intangibles, net | 20.4 |  |  | 21.5 |  |
| Deferred income taxes, net | 128.4 |  |  | 3.9 |  |
| Other non-current assets | 3.5 |  |  | 3.7 |  |
| Total assets | $ | 1,507.4 |  |  | $ | 1,232.9 |  |
| LIABILITIES, REDEEMABLE CONVERTIBLE PREFERRED STOCK, AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 113.0 |  |  | $ | 114.8 |  |
| Accrued payroll and related expenses | 40.2 |  |  | 27.5 |  |
| Income taxes payable | 5.5 |  |  | 0.7 |  |
| Accrued expenses | 29.6 |  |  | 19.3 |  |
| Other current liabilities | 29.4 |  |  | 21.9 |  |
| Total current liabilities | 217.7 |  |  | 184.2 |  |
| Convertible notes | 325.7 |  |  | 317.5 |  |
| Derivative liability | 39.5 |  |  | 51.6 |  |
| Other non-current liabilities | 24.4 |  |  | 25.0 |  |
| Total liabilities | 607.3 |  |  | 578.3 |  |
| Redeemable convertible preferred stock: |  |  |  |
| Non-controlling interest redeemable convertible Series A Preferred Stock, $0.001 par value, 10,000,000 authorized shares; 35,805 shares issued and outstanding as of December 30, 2017 and July 1, 2017 | 35.8 |  |  | 35.8 |  |
| Total redeemable convertible preferred stock | 35.8 |  |  | 35.8 |  |
| Stockholders’ equity: |  |  |  |
| Common stock, $0.001 par value, 990,000,000 authorized shares, 62,334,714 and 61,476,103 shares issued and outstanding as of December 30, 2017 and July 1, 2017, respectively | 0.1 |  |  | 0.1 |  |
| Additional paid-in capital | 724.8 |  |  | 694.5 |  |
| Retained earnings | 130.7 |  |  | (83.2 | ) |
| Accumulated other comprehensive income | 8.7 |  |  | 7.4 |  |
| Total stockholders’ equity | 864.3 |  |  | 618.8 |  |
| Total liabilities, redeemable convertible preferred stock, and stockholders’ equity | $ | 1,507.4 |  |  | $ | 1,232.9 |  |

[0001628280-18-001082:8k_2_02:46]
Use of Non-GAAP Financial Measures

[0001628280-18-001082:8k_2_02:47]
In this press release, Lumentum provides investors with gross margin, operating margin, net income, and net income (loss) per share on a non-GAAP basis. Lumentum believes this non-GAAP financial information provides additional insight into the Company’s on-going performance and has therefore chosen to provide this information to investors for a more consistent basis of comparison and to help them evaluate the results of the Company’s on-going operations and enable more meaningful period to period comparisons. Specifically, the Company believes that providing this information allows investors to better understand the Company’s financial performance and, importantly, to evaluate the efficacy of the methodology and information used by management to evaluate and measure such operating performance.  However, these measures may be different from non-GAAP measures used by other companies, limiting their usefulness for comparison purposes. The non-GAAP financial measures used in this press release should not be considered in isolation from measures of financial performance prepared in accordance with GAAP. Investors are cautioned that there are material limitations associated with the use of non-GAAP financial measures as an analytical tool. In particular, many of the adjustments to our GAAP financial measures reflect the exclusion of items that are recurring and will be reflected in our financial results for the foreseeable future. Further, these non-GAAP financial measures may not be comparable to similarly titled measurements reported by other companies.

[0001628280-18-001082:8k_2_02:48]
Non-GAAP gross margin, non-GAAP operating margin, non-GAAP net income, and non-GAAP net income per share, Adjusted EBITDA, non-GAAP gross profit, non-GAAP operating income, non-GAAP income (loss) before income taxes and non-GAAP expenses exclude (i) workforce related charges such as severance, retention bonuses and employee relocation costs related to formal restructuring plans, (ii) costs for facilities not required for ongoing operations, and costs related to the relocation of certain equipment from these facilities and/or contract manufacturer facilities, (iii) stock-based compensation, (iv) amortization of acquired developed technologies, (v) non-cash interest expense, (vi) unrealized loss on derivative liability, (vii) warranty charges related to our vendor quality issues with expected future recoveries, (viii) release of a U.S. valuation allowance and the write down of deferred tax assets due to the 2017 “Tax Cuts and Jobs Act”, and (ix) other charges comprised mainly of inventory write-downs due to cancelled programs, as well as, acquisition, integration, litigation and other costs and contingencies unrelated to current and future operations. Management does not believe that these non-GAAP items are reflective of the Company’s underlying operating performance. The presentation of these and other similar items in Lumentum’s non-GAAP financial results should not be interpreted as implying that these items are non-recurring, infrequent or unusual.

[0001628280-18-001082:8k_2_02:49]
A quantitative reconciliation between GAAP and non-GAAP financial data with respect to historical periods is included in the supplemental financial table attached to this press release.

[0001628280-18-001082:8k_2_02:50]
LUMENTUM HOLDINGS INC.

[0001628280-18-001082:8k_2_02:51]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001628280-18-001082:8k_2_02:52]
(in millions, except per share data)

[0001628280-18-001082:8k_2_02:53]
(unaudited)

[0001628280-18-001082:8k_2_02:54]
|  | Three Months Ended |  | Six Months Ended |
|  | December 30, 2017 |  | December 31, 2016 |  | December 30, 2017 |  | December 31, 2016 |
| Gross profit on GAAP basis | $ | 171.1 |  |  | $ | 87.0 |  |  | $ | 239.6 |  |  | $ | 168.7 |  |
| Stock-based compensation | 4.4 |  |  | 2.1 |  |  | 7.1 |  |  | 4.1 |  |
| Other charges related to non-recurring activities | 5.5 |  |  | 7.1 |  |  | 16.2 |  |  | 9.9 |  |
| Amortization of acquired developed technologies | 0.8 |  |  | 1.7 |  |  | 1.6 |  |  | 3.4 |  |
| Gross profit on non-GAAP basis | $ | 181.8 |  |  | $ | 97.9 |  |  | $ | 264.5 |  |  | $ | 186.1 |  |
| Research and development on GAAP basis | $ | 43.8 |  |  | $ | 38.7 |  |  | $ | 80.1 |  |  | $ | 75.6 |  |
| Stock-based compensation | (3.8 | ) |  | (3.0 | ) |  | (6.9 | ) |  | (5.8 | ) |
| Other charges related to non-recurring activities | (1.1 | ) |  | (0.3 | ) |  | (1.8 | ) |  | (0.6 | ) |
| Research and development on non-GAAP basis | $ | 38.9 |  |  | $ | 35.4 |  |  | $ | 71.4 |  |  | $ | 69.2 |  |
| Selling, general and administrative on GAAP basis | $ | 35.7 |  |  | $ | 31.0 |  |  | $ | 62.3 |  |  | $ | 56.1 |  |
| Stock-based compensation | (6.6 | ) |  | (4.0 | ) |  | (10.1 | ) |  | (6.9 | ) |
| Other charges related to non-recurring activities | (0.8 | ) |  | (3.4 | ) |  | (2.3 | ) |  | (3.8 | ) |
| Amortization of acquired developed technologies | — |  |  | (0.1 | ) |  | — |  |  | (0.2 | ) |
| Selling, general and administrative on non-GAAP basis | $ | 28.3 |  |  | $ | 23.5 |  |  | $ | 49.9 |  |  | $ | 45.2 |  |
| Income from operations on GAAP basis | $ | 90.8 |  |  | $ | 13.3 |  |  | $ | 93.5 |  |  | $ | 30.1 |  |
| Stock-based compensation | 14.8 |  |  | 9.1 |  |  | 24.1 |  |  | 16.8 |  |
| Other charges related to non-recurring activities | 7.4 |  |  | 10.8 |  |  | 20.3 |  |  | 14.3 |  |
| Amortization of acquired developed technologies | 0.8 |  |  | 1.8 |  |  | 1.6 |  |  | 3.6 |  |
| Restructuring and related charges | 0.8 |  |  | 4.0 |  |  | 3.7 |  |  | 6.9 |  |
| Income from operations on non-GAAP basis | $ | 114.6 |  |  | $ | 39.0 |  |  | $ | 143.2 |  |  | $ | 71.7 |  |
| Interest and other (expense) income, net on GAAP basis | $ | (3.2 | ) |  | $ | (0.2 | ) |  | $ | (6.6 | ) |  | $ | — |  |
| Non-cash other income (expense) | — |  |  | (0.2 | ) |  | — |  |  | (0.2 | ) |
| Effective interest expense on convertible notes | 4.1 |  |  | — |  |  | 8.2 |  |  | — |  |
| Interest and other (expense) income, net on non-GAAP basis | $ | 0.9 |  |  | $ | (0.4 | ) |  | $ | 1.6 |  |  | $ | (0.2 | ) |
| Income before income taxes on GAAP basis | $ | 95.5 |  |  | $ | 17.9 |  |  | $ | 99.0 |  |  | $ | 12.2 |  |
| Stock-based compensation | 14.8 |  |  | 9.1 |  |  | 24.1 |  |  | 16.8 |  |
| Other charges related to non-recurring activities | 7.4 |  |  | 10.8 |  |  | 20.3 |  |  | 14.3 |  |
| Amortization of acquired developed technologies | 0.8 |  |  | 1.8 |  |  | 1.6 |  |  | 3.6 |  |
| Restructuring and related charges | 0.8 |  |  | 4.0 |  |  | 3.7 |  |  | 6.9 |  |
| Non-cash other income (expense) | — |  |  | (0.2 | ) |  | — |  |  | (0.2 | ) |
| Effective interest expense on convertible notes | 4.1 |  |  | — |  |  | 8.2 |  |  | — |  |
| Unrealized (gain) loss on derivative liability | (7.9 | ) |  | (4.8 | ) |  | (12.1 | ) |  | 17.9 |  |
| Income before income taxes on non-GAAP basis | $ | 115.5 |  |  | $ | 38.6 |  |  | $ | 144.8 |  |  | $ | 71.5 |  |

[0001628280-18-001082:8k_2_02:55]
| Provision for (benefit from) income taxes on GAAP basis | $ | (109.3 | ) |  | $ | 6.1 |  |  | $ | (112.9 | ) |  | $ | 3.8 |  |
| Impact of non-GAAP income tax (benefit) expense (a) | 117.0 |  |  | (3.4 | ) |  | 122.1 |  |  | 1.1 |  |
| Provision for income taxes on non-GAAP basis | $ | 7.7 |  |  | $ | 2.7 |  |  | $ | 9.2 |  |  | $ | 4.9 |  |
| Net income on GAAP basis | $ | 204.8 |  |  | $ | 11.8 |  |  | $ | 211.9 |  |  | $ | 8.4 |  |
| Stock-based compensation | 14.8 |  |  | 9.1 |  |  | 24.1 |  |  | 16.8 |  |
| Other charges related to non-recurring activities | 7.4 |  |  | 10.8 |  |  | 20.3 |  |  | 14.3 |  |
| Amortization of acquired developed technologies | 0.8 |  |  | 1.8 |  |  | 1.6 |  |  | 3.6 |  |
| Restructuring and related charges | 0.8 |  |  | 4.0 |  |  | 3.7 |  |  | 6.9 |  |
| Non-cash other income (expense) | — |  |  | (0.2 | ) |  | — |  |  | (0.2 | ) |
| Effective interest expense on convertible notes | 4.1 |  |  | — |  |  | 8.2 |  |  | — |  |
| Unrealized (gain) loss on derivative liability | (7.9 | ) |  | (4.8 | ) |  | (12.1 | ) |  | 17.9 |  |
| Impact of non-GAAP income tax benefit (expense) (a) | (117.0 | ) |  | 3.4 |  |  | (122.1 | ) |  | (1.1 | ) |
| Net income on non-GAAP basis | $ | 107.8 |  |  | $ | 35.9 |  |  | $ | 135.6 |  |  | $ | 66.6 |  |
| Net income per share on non-GAAP basis | $ | 1.67 |  |  | $ | 0.57 |  |  | $ | 2.10 |  |  | $ | 1.06 |  |
| Shares used in per share calculation - diluted on non-GAAP basis | 64.6 |  |  | 62.7 |  |  | 64.5 |  |  | 62.6 |  |

[0001628280-18-001082:8k_2_02:56]
(a) The increase is primarily attributable to a credit of $207.0 million related to a release of a U.S. valuation allowance, which was offset by the write down of deferred tax assets due to the 2017 “Tax Cuts and Jobs Act” reform in the amount of $83.0 million.

[0001628280-18-001082:8k_2_02:57]
LUMENTUM HOLDINGS INC.

[0001628280-18-001082:8k_2_02:58]
RECONCILIATION OF GAAP NET INCOME (LOSS) TO ADJUSTED EBITDA

[0001628280-18-001082:8k_2_02:59]
(in millions)

[0001628280-18-001082:8k_2_02:60]
(unaudited)

[0001628280-18-001082:8k_2_02:61]
|  | Three Months Ended |  | Six Months Ended |
|  | December 30, 2017 |  | December 31, 2016 |  | December 30, 2017 |  | December 31, 2016 |
| GAAP net income | $ | 204.8 |  |  | $ | 11.8 |  |  | $ | 211.9 |  |  | $ | 8.4 |  |
| Interest and other expense (income), net | 3.2 |  |  | 0.2 |  |  | 6.6 |  |  | — |  |
| Provision for (benefit from) income taxes (a) | (109.3 | ) |  | 6.1 |  |  | (112.9 | ) |  | 3.8 |  |
| Depreciation | 18.2 |  |  | 13.1 |  |  | 34.9 |  |  | 25.0 |  |
| Amortization | 0.8 |  |  | 1.8 |  |  | 1.6 |  |  | 3.6 |  |
| EBITDA | 117.7 |  |  | 33.0 |  |  | 142.1 |  |  | 40.8 |  |
| Restructuring and related charges | 0.8 |  |  | 4.0 |  |  | 3.7 |  |  | 6.9 |  |
| Stock-based compensation | 14.8 |  |  | 9.1 |  |  | 24.1 |  |  | 16.8 |  |
| Other charges related to non-recurring activities | 7.4 |  |  | 10.8 |  |  | 20.3 |  |  | 14.3 |  |
| Unrealized (gain) loss on derivative liability | (7.9 | ) |  | (4.8 | ) |  | (12.1 | ) |  | 17.9 |  |
| Adjusted EBITDA | $ | 132.8 |  |  | $ | 52.1 |  |  | $ | 178.1 |  |  | $ | 96.7 |  |

[0001628280-18-001082:8k_2_02:62]
(a) The change is primarily attributable to a credit of $207.0 million related to a release of a U.S. valuation allowance, which was offset by the write down of deferred tax assets due to the 2017 “Tax Cuts and Jobs Act” reform in the amount of $83.0 million.
