# LITE MD&A — 0001628280-18-001086


## mdna

[0001628280-18-001086:mdna:1]
[same as prior period, unchanged from 0001633978-17-000119:mdna:1]

[0001628280-18-001086:mdna:2]
You should read the following discussion in conjunction with the unaudited condensed consolidated financial statements and the corresponding notes included elsewhere in this Quarterly Report on Form 10-Q (this “Quarterly Report”). This Management’s Discussion and Analysis of Financial Condition and Results of Operations contains forward-looking statements. The matters discussed in these forward-looking statements are subject to risk, uncertainties and other factors that could cause actual results to differ materially from those made, projected or implied in the forward-looking statements. Please see “Risk Factors” and “Forward-Looking Statements” for a discussion of the uncertainties, risks and assumptions associated with these statements.

[0001628280-18-001086:mdna:3]
Forward-Looking Statements

[0001628280-18-001086:mdna:4]
[same as prior period, unchanged from 0001633978-17-000119:mdna:6]

[0001628280-18-001086:mdna:5]
We are an industry-leading provider of optical and photonic products defined by revenue and market share addressing a range of end-market applications including Optical Communications, which we refer to as OpComms, and Lasers for manufacturing, inspection and life-science applications. We seek to use our core optical and photonic technology and our volume manufacturing capability to expand into attractive emerging markets that benefit from advantages that optical or photonics-based solutions provide, including 3D sensing for consumer electronics and diode light sources for a variety of consumer and industrial applications. We have two operating segments, OpComms and Lasers. The two operating segments were primarily determined based on how the CODM views and evaluates our operations. Operating results are regularly reviewed by the CODM to make decisions about resources to be allocated to the segments and to assess their performance. Other factors, including market separation and customer specific applications, go-to-market channels, products and manufacturing, are considered in determining the formation of these operating segments.

[0001628280-18-001086:mdna:6]
[same as prior period, unchanged from 0001633978-17-000119:mdna:8]

[0001628280-18-001086:mdna:7]
Our condensed consolidated financial statements are prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) as set forth in the Financial Accounting Standards Board’s Accounting Standards Codification (“ASC”), and we consider the various staff accounting bulletins and other applicable guidance issued by the United States Securities and Exchange Commission (“SEC”). GAAP, as set forth within the ASC, requires us to make certain estimates, judgments and assumptions. We believe that the estimates, judgments and assumptions upon which we rely are reasonable based upon information available to us at the time that these estimates, judgments and assumptions are made. These estimates, judgments and assumptions can affect the reported amounts of assets and liabilities as of the date of the financial statements as well as the reported amounts of revenues and expenses during the periods presented. To the extent there are differences between these estimates, judgments or assumptions and actual results, our financial statements will be affected. The accounting policies that reflect our more significant estimates, judgments and assumptions and which we believe are the most critical to aid in fully understanding and evaluating our reported financial results include the following:

[0001628280-18-001086:mdna:8]
[same as prior period, unchanged from 0001633978-17-000119:mdna:10]

[0001628280-18-001086:mdna:9]
[same as prior period, unchanged from 0001633978-17-000119:mdna:11]

[0001628280-18-001086:mdna:10]
[same as prior period, unchanged from 0001633978-17-000119:mdna:12]

[0001628280-18-001086:mdna:11]
[same as prior period, unchanged from 0001633978-17-000119:mdna:13]

[0001628280-18-001086:mdna:12]
[same as prior period, unchanged from 0001633978-17-000119:mdna:14]

[0001628280-18-001086:mdna:13]
[same as prior period, unchanged from 0001633978-17-000119:mdna:15]

[0001628280-18-001086:mdna:14]
During the first quarter of fiscal 2018, we removed the following policies from the list of critical accounting policies and estimates:

[0001628280-18-001086:mdna:15]
[same as prior period, unchanged from 0001633978-17-000119:mdna:17]

[0001628280-18-001086:mdna:16]
[same as prior period, unchanged from 0001633978-17-000119:mdna:18]

[0001628280-18-001086:mdna:17]
[same as prior period, unchanged from 0001633978-17-000119:mdna:19]

[0001628280-18-001086:mdna:18]
[same as prior period, unchanged from 0001633978-17-000119:mdna:20]

[0001628280-18-001086:mdna:19]
[same as prior period, unchanged from 0001633978-17-000119:mdna:21]

[0001628280-18-001086:mdna:20]
[same as prior period, unchanged from 0001633978-17-000119:mdna:22]

[0001628280-18-001086:mdna:21]
[same as prior period, unchanged from 0001633978-17-000119:mdna:23]

[0001628280-18-001086:mdna:22]
Recently Issued Accounting Pronouncements

[0001628280-18-001086:mdna:23]
Refer to “Note 2. Recently Issued Accounting Pronouncements” in the Notes to Unaudited Condensed Consolidated Financial Statements.

[0001628280-18-001086:mdna:24]
Results of Operations

[0001628280-18-001086:mdna:25]
[same as prior period, unchanged from 0001633978-17-000119:mdna:27]

[0001628280-18-001086:mdna:26]
|  | Three Months Ended |  | Six Months Ended |
|  | December 30, 2017 |  | December 31, 2016 |  | December 30, 2017 |  | December 31, 2016 |
| Segment net revenue: |  |  |  |  |  |  |  |
| OpComms | 89.0 | % |  | 89.3 | % |  | 87.7 | % |  | 87.0 | % |
| Lasers | 11.0 |  |  | 10.7 |  |  | 12.3 |  |  | 13.0 |  |
| Net revenue | 100.0 |  |  | 100.0 |  |  | 100.0 |  |  | 100.0 |  |
| Cost of sales | 57.5 |  |  | 66.6 |  |  | 62.8 |  |  | 67.1 |  |
| Amortization of acquired developed technologies | 0.2 |  |  | 0.6 |  |  | 0.2 |  |  | 0.6 |  |
| Gross profit | 42.3 |  |  | 32.8 |  |  | 37.0 |  |  | 32.3 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 10.8 |  |  | 14.6 |  |  | 12.4 |  |  | 14.5 |  |
| Selling, general and administrative | 8.8 |  |  | 11.7 |  |  | 9.6 |  |  | 10.7 |  |
| Restructuring and related charges | 0.2 |  |  | 1.5 |  |  | 0.6 |  |  | 1.3 |  |
| Total operating expenses | 19.8 |  |  | 27.8 |  |  | 22.6 |  |  | 26.5 |  |
| Income from operations | 22.5 |  |  | 5.0 |  |  | 14.4 |  |  | 5.8 |  |
| Unrealized gain (loss) on derivative liability | 2.0 |  |  | 1.8 |  |  | 1.9 |  |  | (3.4 | ) |
| Interest and other income (expense), net | (0.8 | ) |  | (0.1 | ) |  | (1.0 | ) |  | — |  |
| Income before income taxes | 23.7 |  |  | 6.7 |  |  | 15.3 |  |  | 2.4 |  |
| Provision for (benefit from) income taxes | (27.0 | ) |  | 2.3 |  |  | (17.4 | ) |  | 0.7 |  |
| Net income | 50.7 | % |  | 4.4 | % |  | 32.7 | % |  | 1.7 | % |

[0001628280-18-001086:mdna:27]
32

[0001628280-18-001086:mdna:28]
Financial Data for the three and six months ended December 30, 2017 and December 31, 2016

[0001628280-18-001086:mdna:29]
[same as prior period, unchanged from 0001633978-17-000119:mdna:30]

[0001628280-18-001086:mdna:30]
|  | Three Months Ended |  |  |  |  |  | Six Months Ended |  |  |  |  |
|  | December 30, 2017 |  | December 31, 2016 |  | Change |  | Percentage Change |  | December 30, 2017 |  | December 31, 2016 |  | Change |  | Percentage Change |
| Segment net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| OpComms | $ | 360.1 |  |  | $ | 236.6 |  |  | $ | 123.5 |  |  | 52.2 | % |  | $ | 568.0 |  |  | $ | 454.9 |  |  | $ | 113.1 |  |  | 24.9 | % |
| Lasers | 44.5 |  |  | 28.4 |  |  | 16.1 |  |  | 56.7 |  |  | 79.8 |  |  | 68.2 |  |  | 11.6 |  |  | 17.0 |  |
| Net revenue | $ | 404.6 |  |  | $ | 265.0 |  |  | $ | 139.6 |  |  | 52.7 | % |  | $ | 647.8 |  |  | $ | 523.1 |  |  | $ | 124.7 |  |  | 23.8 | % |
| Gross profit | $ | 171.1 |  |  | $ | 87.0 |  |  | $ | 84.1 |  |  | 96.7 | % |  | $ | 239.6 |  |  | $ | 168.7 |  |  | $ | 70.9 |  |  | 42.0 | % |
| Gross margin | 42.3 | % |  | 32.8 | % |  |  |  |  |  | 37.0 | % |  | 32.3 | % |  |  |  |  |
| Research and development | $ | 43.8 |  |  | $ | 38.7 |  |  | $ | 5.1 |  |  | 13.2 | % |  | $ | 80.1 |  |  | $ | 75.6 |  |  | $ | 4.5 |  |  | 6.0 | % |
| Percentage of net revenue | 10.8 | % |  | 14.6 | % |  |  |  |  |  | 12.4 | % |  | 14.5 | % |  |  |  |  |
| Selling, general and administrative | $ | 35.7 |  |  | $ | 31.0 |  |  | $ | 4.7 |  |  | 15.2 | % |  | $ | 62.3 |  |  | $ | 56.1 |  |  | $ | 6.2 |  |  | 11.1 | % |
| Percentage of net revenue | 8.8 | % |  | 11.7 | % |  |  |  |  |  | 9.6 | % |  | 10.7 | % |  |  |  |  |
| Restructuring and related charges | $ | 0.8 |  |  | $ | 4.0 |  |  | $ | (3.2 | ) |  | (80.0 | )% |  | $ | 3.7 |  |  | $ | 6.9 |  |  | $ | (3.2 | ) |  | (46.4 | )% |
| Percentage of net revenue | 0.2 | % |  | 1.5 | % |  |  |  |  |  | 0.6 | % |  | 1.3 | % |  |  |  |  |

[0001628280-18-001086:mdna:31]
[same as prior period, unchanged from 0001633978-17-000119:mdna:33]

[0001628280-18-001086:mdna:32]
Net revenue increased by $139.6 million, or 52.7%, during the three months ended December 30, 2017 compared to the three months ended December 31, 2016.

[0001628280-18-001086:mdna:33]
OpComms net revenue increased by $123.5 million, or 52.2%, during the three months ended December 30, 2017 compared to the three months ended December 31, 2016, driven by increased sales of Consumer and Industrial products, primarily 3D sensing, partially offset by decreases in Telecom and Datacom products. During the three months ended December 30, 2017, we rapidly expanded 3D sensing vertical-cavity surface-emitting lasers (“VCSEL”) capacity and production volumes.  Due to strong execution, we shipped more than $200 million of 3D sensing VCSEL arrays during the second quarter of fiscal 2018. During the third quarter of fiscal 2018, we expect 3D sensing revenues to decline.

[0001628280-18-001086:mdna:34]
Lasers net revenue increased by $16.1 million, or 56.7%, during the three months ended December 30, 2017 compared to the three months ended December 31, 2016, due to increased sales of solid state laser products.

[0001628280-18-001086:mdna:35]
Net revenue increased by $124.7 million, or 23.8%, during the six months ended December 30, 2017 compared to the six months ended December 31, 2016.

[0001628280-18-001086:mdna:36]
OpComms net revenue increased by $113.1 million, or 24.9%, during the six months ended December 30, 2017 compared to the six months ended December 31, 2016, driven by increased sales of Consumer and Industrial products, primarily 3D sensing, partially offset by decreased sales of Telecom and Datacom products.

[0001628280-18-001086:mdna:37]
Lasers net revenue increased by $11.6 million, or 17.0%, during the six months ended December 30, 2017 compared to the six months ended December 31, 2016, due to increased sales of solid state laser products.

[0001628280-18-001086:mdna:38]
During the three and six months ended December 30, 2017 and December 31, 2016, net revenue generated from a single end customer which represented 10% or greater of total net revenue is summarized as follows:

[0001628280-18-001086:mdna:39]
|  | Three Months Ended |  | Six Months Ended |
|  | December 30, 2017 |  | December 31, 2016 |  | December 30, 2017 |  | December 31, 2016 |
| APPLE | 49.8 | % |  | * |  |  | 37.2 | % |  | * |  |
| HUAWEI | * |  |  | 24.7 | % |  | 10.5 | % |  | 20.0 | % |
| CIENA | * |  |  | 17.5 | % |  | * |  |  | 16.6 | % |
| CISCO | * |  |  | * |  |  | * |  |  | 14.2 | % |
| *Represents less than 10% of total net revenue |  |  |  |  |  |  |  |

[0001628280-18-001086:mdna:40]
[same as prior period, unchanged from 0001633978-17-000119:mdna:35]

[0001628280-18-001086:mdna:41]
[same as prior period, unchanged from 0001633978-17-000119:mdna:36]

[0001628280-18-001086:mdna:42]
|  | Three Months Ended |  | Six Months Ended |
|  | December 30, 2017 |  | December 31, 2016 |  | December 30, 2017 |  | December 31, 2016 |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States | $ | 25.9 |  |  | 6.4 | % |  | $ | 35.6 |  |  | 13.4 | % |  | $ | 59.5 |  |  | 9.2 | % |  | $ | 71.5 |  |  | 13.7 | % |
| Mexico | 30.6 |  |  | 7.6 |  |  | 48.7 |  |  | 18.4 |  |  | 55.4 |  |  | 8.6 |  |  | 88.5 |  |  | 16.9 |  |
| Other Americas | 2.0 |  |  | 0.5 |  |  | 1.9 |  |  | 0.7 |  |  | 4.2 |  |  | 0.6 |  |  | 5.9 |  |  | 1.1 |  |
| Total Americas | $ | 58.5 |  |  | 14.5 | % |  | $ | 86.2 |  |  | 32.5 | % |  | $ | 119.1 |  |  | 18.4 | % |  | $ | 165.9 |  |  | 31.7 | % |
| Asia-Pacific: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Hong Kong | $ | 45.7 |  |  | 11.3 | % |  | $ | 75.7 |  |  | 28.6 | % |  | $ | 94.6 |  |  | 14.6 | % |  | $ | 134.0 |  |  | 25.6 | % |
| Japan | 89.5 |  |  | 22.1 |  |  | 21.3 |  |  | 8.0 |  |  | 123.6 |  |  | 19.1 |  |  | 52.6 |  |  | 10.1 |  |
| South Korea | 86.5 |  |  | 21.4 |  |  | 1.0 |  |  | 0.4 |  |  | 97.4 |  |  | 15.0 |  |  | 2.7 |  |  | 0.5 |  |
| Philippines | 48.4 |  |  | 12.0 |  |  | 0.1 |  |  | — |  |  | 63.4 |  |  | 9.8 |  |  | 0.1 |  |  | — |  |
| Other Asia-Pacific | 50.5 |  |  | 12.5 |  |  | 51.9 |  |  | 19.6 |  |  | 98.8 |  |  | 15.3 |  |  | 115.6 |  |  | 22.1 |  |
| Total Asia-Pacific | $ | 320.6 |  |  | 79.3 | % |  | $ | 150.0 |  |  | 56.6 | % |  | $ | 477.8 |  |  | 73.8 | % |  | $ | 305.0 |  |  | 58.3 | % |
| EMEA | $ | 25.5 |  |  | 6.3 | % |  | $ | 28.8 |  |  | 10.9 | % |  | $ | 50.9 |  |  | 7.9 | % |  | $ | 52.2 |  |  | 10.0 | % |
| Total net revenue | $ | 404.6 |  |  |  |  | $ | 265.0 |  |  |  |  | $ | 647.8 |  |  |  |  | $ | 523.1 |  |  |  |

[0001628280-18-001086:mdna:43]
During the three months ended December 30, 2017 and December 31, 2016, net revenue from customers outside the United States, based on customer shipping location, represented 93.6%, and 86.6% of net revenue, respectively. During the six months ended December 30, 2017 and December 31, 2016, net revenue from customers outside the United States, based on customer shipping location, represented 90.8%, and 86.3% of net revenue, respectively.

[0001628280-18-001086:mdna:44]
Our net revenue is primarily denominated in U.S. dollars, including our net revenue from customers outside the United States as presented above. We expect revenue from customers outside of the United States to continue to be an important part of our overall net revenue and an increasing focus for net revenue growth opportunities.

[0001628280-18-001086:mdna:45]
[same as prior period, unchanged from 0001633978-17-000119:mdna:39]

[0001628280-18-001086:mdna:46]
The following table summarizes segment gross margin for the three and six months ended December 30, 2017 and December 31, 2016 (in millions, except for percentages):

[0001628280-18-001086:mdna:47]
|  |  |  |  |  | Gross Margin |  |  |  | Gross Margin |
|  | Three Months Ended |  | Three Months Ended |  | Six Months Ended |  | Six Months Ended |
|  | December 30, 2017 |  | December 31, 2016 |  | December 30, 2017 |  | December 31, 2016 |  | December 30, 2017 |  | December 31, 2016 |  | December 30, 2017 |  | December 31, 2016 |
| OpComms | $ | 161.9 |  |  | $ | 86.7 |  |  | 45.0 | % |  | 36.6 | % |  | $ | 234.0 |  |  | $ | 157.7 |  |  | 41.2 | % |  | 34.7 | % |
| Lasers | 19.9 |  |  | 11.2 |  |  | 44.7 | % |  | 39.4 | % |  | 30.5 |  |  | 28.4 |  |  | 38.2 | % |  | 41.6 | % |
| Segment total | $ | 181.8 |  |  | $ | 97.9 |  |  | 44.9 | % |  | 36.9 | % |  | $ | 264.5 |  |  | $ | 186.1 |  |  | 40.8 | % |  | 35.6 | % |
| Unallocated corporate items (1) | (10.7 | ) |  | (10.9 | ) |  |  |  |  |  | (24.9 | ) |  | (17.4 | ) |  |  |  |  |
| Total | $ | 171.1 |  |  | $ | 87.0 |  |  | 42.3 | % |  | 32.8 | % |  | $ | 239.6 |  |  | $ | 168.7 |  |  | 37.0 | % |  | 32.3 | % |

[0001628280-18-001086:mdna:48]
(1) The unallocated corporate items for the years presented include the effects of amortization of acquired developed technology intangible assets, share-based compensation and certain other charges. We do not allocate these items to the gross margin for each segment because management does not include such information in measuring the performance of the operating segments. The increase in unallocated corporate items during the six months ended December 30, 2017 compared to the six months ended December 31, 2016 primarily relates to inventory write-downs due to canceled programs which were not allocated to the segments.

[0001628280-18-001086:mdna:49]
[same as prior period, unchanged from 0001633978-17-000119:mdna:43]

[0001628280-18-001086:mdna:50]
Gross margin during the three months ended December 30, 2017 increased by 9.5% to 42.3% from 32.8% in the same period a year ago. This increase was primarily due to increased sales in our 3D sensing and lasers products. The increase was partially offset by underutilized capacity costs due to the decline in Telecom and Datacom demand, as well as higher write-downs of excess and obsolete inventory.

[0001628280-18-001086:mdna:51]
Gross margin during the six months ended December 30, 2017 increased by 4.7% to 37.0% from 32.3% in the same period a year ago. This increase was primarily due to increased sales in our 3D sensing and lasers products. The increase was partially offset by underutilized capacity costs due to the decline in Telecom and Datacom demand, as well as higher write-downs of excess and obsolete inventory.

[0001628280-18-001086:mdna:52]
We sell products in certain markets that are consolidating, undergoing product, architectural and business model transitions, have high customer concentrations, are highly competitive, are price sensitive and/or are affected by customer seasonal and mix variant buying patterns. We expect these factors to continue to result in variability of our gross margin.

[0001628280-18-001086:mdna:53]
[same as prior period, unchanged from 0001633978-17-000119:mdna:46]

[0001628280-18-001086:mdna:54]
[same as prior period, unchanged from 0001633978-17-000119:mdna:47]

[0001628280-18-001086:mdna:55]
OpComms gross margin during the three months ended December 30, 2017 increased by 8.4% to 45.0% from 36.6% in the same period a year ago. This increase was primarily due to increased sales of our 3D sensing products. The increase was partially offset by underutilized capacity costs due to the decline in Telecom and Datacom demand, as well as higher write-downs of excess and obsolete inventory.

[0001628280-18-001086:mdna:56]
OpComms gross margin during the six months ended December 30, 2017 increased by 6.5% to 41.2% from 34.7% in the same period a year ago. This increase was primarily due to increased sales of our 3D sensing products, offset partially by underutilization of manufacturing capacity for our Telecom and Datacom products.

[0001628280-18-001086:mdna:57]
[same as prior period, unchanged from 0001633978-17-000119:mdna:49]

[0001628280-18-001086:mdna:58]
Lasers gross margin during the three months ended December 30, 2017 increased by 5.3% to 44.7% from 39.4% in the same period a year ago. This increase was primarily due to increased sales, product mix, as well as improved manufacturing utilization.

[0001628280-18-001086:mdna:59]
Lasers gross margin during the six months ended December 30, 2017 decreased by 3.4% to 38.2% from 41.6% in the same period a year ago. This decrease was primarily due to unfavorable product mix and a write-down of excess inventory.

[0001628280-18-001086:mdna:60]
[same as prior period, unchanged from 0001633978-17-000119:mdna:51]

[0001628280-18-001086:mdna:61]
R&D expense increased by $5.1 million, or 13.2%, during the three months ended December 30, 2017 compared to the three months ended December 31, 2016. The increase in R&D expense was primarily due to an increase in stock-based compensation of $0.8 million and an increase in payroll related expense of $3.8 million, which includes an increase in variable incentive compensation of $2.9 million.

[0001628280-18-001086:mdna:62]
R&D expense increased by $4.5 million, or 6.0%, during the six months ended December 30, 2017 compared to the six months ended December 31, 2016. The increase in R&D expense was primarily due to an increase in stock-based compensation of $1.1 million and an increase in payroll related expense of $3.3 million, which includes an increase in variable incentive compensation of $2.4 million.

[0001628280-18-001086:mdna:63]
[same as prior period, unchanged from 0001633978-17-000119:mdna:53]

[0001628280-18-001086:mdna:64]
[same as prior period, unchanged from 0001633978-17-000119:mdna:54]

[0001628280-18-001086:mdna:65]
SG&A expense increased by $4.7 million, or 15.2%, during the three months ended December 30, 2017 compared to the three months ended December 31, 2016. The increase was primarily attributable to an increase in stock based compensation of $2.6 million and an increase in payroll related expense of $3.0 million, which includes an increase in variable incentive compensation of $2.2 million.

[0001628280-18-001086:mdna:66]
SG&A expense increased by $6.2 million, or 11.1%, during the six months ended December 30, 2017 compared to the six months ended December 31, 2016. The increase was primarily attributable to an increase in stock based compensation of $3.1 million and an increase in payroll related expense of $3.8 million, which includes an increase in variable incentive compensation of $2.0 million.

[0001628280-18-001086:mdna:67]
We may experience in the future, certain non-core expenses, such as mergers and acquisitions-related expenses and litigation expenses, which could increase our SG&A expenses and potentially impact our profitability expectations in any particular quarter.

[0001628280-18-001086:mdna:68]
[same as prior period, unchanged from 0001633978-17-000119:mdna:57]

[0001628280-18-001086:mdna:69]
We have reduced costs through targeted restructuring efforts intended to consolidate our operations, rationalize the manufacturing of our products and align our business in response to market conditions. Refer to “Note 12. Restructuring and Related Charges” in the Notes to Unaudited Condensed Consolidated Financial Statements.

[0001628280-18-001086:mdna:70]
During the three and six months ended December 30, 2017, we recorded $0.8 million and $3.7 million, respectively, in restructuring and related charges in the condensed consolidated statements of operations, primarily attributable to costs to vacate facilities, temporary labor and employee related benefits, as well as costs for materials used in set up and production activities. We incurred no additional costs related to severance for the same periods.

[0001628280-18-001086:mdna:71]
During the three and six months ended December 31, 2016, we recorded $4.0 million and $6.9 million, respectively, in restructuring and related charges in the condensed consolidated statements of operations. Of the $ 4.0 million and $6.9 million charges recorded during the three months and six months ended December 31, 2016, $1.3 million and $1.7 million, respectively, was related to severance, retention, and employee benefits; $2.7 million and $5.2 million, respectively, was related to other restructuring related charges which include relocation costs, temporary labor and employee related benefits, as well as costs for materials used in set up and production activities.

[0001628280-18-001086:mdna:72]
[same as prior period, unchanged from 0001633978-17-000119:mdna:60]

[0001628280-18-001086:mdna:73]
The components of interest and other income (expense), net are as follows (in millions):

[0001628280-18-001086:mdna:74]
|  | Three Months Ended |  | Six Months Ended |
|  | December 30, 2017 |  | December 31, 2016 |  | December 30, 2017 |  | December 31, 2016 |
| Interest expense | $ | (4.6 | ) |  | $ | — |  |  | $ | (9.0 | ) |  | $ | — |  |
| Foreign exchange gains (losses), net | (0.3 | ) |  | 0.3 |  |  | (0.7 | ) |  | 0.5 |  |
| Other income (expense), net | 1.7 |  |  | (0.5 | ) |  | 3.1 |  |  | (0.5 | ) |
| Interest and other income (expense), net | $ | (3.2 | ) |  | $ | (0.2 | ) |  | $ | (6.6 | ) |  | $ | — |  |

[0001628280-18-001086:mdna:75]
For the three and six months ended December 30, 2017, interest and other income (expense) increased compared to the three and six months ended December 31, 2016, driven by amortization of the debt discount on the 2024 Notes, partially offset by interest income on the short-term investments and cash equivalents. See “Note 9. Convertible Senior Notes” in the Notes to the Unaudited Condensed Consolidated Financial Statements for additional information on the 2024 Notes.

[0001628280-18-001086:mdna:76]
Unrealized Gain (Loss) on Derivative Liability

[0001628280-18-001086:mdna:77]
Unrealized gain (loss) on Series A Preferred Stock derivative liability amounted to $7.9 million and $12.1 million, respectively, for the three and six months ended December 30, 2017 and $4.8 million and $(17.9) million, respectively, for the three and six months ended December 31, 2016. The change is primarily related to the change in the price of our underlying common stock and is reflected in the condensed consolidated statements of operations as “Unrealized gain (loss) on derivative liability”.

[0001628280-18-001086:mdna:78]
For further discussion of our derivative liability, see “Note 10. Derivative Liability” in the Notes to Unaudited Condensed Consolidated Financial Statements.

[0001628280-18-001086:mdna:79]
[same as prior period, unchanged from 0001633978-17-000119:mdna:68]

[0001628280-18-001086:mdna:80]
|  | Three Months Ended |  | Six Months Ended |
|  | December 30, 2017 |  | December 31, 2016 |  | December 30, 2017 |  | December 31, 2016 |
| Provision for (benefit from) income taxes | $ | (109.3 | ) |  | $ | 6.1 |  |  | $ | (112.9 | ) |  | $ | 3.8 |  |

[0001628280-18-001086:mdna:81]
Our tax provision for interim periods is determined using an estimate of its annual effective tax rate, adjusted for discrete items, if any, that arise during the period. Each quarter, we update our estimate of the annual effective tax rate and, if the estimated annual effective tax rate changes, we make a cumulative adjustment in such period.

[0001628280-18-001086:mdna:82]
Our quarterly tax provision and estimate of annual effective tax rate are subject to variation due to several factors, including variability in pre-tax income (or loss), the mix of jurisdictions to which such income relates, changes in how we do business, and tax law developments. Our estimated effective tax rate for the year differs from the U.S. statutory rate primarily due to the earnings of our foreign subsidiaries being taxed at rates lower than the U.S. statutory rate, partially offset by foreign earnings subject to the anti-deferral rules of the U.S. tax regime.

[0001628280-18-001086:mdna:83]
We recorded a tax benefit of $(109.3) million and $(112.9) million for the three and six months ended December 30, 2017, respectively. Our tax benefit for the three and six months ended December 30, 2017 was primarily due to the release of our U.S. federal and certain state valuation allowances.  The benefit of this valuation allowance release was partially offset by a non-cash deferred expense associated with the change in the U.S. statutory rate as a result of the Tax Act which was enacted during the three-month period ended December 30, 2017.

[0001628280-18-001086:mdna:84]
We recorded a tax provision of $6.1 million and $3.8 million for the three and six months ended December 31, 2016, respectively. Our tax provision for the three and six months ended December 31, 2016 was primarily due to the tax effect of our operating profits, non-deductible stock-based compensation, and unrecognized tax benefits, partially offset by benefit from the utilization of U.S. deferred tax assets that were subject to a full valuation allowance.

[0001628280-18-001086:mdna:85]
We assess our ability to realize our deferred tax assets on a quarterly basis and establish a valuation allowance if the deferred tax assets are not more-likely-than-not to be realized. We weigh all available positive and negative evidence, including our earnings history and results of recent operations, reversals of deferred tax liabilities, projected future taxable income, and tax planning strategies.

[0001628280-18-001086:mdna:86]
As of each reporting date, we consider new evidence, both positive and negative, that could affect our view of the future realization of deferred tax assets. As of December 30, 2017, we determined that there is sufficient positive evidence to conclude that it is more-likely-than-not that the deferred tax assets are realizable.  The positive evidence leading to this determination includes our recent earnings history and forecasted earnings for future periods. As a result, we released the valuation allowance against its U.S. federal and certain states deferred tax assets.  This resulted in the recognition of a tax benefit of $207 million as a discrete item for the second quarter of fiscal year 2018.  Due to the weight of negative evidence, we continue to maintain a full valuation allowance on our California deferred tax assets.

[0001628280-18-001086:mdna:87]
On December 22, 2017, the U.S. government enacted comprehensive tax legislation, the Tax Act. The Tax Act makes broad and complex changes to the U.S. tax code that will affect our fiscal year ending June 30, 2018, including, but not limited to, (1) a reduction in the U.S. federal corporate tax rate; (2) a transition tax on certain deferred income of foreign subsidiaries that, if the taxpayer so elects, is payable over eight years; and (3) bonus depreciation that allows full expensing of qualified property. The Tax Act reduces the federal corporate tax rate to 21 percent in the fiscal year ending June 30, 2018. Section 15 of the Internal Revenue Code stipulates that our fiscal year ending June 30, 2018, will have a blended corporate tax rate of 28 percent, which is based on the applicable tax rates before and after the Tax Act and the number of days in each period.

[0001628280-18-001086:mdna:88]
The Tax Act also establishes new tax laws that will affect our fiscal year ending June 30, 2019, including, but not limited to, (1) reduction of the U.S. federal corporate tax rate; (2) elimination of the corporate alternative minimum tax; (3) the creation of BEAT, a new minimum tax on taxable income adjusted for certain base erosion payments; (4) a general elimination of U.S. federal income taxes on dividends from foreign subsidiaries; (5) a new provision designed to currently tax GILTI, which allows for the possibility of using FTCs and a deduction of up to 50 percent to reduce this income tax liability (subject to some limitations); (6) a new limitation on deductible interest expense; (7) the repeal of the domestic production activity deduction; (8) limitations on the deductibility of certain executive compensation; (9) limitations on the use of FTCs to reduce the U.S. income tax liability; and (10) limitations on net operating losses generated in the taxable years beginning after December 31, 2017, to 80 percent of taxable income.

[0001628280-18-001086:mdna:89]
The SEC staff issued SAB 118, which provides guidance on accounting for the tax effects of the Tax Act. SAB 118 provides a measurement period that should not extend beyond one year from the Tax Act enactment date for companies to complete the accounting under ASC 740. In accordance with SAB 118, a company must reflect the income tax effects of those aspects of the Tax Act for which the accounting under ASC 740 is complete. To the extent that a company’s accounting for certain income tax effects of the Tax Act is incomplete but it is able to determine a reasonable estimate, it must record a provisional estimate in the financial statements. If a company cannot determine a provisional estimate to be included in the financial statements, it should continue to apply ASC 740 on the basis of the provisions of the tax laws that were in effect immediately before the enactment of the Tax Act.

[0001628280-18-001086:mdna:90]
In connection with our initial analysis of the impact of the Tax Act, we have recorded a provisional tax expense of $83 million as a result of the rate decrease, which was accounted for as discrete item in the tax provision for the second quarter of fiscal year 2018. This net expense was a result of the corporate rate reduction. We are required to recognize the effect of this rate change on our deferred tax assets and liabilities, and deferred tax asset valuation allowances in the period the tax rate change was enacted.

[0001628280-18-001086:mdna:91]
The reduction in the U.S. federal statutory rate is expected to positively impact our federal cash tax liability.  However, the ultimate impact is subject to the effect of other complex provisions in the Act (including BEAT and GILTI), which we are currently reviewing, and it is possible that any impact of BEAT and GILTI could significantly reduce the benefit of the reduction in the U.S. federal statutory rate. Due to the uncertain practical and technical application of many of these provisions, it is currently not possible to reliably estimate whether BEAT and GILTI will apply and, if so, how it would impact us. We will continue to analyze the Tax Act to assess the full effects on our financial results for the June 30, 2018 fiscal year-end.

[0001628280-18-001086:mdna:92]
As of December 30, 2017, we had $7.2 million of unrecognized tax benefits, which, if recognized, would affect the effective tax rate. We are subject to examination of income tax returns by various domestic and foreign tax authorities. The timing of resolutions and closures of tax audits is highly unpredictable. Given the uncertainty, it is reasonably possible that certain tax audits may be concluded within the next 12 months that could materially impact the balance of our gross unrecognized tax benefits. An estimate of the range of increase or decrease that could occur in the next twelve months cannot be made. However, the estimated impact to tax expense and net income from the resolution and closure of tax exams is not expected to be significant within the next 12 months.

[0001628280-18-001086:mdna:93]
For further discussion of our income tax provision, see “Note 13. Income Taxes” in the Notes to Unaudited Condensed Consolidated Financial Statements.

[0001628280-18-001086:mdna:94]
[same as prior period, unchanged from 0001633978-17-000119:mdna:76]

[0001628280-18-001086:mdna:95]
The following table summarizes our contractual obligations as of December 30, 2017, and the effect such obligations are expected to have on our liquidity and cash flow over the next five years (in millions):

[0001628280-18-001086:mdna:96]
|  | Payments due by period |
|  | Total |  | Less than 1 year |  | 1 - 3 years |  | 3 - 5 years |  | More than 5 years |
| Contractual Obligations |  |  |  |  |  |  |  |  |  |
| Asset retirement obligations | $ | 2.8 |  |  | $ | 0.3 |  |  | $ | 0.4 |  |  | $ | 0.5 |  |  | $ | 1.6 |  |
| Purchase obligations (1) | 187.4 |  |  | 179.1 |  |  | 8.3 |  |  | — |  |  | — |  |
| Operating lease obligations (1) | 37.2 |  |  | 13.8 |  |  | 14.5 |  |  | 6.6 |  |  | 2.3 |  |
| Capital lease obligation (1) | 14.9 |  |  | 11.7 |  |  | 3.2 |  |  | — |  |  | — |  |
| Pension and post-retirement benefit payments | 4.3 |  |  | 0.5 |  |  | 0.2 |  |  | 0.2 |  |  | 3.4 |  |
| 0.25% Convertible Senior Notes due 2024 | 450.0 |  |  | — |  |  | — |  |  | — |  |  | 450.0 |  |
| Interest on 2024 Notes (2) | 6.7 |  |  | 1.1 |  |  | 2.2 |  |  | 2.3 |  |  | 1.1 |  |
| Acquisition contingencies (1) | 2.7 |  |  | — |  |  | 2.7 |  |  | — |  |  | — |  |
| Total | $ | 706.0 |  |  | $ | 206.5 |  |  | $ | 31.5 |  |  | $ | 9.6 |  |  | $ | 458.4 |  |

[0001628280-18-001086:mdna:97]
(1) Refer to “Note 15. Commitments and Contingencies” in the Notes to Unaudited Condensed Consolidated Financial Statements.

[0001628280-18-001086:mdna:98]
(2) Includes interest on our 0.25% Convertible Senior Notes due 2024 through September 2023 as we have the right to redeem the 2024 Notes in whole or in part at any time on or after March 15, 2024. Refer to “Note 9. Convertible Senior Notes” in the Notes to Unaudited Condensed Consolidated Financial Statements.

[0001628280-18-001086:mdna:99]
[same as prior period, unchanged from 0001633978-17-000119:mdna:82]

[0001628280-18-001086:mdna:100]
As of December 30, 2017, our other current liabilities include $0.3 million of asset retirement obligations in connection with restructuring and related activities, disclosed in the preceding table.

[0001628280-18-001086:mdna:101]
As of December 30, 2017, our other non-current liabilities primarily relate to asset retirement obligations and pension which are presented in various lines in the preceding table.

[0001628280-18-001086:mdna:102]
As of December 30, 2017, our other non-current liabilities on the condensed consolidated balance sheet include $7.2 million of unrecognized tax benefit for uncertain tax positions. We are unable to reliably estimate the timing of future payments related to uncertain tax positions and therefore have excluded them from the preceding table.

[0001628280-18-001086:mdna:103]
[same as prior period, unchanged from 0001633978-17-000119:mdna:86]

[0001628280-18-001086:mdna:104]
[same as prior period, unchanged from 0001633978-17-000119:mdna:87]

[0001628280-18-001086:mdna:105]
[same as prior period, unchanged from 0001633978-17-000119:mdna:88]

[0001628280-18-001086:mdna:106]
[same as prior period, unchanged from 0001633978-17-000119:mdna:89]

[0001628280-18-001086:mdna:107]
[same as prior period, unchanged from 0001633978-17-000119:mdna:90]

[0001628280-18-001086:mdna:108]
As of December 30, 2017 and July 1, 2017, our cash and cash equivalents of $202.1 million and $272.9 million, respectively, were held predominantly in the United States. The total amount of cash outside the United States as of December 30, 2017 was $31.1 million, which was primarily held in Cayman Islands, Thailand, Japan, Switzerland, and China. Although the cash currently

[0001628280-18-001086:mdna:109]
held in the United States as well as the cash generated in the United States from future operations is expected to cover our normal operating requirements, a substantial amount of additional cash could be required for other purposes, such as capital expenditures to support our business and growth, including costs associated with increasing internal manufacturing capabilities, such as our new Thailand facility, strategic transactions and partnerships, and acquisitions. Our intent is to indefinitely reinvest funds held outside the United States and our current plans do not demonstrate a need to repatriate them to fund our domestic operations. However, if in the future, we encounter a significant need for liquidity domestically or at a particular location that we cannot fulfill through borrowings, equity offerings, or other internal or external sources, we may determine that cash repatriations are necessary. Repatriation could result in additional material taxes. These factors may cause us to have an overall tax rate higher than other companies or higher than our tax rates have been in the past. If conditions warrant, we may seek to obtain additional financing through debt or equity sources. To the extent we issue additional shares, our existing stockholders may be diluted. However, any such financing may not be available on terms favorable to us, or may not be available at all.

[0001628280-18-001086:mdna:110]
As of December 30, 2017, our consolidated balance of cash and cash equivalents decreased by $70.8 million, to $202.1 million from $272.9 million as of July 1, 2017. The decrease in cash and cash equivalents was mainly due to purchases of short-term investments, net of sales of $140.9 million and capital expenditures of $50.2 million, offset by cash provided by operating activities of $114.8 million during the six months ended December 30, 2017.

[0001628280-18-001086:mdna:111]
[same as prior period, unchanged from 0001633978-17-000119:mdna:93]

[0001628280-18-001086:mdna:112]
Cash provided by operating activities was $114.8 million during the six months ended December 30, 2017, primarily resulting from $211.9 million of net income, offset by $66.7 million of non-cash items (such as depreciation, stock-based compensation, amortization of intangibles, amortization of discount on the 2024 Notes, net of the release of the valuation allowance and unrealized gain on derivative liability), and $30.4 million of changes in our operating assets and liabilities. Changes in our operating assets and liabilities related primarily to an increase in accounts receivable of $55.8 million offset by an increase in accrued expenses and other current and non-current liabilities of $15.1 million.

[0001628280-18-001086:mdna:113]
Cash provided by operating activities was $55.5 million during the six months ended December 31, 2016, primarily resulting from $8.4 million of net income and $60.4 million of non-cash items such as depreciation, stock-based compensation, amortization of intangibles, unrealized gain on derivative liability, offset by changes in excess tax benefit associated with stock-based compensation and changes in operating assets and liabilities of $13.3 million. Changes in our operating assets and liabilities related primarily to an increase in accounts receivable of $22.0 million due to the timing of collections, an increase in inventories of $20.1 million related to the growth in our business, offset by a decrease in accrued expenses and other current and non-current liabilities of $12.5 million and a decrease in accrued payroll and related expenses of $9.6 million.

[0001628280-18-001086:mdna:114]
[same as prior period, unchanged from 0001633978-17-000119:mdna:96]

[0001628280-18-001086:mdna:115]
Cash used in investing activities of $191.1 million during the six months ended December 30, 2017 was primarily attributable to capital expenditures of $50.2 million and purchases of short-term investments, net of sales of $140.9 million.

[0001628280-18-001086:mdna:116]
Cash used in investing activities of $64.3 million during the six months ended December 31, 2016 was primarily attributable to capital expenditures.

[0001628280-18-001086:mdna:117]
[same as prior period, unchanged from 0001633978-17-000119:mdna:99]

[0001628280-18-001086:mdna:118]
During the six months ended December 30, 2017 and December 31, 2016, cash provided by financing activities of $4.7 million and $9.0 million, respectively, resulted primarily from the issuance of common stock under the employee stock plan.

[0001628280-18-001086:mdna:119]
[same as prior period, unchanged from 0001633978-17-000119:mdna:102]

[0001628280-18-001086:mdna:120]
We believe that our cash and cash equivalents as of December 30, 2017, and cash flows from our operating activities will be sufficient to meet our liquidity and capital spending requirements for at least the next 12 months. However, if market conditions are favorable, we may evaluate alternatives to opportunistically pursue additional financing.

[0001628280-18-001086:mdna:121]
[same as prior period, unchanged from 0001633978-17-000119:mdna:104]

[0001628280-18-001086:mdna:122]
[same as prior period, unchanged from 0001633978-17-000119:mdna:105]

[0001628280-18-001086:mdna:123]
[same as prior period, unchanged from 0001633978-17-000119:mdna:106]

[0001628280-18-001086:mdna:124]
[same as prior period, unchanged from 0001633978-17-000119:mdna:107]

[0001628280-18-001086:mdna:125]
[same as prior period, unchanged from 0001633978-17-000119:mdna:108]

[0001628280-18-001086:mdna:126]
[same as prior period, unchanged from 0001633978-17-000119:mdna:109]

[0001628280-18-001086:mdna:127]
[same as prior period, unchanged from 0001633978-17-000119:mdna:110]

[0001628280-18-001086:mdna:128]
[same as prior period, unchanged from 0001633978-17-000119:mdna:111]

[0001628280-18-001086:mdna:129]
[same as prior period, unchanged from 0001633978-17-000119:mdna:112]

[0001628280-18-001086:mdna:130]
[same as prior period, unchanged from 0001633978-17-000119:mdna:113]

[0001628280-18-001086:mdna:131]
[same as prior period, unchanged from 0001633978-17-000119:mdna:114]

[0001628280-18-001086:mdna:132]
[same as prior period, unchanged from 0001633978-17-000119:mdna:115]

[0001628280-18-001086:mdna:133]
| • | settlement of any conversion or redemption of the 2024 Notes in cash. |

[0001628280-18-001086:mdna:134]
41
