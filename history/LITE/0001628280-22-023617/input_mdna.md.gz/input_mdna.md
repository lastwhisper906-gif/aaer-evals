# LITE MD&A — 0001628280-22-023617


## mdna

[0001628280-22-023617:mdna:1]
ITEM 7.    MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0001628280-22-023617:mdna:2]
You should read the following discussion in conjunction with the audited consolidated financial statements and the corresponding notes included elsewhere in this Annual Report. This Management’s Discussion and Analysis of Financial Condition and Results of Operations contains forward-looking statements. The matters discussed in these forward-looking statements are subject to risk, uncertainties and other factors that could cause actual results to differ materially from those made, projected or implied in the forward-looking statements. Please refer to “Risk Factors” and “Forward-Looking Statements” for a discussion of the uncertainties, risks and assumptions associated with these statements.

[0001628280-22-023617:mdna:3]
Overview

[0001628280-22-023617:mdna:4]
We are an industry-leading provider of optical and photonic products, defined by revenue and market share, addressing a range of end-market applications including Optical Communications, which we refer to as OpComms, and Lasers for manufacturing, inspection and life-science applications. We have two operating segments, OpComms and Lasers. The two operating segments were primarily determined based on how the Chief Operating Decision Maker (“CODM”) views and evaluates our operations. Operating results are regularly reviewed by the CODM to make decisions about resources to be allocated to the segments and to assess their performance. Other factors, including market separation and customer specific applications, go-to-market channels, products and manufacturing, are considered in determining the formation of these operating segments.

[0001628280-22-023617:mdna:5]
We believe the global markets in which Lumentum participates have fundamentally robust, long-term trends that increase the need for our photonics products and technologies. We believe the world is becoming more reliant on ever-increasing amounts of data flowing through optical networks and data centers. Lumentum’s products and technology enable the scaling of these optical networks and data centers to higher capacities. We expect the accelerating shift to digital and virtual approaches to all aspects of work and life that is driving staggering amounts of data in the world’s networks and cloud datacenters will continue into the future. Virtual meetings, video calls, and hybrid in-person and virtual environments for work and other aspects of life will continue to drive strong needs for bandwidth growth and present dynamic new challenges that our technology addresses. As manufacturers demand higher levels of precision, new materials, and factory and energy efficiency, suppliers of manufacturing tools globally are turning to laser-based approaches, including the types of lasers Lumentum supplies. Laser-based 3D sensing and LiDAR for security, industrial and automotive applications are rapidly developing markets. The technology enables computer vision applications that enhance security, safety, and new functionality in the electronic devices that people rely on every day. The use of LiDAR and in-cabin 3D sensing in automobile and delivery vehicles over time significantly adds to our long-term market opportunity. Frictionless and contactless biometric security and access control is of increasing focus globally given the world’s experience with the COVID-19 pandemic. Additionally, we expect 3D-enabled machine vision solutions to expand significantly in industrial applications in the coming years.

[0001628280-22-023617:mdna:6]
OpComms

[0001628280-22-023617:mdna:7]
Our OpComms products address the following markets: Telecom, Datacom and Consumer and Industrial.

[0001628280-22-023617:mdna:8]
Our OpComms products include a wide range of components, modules and subsystems to support customers including carrier networks for access (local), metro (intracity), long-haul (city-to-city and worldwide) and submarine (undersea) applications. Additionally, our products address enterprise, cloud, and data center applications, including storage-access networks (“SANs”), local-area networks (“LANs”) and wide-area networks (“WANs”). These products enable the transmission and transport of video, audio and data over high-capacity fiber-optic cables. We maintain leading positions in these fast growing OpComms markets through our extensive product portfolio, including reconfigurable optical add/drop multiplexers (“ROADMs”), coherent dense wavelength division multiplexing (“DWDM”) pluggable transceivers, and tunable small form-factor pluggable transceivers. We also sell laser chips for use in manufacturing of high-speed Datacom transceivers. In the Consumer and Industrial market, our OpComms products include laser light sources, which are integrated into 3D sensing platforms being used in applications for mobile devices, gaming, computers, and other consumer electronics devices. New emerging applications include virtual and augmented reality, as well as automotive and industrial segments. Our products include vertical cavity surface emitting lasers (“VCSELs”) and edge emitting lasers which are used in 3D sensing depth imaging systems. These systems simplify the way people interact with technology by enabling the use of natural user interfaces. Systems are used for biometric identification, surveillance, and process efficiency, among numerous other application spaces. Emerging applications for this technology include various mobile device applications, autonomous vehicles, self-navigating robotics and drones in industrial applications and 3D capture of objects coupled with 3D printing. In addition, our industrial diode lasers are used primarily as pump sources for pulsed and kilowatt class fiber lasers.

[0001628280-22-023617:mdna:9]
Our OpComms customers include Accelink, Alphabet, Amazon, Apple, Ciena, Cisco Systems (including Acacia Communications, which was acquired by Cisco), Comcast, Infinera, Nokia Networks (including Alcatel-Lucent International), and ZTE.

[0001628280-22-023617:mdna:10]
Lasers

[0001628280-22-023617:mdna:11]
Our Lasers products serve our customers in markets and applications such as sheet metal processing, general manufacturing, biotechnology, graphics and imaging, remote sensing, and precision machining such as drilling in printed circuit boards, wafer singulation, glass cutting and solar cell scribing.

[0001628280-22-023617:mdna:12]
Our Lasers products are used in a variety of OEM applications including diode-pumped solid-state, fiber, diode, direct-diode and gas lasers such as argon-ion and helium-neon lasers. Fiber lasers provide kW-class output powers combined with excellent beam quality and are used in sheet metal processing and metal welding applications. Diode-pumped solid-state lasers provide excellent beam quality, low noise and exceptional reliability and are used in biotechnology, graphics and imaging, remote sensing, materials processing and precision machining applications. Diode and direct-diode lasers address a wide variety of applications, including laser pumping, thermal exposure, illumination, ophthalmology, image recording, printing, plastic welding and selective soldering. Gas lasers such as argon-ion and helium-neon lasers provide a stable, low-cost and reliable solution over a wide range of operating conditions, making them well-suited for complex, high-resolution OEM applications such as flow cytometry, DNA sequencing, graphics and imaging and semiconductor inspection.

[0001628280-22-023617:mdna:13]
We also provide high-powered and ultrafast lasers for the industrial and scientific markets. Manufacturers use high-power, ultrafast lasers to create micro parts for consumer electronics and to process semiconductor, LED, and other types of chips. Use of ultrafast lasers for micromachining applications is being driven primarily by the increasing use of consumer electronics and connected devices globally.

[0001628280-22-023617:mdna:14]
Our Lasers customers include Amada, ASM Pacific Technology, DISCO, KLA-Tencor, Lasertec, Life Technologies, LPKF Laser & Electronics, Malvern Panalytical, and MKS Instruments.

[0001628280-22-023617:mdna:15]
45

[0001628280-22-023617:mdna:16]
Mergers and Acquisitions

[0001628280-22-023617:mdna:17]
NeoPhotonics

[0001628280-22-023617:mdna:18]
On August 3, 2022 (the “Closing Date”), we completed our acquisition of NeoPhotonics Corporation (“NeoPhotonics”). The addition of NeoPhotonics expands our opportunity in some of the fastest growing markets for optical components used in cloud and telecom network infrastructure. We expect the integrated company to be better positioned to serve the needs of a global customer base who are increasingly utilizing photonics to accelerate the shift to digital and virtual approaches to work and life, the proliferation of IoT, 5G, and next-generation mobile networks, and the transition to advanced cloud computing architectures.

[0001628280-22-023617:mdna:19]
Under the terms of the merger agreement, on Closing Date, NeoPhotonics stockholders received $16.00 per share in cash for each of their NeoPhotonics shares for a total cash consideration of $867.3 million.

[0001628280-22-023617:mdna:20]
Prior to the Closing Date, as contemplated by the merger agreement, on January 14, 2022, entered into a credit agreement with NeoPhotonics, pursuant to which we agreed to make term loans (“loans”) to NeoPhotonics in an aggregate principal amount not to exceed $50.0 million to help fund capital expenditures and increased working capital associated with NeoPhotonics’ growth plans. During fiscal 2022, we funded a $30.0 million loan request to NeoPhotonics. On August 1, 2022, we funded an additional $20.0 million loan request to NeoPhotonics. The interest is payable monthly in arrears on the first day of each month. The loans will mature on January 14, 2024 unless earlier repaid or accelerated. The $50.0 million loans in aggregate were not settled as of the Closing Date and therefore were considered part of the total purchase price in connection with the merger.

[0001628280-22-023617:mdna:21]
During the fiscal year ended July 2, 2022, we incurred $8.4 million of transaction costs related to our acquisition of NeoPhotonics, which are recorded under selling, general and administrative expenses in our consolidated statement of operations.

[0001628280-22-023617:mdna:22]
Please refer to “Note 4. Business Combination” to the consolidated financial statements.

[0001628280-22-023617:mdna:23]
Other Acquisition

[0001628280-22-023617:mdna:24]
On August 15, 2022, we completed a transaction to acquire a business that develops and markets products for use in telecommunications and datacenter infrastructure, including Digital Signal Processors (DSP’s), ASICs and optical transceivers.  This acquisition will help us to expand our business in our OpComms segment. Please refer to “Note 21. Subsequent Events” to the consolidated financial statements.

[0001628280-22-023617:mdna:25]
We evaluate strategic opportunities regularly and, where appropriate, may acquire additional businesses, products, or technologies that are complementary to, or broaden the markets for our products. We believe we have strengthened our business model by expanding our addressable markets, customer base and expertise, diversifying our product portfolio and fortifying our core businesses from acquisitions as well as through organic initiatives.

[0001628280-22-023617:mdna:26]
Impact of COVID-19 to Our Business

[0001628280-22-023617:mdna:27]
Since February 2020, the COVID-19 pandemic has caused public health officials to recommend, and governments to enact, precautions to mitigate the spread of the virus, including travel restrictions and bans, extensive social distancing guidelines, closure or restrictions on business and quarantine or other types of “shelter-in-place” orders in many regions of the world. The pandemic and these related responses continue to cause a global slowdown of economic activity (including a decrease in demand for a broad variety of goods and services), disruptions in global supply chains, labor shortages, and significant volatility and potential disruption of financial markets. The ultimate extent to which COVID-19 will impact our business depends on future developments, which are highly uncertain and very difficult to predict, including the effectiveness and utilization of vaccines for COVID-19 and its variants, the severity of COVID-19 and its variants, and the effectiveness of the actions to contain or limit their spread.

[0001628280-22-023617:mdna:28]
From the start of the COVID-19 pandemic, we proactively implemented preventative measures and protocols, which we continuously assess and update for changes in conditions and emerging trends. Some of these measures have included complying with local, state or federal orders that require employees to work from home, instructing employees to work from home in certain jurisdictions, limiting the number of employees onsite which slowed our manufacturing operations in certain countries, enhancing use of personal protective equipment and restricting non-critical business travel by our employees, enacting vaccine and testing mandates in certain jurisdictions, and implementing health and safety enhancements. These measures are intended to safeguard our team members, contractors, suppliers, customers, distributors, and communities, and to ensure business continuity. Currently, our major production facilities in Europe, Asia, and the United States remain open. At most of our locations, we have transitioned from business continuity plans to return-to-office plans while continuing to maintain high standards of employee safety and sanitization protocols.

[0001628280-22-023617:mdna:29]
In the geographies where we have operations, we have, in general and where applicable, been deemed an essential business and been permitted to continue manufacturing and conducting new product development operations in a more limited capacity during the pandemic. This stems from our critical role in global supply chains for the world’s communications and health-care systems. However, the pandemic continues to affect our suppliers and manufacturers who are experiencing component materials and labor shortages. Given the continually evolving situation, particularly in light of the recent Delta and Omicron variants, it is difficult to predict the magnitude and duration of the impact of the COVID-19 pandemic to our markets, its effects, or precisely when our ability to supply our products will return to full capacity. We are continuing to actively monitor the situation and may take further actions altering our business operations that we determine are in the best interests of our employees, customers, communities, business partners, suppliers and stockholders, or as required by federal, state, or local authorities. It is not clear what the potential effects any such alterations or modifications may have on our business, including the effects on our customers, employees and prospects, or on our financial results for the future.

[0001628280-22-023617:mdna:30]
Our primary strategic focus for several years has been technology and product leadership combined with close customer relationships in long-term healthy and growing markets. We believe this strategy is even more apt, and our long-term opportunity is not diminished, with COVID-19. We believe there are long-term opportunities, as the world’s experience with COVID-19 could drive an increasingly digital and virtual world, touching all aspects of life and work, that increasingly emphasizes the importance of communications systems, cloud services, augmented and virtual reality, and enhanced security. Additionally, ever advancing electronic devices are needed to consume, produce, and communicate digital and virtual content. All these trends could drive the need for higher volumes of higher performing optical devices that we could supply. As such, we expect to continue to invest strongly in new products, technology and customer programs.

[0001628280-22-023617:mdna:31]
For more information on risks associated with the COVID-19 outbreak and regulatory actions, please refer to the section titled “Risk Factors” in Item 1A of Part I of this report.

[0001628280-22-023617:mdna:32]
Supply Chain Constraints

[0001628280-22-023617:mdna:33]
COVID-19 has also created dynamics in the semiconductor component supply chains that have led to shortages of the types of components we and our customers require in our products. These shortages have impacted our ability to meet demand and generate revenue from certain products in fiscal 2022 and, if our ability to procure needed semiconductor components does not improve, this will impact our ability to supply our products to our customers and may reduce our revenue and profit margin. In addition, if our customers are unable to procure needed semiconductor components, this could reduce their demand for our products and reduce our revenue. The impact of semiconductor component shortages may continue in the near term as supplier and customer buffer inventories and safety stocks are exhausted. Due to the global supply chain constraint, we have had to incur incremental supply and procurement costs in order to increase our ability to fulfill demands from our customers. These costs have increased our inventory balances as of July 2, 2022 and may decrease our gross margin in the near term. We expect component supply to be a challenge at least through the second quarter of fiscal 2023. For more information on risks associated with supply chain constraints, please refer to the section titled “Risk Factors” in Item 1A of Part I of this report.

[0001628280-22-023617:mdna:34]
47

[0001628280-22-023617:mdna:35]
Critical Accounting Policies and Estimates

[0001628280-22-023617:mdna:36]
Our consolidated financial statements are prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) as set forth in the Financial Accounting Standards Board’s Accounting Standards Codification (“ASC”), and we consider the various staff accounting bulletins and other applicable guidance issued by the United States Securities and Exchange Commission (“SEC”). GAAP, as set forth within the ASC, requires us to make certain estimates, judgments and assumptions. We believe that the estimates, judgments and assumptions upon which we rely are reasonable based upon information available to us at the time that these estimates, judgments and assumptions are made. These estimates, judgments and assumptions can affect the reported amounts of assets and liabilities as of the date of the financial statements as well as the reported amounts of revenues and expenses during the periods presented. To the extent there are differences between these estimates, judgments or assumptions and actual results, our financial statements will be affected. The accounting policies that reflect our more significant estimates, judgments and assumptions and which we believe are the most critical to aid in fully understanding and evaluating our reported financial results include the following:

[0001628280-22-023617:mdna:37]
•Inventory Valuation

[0001628280-22-023617:mdna:38]
•Revenue Recognition

[0001628280-22-023617:mdna:39]
•Income Taxes

[0001628280-22-023617:mdna:40]
•Business Combinations

[0001628280-22-023617:mdna:41]
•Goodwill

[0001628280-22-023617:mdna:42]
As a result of our Merger Agreement with NeoPhotonics, we added Business Combinations and Goodwill to our critical accounting policies and estimates in fiscal 2022. Please refer to “Note 4. Business Combination” to the consolidated financial statements.

[0001628280-22-023617:mdna:43]
Inventory Valuation

[0001628280-22-023617:mdna:44]
Inventory is recorded at standard cost, which approximates actual cost computed on a first-in, first-out basis, not in excess of net realizable value. We assess the value of our inventory on a quarterly basis and write down those inventories which are obsolete or in excess of our forecasted demand to the lower of their cost or estimated net realizable value. Our estimates of forecasted demand are based upon our analysis and assumptions including, but not limited to, expected product lifecycles, product development plans and historical usage by product. Our product line management personnel play a key role in our excess review process by providing updated sales forecasts, managing product transitions and working with manufacturing to minimize excess inventory. If actual market conditions are less favorable than our forecasts, or actual demand from our customers is lower than our estimates, we may be required to record additional inventory write-downs. If actual market conditions are more favorable than anticipated, inventory previously written down may be sold, resulting in lower cost of sales and higher income from operations than expected in that period.

[0001628280-22-023617:mdna:45]
Revenue Recognition

[0001628280-22-023617:mdna:46]
Pursuant to Topic 606, our revenues are recognized upon the application of the following steps:

[0001628280-22-023617:mdna:47]
•identification of the contract, or contracts, with a customer;

[0001628280-22-023617:mdna:48]
•identification of the performance obligations in the contract;

[0001628280-22-023617:mdna:49]
•determination of the transaction price;

[0001628280-22-023617:mdna:50]
•allocation of the transaction price to the performance obligations in the contract; and

[0001628280-22-023617:mdna:51]
•recognition of revenues when, or as, the contractual performance obligations are satisfied

[0001628280-22-023617:mdna:52]
The majority of our revenue comes from product sales, consisting of sales of Lasers and OpComms hardware products to our customers. Our revenue contracts generally include only one performance obligation. Revenues are recognized at a point in time when control of the promised goods or services are transferred to our customers upon shipment or delivery, in an amount that reflects the consideration we expect to be entitled to in exchange for those goods or services. We have entered into vendor managed inventory (“VMI”) programs with our customers. Under these arrangements, we receive purchase orders from our customers, and the inventory is shipped to the VMI location upon receipt of the purchase order. The customer then pulls the inventory from the VMI hub based on its production needs. Revenue under VMI programs is recognized when control transfers to the customer, which is generally once the customer pulls the inventory from the hub.

[0001628280-22-023617:mdna:53]
Revenue from all sales types is recognized at the transaction price. The transaction price is determined based on the consideration to which we will be entitled in exchange for transferring goods or services to the customer, adjusted for estimated variable consideration, if any. We typically estimate the impact on the transaction price for discounts offered to the customer for early payments on receivables or net of accruals for estimated sales returns. These estimates are based on historical returns, analysis of credit memo data and other known factors. Actual returns could differ from these estimates. We allocate the transaction price to each distinct product based on its relative standalone selling price. The product price as specified on the purchase order is considered the standalone selling price as it is an observable input that depicts the price as if sold to a similar customer in similar circumstances.

[0001628280-22-023617:mdna:54]
Taxes assessed by a governmental authority that are both imposed on and concurrent with a specific revenue-producing transaction, that are collected by us from a customer and deposited with the relevant government authority, are excluded from revenue. Our revenue arrangements do not contain significant financing components as our standard payment terms are less than one year.

[0001628280-22-023617:mdna:55]
If a customer pays consideration, or if we have a right to an amount of consideration that is unconditional before we transfer a good or service to the customer, those amounts are classified as deferred revenue or deposits received from customers which are included in other current liabilities or other long-term liabilities when the payment is made or when it is due, whichever is earlier.

[0001628280-22-023617:mdna:56]
Transaction Price Allocated to the Remaining Performance Obligations

[0001628280-22-023617:mdna:57]
Remaining performance obligations represent the transaction price allocated to performance obligations that are unsatisfied or partially unsatisfied as of the end of the reporting period. Unsatisfied and partially unsatisfied performance obligations consist of contract liabilities and non-cancellable backlog. Non-cancellable backlog includes goods and services for which customer purchase orders have been accepted that are scheduled or in the process of being scheduled for shipment. A portion of our revenue arises from vendor-managed inventory arrangements where the timing and volume of customer utilization is difficult to predict.

[0001628280-22-023617:mdna:58]
Warranty

[0001628280-22-023617:mdna:59]
Hardware products regularly include warranties to the end customers such that the product continues to function according to published specifications. We typically offer a twelve-month warranty for most of our products. However, in certain circumstances depending upon the product, specific market, product line and geography in which we operate, and what is common in the industry, our warranties can vary and range from six months to five years. These standard warranties are assurance type warranties and do not offer any services in addition to the assurance that the product will continue working as specified. Therefore, warranties are not considered separate performance obligations in the arrangement. Instead, the expected cost of the warranty is accrued as expense in accordance with authoritative guidance.

[0001628280-22-023617:mdna:60]
We provide reserves for the estimated costs of product warranties at the time revenue is recognized. We estimate the costs of our warranty obligations based on our historical experience of known product failure rates, use of materials to repair or replace defective products and service delivery costs incurred in correcting product failures. In addition, from time to time, specific warranty accruals may be made if unforeseen technical problems arise.

[0001628280-22-023617:mdna:61]
Shipping and Handling Costs

[0001628280-22-023617:mdna:62]
We record shipping and handling costs related to revenue transactions within cost of sales as a period cost.

[0001628280-22-023617:mdna:63]
Contract Costs

[0001628280-22-023617:mdna:64]
We recognize the incremental direct costs of obtaining a contract, which consist of sales commissions, when control over the products they relate to transfers to the customer. Applying the practical expedient, we recognize commissions as expense when incurred, as the amortization period of the commission asset we would have otherwise recognized is less than one year.

[0001628280-22-023617:mdna:65]
Contract Balances

[0001628280-22-023617:mdna:66]
We record accounts receivable when we have an unconditional right to consideration. Contract liabilities are recorded when cash payments are received or due in advance of performance. Contract liabilities consist of advance payments and deferred revenue, where we have unsatisfied performance obligations. Contract liabilities are classified as deferred revenue and customer deposits, and are included in other current liabilities within our consolidated balance sheet. Payment terms vary by customer. The time between invoicing and when payment is due is not significant.

[0001628280-22-023617:mdna:67]
The following table reflects the changes in contract balances as of July 2, 2022 (in millions, except percentages):

[0001628280-22-023617:mdna:68]
| Contract balances | Balance sheet location | July 2, 2022 |  | July 3, 2021 |  | Change |  | Percentage Change |
| Accounts receivable, net | Accounts receivable, net | $ | 262.0 |  |  | $ | 212.8 |  |  | $ | 49.2 |  |  | 23.1% |
| Deferred revenue and customer deposits | Other current liabilities | $ | — |  |  | $ | 0.6 |  |  | $ | (0.6) |  |  | (100.0)% |

[0001628280-22-023617:mdna:69]
Disaggregation of Revenue

[0001628280-22-023617:mdna:70]
We disaggregate revenue by geography and by product. Please refer to “Note 20. Revenue Recognition” to the consolidated financial statements for a presentation of disaggregated revenue. We do not present other levels of disaggregation, such as by type of products, customer, markets, contracts, duration of contracts, timing of transfer of control and sales channels, as this information is not used by our CODM to manage the business.

[0001628280-22-023617:mdna:71]
Income Taxes

[0001628280-22-023617:mdna:72]
In accordance with the authoritative guidance on accounting for income taxes, we recognize income taxes using an asset and liability approach. This approach requires the recognition of taxes payable or refundable for the current year and deferred tax liabilities and assets for the future tax consequences of events that have been recognized in our consolidated financial statements or tax returns. The measurement of current and deferred taxes is based on provisions of the enacted tax law, and the effects of future changes in tax laws or rates are not anticipated.

[0001628280-22-023617:mdna:73]
The authoritative guidance provides for recognition of deferred tax assets if the realization of such deferred tax assets is more likely than not to occur based on an evaluation of both positive and negative evidence and the relative weight of the evidence. We consider future growth, forecasted earnings, future taxable income, the mix of earnings in the jurisdictions in which we operate, historical earnings, taxable income in prior years, if carryback is permitted under the law, and prudent and feasible tax planning strategies in determining the need for a valuation allowance. In the event we were to determine that we would not be able to realize all or part of our net deferred tax assets in the future, an adjustment to the deferred tax assets valuation allowance would be charged to earnings in the period in which we make such a determination, or goodwill would be adjusted at our final determination of the valuation allowance related to an acquisition within the measurement period. If we later determine that it is more likely than not that the net deferred tax assets would be realized, we would reverse the applicable portion of the previously provided valuation allowance as an adjustment to earnings at such time.

[0001628280-22-023617:mdna:74]
We are subject to income tax audits by the respective tax authorities of the jurisdictions in which we operate. The determination of our income tax liabilities in each of these jurisdictions requires the interpretation and application of complex, and sometimes uncertain, tax laws and regulations. The authoritative guidance on accounting for income taxes prescribes both recognition and measurement criteria that must be met for the benefit of a tax position to be recognized in the financial statements.  If a tax position taken, or expected to be taken, in a tax return does not meet such recognition or measurement criteria, an unrecognized tax benefit liability is recorded.  If we ultimately determine that an unrecognized tax benefit liability is no longer necessary, we reverse the liability and recognize a tax benefit in the period in which it is determined that the unrecognized tax benefit liability is no longer necessary.

[0001628280-22-023617:mdna:75]
The recognition and measurement of current taxes payable or refundable and deferred tax assets and liabilities requires that we make certain estimates and judgments. Changes to these estimates or a change in judgment may have a material impact on our tax provision in a future period.

[0001628280-22-023617:mdna:76]
Business Combinations

[0001628280-22-023617:mdna:77]
In accordance with the guidance for business combinations, we determine whether a transaction or event is a business combination, which requires that the assets acquired and liabilities assumed constitute a business. Each business combination is then accounted for by applying the acquisition method. If the assets acquired are not a business, we account for the transaction or event as an asset acquisition. Under both methods, we recognize the identifiable assets acquired, the liabilities assumed, and any noncontrolling interest in the acquired entity. We capitalize acquisition-related costs and fees associated with asset acquisitions and immediately expense acquisition-related costs and fees associated with business combinations.

[0001628280-22-023617:mdna:78]
We allocate the fair value of purchase consideration to the tangible assets acquired, liabilities assumed and intangible assets acquired based on their estimated fair values. The excess of the fair value of purchase consideration over the fair values of these identifiable assets and liabilities is recorded as goodwill. When determining the fair values of assets acquired and liabilities assumed, we make significant estimates and assumptions, especially with respect to intangible assets. Critical estimates in valuing certain intangible assets include, but are not limited to, future expected cash flows from customer relationships and acquired developed technology and discount rates. Our estimates of fair value are based upon assumptions believed to be reasonable using best information available. These assumptions are inherently uncertain and unpredictable and, as a result, actual results may differ materially from estimates. Certain estimates associated with the accounting for acquisitions may change as additional information becomes available regarding the assets acquired and liabilities assumed. Any change in facts and circumstances that existed as of the acquisition date and impacts to our preliminary estimates is recorded to goodwill if identified within the measurement period. Subsequent to the measurement period or our final determination of fair value of assets and liabilities, whichever is earlier, the adjustments will affect our earnings.

[0001628280-22-023617:mdna:79]
We estimate the economic lives of certain acquired assets and these lives are used to calculate depreciation and amortization expense. If our estimates of the economic lives change, depreciation or amortization expenses could be accelerated or slowed.

[0001628280-22-023617:mdna:80]
Goodwill

[0001628280-22-023617:mdna:81]
Goodwill represents the excess of the purchase price of an acquired business over the fair value of the identifiable assets acquired and liabilities assumed. We test goodwill impairment on an annual basis in the fiscal fourth quarter and at any other time when events occur or circumstances indicate that the carrying amount of goodwill may not be recoverable.

[0001628280-22-023617:mdna:82]
We have the option to first assess qualitative factors to determine whether it is necessary to perform the quantitative goodwill impairment test. The qualitative factors we assess include long-term prospects of our performance, share price trends and market capitalization, and Company specific events. Unanticipated events and circumstances may occur that affect the accuracy of our assumptions, estimates and judgments. For example, if the price of our common stock were to significantly decrease combined with other adverse changes in market conditions, thus indicating that the underlying fair value of our reporting units may have decreased, we may reassess the value of our goodwill in the period such circumstances were identified.

[0001628280-22-023617:mdna:83]
If we determine that, as a result of the qualitative assessment, it is more likely than not (i.e., greater than 50% likelihood) that the fair value of a reporting unit is less than its carrying amount, we perform the quantitative test by estimating the fair value of our reporting units. If the carrying value of a reporting unit exceeds its fair value, we record goodwill impairment loss equal to the excess of the carrying value of the reporting unit’s goodwill over its fair value, not to exceed the carrying amount of goodwill. The fair value of each of our goodwill reporting units is generally estimated using a combination of public company multiples and discounted cash flow methodologies.

[0001628280-22-023617:mdna:84]
Recently Issued Accounting Pronouncements

[0001628280-22-023617:mdna:85]
Please refer to “Note 2. Recently Issued Accounting Pronouncements” to the consolidated financial statements.

[0001628280-22-023617:mdna:86]
Results of Operations

[0001628280-22-023617:mdna:87]
The results of operations for the periods presented are not necessarily indicative of results to be expected for future periods. The following table summarizes selected consolidated statements of operations items as a percentage of net revenue:

[0001628280-22-023617:mdna:88]
|  | Years Ended |
|  | July 2, 2022 |  | July 3, 2021 |  | June 27, 2020 |
| Segment net revenue: |  |  |  |  |  |
| OpComms | 88.7 | % |  | 93.0 | % |  | 90.3 | % |
| Lasers | 11.3 |  |  | 7.0 |  |  | 9.7 |  |
| Net revenue | 100.0 |  |  | 100.0 |  |  | 100.0 |  |
| Cost of sales | 50.3 |  |  | 51.5 |  |  | 58.1 |  |
| Amortization of acquired developed intangibles | 3.7 |  |  | 3.5 |  |  | 3.2 |  |
| Gross profit | 46.0 |  |  | 44.9 |  |  | 38.7 |  |
| Operating expenses: |  |  |  |  |  |
| Research and development | 12.9 |  |  | 12.3 |  |  | 11.8 |  |
| Selling, general and administrative | 15.5 |  |  | 13.9 |  |  | 14.0 |  |
| Restructuring and related charges | (0.1) |  |  | 0.4 |  |  | 0.5 |  |
| Merger termination fee and related costs, net | — |  |  | (11.9) |  |  | — |  |
| Impairment charges | — |  |  | — |  |  | 0.3 |  |
| Total operating expenses | 28.3 |  |  | 14.7 |  |  | 26.6 |  |
| Income from operations | 17.7 |  |  | 30.2 |  |  | 12.2 |  |
| Interest expense | (4.7) |  |  | (3.8) |  |  | (3.6) |  |
| Other income (expense), net | 0.7 |  |  | 0.2 |  |  | 1.9 |  |
| Income before income taxes | 13.7 |  |  | 26.6 |  |  | 10.4 |  |
| Provision for income taxes | 2.1 |  |  | 3.8 |  |  | 2.3 |  |
| Net income | 11.6 | % |  | 22.8 | % |  | 8.1 | % |

[0001628280-22-023617:mdna:89]
52

[0001628280-22-023617:mdna:90]
Financial Data for Fiscal 2022, 2021, and 2020

[0001628280-22-023617:mdna:91]
The following table summarizes selected consolidated statements of operations items (in millions, except for percentages):

[0001628280-22-023617:mdna:92]
|  | 2022 |  | 2021 |  | Change |  | Percentage Change |  | 2021 |  | 2020 |  | Change |  | Percentage Change |
| Segment net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| OpComms | $ | 1,518.5 |  |  | $ | 1,620.7 |  |  | $ | (102.2) |  |  | (6.3) | % |  | $ | 1,620.7 |  |  | $ | 1,515.1 |  |  | $ | 105.6 |  |  | 7.0 | % |
| Lasers | 194.1 |  |  | 122.1 |  |  | 72.0 |  |  | 59.0 |  |  | 122.1 |  |  | 163.5 |  |  | (41.4) |  |  | (25.3) |  |
| Net revenue | $ | 1,712.6 |  |  | $ | 1,742.8 |  |  | $ | (30.2) |  |  | (1.7) | % |  | $ | 1,742.8 |  |  | $ | 1,678.6 |  |  | $ | 64.2 |  |  | 3.8 | % |
| Gross profit | $ | 788.6 |  | $ | 783.1 |  | $ | 5.5 |  |  | 0.7 | % |  | $ | 783.1 |  | $ | 650.2 |  | $ | 132.9 |  |  | 20.4 | % |
| Gross margin | 46.0 | % |  | 44.9 | % |  |  |  |  |  | 44.9 | % |  | 38.7 | % |  |  |  |  |
| Research and development | $ | 220.7 |  |  | $ | 214.5 |  | $ | 6.2 |  | 2.9 | % |  | $ | 214.5 |  | $ | 198.6 |  | $ | 15.9 |  |  | 8.0 | % |
| Percentage of net revenue | 12.9 | % |  | 12.3 | % |  |  |  |  |  | 12.3 | % |  | 11.8 | % |  |  |  |  |
| Selling, general and administrative | $ | 265.7 |  | $ | 241.4 |  | $ | 24.3 |  |  | 10.1 | % |  | $ | 241.4 |  | $ | 235.2 |  | $ | 6.2 |  |  | 2.6 | % |
| Percentage of net revenue | 15.5 | % |  | 13.9 | % |  |  |  |  |  | 13.9 | % |  | 14.0 | % |  |  |  |  |
| Restructuring and related charges | $ | (1.1) |  | $ | 7.7 |  | $ | (8.8) |  |  | (114.3) | % |  | $ | 7.7 |  | $ | 8.0 |  | $ | (0.3) |  |  | (3.8) | % |
| Percentage of net revenue | (0.1) | % |  | 0.4 | % |  |  |  |  |  | 0.4 | % |  | 0.5 | % |  |  |  |  |
| Merger termination fee and related costs, net | $ | — |  | $ | (207.5) |  | $ | 207.5 |  | (100.0) | % |  | $ | (207.5) |  | $ | — |  | $ | (207.5) |  | N/A |
| Percentage of net revenue | — | % |  | (11.9) | % |  |  |  |  |  | (11.9) | % |  | — | % |  |  |  |  |
| Impairment charges | $ | — |  |  | $ | — |  | $ | — |  | — | % |  | $ | — |  |  | $ | 4.3 |  |  | $ | (4.3) |  |  | (100.0) | % |
| Percentage of net revenue | — | % |  | — | % |  |  |  |  |  | — | % |  | 0.3 | % |  |  |  |  |

[0001628280-22-023617:mdna:93]
Net Revenue

[0001628280-22-023617:mdna:94]
Net revenue decreased by $30.2 million, or 1.7%, during fiscal 2022 as compared to fiscal 2021, due to a $102.2 million decrease in OpComms revenue, partially offset by a $72.0 million increase in Lasers revenue.

[0001628280-22-023617:mdna:95]
OpComms net revenue decreased by $102.2 million, or 6.3%, during fiscal 2022 as compared to fiscal 2021. Within OpComms, Telecom and Datacom decreased by $51.0 million primarily a result of continued material and component shortages for our Telecom products, which impacted our ability to meet demand. Industrial and Consumer decreased by $51.2 million primarily due to a decrease in average selling price for our chips as a result of a smaller chips design.

[0001628280-22-023617:mdna:96]
Lasers net revenue increased by $72.0 million, or 59.0%, during fiscal 2022 as compared to fiscal 2021, primarily due to a return in customer demand for our kilowatt class fiber lasers following the recent recovery in industrial production.

[0001628280-22-023617:mdna:97]
Net revenue increased by $64.2 million, or 3.8%, during fiscal 2021 as compared to fiscal 2020. This increase was primarily due to a $105.6 million increase in OpComms revenue, partially offset by a $41.4 million decrease in Lasers revenue.

[0001628280-22-023617:mdna:98]
OpComms net revenue increased by $105.6 million, or 7.0%, during fiscal 2021 as compared to fiscal 2020. Within OpComms, sales of Industrial and Consumer increased $67.7 million and Telecom and Datacom products increased by $37.9 million. The Industrial and Consumer increase was primarily driven by an expansion of the available market due to an increased dollar content of 3D sensing lasers and higher adoption rates of 3D sensing in consumer electronic devices compared with the prior year. Telecom and Datacom increased by $37.9 million primarily due to market growth and recovery from the impact of COVID-19 supply constraints. Revenue from EML chips for datacenters increased by more than $40.0 million in fiscal 2021 compared to fiscal 2020. These increases, along with growth in Transport product lines more than offset the $57.2 million of lower sales from product lines we exited, such as Datacom transceiver modules and certain Lithium Niobate product lines. These results also include a deferral of $14.8 million of revenue due to delays in 5G deployments in China.

[0001628280-22-023617:mdna:99]
Lasers net revenue decreased by $41.4 million, or 25.3%, during fiscal 2021 as compared to fiscal 2020, primarily due to  reduced customer demand for our kilowatt class fiber lasers as a result of COVID-19.

[0001628280-22-023617:mdna:100]
During our fiscal 2022, 2021 and 2020, net revenue generated from a single customer which represented 10% or greater of total net revenue is summarized as follows:

[0001628280-22-023617:mdna:101]
|  | Years Ended |
|  | July 2, 2022 |  | July 3, 2021 |  | June 27, 2020 |
| Apple | 28.7 | % |  | 30.2 | % |  | 26.0 | % |
| Ciena | 12.6 | % |  | 10.1 | % |  | * |
| Huawei | * |  | 10.8 | % |  | 13.2 | % |
| *Represents less than 10% of total net revenue. |  |  |  |  |  |

[0001628280-22-023617:mdna:102]
Revenue by Region

[0001628280-22-023617:mdna:103]
We operate in three geographic regions: Americas, Asia-Pacific and EMEA. Net revenue is assigned to the geographic region and country where our product is initially shipped. For example, certain customers may request shipment of our product to a contract manufacturer in one country; however, the location of the end customers may differ. The following table presents net revenue by the three geographic regions we operate in and net revenue from countries within those regions that generally represented 10% or more of our total net revenue (in millions, except for percentages):

[0001628280-22-023617:mdna:104]
|  |  |  | Years Ended |
|  |  |  |  |  | July 2, 2022 |  | July 3, 2021 |  | June 27, 2020 |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  |  |  |  |  |  |  |  | $ | 173.9 |  |  | 10.2 | % |  | $ | 133.4 |  |  | 7.7 | % |  | $ | 149.8 |  |  | 8.9 | % |
| Other Americas |  |  |  |  |  |  |  |  | 173.0 |  |  | 10.1 |  |  | 146.9 |  |  | 8.4 |  |  | 128.3 |  |  | 7.6 |  |
| Total Americas |  |  |  |  |  |  |  |  | $ | 346.9 |  |  | 20.3 | % |  | $ | 280.3 |  |  | 16.1 | % |  | $ | 278.1 |  |  | 16.5 | % |
| Asia-Pacific: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Hong Kong |  |  |  |  |  |  |  |  | $ | 458.2 |  |  | 26.7 | % |  | $ | 546.3 |  |  | 31.3 | % |  | $ | 532.0 |  |  | 31.8 | % |
| South Korea |  |  |  |  |  |  |  |  | 265.2 |  |  | 15.5 |  |  | 240.0 |  |  | 13.8 |  |  | 260.9 |  |  | 15.5 |  |
| Japan |  |  |  |  |  |  |  |  | 181.2 |  |  | 10.6 |  |  | 114.7 |  |  | 6.6 |  |  | 137.9 |  |  | 8.2 |  |
| Other Asia-Pacific |  |  |  |  |  |  |  |  | 344.7 |  |  | 20.1 |  |  | 421.3 |  |  | 24.2 |  |  | 346.0 |  |  | 20.6 |  |
| Total Asia-Pacific |  |  |  |  |  |  |  |  | $ | 1,249.3 |  |  | 72.9 | % |  | $ | 1,322.3 |  |  | 75.9 | % |  | $ | 1,276.8 |  |  | 76.1 | % |
| EMEA |  |  |  |  |  |  |  |  | $ | 116.4 |  |  | 6.8 | % |  | $ | 140.2 |  |  | 8.0 | % |  | $ | 123.7 |  |  | 7.4 | % |
| Total net revenue |  |  |  |  |  |  |  |  | $ | 1,712.6 |  |  |  |  | $ | 1,742.8 |  |  |  |  | $ | 1,678.6 |  |  |  |

[0001628280-22-023617:mdna:105]
During fiscal 2022, 2021 and 2020, net revenue from customers outside the United States, based on customer shipping location, represented 89.8%, 92.3% and 91.1% of net revenue, respectively.

[0001628280-22-023617:mdna:106]
Our net revenue is primarily denominated in U.S. dollars, including our net revenue from customers outside the United States as presented above. We expect revenue from customers outside of the United States to continue to be an important part of our overall net revenue and an increasing focus for net revenue growth opportunities. However, regulatory and enforcement actions by the United States and other governmental agencies, as well as changes in tax and trade policies and tariffs, have impacted and may continue to adversely impact net revenue from customers outside the United States.

[0001628280-22-023617:mdna:107]
54

[0001628280-22-023617:mdna:108]
Gross Margin and Segment Gross Margin

[0001628280-22-023617:mdna:109]
The following table summarizes segment gross profit and gross margin for fiscal 2022, 2021 and 2020 (in millions, except for percentages):

[0001628280-22-023617:mdna:110]
|  | Gross Profit |  | Gross Margin |
|  | Years Ended |  | Years Ended |
|  | 2022 |  | 2021 |  | 2020 |  | 2022 |  | 2021 |  | 2020 |
| OpComms | $ | 780.9 |  |  | $ | 830.2 |  |  | $ | 704.0 |  |  | 51.4 | % |  | 51.2 | % |  | 46.5 | % |
| Lasers | 102.1 |  |  | 57.3 |  |  | 76.2 |  |  | 52.6 | % |  | 46.9 | % |  | 46.6 | % |
| Segment total | $ | 883.0 |  |  | $ | 887.5 |  |  | $ | 780.2 |  |  | 51.6 | % |  | 50.9 | % |  | 46.5 | % |
| Unallocated corporate items: |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation | (20.8) |  |  | (19.2) |  |  | (16.1) |  |  |  |  |  |  |  |
| Amortization of acquired intangibles | (62.9) |  |  | (61.7) |  |  | (53.8) |  |  |  |  |  |  |  |
| Amortization of inventory fair value adjustments | — |  |  | — |  |  | (5.8) |  |  |  |  |  |  |  |
| Inventory and fixed asset write down due to product line exits (1) | (0.1) |  |  | (0.4) |  |  | (7.0) |  |  |  |  |  |  |  |
| Integration related costs | — |  |  | — |  |  | (4.9) |  |  |  |  |  |  |  |
| Other charges (2) | (10.6) |  |  | (23.1) |  |  | (42.4) |  |  |  |  |  |  |  |
| Total | $ | 788.6 |  |  | $ | 783.1 |  |  | $ | 650.2 |  |  | 46.0 | % |  | 44.9 | % |  | 38.7 | % |

[0001628280-22-023617:mdna:111]
(1) In fiscal 2022, 2021 and 2020, we recorded inventory and fixed assets write down charges of $0.1 million,  $0.4 million and $7.0 million, respectively, related to the decision to exit the Datacom module and Lithium Niobate product lines.

[0001628280-22-023617:mdna:112]
(2) Other (charges) gains of unallocated corporate items in fiscal 2022 primarily relate to $14.0 million of charges to acquire components from various brokers to satisfy customer demand, offset by a $5.9 million gain from selling equipment that was no longer needed after we transferred certain product lines to new production facilities in fiscal 2021.

[0001628280-22-023617:mdna:113]
Other (charges) gains of unallocated corporate items for fiscal 2021 relate to costs of transferring product lines to new production facilities, including Thailand, of $6.9 million, excess and obsolete inventory charges of $7.7 million driven by U.S. trade restrictions and the related decline in demand from Huawei, and fixed asset write-off of $5.0 million associated with excess capacity related to our Fiber laser business.

[0001628280-22-023617:mdna:114]
Other (charges) gains of unallocated corporate items for fiscal 2020 primarily include costs of transferring product lines to new production facilities, including Thailand, of  $11.5 million, excess and obsolete inventory charges of $12.8 million driven by U.S. trade restrictions and the related decline in demand from Huawei, and  fixed asset write-off of $6.2 million associated with excess capacity related to our Fiber laser business.

[0001628280-22-023617:mdna:115]
The unallocated corporate items for the periods presented include the effects of amortization of acquired developed technologies and other intangibles, share-based compensation and certain other charges. We do not allocate these items to the gross margin for each segment because management does not include such information in measuring the performance of the operating segments.

[0001628280-22-023617:mdna:116]
Gross Margin

[0001628280-22-023617:mdna:117]
Gross margin in fiscal 2022 increased to 46.0% from 44.9% in fiscal 2021, driven by higher gross margin from the Lasers segment due to the higher manufacturing levels and improved factory utilization as a result of return in customer demand for our kilowatt class fiber products following the recent recovery in industrial production. However, these improvements in gross margin were partially offset by $14.0 million of charges to acquire components from various brokers to satisfy customer demand.

[0001628280-22-023617:mdna:118]
Gross margin in fiscal 2021 increased to 44.9% from 38.7% in fiscal 2020, due to both higher OpComms and Lasers segment gross margins. The increase was primarily driven by a higher mix of higher margin product lines, particularly due to increased revenue of 3D sensing, pump lasers and High-Reliability (“HiRel”) components products, which have higher than average margins.

[0001628280-22-023617:mdna:119]
We sell products in certain markets that are consolidating, undergoing product, architectural and business model transitions, have high customer concentrations, are highly competitive, are price sensitive and/or are affected by customer seasonal and mix variant buying patterns. We expect these factors to continue to result in variability of our gross margin.

[0001628280-22-023617:mdna:120]
The magnitude of the impact of COVID-19 on our business operations remains uncertain and difficult to predict, and this remains a highly dynamic situation, we have experienced, and we expect that we may continue to experience disruptions to our and our customers’ businesses that will adversely impact our business, financial condition and results of operations. Due to the global supply chain constraint, we have had to incur incremental supply and procurement costs in order to increase our ability to fulfill demands from our customers. These costs have increased our inventory balances by $16.8 million as of July 2, 2022 and will decrease our gross margin in the near term.

[0001628280-22-023617:mdna:121]
Segment Gross Margin

[0001628280-22-023617:mdna:122]
OpComms

[0001628280-22-023617:mdna:123]
OpComms gross margin in fiscal 2022 remained relatively flat at 51.4% as compared to 51.2% in fiscal 2021.

[0001628280-22-023617:mdna:124]
OpComms gross margin in fiscal 2021 increased to 51.2% from 46.5% in fiscal 2020. The increase was primarily due to higher manufacturing volumes, a more profitable mix of products, including higher sales of higher margin Datacom, pump lasers, and HiRel components products.  We also benefited from exiting lower margin product lines, such as Datacom transceiver module and Lithium Niobate modulator products, as well as from ongoing operational improvements.

[0001628280-22-023617:mdna:125]
Lasers

[0001628280-22-023617:mdna:126]
Lasers gross margin in fiscal 2022 increased to 52.6% from 46.9% in fiscal 2021. The increase was primarily due to the higher manufacturing levels and improved factory utilization as a result of return in customer demand for our kilowatt class fiber products following the recent recovery in industrial production.

[0001628280-22-023617:mdna:127]
Lasers gross margin in fiscal 2021 increased to 46.9% from 46.6% in fiscal 2020. This increase was primarily driven by the streamlining of our manufacturing supply chain related to our kilowatt class fiber products over the past year, offset by the impact of lower manufacturing levels related to COVID-19 reducing customer demand for our kilowatt class fiber products.

[0001628280-22-023617:mdna:128]
Research and Development (“R&D”)

[0001628280-22-023617:mdna:129]
R&D expense increased by $6.2 million, or 2.9%, in fiscal 2022 as compared to fiscal 2021. The increase in R&D expense was primarily driven by a $4.1 million increase in new product development activities in our factories, and a $2.6 million increase in share-based compensation.

[0001628280-22-023617:mdna:130]
R&D expense increased by $15.9 million, or 8.0%, in fiscal 2021 as compared to fiscal 2020. The increase in R&D expense was primarily due to an increase in payroll related expense and stock-based compensation partially due to the additional week in fiscal year 2021, partially offset by a decrease in R&D materials, as well as a reduction in discretionary travel, primarily due to COVID-19 restrictions.

[0001628280-22-023617:mdna:131]
We believe that continuing our investments in R&D is critical to attaining our strategic objectives. Despite the uncertainty related to COVID-19 and the global economic outlook, we plan to continue to invest in R&D and new products that we believe will further differentiate us in the marketplace and expect our investment in R&D to increase in absolute dollars in future quarters.

[0001628280-22-023617:mdna:132]
Selling, General and Administrative (“SG&A”)

[0001628280-22-023617:mdna:133]
SG&A expense increased by $24.3 million, or 10.1%, in fiscal 2022 as compared to fiscal 2021. The increase in SG&A expense for fiscal 2022 was primarily due to a $13.9 million increase in outside services and professional fees related to the  NeoPhotonics acquisition and increased investments in information technology and professional service fees for optimizing our international legal structure, as well as a $6.0 million increase in share-based compensation primarily due to increased employee headcount.

[0001628280-22-023617:mdna:134]
SG&A expense increased by $6.2 million, or 2.6%, in fiscal 2021 as compared to fiscal 2020. The increase in SG&A expense was primarily due to an increase in payroll related expense due to incremental headcount and additional week in fiscal year 2021, an increase in stock-based compensation, and an increase in legal expenses, offset by lower discretionary travel and trade shows, primarily due to COVID-19 restrictions. In addition, during the fourth quarter of fiscal 2021, we sold land and building located in San Jose, California for $23.0 million and recognized a $8.3 million gain in SG&A.

[0001628280-22-023617:mdna:135]
From time to time, we expect to incur non-recurring expenses, such as mergers and acquisition-related expenses, which will likely increase our SG&A expenses in the near term and potentially impact our profitability expectations in any particular quarter.

[0001628280-22-023617:mdna:136]
Restructuring and Related Charges

[0001628280-22-023617:mdna:137]
We have initiated various strategic restructuring events primarily intended to reduce costs, consolidate our operations, rationalize the manufacturing of our products and align our business in response to market conditions.

[0001628280-22-023617:mdna:138]
During fiscal 2022, we recorded a net reversal to our restructuring and related charges of $1.1 million, which was attributable to lower than anticipated employee severance charges primarily as a result of retaining and re-assigning certain employees.

[0001628280-22-023617:mdna:139]
During fiscal 2021, we recorded $7.7 million in restructuring and related charges in our consolidated statements of operations. The charges were mainly attributable to severance charges associated with the decision to move certain manufacturing from San Jose, California, as well as other cost reduction measures taken across the Company impacting all regions.

[0001628280-22-023617:mdna:140]
During fiscal 2020, we recorded $8.0 million in restructuring and related charges in our consolidated statements of operations. The charges were mainly attributable to severance charges associated with the decision to move certain manufacturing from San Jose, California to our facility in Thailand.

[0001628280-22-023617:mdna:141]
Please refer to “Note 13. Restructuring and Related Charges” to the consolidated financial statements.

[0001628280-22-023617:mdna:142]
Merger Termination Fee and Related Costs, Net

[0001628280-22-023617:mdna:143]
On January 18, 2021, we entered into a merger agreement with Coherent, under which we would acquire all outstanding shares of Coherent common stock. In March 2021, Coherent terminated the merger agreement and paid us a termination fee of $217.6 million in accordance with the merger agreement. For the year ended July 3, 2021, we recorded $217.6 million gain related to the receipt of a termination fee from Coherent in March 2021 as a result of the termination of our merger agreement. This gain was offset by $10.1 million of Coherent acquisition related charges and presented as “merger termination fee and related costs, net” in our consolidated statements of operations for the year ended July 3, 2021.

[0001628280-22-023617:mdna:144]
Impairment Charges

[0001628280-22-023617:mdna:145]
In the third quarter of fiscal 2019, we announced our plan to discontinue the development and manufacturing of future Datacom transceiver modules which impacted the California and China based Datacom module teams. As a result of these actions, we recorded impairment charges of $4.3 million in fiscal 2020 to our long-lived assets that were not deemed to be useful. While we expect strong growth in Datacom volumes in the future, gross margins at the transceiver market level are lower due to extreme competition.

[0001628280-22-023617:mdna:146]
We had no impairments in fiscal 2022 or fiscal 2021.

[0001628280-22-023617:mdna:147]
Interest Expense

[0001628280-22-023617:mdna:148]
The components of interest expense are as follows for the years presented (in millions):

[0001628280-22-023617:mdna:149]
|  |  |  | Years Ended |
|  |  |  | July 2, 2022 |  | July 3, 2021 |  | June 27, 2020 |
| Interest expense |  |  | $ | 80.2 |  |  | $ | 66.7 |  |  | $ | 61.2 |  |

[0001628280-22-023617:mdna:150]
For fiscal 2022, we recorded interest expense of $80.2 million, driven by the amortization of the debt discount and issuance costs of our Notes. The increase in interest expense is primarily a result of issuing $861.0 million in aggregate principal amount of 2028 Notes in March 2022.

[0001628280-22-023617:mdna:151]
For fiscal 2021, we recorded interest expense of $66.7 million related to the amortization of the debt discount and issuance costs of our Notes. The increase in interest expense during fiscal 2021 as compared to fiscal 2020 was mainly driven by the increase in amortization of the debt discount and contractual interest expense of our 2026 Notes issued in December 2019, partially offset by a loss and decreased interest expense due to the early extinguishment of our term loan facility in the second quarter of fiscal 2020.

[0001628280-22-023617:mdna:152]
Other Income (Expense), Net

[0001628280-22-023617:mdna:153]
The components of other income (expense), net are as follows for the years presented (in millions):

[0001628280-22-023617:mdna:154]
|  |  |  | Years Ended |  |
|  |  |  | July 2, 2022 |  | July 3, 2021 |  | June 27, 2020 |  |
| Foreign exchange gains (losses), net |  |  | $ | 6.1 |  |  | $ | (4.4) |  |  | $ | (1.4) |  |  |
| Interest and investment income |  |  | 6.1 |  |  | 5.7 |  |  | 15.8 |  |  |
| Other income (expense), net |  |  | (0.2) |  |  | 1.5 |  |  | 17.0 |  |  |
| Total other income (expense), net |  |  | $ | 12.0 |  |  | $ | 2.8 |  |  | $ | 31.4 |  |  |

[0001628280-22-023617:mdna:155]
During fiscal 2022, other income (expense), net increased by $9.2 million as compared to fiscal 2021, primarily due to $10.5 million more in foreign exchange gains as a result of a strengthening U.S. dollar relative to other foreign currencies, offset by $1.7 million decrease in other income.

[0001628280-22-023617:mdna:156]
During fiscal 2021, other income (expense), net decreased by $28.6 million as compared to fiscal 2020, mainly driven by a gain on the sale of Lithium Niobate modulators business of $13.8 million completed in fiscal 2020 and $10.1 million decrease in interest and investment income due to lower returns from our short-term investments at lower interest rates.

[0001628280-22-023617:mdna:157]
Provision for Income Taxes:

[0001628280-22-023617:mdna:158]
|  |  | Years Ended |
| (in millions) |  | July 2, 2022 |  | July 3, 2021 |  | June 27, 2020 |
| Provision for income taxes |  | $ | 36.2 |  |  | $ | 65.8 |  |  | $ | 38.8 |  |

[0001628280-22-023617:mdna:159]
Our tax provision for fiscal 2022 differs from the 21% U.S. statutory rate primarily due to the income tax benefit from earnings of our foreign subsidiaries being taxed at rates that differ from the U.S. statutory rate, offset by the tax expense from U.S. income inclusions from Subpart F and GILTI. Additionally, our provision for income taxes includes an income tax benefit from various tax credits, offset by an income tax expense from non-deductible stock-based compensation as well as change in valuation allowance because it is not more-likely-than-not that certain deferred tax assets will be realizable in the future.

[0001628280-22-023617:mdna:160]
Our provision for income taxes for fiscal 2021 differs from the 21% U.S. statutory rate primarily due to the income tax benefit from earnings of our foreign subsidiaries being taxed at rates that differ from the U.S. statutory rate, which is offset by the tax expense from U.S. income inclusions from Subpart F and GILTI. Further our provision for income taxes includes an income tax benefit from various tax credits and non-U.S. statutory rate changes enacted during the year, offset by an income tax expense from non-deductible stock-based compensation as well as change in valuation allowance because it is not more-likely-than-not that certain deferred tax assets will be realizable in the future.

[0001628280-22-023617:mdna:161]
Our provision for income taxes for fiscal 2020 differs from the 21% U.S. statutory rate primarily due to the income tax benefit of the earnings of our foreign subsidiaries being taxed at rates that differ from the U.S. statutory rate and certain tax credits, which is offset by the tax expense from U.S. income inclusions from Subpart F and GILTI.  Further our provision for income taxes includes an income tax expense from changes in our valuation allowance because it is not more-likely-than-not that certain deferred tax assets will be realized in the future.

[0001628280-22-023617:mdna:162]
Subsequent to fiscal 2022, President Biden signed into law the CHIPS and Science Act and the Inflation Reduction Act.  The new legislation provide tax incentives as well as impose a 15% minimum tax on certain corporation’s book income and a 1% excise tax on certain stock buybacks.  We are evaluating the effect, if any, of these new laws will have on our consolidated financial statements.

[0001628280-22-023617:mdna:163]
Defined Benefit Plans

[0001628280-22-023617:mdna:164]
The Company sponsors defined benefit pension plans covering employees in Japan, Switzerland, and Thailand. Pension plan benefits are based primarily on participants’ compensation and years of service credited as specified under the terms of each country’s plan. Employees are entitled to a lump sum benefit upon retirement or upon certain instances of termination.  The funding policy is consistent with the local requirements of each country. As of July 2, 2022, a defined benefit plan in Switzerland was partially funded, while defined benefit plans in Japan and Thailand were unfunded. As of July 2, 2022, our projected benefit obligations, net, in Japan, Switzerland, and Thailand were $2.6 million, $1.7 million, and $3.4 million, respectively. They were recorded in our consolidated balance sheets as other non-current liabilities and represent the total projected benefit obligation (“PBO”) less the fair value of plan assets.

[0001628280-22-023617:mdna:165]
A key actuarial assumption in calculating the net periodic cost and the PBO is the discount rate. Changes in the discount rate impact the interest cost component of the net periodic benefit cost calculation and PBO due to the fact that the PBO is calculated on a net present value basis. Decreases in the discount rate will generally increase pre-tax cost, recognized expense and the PBO. Increases in the discount rate tend to have the opposite effect. We estimate a 100 basis point decrease or increase in the discount rate would cause a corresponding increase or decrease of $2.8 million or $2.4 million, respectively, in the PBO based upon data as of July 2, 2022.

[0001628280-22-023617:mdna:166]
We expect to contribute $1.4 million to our defined benefit pension plans in fiscal 2023.

[0001628280-22-023617:mdna:167]
Financial Condition

[0001628280-22-023617:mdna:168]
Liquidity and Capital Resources

[0001628280-22-023617:mdna:169]
As of July 2, 2022 and July 3, 2021, our cash and cash equivalents of $1,290.2 million and $774.3 million, respectively, were largely held in the United States. As of July 2, 2022 and July 3, 2021, our short-term investments of $1,258.8 million and $1,171.7 million, respectively, were all held in the United States. Cash equivalents and short-term investments are primarily comprised of money market funds, treasuries, agencies, high quality investment grade fixed income securities, certificates of deposit, and commercial paper. Our investment policy and strategy is focused on the preservation of capital and supporting our liquidity requirements.

[0001628280-22-023617:mdna:170]
The total amount of cash outside the United States held by the non-U.S. entities as of July 2, 2022 was $216.1 million, which was primarily held by entities incorporated in the United Kingdom, the British Virgin Islands, Japan, Hong Kong, China, Canada, and Thailand. Although the cash currently held in the United States, as well as the cash generated in the United States from future operations, is expected to cover our normal operating requirements, a substantial amount of additional cash could be required for other purposes, such as capital expenditures to support our business and growth, including costs associated with increasing internal manufacturing capabilities, particularly in our Thailand facility, strategic transactions and partnerships, and future acquisitions.

[0001628280-22-023617:mdna:171]
Our intent is to indefinitely reinvest funds held outside the United States and, except for the funds held in the Cayman Islands, the British Virgin Islands, Japan and Hong Kong, our current plans do not demonstrate a need to repatriate them to fund our domestic operations. However, if in the future, we encounter a significant need for liquidity domestically or at a particular location that we cannot fulfill through borrowings, equity offerings, or other internal or external sources, or the cost to bring back the money is not significant from a tax perspective, we may determine that cash repatriations are necessary or desirable. Repatriation could result in additional material taxes. These factors may cause us to have an overall tax rate higher than other companies or higher than our tax rates have been in the past. Additionally, if conditions warrant, we may seek to obtain additional financing through debt or equity sources. To the extent we issue additional shares, our existing stockholders may be diluted. However, any such financing may not be available on terms favorable to us, or may not be available at all.

[0001628280-22-023617:mdna:172]
Beginning in fiscal 2023, the Tax Cuts and Jobs Act of 2017 requires taxpayers to capitalize research and development expenditures and amortize domestic expenditures over five years and foreign expenditures over fifteen years. This will delay deductibility of these expenses and potentially increase the amount of cash taxes we pay in the next several years.

[0001628280-22-023617:mdna:173]
Indebtedness

[0001628280-22-023617:mdna:174]
As of July 2, 2022, the debt component of our 2024 Notes of $409.9 million (principal balance of $450 million maturing in 2024) is presented in short-term liabilities since our stock price exceeded $78.80 for 20 of the last 30 trading days of the quarter ended July 2, 2022 and the 2024 Notes are convertible at the option of the holders. During the year ended July 2, 2022, we received conversion requests of $1.8 million principal amount of the 2024 Notes, which we settled with a combination of $1.8 million of cash and approximately 9 thousand  shares of the Company’s stock in accordance with the applicable indenture.

[0001628280-22-023617:mdna:175]
As of July 2, 2022, the debt component of our 2026 Notes of $831.4 million (principal balance of $1,050.0 million maturing in 2026) is presented in non-current liabilities. If the closing price of our stock exceeds $129.08 for 20 of the last 30 trading days of any future quarter, our 2026 Notes would also become convertible at the option of the holders and the debt component would be reclassified to current liabilities in our condensed consolidated balance sheet.

[0001628280-22-023617:mdna:176]
As of July 2, 2022, the debt component of our 2028 Notes of $634.7 million (principal balance of $861.0 million maturing in 2028) is presented in non-current liabilities. If the closing price of our stock exceeds $170.34 for 20 of the last 30 trading days in any fiscal quarter commencing after July 2, 2022, our 2028 Notes would also become convertible at the option of the holders and the debt component would be reclassified to current liabilities in our condensed consolidated balance sheet.

[0001628280-22-023617:mdna:177]
Share Repurchases

[0001628280-22-023617:mdna:178]
Repurchase Made in Connection with Convertible Note Offering

[0001628280-22-023617:mdna:179]
In fiscal 2022, concurrent with the issuance of the 2028 Notes, we repurchased 2.0 million shares of our common stock in privately negotiated transactions at an average price of $99.0 per share for an aggregate purchase price of $200.0 million. We recorded the $200.0 million aggregate purchase price as a reduction of retained earnings within our condensed consolidated balance sheet. These shares were retired immediately.

[0001628280-22-023617:mdna:180]
Share Buyback Program

[0001628280-22-023617:mdna:181]
On May 7, 2021, our board of directors approved the 2021 share buyback program, which authorizes us to use up to $700.0 million to purchase our own shares of common stock. The 2021 share buyback program was authorized for 2 years. On March 3, 2022, our board of directors approved an increase in our share buyback program, which authorizes us to use up to an aggregate amount of $1.0 billion to purchase our own shares of common stock.

[0001628280-22-023617:mdna:182]
During fiscal 2022, we repurchased 4.0 million shares of our common stock as part of the share buyback program at an average price of $87.21 per share for an aggregate purchase price of $348.9 million. During fiscal 2021, we repurchased 3.1 million shares of our common stock at an average price of $77.84 per share for an aggregate purchase price of $241.0 million. Since the share buyback program was approved by the board of directors, we have repurchased 7.1 million shares in aggregate at an average price of $83.12 per share for a total purchase price of $589.8 million. We recorded the $589.8 million aggregate purchase price as a reduction of retained earnings within our consolidated balance sheets. All repurchased shares were retired immediately.

[0001628280-22-023617:mdna:183]
The price, timing, amount, and method of such repurchases will be determined based on the valuation of market conditions and other factors, at prices determined to be attractive and in the best interests of both Lumentum and our stockholders.

[0001628280-22-023617:mdna:184]
Contractual Obligations

[0001628280-22-023617:mdna:185]
The following table summarizes our contractual obligations as of July 2, 2022, and the effect such obligations are expected to have on our liquidity and cash flow (in millions):

[0001628280-22-023617:mdna:186]
|  | Payments due |
|  | Total |  | Less than 1 year |  | More than 1 year |
| Contractual Obligations |  |  |  |  |  |
| Asset retirement obligations | $ | 4.6 |  |  | $ | 0.5 |  |  | $ | 4.1 |  |
| Operating lease liabilities, including imputed interest (1) | 66.5 |  |  | 12.9 |  |  | 53.6 |  |
| Pension plan contributions (2) | 1.4 |  |  | 1.4 |  |  | — |  |
| Purchase obligations (3) | 403.7 |  |  | 361.7 |  |  | 42.0 |  |
| Convertible notes - principal (4) | 2,359.1 |  |  | — |  |  | 2,359.1 |  |
| Convertible notes - interest (4) | 51.8 |  |  | 10.7 |  |  | 41.1 |  |
| Total | $ | 2,887.1 |  |  | $ | 387.2 |  |  | $ | 2,499.9 |  |

[0001628280-22-023617:mdna:187]
(1) The amounts of operating lease liabilities do not include any sublease income amounts nor do they include payments for short-term leases or variable lease payments. As of July 2, 2022, we expect to receive sublease income of approximately $2.4 million over the next year. Please refer to “Note 9. Leases” to the consolidated financial statements.

[0001628280-22-023617:mdna:188]
(2) The amount of pension plan contributions represents planned contributions to our defined benefit plans. Although additional future contributions will be required, the amount and timing of these contributions will be affected by actuarial assumptions, the actual rate of returns on plan assets, the level of market interest rates, legislative changes, and the amount of voluntary contributions to the plan. Any contributions for the following fiscal year and later will depend on the value of the plan assets in the future and thus are uncertain. As such, we have not included any amounts beyond one year in the table above.  Please refer to “Note 17. Employee Retirement Plans” to the consolidated financial statements.

[0001628280-22-023617:mdna:189]
(3) Purchase obligations represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Please refer to “Note 18. Commitments and Contingencies” to the consolidated financial statements.

[0001628280-22-023617:mdna:190]
(4) The amounts related to convertible notes include principal and interest on our 0.25% Convertible Senior Notes due in 2024 (the “2024 Notes”), principal and interest on our 0.50% Convertible Senior Notes due in 2026 (the “2026 Notes”), and principal and interest on our 0.50% Convertible Notes due in 2028 (the “2028 Notes”, and together with the 2024 Notes and 2026 Notes, the “Notes”). The 2024 Notes have a maturity date of March 15, 2024, the 2026 Notes have a maturity date of December 15, 2026, and the 2028 Notes have a maturity date of June 15, 2028.  The principal balances of our Notes are reflected in the payment periods in the table above based on their respective contractual maturities assuming no conversions. Please refer to “Note 11. Debt” to the consolidated financial statements.

[0001628280-22-023617:mdna:191]
Unrecognized Tax Benefits

[0001628280-22-023617:mdna:192]
As of July 2, 2022, our other non-current liabilities also include $30.5 million of unrecognized tax benefit for uncertain tax positions. We are unable to reliably estimate the timing of future payments related to uncertain tax positions.

[0001628280-22-023617:mdna:193]
Liquidity and Capital Resources Requirements

[0001628280-22-023617:mdna:194]
We believe that our cash and cash equivalents as of July 2, 2022, and cash flows from our operating activities will be sufficient to meet our liquidity and capital spending requirements for at least the next 12 months. However, if market conditions are favorable, we may evaluate alternatives to opportunistically pursue additional financing.  Following the end of fiscal year 2022, we used approximately $867.3 million in cash from our balance sheet for the acquisition of NeoPhotonics which closed on August 3, 2022.  In addition, because the term loans we provided to NeoPhotonics were not settled as of the closing of the acquisition, the outstanding amounts of such loans were included as part of the purchase price in connection with the acquisition.

[0001628280-22-023617:mdna:195]
There are a number of factors that could positively or negatively impact our liquidity position, including:

[0001628280-22-023617:mdna:196]
•global economic conditions which affect demand for our products and services and impact the financial stability of our suppliers and customers, including the impact of COVID-19;

[0001628280-22-023617:mdna:197]
•fluctuations in demand for our products as a result of changes in regulations, tariffs or other trade barriers, and trade relations in general;

[0001628280-22-023617:mdna:198]
•changes in accounts receivable, inventory or other operating assets and liabilities, which affect our working capital;

[0001628280-22-023617:mdna:199]
•increase in capital expenditures to support our business and growth, including increases in manufacturing capacity;

[0001628280-22-023617:mdna:200]
•the tendency of customers to delay payments or to negotiate favorable payment terms to manage their own liquidity positions;

[0001628280-22-023617:mdna:201]
•timing of payments to our suppliers;

[0001628280-22-023617:mdna:202]
•volatility in fixed income and credit, which impact the liquidity and valuation of our investment portfolios;

[0001628280-22-023617:mdna:203]
•volatility in foreign exchange markets, which impacts our financial results;

[0001628280-22-023617:mdna:204]
•possible investments or acquisitions of complementary businesses, products or technologies, or other strategic transactions or partnerships;

[0001628280-22-023617:mdna:205]
•issuance of debt or equity securities, or other financing transactions, including bank debt;

[0001628280-22-023617:mdna:206]
•potential funding of pension liabilities either voluntarily or as required by law or regulation;

[0001628280-22-023617:mdna:207]
•other acquisitions or strategic transactions;

[0001628280-22-023617:mdna:208]
•the settlement of any conversion or redemption of the 2024 Notes, the 2026 Notes, and the 2028 Notes in cash, and

[0001628280-22-023617:mdna:209]
•common stock repurchases under 2021 share buyback program

[0001628280-22-023617:mdna:210]
Fiscal 2022

[0001628280-22-023617:mdna:211]
As of July 2, 2022, our consolidated balance of cash and cash equivalents increased by $515.9 million, to $1,290.2 million from $774.3 million as of July 3, 2021. The increase in cash and cash equivalents was mainly due to cash provided by operating activities of $459.3 million and financing activities of $282.9 million, partially offset by cash used in investing activities of $226.3 million during the year ended July 2, 2022.

[0001628280-22-023617:mdna:212]
Cash provided by operating activities was $459.3 million during the year ended July 2, 2022, which reflects net income of $198.9 million and non-cash items (such as depreciation, stock-based compensation, amortization of intangibles, amortization of debt discount and debt issuance costs on our Notes, and other non-cash charges) of $351.0 million, partially offset by $90.6 million of changes in our operating assets and liabilities.

[0001628280-22-023617:mdna:213]
Cash used in investing activities of $226.3 million during the year ended July 2, 2022 was attributable to purchases of short-term investments, net of sales and maturities of $111.5 million, capital expenditures of $91.2 million, and a $30.0 million term loan provided to NeoPhotonics to support their on-going growth plans through the anticipated merger completion, partially offset by proceeds from the sales of property, plant and equipment of $6.4 million. The term loan to NeoPhotonics is described in “Note 4. Business Combination” to the consolidated financial statements.

[0001628280-22-023617:mdna:214]
Cash provided by financing activities of $282.9 million during the year ended July 2, 2022, was primarily a result of proceeds from the issuance of the 2028 Notes, net of issuance costs of $854.1 million and proceeds from employee stock plans of $13.5 million, partially offset by the repurchase of shares of our common stock of $543.9 million, tax payments related to net share settlement of restricted stock of $39.0 million, and $1.8 million to settle conversion requests for the principal amount of the 2024 Notes.

[0001628280-22-023617:mdna:215]
Fiscal 2021

[0001628280-22-023617:mdna:216]
As of July 3, 2021, our consolidated balance of cash and cash equivalents increased by $476.3 million, to $774.3 million from $298.0 million as of June 27, 2020. The increase in cash and cash equivalents was mainly due to cash provided by operating activities of $738.7 million and investing activities of $1.0 million, offset by cash used in financing activities of $263.4 million during the year ended July 3, 2021.

[0001628280-22-023617:mdna:217]
Cash provided by operating activities was $738.7 million during the year ended July 3, 2021.  Our net income was $397.3 million for the year ended July 3, 2021 and included the merger termination fee paid by Coherent, net of related costs of $207.5 million. Cash provided by operating activities was also generated from $339.9 million of non-cash items (such as depreciation, stock-based compensation, amortization of intangibles, amortization of debt discount and debt issuance costs on our Notes, and other non-cash charges), offset by $1.5 million of changes in our operating assets and liabilities.

[0001628280-22-023617:mdna:218]
Cash provided by investing activities of $1.0 million during the year ended July 3, 2021 was primarily attributable to proceeds from maturities and sales of short-term investment, net of purchases of $71.2 million and proceeds from sales of product lines of $1.3 million and sales of property and equipment of $23.3 million. However, we had capital expenditures of $84.8 million and a payment for an asset acquisition of $10.0 million.

[0001628280-22-023617:mdna:219]
Cash used in financing activities of $263.4 million during the year ended July 3, 2021, was primarily resulted from the repurchase of shares of our common stock of $236.0 million and tax payments related to restricted stock of $39.7 million, offset by the proceeds from employee stock plans of $12.6 million.

[0001628280-22-023617:mdna:220]
Fiscal 2020

[0001628280-22-023617:mdna:221]
As of June 27, 2020, our consolidated balance of cash and cash equivalents decreased by $134.6 million, to $298.0 million from $432.6 million as of June 29, 2019. The decrease in cash and cash equivalents was mainly due to cash used in investing activities of $987.7 million, offset by cash provided by operating activities of $524.3 million and cash provided by financing activities of $328.8 million during the year ended June 27, 2020.

[0001628280-22-023617:mdna:222]
Cash provided by operating activities of $524.3 million during the year ended June 27, 2020, primarily resulted from $323.4 million of non-cash items (such as depreciation, stock-based compensation, amortization of intangibles, amortization of debt discount and debt issuance costs on our term loan and the Notes, and other non-cash items), net income of $135.5 million, and $65.4 million of changes in our operating assets and liabilities.

[0001628280-22-023617:mdna:223]
Cash used in investing activities of $987.7 million during the year ended June 27, 2020, was primarily attributable to purchases of short-term investments, net of sales and maturities of $917.8 million. In addition, we had capital expenditures of $86.0 million, payment for asset acquisitions of $4.0 million, offset by proceeds from sales of product lines of $20.1 million.

[0001628280-22-023617:mdna:224]
Cash provided by financing activities of $328.8 million during the year ended June 27, 2020, primarily resulted from the proceeds of the issuance of the 2026 Notes of $1,042.2 million, net of issuance costs, offset by repayment of our term loan facility of $497.5 million and the repurchase of shares of our common stock of $200.0 million.
