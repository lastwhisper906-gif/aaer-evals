# LITE note change history — 0001628280-22-001745 → 0001628280-22-012157


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-05-04):
[0001628280-22-012157:note_history:1]
Purchase obligations of $345.6 million as of April 2, 2022, represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements.
  (was, 2022-02-03, similarity 0.9707):
[0001628280-22-001745:note_history:1]
Purchase obligations of $314.5 million as of January 1, 2022, represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements.

- added (2022-05-04):
[0001628280-22-012157:note_history:2]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 2, 2022 |  | April 3, 2021 |  | April 2, 2022 |  | April 3, 2021 |
| Balance as of beginning of period | $ | 8.6 |  |  | $ | 5.7 |  |  | $ | 5.0 |  |  | $ | 5.0 |  |
| Provision for warranty | 1.5 |  |  | 1.7 |  |  | 7.0 |  |  | 5.8 |  |
| Utilization of reserve | (1.0) |  |  | (1.8) |  |  | (2.9) |  |  | (5.2) |  |
| Balance as of end of period | $ | 9.1 |  |  | $ | 5.6 |  |  | $ | 9.1 |  |  | $ | 5.6 |  |

- changed (2022-05-04):
[0001628280-22-012157:note_history:3]
In the normal course of business, we enter into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown because claims may be made against us in the future, and we may record charges in the future as a result of these indemnification obligations. As of April 2, 2022, we did not have any material indemnification claims that were probable or reasonably possible.
  (was, 2022-02-03, similarity 0.7952):
[0001628280-22-001745:note_history:3]
In the normal course of business, we enter into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown because claims may be made against us in the future, and we may record charges in the future as a result of these indemnification obligations. As of January 1, 2022, we did not have any material indemnification claims that were probable or reasonably possible.

- removed (2022-05-04):
[0001628280-22-001745:note_history:4]
|  | Three Months Ended |  | Six Months Ended |
|  | January 1, 2022 |  | December 26, 2020 |  | January 1, 2022 |  | December 26, 2020 |
| Balance as of beginning of period | $ | 5.1 |  |  | $ | 7.6 |  |  | $ | 5.0 |  |  | $ | 5.0 |  |
| Provision for warranty | 3.8 |  |  | 0.2 |  |  | 5.5 |  |  | 4.1 |  |
| Utilization of reserve | (0.3) |  |  | (2.1) |  |  | (1.9) |  |  | (3.4) |  |
| Balance as of end of period | $ | 8.6 |  |  | $ | 5.7 |  |  | $ | 8.6 |  |  | $ | 5.7 |  |


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2022-05-04):
[0001628280-22-012157:note_history:5]
Lumentum Holdings Inc. (“we,” “us,” “our”, “Lumentum” or the “Company”) is an industry-leading provider of optical and photonic products defined by revenue and market share addressing a range of end market applications including Optical Communications (“OpComms”) and Commercial Lasers (“Lasers”) for manufacturing, inspection and life-science applications. We seek to use our core optical and photonic technology, and our volume manufacturing capability, to expand into attractive emerging markets that benefit from advantages that optical or photonics-based solutions provide, including 3D sensing for consumer electronics and diode light sources for a variety of consumer and industrial applications. The majority of our customers tend to be original equipment manufacturers (“OEMs”) that incorporate our products into their products which then address end-market applications. For example, we sell fiber optic components that network equipment manufacturers (“NEMs”) assemble into communications networking systems, which they sell to communications service providers, hyperscale cloud operators, and enterprises with their own networks. Similarly, many of our Lasers products customers incorporate our products into tools they produce, which are used for manufacturing processes by their customers. For 3D sensing, we sell diode lasers to manufacturers of consumer electronics products for mobile, personal computing, gaming, and other applications, including to the automotive industry, who then integrate our devices within their products, for eventual resale to consumers and also into other industrial applications.
  (was, 2022-02-03, similarity 0.9325):
[0001628280-22-001745:note_history:5]
Lumentum Holdings Inc. (“we,” “us,” “our”, “Lumentum” or the “Company”) is an industry-leading provider of optical and photonic products defined by revenue and market share addressing a range of end market applications including Optical Communications (“OpComms”) and Commercial Lasers (“Lasers”) for manufacturing, inspection and life-science applications. We seek to use our core optical and photonic technology, and our volume manufacturing capability, to expand into attractive emerging markets that benefit from advantages that optical or photonics-based solutions provide, including 3D sensing for consumer electronics and diode light sources for a variety of consumer and industrial applications. The majority of our customers tend to be original equipment manufacturers (“OEMs”) that incorporate our products into their products which then address end-market applications. For example, we sell fiber optic components that network equipment manufacturers (“NEMs”) assemble into communications networking systems, which they sell to network service providers, operators or enterprises with their own networks. Similarly, many of our Lasers products customers incorporate our products into tools they produce, which are used for manufacturing processes by their customers. For 3D sensing, we sell diode lasers to manufacturers of consumer electronics products for mobile, personal computing, gaming, and other applications who then integrate our devices within their products, for eventual resale to consumers and also into other industrial applications.

- changed (2022-05-04):
[0001628280-22-012157:note_history:6]
The accompanying condensed consolidated financial statements have been prepared in accordance with U.S. generally accepted accounting principles (“GAAP”), which requires management to make estimates and assumptions that affect the amounts reported in our condensed consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact us in the future, actual results may be different from the estimates. Operating results for the quarter ended April 2, 2022 are not necessarily indicative of the results that may be expected for the fiscal year ending July 2, 2022. In the opinion of the Company’s management, the information presented herein reflects all normal and recurring adjustments necessary for a fair presentation of our results of operations, financial position, stockholders’ equity and cash flows.
  (was, 2022-02-03, similarity 0.9941):
[0001628280-22-001745:note_history:6]
The accompanying condensed consolidated financial statements have been prepared in accordance with U.S. generally accepted accounting principles (“GAAP”), which requires management to make estimates and assumptions that affect the amounts reported in our condensed consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact us in the future, actual results may be different from the estimates. Operating results for the quarter ended January 1, 2022 are not necessarily indicative of the results that may be expected for the fiscal year ending July 2, 2022. In the opinion of the Company’s management, the information presented herein reflects all normal and recurring adjustments necessary for a fair presentation of our results of operations, financial position, stockholders’ equity and cash flows.

- added (2022-05-04):
[0001628280-22-012157:note_history:7]
We are now in the third year of the COVID-19 pandemic, and while the impact of the pandemic is lessening, new variants are causing continued concern. As these variants continue to emerge, efforts to mitigate or contain the impacts of the pandemic continue to evolve, and the duration and severity of the impact of the pandemic on our business and results of operations in future periods remain uncertain. The extent of the impact of COVID-19 on our operational and financial performance will depend on certain developments, including but not limited to the duration and spread of the pandemic and its variants, duration of local, state and federal issued public health orders in each jurisdiction where we operate or in which our customers and suppliers operate, impact on our customers and our sales cycles, impact on our supply chain and manufacturing partners, impact on our employees and impact on regional and worldwide economies and financial markets in general, all of which are uncertain and cannot be predicted. We assessed the potential impact that this pandemic has on our estimates as of April 2, 2022 and determined that there were no material impacts. However, due to the global supply chain constraint, we have had to incur incremental supply and procurement costs in order to fulfill demand from our customers. These higher costs have increased our inventory balances as of April 2, 2022 and may decrease our gross margin in the near term.

- added (2022-05-04):
[0001628280-22-012157:note_history:8]
We are also continuously monitoring developments in the ongoing conflict between Russia and Ukraine including the related export controls and resulting sanctions imposed on Russia by the U.S. and other countries.  Additional factors such as increased inflation, escalating energy costs, constrained raw material availability, and thus increasing costs could impact the global economy.  Although the global implications of the Russian/Ukraine conflict are difficult to predict at this time, we do not presently foresee direct material adverse effects upon our business.

- changed (2022-05-04):
[0001628280-22-012157:note_history:9]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Every fifth or sixth fiscal year will have a 53-week period. The additional week in a 53-week year is added to the third quarter, making such quarter consist of 14 weeks. Our fiscal 2022 is a 52-week year ending on July 2, 2022, with the quarter ended April 2, 2022 being a 13-week quarterly period. Our fiscal 2021 was a 53-week year that ended on July 3, 2021, with the quarter ended April 3, 2021 being a 14-week quarterly period.
  (was, 2022-02-03, similarity 0.7275):
[0001628280-22-001745:note_history:9]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Every fifth or sixth fiscal year will have a 53-week period. The additional week in a 53-week year is added to the third quarter, making such quarter consist of 14 weeks. Our fiscal 2022 is a 52-week year ending on July 2, 2022, with the quarter ended January 1, 2022 being a 13-week quarterly period. Our fiscal 2021 was a 53-week year that ended on July 3, 2021, with the quarter ended December 26, 2020 being a 13-week quarterly period.

- added (2022-05-04):
[0001628280-22-012157:note_history:10]
Certain prior period amounts have been reclassified to conform to the current period presentation. The reclassification of the prior period amounts did not impact previously reported condensed consolidated financial statements.

- changed (2022-05-04):
[0001628280-22-012157:note_history:11]
The condensed consolidated financial statements and accompanying related notes should be read in conjunction with the audited consolidated financial statements and related notes included in our Annual Report on Form 10-K for the fiscal year ended July 3, 2021. There have been no significant changes to our accounting policies during the three and nine months ended April 2, 2022.
  (was, 2022-02-03, similarity 0.9256):
[0001628280-22-001745:note_history:11]
The condensed consolidated financial statements and accompanying related notes should be read in conjunction with the audited consolidated financial statements and related notes included in our Annual Report on Form 10-K for the fiscal year ended July 3, 2021. There have been no significant changes to our accounting policies during the three and six months ended January 1, 2022.

- changed (2022-05-04):
[0001628280-22-012157:note_history:12]
On November 4, 2021, Lumentum and NeoPhotonics Corporation (“NeoPhotonics”) announced a merger agreement (the “Merger Agreement”) pursuant to which Lumentum will acquire all outstanding shares of NeoPhotonics stock. Under the terms of the Merger Agreement, NeoPhotonics stockholders will receive $16.00 per share in cash for each NeoPhotonics share they own. As of April 2, 2022, the estimated total transaction consideration is expected to be approximately $918 million.  The cash consideration will be funded from the combined company’s balance sheet.
  (was, 2022-02-03, similarity 0.6229):
[0001628280-22-001745:note_history:12]
On November 4, 2021, Lumentum and NeoPhotonics Corporation (“NeoPhotonics”) announced a merger agreement (the “Merger Agreement”). Under the terms of the Merger Agreement, NeoPhotonics stockholders will receive $16.00 per share in cash for each NeoPhotonics share they own. As of January 1, 2022, the estimated total transaction consideration is expected to be approximately $918 million.  The cash consideration will be funded from the combined company’s balance sheet.

- changed (2022-05-04):
[0001628280-22-012157:note_history:13]
The Merger Agreement contains certain termination rights for both Lumentum and NeoPhotonics and provides that upon termination of the Merger Agreement under specified circumstances (including termination by NeoPhotonics to accept a superior proposal), NeoPhotonics may be required to pay Lumentum a termination fee of $27.5 million. The Merger Agreement further provides that if the Merger Agreement is terminated for failure to obtain antitrust approval, Lumentum may be required to pay NeoPhotonics a termination fee of $55.1 million; and if Lumentum takes certain specified actions, (including entering into any definitive agreement for an acquisition by stock purchase, merger, consolidation, amalgamation, purchase of assets, license or otherwise of any ownership interest or assets of any Person) that cause a material delay in, or results in the failure of, the consummation of the Merger, Lumentum may be required to pay NeoPhotonics an additional termination fee of $36.7 million.
  (was, 2022-02-03, similarity 0.7519):
[0001628280-22-001745:note_history:13]
The Merger Agreement contains certain termination rights for both Lumentum and NeoPhotonics and provides that upon termination of the Merger Agreement under specified circumstances (including termination by NeoPhotonics to accept a superior proposal), NeoPhotonics may be required to pay Lumentum a termination fee of $27.5 million. The Merger Agreement further provides that if the Merger Agreement is terminated for failure to obtain antitrust approval, Lumentum may be required to pay NeoPhotonics a termination fee of $55.1 million; and if Lumentum takes certain specified actions, (including entering into any definitive agreement for an acquisition by stock purchase, merger, consolidation, amalgamation, purchase of assets, license or otherwise of any ownership interest or assets of any Person) that cause a material delay in, or results in the failure of, the consummation of the Merger, Lumentum may be required to payNeoPhotonics an additional termination fee of $36.7 million.
The Boards of Directors of Lumentum and NeoPhotonics have unanimously approved the transaction and the Merger Agreement. The transaction is subject to customary closing conditions, including the absence of certain legal impediments, the expiration or termination of the required waiting periods under the Hart-Scott-Rodino Antitrust Improvements Act of 1976, as amended, receipt of any required antitrust and regulatory approvals.  The transaction was approved by the NeoPhotonics stockholders on February 1, 2022. The transaction is not subject to any financing condition. We expect this transaction to be completed in the second half of calendar year 2022.

- added (2022-05-04):
[0001628280-22-012157:note_history:14]
The Boards of Directors of Lumentum and NeoPhotonics have unanimously approved the transaction and the Merger Agreement. On January 21, 2022, the waiting period under the Hart-Scott-Rodino Antitrust Improvements Act of 1976, as amended, expired with respect to the proposed acquisition. The transaction is subject to customary closing conditions, including the absence of certain legal impediments and receipt of any required antitrust and regulatory approvals. The transaction was approved by the NeoPhotonics stockholders on February 1, 2022. The transaction is not subject to any financing condition. We expect this transaction to be completed in the second half of calendar year 2022.

- added (2022-05-04):
[0001628280-22-012157:note_history:15]
In connection with the Merger Agreement, on January 14, 2022, Lumentum and NeoPhotonics entered into a credit agreement where Lumentum agreed to make term loans (“loans”) to NeoPhotonics in an aggregate principal amount not to exceed $50.0 million to help fund capital expenditures and increased working capital associated with NeoPhotonics’ growth plans. During the three months ended April 2, 2022, the Company funded a $30.0 million loan request to NeoPhotonics, which bears interest at the Wall Street Journal “prime rate,” which was 3.5% as of April 2, 2022. The interest is payable monthly in arrears on the first day of each month. The loans will mature on January 14, 2024 unless earlier repaid or accelerated.

- added (2022-05-04):
[0001628280-22-012157:note_history:16]
Termination of Coherent Merger Agreement

- added (2022-05-04):
[0001628280-22-012157:note_history:17]
On January 18, 2021, Lumentum and Coherent, Inc. (“Coherent”) entered into a merger agreement, under which Lumentum would acquire all outstanding shares of Coherent common stock. As of the date of the merger agreement, the total transaction consideration was approximately $5.7 billion. In March 2021, Coherent terminated the merger agreement and paid 
Lumentum a termination fee of $217.6 million in accordance with the merger agreement. This gain was offset by $10.1 million of acquisition related expenses and the net amount is presented as “merger termination fee and related costs, net” in our condensed consolidated statements of operations for the three and nine months ended April 3, 2021.

- removed (2022-05-04):
[0001628280-22-001745:note_history:18]
The COVID-19 pandemic has created and may continue to create significant uncertainty in global financial markets, which has disrupted and harmed, and may continue to disrupt and harm, our business, financial condition, and results of operations. The extent of the impact of COVID-19 on our operational and financial performance will depend on certain developments, including but not limited to the duration and spread of the outbreak, duration of local, state and federal issued public health orders in each jurisdiction where we operate or in which our customers and suppliers operate, impact on our customers and our sales cycles, impact on our supply chain and manufacturing partners, impact on our employees and impact on regional and worldwide economies and financial markets in general, all of which are uncertain and cannot be predicted. We assessed the potential impact that this pandemic has on our estimates as of January 1, 2022 and determined that there were no material impacts. However, due to the global supply chain constraint, we have had to incur incremental supply and procurement costs in order to increase our ability to fulfill demands from our customers. These costs have increased our inventory balances as of January 1, 2022 and will decrease our gross margin in the near term.

- removed (2022-05-04):
[0001628280-22-001745:note_history:19]
On January 14, 2022, Lumentum and NeoPhotonics entered into a credit agreement where Lumentum agreed to make delayed draw term loans (“loans”) to NeoPhotonics in an aggregate principal amount not to exceed $50.0 million to help fund capital expenditures and increased working capital associated with NeoPhotonics’ growth plans. The loans will mature on January 14, 2024 unless earlier repaid or accelerated. The loans bear interest at the Wall Street Journal “prime rate”, payable monthly in arrears on the first day of each month. There have not been any drawdown of the loans.


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-05-04):
[0001628280-22-012157:note_history:20]
| Liability component: | April 2, 2022 |  | July 3, 2021 |
|  | 2024 Notes (1) |  | 2026 Notes (2) |  | 2028 Notes (3) |  | 2024 Notes |  | 2026 Notes |
| Principal | $ | 450.0 |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |  | $ | 450.0 |  |  | $ | 1,050.0 |  |
| Unamortized debt discount and issuance costs | (43.9) |  |  | (229.2) |  |  | (234.2) |  |  | (59.3) |  |  | (260.2) |  |
| Net carrying amount of the liability component | $ | 406.1 |  |  | $ | 820.8 |  |  | $ | 626.8 |  |  | $ | 390.7 |  |  | $ | 789.8 |  |
  (was, 2022-02-03, similarity 0.6923):
[0001628280-22-001745:note_history:20]
| Liability component: | January 1, 2022 |  | July 3, 2021 |
|  | 2024 Notes (1) |  | 2026 Notes (2) |  | 2024 Notes |  | 2026 Notes |
| Principal | $ | 450.0 |  |  | $ | 1,050.0 |  |  | $ | 450.0 |  |  | $ | 1,050.0 |  |
| Unamortized debt discount and issuance costs | (49.0) |  |  | (239.7) |  |  | (59.3) |  |  | (260.2) |  |
| Net carrying amount of the liability component | $ | 401.0 |  |  | $ | 810.3 |  |  | $ | 390.7 |  |  | $ | 789.8 |  |

- changed (2022-05-04):
[0001628280-22-012157:note_history:21]
(1) Since the closing price of our stock exceeded $78.80 (or 130% of the conversion price of $60.62) for 20 of the last 30 trading days of the third quarter of fiscal 2022, the 2024 Notes have become convertible at the option of the holders. Therefore, the debt component of our 2024 Notes as of April 2, 2022 has been classified as current liabilities in our condensed consolidated balance sheet.
  (was, 2022-02-03, similarity 0.9718):
[0001628280-22-001745:note_history:21]
(1) Since the closing price of our stock exceeded $78.80 (or 130% of the conversion price of $60.62) for 20 of the last 30 trading days of the second quarter of fiscal 2022, the 2024 Notes have become convertible at the option of the holders. Therefore, the debt component of our 2024 Notes as of January 1, 2022 has been classified as current liabilities in our condensed consolidated balance sheet.

- added (2022-05-04):
[0001628280-22-012157:note_history:22]
(3) During any fiscal quarter commencing after July 2, 2022, if the closing price of our stock exceeds $170.34 (or 130% of the conversion price of $131.03) for 20 of the last 30 trading days of such quarter, our 2028 Notes would also become convertible at the option of the holders and the debt component would be reclassified to current liabilities in our condensed consolidated balance sheet.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-05-04):
[0001628280-22-012157:note_history:23]
In March 2022, we issued $861.0 million in aggregate principal amount of 0.50% Convertible Notes due in 2028 (the “2028 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act of 1933, as amended (the “Securities Act”). The 2028 Notes are governed by an indenture between the Company and U.S. Bank Trust Company National Association (as successor in interest to U.S. Bank National Association), as a trustee (the “2028 Indenture”). The 2028 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.
  (was, 2022-02-03, similarity 0.6095):
[0001628280-22-001745:note_history:23]
In December 2019, we issued $1,050.0 million in aggregate principal amount of 0.50% Convertible Notes due in 2026 (“the 2026 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act of 1933, as amended (the “Securities Act”). The 2026 Notes are governed by an indenture between the Company and U.S. Bank National Association (the “2026 Indenture”). We used approximately $196.0 million of the net proceeds of the offering to repay in full all amounts outstanding under our term loan credit facility, and a portion of the net proceeds of the offering to purchase approximately $200.0 million of our common stock concurrently with the pricing of the offering in privately negotiated transactions. The 2026 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

- added (2022-05-04):
[0001628280-22-012157:note_history:24]
The net proceeds from the sale of the 2028 Notes was $854.8 million, after deducting $6.2 million in issuance costs. In addition, we incurred $0.7 million in professional fees in connection with this transaction.  Concurrent with the issuance of the 2028 Notes, we used $200.0 million of the net proceeds to repurchase our common stock in privately negotiated transactions. We intend to use the remaining net proceeds for general corporate purposes, which may include capital expenditures and working capital.

- added (2022-05-04):
[0001628280-22-012157:note_history:25]
The 2028 Notes bear interest at a rate of 0.50% per year, payable semi-annually in arrears on June 15 and December 15 of each year, beginning on June 15, 2022. The 2028 Notes will mature on June 15, 2028, unless earlier redeemed, repurchased by us, or converted pursuant to the terms.

- added (2022-05-04):
[0001628280-22-012157:note_history:26]
Prior to the close of business on the business day immediately preceding March 15, 2028, holders of the 2028 Notes may convert their 2028 Notes only under the following circumstances:

- added (2022-05-04):
[0001628280-22-012157:note_history:27]
•during any fiscal quarter commencing after July 2, 2022 (and only during such fiscal quarter), if the last reported sale price of the Company’s common stock for at least 20 trading days (whether or not consecutive) during the 30

- added (2022-05-04):
[0001628280-22-012157:note_history:28]
consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% if the applicable conversion price on each applicable trading day;

- added (2022-05-04):
[0001628280-22-012157:note_history:29]
•during the five consecutive business day period after any five consecutive trading day period (the “measurement period”) in which the trading price per $1,000 principal amount of the 2028 Notes for each trading day of such measurement was less than 98% of the product of the last reported sale price of the Company’s common stock and the applicable conversion rate on each such trading day;

- added (2022-05-04):
[0001628280-22-012157:note_history:30]
•if the Company calls any or all of the 2028 Notes for redemption, at any time prior to the close of business on the second business day immediately preceding the redemption date; or

- added (2022-05-04):
[0001628280-22-012157:note_history:31]
•upon the occurrence of specified corporate events, as specified in the 2028 Indentures.

- added (2022-05-04):
[0001628280-22-012157:note_history:32]
On or after March 15, 2028 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their 2028 Notes at any time. Upon conversion, we may satisfy our conversion obligation in cash, shares of common stock or a combination of cash and shares of common stock, at our election.

- added (2022-05-04):
[0001628280-22-012157:note_history:33]
We may redeem for cash all or any of the 2028 Notes, at our option (subject to the partial redemption limitation set forth in the 2028 Indenture), on or after June 20, 2025, if the last reported sale price of its common stock has been at least 130% of the conversion price then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading-day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which the Company provides notice of redemption at a redemption price equal to 100% of the principal amount of the 2028 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. No sinking fund is provided for the 2028 Notes. If we elect to redeem fewer than all of the outstanding 2028 Notes, at least $100.0 million aggregate principal amount of the 2028 Notes must be outstanding and not subject to redemption as of the redemption notice date.  Upon the occurrence of a fundamental change (as defined in the 2028 Indenture), holders may require the Company to repurchase all or a portion of their 2028 Notes for cash at a price equal to 100% of the principal amount of the 2028 Notes to be repurchased, plus any accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

- added (2022-05-04):
[0001628280-22-012157:note_history:34]
We bifurcated the principal amount of the 2028 Notes into liability and equity components.  The liability component of the 2028 Notes was valued at $629.8 million based on the contractual cash flow discounted at an appropriate comparable market on non-convertible debt borrowing rate at the date of issuance, which was 5.7%, with the equity component representing the residual amount of the proceeds of $231.2 million, which was recorded as a debt discount.  The issuance and other related costs of $6.9 million were allocated pro rata based on the relative carrying amounts of the liability and equity components.

- added (2022-05-04):
[0001628280-22-012157:note_history:35]
The debt discount and debt issuance costs attributable to the liability component will be amortized to interest expense using an effective interest rate of 5.7% over the expected life of the 2028 Notes.  Debt issuance costs attributable to the equity component are netted against the equity component in stockholders’ equity, and the equity component is not remeasured as long as it continues to meet the conditions for equity classification.

- added (2022-05-04):
[0001628280-22-012157:note_history:36]
In December 2019, we issued $1,050.0 million in aggregate principal amount of 0.50% Convertible Notes due in 2026 (the “2026 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities. The 2026 Notes are governed by an indenture between the Company and U.S. Bank Trust Company National Association (as successor in interest to U.S. Bank National Association, as a trustee (the “2026 Indenture”). We used approximately $196.0 million of the net proceeds of the offering to repay in full all amounts outstanding under our term loan credit facility, and a portion of the net proceeds of the offering to purchase approximately $200.0 million of our common stock concurrently with the pricing of the offering in privately negotiated transactions. The 2026 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

- added (2022-05-04):
[0001628280-22-012157:note_history:37]
The initial conversion rate is 10.0711 shares of common stock per $1,000 principal amount of the 2026 Notes (which is equivalent to an initial conversion price of approximately $99.29 per share). The conversion rate is subject to adjustment upon the occurrence of certain specified events but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert the 2026 Notes in connection with such make-whole fundamental change or notice of redemption.

- changed (2022-05-04):
[0001628280-22-012157:note_history:38]
2024 Notes
  (was, 2022-02-03, similarity 0.7):
[0001628280-22-001745:note_history:38]
2024 and 2026 Notes

- changed (2022-05-04):
[0001628280-22-012157:note_history:39]
In March 2017, we issued $450 million of 0.25% Convertible Notes due in 2024 (the “2024 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act. The 2024 Notes are governed by an indenture between the Company, as the issuer, and U.S. Bank Trust Company National Association (as successor in interest to U.S. Bank National Association), as trustee (the “2024 Indenture”). The 2024 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.
  (was, 2022-02-03, similarity 0.8978):
[0001628280-22-001745:note_history:39]
In March 2017, we issued $450 million of 0.25% Convertible Notes due in 2024 (the “2024 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act. The 2024 Notes are governed by an indenture between the Company, as the issuer, and U.S. Bank National Association, as trustee (the “2024 Indenture”). The 2024 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

- changed (2022-05-04):
[0001628280-22-012157:note_history:40]
The initial conversion rate of the 2024 Notes is 16.4965 shares of common stock per $1,000 principal amount of 2024 Notes, which is equivalent to an initial conversion price of approximately $60.62 per share. Prior to the close of business on the business day immediately preceding December 15, 2023, each holder of the 2024 Notes may convert their 2024 Notes only under certain circumstances discussed in detail in our Annual Report on Form 10-K for the year ended July 3, 2021.
  (was, 2022-02-03, similarity 0.9333):
[0001628280-22-001745:note_history:40]
The initial conversion rate of the 2024 Notes is 16.4965 shares of common stock per $1,000 principal amount of 2024 Notes, which is equivalent to an initial conversion price of approximately $60.62 per share, a 132.5% premium to the fair market value at the date of issuance. Prior to the close of business on the business day immediately preceding December 15, 2023, each holder of the 2024 Notes may convert their 2024 Notes only under certain circumstances discussed in detail in our Annual Report on Form 10-K for the year ended July 3, 2021.

- added (2022-05-04):
[0001628280-22-012157:note_history:41]
During the nine months ended April 2, 2022, we received and settled in cash, conversion requests of less than $0.1 million principal amount of the 2024 Notes. From April 1, 2022 through May 4, 2022, we received requests for conversion of approximately $1.8 million in principal amount of the 2024 Notes. Such conversion will be settled in the fourth quarter of fiscal 2022 with a combination of cash and shares of the Company’s common stock in accordance with the applicable indenture.

- added (2022-05-04):
[0001628280-22-012157:note_history:42]
Convertible Notes

- changed (2022-05-04):
[0001628280-22-012157:note_history:43]
| Liability component: | April 2, 2022 |  | July 3, 2021 |
|  | 2024 Notes (1) |  | 2026 Notes (2) |  | 2028 Notes (3) |  | 2024 Notes |  | 2026 Notes |
| Principal | $ | 450.0 |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |  | $ | 450.0 |  |  | $ | 1,050.0 |  |
| Unamortized debt discount and issuance costs | (43.9) |  |  | (229.2) |  |  | (234.2) |  |  | (59.3) |  |  | (260.2) |  |
| Net carrying amount of the liability component | $ | 406.1 |  |  | $ | 820.8 |  |  | $ | 626.8 |  |  | $ | 390.7 |  |  | $ | 789.8 |  |
  (was, 2022-02-03, similarity 0.6923):
[0001628280-22-001745:note_history:43]
| Liability component: | January 1, 2022 |  | July 3, 2021 |
|  | 2024 Notes (1) |  | 2026 Notes (2) |  | 2024 Notes |  | 2026 Notes |
| Principal | $ | 450.0 |  |  | $ | 1,050.0 |  |  | $ | 450.0 |  |  | $ | 1,050.0 |  |
| Unamortized debt discount and issuance costs | (49.0) |  |  | (239.7) |  |  | (59.3) |  |  | (260.2) |  |
| Net carrying amount of the liability component | $ | 401.0 |  |  | $ | 810.3 |  |  | $ | 390.7 |  |  | $ | 789.8 |  |

- changed (2022-05-04):
[0001628280-22-012157:note_history:44]
(1) Since the closing price of our stock exceeded $78.80 (or 130% of the conversion price of $60.62) for 20 of the last 30 trading days of the third quarter of fiscal 2022, the 2024 Notes have become convertible at the option of the holders. Therefore, the debt component of our 2024 Notes as of April 2, 2022 has been classified as current liabilities in our condensed consolidated balance sheet.
  (was, 2022-02-03, similarity 0.9718):
[0001628280-22-001745:note_history:44]
(1) Since the closing price of our stock exceeded $78.80 (or 130% of the conversion price of $60.62) for 20 of the last 30 trading days of the second quarter of fiscal 2022, the 2024 Notes have become convertible at the option of the holders. Therefore, the debt component of our 2024 Notes as of January 1, 2022 has been classified as current liabilities in our condensed consolidated balance sheet.

- added (2022-05-04):
[0001628280-22-012157:note_history:45]
(3) During any fiscal quarter commencing after July 2, 2022, if the closing price of our stock exceeds $170.34 (or 130% of the conversion price of $131.03) for 20 of the last 30 trading days of such quarter, our 2028 Notes would also become convertible at the option of the holders and the debt component would be reclassified to current liabilities in our condensed consolidated balance sheet.

- changed (2022-05-04):
[0001628280-22-012157:note_history:46]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 2, 2022 |  | April 3, 2021 |  | April 2, 2022 |  | April 3, 2021 |
| Contractual interest expense | $ | 1.9 |  |  | $ | 1.6 |  |  | $ | 5.1 |  |  | $ | 4.8 |  |
| Amortization of the debt discount and debt issuance costs | 17.8 |  |  | 14.8 |  |  | 48.6 |  |  | 43.9 |  |
| Total interest expense | $ | 19.7 |  |  | $ | 16.4 |  |  | $ | 53.7 |  |  | $ | 48.7 |  |
  (was, 2022-02-03, similarity 0.8426):
[0001628280-22-001745:note_history:46]
|  | Three Months Ended |  | Six Months Ended |
|  | January 1, 2022 |  | December 26, 2020 |  | January 1, 2022 |  | December 26, 2020 |
| Contractual interest expense | $ | 1.6 |  |  | $ | 1.6 |  |  | $ | 3.2 |  |  | $ | 3.2 |  |
| Amortization of the debt discount and debt issuance costs | 15.5 |  |  | 14.7 |  |  | 30.8 |  |  | 29.1 |  |
| Total interest expense | $ | 17.1 |  |  | $ | 16.3 |  |  | $ | 34.0 |  |  | $ | 32.3 |  |

- changed (2022-05-04):
[0001628280-22-012157:note_history:47]
The future interest and principal payments related to our convertible notes are as follows as of April 2, 2022 (in millions):
  (was, 2022-02-03, similarity 0.9672):
[0001628280-22-001745:note_history:47]
The future interest and principal payments related to our convertible notes are as follows as of January 1, 2022 (in millions):

- changed (2022-05-04):
[0001628280-22-012157:note_history:48]
| Fiscal Years | 2024 Notes |  | 2026 Notes |  | 2028 Notes |  | Total |
| Remainder of 2022 | $ | 1.8 |  |  | $ | 2.7 |  |  | $ | 1.2 |  |  | $ | 5.7 |  |
| 2023 | 1.1 |  |  | 5.3 |  |  | 4.3 |  |  | 10.7 |  |
| 2024 | 449.4 |  |  | 5.3 |  |  | 4.3 |  |  | 459.0 |  |
| 2025 | — |  |  | 5.3 |  |  | 4.3 |  |  | 9.6 |  |
| 2026 | — |  |  | 5.3 |  |  | 4.3 |  |  | 9.6 |  |
| Thereafter | — |  |  | 1,052.4 |  |  | 869.6 |  |  | 1,922.0 |  |
| Total convertible notes payments | $ | 452.3 |  |  | $ | 1,076.3 |  |  | $ | 888.0 |  |  | $ | 2,416.6 |  |
  (was, 2022-02-03, similarity 0.8134):
[0001628280-22-001745:note_history:48]
| Fiscal Years | 2024 Notes |  | 2026 Notes |  | Total |
| Remainder of 2022 | $ | 0.5 |  |  | $ | 2.7 |  |  | $ | 3.2 |  |
| 2023 | 1.1 |  |  | 5.3 |  |  | 6.4 |  |
| 2024 | 451.1 |  |  | 5.3 |  |  | 456.4 |  |
| 2025 | — |  |  | 5.3 |  |  | 5.3 |  |
| 2026 | — |  |  | 5.3 |  |  | 5.3 |  |
| Thereafter | — |  |  | 1,052.4 |  |  | 1,052.4 |  |
| Total convertible notes payments | $ | 452.7 |  |  | $ | 1,076.3 |  |  | $ | 1,529.0 |  |

- removed (2022-05-04):
[0001628280-22-001745:note_history:49]
During the six months ended January 1, 2022, we received conversion requests for less than $0.1 million principal amount of the 2024 Notes, which were settled in cash in the first half of fiscal 2022.


## us-gaap:DebtSecuritiesAvailableForSaleUnrealizedLossPositionFairValueTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-05-04):
[0001628280-22-012157:note_history:50]
|  | Fair Value |  | Unrealized Losses |  |  |  |  |  |  |  |  |
| April 2, 2022: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | 64.0 |  |  | (1.2) |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | 11.3 |  |  | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | 253.3 |  |  | (0.1) |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 639.3 |  |  | (6.6) |  |  |  |  |  |  |  |  |  |
| Municipal bonds | 1.0 |  |  | — |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 566.3 |  |  | (3.5) |  |  |  |  |  |  |  |  |  |
| Total | $ | 1,535.2 |  |  | $ | (11.4) |  |  |  |  |  |  |  |  |  |
| July 3, 2021: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | 28.3 |  |  | $ | — |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | 6.0 |  |  | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | 43.0 |  |  | — |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 432.3 |  |  | (0.4) |  |  |  |  |  |  |  |  |  |
| Municipal bonds | 1.0 |  |  | — |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 106.9 |  |  | — |  |  |  |  |  |  |  |  |  |
| Total | $ | 617.5 |  |  | $ | (0.4) |  |  |  |  |  |  |  |  |  |
  (was, 2022-02-03, similarity 0.9912):
[0001628280-22-001745:note_history:50]
|  | Fair Value |  | Unrealized Losses |  |  |  |  |  |  |  |  |
| January 1, 2022: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | 60.1 |  |  | (0.2) |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | 3.3 |  |  | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | 83.7 |  |  | — |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 645.9 |  |  | (1.8) |  |  |  |  |  |  |  |  |  |
| Municipal bonds | 2.0 |  |  | — |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 516.3 |  |  | (0.7) |  |  |  |  |  |  |  |  |  |
| Total | $ | 1,311.3 |  |  | $ | (2.7) |  |  |  |  |  |  |  |  |  |
| July 3, 2021: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | 28.3 |  |  | $ | — |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | 6.0 |  |  | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | 43.0 |  |  | — |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 432.3 |  |  | (0.4) |  |  |  |  |  |  |  |  |  |
| Municipal bonds | 1.0 |  |  | — |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 106.9 |  |  | — |  |  |  |  |  |  |  |  |  |
| Total | $ | 617.5 |  |  | $ | (0.4) |  |  |  |  |  |  |  |  |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-05-04):
[0001628280-22-012157:note_history:51]
The future interest and principal payments related to our convertible notes are as follows as of April 2, 2022 (in millions):
  (was, 2022-02-03, similarity 0.9672):
[0001628280-22-001745:note_history:51]
The future interest and principal payments related to our convertible notes are as follows as of January 1, 2022 (in millions):

- changed (2022-05-04):
[0001628280-22-012157:note_history:52]
| Fiscal Years | 2024 Notes |  | 2026 Notes |  | 2028 Notes |  | Total |
| Remainder of 2022 | $ | 1.8 |  |  | $ | 2.7 |  |  | $ | 1.2 |  |  | $ | 5.7 |  |
| 2023 | 1.1 |  |  | 5.3 |  |  | 4.3 |  |  | 10.7 |  |
| 2024 | 449.4 |  |  | 5.3 |  |  | 4.3 |  |  | 459.0 |  |
| 2025 | — |  |  | 5.3 |  |  | 4.3 |  |  | 9.6 |  |
| 2026 | — |  |  | 5.3 |  |  | 4.3 |  |  | 9.6 |  |
| Thereafter | — |  |  | 1,052.4 |  |  | 869.6 |  |  | 1,922.0 |  |
| Total convertible notes payments | $ | 452.3 |  |  | $ | 1,076.3 |  |  | $ | 888.0 |  |  | $ | 2,416.6 |  |
  (was, 2022-02-03, similarity 0.8134):
[0001628280-22-001745:note_history:52]
| Fiscal Years | 2024 Notes |  | 2026 Notes |  | Total |
| Remainder of 2022 | $ | 0.5 |  |  | $ | 2.7 |  |  | $ | 3.2 |  |
| 2023 | 1.1 |  |  | 5.3 |  |  | 6.4 |  |
| 2024 | 451.1 |  |  | 5.3 |  |  | 456.4 |  |
| 2025 | — |  |  | 5.3 |  |  | 5.3 |  |
| 2026 | — |  |  | 5.3 |  |  | 5.3 |  |
| Thereafter | — |  |  | 1,052.4 |  |  | 1,052.4 |  |
| Total convertible notes payments | $ | 452.7 |  |  | $ | 1,076.3 |  |  | $ | 1,529.0 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2022-05-04):
[0001628280-22-012157:note_history:53]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 2, 2022 |  | April 3, 2021 |  | April 2, 2022 |  | April 3, 2021 |
| OpComms: |  |  |  |  |  |  |  |  |  |  |  |
| Telecom and Datacom | $ | 243.5 |  | 61.6 | % |  | $ | 255.8 |  | 61.0 | % |  | $ | 726.6 |  | 56.3 | % |  | $ | 803.3 |  | 59.5 | % |
| Industrial and Consumer | 100.7 |  | 25.5 |  |  | 132.1 |  | 31.5 | % |  | 421.0 |  | 32.6 |  |  | 462.2 |  | 34.2 | % |
| Total OpComms | $ | 344.2 |  | 87.1 | % |  | $ | 387.9 |  | 92.5 | % |  | $ | 1,147.6 |  | 88.9 | % |  | $ | 1,265.5 |  | 93.7 | % |
| Lasers | 51.2 |  | 12.9 | % |  | 31.6 |  | 7.5 | % |  | 142.9 |  | 11.1 |  |  | 85.2 |  | 6.3 |  |
| Net Revenue | $ | 395.4 |  |  |  | $ | 419.5 |  |  |  | $ | 1,290.5 |  |  |  | $ | 1,350.7 |  |  |

- changed (2022-05-04):
[0001628280-22-012157:note_history:54]
The following table reflects the changes in contract balances for the periods presented (in millions, except percentages):
  (was, 2022-02-03, similarity 0.8475):
[0001628280-22-001745:note_history:54]
The following table reflects the changes in contract balances as of January 1, 2022 (in millions, except percentages):

- added (2022-05-04):
[0001628280-22-012157:note_history:55]
| Contract balances |  | Balance sheet location |  | April 2, 2022 |  | July 3, 2021 |  | Change |  | Percentage Change |
| Accounts receivable, net |  | Accounts receivable, net |  | $ | 242.2 |  |  | $ | 212.8 |  |  | $ | 29.4 |  |  | 13.8 | % |
| Deferred revenue and customer deposits |  | Other current liabilities |  | $ | — |  |  | $ | 0.6 |  |  | $ | (0.6) |  |  | (100.0) | % |

- removed (2022-05-04):
[0001628280-22-001745:note_history:56]
|  | Three Months Ended |  | Six Months Ended |
|  | January 1, 2022 |  | December 26, 2020 |  | January 1, 2022 |  | December 26, 2020 |
| OpComms: |  |  |  |  |  |  |  |  |  |  |  |
| Telecom and Datacom | $ | 267.1 |  | 59.8 | % |  | $ | 286.2 |  | 59.8 | % |  | $ | 483.1 |  | 54.0 | % |  | $ | 547.5 |  | 58.8 | % |
| Industrial and Consumer | 130.3 |  | 29.2 |  |  | 162.9 |  | 34.0 |  |  | 320.3 |  | 35.8 |  |  | 330.1 |  | 35.4 |  |
| Total OpComms | $ | 397.4 |  | 89.0 | % |  | $ | 449.1 |  | 93.8 | % |  | $ | 803.4 |  | 89.8 | % |  | $ | 877.6 |  | 94.2 | % |
| Lasers | 49.3 |  | 11.0 | % |  | 29.7 |  | 6.2 | % |  | 91.7 |  | 10.2 |  |  | 53.6 |  | 5.8 |  |
| Net Revenue | $ | 446.7 |  |  |  | $ | 478.8 |  |  |  | $ | 895.1 |  |  |  | $ | 931.2 |  |  |

- removed (2022-05-04):
[0001628280-22-001745:note_history:57]
| Contract balances |  | Balance sheet location |  | January 1, 2022 |  | July 3, 2021 |  | Change |  | Percentage Change |
| Accounts receivable, net |  | Accounts receivable, net |  | $ | 239.2 |  |  | $ | 212.8 |  |  | $ | 26.4 |  |  | 12.4 | % |
| Deferred revenue and customer deposits |  | Other current liabilities |  | $ | — |  |  | $ | 0.6 |  |  | $ | (0.6) |  |  | (100.0) | % |
