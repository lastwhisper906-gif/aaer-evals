# LITE 8-K — 0001628280-22-022980 filed 2022-08-16

## item codes, every 8-K on or before 2022-08-24

- 2022-08-16 0001628280-22-022980 — 2.02, 9.01
- 2022-08-03 0001193125-22-210674 — 2.01, 8.01, 9.01
- 2022-07-29 0001193125-22-206587 — 8.01, 9.01
- 2022-05-04 0001628280-22-012145 — 2.02, 9.01
- 2022-03-08 0001193125-22-069350 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2022-02-03 0001628280-22-001736 — 2.02, 9.01
- 2022-01-21 0001193125-22-014413 — 8.01, 9.01
- 2021-11-23 0001628280-21-024070 — 5.02, 5.07
- 2021-11-05 0001193125-21-321796 — 1.01, 9.01
- 2021-11-04 0001628280-21-021618 — 2.02, 9.01
- 2021-11-04 0001193125-21-319601 — 8.01, 9.01
- 2021-08-18 0001628280-21-017219 — 2.02, 9.01
- 2021-06-08 0001633978-21-000030 — 5.02, 9.01
- 2021-05-12 0001633978-21-000008 — 2.02, 9.01
- 2021-03-10 0001193125-21-075438 — 1.01, 8.01, 9.01
- 2021-02-02 0001633978-21-000002 — 2.02, 9.01
- 2021-01-19 0001104659-21-005024 — 1.01, 2.02, 8.01, 9.01
- 2020-11-24 0001193125-20-302557 — 5.02, 5.07
- 2020-11-02 0001633978-20-000017 — 2.02, 9.01
- 2020-09-18 0001633978-20-000012 — 5.02, 9.01
- 2020-08-11 0001633978-20-000010 — 2.02, 9.01
- 2020-05-05 0001628280-20-006358 — 2.02, 9.01
- 2020-02-04 0001633978-20-000002 — 2.02, 9.01
- 2019-12-12 0001193125-19-312875 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2019-12-04 0001633978-19-000075 — 8.01
- 2019-11-20 0001633978-19-000074 — 5.07
- 2019-10-31 0001633978-19-000070 — 2.02, 9.01
- 2019-08-08 0001633978-19-000068 — 2.02, 9.01
- 2019-05-08 0001633978-19-000031 — 1.01
- 2019-05-07 0001633978-19-000029 — 2.02, 9.01
- 2019-02-15 0001633978-19-000005 — 9.01 — amendment of 0001193125-18-346211
- 2019-02-08 0001193125-19-031591 — 5.02, 9.01
- 2019-02-05 0001633978-19-000001 — 2.02, 9.01
- 2018-12-10 0001193125-18-346211 — 1.01, 2.01, 2.03, 5.02, 8.01, 9.01
- 2018-12-06 0001633978-18-000150 — 8.01
- 2018-11-14 0001633978-18-000139 — 5.07
- 2018-11-13 0001633978-18-000136 — 3.02
- 2018-11-13 0001633978-18-000132 — 7.01, 9.01
- 2018-11-01 0001628280-18-013238 — 2.02, 9.01
- 2018-08-08 0001633978-18-000056 — 2.02, 9.01
- 2018-06-08 0001193125-18-188241 — 5.02, 9.01
- 2018-05-02 0001633978-18-000029 — 2.02, 9.01
- 2018-03-12 0001193125-18-078154 — 1.01, 2.01, 8.01, 9.01
- 2018-02-06 0001628280-18-001082 — 2.02, 9.01
- 2017-11-08 0001633978-17-000133 — 5.02, 9.01
- 2017-11-07 0001633978-17-000131 — 5.07
- 2017-11-01 0001633978-17-000117 — 2.02, 9.01
- 2017-08-09 0001633978-17-000058 — 2.02, 9.01
- 2017-05-04 0001633978-17-000035 — 2.02, 9.01
- 2017-03-08 0001193125-17-074740 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2017-03-02 0001193125-17-066769 — 8.01, 9.01
- 2017-02-07 0001633978-17-000005 — 2.02, 9.01
- 2017-01-03 0001628280-17-000018 — 4.01, 9.01
- 2016-11-09 0001628280-16-021143 — 5.02, 5.07, 9.01
- 2016-10-27 0001628280-16-020382 — 2.02, 9.01
- 2016-08-09 0001628280-16-018811 — 2.02, 9.01
- 2016-06-21 0001628280-16-017201 — 8.01
- 2016-05-04 0001628280-16-015501 — 2.02, 9.01
- 2016-02-16 0001628280-16-011261 — 5.02, 9.01
- 2016-02-04 0001628280-16-010758 — 5.02, 9.01
- 2016-02-04 0001628280-16-010755 — 2.02, 9.01
- 2015-11-17 0001193125-15-378953 — 7.01
- 2015-11-10 0001628280-15-008606 — 2.02, 9.01
- 2015-09-28 0001193125-15-329665 — 8.01, 9.01
- 2015-08-11 0001193125-15-286405 — 7.01, 9.01
- 2015-08-06 0001193125-15-281219 — 1.01, 5.02, 5.03, 5.05, 8.01, 9.01
- 2015-08-03 0001193125-15-274808 — 5.03, 9.01

## late-filing notifications on or before 2022-08-24

- 2015-11-10 0001628280-15-008612 — NT 10-Q, for the period ended 2015-09-26
- 2015-09-28 0001193125-15-329672 — NT 10-K, for the period ended 2015-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001628280-22-022980:8k_2_02:1]
EX-99.1
2
lite_ex991xq4fy22.htm
EX-99.1

[0001628280-22-022980:8k_2_02:2]
Document

[0001628280-22-022980:8k_2_02:3]
NEWS RELEASE

[0001628280-22-022980:8k_2_02:4]
LUMENTUM ANNOUNCES FISCAL FOURTH QUARTER AND FULL YEAR 2022 RESULTS

[0001628280-22-022980:8k_2_02:5]
Fiscal Fourth Quarter Highlights:

[0001628280-22-022980:8k_2_02:6]
•Net revenue of $422.1 million

[0001628280-22-022980:8k_2_02:7]
•GAAP operating margin of 13.1%; Non-GAAP operating margin of 28.8%

[0001628280-22-022980:8k_2_02:8]
•GAAP diluted net income per share of $0.49; Non-GAAP diluted net income per share of  $1.47

[0001628280-22-022980:8k_2_02:9]
Fiscal Year 2022 Highlights:

[0001628280-22-022980:8k_2_02:10]
•Net revenue of $1.7 billion

[0001628280-22-022980:8k_2_02:11]
•GAAP operating margin of 17.7%; Non-GAAP operating margin of 30.8%

[0001628280-22-022980:8k_2_02:12]
•GAAP diluted net income per share of $2.68; Non-GAAP diluted net income per share of  $6.05

[0001628280-22-022980:8k_2_02:13]
San Jose, Calif., August 16, 2022 – Lumentum Holdings Inc. (“Lumentum” or the “Company”) today reported results for its fiscal fourth quarter and full year ended July 2, 2022.

[0001628280-22-022980:8k_2_02:14]
“In fiscal 2022, we achieved record revenue in datacom EMLs, coherent components, pump lasers, tunable products, and sub-sea components, with company profitability above our target model of 50 percent gross margin and 30 percent operating margin. Fourth quarter revenue was above our midpoint, with both operating margin and earnings per share exceeding the top end of guidance. In addition, we are making meaningful progress in alleviating component shortages in our Telecom business,” said Alan Lowe, President and CEO.

[0001628280-22-022980:8k_2_02:15]
“On August 3rd, we completed our acquisition of NeoPhotonics, and yesterday we announced our purchase of IPG’s telecom transmission product lines, both of which position us to create even more value for our cloud and networking customers. Our guidance for the first quarter and outlook for fiscal 2023 reflects the previously discussed share normalization in 3D sensing for smartphones. As we close a solid year and position the company for growth with these investments, we expect that the business fundamentals will drive a mix shift toward our Telecom, Datacom, and Commercial Lasers businesses, supporting double-digit revenue growth in fiscal 2023 and beyond,” added Mr. Lowe.

[0001628280-22-022980:8k_2_02:16]
Fiscal Fourth Quarter Highlights:

[0001628280-22-022980:8k_2_02:17]
Net revenue for the fiscal fourth quarter of 2022 was $422.1 million, with GAAP net income attributable to common stockholders of $34.7 million, or $0.49 per diluted share. Net revenue for the fiscal third quarter of 2022 was $395.4 million, with GAAP net income of $26.0 million, or $0.35 per diluted share. Net revenue for the fiscal fourth quarter of 2021 was $392.1 million, with GAAP net income attributable to common stockholders of $21.5 million, or $0.28 per diluted share.

[0001628280-22-022980:8k_2_02:18]
Non-GAAP net income for fiscal fourth quarter of 2022 was $105.0 million, or $1.47 per diluted share. Non-GAAP net income for fiscal third quarter of 2022 was $88.9 million, or $1.19 per diluted share. Non-GAAP net income for the fiscal fourth quarter of 2021 was $81.9 million, or $1.06 per diluted share.

[0001628280-22-022980:8k_2_02:19]
The Company held $2,549.0 million in total cash, cash equivalents, and short-term investments at the end of the fiscal fourth quarter of 2022, down $15.1 million from the third quarter of 2022.

[0001628280-22-022980:8k_2_02:20]
Full Fiscal Year 2022 Highlights:

[0001628280-22-022980:8k_2_02:21]
Net revenue for fiscal year 2022 was $1,712.6 million, with GAAP net income attributable to common stockholders of $198.9 million, or $2.68 per diluted share. Net revenue for fiscal year 2021 was $1,742.8 million, with GAAP net income attributable to common stockholders of $397.3 million, or $5.07 per diluted share.

[0001628280-22-022980:8k_2_02:22]
Non-GAAP net income for fiscal year 2022 was $449.2 million, or $6.05 per diluted share. Non-GAAP net income for fiscal year 2021 was $458.2 million, or $5.84 per diluted share.

[0001628280-22-022980:8k_2_02:23]
The Company held $2,549.0 million in total cash, cash equivalents, and short-term investments at the end of the fiscal fourth quarter of 2022, up $603.0 million from the fourth quarter of 2021. In March 2022, we issued $861.0 million in aggregate principal amount of 0.50% Convertible Notes due in 2028 (“the 2028 Notes”). The net proceeds from the sale of the 2028 Notes were $854.1 million, after deducting $6.9 million in issuance costs and professional fees. Concurrent with the issuance of the 2028 Notes, we used $200.0 million of the net proceeds to repurchase 2.0 million shares of our common stock in privately negotiated transactions. In addition, we repurchased 4.0 million shares of our common stock for an aggregate purchase price of $348.9 million during fiscal 2022 under the board-authorized share buyback program. As of the end of the fiscal year 2022, we have $410.2 million remaining under the share buyback program.  Cash from operations for the fiscal year of 2022 was $459.3 million.

[0001628280-22-022980:8k_2_02:24]
Financial Overview – Fiscal Fourth Quarter Ended July 2, 2022

[0001628280-22-022980:8k_2_02:25]
|  | GAAP Results ($ in millions) |
|  | Q4 |  | Q3 |  | Q4 |  | Change |
|  | FY 2022 |  | FY 2022 |  | FY 2021 |  | Q/Q |  | Y/Y |
| Net revenue | $ | 422.1 |  |  | $ | 395.4 |  |  | $ | 392.1 |  |  | 6.8% |  | 7.7% |
| Gross margin | 43.0 | % |  | 42.3 | % |  | 41.5 | % |  | 70bps |  | 150bps |
| Operating margin | 13.1 | % |  | 11.8 | % |  | 11.7 | % |  | 130bps |  | 140bps |
|  | Non-GAAP Results ($ in millions) |
|  | Q4 |  | Q3 |  | Q4 |  | Change |
|  | FY 2022 |  | FY 2022 |  | FY 2021 |  | Q/Q |  | Y/Y |
| Net revenue | $ | 422.1 |  |  | $ | 395.4 |  |  | $ | 392.1 |  |  | 6.8% |  | 7.7% |
| Gross margin | 50.4 | % |  | 49.5 | % |  | 47.7 | % |  | 90bps |  | 270bps |
| Operating margin | 28.8 | % |  | 26.5 | % |  | 24.6 | % |  | 230bps |  | 420bps |

[0001628280-22-022980:8k_2_02:26]
|  | Net Revenue by Segment ($ in millions) |
|  | Q4 |  | % of |  | Q3 |  | Q4 |  | Change |
|  | FY 2022 |  | Net Revenue |  | FY 2022 |  | FY 2021 |  | Q/Q |  | Y/Y |
| Optical Communications | $ | 370.9 |  |  | 87.9 | % |  | $ | 344.2 |  |  | $ | 355.2 |  |  | 7.8 | % |  | 4.4 | % |
| Lasers | 51.2 |  |  | 12.1 | % |  | 51.2 |  |  | 36.9 |  |  | — | % |  | 38.8 | % |
| Total | $ | 422.1 |  |  | 100.0 | % |  | $ | 395.4 |  |  | $ | 392.1 |  |  | 6.8 | % |  | 7.7 | % |

[0001628280-22-022980:8k_2_02:27]
Financial Overview – Fiscal Year Ended July 2, 2022

[0001628280-22-022980:8k_2_02:28]
|  | GAAP Results ($ in millions) |
|  | FY 2022 |  | FY 2021 |  | Change Y/Y |  |
| Net revenue | $ | 1,712.6 |  |  | $ | 1,742.8 |  |  | (1.7)% |  |
| Gross margin | 46.0 | % |  | 44.9 | % |  | 110bps |  |
| Operating margin | 17.7 | % |  | 30.2 | % |  | (1,250)bps |  |

[0001628280-22-022980:8k_2_02:29]
|  | Non-GAAP Results ($ in millions) |
|  | FY 2022 |  | FY 2021 |  | Change Y/Y |  |
| Net revenue | $ | 1,712.6 |  |  | $ | 1,742.8 |  |  | (1.7)% |  |
| Gross margin | 51.6 | % |  | 50.9 | % |  | 70bps |  |
| Operating margin | 30.8 | % |  | 30.8 | % |  | —bps |  |

[0001628280-22-022980:8k_2_02:30]
|  | Net Revenue by Segment ($ in millions) |
|  | FY 2022 |  | FY 2021 |  | Change Y/Y |  |
| Optical Communications | $ | 1,518.5 |  |  | $ | 1,620.7 |  |  | (6.3)% |  |
| Lasers | 194.1 |  |  | 122.1 |  |  | 59.0% |  |
| Total | $ | 1,712.6 |  |  | $ | 1,742.8 |  |  | (1.7)% |  |

[0001628280-22-022980:8k_2_02:31]
The tables above provide comparisons of quarterly and annual results to prior periods, including sequential quarterly and year-over-year changes. A reconciliation between GAAP and non-GAAP measures is contained in this release under the section titled “Use of Non-GAAP Financial Measures.”

[0001628280-22-022980:8k_2_02:32]
Business Outlook

[0001628280-22-022980:8k_2_02:33]
Lumentum expects the following for the fiscal first quarter of 2023:

[0001628280-22-022980:8k_2_02:34]
•Net revenue in the range of $490 million to $520 million

[0001628280-22-022980:8k_2_02:35]
•Non-GAAP operating margin of 25.0% to 27.0%

[0001628280-22-022980:8k_2_02:36]
•Non-GAAP diluted earnings per share of $1.45 to $1.70

[0001628280-22-022980:8k_2_02:37]
We have not provided reconciliations from GAAP to non-GAAP measures for our outlook. A large portion of non-GAAP adjustments, such as restructuring charges, stock-based compensation, non-cash income tax expense and credits, integration related costs, and other costs unrelated to current and future operations are by their nature highly volatile and we have low visibility as to the range that may be incurred in the future. The non-GAAP diluted earnings per share forecast is based on an estimated share count of 71.5 million utilizing the treasury stock method.

[0001628280-22-022980:8k_2_02:38]
Conference Call

[0001628280-22-022980:8k_2_02:39]
Lumentum will host a conference call on August 16, 2022, at 5:30 am PT/8:30 am ET. A live webcast of the call and the replay will be available on the Lumentum website at http://investor.lumentum.com through August 23, 2022, at 8:59 pm PT. To listen to the live conference call, dial (844) 200-6205 or (929) 526-1599 and reference the passcode 824091. To access the replay, dial (866) 813-9403 or (929) 458-6194 and reference the passcode 159915. Supporting materials outlining the Company’s latest financial results will be posted on http://investor.lumentum.com under the “Events and Presentations” section concurrently with this earnings press release. Lumentum has used, and intends to continue to use, its Investor Relations website as means of disclosing material nonpublic information and for complying with its disclosure obligations under Regulation FD. This press release is being furnished as an exhibit to a Current Report on Form 8-K filed with the Securities and Exchange Commission and will be available at http://www.sec.gov/.

[0001628280-22-022980:8k_2_02:40]
About Lumentum

[0001628280-22-022980:8k_2_02:41]
Lumentum (NASDAQ: LITE) is a market-leading designer and manufacturer of innovative optical and photonic products enabling optical networking and laser applications worldwide. Lumentum optical components and subsystems are part of virtually every type of telecom, enterprise, and data center network. Lumentum lasers enable advanced manufacturing techniques and diverse applications including next-generation 3D sensing capabilities. Lumentum is headquartered in San Jose, California with R&D, manufacturing, and sales offices worldwide. For more information, visit www.lumentum.com and follow Lumentum on LinkedIn, Twitter, Facebook, Instagram and YouTube.

[0001628280-22-022980:8k_2_02:42]
Forward-Looking Statements

[0001628280-22-022980:8k_2_02:43]
Contact Information

[0001628280-22-022980:8k_2_02:44]
Investors:     Kathy Ta, 408-750-3853; investor.relations@lumentum.com

[0001628280-22-022980:8k_2_02:45]
Media:         Sean Ogarrio, 408-546-5405; media@lumentum.com

[0001628280-22-022980:8k_2_02:46]
Category:    Financial

[0001628280-22-022980:8k_2_02:47]
The following financial tables are presented in accordance with GAAP, unless otherwise specified.

[0001628280-22-022980:8k_2_02:48]
LUMENTUM HOLDINGS INC.

[0001628280-22-022980:8k_2_02:49]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001628280-22-022980:8k_2_02:50]
(in millions, except per share data)

[0001628280-22-022980:8k_2_02:51]
(unaudited)

[0001628280-22-022980:8k_2_02:52]
|  | Three Months Ended |  | Twelve Months Ended |
|  | July 2, 2022 |  | July 3, 2021 |  | July 2, 2022 |  | July 3, 2021 |
| Net revenue | $ | 422.1 |  |  | $ | 392.1 |  |  | $ | 1,712.6 |  |  | $ | 1,742.8 |  |
| Cost of sales | 224.8 |  |  | 213.4 |  |  | 861.1 |  |  | 898.0 |  |
| Amortization of acquired developed intangibles | 15.6 |  |  | 15.9 |  |  | 62.9 |  |  | 61.7 |  |
| Gross profit | 181.7 |  |  | 162.8 |  |  | 788.6 |  |  | 783.1 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 56.7 |  |  | 54.1 |  |  | 220.7 |  |  | 214.5 |  |
| Selling, general and administrative | 69.6 |  |  | 58.3 |  |  | 265.7 |  |  | 241.4 |  |
| Restructuring and related charges | — |  |  | 4.6 |  |  | (1.1) |  |  | 7.7 |  |
| Merger termination fee and related costs, net | — |  |  | — |  |  | — |  |  | (207.5) |  |
| Total operating expenses | 126.3 |  |  | 117.0 |  |  | 485.3 |  |  | 256.1 |  |
| Income from operations | 55.4 |  |  | 45.8 |  |  | 303.3 |  |  | 527.0 |  |
| Interest expense | (26.5) |  |  | (18.0) |  |  | (80.2) |  |  | (66.7) |  |
| Other income (expense), net | 8.2 |  |  | 0.7 |  |  | 12.0 |  |  | 2.8 |  |
| Income before income taxes | 37.1 |  |  | 28.5 |  |  | 235.1 |  |  | 463.1 |  |
| Provision for income taxes | 2.4 |  |  | 7.0 |  |  | 36.2 |  |  | 65.8 |  |
| Net income | $ | 34.7 |  |  | $ | 21.5 |  |  | $ | 198.9 |  |  | $ | 397.3 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.50 |  |  | $ | 0.29 |  |  | $ | 2.79 |  |  | $ | 5.27 |  |
| Diluted | $ | 0.49 |  |  | $ | 0.28 |  |  | $ | 2.68 |  |  | $ | 5.07 |  |
| Shares used to compute net income per share: |  |  |  |  |  |  |  |
| Basic | 68.9 |  |  | 74.8 |  |  | 71.2 |  |  | 75.4 |  |
| Diluted | 71.5 |  |  | 77.5 |  |  | 74.2 |  |  | 78.4 |  |

[0001628280-22-022980:8k_2_02:53]
LUMENTUM HOLDINGS INC.

[0001628280-22-022980:8k_2_02:54]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001628280-22-022980:8k_2_02:55]
(in millions, except per share data)

[0001628280-22-022980:8k_2_02:56]
(unaudited)

[0001628280-22-022980:8k_2_02:57]
|  | July 2, 2022 |  | July 3, 2021 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 1,290.2 |  |  | $ | 774.3 |  |
| Short-term investments | 1,258.8 |  |  | 1,171.7 |  |
| Accounts receivable, net | 262.0 |  |  | 212.8 |  |
| Inventories | 250.1 |  |  | 196.4 |  |
| Prepayments and other current assets | 78.1 |  |  | 81.6 |  |
| Total current assets | 3,139.2 |  |  | 2,436.8 |  |
| Property, plant and equipment, net | 360.5 |  |  | 361.1 |  |
| Operating lease right-of-use assets, net | 73.6 |  |  | 67.4 |  |
| Goodwill | 368.9 |  |  | 368.9 |  |
| Other intangible assets, net | 155.7 |  |  | 241.2 |  |
| Deferred tax asset | 27.0 |  |  | 72.9 |  |
| Other non-current assets | 37.3 |  |  | 3.3 |  |
| Total assets | $ | 4,162.2 |  |  | $ | 3,551.6 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 156.7 |  |  | $ | 116.9 |  |
| Accrued payroll and related expenses | 54.6 |  |  | 54.3 |  |
| Accrued expenses | 44.7 |  |  | 33.1 |  |
| Convertible notes, current | 409.9 |  |  | 390.7 |  |
| Operating lease liabilities, current | 11.2 |  |  | 11.8 |  |
| Other current liabilities | 39.4 |  |  | 57.8 |  |
| Total current liabilities | 716.5 |  |  | 664.6 |  |
| Convertible notes, non-current | 1,466.1 |  |  | 789.8 |  |
| Operating lease liabilities, non-current | 48.8 |  |  | 47.6 |  |
| Deferred tax liability | 12.9 |  |  | 35.9 |  |
| Other non-current liabilities | 42.9 |  |  | 40.9 |  |
| Total liabilities | 2,287.2 |  |  | 1,578.8 |  |
| Stockholders’ equity: |  |  |  |
| Common stock, $0.001 par value, 990 authorized shares; 68.0 and 73.0 shares issued and outstanding as of July 2, 2022 and July 3, 2021, respectively | 0.1 |  |  | 0.1 |  |
| Additional paid-in capital | 2,003.6 |  |  | 1,743.6 |  |
| Retained earnings (accumulated deficit) | (129.1) |  |  | 220.9 |  |
| Accumulated other comprehensive income | 0.4 |  |  | 8.2 |  |
| Total stockholders’ equity | 1,875.0 |  |  | 1,972.8 |  |
| Total liabilities and stockholders’ equity | $ | 4,162.2 |  |  | $ | 3,551.6 |  |

[0001628280-22-022980:8k_2_02:58]
Use of Non-GAAP Financial Measures

[0001628280-22-022980:8k_2_02:59]
In this press release, Lumentum provides investors with margin, gross profit, gross margin, research and development expense, selling, general and administrative expense, operating income, operating margin, interest and other income (expense), net, income before income taxes, provision for income taxes, net income, and net income per share on a non-GAAP basis, as well as the non-GAAP measures of EBITDA and Adjusted EBITDA. Lumentum believes this non-GAAP financial information provides additional insight into the Company’s on-going business operations and results, as well as cash generation, and has therefore chosen to provide this information to investors for a more consistent basis of comparison and to help them evaluate the results of the Company’s on-going operations and enable more meaningful period to period comparisons. In addition, the Company believes that providing certain of these measures allow investors to better understand the Company’s cash flows and, importantly, to evaluate the efficacy of the methodology and information used by management to evaluate and measure such cash flows. However, these measures may be different from non-GAAP measures used by other companies, limiting their usefulness for comparison purposes. The non-GAAP financial measures used in this press release should not be considered in isolation from measures of financial performance prepared in accordance with GAAP. Investors are cautioned that there are material limitations associated with the use of non-GAAP financial measures as an analytical tool. In particular, many of the adjustments to our GAAP financial measures reflect the exclusion of items that are recurring and will be reflected in our financial results for the foreseeable future. Further, these non-GAAP financial measures may not be comparable to similarly titled measurements reported by other companies.

[0001628280-22-022980:8k_2_02:60]
Non-GAAP gross margin, non-GAAP gross profit, non-GAAP expenses, non-GAAP operating margin, non-GAAP operating income, non-GAAP income before income taxes, non-GAAP net income, and non-GAAP net income per share and Adjusted EBITDA exclude (i) stock-based compensation, (ii) gains on sale of product lines, (iii) integration related costs, (iv) inventory and fixed asset write down due to product line exits, (v) amortization of acquired intangibles, (vi) restructuring and related charges, (vii) merger termination fee related to our terminated Agreement with Coherent, (viii) foreign exchange (gains) losses, net, (ix) non-cash interest expense on convertible notes, (x) income tax impacts, and (xi) other (gains) charges related to non-recurring activities. The presentation of these and other similar items in Lumentum’s non-GAAP financial results should not be interpreted as implying that these items are non-recurring, infrequent or unusual.

[0001628280-22-022980:8k_2_02:61]
A quantitative reconciliation between GAAP and non-GAAP financial data with respect to historical periods is included in the supplemental financial table attached to this press release.

[0001628280-22-022980:8k_2_02:62]
LUMENTUM HOLDINGS INC.

[0001628280-22-022980:8k_2_02:63]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001628280-22-022980:8k_2_02:64]
(in millions, except per share data)

[0001628280-22-022980:8k_2_02:65]
(unaudited)

[0001628280-22-022980:8k_2_02:66]
|  | Three Months Ended |  | Twelve Months Ended |
|  | July 2, 2022 |  | April 2, 2022 |  | July 3, 2021 |  | July 2, 2022 |  | July 3, 2021 |
| Gross profit on GAAP basis | $ | 181.7 |  |  | $ | 167.2 |  |  | $ | 162.8 |  |  | $ | 788.6 |  |  | $ | 783.1 |  |
| Stock-based compensation | 5.6 |  |  | 5.4 |  |  | 5.4 |  |  | 20.8 |  |  | 19.2 |  |
| Inventory and fixed asset write down due to product line exits | — |  |  | — |  |  | — |  |  | 0.1 |  |  | 0.4 |  |
| Amortization of acquired intangibles | 15.6 |  |  | 15.6 |  |  | 15.9 |  |  | 62.9 |  |  | 61.7 |  |
| Other charges, net (1) | 9.8 |  |  | 7.4 |  |  | 3.1 |  |  | 10.6 |  |  | 23.1 |  |
| Gross profit on non-GAAP basis | $ | 212.7 |  |  | $ | 195.6 |  |  | $ | 187.2 |  |  | $ | 883.0 |  |  | $ | 887.5 |  |
| Gross margin on non-GAAP basis | 50.4 | % |  | 49.5 | % |  | 47.7 | % |  | 51.6 | % |  | 50.9 | % |
| Research and development on GAAP basis | $ | 56.7 |  |  | $ | 56.7 |  |  | $ | 54.1 |  |  | $ | 220.7 |  |  | $ | 214.5 |  |
| Stock-based compensation | (6.3) |  |  | (5.4) |  |  | (4.7) |  |  | (22.1) |  |  | (19.5) |  |
| Other charges, net | (0.3) |  |  | (0.6) |  |  | (0.3) |  |  | (1.0) |  |  | (0.9) |  |
| Research and development on non-GAAP basis | $ | 50.1 |  |  | $ | 50.7 |  |  | $ | 49.1 |  |  | $ | 197.6 |  |  | $ | 194.1 |  |
| Selling, general and administrative on GAAP basis | $ | 69.6 |  |  | $ | 63.8 |  |  | $ | 58.3 |  |  | $ | 265.7 |  |  | $ | 241.4 |  |
| Stock-based compensation | (15.8) |  |  | (12.5) |  |  | (14.1) |  |  | (60.2) |  |  | (54.2) |  |
| Integration related costs | — |  |  | — |  |  | — |  |  | — |  |  | (0.7) |  |
| Amortization of acquired intangibles | (5.6) |  |  | (5.8) |  |  | (6.2) |  |  | (22.6) |  |  | (24.0) |  |
| Other gains (charges), net (2) | (7.2) |  |  | (5.5) |  |  | 3.5 |  |  | (24.5) |  |  | (5.2) |  |
| Selling, general and administrative on non-GAAP basis | $ | 41.0 |  |  | $ | 40.0 |  |  | $ | 41.5 |  |  | $ | 158.4 |  |  | $ | 157.3 |  |
| Income from operations on GAAP basis | $ | 55.4 |  |  | $ | 46.8 |  |  | $ | 45.8 |  |  | $ | 303.3 |  |  | $ | 527.0 |  |
| Stock-based compensation | 27.7 |  |  | 23.3 |  |  | 24.2 |  |  | 103.1 |  |  | 92.9 |  |
| Inventory and fixed asset write down due to product line exits | — |  |  | — |  |  | — |  |  | 0.1 |  |  | 0.4 |  |
| Integration related costs | — |  |  | — |  |  | — |  |  | — |  |  | 0.7 |  |
| Amortization of acquired intangibles | 21.2 |  |  | 21.4 |  |  | 22.1 |  |  | 85.5 |  |  | 85.7 |  |
| Restructuring and related charges (3) | — |  |  | (0.1) |  |  | 4.6 |  |  | (1.1) |  |  | 7.7 |  |
| Merger termination fee and related costs, net (4) | — |  |  | — |  |  | — |  |  | — |  |  | (207.5) |  |
| Other (gains) charges, net | 17.3 |  |  | 13.5 |  |  | (0.1) |  |  | 36.1 |  |  | 29.2 |  |
| Income from operations on non-GAAP basis | $ | 121.6 |  |  | $ | 104.9 |  |  | $ | 96.6 |  |  | $ | 527.0 |  |  | $ | 536.1 |  |
| Operating margin on non-GAAP basis | 28.8 | % |  | 26.5 | % |  | 24.6 | % |  | 30.8 | % |  | 30.8 | % |
| Interest and other (expense) income, net on GAAP basis | $ | (18.3) |  |  | $ | (17.5) |  |  | $ | (17.3) |  |  | $ | (68.2) |  |  | $ | (63.9) |  |
| Gains on sale of product lines | — |  |  | — |  |  | (0.2) |  |  | — |  |  | (0.7) |  |
| Foreign exchange (gains) losses, net | (4.4) |  |  | (1.1) |  |  | 0.6 |  |  | (6.1) |  |  | 4.4 |  |
| Non-cash interest expense on convertible notes and other expenses | 23.9 |  |  | 17.7 |  |  | 16.2 |  |  | 72.7 |  |  | 60.1 |  |
| Interest and other (expense) income, net on non-GAAP basis | $ | 1.2 |  |  | $ | (0.9) |  |  | $ | (0.7) |  |  | $ | (1.6) |  |  | $ | (0.1) |  |

[0001628280-22-022980:8k_2_02:67]
| Income before income taxes on GAAP basis | $ | 37.1 |  |  | $ | 29.3 |  |  | $ | 28.5 |  |  | $ | 235.1 |  |  | $ | 463.1 |  |
| Stock-based compensation | 27.7 |  |  | 23.3 |  |  | 24.2 |  |  | 103.1 |  |  | 92.9 |  |
| Inventory and fixed asset write down due to product line exits | — |  |  | — |  |  | — |  |  | 0.1 |  |  | 0.4 |  |
| Integration related costs | — |  |  | — |  |  | — |  |  | — |  |  | 0.7 |  |
| Amortization of acquired intangibles | 21.2 |  |  | 21.4 |  |  | 22.1 |  |  | 85.5 |  |  | 85.7 |  |
| Restructuring and related charges (3) | — |  |  | (0.1) |  |  | 4.6 |  |  | (1.1) |  |  | 7.7 |  |
| Merger termination fee and related costs, net (4) | — |  |  | — |  |  | — |  |  | — |  |  | (207.5) |  |
| Gains on sale of product lines | — |  |  | — |  |  | (0.2) |  |  | — |  |  | (0.7) |  |
| Foreign exchange (gains) losses, net | (4.4) |  |  | (1.1) |  |  | 0.6 |  |  | (6.1) |  |  | 4.4 |  |
| Non-cash interest expense on convertible notes and other expenses | 23.9 |  |  | 17.7 |  |  | 16.2 |  |  | 72.7 |  |  | 60.1 |  |
| Other (gains) charges, net | 17.3 |  |  | 13.5 |  |  | (0.1) |  |  | 36.1 |  |  | 29.2 |  |
| Income before income taxes on non-GAAP basis | $ | 122.8 |  |  | $ | 104.0 |  |  | $ | 95.9 |  |  | $ | 525.4 |  |  | $ | 536.0 |  |
| Provision for income taxes on GAAP basis | $ | 2.4 |  |  | $ | 3.3 |  |  | $ | 7.0 |  |  | $ | 36.2 |  |  | $ | 65.8 |  |
| Income tax adjustments | 15.4 |  |  | 11.8 |  |  | 7.0 |  |  | 40.0 |  |  | 12.0 |  |
| Provision for income taxes on non-GAAP basis | $ | 17.8 |  |  | $ | 15.1 |  |  | $ | 14.0 |  |  | $ | 76.2 |  |  | $ | 77.8 |  |
| Net income on GAAP basis | $ | 34.7 |  |  | $ | 26.0 |  |  | $ | 21.5 |  |  | $ | 198.9 |  |  | $ | 397.3 |  |
| Stock-based compensation | 27.7 |  |  | 23.3 |  |  | 24.2 |  |  | 103.1 |  |  | 92.9 |  |
| Inventory and fixed asset write down due to product line exits | — |  |  | — |  |  | — |  |  | 0.1 |  |  | 0.4 |  |
| Integration related costs | — |  |  | — |  |  | — |  |  | — |  |  | 0.7 |  |
| Amortization of acquired intangibles | 21.2 |  |  | 21.4 |  |  | 22.1 |  |  | 85.5 |  |  | 85.7 |  |
| Restructuring and related charges (3) | — |  |  | (0.1) |  |  | 4.6 |  |  | (1.1) |  |  | 7.7 |  |
| Merger termination fee and related costs, net (4) | — |  |  | — |  |  | — |  |  | — |  |  | (207.5) |  |
| Gains on sale of product lines | — |  |  | — |  |  | (0.2) |  |  | — |  |  | (0.7) |  |
| Foreign exchange (gains) losses, net | (4.4) |  |  | (1.1) |  |  | 0.6 |  |  | (6.1) |  |  | 4.4 |  |
| Non-cash interest expense on convertible notes and other expenses | 23.9 |  |  | 17.7 |  |  | 16.2 |  |  | 72.7 |  |  | 60.1 |  |
| Other (gains) charges, net | 17.3 |  |  | 13.5 |  |  | (0.1) |  |  | 36.1 |  |  | 29.2 |  |
| Income tax adjustments | (15.4) |  |  | (11.8) |  |  | (7.0) |  |  | (40.0) |  |  | (12.0) |  |
| Net income on non-GAAP basis | $ | 105.0 |  |  | $ | 88.9 |  |  | $ | 81.9 |  |  | $ | 449.2 |  |  | $ | 458.2 |  |
| Net income per share on non-GAAP basis | $ | 1.47 |  |  | $ | 1.19 |  |  | $ | 1.06 |  |  | $ | 6.05 |  |  | $ | 5.84 |  |
| Shares used in per share calculation - diluted on GAAP basis | 71.5 |  |  | 74.5 |  |  | 77.5 |  |  | 74.2 |  |  | 78.4 |  |

[0001628280-22-022980:8k_2_02:68]
(1) Other charges excluded in deriving non-GAAP gross profit for the three months ended July 2, 2022 primarily relate to $8.2 million of incremental charges to acquire components from various brokers to satisfy customer demand.

[0001628280-22-022980:8k_2_02:69]
Other charges excluded in deriving non-GAAP gross profit for the twelve months ended July 2, 2022 primarily relate to $14.0 million of incremental charges to acquire components from various brokers to satisfy customer demand, offset by a $5.9 million gain from equipment sales in connection with transferring product lines to new production facilities.

[0001628280-22-022980:8k_2_02:70]
(2) Other charges excluded from selling, general and administrative expense for the three months ended July 2, 2022 primarily include $1.9 million of transaction costs related to the acquisition of NeoPhotonics and $2.8 million of professional service fees related to optimizing our international legal structure.

[0001628280-22-022980:8k_2_02:71]
Other charges excluded from selling, general and administrative expense for the twelve months ended July 2, 2022 primarily include $8.4 million of transaction costs related to the acquisition of NeoPhotonics and $9.4 million of professional service fees related to optimizing our international legal structure.

[0001628280-22-022980:8k_2_02:72]
(3) During fiscal 2022, we recorded a net reversal to our restructuring and related charges of $1.1 million in our consolidated statements of operations, which was primarily attributable to lower than anticipated employee severance charges due to retaining and re-assigning certain employees.

[0001628280-22-022980:8k_2_02:73]
(4) For the twelve months ended July 3, 2021, we recorded a $217.6 million gain related to the receipt of a termination fee from Coherent in March 2021 as a result of the termination of our merger agreement. This gain was offset by $10.1 million of Coherent acquisition-related charges.

[0001628280-22-022980:8k_2_02:74]
LUMENTUM HOLDINGS INC.

[0001628280-22-022980:8k_2_02:75]
RECONCILIATION OF GAAP NET INCOME (LOSS) TO ADJUSTED EBITDA

[0001628280-22-022980:8k_2_02:76]
(in millions, except per share data)

[0001628280-22-022980:8k_2_02:77]
(unaudited)

[0001628280-22-022980:8k_2_02:78]
|  | Three Months Ended |  | Twelve Months Ended |
|  | July 2, 2022 |  | April 2, 2022 |  | July 3, 2021 |  | July 2, 2022 |  | July 3, 2021 |
| GAAP net income | $ | 34.7 |  |  | $ | 26.0 |  |  | $ | 21.5 |  |  | $ | 198.9 |  |  | $ | 397.3 |  |
| Interest and other expense (income), net | 18.3 |  |  | 17.5 |  |  | 17.3 |  |  | 68.2 |  |  | 63.9 |  |
| Provision for income taxes | 2.4 |  |  | 3.3 |  |  | 7.0 |  |  | 36.2 |  |  | 65.8 |  |
| Depreciation | 20.4 |  |  | 20.2 |  |  | 21.0 |  |  | 81.6 |  |  | 91.4 |  |
| Amortization of acquired intangibles | 21.2 |  |  | 21.4 |  |  | 22.1 |  |  | 85.5 |  |  | 85.7 |  |
| EBITDA | 97.0 |  |  | 88.4 |  |  | 88.9 |  |  | 470.4 |  |  | 704.1 |  |
| Restructuring and related charges | — |  |  | (0.1) |  |  | 4.6 |  |  | (1.1) |  |  | 7.7 |  |
| Stock-based compensation | 27.7 |  |  | 23.3 |  |  | 24.2 |  |  | 103.1 |  |  | 92.9 |  |
| Inventory and fixed asset write down due to product line exits | — |  |  | — |  |  | — |  |  | 0.1 |  |  | 0.4 |  |
| Integration related costs | — |  |  | — |  |  | — |  |  | — |  |  | 0.7 |  |
| Merger termination fee and related costs, net | — |  |  | — |  |  | — |  |  | — |  |  | (207.5) |  |
| Other (gains) and charges | 17.3 |  |  | 13.5 |  |  | (0.2) |  |  | 36.1 |  |  | 22.7 |  |
| Adjusted EBITDA | $ | 142.0 |  |  | $ | 125.1 |  |  | $ | 117.5 |  |  | $ | 608.6 |  |  | $ | 621.0 |  |
