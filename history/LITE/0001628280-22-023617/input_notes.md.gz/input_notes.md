# LITE notes — 0001628280-22-023617


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001628280-22-023617:notes:1]
Portions of the information called for by Part III of this Annual Report on Form 10-K is hereby incorporated by reference from the definitive proxy statement for the Registrant’s annual meeting of stockholders, which will be filed with the Securities and Exchange Commission not later than 120 days after the Registrant’s fiscal year ended July 2, 2022.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001628280-22-023617:notes:2]
Note 1. Description of Business and Summary of Significant Accounting Policies

[0001628280-22-023617:notes:3]
Description of Business

[0001628280-22-023617:notes:4]
Lumentum Holdings Inc. (“we,” “us,” “our”, “Lumentum” or the “Company”) is an industry-leading provider of optical and photonic products defined by revenue and market share addressing a range of end market applications including Optical Communications (“OpComms”) and Commercial Lasers (“Lasers”) for manufacturing, inspection and life-science applications. We seek to use our core optical and photonic technology, and our volume manufacturing capability, to expand into attractive emerging markets that benefit from advantages that optical or photonics-based solutions provide, including 3D sensing for consumer electronics and diode light sources for a variety of consumer and industrial applications. The majority of our customers are currently as well as historically original equipment manufacturers (“OEMs”) that incorporate our products into their products which then address end-market applications. For example, we sell fiber optic components that network equipment manufacturers (“NEMs”) assemble into communications networking systems, which they sell to communications service providers, hyperscale cloud operators, and enterprises with their own networks. Similarly, many of our Lasers products customers incorporate our products into tools they produce, which are used for manufacturing processes by their customers. For 3D sensing, we sell diode lasers to manufacturers of consumer electronics products for mobile, personal computing, gaming, and other applications, including to the automotive industry, who then integrate our devices within their products, for eventual resale to consumers and also into other industrial applications.

[0001628280-22-023617:notes:5]
Basis of Presentation

[0001628280-22-023617:notes:6]
The preparation of the consolidated financial statements in accordance with U.S. generally accepted accounting principles (“GAAP”) requires management to make estimates and assumptions that affect the amounts reported in our consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates. Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are inventory valuation, revenue recognition, income taxes, goodwill and business combinations.

[0001628280-22-023617:notes:7]
We are now in the third year of the COVID-19 pandemic, and while the impact of the pandemic is lessening, new variants are causing continued concern. As these variants continue to emerge, efforts to mitigate or contain the impacts of the pandemic continue to evolve, and the duration and severity of the impact of the pandemic on our business and results of operations in future periods remain uncertain. The extent of the impact of COVID-19 on our operational and financial performance will depend on certain developments, including but not limited to the duration and spread of the pandemic and its variants, duration of local, state and federal issued public health orders in each jurisdiction where we operate or in which our customers and suppliers operate, impact on our customers and our sales cycles, impact on our supply chain and manufacturing partners, impact on our employees and impact on regional and worldwide economies and financial markets in general, all of which are uncertain and cannot be predicted. We assessed the potential impact that this pandemic has on our estimates as of July 2, 2022 and determined that there were no material impacts. However, due to the global supply chain constraint, we have had to incur incremental supply and procurement costs in order to fulfill demand from our customers. These higher costs have increased our inventory balances by $16.8 million as of July 2, 2022 and may decrease our gross margin in the near term.

[0001628280-22-023617:notes:8]
We are also continuously monitoring developments in the ongoing conflict between Russia and Ukraine including the related export controls and resulting sanctions imposed on Russia by the U.S. and other countries.  Additional factors such as increased inflation, escalating energy costs, constrained raw material availability, and thus increasing costs could impact the global economy.  Although the global implications of the Russian/Ukraine conflict are difficult to predict at this time, we do not presently foresee direct material adverse effects upon our business.

[0001628280-22-023617:notes:9]
Fiscal Years

[0001628280-22-023617:notes:10]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Every fifth or sixth fiscal year will have a 53-week period. The additional week in a 53-week year is added to the third quarter, making such quarter consist of 14 weeks. Our fiscal 2022 and 2020 were 52-week years, ending on July 2, 2022 and June 27, 2020, respectively. Our fiscal 2021 was a 53-week year, ending on July 3, 2021.

[0001628280-22-023617:notes:11]
Principles of Consolidation

[0001628280-22-023617:notes:12]
The consolidated financial statements are prepared in accordance with GAAP and includes the accounts of Lumentum Holdings Inc. and its wholly-owned subsidiaries. Intercompany transactions and balances are fully eliminated in consolidation.

[0001628280-22-023617:notes:13]
Certain prior period amounts have been reclassified to conform to the current period presentation. The reclassification of the prior period amounts did not impact previously reported consolidated financial statements.

[0001628280-22-023617:notes:14]
Business Combination

[0001628280-22-023617:notes:15]
On November 4, 2021, Lumentum and NeoPhotonics Corporation (“NeoPhotonics”) announced a merger agreement (the “Merger Agreement”) pursuant to which Lumentum will acquire all outstanding shares of NeoPhotonics stock. On August 3, 2022, we completed our merger with NeoPhotonics. Please refer to “Note 4. Business Combination”.

[0001628280-22-023617:notes:16]
On August 15, 2022, we completed a transaction to acquire a business that develops and markets products for use in telecommunications and datacenter infrastructure, including ASICs and optical transceivers.  This acquisition will enable us to expand our business in our OpComms segment. Please refer to “Note 21. Subsequent Events”.

[0001628280-22-023617:notes:17]
Termination of Coherent Merger Agreement

[0001628280-22-023617:notes:18]
On January 18, 2021, Lumentum and Coherent, Inc. (“Coherent”) entered into a merger agreement (the “merger agreement”), under which Lumentum would acquire all outstanding shares of Coherent common stock. As of the date of the merger agreement, the total transaction consideration was approximately $5.7 billion. In March 2021, Coherent terminated the merger agreement and paid Lumentum a termination fee of $217.6 million in accordance with the merger agreement. This gain was offset by $10.1 million of acquisition-related expenses and the net amount is presented as “merger termination fee and related costs, net” in our consolidated statement of operations for the year ended July 3, 2021.

[0001628280-22-023617:notes:19]
Summary of Significant Accounting Policies

[0001628280-22-023617:notes:20]
Our significant accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. We believe that of our significant accounting policies described below, involve a greater degree of judgment and complexity and are the most critical to aid in fully understanding and evaluating our consolidated financial statements. These policies include inventory valuation, revenue recognition, income taxes, goodwill and business combinations. For a description of our critical accounting policies, please also refer to “Management’s Discussion and Analysis of Financial Condition and Results of Operations”, Critical Accounting Policies and Estimates.

[0001628280-22-023617:notes:21]
Cash Equivalents

[0001628280-22-023617:notes:22]
We consider highly-liquid fixed income securities with original maturities of three months or less at the time of purchase to be cash equivalents. As of fiscal year ended July 2, 2022, our cash equivalents consist of money market funds, commercial paper, U.S. Agency securities and U.S. Treasury securities.

[0001628280-22-023617:notes:23]
Short-Term Investments

[0001628280-22-023617:notes:24]
We classify our investments in debt securities as available-for-sale and record these investments at fair value. Investments with an original maturity of three months or less at the date of purchase are considered cash equivalents, while all other investments are classified as short-term based on management’s intent and ability to use the funds in current operations. Unrealized gains and losses are reported as a component of other comprehensive income (loss). Realized gains and losses are determined based on the specific identification method, and are reflected as other income (expense), net in our consolidated statements of operations.

[0001628280-22-023617:notes:25]
We regularly review our investment portfolio to identify and evaluate investments that have indicators of possible impairment. Factors considered in determining whether a loss is other-than-temporary include, but are not limited to: the length of time and extent a security’s fair value has been below its cost, the financial condition and near-term prospects of the investee, the credit quality of the security’s issuer, likelihood of recovery and our intent and ability to hold the security for a period of time sufficient to allow for any anticipated recovery in value. For our debt instruments, we also evaluate whether we have the intent to sell the security or it is more likely than not that we will be required to sell the security before recovery of its cost basis.

[0001628280-22-023617:notes:26]
Fair Value of Financial Instruments

[0001628280-22-023617:notes:27]
We define fair value as the price that would be received from selling an asset, or paid to transfer a liability, in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities which are required to be recorded at fair value, we consider the principal or most advantageous market in which to transact and the market-based risk. We apply fair value accounting for all financial assets and liabilities that are recognized or disclosed at fair value in the financial statements on a recurring basis. The carrying amounts reported in the consolidated financial statements approximate the fair value for cash, accounts receivable, accounts payable and accrued liabilities due to their short-term nature.

[0001628280-22-023617:notes:28]
Basic and Diluted Net Income per Common Share

[0001628280-22-023617:notes:29]
Basic income per share is computed by dividing net income available to common stockholders by the weighted average number of common shares outstanding during the reporting period. The weighted average number of shares is calculated by taking the number of shares outstanding and weighting them by the amount of time that they were outstanding. Diluted earnings per share reflects the potential dilution that could occur if stock options, preferred stock, and other commitments to issue common stock were exercised or equity awards vest resulting in the issuance of common stock that could share in the earnings of the Company.

[0001628280-22-023617:notes:30]
Diluted loss per share is the same as basic loss per share during periods where net losses are incurred since the inclusion of the potential common stock equivalents would be anti-dilutive as a result of the net loss.

[0001628280-22-023617:notes:31]
Potentially dilutive common shares result from the assumed exercise of outstanding stock options, assumed vesting of outstanding equity awards, assumed issuance of stock under the employee stock purchase plan, and assumed conversion of our outstanding $448.1 million in aggregate principal amount of 2024 Notes, $1,050.0 million in aggregate principal amount of 2026 Notes, and $861.0 million in aggregate principal amount of 2028 Notes, all using the treasury stock method as we have the ability and intent to settle the face value of the Notes in cash.

[0001628280-22-023617:notes:32]
The dilutive effect of securities from the 2015 Equity Incentive Plan is reflected in diluted earnings per share by application of the treasury stock method, which includes consideration of unamortized share-based compensation expense and the dilutive effect of in-the-money options and non-vested restricted stock units. Under the treasury stock method, the amount the employee must pay for exercising stock options and the amount of unamortized share-based compensation expense are collectively assumed to be used to repurchase hypothetical shares. An increase in the fair value of our common stock can result in a greater dilutive effect from potentially dilutive awards.

[0001628280-22-023617:notes:33]
Anti-dilutive potential shares from 2015 Equity Incentive Plan are excluded from the calculation of diluted earnings per share if their exercise price exceeded the average market price during the period or the share-based awards were determined to be anti-dilutive based on applying the treasury stock method.

[0001628280-22-023617:notes:34]
Inventory Valuation

[0001628280-22-023617:notes:35]
Inventory is recorded at standard cost, which approximates actual cost computed on a first-in, first-out basis, not in excess of net realizable value. We assess the value of our inventory on a quarterly basis and write down those inventories which are obsolete or in excess of our forecasted demand to the lower of their cost or estimated net realizable value. Our estimates of forecasted demand are based upon our analysis and assumptions including, but not limited to, expected product lifecycles, product development plans and historical usage by product. Our product line management personnel play a key role in our excess review process by providing updated sales forecasts, managing product transitions and working with manufacturing to minimize excess inventory. If actual market conditions are less favorable than our forecasts, or actual demand from our customers is lower than our estimates, we may be required to record additional inventory write-downs. If actual market conditions are more favorable than anticipated, inventory previously written down may be sold, resulting in lower cost of sales and higher income from operations than expected in that period.

[0001628280-22-023617:notes:36]
Leases

[0001628280-22-023617:notes:37]
We adopted Topic 842 on June 30, 2019, the first day of fiscal year 2020, using the modified retrospective transition approach.

[0001628280-22-023617:notes:38]
We determine if an arrangement is a lease at inception for arrangements with an initial term of more than 12 months, and classify it as either a finance or operating lease.

[0001628280-22-023617:notes:39]
Finance leases are generally those that allow us to substantially utilize or pay for the entire asset over its estimated useful life. Finance leases are recorded in property, plant and equipment, net, and finance lease liabilities within other current and other non-current liabilities on our consolidated balance sheets. We have lease arrangements with lease and non-lease components, and the non-lease components for our finance leases are accounted for separately, based on estimated stand-alone values, and are not included in the initial measurement of our finance lease assets and corresponding liabilities. Finance lease assets are amortized in operating expenses on a straight-line basis over the shorter of the estimated useful lives of the assets or the lease term, with the interest component included in interest expense and recognized using the effective interest method over the lease term.

[0001628280-22-023617:notes:40]
Operating leases are recorded in operating lease right-of-use assets, net, and operating lease liabilities, current and non-current on our consolidated balance sheets. For operating leases of buildings, we account for non-lease components, such as common area maintenance, as a component of the lease, and include it in the initial measurement of our operating lease assets and corresponding liabilities. Operating lease assets are amortized on a straight-line basis in operating expenses over the lease term.

[0001628280-22-023617:notes:41]
Our lease liabilities are recognized based on the present value of the remaining fixed lease payments, over the lease term, using a discount rate of similarly secured borrowings available to us. For the purpose of lease liability measurement, we consider only payments that are fixed and determinable at the time of commencement. Any variable payments that depend on an index or rate are expensed as incurred. Our lease terms may include options to extend when it is reasonably certain that we will exercise that option. Our lease assets also include any lease payments made and exclude any lease incentives received prior to commencement. Our lease assets are tested for impairment in the same manner as long-lived assets used in operations. We generally recognize sublease income on a straight-line basis over the sublease term.

[0001628280-22-023617:notes:42]
Revenue Recognition

[0001628280-22-023617:notes:43]
Pursuant to Topic 606, our revenues are recognized upon the application of the following steps:

[0001628280-22-023617:notes:44]
•identification of the contract, or contracts, with a customer;

[0001628280-22-023617:notes:45]
•identification of the performance obligations in the contract;

[0001628280-22-023617:notes:46]
•determination of the transaction price;

[0001628280-22-023617:notes:47]
•allocation of the transaction price to the performance obligations in the contract; and

[0001628280-22-023617:notes:48]
•recognition of revenues when, or as, the contractual performance obligations are satisfied.

[0001628280-22-023617:notes:49]
The majority of our revenue comes from product sales, consisting of sales of Lasers and OpComms hardware products to our customers. Our revenue contracts generally include only one performance obligation. Revenues are recognized at a point in time when control of the promised goods or services are transferred to our customers upon shipment or delivery of goods or rendering of services, in an amount that reflects the consideration we expect to be entitled to in exchange for those goods or services. We have entered into vendor managed inventory (“VMI”) programs with our customers. Under these arrangements, we receive purchase orders from our customers, and the inventory is shipped to the VMI location upon receipt of the purchase order. The customer then pulls the inventory from the VMI hub based on its production needs. Revenue under VMI programs is recognized when control transfers to the customer, which is generally once the customer pulls the inventory from the hub.

[0001628280-22-023617:notes:50]
Revenue from all sales types is recognized at the transaction price. The transaction price is determined based on the consideration to which we will be entitled in exchange for transferring goods or services to the customer adjusted for estimated variable consideration, if any. We typically estimate the impact on the transaction price for discounts offered to the customers for early payments on receivables or net of accruals for estimated sales returns. These estimates are based on historical returns, analysis of credit memo data and other known factors. Actual returns could differ from these estimates. We allocate the transaction price to each distinct product based on its relative standalone selling price. The product price as specified on the purchase order is considered the standalone selling price as it is an observable input that depicts the price as if sold to a similar customer in similar circumstances.

[0001628280-22-023617:notes:51]
Taxes assessed by a governmental authority that are both imposed on and concurrent with a specific revenue-producing transaction, that are collected by us from a customer and deposited with the relevant government authority, are excluded from revenue.

[0001628280-22-023617:notes:52]
Our revenue arrangements do not contain significant financing components as our standard payment terms are less than one year.

[0001628280-22-023617:notes:53]
If a customer pays consideration, or the Company has a right to an amount of consideration that is unconditional before we transfer a good or service to the customer, those amounts are classified as deferred revenue or deposits received from customers which are included in other current liabilities or other long-term liabilities when the payment is made or it is due, whichever is earlier.

[0001628280-22-023617:notes:54]
Transaction Price Allocated to the Remaining Performance Obligations

[0001628280-22-023617:notes:55]
Remaining performance obligations represent the transaction price allocated to performances obligations that are unsatisfied or partially unsatisfied as of the end of the reporting period. Unsatisfied and partially unsatisfied performance obligations consist of contract liabilities and non-cancellable backlog. Non-cancellable backlog includes goods and services for which customer purchase orders have been accepted that are scheduled or in the process of being scheduled for shipment. A portion of our revenue arises from vendor managed inventory arrangements where the timing and volume of customer utilization is difficult to predict.

[0001628280-22-023617:notes:56]
Deferred revenue at July 2, 2022 and July 3, 2021 was nil and $0.6 million, respectively, which was recorded in other current liabilities within the consolidated balance sheets. During fiscal 2022 and 2021, we recognized $0.6 million and $1.7 million of revenue that was included in deferred revenue as of July 3, 2021 and June 27, 2020, respectively.

[0001628280-22-023617:notes:57]
Warranty

[0001628280-22-023617:notes:58]
Hardware products regularly include warranties to the end customers such that the product continues to function according to published specifications. We typically offer a twelve month warranty for most of our products. However, in some instances depending upon the product, specific market, product line and geography in which we operate, and what is common in the industry, our warranties can vary and range from six months to five years. These standard warranties are assurance type warranties and do not offer any services in addition to the assurance that the product will continue working as specified. Therefore, warranties are not considered separate performance obligations in the arrangement. Instead, the expected cost of warranty is accrued as expense in accordance with authoritative guidance.

[0001628280-22-023617:notes:59]
We provide reserves for the estimated costs of product warranties that we record as cost of sales at the time revenue is recognized. We estimate the costs of our warranty obligations based on our historical experience of known product failure rates, use of materials to repair or replace defective products and service delivery costs incurred in correcting product failures. In addition, from time to time, specific warranty accruals may be made if discrete technical problems arise.

[0001628280-22-023617:notes:60]
Shipping and Handling Costs

[0001628280-22-023617:notes:61]
We record shipping and handling costs related to revenue transactions within cost of sales as a period cost.

[0001628280-22-023617:notes:62]
Contract Costs

[0001628280-22-023617:notes:63]
The Company recognizes the incremental direct costs of obtaining a contract, which consist of sales commissions, when control over the products they relate to transfers to the customer. Applying the practical expedient, the Company recognizes commissions as expense when incurred, as the amortization period of the commission asset the Company would have otherwise recognized is less than one year.

[0001628280-22-023617:notes:64]
Contract Balances

[0001628280-22-023617:notes:65]
The Company records accounts receivable when it has an unconditional right to consideration. Contract liabilities are recorded when cash payments are received or due in advance of performance. Contract liabilities consist of advance payments and deferred revenue, where the Company has unsatisfied performance obligations. Contract liabilities are classified as deferred revenue and customer deposits, and are included in other current liabilities within our consolidated balance sheet. Payment terms vary by customer. The time between invoicing and when payment is due is not significant. Please refer to “Note 20. Revenue Recognition” for a presentation of changes in contract balances.

[0001628280-22-023617:notes:66]
Disaggregation of Revenue

[0001628280-22-023617:notes:67]
We disaggregate revenue by geography and by product. Please refer to “Note 20. Revenue Recognition” for a presentation of disaggregated revenue. We do not present other levels of disaggregation, such as by type of products, customer, markets, contracts, duration of contracts, timing of transfer of control and sales channels, as this information is not used by our Chief Operating Decision Maker to manage the business.

[0001628280-22-023617:notes:68]
Income Taxes

[0001628280-22-023617:notes:69]
In accordance with the authoritative guidance on accounting for income taxes, we recognize income taxes using an asset and liability approach. This approach requires the recognition of taxes payable or refundable for the current year and deferred tax liabilities and assets for the future tax consequences of events that have been recognized in our consolidated financial statements or tax returns. The measurement of current and deferred taxes is based on provisions of the enacted tax law, and the effects of future changes in tax laws or rates are not anticipated.

[0001628280-22-023617:notes:70]
The authoritative guidance provides for recognition of deferred tax assets if the realization of such deferred tax assets is more likely than not to occur based on an evaluation of both positive and negative evidence and the relative weight of the evidence. We consider future growth, forecasted earnings, future taxable income, the mix of earnings in the jurisdictions in which we operate, historical earnings, taxable income in prior years, if carryback is permitted under the law, and prudent and feasible tax planning strategies in determining the need for a valuation allowance. In the event we were to determine that we would not be able to realize all or part of our net deferred tax assets in the future, an adjustment to the deferred tax assets valuation allowance would be charged to earnings in the period in which we make such a determination, or goodwill would be adjusted at our final determination of the valuation allowance related to an acquisition within the measurement period. If we later determine that it is more likely than not that the net deferred tax assets would be realized, we would reverse the applicable portion of the previously provided valuation allowance as an adjustment to earnings at such time.

[0001628280-22-023617:notes:71]
We are subject to income tax audits by the respective tax authorities of the jurisdictions in which we operate. The determination of our income tax liabilities in each of these jurisdictions requires the interpretation and application of complex, and sometimes uncertain, tax laws and regulations. The authoritative guidance on accounting for income taxes prescribes both recognition and measurement criteria that must be met for the benefit of a tax position to be recognized in the financial statements. If a tax position taken, or expected to be taken, in a tax return does not meet such recognition or measurement criteria, an unrecognized tax benefit liability is recorded.  If we ultimately determine that an unrecognized tax benefit liability is no longer necessary, we reverse the liability and recognize a tax benefit in the period in which it is determined that the unrecognized tax benefit liability is no longer necessary.

[0001628280-22-023617:notes:72]
The recognition and measurement of current taxes payable or refundable and deferred tax assets and liabilities requires that we make certain estimates and judgments. Changes to these estimates or a change in judgment may have a material impact on our tax provision in a future period.

[0001628280-22-023617:notes:73]
Property, Plant and Equipment

[0001628280-22-023617:notes:74]
Property, plant and equipment are stated at cost. Depreciation is computed by the straight-line method generally over the following estimated useful lives of the assets: 10 to 40 years for building and improvements, 3 to 10 years for machinery and equipment, and 2 to 5 years for furniture, fixtures, software and office equipment. Leasehold improvements are amortized using the straight-line method over the shorter of the estimated useful lives of the assets or the term of the lease, including the renewal option that we are reasonably certain to exercise.

[0001628280-22-023617:notes:75]
In accordance with the guidance for business combinations, we determine whether a transaction or event is a business combination, which requires that the assets acquired and liabilities assumed constitute a business. Each business combination is then accounted for by applying the acquisition method. If the assets acquired are not a business, we account for the transaction or event as an asset acquisition. Under both methods, we recognize the identifiable assets acquired, the liabilities assumed, and any noncontrolling interest in the acquired entity. We capitalize acquisition-related costs and fees associated with asset acquisitions and immediately expense acquisition-related costs and fees associated with business combinations.

[0001628280-22-023617:notes:76]
We allocate the fair value of purchase consideration to the tangible assets acquired, liabilities assumed and intangible assets acquired based on their estimated fair values. The excess of the fair value of purchase consideration over the fair values of these identifiable assets and liabilities is recorded as goodwill. When determining the fair values of assets acquired and liabilities assumed, we make significant estimates and assumptions, especially with respect to intangible assets. Critical estimates in valuing certain intangible assets include, but are not limited to, future expected cash flows from customer relationships and acquired developed technology and discount rates. Our estimates of fair value are based upon assumptions believed to be reasonable using best information available. These assumptions are inherently uncertain and unpredictable and, as a result, actual results may differ materially from estimates. Certain estimates associated with the accounting for acquisitions may change as additional information becomes available regarding the assets acquired and liabilities assumed. Any change in facts and circumstances that existed as of the acquisition date and impacts to our preliminary estimates is recorded to goodwill if identified within the measurement period. Subsequent to the measurement period or our final determination of fair value of assets and liabilities, whichever is earlier, the adjustments will affect our earnings.

[0001628280-22-023617:notes:77]
We estimate the economic lives of certain acquired assets and these lives are used to calculate depreciation and amortization expense. If our estimates of the economic lives change, depreciation or amortization expenses could be accelerated or slowed.

[0001628280-22-023617:notes:78]
Goodwill

[0001628280-22-023617:notes:79]
Goodwill represents the excess of the purchase price of an acquired business over the fair value of the identifiable assets acquired and liabilities assumed. We test goodwill impairment on an annual basis in the fiscal fourth quarter and at any other time when events occur or circumstances indicate that the carrying amount of goodwill may not be recoverable.

[0001628280-22-023617:notes:80]
We have the option to first assess qualitative factors to determine whether it is necessary to perform the quantitative goodwill impairment test. The qualitative factors we assess include long-term prospects of our performance, share price trends and market capitalization, and Company specific events. Unanticipated events and circumstances may occur that affect the accuracy of our assumptions, estimates and judgments. For example, if the price of our common stock were to significantly decrease combined with other adverse changes in market conditions, thus indicating that the underlying fair value of our reporting units may have decreased, we may reassess the value of our goodwill in the period such circumstances were identified.

[0001628280-22-023617:notes:81]
If we determine that, as a result of the qualitative assessment, it is more likely than not (i.e., greater than 50% likelihood) that the fair value of a reporting unit is less than its carrying amount, we perform the quantitative test by estimating the fair value of our reporting units. If the carrying value of a reporting unit exceeds its fair value, we record goodwill impairment loss equal to the excess of the carrying value of the reporting unit’s goodwill over its fair value, not to exceed the carrying amount of goodwill. The fair value of each of our goodwill reporting units is generally estimated using a combination of public company multiples and discounted cash flow methodologies.

[0001628280-22-023617:notes:82]
Based on the impairment analysis performed in the fourth quarter of each year presented, the fair value of each of our reporting units substantially exceeded the carrying value; as such, our annual qualitative assessment did not indicate that a more detailed quantitative analysis was necessary.

[0001628280-22-023617:notes:83]
Intangible Assets

[0001628280-22-023617:notes:84]
Intangible assets consist primarily of intangible assets purchased through acquisitions. Purchased intangible assets include acquired developed technologies (developed and core technology), customer relationships, and order backlog. Intangible assets, with the exception of customer relationships and order backlog, are amortized using the straight-line method over the estimated economic useful lives of the assets, which is the period during which expected cash flows support the fair value of such intangible assets. Customer relationships and order backlog are amortized using an accelerated method of amortization over the expected customer lives, which more accurately reflects the pattern of realization of economic benefits expected to be obtained.

[0001628280-22-023617:notes:85]
Long-lived Asset Valuation

[0001628280-22-023617:notes:86]
We test long-lived assets for recoverability, at the asset group level, when events or changes in circumstances indicate that their carrying amount may not be recoverable. Circumstances which could trigger a review include, but are not limited to: significant decreases in the market price of the asset, significant adverse changes in the business climate or legal factors, accumulation of costs significantly in excess of the amount originally expected for the acquisition or construction of the asset, current period cash flow or operating losses combined with a history of losses or a forecast of continuing losses associated with the use of the asset, or current expectation that the asset will more likely than not be sold or disposed significantly before the end of its estimated useful life.

[0001628280-22-023617:notes:87]
Recoverability is assessed based on the difference between the carrying amount of the asset and the sum of the undiscounted cash flows expected to result from the use and the eventual disposal of the asset. An impairment loss is recognized when the carrying amount is not recoverable and exceeds fair value.

[0001628280-22-023617:notes:88]
Pension Benefits

[0001628280-22-023617:notes:89]
The Company sponsors various employee retirement plans, including defined contribution, defined benefit and other post-retirement plans.  Please refer to “Note 17. Employee Retirement Plans” for more information.

[0001628280-22-023617:notes:90]
The funded status of our retirement-related benefit plan is measured as the difference between the fair value of plan assets and the benefit obligation at fiscal year end, the measurement date. The funded status of an underfunded benefit plan, of which the fair value of plan assets is less than the benefit obligation, is recognized as a non-current net pension liability in the consolidated balance sheets. For defined benefit pension plans, the benefit obligation is the projected benefit obligation (“PBO”) which represents the actuarial present value of benefits expected to be paid upon retirement.

[0001628280-22-023617:notes:91]
Net periodic pension cost (income) (“NPPC”) is recorded in the consolidated statements of operations and includes service cost, interest cost, expected return on plan assets, amortization of prior service cost and gains or losses previously recognized as a component of accumulated other comprehensive income. Service cost represents the actuarial present value of participant benefits attributed to services rendered by employees in the current year. Interest cost represents the time value of money cost associated with the passage of time. Gains or losses arise as a result of differences between actual experience and assumptions or as a result of changes in actuarial assumptions. Prior service cost or credits represent the cost of benefit improvements attributable to prior service granted in plan amendments. (Gains) losses and prior service cost (credit) that arise during the current year are first recognized as a component of accumulated other comprehensive income in the consolidated balances sheets, net of tax. Prior service cost is amortized as a component of NPPC over the average remaining service period of active plan participants starting at the date the plan amendment is adopted. Deferred actuarial gains or losses are subsequently recognized as a component of NPPC if they exceed the greater of 10% of PBO or the fair value of plan assets, with the excess amortized over the average remaining service period of active plan participants.

[0001628280-22-023617:notes:92]
The measurement of the benefit obligation and NPPC is based on our estimates and actuarial valuations, provided by third-party actuaries, which are approved by management. These valuations reflect the terms of the plans and use participant-specific information such as compensation, age and years of service, as well as certain assumptions, including estimates of discount rates, expected return on plan assets, rate of compensation increases, and mortality rates. We evaluate these assumptions annually at a minimum. In estimating the expected return on plan assets, we consider historical returns on plan assets, adjusted for forward-looking considerations, inflation assumptions and the impact of the active management of the plan’s invested assets.

[0001628280-22-023617:notes:93]
Concentration of Credit and Other Risks

[0001628280-22-023617:notes:94]
Financial instruments that potentially subject our business to concentration of credit risk consist primarily of cash, short-term investments, and trade receivables.

[0001628280-22-023617:notes:95]
Although the Company deposits its cash with financial institutions that management believes are of high credit quality, its deposits, at times, may exceed federally insured limits. The Company’s investment portfolio consists of investment grade securities diversified amongst security types, industries, and issuers. The Company’s investment policy limits the amount of credit exposure in the investment portfolio by imposing credit rating minimums and limiting purchases of a single issuer, security type, geography and industry, except for Treasury securities. The Company believes no significant concentration risk exists with respect to these investments.

[0001628280-22-023617:notes:96]
We perform credit evaluations of our customers’ financial condition and generally do not require collateral from our customers. These evaluations require significant judgment and are based on a variety of factors including, but not limited to, current economic trends, payment history, bad debt write-off experience, and financial review of the customer.

[0001628280-22-023617:notes:97]
We maintain an allowance for credit losses for estimated losses resulting from the inability of our customers to make required payments. When we become aware that a specific customer is unable to meet their financial obligations, we record a specific allowance to reflect the level of credit risk in the customer’s outstanding receivable balance. In addition, we record additional allowances based on certain percentages of aged receivable balances. These percentages take into account a variety of factors including, but not limited to, current economic trends, payment history and bad debt write-off experience. We classify bad debt expenses as selling, general and administrative expense.

[0001628280-22-023617:notes:98]
During fiscal 2022, 2021, and 2020, a few customers generated more than 10% of total net revenue. Please refer to “Note 19. Operating Segments and Geographic Information” to the consolidated financial statements.

[0001628280-22-023617:notes:99]
Our accounts receivable was concentrated with two customers as of July 2, 2022, which individually represented 10% and 10% of gross accounts receivable, respectively, and collectively accounted for 20% of the total gross accounts receivable, compared with two customers as of July 3, 2021, which individually represented 17% and 14% of gross accounts receivable, respectively, and collectively accounted for 31% of the total gross accounts receivable.

[0001628280-22-023617:notes:100]
We rely on a limited number of suppliers for a number of key components contained in our products. We also rely on a limited number of significant independent contract manufacturers for the production of certain key components and subassemblies contained in our products.

[0001628280-22-023617:notes:101]
We generally use a rolling twelve months forecast based on anticipated product orders, customer forecasts, product order history and backlog to determine our materials requirements. Lead times for the parts and components that we order vary significantly and depend on factors such as the specific supplier, contract terms and demand for a component at a given time. If the forecast does not meet or if it exceeds actual demand, we may have excess or shortfalls of some materials and components, as well as excess inventory purchase commitments. We could experience reduced or delayed product shipments or incur additional inventory write-downs and cancellation charges or penalties, which would increase costs and could have a material adverse impact on our results of operations.

[0001628280-22-023617:notes:102]
Foreign Currency Translation

[0001628280-22-023617:notes:103]
In fiscal 2019, we established the functional currency for our worldwide operations as the U.S. dollar. The change in our functional currency was made as a result of significant changes in economic facts and circumstances, primarily the acquisition of Oclaro, a U.S. dollar-denominated functional currency company, and the predominant use of the U.S. dollar, including when negotiating with customers and major suppliers.

[0001628280-22-023617:notes:104]
Translation adjustments reported prior to fiscal 2019, remain as a component of accumulated other comprehensive income in our consolidated balance sheet. The translated values for any non-monetary assets and liabilities as of the date we established the U.S. dollar as the functional currency became the new accounting basis for those assets. Accordingly, monetary assets and liabilities denominated in foreign currencies have been remeasured into U.S. dollars using the exchange rates in effect at the balance sheet date. Foreign currency re-measurement gains or losses are included in other income (expense), net in the consolidated statements of operations.

[0001628280-22-023617:notes:105]
Stock-based Compensation

[0001628280-22-023617:notes:106]
Compensation expense related to stock-based transactions is measured and recognized in the financial statements based on fair value at the grant date.

[0001628280-22-023617:notes:107]
Restricted stock units (“RSUs”) are grants of shares of our common stock, the vesting of which is based on the requisite service requirement. Generally, our RSUs are subject to forfeiture and expected to vest over one to four years. For new-hire grants, RSUs generally vest ratably on an annual basis over four years. For annual refresh grants, RSUs generally vest ratably on an annual, or combination of annual and quarterly, basis over three years.

[0001628280-22-023617:notes:108]
Restricted stock awards (“RSAs”) are grants of shares of our common stock that are subject to various restrictions, including restrictions on transferability and forfeiture provisions. RSAs are expected to vest over one to four years, and the shares acquired may not be transferred by the holder until the vesting conditions (if any) are satisfied.

[0001628280-22-023617:notes:109]
Performance stock units (“PSUs”) are grants of shares of our common stock that vest upon the achievement of certain performance and service conditions. We account for the fair value of PSUs using the closing market price of our common stock on the date of grant. We begin recognizing compensation expense when we conclude that it is probable that the performance conditions will be achieved. We reassess the probability of vesting at each reporting period and adjust our compensation cost based on this probability assessment. Our PSUs are subject to risk of forfeiture until performance and service conditions are satisfied and generally vest over three years.

[0001628280-22-023617:notes:110]
We estimate the fair value of the rights to acquire stock under our 2015 Employee Stock Purchase Plan (the “2015 Purchase Plan”) using the Black-Scholes option pricing formula. Our 2015 Purchase Plan provides for consecutive six-month offering periods. We recognize such compensation expense on a straight-line basis over the requisite service period. We calculate the volatility factor based on our historical stock prices.

[0001628280-22-023617:notes:111]
Treasury Stock

[0001628280-22-023617:notes:112]
Treasury stock is carried at cost. When we retire our treasury stock, any excess of the repurchase price paid over par value is allocated to retained earnings.

[0001628280-22-023617:notes:113]
Restructuring and Related Charges

[0001628280-22-023617:notes:114]
Costs associated with restructuring activities are recognized when they are obligated. However, in the case of leases, the expense is estimated and accrued when the property is vacated. Given the significance of, and the timing of the execution of such activities, this process is complex and involves periodic reassessments of estimates made from the time the property was vacated, including evaluating real estate market conditions for expected vacancy periods and sub-lease income. We recognize a liability for post-employment benefits for workforce reductions related to restructuring activities when payment is probable and the amount is reasonably estimable. We continually evaluate the adequacy of the remaining liabilities under our restructuring initiatives. Although we believe that these estimates accurately reflect the costs of our restructuring plans, actual results may differ, thereby requiring us to record additional provisions or reverse a portion of such provisions. Please refer to “Note 13. Restructuring and Related Charges”.

[0001628280-22-023617:notes:115]
Research and Development (“R&D”) Expense

[0001628280-22-023617:notes:116]
Costs related to R&D, which primarily consists of labor and benefits, supplies, facilities, consulting and outside service fees, are charged to expense as incurred.

[0001628280-22-023617:notes:117]
Loss Contingencies

[0001628280-22-023617:notes:118]
We are subject to the possibility of various loss contingencies arising in the ordinary course of business. We consider the likelihood of loss or impairment of an asset or the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss in determining loss contingencies. An estimated loss is accrued when it is probable that an asset has been impaired or a liability has been incurred and the amount of loss can be reasonably estimated. We regularly evaluate current information available to determine whether such accruals should be adjusted and whether new accruals are required.

[0001628280-22-023617:notes:119]
Asset Retirement Obligations (“ARO”)

[0001628280-22-023617:notes:120]
Our ARO are legal obligations associated with the retirement of long-lived assets pertaining to leasehold improvements. These liabilities are initially recorded at fair value and the related asset retirement costs are capitalized by increasing the carrying amount of the related assets by the same amount as the liability. Asset retirement costs are subsequently depreciated over the useful lives of the related assets. Subsequent to initial recognition, we record period-to-period changes in the ARO liability resulting from the passage of time and revisions to either the timing or the amount of the original estimate of undiscounted cash flows. We derecognize ARO liabilities when the related obligations are settled.


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0001628280-22-023617:notes:121]
We determine fair value based on the fair value hierarchy, which requires an entity to maximize the use of observable inputs and minimize the use of unobservable inputs when measuring fair value. Fair value is defined as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. The fair value assumes that the transaction to sell the asset or transfer the liability occurs in the principal or most advantageous market for the asset or liability and establishes that the fair value of an asset or liability shall be determined based on the assumptions that market participants would use in pricing the asset or liability. The classification of a financial asset or liability within the hierarchy is based upon the lowest level input that is significant to the fair value measurement. The fair value hierarchy prioritizes the inputs into three levels that may be used to measure fair value:

[0001628280-22-023617:notes:122]
| Level 1: | Inputs are unadjusted quoted prices in active markets for identical assets or liabilities. |
| Level 2: | Inputs are quoted prices for similar assets and liabilities in active markets or inputs that are observable for the asset or liability, either directly or indirectly through market corroboration, for substantially the full term of the financial instrument. |
| Level 3: | Inputs are unobservable inputs based on our assumptions. |

[0001628280-22-023617:notes:123]
The fair value of our Level 1 financial instruments, such as money market funds and U.S. Treasury securities, which are traded in active markets, is based on quoted market prices for identical instruments. The fair value of our Level 2 fixed income securities is obtained from an independent pricing service, which may use quoted market prices for identical or comparable instruments or model driven valuations using observable market data or inputs corroborated by observable market data. Our marketable securities are held by custodians who obtain investment prices from a third-party pricing provider that incorporates standard inputs in various asset price models. Our procedures include controls to ensure that appropriate fair values are recorded, including comparing the fair values obtained from our pricing service against fair values obtained from another independent source.

[0001628280-22-023617:notes:124]
Our pension assets consist of multiple institutional funds (“pension funds”) of which the fair values are based on the quoted prices of the underlying funds. Pension funds are mainly classified as Level 2 assets since such funds are not directly traded in active markets. Please refer to “Note 17. Employee Retirement Plans.”

[0001628280-22-023617:notes:125]
Assets Measured at Fair Value on a Non-Recurring Basis

[0001628280-22-023617:notes:126]
We periodically review our intangible and other long-lived assets for impairment whenever events or changes in circumstances indicate that the carrying amount of such assets may not be recoverable. Determination of recoverability is based on the lowest level of identifiable estimated undiscounted cash flows resulting from use of the asset and its eventual disposition. If not recoverable, an impairment loss would be calculated based on the excess of the carrying amount over the fair value.
Management utilizes various valuation methods, including an income approach, a market approach and a cost approach, to estimate the fair value of intangibles and other long-lived assets.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0001628280-22-023617:notes:127]
Contract Balances
The Company records accounts receivable when it has an unconditional right to consideration. Contract liabilities are recorded when cash payments are received or due in advance of performance. Contract liabilities consist of advance payments and deferred revenue, where the Company has unsatisfied performance obligations. Contract liabilities are classified as deferred revenue and customer deposits, and are included in other current liabilities within our consolidated balance sheet. Payment terms vary by customer. The time between invoicing and when payment is due is not significant.Disaggregation of RevenueWe disaggregate revenue by geography and by product. Please refer to “Note 20. Revenue Recognition” for a presentation of disaggregated revenue. We do not present other levels of disaggregation, such as by type of products, customer, markets, contracts, duration of contracts, timing of transfer of control and sales channels, as this information is not used by our Chief Operating Decision Maker to manage the business.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001628280-22-023617:notes:128]
Note 2. Recently Issued Accounting Pronouncements

[0001628280-22-023617:notes:129]
Accounting Pronouncements Recently Adopted

[0001628280-22-023617:notes:130]
In December 2019, the Financial Accounting Standard Board (“FASB”) issued Accounting Standards Update (“ASU”) 2019-12, Simplifying the Accounting for Income Taxes (Topic 740), which is intended to simplify various aspects related to accounting for income taxes by removing certain exceptions to the general principles in Topic 740 and which also clarifies and amends existing guidance to improve consistent application. ASU 2019-12 was effective for us at the beginning of fiscal year 2022, including interim periods within that reporting period. We adopted ASU 2019-12 in our first quarter of fiscal year 2022 on a prospective basis with no material impact to our consolidated financial statements.

[0001628280-22-023617:notes:131]
Accounting Pronouncements Not Yet Effective

[0001628280-22-023617:notes:132]
In October 2021, the FASB issued ASU 2021-08, Business Combinations (Topic 805)—Accounting for Contract Assets and Contract Liabilities from Contracts with Customers. This ASU clarifies that an acquirer of a business should recognize and measure contract assets and contract liabilities in a business combination in accordance with Accounting Standards Codification (“ASC”) Topic 606, Revenue from Contracts with Customers. This ASU is expected to improve comparability for both the recognition and measurement of acquired revenue contracts with customers at the date of and after a business combination. The new guidance is effective for fiscal years beginning after December 15, 2022, with early adoption permitted. ASU 2021-08 is effective for us in our first quarter of fiscal year 2024.  The impact of the adoption of ASU 2021-08 will depend on the contract assets and liabilities acquired in a business combination after that date, unless early adopted. We plan to early adopt the new standard in the first quarter of fiscal year 2023. 
In August 2020, FASB issued ASU 2020-06, Debt—Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging—Contracts in Entity’s Own Equity (Subtopic 815-40): Accounting for Convertible Instruments and Contracts in an Entity’s Own Equity, which simplifies the accounting for convertible instruments by removing the separation models for (i) convertible debt with a cash conversion feature and (ii) convertible instruments with a beneficial conversion feature. As a result, a convertible debt instrument will be accounted for as a single liability measured at its amortized cost.  ASU 2020-06 also requires the application of the if-converted method for calculating diluted earnings per share and the treasury stock method will no longer be available. The new guidance is effective for fiscal years beginning after December 15, 2021, with early adoption permitted no earlier than fiscal years beginning after December 15, 2020. ASU 2020-06 is effective for us in the first quarter of fiscal year 2023. We plan to adopt ASU 2020-06 using the modified retrospective approach as of July 3, 2022. Upon adoption, our 2026 Note and 2028 Notes will be accounted for as a single liability measured at amortized cost, resulting in an increase to "Convertible notes, non-current" by approximately $436 million, to reflect the full principal amount of the Notes outstanding, net of issuance costs; a reduction to additional paid-in capital, net of estimated income tax effects, by approximately $426 million, to remove the equity component separately recorded for the conversion features associated with the Notes;  an increase to deferred tax assets, net of approximately $92 million; and a cumulative-effect adjustment of approximately $82 million, net of estimated income tax effects. The adoption of this new guidance is anticipated to reduce interest expense by approximately $75 million during the fiscal year ended July 1, 2023.  In addition, the adoption requires the use of the if-converted method for all convertible notes in the diluted net income (loss) per share calculation and the inclusion of the effect of potential share settlement of the convertible notes, if the effect is more dilutive.


## us-gaap:EarningsPerShareTextBlock

[0001628280-22-023617:notes:133]
Note 3. Earnings Per Share

[0001628280-22-023617:notes:134]
The following table sets forth the computation of basic and diluted net income per share (in millions, except per share data):

[0001628280-22-023617:notes:135]
|  | Years Ended |
|  | July 2, 2022 |  | July 3, 2021 |  |  |  | June 27, 2020 |
| Numerator: |  |  |  |  |  |  |  |
| Net income - basic and diluted | $ | 198.9 |  |  | $ | 397.3 |  |  |  |  | $ | 135.5 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted average common shares outstanding - basic | 71.2 |  |  | 75.4 |  |  |  |  | 75.9 |  |
| Effect of dilutive securities from 2015 Equity Incentive Plan | 0.6 |  |  | 0.8 |  |  |  |  | 0.8 |  |
| Shares issuable assuming conversion of the 2024 Notes | 2.4 |  |  | 2.2 |  |  |  |  | 0.9 |  |
| Weighted average common shares outstanding - diluted | 74.2 |  |  | 78.4 |  |  |  |  | 77.6 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic | $ | 2.79 |  |  | $ | 5.27 |  |  |  |  | $ | 1.79 |  |
| Diluted | $ | 2.68 |  |  | $ | 5.07 |  |  |  |  | $ | 1.75 |  |

[0001628280-22-023617:notes:136]
Potentially dilutive common shares result from the assumed exercise of outstanding stock options, assumed vesting of outstanding equity awards, assumed issuance of stock under the employee stock purchase plan, and assumed conversion of our outstanding Notes, all using the treasury stock method.

[0001628280-22-023617:notes:137]
We have the ability and intent to settle the face value of our Notes in cash. Therefore, we use the treasury stock method for calculating the dilutive impact of the Notes.

[0001628280-22-023617:notes:138]
•The 2026 Notes and the 2028 Notes will have no impact on diluted earnings per share until the average price of our common stock exceeds the conversion price of $99.29 and $131.03, respectively.

[0001628280-22-023617:notes:139]
•The potentially dilutive shares resulting from the 2024 Notes were included in the calculation of diluted income per share for the years ended July 2, 2022, July 3, 2021 and June 27, 2020 since the average price of our common stock exceeded the conversion price of $60.62. Please refer to “Note 11. Debt” for further discussion of convertible notes.

[0001628280-22-023617:notes:140]
Anti-dilutive potential shares are excluded from the calculation of diluted earnings per share if their exercise price exceeded the average market price during the period or the share-based awards were determined to be anti-dilutive based on applying the treasury stock method. Anti-dilutive shares excluded from the calculation of diluted earnings per share were 0.1 million, 0.5 million, and 0.4 million for the years ended July 2, 2022, July 3, 2021 and June 27, 2020, respectively.


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0001628280-22-023617:notes:141]
Note 4. Business Combination

[0001628280-22-023617:notes:142]
On November 4, 2021, Lumentum and NeoPhotonics Corporation (“NeoPhotonics”) announced a merger agreement (the “Merger Agreement”). On August 3, 2022 (the “Closing Date”), we completed the merger with NeoPhotonics, pursuant to which Lumentum acquired all of the outstanding shares of NeoPhotonics stock. The addition of NeoPhotonics expands Lumentum’s opportunity in some of the fastest growing markets for optical components used in cloud and telecom network infrastructure. We expect the integrated company to be better positioned to serve the needs of a global customer base who are increasingly utilizing photonics to accelerate the shift to digital and virtual approaches to work and life, the proliferation of IoT, 5G, and next-generation mobile networks, and the transition to advanced cloud computing architectures.

[0001628280-22-023617:notes:143]
Under the terms of the Merger Agreement, NeoPhotonics stockholders received $16.00 per share in cash for each NeoPhotonics share they own. As a result, a total cash consideration of $867.3 million was paid to shareholders of NeoPhotonics on the Closing Date.

[0001628280-22-023617:notes:144]
As contemplated by the Merger Agreement, on January 14, 2022, Lumentum and NeoPhotonics entered into a credit agreement where Lumentum agreed to make term loans (“loans”) to NeoPhotonics in an aggregate principal amount not to exceed $50.0 million to help fund capital expenditures and increased working capital associated with NeoPhotonics’ growth plans. During fiscal 2022, the Company funded a $30.0 million loan request to NeoPhotonics. On August 1, 2022, the Company funded an additional $20.0 million loan request to NeoPhotonics. The interest is payable monthly in arrears on the first day of each month. The loans will mature on January 14, 2024 unless earlier repaid or accelerated. The $50.0 million loans in aggregate were not settled as of the Closing Date and therefore were included as part of the total purchase price in connection with the acquisition.

[0001628280-22-023617:notes:145]
During the fiscal year ended July 2, 2022, we incurred $8.4 million of transaction costs related to the merger, which are recorded under selling, general and administrative expenses in our consolidated statement of operations.
The acquisition will be accounted for as a business combination using the acquisition method of accounting, which requires, among other things, certain assets acquired and liabilities assumed to be recognized at their fair values as of the acquisition date. We are currently evaluating the purchase accounting for the acquisition.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001628280-22-023617:notes:146]
Note 5. Sale of Assets and Dispositions

[0001628280-22-023617:notes:147]
We continually evaluate our existing portfolio of businesses to maximize long-term stockholder value. We consider assets and liabilities as held-for-sale when management approves and commits to a plan to actively market assets or a group of assets for sale. Assets held-for-sale are recorded initially at the lower of its carrying value or its estimated fair value, less estimated costs to sell. Upon designation as an asset held-for-sale, we discontinue recording depreciation expense on such asset.

[0001628280-22-023617:notes:148]
Sale of Land and Building

[0001628280-22-023617:notes:149]
In fiscal 2021, we made a decision to cease manufacturing of certain products at a manufacturing facility that we owned in San Jose, California. During the fourth quarter of fiscal 2021, we shut down the manufacturing site and sold the related land and building for $23.0 million and recognized a gain of $8.3 million, which was recorded as an offset to selling, general and administrative expenses in our consolidated statement of operations as of July 3, 2021. As part of this transition, in fiscal 2022, we sold equipment that was no longer needed and recognized a gain of $5.9 million, which was recorded as an offset to cost of sales in our consolidated statement of operations for the year-ended July 2, 2022.

[0001628280-22-023617:notes:150]
Sale of Lithium Niobate modulators

[0001628280-22-023617:notes:151]
Following our acquisition of Oclaro, we announced our plan to discontinue development and manufacturing of Lithium Niobate modulators and wind down these operations in our San Donato, Italy site. In fiscal 2020, we sold our assets associated with certain Lithium Niobate product lines manufactured by our San Donato site for $17.0 million to Advanced Fiber Resources (Zhuhai) Ltd. (“AFR”) and recognized a gain of $13.8 million, which was recorded in other income (expense), net in the consolidated statements of operations.

[0001628280-22-023617:notes:152]
In fiscal 2020, we also sold certain assets that did not have any carrying value, including licenses to manufacture specific Lithium Niobate products and recognized a gain of $0.7 million, which was recorded in our other income (expense), net in the consolidated statements of operations.

[0001628280-22-023617:notes:153]
With the close of these transactions, our telecom transmission product strategy is now focused on Indium Phosphide photonic integrated circuits, as well as components and modules that incorporate these Indium Phosphide photonic integrated circuits.

[0001628280-22-023617:notes:154]
Datacom transceiver modules

[0001628280-22-023617:notes:155]
In fiscal 2019, we announced our plan to discontinue the development of future Datacom transceiver modules. As a result of this strategic change, we sold $3.0 million of the related Datacom assets held-for-sale and recorded an impairment charge of $1.6 million related to these assets held-for-sale in fiscal 2020. In fiscal 2020, we recorded $4.3 million of total impairment charges related to our long-lived assets that were not deemed to be useful.

[0001628280-22-023617:notes:156]
Other assets held-for-sale
In fiscal 2021, we recorded $0.4 million of land, building, and improvements as assets held-for-sale for one of our manufacturing sites in Slovenia. In fiscal 2022, we sold these assets at their book value


## us-gaap:CashCashEquivalentsAndShortTermInvestmentsTextBlock

[0001628280-22-023617:notes:157]
Note 6. Cash, Cash Equivalents and Short-term Investments

[0001628280-22-023617:notes:158]
The following table summarizes our cash, cash equivalents and short-term investments by category for the periods presented (in millions):

[0001628280-22-023617:notes:159]
|  | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| July 2, 2022: |  |  |  |  |  |  |  |
| Cash | $ | 235.9 |  |  | $ | — |  |  | $ | — |  |  | $ | 235.9 |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | 23.6 |  |  | — |  |  | — |  |  | 23.6 |  |
| Money market funds | 1,000.2 |  |  | — |  |  | — |  |  | 1,000.2 |  |
| U.S. Agency securities | 8.0 |  |  | — |  |  | — |  |  | 8.0 |  |
| U.S. Treasury securities | 22.5 |  |  | — |  |  | — |  |  | 22.5 |  |
| Total cash and cash equivalents | $ | 1,290.2 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,290.2 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 28.3 |  |  | $ | — |  |  | $ | — |  |  | $ | 28.3 |  |
| Commercial paper | 107.4 |  |  | — |  |  | (0.4) |  |  | 107.0 |  |
| Corporate debt securities | 539.9 |  |  | — |  |  | (7.4) |  |  | 532.5 |  |
| Municipal bonds | 1.0 |  |  | — |  |  | — |  |  | 1.0 |  |
| U.S. Agency securities | 67.1 |  |  | — |  |  | (1.4) |  |  | 65.7 |  |
| U.S. Treasury securities | 528.2 |  |  | 0.3 |  |  | (4.2) |  |  | 524.3 |  |
| Total short-term investments | $ | 1,271.9 |  |  | $ | 0.3 |  |  | $ | (13.4) |  |  | $ | 1,258.8 |  |
| July 3, 2021: |  |  |  |  |  |  |  |
| Cash | $ | 128.3 |  |  | $ | — |  |  | $ | — |  |  | $ | 128.3 |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | 7.5 |  |  | — |  |  | — |  |  | 7.5 |  |
| Corporate debt securities | 7.0 |  |  | — |  |  | — |  |  | 7.0 |  |
| Money market funds | 631.5 |  |  | — |  |  | — |  |  | 631.5 |  |
| Total cash and cash equivalents | $ | 774.3 |  |  | $ | — |  |  | $ | — |  |  | $ | 774.3 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 28.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 28.5 |  |
| Commercial paper | 136.7 |  |  | — |  |  | — |  |  | 136.7 |  |
| Corporate debt securities | 626.0 |  |  | 0.3 |  |  | (0.4) |  |  | 625.9 |  |
| Municipal bonds | 1.0 |  |  | — |  |  | — |  |  | 1.0 |  |
| U.S. Agency securities | 29.3 |  |  | — |  |  | — |  |  | 29.3 |  |
| U.S. Treasury securities | 350.3 |  |  | — |  |  | — |  |  | 350.3 |  |
| Total short-term investments | $ | 1,171.8 |  |  | $ | 0.3 |  |  | $ | (0.4) |  |  | $ | 1,171.7 |  |

[0001628280-22-023617:notes:160]
We review our investment portfolio to identify and evaluate investments that have indicators of possible impairment. Factors considered in determining whether a loss is other-than-temporary include, but are not limited to: the length of time and extent a security’s fair value has been below its cost, the financial condition and near-term prospects of the investee, the credit quality of the security’s issuer, likelihood of recovery and our intent and ability to hold the security for a period of time sufficient to allow for any anticipated recovery in value. For our debt instruments, we also evaluate whether we have the intent to sell the security or whether it is more likely than not that we will be required to sell the security before recovery of its cost basis. We have not recorded our unrealized losses on our short-term investments into income because we do not intend to sell nor is it more likely than not that we will be required to sell these investments prior to recovery of their amortized cost basis.

[0001628280-22-023617:notes:161]
We use the specific-identification method to determine any realized gains or losses from the sale of our short-term investments classified as available-for-sale. During fiscal 2022, 2021 and 2020, we did not realize significant gains or losses on a gross level from the sale of our short-term investments classified as available-for-sale.

[0001628280-22-023617:notes:162]
The components of other income (expense), net are as follows for the years presented (in millions):

[0001628280-22-023617:notes:163]
|  |  |  | Years Ended |
|  |  |  | July 2, 2022 |  | July 3, 2021 |  | June 27, 2020 |
| Foreign exchange gains (losses), net |  |  | $ | 6.1 |  |  | $ | (4.4) |  |  | $ | (1.4) |  |
| Interest and investment income |  |  | 6.1 |  |  | 5.7 |  |  | 15.8 |  |
| Other income (losses), net |  |  | (0.2) |  |  | 1.5 |  |  | 17.0 |  |
| Total other income (expense), net |  |  | $ | 12.0 |  |  | $ | 2.8 |  |  | $ | 31.4 |  |

[0001628280-22-023617:notes:164]
Other income (expense), net in fiscal 2020 includes a gain on the sale of Lithium Niobate modulators business of $13.8 million and a gain on the sale of certain assets used to manufacture specific Lithium Niobate products of $0.7 million. Please refer to “Note 5. Sale of Assets and Dispositions.”

[0001628280-22-023617:notes:165]
Included in the interest and investment income are $3.9 million, $4.1 million and $4.3 million of interest receivable as of July 2, 2022, July 3, 2021 and June 27, 2020, respectively, recorded in prepayments and other current assets within the consolidated balance sheets. We did not recognize an allowance for credit losses against the interest receivable in any of the periods presented as there were no such losses.

[0001628280-22-023617:notes:166]
As of July 2, 2022, the Company had $57.4 million of corporate debt securities that have been in a continuous unrealized loss position for more than 12 months with an unrealized loss position of $0.9 million. As of July 3, 2021, the Company did not have any cash equivalents and short-term investments that have been in a continuous unrealized gain or loss position for more than 12 months as of the periods presented.

[0001628280-22-023617:notes:167]
The following table summarizes unrealized losses on our cash equivalents and short-term investments by category that have been in a continuous unrealized loss position for less than 12 months as of the periods presented (in millions):

[0001628280-22-023617:notes:168]
|  | Fair Value |  | Unrealized Losses |  |  |  |  |  |  |  |  |
| July 2, 2022 |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | 73.7 |  |  | $ | (1.4) |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | 16.2 |  |  | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | 130.7 |  |  | (0.4) |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 473.2 |  |  | (6.5) |  |  |  |  |  |  |  |  |  |
| Municipal bonds | 1.0 |  |  | — |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 366.0 |  |  | (4.2) |  |  |  |  |  |  |  |  |  |
| Total | $ | 1,060.8 |  |  | $ | (12.5) |  |  |  |  |  |  |  |  |  |
| July 3, 2021 |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | 28.3 |  |  | $ | — |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | 6.0 |  |  |  |  |  |  |  |  |  |  |  |
| Commercial paper | 43.0 |  |  | — |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 432.3 |  |  | (0.4) |  |  |  |  |  |  |  |  |  |
| Municipal bonds | 1.0 |  |  | — |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 106.9 |  |  | — |  |  |  |  |  |  |  |  |  |
| Total | $ | 617.5 |  |  | $ | (0.4) |  |  |  |  |  |  |  |  |  |

[0001628280-22-023617:notes:169]
The following table classifies our short-term investments by contractual maturities (in millions):

[0001628280-22-023617:notes:170]
|  | July 2, 2022 |  | July 3, 2021 |
|  | Amortized Cost |  | Fair Value |  | Amortized Cost |  | Fair Value |
| Due within 1 year | $ | 1,010.9 |  |  | $ | 1,002.2 |  |  | $ | 587.0 |  |  | $ | 587.1 |  |
| Due between 1 year to 5 years | 261.0 |  |  | 256.6 |  |  | 584.8 |  |  | 584.6 |  |
|  | $ | 1,271.9 |  |  | $ | 1,258.8 |  |  | $ | 1,171.8 |  |  | $ | 1,171.7 |  |

[0001628280-22-023617:notes:171]
All available-for-sale securities have been classified as current, based on management’s intent and ability to use the funds in current operations.


## us-gaap:FairValueDisclosuresTextBlock

[0001628280-22-023617:notes:172]
Note 7. Fair Value Measurements

[0001628280-22-023617:notes:173]
Financial assets measured at fair value on a recurring basis are summarized below (in millions):

[0001628280-22-023617:notes:174]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| July 2, 2022 (1) |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | — |  |  | $ | 23.6 |  |  | $ | — |  |  | $ | 23.6 |  |
| Money market funds | 1,000.2 |  |  | — |  |  | — |  |  | 1,000.2 |  |
| U.S. Agency securities | — |  |  | 8.0 |  |  | — |  |  | 8.0 |  |
| U.S. Treasury securities | 22.5 |  |  | — |  |  | — |  |  | 22.5 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | 28.3 |  |  | — |  |  | 28.3 |  |
| Commercial paper | — |  |  | 107.0 |  |  | — |  |  | 107.0 |  |
| Corporate debt securities | — |  |  | 532.5 |  |  | — |  |  | 532.5 |  |
| Municipal bonds | — |  |  | 1.0 |  |  | — |  |  | 1.0 |  |
| U.S. Agency securities | — |  |  | 65.7 |  |  | — |  |  | 65.7 |  |
| U.S. Treasury securities | 524.3 |  |  | — |  |  | — |  |  | 524.3 |  |
| Total assets | $ | 1,547.0 |  |  | $ | 766.1 |  |  | $ | — |  |  | $ | 2,313.1 |  |

[0001628280-22-023617:notes:175]
(1)  Excludes $235.9 million in cash held in our bank accounts as of July 2, 2022.

[0001628280-22-023617:notes:176]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| July 3, 2021: (1) |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | — |  |  | $ | 7.5 |  |  | $ | — |  |  | $ | 7.5 |  |
| Corporate debt securities | — |  |  | 7.0 |  |  | — |  |  | 7.0 |  |
| Money market funds | 631.5 |  |  | — |  |  | — |  |  | 631.5 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | 28.5 |  |  | — |  |  | 28.5 |  |
| Commercial paper | — |  |  | 136.7 |  |  | — |  |  | 136.7 |  |
| Corporate debt securities | — |  |  | 625.9 |  |  | — |  |  | 625.9 |  |
| Municipal bonds | — |  |  | 1.0 |  |  | — |  |  | 1.0 |  |
| U.S. Agency securities | — |  |  | 29.3 |  |  | — |  |  | 29.3 |  |
| U.S. Treasury securities | 350.3 |  |  | — |  |  | — |  |  | 350.3 |  |
| Total assets | $ | 981.8 |  |  | $ | 835.9 |  |  | $ | — |  |  | $ | 1,817.7 |  |

[0001628280-22-023617:notes:177]
(1)  Excludes $128.3 million in cash held in our bank accounts as of July 3, 2021.

[0001628280-22-023617:notes:178]
Financial Instruments Not Recorded at Fair Value on a Recurring Basis

[0001628280-22-023617:notes:179]
We report our financial instruments at fair value with the exception of the 2028 Notes, 2026 Notes, and the 2024 Notes (“Note 11. Debt”). The estimated fair value of the Notes was determined based on the trading price of the notes as of the last day of trading for the period. We consider the fair value of the Notes to be a Level 2 measurement as they are not actively traded in markets.

[0001628280-22-023617:notes:180]
The carrying amounts and estimated fair values of the 2028 Notes, 2026 Notes, and 2024 Notes are as follows for the periods presented (in millions):

[0001628280-22-023617:notes:181]
|  | July 2, 2022 |  | July 3, 2021 |
|  | Carrying Amount |  | Estimated Fair Value |  | Carrying Amount |  | Estimated Fair Value |
| 2024 Notes | $ | 409.9 |  |  | $ | 614.2 |  |  | $ | 390.7 |  |  | $ | 669.3 |  |
| 2026 Notes | 831.4 |  |  | 1,065.0 |  |  | 789.8 |  |  | 1,146.1 |  |
| 2028 Notes | 634.7 |  |  | 735.7 |  |  | N/A |  | N/A |
|  | $ | 1,876.0 |  |  | $ | 2,414.9 |  |  | $ | 1,180.5 |  |  | $ | 1,815.4 |  |

[0001628280-22-023617:notes:182]
We periodically review our intangible and other long-lived assets for impairment whenever events or changes in circumstances indicate that the carrying amount of such assets may not be recoverable. Determination of recoverability is based on the lowest level of identifiable estimated undiscounted cash flows resulting from use of the asset and its eventual disposition. If not recoverable, an impairment loss would be calculated based on the excess of the carrying amount over the fair value.

[0001628280-22-023617:notes:183]
Management utilizes various valuation methods, including an income approach, a market approach and a cost approach, to estimate the fair value of intangibles and other long-lived assets. During the annual impairment testing performed in the fourth quarter of fiscal 2022, we concluded that our intangible and other long-lived assets were not impaired. We review our intangible and other long-lived assets for impairment at least annually in the fourth quarter of each fiscal year, absent any interim indicators of impairment.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001628280-22-023617:notes:184]
Note 8. Balance Sheet Details

[0001628280-22-023617:notes:185]
Allowance for current expected credit losses

[0001628280-22-023617:notes:186]
We did not have any allowance for credit losses other than our allowance for uncollectible accounts receivable. As of July 2, 2022 and July 3, 2021, the allowance for credit losses on our trade receivables was less than $0.1 million and $0.4 million, respectively.

[0001628280-22-023617:notes:187]
Inventories

[0001628280-22-023617:notes:188]
The components of inventories were as follows (in millions):

[0001628280-22-023617:notes:189]
|  | July 2, 2022 |  | July 3, 2021 |
| Raw materials and purchased parts | $ | 98.9 |  |  | $ | 64.4 |  |
| Work in process | 92.2 |  |  | 79.0 |  |
| Finished goods | 59.0 |  |  | 53.0 |  |
| Inventories | $ | 250.1 |  |  | $ | 196.4 |  |

[0001628280-22-023617:notes:190]
Operating lease right-of-use assets, net

[0001628280-22-023617:notes:191]
Operating lease right-of-use assets, net were as follows (in millions):

[0001628280-22-023617:notes:192]
|  | July 2, 2022 |  | July 3, 2021 |
| Operating lease right-of-use assets | $ | 102.1 |  |  | $ | 87.3 |  |
| Less: accumulated amortization | (28.5) |  |  | (19.9) |  |
| Operating lease right-of-use assets, net | $ | 73.6 |  |  | $ | 67.4 |  |

[0001628280-22-023617:notes:193]
Property, plant and equipment, net

[0001628280-22-023617:notes:194]
The components of property, plant and equipment, net were as follows (in millions):

[0001628280-22-023617:notes:195]
|  | July 2, 2022 |  | July 3, 2021 |
| Land | $ | 49.7 |  |  | $ | 38.2 |  |
| Buildings and improvement | 105.3 |  |  | 92.7 |  |
| Machinery and equipment | 548.8 |  |  | 498.3 |  |
| Computer equipment and software | 31.3 |  |  | 28.6 |  |
| Furniture and fixtures | 8.9 |  |  | 8.8 |  |
| Leasehold improvements | 35.7 |  |  | 33.9 |  |
| Finance lease right-of-use assets | — |  |  | 28.1 |  |
| Construction in progress | 47.0 |  |  | 43.4 |  |
|  | 826.7 |  |  | 772.0 |  |
| Less: Accumulated depreciation | (466.2) |  |  | (410.9) |  |
| Property, plant and equipment, net | $ | 360.5 |  |  | $ | 361.1 |  |

[0001628280-22-023617:notes:196]
During fiscal 2022, we purchased land and buildings in Thailand and Slovenia with a fair value of $15.1 million in order to expand our manufacturing capacity. Please refer to Note 19 Operating Segments and Geographic Information for property, plant and equipment by geographic areas based on the physical location of the assets.

[0001628280-22-023617:notes:197]
During fiscal 2021, we sold land and building located in San Jose, California for $23.0 million and recognized a gain of $8.3 million, which was recorded as an offset to selling, general and administrative expenses in our consolidated statement of operations for the year ended July 3, 2021. As part of this transition, in fiscal 2022, we sold equipment that was no longer needed and recognized a gain of $5.9 million, which we recorded as an offset to cost of sales in our consolidated statement of operations for the year ended July 2, 2022.

[0001628280-22-023617:notes:198]
As of July 2, 2022, finance lease assets are fully amortized and there are no outstanding finance lease liabilities.

[0001628280-22-023617:notes:199]
Our construction in progress primarily includes machinery and equipment that we expect to place in service in the next 12 months.

[0001628280-22-023617:notes:200]
During fiscal 2022, 2021 and 2020, we recorded depreciation expense of $81.6 million, $91.4 million, and $113.3 million, respectively.

[0001628280-22-023617:notes:201]
Other current liabilities

[0001628280-22-023617:notes:202]
The components of other current liabilities were as follows (in millions):

[0001628280-22-023617:notes:203]
|  | July 2, 2022 |  | July 3, 2021 |
| Restructuring accrual and related charges (1) | $ | — |  |  | $ | 5.7 |  |
| Warranty accrual (2) | 10.0 |  |  | 5.0 |  |
| Deferred revenue and customer deposits | — |  |  | 0.6 |  |
| Income tax payable (3) | 26.0 |  |  | 43.5 |  |
| Other current liabilities | 3.4 |  |  | 3.0 |  |
| Other current liabilities | $ | 39.4 |  |  | $ | 57.8 |  |

[0001628280-22-023617:notes:204]
(1) Please refer to “Note 13. Restructuring and Related Charges.”

[0001628280-22-023617:notes:205]
(2) Please refer to “Note 18. Commitments and Contingencies.”

[0001628280-22-023617:notes:206]
(3) Please refer to “Note 15. Income Taxes.”

[0001628280-22-023617:notes:207]
Other non-current liabilities

[0001628280-22-023617:notes:208]
The components of other non-current liabilities were as follows (in millions):

[0001628280-22-023617:notes:209]
|  | July 2, 2022 |  | July 3, 2021 |
| Asset retirement obligation | $ | 4.6 |  |  | $ | 4.7 |  |
| Pension and related accrual (1) | 7.7 |  |  | 10.8 |  |
| Unrecognized tax benefit | 30.5 |  |  | 23.0 |  |
| Other non-current liabilities | 0.1 |  |  | 2.4 |  |
| Other non-current liabilities | $ | 42.9 |  |  | $ | 40.9 |  |

[0001628280-22-023617:notes:210]
(1) We have defined benefit pension plans in Japan, Switzerland, and Thailand. As of July 2, 2022, the projected benefit obligations, net of plan assets, in Japan, Switzerland, and Thailand were $2.6 million, $1.7 million, and $3.4 million, respectively. As of July 3, 2021, the projected benefit obligations, net of plan assets, in Japan, Switzerland and Thailand were $2.9 million, $4.8 million and $3.1 million, respectively.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001628280-22-023617:notes:211]
Note 9. Leases

[0001628280-22-023617:notes:212]
We lease certain real and personal property from unrelated third parties under non-cancellable operating leases that expire at various dates through fiscal 2033. These operating leases are mainly for administrative offices, research-and-development and manufacturing facilities, as well as sales offices in various countries around the world. Certain leases require us to pay property taxes, insurance and routine maintenance, and include escalation clauses. Many leases include one or more options to renew. We do not assume renewals in our determination of the lease term unless the renewals are deemed to be reasonably assured at lease commencement.

[0001628280-22-023617:notes:213]
As of July 2, 2022, we sublease a portion of our offices in the United Kingdom, the United States and Canada. These subleases will expire at various dates through fiscal year 2028. We anticipate receiving approximately $2.4 million in sublease income over the next year.

[0001628280-22-023617:notes:214]
The components of lease costs, lease term, and discount rate are as follows (in millions, except for weighted average data):

[0001628280-22-023617:notes:215]
|  | July 2, 2022 |  | July 3, 2021 |  | June 27, 2020 |
| Finance lease cost: |  |  |  |  |  |
| Amortization of right-of-use assets | $ | — |  |  | $ | 0.5 |  |  | $ | 16.3 |  |
| Interest | — |  |  | — |  |  | 0.1 |  |
| Operating lease cost | 13.0 |  |  | 14.1 |  |  | 15.5 |  |
| Short-term and variable lease cost | 2.0 |  |  | 4.3 |  |  | 4.4 |  |
| Sublease income | (3.0) |  |  | (2.8) |  |  | (2.6) |  |
| Total lease cost | $ | 12.0 |  |  | $ | 16.1 |  |  | $ | 33.7 |  |
| Weighted average remaining lease term (in years): |  |  |  |  |  |
| Operating leases | 6.9 |  | 7.5 |  | 8.6 |
| Finance leases | — |  | — |  | 1.0 |
| Weighted average discount rate (in percentages): |  |  |  |  |  |
| Operating leases | 3.0 | % |  | 3.5 | % |  | 3.5 | % |
| Finance leases | — | % |  | — | % |  | 4.4 | % |

[0001628280-22-023617:notes:216]
As of July 2, 2022, finance lease assets are fully amortized and there are no outstanding finance lease liabilities.

[0001628280-22-023617:notes:217]
As of July 2, 2022, maturities of our operating lease liabilities, which do not include short-term leases and variable lease payments, were as follows (in millions):

[0001628280-22-023617:notes:218]
| Fiscal Years |  | Operating Leases (1) |  |  |  |  |
| 2023 |  | $ | 12.9 |  |  |  |  |  |
| 2024 |  | 12.5 |  |  |  |  |  |
| 2025 |  | 9.3 |  |  |  |  |  |
| 2026 |  | 7.9 |  |  |  |  |  |
| 2027 |  | 6.3 |  |  |  |  |  |
| Thereafter |  | 17.6 |  |  |  |  |  |
| Total minimum lease payments |  | $ | 66.5 |  |  |  |  |  |
| Less: amount representing interest |  | (6.5) |  |  |  |  |  |
| Present value of total lease liabilities |  | $ | 60.0 |  |  |  |  |  |

[0001628280-22-023617:notes:219]
(1)  Non-cancellable sublease proceeds for fiscal 2023 of $2.4 million are not included in the table above.


## us-gaap:GoodwillDisclosureTextBlock

[0001628280-22-023617:notes:220]
Note 10. Goodwill and Other Intangible Assets

[0001628280-22-023617:notes:221]
The following table presents our goodwill balance by the reportable segments as of July 2, 2022 and July 3, 2021 (in millions):

[0001628280-22-023617:notes:222]
|  |  | Optical Communications |  | Commercial Lasers |  | Total |
| Balance as of July 2, 2022 and July 3, 2021 | $ | 363.5 |  |  | $ | 5.4 |  |  | $ | 368.9 |  |

[0001628280-22-023617:notes:223]
Impairment of Goodwill

[0001628280-22-023617:notes:224]
We review goodwill for impairment during the fourth quarter of each fiscal year or more frequently if events or circumstances indicate that an impairment loss may have occurred. Based on the impairment analysis performed in the fourth quarter of each year presented, the fair value of each of our reporting units substantially exceeded the carrying value; as such, our annual qualitative assessment did not indicate that a more detailed quantitative analysis was necessary.

[0001628280-22-023617:notes:225]
Other Intangibles

[0001628280-22-023617:notes:226]
The intangible assets are amortized on a straight-line basis over the estimated useful lives, except for customer relationships and order backlog, which are amortized using an accelerated method of amortization over the expected customer lives, which more accurately reflects the pattern of realization of economic benefits expected to be obtained. Acquired developed technologies and order backlog are amortized to cost of sales and customer relationships is amortized to selling, general and administrative.

[0001628280-22-023617:notes:227]
In-process research and development (“IPR&D”) is initially capitalized at fair value as an intangible asset with an indefinite life and assessed for impairment thereafter. When an IPR&D project is completed, the IPR&D is reclassified as an amortizable purchased intangible asset and amortized over the asset’s estimated useful life.

[0001628280-22-023617:notes:228]
The following tables present details of our other intangibles as of the periods presented (in millions, except for weighted average remaining amortization period):

[0001628280-22-023617:notes:229]
| July 2, 2022 | Gross Carrying Amounts |  | Accumulated Amortization |  | Net Carrying Amounts |  | Weighted average remaining amortization period (years) |
| Acquired developed technologies | $ | 390.3 |  |  | $ | (303.6) |  |  | $ | 86.7 |  |  | 2.5 |
| Customer relationships | 145.0 |  |  | (76.0) |  |  | 69.0 |  |  | 4.4 |
| Total intangible assets | $ | 535.3 |  |  | $ | (379.6) |  |  | $ | 155.7 |  |  |  |

[0001628280-22-023617:notes:230]
| July 3, 2021 | Gross Carrying Amounts |  | Accumulated Amortization |  | Net Carrying Amounts |  | Weighted average remaining amortization period (years) |
| Acquired developed technologies | $ | 390.3 |  |  | $ | (238.6) |  |  | $ | 151.7 |  |  | 3.0 |
| Customer relationships | 145.0 |  |  | (55.5) |  |  | 89.5 |  |  | 5.4 |
| Order backlog | 22.0 |  |  | (22.0) |  |  | — |  |  | — |
| Other intangibles | 2.7 |  |  | (2.7) |  |  | — |  |  | — |
| Total intangible assets | $ | 560.0 |  |  | $ | (318.8) |  |  | $ | 241.2 |  |  |  |

[0001628280-22-023617:notes:231]
During the year ended July 3, 2021, we purchased intellectual property from a third party for total consideration of $10.0 million. These intangible assets have an estimated useful life of 5 years.

[0001628280-22-023617:notes:232]
The tables above exclude fully amortized intangibles that were written off against accumulated amortization of $24.7 million and $5.5 million during the years ended July 2, 2022 and July 3, 2021, respectively.

[0001628280-22-023617:notes:233]
During fiscal 2022, 2021 and 2020, we recorded $85.5 million, $85.7 million, and $78.6 million, respectively, of amortization related to intangibles assets.

[0001628280-22-023617:notes:234]
The following table presents details of amortization for the periods presented (in millions):

[0001628280-22-023617:notes:235]
|  | Years ended |
|  | July 2, 2022 |  | July 3, 2021 |  |  |  | June 27, 2020 |
| Cost of sales | $ | 62.9 |  |  | $ | 61.7 |  |  |  |  | $ | 53.8 |  |
| Selling, general and administrative | 22.6 |  |  | 24.0 |  |  |  |  | 24.8 |  |
| Total amortization of intangibles | $ | 85.5 |  |  | $ | 85.7 |  |  |  |  | $ | 78.6 |  |

[0001628280-22-023617:notes:236]
Based on the carrying amount of our acquired developed technologies and other intangibles as of July 2, 2022, and assuming no future impairment of the underlying assets, the estimated future amortization is as follows (in millions):

[0001628280-22-023617:notes:237]
| Fiscal Years |  |
| 2023 | $ | 61.9 |  |
| 2024 | 40.5 |  |
| 2025 | 27.7 |  |
| 2026 | 18.1 |  |
| 2027 | 7.5 |  |
| Total | $ | 155.7 |  |


## us-gaap:DebtDisclosureTextBlock

[0001628280-22-023617:notes:238]
Note 11. Debt

[0001628280-22-023617:notes:239]
Convertible Notes

[0001628280-22-023617:notes:240]
2028 Notes

[0001628280-22-023617:notes:241]
In March 2022, we issued $861.0 million in aggregate principal amount of 2028 Notes in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act of 1933, as amended (the “Securities Act”). The 2028 Notes are governed by an indenture between the Company and U.S. Bank Trust Company National Association (as successor in interest to U.S. Bank National Association), as a trustee (the “2028 Indenture”). The 2028 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001628280-22-023617:notes:242]
The net proceeds from the sale of the 2028 Notes was $854.8 million, after deducting $6.2 million in issuance costs. In addition, we incurred $0.7 million in professional fees in connection with this transaction.  Concurrent with the issuance of the 2028 Notes, we used $200.0 million of the net proceeds to repurchase our common stock in privately negotiated transactions. We intend to use the remaining net proceeds for general corporate purposes, which may include capital expenditures and working capital.

[0001628280-22-023617:notes:243]
The 2028 Notes bear interest at a rate of 0.50% per year, payable semi-annually in arrears on June 15 and December 15 of each year, beginning on June 15, 2022. The 2028 Notes will mature on June 15, 2028, unless earlier redeemed, repurchased by us, or converted pursuant to their terms.

[0001628280-22-023617:notes:244]
The initial conversion rate is 7.6319 shares of common stock per $1,000 principal amount of the 2028 Notes (which is equivalent to an initial conversion price of approximately $131.03 per share). The conversion rate is subject to adjustment upon the occurrence of certain events specified in the 2028 Indenture, but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert the 2028 Notes in connection with such make-whole fundamental change or notice of redemption.

[0001628280-22-023617:notes:245]
Prior to the close of business on the business day immediately preceding March 15, 2028, holders of the 2028 Notes may convert their 2028 Notes only under the following circumstances:

[0001628280-22-023617:notes:246]
•during any fiscal quarter commencing after July 2, 2022 (and only during such fiscal quarter), if the last reported sale price of the common stock for at least 20 trading days (whether or not consecutive) during the 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% if the applicable conversion price, or $170.34 on each applicable trading day;

[0001628280-22-023617:notes:247]
•during the five consecutive business day period after any five consecutive trading day period (the “2028 measurement period”) in which the trading price per $1,000 principal amount of the 2028 Notes for each trading day of the 2028 measurement period was less than 98% of the product of the last reported sale price of the Company’s common stock and the applicable conversion rate on each such trading day;

[0001628280-22-023617:notes:248]
•if we call any or all of the 2028 Notes for redemption, at any time prior to the close of business on the second business day immediately preceding the redemption date; or

[0001628280-22-023617:notes:249]
•upon the occurrence of specified corporate events.

[0001628280-22-023617:notes:250]
On or after March 15, 2028 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their 2028 Notes at any time. Upon conversion, we may satisfy our conversion obligation in cash, shares of common stock or a combination of cash and shares of common stock, at our election.

[0001628280-22-023617:notes:251]
We may redeem for cash all or any of the 2028 Notes, at our option (subject to the partial redemption limitation set forth in the 2028 Indenture), on or after June 20, 2025, if the last reported sale price of its common stock has been at least 130% of the conversion price then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading-day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which we provide notice of redemption at a redemption price equal to 100% of the principal amount of the 2028 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. No sinking fund is provided for the 2028 Notes. If we elect to redeem fewer than all of the outstanding 2028 Notes, at least $100.0 million aggregate principal amount of the 2028 Notes must be outstanding and not subject to redemption as of the redemption notice date.  Upon the occurrence of a fundamental change (as defined in the 2028 Indenture), holders may require us to repurchase all or a portion of their 2028 Notes for cash at a price equal to 100% of the principal amount of the 2028 Notes to be repurchased, plus any accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

[0001628280-22-023617:notes:252]
We bifurcated the principal amount of the 2028 Notes into liability and equity components.  The liability component of the 2028 Notes was valued at $629.8 million based on the contractual cash flow discounted at an appropriate comparable market on non-convertible debt borrowing rate at the date of issuance, which was 5.7%, with the equity component representing the residual amount of the proceeds of $231.2 million, which was recorded as a debt discount. The issuance and other related costs of $6.9 million were allocated pro rata based on the relative carrying amounts of the liability and equity components.

[0001628280-22-023617:notes:253]
The debt discount and debt issuance costs attributable to the liability component will be amortized to interest expense using an effective interest rate of 5.7% over the expected life of the 2028 Notes.  Debt issuance costs attributable to the equity component are netted against the equity component in stockholders’ equity, and the equity component is not remeasured as long as it continues to meet the conditions for equity classification.

[0001628280-22-023617:notes:254]
2026 Notes

[0001628280-22-023617:notes:255]
In December 2019, we issued $1,050.0 million in aggregate principal amount of the 2026 Notes in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act. The 2026 Notes are governed by an indenture between the Company and U.S. Bank Trust Company, National Association (as successor in interest to U.S. Bank National Association), as trustee (the “2026 Indenture”). We used approximately $196.0 million of the net proceeds of the offering to repay in full all amounts outstanding under our term loan facility, and a portion of the net proceeds of the offering to purchase approximately $200.0 million of our common stock concurrently with the pricing of the offering in privately negotiated transactions. The 2026 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, the incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001628280-22-023617:notes:256]
The 2026 Notes bear interest at a rate of 0.50% per year, payable semi-annually in arrears on June 15 and December 15 of each year, beginning on June 15, 2020. The 2026 Notes will mature on December 15, 2026, unless earlier redeemed, repurchased by us, or converted pursuant to their terms.

[0001628280-22-023617:notes:257]
The initial conversion rate is 10.0711 shares of common stock per $1,000 principal amount of the 2026 Notes (which is equivalent to an initial conversion price of approximately $99.29 per share). The conversion rate is subject to adjustment upon the occurrence of certain events specified in the 2026 Indenture, but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares set forth in the 2026 Indenture or a holder that elects to convert the 2026 Notes in connection with such make-whole fundamental change or notice of redemption.

[0001628280-22-023617:notes:258]
Prior to the close of business on the business day immediately preceding September 15, 2026, holders of the 2026 Notes may convert their 2026 Notes only under the following circumstances:

[0001628280-22-023617:notes:259]
•during any fiscal quarter (and only during such fiscal quarter), if the last reported sale price of the common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price of the 2026 Notes, or $129.08 on each applicable trading day;

[0001628280-22-023617:notes:260]
•during the five business day period after any five consecutive trading day period (the "2026 measurement period") in which the trading price per $1,000 principal amount of the 2026 Notes for each trading day of the 2026 measurement period was less than 98% of the product of the last reported sale price of our common stock and the conversion rate for the 2026 Notes on each such trading day;

[0001628280-22-023617:notes:261]
•if we call any or all of the 2026 Notes for redemption, at any time prior to the close of business on the second business day immediately preceding the relevant redemption date; or

[0001628280-22-023617:notes:262]
On or after September 15, 2026 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert the 2026 Notes at any time. Upon conversion, we may satisfy our conversion obligation in cash, shares of common stock or a combination of cash and shares of common stock, at our election.

[0001628280-22-023617:notes:263]
We may redeem for cash, for all or any portion of the 2026 Notes, at our option, on or after December 20, 2023, if the last reported sale price of its common stock has been at least 130% of the conversion price then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading-day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which we provide a notice of redemption at a redemption price equal to 100% of the principal amount of the 2026 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. No sinking fund is provided for the 2026 Notes. Upon the occurrence of a fundamental change (as defined in the 2026 Indenture), holders may require us to repurchase all or a portion of the 2026 Notes for cash at a price equal to 100% of the principal amount of the 2026 Notes to be repurchased, plus any accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

[0001628280-22-023617:notes:264]
In accordance with accounting for debt with conversions and other options, we bifurcated the principal amount of the 2026 Notes into liability and equity components. The liability component of the 2026 Notes was valued at $734.8 million based on the contractual cash flows discounted at an appropriate comparable market non-convertible debt borrowing rate at the date of issuance of 5.8% with the equity component representing the residual amount of the proceeds of $315.2 million, which was recorded as a debt discount.

[0001628280-22-023617:notes:265]
We incurred approximately $7.8 million in transaction costs in connection with the issuance of the 2026 Notes and these costs were allocated pro rata based on the relative carrying amounts of the liability and equity components. The debt discount and debt issuance costs attributable to the liability component will be amortized to interest expense using an effective interest rate of 5.8% over the expected life of the 2026 Notes. Debt issuance costs attributable to the equity component are netted with the equity component in stockholders’ equity, and the equity component is not remeasured as long as it continues to meet the conditions for equity classification.

[0001628280-22-023617:notes:266]
2024 Notes

[0001628280-22-023617:notes:267]
In March 2017, we issued $450.0 million in aggregate principal amount of the 2024 Notes in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act. The 2024 Notes are governed by an indenture between the Company, and U.S. Bank Trust Company National Association (as successor in interest to U.S. Bank National Association), as trustee (the “2024 Indenture”). The 2024 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001628280-22-023617:notes:268]
The 2024 Notes bear interest at a rate of 0.25% per year. Interest on the 2024 Notes is payable semi-annually in arrears on March 15 and September 15 of each year, beginning on September 15, 2017. The 2024 Notes will mature on March 15, 2024, unless earlier repurchased by us or converted pursuant to their terms.

[0001628280-22-023617:notes:269]
The initial conversion rate of the 2024 Notes is 16.4965 shares of common stock per $1,000 principal amount of 2024 Notes, which is equivalent to an initial conversion price of approximately $60.62 per share, a 132.5% premium to the fair market value at the date of issuance. Prior to the close of business on the business day immediately preceding December 15, 2023, each holder of the 2024 Notes may convert their 2024 Notes only under the following circumstances:

[0001628280-22-023617:notes:270]
•during any fiscal quarter (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during the period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price, or $78.80 on each applicable trading day;

[0001628280-22-023617:notes:271]
•during the five consecutive business day period after any five consecutive trading day period (the “2024 measurement period”) in which the trading price per $1,000 principal amount of 2024 Notes for each trading day of such 2024 measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate on each such trading day;

[0001628280-22-023617:notes:272]
On or after December 15, 2023 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their 2024 Notes at any time. In addition, upon the occurrence of a make-whole fundamental

[0001628280-22-023617:notes:273]
change (as defined in the 2024 Indenture), we will, in certain circumstances, increase the conversion rate by a number of additional shares set forth in the 2024 Indenture for a holder that elects to convert 2024 Notes in connection with such make-whole fundamental change.

[0001628280-22-023617:notes:274]
We may not redeem the 2024 Notes prior to their maturity date and no sinking fund is provided for the 2024 Notes. Upon the occurrence of a fundamental change, holders may require us to repurchase all or a portion of their 2024 Notes for cash at a price equal to 100% of the principal amount of the 2024 Notes to be repurchased, plus any accrued and unpaid interest.

[0001628280-22-023617:notes:275]
During the year ended July 2, 2022, we received conversion requests of $1.8 million principal amount of the 2024 Notes, which we settled with a combination of $1.8 million of cash and approximately 9 thousand shares of common stock in accordance with the 2024 Indenture.

[0001628280-22-023617:notes:276]
We considered the features embedded in the 2024 Notes other than the conversion feature, including the holders’ put feature, our call feature, and the make-whole feature, and concluded that they are not required to be bifurcated and accounted for separately from the host debt instrument.

[0001628280-22-023617:notes:277]
Prior to the Tax Matters Agreement settlement condition (“TMA settlement condition”), because we could only settle the 2024 Notes in cash, we determined that the conversion feature met the definition of a derivative liability. We separated the derivative liability from the host debt instrument based on the fair value of the derivative liability. As of the issuance date, March 8, 2017, the derivative liability fair value of $129.9 million was calculated using the binomial valuation approach. The residual principal amount of the 2024 Notes of $320.1 million before issuance costs was allocated to the debt component. We incurred approximately $7.7 million in transaction costs in connection with the issuance of the 2024 Notes. These costs were allocated to the debt component and recognized as a debt discount. We amortize the debt discount, including both the initial value of the derivative liability and the transaction costs, over the term of the 2024 Notes using the effective interest method. The effective interest rate of the 2024 Notes is 5.4% per year.

[0001628280-22-023617:notes:278]
During fiscal 2017, we satisfied the TMA settlement condition. As such, the value of the conversion option is no longer marked-to-market and was reclassified to additional paid-in capital within stockholders’ equity on our consolidated balance sheet. The value of the conversion option at the time of issuance will be treated as an original issue discount for purposes of accounting for the debt component of the 2024 Notes. The debt component will accrete up to the principal amount over the expected term of the debt.

[0001628280-22-023617:notes:279]
Our Notes consisted of the following components as of the periods presented (in millions):

[0001628280-22-023617:notes:280]
| Liability component: | July 2, 2022 |  | July 3, 2021 |
|  | 2024 Notes (1) |  | 2026 Notes (2) |  | 2028 Notes (3) |  | 2024 Notes (1) |  | 2026 Notes (2) |  |  |
| Principal | $ | 448.1 |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |  | $ | 450.0 |  |  | $ | 1,050.0 |  |  |  |
| Unamortized debt discount and debt issuance costs | (38.2) |  |  | (218.6) |  |  | (226.3) |  |  | (59.3) |  |  | (260.2) |  |  |  |
| Net carrying amount of the liability component | $ | 409.9 |  |  | $ | 831.4 |  |  | $ | 634.7 |  |  | $ | 390.7 |  |  | $ | 789.8 |  |  |  |

[0001628280-22-023617:notes:281]
(1) Since the closing price of our stock exceeded $78.80 (or 130% of the conversion price of $60.62) for 20 of the last 30 trading days of the fourth quarters of fiscal 2021 and 2022, the 2024 Notes have become convertible at the option of the holders. Therefore, the debt component of our 2024 Notes as of July 3, 2021 and July 2, 2022 has been classified as current liabilities in our consolidated balance sheets. Principal amount of $448.1 million reflects $1.8 million converted during the fiscal year 2022 and less than $0.1 million converted previously.

[0001628280-22-023617:notes:282]
(2) If the closing price of our stock exceeds $129.08 (or 130% of the conversion price of $99.29 for 20 of the last 30 trading days of any future quarter, our 2026 Notes would also become convertible at the option of the holders and the debt component would be reclassified to current liabilities in our consolidated balance sheets.

[0001628280-22-023617:notes:283]
(3) During any fiscal quarter commencing after July 2, 2022, if the closing price of our stock exceeds $170.34 (or 130% of the conversion price of $131.03) for 20 of the last 30 trading days of such quarter, our 2028 Notes would become convertible at the option of the holders and the debt component would be reclassified to current liabilities in our condensed consolidated balance sheet.

[0001628280-22-023617:notes:284]
The following table sets forth interest expense information related to the Notes for the periods presented (in millions):

[0001628280-22-023617:notes:285]
|  |  |  |  |  | July 2, 2022 |  | July 3, 2021 |  | June 27, 2020 |
| Contractual interest expense |  |  |  |  | $ | 7.8 |  |  | $ | 6.5 |  |  | $ | 3.9 |  |
| Amortization of the debt discount and debt issuance costs |  |  |  |  | 72.4 |  |  | 60.2 |  |  | 39.1 |  |
| Total interest expense |  |  |  |  | $ | 80.2 |  |  | $ | 66.7 |  |  | $ | 43.0 |  |

[0001628280-22-023617:notes:286]
The future interest and principal payments related to our Notes are as follows as of July 2, 2022 (in millions):

[0001628280-22-023617:notes:287]
| Fiscal Years | 2024 Notes |  | 2026 Notes |  | 2028 Notes |  | Total |
| 2023 | $ | 1.1 |  |  | $ | 5.3 |  |  | $ | 4.3 |  |  | $ | 10.7 |  |
| 2024 | 449.4 |  |  | 5.3 |  |  | 4.3 |  | 459.0 |  |
| 2025 | — |  |  | 5.3 |  |  | 4.3 |  | 9.6 |  |
| 2026 | — |  |  | 5.3 |  |  | 4.3 |  | 9.6 |  |
| 2027 | — |  |  | 1,052.4 |  |  | 869.6 |  | 1,922.0 |  |
| Total Notes payments | $ | 450.5 |  |  | $ | 1,073.6 |  |  | $ | 886.8 |  |  | $ | 2,410.9 |  |

[0001628280-22-023617:notes:288]
The principal balances of our Notes are reflected in the payment periods in the table above based on their respective contractual maturities.

[0001628280-22-023617:notes:289]
Term Loan Facility

[0001628280-22-023617:notes:290]
In December 2018, concurrent with the closing of the Oclaro merger, we entered into a credit agreement providing for a term loan facility (the “Term Loan Facility”) in an aggregate principal amount of $500.0 million. and we drew in full the term loans available under the Term Loan Facility on the closing date of the Oclaro merger. In fiscal 2020, we repaid, in full, all amounts outstanding under our Term Loan Facility. During the year ended June 27, 2020, we incurred $18.1 million of interest expense on this Term Loan Facility, which includes an $8.0 million loss on the early extinguishment of debt.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001628280-22-023617:notes:291]
Note 12. Accumulated Other Comprehensive Income

[0001628280-22-023617:notes:292]
Our accumulated other comprehensive income consists of the accumulated net unrealized gains or losses on foreign currency translation adjustments, defined benefit obligations, and available-for-sale securities.

[0001628280-22-023617:notes:293]
The changes in accumulated other comprehensive income, net of tax were as follows for the periods as presented (in millions):

[0001628280-22-023617:notes:294]
|  | Foreign currency translation adjustments, net of tax (1) |  | Defined benefit obligations, net of tax (2) |  | Unrealized gain (loss) on available-for-sale securities, net of tax (3) |  | Total |
| Ending balance as of June 29, 2019 | $ | 9.7 |  |  | $ | (3.5) |  |  | $ | 0.9 |  |  | $ | 7.1 |  |
| Other comprehensive income (loss) | — |  |  | (0.7) |  |  | 1.5 |  |  | 0.8 |  |
| Ending balance as of June 27, 2020 | 9.7 |  |  | (4.2) |  |  | 2.4 |  |  | 7.9 |  |
| Other comprehensive income (loss) | — |  |  | 2.8 |  |  | (2.5) |  |  | 0.3 |  |
| Ending balance as of July 3, 2021 | 9.7 |  |  | (1.4) |  |  | (0.1) |  |  | 8.2 |  |
| Other comprehensive income (loss) | — |  |  | 2.4 |  |  | (10.2) |  |  | (7.8) |  |
| Ending balance as of July 2, 2022 | $ | 9.7 |  |  | $ | 1.0 |  |  | $ | (10.3) |  |  | $ | 0.4 |  |

[0001628280-22-023617:notes:295]
(1) In fiscal 2019, as a result of significant changes in economic facts and circumstances, primarily due to the acquisition of Oclaro, we established the functional currency for our worldwide operations as the U.S. dollar. Translation adjustments reported prior to fiscal 2019, remain as a component of accumulated other comprehensive income in our consolidated balance sheets, until all or a part of the investment in the subsidiaries is sold or liquidated.
(2) We evaluate the assumptions over the fair value of our defined benefit obligations annually and make changes as necessary.  During each of fiscal 2022, 2021 and 2020, our income (loss) on defined benefit obligations is presented net of tax of $1.5 million, nil, and $0.2 million, respectively.(3) In fiscal 2022, 2021 and 2020, our unrealized gain (loss) on available-for-sale securities is presented net of tax of $2.8 million, $(0.5) million and $0.3 million, respectively.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001628280-22-023617:notes:296]
Note 13. Restructuring and Related Charges

[0001628280-22-023617:notes:297]
We have initiated various strategic restructuring actions primarily intended to reduce costs, consolidate our operations, rationalize the manufacturing of our products and align our business in response to market conditions.

[0001628280-22-023617:notes:298]
The following table summarizes the activity of restructuring and related charges during the periods presented (in millions):

[0001628280-22-023617:notes:299]
|  | Years Ended |  |  |
|  | July 2, 2022 |  | July 3, 2021 |  |  |  | June 27, 2020 |  |  |
| Balance as of beginning of period | $ | 5.7 |  |  | $ | 5.2 |  |  |  |  | $ | 14.6 |  |  |  |
| Charges (benefits) | (1.1) |  |  | 7.7 |  |  |  |  | 8.0 |  |  |  |
| Payments | (4.6) |  |  | (7.2) |  |  |  |  | (17.4) |  |  |  |
| Balance as of end of period | $ | — |  |  | $ | 5.7 |  |  |  |  | $ | 5.2 |  |  |  |

[0001628280-22-023617:notes:300]
During fiscal 2022, we recorded a net reversal to our restructuring and related charges of $1.1 million in our consolidated statements of operations, which was primarily attributable to lower than anticipated employee severance charges due to retaining and re-assigning certain employees.

[0001628280-22-023617:notes:301]
During fiscal 2021, we recorded restructuring and related charges of $7.7 million in our consolidated statements of operations. The charges were mainly attributable to severance charges associated with the decision to cease manufacturing of certain products in San Jose, California, as well as other cost reduction measures taken across the Company impacting all regions.

[0001628280-22-023617:notes:302]
During fiscal 2020, we recorded $8.0 million in restructuring and related charges in our consolidated statements of operations. The charges were primarily attributable to severance charges associated with the decision to move certain manufacturing from San Jose, California to our facility in Thailand and other third-party vendors.

[0001628280-22-023617:notes:303]
Any changes in the estimates of executing our restructuring activities will be reflected in our future results of operations.


## us-gaap:AssetImpairmentChargesTextBlock

[0001628280-22-023617:notes:304]
Note 14. Impairment and Other Charges

[0001628280-22-023617:notes:305]
Impairment Charges Associated with Exist of Product Lines

[0001628280-22-023617:notes:306]
The following table summarizes the activity of impairment charges during the periods presented (in millions):

[0001628280-22-023617:notes:307]
|  |  | Years Ended |
|  |  |  |  | July 2, 2022 |  | July 3, 2021 |  | June 27, 2020 |
| Impairment charges |  |  |  | $ | — |  |  | $ | — |  |  | $ | 4.3 |  |

[0001628280-22-023617:notes:308]
In fiscal 2019, we announced our plan to discontinue the development and manufacturing of Datacom transceiver modules which impacted the California and China-based Datacom module teams. As a result of these actions, we recorded impairment charges of $4.3 million in fiscal 2020 related to our long-lived assets that were not deemed to be useful.

[0001628280-22-023617:notes:309]
In fiscal 2020, we also recorded inventory and fixed asset write-down charges of $7.0 million, related to the decision to exit the Datacom module and Lithium Niobate product lines in our cost of goods sold in our consolidated statements of operations. Please refer to “Note 5. Sale of Assets and Dispositions” for details on the exit from these product lines.

[0001628280-22-023617:notes:310]
These actions do not qualify as discontinued operations for disclosure purposes as they do not represent a strategic shift having a major effect on an entity’s operations and financial results.

[0001628280-22-023617:notes:311]
Other Losses on Property, Plant and Equipment

[0001628280-22-023617:notes:312]
We record fixed assets losses, mainly attributable to the retirement and disposal of fixed assets, net of proceeds received, and not associated with the exit from product lines. The impact of such losses on our results of operations by function during the periods presented was as follows (in millions):

[0001628280-22-023617:notes:313]
|  | Years Ended |
|  | July 2, 2022 |  | July 3, 2021 |  |  |  |  | June 27, 2020 |
| Cost of sales (1) | $ | 2.5 |  |  | $ | 9.3 |  |  |  |  |  | $ | 16.1 |  |
| Research and development | 0.4 |  |  | 0.3 |  |  |  |  |  | 0.8 |  |
| Selling, general and administrative (2) | 0.1 |  |  | (7.2) |  |  |  |  |  | 0.6 |  |
|  | $ | 3.0 |  |  | $ | 2.4 |  |  |  |  |  | $ | 17.5 |  |

[0001628280-22-023617:notes:314]
(1) In fiscal 2021, we made a decision to cease manufacturing of certain products at a manufacturing facility that we owned in San Jose, California.  As part of this transition, in fiscal 2022, we sold equipment that was no longer needed and recognized a gain of $5.9 million, which was recorded as an offset to cost of sales in our consolidated statement of operations for the year ended July 2, 2022.

[0001628280-22-023617:notes:315]
(2) In fiscal year 2021, we made a decision to cease manufacturing of certain products at a manufacturing facility that we owned in San Jose, California. During the fourth quarter of fiscal 2021, we shut down the manufacturing site and sold the related land and building for $23.0 million and recognized a gain of $8.3 million, which was recorded as an offset to operating expenses.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-22-023617:notes:316]
Note 15. Income Taxes

[0001628280-22-023617:notes:317]
Our income before income taxes consisted of the following (in millions):

[0001628280-22-023617:notes:318]
|  | Years Ended |
|  | July 2, 2022 |  | July 3, 2021 |  | June 27, 2020 |
| Domestic | $ | 77.5 |  |  | $ | 314.9 |  |  | $ | (33.1) |  |
| Foreign | 157.6 |  |  | 148.2 |  |  | 207.4 |  |
| Income before income taxes | $ | 235.1 |  |  | $ | 463.1 |  |  | $ | 174.3 |  |

[0001628280-22-023617:notes:319]
Our income tax provision consisted of the following (in millions):

[0001628280-22-023617:notes:320]
|  | Years Ended |
|  | July 2, 2022 |  | July 3, 2021 |  | June 27, 2020 |
| Federal: |  |  |  |  |  |
| Current | $ | 13.7 |  |  | $ | 30.5 |  |  | $ | 2.9 |  |
| Deferred | 1.0 |  |  | 9.2 |  |  | 19.3 |  |
|  | 14.7 |  |  | 39.7 |  |  | 22.2 |  |
| State: |  |  |  |  |  |
| Current | (0.1) |  |  | 1.7 |  |  | 0.1 |  |
| Deferred | 0.3 |  |  | (0.3) |  |  | (0.4) |  |
|  | 0.2 |  |  | 1.4 |  |  | (0.3) |  |
| Foreign: |  |  |  |  |  |
| Current | 46.8 |  |  | 36.5 |  |  | 23.4 |  |
| Deferred | (25.5) |  |  | (11.8) |  |  | (6.5) |  |
|  | 21.3 |  |  | 24.7 |  |  | 16.9 |  |
| Total income tax provision | $ | 36.2 |  |  | $ | 65.8 |  |  | $ | 38.8 |  |

[0001628280-22-023617:notes:321]
The provision for income taxes differs from the amount computed by applying the U.S. Federal statutory income tax rate to our income before provision for income taxes as follows (in millions):

[0001628280-22-023617:notes:322]
|  | Years Ended |
|  | July 2, 2022 |  | July 3, 2021 |  | June 27, 2020 |
| Income tax provision computed at federal statutory rate | $ | 49.4 |  |  | $ | 97.3 |  |  | $ | 36.6 |  |
| Foreign rate differential | (50.4) |  |  | (50.4) |  |  | (24.6) |  |
| Change in valuation allowance | 10.5 |  |  | 45.4 |  |  | 13.4 |  |
| Tax credits | (23.1) |  |  | (31.8) |  |  | (10.2) |  |
| Stock-based compensation | 9.6 |  |  | 5.6 |  |  | 4.8 |  |
| Subpart F and GILTI | 28.2 |  |  | 42.1 |  |  | 22.9 |  |
| Unrecognized tax benefits | 4.1 |  |  | (3.7) |  |  | (1.7) |  |
| Change in Non-US Statutory Tax Rates | (1.2) |  |  | (35.8) |  |  | (2.8) |  |
| Base Erosion Anti-Abuse Tax (BEAT) | 8.0 |  |  | — |  |  | 2.8 |  |
| Other | 1.1 |  |  | (2.9) |  |  | (2.4) |  |
| Total income tax provision | $ | 36.2 |  |  | $ | 65.8 |  |  | $ | 38.8 |  |
| Effective tax rate | 15.40 | % |  | 14.22 | % |  | 22.26 | % |

[0001628280-22-023617:notes:323]
Our provision for income taxes for fiscal 2022 differs from the 21% U.S. statutory rate primarily due to the income tax benefit from earnings of our foreign subsidiaries being taxed at rates that differ from the U.S. statutory rate, offset by the tax expense from U.S. income inclusions from Subpart F and GILTI. Additionally, our provision for income taxes includes an income tax benefit from various tax credits and non-U.S. statutory rate changes enacted during the year, offset by an income tax expense from non-deductible stock-based compensation as well as change in valuation allowance because it is not more-likely-than-not that certain deferred tax assets will be realizable in the future.

[0001628280-22-023617:notes:324]
Our provision for income taxes for fiscal 2021 differs from the 21% U.S. statutory rate primarily due to the income tax benefit from earnings of our foreign subsidiaries being taxed at rates that differ from the U.S. statutory rate, which is offset by the tax expense from U.S. income inclusions from Subpart F and GILTI. Further our provision for income taxes includes an income tax benefit from various tax credits and non-U.S. statutory rate changes enacted during the year, offset by an income tax expense from non-deductible stock-based compensation as well as change in valuation allowance because it is not more-likely-than-not that certain deferred tax assets will be realizable in the future.

[0001628280-22-023617:notes:325]
Our provision for income taxes for fiscal 2020 differs from the 21% U.S. statutory rate primarily due to the income tax benefit of the earnings of our foreign subsidiaries being taxed at rates that differ from the U.S. statutory rate and certain tax credits, which is offset by the tax expense from U.S. income inclusions from Subpart F and GILTI.  Further our provision for income taxes includes an income tax expense from changes in our valuation allowance because it is not more-likely-than-not that certain deferred tax assets will be realized in the future.

[0001628280-22-023617:notes:326]
The components of our net deferred taxes consisted of the following (in millions):

[0001628280-22-023617:notes:327]
|  | Years Ended |
|  | July 2, 2022 |  | July 3, 2021 |  |  |
| Gross deferred tax assets: |  |  |  |  |  |
| Intangibles | $ | 81.2 |  |  | $ | 92.0 |  |  |  |
| Tax credit carryforwards | 75.3 |  |  | 75.3 |  |  |  |
| Net operating loss carryforwards | 151.0 |  |  | 172.7 |  |  |  |
| Inventories | 6.3 |  |  | 6.8 |  |  |  |
| Accruals and reserves | 14.2 |  |  | 10.6 |  |  |  |
| Fixed assets | 25.5 |  |  | 23.9 |  |  |  |
| Capital loss carryforwards | 12.0 |  |  | 12.6 |  |  |  |
| Unclaimed research and experimental development expenditure | 40.5 |  |  | 42.1 |  |  |  |
| Stock-based compensation | 5.6 |  |  | 5.1 |  |  |  |
| Lease liabilities | 15.9 |  |  | 16.3 |  |  |  |
| Other | 4.7 |  |  | 0.3 |  |  |  |
| Gross deferred tax assets | 432.2 |  |  | 457.7 |  |  |  |
| Valuation allowance | (263.2) |  |  | (272.4) |  |  |  |
| Deferred tax assets | 169.0 |  |  | 185.3 |  |  |  |
| Gross deferred tax liabilities: |  |  |  |  |  |
| Intangible amortization | (33.7) |  |  | (59.6) |  |  |  |
| Convertible notes | (100.6) |  |  | (68.0) |  |  |  |
| Right-of-use assets | (18.2) |  |  | (19.6) |  |  |  |
| Other | (2.4) |  |  | (1.1) |  |  |  |
| Deferred tax liabilities | (154.9) |  |  | (148.3) |  |  |  |
| Total net deferred tax assets | $ | 14.1 |  |  | $ | 37.0 |  |  |  |

[0001628280-22-023617:notes:328]
We assess our ability to realize the deferred tax assets on a quarterly basis and establish a valuation allowance if the deferred tax assets are not more-likely-than-not to be realized. We weigh all available positive and negative evidence, including our earnings history and results of recent operations, reversals of deferred tax liabilities, projected future taxable income, and tax planning strategies. In fiscal 2022, after considering both positive and negative evidence, we have determined that we will be able to realize all of our deferred tax assets in Thailand and have therefore reversed the related valuation allowance. We continue to maintain our valuation allowance on our California, Canada, and UK deferred tax assets, and a partial valuation allowance on our federal deferred tax asset related to foreign tax credits. In the event the Company determines that it will be able to realize all or part of the deferred tax assets in the future, the valuation allowance will be reversed in the period in which the Company makes such determination. Based on the information currently available, we do not believe that a significant portion of our valuation allowance for the U.S., California, Canada, and UK will be released in the next 12 months. Such a release would result in the recognition of certain deferred tax assets and a decrease in the income tax expense for the period in which the release is recorded.

[0001628280-22-023617:notes:329]
As of July 2, 2022, the Company had federal and foreign net operating loss carryforwards of $88.9 million and $497.3 million, respectively. These carryforwards will begin to expire in the fiscal year ending 2027. The federal and foreign tax attributes carried forward are subject to various rules which impose limitations on the utilization.

[0001628280-22-023617:notes:330]
Additionally, the Company has federal, state, and foreign research and other tax credit carryforwards of $5.7 million, $51.4 million, and $43.5 million, respectively. The federal credits will begin to expire in the fiscal year ending 2033 and California credits can be carried forward indefinitely. The foreign tax credits will begin to expire in the fiscal year ending 2023.

[0001628280-22-023617:notes:331]
Current U.S. tax law generally provides greater flexibility for us to access and utilize our cash held by certain of our foreign subsidiaries and we intend to repatriate all or some of the earnings of our subsidiaries in the Cayman Islands, Japan, and Hong Kong. As to all other foreign subsidiaries, we intend to reinvest these earnings indefinitely in our foreign subsidiaries. As a result, U.S. income and foreign withholding taxes associated with the repatriation of $27.0 million of earnings from our foreign subsidiaries, other than the Cayman Islands, Japan, and Hong Kong subsidiaries, have not been provided for. We estimate that an additional $1.5 million of foreign withholding taxes would have to be provided if these earnings were repatriated back to the U.S. and such withholding taxes may be available as foreign tax credit or deduction to reduce U.S. tax liability.

[0001628280-22-023617:notes:332]
The aggregate changes in the balance of our unrecognized tax benefits between July 3, 2021 and July 2, 2022 are as follows (in millions):

[0001628280-22-023617:notes:333]
| Balance at June 29, 2019 | $ | 58.0 |  |
| Decreases based on the tax positions related to the prior year | (8.2) |  |
| Decreases related to settlement with Tax Authorities | (2.0) |  |
| Additions based on tax positions related to current year | 7.7 |  |
| Balance at June 27, 2020 | $ | 55.5 |  |
| Increases based on tax positions related to prior year | 6.8 |  |
| Decreases based on tax positions related to prior year | (1.6) |  |
| Decreases related to Statute of Limitations | (5.1) |  |
| Additions based on tax positions related to current year | 6.5 |  |
| Balance at July 3, 2021 | $ | 62.1 |  |
| Increases based on tax positions related to prior year | 5.2 |  |
| Decreases based on tax positions related to prior year | (2.1) |  |
| Decreases related to Statute of Limitations | (9.8) |  |
| Additions based on tax positions related to current year | 6.5 |  |
| Decreases related to audit settlements | (0.2) |  |
| Balance at July 2, 2022 | $ | 61.7 |  |

[0001628280-22-023617:notes:334]
As of July 2, 2022, we had $30.5 million of unrecognized tax benefits, which, if recognized, would affect the effective tax rate. We are subject to examination of income tax returns by various domestic and foreign tax authorities. The timing of resolutions and closures of tax audits is highly unpredictable. Although it is possible that certain tax audits may be concluded within the next 12 months, we cannot reasonably estimate the impact to tax expense and net income from tax exams that could be resolved or closed within next 12 months. However, we believe that we have adequately provided under GAAP for potential audit outcomes. Subject to audit timing and uncertainty, we expect none of unrecognized tax benefit that would become recognized due to expiration of the statute of limitations and affect the effective tax rate over the next 12 months.

[0001628280-22-023617:notes:335]
The Company has obtained the tax holiday related to certain business activities but to date, has not met the requirements to obtain the benefits of the tax holiday. Accordingly, the earned income is subject to normal Thailand statutory tax rates.

[0001628280-22-023617:notes:336]
Our policy is to recognize accrued interest and penalties related to unrecognized tax benefits within the income tax provision. The amount of interest and penalties accrued as of July 2, 2022 and July 3, 2021 were $1.6 million and $1.4 million, respectively.

[0001628280-22-023617:notes:337]
The major tax jurisdictions where we file tax returns are the U.S. federal government, the state of California, Japan, the United Kingdom, Thailand, China and Canada. As of July 2, 2022, our fiscal 2011 to 2021 tax returns are open to potential examination in one or more jurisdictions. In addition, certain net operating loss and credit carryforwards may extend the ability of the tax authorities to examine our tax returns beyond the regular limits.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001628280-22-023617:notes:338]
Note 16. Equity

[0001628280-22-023617:notes:339]
Description of Lumentum Stock-Based Benefit Plans

[0001628280-22-023617:notes:340]
Equity Incentive Plan

[0001628280-22-023617:notes:341]
On November 19, 2021, our stockholders approved amendments to the Amended and Restated 2015 Equity Incentive Plan (the “2015 Plan”) to (i) increase the number of shares reserved for issuance under the 2015 Plan by an additional 3.0 million shares and (ii) make certain other changes to reflect changes in the law and/or good corporate governance practices.

[0001628280-22-023617:notes:342]
As of July 2, 2022, we had 2.4 million shares subject to restricted stock units, restricted stock awards and performance stock units issued and outstanding under the 2015 Equity Incentive Plan (the “2015 Plan”).

[0001628280-22-023617:notes:343]
Restricted stock units, restricted stock awards, and performance stock units are performance-based, time-based or a combination of both and are expected to vest over one to four years. The fair value of these grants is based on the closing market price of our common stock on the date of grant.

[0001628280-22-023617:notes:344]
As of July 2, 2022, 3.8 million shares of common stock under the 2015 Plan were available for grant.

[0001628280-22-023617:notes:345]
Restricted Stock Units

[0001628280-22-023617:notes:346]
Restricted stock units (“RSUs”) under the 2015 Plan are grants of shares of our common stock, the vesting of which is based on the requisite service requirement. Generally, our RSUs are subject to forfeiture and are expected to vest over one to four years. For annual refresh grants, RSUs generally vest ratably on an annual, or combination of annual and quarterly, basis over three years.

[0001628280-22-023617:notes:347]
During fiscal 2022, our board of directors approved grants of 1.5 million shares which primarily vest over three years.

[0001628280-22-023617:notes:348]
Performance Stock Units

[0001628280-22-023617:notes:349]
Performance stock units (“PSUs”) under the 2015 Plan are grants of shares of our common stock that vest upon the achievement of certain performance and service conditions. We begin recognizing compensation expense when we conclude that it is probable that the performance conditions will be achieved. We reassess the probability of vesting at each reporting period and adjust our compensation cost based on this probability assessment. Our PSUs are subject to risk of forfeiture until performance and service conditions are satisfied and generally vest over three years.

[0001628280-22-023617:notes:350]
During fiscal 2022, our board of directors approved a grant of 0.2 million PSUs with an aggregate grant date fair value of $16.7 million to certain executive officers and senior management. These PSUs will vest subject to the achievement of 3-year revenue targets and certain non-financial performance measurement, as well as service conditions.

[0001628280-22-023617:notes:351]
Employee Stock Purchase Plan

[0001628280-22-023617:notes:352]
Our 2015 Employee Stock Purchase Plan (the “2015 Purchase Plan”) provides eligible employees with the opportunity to acquire an ownership interest in the Company through periodic payroll deductions and provides a 15% purchase price discount as well as a 6-month look-back period. The 2015 Purchase Plan is structured as a qualified employee stock purchase plan under Section 423 of the Internal Revenue Code of 1986, as amended. The 2015 Purchase Plan will terminate upon the date on which all shares available for issuance have been sold. Of the 3.0 million shares authorized under the 2015 Purchase Plan, 1.4 million shares remained available for issuance as of July 2, 2022.

[0001628280-22-023617:notes:353]
Stock-Based Compensation

[0001628280-22-023617:notes:354]
The impact on our results of operations of recording stock-based compensation by function during the periods presented was as follows (in millions):

[0001628280-22-023617:notes:355]
|  | Years Ended |
|  | July 2, 2022 |  | July 3, 2021 |  |  |  |  | June 27, 2020 |
| Cost of sales | $ | 20.8 |  |  | $ | 19.2 |  |  |  |  |  | $ | 16.1 |  |
| Research and development | 22.1 |  |  | 19.5 |  |  |  |  |  | 15.9 |  |
| Selling, general and administrative | 60.2 |  |  | 54.2 |  |  |  |  |  | 41.2 |  |
| Total stock-based compensation | $ | 103.1 |  |  | $ | 92.9 |  |  |  |  |  | $ | 73.2 |  |

[0001628280-22-023617:notes:356]
Stock-based compensation for fiscal 2022, 2021 and 2020 includes $16.8 million, $16.8 million and $9.4 million, respectively, of stock-based compensation costs related to PSUs. The amount of stock-based compensation expense recognized in any one period related to PSUs can vary based on the achievement or anticipated achievement of the performance conditions. If the performance conditions are not met or not expected to be met, no compensation cost would be recognized on the underlying PSUs, and any previously recognized compensation expense related to those PSUs would be reversed.

[0001628280-22-023617:notes:357]
Total income tax benefit associated with stock-based compensation recognized in our consolidated statements of operations during the years presented was as follows (in millions):

[0001628280-22-023617:notes:358]
|  | Years Ended |
|  | July 2, 2022 |  | July 3, 2021 |  |  |  |  | June 27, 2020 |
| Income tax benefit associated with stock-based compensation | $ | 12.5 |  |  | $ | 14.6 |  |  |  |  |  | $ | 10.6 |  |

[0001628280-22-023617:notes:359]
Approximately $6.4 million and $4.6 million of stock-based compensation was capitalized to inventory as of July 2, 2022 and July 3, 2021, respectively.

[0001628280-22-023617:notes:360]
As of July 2, 2022, $133.0 million of stock-based compensation cost related to RSU awards granted to our employees remains to be amortized. This cost is expected to be recognized over an estimated amortization period of 1.9 years.

[0001628280-22-023617:notes:361]
Stock Award Activity

[0001628280-22-023617:notes:362]
The following table summarizes our awards activity in fiscal 2022, 2021 and 2020 (in millions, except per share amounts):

[0001628280-22-023617:notes:363]
|  |  |  |  |  |  |  | Restricted Stock Units |  | Restricted Stock Awards |  | Performance Stock Units |
|  |  |  |  |  |  |  |  |  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |
| Balance as of June 29, 2019 |  |  |  |  |  |  |  |  | 2.2 |  |  | $ | 52.4 |  |  | — |  |  | $ | 32.5 |  |  | 0.2 |  |  | $ | 56.0 |  |
| Granted |  |  |  |  |  |  |  |  | 1.1 |  |  | 60.3 |  |  | — |  |  | — |  |  | 0.2 |  |  | 61.9 |  |
| Vested/Exercised |  |  |  |  |  |  |  |  | (1.2) |  |  | 52.1 |  |  | — |  |  | 32.4 |  |  | (0.1) |  |  | 54.7 |  |
| Canceled |  |  |  |  |  |  |  |  | (0.2) |  |  | 52.3 |  |  | — |  |  | — |  |  | — |  |  | 57.3 |  |
| Balance as of June 27, 2020 |  |  |  |  |  |  |  |  | 1.9 |  |  | $ | 56.6 |  |  | — |  |  | $ | — |  |  | 0.3 |  |  | $ | 60.6 |  |
| Granted |  |  |  |  |  |  |  |  | 1.2 |  |  | 86.6 |  |  | — |  |  | — |  |  | 0.2 |  |  | 86.7 |  |
| Vested/Exercised |  |  |  |  |  |  |  |  | (1.1) |  |  | 56.5 |  |  | — |  |  | — |  |  | (0.2) |  |  | 57.8 |  |
| Canceled |  |  |  |  |  |  |  |  | (0.2) |  |  | 67.1 |  |  | — |  |  | — |  |  | — |  |  | 70.0 |  |
| Balance as of July 3, 2021 |  |  |  |  |  |  |  |  | 1.8 |  |  | $ | 76.0 |  |  | — |  |  | $ | — |  |  | 0.3 |  |  | $ | 75.7 |  |
| Granted |  |  |  |  |  |  |  |  | 1.5 |  |  | 87.8 |  |  | — |  |  | — |  |  | 0.2 |  |  | 85.7 |  |
| Vested/Exercised |  |  |  |  |  |  |  |  | (1.1) |  |  | 73.4 |  |  | — |  |  | — |  |  | (0.2) |  |  | 76.1 |  |
| Canceled |  |  |  |  |  |  |  |  | (0.2) |  |  | 79.9 |  |  | — |  |  | — |  |  | — |  |  | 58.7 |  |
| Balance as of July 2, 2022 |  |  |  |  |  |  |  |  | 2.0 |  |  | $ | 85.9 |  |  | — |  |  | $ | — |  |  | 0.3 |  |  | $ | 81.9 |  |

[0001628280-22-023617:notes:364]
A summary of awards available for grant for fiscal 2022, 2021 and 2020 is as follows (in millions):

[0001628280-22-023617:notes:365]
|  | Awards Available for Grant |
| Balance as of June 29, 2019 | 4.7 |  |
| Granted | (1.3) |  |
| Canceled | 0.1 |  |
| Balance as of June 27, 2020 | 3.5 |  |
| Granted | (1.4) |  |
| Canceled | 0.2 |  |
| Balance as of July 3, 2021 | 2.3 |  |
| Authorized | 3.0 |  |
| Granted | (1.7) |  |
| Canceled | 0.2 |  |
| Balance as of July 2, 2022 | 3.8 |  |

[0001628280-22-023617:notes:366]
Employee Stock Purchase Plan Activity

[0001628280-22-023617:notes:367]
The 2015 Purchase Plan expense for fiscal 2022, 2021 and 2020 was $4.6 million, $4.6 million, and $3.5 million, respectively. The expense related to the 2015 Purchase Plan is recorded on a straight-line basis over the relevant subscription period. There were 0.2 million, 0.2 million, and 0.2 million shares issued to employees through the 2015 Purchase Plan during fiscal 2022, 2021 and 2020, respectively.

[0001628280-22-023617:notes:368]
We estimate the fair value of the 2015 Purchase Plan shares on the date of grant using the Black-Scholes option-pricing model. The assumptions used to estimate the fair value of the 2015 Purchase Plan shares during the periods presented were as follows:

[0001628280-22-023617:notes:369]
|  | July 2, 2022 |  | July 3, 2021 |
| Expected term (years) | 0.5 |  | 0.5 |
| Expected volatility | 45.4 | % |  | 46.6 | % |
| Risk-free interest rate | 1.49 | % |  | 0.07 | % |
| Dividend yield | — | % |  | — | % |

[0001628280-22-023617:notes:370]
Repurchase and Retirement of Common Stock

[0001628280-22-023617:notes:371]
Repurchase Made in Connection with Convertible Note Offering

[0001628280-22-023617:notes:372]
In fiscal 2022, concurrent with the issuance of the 2028 Notes, we repurchased 2.0 million shares of our common stock in privately negotiated transactions at an average price of $99.0 per share for an aggregate purchase price of $200.0 million. We recorded the $200.0 million aggregate purchase price as a reduction of retained earnings within our consolidated balance sheet.  These shares were retired immediately.

[0001628280-22-023617:notes:373]
In fiscal 2020, concurrent with the issuance of the 2026 Notes, we repurchased 2.9 million shares of our common stock in privately negotiated transactions at an average price of $69.68 per share for an aggregate purchase price of $200.0 million. These shares were retired immediately.

[0001628280-22-023617:notes:374]
Share Buyback Program

[0001628280-22-023617:notes:375]
On May 7, 2021, our board of directors approved the 2021 share buyback program, which authorizes us to use up to $700.0 million to purchase our own shares of common stock. The buyback program was authorized for 2 years. On March 3, 2022, our board of directors approved an increase in our share buyback program, which authorizes us to use up to an aggregate amount of $1.0 billion (an increase from $700.0 million) to purchase our own shares of common stock through May 2024, but may be suspended or terminated by the board of directors at any time.

[0001628280-22-023617:notes:376]
During fiscal 2022, we repurchased 4.0 million shares of our common stock as part of the share buyback program at an average price of $87.21 per share for an aggregate purchase price of $348.9 million. During fiscal 2021, we repurchased 3.1 million shares of our common stock at an average price of $77.84 per share for an aggregate purchase price of $241.0 million. Since the share buyback program was approved by the board of directors, we have repurchased 7.1 million shares in aggregate at an average price of $83.12 per share for a total purchase price of $589.8 million. We recorded the $589.8 million aggregate purchase price as a reduction of retained earnings within our consolidated balance sheets. All repurchased shares were retired immediately.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001628280-22-023617:notes:377]
Note 17. Employee Retirement Plans

[0001628280-22-023617:notes:378]
Defined Contribution Plans

[0001628280-22-023617:notes:379]
In the United States, the Company sponsors the Lumentum 401(k) Retirement Plan (the “401(k) Plan”), a defined contribution plan under the Employee Retirement Income Security Act of 1974 (“ERISA”), which provides retirement benefits for its eligible employees through tax deferred salary deductions. The 401(k) Plan allows employees to contribute up to 50% of their annual compensation, with contributions limited to $20,500 (or $27,000 for employees over 50 years of age) in calendar year 2022 as set by the Internal Revenue Service. Employees are eligible for matching contributions after completing 180 days of service. The Company’s match is contributed on a per-pay-period basis and is based on employees’ before-tax contributions and compensation each pay period. All matching contributions are made in cash and vest immediately under the 401(k) Plan. In fiscal 2022, 2021 and 2020, our contribution expense to the 401(k) Plan was $3.7 million, $3.5 million, and $3.8 million, respectively.

[0001628280-22-023617:notes:380]
We also have defined contribution plans in most of the other countries in which we operate, either as required by statutory law or as provided by the Company’s supplemental offering. Our contribution expense to all defined contribution plans outside the United States were $7.7 million, $8.3 million, and $6.7 million for fiscal 2022, 2021 and 2020, respectively.

[0001628280-22-023617:notes:381]
Defined Benefit Plans

[0001628280-22-023617:notes:382]
The Company sponsors defined benefit pension plans covering employees in Japan, Switzerland and Thailand. Pension plan benefits are based primarily on participants’ compensation and years of service credited as specified under the terms of each country’s plan. Employees are entitled to a lump sum benefit upon retirement or upon certain instances of termination.  The funding policy is consistent with the local requirements of each country.

[0001628280-22-023617:notes:383]
We account for our defined benefit obligations in accordance with the authoritative guidance which requires us to record our obligation to the participants, as well as the corresponding net periodic cost. We determine our obligation to the participants and our net periodic cost principally using actuarial valuations provided by third-party actuaries. As of July 2, 2022, our projected benefit obligations, net, in Japan, Switzerland and Thailand were $2.6 million, $1.7 million and $3.4 million, respectively. They were recorded in our consolidated balance sheets as other non-current liabilities and represent the total projected benefit obligation (“PBO”) less the fair value of plan assets.

[0001628280-22-023617:notes:384]
As of July 2, 2022, the defined benefit plan in Switzerland was partially funded, while the defined benefit plans in Japan and Thailand were unfunded.

[0001628280-22-023617:notes:385]
The change in the benefit obligations of pension plans in Japan, Switzerland, and Thailand, and the change in plan assets in Switzerland were as follows (in millions):

[0001628280-22-023617:notes:386]
|  | July 2, 2022 |  | July 3, 2021 |
| Change in projected benefit obligation: |  |  |  |
| Benefit obligation at beginning of year | $ | 20.6 |  |  | $ | 20.9 |  |
| Service cost | 1.8 |  |  | 2.0 |  |
| Interest cost | 0.1 |  |  | 0.1 |  |
| Plan participants’ contributions | 0.5 |  |  | 0.5 |  |
| Actuarial gains (1) | (3.9) |  |  | (1.2) |  |
| Benefits paid | (0.2) |  |  | (1.7) |  |
| Plan amendments | (0.2) |  |  | — |  |
| Foreign exchange impact | (1.2) |  |  | — |  |
| Benefit obligation at end of year | $ | 17.5 |  |  | $ | 20.6 |  |
| Change in plan assets: |  |  |  |
| Fair value of plan assets at beginning of year | $ | 9.8 |  |  | $ | 9.1 |  |
| Actual return on plan assets | (0.2) |  |  | 1.2 |  |
| Employer contribution | 0.6 |  |  | 0.5 |  |
| Plan participants’ contribution | 0.5 |  |  | 0.5 |  |
| Benefits paid | (0.2) |  |  | (1.5) |  |
| Foreign exchange impact | (0.7) |  |  | — |  |
| Fair value of plan assets at end of year | $ | 9.8 |  |  | $ | 9.8 |  |
| Funded status (2) | $ | (7.7) |  |  | $ | (10.8) |  |
| Changes in benefit obligations and plan assets recognized in other comprehensive income: |  |  |  |
| Prior service cost | $ | (0.1) |  |  | $ | 0.1 |  |
| Amortization of accumulated net actuarial loss | (0.1) |  |  | (0.4) |  |
| Net actuarial gain | (3.6) |  |  | (2.2) |  |
| Loss recognized due to settlement | — |  |  | (0.3) |  |
|  | $ | (3.8) |  |  | $ | (2.8) |  |
| Accumulated benefit obligation | $ | 14.0 |  |  | $ | 16.5 |  |

[0001628280-22-023617:notes:387]
(1) Actuarial gains are primarily driven by changes in discount rates.

[0001628280-22-023617:notes:388]
(2) As of July 2, 2022 and July 3, 2021, $7.7 million and $10.8 million were recorded in other non-current liabilities on our consolidated balance sheets, respectively, to account for the PBO. Please refer to “Note 8. Balance Sheet Details”.

[0001628280-22-023617:notes:389]
Net periodic pension costs in Japan, Switzerland and Thailand include the following components for the periods presented (in millions):

[0001628280-22-023617:notes:390]
|  | Years Ended |  |  |  |
|  | July 2, 2022 |  | July 3, 2021 |  | June 27, 2020 |  |  |  |
| Service cost | $ | 1.8 |  |  | $ | 2.0 |  |  | $ | 3.5 |  |  |  |  |
| Interest cost | 0.1 |  |  | 0.1 |  |  | 0.2 |  |  |  |  |
| Amortization of prior service cost | (0.1) |  |  | (0.1) |  |  | — |  |  |  |  |
| Expected return on plan assets | (0.2) |  |  | (0.3) |  |  | (0.3) |  |  |  |  |
| Amortization of net loss | 0.2 |  |  | 0.3 |  |  | 0.3 |  |  |  |  |
| Settlement losses | — |  |  | 0.3 |  |  | — |  |  |  |  |
| Net periodic pension cost | $ | 1.8 |  |  | $ | 2.3 |  |  | $ | 3.7 |  |  |  |  |

[0001628280-22-023617:notes:391]
Assumptions

[0001628280-22-023617:notes:392]
Underlying both the calculation of the PBO and net periodic cost are actuarial valuations. These valuations use participant-specific information such as salary, age and assumptions about interest rates, compensation increases and other factors. At a minimum, we evaluate these assumptions annually and make changes as necessary.

[0001628280-22-023617:notes:393]
The discount rate reflects the estimated rate at which the pension benefits could be effectively settled. In developing the discount rate, we consider the yield available on an appropriate AA or AAA corporate bond index, adjusted to reflect the term of the plan’s liabilities.

[0001628280-22-023617:notes:394]
The expected return on assets was estimated by using the weighted average of the real expected long-term return (net of inflation) on the relevant classes of assets based on the target asset mix and adding the chosen inflation assumption.

[0001628280-22-023617:notes:395]
The following table summarizes the weighted-average assumptions used to determine net periodic cost and benefit obligation for our defined benefit plans in Japan, Switzerland and Thailand:

[0001628280-22-023617:notes:396]
|  | Years Ended |
|  | July 2, 2022 |  | July 3, 2021 |
| Assumptions used to determine net periodic cost: |  |  |  |
| Discount rate | 1.1 | % |  | 0.6 | % |
| Expected long-term return on plan assets | 2.0 | % |  | 2.7 | % |
| Salary increase rate | 3.7 | % |  | 3.4 | % |
| Assumptions used to determine benefit obligation at end of year: |  |  |  |
| Discount rate | 1.9 | % |  | 0.7 | % |
| Salary increase rate | 3.1 | % |  | 2.9 | % |

[0001628280-22-023617:notes:397]
Fair Value Measurement of Plan Assets

[0001628280-22-023617:notes:398]
The following table sets forth the plan assets of our defined benefit plan in Switzerland at fair value and the percentage of assets allocations as of July 2, 2022 and July 3, 2021 (in millions, except percentage data):

[0001628280-22-023617:notes:399]
|  |  |  |  |  |  | Fair Value Measurement as of July 2, 2022 |
|  | Target Allocation | Total |  | Percentage of Plan Asset |  | Quoted Prices in Active Markets for Identical Assets(Level 1) |  | Significant Other Observable Inputs (Level 2) |
| Assets: |  |  |  |  |  |  |  |  |  |
| Global equity | 33 | % |  | $ | 3.2 |  |  | 33 | % |  | $ | — |  |  | $ | 3.2 |  |
| Fixed income | 32 | % |  | 3.1 |  |  | 30 | % |  | — |  |  | 3.1 |  |
| Alternative investment | 12 | % |  | 1.2 |  |  | 13 | % |  | — |  |  | 1.2 |  |
| Cash | 1 | % |  | 0.1 |  |  | 1 | % |  | 0.1 |  |  | — |  |
| Other assets | 22 | % |  | 2.2 |  |  | 23 | % |  | — |  |  | 2.2 |  |
| Total Assets | 100 | % |  | $ | 9.8 |  |  | 100 | % |  | $ | 0.1 |  |  | $ | 9.7 |  |

[0001628280-22-023617:notes:400]
|  |  |  |  |  |  | Fair Value Measurement as of July 3, 2021 |
|  | Target Allocation | Total |  | Percentage of Plan Asset |  | Quoted Prices in Active Markets for Identical Assets(Level 1) |  | Significant Other Observable Inputs (Level 2) |
| Assets: |  |  |  |  |  |  |  |  |  |
| Global equity | 31 | % |  | $ | 3.0 |  |  | 30 | % |  | $ | — |  |  | $ | 3.0 |  |
| Fixed income | 31 | % |  | 3.0 |  |  | 29 | % |  | — |  |  | 3.0 |  |
| Alternative investment | 15 | % |  | 1.5 |  |  | 18 | % |  | — |  |  | 1.5 |  |
| Cash | 1 | % |  | 0.1 |  |  | 1 | % |  | 0.1 |  |  | — |  |
| Other assets | 22 | % |  | 2.2 |  |  | 22 | % |  | — |  |  | 2.2 |  |
| Total Assets | 100 | % |  | $ | 9.8 |  |  | 100 | % |  | $ | 0.1 |  |  | $ | 9.7 |  |

[0001628280-22-023617:notes:401]
Our pension assets consist of multiple institutional funds (“pension funds”) of which the fair values are based on the quoted prices of the underlying funds. Pension funds are classified as Level 2 assets since such funds are not directly traded in active markets. Global equity consists of several funds that invest primarily in Swiss and foreign equities; fixed income consists of several funds that invest primarily in investment grade domestic and overseas bonds; other assets consist of several funds that primarily invest in hedge fund, private equity, global real estate and infrastructure funds.

[0001628280-22-023617:notes:402]
Future Benefit Payments

[0001628280-22-023617:notes:403]
We estimate our expected benefit payments to participants in the defined benefit pension plans based on the same assumptions used to measure our PBO at year-end which includes benefits attributable to estimated future compensation increases.

[0001628280-22-023617:notes:404]
The following benefit payments are estimated to be paid from our defined benefit pension plans (in millions):

[0001628280-22-023617:notes:405]
| Fiscal Years |  | Total |
| 2023 |  | $ | 1.5 |  |
| 2024 |  | 0.8 |  |
| 2025 |  | 1.2 |  |
| 2026 |  | 1.0 |  |
| 2027 |  | 1.1 |  |
| Next five years |  | 8.8 |  |
| Total expected benefit payments |  | 14.4 |  |

[0001628280-22-023617:notes:406]
We expect to contribute $1.4 million to our defined benefit pension plans in fiscal 2023.


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0001628280-22-023617:notes:407]
Note 18. Commitments and Contingencies

[0001628280-22-023617:notes:408]
Purchase Obligations

[0001628280-22-023617:notes:409]
Purchase obligations of $403.7 million as of July 2, 2022, represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements.

[0001628280-22-023617:notes:410]
Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule and adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

[0001628280-22-023617:notes:411]
We depend on a limited number of contract manufacturers, subcontractors and suppliers for raw materials, packages and standard components. We generally purchase these single or limited source products through standard purchase orders or one-year supply agreements and have no significant long-term guaranteed supply agreements with such vendors. While we seek to maintain a sufficient safety stock of such products and maintain on-going communications with our suppliers to guard against interruptions or cessation of supply, our business and results of operations could be adversely affected by a stoppage or delay of supply, substitution of more expensive or less reliable products, receipt of defective parts or contaminated materials, increases in the price of such supplies, or our inability to obtain reduced pricing from our suppliers in response to competitive pressures.

[0001628280-22-023617:notes:412]
Product Warranties

[0001628280-22-023617:notes:413]
We provide reserves for the estimated costs of product warranties at the time revenue is recognized. We typically offer a twelve month warranty for most of our products. However, in some instances depending upon the product, product components or application of our products by the end customer, our warranties can vary and generally range from six months to five years. We estimate the costs of our warranty obligations on an annualized basis based on our historical experience of known product failure rates, use of materials to repair or replace defective products and service delivery costs incurred in correcting product failures. In addition, from time to time, specific warranty accruals may be made if unforeseen technical problems arise with specific products. We assess the adequacy of our recorded warranty liabilities and adjust the amounts as necessary.

[0001628280-22-023617:notes:414]
The following table presents the changes in our warranty reserve during the periods presented (in millions):

[0001628280-22-023617:notes:415]
|  | Years Ended |
|  | July 2, 2022 |  | July 3, 2021 |  |  |  |  |
| Balance as of beginning of period | $ | 5.0 |  |  | $ | 5.0 |  |  |  |  |  |
| Provision for warranty | 9.4 |  |  | 7.1 |  |  |  |  |  |
| Utilization of reserve | (4.4) |  |  | (7.1) |  |  |  |  |  |
| Balance as of end of period | $ | 10.0 |  |  | $ | 5.0 |  |  |  |  |  |

[0001628280-22-023617:notes:416]
Environmental Liabilities

[0001628280-22-023617:notes:417]
Our research and development (“R&D”), manufacturing and distribution operations involve the use of hazardous substances and are regulated under international, federal, state and local laws governing health and safety and the environment. We apply strict standards for protection of the environment and occupational health and safety to sites inside and outside the United States, even if not subject to regulations imposed by foreign governments. We believe that our properties and operations at our facilities comply in all material respects with applicable environmental laws and occupational health and safety laws. However, the risk of environmental liabilities cannot be completely eliminated and there can be no assurance that the application of environmental and health and safety laws will not require us to incur significant expenditures. We are also regulated under a number of international, federal, state and local laws regarding recycling, product packaging and product content requirements. The environmental, product content/disposal and recycling laws are gradually becoming more stringent and may cause us to incur significant expenditures in the future.

[0001628280-22-023617:notes:418]
Legal Proceedings

[0001628280-22-023617:notes:419]
We are subject to a variety of claims and suits that arise from time to time in the ordinary course of our business. While management currently believes that resolving claims against us, individually or in the aggregate, will not have a material adverse impact on our financial position, results of operations or statements of cash flows, these matters are subject to inherent uncertainties and management’s view of these matters may change in the future. We accrue for loss contingencies when it is both probable that we will incur the loss and when we can reasonably estimate the amount of the loss or range of loss.

[0001628280-22-023617:notes:420]
Oclaro Merger Litigation

[0001628280-22-023617:notes:421]
In connection with our acquisition of Oclaro, seven lawsuits were filed by purported stockholders of Oclaro challenging the merger (the “Oclaro Merger”). Two of the seven suits were putative class actions filed against Oclaro, its directors, Lumentum, Prota Merger Sub, Inc. and Prota Merger, LLC: Nicholas Neinast v. Oclaro, Inc., et al., No. 3:18-cv-03112-VC, in the United States District Court for the Northern District of California (filed May 24, 2018) (the “Neinast Lawsuit”); and Adam Franchi v. Oclaro, Inc., et al., No. 1:18-cv-00817-GMS, in the United States District Court for the District of Delaware (filed June 9, 2018) (the “Franchi Lawsuit”). Both the Neinstat Lawsuit and the Franchi Lawsuit were voluntarily dismissed with prejudice.

[0001628280-22-023617:notes:422]
The other five suits, styled as Gerald F. Wordehoff v. Oclaro, Inc., et al., No. 5:18-cv-03148-NC (the “Wordehoff Lawsuit”), Walter Ryan v. Oclaro, Inc., et al., No. 3:18-cv-03174-VC (the “Ryan Lawsuit”), Jayme Walker v. Oclaro, Inc., et al., No. 5:18-cv-03203-EJD (the “Walker Lawsuit”), Kevin Garcia v. Oclaro, Inc., et al., No. 5:18-cv-03262-VKD (the “Garcia Lawsuit”), and SaiSravan B. Karri v. Oclaro, Inc., et al., No. 3:18-cv-03435-JD (the “Karri Lawsuit” and, together with the other six lawsuits, the “Oclaro Lawsuits”), were filed in the United States District Court for the Northern District of California on May 25, 2018, May 29, 2018, May 30, 2018, May 31, 2018, and June 9, 2018, respectively. These five Oclaro Lawsuits named Oclaro and its directors as defendants, but did not name Lumentum. The Wordehoff, Ryan, Walker, and Garcia Lawsuits have been voluntarily dismissed, and the Wordehoff, Ryan, and Walker dismissals were with prejudice. The Karri Lawsuit has not yet been dismissed. The Ryan Lawsuit was, and the Karri Lawsuit is, a putative class action.

[0001628280-22-023617:notes:423]
The Oclaro Lawsuits generally alleged, among other things, that Oclaro and its directors violated Section 14(a) of the Securities Exchange Act of 1934, as amended (the “Exchange Act”), and Rule 14a-9 promulgated thereunder by disseminating an incomplete and misleading Form S-4, including proxy statement/prospectus. The Lawsuits further alleged that Oclaro’s directors violated Section 20(a) of the Exchange Act by failing to exercise proper control over the person(s) who violated Section 14(a) of the Exchange Act.

[0001628280-22-023617:notes:424]
The remaining Oclaro Lawsuit (the Karri Lawsuit) currently purports to seek, among other things, damages to be awarded to the plaintiff and any class, if a class is certified, and litigation costs, including attorneys’ fees.  Karri has been appointed as  lead plaintiff and his counsel as lead counsel, and a first amended complaint (“FAC”) was filed on April 15, 2019, which also named Lumentum as a defendant. A motion to dismiss the FAC was granted in part and denied in part by the court on October 8, 2020. On December 1, 2020, defendants answered the FAC. On December 23, 2020, defendants filed a motion for leave to file a motion for reconsideration of the Court’s October 8th order on the motion to dismiss, which was denied on January 29, 2021. On June 22, 2021, the Court granted the parties’ stipulation to dismiss Lumentum as a defendant from the action.  On September 17, 2021, lead plaintiff filed a second amended complaint (“SAC”). Defendants moved to stay discovery in light of the SAC, and on January 11, 2022 the Court struck the SAC as untimely, terminated defendants’ motions to dismiss as moot, and lifted the stay.  The Karri Lawsuit remains pending. The parties have completed fact discovery. Expert discovery is ongoing.  Defendants intend to defend the Karri Lawsuit vigorously.

[0001628280-22-023617:notes:425]
NeoPhotonics Merger Litigation

[0001628280-22-023617:notes:426]
In connection with our acquisition of NeoPhotonics Corporation (“NeoPhotonics”) announced in November 2021, ten lawsuits (the “NeoPhotonics Lawsuits”) were filed by purported stockholders of NeoPhotonics challenging the merger (the “NeoPhotonics Merger”).  Four of the NeoPhotonics Lawsuits, styled as Elaine Wang v. NeoPhotonics Corporation, et al., No. 1:21-cv-10338, Heather Smith v. NeoPhotonics Corporation, et al., No. 1:21-cv-10698, Matthew Hopkins v. NeoPhotonics Corporation, et al., No. 1:21-cv-10725, and John Ryan v. NeoPhotonics Corporation, et al., No. 1:22-cv-00046, were filed in the United States District Court for the Southern District of New York on December 3, 2021, December 14, 2021, December 15, 2021, and January 4, 2022, respectively.  Three of the NeoPhotonics Lawsuits, styled as Mengsheng Ku v. NeoPhotonics Corporation, et al., No. 5:21-cv-09479, Stephen Bushansky v. NeoPhotonics Corporation, et al., No. 5:21-cv-09825, and James Parshall v. NeoPhotonics Corporation, et al., No. 5:22-cv-00055, were filed in the United States District Court for the Northern District of New York on December 8, 2021, December 20, 2021, and January 5, 2022, respectively. One NeoPhotonics Lawsuit, styled as James Hendrickson v. NeoPhotonics Corporation, et al., No. 1:21-cv-06919, was filed in the United States District Court for the Eastern District of New York on December 15, 2021. One NeoPhotonics Lawsuit, styled as Alex Ciccotelli v. NeoPhotonics Corporation, et al., No. 2:21-cv-05611, was filed in the United States District Court for the Eastern District of Pennsylvania on December 23, 2021. One NeoPhotonics Lawsuit, styled as Christopher Taylor v. NeoPhotonics Corporation, et al., No. 1:22-cv-00002, was filed in the United States District Court for the District of Delaware on January 3, 2022.

[0001628280-22-023617:notes:427]
These ten NeoPhotonics Lawsuits name NeoPhotonics and its directors as defendants and do not name Lumentum.

[0001628280-22-023617:notes:428]
The NeoPhotonics Lawsuits generally allege, among other things, that NeoPhotonics and its directors violated Section 14(a) of the Exchange Act, Rule 14a-9 promulgated thereunder, and 17 C.F.R. § 244.100 by disseminating an incomplete and misleading Preliminary Proxy Statement on Schedule 14A, filed with the SEC on December 1, 2021 regarding the NeoPhotonics Merger. The NeoPhotonics Lawsuits further allege that NeoPhotonics’ directors violated Section 20(a) of the Exchange Act by failing to exercise proper control over the person(s) who violated Section 14(a) of the Exchange Act. The complaints seek injunctive relief, rescission or rescissory damages, dissemination of a proxy statement that discloses certain information requested by the plaintiffs, and an award of plaintiffs’ costs, including attorneys’ fees and expenses.

[0001628280-22-023617:notes:429]
Indemnifications

[0001628280-22-023617:notes:430]
In the normal course of business, we enter into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown because claims may be made against us in the future and we may record charges in the future as a result of these indemnification obligations. As of July 2, 2022, we did not have any material indemnification claims that were probable or reasonably possible.

[0001628280-22-023617:notes:431]
Audit Proceedings

[0001628280-22-023617:notes:432]
We are under audit by various domestic and foreign tax authorities with regards to income tax and indirect tax matters. In some, although not all cases, we have reserved for potential adjustments to our provision for income taxes and accrual of indirect taxes that may result from examinations by these tax authorities or final outcomes in judicial proceedings, and we believe that the final outcome of these examinations, agreements or judicial proceedings will not have a material effect on our results of operations. If events occur which indicate payment of these amounts is unnecessary, the reversal of the liabilities would result in the recognition of benefits in the period we determine the liabilities are no longer necessary. If our estimates of the federal, state, and foreign income tax liabilities and indirect tax liabilities are less than the ultimate assessment, it  result in a further charge to expense.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001628280-22-023617:notes:433]
Note 19. Operating Segments and Geographic Information

[0001628280-22-023617:notes:434]
Our chief executive officer is our Chief Operating Decision Maker (“CODM”). The CODM allocates resources to the segments based on their business prospects, competitive factors, net revenue and gross margin. We do not track all of our property, plant and equipment by operating segments. The geographic identification of these assets is set forth below.

[0001628280-22-023617:notes:435]
We are an industry leading provider of optical and photonic products defined by revenue and market share addressing a range of end-market applications including optical communications and commercial lasers. We have two operating segments, Optical Communications, which we refer to as OpComms, and Commercial Lasers, which we refer to as Lasers. Our OpComms products address the following markets: telecommunications and data communications (“Telecom and Datacom”), and consumer and industrial (“Consumer and Industrial”). The two operating segments were primarily determined based on how the CODM views and evaluates our operations. The CODM regularly reviews operating results to make decisions about resources to be allocated to the segments and to assess their performance. Other factors, including market separation and customer specific applications, go-to-market channels, products and manufacturing, are considered in determining the formation of these operating segments.

[0001628280-22-023617:notes:436]
OpComms

[0001628280-22-023617:notes:437]
Our OpComms products include a wide range of components, modules and subsystems to support customers including carrier networks for access (local), metro (intracity), long-haul (city-to-city and worldwide) and submarine (undersea) applications. Additionally, our products address enterprise, cloud, and data center applications, including storage-access networks (“SANs”), local-area networks (“LANs”) and wide-area networks (“WANs”). These products enable the transmission and transport of video, audio and data over high-capacity fiber-optic cables. We maintain leading positions in these fast growing OpComms markets through our extensive product portfolio, including reconfigurable optical add/drop multiplexers (“ROADMs”), coherent dense wavelength division multiplexing (“DWDM”) pluggable transceivers, and tunable small form-factor pluggable transceivers. We also sell laser chips for use in manufacturing of high-speed Datacom transceivers.

[0001628280-22-023617:notes:438]
In the Consumer and Industrial market, our OpComms diode laser products include vertical cavity surface emitting lasers (“VCSELs”) and edge emitting lasers. In the Consumer end-market, our laser light sources are integrated into 3D sensing cameras which are used in applications in mobile devices, gaming, payment kiosks, computers, and other consumer electronics devices. Applications include biometric identification, computational photography, virtual and augmented reality, and natural user interfaces. Emerging applications for our lasers include automotive safety systems, LiDAR for advanced driver assistance systems in automobiles and autonomous vehicles, self-navigating robotics and drones in industrial applications, and 3D capture of objects coupled with 3D imaging or printing. In the industrial end-market, our diode lasers are used primarily as pump sources for pulsed and kilowatt class fiber lasers.

[0001628280-22-023617:notes:439]
Lasers

[0001628280-22-023617:notes:440]
Our Lasers products serve our customers in markets and applications such as sheet metal processing, general manufacturing, biotechnology, graphics and imaging, remote sensing, and precision machining such as drilling in printed circuit boards, wafer singulation, glass cutting and solar cell scribing.

[0001628280-22-023617:notes:441]
Our Lasers products are used in a variety of OEM applications including diode-pumped solid-state, fiber, diode, direct-diode and gas lasers such as argon-ion and helium-neon lasers. Fiber lasers provide kW-class output powers combined with excellent beam quality and are used in sheet metal processing and metal welding applications. Diode-pumped solid-state lasers provide excellent beam quality, low noise and exceptional reliability and are used in biotechnology, graphics and imaging, remote sensing, materials processing and precision machining applications. Diode and direct-diode lasers address a wide variety of applications, including laser pumping, thermal exposure, illumination, ophthalmology, image recording, printing, plastic welding and selective soldering. Gas lasers such as argon-ion and helium-neon lasers provide a stable, low-cost and reliable solution over a wide range of operating conditions, making them well-suited for complex, high-resolution OEM applications such as flow cytometry, DNA sequencing, graphics and imaging and semiconductor inspection.

[0001628280-22-023617:notes:442]
We also provide high-powered and ultrafast lasers for the industrial and scientific markets. Manufacturers use high-power, ultrafast lasers to create micro parts for consumer electronics and to process semiconductor, LED, and other types of chips. Use of ultrafast lasers for micromachining applications is being driven primarily by the increasing use of consumer electronics and connected devices globally.

[0001628280-22-023617:notes:443]
We do not allocate research and development, sales and marketing, or general and administrative expenses to our segments because management does not include the information in its measurement of the performance of the operating segments. In addition, we do not allocate amortization and impairment of acquisition-related intangible assets, stock-based compensation and certain other charges impacting the gross margin of each segment because management does not include this information in its measurement of the performance of the operating segments.

[0001628280-22-023617:notes:444]
Information on reportable segments utilized by our CODM is as follows (in millions):

[0001628280-22-023617:notes:445]
|  |  |  | Years Ended |
|  |  |  |  |  | July 2, 2022 |  | July 3, 2021 |  | June 27, 2020 |
| Net revenue: |  |  |  |  |  |  |  |  |  |
| OpComms |  |  |  |  | $ | 1,518.5 |  |  | $ | 1,620.7 |  |  | $ | 1,515.1 |  |
| Lasers |  |  |  |  | 194.1 |  |  | 122.1 |  |  | 163.5 |  |
| Net revenue |  |  |  |  | $ | 1,712.6 |  |  | $ | 1,742.8 |  |  | $ | 1,678.6 |  |
| Gross profit: |  |  |  |  |  |  |  |  |  |
| OpComms |  |  |  |  | $ | 780.9 |  |  | $ | 830.2 |  |  | $ | 704.0 |  |
| Lasers |  |  |  |  | 102.1 |  |  | 57.3 |  |  | 76.2 |  |
| Total segment gross profit |  |  |  |  | 883.0 |  |  | 887.5 |  |  | 780.2 |  |
| Unallocated corporate items: |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  |  |  | (20.8) |  |  | (19.2) |  |  | (16.1) |  |
| Amortization of acquired intangibles |  |  |  |  | (62.9) |  |  | (61.7) |  |  | (53.8) |  |
| Amortization of inventory fair value adjustments |  |  |  |  | — |  |  | — |  |  | (5.8) |  |
| Inventory and fixed asset write down due to product line exits (1) |  |  |  |  | (0.1) |  |  | (0.4) |  |  | (7.0) |  |
| Integration related costs |  |  |  |  | — |  |  | — |  |  | (4.9) |  |
| Other (charges) gains (2) |  |  |  |  | (10.6) |  |  | (23.1) |  |  | (42.4) |  |
| Gross profit |  |  |  |  | $ | 788.6 |  |  | $ | 783.1 |  |  | $ | 650.2 |  |

[0001628280-22-023617:notes:446]
(1) In fiscal 2022, 2021 and 2020, we recorded inventory and fixed assets write down charges of $0.1 million, $0.4 million  and $7.0 million, respectively, related to the decision to exit the Datacom module and Lithium Niobate product lines.

[0001628280-22-023617:notes:447]
(2) Other (charges) gains of unallocated corporate items in fiscal 2022 primarily relate to $14.0 million of charges to acquire components from various brokers to satisfy customer demand, offset by a $5.9 million gain from selling equipment that was no longer needed after we transferred certain product lines to new production facilities in fiscal 2021.

[0001628280-22-023617:notes:448]
Other (charges) gains of unallocated corporate items for fiscal 2021 relate to costs of transferring product lines to new production facilities, including Thailand, of $6.9 million, excess and obsolete inventory charges of $7.7 million driven by U.S. trade restrictions and the related decline in demand from Huawei, and fixed asset write-off of $5.0 million associated with excess capacity related to our Fiber laser business.

[0001628280-22-023617:notes:449]
Other (charges) gains of unallocated corporate items for fiscal 2020 primarily include costs of transferring product lines to new production facilities, including Thailand of  $11.5 million, excess and obsolete inventory charges of $12.8 million driven by U.S. trade restrictions and the related decline in demand from Huawei, and  fixed asset write-off of $6.2 million associated with excess capacity related to our Fiber laser business.

[0001628280-22-023617:notes:450]
We operate in three geographic regions: Americas, Asia-Pacific, and EMEA (Europe, Middle East, and Africa). Net revenue is assigned to the geographic region and country where our product is initially shipped. For example, certain customers may request shipment of our product to a contract manufacturer in one country, which may differ from the location of their end customers. The following table presents net revenue by the three geographic regions we operate in and net revenue from countries that represented 10% or more of our total net revenue (in millions, except percentage data):

[0001628280-22-023617:notes:451]
|  |  |  | Years Ended |  |
|  |  |  |  |  | July 2, 2022 |  | July 3, 2021 |  | June 27, 2020 |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  |  |  |  |  |  |  |  | $ | 173.9 |  |  | 10.2 | % |  | $ | 133.4 |  |  | 7.7 | % |  | $ | 149.8 |  |  | 8.9 | % |  |
| Other Americas |  |  |  |  |  |  |  |  | 173.0 |  |  | 10.1 |  |  | 146.9 |  |  | 8.4 |  |  | 128.3 |  |  | 7.6 |  |  |
| Total Americas |  |  |  |  |  |  |  |  | $ | 346.9 |  |  | 20.3 | % |  | $ | 280.3 |  |  | 16.1 | % |  | $ | 278.1 |  |  | 16.5 | % |  |
| Asia-Pacific: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Hong Kong |  |  |  |  |  |  |  |  | $ | 458.2 |  |  | 26.7 | % |  | $ | 546.3 |  |  | 31.3 | % |  | $ | 532.0 |  |  | 31.8 | % |  |
| South Korea |  |  |  |  |  |  |  |  | 265.2 |  |  | 15.5 |  |  | 240.0 |  |  | 13.8 |  |  | 260.9 |  |  | 15.5 |  |  |
| Japan |  |  |  |  |  |  |  |  | 181.2 |  |  | 10.6 |  |  | 114.7 |  |  | 6.6 |  |  | 137.9 |  |  | 8.2 |  |  |
| Other Asia-Pacific |  |  |  |  |  |  |  |  | 344.7 |  |  | 20.1 |  |  | 421.3 |  |  | 24.2 |  |  | 346.0 |  |  | 20.6 |  |  |
| Total Asia-Pacific |  |  |  |  |  |  |  |  | $ | 1,249.3 |  |  | 72.9 | % |  | $ | 1,322.3 |  |  | 75.9 | % |  | $ | 1,276.8 |  |  | 76.1 | % |  |
| EMEA |  |  |  |  |  |  |  |  | $ | 116.4 |  |  | 6.8 | % |  | $ | 140.2 |  |  | 8.0 | % |  | $ | 123.7 |  |  | 7.4 | % |  |
| Total net revenue |  |  |  |  |  |  |  |  | $ | 1,712.6 |  |  |  |  | $ | 1,742.8 |  |  |  |  | $ | 1,678.6 |  |  |  |  |

[0001628280-22-023617:notes:452]
During the years ended July 2, 2022, July 3, 2021, and June 27, 2020, net revenue generated from a single customer which represented 10% or greater of total net revenue is summarized as follows:

[0001628280-22-023617:notes:453]
|  | Years Ended |
|  | July 2, 2022 |  | July 3, 2021 |  | June 27, 2020 |
| Customer A | 28.7 | % |  | 30.2 | % |  | 26.0 | % |
| Customer B | 12.6 | % |  | 10.1 | % |  | * |
| Customer C | * |  | 10.8 | % |  | 13.2 | % |
| *Represents less than 10% of total net revenue. |  |  |  |  |  |

[0001628280-22-023617:notes:454]
Our accounts receivable was concentrated with two customers as of July 2, 2022, which individually represented 10% and 10% of gross accounts receivable, respectively, and collectively accounted for 20% of the total gross accounts receivable, as compared with two customers as of July 3, 2021, which individually represented 17% and 14% of gross accounts receivable, respectively, and collectively accounted for 31% of the total gross accounts receivable.

[0001628280-22-023617:notes:455]
Long-lived assets, namely property, plant and equipment, net, were identified based on the physical location of the assets in the corresponding geographic areas as of the periods indicated (in millions):

[0001628280-22-023617:notes:456]
|  | July 2, 2022 |  | July 3, 2021 |
| United States | $ | 107.8 |  |  | $ | 116.7 |  |
| Thailand | 107.6 |  |  | 103.9 |  |
| Japan | 38.9 |  |  | 36.4 |  |
| China | 32.7 |  |  | 41.3 |  |
| Other countries | 73.5 |  |  | 62.8 |  |
| Total long-lived assets | $ | 360.5 |  |  | $ | 361.1 |  |

[0001628280-22-023617:notes:457]
We purchase a portion of our inventory from contract manufacturers and vendors located primarily in Taiwan, Thailand, and Malaysia. During fiscal 2022, 2021 and 2020, our net inventory purchases from a single contract manufacturer, which represented 10% or greater of total net purchases, were concentrated with two contract manufacturers in each fiscal year, who collectively accounted for 55%, 40%, and 39% of total net inventory purchases, respectively.


## us-gaap:SchedulesOfConcentrationOfRiskByRiskFactorTextBlock

[0001628280-22-023617:notes:458]
The table below discloses our total net revenue attributable to each of our two reportable segments. In addition, the table sets forth the percentage of our total net revenue attributable to our product offerings which serve Telecom and Datacom, and Consumer and Industrial markets which accounted for 10% or more of our total net revenue during the periods presented (in millions, except percentage data):

[0001628280-22-023617:notes:459]
|  |  |  | Years Ended |
|  |  |  | July 2, 2022 |  | July 3, 2021 |  | June 27, 2020 |
| OpComms: |  |  |  |  |  |  |  |  |  |  |
| Telecom and Datacom |  |  | $ | 1,008.7 |  | 58.9 | % |  | $ | 1,059.7 |  | 60.8 | % |  | $ | 1,021.8 |  | 60.9 | % |
| Consumer and Industrial |  |  | 509.8 |  | 29.8 | % |  | 561.0 |  | 32.2 | % |  | 493.3 |  | 29.4 | % |
| Total OpComms |  |  | $ | 1,518.5 |  | 88.7 | % |  | $ | 1,620.7 |  | 93.0 | % |  | $ | 1,515.1 |  | 90.3 | % |
| Lasers |  |  | 194.1 |  | 11.3 | % |  | 122.1 |  | 7.0 | % |  | 163.5 |  | 9.7 | % |
| Net Revenue |  |  | $ | 1,712.6 |  |  |  | $ | 1,742.8 |  |  |  | $ | 1,678.6 |  |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001628280-22-023617:notes:460]
Note 20. Revenue Recognition

[0001628280-22-023617:notes:461]
We disaggregate revenue by product and by geography. We do not present other levels of disaggregation, such as by type of products, customer, markets, contracts, duration of contracts, timing of transfer of control and sales channels, as this information is not used by our CODM to manage the business.

[0001628280-22-023617:notes:462]
The following table reflects the changes in contract balances for the periods presented (in millions, except percentages):

[0001628280-22-023617:notes:463]
| Contract balances |  | Balance sheet location |  | July 2, 2022 |  | July 3, 2021 |  | Change |  | Percentage Change |
| Accounts receivable, net |  | Accounts receivable, net |  | $ | 262.0 |  |  | $ | 212.8 |  |  | $ | 49.2 |  |  | 23.1% |
| Deferred revenue and customer deposits |  | Other current liabilities |  | $ | — |  |  | $ | 0.6 |  |  | $ | (0.6) |  |  | (100.0)% |


## us-gaap:SubsequentEventsTextBlock

[0001628280-22-023617:notes:464]
Note 21. Subsequent Events

[0001628280-22-023617:notes:465]
On August 3, 2022, we completed the acquisition of NeoPhotonics, which was announced on November 2, 2021. The acquisition is accounted for as a business combination using the acquisition method of accounting. Please refer to Note 4. Business Combination.

[0001628280-22-023617:notes:466]
On August 15, 2022, we completed a transaction to acquire a business that develops and markets products for use in telecommunications and datacenter infrastructure, including Digital Signal Processors (DSP’s), ASICs and optical transceivers.  This acquisition will enable us to expand our business in our OpComms segment.


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001628280-22-023617:notes:467]
SCHEDULE II - VALUATION AND QUALIFYING ACCOUNTS

[0001628280-22-023617:notes:468]
|  | (in millions) |
|  | Balance atbeginningof Period |  |  |  | Increase (decrease) in Consolidated Statements of Operations |  | Writeoffs and other adjustments |  |  |  | Balanceat end ofperiod |
| Allowance for credit losses: |  |  |  |  |  |  |  |  |  |  |  |
| Fiscal year ended July 2, 2022 | $ | 0.4 |  |  |  |  | $ | (0.1) |  |  | $ | (0.3) |  |  |  |  | $ | — |  |
| Fiscal year ended July 3, 2021 | $ | 1.8 |  |  |  |  | $ | 0.2 |  |  | $ | (1.6) |  |  |  |  | $ | 0.4 |  |
| Fiscal year ended June 27, 2020 | $ | 4.5 |  |  |  |  | $ | 0.1 |  |  | $ | (2.8) |  |  |  |  | $ | 1.8 |  |

[0001628280-22-023617:notes:469]
|  |  | (in millions) |
|  |  | Balance at beginning of period |  | Additions charged to costs/expenses (1) |  | Deductions credited to costs/expenses (2) |  | Balance at end of period |
| Deferred tax valuation allowance: |  |  |  |  |  |  |  |  |
| Fiscal year ended July 2, 2022 |  | $ | 269.5 |  |  | $ | 5.7 |  |  | $ | (12.1) |  |  | $ | 263.1 |  |
| Fiscal year ended July 3, 2021 |  | $ | 200.8 |  |  | $ | 68.7 |  |  | $ | — |  |  | $ | 269.5 |  |
| Fiscal year ended June 27, 2020 (3) |  | $ | 190.3 |  |  | $ | 12.7 |  |  | $ | (2.2) |  |  | $ | 200.8 |  |

[0001628280-22-023617:notes:470]
(1) Additions include current year additions charged to expenses and current year build due to increases in net deferred tax assets, return to provision true-ups, other adjustments to deferred taxes.

[0001628280-22-023617:notes:471]
(2) Net deductions include current year releases credited to expenses and current year reductions due to decreases in net deferred tax assets, return to provision true-ups, other adjustments to deferred taxes.

[0001628280-22-023617:notes:472]
(3) Certain prior period amounts have been reclassified to conform to current year presentation on a jurisdiction by jurisdiction basis.
