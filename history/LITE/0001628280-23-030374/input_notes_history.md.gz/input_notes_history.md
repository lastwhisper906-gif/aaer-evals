# LITE note change history — 0001628280-23-002880 → 0001628280-23-016653


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-05-09):
[0001628280-23-016653:note_history:1]
Our purchase obligations of $379.2 million as of April 1, 2023 represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet our operational requirements. In addition, we assumed certain purchase orders in connection with our merger with NeoPhotonics for the purchase of inventory and other items in the ordinary course of its business.  Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule, and adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.
  (was, 2023-02-09, similarity 0.9854):
[0001628280-23-002880:note_history:1]
Purchase obligations of $391.5 million as of December 31, 2022, represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. In addition, we assumed certain purchase orders in connection with our merger with NeoPhotonics for the purchase of inventory and other items in the ordinary course of its business.  Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule and adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

- changed (2023-05-09):
[0001628280-23-016653:note_history:2]
We provide reserves for the estimated costs of product warranties at the time revenue is recognized. We typically offer a twelve-month warranty for most of our products. However, in some instances depending upon the product, product components or application of our products by the end customer, our warranties can vary and generally range from six months to five years. We estimate the costs of our warranty obligations on an annualized basis based on our historical experience of known product failure rates, use of materials to repair or replace defective products, and service delivery costs incurred in correcting product failures. In addition, from time to time, specific warranty accruals may be made if unforeseen technical problems arise with specific products. We assess the adequacy of our recorded warranty liabilities and adjust the amounts as necessary.
  (was, 2023-02-09, similarity 0.6613):
[0001628280-23-002880:note_history:2]
We provide reserves for the estimated costs of product warranties at the time revenue is recognized. We typically offer a twelve month warranty for most of our products. However, in some instances depending upon the product, product components or application of our products by the end customer, our warranties can vary and generally range from six months to five years. We estimate the costs of our warranty obligations on an annualized basis based on our historical experience of known product failure rates, use of materials to repair or replace defective products and service delivery costs incurred in correcting product failures. In addition, from time to time, specific warranty accruals may be made if unforeseen technical problems arise with specific products. We assess the adequacy of our recorded warranty liabilities and adjust the amounts as necessary.

- changed (2023-05-09):
[0001628280-23-016653:note_history:3]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 1, 2023 |  | April 2, 2022 |  | April 1, 2023 |  | April 2, 2022 |
| Balance as of beginning of period | $ | 8.4 |  |  | $ | 8.6 |  |  | $ | 10.0 |  |  | $ | 5.0 |  |
| Warranties assumed in NeoPhotonics merger | — |  |  | — |  |  | 0.7 |  |  | — |  |
| Provision for warranty | 1.1 |  |  | 1.5 |  |  | 5.4 |  |  | 7.0 |  |
| Utilization of reserve | (2.7) |  |  | (1.0) |  |  | (9.3) |  |  | (2.9) |  |
| Balance as of end of period | $ | 6.8 |  |  | $ | 9.1 |  |  | $ | 6.8 |  |  | $ | 9.1 |  |
  (was, 2023-02-09, similarity 0.8815):
[0001628280-23-002880:note_history:3]
|  | Three Months Ended |  | Six Months Ended |
|  | December 31, 2022 |  | January 1, 2022 |  | December 31, 2022 |  | January 1, 2022 |
| Balance as of beginning of period | $ | 10.1 |  |  | $ | 5.1 |  |  | $ | 10.0 |  |  | $ | 5.0 |  |
| Warranties assumed in NeoPhotonics merger | — |  |  | — |  |  | 0.7 |  |  | — |  |
| Provision for warranty | 2.8 |  |  | 3.8 |  |  | 4.3 |  |  | 5.5 |  |
| Utilization of reserve | (4.5) |  |  | (0.3) |  |  | (6.6) |  |  | (1.9) |  |
| Balance as of end of period | $ | 8.4 |  |  | $ | 8.6 |  |  | $ | 8.4 |  |  | $ | 8.6 |  |

- changed (2023-05-09):
[0001628280-23-016653:note_history:4]
Our research and development, manufacturing and distribution operations involve the use of hazardous substances and are regulated under international, federal, state and local laws governing health and safety and the environment. We apply strict standards for protection of the environment and occupational health and safety to sites inside and outside the United States, even if not subject to regulations imposed by foreign governments. We believe that our properties and operations at our facilities comply in all material respects with applicable environmental laws and occupational health and safety laws. However, the risk of environmental liabilities cannot be completely eliminated and there can be no assurance that the application of environmental and health and safety laws will not require us to incur significant expenditures. We are also regulated under a number of international, federal, state and local laws regarding recycling, product packaging and product content requirements. The environmental and product content/disposal and recycling laws are gradually becoming more stringent and may cause us to incur significant expenditures in the future.
  (was, 2023-02-09, similarity 0.9979):
[0001628280-23-002880:note_history:4]
Our research and development, manufacturing and distribution operations involve the use of hazardous substances and are regulated under international, federal, state and local laws governing health and safety and the environment. We apply strict standards for protection of the environment and occupational health and safety to sites inside and outside the United States, even if not subject to regulations imposed by foreign governments. We believe that our properties and operations at our facilities comply in all material respects with applicable environmental laws and occupational health and safety laws. However, the risk of environmental liabilities cannot be completely eliminated and there can be no assurance that the application of environmental and health and safety laws will not require us to incur significant expenditures. We are also regulated under a number of international, federal, state and local laws regarding recycling, product packaging and product content requirements. The environmental, product content/disposal and recycling laws are gradually becoming more stringent and may cause us to incur significant expenditures in the future.

- changed (2023-05-09):
[0001628280-23-016653:note_history:5]
We are subject to a variety of claims and suits that arise from time to time in the ordinary course of our business. While management currently believes that resolving claims against us, individually or in the aggregate, will not have a material adverse impact on our financial position, results of operations or statements of cash flows, these matters are subject to inherent uncertainties and management’s view of these matters may change in the future. We accrue for loss contingencies when it is both probable that we will incur the loss and when we can reasonably estimate the amount of the loss or range of loss.  We have recorded $7.8 million with respect to the pending settlement of certain non-ordinary course litigation matters under accrued expenses in our condensed consolidated balance sheet as of April 1, 2023.
  (was, 2023-02-09, similarity 0.9871):
[0001628280-23-002880:note_history:5]
We are subject to a variety of claims and suits that arise from time to time in the ordinary course of our business. While management currently believes that resolving claims against us, individually or in the aggregate, will not have a material adverse impact on our financial position, results of operations or statements of cash flows, these matters are subject to inherent uncertainties and management’s view of these matters may change in the future. We accrue for loss contingencies when it is both probable that we will incur the loss and when we can reasonably estimate the amount of the loss or range of loss.  We have recorded $7.8 million with respect to the settlement of certain non-ordinary course litigation matters under accrued expenses in our condensed consolidated balance sheet as of December 31, 2022.

- changed (2023-05-09):
[0001628280-23-016653:note_history:6]
On August 16, 2022, the lead plaintiff moved for class certification and to be appointed class representative. Defendants opposed the motion. The action subsequently was stayed while the parties participated in a mediation. On January 18, 2023, the lead plaintiff filed a Notice of Settlement informing the court of an agreement in principle between the parties for a class-wide settlement of the Karri Lawsuit. On January 24, 2023, in light of the potential settlement, the court vacated all pretrial and trial dates and ordered the lead plaintiff to file a motion for preliminary approval of the settlement by March 17, 2023. The lead plaintiff filed his motion for preliminary approval of the settlement on March 16, 2023, and defendants filed a statement of non-opposition on March 30, 2023.  On April 20, 2023, the court held a hearing on lead plaintiff’s motion for preliminary approval of the settlement.  The court declined to grant lead plaintiff’s motion for preliminary approval and ordered lead plaintiff to file a revised motion by May 22, 2023.  In the event that the settlement does not go forward for any reason, the defendants intend to continue to defend the Karri Lawsuit vigorously.
  (was, 2023-02-09, similarity 0.7086):
[0001628280-23-002880:note_history:6]
On August 16, 2022, Plaintiff moved for class certification and to be appointed class representative.  Defendants opposed the motion. The action subsequently was stayed while the parties participated in a mediation.  On January 18, 2023, the plaintiff filed a Notice of Settlement informing the court of an agreement in principle between the parties for a class-wide settlement of the Karri Lawsuit.  On January 24, 2023, in light of the potential settlement, the court vacated all pretrial and trial dates and ordered the plaintiff to file a motion for preliminary approval of the settlement by March 17, 2023. In the event that the settlement does not go forward for any reason, Defendants intend to continue to defend the Karri Lawsuit vigorously.

- changed (2023-05-09):
[0001628280-23-016653:note_history:7]
In connection with our acquisition of NeoPhotonics Corporation (“NeoPhotonics”) announced in November 2021, ten lawsuits (the “NeoPhotonics Lawsuits”) were filed by purported stockholders of NeoPhotonics challenging the proposed merger (the “NeoPhotonics Merger”). All of the NeoPhotonics Lawsuits have been dismissed.
  (was, 2023-02-09, similarity 0.9874):
[0001628280-23-002880:note_history:7]
In connection with our planned acquisition of NeoPhotonics Corporation (“NeoPhotonics”) announced in November 2021, ten lawsuits (the “NeoPhotonics Lawsuits”) were filed by purported stockholders of NeoPhotonics challenging the proposed merger (the “NeoPhotonics Merger”). All of the NeoPhotonics Lawsuits have been dismissed.

- added (2023-05-09):
[0001628280-23-016653:note_history:8]
In the normal course of business, we enter into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown, because claims may be made against us in the future and we may record charges in the future as a result of these indemnification obligations. As of April 1, 2023, we did not have any material indemnification claims that were probable or reasonably possible.

- changed (2023-05-09):
[0001628280-23-016653:note_history:9]
We are under audit by various domestic and foreign tax authorities with regards to income tax and indirect tax matters. In some, although not all cases, we have reserved for potential adjustments to our provision for income taxes and accrual of indirect taxes that may result from examinations by these tax authorities or final outcomes in judicial proceedings, and we believe that the final outcome of these examinations, agreements or judicial proceedings will not have a material effect on our results of operations. If events occur which indicate payment of these amounts is unnecessary, the reversal of the liabilities would result in the recognition of benefits in the period when we determine the liabilities are no longer necessary. If our estimates of the federal, state, and foreign income tax liabilities and indirect tax liabilities are less than the ultimate assessment, it could result in a further charge to expense.
  (was, 2023-02-09, similarity 0.9973):
[0001628280-23-002880:note_history:9]
We are under audit by various domestic and foreign tax authorities with regards to income tax and indirect tax matters. In some, although not all cases, we have reserved for potential adjustments to our provision for income taxes and accrual of indirect taxes that may result from examinations by these tax authorities or final outcomes in judicial proceedings, and we believe that the final outcome of these examinations, agreements or judicial proceedings will not have a material effect on our results of operations. If events occur which indicate payment of these amounts is unnecessary, the reversal of the liabilities would result in the recognition of benefits in the period we determine the liabilities are no longer necessary. If our estimates of the federal, state, and foreign income tax liabilities and indirect tax liabilities are less than the ultimate assessment, it could result in a further charge to expense.

- removed (2023-05-09):
[0001628280-23-002880:note_history:10]
In the normal course of business, we enter into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown because claims may be made against us in the future, and we may record charges in the future as a result of these indemnification obligations. As of December 31, 2022, we did not have any material indemnification claims that were probable or reasonably possible.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2023-05-09):
[0001628280-23-016653:note_history:11]
Lumentum Holdings Inc. (“we,” “us,” “our”, “Lumentum” or the “Company”) is an industry-leading provider of optical and photonic products addressing a range of end market applications including Optical Communications (“OpComms”) and Commercial Lasers (“Lasers”) for manufacturing, inspection, and life-science applications. We seek to use our core optical and photonic technology and our volume manufacturing capability to expand into attractive emerging markets that benefit from advantages that optical or photonics-based solutions provide, including imaging and sensing for consumer electronics and diode light sources for a variety of consumer and industrial applications. The majority of our customers have historically been, and are currently, original equipment manufacturers (“OEMs”) that incorporate our products into their products, which then address end-market applications. For example, we sell fiber optic components that network equipment manufacturers (“NEMs”) assemble into communications networking systems, which they sell to communications service providers, hyperscale cloud operators, and enterprises with their own networks. Similarly, many of our Lasers products customers incorporate our products into tools they produce, which are used for manufacturing processes by their customers. For imaging and sensing, we sell diode lasers to manufacturers of consumer electronics products for mobile, personal computing, gaming, and other applications, including to the automotive industry, who then integrate our devices within their products, for eventual resale to consumers and also into other industrial applications.
  (was, 2023-02-09, similarity 0.9988):
[0001628280-23-002880:note_history:11]
Lumentum Holdings Inc. (“we,” “us,” “our”, “Lumentum” or the “Company”) is an industry-leading provider of optical and photonic products addressing a range of end market applications including Optical Communications (“OpComms”) and Commercial Lasers (“Lasers”) for manufacturing, inspection and life-science applications. We seek to use our core optical and photonic technology, and our volume manufacturing capability, to expand into attractive emerging markets that benefit from advantages that optical or photonics-based solutions provide, including imaging and sensing for consumer electronics and diode light sources for a variety of consumer and industrial applications. The majority of our customers have historically been, and are currently, original equipment manufacturers (“OEMs”) that incorporate our products into their products which then address end-market applications. For example, we sell fiber optic components that network equipment manufacturers (“NEMs”) assemble into communications networking systems, which they sell to communications service providers, hyperscale cloud operators, and enterprises with their own networks. Similarly, many of our Lasers products customers incorporate our products into tools they produce, which are used for manufacturing processes by their customers. For imaging and sensing, we sell diode lasers to manufacturers of consumer electronics products for mobile, personal computing, gaming, and other applications, including to the automotive industry, who then integrate our devices within their products, for eventual resale to consumers and also into other industrial applications.

- added (2023-05-09):
[0001628280-23-016653:note_history:12]
We have prepared the accompanying condensed consolidated financial statements in accordance with U.S. generally accepted accounting principles (“GAAP”), which requires management to make estimates and assumptions that affect the amounts reported in our condensed consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact us in the future, actual results may be different from the estimates. Our interim period operating results do not necessarily indicate the results that may be expected for any other interim period or for the full fiscal year.  In the opinion of the Company’s management, the information presented herein reflects all normal and recurring adjustments necessary for a fair presentation of our results of operations, financial position, stockholders’ equity, and cash flows. Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective, or complex judgments by management. Those policies are inventory valuation, revenue recognition, income taxes, goodwill, and business combinations.

- added (2023-05-09):
[0001628280-23-016653:note_history:13]
Our business and operating results depend significantly on general market and economic conditions. The current global macroeconomic environment is volatile and continues to be adversely impacted by inflation, and a dynamic supply chain and demand environment, and signs of a weaker macroeconomic environment impacting capital expenditures across our served markets. Additionally, instability in the global credit markets, the impact of uncertainty regarding global central bank monetary policy, capital expenditure reductions, unemployment and other labor issues, decline in stock markets, the instability in the geopolitical environment in many parts of the world, and the current global economic challenges continue to put pressure on our business and operating results.

- added (2023-05-09):
[0001628280-23-016653:note_history:14]
While the impact of the COVID-19 pandemic is lessening, the duration and severity of the impact of the pandemic on our business and results of operations in future periods remain uncertain. The extent of the impact of COVID-19 on our operational and financial performance will depend on certain developments, including but not limited to the duration and spread of the pandemic and its variants in geographies where we do business, implementation and duration of local, state and federal issued public health orders in each jurisdiction where we operate or our customers and suppliers operate, impact on our customers and our sales cycles, impact on our supply chain and manufacturing partners, impact on our employees, and impact on regional and worldwide economies and financial markets in general, all of which are uncertain and not predictable. We assessed the potential impact that this pandemic has on our estimates as of April 1, 2023 and determined that there were no material impacts. However, due to the global supply chain constraint, we have had to incur incremental supply and procurement costs in order to fulfill demand from our customers.  As of April 1, 2023, our inventory balance includes $10.8 million of incremental supply and procurement costs.

- changed (2023-05-09):
[0001628280-23-016653:note_history:15]
We are also continuously monitoring the current developments in the ongoing war between Russia and Ukraine including the related export controls and resulting sanctions imposed on Russia by the U.S. and other countries. Additional factors such as increased inflation, escalating energy costs, constrained raw material availability, and related cost increases could continue to impact the global economy and our business. Although the global implications of the Russian and Ukraine war are difficult to predict at this time, we do not presently foresee direct material adverse effects on our business.
  (was, 2023-02-09, similarity 0.6826):
[0001628280-23-002880:note_history:15]
We are also continuously monitoring the current developments in the ongoing war between Russia and Ukraine including the related export controls and resulting sanctions imposed on Russia by the U.S. and other countries. Additional factors such as increased inflation, escalating energy costs, constrained raw material availability, and related cost increases could impact the global economy. Although the global implications of the Russian/Ukraine war are difficult to predict at this time, we do not presently foresee direct material adverse effects upon our business.

- changed (2023-05-09):
[0001628280-23-016653:note_history:16]
On August 3, 2022, we completed a merger with NeoPhotonics Corporation (“NeoPhotonics”). Our condensed consolidated financial statements include the operating results of NeoPhotonics for the period from the date of the closing of the merger through April 1, 2023. We have applied the acquisition method of accounting in accordance with Accounting Standards Codification (“ASC”) Topic 805, Business Combinations to account for this transaction. Refer to “Note 4. Business Combinations” for further discussion of the merger.
  (was, 2023-02-09, similarity 0.9872):
[0001628280-23-002880:note_history:16]
On August 3, 2022, we completed a merger with NeoPhotonics Corporation (“NeoPhotonics”). Our condensed consolidated financial statements include the operating results of NeoPhotonics for the period from the date of the closing of the merger through December 31, 2022. We have applied the acquisition method of accounting in accordance with Accounting Standards Codification (“ASC”) Topic 805, Business Combinations to account for this transaction. Refer to “Note 4. Business Combinations” for further discussion of the merger.

- changed (2023-05-09):
[0001628280-23-016653:note_history:17]
On August 15, 2022, we completed a transaction to acquire IPG Photonics’ telecom transmission product lines. Our condensed consolidated financial statements include the operating results of this business unit for the period from the date of the acquisition through April 1, 2023. We have applied the acquisition method of accounting in accordance with ASC Topic 805, Business Combinations to account for this transaction. Refer to “Note 4. Business Combinations” for further discussion of this acquisition.
  (was, 2023-02-09, similarity 0.9868):
[0001628280-23-002880:note_history:17]
On August 15, 2022, we completed a transaction to acquire IPG Photonics’ telecom transmission product lines. Our condensed consolidated financial statements include the operating results of this business unit for the period from the date of the acquisition through December 31, 2022. We have applied the acquisition method of accounting in accordance with ASC Topic 805, Business Combinations to account for this transaction. Refer to “Note 4. Business Combinations” for further discussion of this acquisition.

- changed (2023-05-09):
[0001628280-23-016653:note_history:18]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Every fifth or sixth fiscal year will have a 53-week period. The additional week in a 53-week year is added to the third quarter, making such quarter consist of 14 weeks. Our fiscal 2023 is a 52-week year ending on July 1, 2023, with the quarter ended April 1, 2023 being a 13-week quarterly period. Our fiscal 2022 was a 52-week year that ended on July 2, 2022, with the quarter ended April 2, 2022 being a 13-week quarterly period.
  (was, 2023-02-09, similarity 0.7378):
[0001628280-23-002880:note_history:18]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Every fifth or sixth fiscal year will have a 53-week period. The additional week in a 53-week year is added to the third quarter, making such quarter consist of 14 weeks. Our fiscal 2023 is a 52-week year ending on July 1, 2023, with the quarter ended December 31, 2022 being a 13-week quarterly period. Our fiscal 2022 was a 52-week year that ended on July 2, 2022, with the quarter ended January 1, 2022 being a 13-week quarterly period.

- changed (2023-05-09):
[0001628280-23-016653:note_history:19]
The condensed consolidated financial statements include the accounts of Lumentum Holdings Inc. and its wholly-owned subsidiaries. All inter-company transactions and balances are eliminated in consolidation.
  (was, 2023-02-09, similarity 0.9537):
[0001628280-23-002880:note_history:19]
These interim unaudited condensed consolidated financial statements include the accounts of Lumentum Holdings Inc. and its wholly-owned subsidiaries. All inter-company transactions and balances are eliminated in consolidation.

- changed (2023-05-09):
[0001628280-23-016653:note_history:20]
The condensed consolidated financial statements and accompanying notes should be read in conjunction with the audited consolidated financial statements and accompanying notes included in our Annual Report on Form 10-K for the fiscal year ended July 2, 2022. 
Except for the accounting policies for convertible instruments as a result of our adoption of Accounting Standards Update (“ASU”) 2020-06, Debt—Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging—Contracts in Entity’s Own Equity (Subtopic 815-40): Accounting for Convertible Instruments and Contracts in an Entity’s Own Equity, described in “Note 2. Recently Issued Accounting Pronouncements”, there have been no significant changes to our accounting policies during the three and nine months ended April 1, 2023.
  (was, 2023-02-09, similarity 0.9403):
[0001628280-23-002880:note_history:20]
The condensed consolidated financial statements and accompanying related notes should be read in conjunction with the audited consolidated financial statements and related notes included in our Annual Report on Form 10-K for the fiscal year ended July 2, 2022. 
Except for the accounting policies for convertible instruments as a result of our adoption of Accounting Standards Update (“ASU”) 2020-06, Debt—Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging—Contracts in Entity’s Own Equity (Subtopic 815-40): Accounting for Convertible Instruments and Contracts in an Entity’s Own Equity, described in “Note 2. Recently Issued Accounting Pronouncements”, there have been no significant changes to our accounting policies during the six months ended December 31, 2022.

- removed (2023-05-09):
[0001628280-23-002880:note_history:21]
The accompanying condensed consolidated financial statements have been prepared in accordance with U.S. generally accepted accounting principles (“GAAP”), which requires management to make estimates and assumptions that affect the amounts reported in our condensed consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact us in the future, actual results may be different from the estimates. Operating results for the quarter ended December 31, 2022 are not necessarily indicative of the results that may be expected for the fiscal year ending July 1, 2023. In the opinion of the Company’s management, the information presented herein reflects all normal and recurring adjustments necessary for a fair presentation of our results of operations, financial position, stockholders’ equity and cash flows. Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are inventory valuation, revenue recognition, income taxes, goodwill and business combinations.

- removed (2023-05-09):
[0001628280-23-002880:note_history:22]
Our business and operating results depend significantly on general market and economic conditions. The current global macroeconomic environment is volatile and continues to be significantly and adversely impacted by the COVID-19 pandemic, global supply chain constraints, inflation, and a dynamic demand environment. Additionally, instability in the global credit markets, the impact of uncertainty regarding global central bank monetary policy, capital expenditure reductions, unemployment and other labor issues, decline in stock markets, the instability in the geopolitical environment in many parts of the world and the current economic challenges in China continue to put pressure on global economic conditions and our business and operating results.

- removed (2023-05-09):
[0001628280-23-002880:note_history:23]
While the impact of the COVID-19 pandemic is lessening, the duration and severity of the impact of the pandemic on our business and results of operations in future periods remain uncertain. The extent of the impact of COVID-19 on our operational and financial performance will depend on certain developments, including but not limited to the duration and spread of the pandemic and its variants, implementation and duration of local, state and federal issued public health orders in each jurisdiction where we operate or in which our customers and suppliers operate, impact on our customers and our sales cycles, impact on our supply chain and manufacturing partners, impact on our employees and impact on regional and worldwide economies and financial markets in general, all of which are uncertain and not predictable. We assessed the potential impact that this pandemic has on our estimates as of December 31, 2022 and determined that there were no material impacts. However, due to the global supply chain constraint, we have had to incur incremental supply and procurement costs in order to fulfill demand from our customers.  As of December 31, 2022, our inventory balance includes $18.0 million of incremental supply and procurement costs.

- removed (2023-05-09):
[0001628280-23-002880:note_history:24]
Certain prior period amounts have been reclassified to conform to the current period presentation. The reclassification of the prior period amounts did not impact previously reported condensed consolidated financial statements.


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2023-05-09):
[0001628280-23-016653:note_history:25]
| Liability component: | April 1, 2023 |  | July 2, 2022 |
|  | 2024 Notes (1) |  | 2026 Notes (2) |  | 2028 Notes (3) |  | 2024 Notes (1) |  | 2026 Notes (2) |  | 2028 Notes (3) |
| Principal | $ | 448.1 |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |  | $ | 448.1 |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |
| Unamortized debt discount | (20.7) |  |  | — |  |  | — |  |  | (36.1) |  |  | (214.9) |  |  | (221.4) |  |
| Unamortized issuance costs | (1.2) |  |  | (4.4) |  |  | (5.8) |  |  | (2.1) |  |  | (3.7) |  |  | (4.9) |  |
| Net carrying amount of the liability component | $ | 426.2 |  |  | $ | 1,045.6 |  |  | $ | 855.2 |  |  | $ | 409.9 |  |  | $ | 831.4 |  |  | $ | 634.7 |  |

- added (2023-05-09):
[0001628280-23-016653:note_history:26]
(1) If the closing price of our stock exceeds $78.80 (or 130% of the conversion price of $60.62) for 20 of the last 30 trading days of any future fiscal quarter, our 2024 Notes would become convertible at the option of the holders during the next fiscal quarter. The 2024 Notes are classified as current liabilities as the debt will mature on March 15, 2024.

- removed (2023-05-09):
[0001628280-23-002880:note_history:27]
| Liability component: | December 31, 2022 |  | July 2, 2022 |
|  | 2024 Notes (1) |  | 2026 Notes (2) |  | 2028 Notes (3) |  | 2024 Notes (1) |  | 2026 Notes (2) |  | 2028 Notes (3) |
| Principal | $ | 448.1 |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |  | $ | 448.1 |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |
| Unamortized debt discount and issuance costs | (27.4) |  |  | (4.7) |  |  | (6.0) |  |  | (38.2) |  |  | (218.6) |  |  | (226.3) |  |
| Net carrying amount of the liability component | $ | 420.7 |  |  | $ | 1,045.3 |  |  | $ | 855.0 |  |  | $ | 409.9 |  |  | $ | 831.4 |  |  | $ | 634.7 |  |

- removed (2023-05-09):
[0001628280-23-002880:note_history:28]
(1) If the closing price of our stock exceeds $78.80 (or 130% of the conversion price of $60.62) for 20 of the last 30 trading days of any future fiscal quarter, our 2024 Notes would become convertible at the option of the holders during the next fiscal quarter. During the fourth quarter of fiscal 2022, the 2024 Notes were convertible at the option of the holders and therefore, the debt component of our 2024 Notes was classified as current liabilities in our condensed consolidated balance sheet. Although the 2024 Notes will not be convertible during the third quarter of fiscal 2023 due to our stock price not exceeding $78.80 for 20 of the last 30 trading days of the quarter ended December 31, 2022, we continue to classify the 2024 Notes in current liabilities, as holders may convert their 2024 Notes at any time on or after December 15, 2023 until the close of business on the second scheduled trading day immediately preceding the maturity date.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-05-09):
[0001628280-23-016653:note_history:29]
In March 2022, we issued $861.0 million in aggregate principal amount of 0.50% convertible notes due in 2028 (the “2028 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act of 1933, as amended (the “Securities Act”). The 2028 Notes are governed by an indenture between the Company and U.S. Bank Trust Company National Association (as successor in interest to U.S. Bank National Association), as trustee (the “2028 Indenture”). The 2028 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.
  (was, 2023-02-09, similarity 0.9985):
[0001628280-23-002880:note_history:29]
In March 2022, we issued $861.0 million in aggregate principal amount of 0.50% convertible notes due in 2028 (the “2028 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act of 1933, as amended (the “Securities Act”). The 2028 Notes are governed by an indenture between the Company and U.S. Bank Trust Company National Association (as successor in interest to U.S. Bank National Association), as a trustee (the “2028 Indenture”). The 2028 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

- changed (2023-05-09):
[0001628280-23-016653:note_history:30]
The net proceeds from the sale of the 2028 Notes was $854.8 million, after deducting $6.2 million in issuance costs. In addition, we incurred $0.7 million in professional fees in connection with this transaction. Concurrent with the issuance of the 2028 Notes, we used $200.0 million of the net proceeds to repurchase our common stock in privately negotiated transactions.
  (was, 2023-02-09, similarity 0.8389):
[0001628280-23-002880:note_history:30]
The net proceeds from the sale of the 2028 Notes was $854.8 million, after deducting $6.2 million in issuance costs. In addition, we incurred $0.7 million in professional fees in connection with this transaction. Concurrent with the issuance of the 2028 Notes, we used $200.0 million of the net proceeds to repurchase our common stock in privately negotiated transactions. We intend to use the remaining net proceeds for general corporate purposes, which may include capital expenditures and working capital.

- changed (2023-05-09):
[0001628280-23-016653:note_history:31]
•upon the occurrence of specified corporate events, as specified in the 2028 Indentures
  (was, 2023-02-09, similarity 0.9941):
[0001628280-23-002880:note_history:31]
•upon the occurrence of specified corporate events, as specified in the 2028 Indentures.

- changed (2023-05-09):
[0001628280-23-016653:note_history:32]
In December 2019, we issued $1,050.0 million in aggregate principal amount of 0.50% convertible notes due in 2026 (the “2026 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act. The 2026 Notes are governed by an indenture between the Company and U.S. Bank Trust Company National Association (as successor in interest to U.S. Bank National Association, as trustee (the “2026 Indenture”). We used approximately $196.0 million of the net proceeds of the offering to repay in full all amounts outstanding under our term loan credit facility, and a portion of the net proceeds of the offering to purchase approximately $200.0 million of our common stock concurrently with the pricing of the offering in privately negotiated transactions. The 2026 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.
  (was, 2023-02-09, similarity 0.999):
[0001628280-23-002880:note_history:32]
In December 2019, we issued $1,050.0 million in aggregate principal amount of 0.50% convertible notes due in 2026 (the “2026 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act. The 2026 Notes are governed by an indenture between the Company and U.S. Bank Trust Company National Association (as successor in interest to U.S. Bank National Association, as a trustee (the “2026 Indenture”). We used approximately $196.0 million of the net proceeds of the offering to repay in full all amounts outstanding under our term loan credit facility, and a portion of the net proceeds of the offering to purchase approximately $200.0 million of our common stock concurrently with the pricing of the offering in privately negotiated transactions. The 2026 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

- changed (2023-05-09):
[0001628280-23-016653:note_history:33]
•during the five consecutive business day period after any five consecutive trading day period (the “2026 measurement period”) in which the trading price per $1,000 principal amount of the 2026 Notes for each trading day of the 2026 measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate for the 2026 Notes on each such trading day;
  (was, 2023-02-09, similarity 0.9449):
[0001628280-23-002880:note_history:33]
•during the five consecutive business day period after any five consecutive trading day period (the "2026 measurement period") in which the trading price per $1,000 principal amount of the 2026 Notes for each trading day of the 2026 measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate for the 2026 Notes on each such trading day;

- changed (2023-05-09):
[0001628280-23-016653:note_history:34]
In March 2017, we issued $450.0 million in aggregate principal amount of 0.25% convertible notes due in 2024 (the “2024 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act. The 2024 Notes are governed by an indenture between the Company, as the issuer, and U.S. Bank Trust Company National Association (as successor in interest to U.S. Bank National Association), as trustee (the “2024 Indenture”). The 2024 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.
  (was, 2023-02-09, similarity 0.9937):
[0001628280-23-002880:note_history:34]
In March 2017, we issued $450.0 million in aggregate principal amount 2024 Notes of 0.25% convertible notes due in 2024 (the “2024 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act. The 2024 Notes are governed by an indenture between the Company, as the issuer, and U.S. Bank Trust Company National Association (as successor in interest to U.S. Bank National Association), as trustee (the “2024 Indenture”). The 2024 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

- changed (2023-05-09):
[0001628280-23-016653:note_history:35]
•during the five consecutive business day period after any five consecutive trading day period (the “2024 measurement period”) in which the trading price per $1,000 principal amount of 2024 Notes for each trading day of such 2024 measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate for the 2024 Notes on each such trading day; or
  (was, 2023-02-09, similarity 0.9962):
[0001628280-23-002880:note_history:35]
•during the five consecutive business day period after any five consecutive trading day period (the “2024 measurement period”) in which the trading price per $1,000 principal amount of 2024 Notes for each trading day of such 2024 measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate for the 2024 Notes on each such trading day;

- changed (2023-05-09):
[0001628280-23-016653:note_history:36]
During the three and nine months ended April 1, 2023, we received conversion requests of less than $0.1 million principal amount of the 2024 Notes, which we settled with cash in accordance with the 2024 Indenture. Since issuing the 2024 Notes, we have converted a total of approximately $1.9 million principal amount of the 2024 Notes. The remaining principal amount of the 2024 Notes as of April 1, 2023 was $448.1 million.
  (was, 2023-02-09, similarity 0.9227):
[0001628280-23-002880:note_history:36]
During the three and six months ended December 31, 2022 we received conversion requests of less than $0.1 million principal amount of the 2024 Notes, which we settled with cash in accordance with the 2024 Indenture. Since issuing the 2024 Notes, we have converted a total of approximately $1.9 million principal amount of the 2024 Notes. The remaining principal amount of the 2024 Notes as of December 31, 2022 was $448.1 million.

- added (2023-05-09):
[0001628280-23-016653:note_history:37]
| Liability component: | April 1, 2023 |  | July 2, 2022 |
|  | 2024 Notes (1) |  | 2026 Notes (2) |  | 2028 Notes (3) |  | 2024 Notes (1) |  | 2026 Notes (2) |  | 2028 Notes (3) |
| Principal | $ | 448.1 |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |  | $ | 448.1 |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |
| Unamortized debt discount | (20.7) |  |  | — |  |  | — |  |  | (36.1) |  |  | (214.9) |  |  | (221.4) |  |
| Unamortized issuance costs | (1.2) |  |  | (4.4) |  |  | (5.8) |  |  | (2.1) |  |  | (3.7) |  |  | (4.9) |  |
| Net carrying amount of the liability component | $ | 426.2 |  |  | $ | 1,045.6 |  |  | $ | 855.2 |  |  | $ | 409.9 |  |  | $ | 831.4 |  |  | $ | 634.7 |  |

- added (2023-05-09):
[0001628280-23-016653:note_history:38]
(1) If the closing price of our stock exceeds $78.80 (or 130% of the conversion price of $60.62) for 20 of the last 30 trading days of any future fiscal quarter, our 2024 Notes would become convertible at the option of the holders during the next fiscal quarter. The 2024 Notes are classified as current liabilities as the debt will mature on March 15, 2024.

- changed (2023-05-09):
[0001628280-23-016653:note_history:39]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 1, 2023 |  | April 2, 2022 |  | April 1, 2023 |  | April 2, 2022 |
| Contractual interest expense | $ | 2.7 |  |  | $ | 1.9 |  |  | $ | 8.1 |  |  | $ | 5.1 |  |
| Amortization of the debt discount and debt issuance costs | 6.0 |  |  | 17.8 |  |  | 17.9 |  |  | 48.6 |  |
| Total interest expense | $ | 8.7 |  |  | $ | 19.7 |  |  | $ | 26.0 |  |  | $ | 53.7 |  |
  (was, 2023-02-09, similarity 0.8426):
[0001628280-23-002880:note_history:39]
|  | Three Months Ended |  | Six Months Ended |
|  | December 31, 2022 |  | January 1, 2022 |  | December 31, 2022 |  | January 1, 2022 |
| Contractual interest expense | $ | 2.7 |  |  | $ | 1.6 |  |  | $ | 5.4 |  |  | $ | 3.2 |  |
| Amortization of the debt discount and debt issuance costs | 6.2 |  |  | 15.5 |  |  | 11.9 |  |  | 30.8 |  |
| Total interest expense | $ | 8.9 |  |  | $ | 17.1 |  |  | $ | 17.3 |  |  | $ | 34.0 |  |

- changed (2023-05-09):
[0001628280-23-016653:note_history:40]
The future interest and principal payments related to our convertible notes are as follows as of April 1, 2023 (in millions):
  (was, 2023-02-09, similarity 0.9551):
[0001628280-23-002880:note_history:40]
The future interest and principal payments related to our convertible notes are as follows as of December 31, 2022 (in millions):

- changed (2023-05-09):
[0001628280-23-016653:note_history:41]
| Fiscal Years | 2024 Notes |  | 2026 Notes |  | 2028 Notes |  | Total |
| Remainder of 2023 | $ | — |  |  | $ | 2.6 |  |  | $ | 2.2 |  |  | $ | 4.8 |  |
| 2024 | 449.3 |  |  | 5.3 |  |  | 4.3 |  |  | 458.9 |  |
| 2025 | — |  |  | 5.3 |  |  | 4.3 |  |  | 9.6 |  |
| 2026 | — |  |  | 5.3 |  |  | 4.3 |  |  | 9.6 |  |
| 2027 and thereafter | — |  |  | 1,052.5 |  |  | 869.6 |  |  | 1,922.1 |  |
| Total convertible notes payments | $ | 449.3 |  |  | $ | 1,071.0 |  |  | $ | 884.7 |  |  | $ | 2,405.0 |  |
  (was, 2023-02-09, similarity 0.9973):
[0001628280-23-002880:note_history:41]
| Fiscal Years | 2024 Notes |  | 2026 Notes |  | 2028 Notes |  | Total |
| Remainder of 2023 | $ | 0.6 |  |  | $ | 2.6 |  |  | $ | 2.2 |  |  | $ | 5.4 |  |
| 2024 | 449.2 |  |  | 5.3 |  |  | 4.3 |  |  | 458.8 |  |
| 2025 | — |  |  | 5.3 |  |  | 4.3 |  |  | 9.6 |  |
| 2026 | — |  |  | 5.3 |  |  | 4.3 |  |  | 9.6 |  |
| 2027 and thereafter | — |  |  | 1,052.4 |  |  | 869.6 |  |  | 1,922.0 |  |
| Total convertible notes payments | $ | 449.8 |  |  | $ | 1,070.9 |  |  | $ | 884.7 |  |  | $ | 2,405.4 |  |

- changed (2023-05-09):
[0001628280-23-016653:note_history:42]
In connection with our merger of NeoPhotonics, we assumed several loan agreements with MUFG Bank, Ltd. (the “Mitsubishi Bank Loans”) for an aggregate fair value of approximately $5.9 million, approximately $0.9 million of which was paid in the fiscal first quarter of 2023.  In October 2022, we fully paid the remaining outstanding amount of the Mitsubishi Bank Loans of approximately $5.0 million. We recorded $0.1 million of interest expense related to the Mitsubishi Bank Loans for the nine months ended April 1, 2023.
  (was, 2023-02-09, similarity 0.9222):
[0001628280-23-002880:note_history:42]
In connection with our merger of NeoPhotonics, we assumed several loan agreements with MUFG Bank, Ltd. (the “Mitsubishi Bank Loans”) for an aggregate fair value of approximately $5.9 million, approximately $0.9 million of which was paid in the fiscal first quarter of 2023.  In October 2022, we fully paid the remaining outstanding amount of the Mitsubishi Bank Loans of approximately $5.0 million. We recorded $0.1 million of interest expense related to the Mitsubishi Bank Loans for both the three and six months ended December 31, 2022.

- removed (2023-05-09):
[0001628280-23-002880:note_history:43]
| Liability component: | December 31, 2022 |  | July 2, 2022 |
|  | 2024 Notes (1) |  | 2026 Notes (2) |  | 2028 Notes (3) |  | 2024 Notes (1) |  | 2026 Notes (2) |  | 2028 Notes (3) |
| Principal | $ | 448.1 |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |  | $ | 448.1 |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |
| Unamortized debt discount and issuance costs | (27.4) |  |  | (4.7) |  |  | (6.0) |  |  | (38.2) |  |  | (218.6) |  |  | (226.3) |  |
| Net carrying amount of the liability component | $ | 420.7 |  |  | $ | 1,045.3 |  |  | $ | 855.0 |  |  | $ | 409.9 |  |  | $ | 831.4 |  |  | $ | 634.7 |  |

- removed (2023-05-09):
[0001628280-23-002880:note_history:44]
(1) If the closing price of our stock exceeds $78.80 (or 130% of the conversion price of $60.62) for 20 of the last 30 trading days of any future fiscal quarter, our 2024 Notes would become convertible at the option of the holders during the next fiscal quarter. During the fourth quarter of fiscal 2022, the 2024 Notes were convertible at the option of the holders and therefore, the debt component of our 2024 Notes was classified as current liabilities in our condensed consolidated balance sheet. Although the 2024 Notes will not be convertible during the third quarter of fiscal 2023 due to our stock price not exceeding $78.80 for 20 of the last 30 trading days of the quarter ended December 31, 2022, we continue to classify the 2024 Notes in current liabilities, as holders may convert their 2024 Notes at any time on or after December 15, 2023 until the close of business on the second scheduled trading day immediately preceding the maturity date.


## us-gaap:DebtSecuritiesAvailableForSaleUnrealizedLossPositionFairValueTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-05-09):
[0001628280-23-016653:note_history:45]
|  | Continuous Loss Position For More Than 12 Months |  | Continuous Loss Position For Less Than 12 Months |  | Gross Unrealized Losses |  |  |  |  |  |  |  |  |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  |  |  |  |  |  |  |  |  |
| April 1, 2023: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | 42.2 |  |  | $ | (0.8) |  |  | $ | 82.9 |  |  | $ | (0.2) |  |  | $ | (1.0) |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | — |  |  | 12.7 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | — |  |  | — |  |  | 112.5 |  |  | (0.2) |  |  | (0.2) |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 153.7 |  |  | (1.8) |  |  | 192.8 |  |  | (1.2) |  |  | (3.0) |  |  |  |  |  |  |  |  |  |
| Foreign government bonds | — |  |  | — |  |  | 1.4 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 90.8 |  |  | (1.0) |  |  | 124.6 |  |  | (0.3) |  |  | (1.3) |  |  |  |  |  |  |  |  |  |
| Total | $ | 286.7 |  |  | $ | (3.6) |  |  | $ | 526.9 |  |  | $ | (1.9) |  |  | $ | (5.5) |  |  |  |  |  |  |  |  |  |
| July 2, 2022: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | — |  |  | $ | — |  |  | $ | 73.7 |  |  | $ | (1.4) |  |  | $ | (1.4) |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | — |  |  | 16.2 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | — |  |  | — |  |  | 130.7 |  |  | (0.4) |  |  | (0.4) |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 57.4 |  |  | (0.9) |  |  | 473.2 |  |  | (6.5) |  |  | (7.4) |  |  |  |  |  |  |  |  |  |
| Municipal bonds | — |  |  | — |  |  | 1.0 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | — |  |  | — |  |  | 366.0 |  |  | (4.2) |  |  | (4.2) |  |  |  |  |  |  |  |  |  |
| Total | $ | 57.4 |  |  | $ | (0.9) |  |  | $ | 1,060.8 |  |  | $ | (12.5) |  |  | $ | (13.4) |  |  |  |  |  |  |  |  |  |
  (was, 2023-02-09, similarity 0.9728):
[0001628280-23-002880:note_history:45]
|  | Continuous Loss Position For More Than 12 Months |  | Continuous Loss Position For Less Than 12 Months |  | Gross Unrealized Losses |  |  |  |  |  |  |  |  |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  |  |  |  |  |  |  |  |  |
| December 31, 2022: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | 45.9 |  |  | $ | (1.1) |  |  | $ | 83.0 |  |  | $ | (0.5) |  |  | $ | (1.6) |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | — |  |  | 5.7 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | — |  |  | — |  |  | 73.4 |  |  | (0.2) |  |  | (0.2) |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 283.9 |  |  | (3.0) |  |  | 176.2 |  |  | (1.8) |  |  | (4.8) |  |  |  |  |  |  |  |  |  |
| Municipal bonds | 1.0 |  |  | — |  |  | — |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Foreign government bonds | — |  |  | — |  |  | 1.4 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 148.1 |  |  | (2.4) |  |  | 98.2 |  |  | (0.4) |  |  | (2.8) |  |  |  |  |  |  |  |  |  |
| Total | $ | 478.9 |  |  | $ | (6.5) |  |  | $ | 437.9 |  |  | $ | (2.9) |  |  | $ | (9.4) |  |  |  |  |  |  |  |  |  |
| July 2, 2022: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | — |  |  | $ | — |  |  | $ | 73.7 |  |  | $ | (1.4) |  |  | $ | (1.4) |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | — |  |  | 16.2 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | — |  |  | — |  |  | 130.7 |  |  | (0.4) |  |  | (0.4) |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 57.4 |  |  | (0.9) |  |  | 473.2 |  |  | (6.5) |  |  | (7.4) |  |  |  |  |  |  |  |  |  |
| Municipal bonds | — |  |  | — |  |  | 1.0 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | — |  |  | — |  |  | 366.0 |  |  | (4.2) |  |  | (4.2) |  |  |  |  |  |  |  |  |  |
| Total | $ | 57.4 |  |  | $ | (0.9) |  |  | $ | 1,060.8 |  |  | $ | (12.5) |  |  | $ | (13.4) |  |  |  |  |  |  |  |  |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-05-09):
[0001628280-23-016653:note_history:46]
The future interest and principal payments related to our convertible notes are as follows as of April 1, 2023 (in millions):
  (was, 2023-02-09, similarity 0.9551):
[0001628280-23-002880:note_history:46]
The future interest and principal payments related to our convertible notes are as follows as of December 31, 2022 (in millions):

- changed (2023-05-09):
[0001628280-23-016653:note_history:47]
| Fiscal Years | 2024 Notes |  | 2026 Notes |  | 2028 Notes |  | Total |
| Remainder of 2023 | $ | — |  |  | $ | 2.6 |  |  | $ | 2.2 |  |  | $ | 4.8 |  |
| 2024 | 449.3 |  |  | 5.3 |  |  | 4.3 |  |  | 458.9 |  |
| 2025 | — |  |  | 5.3 |  |  | 4.3 |  |  | 9.6 |  |
| 2026 | — |  |  | 5.3 |  |  | 4.3 |  |  | 9.6 |  |
| 2027 and thereafter | — |  |  | 1,052.5 |  |  | 869.6 |  |  | 1,922.1 |  |
| Total convertible notes payments | $ | 449.3 |  |  | $ | 1,071.0 |  |  | $ | 884.7 |  |  | $ | 2,405.0 |  |
  (was, 2023-02-09, similarity 0.9973):
[0001628280-23-002880:note_history:47]
| Fiscal Years | 2024 Notes |  | 2026 Notes |  | 2028 Notes |  | Total |
| Remainder of 2023 | $ | 0.6 |  |  | $ | 2.6 |  |  | $ | 2.2 |  |  | $ | 5.4 |  |
| 2024 | 449.2 |  |  | 5.3 |  |  | 4.3 |  |  | 458.8 |  |
| 2025 | — |  |  | 5.3 |  |  | 4.3 |  |  | 9.6 |  |
| 2026 | — |  |  | 5.3 |  |  | 4.3 |  |  | 9.6 |  |
| 2027 and thereafter | — |  |  | 1,052.4 |  |  | 869.6 |  |  | 1,922.0 |  |
| Total convertible notes payments | $ | 449.8 |  |  | $ | 1,070.9 |  |  | $ | 884.7 |  |  | $ | 2,405.4 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2023-05-09):
[0001628280-23-016653:note_history:48]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 1, 2023 |  | April 2, 2022 |  | April 1, 2023 |  | April 2, 2022 |
| OpComms: |  |  |  |  |  |  |  |  |  |  |  |
| Telecom and Datacom | $ | 293.3 |  | 76.5 | % |  | $ | 243.5 |  | 61.6 | % |  | $ | 1,037.6 |  | 74.3 | % |  | $ | 726.6 |  | 56.3 | % |
| Industrial and Consumer | 41.8 |  | 10.9 | % |  | 100.7 |  | 25.5 | % |  | 199.7 |  | 14.3 | % |  | 421.0 |  | 32.6 | % |
| Total OpComms | $ | 335.1 |  | 87.4 | % |  | $ | 344.2 |  | 87.1 | % |  | $ | 1,237.3 |  | 88.6 | % |  | $ | 1,147.6 |  | 88.9 | % |
| Lasers | 48.3 |  | 12.6 | % |  | 51.2 |  | 12.9 | % |  | 158.9 |  | 11.4 | % |  | 142.9 |  | 11.1 | % |
| Net Revenue | $ | 383.4 |  |  |  | $ | 395.4 |  |  |  | $ | 1,396.2 |  |  |  | $ | 1,290.5 |  |  |

- added (2023-05-09):
[0001628280-23-016653:note_history:49]
| Contract balances |  | Balance sheet location |  | April 1, 2023 |  | July 2, 2022 |  | Change |  | Percentage Change |
| Accounts receivable, net |  | Accounts receivable, net |  | $ | 278.0 |  |  | $ | 262.0 |  |  | $ | 16.0 |  |  | 6.1 | % |
| Deferred revenue and customer deposits |  | Other current liabilities |  | $ | 3.4 |  |  | $ | — |  |  | $ | 3.4 |  |  | n/a |

- removed (2023-05-09):
[0001628280-23-002880:note_history:50]
|  | Three Months Ended |  | Six Months Ended |
|  | December 31, 2022 |  | January 1, 2022 |  | December 31, 2022 |  | January 1, 2022 |
| OpComms: |  |  |  |  |  |  |  |  |  |  |  |
| Telecom and Datacom | $ | 384.2 |  | 75.9 | % |  | $ | 267.1 |  | 59.8 | % |  | $ | 744.3 |  | 73.5 | % |  | $ | 483.1 |  | 54.0 | % |
| Industrial and Consumer | 64.6 |  | 12.8 | % |  | 130.3 |  | 29.2 | % |  | 157.9 |  | 15.6 | % |  | 320.3 |  | 35.8 | % |
| Total OpComms | $ | 448.8 |  | 88.7 | % |  | $ | 397.4 |  | 89.0 | % |  | $ | 902.2 |  | 89.1 | % |  | $ | 803.4 |  | 89.8 | % |
| Lasers | 57.2 |  | 11.3 | % |  | 49.3 |  | 11.0 | % |  | 110.6 |  | 10.9 | % |  | 91.7 |  | 10.2 | % |
| Net Revenue | $ | 506.0 |  |  |  | $ | 446.7 |  |  |  | $ | 1,012.8 |  |  |  | $ | 895.1 |  |  |

- removed (2023-05-09):
[0001628280-23-002880:note_history:51]
| Contract balances |  | Balance sheet location |  | December 31, 2022 |  | July 2, 2022 |  | Change |  | Percentage Change |
| Accounts receivable, net |  | Accounts receivable, net |  | $ | 330.5 |  |  | $ | 262.0 |  |  | $ | 68.5 |  |  | 26.1 | % |
| Deferred revenue and customer deposits |  | Other current liabilities |  | $ | 1.3 |  |  | $ | — |  |  | $ | 1.3 |  |  | n/a |
