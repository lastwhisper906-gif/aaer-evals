# LITE 8-K — 0001628280-23-029741 filed 2023-08-17

## item codes, every 8-K on or before 2023-08-23

- 2023-08-17 0001628280-23-029741 — 2.02, 9.01
- 2023-06-16 0001193125-23-168966 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2023-05-09 0001628280-23-016629 — 2.02, 9.01
- 2023-04-06 0001628280-23-010935 — 2.02, 8.01, 9.01
- 2023-02-24 0001193125-23-048742 — 5.02, 9.01
- 2023-02-09 0001628280-23-002866 — 2.02, 9.01
- 2022-11-21 0001628280-22-030473 — 5.02, 5.07, 9.01
- 2022-11-08 0001628280-22-028758 — 2.02, 9.01
- 2022-08-16 0001628280-22-022980 — 2.02, 9.01
- 2022-08-03 0001193125-22-210674 — 2.01, 8.01, 9.01
- 2022-07-29 0001193125-22-206587 — 8.01, 9.01
- 2022-05-04 0001628280-22-012145 — 2.02, 9.01
- 2022-03-08 0001193125-22-069350 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2022-02-03 0001628280-22-001736 — 2.02, 9.01
- 2022-01-21 0001193125-22-014413 — 8.01, 9.01
- 2021-11-23 0001628280-21-024070 — 5.02, 5.07
- 2021-11-05 0001193125-21-321796 — 1.01, 9.01
- 2021-11-04 0001628280-21-021618 — 2.02, 9.01
- 2021-11-04 0001193125-21-319601 — 8.01, 9.01
- 2021-08-18 0001628280-21-017219 — 2.02, 9.01
- 2021-06-08 0001633978-21-000030 — 5.02, 9.01
- 2021-05-12 0001633978-21-000008 — 2.02, 9.01
- 2021-03-10 0001193125-21-075438 — 1.01, 8.01, 9.01
- 2021-02-02 0001633978-21-000002 — 2.02, 9.01
- 2021-01-19 0001104659-21-005024 — 1.01, 2.02, 8.01, 9.01
- 2020-11-24 0001193125-20-302557 — 5.02, 5.07
- 2020-11-02 0001633978-20-000017 — 2.02, 9.01
- 2020-09-18 0001633978-20-000012 — 5.02, 9.01
- 2020-08-11 0001633978-20-000010 — 2.02, 9.01
- 2020-05-05 0001628280-20-006358 — 2.02, 9.01
- 2020-02-04 0001633978-20-000002 — 2.02, 9.01
- 2019-12-12 0001193125-19-312875 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2019-12-04 0001633978-19-000075 — 8.01
- 2019-11-20 0001633978-19-000074 — 5.07
- 2019-10-31 0001633978-19-000070 — 2.02, 9.01
- 2019-08-08 0001633978-19-000068 — 2.02, 9.01
- 2019-05-08 0001633978-19-000031 — 1.01
- 2019-05-07 0001633978-19-000029 — 2.02, 9.01
- 2019-02-15 0001633978-19-000005 — 9.01 — amendment of 0001193125-18-346211
- 2019-02-08 0001193125-19-031591 — 5.02, 9.01
- 2019-02-05 0001633978-19-000001 — 2.02, 9.01
- 2018-12-10 0001193125-18-346211 — 1.01, 2.01, 2.03, 5.02, 8.01, 9.01
- 2018-12-06 0001633978-18-000150 — 8.01
- 2018-11-14 0001633978-18-000139 — 5.07
- 2018-11-13 0001633978-18-000136 — 3.02
- 2018-11-13 0001633978-18-000132 — 7.01, 9.01
- 2018-11-01 0001628280-18-013238 — 2.02, 9.01
- 2018-08-08 0001633978-18-000056 — 2.02, 9.01
- 2018-06-08 0001193125-18-188241 — 5.02, 9.01
- 2018-05-02 0001633978-18-000029 — 2.02, 9.01
- 2018-03-12 0001193125-18-078154 — 1.01, 2.01, 8.01, 9.01
- 2018-02-06 0001628280-18-001082 — 2.02, 9.01
- 2017-11-08 0001633978-17-000133 — 5.02, 9.01
- 2017-11-07 0001633978-17-000131 — 5.07
- 2017-11-01 0001633978-17-000117 — 2.02, 9.01
- 2017-08-09 0001633978-17-000058 — 2.02, 9.01
- 2017-05-04 0001633978-17-000035 — 2.02, 9.01
- 2017-03-08 0001193125-17-074740 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2017-03-02 0001193125-17-066769 — 8.01, 9.01
- 2017-02-07 0001633978-17-000005 — 2.02, 9.01
- 2017-01-03 0001628280-17-000018 — 4.01, 9.01
- 2016-11-09 0001628280-16-021143 — 5.02, 5.07, 9.01
- 2016-10-27 0001628280-16-020382 — 2.02, 9.01
- 2016-08-09 0001628280-16-018811 — 2.02, 9.01
- 2016-06-21 0001628280-16-017201 — 8.01
- 2016-05-04 0001628280-16-015501 — 2.02, 9.01
- 2016-02-16 0001628280-16-011261 — 5.02, 9.01
- 2016-02-04 0001628280-16-010758 — 5.02, 9.01
- 2016-02-04 0001628280-16-010755 — 2.02, 9.01
- 2015-11-17 0001193125-15-378953 — 7.01
- 2015-11-10 0001628280-15-008606 — 2.02, 9.01
- 2015-09-28 0001193125-15-329665 — 8.01, 9.01
- 2015-08-11 0001193125-15-286405 — 7.01, 9.01
- 2015-08-06 0001193125-15-281219 — 1.01, 5.02, 5.03, 5.05, 8.01, 9.01
- 2015-08-03 0001193125-15-274808 — 5.03, 9.01

## late-filing notifications on or before 2023-08-23

- 2015-11-10 0001628280-15-008612 — NT 10-Q, for the period ended 2015-09-26
- 2015-09-28 0001193125-15-329672 — NT 10-K, for the period ended 2015-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001628280-23-029741:8k_2_02:1]
EX-99.1
2
lite_ex991xq4fy23.htm
EX-99.1

[0001628280-23-029741:8k_2_02:2]
Document

[0001628280-23-029741:8k_2_02:3]
NEWS RELEASE

[0001628280-23-029741:8k_2_02:4]
LUMENTUM ANNOUNCES FISCAL FOURTH QUARTER AND FULL YEAR 2023 RESULTS

[0001628280-23-029741:8k_2_02:5]
Fiscal Fourth Quarter Highlights:

[0001628280-23-029741:8k_2_02:6]
•Net revenue of $370.8 million

[0001628280-23-029741:8k_2_02:7]
•GAAP operating loss of 15.1%; Non-GAAP operating margin of 9.1%

[0001628280-23-029741:8k_2_02:8]
•GAAP diluted net loss per share of $0.88; Non-GAAP diluted net income per share of  $0.59

[0001628280-23-029741:8k_2_02:9]
Fiscal Year 2023 Highlights:

[0001628280-23-029741:8k_2_02:10]
•Net revenue of $1.77 billion

[0001628280-23-029741:8k_2_02:11]
•GAAP operating loss of 6.5%; Non-GAAP operating margin of 19.2%

[0001628280-23-029741:8k_2_02:12]
•GAAP diluted net loss per share of $1.93; Non-GAAP diluted net income per share of  $4.56

[0001628280-23-029741:8k_2_02:13]
San Jose, Calif., August 17, 2023 – Lumentum Holdings Inc. (“Lumentum” or the “Company”) today reported results for its fiscal fourth quarter and full year ended July 1, 2023.

[0001628280-23-029741:8k_2_02:14]
“With generational upgrades in the backbone of the network and increased customer activity for AI in the data center, we expect year-over-year Telecom and Datacom growth in calendar 2024,” said Alan Lowe, President and CEO. “Fourth quarter revenue and EPS results were above the midpoints of our guidance. We believe that the current customer inventory correction cycle will continue through the balance of the calendar year, and therefore, our shipments will be below end-market demand. During this transition period, we are delivering as planned on our product roadmaps and are tracking ahead of our previously announced synergy plans.”

[0001628280-23-029741:8k_2_02:15]
Fiscal Fourth Quarter Highlights:

[0001628280-23-029741:8k_2_02:16]
Net revenue for the fiscal fourth quarter of 2023 was $370.8 million, with GAAP net loss of $60.2 million, or $0.88 per diluted share. Net revenue for the fiscal third quarter of 2023 was $383.4 million, with GAAP net loss of $39.3 million, or $0.57 per diluted share. Net revenue for the fiscal fourth quarter of 2022 was $422.1 million, with GAAP net income of $34.7 million, or $0.49 per diluted share.

[0001628280-23-029741:8k_2_02:17]
Non-GAAP net income for fiscal fourth quarter of 2023 was $40.2 million, or $0.59 per diluted share. Non-GAAP net income for fiscal third quarter of 2023 was $51.8 million, or $0.75 per diluted share. Non-GAAP net income for the fiscal fourth quarter of 2022 was $105.0 million, or $1.47 per diluted share.

[0001628280-23-029741:8k_2_02:18]
The Company held $2,013.6 million in total cash, cash equivalents, and short-term investments at the end of the fiscal fourth quarter of 2023, an increase of $346.4 million from the third quarter of 2023. In June 2023, we issued $603.7 million in aggregate principal amount of convertible notes due in 2029 (the “2029 Notes”). Net proceeds from the issuance of 2029 Notes were $599.4 million, after deducting $4.3 million of net issuance costs. Concurrent with the issuance of the 2029 Notes, we used $132.8 million of the net proceeds to repurchase $125.0 million aggregate principal amount of our convertible notes due in 2024 ( the “2024 Notes”) and $125.0 million of the net proceeds to repurchase our common stock.

[0001628280-23-029741:8k_2_02:19]
Full Fiscal Year 2023 Highlights:

[0001628280-23-029741:8k_2_02:20]
Net revenue for fiscal year 2023 was $1,767.0 million, with GAAP net loss of $131.6 million, or $1.93 per diluted share. Net revenue for fiscal year 2022 was $1,712.6 million, with GAAP net income of $198.9 million, or $2.68 per diluted share.

[0001628280-23-029741:8k_2_02:21]
Non-GAAP net income for fiscal year 2023 was $315.3 million, or $4.56 per diluted share. Non-GAAP net income for fiscal year 2022 was $449.2 million, or $6.05 per diluted share.

[0001628280-23-029741:8k_2_02:22]
Cash from operations for the fiscal year of 2023 was $179.8 million.

[0001628280-23-029741:8k_2_02:23]
Financial Overview – Fiscal Fourth Quarter Ended July 1, 2023

[0001628280-23-029741:8k_2_02:24]
|  | GAAP Results ($ in millions) |
|  | Q4 |  | Q3 |  | Q4 |  | Change |
|  | FY 2023 |  | FY 2023 |  | FY 2022 |  | Q/Q |  | Y/Y |
| Net revenue | $ | 370.8 |  |  | $ | 383.4 |  |  | $ | 422.1 |  |  | (3.3)% |  | (12.2)% |
| Gross margin | 24.2 | % |  | 29.2 | % |  | 43.0 | % |  | (500)bps |  | (1,880)bps |
| Operating margin (loss) | (15.1) | % |  | (13.4) | % |  | 13.1 | % |  | (170)bps |  | (2,820)bps |
|  | Non-GAAP Results ($ in millions) |
|  | Q4 |  | Q3 |  | Q4 |  | Change |
|  | FY 2023 |  | FY 2023 |  | FY 2022 |  | Q/Q |  | Y/Y |
| Net revenue | $ | 370.8 |  |  | $ | 383.4 |  |  | $ | 422.1 |  |  | (3.3)% |  | (12.2)% |
| Gross margin | 36.7 | % |  | 40.8 | % |  | 50.4 | % |  | (410)bps |  | (1,370)bps |
| Operating margin | 9.1 | % |  | 13.4 | % |  | 28.8 | % |  | (430)bps |  | (1,970)bps |

[0001628280-23-029741:8k_2_02:25]
|  | Net Revenue by Segment ($ in millions) |
|  | Q4 |  | % of |  | Q3 |  | Q4 |  | Change |
|  | FY 2023 |  | Net Revenue |  | FY 2023 |  | FY 2022 |  | Q/Q |  | Y/Y |
| Optical Communications | $ | 320.5 |  |  | 86.4 | % |  | $ | 335.1 |  |  | $ | 370.9 |  |  | (4.4) | % |  | (13.6) | % |
| Lasers | 50.3 |  |  | 13.6 | % |  | 48.3 |  |  | 51.2 |  |  | 4.1 | % |  | (1.8) | % |
| Total | $ | 370.8 |  |  | 100.0 | % |  | $ | 383.4 |  |  | $ | 422.1 |  |  | (3.3) | % |  | (12.2) | % |

[0001628280-23-029741:8k_2_02:26]
Financial Overview – Fiscal Year Ended July 1, 2023

[0001628280-23-029741:8k_2_02:27]
|  | GAAP Results ($ in millions) |
|  | FY 2023 |  | FY 2022 |  | Change Y/Y |  |
| Net revenue | $ | 1,767.0 |  |  | $ | 1,712.6 |  |  | 3.2% |  |
| Gross margin | 32.2 | % |  | 46.0 | % |  | (1,380)bps |  |
| Operating margin (loss) | (6.5) | % |  | 17.7 | % |  | (2,420)bps |  |

[0001628280-23-029741:8k_2_02:28]
|  | Non-GAAP Results ($ in millions) |
|  | FY 2023 |  | FY 2022 |  | Change Y/Y |  |
| Net revenue | $ | 1,767.0 |  |  | $ | 1,712.6 |  |  | 3.2% |  |
| Gross margin | 43.2 | % |  | 51.6 | % |  | (840)bps |  |
| Operating margin | 19.2 | % |  | 30.8 | % |  | (1,160)bps |  |

[0001628280-23-029741:8k_2_02:29]
|  | Net Revenue by Segment ($ in millions) |
|  | FY 2023 |  | FY 2022 |  | Change Y/Y |  |
| Optical Communications | $ | 1,557.8 |  |  | $ | 1,518.5 |  |  | 2.6% |  |
| Lasers | 209.2 |  |  | 194.1 |  |  | 7.8% |  |
| Total | $ | 1,767.0 |  |  | $ | 1,712.6 |  |  | 3.2% |  |

[0001628280-23-029741:8k_2_02:30]
The tables above provide comparisons of quarterly and annual results to prior periods, including sequential quarterly and year-over-year changes. A reconciliation between GAAP and non-GAAP measures is contained in this release under the section titled “Use of Non-GAAP Financial Measures.”

[0001628280-23-029741:8k_2_02:31]
Business Outlook

[0001628280-23-029741:8k_2_02:32]
Lumentum expects the following for the fiscal first quarter of 2024:

[0001628280-23-029741:8k_2_02:33]
•Net revenue in the range of $300 million to $325 million

[0001628280-23-029741:8k_2_02:34]
•Non-GAAP operating margin of 1.0% to 4.0%

[0001628280-23-029741:8k_2_02:35]
•Non-GAAP diluted earnings per share of $0.20 to $0.35

[0001628280-23-029741:8k_2_02:36]
We have not provided reconciliations from GAAP to non-GAAP measures for our outlook. A large portion of non-GAAP adjustments, such as restructuring charges, stock-based compensation, non-GAAP income tax reconciling adjustments, acquisition related costs, and other costs and contingencies unrelated to current and future operations are by their nature highly volatile and we have low visibility as to the range that may be incurred in the future. The non-GAAP diluted earnings per share forecast is based on an estimated share count of 67.0 million.

[0001628280-23-029741:8k_2_02:37]
Conference Call

[0001628280-23-029741:8k_2_02:38]
Lumentum will host a conference call today, August 17, 2023, at 5:30 am PT/8:30 am ET. A live webcast of the call and the replay will be available on the Lumentum website at http://investor.lumentum.com through August 24, 2023, at 8:59 pm PT. To listen to the live conference call, dial (888) 575-5163 or (416) 764-8620 and reference the conference ID 45504989. To access the replay, dial (877) 674-7070 or (416) 764-8692 and reference the passcode 504989#. Supporting materials outlining the Company’s latest financial results will be posted on http://investor.lumentum.com under the “Events and Presentations” section concurrently with this earnings press release. Lumentum has used, and intends to continue to use, its Investor Relations website as means of disclosing material nonpublic information and for complying with its disclosure obligations under Regulation FD. This press release is being furnished as an exhibit to a Current Report on Form 8-K filed with the Securities and Exchange Commission and will be available at http://www.sec.gov/.

[0001628280-23-029741:8k_2_02:39]
About Lumentum

[0001628280-23-029741:8k_2_02:40]
Lumentum (NASDAQ: LITE) is a market-leading designer and manufacturer of innovative optical and photonic products enabling optical networking and laser applications worldwide. Lumentum optical components and subsystems are part of virtually every type of telecom, enterprise, and data center network. Lumentum lasers enable advanced manufacturing techniques and diverse applications including next-generation imaging and sensing capabilities. Lumentum is headquartered in San Jose, California with R&D, manufacturing, and sales offices worldwide. For more information, visit www.lumentum.com and follow Lumentum on LinkedIn, X (formerly known as Twitter), Facebook, Instagram and YouTube.

[0001628280-23-029741:8k_2_02:41]
Forward-Looking Statements

[0001628280-23-029741:8k_2_02:42]
Contact Information

[0001628280-23-029741:8k_2_02:43]
Investors:     Kathy Ta, (408) 750-3853; investor.relations@lumentum.com

[0001628280-23-029741:8k_2_02:44]
Media:         Caroline Pan, (650) 267-4180; media@lumentum.com

[0001628280-23-029741:8k_2_02:45]
Category:    Financial

[0001628280-23-029741:8k_2_02:46]
The following financial tables are presented in accordance with GAAP, unless otherwise specified.

[0001628280-23-029741:8k_2_02:47]
LUMENTUM HOLDINGS INC.

[0001628280-23-029741:8k_2_02:48]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001628280-23-029741:8k_2_02:49]
(in millions, except per share data)

[0001628280-23-029741:8k_2_02:50]
(unaudited)

[0001628280-23-029741:8k_2_02:51]
|  | Three Months Ended |  | Twelve Months Ended |
|  | July 1, 2023 |  | July 2, 2022 |  | July 1, 2023 |  | July 2, 2022 |
| Net revenue | $ | 370.8 |  |  | $ | 422.1 |  |  | $ | 1,767.0 |  |  | $ | 1,712.6 |  |
| Cost of sales | 263.2 |  |  | 224.8 |  |  | 1,113.6 |  |  | 861.1 |  |
| Amortization of acquired developed intangibles | 18.0 |  |  | 15.6 |  |  | 84.4 |  |  | 62.9 |  |
| Gross profit | 89.6 |  |  | 181.7 |  |  | 569.0 |  |  | 788.6 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 73.9 |  |  | 56.7 |  |  | 307.8 |  |  | 220.7 |  |
| Selling, general and administrative | 68.3 |  |  | 69.6 |  |  | 348.8 |  |  | 265.7 |  |
| Restructuring and related charges | 3.3 |  |  | — |  |  | 28.1 |  |  | (1.1) |  |
| Total operating expenses | 145.5 |  |  | 126.3 |  |  | 684.7 |  |  | 485.3 |  |
| Income (loss) from operations | (55.9) |  |  | 55.4 |  |  | (115.7) |  |  | 303.3 |  |
| Interest expense | (9.4) |  |  | (26.5) |  |  | (35.5) |  |  | (80.2) |  |
| Other income, net | 19.9 |  |  | 8.2 |  |  | 48.8 |  |  | 12.0 |  |
| Income (loss) before income taxes | (45.4) |  |  | 37.1 |  |  | (102.4) |  |  | 235.1 |  |
| Income tax provision | 14.8 |  |  | 2.4 |  |  | 29.2 |  |  | 36.2 |  |
| Net income (loss) | $ | (60.2) |  |  | $ | 34.7 |  |  | $ | (131.6) |  |  | $ | 198.9 |  |
| Net income (loss) per share: |  |  |  |  |  |  |  |
| Basic | $ | (0.88) |  |  | $ | 0.50 |  |  | $ | (1.93) |  |  | $ | 2.79 |  |
| Diluted | $ | (0.88) |  |  | $ | 0.49 |  |  | $ | (1.93) |  |  | $ | 2.68 |  |
| Shares used to compute net income (loss) per share: |  |  |  |  |  |  |  |
| Basic | 68.3 |  |  | 68.9 |  |  | 68.3 |  |  | 71.2 |  |
| Diluted | 68.3 |  |  | 71.5 |  |  | 68.3 |  |  | 74.2 |  |

[0001628280-23-029741:8k_2_02:52]
LUMENTUM HOLDINGS INC.

[0001628280-23-029741:8k_2_02:53]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001628280-23-029741:8k_2_02:54]
(in millions, except per share data)

[0001628280-23-029741:8k_2_02:55]
(unaudited)

[0001628280-23-029741:8k_2_02:56]
|  | July 1, 2023 |  | July 2, 2022 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 859.0 |  |  | $ | 1,290.2 |  |
| Short-term investments | 1,154.6 |  |  | 1,258.8 |  |
| Accounts receivable, net | 246.1 |  |  | 262.0 |  |
| Inventories | 408.6 |  |  | 250.1 |  |
| Prepayments and other current assets | 109.6 |  |  | 78.1 |  |
| Total current assets | 2,777.9 |  |  | 3,139.2 |  |
| Property, plant and equipment, net | 489.5 |  |  | 360.5 |  |
| Operating lease right-of-use assets, net | 77.3 |  |  | 73.6 |  |
| Goodwill | 695.1 |  |  | 368.9 |  |
| Other intangible assets, net | 459.2 |  |  | 155.7 |  |
| Deferred tax asset | 116.3 |  |  | 27.0 |  |
| Other non-current assets | 16.8 |  |  | 37.3 |  |
| Total assets | $ | 4,632.1 |  |  | $ | 4,162.2 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 169.4 |  |  | $ | 156.7 |  |
| Accrued payroll and related expenses | 39.4 |  |  | 54.6 |  |
| Accrued expenses | 51.2 |  |  | 44.7 |  |
| Convertible notes, current | 311.6 |  |  | 409.9 |  |
| Operating lease liabilities, current | 14.4 |  |  | 11.2 |  |
| Other current liabilities | 47.8 |  |  | 39.4 |  |
| Total current liabilities | 633.8 |  |  | 716.5 |  |
| Convertible notes, non-current | 2,500.0 |  |  | 1,466.1 |  |
| Operating lease liabilities, non-current | 47.7 |  |  | 48.8 |  |
| Deferred tax liability | 3.4 |  |  | 12.9 |  |
| Other non-current liabilities | 91.4 |  |  | 42.9 |  |
| Total liabilities | 3,276.3 |  |  | 2,287.2 |  |
| Stockholders’ equity: |  |  |  |
| Common stock, $0.001 par value, 990 authorized shares; 66.4 and 68.0 shares issued and outstanding as of July 1, 2023 and July 2, 2022, respectively | 0.1 |  |  | 0.1 |  |
| Additional paid-in capital | 1,692.2 |  |  | 2,003.6 |  |
| Accumulated deficit | (340.6) |  |  | (129.1) |  |
| Accumulated other comprehensive income | 4.1 |  |  | 0.4 |  |
| Total stockholders’ equity | 1,355.8 |  |  | 1,875.0 |  |
| Total liabilities and stockholders’ equity | $ | 4,632.1 |  |  | $ | 4,162.2 |  |

[0001628280-23-029741:8k_2_02:57]
Use of Non-GAAP Financial Measures

[0001628280-23-029741:8k_2_02:58]
In this press release, Lumentum provides investors with certain non-GAAP financial measures: gross profit, gross margin, research and development expense, selling, general and administrative expense, operating margin, income from operations, interest and other income (expense), net, income before income taxes, provision for income taxes, net income, and net income per share on a non-GAAP basis, as well as the non-GAAP measures of EBITDA and Adjusted EBITDA. Lumentum believes this non-GAAP financial information provides additional insight into the Company’s on-going business operations and results, as well as cash generation, and has therefore chosen to provide this information to investors for a more consistent basis of comparison and to help them evaluate the results of the Company’s on-going operations and enable more meaningful period to period comparisons. In addition, the Company believes that providing certain of these measures allows investors to better understand the Company’s operating performance and cash flows and, importantly, to evaluate the methodology and information used by management to monitor, manage, evaluate and measure the Company’s business, results of operations, and cash flows. However, these measures may be different from non-GAAP measures used by other companies, limiting their usefulness for comparison purposes. The non-GAAP financial measures used in this press release should not be considered in isolation from measures of financial performance prepared in accordance with GAAP. Investors are cautioned that there are material limitations associated with the use of non-GAAP financial measures as an analytical tool. In particular, many of the adjustments to our GAAP financial measures reflect the exclusion of items that are recurring and will be reflected in our financial results for the foreseeable future. Further, these non-GAAP financial measures may not be comparable to similarly titled measurements reported by other companies.

[0001628280-23-029741:8k_2_02:59]
Our non-GAAP measures used in this press release exclude (i) stock-based compensation, (ii) acquisition related stock-based compensation, (iii) acquisition related costs, (iv) amortization of acquired intangibles, (v) amortization of acquired inventory fair value adjustments, (vi) restructuring and related charges, (vii) foreign exchange (gains) losses, net, (viii) non-cash interest expense on convertible notes, (ix) non-recurring expenses related to litigation matters, (x) intangible assets write-off, (xi) integration related costs, (xii) non-GAAP income tax reconciling adjustments, and (xiii) other (gains) charges related to non-recurring activities.

[0001628280-23-029741:8k_2_02:60]
A quantitative reconciliation between GAAP and non-GAAP financial data with respect to historical periods is included in the supplemental financial table attached to this press release.

[0001628280-23-029741:8k_2_02:61]
LUMENTUM HOLDINGS INC.

[0001628280-23-029741:8k_2_02:62]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001628280-23-029741:8k_2_02:63]
(in millions, except per share data)

[0001628280-23-029741:8k_2_02:64]
(unaudited)

[0001628280-23-029741:8k_2_02:65]
|  | Three Months Ended |  | Twelve Months Ended |
|  | July 1, 2023 |  | April 1, 2023 |  | July 2, 2022 |  | July 1, 2023 |  | July 2, 2022 |
| Gross profit on GAAP basis | $ | 89.6 |  |  | $ | 112.0 |  |  | $ | 181.7 |  |  | $ | 569.0 |  |  | $ | 788.6 |  |
| Stock-based compensation | 11.0 |  |  | 6.9 |  |  | 5.6 |  |  | 30.1 |  |  | 20.8 |  |
| Integration related costs | 2.6 |  |  | 6.7 |  |  | — |  |  | 12.1 |  |  | — |  |
| Amortization of acquired intangibles | 18.0 |  |  | 18.7 |  |  | 15.6 |  |  | 84.4 |  |  | 62.9 |  |
| Amortization of inventory fair value adjustments | — |  |  | 3.6 |  |  | — |  |  | 17.8 |  |  | — |  |
| Intangible asset write-off (1) | 6.8 |  |  | — |  |  | — |  |  | 6.8 |  |  | — |  |
| Other charges, net (2) | 8.1 |  |  | 8.4 |  |  | 9.8 |  |  | 43.3 |  |  | 10.7 |  |
| Gross profit on non-GAAP basis | $ | 136.1 |  |  | $ | 156.3 |  |  | $ | 212.7 |  |  | $ | 763.5 |  |  | $ | 883.0 |  |
| Gross margin on non-GAAP basis | 36.7 | % |  | 40.8 | % |  | 50.4 | % |  | 43.2 | % |  | 51.6 | % |
| Research and development on GAAP basis | $ | 73.9 |  |  | $ | 85.4 |  |  | $ | 56.7 |  |  | $ | 307.8 |  |  | $ | 220.7 |  |
| Stock-based compensation | (10.2) |  |  | (11.0) |  |  | (6.3) |  |  | (41.4) |  |  | (22.1) |  |
| Integration related costs | (0.6) |  |  | (0.5) |  |  | — |  |  | (1.9) |  |  | — |  |
| Intangible asset write-off (1) | (1.4) |  |  | (11.5) |  |  | — |  |  | (12.9) |  |  | — |  |
| Other charges, net | — |  |  | (0.3) |  |  | (0.3) |  |  | (2.6) |  |  | (1.0) |  |
| Research and development on non-GAAP basis | $ | 61.7 |  |  | $ | 62.1 |  |  | $ | 50.1 |  |  | $ | 249.0 |  |  | $ | 197.6 |  |
| Selling, general and administrative on GAAP basis | $ | 68.3 |  |  | $ | 76.4 |  |  | $ | 69.6 |  |  | $ | 348.8 |  |  | $ | 265.7 |  |
| Stock-based compensation | (10.9) |  |  | (15.2) |  |  | (15.8) |  |  | (65.0) |  |  | (60.2) |  |
| Stock-based compensation - acquisition related (3) | — |  |  | — |  |  | — |  |  | (11.9) |  |  | — |  |
| Acquisition related (costs) reversal (4) | 4.7 |  |  | — |  |  | — |  |  | (11.5) |  |  | — |  |
| Integration related costs | (6.2) |  |  | (3.4) |  |  | — |  |  | (14.6) |  |  | — |  |
| Litigation matters (5) | — |  |  | — |  |  | — |  |  | (7.8) |  |  | — |  |
| Intangible asset write-off (1) | (1.6) |  |  | — |  |  | — |  |  | (1.6) |  |  | — |  |
| Amortization of acquired intangibles | (11.4) |  |  | (11.3) |  |  | (5.6) |  |  | (43.3) |  |  | (22.6) |  |
| Other charges, net (6) | (2.2) |  |  | (3.7) |  |  | (7.2) |  |  | (17.8) |  |  | (24.5) |  |
| Selling, general and administrative on non-GAAP basis | $ | 40.7 |  |  | $ | 42.8 |  |  | $ | 41.0 |  |  | $ | 175.3 |  |  | $ | 158.4 |  |
| Income from operations on GAAP basis | $ | (55.9) |  |  | $ | (51.4) |  |  | $ | 55.4 |  |  | $ | (115.7) |  |  | $ | 303.3 |  |
| Stock-based compensation | 32.1 |  |  | 33.1 |  |  | 27.7 |  |  | 136.5 |  |  | 103.1 |  |
| Stock-based compensation - acquisition related (3) | — |  |  | — |  |  | — |  |  | 11.9 |  |  | — |  |
| Acquisition related costs (reversal) (4) | (4.7) |  |  | — |  |  | — |  |  | 11.5 |  |  | — |  |
| Integration related costs | 9.4 |  |  | 10.6 |  |  | — |  |  | 28.6 |  |  | — |  |
| Litigation matters (5) | — |  |  | — |  |  | — |  |  | 7.8 |  |  | — |  |
| Amortization of acquired intangibles | 29.4 |  |  | 30.0 |  |  | 21.2 |  |  | 127.7 |  |  | 85.5 |  |
| Amortization of inventory fair value adjustments | — |  |  | 3.6 |  |  | — |  |  | 17.8 |  |  | — |  |
| Restructuring and related charges (7) | 3.3 |  |  | 1.6 |  |  | — |  |  | 28.1 |  |  | (1.1) |  |
| Intangible asset write-off (1) | 9.8 |  |  | 11.5 |  |  | — |  |  | 21.3 |  |  | — |  |
| Other charges, net | 10.3 |  |  | 12.4 |  |  | 17.3 |  |  | 63.7 |  |  | 36.2 |  |

[0001628280-23-029741:8k_2_02:66]
| Income from operations on non-GAAP basis | $ | 33.7 |  |  | $ | 51.4 |  |  | $ | 121.6 |  |  | $ | 339.2 |  |  | $ | 527.0 |  |
| Operating margin on non-GAAP basis | 9.1 | % |  | 13.4 | % |  | 28.8 | % |  | 19.2 | % |  | 30.8 | % |
| Interest and other (expense) income, net on GAAP basis | $ | 10.5 |  |  | $ | 2.7 |  |  | $ | (18.3) |  |  | $ | 13.3 |  |  | $ | (68.2) |  |
| Foreign exchange (gains) losses, net | (2.6) |  |  | 0.5 |  |  | (4.4) |  |  | (7.0) |  |  | (6.1) |  |
| Gain on repurchase of convertible notes (8) | (1.0) |  |  | — |  |  | — |  |  | (1.0) |  |  | — |  |
| Non-cash interest expense on convertible notes and other expenses | 6.4 |  |  | 6.0 |  |  | 23.9 |  |  | 24.3 |  |  | 72.7 |  |
| Interest and other (expense) income, net on non-GAAP basis | $ | 13.3 |  |  | $ | 9.2 |  |  | $ | 1.2 |  |  | $ | 29.6 |  |  | $ | (1.6) |  |
| Income (loss) before income taxes on GAAP basis | $ | (45.4) |  |  | $ | (48.7) |  |  | $ | 37.1 |  |  | $ | (102.4) |  |  | $ | 235.1 |  |
| Stock-based compensation | 32.1 |  |  | 33.1 |  |  | 27.7 |  |  | 136.5 |  |  | 103.1 |  |
| Stock-based compensation - acquisition related (3) | — |  |  | — |  |  | — |  |  | 11.9 |  |  | — |  |
| Acquisition related costs (reversal) (4) | (4.7) |  |  | — |  |  | — |  |  | 11.5 |  |  | — |  |
| Integration related costs | 9.4 |  |  | 10.6 |  |  | — |  |  | 28.6 |  |  | — |  |
| Litigation matters (5) | — |  |  | — |  |  | — |  |  | 7.8 |  |  | — |  |
| Amortization of acquired intangibles | 29.4 |  |  | 30.0 |  |  | 21.2 |  |  | 127.7 |  |  | 85.5 |  |
| Amortization of inventory fair value adjustments | — |  |  | 3.6 |  |  | — |  |  | 17.8 |  |  | — |  |
| Restructuring and related charges (7) | 3.3 |  |  | 1.6 |  |  | — |  |  | 28.1 |  |  | (1.1) |  |
| Intangible asset write-off (1) | 9.8 |  |  | 11.5 |  |  | — |  |  | 21.3 |  |  | — |  |
| Foreign exchange (gains) losses, net | (2.6) |  |  | 0.5 |  |  | (4.4) |  |  | (7.0) |  |  | (6.1) |  |
| Gain on repurchase of convertible notes (8) | (1.0) |  |  | — |  |  | — |  |  | (1.0) |  |  | — |  |
| Non-cash interest expense on convertible notes and other expenses | 6.4 |  |  | 6.0 |  |  | 23.9 |  |  | 24.3 |  |  | 72.7 |  |
| Other charges, net | 10.3 |  |  | 12.4 |  |  | 17.3 |  |  | 63.7 |  |  | 36.2 |  |
| Income before income taxes on non-GAAP basis | $ | 47.0 |  |  | $ | 60.6 |  |  | $ | 122.8 |  |  | $ | 368.8 |  |  | $ | 525.4 |  |
| Income tax provision (benefit) on GAAP basis | $ | 14.8 |  |  | $ | (9.4) |  |  | $ | 2.4 |  |  | $ | 29.2 |  |  | $ | 36.2 |  |
| Non-GAAP income tax reconciling adjustments | (8.0) |  |  | 18.2 |  |  | 15.4 |  |  | 24.3 |  |  | 40.0 |  |
| Income tax provision on non-GAAP basis | $ | 6.8 |  |  | $ | 8.8 |  |  | $ | 17.8 |  |  | $ | 53.5 |  |  | $ | 76.2 |  |
| Net income (loss) on GAAP basis | $ | (60.2) |  |  | $ | (39.3) |  |  | $ | 34.7 |  |  | $ | (131.6) |  |  | $ | 198.9 |  |
| Stock-based compensation | 32.1 |  |  | 33.1 |  |  | 27.7 |  |  | 136.5 |  |  | 103.1 |  |
| Stock-based compensation - acquisition related (3) | — |  |  | — |  |  | — |  |  | 11.9 |  |  | — |  |
| Acquisition related costs (reversal) (4) | (4.7) |  |  | — |  |  | — |  |  | 11.5 |  |  | — |  |
| Integration related costs | 9.4 |  |  | 10.6 |  |  | — |  |  | 28.6 |  |  | — |  |
| Litigation matters (5) | — |  |  | — |  |  | — |  |  | 7.8 |  |  | — |  |
| Amortization of acquired intangibles | 29.4 |  |  | 30.0 |  |  | 21.2 |  |  | 127.7 |  |  | 85.5 |  |
| Amortization of inventory fair value adjustments | — |  |  | 3.6 |  |  | — |  |  | 17.8 |  |  | — |  |
| Restructuring and related charges (7) | 3.3 |  |  | 1.6 |  |  | — |  |  | 28.1 |  |  | (1.1) |  |
| Intangible asset write-off (1) | 9.8 |  |  | 11.5 |  |  | — |  |  | 21.3 |  |  | — |  |
| Foreign exchange (gains) losses, net | (2.6) |  |  | 0.5 |  |  | (4.4) |  |  | (7.0) |  |  | (6.1) |  |
| Gain on repurchase of convertible notes (8) | (1.0) |  |  | — |  |  | — |  |  | (1.0) |  |  | — |  |
| Non-cash interest expense on convertible notes and other expenses | 6.4 |  |  | 6.0 |  |  | 23.9 |  |  | 24.3 |  |  | 72.7 |  |
| Other charges, net | 10.3 |  |  | 12.4 |  |  | 17.3 |  |  | 63.7 |  |  | 36.2 |  |
| Non-GAAP income tax reconciling adjustments | 8.0 |  |  | (18.2) |  |  | (15.4) |  |  | (24.3) |  |  | (40.0) |  |

[0001628280-23-029741:8k_2_02:67]
| Net income on non-GAAP basis | $ | 40.2 |  |  | $ | 51.8 |  |  | $ | 105.0 |  |  | $ | 315.3 |  |  | $ | 449.2 |  |
| Net income per share on non-GAAP basis | $ | 0.59 |  |  | $ | 0.75 |  |  | $ | 1.47 |  |  | $ | 4.56 |  |  | $ | 6.05 |  |
| Shares used in per share calculation - diluted on GAAP basis | 68.3 |  |  | 68.6 |  |  | 71.5 |  |  | 68.3 |  |  | 74.2 |  |
| Non-GAAP adjustment (9) | 0.3 |  |  | 0.1 |  |  | — |  |  | 0.8 |  |  | — |  |
| Shares used in per share calculation - diluted on non-GAAP basis | 68.6 |  |  | 68.7 |  |  | 71.5 |  |  | 69.1 |  |  | 74.2 |  |

[0001628280-23-029741:8k_2_02:68]
(1) During the three months ended July 1, 2023 we recorded a total charge of $9.8 million to write-off acquired intangible assets, which includes $1.4 million of research and development expense for IPR&D intangible assets acquired from NeoPhotonics for projects we will no longer pursue, $6.8 million of cost of sales for developed technologies acquired from IPG and $1.6 million of selling, general and administrative expense for customer relationship acquired from IPG mainly due to product discontinuation as well as changes in customer demand.

[0001628280-23-029741:8k_2_02:69]
During the twelve months ended July 1, 2023, we recorded a total charge of $21.3 million to write-off acquired intangible assets, which includes $12.9 million of research and development expense for IPR&D intangible assets acquired from NeoPhotonics for projects we will no longer pursue, $6.8 million of cost of sales for developed technologies acquired from IPG and $1.6 million of selling, general and administrative expense for customer relationship acquired from IPG mainly due to product discontinuation as well as changes in customer demand.

[0001628280-23-029741:8k_2_02:70]
(2) Other charges excluded in deriving non-GAAP gross profit for the three months ended July 1, 2023 primarily relate to  $5.5 million of incremental costs of sales related to components previously acquired from various brokers to satisfy customer demand, and $2.7 million of excess and obsolete inventory charges driven by U.S. trade restrictions and the related decline in demand from Huawei.

[0001628280-23-029741:8k_2_02:71]
Other charges excluded in deriving non-GAAP gross profit for the twelve months ended July 1, 2023 primarily relate to $32.5 million of incremental costs of sales related to components previously acquired from various brokers to satisfy customer demand and $2.7 million of excess and obsolete inventory charges driven by U.S. trade restrictions and the related decline in demand from Huawei.

[0001628280-23-029741:8k_2_02:72]
(3) In connection with the NeoPhotonics merger, certain equity awards for NeoPhotonics employees were accelerated. The total stock-based compensation associated with the acceleration was $11.9 million for the twelve months ended July 1, 2023, of which $9.0 million was settled in cash.

[0001628280-23-029741:8k_2_02:73]
(4) Acquisition related costs mainly include professional, advisory and legal service fees related to the merger with NeoPhotonics and the acquisition of IPG Photonics’ telecom transmission product lines during the fiscal first quarter of 2023. During the three months ended July 1, 2023, we recorded a reversal of $4.7 million as a result of settlement with a third party service provider during the fiscal fourth quarter of 2023 for professional fees accrued in the fiscal first quarter of 2023.

[0001628280-23-029741:8k_2_02:74]
(5)  During the twelve months ended July 1, 2023, we recorded a charge of $7.8 million with respect to the pending settlement of certain non-ordinary course litigation matters.

[0001628280-23-029741:8k_2_02:75]
(6) Other charges excluded in deriving non-GAAP selling, general and administrative expense for the twelve months ended July 1, 2023 primarily include $12.5 million of legal fees related to certain non-ordinary course litigation matters.

[0001628280-23-029741:8k_2_02:76]
(7) During the three months ended July 1, 2023, we recorded restructuring and related charges of $3.3 million, which was primarily due to company-wide integration efforts as a result of the merger with NeoPhotonics, as well as our cost reduction initiatives.

[0001628280-23-029741:8k_2_02:77]
During the twelve months ended July 1, 2023, we recorded restructuring and related charges of $28.1 million, which was primarily attributable to company-wide integration efforts as a result of the merger with NeoPhotonics, our cost reduction initiatives, as well as severance and employee-related benefits associated with NeoPhotonics’ executive severance and retention agreements. These agreements provide for payments and benefits upon an involuntary termination of employment under certain circumstances.

[0001628280-23-029741:8k_2_02:78]
(8) Concurrent with the issuance of the 2029 Notes, we used $132.8 million of the net proceeds to repurchase $125.0 million aggregate principal amount of the 2024 Notes and recorded a related gain of $1.0 million as a result of the repurchase.

[0001628280-23-029741:8k_2_02:79]
(9) Shares used for net income per share on non-GAAP basis include incremental dilutive shares that would occur upon conversion of our convertible notes assuming we settle the face value of the notes in cash as the Company intends, and shares related to restricted stock units (“RSUs”) and shares issuable under our Employee Stock Purchase Plan that are anti-dilutive on GAAP basis.

[0001628280-23-029741:8k_2_02:80]
LUMENTUM HOLDINGS INC.

[0001628280-23-029741:8k_2_02:81]
RECONCILIATION OF GAAP NET INCOME (LOSS) TO ADJUSTED EBITDA

[0001628280-23-029741:8k_2_02:82]
(in millions, except per share data)

[0001628280-23-029741:8k_2_02:83]
(unaudited)

[0001628280-23-029741:8k_2_02:84]
|  | Three Months Ended |  | Twelve Months Ended |
|  | July 1, 2023 |  | April 1, 2023 |  | July 2, 2022 |  | July 1, 2023 |  | July 2, 2022 |
| GAAP net income (loss) | $ | (60.2) |  |  | $ | (39.3) |  |  | $ | 34.7 |  |  | $ | (131.6) |  |  | $ | 198.9 |  |
| Interest and other expense (income), net | (10.5) |  |  | (2.7) |  |  | 18.3 |  |  | (13.3) |  |  | 68.2 |  |
| Income tax provision (benefit) | 14.8 |  |  | (9.4) |  |  | 2.4 |  |  | 29.2 |  |  | 36.2 |  |
| Depreciation | 28.0 |  |  | 27.7 |  |  | 20.4 |  |  | 106.6 |  |  | 81.6 |  |
| Amortization of acquired intangibles | 29.4 |  |  | 30.0 |  |  | 21.2 |  |  | 127.7 |  |  | 85.5 |  |
| EBITDA | 1.5 |  |  | 6.3 |  |  | 97.0 |  |  | 118.6 |  |  | 470.4 |  |
| Amortization of inventory fair value adjustments | — |  |  | 3.6 |  |  | — |  |  | 17.8 |  |  | — |  |
| Restructuring and related charges | 3.3 |  |  | 1.6 |  |  | — |  |  | 28.1 |  |  | (1.1) |  |
| Stock-based compensation | 32.1 |  |  | 33.1 |  |  | 27.7 |  |  | 148.4 |  |  | 103.1 |  |
| Acquisition related costs | (4.7) |  |  | — |  |  | — |  |  | 11.5 |  |  | — |  |
| Integration related costs | 9.4 |  |  | 10.6 |  |  | — |  |  | 28.6 |  |  | — |  |
| Intangible asset write-off | 9.8 |  |  | 11.5 |  |  | — |  |  | 21.3 |  |  | — |  |
| Other (gains) and charges | 8.0 |  |  | 10.3 |  |  | 17.3 |  |  | 57.4 |  |  | 36.2 |  |
| Adjusted EBITDA | $ | 59.4 |  |  | $ | 77.0 |  |  | $ | 142.0 |  |  | $ | 431.7 |  |  | $ | 608.6 |  |
