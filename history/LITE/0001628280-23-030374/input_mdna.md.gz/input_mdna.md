# LITE MD&A — 0001628280-23-030374


## mdna

[0001628280-23-030374:mdna:1]
ITEM 7.    MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0001628280-23-030374:mdna:2]
You should read the following discussion in conjunction with the audited consolidated financial statements and the corresponding notes included elsewhere in this Annual Report. This Management’s Discussion and Analysis of Financial Condition and Results of Operations contains forward-looking statements. The matters discussed in these forward-looking statements are subject to risk, uncertainties and other factors that could cause actual results to differ materially from those made, projected or implied in the forward-looking statements. Refer to “Risk Factors” and “Forward-Looking Statements” for a discussion of the uncertainties, risks and assumptions associated with these statements.

[0001628280-23-030374:mdna:3]
Overview

[0001628280-23-030374:mdna:4]
We are an industry-leading provider of optical and photonic products, defined by revenue and market share, addressing a range of end-market applications including Optical Communications (“OpComms”) and Commercial Lasers (“Lasers”) for manufacturing, inspection and life-science applications.

[0001628280-23-030374:mdna:5]
We have two operating segments, OpComms and Lasers. The two operating segments were primarily determined based on how the Chief Operating Decision Maker (“CODM”) views and evaluates our operations. Operating results are regularly reviewed by the CODM to make decisions about resources to be allocated to the segments and to assess their performance. Other factors, including market separation and customer specific applications, go-to-market channels, products and manufacturing, are considered in determining the formation of these operating segments.

[0001628280-23-030374:mdna:6]
OpComms

[0001628280-23-030374:mdna:7]
Our OpComms products address the following markets: Telecom, Datacom and Consumer and Industrial.

[0001628280-23-030374:mdna:8]
Our OpComms products include a wide range of components, modules and subsystems to support customers including carrier networks for access (local), metro (intracity), long-haul (city-to-city and worldwide) and submarine (undersea) applications. Additionally, our products address enterprise, cloud, and data center applications, including storage-access networks (“SANs”), local-area networks (“LANs”) and wide-area networks (“WANs”). These products enable the transmission and transport of video, audio and data over high-capacity fiber-optic cables. We maintain leading positions in these fast-growing OpComms markets through our extensive product portfolio, including reconfigurable optical add/drop multiplexers (“ROADMs”), coherent dense wavelength division multiplexing (“DWDM”) pluggable transceivers, and tunable small form-factor pluggable transceivers. We also sell laser chips for use in manufacturing of high-speed Datacom transceivers. In the Consumer and Industrial market, our OpComms products include laser light sources, which are integrated into 3D sensing platforms being used in applications for mobile devices, gaming, computers, and other consumer electronics devices. New emerging applications include virtual and augmented reality, as well as automotive and industrial segments. Our products include vertical cavity surface emitting lasers (“VCSELs”) and edge emitting lasers which are used in 3D sensing depth imaging systems. These systems simplify the way people interact with technology by enabling the use of natural user interfaces. Systems are used for biometric identification, surveillance, and process efficiency, among numerous other application spaces. Emerging applications for this technology include various mobile device applications, autonomous vehicles, self-navigating robotics and drones in industrial applications and 3D capture of objects coupled with 3D printing. In addition, our industrial diode lasers are used primarily as pump sources for pulsed and kilowatt class fiber lasers.

[0001628280-23-030374:mdna:9]
Lasers

[0001628280-23-030374:mdna:10]
Our Lasers products serve our customers in markets and applications such as sheet metal processing, general manufacturing, solar, biotechnology, graphics and imaging, remote sensing, and precision machining such as drilling in printed circuit boards, wafer singulation, glass cutting and solar cell scribing.

[0001628280-23-030374:mdna:11]
Our Lasers products are used in a variety of OEM applications including diode-pumped solid-state, fiber, diode, direct-diode and gas lasers such as argon-ion and helium-neon lasers. Fiber lasers provide kW-class output powers combined with excellent beam quality and are used in sheet metal processing and metal welding applications. Diode-pumped solid-state lasers provide excellent beam quality, low noise and exceptional reliability and are used in biotechnology, graphics and imaging, remote sensing, materials processing and precision machining applications. Diode and direct-diode lasers address a wide variety of applications, including laser pumping, thermal exposure, illumination, ophthalmology, image recording, printing, plastic welding and selective soldering. Gas lasers such as argon-ion and helium-neon lasers provide a stable, low-cost and reliable solution over a wide range of operating conditions, making them well-suited for complex, high-resolution OEM applications such as flow cytometry, DNA sequencing, graphics and imaging and semiconductor inspection.

[0001628280-23-030374:mdna:12]
We also provide high-powered and ultrafast lasers for the industrial and scientific markets. Manufacturers use high-power, ultrafast lasers to create micro parts for consumer electronics and to process semiconductor, LED, solar cells, and other types of chips. Use of ultrafast lasers for micromachining applications is being driven primarily by the increasing use of renewable energy, consumer electronics and connected devices globally.

[0001628280-23-030374:mdna:13]
We believe the global markets in which Lumentum participates have fundamentally robust, long-term trends that will increase the need for our photonics products and technologies. We believe the world is becoming more reliant on ever-increasing amounts of data flowing through optical networks and data centers. Lumentum’s products and technology enable the scaling of these optical networks and data centers to higher capacities. We expect that the accelerating shift to digital and virtual approaches to many aspects of work and life will continue into the future. Virtual meetings, video calls, and hybrid in-person and virtual environments for work and other aspects of life will continue to drive strong needs for bandwidth growth and present dynamic new challenges that our technology addresses. As manufacturers demand higher levels of precision, new materials, and factory and energy efficiency, suppliers of manufacturing tools globally are turning to laser-based approaches, including the types of lasers Lumentum supplies. Laser-based 3D sensing and LiDAR for security, industrial and automotive applications are rapidly developing markets. The technology enables computer vision applications that enhance security, safety, and new functionality in the electronic devices that people rely on every day. The use of LiDAR and in-cabin 3D sensing in automobile and delivery vehicles over time significantly adds to our long-term market opportunity. Frictionless and contactless biometric security and access control is of increasing focus globally given the world’s experience with the COVID-19 pandemic. Additionally, we expect 3D-enabled machine vision solutions to expand significantly in industrial applications in the coming years.

[0001628280-23-030374:mdna:14]
To maintain and grow our market and technology leadership positions, we are continually investing in new and differentiated products and technologies and customer programs that address both nearer-term and longer-term growth opportunities, both organically and through acquisitions, as well as continually improving and optimizing our operations. Over many years, we have developed close relationships with market leading customers. We seek to use our core optical and photonic technology and our volume manufacturing capability to expand into attractive emerging markets that benefit from advantages that optical or photonics-based solutions provide.

[0001628280-23-030374:mdna:15]
44

[0001628280-23-030374:mdna:16]
Mergers and Acquisitions

[0001628280-23-030374:mdna:17]
NeoPhotonics Merger

[0001628280-23-030374:mdna:18]
On August 3, 2022 (the “Closing date”), we completed our merger with NeoPhotonics Corporation (“NeoPhotonics”). The addition of NeoPhotonics expands our opportunities in some of the fastest growing markets for optical components used in cloud and telecom network infrastructure. The integrated company is better positioned to serve the needs of a global customer base who are increasingly utilizing photonics to accelerate the shift to digital and virtual approaches to work and life, the proliferation of IoT, 5G, and next-generation mobile networks, and the transition to advanced cloud computing architectures.

[0001628280-23-030374:mdna:19]
Under the terms of the merger agreement, NeoPhotonics stockholders received $16.00 per share for each of the NeoPhotonics common stock they own at the Closing date. As a result, we paid $867.3 million of cash consideration to shareholders of NeoPhotonics on the Closing date.

[0001628280-23-030374:mdna:20]
As contemplated by the merger agreement, on January 14, 2022, Lumentum and NeoPhotonics entered into a credit agreement where Lumentum agreed to make term loans (“loans”) to NeoPhotonics in an aggregate principal amount not to exceed $50.0 million to help fund capital expenditures and increase working capital associated with NeoPhotonics’ growth plans. During fiscal 2022, we funded a $30.0 million loan request to NeoPhotonics. On August 1, 2022, we funded an additional $20.0 million loan request to NeoPhotonics. The interest was payable monthly in arrears on the first day of each month. The loans would have matured on January 14, 2024, unless earlier repaid or accelerated. The $50.0 million loans in aggregate were not settled at the Closing date, and therefore, were included as part of the total purchase price consideration.

[0001628280-23-030374:mdna:21]
We paid $22.6 million cash consideration to shareholders of NeoPhotonics for the vested and accelerated NeoPhotonics equity awards, of which $13.6 million was allocated to the purchase price consideration. The remaining $9.0 million related to the payment of change-in-control provisions for certain executives, which were recognized as post-combination expenses due to the dual-trigger nature of the arrangements. Additionally, we issued replacement equity awards (the “Replacement Awards”) in settlement of certain NeoPhotonics equity awards that did not become vested at the Closing date, with the total  fair value of $40.2 million based on our closing stock price on the Closing date. The portion of Replacement Awards attributed to pre-merger service was recorded as part of the consideration transferred, which was $3.5 million.

[0001628280-23-030374:mdna:22]
The total transaction consideration of $934.4 million was funded by the cash balances of the combined company. We also recorded $28.7 million of merger-related costs, representing professional and other direct acquisition costs. Of the $28.7 million of merger-related costs, $8.3 million was incurred in fiscal year 2022 and $20.4 million was incurred in fiscal year 2023, which was recorded as selling, general and administrative expense in the consolidated statements of operations.

[0001628280-23-030374:mdna:23]
Acquisition of IPG Photonics’ Telecom Transmission Product Lines

[0001628280-23-030374:mdna:24]
On August 15, 2022, we completed a transaction to acquire IPG Photonics’ telecom transmission product lines (“IPG telecom transmission product lines”) that develop and market products for use in telecommunications and datacenter infrastructure, including Digital Signal Processors (“DSPs”), ASICs and optical transceivers. This acquisition enables us to expand our business in the OpComms segment. The total purchase price of $55.9 million was paid in cash. Refer to “Note 4. Business Combination” to the consolidated financial statements for additional information.

[0001628280-23-030374:mdna:25]
We evaluate strategic opportunities regularly and, where appropriate, may acquire additional businesses, products, or technologies that are complementary to, or broaden the markets for our products. We believe we have strengthened our business model by expanding our addressable markets, customer base and expertise, diversifying our product portfolio and fortifying our core businesses from acquisitions as well as through organic initiatives.

[0001628280-23-030374:mdna:26]
Impact of COVID-19 to Our Business

[0001628280-23-030374:mdna:27]
We continue to monitor the COVID-19 pandemic and actively assess potential implications to our business, supply chain, customer fulfillment sites, support operations and customer demand. We also continue to take appropriate measures to protect the health and safety of our employees and to create and maintain a safe working environment. While the effects of the COVID-19 pandemic have been lessening, if the adverse effects of COVID-19 or related responses of business or governments become more severe and prevalent or prolonged in the locations where we, our customers, suppliers or contract manufacturers conduct business, our business and results of operations could be materially and adversely affected in the future periods.

[0001628280-23-030374:mdna:28]
For more information on risks associated with the COVID-19 outbreak and regulatory actions, refer Item 1A “Risk Factors” of this Annual Report.

[0001628280-23-030374:mdna:29]
Supply Chain Constraints

[0001628280-23-030374:mdna:30]
Our business and our customers’ businesses have been negatively impacted by worldwide logistics and supply chain issues, including constraints on available cargo capabilities and limited availability of once broadly available supplies of both raw materials and finished components. COVID-19 also created dynamics in the semiconductor component supply chains that have led to shortages of the types of components we and our customers require in our products. Although the supply chain constraints have improved in the latter half of fiscal 2023, these shortages impacted our ability to meet demand and generate revenue from certain products in fiscal 2022 and fiscal 2023. If these shortages happen again in the future, they will impact our ability to supply our products to our customers and may reduce our revenue and profit margin. In addition, if our customers are unable to procure needed semiconductor components, this could reduce their demand for our products and reduce our revenue. The impact of semiconductor component shortages may continue in the near term with the exhaustion of supplier and customer buffer inventories and safety stocks. Due to the global supply chain constraints, we had to incur incremental supply and procurement costs in order to increase our ability to fulfill demands from our customers.

[0001628280-23-030374:mdna:31]
In addition, in response to component shortages, certain of our customers accumulated inventory that they are now managing down as supply conditions improve.  Accordingly, ordering patterns are difficult to predict and have declined from recent periods. For example, in the third quarter of fiscal 2023, a significant network equipment manufacturer informed us that due to their inventory management, it would not take the shipments we had originally projected for the quarter. These trends continued through the end of fiscal 2023 and we expect some level of inventory management by our customers will continue to impact our business during fiscal 2024.

[0001628280-23-030374:mdna:32]
For more information on risks associated with supply chain constraints and customer inventory, refer to Item 1A “Risk Factors” of this Annual Report.

[0001628280-23-030374:mdna:33]
Critical Accounting Policies and Estimates

[0001628280-23-030374:mdna:34]
Our consolidated financial statements are prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) as set forth in the Financial Accounting Standards Board’s Accounting Standards Codification (“ASC”). We also consider the various staff accounting bulletins and other applicable guidance issued by the United States Securities and Exchange Commission (“SEC”). GAAP, as set forth within the ASC, requires us to make certain estimates, judgments and assumptions. We believe that the estimates, judgments and assumptions upon which we rely are reasonable based upon information available to us at the time that these estimates, judgments and assumptions are made. These estimates, judgments and assumptions can affect the reported amounts of assets and liabilities as of the date of the financial statements as well as the reported amounts of revenues and expenses during the periods presented. To the extent there are differences between these estimates, judgments or assumptions and actual results, our financial statements will be affected. The accounting policies that reflect our more significant estimates, judgments and assumptions and which we believe are the most critical to aid in fully understanding and evaluating our reported financial results include the following:

[0001628280-23-030374:mdna:35]
•Inventory Valuation

[0001628280-23-030374:mdna:36]
•Revenue Recognition

[0001628280-23-030374:mdna:37]
•Income Taxes

[0001628280-23-030374:mdna:38]
•Business Combinations

[0001628280-23-030374:mdna:39]
•Goodwill and Intangible Assets - Impairment Assessment

[0001628280-23-030374:mdna:40]
Inventory Valuation

[0001628280-23-030374:mdna:41]
Our inventories are recorded at standard cost, which approximates actual cost computed on a first-in, first-out basis, not in excess of net realizable value. We assess the value of our inventories on a quarterly basis and write down those inventories which are obsolete or in excess of our forecasted demand to the lower of their cost or estimated net realizable value.

[0001628280-23-030374:mdna:42]
Our estimates of forecasted demand are based upon our analysis and assumptions including, but not limited to, expected product lifecycles, product development plans and historical usage by product. Our product line management personnel play a key role in our excess review process by providing updated sales forecasts, managing product transitions and working with manufacturing to minimize excess inventory. If actual market conditions are less favorable than our forecasts, or actual demand from our customers is lower than our estimates, we may be required to record additional inventory write-downs. If actual market conditions are more favorable than anticipated, inventories previously written down may be sold, resulting in lower cost of sales and higher income from operations than expected in that period.

[0001628280-23-030374:mdna:43]
Our inventories are sensitive to technical obsolescence in the near term due to the use in industries characterized by the continuous introduction of new product lines, rapid technological advances, and product obsolescence. Based on certain assumptions and judgments made from the information available at that time, we determine the amount of allowance for

[0001628280-23-030374:mdna:44]
potential inventory obsolescence. If these estimates and related assumptions or the market changes, we may be required to record additional reserves. Historically, actual results have not varied materially from our estimates.

[0001628280-23-030374:mdna:45]
Revenue Recognition

[0001628280-23-030374:mdna:46]
Pursuant to Topic 606, our revenues are recognized upon the application of the following steps:

[0001628280-23-030374:mdna:47]
•identification of the contract, or contracts, with a customer;

[0001628280-23-030374:mdna:48]
•identification of the performance obligations in the contract;

[0001628280-23-030374:mdna:49]
•determination of the transaction price;

[0001628280-23-030374:mdna:50]
•allocation of the transaction price to the performance obligations in the contract; and

[0001628280-23-030374:mdna:51]
•recognition of revenues when, or as, the contractual performance obligations are satisfied.

[0001628280-23-030374:mdna:52]
The majority of our revenue comes from product sales, consisting of sales of Lasers and OpComms hardware products to our customers. Our revenue contracts generally include only one performance obligation. Revenues are recognized at a point in time when control of the promised goods or services are transferred to our customers upon shipment or delivery of goods or rendering of services, in an amount that reflects the consideration we expect to be entitled to in exchange for those goods or services. We have entered into vendor managed inventory (“VMI”) programs with our customers. Under these arrangements, we receive purchase orders from our customers, and the inventory is shipped to the VMI location upon receipt of the purchase order. The customer then pulls the inventory from the VMI hub based on its production needs. Revenue under VMI programs is recognized when control transfers to the customer, which is generally once the customer pulls the inventory from the hub.

[0001628280-23-030374:mdna:53]
Revenue from all sales types is recognized at the transaction price. The transaction price is determined based on the consideration to which we will be entitled in exchange for transferring goods or services to the customer adjusted for estimated variable consideration, if any. We typically estimate the impact on the transaction price for discounts offered to the customers for early payments on receivables or net of accruals for estimated sales returns. These estimates are based on historical returns, analysis of credit memo data and other known factors. Actual returns could differ from these estimates. We allocate the transaction price to each distinct product based on its relative standalone selling price. The product price as specified on the purchase order is considered the standalone selling price as it is an observable input that depicts the price as if sold to a similar customer in similar circumstances.

[0001628280-23-030374:mdna:54]
Taxes assessed by a governmental authority that are both imposed on and concurrent with a specific revenue-producing transaction, which are collected by us from a customer and deposited with the relevant government authority, are excluded from revenue.

[0001628280-23-030374:mdna:55]
Our revenue arrangements do not contain significant financing components as our standard payment terms are less than one year.

[0001628280-23-030374:mdna:56]
If a customer pays consideration, or we have a right to an amount of consideration that is unconditional before we transfer a good or service to the customer, those amounts are classified as deferred revenue or deposits received from customers which are included in other current liabilities or other long-term liabilities when the payment is made or it is due, whichever is earlier.

[0001628280-23-030374:mdna:57]
Transaction Price Allocated to the Remaining Performance Obligations

[0001628280-23-030374:mdna:58]
Remaining performance obligations represent the transaction price allocated to performances obligations that are unsatisfied or partially unsatisfied as of the end of the reporting period. Unsatisfied and partially unsatisfied performance obligations consist of contract liabilities and non-cancellable backlog. Non-cancellable backlog includes goods and services for which customer purchase orders have been accepted that are scheduled or in the process of being scheduled for shipment. A portion of our revenue arises from vendor managed inventory arrangements where the timing and volume of customer utilization is difficult to predict.

[0001628280-23-030374:mdna:59]
Warranty

[0001628280-23-030374:mdna:60]
Hardware products regularly include warranties to the end customers such that the product continues to function according to published specifications. We typically offer a twelvemonth warranty for most of our products. However, in some instances depending upon the product, specific market, product line and geography in which we operate, and what is common in the industry, our warranties can vary and range from six months to five years. These standard warranties are assurance type warranties and do not offer any services in addition to the assurance that the product will continue working as specified.

[0001628280-23-030374:mdna:61]
Therefore, warranties are not considered separate performance obligations in the arrangement. Instead, the expected cost of warranty is accrued as expense in accordance with authoritative guidance.

[0001628280-23-030374:mdna:62]
We provide reserves for the estimated costs of product warranties that we record as cost of sales at the time revenue is recognized. We estimate the costs of our warranty obligations based on our historical experience of known product failure rates, use of materials to repair or replace defective products and service delivery costs incurred in correcting product failures. In addition, from time to time, specific warranty accruals may be made if discrete technical problems arise.

[0001628280-23-030374:mdna:63]
Shipping and Handling Costs

[0001628280-23-030374:mdna:64]
We record shipping and handling costs related to revenue transactions within cost of sales as a period cost.

[0001628280-23-030374:mdna:65]
Contract Costs

[0001628280-23-030374:mdna:66]
We recognize the incremental direct costs of obtaining a contract, which consist of sales commissions, when control over the products they relate to transfers to the customer. Applying the practical expedient, we recognize commissions as expense when incurred, as the amortization period of the commission asset we would have otherwise recognized is less than one year.

[0001628280-23-030374:mdna:67]
Contract Balances

[0001628280-23-030374:mdna:68]
We record accounts receivable when we have an unconditional right to consideration. Contract liabilities are recorded when cash payments are received or due in advance of performance. Contract liabilities consist of advance payments and deferred revenue, where we have unsatisfied performance obligations. Contract liabilities are classified as deferred revenue and customer deposits and are included in other current liabilities within our consolidated balance sheet. Payment terms vary by customer. The time between invoicing and when payment is due is not significant.

[0001628280-23-030374:mdna:69]
The following table reflects the changes in contract balances as of July 1, 2023 (in millions, except percentages):

[0001628280-23-030374:mdna:70]
| Contract balances | Balance sheet location | July 1, 2023 |  | July 2, 2022 |  | Change |  | Percentage Change |
| Accounts receivable, net | Accounts receivable, net | $ | 246.1 |  |  | $ | 262.0 |  |  | $ | (15.9) |  |  | (6.1) | % |
| Deferred revenue and customer deposits | Other current liabilities | $ | 2.1 |  |  | $ | — |  |  | $ | 2.1 |  |  | 100.0 | % |

[0001628280-23-030374:mdna:71]
Disaggregation of Revenue

[0001628280-23-030374:mdna:72]
We disaggregate revenue by geography and by product.  Refer to “Note 19. Revenue Recognition” to the consolidated financial statements for a presentation of disaggregated revenue. We do not present other levels of disaggregation, such as by type of products, customer, markets, contracts, duration of contracts, timing of transfer of control and sales channels, as this information is not used by our Chief Operating Decision Maker (“CODM”) to manage the business.

[0001628280-23-030374:mdna:73]
Income Taxes

[0001628280-23-030374:mdna:74]
In accordance with the authoritative guidance on accounting for income taxes, we recognize income taxes using an asset and liability approach. This approach requires the recognition of taxes payable or refundable for the current year and deferred tax liabilities and assets for the future tax consequences of events that have been recognized in our consolidated financial statements or tax returns. The measurement of current and deferred taxes is based on provisions of the enacted tax law, and the effects of future changes in tax laws or rates are not anticipated.

[0001628280-23-030374:mdna:75]
The authoritative guidance provides for recognition of deferred tax assets if the realization of such deferred tax assets is more likely than not to occur based on an evaluation of both positive and negative evidence and the relative weight of the evidence. We consider future growth, forecasted earnings, future taxable income, the mix of earnings in the jurisdictions in which we operate, historical earnings, taxable income in prior years, if carry-back is permitted under the law, and prudent and feasible tax planning strategies in determining the need for a valuation allowance. In the event we were to determine that we would not be able to realize all or part of our net deferred tax assets in the future, an adjustment to the deferred tax assets valuation allowance would be charged to earnings in the period in which we make such a determination, or goodwill would be adjusted at our final determination of the valuation allowance related to an acquisition within the measurement period. If we later determine that it is more likely than not that the net deferred tax assets would be realized, we would reverse the applicable portion of the previously provided valuation allowance as an adjustment to earnings at such time.

[0001628280-23-030374:mdna:76]
We are subject to income tax audits by the respective tax authorities of the jurisdictions in which we operate. The determination of our income tax liabilities in each of these jurisdictions requires the interpretation and application of complex, and sometimes uncertain, tax laws and regulations. The authoritative guidance on accounting for income taxes prescribes both recognition and measurement criteria that must be met for the benefit of a tax position to be recognized in the financial statements. If a tax position taken, or expected to be taken, in a tax return does not meet such recognition or measurement criteria, an unrecognized tax benefit liability is recorded.  If we ultimately determine that an unrecognized tax benefit liability is no longer necessary, we reverse the liability and recognize a tax benefit in the period in which it is determined that the unrecognized tax benefit liability is no longer necessary.

[0001628280-23-030374:mdna:77]
Our income tax provision is highly dependent upon the geographic distribution of our worldwide earnings or losses, tax laws and regulations in various jurisdictions, tax incentives, the availability of tax credits and loss carryforwards, and the effectiveness of our tax planning strategies. The application of tax laws and regulations is subject to legal and factual interpretation, judgment and uncertainty. Tax laws themselves are subject to change as a result of changes in fiscal policy, changes in legislation, and the evolution of regulations and court rulings and tax audits.

[0001628280-23-030374:mdna:78]
The recognition and measurement of current taxes payable or refundable and deferred tax assets and liabilities requires that we make certain estimates and judgments. Changes to these estimates or a change in judgment may have a material impact on our tax provision in a future period.

[0001628280-23-030374:mdna:79]
Business Combinations

[0001628280-23-030374:mdna:80]
In accordance with the guidance for business combinations, we determine whether a transaction or event is a business combination, which requires that the assets acquired and liabilities assumed constitute a business. Each business combination is then accounted for by applying the acquisition method. If the assets acquired are not a business, we account for the transaction or event as an asset acquisition. Under both methods, we recognize the identifiable assets acquired, the liabilities assumed, and noncontrolling interest, if any, in the acquired entity. We capitalize acquisition-related costs and fees associated with asset acquisitions and immediately expense acquisition-related costs and fees associated with business combinations.

[0001628280-23-030374:mdna:81]
We allocate the fair value of purchase consideration to assets acquired and liabilities assumed based on their estimated fair values at the acquisition date. The excess of the fair value of purchase consideration over the fair values of these identifiable assets and liabilities is recorded as goodwill. We make significant estimates and assumptions to determine assets acquired and liabilities assumed, in particular intangible assets and pre-acquisition contingencies, as applicable.

[0001628280-23-030374:mdna:82]
Critical estimates in valuing intangible assets include, but are not limited to, discount rates and future expected cash flows from customer relationships, acquired developed technology and acquired in-process research and development assets. Our estimates of fair value are based upon assumptions using the best information available. These assumptions are inherently uncertain and unpredictable and, as a result, actual results may differ materially from these estimates.

[0001628280-23-030374:mdna:83]
We may identify certain pre-acquisition contingencies as of the acquisition date and may extend our review and evaluation of these pre-acquisition contingencies throughout the measurement period in order to obtain sufficient information to assess whether these contingencies should be included as a part of the fair value of assets acquired and liabilities assumed and, if so, the amounts to be included.

[0001628280-23-030374:mdna:84]
Certain estimates associated with the accounting for acquisitions may change as additional information becomes available regarding the assets acquired and liabilities assumed. Any change in facts and circumstances that existed as of the acquisition date and impacts to our preliminary estimates is recorded to goodwill if identified within the measurement period. Subsequent to the measurement period or our final determination of fair value of assets and liabilities, whichever is earlier, the adjustments will affect our earnings. Although we believe that the assumptions and estimates we have made in the past have been reasonable and appropriate, they are based in part on historical experience and information obtained from the management of the acquired companies and are inherently uncertain. Unanticipated events and circumstances may occur that may affect the accuracy or validity of such assumptions, estimates or actual results.

[0001628280-23-030374:mdna:85]
Goodwill and Intangible Assets - Impairment Assessment

[0001628280-23-030374:mdna:86]
Goodwill represents the excess of the purchase price of an acquired business over the fair value of the identifiable assets acquired and liabilities assumed. We test goodwill impairment on an annual basis in the fiscal fourth quarter and at any other time when events occur or circumstances indicate that the carrying amount of goodwill may not be recoverable.

[0001628280-23-030374:mdna:87]
We have the option to first assess qualitative factors to determine whether it is necessary to perform the quantitative goodwill impairment test. The qualitative factors we assess include long-term prospects of our performance, share price trends and market capitalization, and Company specific events. Unanticipated events and circumstances may occur that affect the accuracy of our assumptions, estimates and judgments. For example, if the price of our common stock were to significantly decrease combined with other adverse changes in market conditions, thus indicating that the underlying fair value of our reporting units may have decreased, we may reassess the value of our goodwill in the period such circumstances were identified.

[0001628280-23-030374:mdna:88]
If we determine that, as a result of the qualitative assessment, it is more likely than not (i.e., greater than 50% likelihood) that the fair value of a reporting unit is less than its carrying amount, we perform the quantitative test by estimating the fair value of our reporting units. If the carrying value of a reporting unit exceeds its fair value, we record goodwill impairment loss equal to the excess of the carrying value of the reporting unit’s goodwill over its fair value, not to exceed the carrying amount of goodwill. Performing a quantitative goodwill impairment test includes the determination of the fair value of a reporting unit and involves significant estimates and assumptions. These estimates and assumptions include, among others, revenue growth rates and operating margins used to calculate projected future cash flows, risk-adjusted discount rates, future economic and market conditions, and the determination of appropriate market comparables.

[0001628280-23-030374:mdna:89]
We make judgments about the recoverability of purchased finite lived intangible assets whenever events or changes in circumstances indicate that impairment may exist. In such situations, we are required to evaluate whether the net book values of our finite lived intangible assets are recoverable. We determine whether finite lived intangible assets are recoverable based upon the forecasted future cash flows that are expected to be generated by the lowest level associated asset grouping. Assumptions and estimates about future values and remaining useful lives of our intangible assets are complex and subjective and include, among others, forecasted undiscounted cash flows to be generated by certain asset groupings. These assumptions and estimates can be affected by a variety of factors, including external factors such as industry and economic trends and internal factors such as changes in our business strategy and our internal forecasts.

[0001628280-23-030374:mdna:90]
Recently Issued Accounting Pronouncements

[0001628280-23-030374:mdna:91]
Refer to “Note 2. Recently Issued Accounting Pronouncements” to the consolidated financial statements.

[0001628280-23-030374:mdna:92]
50

[0001628280-23-030374:mdna:93]
Results of Operations

[0001628280-23-030374:mdna:94]
The results of operations for the periods presented are not necessarily indicative of results to be expected for future periods. The following table summarizes selected consolidated statements of operations items as a percentage of net revenue:

[0001628280-23-030374:mdna:95]
|  | Years Ended |
|  | July 1, 2023 |  | July 2, 2022 |  | July 3, 2021 |
| Segment net revenue: |  |  |  |  |  |
| OpComms | 88.2 | % |  | 88.7 | % |  | 93.0 | % |
| Lasers | 11.8 |  |  | 11.3 |  |  | 7.0 |  |
| Net revenue | 100.0 |  |  | 100.0 |  |  | 100.0 |  |
| Cost of sales | 63.0 |  |  | 50.3 |  |  | 51.5 |  |
| Amortization of acquired developed intangibles | 4.8 |  |  | 3.7 |  |  | 3.5 |  |
| Gross profit | 32.2 |  |  | 46.0 |  |  | 44.9 |  |
| Operating expenses: |  |  |  |  |  |
| Research and development | 17.4 |  |  | 12.9 |  |  | 12.3 |  |
| Selling, general and administrative | 19.7 |  |  | 15.5 |  |  | 13.9 |  |
| Restructuring and related charges | 1.6 |  |  | (0.1) |  |  | 0.4 |  |
| Merger termination fee and related costs, net | — |  |  | — |  |  | (11.9) |  |
| Total operating expenses | 38.7 |  |  | 28.3 |  |  | 14.7 |  |
| Income (loss) from operations | (6.5) |  |  | 17.7 |  |  | 30.2 |  |
| Interest expense | (2.0) |  |  | (4.7) |  |  | (3.8) |  |
| Other income, net | 2.8 |  |  | 0.7 |  |  | 0.2 |  |
| Income (loss) before income taxes | (5.7) |  |  | 13.7 |  |  | 26.6 |  |
| Income tax provision | 1.7 |  |  | 2.1 |  |  | 3.8 |  |
| Net income (loss) | (7.4) | % |  | 11.6 | % |  | 22.8 | % |

[0001628280-23-030374:mdna:96]
Financial Data for Fiscal 2023, 2022, and 2021

[0001628280-23-030374:mdna:97]
The following table summarizes selected consolidated statements of operations items (in millions, except for percentages):

[0001628280-23-030374:mdna:98]
|  | 2023 |  | 2022 |  | Change |  | Percentage Change |  | 2022 |  | 2021 |  | Change |  | Percentage Change |
| Segment net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| OpComms | $ | 1,557.8 |  |  | $ | 1,518.5 |  |  | $ | 39.3 |  |  | 2.6 | % |  | $ | 1,518.5 |  |  | $ | 1,620.7 |  |  | $ | (102.2) |  |  | (6.3) | % |
| Lasers | 209.2 |  |  | 194.1 |  |  | 15.1 |  |  | 7.8 |  |  | 194.1 |  |  | 122.1 |  |  | 72.0 |  |  | 59.0 |  |
| Net revenue | $ | 1,767.0 |  |  | $ | 1,712.6 |  |  | $ | 54.4 |  |  | 3.2 | % |  | $ | 1,712.6 |  |  | $ | 1,742.8 |  |  | $ | (30.2) |  |  | (1.7) | % |
| Gross profit | $ | 569.0 |  | $ | 788.6 |  | $ | (219.6) |  |  | (27.8) | % |  | $ | 788.6 |  | $ | 783.1 |  | $ | 5.5 |  |  | 0.7 | % |
| Gross margin | 32.2 | % |  | 46.0 | % |  |  |  |  |  | 46.0 | % |  | 44.9 | % |  |  |  |  |
| Research and development | $ | 307.8 |  |  | $ | 220.7 |  |  | $ | 87.1 |  | 39.5 | % |  | $ | 220.7 |  |  | $ | 214.5 |  | $ | 6.2 |  |  | 2.9 | % |
| Percentage of net revenue | 17.4 | % |  | 12.9 | % |  |  |  |  |  | 12.9 | % |  | 12.3 | % |  |  |  |  |
| Selling, general and administrative | $ | 348.8 |  | $ | 265.7 |  | $ | 83.1 |  |  | 31.3 | % |  | $ | 265.7 |  | $ | 241.4 |  | $ | 24.3 |  |  | 10.1 | % |
| Percentage of net revenue | 19.7 | % |  | 15.5 | % |  |  |  |  |  | 15.5 | % |  | 13.9 | % |  |  |  |  |
| Restructuring and related charges | $ | 28.1 |  | $ | (1.1) |  | $ | 29.2 |  |  | N/A |  | $ | (1.1) |  | $ | 7.7 |  | $ | (8.8) |  |  | (114.3) | % |
| Percentage of net revenue | 1.6 | % |  | (0.1) | % |  |  |  |  |  | (0.1) | % |  | 0.4 | % |  |  |  |  |
| Merger termination fee and related costs, net | $ | — |  | $ | — |  | $ | — |  | — | % |  | $ | — |  | $ | (207.5) |  | $ | 207.5 |  |  | N/A |
| Percentage of net revenue | — | % |  | — | % |  |  |  |  |  | — | % |  | (11.9) | % |  |  |  |  |

[0001628280-23-030374:mdna:99]
Net Revenue

[0001628280-23-030374:mdna:100]
Net revenue increased by $54.4 million, or 3.2%, during fiscal 2023 as compared to fiscal 2022, due to a $39.3 million increase in OpComms revenue and a $15.1 million increase in Lasers revenue.

[0001628280-23-030374:mdna:101]
Within OpComms, Telecom and Datacom increased by $315.8 million primarily due to $340.4 million of revenue attributable to the NeoPhotonics acquisition. Additionally, the supply chain shortage in fiscal 2022 was partially relieved, allowing us to meet more customer demand during fiscal 2023. The increase was offset by $67.8 million decrease in Datacom due to reduction in demand associated with inventory management and build-up at our customers and slowing of cloud data center customer capital spending. Industrial and Consumer decreased by $276.5 million primarily due to higher market competition and reflects share normalization in the market.

[0001628280-23-030374:mdna:102]
Lasers net revenue increased by $15.1 million, or 7.8%, during fiscal 2023 as compared to fiscal 2022, primarily due to a return in customer demand for our kilowatt class fiber lasers following a recovery in industrial production earlier in fiscal 2023.

[0001628280-23-030374:mdna:103]
Net revenue decreased by $30.2 million, or 1.7%, during fiscal 2022 as compared to fiscal 2021 due to a $102.2 million decrease in OpComms revenue, partially offset by a $72.0 million increase in Lasers revenue.

[0001628280-23-030374:mdna:104]
OpComms net revenue decreased by $102.2 million, or 6.3%, during fiscal 2022 as compared to fiscal 2021. Within OpComms, Telecom and Datacom decreased by $51.0 million primarily a result of continued material and component shortages for our Telecom products, which impacted our ability to meet demand. Industrial and Consumer decreased by $51.2 million primarily due to a decrease in average selling price for our chips as a result of a smaller chips design.

[0001628280-23-030374:mdna:105]
Lasers net revenue increased by $72.0 million, or 59.0%, during fiscal 2022 as compared to fiscal 2021, primarily due to   a return in customer demand for our kilowatt class fiber lasers following the recent recovery in industrial production.

[0001628280-23-030374:mdna:106]
During our fiscal 2023, 2022 and 2021, net revenue generated from a single customer which represented 10% or greater of total net revenue is summarized as follows:

[0001628280-23-030374:mdna:107]
|  | Years Ended |
|  | July 1, 2023 |  | July 2, 2022 |  | July 3, 2021 |
| Apple | 12.1 | % |  | 28.7 | % |  | 30.2 | % |
| Ciena | 15.3 | % |  | 12.6 | % |  | 10.1 | % |
| Huawei | * |  | * |  | 10.8 | % |
| Nokia | 10.5 | % |  | * |  | * |
| *Represents less than 10% of total net revenue. |  |  |  |  |  |

[0001628280-23-030374:mdna:108]
Revenue by Region

[0001628280-23-030374:mdna:109]
We operate in three geographic regions: Americas, Asia-Pacific, and EMEA (Europe, Middle East, and Africa). Net revenue is assigned to the geographic region and country where our product is initially shipped to. For example, certain customers may request shipment of our product to a contract manufacturer in one country, which may differ from the location of their end customers. The following table presents net revenue by the three geographic regions we operate in and net revenue from countries that represented 10% or more of our total net revenue (in millions, except percentage data):

[0001628280-23-030374:mdna:110]
|  |  |  | Years Ended |
|  |  |  |  |  | July 1, 2023 |  | July 2, 2022 |  | July 3, 2021 |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  |  |  |  |  |  |  |  | $ | 241.3 |  |  | 13.7 | % |  | $ | 173.9 |  |  | 10.2 | % |  | $ | 133.4 |  |  | 7.7 | % |
| Mexico |  |  |  |  |  |  |  |  | 180.0 |  |  | 10.2 |  |  | 160.9 |  |  | 9.4 |  |  | 134.8 |  |  | 7.7 |  |
| Other Americas |  |  |  |  |  |  |  |  | 9.3 |  |  | 0.5 |  |  | 12.1 |  |  | 0.7 |  |  | 12.1 |  |  | 0.7 |  |
| Total Americas |  |  |  |  |  |  |  |  | $ | 430.6 |  |  | 24.4 | % |  | $ | 346.9 |  |  | 20.3 | % |  | $ | 280.3 |  |  | 16.1 | % |
| Asia-Pacific: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Thailand |  |  |  |  |  |  |  |  | $ | 269.0 |  |  | 15.2 | % |  | $ | 102.3 |  |  | 5.9 | % |  | $ | 116.8 |  |  | 6.7 | % |
| Hong Kong |  |  |  |  |  |  |  |  | 246.7 |  |  | 14.0 |  |  | 458.2 |  |  | 26.7 |  |  | 546.3 |  |  | 31.3 |  |
| South Korea |  |  |  |  |  |  |  |  | 170.2 |  |  | 9.6 |  |  | 265.2 |  |  | 15.5 |  |  | 240.0 |  |  | 13.8 |  |
| Japan |  |  |  |  |  |  |  |  | 179.5 |  |  | 10.2 |  |  | 181.2 |  |  | 10.6 |  |  | 114.7 |  |  | 6.6 |  |
| Other Asia-Pacific |  |  |  |  |  |  |  |  | 276.3 |  |  | 15.6 |  |  | 242.4 |  |  | 14.2 |  |  | 304.5 |  |  | 17.5 |  |
| Total Asia-Pacific |  |  |  |  |  |  |  |  | $ | 1,141.7 |  |  | 64.6 | % |  | $ | 1,249.3 |  |  | 72.9 | % |  | $ | 1,322.3 |  |  | 75.9 | % |
| EMEA |  |  |  |  |  |  |  |  | $ | 194.7 |  |  | 11.0 | % |  | $ | 116.4 |  |  | 6.8 | % |  | $ | 140.2 |  |  | 8.0 | % |
| Total net revenue |  |  |  |  |  |  |  |  | $ | 1,767.0 |  |  |  |  | $ | 1,712.6 |  |  |  |  | $ | 1,742.8 |  |  |  |

[0001628280-23-030374:mdna:111]
During fiscal 2023, 2022 and 2021, net revenue from customers outside the United States, based on customer shipping location, represented 86.3%, 89.8% and 92.3% of net revenue, respectively.

[0001628280-23-030374:mdna:112]
Our net revenue is primarily denominated in U.S. dollars, including our net revenue from customers outside the United States as presented above. We expect revenue from customers outside of the United States to continue to be an important part of our overall net revenue and a focus for net revenue growth opportunities. However, regulatory and enforcement actions by the United States and other governmental agencies, as well as changes in tax and trade policies and tariffs, have impacted and may continue to adversely impact net revenue from customers outside the United States.

[0001628280-23-030374:mdna:113]
53

[0001628280-23-030374:mdna:114]
Gross Margin and Segment Gross Margin

[0001628280-23-030374:mdna:115]
The following table summarizes segment gross profit and gross margin for fiscal 2023, 2022 and 2021 (in millions, except for percentages):

[0001628280-23-030374:mdna:116]
|  | Gross Profit |  | Gross Margin |
|  | Years Ended |  | Years Ended |
|  | 2023 |  | 2022 |  | 2021 |  | 2023 |  | 2022 |  | 2021 |
| OpComms | $ | 665.5 |  |  | $ | 780.9 |  |  | $ | 830.2 |  |  | 42.7 | % |  | 51.4 | % |  | 51.2 | % |
| Lasers | 98.0 |  |  | 102.1 |  |  | 57.3 |  |  | 46.8 | % |  | 52.6 | % |  | 46.9 | % |
| Segment total | $ | 763.5 |  |  | $ | 883.0 |  |  | $ | 887.5 |  |  | 43.2 | % |  | 51.6 | % |  | 50.9 | % |
| Unallocated corporate items: |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation | (30.1) |  |  | (20.8) |  |  | (19.2) |  |  |  |  |  |  |  |
| Amortization of acquired intangibles | (84.4) |  |  | (62.9) |  |  | (61.7) |  |  |  |  |  |  |  |
| Amortization of inventory fair value adjustments | (17.8) |  |  | — |  |  | — |  |  |  |  |  |  |  |
| Inventory and fixed asset write down due to product line exits | — |  |  | (0.1) |  |  | (0.4) |  |  |  |  |  |  |  |
| Integration related costs | (12.1) |  |  | — |  |  | — |  |  |  |  |  |  |  |
| Intangible asset write-off (1) | (6.8) |  |  | — |  |  | — |  |  |  |  |  |  |  |
| Other charges, net (2) | (43.3) |  |  | (10.6) |  |  | (23.1) |  |  |  |  |  |  |  |
| Total | $ | 569.0 |  |  | $ | 788.6 |  |  | $ | 783.1 |  |  | 32.2 | % |  | 46.0 | % |  | 44.9 | % |

[0001628280-23-030374:mdna:117]
(1)  During fiscal 2023, we recorded $6.8 million of write-off of developed technologies acquired from IPG, primarily due to product discontinuation as well as changes in customer demand.

[0001628280-23-030374:mdna:118]
(2) Other charges of unallocated corporate items during fiscal 2023 primarily relate to $32.5 million of incremental costs of sales related to components previously acquired from various brokers to satisfy customer demand and $2.7 million of excess and obsolete inventory charges driven by U.S. trade restrictions and the related decline in customer demand.

[0001628280-23-030374:mdna:119]
Other charges of unallocated corporate items during fiscal 2022 primarily relate to $14.0 million of  incremental costs of sales related to components previously acquired from various brokers to satisfy customer demand, offset by a $5.9 million gain from selling equipment that was no longer needed after we transferred certain product lines to new production facilities in fiscal 2021.

[0001628280-23-030374:mdna:120]
Other charges of unallocated corporate items during fiscal 2021 primarily relate to costs of transferring product lines to new production facilities, including Thailand, of $6.9 million, excess and obsolete inventory charges of $7.7 million driven by U.S. trade restrictions and the related decline in customer demand, and fixed asset write-off of $5.0 million associated with excess capacity related to our Fiber laser business.

[0001628280-23-030374:mdna:121]
The unallocated corporate items for the periods presented include the effects of amortization of acquired developed technologies and other intangibles, share-based compensation and certain other charges. We do not allocate these items to the gross margin for each segment because management does not include such information in measuring the performance of the operating segments.

[0001628280-23-030374:mdna:122]
Gross Margin

[0001628280-23-030374:mdna:123]
Gross margin in fiscal 2023 decreased to 32.2% from 46.0% in fiscal 2022, primarily driven by lower gross margin from our OpComms segment, as discussed further below. The lower gross margin was also driven by an aggregate $21.5 million higher amortization of intangible assets due to the NeoPhotonics merger and the acquisition of IPG telecom transmission product lines, $18.5 million higher incremental cost of sales related to components previously acquired from various brokers to satisfy customer demand,  $17.8 million of amortization of acquired inventory step-up, and $17.4 million higher inventory excess and obsolete charges primarily due to company-wide integration efforts as a result of the NeoPhotonics merger and transitions to the next generation of products. Additionally, gross margin was negatively impacted by factory underutilization as a result of a drop in demand as customers actively work to reduce their elevated inventory levels.

[0001628280-23-030374:mdna:124]
Gross margin in fiscal 2022 increased to 46.0% from 44.9% in fiscal 2021, driven by higher gross margin from the Lasers segment due to the higher manufacturing levels and improved factory utilization as a result of return in customer demand for our kilowatt class fiber products following the recent recovery in industrial production. However, these improvements in gross margin were partially offset by $14.0 million of charges to acquire components from various brokers to satisfy customer demand.

[0001628280-23-030374:mdna:125]
The markets in which we sell products are consolidating, undergoing product, architectural and business model transitions, have high customer concentrations, are highly competitive, are price sensitive and/or are affected by customer seasonal and have variant buying patterns. We expect these factors to result in variability of our gross margin.

[0001628280-23-030374:mdna:126]
Due to the global supply chain constraint, we incurred incremental supply and procurement costs in order to increase our ability to fulfill demands from our customers. As of July 1, 2023, our inventory balance includes $6.1 million of incremental supply and procurement costs.

[0001628280-23-030374:mdna:127]
Segment Gross Margin

[0001628280-23-030374:mdna:128]
OpComms

[0001628280-23-030374:mdna:129]
OpComms gross margin in fiscal 2023 decreased to 42.7% as compared from 51.4% in fiscal 2022. The decrease was primarily due to a less profitable mix of products, including lower sales of higher margin imaging and sensing products, as well as higher sales of lower margin telecom products due to the merger with NeoPhotonics. Additionally, OpComms gross margin was negatively impacted by factory underutilization as a result of a drop in demand as customers actively work to reduce their elevated inventory levels.

[0001628280-23-030374:mdna:130]
OpComms gross margin in fiscal 2022 remained relatively flat at 51.4% compared to 51.2% in fiscal 2021.

[0001628280-23-030374:mdna:131]
Lasers

[0001628280-23-030374:mdna:132]
Lasers gross margin in fiscal 2023 decreased to 46.8% from 52.6% in fiscal 2022. The decrease was primarily due to lower revenue from high margin solid-state lasers, as well as increased excess and obsolete charges due to transitions to the next generation of products.

[0001628280-23-030374:mdna:133]
Lasers gross margin in fiscal 2022 increased to 52.6% from 46.9% in fiscal 2021. The increase was primarily due to the higher manufacturing levels and improved factory utilization as a result of return in customer demand for our kilowatt class fiber products following the recent recovery in industrial production.

[0001628280-23-030374:mdna:134]
Research and Development (“R&D”)

[0001628280-23-030374:mdna:135]
R&D expense increased by $87.1 million, or 39.5%, in fiscal 2023 as compared to fiscal 2022.  The increase in R&D expense is attributable to an increase in payroll and employee compensation related expenses due to additional headcount from the merger with NeoPhotonics and the acquisition of IPG telecom transmission product lines. In addition, we recognized a $12.9 million write-off of in-process research and development intangible assets associated with our NeoPhotonics acquisition for projects that we will no longer pursue.

[0001628280-23-030374:mdna:136]
R&D expense increased by $6.2 million, or 2.9%, in fiscal 2022 as compared to fiscal 2021. The increase in R&D expense was primarily driven by a $4.1 million increase in new product development activities in our factories, and a $2.6 million increase in share-based compensation.

[0001628280-23-030374:mdna:137]
We believe that continuing our investments in R&D is critical to attaining our strategic objectives. Despite signs of a weaker macroeconomic environment, we plan to continue to invest in R&D and new products that we believe will further differentiate us in the marketplace and we expect to continue to invest significant R&D in the future.

[0001628280-23-030374:mdna:138]
Selling, General and Administrative (“SG&A”)

[0001628280-23-030374:mdna:139]
SG&A expense increased by $83.1 million, or 31.3%, in fiscal 2023 as compared to fiscal 2022. The increase in SG&A expense was primarily driven by an increase in payroll and employee compensation related expenses due to additional headcount from the merger with NeoPhotonics and higher stock-based compensation. The increase was also attributable to incremental facility costs and $20.7 million of incremental amortization of intangibles due to the NeoPhotonics merger and the acquisition of IPG telecom transmission product lines. Additionally, in connection with the NeoPhotonics merger, certain equity awards for NeoPhotonics employees were accelerated. We recognized $11.9 million of stock-based compensation associated with the acceleration during the first quarter of fiscal year 2023. We also recognized $11.5 million of merger and acquisition related costs, primarily professional service fees and retention expenses related to the NeoPhotonics merger and the acquisition of IPG telecom transmission product lines. Furthermore, we recognized $7.8 million of expense with respect to the pending settlement of certain non-ordinary course litigation matters. For a description of our material pending legal proceedings, refer to “Note 17. Commitments and Contingencies” to the consolidated financial statements.

[0001628280-23-030374:mdna:140]
SG&A expense increased by $24.3 million, or 10.1%, in fiscal 2022 as compared to fiscal 2021. The increase in SG&A expense for fiscal 2022 was primarily due to a $13.9 million increase in outside services and professional fees related to the NeoPhotonics acquisition and increased investments in information technology and professional service fees for optimizing our international legal structure, as well as a $6.0 million increase in share-based compensation primarily due to increased employee headcount.

[0001628280-23-030374:mdna:141]
From time to time, we incur expenses that are not part of our ordinary operations, such as mergers and acquisition-related and litigation expenses, which generally increase our SG&A expenses and potentially impact our profitability expectations in any particular period.

[0001628280-23-030374:mdna:142]
Restructuring and Related Charges

[0001628280-23-030374:mdna:143]
We have initiated various strategic restructuring events primarily intended to reduce costs, consolidate our operations, rationalize the manufacturing of our products, align our business in response to market conditions, and as a result of our merger with NeoPhotonics.

[0001628280-23-030374:mdna:144]
During fiscal 2023, we recorded restructuring and related charges of $28.1 million, which were primarily attributable to company-wide integration efforts as a result of the merger with NeoPhotonics, our cost reduction initiatives, as well as severance and employee-related benefits associated with NeoPhotonics’ executive severance and retention agreements. These agreements provided for payments and benefits upon an involuntary termination of employment under certain circumstances.

[0001628280-23-030374:mdna:145]
During fiscal 2022, we recorded a net reversal to our restructuring and related charges of $1.1 million, which was attributable to lower than anticipated employee severance charges primarily as a result of retaining and re-assigning certain employees.

[0001628280-23-030374:mdna:146]
During fiscal 2021, we recorded $7.7 million in restructuring and related charges in our consolidated statements of operations. The charges were primarily attributable to severance charges associated with the decision to move certain manufacturing from San Jose, California, as well as other cost reduction measures taken across the Company impacting all regions.

[0001628280-23-030374:mdna:147]
Refer to “Note 12. Restructuring and Related Charges” to the consolidated financial statements.

[0001628280-23-030374:mdna:148]
Merger Termination Fee and Related Costs, Net

[0001628280-23-030374:mdna:149]
On January 18, 2021, we entered into a merger agreement with Coherent, under which we would acquire all outstanding shares of Coherent common stock. In March 2021, Coherent terminated the merger agreement and paid us a termination fee of $217.6 million in accordance with the merger agreement. For the year ended July 3, 2021, we recorded $217.6 million gain related to the receipt of a termination fee from Coherent in March 2021 as a result of the termination of the merger agreement. This gain was offset by $10.1 million of Coherent acquisition related charges and the net balance of $207.5 million is presented as “merger termination fee and related costs, net” in our consolidated statements of operations for the year ended July 3, 2021.

[0001628280-23-030374:mdna:150]
Interest Expense

[0001628280-23-030374:mdna:151]
Our interest expense is as follows for the years presented (in millions):

[0001628280-23-030374:mdna:152]
|  |  |  | Years Ended |
|  |  |  | July 1, 2023 |  | July 2, 2022 |  | July 3, 2021 |
| Interest expense |  |  | $ | 35.5 |  |  | $ | 80.2 |  |  | $ | 66.7 |  |

[0001628280-23-030374:mdna:153]
Interest expense is driven by the amortization of the debt discount and issuance costs of our convertible notes.

[0001628280-23-030374:mdna:154]
Interest expense in fiscal 2023 decreased by $44.7 million, or 55.7%, from fiscal 2022, primarily due to the adoption of ASU 2020-06 in our first quarter of fiscal 2023, which requires us to record each of our 2026 Notes and 2028 Notes as a single liability, measured at amortized cost, eliminating the interest expense associated with the debt discount.

[0001628280-23-030374:mdna:155]
Interest expense in fiscal 2022 increased by $13.5 million, or 20.2%, from fiscal 2021, as a result of issuing $861.0 million in aggregate principal amount of 2028 Notes in March 2022.

[0001628280-23-030374:mdna:156]
Other Income, Net

[0001628280-23-030374:mdna:157]
The components of other income, net are as follows for the years presented (in millions):

[0001628280-23-030374:mdna:158]
|  |  |  | Years Ended |  |
|  |  |  | July 1, 2023 |  | July 2, 2022 |  | July 3, 2021 |  |
| Foreign exchange gains (losses), net |  |  | $ | 7.0 |  |  | $ | 6.1 |  |  | $ | (4.4) |  |  |
| Interest and investment income |  |  | 40.8 |  |  | 6.1 |  |  | 5.7 |  |  |
| Other income (expense), net |  |  | 1.0 |  |  | (0.2) |  |  | 1.5 |  |  |
| Other income, net |  |  | $ | 48.8 |  |  | $ | 12.0 |  |  | $ | 2.8 |  |  |

[0001628280-23-030374:mdna:159]
Other income, net in fiscal 2023 increased by $36.8 million from fiscal 2022 due to an increase in interest and investment income of $34.7 million driven by an increase in interest rates on our fixed income securities and increase in net foreign exchange gain of $0.9 million as a result of the strengthening of the U.S. dollar relative to most foreign currencies. Additionally, concurrent with the issuance of the 2029 Notes, we used $132.8 million of the net proceeds to repurchase $125.0 million aggregate principal amount of the 2024 Notes. We recognized a gain of $1.0 million related to the repurchase, which was recorded under other income, net in fiscal 2023.

[0001628280-23-030374:mdna:160]
Other income, net in fiscal 2022 increased by $9.2 million from fiscal 2021 primarily due to $10.5 million more in foreign exchange gains as a result of a strengthening U.S. dollar relative to other foreign currencies, offset by $1.7 million decrease in other income.

[0001628280-23-030374:mdna:161]
Provision for Income Taxes

[0001628280-23-030374:mdna:162]
|  |  | Years Ended |
| (in millions) |  | July 1, 2023 |  | July 2, 2022 |  | July 3, 2021 |
| Income tax provision |  | $ | 29.2 |  |  | $ | 36.2 |  |  | $ | 65.8 |  |

[0001628280-23-030374:mdna:163]
Our  provision for income taxes for  fiscal 2023 differs from the 21% U.S. statutory rate primarily due to the income tax expense from foreign income inclusions in the U.S., earnings of our foreign subsidiaries being taxed at rates that differ from the U.S. statutory rate and non-deductible stock-based compensation. Additionally, our provision for income taxes includes income tax benefits from various tax credits and change in valuation allowance as it is more-likely-than-not that certain deferred tax assets will be realizable in the future. During fiscal 2023, we also effectuated certain tax planning actions which reduced the amount of Base Erosion Anti-Abuse Tax (BEAT) for fiscal 2022.

[0001628280-23-030374:mdna:164]
Our provision for income taxes for fiscal 2022 differs from the 21% U.S. statutory rate primarily due to the income tax benefit from earnings of our foreign subsidiaries being taxed at rates that differ from the U.S. statutory rate, offset by the tax expense from foreign income inclusions in the U.S. Additionally, our provision for income taxes includes income tax benefits from various tax credits, offset by an income tax expense from non-deductible stock-based compensation and change in valuation allowance as it is not more-likely-than-not that certain deferred tax assets will be realizable in the future.

[0001628280-23-030374:mdna:165]
Our provision for income taxes for fiscal 2021 differs from the 21% U.S. statutory rate primarily due to the income tax benefit from earnings of our foreign subsidiaries being taxed at rates that differ from the U.S. statutory rate, which is offset by the tax expense from foreign income inclusions in the U.S. Additionally, our provision for income taxes includes income tax benefit from various tax credits and non-U.S. statutory rate changes enacted during the year, offset by an income tax expense from non-deductible stock-based compensation and change in valuation allowance as it is not more-likely-than-not that certain deferred tax assets will be realizable in the future.

[0001628280-23-030374:mdna:166]
Our provision for incomes taxes may be affected by changes in the geographic mix of earnings, acquisitions, changes in the realizability of deferred tax assets, changes in contingent tax liabilities, the results of income tax audits, settlements with tax authorities, the expiration of statutes of limitations, the implementation of tax planning strategies, tax rulings, court decisions, and changes in tax laws and regulations. It is also possible that significant negative or positive evidence may become available that causes us to change our conclusion regarding whether a valuation allowance is needed on certain of our deferred tax assets, which would affect our income tax provision in the period of such change. For additional information, refer to Item 1A “Risk Factors” of this Annual Report.

[0001628280-23-030374:mdna:167]
Defined Benefit Plans

[0001628280-23-030374:mdna:168]
The Company sponsors defined benefit pension plans covering employees in Japan, Switzerland, and Thailand. Pension plan benefits are based primarily on participants’ compensation and years of service credited as specified under the terms of each country’s plan. Employees are entitled to a lump sum benefit upon retirement or upon certain instances of termination.  The funding policy is consistent with the local requirements of each country. As of July 1, 2023, the defined benefit plans in Switzerland were partially funded, while defined benefit plans in Japan and Thailand were unfunded. As of July 1, 2023, our projected benefit obligations, net, in Japan, Switzerland, and Thailand were $4.2 million, $3.3 million and $3.9 million, respectively. They were recorded in our consolidated balance sheets as accrued payroll and related expenses for the current portion while other non-current liabilities for the non-current portion, and represent the total projected benefit obligation (“PBO”) less the fair value of plan assets.

[0001628280-23-030374:mdna:169]
A key actuarial assumption in calculating the net periodic cost and the PBO is the discount rate. Changes in the discount rate impact the interest cost component of the net periodic benefit cost calculation and PBO due to the fact that the PBO is calculated on a net present value basis. Decreases in the discount rate will generally increase pre-tax cost, recognized expense and the PBO. Increases in the discount rate tend to have the opposite effect. We estimate a 100 basis point decrease or increase in the discount rate would cause a corresponding increase or decrease of $20.4 million or $14.7 million, respectively, in the PBO based upon data as of July 1, 2023.

[0001628280-23-030374:mdna:170]
We expect to contribute $2.2 million to our defined benefit pension plans in fiscal 2024.

[0001628280-23-030374:mdna:171]
Financial Condition

[0001628280-23-030374:mdna:172]
Liquidity and Capital Resources

[0001628280-23-030374:mdna:173]
As of July 1, 2023 and July 2, 2022, our cash and cash equivalents of $859.0 million and $1,290.2 million, respectively, were largely held in the United States. As of July 1, 2023 and July 2, 2022, our short-term investments of $1,154.6 million and $1,258.8 million, respectively, were all held in the United States. Cash equivalents and short-term investments are primarily comprised of money market funds, treasuries, agencies, high quality investment grade fixed income securities, certificates of deposit, and commercial paper. Our investment policy and strategy is focused on the preservation of capital and supporting our liquidity requirements.

[0001628280-23-030374:mdna:174]
The total amount of cash outside the United States held by the non-U.S. entities as of July 1, 2023 was $298.4 million, which was primarily held by entities incorporated in the United Kingdom, the British Virgin Islands, Japan, Hong Kong, China, Switzerland, the Cayman Islands, and Thailand. Although the cash currently held in the United States, as well as the cash generated in the United States from future operations, is expected to cover our normal operating requirements, a substantial amount of additional cash could be required for other purposes, such as capital expenditures to support our business and growth, including costs associated with increasing internal manufacturing capabilities, particularly in our Thailand facility, strategic transactions and partnerships, and future acquisitions.

[0001628280-23-030374:mdna:175]
Our intent is to indefinitely reinvest funds held outside the United States and, except for the funds held in the Cayman Islands, the British Virgin Islands, and Hong Kong, as well as certain subsidiaries in China and Japan, our current plans do not demonstrate a need to repatriate them to fund our domestic operations. However, if in the future, we encounter a significant need for liquidity domestically or at a particular location that we cannot fulfill through borrowings, equity offerings, or other internal or external sources, or the cost to bring back the money is not significant from a tax perspective, we may determine that cash repatriations are necessary or desirable. Repatriation could result in additional material taxes. These factors may cause us to have an overall tax rate higher than other companies or higher than our tax rates in the past. Additionally, if conditions warrant, we may seek to obtain additional financing through debt or equity sources. To the extent we issue additional shares, it may create dilution to our existing stockholders. However, any such financing may not be available on terms favorable to us or may not be available at all.

[0001628280-23-030374:mdna:176]
Beginning in fiscal 2023, the Tax Cuts and Jobs Act of 2017 requires taxpayers to capitalize research and development expenditures and amortize domestic expenditures over five years and foreign expenditures over fifteen years. This will delay deductibility of these expenses and potentially increase the amount of cash taxes we pay in the next several years.

[0001628280-23-030374:mdna:177]
Indebtedness

[0001628280-23-030374:mdna:178]
On June 16, 2023, we issued $603.7 million in aggregate principal amount of 2029 Notes. The net proceeds from the issuance of the 2029 Notes was $599.4 million, after deducting $4.3 million of net issuance costs. In addition, we incurred $0.8 million of professional fees directly related to this transaction. Concurrent with the issuance of the 2029 Notes, we used $132.8 million of the net proceeds to repurchase $125.0 million aggregate principal amount of the 2024 Notes and $125.0 million of the net proceeds to repurchase our common stock in privately negotiated transactions. Refer to “Note 10. Debt” to the consolidated financial statements.

[0001628280-23-030374:mdna:179]
As of July 1, 2023, the net carrying amount of our 2029 Notes of $598.6 (principal balance of $603.7 million maturing in 2029) is presented in non-current liabilities. If the closing price of our stock exceeds $90.40  for 20 of the last 30 trading days in any future quarter, our 2029 Notes would become convertible at the option of the holders during the subsequent fiscal quarter and the debt would be reclassified to current liabilities in our consolidated balance sheets.

[0001628280-23-030374:mdna:180]
As of July 1, 2023, the net carrying amount of our 2028 Notes of $855.5 million (principal balance of $861.0 million maturing in 2028) is presented in non-current liabilities. If the closing price of our stock exceeds $170.34 for 20 of the last 30 trading days in any future quarter, our 2028 Notes would also become convertible at the option of the holders and the debt component would be reclassified to current liabilities in our condensed consolidated balance sheet.

[0001628280-23-030374:mdna:181]
As of July 1, 2023, the net carrying amount of our 2026 Notes of $1,045.9 million (principal balance of $1,050.0 maturing in 2026) is presented in non-current liabilities. If the closing price of our stock exceeds $129.08 for 20 of the last 30 trading days in any future quarter, our 2026 Notes would also become convertible at the option of the holders and the debt component would be reclassified to current liabilities in our condensed consolidated balance sheet.

[0001628280-23-030374:mdna:182]
As of July 1, 2023, the net carrying amount of the debt component of our 2024 Notes of $311.6 million (principal balance of $323.1 million maturing in 2024) is presented in short-term liabilities as the debt will mature on March 15, 2024. During the year ended July 1, 2023, we received conversion requests of less than $0.1 million principal amount of the 2024 Notes, which we settled with cash in accordance with the 2024 Indenture (as defined below). Since issuing the 2024 Notes, we have converted a total of approximately $1.9 million principal amount of the 2024 Notes.

[0001628280-23-030374:mdna:183]
Refer to “Note 10. Debt” to the consolidated financial statements for more information.

[0001628280-23-030374:mdna:184]
Share Repurchases

[0001628280-23-030374:mdna:185]
Repurchase Made in Connection with Convertible Note Offering

[0001628280-23-030374:mdna:186]
In fiscal 2023, concurrent with the issuance of the 2029 Notes, we repurchased 2.3 million shares of our common stock in privately negotiated transactions at an average price of $53.49 per share for an aggregate purchase price of $125.0 million. We recorded the aggregate purchase price as a reduction of retained earnings within our consolidated balance sheet.  These shares were retired immediately.

[0001628280-23-030374:mdna:187]
In fiscal 2022, concurrent with the issuance of the 2028 Notes, we repurchased 2.0 million shares of our common stock in privately negotiated transactions at an average price of $99.0 per share for an aggregate purchase price of approximately $200.0 million. We recorded the  aggregate purchase price as a reduction of retained earnings within our consolidated balance sheet and retired these shares immediately.

[0001628280-23-030374:mdna:188]
Share Buyback Program

[0001628280-23-030374:mdna:189]
On May 7, 2021, our board of directors approved the 2021 share buyback program, which authorizes us to use up to $700.0 million to purchase our own shares of common stock.  On March 3, 2022, our board of directors approved an increase in our share buyback program, which authorizes us to use up to an aggregate amount of $1.0 billion (an increase from $700.0 million) to purchase our own shares of common stock through May 2024. On April 5, 2023, our board of directors approved a further increase in our share buyback program to authorize us to use up to an aggregate amount of $1.2 billion (an increase from $1.0 billion) to purchase our own shares of common stock through May 2025.

[0001628280-23-030374:mdna:190]
During fiscal 2023, we repurchased 0.7 million shares of our common stock as part of the share buyback program at an average price of $65.03 per share for an aggregate purchase price of $40.5 million. During fiscal 2022, we repurchased 4.0 million shares of our common stock as part of the share buyback program at an average price of $87.21 per share for an aggregate purchase price of $348.9 million. Since the appoval of the share buyback program by the board of directors, we have repurchased 7.7 million shares in aggregate at an average price of $81.66 per share for a total purchase price of $630.4 million. We recorded the $630.4 million aggregate purchase price as a reduction of retained earnings within our consolidated balance sheets. All repurchased shares were retired immediately. As of July 1, 2023, we have $569.6 million remaining under the share buyback program.

[0001628280-23-030374:mdna:191]
The price, timing, amount, and method of future repurchases will be determined based on the evaluation of market conditions and other factors, at prices determined to be in the best interests of the Company and our stockholders. The stock buyback program may be suspended or terminated at any time.

[0001628280-23-030374:mdna:192]
Contractual Obligations

[0001628280-23-030374:mdna:193]
The following table summarizes our contractual obligations as of July 1, 2023, and the effect such obligations are expected to have on our liquidity and cash flow (in millions):

[0001628280-23-030374:mdna:194]
|  | Payments due |
|  | Total |  | Less than 1 year |  | More than 1 year |
| Contractual Obligations |  |  |  |  |  |
| Asset retirement obligations | $ | 8.2 |  |  | $ | — |  |  | $ | 8.2 |  |
| Operating lease liabilities, including imputed interest (1) | 67.8 |  |  | 16.1 |  |  | 51.7 |  |
| Pension plan contributions (2) | 2.2 |  |  | 2.2 |  |  | — |  |
| Purchase obligations (3) | 348.9 |  |  | 308.5 |  |  | 40.4 |  |
| Convertible notes - principal (4) | 2,837.8 |  |  | 323.1 |  |  | 2,514.7 |  |
| Convertible notes - interest (4) | 100.0 |  |  | 19.9 |  |  | 80.1 |  |
| Total | $ | 3,364.9 |  |  | $ | 669.8 |  |  | $ | 2,695.1 |  |

[0001628280-23-030374:mdna:195]
(1) The amounts of operating lease liabilities do not include any sublease income amounts nor do they include payments for short-term leases or variable lease payments. As of July 1, 2023, we expect to receive sublease income of approximately $1.8 million over the next year. Refer to “Note 8. Leases” to the consolidated financial statements.

[0001628280-23-030374:mdna:196]
(2) The amount of pension plan contributions represents planned contributions to our defined benefit plans. Although additional future contributions will be required, the amount and timing of these contributions will be affected by actuarial assumptions, the actual rate of returns on plan assets, the level of market interest rates, legislative changes, and the amount of voluntary contributions to the plan. Any contributions for the following fiscal year and later will depend on the value of the plan assets in the future and thus are uncertain. As such, we have not included any amounts beyond one year in the table above.  Refer to “Note 16. Employee Retirement Plans” to the consolidated financial statements.

[0001628280-23-030374:mdna:197]
(3) Purchase obligations represent legally binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Refer to “Note 17. Commitments and Contingencies” to the consolidated financial statements.

[0001628280-23-030374:mdna:198]
(4) The amounts related to convertible notes include principal and interest on our 0.25% Convertible Senior Notes due in 2024 (the “2024 Notes”), principal and interest on our 0.50% Convertible Senior Notes due in 2026 (the “2026 Notes”), principal and interest on our 0.50% Convertible Notes due in 2028 (the “2028 Notes”), and principal and interest on our 1.50% Convertible Notes due in 2029 (the “2029 Notes”). The 2024 Notes have a maturity date of March 15, 2024, the 2026 Notes have a maturity date of December 15, 2026, the 2028 Notes have a maturity date of June 15, 2028, and the 2029 Notes have a maturity date of December 15, 2029. The principal balances of our convertible notes are reflected in the payment periods in the table above based on their respective contractual maturities assuming no conversions. Refer to “Note 10. Debt” to the consolidated financial statements.

[0001628280-23-030374:mdna:199]
Unrecognized Tax Benefits

[0001628280-23-030374:mdna:200]
As of July 1, 2023, our other non-current liabilities also include $64.4 million of unrecognized tax benefit for uncertain tax positions. We are unable to reliably estimate the timing of future payments related to uncertain tax positions.

[0001628280-23-030374:mdna:201]
Liquidity and Capital Resources Requirements

[0001628280-23-030374:mdna:202]
We believe that our cash and cash equivalents as of July 1, 2023, and cash flows from our operating activities will be sufficient to meet our liquidity and capital spending requirements for at least the next 12 months.

[0001628280-23-030374:mdna:203]
There are a number of factors that could positively or negatively impact our liquidity position, including:

[0001628280-23-030374:mdna:204]
•global economic conditions which affect demand for our products and services and impact the financial stability of our suppliers and customers, including the impact of uncertainty in the banking and financial services industries as well as COVID-19;

[0001628280-23-030374:mdna:205]
•fluctuations in demand for our products as a result of changes in regulations, tariffs or other trade barriers, and trade relations in general;

[0001628280-23-030374:mdna:206]
•changes in accounts receivable, inventory or other operating assets and liabilities, which affect our working capital;

[0001628280-23-030374:mdna:207]
•increase in capital expenditures to support our business and growth, including increases in manufacturing capacity;

[0001628280-23-030374:mdna:208]
•the tendency of customers to delay payments or to negotiate favorable payment terms to manage their own liquidity positions;

[0001628280-23-030374:mdna:209]
•timing of payments to our suppliers;

[0001628280-23-030374:mdna:210]
•volatility in fixed income and credit, which impact the liquidity and valuation of our investment portfolios;

[0001628280-23-030374:mdna:211]
•cost and availability of credit, which may impact available financing for us, our customers or others with whom we do business;

[0001628280-23-030374:mdna:212]
•volatility in foreign exchange markets, which impacts our financial results;

[0001628280-23-030374:mdna:213]
•possible investments or acquisitions of complementary businesses, products or technologies, or other strategic transactions or partnerships;

[0001628280-23-030374:mdna:214]
•issuance of debt or equity securities, or other financing transactions, including bank debt;

[0001628280-23-030374:mdna:215]
•potential funding of pension liabilities either voluntarily or as required by law or regulation;

[0001628280-23-030374:mdna:216]
•other acquisitions or strategic transactions;

[0001628280-23-030374:mdna:217]
•the settlement of any conversion or redemption of our convertible notes in cash; and

[0001628280-23-030374:mdna:218]
•common stock repurchases under the share buyback program.

[0001628280-23-030374:mdna:219]
Cash Flows

[0001628280-23-030374:mdna:220]
Fiscal 2023

[0001628280-23-030374:mdna:221]
As of July 1, 2023, our consolidated balance of cash and cash equivalents decreased by $431.2 million, to $859.0 million from $1,290.2 million as of July 2, 2022. The decrease in cash and cash equivalents was due to cash used in investing activities of $874.0 million, partially offset by cash provided by financing activities of $263.0 million and operating activities of $179.8 million during the year ended July 1, 2023.

[0001628280-23-030374:mdna:222]
Cash provided by operating activities was $179.8 million during the year ended July 1, 2023, which reflects the net loss of $131.6 million and non-cash items of $448.0 million, partially offset by $136.6 million of changes in our operating assets and liabilities.

[0001628280-23-030374:mdna:223]
Cash used in investing activities of $874.0 million during the year ended July 1, 2023 was primarily attributable to the merger with NeoPhotonics and the acquisition of IPG telecom transmission product lines in the amount of $861.6 million, net of cash acquired and capital expenditures of $128.5 million, partially offset by net proceeds from sales or maturities of short-term investments of $115.7 million.

[0001628280-23-030374:mdna:224]
Cash provided by financing activities of $263.0 million during the year ended July 1, 2023, was primarily a result of proceeds from the issuance of the 2029 Notes, net of issuance costs of $599.4 million, partially offset by the repurchase of shares of our common stock of $175.6 million, repurchase of our 2024 Notes of $132.8 million and tax payments related to the net share settlement of restricted stock of $37.2 million.

[0001628280-23-030374:mdna:225]
Fiscal 2022

[0001628280-23-030374:mdna:226]
As of July 2, 2022,  our consolidated balance of cash and cash equivalents increased by $515.9 million, to $1,290.2 million from $774.3 million as of July 3, 2021. The increase in cash and cash equivalents was primarily due to cash provided by operating activities of $459.3 million and financing activities of $282.9 million, partially offset by cash used in investing activities of $226.3 million during the year ended July 2, 2022.

[0001628280-23-030374:mdna:227]
Cash provided by operating activities was $459.3 million during the year ended July 2, 2022, which reflects net income of $198.9 million and non-cash items of $351.0 million, partially offset by $90.6 million of changes in our operating assets and liabilities.

[0001628280-23-030374:mdna:228]
Cash used in investing activities of $226.3 million during the year ended July 2, 2022 was attributable to purchases of short-term investments, net of sales and maturities of $111.5 million, capital expenditures of $91.2 million, and a $30.0 million term loan provided to NeoPhotonics to support their on-going growth plans through the anticipated merger completion, partially offset by proceeds from the sales of property, plant and equipment of $6.4 million. The term loan to NeoPhotonics is described in “Note 4. Business Combination” to the consolidated financial statements.

[0001628280-23-030374:mdna:229]
Cash provided by financing activities of $282.9 million during the year ended July 2, 2022, was primarily a result of proceeds from the issuance of the 2028 Notes, net of issuance costs of $854.1 million and proceeds from employee stock plans of $13.5 million, partially offset by the repurchase of shares of our common stock of $543.9 million, tax payments related to the net share settlement of restricted stock of $39.0 million, and $1.8 million to settle conversion requests for the principal amount of the 2024 Notes.

[0001628280-23-030374:mdna:230]
Fiscal 2021

[0001628280-23-030374:mdna:231]
As of July 3, 2021,  our consolidated balance of cash and cash equivalents increased by $476.3 million, to $774.3 million from $298.0 million as of June 27, 2020. The increase in cash and cash equivalents was primarily due to cash provided by operating activities of $738.7 million and investing activities of $1.0 million, offset by cash used in financing activities of $263.4 million during the year ended July 3, 2021.

[0001628280-23-030374:mdna:232]
Cash provided by operating activities was $738.7 million during the year ended July 3, 2021. Our net income was $397.3 million for the year ended July 3, 2021 and included the merger termination fee paid by Coherent, net of related costs of $207.5 million. Cash provided by operating activities was also generated from $339.9 million of non-cash items, offset by $1.5 million of changes in our operating assets and liabilities.

[0001628280-23-030374:mdna:233]
Cash provided by investing activities of $1.0 million during the year ended July 3, 2021 was primarily attributable to proceeds from maturities and sales of short-term investments, net of purchases of $71.2 million and proceeds from sales of product lines of $1.3 million and sales of property and equipment of $23.3 million. However, we had capital expenditures of $84.8 million and a payment for an asset acquisition of $10.0 million.

[0001628280-23-030374:mdna:234]
Cash used in financing activities of $263.4 million during the year ended July 3, 2021, was primarily resulted from the repurchase of shares of our common stock of $236.0 million and tax payments related to restricted stock of $39.7 million, offset by the proceeds from employee stock plans of $12.6 million.
