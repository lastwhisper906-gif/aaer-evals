# LITE notes — 0001628280-23-030374


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001628280-23-030374:notes:1]
Portions of the information called for by Part III of this Annual Report on Form 10-K are hereby incorporated by reference from the definitive proxy statement for the Registrant’s annual meeting of stockholders, which will be filed with the Securities and Exchange Commission not later than 120 days after the Registrant’s fiscal year ended July 1, 2023.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001628280-23-030374:notes:2]
Note 1. Description of Business and Summary of Significant Accounting Policies

[0001628280-23-030374:notes:3]
Description of Business

[0001628280-23-030374:notes:4]
Lumentum Holdings Inc. (“we,” “us,” “our”, “Lumentum” or the “Company”) is an industry-leading provider of optical and photonic products addressing a range of end market applications including Optical Communications (“OpComms”) and Commercial Lasers (“Lasers”) for manufacturing, inspection and life-science applications. We seek to use our core optical and photonic technology, and our volume manufacturing capability, to expand into attractive emerging markets that benefit from advantages that optical or photonics-based solutions provide, including imaging and sensing for consumer electronics and diode light sources for a variety of consumer and industrial applications. The majority of our customers have historically been, and are currently, original equipment manufacturers (“OEMs”) that incorporate our products into their products, which then address end-market applications. For example, we sell fiber optic components that network equipment manufacturers (“NEMs”) assemble into communications networking systems, which they sell to communications service providers, hyperscale cloud operators, and enterprises with their own networks. Similarly, many of our Lasers products customers incorporate our products into tools they produce, which are used for manufacturing processes by their customers. For imaging and sensing, we sell diode lasers to manufacturers of consumer electronics products for mobile, personal computing, gaming, and other applications, including to the automotive industry, who then integrate our devices within their products, for eventual resale to consumers and also into other industrial applications.

[0001628280-23-030374:notes:5]
Basis of Presentation

[0001628280-23-030374:notes:6]
We have prepared the consolidated financial statements in accordance with U.S. generally accepted accounting principles (“GAAP”), which requires management to make estimates and assumptions that affect the amounts reported in our consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates. Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. These policies are inventory valuation, revenue recognition, income taxes, goodwill and business combinations.

[0001628280-23-030374:notes:7]
Our business and operating results depend significantly on general market and economic conditions. The current global macroeconomic environment is volatile and continues to be adversely impacted by inflation, a dynamic supply chain and demand environment, and signs of a weaker macroeconomic environment impacting capital expenditures across our served markets. Additionally, instability in the global credit markets, the impact of uncertainty regarding global central bank monetary policy, capital expenditure reductions, unemployment and other labor issues, stock market volatility, the instability in the geopolitical environment in many parts of the world, and the current global economic challenges continue to put pressure on our business and operating results.

[0001628280-23-030374:notes:8]
While the impact of the COVID-19 pandemic is lessening, the duration and severity of the impact of the pandemic on our business and results of operations in future periods remain uncertain. The extent of the impact of COVID-19 on our operational and financial performance will depend on certain developments, including but not limited to the duration and spread of the pandemic and its variants in geographies where we do business, implementation and duration of local, state and federal issued public health orders in each jurisdiction where we or our customers and suppliers operate, impact on our customers and our sales cycles, impact on our supply chain and manufacturing partners, impact on our employees, and impact on regional and worldwide economies and financial markets in general, all of which are uncertain and not predictable. We assessed the potential impact that this pandemic has on our estimates as of July 1, 2023 and determined that there were no material impacts.

[0001628280-23-030374:notes:9]
We are also continuously monitoring developments in the ongoing conflict between Russia and Ukraine including the related export controls and resulting sanctions imposed on Russia by the U.S. and other countries.  Additional factors such as increased inflation, escalating energy costs, constrained raw material availability, and thus increasing costs could impact the global economy.  Although the global implications of the Russian/Ukraine conflict are difficult to predict at this time, we do not presently foresee direct material adverse effects upon our business.

[0001628280-23-030374:notes:10]
Fiscal Years

[0001628280-23-030374:notes:11]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Every fifth or sixth fiscal year will have a 53-week period. The additional week in a 53-week year is added to the third quarter, making such quarter consist of 14 weeks. Our fiscal 2023 and 2022 were 52-week years, ending on July 1, 2023 and July 2, 2022, respectively. Our fiscal 2021 was a 53-week year, ending on July 3, 2021.

[0001628280-23-030374:notes:12]
Principles of Consolidation

[0001628280-23-030374:notes:13]
The consolidated financial statements are prepared in accordance with GAAP and includes the accounts of Lumentum Holdings Inc. and its wholly owned subsidiaries. Intercompany transactions and balances are fully eliminated in consolidation.

[0001628280-23-030374:notes:14]
Business Combination

[0001628280-23-030374:notes:15]
On August 3, 2022, we completed a merger with NeoPhotonics Corporation (“NeoPhotonics”).  Our consolidated financial statements include the operating results of NeoPhotonics for the period from the date of the closing of the merger through July 1, 2023. We have applied the acquisition method of accounting in accordance with Accounting Standards Codification (“ASC”) Topic 805, Business Combinations to account for this transaction.  Refer to “Note 4. Business Combination”.

[0001628280-23-030374:notes:16]
On August 15, 2022, we completed a transaction to acquire IPG Photonics’ telecom transmission product lines (“IPG telecom transmission product lines”). Our consolidated financial statements include the operating results of this business unit for the period from the date of acquisition through July 1, 2023.  We applied the acquisition method of accounting in accordance with ASC Topic 805, Business Combination to account for this transaction. Refer to “Note 4. Business Combination”.

[0001628280-23-030374:notes:17]
Termination of Coherent Merger Agreement

[0001628280-23-030374:notes:18]
On January 18, 2021, Lumentum and Coherent, Inc. (“Coherent”) entered into a merger agreement (the “merger agreement”), under which Lumentum would acquire all outstanding shares of Coherent common stock. As of the date of the merger agreement, the total transaction consideration was approximately $5.7 billion. In March 2021, Coherent terminated the merger agreement and paid Lumentum a termination fee of $217.6 million in accordance with the merger agreement. This gain was offset by $10.1 million of acquisition-related expenses and the net amount is presented as “merger termination fee and related costs, net” in our consolidated statement of operations for the year ended July 3, 2021.

[0001628280-23-030374:notes:19]
Summary of Significant Accounting Policies

[0001628280-23-030374:notes:20]
Our significant accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. We believe that of our significant accounting policies described below, involve a greater degree of judgment and complexity and are the most critical to aid in fully understanding and evaluating our consolidated financial statements. These policies include inventory valuation, revenue recognition, income taxes, goodwill and business combinations. For a description of our critical accounting policies, also refer to “Management’s Discussion and Analysis of Financial Condition and Results of Operations”, Critical Accounting Policies and Estimates.

[0001628280-23-030374:notes:21]
Cash Equivalents

[0001628280-23-030374:notes:22]
We consider highly liquid fixed income securities with original maturities of three months or less at the time of purchase to be cash equivalents. As of July 1, 2023, our cash equivalents consist of money market funds, U.S. Agency securities and U.S. Treasury securities.

[0001628280-23-030374:notes:23]
Short-Term Investments

[0001628280-23-030374:notes:24]
We classify our investments in debt securities as available-for-sale and record these investments at fair value. Investments with an original maturity of three months or less at the date of purchase are considered cash equivalents, while all other investments are classified as short-term based on management’s intent and ability to use the funds in current operations. Unrealized gains and losses are reported as a component of other comprehensive income (loss). Realized gains and losses are determined based on the specific identification method, and are reflected as other income (expense), net in our consolidated statements of operations.

[0001628280-23-030374:notes:25]
We regularly review our investment portfolio to identify and evaluate investments that have indicators of possible impairment. Factors considered in determining whether a loss is other-than-temporary include, but are not limited to: the length of time and extent a security’s fair value has been below its cost, the financial condition and near-term prospects of the investee, the credit quality of the security’s issuer, likelihood of recovery and our intent and ability to hold the security for a period of time sufficient to allow for any anticipated recovery in value. For our debt instruments, we also evaluate whether we have the intent to sell the security, or it is more likely than not that we will be required to sell the security before recovery of its cost basis.

[0001628280-23-030374:notes:26]
Fair Value of Financial Instruments

[0001628280-23-030374:notes:27]
We define fair value as the price that would be received from selling an asset, or paid to transfer a liability, in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities which are required to be recorded at fair value, we consider the principal or most advantageous market in which to transact and the market-based risk. We apply fair value accounting for all financial assets and liabilities that are recognized or disclosed at fair value in the financial statements on a recurring basis. The carrying amounts reported in the consolidated financial statements approximate the fair value for cash, accounts receivable, accounts payable and accrued liabilities due to their short-term nature.

[0001628280-23-030374:notes:28]
Basic and Diluted Net Income per Common Share

[0001628280-23-030374:notes:29]
Basic income per share is computed by dividing net income available to common stockholders by the weighted average number of common shares outstanding during the reporting period. The weighted average number of shares is calculated by taking the number of shares outstanding and weighting them by the amount of time that they were outstanding. Diluted earnings per share reflects the potential dilution that could occur if stock options, preferred stock, and other commitments to issue common stock were exercised or equity awards vest resulting in the issuance of common stock that could share in the earnings of the Company.

[0001628280-23-030374:notes:30]
Diluted loss per share is the same as basic loss per share during periods where net losses are incurred since the inclusion of the potential common stock equivalents would be anti-dilutive as a result of the net loss.

[0001628280-23-030374:notes:31]
Potentially dilutive common shares result from the assumed exercise of outstanding stock options, assumed vesting of outstanding equity awards, assumed issuance of stock under the employee stock purchase plan, and assumed conversion of our outstanding $323.1 million in aggregate principal amount of 2024 Notes, $1,050.0 million in aggregate principal amount of 2026 Notes, $861.0 million in aggregate principal amount of 2028 Notes, and $603.7 million in aggregate principle amount of 2029 Notes (collectively, the “convertible notes”). We used the treasury stock method for all convertible notes in the diluted net income per share calculation for the year ended July 2, 2022 and July 3, 2021 as we had the ability and intent to settle the face value of the convertible notes in cash. Upon adoption of ASU 2020-06 on July 3, 2022, we used the if-converted method for all convertible notes in the diluted net income per share calculation.

[0001628280-23-030374:notes:32]
The dilutive effect of securities from the 2015 Equity Incentive Plan is reflected in diluted earnings per share by application of the treasury stock method, which includes consideration of unamortized share-based compensation expense and the dilutive effect of in-the-money options and non-vested restricted stock units. Under the treasury stock method, the amount the employee must pay for exercising stock options and the amount of unamortized share-based compensation expense are collectively assumed to be used to repurchase hypothetical shares. An increase in the fair value of our common stock can result in a greater dilutive effect from potentially dilutive awards.

[0001628280-23-030374:notes:33]
Anti-dilutive potential shares from 2015 Equity Incentive Plan are excluded from the calculation of diluted earnings per share if their exercise price exceeded the average market price during the period or the share-based awards were determined to be anti-dilutive based on applying the treasury stock method.

[0001628280-23-030374:notes:34]
Inventory Valuation

[0001628280-23-030374:notes:35]
Inventory is recorded at standard cost, which approximates actual cost computed on a first-in, first-out basis, not in excess of net realizable value. We assess the value of our inventory on a quarterly basis and write down those inventories which are obsolete or in excess of our forecasted demand to the lower of their cost or estimated net realizable value. Our estimates of forecasted demand are based upon our analysis and assumptions including, but not limited to, expected product lifecycles, product development plans and historical usage by product. Our product line management personnel play a key role in our excess review process by providing updated sales forecasts, managing product transitions and working with manufacturing to minimize excess inventory. If actual market conditions are less favorable than our forecasts, or actual demand from our customers is lower than our estimates, we may be required to record additional inventory write-downs. If actual market conditions are more favorable than anticipated, inventory previously written down may be sold, resulting in lower cost of sales and higher income from operations than expected in that period.

[0001628280-23-030374:notes:36]
Leases

[0001628280-23-030374:notes:37]
We determine if an arrangement is a lease at inception for arrangements with an initial term of more than 12 months, and classify it as either a finance or operating lease pursuant to Topic 842.

[0001628280-23-030374:notes:38]
Finance leases are generally those that allow us to substantially utilize or pay for the entire asset over its estimated useful life. Finance leases are recorded in property, plant and equipment, net, and finance lease liabilities within other current and other non-current liabilities on our consolidated balance sheets. We have lease arrangements with lease and non-lease components, and the non-lease components for our finance leases are accounted for separately, based on estimated stand-alone values, and are not included in the initial measurement of our finance lease assets and corresponding liabilities. Finance lease assets are amortized in operating expenses on a straight-line basis over the shorter of the estimated useful lives of the assets or the lease term, with the interest component included in interest expense and recognized using the effective interest method over the lease term.

[0001628280-23-030374:notes:39]
Operating leases are recorded in operating lease right-of-use assets, net, and operating lease liabilities, current and non-current on our consolidated balance sheets. For operating leases of buildings, we account for non-lease components, such as common area maintenance, as a component of the lease, and include it in the initial measurement of our operating lease assets and corresponding liabilities. Operating lease assets are amortized on a straight-line basis in operating expenses over the lease term.

[0001628280-23-030374:notes:40]
Our lease liabilities are recognized based on the present value of the remaining fixed lease payments, over the lease term, using a discount rate of similarly secured borrowings available to us. For the purpose of lease liability measurement, we consider only payments that are fixed and determinable at the time of commencement. Any variable payments that depend on an index or rate are expensed as incurred. Our lease terms may include options to extend when it is reasonably certain that we will exercise that option. Our lease assets also include any lease payments made and exclude any lease incentives received prior to commencement. Our lease assets are tested for impairment in the same manner as long-lived assets used in operations. We generally recognize sublease income on a straight-line basis over the sublease term.

[0001628280-23-030374:notes:41]
Revenue Recognition

[0001628280-23-030374:notes:42]
Pursuant to Topic 606, our revenues are recognized upon the application of the following steps:

[0001628280-23-030374:notes:43]
•identification of the contract, or contracts, with a customer;

[0001628280-23-030374:notes:44]
•identification of the performance obligations in the contract;

[0001628280-23-030374:notes:45]
•determination of the transaction price;

[0001628280-23-030374:notes:46]
•allocation of the transaction price to the performance obligations in the contract; and

[0001628280-23-030374:notes:47]
•recognition of revenues when, or as, the contractual performance obligations are satisfied.

[0001628280-23-030374:notes:48]
The majority of our revenue comes from product sales, consisting of sales of Lasers and OpComms hardware products to our customers. Our revenue contracts generally include only one performance obligation. Revenues are recognized at a point in time when control of the promised goods or services are transferred to our customers upon shipment or delivery of goods or rendering of services, in an amount that reflects the consideration we expect to be entitled to in exchange for those goods or services. We have entered into vendor managed inventory (“VMI”) programs with our customers. Under these arrangements, we receive purchase orders from our customers, and the inventory is shipped to the VMI location upon receipt of the purchase order. The customer then pulls the inventory from the VMI hub based on its production needs. Revenue under VMI programs is recognized when control transfers to the customer, which is generally once the customer pulls the inventory from the hub.

[0001628280-23-030374:notes:49]
Revenue from all sales types is recognized at the transaction price. The transaction price is determined based on the consideration to which we will be entitled in exchange for transferring goods or services to the customer adjusted for estimated variable consideration, if any. We typically estimate the impact on the transaction price for discounts offered to the customers for early payments on receivables or net of accruals for estimated sales returns. These estimates are based on historical returns, analysis of credit memo data and other known factors. Actual returns could differ from these estimates. We allocate the transaction price to each distinct product based on its relative standalone selling price. The product price as specified on the purchase order is considered the standalone selling price as it is an observable input that depicts the price as if sold to a similar customer in similar circumstances.

[0001628280-23-030374:notes:50]
Taxes assessed by a governmental authority that are both imposed on and concurrent with a specific revenue-producing transaction, which are collected by us from a customer and deposited with the relevant government authority, are excluded from revenue.

[0001628280-23-030374:notes:51]
Our revenue arrangements do not contain significant financing components as our standard payment terms are less than one year.

[0001628280-23-030374:notes:52]
If a customer pays consideration, or we have a right to an amount of consideration that is unconditional before we transfer a good or service to the customer, those amounts are classified as deferred revenue or deposits received from customers which are included in other current liabilities or other long-term liabilities when the payment is made or it is due, whichever is earlier.

[0001628280-23-030374:notes:53]
Transaction Price Allocated to the Remaining Performance Obligations

[0001628280-23-030374:notes:54]
Remaining performance obligations represent the transaction price allocated to performances obligations that are unsatisfied or partially unsatisfied as of the end of the reporting period. Unsatisfied and partially unsatisfied performance obligations consist of contract liabilities and non-cancellable backlog. Non-cancellable backlog includes goods and services for which customer purchase orders have been accepted that are scheduled or in the process of being scheduled for shipment. A portion of our revenue arises from vendor managed inventory arrangements where the timing and volume of customer utilization is difficult to predict.

[0001628280-23-030374:notes:55]
Deferred revenue as of July 1, 2023 and July 2, 2022 was $2.1 million and nil, respectively, which was recorded in other current liabilities within the consolidated balance sheets. During fiscal 2023 and 2022, we recognized nil and $0.6 million of revenue that was included in deferred revenue as of July 2, 2022 and July 3, 2021, respectively.

[0001628280-23-030374:notes:56]
Warranty

[0001628280-23-030374:notes:57]
Hardware products regularly include warranties to the end customers such that the product continues to function according to published specifications. We typically offer a twelve-month warranty for most of our products. However, in some instances depending upon the product, specific market, product line and geography in which we operate, and what is common in the industry, our warranties can vary and range from six months to five years. These standard warranties are assurance type warranties and do not offer any services in addition to the assurance that the product will continue working as specified. Therefore, warranties are not considered separate performance obligations in the arrangement. Instead, the expected cost of warranty is accrued as expense in accordance with authoritative guidance.

[0001628280-23-030374:notes:58]
We provide reserves for the estimated costs of product warranties that we record as cost of sales at the time revenue is recognized. We estimate the costs of our warranty obligations based on our historical experience of known product failure rates, use of materials to repair or replace defective products and service delivery costs incurred in correcting product failures. In addition, from time to time, specific warranty accruals may be made if discrete technical problems arise.

[0001628280-23-030374:notes:59]
Shipping and Handling Costs

[0001628280-23-030374:notes:60]
We record shipping and handling costs related to revenue transactions within cost of sales as a period cost.

[0001628280-23-030374:notes:61]
Contract Costs

[0001628280-23-030374:notes:62]
We recognize the incremental direct costs of obtaining a contract, which consist of sales commissions, when control over the products they relate to transfers to the customer. Applying the practical expedient, we recognize commissions as expense when incurred, as the amortization period of the commission asset we would have otherwise recognized is less than one year.

[0001628280-23-030374:notes:63]
Contract Balances

[0001628280-23-030374:notes:64]
We record accounts receivable when we have an unconditional right to consideration. Contract liabilities are recorded when cash payments are received or due in advance of performance. Contract liabilities consist of advance payments and deferred revenue, where we have unsatisfied performance obligations. Contract liabilities are classified as deferred revenue and customer deposits and are included in other current liabilities within our consolidated balance sheet. Payment terms vary by customer. The time between invoicing and when payment is due is not significant. Refer to “Note 19. Revenue Recognition” for a presentation of changes in contract balances.

[0001628280-23-030374:notes:65]
Disaggregation of Revenue

[0001628280-23-030374:notes:66]
We disaggregate revenue by geography and by product. Refer to “Note 19. Revenue Recognition” for a presentation of disaggregated revenue. We do not present other levels of disaggregation, such as by type of products, customer, markets, contracts, duration of contracts, timing of transfer of control and sales channels, as this information is not used by our Chief Operating Decision Maker (“CODM”) to manage the business.

[0001628280-23-030374:notes:67]
Income Taxes

[0001628280-23-030374:notes:68]
In accordance with the authoritative guidance on accounting for income taxes, we recognize income taxes using an asset and liability approach. This approach requires the recognition of taxes payable or refundable for the current year and deferred tax liabilities and assets for the future tax consequences of events that have been recognized in our consolidated financial statements or tax returns. The measurement of current and deferred taxes is based on provisions of the enacted tax law, and the effects of future changes in tax laws or rates are not anticipated.

[0001628280-23-030374:notes:69]
The authoritative guidance provides for recognition of deferred tax assets if the realization of such deferred tax assets is more likely than not to occur based on an evaluation of both positive and negative evidence and the relative weight of the evidence. We consider future growth, forecasted earnings, future taxable income, the mix of earnings in the jurisdictions in which we operate, historical earnings, taxable income in prior years, if carry-back is permitted under the law, and prudent and feasible tax planning strategies in determining the need for a valuation allowance. In the event we were to determine that we would not be able to realize all or part of our net deferred tax assets in the future, an adjustment to the deferred tax assets valuation allowance would be charged to earnings in the period in which we make such a determination, or goodwill would be adjusted at our final determination of the valuation allowance related to an acquisition within the measurement period. If we later determine that it is more likely than not that the net deferred tax assets would be realized, we would reverse the applicable portion of the previously provided valuation allowance as an adjustment to earnings at such time.

[0001628280-23-030374:notes:70]
We are subject to income tax audits by the respective tax authorities of the jurisdictions in which we operate. The determination of our income tax liabilities in each of these jurisdictions requires the interpretation and application of complex, and sometimes uncertain, tax laws and regulations. The authoritative guidance on accounting for income taxes prescribes both recognition and measurement criteria that must be met for the benefit of a tax position to be recognized in the financial statements. If a tax position taken, or expected to be taken, in a tax return does not meet such recognition or measurement criteria, an unrecognized tax benefit liability is recorded.  If we ultimately determine that an unrecognized tax benefit liability is no longer necessary, we reverse the liability and recognize a tax benefit in the period in which it is determined that the unrecognized tax benefit liability is no longer necessary.

[0001628280-23-030374:notes:71]
The recognition and measurement of current taxes payable or refundable and deferred tax assets and liabilities requires that we make certain estimates and judgments. Changes to these estimates or a change in judgment may have a material impact on our tax provision in a future period.

[0001628280-23-030374:notes:72]
Property, Plant and Equipment

[0001628280-23-030374:notes:73]
Property, plant and equipment are stated at cost. Depreciation is computed by the straight-line method generally over the following estimated useful lives of the assets: 10 to 40 years for building and improvements, 3 to 10 years for machinery and equipment, and 2 to 5 years for furniture, fixtures, software and office equipment. Leasehold improvements are amortized using the straight-line method over the shorter of the estimated useful lives of the assets or the term of the lease, including the renewal option that we are reasonably certain to exercise.

[0001628280-23-030374:notes:74]
In accordance with the guidance for business combinations, we determine whether a transaction or event is a business combination, which requires that the assets acquired and liabilities assumed constitute a business. Each business combination is then accounted for by applying the acquisition method. If the assets acquired are not a business, we account for the transaction or event as an asset acquisition. Under both methods, we recognize the identifiable assets acquired, the liabilities assumed, and any noncontrolling interest in the acquired entity. We capitalize acquisition-related costs and fees associated with asset acquisitions and immediately expense acquisition-related costs and fees associated with business combinations.

[0001628280-23-030374:notes:75]
We allocate the fair value of purchase consideration to the tangible assets acquired, liabilities assumed and intangible assets acquired based on their estimated fair values. The excess of the fair value of purchase consideration over the fair values of these identifiable assets and liabilities is recorded as goodwill. When determining the fair values of assets acquired and liabilities assumed, we make significant estimates and assumptions, especially with respect to intangible assets. Critical estimates in valuing certain intangible assets include, but are not limited to, future expected cash flows from customer relationships and acquired developed technology and discount rates. Our estimates of fair value are based upon assumptions believed to be reasonable using best information available. These assumptions are inherently uncertain and unpredictable and, as a result, actual results may differ materially from estimates. Certain estimates associated with the accounting for acquisitions may change as additional information becomes available regarding the assets acquired and liabilities assumed. Any change in facts and circumstances that existed as of the acquisition date and impacts to our preliminary estimates is recorded to goodwill if identified within the measurement period. Subsequent to the measurement period or our final determination of fair value of assets and liabilities, whichever is earlier, the adjustments will affect our earnings.

[0001628280-23-030374:notes:76]
We estimate the economic lives of certain acquired assets and these lives are used to calculate depreciation and amortization expense. If our estimates of the economic lives change, depreciation or amortization expenses could be accelerated or slowed.

[0001628280-23-030374:notes:77]
Goodwill

[0001628280-23-030374:notes:78]
Goodwill represents the excess of the purchase price of an acquired business over the fair value of the identifiable assets acquired and liabilities assumed. We test goodwill impairment on an annual basis in the fiscal fourth quarter and at any other time when events occur or circumstances indicate that the carrying amount of goodwill may not be recoverable.

[0001628280-23-030374:notes:79]
We have the option to first assess qualitative factors to determine whether it is necessary to perform the quantitative goodwill impairment test. The qualitative factors we assess include long-term prospects of our performance, share price trends and market capitalization, and Company specific events. Unanticipated events and circumstances may occur that affect the accuracy of our assumptions, estimates and judgments. For example, if the price of our common stock were to significantly decrease combined with other adverse changes in market conditions, thus indicating that the underlying fair value of our reporting units may have decreased, we may reassess the value of our goodwill in the period such circumstances were identified.

[0001628280-23-030374:notes:80]
If we determine that, as a result of the qualitative assessment, it is more likely than not (i.e., greater than 50% likelihood) that the fair value of a reporting unit is less than its carrying amount, we perform the quantitative test by estimating the fair value of our reporting units. If the carrying value of a reporting unit exceeds its fair value, we record goodwill impairment loss equal to the excess of the carrying value of the reporting unit’s goodwill over its fair value, not to exceed the carrying amount of goodwill. The fair value of each of our goodwill reporting units is generally estimated using a combination of public company multiples and discounted cash flow methodologies.

[0001628280-23-030374:notes:81]
Based on the impairment analysis performed in the fourth quarter of each year presented, the fair value of each of our reporting units substantially exceeded the carrying value; as such, our annual qualitative assessment did not indicate that a more detailed quantitative analysis was necessary.

[0001628280-23-030374:notes:82]
Intangible Assets

[0001628280-23-030374:notes:83]
Intangible assets consist primarily of intangible assets purchased through acquisitions. Purchased intangible assets include acquired developed technologies (developed and core technology), customer relationships, and order backlog. Intangible assets, with the exception of certain customer relationships, are amortized using the straight-line method over the estimated economic useful lives of the assets, which is the period during which expected cash flows support the fair value of such intangible assets. Certain customer relationships are amortized using an accelerated method of amortization over the expected customer lives, which more accurately reflects the pattern of realization of economic benefits expected to be obtained.

[0001628280-23-030374:notes:84]
Long-lived Asset Valuation

[0001628280-23-030374:notes:85]
We test long-lived assets for recoverability, at the asset group level, when events or changes in circumstances indicate that their carrying amount may not be recoverable. Circumstances which could trigger a review include, but are not limited to: significant decreases in the market price of the asset, significant adverse changes in the business climate or legal factors, accumulation of costs significantly in excess of the amount originally expected for the acquisition or construction of the asset, current period cash flow or operating losses combined with a history of losses or a forecast of continuing losses associated with the use of the asset, or current expectation that the asset will more likely than not be sold or disposed significantly before the end of its estimated useful life.

[0001628280-23-030374:notes:86]
Recoverability is assessed based on the difference between the carrying amount of the asset and the sum of the undiscounted cash flows expected to result from the use and the eventual disposal of the asset. An impairment loss is recognized when the carrying amount is not recoverable and exceeds fair value.

[0001628280-23-030374:notes:87]
Pension Benefits

[0001628280-23-030374:notes:88]
The Company sponsors various employee retirement plans, including defined contribution, defined benefit and other post-retirement plans.  Refer to “Note 16. Employee Retirement Plans” for more information.

[0001628280-23-030374:notes:89]
The funded status of our retirement-related benefit plan is measured as the difference between the fair value of plan assets and the benefit obligation at fiscal year end, the measurement date. The funded status of an underfunded benefit plan, of which the fair value of plan assets is less than the benefit obligation, is recognized as a non-current net pension liability in the consolidated balance sheets. For defined benefit pension plans, the benefit obligation is the projected benefit obligation (“PBO”) which represents the actuarial present value of benefits expected to be paid upon retirement.

[0001628280-23-030374:notes:90]
Net periodic pension cost (income) (“NPPC”) is recorded in the consolidated statements of operations and includes service cost, interest cost, expected return on plan assets, amortization of prior service cost and gains or losses previously recognized as a component of accumulated other comprehensive income. Service cost represents the actuarial present value of participant benefits attributed to services rendered by employees in the current year. Interest cost represents the time value of money cost associated with the passage of time. Gains or losses arise as a result of differences between actual experience and assumptions or as a result of changes in actuarial assumptions. Prior service cost or credits represent the cost of benefit improvements attributable to prior service granted in plan amendments. (Gains) losses and prior service cost (credit) that arise during the current year are first recognized as a component of accumulated other comprehensive income in the consolidated balances sheets, net of tax. Prior service cost is amortized as a component of NPPC over the average remaining service period of active plan participants starting at the date the plan amendment is adopted. Deferred actuarial gains or losses are subsequently recognized as a component of NPPC if they exceed the greater of 10% of PBO or the fair value of plan assets, with the excess amortized over the average remaining service period of active plan participants.

[0001628280-23-030374:notes:91]
The measurement of the benefit obligation and NPPC is based on our estimates and actuarial valuations, provided by third-party actuaries, which are approved by management. These valuations reflect the terms of the plans and use participant-specific information such as compensation, age and years of service, as well as certain assumptions, including estimates of discount rates, expected return on plan assets, rate of compensation increases, and mortality rates. We evaluate these assumptions annually at a minimum. In estimating the expected return on plan assets, we consider historical returns on plan assets, adjusted for forward-looking considerations, inflation assumptions and the impact of the active management of the plan’s invested assets.

[0001628280-23-030374:notes:92]
Concentration of Credit and Other Risks

[0001628280-23-030374:notes:93]
Financial instruments that potentially subject our business to concentration of credit risk consist primarily of cash, short-term investments, and trade receivables.

[0001628280-23-030374:notes:94]
Although the Company deposits its cash with financial institutions that management believes are of high credit quality, its deposits, at times, may exceed federally insured limits. The Company’s investment portfolio consists of investment grade securities diversified amongst security types, industries, and issuers. The Company’s investment policy limits the amount of credit exposure in the investment portfolio by imposing credit rating minimums and limiting purchases of a single issuer, security type, geography and industry, except for Treasury securities. The Company believes no significant concentration risk exists with respect to these investments.

[0001628280-23-030374:notes:95]
We perform credit evaluations of our customers’ financial condition and generally do not require collateral from our customers. These evaluations require significant judgment and are based on a variety of factors including, but not limited to, current economic trends, payment history, bad debt write-off experience, and financial review of the customer.

[0001628280-23-030374:notes:96]
We maintain an allowance for credit losses for estimated losses resulting from the inability of our customers to make required payments. When we become aware that a specific customer is unable to meet their financial obligations, we record a specific allowance to reflect the level of credit risk in the customer’s outstanding receivable balance. In addition, we record additional allowances based on certain percentages of aged receivable balances. These percentages take into account a variety of factors including, but not limited to, current economic trends, payment history and bad debt write-off experience. We classify bad debt expenses as selling, general and administrative expense.

[0001628280-23-030374:notes:97]
During fiscal 2023, 2022, and 2021, a few customers generated more than 10% of total net revenue. Refer to “Note 18. Operating Segments and Geographic Information” for more information.

[0001628280-23-030374:notes:98]
As of July 1, 2023, our accounts receivable from a single customer, which represented 10% or greater of the total accounts receivable, was concentrated with three customers, which individually represented 14%, 12% and 12% of gross accounts receivable, respectively. As of July 2, 2022, our accounts receivable from a single customer, which represented 10% or greater of the total accounts receivable, was concentrated with two customers, which individually represented 10% and 10% of gross accounts receivable, respectively.

[0001628280-23-030374:notes:99]
We rely on a limited number of suppliers for a number of key components contained in our products. We also rely on a limited number of significant independent contract manufacturers for the production of certain key components and subassemblies contained in our products.

[0001628280-23-030374:notes:100]
We generally use a rolling twelve months forecast based on anticipated product orders, customer forecasts, product order history and backlog to determine our materials requirements. Lead times for the parts and components that we order vary significantly and depend on factors such as the specific supplier, contract terms and demand for a component at a given time. If the forecast does not meet or if it exceeds actual demand, we may have excess or shortfalls of some materials and components, as well as excess inventory purchase commitments. We could experience reduced or delayed product shipments or incur additional inventory write-downs and cancellation charges or penalties, which would increase costs and could have a material adverse impact on our results of operations.

[0001628280-23-030374:notes:101]
Foreign Currency Translation

[0001628280-23-030374:notes:102]
In fiscal 2019, we established the functional currency for our worldwide operations as the U.S. dollar. Translation adjustments reported prior to December 10, 2018 remain as a component of accumulated other comprehensive income (loss) in our condensed consolidated balance sheets, until all or a part of the investment in the subsidiaries is sold or liquidated. In fiscal 2023, we acquired IPG telecom transmission product lines. The functional currency of the Brazilian entities acquired as part of this acquisition is the local currency.

[0001628280-23-030374:notes:103]
Translation adjustments reported prior to fiscal 2019, remain as a component of accumulated other comprehensive income in our consolidated balance sheet. The translated values for any non-monetary assets and liabilities as of the date we established the U.S. dollar as the functional currency became the new accounting basis for those assets. Accordingly, monetary assets and liabilities denominated in foreign currencies have been remeasured into U.S. dollars using the exchange rates in effect at the balance sheet date. Foreign currency re-measurement gains or losses are included in other income (expense), net in the consolidated statements of operations.

[0001628280-23-030374:notes:104]
Stock-based Compensation

[0001628280-23-030374:notes:105]
Compensation expense related to stock-based transactions is measured and recognized in the financial statements based on fair value at the grant date.

[0001628280-23-030374:notes:106]
Restricted stock units (“RSUs”) are grants of shares of our common stock, the vesting of which is based on the requisite service requirement. Generally, our RSUs are subject to forfeiture and expected to vest over one to four years. For new-hire grants, RSUs generally vest ratably on an annual basis over four years. For annual refresh grants, RSUs generally vest ratably on an annual, or combination of annual and quarterly, basis over three years.

[0001628280-23-030374:notes:107]
Restricted stock awards (“RSAs”) are grants of shares of our common stock that are subject to various restrictions, including restrictions on transferability and forfeiture provisions. RSAs are expected to vest over one to four years, and the shares acquired may not be transferred by the holder until the vesting conditions (if any) are satisfied.

[0001628280-23-030374:notes:108]
Performance stock units (“PSUs”) are grants of shares of our common stock that vest upon the achievement of certain performance and service conditions. We account for the fair value of PSUs using the closing market price of our common stock on the date of grant. We begin recognizing compensation expense when we conclude that it is probable that the performance conditions will be achieved. We reassess the probability of vesting at each reporting period and adjust our compensation cost based on this probability assessment. Our PSUs are subject to risk of forfeiture until performance and service conditions are satisfied and generally vest over three years.

[0001628280-23-030374:notes:109]
We estimate the fair value of the rights to acquire stock under our 2015 Employee Stock Purchase Plan (the “2015 Purchase Plan”) using the Black-Scholes option pricing formula. Our 2015 Purchase Plan provides for consecutive six-month offering periods. We recognize such compensation expense on a straight-line basis over the requisite service period. We calculate the volatility factor based on our historical stock prices.

[0001628280-23-030374:notes:110]
Treasury Stock

[0001628280-23-030374:notes:111]
Treasury stock is carried at cost. When we retire our treasury stock, any excess of the repurchase price paid over par value is allocated to retained earnings.

[0001628280-23-030374:notes:112]
Restructuring and Related Charges

[0001628280-23-030374:notes:113]
Costs associated with restructuring activities are recognized when they are obligated. However, in the case of leases, the expense is estimated and accrued when the property is vacated. Given the significance of, and the timing of the execution of such activities, this process is complex and involves periodic reassessments of estimates made from the time the property was vacated, including evaluating real estate market conditions for expected vacancy periods and sub-lease income. We recognize a liability for post-employment benefits for workforce reductions related to restructuring activities when payment is probable and the amount is reasonably estimable. We continually evaluate the adequacy of the remaining liabilities under our restructuring initiatives. Although we believe that these estimates accurately reflect the costs of our restructuring plans, actual results may differ, thereby requiring us to record additional provisions or reverse a portion of such provisions. Refer to “Note 12. Restructuring and Related Charges”.

[0001628280-23-030374:notes:114]
Research and Development (“R&D”) Expense

[0001628280-23-030374:notes:115]
Costs related to R&D, which primarily consists of labor and benefits, supplies, facilities, consulting and outside service fees, are charged to expense as incurred.

[0001628280-23-030374:notes:116]
Loss Contingencies

[0001628280-23-030374:notes:117]
We are subject to the possibility of various loss contingencies arising in the ordinary course of business. We consider the likelihood of loss or impairment of an asset or the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss in determining loss contingencies. An estimated loss is accrued when it is probable that an asset has been impaired or a liability has been incurred and the amount of loss can be reasonably estimated. We regularly evaluate current information available to determine whether such accruals should be adjusted and whether new accruals are required.

[0001628280-23-030374:notes:118]
Asset Retirement Obligations (“ARO”)

[0001628280-23-030374:notes:119]
Our ARO are legal obligations associated with the retirement of long-lived assets pertaining to leasehold improvements. These liabilities are initially recorded at fair value and the related asset retirement costs are capitalized by increasing the carrying amount of the related assets by the same amount as the liability. Asset retirement costs are subsequently depreciated over the useful lives of the related assets. Subsequent to initial recognition, we record period-to-period changes in the ARO liability resulting from the passage of time and revisions to either the timing or the amount of the original estimate of undiscounted cash flows. We de-recognize ARO liabilities when the related obligations are settled.


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0001628280-23-030374:notes:120]
We determine fair value based on the fair value hierarchy, which requires an entity to maximize the use of observable inputs and minimize the use of unobservable inputs when measuring fair value. Fair value is defined as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. The fair value assumes that the transaction to sell the asset or transfer the liability occurs in the principal or most advantageous market for the asset or liability and establishes that the fair value of an asset or liability shall be determined based on the assumptions that market participants would use in pricing the asset or liability. The classification of a financial asset or liability within the hierarchy is based upon the lowest level input that is significant to the fair value measurement. The fair value hierarchy prioritizes the inputs into three levels that may be used to measure fair value:

[0001628280-23-030374:notes:121]
| Level 1: | Inputs are unadjusted quoted prices in active markets for identical assets or liabilities. |
| Level 2: | Inputs are quoted prices for similar assets and liabilities in active markets or inputs that are observable for the asset or liability, either directly or indirectly through market corroboration, for substantially the full term of the financial instrument. |
| Level 3: | Inputs are unobservable inputs based on our assumptions. |

[0001628280-23-030374:notes:122]
The fair value of our Level 1 financial instruments, such as money market funds and U.S. Treasury securities, which are traded in active markets, is based on quoted market prices for identical instruments. The fair value of our Level 2 fixed income securities is obtained from an independent pricing service, which may use quoted market prices for identical or comparable instruments or model driven valuations using observable market data or inputs corroborated by observable market data. Our marketable securities are held by custodians who obtain investment prices from a third-party pricing provider that incorporates standard inputs in various asset price models. Our procedures include controls to ensure that appropriate fair values are recorded, including comparing the fair values obtained from our pricing service against fair values obtained from another independent source.

[0001628280-23-030374:notes:123]
Our pension assets consist of multiple institutional funds (“pension funds”) of which the fair values are based on the quoted prices of the underlying funds. Pension funds are primarily classified as Level 2 assets since such funds are not directly traded in active markets. Refer to “Note 16. Employee Retirement Plans.”

[0001628280-23-030374:notes:124]
Assets Measured at Fair Value on a Non-Recurring Basis

[0001628280-23-030374:notes:125]
We periodically review our intangible and other long-lived assets for impairment whenever events or changes in circumstances indicate that the carrying amount of such assets may not be recoverable. Determination of recoverability is based on the lowest level of identifiable estimated undiscounted cash flows resulting from use of the asset and its eventual disposition. If not recoverable, an impairment loss would be calculated based on the excess of the carrying amount over the fair value.
Management utilizes various valuation methods, including an income approach, a market approach and a cost approach, to estimate the fair value of intangibles and other long-lived assets.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0001628280-23-030374:notes:126]
Contract Balances
We record accounts receivable when we have an unconditional right to consideration. Contract liabilities are recorded when cash payments are received or due in advance of performance. Contract liabilities consist of advance payments and deferred revenue, where we have unsatisfied performance obligations. Contract liabilities are classified as deferred revenue and customer deposits and are included in other current liabilities within our consolidated balance sheet. Payment terms vary by customer. The time between invoicing and when payment is due is not significant.Disaggregation of RevenueWe disaggregate revenue by geography and by product. Refer to “Note 19. Revenue Recognition” for a presentation of disaggregated revenue. We do not present other levels of disaggregation, such as by type of products, customer, markets, contracts, duration of contracts, timing of transfer of control and sales channels, as this information is not used by our Chief Operating Decision Maker (“CODM”) to manage the business.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001628280-23-030374:notes:127]
Note 2. Recently Issued Accounting Pronouncements

[0001628280-23-030374:notes:128]
Accounting Pronouncements Recently Adopted

[0001628280-23-030374:notes:129]
In October 2021, the Financial Accounting Standards Board (“FASB”) issued ASU 2021-08, Business Combinations (Topic 805)—Accounting for Contract Assets and Contract Liabilities from Contracts with Customers. This ASU clarifies that an acquirer of a business should recognize and measure contract assets and contract liabilities in a business combination in accordance with ASC Topic 606, Revenue from Contracts with Customers. This ASU is expected to improve comparability for both recognition and measurement of acquired revenue contracts with customers at the date of and after a business combination. The new guidance is effective for fiscal years beginning after December 15, 2022, with early adoption permitted. We early adopted the new standard in the first quarter of fiscal 2023 in connection with the merger with NeoPhotonics. There was no material impact to our consolidated financial statements as of and for the year ended July 1, 2023.

[0001628280-23-030374:notes:130]
In August 2020, the FASB issued ASU 2020-06, Debt—Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging—Contracts in Entity’s Own Equity (Subtopic 815-40): Accounting for Convertible Instruments and Contracts in an Entity’s Own Equity, which simplifies the accounting for convertible instruments by removing the separation models for (i) convertible debt with a cash conversion feature and (ii) convertible instruments with a beneficial conversion feature. As a result, a convertible debt instrument is accounted for as a single liability measured at its amortized cost. ASU 2020-06 also requires the application of the if-converted method for calculating diluted earnings per share. We adopted the standard as of July 3, 2022, using the modified retrospective approach. Upon adoption, our 2026 Notes and 2028 Notes were accounted for as a single liability measured at amortized cost, resulting in: (i) an increase to the convertible notes liability balance of $433.0 million to reflect the full principal amount of the convertible notes outstanding, net of issuance costs; (ii) a reduction to additional paid-in capital, net of estimated income tax effects, of $426.5 million, to remove the equity component separately recorded for the conversion features associated with the convertible notes; (iii) an increase to deferred tax assets, net of $92.1 million; and (iv) a cumulative-effect adjustment of $85.6 million, net of estimated income tax effects, to decrease the accumulated deficit. In addition, the adoption requires the use of the if-converted method for all convertible notes in the diluted net income per share calculation and the inclusion of the effect of potential share settlement of the convertible notes, if the effect is more dilutive. There was no impact to diluted earnings per share for the year ended July 1, 2023, as the inclusion of potential shares of common stock related to the convertible notes was anti-dilutive. Refer to “Note 10. Debt” for further information.

[0001628280-23-030374:notes:131]
The following table sets forth the impact upon adoption of ASU 2020-06 as of July 3, 2022 (in millions):

[0001628280-23-030374:notes:132]
|  |  | Short Term Debt - 2024 Notes |  | Long Term Debt - 2026 Notes |  | Long Term Debt - 2028 Notes |  | Additional Paid-In Capital |  | Accumulated Deficit |  | Deferred Tax Asset (Liability), net |
| Balances pre-adoption of ASC 2020-06 |  | $ | 409.9 |  |  | $ | 831.4 |  |  | $ | 634.7 |  |  | $ | 2,003.6 |  |  | $ | 129.1 |  |  | $ | 12.9 |  |
| Reclassify amounts from equity to debt |  | — |  |  | 312.9 |  |  | 229.3 |  |  | (542.2) |  |  | — |  |  | — |  |
| Adjustment for interest accretion |  | — |  |  | (99.5) |  |  | (9.7) |  |  | — |  |  | (109.2) |  |  | — |  |
| Tax effect |  | — |  |  | — |  |  | — |  |  | 115.7 |  |  | 23.6 |  |  | 92.1 |  |
| Balances upon adoption of ASC 2020-06 |  | $ | 409.9 |  |  | $ | 1,044.8 |  |  | $ | 854.3 |  |  | $ | 1,577.1 |  |  | $ | 43.5 |  |  | $ | 105.0 |  |


## us-gaap:EarningsPerShareTextBlock

[0001628280-23-030374:notes:133]
Note 3. Earnings Per Share

[0001628280-23-030374:notes:134]
The following table sets forth the computation of basic and diluted net income per share (in millions, except per share data):

[0001628280-23-030374:notes:135]
|  | Years Ended |
|  | July 1, 2023 |  | July 2, 2022 |  |  |  | July 3, 2021 |
| Numerator: |  |  |  |  |  |  |  |
| Net income (loss) - basic and diluted | $ | (131.6) |  |  | $ | 198.9 |  |  |  |  | $ | 397.3 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted average common shares outstanding - basic | 68.3 |  |  | 71.2 |  |  |  |  | 75.4 |  |
| Effect of dilutive securities from stock-based benefit plans | — |  |  | 0.6 |  |  |  |  | 0.8 |  |
| Shares issuable assuming conversion of the convertible notes | — |  |  | 2.4 |  |  |  |  | 2.2 |  |
| Weighted average common shares outstanding - diluted | 68.3 |  |  | 74.2 |  |  |  |  | 78.4 |  |
| Net income (loss) per share: |  |  |  |  |  |  |  |
| Basic | $ | (1.93) |  |  | $ | 2.79 |  |  |  |  | $ | 5.27 |  |
| Diluted | $ | (1.93) |  |  | $ | 2.68 |  |  |  |  | $ | 5.07 |  |

[0001628280-23-030374:notes:136]
Shares from stock-based benefit plans and shares issuable assuming conversion of our convertible notes are anti-dilutive for the year ended July 1, 2023 and are therefore excluded from the calculation of diluted net loss per share, as the Company had a net loss for the period. Average anti-dilutive shares excluded from the calculation of diluted net loss per share for the year ended July 1, 2023 include 24.8 million shares related to the convertible notes, 3.2 million shares issuable under RSUs and PSUs, and 0.2 million shares issuable under the 2015 Purchase Plan. Refer to “Note 15. Equity”.

[0001628280-23-030374:notes:137]
Anti-dilutive shares excluded from the calculation of diluted net income per share were 0.1 million, and 0.5 million for the year ended  July 2, 2022 and July 3, 2021, respectively.

[0001628280-23-030374:notes:138]
As a result of our adoption of ASU 2020-06 in the first quarter of fiscal 2023, potentially dilutive common shares issuable upon conversion of our outstanding convertible notes are determined using the if-converted method. For periods prior to the adoption of ASU 2020-06, which include fiscal year 2022 and 2021, our potentially dilutive common shares issuable upon conversion of our outstanding convertible notes are determined using the treasury stock method.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001628280-23-030374:notes:139]
Note 4. Business Combination

[0001628280-23-030374:notes:140]
NeoPhotonics Merger

[0001628280-23-030374:notes:141]
On November 3, 2021, we entered into an Agreement and Plan of Merger (the “Merger Agreement”) with NeoPhotonics and Neptune Merger Sub, Inc. On August 3, 2022 (the “Closing date”), we completed the acquisition of NeoPhotonics through the consummation of the merger and, accordingly, we acquired all of the issued and outstanding common stock of NeoPhotonics. The addition of NeoPhotonics expands our opportunity in some of the fastest growing markets for optical components used in cloud and telecom network infrastructure. The integrated company is better positioned to serve the needs of a global customer base who are increasingly utilizing photonics to accelerate the shift to digital and virtual approaches to work and life, the proliferation of IoT, 5G, and next-generation mobile networks, and the transition to advanced cloud computing architectures.

[0001628280-23-030374:notes:142]
We have applied the acquisition method of accounting in accordance with ASC Topic 805, Business Combinations, with respect to the fair value of purchase price consideration and the identifiable assets and liabilities of NeoPhotonics, which have been measured at estimated fair value as of the Closing date. The following tables summarize the total purchase price consideration (in millions):

[0001628280-23-030374:notes:143]
|  | Fair Value |
| Cash consideration for outstanding NeoPhotonics common stock (1) | $ | 867.3 |  |
| Settlement of pre-existing relationship (loan to NeoPhotonics) (2) | 50.0 |  |
| Stock-based compensation (3) | 17.1 |  |
| Total purchase price consideration | $ | 934.4 |  |

[0001628280-23-030374:notes:144]
(1) Under the terms of the Merger Agreement, NeoPhotonics stockholders received $16.00 per share for each of the 54.2 million NeoPhotonics common stock outstanding at the Closing date. As a result, we paid $867.3 million of cash consideration to shareholders of NeoPhotonics on the Closing date.

[0001628280-23-030374:notes:145]
(2) As contemplated by the Merger Agreement, on January 14, 2022, Lumentum and NeoPhotonics entered into a credit agreement where Lumentum agreed to make term loans (“loans”) to NeoPhotonics in an aggregate principal amount not to exceed $50.0 million to help fund capital expenditures and increase working capital associated with NeoPhotonics’ growth plans. During fiscal 2022, the Company funded a $30.0 million loan to NeoPhotonics. On August 1, 2022, we funded an additional $20.0 million loan to NeoPhotonics. The interest was payable monthly in arrears on the first day of each month. The loans would have matured on January 14, 2024, unless earlier repaid or accelerated. The $50.0 million loans in aggregate were included as part of the total purchase price consideration.

[0001628280-23-030374:notes:146]
(3) We paid $22.6 million cash consideration to holders of vested NeoPhotonics equity awards as of closing, of which $13.6 million was allocated to the purchase price consideration and $9.0 million was expensed immediately after the Closing date. Additionally, we issued replacement equity awards (the “Replacement Awards”) in settlement of certain NeoPhotonics equity awards that did not become vested at the Closing date, with the total fair value of $40.2 million based on our closing stock price on the Closing date. The portion of Replacement Awards attributed to pre-merger service was recorded as part of the consideration transferred, which was $3.5 million.

[0001628280-23-030374:notes:147]
The total transaction consideration of $934.4 million was funded by the cash balances of the combined company. We also recorded $28.7 million of merger-related costs, representing professional and other direct acquisition costs. Of the $28.7 million of merger-related costs, $8.3 million was incurred in fiscal year 2022 and $20.4 million was incurred in fiscal year 2023, which was recorded as selling, general and administrative expense in the consolidated statements of operations.

[0001628280-23-030374:notes:148]
We allocated the fair value of the purchase price consideration to the assets acquired and liabilities assumed as of the Closing date based on their estimated fair values. The excess of purchase price consideration over the fair value of net assets acquired is recorded as goodwill. We have completed the purchase price allocation. Our final allocation of the purchase price consideration to the assets acquired and liabilities assumed as of the Closing date is as follows (in millions):

[0001628280-23-030374:notes:149]
|  | Fair Value |
| Total purchase price consideration | $ | 934.4 |  |
| Assets acquired |  |
| Cash and cash equivalents | $ | 92.9 |  |
| Accounts receivable, net | 66.8 |  |
| Inventories | 84.3 |  |
| Prepayments and other current assets | 24.2 |  |
| Property, plant and equipment, net | 106.1 |  |
| Operating lease right-of-use assets, net | 16.9 |  |
| Other intangible assets, net (1) | 412.5 |  |
| Deferred tax asset | 5.4 |  |
| Other non-current assets | 1.9 |  |
| Total assets | 811.0 |  |
| Liabilities assumed |  |
| Accounts payable | 79.6 |  |
| Accrued payroll and related expenses | 11.1 |  |
| Accrued expenses | 3.8 |  |
| Other current liabilities | 10.6 |  |
| Operating lease liabilities, current | 2.8 |  |
| Operating lease liabilities, non-current | 13.2 |  |
| Deferred tax liability | 38.3 |  |
| Other non-current liabilities | 32.5 |  |
| Total liabilities | 191.9 |  |
| Goodwill | $ | 315.3 |  |

[0001628280-23-030374:notes:150]
(1) Other intangible assets include customer relationship of $144.5 million, developed technology of $220.0 million, and in-process research and development (“IPR&D”) of $48.0 million. Refer to “Note 9. Goodwill and Other Intangible Assets”.

[0001628280-23-030374:notes:151]
Goodwill has been assigned to the OpComms segment. Goodwill of $315.3 million arising from the acquisition is attributed to the expected synergies, including future cost efficiencies and other benefits that are expected to be generated by combining Lumentum and NeoPhotonics. None of the goodwill is expected to be deductible for local tax purposes. Refer to “Note 9. Goodwill and Other Intangible Assets.”

[0001628280-23-030374:notes:152]
From the Closing date, NeoPhotonics contributed $340.4 million of our consolidated net revenue for the year ended July 1, 2023. Due to the continued integration of the combined businesses, as well as our corporate structure and the allocation of selling, general and administrative costs, it is impracticable to determine NeoPhotonics’ contribution to our earnings.

[0001628280-23-030374:notes:153]
Supplemental Pro Forma Information

[0001628280-23-030374:notes:154]
The following supplemental pro forma information presents the combined results of operations for the years ended July 1, 2023 and July 2, 2022, respectively, as if the merger was completed at the first day of fiscal 2022. The supplemental pro forma financial information presented below is not necessarily indicative of the financial position or results of operations that would have been realized if the acquisition had been completed on the date indicated. The supplemental pro forma financial information does not reflect synergies that might have been achieved, nor is it indicative of future operating results or financial position.

[0001628280-23-030374:notes:155]
The pro forma financial information includes adjustments for: (i) additional amortization expense that would have been recognized related to the acquired intangible assets, (ii) additional depreciation expense that would have been recognized related to the acquired property, plant, and equipment, (iii) additional cost of sales related to the inventory valuation adjustment, (iv) acquisition related costs, such as third party transaction costs and restructuring costs, (v) stock-based compensation expense and (vi) the estimated income tax effect on the pro forma adjustments.

[0001628280-23-030374:notes:156]
The supplemental pro forma financial information for the periods presented is as follows (in millions):

[0001628280-23-030374:notes:157]
|  |  |  | Years Ended |
|  |  |  |  |  | July 1, 2023 |  | July 2, 2022 |
| Net revenue |  |  |  |  | $ | 1,790.9 |  |  | $ | 2,061.2 |  |
| Net income (loss) |  |  |  |  | (90.1) |  |  | 77.2 |  |

[0001628280-23-030374:notes:158]
Acquisition of IPG Photonics’ Telecom Transmission Product Lines

[0001628280-23-030374:notes:159]
On August 15, 2022 (“IPG Closing date”), we completed a transaction to acquire IPG Photonics’ telecom transmission product lines (“IPG telecom transmission product lines”) that are used to develop and market products for use in telecommunications and datacenter infrastructure, including Digital Signal Processors (DSPs), ASICs and optical transceivers. This acquisition enables us to expand our business in the OpComms segment.

[0001628280-23-030374:notes:160]
We have applied the acquisition method of accounting in accordance with ASC Topic 805, Business Combinations to account for this transaction. The total purchase price of $55.9 million was paid in cash. We have completed the purchase price allocation. Our final allocation of the purchase price consideration includes $29.1 million of in process research and development (“IPR&D”), $8.6 million of developed technology, $2.3 million of customer relationships, and $5.0 million of other net assets and liabilities, resulting in goodwill of $10.9 million.

[0001628280-23-030374:notes:161]
We also recorded $2.0 million of merger-related costs, representing professional and other direct acquisition costs. Of the $2.0 million of merger-related costs, $0.4 million was incurred in fiscal year 2022 and $1.6 million was incurred in fiscal year 2023, which was recorded as selling, general and administrative expense in the consolidated statements of operations.

[0001628280-23-030374:notes:162]
The pro forma financial information from the acquisition of the IPG telecom transmission product lines, assuming the acquisition had occurred as of the first day of fiscal 2022, as well as revenue and earnings generated during fiscal 2023, were not material for disclosure purposes.


## us-gaap:CashCashEquivalentsAndShortTermInvestmentsTextBlock

[0001628280-23-030374:notes:163]
Note 5. Cash, Cash Equivalents and Short-term Investments

[0001628280-23-030374:notes:164]
The following table summarizes our cash, cash equivalents and short-term investments by category for the periods presented (in millions):

[0001628280-23-030374:notes:165]
|  | Amortized Cost |  | Gross Unrealized Gains |  | Gross Unrealized Losses |  | Fair Value |
| July 1, 2023: |  |  |  |  |  |  |  |
| Cash | $ | 254.3 |  |  | $ | — |  |  | $ | — |  |  | $ | 254.3 |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Money market funds | 276.1 |  |  | — |  |  | — |  |  | 276.1 |  |
| U.S. Agency securities | 4.0 |  |  | — |  |  | — |  |  | 4.0 |  |
| U.S. Treasury securities | 324.6 |  |  | — |  |  | — |  |  | 324.6 |  |
| Total cash and cash equivalents | $ | 859.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 859.0 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 16.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 16.5 |  |
| Commercial paper | 132.9 |  |  | — |  |  | (0.2) |  |  | 132.7 |  |
| Corporate debt securities | 472.7 |  |  | — |  |  | (3.9) |  |  | 468.8 |  |
| U.S. Agency securities | 207.9 |  |  | — |  |  | (1.7) |  |  | 206.2 |  |
| U.S. Treasury securities | 332.4 |  |  | — |  |  | (2.0) |  |  | 330.4 |  |
| Total short-term investments | $ | 1,162.4 |  |  | $ | — |  |  | $ | (7.8) |  |  | $ | 1,154.6 |  |
| July 2, 2022: |  |  |  |  |  |  |  |
| Cash | $ | 235.9 |  |  | $ | — |  |  | $ | — |  |  | $ | 235.9 |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | 23.6 |  |  | — |  |  | — |  |  | 23.6 |  |
| Money market funds | 1,000.2 |  |  | — |  |  | — |  |  | 1,000.2 |  |
| U.S. Agency securities | 8.0 |  |  | — |  |  | — |  |  | 8.0 |  |
| U.S. Treasury securities | 22.5 |  |  | — |  |  | — |  |  | 22.5 |  |
| Total cash and cash equivalents | $ | 1,290.2 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,290.2 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 28.3 |  |  | $ | — |  |  | $ | — |  |  | $ | 28.3 |  |
| Commercial paper | 107.4 |  |  | — |  |  | (0.4) |  |  | 107.0 |  |
| Corporate debt securities | 539.9 |  |  | — |  |  | (7.4) |  |  | 532.5 |  |
| Municipal bonds | 1.0 |  |  | — |  |  | — |  |  | 1.0 |  |
| U.S. Agency securities | 67.1 |  |  | — |  |  | (1.4) |  |  | 65.7 |  |
| U.S. Treasury securities | 528.2 |  |  | 0.3 |  |  | (4.2) |  |  | 524.3 |  |
| Total short-term investments | $ | 1,271.9 |  |  | $ | 0.3 |  |  | $ | (13.4) |  |  | $ | 1,258.8 |  |

[0001628280-23-030374:notes:166]
We review our investment portfolio to identify and evaluate investments that have indicators of possible impairment. Factors considered in determining whether a loss is other-than-temporary include, but are not limited to, the length of time and extent a security’s fair value has been below its cost, the financial condition and near-term prospects of the investee, the credit quality of the security’s issuer, likelihood of recovery and our intent and ability to hold the security for a period of time sufficient to allow for any anticipated recovery in value. For the debt instruments we own, we also evaluate whether we have the intent to sell the security or whether it is more likely than not that we will be required to sell the security before recovery of its cost basis. We have not recorded our unrealized losses on our short-term investments into income because we do not intend to sell nor is it more likely than not that we will be required to sell these investments prior to recovery of their amortized cost basis.

[0001628280-23-030374:notes:167]
We use the specific-identification method to determine any realized gains or losses from the sale of our short-term investments classified as available-for-sale. During fiscal 2023, 2022 and 2021, we did not realize significant gains or losses on a gross level from the sale of our short-term investments classified as available-for-sale.

[0001628280-23-030374:notes:168]
The components of other income, net are as follows for the years presented (in millions):

[0001628280-23-030374:notes:169]
|  |  |  | Years Ended |
|  |  |  | July 1, 2023 |  | July 2, 2022 |  | July 3, 2021 |
| Foreign exchange gains (losses), net |  |  | $ | 7.0 |  |  | $ | 6.1 |  |  | $ | (4.4) |  |
| Interest and investment income |  |  | 40.8 |  |  | 6.1 |  |  | 5.7 |  |
| Other income (losses), net |  |  | 1.0 |  |  | (0.2) |  |  | 1.5 |  |
| Other income, net |  |  | $ | 48.8 |  |  | $ | 12.0 |  |  | $ | 2.8 |  |

[0001628280-23-030374:notes:170]
Included in the interest and investment income are $6.7 million, $3.9 million and $4.1 million of interest receivable as of July 1, 2023, July 2, 2022 and July 3, 2021, respectively, recorded in prepayments and other current assets within the consolidated balance sheets. We did not recognize an allowance for credit losses against the interest receivable in any of the periods presented as there were no such losses.

[0001628280-23-030374:notes:171]
Concurrent with the issuance of the 2029 Notes in June 2023, we used $132.8 million of the net proceeds to repurchase $125.0 million aggregate principal amount of the 2024 Notes. We recognized a gain of $1.0 million, which was recorded under other income, net on our consolidated statements of operations for the year ended July 1, 2023. Refer to “Note 10. Debt”.

[0001628280-23-030374:notes:172]
The following table summarizes unrealized losses on our cash equivalents and short-term investments by category that have been in a continuous unrealized loss position for more than 12 months and less than 12 months, respectively, as of the periods presented (in millions):

[0001628280-23-030374:notes:173]
|  | Continuous Loss Position For More Than 12 Months |  | Continuous Loss Position For Less Than 12 Months |  | Gross Unrealized Losses |  |  |  |  |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  |  |  |  |  |  |  |  |  |
| July 1, 2023 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | 39.6 |  |  | $ | (0.4) |  |  | $ | 170.6 |  |  | $ | (1.3) |  |  | $ | (1.7) |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | — |  |  | 7.7 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | — |  |  | — |  |  | 128.5 |  |  | (0.2) |  |  | (0.2) |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 93.6 |  |  | (1.2) |  |  | 358.9 |  |  | (2.7) |  |  | (3.9) |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 50.8 |  |  | (0.6) |  |  | 221.4 |  |  | (1.4) |  |  | (2.0) |  |  |  |  |  |  |  |  |  |
| Total | $ | 184.0 |  |  | $ | (2.2) |  |  | $ | 887.1 |  |  | $ | (5.6) |  |  | $ | (7.8) |  |  |  |  |  |  |  |  |  |
| July 2, 2022 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | — |  |  | $ | — |  |  | $ | 73.7 |  |  | $ | (1.4) |  |  | $ | (1.4) |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | — |  |  | 16.2 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | — |  |  | — |  |  | 130.7 |  |  | (0.4) |  |  | (0.4) |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 57.4 |  |  | (0.9) |  |  | 473.2 |  |  | (6.5) |  |  | (7.4) |  |  |  |  |  |  |  |  |  |
| Municipal bonds | — |  |  | — |  |  | 1.0 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | — |  |  | — |  |  | 366.0 |  |  | (4.2) |  |  | (4.2) |  |  |  |  |  |  |  |  |  |
| Total | $ | 57.4 |  |  | $ | (0.9) |  |  | $ | 1,060.8 |  |  | $ | (12.5) |  |  | $ | (13.4) |  |  |  |  |  |  |  |  |  |

[0001628280-23-030374:notes:174]
The following table classifies our short-term investments by remaining maturities (in millions):

[0001628280-23-030374:notes:175]
|  | July 1, 2023 |  | July 2, 2022 |
|  | Amortized Cost |  | Fair Value |  | Amortized Cost |  | Fair Value |
| Due within 1 year | $ | 762.9 |  |  | $ | 759.1 |  |  | $ | 1,010.9 |  |  | $ | 1,002.2 |  |
| Due between 1 year to 5 years | 399.5 |  |  | 395.5 |  |  | 261.0 |  |  | 256.6 |  |
|  | $ | 1,162.4 |  |  | $ | 1,154.6 |  |  | $ | 1,271.9 |  |  | $ | 1,258.8 |  |

[0001628280-23-030374:notes:176]
All available-for-sale securities have been classified as current, based on management’s intent and ability to use the funds in current operations.


## us-gaap:FairValueDisclosuresTextBlock

[0001628280-23-030374:notes:177]
Note 6. Fair Value Measurements

[0001628280-23-030374:notes:178]
Financial assets measured at fair value on a recurring basis are summarized below (in millions):

[0001628280-23-030374:notes:179]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| July 1, 2023 (1) |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Money market funds | $ | 276.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 276.1 |  |
| U.S. Agency securities | — |  |  | 4.0 |  |  | — |  |  | 4.0 |  |
| U.S. Treasury securities | 324.6 |  |  | — |  |  | — |  |  | 324.6 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | 16.5 |  |  | — |  |  | 16.5 |  |
| Commercial paper | — |  |  | 132.7 |  |  | — |  |  | 132.7 |  |
| Corporate debt securities | — |  |  | 468.8 |  |  | — |  |  | 468.8 |  |
| U.S. Agency securities | — |  |  | 206.2 |  |  | — |  |  | 206.2 |  |
| U.S. Treasury securities | 330.4 |  |  | — |  |  | — |  |  | 330.4 |  |
| Total assets | $ | 931.1 |  |  | $ | 828.2 |  |  | $ | — |  |  | $ | 1,759.3 |  |

[0001628280-23-030374:notes:180]
(1)  Excludes $254.3 million in cash held in our bank accounts as of July 1, 2023.

[0001628280-23-030374:notes:181]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| July 2, 2022: (1) |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | — |  |  | $ | 23.6 |  |  | $ | — |  |  | $ | 23.6 |  |
| Money market funds | 1,000.2 |  |  | — |  |  | — |  |  | 1,000.2 |  |
| U.S. Agency securities | — |  |  | 8.0 |  |  | — |  |  | 8.0 |  |
| U.S. Treasury securities | 22.5 |  |  | — |  |  | — |  |  | 22.5 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | 28.3 |  |  | — |  |  | 28.3 |  |
| Commercial paper | — |  |  | 107.0 |  |  | — |  |  | 107.0 |  |
| Corporate debt securities | — |  |  | 532.5 |  |  | — |  |  | 532.5 |  |
| Municipal bonds | — |  |  | 1.0 |  |  | — |  |  | 1.0 |  |
| U.S. Agency securities | — |  |  | 65.7 |  |  | — |  |  | 65.7 |  |
| U.S. Treasury securities | 524.3 |  |  | — |  |  | — |  |  | 524.3 |  |
| Total assets | $ | 1,547.0 |  |  | $ | 766.1 |  |  | $ | — |  |  | $ | 2,313.1 |  |

[0001628280-23-030374:notes:182]
(1)  Excludes $235.9 million in cash held in our bank accounts as of July 2, 2022.

[0001628280-23-030374:notes:183]
Financial Instruments Not Recorded at Fair Value on a Recurring Basis

[0001628280-23-030374:notes:184]
We report our financial instruments at fair value with the exception of the convertible notes, see “Note 10. Debt”. The estimated fair value of the convertible notes was determined based on the trading price of the convertible notes as of the last day of trading for the period. We consider the fair value of the convertible notes to be a Level 2 measurement as they are not actively traded in markets.

[0001628280-23-030374:notes:185]
The carrying amounts and estimated fair values of our convertible notes are as follows for the periods presented (in millions):

[0001628280-23-030374:notes:186]
|  | July 1, 2023 |  | July 2, 2022 |
|  | Carrying Amount |  | Estimated Fair Value |  | Carrying Amount |  | Estimated Fair Value |
| 2029 Notes | $ | 598.6 |  |  | $ | 625.2 |  |  | $ | — |  |  | $ | — |  |
| 2028 Notes | 855.5 |  |  | 677.8 |  |  | 634.7 |  |  | 735.7 |  |
| 2026 Notes | 1,045.9 |  |  | 933.2 |  |  | 831.4 |  |  | 1,065.0 |  |
| 2024 Notes | 311.6 |  |  | 345.2 |  |  | 409.9 |  |  | 614.2 |  |
|  | $ | 2,811.6 |  |  | $ | 2,581.4 |  |  | $ | 1,876.0 |  |  | $ | 2,414.9 |  |

[0001628280-23-030374:notes:187]
We periodically review our intangible and other long-lived assets for impairment whenever events or changes in circumstances indicate that the carrying amount of such assets may not be recoverable. Determination of recoverability is based on the lowest level of identifiable estimated undiscounted cash flows resulting from use of the asset and its eventual disposition. If not recoverable, an impairment loss would be calculated based on the excess of the carrying amount over the fair value.

[0001628280-23-030374:notes:188]
Management utilizes various valuation methods, including an income approach, a market approach and a cost approach, to estimate the fair value of intangibles and other long-lived assets. During the annual impairment testing performed in the fourth quarter of fiscal 2023, we concluded that our intangible and other long-lived assets were not impaired. We review our intangible and other long-lived assets for impairment at least annually in the fourth quarter of each fiscal year, or any indicators of impairment exist.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001628280-23-030374:notes:189]
Note 7. Balance Sheet Details

[0001628280-23-030374:notes:190]
Allowance for current expected credit losses

[0001628280-23-030374:notes:191]
We did not have any allowance for credit losses other than our allowance for uncollectible accounts receivable. As of July 1, 2023 and July 2, 2022, the allowance for credit losses on our trade receivables was less than $0.1 million for both years.

[0001628280-23-030374:notes:192]
Inventories

[0001628280-23-030374:notes:193]
The components of inventories were as follows (in millions):

[0001628280-23-030374:notes:194]
|  | July 1, 2023 |  | July 2, 2022 |
| Raw materials and purchased parts | $ | 170.5 |  |  | $ | 98.9 |  |
| Work in process | 103.2 |  |  | 92.2 |  |
| Finished goods | 134.9 |  |  | 59.0 |  |
| Inventories | $ | 408.6 |  |  | $ | 250.1 |  |

[0001628280-23-030374:notes:195]
In connection with the NeoPhotonics merger, we recorded $17.8 million of inventory fair value step-up as of the merger Closing date. As of July 1, 2023, the fair value step-up is fully amortized.

[0001628280-23-030374:notes:196]
Operating lease right-of-use assets, net

[0001628280-23-030374:notes:197]
Operating lease right-of-use assets, net were as follows (in millions):

[0001628280-23-030374:notes:198]
|  | July 1, 2023 |  | July 2, 2022 |
| Operating lease right-of-use assets | $ | 116.5 |  |  | $ | 102.1 |  |
| Less: accumulated amortization | (39.2) |  |  | (28.5) |  |
| Operating lease right-of-use assets, net | $ | 77.3 |  |  | $ | 73.6 |  |

[0001628280-23-030374:notes:199]
In connection with the NeoPhotonics merger, we acquired $16.9 million right-of-use assets as of the merger Closing date,  related to leases of real estate properties used as our manufacturing and R&D premises. These leases are accounted for as operating leases and have the remaining lease term ranging from 3.8 to 6.4 years at the Closing date.

[0001628280-23-030374:notes:200]
Property, plant and equipment, net

[0001628280-23-030374:notes:201]
The components of property, plant and equipment, net were as follows (in millions):

[0001628280-23-030374:notes:202]
|  | July 1, 2023 |  | July 2, 2022 |
| Land | $ | 63.5 |  |  | $ | 49.7 |  |
| Buildings and improvement | 170.3 |  |  | 105.3 |  |
| Machinery and equipment | 657.9 |  |  | 548.8 |  |
| Computer equipment and software | 41.4 |  |  | 31.3 |  |
| Furniture and fixtures | 10.2 |  |  | 8.9 |  |
| Leasehold improvements | 49.6 |  |  | 35.7 |  |
| Construction in progress | 69.2 |  |  | 47.0 |  |
|  | 1,062.1 |  |  | 826.7 |  |
| Less: Accumulated depreciation | (572.6) |  |  | (466.2) |  |
| Property, plant and equipment, net | $ | 489.5 |  |  | $ | 360.5 |  |

[0001628280-23-030374:notes:203]
Our construction in progress primarily includes machinery and equipment that we expect to place in service in the next 12 months.

[0001628280-23-030374:notes:204]
In connection with our merger with NeoPhotonics in fiscal 2023, we assumed $106.1 million of property, plant and equipment, net, as of the Closing date.

[0001628280-23-030374:notes:205]
During fiscal 2022, we purchased the land and buildings in Thailand and Slovenia with a fair value of $15.1 million in order to expand our manufacturing capacity. Refer to Note 18. Operating Segments and Geographic Information for property, plant and equipment by geographic areas based on the physical location of the assets.

[0001628280-23-030374:notes:206]
During fiscal 2021, we sold land and building located in San Jose, California for $23.0 million and recognized a gain of $8.3 million, which was recorded as an offset to selling, general and administrative expenses in our consolidated statement of operations for the year ended July 3, 2021. As part of this transition, in fiscal 2022, we sold equipment that was no longer needed and recognized a gain of $5.9 million, which we recorded as an offset to cost of sales in our consolidated statement of operations for the year ended July 2, 2022.

[0001628280-23-030374:notes:207]
During fiscal 2023, 2022 and 2021, we recorded depreciation expense of $106.6 million, $81.6 million, and $91.4 million, respectively.

[0001628280-23-030374:notes:208]
Other current liabilities

[0001628280-23-030374:notes:209]
The components of other current liabilities were as follows (in millions):

[0001628280-23-030374:notes:210]
|  | July 1, 2023 |  | July 2, 2022 |
| Restructuring and related accrual (1) | $ | 5.0 |  |  | $ | — |  |
| Warranty reserve (2) | 6.8 |  |  | 10.0 |  |
| Deferred revenue and customer deposits | 2.1 |  |  | — |  |
| Income tax payable (3) | 28.0 |  |  | 26.0 |  |
| Other current liabilities | 5.9 |  |  | 3.4 |  |
| Other current liabilities | $ | 47.8 |  |  | $ | 39.4 |  |

[0001628280-23-030374:notes:211]
(1) Refer to “Note 12. Restructuring and Related Charges.”

[0001628280-23-030374:notes:212]
(2) Refer to “Note 17. Commitments and Contingencies.”

[0001628280-23-030374:notes:213]
(3) Refer to “Note 14. Income Taxes.”

[0001628280-23-030374:notes:214]
Other non-current liabilities

[0001628280-23-030374:notes:215]
The components of other non-current liabilities were as follows (in millions):

[0001628280-23-030374:notes:216]
|  | July 1, 2023 |  | July 2, 2022 |
| Asset retirement obligation | $ | 8.2 |  |  | $ | 4.6 |  |
| Pension and related accrual (1) | 9.6 |  |  | 7.2 |  |
| Unrecognized tax benefit | 64.4 |  |  | 30.5 |  |
| Other non-current liabilities | 9.2 |  |  | 0.6 |  |
| Other non-current liabilities | $ | 91.4 |  |  | $ | 42.9 |  |

[0001628280-23-030374:notes:217]
(1) We have defined benefit pension plans in Japan, Switzerland, and Thailand. In connection with our merger with NeoPhotonics in August 2023, we assumed an additional defined benefit plan covering employees in Japan. Pension and related accrual of $9.6 million as of July 1, 2023 relates to $10.2 million of non-current portion of benefit obligation, offset by $0.6 million of funding for the pension plan in Switzerland. Pension and related accrual of $7.2 million as of July 2, 2022 relates to $7.7 million of non-current portion of benefit obligation, offset by $0.5 million of funding for the pension plan in Switzerland. Refer to “Note 16. Employee Retirement Plans”.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001628280-23-030374:notes:218]
Note 8. Leases

[0001628280-23-030374:notes:219]
We lease certain real and personal property from unrelated third parties under non-cancellable operating leases that expire at various dates through fiscal 2033. These operating leases are primarily for administrative offices, research and development and manufacturing facilities, as well as sales offices in various countries around the world. Certain leases require us to pay property taxes, insurance and routine maintenance, and include escalation clauses. Many leases include one or more options to renew. We do not assume renewals in our determination of the lease term unless the renewals are deemed to be reasonably assured at lease commencement.

[0001628280-23-030374:notes:220]
As of July 1, 2023, we sublease a portion of our offices in the Japan, United Kingdom, the United States and Canada. These subleases will expire at various dates through fiscal year 2028. We anticipate receiving approximately $1.8 million in sublease income over the next fiscal year.

[0001628280-23-030374:notes:221]
The components of lease costs, lease term, and discount rate are as follows (in millions, except for weighted average data):

[0001628280-23-030374:notes:222]
|  | July 1, 2023 |  | July 2, 2022 |  | July 3, 2021 |
| Finance lease cost | $ | — |  |  | $ | — |  |  | $ | 0.5 |  |
| Operating lease cost | 14.4 |  |  | 13.0 |  |  | 14.1 |  |
| Short-term and variable lease cost | 2.7 |  |  | 2.0 |  |  | 4.3 |  |
| Sublease income | (2.6) |  |  | (3.0) |  |  | (2.8) |  |
| Total lease cost | $ | 14.5 |  |  | $ | 12.0 |  |  | $ | 16.1 |  |
| Weighted average remaining lease term (in years): |  |  |  |  |  |
| Operating leases | 5.8 |  | 6.9 |  | 7.5 |
| Finance leases | N/A |  | N/A |  | — |  |
| Weighted average discount rate (in percentages): |  |  |  |  |  |
| Operating leases | 3.1 | % |  | 3.0 | % |  | 3.5 | % |
| Finance leases | N/A |  | N/A |  | — | % |

[0001628280-23-030374:notes:223]
As of July 1, 2023, maturities of our operating lease liabilities, which do not include short-term leases and variable lease payments, were as follows (in millions):

[0001628280-23-030374:notes:224]
| Fiscal Years |  | Operating Leases (1) |  |  |  |  |
| 2024 |  | $ | 16.1 |  |  |  |  |  |
| 2025 |  | 13.2 |  |  |  |  |  |
| 2026 |  | 11.6 |  |  |  |  |  |
| 2027 |  | 9.3 |  |  |  |  |  |
| 2028 |  | 5.4 |  |  |  |  |  |
| Thereafter |  | 12.2 |  |  |  |  |  |
| Total minimum lease payments |  | 67.8 |  |  |  |  |  |
| Less: amount representing interest |  | (5.7) |  |  |  |  |  |
| Present value of total lease liabilities |  | $ | 62.1 |  |  |  |  |  |

[0001628280-23-030374:notes:225]
(1)  Non-cancellable sublease proceeds for fiscal 2024 of $1.8 million are not included in the table above.


## us-gaap:GoodwillDisclosureTextBlock

[0001628280-23-030374:notes:226]
Note 9. Goodwill and Other Intangible Assets

[0001628280-23-030374:notes:227]
In the first quarter of fiscal 2023, we completed two acquisitions, our merger with NeoPhotonics and the acquisition of IPG telecom transmission product lines. We recognized goodwill of $315.3 million related to the NeoPhotonics merger and $10.9 million related to the acquisition of the IPG telecom transmission product lines as of July 1, 2023. We allocated the entire goodwill amount in connection with these two acquisitions to the OpComms segment.

[0001628280-23-030374:notes:228]
The following table presents our goodwill balance by the reportable segments as of July 1, 2023 and July 2, 2022 (in millions):

[0001628280-23-030374:notes:229]
|  |  | Optical Communications |  | Commercial Lasers |  | Total |
|  | Balance as of July 2, 2022 | $ | 363.5 |  |  | $ | 5.4 |  |  | $ | 368.9 |  |
|  | Acquisition of NeoPhotonics (1) | 315.3 |  |  | — |  |  | 315.3 |  |
|  | Acquisition of IPG telecom transmission product lines (2) | 10.9 |  |  | — |  |  | 10.9 |  |
|  | Balance as of July 1, 2023 | $ | 689.7 |  |  | $ | 5.4 |  |  | $ | 695.1 |  |

[0001628280-23-030374:notes:230]
(1) We recorded $318.3 million of goodwill as of the acquisition date, and $3.0 million of measurement period adjustments to reduce goodwill during the year ended July 1, 2023.

[0001628280-23-030374:notes:231]
(2)  We recorded $6.5 million of goodwill as of the acquisition date, and $4.4 million of measurement period adjustments to increase goodwill during the year ended July 1, 2023.

[0001628280-23-030374:notes:232]
Impairment of Goodwill

[0001628280-23-030374:notes:233]
We review goodwill for impairment during the fourth quarter of each fiscal year or more frequently if events or circumstances indicate that an impairment loss may have occurred. Based on the impairment analysis performed in the fourth quarter of each year presented, the fair value of each of our reporting units substantially exceeded the carrying value; as such, our annual qualitative assessment did not indicate that a more detailed quantitative analysis was necessary.

[0001628280-23-030374:notes:234]
Other Intangibles

[0001628280-23-030374:notes:235]
The intangible assets are amortized on a straight-line basis over the estimated useful lives, except for certain customer relationships, which are amortized using an accelerated method of amortization over the expected customer lives, more accurately reflecting the pattern of realization of economic benefits we expect to derive. Acquired developed technologies are amortized to cost of sales and customer relationships are amortized to selling, general and administrative expenses in the consolidated statement of operations.

[0001628280-23-030374:notes:236]
In-process research and development (“IPR&D”) is initially capitalized at fair value as an intangible asset with an indefinite life and assessed for impairment thereafter. When an IPR&D project is completed, the IPR&D is reclassified as an amortizable purchased intangible asset and amortized over the asset’s estimated useful life.

[0001628280-23-030374:notes:237]
During the annual impairment testing performed in the fourth quarter of fiscal 2023, we concluded that our intangible and other long-lived assets were not impaired at the asset group level. We review our intangible and other long-lived assets for impairment at least annually in the fourth quarter of each fiscal year, absent any interim indicators of impairment.  There were no indicators of impairment at the asset group level during the during the years ended July 1, 2023 and July 2, 2022.

[0001628280-23-030374:notes:238]
In connection with the merger with NeoPhotonics and the acquisition of the IPG telecom transmission product lines, we recorded $452.5 million of intangible assets. Refer to “Note 4. Business Combination”. The intangible assets acquired from the acquisitions were as follows as of the acquisition date (in millions, except for weighted average amortization period):

[0001628280-23-030374:notes:239]
|  | Fair value at the acquisition date |  | Weighted average amortization period(in years) |
|  | NeoPhotonics |  | IPG telecom transmission product lines |  | Total acquired |  |
| Acquired developed technologies | $ | 220.0 |  |  | $ | 8.6 |  |  | $ | 228.6 |  |  | 5.2 |
| Customer relationships | 144.5 |  |  | 2.3 |  |  | 146.8 |  |  | 5.9 |
| In-process research and development | 48.0 |  |  | 29.1 |  |  | 77.1 |  |  | n/a |
| Total intangible assets | $ | 412.5 |  |  | $ | 40.0 |  |  | $ | 452.5 |  |  |  |

[0001628280-23-030374:notes:240]
During the year ended July 1, 2023, we reclassified $23.3 million of IPR&D intangible assets acquired from NeoPhotonics to acquired developed technologies for IPR&D projects that were completed during the period. We recorded $2.6 million of related amortization expense in our consolidated statements of operations during the year ended July 1, 2023.

[0001628280-23-030374:notes:241]
During the year ended July 1, 2023, we recorded a total charge of $21.3 million to write-off acquired intangible assets, which includes $12.9 million of research and development expense for IPR&D intangible assets acquired from NeoPhotonics for projects we will no longer pursue, and $6.8 million of cost of sales for developed technologies acquired from IPG and $1.6 million of selling, general and administrative expense for customer relationship acquired from IPG primarily due to product discontinuation as well as changes in customer demand.

[0001628280-23-030374:notes:242]
The following tables present details of all of our intangibles, including those acquired in connection with our acquisitions in the first quarter of fiscal 2023, as of the periods presented (in millions, except for weighted average remaining amortization period):

[0001628280-23-030374:notes:243]
| July 1, 2023 | Gross Carrying Amounts |  | Accumulated Amortization |  | Net Carrying Amounts |  | Weighted average remaining amortization period (years) |
| Acquired developed technologies | $ | 630.9 |  |  | $ | (385.5) |  |  | $ | 245.4 |  |  | 4.2 |
| Customer relationships | 289.7 |  |  | (116.8) |  |  | 172.9 |  |  | 3.7 |
| In-process research and development | 40.9 |  |  | — |  |  | 40.9 |  |  | n/a |
| Total intangible assets | $ | 961.5 |  |  | $ | (502.3) |  |  | $ | 459.2 |  |  |  |

[0001628280-23-030374:notes:244]
| July 2, 2022 | Gross Carrying Amounts |  | Accumulated Amortization |  | Net Carrying Amounts |  | Weighted average remaining amortization period (years) |
| Acquired developed technologies | $ | 390.3 |  |  | $ | (303.6) |  |  | $ | 86.7 |  |  | 2.5 |
| Customer relationships | 145.0 |  |  | (76.0) |  |  | 69.0 |  |  | 4.4 |
| Total intangible assets | $ | 535.3 |  |  | $ | (379.6) |  |  | $ | 155.7 |  |  |  |

[0001628280-23-030374:notes:245]
During fiscal 2023, 2022 and 2021, we recorded $127.7 million, $85.5 million and $85.7 million, respectively, of amortization related to intangibles assets.

[0001628280-23-030374:notes:246]
The following table presents details of amortization for the periods presented (in millions):

[0001628280-23-030374:notes:247]
|  | Years ended |
|  | July 1, 2023 |  | July 2, 2022 |  |  |  | July 3, 2021 |
| Cost of sales | $ | 84.4 |  |  | $ | 62.9 |  |  |  |  | $ | 61.7 |  |
| Selling, general and administrative | 43.3 |  |  | 22.6 |  |  |  |  | 24.0 |  |
| Total amortization of intangibles | $ | 127.7 |  |  | $ | 85.5 |  |  |  |  | $ | 85.7 |  |

[0001628280-23-030374:notes:248]
Based on the carrying amount of our acquired developed technologies and customer relationships as of July 1, 2023, and assuming no future impairment of the underlying assets, the estimated future amortization is as follows (in millions):

[0001628280-23-030374:notes:249]
| Fiscal Years |  |
| 2024 | $ | 110.8 |  |
| 2025 | 96.9 |  |
| 2026 | 87.2 |  |
| 2027 | 76.7 |  |
| 2028 | 37.3 |  |
| Thereafter | 9.4 |  |
| Total | $ | 418.3 |  |

[0001628280-23-030374:notes:250]
The table above excludes in-process research and development intangible assets.


## us-gaap:ScheduleOfFiniteLivedIntangibleAssetsTableTextBlock

[0001628280-23-030374:notes:251]
The intangible assets acquired from the acquisitions were as follows as of the acquisition date (in millions, except for weighted average amortization period):


## us-gaap:DebtDisclosureTextBlock

[0001628280-23-030374:notes:252]
Note 10. Debt

[0001628280-23-030374:notes:253]
Convertible Notes

[0001628280-23-030374:notes:254]
2029 Notes

[0001628280-23-030374:notes:255]
On June 16, 2023, we issued $603.7 million in aggregate principal amount of 2029 Notes in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act of 1933, as amended. The 2029 Notes are governed by an indenture between the Company and U.S. Bank Trust Company National Association, (as successor in interest to U.S. Bank National Association), as a trustee (the “2029 Indenture”). The 2029 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001628280-23-030374:notes:256]
The net proceeds from the sale of the 2029 Notes was $599.4 million, after deducting $4.3 million of net issuance costs. In addition, we incurred $0.8 million of professional fees directly related to this transaction. Concurrent with the issuance of the 2029 Notes, we used $132.8 million of the net proceeds to repurchase $125.0 million aggregate principal amount of the 2024 Notes and $125.0 million of the net proceeds to repurchase our common stock in privately negotiated transactions. We intend to use the remaining net proceeds for general corporate purposes, which may include the repayment of our indebtedness, including any of our existing convertible notes, capital expenditures, working capital and potential acquisitions.

[0001628280-23-030374:notes:257]
The 2029 Notes bear interest at a rate of 1.50% per year, payable semi-annually in arrears on June 15 and December 15 of each year, beginning on December 15, 2023. The 2029 Notes will mature on December 15, 2029, unless earlier redeemed, repurchased by us, or converted pursuant to their terms.

[0001628280-23-030374:notes:258]
The initial conversion rate is 14.3808 shares of common stock per $1,000 principal amount of the 2029 Notes (which is equivalent to an initial conversion price of approximately $69.54 per share). The conversion rate is subject to adjustment upon the occurrence of certain events specified in the 2029 Indenture, but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert the 2029 Notes in connection with such make-whole fundamental change or notice of redemption.

[0001628280-23-030374:notes:259]
Prior to the close of business on the business day immediately preceding September 15, 2029, holders of the 2029 Notes may convert their 2029 Notes only under the following circumstances:

[0001628280-23-030374:notes:260]
•during any fiscal quarter commencing after September 30, 2023 (and only during such fiscal quarter), if the last reported sale price of the common stock for at least 20 trading days (whether or not consecutive) during the period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% if the applicable conversion price on each applicable trading day;

[0001628280-23-030374:notes:261]
•during the five consecutive business day period after any five consecutive trading day period (the “2029 measurement period”) in which the trading price per $1,000 principal amount of 2029 Notes for each trading day of the 2029 measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate on each such trading day;

[0001628280-23-030374:notes:262]
•if we call any or all of the 2029 Notes for redemption, at any time prior to the close of business on the second business day immediately preceding the redemption date; or

[0001628280-23-030374:notes:263]
•upon the occurrence of specified corporate events as specified in the 2029 Indenture.

[0001628280-23-030374:notes:264]
On or after September 15, 2029 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their 2029 Notes at any time. Upon conversion, we will satisfy our conversion obligation in cash, shares of common stock or a combination of cash and shares of common stock, at our election.

[0001628280-23-030374:notes:265]
We may redeem for cash all or any portion of the 2029 Notes, at our option (subject to the partial redemption limitation set forth in the 2029 Indenture), on or after June 22, 2026, if the last reported sale price of our  common stock has been at least 130% of the conversion price then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading-day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which we provide notice of redemption at a redemption price equal to 100% of the principal amount of the 2029 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. No sinking fund is provided for the 2029 Notes. If we elect to redeem fewer than all of the outstanding 2029 Notes, at least $100.0 million aggregate principal amount of the 2029 Notes must be outstanding and not subject to redemption as of the redemption notice date. Upon the occurrence of a fundamental change (as defined in the 2029 Indenture), holders may require us to repurchase all or a portion of their 2029 Notes for cash at a price equal to 100% of the principal amount of the 2029 Notes to be repurchased, plus any accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

[0001628280-23-030374:notes:266]
The entire 2029 Notes are recorded as convertible notes, non-current in our consolidated balance sheets as of July 1, 2023, measured at amortized cost.

[0001628280-23-030374:notes:267]
2028 Notes

[0001628280-23-030374:notes:268]
In March 2022, we issued $861.0 million in aggregate principal amount of 2028 Notes in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act of 1933, as amended. The 2028 Notes are governed by an indenture between the Company and U.S. Bank Trust Company National Association (as successor in interest to U.S. Bank National Association), as a trustee (the “2028 Indenture”). The 2028 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001628280-23-030374:notes:269]
The net proceeds from the sale of the 2028 Notes was $854.8 million, after deducting $6.2 million in issuance costs. In addition, we incurred $0.7 million of professional fees directly related to this transaction.  Concurrent with the issuance of the 2028 Notes, we used $200.0 million of the net proceeds to repurchase our common stock in privately negotiated transactions.

[0001628280-23-030374:notes:270]
The 2028 Notes bear interest at a rate of 0.50% per year, payable semi-annually in arrears on June 15 and December 15 of each year, beginning on June 15, 2022. The 2028 Notes will mature on June 15, 2028, unless earlier redeemed, repurchased by us, or converted pursuant to their terms.

[0001628280-23-030374:notes:271]
The initial conversion rate is 7.6319 shares of common stock per $1,000 principal amount of the 2028 Notes (which is equivalent to an initial conversion price of approximately $131.03 per share). The conversion rate is subject to adjustment upon the occurrence of certain events specified in the 2028 Indenture, but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert the 2028 Notes in connection with such make-whole fundamental change or notice of redemption.

[0001628280-23-030374:notes:272]
Prior to the close of business on the business day immediately preceding March 15, 2028, holders of the 2028 Notes may convert their 2028 Notes only under the following circumstances:

[0001628280-23-030374:notes:273]
•during any fiscal quarter (and only during such fiscal quarter), if the last reported sale price of the common stock for at least 20 trading days (whether or not consecutive) during the 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% if the applicable conversion price, or $170.34 on each applicable trading day;

[0001628280-23-030374:notes:274]
•during the five consecutive business day period after any five consecutive trading day period (the “2028 measurement period”) in which the trading price per $1,000 principal amount of the 2028 Notes for each trading day of the 2028 measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate on each such trading day;

[0001628280-23-030374:notes:275]
•if we call any or all of the 2028 Notes for redemption, at any time prior to the close of business on the second business day immediately preceding the redemption date; or

[0001628280-23-030374:notes:276]
•upon the occurrence of specified corporate events as specified in the 2028 Indenture.

[0001628280-23-030374:notes:277]
On or after March 15, 2028 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their 2028 Notes at any time. Upon conversion, we may satisfy our conversion obligation in cash, shares of common stock or a combination of cash and shares of common stock, at our election.

[0001628280-23-030374:notes:278]
We may redeem for cash all or any portion of the 2028 Notes, at our option (subject to the partial redemption limitation set forth in the 2028 Indenture), on or after June 20, 2025, if the last reported sale price of its common stock has been at least 130% of the conversion price then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading-day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which we provide notice of redemption at a redemption price equal to 100% of the principal amount of the 2028 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. No sinking fund is provided for the 2028 Notes. If we elect to redeem fewer than all of the outstanding 2028 Notes, at least $100.0 million aggregate principal amount of the 2028 Notes must be outstanding and not subject to redemption as of the redemption notice date.  Upon the occurrence of a fundamental change (as defined in the 2028 Indenture), holders may require us to repurchase all or a portion of their 2028 Notes for cash at a price equal to 100% of the principal amount of the 2028 Notes to be repurchased, plus any accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

[0001628280-23-030374:notes:279]
We initially bifurcated the principal amount of the 2028 Notes into liability and equity components.  The liability component of the 2028 Notes was initially valued at $629.8 million based on the contractual cash flow discounted at an appropriate comparable market on the non-convertible debt borrowing rate at the date of issuance, which was 5.7%, with the equity component representing the residual amount of the proceeds of $231.2 million, which was recorded as a debt discount. Upon adoption of ASU 2020-06 in the first quarter of fiscal 2023, our 2028 Notes were accounted for as a single liability measured at amortized cost.  Refer to “Note 2. Recently Issued Accounting Pronouncements” for the detailed adoption impact.

[0001628280-23-030374:notes:280]
2026 Notes

[0001628280-23-030374:notes:281]
In December 2019, we issued $1,050.0 million in aggregate principal amount of the 2026 Notes in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act. The 2026 Notes are governed by an indenture between the Company and U.S. Bank Trust Company National Association (as successor in interest to U.S. Bank National Association), as trustee (the “2026 Indenture”). We used approximately $196.0 million of the net proceeds of the offering to repay in full all amounts outstanding under our term loan facility, and a portion of the net proceeds of the offering to purchase approximately $200.0 million of our common stock concurrently with the pricing of the offering in privately negotiated transactions. The 2026 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, the incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001628280-23-030374:notes:282]
The 2026 Notes bear interest at a rate of 0.50% per year, payable semi-annually in arrears on June 15 and December 15 of each year, beginning on June 15, 2020. The 2026 Notes will mature on December 15, 2026, unless earlier redeemed, repurchased by us, or converted pursuant to their terms.

[0001628280-23-030374:notes:283]
The initial conversion rate is 10.0711 shares of common stock per $1,000 principal amount of the 2026 Notes (which is equivalent to an initial conversion price of approximately $99.29 per share). The conversion rate is subject to adjustment upon the occurrence of certain events specified in the 2026 Indenture, but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares set forth in the 2026 Indenture or a holder that elects to convert the 2026 Notes in connection with such make-whole fundamental change or notice of redemption.

[0001628280-23-030374:notes:284]
Prior to the close of business on the business day immediately preceding September 15, 2026, holders of the 2026 Notes may convert their 2026 Notes only under the following circumstances:

[0001628280-23-030374:notes:285]
•during any fiscal quarter (and only during such fiscal quarter), if the last reported sale price of the common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price of the 2026 Notes, or $129.08 on each applicable trading day;

[0001628280-23-030374:notes:286]
•during the five business day period after any five consecutive trading day period (the "2026 measurement period") in which the trading price per $1,000 principal amount of the 2026 Notes for each trading day of the 2026 measurement period was less than 98% of the product of the last reported sale price of our common stock and the conversion rate for the 2026 Notes on each such trading day;

[0001628280-23-030374:notes:287]
•if we call any or all of the 2026 Notes for redemption, at any time prior to the close of business on the second business day immediately preceding the relevant redemption date; or

[0001628280-23-030374:notes:288]
•upon the occurrence of specified corporate events as specified in the 2026 Indenture.

[0001628280-23-030374:notes:289]
On or after September 15, 2026 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert the 2026 Notes at any time. Upon conversion, we may satisfy our conversion obligation in cash, shares of common stock or a combination of cash and shares of common stock, at our election.

[0001628280-23-030374:notes:290]
We may redeem for cash, for all or any portion of the 2026 Notes, at our option, on or after December 20, 2023, if the last reported sale price of its common stock has been at least 130% of the conversion price then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading-day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which we provide a notice of redemption at a redemption price equal to 100% of the principal amount of the 2026 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. No sinking fund is provided for the 2026 Notes. Upon the occurrence of a fundamental change (as defined in the 2026 Indenture), holders may require us to repurchase all or a portion of the 2026 Notes for cash at a price equal to 100% of the principal amount of the 2026 Notes to be repurchased, plus any accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

[0001628280-23-030374:notes:291]
We initially bifurcated the principal amount of the 2026 Notes into liability and equity components. The liability component of the 2026 Notes was valued at $734.8 million based on the contractual cash flows discounted at an appropriate comparable market non-convertible debt borrowing rate at the date of issuance of 5.8% with the equity component representing the residual amount of the proceeds of $315.2 million, which was recorded as a debt discount.  Upon adoption of ASU 2020-06 in the first quarter of fiscal 2023, our 2026 Notes were accounted for as a single liability measured at amortized cost. Refer to “Note 2. Recently Issued Accounting Pronouncements” for the detailed adoption impact.

[0001628280-23-030374:notes:292]
2024 Notes

[0001628280-23-030374:notes:293]
In March 2017, we issued $450.0 million in aggregate principal amount of the 2024 Notes in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act. The 2024 Notes are governed by an indenture between the Company, and U.S. Bank Trust Company National Association (as successor in interest to U.S. Bank National Association), as trustee (the “2024 Indenture”). The 2024 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001628280-23-030374:notes:294]
The 2024 Notes bear interest at a rate of 0.25% per year. Interest on the 2024 Notes is payable semi-annually in arrears on March 15 and September 15 of each year, beginning on September 15, 2017. The 2024 Notes will mature on March 15, 2024, unless earlier repurchased by us or converted pursuant to their terms.

[0001628280-23-030374:notes:295]
The initial conversion rate of the 2024 Notes is 16.4965 shares of common stock per $1,000 principal amount of 2024 Notes, which is equivalent to an initial conversion price of approximately $60.62 per share. The conversion rate is subject to adjustment upon the occurrence of certain specified events, but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change (as defined in the 2024 Indenture) or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert the 2024 Notes in connection with such make-whole fundamental change or notice of redemption.

[0001628280-23-030374:notes:296]
Prior to the close of business on the business day immediately preceding December 15, 2023, each holder of the 2024 Notes may convert their 2024 Notes only under the following circumstances:

[0001628280-23-030374:notes:297]
•during any fiscal quarter (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during the period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price, or $78.80 on each applicable trading day;

[0001628280-23-030374:notes:298]
•during the five consecutive business day period after any five consecutive trading day period (the “2024 measurement period”) in which the trading price per $1,000 principal amount of 2024 Notes for each trading day of such 2024 measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate on each such trading day;

[0001628280-23-030374:notes:299]
•upon the occurrence of specified corporate events as specified in the 2024 Indenture.

[0001628280-23-030374:notes:300]
On or after December 15, 2023 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their 2024 Notes at any time. In addition, upon the occurrence of a make-whole fundamental change (as defined in the 2024 Indenture), we will, in certain circumstances, increase the conversion rate by a number of additional shares set forth in the 2024 Indenture for a holder that elects to convert 2024 Notes in connection with such make-whole fundamental change.

[0001628280-23-030374:notes:301]
We may not redeem the 2024 Notes prior to their maturity date and no sinking fund is provided for the 2024 Notes. Upon the occurrence of a fundamental change, holders may require us to repurchase all or a portion of their 2024 Notes for cash at a price equal to 100% of the principal amount of the 2024 Notes to be repurchased, plus any accrued and unpaid interest.

[0001628280-23-030374:notes:302]
We considered the features embedded in the 2024 Notes other than the conversion feature, including the holders’ put feature, our call feature, and the make-whole feature, and concluded that they are not required to be bifurcated and accounted for separately from the host debt instrument.

[0001628280-23-030374:notes:303]
Prior to the Tax Matters Agreement settlement condition (“TMA settlement condition”), because we could only settle the 2024 Notes in cash, we determined that the conversion feature met the definition of a derivative liability. We separated the derivative liability from the host debt instrument based on the fair value of the derivative liability. As of the issuance date, March 8, 2017, the derivative liability fair value of $129.9 million was calculated using the binomial valuation approach. The residual principal amount of the 2024 Notes of $320.1 million before issuance costs was allocated to the debt component. We incurred approximately $7.7 million in transaction costs in connection with the issuance of the 2024 Notes. These costs were allocated to the debt component and recognized as a debt discount. We amortize the debt discount, including both the initial value of the derivative liability and the transaction costs, over the term of the 2024 Notes using the effective interest method. The effective interest rate of the 2024 Notes is 5.4% per year.

[0001628280-23-030374:notes:304]
During fiscal 2017, we satisfied the TMA settlement condition. As such, the value of the conversion option is no longer marked-to-market and was reclassified to additional paid-in capital within stockholders’ equity on our consolidated balance sheet. The value of the conversion option at the time of issuance is treated as an original issue discount for purposes of accounting for the debt component of the 2024 Notes. The debt component will accrete up to the principal amount over the expected term of the debt. The adoption of ASU 2020-06 did not change the presentation of the 2024 Notes, as the conversion feature associated with the 2024 Notes continues to be classified within stockholders’ equity.

[0001628280-23-030374:notes:305]
Concurrent with the issuance of the 2029 Notes, we used $132.8 million of the net proceeds to repurchase $125.0 million aggregate principal amount of the 2024 Notes, which we accounted for as an extinguishment of liability. $13.5 million of the $132.8 million repurchase price was allocated to the conversion feature of the repurchased 2024 Notes, representing the fair value of the conversion feature at the date of the repurchase, and was recognized as a reduction of the stockholders’ equity. Refer to consolidated statements of stockholders’ equity. We recognized an extinguishment gain of $1.0 million related to the repurchase, which was recorded under other income, net on our consolidated statements of operations for the year ended July 1, 2023. The remaining principal amount of the 2024 Notes as of July 1, 2023 was $323.1 million.

[0001628280-23-030374:notes:306]
During the year ended July 1, 2023, we received conversion requests of less than $0.1 million principal amount of the 2024 Notes, which we settled with cash in accordance with the 2024 Indenture. During the year ended July 2, 2022, we received conversion requests of $1.8 million principal amount of the 2024 Notes, which we settled with a combination of $1.8 million of cash and approximately 9 thousand shares of common stock in accordance with the 2024 Indenture. Since issuing the 2024 Notes, we have converted a total of approximately $1.9 million principal amount of the 2024 Notes.

[0001628280-23-030374:notes:307]
Convertible Notes - Additional Disclosures

[0001628280-23-030374:notes:308]
Our convertible notes consisted of the following components as of the periods presented (in millions):

[0001628280-23-030374:notes:309]
| July 1, 2023 | 2024 Notes (1) |  | 2026 Notes (2) |  | 2028 Notes (3) |  | 2029 Notes (4) |  | Total |
| Principal | $ | 323.1 |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |  | $ | 603.7 |  |  | $ | 2,837.8 |  |
| Unamortized debt discount and debt issuance costs | (11.5) |  |  | (4.1) |  |  | (5.5) |  |  | (5.1) |  |  | (26.2) |  |
| Net carrying amount of the liability component | $ | 311.6 |  |  | $ | 1,045.9 |  |  | $ | 855.5 |  |  | $ | 598.6 |  |  | $ | 2,811.6 |  |

[0001628280-23-030374:notes:310]
| July 2, 2022 | 2024 Notes (1) |  | 2026 Notes (2) |  | 2028 Notes (3) |  | Total |
| Principal | $ | 448.1 |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |  | $ | 2,359.1 |  |
| Unamortized debt discount and debt issuance costs | (38.2) |  |  | (218.6) |  |  | (226.3) |  |  | (483.1) |  |
| Net carrying amount of the liability component | $ | 409.9 |  |  | $ | 831.4 |  |  | $ | 634.7 |  |  | $ | 1,876.0 |  |

[0001628280-23-030374:notes:311]
(1) If the closing price of our stock exceeded $78.80 (or 130% of the conversion price of $60.62) for 20 of the last 30 trading days of any future quarter, the 2024 Notes would become convertible at the option of the holders during the subsequent fiscal quarter. The 2024 Notes are classified as current liabilities as the debt will mature on March 15, 2024.

[0001628280-23-030374:notes:312]
(2) If the closing price of our stock exceeds $129.08 (or 130% of the conversion price of $99.29 for 20 of the last 30 trading days of any future quarter, the 2026 Notes would also become convertible at the option of the holders during the subsequent fiscal quarter and the debt would be reclassified to current liabilities in our consolidated balance sheets.

[0001628280-23-030374:notes:313]
(3) If the closing price of our stock exceeds $170.34 (or 130% of the conversion price of $131.03) for 20 of the last 30 trading days of any future quarter, the 2028 Notes would become convertible at the option of the holders during the subsequent fiscal quarter and the debt would be reclassified to current liabilities in our consolidated balance sheets.

[0001628280-23-030374:notes:314]
(4) If the closing price of our stock exceeds $90.40 (or 130% of the conversion price of $69.54) for 20 of the last 30 trading days of any future quarter, the 2029 Notes would become convertible at the option of the holders during the subsequent fiscal quarter and the debt would be reclassified to current liabilities in our consolidated balance sheets.

[0001628280-23-030374:notes:315]
The following table sets forth interest expense information related to our convertible notes for the periods presented (in millions):

[0001628280-23-030374:notes:316]
|  |  |  |  |  | July 1, 2023 |  | July 2, 2022 |  | July 3, 2021 |
| Contractual interest expense |  |  |  |  | $ | 11.2 |  |  | $ | 7.8 |  |  | $ | 6.5 |  |
| Amortization of the debt discount and debt issuance costs |  |  |  |  | 24.3 |  |  | 72.4 |  |  | 60.2 |  |
| Total interest expense |  |  |  |  | $ | 35.5 |  |  | $ | 80.2 |  |  | $ | 66.7 |  |

[0001628280-23-030374:notes:317]
The future interest and principal payments related to our convertible notes are as follows as of July 1, 2023 (in millions):

[0001628280-23-030374:notes:318]
| Fiscal Years | 2024 Notes |  | 2026 Notes |  | 2028 Notes |  | 2029 Notes |  | Total |
| 2024 | $ | 324.3 |  |  | $ | 5.3 |  |  | $ | 4.3 |  |  | $ | 9.1 |  |  | $ | 343.0 |  |
| 2025 | — |  |  | 5.3 |  |  | 4.3 |  | 9.1 |  |  | 18.7 |  |
| 2026 | — |  |  | 5.3 |  |  | 4.3 |  | 9.1 |  |  | 18.7 |  |
| 2027 | — |  |  | 1,052.5 |  |  | 4.3 |  | 9.1 |  |  | 1,065.9 |  |
| 2028 | — |  |  | — |  |  | 865.3 |  | 9.1 |  |  | 874.4 |  |
| Thereafter | — |  |  | — |  |  | — |  |  | 617.1 |  |  | 617.1 |  |
| Total payments | $ | 324.3 |  |  | $ | 1,068.4 |  |  | $ | 882.5 |  |  | $ | 662.6 |  |  | $ | 2,937.8 |  |

[0001628280-23-030374:notes:319]
The principal balances of our convertible notes are reflected in the payment periods in the table above based on their respective contractual maturities.

[0001628280-23-030374:notes:320]
Mitsubishi Bank Loans

[0001628280-23-030374:notes:321]
In connection with our merger of NeoPhotonics, we assumed several loan agreements with MUFG Bank, Ltd. (the “Mitsubishi Bank Loans”) for an aggregate fair value of approximately $5.9 million, approximately $0.9 million of which was paid in the fiscal first quarter of 2023 and the remaining balance was fully paid in the fiscal second quarter of 2023. We recorded $0.1 million of interest expense related to the Mitsubishi Bank Loans for the year ended July 1, 2023.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001628280-23-030374:notes:322]
Note 11. Accumulated Other Comprehensive Income

[0001628280-23-030374:notes:323]
Our accumulated other comprehensive income (loss) consists of the accumulated net unrealized gains or losses on foreign currency translation adjustments, defined benefit obligations, and available-for-sale securities.

[0001628280-23-030374:notes:324]
The changes in accumulated other comprehensive income (loss), net of tax, were as follows for the periods as presented (in millions):

[0001628280-23-030374:notes:325]
|  | Foreign currency translation adjustments, net of tax (1) |  | Defined benefit obligations, net of tax (2) |  | Unrealized gain (loss) on available-for-sale securities, net of tax (3) |  | Total |
| Ending balance as of June 27, 2020 | $ | 9.7 |  |  | $ | (4.2) |  |  | $ | 2.4 |  |  | $ | 7.9 |  |
| Other comprehensive income (loss) | — |  |  | 2.8 |  |  | (2.5) |  |  | 0.3 |  |
| Ending balance as of July 3, 2021 | 9.7 |  |  | (1.4) |  |  | (0.1) |  |  | 8.2 |  |
| Other comprehensive income (loss) | — |  |  | 2.4 |  |  | (10.2) |  |  | (7.8) |  |
| Ending balance as of July 2, 2022 | $ | 9.7 |  |  | $ | 1.0 |  |  | $ | (10.3) |  |  | $ | 0.4 |  |
| Other comprehensive income (loss) | 0.7 |  |  | (1.4) |  |  | 4.4 |  |  | 3.7 |  |
| Ending balance as of July 1, 2023 | $ | 10.4 |  |  | $ | (0.4) |  |  | $ | (5.9) |  |  | $ | 4.1 |  |

[0001628280-23-030374:notes:326]
(1) In fiscal 2019, as a result of significant changes in economic facts and circumstances, primarily due to the acquisition of Oclaro, we established the functional currency for our worldwide operations as the U.S. dollar. Translation adjustments reported prior to December 10, 2028 remain as a component of accumulated other comprehensive income in our consolidated balance sheets, until all or a part of the investment in the subsidiaries is sold or liquidated. In fiscal 2023, we acquired IPG telecom transmission product lines. The functional currency of the Brazilian entities acquired as part of this acquisition is the local currency. For the year ended July 1, 2023, we recorded $0.7 million of foreign currency translation adjustments.

[0001628280-23-030374:notes:327]
(2) We evaluate the assumptions over the fair value of our defined benefit obligations annually and make changes as necessary. During fiscal 2023, 2022 and 2021, our income (loss) on defined benefit obligations is presented net of tax of nil, $1.5 million, and nil, respectively.
(3) In fiscal 2023, 2022 and 2021, our unrealized gain (loss) on available-for-sale securities is presented net of tax of $0.8 million, $2.8 million and $(0.5) million, respectively.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001628280-23-030374:notes:328]
Note 12. Restructuring and Related Charges

[0001628280-23-030374:notes:329]
We have initiated various strategic restructuring actions primarily to reduce costs, consolidate our operations, rationalize the manufacturing of our products and align our business in response to market conditions and as a result of our acquisitions in the first quarter of fiscal 2023.

[0001628280-23-030374:notes:330]
The following table summarizes the activity of restructuring and related charges during the periods presented (in millions):

[0001628280-23-030374:notes:331]
|  | Years Ended |  |  |
|  | July 1, 2023 |  | July 2, 2022 |  |  |  | July 3, 2021 |  |  |
| Balance as of beginning of period | $ | — |  |  | $ | 5.7 |  |  |  |  | $ | 5.2 |  |  |  |
| Charges (reversals), net | 28.1 |  |  | (1.1) |  |  |  |  | 7.7 |  |  |  |
| Payments | (23.1) |  |  | (4.6) |  |  |  |  | (7.2) |  |  |  |
| Balance as of end of period | $ | 5.0 |  |  | $ | — |  |  |  |  | $ | 5.7 |  |  |  |

[0001628280-23-030374:notes:332]
During the year ended July 1, 2023, we recorded restructuring and related charges of $28.1 million in our consolidated statements of operations, which was primarily attributable to company-wide integration efforts as a result of the merger with NeoPhotonics, our cost reduction initiatives, as well as severance and employee-related benefits associated with NeoPhotonics’ executive severance and retention agreements. These agreements provide for payments and benefits upon an involuntary termination of employment under certain circumstances.

[0001628280-23-030374:notes:333]
During the year ended July 2, 2022, we recorded a net reversal to our restructuring and related charges of $1.1 million in our consolidated statements of operations, which was primarily attributable to lower than anticipated employee severance charges due to retaining and re-assigning certain employees.

[0001628280-23-030374:notes:334]
During the year ended July 3, 2021, we recorded restructuring and related charges of $7.7 million in our consolidated statements of operations. The charges were primarily attributable to severance charges associated with the decision to cease manufacturing of certain products in San Jose, California, as well as other cost reduction measures taken across the Company impacting all regions.

[0001628280-23-030374:notes:335]
Any changes in the estimates of executing our restructuring activities will be reflected in our future results of operations.


## us-gaap:AssetImpairmentChargesTextBlock

[0001628280-23-030374:notes:336]
Note 13. Retirement and Disposal of Assets

[0001628280-23-030374:notes:337]
We record fixed assets losses, primarily attributable to the retirement and disposal of fixed assets, net of proceeds received. The impact of such losses on our results of operations by function during the periods presented was as follows (in millions):

[0001628280-23-030374:notes:338]
|  | Years Ended |
|  | July 1, 2023 |  | July 2, 2022 |  |  |  |  | July 3, 2021 |
| Cost of sales | $ | 1.5 |  |  | $ | 2.5 |  |  |  |  |  | $ | 9.3 |  |
| Research and development | 0.5 |  |  | 0.4 |  |  |  |  |  | 0.3 |  |
| Selling, general and administrative | 6.6 |  |  | 0.1 |  |  |  |  |  | (7.2) |  |
|  | $ | 8.6 |  |  | $ | 3.0 |  |  |  |  |  | $ | 2.4 |  |

[0001628280-23-030374:notes:339]
In fiscal year 2023, as a result of company-wide integration efforts associated with the recent merger with NeoPhotonics, we made a decision to consolidate our manufacturing and operational sites. The $8.6 million of expense recorded during the year primarily relates to the retirement of assets that were no longer needed as part of this initiative.

[0001628280-23-030374:notes:340]
In fiscal year 2021, we made a decision to cease manufacturing of certain products at a manufacturing facility that we owned in San Jose, California. During the fourth quarter of fiscal 2021, we shut down the manufacturing site and sold the related land and building for $23.0 million and recognized a gain of $8.3 million, which was recorded as an offset to selling, general and administrative expenses in our consolidated statement of operations for the fiscal year ended July 3, 2021. As part of this transition, in fiscal 2022, we sold equipment that was no longer needed and recognized a gain of $5.9 million, which was recorded as an offset to cost of sales in our consolidated statement of operations for the fiscal year ended July 2, 2022.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-23-030374:notes:341]
Note 14. Income Taxes

[0001628280-23-030374:notes:342]
Our income before income taxes consisted of the following (in millions):

[0001628280-23-030374:notes:343]
|  | Years Ended |
|  | July 1, 2023 |  | July 2, 2022 |  | July 3, 2021 |
| Domestic | $ | (44.3) |  |  | $ | 77.5 |  |  | $ | 314.9 |  |
| Foreign | (58.1) |  |  | 157.6 |  |  | 148.2 |  |
| Income before income taxes | $ | (102.4) |  |  | $ | 235.1 |  |  | $ | 463.1 |  |

[0001628280-23-030374:notes:344]
Our income tax provision consisted of the following (in millions):

[0001628280-23-030374:notes:345]
|  | Years Ended |
|  | July 1, 2023 |  | July 2, 2022 |  | July 3, 2021 |
| Federal: |  |  |  |  |  |
| Current | $ | 12.9 |  |  | $ | 13.7 |  |  | $ | 30.5 |  |
| Deferred | (22.5) |  |  | 1.0 |  |  | 9.2 |  |
|  | (9.6) |  |  | 14.7 |  |  | 39.7 |  |
| State: |  |  |  |  |  |
| Current | 0.9 |  |  | (0.1) |  |  | 1.7 |  |
| Deferred | (0.5) |  |  | 0.3 |  |  | (0.3) |  |
|  | 0.4 |  |  | 0.2 |  |  | 1.4 |  |
| Foreign: |  |  |  |  |  |
| Current | 55.3 |  |  | 46.8 |  |  | 36.5 |  |
| Deferred | (16.9) |  |  | (25.5) |  |  | (11.8) |  |
|  | 38.4 |  |  | 21.3 |  |  | 24.7 |  |
| Total income tax provision | $ | 29.2 |  |  | $ | 36.2 |  |  | $ | 65.8 |  |

[0001628280-23-030374:notes:346]
The provision for income taxes differs from the amount computed by applying the U.S. Federal statutory income tax rate to our income before provision for income taxes as follows (in millions):

[0001628280-23-030374:notes:347]
|  | Years Ended |
|  | July 1, 2023 |  | July 2, 2022 |  | July 3, 2021 |
| Income tax provision computed at federal statutory rate | $ | (21.5) |  |  | $ | 49.4 |  |  | $ | 97.3 |  |
| Foreign rate differential | 33.6 |  |  | (50.4) |  |  | (50.4) |  |
| Change in valuation allowance | (4.8) |  |  | 10.5 |  |  | 45.4 |  |
| Tax credits | (46.5) |  |  | (23.1) |  |  | (31.8) |  |
| Stock-based compensation | 19.1 |  |  | 9.6 |  |  | 5.6 |  |
| Permanent items | 2.9 |  |  | 0.6 |  |  | 1.5 |  |
| Transaction costs | 2.4 |  |  | — |  |  | — |  |
| Subpart F and GILTI | 44.2 |  |  | 28.2 |  |  | 42.1 |  |
| Unrecognized tax benefits | 8.6 |  |  | 4.1 |  |  | (3.7) |  |
| Change in Non-US Statutory Tax Rates | — |  |  | (1.2) |  |  | (35.8) |  |
| BEAT | (8.0) |  |  | 8.0 |  |  | — |  |
| Other | (0.8) |  |  | 0.5 |  |  | (4.4) |  |
| Total income tax provision | $ | 29.2 |  |  | $ | 36.2 |  |  | $ | 65.8 |  |
| Effective tax rate | (28.52) | % |  | 15.40 | % |  | 14.22 | % |

[0001628280-23-030374:notes:348]
Our provision for income taxes for fiscal 2023 differs from the 21% U.S. statutory rate primarily due to the income tax expense from foreign income inclusions in the U.S., earnings of our foreign subsidiaries being taxed at rates that differ from the U.S. statutory rate and non-deductible stock-based compensation. Additionally, our provision for income taxes includes income tax benefits from various tax credits and change in valuation allowance as it is more-likely-than-not that certain deferred tax assets will be realizable in the future. During fiscal 2023, we also effectuated certain tax planning actions which reduced the amount of BEAT for fiscal 2022.

[0001628280-23-030374:notes:349]
Our provision for income taxes for fiscal 2022 differs from the 21% U.S. statutory rate primarily due to the income tax benefit from earnings of our foreign subsidiaries being taxed at rates that differ from the U.S. statutory rate, offset by the tax expense from foreign income inclusions in U.S. Additionally, our provision for income taxes includes income tax benefits from various tax credits offset by an income tax expense from non-deductible stock-based compensation as well as change in valuation allowance as it is not more-likely-than-not that certain deferred tax assets will be realizable in the future.

[0001628280-23-030374:notes:350]
Our provision for income taxes for fiscal 2021 differs from the 21% U.S. statutory rate primarily due to the income tax benefit from earnings of our foreign subsidiaries being taxed at rates that differ from the U.S. statutory rate, which is offset by the tax expense from foreign income inclusions in the U.S. Additionally, our provision for income taxes includes income tax benefit from various tax credits and non-U.S. statutory rate changes enacted during the year, offset by an income tax expense from non-deductible stock-based compensation as well as change in valuation allowance as it is not more-likely-than-not that certain deferred tax assets will be realizable in the future.

[0001628280-23-030374:notes:351]
The components of our net deferred taxes consisted of the following (in millions):

[0001628280-23-030374:notes:352]
|  | Years Ended |
|  | July 1, 2023 |  | July 2, 2022 |  |  |
| Gross deferred tax assets: |  |  |  |  |  |
| Intangibles | $ | 11.5 |  |  | $ | 81.2 |  |  |  |
| Tax credit carryforwards | 84.3 |  |  | 75.3 |  |  |  |
| Net operating loss carryforwards | 218.6 |  |  | 151.0 |  |  |  |
| Inventories | 7.9 |  |  | 6.3 |  |  |  |
| Accruals and reserves | 11.5 |  |  | 14.2 |  |  |  |
| Fixed assets | 18.4 |  |  | 25.5 |  |  |  |
| Capital loss carryforwards | 13.9 |  |  | 12.0 |  |  |  |
| Capitalized and unclaimed R&D expenditure | 67.2 |  |  | 40.5 |  |  |  |
| Stock-based compensation | 8.3 |  |  | 5.6 |  |  |  |
| Lease liabilities | 13.8 |  |  | 15.9 |  |  |  |
| Other | 2.6 |  |  | 4.7 |  |  |  |
| Gross deferred tax assets | 458.0 |  |  | 432.2 |  |  |  |
| Valuation allowance | (303.4) |  |  | (263.2) |  |  |  |
| Deferred tax assets | 154.6 |  |  | 169.0 |  |  |  |
| Gross deferred tax liabilities: |  |  |  |  |  |
| Intangible amortization | (21.1) |  |  | (33.7) |  |  |  |
| Convertible notes | (3.4) |  |  | (100.6) |  |  |  |
| Right-of-use assets | (16.1) |  |  | (18.2) |  |  |  |
| Other | (1.4) |  |  | (2.4) |  |  |  |
| Deferred tax liabilities | (42.0) |  |  | (154.9) |  |  |  |
| Total net deferred tax assets | $ | 112.6 |  |  | $ | 14.1 |  |  |  |

[0001628280-23-030374:notes:353]
We assess our ability to realize the deferred tax assets on a quarterly basis and establish a valuation allowance if the deferred tax assets are not more-likely-than-not to be realized. We weigh all available positive and negative evidence, including our earnings history and results of recent operations, reversals of deferred tax liabilities, projected future taxable income, and tax planning strategies. In fiscal 2023, after considering both positive and negative evidence, we have determined that we will be able to realize all of our deferred tax assets relating to foreign tax credits and have therefore reversed the related valuation allowance. We continue to maintain our valuation allowance on our U.S. federal capital loss carryforwards as well as  California, Canada, and UK deferred tax assets, and a partial valuation allowance on our Slovenia deferred tax asset. In the event the Company determines that it will be able to realize all or part of the deferred tax assets in the future, the valuation allowance will be reversed in the period in which the Company makes such determination. Based on the information currently available, we do not believe that a significant portion of our valuation allowance for the U.S., California, Canada, and UK will be released in the next 12 months. Such a release would result in the recognition of certain deferred tax assets and a decrease in the income tax expense for the period in which the release is recorded.

[0001628280-23-030374:notes:354]
As of July 1, 2023, the Company had federal and foreign net operating loss carryforwards of $339.2 million and $575.9 million, respectively. These carryforwards will begin to expire in the fiscal year ending 2025. The federal and foreign tax attributes carried forward are subject to various rules which impose limitations on the utilization.

[0001628280-23-030374:notes:355]
Additionally, the Company has federal, state, and foreign research and other tax credit carryforwards of $15.2 million, $105.7 million, and $36.7 million, respectively. The federal credits will begin to expire in the fiscal year ending 2025 and California credits can be carried forward indefinitely. The foreign tax credits will begin to expire in the fiscal year ending 2024.

[0001628280-23-030374:notes:356]
Current U.S. tax law generally provides greater flexibility for us to access and utilize our cash held by certain of our foreign subsidiaries and we intend to repatriate all or some of the earnings of our subsidiaries in the Cayman Islands, Japan, and Hong Kong. As to all other foreign subsidiaries, we intend to reinvest these earnings indefinitely in our foreign subsidiaries. As a result, U.S. income and foreign withholding taxes associated with the repatriation of $39.4 million of earnings from our foreign subsidiaries, other than the Cayman Islands, Japan, and Hong Kong subsidiaries, have not been provided for. We estimate that an additional $2.8 million of foreign withholding taxes would have to be provided if these earnings were repatriated back to the U.S. and such withholding taxes may be available as foreign tax credit or deduction to reduce U.S. tax liability.

[0001628280-23-030374:notes:357]
The aggregate changes in the balance of our unrecognized tax benefits between July 2, 2022 and July 1, 2023 are as follows (in millions):

[0001628280-23-030374:notes:358]
| Balance as of June 27, 2020 | $ | 55.5 |  |
| Increases based on tax positions related to prior year | 6.8 |  |
| Decreases based on tax positions related to prior year | (1.6) |  |
| Decreases related to Statute of Limitations | (5.1) |  |
| Additions based on tax positions related to current year | 6.5 |  |
| Balance as of July 3, 2021 | $ | 62.1 |  |
| Increases based on tax positions related to prior year | 5.2 |  |
| Decreases based on tax positions related to prior year | (2.1) |  |
| Decreases related to Statute of Limitations | (9.8) |  |
| Additions based on tax positions related to current year | 6.5 |  |
| Decreases related to audit settlements | (0.2) |  |
| Balance as of July 2, 2022 | $ | 61.7 |  |
| Increases based on tax positions related to prior year | 2.8 |  |
| Decreases based on tax positions related to prior year | (5.5) |  |
| Decreases related to Statute of Limitations | (0.1) |  |
| Additions based on tax positions related to current year | 7.7 |  |
| Increases due to acquisition | 47.3 |  |
| Balance as of July 1, 2023 | $ | 113.9 |  |

[0001628280-23-030374:notes:359]
As of July 1, 2023, we had $64.4 million of unrecognized tax benefits, which, if recognized, would affect the effective tax rate. We are subject to examination of income tax returns by various domestic and foreign tax authorities. The timing of resolutions and closures of tax audits is highly unpredictable. Although it is possible that certain tax audits may be concluded within the next 12 months, we cannot reasonably estimate the impact to tax expense and net income from tax exams that could be resolved or closed within next 12 months. However, we believe that we have adequately provided under GAAP for potential audit outcomes. Subject to audit timing and uncertainty, we expect the amount of unrecognized tax benefit that would become recognized due to expiration of the statute of limitations and affect the effective tax rate to be $13.3 million over the next 12 months.

[0001628280-23-030374:notes:360]
The Company has obtained a tax holiday related to certain business activities in Thailand but to date, has not met the requirements to obtain the benefits of the tax holiday. Accordingly, the earned income is subject to normal Thailand statutory tax rates.

[0001628280-23-030374:notes:361]
Our policy is to recognize accrued interest and penalties related to unrecognized tax benefits within the income tax provision. The amount of interest and penalties accrued as of July 1, 2023 and July 2, 2022 were $15.2 million and $1.6 million, respectively.

[0001628280-23-030374:notes:362]
The major tax jurisdictions where we file tax returns are the U.S. federal government, the state of California, Japan, the United Kingdom, Thailand, China and Canada. As of July 1, 2023, our fiscal 2011 to 2022 tax returns are open to potential examination in one or more jurisdictions. In addition, certain net operating loss and credit carryforwards may extend the ability of the tax authorities to examine our tax returns beyond the regular limits.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001628280-23-030374:notes:363]
Note 15. Equity

[0001628280-23-030374:notes:364]
Description of Lumentum Stock-Based Benefit Plans

[0001628280-23-030374:notes:365]
Equity Incentive Plan

[0001628280-23-030374:notes:366]
On November 16, 2022, our stockholders approved amendments to the Amended and Restated 2015 Equity Incentive Plan (the “2015 Plan”) to (i) increase the number of shares reserved for issuance by an additional 0.9 million shares and (ii) make certain other changes to reflect good corporate governance practices.

[0001628280-23-030374:notes:367]
As of July 1, 2023, we had 3.2 million shares subject to restricted stock units, restricted stock awards and performance stock units issued and outstanding under the 2015 Plan. These grants are performance-based, time-based or a combination of both and are expected to vest within four years. The fair value of these grants is based on the closing market price of our common stock on the date of grant.

[0001628280-23-030374:notes:368]
As of July 1, 2023, 2.7 million shares of common stock under the 2015 Plan were available for grant.

[0001628280-23-030374:notes:369]
Replacement Awards

[0001628280-23-030374:notes:370]
In connection with the merger with NeoPhotonics, we issued equity awards to certain NeoPhotonics employees, consisting of restricted stock units (the “Replacement Awards”) in exchange for their NeoPhotonics equity awards. The terms of these Replacement Awards are substantially similar to the original NeoPhotonics equity awards. The Replacement Awards consisted of 0.4 million restricted stock units with a grant date fair value of $93.4 per share, which represents our closing stock price on the Closing date. The total fair value of these Replacement Awards is $40.2 million, $3.5 million of which is attributable to employee services rendered through August 3, 2022, the merger Closing date, and was recognized as a component of the merger consideration and stock-based compensation in the consolidated statements of stockholders’ equity. The remaining fair value of the Replacement Awards is recorded as stock-based compensation over the remaining vesting period. Refer to “Note 4. Business Combination.”

[0001628280-23-030374:notes:371]
Restricted Stock Units

[0001628280-23-030374:notes:372]
Restricted stock units (“RSUs”) under the 2015 Plan are grants of shares of our common stock, the vesting of which is based on the requisite service requirement. Generally, our RSUs are subject to forfeiture and are expected to vest within four years. For annual refresh grants, RSUs generally vest ratably on an annual, or combination of annual and quarterly, basis over three years.

[0001628280-23-030374:notes:373]
During fiscal 2023, our board of directors approved grants of 1.8 million shares which primarily vest over three years.  In addition, we issued 0.4 million RSUs as part of the Replacement Awards in connection with the merger with NeoPhotonics as described above.

[0001628280-23-030374:notes:374]
Performance Stock Units

[0001628280-23-030374:notes:375]
Performance stock units (“PSUs”) under the 2015 Plan are grants of shares of our common stock that vest upon the achievement of certain performance and service conditions. We begin recognizing compensation expense when we conclude that it is probable that the performance conditions will be achieved. We reassess the probability of vesting at each reporting period and adjust our compensation cost based on this probability assessment. Our PSUs are subject to risk of forfeiture until performance and service conditions are satisfied and generally vest within three years.

[0001628280-23-030374:notes:376]
During fiscal 2023, our board of directors approved a grant of 0.3 million PSUs with an aggregate grant date fair value of $26.0 million to executive and non-executive employees as part of our revised Annual Incentive Plan. These PSUs are subject to performance targets and service conditions, with a vesting period of one year. The board of directors also approved a grant of 0.3 million PSUs with an aggregate grant date fair value of $23.0 million to certain executive officers and senior management. These PSUs will vest subject to the achievement of revenue targets and certain non-financial performance measurements, as well as service conditions, over three years.

[0001628280-23-030374:notes:377]
Employee Stock Purchase Plan

[0001628280-23-030374:notes:378]
The 2015 Purchase Plan provides eligible employees with the opportunity to acquire an ownership interest in the Company through periodic payroll deductions and provides a 15% purchase price discount as well as a 6-month look-back period. The 2015 Purchase Plan is structured as a qualified employee stock purchase plan under Section 423 of the Internal Revenue Code of 1986, as amended. The 2015 Purchase Plan will terminate upon the date on which all shares available for issuance have been sold. Of the 3.0 million shares authorized under the 2015 Purchase Plan, 1.1 million shares remained available for issuance as of July 1, 2023.

[0001628280-23-030374:notes:379]
Stock-Based Compensation

[0001628280-23-030374:notes:380]
The impact on our results of operations of recording stock-based compensation by function during the periods presented was as follows (in millions):

[0001628280-23-030374:notes:381]
|  | Years Ended |
|  | July 1, 2023 |  | July 2, 2022 |  |  |  |  | July 3, 2021 |
| Cost of sales | $ | 30.1 |  |  | $ | 20.8 |  |  |  |  |  | $ | 19.2 |  |
| Research and development | 41.4 |  |  | 22.1 |  |  |  |  |  | 19.5 |  |
| Selling, general and administrative | 76.9 |  |  | 60.2 |  |  |  |  |  | 54.2 |  |
| Total stock-based compensation | $ | 148.4 |  |  | $ | 103.1 |  |  |  |  |  | $ | 92.9 |  |

[0001628280-23-030374:notes:382]
In connection with the NeoPhotonics merger, we issued replacement equity awards (the “Replacement Awards”) in settlement of certain NeoPhotonics equity awards at the merger Closing date, with the total fair value of $40.2 million based on our closing stock price on the Closing date. The portion of Replacement Awards attributed to pre-merger service is $3.5 million, which was accounted for as part of the consideration transferred and was recorded under stock-based compensation in our consolidated statements of stockholders’ equity as of July 1, 2023. Additionally, certain equity awards for NeoPhotonics employees were accelerated. The total stock-based compensation associated with the acceleration was $11.9 million, of which $9.0 million was settled in cash. We recorded the $11.9 million for the accelerated awards in our consolidated statements of operations during the first quarter of fiscal year 2023.  Refer to “Note 4. Business Combination.”

[0001628280-23-030374:notes:383]
Stock-based compensation for fiscal 2023, 2022 and 2021 includes $16.0 million, $16.8 million and $16.8 million, respectively, of stock-based compensation costs related to PSUs. The amount of stock-based compensation expense recognized in any one period related to PSUs can vary based on the achievement or anticipated achievement of the performance conditions. If the performance conditions are not met or not expected to be met, no compensation cost would be recognized on the underlying PSUs, and any previously recognized compensation expense related to those PSUs would be reversed.

[0001628280-23-030374:notes:384]
Total income tax benefit associated with stock-based compensation recognized in our consolidated statements of operations during the years presented was as follows (in millions):

[0001628280-23-030374:notes:385]
|  | Years Ended |
|  | July 1, 2023 |  | July 2, 2022 |  |  |  |  | July 3, 2021 |
| Income tax benefit associated with stock-based compensation | $ | 10.4 |  |  | $ | 12.5 |  |  |  |  |  | $ | 14.6 |  |

[0001628280-23-030374:notes:386]
Approximately $14.2 million and $6.4 million of stock-based compensation was capitalized to inventory as of July 1, 2023 and July 2, 2022, respectively.

[0001628280-23-030374:notes:387]
As of July 1, 2023, $160.1 million of stock-based compensation cost related to RSU awards granted to our employees remains to be amortized. This cost is expected to be recognized over an estimated amortization period of 1.8 years.

[0001628280-23-030374:notes:388]
Stock Award Activity

[0001628280-23-030374:notes:389]
The following table summarizes our awards activity in fiscal 2023, 2022 and 2021 (in millions, except per share amounts):

[0001628280-23-030374:notes:390]
|  |  |  |  |  |  |  | Restricted Stock Units |  |  |  | Performance Stock Units |
|  |  |  |  |  |  |  |  |  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |  |  |  |  |  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |
| Balance as of June 27, 2020 |  |  |  |  |  |  |  |  | 1.9 |  |  | $ | 56.6 |  |  |  |  |  |  | 0.3 |  |  | $ | 60.6 |  |
| Granted |  |  |  |  |  |  |  |  | 1.2 |  |  | 86.6 |  |  |  |  |  |  | 0.2 |  |  | 86.7 |  |
| Vested/Exercised |  |  |  |  |  |  |  |  | (1.1) |  |  | 56.5 |  |  |  |  |  |  | (0.2) |  |  | 57.8 |  |
| Canceled |  |  |  |  |  |  |  |  | (0.2) |  |  | 67.1 |  |  |  |  |  |  | — |  |  | 70.0 |  |
| Balance as of July 3, 2021 |  |  |  |  |  |  |  |  | 1.8 |  |  | $ | 76.0 |  |  |  |  |  |  | 0.3 |  |  | $ | 75.7 |  |
| Granted |  |  |  |  |  |  |  |  | 1.5 |  |  | 87.8 |  |  |  |  |  |  | 0.2 |  |  | 85.7 |  |
| Vested/Exercised |  |  |  |  |  |  |  |  | (1.1) |  |  | 73.4 |  |  |  |  |  |  | (0.2) |  |  | 76.1 |  |
| Canceled |  |  |  |  |  |  |  |  | (0.2) |  |  | 79.9 |  |  |  |  |  |  | — |  |  | 58.7 |  |
| Balance as of July 2, 2022 |  |  |  |  |  |  |  |  | 2.0 |  |  | $ | 85.9 |  |  |  |  |  |  | 0.3 |  |  | $ | 81.9 |  |
| Replacement Awards Issued |  |  |  |  |  |  |  |  | 0.4 |  |  | 93.4 |  |  |  |  |  |  | — |  |  | n/a |
| Granted |  |  |  |  |  |  |  |  | 1.8 |  |  | 85.1 |  |  |  |  |  |  | 0.6 |  |  | 87.9 |  |
| Vested/Exercised |  |  |  |  |  |  |  |  | (1.3) |  |  | 85.8 |  |  |  |  |  |  | (0.2) |  |  | 73.2 |  |
| Canceled |  |  |  |  |  |  |  |  | (0.3) |  |  | 87.7 |  |  |  |  |  |  | (0.1) |  |  | 89.2 |  |
| Balance as of July 1, 2023 |  |  |  |  |  |  |  |  | 2.6 |  |  | $ | 85.0 |  |  |  |  |  |  | 0.6 |  |  | $ | 89.1 |  |

[0001628280-23-030374:notes:391]
A summary of awards available for grant for fiscal 2023, 2022 and 2021  is as follows (in millions):

[0001628280-23-030374:notes:392]
|  | Awards Available for Grant |
| Balance as of June 27, 2020 | 3.5 |  |
| Granted | (1.4) |  |
| Canceled | 0.2 |  |
| Balance as of July 3, 2021 | 2.3 |  |
| Authorized | 3.0 |  |
| Granted | (1.7) |  |
| Canceled | 0.2 |  |
| Balance as of July 2, 2022 | 3.8 |  |
| Assumed in connection with NeoPhotonics merger | 0.4 |  |
| Replacement Awards | (0.4) |  |
| Authorized | 0.9 |  |
| Granted | (2.4) |  |
| Canceled | 0.4 |  |
| Balance as of July 1, 2023 | 2.7 |  |

[0001628280-23-030374:notes:393]
Employee Stock Purchase Plan Activity

[0001628280-23-030374:notes:394]
The 2015 Purchase Plan expense for fiscal 2023, 2022 and 2021 was $5.0 million, $4.6 million, and $4.6 million, respectively. The expense related to the 2015 Purchase Plan is recorded on a straight-line basis over the relevant subscription period. There were 0.3 million, 0.2 million, and 0.2 million shares issued to employees through the 2015 Purchase Plan during fiscal 2023, 2022 and 2021, respectively.

[0001628280-23-030374:notes:395]
We estimate the fair value of the 2015 Purchase Plan shares on the date of grant using the Black-Scholes option-pricing model. The assumptions used to estimate the fair value of the 2015 Purchase Plan shares during the periods presented were as follows:

[0001628280-23-030374:notes:396]
|  | July 1, 2023 |  | July 2, 2022 |
| Expected term (years) | 0.5 |  | 0.5 |
| Expected volatility | 39.7 | % |  | 45.4 | % |
| Risk-free interest rate | 4.85 | % |  | 1.49 | % |
| Dividend yield | — | % |  | — | % |

[0001628280-23-030374:notes:397]
Repurchase and Retirement of Common Stock

[0001628280-23-030374:notes:398]
Repurchase Made in Connection with Convertible Note Offering

[0001628280-23-030374:notes:399]
In fiscal 2023, concurrent with the issuance of the 2029 Notes, we repurchased 2.3 million shares of our common stock in privately negotiated transactions at an average price of $53.49 per share for an aggregate purchase price of $125.0 million. We recorded the aggregate purchase price as a reduction of retained earnings within our consolidated balance sheet.  These shares were retired immediately.

[0001628280-23-030374:notes:400]
In fiscal 2022, concurrent with the issuance of the 2028 Notes, we repurchased 2.0 million shares of our common stock in privately negotiated transactions at an average price of $99.0 per share for an aggregate purchase price of approximately $200.0 million. We recorded the  aggregate purchase price as a reduction of retained earnings within our consolidated balance sheet and retired these shares immediately.

[0001628280-23-030374:notes:401]
Share Buyback Program

[0001628280-23-030374:notes:402]
On May 7, 2021, our board of directors approved the 2021 share buyback program, which authorizes us to use up to $700.0 million to purchase our own shares of common stock.  On March 3, 2022, our board of directors approved an increase in our share buyback program, which authorizes us to use up to an aggregate amount of $1.0 billion (an increase from $700.0 million) to purchase our own shares of common stock through May 2024. On April 5, 2023, our board of directors approved a further increase in our share buyback program to authorize us to use up to an aggregate amount of $1.2 billion (an increase from $1.0 billion) to purchase our own shares of common stock through May 2025.

[0001628280-23-030374:notes:403]
During fiscal 2023, we repurchased 0.7 million shares of our common stock as part of the share buyback program at an average price of $65.03 per share for an aggregate purchase price of $40.5 million. During fiscal 2022, we repurchased 4.0 million shares of our common stock as part of the share buyback program at an average price of $87.21 per share for an aggregate purchase price of $348.9 million. Since the appoval of the share buyback program by the board of directors, we have repurchased 7.7 million shares in aggregate at an average price of $81.66 per share for a total purchase price of $630.4 million. We recorded the $630.4 million aggregate purchase price as a reduction of retained earnings within our consolidated balance sheets. All repurchased shares were retired immediately. As of July 1, 2023, we have $569.6 million remaining under the share buyback program.

[0001628280-23-030374:notes:404]
The price, timing, amount, and method of future repurchases will be determined based on the evaluation of market conditions and other factors, at prices determined to be in the best interests of the Company and our stockholders. The stock buyback program may be suspended or terminated at any time.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001628280-23-030374:notes:405]
Note 16. Employee Retirement Plans

[0001628280-23-030374:notes:406]
Defined Contribution Plans

[0001628280-23-030374:notes:407]
In the United States, the Company sponsors the Lumentum 401(k) Retirement Plan (the “401(k) Plan”), a defined contribution plan under the Employee Retirement Income Security Act of 1974 (“ERISA”), which provides retirement benefits for its eligible employees through tax deferred salary deductions. The 401(k) Plan allows employees to contribute up to 50% of their annual compensation, with contributions limited to $22,500 (or $30,000 for employees over 50 years of age) in calendar year 2023 as set by the Internal Revenue Service. Employees are eligible for matching contributions after completing 180 days of service. The Company’s match is contributed on a per-pay-period basis and is based on employees’ before-tax contributions and compensation each pay period. All matching contributions are made in cash and vest immediately under the 401(k) Plan. In fiscal 2023, 2022 and 2021, our contribution expense to the 401(k) Plan was $3.8 million, $3.7 million, and $3.5 million, respectively.

[0001628280-23-030374:notes:408]
We also have defined contribution plans in most of the other countries in which we operate, either as required by statutory law or as provided by the Company’s supplemental offering. Our contribution expense to all defined contribution plans outside the United States were $8.1 million, $7.7 million, and $8.3 million for fiscal 2023, 2022 and 2021, respectively.

[0001628280-23-030374:notes:409]
Defined Benefit Plans

[0001628280-23-030374:notes:410]
The Company sponsors defined benefit pension plans covering employees in Japan, Switzerland and Thailand. Pension plan benefits are based primarily on participants’ compensation and years of service credited as specified under the terms of each country’s plan. Employees are entitled to a lump sum benefit upon retirement or upon certain instances of termination.  The funding policy is consistent with the local requirements of each country.

[0001628280-23-030374:notes:411]
We account for our defined benefit obligations in accordance with the authoritative guidance which requires us to record our obligation to the participants, as well as the corresponding net periodic cost. We determine our obligation to the participants and our net periodic cost using actuarial valuations provided by third-party actuaries. As of July 1, 2023, our projected benefit obligations, net, in Japan, Switzerland and Thailand were $4.2 million, $3.3 million and $3.9 million, respectively. They were recorded in our consolidated balance sheets as accrued payroll and related expenses for the short-term portion while other non-current liabilities for the long-term portion, and represent the total projected benefit obligation (“PBO”) less the fair value of plan assets.

[0001628280-23-030374:notes:412]
As of July 1, 2023, the defined benefit plans in Switzerland were partially funded, while the defined benefit plans in Japan and Thailand were unfunded.

[0001628280-23-030374:notes:413]
The change in the benefit obligations of pension plans in Japan, Switzerland, and Thailand, and the change in plan assets in Switzerland were as follows (in millions):

[0001628280-23-030374:notes:414]
|  | July 1, 2023 |  | July 2, 2022 |
| Change in projected benefit obligation: |  |  |  |
| Benefit obligation at beginning of year | $ | 17.5 |  |  | $ | 20.6 |  |
| Assumed pension liability in Japan in connection with NeoPhotonics acquisition | 2.2 |  |  | — |  |
| Service cost | 1.7 |  |  | 1.8 |  |
| Interest cost | 0.3 |  |  | 0.1 |  |
| Plan participants’ contributions | 0.8 |  |  | 0.5 |  |
| Actuarial losses (gains) (1) | 0.6 |  |  | (3.9) |  |
| Net benefits payment | 1.0 |  |  | (0.2) |  |
| Plan amendments | (0.1) |  |  | (0.2) |  |
| Foreign exchange impact | 0.8 |  |  | (1.2) |  |
| Benefit obligation at end of year | $ | 24.8 |  |  | $ | 17.5 |  |
| Change in plan assets: |  |  |  |
| Fair value of plan assets at beginning of year | $ | 9.8 |  |  | $ | 9.8 |  |
| Actual return on plan assets | (0.5) |  |  | (0.2) |  |
| Employer contribution | 1.5 |  |  | 0.6 |  |
| Plan participants’ contribution | 0.8 |  |  | 0.5 |  |
| Net benefits payment | 1.0 |  |  | (0.2) |  |
| Foreign exchange impact | 0.8 |  |  | (0.7) |  |
| Fair value of plan assets at end of year | $ | 13.4 |  |  | $ | 9.8 |  |
| Funded status (2) | $ | (11.4) |  |  | $ | (7.7) |  |
| Changes in benefit obligations and plan assets recognized in other comprehensive income: |  |  |  |
| Prior service cost | $ | — |  |  | $ | (0.1) |  |
| Amortization of accumulated net actuarial loss | — |  |  | (0.1) |  |
| Net actuarial loss (gain) | 1.4 |  |  | (3.6) |  |
|  | $ | 1.4 |  |  | $ | (3.8) |  |
| Accumulated benefit obligation | $ | 20.0 |  |  | $ | 14.0 |  |

[0001628280-23-030374:notes:415]
(1) Actuarial losses (gains) are primarily driven by changes in discount rates.

[0001628280-23-030374:notes:416]
(2) As of July 1, 2023, the current portion of the projected benefit obligation is $1.2 million, which was recorded under accrued payroll and related expenses in the consolidated balance sheets, and the non-current portion of the projected benefit obligation is $10.2 million, which was recorded under other non-current liabilities in the consolidated balance sheets. As of July 2, 2022, benefit obligation of $7.7 million was recorded other non-current liabilities in our consolidated balance sheets. Refer to “Note 7. Balance Sheet Details”.

[0001628280-23-030374:notes:417]
Net periodic pension costs in Japan, Switzerland and Thailand include the following components for the periods presented (in millions):

[0001628280-23-030374:notes:418]
|  | Years Ended |  |  |  |
|  | July 1, 2023 |  | July 2, 2022 |  | July 3, 2021 |  |  |  |
| Service cost | $ | 1.7 |  |  | $ | 1.8 |  |  | $ | 2.0 |  |  |  |  |
| Interest cost | 0.3 |  |  | 0.1 |  |  | 0.1 |  |  |  |  |
| Amortization of prior service cost | (0.1) |  |  | (0.1) |  |  | (0.1) |  |  |  |  |
| Expected return on plan assets | (0.3) |  |  | (0.2) |  |  | (0.3) |  |  |  |  |
| Amortization of net loss | — |  |  | 0.2 |  |  | 0.3 |  |  |  |  |
| Settlement losses | — |  |  | — |  |  | 0.3 |  |  |  |  |
| Net periodic pension cost | $ | 1.6 |  |  | $ | 1.8 |  |  | $ | 2.3 |  |  |  |  |

[0001628280-23-030374:notes:419]
Assumptions

[0001628280-23-030374:notes:420]
Underlying both the calculation of the projected benefit obligation and net periodic cost are actuarial valuations. These valuations use participant-specific information such as salary, age and assumptions about interest rates, compensation increases and other factors. At a minimum, we evaluate these assumptions annually and make changes as necessary.

[0001628280-23-030374:notes:421]
The discount rate reflects the estimated rate at which the pension benefits could be effectively settled. In developing the discount rate, we consider the yield available on an appropriate AA or AAA corporate bond index, adjusted to reflect the term of the plan’s liabilities.

[0001628280-23-030374:notes:422]
The expected return on assets was estimated by using the weighted average of the real expected long-term return (net of inflation) on the relevant classes of assets based on the target asset mix and adding the chosen inflation assumption.

[0001628280-23-030374:notes:423]
The following table summarizes the weighted-average assumptions used to determine net periodic cost and benefit obligation for our defined benefit plans in Japan, Switzerland and Thailand:

[0001628280-23-030374:notes:424]
|  | Years Ended |
|  | July 1, 2023 |  | July 2, 2022 |
| Assumptions used to determine net periodic cost: |  |  |  |
| Discount rate | 2.3 | % |  | 1.1 | % |
| Expected long-term return on plan assets | 2.5 | % |  | 2.0 | % |
| Salary increase rate | 4.1 | % |  | 3.7 | % |
| Assumptions used to determine benefit obligation at end of year: |  |  |  |
| Discount rate | 1.8 | % |  | 1.9 | % |
| Salary increase rate | 3.0 | % |  | 3.1 | % |

[0001628280-23-030374:notes:425]
Fair Value Measurement of Plan Assets

[0001628280-23-030374:notes:426]
The following table sets forth the plan assets of our defined benefit plan in Switzerland at fair value and the percentage of assets allocations as of July 1, 2023 and July 2, 2022 (in millions, except percentage data):

[0001628280-23-030374:notes:427]
|  |  |  |  |  |  | Fair value measurement as of July 1, 2023 |
|  | Target allocation | Total |  | Percentage of plan asset |  | Quoted prices in active markets for identical assets(Level 1) |  | Significant other observable inputs (Level 2) |
| Assets: |  |  |  |  |  |  |  |  |  |
| Global equity | 33 | % |  | $ | 4.4 |  |  | 32 | % |  | $ | — |  |  | $ | 4.4 |  |
| Fixed income | 32 | % |  | 4.0 |  |  | 30 | % |  | — |  |  | 4.0 |  |
| Alternative investment | 12 | % |  | 1.7 |  |  | 13 | % |  | — |  |  | 1.7 |  |
| Cash | 1 | % |  | 0.1 |  |  | 1 | % |  | 0.1 |  |  | — |  |
| Other assets | 22 | % |  | 3.2 |  |  | 24 | % |  | — |  |  | 3.2 |  |
| Total Assets | 100 | % |  | $ | 13.4 |  |  | 100 | % |  | $ | 0.1 |  |  | $ | 13.3 |  |

[0001628280-23-030374:notes:428]
|  |  |  |  |  |  | Fair value measurement as of July 2, 2022 |
|  | Target allocation |  | Total |  | Percentage of plan asset |  | Quoted prices in active markets for identical assets(Level 1) |  | Significant other observable inputs (Level 2) |
| Assets: |  |  |  |  |  |  |  |  |  |
| Global equity | 33 | % |  | $ | 3.2 |  |  | 33 | % |  | $ | — |  |  | $ | 3.2 |  |
| Fixed income | 32 | % |  | 3.1 |  |  | 30 | % |  | — |  |  | 3.1 |  |
| Alternative investment | 12 | % |  | 1.2 |  |  | 13 | % |  | — |  |  | 1.2 |  |
| Cash | 1 | % |  | 0.1 |  |  | 1 | % |  | 0.1 |  |  | — |  |
| Other assets | 22 | % |  | 2.2 |  |  | 23 | % |  | — |  |  | 2.2 |  |
| Total Assets | 100 | % |  | $ | 9.8 |  |  | 100 | % |  | $ | 0.1 |  |  | $ | 9.7 |  |

[0001628280-23-030374:notes:429]
Our pension assets consist of multiple institutional funds (“pension funds”) of which the fair values are based on the quoted prices of the underlying funds. Pension funds are classified as Level 2 assets since such funds are not directly traded in active markets. Global equity consists of several funds that invest primarily in Swiss and foreign equities; fixed income consists of several funds that invest primarily in investment grade domestic and overseas bonds; alternative investment consists of several funds that invest primarily in hedge funds, infrastructure funds and private equity and debt; and other assets consist of several funds that invest primarily in real estate funds.

[0001628280-23-030374:notes:430]
Future Benefit Payments

[0001628280-23-030374:notes:431]
We estimate our expected benefit payments to participants in the defined benefit pension plans based on the same assumptions used to measure our PBO at year-end which includes benefits attributable to estimated future compensation increases.

[0001628280-23-030374:notes:432]
The following benefit payments are estimated to be paid from our defined benefit pension plans (in millions):

[0001628280-23-030374:notes:433]
| Fiscal Years |  | Total |
| 2024 |  | $ | 2.2 |  |
| 2025 |  | 1.5 |  |
| 2026 |  | 1.3 |  |
| 2027 |  | 1.5 |  |
| 2028 |  | 2.0 |  |
| Next five years |  | 12.6 |  |
| Total expected benefit payments |  | $ | 21.1 |  |

[0001628280-23-030374:notes:434]
We expect to contribute $2.2 million to our defined benefit pension plans in fiscal 2024.


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0001628280-23-030374:notes:435]
Note 17. Commitments and Contingencies

[0001628280-23-030374:notes:436]
Purchase Obligations

[0001628280-23-030374:notes:437]
Purchase obligations of $348.9 million as of July 1, 2023 represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule and adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

[0001628280-23-030374:notes:438]
We depend on a limited number of contract manufacturers, subcontractors and suppliers for raw materials, packages and standard components. We generally purchase these single or limited source products through standard purchase orders or one-year supply agreements and have no significant long-term guaranteed supply agreements with these vendors. While we seek to maintain a sufficient safety stock of such products and maintain on-going communications with our suppliers to guard against interruptions or cessation of supply, our business and results of operations could be adversely affected by a stoppage or delay of supply, substitution of more expensive or less reliable products, receipt of defective parts or contaminated materials, increases in the price of such supplies, or our inability to obtain reduced pricing from our suppliers in response to competitive pressures.

[0001628280-23-030374:notes:439]
Product Warranties

[0001628280-23-030374:notes:440]
We provide reserves for the estimated costs of product warranties at the time revenue is recognized. We typically offer a twelve-month warranty for most of our products. However, in some instances depending upon the product, product components or application of our products by the end customer, our warranties can vary and generally range from six months to five years. We estimate the costs of our warranty obligations on an annualized basis based on our historical experience of known product failure rates, use of materials to repair or replace defective products, and service delivery costs incurred in correcting product failures. In addition, from time to time, specific warranty accruals may be made if unforeseen technical problems arise with specific products. We assess the adequacy of our recorded warranty liabilities and adjust the amounts as necessary.

[0001628280-23-030374:notes:441]
The following table presents the changes in our warranty reserve during the periods presented (in millions):

[0001628280-23-030374:notes:442]
|  | Years Ended |
|  | July 1, 2023 |  | July 2, 2022 |  |  |  |  |
| Balance as of beginning of period | $ | 10.0 |  |  | $ | 5.0 |  |  |  |  |  |
| Warranties assumed in NeoPhotonics merger | 0.7 |  |  | — |  |  |  |  |  |
| Provision for warranty | 7.1 |  |  | 9.4 |  |  |  |  |  |
| Utilization of reserve | (11.0) |  |  | (4.4) |  |  |  |  |  |
| Balance as of end of period | $ | 6.8 |  |  | $ | 10.0 |  |  |  |  |  |

[0001628280-23-030374:notes:443]
Environmental Liabilities

[0001628280-23-030374:notes:444]
Our research and development, manufacturing and distribution operations involve the use of hazardous substances and are regulated under international, federal, state and local laws governing health and safety and the environment. We apply strict standards for protection of the environment and occupational health and safety to sites inside and outside the United States, even if not subject to regulations imposed by foreign governments. We believe that our properties and operations at our facilities comply in all material respects with applicable environmental laws and occupational health and safety laws. However, the risk of environmental liabilities cannot be completely eliminated and there can be no assurance that the application of environmental and health and safety laws will not require us to incur significant expenditures. We are also regulated under a number of international, federal, state and local laws regarding recycling, product packaging and product content requirements. The environmental and product content/disposal and recycling laws are gradually becoming more stringent and may cause us to incur significant expenditures in the future.

[0001628280-23-030374:notes:445]
Legal Proceedings

[0001628280-23-030374:notes:446]
We are subject to a variety of claims and suits that arise from time to time in the ordinary course of our business. While management currently believes that resolving claims against us, individually or in the aggregate, will not have a material adverse impact on our financial position, results of operations or statements of cash flows, these matters are subject to inherent uncertainties and management’s view of these matters may change in the future. We accrue for loss contingencies when it is both probable that we will incur the loss and when we can reasonably estimate the amount of the loss or range of loss.  We have recorded $7.8 million with respect to the pending settlement of certain non-ordinary course litigation matters under accrued expenses in our consolidated balance sheet as of July 1, 2023 and under selling, general and administrative expenses in our consolidated statement of operations for the year ended July 1, 2023.

[0001628280-23-030374:notes:447]
Oclaro Merger Litigation

[0001628280-23-030374:notes:448]
In connection with our acquisition of Oclaro in 2018, seven lawsuits were filed by purported stockholders of Oclaro challenging the proposed merger (the “Merger”). All but one was voluntarily dismissed after the Oclaro Merger closed.  The remaining lawsuit, SaiSravan B. Karri v. Oclaro, Inc., et al., No. 3:18-cv-03435-JD (the “Karri Lawsuit”), was filed in the United States District Court for the Northern District of California and is styled as a class action.

[0001628280-23-030374:notes:449]
The Karri Lawsuit alleges, among other things, that Oclaro and its directors violated Section 14(a) of the Securities Exchange Act of 1934, as amended (the “Exchange Act”), and Rule 14a-9 promulgated thereunder by disseminating an incomplete and misleading Form S-4, including proxy statement/prospectus. The Karri Lawsuit further alleged that Oclaro’s directors violated Section 20(a) of the Exchange Act by failing to exercise proper control over the person(s) who violated Section 14(a) of the Exchange Act. The plaintiff in the Karri Lawsuit seeks, among other things, damages to be awarded to the plaintiff and any class, if a class is certified, and litigation costs, including attorneys’ fees.

[0001628280-23-030374:notes:450]
After the plaintiff in the Karri Lawsuit was appointed as lead plaintiff and his counsel as lead counsel, the plaintiff filed a first amended complaint on April 15, 2019.  The first amended complaint, also named Lumentum as a defendant but Lumentum has since been dismissed from the action.  On October 8, 2020, the court granted in part and denied in part the defendant’s motion to dismiss the first amended complaint. On December 1, 2020, defendants answered the first amended complaint. On September 17, 2021, lead plaintiff filed a second amended complaint. Defendants moved to stay discovery in light of the second amended complaint. On January 11, 2022, the Court struck the second amended complaint as untimely, terminated defendants’ motions to dismiss as moot, and lifted the stay. The case proceeded through fact and expert discovery.

[0001628280-23-030374:notes:451]
On August 16, 2022, the lead plaintiff moved for class certification and to be appointed class representative. Defendants opposed the motion. The action subsequently was stayed while the parties participated in a mediation. On January 18, 2023, the lead plaintiff filed a Notice of Settlement informing the court of an agreement in principle between the parties for a class-wide settlement of the Karri Lawsuit. On January 24, 2023, in light of the potential settlement, the court vacated all pretrial and trial dates and ordered the lead plaintiff to file a motion for preliminary approval of the settlement by March 17, 2023. The lead plaintiff filed his motion for preliminary approval of the settlement on March 16, 2023, and defendants filed a statement of non-opposition on March 30, 2023.  On April 20, 2023, the court held a hearing on lead plaintiff’s motion for preliminary approval of the settlement.  The court declined to grant lead plaintiff’s motion for preliminary approval and ordered lead plaintiff to file a revised motion by May 22, 2023. Lead plaintiff filed his Revised Motion for Preliminary Approval of Settlement (the “Amended Motion”) on May 22, 2023, defendants filed a response in support of the Amended Motion on June 5, 2023, and the lead plaintiff submitted his reply on June 12, 2023. The hearing on the Amended Motion took place on August 17, 2023 and the court preliminarily approved the settlement. In the event that the settlement does not go forward for any reason, the defendants intend to continue to defend the Karri Lawsuit vigorously.

[0001628280-23-030374:notes:452]
NeoPhotonics Merger Litigation

[0001628280-23-030374:notes:453]
In connection with our acquisition of NeoPhotonics Corporation (“NeoPhotonics”) announced in November 2021, ten lawsuits (the “NeoPhotonics Lawsuits”) were filed by purported stockholders of NeoPhotonics challenging the proposed merger (the “NeoPhotonics Merger”). All of the NeoPhotonics Lawsuits have been dismissed.

[0001628280-23-030374:notes:454]
Indemnifications

[0001628280-23-030374:notes:455]
In the normal course of business, we enter into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown, because claims may be made against us in the future and we may record charges in the future as a result of these indemnification obligations. As of July 1, 2023, we did not have any material indemnification claims that were probable or reasonably possible.

[0001628280-23-030374:notes:456]
Audit Proceedings

[0001628280-23-030374:notes:457]
We are under audit by various domestic and foreign tax authorities with regards to income tax and indirect tax matters. In some, although not all cases, we have reserved for potential adjustments to our provision for income taxes and accrual of indirect taxes that may result from examinations by these tax authorities or final outcomes in judicial proceedings, and we believe that the final outcome of these examinations, agreements or judicial proceedings will not have a material effect on our results of operations. If events occur which indicate payment of these amounts is unnecessary, the reversal of the liabilities would result in the recognition of benefits in the period when we determine the liabilities are no longer necessary. If our estimates of the federal, state, and foreign income tax liabilities and indirect tax liabilities are less than the ultimate assessment, it could result in a further charge to expense.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001628280-23-030374:notes:458]
Note 18. Operating Segments and Geographic Information

[0001628280-23-030374:notes:459]
Our chief executive officer is our CODM. The CODM allocates resources to the segments based on their business prospects, competitive factors, net revenue and gross margin. We do not track all of our property, plant and equipment by operating segments. The geographic identification of these assets is set forth below.

[0001628280-23-030374:notes:460]
We are an industry leading provider of optical and photonic products defined by revenue and market share addressing a range of end-market applications including optical communications and commercial lasers. We have two operating segments, Optical Communications, which we refer to as OpComms, and Commercial Lasers, which we refer to as Lasers. Our OpComms products address the following markets: telecommunications and data communications (“Telecom and Datacom”), and consumer and industrial (“Consumer and Industrial”). The two operating segments were primarily determined based on how the CODM views and evaluates our operations. The CODM regularly reviews operating results to make decisions about resources to be allocated to the segments and to assess their performance. Other factors, including market separation and customer specific applications, go-to-market channels, products and manufacturing, are considered in determining the formation of these operating segments.

[0001628280-23-030374:notes:461]
OpComms

[0001628280-23-030374:notes:462]
Our OpComms products include a wide range of components, modules and subsystems to support customers including carrier networks for access (local), metro (intracity), long-haul (city-to-city and worldwide) and submarine (undersea) applications. Additionally, our products address enterprise, cloud, and data center applications, including storage-access networks (“SANs”), local-area networks (“LANs”) and wide-area networks (“WANs”), as well as artificial intelligence and machine learning (“AI/ML”). These products enable the transmission and transport of video, audio and data over high-capacity fiber-optic cables. We maintain leading positions in these fast-growing OpComms markets through our extensive product portfolio, including reconfigurable optical add/drop multiplexers (“ROADMs”), coherent dense wavelength division multiplexing (“DWDM”) pluggable transceivers, and tunable small form-factor pluggable transceivers. We also sell laser chips for use in manufacturing of high-speed Datacom transceivers.

[0001628280-23-030374:notes:463]
In the Consumer and Industrial market, our OpComms diode laser products include VCSELs and edge emitting lasers. In the Consumer end-market, our laser light sources are integrated into 3D sensing cameras which are used in applications in mobile devices, gaming, payment kiosks, computers, and other consumer electronics devices. Applications include biometric identification, computational photography, virtual and augmented reality, and natural user interfaces. Emerging applications for our lasers include automotive safety systems, LiDAR for advanced driver assistance systems in automobiles and autonomous vehicles, self-navigating robotics and drones in industrial applications, and 3D capture of objects coupled with 3D imaging or printing. In the industrial end-market, our diode lasers are used primarily as pump sources for pulsed and kilowatt class fiber lasers.

[0001628280-23-030374:notes:464]
Lasers

[0001628280-23-030374:notes:465]
Our Lasers products serve our customers in markets and applications such as sheet metal processing, general manufacturing, solar cell processing, biotechnology, graphics and imaging, remote sensing, and precision machining such as drilling in printed circuit boards, wafer singulation, glass cutting and solar cell scribing.

[0001628280-23-030374:notes:466]
Our Lasers products are used in a variety of OEM applications including diode-pumped solid-state, fiber, diode, direct-diode and gas lasers such as argon-ion and helium-neon lasers. Fiber lasers provide kW-class output powers combined with excellent beam quality and are used in sheet metal processing and metal welding applications. Diode-pumped solid-state and fiber lasers that provide excellent beam quality, low noise and exceptional reliability are used in biotechnology, graphics and imaging, remote sensing, materials processing and precision machining applications. Diode and direct-diode lasers address a wide variety of applications, including laser pumping, thermal exposure, illumination, ophthalmology, image recording, printing, plastic welding and selective soldering. Gas lasers such as argon-ion and helium-neon lasers provide a stable, low-cost and reliable solution over a wide range of operating conditions, making them well-suited for complex, high-resolution OEM applications such as flow cytometry, DNA sequencing, graphics and imaging and semiconductor inspection.

[0001628280-23-030374:notes:467]
We also provide high-powered and ultrafast lasers for the industrial and scientific markets. Manufacturers use high-power, ultrafast lasers to create micro parts for consumer electronics and to process semiconductor, LED, solar cells, and other types of chips. Use of ultrafast lasers for micromachining applications is being driven primarily by the increasing use of renewable energy, consumer electronics and connected devices globally.

[0001628280-23-030374:notes:468]
Reportable Segments

[0001628280-23-030374:notes:469]
We do not allocate research and development, sales and marketing, or general and administrative expenses to our segments because management does not include the information in its measurement of the performance of the operating segments. In addition, we do not allocate amortization and impairment of acquisition-related intangible assets, stock-based compensation and certain other charges impacting the gross margin of each segment because management does not include this information in its measurement of the performance of the operating segments.

[0001628280-23-030374:notes:470]
Information on reportable segments utilized by our CODM is as follows (in millions):

[0001628280-23-030374:notes:471]
|  |  |  | Years Ended |
|  |  |  |  |  | July 1, 2023 |  | July 2, 2022 |  | July 3, 2021 |
| Net revenue: |  |  |  |  |  |  |  |  |  |
| OpComms |  |  |  |  | $ | 1,557.8 |  |  | $ | 1,518.5 |  |  | $ | 1,620.7 |  |
| Lasers |  |  |  |  | 209.2 |  |  | 194.1 |  |  | 122.1 |  |
| Net revenue |  |  |  |  | $ | 1,767.0 |  |  | $ | 1,712.6 |  |  | $ | 1,742.8 |  |
| Gross profit: |  |  |  |  |  |  |  |  |  |
| OpComms |  |  |  |  | $ | 665.5 |  |  | $ | 780.9 |  |  | $ | 830.2 |  |
| Lasers |  |  |  |  | 98.0 |  |  | 102.1 |  |  | 57.3 |  |
| Total segment gross profit |  |  |  |  | 763.5 |  |  | 883.0 |  |  | 887.5 |  |
| Unallocated corporate items: |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  |  |  | (30.1) |  |  | (20.8) |  |  | (19.2) |  |
| Amortization of acquired intangibles |  |  |  |  | (84.4) |  |  | (62.9) |  |  | (61.7) |  |
| Amortization of inventory fair value adjustments |  |  |  |  | (17.8) |  |  | — |  |  | — |  |
| Inventory and fixed asset write down due to product line exits |  |  |  |  | — |  |  | (0.1) |  |  | (0.4) |  |
| Integration related costs |  |  |  |  | (12.1) |  |  | — |  |  | — |  |
| Intangible asset write-off (1) |  |  |  |  | (6.8) |  |  | — |  |  | — |  |
| Other charges, net (2) |  |  |  |  | (43.3) |  |  | (10.6) |  |  | (23.1) |  |
| Gross profit |  |  |  |  | $ | 569.0 |  |  | $ | 788.6 |  |  | $ | 783.1 |  |

[0001628280-23-030374:notes:472]
(1)  During fiscal 2023, we recorded $6.8 million of write-off of developed technologies acquired from IPG, primarily due to product discontinuation as well as changes in customer demand.

[0001628280-23-030374:notes:473]
(2) Other charges of unallocated corporate items during fiscal 2023 primarily relate to $32.5 million of incremental costs of sales related to components previously acquired from various brokers to satisfy customer demand and $2.7 million of excess and obsolete inventory charges driven by U.S. trade restrictions and the related decline in customer demand.

[0001628280-23-030374:notes:474]
Other charges of unallocated corporate items during fiscal 2022 primarily relate to $14.0 million of incremental costs of sales related to components previously acquired from various brokers to satisfy customer demand, offset by a $5.9 million gain from selling equipment that was no longer needed after we transferred certain product lines to new production facilities in fiscal 2021.

[0001628280-23-030374:notes:475]
Other charges of unallocated corporate items during fiscal 2021 primarily relate to costs of transferring product lines to new production facilities, including Thailand, of $6.9 million, excess and obsolete inventory charges of $7.7 million driven by U.S. trade restrictions and the related decline in customer demand, and fixed asset write-off of $5.0 million associated with excess capacity related to our Fiber laser business.

[0001628280-23-030374:notes:476]
Concentrations

[0001628280-23-030374:notes:477]
We operate in three geographic regions: Americas, Asia-Pacific, and EMEA (Europe, Middle East, and Africa). Net revenue is assigned to the geographic region and country where our product is initially shipped to. For example, certain customers may request shipment of our product to a contract manufacturer in one country, which may differ from the location of their end customers. The following table presents net revenue by the three geographic regions we operate in and net revenue from countries that represented 10% or more of our total net revenue (in millions, except percentage data):

[0001628280-23-030374:notes:478]
|  |  |  | Years Ended |  |
|  |  |  |  |  | July 1, 2023 |  | July 2, 2022 |  | July 3, 2021 |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  |  |  |  |  |  |  |  | $ | 241.3 |  |  | 13.7 | % |  | $ | 173.9 |  |  | 10.2 | % |  | $ | 133.4 |  |  | 7.7 | % |  |
| Mexico |  |  |  |  |  |  |  |  | 180.0 |  |  | 10.2 | % |  | 160.9 |  |  | 9.4 |  |  | 134.8 |  |  | 7.7 |  |  |
| Other Americas |  |  |  |  |  |  |  |  | 9.3 |  |  | 0.5 |  |  | 12.1 |  |  | 0.7 |  |  | 12.1 |  |  | 0.7 |  |  |
| Total Americas |  |  |  |  |  |  |  |  | $ | 430.6 |  |  | 24.4 | % |  | $ | 346.9 |  |  | 20.3 | % |  | $ | 280.3 |  |  | 16.1 | % |  |
| Asia-Pacific: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Thailand |  |  |  |  |  |  |  |  | $ | 269.0 |  |  | 15.2 | % |  | $ | 102.3 |  |  | 5.9 | % |  | $ | 116.8 |  |  | 6.7 | % |  |
| Hong Kong |  |  |  |  |  |  |  |  | 246.7 |  |  | 14.0 |  |  | 458.2 |  |  | 26.7 |  |  | 546.3 |  |  | 31.3 |  |  |
| South Korea |  |  |  |  |  |  |  |  | 170.2 |  |  | 9.6 |  |  | 265.2 |  |  | 15.5 |  |  | 240.0 |  |  | 13.8 |  |  |
| Japan |  |  |  |  |  |  |  |  | 179.5 |  |  | 10.2 |  |  | 181.2 |  |  | 10.6 |  |  | 114.7 |  |  | 6.6 |  |  |
| Other Asia-Pacific |  |  |  |  |  |  |  |  | 276.3 |  |  | 15.6 |  |  | 242.4 |  |  | 14.2 |  |  | 304.5 |  |  | 17.5 |  |  |
| Total Asia-Pacific |  |  |  |  |  |  |  |  | $ | 1,141.7 |  |  | 64.6 | % |  | $ | 1,249.3 |  |  | 72.9 | % |  | $ | 1,322.3 |  |  | 75.9 | % |  |
| EMEA |  |  |  |  |  |  |  |  | $ | 194.7 |  |  | 11.0 | % |  | $ | 116.4 |  |  | 6.8 | % |  | $ | 140.2 |  |  | 8.0 | % |  |
| Total net revenue |  |  |  |  |  |  |  |  | $ | 1,767.0 |  |  |  |  | $ | 1,712.6 |  |  |  |  | $ | 1,742.8 |  |  |  |  |

[0001628280-23-030374:notes:479]
During the years ended July 1, 2023, July 2, 2022, and July 3, 2021, net revenue generated from a single customer which represented 10% or greater of total net revenue is summarized as follows:

[0001628280-23-030374:notes:480]
|  | Years Ended |
|  | July 1, 2023 |  | July 2, 2022 |  | July 3, 2021 |
| Customer A | 12.1 | % |  | 28.7 | % |  | 30.2 | % |
| Customer B | 15.3 | % |  | 12.6 | % |  | 10.1 | % |
| Customer C | * |  | * |  | 10.8 | % |
| Customer D | 10.5 | % |  | * |  | * |
| *Represents less than 10% of total net revenue. |  |  |  |  |  |

[0001628280-23-030374:notes:481]
Long-lived assets, namely property, plant and equipment, net, were identified based on the physical location of the assets in the corresponding geographic areas as of the periods indicated (in millions):

[0001628280-23-030374:notes:482]
|  | July 1, 2023 |  | July 2, 2022 |
| United States | $ | 134.7 |  |  | $ | 107.8 |  |
| Thailand | 132.0 |  |  | 107.6 |  |
| Japan | 93.0 |  |  | 38.9 |  |
| China | 42.1 |  |  | 32.7 |  |
| Other countries | 87.7 |  |  | 73.5 |  |
| Total long-lived assets | $ | 489.5 |  |  | $ | 360.5 |  |

[0001628280-23-030374:notes:483]
We purchase a portion of our inventory from contract manufacturers and vendors located primarily in Taiwan, Thailand, and Malaysia. During fiscal 2023, our net inventory purchases from a single contract manufacturer, which represented 10% or greater of total net purchases, were concentrated with one contract manufacturer, who accounted for 43% of total net inventory purchases. During fiscal 2022 and 2021, our net inventory purchases from a single contract manufacturer, which represented 10% or greater of total net purchases, were concentrated with  two contract manufacturers for both periods, who collectively accounted for 55%  and 40% of total net inventory purchases, respectively.


## us-gaap:SchedulesOfConcentrationOfRiskByRiskFactorTextBlock

[0001628280-23-030374:notes:484]
The table below discloses our total net revenue attributable to each of our two reportable segments. In addition, the table sets forth the percentage of our total net revenue attributable to our product offerings which serve Telecom and Datacom, and Consumer and Industrial markets which accounted for 10% or more of our total net revenue during the periods presented (in millions, except percentage data):

[0001628280-23-030374:notes:485]
|  |  |  | Years Ended |
|  |  |  | July 1, 2023 |  | July 2, 2022 |  | July 3, 2021 |
| OpComms: |  |  |  |  |  |  |  |  |  |  |
| Telecom and Datacom |  |  | $ | 1,324.5 |  | 75.0 | % |  | $ | 1,008.7 |  | 58.9 | % |  | $ | 1,059.7 |  | 60.8 | % |
| Consumer and Industrial |  |  | 233.3 |  | 13.2 | % |  | 509.8 |  | 29.8 | % |  | 561.0 |  | 32.2 | % |
| Total OpComms |  |  | $ | 1,557.8 |  | 88.2 | % |  | $ | 1,518.5 |  | 88.7 | % |  | $ | 1,620.7 |  | 93.0 | % |
| Lasers |  |  | 209.2 |  | 11.8 | % |  | 194.1 |  | 11.3 | % |  | 122.1 |  | 7.0 | % |
| Net Revenue |  |  | $ | 1,767.0 |  |  |  | $ | 1,712.6 |  |  |  | $ | 1,742.8 |  |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001628280-23-030374:notes:486]
Note 19. Revenue Recognition

[0001628280-23-030374:notes:487]
We disaggregate revenue by product and by geography. We do not present other levels of disaggregation, such as by type of products, customer, markets, contracts, duration of contracts, timing of transfer of control and sales channels, as this information is not used by our CODM to manage the business.

[0001628280-23-030374:notes:488]
The following table reflects the changes in contract balances for the periods presented (in millions, except percentages):

[0001628280-23-030374:notes:489]
| Contract balances |  | Balance sheet location |  | July 1, 2023 |  | July 2, 2022 |  | Change |  | Percentage Change |
| Accounts receivable, net |  | Accounts receivable, net |  | $ | 246.1 |  |  | $ | 262.0 |  |  | $ | (15.9) |  |  | (6.1)% |
| Deferred revenue and customer deposits |  | Other current liabilities |  | $ | 2.1 |  |  | $ | — |  |  | $ | 2.1 |  |  | 100.0% |


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001628280-23-030374:notes:490]
SCHEDULE II - VALUATION AND QUALIFYING ACCOUNTS

[0001628280-23-030374:notes:491]
|  | (in millions) |
|  | Balance at beginning of period |  |  |  | Increase (decrease) in Consolidated Statements of Operations |  | Write-offs and other adjustments |  |  |  | Balance at end of period |
| Allowance for credit losses: |  |  |  |  |  |  |  |  |  |  |  |
| Fiscal year ended July 1, 2023 | $ | — |  |  |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |
| Fiscal year ended July 2, 2022 | $ | 0.4 |  |  |  |  | $ | (0.1) |  |  | $ | (0.3) |  |  |  |  | $ | — |  |
| Fiscal year ended July 3, 2021 | $ | 1.8 |  |  |  |  | $ | 0.2 |  |  | $ | (1.6) |  |  |  |  | $ | 0.4 |  |

[0001628280-23-030374:notes:492]
|  |  | (in millions) |
|  |  | Balance at beginning of period |  | Additions charged to costs/expenses (1) |  | Deductions credited to costs/expenses (2) |  | Balance at end of period |
| Deferred tax valuation allowance: |  |  |  |  |  |  |  |  |
| Fiscal year ended July 1, 2023 |  | $ | 263.1 |  |  | $ | 42.7 |  |  | $ | (2.4) |  |  | $ | 303.4 |  |
| Fiscal year ended July 2, 2022 |  | $ | 269.5 |  |  | $ | 5.7 |  |  | $ | (12.1) |  |  | $ | 263.1 |  |
| Fiscal year ended July 3, 2021 |  | $ | 200.8 |  |  | $ | 68.7 |  |  | $ | — |  |  | $ | 269.5 |  |

[0001628280-23-030374:notes:493]
(1) Additions include current year additions charged to expenses and current year build due to increases in net deferred tax assets, return to provision true-ups, other adjustments to deferred taxes.

[0001628280-23-030374:notes:494]
(2) Net deductions include current year releases credited to expenses and current year reductions due to decreases in net deferred tax assets, return to provision true-ups, other adjustments to deferred taxes.
