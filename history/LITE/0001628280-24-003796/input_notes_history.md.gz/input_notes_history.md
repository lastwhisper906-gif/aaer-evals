# LITE note change history — 0001628280-23-037591 → 0001628280-24-003796


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-02-08):
[0001628280-24-003796:note_history:1]
Our purchase obligations of $423.8 million as of December 30, 2023 represent legally binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule and adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.
  (was, 2023-11-08, similarity 0.9939):
[0001628280-23-037591:note_history:1]
Our purchase obligations of $395.0 million as of September 30, 2023  represent legally binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule and adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

- changed (2024-02-08):
[0001628280-24-003796:note_history:2]
We provide reserves for the estimated costs of product warranties at the time revenue is recognized. We typically offer a twelve-month warranty for most of our products. However, in some instances depending upon the product, product components or application of our products by the end customer, our warranties can vary and generally range from six months to five years. We estimate the costs of our warranty obligations on an annualized basis based on our historical experience of known product failure rates, use of materials to repair or replace defective products, and service delivery costs incurred in correcting product failures. In addition, from time-to-time, specific warranty accruals may be made if unforeseen technical problems arise with specific products. We assess the adequacy of our recorded warranty liabilities and adjust the amounts as necessary.
  (was, 2023-11-08, similarity 0.9954):
[0001628280-23-037591:note_history:2]
We provide reserves for the estimated costs of product warranties at the time revenue is recognized. We typically offer a twelve-month warranty for most of our products. However, in some instances depending upon the product, product components or application of our products by the end customer, our warranties can vary and generally range from six months to five years. We estimate the costs of our warranty obligations on an annualized basis based on our historical experience of known product failure rates, use of materials to repair or replace defective products, and service delivery costs incurred in correcting product failures. In addition, from time to time, specific warranty accruals may be made if unforeseen technical problems arise with specific products. We assess the adequacy of our recorded warranty liabilities and adjust the amounts as necessary.

- added (2024-02-08):
[0001628280-24-003796:note_history:3]
|  | Three Months Ended |  | Six Months Ended |
|  | December 30, 2023 |  | December 31, 2022 |  | December 30, 2023 |  | December 31, 2022 |
| Balance as of beginning of period | $ | 5.5 |  |  | $ | 10.1 |  |  | $ | 6.8 |  |  | $ | 10.0 |  |
| Warranty assumed from Cloud Light | 5.2 |  |  | — |  |  | 5.2 |  |  | — |  |
| Provision for warranty | 0.8 |  |  | 2.8 |  |  | 1.0 |  |  | 5.0 |  |
| Utilization of reserve, net | (1.4) |  |  | (4.5) |  |  | (2.9) |  |  | (6.6) |  |
| Balance as of end of period | $ | 10.1 |  |  | $ | 8.4 |  |  | $ | 10.1 |  |  | $ | 8.4 |  |

- changed (2024-02-08):
[0001628280-24-003796:note_history:4]
We are subject to a variety of claims and suits that arise from time-to-time in the ordinary course of our business. While management currently believes that resolving claims against us, individually or in the aggregate, will not have a material adverse impact on our financial position, results of operations or statements of cash flows, these matters are subject to inherent uncertainties and management’s view of these matters may change in the future. We accrue for loss contingencies when it is both probable that we will incur the loss and when we can reasonably estimate the amount of the loss or range of loss. During the year ended July 1, 2023, we recorded $7.8 million with respect to the pending settlement of certain non-ordinary course litigation matters under accrued expenses in our consolidated balance sheet, which has not been settled as of December 30, 2023.
  (was, 2023-11-08, similarity 0.9913):
[0001628280-23-037591:note_history:4]
We are subject to a variety of claims and suits that arise from time to time in the ordinary course of our business. While management currently believes that resolving claims against us, individually or in the aggregate, will not have a material adverse impact on our financial position, results of operations or statements of cash flows, these matters are subject to inherent uncertainties and management’s view of these matters may change in the future. We accrue for loss contingencies when it is both probable that we will incur the loss and when we can reasonably estimate the amount of the loss or range of loss. During the year ended July 1, 2023, we recorded $7.8 million with respect to the pending settlement of certain non-ordinary course litigation matters under accrued expenses in our consolidated balance sheet, which has not been settled as of September 30, 2023.

- changed (2024-02-08):
[0001628280-24-003796:note_history:5]
In the normal course of business, we enter into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown, because claims may be made against us in the future, and we may record charges in the future as a result of these indemnification obligations. As of December 30, 2023, we did not have any material indemnification claims that were probable or reasonably possible.
  (was, 2023-11-08, similarity 0.9923):
[0001628280-23-037591:note_history:5]
In the normal course of business, we enter into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown, because claims may be made against us in the future, and we may record charges in the future as a result of these indemnification obligations. As of September 30, 2023, we did not have any material indemnification claims that were probable or reasonably possible.

- removed (2024-02-08):
[0001628280-23-037591:note_history:6]
|  | Three Months Ended |  |  |
|  | September 30, 2023 |  | October 1, 2022 |  |  |  |  |
| Balance as of beginning of period | $ | 6.8 |  |  | $ | 10.0 |  |  |  |  |  |
| Warranties assumed in NeoPhotonics merger | — |  |  | 0.7 |  |  |  |  |  |
| Provision for warranty | 0.2 |  |  | 1.5 |  |  |  |  |  |
| Utilization of reserve | (1.5) |  |  | (2.1) |  |  |  |  |  |
| Balance as of end of period | $ | 5.5 |  |  | $ | 10.1 |  |  |  |  |  |


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2024-02-08):
[0001628280-24-003796:note_history:7]
Lumentum Holdings Inc. (“we,” “us,” “our,” “Lumentum” or the “Company”) is an industry-leading provider of optical and photonic products addressing a range of end-market applications for manufacturing, inspection, and life-science applications.
  (was, 2023-11-08, similarity 0.7541):
[0001628280-23-037591:note_history:7]
Lumentum Holdings Inc. (“we,” “us,” “our,” “Lumentum” or the “Company”) is an industry-leading provider of optical and photonic products addressing a range of end market applications for manufacturing, inspection, and life-science applications.

- changed (2024-02-08):
[0001628280-24-003796:note_history:8]
Our Cloud & Networking products include a wide range of components, modules and subsystems to support customers including carrier networks for access (local), metro (intracity), long-haul (city-to-city and worldwide) and submarine (undersea) applications. Our products also address enterprise, cloud and data center applications, including storage-access networks (“SANs”), local-area networks (“LANs”) and wide-area networks (“WANs”), as well as artificial intelligence and machine learning (“AI/ML”).
  (was, 2023-11-08, similarity 0.994):
[0001628280-23-037591:note_history:8]
Our Cloud and Networking products include a wide range of components, modules, and subsystems to support customers including carrier networks for access (local), metro (intracity), long-haul (city-to-city and worldwide) and submarine (undersea) applications. Our  products also address enterprise, cloud, and data center applications, including storage-access networks (“SANs”), local-area networks (“LANs”) and wide-area networks (“WANs”), as well as artificial intelligence and machine learning (“AI/ML”).

- added (2024-02-08):
[0001628280-24-003796:note_history:9]
Our Industrial Tech products include diode laser products such as VCSELs and edge emitting lasers. In the consumer end-market, our laser light sources are integrated into 3D sensing cameras, which are used in applications in mobile devices, gaming, payment kiosks, computers, other consumer electronics devices, and automobiles. Applications include biometric identification, computational photography, virtual and augmented reality, and natural user interfaces, among others. In the industrial end-market, our diode lasers are used primarily as pump sources for pulsed and kilowatt class fiber lasers. Our products also include laser products used in a variety of OEM applications including diode-pumped solid-state, fiber, diode, direct-diode and gas lasers, such as argon-ion and helium-neon lasers.

- changed (2024-02-08):
[0001628280-24-003796:note_history:10]
We are continuously monitoring both the current developments in the ongoing war between Russia and Ukraine including the related additional export controls and resulting sanctions imposed on Russia and Belarus by the U.S. and other countries, and the war between Israel and Hamas. Additional factors, such as increased inflation, escalating energy costs, constrained raw material availability and the related cost increases, could continue to impact the global economy and our business. Although the global implications of the wars are difficult to predict at this time, we do not presently foresee direct material adverse effects on our business.
  (was, 2023-11-08, similarity 0.9946):
[0001628280-23-037591:note_history:10]
We are continuously monitoring both the current developments in the ongoing war between Russia and Ukraine including the related additional export controls and resulting sanctions imposed on Russia and Belarus by the U.S. and other countries, and the recent war between Israel and Hamas. Additional factors, such as increased inflation, escalating energy costs, constrained raw material availability and the related cost increases, could continue to impact the global economy and our business. Although the global implications of the wars are difficult to predict at this time, we do not presently foresee direct material adverse effects on our business.

- added (2024-02-08):
[0001628280-24-003796:note_history:11]
On November 7, 2023 (the “Closing date”), we completed the acquisition of Cloud Light Technology Limited (“Cloud Light”). Our condensed consolidated financial statements include the operating results of Cloud Light for the period from the Closing date of the acquisition through December 30, 2023. On August 3, 2022, we completed the acquisition of NeoPhotonics Corporation (“NeoPhotonics”). On August 15, 2022, we completed the acquisition of IPG Photonics’ telecom transmission product lines. We have applied the acquisition method of accounting to account for these transactions in accordance with ASC Topic 805, Business Combinations. Refer to “Note 4. Business Combinations” for further discussions of these transactions.

- changed (2024-02-08):
[0001628280-24-003796:note_history:12]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Every fifth or sixth fiscal year will have a 53-week period. The additional week in a 53-week year is added to the third quarter, making such quarter consist of 14 weeks. Our fiscal 2024 is a 52-week year ending on June 29, 2024, with the quarter ended December 30, 2023 being a 13-week quarterly period. Our fiscal 2023 was a 52-week year that ended on July 1, 2023, with the quarter ended December 31, 2022 being a 13-week quarterly period.
  (was, 2023-11-08, similarity 0.9835):
[0001628280-23-037591:note_history:12]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Every fifth or sixth fiscal year will have a 53-week period. The additional week in a 53-week year is added to the third quarter, making such quarter consist of 14 weeks. Our fiscal 2024 is a 52-week year ending on June 29, 2024, with the quarter ended September 30, 2023 being a 13-week quarterly period. Our fiscal 2023 was a 52-week year that ended on July 1, 2023, with the quarter ended October 1, 2022 being a 13-week quarterly period.

- added (2024-02-08):
[0001628280-24-003796:note_history:13]
Accounting Policies

- changed (2024-02-08):
[0001628280-24-003796:note_history:14]
The condensed consolidated financial statements and accompanying notes should be read in conjunction with the audited consolidated financial statements and accompanying notes included in our Annual Report on Form 10-K for the fiscal year ended July 1, 2023. There were no significant changes to our accounting policies during the six months ended December 30, 2023
  (was, 2023-11-08, similarity 0.9136):
[0001628280-23-037591:note_history:14]
Accounting Policies
The condensed consolidated financial statements and accompanying notes should be read in conjunction with the audited consolidated financial statements and accompanying notes included in our Annual Report on Form 10-K for the fiscal year ended July 1, 2023. There were no significant changes to our accounting policies during the three months ended September 30, 2023.

- removed (2024-02-08):
[0001628280-23-037591:note_history:15]
Our Industrial Tech products include diode laser products such as VCSELs and edge emitting lasers. In the consumer end-market, our laser light sources are integrated into 3D sensing cameras which are used in applications in mobile devices, gaming, payment kiosks, computers, and other consumer electronics devices. Applications include biometric identification, computational photography, virtual and augmented reality, and natural user interfaces, among others. In the industrial end-market, our diode lasers are used primarily as pump sources for pulsed and kilowatt class fiber lasers. Our products also include laser products used in a variety of OEM applications including diode-pumped solid-state, fiber, diode, direct-diode and gas lasers such as argon-ion and helium-neon lasers.

- removed (2024-02-08):
[0001628280-23-037591:note_history:16]
On August 3, 2022, we completed a merger with NeoPhotonics Corporation (“NeoPhotonics”). On August 15, 2022, we completed a transaction to acquire IPG Photonics’ telecom transmission product lines. We have applied the acquisition method of accounting in accordance with ASC Topic 805, Business Combinations to account for both of the transactions. Refer to “Note 4. Business Combinations”.


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-02-08):
[0001628280-24-003796:note_history:17]
| December 30, 2023 | 2024 Notes (1) |  | 2026 Notes (2) |  | 2028 Notes (3) |  | 2029 Notes (4) |  | Total |  |  |  |  |  |
| Principal | $ | 323.1 |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |  | $ | 603.7 |  |  | $ | 2,837.8 |  |  |  |  |  |  |
| Unamortized debt discount and debt issuance costs | (3.4) |  |  | (3.5) |  |  | (4.8) |  |  | (4.7) |  |  | (16.4) |  |  |  |  |  |  |
| Net carrying amount of the liability component | $ | 319.7 |  |  | $ | 1,046.5 |  |  | $ | 856.2 |  |  | $ | 599.0 |  |  | $ | 2,821.4 |  |  |  |  |  |  |
  (was, 2023-11-08, similarity 0.9915):
[0001628280-23-037591:note_history:17]
| September 30, 2023 | 2024 Notes (1) |  | 2026 Notes (2) |  | 2028 Notes (3) |  | 2029 Notes (4) |  | Total |  |  |  |  |  |
| Principal | $ | 323.1 |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |  | $ | 603.7 |  |  | $ | 2,837.8 |  |  |  |  |  |  |
| Unamortized debt discount and debt issuance costs | (7.4) |  |  | (3.8) |  |  | (5.1) |  |  | (4.9) |  |  | (21.2) |  |  |  |  |  |  |
| Net carrying amount of the liability component | $ | 315.7 |  |  | $ | 1,046.2 |  |  | $ | 855.9 |  |  | $ | 598.8 |  |  | $ | 2,816.6 |  |  |  |  |  |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-02-08):
[0001628280-24-003796:note_history:18]
On June 16, 2023, we issued $603.7 million in aggregate principal amount of 1.50% Convertible Senior Notes due in 2029 (“2029 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act of 1933, as amended. The 2029 Notes are governed by an indenture between the Company and U.S. Bank Trust Company National Association, (as successor in interest to U.S. Bank National Association), as a trustee (the “2029 Indenture”). The 2029 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.
  (was, 2023-11-08, similarity 0.9945):
[0001628280-23-037591:note_history:18]
On June 16, 2023, we issued $603.7 million in aggregate principal amount of 1.50% convertible notes due in 2029 (“2029 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act of 1933, as amended. The 2029 Notes are governed by an indenture between the Company and U.S. Bank Trust Company National Association, (as successor in interest to U.S. Bank National Association), as a trustee (the “2029 Indenture”). The 2029 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

- added (2024-02-08):
[0001628280-24-003796:note_history:19]
The 2029 Notes bear interest at a rate of 1.50% per year, payable semi-annually in arrears on June 15 and December 15 of each year. The 2029 Notes will mature on December 15, 2029, unless earlier redeemed, repurchased by us, or converted pursuant to their terms.

- changed (2024-02-08):
[0001628280-24-003796:note_history:20]
The entire 2029 Notes are recorded as convertible notes, non-current in our consolidated balance sheets as of December 30, 2023 and July 1, 2023, measured at amortized cost.
  (was, 2023-11-08, similarity 0.9844):
[0001628280-23-037591:note_history:20]
The entire 2029 Notes are recorded as convertible notes, non-current in our consolidated balance sheets as of September 30, 2023 and July 1, 2023, measured at amortized cost.

- changed (2024-02-08):
[0001628280-24-003796:note_history:21]
•upon the occurrence of specified corporate events, as specified in the 2028 Indentures.
  (was, 2023-11-08, similarity 0.9941):
[0001628280-23-037591:note_history:21]
•upon the occurrence of specified corporate events, as specified in the 2028 Indentures

- changed (2024-02-08):
[0001628280-24-003796:note_history:22]
We initially bifurcated the principal amount of the 2028 Notes into liability and equity components. The liability component of the 2028 Notes was initially valued at $629.8 million based on the contractual cash flow discounted at an appropriate comparable market on non-convertible debt borrowing rate at the date of issuance, which was 5.7%, with the equity component representing the residual amount of the proceeds of $231.2 million, which was recorded as a debt discount. Upon adoption of ASU 2020-06 in the first quarter of fiscal 2023, our 2028 Notes were accounted for as a single liability measured at amortized cost. The entire 2028 Notes are recorded as convertible notes, non-current in our consolidated balance sheets as of December 30, 2023 and July 1, 2023, measured at amortized cost.
  (was, 2023-11-08, similarity 0.9954):
[0001628280-23-037591:note_history:22]
We initially bifurcated the principal amount of the 2028 Notes into liability and equity components. The liability component of the 2028 Notes was initially valued at $629.8 million based on the contractual cash flow discounted at an appropriate comparable market on non-convertible debt borrowing rate at the date of issuance, which was 5.7%, with the equity component representing the residual amount of the proceeds of $231.2 million, which was recorded as a debt discount. Upon adoption of ASU 2020-06 in the first quarter of fiscal 2023, our 2028 Notes were accounted for as a single liability measured at amortized cost. The entire 2028 Notes are recorded as convertible notes, non-current in our consolidated balance sheets as of September 30, 2023 and July 1, 2023, measured at amortized cost.

- added (2024-02-08):
[0001628280-24-003796:note_history:23]
The 2026 Notes bear interest at a rate of 0.50% per year, payable semi-annually in arrears on June 15 and December 15 of each year. The 2026 Notes will mature on December 15, 2026, unless earlier redeemed, repurchased by us, or converted pursuant to their terms.

- changed (2024-02-08):
[0001628280-24-003796:note_history:24]
The initial conversion rate is 10.0711 shares of common stock per $1,000 principal amount of the 2026 Notes (which is equivalent to an initial conversion price of approximately $99.29 per share). The conversion rate is subject to adjustment upon the occurrence of certain events specified in the 2026 Indenture, but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change (as defined in the 2026 Indenture) or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares set forth in the 2026 Indenture or a holder that elects to convert the 2026 Notes in connection with such make-whole fundamental change or notice of redemption.
  (was, 2023-11-08, similarity 0.9993):
[0001628280-23-037591:note_history:24]
The initial conversion rate is 10.0711 shares of common stock per $1,000 principal amount of the 2026 Notes (which is equivalent to an initial conversion price of approximately $99.29 per share). The conversion rate is subject to adjustment upon the occurrence of certain events specified in the 2026 Indenture but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change (as defined in the 2026 Indenture) or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares set forth in the 2026 Indenture or a holder that elects to convert the 2026 Notes in connection with such make-whole fundamental change or notice of redemption.

- changed (2024-02-08):
[0001628280-24-003796:note_history:25]
We initially bifurcated the principal amount of the 2026 Notes into liability and equity components. The liability component of the 2026 Notes was initially valued at $734.8 million based on the contractual cash flows discounted at an appropriate comparable market non-convertible debt borrowing rate at the date of issuance of 5.8% with the equity component representing the residual amount of the proceeds of $315.2 million, which was recorded as a debt discount. Upon adoption of ASU 2020-06 in the first quarter of fiscal 2023, our 2026 Notes were accounted for as a single liability measured at amortized cost. The entire 2026 Notes are recorded as convertible notes, non-current in our consolidated balance sheets as of December 30, 2023 and July 1, 2023, measured at amortized cost.
  (was, 2023-11-08, similarity 0.9953):
[0001628280-23-037591:note_history:25]
We initially bifurcated the principal amount of the 2026 Notes into liability and equity components. The liability component of the 2026 Notes was initially valued at $734.8 million based on the contractual cash flows discounted at an appropriate comparable market non-convertible debt borrowing rate at the date of issuance of 5.8% with the equity component representing the residual amount of the proceeds of $315.2 million, which was recorded as a debt discount. Upon adoption of ASU 2020-06 in the first quarter of fiscal 2023, our 2026 Notes were accounted for as a single liability measured at amortized cost. The entire 2026 Notes are recorded as convertible notes, non-current in our consolidated balance sheets as of September 30, 2023 and July 1, 2023, measured at amortized cost.

- added (2024-02-08):
[0001628280-24-003796:note_history:26]
The 2024 Notes bear interest at a rate of 0.25% per year. Interest on the 2024 Notes is payable semi-annually in arrears on March 15 and September 15 of each year. The 2024 Notes will mature on March 15, 2024, unless earlier repurchased by us or converted pursuant to their terms.

- changed (2024-02-08):
[0001628280-24-003796:note_history:27]
Prior to the close of business on the business day immediately preceding December 15, 2023, each holder of the 2024 Notes was able to convert their 2024 Notes only under the following circumstances:
  (was, 2023-11-08, similarity 0.967):
[0001628280-23-037591:note_history:27]
Prior to the close of business on the business day immediately preceding December 15, 2023, each holder of the 2024 Notes may convert their 2024 Notes only under the following circumstances:

- changed (2024-02-08):
[0001628280-24-003796:note_history:28]
Concurrent with the issuance of the 2029 Notes in June 2023, we used $132.8 million of the net proceeds to repurchase $125.0 million aggregate principal amount of the 2024 Notes, which we accounted for as an extinguishment of liability. $13.5 million of the $132.8 million repurchase price was allocated to the conversion feature of the repurchased 2024 Notes, representing the fair value of the conversion feature at the date of the repurchase, and was recognized as a reduction of the stockholders’ equity. Additionally, since issuing the 2024 Notes, we have converted a total of approximately $1.9 million principal amount of the 2024 Notes. The remaining principal amount was $323.1 million as of December 30, 2023 and July 1, 2023, recorded as convertible notes, current in our consolidated balance sheets, as the 2024 Notes will mature on March 15, 2024.
  (was, 2023-11-08, similarity 0.9956):
[0001628280-23-037591:note_history:28]
Concurrent with the issuance of the 2029 Notes in June 2023, we used $132.8 million of the net proceeds to repurchase $125.0 million aggregate principal amount of the 2024 Notes, which we accounted for as an extinguishment of liability. $13.5 million of the $132.8 million repurchase price was allocated to the conversion feature of the repurchased 2024 Notes, representing the fair value of the conversion feature at the date of the repurchase, and was recognized as a reduction of the stockholders’ equity. Additionally, since issuing the 2024 Notes, we have converted a total of approximately $1.9 million principal amount of the 2024 Notes. The remaining principal amount was $323.1 million as of September 30, 2023 and July 1, 2023, recorded as convertible notes, current in our consolidated balance sheets, as the 2024 Notes will mature on March 15, 2024.

- changed (2024-02-08):
[0001628280-24-003796:note_history:29]
| December 30, 2023 | 2024 Notes (1) |  | 2026 Notes (2) |  | 2028 Notes (3) |  | 2029 Notes (4) |  | Total |  |  |  |  |  |
| Principal | $ | 323.1 |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |  | $ | 603.7 |  |  | $ | 2,837.8 |  |  |  |  |  |  |
| Unamortized debt discount and debt issuance costs | (3.4) |  |  | (3.5) |  |  | (4.8) |  |  | (4.7) |  |  | (16.4) |  |  |  |  |  |  |
| Net carrying amount of the liability component | $ | 319.7 |  |  | $ | 1,046.5 |  |  | $ | 856.2 |  |  | $ | 599.0 |  |  | $ | 2,821.4 |  |  |  |  |  |  |
  (was, 2023-11-08, similarity 0.9915):
[0001628280-23-037591:note_history:29]
| September 30, 2023 | 2024 Notes (1) |  | 2026 Notes (2) |  | 2028 Notes (3) |  | 2029 Notes (4) |  | Total |  |  |  |  |  |
| Principal | $ | 323.1 |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |  | $ | 603.7 |  |  | $ | 2,837.8 |  |  |  |  |  |  |
| Unamortized debt discount and debt issuance costs | (7.4) |  |  | (3.8) |  |  | (5.1) |  |  | (4.9) |  |  | (21.2) |  |  |  |  |  |  |
| Net carrying amount of the liability component | $ | 315.7 |  |  | $ | 1,046.2 |  |  | $ | 855.9 |  |  | $ | 598.8 |  |  | $ | 2,816.6 |  |  |  |  |  |  |

- changed (2024-02-08):
[0001628280-24-003796:note_history:30]
|  | Three Months Ended |  | Six Months Ended |
|  | December 30, 2023 |  | December 31, 2022 |  | December 30, 2023 |  | December 31, 2022 |
| Contractual interest expense | $ | 4.9 |  |  | $ | 2.7 |  |  | $ | 9.7 |  |  | $ | 5.4 |  |
| Amortization of the debt discount and debt issuance costs | 4.8 |  |  | 6.2 |  |  | 9.7 |  |  | 11.9 |  |
| Total interest expense | $ | 9.7 |  |  | $ | 8.9 |  |  | $ | 19.4 |  |  | $ | 17.3 |  |
  (was, 2023-11-08, similarity 0.715):
[0001628280-23-037591:note_history:30]
|  | Three Months Ended |  |  |
|  | September 30, 2023 |  | October 1, 2022 |  |  |  |  |
| Contractual interest expense | $ | 4.8 |  |  | $ | 2.7 |  |  |  |  |  |
| Amortization of the debt discount and debt issuance costs | 4.9 |  |  | 5.7 |  |  |  |  |  |
| Total interest expense | $ | 9.7 |  |  | $ | 8.4 |  |  |  |  |  |

- changed (2024-02-08):
[0001628280-24-003796:note_history:31]
The future interest and principal payments related to our convertible notes are as follows as of December 30, 2023 (in millions):
  (was, 2023-11-08, similarity 0.9799):
[0001628280-23-037591:note_history:31]
The future interest and principal payments related to our convertible notes are as follows as of September 30, 2023 (in millions):

- changed (2024-02-08):
[0001628280-24-003796:note_history:32]
In connection with the NeoPhotonics acquisition, we assumed several loan agreements with MUFG Bank, Ltd. (the “Mitsubishi Bank Loans”) for an aggregate fair value of approximately $5.9 million, approximately $0.9 million of which was paid in the fiscal first quarter of 2023 and the remaining balance of approximately $5.0 million was fully paid in the fiscal second quarter of 2023.
  (was, 2023-11-08, similarity 0.9268):
[0001628280-23-037591:note_history:32]
In connection with our merger of NeoPhotonics, we assumed several loan agreements with MUFG Bank, Ltd. (the “Mitsubishi Bank Loans”) for an aggregate fair value of approximately $5.9 million, approximately $0.9 million of which was paid in the fiscal first quarter of 2023 and the remaining balance of approximately $5.0 million was fully paid in the fiscal second quarter of 2023.

- removed (2024-02-08):
[0001628280-23-037591:note_history:33]
The 2029 Notes bear interest at a rate of 1.50% per year, payable semi-annually in arrears on June 15 and December 15 of each year, beginning on December 15, 2023. The 2029 Notes will mature on December 15, 2029, unless earlier redeemed, repurchased by us, or converted pursuant to their terms.

- removed (2024-02-08):
[0001628280-23-037591:note_history:34]
The 2026 Notes bear interest at a rate of 0.50% per year, payable semi-annually in arrears on June 15 and December 15 of each year, beginning on June 15, 2020. The 2026 Notes will mature on December 15, 2026, unless earlier redeemed, repurchased by us, or converted pursuant to their terms.

- removed (2024-02-08):
[0001628280-23-037591:note_history:35]
The 2024 Notes bear interest at a rate of 0.25% per year. Interest on the 2024 Notes is payable semi-annually in arrears on March 15 and September 15 of each year, beginning on September 15, 2017. The 2024 Notes will mature on March 15, 2024, unless earlier repurchased by us or converted pursuant to their terms.


## us-gaap:DebtSecuritiesAvailableForSaleUnrealizedLossPositionFairValueTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-02-08):
[0001628280-24-003796:note_history:36]
|  | Continuous Loss Position for More Than 12 Months |  | Continuous Loss Position for Less Than 12 Months |  | Gross Unrealized Losses |  |  |  |  |  |  |  |  |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  |  |  |  |  |  |  |  |  |
| December 30, 2023: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | 5.0 |  |  | $ | — |  |  | $ | 113.5 |  |  | $ | (0.4) |  |  | $ | (0.4) |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | — |  |  | 4.0 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | — |  |  | — |  |  | 25.0 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 40.8 |  |  | (0.1) |  |  | 231.3 |  |  | (0.7) |  |  | (0.8) |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 4.5 |  |  | — |  |  | 167.0 |  |  | (0.5) |  |  | (0.5) |  |  |  |  |  |  |  |  |  |
| Total | $ | 50.3 |  |  | $ | (0.1) |  |  | $ | 540.8 |  |  | $ | (1.6) |  |  | $ | (1.7) |  |  |  |  |  |  |  |  |  |
| July 1, 2023: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | 39.6 |  |  | $ | (0.4) |  |  | $ | 170.6 |  |  | $ | (1.3) |  |  | $ | (1.7) |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | — |  |  | 7.7 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | — |  |  | — |  |  | 128.5 |  |  | (0.2) |  |  | (0.2) |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 93.6 |  |  | (1.2) |  |  | 358.9 |  |  | (2.7) |  |  | (3.9) |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 50.8 |  |  | (0.6) |  |  | 221.4 |  |  | (1.4) |  |  | (2.0) |  |  |  |  |  |  |  |  |  |
| Total | $ | 184.0 |  |  | $ | (2.2) |  |  | $ | 887.1 |  |  | $ | (5.6) |  |  | $ | (7.8) |  |  |  |  |  |  |  |  |  |
  (was, 2023-11-08, similarity 0.7989):
[0001628280-23-037591:note_history:36]
|  | Continuous Loss Position for More Than 12 Months |  | Continuous Loss Position for Less Than 12 Months |  | Gross Unrealized Losses |  |  |  |  |  |  |  |  |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  |  |  |  |  |  |  |  |  |
| September 30, 2023: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | 159.5 |  |  | $ | (1.2) |  |  | $ | 33.8 |  |  | $ | (0.2) |  |  | $ | (1.4) |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | 11.7 |  |  | — |  |  | — |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | 89.9 |  |  | (0.1) |  |  | — |  |  | — |  |  | (0.1) |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 351.3 |  |  | (2.7) |  |  | 68.7 |  |  | (0.5) |  |  | (3.2) |  |  |  |  |  |  |  |  |  |
| Foreign government bonds | 4.6 |  |  | — |  |  | — |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 215.4 |  |  | (1.3) |  |  | 22.9 |  |  | (0.2) |  |  | (1.5) |  |  |  |  |  |  |  |  |  |
| Total | $ | 832.4 |  |  | $ | (5.3) |  |  | $ | 125.4 |  |  | $ | (0.9) |  |  | $ | (6.2) |  |  |  |  |  |  |  |  |  |
| July 1, 2023: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | 39.6 |  |  | $ | (0.4) |  |  | $ | 170.6 |  |  | $ | (1.3) |  |  | $ | (1.7) |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | — |  |  | $ | 7.7 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | — |  |  | — |  |  | $ | 128.5 |  |  | (0.2) |  |  | (0.2) |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 93.6 |  |  | (1.2) |  |  | $ | 358.9 |  |  | (2.7) |  |  | (3.9) |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 50.8 |  |  | (0.6) |  |  | $ | 221.4 |  |  | (1.4) |  |  | (2.0) |  |  |  |  |  |  |  |  |  |
| Total | $ | 184.0 |  |  | $ | (2.2) |  |  | $ | 887.1 |  |  | $ | (5.6) |  |  | $ | (7.8) |  |  |  |  |  |  |  |  |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-02-08):
[0001628280-24-003796:note_history:37]
The future interest and principal payments related to our convertible notes are as follows as of December 30, 2023 (in millions):
  (was, 2023-11-08, similarity 0.9799):
[0001628280-23-037591:note_history:37]
The future interest and principal payments related to our convertible notes are as follows as of September 30, 2023 (in millions):


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2024-02-08):
[0001628280-24-003796:note_history:38]
|  | Three Months Ended |  | Six Months Ended |
|  | December 30, 2023 |  | December 31, 2022 |  | December 30, 2023 |  | December 31, 2022 |
|  | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |
| Cloud & Networking | $ | 286.7 |  |  | 78.2 | % |  | $ | 382.9 |  |  | 75.7 | % |  | $ | 516.4 |  |  | 75.5 | % |  | $ | 743.0 |  |  | 73.4 | % |
| Industrial Tech | 80.1 |  |  | 21.8 | % |  | 123.1 |  |  | 24.3 | % |  | 168.0 |  |  | 24.5 | % |  | 269.8 |  |  | 26.6 | % |
| Net revenue | $ | 366.8 |  |  | 100.0 | % |  | $ | 506.0 |  |  | 100.0 | % |  | $ | 684.4 |  |  | 100.0 | % |  | $ | 1,012.8 |  |  | 100.0 | % |

- added (2024-02-08):
[0001628280-24-003796:note_history:39]
| Contract balances |  | Balance sheet location |  | December 30, 2023 |  | July 1, 2023 |  | Change |  | Percentage Change |
| Accounts receivable, net |  | Accounts receivable, net |  | $ | 248.3 |  |  | $ | 246.1 |  |  | $ | 2.2 |  |  | 0.9 | % |
| Deferred revenue and customer deposits |  | Other current liabilities |  | $ | 0.9 |  |  | $ | 2.1 |  |  | $ | (1.2) |  |  | (57.1) | % |

- removed (2024-02-08):
[0001628280-23-037591:note_history:40]
|  | Three Months Ended |  |  |
|  | September 30, 2023 |  | October 1, 2022 |  |  |  |  |
|  | Amount |  | % of Total |  | Amount |  | % of Total |  |  |  |  |  |  |
| Cloud & Networking | $ | 229.7 |  |  | 72.3 | % |  | $ | 360.1 |  |  | 71.1 | % |  |  |  |  |  |  |
| Industrial Tech | 87.9 |  |  | 27.7 | % |  | 146.7 |  |  | 28.9 | % |  |  |  |  |  |  |
| Net revenue | $ | 317.6 |  |  | 100.0 | % |  | $ | 506.8 |  |  | 100.0 | % |  |  |  |  |  |  |

- removed (2024-02-08):
[0001628280-23-037591:note_history:41]
| Contract balances |  | Balance sheet location |  | September 30, 2023 |  | July 1, 2023 |  | Change |  | Percentage Change |
| Accounts receivable, net |  | Accounts receivable, net |  | $ | 220.0 |  |  | $ | 246.1 |  |  | $ | (26.1) |  |  | (10.6) | % |
| Deferred revenue and customer deposits |  | Other current liabilities |  | $ | 1.6 |  |  | $ | 2.1 |  |  | $ | (0.5) |  |  | (23.8) | % |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2024-02-08):
[0001628280-23-037591:note_history:42]
Note 17. Subsequent Event

- removed (2024-02-08):
[0001628280-23-037591:note_history:43]
On October 30, 2023, Lumentum and Cloud Light Technology Limited (“Cloud Light”) announced a definitive merger agreement (the “Merger Agreement”), On November 7, 2023 (the “Closing date”), we completed the acquisition of Cloud Light. The acquisition will enable us to be well-positioned to serve the growing needs of cloud and networking customers, particularly those focused on optimizing their data center infrastructure for the demands of AI/ML. The total transaction value is approximately $750.0 million, subject to certain customary adjustments as specified in the Merger Agreement. We paid cash consideration of $706.6 million to shareholders of Cloud Light on the Closing date. Additionally, we converted each of Cloud Light’s outstanding options into options to acquire Lumentum common stock with equivalent value.

- removed (2024-02-08):
[0001628280-23-037591:note_history:44]
During the three months ended September 30, 2023, we incurred $3.7 million of transaction costs related to this acquisition, which were recorded under selling, general and administrative expenses in our consolidated statement of operations.

- removed (2024-02-08):
[0001628280-23-037591:note_history:45]
The acquisition will be accounted for as a business combination using the acquisition method of accounting, which requires, among other things, certain assets acquired and liabilities assumed be recognized at their fair values as of the acquisition date. We are currently evaluating the purchase accounting for this acquisition.
