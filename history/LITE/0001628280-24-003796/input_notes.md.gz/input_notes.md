# LITE notes — 0001628280-24-003796


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001628280-24-003796:notes:1]
[same as prior period, unchanged from 0001628280-23-037591:notes:1]

[0001628280-24-003796:notes:2]
[same as prior period, unchanged from 0001628280-23-037591:notes:2]

[0001628280-24-003796:notes:3]
Lumentum Holdings Inc. (“we,” “us,” “our,” “Lumentum” or the “Company”) is an industry-leading provider of optical and photonic products addressing a range of end-market applications for manufacturing, inspection, and life-science applications.

[0001628280-24-003796:notes:4]
Our Cloud & Networking products include a wide range of components, modules and subsystems to support customers including carrier networks for access (local), metro (intracity), long-haul (city-to-city and worldwide) and submarine (undersea) applications. Our products also address enterprise, cloud and data center applications, including storage-access networks (“SANs”), local-area networks (“LANs”) and wide-area networks (“WANs”), as well as artificial intelligence and machine learning (“AI/ML”).

[0001628280-24-003796:notes:5]
Our Industrial Tech products include diode laser products such as VCSELs and edge emitting lasers. In the consumer end-market, our laser light sources are integrated into 3D sensing cameras, which are used in applications in mobile devices, gaming, payment kiosks, computers, other consumer electronics devices, and automobiles. Applications include biometric identification, computational photography, virtual and augmented reality, and natural user interfaces, among others. In the industrial end-market, our diode lasers are used primarily as pump sources for pulsed and kilowatt class fiber lasers. Our products also include laser products used in a variety of OEM applications including diode-pumped solid-state, fiber, diode, direct-diode and gas lasers, such as argon-ion and helium-neon lasers.

[0001628280-24-003796:notes:6]
[same as prior period, unchanged from 0001628280-23-037591:notes:6]

[0001628280-24-003796:notes:7]
[same as prior period, unchanged from 0001628280-23-037591:notes:7]

[0001628280-24-003796:notes:8]
[same as prior period, unchanged from 0001628280-23-037591:notes:8]

[0001628280-24-003796:notes:9]
[same as prior period, unchanged from 0001628280-23-037591:notes:9]

[0001628280-24-003796:notes:10]
We are continuously monitoring both the current developments in the ongoing war between Russia and Ukraine including the related additional export controls and resulting sanctions imposed on Russia and Belarus by the U.S. and other countries, and the war between Israel and Hamas. Additional factors, such as increased inflation, escalating energy costs, constrained raw material availability and the related cost increases, could continue to impact the global economy and our business. Although the global implications of the wars are difficult to predict at this time, we do not presently foresee direct material adverse effects on our business.

[0001628280-24-003796:notes:11]
[same as prior period, unchanged from 0001628280-23-037591:notes:11]

[0001628280-24-003796:notes:12]
On November 7, 2023 (the “Closing date”), we completed the acquisition of Cloud Light Technology Limited (“Cloud Light”). Our condensed consolidated financial statements include the operating results of Cloud Light for the period from the Closing date of the acquisition through December 30, 2023. On August 3, 2022, we completed the acquisition of NeoPhotonics Corporation (“NeoPhotonics”). On August 15, 2022, we completed the acquisition of IPG Photonics’ telecom transmission product lines. We have applied the acquisition method of accounting to account for these transactions in accordance with ASC Topic 805, Business Combinations. Refer to “Note 4. Business Combinations” for further discussions of these transactions.

[0001628280-24-003796:notes:13]
[same as prior period, unchanged from 0001628280-23-037591:notes:13]

[0001628280-24-003796:notes:14]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Every fifth or sixth fiscal year will have a 53-week period. The additional week in a 53-week year is added to the third quarter, making such quarter consist of 14 weeks. Our fiscal 2024 is a 52-week year ending on June 29, 2024, with the quarter ended December 30, 2023 being a 13-week quarterly period. Our fiscal 2023 was a 52-week year that ended on July 1, 2023, with the quarter ended December 31, 2022 being a 13-week quarterly period.

[0001628280-24-003796:notes:15]
[same as prior period, unchanged from 0001628280-23-037591:notes:15]

[0001628280-24-003796:notes:16]
[same as prior period, unchanged from 0001628280-23-037591:notes:16]

[0001628280-24-003796:notes:17]
Accounting Policies

[0001628280-24-003796:notes:18]
The condensed consolidated financial statements and accompanying notes should be read in conjunction with the audited consolidated financial statements and accompanying notes included in our Annual Report on Form 10-K for the fiscal year ended July 1, 2023. There were no significant changes to our accounting policies during the six months ended December 30, 2023


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001628280-24-003796:notes:19]
Note 2. Recently Issued Accounting Pronouncements

[0001628280-24-003796:notes:20]
In December 2023, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) No. 2023-09, “Income Taxes (Topic 740): Improvements to Income Tax Disclosures”. ASU No. 2023-09 requires disaggregated information about a reporting entity’s effective tax rate reconciliation as well as information on income tax paid. ASU No. 2023-09 will become effective for us in fiscal 2026, with early adoption permitted. We are currently evaluating the impact of this ASU on our income tax disclosures within the consolidated financial statements.

[0001628280-24-003796:notes:21]
In November 2023, the FASB issued ASU 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures, which updates reportable segment disclosure requirements primarily through enhanced disclosures about significant segment expenses. ASU 2023-07 does not change how a public entity identifies its operating segments, aggregates those operating segments, or applies quantitative thresholds to determine its reportable segments. The update is effective for fiscal years beginning after December 15, 2023, and interim periods within fiscal years beginning after December 15, 2024, with early adoption permitted. The amendments should be applied retrospectively to all prior periods presented in the financial statements. The Company plans to adopt ASU 2023-07 in the fiscal first quarter of 2025. We are currently evaluating the impact of adopting this ASU on our consolidated financial statements and disclosures.


## us-gaap:EarningsPerShareTextBlock

[0001628280-24-003796:notes:22]
[same as prior period, unchanged from 0001628280-23-037591:notes:24]

[0001628280-24-003796:notes:23]
[same as prior period, unchanged from 0001628280-23-037591:notes:25]

[0001628280-24-003796:notes:24]
|  | Three Months Ended |  | Six Months Ended |
|  | December 30, 2023 |  | December 31, 2022 |  | December 30, 2023 |  | December 31, 2022 |
| Numerator: |  |  |  |  |  |  |  |
| Net loss - basic and diluted | $ | (99.1) |  |  | $ | (31.7) |  |  | $ | (167.0) |  |  | $ | (32.1) |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted average common shares outstanding - basic and diluted | 67.2 |  |  | 68.3 |  |  | 67.0 |  |  | 68.2 |  |
| Net loss per share: |  |  |  |  |  |  |  |
| Basic | $ | (1.47) |  |  | $ | (0.46) |  |  | $ | (2.49) |  |  | $ | (0.47) |  |
| Diluted | $ | (1.47) |  |  | $ | (0.46) |  |  | $ | (2.49) |  |  | $ | (0.47) |  |

[0001628280-24-003796:notes:25]
Shares from stock-based benefit plans and shares issuable assuming conversion of our convertible notes are anti-dilutive for the three and six months ended December 30, 2023 and December 31, 2022, respectively, and are therefore excluded from the calculation of diluted net loss per share as the Company had a net loss for both periods.

[0001628280-24-003796:notes:26]
Anti-dilutive shares excluded from the calculation of diluted net loss per share for the three months ended December 30, 2023 include 31.2 million shares related to convertible notes, 4.4 million shares issuable under restricted stock units (“RSUs”) and performance stock units (“PSUs”), 0.2 million shares issuable under the Employee Stock Purchase Plan (the “2015 Purchase Plan”), and 1.1 million shares outstanding related to stock options. Average anti-dilutive shares excluded from the calculation of diluted net loss per share for the six months ended December 30, 2023 include 31.2 million shares related to convertible notes, 4.5 million shares issuable under RSUs and PSUs, 0.2 million shares issuable under the 2015 Purchase Plan, and 1.1 million shares outstanding related to stock options. Refer to “Note 13. Equity.”

[0001628280-24-003796:notes:27]
Anti-dilutive shares excluded from the calculation of diluted net loss per share for the the three months ended December 31, 2022 include 24.5 million shares related to convertible notes, 3.8 million shares issuable under RSUs and PSUs, and 0.2 million shares issuable under the 2015 Purchase Plan. Average anti-dilutive shares excluded from the calculation of diluted net loss per share for the six months ended December 31, 2022 include 24.5 million shares related to convertible notes, 3.9 million shares issuable under RSUs and PSUs, and 0.1 million shares issuable under the 2015 Purchase Plan. 
Potentially dilutive common shares issuable upon conversion of our outstanding convertible notes are determined using the if-converted method.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001628280-24-003796:notes:28]
[same as prior period, unchanged from 0001628280-23-037591:notes:29]

[0001628280-24-003796:notes:29]
Cloud Light Acquisition

[0001628280-24-003796:notes:30]
On October 29, 2023, we entered into a definitive merger agreement (the “Merger Agreement”) with Cloud Light. On November 7, 2023 (the “Closing date”), we completed the acquisition of Cloud Light. Cloud Light designs, markets, and manufactures advanced optical modules for data center interconnect applications. The acquisition enables us to be well-positioned to serve the growing needs of cloud & networking customers, particularly those customers focused on optimizing their data center infrastructure for the demands of AI/ML.

[0001628280-24-003796:notes:31]
We have applied the acquisition method of accounting in accordance with ASC 805 Business Combinations, with respect to the fair value of purchase price consideration and the identifiable assets and liabilities of Cloud Light, which have been measured at estimated fair value as of the Closing date. The following tables summarize the preliminary purchase price consideration (in millions):

[0001628280-24-003796:notes:32]
|  | Fair Value |
| Cash consideration (1) | $ | 705.0 |  |
| Share-based consideration (2) | 23.5 |  |
| Total purchase price consideration | $ | 728.5 |  |

[0001628280-24-003796:notes:33]
(1) Under the terms of the Merger Agreement, Cloud Light stockholders received $1.69 per share after adjusting for applicable withholding taxes, escrow fund and expense fund contributions, for each of the 409.4 million of shares outstanding at the Closing date. As a result, we transferred $691.7 million of cash consideration on the Closing date. Additionally, each of Cloud Light’s outstanding options was exchanged for a combination of up-front cash consideration and newly issued options (the “replacement options”). As a result, we transferred $13.3 million of cash consideration on the Closing date.

[0001628280-24-003796:notes:34]
(2) The  replacement options have a total fair value of $38.9 million as of the Closing date, of which $23.5 million attributed to pre-acquisition service is recorded as part of the purchase price consideration and the remaining $15.4 million is recorded as post-acquisition stock-based compensation expense over the vesting period of three years from the acquisition Closing date. In general, these options expire within 10 years from the acquisition Closing date. Refer to “Note 13. Equity”.

[0001628280-24-003796:notes:35]
The cash consideration of $705.0 million, which was funded by the cash balances of Lumentum, includes $75.8 million of cash held in an escrow fund for a period of 12 months following the Closing date to support Cloud Light’s indemnification obligations under the Merger Agreement. The consideration is subject to customary adjustment for working capital.

[0001628280-24-003796:notes:36]
We also incurred a total of $9.2 million of merger-related costs, representing professional and other direct acquisition costs, of which $2.4 million was incurred during the fiscal first quarter of 2024 and $6.8 million was incurred during the fiscal second quarter of 2024. Merger related costs are recorded as selling, general and administrative expense in the consolidated statement of operations when incurred.

[0001628280-24-003796:notes:37]
We allocated the fair value of the purchase price consideration to the assets acquired and liabilities assumed as of the Closing date based on their estimated fair values. The excess of purchase price consideration over the fair value of net assets acquired is recorded as goodwill. Our preliminary allocation of the purchase price consideration to the assets acquired and liabilities assumed as of the Closing date is as follows (in millions):

[0001628280-24-003796:notes:38]
|  | Fair Value |
| Total purchase price consideration | $ | 728.5 |  |
| Assets acquired |  |
| Cash and cash equivalents | 4.1 |  |
| Short-term investments | 1.0 |  |
| Accounts receivable, net | 20.9 |  |
| Inventories | 71.5 |  |
| Prepayments and other current assets | 14.3 |  |
| Property, plant and equipment, net | 63.2 |  |
| Operating lease right-of-use assets, net | 3.7 |  |
| Other intangible assets, net (1) | 333.0 |  |
| Other non-current assets | 0.3 |  |
| Total assets | 512.0 |  |
| Liabilities assumed |  |
| Accounts payable | 45.8 |  |
| Accrued payroll and related expenses | 5.9 |  |
| Accrued expenses | 9.8 |  |
| Operating lease liabilities, current | 1.8 |  |
| Other current liabilities | 8.0 |  |
| Operating lease liabilities, non-current | 1.9 |  |
| Deferred tax liability | 60.7 |  |
| Other non-current liabilities | 9.1 |  |
| Total liabilities | 143.0 |  |
| Goodwill | $ | 359.5 |  |

[0001628280-24-003796:notes:39]
(1) Other intangible assets include developed technology of $170.0 million, customer relationship of $130.0 million, in-process research and development (“IPR&D”) of $16.0 million, order backlog of $14.0 million, and trade name and trademarks of $3.0 million. Refer to “Note 8. Goodwill and Other Intangible Assets” for more information.

[0001628280-24-003796:notes:40]
The allocation of the purchase price to the assets acquired and liabilities assumed, including the residual amount allocated to goodwill, is based upon preliminary information and subject to change. The primary areas of the preliminary purchase price allocation that are not yet finalized relate to the working capital adjustments pursuant to the Merger Agreement, the fair value of inventories, property, plant and equipment, intangible assets, deferred tax assets and liabilities, and contingent liabilities, if any. Further adjustments may result before the end of the measurement period, which ends one year from the Closing date. During the measurement period, if new information is obtained about facts and circumstances that existed as of the Closing date that, if known, would have resulted in revised estimated values of assets acquired and liabilities assumed, we will revise the preliminary purchase price allocation. The effect of measurement period adjustments to the estimated fair values will be calculated as if the adjustments had been completed on the acquisition date. The impact of all changes that do not qualify as measurement period adjustments will be included in current period earnings.

[0001628280-24-003796:notes:41]
Goodwill from the Cloud Light acquisition has been assigned to the Cloud & Networking segment. The preliminary goodwill of $359.5 million arising from the acquisition is attributed to the expected revenue growth and synergies, including future cost efficiencies and other benefits that are expected to be generated by combining Lumentum and Cloud Light. None of the goodwill is expected to be deductible for local tax purposes. Refer to “Note 8. Goodwill and Other Intangible Assets.”

[0001628280-24-003796:notes:42]
From the Closing date, Cloud Light contributed $59.5 million of our consolidated net revenue for the three months ended December 30, 2023. Due to the continued integration of the combined businesses, as well as our corporate structure and the allocation of selling, general and administrative costs, it is impracticable to determine Cloud Light’s contribution to our earnings.

[0001628280-24-003796:notes:43]
[same as prior period, unchanged from 0001628280-23-037591:notes:38]

[0001628280-24-003796:notes:44]
The following supplemental pro forma information presents the combined results of operations for the three and six months ended December 30, 2023 and December 31, 2022, as if the acquisition was completed on July 3, 2022, the first day of the fiscal year 2023. The supplemental pro forma financial information presented below is not necessarily indicative of the financial position or results of operations that would have been realized if the acquisition had been completed on the date indicated. The supplemental pro forma financial information does not reflect synergies that might have been achieved, nor is it indicative of future operating results or financial position.

[0001628280-24-003796:notes:45]
The pro forma financial information includes adjustments for: (i) amortization expense that would have been recognized related to the acquired intangible assets, (ii) depreciation expense that would have been recognized related to the acquired property, plant, and equipment, (iii) amortization of inventory fair value adjustment, (iv) acquisition related costs, such as third party transaction costs and restructuring costs, (v) stock-based compensation expense and (vi) the estimated income tax effect on the pro forma adjustments.

[0001628280-24-003796:notes:46]
The supplemental pro forma financial information for the periods presented is as follows (in millions):

[0001628280-24-003796:notes:47]
|  | Three Months Ended |  | Six Months Ended |
|  | December 30, 2023 |  | December 31, 2022 |  | December 30, 2023 |  | December 31, 2022 |
| Net revenue | $ | 386.5 |  |  | $ | 553.2 |  |  | $ | 773.1 |  |  | $ | 1,113.4 |  |
| Net loss | $ | (96.3) |  |  | $ | (39.9) |  |  | $ | (159.9) |  |  | $ | (61.7) |  |

[0001628280-24-003796:notes:48]
NeoPhotonics Acquisition

[0001628280-24-003796:notes:49]
On November 3, 2021, we entered into an Agreement and Plan of Merger (the “Merger Agreement”) with NeoPhotonics and Neptune Merger Sub, Inc. On August 3, 2022, we completed the acquisition of NeoPhotonics through the consummation of the merger and, accordingly, we acquired all of the issued and outstanding common stock of NeoPhotonics with a total purchase price consideration of $934.4 million, which was funded by the cash balances of the combined company. The addition of NeoPhotonics expands our opportunity in some of the fastest growing markets for optical components used in cloud and telecom network infrastructure.

[0001628280-24-003796:notes:50]
We have applied the acquisition method of accounting in accordance with ASC Topic 805, Business Combinations to account for this transaction and recorded a goodwill of $315.3 million arising from the acquisition, which has been assigned to the Cloud & Networking segment. NeoPhotonics contributed $104.6 million and $177.4 million of our consolidated net revenue for the three and six months ended December 31, 2022, respectively. Due to the integration of the combined businesses, as well as our corporate structure and the allocation of selling, general and administrative costs, it is impracticable to determine NeoPhotonics’ contribution to our earnings. As of December 30, 2023, the operation of NeoPhotonics has been fully integrated to the combined business.

[0001628280-24-003796:notes:51]
We also recorded $28.7 million of merger-related costs, representing professional and other direct acquisition costs, of which $8.3 million was incurred in fiscal year 2022 and $20.4 million was incurred in fiscal year 2023, which was recorded as selling, general and administrative expense in the condensed consolidated statements of operations.

[0001628280-24-003796:notes:52]
The following supplemental pro forma information presents the combined results of operations for the three and six months ended December 31, 2022, as if the acquisition was completed at the first day of fiscal 2022. The supplemental pro forma financial information is not necessarily indicative of the financial position or results of operations that would have been realized if the acquisition had been completed on the date indicated. The supplemental pro forma financial information does not reflect synergies that might have been achieved, nor is it indicative of future operating results or financial position. The pro forma financial information includes adjustments for: (i) amortization expense that would have been recognized related to the acquired intangible assets, (ii) depreciation expense that would have been recognized related to the acquired property, plant, and equipment, (iii) amortization of inventory fair value adjustment, (iv) acquisition related costs, such as third party transaction costs and restructuring costs, (v) stock-based compensation expense and (vi) the estimated income tax effect on the pro forma adjustments.

[0001628280-24-003796:notes:53]
|  | December 31, 2022 |
|  | Three Months Ended |  | Six Months Ended |
| Net revenue | $ | 506.0 |  |  |  |  | $ | 1,036.7 |  |
| Net income (loss) | (25.8) |  |  |  |  | 6.6 |  |

[0001628280-24-003796:notes:54]
[same as prior period, unchanged from 0001628280-23-037591:notes:40]

[0001628280-24-003796:notes:55]
On August 15, 2022 (“IPG Closing date”), we completed a transaction to acquire IPG Photonics’ telecom transmission product lines (“IPG telecom transmission product lines”) that are used to develop and market products for use in telecommunications and datacenter infrastructure, including Digital Signal Processors (DSPs), ASICs and optical transceivers with a total purchase price of $55.9 million, which was paid in cash. This acquisition enables us to expand our business in the Cloud & Networking segment.

[0001628280-24-003796:notes:56]
We have applied the acquisition method of accounting in accordance with ASC Topic 805, Business Combinations to account for this transaction and recorded a goodwill of $10.9 million arising from the acquisition, which has been assigned to the Cloud & Networking segment. We recorded $2.0 million of merger-related costs, representing professional and other direct acquisition costs, of which $0.4 million was incurred in fiscal year 2022 and $1.6 million was incurred in fiscal year 2023, which was recorded as selling, general and administrative expense in the consolidated statements of operations.

[0001628280-24-003796:notes:57]
[same as prior period, unchanged from 0001628280-23-037591:notes:44]


## us-gaap:CashCashEquivalentsAndShortTermInvestmentsTextBlock

[0001628280-24-003796:notes:58]
[same as prior period, unchanged from 0001628280-23-037591:notes:45]

[0001628280-24-003796:notes:59]
[same as prior period, unchanged from 0001628280-23-037591:notes:46]

[0001628280-24-003796:notes:60]
|  | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| December 30, 2023: |  |  |  |  |  |  |  |
| Cash | $ | 235.2 |  |  | $ | — |  |  | $ | — |  |  | $ | 235.2 |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | 5.1 |  |  | — |  |  | — |  |  | 5.1 |  |
| Money market funds | 206.6 |  |  | — |  |  | — |  |  | 206.6 |  |
| U.S. Treasury securities | 22.4 |  |  | — |  |  | — |  |  | 22.4 |  |
| Total cash and cash equivalents | $ | 469.3 |  |  | $ | — |  |  | $ | — |  |  | $ | 469.3 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 13.8 |  |  | $ | — |  |  | $ | — |  |  | $ | 13.8 |  |
| Commercial paper | 43.8 |  |  | — |  |  | — |  |  | 43.8 |  |
| Corporate debt securities | 365.4 |  |  | 0.3 |  |  | (0.8) |  |  | 364.9 |  |
| Municipal bonds | 4.6 |  |  | — |  |  | — |  |  | 4.6 |  |
| U.S. Agency securities | 143.5 |  |  | 0.1 |  |  | (0.4) |  |  | 143.2 |  |
| U.S. Treasury securities | 184.9 |  |  | — |  |  | (0.5) |  |  | 184.4 |  |
| Total short-term investments | $ | 756.0 |  |  | $ | 0.4 |  |  | $ | (1.7) |  |  | $ | 754.7 |  |
| July 1, 2023: |  |  |  |  |  |  |  |
| Cash | $ | 254.3 |  |  | $ | — |  |  | $ | — |  |  | $ | 254.3 |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Money market funds | 276.1 |  |  | — |  |  | — |  |  | 276.1 |  |
| U.S. Agency securities | 4.0 |  |  | — |  |  | — |  |  | 4.0 |  |
| U.S. Treasury securities | 324.6 |  |  | — |  |  | — |  |  | 324.6 |  |
| Total cash and cash equivalents | $ | 859.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 859.0 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 16.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 16.5 |  |
| Commercial paper | 132.9 |  |  | — |  |  | (0.2) |  |  | 132.7 |  |
| Corporate debt securities | 472.7 |  |  | — |  |  | (3.9) |  |  | 468.8 |  |
| U.S. Agency securities | 207.9 |  |  | — |  |  | (1.7) |  |  | 206.2 |  |
| U.S. Treasury securities | 332.4 |  |  | — |  |  | (2.0) |  |  | 330.4 |  |
| Total short-term investments | $ | 1,162.4 |  |  | $ | — |  |  | $ | (7.8) |  |  | $ | 1,154.6 |  |

[0001628280-24-003796:notes:61]
[same as prior period, unchanged from 0001628280-23-037591:notes:48]

[0001628280-24-003796:notes:62]
We use the specific-identification method to determine any realized gains or losses from the sale of our short-term investments classified as available-for-sale. During the three and six months ended December 30, 2023 and December 31, 2022, we did not realize significant gains or losses on a gross level from the sale of our short-term investments classified as available-for-sale.

[0001628280-24-003796:notes:63]
During the three and six months ended December 30, 2023, our other income, net was $13.4 million, and $34.6 million, respectively, which includes interest and investment income on cash equivalents and short-term investments of $17.1 million and $38.8 million, respectively.

[0001628280-24-003796:notes:64]
During the three and six months ended December 31, 2022, our other income, net was $3.7 million and $17.5 million, respectively, which includes interest and investment income on cash equivalents and short-term investments of $7.7 million and $12.5 million, respectively.

[0001628280-24-003796:notes:65]
As of December 30, 2023 and July 1, 2023, we recorded interest receivables of $7.2 million and $6.7 million, respectively, in prepayments and other current assets within the condensed consolidated balance sheets. We did not recognize an allowance for credit losses against interest receivables in any of the periods presented, as there were no such losses.

[0001628280-24-003796:notes:66]
[same as prior period, unchanged from 0001628280-23-037591:notes:52]

[0001628280-24-003796:notes:67]
|  | Continuous Loss Position for More Than 12 Months |  | Continuous Loss Position for Less Than 12 Months |  | Gross Unrealized Losses |  |  |  |  |  |  |  |  |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  |  |  |  |  |  |  |  |  |
| December 30, 2023: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | 5.0 |  |  | $ | — |  |  | $ | 113.5 |  |  | $ | (0.4) |  |  | $ | (0.4) |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | — |  |  | 4.0 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | — |  |  | — |  |  | 25.0 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 40.8 |  |  | (0.1) |  |  | 231.3 |  |  | (0.7) |  |  | (0.8) |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 4.5 |  |  | — |  |  | 167.0 |  |  | (0.5) |  |  | (0.5) |  |  |  |  |  |  |  |  |  |
| Total | $ | 50.3 |  |  | $ | (0.1) |  |  | $ | 540.8 |  |  | $ | (1.6) |  |  | $ | (1.7) |  |  |  |  |  |  |  |  |  |
| July 1, 2023: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | 39.6 |  |  | $ | (0.4) |  |  | $ | 170.6 |  |  | $ | (1.3) |  |  | $ | (1.7) |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | — |  |  | 7.7 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | — |  |  | — |  |  | 128.5 |  |  | (0.2) |  |  | (0.2) |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 93.6 |  |  | (1.2) |  |  | 358.9 |  |  | (2.7) |  |  | (3.9) |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 50.8 |  |  | (0.6) |  |  | 221.4 |  |  | (1.4) |  |  | (2.0) |  |  |  |  |  |  |  |  |  |
| Total | $ | 184.0 |  |  | $ | (2.2) |  |  | $ | 887.1 |  |  | $ | (5.6) |  |  | $ | (7.8) |  |  |  |  |  |  |  |  |  |

[0001628280-24-003796:notes:68]
[same as prior period, unchanged from 0001628280-23-037591:notes:54]

[0001628280-24-003796:notes:69]
|  | December 30, 2023 |  | July 1, 2023 |
|  | Amortized Cost |  | Fair Value |  | Amortized Cost |  | Fair Value |
| Due in 1 year | $ | 534.2 |  |  | $ | 533.2 |  |  | $ | 762.9 |  |  | $ | 759.1 |  |
| Due in 1 year through 5 years | 221.8 |  |  | 221.5 |  |  | 399.5 |  |  | 395.5 |  |
| Total | $ | 756.0 |  |  | $ | 754.7 |  |  | $ | 1,162.4 |  |  | $ | 1,154.6 |  |

[0001628280-24-003796:notes:70]
[same as prior period, unchanged from 0001628280-23-037591:notes:56]


## us-gaap:FairValueDisclosuresTextBlock

[0001628280-24-003796:notes:71]
[same as prior period, unchanged from 0001628280-23-037591:notes:57]

[0001628280-24-003796:notes:72]
[same as prior period, unchanged from 0001628280-23-037591:notes:58]

[0001628280-24-003796:notes:73]
[same as prior period, unchanged from 0001628280-23-037591:notes:59]

[0001628280-24-003796:notes:74]
[same as prior period, unchanged from 0001628280-23-037591:notes:60]

[0001628280-24-003796:notes:75]
[same as prior period, unchanged from 0001628280-23-037591:notes:61]

[0001628280-24-003796:notes:76]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| December 30, 2023: (1) |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | — |  |  | $ | 5.1 |  |  | $ | — |  |  | $ | 5.1 |  |
| Money market funds | 206.6 |  |  | — |  |  | — |  |  | 206.6 |  |
| U.S. Treasury securities | 22.4 |  |  | — |  |  | — |  |  | 22.4 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | 13.8 |  |  | — |  |  | 13.8 |  |
| Commercial paper | — |  |  | 43.8 |  |  | — |  |  | 43.8 |  |
| Corporate debt securities | — |  |  | 364.9 |  |  | — |  |  | 364.9 |  |
| Municipal bonds | — |  |  | 4.6 |  |  | — |  |  | 4.6 |  |
| U.S. Agency securities | — |  |  | 143.2 |  |  | — |  |  | 143.2 |  |
| U.S. Treasury securities | 184.4 |  |  | — |  |  | — |  |  | 184.4 |  |
| Total assets | $ | 413.4 |  |  | $ | 575.4 |  |  | $ | — |  |  | $ | 988.8 |  |

[0001628280-24-003796:notes:77]
(1)  Excludes $235.2 million in cash held in our bank accounts as of December 30, 2023.

[0001628280-24-003796:notes:78]
[same as prior period, unchanged from 0001628280-23-037591:notes:64]

[0001628280-24-003796:notes:79]
[same as prior period, unchanged from 0001628280-23-037591:notes:65]

[0001628280-24-003796:notes:80]
[same as prior period, unchanged from 0001628280-23-037591:notes:66]

[0001628280-24-003796:notes:81]
[same as prior period, unchanged from 0001628280-23-037591:notes:67]

[0001628280-24-003796:notes:82]
[same as prior period, unchanged from 0001628280-23-037591:notes:68]

[0001628280-24-003796:notes:83]
|  | December 30, 2023 |  | July 1, 2023 |
|  | Carrying Amount |  | Estimated Fair Value |  | Carrying Amount |  | Estimated Fair Value |
| 2029 Notes | $ | 599.0 |  |  | $ | 601.9 |  |  | $ | 598.6 |  |  | $ | 625.2 |  |
| 2028 Notes | 856.2 |  |  | 681.3 |  |  | 855.5 |  |  | 677.8 |  |
| 2026 Notes | 1,046.5 |  |  | 935.3 |  |  | 1,045.9 |  |  | 933.2 |  |
| 2024 Notes | 319.7 |  |  | 325.9 |  |  | 311.6 |  |  | 345.2 |  |
|  | $ | 2,821.4 |  |  | $ | 2,544.4 |  |  | $ | 2,811.6 |  |  | $ | 2,581.4 |  |

[0001628280-24-003796:notes:84]
[same as prior period, unchanged from 0001628280-23-037591:notes:70]

[0001628280-24-003796:notes:85]
[same as prior period, unchanged from 0001628280-23-037591:notes:71]

[0001628280-24-003796:notes:86]
Management utilizes various valuation methods, including an income approach, a market approach and a cost approach, to estimate the fair value of intangibles and other long-lived assets. During the annual impairment testing performed in the fourth quarter of fiscal 2023, we concluded that there was no impairment of our intangible and other long-lived assets. We review our intangible and other long-lived assets for impairment at least annually in the fourth quarter of each fiscal year, absent any interim indicators of impairment. There were no indicators of impairment during the three and six months ended December 30, 2023.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001628280-24-003796:notes:87]
[same as prior period, unchanged from 0001628280-23-037591:notes:73]

[0001628280-24-003796:notes:88]
[same as prior period, unchanged from 0001628280-23-037591:notes:74]

[0001628280-24-003796:notes:89]
We did not have any allowance for credit losses other than our allowance for uncollectible accounts receivable. As of December 30, 2023 and July 1, 2023, the allowance for credit losses on our trade receivables was $0.2 million and less than $0.1 million, respectively.

[0001628280-24-003796:notes:90]
[same as prior period, unchanged from 0001628280-23-037591:notes:76]

[0001628280-24-003796:notes:91]
[same as prior period, unchanged from 0001628280-23-037591:notes:77]

[0001628280-24-003796:notes:92]
|  | December 30, 2023 |  | July 1, 2023 |
| Raw materials and purchased parts | $ | 206.6 |  |  | $ | 170.5 |  |
| Work in process | 117.4 |  |  | 103.2 |  |
| Finished goods | 147.7 |  |  | 134.9 |  |
| Inventories | $ | 471.7 |  |  | $ | 408.6 |  |

[0001628280-24-003796:notes:93]
The inventory balance as of December 30, 2023 includes $63.4 million inventory from the Cloud Light acquisition, net of amortization of fair value step-up of $3.1 million during the three months ended December 30, 2023.

[0001628280-24-003796:notes:94]
[same as prior period, unchanged from 0001628280-23-037591:notes:79]

[0001628280-24-003796:notes:95]
[same as prior period, unchanged from 0001628280-23-037591:notes:80]

[0001628280-24-003796:notes:96]
|  | December 30, 2023 |  | July 1, 2023 |
| Land | $ | 75.2 |  |  | $ | 63.5 |  |
| Buildings and improvements | 189.6 |  |  | 170.3 |  |
| Machinery and equipment | 733.3 |  |  | 657.9 |  |
| Computer equipment and software | 44.2 |  |  | 41.4 |  |
| Furniture and fixtures | 11.0 |  |  | 10.2 |  |
| Leasehold improvements | 44.7 |  |  | 49.6 |  |
| Construction in progress | 102.1 |  |  | 69.2 |  |
|  | 1,200.1 |  |  | 1,062.1 |  |
| Less: Accumulated depreciation | (617.8) |  |  | (572.6) |  |
| Property, plant and equipment, net | $ | 582.3 |  |  | $ | 489.5 |  |

[0001628280-24-003796:notes:97]
In connection with the Cloud Light acquisition, we assumed $63.2 million of property, plant and equipment, net.

[0001628280-24-003796:notes:98]
[same as prior period, unchanged from 0001628280-23-037591:notes:82]

[0001628280-24-003796:notes:99]
[same as prior period, unchanged from 0001628280-23-037591:notes:83]

[0001628280-24-003796:notes:100]
During the three and six months ended December 30, 2023, we recorded depreciation expense of $27.2 million and $55.4 million, respectively. During the three and six months ended December 31, 2022, we recorded depreciation expense of $26.4 million and $50.9 million, respectively.

[0001628280-24-003796:notes:101]
[same as prior period, unchanged from 0001628280-23-037591:notes:85]

[0001628280-24-003796:notes:102]
[same as prior period, unchanged from 0001628280-23-037591:notes:86]

[0001628280-24-003796:notes:103]
|  | December 30, 2023 |  | July 1, 2023 |
| Operating lease right-of-use assets | $ | 109.4 |  |  | $ | 116.5 |  |
| Less: accumulated amortization | (28.1) |  |  | (39.2) |  |
| Operating lease right-of-use assets, net | $ | 81.3 |  |  | $ | 77.3 |  |

[0001628280-24-003796:notes:104]
In connection with the Cloud Light acquisition, we acquired $3.7 million of right-of-use assets related to leases of real estate properties used as our manufacturing and office premises.  We accounted for these leases as operating leases and have the remaining lease term ranging from 1.5 to 2.6 years at the acquisition Closing date.

[0001628280-24-003796:notes:105]
In connection with the purchase of land and buildings in Caswell, United Kingdom in August 2023, we terminated our leases for the purchased buildings and recorded a $0.3 million of reduction in the carrying value of buildings purchased, as a result of derecognizing $4.8 million of net operating lease right-of-use asset, $2.4 million of operating lease liabilities, current, and $2.7 million of operating lease liabilities, non-current.

[0001628280-24-003796:notes:106]
[same as prior period, unchanged from 0001628280-23-037591:notes:89]

[0001628280-24-003796:notes:107]
[same as prior period, unchanged from 0001628280-23-037591:notes:90]

[0001628280-24-003796:notes:108]
|  | December 30, 2023 |  | July 1, 2023 |
| Restructuring accrual and related charges (1) | $ | 10.2 |  |  | $ | 5.0 |  |
| Warranty accrual (2) | 10.1 |  |  | 6.8 |  |
| Deferred revenue and customer deposits | 0.9 |  |  | 2.1 |  |
| Income tax payable (3) | 17.7 |  |  | 28.0 |  |
| Other current liabilities | 6.1 |  |  | 5.9 |  |
| Other current liabilities | $ | 45.0 |  |  | $ | 47.8 |  |

[0001628280-24-003796:notes:109]
[same as prior period, unchanged from 0001628280-23-037591:notes:92]

[0001628280-24-003796:notes:110]
(2) Refer to “Note 14. Commitments and Contingencies.”

[0001628280-24-003796:notes:111]
[same as prior period, unchanged from 0001628280-23-037591:notes:94]

[0001628280-24-003796:notes:112]
[same as prior period, unchanged from 0001628280-23-037591:notes:95]

[0001628280-24-003796:notes:113]
[same as prior period, unchanged from 0001628280-23-037591:notes:96]

[0001628280-24-003796:notes:114]
|  | December 30, 2023 |  | July 1, 2023 |
| Asset retirement obligations | $ | 7.6 |  |  | $ | 8.2 |  |
| Pension and related accruals (1) | 11.4 |  |  | 9.6 |  |
| Unrecognized tax benefit | 70.1 |  |  | 64.4 |  |
| Other non-current liabilities | 8.5 |  |  | 9.2 |  |
| Other non-current liabilities | $ | 97.6 |  |  | $ | 91.4 |  |

[0001628280-24-003796:notes:115]
(1) We have defined benefit pension plans in Japan, Switzerland, and Thailand. Pension and related accrual of $11.4 million as of December 30, 2023 represents the non-current portion of benefit obligation. Pension and related accrual of $9.6 million as of July 1, 2023 relates to $10.2 million of non-current portion of benefit obligation, offset by $0.6 million of funding for the pension plan in Switzerland. We typically re-evaluate the assumptions related to the fair value of our defined benefit obligations annually in the fiscal fourth quarter and make any updates as necessary.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001628280-24-003796:notes:116]
[same as prior period, unchanged from 0001628280-23-037591:notes:99]

[0001628280-24-003796:notes:117]
[same as prior period, unchanged from 0001628280-23-037591:notes:100]

[0001628280-24-003796:notes:118]
In November 2023, we completed the acquisition of Cloud Light.  As of the acquisition date, we recognized preliminary goodwill of $359.5 million, which was allocated to the Cloud & Networking segment.

[0001628280-24-003796:notes:119]
The following table presents goodwill by reportable segments as of December 30, 2023 and July 1, 2023 (in millions):

[0001628280-24-003796:notes:120]
|  | Cloud & Networking |  | Industrial Tech |  | Total |
| Balances as of July 1, 2023 | $ | 683.9 |  |  | $ | 11.2 |  |  | $ | 695.1 |  |
| Acquisition of Cloud Light | 359.5 |  |  | — |  |  | 359.5 |  |
| Balance as of December 30, 2023 | $ | 1,043.4 |  |  | $ | 11.2 |  |  | $ | 1,054.6 |  |

[0001628280-24-003796:notes:121]
[same as prior period, unchanged from 0001628280-23-037591:notes:104]

[0001628280-24-003796:notes:122]
We review goodwill for impairment during the fourth quarter of each fiscal year or more frequently if events or circumstances indicate that an impairment loss may have occurred. In the fourth quarter of fiscal 2023, we completed the annual impairment test of goodwill, which indicated there was no goodwill impairment. There were no indicators of goodwill impairment during the three and six months ended December 30, 2023.

[0001628280-24-003796:notes:123]
[same as prior period, unchanged from 0001628280-23-037591:notes:106]

[0001628280-24-003796:notes:124]
Our intangible assets are amortized on a straight-line basis over the estimated useful lives, except for certain customer relationships, which are amortized using an accelerated method of amortization over the expected customer lives, more accurately reflecting the pattern of realization of economic benefits we expect to derive. Acquired developed technologies are amortized to cost of sales and research and development expenses. Acquired customer relationships are amortized to selling, general and administrative expenses in the consolidated statement of operations.

[0001628280-24-003796:notes:125]
In-process research and development (“IPR&D”) is initially capitalized at fair value as an intangible asset with an indefinite life and assessed for impairment thereafter. When an IPR&D project is completed, the IPR&D is reclassified to an amortizable purchased intangible asset and amortized over the asset’s estimated useful life.

[0001628280-24-003796:notes:126]
During the annual impairment testing performed in the fourth quarter of fiscal 2023, we concluded that our intangible and other long-lived assets were not impaired at the asset group level. We review our intangible and other long-lived assets for impairment at least annually in the fourth quarter of each fiscal year, absent any interim indicators of impairment. There were no indicators of impairment at the asset group level during the three and six months ended December 30, 2023.

[0001628280-24-003796:notes:127]
In November 2023, we completed the acquisition of Cloud Light. The intangible assets acquired from the acquisition were as follows as of the acquisition date (in millions, except for weighted average amortization period):

[0001628280-24-003796:notes:128]
|  | Fair Value at the Acquisition Date |  | Weighted Average Amortization Period(Years) |
| Acquired developed technologies | $ | 170.0 |  |  | 7.0 |
| Customer relationships | 130.0 |  |  | 7.0 |
| In-process research and development | 16.0 |  |  | n/a |
| Order backlog | 14.0 |  |  | 1.0 |
| Trade name and trademarks | 3.0 |  |  | 1.2 |
| Total intangible assets | $ | 333.0 |  |  |  |

[0001628280-24-003796:notes:129]
In August 2022, we completed the NeoPhotonics acquisition and the acquisition of IPG telecom transmission product lines. The intangible assets acquired from the acquisitions were as follows as of the acquisition date (in millions, except for weighted average amortization period):

[0001628280-24-003796:notes:130]
|  | Fair Value at the Acquisition Date |  | Weighted Average Amortization Period(Years) |
|  | NeoPhotonics |  | IPG Telecom Transmission Product Lines |  | Total Acquired |  |
| Acquired developed technologies | $ | 220.0 |  |  | $ | 8.6 |  |  | $ | 228.6 |  |  | 5.2 |
| Customer relationships | 144.5 |  |  | 2.3 |  |  | 146.8 |  |  | 5.9 |
| In-process research and development | 48.0 |  |  | 29.1 |  |  | 77.1 |  |  | n/a |
| Total intangible assets | $ | 412.5 |  |  | $ | 40.0 |  |  | $ | 452.5 |  |  |  |

[0001628280-24-003796:notes:131]
Refer to “Note 4. Business Combinations” for the acquisitions of Cloud Light, NeoPhotonics and IPG telecom transmission product lines.

[0001628280-24-003796:notes:132]
The following tables present details of all of our intangible assets as of the periods presented (in millions, except for weighted average remaining amortization period):

[0001628280-24-003796:notes:133]
| December 30, 2023 | Gross Carrying Amounts |  | Accumulated Amortization |  | Net Carrying Amounts |  | Weighted Average Remaining Amortization Period (Years) |
| Acquired developed technologies | $ | 807.8 |  |  | $ | (426.8) |  |  | $ | 381.0 |  |  | 5.1 |
| Customer relationships | 419.8 |  |  | (139.7) |  |  | 280.1 |  |  | 2.8 |
| In-process research and development | 54.9 |  |  | — |  |  | 54.9 |  |  | n/a |
| Order backlog | 14.0 |  |  | (2.0) |  |  | 12.0 |  |  | — |
| Trade name and trademarks | 3.0 |  |  | (0.4) |  |  | 2.6 |  |  | — |
| Total intangible assets | $ | 1,299.5 |  |  | $ | (568.9) |  |  | $ | 730.6 |  |  |  |

[0001628280-24-003796:notes:134]
[same as prior period, unchanged from 0001628280-23-037591:notes:114]

[0001628280-24-003796:notes:135]
[same as prior period, unchanged from 0001628280-23-037591:notes:115]

[0001628280-24-003796:notes:136]
|  | Three Months Ended |  | Six Months Ended |
|  | December 30, 2023 |  | December 31, 2022 |  | December 30, 2023 |  | December 31, 2022 |
| Cost of sales | $ | 21.5 |  |  | $ | 24.8 |  |  | $ | 39.5 |  |  | $ | 47.7 |  |
| Research and development | 0.4 |  |  | — |  |  | 0.7 |  |  | — |  |
| Selling, general and administrative | 15.7 |  |  | 11.3 |  |  | 26.4 |  |  | 20.6 |  |
| Total amortization of intangibles | $ | 37.6 |  |  | $ | 36.1 |  |  | $ | 66.6 |  |  | $ | 68.3 |  |

[0001628280-24-003796:notes:137]
Based on the carrying amount of our acquired developed technologies and customer relationships as of December 30, 2023, and assuming no future impairment of the underlying assets, the estimated future amortization is as follows (in millions):

[0001628280-24-003796:notes:138]
| Fiscal Years |  |
| Remainder of 2024 | $ | 83.8 |  |
| 2025 | 147.5 |  |
| 2026 | 131.5 |  |
| 2027 | 118.7 |  |
| 2028 | 80.5 |  |
| Thereafter | 113.7 |  |
| Total future amortization | $ | 675.7 |  |


## us-gaap:ScheduleOfFiniteLivedIntangibleAssetsTableTextBlock

[0001628280-24-003796:notes:139]
The intangible assets acquired from the acquisition were as follows as of the acquisition date (in millions, except for weighted average amortization period):

[0001628280-24-003796:notes:140]
The intangible assets acquired from the acquisitions were as follows as of the acquisition date (in millions, except for weighted average amortization period):


## us-gaap:DebtDisclosureTextBlock

[0001628280-24-003796:notes:141]
Note 9. Debt

[0001628280-24-003796:notes:142]
Convertible Notes

[0001628280-24-003796:notes:143]
2029 Notes

[0001628280-24-003796:notes:144]
On June 16, 2023, we issued $603.7 million in aggregate principal amount of 1.50% Convertible Senior Notes due in 2029 (“2029 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act of 1933, as amended. The 2029 Notes are governed by an indenture between the Company and U.S. Bank Trust Company National Association, (as successor in interest to U.S. Bank National Association), as a trustee (the “2029 Indenture”). The 2029 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001628280-24-003796:notes:145]
The net proceeds from the sale of the 2029 Notes was $599.4 million, after deducting $4.3 million of net issuance costs. In addition, we incurred $0.8 million of professional fees directly related to this transaction. Concurrent with the issuance of the 2029 Notes, we used $132.8 million of the net proceeds to repurchase $125.0 million aggregate principal amount of the 2024 Notes and $125.0 million of the net proceeds to repurchase our common stock in privately negotiated transactions. We intend to use the remaining net proceeds for general corporate purposes, which may include the repayment of our indebtedness, including any of our existing convertible notes, capital expenditures, working capital and potential acquisitions.

[0001628280-24-003796:notes:146]
The 2029 Notes bear interest at a rate of 1.50% per year, payable semi-annually in arrears on June 15 and December 15 of each year. The 2029 Notes will mature on December 15, 2029, unless earlier redeemed, repurchased by us, or converted pursuant to their terms.

[0001628280-24-003796:notes:147]
The initial conversion rate is 14.3808 shares of common stock per $1,000 principal amount of the 2029 Notes (which is equivalent to an initial conversion price of approximately $69.54 per share). The conversion rate is subject to adjustment upon the occurrence of certain events specified in the 2029 Indenture but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert the 2029 Notes in connection with such make-whole fundamental change or notice of redemption.

[0001628280-24-003796:notes:148]
Prior to the close of business on the business day immediately preceding September 15, 2029, holders of the 2029 Notes may convert their 2029 Notes only under the following circumstances:

[0001628280-24-003796:notes:149]
•during any fiscal quarter commencing after September 30, 2023 (and only during such fiscal quarter), if the last reported sale price of the common stock for at least 20 trading days (whether or not consecutive) during the period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% if the applicable conversion price on each applicable trading day;

[0001628280-24-003796:notes:150]
•during the five consecutive business day period after any five consecutive trading day period (the “2029 measurement period”) in which the trading price per $1,000 principal amount of 2029 Notes for each trading day of the 2029 measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate on each such trading day;

[0001628280-24-003796:notes:151]
•if we call any or all of the 2029 Notes for redemption, at any time prior to the close of business on the second business day immediately preceding the redemption date; or

[0001628280-24-003796:notes:152]
•upon the occurrence of specified corporate events as specified in the 2029 Indenture.

[0001628280-24-003796:notes:153]
On or after September 15, 2029 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their 2029 Notes at any time. Upon conversion, we will satisfy our conversion obligation in cash, shares of common stock or a combination of cash and shares of common stock, at our election.

[0001628280-24-003796:notes:154]
We may redeem for cash all or any portion of the 2029 Notes, at our option (subject to the partial redemption limitation set forth in the 2029 Indenture), on or after June 22, 2026, if the last reported sale price of our  common stock has been at least 130% of the conversion price then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading-day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which we provide notice of redemption at a redemption price equal to 100% of the principal amount of the 2029 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. No sinking fund is provided for the 2029 Notes. If we elect to redeem fewer than all of the outstanding 2029 Notes, at least $100.0 million aggregate principal amount of the 2029 Notes must be outstanding and not subject to redemption as of the redemption notice date. Upon the occurrence of a fundamental change (as defined in the 2029 Indenture), holders may require us to repurchase all or a portion of their 2029 Notes for cash at a price equal to 100% of the principal amount of the 2029 Notes to be repurchased, plus any accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

[0001628280-24-003796:notes:155]
The entire 2029 Notes are recorded as convertible notes, non-current in our consolidated balance sheets as of December 30, 2023 and July 1, 2023, measured at amortized cost.

[0001628280-24-003796:notes:156]
2028 Notes

[0001628280-24-003796:notes:157]
In March 2022, we issued $861.0 million in aggregate principal amount of 0.50% convertible senior notes due in 2028 (the “2028 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act of 1933, as amended (the “Securities Act”). The 2028 Notes are governed by an indenture between the Company and U.S. Bank Trust Company National Association (as successor in interest to U.S. Bank National Association), as trustee (the “2028 Indenture”). The 2028 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001628280-24-003796:notes:158]
The net proceeds from the sale of the 2028 Notes was $854.8 million, after deducting $6.2 million in issuance costs. In addition, we incurred $0.7 million in professional fees in connection with this transaction. Concurrent with the issuance of the 2028 Notes, we used $200.0 million of the net proceeds to repurchase our common stock in privately negotiated transactions.

[0001628280-24-003796:notes:159]
The 2028 Notes bear interest at a rate of 0.50% per year, payable semi-annually in arrears on June 15 and December 15 of each year, beginning on June 15, 2022. The 2028 Notes will mature on June 15, 2028, unless earlier redeemed, repurchased by us, or converted pursuant to their terms.

[0001628280-24-003796:notes:160]
The initial conversion rate is 7.6319 shares of common stock per $1,000 principal amount of the 2028 Notes (which is equivalent to an initial conversion price of approximately $131.03 per share). The conversion rate is subject to adjustment upon the occurrence of certain specified events, but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change (as defined in the 2028 Indenture) or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert the 2028 Notes in connection with such make-whole fundamental change or notice of redemption.

[0001628280-24-003796:notes:161]
Prior to the close of business on the business day immediately preceding March 15, 2028, holders of the 2028 Notes may convert their 2028 Notes only under the following circumstances:

[0001628280-24-003796:notes:162]
•during any fiscal quarter (and only during such fiscal quarter), if the last reported sale price of the Company’s common stock for at least 20 trading days (whether or not consecutive) during the 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price, or $170.34, on each applicable trading day;

[0001628280-24-003796:notes:163]
•during the five consecutive business day period after any five consecutive trading day period (the “measurement period”) in which the trading price per $1,000 principal amount of the 2028 Notes for each trading day of such measurement period was less than 98% of the product of the last reported sale price of the Company’s common stock and the applicable conversion rate on each such trading day;

[0001628280-24-003796:notes:164]
•if the Company calls any or all of the 2028 Notes for redemption, at any time prior to the close of business on the second business day immediately preceding the redemption date; or

[0001628280-24-003796:notes:165]
•upon the occurrence of specified corporate events, as specified in the 2028 Indentures.

[0001628280-24-003796:notes:166]
On or after March 15, 2028 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their 2028 Notes at any time. Upon conversion, we may satisfy our conversion obligation in cash, shares of common stock or a combination of cash and shares of common stock, at our election.

[0001628280-24-003796:notes:167]
We may redeem for cash all or any portion of the 2028 Notes, at our option (subject to the partial redemption limitation set forth in the 2028 Indenture), on or after June 20, 2025, if the last reported sale price of its common stock has been at least 130% of the conversion price then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading-day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which the Company provides notice of redemption at a redemption price equal to 100% of the principal amount of the 2028 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. No sinking fund is provided for the 2028 Notes. If we elect to redeem fewer than all of the outstanding 2028 Notes, at least $100.0 million aggregate principal amount of the 2028 Notes must be outstanding and not subject to redemption as of the redemption notice date. Upon the occurrence of a fundamental change (as defined in the 2028 Indenture), holders may require the Company to repurchase all or a portion of their 2028 Notes for cash at a price equal to 100% of the principal amount of the 2028 Notes to be repurchased, plus any accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

[0001628280-24-003796:notes:168]
We initially bifurcated the principal amount of the 2028 Notes into liability and equity components. The liability component of the 2028 Notes was initially valued at $629.8 million based on the contractual cash flow discounted at an appropriate comparable market on non-convertible debt borrowing rate at the date of issuance, which was 5.7%, with the equity component representing the residual amount of the proceeds of $231.2 million, which was recorded as a debt discount. Upon adoption of ASU 2020-06 in the first quarter of fiscal 2023, our 2028 Notes were accounted for as a single liability measured at amortized cost. The entire 2028 Notes are recorded as convertible notes, non-current in our consolidated balance sheets as of December 30, 2023 and July 1, 2023, measured at amortized cost.

[0001628280-24-003796:notes:169]
2026 Notes

[0001628280-24-003796:notes:170]
In December 2019, we issued $1,050.0 million in aggregate principal amount of 0.50% convertible senior notes due in 2026 (the “2026 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act. The 2026 Notes are governed by an indenture between the Company and U.S. Bank Trust Company National Association (as successor in interest to U.S. Bank National Association, as trustee (the “2026 Indenture”). We used approximately $196.0 million of the net proceeds of the offering to repay in full all amounts outstanding under our term loan credit facility, and a portion of the net proceeds of the offering to purchase approximately $200.0 million of our common stock concurrently with the pricing of the offering in privately negotiated transactions. The 2026 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001628280-24-003796:notes:171]
The 2026 Notes bear interest at a rate of 0.50% per year, payable semi-annually in arrears on June 15 and December 15 of each year. The 2026 Notes will mature on December 15, 2026, unless earlier redeemed, repurchased by us, or converted pursuant to their terms.

[0001628280-24-003796:notes:172]
The initial conversion rate is 10.0711 shares of common stock per $1,000 principal amount of the 2026 Notes (which is equivalent to an initial conversion price of approximately $99.29 per share). The conversion rate is subject to adjustment upon the occurrence of certain events specified in the 2026 Indenture, but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change (as defined in the 2026 Indenture) or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares set forth in the 2026 Indenture or a holder that elects to convert the 2026 Notes in connection with such make-whole fundamental change or notice of redemption.

[0001628280-24-003796:notes:173]
Prior to the close of business on the business day immediately preceding September 15, 2026, holders of the 2026 Notes may convert their 2026 Notes only under the following circumstances:

[0001628280-24-003796:notes:174]
•during any fiscal quarter (and only during such fiscal quarter), if the last reported sale price of the common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price of the 2026 Notes, or $129.08 on each applicable trading day;

[0001628280-24-003796:notes:175]
•during the five consecutive business day period after any five consecutive trading day period (the “2026 measurement period”) in which the trading price per $1,000 principal amount of the 2026 Notes for each trading day of the 2026 measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate for the 2026 Notes on each such trading day;

[0001628280-24-003796:notes:176]
•if we call any or all of the 2026 Notes for redemption, at any time prior to the close of business on the second business day immediately preceding the relevant redemption date; or

[0001628280-24-003796:notes:177]
•upon the occurrence of specified corporate events.

[0001628280-24-003796:notes:178]
On or after September 15, 2026 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their 2026 Notes at any time. Upon conversion, we may satisfy our conversion obligation in cash, shares of common stock or a combination of cash and shares of common stock, at our election.

[0001628280-24-003796:notes:179]
We may redeem for cash, all or any portion of the 2026 Notes, at our option, on or after December 20, 2023, if the last reported sale price of its common stock has been at least 130% of the conversion price then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading-day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which we provide a notice of redemption at a redemption price equal to 100% of the principal amount of the 2026 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. No sinking fund is provided for the 2026 Notes. Upon the occurrence of a fundamental change (as defined in the 2026 Indenture), holders may require us to repurchase all or a portion of the 2026 Notes for cash at a price equal to 100% of the principal amount of the 2026 Notes to be repurchased, plus any accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

[0001628280-24-003796:notes:180]
We initially bifurcated the principal amount of the 2026 Notes into liability and equity components. The liability component of the 2026 Notes was initially valued at $734.8 million based on the contractual cash flows discounted at an appropriate comparable market non-convertible debt borrowing rate at the date of issuance of 5.8% with the equity component representing the residual amount of the proceeds of $315.2 million, which was recorded as a debt discount. Upon adoption of ASU 2020-06 in the first quarter of fiscal 2023, our 2026 Notes were accounted for as a single liability measured at amortized cost. The entire 2026 Notes are recorded as convertible notes, non-current in our consolidated balance sheets as of December 30, 2023 and July 1, 2023, measured at amortized cost.

[0001628280-24-003796:notes:181]
2024 Notes

[0001628280-24-003796:notes:182]
In March 2017, we issued $450.0 million in aggregate principal amount of 0.25% convertible senior notes due in 2024 (the “2024 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act. The 2024 Notes are governed by an indenture between the Company, as the issuer, and U.S. Bank Trust Company National Association (as successor in interest to U.S. Bank National Association), as trustee (the “2024 Indenture”). The 2024 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001628280-24-003796:notes:183]
The 2024 Notes bear interest at a rate of 0.25% per year. Interest on the 2024 Notes is payable semi-annually in arrears on March 15 and September 15 of each year. The 2024 Notes will mature on March 15, 2024, unless earlier repurchased by us or converted pursuant to their terms.

[0001628280-24-003796:notes:184]
The initial conversion rate of the 2024 Notes is 16.4965 shares of common stock per $1,000 principal amount of 2024 Notes, which is equivalent to an initial conversion price of approximately $60.62 per share. The conversion rate is subject to adjustment upon the occurrence of certain specified events but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change (as defined in the 2024 Indenture) or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert the 2024 Notes in connection with such make-whole fundamental change or notice of redemption.

[0001628280-24-003796:notes:185]
Prior to the close of business on the business day immediately preceding December 15, 2023, each holder of the 2024 Notes was able to convert their 2024 Notes only under the following circumstances:

[0001628280-24-003796:notes:186]
•during any fiscal quarter (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during the period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price, or $78.80 on each applicable trading day;

[0001628280-24-003796:notes:187]
•during the five consecutive business day period after any five consecutive trading day period (the “2024 measurement period”) in which the trading price per $1,000 principal amount of 2024 Notes for each trading day of such 2024 measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate for the 2024 Notes on each such trading day; or

[0001628280-24-003796:notes:188]
On or after December 15, 2023 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their 2024 Notes at any time. In addition, upon the occurrence of a make-whole fundamental change (as defined in the 2024 Indenture), we will, in certain circumstances, increase the conversion rate by a number of additional shares set forth in the 2024 Indenture for a holder that elects to convert 2024 Notes in connection with such make-whole fundamental change.

[0001628280-24-003796:notes:189]
We may not redeem the 2024 Notes prior to their maturity date and no sinking fund is provided for the 2024 Notes. Upon the occurrence of a fundamental change (as defined in the 2024 Indenture), holders may require us to repurchase all or a portion of their 2024 Notes for cash at a price equal to 100% of the principal amount of the 2024 Notes to be repurchased, plus any accrued and unpaid interest.

[0001628280-24-003796:notes:190]
We considered the features embedded in the 2024 Notes other than the conversion feature, including the holders’ put feature, our call feature, and the make-whole feature, and concluded that they are not required to be bifurcated and accounted for separately from the host debt instrument.

[0001628280-24-003796:notes:191]
Prior to the Tax Matters Agreement settlement condition (“TMA settlement condition”), because we could only settle the 2024 Notes in cash, we determined that the conversion feature met the definition of a derivative liability. We separated the derivative liability from the host debt instrument based on the fair value of the derivative liability. As of the issuance date, March 8, 2017, the derivative liability fair value of $129.9 million was calculated using the binomial valuation approach. The residual principal amount of the 2024 Notes of $320.1 million before issuance costs was allocated to the debt component. We incurred approximately $7.7 million in transaction costs in connection with the issuance of the 2024 Notes. These costs were allocated to the debt component and recognized as a debt discount. We amortize the debt discount, including both the initial value of the derivative liability and the transaction costs, over the term of the 2024 Notes using the effective interest method. The effective interest rate of the 2024 Notes is 5.4% per year.

[0001628280-24-003796:notes:192]
During fiscal 2017, we satisfied the TMA settlement condition. As such, the value of the conversion option is no longer marked-to-market and was reclassified to additional paid-in capital within stockholders’ equity on our condensed consolidated balance sheets. The value of the conversion option at the time of issuance is treated as an original issue discount for purposes of accounting for the debt component of the 2024 Notes. The debt component will accrete up to the original amount over the expected term of the debt. The adoption of ASU 2020-06 did not change the presentation of the 2024 Notes, as the conversion feature associated with the 2024 Notes continues to be classified within stockholders’ equity.

[0001628280-24-003796:notes:193]
Concurrent with the issuance of the 2029 Notes in June 2023, we used $132.8 million of the net proceeds to repurchase $125.0 million aggregate principal amount of the 2024 Notes, which we accounted for as an extinguishment of liability. $13.5 million of the $132.8 million repurchase price was allocated to the conversion feature of the repurchased 2024 Notes, representing the fair value of the conversion feature at the date of the repurchase, and was recognized as a reduction of the stockholders’ equity. Additionally, since issuing the 2024 Notes, we have converted a total of approximately $1.9 million principal amount of the 2024 Notes. The remaining principal amount was $323.1 million as of December 30, 2023 and July 1, 2023, recorded as convertible notes, current in our consolidated balance sheets, as the 2024 Notes will mature on March 15, 2024.

[0001628280-24-003796:notes:194]
Convertible Notes - Additional Disclosures

[0001628280-24-003796:notes:195]
Our convertible notes consisted of the following components as of the periods presented (in millions):

[0001628280-24-003796:notes:196]
| December 30, 2023 | 2024 Notes (1) |  | 2026 Notes (2) |  | 2028 Notes (3) |  | 2029 Notes (4) |  | Total |  |  |  |  |  |
| Principal | $ | 323.1 |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |  | $ | 603.7 |  |  | $ | 2,837.8 |  |  |  |  |  |  |
| Unamortized debt discount and debt issuance costs | (3.4) |  |  | (3.5) |  |  | (4.8) |  |  | (4.7) |  |  | (16.4) |  |  |  |  |  |  |
| Net carrying amount of the liability component | $ | 319.7 |  |  | $ | 1,046.5 |  |  | $ | 856.2 |  |  | $ | 599.0 |  |  | $ | 2,821.4 |  |  |  |  |  |  |

[0001628280-24-003796:notes:197]
| July 1, 2023 | 2024 Notes (1) |  | 2026 Notes (2) |  | 2028 Notes (3) |  | 2029 Notes (4) |  | Total |
| Principal | $ | 323.1 |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |  | $ | 603.7 |  |  | $ | 2,837.8 |  |
| Unamortized debt discount and debt issuance costs | (11.5) |  |  | (4.1) |  |  | (5.5) |  |  | (5.1) |  |  | (26.2) |  |
| Net carrying amount of the liability component | $ | 311.6 |  |  | $ | 1,045.9 |  |  | $ | 855.5 |  |  | $ | 598.6 |  |  | $ | 2,811.6 |  |

[0001628280-24-003796:notes:198]
(1) If the closing price of our stock exceeds $78.80 (or 130% of the conversion price of $60.62) for 20 of the last 30 trading days of any future fiscal quarter, our 2024 Notes would become convertible at the option of the holders during the next fiscal quarter. The 2024 Notes are classified as current liabilities as the debt will mature on March 15, 2024.

[0001628280-24-003796:notes:199]
(2) If the closing price of our stock exceeds $129.08 (or 130% of the conversion price of $99.29) for 20 of the last 30 trading days of any future fiscal quarter, our 2026 Notes would become convertible at the option of the holders during the subsequent fiscal quarter and the debt would be reclassified to current liabilities in our condensed consolidated balance sheet.

[0001628280-24-003796:notes:200]
(3) If the closing price of our stock exceeds $170.34 (or 130% of the conversion price of $131.03) for 20 of the last 30 trading days of any future fiscal quarter, our 2028 Notes would become convertible at the option of the holders during the subsequent fiscal quarter and the debt would be reclassified to current liabilities in our condensed consolidated balance sheet.

[0001628280-24-003796:notes:201]
(4) If the closing price of our stock exceeds $90.40 (or 130% of the conversion price of $69.54) for 20 of the last 30 trading days of any future quarter, the 2029 Notes would become convertible at the option of the holders during the subsequent fiscal quarter and the debt would be reclassified to current liabilities in our consolidated balance sheets.

[0001628280-24-003796:notes:202]
The following table sets forth interest expense information related to the convertible notes for the periods presented (in millions):

[0001628280-24-003796:notes:203]
|  | Three Months Ended |  | Six Months Ended |
|  | December 30, 2023 |  | December 31, 2022 |  | December 30, 2023 |  | December 31, 2022 |
| Contractual interest expense | $ | 4.9 |  |  | $ | 2.7 |  |  | $ | 9.7 |  |  | $ | 5.4 |  |
| Amortization of the debt discount and debt issuance costs | 4.8 |  |  | 6.2 |  |  | 9.7 |  |  | 11.9 |  |
| Total interest expense | $ | 9.7 |  |  | $ | 8.9 |  |  | $ | 19.4 |  |  | $ | 17.3 |  |

[0001628280-24-003796:notes:204]
The future interest and principal payments related to our convertible notes are as follows as of December 30, 2023 (in millions):

[0001628280-24-003796:notes:205]
| Fiscal Years | 2024 Notes |  | 2026 Notes |  | 2028 Notes |  | 2029 Notes |  | Total |
| 2024 | $ | 323.7 |  |  | $ | 2.6 |  |  | $ | 2.2 |  |  | $ | 4.5 |  |  | $ | 333.0 |  |
| 2025 | — |  |  | 5.3 |  |  | 4.3 |  |  | 9.1 |  |  | 18.7 |  |
| 2026 | — |  |  | 5.3 |  |  | 4.3 |  |  | 9.1 |  |  | 18.7 |  |
| 2027 | — |  |  | 1,052.5 |  |  | 4.3 |  |  | 9.1 |  |  | 1,065.9 |  |
| 2028 | — |  |  | — |  |  | 865.3 |  |  | 9.1 |  |  | 874.4 |  |
| Thereafter | — |  |  | — |  |  | — |  |  | 617.1 |  |  | 617.1 |  |
| Total payments | $ | 323.7 |  |  | $ | 1,065.7 |  |  | $ | 880.4 |  |  | $ | 658.0 |  |  | $ | 2,927.8 |  |

[0001628280-24-003796:notes:206]
The principal balances of our convertible notes are reflected in the payment periods in the table above based on their respective contractual maturities.

[0001628280-24-003796:notes:207]
Mitsubishi Bank Loans

[0001628280-24-003796:notes:208]
In connection with the NeoPhotonics acquisition, we assumed several loan agreements with MUFG Bank, Ltd. (the “Mitsubishi Bank Loans”) for an aggregate fair value of approximately $5.9 million, approximately $0.9 million of which was paid in the fiscal first quarter of 2023 and the remaining balance of approximately $5.0 million was fully paid in the fiscal second quarter of 2023.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001628280-24-003796:notes:209]
[same as prior period, unchanged from 0001628280-23-037591:notes:187]

[0001628280-24-003796:notes:210]
[same as prior period, unchanged from 0001628280-23-037591:notes:188]

[0001628280-24-003796:notes:211]
[same as prior period, unchanged from 0001628280-23-037591:notes:189]

[0001628280-24-003796:notes:212]
|  | Foreign Currency Translation Adjustments, Net of Tax (1) |  | Defined Benefit Obligations, Net of Tax (2) |  | Unrealized Gain (Loss) on Available-for-Sale Securities, Net of Tax (3) |  |  |  | Total |
| Beginning balance as of July 1, 2023 | $ | 10.4 |  |  | $ | (0.4) |  |  | $ | (5.9) |  |  |  |  | $ | 4.1 |  |
| Other comprehensive gain (loss), net | (0.2) |  |  | — |  |  | 1.3 |  |  |  |  | 1.1 |  |
| Ending balance as of September 30, 2023 | $ | 10.2 |  |  | $ | (0.4) |  |  | $ | (4.6) |  |  |  |  | $ | 5.2 |  |
| Other comprehensive gain, net | 0.2 |  |  | — |  |  | 3.8 |  |  |  |  | 4.0 |  |
| Ending balance as of December 30, 2023 | $ | 10.4 |  |  | $ | (0.4) |  |  | $ | (0.8) |  |  |  |  | $ | 9.2 |  |
|  | Foreign Currency Translation Adjustments, Net of Tax (1) |  | Defined Benefit Obligations, Net of Tax (2) |  | Unrealized Gain (Loss) on Available-for-Sale Securities, Net of Tax (3) |  |  |  | Total |
| Beginning balance as of July 2, 2022 | $ | 9.7 |  |  | $ | 1.0 |  |  | $ | (10.3) |  |  |  |  | $ | 0.4 |  |
| Other comprehensive loss, net | — |  |  | — |  |  | (0.6) |  |  |  |  | (0.6) |  |
| Ending balance as of October 1, 2022 | $ | 9.7 |  |  | $ | 1.0 |  |  | $ | (10.9) |  |  |  |  | $ | (0.2) |  |
| Other comprehensive gain, net | — |  |  | — |  |  | 3.6 |  |  |  |  | 3.6 |  |
| Ending balance as of December 31, 2022 | $ | 9.7 |  |  | $ | 1.0 |  |  | $ | (7.3) |  |  |  |  | $ | 3.4 |  |

[0001628280-24-003796:notes:213]
(1) In fiscal 2019, we established the functional currency for our worldwide operations as the U.S. dollar. Translation adjustments reported prior to December 10, 2018 remain as a component of accumulated other comprehensive income (loss) in our condensed consolidated balance sheets, until all or a part of the investment in the subsidiaries is sold or liquidated. In fiscal 2023, we acquired IPG telecom transmission product lines. The functional currency of the Brazilian entities acquired as part of this acquisition is the local currency. During the three months ended December 30, 2023, we recorded foreign currency translation adjustments of $0.2 million.

[0001628280-24-003796:notes:214]
[same as prior period, unchanged from 0001628280-23-037591:notes:192]

[0001628280-24-003796:notes:215]
(3) For the three and six months ended December 30, 2023, our unrealized loss on available-for-sale securities is presented net of tax of  $1.0 million and $1.4 million, respectively. For the three and six months ended December 31, 2022, our unrealized loss on available-for-sale securities is presented net of tax of  $1.0 million and $0.8 million, respectively.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001628280-24-003796:notes:216]
[same as prior period, unchanged from 0001628280-23-037591:notes:194]

[0001628280-24-003796:notes:217]
We have initiated various strategic restructuring actions primarily to reduce costs, consolidate our operations, rationalize the manufacturing of our products and align our business in response to market conditions and as a result of our acquisitions.

[0001628280-24-003796:notes:218]
[same as prior period, unchanged from 0001628280-23-037591:notes:196]

[0001628280-24-003796:notes:219]
|  | Three Months Ended |  | Six Months Ended |
|  | December 30, 2023 |  | December 31, 2022 |  | December 30, 2023 |  | December 31, 2022 |
| Balance as of beginning of period | $ | 9.3 |  |  | $ | 3.1 |  |  | $ | 5.0 |  |  | $ | — |  |
| Charges | 5.8 |  |  | 13.9 |  |  | 16.8 |  |  | 23.2 |  |
| Payments | (4.9) |  |  | (2.9) |  |  | (11.6) |  |  | (9.1) |  |
| Balance as of end of period | $ | 10.2 |  |  | $ | 14.1 |  |  | $ | 10.2 |  |  | $ | 14.1 |  |

[0001628280-24-003796:notes:220]
During the three and six months ended December 30, 2023, we recorded restructuring and related charges of $5.8 million and $16.8 million, respectively, primarily due to company-wide cost reduction initiatives, as well as our integration efforts as a result of the NeoPhotonics acquisition in August 2022.

[0001628280-24-003796:notes:221]
During the three months ended December 31, 2022, we recorded restructuring and related charges of $13.9 million, primarily due to our integration efforts as a result of the NeoPhotonics acquisition, as well as company-wide cost reduction initiatives. During the six months ended December 31, 2022, we recorded restructuring and related charges of $23.2 million, primarily due to our integration efforts as a result of the NeoPhotonics acquisition, company-wide cost reduction initiatives, as well as severance and employee-related benefits associated with NeoPhotonics’ executive severance and retention agreements. These agreements provide for payments and benefits upon an involuntary termination of employment under certain circumstances.

[0001628280-24-003796:notes:222]
[same as prior period, unchanged from 0001628280-23-037591:notes:200]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-24-003796:notes:223]
[same as prior period, unchanged from 0001628280-23-037591:notes:201]

[0001628280-24-003796:notes:224]
[same as prior period, unchanged from 0001628280-23-037591:notes:202]

[0001628280-24-003796:notes:225]
We recorded a tax benefit of $2.4 million  and $3.8 million for the three and six months ended December 30, 2023, respectively. Our tax benefit for the three months ended December 30, 2023 includes a discrete tax expense of $3.4 million , primarily related to a shortfall in connection with stock-based compensation vested during the quarter, interest on uncertain tax positions and currency re-measurements. Our tax benefit for the six months ended December 30, 2023 includes a discrete tax expense of $1.6 million, primarily related to a shortfall in connection with stock-based compensation vested during the quarter, foreign return to provision differences and interest on unrecognized tax positions, partially offset by the tax benefit from changes in prior year uncertain tax positions.

[0001628280-24-003796:notes:226]
We recorded a tax provision of $4.6 million and $23.8 million for the three and six months ended December 31, 2022, respectively. Our tax provision for the three months ended December 31, 2022 includes a discrete tax expense of $4.0 million primarily related to the U.S. return to provision differences for transaction costs, currency re-measurements. Our tax provision for the six months ended December 31, 2022 includes a discrete tax expense of $17.1 million, primarily related to the international restructuring, currency re-measurements and U.S. return to provision differences for transaction costs, partially offset by the tax benefit from tax rate changes.

[0001628280-24-003796:notes:227]
Our estimated effective tax rate for fiscal 2024 differs from the 21% U.S. statutory rate primarily due to the income tax expense from foreign rate differential, non-deductible stock-based compensation and foreign  inclusions in the U.S., partially offset by the income tax benefit from various income tax credits.

[0001628280-24-003796:notes:228]
As of December 30, 2023, we had $70.1 million of unrecognized tax benefits, which, if recognized, would affect the effective tax rate. We are subject to examination of income tax returns by various domestic and foreign tax authorities. The timing of resolution and closure of these tax examinations is highly unpredictable. Although it is possible that certain ongoing tax examinations may be concluded within the next 12 months, we cannot reasonably estimate the impact to tax expense and net income from tax examinations that could be resolved or closed within the next 12 months. Subject to audit timing and uncertainty, we expect the amount of unrecognized tax benefit that would become recognized due to expiration of the statute of limitations and affect the effective tax rate to decrease by $2.1 million over the next 12 months.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001628280-24-003796:notes:229]
[same as prior period, unchanged from 0001628280-23-037591:notes:206]

[0001628280-24-003796:notes:230]
Description of Lumentum Stock-Based Compensation Plans

[0001628280-24-003796:notes:231]
[same as prior period, unchanged from 0001628280-23-037591:notes:208]

[0001628280-24-003796:notes:232]
On November 28, 2023, our board of directors authorized 1.5 million shares of common stock reserved for issuance in connection with the adoption of the Cloud Light Share Option Scheme as a result of the Cloud Light acquisition.

[0001628280-24-003796:notes:233]
On November 17, 2023, our stockholders approved amendments to the Amended and Restated Equity Incentive Plan (the “2015 Plan”) to increase the number of shares of common stock reserved for issuance by an additional 3.0 million shares.

[0001628280-24-003796:notes:234]
As of December 30, 2023, we had 5.5 million shares subject to stock options, restricted stock units, restricted stock awards, and performance stock units issued and outstanding under the 2015 Plan. Restricted stock units, restricted stock awards, and performance stock units are performance-based, time-based or a combination of both and are expected to vest within four years. The fair value of these grants is based on the closing market price of our common stock on the date of grant. The exercise price for stock options is equal to the fair value of the underlying stock at the date of grant. We issue new shares of common stock upon exercise of stock options. Options generally have vesting period of three years. As of December 30, 2023, 3.8 million shares of common stock under the 2015 Plan were available for grant.

[0001628280-24-003796:notes:235]
Stock Options

[0001628280-24-003796:notes:236]
In connection with the acquisition of Cloud Light, each of Cloud Light’s outstanding options was exchanged for a combination of cash and options to acquire Lumentum common stock having equivalent value (the “replacement options”) using an exchange ratio of 0.04375 according to the terms in the Merger Agreement. At the acquisition Closing date, the replacement options consisted of 1.1 million options with a weighted average grant date fair value of $34.63. These replacement options have a total fair value of $38.9 million as of the Closing date, of which $23.5 million attributed to pre-acquisition service was recorded as part of purchase price consideration and the remaining $15.4 million will be recorded as post-acquisition stock-based compensation expense over the vesting period of three years from the acquisition Closing date. Refer to “Note 4. Business Combinations.”

[0001628280-24-003796:notes:237]
We estimate the fair value of the replacement options on the date of grant using the Black-Scholes option-pricing model. The assumptions used to estimate the fair value of the replacement options are as follows:

[0001628280-24-003796:notes:238]
|  | At the Acquisition Date |
| Expected terms (years) | 3.0 |
| Expected volatility | 45.0 | % |
| Risk-free interest rate | 5.0 | % |
| Dividend yield | — | % |

[0001628280-24-003796:notes:239]
[same as prior period, unchanged from 0001628280-23-037591:notes:213]

[0001628280-24-003796:notes:240]
Restricted stock units (“RSUs”) under the 2015 Plan are grants of shares of our common stock, the vesting of which is based on the requisite service requirement. Generally, our RSUs are subject to forfeiture and are expected to vest within four years. For annual grants to existing employees, RSUs generally vest ratably on an annual basis, or combination of annual and quarterly basis, over three years.

[0001628280-24-003796:notes:241]
During the six months ended December 30, 2023, our board of directors approved grants of 1.9 million RSUs, which primarily vest over three years.

[0001628280-24-003796:notes:242]
In connection with the NeoPhotonics acquisition, we issued equity awards to certain NeoPhotonics employees, consisting of restricted stock units (the “replacement awards”) in exchange for their NeoPhotonics equity awards. The terms of these replacement awards are substantially similar to the original NeoPhotonics equity awards. The replacement awards consisted of 0.4 million restricted stock units with a grant date fair value of $93.4 per share, which represents our closing stock price on August 3, 2022, the acquisition closing date. The total fair value of these replacement awards is $40.2 million, $3.5 million of which is attributable to employee services rendered through the acquisition Closing date and was recognized as a component of the purchase consideration. The remaining $36.7 million of the replacement awards is recorded as stock-based compensation over the remaining vesting period. Refer to “Note 4. Business Combinations.”

[0001628280-24-003796:notes:243]
[same as prior period, unchanged from 0001628280-23-037591:notes:216]

[0001628280-24-003796:notes:244]
[same as prior period, unchanged from 0001628280-23-037591:notes:217]

[0001628280-24-003796:notes:245]
During the six months ended December 30, 2023, our board of directors approved a grant of 0.3 million PSUs with an aggregate grant date fair value of $16.0 million to executive and non-executive employees as part of our revised Annual Incentive Plan. These PSUs are subject to performance targets and service conditions, with a vesting period of one year. The board of directors also approved a grant of 0.4 million PSUs with an aggregate grant date fair value of $19.3 million to certain executive officers and senior management. These PSUs will vest subject to the achievement of revenue targets and certain non-financial performance measurements, as well as service conditions, over three years.

[0001628280-24-003796:notes:246]
[same as prior period, unchanged from 0001628280-23-037591:notes:219]

[0001628280-24-003796:notes:247]
Our 2015 Purchase Plan provides eligible employees with the opportunity to acquire an ownership interest in the Company through periodic payroll deductions and provides a 15% purchase price discount as well as a 6-month look-back period. The 2015 Purchase Plan is structured as a qualified employee stock purchase plan under Section 423 of the Internal Revenue Code of 1986, as amended. The 2015 Purchase Plan will terminate upon the date on which all shares available for issuance have been sold. Of the 3.0 million shares authorized under the 2015 Purchase Plan, 0.9 million shares remained available for issuance as of December 30, 2023.

[0001628280-24-003796:notes:248]
[same as prior period, unchanged from 0001628280-23-037591:notes:221]

[0001628280-24-003796:notes:249]
[same as prior period, unchanged from 0001628280-23-037591:notes:222]

[0001628280-24-003796:notes:250]
|  | Three Months Ended |  | Six Months Ended |
|  | December 30, 2023 |  | December 31, 2022 |  | December 30, 2023 |  | December 31, 2022 |
| Cost of sales | $ | 9.0 |  |  | $ | 6.7 |  |  | $ | 15.0 |  |  | $ | 12.2 |  |
| Research and development | 10.0 |  |  | 10.6 |  |  | 20.3 |  |  | 20.2 |  |
| Selling, general and administrative | 15.6 |  |  | 19.3 |  |  | 31.4 |  |  | 50.8 |  |
| Total stock-based compensation | $ | 34.6 |  |  | $ | 36.6 |  |  | $ | 66.7 |  |  | $ | 83.2 |  |

[0001628280-24-003796:notes:251]
Stock-based compensation for the six months ended December 31, 2022 includes $11.9 million of expenses related to the acceleration of certain equity awards in connection with the NeoPhotonics acquisition.

[0001628280-24-003796:notes:252]
During the three months ended December 30, 2023, we recorded $0.2 million of net reversal of stock-based compensation related to PSUs due to decline in the anticipated achievement of performance conditions. During the six months ended December 30, 2023, we recorded $4.5 million of stock-based compensation related to PSUs. During the three and six months ended December 31, 2022, we recorded $6.2 million and $15.0 million of stock-based compensation related to PSUs, respectively. The amount of stock-based compensation expense recognized in any one period related to PSUs can vary based on the achievement or anticipated achievement of the performance conditions. If the performance conditions are not met or not expected to be met, no compensation cost would be recognized on the underlying PSUs, and any previously recognized compensation expense related to those PSUs would be reversed.

[0001628280-24-003796:notes:253]
[same as prior period, unchanged from 0001628280-23-037591:notes:226]

[0001628280-24-003796:notes:254]
|  | Three Months Ended |  | Six Months Ended |
|  | December 30, 2023 |  | December 31, 2022 |  | December 30, 2023 |  | December 31, 2022 |
| Income tax benefit associated with stock-based compensation | $ | 0.6 |  |  | $ | 6.4 |  |  | $ | 2.5 |  |  | $ | 11.5 |  |

[0001628280-24-003796:notes:255]
Approximately $16.8 million and $14.2 million of stock-based compensation was capitalized to inventory as of December 30, 2023 and July 1, 2023, respectively.

[0001628280-24-003796:notes:256]
As of December 30, 2023, $187.3 million of stock-based compensation cost related to RSU awards remains to be amortized, which is expected to be recognized over an estimated amortization period of 2.1 years.

[0001628280-24-003796:notes:257]
[same as prior period, unchanged from 0001628280-23-037591:notes:230]

[0001628280-24-003796:notes:258]
The following table summarizes our award activities for the six months ended December 30, 2023 (in millions):

[0001628280-24-003796:notes:259]
|  | Stock Options |  | Restricted Stock Units |  | Performance Stock Units |  |  |  |  |
|  | Number of Shares |  | Weighted-Average Exercise Price per Share |  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |  |  |  |  |
| Balance as of July 1, 2023 | — |  |  | $ | — |  |  | 2.6 |  |  | $ | 85.0 |  |  | 0.6 |  |  | $ | 89.1 |  |  |  |  |  |
| Replacement options in connection with Cloud Light acquisition | 1.1 |  |  | 34.6 |  |  | — |  |  | — |  |  | — |  |  | — |  |  |  |  |  |
| Granted | — |  |  | — |  |  | 1.9 |  |  | 52.6 |  |  | 0.7 |  |  | 53.2 |  |  |  |  |  |
| Vested/Exercised (1) | — |  |  | 8.0 |  |  | (1.0) |  |  | 87.4 |  |  | (0.1) |  |  | 89.5 |  |  |  |  |  |
| Canceled | — |  |  | — |  |  | (0.2) |  |  | 78.5 |  |  | (0.1) |  |  | 88.9 |  |  |  |  |  |
| Balance as of December 30, 2023 | 1.1 |  |  | $ | 34.6 |  |  | 3.3 |  |  | $ | 66.2 |  |  | 1.1 |  |  | $ | 65.9 |  |  |  |  |  |

[0001628280-24-003796:notes:260]
(1) Vested/exercised number of shares related to stock options is less than 0.1 million.

[0001628280-24-003796:notes:261]
[same as prior period, unchanged from 0001628280-23-037591:notes:233]

[0001628280-24-003796:notes:262]
|  | Awards Available for Grant |
| Balance as of July 1, 2023 | 2.7 |  |
| Authorized in connection with Cloud Light acquisition | 1.5 |  |
| Replacement options in connection with Cloud Light acquisition | (1.1) |  |
| Authorized | 3.0 |  |
| Granted | (2.6) |  |
| Canceled | 0.3 |  |
| Balance as of December 30, 2023 | 3.8 |  |

[0001628280-24-003796:notes:263]
[same as prior period, unchanged from 0001628280-23-037591:notes:235]

[0001628280-24-003796:notes:264]
The 2015 Purchase Plan expense for the three and six months ended December 30, 2023 was $1.0 million and $2.2 million, respectively. The 2015 Purchase Plan expense for the three and six months ended December 31, 2022 was $0.8 million and $2.0 million, respectively. The expense related to the 2015 Purchase Plan is recorded on a straight-line basis over the relevant subscription period.

[0001628280-24-003796:notes:265]
During the six months ended December 30, 2023, there were 0.2 million shares issued to employees through the 2015 Purchase Plan. During the six months ended December 31, 2022, there were 0.1 million shares issued to employees through the 2015 Purchase Plan.

[0001628280-24-003796:notes:266]
[same as prior period, unchanged from 0001628280-23-037591:notes:238]

[0001628280-24-003796:notes:267]
[same as prior period, unchanged from 0001628280-23-037591:notes:239]

[0001628280-24-003796:notes:268]
We have a share buyback program that authorizes us to utilize up to an aggregate amount of $1.2 billion to purchase our own shares of common stock through May 2025. During the six months ended December 30, 2023, we did not repurchase any shares of our common stock. During the six months ended December 31, 2022, we repurchased 0.3 million shares of our common stock at an average price of $89.80 per share for an aggregate purchase price of $25.7 million. Since the board of directors initially approved the share buyback program, we have repurchased 7.7 million shares in aggregate at an average price of $81.66 per share for a total purchase price of $630.4 million. We recorded the $630.4 million aggregate purchase price as a reduction of retained earnings within our condensed consolidated balance sheet and immediately retired all repurchased shares. As of December 30, 2023, we have $569.6 million remaining under the share buyback program.

[0001628280-24-003796:notes:269]
[same as prior period, unchanged from 0001628280-23-037591:notes:241]


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0001628280-24-003796:notes:270]
Note 14. Commitments and Contingencies

[0001628280-24-003796:notes:271]
Purchase Obligations

[0001628280-24-003796:notes:272]
Our purchase obligations of $423.8 million as of December 30, 2023 represent legally binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule and adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

[0001628280-24-003796:notes:273]
We depend on a limited number of contract manufacturers, subcontractors and suppliers for raw materials, packages and standard components. We generally purchase these single or limited source products through standard purchase orders or one-year supply agreements and have no significant long-term guaranteed supply agreements with these vendors. While we seek to maintain a sufficient safety stock of such products and maintain on-going communications with our suppliers to guard against interruptions or cessation of supply, our business and results of operations could be adversely affected by a stoppage or delay of supply, substitution of more expensive or less reliable products, receipt of defective parts or contaminated materials, increases in the price of such supplies, or our inability to obtain reduced pricing from our suppliers in response to competitive pressures.

[0001628280-24-003796:notes:274]
Product Warranties

[0001628280-24-003796:notes:275]
We provide reserves for the estimated costs of product warranties at the time revenue is recognized. We typically offer a twelve-month warranty for most of our products. However, in some instances depending upon the product, product components or application of our products by the end customer, our warranties can vary and generally range from six months to five years. We estimate the costs of our warranty obligations on an annualized basis based on our historical experience of known product failure rates, use of materials to repair or replace defective products, and service delivery costs incurred in correcting product failures. In addition, from time-to-time, specific warranty accruals may be made if unforeseen technical problems arise with specific products. We assess the adequacy of our recorded warranty liabilities and adjust the amounts as necessary.

[0001628280-24-003796:notes:276]
The following table presents the changes in our warranty reserve for the periods presented (in millions):

[0001628280-24-003796:notes:277]
|  | Three Months Ended |  | Six Months Ended |
|  | December 30, 2023 |  | December 31, 2022 |  | December 30, 2023 |  | December 31, 2022 |
| Balance as of beginning of period | $ | 5.5 |  |  | $ | 10.1 |  |  | $ | 6.8 |  |  | $ | 10.0 |  |
| Warranty assumed from Cloud Light | 5.2 |  |  | — |  |  | 5.2 |  |  | — |  |
| Provision for warranty | 0.8 |  |  | 2.8 |  |  | 1.0 |  |  | 5.0 |  |
| Utilization of reserve, net | (1.4) |  |  | (4.5) |  |  | (2.9) |  |  | (6.6) |  |
| Balance as of end of period | $ | 10.1 |  |  | $ | 8.4 |  |  | $ | 10.1 |  |  | $ | 8.4 |  |

[0001628280-24-003796:notes:278]
Environmental Liabilities

[0001628280-24-003796:notes:279]
Our research and development, manufacturing and distribution operations involve the use of hazardous substances and are regulated under international, federal, state and local laws governing health and safety and the environment. We apply strict standards for protection of the environment and occupational health and safety to sites inside and outside the United States, even if not subject to regulations imposed by foreign governments. We believe that our properties and operations at our facilities comply in all material respects with applicable environmental laws and occupational health and safety laws. However, the risk of environmental liabilities cannot be completely eliminated and there can be no assurance that the application of environmental and health and safety laws will not require us to incur significant expenditures. We are also regulated under a number of international, federal, state and local laws regarding recycling, product packaging and product content requirements. The environmental and product content/disposal and recycling laws are gradually becoming more stringent and may cause us to incur significant expenditures in the future.

[0001628280-24-003796:notes:280]
Legal Proceedings

[0001628280-24-003796:notes:281]
We are subject to a variety of claims and suits that arise from time-to-time in the ordinary course of our business. While management currently believes that resolving claims against us, individually or in the aggregate, will not have a material adverse impact on our financial position, results of operations or statements of cash flows, these matters are subject to inherent uncertainties and management’s view of these matters may change in the future. We accrue for loss contingencies when it is both probable that we will incur the loss and when we can reasonably estimate the amount of the loss or range of loss. During the year ended July 1, 2023, we recorded $7.8 million with respect to the pending settlement of certain non-ordinary course litigation matters under accrued expenses in our consolidated balance sheet, which has not been settled as of December 30, 2023.

[0001628280-24-003796:notes:282]
Oclaro Merger Litigation

[0001628280-24-003796:notes:283]
In connection with our acquisition of Oclaro in 2018, seven lawsuits were filed by purported stockholders of Oclaro challenging the proposed merger (the “Merger”). All but one was voluntarily dismissed after the Oclaro Merger closed. The remaining lawsuit, SaiSravan B. Karri v. Oclaro, Inc., et al., No. 3:18-cv-03435-JD (the “Karri Lawsuit”), was filed in the United States District Court for the Northern District of California and is styled as a class action.

[0001628280-24-003796:notes:284]
The Karri Lawsuit alleges, among other things, that Oclaro and its directors violated Section 14(a) of the Securities Exchange Act of 1934, as amended (the “Exchange Act”), and Rule 14a-9 promulgated thereunder by disseminating an incomplete and misleading Form S-4, including proxy statement/prospectus. The Karri Lawsuit further alleged that Oclaro’s directors violated Section 20(a) of the Exchange Act by failing to exercise proper control over the person(s) who violated Section 14(a) of the Exchange Act. The plaintiff in the Karri Lawsuit seeks, among other things, damages to be awarded to the plaintiff and any class, if a class is certified, and litigation costs, including attorneys’ fees.

[0001628280-24-003796:notes:285]
After the plaintiff in the Karri Lawsuit was appointed as lead plaintiff and his counsel as lead counsel, the plaintiff filed a first amended complaint on April 15, 2019. The first amended complaint, also named Lumentum as a defendant but Lumentum has since been dismissed from the action. On October 8, 2020, the court granted in part and denied in part the defendant’s motion to dismiss the first amended complaint. On December 1, 2020, defendants answered the first amended complaint. On September 17, 2021, lead plaintiff filed a second amended complaint. Defendants moved to stay discovery in light of the second amended complaint. On January 11, 2022, the Court struck the second amended complaint as untimely, terminated defendants’ motions to dismiss as moot, and lifted the stay. The case proceeded through fact and expert discovery.

[0001628280-24-003796:notes:286]
On August 16, 2022, the lead plaintiff moved for class certification and to be appointed class representative. Defendants opposed the motion. The action subsequently was stayed while the parties participated in a mediation. On January 18, 2023, the lead plaintiff filed a Notice of Settlement informing the court of an agreement in principle between the parties for a class-wide settlement of the Karri Lawsuit. On January 24, 2023, in light of the potential settlement, the court vacated all pretrial and trial dates and ordered the lead plaintiff to file a motion for preliminary approval of the settlement by March 17, 2023. The lead plaintiff filed his motion for preliminary approval of the settlement on March 16, 2023, and defendants filed a statement of non-opposition on March 30, 2023. On April 20, 2023, the court held a hearing on lead plaintiff’s motion for preliminary approval of the settlement. The court declined to grant lead plaintiff’s motion for preliminary approval and ordered lead plaintiff to file a revised motion by May 22, 2023. Lead plaintiff filed his Revised Motion for Preliminary Approval of Settlement (the “Amended Motion”) on May 22, 2023, defendants filed a response in support of the Amended Motion on June 5, 2023, and the lead plaintiff submitted his reply on June 12, 2023. The hearing on the Amended Motion took place on August 17, 2023 and the court preliminarily approved the settlement. In the event that the settlement does not go forward for any reason, the defendants intend to continue to defend the Karri Lawsuit vigorously.

[0001628280-24-003796:notes:287]
Indemnifications

[0001628280-24-003796:notes:288]
In the normal course of business, we enter into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown, because claims may be made against us in the future, and we may record charges in the future as a result of these indemnification obligations. As of December 30, 2023, we did not have any material indemnification claims that were probable or reasonably possible.

[0001628280-24-003796:notes:289]
Audit Proceedings

[0001628280-24-003796:notes:290]
We are under audit by various domestic and foreign tax authorities with regards to income tax and indirect tax matters. In some, although not all cases, we have reserved for potential adjustments to our provision for income taxes and accrual of indirect taxes that may result from examinations by these tax authorities or final outcomes in judicial proceedings, and we believe that the final outcome of these examinations, agreements or judicial proceedings will not have a material effect on our results of operations. If events occur which indicate payment of these amounts is unnecessary, the reversal of the liabilities would result in the recognition of benefits in the period when we determine the liabilities are no longer necessary. If our estimates of the federal, state, and foreign income tax liabilities and indirect tax liabilities are less than the ultimate assessment, it could result in a further charge to expense.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001628280-24-003796:notes:291]
[same as prior period, unchanged from 0001628280-23-037591:notes:263]

[0001628280-24-003796:notes:292]
[same as prior period, unchanged from 0001628280-23-037591:notes:264]

[0001628280-24-003796:notes:293]
[same as prior period, unchanged from 0001628280-23-037591:notes:265]

[0001628280-24-003796:notes:294]
[same as prior period, unchanged from 0001628280-23-037591:notes:266]

[0001628280-24-003796:notes:295]
[same as prior period, unchanged from 0001628280-23-037591:notes:267]

[0001628280-24-003796:notes:296]
[same as prior period, unchanged from 0001628280-23-037591:notes:268]

[0001628280-24-003796:notes:297]
Our Cloud & Networking products include a wide range of components, modules, and subsystems to support customers including carrier networks for access (local), metro (intracity), long-haul (city-to-city and worldwide) and submarine (undersea) applications. Additionally, our products address enterprise, cloud, and data center applications, including SANs, LANs and WANs, as well as AI/ML. These products enable the transmission and transport of video, audio, and data over high-capacity fiber-optic cables. We maintain leading positions in these fast-growing cloud & networking markets through our extensive product portfolio, including reconfigurable optical add/drop multiplexers (“ROADMs”), coherent dense wavelength division multiplexing (“DWDM”) pluggable transceivers, and tunable small form-factor pluggable transceivers. We also sell laser chips for use in manufacturing of high-speed ethernet transceivers for use primarily inside data centers.

[0001628280-24-003796:notes:298]
[same as prior period, unchanged from 0001628280-23-037591:notes:270]

[0001628280-24-003796:notes:299]
Our Industrial Tech products include diode laser products such as VCSELs and edge emitting lasers. In the consumer end-market, our laser light sources are integrated into 3D sensing cameras which are used in applications in mobile devices, gaming, payment kiosks, computers, other consumer electronics devices, and automobiles. Applications include biometric identification, computational photography, virtual and augmented reality, and natural user interfaces. Emerging applications for our lasers include automotive safety systems, LiDAR for advanced driver assistance systems in automobiles and autonomous vehicles, self-navigating robotics and drones in industrial applications, and 3D capture of objects coupled with 3D imaging or printing. In the industrial end market, our diode lasers are used primarily as pump sources for pulsed and kilowatt class fiber lasers.

[0001628280-24-003796:notes:300]
[same as prior period, unchanged from 0001628280-23-037591:notes:272]

[0001628280-24-003796:notes:301]
[same as prior period, unchanged from 0001628280-23-037591:notes:273]

[0001628280-24-003796:notes:302]
[same as prior period, unchanged from 0001628280-23-037591:notes:274]

[0001628280-24-003796:notes:303]
|  | Three Months Ended |  | Six Months Ended |
|  | December 30, 2023 |  | December 31, 2022 |  | December 30, 2023 |  | December 31, 2022 |
| Net revenue: |  |  |  |  |  |  |  |
| Cloud & Networking | $ | 286.7 |  |  | $ | 382.9 |  |  | $ | 516.4 |  |  | $ | 743.0 |  |
| Industrial Tech | 80.1 |  |  | 123.1 |  |  | 168.0 |  |  | 269.8 |  |
| Net revenue | $ | 366.8 |  |  | $ | 506.0 |  |  | $ | 684.4 |  |  | $ | 1,012.8 |  |
| Segment profit: |  |  |  |  |  |  |  |
| Cloud & Networking | $ | 29.1 |  |  | $ | 99.9 |  |  | $ | 53.0 |  |  | $ | 201.6 |  |
| Industrial Tech | 12.7 |  |  | 49.7 |  |  | 28.0 |  |  | 118.5 |  |
| Total segment profit | 41.8 |  |  | 149.6 |  |  | 81.0 |  |  | 320.1 |  |
| Unallocated corporate items: |  |  |  |  |  |  |  |
| Selling, general and administrative (1) | (28.8) |  |  | (32.9) |  |  | (57.4) |  |  | (66.0) |  |
| Stock-based compensation | (34.6) |  |  | (36.6) |  |  | (66.7) |  |  | (71.3) |  |
| Stock-based compensation - acquisition related | — |  |  | — |  |  | — |  |  | (11.9) |  |
| Amortization of acquired intangibles | (37.6) |  |  | (36.1) |  |  | (66.6) |  |  | (68.3) |  |
| Amortization of acquired inventory fair value adjustments | (3.4) |  |  | (9.6) |  |  | (3.4) |  |  | (14.2) |  |
| Acquisition related costs | (9.0) |  |  | — |  |  | (13.0) |  |  | (16.2) |  |
| Integration related costs | (11.6) |  |  | (8.0) |  |  | (22.9) |  |  | (8.6) |  |
| Restructuring and related charges | (5.8) |  |  | (13.9) |  |  | (16.8) |  |  | (23.2) |  |
| Abnormal excess capacity | (1.8) |  |  | — |  |  | (1.8) |  |  | — |  |
| Litigation matters | — |  |  | (7.8) |  |  | — |  |  | (7.8) |  |
| Other charges, net (2) | (14.4) |  |  | (26.6) |  |  | (18.4) |  |  | (41.0) |  |
| Interest expense | (9.7) |  |  | (8.9) |  |  | (19.4) |  |  | (17.4) |  |
| Other income, net (3) | 13.4 |  |  | 3.7 |  |  | 34.6 |  |  | 17.5 |  |
| Consolidated loss before income taxes | $ | (101.5) |  |  | $ | (27.1) |  |  | $ | (170.8) |  |  | $ | (8.3) |  |

[0001628280-24-003796:notes:304]
[same as prior period, unchanged from 0001628280-23-037591:notes:276]

[0001628280-24-003796:notes:305]
(2)  Other charges, net for the three months ended December 30, 2023 primarily relate to $9.5 million of net excess and obsolete inventory, $4.6 million of non-recurring legal and tax related fees, and $1.0 million of incremental costs of sales related to components previously acquired from various brokers to satisfy customer demand. The excess and obsolete inventory charges relate to charges that are not attributable to our operating segments due to their unusual nature, primarily those charges driven by U.S. trade restrictions whereby we are no longer able to sell certain products to one of our customers.

[0001628280-24-003796:notes:306]
Other charges, net for the six months ended December 30, 2023 primarily relate to $9.2 million of net excess and obsolete inventory, $5.4 million of non-recurring legal and tax related fees, and $3.9 million of incremental costs of sales related to components previously acquired from various brokers to satisfy customer demand. The excess and obsolete inventory charges relate to charges that are not attributable to our operating segments due to their unusual nature, primarily those charges driven by U.S. trade restrictions whereby we are no longer able to sell certain products to one of our customers.

[0001628280-24-003796:notes:307]
Other charges, net for the three months ended December 31, 2022 primarily relate to $11.7 million of incremental costs of sales related to components previously acquired from various brokers to satisfy customer demand, $4.5 million of non-recurring charges on legal matters, and $5.4 million of excess and obsolete inventory charges primarily driven by U.S. trade restrictions.

[0001628280-24-003796:notes:308]
Other charges, net for the six months ended December 31, 2022 primarily relate to $19.0 million of incremental costs of sales related to components previously acquired from various brokers to satisfy customer demand, $4.5 million of non-recurring charges on legal matters, and $5.5 million of excess and obsolete inventory charges primarily driven by U.S. trade restrictions.

[0001628280-24-003796:notes:309]
(3) Other income, net for the three months ended December 30, 2023 includes interest and investment income of $17.1 million, offset by foreign exchange and other loss, net of $3.7 million. Other income, net for the six months ended December 30, 2023 includes interest and investment income of $38.8 million, offset by foreign exchange and other loss, net of $4.2 million.

[0001628280-24-003796:notes:310]
Other income, net for the three months ended December 31, 2022 primarily relates to $7.7 million of interest and investment income, offset by $4.1 million of net foreign exchange losses. Other income, net for the six months ended December 31, 2022 primarily relates to $12.5 million of interest and investment income and $4.9 million of net foreign exchange gains.

[0001628280-24-003796:notes:311]
[same as prior period, unchanged from 0001628280-23-037591:notes:279]

[0001628280-24-003796:notes:312]
[same as prior period, unchanged from 0001628280-23-037591:notes:280]

[0001628280-24-003796:notes:313]
[same as prior period, unchanged from 0001628280-23-037591:notes:281]

[0001628280-24-003796:notes:314]
|  | Three Months Ended |  | Six Months Ended |
|  | December 30, 2023 |  | December 31, 2022 |  | December 30, 2023 |  | December 31, 2022 |
|  | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States | $ | 103.0 |  |  | 28.1 | % |  | $ | 65.5 |  |  | 12.9 | % |  | $ | 144.1 |  |  | 21.0 | % |  | $ | 127.7 |  |  | 12.6 | % |
| Mexico | 31.4 |  |  | 8.6 |  |  | 59.5 |  |  | 11.8 |  |  | 55.1 |  |  | 8.1 |  |  | 117.0 |  |  | 11.6 |  |
| Other Americas | 0.8 |  |  | 0.2 |  |  | 3.8 |  |  | 0.8 |  |  | 2.0 |  |  | 0.3 |  |  | 6.1 |  |  | 0.6 |  |
| Total Americas | $ | 135.2 |  |  | 36.9 | % |  | $ | 128.8 |  |  | 25.5 | % |  | $ | 201.2 |  |  | 29.4 | % |  | $ | 250.8 |  |  | 24.8 | % |
| Asia-Pacific: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Hong Kong | $ | 65.7 |  |  | 17.9 | % |  | $ | 65.9 |  |  | 13.0 | % |  | $ | 130.6 |  |  | 19.1 | % |  | $ | 143.5 |  |  | 14.2 | % |
| South Korea | 20.8 |  |  | 5.7 |  |  | 52.0 |  |  | 10.3 |  |  | 45.8 |  |  | 6.7 |  |  | 119.7 |  |  | 11.8 |  |
| Japan | 25.9 |  |  | 7.1 |  |  | 50.8 |  |  | 10.0 |  |  | 51.3 |  |  | 7.5 |  |  | 95.6 |  |  | 9.4 |  |
| Thailand | 39.3 |  |  | 10.7 |  |  | 77.9 |  |  | 15.4 |  |  | 103.5 |  |  | 15.1 |  |  | 135.4 |  |  | 13.4 |  |
| Other Asia-Pacific | 49.5 |  |  | 13.4 |  |  | 84.7 |  |  | 16.7 |  |  | 89.0 |  |  | 13.0 |  |  | 173.6 |  |  | 17.1 |  |
| Total Asia-Pacific | $ | 201.2 |  |  | 54.8 | % |  | $ | 331.3 |  |  | 65.4 | % |  | $ | 420.2 |  |  | 61.4 | % |  | $ | 667.8 |  |  | 65.9 | % |
| EMEA | $ | 30.4 |  |  | 8.3 | % |  | $ | 45.9 |  |  | 9.1 | % |  | $ | 63.0 |  |  | 9.2 | % |  | $ | 94.2 |  |  | 9.3 | % |
| Total net revenue | $ | 366.8 |  |  | 100.0 | % |  | $ | 506.0 |  |  | 100.0 | % |  | $ | 684.4 |  |  | 100.0 | % |  | $ | 1,012.8 |  |  | 100.0 | % |

[0001628280-24-003796:notes:315]
During the three months ended December 30, 2023, our net revenue from a single customer that represented 10% or greater of the total net revenue was concentrated with three customers, who individually accounted for 19%, 13% and 11% of our total net revenue, respectively. During the six months ended December 30, 2023, our net revenue from a single customer that represented 10% or greater of the total net revenue was concentrated with three customers, who individually accounted for 14%, 12% and 12% of our total net revenue, respectively.

[0001628280-24-003796:notes:316]
During the three months ended December 31, 2022, our net revenue from a single customer that represented 10% or greater of the total net revenue was concentrated with two customers, who individually accounted for 19% and 12% of our total net revenue, respectively. During the six months ended December 31, 2022, our net revenue from a single customer that represented 10% or greater of the total net revenue was concentrated with two customers, who individually accounted for 18% and 15% of our total net revenue, respectively.

[0001628280-24-003796:notes:317]
As of December 30, 2023, our accounts receivable from a single customer that represented 10% or greater of the total accounts receivable was concentrated with one customer, who accounted for 20% of the total accounts receivable. As of July 1, 2023, our accounts receivable from a single customer that represented 10% or greater of the total accounts receivable was concentrated with three customers, who individually accounted for 14%, 12% and 12% of the total accounts receivable, respectively.

[0001628280-24-003796:notes:318]
[same as prior period, unchanged from 0001628280-23-037591:notes:285]

[0001628280-24-003796:notes:319]
|  | December 30, 2023 |  | July 1, 2023 |
| Property, plant and equipment, net |  |  |  |
| United States | $ | 136.1 |  |  | $ | 134.7 |  |
| Thailand | 134.3 |  |  | 132.0 |  |
| Japan | 84.3 |  |  | 93.0 |  |
| United Kingdom | 76.6 |  |  | 38.2 |  |
| China | 94.0 |  |  | 42.1 |  |
| Other countries | 57.0 |  |  | 49.5 |  |
| Total property, plant and equipment, net | $ | 582.3 |  |  | $ | 489.5 |  |

[0001628280-24-003796:notes:320]
We purchase a portion of our inventory from contract manufacturers and vendors located primarily in Taiwan, Thailand and Malaysia. During the three and six months ended December 30, 2023, our net inventory purchases from a single contract manufacturer that represented 10% or greater of our total net inventory purchases were concentrated with two contract manufacturers, who collectively accounted for 33% and 43% of the total net inventory purchases, respectively. During the three and six months ended December 31, 2022, our net inventory purchases from a single contract manufacturer, which represented 10% or greater of our total net inventory purchases, were concentrated with one and two contract manufacturers, who collectively accounted for 43% and 52% of total net inventory purchases, respectively.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001628280-24-003796:notes:321]
[same as prior period, unchanged from 0001628280-23-037591:notes:288]

[0001628280-24-003796:notes:322]
[same as prior period, unchanged from 0001628280-23-037591:notes:289]

[0001628280-24-003796:notes:323]
[same as prior period, unchanged from 0001628280-23-037591:notes:290]

[0001628280-24-003796:notes:324]
[same as prior period, unchanged from 0001628280-23-037591:notes:291]

[0001628280-24-003796:notes:325]
|  | Three Months Ended |  | Six Months Ended |
|  | December 30, 2023 |  | December 31, 2022 |  | December 30, 2023 |  | December 31, 2022 |
|  | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |
| Cloud & Networking | $ | 286.7 |  |  | 78.2 | % |  | $ | 382.9 |  |  | 75.7 | % |  | $ | 516.4 |  |  | 75.5 | % |  | $ | 743.0 |  |  | 73.4 | % |
| Industrial Tech | 80.1 |  |  | 21.8 | % |  | 123.1 |  |  | 24.3 | % |  | 168.0 |  |  | 24.5 | % |  | 269.8 |  |  | 26.6 | % |
| Net revenue | $ | 366.8 |  |  | 100.0 | % |  | $ | 506.0 |  |  | 100.0 | % |  | $ | 684.4 |  |  | 100.0 | % |  | $ | 1,012.8 |  |  | 100.0 | % |

[0001628280-24-003796:notes:326]
[same as prior period, unchanged from 0001628280-23-037591:notes:293]

[0001628280-24-003796:notes:327]
[same as prior period, unchanged from 0001628280-23-037591:notes:294]

[0001628280-24-003796:notes:328]
| Contract balances |  | Balance sheet location |  | December 30, 2023 |  | July 1, 2023 |  | Change |  | Percentage Change |
| Accounts receivable, net |  | Accounts receivable, net |  | $ | 248.3 |  |  | $ | 246.1 |  |  | $ | 2.2 |  |  | 0.9 | % |
| Deferred revenue and customer deposits |  | Other current liabilities |  | $ | 0.9 |  |  | $ | 2.1 |  |  | $ | (1.2) |  |  | (57.1) | % |
