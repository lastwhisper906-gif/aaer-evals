# LITE 8-K — 0001628280-24-003789 filed 2024-02-08

## item codes, every 8-K on or before 2024-02-08

- 2024-02-08 0001628280-24-003789 — 2.02, 9.01
- 2024-01-18 0001628280-24-001551 — 9.01 — amendment of 0001193125-23-272452
- 2023-11-21 0001628280-23-039654 — 5.02, 5.07
- 2023-11-08 0001628280-23-037563 — 2.02, 9.01
- 2023-11-07 0001193125-23-272452 — 2.01, 8.01, 9.01
- 2023-10-30 0001193125-23-265658 — 1.01, 2.02, 9.01
- 2023-08-17 0001628280-23-029741 — 2.02, 9.01
- 2023-06-16 0001193125-23-168966 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2023-05-09 0001628280-23-016629 — 2.02, 9.01
- 2023-04-06 0001628280-23-010935 — 2.02, 8.01, 9.01
- 2023-02-24 0001193125-23-048742 — 5.02, 9.01
- 2023-02-09 0001628280-23-002866 — 2.02, 9.01
- 2022-11-21 0001628280-22-030473 — 5.02, 5.07, 9.01
- 2022-11-08 0001628280-22-028758 — 2.02, 9.01
- 2022-08-16 0001628280-22-022980 — 2.02, 9.01
- 2022-08-03 0001193125-22-210674 — 2.01, 8.01, 9.01
- 2022-07-29 0001193125-22-206587 — 8.01, 9.01
- 2022-05-04 0001628280-22-012145 — 2.02, 9.01
- 2022-03-08 0001193125-22-069350 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2022-02-03 0001628280-22-001736 — 2.02, 9.01
- 2022-01-21 0001193125-22-014413 — 8.01, 9.01
- 2021-11-23 0001628280-21-024070 — 5.02, 5.07
- 2021-11-05 0001193125-21-321796 — 1.01, 9.01
- 2021-11-04 0001628280-21-021618 — 2.02, 9.01
- 2021-11-04 0001193125-21-319601 — 8.01, 9.01
- 2021-08-18 0001628280-21-017219 — 2.02, 9.01
- 2021-06-08 0001633978-21-000030 — 5.02, 9.01
- 2021-05-12 0001633978-21-000008 — 2.02, 9.01
- 2021-03-10 0001193125-21-075438 — 1.01, 8.01, 9.01
- 2021-02-02 0001633978-21-000002 — 2.02, 9.01
- 2021-01-19 0001104659-21-005024 — 1.01, 2.02, 8.01, 9.01
- 2020-11-24 0001193125-20-302557 — 5.02, 5.07
- 2020-11-02 0001633978-20-000017 — 2.02, 9.01
- 2020-09-18 0001633978-20-000012 — 5.02, 9.01
- 2020-08-11 0001633978-20-000010 — 2.02, 9.01
- 2020-05-05 0001628280-20-006358 — 2.02, 9.01
- 2020-02-04 0001633978-20-000002 — 2.02, 9.01
- 2019-12-12 0001193125-19-312875 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2019-12-04 0001633978-19-000075 — 8.01
- 2019-11-20 0001633978-19-000074 — 5.07
- 2019-10-31 0001633978-19-000070 — 2.02, 9.01
- 2019-08-08 0001633978-19-000068 — 2.02, 9.01
- 2019-05-08 0001633978-19-000031 — 1.01
- 2019-05-07 0001633978-19-000029 — 2.02, 9.01
- 2019-02-15 0001633978-19-000005 — 9.01 — amendment of 0001193125-18-346211
- 2019-02-08 0001193125-19-031591 — 5.02, 9.01
- 2019-02-05 0001633978-19-000001 — 2.02, 9.01
- 2018-12-10 0001193125-18-346211 — 1.01, 2.01, 2.03, 5.02, 8.01, 9.01
- 2018-12-06 0001633978-18-000150 — 8.01
- 2018-11-14 0001633978-18-000139 — 5.07
- 2018-11-13 0001633978-18-000136 — 3.02
- 2018-11-13 0001633978-18-000132 — 7.01, 9.01
- 2018-11-01 0001628280-18-013238 — 2.02, 9.01
- 2018-08-08 0001633978-18-000056 — 2.02, 9.01
- 2018-06-08 0001193125-18-188241 — 5.02, 9.01
- 2018-05-02 0001633978-18-000029 — 2.02, 9.01
- 2018-03-12 0001193125-18-078154 — 1.01, 2.01, 8.01, 9.01
- 2018-02-06 0001628280-18-001082 — 2.02, 9.01
- 2017-11-08 0001633978-17-000133 — 5.02, 9.01
- 2017-11-07 0001633978-17-000131 — 5.07
- 2017-11-01 0001633978-17-000117 — 2.02, 9.01
- 2017-08-09 0001633978-17-000058 — 2.02, 9.01
- 2017-05-04 0001633978-17-000035 — 2.02, 9.01
- 2017-03-08 0001193125-17-074740 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2017-03-02 0001193125-17-066769 — 8.01, 9.01
- 2017-02-07 0001633978-17-000005 — 2.02, 9.01
- 2017-01-03 0001628280-17-000018 — 4.01, 9.01
- 2016-11-09 0001628280-16-021143 — 5.02, 5.07, 9.01
- 2016-10-27 0001628280-16-020382 — 2.02, 9.01
- 2016-08-09 0001628280-16-018811 — 2.02, 9.01
- 2016-06-21 0001628280-16-017201 — 8.01
- 2016-05-04 0001628280-16-015501 — 2.02, 9.01
- 2016-02-16 0001628280-16-011261 — 5.02, 9.01
- 2016-02-04 0001628280-16-010758 — 5.02, 9.01
- 2016-02-04 0001628280-16-010755 — 2.02, 9.01
- 2015-11-17 0001193125-15-378953 — 7.01
- 2015-11-10 0001628280-15-008606 — 2.02, 9.01
- 2015-09-28 0001193125-15-329665 — 8.01, 9.01
- 2015-08-11 0001193125-15-286405 — 7.01, 9.01
- 2015-08-06 0001193125-15-281219 — 1.01, 5.02, 5.03, 5.05, 8.01, 9.01
- 2015-08-03 0001193125-15-274808 — 5.03, 9.01

## late-filing notifications on or before 2024-02-08

- 2015-11-10 0001628280-15-008612 — NT 10-Q, for the period ended 2015-09-26
- 2015-09-28 0001193125-15-329672 — NT 10-K, for the period ended 2015-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001628280-24-003789:8k_2_02:1]
EX-99.1
2
lite_ex991xq2fy24.htm
EX-99.1

[0001628280-24-003789:8k_2_02:2]
Document

[0001628280-24-003789:8k_2_02:3]
NEWS RELEASE

[0001628280-24-003789:8k_2_02:4]
LUMENTUM ANNOUNCES FISCAL SECOND QUARTER 2024 FINANCIAL RESULTS

[0001628280-24-003789:8k_2_02:5]
•Net revenue of $366.8 million

[0001628280-24-003789:8k_2_02:6]
•GAAP gross margin of 17.4%; Non-GAAP gross margin of 32.6%

[0001628280-24-003789:8k_2_02:7]
•GAAP operating loss of 28.7%; Non-GAAP operating margin of 3.5%

[0001628280-24-003789:8k_2_02:8]
•GAAP diluted net loss per share of $1.47; Non-GAAP diluted net income per share of $0.32

[0001628280-24-003789:8k_2_02:9]
San Jose, Calif., February 8, 2024 – Lumentum Holdings Inc. (“Lumentum” or the “Company”) today reported results for its fiscal second quarter ended December 30, 2023.

[0001628280-24-003789:8k_2_02:10]
“Lumentum stands at the leading edge of photonics innovation, partnering with customers to enable the future of data centers and the networks that connect them. Given the surging bandwidth demands of AI data centers, and our strong traction on new transceiver opportunities, we are strategically expanding our leading-edge transceiver manufacturing capacity. As a key part of this expansion, we are investing in state-of-the-art production lines at our manufacturing facility in Thailand. This factory has proven photonics manufacturing capabilities and has received numerous customer accolades, giving us confidence in our ability to ramp rapidly. We will be ramping capacity this summer and expect to lead the first wave of 1.6T transceivers for multiple customers at this site,” said Alan Lowe, President and CEO.

[0001628280-24-003789:8k_2_02:11]
“Second quarter revenue and EPS results were above the midpoints of our guidance. Based on sluggish carrier capex spending and our latest customer discussions, we now expect customer inventory digestion to extend through the balance of fiscal 2024. Nevertheless, we are highly confident in our market position and the ultimate recovery and growth in this business,” concluded Mr. Lowe.

[0001628280-24-003789:8k_2_02:12]
Fiscal Second Quarter Highlights:

[0001628280-24-003789:8k_2_02:13]
Net revenue for the fiscal second quarter of 2024 was $366.8 million, with GAAP net loss of $99.1 million, or $1.47 per diluted share. Net revenue for the fiscal first quarter of 2024 was $317.6 million, with GAAP net loss of $67.9 million, or $1.02 per diluted share. Net revenue for the fiscal second quarter of 2023 was $506.0 million, with GAAP net loss of $31.7 million, or $0.46 per diluted share.

[0001628280-24-003789:8k_2_02:14]
Non-GAAP net income for the fiscal second quarter of 2024 was $21.7 million, or $0.32 per diluted share. Non-GAAP net income for fiscal first quarter of 2024 was $23.4 million, or $0.35 per diluted share. Non-GAAP net income for the fiscal second quarter of 2023 was $104.1 million, or $1.52 per diluted share.

[0001628280-24-003789:8k_2_02:15]
The Company held $1,224.0 million in total cash, cash equivalents, and short-term investments at the end of the fiscal second quarter of 2024, down $720.3 million from the end of the fiscal first quarter of 2024. On November 7, 2023 (the “Closing date”), we completed the acquisition of Cloud Light Technology Limited (“Cloud Light”) for a total purchase price consideration of $728.5 million, of which $705.0 million of cash consideration was paid on the Closing date.

[0001628280-24-003789:8k_2_02:16]
Financial Overview – Fiscal Second Quarter Ended December 30, 2023

[0001628280-24-003789:8k_2_02:17]
|  | GAAP Results ($ in millions) |
|  | Q2 |  | Q1 |  | Q2 |  | Change |
|  | FY 2024 |  | FY 2024 |  | FY 2023 |  | Q/Q |  | Y/Y |
| Net revenue | $ | 366.8 |  |  | $ | 317.6 |  |  | $ | 506.0 |  |  | 15.5% |  | (27.5)% |
| Gross margin | 17.4 | % |  | 24.1 | % |  | 32.8 | % |  | (670) | bps |  | (1,540) | bps |
| Operating loss | (28.7) | % |  | (25.4) | % |  | (4.3) | % |  | (330) | bps |  | (2,440) | bps |
|  | Non-GAAP Results ($ in millions) |
|  | Q2 |  | Q1 |  | Q2 |  | Change |
|  | FY 2024 |  | FY 2024 |  | FY 2023 |  | Q/Q |  | Y/Y |
| Net revenue | $ | 366.8 |  |  | $ | 317.6 |  |  | $ | 506.0 |  |  | 15.5% |  | (27.5)% |
| Gross margin | 32.6 | % |  | 34.9 | % |  | 44.9 | % |  | (230) | bps |  | (1,230) | bps |
| Operating margin | 3.5 | % |  | 3.3 | % |  | 23.1 | % |  | 20 | bps |  | (1,960) | bps |

[0001628280-24-003789:8k_2_02:18]
|  | Net Revenue by Segment ($ in millions) |  |  |  |  |
|  | Q2 |  | % of |  | Q1 |  | Q2 |  | Change |  |  |  |  |
|  | FY 2024 |  | Net Revenue |  | FY 2024 |  | FY 2023 (1) |  | Q/Q |  | Y/Y |  |  |  |  |
| Cloud & Networking | $ | 286.7 |  |  | 78.2 | % |  | $ | 229.7 |  |  | $ | 382.9 |  |  | 24.8% |  | (25.1)% |  |  |  |  |
| Industrial Tech | 80.1 |  |  | 21.8 | % |  | 87.9 |  |  | 123.1 |  |  | (8.9)% |  | (34.9)% |  |  |  |  |
| Total | $ | 366.8 |  |  | 100.0 | % |  | $ | 317.6 |  |  | $ | 506.0 |  |  | 15.5% |  | (27.5)% |  |  |  |  |

[0001628280-24-003789:8k_2_02:19]
(1) Prior period amounts have been recast to conform to the new segment structure effective the fiscal first quarter of 2024.

[0001628280-24-003789:8k_2_02:20]
The tables above provide comparisons of quarterly results to prior periods, including sequential quarterly and year-over-year changes. A reconciliation between GAAP and non-GAAP measures is contained in this release under the section titled “Use of Non-GAAP Financial Measures.”

[0001628280-24-003789:8k_2_02:21]
Business Outlook

[0001628280-24-003789:8k_2_02:22]
Lumentum expects the following for the fiscal third quarter 2024:

[0001628280-24-003789:8k_2_02:23]
•Net revenue in the range of $350 million to $380 million

[0001628280-24-003789:8k_2_02:24]
•Non-GAAP operating margin of 2.0% to 5.0%

[0001628280-24-003789:8k_2_02:25]
•Non-GAAP diluted earnings per share of $0.20 to $0.35

[0001628280-24-003789:8k_2_02:26]
We have not provided reconciliations from GAAP to non-GAAP measures or the equivalent GAAP measure for non-GAAP measures in our outlook, as they cannot be provided without unreasonable effort. A large portion of non-GAAP adjustments, such as restructuring charges, stock-based compensation, non-GAAP income tax reconciling adjustments, acquisition related costs, and other costs and contingencies unrelated to current and future operations are by their nature highly volatile and we have low visibility as to the range that may be incurred in the future.

[0001628280-24-003789:8k_2_02:27]
Related Announcement and Conference Call

[0001628280-24-003789:8k_2_02:28]
Lumentum will host a conference call today, February 8, 2024, at 5:30 am PT / 8:30 am ET to discuss its fiscal second quarter results. A live webcast of the call will be available in the Investors section of the Lumentum website at http://investor.lumentum.com. To listen to the live conference call, dial (833) 470-1428 or (404) 975-4839 and reference the conference ID 255741. Supporting materials outlining the Company’s latest financial results will be posted on http://investor.lumentum.com under the “Events and Presentations” section concurrently with this earnings press release. Lumentum has used, and intends to continue to use, its Investor Relations website as means of disclosing material nonpublic information and for complying with its disclosure obligations under Regulation FD. This press release is being furnished as an exhibit to a Current Report on Form 8-K filed with the Securities and Exchange Commission and will be available at http://www.sec.gov/.

[0001628280-24-003789:8k_2_02:29]
About Lumentum

[0001628280-24-003789:8k_2_02:30]
Lumentum (NASDAQ: LITE) is a market-leading designer and manufacturer of innovative optical and photonic products enabling optical networking and laser applications worldwide. Lumentum optical components and subsystems are part of virtually every type of telecom, enterprise, and data center network. Lumentum lasers enable advanced manufacturing techniques and diverse applications including next-generation imaging and sensing capabilities. Lumentum is headquartered in San Jose, California with R&D, manufacturing, and sales offices worldwide. For more information, visit www.lumentum.com and follow Lumentum on LinkedIn, X (formerly known as Twitter), Facebook, Instagram and YouTube.

[0001628280-24-003789:8k_2_02:31]
Forward-Looking Statements

[0001628280-24-003789:8k_2_02:32]
Contact Information

[0001628280-24-003789:8k_2_02:33]
Investors:    Kathy Ta, (408) 750-3853; investor.relations@lumentum.com

[0001628280-24-003789:8k_2_02:34]
Media:        Caroline Pan, (650) 267-4180; media@lumentum.com

[0001628280-24-003789:8k_2_02:35]
Category:    Financial

[0001628280-24-003789:8k_2_02:36]
The following financial tables are presented in accordance with GAAP, unless otherwise specified.

[0001628280-24-003789:8k_2_02:37]
LUMENTUM HOLDINGS INC.

[0001628280-24-003789:8k_2_02:38]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001628280-24-003789:8k_2_02:39]
(in millions, except per share data)

[0001628280-24-003789:8k_2_02:40]
(unaudited)

[0001628280-24-003789:8k_2_02:41]
|  | Three Months Ended |  | Six Months Ended |
|  | December 30, 2023 |  | December 31, 2022 |  | December 30, 2023 |  | December 31, 2022 |
| Net revenue | $ | 366.8 |  |  | $ | 506.0 |  |  | $ | 684.4 |  |  | $ | 1,012.8 |  |
| Cost of sales | 281.3 |  |  | 315.1 |  |  | 504.2 |  |  | 597.7 |  |
| Amortization of acquired developed intangibles | 21.5 |  |  | 24.7 |  |  | 39.5 |  |  | 47.7 |  |
| Gross profit | 64.0 |  |  | 166.2 |  |  | 140.7 |  |  | 367.4 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 78.3 |  |  | 75.8 |  |  | 151.8 |  |  | 148.5 |  |
| Selling, general and administrative | 85.1 |  |  | 98.4 |  |  | 158.1 |  |  | 204.1 |  |
| Restructuring and related charges | 5.8 |  |  | 13.9 |  |  | 16.8 |  |  | 23.2 |  |
| Total operating expenses | 169.2 |  |  | 188.1 |  |  | 326.7 |  |  | 375.8 |  |
| Loss from operations | (105.2) |  |  | (21.9) |  |  | (186.0) |  |  | (8.4) |  |
| Interest expense | (9.7) |  |  | (8.9) |  |  | (19.4) |  |  | (17.4) |  |
| Other income, net | 13.4 |  |  | 3.7 |  |  | 34.6 |  |  | 17.5 |  |
| Loss before income taxes | (101.5) |  |  | (27.1) |  |  | (170.8) |  |  | (8.3) |  |
| Income tax provision (benefit) | (2.4) |  |  | 4.6 |  |  | (3.8) |  |  | 23.8 |  |
| Net loss | $ | (99.1) |  |  | $ | (31.7) |  |  | $ | (167.0) |  |  | $ | (32.1) |  |
| Net loss per share: |  |  |  |  |  |  |  |
| Basic | $ | (1.47) |  |  | $ | (0.46) |  |  | $ | (2.49) |  |  | $ | (0.47) |  |
| Diluted | $ | (1.47) |  |  | $ | (0.46) |  |  | $ | (2.49) |  |  | $ | (0.47) |  |
| Shares used to compute net loss per share: |  |  |  |  |  |  |  |
| Basic | 67.2 |  |  | 68.3 |  |  | 67.0 |  |  | 68.2 |  |
| Diluted | 67.2 |  |  | 68.3 |  |  | 67.0 |  |  | 68.2 |  |

[0001628280-24-003789:8k_2_02:42]
LUMENTUM HOLDINGS INC.

[0001628280-24-003789:8k_2_02:43]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001628280-24-003789:8k_2_02:44]
(in millions, except per share data)

[0001628280-24-003789:8k_2_02:45]
(unaudited)

[0001628280-24-003789:8k_2_02:46]
|  | December 30, 2023 |  | July 1, 2023 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 469.3 |  |  | $ | 859.0 |  |
| Short-term investments | 754.7 |  |  | 1,154.6 |  |
| Accounts receivable, net | 248.3 |  |  | 246.1 |  |
| Inventories | 471.7 |  |  | 408.6 |  |
| Prepayments and other current assets | 118.1 |  |  | 109.6 |  |
| Total current assets | 2,062.1 |  |  | 2,777.9 |  |
| Property, plant and equipment, net | 582.3 |  |  | 489.5 |  |
| Operating lease right-of-use assets, net | 81.3 |  |  | 77.3 |  |
| Goodwill | 1,054.6 |  |  | 695.1 |  |
| Other intangible assets, net | 730.6 |  |  | 459.2 |  |
| Deferred tax asset | 130.2 |  |  | 116.3 |  |
| Other non-current assets | 14.9 |  |  | 16.8 |  |
| Total assets | $ | 4,656.0 |  |  | $ | 4,632.1 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 163.0 |  |  | $ | 169.4 |  |
| Accrued payroll and related expenses | 50.4 |  |  | 39.4 |  |
| Accrued expenses | 65.8 |  |  | 51.2 |  |
| Convertible notes, current | 319.7 |  |  | 311.6 |  |
| Operating lease liabilities, current | 14.5 |  |  | 14.4 |  |
| Other current liabilities | 45.0 |  |  | 47.8 |  |
| Total current liabilities | 658.4 |  |  | 633.8 |  |
| Convertible notes, non-current | 2,501.7 |  |  | 2,500.0 |  |
| Operating lease liabilities, non-current | 52.9 |  |  | 47.7 |  |
| Deferred tax liability | 67.6 |  |  | 3.4 |  |
| Other non-current liabilities | 97.6 |  |  | 91.4 |  |
| Total liabilities | 3,378.2 |  |  | 3,276.3 |  |
| Stockholders’ equity: |  |  |  |
| Common stock, $0.001 par value, 990 authorized shares, 67.4 and 66.4 shares issued and outstanding as of December 30, 2023 and July 1, 2023, respectively | 0.1 |  |  | 0.1 |  |
| Additional paid-in capital | 1,776.1 |  |  | 1,692.2 |  |
| Accumulated deficit | (507.6) |  |  | (340.6) |  |
| Accumulated other comprehensive income | 9.2 |  |  | 4.1 |  |
| Total stockholders’ equity | 1,277.8 |  |  | 1,355.8 |  |
| Total liabilities and stockholders’ equity | $ | 4,656.0 |  |  | $ | 4,632.1 |  |

[0001628280-24-003789:8k_2_02:47]
Use of Non-GAAP Financial Measures

[0001628280-24-003789:8k_2_02:48]
In this press release, Lumentum provides investors with certain non-GAAP financial measures: gross profit, gross margin, research and development expense, selling, general and administrative expense, operating margin, income from operations, interest and other income (expense), net, income before income taxes, provision for income taxes, net income (loss), and net income (loss) per share on a non-GAAP basis, as well as the non-GAAP measures of EBITDA and Adjusted EBITDA. Lumentum believes this non-GAAP financial information provides additional insight into the Company’s on-going business operations and results, as well as cash generation, and has therefore chosen to provide this information to investors for a more consistent basis of comparison and to help them evaluate the results of the Company’s on-going operations and enable more meaningful period to period comparisons. In addition, the Company believes that providing certain of these measures allows investors to better understand the Company’s operating performance and cash flows and, importantly, to evaluate the methodology and information used by management to monitor, manage, evaluate and measure the Company’s business, results of operations, and cash flows. However, these measures may be different from non-GAAP measures used by other companies, limiting their usefulness for comparison purposes. The non-GAAP financial measures used in this press release should not be considered in isolation from measures of financial performance prepared in accordance with GAAP. Investors are cautioned that there are material limitations associated with the use of non-GAAP financial measures as an analytical tool. In particular, many of the adjustments to our GAAP financial measures reflect the exclusion of items that are recurring and will be reflected in our financial results for the foreseeable future. Further, these non-GAAP financial measures may not be comparable to similarly titled measurements reported by other companies.

[0001628280-24-003789:8k_2_02:49]
Our non-GAAP measures used in this press release exclude (i) stock-based compensation, (ii) acquisition related stock-based compensation, (iii) acquisition related costs, (iv) amortization of acquired intangibles, (v) amortization of acquired inventory fair value adjustments, (vi) restructuring and related charges, (vii) foreign exchange (gains) losses, net, (viii) non-cash interest expense on convertible notes, (ix) gain on repurchase of convertible notes, (x) non-recurring expenses related to litigation matters, (xi) intangible assets write-off, (xii) integration related costs, (xiii) non-GAAP income tax reconciling adjustments, and (xiv) other (gains) charges related to non-recurring activities.

[0001628280-24-003789:8k_2_02:50]
A quantitative reconciliation between GAAP and non-GAAP financial data with respect to historical periods is included in the supplemental financial table attached to this press release.

[0001628280-24-003789:8k_2_02:51]
LUMENTUM HOLDINGS INC.

[0001628280-24-003789:8k_2_02:52]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001628280-24-003789:8k_2_02:53]
(in millions, except per share data)

[0001628280-24-003789:8k_2_02:54]
(unaudited)

[0001628280-24-003789:8k_2_02:55]
|  | Three Months Ended |  | Six Months Ended |  |
|  | December 30, 2023 |  | September 30, 2023 |  | December 31, 2022 |  | December 30, 2023 |  | December 31, 2022 |  |
| Gross profit on GAAP basis | $ | 64.0 |  |  | $ | 76.7 |  |  | $ | 166.2 |  |  | $ | 140.7 |  |  | $ | 367.4 |  |  |
| Stock-based compensation | 9.0 |  |  | 6.0 |  |  | 6.7 |  |  | 15.0 |  |  | 12.2 |  |  |
| Amortization of acquired intangibles | 21.5 |  |  | 18.0 |  |  | 24.8 |  |  | 39.5 |  |  | 47.7 |  |  |
| Amortization of acquired inventory fair value adjustments | 3.4 |  |  | — |  |  | 9.6 |  |  | 3.4 |  |  | 14.2 |  |  |
| Integration related costs | 10.1 |  |  | 6.8 |  |  | 2.8 |  |  | 16.9 |  |  | 2.8 |  |  |
| Abnormal excess capacity (1) | 1.8 |  |  | — |  |  | — |  |  | 1.8 |  |  | — |  |  |
| Other charges, net (2) | 9.9 |  |  | 3.2 |  |  | 16.9 |  |  | 13.1 |  |  | 26.8 |  |  |
| Gross profit on non-GAAP basis | $ | 119.7 |  |  | $ | 110.7 |  |  | $ | 227.0 |  |  | $ | 230.4 |  |  | $ | 471.1 |  |  |
| Gross margin on non-GAAP basis | 32.6 | % |  | 34.9 | % |  | 44.9 | % |  | 33.7 | % |  | 46.5 | % |  |
| Research and development on GAAP basis | $ | 78.3 |  |  | $ | 73.5 |  |  | $ | 75.8 |  |  | $ | 151.8 |  |  | 148.5 |  |  |
| Stock-based compensation | (10.0) |  |  | (10.3) |  |  | (10.6) |  |  | (20.3) |  |  | (20.2) |  |  |
| Amortization of acquired intangibles | (0.4) |  |  | (0.3) |  |  | — |  |  | (0.7) |  |  | — |  |  |
| Acquisition related costs | (0.1) |  |  | (0.3) |  |  | — |  |  | (0.4) |  |  | — |  |  |
| Integration related costs (reversal) | 0.6 |  |  | (0.9) |  |  | (0.8) |  |  | (0.3) |  |  | (0.8) |  |  |
| Other charges, net | (0.1) |  |  | (0.7) |  |  | — |  |  | (0.8) |  |  | (2.3) |  |  |
| Research and development on non-GAAP basis | $ | 68.3 |  |  | $ | 61.0 |  |  | $ | 64.4 |  |  | $ | 129.3 |  |  | $ | 125.2 |  |  |
| Selling, general and administrative on GAAP basis | $ | 85.1 |  |  | $ | 73.0 |  |  | $ | 98.4 |  |  | $ | 158.1 |  |  | $ | 204.1 |  |  |
| Stock-based compensation | (15.6) |  |  | (15.8) |  |  | (19.3) |  |  | (31.4) |  |  | (38.9) |  |  |
| Stock-based compensation - acquisition related | — |  |  | — |  |  | — |  |  | — |  |  | (11.9) |  |  |
| Amortization of acquired intangibles | (15.7) |  |  | (10.7) |  |  | (11.3) |  |  | (26.4) |  |  | (20.6) |  |  |
| Acquisition related costs | (8.9) |  |  | (3.7) |  |  | — |  |  | (12.6) |  |  | (16.2) |  |  |
| Integration related costs | (2.1) |  |  | (3.6) |  |  | (4.4) |  |  | (5.7) |  |  | (5.0) |  |  |
| Litigation matters | — |  |  | — |  |  | (7.8) |  |  | — |  |  | (7.8) |  |  |
| Other charges, net | (4.4) |  |  | (0.1) |  |  | (9.7) |  |  | (4.5) |  |  | (11.9) |  |  |
| Selling, general and administrative on non-GAAP basis | $ | 38.4 |  |  | $ | 39.1 |  |  | $ | 45.9 |  |  | $ | 77.5 |  |  | $ | 91.8 |  |  |
| Loss from operations on GAAP basis | $ | (105.2) |  |  | $ | (80.8) |  |  | $ | (21.9) |  |  | $ | (186.0) |  |  | $ | (8.4) |  |  |
| Stock-based compensation | 34.6 |  |  | 32.1 |  |  | 36.6 |  |  | 66.7 |  |  | 71.3 |  |  |
| Stock-based compensation - acquisition related | — |  |  | — |  |  | — |  |  | — |  |  | 11.9 |  |  |
| Amortization of acquired intangibles | 37.6 |  |  | 29.0 |  |  | 36.1 |  |  | 66.6 |  |  | 68.3 |  |  |
| Amortization of acquired inventory fair value adjustments | 3.4 |  |  | — |  |  | 9.6 |  |  | 3.4 |  |  | 14.2 |  |  |
| Acquisition related costs | 9.0 |  |  | 4.0 |  |  | — |  |  | 13.0 |  |  | 16.2 |  |  |
| Integration related costs | 11.6 |  |  | 11.3 |  |  | 8.0 |  |  | 22.9 |  |  | 8.6 |  |  |
| Abnormal excess capacity (1) | 1.8 |  |  | — |  |  | — |  |  | 1.8 |  |  | — |  |  |
| Restructuring and related charges | 5.8 |  |  | 11.0 |  |  | 13.9 |  |  | 16.8 |  |  | 23.2 |  |  |
| Intangible asset write-off | — |  |  | — |  |  | — |  |  | — |  |  | 7.8 |  |  |
| Litigation matters | — |  |  | — |  |  | 7.8 |  |  | — |  |  | — |  |  |
| Other charges, net (2) | 14.4 |  |  | 4.0 |  |  | 26.6 |  |  | 18.4 |  |  | 41.0 |  |  |

[0001628280-24-003789:8k_2_02:56]
| Income from operations on non-GAAP basis | $ | 13.0 |  |  | $ | 10.6 |  |  | $ | 116.7 |  |  | $ | 23.6 |  |  | $ | 254.1 |  |  |
| Operating margin on non-GAAP basis | 3.5 | % |  | 3.3 | % |  | 23.1 | % |  | 3.4 | % |  | 25.1 | % |  |
| Interest and other income, net on GAAP basis | $ | 3.7 |  |  | $ | 11.5 |  |  | $ | (5.2) |  |  | $ | 15.2 |  |  | $ | 0.1 |  |  |
| Foreign exchange (gains) losses, net | 3.8 |  |  | 0.4 |  |  | 4.1 |  |  | 4.2 |  |  | (4.9) |  |  |
| Non-cash interest expense on convertible notes and other income and expenses, net | 4.8 |  |  | 4.9 |  |  | 6.2 |  |  | 9.7 |  |  | 11.9 |  |  |
| Interest and other income, net on non-GAAP basis | $ | 12.3 |  |  | $ | 16.8 |  |  | $ | 5.1 |  |  | $ | 29.1 |  |  | $ | 7.1 |  |  |
| Loss before income taxes on GAAP basis | $ | (101.5) |  |  | $ | (69.3) |  |  | $ | (27.1) |  |  | $ | (170.8) |  |  | $ | (8.3) |  |  |
| Stock-based compensation | 34.6 |  |  | 32.1 |  |  | 36.6 |  |  | 66.7 |  |  | 71.3 |  |  |
| Stock-based compensation - acquisition related | — |  |  | — |  |  | — |  |  | — |  |  | 11.9 |  |  |
| Acquisition related costs | 9.0 |  |  | 4.0 |  |  | — |  |  | 13.0 |  |  | 16.2 |  |  |
| Integration related costs | 11.6 |  |  | 11.3 |  |  | 8.0 |  |  | 22.9 |  |  | 8.6 |  |  |
| Abnormal excess capacity (1) | 1.8 |  |  | — |  |  | — |  |  | 1.80 |  |  | — |  |  |
| Amortization of acquired intangibles | 37.6 |  |  | 29.0 |  |  | 36.1 |  |  | 66.6 |  |  | 68.3 |  |  |
| Amortization of acquired inventory fair value adjustments | 3.4 |  |  | — |  |  | 9.6 |  |  | 3.4 |  |  | 14.2 |  |  |
| Restructuring and related charges | 5.8 |  |  | 11.0 |  |  | 13.9 |  |  | 16.8 |  |  | 23.2 |  |  |
| Litigation matters | — |  |  | — |  |  | 7.8 |  |  | — |  |  | 7.8 |  |  |
| Foreign exchange (gains) losses, net | 3.8 |  |  | 0.4 |  |  | 4.1 |  |  | 4.2 |  |  | (4.9) |  |  |
| Non-cash interest expense on convertible notes and other income and expenses, net | 4.8 |  |  | 4.9 |  |  | 6.2 |  |  | 9.7 |  |  | 11.9 |  |  |
| Other charges, net (2) | 14.4 |  |  | 4.0 |  |  | 26.6 |  |  | 18.4 |  |  | 41.0 |  |  |
| Income before income taxes on non-GAAP basis | $ | 25.3 |  |  | $ | 27.4 |  |  | $ | 121.8 |  |  | $ | 52.7 |  |  | $ | 261.2 |  |  |
| Income tax provision (benefit) on GAAP basis | $ | (2.4) |  |  | $ | (1.4) |  |  | $ | 4.6 |  |  | $ | (3.8) |  |  | $ | 23.8 |  |  |
| Non-GAAP income tax reconciling adjustments | 6.0 |  |  | 5.4 |  |  | 13.1 |  |  | 11.4 |  |  | 14.1 |  |  |
| Income tax provision on non-GAAP basis | $ | 3.6 |  |  | $ | 4.0 |  |  | $ | 17.7 |  |  | $ | 7.6 |  |  | $ | 37.9 |  |  |
| Net loss on GAAP basis | $ | (99.1) |  |  | $ | (67.9) |  |  | $ | (31.7) |  |  | $ | (167.0) |  |  | $ | (32.1) |  |  |
| Stock-based compensation | 34.6 |  |  | 32.1 |  |  | 36.6 |  |  | 66.7 |  |  | 71.3 |  |  |
| Stock-based compensation - acquisition related | — |  |  | — |  |  | — |  |  | — |  |  | 11.9 |  |  |
| Acquisition related costs | 9.0 |  |  | 4.0 |  |  | — |  |  | 13.0 |  |  | 16.2 |  |  |
| Integration related costs | 11.6 |  |  | 11.3 |  |  | 8.0 |  |  | 22.9 |  |  | 8.6 |  |  |
| Abnormal excess capacity (1) | 1.8 |  |  | — |  |  | — |  |  | 1.8 |  |  | — |  |  |
| Amortization of acquired intangibles | 37.6 |  |  | 29.0 |  |  | 36.1 |  |  | 66.6 |  |  | 68.3 |  |  |
| Amortization of acquired inventory fair value adjustments | 3.4 |  |  | — |  |  | 9.6 |  |  | 3.4 |  |  | 14.2 |  |  |
| Restructuring and related charges | 5.8 |  |  | 11.0 |  |  | 13.9 |  |  | 16.8 |  |  | 23.2 |  |  |
| Litigation matters | — |  |  | — |  |  | 7.8 |  |  | — |  |  | 7.8 |  |  |
| Foreign exchange (gains) losses, net | 3.8 |  |  | 0.4 |  |  | 4.1 |  |  | 4.2 |  |  | (4.9) |  |  |
| Non-cash interest expense on convertible notes and other income and expenses, net | 4.8 |  |  | 4.9 |  |  | 6.2 |  |  | 9.7 |  |  | 11.9 |  |  |
| Non-GAAP income tax reconciling adjustments | (6.0) |  |  | (5.4) |  |  | (13.1) |  |  | (11.4) |  |  | (14.1) |  |  |
| Other charges, net (2) | 14.4 |  |  | 4.0 |  |  | 26.6 |  |  | 18.4 |  |  | 41.0 |  |  |
| Net income on non-GAAP basis | $ | 21.7 |  |  | $ | 23.4 |  |  | $ | 104.1 |  |  | $ | 45.1 |  |  | $ | 223.3 |  |  |
| Net income per share on non-GAAP basis | $ | 0.32 |  |  | $ | 0.35 |  |  | $ | 1.52 |  |  | $ | 0.67 |  |  | $ | 3.20 |  |  |

[0001628280-24-003789:8k_2_02:57]
| Shares used in per share calculation - diluted on GAAP basis | 67.2 |  |  | 66.7 |  |  | 68.3 |  |  | 67.0 |  |  | 68.2 |  |  |
| Non-GAAP adjustment (3) | 0.2 |  |  | 0.3 |  |  | 0.3 |  |  | 0.3 |  |  | 1.5 |  |  |
| Shares used in per share calculation - diluted on non-GAAP basis | 67.4 |  |  | 67.0 |  |  | 68.6 |  |  | 67.3 |  |  | 69.7 |  |  |

[0001628280-24-003789:8k_2_02:58]
(1) Abnormal excess capacity for the three months ended December 30, 2023 represents excess capacity above our historical normalized run rate due to a near-term reduction in manufacturing production.

[0001628280-24-003789:8k_2_02:59]
(2) Other charges, net for the three months ended December 30, 2023 primarily relate to $9.5 million of net excess and obsolete inventory, $4.6 million of non-recurring legal and tax related fees, and $1.0 million of incremental costs of sales related to components previously acquired from various brokers to satisfy customer demand. The excess and obsolete inventory charges excluded from non-GAAP results relate to charges that are not attributable to our operating segments due to their unusual nature, primarily those charges driven by U.S. trade restrictions whereby we are no longer able to sell certain products to one of our customers.

[0001628280-24-003789:8k_2_02:60]
Other charges, net for the six months ended December 30, 2023 primarily relate to $9.2 million of net excess and obsolete inventory, $5.4 million of non-recurring legal and tax related fees, and $3.9 million of incremental costs of sales related to components previously acquired from various brokers to satisfy customer demand. The excess and obsolete inventory charges excluded from non-GAAP results relate to charges that are not attributable to our operating segments due to their unusual nature, primarily those charges driven by U.S. trade restrictions whereby we are no longer able to sell certain products to one of our customers.

[0001628280-24-003789:8k_2_02:61]
(3) Shares used for net income per share on non-GAAP basis include incremental dilutive shares that would occur upon conversion of our convertible notes assuming we settle the face value of the notes in cash as the Company intends, and shares related to restricted stock units (“RSUs”) and stock options and shares issuable under our Employee Stock Purchase Plan that are anti-dilutive on GAAP basis.

[0001628280-24-003789:8k_2_02:62]
LUMENTUM HOLDINGS INC.

[0001628280-24-003789:8k_2_02:63]
RECONCILIATION OF GAAP NET INCOME TO ADJUSTED EBITDA

[0001628280-24-003789:8k_2_02:64]
(in millions, except per share data)

[0001628280-24-003789:8k_2_02:65]
(unaudited)

[0001628280-24-003789:8k_2_02:66]
|  | Three Months Ended |  |  |  | Six Months Ended |
|  | December 30, 2023 |  |  |  | September 30, 2023 |  | December 31, 2022 |  |  |  |  |  | December 30, 2023 |  | December 31, 2022 |
| GAAP net loss | $ | (99.1) |  |  |  |  | $ | (67.9) |  |  | $ | (31.7) |  |  |  |  |  |  | $ | (167.0) |  |  | $ | (32.1) |  |
| Interest and other expense, net | (3.7) |  |  |  |  | (11.5) |  |  | 5.2 |  |  |  |  |  |  | (15.2) |  |  | (0.1) |  |
| Income tax provision (benefit) | (2.4) |  |  |  |  | (1.4) |  |  | 4.6 |  |  |  |  |  |  | (3.8) |  |  | 23.8 |  |
| Depreciation | 27.2 |  |  |  |  | 28.2 |  |  | 26.4 |  |  |  |  |  |  | 55.4 |  |  | 50.9 |  |
| Amortization of acquired intangibles | 37.6 |  |  |  |  | 29.0 |  |  | 36.1 |  |  |  |  |  |  | 66.6 |  |  | 68.3 |  |
| EBITDA | (40.4) |  |  |  |  | (23.6) |  |  | 40.6 |  |  |  |  |  |  | (64.0) |  |  | 110.8 |  |
| Amortization of inventory fair value adjustments | 3.4 |  |  |  |  | — |  |  | 9.6 |  |  |  |  |  |  | 3.4 |  |  | 14.2 |  |
| Restructuring and related charges | 5.8 |  |  |  |  | 11.0 |  |  | 13.9 |  |  |  |  |  |  | 16.8 |  |  | 23.2 |  |
| Stock-based compensation | 34.6 |  |  |  |  | 32.1 |  |  | 36.6 |  |  |  |  |  |  | 66.7 |  |  | 83.2 |  |
| Acquisition related costs | 9.0 |  |  |  |  | 4.0 |  |  | — |  |  |  |  |  |  | 13.0 |  |  | 16.2 |  |
| Integration related costs | 11.6 |  |  |  |  | 11.3 |  |  | 8.0 |  |  |  |  |  |  | 22.9 |  |  | 8.6 |  |
| Abnormal excess capacity | 1.8 |  |  |  |  | — |  |  | — |  |  |  |  |  |  | 1.8 |  |  | — |  |
| Other charges (gains), net | 13.2 |  |  |  |  | (0.2) |  |  | 24.7 |  |  |  |  |  |  | 13.0 |  |  | 39.1 |  |
| Adjusted EBITDA | $ | 39.0 |  |  |  |  | $ | 34.6 |  |  | $ | 133.4 |  |  |  |  |  |  | $ | 73.6 |  |  | $ | 295.3 |  |
