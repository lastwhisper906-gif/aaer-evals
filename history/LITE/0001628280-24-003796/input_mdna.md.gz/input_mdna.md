# LITE MD&A — 0001628280-24-003796


## mdna

[0001628280-24-003796:mdna:1]
[same as prior period, unchanged from 0001628280-23-037591:mdna:1]

[0001628280-24-003796:mdna:2]
[same as prior period, unchanged from 0001628280-23-037591:mdna:2]

[0001628280-24-003796:mdna:3]
[same as prior period, unchanged from 0001628280-23-037591:mdna:3]

[0001628280-24-003796:mdna:4]
[same as prior period, unchanged from 0001628280-23-037591:mdna:4]

[0001628280-24-003796:mdna:5]
[same as prior period, unchanged from 0001628280-23-037591:mdna:5]

[0001628280-24-003796:mdna:6]
[same as prior period, unchanged from 0001628280-23-037591:mdna:6]

[0001628280-24-003796:mdna:7]
[same as prior period, unchanged from 0001628280-23-037591:mdna:7]

[0001628280-24-003796:mdna:8]
[same as prior period, unchanged from 0001628280-23-037591:mdna:8]

[0001628280-24-003796:mdna:9]
[same as prior period, unchanged from 0001628280-23-037591:mdna:9]

[0001628280-24-003796:mdna:10]
[same as prior period, unchanged from 0001628280-23-037591:mdna:10]

[0001628280-24-003796:mdna:11]
[same as prior period, unchanged from 0001628280-23-037591:mdna:11]

[0001628280-24-003796:mdna:12]
Our Cloud & Networking products include a wide range of components, modules, and subsystems to support customers including carrier networks for access (local), metro (intracity), long-haul (city-to-city and worldwide) and submarine (undersea) applications. Additionally, our products address enterprise, cloud, and data center applications, including storage-access networks (“SANs”), local-area networks (“LANs”) and wide-area networks (“WANs”), as well as artificial intelligence and machine learning (“AI/ML”). These products enable the transmission and transport of video, audio, and data over high-capacity fiber-optic cables. We maintain leading positions in these fast-growing cloud & networking markets through our extensive product portfolio, including reconfigurable optical add/drop multiplexers (“ROADMs”), coherent dense wavelength division multiplexing (“DWDM”) pluggable transceivers, and tunable small form-factor pluggable transceivers. We also sell laser chips for use in manufacturing of high-speed ethernet transceivers for use primarily inside data centers.

[0001628280-24-003796:mdna:13]
[same as prior period, unchanged from 0001628280-23-037591:mdna:13]

[0001628280-24-003796:mdna:14]
Our Industrial Tech products include diode laser products such as VCSELs and edge emitting lasers. In the consumer end-market, our laser light sources are integrated into 3D sensing cameras which are used in applications in mobile devices, gaming, payment kiosks, computers, other consumer electronics devices, and automobiles. Applications include biometric identification, computational photography, virtual and augmented reality, and natural user interfaces. Emerging applications for our lasers include automotive safety systems, LiDAR for advanced driver assistance systems in automobiles and autonomous vehicles, self-navigating robotics and drones in industrial applications, and 3D capture of objects coupled with 3D imaging or printing. In the industrial end market, our diode lasers are used primarily as pump sources for pulsed and kilowatt class fiber lasers.

[0001628280-24-003796:mdna:15]
[same as prior period, unchanged from 0001628280-23-037591:mdna:15]

[0001628280-24-003796:mdna:16]
[same as prior period, unchanged from 0001628280-23-037591:mdna:17]

[0001628280-24-003796:mdna:17]
On October 29, 2023, Lumentum and Cloud Light Technology Limited (“Cloud Light”) entered into a definitive merger agreement (the “Merger Agreement”). On November 7, 2023 (the “Closing date”), we completed the acquisition of Cloud Light. Cloud Light designs, markets, and manufactures advanced optical modules for data center interconnect applications. The acquisition enables us to be well-positioned to serve the growing needs of cloud & networking customers, particularly those focused on optimizing their data center infrastructure for the demands of AI/ML. On the Closing date, we paid $705.0 million of total cash consideration to Cloud Light. Additionally, each of Cloud Light’s outstanding options was exchanged for a combination of cash and options to acquire Lumentum common stock having equivalent value (the “replacement options”). These replacement options have a total fair value of $38.9 million as of the Closing date, of which $23.5 million attributed to pre-acquisition service is recorded as part of purchase price consideration and the remaining $15.4 million is recorded as post-acquisition stock-based compensation expense over the vesting period of three years from the acquisition Closing date. We also incurred $6.8 million of merger-related costs during the fiscal second quarter of 2024, representing professional and other direct acquisition costs, which was recorded as general and administrative expense in the consolidated statement of operations. Refer to “Note 4. Business Combinations” in the notes to condensed consolidated financial statements.

[0001628280-24-003796:mdna:18]
[same as prior period, unchanged from 0001628280-23-037591:mdna:20]

[0001628280-24-003796:mdna:19]
[same as prior period, unchanged from 0001628280-23-037591:mdna:21]

[0001628280-24-003796:mdna:20]
[same as prior period, unchanged from 0001628280-23-037591:mdna:22]

[0001628280-24-003796:mdna:21]
In addition, in response to component shortages, certain of our customers accumulated inventory that they are now managing down as supply conditions improve. Accordingly, customer orders have declined in recent periods and certain customers have not taken the shipments we had originally projected due to their inventory management. As customers manage their inventory down, our revenue has declined and our margins are adversely impacted as we are not able to fully recover costs, such as underutilized manufacturing capacity, associated with the forecasted demand and we may incur excess and obsolescence charges from unsold inventory. We expect this trend to continue to impact our business during the calendar year 2024.

[0001628280-24-003796:mdna:22]
For more information on risks associated with supply chain constraints and customer inventory management, see the section titled “Risk Factors” in Item 1A of Part II of this report.

[0001628280-24-003796:mdna:23]
[same as prior period, unchanged from 0001628280-23-037591:mdna:25]

[0001628280-24-003796:mdna:24]
[same as prior period, unchanged from 0001628280-23-037591:mdna:26]

[0001628280-24-003796:mdna:25]
[same as prior period, unchanged from 0001628280-23-037591:mdna:27]

[0001628280-24-003796:mdna:26]
[same as prior period, unchanged from 0001628280-23-037591:mdna:28]

[0001628280-24-003796:mdna:27]
[same as prior period, unchanged from 0001628280-23-037591:mdna:29]

[0001628280-24-003796:mdna:28]
[same as prior period, unchanged from 0001628280-23-037591:mdna:30]

[0001628280-24-003796:mdna:29]
[same as prior period, unchanged from 0001628280-23-037591:mdna:31]

[0001628280-24-003796:mdna:30]
Management’s Discussion and Analysis of Financial Condition and Results of Operations contained in Part II, Item 7 of our Annual Report on Form 10-K for our fiscal year ended July 1, 2023 provides a complete discussion of our critical accounting policies and estimates. There have been no changes to these policies during the three and six months ended December 30, 2023.

[0001628280-24-003796:mdna:31]
Recently Issued Accounting Pronouncements

[0001628280-24-003796:mdna:32]
Refer to “Note 2. Recently Issued Accounting Pronouncements” in the notes to condensed consolidated financial statements.

[0001628280-24-003796:mdna:33]
[same as prior period, unchanged from 0001628280-23-037591:mdna:35]

[0001628280-24-003796:mdna:34]
[same as prior period, unchanged from 0001628280-23-037591:mdna:36]

[0001628280-24-003796:mdna:35]
[same as prior period, unchanged from 0001628280-23-037591:mdna:37]

[0001628280-24-003796:mdna:36]
|  | Three Months Ended |  | Six Months Ended |
|  | December 30, 2023 |  | December 31, 2022 |  | December 30, 2023 |  | December 31, 2022 |
| Segment net revenue: |  |  |  |  |  |  |  |
| Cloud & Networking | 78.2 | % |  | 75.7 | % |  | 75.5 | % |  | 73.4 | % |
| Industrial Tech | 21.8 |  |  | 24.3 |  |  | 24.5 |  |  | 26.6 |  |
| Net revenue | 100.0 |  |  | 100.0 |  |  | 100.0 |  |  | 100.0 |  |
| Cost of sales | 76.7 |  |  | 62.3 |  |  | 73.6 |  |  | 59.0 |  |
| Amortization of acquired developed intangibles | 5.9 |  |  | 4.9 |  |  | 5.8 |  |  | 4.7 |  |
| Gross profit | 17.4 |  |  | 32.8 |  |  | 20.6 |  |  | 36.3 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 21.3 |  |  | 15.0 |  |  | 22.2 |  |  | 14.7 |  |
| Selling, general and administrative | 23.2 |  |  | 19.4 |  |  | 23.1 |  |  | 20.2 |  |
| Restructuring and related charges | 1.6 |  |  | 2.7 |  |  | 2.5 |  |  | 2.3 |  |
| Total operating expenses | 46.1 |  |  | 37.2 |  |  | 47.8 |  |  | 37.1 |  |
| Loss from operations | (28.7) |  |  | (4.3) |  |  | (27.2) |  |  | (0.8) |  |
| Interest expense | (2.7) |  |  | (1.8) |  |  | (2.8) |  |  | (1.7) |  |
| Other income, net | 3.7 |  |  | 0.7 |  |  | 5.0 |  |  | 1.7 |  |
| Loss before income taxes | (27.7) |  |  | (5.4) |  |  | (25.0) |  |  | (0.8) |  |
| Income tax provision (benefit) | (0.7) |  |  | 0.9 |  |  | (0.6) |  |  | 2.3 |  |
| Net loss | (27.0) | % |  | (6.3) | % |  | (24.4) | % |  | (3.2) | % |

[0001628280-24-003796:mdna:37]
46

[0001628280-24-003796:mdna:38]
Financial data for the three and six months ended December 30, 2023

[0001628280-24-003796:mdna:39]
[same as prior period, unchanged from 0001628280-23-037591:mdna:41]

[0001628280-24-003796:mdna:40]
|  | Three Months Ended |  | Six Months Ended |  |  |  |  |
|  | December 30, 2023 |  | December 31, 2022 |  | Change |  | Percentage Change |  | December 30, 2023 |  | December 31, 2022 |  | Change |  | Percentage Change |
| Segment net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cloud & Networking | $ | 286.7 |  |  | $ | 382.9 |  |  | $ | (96.2) |  |  | (25.1) | % |  | $ | 516.4 |  |  | $ | 743.0 |  |  | $ | (226.6) |  |  | (30.5) | % |
| Industrial Tech | 80.1 |  |  | 123.1 |  |  | (43.0) |  |  | (34.9) | % |  | 168.0 |  |  | 269.8 |  |  | (101.8) |  |  | (37.7) | % |
| Net revenue | $ | 366.8 |  |  | $ | 506.0 |  |  | $ | (139.2) |  |  | (27.5) | % |  | $ | 684.4 |  |  | $ | 1,012.8 |  |  | $ | (328.4) |  |  | (32.4) | % |
| Gross profit | $ | 64.0 |  |  | $ | 166.2 |  |  | $ | (102.2) |  |  | (61.5) | % |  | $ | 140.7 |  |  | $ | 367.4 |  |  | $ | (226.7) |  |  | (61.7) | % |
| Gross margin | 17.4 | % |  | 32.8 | % |  |  |  |  |  | 20.6 | % |  | 36.3 | % |  |  |  |  |
| Research and development | $ | 78.3 |  |  | $ | 75.8 |  |  | $ | 2.5 |  |  | 3.3 | % |  | $ | 151.8 |  |  | $ | 148.5 |  |  | $ | 3.3 |  |  | 2.2 | % |
| Percentage of net revenue | 21.3 | % |  | 15.0 | % |  |  |  |  |  | 22.2 | % |  | 14.7 | % |  |  |  |  |
| Selling, general and administrative | $ | 85.1 |  |  | $ | 98.4 |  |  | $ | (13.3) |  |  | (13.5) | % |  | $ | 158.1 |  |  | $ | 204.1 |  |  | $ | (46.0) |  |  | (22.5) | % |
| Percentage of net revenue | 23.2 | % |  | 19.4 | % |  |  |  |  |  | 23.1 | % |  | 20.2 | % |  |  |  |  |
| Restructuring and related charges | $ | 5.8 |  |  | $ | 13.9 |  |  | $ | (8.1) |  |  | (58.3) | % |  | $ | 16.8 |  |  | $ | 23.2 |  |  | $ | (6.4) |  |  | (27.6) | % |
| Percentage of net revenue | 1.6 | % |  | 2.7 | % |  |  |  |  |  | 2.4 | % |  | 2.3 | % |  |  |  |  |

[0001628280-24-003796:mdna:41]
[same as prior period, unchanged from 0001628280-23-037591:mdna:43]

[0001628280-24-003796:mdna:42]
Net revenue decreased by $139.2 million, or 27.5%, during the three months ended December 30, 2023 compared to the three months ended December 31, 2022, driven by a $96.2 million decrease in Cloud & Networking revenue and a $43.0 million decrease in Industrial Tech revenue. The decrease in Cloud & Networking net revenue is primarily due to reduction in demand associated with a build-up of inventory and resulting inventory management actions by our customers, offset by $59.5 million of revenue generated by Cloud Light. The decrease in Industrial Tech net revenue is primarily due to higher market competition, which reflects share normalization in the market, as well as reduction in demand associated with a build-up of inventory and resulting inventory management actions by our customers.

[0001628280-24-003796:mdna:43]
Net revenue decreased by $328.4 million, or 32.4%, during the six months ended December 30, 2023 compared to the six months ended December 31, 2022, driven by a $226.6 million decrease in Cloud & Networking revenue and a $101.8 million decrease in Industrial Tech revenue. The decrease in Cloud & Networking net revenue is primarily due to reduction in demand associated with a build-up of inventory and resulting inventory management actions by our customers, offset by $59.5 million of revenue generated by Cloud Light. The decrease in Industrial Tech net revenue is primarily due to higher market competition, which reflects share normalization in the market, as well as reduction in demand associated with a build-up of inventory and resulting inventory management actions by our customers.

[0001628280-24-003796:mdna:44]
During the three months ended December 30, 2023, our net revenue from a single customer that represented 10% or greater of the total net revenue was concentrated with three customers, who individually accounted for 19%, 13% and 11% of our total net revenue, respectively. During the six months ended December 30, 2023, our net revenue from a single customer that represented 10% or greater of the total net revenue was concentrated with three customers, who individually accounted for 14%, 12% and 12% of our total net revenue, respectively.

[0001628280-24-003796:mdna:45]
During the three months ended December 31, 2022, our net revenue from a single customer that represented 10% or greater of the total net revenue was concentrated with two customers, who individually accounted for 19% and 12% of our total net revenue, respectively. During the six months ended December 31, 2022, our net revenue from a single customer that represented 10% or greater of the total net revenue was concentrated with two customers, who individually accounted for 18% and 15% of our total net revenue, respectively.

[0001628280-24-003796:mdna:46]
[same as prior period, unchanged from 0001628280-23-037591:mdna:46]

[0001628280-24-003796:mdna:47]
[same as prior period, unchanged from 0001628280-23-037591:mdna:47]

[0001628280-24-003796:mdna:48]
[same as prior period, unchanged from 0001628280-23-037591:mdna:48]

[0001628280-24-003796:mdna:49]
|  | Three Months Ended |  | Six Months Ended |
|  | December 30, 2023 |  | December 31, 2022 |  | December 30, 2023 |  | December 31, 2022 |
|  | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States | $ | 103.0 |  |  | 28.1 | % |  | $ | 65.5 |  |  | 12.9 | % |  | $ | 144.1 |  |  | 21.0 | % |  | $ | 127.7 |  |  | 12.6 | % |
| Mexico | 31.4 |  |  | 8.6 |  |  | 59.5 |  |  | 11.8 |  |  | 55.1 |  |  | 8.1 |  |  | 117.0 |  |  | 11.6 |  |
| Other Americas | 0.8 |  |  | 0.2 |  |  | 3.8 |  |  | 0.8 |  |  | 2.0 |  |  | 0.3 |  |  | 6.1 |  |  | 0.6 |  |
| Total Americas | $ | 135.2 |  |  | 36.9 | % |  | $ | 128.8 |  |  | 25.5 | % |  | $ | 201.2 |  |  | 29.4 | % |  | $ | 250.8 |  |  | 24.8 | % |
| Asia-Pacific: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Hong Kong | $ | 65.7 |  |  | 17.9 | % |  | $ | 65.9 |  |  | 13.0 | % |  | $ | 130.6 |  |  | 19.1 | % |  | $ | 143.5 |  |  | 14.2 | % |
| South Korea | 20.8 |  |  | 5.7 |  |  | 52.0 |  |  | 10.3 |  |  | 45.8 |  |  | 6.7 |  |  | 119.7 |  |  | 11.8 |  |
| Japan | 25.9 |  |  | 7.1 |  |  | 50.8 |  |  | 10.0 |  |  | 51.3 |  |  | 7.5 |  |  | 95.6 |  |  | 9.4 |  |
| Thailand | 39.3 |  |  | 10.7 |  |  | 77.9 |  |  | 15.4 |  |  | 103.5 |  |  | 15.1 |  |  | 135.4 |  |  | 13.4 |  |
| Other Asia-Pacific | 49.5 |  |  | 13.4 |  |  | 84.7 |  |  | 16.7 |  |  | 89.0 |  |  | 13.0 |  |  | 173.6 |  |  | 17.1 |  |
| Total Asia-Pacific | $ | 201.2 |  |  | 54.8 | % |  | $ | 331.3 |  |  | 65.4 | % |  | $ | 420.2 |  |  | 61.4 | % |  | $ | 667.8 |  |  | 65.9 | % |
| EMEA | $ | 30.4 |  |  | 8.3 | % |  | $ | 45.9 |  |  | 9.1 | % |  | $ | 63.0 |  |  | 9.2 | % |  | $ | 94.2 |  |  | 9.3 | % |
| Total net revenue | $ | 366.8 |  |  | 100.0 | % |  | $ | 506.0 |  |  | 100.0 | % |  | $ | 684.4 |  |  | 100.0 | % |  | $ | 1,012.8 |  |  | 100.0 | % |

[0001628280-24-003796:mdna:50]
For the three and six months ended December 30, 2023, net revenue from customers outside the United States, based on customer shipping location, represented 71.9% and 79.0% of net revenue, respectively.

[0001628280-24-003796:mdna:51]
For the three and six months ended December 31, 2022, net revenue from customers outside the United States, based on customer shipping location, represented 87.1% and 87.4% of net revenue, respectively.

[0001628280-24-003796:mdna:52]
[same as prior period, unchanged from 0001628280-23-037591:mdna:51]

[0001628280-24-003796:mdna:53]
[same as prior period, unchanged from 0001628280-23-037591:mdna:52]

[0001628280-24-003796:mdna:54]
Gross margin for the three months ended December 30, 2023 decreased to 17.4% from 32.8% for the three months ended December 31, 2022. The decrease in gross margin was primarily driven by lower revenue as discussed above, a less profitable mix of products, and $7.9 million of incremental excess and obsolete inventory charges primarily driven by U.S. trade restrictions whereby we are no longer able to sell certain products to one of customers. Additionally, gross margin was negatively impacted by factory underutilization as a result of a drop in demand as customers continue to work to reduce their elevated inventory levels. This decrease in gross margin was partially offset by lower amortization of acquired inventory resulting from our acquisitions of NeoPhotonics in August 2022 and Cloud Light in November 2023.

[0001628280-24-003796:mdna:55]
Gross margin for the six months ended December 30, 2023 decreased to 20.6% from 36.3% for the six months ended December 31, 2022. The decrease was primarily driven by lower revenue as discussed above, a less profitable mix of products, and $19.2 million of incremental inventory excess and obsolescence charges primarily driven by U.S trade restrictions whereby we are no longer able to sell certain products to one of customers, customer demand change and transitions to the next generation of products. Additionally, gross margin was negatively impacted by factory underutilization as a result of a drop in demand as customers work to reduce their elevated inventory levels. This was partially offset by lower amortization of acquired inventory resulting from our acquisitions of NeoPhotonics in August 2022 and Cloud Light in November 2023.

[0001628280-24-003796:mdna:56]
[same as prior period, unchanged from 0001628280-23-037591:mdna:54]

[0001628280-24-003796:mdna:57]
49

[0001628280-24-003796:mdna:58]
[same as prior period, unchanged from 0001628280-23-037591:mdna:56]

[0001628280-24-003796:mdna:59]
[same as prior period, unchanged from 0001628280-23-037591:mdna:57]

[0001628280-24-003796:mdna:60]
|  | Three Months Ended |  | Six Months Ended |
|  | December 30, 2023 |  | December 31, 2022 |  | December 30, 2023 |  | December 31, 2022 |
| Net revenue: |  |  |  |  |  |  |  |
| Cloud & Networking | $ | 286.7 |  |  | $ | 382.9 |  |  | $ | 516.4 |  |  | $ | 743.0 |  |
| Industrial Tech | 80.1 |  |  | 123.1 |  |  | 168.0 |  |  | 269.8 |  |
| Net revenue | $ | 366.8 |  |  | $ | 506.0 |  |  | $ | 684.4 |  |  | $ | 1,012.8 |  |
| Segment profit: |  |  |  |  |  |  |  |
| Cloud & Networking | $ | 29.1 |  |  | $ | 99.9 |  |  | $ | 53.0 |  |  | $ | 201.6 |  |
| Industrial Tech | 12.7 |  |  | 49.7 |  |  | 28.0 |  |  | 118.5 |  |
| Total segment profit | 41.8 |  |  | 149.6 |  |  | 81.0 |  |  | 320.1 |  |
| Unallocated corporate items: |  |  |  |  |  |  |  |
| Selling, general and administrative (1) | (28.8) |  |  | (32.9) |  |  | (57.4) |  |  | (66.0) |  |
| Stock-based compensation | (34.6) |  |  | (36.6) |  |  | (66.7) |  |  | (71.3) |  |
| Stock-based compensation - acquisition related | — |  |  | — |  |  | — |  |  | (11.9) |  |
| Amortization of acquired intangibles | (37.6) |  |  | (36.1) |  |  | (66.6) |  |  | (68.3) |  |
| Amortization of acquired inventory fair value adjustments | (3.4) |  |  | (9.6) |  |  | (3.4) |  |  | (14.2) |  |
| Acquisition related costs | (9.0) |  |  | — |  |  | (13.0) |  |  | (16.2) |  |
| Integration related costs | (11.6) |  |  | (8.0) |  |  | (22.9) |  |  | (8.6) |  |
| Restructuring and related charges | (5.8) |  |  | (13.9) |  |  | (16.8) |  |  | (23.2) |  |
| Abnormal excess capacity | (1.8) |  |  | — |  |  | (1.8) |  |  | — |  |
| Litigation matters | — |  |  | (7.8) |  |  | — |  |  | (7.8) |  |
| Other charges, net (2) | (14.4) |  |  | (26.6) |  |  | (18.4) |  |  | (41.0) |  |
| Interest expense | (9.7) |  |  | (8.9) |  |  | (19.4) |  |  | (17.4) |  |
| Other income, net (3) | 13.4 |  |  | 3.7 |  |  | 34.6 |  |  | 17.5 |  |
| Consolidated loss before income taxes | $ | (101.5) |  |  | $ | (27.1) |  |  | $ | (170.8) |  |  | $ | (8.3) |  |

[0001628280-24-003796:mdna:61]
[same as prior period, unchanged from 0001628280-23-037591:mdna:59]

[0001628280-24-003796:mdna:62]
(2)  Other charges, net for the three months ended December 30, 2023 primarily relate to $9.5 million of net excess and obsolete inventory, $4.6 million of non-recurring legal and tax related fees, and $1.0 million of incremental costs of sales related to components previously acquired from various brokers to satisfy customer demand. The excess and obsolete inventory charges relate to charges that are not attributable to our operating segments due to their unusual nature, primarily those charges driven by U.S. trade restrictions whereby we are no longer able to sell certain products to one of our customers.

[0001628280-24-003796:mdna:63]
Other charges, net for the six months ended December 30, 2023 primarily relate to $9.2 million of net excess and obsolete inventory, $5.4 million of non-recurring legal and tax related fees, and $3.9 million of incremental costs of sales related to components previously acquired from various brokers to satisfy customer demand. The excess and obsolete inventory charges relate to charges that are not attributable to our operating segments due to their unusual nature, primarily those charges driven by U.S. trade restrictions whereby we are no longer able to sell certain products to one of our customers.

[0001628280-24-003796:mdna:64]
Other charges, net for the three months ended December 31, 2022 primarily relate to $11.7 million of incremental costs of sales related to components previously acquired from various brokers to satisfy customer demand, $4.5 million of non-recurring charges on legal matters, and $5.4 million of excess and obsolete inventory charges primarily driven by U.S. trade restrictions.

[0001628280-24-003796:mdna:65]
Other charges, net for the six months ended December 31, 2022 primarily relate to $19.0 million of incremental costs of sales related to components previously acquired from various brokers to satisfy customer demand, $4.5 million of non-recurring charges on legal matters, and $5.5 million of excess and obsolete inventory charges primarily driven by U.S. trade restrictions.

[0001628280-24-003796:mdna:66]
(3) Other income, net for the three months ended December 30, 2023 includes interest and investment income of $17.1 million, offset by foreign exchange and other loss, net of $3.7 million. Other income, net for the six months ended December 30, 2023 includes interest and investment income of $38.8 million, offset by foreign exchange and other loss, net of $4.2 million.

[0001628280-24-003796:mdna:67]
Other income, net for the three months ended December 31, 2022 primarily relates to $7.7 million of interest and investment income, offset by $4.1 million of net foreign exchange losses. Other income, net for the six months ended December 31, 2022 primarily relates to $12.5 million of interest and investment income and $4.9 million of net foreign exchange gains.

[0001628280-24-003796:mdna:68]
Total segment profit decreased by $107.8 million, or 72.1%, during the three months ended December 30, 2023. Cloud & Networking segment profit decreased by $70.8 million, or 70.9%,  primarily due to lower revenue and the negative impact from factory under-utilization as a result of a drop in demand as customers actively work to reduce their elevated inventory levels, as well as higher excess and obsolete charges primarily driven by U.S. trade restrictions whereby we are no longer able to sell certain products to one of our customers. This is partially offset by segment profit generated by our acquisition of Cloud Light.  Industrial Tech segment profit decreased by $37.0 million, or 74.4%, primarily due to a less profitable mix of products, including lower sales of higher margin imaging and sensing products.

[0001628280-24-003796:mdna:69]
Total segment profit decreased by $239.1 million, or 74.7%, during the six months ended December 30, 2023. Cloud & Networking segment profit decreased by $148.6 million, or 73.7%, primarily due to lower revenue and the negative impact from factory under-utilization as a result of a drop in demand as customers actively work to reduce their elevated inventory levels as well as higher excess and obsolete charges driven by U.S. trade restrictions whereby we are no longer able to sell certain products to one of our customers and customer demand changes as a result of product transitions. This is partially offset by segment profit generated by our recent acquisition of Cloud Light. Industrial Tech segment profit decreased by $90.5 million, or 76.4%, primarily due to less profitable mix of products, including lower sales of higher margin imaging and sensing products due to share normalization.

[0001628280-24-003796:mdna:70]
[same as prior period, unchanged from 0001628280-23-037591:mdna:63]

[0001628280-24-003796:mdna:71]
R&D expense increased $2.5 million, or 3.3% for the three months ended December 30, 2023 compared to the three months ended December 31, 2022.  The increase in R&D expense for the three months ended December 30, 2023 was primarily driven by an increase in project spend, offset by a slight decrease in payroll and other compensation related expenses.  Although we received benefits from restructuring actions taken in fiscal 2023 and in the first quarter of fiscal 2024, this savings was substantially offset by the additional headcount costs from our recent acquisition of Cloud Light.

[0001628280-24-003796:mdna:72]
R&D expense increased by $3.3 million, or 2.2% for the six months ended December 30, 2023 compared to the six months ended December 31, 2022. The increase in R&D expense for the six months ended December 30, 2023 was primarily driven by an increase in project spend and lower funding from customers, offset by a slight decrease in payroll and other compensation related expenses. Although we received benefits from restructuring actions taken in fiscal 2023 and in the first quarter of fiscal 2024, this saving was offset by the additional headcount costs from our recent acquisition of Cloud Light.

[0001628280-24-003796:mdna:73]
[same as prior period, unchanged from 0001628280-23-037591:mdna:65]

[0001628280-24-003796:mdna:74]
[same as prior period, unchanged from 0001628280-23-037591:mdna:66]

[0001628280-24-003796:mdna:75]
SG&A expense decreased by $13.3 million, or 13.5%, during the three months ended December 30, 2023 compared to the three months ended December 31, 2022, primarily driven by lower payroll related expenses due to headcount reductions as a result of restructuring actions taken in fiscal 2023 and in the first quarter of fiscal 2024, partially offset by compensation expenses related to additional headcount from our recent acquisition of Cloud Light. In addition, we reduced our outside consultant costs as a result of business and system integrations efforts. During the three months ended December 31, 2022, we incurred a $7.8 million expense with respect to the settlement of certain non-ordinary course litigation matters.

[0001628280-24-003796:mdna:76]
SG&A expense decreased by $46.0 million, or 22.5%, during the six months ended December 30, 2023 compared to the six months ended December 31, 2022. The decrease in SG&A expense for the six months ended December 30, 2023 was primarily driven by lower stock-based compensation of $19.5 million, lower acquisition related costs of $3.6 million as a result of the timing of our recent acquisitions, and lower legal costs of $7.8 million as a result of non-recurring litigation matters discussed above. In connection with the merger with NeoPhotonics that occurred in August 2022, certain equity awards for NeoPhotonics employees were accelerated, resulting in $11.9 million of stock-based compensation recognized during the six months ended December 31, 2022.  In addition, we reduced our outside consultant costs as a result of business and system integrations efforts.  These amounts were partially offset by the additional headcount costs and other expenses from our recent acquisition of Cloud Light.

[0001628280-24-003796:mdna:77]
From time-to-time, we incur expenses that are not part of our ordinary operations, such as mergers and acquisition-related and litigation expenses, which generally increase our SG&A expenses and potentially impact our profitability expectations in any particular period.

[0001628280-24-003796:mdna:78]
[same as prior period, unchanged from 0001628280-23-037591:mdna:69]

[0001628280-24-003796:mdna:79]
We have initiated various strategic restructuring events primarily intended to reduce costs, consolidate our operations, rationalize the manufacturing of our products, and align our business in response to market conditions. We also took certain actions in connection with the integration of NeoPhotonics business.

[0001628280-24-003796:mdna:80]
During the three and six months ended December 30, 2023, we recorded restructuring and related charges of $5.8 million and $16.8 million, respectively, primarily due to company-wide cost reduction initiatives, as well as our integration efforts as a result of the NeoPhotonics acquisition in August 2022.

[0001628280-24-003796:mdna:81]
During the three months ended December 31, 2022, we recorded restructuring and related charges of $13.9 million, primarily due to our integration efforts as a result of the NeoPhotonics acquisition, as well as company-wide cost reduction initiatives. During the six months ended December 31, 2022, we recorded restructuring and related charges of $23.2 million, primarily due to our integration efforts in connection with the NeoPhotonics acquisition, company-wide cost reduction initiatives, as well as severance and employee-related benefits associated with NeoPhotonics’ executive severance and retention agreements. These agreements provide for payments and benefits upon an involuntary termination of employment under certain circumstances.

[0001628280-24-003796:mdna:82]
[same as prior period, unchanged from 0001628280-23-037591:mdna:73]

[0001628280-24-003796:mdna:83]
For the three months ended December 30, 2023 and December 31, 2022, we recorded interest expense of $9.7 million and $8.9 million, respectively. For the six months ended December 30, 2023 and December 31, 2022, we recorded interest expense of $19.4 million and $17.4 million, respectively. Interest expense relates to the amortization of the debt discount and issuance costs of our convertible notes. The increase in interest expense for the three and six months ended December 30, 2023 is due to our 2029 Notes (as defined below) issued in June 2023.

[0001628280-24-003796:mdna:84]
[same as prior period, unchanged from 0001628280-23-037591:mdna:75]

[0001628280-24-003796:mdna:85]
[same as prior period, unchanged from 0001628280-23-037591:mdna:76]

[0001628280-24-003796:mdna:86]
|  | Three Months Ended |  | Six Months Ended |  |  |
|  | December 30, 2023 |  | December 31, 2022 |  | December 30, 2023 |  | December 31, 2022 |  |  |
| Foreign exchange and other gains (losses), net | $ | (3.7) |  |  | $ | (4.1) |  |  | $ | (4.2) |  |  | $ | 4.9 |  |  |  |
| Interest and investment income, net | 17.1 |  |  | 7.7 |  |  | 38.8 |  |  | 12.5 |  |  |  |
| Total other income, net | $ | 13.4 |  |  | $ | 3.6 |  |  | $ | 34.6 |  |  | $ | 17.4 |  |  |  |

[0001628280-24-003796:mdna:87]
Other income, net for the three months ended December 30, 2023 increased by $9.8 million from the three months ended December 31, 2022 primarily due to $9.4 million increase in interest and investment income driven by an increase in interest rates on our fixed income securities.

[0001628280-24-003796:mdna:88]
Other income, net for the six months ended December 30, 2023 increased by $17.2 million from the six months ended December 31, 2022 due to $26.3 million of increase in interest and investment income driven by an increase in interest rates on our fixed income securities, offset by a decrease in income from foreign exchange of $9.1 million as a result of the weakening of other foreign currencies relative to the U.S. dollar during the six months ended December 31, 2022.

[0001628280-24-003796:mdna:89]
[same as prior period, unchanged from 0001628280-23-037591:mdna:79]

[0001628280-24-003796:mdna:90]
[same as prior period, unchanged from 0001628280-23-037591:mdna:80]

[0001628280-24-003796:mdna:91]
|  | Three Months Ended |  | Six Months Ended |
|  | December 30, 2023 |  | December 31, 2022 |  | December 30, 2023 |  | December 31, 2022 |
| Income tax provision (benefit) | $ | (2.4) |  |  | $ | 4.6 |  |  | $ | (3.8) |  |  | $ | 23.8 |  |

[0001628280-24-003796:mdna:92]
We recorded a tax benefit of $2.4 million and $3.8 million for the three and six months ended December 30, 2023, respectively. Our tax benefit for the three months ended December 30, 2023 includes a discrete tax expense of $3.4 million primarily related to a shortfall in connection with stock-based compensation vested during the quarter, interest on uncertain tax positions and currency re-measurements. Our tax benefit for the six months ended December 30, 2023 includes a discrete tax expense of $1.6 million, primarily related to a shortfall in connection with stock-based compensation vested during the quarter, foreign return to provision differences and interest on unrecognized tax positions, partially offset by the tax benefit from changes in prior year uncertain tax positions.

[0001628280-24-003796:mdna:93]
We recorded a tax provision of $4.6 million and $23.8 million for the three and six months ended December 31, 2022, respectively. Our tax provision for the three months ended December 31, 2022 includes a discrete tax expense of $4.0 million primarily related to the U.S. return to provision differences for transaction costs, currency re-measurements. Our tax provision for the six months ended December 31, 2022 includes a discrete tax expense of $17.1 million, primarily related to the international restructuring, currency re-measurements and U.S. return to provision differences for transaction costs, partially offset by the tax benefit from tax rate changes.

[0001628280-24-003796:mdna:94]
[same as prior period, unchanged from 0001628280-23-037591:mdna:83]

[0001628280-24-003796:mdna:95]
[same as prior period, unchanged from 0001628280-23-037591:mdna:84]

[0001628280-24-003796:mdna:96]
[same as prior period, unchanged from 0001628280-23-037591:mdna:85]

[0001628280-24-003796:mdna:97]
[same as prior period, unchanged from 0001628280-23-037591:mdna:86]

[0001628280-24-003796:mdna:98]
[same as prior period, unchanged from 0001628280-23-037591:mdna:87]

[0001628280-24-003796:mdna:99]
As of December 30, 2023 and July 1, 2023, our cash and cash equivalents were $469.3 million and $859.0 million, respectively. As of December 30, 2023 and July 1, 2023, our short-term investments of $754.7 million and $1,154.6 million, respectively, were all held in the United States. Cash equivalents and short-term investments are primarily comprised of money market funds, treasuries, agencies, high quality investment grade fixed income securities, certificates of deposit and commercial paper. Our investment policy and strategy provide for diversification of investments and is focused on the preservation of capital and supporting our liquidity requirements.

[0001628280-24-003796:mdna:100]
The total amount of cash held by the non-United States entities as of December 30, 2023 and July 1, 2023 was $260.8 million and $298.4 million, respectively, which was primarily held by entities incorporated in the United Kingdom, the British Virgin Islands, Japan, Hong Kong, China, Switzerland, the Cayman Islands, Thailand and Brazil. Although cash currently held in the United States, as well as cash generated in the United States from future operations, is expected to cover our normal operating requirements, a substantial amount of additional cash could be required for other purposes, such as capital expenditures to support our business and growth, including costs associated with increasing internal manufacturing capabilities, strategic transactions and partnerships, and future acquisitions.

[0001628280-24-003796:mdna:101]
[same as prior period, unchanged from 0001628280-23-037591:mdna:90]

[0001628280-24-003796:mdna:102]
[same as prior period, unchanged from 0001628280-23-037591:mdna:91]

[0001628280-24-003796:mdna:103]
We believe that our cash and cash equivalents as of December 30, 2023 and cash flows from our operating activities will be sufficient to meet our liquidity and capital spending requirements for at least the next 12 months, including the repayment of our 2024 Notes when they become due.

[0001628280-24-003796:mdna:104]
[same as prior period, unchanged from 0001628280-23-037591:mdna:93]

[0001628280-24-003796:mdna:105]
[same as prior period, unchanged from 0001628280-23-037591:mdna:94]

[0001628280-24-003796:mdna:106]
[same as prior period, unchanged from 0001628280-23-037591:mdna:95]

[0001628280-24-003796:mdna:107]
[same as prior period, unchanged from 0001628280-23-037591:mdna:96]

[0001628280-24-003796:mdna:108]
[same as prior period, unchanged from 0001628280-23-037591:mdna:97]

[0001628280-24-003796:mdna:109]
[same as prior period, unchanged from 0001628280-23-037591:mdna:98]

[0001628280-24-003796:mdna:110]
[same as prior period, unchanged from 0001628280-23-037591:mdna:99]

[0001628280-24-003796:mdna:111]
[same as prior period, unchanged from 0001628280-23-037591:mdna:100]

[0001628280-24-003796:mdna:112]
[same as prior period, unchanged from 0001628280-23-037591:mdna:101]

[0001628280-24-003796:mdna:113]
[same as prior period, unchanged from 0001628280-23-037591:mdna:102]

[0001628280-24-003796:mdna:114]
[same as prior period, unchanged from 0001628280-23-037591:mdna:103]

[0001628280-24-003796:mdna:115]
[same as prior period, unchanged from 0001628280-23-037591:mdna:104]

[0001628280-24-003796:mdna:116]
[same as prior period, unchanged from 0001628280-23-037591:mdna:105]

[0001628280-24-003796:mdna:117]
[same as prior period, unchanged from 0001628280-23-037591:mdna:106]

[0001628280-24-003796:mdna:118]
[same as prior period, unchanged from 0001628280-23-037591:mdna:107]

[0001628280-24-003796:mdna:119]
[same as prior period, unchanged from 0001628280-23-037591:mdna:108]

[0001628280-24-003796:mdna:120]
[same as prior period, unchanged from 0001628280-23-037591:mdna:109]

[0001628280-24-003796:mdna:121]
The following table summarizes our contractual obligations as of December 30, 2023, and the effect such obligations are expected to have on our liquidity and cash flow (in millions):

[0001628280-24-003796:mdna:122]
|  | Payments Due |
|  | Total |  | Less Than 1 Year |  | More Than 1 Year |  |  |  |  |
| Contractual Obligations |  |  |  |  |  |  |  |  |  |
| Asset retirement obligations | $ | 7.6 |  |  | $ | — |  |  | $ | 7.6 |  |  |  |  |  |
| Operating lease liabilities, including imputed interest (1) | 79.4 |  |  | 18.8 |  |  | 60.6 |  |  |  |  |  |
| Pension plan contributions (2) | 2.2 |  |  | 2.2 |  |  | — |  |  |  |  |  |
| Purchase obligations (3) | 423.8 |  |  | 372.1 |  |  | 51.7 |  |  |  |  |  |
| Convertible notes - principal (4) | 2,837.8 |  |  | 323.1 |  |  | 2,514.7 |  |  |  |  |  |
| Convertible notes - interest (4) | 90.0 |  |  | 19.3 |  |  | 70.7 |  |  |  |  |  |
| Total | $ | 3,440.8 |  |  | $ | 735.5 |  |  | $ | 2,705.3 |  |  |  |  |  |

[0001628280-24-003796:mdna:123]
(1) The amounts of operating lease liabilities do not include any sublease income amounts nor do they include payments for short-term leases or variable lease payments. As of December 30, 2023, we expect to receive sublease income of approximately $4.0 million over the sublease periods.

[0001628280-24-003796:mdna:124]
[same as prior period, unchanged from 0001628280-23-037591:mdna:113]

[0001628280-24-003796:mdna:125]
(3) Purchase obligations represent legally binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Refer to “Note 14. Commitments and Contingencies” in the notes to condensed consolidated financial statements.

[0001628280-24-003796:mdna:126]
(4) The amounts related to convertible notes include principal and interest on our 0.25% Convertible Senior Notes due 2024 (the “2024 Notes”), principal and interest on our 0.50% Convertible Senior Notes due 2026 (the “2026 Notes”), principal and interest on our 0.50% Convertible Senior Notes due 2028 (the “2028 Notes”), and principal and interest on our 1.50% Convertible Senior Notes due 2029 (the “2029 Notes”). The 2024 Notes have a maturity date of March 15, 2024, the 2026 Notes have a maturity date of December 15, 2026, the 2028 Notes have a maturity date of June 15, 2028, and the 2029 Notes have a maturity date of December 15, 2029. The principal balances of our convertible notes are reflected in the payment periods in the table above based on their respective contractual maturities assuming no conversions. Refer to “Note 9. Debt” in the notes to condensed consolidated financial statements.

[0001628280-24-003796:mdna:127]
[same as prior period, unchanged from 0001628280-23-037591:mdna:116]

[0001628280-24-003796:mdna:128]
[same as prior period, unchanged from 0001628280-23-037591:mdna:117]

[0001628280-24-003796:mdna:129]
As of December 30, 2023, the net carrying amount of our 2029 Notes of $599.0 million (principal balance of $603.7 million maturing in 2029) is presented in non-current liabilities. If the closing price of our stock exceeds $90.40 (or 130% of the conversion price of $69.54) for 20 of the last 30 trading days of any future quarter, the 2029 Notes would become convertible at the option of the holders during the subsequent fiscal quarter and the debt would be reclassified to current liabilities in our consolidated balance sheets.

[0001628280-24-003796:mdna:130]
As of December 30, 2023, our 2028 Notes of $856.2 million (which have an aggregate principal amount of $861.0 million outstanding that matures in 2028) is presented in non-current liabilities in our condensed consolidated balance sheets. If the closing price of our stock exceeds $170.34 (or 130% of the conversion price of $131.03) for 20 of the last 30 trading days of any future fiscal quarter, our 2028 Notes would become convertible at the option of the holders during the subsequent fiscal quarter and the debt would be reclassified to current liabilities in our condensed consolidated balance sheet.

[0001628280-24-003796:mdna:131]
As of December 30, 2023, our 2026 Notes of $1,046.5 million (which have an aggregate principal amount of $1,050.0 million outstanding that matures in 2026) is presented in non-current liabilities in our condensed consolidated balance sheets. If the closing price of our stock exceeds $129.08 (or 130% of the conversion price of $99.29) for 20 of the last 30 trading days of any future fiscal quarter, our 2026 Notes would become convertible at the option of the holders during the subsequent fiscal quarter and the debt would be reclassified to current liabilities in our condensed consolidated balance sheet.

[0001628280-24-003796:mdna:132]
As of December 30, 2023, our 2024 Notes of $319.7 million (which have an aggregate principal amount of $323.1 million outstanding) is presented in current liabilities in our condensed consolidated balance sheets, as the debt will mature on March 15, 2024. Since issuing the 2024 Notes, we have converted a total of approximately $1.9 million principal amount of the 2024 Notes.

[0001628280-24-003796:mdna:133]
[same as prior period, unchanged from 0001628280-23-037591:mdna:122]

[0001628280-24-003796:mdna:134]
We have a share buyback program that authorizes us to utilize up to an aggregate amount of $1.2 billion to purchase our own shares of common stock through May 2025. During the six months ended December 30, 2023, we did not repurchase any shares of our common stock. During the six months ended December 31, 2022, we repurchased 0.3 million shares of our common stock at an average price of $89.80 per share for an aggregate purchase price of $25.7 million. Since the board of directors initially approved the share buyback program, we have repurchased 7.7 million shares in aggregate at an average price of $81.66 per share for a total purchase price of $630.4 million. We recorded the $630.4 million aggregate purchase price as a reduction of retained earnings within our condensed consolidated balance sheet. All repurchased shares were retired immediately. As of December 30, 2023, we have $569.6 million remaining under the share buyback program.

[0001628280-24-003796:mdna:135]
[same as prior period, unchanged from 0001628280-23-037591:mdna:124]

[0001628280-24-003796:mdna:136]
[same as prior period, unchanged from 0001628280-23-037591:mdna:125]

[0001628280-24-003796:mdna:137]
As of December 30, 2023 and July 1, 2023, our other non-current liabilities include unrecognized tax benefit for uncertain tax positions of $70.1 million and $64.4 million, respectively. We are unable to reliably estimate the timing of future payments related to uncertain tax positions.

[0001628280-24-003796:mdna:138]
[same as prior period, unchanged from 0001628280-23-037591:mdna:127]

[0001628280-24-003796:mdna:139]
Our balance of cash and cash equivalents decreased by $389.7 million from $859.0 million as of July 1, 2023 to $469.3 million as of December 30, 2023. The decrease in cash and cash equivalents during the six months ended December 30, 2023 was due to cash used in investing activities of $377.1 million and cash used in financing activities of $8.8 million, offset by cash used in operating activities of $3.8 million.

[0001628280-24-003796:mdna:140]
[same as prior period, unchanged from 0001628280-23-037591:mdna:129]

[0001628280-24-003796:mdna:141]
Cash used in operating activities was $3.8 million during the six months ended December 30, 2023, which reflects a net loss of $167.0 million and non-cash items of $194.7 million, offset by $31.5 million of changes in our operating assets and liabilities. Changes in our operating assets and liabilities were primarily driven by a decrease in accounts payable of $51.1 million primarily due to lower purchases from our contract manufactures and linearity of payments, and a decrease in income taxes of $26.6 million primarily due annual income tax payable in Japan, offset by a decrease in accounts receivable of $18.7 million due to lower revenue and a decrease in inventories of $7.5 million primarily due to reduced inventory level in our Cloud & Networking business.

[0001628280-24-003796:mdna:142]
Cash provided by operating activities was $115.7 million during the six months ended December 31, 2022, which reflects a net loss of $32.1 million and non-cash items of $240.2 million, offset by $92.4 million of changes in our operating assets and liabilities.  Changes in our operating assets and liabilities were primarily driven by an increase in inventory by $36.4 million mainly attributable to prebuild inventory and safety stock as a result of supply constraints and a decrease in accounts payable of $45.0 million primarily due to lower purchases, offset by an increase in accrued expenses and other current and non-current liabilities of $37.1 million primarily due to $7.8 million of legal expense with respect to the pending settlement of certain non-ordinary course litigation matters and $24.8 million of acquisition and integration related costs primarily related to the NeoPhotonics acquisition and the acquisition of IPG telecom transmission product lines.

[0001628280-24-003796:mdna:143]
[same as prior period, unchanged from 0001628280-23-037591:mdna:132]

[0001628280-24-003796:mdna:144]
Cash used in investing activities of $377.1 million during the six months ended December 30, 2023 was attributable to cash used in the acquisition of Cloud Light of $700.9 million, net of cash acquired, capital expenditures of $88.8 million, and an intangible asset acquisition of $3.0 million, offset by net proceeds from sales or maturities of short-term investments of $415.4 million and proceeds from sales of property and equipment of $0.2 million.

[0001628280-24-003796:mdna:145]
Cash used in investing activities of $751.1 million during the six months ended December 31, 2022 was attributable to cash used the acquisition of NeoPhotonics and IPG product lines of $861.6 million, net of cash acquired, and capital expenditures of $62.8 million, offset by net proceeds from sales or maturities of short-term investments of $173.2 million.

[0001628280-24-003796:mdna:146]
[same as prior period, unchanged from 0001628280-23-037591:mdna:135]

[0001628280-24-003796:mdna:147]
Cash used in financing activities of $8.8 million during the six months ended December 30, 2023 was attributable to tax payments related to net share settlement of restricted stock of $16.1 million, offset by $7.3 million of proceeds from employee stock plans.

[0001628280-24-003796:mdna:148]
Cash used in financing activities of $62.7 million during the six months ended December 31, 2022 was driven by the repurchase of shares of our common stock of $35.8 million, tax payments related to net share settlement of restricted stock of $26.7 million, and $5.9 million payments of all the term loans that we assumed in connection with our merger with NeoPhotonics offset by $5.7 million proceeds from employee stock plans.
