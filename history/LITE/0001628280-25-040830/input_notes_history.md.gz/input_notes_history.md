# LITE note change history — 0001628280-25-004288 → 0001628280-25-022788


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-05-07):
[0001628280-25-022788:note_history:1]
Our purchase obligations of $635.3 million as of March 29, 2025 represent legally binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule and adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.
  (was, 2025-02-06, similarity 0.9887):
[0001628280-25-004288:note_history:1]
Our purchase obligations of $620.1 million as of December 28, 2024 represent legally binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule and adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

- changed (2025-05-07):
[0001628280-25-022788:note_history:2]
We depend on a limited number of contract manufacturers, subcontractors and suppliers for raw materials, packages and standard components. We generally purchase these single or limited source products through standard purchase orders or one-year supply agreements and have no significant long-term guaranteed supply agreements with these vendors. While we seek to maintain a sufficient safety stock of such products and maintain on-going communications with our suppliers to guard against interruptions or cessation of supply, our business and results of operations could be adversely affected by a stoppage or delay of supply, substitution of more expensive or less reliable products, receipt of defective parts or contaminated materials, increases in the price of such supplies, or our inability to obtain reduced pricing from our suppliers in response to competitive pressures. In addition, the imposition of tariffs on certain imported goods and materials may increase our costs and place upward pressure on the cost of goods sold.
  (was, 2025-02-06, similarity 0.9191):
[0001628280-25-004288:note_history:2]
We depend on a limited number of contract manufacturers, subcontractors and suppliers for raw materials, packages and standard components. We generally purchase these single or limited source products through standard purchase orders or one-year supply agreements and have no significant long-term guaranteed supply agreements with these vendors. While we seek to maintain a sufficient safety stock of such products and maintain on-going communications with our suppliers to guard against interruptions or cessation of supply, our business and results of operations could be adversely affected by a stoppage or delay of supply, substitution of more expensive or less reliable products, receipt of defective parts or contaminated materials, increases in the price of such supplies, or our inability to obtain reduced pricing from our suppliers in response to competitive pressures.

- changed (2025-05-07):
[0001628280-25-022788:note_history:3]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 29, 2025 |  | March 30, 2024 |  | March 29, 2025 |  | March 30, 2024 |
| Balance as of beginning of period | $ | 12.8 |  |  | $ | 10.1 |  |  | $ | 13.2 |  |  | $ | 6.8 |  |
| Warranties assumed in Cloud Light acquisition | — |  |  | 3.0 |  |  | 0.8 |  |  | 8.2 |  |
| Provision for warranty | 1.8 |  |  | 2.6 |  |  | 6.2 |  |  | 3.6 |  |
| Utilization of reserve, net | (1.6) |  |  | (2.2) |  |  | (7.2) |  |  | (5.1) |  |
| Balance as of end of period | $ | 13.0 |  |  | $ | 13.5 |  |  | $ | 13.0 |  |  | $ | 13.5 |  |
  (was, 2025-02-06, similarity 0.8819):
[0001628280-25-004288:note_history:3]
|  | Three Months Ended |  | Six Months Ended |
|  | December 28, 2024 |  | December 30, 2023 |  | December 28, 2024 |  | December 30, 2023 |
| Balance as of beginning of period | $ | 13.2 |  |  | $ | 5.5 |  |  | $ | 13.2 |  |  | $ | 6.8 |  |
| Warranties assumed in Cloud Light acquisition | — |  |  | 5.2 |  |  | 0.8 |  |  | 5.2 |  |
| Provision for warranty | 2.0 |  |  | 0.8 |  |  | 4.4 |  |  | 1.0 |  |
| Utilization of reserve, net | (2.4) |  |  | (1.4) |  |  | (5.6) |  |  | (2.9) |  |
| Balance as of end of period | $ | 12.8 |  |  | $ | 10.1 |  |  | $ | 12.8 |  |  | $ | 10.1 |  |

- changed (2025-05-07):
[0001628280-25-022788:note_history:4]
We are subject to a variety of claims and suits that arise from time-to-time in the ordinary course of our business. While management currently believes that resolving claims against us, individually or in the aggregate, will not have a material adverse impact on our financial position, results of operations or statements of cash flows, these matters are subject to inherent uncertainties and management’s view of these matters may change in the future. We accrue for loss contingencies when it is both probable that we will incur the loss and when we can reasonably estimate the amount of the loss or range of loss. As of March 29, 2025, the accrual for expected settlement of litigation matters was not material.
  (was, 2025-02-06, similarity 0.8747):
[0001628280-25-004288:note_history:4]
We are subject to a variety of claims and suits that arise from time-to-time in the ordinary course of our business. While management currently believes that resolving claims against us, individually or in the aggregate, will not have a material adverse impact on our financial position, results of operations or statements of cash flows, these matters are subject to inherent uncertainties and management’s view of these matters may change in the future. We accrue for loss contingencies when it is both probable that we will incur the loss and when we can reasonably estimate the amount of the loss or range of loss. As of December 28, 2024, we have accrued $1.2 million with respect to settlement of certain non-ordinary course litigation matters.

- added (2025-05-07):
[0001628280-25-022788:note_history:5]
In the normal course of business, we enter into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown, because claims may be made against us in the future, and we may record charges in the future as a result of these indemnification obligations. On March 5, 2025, we completed a sale of assets located in an entity in Shenzhen, China.  The Company has reclassified a $21.4 million unrecognized tax position to other non-current liabilities in the condensed consolidated balance sheets as of March 29, 2025 for an indemnification liability related to the sale of certain assets. This does not impact our results of operations for the three months ended March 29, 2025. We did not have any other material indemnification claims that were probable or reasonably possible.

- removed (2025-05-07):
[0001628280-25-004288:note_history:6]
In the normal course of business, we enter into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown, because claims may be made against us in the future, and we may record charges in the future as a result of these indemnification obligations. As of December 28, 2024, we did not have any material indemnification claims that were probable or reasonably possible.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2025-05-07):
[0001628280-25-022788:note_history:7]
Our business and operating results depend significantly on general market and economic conditions. The current global macroeconomic environment is volatile and continues to be adversely impacted by many factors including inflation, a dynamic supply chain and demand environment, trade wars, including heightened, scheduled, or threatened tariffs, trade restrictions including for certain rare earth minerals, and signs of a weaker macroeconomic environment impacting capital expenditures across our served markets. Additionally, instability in the global credit markets, capital expenditure reductions, unemployment and other labor issues, decline in stock markets, the instability in the geopolitical environment in many parts of the world, and the current global economic challenges continue to put pressure on our business and operating results.

- added (2025-05-07):
[0001628280-25-022788:note_history:8]
The Company is actively monitoring and assessing the ongoing global trade environment, particularly with respect to recent changes in tariff regulations. We have assessed the potential impacts of heightened restrictions and tariffs on our allowance for credit losses, the carrying value of our goodwill and other long-lived assets, inventory valuation, and revenue recognition.  While we have determined there was not a material impact to our condensed consolidated financial statements as of March 29, 2025 and for the quarter ended March 29, 2025, import tariffs implemented by the U.S. and other countries, as currently in effect and/or proposed, could have a material impact on our results for the remainder of 2025 and in the future. The impact of tariffs is dependent upon negotiations with customers and suppliers and other mitigation efforts and potential further changes in global trade policies, including higher tariffs in the U.S. or other countries.

- changed (2025-05-07):
[0001628280-25-022788:note_history:9]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Every fifth or sixth fiscal year will have a 53-week period. The additional week in a 53-week year is added to the third quarter, making such quarter consist of 14 weeks. Our fiscal 2025 is a 52-week year ending on June 28, 2025, with the quarter ended March 29, 2025 being a 13-week quarterly period. Our fiscal 2024 was a 52-week year that ended on June 29, 2024, with the quarter ended March 30, 2024 being a 13-week quarterly period.
  (was, 2025-02-06, similarity 0.9565):
[0001628280-25-004288:note_history:9]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Every fifth or sixth fiscal year will have a 53-week period. The additional week in a 53-week year is added to the third quarter, making such quarter consist of 14 weeks. Our fiscal 2025 is a 52-week year ending on June 28, 2025, with the quarter ended December 28, 2024 being a 13-week quarterly period. Our fiscal 2024 was a 52-week year that ended on June 29, 2024, with the quarter ended December 30, 2023 being a 13-week quarterly period.

- changed (2025-05-07):
[0001628280-25-022788:note_history:10]
The condensed consolidated financial statements and accompanying notes should be read in conjunction with the audited consolidated financial statements and accompanying notes included in our Annual Report on Form 10-K for the fiscal year ended June 29, 2024. There were no significant changes to our accounting policies during the nine months ended March 29, 2025.
  (was, 2025-02-06, similarity 0.9205):
[0001628280-25-004288:note_history:10]
The condensed consolidated financial statements and accompanying notes should be read in conjunction with the audited consolidated financial statements and accompanying notes included in our Annual Report on Form 10-K for the fiscal year ended June 29, 2024. There were no significant changes to our accounting policies during the six months ended December 28, 2024.

- removed (2025-05-07):
[0001628280-25-004288:note_history:11]
Our business and operating results depend significantly on general market and economic conditions. The current global macroeconomic environment is volatile and continues to be adversely impacted by inflation, a dynamic supply chain and demand environment, and signs of a weaker macroeconomic environment impacting capital expenditures across our served markets. Additionally, instability in the global credit markets, capital expenditure reductions, unemployment and other labor issues, decline in stock markets, the instability in the geopolitical environment in many parts of the world, and the current global economic challenges continue to put pressure on our business and operating results.

- removed (2025-05-07):
[0001628280-25-004288:note_history:12]
We are continuously monitoring both the current developments in the ongoing Russia-Ukraine war including the related export controls and resulting sanctions imposed on Russia and Belarus by the U.S. and other countries, and the ongoing conflicts in the Middle East. Additional factors, such as increased inflation, escalating energy prices and the related cost increases, could continue to impact the global economy and our business. Although the global implications of these wars are difficult to predict at this time, we do not presently foresee direct material adverse effects on our business.


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-05-07):
[0001628280-25-022788:note_history:13]
| March 29, 2025 |  |  | 2026 Notes (1) |  | 2028 Notes (2) |  | 2029 Notes (3) |  | Total |  |  |  |  |  |
| Principal |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |  | $ | 603.7 |  |  | $ | 2,514.7 |  |  |  |  |  |  |
| Unamortized debt discount and debt issuance costs |  |  | (2.0) |  |  | (3.6) |  |  | (3.6) |  |  | (9.2) |  |  |  |  |  |  |
| Net carrying amount of the liability component |  |  | $ | 1,048.0 |  |  | $ | 857.4 |  |  | $ | 600.1 |  |  | $ | 2,505.5 |  |  |  |  |  |  |
  (was, 2025-02-06, similarity 0.9854):
[0001628280-25-004288:note_history:13]
| December 28, 2024 |  |  | 2026 Notes (1) |  | 2028 Notes (2) |  | 2029 Notes (3) |  | Total |  |  |  |  |  |
| Principal |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |  | $ | 603.7 |  |  | $ | 2,514.7 |  |  |  |  |  |  |
| Unamortized debt discount and debt issuance costs |  |  | (2.3) |  |  | (3.9) |  |  | (3.8) |  |  | (10.0) |  |  |  |  |  |  |
| Net carrying amount of the liability component |  |  | $ | 1,047.7 |  |  | $ | 857.1 |  |  | $ | 599.9 |  |  | $ | 2,504.7 |  |  |  |  |  |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2025-05-07):
[0001628280-25-022788:note_history:14]
Our debt consists of the following:

- added (2025-05-07):
[0001628280-25-022788:note_history:15]
|  | March 29, 2025 |  | June 29, 2024 |
|  | Short-term |  | Long-term |  | Total |  | Short-term |  | Long-term |  | Total |
| Convertible notes | $ | — |  |  | $ | 2,505.5 |  |  | $ | 2,505.5 |  |  | $ | — |  |  | $ | 2,503.2 |  |  | $ | 2,503.2 |  |
| Term loans | 10.3 |  |  | 56.9 |  |  | 67.2 |  |  | — |  |  | — |  |  | — |  |
| Total | $ | 10.3 |  |  | $ | 2,562.4 |  |  | $ | 2,572.7 |  |  | $ | — |  |  | $ | 2,503.2 |  |  | $ | 2,503.2 |  |

- changed (2025-05-07):
[0001628280-25-022788:note_history:16]
The entire 2029 Notes are recorded as convertible notes, non-current in our consolidated balance sheets as of March 29, 2025 and June 29, 2024, measured at amortized cost.
  (was, 2025-02-06, similarity 0.9716):
[0001628280-25-004288:note_history:16]
The entire 2029 Notes are recorded as convertible notes, non-current in our consolidated balance sheets as of December 28, 2024 and June 29, 2024, measured at amortized cost.

- changed (2025-05-07):
[0001628280-25-022788:note_history:17]
We initially bifurcated the principal amount of the 2028 Notes into liability and equity components. The liability component of the 2028 Notes was initially valued at $629.8 million based on the contractual cash flow discounted at an appropriate comparable market on non-convertible debt borrowing rate at the date of issuance, which was 5.7%, with the equity component representing the residual amount of the proceeds of $231.2 million, which was recorded as a debt discount. Upon adoption of ASU 2020-06 in the first quarter of fiscal 2023, our 2028 Notes were accounted for as a single liability measured at amortized cost. The entire 2028 Notes are recorded as convertible notes, non-current in our consolidated balance sheets as of March 29, 2025 and June 29, 2024, measured at amortized cost.
  (was, 2025-02-06, similarity 0.9914):
[0001628280-25-004288:note_history:17]
We initially bifurcated the principal amount of the 2028 Notes into liability and equity components. The liability component of the 2028 Notes was initially valued at $629.8 million based on the contractual cash flow discounted at an appropriate comparable market on non-convertible debt borrowing rate at the date of issuance, which was 5.7%, with the equity component representing the residual amount of the proceeds of $231.2 million, which was recorded as a debt discount. Upon adoption of ASU 2020-06 in the first quarter of fiscal 2023, our 2028 Notes were accounted for as a single liability measured at amortized cost. The entire 2028 Notes are recorded as convertible notes, non-current in our consolidated balance sheets as of December 28, 2024 and June 29, 2024, measured at amortized cost.

- changed (2025-05-07):
[0001628280-25-022788:note_history:18]
In December 2019, we issued $1,050.0 million in aggregate principal amount of 0.50% Convertible Senior Notes due in 2026 (the “2026 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act. The 2026 Notes are governed by an indenture between the Company and U.S. Bank Trust Company, National Association as successor in interest to U.S. Bank National Association, as trustee (as supplemented by the First Supplemental Indenture, dated as of September 25, 2024, the “2026 Indenture”). We used approximately $196.0 million of the net proceeds of the offering to repay in full all amounts outstanding under our term loan credit facility, and a portion of the net proceeds of the offering to purchase approximately $200.0 million of our common stock concurrently with the pricing of the offering in privately negotiated transactions. The 2026 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.
  (was, 2025-02-06, similarity 0.8805):
[0001628280-25-004288:note_history:18]
In December 2019, we issued $1,050.0 million in aggregate principal amount of 0.50% Convertible Senior Notes due in 2026 (the “2026 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act. The 2026 Notes are governed by an indenture between the Company and U.S. Bank Trust Company, National Association as successor in interest to U.S. Bank National Association, as trustee (as supplemented by the First Supplemental Indenture, dated as of September 25, 2024, the “2026 Indenture”). We used approximately $196.0 million of the net proceeds of the offering to repay in full all amounts outstanding under our term loan credit facility, and a portion of the net proceeds of the offering to purchase approximately $200.0 million of our common stock concurrently with the pricing of the offering in privately

- changed (2025-05-07):
[0001628280-25-022788:note_history:19]
We initially bifurcated the principal amount of the 2026 Notes into liability and equity components. The liability component of the 2026 Notes was initially valued at $734.8 million based on the contractual cash flows discounted at an appropriate comparable market non-convertible debt borrowing rate at the date of issuance of 5.8% with the equity component representing the residual amount of the proceeds of $315.2 million, which was recorded as a debt discount. Upon adoption of ASU 2020-06 in the first quarter of fiscal 2023, our 2026 Notes were accounted for as a single liability measured at amortized cost. The entire 2026 Notes are recorded as convertible notes, non-current in our consolidated balance sheets as of March 29, 2025 and June 29, 2024, measured at amortized cost.
  (was, 2025-02-06, similarity 0.9913):
[0001628280-25-004288:note_history:19]
We initially bifurcated the principal amount of the 2026 Notes into liability and equity components. The liability component of the 2026 Notes was initially valued at $734.8 million based on the contractual cash flows discounted at an appropriate comparable market non-convertible debt borrowing rate at the date of issuance of 5.8% with the equity component representing the residual amount of the proceeds of $315.2 million, which was recorded as a debt discount. Upon adoption of ASU 2020-06 in the first quarter of fiscal 2023, our 2026 Notes were accounted for as a single liability measured at amortized cost. The entire 2026 Notes are recorded as convertible notes, non-current in our consolidated balance sheets as of December 28, 2024 and June 29, 2024, measured at amortized cost.

- changed (2025-05-07):
[0001628280-25-022788:note_history:20]
Concurrent with the issuance of the 2029 Notes in June 2023, we used $132.8 million of the net proceeds to repurchase $125.0 million aggregate principal amount of the 2024 Notes, which we accounted for as an extinguishment of liability. $13.5 million of the $132.8 million repurchase price was allocated to the conversion feature of the repurchased 2024 Notes, representing the fair value of the conversion feature at the date of the repurchase, and was recognized as a reduction of the stockholders’ equity. Additionally, since issuing the 2024 Notes, we converted a total of approximately $1.9 million of principal amount of the 2024 Notes, with less than $0.1 million of principle amount converted during the three and nine months ended March 29, 2025.
  (was, 2025-02-06, similarity 0.9607):
[0001628280-25-004288:note_history:20]
Concurrent with the issuance of the 2029 Notes in June 2023, we used $132.8 million of the net proceeds to repurchase $125.0 million aggregate principal amount of the 2024 Notes, which we accounted for as an extinguishment of liability. $13.5 million of the $132.8 million repurchase price was allocated to the conversion feature of the repurchased 2024 Notes, representing the fair value of the conversion feature at the date of the repurchase, and was recognized as a reduction of the stockholders’ equity. Additionally, since issuing the 2024 Notes, we converted a total of approximately $1.9 million of principal amount of the 2024 Notes, with less than $0.1 million of principle amount converted during the three and six months ended December 28, 2024.

- changed (2025-05-07):
[0001628280-25-022788:note_history:21]
| March 29, 2025 |  |  | 2026 Notes (1) |  | 2028 Notes (2) |  | 2029 Notes (3) |  | Total |  |  |  |  |  |
| Principal |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |  | $ | 603.7 |  |  | $ | 2,514.7 |  |  |  |  |  |  |
| Unamortized debt discount and debt issuance costs |  |  | (2.0) |  |  | (3.6) |  |  | (3.6) |  |  | (9.2) |  |  |  |  |  |  |
| Net carrying amount of the liability component |  |  | $ | 1,048.0 |  |  | $ | 857.4 |  |  | $ | 600.1 |  |  | $ | 2,505.5 |  |  |  |  |  |  |
  (was, 2025-02-06, similarity 0.9854):
[0001628280-25-004288:note_history:21]
| December 28, 2024 |  |  | 2026 Notes (1) |  | 2028 Notes (2) |  | 2029 Notes (3) |  | Total |  |  |  |  |  |
| Principal |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |  | $ | 603.7 |  |  | $ | 2,514.7 |  |  |  |  |  |  |
| Unamortized debt discount and debt issuance costs |  |  | (2.3) |  |  | (3.9) |  |  | (3.8) |  |  | (10.0) |  |  |  |  |  |  |
| Net carrying amount of the liability component |  |  | $ | 1,047.7 |  |  | $ | 857.1 |  |  | $ | 599.9 |  |  | $ | 2,504.7 |  |  |  |  |  |  |

- changed (2025-05-07):
[0001628280-25-022788:note_history:22]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 29, 2025 |  | March 30, 2024 |  | March 29, 2025 |  | March 30, 2024 |
| Contractual interest expense | $ | 4.7 |  |  | $ | 4.9 |  |  | $ | 14.0 |  |  | $ | 14.6 |  |
| Amortization of the debt discount and debt issuance costs | 0.8 |  |  | 4.1 |  |  | 2.3 |  |  | 13.8 |  |
| Total interest expense | $ | 5.5 |  |  | $ | 9.0 |  |  | $ | 16.3 |  |  | $ | 28.4 |  |
  (was, 2025-02-06, similarity 0.8402):
[0001628280-25-004288:note_history:22]
|  | Three Months Ended |  | Six Months Ended |
|  | December 28, 2024 |  | December 30, 2023 |  | December 28, 2024 |  | December 30, 2023 |
| Contractual interest expense | $ | 4.6 |  |  | $ | 4.9 |  |  | $ | 9.3 |  |  | $ | 9.7 |  |
| Amortization of the debt discount and debt issuance costs | 0.8 |  |  | 4.8 |  |  | 1.5 |  |  | 9.7 |  |
| Total interest expense | $ | 5.4 |  |  | $ | 9.7 |  |  | $ | 10.8 |  |  | $ | 19.4 |  |

- changed (2025-05-07):
[0001628280-25-022788:note_history:23]
The future interest and principal payments related to our convertible notes are as follows as of March 29, 2025 (in millions):
  (was, 2025-02-06, similarity 0.9633):
[0001628280-25-004288:note_history:23]
The future interest and principal payments related to our convertible notes are as follows as of December 28, 2024 (in millions):

- changed (2025-05-07):
[0001628280-25-022788:note_history:24]
On August 9, 2024, the Company entered into a term loan agreement (the “SMBC Term Loan”) with Sumitomo Mitsui Banking Corporation (“SMBC”). The SMBC Term Loan provides an aggregate principal amount of 6.4 billion Japanese yen (“JPY”). The loan requires monthly principal payments of approximately 53.3 million JPY, from August 31, 2024 to June 30, 2029 and interest based on a fixed annual interest rate of 0.88%, with the remaining principal of approximately 3.3 billion JPY due on the loan maturity date of July 31, 2029. Under the loan agreement, the Company cannot prepay the outstanding loan without SMBC’s approval.  In the event the Company prepays the outstanding loan with SMBC’s approval, the Company shall pay SMBC a settlement amount calculated pursuant to the terms of the loan agreement. The SMBC Term Loan is secured by the real estate owned in Sagamihara, Japan.
  (was, 2025-02-06, similarity 0.86):
[0001628280-25-004288:note_history:24]
On August 9, 2024, the Company entered into a term loan agreement with Sumitomo Mitsui Banking Corporation (“SMBC”). The SMBC term loan provides an aggregate principal amount of 6.4 billion Japanese yen (“JPY”). The loan requires monthly payments of the principal amounting to approximately 53.3 million JPY, which commenced on August 31, 2024 totaling approximately 3.1 billion JPY and interest based on a fixed annual interest rate of 0.88%, with the remaining principal of approximately 3.3 billion JPY due on the loan maturity date of July 31, 2029. Under the loan agreement, the Company cannot prepay the outstanding loan without SMBC’s approval.  In the event the Company prepays the outstanding loan with SMBC’s approval, the Company shall pay SMBC settlement money pursuant to the loan agreement. The term loan is secured by the real estate owned in Sagamihara, Japan.

- changed (2025-05-07):
[0001628280-25-022788:note_history:25]
As of March 29, 2025, the Company had $40.2 million in principal amount outstanding, of which the short-term portion of $4.3 million is recorded as current liabilities while the long-term portion of $35.9 million is recorded as long-term debt in the Company’s condensed consolidated balance sheets.
  (was, 2025-02-06, similarity 0.9737):
[0001628280-25-004288:note_history:25]
As of December 28, 2024, the Company has $39.2 million in principal amount outstanding, of which the short-term portion of $4.1 million is recorded as current liabilities while the long-term portion of $35.1 million is recorded as long-term debt in the Company’s condensed consolidated balance sheets.

- added (2025-05-07):
[0001628280-25-022788:note_history:26]
On September 20, 2024, the Company entered into a term loan agreement (the “Mizuho Term Loan”) with Mizuho Bank, Ltd. (“Mizuho”), in order to finance our planned manufacturing expansions. The Mizuho Term Loan provides for borrowings of 4.5 billion JPY with a 5-year term from the funding date September 20, 2024. The loan requires quarterly principal payments of approximately 225.0 million JPY commencing on December 20, 2024 with the final payment on September 20, 2029. The Mizuho Term Loan bears interest at a fixed annual rate of 0.90%. The Mizuho Term Loan is secured by the real estate assets owned by NeoPhotonics Semiconductor GK. The Mizuho Term Loan agreement requires that the Company and certain domestic subsidiaries comply with covenants relating to customary matters, including obtaining approval from Mizuho prior to transferring, creating a security interest, or disposing of the collateral assets; obtaining approval from Mizuho prior to a business transfer, business acquisition, corporate reorganization or changes such as mergers, company splits, share exchanges or share transfers or capital structure changes; obtaining approval from Mizuho prior to changing the Company’s indirect ownership in Lumentum Japan, Inc; and obtaining approval from Mizuho prior to a distribution of dividends by Lumentum Japan, Inc. to its shareholders.

- changed (2025-05-07):
[0001628280-25-022788:note_history:27]
As of March 29, 2025, the Company had $27.0 million in principal amount outstanding, of which the short-term portion of $6.0 million is recorded as current liabilities while the long-term portion of $21.0 million is recorded as long-term debt in the Company’s condensed consolidated balance sheets.
The SMBC Term Loan and the Mizuho Term Loan are collectively referred to as Japan Term Loans.
  (was, 2025-02-06, similarity 0.8361):
[0001628280-25-004288:note_history:27]
As of December 28, 2024, the Company has $27.1 million in principal amount outstanding, of which the short-term portion of $5.7 million is recorded as current liabilities while the long-term portion of $21.4 million is recorded as long-term debt in the Company’s condensed consolidated balance sheets.

- removed (2025-05-07):
[0001628280-25-004288:note_history:28]
negotiated transactions. The 2026 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

- removed (2025-05-07):
[0001628280-25-004288:note_history:29]
The initial conversion rate of the 2024 Notes was 16.4965 shares of common stock per $1,000 principal amount of 2024 Notes, which was equivalent to an initial conversion price of approximately $60.62 per share. The conversion rate was subject to adjustment upon the occurrence of certain specified events but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change (as defined in the 2024 Indenture) or our issuance of a notice of redemption, we were required to, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elected to convert the 2024 Notes in connection with such make-whole fundamental change or notice of redemption.

- removed (2025-05-07):
[0001628280-25-004288:note_history:30]
Prior to the close of business on the business day immediately preceding December 15, 2023, each holder of the 2024 Notes was able to convert their 2024 Notes only under the following circumstances:

- removed (2025-05-07):
[0001628280-25-004288:note_history:31]
•during any fiscal quarter (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during the period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter was greater than or equal to 130% of the applicable conversion price, or $78.80 on each applicable trading day;

- removed (2025-05-07):
[0001628280-25-004288:note_history:32]
•during the five consecutive business day period after any five consecutive trading day period (the “2024 measurement period”) in which the trading price per $1,000 principal amount of 2024 Notes for each trading day of such 2024 measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate for the 2024 Notes on each such trading day; or

- removed (2025-05-07):
[0001628280-25-004288:note_history:33]
•upon the occurrence of specified corporate events.

- removed (2025-05-07):
[0001628280-25-004288:note_history:34]
On or after December 15, 2023 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders could convert their 2024 Notes at any time. In addition, upon the occurrence of a make-whole fundamental change (as defined in the 2024 Indenture), we were required to, in certain circumstances, increase the conversion rate by a number of additional shares set forth in the 2024 Indenture for a holder that elected to convert 2024 Notes in connection with such make-whole fundamental change.

- removed (2025-05-07):
[0001628280-25-004288:note_history:35]
We could not redeem the 2024 Notes prior to their maturity date and no sinking fund was provided for the 2024 Notes. Upon the occurrence of a fundamental change (as defined in the 2024 Indenture), holders could require us to repurchase all or a portion of their 2024 Notes for cash at a price equal to 100% of the principal amount of the 2024 Notes to be repurchased, plus any accrued and unpaid interest.

- removed (2025-05-07):
[0001628280-25-004288:note_history:36]
We considered the features embedded in the 2024 Notes other than the conversion feature, including the holders’ put feature, our call feature, and the make-whole feature, and concluded that they are not required to be bifurcated and accounted for separately from the host debt instrument.

- removed (2025-05-07):
[0001628280-25-004288:note_history:37]
Prior to the Tax Matters Agreement settlement condition (“TMA settlement condition”), because we could only settle the 2024 Notes in cash, we determined that the conversion feature met the definition of a derivative liability. We separated the derivative liability from the host debt instrument based on the fair value of the derivative liability. As of the issuance date, March 8, 2017, the derivative liability fair value of $129.9 million was calculated using the binomial valuation approach. The residual principal amount of the 2024 Notes of $320.1 million before issuance costs was allocated to the debt component. We incurred approximately $7.7 million in transaction costs in connection with the issuance of the 2024 Notes. These costs were allocated to the debt component and recognized as a debt discount. We amortized the debt discount, including both the initial value of the derivative liability and the transaction costs, over the term of the 2024 Notes using the effective interest method. The effective interest rate of the 2024 Notes was 5.4% per year.

- removed (2025-05-07):
[0001628280-25-004288:note_history:38]
During fiscal 2017, we satisfied the TMA settlement condition. As such, the value of the conversion option was no longer marked-to-market and was reclassified to additional paid-in capital within stockholders’ equity on our condensed consolidated balance sheets. The value of the conversion option at the time of issuance was treated as an original issue discount for purposes of accounting for the debt component of the 2024 Notes. The debt component accreted up to the original amount over the term of the debt. The adoption of ASU 2020-06 did not change the presentation of the 2024 Notes, as the conversion feature associated with the 2024 Notes was classified within stockholders’ equity.

- removed (2025-05-07):
[0001628280-25-004288:note_history:39]
Convertible Notes - Additional Disclosures

- removed (2025-05-07):
[0001628280-25-004288:note_history:40]
On September 25, 2024, Lumentum entered into the First Supplemental Indenture to the 2029 Indenture, 2028 Indenture and 2026 Indenture, pursuant to which we irrevocably elected to settle the principal amounts of the 2029 Notes, 2028 Notes and 2026 Notes in cash. Any amounts due above the principal may be settled in cash, equity, or any combination thereof at the election of the Company.

- removed (2025-05-07):
[0001628280-25-004288:note_history:41]
On September 20, 2024, the Company entered into a loan agreement with Mizuho Bank, Ltd. (the “Mizuho Term Loan”), in order to finance our planned manufacturing expansions. The Mizuho Term Loan provides for borrowings of 4.5 billion JPY with a 5-year term from the funding date September 20, 2024. The loan requires quarterly principal payments of approximately 225.0 million JPY commencing on December 20, 2024 with the final payment on September 20, 2029. The Mizuho Term Loan bears a fixed annual interest rate of 0.90%. The term loan is secured by the real estate assets owned by NeoPhotonics Semiconductor GK. The Mizuho Term Loan agreement requires that the Company and certain domestic subsidiaries comply with covenants relating to customary matters, including obtaining prior approval from lender in case of transferring, creating a security interest, or disposing the collateral assets; obtaining prior approval from lender in case of business transfer, business acquisition, corporate reorganization or changes as mergers, company splits, share exchanges or share transfers or capital structure changes; obtaining prior approval of the lender in case Lumentum Holdings Inc. changes its indirect ownership in Lumentum Japan, Inc; and obtaining prior approval from the lender in case Lumentum Japan, Inc. distributes dividends to its shareholders.


## us-gaap:DebtSecuritiesAvailableForSaleUnrealizedLossPositionFairValueTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-05-07):
[0001628280-25-022788:note_history:42]
|  | Continuous Loss Position for More Than 12 Months |  | Continuous Loss Position for Less Than 12 Months |  | Gross Unrealized Losses |  |  |  |  |  |  |  |  |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  |  |  |  |  |  |  |  |  |
| March 29, 2025: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | — |  |  | $ | — |  |  | $ | 26.2 |  |  | $ | — |  |  | $ | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | — |  |  | — |  |  | 2.3 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 4.3 |  |  | — |  |  | 72.3 |  |  | (0.1) |  |  | (0.1) |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | — |  |  | — |  |  | 29.8 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Total | $ | 4.3 |  |  | $ | — |  |  | $ | 130.6 |  |  | $ | (0.1) |  |  | $ | (0.1) |  |  |  |  |  |  |  |  |  |
| June 29, 2024: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | 62.3 |  |  | $ | (0.3) |  |  | $ | 12.6 |  |  | $ | — |  |  | $ | (0.3) |  |  |  |  |  |  |  |  |  |
| Commercial paper | — |  |  | — |  |  | 28.6 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 133.7 |  |  | (0.5) |  |  | 90.6 |  |  | (0.2) |  |  | (0.7) |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 72.3 |  |  | (0.4) |  |  | 39.7 |  |  | (0.1) |  |  | (0.5) |  |  |  |  |  |  |  |  |  |
| Total | $ | 268.3 |  |  | $ | (1.2) |  |  | $ | 171.5 |  |  | $ | (0.3) |  |  | $ | (1.5) |  |  |  |  |  |  |  |  |  |
  (was, 2025-02-06, similarity 0.9546):
[0001628280-25-004288:note_history:42]
|  | Continuous Loss Position for More Than 12 Months |  | Continuous Loss Position for Less Than 12 Months |  | Gross Unrealized Losses |  |  |  |  |  |  |  |  |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  |  |  |  |  |  |  |  |  |
| December 28, 2024: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | — |  |  | $ | — |  |  | $ | 36.4 |  |  | $ | (0.1) |  |  | $ | (0.1) |  |  |  |  |  |  |  |  |  |
| Commercial paper | — |  |  | — |  |  | 7.1 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 31.7 |  |  | — |  |  | 104.4 |  |  | (0.5) |  |  | (0.5) |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 58.6 |  |  | — |  |  | 28.0 |  |  | (0.1) |  |  | (0.1) |  |  |  |  |  |  |  |  |  |
| Total | $ | 90.3 |  |  | $ | — |  |  | $ | 175.9 |  |  | $ | (0.7) |  |  | $ | (0.7) |  |  |  |  |  |  |  |  |  |
| June 29, 2024: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | 62.3 |  |  | $ | (0.3) |  |  | $ | 12.6 |  |  | $ | — |  |  | $ | (0.3) |  |  |  |  |  |  |  |  |  |
| Commercial paper | — |  |  | — |  |  | 28.6 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 133.7 |  |  | (0.5) |  |  | 90.6 |  |  | (0.2) |  |  | (0.7) |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 72.3 |  |  | (0.4) |  |  | 39.7 |  |  | (0.1) |  |  | (0.5) |  |  |  |  |  |  |  |  |  |
| Total | $ | 268.3 |  |  | $ | (1.2) |  |  | $ | 171.5 |  |  | $ | (0.3) |  |  | $ | (1.5) |  |  |  |  |  |  |  |  |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2025-05-07):
[0001628280-25-022788:note_history:43]
Our debt consists of the following:

- added (2025-05-07):
[0001628280-25-022788:note_history:44]
|  | March 29, 2025 |  | June 29, 2024 |
|  | Short-term |  | Long-term |  | Total |  | Short-term |  | Long-term |  | Total |
| Convertible notes | $ | — |  |  | $ | 2,505.5 |  |  | $ | 2,505.5 |  |  | $ | — |  |  | $ | 2,503.2 |  |  | $ | 2,503.2 |  |
| Term loans | 10.3 |  |  | 56.9 |  |  | 67.2 |  |  | — |  |  | — |  |  | — |  |
| Total | $ | 10.3 |  |  | $ | 2,562.4 |  |  | $ | 2,572.7 |  |  | $ | — |  |  | $ | 2,503.2 |  |  | $ | 2,503.2 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-05-07):
[0001628280-25-022788:note_history:45]
The future interest and principal payments related to our convertible notes are as follows as of March 29, 2025 (in millions):
  (was, 2025-02-06, similarity 0.9633):
[0001628280-25-004288:note_history:45]
The future interest and principal payments related to our convertible notes are as follows as of December 28, 2024 (in millions):


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2025-05-07):
[0001628280-25-022788:note_history:46]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 29, 2025 |  | March 30, 2024 |  | March 29, 2025 |  | March 30, 2024 |
|  | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |
| Cloud & Networking | $ | 365.2 |  |  | 85.9 | % |  | 313.8 |  |  | 85.6 | % |  | $ | 986.7 |  |  | 84.7 | % |  | $ | 830.2 |  |  | 79.0 | % |
| Industrial Tech | 60.0 |  |  | 14.1 | % |  | 52.7 |  |  | 14.4 | % |  | 177.6 |  |  | 15.3 | % |  | 220.7 |  |  | 21.0 | % |
| Net revenue | $ | 425.2 |  |  | 100.0 | % |  | $ | 366.5 |  |  | 100.0 | % |  | $ | 1,164.3 |  |  | 100.0 | % |  | $ | 1,050.9 |  |  | 100.0 | % |

- added (2025-05-07):
[0001628280-25-022788:note_history:47]
| Contract balances |  | Balance sheet location |  | March 29, 2025 |  | June 29, 2024 |  | Change |  | Percentage Change |
| Accounts receivable, net |  | Accounts receivable, net |  | $ | 255.7 |  |  | $ | 194.7 |  |  | $ | 61.0 |  |  | 31.3 | % |
| Deferred revenue and customer deposits |  | Other current liabilities |  | $ | 0.7 |  |  | $ | 0.6 |  |  | $ | 0.1 |  |  | 16.7 | % |

- removed (2025-05-07):
[0001628280-25-004288:note_history:48]
|  | Three Months Ended |  | Six Months Ended |
|  | December 28, 2024 |  | December 30, 2023 |  | December 28, 2024 |  | December 30, 2023 |
|  | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |
| Cloud & Networking | $ | 339.2 |  |  | 84.3 | % |  | 286.7 |  |  | 78.2 | % |  | $ | 621.5 |  |  | 84.1 | % |  | $ | 516.4 |  |  | 75.5 | % |
| Industrial Tech | 63.0 |  |  | 15.7 | % |  | 80.1 |  |  | 21.8 | % |  | 117.6 |  |  | 15.9 | % |  | 168.0 |  |  | 24.5 | % |
| Net revenue | $ | 402.2 |  |  | 100.0 | % |  | $ | 366.8 |  |  | 100.0 | % |  | $ | 739.1 |  |  | 100.0 | % |  | $ | 684.4 |  |  | 100.0 | % |

- removed (2025-05-07):
[0001628280-25-004288:note_history:49]
| Contract balances |  | Balance sheet location |  | December 28, 2024 |  | June 29, 2024 |  | Change |  | Percentage Change |
| Accounts receivable, net |  | Accounts receivable, net |  | $ | 226.9 |  |  | $ | 194.7 |  |  | $ | 32.2 |  |  | 16.5 | % |
| Deferred revenue and customer deposits |  | Other current liabilities |  | $ | 0.7 |  |  | $ | 0.6 |  |  | $ | 0.1 |  |  | 16.7 | % |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2025-05-07):
[0001628280-25-022788:note_history:50]
Subsequent to the end of the reporting period, the Company initiated a restructuring plan to reduce headcount and spending in order to focus on other market opportunities including cloud and AI markets. We recognized a charge of approximately $7.1 million during the three months ended March 29, 2025, which is included in the restructuring and related charges in our condensed consolidated statements of operations. These charges primarily consist of $5.7 million of write-off of assets including property, plant and equipment, prepayments and other current assets as well as $1.4 million of charges for other contractual commitments associated with the related site closures. The Company expects to incur further restructuring charges in the fourth quarter of fiscal year 2025 for employee severance and other personnel-related costs as a result of these actions, which we estimate to be about $5.0 million.

- removed (2025-05-07):
[0001628280-25-004288:note_history:51]
On February 3, 2025, the Company announced that the Company’s board of directors (the “Board) had appointed Michael Hurlston as President and Chief Executive Officer (“CEO”) of the Company, effective February 7, 2025. Mr. Hurlston will succeed Alan Lowe, the Company’s President and CEO, who is stepping down and retiring as President and CEO effective as of the end of day February 6, 2025. Mr. Lowe will remain on the Board until the end of the Company’s fiscal year 2025 and will serve as an advisor to the Company until December 15, 2025. Mr. Hurlston has also been appointed to the Board effective as of February 7, 2025.
