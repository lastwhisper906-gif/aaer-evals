# LITE notes — 0001628280-25-040830


## us-gaap:SubsequentEventsTextBlock

[0001628280-25-040830:notes:1]
Note 19. Subsequent Events
TBD


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001628280-25-040830:notes:2]
Portions of the information called for by Part III of this Annual Report on Form 10-K are hereby incorporated by reference from the definitive proxy statement for the registrant’s annual meeting of stockholders, which will be filed with the Securities and Exchange Commission not later than 120 days after the registrant’s fiscal year ended June 28, 2025.


## cyd:CybersecurityRiskManagementProcessesIntegratedTextBlock

[0001628280-25-040830:notes:3]
Cybersecurity risk management is an important part of and is integrated into our overall enterprise risk management framework, with cybersecurity risks being among the core enterprise risks identified for oversight by our Board of Directors (the “Board”) through our annual enterprise risk assessment.  We maintain an enterprise-wide cybersecurity risk assessment program and framework that is designed to identify, assess, and manage cybersecurity risk, vulnerabilities, and threats. The 
foundation of our cybersecurity program is based on the International Organization for Standardization (“ISO”) and the National Institute of Standards and Technology ("NIST") Cybersecurity Framework. In alignment with the concepts and principles articulated in these standards, we have implemented controls related to cybersecurity threats and incidents including monitoring, log collection and analysis, threat hunting and intelligence surveillance, and regular vulnerability scans/penetration tests.


## cyd:CybersecurityRiskManagementProcessesForAssessingIdentifyingAndManagingThreatsTextBlock

[0001628280-25-040830:notes:4]
Cybersecurity risk management is an important part of and is integrated into our overall enterprise risk management framework, with cybersecurity risks being among the core enterprise risks identified for oversight by our Board of Directors (the “Board”) through our annual enterprise risk assessment.  We maintain an enterprise-wide cybersecurity risk assessment program and framework that is designed to identify, assess, and manage cybersecurity risk, vulnerabilities, and threats. The

[0001628280-25-040830:notes:5]
foundation of our cybersecurity program is based on the International Organization for Standardization (“ISO”) and the National Institute of Standards and Technology ("NIST") Cybersecurity Framework. In alignment with the concepts and principles articulated in these standards, we have implemented controls related to cybersecurity threats and incidents including monitoring, log collection and analysis, threat hunting and intelligence surveillance, and regular vulnerability scans/penetration tests. Additionally, in furtherance of assessing, identifying, and managing material cybersecurity risks, we:

[0001628280-25-040830:notes:6]
•Leverage technology solutions designed to provide protection for our assets and detect threats in our environment;

[0001628280-25-040830:notes:7]
•Regular vulnerability assessments and penetration testing in efforts to identify, assess, and remediate weaknesses;

[0001628280-25-040830:notes:8]
•Maintain an enterprise-wide disaster recovery governance program, which includes cybersecurity-related disaster recovery policies and procedures related thereto;

[0001628280-25-040830:notes:9]
•Regularly perform cybersecurity-related disaster recovery testing designed to ensure that the Company’s mission-critical systems are recoverable, in support of our business continuity needs; and

[0001628280-25-040830:notes:10]
•Work with each of our business and corporate groups with our internal cybersecurity program to integrate cybersecurity requirements into operating environments as appropriate, which drives business strategies, budgeting, and similar processes. In addition, executive management, as well as our Board, regularly review our financial planning processes for these areas, inclusive of our cybersecurity programs.

[0001628280-25-040830:notes:11]
Changes or additions to our cybersecurity risk assessment program and related practices and procedures described above in response to cybersecurity needs are reviewed by our Cybersecurity Steering Committee (“CSC”), an executive management-level cross-functional group.

[0001628280-25-040830:notes:12]
We regularly engage independent third parties to assess our cybersecurity program and practices and to assist with risk mitigation. The effectiveness of our cybersecurity environment is regularly tested by internal personnel and these third parties. These assessments are performed in conformance with ISO standards and requirements. Enhancements to our cybersecurity program and practices are identified from assessment findings, and if deemed appropriate, implemented.

[0001628280-25-040830:notes:13]
In addition, we evaluate critical systems and applications hosted by third parties for cybersecurity risks and we also assess the security posture and features of those services. This includes review and monitoring of the third party, and inclusion of cybersecurity requirements in contractual agreements to help ensure third party services meet our standards for such providers and that the cybersecurity risks associated with the use of these services are appropriate.

[0001628280-25-040830:notes:14]
For additional information regarding whether any risks from cybersecurity threats are reasonably likely to materially affect our company, including our business strategy, results of operations, or financial condition, please refer to Item 1A, “Risk Factors - Any failure, disruption or security breach or incident of or impacting our information technology infrastructure or information management systems could have an adverse impact on our business and operations.” We believe that risks from prior cybersecurity threats, including as a result of any previous cybersecurity incidents, have not materially affected our business to date. However, we can provide no assurance that there will not be incidents in the future or that they will not materially affect us, including our business strategy, results of operations, or financial condition.


## cyd:CybersecurityRiskManagementPositionsOrCommitteesResponsibleTextBlock

[0001628280-25-040830:notes:15]
Our Board oversees our enterprise risk management program and practices, and the Audit Committee assists the Board in its oversight of cybersecurity matters. Quarterly updates are presented to our Audit Committee by our Chief Information Security Officer (“CISO”) on cybersecurity risks and threats. In addition, our Audit Committee provides Board-level oversight for management’s actions with respect to practices, procedures and controls used to identify, assess, and manage our key cybersecurity programs and risks, and, as necessary, responses to any significant cybersecurity incidents.

[0001628280-25-040830:notes:16]
Our cybersecurity program is led by our CISO, who manages a team of cybersecurity professionals.  Our CISO has over 20 years of experience in cybersecurity and technology, including as a CISO at another public company. Members of our cybersecurity team, combined, have over 80 years of cybersecurity experience and members of the team hold various professional certifications, including Certified Information Systems Security Professional (“CISSP”).

[0001628280-25-040830:notes:17]
As noted above, we also maintain a CSC, which consists of our Group Vice President, IT and CISO, Executive Vice President, Chief Financial Officer, Senior Vice President, Chief Human Resources Officer, Senior Vice President, General Counsel, Executive Vice President, Global Operations, Senior Vice President, Chief Accounting Officer, and Vice President, Internal Audit.  The CSC has the primary day to day responsibility to monitor and manage cybersecurity risks. The CSC provides oversight of cybersecurity initiatives within Lumentum and is responsible for integrating cybersecurity risk management practices with critical business processes to help ensure that cybersecurity is appropriately addressed throughout Lumentum.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001628280-25-040830:notes:18]
Note 1. Description of Business and Summary of Significant Accounting Policies

[0001628280-25-040830:notes:19]
Description of Business

[0001628280-25-040830:notes:20]
Lumentum Holdings Inc. (“we,” “us,” “our”, “Lumentum” or the “Company”) is a leading provider of optical and photonic products and is recognized as an industry leader based on revenue and market share. Our products are essential to a range of cloud, artificial intelligence and machine learning (“AI/ML”), telecommunications, consumer, and industrial end-market applications. We operate in two end-market focused reportable segments, Cloud & Networking and Industrial Tech.

[0001628280-25-040830:notes:21]
Our Cloud & Networking products comprise a comprehensive portfolio of optical and photonic chips, components, modules, and subsystems supplied to cloud data center operators, AI/ML infrastructure providers, and network equipment manufacturer customers who are building cloud data center and network infrastructures. Our products enable high-capacity optical links for cloud computing, AI/ML workloads, and data center interconnect (“DCI”) applications, as well as for communications service provider networks. Our offerings support access (local), metro (intracity), long-haul (intercity and global), and submarine (undersea) network infrastructure. Additionally, our Cloud & Networking products serve enterprise network infrastructure needs, including storage area networks (“SANs”), local area networks (“LANs”), and wide area networks (“WANs”). Demand for our products is fueled by the ongoing expansion of network capacity required to support cloud and services, AI/ML processing, streaming video, video conferencing, wireless and mobile connectivity, and the internet of things (“IoT”).

[0001628280-25-040830:notes:22]
Our Industrial Tech products include short-pulse solid-state lasers, kilowatt-class fiber lasers, diode lasers, and gas lasers, serving a wide range of end-markets applications. In the consumer market, our laser light sources are integrated into customers’ 3D sensing cameras, primarily used in mobile devices. In the industrial manufacturing market, our lasers are embedded in machine tools used for precision material processing across diverse industries, including semiconductor and microelectronics fabrication, electric vehicle and battery production, metal cutting and welding, and advanced manufacturing. Adoption of our Industrial Tech products is driven by the need to advance semiconductor and microelectronics technology roadmaps and by Industry 4.0 and 5.0 trends that emphasize greater manufacturing precision, flexibility, and sustainability.

[0001628280-25-040830:notes:23]
Basis of Presentation

[0001628280-25-040830:notes:24]
We have prepared the consolidated financial statements in accordance with U.S. generally accepted accounting principles (“GAAP”), which requires management to make estimates and assumptions that affect the amounts reported in our consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates. Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. These policies are inventory valuation, revenue recognition, income taxes, goodwill and business combinations.

[0001628280-25-040830:notes:25]
Our business and operating results depend significantly on general market and economic conditions. The current global macroeconomic environment is volatile and continues to be adversely impacted by many factors including inflation, a dynamic supply chain and demand environment, changes in trade policies, including heightened, scheduled, or threatened tariffs, trade restrictions including for certain rare earth minerals, and signs of a fluctuating macroeconomic environment.

[0001628280-25-040830:notes:26]
The Company is actively monitoring and assessing the ongoing global trade environment, particularly with respect to recent changes in tariff regulations. We have assessed the potential impacts of heightened restrictions and tariffs on our allowance for credit losses, the carrying value of our goodwill and other long-lived assets, inventory valuation, and revenue recognition.  While we have determined there was not a material impact to our consolidated financial statements as of June 28, 2025 and for the year ended June 28, 2025, import tariffs implemented by the U.S. and other countries, as currently in effect and/or proposed, could have a material impact on our results for the remainder of 2025 and in the future. The impact of tariffs is dependent on negotiations with customers and suppliers and other mitigation efforts and potential further changes in global trade policies, including higher tariffs in the U.S. or other countries.

[0001628280-25-040830:notes:27]
Fiscal Years

[0001628280-25-040830:notes:28]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Every fifth or sixth fiscal year will have a 53-week period. The additional week in a 53-week year is added to the third quarter, making such quarter consist of 14 weeks. Our fiscal years 2025, 2024 and 2023 were 52-week years, ending on June 28, 2025, June 29, 2024 and July 1, 2023, respectively.

[0001628280-25-040830:notes:29]
Principles of Consolidation

[0001628280-25-040830:notes:30]
The consolidated financial statements are prepared in accordance with GAAP and includes the accounts of Lumentum Holdings Inc. and its wholly owned subsidiaries. Intercompany transactions and balances are fully eliminated in consolidation.

[0001628280-25-040830:notes:31]
Business Combination

[0001628280-25-040830:notes:32]
On November 7, 2023, we completed the acquisition of Cloud Light Technology Limited (“Cloud Light”). On August 3, 2022, we completed the acquisition of NeoPhotonics Corporation (“NeoPhotonics”). On August 15, 2022, we completed the acquisition of IPG Photonics’ telecom transmission product lines. We have applied the acquisition method of accounting to account for these transactions in accordance with ASC Topic 805, Business Combinations. Our consolidated financial statements include the operating results of the acquired entities from the acquisition close date. Refer to “Note 4. Business Combination”.

[0001628280-25-040830:notes:33]
Summary of Significant Accounting Policies

[0001628280-25-040830:notes:34]
Our significant accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. We believe that of our significant accounting policies described below, involve a greater degree of judgment and complexity and are the most critical to aid in fully understanding and evaluating our consolidated financial statements. These policies include inventory valuation, revenue recognition, income taxes, goodwill and business combinations. For a description of our critical accounting policies, also refer to “Management’s Discussion and Analysis of Financial Condition and Results of Operations”, Critical Accounting Policies and Estimates.

[0001628280-25-040830:notes:35]
Cash Equivalents

[0001628280-25-040830:notes:36]
We consider highly liquid fixed income securities with original maturities of three months or less at the time of purchase to be cash equivalents. As of June 28, 2025, our cash equivalents consist of money market funds, U.S. Agency securities and U.S. Treasury securities.

[0001628280-25-040830:notes:37]
Short-Term Investments

[0001628280-25-040830:notes:38]
We classify our investments in debt securities as available-for-sale and record these investments at fair value. Investments with an original maturity of three months or less at the date of purchase are considered cash equivalents, while all other investments are classified as short-term based on management’s intent and ability to use the funds in current operations. Unrealized gains and losses are reported as a component of other comprehensive income (loss). Realized gains and losses are determined based on the specific identification method, and are reflected as other income (expense), net in our consolidated statements of operations.

[0001628280-25-040830:notes:39]
We regularly review our investment portfolio to identify and evaluate investments that have indicators of possible impairment. Factors considered in determining whether a loss is other-than-temporary include, but are not limited to: the length of time and extent a security’s fair value has been below its cost, the financial condition and near-term prospects of the investee, the credit quality of the security’s issuer, likelihood of recovery and our intent and ability to hold the security for a period of time sufficient to allow for any anticipated recovery in value. For our debt instruments, we also evaluate whether we have the intent to sell the security, or it is more likely than not that we will be required to sell the security before recovery of its cost basis.

[0001628280-25-040830:notes:40]
Fair Value of Financial Instruments

[0001628280-25-040830:notes:41]
We define fair value as the price that would be received from selling an asset, or paid to transfer a liability, in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities which are required to be recorded at fair value, we consider the principal or most advantageous market in which to transact and the market-based risk. We apply fair value accounting for all financial assets and liabilities that are recognized or disclosed at fair value in the financial statements on a recurring basis. The carrying amounts reported in the consolidated financial statements approximate the fair value for cash, accounts receivable, accounts payable and accrued liabilities due to their short-term nature.

[0001628280-25-040830:notes:42]
Basic and Diluted Net Income (Loss) per Common Share

[0001628280-25-040830:notes:43]
Basic income (loss) per share is computed by dividing net income available to common stockholders by the weighted average number of common shares outstanding during the reporting period. The weighted average number of shares is calculated by taking the number of shares outstanding and weighting them by the amount of time that they were outstanding. Diluted income per share reflects the potential dilution that could occur if employee equity programs and convertible notes, and other commitments to issue common stock were exercised or equity awards vest resulting in the issuance of common stock that could share in the earnings of the Company. Diluted loss per share is the same as basic loss per share during periods where net losses are incurred since the inclusion of the potential common stock equivalents would be anti-dilutive as a result of the net loss.

[0001628280-25-040830:notes:44]
Potentially dilutive common shares result from the assumed exercise of outstanding stock options, assumed vesting of outstanding equity awards, assumed issuance of stock under the employee stock purchase plan, and assumed conversion of our outstanding $1,050.0 million in aggregate principal amount of 2026 Notes, $861.0 million in aggregate principal amount of 2028 Notes, and $603.7 million in aggregate principle amount of 2029 Notes (collectively, the “convertible notes”). Upon adoption of ASU 2020-06 on July 3, 2022, we used the if-converted method for all convertible notes in the diluted net income per share calculation. On September 25, 2024, we made an irrevocable settlement method election, wherein upon conversion, we are required to satisfy our conversion obligation with respect to such converted convertible notes by delivering cash equal to the principal amount of such converted convertible notes and cash, shares of common stock or a combination of cash and shares of common stock, at our election, with respect to any conversion value in excess thereof. Therefore, the convertible notes will only be dilutive when the average share price of our stock exceeds the conversion price, as the principal will be paid in cash.

[0001628280-25-040830:notes:45]
The dilutive effect of securities from the 2015 Equity Incentive Plan is reflected in diluted earnings per share by application of the treasury stock method, which includes consideration of unamortized share-based compensation expense and the dilutive effect of in-the-money options and non-vested restricted stock units. Under the treasury stock method, the amount the employee must pay for exercising stock options and the amount of unamortized share-based compensation expense are collectively assumed to be used to repurchase hypothetical shares. An increase in the fair value of our common stock can result in a greater dilutive effect from potentially dilutive awards.

[0001628280-25-040830:notes:46]
Anti-dilutive potential shares from 2015 Equity Incentive Plan are excluded from the calculation of diluted earnings per share if their exercise price exceeded the average market price during the period or the share-based awards were determined to be anti-dilutive based on applying the treasury stock method.

[0001628280-25-040830:notes:47]
Inventory Valuation

[0001628280-25-040830:notes:48]
Inventory is recorded at standard cost, which approximates actual cost computed on a first-in, first-out basis, not in excess of net realizable value. We assess the value of our inventory on a quarterly basis and write down those inventories which are obsolete or in excess of our forecasted demand to the lower of their cost or estimated net realizable value. Our estimates of forecasted demand are based on our analysis and assumptions including, but not limited to, expected product lifecycles, product development plans and historical usage by product. Our product line management personnel play a key role in our excess review process by providing updated sales forecasts, managing product transitions and working with manufacturing to minimize excess inventory. If actual market conditions are less favorable than our forecasts, or actual demand from our customers is lower than our estimates, we may be required to record additional inventory write-downs. If actual market conditions are more favorable than anticipated, inventory previously written down may be sold, resulting in lower cost of sales and higher income from operations than expected in that period.

[0001628280-25-040830:notes:49]
Leases

[0001628280-25-040830:notes:50]
We determine if an arrangement is a lease at inception for arrangements with an initial term of more than 12 months, and classify it as either a finance or operating lease pursuant to Topic 842.

[0001628280-25-040830:notes:51]
Finance leases are generally those that allow us to substantially utilize or pay for the entire asset over its estimated useful life. Finance leases are recorded in property, plant and equipment, net, and finance lease liabilities within other current and other non-current liabilities on our consolidated balance sheets. We have lease arrangements with lease and non-lease components, and the non-lease components for our finance leases are accounted for separately, based on estimated stand-alone values, and are not included in the initial measurement of our finance lease assets and corresponding liabilities. Finance lease assets are amortized in operating expenses on a straight-line basis over the shorter of the estimated useful lives of the assets or the lease term, with the interest component included in interest expense and recognized using the effective interest method over the lease term.

[0001628280-25-040830:notes:52]
Operating leases are recorded in operating lease right-of-use assets, net, and operating lease liabilities, current and non-current on our consolidated balance sheets. For operating leases of buildings, we account for non-lease components, such as common area maintenance, as a component of the lease, and include it in the initial measurement of our operating lease assets and corresponding liabilities. Operating lease assets are amortized on a straight-line basis in operating expenses over the lease term.

[0001628280-25-040830:notes:53]
Our lease liabilities are recognized based on the present value of the remaining fixed lease payments, over the lease term, using a discount rate of similarly secured borrowings available to us. For the purpose of lease liability measurement, we consider only payments that are fixed and determinable at the time of commencement. Any variable payments that depend on an index or rate are expensed as incurred. Our lease terms may include options to extend when it is reasonably certain that we will exercise that option. Our lease assets also include any lease payments made and exclude any lease incentives received prior to commencement. Our lease assets are tested for impairment in the same manner as long-lived assets used in operations. We generally recognize sublease income on a straight-line basis over the sublease term.

[0001628280-25-040830:notes:54]
Revenue Recognition

[0001628280-25-040830:notes:55]
Pursuant to Topic 606, we recognize our revenues upon the application of the following steps:

[0001628280-25-040830:notes:56]
•identification of the contract, or contracts, with a customer;

[0001628280-25-040830:notes:57]
•identification of the performance obligations in the contract;

[0001628280-25-040830:notes:58]
•determination of the transaction price;

[0001628280-25-040830:notes:59]
•allocation of the transaction price to the performance obligations in the contract; and

[0001628280-25-040830:notes:60]
•recognition of revenues when, or as, the contractual performance obligations are satisfied.

[0001628280-25-040830:notes:61]
The majority of our revenue comes from product sales, consisting of sales of hardware products to our customers. Our revenue contracts generally include only one performance obligation. Revenues are recognized at a point in time when control of the promised goods or services are transferred to our customers upon shipment or delivery of goods or rendering of services, in an amount that reflects the consideration we expect to be entitled to in exchange for those goods or services. We have entered into vendor managed inventory (“VMI”) programs with our customers. Under these arrangements, we receive purchase orders from our customers, and the inventory is shipped to the VMI location upon receipt of the purchase order. The customer then pulls the inventory from the VMI hub based on its production needs. Revenue under VMI programs is recognized when control transfers to the customer, which is generally once the customer pulls the inventory from the hub.

[0001628280-25-040830:notes:62]
Revenue from all sales types is recognized at the transaction price. The transaction price is determined based on the consideration to which we will be entitled in exchange for transferring goods or services to the customer adjusted for estimated variable consideration, if any. We typically estimate the impact on the transaction price for discounts offered to the customers for early payments on receivables or net of accruals for estimated sales returns. These estimates are based on historical returns, analysis of credit memo data and other known factors. Actual returns could differ from these estimates. We allocate the transaction price to each distinct product based on its relative standalone selling price. The product price as specified on the purchase order is considered the standalone selling price as it is an observable input that depicts the price as if sold to a similar customer in similar circumstances.

[0001628280-25-040830:notes:63]
We exclude from revenue the taxes assessed by a governmental authority that are both imposed on and concurrent with a specific revenue-producing transaction, which are collected by us from a customer and deposited with the relevant government authority.

[0001628280-25-040830:notes:64]
Our revenue arrangements do not contain significant financing components as our standard payment terms are less than one year.

[0001628280-25-040830:notes:65]
If a customer pays consideration, or we have a right to an amount of consideration that is unconditional before we transfer a good or service to the customer, those amounts are classified as deferred revenue or deposits received from customers which are included in other current liabilities or other long-term liabilities when the payment is made or it is due, whichever is earlier.

[0001628280-25-040830:notes:66]
Transaction Price Allocated to the Remaining Performance Obligations

[0001628280-25-040830:notes:67]
Remaining performance obligations represent the transaction price allocated to performances obligations that are unsatisfied or partially unsatisfied as of the end of the reporting period. Unsatisfied and partially unsatisfied performance obligations consist of contract liabilities and non-cancellable backlog. Non-cancellable backlog includes goods and services for which customer purchase orders have been accepted that are scheduled or in the process of being scheduled for shipment. A portion of our revenue arises from vendor managed inventory arrangements where the timing and volume of customer utilization is difficult to predict.

[0001628280-25-040830:notes:68]
Deferred revenue as of June 28, 2025 and June 29, 2024 was $0.7 million and $0.6 million, respectively, which was recorded in other current liabilities in the consolidated balance sheets. During fiscal year 2025 and fiscal year 2024, we recognized $0.1 million and $2.0 million of revenue that was included in deferred revenue as of June 29, 2024 and July 1, 2023, respectively.

[0001628280-25-040830:notes:69]
Warranty

[0001628280-25-040830:notes:70]
Hardware products regularly include warranties to the end customers such that the product continues to function according to published specifications. We typically offer a twelve-month warranty for most of our products. However, in some instances depending on the product, specific market, product line and geography in which we operate, and what is common in the industry, our warranties can vary and range from six months to five years. These standard warranties are assurance type warranties and do not offer any services in addition to the assurance that the product will continue working as specified. Therefore, warranties are not considered separate performance obligations in the arrangement.

[0001628280-25-040830:notes:71]
We provide reserves for the estimated costs of product warranties that we record as cost of sales at the time revenue is recognized. We estimate the costs of our warranty obligations based on our historical experience of known product failure rates, use of materials to repair or replace defective products and service delivery costs incurred in correcting product failures. In addition, from time-to-time, specific warranty accruals may be made if discrete technical problems arise.

[0001628280-25-040830:notes:72]
Shipping and Handling Costs and Tariffs

[0001628280-25-040830:notes:73]
We record shipping and handling costs and tariffs related to revenue transactions within cost of sales as a period cost. Amounts billed to the customer for shipping and handling costs, including tariff charges, is recorded as revenue when the relevant product is recognized as revenue.

[0001628280-25-040830:notes:74]
Contract Costs

[0001628280-25-040830:notes:75]
We recognize the incremental direct costs of obtaining a contract, which consist of sales commissions, when control over the products they relate to transfers to the customer. Applying the practical expedient, we recognize commissions as expense when incurred, as the amortization period of the commission asset we would have otherwise recognized is less than one year.

[0001628280-25-040830:notes:76]
Contract Balances

[0001628280-25-040830:notes:77]
We record accounts receivable when we have an unconditional right to consideration. Contract liabilities are recorded when cash payments are received or due in advance of performance. Contract liabilities consist of advance payments and deferred revenue, where we have unsatisfied performance obligations. Contract liabilities are classified as deferred revenue and customer deposits and are included in other current liabilities within our consolidated balance sheet. Payment terms vary by customer. The time between invoicing and when payment is due is not significant. Refer to “Note 18. Revenue Recognition” for a presentation of changes in contract balances.

[0001628280-25-040830:notes:78]
Disaggregation of Revenue

[0001628280-25-040830:notes:79]
We disaggregate revenue by geography and by product. Refer to “Note 18. Revenue Recognition” for a presentation of disaggregated revenue. We do not present other levels of disaggregation, such as by type of products, customer, markets, contracts, duration of contracts, timing of transfer of control and sales channels, as this information is not used by our Chief Operating Decision Maker (“CODM”) to manage the business.

[0001628280-25-040830:notes:80]
Income Taxes

[0001628280-25-040830:notes:81]
In accordance with the authoritative guidance on accounting for income taxes, we recognize income taxes using an asset and liability approach. This approach requires the recognition of taxes payable or refundable for the current year and deferred tax liabilities and assets for the future tax consequences of events that have been recognized in our consolidated financial statements or tax returns. The measurement of current and deferred taxes is based on provisions of the enacted tax law, and the effects of future changes in tax laws or rates are not anticipated.

[0001628280-25-040830:notes:82]
The authoritative guidance provides for recognition of deferred tax assets if the realization of such deferred tax assets is more likely than not to occur based on an evaluation of both positive and negative evidence and the relative weight of the evidence. We consider future growth, forecasted earnings, future taxable income, the mix of earnings in the jurisdictions in which we operate, historical earnings, taxable income in prior years, if carry-back is permitted under the law, and prudent and feasible tax planning strategies in determining the need for a valuation allowance. In the event we were to determine that we would not be able to realize all or part of our net deferred tax assets in the future, an adjustment to the deferred tax assets valuation allowance would be charged to earnings in the period in which we make such a determination, or goodwill would be adjusted at our final determination of the valuation allowance related to an acquisition within the measurement period. If we later determine that it is more likely than not that the net deferred tax assets would be realized, we would reverse the applicable portion of the previously provided valuation allowance as an adjustment to earnings at such time.

[0001628280-25-040830:notes:83]
We are subject to income tax audits by the respective tax authorities of the jurisdictions in which we operate. The determination of our income tax liabilities in each of these jurisdictions requires the interpretation and application of complex, and sometimes uncertain, tax laws and regulations. The authoritative guidance on accounting for income taxes prescribes both recognition and measurement criteria that must be met for the benefit of a tax position to be recognized in the financial statements. If a tax position taken, or expected to be taken, in a tax return does not meet such recognition or measurement criteria, an unrecognized tax benefit liability is recorded.  If we ultimately determine that an unrecognized tax benefit liability is no longer necessary, we reverse the liability and recognize a tax benefit in the period in which it is determined that the unrecognized tax benefit liability is no longer necessary.

[0001628280-25-040830:notes:84]
The recognition and measurement of current taxes payable or refundable and deferred tax assets and liabilities requires that we make certain estimates and judgments. Changes to these estimates or a change in judgment may have a material impact on our tax provision in a future period.

[0001628280-25-040830:notes:85]
Property, Plant and Equipment

[0001628280-25-040830:notes:86]
Property, plant and equipment are stated at cost. Depreciation is computed by the straight-line method generally over the following estimated useful lives of the assets: 10 to 40 years for building and improvements, 3 to 10 years for machinery and equipment, and 2 to 5 years for furniture, fixtures, software and office equipment. Leasehold improvements are amortized using the straight-line method over the shorter of the estimated useful lives of the assets or the term of the lease, including the renewal option that we are reasonably certain to exercise.

[0001628280-25-040830:notes:87]
In accordance with the guidance for business combinations, we determine whether a transaction or event is a business combination, which requires that the assets acquired and liabilities assumed constitute a business. Each business combination is then accounted for by applying the acquisition method. If the assets acquired are not a business, we account for the transaction or event as an asset acquisition. Under both methods, we recognize the identifiable assets acquired, the liabilities assumed, and any noncontrolling interest in the acquired entity. We capitalize acquisition-related costs and fees associated with asset acquisitions and immediately expense acquisition-related costs and fees associated with business combinations.

[0001628280-25-040830:notes:88]
We allocate the fair value of purchase consideration to the tangible assets acquired, liabilities assumed and intangible assets acquired based on their estimated fair values. The excess of the fair value of purchase consideration over the fair values of these identifiable assets and liabilities is recorded as goodwill. When determining the fair values of assets acquired and liabilities assumed, we make significant estimates and assumptions, especially with respect to intangible assets. Critical estimates in valuing certain intangible assets include, but are not limited to, future expected cash flows from customer relationships and acquired developed technology and discount rates. Our estimates of fair value are based on assumptions believed to be reasonable using the best information available. These assumptions are inherently uncertain and unpredictable and, as a result, actual results may differ materially from estimates. Certain estimates associated with the accounting for acquisitions may change as additional information becomes available regarding the assets acquired and liabilities assumed. Any change in facts and circumstances that existed as of the acquisition date and impacts to our preliminary estimates is recorded to goodwill if identified within the measurement period. Subsequent to the measurement period or our final determination of fair value of assets and liabilities, whichever is earlier, the adjustments will affect our earnings.

[0001628280-25-040830:notes:89]
We estimate the economic lives of certain acquired assets and these lives are used to calculate depreciation and amortization expense. If our estimates of the economic lives change, depreciation or amortization expenses could be accelerated or slowed.

[0001628280-25-040830:notes:90]
Goodwill

[0001628280-25-040830:notes:91]
Goodwill represents the excess of the purchase price of an acquired business over the fair value of the identifiable assets acquired and liabilities assumed. We test goodwill impairment on an annual basis in the fiscal fourth quarter and at any other time when events occur or circumstances indicate that the carrying amount of goodwill may not be recoverable.

[0001628280-25-040830:notes:92]
We have the option to first assess qualitative factors to determine whether it is necessary to perform the quantitative goodwill impairment test. The qualitative factors we assess include long-term prospects of our performance, share price trends and market capitalization, and Company specific events. Unanticipated events and circumstances may occur that affect the accuracy of our assumptions, estimates and judgments. For example, if the price of our common stock were to significantly decrease combined with other adverse changes in market conditions, thus indicating that the underlying fair value of our reporting units may have decreased, we may reassess the value of our goodwill in the period such circumstances were identified.

[0001628280-25-040830:notes:93]
If we determine that, as a result of the qualitative assessment, it is more likely than not (i.e., greater than 50% likelihood) that the fair value of a reporting unit is less than its carrying amount, we perform the quantitative test by estimating the fair value of our reporting units. If the carrying value of a reporting unit exceeds its fair value, we record goodwill impairment loss equal to the excess of the carrying value of the reporting unit’s goodwill over its fair value, not to exceed the carrying amount of goodwill. The fair value of each of our goodwill reporting units is generally estimated using a combination of public company multiples and discounted cash flow methodologies.

[0001628280-25-040830:notes:94]
Based on the impairment analysis performed in the fourth quarter of each year presented, the fair value of each of our reporting units substantially exceeded the carrying value; as such, our annual qualitative assessment did not indicate that a more detailed quantitative analysis was necessary.

[0001628280-25-040830:notes:95]
Intangible Assets

[0001628280-25-040830:notes:96]
Intangible assets consist primarily of intangible assets purchased through acquisitions. Purchased intangible assets include acquired developed technologies (developed and core technology), customer relationships, and order backlog. Intangible assets, with the exception of certain customer relationships, are amortized using the straight-line method over the estimated economic useful lives of the assets, which is the period during which expected cash flows support the fair value of such intangible assets. Certain customer relationships are amortized using an accelerated method of amortization over the expected customer lives, which more accurately reflects the pattern of realization of economic benefits expected to be obtained.

[0001628280-25-040830:notes:97]
Long-lived Asset Valuation

[0001628280-25-040830:notes:98]
We test long-lived assets for recoverability, at the asset group level, when events or changes in circumstances indicate that their carrying amount may not be recoverable. Circumstances which could trigger a review include, but are not limited to: significant decreases in the market price of the asset, significant adverse changes in the business climate or legal factors, accumulation of costs significantly in excess of the amount originally expected for the acquisition or construction of the asset, current period cash flow or operating losses combined with a history of losses or a forecast of continuing losses associated with the use of the asset, or current expectation that the asset will more likely than not be sold or disposed significantly before the end of its estimated useful life.

[0001628280-25-040830:notes:99]
Recoverability is assessed based on the difference between the carrying amount of the asset and the sum of the undiscounted cash flows expected to result from the use and the eventual disposal of the asset. An impairment loss is recognized when the carrying amount is not recoverable and exceeds fair value.

[0001628280-25-040830:notes:100]
Pension Benefits

[0001628280-25-040830:notes:101]
The Company sponsors various employee retirement plans, including defined contribution, defined benefit and other post-retirement plans.  Refer to “Note 15. Employee Retirement Plans” for more information.

[0001628280-25-040830:notes:102]
The funded status of our retirement-related benefit plan is measured as the difference between the fair value of plan assets and the benefit obligation at fiscal year end, the measurement date. The funded status of an underfunded benefit plan, of which the fair value of plan assets is less than the benefit obligation, is recognized as a non-current net pension liability in the consolidated balance sheets. For defined benefit pension plans, the benefit obligation is the projected benefit obligation (“PBO”) which represents the actuarial present value of benefits expected to be paid upon retirement.

[0001628280-25-040830:notes:103]
Net periodic pension cost (income) (“NPPC”) is recorded in the consolidated statements of operations and includes service cost, interest cost, expected return on plan assets, amortization of prior service cost and gains or losses previously recognized as a component of accumulated other comprehensive income. Service cost represents the actuarial present value of participant benefits attributed to services rendered by employees in the current year. Interest cost represents the time value of money cost associated with the passage of time. Gains or losses arise as a result of differences between actual experience and assumptions or as a result of changes in actuarial assumptions. Prior service cost or credits represent the cost of benefit improvements attributable to prior service granted in plan amendments. (Gains) losses and prior service cost (credit) that arise during the current year are first recognized as a component of accumulated other comprehensive income in the consolidated balances sheets, net of tax. Prior service cost is amortized as a component of NPPC over the average remaining service period of active plan participants starting at the date the plan amendment is adopted. Deferred actuarial gains or losses are subsequently recognized as a component of NPPC if they exceed the greater of 10% of PBO or the fair value of plan assets, with the excess amortized over the average remaining service period of active plan participants.

[0001628280-25-040830:notes:104]
The measurement of the benefit obligation and NPPC is based on our estimates and actuarial valuations, provided by third-party actuaries, which are approved by management. These valuations reflect the terms of the plans and use participant-specific information such as compensation, age and years of service, as well as certain assumptions, including estimates of discount rates, expected return on plan assets, rate of compensation increases, and mortality rates. We evaluate these assumptions annually at a minimum. In estimating the expected return on plan assets, we consider historical returns on plan assets, adjusted for forward-looking considerations, inflation assumptions and the impact of the active management of the plan’s invested assets.

[0001628280-25-040830:notes:105]
Concentration of Credit and Other Risks

[0001628280-25-040830:notes:106]
Financial instruments that potentially subject our business to concentration of credit risk consist primarily of cash, short-term investments, and trade receivables.

[0001628280-25-040830:notes:107]
Although the Company deposits its cash with financial institutions that management believes are of high credit quality, its deposits, at times, may exceed federally insured limits. The Company’s investment portfolio consists of investment grade securities diversified amongst security types, industries, and issuers. The Company’s investment policy limits the amount of credit exposure in the investment portfolio by imposing credit rating minimums and limiting purchases of a single issuer, security type, geography and industry, except for Treasury securities. The Company believes no significant concentration risk exists with respect to these investments.

[0001628280-25-040830:notes:108]
We perform credit evaluations of our customers’ financial condition and generally do not require collateral from our customers. These evaluations require significant judgment and are based on a variety of factors including, but not limited to, current economic trends, payment history, bad debt write-off experience, and financial review of the customer.

[0001628280-25-040830:notes:109]
We maintain an allowance for credit losses for estimated losses resulting from the inability of our customers to make required payments. When we become aware that a specific customer is unable to meet their financial obligations, we record a specific allowance to reflect the level of credit risk in the customer’s outstanding receivable balance. In addition, we record additional allowances based on certain percentages of aged receivable balances. These percentages take into account a variety of factors including, but not limited to, current economic trends, payment history and bad debt write-off experience. We classify bad debt expenses as selling, general and administrative expense.

[0001628280-25-040830:notes:110]
During fiscal years 2025, 2024, and 2023, a few customers generated more than 10% of total net revenue. Refer to “Note 17. Operating Segments and Geographic Information” for more information.

[0001628280-25-040830:notes:111]
As of June 28, 2025, our accounts receivable from a single customer, which represented 10% or greater of the total accounts receivable, was concentrated with two customers, which represented 13% and 11% of gross accounts receivable, respectively. As of June 29, 2024, our accounts receivable from a single customer, which represented 10% or greater of the total accounts receivable, was concentrated with one customer, which represented 13% of gross accounts receivable.

[0001628280-25-040830:notes:112]
We rely on a limited number of suppliers for a number of key components contained in our products. We also rely on a limited number of significant independent contract manufacturers for the production of certain key components and subassemblies contained in our products.

[0001628280-25-040830:notes:113]
We generally use a rolling twelve months forecast based on anticipated product orders, customer forecasts, product order history and backlog to determine our materials requirements. Lead times for the parts and components that we order vary significantly and depend on factors such as the specific supplier, contract terms and demand for a component at a given time. If the forecast does not meet or if it exceeds actual demand, we may have excess or shortfalls of some materials and components, as well as excess inventory purchase commitments. We could experience reduced or delayed product shipments or incur additional inventory write-downs and cancellation charges or penalties, which would increase costs and could have a material adverse impact on our results of operations.

[0001628280-25-040830:notes:114]
Foreign Currency Translation

[0001628280-25-040830:notes:115]
In fiscal year 2019, we established the functional currency for our worldwide operations as the U.S. dollar. Translation adjustments reported prior to December 10, 2018 remain as a component of accumulated other comprehensive income (loss) in our condensed consolidated balance sheets, until all or a part of the investment in the subsidiaries is sold or liquidated. In fiscal year 2023, we acquired IPG telecom transmission product lines. The functional currency of the Brazilian entities acquired as part of this acquisition is the local currency.

[0001628280-25-040830:notes:116]
Translation adjustments reported prior to fiscal year 2019, remain as a component of accumulated other comprehensive income in our consolidated balance sheet. The translated values for any non-monetary assets and liabilities as of the date we established the U.S. dollar as the functional currency became the new accounting basis for those assets. Accordingly, monetary assets and liabilities denominated in foreign currencies have been remeasured into U.S. dollars using the exchange rates in effect at the balance sheet date. Foreign currency re-measurement gains or losses are included in other income (expense), net in the consolidated statements of operations.

[0001628280-25-040830:notes:117]
Stock-based Compensation

[0001628280-25-040830:notes:118]
Generally, compensation expense related to stock-based transactions is measured and recognized in the financial statements based on fair value at the grant date.

[0001628280-25-040830:notes:119]
Restricted stock units (“RSUs”) are grants of shares of our common stock, the vesting of which is based on the requisite service requirement. Generally, our RSUs are subject to forfeiture and expected to vest over one to four years. For new-hire grants, RSUs generally vest ratably on an annual basis over four years. For annual refresh grants, RSUs generally vest ratably on an annual, or combination of annual and quarterly, basis over three years.

[0001628280-25-040830:notes:120]
Performance stock units (“PSUs”) are grants of shares of our common stock that vest upon the achievement of certain performance and service conditions. We account for the fair value of PSUs using the closing market price of our common stock on the date of grant. We begin recognizing compensation expense when we conclude that it is probable that the performance conditions will be achieved. We reassess the probability of vesting at each reporting period and adjust our compensation cost based on this probability assessment. Our PSUs are subject to risk of forfeiture until performance and service conditions are satisfied and generally vest over three years.

[0001628280-25-040830:notes:121]
The Company granted certain employees with stock options, the vesting of which is based on the requisite service requirement and expected to vest within three years. The Company calculates the fair value of stock options using the Black-Scholes option-pricing model, which requires the Company to make estimates of assumptions such as expected volatility, expected term, risk-free interest rate, expected dividend yield, and forfeiture rates.

[0001628280-25-040830:notes:122]
We estimate the fair value of the rights to acquire stock under our 2015 Employee Stock Purchase Plan (the “2015 Purchase Plan”) using the Black-Scholes option pricing formula. Our 2015 Purchase Plan provides for consecutive six-month offering periods. We recognize such compensation expense on a straight-line basis over the requisite service period. We calculate the volatility factor based on our historical stock prices.

[0001628280-25-040830:notes:123]
Restructuring and Related Charges

[0001628280-25-040830:notes:124]
Costs associated with restructuring activities are recognized when they are obligated. However, in the case of leases, the expense is estimated and accrued when the property is vacated. Given the significance of, and the timing of the execution of such activities, this process is complex and involves periodic reassessments of estimates made from the time the property was vacated, including evaluating real estate market conditions for expected vacancy periods and sub-lease income. We recognize a liability for post-employment benefits for workforce reductions related to restructuring activities when payment is probable and the amount is reasonably estimable. Restructuring and related charges may also include charges related to write-offs of long lived assets related to significant restructuring initiatives.

[0001628280-25-040830:notes:125]
We continually evaluate the adequacy of the remaining liabilities under our restructuring initiatives. Although we believe that these estimates accurately reflect the costs of our restructuring plans, actual results may differ, thereby requiring us to record additional provisions or reverse a portion of such provisions.

[0001628280-25-040830:notes:126]
Refer to “Note 12. Restructuring and Related Charges”.

[0001628280-25-040830:notes:127]
Research and Development (“R&D”) Expense

[0001628280-25-040830:notes:128]
Costs related to R&D, which primarily consists of labor and benefits, supplies, facilities, consulting and outside service fees, are charged to expense as incurred.

[0001628280-25-040830:notes:129]
Loss Contingencies

[0001628280-25-040830:notes:130]
We are subject to the possibility of various loss contingencies arising in the ordinary course of business. We consider the likelihood of loss or impairment of an asset or the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss in determining loss contingencies. An estimated loss is accrued when it is probable that an asset has been impaired or a liability has been incurred and the amount of loss can be reasonably estimated. We regularly evaluate current information available to determine whether such accruals should be adjusted and whether new accruals are required.

[0001628280-25-040830:notes:131]
Asset Retirement Obligations (“ARO”)

[0001628280-25-040830:notes:132]
Our ARO are legal obligations associated with the retirement of long-lived assets pertaining to leasehold improvements. These liabilities are initially recorded at fair value and the related asset retirement costs are capitalized by increasing the carrying amount of the related assets by the same amount as the liability. Asset retirement costs are subsequently depreciated over the useful lives of the related assets. Subsequent to initial recognition, we record period-to-period changes in the ARO liability resulting from the passage of time and revisions to either the timing or the amount of the original estimate of undiscounted cash flows. We de-recognize ARO liabilities when the related obligations are settled.


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0001628280-25-040830:notes:133]
We determine fair value based on the fair value hierarchy, which requires an entity to maximize the use of observable inputs and minimize the use of unobservable inputs when measuring fair value. Fair value is defined as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. The fair value assumes that the transaction to sell the asset or transfer the liability occurs in the principal or most advantageous market for the asset or liability and establishes that the fair value of an asset or liability shall be determined based on the assumptions that market participants would use in pricing the asset or liability. The classification of a financial asset or liability within the hierarchy is based on the lowest level input that is significant to the fair value measurement. The fair value hierarchy prioritizes the inputs into three levels that may be used to measure fair value:

[0001628280-25-040830:notes:134]
| Level 1: | Inputs are unadjusted quoted prices in active markets for identical assets or liabilities. |
| Level 2: | Inputs are quoted prices for similar assets and liabilities in active markets or inputs that are observable for the asset or liability, either directly or indirectly through market corroboration, for substantially the full term of the financial instrument. |
| Level 3: | Inputs are unobservable inputs based on our assumptions. |

[0001628280-25-040830:notes:135]
The fair value of our Level 1 financial instruments, such as money market funds and U.S. Treasury securities, which are traded in active markets, is based on quoted market prices for identical instruments. The fair value of our Level 2 fixed income securities is obtained from an independent pricing service, which may use quoted market prices for identical or comparable instruments or model driven valuations using observable market data or inputs corroborated by observable market data. Our marketable securities are held by custodians who obtain investment prices from a third-party pricing provider that incorporates standard inputs in various asset price models. Our procedures include controls to ensure that appropriate fair values are recorded, including comparing the fair values obtained from our pricing service against fair values obtained from another independent source.

[0001628280-25-040830:notes:136]
Our pension assets consist of multiple institutional funds (“pension funds”) of which the fair values are based on the quoted prices of the underlying funds. Pension funds are primarily classified as Level 2 assets since such funds are not directly traded in active markets. Refer to “Note 15. Employee Retirement Plans.”

[0001628280-25-040830:notes:137]
Assets Measured at Fair Value on a Non-Recurring Basis

[0001628280-25-040830:notes:138]
We periodically review our intangible and other long-lived assets for impairment whenever events or changes in circumstances indicate that the carrying amount of such assets may not be recoverable. Determination of recoverability is based on the lowest level of identifiable estimated undiscounted cash flows resulting from use of the asset and its eventual disposition. If not recoverable, an impairment loss would be calculated based on the excess of the carrying amount over the fair value.
Management utilizes various valuation methods, including an income approach, a market approach and a cost approach, to estimate the fair value of intangibles and other long-lived assets.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0001628280-25-040830:notes:139]
Contract Balances
We record accounts receivable when we have an unconditional right to consideration. Contract liabilities are recorded when cash payments are received or due in advance of performance. Contract liabilities consist of advance payments and deferred revenue, where we have unsatisfied performance obligations. Contract liabilities are classified as deferred revenue and customer deposits and are included in other current liabilities within our consolidated balance sheet. Payment terms vary by customer. The time between invoicing and when payment is due is not significant.
Disaggregation of Revenue
We disaggregate revenue by geography and by product. Refer to “Note 18. Revenue Recognition” for a presentation of disaggregated revenue. We do not present other levels of disaggregation, such as by type of products, customer, markets, contracts, duration of contracts, timing of transfer of control and sales channels, as this information is not used by our Chief Operating Decision Maker (“CODM”) to manage the business.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001628280-25-040830:notes:140]
Note 2. Recently Issued Accounting Pronouncements

[0001628280-25-040830:notes:141]
Accounting Pronouncements Recently Adopted

[0001628280-25-040830:notes:142]
In November 2023, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) No. 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures, which updates reportable segment disclosure requirements primarily through enhanced disclosures about significant segment expenses. ASU No. 2023-07 does not change how a public entity identifies its operating segments, aggregates those operating segments, or applies quantitative thresholds to determine its reportable segments. The update is effective for fiscal years beginning after December 15, 2023 and interim periods within fiscal years beginning after December 15, 2024, with early adoption permitted. The amendments should be applied retrospectively to all prior periods presented in the financial statements. The Company adopted ASU No. 2023-07 during the fiscal year ended June 28, 2025, and applied the guidance retrospectively to all periods presented. The adoption of this standard only impacts disclosures and did not have a material impact to the Company’s consolidated financial statements.  Refer to “Note 17. Operating Segments and Geographic Information” for further details.

[0001628280-25-040830:notes:143]
Accounting Pronouncements Not Yet Effective

[0001628280-25-040830:notes:144]
In May 2025, the FASB issued ASU No. 2025-04, Compensation - Stock Compensation (Topic 718) and Revenue from Contracts with Customers (Topic 606), which is intended to reduce diversity in practice and improve existing guidance, primarily by revising the definition of a “performance condition” and eliminating forfeiture policy election for service conditions associated with share-based consideration payable to a customer. In addition, ASU No. 2025-04 clarifies that the guidance in ASC 606 on the variable consideration constraints does not apply to share-based consideration payable to a customer regardless of whether an award’s grant date has occurred (as determined under ASC 718). ASU No. 2025-04 is effective for fiscal years beginning after December 15, 2026, with early adoption permitted. We plan to adopt ASU No. 2025-04 in the first quarter of fiscal year 2027. We are currently evaluating the impact of this ASU on our financial statements and disclosures.

[0001628280-25-040830:notes:145]
In May 2025, the FASB issued ASU No. 2025-03, Business Combinations (Topic 805) and Consolidation (Topic 810), which revises the guidance in ASC 805 to clarify that, in determining the accounting acquirer in a business combination that is effected primarily by exchanging equity interests in which a VIE is acquired, an entity would be required to consider the factors in ASC 805-10-55-12 through 55-15. Previously, the accounting acquirer in such transactions was always the primarily beneficiary. ASU No. 2025-03 is effective for fiscal years beginning after December 15, 2026, with early adoption permitted. We plan to adopt ASU No. 2025-04 in the first quarter of fiscal year 2027. We are currently evaluating the impact of this ASU on our financial statements and disclosures.

[0001628280-25-040830:notes:146]
In November 2024, the FASB issued ASU No. 2024-03, Reporting Comprehensive Income - Expense Disaggregation Disclosures (Subtopic 220-40), which requires disaggregation of certain expense captions into specified categories in disclosures within the footnotes to the financial statements. In January 2025, the FASB issued ASU No. 2025-01, which revises the effective date of ASU No. 2024-03, to clarify that all public business entities are required to adopt the guidance in annual reporting periods beginning after December 15, 2026, and interim periods within annual reporting periods beginning after December 15, 2027, with early adoption permitted.  We plan to adopt ASU No. 2024-04 in the first quarter of fiscal year 2027. We are currently evaluating the impact of this ASU on our financial statements and disclosures.

[0001628280-25-040830:notes:147]
In November 2024, the FASB issued ASU No. 2024-04, Debt with Conversion and Other Options (Subtopic 470-20): Induced Conversions of Convertible Debt Instruments, which clarify the requirements related to accounting for the settlement of a debt as an induced conversion. ASU No. 2024-04 is intended to improve the relevance and consistency in application of the induced conversion guidance in Subtopic 470-20 for convertible debt instruments with cash conversion features and debt instruments that are not currently convertible. ASU No. 2024-04 is effective for fiscal years beginning after December 15, 2025, with early adoption permitted. We plan to adopt ASU No. 2024-04 in the first quarter of fiscal year 2027. We are currently evaluating the impact of this ASU on our financial statements and disclosures.

[0001628280-25-040830:notes:148]
In March 2024, the FASB issued ASU No. 2024-02: Codification Improvements - Amendments to Remove References to the Concepts Statements, which contains amendments to the Codification that remove references to various FASB Concepts Statements.  ASU No. 2024-02 is effective for fiscal years beginning after December 15, 2024, with early adoption permitted. We do not expect this ASU to have a material impact on our consolidated financial statements and disclosures.

[0001628280-25-040830:notes:149]
In December 2023, the FASB issued ASU No. 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures, which requires disaggregated information about a reporting entity’s effective tax rate reconciliation as well as information on income tax paid. ASU No. 2023-09 is effective for fiscal years beginning after December 15, 2024, with early adoption permitted. We do not plan to early adopt and the standard will become effective for the Company for fiscal year 2026.


## us-gaap:EarningsPerShareTextBlock

[0001628280-25-040830:notes:150]
Note 3. Earnings Per Share

[0001628280-25-040830:notes:151]
The following table sets forth the computation of basic and diluted net income (loss) per share (in millions, except per share data):

[0001628280-25-040830:notes:152]
|  | Years Ended |
|  | June 28, 2025 |  | June 29, 2024 |  |  |  | July 1, 2023 |
| Numerator: |  |  |  |  |  |  |  |
| Net income (loss) - basic and diluted | $ | 25.9 |  |  | $ | (546.5) |  |  |  |  | $ | (131.6) |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted average common shares outstanding - basic | 69.0 |  |  | 67.3 |  |  |  |  | 68.3 |  |
| Effect of dilutive securities from stock-based benefit plans | 0.6 |  |  | — |  |  |  |  | — |  |
| Weighted average common shares outstanding - diluted | 69.6 |  |  | 67.3 |  |  |  |  | 68.3 |  |
| Net income (loss) per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.38 |  |  | $ | (8.12) |  |  |  |  | $ | (1.93) |  |
| Diluted | $ | 0.37 |  |  | $ | (8.12) |  |  |  |  | $ | (1.93) |  |

[0001628280-25-040830:notes:153]
Shares from stock-based benefit plans and shares issuable assuming conversion of our convertible notes are anti-dilutive for the years ended June 29, 2024 and July 1, 2023, therefore excluded from the calculation of diluted net loss per share, as the Company had net loss for these periods. For the year ended June 28, 2025, the Company had net loss during the first three quarters, and therefore shares from stock-based benefit plans and shares issuable assuming conversion of our convertible notes were included in the weighted average only for the fourth quarter of fiscal year 2025.

[0001628280-25-040830:notes:154]
Average anti-dilutive shares excluded from the calculation of diluted net income per share for the year ended June 28, 2025 include 4.4 million shares issuable under restricted stock units (“RSUs”) and performance stock units (“PSUs”), 0.1 million shares issuable under the 2015 Purchase Plan (the “ESPP”) and 0.8 million shares outstanding related to stock options. In addition, the calculation of diluted net income per share for the year ended June 28, 2025 excludes the impact of our convertible notes under the if-converted method.

[0001628280-25-040830:notes:155]
Average anti-dilutive shares excluded from the calculation of diluted net loss per share for the year ended June 29, 2024 include 29.6 million shares related to the convertible notes, 4.1 million shares issuable under RSUs and PSUs and 0.2 million shares issuable under the ESPP and 1.1 million shares outstanding related to stock options.

[0001628280-25-040830:notes:156]
Average anti-dilutive shares excluded from the calculation of diluted net loss per share for the year ended July 1, 2023 include 24.8 million shares related to convertible notes, 3.2 million shares issuable under RSUs and PSUs and 0.2 million shares issuable under the ESPP. Refer to “Note 14. Equity”.

[0001628280-25-040830:notes:157]
As a result of our adoption of ASU No. 2020-06 in the first quarter of fiscal year 2023, potentially dilutive common shares issuable upon conversion of our outstanding convertible notes are determined using the if-converted method.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001628280-25-040830:notes:158]
Note 4. Business Combination

[0001628280-25-040830:notes:159]
Cloud Light Acquisition

[0001628280-25-040830:notes:160]
On October 29, 2023, we entered into a definitive merger agreement (the “Merger Agreement”) with Cloud Light. On November 7, 2023, we completed the acquisition of Cloud Light (the “Cloud Light Closing Date”). Cloud Light designs, markets, and manufactures advanced optical modules for data center applications. This acquisition enabled us to be well-positioned to serve the growing needs of Cloud & Networking customers, particularly those customers focused on optimizing their data center infrastructure for the demands of AI/ML.

[0001628280-25-040830:notes:161]
We have applied the acquisition method of accounting in accordance with ASC 805 Business Combinations, with respect to the fair value of purchase price consideration and the identifiable assets and liabilities of Cloud Light, which have been measured at estimated fair value as of the Cloud Light Closing date. The following table summarizes the purchase price consideration (in millions):

[0001628280-25-040830:notes:162]
|  | Fair Value |
| Cash consideration (1) | $ | 705.0 |  |
| Share-based consideration (2) | 23.5 |  |
| Total purchase price consideration | $ | 728.5 |  |

[0001628280-25-040830:notes:163]
(1) Under the terms of the Merger Agreement, Cloud Light stockholders received $1.69 per share after adjusting for applicable withholding taxes, escrow fund and expense fund contributions, for each of the 409.4 million of shares outstanding at the Cloud Light Closing date. As a result, we transferred $691.7 million of cash consideration on the Cloud Light Closing date. Additionally, each of Cloud Light’s outstanding options was exchanged for a combination of up-front cash consideration and newly issued options (the “replacement options”). As a result, we transferred $13.3 million of cash consideration on the Cloud Light Closing date.

[0001628280-25-040830:notes:164]
(2) The replacement options have a total fair value of $38.9 million as of the Cloud Light Closing date, of which $23.5 million attributable to pre-acquisition service is recorded as part of the purchase price consideration and the remaining $15.4 million is recorded as post-acquisition stock-based compensation expense over the vesting period of three years from the Cloud Light Closing date. In general, these options expire within 10 years from the Cloud Light Closing date. Refer to “Note 14. Equity”.

[0001628280-25-040830:notes:165]
The cash consideration of $705.0 million, which was funded by the cash balances of Lumentum, includes $75.8 million of cash held in an escrow fund to support Cloud Light’s indemnification obligations under the Merger Agreement and customary adjustment for working capital. Since the measurement period expired, any future adjustments will be included in our earnings.  No amount of the escrow funds have been released as the parties have not mutually agreed on the indemnification obligation and working capital adjustment.

[0001628280-25-040830:notes:166]
We incurred a total of $9.6 million of acquisition-related costs the year ended June 29, 2024, representing professional and other direct acquisition costs, which are recorded as selling, general and administrative expense in the consolidated statement of operations when incurred.

[0001628280-25-040830:notes:167]
We allocated the fair value of the purchase price consideration to the assets acquired and liabilities assumed as of the Cloud Light Closing date based on their estimated fair values. The excess of purchase price consideration over the fair value of net assets acquired is recorded as goodwill. Our final allocation of the purchase price consideration to the assets acquired and liabilities assumed as of the Cloud Light Closing date is as follows (in millions):

[0001628280-25-040830:notes:168]
|  | Fair Value |
| Total purchase price consideration | $ | 728.5 |  |
| Assets acquired |  |
| Cash and cash equivalents | 4.1 |  |
| Short-term investments | 1.0 |  |
| Accounts receivable, net | 20.9 |  |
| Inventories | 72.8 |  |
| Prepayments and other current assets | 14.2 |  |
| Property, plant and equipment, net | 62.5 |  |
| Operating lease right-of-use assets, net | 3.7 |  |
| Other intangible assets, net (1) | 333.0 |  |
| Other non-current assets | 0.3 |  |
| Total assets | 512.5 |  |
| Liabilities assumed |  |
| Accounts payable | 45.5 |  |
| Accrued payroll and related expenses | 5.6 |  |
| Accrued expenses | 7.9 |  |
| Operating lease liabilities, current | 1.8 |  |
| Other current liabilities | 10.3 |  |
| Operating lease liabilities, non-current | 1.9 |  |
| Deferred tax liability | 60.6 |  |
| Other non-current liabilities | 16.2 |  |
| Total liabilities | 149.8 |  |
| Goodwill | $ | 365.8 |  |

[0001628280-25-040830:notes:169]
(1) Other intangible assets include developed technology of $170.0 million, customer relationship of $130.0 million, in-process research and development (“IPR&D”) of $16.0 million, order backlog of $14.0 million, and trade name and trademarks of $3.0 million. Refer to “Note 9. Goodwill and Other Intangible Assets”.

[0001628280-25-040830:notes:170]
Goodwill from the Cloud Light acquisition was assigned to the Cloud & Networking segment. The goodwill of $365.8 million arising from the acquisition is attributed to the expected revenue growth and synergies, including future cost efficiencies and other benefits that are expected to be generated by combining Lumentum and Cloud Light. None of the goodwill is expected to be deductible for local tax purposes. Refer to “Note 9. Goodwill and Other Intangible Assets.”

[0001628280-25-040830:notes:171]
Due to the integration of the combined businesses, including our sales and customer organizations, operations teams and manufacturing facilities, it is impracticable to determine Cloud Light’s contribution to our revenue and earnings during the year ended June 28, 2025.

[0001628280-25-040830:notes:172]
Unaudited Supplemental Pro Forma Information

[0001628280-25-040830:notes:173]
The following unaudited supplemental pro forma information presents the combined results of operations for the years ended June 28, 2025, June 29, 2024 and July 1, 2023, respectively, as if the acquisition was completed on July 3, 2022, the first day of the fiscal year 2023. The unaudited supplemental pro forma financial information presented below is not necessarily indicative of the financial position or results of operations that would have been realized if the acquisition had been completed on the date indicated. The unaudited supplemental pro forma financial information does not reflect synergies that might have been achieved, nor is it indicative of future operating results or financial position.

[0001628280-25-040830:notes:174]
The unaudited pro forma financial information includes adjustments for: (i) amortization expense that would have been recognized related to the acquired intangible assets, (ii) depreciation expense that would have been recognized related to the acquired property, plant, and equipment, (iii) amortization of inventory fair value adjustment, (iv) acquisition related costs, such as third party transaction costs and restructuring costs, (v) stock-based compensation expense and (vi) the estimated income tax effect on the unaudited pro forma adjustments.

[0001628280-25-040830:notes:175]
The unaudited supplemental pro forma financial information for the periods presented is as follows (in millions):

[0001628280-25-040830:notes:176]
|  | Years Ended |
|  | June 28, 2025 |  | June 29, 2024 |  | July 1, 2023 |
| Net revenue | $ | 1,645.0 |  |  | $ | 1,447.9 |  |  | $ | 1,961.5 |  |
| Net income | $ | 32.8 |  |  | $ | 531.7 |  |  | $ | 180.1 |  |

[0001628280-25-040830:notes:177]
NeoPhotonics Acquisition

[0001628280-25-040830:notes:178]
On August 3, 2022, we completed the acquisition of NeoPhotonics. The total purchase price consideration of $934.4 million was funded by the cash balances of the combined company. The addition of NeoPhotonics expanded our opportunity in some of the fastest growing markets for optical components used in cloud and telecom network infrastructure.

[0001628280-25-040830:notes:179]
We have applied the acquisition method of accounting in accordance with ASC Topic 805, Business Combinations to account for this transaction and recorded a goodwill of $315.3 million arising from the acquisition, which has been assigned to the Cloud & Networking segment.

[0001628280-25-040830:notes:180]
We recorded $28.7 million of merger-related costs, representing professional and other direct acquisition costs, of which $8.3 million was incurred in fiscal year 2022 and $20.4 million was incurred in fiscal year 2023, which was recorded as selling, general and administrative expense in the condensed consolidated statements of operations.

[0001628280-25-040830:notes:181]
The following unaudited supplemental pro forma information (unaudited) presents the combined results of operations for the year ended July 1, 2023, as if the acquisition was completed on July 4, 2021, the first day of fiscal year 2022. The unaudited supplemental pro forma financial information is not necessarily indicative of the financial position or results of operations that would have been realized if the acquisition had been completed on the date indicated. The unaudited supplemental pro forma financial information does not reflect synergies that might have been achieved, nor is it indicative of future operating results or financial position. The unaudited pro forma financial information includes adjustments for: (i) amortization expense that would have been recognized related to the acquired intangible assets, (ii) depreciation expense that would have been recognized related to the acquired property, plant, and equipment, (iii) amortization of inventory fair value adjustment, (iv) acquisition related costs, such as third party transaction costs and restructuring costs, (v) stock-based compensation expense and (vi) the estimated income tax effect on the unaudited pro forma adjustments.

[0001628280-25-040830:notes:182]
|  | Year Ended |
|  | July 1, 2023 |
| Net revenue | $ | 1,790.9 |  |
| Net loss | $ | (90.1) |  |

[0001628280-25-040830:notes:183]
Acquisition of IPG Photonics’ Telecom Transmission Product Lines

[0001628280-25-040830:notes:184]
On August 15, 2022 (“IPG Closing date”), we completed a transaction to acquire IPG Photonics’ telecom transmission product lines (“IPG telecom transmission product lines”) that are used to develop and market products for use in telecommunications and datacenter infrastructure, including Digital Signal Processors (DSPs), ASICs and optical transceivers with a total purchase price of $55.9 million, which was paid in cash.

[0001628280-25-040830:notes:185]
We have applied the acquisition method of accounting in accordance with ASC Topic 805, Business Combinations to account for this transaction and recorded a goodwill of $10.9 million arising from the acquisition, which has been assigned to the Cloud & Networking segment. We recorded $2.0 million of merger-related costs, representing professional and other direct acquisition costs, of which $0.4 million was incurred in fiscal year 2022 and $1.6 million was incurred in fiscal year 2023, which was recorded as selling, general and administrative expense in the consolidated statements of operations.

[0001628280-25-040830:notes:186]
The unaudited pro forma financial information from the acquisition of the IPG telecom transmission product lines, assuming the acquisition was completed on the first day of fiscal year 2022, as well as revenue and earnings generated during fiscal year 2023, were not material for disclosure purposes.


## us-gaap:CashCashEquivalentsAndShortTermInvestmentsTextBlock

[0001628280-25-040830:notes:187]
Note 5. Cash, Cash Equivalents and Short-term Investments

[0001628280-25-040830:notes:188]
The following table summarizes our cash, cash equivalents and short-term investments by category for the periods presented (in millions):

[0001628280-25-040830:notes:189]
|  | Amortized Cost |  | Gross Unrealized Gains |  | Gross Unrealized Losses |  | Fair Value |
| June 28, 2025: |  |  |  |  |  |  |  |
| Cash | $ | 349.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 349.5 |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | 2.5 |  |  | — |  |  | — |  |  | 2.5 |  |
| Money market funds | 161.7 |  |  | — |  |  | — |  |  | 161.7 |  |
| U.S. Treasury securities | 7.0 |  |  | — |  |  | — |  |  | 7.0 |  |
| Total cash and cash equivalents | $ | 520.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 520.7 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Commercial paper | 2.7 |  |  | — |  |  | — |  |  | 2.7 |  |
| Corporate debt securities | 210.9 |  |  | 0.3 |  |  | (0.1) |  |  | 211.1 |  |
| U.S. Agency securities | 67.6 |  |  | 0.1 |  |  | — |  |  | 67.7 |  |
| U.S. Treasury securities | 74.8 |  |  | 0.1 |  |  | — |  |  | 74.9 |  |
| Total short-term investments | $ | 356.0 |  |  | $ | 0.5 |  |  | $ | (0.1) |  |  | $ | 356.4 |  |
| June 29, 2024: |  |  |  |  |  |  |  |
| Cash | $ | 196.9 |  |  | $ | — |  |  | $ | — |  |  | $ | 196.9 |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | 15.9 |  |  | — |  |  | — |  |  | 15.9 |  |
| Money market funds | 223.9 |  |  | — |  |  | — |  |  | 223.9 |  |
| Total cash and cash equivalents | $ | 436.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 436.7 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 0.8 |  |  | $ | — |  |  | $ | — |  |  | $ | 0.8 |  |
| Commercial paper | 12.6 |  |  | — |  |  | — |  |  | 12.6 |  |
| Corporate debt securities | 244.5 |  |  | — |  |  | (0.6) |  |  | 243.9 |  |
| U.S. Agency securities | 81.2 |  |  | — |  |  | (0.3) |  |  | 80.9 |  |
| U.S. Treasury securities | 112.6 |  |  | — |  |  | (0.5) |  |  | 112.1 |  |
| Total short-term investments | $ | 451.7 |  |  | $ | — |  |  | $ | (1.4) |  |  | $ | 450.3 |  |

[0001628280-25-040830:notes:190]
We review our investment portfolio to identify and evaluate investments that have indicators of possible impairment. Factors considered in determining whether a loss is other-than-temporary include, but are not limited to, the length of time and extent a security’s fair value has been below its cost, the financial condition and near-term prospects of the investee, the credit quality of the security’s issuer, likelihood of recovery and our intent and ability to hold the security for a period sufficient to allow for any anticipated recovery in value. For the debt instruments we own, we also evaluate whether we have the intent to sell the security or whether it is more likely than not that we will be required to sell the security before recovery of its cost basis. We have not recorded our unrealized losses on our short-term investments into income because we do not intend to sell nor is it more likely than not that we will be required to sell these investments prior to recovery of their amortized cost basis.

[0001628280-25-040830:notes:191]
We use the specific-identification method to determine any realized gains or losses from the sale of our short-term investments classified as available-for-sale. During fiscal years 2025, 2024 and 2023, we did not realize significant gains or losses on a gross level from the sale of our short-term investments classified as available-for-sale.

[0001628280-25-040830:notes:192]
The components of other income, net are as follows for the years presented (in millions):

[0001628280-25-040830:notes:193]
|  |  |  | Years Ended |
|  |  |  | June 28, 2025 |  | June 29, 2024 |  | July 1, 2023 |
| Foreign exchange gains (losses), net |  |  | $ | (4.2) |  |  | $ | 0.8 |  |  | $ | 7.0 |  |
| Interest and investment income |  |  | 34.4 |  |  | 61.3 |  |  | 40.8 |  |
| Other income (losses), net |  |  | — |  |  | — |  |  | 1.0 |  |
| Other income, net |  |  | $ | 30.2 |  |  | $ | 62.1 |  |  | $ | 48.8 |  |

[0001628280-25-040830:notes:194]
Included in the interest and investment income are $5.2 million, $5.8 million and $6.7 million of interest receivable as of June 28, 2025, June 29, 2024 and July 1, 2023, respectively, recorded as prepayments and other current assets within the consolidated balance sheets. We did not recognize an allowance for credit losses against the interest receivable in any of the periods presented as there were no such losses.

[0001628280-25-040830:notes:195]
Concurrent with the issuance of the 2029 Notes in June 2023, we used $132.8 million of the net proceeds to repurchase $125.0 million aggregate principal amount of the 2024 Notes. We recognized a gain of $1.0 million, which was recorded under other income, net on our consolidated statements of operations for the year ended July 1, 2023. Refer to “Note 10. Debt”.

[0001628280-25-040830:notes:196]
The following table summarizes unrealized losses on our cash equivalents and short-term investments by category that have been in a continuous unrealized loss position for more than 12 months and less than 12 months, respectively, as of the periods presented (in millions):

[0001628280-25-040830:notes:197]
|  | Continuous Loss Position For More Than 12 Months |  | Continuous Loss Position For Less Than 12 Months |  | Gross Unrealized Losses |  |  |  |  |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  |  |  |  |  |  |  |  |  |
| June 28, 2025: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | — |  |  | $ | — |  |  | $ | 24.5 |  |  | $ | — |  |  | $ | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | — |  |  | — |  |  | 5.2 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | — |  |  | — |  |  | 73.8 |  |  | (0.1) |  |  | (0.1) |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | — |  |  | — |  |  | 35.3 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Total | $ | — |  |  | $ | — |  |  | $ | 138.8 |  |  | $ | (0.1) |  |  | $ | (0.1) |  |  |  |  |  |  |  |  |  |
| June 29, 2024: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | 62.3 |  |  | $ | (0.3) |  |  | $ | 12.6 |  |  | $ | — |  |  | $ | (0.3) |  |  |  |  |  |  |  |  |  |
| Commercial paper | — |  |  | — |  |  | 28.6 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 133.7 |  |  | (0.5) |  |  | 90.6 |  |  | (0.2) |  |  | (0.7) |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 72.3 |  |  | (0.4) |  |  | 39.7 |  |  | (0.1) |  |  | (0.5) |  |  |  |  |  |  |  |  |  |
| Total | $ | 268.3 |  |  | $ | (1.2) |  |  | $ | 171.5 |  |  | $ | (0.3) |  |  | $ | (1.5) |  |  |  |  |  |  |  |  |  |

[0001628280-25-040830:notes:198]
The following table classifies our short-term investments by remaining maturities (in millions):

[0001628280-25-040830:notes:199]
|  | June 28, 2025 |  | June 29, 2024 |
|  | Amortized Cost |  | Fair Value |  | Amortized Cost |  | Fair Value |
| Due within 1 year | $ | 139.9 |  |  | $ | 140.0 |  |  | $ | 405.5 |  |  | $ | 404.1 |  |
| Due between 1 year to 5 years | 216.1 |  |  | 216.4 |  |  | 46.2 |  |  | 46.2 |  |
|  | $ | 356.0 |  |  | $ | 356.4 |  |  | $ | 451.7 |  |  | $ | 450.3 |  |

[0001628280-25-040830:notes:200]
All available-for-sale securities have been classified as current, based on management’s intent and ability to use the funds in current operations.


## us-gaap:FairValueDisclosuresTextBlock

[0001628280-25-040830:notes:201]
Note 6. Fair Value Measurements

[0001628280-25-040830:notes:202]
Financial assets measured at fair value on a recurring basis are summarized below (in millions):

[0001628280-25-040830:notes:203]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| June 28, 2025 (1) |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | — |  |  | $ | 2.5 |  |  | $ | — |  |  | $ | 2.5 |  |
| Money market funds | 161.7 |  |  | — |  |  | — |  |  | 161.7 |  |
| U.S. Treasury securities | 7.0 |  |  |  |  |  |  | 7.0 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | — |  |  | — |  |  | — |  |
| Commercial paper | — |  |  | 2.7 |  |  | — |  |  | 2.7 |  |
| Corporate debt securities | — |  |  | 211.1 |  |  | — |  |  | 211.1 |  |
| U.S. Agency securities | — |  |  | 67.7 |  |  | — |  |  | 67.7 |  |
| U.S. Treasury securities | 74.9 |  |  | — |  |  | — |  |  | 74.9 |  |
| Total assets | $ | 243.6 |  |  | $ | 284.0 |  |  | $ | — |  |  | $ | 527.6 |  |

[0001628280-25-040830:notes:204]
(1)  Excludes $349.5 million in cash held in our bank accounts as of June 28, 2025.

[0001628280-25-040830:notes:205]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| June 29, 2024 (1) |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | — |  |  | $ | 15.9 |  |  | $ | — |  |  | $ | 15.9 |  |
| Money market funds | $ | 223.9 |  |  | $ | — |  |  | $ | — |  |  | 223.9 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | 0.8 |  |  | — |  |  | 0.8 |  |
| Commercial paper | — |  |  | 12.6 |  |  | — |  |  | 12.6 |  |
| Corporate debt securities | — |  |  | 243.9 |  |  | — |  |  | 243.9 |  |
| U.S. Agency securities |  |  | 80.9 |  |  |  |  | 80.9 |  |
| U.S. Treasury securities | 112.1 |  |  | — |  |  | — |  |  | 112.1 |  |
| Total assets | $ | 336.0 |  |  | $ | 354.1 |  |  | $ | — |  |  | $ | 690.1 |  |

[0001628280-25-040830:notes:206]
(1)  Excludes $196.9 million in cash held in our bank accounts as of June 29, 2024.

[0001628280-25-040830:notes:207]
Financial Instruments Not Recorded at Fair Value on a Recurring Basis

[0001628280-25-040830:notes:208]
We report our financial instruments at fair value with the exception of the convertible notes and term loans, see “Note 10. Debt”. The estimated fair value of the convertible notes was determined based on the trading price of the convertible notes as of the last day of trading for the period. We consider the fair value of the convertible notes to be a Level 2 measurement as they are not actively traded in markets.

[0001628280-25-040830:notes:209]
The carrying amounts and estimated fair values of our convertible notes are as follows for the periods presented (in millions):

[0001628280-25-040830:notes:210]
|  | June 28, 2025 |  | June 29, 2024 |
|  | Carrying Amount |  | Estimated Fair Value |  | Carrying Amount |  | Estimated Fair Value |
| 2029 Notes | $ | 600.2 |  |  | $ | 925.5 |  |  | $ | 599.4 |  |  | $ | 588.8 |  |
| 2028 Notes | 857.7 |  |  | 890.2 |  |  | 856.6 |  |  | 680.2 |  |
| 2026 Notes | 1,048.3 |  |  | 1,233.3 |  |  | 1,047.2 |  |  | 948.3 |  |
|  | $ | 2,506.2 |  |  | $ | 3,049.0 |  |  | $ | 2,503.2 |  |  | $ | 2,217.3 |  |

[0001628280-25-040830:notes:211]
As of June 28, 2025, the carrying amount of our term loans is not significantly different from its fair value.

[0001628280-25-040830:notes:212]
We periodically review our intangible and other long-lived assets for impairment whenever events or changes in circumstances indicate that the carrying amount of such assets may not be recoverable. Determination of recoverability is based on the lowest level of identifiable estimated undiscounted cash flows resulting from use of the asset and its eventual disposition. If not recoverable, an impairment loss would be calculated based on the excess of the carrying amount over the fair value.

[0001628280-25-040830:notes:213]
Management utilizes various valuation methods, including an income approach, a market approach and a cost approach, to estimate the fair value of intangibles and other long-lived assets. During the annual impairment testing performed in the fourth quarter of fiscal year 2025, we concluded that our intangible and other long-lived assets were not impaired. We review our intangible and other long-lived assets for impairment at least annually in the fourth quarter of each fiscal year, or any indicators of impairment exist.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001628280-25-040830:notes:214]
Note 7. Balance Sheet Details

[0001628280-25-040830:notes:215]
Allowance for current expected credit losses

[0001628280-25-040830:notes:216]
We did not have any allowance for credit losses other than our allowance for uncollectible accounts receivable. As of June 28, 2025 and June 29, 2024, the allowance for credit losses on our trade receivables were $3.5 million and $0.2 million, respectively.

[0001628280-25-040830:notes:217]
Inventories

[0001628280-25-040830:notes:218]
The components of inventories were as follows (in millions):

[0001628280-25-040830:notes:219]
|  | June 28, 2025 |  | June 29, 2024 |
| Raw materials and purchased parts | $ | 253.2 |  |  | $ | 196.9 |  |
| Work in process | 159.1 |  |  | 101.6 |  |
| Finished goods | 57.8 |  |  | 99.9 |  |
| Inventories | $ | 470.1 |  |  | $ | 398.4 |  |

[0001628280-25-040830:notes:220]
In connection with the Cloud Light Acquisition, we recorded $72.8 million of inventory as of the Cloud Light Closing date. During the year ended June 29, 2024, we amortized and recognized as cost of sales in our consolidated statements of operations the entire $8.0 million of fair value step-up of inventory acquired from Cloud Light.

[0001628280-25-040830:notes:221]
Property, plant and equipment, net

[0001628280-25-040830:notes:222]
The components of property, plant and equipment, net were as follows (in millions):

[0001628280-25-040830:notes:223]
|  | June 28, 2025 |  | June 29, 2024 |
| Land | $ | 108.6 |  |  | $ | 75.2 |  |
| Buildings and improvement | 270.4 |  |  | 215.1 |  |
| Machinery and equipment | 848.8 |  |  | 772.1 |  |
| Computer equipment and software | 39.1 |  |  | 44.9 |  |
| Furniture and fixtures | 14.7 |  |  | 14.3 |  |
| Leasehold improvements | 45.9 |  |  | 47.5 |  |
| Construction in progress | 152.3 |  |  | 71.1 |  |
|  | 1,479.8 |  |  | 1,240.2 |  |
| Less: Accumulated depreciation | (753.4) |  |  | (667.7) |  |
| Property, plant and equipment, net | $ | 726.4 |  |  | $ | 572.5 |  |

[0001628280-25-040830:notes:224]
Our construction in progress primarily includes building and improvements and machinery and equipment that we expect to place in service in the next 12 months.

[0001628280-25-040830:notes:225]
In connection with the Cloud Light acquisition, we assumed $62.5 million of property, plant and equipment as of the Cloud Light Closing date.

[0001628280-25-040830:notes:226]
On December 17, 2024, we entered into an agreement to sell our assets in an entity in Shenzhen, China. On March 5, 2025, we completed the sale and received net proceeds of $47.8 million, which was net of cash of $17.6 million and direct selling costs of $1.1 million. The net assets sold consisted primarily of building, building improvements and land rights as of December 17, 2024 with a net carrying value of $12.9 million, and were used by the Cloud and Networking segment for manufacturing and research and development activities. As a result, we recognized a gain on sale of facility of $34.9 million, which was recorded in our consolidated statements of operations for the year ended June 28, 2025. We paid $4.4 million of withholding taxes on this sale transaction, which is recorded as part of the income tax provision for the year ended June 28, 2025. We also incurred $0.7 million of indirect selling expenses related to this transaction, which was recorded as part of selling, general and administrative expenses in our consolidated statements of operations for the year ended June 28, 2025.

[0001628280-25-040830:notes:227]
In July 2024, we purchased the land and building of our wafer fabrication facility located in Sagamihara, Japan for a total transaction price of $42.2 million including $1.3 million of incremental direct costs for fees paid to third parties that were capitalized. We also recorded a $16.3 million increase in the carrying value of buildings purchased related to the termination of leases for the purchased building. The total carrying value of assets purchased was $58.5 million at the purchase date, of which $33.4 million was allocated to the land and $25.1 million to the building.

[0001628280-25-040830:notes:228]
In August 2023, we purchased land and buildings that we previously leased in the United Kingdom for a total purchase price of $23.3 million. Additionally, we capitalized $1.8 million of incremental direct costs for fees paid to third parties. We also recorded a $0.3 million reduction in the carrying value of buildings purchased related to the termination of leases for the purchased buildings. The total carrying value of assets purchased is $24.8 million at the purchase date, of which $11.8 million was allocated to the land and $13.0 million to the buildings.

[0001628280-25-040830:notes:229]
During fiscal years 2025, 2024 and 2023, we recorded depreciation expense of $104.3 million, $110.6 million, and $106.6 million, respectively.

[0001628280-25-040830:notes:230]
Operating lease right-of-use assets, net

[0001628280-25-040830:notes:231]
Operating lease right-of-use assets, net were as follows (in millions):

[0001628280-25-040830:notes:232]
|  | June 28, 2025 |  | June 29, 2024 |
| Operating lease right-of-use assets | $ | 54.4 |  |  | $ | 112.3 |  |
| Less: accumulated amortization | (26.5) |  |  | (39.5) |  |
| Operating lease right-of-use assets, net | $ | 27.9 |  |  | $ | 72.8 |  |

[0001628280-25-040830:notes:233]
In connection with the Cloud Light acquisition, we acquired $3.7 million of right-of-use assets related to leases of real estate properties used as our manufacturing and office premises.  We accounted for these leases as operating leases and have the remaining lease term ranging from 1.5 to 2.6 years at the Cloud Light Closing date.

[0001628280-25-040830:notes:234]
In connection with our integration efforts to consolidate our sites, we recorded restructuring charges for various sites and reduced our operating lease right-of-use assets by $7.8 million during the year ended June 28, 2025.

[0001628280-25-040830:notes:235]
In connection with the purchase of land and building in Sagamihara, Japan in July 2024, we terminated our leases for the related facilities and recorded a $16.3 million increase in the carrying value of building purchased, as a result of derecognizing $32.0 million of net operating lease right-of-use asset, $1.6 million of operating lease liabilities, current, and $14.1 million of operating lease liabilities, non-current.

[0001628280-25-040830:notes:236]
In connection with the purchase of land and buildings in the United Kingdom in August 2023, we terminated our leases for the purchased buildings and recorded a $0.3 million of reduction in the carrying value of buildings purchased, as a result of derecognizing $4.8 million of net operating lease right-of-use asset, $2.4 million of operating lease liabilities, current, and $2.7 million of operating lease liabilities, non-current.

[0001628280-25-040830:notes:237]
Other current liabilities

[0001628280-25-040830:notes:238]
The components of other current liabilities were as follows (in millions):

[0001628280-25-040830:notes:239]
|  | June 28, 2025 |  | June 29, 2024 |
| Restructuring and related accrual (1) | $ | 2.5 |  |  | $ | 11.1 |  |
| Warranty reserve (2) | 14.4 |  |  | 13.2 |  |
| Deferred revenue and customer deposits | 0.7 |  |  | 0.6 |  |
| Income tax payable (3) | 29.1 |  |  | 13.2 |  |
| Other current liabilities | 6.4 |  |  | 3.0 |  |
| Other current liabilities | $ | 53.1 |  |  | $ | 41.1 |  |

[0001628280-25-040830:notes:240]
(1) Refer to “Note 12. Restructuring and Related Charges.”

[0001628280-25-040830:notes:241]
(2) Refer to “Note 16. Commitments and Contingencies.”

[0001628280-25-040830:notes:242]
(3) Refer to “Note 13. Income Taxes.”

[0001628280-25-040830:notes:243]
Other non-current liabilities

[0001628280-25-040830:notes:244]
The components of other non-current liabilities were as follows (in millions):

[0001628280-25-040830:notes:245]
|  | June 28, 2025 |  | June 29, 2024 |
| Asset retirement obligation | $ | 7.1 |  |  | $ | 7.5 |  |
| Pension and related accrual (1) | 9.7 |  |  | 7.5 |  |
| Unrecognized tax benefit (2) | 55.6 |  |  | 83.0 |  |
| Other non-current liabilities (2) | 25.4 |  |  | 5.4 |  |
| Other non-current liabilities | $ | 97.8 |  |  | $ | 103.4 |  |

[0001628280-25-040830:notes:246]
(1) We have defined benefit pension plans in Japan, Switzerland, and Thailand. Pension and related accrual of $9.7 million as of June 28, 2025 relates to $11.0 million of non-current portion of benefit obligation, offset by $1.3 million of funding for the pension plan in Switzerland. Pension and related accrual of $7.5 million as of June 29, 2024 relates to $8.6 million of non-current portion of benefit obligation, offset by $1.2 million of funding for the pension plan in Switzerland. We typically re-evaluate the assumptions related to the fair value of our defined benefit obligations annually in the fiscal fourth quarter and make any updates as necessary. Refer to “Note 15. Employee Retirement Plans”.
(2) The Company reclassified a $21.4 million unrecognized tax position to other non-current liabilities during the year ended June 28, 2025 for an indemnification liability related to the sale of certain assets. This did not impact our results of operations for the year ended June 28, 2025.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001628280-25-040830:notes:247]
Note 8. Leases

[0001628280-25-040830:notes:248]
We lease certain real and personal property from unrelated third parties under non-cancellable operating leases that expire at various dates through fiscal year 2033. These operating leases are primarily for administrative offices, research and development and manufacturing facilities, as well as sales offices in various countries around the world. Certain leases require us to pay property taxes, insurance and routine maintenance, and include escalation clauses. Many leases include one or more options to renew. We do not assume renewals in our determination of the lease term unless the renewals are deemed to be reasonably assured at lease commencement.

[0001628280-25-040830:notes:249]
As of June 28, 2025, we sublease a portion of our offices in the United States, Canada, the United Kingdom and China. These subleases will expire at various dates through fiscal year 2029. We anticipate receiving approximately $0.9 million in sublease income over the next fiscal year.

[0001628280-25-040830:notes:250]
The components of lease costs, lease term, and discount rate are as follows (in millions, except for weighted average data):

[0001628280-25-040830:notes:251]
|  | June 28, 2025 |  | June 29, 2024 |  | July 1, 2023 |
| Operating lease cost | $ | 13.3 |  |  | $ | 16.8 |  |  | $ | 14.4 |  |
| Short-term and variable lease cost | 3.5 |  |  | 4.6 |  |  | 2.7 |  |
| Sublease income | (0.8) |  |  | (2.0) |  |  | (2.6) |  |
| Total lease cost | $ | 16.0 |  |  | $ | 19.4 |  |  | $ | 14.5 |  |
| Weighted average remaining lease term (in years): |  |  |  |  |  |
| Operating leases | 3.3 |  | 5.2 |  | 5.8 |
| Weighted average discount rate (in percentages): |  |  |  |  |  |
| Operating leases | 3.8 | % |  | 3.5 | % |  | 3.1 | % |

[0001628280-25-040830:notes:252]
As of June 28, 2025, maturities of our operating lease liabilities, which do not include short-term leases and variable lease payments, were as follows (in millions):

[0001628280-25-040830:notes:253]
| Fiscal Years |  | Operating Leases (1) |  |  |  |  |
| 2026 |  | $ | 12.7 |  |  |  |  |  |
| 2027 |  | 11.7 |  |  |  |  |  |
| 2028 |  | 7.5 |  |  |  |  |  |
| 2029 |  | 4.4 |  |  |  |  |  |
| 2030 |  | 1.0 |  |  |  |  |  |
| Thereafter |  | 0.3 |  |  |  |  |  |
| Total minimum lease payments |  | 37.6 |  |  |  |  |  |
| Less: amount representing interest |  | (2.6) |  |  |  |  |  |
| Present value of total lease liabilities |  | $ | 35.0 |  |  |  |  |  |

[0001628280-25-040830:notes:254]
(1)  Non-cancellable sublease proceeds for fiscal year 2025 of $0.9 million are not included in the table above.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001628280-25-040830:notes:255]
Note 9. Goodwill and Other Intangible Assets

[0001628280-25-040830:notes:256]
In November 2023, we completed the acquisition of Cloud Light. We recognized goodwill of $365.8 million, which was allocated to the Cloud & Networking segment.

[0001628280-25-040830:notes:257]
In the first quarter of fiscal year 2023, we completed two acquisitions, our acquisition of NeoPhotonics and the acquisition of IPG telecom transmission product lines. We recognized goodwill of $315.3 million related to the NeoPhotonics acquisition and $10.9 million related to the acquisition of the IPG telecom transmission product lines as of July 1, 2023. We allocated the entire goodwill amount in connection with these two acquisitions to the Cloud & Networking segment.

[0001628280-25-040830:notes:258]
The following table presents our goodwill balance by the reportable segments as of June 28, 2025 and June 29, 2024 (in millions):

[0001628280-25-040830:notes:259]
|  |  | Cloud & Networking |  | Industrial Tech |  | Total |
|  | Balance as of July 1, 2023 | $ | 683.9 |  |  | $ | 11.2 |  |  | $ | 695.1 |  |
|  | Acquisition of Cloud Light (1) | 360.7 |  |  | — |  |  | 360.7 |  |
|  | Balances as of June 29, 2024 | $ | 1,044.6 |  |  | $ | 11.2 |  |  | $ | 1,055.8 |  |
|  | Acquisition of Cloud Light (2) | 5.1 |  |  | — |  |  | 5.1 |  |
|  | Balances as of June 28, 2025 | $ | 1,049.7 |  |  | $ | 11.2 |  |  | $ | 1,060.9 |  |

[0001628280-25-040830:notes:260]
(1) We recorded $359.5 million of goodwill as of the acquisition date and $1.2 million of measurement period adjustments to increase goodwill during the year ended June 29, 2024.

[0001628280-25-040830:notes:261]
(2) During the year ended June 28, 2025, prior to the end of the measurement period, we adjusted the purchase price allocation and recorded a $5.1 million increase to goodwill. The primary adjustment to the opening balance sheet relates to income tax liabilities which were not known in previous periods.

[0001628280-25-040830:notes:262]
Impairment of Goodwill

[0001628280-25-040830:notes:263]
We review goodwill for impairment during the fourth quarter of each fiscal year or more frequently if events or circumstances indicate that an impairment loss may have occurred. Based on the impairment analysis performed in the fourth quarter of each year presented, the fair value of each of our reporting units substantially exceeded the carrying value; as such, our annual qualitative assessment did not indicate that a more detailed quantitative analysis was necessary.

[0001628280-25-040830:notes:264]
Other Intangibles

[0001628280-25-040830:notes:265]
Our intangible assets are amortized on a straight-line basis over the estimated useful lives, except for certain customer relationships, which are amortized using an accelerated method of amortization over the expected customer lives, more accurately reflecting the pattern of realization of economic benefits we expect to derive. Acquired developed technologies are amortized to cost of sales and research and development expenses. Acquired customer relationships are amortized to selling, general and administrative expenses in the consolidated statement of operations.

[0001628280-25-040830:notes:266]
IPR&D is initially capitalized at fair value as an intangible asset with an indefinite life and assessed for impairment thereafter. When an IPR&D project is completed, the IPR&D is reclassified to an amortizable purchased intangible asset and amortized over the asset’s estimated useful life.

[0001628280-25-040830:notes:267]
During the annual impairment testing performed in the fourth quarter of each year presented, we concluded that our intangible and other long-lived assets were not impaired at the asset group level. We review our intangible and other long-lived assets for impairment at least annually in the fourth quarter of each fiscal year, absent any interim indicators of impairment. There were no indicators of impairment at the asset group level during the years ended June 28, 2025 and June 29, 2024.

[0001628280-25-040830:notes:268]
In November 2023, we completed the acquisition of Cloud Light. The intangible assets acquired from the acquisition were as follows as of the acquisition date (in millions, except for weighted average amortization period):

[0001628280-25-040830:notes:269]
|  | Fair Value at the Acquisition Date |  | Weighted Average Amortization Period(Years) |
| Acquired developed technologies | $ | 170.0 |  |  | 7.0 |
| Customer relationships | 130.0 |  |  | 7.0 |
| In-process research and development | 16.0 |  |  | n/a |
| Order backlog | 14.0 |  |  | 1.0 |
| Trade name and trademarks | 3.0 |  |  | 1.2 |
| Total intangible assets | $ | 333.0 |  |  |  |

[0001628280-25-040830:notes:270]
During the years ended June 28, 2025 and June 29, 2024, we reclassified $4.3 million and $10.3 million, respectively, of IPR&D intangible assets acquired from Cloud Light to acquired developed technologies for IPR&D projects that were completed during the periods. We recorded $0.2 million and $0.1 million of related amortization expense in our consolidated statements of operations during the years ended June 28, 2025 and June 29, 2024, respectively.

[0001628280-25-040830:notes:271]
The following tables present details of all of our intangibles, including those acquired in connection with our acquisitions in fiscal year 2024 and fiscal year 2023, as of the periods presented (in millions, except for weighted average remaining amortization period):

[0001628280-25-040830:notes:272]
| June 28, 2025 | Gross Carrying Amounts |  | Accumulated Amortization |  | Net Carrying Amounts |  | Weighted average remaining amortization period (years) |
| Acquired developed technologies | $ | 822.4 |  |  | $ | (559.0) |  |  | $ | 263.4 |  |  | 4.1 |
| Customer relationships | 419.8 |  |  | (226.6) |  |  | 193.2 |  |  | 4.1 |
| In-process research and development | 8.5 |  |  | — |  |  | 8.5 |  |  | n/a |
| Order backlog | 14.0 |  |  | (14.0) |  |  | — |  |  | — |
| Trade name and trademarks | 3.0 |  |  | (3.0) |  |  | — |  |  | — |
| Total intangible assets | $ | 1,267.7 |  |  | $ | (802.6) |  |  | $ | 465.1 |  |  |  |

[0001628280-25-040830:notes:273]
During the year ended June 28, 2025, we recorded a $2.7 million write-off of IPR&D intangible assets for projects we will no longer pursue, which includes $2.0 million from the NeoPhotonics acquisition and $0.6 million from the Cloud Light acquisition. We recognized this charge as research and development expense in our consolidated statements of operations during the year ended June 28, 2025.

[0001628280-25-040830:notes:274]
| June 29, 2024 | Gross Carrying Amounts |  | Accumulated Amortization |  | Net Carrying Amounts |  | Weighted average remaining amortization period (years) |
| Acquired developed technologies | $ | 818.1 |  |  | $ | (473.0) |  |  | $ | 345.1 |  |  | 4.8 |
| Customer relationships | 419.8 |  |  | (169.4) |  |  | 250.4 |  |  | 4.9 |
| In-process research and development | 15.5 |  |  | — |  |  | 15.5 |  |  | n/a |
| Order backlog | 14.0 |  |  | (8.9) |  |  | 5.1 |  |  | 0.4 |
| Trade name and trademarks | 3.0 |  |  | (1.6) |  |  | 1.4 |  |  | 0.6 |
| Total intangible assets | $ | 1,270.4 |  |  | $ | (652.9) |  |  | $ | 617.5 |  |  |  |

[0001628280-25-040830:notes:275]
During the year ended June 29, 2024, we reclassified $1.9 million of IPR&D intangible assets acquired from NeoPhotonics to acquired developed technologies for IPR&D projects that were completed during the period and recorded $0.3 million of related amortization expense in our consolidated statements of operations during the year ended June 29, 2024.

[0001628280-25-040830:notes:276]
During the year ended June 29, 2024, we discontinued our in-house development of coherent DSPs and RFICs. As a result, we recorded $35.8 million of restructuring and related charges during the fiscal fourth quarter of 2024, which included a $29.1 million write-off of IPR&D assets acquired as part of the acquisition of IPG telecom transmission product lines, as well as $6.7 million of contract exit costs and asset write-offs.

[0001628280-25-040830:notes:277]
During fiscal years 2025, 2024 and 2023, we recorded $149.7 million, $150.6 million and $127.7 million, respectively, of amortization related to intangibles assets.

[0001628280-25-040830:notes:278]
The following table presents details of amortization for the periods presented (in millions):

[0001628280-25-040830:notes:279]
|  | Years ended |
|  | June 28, 2025 |  | June 29, 2024 |  |  |  | July 1, 2023 |
| Cost of sales | $ | 82.2 |  |  | $ | 83.9 |  |  |  |  | $ | 84.4 |  |
| Selling, general and administrative | 65.9 |  |  | 65.2 |  |  |  |  | 43.3 |  |
| Research and development | 1.6 |  |  | 1.5 |  |  |  |  | — |  |
| Total amortization of intangibles | $ | 149.7 |  |  | $ | 150.6 |  |  |  |  | $ | 127.7 |  |

[0001628280-25-040830:notes:280]
Based on the carrying amount of our intangible assets as of June 28, 2025, and assuming no future impairment of the underlying assets, the estimated future amortization is as follows (in millions):

[0001628280-25-040830:notes:281]
| Fiscal Years |  |
| 2026 | $ | 135.0 |  |
| 2027 | 122.7 |  |
| 2028 | 82.1 |  |
| 2029 | 51.8 |  |
| 2030 | 45.8 |  |
| Thereafter | 19.2 |  |
| Total | $ | 456.6 |  |

[0001628280-25-040830:notes:282]
The table above excludes in-process research and development intangible assets.


## us-gaap:DebtDisclosureTextBlock

[0001628280-25-040830:notes:283]
Note 10. Debt

[0001628280-25-040830:notes:284]
Our debt consists of the following:

[0001628280-25-040830:notes:285]
|  | June 28, 2025 |  | June 29, 2024 |
|  | Short-term |  | Long-term |  | Total |  | Short-term |  | Long-term |  | Total |
| Convertible notes | $ | — |  |  | $ | 2,506.2 |  |  | $ | 2,506.2 |  |  | $ | — |  |  | $ | 2,503.2 |  |  | $ | 2,503.2 |  |
| Term loans | 10.6 |  |  | 56.4 |  |  | 67.0 |  |  | — |  |  | — |  |  | — |  |
| Total | $ | 10.6 |  |  | $ | 2,562.6 |  |  | $ | 2,573.2 |  |  | $ | — |  |  | $ | 2,503.2 |  |  | $ | 2,503.2 |  |

[0001628280-25-040830:notes:286]
Convertible Notes

[0001628280-25-040830:notes:287]
2029 Notes

[0001628280-25-040830:notes:288]
On June 16, 2023, we issued $603.7 million in aggregate principal amount of 2029 Notes in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act of 1933, as amended. The 2029 Notes are governed by an indenture between the Company and U.S. Bank Trust Company National Association, (as successor in interest to U.S. Bank National Association), as a trustee (the “2029 Indenture”). The 2029 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001628280-25-040830:notes:289]
The net proceeds from the sale of the 2029 Notes was $599.4 million, after deducting $4.3 million of net issuance costs. In addition, we incurred $0.8 million of professional fees directly related to this transaction. Concurrent with the issuance of the 2029 Notes, we used $132.8 million of the net proceeds to repurchase $125.0 million aggregate principal amount of the 2024 Notes and $125.0 million of the net proceeds to repurchase our common stock in privately negotiated transactions. We intend to use the remaining net proceeds for general corporate purposes, which may include the repayment of our indebtedness, including any of our existing convertible notes, capital expenditures, working capital and potential acquisitions.

[0001628280-25-040830:notes:290]
The 2029 Notes bear interest at a rate of 1.50% per year, payable semi-annually in arrears on June 15 and December 15 of each year, beginning on December 15, 2023. The 2029 Notes will mature on December 15, 2029, unless earlier redeemed, repurchased by us, or converted pursuant to their terms.

[0001628280-25-040830:notes:291]
The initial conversion rate is 14.3808 shares of common stock per $1,000 principal amount of the 2029 Notes (which is equivalent to an initial conversion price of approximately $69.54 per share). The conversion rate is subject to adjustment upon the occurrence of certain events specified in the 2029 Indenture, but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert the 2029 Notes in connection with such make-whole fundamental change or notice of redemption.

[0001628280-25-040830:notes:292]
Prior to the close of business on the business day immediately preceding September 15, 2029, holders of the 2029 Notes may convert their 2029 Notes only under the following circumstances:

[0001628280-25-040830:notes:293]
•during any fiscal quarter commencing after September 30, 2023 (and only during such fiscal quarter), if the last reported sale price of the common stock for at least 20 trading days (whether or not consecutive) during the period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% if the applicable conversion price, or $90.40, on each applicable trading day;

[0001628280-25-040830:notes:294]
•during the five consecutive business day period after any five consecutive trading day period (the “2029 measurement period”) in which the trading price per $1,000 principal amount of 2029 Notes for each trading day of the 2029 measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate on each such trading day;

[0001628280-25-040830:notes:295]
•if we call any or all of the 2029 Notes for redemption, at any time prior to the close of business on the second business day immediately preceding the redemption date; or

[0001628280-25-040830:notes:296]
•upon the occurrence of specified corporate events as specified in the 2029 Indenture.

[0001628280-25-040830:notes:297]
On or after September 15, 2029 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their 2029 Notes at any time. Following our irrevocable settlement method election made on September 25, 2024, upon conversion, we are required to satisfy our conversion obligation with respect to such converted 2029 Notes by delivering cash equal to the principal amount of such converted 2029 Notes and cash, shares of common stock or a combination of cash and shares of common stock, at our election, with respect to any conversion value in excess thereof.

[0001628280-25-040830:notes:298]
We may redeem for cash all or any portion of the 2029 Notes, at our option (subject to the partial redemption limitation set forth in the 2029 Indenture), on or after June 22, 2026, if the last reported sale price of our common stock has been at least 130% of the conversion price then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading-day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which we provide notice of redemption at a redemption price equal to 100% of the principal amount of the 2029 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. No sinking fund is provided for the 2029 Notes. If we elect to redeem fewer than all of the outstanding 2029 Notes, at least $100.0 million aggregate principal amount of the 2029 Notes must be outstanding and not subject to redemption as of the redemption notice date. Upon the occurrence of a fundamental change (as defined in the 2029 Indenture), holders may require us to repurchase all or a portion of their 2029 Notes for cash at a price equal to 100% of the principal amount of the 2029 Notes to be repurchased, plus any accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

[0001628280-25-040830:notes:299]
The entire 2029 Notes are recorded as convertible notes, non-current in our consolidated balance sheets as of June 28, 2025 and June 29, 2024, measured at amortized cost.

[0001628280-25-040830:notes:300]
2028 Notes

[0001628280-25-040830:notes:301]
In March 2022, we issued $861.0 million in aggregate principal amount of 2028 Notes in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act of 1933, as amended. The 2028 Notes are governed by an indenture between the Company and U.S. Bank Trust Company National Association (as successor in interest to U.S. Bank National Association), as a trustee (the “2028 Indenture”). The 2028 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001628280-25-040830:notes:302]
The net proceeds from the sale of the 2028 Notes was $854.8 million, after deducting $6.2 million in issuance costs. In addition, we incurred $0.7 million of professional fees directly related to this transaction.  Concurrent with the issuance of the 2028 Notes, we used $200.0 million of the net proceeds to repurchase our common stock in privately negotiated transactions.

[0001628280-25-040830:notes:303]
The 2028 Notes bear interest at a rate of 0.50% per year, payable semi-annually in arrears on June 15 and December 15 of each year, beginning on June 15, 2022. The 2028 Notes will mature on June 15, 2028, unless earlier redeemed, repurchased by us, or converted pursuant to their terms.

[0001628280-25-040830:notes:304]
The initial conversion rate is 7.6319 shares of common stock per $1,000 principal amount of the 2028 Notes (which is equivalent to an initial conversion price of approximately $131.03 per share). The conversion rate is subject to adjustment upon the occurrence of certain events specified in the 2028 Indenture, but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert the 2028 Notes in connection with such make-whole fundamental change or notice of redemption.

[0001628280-25-040830:notes:305]
Prior to the close of business on the business day immediately preceding March 15, 2028, holders of the 2028 Notes may convert their 2028 Notes only under the following circumstances:

[0001628280-25-040830:notes:306]
•during any fiscal quarter (and only during such fiscal quarter), if the last reported sale price of the common stock for at least 20 trading days (whether or not consecutive) during the 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% if the applicable conversion price, or $170.34 on each applicable trading day;

[0001628280-25-040830:notes:307]
•during the five consecutive business day period after any five consecutive trading day period (the “2028 measurement period”) in which the trading price per $1,000 principal amount of the 2028 Notes for each trading day of the 2028 measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate on each such trading day;

[0001628280-25-040830:notes:308]
•if we call any or all of the 2028 Notes for redemption, at any time prior to the close of business on the second business day immediately preceding the redemption date; or

[0001628280-25-040830:notes:309]
•upon the occurrence of specified corporate events as specified in the 2028 Indenture.

[0001628280-25-040830:notes:310]
On or after March 15, 2028 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their 2028 Notes at any time. Following our irrevocable settlement method election made on September 25, 2024, upon conversion, we are required to satisfy our conversion obligation with respect to such converted 2028 Notes by delivering cash equal to the principal amount of such converted 2028 Notes and cash, shares of common stock or a combination of cash and shares of common stock, at our election, with respect to any conversion value in excess thereof.

[0001628280-25-040830:notes:311]
We may redeem for cash all or any portion of the 2028 Notes, at our option (subject to the partial redemption limitation set forth in the 2028 Indenture), on or after June 20, 2025, if the last reported sale price of its common stock has been at least 130% of the conversion price then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading-day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which we provide notice of redemption at a redemption price equal to 100% of the principal amount of the 2028 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. No sinking fund is provided for the 2028 Notes. If we elect to redeem fewer than all of the outstanding 2028 Notes, at least $100.0 million aggregate principal amount of the 2028 Notes must be outstanding and not subject to redemption as of the redemption notice date.  Upon the occurrence of a fundamental change (as defined in the 2028 Indenture), holders may require us to repurchase all or a portion of their 2028 Notes for cash at a price equal to 100% of the principal amount of the 2028 Notes to be repurchased, plus any accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

[0001628280-25-040830:notes:312]
We initially bifurcated the principal amount of the 2028 Notes into liability and equity components. The liability component of the 2028 Notes was initially valued at $629.8 million based on the contractual cash flow discounted at an appropriate comparable market on the non-convertible debt borrowing rate at the date of issuance, which was 5.7%, with the equity component representing the residual amount of the proceeds of $231.2 million, which was recorded as a debt discount. Upon adoption of ASU 2020-06 in the first quarter of fiscal year 2023, our 2028 Notes were accounted for as a single liability measured at amortized cost.  The entire 2028 Notes are recorded as convertible notes, non-current in our consolidated balance sheets as of June 28, 2025 and June 29, 2024, measured at amortized cost.

[0001628280-25-040830:notes:313]
2026 Notes

[0001628280-25-040830:notes:314]
In December 2019, we issued $1,050.0 million in aggregate principal amount of the 2026 Notes in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act. The 2026 Notes are governed by an indenture between the Company and U.S. Bank Trust Company National Association (as successor in interest to U.S. Bank National Association), as trustee (the “2026 Indenture”). We used approximately $196.0 million of the net proceeds of the offering to repay in full all amounts outstanding under our term loan facility, and a portion of the net proceeds of the offering to purchase approximately $200.0 million of our common stock concurrently with the pricing of the offering in privately negotiated transactions. The 2026 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, the incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001628280-25-040830:notes:315]
The 2026 Notes bear interest at a rate of 0.50% per year, payable semi-annually in arrears on June 15 and December 15 of each year, beginning on June 15, 2020. The 2026 Notes will mature on December 15, 2026, unless earlier redeemed, repurchased by us, or converted pursuant to their terms.

[0001628280-25-040830:notes:316]
The initial conversion rate is 10.0711 shares of common stock per $1,000 principal amount of the 2026 Notes (which is equivalent to an initial conversion price of approximately $99.29 per share). The conversion rate is subject to adjustment upon the occurrence of certain events specified in the 2026 Indenture, but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares set forth in the 2026 Indenture or a holder that elects to convert the 2026 Notes in connection with such make-whole fundamental change or notice of redemption.

[0001628280-25-040830:notes:317]
Prior to the close of business on the business day immediately preceding September 15, 2026, holders of the 2026 Notes may convert their 2026 Notes only under the following circumstances:

[0001628280-25-040830:notes:318]
•during any fiscal quarter (and only during such fiscal quarter), if the last reported sale price of the common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price of the 2026 Notes, or $129.08 on each applicable trading day;

[0001628280-25-040830:notes:319]
•during the five business day period after any five consecutive trading day period (the "2026 measurement period") in which the trading price per $1,000 principal amount of the 2026 Notes for each trading day of the 2026 measurement period was less than 98% of the product of the last reported sale price of our common stock and the conversion rate for the 2026 Notes on each such trading day;

[0001628280-25-040830:notes:320]
•if we call any or all of the 2026 Notes for redemption, at any time prior to the close of business on the second business day immediately preceding the relevant redemption date; or

[0001628280-25-040830:notes:321]
•upon the occurrence of specified corporate events as specified in the 2026 Indenture.

[0001628280-25-040830:notes:322]
On or after September 15, 2026 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert the 2026 Notes at any time. Following our entry into the First Supplemental Indenture, dated as of September 25, 2024, to the 2026 Indenture, upon conversion, we are required to satisfy our conversion obligation with respect to such converted 2026 Notes by delivering cash equal to the principal amount of such converted 2026 Notes and cash, shares of common stock or a combination of cash and shares of common stock, at our election, with respect to any conversion value in excess thereof.

[0001628280-25-040830:notes:323]
We may redeem for cash, for all or any portion of the 2026 Notes, at our option, on or after December 20, 2023, if the last reported sale price of its common stock has been at least 130% of the conversion price then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading-day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which we provide a notice of redemption at a redemption price equal to 100% of the principal amount of the 2026 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. No sinking fund is provided for the 2026 Notes. Upon the occurrence of a fundamental change (as defined in the 2026 Indenture), holders may require us to repurchase all or a portion of the 2026 Notes for cash at a price equal to 100% of the principal amount of the 2026 Notes to be repurchased, plus any accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

[0001628280-25-040830:notes:324]
We initially bifurcated the principal amount of the 2026 Notes into liability and equity components. The liability component of the 2026 Notes was valued at $734.8 million based on the contractual cash flows discounted at an appropriate comparable market non-convertible debt borrowing rate at the date of issuance of 5.8% with the equity component representing the residual amount of the proceeds of $315.2 million, which was recorded as a debt discount.  Upon adoption of ASU 2020-06 in the first quarter of fiscal year 2023, our 2026 Notes were accounted for as a single liability measured at amortized cost. The entire 2026 Notes are recorded as convertible notes, non-current in our consolidated balance sheets as of June 28, 2025 and June 29, 2024, measured at amortized cost.

[0001628280-25-040830:notes:325]
2024 Notes

[0001628280-25-040830:notes:326]
In March 2017, we issued $450.0 million in aggregate principal amount of 0.25% convertible senior notes due in 2024 (the “2024 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act. The 2024 Notes were governed by an indenture between the Company, as the issuer, and U.S. Bank Trust Company National Association (as successor in interest to U.S. Bank National Association), as trustee (the “2024 Indenture”). The 2024 Notes were unsecured and did not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001628280-25-040830:notes:327]
The 2024 Notes bore interest at a rate of 0.25% per year. Interest on the 2024 Notes was payable semi-annually in arrears on March 15 and September 15 of each year, beginning on September 15, 2017. The 2024 Notes matured on March 15, 2024.

[0001628280-25-040830:notes:328]
Concurrent with the issuance of the 2029 Notes, we used $132.8 million of the net proceeds to repurchase $125.0 million aggregate principal amount of the 2024 Notes, which we accounted for as an extinguishment of liability. $13.5 million of the $132.8 million repurchase price was allocated to the conversion feature of the repurchased 2024 Notes, representing the fair value of the conversion feature at the date of the repurchase, and was recognized as a reduction of the stockholders’ equity. Refer to consolidated statements of stockholders’ equity. We recognized an extinguishment gain of $1.0 million related to the repurchase, which was recorded under other income, net on our consolidated statements of operations for the year ended July 1, 2023.  Additionally, since issuing the 2024 Notes, we have converted a total of approximately $1.9 million of principal amount of the 2024 Notes, with less than $0.1 million of principal amount converted during the twelve months ended June 29, 2024.

[0001628280-25-040830:notes:329]
On March 15, 2024, the 2024 Notes maturity date, we fully repaid the remaining principal amount of $323.1 million. The conversion feature previously classified within stockholder’s equity was fully amortized as of the maturity date.

[0001628280-25-040830:notes:330]
Convertible Notes - Additional Disclosures

[0001628280-25-040830:notes:331]
Our convertible notes consisted of the following components as of the periods presented (in millions):

[0001628280-25-040830:notes:332]
| June 28, 2025 |  |  | 2026 Notes (1) |  | 2028 Notes (2) |  | 2029 Notes (3) |  | Total |
| Principal |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |  | $ | 603.7 |  |  | $ | 2,514.7 |  |
| Unamortized debt discount and debt issuance costs |  |  | (1.7) |  |  | (3.3) |  |  | (3.5) |  |  | (8.5) |  |
| Net carrying amount of the liability component |  |  | $ | 1,048.3 |  |  | $ | 857.7 |  |  | $ | 600.2 |  |  | $ | 2,506.2 |  |

[0001628280-25-040830:notes:333]
| June 29, 2024 |  |  | 2026 Notes (1) |  | 2028 Notes (2) |  | 2029 Notes (3) |  | Total |
| Principal |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |  | $ | 603.7 |  |  | $ | 2,514.7 |  |
| Unamortized debt discount and debt issuance costs |  |  | (2.8) |  |  | (4.4) |  |  | (4.3) |  |  | (11.5) |  |
| Net carrying amount of the liability component |  |  | $ | 1,047.2 |  |  | $ | 856.6 |  |  | $ | 599.4 |  |  | $ | 2,503.2 |  |

[0001628280-25-040830:notes:334]
(1) If the closing price of our stock exceeds $129.08 (or 130% of the conversion price of $99.29) for 20 of the last 30 trading days of any future quarter, the 2026 Notes would also become convertible at the option of the holders during the subsequent fiscal quarter and the debt would be reclassified to current liabilities in our consolidated balance sheets.

[0001628280-25-040830:notes:335]
(2) If the closing price of our stock exceeds $170.34 (or 130% of the conversion price of $131.03) for 20 of the last 30 trading days of any future quarter, the 2028 Notes would become convertible at the option of the holders during the subsequent fiscal quarter and the debt would be reclassified to current liabilities in our consolidated balance sheets.

[0001628280-25-040830:notes:336]
(3) If the closing price of our stock exceeds $90.40 (or 130% of the conversion price of $69.54) for 20 of the last 30 trading days of any future quarter, the 2029 Notes would become convertible at the option of the holders during the subsequent fiscal quarter and the debt would be reclassified to current liabilities in our consolidated balance sheets.

[0001628280-25-040830:notes:337]
The following table sets forth interest expense information related to our convertible notes for the periods presented (in millions):

[0001628280-25-040830:notes:338]
|  |  |  |  |  | June 28, 2025 |  | June 29, 2024 |  | July 1, 2023 |
| Contractual interest expense |  |  |  |  | $ | 18.6 |  |  | $ | 19.2 |  |  | $ | 11.2 |  |
| Amortization of the debt discount and debt issuance costs |  |  |  |  | 3.0 |  |  | 14.6 |  |  | 24.3 |  |
| Total interest expense |  |  |  |  | $ | 21.6 |  |  | $ | 33.8 |  |  | $ | 35.5 |  |

[0001628280-25-040830:notes:339]
The future interest and principal payments related to our convertible notes are as follows as of June 28, 2025 (in millions):

[0001628280-25-040830:notes:340]
| Fiscal Years |  |  | 2026 Notes |  | 2028 Notes |  | 2029 Notes |  | Total |
| 2026 |  |  | $ | 5.3 |  |  | $ | 4.3 |  |  | $ | 9.1 |  |  | $ | 18.7 |  |
| 2027 |  |  | 1,052.6 |  |  | 4.3 |  | 9.1 |  |  | 1,066.0 |  |
| 2028 |  |  | — |  |  | 865.3 |  | 9.1 |  |  | 874.4 |  |
| 2029 |  |  | — |  |  | — |  |  | 9.1 |  |  | 9.1 |  |
| 2030 |  |  | — |  |  | — |  |  | 608.1 |  |  | 608.1 |  |
| Total payments |  |  | $ | 1,057.9 |  |  | $ | 873.9 |  |  | $ | 644.5 |  |  | $ | 2,576.3 |  |

[0001628280-25-040830:notes:341]
The principal balances of our convertible notes are reflected in the payment periods in the table above based on their respective contractual maturities.

[0001628280-25-040830:notes:342]
Term Loans

[0001628280-25-040830:notes:343]
SMBC Term Loan

[0001628280-25-040830:notes:344]
On August 9, 2024, the Company entered into a term loan agreement (the “SMBC Term Loan”) with Sumitomo Mitsui Banking Corporation (“SMBC”). The SMBC Term Loan provides an aggregate principal amount of 6.4 billion Japanese yen (“JPY”). The loan requires monthly principal payments of approximately 53.3 million JPY, from August 31, 2024 to June 30, 2029 and interest based on a fixed annual interest rate of 0.88%, with the remaining principal of approximately 3.3 billion JPY due on the loan maturity date of July 31, 2029. Under the loan agreement, the Company cannot prepay the outstanding loan without SMBC’s approval.  In the event the Company prepays the outstanding loan with SMBC’s approval, the Company shall pay SMBC a settlement amount calculated pursuant to the terms of the loan agreement. The SMBC Term Loan is secured by the real estate owned in Sagamihara, Japan.

[0001628280-25-040830:notes:345]
As of June 28, 2025, the Company had $40.6 million in principal amount outstanding on our SMBC Term Loan, of which the short-term portion of $4.4 million is recorded as current liabilities while the long-term portion of $36.2 million is recorded as long-term debt in the Company’s consolidated balance sheets.

[0001628280-25-040830:notes:346]
Mizuho Term Loan

[0001628280-25-040830:notes:347]
On September 20, 2024, the Company entered into a term loan agreement (the “Mizuho Term Loan”) with Mizuho Bank, Ltd. (“Mizuho”), in order to finance our planned manufacturing expansions. The Mizuho Term Loan provides for borrowings of 4.5 billion JPY with a 5-year term from the funding date of September 20, 2024. The loan requires quarterly principal payments of approximately 225.0 million JPY commencing on December 20, 2024 with the final payment on September 20, 2029. The Mizuho Term Loan bears interest at a fixed annual rate of 0.90%. The Mizuho Term Loan is secured by the real estate assets owned by NeoPhotonics Semiconductor GK. The Mizuho Term Loan agreement requires that the Company and certain domestic subsidiaries comply with covenants relating to customary matters, including obtaining approval from Mizuho prior to transferring, creating a security interest, or disposing of the collateral assets; obtaining approval from Mizuho prior to a business transfer, business acquisition, corporate reorganization or changes such as mergers, company splits, share exchanges or share transfers or capital structure changes; obtaining approval from Mizuho prior to changing the Company’s indirect ownership in Lumentum Japan, Inc; and obtaining approval from Mizuho prior to a distribution of dividends by Lumentum Japan, Inc. to its shareholders.

[0001628280-25-040830:notes:348]
As of June 28, 2025, the Company had $26.4 million in principal amount outstanding on our Mizuho Term Loan, of which the short-term portion of $6.2 million is recorded as current liabilities while the long-term portion of $20.2 million is recorded as long-term debt in the Company’s consolidated balance sheets.

[0001628280-25-040830:notes:349]
The SMBC Term Loan and the Mizuho Term Loan are collectively referred to as Japan Term Loans.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001628280-25-040830:notes:350]
Note 11. Accumulated Other Comprehensive Income (Loss)

[0001628280-25-040830:notes:351]
Our accumulated other comprehensive income (loss) consists of the accumulated net unrealized gains or losses on foreign currency translation adjustments, defined benefit obligations, and available-for-sale securities.

[0001628280-25-040830:notes:352]
The changes in accumulated other comprehensive income (loss), net of tax, were as follows for the periods as presented (in millions):

[0001628280-25-040830:notes:353]
|  | Foreign currency translation adjustments, net of tax (1) |  | Defined benefit obligations, net of tax (2) |  | Unrealized gain (loss) on available-for-sale securities, net of tax (3) |  | Total |
| Balances as of July 2, 2022 | $ | 9.7 |  |  | $ | 1.0 |  |  | $ | (10.3) |  |  | $ | 0.4 |  |
| Other comprehensive income (loss) | 0.7 |  |  | (1.4) |  |  | 4.4 |  |  | 3.7 |  |
| Balances as of July 1, 2023 | $ | 10.4 |  |  | $ | (0.4) |  |  | $ | (5.9) |  |  | $ | 4.1 |  |
| Other comprehensive income (loss) | (0.6) |  |  | 1.1 |  |  | 4.7 |  |  | 5.2 |  |
| Balances as of June 29, 2024 | $ | 9.8 |  |  | $ | 0.7 |  |  | $ | (1.2) |  |  | $ | 9.3 |  |
| Other comprehensive income (loss) | 0.1 |  |  | (2.3) |  |  | 1.9 |  |  | (0.3) |  |
| Balances as of June 28, 2025 | $ | 9.9 |  |  | $ | (1.6) |  |  | $ | 0.7 |  |  | $ | 9.0 |  |

[0001628280-25-040830:notes:354]
(1) In fiscal year 2019, as a result of significant changes in economic facts and circumstances, primarily due to the acquisition of Oclaro, we established the functional currency for our worldwide operations as the U.S. dollar. Translation adjustments reported prior to December 10, 2018 remain as a component of accumulated other comprehensive income in our consolidated balance sheets, until all or a part of the investment in the subsidiaries is sold or liquidated. In fiscal year 2023, we acquired IPG telecom transmission product lines. The functional currency of the Brazilian entities acquired as part of this acquisition is the local currency.

[0001628280-25-040830:notes:355]
(2) We evaluate the assumptions over the fair value of our defined benefit obligations annually and make changes as necessary. During fiscal years 2025, 2024 and 2023, our income (loss) on defined benefit obligations is presented net of tax of nil, $0.4 million, and nil, respectively.
(3) In fiscal years 2025, 2024 and 2023, our unrealized gain (loss) on available-for-sale securities is presented net of tax of nil, $1.7 million and $0.8 million, respectively.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001628280-25-040830:notes:356]
Note 12. Restructuring and Related Charges

[0001628280-25-040830:notes:357]
We have initiated various strategic restructuring actions primarily to reduce costs, consolidate our operations, rationalize the manufacturing of our products and align our business in response to market conditions and as a result of our acquisitions.

[0001628280-25-040830:notes:358]
The following table summarizes the activities of restructuring and related charges during the periods presented (in millions):

[0001628280-25-040830:notes:359]
|  | Years Ended |  |  |
|  | June 28, 2025 |  | June 29, 2024 |  |  |  | July 1, 2023 |  |  |
| Balance as of beginning of period | $ | 11.1 |  |  | $ | 5.0 |  |  |  |  | $ | — |  |  |  |
| Charges | 22.8 |  |  | 72.6 |  |  |  |  | 28.1 |  |  |  |
| Payments and other adjustments | (31.4) |  |  | (66.5) |  |  |  |  | (23.1) |  |  |  |
| Balance as of end of period | $ | 2.5 |  |  | $ | 11.1 |  |  |  |  | $ | 5.0 |  |  |  |

[0001628280-25-040830:notes:360]
During the year ended June 28, 2025, we recorded restructuring and related charges of $22.8 million. This included $14.6 million of assets written off, including property, plant and equipment, right-of-use assets, prepayments and other current assets as well as charges for other contractual commitments associated with site closures, and $4.3 million of employee severance primarily due to efforts to consolidate our sites and focus on other market opportunities, including cloud and AI markets. In addition, we also recorded $3.0 million of charges related to the discontinuation of our in-house development of coherent Digital Signal Processors (“DSPs”) and Radio Frequency Integrated Circuits (“RFICs”).

[0001628280-25-040830:notes:361]
During the year ended June 29, 2024, we recorded restructuring and related charges of $72.6 million. We discontinued our in-house development of coherent DSPs and RFICs. As a result, we recorded $35.8 million of restructuring and related charges during the fiscal fourth quarter of 2024, which includes $29.1 million write-off of IPR&D assets, as well as $6.7 million of contract exit costs and asset write-offs. The remaining $36.8 million of restructuring and related charges are primarily due to company-wide cost reduction initiatives, as well as our integration efforts to consolidate our manufacturing sites. We have shut down our factories in China which were acquired as part of the NeoPhotonics acquisition and are ramping up production of most of the related products at our Thailand facility.

[0001628280-25-040830:notes:362]
During the year ended July 1, 2023, we recorded restructuring and related charges of $28.1 million in our consolidated statements of operations, which was primarily attributable to company-wide integration efforts as a result of the NeoPhotonics acquisition, our cost reduction initiatives, as well as severance and employee-related benefits associated with NeoPhotonics’ executive severance and retention agreements. These agreements provide for payments and benefits upon an involuntary termination of employment under certain circumstances.

[0001628280-25-040830:notes:363]
Any changes in the estimates of executing our restructuring activities will be reflected in our future results of operations.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-25-040830:notes:364]
Note 13. Income Taxes

[0001628280-25-040830:notes:365]
Our loss before income taxes consisted of the following (in millions):

[0001628280-25-040830:notes:366]
|  | Years Ended |
|  | June 28, 2025 |  | June 29, 2024 |  | July 1, 2023 |
| Domestic | $ | (174.4) |  |  | $ | (219.6) |  |  | $ | (44.3) |  |
| Foreign | 2.3 |  |  | (186.1) |  |  | (58.1) |  |
| Loss before income taxes | $ | (172.1) |  |  | $ | (405.7) |  |  | $ | (102.4) |  |

[0001628280-25-040830:notes:367]
Our income tax (benefit) provision consisted of the following (in millions):

[0001628280-25-040830:notes:368]
|  | Years Ended |
|  | June 28, 2025 |  | June 29, 2024 |  | July 1, 2023 |
| Federal: |  |  |  |  |  |
| Current | $ | (8.4) |  |  | $ | (10.6) |  |  | $ | 12.9 |  |
| Deferred | — |  |  | 124.0 |  |  | (22.5) |  |
|  | (8.4) |  |  | 113.4 |  |  | (9.6) |  |
| State: |  |  |  |  |  |
| Current | 1.8 |  |  | 1.3 |  |  | 0.9 |  |
| Deferred | — |  |  | (8.0) |  |  | (0.5) |  |
|  | 1.8 |  |  | (6.7) |  |  | 0.4 |  |
| Foreign: |  |  |  |  |  |
| Current | 55.5 |  |  | 52.1 |  |  | 55.3 |  |
| Deferred | (246.9) |  |  | (18.0) |  |  | (16.9) |  |
|  | (191.4) |  |  | 34.1 |  |  | 38.4 |  |
| Total income tax (benefit) provision | $ | (198.0) |  |  | $ | 140.8 |  |  | $ | 29.2 |  |

[0001628280-25-040830:notes:369]
The provision for income taxes differs from the amount computed by applying the U.S. Federal statutory income tax rate to our income before provision for income taxes as follows (in millions):

[0001628280-25-040830:notes:370]
|  | Years Ended |
|  | June 28, 2025 |  | June 29, 2024 |  | July 1, 2023 |
| Income tax provision computed at federal statutory rate | $ | (36.1) |  |  | $ | (85.2) |  |  | $ | (21.5) |  |
| Foreign rate differential | (49.9) |  |  | 58.9 |  |  | 33.6 |  |
| Change in valuation allowance | (161.5) |  |  | 150.1 |  |  | (4.8) |  |
| Tax credits | (2.2) |  |  | (1.8) |  |  | (46.5) |  |
| Stock-based compensation | 22.3 |  |  | 17.8 |  |  | 19.1 |  |
| Permanent items | 0.3 |  |  | (3.2) |  |  | 2.9 |  |
| Transaction costs | — |  |  | 1.3 |  |  | 2.4 |  |
| Subpart F and GILTI | 22.4 |  |  | 0.2 |  |  | 44.2 |  |
| Unrecognized tax benefits | 8.5 |  |  | 11.7 |  |  | 8.6 |  |
| Change in Tax Rates | 0.5 |  |  | (9.9) |  |  | — |  |
| BEAT | — |  |  | — |  |  | (8.0) |  |
| Audit settlement | (4.4) |  |  | — |  |  | — |  |
| State taxes | 1.9 |  |  | — |  |  | — |  |
| Other | 0.2 |  |  | 0.9 |  |  | (0.8) |  |
| Total income tax (benefit) provision | $ | (198.0) |  |  | $ | 140.8 |  |  | $ | 29.2 |  |
| Effective tax rate | 115.04 | % |  | (34.71) | % |  | (28.52) | % |

[0001628280-25-040830:notes:371]
Our provision for income taxes for fiscal year 2025 differs from the 21% U.S. statutory rate primarily due to the income tax benefit associated with the release of a valuation allowance on our UK deferred tax assets, earnings of our foreign subsidiaries being taxed at rates that differ from the U.S. statutory rate, partially offset by the income tax expense from U.S. income inclusions from Subpart F and GILTI, non-deductible stock-based compensation and changes in unrecognized tax benefits.

[0001628280-25-040830:notes:372]
Our provision for income taxes for fiscal year 2024 differs from the 21% U.S. statutory rate primarily due to the income tax expense associated with the recognition of a valuation allowance on our U.S. federal and state deferred tax assets, earnings of our foreign subsidiaries being taxed at rates that differ from the U.S. statutory rate and non-deductible stock-based compensation. Additionally, our provision for income taxes includes changes in unrecognized tax benefits, partially offset by the income tax benefit from a change in the applicable statutory income tax rate in certain jurisdictions.

[0001628280-25-040830:notes:373]
Our provision for income taxes for fiscal year 2023 differs from the 21% U.S. statutory rate primarily due to the income tax expense from foreign income inclusions in the U.S., earnings of our foreign subsidiaries being taxed at rates that differ from the U.S. statutory rate and non-deductible stock-based compensation. Additionally, our provision for income taxes includes income tax benefits from various tax credits and change in valuation allowance as it is more-likely-than-not that certain deferred tax assets will be realizable in the future. During fiscal year 2023, we also effectuated certain tax planning actions which reduced the amount of BEAT for fiscal year 2022.

[0001628280-25-040830:notes:374]
The components of our net deferred taxes consisted of the following (in millions):

[0001628280-25-040830:notes:375]
|  | Years Ended |
|  | June 28, 2025 |  | June 29, 2024 |  |  |
| Gross deferred tax assets: |  |  |  |  |  |
| Intangibles | $ | 20.3 |  |  | $ | 27.0 |  |  |  |
| Tax credit carryforwards | 143.2 |  |  | 109.3 |  |  |  |
| Net operating loss carryforwards | 232.1 |  |  | 226.0 |  |  |  |
| Inventories | 14.9 |  |  | 11.1 |  |  |  |
| Accruals and reserves | 28.1 |  |  | 14.1 |  |  |  |
| Fixed assets | 17.2 |  |  | 26.2 |  |  |  |
| Capital loss carryforwards | 11.2 |  |  | 11.2 |  |  |  |
| Capitalized and unclaimed R&D expenditure | 178.1 |  |  | 77.0 |  |  |  |
| Stock-based compensation | 8.9 |  |  | 5.9 |  |  |  |
| Lease liabilities | 7.5 |  |  | 13.4 |  |  |  |
| Other | 2.4 |  |  | 1.0 |  |  |  |
| Gross deferred tax assets | 663.9 |  |  | 522.2 |  |  |  |
| Valuation allowance | (440.8) |  |  | (490.4) |  |  |  |
| Deferred tax assets | 223.1 |  |  | 31.8 |  |  |  |
| Gross deferred tax liabilities: |  |  |  |  |  |
| Intangible amortization | (10.5) |  |  | (59.1) |  |  |  |
| Convertible notes | — |  |  | (0.1) |  |  |  |
| Right-of-use assets | (5.8) |  |  | (15.0) |  |  |  |
| Inventories | (3.6) |  |  | (2.2) |  |  |  |
| Other | (0.1) |  |  | (0.4) |  |  |  |
| Deferred tax liabilities | (20.0) |  |  | (76.8) |  |  |  |
| Total net deferred tax assets | $ | 203.1 |  |  | $ | (45.0) |  |  |  |

[0001628280-25-040830:notes:376]
We regularly assess our ability to realize our deferred tax assets on a quarterly basis and will establish a valuation allowance if it is more-likely-than-not that some portion of the deferred tax assets will not be realized. We weigh all available positive and negative evidence, including our earnings history and results of recent operations, reversals of deferred tax liabilities, projected future taxable income, and tax planning strategies. In fiscal year 2025, after considering both positive and negative evidence, we determined that there is sufficient objectively verifiable positive evidence to conclude that it is more-likely-than-not that our UK deferred tax assets are realizable in the future. As a result, we released a valuation allowance against such deferred tax assets except for the non-trading deficit carryforward resulting in an income tax benefit of $153.1 million. We continue to maintain our valuation allowance on U.S. and Canada deferred tax assets, and a partial valuation allowance on our Slovenia deferred tax asset. The total valuation allowance against our deferred tax assets decreased by $49.6 million in fiscal year 2025. We will continue to assess the need for a valuation allowance against our remaining deferred tax assets and may increase or decrease our valuation allowance materially in the future. Based on the information currently available, we do not believe that a significant portion of our valuation allowance for the U.S., California, Canada, and UK will be released in the next 12 months. Such a release would result in the recognition of certain deferred tax assets and a decrease in the income tax expense for the period in which the release is recorded.

[0001628280-25-040830:notes:377]
As of June 28, 2025, the Company had federal and foreign net operating loss carryforwards of $217.3 million and $750.1 million, respectively. These carryforwards will begin to expire in the fiscal year ending 2027. The federal and foreign tax attributes carried forward are subject to various rules which impose limitations on the utilization. Additionally, the Company has federal, state, and foreign research and other tax credit carryforwards of $55.4 million, $90.4 million, and $34.4 million, respectively. The federal credits will begin to expire in the fiscal year ending 2026 and California credits can be carried forward indefinitely. The foreign tax credits will begin to expire in the fiscal year ending 2026. The Company’s U.S. federal and state net operating loss and credit carryforwards are subject to annual limitations due to ownership change provisions of Section 382 of the Internal Revenue Code and similar state provisions.

[0001628280-25-040830:notes:378]
We have certain tax incentives with respect to our operations in China. These tax incentives require compliance with certain conditions and expire at various dates through calendar year 2025. The impact of these tax incentives was an increase in net income of approximately $0.5 million, or $0.01 per share in fiscal year 2025, $3.1 million, or $0.05 per share in fiscal year 2024, and $0.6 million or $0.01 per share in fiscal year 2023. The Company has also obtained a tax holiday related to certain business activities in Thailand, but to date, has not met the requirements to obtain the benefits of the tax holiday. Accordingly, the earned income is subject to regular Thailand statutory rates.

[0001628280-25-040830:notes:379]
Current U.S. tax law generally provides greater flexibility for us to access and utilize our cash held by certain of our foreign subsidiaries and we intend to repatriate all or some of the earnings of our subsidiaries in the Cayman Islands, Japan, and Hong Kong. As to all other foreign subsidiaries, we intend to reinvest these earnings indefinitely in our foreign subsidiaries. As a result, U.S. income and foreign withholding taxes associated with the repatriation of $47.3 million of earnings from our foreign subsidiaries, other than the Cayman Islands, Japan, and Hong Kong subsidiaries, have not been provided for. We estimate that an additional $5.7 million of foreign withholding taxes would have to be provided if these earnings were repatriated back to the U.S. and such withholding taxes may be available as foreign tax credit or deduction to reduce U.S. tax liability.

[0001628280-25-040830:notes:380]
The aggregate changes in the balance of our unrecognized tax benefits between June 29, 2024 and June 28, 2025 are as follows (in millions):

[0001628280-25-040830:notes:381]
| Balance as of July 2, 2022 | $ | 61.7 |  |
| Increases based on tax positions related to prior year | 2.8 |  |
| Decreases based on tax positions related to prior year | (5.5) |  |
| Decreases related to Statute of Limitations | (0.1) |  |
| Additions based on tax positions related to current year | 7.7 |  |
| Increases due to acquisition | 47.3 |  |
| Balance as of July 1, 2023 | $ | 113.9 |  |
| Increases based on tax positions related to prior year | 19.6 |  |
| Decreases based on tax positions related to prior year | (9.4) |  |
| Decreases related to Statute of Limitations | (24.8) |  |
| Additions based on tax positions related to current year | 7.3 |  |
| Increases due to acquisition | 9.1 |  |
| Balance as of June 29, 2024 | $ | 115.7 |  |
| Increases based on tax positions related to prior year | 10.4 |  |
| Decreases based on tax positions related to prior year | (4.9) |  |
| Decreases related to Statute of Limitations | (13.6) |  |
| Additions based on tax positions related to current year | 14.8 |  |
| Increases due to acquisition | 4.4 |  |
| Decreases due to audit settlement | (13.9) |  |
| Decreases due to reclass | (14.3) |  |
| Balance as of June 28, 2025 | $ | 98.6 |  |

[0001628280-25-040830:notes:382]
As of June 28, 2025, we had $55.3 million of unrecognized tax benefits, which, if recognized, would affect the effective tax rate. We are subject to examination of income tax returns by various domestic and foreign tax authorities. The timing of resolutions and closures of tax audits is highly unpredictable. Although it is possible that certain tax audits may be concluded within the next 12 months, we cannot reasonably estimate the impact to tax expense and net income from tax exams that could be resolved or closed within next 12 months. However, we believe that we have adequately provided under GAAP for potential audit outcomes. Subject to audit timing and uncertainty, we expect the amount of unrecognized tax benefit that would become recognized due to expiration of the statute of limitations and affect the effective tax rate to be $2.5 million over the next 12 months.

[0001628280-25-040830:notes:383]
Our policy is to recognize accrued interest and penalties related to unrecognized tax benefits within the income tax provision. The amount of interest and penalties accrued as of June 28, 2025 and June 29, 2024 were $12.5 million and $21.0 million, respectively.

[0001628280-25-040830:notes:384]
The major tax jurisdictions where we file tax returns are the U.S. federal government, the state of California, Japan, the United Kingdom, Thailand, China and Canada. As of June 28, 2025, our fiscal years 2012 to 2024 tax returns are open to potential examination in one or more jurisdictions. In addition, certain net operating loss and credit carryforwards may extend the ability of the tax authorities to examine our tax returns beyond the regular limits.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001628280-25-040830:notes:385]
Note 14. Equity

[0001628280-25-040830:notes:386]
Description of Lumentum Stock-Based Benefit Plans

[0001628280-25-040830:notes:387]
Equity Incentive Plan

[0001628280-25-040830:notes:388]
On November 17, 2023, our stockholders approved amendments to the Amended and Restated 2015 Equity Incentive Plan (the “2015 Plan”) to increase the number of shares of common stock reserved for issuance by an additional 3.0 million shares. On November 20, 2024, our stockholders approved an amendment to the 2015 Plan to extend the expiration date of the 2015 Plan by one year until June 23, 2026.

[0001628280-25-040830:notes:389]
In February 2025, our board of directors approved the 2025 Inducement Equity Incentive Plan (the “Inducement Plan”) in accordance with Listing Rule 5635(c)(4) of the corporate governance rules of the Nasdaq Stock Market, which became effective in February 2025. The Inducement Plan has substantially the same terms and conditions as the 2015 Plan, however, the Inducement Plan may only be used for grants to new employees and not for existing employees, executives, directors or consultants.

[0001628280-25-040830:notes:390]
As of June 28, 2025, we had 4.8 million shares subject to stock options, restricted stock units, and performance stock units issued and outstanding under the 2015 Plan. Restricted stock units and performance stock units have vesting that is performance-based, market-based and time-based or any combination thereof, and are expected to vest within four years. The exercise price for stock options is equal to the fair value of the underlying stock at the date of grant. We issue new shares of common stock upon exercise of stock options. Options generally have a vesting period of three years. As of June 28, 2025, 2.6 million shares of common stock under the 2015 Plan were available for grant.

[0001628280-25-040830:notes:391]
On November 28, 2023 we adopted and assumed the Cloud Light Share Option Scheme (the “Cloud Light Scheme”) in connection with the Cloud Light acquisition and we have reserved a total of 1.5 million shares of common stock for issuance thereunder, of which stock options covering 1.1 million shares were granted at the Cloud Light Closing date.

[0001628280-25-040830:notes:392]
Stock Options

[0001628280-25-040830:notes:393]
In connection with the acquisition of Cloud Light, each of Cloud Light’s outstanding options was exchanged for a combination of cash and options to acquire Lumentum common stock having equivalent value (the “replacement options”) using an exchange ratio of 0.04375 according to the terms in the Merger Agreement. At the Cloud Light Closing date, the replacement options covered 1.1 million shares with a weighted average grant date fair value of $34.63. These replacement options have a total fair value of $38.9 million as of the Closing date, of which $23.5 million attributable to pre-acquisition service was recorded as part of the purchase price consideration and the remaining $15.4 million is recorded as post-acquisition stock-based compensation expense over the vesting period of three years from the Cloud Light Closing date. Refer to “Note 4. Business Combination.”

[0001628280-25-040830:notes:394]
We estimated the fair value of the replacement options on the date of grant using the Black-Scholes option-pricing model. The assumptions used to estimate the fair value of the replacement options were as follows:

[0001628280-25-040830:notes:395]
|  | At the Acquisition Date |
| Expected terms (years) | 3.0 |
| Expected volatility | 45.0 | % |
| Risk-free interest rate | 5.0 | % |
| Dividend yield | — | % |

[0001628280-25-040830:notes:396]
Restricted Stock Units

[0001628280-25-040830:notes:397]
Restricted stock units (“RSUs”) are grants of shares of our common stock, the vesting of which is based on the requisite service requirement. Generally, our RSUs are subject to forfeiture and are expected to vest within four years. For annual refresh grants, RSUs generally vest ratably on an annual, or combination of annual and quarterly, basis over three years.

[0001628280-25-040830:notes:398]
During fiscal year 2025, our board of directors approved grants of 2.0 million shares which primarily vest over three years. The fair value of these grants is based on the closing market price of our common stock on the date of grant.

[0001628280-25-040830:notes:399]
In connection with the NeoPhotonics acquisition, we issued awards to certain NeoPhotonics employees, consisting of restricted stock units in exchange for their NeoPhotonics equity awards. The terms of these replacement awards are substantially similar to the original NeoPhotonics equity awards. The replacement awards consisted of 0.4 million restricted stock units with a grant date fair value of $93.4 per share, which represents our closing stock price on August 3, 2022, the acquisition closing date. The total fair value of these replacement awards is $40.2 million, $3.5 million of which is attributable to employee services rendered through the acquisition closing date and was recognized as a component of the purchase consideration. The remaining $36.7 million of the replacement awards is recorded as stock-based compensation over the remaining vesting period.

[0001628280-25-040830:notes:400]
Performance Stock Units

[0001628280-25-040830:notes:401]
Performance stock units (“PSUs”) are grants of shares of our common stock that vest upon the achievement of certain performance and service conditions. For PSUs with performance-based conditions, the fair value of these grants is based on the closing market price of our common stock on the date of grant, and we begin recognizing compensation expense when we conclude that it is probable that the performance conditions will be achieved. We reassess the probability of vesting at each reporting period and adjust our compensation cost based on this probability assessment. For PSUs with market-based conditions, the fair value of these grants is estimated using a Monte-Carlo simulation model, and the compensation expense is recognized ratably over the requisite service period regardless of whether or not the market condition is satisfied, provided the requisite service is rendered. Our PSUs are subject to risk of forfeiture until performance and service conditions are satisfied and generally vest within three years.

[0001628280-25-040830:notes:402]
During fiscal year 2025, our board of directors approved a grant of 0.7 million PSUs with an aggregate grant date fair value of $39.8 million to executive and non-executive employees as part of our Annual Incentive Plan (“AIP PSUs”). These AIP PSUs are subject to performance targets and service conditions, with a vesting period of one year. The board of directors also approved a grant of 0.3 million PSUs with an aggregate grant date fair value of $18.3 million to certain executive officers and senior management. These PSUs will vest subject to the achievement of revenue targets and certain non-financial performance measurements, as well as service conditions, over three years. The number of shares may be increased or decreased based on the results of these measurement targets ranging between 0% and 300% in accordance with the terms established at the date of grant. In addition, the board of directors also approved a grant of 0.1 million PSUs with an aggregate grant date fair value of $7.7 million to certain executive officers and senior management. These PSUs will vest subject to the achievement of the Company’s total shareholder return (or “TSR”) relative to specified peer group (or “rTSR”), as well as service conditions, over three years. The number of shares may be increased or decreased based on the results of these measurement targets ranging between 0% and 300% in accordance with the terms established at the date of grant. The Company estimated the grant date fair value of TSR awards using a Monte-Carlo simulation model, which was calculated at $70.57 per share. We also granted approximately 0.2 million PSUs with an aggregate grant date fair value of $17.4 million to our new President and Chief Executive Officer. These PSUs will vest subject to the achievement of the Company’s rTSR, as well as service conditions, over four years. The number of shares may be increased or decreased based on the results of these measurement targets ranging between 0% and 200% in accordance with the terms established at the date of grant. The Company estimated the grant date fair value of TSR awards using a Monte-Carlo simulation model, which was calculated at $107.72 per share.

[0001628280-25-040830:notes:403]
Employee Stock Purchase Plan

[0001628280-25-040830:notes:404]
The ESPP provides eligible employees with the opportunity to acquire an ownership interest in the Company through periodic payroll deductions and provides a 15% purchase price discount as well as a 6-month look-back period. The ESPP is structured as a qualified employee stock purchase plan under Section 423 of the Internal Revenue Code of 1986, as amended. The ESPP will terminate upon the date on which all shares available for issuance have been sold. Of the 3.0 million shares authorized under the 2015 Purchase Plan, 0.4 million shares remained available for issuance as of June 28, 2025.

[0001628280-25-040830:notes:405]
Stock-Based Compensation

[0001628280-25-040830:notes:406]
The impact on our results of operations of recording stock-based compensation by function during the periods presented was as follows (in millions):

[0001628280-25-040830:notes:407]
|  | Years Ended |
|  | June 28, 2025 |  | June 29, 2024 |  |  |  |  | July 1, 2023 |
| Cost of sales | $ | 36.9 |  |  | $ | 31.7 |  |  |  |  |  | $ | 30.1 |  |
| Research and development | 43.3 |  |  | 38.1 |  |  |  |  |  | 41.4 |  |
| Selling, general and administrative | 97.0 |  |  | 59.0 |  |  |  |  |  | 76.9 |  |
| Total stock-based compensation | $ | 177.2 |  |  | $ | 128.8 |  |  |  |  |  | $ | 148.4 |  |

[0001628280-25-040830:notes:408]
Our stock-based compensation by equity awards for the periods presented were as follows (in millions):

[0001628280-25-040830:notes:409]
|  | Years Ended |
|  | June 28, 2025 |  | June 29, 2024 |  | July 1, 2023 |
| RSUs | $ | 101.8 |  |  | $ | 114.3 |  |  | $ | 135.3 |  |
| AIP PSUs | 29.8 |  |  | 0.8 |  |  | — |  |
| TSR PSUs | 3.2 |  |  | — |  |  | — |  |
| Other PSUs | 31.6 |  |  | 5.8 |  |  | 16.0 |  |
| Total PSUs | 64.6 |  |  | 6.6 |  |  | 16.0 |  |
| Options | 6.1 |  |  | 3.3 |  |  | — |  |
| ESPP | 4.9 |  |  | 4.7 |  |  | 5.0 |  |
| Sub-total | 177.4 |  |  | 128.9 |  |  | 156.3 |  |
| Change in stock-based compensation capitalized to inventory | (0.2) |  |  | (0.1) |  |  | (7.9) |  |
| Total stock-based compensation | $ | 177.2 |  |  | $ | 128.8 |  |  | $ | 148.4 |  |

[0001628280-25-040830:notes:410]
Stock-based compensation for fiscal years 2025, 2024 and 2023 includes $64.6 million, $6.6 million and $16.0 million, respectively, of expenses related to PSUs. The amount of stock-based compensation expense recognized in any one period related to PSUs with performance-based conditions can vary based on the achievement or anticipated achievement of the performance conditions. If the performance conditions are not met or not expected to be met, no compensation expense would be recognized on the underlying PSUs, and any previously recognized compensation expense related to those PSUs would be reversed.

[0001628280-25-040830:notes:411]
During the twelve months ended June 28, 2025, the total PSU expense of $64.6 million includes $18.2 million of additional stock-compensation expense resulting from modifications. On February 2, 2025, the Company and our former President and Chief Executive Officer mutually agreed to modify the terms of previously granted equity awards by changing the level of remaining service condition required for vesting. In accordance with ASC 718, Compensation - Stock Compensation, the Company accounted for the change as a modification as the Company determined the remaining service conditions were non-substantive. For awards that vested on February 20, 2025, the separation date, we recognized compensation expense equal to the sum of the remaining unrecognized grant-date fair value amounting to $9.0 million during the twelve months ended June 28, 2025. For awards that will vest on December 15, 2025, the termination date, we recognized compensation expense equal to the sum of the remaining unrecognized grant-date fair value and any incremental fair value resulting from the modification of $19.2 million during the twelve months ended June 28, 2025. The modification date, for accounting purposes, was determined to be February 2, 2025, the date on which mutual agreement between the Company and employee was achieved. As February 2, 2025 was a non-trading day, the Company used observable market inputs as of January 31, 2025 (the most recent trading day prior to the modification date) to determine the fair value of the modified awards in accordance with fair value measurement principles under ASC 718.

[0001628280-25-040830:notes:412]
Total income tax benefit associated with stock-based compensation recognized in our consolidated statements of operations during the years presented was as follows (in millions):

[0001628280-25-040830:notes:413]
|  | Years Ended |
|  | June 28, 2025 |  | June 29, 2024 |  |  |  |  | July 1, 2023 |
| Income tax benefit associated with stock-based compensation | $ | 2.5 |  |  | $ | 7.5 |  |  |  |  |  | $ | 10.4 |  |

[0001628280-25-040830:notes:414]
Approximately $14.6 million and $14.4 million of stock-based compensation was capitalized to inventory as of June 28, 2025 and June 29, 2024, respectively.

[0001628280-25-040830:notes:415]
The table below summarizes the unrecognized stock-based compensation cost related to unvested shares and the weighted-average period over which it is expected to be recognized as of June 28, 2025:

[0001628280-25-040830:notes:416]
|  | Unrecognized stock-based compensation (in millions) |  | Weighted-average period(in years) |
| RSUs | $ | 117.8 |  |  | 1.9 |
| PSUs | 40.2 |  |  | 2.3 |
| Stock options | 5.9 |  |  | 1.4 |
| ESPP | 2.4 |  |  | 0.4 |

[0001628280-25-040830:notes:417]
Stock Award Activity

[0001628280-25-040830:notes:418]
The following table summarizes our awards activity in fiscal years 2025, 2024 and 2023 (in millions, except per share amounts):

[0001628280-25-040830:notes:419]
|  |  |  |  |  | Stock Options |  | Restricted Stock Units |  |  |  | Performance Stock Units |
|  |  |  |  |  | Number of Shares |  | Weighted-Average Exercise Price per Share |  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |  |  |  |  |  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |
| Balance as of July 2, 2022 |  |  |  |  | — |  |  | $ | — |  |  | 2.0 |  |  | $ | 85.9 |  |  |  |  |  |  | 0.3 |  |  | $ | 81.9 |  |
| Replacement Awards Issued |  |  |  |  | — |  |  | — |  |  | 0.4 |  |  | 93.4 |  |  |  |  |  |  | — |  |  | n/a |
| Granted |  |  |  |  | — |  |  | — |  |  | 1.8 |  |  | 85.1 |  |  |  |  |  |  | 0.6 |  |  | 87.9 |  |
| Vested/Exercised |  |  |  |  | — |  |  | — |  |  | (1.3) |  |  | 85.8 |  |  |  |  |  |  | (0.2) |  |  | 73.2 |  |
| Canceled |  |  |  |  | — |  |  | — |  |  | (0.3) |  |  | 87.7 |  |  |  |  |  |  | (0.1) |  |  | 89.2 |  |
| Balance as of July 1, 2023 |  |  |  |  | — |  |  | $ | — |  |  | 2.6 |  |  | $ | 85.0 |  |  |  |  |  |  | 0.6 |  |  | $ | 89.1 |  |
| Replacement options in connection with Cloud Light acquisition |  |  |  |  | 1.1 |  |  | $ | 8.0 |  |  | — |  |  | — |  |  |  |  |  |  | — |  |  | — |  |
| Granted |  |  |  |  | — |  |  | — |  |  | 2.0 |  |  | 52.2 |  |  |  |  |  |  | 0.7 |  |  | 52.8 |  |
| Vested/Exercised |  |  |  |  | — |  |  | 8.2 |  |  | (1.3) |  |  | 85.7 |  |  |  |  |  |  | (0.1) |  |  | 87.7 |  |
| Canceled |  |  |  |  | — |  |  | — |  |  | (0.6) |  |  | 68.7 |  |  |  |  |  |  | (0.3) |  |  | 78.7 |  |
| Balance as of June 29, 2024 |  |  |  |  | 1.1 |  |  | $ | 8.0 |  |  | 2.7 |  |  | $ | 62.5 |  |  |  |  |  |  | 0.9 |  |  | $ | 65.5 |  |
| Granted |  |  |  |  | — |  |  | $ | — |  |  | 2.0 |  |  | 60.2 |  |  |  |  |  |  | 1.3 |  |  | 60.5 |  |
| Vested/Exercised |  |  |  |  | (0.5) |  |  | $ | 7.8 |  |  | (1.7) |  |  | 64.4 |  |  |  |  |  |  | (0.1) |  |  | 83.5 |  |
| Canceled |  |  |  |  | — |  |  | $ | — |  |  | (0.4) |  |  | 60.3 |  |  |  |  |  |  | (0.5) |  |  | 61.4 |  |
| Balance as of June 28, 2025 |  |  |  |  | 0.6 |  |  | $ | 8.1 |  |  | 2.6 |  |  | $ | 59.9 |  |  |  |  |  |  | 1.6 |  |  | $ | 61.0 |  |

[0001628280-25-040830:notes:420]
A summary of awards available for grant for fiscal years 2025, 2024 and 2023 is as follows (in millions):

[0001628280-25-040830:notes:421]
|  | Awards Available for Grant |
| Balance as of July 2, 2022 | 3.8 |  |
| Assumed in connection with NeoPhotonics acquisition | 0.4 |  |
| Replacement Awards | (0.4) |  |
| Authorized | 0.9 |  |
| Granted | (2.4) |  |
| Canceled | 0.4 |  |
| Balance as of July 1, 2023 | 2.7 |  |
| Authorized in connection with Cloud Light acquisition | 1.5 |  |
| Replacement options in connection with Cloud Light acquisition | (1.1) |  |
| Authorized | 3.0 |  |
| Granted | (2.7) |  |
| Canceled | 0.9 |  |
| Balance as of June 29, 2024 | 4.3 |  |
| Authorized | 0.7 |  |
| Granted | (3.3) |  |
| Canceled | 0.9 |  |
| Balance as of June 28, 2025 | 2.6 |  |

[0001628280-25-040830:notes:422]
Employee Stock Purchase Plan Activity

[0001628280-25-040830:notes:423]
The ESPP expense for fiscal years 2025, 2024 and 2023 was $4.9 million, $4.7 million, and $5.0 million, respectively. The expense related to the ESPP is recorded on a straight-line basis over the relevant subscription period. There were 0.3 million, 0.4 million, and 0.3 million shares issued to employees through the ESPP during fiscal years 2025, 2024 and 2023, respectively.

[0001628280-25-040830:notes:424]
We estimate the fair value of the ESPP shares on the date of grant using the Black-Scholes option-pricing model. The assumptions used to estimate the fair value of the ESPP shares during the periods presented were as follows:

[0001628280-25-040830:notes:425]
|  | June 28, 2025 |  | June 29, 2024 |
| Expected term (years) | 0.5 |  | 0.5 |
| Expected volatility | 69.8 | % |  | 51.9 | % |
| Risk-free interest rate | 4.22 | % |  | 5.28 | % |
| Dividend yield | — | % |  | — | % |


## us-gaap:ScheduleOfShareBasedPaymentAwardEmployeeStockPurchasePlanValuationAssumptionsTableTextBlock

[0001628280-25-040830:notes:426]
The assumptions used to estimate the fair value of the replacement options were as follows:

[0001628280-25-040830:notes:427]
The assumptions used to estimate the fair value of the ESPP shares during the periods presented were as follows:


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001628280-25-040830:notes:428]
Note 15. Employee Retirement Plans

[0001628280-25-040830:notes:429]
Defined Contribution Plans

[0001628280-25-040830:notes:430]
In the United States, the Company sponsors the Lumentum 401(k) Retirement Plan (the “401(k) Plan”), a defined contribution plan under the Employee Retirement Income Security Act of 1974 (“ERISA”), which provides retirement benefits for its eligible employees through tax deferred salary deductions. The 401(k) Plan allows employees to contribute up to 50% of their annual compensation, with contributions limited to $23,500 (or $31,000 for employees over 50 years of age) in calendar year 2025 as set by the Internal Revenue Service. Employees are eligible for matching contributions after completing 180 days of service. The Company’s match is contributed on a per-pay-period basis and is based on employees’ before-tax contributions and compensation each pay period. All matching contributions are made in cash and vest immediately under the 401(k) Plan. In fiscal years 2025, 2024 and 2023, our contribution expense to the 401(k) Plan was $2.7 million, $3.8 million, and $3.8 million, respectively.

[0001628280-25-040830:notes:431]
We also have defined contribution plans in most of the other countries in which we operate, either as required by statutory law or as provided by the Company’s supplemental offering. Our contribution expense to all defined contribution plans outside the United States were $11.4 million, $7.4 million, and $8.1 million for fiscal years 2025, 2024 and 2023, respectively.

[0001628280-25-040830:notes:432]
Defined Benefit Plans

[0001628280-25-040830:notes:433]
The Company sponsors defined benefit pension plans covering employees in Japan, Switzerland and Thailand. Pension plan benefits are based primarily on participants’ compensation and years of service credited as specified under the terms of each country’s plan. Employees are entitled to a lump sum benefit upon retirement or upon certain instances of termination.  The funding policy is consistent with the local requirements of each country.

[0001628280-25-040830:notes:434]
We account for our defined benefit obligations in accordance with the authoritative guidance which requires us to record our obligation to the participants, as well as the corresponding net periodic cost. We determine our obligation to the participants and our net periodic cost using actuarial valuations provided by third-party actuaries. As of June 28, 2025, our projected benefit obligations, net, in Japan, Switzerland and Thailand were $2.3 million, $2.6 million and $5.7 million, respectively. They were recorded in our consolidated balance sheets as accrued payroll and related expenses for the short-term portion while other non-current liabilities for the long-term portion, and represent the total projected benefit obligation (“PBO”) less the fair value of plan assets.

[0001628280-25-040830:notes:435]
As of June 28, 2025, the defined benefit plans in Switzerland were partially funded, while the defined benefit plans in Japan and Thailand were unfunded.

[0001628280-25-040830:notes:436]
The change in the benefit obligations of pension plans in Japan, Switzerland, and Thailand, and the change in plan assets in Switzerland were as follows (in millions):

[0001628280-25-040830:notes:437]
|  | June 28, 2025 |  | June 29, 2024 |
| Change in projected benefit obligation: |  |  |  |
| Benefit obligation at beginning of year | $ | 24.5 |  |  | $ | 24.8 |  |
| Assumed pension liability in Japan in connection with NeoPhotonics acquisition | — |  |  | — |  |
| Service cost | 1.7 |  |  | 1.9 |  |
| Interest cost | 0.5 |  |  | 0.4 |  |
| Plan participants’ contributions | 0.8 |  |  | 1.1 |  |
| Actuarial losses (1) | 3.0 |  |  | 0.4 |  |
| Net benefits payment | (2.0) |  |  | (3.3) |  |
| Settlements | (1.6) |  |  | — |  |
| Plan amendments | (0.2) |  |  | (0.1) |  |
| Foreign exchange impact | 2.9 |  |  | (0.7) |  |
| Benefit obligation at end of year | $ | 29.6 |  |  | $ | 24.5 |  |
| Change in plan assets: |  |  |  |
| Fair value of plan assets at beginning of year | $ | 14.9 |  |  | $ | 13.4 |  |
| Actual return on plan assets | 1.1 |  |  | 0.8 |  |
| Employer contribution | 2.8 |  |  | 3.1 |  |
| Plan participants’ contribution | 0.8 |  |  | 1.1 |  |
| Net benefits payment | (2.0) |  |  | (3.3) |  |
| Settlements | (1.6) |  |  | — |  |
| Foreign exchange impact | 1.8 |  |  | (0.2) |  |
| Fair value of plan assets at end of year | $ | 17.8 |  |  | $ | 14.9 |  |
| Funded status (2) | $ | (11.8) |  |  | $ | (9.6) |  |
| Changes in benefit obligations and plan assets recognized in other comprehensive income: |  |  |  |
| Net actuarial loss (gain) | $ | 2.4 |  |  | $ | (0.1) |  |
| Loss recognized due to settlement | (0.4) |  |  | (0.1) |  |
|  | $ | 2.0 |  |  | $ | (0.2) |  |
| Accumulated benefit obligation | $ | 23.2 |  |  | $ | 19.6 |  |

[0001628280-25-040830:notes:438]
(1) Actuarial losses are primarily driven by changes in discount rates.

[0001628280-25-040830:notes:439]
(2) The current portion of the projected benefit obligation is $0.9 million and $1.0 million, respectively, as of June 28, 2025 and June 29, 2024, which was recorded under accrued payroll and related expenses in the consolidated balance sheets. The non-current portion of the projected benefit obligation is $11.0 million and $8.6 million, respectively, as of June 28, 2025 and June 29, 2024, which was recorded under other non-current liabilities in the consolidated balance sheets. Refer to “Note 7. Balance Sheet Details.”

[0001628280-25-040830:notes:440]
Net periodic pension costs in Japan, Switzerland and Thailand include the following components for the periods presented (in millions):

[0001628280-25-040830:notes:441]
|  | Years Ended |  |  |  |
|  | June 28, 2025 |  | June 29, 2024 |  | July 1, 2023 |  |  |  |
| Service cost | $ | 1.7 |  |  | $ | 1.9 |  |  | $ | 1.7 |  |  |  |  |
| Interest cost | 0.5 |  |  | 0.4 |  |  | 0.3 |  |  |  |  |
| Amortization of prior service cost | (0.1) |  |  | (0.1) |  |  | (0.1) |  |  |  |  |
| Expected return on plan assets | (0.5) |  |  | (0.4) |  |  | (0.3) |  |  |  |  |
| Settlement losses | 0.4 |  |  | 0.1 |  |  | — |  |  |  |  |
| Net periodic pension cost | $ | 2.0 |  |  | $ | 1.9 |  |  | $ | 1.6 |  |  |  |  |

[0001628280-25-040830:notes:442]
Assumptions

[0001628280-25-040830:notes:443]
Underlying both the calculation of the projected benefit obligation and net periodic cost are actuarial valuations. These valuations use participant-specific information such as salary, age and assumptions about interest rates, compensation increases and other factors. At a minimum, we evaluate these assumptions annually and make changes as necessary.

[0001628280-25-040830:notes:444]
The discount rate reflects the estimated rate at which the pension benefits could be effectively settled. In developing the discount rate, we consider the yield available on an appropriate AA or AAA corporate bond index, adjusted to reflect the term of the plan’s liabilities.

[0001628280-25-040830:notes:445]
The expected return on assets was estimated by using the weighted average of the real expected long-term return (net of inflation) on the relevant classes of assets based on the target asset mix and adding the chosen inflation assumption.

[0001628280-25-040830:notes:446]
The following table summarizes the weighted-average assumptions used to determine net periodic cost and benefit obligation for our defined benefit plans in Japan, Switzerland and Thailand:

[0001628280-25-040830:notes:447]
|  | Years Ended |
|  | June 28, 2025 |  | June 29, 2024 |
| Assumptions used to determine net periodic cost: |  |  |  |
| Discount rate | 2.0 | % |  | 2.0 | % |
| Expected long-term return on plan assets | 3.0 | % |  | 3.0 | % |
| Salary increase rate | 3.9 | % |  | 3.8 | % |
| Assumptions used to determine benefit obligation at end of year: |  |  |  |
| Discount rate | 1.3 | % |  | 1.8 | % |
| Salary increase rate | 3.0 | % |  | 2.9 | % |

[0001628280-25-040830:notes:448]
Fair Value Measurement of Plan Assets

[0001628280-25-040830:notes:449]
The following table sets forth the plan assets of our defined benefit plan in Switzerland at fair value and the percentage of assets allocations as of June 28, 2025 and June 29, 2024 (in millions, except percentage data):

[0001628280-25-040830:notes:450]
|  |  |  |  |  |  | Fair value measurement as of June 28, 2025 |
|  | Target allocation | Total |  | Percentage of plan asset |  | Quoted prices in active markets for identical assets(Level 1) |  | Significant other observable inputs (Level 2) |
| Assets: |  |  |  |  |  |  |  |  |  |
| Global equity | 35 | % |  | $ | 6.5 |  |  | 34 | % |  | $ | — |  |  | $ | 6.5 |  |
| Fixed income | 27 | % |  | 5.1 |  |  | 27 | % |  | — |  |  | 5.1 |  |
| Alternative investment | 14 | % |  | 2.7 |  |  | 14 | % |  | — |  |  | 2.7 |  |
| Cash | 1 | % |  | 0.2 |  |  | 1 | % |  | 0.2 |  |  | — |  |
| Other assets | 23 | % |  | 4.6 |  |  | 24 | % |  | — |  |  | 4.6 |  |
| Total Assets | 100 | % |  | $ | 19.1 |  |  | 100 | % |  | $ | 0.2 |  |  | $ | 18.9 |  |

[0001628280-25-040830:notes:451]
|  |  |  |  |  |  | Fair value measurement as of June 29, 2024 |
|  | Target allocation |  | Total |  | Percentage of plan asset |  | Quoted prices in active markets for identical assets(Level 1) |  | Significant other observable inputs (Level 2) |
| Assets: |  |  |  |  |  |  |  |  |  |
| Global equity | 33 | % |  | $ | 5.1 |  |  | 32 | % |  | $ | — |  |  | $ | 5.1 |  |
| Fixed income | 30 | % |  | 4.2 |  |  | 30 | % |  | — |  |  | 4.2 |  |
| Alternative investment | 13 | % |  | 1.9 |  |  | 13 | % |  | — |  |  | 1.9 |  |
| Cash | 1 | % |  | 0.1 |  |  | 1 | % |  | 0.1 |  |  | — |  |
| Other assets | 23 | % |  | 3.6 |  |  | 24 | % |  | — |  |  | 3.6 |  |
| Total Assets | 100 | % |  | $ | 14.9 |  |  | 100 | % |  | $ | 0.1 |  |  | $ | 14.8 |  |

[0001628280-25-040830:notes:452]
Our pension assets consist of multiple institutional funds (“pension funds”) of which the fair values are based on the quoted prices of the underlying funds. Pension funds are classified as Level 2 assets since such funds are not directly traded in active markets. Global equity consists of several funds that invest primarily in Swiss and foreign equities; fixed income consists of several funds that invest primarily in investment grade domestic and overseas bonds; alternative investment consists of several funds that invest primarily in hedge funds, infrastructure funds and private equity and debt; and other assets consist of several funds that invest primarily in real estate funds.

[0001628280-25-040830:notes:453]
Future Benefit Payments

[0001628280-25-040830:notes:454]
We estimate our expected benefit payments to participants in the defined benefit pension plans based on the same assumptions used to measure our PBO at year-end which includes benefits attributable to estimated future compensation increases.

[0001628280-25-040830:notes:455]
The following benefit payments are estimated to be paid from our defined benefit pension plans (in millions):

[0001628280-25-040830:notes:456]
| Fiscal Years |  | Total |
| 2026 |  | $ | 2.0 |  |
| 2027 |  | 1.4 |  |
| 2028 |  | 1.7 |  |
| 2029 |  | 1.6 |  |
| 2030 |  | 1.7 |  |
| Next five years |  | 13.9 |  |
| Total expected benefit payments |  | $ | 22.3 |  |

[0001628280-25-040830:notes:457]
We expect to contribute $2.0 million to our defined benefit pension plans in fiscal year 2026.


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0001628280-25-040830:notes:458]
Note 16. Commitments and Contingencies

[0001628280-25-040830:notes:459]
Purchase Obligations

[0001628280-25-040830:notes:460]
Purchase obligations of $837.6 million as of June 28, 2025 represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule and adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

[0001628280-25-040830:notes:461]
We depend on a limited number of contract manufacturers, subcontractors and suppliers for raw materials, packages and standard components. We generally purchase these single or limited source products through standard purchase orders or one-year supply agreements and have no significant long-term guaranteed supply agreements with these vendors. While we seek to maintain a sufficient safety stock of such products and maintain on-going communications with our suppliers to guard against interruptions or cessation of supply, our business and results of operations could be adversely affected by a stoppage or delay of supply, substitution of more expensive or less reliable products, receipt of defective parts or contaminated materials, increases in the price of such supplies, or our inability to obtain reduced pricing from our suppliers in response to competitive pressures.

[0001628280-25-040830:notes:462]
Product Warranties

[0001628280-25-040830:notes:463]
We provide reserves for the estimated costs of product warranties at the time revenue is recognized. We typically offer a twelve-month warranty for most of our products. However, in some instances depending on the product, product components or application of our products by the end customer, our warranties can vary and generally range from six months to five years. We estimate the costs of our warranty obligations on an annualized basis based on our historical experience of known product failure rates, use of materials to repair or replace defective products, and service delivery costs incurred in correcting product failures. In addition, from time-to-time, specific warranty accruals may be made if unforeseen technical problems arise with specific products. We assess the adequacy of our recorded warranty liabilities and adjust the amounts as necessary.

[0001628280-25-040830:notes:464]
The following table presents the changes in our warranty reserve during the periods presented (in millions):

[0001628280-25-040830:notes:465]
|  | Years Ended |
|  | June 28, 2025 |  | June 29, 2024 |  |  |  |  |
| Balance as of beginning of period | $ | 13.2 |  |  | $ | 6.8 |  |  |  |  |  |
| Warranties assumed in Cloud Light acquisition | 0.8 |  |  | 8.2 |  |  |  |  |  |
| Provision for warranty | 10.2 |  |  | 6.0 |  |  |  |  |  |
| Utilization of reserve | (9.8) |  |  | (7.8) |  |  |  |  |  |
| Balance as of end of period | $ | 14.4 |  |  | $ | 13.2 |  |  |  |  |  |

[0001628280-25-040830:notes:466]
Environmental Liabilities

[0001628280-25-040830:notes:467]
Our research and development, manufacturing and distribution operations involve the use of hazardous substances and are regulated under international, federal, state and local laws governing health and safety and the environment. We apply strict standards for protection of the environment and occupational health and safety to sites inside and outside the United States, even if not subject to regulations imposed by foreign governments. We believe that our properties and operations at our facilities comply in all material respects with applicable environmental laws and occupational health and safety laws. However, the risk of environmental liabilities cannot be completely eliminated and there can be no assurance that the application of environmental and health and safety laws will not require us to incur significant expenditures. We are also regulated under a number of international, federal, state and local laws regarding recycling, product packaging and product content requirements. The environmental and product content/disposal and recycling laws are gradually becoming more stringent and may cause us to incur significant expenditures in the future.

[0001628280-25-040830:notes:468]
Legal Proceedings

[0001628280-25-040830:notes:469]
We are subject to a variety of claims and suits that arise from time-to-time in the ordinary course of our business. In addition, we are subject to various legal matters, investigations, subpoenas, inquiries, audits, claims, and disputes, including with regulatory bodies and governmental agencies. While management currently believes that resolving claims against us, individually or in the aggregate, will not have a material adverse impact on our financial position, results of operations or statements of cash flows, these matters are subject to inherent uncertainties and management’s view of these matters may change in the future. We accrue for loss contingencies when it is both probable that we will incur the loss and when we can reasonably estimate the amount of the loss or range of loss. As of June 28, 2025, the accrual for expected settlement of litigation matters was not material.

[0001628280-25-040830:notes:470]
Oclaro Merger Litigation

[0001628280-25-040830:notes:471]
In connection with our acquisition of Oclaro in 2018, seven lawsuits were filed by purported stockholders of Oclaro challenging the proposed merger (the “Merger”). All but one was voluntarily dismissed after the Oclaro Merger closed. The remaining lawsuit, SaiSravan B. Karri v. Oclaro, Inc., et al., No. 3:18-cv-03435-JD (the “Karri Lawsuit”), was filed in the United States District Court for the Northern District of California and is styled as a class action.

[0001628280-25-040830:notes:472]
The Karri Lawsuit alleges, among other things, that Oclaro and its directors violated Section 14(a) of the Securities Exchange Act of 1934, as amended (the “Exchange Act”), and Rule 14a-9 promulgated thereunder by disseminating an incomplete and misleading Form S-4, including proxy statement/prospectus. The Karri Lawsuit further alleged that Oclaro’s directors violated Section 20(a) of the Exchange Act by failing to exercise proper control over the person(s) who violated Section 14(a) of the Exchange Act. The plaintiff in the Karri Lawsuit seeks, among other things, damages to be awarded to the plaintiff and any class, if a class is certified, and litigation costs, including attorneys’ fees.

[0001628280-25-040830:notes:473]
After the plaintiff in the Karri Lawsuit was appointed as lead plaintiff and his counsel as lead counsel, the plaintiff filed a first amended complaint on April 15, 2019. The first amended complaint, also named Lumentum as a defendant but Lumentum has since been dismissed from the action. On October 8, 2020, the court granted in part and denied in part the defendant’s motion to dismiss the first amended complaint. On December 1, 2020, defendants answered the first amended complaint. On September 17, 2021, lead plaintiff filed a second amended complaint. Defendants moved to stay discovery in light of the second amended complaint. On January 11, 2022, the Court struck the second amended complaint as untimely, terminated defendants’ motions to dismiss as moot, and lifted the stay. The case proceeded through fact and expert discovery.

[0001628280-25-040830:notes:474]
On August 16, 2022, the lead plaintiff moved for class certification and to be appointed class representative. Defendants opposed the motion. The action subsequently was stayed while the parties participated in a mediation. On January 18, 2023, the lead plaintiff filed a Notice of Settlement informing the court of an agreement in principle between the parties for a class-wide settlement of the Karri Lawsuit. On January 24, 2023, in light of the potential settlement, the court vacated all pretrial and trial dates and ordered the lead plaintiff to file a motion for preliminary approval of the settlement by March 17, 2023. The lead plaintiff filed his motion for preliminary approval of the settlement on March 16, 2023, and defendants filed a statement of non-opposition on March 30, 2023. On April 20, 2023, the court held a hearing on lead plaintiff’s motion for preliminary approval of the settlement. The court declined to grant lead plaintiff’s motion for preliminary approval and ordered lead plaintiff to file a revised motion by May 22, 2023. Lead plaintiff filed his Revised Motion for Preliminary Approval of Settlement (the “Amended Motion”) on May 22, 2023, defendants filed a response in support of the Amended Motion on June 5, 2023, and the lead plaintiff submitted his reply in further support of the Amended Motion on June 12, 2023. The hearing on the Amended Motion took place on August 17, 2023 and the court preliminarily approved the settlement and scheduled the fairness hearing for February 22, 2023. On November 2, 2023, lead plaintiff filed a Motion for an Award of Attorneys’ Fees and Expenses and

[0001628280-25-040830:notes:475]
Award to Class Representative Pursuant to 15 U.S.C. §78u-4(a)(4) (the “Fee Motion”) and on November 16, 2023, Defendants filed a response to the Fee Motion. On January 11, 2024, lead plaintiff filed a Motion for Final Approval of Class Action Settlement, for Certification of the Settlement Class and for Approval of the Plan of Allocation, and supporting papers.  On January 25, 2024, lead plaintiff filed a Reply in Support of Motions for Final Approval of Class Action Settlement and an Award of Attorneys’ Fees and Expenses. On July 12, 2024, the court entered an order approving the settlement in all respects and dismissing the action with prejudice. On July 26, 2024, the court entered an order awarding attorneys’ fees and expenses and service award to Karri as class representative. Pursuant to the order, the court awarded Karri attorneys’ fees in the amount of $5.1 million and expenses in the amount of $0.4 million, all to be paid from the settlement fund, subject to certain conditions.

[0001628280-25-040830:notes:476]
We recorded the court approved settlement amount of $15.3 million as accrued expenses in our condensed consolidated balance sheet as of June 29, 2024, of which $7.5 million represents the amount to be reimbursed by insurance and was recorded as prepayments and other current assets.

[0001628280-25-040830:notes:477]
Regulatory Matters

[0001628280-25-040830:notes:478]
In August 2024, the Company received inquiries from the Bureau of Industry and Security of the U.S. Department of Commerce (“BIS”) and Department of Justice (“DOJ”) following the Company’s voluntary self-disclosures to BIS in December 2023, and supplemented in April 2024. The Company continues to cooperate with both agencies on this matter. The Company is unable to predict the likely outcome of these matters.

[0001628280-25-040830:notes:479]
Indemnifications

[0001628280-25-040830:notes:480]
In the normal course of business, we enter into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown, because claims may be made against us in the future and we may record charges in the future as a result of these indemnification obligations. As of June 28, 2025, we did not have any material indemnification claims that were probable or reasonably possible.

[0001628280-25-040830:notes:481]
Audit Proceedings

[0001628280-25-040830:notes:482]
We are under audit by various domestic and foreign tax authorities with regards to income tax and indirect tax matters. In some, although not all cases, we have reserved for potential adjustments to our provision for income taxes and accrual of indirect taxes that may result from examinations by these tax authorities or final outcomes in judicial proceedings, and we believe that the final outcome of these examinations, agreements or judicial proceedings will not have a material effect on our results of operations. If events occur which indicate payment of these amounts is unnecessary, the reversal of the liabilities would result in the recognition of benefits in the period when we determine the liabilities are no longer necessary. If our estimates of the federal, state, and foreign income tax liabilities and indirect tax liabilities are less than the ultimate assessment, it could result in a further charge to expense.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001628280-25-040830:notes:483]
Note 17. Operating Segments and Geographic Information

[0001628280-25-040830:notes:484]
Our Chief Executive Officer is our Chief Operating Decision Maker (“CODM”). We have two operating segments, Cloud & Networking and Industrial Tech, which also represent our two reportable segments. The CODM allocates resources to the segments based on their business prospects, competitive factors, segment net revenue and segment profit. Segment profit includes operating expenses directly managed by operating segments, including research and development, and direct sales and marketing expenses. The CODM regularly reviews operating results to make decisions about resources to be allocated to the segments and to assess their performance.

[0001628280-25-040830:notes:485]
Cloud & Networking

[0001628280-25-040830:notes:486]
Industrial Tech

[0001628280-25-040830:notes:487]
Reportable Segments

[0001628280-25-040830:notes:488]
The two operating segments, Cloud & Networking and Industrial Tech, also represent our two reportable segments. Our CODM allocates resources and evaluates segment performance based on segment revenue and segment profit. The following table summarizes segment profit and a reconciliation to the consolidated loss before income taxes for the periods presented (in millions). Segment profit does not include stock-based compensation, acquisition or integration related costs, amortization and impairment of acquisition-related intangible assets, restructuring and related charges, and certain other charges. Additionally, we do not allocate corporate marketing and strategic marketing expenses and general and administrative expenses, as these expenses are not directly attributable to our operating segments. In addition, we do not track all of our property, plant and equipment by operating segments. Comparative prior period segment information has been recast to conform to the new segment structure.

[0001628280-25-040830:notes:489]
Information on reportable segments utilized by our CODM is as follows (in millions):

[0001628280-25-040830:notes:490]
|  |  |  | Years Ended |
|  |  |  |  |  | June 28, 2025 |  | June 29, 2024 |  | July 1, 2023 |
|  |  |  |  |  | Cloud & Networking | Industrial Tech | Total |  | Cloud & Networking | Industrial Tech | Total |  | Cloud & Networking | Industrial Tech | Total |
| Net revenue |  |  |  |  | $ | 1,410.8 |  | 234.2 |  | $ | 1,645.0 |  |  | $ | 1,084.9 |  | 274.3 |  | $ | 1,359.2 |  |  | $ | 1,322.5 |  | 444.5 |  | $ | 1,767.0 |  |
| Cost of sales |  |  |  |  | 924.4 | 149.2 | 1073.6 |  | 743.8 | 166.5 | 910.3 |  | 794.3 | 209.2 | 1003.5 |
| Segment gross profit |  |  |  |  | 486.4 |  | 85.0 |  | 571.4 |  |  | 341.1 |  | 107.8 |  | 448.9 |  |  | 528.2 |  | 235.3 |  | 763.5 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  |  |  | 194.7 |  | 61.3 |  | 256.0 |  |  | 192.4 |  | 68.0 |  | 260.4 |  |  | 181.8 |  | 67.2 |  | 249.0 |  |
| Selling, general and administrative |  |  |  |  | 27.2 |  | 11.6 |  | 38.8 |  |  | 24.20 |  | 14.70 |  | 38.9 |  |  | 33.2 |  | 15.4 |  | 48.6 |  |
| Segment profit |  |  |  |  | $ | 264.5 |  | 12.1 |  | 276.6 |  |  | $ | 124.5 |  | 25.1 |  | $ | 149.6 |  |  | $ | 313.2 |  | 152.7 |  | $ | 465.9 |  |

[0001628280-25-040830:notes:491]
Reconciliation of segment profit to consolidated loss before income taxes is as follows (in millions):

[0001628280-25-040830:notes:492]
|  |  |  | Years Ended |
|  |  |  |  |  | June 28, 2025 |  | June 29, 2024 |  | July 1, 2023 |
| Segment profit |  |  |  |  | $ | 276.6 |  |  | $ | 149.6 |  |  | $ | 465.9 |  |
| Unallocated corporate items: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative (1) |  |  |  |  | (116.5) |  |  | (111.8) |  |  | (126.7) |  |
| Stock-based compensation (2) |  |  |  |  | (177.2) |  |  | (128.8) |  |  | (136.5) |  |
| Stock-based compensation - acquisition related |  |  |  |  | — |  |  | — |  |  | (11.9) |  |
| Amortization of acquired intangibles |  |  |  |  | (149.7) |  |  | (150.6) |  |  | (127.7) |  |
| Amortization of acquired inventory fair value adjustments |  |  |  |  | — |  |  | (8.3) |  |  | (17.8) |  |
| Acquisition related costs |  |  |  |  | (1.2) |  |  | (13.3) |  |  | (11.5) |  |
| Integration related costs |  |  |  |  | (9.2) |  |  | (37.1) |  |  | (28.6) |  |
| Restructuring and related charges |  |  |  |  | (22.8) |  |  | (72.6) |  |  | (28.1) |  |
| Abnormal excess capacity (3) |  |  |  |  | — |  |  | (20.7) |  |  | — |  |
| Litigation matters |  |  |  |  | — |  |  | — |  |  | (7.8) |  |
| Intangible asset write-off |  |  |  |  | (2.7) |  |  | — |  |  | (21.3) |  |
| Gain on sale of facility (4) |  |  |  |  | 34.9 |  |  | — |  |  | — |  |
| Other charges, net (5) |  |  |  |  | (12.3) |  |  | (40.4) |  |  | (63.7) |  |
| Interest expense |  |  |  |  | (22.2) |  |  | (33.8) |  |  | (35.5) |  |
| Other income, net (6) |  |  |  |  | 30.2 |  |  | 62.1 |  |  | 48.8 |  |
| Consolidated loss before income taxes |  |  |  |  | $ | (172.1) |  |  | $ | (405.7) |  |  | $ | (102.4) |  |

[0001628280-25-040830:notes:493]
(1) We do not allocate selling, general and administrative expenses that are not directly attributable to our operating segments.

[0001628280-25-040830:notes:494]
2) Stock-based compensation for the year ended June 28, 2025 includes $28.2 million of stock-based compensation expense resulting from equity award modifications for our former President and Chief Executive Officer (“CEO”), which include RSUs and PSUs that were immediately expensed as of the separation date.

[0001628280-25-040830:notes:495]
(3) Abnormal excess capacity for the year ended June 29, 2024 represents excess capacity attributable to a near-term reduction in our manufacturing production, primarily driven by our non-recurring inventory reduction effort following the disruptions in the supply chain due to the COVID-19 pandemic and factory consolidation efforts.

[0001628280-25-040830:notes:496]
(4) Gain on sale of facility for the year ended June 28, 2025 represents a gain for net assets sold in an entity in Shenzhen, China, which consist primarily of building, building improvements and land rights.

[0001628280-25-040830:notes:497]
(5) Other charges, net for the year ended June 28, 2025 mainly includes $12.2 million of legal and professional fees primarily related to non-ordinary course legal matters, $6.2 million of CEO transition costs, and $3.2 million of bad debt reserve related to the remaining unpaid balances due from Huawei associated with the trade restrictions, offset by a credit of $5.2 million associated with an audit settlement of indirect taxes for prior periods and a $5.0 million credit related to units sold that were previously written-down.

[0001628280-25-040830:notes:498]
Other charges, net for the year ended June 29, 2024 primarily relate to $11.2 million of net excess and obsolete inventory, $12.4 million of non-recurring legal and professional fees, $4.9 million of incremental costs of sales related to components previously acquired from various brokers to satisfy customer demand and $3.4 million of one-time charge as a result of contract termination with one of our vendors due to a change in our manufacturing strategy, offset by various miscellaneous gains. The excess and obsolete inventory charges relate to charges that are not attributable to our operating segments due to their unusual nature, primarily those charges driven by U.S. trade restrictions whereby we are no longer able to sell certain products to one of our customers.

[0001628280-25-040830:notes:499]
Other charges, net for the year ended July 1, 2023 primarily relate to $32.5 million of incremental costs of sales related to components previously acquired from various brokers to satisfy customer demand, $12.5 million of non-recurring legal and professional fees, $5.4 million of excess and obsolete inventory charges primarily driven by synergies as a result of the NeoPhotonics integration and $2.7 million of excess and obsolete inventory charges driven by U.S. trade restrictions and the related decline in demand from Huawei.

[0001628280-25-040830:notes:500]
(6) Other income, net for the year ended June 28, 2025 includes interest and investment income of $34.4 million, and foreign exchange losses, net of $4.2 million.

[0001628280-25-040830:notes:501]
Other income, net for the year ended June 29, 2024 includes interest and investment income of $61.3 million, and foreign exchange gains, net of $0.8 million.

[0001628280-25-040830:notes:502]
Other income, net for the year ended July 1, 2023 includes interest and investment income of $40.8 million, foreign exchange gains, net of $7.0 million, and other income, net of $1.0 million.

[0001628280-25-040830:notes:503]
Concentrations

[0001628280-25-040830:notes:504]
We operate in three geographic regions: Americas, Asia-Pacific, and EMEA (Europe, Middle East, and Africa). Net revenue is assigned to the geographic region and country where our product is initially shipped to. For example, certain customers may request shipment of our product to a contract manufacturer in one country, which may differ from the location of their end customers. The following table presents net revenue by the three geographic regions we operate in and net revenue from countries that represented 10% or more of our total net revenue (in millions, except percentage data):

[0001628280-25-040830:notes:505]
|  |  |  | Years Ended |  |
|  |  |  |  |  | June 28, 2025 |  | June 29, 2024 |  | July 1, 2023 |  |
|  |  |  |  |  |  |  |  |  | Amount |  | % to Total |  | Amount |  | % to Total |  | Amount |  | % to Total |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  |  |  |  |  |  |  |  | $ | 312.3 |  |  | 19.0 | % |  | $ | 356.1 |  |  | 26.2 | % |  | $ | 241.3 |  |  | 13.7 | % |  |
| Mexico |  |  |  |  |  |  |  |  | 148.5 |  |  | 9.0 |  |  | 91.7 |  |  | 6.7 |  |  | 180.0 |  |  | 10.2 |  |  |
| Other Americas |  |  |  |  |  |  |  |  | 20.1 |  |  | 1.2 |  |  | 3.4 |  |  | 0.3 |  |  | 9.3 |  |  | 0.5 |  |  |
| Total Americas |  |  |  |  |  |  |  |  | $ | 480.9 |  |  | 29.2 | % |  | $ | 451.2 |  |  | 33.2 | % |  | $ | 430.6 |  |  | 24.4 | % |  |
| Asia-Pacific: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Thailand |  |  |  |  |  |  |  |  | $ | 291.8 |  |  | 17.7 | % |  | $ | 183.8 |  |  | 13.5 | % |  | $ | 269.0 |  |  | 15.2 | % |  |
| Hong Kong |  |  |  |  |  |  |  |  | 398.6 |  |  | 24.2 |  |  | 261.9 |  |  | 19.3 |  |  | 246.7 |  |  | 14.0 |  |  |
| South Korea |  |  |  |  |  |  |  |  | 32.4 |  |  | 2.0 |  |  | 75.2 |  |  | 5.5 |  |  | 170.2 |  |  | 9.6 |  |  |
| Japan |  |  |  |  |  |  |  |  | 78.3 |  |  | 4.8 |  |  | 84.6 |  |  | 6.2 |  |  | 179.5 |  |  | 10.2 |  |  |
| Other Asia-Pacific |  |  |  |  |  |  |  |  | 199.5 |  |  | 12.2 |  |  | 174.3 |  |  | 12.9 |  |  | 276.3 |  |  | 15.6 |  |  |
| Total Asia-Pacific |  |  |  |  |  |  |  |  | $ | 1,000.6 |  |  | 60.9 | % |  | $ | 779.8 |  |  | 57.4 | % |  | $ | 1,141.7 |  |  | 64.6 | % |  |
| EMEA |  |  |  |  |  |  |  |  | $ | 163.5 |  |  | 9.9 | % |  | $ | 128.2 |  |  | 9.4 | % |  | $ | 194.7 |  |  | 11.0 | % |  |
| Total net revenue |  |  |  |  |  |  |  |  | $ | 1,645.0 |  |  | 100.0 | % |  | $ | 1,359.2 |  |  | 100.0 | % |  | $ | 1,767.0 |  |  | 100.0 | % |  |

[0001628280-25-040830:notes:506]
During the years ended June 28, 2025, June 29, 2024, and July 1, 2023, net revenue generated from a single customer which represented 10% or greater of total net revenue is summarized as follows:

[0001628280-25-040830:notes:507]
|  | Years Ended |
|  | June 28, 2025 |  | June 29, 2024 |  | July 1, 2023 |
| Customer A | 16.0 | % |  | 11.4 | % |  | 15.3 | % |
| Customer B | 15.4 | % |  | 18.9 | % |  | * |
| Customer C | * |  | * |  | 12.1 | % |
| Customer D | * |  | * |  | 10.5 | % |
| *Represents less than 10% of total net revenue |  |  |  |  |  |

[0001628280-25-040830:notes:508]
The following table sets forth accounts receivable from a single customer that represented 10% or greater of the total accounts receivable for the periods presented:

[0001628280-25-040830:notes:509]
|  | June 28, 2025 |  | June 29, 2024 |
| Customer 1 | 13.2 | % |  | 12.9 | % |
| Customer 2 | 11.0 | % |  | * |
| *Represents less than 10% of total accounts receivable |  |  |  |

[0001628280-25-040830:notes:510]
Long-lived assets, namely property, plant and equipment, net, were identified based on the physical location of the assets in the corresponding geographic areas as of the periods indicated (in millions):

[0001628280-25-040830:notes:511]
|  | June 28, 2025 |  | June 29, 2024 |
| Property, plant and equipment, net |  |  |  |
| United States | $ | 123.0 |  |  | $ | 131.0 |  |
| Thailand | 218.6 |  |  | 141.0 |  |
| Japan | 144.3 |  |  | 75.7 |  |
| United Kingdom | 109.4 |  |  | 83.8 |  |
| China | 76.8 |  |  | 85.7 |  |
| Other countries | 54.3 |  |  | 55.3 |  |
| Total property, plant and equipment, net | $ | 726.4 |  |  | $ | 572.5 |  |

[0001628280-25-040830:notes:512]
We purchase a portion of our inventory from contract manufacturers and vendors located primarily in Thailand, Taiwan and Malaysia. The following table sets forth inventory purchase from a single contract manufacturer that represented 10% or greater of our total net inventory purchases for the periods presented:

[0001628280-25-040830:notes:513]
|  | June 28, 2025 |  | June 29, 2024 |
| Contract Manufacturer A | 25.1 | % |  | 30.3 | % |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001628280-25-040830:notes:514]
The following table presents net revenue by the three geographic regions we operate in and net revenue from countries that represented 10% or more of our total net revenue (in millions, except percentage data):


## us-gaap:SchedulesOfConcentrationOfRiskByRiskFactorTextBlock

[0001628280-25-040830:notes:515]
The table below discloses our total net revenue attributable to each of our two reportable segments (in millions, except percentage data):

[0001628280-25-040830:notes:516]
|  |  |  | Years Ended |
|  |  |  | June 28, 2025 |  | June 29, 2024 |  | July 1, 2023 |
|  |  |  | Amount |  | % to Total |  | Amount |  | % to Total |  | Amount |  | % to Total |
| Cloud & Networking |  |  | $ | 1,410.8 |  |  | 85.8 | % |  | $ | 1,084.9 |  |  | 79.8 | % |  | $ | 1,322.5 |  |  | 74.8 | % |
| Industrial Tech |  |  | 234.2 |  |  | 14.2 | % |  | 274.3 |  |  | 20.2 | % |  | 444.5 |  |  | 25.2 | % |
| Net revenue |  |  | $ | 1,645.0 |  |  | 100.0 | % |  | $ | 1,359.2 |  |  | 100.0 | % |  | $ | 1,767.0 |  |  | 100.0 | % |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001628280-25-040830:notes:517]
Note 18. Revenue Recognition

[0001628280-25-040830:notes:518]
We disaggregate revenue by segment and by geography. We do not present other levels of disaggregation, such as by type of products, customer, markets, contracts, duration of contracts, timing of transfer of control and sales channels, as this information is not used by our CODM to manage the business.

[0001628280-25-040830:notes:519]
The following table reflects the changes in contract balances for the periods presented (in millions, except percentages):

[0001628280-25-040830:notes:520]
| Contract balances |  | Balance sheet location |  | June 28, 2025 |  | June 29, 2024 |  | Change |  | Percentage Change |
| Accounts receivable, net |  | Accounts receivable, net |  | $ | 250.0 |  |  | $ | 194.7 |  |  | $ | 55.3 |  |  | 28.4% |
| Deferred revenue and customer deposits |  | Other current liabilities |  | $ | 0.7 |  |  | $ | 0.6 |  |  | $ | 0.1 |  |  | 16.7% |


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001628280-25-040830:notes:521]
SCHEDULE II - VALUATION AND QUALIFYING ACCOUNTS

[0001628280-25-040830:notes:522]
|  | (in millions) |
|  | Balance at beginning of period |  |  |  | Increase (decrease) in Consolidated Statements of Operations |  | Write-offs and other adjustments |  |  |  | Balance at end of period |
| Allowance for credit losses: |  |  |  |  |  |  |  |  |  |  |  |
| Fiscal year ended June 28, 2025 | $ | 0.2 |  |  |  |  | $ | 3.4 |  |  | $ | (0.1) |  |  |  |  | $ | 3.5 |  |
| Fiscal year ended June 29, 2024 | $ | — |  |  |  |  | $ | 0.2 |  |  | $ | — |  |  |  |  | $ | 0.2 |  |
| Fiscal year ended July 1, 2023 | $ | — |  |  |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |

[0001628280-25-040830:notes:523]
|  |  | (in millions) |
|  |  | Balance at beginning of period |  | Additions charged to costs/expenses (1) |  | Deductions credited to costs/expenses (2) |  | Balance at end of period |
| Deferred tax valuation allowance: |  |  |  |  |  |  |  |  |
| Fiscal year ended June 28, 2025 |  | $ | 490.4 |  |  | $ | 128.6 |  |  | $ | (178.2) |  |  | $ | 440.8 |  |
| Fiscal year ended June 29, 2024 |  | $ | 303.4 |  |  | $ | 205.4 |  |  | $ | (18.4) |  |  | $ | 490.4 |  |
| Fiscal year ended July 1, 2023 |  | $ | 263.1 |  |  | $ | 42.7 |  |  | $ | (2.4) |  |  | $ | 303.4 |  |

[0001628280-25-040830:notes:524]
(1) Additions include current year additions charged to expenses and current year build due to increases in net deferred tax assets, return to provision true-ups, other adjustments to deferred taxes.

[0001628280-25-040830:notes:525]
(2) Net deductions include current year releases credited to expenses and current year reductions due to decreases in net deferred tax assets, return to provision true-ups, other adjustments to deferred taxes.
