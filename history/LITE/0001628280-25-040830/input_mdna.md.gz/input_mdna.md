# LITE MD&A — 0001628280-25-040830


## mdna

[0001628280-25-040830:mdna:1]
ITEM 7.    MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0001628280-25-040830:mdna:2]
You should read the following discussion in conjunction with the audited consolidated financial statements and the corresponding notes included elsewhere in this Annual Report. This Management’s Discussion and Analysis of Financial Condition and Results of Operations contains forward-looking statements. The matters discussed in these forward-looking statements are subject to risk, uncertainties and other factors that could cause actual results to differ materially from those made, projected or implied in the forward-looking statements. Refer to “Risk Factors” and “Forward-Looking Statements” for a discussion of the uncertainties, risks and assumptions associated with these statements.

[0001628280-25-040830:mdna:3]
Overview

[0001628280-25-040830:mdna:4]
We are a leading provider of optical and photonic products and are recognized as an industry leader based on revenue and market share. Our products are essential to a range of cloud, artificial intelligence and machine learning (“AI/ML”), telecommunications, consumer, and industrial end-market applications.

[0001628280-25-040830:mdna:5]
We believe the global markets in which Lumentum participates have fundamentally robust, long-term trends that will increase the need for our photonics products and technologies. We believe the world is becoming more reliant on ever-increasing amounts of data flowing through optical networks and data centers. Lumentum’s products and technology enable the scaling of these optical networks and data centers to higher capacities. AI/ML has caused a dramatic surge in the growing demands on data networking in cloud data centers and accelerated the usage of optical components and modules. We expect that the accelerating shift to digital and virtual approaches to many aspects of work and life will continue into the future. Virtual meetings, video calls, and hybrid in-person and virtual environments for work and other aspects of life will continue to drive strong needs for bandwidth growth and present dynamic new challenges that our technologies address. As manufacturers demand higher levels of precision, new materials, and factory and energy efficiency, suppliers of manufacturing tools globally are turning to laser-based approaches, including the types of lasers Lumentum supplies. Laser-based 3D sensing and LiDAR for security, industrial and automotive applications are rapidly developing markets. The technology enables computer vision applications that enhance security, safety, and new functionality in the electronic devices that people rely on every day. The use of LiDAR and in-cabin 3D sensing in automobile and delivery vehicles over time significantly adds to our long-term market opportunity. Additionally, we expect 3D-enabled machine vision solutions to expand significantly in industrial applications in the coming years.

[0001628280-25-040830:mdna:6]
To maintain and grow our market and technology leadership positions, we are continually investing in new and differentiated products and technologies and customer programs that address both nearer-term and longer-term growth opportunities, both organically and through acquisitions, as well as continually improving and optimizing our operations. Over many years, we have developed close relationships with market-leading customers. We seek to use our core optical and photonic technologies and our volume manufacturing capability to expand into attractive emerging markets that benefit from advantages that optical or photonics-based solutions provide.

[0001628280-25-040830:mdna:7]
We have two reportable segments, Cloud & Networking and Industrial Tech. The two operating segments were primarily determined based on how our Chief Operating Decision Maker (“CODM”) views and evaluates our operations. The CODM regularly reviews operating results to make decisions about resources to be allocated to the segments and to assess their performance. Our CODM allocates resources to the segments based on their business prospects, competitive factors, segment net revenue and segment profit. Segment profit includes operating expenses directly managed by operating segments, including research and development, and direct sales and marketing expenses. Segment profit does not include stock-based compensation, acquisition or integration related costs, amortization and impairment of acquisition-related intangible assets, restructuring and related charges, and certain other charges. Additionally, we do not allocate certain marketing and general and administrative expenses, as these expenses are not directly attributable to our operating segments.

[0001628280-25-040830:mdna:8]
Cloud & Networking

[0001628280-25-040830:mdna:9]
Our Cloud & Networking products comprise a comprehensive portfolio of optical and photonic chips, components, modules, and subsystems supplied to cloud data center operators, AI/ML infrastructure providers, and network equipment manufacturer customers who are building cloud data center and network infrastructures. Our products enable high-capacity optical links for cloud computing, AI/ML workloads, and data center interconnect (“DCI”) applications, as well as for communications service provider networks. Our offerings support access (local), metro (intracity), long-haul (intercity and global), and submarine (undersea) network infrastructure. Additionally, our Cloud & Networking products serve enterprise network infrastructure needs, including storage area networks (“SANs”), local area networks (“LANs”), and wide area networks (“WANs”). Demand for our products is fueled by the ongoing expansion of network capacity required to support cloud and services, AI/ML processing, streaming video, video conferencing, wireless and mobile connectivity, and the internet of things (“IoT”).

[0001628280-25-040830:mdna:10]
Industrial Tech

[0001628280-25-040830:mdna:11]
Our Industrial Tech products include short-pulse solid-state lasers, kilowatt-class fiber lasers, diode lasers, and gas lasers, serving a wide range of end-markets applications. In the consumer market, our laser light sources are integrated into customers’ 3D sensing cameras, primarily used in mobile devices. In the industrial manufacturing market, our lasers are embedded in machine tools used for precision material processing across diverse industries, including semiconductor and microelectronics fabrication, electric vehicle and battery production, metal cutting and welding, and advanced manufacturing. Adoption of our Industrial Tech products is driven by the need to advance semiconductor and microelectronics technology roadmaps and by Industry 4.0 and 5.0 trends that emphasize greater manufacturing precision, flexibility, and sustainability.

[0001628280-25-040830:mdna:12]
Cloud Light Acquisition

[0001628280-25-040830:mdna:13]
On November 7, 2023 (the “Closing date”), we completed the acquisition of Cloud Light. Cloud Light designs, markets, and manufactures advanced optical modules for data center interconnect applications. This acquisition enabled us to be well-positioned to serve the growing needs of cloud & networking customers, particularly those focused on optimizing their data center infrastructure for the demands of AI/ML. On the Closing date, we paid $705.0 million of total cash consideration to Cloud Light. Additionally, each of Cloud Light’s outstanding options was exchanged for a combination of cash and options to acquire Lumentum common stock having equivalent value (the “replacement options”). These replacement options have a total fair value of $38.9 million as of the Closing date, of which $23.5 million attributable to pre-acquisition service is recorded as part of the purchase price consideration and the remaining $15.4 million is recorded as post-acquisition stock-based compensation expense over the vesting period of three years from the Closing date. We also incurred a total of $9.6 million of merger-related costs, representing professional and other direct acquisition costs, which was recorded as general and administrative expense in the consolidated statement of operations for the year ended June 29, 2024. Refer to “Note 4. Business Combination” to the consolidated financial statements for additional information.

[0001628280-25-040830:mdna:14]
Supply Chain and Inventory Management

[0001628280-25-040830:mdna:15]
Our supply chain is complex, and we need to manage supply of certain components required to build our products while confronted with fluctuating demand from our customers. Our business and our customers’ businesses were negatively impacted by worldwide logistics and supply chain issues during and following the COVID-19 pandemic, including constraints on available cargo capabilities and limited availability of once broadly available supplies of both raw materials and finished components. From time to time, we experience shortages of the types of components we and our customers require in our products, and we have had to incur incremental supply and procurement costs in order to increase our ability to fulfill demands from our customers.

[0001628280-25-040830:mdna:16]
In addition, through fiscal year 2024, we experienced significant fluctuations in demand as customers delayed projected shipments or built up inventory in response to supply shortages and then brought down inventories as supply chain constraints eased. Our revenue fluctuated in response to these changes in demand and our margins were adversely impacted as we were not been able to fully recover costs, such as underutilized manufacturing capacity. However, during fiscal year 2025, network equipment manufacturers continued to normalize inventory levels and we saw increasing demand from AI and cloud customers as they continue to expand their data centers.

[0001628280-25-040830:mdna:17]
Due to worldwide operations, we and our customers are also subject to risks relating to the global trade environment. The Company is actively monitoring and assessing the global trade environment, particularly with respect to recent changes and proposed changes in tariff regulations and trade restrictions. The ongoing uncertainty surrounding trading policies, including the potential for additional tariffs, restrictions related to our customers and retaliatory measures by non-U.S. governments, continues to create a volatile environment that could disrupt our operations. The imposition of tariffs on certain imported goods and materials and export controls on critical components may increase our costs and place upward pressure on the cost of goods sold, which, in turn, may reduce our gross margins if we are unable to pass these costs onto customers through price increases.

[0001628280-25-040830:mdna:18]
If these tariff-related cost increases persist or escalate, our financial results could be adversely affected, including lower profitability. Additionally, changes in the global trade landscape could result in reduced market competitiveness and a slowdown in consumer demand as well as disruptions to our supply chain, including longer lead times, higher shipping costs, or limited availability of key inputs. This may constrain our ability to meet customer demand in a timely manner, potentially affecting our revenue growth and operational efficiency. The impact of tariffs on our business is hard to predict, as it is dependent on negotiations with customers and suppliers and other mitigation efforts and potential further changes in global trade policies, including higher tariffs or trade restrictions in the U.S. or other countries.

[0001628280-25-040830:mdna:19]
For more information on risks associated with supply chain constraints and customer inventory, refer to Item 1A “Risk Factors” of this Annual Report.

[0001628280-25-040830:mdna:20]
Critical Accounting Policies and Estimates

[0001628280-25-040830:mdna:21]
Our consolidated financial statements are prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) as set forth in the Financial Accounting Standards Board’s Accounting Standards Codification (“ASC”). We also consider the various staff accounting bulletins and other applicable guidance issued by the United States Securities and Exchange Commission (“SEC”). GAAP, as set forth within the ASC, requires us to make certain estimates, judgments and assumptions. We believe that the estimates, judgments and assumptions on which we rely are reasonable based on information available to us at the time that we make these estimates, judgments and assumptions. These estimates, judgments and assumptions can affect the reported amounts of assets and liabilities as of the date of the financial statements as well as the reported amounts of revenues and expenses during the periods presented. To the extent there are differences between these estimates, judgments or assumptions and actual results, these difference will affect our financial statements. The accounting policies that reflect our more significant estimates, judgments and assumptions and which we believe are the most critical to aid in fully understanding and evaluating our reported financial results include the following:

[0001628280-25-040830:mdna:22]
•Inventory Valuation

[0001628280-25-040830:mdna:23]
•Revenue Recognition

[0001628280-25-040830:mdna:24]
•Income Taxes

[0001628280-25-040830:mdna:25]
•Business Combinations

[0001628280-25-040830:mdna:26]
•Goodwill and Intangible Assets - Impairment Assessment

[0001628280-25-040830:mdna:27]
Inventory Valuation

[0001628280-25-040830:mdna:28]
Our inventories are recorded at standard cost, which approximates actual cost computed on a first-in, first-out basis, not in excess of net realizable value. We assess the value of our inventories on a quarterly basis and write down those inventories which are obsolete or in excess of our forecasted demand to the lower of their cost or estimated net realizable value.

[0001628280-25-040830:mdna:29]
Our estimates of forecasted demand are based on our analysis and assumptions including, but not limited to, expected product lifecycles, product development plans and historical usage by product. Our product line management personnel play a key role in our excess review process by providing updated sales forecasts, managing product transitions and working with manufacturing to minimize excess inventory. If actual market conditions are less favorable than our forecasts, or actual demand from our customers is lower than our estimates, we may be required to record additional inventory write-downs. If actual market conditions are more favorable than anticipated, inventories previously written down may be sold, resulting in lower cost of sales and higher income from operations than expected in that period.

[0001628280-25-040830:mdna:30]
Our inventories are sensitive to technical obsolescence in the near term due to the use in industries characterized by the continuous introduction of new product lines, rapid technological advances, and product obsolescence. Based on certain assumptions and judgments made from the information available at that time, we determine the amount of allowance for potential inventory obsolescence. If these estimates and related assumptions or the market changes, we may be required to record additional reserves. Historically, actual results have not varied materially from our estimates.

[0001628280-25-040830:mdna:31]
Revenue Recognition

[0001628280-25-040830:mdna:32]
Pursuant to Topic 606, we recognize our revenues upon the application of the following steps:

[0001628280-25-040830:mdna:33]
•identification of the contract, or contracts, with a customer;

[0001628280-25-040830:mdna:34]
•identification of the performance obligations in the contract;

[0001628280-25-040830:mdna:35]
•determination of the transaction price;

[0001628280-25-040830:mdna:36]
•allocation of the transaction price to the performance obligations in the contract; and

[0001628280-25-040830:mdna:37]
•recognition of revenues when, or as, the contractual performance obligations are satisfied.

[0001628280-25-040830:mdna:38]
The majority of our revenue comes from product sales, consisting of sales of hardware products to our customers. Our revenue contracts generally include only one performance obligation. Revenues are recognized at a point in time when control of the promised goods or services are transferred to our customers upon shipment or delivery of goods or rendering of services, in an amount that reflects the consideration we expect to be entitled to in exchange for those goods or services. We have entered into vendor managed inventory (“VMI”) programs with our customers. Under these arrangements, we receive purchase orders from our customers, and the inventory is shipped to the VMI location upon receipt of the purchase order. The customer then pulls the inventory from the VMI hub based on its production needs. Revenue under VMI programs is recognized when control transfers to the customer, which is generally once the customer pulls the inventory from the hub.

[0001628280-25-040830:mdna:39]
Revenue from all sales types is recognized at the transaction price. The transaction price is determined based on the consideration to which we will be entitled in exchange for transferring goods or services to the customer adjusted for estimated variable consideration, if any. We typically estimate the impact on the transaction price for discounts offered to the customers for early payments on receivables or net of accruals for estimated sales returns. These estimates are based on historical returns, analysis of credit memo data and other known factors. Actual returns could differ from these estimates. We allocate the transaction price to each distinct product based on its relative standalone selling price. The product price as specified on the purchase order is considered the standalone selling price as it is an observable input that depicts the price as if sold to a similar customer in similar circumstances.

[0001628280-25-040830:mdna:40]
We exclude from revenue the taxes assessed by a governmental authority that are both imposed on and concurrent with a specific revenue-producing transaction, which are collected by us from a customer and deposited with the relevant government authority.

[0001628280-25-040830:mdna:41]
Our revenue arrangements do not contain significant financing components as our standard payment terms are less than one year.

[0001628280-25-040830:mdna:42]
If a customer pays consideration, or we have a right to an amount of consideration that is unconditional before we transfer a good or service to the customer, those amounts are classified as deferred revenue or deposits received from customers which are included in other current liabilities or other long-term liabilities when the payment is made or it is due, whichever is earlier.

[0001628280-25-040830:mdna:43]
Transaction Price Allocated to the Remaining Performance Obligations

[0001628280-25-040830:mdna:44]
Remaining performance obligations represent the transaction price allocated to performances obligations that are unsatisfied or partially unsatisfied as of the end of the reporting period. Unsatisfied and partially unsatisfied performance obligations consist of contract liabilities and non-cancellable backlog. Non-cancellable backlog includes goods and services for which customer purchase orders have been accepted that are scheduled or in the process of being scheduled for shipment. A portion of our revenue arises from vendor managed inventory arrangements where the timing and volume of customer utilization is difficult to predict.

[0001628280-25-040830:mdna:45]
Warranty

[0001628280-25-040830:mdna:46]
Hardware products regularly include warranties to the end customers such that the product continues to function according to published specifications. We typically offer a twelve-month warranty for most of our products. However, in some instances depending on the product, specific market, product line and geography in which we operate, and what is common in the industry, our warranties can vary and range from six months to five years. These standard warranties are assurance type warranties and do not offer any services in addition to the assurance that the product will continue working as specified. Therefore, warranties are not considered separate performance obligations in the arrangement.

[0001628280-25-040830:mdna:47]
We provide reserves for the estimated costs of product warranties that we record as cost of sales at the time revenue is recognized. We estimate the costs of our warranty obligations based on our historical experience of known product failure rates, use of materials to repair or replace defective products and service delivery costs incurred in correcting product failures. In addition, from time-to-time, specific warranty accruals may be made if discrete technical problems arise.

[0001628280-25-040830:mdna:48]
Shipping and Handling Costs and Tariffs

[0001628280-25-040830:mdna:49]
We record shipping and handling costs and tariffs related to revenue transactions within cost of sales as a period cost. Amounts billed to the customer for shipping and handling costs, including tariff charges, is recorded as revenue when the relevant product is recognized as revenue.

[0001628280-25-040830:mdna:50]
Contract Costs

[0001628280-25-040830:mdna:51]
We recognize the incremental direct costs of obtaining a contract, which consist of sales commissions, when control over the products they relate to transfers to the customer. Applying the practical expedient, we recognize commissions as expense when incurred, as the amortization period of the commission asset we would have otherwise recognized is less than one year.

[0001628280-25-040830:mdna:52]
Contract Balances

[0001628280-25-040830:mdna:53]
We record accounts receivable when we have an unconditional right to consideration. Contract liabilities are recorded when cash payments are received or due in advance of performance. Contract liabilities consist of advance payments and deferred revenue, where we have unsatisfied performance obligations. Contract liabilities are classified as deferred revenue and customer deposits and are included in other current liabilities within our consolidated balance sheet. Payment terms vary by customer. The time between invoicing and when payment is due is not significant.

[0001628280-25-040830:mdna:54]
The following table reflects the changes in contract balances as of June 28, 2025 (in millions, except percentages):

[0001628280-25-040830:mdna:55]
| Contract balances | Balance sheet location | June 28, 2025 |  | June 29, 2024 |  | Change |  | Percentage Change |
| Accounts receivable, net | Accounts receivable, net | $ | 250.0 |  |  | $ | 194.7 |  |  | $ | 55.3 |  |  | 28.4 | % |
| Deferred revenue and customer deposits | Other current liabilities | $ | 0.7 |  |  | $ | 0.6 |  |  | $ | 0.1 |  |  | 16.7 | % |

[0001628280-25-040830:mdna:56]
Disaggregation of Revenue

[0001628280-25-040830:mdna:57]
We disaggregate revenue by geography and by product.  Refer to “Note 18. Revenue Recognition” to the consolidated financial statements for a presentation of disaggregated revenue. We do not present other levels of disaggregation, such as by type of products, customer, markets, contracts, duration of contracts, timing of transfer of control and sales channels, as this information is not used by our Chief Operating Decision Maker (“CODM”) to manage the business.

[0001628280-25-040830:mdna:58]
Income Taxes

[0001628280-25-040830:mdna:59]
In accordance with the authoritative guidance on accounting for income taxes, we recognize income taxes using an asset and liability approach. This approach requires the recognition of taxes payable or refundable for the current year and deferred tax liabilities and assets for the future tax consequences of events that have been recognized in our consolidated financial statements or tax returns. The measurement of current and deferred taxes is based on provisions of the enacted tax law, and the effects of future changes in tax laws or rates are not anticipated.

[0001628280-25-040830:mdna:60]
The authoritative guidance provides for recognition of deferred tax assets if the realization of such deferred tax assets is more likely than not to occur based on an evaluation of both positive and negative evidence and the relative weight of the evidence. We consider future growth, forecasted earnings, future taxable income, the mix of earnings in the jurisdictions in which we operate, historical earnings, taxable income in prior years, if carry-back is permitted under the law, and prudent and feasible tax planning strategies in determining the need for a valuation allowance. In the event we were to determine that we would not be able to realize all or part of our net deferred tax assets in the future, an adjustment to the deferred tax assets valuation allowance would be charged to earnings in the period in which we make such a determination, or goodwill would be adjusted at our final determination of the valuation allowance related to an acquisition within the measurement period. If we later determine that it is more likely than not that the net deferred tax assets would be realized, we would reverse the applicable portion of the previously provided valuation allowance as an adjustment to earnings at such time.

[0001628280-25-040830:mdna:61]
We are subject to income tax audits by the respective tax authorities of the jurisdictions in which we operate. The determination of our income tax liabilities in each of these jurisdictions requires the interpretation and application of complex, and sometimes uncertain, tax laws and regulations. The authoritative guidance on accounting for income taxes prescribes both recognition and measurement criteria that must be met for the benefit of a tax position to be recognized in the financial statements. If a tax position taken, or expected to be taken, in a tax return does not meet such recognition or measurement criteria, an unrecognized tax benefit liability is recorded.  If we ultimately determine that an unrecognized tax benefit liability is no longer necessary, we reverse the liability and recognize a tax benefit in the period in which it is determined that the unrecognized tax benefit liability is no longer necessary.

[0001628280-25-040830:mdna:62]
Our income tax provision is highly dependent on the geographic distribution of our worldwide earnings or losses, tax laws and regulations in various jurisdictions, tax incentives, the availability of tax credits and loss carryforwards, and the effectiveness of our tax planning strategies. The application of tax laws and regulations is subject to legal and factual interpretation, judgment and uncertainty. Tax laws themselves are subject to change as a result of changes in fiscal policy, changes in legislation, and the evolution of regulations and court rulings and tax audits.

[0001628280-25-040830:mdna:63]
The recognition and measurement of current taxes payable or refundable and deferred tax assets and liabilities requires that we make certain estimates and judgments. Changes to these estimates or a change in judgment may have a material impact on our tax provision in a future period.

[0001628280-25-040830:mdna:64]
Business Combinations

[0001628280-25-040830:mdna:65]
In accordance with the guidance for business combinations, we determine whether a transaction or event is a business combination, which requires that the assets acquired and liabilities assumed constitute a business. Each business combination is then accounted for by applying the acquisition method. If the assets acquired are not a business, we account for the transaction or event as an asset acquisition. Under both methods, we recognize the identifiable assets acquired, the liabilities assumed, and noncontrolling interest, if any, in the acquired entity. We capitalize acquisition-related costs and fees associated with asset acquisitions and immediately expense acquisition-related costs and fees associated with business combinations.

[0001628280-25-040830:mdna:66]
We allocate the fair value of purchase consideration to assets acquired and liabilities assumed based on their estimated fair values at the acquisition date. The excess of the fair value of purchase consideration over the fair values of these identifiable assets and liabilities is recorded as goodwill. We make significant estimates and assumptions to determine assets acquired and liabilities assumed, in particular intangible assets and pre-acquisition contingencies, as applicable.

[0001628280-25-040830:mdna:67]
Critical estimates in valuing intangible assets include, but are not limited to, discount rates, the period required for customer revenues to mature, and future expected cash flows from customer relationships, acquired developed technology and acquired in-process research and development assets. Our estimates of fair value are based on assumptions using the best information available. These assumptions are inherently uncertain and unpredictable and, as a result, actual results may differ materially from these estimates.

[0001628280-25-040830:mdna:68]
We may identify certain pre-acquisition contingencies as of the acquisition date and may extend our review and evaluation of these pre-acquisition contingencies throughout the measurement period in order to obtain sufficient information to assess whether these contingencies should be included as a part of the fair value of assets acquired and liabilities assumed and, if so, the amounts to be included.

[0001628280-25-040830:mdna:69]
Certain estimates associated with the accounting for acquisitions may change as additional information becomes available regarding the assets acquired and liabilities assumed. Any change in facts and circumstances that existed as of the acquisition date and impacts to our preliminary estimates are recorded to goodwill if identified within the measurement period. Subsequent to the measurement period or our final determination of fair value of assets and liabilities, whichever is earlier, the adjustments will affect our earnings. Although we believe that the assumptions and estimates we have made in the past have been reasonable and appropriate, they are based in part on historical experience and information obtained from the management of the acquired companies and are inherently uncertain. Unanticipated events and circumstances may occur that may affect the accuracy or validity of such assumptions, estimates or actual results.

[0001628280-25-040830:mdna:70]
Goodwill and Intangible Assets - Impairment Assessment

[0001628280-25-040830:mdna:71]
Goodwill represents the excess of the purchase price of an acquired business over the fair value of the identifiable assets acquired and liabilities assumed. We test goodwill impairment on an annual basis in the fiscal fourth quarter and at any other time when events occur or circumstances indicate that the carrying amount of goodwill may not be recoverable.

[0001628280-25-040830:mdna:72]
We have the option to first assess qualitative factors to determine whether it is necessary to perform the quantitative goodwill impairment test. The qualitative factors we assess include long-term prospects of our performance, share price trends and market capitalization, and Company specific events. Unanticipated events and circumstances may occur that affect the accuracy of our assumptions, estimates and judgments. For example, if the price of our common stock were to significantly decrease combined with other adverse changes in market conditions, thus indicating that the underlying fair value of our reporting units may have decreased, we may reassess the value of our goodwill in the period such circumstances were identified.

[0001628280-25-040830:mdna:73]
If we determine that, as a result of the qualitative assessment, it is more likely than not (i.e., greater than 50% likelihood) that the fair value of a reporting unit is less than its carrying amount, we perform the quantitative test by estimating the fair value of our reporting units. If the carrying value of a reporting unit exceeds its fair value, we record goodwill impairment loss equal to the excess of the carrying value of the reporting unit’s goodwill over its fair value, not to exceed the carrying amount of goodwill. Performing a quantitative goodwill impairment test includes the determination of the fair value of a reporting unit and involves significant estimates and assumptions. These estimates and assumptions include, among others, revenue growth rates and operating margins used to calculate projected future cash flows, risk-adjusted discount rates, future economic and market conditions, and the determination of appropriate market comparables.

[0001628280-25-040830:mdna:74]
We make judgments about the recoverability of purchased finite-lived intangible assets whenever events or changes in circumstances indicate that impairment may exist. In such situations, we are required to evaluate whether the net book values of our finite-lived intangible assets are recoverable. We determine whether finite-lived intangible assets are recoverable based on the forecasted future cash flows that are expected to be generated by the lowest level associated asset grouping. Assumptions and estimates about future values and remaining useful lives of our intangible assets are complex and subjective and include, among others, forecasted undiscounted cash flows to be generated by certain asset groupings. These assumptions and estimates can be affected by a variety of factors, including external factors such as industry and economic trends and internal factors such as changes in our business strategy and our internal forecasts.

[0001628280-25-040830:mdna:75]
Recently Issued Accounting Pronouncements

[0001628280-25-040830:mdna:76]
Refer to “Note 2. Recently Issued Accounting Pronouncements” to the consolidated financial statements.

[0001628280-25-040830:mdna:77]
49

[0001628280-25-040830:mdna:78]
Results of Operations

[0001628280-25-040830:mdna:79]
This section of this Form 10-K generally discusses fiscal year 2025 compared to fiscal year 2024. The comparison of the fiscal year 2024 results with the fiscal year 2023 results that are not included in this Form 10-K can be found in the “Management’s Discussion and Analysis Results of Operations” section in the Company’s  fiscal year 2024 Annual Report within Part II, Item 7 of Form 10-K, filed on August 21, 2024.

[0001628280-25-040830:mdna:80]
The following table summarizes selected consolidated statements of operations items as a percentage of net revenue:

[0001628280-25-040830:mdna:81]
|  | Years Ended |
|  | June 28, 2025 |  | June 29, 2024 |  | July 1, 2023 |
| Segment net revenue: |  |  |  |  |  |
| Cloud & Networking | 85.8 | % |  | 79.8 | % |  | 74.8 | % |
| Industrial Tech | 14.2 |  |  | 20.2 |  |  | 25.2 |  |
| Net revenue | 100.0 |  |  | 100.0 |  |  | 100.0 |  |
| Cost of sales | 67.0 |  |  | 75.3 |  |  | 63.0 |  |
| Amortization of acquired developed intangibles | 5.0 |  |  | 6.2 |  |  | 4.8 |  |
| Gross profit | 28.0 |  |  | 18.5 |  |  | 32.2 |  |
| Operating expenses: |  |  |  |  |  |
| Research and development | 18.5 |  |  | 22.2 |  |  | 17.4 |  |
| Selling, general and administrative | 21.2 |  |  | 22.9 |  |  | 19.7 |  |
| Restructuring and related charges | 1.4 |  |  | 5.3 |  |  | 1.6 |  |
| Gain on sale of facility | (2.1) |  |  | — |  |  | — |  |
| Total operating expenses | 38.9 |  |  | 50.4 |  |  | 38.7 |  |
| Loss from operations | (10.9) |  |  | (31.9) |  |  | (6.5) |  |
| Interest expense | (1.3) |  |  | (2.5) |  |  | (2.0) |  |
| Other income, net | 1.8 |  |  | 4.6 |  |  | 2.8 |  |
| Loss before income taxes | (10.5) |  |  | (29.8) |  |  | (5.7) |  |
| Income tax (benefit) provision | (12.0) |  |  | 10.4 |  |  | 1.7 |  |
| Net income (loss) | 1.6 | % |  | (40.2) | % |  | (7.4) | % |

[0001628280-25-040830:mdna:82]
Financial Data for Fiscal Years 2025, 2024, and 2023

[0001628280-25-040830:mdna:83]
The following table summarizes selected consolidated statements of operations items (in millions, except for percentages):

[0001628280-25-040830:mdna:84]
|  | 2025 |  | 2024 |  | Change |  | Percentage Change |  | 2024 |  | 2023 |  | Change |  | Percentage Change |
| Segment net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cloud & Networking | $ | 1,410.8 |  | $ | 1,084.9 |  | $ | 325.9 |  |  | 30.0 | % |  | $ | 1,084.9 |  | $ | 1,322.5 |  | $ | (237.6) |  |  | (18.0) | % |
| Industrial Tech | 234.2 |  | 274.3 |  | (40.1) |  |  | (14.6) |  |  | 274.3 |  | 444.5 |  | (170.2) |  |  | (38.3) |  |
| Net revenue | $ | 1,645.0 |  | $ | 1,359.2 |  | $ | 285.8 |  |  | 21.0 | % |  | $ | 1,359.2 |  | $ | 1,767.0 |  | $ | (407.8) |  |  | (23.1) | % |
| Gross profit | $ | 459.9 |  | $ | 251.5 |  | $ | 208.4 |  |  | 82.9 | % |  | $ | 251.5 |  | $ | 569.0 |  | $ | (317.5) |  |  | (55.8) | % |
| Gross margin | 28.0 | % |  | 18.5 | % |  |  |  |  |  | 18.5 | % |  | 32.2 | % |  |  |  |  |
| Research and development | $ | 303.9 |  | $ | 302.2 |  | $ | 1.7 |  | 0.6 | % |  | $ | 302.2 |  | $ | 307.8 |  | $ | (5.6) |  |  | (1.8) | % |
| Percentage of net revenue | 18.5 | % |  | 22.2 | % |  |  |  |  |  | 22.2 | % |  | 17.4 | % |  |  |  |  |
| Selling, general and administrative | $ | 348.2 |  | $ | 310.7 |  | $ | 37.5 |  |  | 12.1 | % |  | $ | 310.7 |  | $ | 348.8 |  | $ | (38.1) |  |  | (10.9) | % |
| Percentage of net revenue | 21.2 | % |  | 22.9 | % |  |  |  |  |  | 22.9 | % |  | 19.7 | % |  |  |  |  |
| Restructuring and related charges | $ | 22.8 |  | $ | 72.6 |  | $ | (49.8) |  |  | (68.6) | % |  | $ | 72.6 |  | $ | 28.1 |  | $ | 44.5 |  |  | 158.4 | % |
| Percentage of net revenue | 1.4 | % |  | 5.3 | % |  |  |  |  |  | 5.3 | % |  | 1.6 | % |  |  |  |  |
| Gain on sale of facility | $ | (34.9) |  |  | $ | — |  |  | $ | (34.9) |  | — | % |  | $ | — |  |  | $ | — |  | $ | — |  |  | n/a |
| Percentage of net revenue | (2.1) | % |  | — | % |  |  |  |  |  | — | % |  | — | % |  |  |  |  |

[0001628280-25-040830:mdna:85]
Net Revenue

[0001628280-25-040830:mdna:86]
Net revenue increased by $285.8 million, or 21.0%, during fiscal year 2025 as compared to fiscal year 2024, due to a $325.9 million increase in Cloud & Networking net revenue offset by a $40.1 million decrease in Industrial Tech net revenue.

[0001628280-25-040830:mdna:87]
The increase in Cloud & Networking net revenue is primarily due to higher unit sales from cloud and AI/ML customers, which increased by $193.2 million, in part due to a full year of revenue from Cloud Light, which we acquired in the second quarter of fiscal year 2024. In addition, revenue from network equipment manufacturers increased by $132.7 million  as a result of higher unit sales from the market recovery and the related inventory normalization. The decrease in Industrial Tech net revenue is primarily due to a decline in unit sales of our imaging and sensing products due to higher market competition in the consumer end-market for these products, which was partially offset by a $17.5 million increase in our laser products due to higher market demand.

[0001628280-25-040830:mdna:88]
During our fiscal years 2025, 2024 and 2023, net revenue generated from a single customer which represented 10% or greater of total net revenue is summarized as follows:

[0001628280-25-040830:mdna:89]
|  | Years Ended |
|  | June 28, 2025 |  | June 29, 2024 |  | July 1, 2023 |
| Customer A | 16.0 | % |  | 11.4 | % |  | 15.3 | % |
| Customer B | 15.4 | % |  | 18.9 | % |  | * |
| Customer C | * |  | * |  | 12.1 | % |
| Customer D | * |  | * |  | 10.5 | % |
| *Represents less than 10% of total net revenue |  |  |  |  |  |

[0001628280-25-040830:mdna:90]
51

[0001628280-25-040830:mdna:91]
Revenue by Region

[0001628280-25-040830:mdna:92]
We operate in three geographic regions: Americas, Asia-Pacific, and EMEA (Europe, Middle East, and Africa). Net revenue is assigned to the geographic region and country where our product is initially shipped to. For example, certain customers may request shipment of our product to a contract manufacturer in one country, which may differ from the location of their end customers. The following table presents net revenue by the three geographic regions we operate in and net revenue from countries that represented 10% or more of our total net revenue (in millions, except percentage data):

[0001628280-25-040830:mdna:93]
|  |  |  | Years Ended |
|  |  |  |  |  | June 28, 2025 |  | June 29, 2024 |  | July 1, 2023 |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  |  |  |  |  |  |  |  | $ | 312.3 |  |  | 19.0 | % |  | $ | 356.1 |  |  | 26.2 | % |  | $ | 241.3 |  |  | 13.7 | % |
| Mexico |  |  |  |  |  |  |  |  | 148.5 |  |  | 9.0 |  |  | 91.7 |  |  | 6.7 |  |  | 180.0 |  |  | 10.2 |  |
| Other Americas |  |  |  |  |  |  |  |  | 20.1 |  |  | 1.2 |  |  | 3.4 |  |  | 0.3 |  |  | 9.3 |  |  | 0.5 |  |
| Total Americas |  |  |  |  |  |  |  |  | $ | 480.9 |  |  | 29.2 | % |  | $ | 451.2 |  |  | 33.2 | % |  | $ | 430.6 |  |  | 24.4 | % |
| Asia-Pacific: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Thailand |  |  |  |  |  |  |  |  | $ | 291.8 |  |  | 17.7 | % |  | $ | 183.8 |  |  | 13.5 | % |  | $ | 269.0 |  |  | 15.2 | % |
| Hong Kong |  |  |  |  |  |  |  |  | 398.6 |  |  | 24.2 |  |  | 261.9 |  |  | 19.3 |  |  | 246.7 |  |  | 14.0 |  |
| South Korea |  |  |  |  |  |  |  |  | 32.4 |  |  | 2.0 |  |  | 75.2 |  |  | 5.5 |  |  | 170.2 |  |  | 9.6 |  |
| Japan |  |  |  |  |  |  |  |  | 78.3 |  |  | 4.8 |  |  | 84.6 |  |  | 6.2 |  |  | 179.5 |  |  | 10.2 |  |
| Other Asia-Pacific |  |  |  |  |  |  |  |  | 199.5 |  |  | 12.2 |  |  | 174.3 |  |  | 12.9 |  |  | 276.3 |  |  | 15.6 |  |
| Total Asia-Pacific |  |  |  |  |  |  |  |  | $ | 1,000.6 |  |  | 60.9 | % |  | $ | 779.8 |  |  | 57.4 | % |  | $ | 1,141.7 |  |  | 64.6 | % |
| EMEA |  |  |  |  |  |  |  |  | $ | 163.5 |  |  | 9.9 | % |  | $ | 128.2 |  |  | 9.4 | % |  | $ | 194.7 |  |  | 11.0 | % |
| Total net revenue |  |  |  |  |  |  |  |  | $ | 1,645.0 |  |  | 100.0% |  | $ | 1,359.2 |  |  | 100.0% |  | $ | 1,767.0 |  |  | 100.0% |

[0001628280-25-040830:mdna:94]
During fiscal years 2025, 2024 and 2023, net revenue from customers outside the United States, based on customer shipping location, represented 81.0%, 73.8% and 86.3% of net revenue, respectively.

[0001628280-25-040830:mdna:95]
Our net revenue is primarily denominated in U.S. dollars, including our net revenue from customers outside the United States as presented above. We expect revenue from customers outside of the United States to continue to be an important part of our overall net revenue and a focus for net revenue growth opportunities. However, regulatory and enforcement actions by the United States and other governmental agencies, as well as changes in tax and trade policies and tariffs, have impacted and may continue to adversely impact net revenue from customers outside the United States.

[0001628280-25-040830:mdna:96]
Gross Margin

[0001628280-25-040830:mdna:97]
Gross margin in fiscal year 2025 increased to 28.0% from 18.5% in fiscal year 2024. The increase was driven by a $20.8 million reduction in excess and obsolete inventory charges during fiscal year 2025, primarily as a result of the U.S. trade restrictions imposed during fiscal year 2024 whereby we were no longer able to sell certain products to one of our customers. In addition, costs incurred related to the acquisition of Cloud Light, including integration costs and amortization of inventory fair value adjustments were $23.5 million lower compared to the prior year. In fiscal year 2024, we also incurred $20.7 million of higher excess capacity charges as a result of our manufacturing synergy plans in connection with the NeoPhotonics integration, transferring product lines out of China due to U.S. export restrictions, and a drop in demand due to customers actively working to reduce their elevated inventory levels. Our Cloud & Networking gross profit increased year over year primarily due to higher unit sales of our products for both cloud and AI/ML applications. Our Industrial Tech segment gross margin decreased year over year primarily due to lower revenue, mainly from sales of imaging and sensing products.

[0001628280-25-040830:mdna:98]
The markets in which we sell products are undergoing product, architectural and business model transitions, have high customer concentrations, are highly competitive, are price sensitive and/or are affected by customer seasonality and have variant buying patterns. We expect these factors to result in variability of our gross margin, and our gross margin may be subject to increasing downward pressure due to these factors.

[0001628280-25-040830:mdna:99]
Segment Profit

[0001628280-25-040830:mdna:100]
|  | Years Ended |
|  | June 28, 2025 |  | June 29, 2024 |  | July 1, 2023 |
| Cloud & Networking | $ | 264.5 |  |  | $ | 124.5 |  |  | $ | 313.2 |  |
| Industrial Tech | 12.1 |  |  | 25.1 |  |  | 152.7 |  |

[0001628280-25-040830:mdna:101]
Cloud & Networking segment profit increased by $140.0 million, or 112.4%, during fiscal year 2025 as compared to fiscal year 2024 primarily due to higher sales of our products for both cloud and AI/ML applications. Industrial Tech segment profit decreased by $13.0 million, or 51.8%, during fiscal year 2025 as compared to fiscal year 2024 primarily due to lower revenue, mainly from lower sales of imaging and sensing products due to increasing competition and share normalization.

[0001628280-25-040830:mdna:102]
Research and Development (“R&D”)

[0001628280-25-040830:mdna:103]
R&D expense was approximately flat in fiscal year 2025 as compared to fiscal year 2024. Salary expenses were lower by $10.0 million as a result of lower headcount and restructuring actions taken in the past, primarily due to the discontinuation of our in-house development of coherent DSPs and Radio Frequency Integrated Circuits (“RFICs”). The decrease was offset by higher variable compensation due to higher profit levels, which increased our cash incentive compensation by $5.3 million, and increased our stock-based incentive compensation by $5.0 million.

[0001628280-25-040830:mdna:104]
We believe that continuing our investments in R&D is critical to attaining our strategic objectives. We plan to continue to invest in R&D and new products that we believe will further differentiate us in the marketplace.

[0001628280-25-040830:mdna:105]
Selling, General and Administrative (“SG&A”)

[0001628280-25-040830:mdna:106]
SG&A expense increased by $37.5 million, or 12.1%, during fiscal year 2025 as compared to fiscal year 2024, primarily driven by an increase of $38.0 million in stock-based compensation driven by equity award modifications and $5.2 million of severance payments, both primarily due to the resignation of our former Chief Executive Officer, as well as an increase of $8.1 million related to cash incentive compensation due to the higher levels of revenue and profit. This was partially offset by a $13.0 million decrease in salary expenses as a result of recent restructuring actions and a $2.8 million of reduction in integration related costs.

[0001628280-25-040830:mdna:107]
From time-to-time, we incur expenses that are not part of our ordinary operations, such as mergers and acquisition-related and litigation expenses, which generally increase our SG&A expenses and potentially impact our profitability expectations in any particular period.

[0001628280-25-040830:mdna:108]
Restructuring and Related Charges

[0001628280-25-040830:mdna:109]
We have initiated various strategic restructuring events primarily intended to reduce costs, consolidate our operations, rationalize the manufacturing of our products and align our business in response to market conditions and as a result of recent acquisitions.

[0001628280-25-040830:mdna:110]
During fiscal year 2025, we recorded restructuring and related charges of $22.8 million, This included $14.6 million of assets written off, including property, plant and equipment, right-of-use assets, prepayments and other current assets as well as charges for other contractual commitments associated with site closures, and $4.3 million of employee severance primarily due to efforts to consolidate our sites and focus on other market opportunities, including cloud and AI markets. In addition, we also recorded $3.0 million of charges related to the discontinuation of our in-house development of coherent Digital Signal Processors (“DSPs”) and Radio Frequency Integrated Circuits (“RFICs”).

[0001628280-25-040830:mdna:111]
Refer to “Note 12. Restructuring and Related Charges” to the consolidated financial statements.

[0001628280-25-040830:mdna:112]
Gain on Sale of Facility

[0001628280-25-040830:mdna:113]
On December 17, 2024, we entered into an agreement to sell our assets in an entity in Shenzhen, China. On March 5, 2025, we completed the sale and received net proceeds of $47.8 million, which was net of cash of $17.6 million and direct selling costs of $1.1 million. The net assets sold consisted primarily of building, building improvements and land rights as of December 17, 2024 with a net carrying value of $12.9 million, and were used by the Cloud and Networking segment for manufacturing and research and development activities. As a result, we recognized a gain on sale of facility of $34.9 million, which was recorded in our consolidated statements of operations for the year ended June 28, 2025. We paid $4.4 million of withholding taxes on this sale transaction, which is recorded as part of the income tax provision for the year ended June 28, 2025. We also incurred $0.7 million of indirect selling expenses related to this transaction, which was recorded as part of selling, general and administrative expenses in our consolidated statements of operations for the year ended June 28, 2025.

[0001628280-25-040830:mdna:114]
Refer to “Note 7. Balance Sheet Details” to the consolidated financial statements.

[0001628280-25-040830:mdna:115]
Interest Expense

[0001628280-25-040830:mdna:116]
Our interest expense is as follows for the years presented (in millions):

[0001628280-25-040830:mdna:117]
|  |  |  | Years Ended |
|  |  |  | June 28, 2025 |  | June 29, 2024 |  | July 1, 2023 |
| Interest expense |  |  | $ | 22.2 |  |  | $ | 33.8 |  |  | $ | 35.5 |  |

[0001628280-25-040830:mdna:118]
Interest expense is primarily driven by interest on our convertible notes and term loans.

[0001628280-25-040830:mdna:119]
Interest expense in fiscal year 2025 decreased by $11.6 million, or 34.3%, as compared to fiscal year 2024, primarily due to the repayment in full of our 0.25% convertible senior notes due in 2024 (the “2024 Notes”) upon maturity in March 2024.

[0001628280-25-040830:mdna:120]
Other Income, Net

[0001628280-25-040830:mdna:121]
The components of other income, net are as follows for the years presented (in millions):

[0001628280-25-040830:mdna:122]
|  |  |  | Years Ended |  |
|  |  |  | June 28, 2025 |  | June 29, 2024 |  | July 1, 2023 |  |
| Foreign exchange gains (losses), net |  |  | $ | (4.2) |  |  | $ | 0.8 |  |  | $ | 7.0 |  |  |
| Interest and investment income |  |  | 34.4 |  |  | 61.3 |  |  | 40.8 |  |  |
| Other income (expense), net |  |  | — |  |  | — |  |  | 1.0 |  |  |
| Other income, net |  |  | $ | 30.2 |  |  | $ | 62.1 |  |  | $ | 48.8 |  |  |

[0001628280-25-040830:mdna:123]
Other income, net in fiscal year 2025 decreased by $31.9 million as compared to fiscal year 2024 primarily due to $26.9 million of decrease in interest and investment income driven by lower short term investment balances, as we used cash for the Cloud Light acquisition as well as the repayment of the 2024 Notes in March 2024. This was offset by an increase in net foreign exchange loss of $5.0 million as the U.S. dollars weakened against across all major currencies, including the Japanese Yen, which is the underlying currency for our term loans.

[0001628280-25-040830:mdna:124]
Provision for Income Taxes

[0001628280-25-040830:mdna:125]
|  |  | Years Ended |
| (in millions) |  | June 28, 2025 |  | June 29, 2024 |  | July 1, 2023 |
| Income tax (benefit) provision |  | $ | (198.0) |  |  | $ | 140.8 |  |  | $ | 29.2 |  |

[0001628280-25-040830:mdna:126]
Our provision for income taxes for fiscal year 2025 differs from the 21% U.S. statutory rate primarily due to the income tax benefit associated with the release of a valuation allowance on our UK deferred tax assets, earnings of our foreign subsidiaries being taxed at rates that differ from the U.S. statutory rate, partially offset by the income tax expense from U.S. income inclusions from Subpart F and GILTI, non-deductible stock-based compensation and changes in unrecognized tax benefits.

[0001628280-25-040830:mdna:127]
Our provision for incomes taxes may be impacted by changes in the geographic mix of earnings, acquisitions, changes in the realizability of deferred tax assets, changes in our uncertain tax positions, the results of income tax audits, settlements with tax authorities, the expiration of statutes of limitations, the implementation of tax planning strategies, tax rulings, court decisions, and changes in tax laws and regulations.  It is also possible that significant negative or positive evidence may become available that causes us to change our conclusion regarding whether a valuation allowance is needed on certain of our deferred tax assets, which would affect our income tax provision in the period of such change.

[0001628280-25-040830:mdna:128]
We also evaluate changes to regulations and requirements in the international jurisdictions where we conduct our business. For additional information, refer to Part II Item 1A “Risk Factors”.

[0001628280-25-040830:mdna:129]
Defined Benefit Plans

[0001628280-25-040830:mdna:130]
The Company sponsors defined benefit pension plans covering employees in Japan, Switzerland, and Thailand. Pension plan benefits are based primarily on participants’ compensation and years of service credited as specified under the terms of each country’s plan. Employees are entitled to a lump sum benefit upon retirement or upon certain instances of termination.  The funding policy is consistent with the local requirements of each country. As of June 28, 2025, the defined benefit plans in Switzerland were partially funded, while defined benefit plans in Japan and Thailand were unfunded. As of June 28, 2025, our projected benefit obligations, net, in Japan, Switzerland, and Thailand were $2.3 million, $2.6 million and $5.7 million, respectively. They were recorded in our consolidated balance sheets as accrued payroll and related expenses for the current portion while other non-current liabilities for the non-current portion, and represent the total projected benefit obligation (“PBO”) less the fair value of plan assets.

[0001628280-25-040830:mdna:131]
A key actuarial assumption in calculating the net periodic cost and the PBO is the discount rate. Changes in the discount rate impact the interest cost component of the net periodic benefit cost calculation and PBO due to the fact that the PBO is calculated on a net present value basis. Decreases in the discount rate will generally increase pre-tax cost, recognized expense and the PBO. Increases in the discount rate tend to have the opposite effect. We estimate a 100 basis point decrease or increase in the discount rate would cause a corresponding increase or decrease of $5.1 million or $4.0 million, respectively, in the PBO based on data as of June 28, 2025.

[0001628280-25-040830:mdna:132]
We expect to contribute $2.0 million to our defined benefit pension plans in fiscal year 2026.

[0001628280-25-040830:mdna:133]
Financial Condition

[0001628280-25-040830:mdna:134]
Liquidity and Capital Resources

[0001628280-25-040830:mdna:135]
As of June 28, 2025 and June 29, 2024, our cash and cash equivalents were $520.7 million and $436.7 million, respectively. As of June 28, 2025 and June 29, 2024, our short-term investments of $356.4 million and $450.3 million, respectively, were all held in the United States. Cash equivalents and short-term investments are primarily comprised of money market funds, treasuries, agencies, high quality investment grade fixed income securities, certificates of deposit, and commercial paper. Our investment policy and strategy is focused on the preservation of capital and supporting our liquidity requirements.

[0001628280-25-040830:mdna:136]
The total amount of cash outside the United States held by the non-U.S. entities as of June 28, 2025 and June 29, 2024 was $398.3 million and $306.9 million, respectively, which was primarily held by entities incorporated in the United Kingdom, Japan, Hong Kong, China, Switzerland, and Thailand. Although cash currently held in the United States, as well as cash generated in the United States from future operations, is expected to cover our normal operating requirements, a substantial amount of additional cash could be required for other purposes, such as capital expenditures to support our business and growth, including costs associated with increasing internal manufacturing capabilities, strategic transactions and partnerships, and future acquisitions.

[0001628280-25-040830:mdna:137]
Our intent is to indefinitely reinvest funds held outside the United States and, except for the funds held in the Cayman Islands, the British Virgin Islands, and Hong Kong, as well as certain subsidiaries in China and Japan, our current plans do not demonstrate a need to repatriate them to fund our domestic operations. However, if in the future, we encounter a significant need for liquidity domestically or at a particular location that we cannot fulfill through borrowings, equity offerings, or other internal or external sources, or the cost to bring back the money is not significant from a tax perspective, we may determine that cash repatriations are necessary or desirable. Repatriation could result in additional material taxes. These factors may cause us to have an overall tax rate higher than other companies or higher than our tax rates in the past. Additionally, if conditions warrant, we may seek to obtain additional financing through debt or equity sources. To the extent we issue additional shares, it may create dilution to our existing stockholders. However, any such financing may not be available on terms favorable to us or may not be available at all.

[0001628280-25-040830:mdna:138]
Beginning in fiscal year 2023, the Tax Cuts and Jobs Act of 2017 requires taxpayers to capitalize research and development expenditures and amortize domestic expenditures over five years and foreign expenditures over fifteen years. The OBBBA enacted in July 2025 eliminates capitalization of domestic research and development expenditures for taxable years beginning on or after January 1, 2025, but retains the requirement to amortize foreign research and development expenditures over 15 years. In addition, the OBBBA permits all taxpayers who paid or incurred domestic research and development expenses in tax years beginning on or after January 1, 2022 and before January 1, 2025 to elect to deduct any remaining unamortized amount over a one-year period or ratably over a two-year period (at the taxpayer’s election), accelerating the benefit of such expenses. We are evaluating the impact of these changes to our financial conditions and will adjust our tax and accounting policies accordingly.

[0001628280-25-040830:mdna:139]
Indebtedness

[0001628280-25-040830:mdna:140]
As of June 28, 2025, the net carrying amount of our 2029 Notes of $600.2 million, which have an aggregate principal balance of $603.7 million maturing in 2029, is presented in non-current liabilities in our condensed consolidated balance sheets. If the closing price of our stock exceeds $90.40 (130% of the conversion price of $69.54) for 20 of the last 30 trading days of any future quarter, the 2029 Notes would become convertible at the option of the holders during the subsequent fiscal quarter and the debt component would be reclassified to current liabilities.

[0001628280-25-040830:mdna:141]
As of June 28, 2025, the net carrying amount of our 2028 Notes of $857.7 million, which have an aggregate principal balance of $861.0 million maturing in 2028, is presented in non-current liabilities in our condensed consolidated balance sheets. If the closing price of our stock exceeds $170.34 (130% of the conversion price of $131.03) for 20 of the last 30 trading days of any future fiscal quarter, our 2028 Notes would become convertible at the option of the holders during the subsequent fiscal quarter and the debt component would be reclassified to current liabilities.

[0001628280-25-040830:mdna:142]
As of June 28, 2025, the net carrying amount of our 2026 Notes of $1,048.3 million, which have an aggregate principal balance of $1,050.0 million maturing in 2026, is presented in non-current liabilities in our condensed consolidated balance sheets. If the closing price of our stock exceeds $129.08 (130% of the conversion price of $99.29) for 20 of the last 30 trading days of any future fiscal quarter, our 2026 Notes would become convertible at the option of the holders during the subsequent fiscal quarter and the debt component would be reclassified to current liabilities.

[0001628280-25-040830:mdna:143]
As of June 28, 2025, the Company had $40.6 million in principal amount outstanding on our SMBC Term Loan, of which the short-term portion of $4.4 million is recorded as current liabilities while the long-term portion of $36.2 million is recorded as long-term debt in the Company’s consolidated balance sheets.

[0001628280-25-040830:mdna:144]
As of June 28, 2025, the Company had $26.4 million in principal amount outstanding on our Mizuho Term Loan, of which the short-term portion of $6.2 million is recorded as current liabilities while the long-term portion of $20.2 million is recorded as long-term debt in the Company’s consolidated balance sheets.

[0001628280-25-040830:mdna:145]
Refer to “Note 10. Debt” to the consolidated financial statements for more information.

[0001628280-25-040830:mdna:146]
Contractual Obligations

[0001628280-25-040830:mdna:147]
The following table summarizes our contractual obligations as of June 28, 2025, and the effect such obligations are expected to have on our liquidity and cash flow (in millions):

[0001628280-25-040830:mdna:148]
|  | Payments due |
|  | Total |  | Less than 1 year |  | More than 1 year |
| Contractual Obligations |  |  |  |  |  |
| Asset retirement obligations | $ | 7.1 |  |  | $ | — |  |  | $ | 7.1 |  |
| Operating lease liabilities, including imputed interest (1) | 37.6 |  |  | 12.7 |  |  | 24.9 |  |
| Pension plan contributions (2) | 2.0 |  |  | $ | 2.0 |  |  | — |  |
| Purchase obligations (3) | 837.6 |  |  | 781.4 |  |  | 56.2 |  |
| Term loans - principal (4) | 67.0 |  |  | 10.6 |  |  | 56.4 |  |
| Term loans - interest (4) | 1.7 |  |  | 0.6 |  |  | 1.1 |  |
| Convertible notes - principal (5) | 2,514.7 |  |  | — |  |  | 2,514.7 |  |
| Convertible notes - interest (5) | 61.6 |  |  | 18.7 |  |  | 42.9 |  |
| Total | $ | 3,529.3 |  |  | $ | 826.0 |  |  | $ | 2,703.3 |  |

[0001628280-25-040830:mdna:149]
(1) The amounts of operating lease liabilities do not include any sublease income amounts nor do they include payments for short-term leases or variable lease payments. As of June 28, 2025, we expect to receive sublease income of approximately $0.9 million over the next year. Refer to “Note 8. Leases” to the consolidated financial statements.

[0001628280-25-040830:mdna:150]
(2) The amount of pension plan contributions represents planned contributions to our defined benefit plans. Although additional future contributions will be required, the amount and timing of these contributions will be affected by actuarial assumptions, the actual rate of returns on plan assets, the level of market interest rates, legislative changes, and the amount of voluntary contributions to the plan. Any contributions for the following fiscal year and later will depend on the value of the plan assets in the future and thus are uncertain. As such, we have not included any amounts beyond one year in the table above.  Refer to “Note 15. Employee Retirement Plans” to the consolidated financial statements.

[0001628280-25-040830:mdna:151]
(3) Purchase obligations represent legally binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Refer to “Note 16. Commitments and Contingencies” to the consolidated financial statements.

[0001628280-25-040830:mdna:152]
(4) The amounts related to term loans include principal and interest on our Sumitomo Mitsui Banking Corporation (“SMBC”) term loan with a fixed annual interest rate of 0.88% and Mizuho Bank, Ltd. (“Mizuho”) term loan with a fixed annual interest rate of 0.90%. The SMBC Term Loan requires monthly principal payments with the remaining principal due on the loan maturity date of July 31, 2029 while the Mizuho Term Loan requires quarterly principal payments with the final payment due on September 20, 2029.

[0001628280-25-040830:mdna:153]
(5) The amounts related to convertible notes include principal and interest on our 2026 Notes, 2028 Notes and 2029 Notes. The 2026 Notes have a maturity date of December 15, 2026, the 2028 Notes have a maturity date of June 15, 2028, and the 2029 Notes have a maturity date of December 15, 2029. The principal balances of our convertible notes are reflected in the payment periods in the table above based on their respective contractual maturities assuming no conversions. On March 15, 2024, the maturity date of the 2024 Notes, we repaid the outstanding $323.1 million principal amount of the 2024 Notes in full. Refer to “Note 10. Debt” to the consolidated financial statements.

[0001628280-25-040830:mdna:154]
We do not have any off-balance sheet arrangements, as such term is defined in rules promulgated by the SEC, which have or are reasonably likely to have a current or future effect on our liquidity or capital resources that are material to investors.

[0001628280-25-040830:mdna:155]
Unrecognized Tax Benefits

[0001628280-25-040830:mdna:156]
As of June 28, 2025, our other non-current liabilities also include $55.6 million of unrecognized tax benefit for uncertain tax positions. We are unable to reliably estimate the timing of future payments related to uncertain tax positions.

[0001628280-25-040830:mdna:157]
Liquidity and Capital Resources Requirements

[0001628280-25-040830:mdna:158]
We believe that our cash and cash equivalents as of June 28, 2025, and cash flows from our operating activities will be sufficient to meet our liquidity and capital spending requirements for at least the next 12 months.

[0001628280-25-040830:mdna:159]
There are a number of factors that could positively or negatively impact our liquidity position, including:

[0001628280-25-040830:mdna:160]
•global economic conditions which affect demand for our products and services and impact the financial stability of our suppliers and customers, including the impact of uncertainty in the banking and financial services industries;

[0001628280-25-040830:mdna:161]
•fluctuations in demand for our products as a result of changes in regulations, tariffs or other trade barriers, and trade relations in general;

[0001628280-25-040830:mdna:162]
•changes in accounts receivable, inventory or other operating assets and liabilities, which affect our working capital;

[0001628280-25-040830:mdna:163]
•increase in capital expenditures to support our business and growth, including increases in manufacturing capacity;

[0001628280-25-040830:mdna:164]
•the tendency of customers to delay payments or to negotiate favorable payment terms to manage their own liquidity positions;

[0001628280-25-040830:mdna:165]
•timing of payments to our suppliers;

[0001628280-25-040830:mdna:166]
•volatility in fixed income and credit, which impact the liquidity and valuation of our investment portfolios;

[0001628280-25-040830:mdna:167]
•cost and availability of credit, which may impact available financing for us, our customers or others with whom we do business;

[0001628280-25-040830:mdna:168]
•volatility in foreign exchange markets, which impacts our financial results;

[0001628280-25-040830:mdna:169]
•possible investments or acquisitions of complementary businesses, products or technologies, or other strategic transactions or partnerships;

[0001628280-25-040830:mdna:170]
•issuance of debt or equity securities, or other financing transactions, including bank debt;

[0001628280-25-040830:mdna:171]
•potential funding of pension liabilities either voluntarily or as required by law or regulation;

[0001628280-25-040830:mdna:172]
•acquisitions or strategic transactions; and

[0001628280-25-040830:mdna:173]
•the settlement of any conversion or redemption of our convertible notes in cash.

[0001628280-25-040830:mdna:174]
Cash Flows

[0001628280-25-040830:mdna:175]
Fiscal Year 2025

[0001628280-25-040830:mdna:176]
As of June 28, 2025, our consolidated balance of cash and cash equivalents increased by $84.0 million, to $520.7 million from $436.7 million as of June 29, 2024. The increase in cash and cash equivalents was due to cash from operating activities of $126.3 million and cash from financing activities of $41.8 million, partially offset by and cash used in investing activities of $84.1 million during the year ended June 28, 2025.

[0001628280-25-040830:mdna:177]
Cash provided by operating activities was $126.3 million during the year ended June 28, 2025, which reflects the net income of $25.9 million and non-cash items of $414.9 million, partially offset by $314.5 million of changes in our operating assets and liabilities. Changes in operating assets and liabilities were primarily driven by an increase in accounts payable of $69.2 million primarily due to higher inventory purchases and capital expenditures, an increase in accrued payroll and related expenses of $22.0 million mainly driven by accrual for cash incentive compensation,  offset by a decrease in income tax liabilities of $218.2 million primarily due to income tax benefits during the year ended June 28, 2025, an increase in inventories of $71.3 million primarily due to inventory builds to support market demand, an increase in accounts receivable of $58.7 million driven by higher revenue, an increase of $35.1 million in prepayments and other current and non-current assets related mainly to value-added-tax receivables driven by higher recent capital expenditures and inventory purchases, and a decrease of $21.8 million in accrued expenses and other current and non-current liabilities driven by payment of the net settlement amount of the Oclaro merger litigation and restructuring related payments.

[0001628280-25-040830:mdna:178]
Cash used in investing activities of $84.1 million during the year ended June 28, 2025 was primarily attributable to capital expenditures of $231.0 million, offset by net proceeds from short-term investments of $98.8 million, $47.8 million of proceeds from sale of facility, net of cash transferred and selling costs, and proceeds from sales of property and equipment of $0.3 million.

[0001628280-25-040830:mdna:179]
Cash from financing activities of $41.8 million during the year ended June 28, 2025, was attributable to $76.5 million of proceeds from Japan term loans and $16.1 million of proceeds from employee stock plans, offset by tax payments related to the net share settlement of restricted stock units of $41.7 million, $8.1 million of principal payments on term loans and payment for an intangible asset acquisition holdback of $1.0 million.
