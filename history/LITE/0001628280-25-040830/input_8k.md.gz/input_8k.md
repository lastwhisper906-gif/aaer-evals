# LITE 8-K — 0001628280-25-039896 filed 2025-08-12

## item codes, every 8-K on or before 2025-08-19

- 2025-08-12 0001628280-25-039896 — 2.02, 9.01
- 2025-06-03 0001628280-25-029086 — 7.01, 9.01
- 2025-05-06 0001628280-25-022709 — 2.02, 9.01
- 2025-02-06 0001628280-25-004265 — 2.02, 9.01
- 2025-02-03 0001193125-25-019371 — 2.02, 5.02, 9.01
- 2024-12-12 0001193125-24-277338 — 5.02, 9.01
- 2024-11-22 0001628280-24-048886 — 5.02, 5.07, 9.01
- 2024-11-07 0001628280-24-046302 — 2.02, 9.01
- 2024-08-21 0001628280-24-037938 — 2.02, 9.01 — amendment of 0001628280-24-037191
- 2024-08-14 0001628280-24-037191 — 2.02, 9.01
- 2024-05-06 0001628280-24-020640 — 2.02, 9.01
- 2024-02-27 0001628280-24-006936 — 5.02
- 2024-02-08 0001628280-24-003789 — 2.02, 9.01
- 2024-01-18 0001628280-24-001551 — 9.01 — amendment of 0001193125-23-272452
- 2023-11-21 0001628280-23-039654 — 5.02, 5.07
- 2023-11-08 0001628280-23-037563 — 2.02, 9.01
- 2023-11-07 0001193125-23-272452 — 2.01, 8.01, 9.01
- 2023-10-30 0001193125-23-265658 — 1.01, 2.02, 9.01
- 2023-08-17 0001628280-23-029741 — 2.02, 9.01
- 2023-06-16 0001193125-23-168966 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2023-05-09 0001628280-23-016629 — 2.02, 9.01
- 2023-04-06 0001628280-23-010935 — 2.02, 8.01, 9.01
- 2023-02-24 0001193125-23-048742 — 5.02, 9.01
- 2023-02-09 0001628280-23-002866 — 2.02, 9.01
- 2022-11-21 0001628280-22-030473 — 5.02, 5.07, 9.01
- 2022-11-08 0001628280-22-028758 — 2.02, 9.01
- 2022-08-16 0001628280-22-022980 — 2.02, 9.01
- 2022-08-03 0001193125-22-210674 — 2.01, 8.01, 9.01
- 2022-07-29 0001193125-22-206587 — 8.01, 9.01
- 2022-05-04 0001628280-22-012145 — 2.02, 9.01
- 2022-03-08 0001193125-22-069350 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2022-02-03 0001628280-22-001736 — 2.02, 9.01
- 2022-01-21 0001193125-22-014413 — 8.01, 9.01
- 2021-11-23 0001628280-21-024070 — 5.02, 5.07
- 2021-11-05 0001193125-21-321796 — 1.01, 9.01
- 2021-11-04 0001628280-21-021618 — 2.02, 9.01
- 2021-11-04 0001193125-21-319601 — 8.01, 9.01
- 2021-08-18 0001628280-21-017219 — 2.02, 9.01
- 2021-06-08 0001633978-21-000030 — 5.02, 9.01
- 2021-05-12 0001633978-21-000008 — 2.02, 9.01
- 2021-03-10 0001193125-21-075438 — 1.01, 8.01, 9.01
- 2021-02-02 0001633978-21-000002 — 2.02, 9.01
- 2021-01-19 0001104659-21-005024 — 1.01, 2.02, 8.01, 9.01
- 2020-11-24 0001193125-20-302557 — 5.02, 5.07
- 2020-11-02 0001633978-20-000017 — 2.02, 9.01
- 2020-09-18 0001633978-20-000012 — 5.02, 9.01
- 2020-08-11 0001633978-20-000010 — 2.02, 9.01
- 2020-05-05 0001628280-20-006358 — 2.02, 9.01
- 2020-02-04 0001633978-20-000002 — 2.02, 9.01
- 2019-12-12 0001193125-19-312875 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2019-12-04 0001633978-19-000075 — 8.01
- 2019-11-20 0001633978-19-000074 — 5.07
- 2019-10-31 0001633978-19-000070 — 2.02, 9.01
- 2019-08-08 0001633978-19-000068 — 2.02, 9.01
- 2019-05-08 0001633978-19-000031 — 1.01
- 2019-05-07 0001633978-19-000029 — 2.02, 9.01
- 2019-02-15 0001633978-19-000005 — 9.01 — amendment of 0001193125-18-346211
- 2019-02-08 0001193125-19-031591 — 5.02, 9.01
- 2019-02-05 0001633978-19-000001 — 2.02, 9.01
- 2018-12-10 0001193125-18-346211 — 1.01, 2.01, 2.03, 5.02, 8.01, 9.01
- 2018-12-06 0001633978-18-000150 — 8.01
- 2018-11-14 0001633978-18-000139 — 5.07
- 2018-11-13 0001633978-18-000136 — 3.02
- 2018-11-13 0001633978-18-000132 — 7.01, 9.01
- 2018-11-01 0001628280-18-013238 — 2.02, 9.01
- 2018-08-08 0001633978-18-000056 — 2.02, 9.01
- 2018-06-08 0001193125-18-188241 — 5.02, 9.01
- 2018-05-02 0001633978-18-000029 — 2.02, 9.01
- 2018-03-12 0001193125-18-078154 — 1.01, 2.01, 8.01, 9.01
- 2018-02-06 0001628280-18-001082 — 2.02, 9.01
- 2017-11-08 0001633978-17-000133 — 5.02, 9.01
- 2017-11-07 0001633978-17-000131 — 5.07
- 2017-11-01 0001633978-17-000117 — 2.02, 9.01
- 2017-08-09 0001633978-17-000058 — 2.02, 9.01
- 2017-05-04 0001633978-17-000035 — 2.02, 9.01
- 2017-03-08 0001193125-17-074740 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2017-03-02 0001193125-17-066769 — 8.01, 9.01
- 2017-02-07 0001633978-17-000005 — 2.02, 9.01
- 2017-01-03 0001628280-17-000018 — 4.01, 9.01
- 2016-11-09 0001628280-16-021143 — 5.02, 5.07, 9.01
- 2016-10-27 0001628280-16-020382 — 2.02, 9.01
- 2016-08-09 0001628280-16-018811 — 2.02, 9.01
- 2016-06-21 0001628280-16-017201 — 8.01
- 2016-05-04 0001628280-16-015501 — 2.02, 9.01
- 2016-02-16 0001628280-16-011261 — 5.02, 9.01
- 2016-02-04 0001628280-16-010758 — 5.02, 9.01
- 2016-02-04 0001628280-16-010755 — 2.02, 9.01
- 2015-11-17 0001193125-15-378953 — 7.01
- 2015-11-10 0001628280-15-008606 — 2.02, 9.01
- 2015-09-28 0001193125-15-329665 — 8.01, 9.01
- 2015-08-11 0001193125-15-286405 — 7.01, 9.01
- 2015-08-06 0001193125-15-281219 — 1.01, 5.02, 5.03, 5.05, 8.01, 9.01
- 2015-08-03 0001193125-15-274808 — 5.03, 9.01

## late-filing notifications on or before 2025-08-19

- 2015-11-10 0001628280-15-008612 — NT 10-Q, for the period ended 2015-09-26
- 2015-09-28 0001193125-15-329672 — NT 10-K, for the period ended 2015-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001628280-25-039896:8k_2_02:1]
EX-99.1
2
lite_ex991xq4fy25.htm
EX-99.1

[0001628280-25-039896:8k_2_02:2]
Document

[0001628280-25-039896:8k_2_02:3]
NEWS RELEASE

[0001628280-25-039896:8k_2_02:4]
LUMENTUM ANNOUNCES FOURTH QUARTER AND FULL FISCAL YEAR 2025 RESULTS

[0001628280-25-039896:8k_2_02:5]
Fiscal Fourth Quarter Highlights:

[0001628280-25-039896:8k_2_02:6]
•Net revenue of $480.7 million

[0001628280-25-039896:8k_2_02:7]
•GAAP gross margin of 33.3%; Non-GAAP gross margin of 37.8%

[0001628280-25-039896:8k_2_02:8]
•GAAP operating loss of 1.7%; Non-GAAP operating margin of 15.0%

[0001628280-25-039896:8k_2_02:9]
Fiscal Year 2025 Highlights:

[0001628280-25-039896:8k_2_02:10]
•Net revenue of $1.65 billion

[0001628280-25-039896:8k_2_02:11]
•GAAP gross margin of 28.0%; Non-GAAP gross margin of 34.7%

[0001628280-25-039896:8k_2_02:12]
•GAAP operating loss of 10.9%; Non-GAAP operating margin of 9.7%

[0001628280-25-039896:8k_2_02:13]
San Jose, Calif., August 12, 2025 – Lumentum Holdings Inc. (“Lumentum” or the “Company”) today reported results for its fourth quarter and full fiscal year ended June 28, 2025.

[0001628280-25-039896:8k_2_02:14]
“In our fiscal fourth quarter, we executed exceptionally well in meeting robust demand across our portfolio of cloud products supporting AI data centers,” said Michael Hurlston, Lumentum President and CEO. “This solid performance, combined with sustained customer demand, drove our Q4 revenue above the high end of the upwardly revised guidance we provided in early June. The outperformance was broad-based across our cloud-focused business, with particular strength in components, specifically EML chips, pump lasers, and narrow linewidth laser assemblies for data center interconnect, as well as 800G modules. Looking ahead, we expect continued strong demand for our AI data center and long-haul solutions, giving us confidence in surpassing $600 million in quarterly revenue by June 2026 or earlier.”

[0001628280-25-039896:8k_2_02:15]
Fiscal Fourth Quarter Highlights:

[0001628280-25-039896:8k_2_02:16]
Net revenue for the fourth quarter of fiscal year 2025 was $480.7 million, with GAAP net income of $213.3 million, or $2.96 per diluted share. Net revenue for the third quarter of fiscal year 2025 was $425.2 million, with GAAP net loss of $44.1 million, or $0.64 per diluted share. Net revenue for the fourth quarter of fiscal year 2024 was $308.3 million, with GAAP net loss of $252.5 million, or $3.72 per diluted share.

[0001628280-25-039896:8k_2_02:17]
Non-GAAP net income for the fourth quarter of fiscal year 2025 was $63.3 million, or $0.88 per diluted share. Non-GAAP net income for the third quarter of fiscal year 2025 was $40.9 million, or $0.57 per diluted share. Non-GAAP net loss for the fourth quarter of fiscal year 2024 was $8.9 million, or $0.13 per diluted share.(1)

[0001628280-25-039896:8k_2_02:18]
The Company held $877.1 million in total cash, cash equivalents, and short-term investments at the end of the fourth quarter of fiscal year 2025, an increase of $10.4 million from the third quarter of fiscal year 2025.

[0001628280-25-039896:8k_2_02:19]
Full Fiscal Year 2025 Highlights:

[0001628280-25-039896:8k_2_02:20]
Net revenue for fiscal year 2025 was $1,645.0 million, with GAAP net income of $25.9 million, or $0.37 per diluted share. Net revenue for fiscal year 2024 was $1,359.2 million, with GAAP net loss of $546.5 million, or $8.12 per diluted share.

[0001628280-25-039896:8k_2_02:21]
Non-GAAP net income for fiscal year 2025 was $146.4 million, or $2.06 per diluted share. Non-GAAP net income for fiscal year 2024 was $29.8 million, or $0.44 per diluted share.(1)

[0001628280-25-039896:8k_2_02:22]
Financial Overview – Fiscal Fourth Quarter Ended June 28, 2025

[0001628280-25-039896:8k_2_02:23]
|  | GAAP Results ($ in millions) |
|  | Q4 |  | Q3 |  | Q4 |  | Change |
|  | FY 2025 |  | FY 2025 |  | FY 2024 |  | Q/Q |  | Y/Y |
| Net revenue | $ | 480.7 |  |  | $ | 425.2 |  |  | $ | 308.3 |  |  | 13.1% |  | 55.9% |
| GAAP gross margin | 33.3 | % |  | 28.8 | % |  | 16.6 | % |  | 450bps |  | 1,670bps |
| GAAP operating loss | (1.7) | % |  | (8.9) | % |  | (43.3) | % |  | 720bps |  | 4,160bps |
|  | Non-GAAP Results ($ in millions) |
|  | Q4 |  | Q3 |  | Q4 |  | Change |
|  | FY 2025 |  | FY 2025 |  | FY 2024 (1) |  | Q/Q |  | Y/Y |
| Net revenue | $ | 480.7 |  |  | $ | 425.2 |  |  | $ | 308.3 |  |  | 13.1% |  | 55.9% |
| Non-GAAP gross margin | 37.8 | % |  | 35.2 | % |  | 27.8 | % |  | 260bps |  | 1,000bps |
| Non-GAAP operating margin (loss) | 15.0 | % |  | 10.8 | % |  | (5.1) | % |  | 420bps |  | 2,010bps |

[0001628280-25-039896:8k_2_02:24]
|  | Net Revenue by Segment ($ in millions) |
|  | Q4 |  | % of |  | Q3 |  | Q4 |  | Change |
|  | FY 2025 |  | Net Revenue |  | FY 2025 |  | FY 2024 |  | Q/Q |  | Y/Y |
| Cloud & Networking | $ | 424.1 |  |  | 88.2 | % |  | $ | 365.2 |  |  | $ | 254.7 |  |  | 16.1 | % |  | 66.5 | % |
| Industrial Tech | 56.6 |  |  | 11.8 | % |  | 60.0 |  |  | 53.6 |  |  | (5.7) | % |  | 5.6 | % |
| Total | $ | 480.7 |  |  | 100.0 | % |  | $ | 425.2 |  |  | $ | 308.3 |  |  | 13.1 | % |  | 55.9 | % |

[0001628280-25-039896:8k_2_02:25]
Financial Overview – Fiscal Year Ended June 28, 2025

[0001628280-25-039896:8k_2_02:26]
|  | GAAP Results ($ in millions) |
|  | FY 2025 |  | FY 2024 |  | Change Y/Y |  |
| Net revenue | $ | 1,645.0 |  |  | $ | 1,359.2 |  |  | 21.0% |  |
| GAAP Gross margin | 28.0 | % |  | 18.5 | % |  | 950bps |  |
| GAAP Operating loss | (10.9) | % |  | (31.9) | % |  | 2,100bps |  |

[0001628280-25-039896:8k_2_02:27]
|  | Non-GAAP Results ($ in millions) |
|  | FY 2025 |  | FY 2024 (1) |  | Change Y/Y |  |
| Net revenue | $ | 1,645.0 |  |  | $ | 1,359.2 |  |  | 21.0% |  |
| Non-GAAP Gross margin | 34.7 | % |  | 30.2 | % |  | 450bps |  |
| Non-GAAP Operating margin (loss) | 9.7 | % |  | (0.6) | % |  | 1,030bps |  |

[0001628280-25-039896:8k_2_02:28]
|  | Net Revenue by Segment ($ in millions) |
|  | FY 2025 |  | FY 2024 |  | Change Y/Y |  |
| Cloud & Networking | $ | 1,410.8 |  |  | $ | 1,084.9 |  |  | 30.0% |  |
| Industrial Tech | 234.2 |  |  | 274.3 |  |  | (14.6)% |  |
| Total | $ | 1,645.0 |  |  | $ | 1,359.2 |  |  | 21.0% |  |

[0001628280-25-039896:8k_2_02:29]
(1) During the first quarter of fiscal year 2025, the Company refined its methodology to report non-GAAP financial measures. The change does not impact the Company’s financial position, cash flows, or GAAP consolidated results of operations. Prior period non-GAAP financial measures presented in this press release have been recast to conform to the current presentation.

[0001628280-25-039896:8k_2_02:30]
The tables above provide comparisons of quarterly and annual results to prior periods, including sequential quarterly and year-over-year changes. A reconciliation between GAAP and non-GAAP financial measures is contained in this release under the section titled “Use of Non-GAAP Financial Measures.”

[0001628280-25-039896:8k_2_02:31]
Business Outlook

[0001628280-25-039896:8k_2_02:32]
Lumentum expects the following for the first quarter of fiscal year 2026:

[0001628280-25-039896:8k_2_02:33]
•Net revenue in the range of $510 million to $540 million

[0001628280-25-039896:8k_2_02:34]
•Non-GAAP operating margin of 16.0% - 17.5%

[0001628280-25-039896:8k_2_02:35]
•Non-GAAP diluted earnings per share of $0.95 to $1.10

[0001628280-25-039896:8k_2_02:36]
We have not provided reconciliations from GAAP to non-GAAP financial measures or the equivalent GAAP measure for non-GAAP financial measures in our outlook, as they cannot be provided without unreasonable effort. A large portion of non-GAAP adjustments, such as restructuring charges, stock-based compensation, non-GAAP income tax reconciling adjustments, acquisition related costs, and other costs and contingencies unrelated to current and future operations are by their nature highly volatile and we have low visibility as to the range that may be incurred in the future.

[0001628280-25-039896:8k_2_02:37]
Conference Call

[0001628280-25-039896:8k_2_02:38]
Lumentum will host a conference call today, August 12, 2025, at 2:00 pm PT / 5:00 pm ET to discuss its fiscal fourth quarter and full year results. A live webcast of the call will be available in the Investors section of the Lumentum website at http://investor.lumentum.com. To listen to the live conference call, dial (833) 470-1428 or (404) 975-4839 and reference the conference ID 554196. Supporting materials outlining the Company’s latest financial results will be posted on http://investor.lumentum.com under the “Events and Presentations” section concurrently with this earnings press release. Lumentum has used, and intends to continue to use, its Investor Relations website as means of disclosing material nonpublic information and for complying with its disclosure obligations under Regulation FD. This press release is also being furnished as an exhibit to a Current Report on Form 8-K filed with the Securities and Exchange Commission and will be available at http://www.sec.gov/.

[0001628280-25-039896:8k_2_02:39]
About Lumentum

[0001628280-25-039896:8k_2_02:40]
Lumentum (NASDAQ: LITE) is a market-leading designer and manufacturer of innovative optical and photonic products enabling optical networking and laser applications worldwide. Lumentum optical components and subsystems are part of virtually every type of telecom, enterprise, and data center network. Lumentum lasers enable advanced manufacturing techniques and diverse applications including next-generation imaging and sensing capabilities. Lumentum is headquartered in San Jose, California with R&D, manufacturing, and sales offices worldwide. For more information, visit www.lumentum.com and follow Lumentum on LinkedIn, X (formerly known as Twitter), Facebook, Instagram and YouTube.

[0001628280-25-039896:8k_2_02:41]
Forward-Looking Statements

[0001628280-25-039896:8k_2_02:42]
Contact Information

[0001628280-25-039896:8k_2_02:43]
Investors:     Kathy Ta, (408) 750-3853; investor.relations@lumentum.com

[0001628280-25-039896:8k_2_02:44]
Media:         Diane Soto, (408) 546-4439; media@lumentum.com

[0001628280-25-039896:8k_2_02:45]
Category:    Financial

[0001628280-25-039896:8k_2_02:46]
The following financial tables are presented in accordance with GAAP, unless otherwise specified.

[0001628280-25-039896:8k_2_02:47]
LUMENTUM HOLDINGS INC.

[0001628280-25-039896:8k_2_02:48]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001628280-25-039896:8k_2_02:49]
(in millions, except per share data)

[0001628280-25-039896:8k_2_02:50]
(unaudited)

[0001628280-25-039896:8k_2_02:51]
|  | Three Months Ended |  | Twelve Months Ended |
|  | June 28, 2025 |  | June 29, 2024 |  | June 28, 2025 |  | June 29, 2024 |
| Net revenue | $ | 480.7 |  |  | $ | 308.3 |  |  | $ | 1,645.0 |  |  | $ | 1,359.2 |  |
| Cost of sales | 301.5 |  |  | 234.9 |  |  | 1,102.9 |  |  | 1,023.8 |  |
| Amortization of acquired developed intangibles | 19.3 |  |  | 22.1 |  |  | 82.2 |  |  | 83.9 |  |
| Gross profit | 159.9 |  |  | 51.3 |  |  | 459.9 |  |  | 251.5 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 79.5 |  |  | 73.2 |  |  | 303.9 |  |  | 302.2 |  |
| Selling, general and administrative | 83.6 |  |  | 74.9 |  |  | 348.2 |  |  | 310.7 |  |
| Restructuring and related charges | 5.2 |  |  | 36.6 |  |  | 22.8 |  |  | 72.6 |  |
| Gain on sale of facility | — |  |  | — |  |  | (34.9) |  |  | — |  |
| Total operating expenses | 168.3 |  |  | 184.7 |  |  | 640.0 |  |  | 685.5 |  |
| Loss from operations | (8.4) |  |  | (133.4) |  |  | (180.1) |  |  | (434.0) |  |
| Interest expense | (5.4) |  |  | (5.4) |  |  | (22.2) |  |  | (33.8) |  |
| Other income, net | 2.4 |  |  | 11.3 |  |  | 30.2 |  |  | 62.1 |  |
| Loss before income taxes | (11.4) |  |  | (127.5) |  |  | (172.1) |  |  | (405.7) |  |
| Income tax (benefit) provision | (224.7) |  |  | 125.0 |  |  | (198.0) |  |  | 140.8 |  |
| Net income (loss) | $ | 213.3 |  |  | $ | (252.5) |  |  | $ | 25.9 |  |  | $ | (546.5) |  |
| Net income (loss) per share: |  |  |  |  |  |  |  |
| Basic | $ | 3.06 |  |  | $ | (3.72) |  |  | $ | 0.38 |  |  | $ | (8.12) |  |
| Diluted | $ | 2.96 |  |  | $ | (3.72) |  |  | $ | 0.37 |  |  | $ | (8.12) |  |
| Shares used to compute net income (loss) per share: |  |  |  |  |  |  |  |
| Basic | 69.6 |  |  | 67.8 |  |  | 69.0 |  |  | 67.3 |  |
| Diluted | 72.0 |  |  | 67.8 |  |  | 69.6 |  |  | 67.3 |  |

[0001628280-25-039896:8k_2_02:52]
LUMENTUM HOLDINGS INC.

[0001628280-25-039896:8k_2_02:53]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001628280-25-039896:8k_2_02:54]
(in millions, except per share data)

[0001628280-25-039896:8k_2_02:55]
(unaudited)

[0001628280-25-039896:8k_2_02:56]
|  | June 28, 2025 |  | June 29, 2024 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 520.7 |  |  | $ | 436.7 |  |
| Short-term investments | 356.4 |  |  | 450.3 |  |
| Accounts receivable, net | 250.0 |  |  | 194.7 |  |
| Inventories | 470.1 |  |  | 398.4 |  |
| Prepayments and other current assets | 120.1 |  |  | 110.0 |  |
| Total current assets | 1,717.3 |  |  | 1,590.1 |  |
| Property, plant and equipment, net | 726.4 |  |  | 572.5 |  |
| Operating lease right-of-use assets, net | 27.9 |  |  | 72.8 |  |
| Goodwill | 1,060.9 |  |  | 1,055.8 |  |
| Other intangible assets, net | 465.1 |  |  | 617.5 |  |
| Deferred tax asset | 210.3 |  |  | 10.7 |  |
| Other non-current assets | 10.8 |  |  | 12.5 |  |
| Total assets | $ | 4,218.7 |  |  | $ | 3,931.9 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 225.2 |  |  | $ | 126.3 |  |
| Accrued payroll and related expenses | 57.9 |  |  | 36.1 |  |
| Accrued expenses | 34.6 |  |  | 52.4 |  |
| Current portion of long-term debt | 10.6 |  |  | — |  |
| Operating lease liabilities, current | 11.4 |  |  | 13.4 |  |
| Other current liabilities | 53.1 |  |  | 41.1 |  |
| Total current liabilities | 392.8 |  |  | 269.3 |  |
| Long-term debt | 2,562.6 |  |  | 2,503.2 |  |
| Operating lease liabilities, non-current | 23.6 |  |  | 43.0 |  |
| Deferred tax liability | 7.2 |  |  | 55.7 |  |
| Other non-current liabilities | 97.8 |  |  | 103.4 |  |
| Total liabilities | 3,084.0 |  |  | 2,974.6 |  |
| Stockholders’ equity: |  |  |  |
| Common stock, $0.001 par value, 990 authorized shares; 69.8 and 67.9 shares issued and outstanding as of June 28, 2025 and June 29, 2024, respectively | 0.1 |  |  | 0.1 |  |
| Additional paid-in capital | 1,986.8 |  |  | 1,835.0 |  |
| Accumulated deficit | (861.2) |  |  | (887.1) |  |
| Accumulated other comprehensive income | 9.0 |  |  | 9.3 |  |
| Total stockholders’ equity | 1,134.7 |  |  | 957.3 |  |
| Total liabilities and stockholders’ equity | $ | 4,218.7 |  |  | $ | 3,931.9 |  |

[0001628280-25-039896:8k_2_02:57]
Use of Non-GAAP Financial Measures

[0001628280-25-039896:8k_2_02:58]
In this press release, Lumentum provides investors with certain non-GAAP financial measures: gross profit, gross margin, research and development expense, selling, general and administrative expense, operating margin (loss), income (loss) from operations, interest and other income (expense), net, income before income taxes, provision for income taxes, net income (loss), and net income (loss) per share on a non-GAAP basis, as well as the non-GAAP financial measures of EBITDA and Adjusted EBITDA. Lumentum believes this non-GAAP financial information provides additional insight into the Company’s on-going business operations and results, as well as cash generation, and has therefore chosen to provide this information to investors for a more consistent basis of comparison and to help them evaluate the results of the Company’s on-going operations and enable more meaningful period to period comparisons. In addition, the Company believes that providing certain of these measures allows investors to better understand the Company’s operating performance and cash flows and, importantly, to evaluate the methodology and information used by management to monitor, manage, evaluate and measure the Company’s business, results of operations, and cash flows. However, investors are cautioned that there are material limitations associated with the use of non-GAAP financial measures as an analytical tool. In particular, many of the adjustments to our GAAP financial measures reflect the exclusion of items that are recurring and will be reflected in our financial results for the foreseeable future.  Moreover, the non-GAAP financial measures we present may be different from non-GAAP financial measures used by other companies or may not be comparable to similarly titled measurements reported by other companies, limiting their usefulness for comparison purposes. We do not consider non-GAAP financial measures to be a substitute for, or superior to, the information provided by GAAP financial measures, and the non-GAAP financial measures used in this press release should not be considered in isolation from measures of financial performance prepared in accordance with GAAP.

[0001628280-25-039896:8k_2_02:59]
Our non-GAAP financial measures used in this press release exclude (i) stock-based compensation, (ii) acquisition related costs, (iii) integration related costs, (iv) amortization of acquired intangibles, (v) amortization of acquired inventory fair value adjustments, (vi) restructuring and related charges, (vii) intangible assets write-off, (viii) gain on sale of facility, (ix) foreign exchange losses (gains), net, (x) non-cash interest expense on convertible notes, (xi) non-GAAP income tax reconciling adjustments, and (xii) other (gains) charges related to non-recurring activities.

[0001628280-25-039896:8k_2_02:60]
We utilize a long-term projected non-GAAP tax rate to compute our non-GAAP income tax provision. The long-term projected non-GAAP tax rate is based on a multi-year projection of our estimated annual GAAP income tax forecast, adjusted to account for the tax effect of non-GAAP pretax adjustments as well as the effects of significant non-recurring and period specific tax items. Our non-GAAP tax provision for fiscal year 2025 is 16.5%. The difference between our GAAP income tax provision and our non-GAAP income tax provision is presented as non-GAAP income tax reconciling adjustments.

[0001628280-25-039896:8k_2_02:61]
A quantitative reconciliation between GAAP and non-GAAP financial data with respect to historical periods is included in the supplemental financial table attached to this press release.

[0001628280-25-039896:8k_2_02:62]
LUMENTUM HOLDINGS INC.

[0001628280-25-039896:8k_2_02:63]
RECONCILIATION OF GAAP TO NON-GAAP FINANCIAL MEASURES

[0001628280-25-039896:8k_2_02:64]
(in millions, except per share data)

[0001628280-25-039896:8k_2_02:65]
(unaudited)

[0001628280-25-039896:8k_2_02:66]
|  | Three Months Ended |  | Twelve Months Ended |
|  | June 28, 2025 |  | March 29, 2025 |  | June 29, 2024 (1) |  | June 28, 2025 |  | June 29, 2024 (1) |
| Gross profit on GAAP basis | $ | 159.9 |  |  | $ | 122.5 |  |  | $ | 51.3 |  |  | $ | 459.9 |  |  | $ | 251.5 |  |
| Stock-based compensation | 8.8 |  |  | 9.2 |  |  | 8.2 |  |  | 36.9 |  |  | 31.7 |  |
| Integration related costs | 0.6 |  |  | — |  |  | 1.9 |  |  | 2.9 |  |  | 18.1 |  |
| Amortization of acquired intangibles | 19.3 |  |  | 19.0 |  |  | 22.1 |  |  | 82.2 |  |  | 83.9 |  |
| Amortization of inventory fair value adjustments | — |  |  | — |  |  | — |  |  | — |  |  | 8.3 |  |
| Other charges, net (5) | (7.0) |  |  | (1.2) |  |  | 2.1 |  |  | (10.4) |  |  | 16.6 |  |
| Gross profit on non-GAAP basis | $ | 181.6 |  |  | $ | 149.5 |  |  | $ | 85.6 |  |  | $ | 571.5 |  |  | $ | 410.1 |  |
| Gross margin on non-GAAP basis | 37.8 | % |  | 35.2 | % |  | 27.8 | % |  | 34.7 | % |  | 30.2 | % |
| Research and development on GAAP basis | $ | 79.5 |  |  | $ | 75.9 |  |  | $ | 73.2 |  |  | $ | 303.9 |  |  | $ | 302.2 |  |
| Stock-based compensation | (11.4) |  |  | (11.2) |  |  | (8.0) |  |  | (43.3) |  |  | (38.1) |  |
| Integration related costs | — |  |  | (0.3) |  |  | — |  |  | (0.3) |  |  | (0.1) |  |
| Amortization of acquired intangibles | (0.4) |  |  | (0.4) |  |  | (0.4) |  |  | (1.6) |  |  | (1.5) |  |
| Intangible assets write-off | (0.1) |  |  | (0.7) |  |  | — |  |  | (2.7) |  |  | — |  |
| Acquisition related costs | — |  |  | — |  |  | — |  |  | — |  |  | (0.4) |  |
| Other charges, net | — |  |  | — |  |  | 0.1 |  |  | — |  |  | (1.1) |  |
| Research and development on non-GAAP basis | $ | 67.6 |  |  | $ | 63.3 |  |  | $ | 64.9 |  |  | $ | 256.0 |  |  | $ | 261.0 |  |
| Selling, general and administrative on GAAP basis | $ | 83.6 |  |  | $ | 112.0 |  |  | $ | 74.9 |  |  | $ | 348.2 |  |  | $ | 310.7 |  |
| Stock-based compensation (2) | (19.8) |  |  | (42.4) |  |  | (14.3) |  |  | (97.0) |  |  | (59.0) |  |
| Acquisition related (costs) reversal | (0.7) |  |  | (0.5) |  |  | 0.2 |  |  | (1.2) |  |  | (12.9) |  |
| Integration related costs | (0.7) |  |  | (1.1) |  |  | (2.2) |  |  | (6.0) |  |  | (8.8) |  |
| Amortization of acquired intangibles | (14.9) |  |  | (15.0) |  |  | (19.4) |  |  | (65.9) |  |  | (65.2) |  |
| Other charges, net (5) | (5.8) |  |  | (12.9) |  |  | (2.7) |  |  | (22.7) |  |  | (8.1) |  |
| Selling, general and administrative on non-GAAP basis | $ | 41.7 |  |  | $ | 40.1 |  |  | $ | 36.5 |  |  | $ | 155.4 |  |  | $ | 156.7 |  |
| Loss from operations on GAAP basis | $ | (8.4) |  |  | $ | (37.7) |  |  | $ | (133.4) |  |  | $ | (180.1) |  |  | $ | (434.0) |  |
| Stock-based compensation (2) | 40.0 |  |  | 62.8 |  |  | 30.5 |  |  | 177.2 |  |  | 128.8 |  |
| Acquisition related costs (reversal) | 0.7 |  |  | 0.5 |  |  | (0.2) |  |  | 1.2 |  |  | 13.3 |  |
| Integration related costs | 1.3 |  |  | 1.4 |  |  | 4.1 |  |  | 9.2 |  |  | 27.0 |  |
| Amortization of acquired intangibles | 34.6 |  |  | 34.4 |  |  | 41.9 |  |  | 149.7 |  |  | 150.6 |  |
| Amortization of inventory fair value adjustments | — |  |  | — |  |  | — |  |  | — |  |  | 8.3 |  |
| Restructuring and related charges (3) | 5.2 |  |  | 7.2 |  |  | 36.6 |  |  | 22.8 |  |  | 72.6 |  |
| Intangible assets write-off | 0.1 |  |  | 0.7 |  |  | — |  |  | 2.7 |  |  | — |  |
| Gain on sale of facility (4) | — |  |  | (34.9) |  |  | — |  |  | (34.9) |  |  | — |  |
| Other charges, net (5) | (1.2) |  |  | 11.7 |  |  | 4.7 |  |  | 12.3 |  |  | 25.8 |  |
| Income (loss) from operations on non-GAAP basis | $ | 72.3 |  |  | $ | 46.1 |  |  | $ | (15.8) |  |  | $ | 160.1 |  |  | $ | (7.6) |  |
| Operating margin (loss) on non-GAAP basis | 15.0 | % |  | 10.8 | % |  | (5.1) | % |  | 9.7 | % |  | (0.6) | % |

[0001628280-25-039896:8k_2_02:67]
| Interest and other income, net on GAAP basis | $ | (3.0) |  |  | $ | (1.5) |  |  | $ | 5.9 |  |  | $ | 8.0 |  |  | $ | 28.3 |  |
| Foreign exchange losses (gains), net | 5.8 |  |  | 3.6 |  |  | (1.2) |  |  | 4.2 |  |  | (0.7) |  |
| Non-cash interest expense on convertible notes and other expenses | 0.7 |  |  | 0.8 |  |  | 0.7 |  |  | 3.0 |  |  | 14.9 |  |
| Interest and other income, net on non-GAAP basis | $ | 3.5 |  |  | $ | 2.9 |  |  | $ | 5.4 |  |  | $ | 15.2 |  |  | $ | 42.5 |  |
| Loss before income taxes on GAAP basis | $ | (11.4) |  |  | $ | (39.2) |  |  | $ | (127.5) |  |  | $ | (172.1) |  |  | $ | (405.7) |  |
| Stock-based compensation (2) | 40.0 |  |  | 62.8 |  |  | 30.5 |  |  | 177.2 |  |  | 128.8 |  |
| Acquisition related costs (reversal) | 0.7 |  |  | 0.5 |  |  | (0.2) |  |  | 1.2 |  |  | 13.3 |  |
| Integration related costs | 1.3 |  |  | 1.4 |  |  | 4.1 |  |  | 9.2 |  |  | 27.0 |  |
| Amortization of acquired intangibles | 34.6 |  |  | 34.4 |  |  | 41.9 |  |  | 149.7 |  |  | 150.6 |  |
| Amortization of inventory fair value adjustments | — |  |  | — |  |  | — |  |  | — |  |  | 8.3 |  |
| Restructuring and related charges (3) | 5.2 |  |  | 7.2 |  |  | 36.6 |  |  | 22.8 |  |  | 72.6 |  |
| Gain on sale of facility (4) | — |  |  | (34.9) |  |  | — |  |  | (34.9) |  |  | — |  |
| Intangible assets write-off | 0.1 |  |  | 0.7 |  |  | — |  |  | 2.7 |  |  | — |  |
| Foreign exchange losses (gains), net | 5.8 |  |  | 3.6 |  |  | (1.2) |  |  | 4.2 |  |  | (0.7) |  |
| Non-cash interest expense on convertible notes and other expenses | 0.7 |  |  | 0.8 |  |  | 0.7 |  |  | 3.0 |  |  | 14.9 |  |
| Other charges, net (5) | (1.2) |  |  | 11.7 |  |  | 4.7 |  |  | 12.3 |  |  | 25.8 |  |
| Income (loss) before income taxes on non-GAAP basis | $ | 75.8 |  |  | $ | 49.0 |  |  | $ | (10.4) |  |  | $ | 175.3 |  |  | $ | 34.9 |  |
| Income tax provision (benefit) on GAAP basis | $ | (224.7) |  |  | $ | 4.9 |  |  | $ | 125.0 |  |  | $ | (198.0) |  |  | $ | 140.8 |  |
| Non-GAAP income tax reconciling adjustments | 237.2 |  |  | 3.2 |  |  | (126.5) |  |  | 226.9 |  |  | (135.7) |  |
| Income tax provision (benefit) on non-GAAP basis | $ | 12.5 |  |  | $ | 8.1 |  |  | $ | (1.5) |  |  | $ | 28.9 |  |  | $ | 5.1 |  |
| Net income (loss) on GAAP basis | $ | 213.3 |  |  | $ | (44.1) |  |  | $ | (252.5) |  |  | $ | 25.9 |  |  | $ | (546.5) |  |
| Stock-based compensation (2) | 40.0 |  |  | 62.8 |  |  | 30.5 |  |  | 177.2 |  |  | 128.8 |  |
| Acquisition related costs (reversal) | 0.7 |  |  | 0.5 |  |  | (0.2) |  |  | 1.2 |  |  | 13.3 |  |
| Integration related costs | 1.3 |  |  | 1.4 |  |  | 4.1 |  |  | 9.2 |  |  | 27.0 |  |
| Amortization of acquired intangibles | 34.6 |  |  | 34.4 |  |  | 41.9 |  |  | 149.7 |  |  | 150.6 |  |
| Amortization of inventory fair value adjustments | — |  |  | — |  |  | — |  |  | — |  |  | 8.3 |  |
| Restructuring and related charges (3) | 5.2 |  |  | 7.2 |  |  | 36.6 |  |  | 22.8 |  |  | 72.6 |  |
| Intangible assets write-off | 0.1 |  |  | 0.7 |  |  | — |  |  | 2.7 |  |  | — |  |
| Gain on sale of facility (4) | — |  |  | (34.9) |  |  | — |  |  | (34.9) |  |  | — |  |
| Foreign exchange losses (gains), net | 5.8 |  |  | 3.6 |  |  | (1.2) |  |  | 4.2 |  |  | (0.7) |  |
| Non-cash interest expense on convertible notes and other expenses | 0.7 |  |  | 0.8 |  |  | 0.7 |  |  | 3.0 |  |  | 14.9 |  |
| Other charges, net (5) | (1.2) |  |  | 11.7 |  |  | 4.7 |  |  | 12.3 |  |  | 25.8 |  |
| Non-GAAP income tax reconciling adjustments | (237.2) |  |  | (3.2) |  |  | 126.5 |  |  | (226.9) |  |  | 135.7 |  |
| Net income (loss) on non-GAAP basis | $ | 63.3 |  |  | $ | 40.9 |  |  | $ | (8.9) |  |  | $ | 146.4 |  |  | $ | 29.8 |  |
| Net income (loss) per share on non-GAAP basis | $ | 0.88 |  |  | $ | 0.57 |  |  | $ | (0.13) |  |  | $ | 2.06 |  |  | $ | 0.44 |  |
| Shares used in per share calculation - diluted on GAAP basis | 72.0 |  |  | 69.3 |  |  | 67.8 |  |  | 69.6 |  |  | 67.3 |  |
| Non-GAAP adjustment (6) | — |  |  | 2.9 |  |  | — |  |  | 1.6 |  |  | 0.4 |  |
| Shares used in per share calculation - diluted on non-GAAP basis | 72.0 |  |  | 72.2 |  |  | 67.8 |  |  | 71.2 |  |  | 67.7 |  |

[0001628280-25-039896:8k_2_02:68]
(1) During the first quarter of fiscal year 2025, the Company refined its methodology to report non-GAAP financial measures. The change does not impact the Company’s financial position, cash flows, or GAAP consolidated results of operations. Prior period non-GAAP financial measures presented in this press release have been recast to conform to the current presentation.

[0001628280-25-039896:8k_2_02:69]
(2) Stock-based compensation for the twelve months ended June 28, 2025 includes $28.2 million of stock-based compensation expense resulting from equity award modifications for our former President and Chief Executive Officer (“CEO”), which include RSUs and PSUs that were immediately expensed as of the separation date.

[0001628280-25-039896:8k_2_02:70]
(3) Restructuring charges for the three months ended June 28, 2025 primarily relate to $3.0 million of employee severance, $2.2 million primarily related to write-off of right-of-use assets as well as charges for other contractual commitments associated with site closures.

[0001628280-25-039896:8k_2_02:71]
Restructuring charges for the twelve months ended June 28, 2025 include $14.6 million of assets written off, including property, plant and equipment, right-of-use assets, prepayments and other current assets as well as charges for other contractual commitments associated with site closures, and $4.3 million of employee severance primarily due to efforts to consolidate our sites and focus on other market opportunities, including cloud and AI markets. In addition, we also recorded $3.0 million of charges related to the discontinuation of our in-house development of coherent Digital Signal Processors (“DSPs”) and Radio Frequency Integrated Circuits (“RFICs”).

[0001628280-25-039896:8k_2_02:72]
(4) Gain on sale of facility for the twelve months ended June 28, 2025 represents a gain for net assets sold in an entity in Shenzhen, China, which consist primarily of building, building improvements and land rights.

[0001628280-25-039896:8k_2_02:73]
(5) Other charges, net for the three months ended June 28, 2025 mainly includes a credit of $5.2 million associated with indirect taxes reserve released due to the settlement of an audit, and a credit of $1.8 million related to units sold that were previously written down, offset by $5.7 million of legal and professional fees primarily related to non-ordinary course legal matters.

[0001628280-25-039896:8k_2_02:74]
Other charges, net for the twelve months ended June 28, 2025 mainly includes $12.2 million of legal and professional fees primarily related to non-ordinary course legal matters, $6.2 million of CEO transition costs, and $3.2 million of bad debt reserve related to the remaining unpaid balances due from Huawei associated with the trade restrictions, offset by a credit of $5.2 million associated with indirect taxes reserve released due to the settlement of an audit and a $5.0 million credit related to units sold that were previously written down.

[0001628280-25-039896:8k_2_02:75]
(6) The adjustment represents the dilutive impact of equity-based compensation awards in accordance with the treasury stock method and dilutive shares from our convertible debt instruments under the if-converted method.

[0001628280-25-039896:8k_2_02:76]
LUMENTUM HOLDINGS INC.

[0001628280-25-039896:8k_2_02:77]
RECONCILIATION OF GAAP NET INCOME (LOSS) TO ADJUSTED EBITDA

[0001628280-25-039896:8k_2_02:78]
(in millions, except per share data)

[0001628280-25-039896:8k_2_02:79]
(unaudited)

[0001628280-25-039896:8k_2_02:80]
|  | Three Months Ended |  | Twelve Months Ended |
|  | June 28, 2025 |  | March 29, 2025 |  | June 29, 2024 (1) |  | June 28, 2025 |  | June 29, 2024 (1) |
| GAAP net income (loss) | $ | 213.3 |  |  | $ | (44.1) |  |  | $ | (252.5) |  |  | $ | 25.9 |  |  | $ | (546.5) |  |
| Interest and other income, net | 3.0 |  |  | 1.5 |  |  | (5.9) |  |  | (8.0) |  |  | (28.3) |  |
| Income tax provision (benefit) | (224.7) |  |  | 4.9 |  |  | 125.0 |  |  | (198.0) |  |  | 140.8 |  |
| Depreciation | 26.4 |  |  | 25.0 |  |  | 28.2 |  |  | 104.3 |  |  | 110.6 |  |
| Amortization of acquired intangibles | 34.6 |  |  | 34.4 |  |  | 41.9 |  |  | 149.7 |  |  | 150.6 |  |
| EBITDA | 52.6 |  |  | 21.7 |  |  | (63.3) |  |  | 73.9 |  |  | (172.8) |  |
| Amortization of inventory fair value adjustments | — |  |  | — |  |  | — |  |  | — |  |  | 8.3 |  |
| Restructuring and related charges | 5.2 |  |  | 7.2 |  |  | 36.6 |  |  | 22.8 |  |  | 72.6 |  |
| Stock-based compensation | 40.0 |  |  | 62.8 |  |  | 30.5 |  |  | 177.2 |  |  | 128.8 |  |
| Acquisition related costs | 0.7 |  |  | 0.5 |  |  | (0.2) |  |  | 1.2 |  |  | 13.3 |  |
| Integration related costs | 1.3 |  |  | 1.4 |  |  | 4.1 |  |  | 9.2 |  |  | 27.0 |  |
| Intangible assets write-off | 0.1 |  |  | 0.7 |  | — |  |  | 2.7 |  |  | — |  |
| Gain on sale of facility | — |  |  | (34.9) |  |  | — |  |  | (34.9) |  |  | — |  |
| Other charges, net | (1.2) |  |  | 11.6 |  |  | 3.2 |  |  | 12.1 |  |  | 17.9 |  |
| Adjusted EBITDA | $ | 98.7 |  |  | $ | 71.0 |  |  | $ | 10.9 |  |  | $ | 264.2 |  |  | $ | 95.1 |  |

[0001628280-25-039896:8k_2_02:81]
(1) During the first quarter of fiscal year 2025, the Company refined its methodology to report non-GAAP financial measures. The change does not impact the Company’s financial position, cash flows, or GAAP consolidated results of operations. Prior period non-GAAP financial measures presented in this press release have been recast to conform to the current presentation.
