# LITE note change history — 0001633978-21-000009 → 0001628280-21-021632


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2021-11-04):
[0001628280-21-021632:note_history:1]
Purchase obligations of $260.4 million as of October 2, 2021, represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements.
  (was, 2021-05-12, similarity 0.9707):
[0001633978-21-000009:note_history:1]
Purchase obligations of $224.9 million as of April 3, 2021, represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements.

- changed (2021-11-04):
[0001628280-21-021632:note_history:2]
The following table presents the changes in our warranty reserve for the periods presented (in millions):
  (was, 2021-05-12, similarity 0.7449):
[0001633978-21-000009:note_history:2]
The following table presents the changes in our warranty reserve during the three and nine months ended April 3, 2021 and March 28, 2020 (in millions):

- added (2021-11-04):
[0001628280-21-021632:note_history:3]
|  | Three Months Ended |  |  |
|  | October 2, 2021 |  | September 26, 2020 |  |  |  |  |
| Balance as of beginning of period | $ | 5.0 |  |  | $ | 5.0 |  |  |  |  |  |
| Provision for warranty | 1.7 |  |  | 3.9 |  |  |  |  |  |
| Utilization of reserve | (1.6) |  |  | (1.3) |  |  |  |  |  |
| Balance as of end of period | $ | 5.1 |  |  | $ | 7.6 |  |  |  |  |  |

- changed (2021-11-04):
[0001628280-21-021632:note_history:4]
The remaining Lawsuit (the Karri Lawsuit) currently purports to seek, among other things, damages to be awarded to the plaintiff and any class, if a class is certified, and litigation costs, including attorneys’ fees.  A lead plaintiff and counsel has been selected, and an amended complaint was filed on April 15, 2019, which also names Lumentum as a defendant. A motion to dismiss the amended complaint was granted in part and denied in part by the court on October 8, 2020. On December 1, 2020, defendants answered the amended complaint.  On December 23, 2020, defendants filed a motion for leave to file a motion for reconsideration of the Court’s October 8th order on the motion to dismiss, which was denied on January 29, 2021. The Karri Lawsuit remains pending with the parties currently in discovery. Defendants intend to defend the Karri Lawsuit vigorously.
  (was, 2021-05-12, similarity 0.9988):
[0001633978-21-000009:note_history:4]
The remaining Lawsuit (the Karri Lawsuit) currently purports to seek, among other things, damages to be awarded to the plaintiff and any class, if a class is certified, and litigation costs, including attorneys’ fees.  A lead plaintiff and counsel has been selected, and an amended complaint was filed on April 15, 2019, which also names Lumentum as a defendant. A motion to dismiss the amended complaint was granted in part and denied in part by the court on October 8, 2020. On December 1, 2020, defendants answered the amended complaint.  On December 23, 2020, defendants filed a motion for leave to file a motion for reconsideration of the Court’s October 8 order on the motion to dismiss, which was denied on January 29, 2021. The Karri Lawsuit remains pending with the parties currently in discovery. Defendants intend to defend the Karri Lawsuit vigorously.

- changed (2021-11-04):
[0001628280-21-021632:note_history:5]
In the normal course of business, we enter into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown because claims may be made against us in the future and we may record charges in the future as a result of these indemnification obligations. As of October 2, 2021, we did not have any material indemnification claims that were probable or reasonably possible.
  (was, 2021-05-12, similarity 0.9868):
[0001633978-21-000009:note_history:5]
In the normal course of business, we enter into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown because claims may be made against us in the future and we may record charges in the future as a result of these indemnification obligations. As of April 3, 2021, we did not have any material indemnification claims that were probable or reasonably possible.

- removed (2021-11-04):
[0001633978-21-000009:note_history:6]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 3, 2021 |  | March 28, 2020 |  | April 3, 2021 |  | March 28, 2020 |
| Balance as of beginning of period | $ | 5.7 |  |  | $ | 6.8 |  |  | $ | 5.0 |  |  | $ | 7.5 |  |
| Provision for warranty | 1.7 |  |  | 0.7 |  |  | 5.8 |  |  | 2.5 |  |
| Utilization of reserve | (1.8) |  |  | (2.1) |  |  | (5.2) |  |  | (4.6) |  |
| Balance as of end of period | $ | 5.6 |  |  | $ | 5.4 |  |  | $ | 5.6 |  |  | $ | 5.4 |  |


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2021-11-04):
[0001628280-21-021632:note_history:7]
The accompanying condensed consolidated financial statements have been prepared in accordance with U.S. generally accepted accounting principles (“GAAP”), which requires management to make estimates and assumptions that affect the amounts reported in our condensed consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact us in the future, actual results may be different from the estimates. Operating results for the quarter ended October 2, 2021 are not necessarily indicative of the results that may be expected for the fiscal year ending July 2, 2022. In the opinion of the Company’s management, the information presented herein reflects all normal and recurring adjustments necessary for a fair presentation of our results of operations, financial position, stockholders’ equity and cash flows.

- added (2021-11-04):
[0001628280-21-021632:note_history:8]
Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are inventory valuation, revenue recognition, income taxes, long-lived asset valuation and goodwill.

- changed (2021-11-04):
[0001628280-21-021632:note_history:9]
The COVID-19 pandemic has created and may continue to create significant uncertainty in global financial markets, which has disrupted and harmed, and may continue to disrupt and harm, our business, financial condition, and results of operations. The extent of the impact of COVID-19 on our operational and financial performance will depend on certain developments, including but not limited to the duration and spread of the outbreak, duration of local, state and federal issued public health orders in each jurisdiction where we operate or in which our customers and suppliers operate, impact on our customers and our sales cycles, impact on our supply chain and manufacturing partners, impact on our employees and impact on regional and worldwide economies and financial markets in general, all of which are uncertain and cannot be predicted. We assessed the potential impact that this pandemic has on our estimates as of October 2, 2021 and determined that there were no material impacts.
  (was, 2021-05-12, similarity 0.9053):
[0001633978-21-000009:note_history:9]
The COVID-19 pandemic has created and may continue to create significant uncertainty in global financial markets, which has disrupted and harmed, and may continue to disrupt and harm, the Company's business, financial condition, and results of operations. The extent of the impact of COVID-19 on the Company's operational and financial performance will depend on certain developments, including but not limited to the duration and spread of the outbreak, duration of local, state and federal issued public health orders in each jurisdiction where we operate or in which our customers and suppliers operate, impact on our customers and our sales cycles, impact on our supply chain and manufacturing partners, impact on our employees and impact on regional and worldwide economies and financial markets in general, all of which are uncertain and cannot be predicted.

- changed (2021-11-04):
[0001628280-21-021632:note_history:10]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Every fifth or sixth fiscal year will have a 53-week period. The additional week in a 53-week year is added to the third quarter, making such quarter consist of 14 weeks. Our fiscal 2022 is a 52-week year ending on July 2, 2022, with the quarter ended October 2, 2021 being a 13-week quarterly period. Our fiscal 2021 was a 53-week year that ended on July 3, 2021, with the quarter ended September 26, 2020 being a 13-week quarterly period.
  (was, 2021-05-12, similarity 0.7391):
[0001633978-21-000009:note_history:10]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Every fifth or sixth fiscal year will have a 53-week period. The additional week in a 53-week year is added to the third quarter, making such quarter consist of 14 weeks. Our fiscal 2021 is a 53-week year ending on July 3, 2021, with the quarter ended April 3, 2021 being a 14-week quarterly period. Our fiscal 2020 was a 52-week year that ended on June 27, 2020, with the quarter ended March 28, 2020 being a 13-week quarterly period.

- changed (2021-11-04):
[0001628280-21-021632:note_history:11]
These interim unaudited condensed consolidated financial statements include the accounts of the Company and its wholly-owned subsidiaries. All inter-company transactions and balances are eliminated in consolidation. 
Accounting PoliciesThe condensed consolidated financial statements and accompanying related notes should be read in conjunction with the audited consolidated financial statements and related notes included in our Annual Report on Form 10-K for the fiscal year ended July 3, 2021. There have been no significant changes to our accounting policies during the three months ended October 2, 2021.
  (was, 2021-05-12, similarity 0.7003):
[0001633978-21-000009:note_history:11]
These interim unaudited condensed consolidated financial statements include the accounts of the Company and its wholly-owned subsidiaries. All inter-company transactions and balances have been eliminated in consolidation. 
Accounting PoliciesThe accompanying condensed consolidated financial statements and accompanying related notes should be read in conjunction with the audited consolidated financial statements and related notes included in our Annual Report on Form 10-K for the fiscal year ended June 27, 2020. There have been no significant changes to these policies during the nine months ended April 3, 2021, except for the removal of the long-lived asset valuation policy and the updates resulting from the adoption of Topic 326, as discussed in “Note 2. Recently Issued Accounting Pronouncements”.

- removed (2021-11-04):
[0001633978-21-000009:note_history:12]
The preparation of the condensed consolidated financial statements in accordance with U.S. generally accepted accounting principles (“GAAP”) requires management to make estimates and assumptions that affect the amounts reported in our condensed consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates. Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are inventory valuation, revenue recognition, income taxes, and goodwill.

- removed (2021-11-04):
[0001633978-21-000009:note_history:13]
Termination of Coherent Merger Agreement

- removed (2021-11-04):
[0001633978-21-000009:note_history:14]
On January 18, 2021, Lumentum and Coherent, Inc. (“Coherent”) entered into a merger agreement (the “merger agreement”), under which Lumentum would acquire all outstanding shares of Coherent common stock. As of the date of the merger agreement, the total transaction consideration was approximately $5.7 billion. In March 2021, Coherent terminated the merger agreement and paid Lumentum a termination fee of $217.6 million in accordance with the merger agreement. This gain was offset by $10.1 million of acquisition related expenses and the net amount is presented as “merger termination fee and related costs, net” in our condensed consolidated statements of operations for the three and nine months ended April 3, 2021.


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2021-11-04):
[0001628280-21-021632:note_history:15]
| Liability component: | October 2, 2021 |  | July 3, 2021 |
|  | 2024 Notes (1) |  | 2026 Notes (2) |  | 2024 Notes |  | 2026 Notes |
| Principal | $ | 450.0 |  |  | $ | 1,050.0 |  |  | $ | 450.0 |  |  | $ | 1,050.0 |  |
| Unamortized debt discount and issuance costs | (54.2) |  |  | (250.0) |  |  | (59.3) |  |  | (260.2) |  |
| Net carrying amount of the liability component | $ | 395.8 |  |  | $ | 800.0 |  |  | $ | 390.7 |  |  | $ | 789.8 |  |

- changed (2021-11-04):
[0001628280-21-021632:note_history:16]
(1) Since the closing price of our stock exceeded $78.80 (or 130% of the conversion price of $60.62) for 20 of the last 30 trading days of the first quarter of fiscal 2022, the 2024 Notes have become convertible at the option of the holders. Therefore, the debt component of our 2024 Notes as of October 2, 2021 has been classified as current liabilities in our condensed consolidated balance sheet.
  (was, 2021-05-12, similarity 0.9704):
[0001633978-21-000009:note_history:16]
(1) Since the closing price of our stock exceeded $78.80 (or 130% of the conversion price of $60.62) for 20 of the last 30 trading days of the third quarter of fiscal 2021, the 2024 Notes have become convertible at the option of the holders. Therefore, the debt component of our 2024 Notes as of April 3, 2021 has been classified as current liabilities in our condensed consolidated balance sheet.

- added (2021-11-04):
[0001628280-21-021632:note_history:17]
(2) If the closing price of our stock exceeds $129.08 (or 130% of the conversion price of $99.29) for 20 of the last 30 trading days of any future quarter, our 2026 Notes would also become convertible at the option of the holders and the debt component would be reclassified to current liabilities in our condensed consolidated balance sheet.

- removed (2021-11-04):
[0001633978-21-000009:note_history:18]
| Liability component: | April 3, 2021 |  | June 27, 2020 |
|  | 2024 Notes (1) |  | 2026 Notes |  | 2024 Notes (1) |  | 2026 Notes |
| Principal | $ | 450.0 |  |  | $ | 1,050.0 |  |  | $ | 450.0 |  |  | $ | 1,050.0 |  |
| Unamortized debt discount and debt issuance costs | (64.7) |  |  | (271.1) |  |  | (79.4) |  |  | (300.3) |  |
| Net carrying amount of the liability component | $ | 385.3 |  |  | $ | 778.9 |  |  | $ | 370.6 |  |  | $ | 749.7 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-11-04):
[0001628280-21-021632:note_history:19]
In December 2019, we issued $1,050.0 million in aggregate principal amount of 0.50% Convertible Notes due in 2026 (“the 2026 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act of 1933, as amended (the “Securities Act”). The 2026 Notes are governed by an indenture between the Company and U.S. Bank National Association (the “2026 Indenture”). We used approximately $196.0 million of the net proceeds of the offering to repay in full all amounts outstanding under our term loan credit facility, and a portion of the net proceeds of the offering to purchase approximately $200.0 million of our common stock concurrently with the pricing of the offering in privately negotiated transactions. The 2026 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.
  (was, 2021-05-12, similarity 0.9685):
[0001633978-21-000009:note_history:19]
In December 2019, we issued $1,050 million in aggregate principal amount of the 2026 Notes in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act of 1933, as amended (the “Securities Act”). The 2026 Notes are governed by an indenture between the Company and U.S. Bank National Association (the “2026 Indenture”). We used approximately $196 million of the net proceeds of the offering to repay in full all amounts outstanding under our term loan credit facility, and a portion of the net proceeds of the offering to purchase approximately $200 million of our common stock concurrently with the pricing of the offering in privately negotiated transactions. The 2026 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

- changed (2021-11-04):
[0001628280-21-021632:note_history:20]
The 2026 Notes bear interest at a rate of 0.50% per year, payable semi-annually in arrears on June 15 and December 15 of each year, beginning on June 15, 2020. The 2026 Notes will mature on December 15, 2026, unless earlier redeemed, repurchased by us, or converted pursuant to their terms.
  (was, 2021-05-12, similarity 0.9907):
[0001633978-21-000009:note_history:20]
The 2026 Notes will bear interest at a rate of 0.50% per year, payable semi-annually in arrears on June 15 and December 15 of each year, beginning on June 15, 2020. The 2026 Notes will mature on December 15, 2026, unless earlier redeemed, repurchased by us, or converted pursuant to their terms.

- changed (2021-11-04):
[0001628280-21-021632:note_history:21]
The initial conversion rate is 10.0711 shares of common stock per $1,000 principal amount of the 2026 Notes (which is equivalent to an initial conversion price of approximately $99.29 per share). The conversion rate is subject to adjustment upon the occurrence of certain specified events, but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert the 2026 Notes in connection with such make-whole fundamental change or notice of redemption.
  (was, 2021-05-12, similarity 0.9992):
[0001633978-21-000009:note_history:21]
The initial conversion rate is 10.0711 shares of common stock per $1,000 principal amount of the 2026 Notes (which is equivalent to an initial conversion price of approximately $99.29 per share). The conversion rate is subject to adjustment upon the occurrence of certain specified events but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert the 2026 Notes in connection with such make-whole fundamental change or notice of redemption.

- changed (2021-11-04):
[0001628280-21-021632:note_history:22]
Prior to the close of business on the business day immediately preceding September 15, 2026, holders of the 2026 Notes may convert their 2026 Notes only under certain circumstances discussed in detail in our Annual Report on Form 10-K for the year ended July 3, 2021.
  (was, 2021-05-12, similarity 0.9759):
[0001633978-21-000009:note_history:22]
Prior to the close of business on the business day immediately preceding September 15, 2026, holders of the 2026 Notes may convert their 2026 Notes only under certain circumstances discussed in detail in our Annual Report on Form 10-K for the year ended June 27, 2020.

- changed (2021-11-04):
[0001628280-21-021632:note_history:23]
In March 2017, we issued $450 million of 0.25% Convertible Notes due in 2024 (the “2024 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act. The 2024 Notes are governed by an indenture between the Company, as the issuer, and U.S. Bank National Association, as trustee (the “2024 Indenture”). The 2024 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.
  (was, 2021-05-12, similarity 0.9449):
[0001633978-21-000009:note_history:23]
In March 2017, we issued $450 million of the 2024 Notes in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act. The 2024 Notes are governed by an indenture between the Company, as the issuer, and U.S. Bank National Association, as trustee (the “2024 Indenture”). The 2024 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

- changed (2021-11-04):
[0001628280-21-021632:note_history:24]
The initial conversion rate of the 2024 Notes is 16.4965 shares of common stock per $1,000 principal amount of 2024 Notes, which is equivalent to an initial conversion price of approximately $60.62 per share, a 132.5% premium to the fair market value at the date of issuance. Prior to the close of business on the business day immediately preceding December 15, 2023, each holder of the 2024 Notes may convert their 2024 Notes only under certain circumstances discussed in detail in our Annual Report on Form 10-K for the year ended July 3, 2021.
  (was, 2021-05-12, similarity 0.9881):
[0001633978-21-000009:note_history:24]
The initial conversion rate of the 2024 Notes is 16.4965 shares of common stock per $1,000 principal amount of 2024 Notes, which is equivalent to an initial conversion price of approximately $60.62 per share, a 132.5% premium to the fair market value at the date of issuance. Prior to the close of business on the business day immediately preceding December 15, 2023, each holder of the 2024 Notes may convert their 2024 Notes only under certain circumstances discussed in detail in our Annual Report on Form 10-K for the year ended June 27, 2020.

- added (2021-11-04):
[0001628280-21-021632:note_history:25]
During the three months ended October 2, 2021, we received conversion requests for less than $0.1 million principal amount of the 2024 Notes, which were settled in cash in the first quarter of fiscal 2022.

- added (2021-11-04):
[0001628280-21-021632:note_history:26]
2024 and 2026 Notes

- added (2021-11-04):
[0001628280-21-021632:note_history:27]
| Liability component: | October 2, 2021 |  | July 3, 2021 |
|  | 2024 Notes (1) |  | 2026 Notes (2) |  | 2024 Notes |  | 2026 Notes |
| Principal | $ | 450.0 |  |  | $ | 1,050.0 |  |  | $ | 450.0 |  |  | $ | 1,050.0 |  |
| Unamortized debt discount and issuance costs | (54.2) |  |  | (250.0) |  |  | (59.3) |  |  | (260.2) |  |
| Net carrying amount of the liability component | $ | 395.8 |  |  | $ | 800.0 |  |  | $ | 390.7 |  |  | $ | 789.8 |  |

- changed (2021-11-04):
[0001628280-21-021632:note_history:28]
(1) Since the closing price of our stock exceeded $78.80 (or 130% of the conversion price of $60.62) for 20 of the last 30 trading days of the first quarter of fiscal 2022, the 2024 Notes have become convertible at the option of the holders. Therefore, the debt component of our 2024 Notes as of October 2, 2021 has been classified as current liabilities in our condensed consolidated balance sheet.
  (was, 2021-05-12, similarity 0.9704):
[0001633978-21-000009:note_history:28]
(1) Since the closing price of our stock exceeded $78.80 (or 130% of the conversion price of $60.62) for 20 of the last 30 trading days of the third quarter of fiscal 2021, the 2024 Notes have become convertible at the option of the holders. Therefore, the debt component of our 2024 Notes as of April 3, 2021 has been classified as current liabilities in our condensed consolidated balance sheet.

- changed (2021-11-04):
[0001628280-21-021632:note_history:29]
(2) If the closing price of our stock exceeds $129.08 (or 130% of the conversion price of $99.29) for 20 of the last 30 trading days of any future quarter, our 2026 Notes would also become convertible at the option of the holders and the debt component would be reclassified to current liabilities in our condensed consolidated balance sheet.
  (was, 2021-05-12, similarity 0.9938):
[0001633978-21-000009:note_history:29]
If the closing price of our stock exceeds $129.08 (or 130% of the conversion price of $99.29) for 20 of the last 30 trading days of any future quarter, our 2026 Notes would also become convertible at the option of the holders and the debt component would be reclassified to current liabilities in our condensed consolidated balance sheet.

- changed (2021-11-04):
[0001628280-21-021632:note_history:30]
|  | Three Months Ended |  |  |
|  | October 2, 2021 |  | September 26, 2020 |  |  |  |  |
| Contractual interest expense | $ | 1.6 |  |  | $ | 1.6 |  |  |  |  |  |
| Amortization of the debt discount and debt issuance costs | 15.3 |  |  | 14.4 |  |  |  |  |  |
| Total interest expense | $ | 16.9 |  |  | $ | 16.0 |  |  |  |  |  |
  (was, 2021-05-12, similarity 0.7276):
[0001633978-21-000009:note_history:30]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 3, 2021 |  | March 28, 2020 |  | April 3, 2021 |  | March 28, 2020 |
| Contractual interest expense | $ | 1.6 |  |  | $ | 1.6 |  |  | $ | 4.8 |  |  | $ | 2.3 |  |
| Amortization of the debt discount and debt issuance costs | 14.8 |  |  | 14.0 |  |  | 43.9 |  |  | 24.8 |  |
| Total interest expense | $ | 16.4 |  |  | $ | 15.6 |  |  | $ | 48.7 |  |  | $ | 27.1 |  |

- changed (2021-11-04):
[0001628280-21-021632:note_history:31]
The future interest and principal payments related to our convertible notes are as follows as of October 2, 2021 (in millions):
  (was, 2021-05-12, similarity 0.959):
[0001633978-21-000009:note_history:31]
The future interest and principal payments related to our convertible notes are as follows as of April 3, 2021 (in millions):

- changed (2021-11-04):
[0001628280-21-021632:note_history:32]
| Fiscal Years | 2024 Notes |  | 2026 Notes |  | Total |
| Remainder of 2022 | $ | 0.5 |  |  | $ | 5.3 |  |  | $ | 5.8 |  |
| 2023 | 1.1 |  |  | 5.3 |  |  | 6.4 |  |
| 2024 | 451.1 |  |  | 5.3 |  |  | 456.4 |  |
| 2025 | — |  |  | 5.3 |  |  | 5.3 |  |
| 2026 | — |  |  | 5.3 |  |  | 5.3 |  |
| Thereafter | — |  |  | 1,052.4 |  |  | 1,052.4 |  |
| Total convertible notes payments | $ | 452.7 |  |  | $ | 1,078.9 |  |  | $ | 1,531.6 |  |
  (was, 2021-05-12, similarity 0.7134):
[0001633978-21-000009:note_history:32]
| Fiscal Years | 2024 Notes |  | 2026 Notes |  | Total |
| Remainder of 2021 | $ | — |  |  | $ | 2.6 |  |  | $ | 2.6 |  |
| 2022 | 1.1 |  |  | 5.3 |  |  | 6.4 |  |
| 2023 | 1.1 |  |  | 5.3 |  |  | 6.4 |  |
| 2024 | 451.2 |  |  | 5.3 |  |  | 456.5 |  |
| 2025 | — |  |  | 5.3 |  |  | 5.3 |  |
| Thereafter | — |  |  | 1,057.7 |  |  | 1,057.7 |  |
| Total convertible notes payments | $ | 453.4 |  |  | $ | 1,081.5 |  |  | $ | 1,534.9 |  |

- added (2021-11-04):
[0001628280-21-021632:note_history:33]
The principal balances of our Notes are reflected in the payment periods in the table above based on their respective contractual maturities.

- removed (2021-11-04):
[0001633978-21-000009:note_history:34]
| Liability component: | April 3, 2021 |  | June 27, 2020 |
|  | 2024 Notes (1) |  | 2026 Notes |  | 2024 Notes (1) |  | 2026 Notes |
| Principal | $ | 450.0 |  |  | $ | 1,050.0 |  |  | $ | 450.0 |  |  | $ | 1,050.0 |  |
| Unamortized debt discount and debt issuance costs | (64.7) |  |  | (271.1) |  |  | (79.4) |  |  | (300.3) |  |
| Net carrying amount of the liability component | $ | 385.3 |  |  | $ | 778.9 |  |  | $ | 370.6 |  |  | $ | 749.7 |  |

- removed (2021-11-04):
[0001633978-21-000009:note_history:35]
The principal balances of our Notes are reflected in the payment periods in the table above based on their respective contractual maturities. During the three and nine months ended April 3, 2021, we received conversion requests for less than $0.1 million principal amount of the 2024 Notes, which will be settled in cash in the fourth quarter of fiscal 2021.

- removed (2021-11-04):
[0001633978-21-000009:note_history:36]
Term Loan Facility

- removed (2021-11-04):
[0001633978-21-000009:note_history:37]
In December 2018, concurrent with the closing of the Oclaro merger, we entered into a credit agreement providing for a term loan facility (the “Term Loan Facility”) in an aggregate principal amount of $500.0 million and we drew in full the term loans available under the Term Loan Facility on the closing date of the Oclaro merger. In the second quarter of fiscal 2020, we repaid, in full, all amounts outstanding under our Term Loan Facility. During the nine months ended March 28, 2020, we incurred $18.1 million of interest expense on this Term Loan Facility, which includes an $8.0 million loss on the early extinguishment of debt.

- removed (2021-11-04):
[0001633978-21-000009:note_history:38]
Other Interest Expense

- removed (2021-11-04):
[0001633978-21-000009:note_history:39]
For the nine months ended March 28, 2020, we also recorded $0.1 million interest expense related to our finance leases.


## us-gaap:DebtSecuritiesAvailableForSaleUnrealizedLossPositionFairValueTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-11-04):
[0001628280-21-021632:note_history:40]
The following table summarizes unrealized losses on our cash equivalents and short-term investments by category that have been in a continuous unrealized loss position for less than 12 months as of the periods presented (in millions):
  (was, 2021-05-12, similarity 0.862):
[0001633978-21-000009:note_history:40]
The following table summarizes unrealized losses on our cash equivalents and short-term investments by category and length of time the investment has been in a continuous unrealized loss position as of the periods presented (in millions):

- added (2021-11-04):
[0001628280-21-021632:note_history:41]
|  | Fair Value |  | Unrealized Losses |  |  |  |  |  |  |  |  |
| October 2, 2021: |  |  |  |  |  |  |  |  |  |  |  |
| Commercial paper | $ | 24.5 |  |  | $ | — |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 329.6 |  |  | (0.2) |  |  |  |  |  |  |  |  |  |
| Municipal bonds | 1.0 |  |  | — |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 338.2 |  |  | — |  |  |  |  |  |  |  |  |  |
| Total | $ | 693.3 |  |  | $ | (0.2) |  |  |  |  |  |  |  |  |  |
| July 3, 2021: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | 28.3 |  |  | $ | — |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | 6.0 |  |  | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | 43.0 |  |  | — |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 432.3 |  |  | (0.4) |  |  |  |  |  |  |  |  |  |
| Municipal bonds | 1.0 |  |  | — |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 106.9 |  |  | — |  |  |  |  |  |  |  |  |  |
| Total | $ | 617.5 |  |  | $ | (0.4) |  |  |  |  |  |  |  |  |  |

- removed (2021-11-04):
[0001633978-21-000009:note_history:42]
|  | Less than 12 months |  |  |  |  |
|  | Fair Value |  | Unrealized Losses |  |  |  |  |  |  |  |  |
| April 3, 2021: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | 34.4 |  |  | $ | — |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | 4.0 |  |  | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | 129.5 |  |  | — |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 310.4 |  |  | (0.3) |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 47.9 |  |  | — |  |  |  |  |  |  |  |  |  |
| Total | $ | 526.2 |  |  | $ | (0.3) |  |  |  |  |  |  |  |  |  |
| June 27, 2020: |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 3.1 |  |  | $ | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | 51.1 |  |  | — |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 96.5 |  |  | (0.1) |  |  |  |  |  |  |  |  |  |
| Foreign government bonds | 1.7 |  |  | — |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | 47.0 |  |  | — |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 159.8 |  |  | — |  |  |  |  |  |  |  |  |  |
| Total | $ | 359.2 |  |  | $ | (0.1) |  |  |  |  |  |  |  |  |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-11-04):
[0001628280-21-021632:note_history:43]
The future interest and principal payments related to our convertible notes are as follows as of October 2, 2021 (in millions):
  (was, 2021-05-12, similarity 0.959):
[0001633978-21-000009:note_history:43]
The future interest and principal payments related to our convertible notes are as follows as of April 3, 2021 (in millions):

- changed (2021-11-04):
[0001628280-21-021632:note_history:44]
| Fiscal Years | 2024 Notes |  | 2026 Notes |  | Total |
| Remainder of 2022 | $ | 0.5 |  |  | $ | 5.3 |  |  | $ | 5.8 |  |
| 2023 | 1.1 |  |  | 5.3 |  |  | 6.4 |  |
| 2024 | 451.1 |  |  | 5.3 |  |  | 456.4 |  |
| 2025 | — |  |  | 5.3 |  |  | 5.3 |  |
| 2026 | — |  |  | 5.3 |  |  | 5.3 |  |
| Thereafter | — |  |  | 1,052.4 |  |  | 1,052.4 |  |
| Total convertible notes payments | $ | 452.7 |  |  | $ | 1,078.9 |  |  | $ | 1,531.6 |  |
  (was, 2021-05-12, similarity 0.7134):
[0001633978-21-000009:note_history:44]
| Fiscal Years | 2024 Notes |  | 2026 Notes |  | Total |
| Remainder of 2021 | $ | — |  |  | $ | 2.6 |  |  | $ | 2.6 |  |
| 2022 | 1.1 |  |  | 5.3 |  |  | 6.4 |  |
| 2023 | 1.1 |  |  | 5.3 |  |  | 6.4 |  |
| 2024 | 451.2 |  |  | 5.3 |  |  | 456.5 |  |
| 2025 | — |  |  | 5.3 |  |  | 5.3 |  |
| Thereafter | — |  |  | 1,057.7 |  |  | 1,057.7 |  |
| Total convertible notes payments | $ | 453.4 |  |  | $ | 1,081.5 |  |  | $ | 1,534.9 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2021-11-04):
[0001628280-21-021632:note_history:45]
Note 16. Revenue Recognition

- added (2021-11-04):
[0001628280-21-021632:note_history:46]
Disaggregation of Revenue

- added (2021-11-04):
[0001628280-21-021632:note_history:47]
We disaggregate revenue by product and by geography. We do not present other levels of disaggregation, such as by type of products, customer, markets, contracts, duration of contracts, timing of transfer of control and sales channels, as this information is not used by our CODM to manage the business.

- added (2021-11-04):
[0001628280-21-021632:note_history:48]
The table below discloses our total net revenue attributable to each of our two reportable segments. In addition, the table sets forth the percentage of our total net revenue attributable to our product offerings which serve Telecom and Datacom, and Consumer and Industrial markets which accounted for 10% or more of our total net revenue during the periods presented (in millions, except percentage data):

- added (2021-11-04):
[0001628280-21-021632:note_history:49]
|  | Three Months Ended |  |  |
|  | October 2, 2021 |  | September 26, 2020 |  |  |  |  |
| OpComms: |  |  |  |  |  |  |  |  |  |  |  |
| Telecom and Datacom | $ | 216.0 |  | 48.2 | % |  | $ | 261.3 |  | 57.7 | % |  |  |  |  |  |  |
| Consumer and Industrial | 190.0 |  | 42.3 |  |  | 167.2 |  | 37.0 |  |  |  |  |  |  |  |
| Total OpComms | $ | 406.0 |  | 90.5 | % |  | $ | 428.5 |  | 94.7 | % |  |  |  |  |  |  |
| Lasers | 42.4 |  | 9.5 | % |  | 23.9 |  | 5.3 | % |  |  |  |  |  |  |
| Net Revenue | $ | 448.4 |  |  |  | $ | 452.4 |  |  |  |  |  |  |  |  |

- added (2021-11-04):
[0001628280-21-021632:note_history:50]
Contract Balances

- added (2021-11-04):
[0001628280-21-021632:note_history:51]
The following table reflects the changes in contract balances as of October 2, 2021 (in millions, except percentages):

- added (2021-11-04):
[0001628280-21-021632:note_history:52]
| Contract balances |  | Balance sheet location |  | October 2, 2021 |  | July 3, 2021 |  | Change |  | Percentage Change |
| Accounts receivable, net |  | Accounts receivable, net |  | $ | 263.2 |  |  | $ | 212.8 |  |  | $ | 50.4 |  |  | 23.7 | % |
| Deferred revenue and customer deposits |  | Other current liabilities |  | $ | — |  |  | $ | 0.6 |  |  | $ | (0.6) |  |  | (100.0) | % |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2021-11-04):
[0001628280-21-021632:note_history:53]
Subsequent Event
On November 4, 2021, Lumentum and NeoPhotonics Corporation (“NeoPhotonics”) announced a merger agreement (the “Merger Agreement”). Under the terms of the Merger Agreement, NeoPhotonics stockholders will receive $16.00 per share in cash for each NeoPhotonics share they own. This equates to a total transaction price of approximately $918 million. Lumentum will provide up to $50 million in interim debt financing to NeoPhotonics to help fund capital expenditures and increased working capital associated with NeoPhotonics’ growth plans. The cash consideration will be funded from the combined company’s balance sheet.

- added (2021-11-04):
[0001628280-21-021632:note_history:54]
The Merger Agreement contains certain termination rights for both Lumentum and NeoPhotonics and provides that upon termination of the Merger Agreement under specified circumstances (including termination by NeoPhotonics to accept a superior proposal), NeoPhotonics may be required to pay Lumentum a termination fee of $27.5 million. The Merger Agreement further provides that if the Merger Agreement is terminated for failure to obtain antitrust approval, Lumentum may be required to pay NeoPhotonics a termination fee of $55.1 million; and if Lumentum takes certain specified actions, (including entering into any definitive agreement for an acquisition by stock purchase, merger, consolidation, amalgamation, purchase of assets, license or otherwise of any ownership interest or assets of any Person) that cause a material delay in, or results in the failure of, the consummation of the Merger, Lumentum may be required to pay NeoPhotonics an additional termination fee of $36.7 million.
The Boards of Directors of Lumentum and NeoPhotonics have unanimously approved the transaction and the Merger Agreement. The transaction is subject to customary closing conditions, including the absence of certain legal impediments, the expiration or termination of the required waiting periods under the Hart-Scott-Rodino Antitrust Improvements Act of 1976, as amended, receipt of any required antitrust and regulatory approvals, and approval by the holders of a majority of the outstanding shares of NeoPhotonics common stock. The transaction is not subject to any financing condition. The transaction is expected to be completed in the second half of calendar year 2022.

- removed (2021-11-04):
[0001633978-21-000009:note_history:55]
Subsequent EventOn May 7, 2021, our board of directors approved the 2021 share buyback program, which authorizes us to use up to $700 million to purchase our own shares of common stock. The repurchase program is authorized for 2 years but may be suspended or terminated by the board of directors at any time.
