# LITE notes — 0001628280-21-021632


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001628280-21-021632:notes:1]
[same as prior period, unchanged from 0001633978-21-000009:notes:1]

[0001628280-21-021632:notes:2]
[same as prior period, unchanged from 0001633978-21-000009:notes:2]

[0001628280-21-021632:notes:3]
[same as prior period, unchanged from 0001633978-21-000009:notes:3]

[0001628280-21-021632:notes:4]
[same as prior period, unchanged from 0001633978-21-000009:notes:4]

[0001628280-21-021632:notes:5]
The accompanying condensed consolidated financial statements have been prepared in accordance with U.S. generally accepted accounting principles (“GAAP”), which requires management to make estimates and assumptions that affect the amounts reported in our condensed consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact us in the future, actual results may be different from the estimates. Operating results for the quarter ended October 2, 2021 are not necessarily indicative of the results that may be expected for the fiscal year ending July 2, 2022. In the opinion of the Company’s management, the information presented herein reflects all normal and recurring adjustments necessary for a fair presentation of our results of operations, financial position, stockholders’ equity and cash flows.

[0001628280-21-021632:notes:6]
Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are inventory valuation, revenue recognition, income taxes, long-lived asset valuation and goodwill.

[0001628280-21-021632:notes:7]
The COVID-19 pandemic has created and may continue to create significant uncertainty in global financial markets, which has disrupted and harmed, and may continue to disrupt and harm, our business, financial condition, and results of operations. The extent of the impact of COVID-19 on our operational and financial performance will depend on certain developments, including but not limited to the duration and spread of the outbreak, duration of local, state and federal issued public health orders in each jurisdiction where we operate or in which our customers and suppliers operate, impact on our customers and our sales cycles, impact on our supply chain and manufacturing partners, impact on our employees and impact on regional and worldwide economies and financial markets in general, all of which are uncertain and cannot be predicted. We assessed the potential impact that this pandemic has on our estimates as of October 2, 2021 and determined that there were no material impacts.

[0001628280-21-021632:notes:8]
[same as prior period, unchanged from 0001633978-21-000009:notes:9]

[0001628280-21-021632:notes:9]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Every fifth or sixth fiscal year will have a 53-week period. The additional week in a 53-week year is added to the third quarter, making such quarter consist of 14 weeks. Our fiscal 2022 is a 52-week year ending on July 2, 2022, with the quarter ended October 2, 2021 being a 13-week quarterly period. Our fiscal 2021 was a 53-week year that ended on July 3, 2021, with the quarter ended September 26, 2020 being a 13-week quarterly period.

[0001628280-21-021632:notes:10]
[same as prior period, unchanged from 0001633978-21-000009:notes:11]

[0001628280-21-021632:notes:11]
These interim unaudited condensed consolidated financial statements include the accounts of the Company and its wholly-owned subsidiaries. All inter-company transactions and balances are eliminated in consolidation. 
Accounting PoliciesThe condensed consolidated financial statements and accompanying related notes should be read in conjunction with the audited consolidated financial statements and related notes included in our Annual Report on Form 10-K for the fiscal year ended July 3, 2021. There have been no significant changes to our accounting policies during the three months ended October 2, 2021.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001628280-21-021632:notes:12]
Accounting PoliciesThe condensed consolidated financial statements and accompanying related notes should be read in conjunction with the audited consolidated financial statements and related notes included in our Annual Report on Form 10-K for the fiscal year ended July 3, 2021. 
Accounting Pronouncements Recently Adopted

[0001628280-21-021632:notes:13]
In December 2019, the Financial Accounting Standard Board (“FASB”) issued Accounting Standards Update (“ASU”) 2019-12, Simplifying the Accounting for Income Taxes (Topic 740), which is intended to simplify various aspects related to accounting for income taxes by removing certain exceptions to the general principles in Topic 740 and which also clarifies and amends existing guidance to improve consistent application. ASU 2019-12 is effective for us at the beginning of fiscal year 2022, including interim periods within that reporting period. We adopted ASU 2019-12 in our first quarter of fiscal year 2022 on a prospective basis with no material impact to our condensed consolidated financial statements.

[0001628280-21-021632:notes:14]
Accounting Pronouncements Not Yet Effective

[0001628280-21-021632:notes:15]
In August 2020, FASB issued ASU 2020-06, Debt—Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging—Contracts in Entity’s Own Equity (Subtopic 815-40): Accounting for Convertible Instruments and Contracts in an Entity’s Own Equity, which simplifies the accounting for convertible instruments by removing the separation models for (i) convertible debt with a cash conversion feature and (ii) convertible instruments with a beneficial conversion feature. As a result, a convertible debt instrument will be accounted for as a single liability measured at its amortized cost. Also, ASU 2020-06 requires the application of the if-converted method for calculating diluted earnings per share and the treasury stock method will be no longer available. The new guidance is effective for fiscal years beginning after December 15, 2021, with early adoption permitted no earlier than fiscal years beginning after December 15, 2020. ASU 2020-06 is effective for us in our first quarter of fiscal year 2023. We are currently evaluating the impact of ASU 2020-06 on our consolidated financial statements.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001628280-21-021632:notes:16]
Note 2. Recently Issued Accounting Pronouncements

[0001628280-21-021632:notes:17]
Accounting Pronouncements Recently Adopted


## us-gaap:EarningsPerShareTextBlock

[0001628280-21-021632:notes:18]
[same as prior period, unchanged from 0001633978-21-000009:notes:21]

[0001628280-21-021632:notes:19]
[same as prior period, unchanged from 0001633978-21-000009:notes:22]

[0001628280-21-021632:notes:20]
|  | Three Months Ended |  |  |
|  | October 2, 2021 |  | September 26, 2020 |  |  |  |  |  |
| Numerator: |  |  |  |  |  |  |  |  |
| Net income - basic and diluted | $ | 81.5 |  |  | $ | 67.1 |  |  |  |  |  |  |
| Denominator: |  |  |  |  |  |  |  |  |
| Weighted average common shares outstanding - basic | 72.7 |  |  | 75.3 |  |  |  |  |  |  |
| Effect of dilutive securities from stock-based benefit plans | 0.6 |  |  | 0.9 |  |  |  |  |  |  |
| Shares issuable assuming conversion of the 2024 Notes | 2.1 |  |  | 2.0 |  |  |  |  |  |  |
| Weighted average common shares outstanding - diluted | 75.4 |  |  | 78.2 |  |  |  |  |  |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic | $ | 1.12 |  |  | $ | 0.89 |  |  |  |  |  |  |
| Diluted | $ | 1.08 |  |  | $ | 0.86 |  |  |  |  |  |  |

[0001628280-21-021632:notes:21]
[same as prior period, unchanged from 0001633978-21-000009:notes:24]

[0001628280-21-021632:notes:22]
We have the ability and intent to settle the face value of our convertible notes in cash. Therefore, we use the treasury stock method for calculating the dilutive impact of the convertible notes.

[0001628280-21-021632:notes:23]
•The 2026 Notes (as defined in Note 9) will have no impact on diluted earnings per share until the average price of our common stock exceeds the conversion price of $99.29.

[0001628280-21-021632:notes:24]
•The potentially dilutive shares resulting from the 2024 Notes (as defined in Note 9) were included in the calculation of diluted income per share for the three months ended October 2, 2021 and September 26, 2020, respectively, since the average price of our common stock exceeded the conversion price of $60.62 in both periods.

[0001628280-21-021632:notes:25]
Anti-dilutive potential shares are excluded from the calculation of diluted earnings per share if their exercise price exceeded the average market price during the period or the share-based awards were determined to be anti-dilutive based on applying the treasury stock method. Anti-dilutive shares excluded from the calculation of diluted earnings per share were 0.4 million and 0.5 million shares for the three months ended October 2, 2021 and September 26, 2020, respectively.


## us-gaap:CashCashEquivalentsAndShortTermInvestmentsTextBlock

[0001628280-21-021632:notes:26]
[same as prior period, unchanged from 0001633978-21-000009:notes:27]

[0001628280-21-021632:notes:27]
[same as prior period, unchanged from 0001633978-21-000009:notes:28]

[0001628280-21-021632:notes:28]
|  | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| October 2, 2021: |  |  |  |  |  |  |  |
| Cash | $ | 196.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 196.1 |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Money market funds | 204.7 |  |  | — |  |  | — |  |  | 204.7 |  |
| U.S. Treasury securities | 210.2 |  |  | — |  |  | — |  |  | 210.2 |  |
| Total cash and cash equivalents | $ | 611.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 611.0 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 28.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 28.5 |  |
| Commercial paper | 124.8 |  |  | — |  |  | — |  |  | 124.8 |  |
| Corporate debt securities | 671.3 |  |  | 0.3 |  |  | (0.2) |  |  | 671.4 |  |
| Municipal bonds | 2.0 |  |  | — |  |  | — |  |  | 2.0 |  |
| U.S. Agency securities | 28.2 |  |  | — |  |  | — |  |  | 28.2 |  |
| U.S. Treasury securities | 418.6 |  |  | 0.1 |  |  | — |  |  | 418.7 |  |
| Total short-term investments | $ | 1,273.4 |  |  | $ | 0.4 |  |  | $ | (0.2) |  |  | $ | 1,273.6 |  |
| July 3, 2021: |  |  |  |  |  |  |  |
| Cash | $ | 128.3 |  |  | $ | — |  |  | $ | — |  |  | $ | 128.3 |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | 7.5 |  |  | — |  |  | — |  |  | 7.5 |  |
| Corporate debt securities | 7.0 |  |  | — |  |  | — |  |  | 7.0 |  |
| Money market funds | 631.5 |  |  | — |  |  | — |  |  | 631.5 |  |
| Total cash and cash equivalents | $ | 774.3 |  |  | $ | — |  |  | $ | — |  |  | $ | 774.3 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 28.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 28.5 |  |
| Commercial paper | 136.7 |  |  | — |  |  | — |  |  | 136.7 |  |
| Corporate debt securities | 626.0 |  |  | 0.3 |  |  | (0.4) |  |  | 625.9 |  |
| Municipal bonds | 1.0 |  |  | — |  |  | — |  |  | 1.0 |  |
| U.S. Agency securities | 29.3 |  |  | — |  |  | — |  |  | 29.3 |  |
| U.S. Treasury securities | 350.3 |  |  | — |  |  | — |  |  | 350.3 |  |
| Total short-term investments | $ | 1,171.8 |  |  | $ | 0.3 |  |  | $ | (0.4) |  |  | $ | 1,171.7 |  |

[0001628280-21-021632:notes:29]
We use the specific-identification method to determine any realized gains or losses from the sale of our short-term investments classified as available-for-sale. During the three months ended October 2, 2021 and September 26, 2020, we did not realize significant gains or losses on a gross level from the sale of our short-term investments classified as available-for-sale.

[0001628280-21-021632:notes:30]
During the three months ended October 2, 2021 and September 26, 2020, our other income (expense), net was $0.6 million and $0.6 million, respectively, which includes interest and investment income on cash equivalents and short-term investments of $0.6 million and $2.4 million, respectively. As of October 2, 2021 and July 3, 2021, we recorded interest receivable of $4.1 million and $4.1 million, respectively, in prepayments and other current assets within the Consolidated Balance Sheets. We did not recognize an allowance for credit losses against interest receivables in any of the periods presented as there were no such losses.

[0001628280-21-021632:notes:31]
As of October 2, 2021 and July 3, 2021, the Company does not have any cash equivalents and short-term investments that have been in a continuous unrealized gain or loss position for more than 12 months as of the periods presented. The following table summarizes unrealized losses on our cash equivalents and short-term investments by category that have been in a continuous unrealized loss position for less than 12 months as of the periods presented (in millions):

[0001628280-21-021632:notes:32]
|  | Fair Value |  | Unrealized Losses |  |  |  |  |  |  |  |  |
| October 2, 2021: |  |  |  |  |  |  |  |  |  |  |  |
| Commercial paper | $ | 24.5 |  |  | $ | — |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 329.6 |  |  | (0.2) |  |  |  |  |  |  |  |  |  |
| Municipal bonds | 1.0 |  |  | — |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 338.2 |  |  | — |  |  |  |  |  |  |  |  |  |
| Total | $ | 693.3 |  |  | $ | (0.2) |  |  |  |  |  |  |  |  |  |
| July 3, 2021: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | 28.3 |  |  | $ | — |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | 6.0 |  |  | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | 43.0 |  |  | — |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 432.3 |  |  | (0.4) |  |  |  |  |  |  |  |  |  |
| Municipal bonds | 1.0 |  |  | — |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 106.9 |  |  | — |  |  |  |  |  |  |  |  |  |
| Total | $ | 617.5 |  |  | $ | (0.4) |  |  |  |  |  |  |  |  |  |

[0001628280-21-021632:notes:33]
[same as prior period, unchanged from 0001633978-21-000009:notes:36]

[0001628280-21-021632:notes:34]
|  | October 2, 2021 |  | July 3, 2021 |
|  | Amortized Cost |  | Fair Value |  | Amortized Cost |  | Fair Value |
| Due in 1 year | $ | 714.3 |  |  | $ | 714.5 |  |  | $ | 587.0 |  |  | $ | 587.1 |  |
| Due in 1 year through 5 years | 559.1 |  |  | 559.1 |  |  | 584.8 |  |  | 584.6 |  |
|  | $ | 1,273.4 |  |  | $ | 1,273.6 |  |  | $ | 1,171.8 |  |  | $ | 1,171.7 |  |

[0001628280-21-021632:notes:35]
[same as prior period, unchanged from 0001633978-21-000009:notes:38]


## us-gaap:FairValueDisclosuresTextBlock

[0001628280-21-021632:notes:36]
[same as prior period, unchanged from 0001633978-21-000009:notes:39]

[0001628280-21-021632:notes:37]
[same as prior period, unchanged from 0001633978-21-000009:notes:40]

[0001628280-21-021632:notes:38]
[same as prior period, unchanged from 0001633978-21-000009:notes:41]

[0001628280-21-021632:notes:39]
[same as prior period, unchanged from 0001633978-21-000009:notes:42]

[0001628280-21-021632:notes:40]
[same as prior period, unchanged from 0001633978-21-000009:notes:43]

[0001628280-21-021632:notes:41]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| October 2, 2021: (1) |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Money market funds | $ | 204.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 204.7 |  |
| U.S. Treasury securities | 210.2 |  |  | — |  |  | — |  |  | 210.2 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | 28.5 |  |  | — |  |  | 28.5 |  |
| Commercial paper | — |  |  | 124.8 |  |  | — |  |  | 124.8 |  |
| Asset-backed securities | — |  |  | — |  |  | — |  |  | — |  |
| Corporate debt securities | — |  |  | 671.4 |  |  | — |  |  | 671.4 |  |
| Municipal bonds | — |  |  | 2.0 |  |  | — |  |  | 2.0 |  |
| Mortgage-backed securities | — |  |  | — |  |  | — |  |  | — |  |
| Foreign government bonds | — |  |  | — |  |  | — |  |  | — |  |
| U.S. Agency securities | — |  |  | 28.2 |  |  | — |  |  | 28.2 |  |
| U.S. Treasury securities | 418.7 |  |  | — |  |  | — |  |  | 418.7 |  |
| Total assets | $ | 833.6 |  |  | $ | 854.9 |  |  | $ | — |  |  | $ | 1,688.5 |  |

[0001628280-21-021632:notes:42]
(1)  Excludes $196.1 million in cash held in our bank accounts as of October 2, 2021.

[0001628280-21-021632:notes:43]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| July 3, 2021: (1) |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | — |  |  | $ | 7.5 |  |  | $ | — |  |  | $ | 7.5 |  |
| Corporate debt securities | — |  |  | 7.0 |  |  | — |  |  | 7.0 |  |
| Money market funds | 631.5 |  |  | — |  |  | — |  |  | 631.5 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | 28.5 |  |  | — |  |  | 28.5 |  |
| Commercial paper | — |  |  | 136.7 |  |  | — |  |  | 136.7 |  |
| Corporate debt securities | — |  |  | 625.9 |  |  | — |  |  | 625.9 |  |
| Municipal bonds | — |  |  | 1.0 |  |  | — |  |  | 1.0 |  |
| U.S. Agency securities | — |  |  | 29.3 |  |  | — |  |  | 29.3 |  |
| U.S. Treasury securities | 350.3 |  |  | — |  |  | — |  |  | 350.3 |  |
| Total assets | $ | 981.8 |  |  | $ | 835.9 |  |  | $ | — |  |  | $ | 1,817.7 |  |

[0001628280-21-021632:notes:44]
(1)  Excludes $128.3 million in cash held in our bank accounts as of July 3, 2021.

[0001628280-21-021632:notes:45]
[same as prior period, unchanged from 0001633978-21-000009:notes:48]

[0001628280-21-021632:notes:46]
[same as prior period, unchanged from 0001633978-21-000009:notes:49]

[0001628280-21-021632:notes:47]
[same as prior period, unchanged from 0001633978-21-000009:notes:50]

[0001628280-21-021632:notes:48]
|  | October 2, 2021 |  | July 3, 2021 |
|  | Carrying Amount |  | Estimated Fair Value |  | Carrying Amount |  | Estimated Fair Value |
| 2026 Notes | 800.0 |  |  | $ | 1,151.3 |  |  | $ | 789.8 |  |  | $ | 1,146.1 |  |
| 2024 Notes | 395.8 |  |  | 670.8 |  |  | 390.7 |  |  | 669.3 |  |
|  | $ | 1,195.8 |  |  | $ | 1,822.1 |  |  | $ | 1,180.5 |  |  | $ | 1,815.4 |  |

[0001628280-21-021632:notes:49]
[same as prior period, unchanged from 0001633978-21-000009:notes:52]

[0001628280-21-021632:notes:50]
[same as prior period, unchanged from 0001633978-21-000009:notes:53]

[0001628280-21-021632:notes:51]
Management utilizes various valuation methods, including an income approach, a market approach and a cost approach, to estimate the fair value of intangibles and other long-lived assets. During the annual impairment testing performed in the fourth quarter of fiscal 2021, we concluded that our intangible and other long-lived assets were not impaired. We review our intangible and other long-lived assets for impairment at least annually in the fourth quarter of each fiscal year, absent any interim indicators of impairment.


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0001628280-21-021632:notes:52]
[same as prior period, unchanged from 0001633978-21-000009:notes:55]


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001628280-21-021632:notes:53]
[same as prior period, unchanged from 0001633978-21-000009:notes:56]

[0001628280-21-021632:notes:54]
[same as prior period, unchanged from 0001633978-21-000009:notes:57]

[0001628280-21-021632:notes:55]
We did not have any allowance for credit losses other than our allowance for uncollectible accounts receivable. As of October 2, 2021 and July 3, 2021, the allowance for credit losses on our trade receivables was $0.3 million and $0.4 million, respectively.

[0001628280-21-021632:notes:56]
[same as prior period, unchanged from 0001633978-21-000009:notes:59]

[0001628280-21-021632:notes:57]
[same as prior period, unchanged from 0001633978-21-000009:notes:60]

[0001628280-21-021632:notes:58]
|  | October 2, 2021 |  | July 3, 2021 |
| Raw materials and purchased parts | $ | 64.5 |  |  | $ | 64.4 |  |
| Work in process | 85.4 |  |  | 79.0 |  |
| Finished goods | 57.1 |  |  | 53.0 |  |
| Inventories | $ | 207.0 |  |  | $ | 196.4 |  |

[0001628280-21-021632:notes:59]
[same as prior period, unchanged from 0001633978-21-000009:notes:62]

[0001628280-21-021632:notes:60]
[same as prior period, unchanged from 0001633978-21-000009:notes:63]

[0001628280-21-021632:notes:61]
|  | October 2, 2021 |  | July 3, 2021 |
| Operating lease right-of-use assets | $ | 97.8 |  |  | $ | 87.3 |  |
| Less: accumulated amortization | (22.6) |  |  | (19.9) |  |
| Operating lease right-of-use assets, net | $ | 75.2 |  |  | $ | 67.4 |  |

[0001628280-21-021632:notes:62]
[same as prior period, unchanged from 0001633978-21-000009:notes:65]

[0001628280-21-021632:notes:63]
[same as prior period, unchanged from 0001633978-21-000009:notes:66]

[0001628280-21-021632:notes:64]
|  | October 2, 2021 |  | July 3, 2021 |
| Land | $ | 40.9 |  |  | $ | 38.2 |  |
| Buildings and improvement | 93.6 |  |  | 92.7 |  |
| Machinery and equipment | 501.2 |  |  | 498.3 |  |
| Computer equipment and software | 29.5 |  |  | 28.6 |  |
| Furniture and fixtures | 8.8 |  |  | 8.8 |  |
| Leasehold improvements | 34.0 |  |  | 33.9 |  |
| Finance lease right-of-use assets | 28.1 |  |  | 28.1 |  |
| Construction in progress | 39.5 |  |  | 43.4 |  |
|  | 775.6 |  |  | 772.0 |  |
| Less: Accumulated depreciation | (422.4) |  |  | (410.9) |  |
| Property, plant and equipment, net | $ | 353.2 |  |  | $ | 361.1 |  |

[0001628280-21-021632:notes:65]
During the three months ended October 2, 2021 and September 26, 2020, we recorded depreciation expense of $20.4 million and $23.8 million, respectively.

[0001628280-21-021632:notes:66]
[same as prior period, unchanged from 0001633978-21-000009:notes:69]

[0001628280-21-021632:notes:67]
[same as prior period, unchanged from 0001633978-21-000009:notes:70]

[0001628280-21-021632:notes:68]
[same as prior period, unchanged from 0001633978-21-000009:notes:71]

[0001628280-21-021632:notes:69]
|  | October 2, 2021 |  | July 3, 2021 |
| Restructuring accrual and related charges (1) | $ | 0.8 |  |  | $ | 5.7 |  |
| Warranty accrual (2) | 5.1 |  |  | 5.0 |  |
| Deferred revenue and customer deposits | — |  |  | 0.6 |  |
| Income tax payable (3) | 9.4 |  |  | 43.5 |  |
| Other current liabilities | 4.0 |  |  | 3.0 |  |
| Other current liabilities | $ | 19.3 |  |  | $ | 57.8 |  |

[0001628280-21-021632:notes:70]
[same as prior period, unchanged from 0001633978-21-000009:notes:73]

[0001628280-21-021632:notes:71]
(2) Refer to “Note 14. Commitments and Contingencies.”

[0001628280-21-021632:notes:72]
(3)  Refer to “Note 12. Income Taxes.” The decrease in income tax payable as of October 2, 2021 is primarily due to $36.3 million of  income tax payment made during the first fiscal quarter of 2022.

[0001628280-21-021632:notes:73]
[same as prior period, unchanged from 0001633978-21-000009:notes:76]

[0001628280-21-021632:notes:74]
[same as prior period, unchanged from 0001633978-21-000009:notes:77]

[0001628280-21-021632:notes:75]
|  | October 2, 2021 |  | July 3, 2021 |
| Asset retirement obligations | $ | 4.7 |  |  | $ | 4.7 |  |
| Pension and related accrual (1) | 11.2 |  |  | 10.8 |  |
| Unrecognized tax benefit | 24.7 |  |  | 23.0 |  |
| Other non-current liabilities | 2.3 |  |  | 2.4 |  |
| Other non-current liabilities | $ | 42.9 |  |  | $ | 40.9 |  |

[0001628280-21-021632:notes:76]
(1) We have defined benefit pension plans in Japan, Switzerland, and Thailand. As of October 2, 2021, the projected benefit obligations, net of plan assets, in Japan, Switzerland and Thailand were $3.0 million, $5.1 million and $3.1 million, respectively. As of July 3, 2021, the projected benefit obligations, net of plan assets, in Japan, Switzerland and Thailand were $2.9 million, $4.8 million and $3.1 million, respectively. We typically re-evaluate the assumptions related to the fair value of our defined benefit obligations annually and make changes as necessary.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001628280-21-021632:notes:77]
Note 7. Leases

[0001628280-21-021632:notes:78]
We lease certain real and personal property from unrelated third parties under non-cancellable operating leases that expire at various dates through fiscal 2033. These operating leases are mainly for administrative offices, research-and-development and manufacturing facilities, as well as sales offices in various countries around the world. Certain leases require us to pay property taxes, insurance and routine maintenance, and include escalation clauses. Many leases include one or more options to renew. We do not assume renewals in our determination of the lease term unless the renewals are deemed to be reasonably certain at lease commencement.

[0001628280-21-021632:notes:79]
As of October 2, 2021, we sublease certain floors of our offices in the United Kingdom, the United States, Canada and Japan. These subleases will expire at various dates by fiscal year 2023. We anticipate receiving approximately $2.8 million in sublease income over the next two years.

[0001628280-21-021632:notes:80]
The components of lease costs, lease term and discount rate are as follows:

[0001628280-21-021632:notes:81]
|  | Three Months Ended |  |  |
|  | October 2, 2021 |  | September 26, 2020 |  |  |  |  |
| (in millions, except for weighted average data) |  |  |  |  |  |  |  |
| Finance lease cost | $ | — |  |  | $ | 0.2 |  |  |  |  |  |
| Operating lease cost | 3.4 |  |  | 3.6 |  |  |  |  |  |
| Variable lease cost | 0.4 |  |  | 0.4 |  |  |  |  |  |
| Short-term lease cost | 0.1 |  |  | 0.7 |  |  |  |  |  |
| Sublease income | (0.8) |  |  | (0.7) |  |  |  |  |  |
| Total lease cost | $ | 3.1 |  |  | $ | 4.2 |  |  |  |  |  |
| Weighted average remaining lease term (in years): |  |  |  |  |  |  |  |
| Operating leases | 7.6 |  | 8.2 |  |  |  |  |
| Finance leases | — |  |  | 0.8 |  |  |  |  |
| Weighted average discount rate (in percentages): |  |  |  |  |  |  |  |
| Operating leases | 3.2 | % |  | 3.5 | % |  |  |  |  |
| Finance leases | N/A |  | 4.4 | % |  |  |  |  |

[0001628280-21-021632:notes:82]
As of October 2, 2021, maturities of our operating lease liabilities, which do not include short-term leases and variable lease payments, were as follows (in millions):

[0001628280-21-021632:notes:83]
| Fiscal Years |  | Operating Leases (1) |  |  |  |  |
| Remainder of 2022 |  | $ | 10.3 |  |  |  |  |  |
| 2023 |  | 12.6 |  |  |  |  |  |
| 2024 |  | 11.9 |  |  |  |  |  |
| 2025 |  | 9.0 |  |  |  |  |  |
| 2026 |  | 8.0 |  |  |  |  |  |
| Thereafter |  | 26.0 |  |  |  |  |  |
| Total minimum lease payments |  | $ | 77.8 |  |  |  |  |  |
| Less: amount representing interest |  | (8.6) |  |  |  |  |  |
| Present value of total lease liabilities |  | $ | 69.2 |  |  |  |  |  |

[0001628280-21-021632:notes:84]
(1) Non-cancellable sublease proceeds for fiscal 2022 and 2023 of $2.4 million and $0.4 million, respectively, are not included in the table above.

[0001628280-21-021632:notes:85]
As of October 2, 2021, finance lease assets are fully amortized and there are no outstanding finance lease liabilities.


## us-gaap:GoodwillDisclosureTextBlock

[0001628280-21-021632:notes:86]
[same as prior period, unchanged from 0001633978-21-000009:notes:88]

[0001628280-21-021632:notes:87]
[same as prior period, unchanged from 0001633978-21-000009:notes:89]

[0001628280-21-021632:notes:88]
The following table presents our goodwill balance by reportable segments as of October 2, 2021 and July 3, 2021 (in millions):

[0001628280-21-021632:notes:89]
|  | Optical Communications |  | Commercial Lasers |  | Total |
| Balance as of October 2, 2021 and July 3, 2021 | $ | 363.5 |  |  | $ | 5.4 |  |  | $ | 368.9 |  |

[0001628280-21-021632:notes:90]
[same as prior period, unchanged from 0001633978-21-000009:notes:92]

[0001628280-21-021632:notes:91]
We review goodwill for impairment during the fourth quarter of each fiscal year or more frequently if events or circumstances indicate that an impairment loss may have occurred. In the fourth quarter of fiscal 2021, we completed the annual impairment test of goodwill, which indicated there was no goodwill impairment. There were no indicators of goodwill impairment during the three months ended October 2, 2021.

[0001628280-21-021632:notes:92]
[same as prior period, unchanged from 0001633978-21-000009:notes:94]

[0001628280-21-021632:notes:93]
The intangible assets are amortized on a straight-line basis over the estimated useful lives, except for customer relationships and order backlog, which are amortized using an accelerated method of amortization over the expected customer lives, which more accurately reflects the pattern of realization of economic benefits expected to be obtained. Acquired developed technologies and order backlog are amortized to cost of sales and customer relationships is amortized to selling, general and administrative.

[0001628280-21-021632:notes:94]
In-process research and development (“IPR&D”) is initially capitalized at fair value as an intangible asset with an indefinite life and assessed for impairment thereafter. When an IPR&D project is completed, the IPR&D is reclassified as an amortizable purchased intangible asset and amortized over the asset’s estimated useful life.  During the year ended July 3, 2021, we completed our remaining IPR&D projects and therefore reclassified $10.0 million from IPR&D to acquired developed technologies. This amount will be amortized over the assets’ estimated useful life of 3 years.

[0001628280-21-021632:notes:95]
[same as prior period, unchanged from 0001633978-21-000009:notes:96]

[0001628280-21-021632:notes:96]
| October 2, 2021 | Gross Carrying Amounts |  | Accumulated Amortization |  | Net Carrying Amounts |  | Weighted average remaining amortization period (years) |
| Acquired developed technologies | $ | 390.3 |  |  | $ | (254.9) |  |  | $ | 135.4 |  |  | 2.8 |
| Customer relationships | 145.0 |  |  | (60.6) |  |  | 84.4 |  |  | 5.2 |
| Order backlog | 22.0 |  |  | (22.0) |  |  | — |  |  | — |
| Other intangibles | 2.7 |  |  | (2.7) |  |  | — |  |  | — |
| Total intangible assets | $ | 560.0 |  |  | $ | (340.2) |  |  | $ | 219.8 |  |  |  |

[0001628280-21-021632:notes:97]
| July 3, 2021 | Gross Carrying Amounts |  | Accumulated Amortization |  | Net Carrying Amounts |  | Weighted average remaining amortization period (years) |
| Acquired developed technologies | $ | 390.3 |  |  | $ | (238.6) |  |  | $ | 151.7 |  |  | 3.0 |
| Customer relationships | 145.0 |  |  | (55.5) |  |  | 89.5 |  |  | 5.4 |
| Order backlog | 22.0 |  |  | (22.0) |  |  | — |  |  | — |
| Other intangibles | 2.7 |  |  | (2.7) |  |  | — |  |  | — |
| Total intangible assets | $ | 560.0 |  |  | $ | (318.8) |  |  | $ | 241.2 |  |  |  |

[0001628280-21-021632:notes:98]
[same as prior period, unchanged from 0001633978-21-000009:notes:102]

[0001628280-21-021632:notes:99]
|  | Three Months Ended |  |  |
|  | October 2, 2021 |  | September 26, 2020 |  |  |  |  |
| Cost of sales | $ | 15.8 |  |  | $ | 15.0 |  |  |  |  |  |
| Selling, general and administrative | 5.6 |  |  | 5.7 |  |  |  |  |  |
| Total amortization of intangibles | $ | 21.4 |  |  | $ | 20.7 |  |  |  |  |  |

[0001628280-21-021632:notes:100]
Based on the carrying amount of our acquired developed technologies and other intangibles as of October 2, 2021, and assuming no future impairment of the underlying assets, the estimated future amortization is as follows (in millions):

[0001628280-21-021632:notes:101]
| Fiscal Years |  |
| Remainder of 2022 | $ | 63.9 |  |
| 2023 | 61.9 |  |
| 2024 | 40.5 |  |
| 2025 | 27.7 |  |
| 2026 | 18.1 |  |
| Thereafter | 7.7 |  |
| Total future amortization | $ | 219.8 |  |


## us-gaap:DebtDisclosureTextBlock

[0001628280-21-021632:notes:102]
Note 9. Debt

[0001628280-21-021632:notes:103]
Convertible Notes

[0001628280-21-021632:notes:104]
2026 Notes

[0001628280-21-021632:notes:105]
In December 2019, we issued $1,050.0 million in aggregate principal amount of 0.50% Convertible Notes due in 2026 (“the 2026 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act of 1933, as amended (the “Securities Act”). The 2026 Notes are governed by an indenture between the Company and U.S. Bank National Association (the “2026 Indenture”). We used approximately $196.0 million of the net proceeds of the offering to repay in full all amounts outstanding under our term loan credit facility, and a portion of the net proceeds of the offering to purchase approximately $200.0 million of our common stock concurrently with the pricing of the offering in privately negotiated transactions. The 2026 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001628280-21-021632:notes:106]
The 2026 Notes bear interest at a rate of 0.50% per year, payable semi-annually in arrears on June 15 and December 15 of each year, beginning on June 15, 2020. The 2026 Notes will mature on December 15, 2026, unless earlier redeemed, repurchased by us, or converted pursuant to their terms.

[0001628280-21-021632:notes:107]
The initial conversion rate is 10.0711 shares of common stock per $1,000 principal amount of the 2026 Notes (which is equivalent to an initial conversion price of approximately $99.29 per share). The conversion rate is subject to adjustment upon the occurrence of certain specified events, but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert the 2026 Notes in connection with such make-whole fundamental change or notice of redemption.

[0001628280-21-021632:notes:108]
Prior to the close of business on the business day immediately preceding September 15, 2026, holders of the 2026 Notes may convert their 2026 Notes only under certain circumstances discussed in detail in our Annual Report on Form 10-K for the year ended July 3, 2021.

[0001628280-21-021632:notes:109]
2024 Notes

[0001628280-21-021632:notes:110]
In March 2017, we issued $450 million of 0.25% Convertible Notes due in 2024 (the “2024 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act. The 2024 Notes are governed by an indenture between the Company, as the issuer, and U.S. Bank National Association, as trustee (the “2024 Indenture”). The 2024 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001628280-21-021632:notes:111]
The 2024 Notes bear interest at a rate of 0.25% per year. Interest on the 2024 Notes is payable semi-annually in arrears on March 15 and September 15 of each year, beginning on September 15, 2017. The 2024 Notes will mature on March 15, 2024, unless earlier repurchased by us or converted pursuant to their terms.

[0001628280-21-021632:notes:112]
The initial conversion rate of the 2024 Notes is 16.4965 shares of common stock per $1,000 principal amount of 2024 Notes, which is equivalent to an initial conversion price of approximately $60.62 per share, a 132.5% premium to the fair market value at the date of issuance. Prior to the close of business on the business day immediately preceding December 15, 2023, each holder of the 2024 Notes may convert their 2024 Notes only under certain circumstances discussed in detail in our Annual Report on Form 10-K for the year ended July 3, 2021.

[0001628280-21-021632:notes:113]
During the three months ended October 2, 2021, we received conversion requests for less than $0.1 million principal amount of the 2024 Notes, which were settled in cash in the first quarter of fiscal 2022.

[0001628280-21-021632:notes:114]
2024 and 2026 Notes

[0001628280-21-021632:notes:115]
Our convertible notes consisted of the following components as of the periods presented (in millions):

[0001628280-21-021632:notes:116]
| Liability component: | October 2, 2021 |  | July 3, 2021 |
|  | 2024 Notes (1) |  | 2026 Notes (2) |  | 2024 Notes |  | 2026 Notes |
| Principal | $ | 450.0 |  |  | $ | 1,050.0 |  |  | $ | 450.0 |  |  | $ | 1,050.0 |  |
| Unamortized debt discount and issuance costs | (54.2) |  |  | (250.0) |  |  | (59.3) |  |  | (260.2) |  |
| Net carrying amount of the liability component | $ | 395.8 |  |  | $ | 800.0 |  |  | $ | 390.7 |  |  | $ | 789.8 |  |

[0001628280-21-021632:notes:117]
(1) Since the closing price of our stock exceeded $78.80 (or 130% of the conversion price of $60.62) for 20 of the last 30 trading days of the first quarter of fiscal 2022, the 2024 Notes have become convertible at the option of the holders. Therefore, the debt component of our 2024 Notes as of October 2, 2021 has been classified as current liabilities in our condensed consolidated balance sheet.

[0001628280-21-021632:notes:118]
(2) If the closing price of our stock exceeds $129.08 (or 130% of the conversion price of $99.29) for 20 of the last 30 trading days of any future quarter, our 2026 Notes would also become convertible at the option of the holders and the debt component would be reclassified to current liabilities in our condensed consolidated balance sheet.

[0001628280-21-021632:notes:119]
The following table sets forth interest expense information related to the convertible notes for the periods presented (in millions):

[0001628280-21-021632:notes:120]
|  | Three Months Ended |  |  |
|  | October 2, 2021 |  | September 26, 2020 |  |  |  |  |
| Contractual interest expense | $ | 1.6 |  |  | $ | 1.6 |  |  |  |  |  |
| Amortization of the debt discount and debt issuance costs | 15.3 |  |  | 14.4 |  |  |  |  |  |
| Total interest expense | $ | 16.9 |  |  | $ | 16.0 |  |  |  |  |  |

[0001628280-21-021632:notes:121]
The future interest and principal payments related to our convertible notes are as follows as of October 2, 2021 (in millions):

[0001628280-21-021632:notes:122]
| Fiscal Years | 2024 Notes |  | 2026 Notes |  | Total |
| Remainder of 2022 | $ | 0.5 |  |  | $ | 5.3 |  |  | $ | 5.8 |  |
| 2023 | 1.1 |  |  | 5.3 |  |  | 6.4 |  |
| 2024 | 451.1 |  |  | 5.3 |  |  | 456.4 |  |
| 2025 | — |  |  | 5.3 |  |  | 5.3 |  |
| 2026 | — |  |  | 5.3 |  |  | 5.3 |  |
| Thereafter | — |  |  | 1,052.4 |  |  | 1,052.4 |  |
| Total convertible notes payments | $ | 452.7 |  |  | $ | 1,078.9 |  |  | $ | 1,531.6 |  |

[0001628280-21-021632:notes:123]
The principal balances of our Notes are reflected in the payment periods in the table above based on their respective contractual maturities.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001628280-21-021632:notes:124]
Note 10. Accumulated Other Comprehensive Income

[0001628280-21-021632:notes:125]
Our accumulated other comprehensive income (loss) consists of the accumulated net unrealized gains or losses on foreign currency translation adjustments, the defined benefit obligations and available-for-sale securities.

[0001628280-21-021632:notes:126]
[same as prior period, unchanged from 0001633978-21-000009:notes:132]

[0001628280-21-021632:notes:127]
|  | Foreign currency translation adjustments, net of tax (1) |  | Defined benefit obligations, net of tax (2) |  | Unrealized gain (loss) on available-for-sale securities, net of tax |  |  |  | Total |
| Beginning balance as of July 3, 2021 | $ | 9.7 |  |  | $ | (1.4) |  |  | $ | (0.1) |  |  |  |  | $ | 8.2 |  |
| Other comprehensive income | — |  |  | — |  |  | 0.3 |  |  |  |  | 0.3 |  |
| Ending balance as of October 2, 2021 | $ | 9.7 |  |  | $ | (1.4) |  |  | $ | 0.2 |  |  |  |  | $ | 8.5 |  |
|  | Foreign currency translation adjustments, net of tax (1) |  | Defined benefit obligations, net of tax (2) |  | Unrealized gain (loss) on available-for-sale securities, net of tax |  |  |  | Total |
| Beginning balance as of June 27, 2020 | $ | 9.7 |  |  | $ | (4.2) |  |  | $ | 2.4 |  |  |  |  | $ | 7.9 |  |
| Other comprehensive loss | — |  |  | — |  |  | (1.5) |  |  |  |  | (1.5) |  |
| Ending balance as of September 26, 2020 | $ | 9.7 |  |  | $ | (4.2) |  |  | $ | 0.9 |  |  |  |  | $ | 6.4 |  |

[0001628280-21-021632:notes:128]
(1) In fiscal 2019, we established the functional currency for our worldwide operations as the U.S. dollar. Translation adjustments reported prior to December 10, 2018, remain as a component of accumulated other comprehensive income in our condensed consolidated balance sheets, until all or a part of the investment in the subsidiaries is sold or liquidated.

[0001628280-21-021632:notes:129]
(2) We re-evaluate the assumptions related to the fair value of our defined benefit obligations annually and make changes as necessary.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001628280-21-021632:notes:130]
[same as prior period, unchanged from 0001633978-21-000009:notes:135]

[0001628280-21-021632:notes:131]
[same as prior period, unchanged from 0001633978-21-000009:notes:136]

[0001628280-21-021632:notes:132]
The following table summarizes the activity of restructuring and related charges for the periods as presented (in millions):

[0001628280-21-021632:notes:133]
|  | Three Months Ended |  |  |
|  | October 2, 2021 |  | September 26, 2020 |  |  |  |  |
| Balance as of beginning of period | $ | 5.7 |  |  | $ | 5.2 |  |  |  |  |  |
| Charges (reversals), net | (1.1) |  |  | — |  |  |  |  |  |
| Payments | (3.8) |  |  | (0.8) |  |  |  |  |  |
| Balance as of end of period | $ | 0.8 |  |  | $ | 4.4 |  |  |  |  |  |

[0001628280-21-021632:notes:134]
During the three months ended October 2, 2021, we recorded a net reversal to our restructuring and related charges of $1.1 million in our condensed consolidated statements of operations which was attributable to lower than anticipated employee severance charges primarily as a result of retaining and re-assigning certain employees.

[0001628280-21-021632:notes:135]
During the three months ended September 26, 2020, we did not record any restructuring and related charges in our condensed consolidated statements of operations.

[0001628280-21-021632:notes:136]
[same as prior period, unchanged from 0001633978-21-000009:notes:141]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-21-021632:notes:137]
[same as prior period, unchanged from 0001633978-21-000009:notes:142]

[0001628280-21-021632:notes:138]
[same as prior period, unchanged from 0001633978-21-000009:notes:143]

[0001628280-21-021632:notes:139]
We recorded a tax provision of $18.1 million and $16.5 million for the three months ended October 2, 2021 and September 26, 2020, respectively. Our tax provision for the three months ended October 2, 2021 includes a discrete tax expense of $1.1 million primarily related to return-to-provision differences. Our estimated effective tax rate for fiscal 2022 differs from the 21% U.S. statutory rate primarily due to the income tax benefit from the earnings of our foreign subsidiaries being taxed at rates that differ from the U.S. statutory rate and U.S. federal R&D tax credits, partially offset by the income tax expense from the tax effect of Global Intangible Low-Taxed Income (“GILTI”), net of benefit for foreign tax credits, subpart F inclusion and non-deductible stock-based compensation.

[0001628280-21-021632:notes:140]
As of October 2, 2021, we had $27.5 million of unrecognized tax benefits, which, if recognized, would affect the effective tax rate. We are subject to examination of income tax returns by various domestic and foreign tax authorities. The timing of resolution and closure of tax audits is highly unpredictable. Although it is possible that certain ongoing tax audits may be concluded within the next 12 months, we cannot reasonably estimate the impact to tax expense and net income from tax exams that could be resolved or closed within the next 12 months. Subject to audit timing and uncertainty, we expect the amount of unrecognized tax benefit that would become recognized due to expiration of the statute of limitations and affect the effective tax rate to decrease by $3.8 million over the next 12 months.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001628280-21-021632:notes:141]
[same as prior period, unchanged from 0001633978-21-000009:notes:147]

[0001628280-21-021632:notes:142]
[same as prior period, unchanged from 0001633978-21-000009:notes:148]

[0001628280-21-021632:notes:143]
[same as prior period, unchanged from 0001633978-21-000009:notes:149]

[0001628280-21-021632:notes:144]
As of October 2, 2021, we had 2.7 million shares subject to restricted stock units and performance stock units issued and outstanding under the 2015 Equity Incentive Plan (the “2015 Plan”). Restricted stock units and performance stock units are performance-based, time-based or a combination of both. The fair value of these grants is based on the closing market price of our common stock on the date of award.

[0001628280-21-021632:notes:145]
As of October 2, 2021, 1.2 million shares of common stock under the 2015 Plan were available for grant.

[0001628280-21-021632:notes:146]
[same as prior period, unchanged from 0001633978-21-000009:notes:154]

[0001628280-21-021632:notes:147]
Restricted stock units (“RSUs”) under the 2015 Plan are grants of shares of our common stock, the vesting of which is based on the requisite service requirement. Generally, our RSUs are subject to forfeiture and are expected to vest over one to four years. For annual refresh grants, RSUs generally vest ratably on an annual basis, or combination of annual and quarterly basis, over three years.

[0001628280-21-021632:notes:148]
During the three months ended October 2, 2021, our board of directors approved a grant of 1.0 million RSUs to our employees, which vest over three years.

[0001628280-21-021632:notes:149]
[same as prior period, unchanged from 0001633978-21-000009:notes:156]

[0001628280-21-021632:notes:150]
[same as prior period, unchanged from 0001633978-21-000009:notes:157]

[0001628280-21-021632:notes:151]
During the three months ended October 2, 2021, our board of directors approved a grant of 0.2 million PSUs with an aggregate grant date fair value of $16.7 million to certain executive officers and senior management. These PSUs will vest subject to the achievement of 3-year revenue targets and certain corporate responsibility goals, and are also subject to service conditions.

[0001628280-21-021632:notes:152]
[same as prior period, unchanged from 0001633978-21-000009:notes:158]

[0001628280-21-021632:notes:153]
Our 2015 Employee Stock Purchase Plan (the “2015 Purchase Plan”) provides eligible employees with the opportunity to acquire an ownership interest in the Company through periodic payroll deductions and provides a 15% purchase price discount as well as a 6-month look-back period. The 2015 Purchase Plan is structured as a qualified employee stock purchase plan under Section 423 of the Internal Revenue Code of 1986, as amended. The 2015 Purchase Plan will terminate upon the date on which all shares available for issuance have been sold. Of the 3.0 million shares authorized under the 2015 Purchase Plan, 1.6 million shares remained available for issuance as of October 2, 2021.

[0001628280-21-021632:notes:154]
[same as prior period, unchanged from 0001633978-21-000009:notes:160]

[0001628280-21-021632:notes:155]
The impact on our results of operations of recording stock-based compensation by function for the periods presented was as follows (in millions):

[0001628280-21-021632:notes:156]
|  | Three Months Ended |  |  |
|  | October 2, 2021 |  | September 26, 2020 |  |  |  |  |
| Cost of sales | $ | 4.6 |  |  | $ | 3.7 |  |  |  |  |  |
| Research and development | 5.0 |  |  | 4.4 |  |  |  |  |  |
| Selling, general and administrative | 15.2 |  |  | 11.4 |  |  |  |  |  |
| Total stock-based compensation | $ | 24.8 |  |  | $ | 19.5 |  |  |  |  |  |

[0001628280-21-021632:notes:157]
Included in stock-based compensation for the three months ended October 2, 2021 and September 26, 2020, is $4.7 million and $3.1 million, respectively, of stock-based compensation costs related to the issuance of PSUs. The amount of stock-based compensation expense recognized in any one period related to PSUs can vary based on the achievement or anticipated achievement of the performance conditions. If the performance conditions are not met or not expected to be met, no compensation cost would be recognized on the underlying PSUs, and any previously recognized compensation expense related to those PSUs would be reversed.

[0001628280-21-021632:notes:158]
Total income tax benefit associated with stock-based compensation recognized in our condensed consolidated statements of operations during the years presented was as follows (in millions):

[0001628280-21-021632:notes:159]
|  | Three Months Ended |  |  |
|  | October 2, 2021 |  | September 26, 2020 |  |  |  |  |
| Income tax benefit associated with stock-based compensation | $ | 4.0 |  |  | $ | 5.3 |  |  |  |  |  |

[0001628280-21-021632:notes:160]
Approximately $4.9 million and $4.6 million of stock-based compensation was capitalized to inventory as of October 2, 2021 and July 3, 2021, respectively.

[0001628280-21-021632:notes:161]
[same as prior period, unchanged from 0001633978-21-000009:notes:166]

[0001628280-21-021632:notes:162]
The following table summarizes our awards activity for the three months ended October 2, 2021 (in millions, except per share amounts):

[0001628280-21-021632:notes:163]
|  |  |  | Restricted Stock Units |  | Performance Stock Units |
|  |  |  |  |  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |
| Balance as of July 3, 2021 |  |  |  |  | 1.8 |  |  | $ | 76.02 |  |  | 0.3 |  |  | $ | 75.68 |  |
| Granted |  |  |  |  | 1.0 |  |  | 86.71 |  |  | 0.2 |  |  | 85.90 |  |
| Vested |  |  |  |  | (0.5) |  |  | 76.58 |  |  | (0.1) |  |  | 78.26 |  |
| Canceled |  |  |  |  | (0.1) |  |  | 74.04 |  |  | — |  |  | 58.52 |  |
| Balance as of October 2, 2021 |  |  |  |  | 2.2 |  |  | $ | 80.84 |  |  | 0.4 |  |  | $ | 80.16 |  |

[0001628280-21-021632:notes:164]
As of October 2, 2021, $166.4 million of stock-based compensation cost related to RSU awards granted to our employees remains to be amortized. That cost is expected to be recognized over an estimated amortization period of 2.2 years.

[0001628280-21-021632:notes:165]
[same as prior period, unchanged from 0001633978-21-000009:notes:170]

[0001628280-21-021632:notes:166]
|  | Awards Available for Grant |
| Balance as of July 3, 2021 | 2.3 |  |
| Granted | (1.2) |  |
| Canceled | 0.1 |  |
| Balance as of October 2, 2021 | 1.2 |  |

[0001628280-21-021632:notes:167]
Employee Stock Purchase Plan Activity

[0001628280-21-021632:notes:168]
The 2015 Purchase Plan expense for the three months ended October 2, 2021 and September 26, 2020 was $1.2 million and $1.1 million, respectively. The expense related to the 2015 Purchase Plan is recorded on a straight-line basis over the relevant subscription period. During the three months ended October 2, 2021 and September 26, 2020, there were no shares issued to employees through the 2015 Purchase Plan.

[0001628280-21-021632:notes:169]
Repurchase and Retirement of Common Stock

[0001628280-21-021632:notes:170]
On May 7, 2021, our board of directors approved the 2021 share buyback program, which authorizes us to use up to $700.0 million to purchase our own shares of common stock. The buyback program is authorized for 2 years but may be suspended or terminated by the board of directors at any time. In the first quarter of fiscal 2022, we repurchased 1.1 million shares of our common stock at an average price of $82.45 per share for an aggregate purchase price of $91.7 million.

[0001628280-21-021632:notes:171]
Since the share buyback program was approved by the board of directors, we have repurchased in aggregate, a total of 4.2 million shares of our common stock at an average price of $79.05 per share for total proceeds of $332.7 million. All repurchased shares were retired immediately. The price, timing, amount, and method of such repurchases will be determined based on the valuation of market conditions and other factors, at prices determined to be attractive and in the best interests of both Lumentum and our stockholders. We recorded the $332.7 million aggregate purchase price as a reduction of retained earnings within our condensed consolidated balance sheet.


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0001628280-21-021632:notes:172]
Note 14. Commitments and Contingencies

[0001628280-21-021632:notes:173]
Purchase Obligations

[0001628280-21-021632:notes:174]
Purchase obligations of $260.4 million as of October 2, 2021, represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements.

[0001628280-21-021632:notes:175]
Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule and adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

[0001628280-21-021632:notes:176]
We depend on a limited number of contract manufacturers, subcontractors and suppliers for raw materials, packages and standard components. We generally purchase these single or limited source products through standard purchase orders or one-year supply agreements and have no significant long-term guaranteed supply agreements with such vendors. While we seek to maintain a sufficient safety stock of such products and maintain on-going communications with our suppliers to guard against interruptions or cessation of supply, our business and results of operations could be adversely affected by a stoppage or delay of supply, substitution of more expensive or less reliable products, receipt of defective parts or contaminated materials, increases in the price of such supplies, or our inability to obtain reduced pricing from our suppliers in response to competitive pressures.

[0001628280-21-021632:notes:177]
Product Warranties

[0001628280-21-021632:notes:178]
We provide reserves for the estimated costs of product warranties at the time revenue is recognized. We typically offer a twelve month warranty for most of our products. However, in some instances depending upon the product, product components or application of our products by the end customer, our warranties can vary and generally range from six months to five years. We estimate the costs of our warranty obligations on an annualized basis based on our historical experience of known product failure rates, use of materials to repair or replace defective products and service delivery costs incurred in correcting product failures. In addition, from time to time, specific warranty accruals may be made if unforeseen technical problems arise with specific products. We assess the adequacy of our recorded warranty liabilities and adjust the amounts as necessary.

[0001628280-21-021632:notes:179]
The following table presents the changes in our warranty reserve for the periods presented (in millions):

[0001628280-21-021632:notes:180]
|  | Three Months Ended |  |  |
|  | October 2, 2021 |  | September 26, 2020 |  |  |  |  |
| Balance as of beginning of period | $ | 5.0 |  |  | $ | 5.0 |  |  |  |  |  |
| Provision for warranty | 1.7 |  |  | 3.9 |  |  |  |  |  |
| Utilization of reserve | (1.6) |  |  | (1.3) |  |  |  |  |  |
| Balance as of end of period | $ | 5.1 |  |  | $ | 7.6 |  |  |  |  |  |

[0001628280-21-021632:notes:181]
Environmental Liabilities

[0001628280-21-021632:notes:182]
Our research and development (“R&D”), manufacturing and distribution operations involve the use of hazardous substances and are regulated under international, federal, state and local laws governing health and safety and the environment. We apply strict standards for protection of the environment and occupational health and safety to sites inside and outside the United States, even if not subject to regulations imposed by foreign governments. We believe that our properties and operations at our facilities comply in all material respects with applicable environmental laws and occupational health and safety laws. However, the risk of environmental liabilities cannot be completely eliminated and there can be no assurance that the application of environmental and health and safety laws will not require us to incur significant expenditures. We are also regulated under a number of international, federal, state and local laws regarding recycling, product packaging and product content requirements. The environmental, product content/disposal and recycling laws are gradually becoming more stringent and may cause us to incur significant expenditures in the future.

[0001628280-21-021632:notes:183]
Legal Proceedings

[0001628280-21-021632:notes:184]
We are subject to a variety of claims and suits that arise from time to time in the ordinary course of our business. While management currently believes that resolving claims against us, individually or in the aggregate, will not have a material adverse impact on our financial position, results of operations or statements of cash flows, these matters are subject to inherent uncertainties and management’s view of these matters may change in the future. We accrue for loss contingencies when it is both probable that we will incur the loss and when we can reasonably estimate the amount of the loss or range of loss.

[0001628280-21-021632:notes:185]
Merger Litigation

[0001628280-21-021632:notes:186]
In connection with our acquisition of Oclaro, seven lawsuits were filed by purported stockholders of Oclaro challenging the proposed merger (the “Merger”). Two of the seven suits were putative class actions filed against Oclaro, its directors, Lumentum, Prota Merger Sub, Inc. and Prota Merger, LLC: Nicholas Neinast v. Oclaro, Inc., et al., No. 3:18-cv-03112-VC, in the United States District Court for the Northern District of California (filed May 24, 2018) (the “Neinast Lawsuit”); and Adam Franchi v. Oclaro, Inc., et al., No. 1:18-cv-00817-GMS, in the United States District Court for the District of Delaware (filed June 9, 2018) (the “Franchi Lawsuit”). Both the Neinstat Lawsuit and the Franchi Lawsuit were voluntarily dismissed with prejudice.

[0001628280-21-021632:notes:187]
The other five suits, styled as Gerald F. Wordehoff v. Oclaro, Inc., et al., No. 5:18-cv-03148-NC (the “Wordehoff Lawsuit”), Walter Ryan v. Oclaro, Inc., et al., No. 3:18-cv-03174-VC (the “Ryan Lawsuit”), Jayme Walker v. Oclaro, Inc., et al., No. 5:18-cv-03203-EJD (the “Walker Lawsuit”), Kevin Garcia v. Oclaro, Inc., et al., No. 5:18-cv-03262-VKD (the “Garcia Lawsuit”), and SaiSravan B. Karri v. Oclaro, Inc., et al., No. 3:18-cv-03435-JD (the “Karri Lawsuit” and, together with the other six lawsuits, the “Lawsuits”), were filed in the United States District Court for the Northern District of California on May 25, 2018, May 29, 2018, May 30, 2018, May 31, 2018, and June 9, 2018, respectively. These five Lawsuits named Oclaro and its directors as defendants only and did not name Lumentum. The Wordehoff, Ryan, Walker, and Garcia Lawsuits have been voluntarily dismissed, and the Wordehoff, Ryan, and Walker dismissals were with prejudice. The Karri Lawsuit has not yet been dismissed. The Ryan Lawsuit was, and the Karri Lawsuit is, a putative class action.

[0001628280-21-021632:notes:188]
The Lawsuits generally alleged, among other things, that Oclaro and its directors violated Section 14(a) of the Securities Exchange Act of 1934, as amended (the “Exchange Act”), and Rule 14a-9 promulgated thereunder by disseminating an incomplete and misleading Form S-4, including proxy statement/prospectus. The Lawsuits further alleged that Oclaro’s directors violated Section 20(a) of the Exchange Act by failing to exercise proper control over the person(s) who violated Section 14(a) of the Exchange Act.

[0001628280-21-021632:notes:189]
The remaining Lawsuit (the Karri Lawsuit) currently purports to seek, among other things, damages to be awarded to the plaintiff and any class, if a class is certified, and litigation costs, including attorneys’ fees.  A lead plaintiff and counsel has been selected, and an amended complaint was filed on April 15, 2019, which also names Lumentum as a defendant. A motion to dismiss the amended complaint was granted in part and denied in part by the court on October 8, 2020. On December 1, 2020, defendants answered the amended complaint.  On December 23, 2020, defendants filed a motion for leave to file a motion for reconsideration of the Court’s October 8th order on the motion to dismiss, which was denied on January 29, 2021. The Karri Lawsuit remains pending with the parties currently in discovery. Defendants intend to defend the Karri Lawsuit vigorously.

[0001628280-21-021632:notes:190]
Indemnifications

[0001628280-21-021632:notes:191]
In the normal course of business, we enter into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown because claims may be made against us in the future and we may record charges in the future as a result of these indemnification obligations. As of October 2, 2021, we did not have any material indemnification claims that were probable or reasonably possible.

[0001628280-21-021632:notes:192]
Audit Proceedings

[0001628280-21-021632:notes:193]
We are under audit by various domestic and foreign tax authorities with regards to income tax and indirect tax matters. In some, although not all cases, we have reserved for potential adjustments to our provision for income taxes and accrual of indirect taxes that may result from examinations by these tax authorities or final outcomes in judicial proceedings, and we believe that the final outcome of these examinations, agreements or judicial proceedings will not have a material effect on our results of operations. If events occur which indicate payment of these amounts is unnecessary, the reversal of the liabilities would result in the recognition of benefits in the period we determine the liabilities are no longer necessary. If our estimates of the federal, state, and foreign income tax liabilities and indirect tax liabilities are less than the ultimate assessment, it could result in a further charge to expense.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001628280-21-021632:notes:194]
[same as prior period, unchanged from 0001633978-21-000009:notes:195]

[0001628280-21-021632:notes:195]
[same as prior period, unchanged from 0001633978-21-000009:notes:196]

[0001628280-21-021632:notes:196]
[same as prior period, unchanged from 0001633978-21-000009:notes:197]

[0001628280-21-021632:notes:197]
[same as prior period, unchanged from 0001633978-21-000009:notes:198]

[0001628280-21-021632:notes:198]
[same as prior period, unchanged from 0001633978-21-000009:notes:199]

[0001628280-21-021632:notes:199]
[same as prior period, unchanged from 0001633978-21-000009:notes:200]

[0001628280-21-021632:notes:200]
[same as prior period, unchanged from 0001633978-21-000009:notes:201]

[0001628280-21-021632:notes:201]
[same as prior period, unchanged from 0001633978-21-000009:notes:202]

[0001628280-21-021632:notes:202]
[same as prior period, unchanged from 0001633978-21-000009:notes:203]

[0001628280-21-021632:notes:203]
[same as prior period, unchanged from 0001633978-21-000009:notes:204]

[0001628280-21-021632:notes:204]
[same as prior period, unchanged from 0001633978-21-000009:notes:205]

[0001628280-21-021632:notes:205]
[same as prior period, unchanged from 0001633978-21-000009:notes:206]

[0001628280-21-021632:notes:206]
|  | Three Months Ended |  |  |
|  | October 2, 2021 |  | September 26, 2020 |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |
| OpComms | $ | 406.0 |  |  | $ | 428.5 |  |  |  |  |  |
| Lasers | 42.4 |  |  | 23.9 |  |  |  |  |  |
| Net revenue | $ | 448.4 |  |  | $ | 452.4 |  |  |  |  |  |
| Gross profit: |  |  |  |  |  |  |  |
| OpComms | $ | 225.9 |  |  | $ | 224.8 |  |  |  |  |  |
| Lasers | 20.8 |  |  | 10.4 |  |  |  |  |  |
| Total segment gross profit | 246.7 |  |  | 235.2 |  |  |  |  |  |
| Unallocated corporate items: |  |  |  |  |  |  |  |
| Stock-based compensation | (4.6) |  |  | (3.7) |  |  |  |  |  |
| Amortization of acquired intangibles | (15.8) |  |  | (15.0) |  |  |  |  |  |
| Inventory and fixed asset write down due to product line exits | — |  |  | (0.3) |  |  |  |  |  |
| Other (charges) gains (1) | 5.9 |  |  | (10.5) |  |  |  |  |  |
| Gross profit | $ | 232.2 |  |  | $ | 205.7 |  |  |  |  |  |

[0001628280-21-021632:notes:207]
(1) “Other (charges) gains” of unallocated corporate items for the three months ended October 2, 2021 primarily relate to $5.9 million gain as a result of selling equipment that was no longer needed after we transferred certain product lines to new production facilities in fiscal 2021. “Other (charges) gains” of unallocated corporate items for the three months ended September 26, 2020 primarily  include  costs  of  $2.1 million of transferring certain product lines to new production facilities  and excess and obsolete inventory charges of $5.9 million driven by U.S. trade restrictions and the related decline in demand from Huawei.

[0001628280-21-021632:notes:208]
[same as prior period, unchanged from 0001633978-21-000009:notes:214]

[0001628280-21-021632:notes:209]
|  | Three Months Ended |  |  |
|  | October 2, 2021 |  | September 26, 2020 |  |  |  |  |
|  | Amount |  | % of Total |  | Amount |  | % of Total |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States | $ | 28.1 |  |  | 6.3 | % |  | $ | 20.3 |  |  | 4.5 | % |  |  |  |  |  |  |  |  |
| Mexico | 33.0 |  |  | 7.4 |  |  | 39.8 |  |  | 8.8 |  |  |  |  |  |  |  |  |  |
| Other Americas | 2.0 |  |  | 0.4 |  |  | 2.8 |  |  | 0.6 |  |  |  |  |  |  |  |  |  |
| Total Americas | $ | 63.1 |  |  | 14.1 | % |  | $ | 62.9 |  |  | 13.9 | % |  |  |  |  |  |  |  |  |
| Asia-Pacific: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Hong Kong | $ | 142.3 |  |  | 31.7 | % |  | $ | 144.4 |  |  | 31.9 | % |  |  |  |  |  |  |  |  |
| Philippines | 9.1 |  |  | 2.0 |  |  | 62.8 |  |  | 13.9 |  |  |  |  |  |  |  |  |  |
| South Korea | 105.1 |  |  | 23.4 |  |  | 56.0 |  |  | 12.4 |  |  |  |  |  |  |  |  |  |
| Other Asia-Pacific | 103.0 |  |  | 23.0 |  |  | 91.6 |  |  | 20.2 |  |  |  |  |  |  |  |  |  |
| Total Asia-Pacific | $ | 359.5 |  |  | 80.1 | % |  | $ | 354.8 |  |  | 78.4 | % |  |  |  |  |  |  |  |  |
| EMEA | $ | 25.8 |  |  | 5.8 | % |  | $ | 34.7 |  |  | 7.7 | % |  |  |  |  |  |  |  |  |
| Total net revenue | $ | 448.4 |  |  |  |  | $ | 452.4 |  |  |  |  |  |  |  |  |  |  |  |

[0001628280-21-021632:notes:210]
During the three months ended October 2, 2021, net revenue from South Korea increased by $49.1 million and net revenue from Philippines decreased by $53.7 million from the three months ended September 26, 2020 due to changes in our customers’ chosen module integrator for specific new products.

[0001628280-21-021632:notes:211]
During the three months ended October 2, 2021, our net revenue from a single customer, which represented 10% or greater of total net revenue was concentrated with one customer, who accounted for 41% of our total net revenue. During the three months ended September 26, 2020, our net revenue from a single customer, which represented 10% or greater of total net revenue was concentrated with one customer, who accounted for 35% of our total net revenue.

[0001628280-21-021632:notes:212]
Our accounts receivable was concentrated with three customers as of October 2, 2021, which individually represented 22%, 19%, and 10% of gross accounts receivable, respectively, compared with two customers as of July 3, 2021, who represented 17% and 14% of gross accounts receivable, respectively.

[0001628280-21-021632:notes:213]
[same as prior period, unchanged from 0001633978-21-000009:notes:226]

[0001628280-21-021632:notes:214]
|  | October 2, 2021 |  | July 3, 2021 |
| Property, plant and equipment, net |  |  |  |
| United States | $ | 110.9 |  |  | $ | 116.7 |  |
| Thailand | 97.8 |  |  | 103.9 |  |
| China | 39.3 |  |  | 41.3 |  |
| Japan | 36.2 |  |  | 36.4 |  |
| Other countries | 69.0 |  |  | 62.8 |  |
| Total property, plant and equipment, net | $ | 353.2 |  |  | $ | 361.1 |  |

[0001628280-21-021632:notes:215]
We purchase a substantial portion of our inventory from contract manufacturers and vendors located primarily in Taiwan, Thailand and Malaysia. During the three months ended October 2, 2021 and September 26, 2020, our net inventory purchases from a single contract manufacturer, which represented 10% or greater of total net purchases, were concentrated with two contract manufacturers, who collectively accounted for 64% and 65% of total net inventory purchases, respectively.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001628280-21-021632:notes:216]
Note 16. Revenue Recognition

[0001628280-21-021632:notes:217]
Disaggregation of Revenue

[0001628280-21-021632:notes:218]
We disaggregate revenue by product and by geography. We do not present other levels of disaggregation, such as by type of products, customer, markets, contracts, duration of contracts, timing of transfer of control and sales channels, as this information is not used by our CODM to manage the business.

[0001628280-21-021632:notes:219]
The table below discloses our total net revenue attributable to each of our two reportable segments. In addition, the table sets forth the percentage of our total net revenue attributable to our product offerings which serve Telecom and Datacom, and Consumer and Industrial markets which accounted for 10% or more of our total net revenue during the periods presented (in millions, except percentage data):

[0001628280-21-021632:notes:220]
|  | Three Months Ended |  |  |
|  | October 2, 2021 |  | September 26, 2020 |  |  |  |  |
| OpComms: |  |  |  |  |  |  |  |  |  |  |  |
| Telecom and Datacom | $ | 216.0 |  | 48.2 | % |  | $ | 261.3 |  | 57.7 | % |  |  |  |  |  |  |
| Consumer and Industrial | 190.0 |  | 42.3 |  |  | 167.2 |  | 37.0 |  |  |  |  |  |  |  |
| Total OpComms | $ | 406.0 |  | 90.5 | % |  | $ | 428.5 |  | 94.7 | % |  |  |  |  |  |  |
| Lasers | 42.4 |  | 9.5 | % |  | 23.9 |  | 5.3 | % |  |  |  |  |  |  |
| Net Revenue | $ | 448.4 |  |  |  | $ | 452.4 |  |  |  |  |  |  |  |  |

[0001628280-21-021632:notes:221]
Contract Balances

[0001628280-21-021632:notes:222]
The following table reflects the changes in contract balances as of October 2, 2021 (in millions, except percentages):

[0001628280-21-021632:notes:223]
| Contract balances |  | Balance sheet location |  | October 2, 2021 |  | July 3, 2021 |  | Change |  | Percentage Change |
| Accounts receivable, net |  | Accounts receivable, net |  | $ | 263.2 |  |  | $ | 212.8 |  |  | $ | 50.4 |  |  | 23.7 | % |
| Deferred revenue and customer deposits |  | Other current liabilities |  | $ | — |  |  | $ | 0.6 |  |  | $ | (0.6) |  |  | (100.0) | % |


## us-gaap:SubsequentEventsTextBlock

[0001628280-21-021632:notes:224]
Subsequent Event
On November 4, 2021, Lumentum and NeoPhotonics Corporation (“NeoPhotonics”) announced a merger agreement (the “Merger Agreement”). Under the terms of the Merger Agreement, NeoPhotonics stockholders will receive $16.00 per share in cash for each NeoPhotonics share they own. This equates to a total transaction price of approximately $918 million. Lumentum will provide up to $50 million in interim debt financing to NeoPhotonics to help fund capital expenditures and increased working capital associated with NeoPhotonics’ growth plans. The cash consideration will be funded from the combined company’s balance sheet.

[0001628280-21-021632:notes:225]
The Merger Agreement contains certain termination rights for both Lumentum and NeoPhotonics and provides that upon termination of the Merger Agreement under specified circumstances (including termination by NeoPhotonics to accept a superior proposal), NeoPhotonics may be required to pay Lumentum a termination fee of $27.5 million. The Merger Agreement further provides that if the Merger Agreement is terminated for failure to obtain antitrust approval, Lumentum may be required to pay NeoPhotonics a termination fee of $55.1 million; and if Lumentum takes certain specified actions, (including entering into any definitive agreement for an acquisition by stock purchase, merger, consolidation, amalgamation, purchase of assets, license or otherwise of any ownership interest or assets of any Person) that cause a material delay in, or results in the failure of, the consummation of the Merger, Lumentum may be required to pay NeoPhotonics an additional termination fee of $36.7 million.
The Boards of Directors of Lumentum and NeoPhotonics have unanimously approved the transaction and the Merger Agreement. The transaction is subject to customary closing conditions, including the absence of certain legal impediments, the expiration or termination of the required waiting periods under the Hart-Scott-Rodino Antitrust Improvements Act of 1976, as amended, receipt of any required antitrust and regulatory approvals, and approval by the holders of a majority of the outstanding shares of NeoPhotonics common stock. The transaction is not subject to any financing condition. The transaction is expected to be completed in the second half of calendar year 2022.
