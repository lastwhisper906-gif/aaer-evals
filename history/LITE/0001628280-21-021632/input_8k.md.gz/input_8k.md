# LITE 8-K — 0001628280-21-021618 filed 2021-11-04

## item codes, every 8-K on or before 2021-11-04

- 2021-11-04 0001628280-21-021618 — 2.02, 9.01
- 2021-11-04 0001193125-21-319601 — 8.01, 9.01
- 2021-08-18 0001628280-21-017219 — 2.02, 9.01
- 2021-06-08 0001633978-21-000030 — 5.02, 9.01
- 2021-05-12 0001633978-21-000008 — 2.02, 9.01
- 2021-03-10 0001193125-21-075438 — 1.01, 8.01, 9.01
- 2021-02-02 0001633978-21-000002 — 2.02, 9.01
- 2021-01-19 0001104659-21-005024 — 1.01, 2.02, 8.01, 9.01
- 2020-11-24 0001193125-20-302557 — 5.02, 5.07
- 2020-11-02 0001633978-20-000017 — 2.02, 9.01
- 2020-09-18 0001633978-20-000012 — 5.02, 9.01
- 2020-08-11 0001633978-20-000010 — 2.02, 9.01
- 2020-05-05 0001628280-20-006358 — 2.02, 9.01
- 2020-02-04 0001633978-20-000002 — 2.02, 9.01
- 2019-12-12 0001193125-19-312875 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2019-12-04 0001633978-19-000075 — 8.01
- 2019-11-20 0001633978-19-000074 — 5.07
- 2019-10-31 0001633978-19-000070 — 2.02, 9.01
- 2019-08-08 0001633978-19-000068 — 2.02, 9.01
- 2019-05-08 0001633978-19-000031 — 1.01
- 2019-05-07 0001633978-19-000029 — 2.02, 9.01
- 2019-02-15 0001633978-19-000005 — 9.01 — amendment of 0001193125-18-346211
- 2019-02-08 0001193125-19-031591 — 5.02, 9.01
- 2019-02-05 0001633978-19-000001 — 2.02, 9.01
- 2018-12-10 0001193125-18-346211 — 1.01, 2.01, 2.03, 5.02, 8.01, 9.01
- 2018-12-06 0001633978-18-000150 — 8.01
- 2018-11-14 0001633978-18-000139 — 5.07
- 2018-11-13 0001633978-18-000136 — 3.02
- 2018-11-13 0001633978-18-000132 — 7.01, 9.01
- 2018-11-01 0001628280-18-013238 — 2.02, 9.01
- 2018-08-08 0001633978-18-000056 — 2.02, 9.01
- 2018-06-08 0001193125-18-188241 — 5.02, 9.01
- 2018-05-02 0001633978-18-000029 — 2.02, 9.01
- 2018-03-12 0001193125-18-078154 — 1.01, 2.01, 8.01, 9.01
- 2018-02-06 0001628280-18-001082 — 2.02, 9.01
- 2017-11-08 0001633978-17-000133 — 5.02, 9.01
- 2017-11-07 0001633978-17-000131 — 5.07
- 2017-11-01 0001633978-17-000117 — 2.02, 9.01
- 2017-08-09 0001633978-17-000058 — 2.02, 9.01
- 2017-05-04 0001633978-17-000035 — 2.02, 9.01
- 2017-03-08 0001193125-17-074740 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2017-03-02 0001193125-17-066769 — 8.01, 9.01
- 2017-02-07 0001633978-17-000005 — 2.02, 9.01
- 2017-01-03 0001628280-17-000018 — 4.01, 9.01
- 2016-11-09 0001628280-16-021143 — 5.02, 5.07, 9.01
- 2016-10-27 0001628280-16-020382 — 2.02, 9.01
- 2016-08-09 0001628280-16-018811 — 2.02, 9.01
- 2016-06-21 0001628280-16-017201 — 8.01
- 2016-05-04 0001628280-16-015501 — 2.02, 9.01
- 2016-02-16 0001628280-16-011261 — 5.02, 9.01
- 2016-02-04 0001628280-16-010758 — 5.02, 9.01
- 2016-02-04 0001628280-16-010755 — 2.02, 9.01
- 2015-11-17 0001193125-15-378953 — 7.01
- 2015-11-10 0001628280-15-008606 — 2.02, 9.01
- 2015-09-28 0001193125-15-329665 — 8.01, 9.01
- 2015-08-11 0001193125-15-286405 — 7.01, 9.01
- 2015-08-06 0001193125-15-281219 — 1.01, 5.02, 5.03, 5.05, 8.01, 9.01
- 2015-08-03 0001193125-15-274808 — 5.03, 9.01

## late-filing notifications on or before 2021-11-04

- 2015-11-10 0001628280-15-008612 — NT 10-Q, for the period ended 2015-09-26
- 2015-09-28 0001193125-15-329672 — NT 10-K, for the period ended 2015-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001628280-21-021618:8k_2_02:1]
EX-99.1
2
lite_ex991xq1fy22.htm
EX-99.1

[0001628280-21-021618:8k_2_02:2]
Document

[0001628280-21-021618:8k_2_02:3]
NEWS RELEASE

[0001628280-21-021618:8k_2_02:4]
LUMENTUM ANNOUNCES FISCAL FIRST QUARTER 2022 FINANCIAL RESULTS

[0001628280-21-021618:8k_2_02:5]
•Net revenue of $448.4 million

[0001628280-21-021618:8k_2_02:6]
•GAAP gross margin of 51.8%; Non-GAAP gross margin of 55.0%

[0001628280-21-021618:8k_2_02:7]
•GAAP operating margin of 25.8%; Non-GAAP operating margin of 35.4%

[0001628280-21-021618:8k_2_02:8]
•GAAP diluted net income per share of $1.08; Non-GAAP diluted net income per share of $1.79

[0001628280-21-021618:8k_2_02:9]
San Jose, Calif., November 4, 2021 – Lumentum Holdings Inc. (“Lumentum” or the “Company”) today reported results for its fiscal first quarter ended October 2, 2021.

[0001628280-21-021618:8k_2_02:10]
“Driven by strong demand, first quarter financial results were above our guidance ranges across all metrics,” said Alan Lowe, President and CEO. “Our Industrial and Consumer product lines and our Commercial Lasers segment revenues were ahead of expectations which more than offset the impact of semiconductor shortages in our Telecom and Datacom product lines.”

[0001628280-21-021618:8k_2_02:11]
“Looking to the second quarter, demand continues to be strong, particularly in Telecom and Datacom as well as Commercial Lasers, where we expect revenue to grow sequentially. While we are increasing our supply of semiconductors, we expect the gap between demand and supply for our products in the second quarter will be larger than it was in the first quarter, and we have incorporated this in our guidance,” added Mr. Lowe.

[0001628280-21-021618:8k_2_02:12]
Fiscal First Quarter Highlights:

[0001628280-21-021618:8k_2_02:13]
Net revenue for the fiscal first quarter of 2022 was $448.4 million, with GAAP net income of $81.5 million, or $1.08 per diluted share. Net revenue for the fiscal fourth quarter of 2021 was $392.1 million, with GAAP net income of $21.5 million, or $0.28 per diluted share. Net revenue for the fiscal first quarter of 2021 was $452.4 million, with GAAP net income of $67.1 million, or $0.86 per diluted share.

[0001628280-21-021618:8k_2_02:14]
Non-GAAP net income for the fiscal first quarter of 2022 was $135.1 million, or $1.79 per diluted share. Non-GAAP net income for the fiscal fourth quarter of 2021 was $81.9 million, or $1.06 per diluted share. Non-GAAP net income for the fiscal first quarter of 2021 was $131.2 million, or $1.68 per diluted share.

[0001628280-21-021618:8k_2_02:15]
The Company held $1,884.6 million in total cash, cash equivalents, and short-term investments at the end of the fiscal first quarter of 2022, down $61.4 million from the fiscal fourth quarter of 2021.

[0001628280-21-021618:8k_2_02:16]
Financial Overview – Fiscal First Quarter Ended October 2, 2021

[0001628280-21-021618:8k_2_02:17]
|  | GAAP Results ($ in millions) |
|  | Q1 |  | Q4 |  | Q1 |  | Change |
|  | FY 2022 |  | FY 2021 |  | FY 2021 |  | Q/Q |  | Y/Y |
| Net revenue | $448.4 |  | $392.1 |  | $452.4 |  | 14.4% |  | (0.9)% |
| Gross margin | 51.8% |  | 41.5% |  | 45.5% |  | 1,030bps |  | 630bps |
| Operating margin | 25.8% |  | 11.7% |  | 21.9% |  | 1,410bps |  | 390bps |
|  | Non-GAAP Results ($ in millions) |
|  | Q1 |  | Q4 |  | Q1 |  | Change |
|  | FY 2022 |  | FY 2021 |  | FY 2021 |  | Q/Q |  | Y/Y |
| Net revenue | $448.4 |  | $392.1 |  | $452.4 |  | 14.4% |  | (0.9)% |
| Gross margin | 55.0% |  | 47.7% |  | 52.0% |  | 730bps |  | 300bps |
| Operating margin | 35.4% |  | 24.6% |  | 33.7% |  | 1,080bps |  | 170bps |

[0001628280-21-021618:8k_2_02:18]
|  | Net Revenue by Segment ($ in millions) |
|  | Q1 |  | % of |  | Q4 |  | Q1 |  | Change |
|  | FY 2022 |  | Net Revenue |  | FY 2021 |  | FY 2021 |  | Q/Q |  | Y/Y |
| Optical Communications | $ | 406.0 |  |  | 90.5 | % |  | $ | 355.2 |  |  | $ | 428.5 |  |  | 14.3 | % |  | (5.3) | % |
| Lasers | 42.4 |  |  | 9.5 | % |  | 36.9 |  |  | 23.9 |  |  | 14.9 | % |  | 77.4 | % |
| Total | $ | 448.4 |  |  | 100.0 | % |  | $ | 392.1 |  |  | $ | 452.4 |  |  | 14.4 | % |  | (0.9) | % |

[0001628280-21-021618:8k_2_02:19]
The tables above provide comparisons of quarterly results to prior periods, including sequential quarterly and year-over-year changes. A reconciliation between GAAP and non-GAAP measures is contained in this release under the section titled “Use of Non-GAAP Financial Measures.”

[0001628280-21-021618:8k_2_02:20]
Business Outlook

[0001628280-21-021618:8k_2_02:21]
Lumentum expects the following for the fiscal second quarter 2022:

[0001628280-21-021618:8k_2_02:22]
•Net revenue in the range of $435 million to $455 million

[0001628280-21-021618:8k_2_02:23]
•Non-GAAP operating margin of 30.0% to 32.0%

[0001628280-21-021618:8k_2_02:24]
•Non-GAAP diluted earnings per share of $1.47 to $1.64

[0001628280-21-021618:8k_2_02:25]
We have not provided reconciliations from GAAP to non-GAAP measures for our outlook. A large portion of non-GAAP adjustments, such as restructuring charges, stock-based compensation, non-cash income tax expense and credits, integration and acquisition related costs, inventory write down due to plans to exit certain product lines and other costs and contingencies unrelated to current and future operations are by their nature highly volatile and we have low visibility as to the range that may be incurred in the future.

[0001628280-21-021618:8k_2_02:26]
Related Announcement and Conference Call

[0001628280-21-021618:8k_2_02:27]
In a separate news release today, the Company announced that it had entered into a transaction to acquire NeoPhotonics Corporation (“NeoPhotonics”). Lumentum will host a conference call today, November 4, 2021, at 5:30 am PT / 8:30 am ET to discuss its fiscal first quarter results and the announced transaction.  A live webcast of the call and the replay will be available in the Investors section of the Lumentum website at http://investor.lumentum.com through November 11, 2021, at 8:59 pm PT / 11:59 pm ET. To listen to the live conference call, dial (844) 200-6205 or (929) 526-1599 and reference the passcode 319529. To access the replay, dial (866) 813-9403 or (929) 458-6194 and reference the passcode 908228. Supporting materials outlining the Company’s latest financial results will be posted on http://investor.lumentum.com under the “Events and Presentations” section concurrently with this earnings press release. Lumentum has used, and intends to continue to use, its Investor Relations website as means of disclosing material nonpublic information and for complying with its disclosure obligations under Regulation FD. This press release is being furnished as an exhibit to a Current Report on Form 8-K filed with the Securities and Exchange Commission and will be available at http://www.sec.gov/.

[0001628280-21-021618:8k_2_02:28]
About Lumentum

[0001628280-21-021618:8k_2_02:29]
Lumentum (NASDAQ: LITE) is a market-leading designer and manufacturer of innovative optical and photonic products enabling optical networking and laser applications worldwide. Lumentum optical components and subsystems are part of virtually every type of telecom, enterprise, and data center network. Lumentum lasers enable advanced manufacturing techniques and diverse applications including next-generation 3D sensing capabilities. Lumentum is headquartered in San Jose, California with R&D, manufacturing, and sales offices worldwide. For more information, visit www.lumentum.com.

[0001628280-21-021618:8k_2_02:30]
Forward-Looking Statements

[0001628280-21-021618:8k_2_02:31]
Contact Information

[0001628280-21-021618:8k_2_02:32]
Investors:            Jim Fanucchi, 408-404-5400; investor.relations@lumentum.com

[0001628280-21-021618:8k_2_02:33]
Media:         Sean Ogarrio, 408-546-5405; media@lumentum.com

[0001628280-21-021618:8k_2_02:34]
Category:            Financial

[0001628280-21-021618:8k_2_02:35]
The following financial tables are presented in accordance with GAAP, unless otherwise specified.

[0001628280-21-021618:8k_2_02:36]
LUMENTUM HOLDINGS INC.

[0001628280-21-021618:8k_2_02:37]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001628280-21-021618:8k_2_02:38]
(in millions, except per share data)

[0001628280-21-021618:8k_2_02:39]
(unaudited)

[0001628280-21-021618:8k_2_02:40]
|  | Three Months Ended |  |  |
|  | October 2, 2021 |  | September 26, 2020 |  |  |  |  |
| Net revenue | $ | 448.4 |  |  | $ | 452.4 |  |  |  |  |  |
| Cost of sales | 200.4 |  |  | 231.7 |  |  |  |  |  |
| Amortization of acquired developed intangibles | 15.8 |  |  | 15.0 |  |  |  |  |  |
| Gross profit | 232.2 |  |  | 205.7 |  |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 54.1 |  |  | 50.4 |  |  |  |  |  |
| Selling, general and administrative | 63.3 |  |  | 56.3 |  |  |  |  |  |
| Restructuring and related charges | (1.1) |  |  | — |  |  |  |  |  |
| Total operating expenses | 116.3 |  |  | 106.7 |  |  |  |  |  |
| Income from operations | 115.9 |  |  | 99.0 |  |  |  |  |  |
| Interest expense | (16.9) |  |  | (16.0) |  |  |  |  |  |
| Other income, net | 0.6 |  |  | 0.6 |  |  |  |  |  |
| Income before income taxes | 99.6 |  |  | 83.6 |  |  |  |  |  |
| Provision for income taxes | 18.1 |  |  | 16.5 |  |  |  |  |  |
| Net income | $ | 81.5 |  |  | $ | 67.1 |  |  |  |  |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic | $ | 1.12 |  |  | $ | 0.89 |  |  |  |  |  |
| Diluted | $ | 1.08 |  |  | $ | 0.86 |  |  |  |  |  |
| Shares used to compute net income per share: |  |  |  |  |  |  |  |
| Basic | 72.7 |  |  | 75.3 |  |  |  |  |  |
| Diluted | 75.4 |  |  | 78.2 |  |  |  |  |  |

[0001628280-21-021618:8k_2_02:41]
LUMENTUM HOLDINGS INC.

[0001628280-21-021618:8k_2_02:42]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001628280-21-021618:8k_2_02:43]
(in millions, except per share data)

[0001628280-21-021618:8k_2_02:44]
(unaudited)

[0001628280-21-021618:8k_2_02:45]
|  | October 2, 2021 |  | July 3, 2021 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 611.0 |  |  | $ | 774.3 |  |
| Short-term investments | 1,273.6 |  |  | 1,171.7 |  |
| Accounts receivable, net | 263.2 |  |  | 212.8 |  |
| Inventories | 207.0 |  |  | 196.4 |  |
| Prepayments and other current assets | 68.2 |  |  | 81.6 |  |
| Total current assets | 2,423.0 |  |  | 2,436.8 |  |
| Property, plant and equipment, net | 353.2 |  |  | 361.1 |  |
| Operating lease right-of-use assets, net | 75.2 |  |  | 67.4 |  |
| Goodwill | 368.9 |  |  | 368.9 |  |
| Other intangible assets, net | 219.8 |  |  | 241.2 |  |
| Deferred tax asset | 72.9 |  |  | 72.9 |  |
| Other non-current assets | 6.0 |  |  | 3.3 |  |
| Total assets | $ | 3,519.0 |  |  | $ | 3,551.6 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 101.6 |  |  | $ | 116.9 |  |
| Accrued payroll and related expenses | 42.9 |  |  | 54.3 |  |
| Accrued expenses | 40.4 |  |  | 33.1 |  |
| Convertible notes, current | 395.8 |  |  | 390.7 |  |
| Operating lease liabilities, current | 11.7 |  |  | 11.8 |  |
| Other current liabilities | 19.3 |  |  | 57.8 |  |
| Total current liabilities | 611.7 |  |  | 664.6 |  |
| Convertible notes, non-current | 800.0 |  |  | 789.8 |  |
| Operating lease liabilities, non-current | 57.5 |  |  | 47.6 |  |
| Deferred tax liability | 35.5 |  |  | 35.9 |  |
| Other non-current liabilities | 42.9 |  |  | 40.9 |  |
| Total liabilities | 1,547.6 |  |  | 1,578.8 |  |
| Stockholders’ equity: |  |  |  |
| Common stock, $0.001 par value, 990 authorized shares, 72.3 and 73.0 shares issued and outstanding as of October 2, 2021 and July 3, 2021, respectively | 0.1 |  |  | 0.1 |  |
| Additional paid-in capital | 1,752.1 |  |  | 1,743.6 |  |
| Retained earnings | 210.7 |  |  | 220.9 |  |
| Accumulated other comprehensive income | 8.5 |  |  | 8.2 |  |
| Total stockholders’ equity | 1,971.4 |  |  | 1,972.8 |  |
| Total liabilities and stockholders’ equity | $ | 3,519.0 |  |  | $ | 3,551.6 |  |

[0001628280-21-021618:8k_2_02:46]
Use of Non-GAAP Financial Measures

[0001628280-21-021618:8k_2_02:47]
In this press release, Lumentum provides investors with gross profit, gross margin, research and development expense, selling, general and administrative expense, operating margin, income from operations, interest and other income (expense), net, income before income taxes, provision for income taxes, net income, and net income per share on a non-GAAP basis, as well as the non-GAAP measures of EBITDA and Adjusted EBITDA. Lumentum believes this non-GAAP financial information provides additional insight into the Company’s on-going business operations and results, as well as cash generation, and has therefore chosen to provide this information to investors for a more consistent basis of comparison and to help them evaluate the results of the Company’s on-going operations and enable more meaningful period to period comparisons. In addition, the Company believes that providing certain of these measures allows investors to better understand the Company’s cash flows and, importantly, to evaluate the efficacy of the methodology and information used by management to evaluate and measure such cash flows. However, these measures may be different from non-GAAP measures used by other companies, limiting their usefulness for comparison purposes. The non-GAAP financial measures used in this press release should not be considered in isolation from measures of financial performance prepared in accordance with GAAP. Investors are cautioned that there are material limitations associated with the use of non-GAAP financial measures as an analytical tool. In particular, many of the adjustments to our GAAP financial measures reflect the exclusion of items that are recurring and will be reflected in our financial results for the foreseeable future. Further, these non-GAAP financial measures may not be comparable to similarly titled measurements reported by other companies.

[0001628280-21-021618:8k_2_02:48]
Our non-GAAP measures used in this press release exclude (i) stock-based compensation, (ii) gain on sale of product lines, (iii) integration related costs, (iv) inventory and fixed asset write down due to product line exists, (v) amortization of acquired intangibles, (vi) restructuring and related charges, (vii) foreign exchange (gains) losses, net, (viii) non-cash interest expense on convertible notes, (ix) non-cash income tax impacts, and (x) other (gains) charges related to non-recurring activities.

[0001628280-21-021618:8k_2_02:49]
A quantitative reconciliation between GAAP and non-GAAP financial data with respect to historical periods is included in the supplemental financial table attached to this press release.

[0001628280-21-021618:8k_2_02:50]
LUMENTUM HOLDINGS INC.

[0001628280-21-021618:8k_2_02:51]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001628280-21-021618:8k_2_02:52]
(in millions, except per share data)

[0001628280-21-021618:8k_2_02:53]
(unaudited)

[0001628280-21-021618:8k_2_02:54]
|  | Three Months Ended |  |  |  |  |
|  | October 2, 2021 |  | July 3, 2021 |  | September 26, 2020 |  |  |  |  |  |  |
| Gross profit on GAAP basis | $ | 232.2 |  |  | 162.8 |  |  | $ | 205.7 |  |  |  |  |  |  |  |
| Stock-based compensation | 4.6 |  |  | 5.4 |  |  | 3.7 |  |  |  |  |  |  |  |
| Inventory and fixed asset write down due to product line exits | — |  |  | — |  |  | 0.3 |  |  |  |  |  |  |  |
| Amortization of acquired intangibles | 15.8 |  |  | 15.9 |  |  | 15.0 |  |  |  |  |  |  |  |
| Other (gains) charges (1) | (5.9) |  |  | 3.1 |  |  | 10.5 |  |  |  |  |  |  |  |
| Gross profit on non-GAAP basis | $ | 246.7 |  |  | $ | 187.2 |  |  | $ | 235.2 |  |  |  |  |  |  |  |
| Gross margin on non-GAAP basis | 55.0 | % |  | 47.7 | % |  | 52.0 | % |  |  |  |  |  |  |
| Research and development on GAAP basis | $ | 54.1 |  |  | $ | 54.1 |  |  | $ | 50.4 |  |  |  |  |  |  |  |
| Stock-based compensation | (5.0) |  |  | (4.7) |  |  | (4.4) |  |  |  |  |  |  |  |
| Other gains (charges) | (0.1) |  |  | (0.3) |  |  | (0.1) |  |  |  |  |  |  |  |
| Research and development on non-GAAP basis | $ | 49.0 |  |  | $ | 49.1 |  |  | $ | 45.9 |  |  |  |  |  |  |  |
| Selling, general and administrative on GAAP basis | $ | 63.3 |  |  | $ | 58.3 |  |  | $ | 56.3 |  |  |  |  |  |  |  |
| Stock-based compensation | (15.2) |  |  | (14.1) |  |  | (11.4) |  |  |  |  |  |  |  |
| Integration related costs | — |  |  | — |  |  | (0.3) |  |  |  |  |  |  |  |
| Amortization of acquired intangibles | (5.6) |  |  | (6.2) |  |  | (5.7) |  |  |  |  |  |  |  |
| Other gains (charges) (2) | (3.7) |  |  | 3.5 |  |  | (2.1) |  |  |  |  |  |  |  |
| Selling, general and administrative on non-GAAP basis | $ | 38.8 |  |  | $ | 41.5 |  |  | $ | 36.8 |  |  |  |  |  |  |  |
| Income from operations on GAAP basis | $ | 115.9 |  |  | $ | 45.8 |  |  | $ | 99.0 |  |  |  |  |  |  |  |
| Stock-based compensation | 24.8 |  |  | 24.2 |  |  | 19.5 |  |  |  |  |  |  |  |
| Inventory and fixed asset write down due to product line exits | — |  |  | — |  |  | 0.3 |  |  |  |  |  |  |  |
| Integration related costs | — |  |  | — |  |  | 0.3 |  |  |  |  |  |  |  |
| Amortization of acquired intangibles | 21.4 |  |  | 22.1 |  |  | 20.7 |  |  |  |  |  |  |  |
| Restructuring and related charges | (1.1) |  |  | 4.6 |  |  | — |  |  |  |  |  |  |  |
| Other (gains) charges (1) (2) | (2.1) |  |  | (0.1) |  |  | 12.7 |  |  |  |  |  |  |  |
| Income from operations on non-GAAP basis | $ | 158.9 |  |  | $ | 96.6 |  |  | $ | 152.5 |  |  |  |  |  |  |  |
| Operating margin on non-GAAP basis | 35.4 | % |  | 24.6 | % |  | 33.7 | % |  |  |  |  |  |  |
| Interest and other expense, net on GAAP basis | $ | (16.3) |  |  | $ | (17.3) |  |  | $ | (15.4) |  |  |  |  |  |  |  |
| Gain on sale of product lines | — |  |  | (0.2) |  |  | (0.4) |  |  |  |  |  |  |  |
| Foreign exchange losses, net | 0.1 |  |  | 0.6 |  |  | 2.3 |  |  |  |  |  |  |  |
| Non-cash interest expense on convertible notes | 15.3 |  |  | 16.2 |  |  | 14.4 |  |  |  |  |  |  |  |
| Interest and other income (expense), net on non-GAAP basis | $ | (0.9) |  |  | $ | (0.7) |  |  | $ | 0.9 |  |  |  |  |  |  |  |
| Income before income taxes on GAAP basis | $ | 99.6 |  |  | $ | 28.5 |  |  | $ | 83.6 |  |  |  |  |  |  |  |
| Stock-based compensation | 24.8 |  |  | 24.2 |  |  | 19.5 |  |  |  |  |  |  |  |
| Inventory and fixed asset write down due to product line exits | — |  |  | — |  |  | 0.3 |  |  |  |  |  |  |  |

[0001628280-21-021618:8k_2_02:55]
| Integration related costs | — |  |  | — |  |  | 0.3 |  |  |  |  |  |  |  |
| Amortization of acquired intangibles | 21.4 |  |  | 22.1 |  |  | 20.7 |  |  |  |  |  |  |  |
| Restructuring and related charges | (1.1) |  |  | 4.6 |  |  | — |  |  |  |  |  |  |  |
| Gain on sale of product lines | — |  |  | (0.2) |  |  | (0.4) |  |  |  |  |  |  |  |
| Foreign exchange losses, net | 0.1 |  |  | 0.6 |  |  | 2.3 |  |  |  |  |  |  |  |
| Non-cash interest expense on convertible notes | 15.3 |  |  | 16.2 |  |  | 14.4 |  |  |  |  |  |  |  |
| Other (gains) charges (1) (2) | (2.1) |  |  | (0.1) |  |  | 12.7 |  |  |  |  |  |  |  |
| Income before income taxes on non-GAAP basis | $ | 158.0 |  |  | $ | 95.9 |  |  | $ | 153.4 |  |  |  |  |  |  |  |
| Provision for income taxes on GAAP basis | $ | 18.1 |  |  | $ | 7.0 |  |  | $ | 16.5 |  |  |  |  |  |  |  |
| Income tax adjustments (3) | 4.8 |  |  | 7.0 |  |  | 5.7 |  |  |  |  |  |  |  |
| Provision for income taxes on non-GAAP basis | $ | 22.9 |  |  | $ | 14.0 |  |  | $ | 22.2 |  |  |  |  |  |  |  |
| Net income on GAAP basis | $ | 81.5 |  |  | $ | 21.5 |  |  | $ | 67.1 |  |  |  |  |  |  |  |
| Stock-based compensation | 24.8 |  |  | 24.2 |  |  | 19.5 |  |  |  |  |  |  |  |
| Inventory and fixed asset write down due to product line exits | — |  |  | — |  |  | 0.3 |  |  |  |  |  |  |  |
| Integration related costs | — |  |  | — |  |  | 0.3 |  |  |  |  |  |  |  |
| Amortization of acquired intangibles | 21.4 |  |  | 22.1 |  |  | 20.7 |  |  |  |  |  |  |  |
| Restructuring and related charges | (1.1) |  |  | 4.6 |  |  | — |  |  |  |  |  |  |  |
| Gain on sale of product lines | — |  |  | (0.2) |  |  | (0.4) |  |  |  |  |  |  |  |
| Foreign exchange losses, net | 0.1 |  |  | 0.6 |  |  | 2.3 |  |  |  |  |  |  |  |
| Non-cash interest expense on convertible notes | 15.3 |  |  | 16.2 |  |  | 14.4 |  |  |  |  |  |  |  |
| Income tax adjustments (3) | (4.8) |  |  | (7.0) |  |  | (5.7) |  |  |  |  |  |  |  |
| Other (gains) charges (1) (2) | (2.1) |  |  | (0.1) |  |  | 12.7 |  |  |  |  |  |  |  |
| Net income on non-GAAP basis | $ | 135.1 |  |  | $ | 81.9 |  |  | $ | 131.2 |  |  |  |  |  |  |  |
| Net income per share on non-GAAP basis | $ | 1.79 |  |  | $ | 1.06 |  |  | $ | 1.68 |  |  |  |  |  |  |  |
| Shares used in per share calculation - diluted on non-GAAP basis | 75.4 |  |  | 77.5 |  |  | 78.2 |  |  |  |  |  |  |  |

[0001628280-21-021618:8k_2_02:56]
(1)  Other (gains) charges excluded from gross profit for the three months ended October 2, 2021 primarily relate to $5.9 million gains from equipment sale in connection with transferring product lines to new production facilities.

[0001628280-21-021618:8k_2_02:57]
(2) Other (gains) charges excluded from selling, general and administrative expense for the three months ended October 2, 2021 mainly include $1.2 million of tax restructuring project costs and $1.3 million of exit, moving and other costs incurred in connection with transferring product lines to new production facilities.

[0001628280-21-021618:8k_2_02:58]
(3) Income tax adjustments have been revised for the three months ended September 26, 2020. In order to give a more meaningful perspective of our tax burden over a longer-term period, and in accordance with the SEC Non-GAAP Financial Measures Compliance  and  Disclosure  Interpretations,  beginning  in fiscal  fourth  quarter 2021,  Lumentum  changed  its  method  of  calculating  its  non-GAAP income  tax provision.  This change in methodology does not affect the Company’s non-GAAP operating profit, annual cash tax payments, or cash flows, but results in higher reported non-GAAP tax provisions.

[0001628280-21-021618:8k_2_02:59]
LUMENTUM HOLDINGS INC.

[0001628280-21-021618:8k_2_02:60]
RECONCILIATION OF GAAP NET INCOME TO ADJUSTED EBITDA

[0001628280-21-021618:8k_2_02:61]
(in millions, except per share data)

[0001628280-21-021618:8k_2_02:62]
(unaudited)

[0001628280-21-021618:8k_2_02:63]
|  | Three Months Ended |  |  |
|  | October 2, 2021 |  |  |  | July 3, 2021 |  | September 26, 2020 |  |  |  |  |
| GAAP Net income | $ | 81.5 |  |  |  |  | $ | 21.5 |  |  | $ | 67.1 |  |  |  |  |  |
| Interest and other expense, net | 16.3 |  |  |  |  | 17.3 |  |  | 15.4 |  |  |  |  |  |
| Provision for income taxes | 18.1 |  |  |  |  | 7.0 |  |  | 16.5 |  |  |  |  |  |
| Depreciation | 20.4 |  |  |  |  | 21.0 |  |  | 23.8 |  |  |  |  |  |
| Amortization of acquired intangibles | 21.4 |  |  |  |  | 22.1 |  |  | 20.7 |  |  |  |  |  |
| EBITDA | 157.7 |  |  |  |  | 88.9 |  |  | 143.5 |  |  |  |  |  |
| Restructuring and related charges | (1.1) |  |  |  |  | 4.6 |  |  | — |  |  |  |  |  |
| Stock-based compensation | 24.8 |  |  |  |  | 24.2 |  |  | 19.5 |  |  |  |  |  |
| Inventory and fixed asset write down due to product line exits | — |  |  |  |  | — |  |  | 0.3 |  |  |  |  |  |
| Integration related costs | — |  |  |  |  | — |  |  | 0.3 |  |  |  |  |  |
| Other (gains) charges | (1.9) |  |  |  |  | (0.2) |  |  | 10.1 |  |  |  |  |  |
| Adjusted EBITDA | $ | 179.5 |  |  |  |  | $ | 117.5 |  |  | $ | 173.7 |  |  |  |  |  |
