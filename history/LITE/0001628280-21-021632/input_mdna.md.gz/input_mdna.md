# LITE MD&A — 0001628280-21-021632


## mdna

[0001628280-21-021632:mdna:1]
ITEM 2. MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0001628280-21-021632:mdna:2]
[same as prior period, unchanged from 0001633978-21-000009:mdna:2]

[0001628280-21-021632:mdna:3]
[same as prior period, unchanged from 0001633978-21-000009:mdna:3]

[0001628280-21-021632:mdna:4]
[same as prior period, unchanged from 0001633978-21-000009:mdna:4]

[0001628280-21-021632:mdna:5]
We are an industry-leading provider of optical and photonic products defined by revenue and market share, addressing a range of end-market applications including Optical Communications (“OpComms”) and Commercial Lasers (“Lasers”) for manufacturing, inspection and life-science applications.

[0001628280-21-021632:mdna:6]
We have two operating segments, OpComms and Lasers. The two operating segments were primarily determined based on how the Chief Operating Decision Maker (“CODM”) views and evaluates our operations. Operating results are regularly reviewed by the CODM to make decisions about resources to be allocated to the segments and to assess their performance. Other factors, including market separation and customer specific applications, go-to-market channels, products and manufacturing, are considered in determining the formation of these operating segments.

[0001628280-21-021632:mdna:7]
We believe the global markets in which Lumentum participates have fundamentally robust, long-term trends that increase the need for our photonics products and technologies. We believe the world is becoming more reliant on ever-increasing amounts of data flowing through optical networks and data centers. Lumentum’s products and technology enable the scaling of these optical networks and data centers to higher capacities. We expect the accelerating shift to digital and virtual approaches to all aspects of work and life that is driving staggering amounts of data in the world’s networks and cloud datacenters will continue into the future. Virtual meetings, video calls, and hybrid in-person and virtual environments for work and other aspects of life will continue to drive strong needs for bandwidth growth and present dynamic new technology challenges that our technology addresses. As manufacturers demand higher levels of precision, new materials, and factory and energy efficiency, suppliers of manufacturing tools globally are turning to laser based approaches, including the types of lasers Lumentum supplies. Laser based 3D sensing and LiDAR for security, industrial and automotive applications are rapidly developing markets. The technology enables computer vision applications that enhance security, safety, and new functionality in the electronic devices that people rely on every day. The use of LiDAR and in-cabin 3D sensing in automobile and delivery vehicles over time significantly adds to our long-term market opportunity. Frictionless and contactless biometric security and access control is of increasing focus globally given the world’s experience with the COVID-19 pandemic. Additionally, we expect 3D enabled machine vision solutions to expand significantly in industrial applications in the coming years.

[0001628280-21-021632:mdna:8]
To maintain and grow our market and technology leadership positions, we are continually investing in new and differentiated products and technologies and customer programs that address both nearer-term and longer-term growth opportunities, both organically and through acquisitions, as well as continually improving and optimizing our operations. Over many years, we have developed close relationships with market leading customers. We seek to use our core optical and photonic technology and our volume manufacturing capability to expand into attractive emerging markets that benefit from advantages that optical or photonics-based solutions provide.

[0001628280-21-021632:mdna:9]
[same as prior period, unchanged from 0001633978-21-000009:mdna:10]

[0001628280-21-021632:mdna:10]
The COVID-19 pandemic has caused public health officials to recommend, and governments to enact, precautions to mitigate the spread of the virus, including travel restrictions and bans, extensive social distancing guidelines, closure or restrictions on business and quarantine or other types of “shelter-in-place” orders in many regions of the world. The pandemic and these related responses have caused, and are expected to continue to cause a global slowdown of economic activity (including a decrease in demand for a broad variety of goods and services), disruptions in global supply chains, labor shortages, and significant volatility and potential disruption of financial markets. We have adopted several measures in response to the COVID-19 outbreak including complying with local, state or federal orders that require employees to work from home, instructing employees to work from home in certain jurisdictions, limiting the number of employees onsite which slowed our manufacturing operations in certain countries, enhanced use of personal protective equipment and restricting non-critical business travel by our employees.

[0001628280-21-021632:mdna:11]
In the geographies where we have operations, we have, in general, been deemed an essential business and been permitted to continue manufacturing and conducting new product development operations in a more limited capacity during the pandemic. This stems from our critical role in global supply chains for the world’s communications and health-care systems. Given the continually evolving situation, it is difficult to predict the magnitude and duration of the impact of the COVID-19 pandemic to our markets or precisely when our ability to supply our products will return to full capacity. We are continuing to actively monitor the situation and may take further actions altering our business operations that we determine are in the best interests of our employees, customers, communities, business partners, suppliers and stockholders, or as required by federal, state, or local authorities. It is not clear what the potential effects any such alterations or modifications may have on our business, including the effects on our customers, employees and prospects, or on our financial results for fiscal year 2022.

[0001628280-21-021632:mdna:12]
While COVID-19 did not have a material adverse effect on our reported results for our first quarter of fiscal 2022, we are actively monitoring the impact of the pandemic on our operations. The extent to which our operations will be impacted by the outbreak will depend largely on future developments, which are highly uncertain and cannot be accurately predicted, including new information which may emerge concerning the severity of the outbreak and additional variants, the speed, efficacy and acceptance of vaccine distributions, variant strains of the virus, actions by government authorities and private businesses to contain the severity of the outbreak and emerging variants in various geographies and the speed and trajectory of any recovery from the impact of the pandemic, among other things.

[0001628280-21-021632:mdna:13]
COVID-19 has also created dynamics in the semiconductor component supply chains that have led to shortages of the types of components we and our customers require in our products. These shortages have impacted our ability to generate revenue from certain products in early fiscal 2022 and, if our ability to procure needed semiconductor components does not improve, this will impact our ability to supply our products to our customers and may reduce our revenue and profit margin. In addition, if our customers are unable to procure needed semiconductor components, this could reduce their demand for our products and reduce our revenue. The impact of semiconductor component shortages may increase in the near term as supplier and customer buffer inventories and safety stocks are exhausted.

[0001628280-21-021632:mdna:14]
Our primary strategic focus for several years has been technology and product leadership combined with close customer relationships in long-term healthy and growing markets. We believe this strategy is even more apt, and our long-term opportunity is not diminished, with COVID-19. We believe there are long-term opportunities, as the world’s experience with COVID-19 could drive an increasingly digital and virtual world touching all aspects of life and work that increasingly emphasizes communications systems, cloud services, augmented and virtual reality, and enhanced security. Additionally, ever advancing electronic devices are needed to consume, produce, and communicate digital and virtual content. All these trends could drive the need for higher volumes of higher performing optical devices that we could supply. As such, we expect to continue to invest strongly in new products, technology and customer programs.

[0001628280-21-021632:mdna:15]
[same as prior period, unchanged from 0001633978-21-000009:mdna:16]

[0001628280-21-021632:mdna:16]
[same as prior period, unchanged from 0001633978-21-000009:mdna:17]

[0001628280-21-021632:mdna:17]
[same as prior period, unchanged from 0001633978-21-000009:mdna:18]

[0001628280-21-021632:mdna:18]
[same as prior period, unchanged from 0001633978-21-000009:mdna:19]

[0001628280-21-021632:mdna:19]
[same as prior period, unchanged from 0001633978-21-000009:mdna:20]

[0001628280-21-021632:mdna:20]
[same as prior period, unchanged from 0001633978-21-000009:mdna:21]

[0001628280-21-021632:mdna:21]
Management’s Discussion and Analysis of Financial Condition and Results of Operations contained in Part II, Item 7 of our Annual Report on Form 10-K for our fiscal year ended July 3, 2021 provides a more complete discussion of our critical accounting policies and estimates. There have been no significant changes to these policies during the three months ended October 2, 2021.

[0001628280-21-021632:mdna:22]
Recently Issued Accounting Pronouncements

[0001628280-21-021632:mdna:23]
Refer to “Note 2. Recently Issued Accounting Pronouncements” in the notes to condensed consolidated financial statements.

[0001628280-21-021632:mdna:24]
[same as prior period, unchanged from 0001633978-21-000009:mdna:26]

[0001628280-21-021632:mdna:25]
[same as prior period, unchanged from 0001633978-21-000009:mdna:27]

[0001628280-21-021632:mdna:26]
|  | Three Months Ended |  |  |
|  | October 2, 2021 |  | September 26, 2020 |  |  |  |  |
| Segment net revenue: |  |  |  |  |  |  |  |
| OpComms | 90.5 | % |  | 94.7 | % |  |  |  |  |
| Lasers | 9.5 |  |  | 5.3 |  |  |  |  |  |
| Net revenue | 100.0 |  |  | 100.0 |  |  |  |  |  |
| Cost of sales | 44.7 |  |  | 51.2 |  |  |  |  |  |
| Amortization of acquired developed intangibles | 3.5 |  |  | 3.3 |  |  |  |  |  |
| Gross profit | 51.8 |  |  | 45.5 |  |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 12.1 |  |  | 11.1 |  |  |  |  |  |
| Selling, general and administrative | 14.1 |  |  | 12.4 |  |  |  |  |  |
| Restructuring and related charges | (0.2) |  |  | — |  |  |  |  |  |
| Total operating expenses (income) | 25.9 |  |  | 23.6 |  |  |  |  |  |
| Income from operations | 25.8 |  |  | 21.9 |  |  |  |  |  |
| Interest expense | (3.8) |  |  | (3.5) |  |  |  |  |  |
| Other income, net | 0.1 |  |  | 0.1 |  |  |  |  |  |
| Income before income taxes | 22.2 |  |  | 18.5 |  |  |  |  |  |
| Provision for income taxes | 4.0 |  |  | 3.6 |  |  |  |  |  |
| Net income | 18.2 | % |  | 14.8 | % |  |  |  |  |

[0001628280-21-021632:mdna:27]
35

[0001628280-21-021632:mdna:28]
Financial Data for the three months ended October 2, 2021 and September 26, 2020

[0001628280-21-021632:mdna:29]
[same as prior period, unchanged from 0001633978-21-000009:mdna:31]

[0001628280-21-021632:mdna:30]
|  | Three Months Ended |  |  |  |  |  |  |  |  |  |  |
|  | October 2, 2021 |  | September 26, 2020 |  | Change |  | Percentage Change |  |  |  |  |  |  |  |  |
| Segment net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| OpComms | $ | 406.0 |  |  | $ | 428.5 |  |  | $ | (22.5) |  |  | (5.3) | % |  |  |  |  |  |  |  |  |
| Lasers | 42.4 |  |  | 23.9 |  |  | 18.5 |  |  | 77.4 |  |  |  |  |  |  |  |  |  |
| Net revenue | $ | 448.4 |  |  | $ | 452.4 |  |  | $ | (4.0) |  |  | (0.9) | % |  |  |  |  |  |  |  |  |
| Gross profit | $ | 232.2 |  |  | $ | 205.7 |  |  | $ | 26.5 |  |  | 12.9 | % |  |  |  |  |  |  |  |  |
| Gross margin | 51.8 | % |  | 45.5 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 54.1 |  |  | $ | 50.4 |  |  | $ | 3.7 |  |  | 7.3 | % |  |  |  |  |  |  |  |  |
| Percentage of net revenue | 12.1 | % |  | 11.1 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative | $ | 63.3 |  |  | $ | 56.3 |  |  | $ | 7.0 |  |  | 12.4 | % |  |  |  |  |  |  |  |  |
| Percentage of net revenue | 14.1 | % |  | 12.4 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring and related charges | $ | (1.1) |  |  | $ | — |  |  | $ | (1.1) |  |  | 100.0 | % |  |  |  |  |  |  |  |  |
| Percentage of net revenue | (0.2) | % |  | — | % |  |  |  |  |  |  |  |  |  |  |  |  |

[0001628280-21-021632:mdna:31]
[same as prior period, unchanged from 0001633978-21-000009:mdna:33]

[0001628280-21-021632:mdna:32]
Net revenue decreased by $4.0 million, or 0.9%, during the three months ended October 2, 2021 compared to the three months ended September 26, 2020. This decrease was due to $22.5 million lower OpComms revenue, partially offset by increased sales of Lasers of $18.5 million.

[0001628280-21-021632:mdna:33]
OpComms net revenue decreased by $22.5 million, or 5.3%, during the three months ended October 2, 2021 compared to the three months ended September 26, 2020. Within OpComms, Telecom and Datacom decreased by $45.3 million primarily a result of continued material and component shortages and lower demand due to continued delays in 5G deployments. Industrial and Consumer increased by $22.8 million due primarily to seasonality and timing of customer product releases, as well as an expansion of the available market as a result of an increased dollar content of 3D sensing lasers and higher adoption rates of 3D sensing in consumer electronic devices compared with the prior period.

[0001628280-21-021632:mdna:34]
Lasers net revenue increased by $18.5 million, or 77.4%, during the three months ended October 2, 2021 compared to the three months ended September 26, 2020, primarily due to a return in customer demand for our kilowatt class fiber lasers following the COVID-19 disruption in fiscal 2021.

[0001628280-21-021632:mdna:35]
During the three months ended October 2, 2021, our net revenue from a single customer, which represented 10% or greater of total net revenue was concentrated with one customer, who accounted for 41% of our total net revenue.

[0001628280-21-021632:mdna:36]
During the three months ended September 26, 2020, our net revenue from a single customer, which represented 10% or greater of total net revenue was concentrated with one customer, who accounted for 35% of our total net revenue.

[0001628280-21-021632:mdna:37]
[same as prior period, unchanged from 0001633978-21-000009:mdna:42]

[0001628280-21-021632:mdna:38]
We operate in three geographic regions: Americas, Asia-Pacific and EMEA. Net revenue is assigned to the geographic region and country where our product is initially shipped. For example, certain customers may request shipment of our product to a contract manufacturer in one country; however, the location of the end-customers may differ. The following table presents net revenue by the three geographic regions we operate in and net revenue from countries within those regions that represented 10% or more of our total net revenue (in millions, except for percentages):

[0001628280-21-021632:mdna:39]
|  | Three Months Ended |  |  |
|  | October 2, 2021 |  | September 26, 2020 |  |  |  |  |
|  | Amount |  | % of Total |  | Amount |  | % of Total |  |  |  |  |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States | $ | 28.1 |  |  | 6.3 | % |  | $ | 20.3 |  |  | 4.5 | % |  |  |  |  |  |  |  |  |
| Mexico | 33.0 |  |  | 7.4 |  |  | 39.8 |  |  | 8.8 |  |  |  |  |  |  |  |  |  |
| Other Americas | 2.0 |  |  | 0.4 |  |  | 2.8 |  |  | 0.6 |  |  |  |  |  |  |  |  |  |
| Total Americas | $ | 63.1 |  |  | 14.1 | % |  | $ | 62.9 |  |  | 13.9 | % |  |  |  |  |  |  |  |  |
| Asia-Pacific: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Hong Kong | $ | 142.3 |  |  | 31.7 | % |  | $ | 144.4 |  |  | 31.9 | % |  |  |  |  |  |  |  |  |
| Philippines | 9.1 |  |  | 2.0 |  |  | 62.8 |  |  | 13.9 |  |  |  |  |  |  |  |  |  |
| South Korea | 105.1 |  |  | 23.4 |  |  | 56.0 |  |  | 12.4 |  |  |  |  |  |  |  |  |  |
| Other Asia-Pacific | 103.0 |  |  | 23.0 |  |  | 91.6 |  |  | 20.2 |  |  |  |  |  |  |  |  |  |
| Total Asia-Pacific | $ | 359.5 |  |  | 80.1 | % |  | $ | 354.8 |  |  | 78.4 | % |  |  |  |  |  |  |  |  |
| EMEA | $ | 25.8 |  |  | 5.8 | % |  | $ | 34.7 |  |  | 7.7 | % |  |  |  |  |  |  |  |  |
| Total net revenue | $ | 448.4 |  |  |  |  | $ | 452.4 |  |  |  |  |  |  |  |  |  |  |  |

[0001628280-21-021632:mdna:40]
For the three months ended October 2, 2021 and September 26, 2020, net revenue from customers outside the United States, based on customer shipping location, represented 93.7% and 95.5% of net revenue, respectively.

[0001628280-21-021632:mdna:41]
[same as prior period, unchanged from 0001633978-21-000009:mdna:48]

[0001628280-21-021632:mdna:42]
[same as prior period, unchanged from 0001633978-21-000009:mdna:49]

[0001628280-21-021632:mdna:43]
The following table summarizes segment gross margin for the periods presented (in millions, except for percentages):

[0001628280-21-021632:mdna:44]
|  | Three Months Ended |  |  |
|  | Gross Profit |  | Gross Margin |  |  |  |  |
|  | October 2, 2021 |  | September 26, 2020 |  | October 2, 2021 |  | September 26, 2020 |  |  |  |  |  |  |  |  |
| OpComms | $ | 225.9 |  |  | $ | 224.8 |  |  | 55.6 | % |  | 52.5 | % |  |  |  |  |  |  |  |  |
| Lasers | 20.8 |  |  | 10.4 |  |  | 49.1 | % |  | 43.5 | % |  |  |  |  |  |  |  |  |
| Segment total | $ | 246.7 |  |  | $ | 235.2 |  |  | 55.0 | % |  | 52.0 | % |  |  |  |  |  |  |  |  |
| Unallocated corporate items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation | (4.6) |  |  | (3.7) |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of acquired intangibles | (15.8) |  |  | (15.0) |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Inventory and fixed asset write down due to product line exits | — |  |  | (0.3) |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other (charges) gains (1) | 5.9 |  |  | (10.5) |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total | $ | 232.2 |  |  | $ | 205.7 |  |  | 51.8 | % |  | 45.5 | % |  |  |  |  |  |  |  |  |

[0001628280-21-021632:mdna:45]
37

[0001628280-21-021632:mdna:46]
(1) “Other (charges) gains” of unallocated corporate items for the three months ended October 2, 2021 primarily relate to $5.9 million gain as a result of selling equipment that was no longer needed after we transferred certain product lines to new production facilities in fiscal 2021. “Other (charges) gains” of unallocated corporate items for the three months ended September 26, 2020 primarily  include  costs  of  $2.1 million of transferring certain product lines to new production facilities  and excess and obsolete inventory charges of $5.9 million driven by U.S. trade restrictions and the related decline in demand from Huawei.

[0001628280-21-021632:mdna:47]
[same as prior period, unchanged from 0001633978-21-000009:mdna:54]

[0001628280-21-021632:mdna:48]
[same as prior period, unchanged from 0001633978-21-000009:mdna:55]

[0001628280-21-021632:mdna:49]
Gross margin for the three months ended October 2, 2021 increased to 51.8% from 45.5% for the three months ended September 26, 2020. The increase was primarily driven by higher gross margin from both OpComms and Lasers segment for the three months ended October 2, 2021 compared to the three months ended September 26, 2020. The increase in gross margin during the three months ended October 2, 2021 as compared to the three months ended September 26, 2020 was also due to lower excess and obsolescence charges.

[0001628280-21-021632:mdna:50]
[same as prior period, unchanged from 0001633978-21-000009:mdna:58]

[0001628280-21-021632:mdna:51]
[same as prior period, unchanged from 0001633978-21-000009:mdna:59]

[0001628280-21-021632:mdna:52]
[same as prior period, unchanged from 0001633978-21-000009:mdna:60]

[0001628280-21-021632:mdna:53]
[same as prior period, unchanged from 0001633978-21-000009:mdna:61]

[0001628280-21-021632:mdna:54]
OpComms gross margin for the three months ended October 2, 2021 increased to 55.6% from 52.5% for the three months ended September 26, 2020. The increase was primarily due to a more profitable mix of products, including higher sales of higher margin 3D sensing products and benefits from ongoing operational improvements.

[0001628280-21-021632:mdna:55]
[same as prior period, unchanged from 0001633978-21-000009:mdna:64]

[0001628280-21-021632:mdna:56]
Lasers gross margin for the three months ended October 2, 2021 increased to 49.1% from 43.5% for the three months ended September 26, 2020. This increase was primarily due to the higher manufacturing levels related to the return in customer demand for our kilowatt class fiber products, following the COVID-19 disruption in fiscal 2021.

[0001628280-21-021632:mdna:57]
[same as prior period, unchanged from 0001633978-21-000009:mdna:67]

[0001628280-21-021632:mdna:58]
R&D expense increased by $3.7 million, or 7.3%, for the three months ended October 2, 2021 compared to the three months ended September 26, 2020. The increase in R&D expense was primarily driven by increased payroll and compensation expenses due to additional headcount and increased costs in supplies and tooling for R&D projects.

[0001628280-21-021632:mdna:59]
[same as prior period, unchanged from 0001633978-21-000009:mdna:70]

[0001628280-21-021632:mdna:60]
[same as prior period, unchanged from 0001633978-21-000009:mdna:71]

[0001628280-21-021632:mdna:61]
SG&A expense increased by $7.0 million, or 12.4%, during the three months ended October 2, 2021 compared to the three months ended September 26, 2020. The increase in SG&A expense was primarily attributable to increased payroll and compensation expenses due to additional headcount and expenses incurred related to optimizing our tax structure.

[0001628280-21-021632:mdna:62]
From time to time, we incur non-recurring expenses, such as mergers and acquisition-related expenses, for example, those related to our pending acquisition of NeoPhotonics, which will likely increase our SG&A expenses in the near term and potentially impact our profitability expectations in any particular quarter.

[0001628280-21-021632:mdna:63]
[same as prior period, unchanged from 0001633978-21-000009:mdna:75]

[0001628280-21-021632:mdna:64]
[same as prior period, unchanged from 0001633978-21-000009:mdna:76]

[0001628280-21-021632:mdna:65]
During the three months ended October 2, 2021, we recorded a net reversal to our restructuring and related charges of $1.1 million in our condensed consolidated statements of operations which was attributable to lower than anticipated employee severance charges primarily as a result of retaining and re-assigning certain employees.

[0001628280-21-021632:mdna:66]
During the three months ended September 26, 2020, we did not record any restructuring and related charges in our condensed consolidated statements of operations.

[0001628280-21-021632:mdna:67]
[same as prior period, unchanged from 0001633978-21-000009:mdna:83]

[0001628280-21-021632:mdna:68]
For the three months ended October 2, 2021 and September 26, 2020, we recorded interest expense of $16.9 million and $16.0 million, respectively. The increase was driven by the amortization of the debt discount and issuance costs of our 2024 Notes and 2026 Notes.

[0001628280-21-021632:mdna:69]
[same as prior period, unchanged from 0001633978-21-000009:mdna:86]

[0001628280-21-021632:mdna:70]
[same as prior period, unchanged from 0001633978-21-000009:mdna:87]

[0001628280-21-021632:mdna:71]
|  | Three Months Ended |  |  |  |  |
|  | October 2, 2021 |  | September 26, 2020 |  |  |  |  |  |  |
| Foreign exchange gains (losses), net | $ | (0.1) |  |  | $ | (2.3) |  |  |  |  |  |  |  |
| Interest and investment income | 0.6 |  |  | 2.4 |  |  |  |  |  |  |  |
| Other income (expense), net | 0.1 |  |  | 0.5 |  |  |  |  |  |  |  |
| Total other income (expense), net | $ | 0.6 |  |  | $ | 0.6 |  |  |  |  |  |  |  |

[0001628280-21-021632:mdna:72]
For the three months ended October 2, 2021, other income (expense), net remained constant as compared to the three months ended September 26, 2020.  During the three months ended October 2, 2021, we recorded $2.2 million less in foreign exchange losses as compared to the three months ended September 26, 2020 as a result of more stable exchange rates between the U.S. dollar and certain foreign currencies. The $1.8 million decrease in interest and investment income during the three months ended October 2, 2021 as compared to the three months ended September 26, 2020 is a result of our  cash equivalent  and investments acquired before COVID-19 maturing and being reinvested at lower yielding investments, while our average maturity and liquidity profile remained consistent.

[0001628280-21-021632:mdna:73]
Provision for Income Taxes

[0001628280-21-021632:mdna:74]
| (in millions) | Three Months Ended |  |  |
|  | October 2, 2021 |  | September 26, 2020 |  |  |  |  |
| Provision for income taxes | $ | 18.1 |  |  | $ | 16.5 |  |  |  |  |  |

[0001628280-21-021632:mdna:75]
We recorded a tax provision of $18.1 million and $16.5 million for the three months ended October 2, 2021 and September 26, 2020, respectively. Our tax provision for the three months ended October 2, 2021 includes a discrete tax expense of $1.1 million primarily related to return-to-provision differences. Our estimated effective tax rate for fiscal 2022 differs from the 21% U.S. statutory rate primarily due to the income tax benefit from the earnings of our foreign subsidiaries being taxed at rates that differ from the U.S. statutory rate and U.S. federal R&D tax credits, partially offset by the income tax expense from the tax effect of Global Intangible Low-Taxed Income (“GILTI”), net of benefit for foreign tax credits, subpart F inclusion and non-deductible stock-based compensation.

[0001628280-21-021632:mdna:76]
[same as prior period, unchanged from 0001633978-21-000009:mdna:103]

[0001628280-21-021632:mdna:77]
[same as prior period, unchanged from 0001633978-21-000009:mdna:104]

[0001628280-21-021632:mdna:78]
As of October 2, 2021 and July 3, 2021, our cash and cash equivalents of $611.0 million and $774.3 million, respectively, were largely held in the United States. As of October 2, 2021 and July 3, 2021, our short-term investments of $1,273.6 million and $1,171.7 million, respectively, were all held in the United States. Cash equivalents and short-term investments are primarily comprised of money market funds and US treasury securities. Our investment policy and strategy is focused on the preservation of capital and supporting our liquidity requirements.

[0001628280-21-021632:mdna:79]
The total amount of cash outside the United States held by the non-United States entities as of October 2, 2021 was $185.3 million, which was primarily held by entities incorporated in the United Kingdom, the British Virgin Islands, Japan, Hong Kong, China, Canada and Thailand. Although the cash currently held in the United States, as well as the cash generated in the United States from future operations, is expected to cover our normal operating requirements, a substantial amount of additional cash could be required for other purposes, such as capital expenditures to support our business and growth, including costs associated with increasing internal manufacturing capabilities, particularly in our Thailand facility, strategic transactions and partnerships, and future acquisitions.

[0001628280-21-021632:mdna:80]
[same as prior period, unchanged from 0001633978-21-000009:mdna:107]

[0001628280-21-021632:mdna:81]
[same as prior period, unchanged from 0001633978-21-000009:mdna:110]

[0001628280-21-021632:mdna:82]
We believe that our cash and cash equivalents as of October 2, 2021 and cash flows from our operating activities will be sufficient to meet our liquidity and capital spending requirements for at least the next 12 months. However, if market conditions are favorable, we may evaluate alternatives to opportunistically pursue additional financing.

[0001628280-21-021632:mdna:83]
[same as prior period, unchanged from 0001633978-21-000009:mdna:112]

[0001628280-21-021632:mdna:84]
[same as prior period, unchanged from 0001633978-21-000009:mdna:113]

[0001628280-21-021632:mdna:85]
[same as prior period, unchanged from 0001633978-21-000009:mdna:114]

[0001628280-21-021632:mdna:86]
[same as prior period, unchanged from 0001633978-21-000009:mdna:115]

[0001628280-21-021632:mdna:87]
[same as prior period, unchanged from 0001633978-21-000009:mdna:116]

[0001628280-21-021632:mdna:88]
[same as prior period, unchanged from 0001633978-21-000009:mdna:117]

[0001628280-21-021632:mdna:89]
[same as prior period, unchanged from 0001633978-21-000009:mdna:118]

[0001628280-21-021632:mdna:90]
[same as prior period, unchanged from 0001633978-21-000009:mdna:119]

[0001628280-21-021632:mdna:91]
[same as prior period, unchanged from 0001633978-21-000009:mdna:120]

[0001628280-21-021632:mdna:92]
•investments or acquisitions of complementary businesses, products or technologies, or other strategic transactions or partnerships;

[0001628280-21-021632:mdna:93]
[same as prior period, unchanged from 0001633978-21-000009:mdna:122]

[0001628280-21-021632:mdna:94]
•funding of pension liabilities either voluntarily or as required by law or regulation;

[0001628280-21-021632:mdna:95]
•the settlement of any conversion or redemption of the 2024 Notes and the 2026 Notes in cash;

[0001628280-21-021632:mdna:96]
•common stock repurchases under the 2021 share buyback program;

[0001628280-21-021632:mdna:97]
•payment of tax obligations; and

[0001628280-21-021632:mdna:98]
•acquisitions, in particular our recently announced acquisition of NeoPhotonics

[0001628280-21-021632:mdna:99]
The following table summarizes certain of our contractual obligations as of October 2, 2021, and the effect such obligations are expected to have on our liquidity and cash flow over the next five years (in millions):

[0001628280-21-021632:mdna:100]
|  | Payments due by period |
|  | Total |  | Less than 1 year |  | 1 - 3 years |  | 3 - 5 years |  | More than 5 years |
| Contractual Obligations |  |  |  |  |  |  |  |  |  |
| Asset retirement obligations | $ | 4.7 |  |  | $ | — |  |  | $ | 1.6 |  |  | $ | 1.6 |  |  | $ | 1.5 |  |
| Operating lease liabilities, including imputed interest (1) | 77.8 |  |  | 13.7 |  |  | 23.4 |  |  | 16.3 |  |  | 24.4 |  |
| Pension plan contributions (2) | 0.5 |  |  | 0.5 |  |  | — |  |  | — |  |  | — |  |
| Purchase obligations (3) | 260.4 |  |  | 247.7 |  |  | 12.6 |  |  | 0.1 |  |  | — |  |
| Convertible notes - principal (4) | 1,500.0 |  |  | — |  |  | 450.0 |  |  | — |  |  | 1,050.0 |  |
| Convertible notes - interest (4) | 31.6 |  |  | 6.4 |  |  | 12.2 |  |  | 10.5 |  |  | 2.5 |  |
| Total | $ | 1,875.0 |  |  | $ | 268.3 |  |  | $ | 499.8 |  |  | $ | 28.5 |  |  | $ | 1,078.4 |  |

[0001628280-21-021632:mdna:101]
(1) The amounts of operating lease liabilities in the table above do not include any sublease income amounts nor do they include payments for short-term leases or variable lease payments. As of October 2, 2021, we expect to receive sublease income of approximately $2.8 million over the next two years. Refer to “Note 7. Leases” in the notes to condensed consolidated financial statements.

[0001628280-21-021632:mdna:102]
[same as prior period, unchanged from 0001633978-21-000009:mdna:97]

[0001628280-21-021632:mdna:103]
(3) Purchase obligations represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Refer to “Note 14. Commitments and Contingencies” in the notes to condensed consolidated financial statements.

[0001628280-21-021632:mdna:104]
(4) Includes principal and interest payment in cash on our 0.25% Convertible Notes due in 2024 (the “2024 Notes”) through March 2024, and principal and interest on our 0.50% Convertible Notes due in 2026 (the “2026 Notes” and together with the 2024 Notes, the “Notes”) through December 2026. We have the right to redeem the 2024 Notes and the 2026 Notes in whole or in part at any time on or after March 15, 2024 and on or after December 15, 2026, respectively. The principal balances of our Notes are reflected in the payment periods in the table above based on their respective contractual maturities assuming no conversion. Refer to “Note 9. Debt” in the notes to condensed consolidated financial statements.

[0001628280-21-021632:mdna:105]
We do not have any off-balance sheet arrangements, as such term is defined in rules promulgated by the SEC, that have or are reasonably likely to have a current or future effect on our liquidity or capital resources that are material to investors.

[0001628280-21-021632:mdna:106]
Indebtedness

[0001628280-21-021632:mdna:107]
As of October 2, 2021, the debt component of our 2024 Notes of $395.8 million (principal balance of $450.0 million maturing in 2024) is presented in current liabilities in our condensed consolidated balance sheet since our stock price exceeded $78.80 for 20 of the last 30 trading days of the quarter ended October 2, 2021 and the 2024 Notes are convertible at the option of the holders. During the three months ended October 2, 2021, we received conversion requests for less than $0.1 million principal amount of the 2024 Notes, which were settled in cash in the first quarter of fiscal 2022.

[0001628280-21-021632:mdna:108]
As of October 2, 2021, the debt component of our 2026 Notes of $800.0 million (principal balance of $1,050.0 million maturing in 2026) is presented in non-current liabilities. If the closing price of our stock exceeds $129.08 for 20 of the last 30 trading days of any future quarter, our 2026 Notes would also become convertible at the option of the holders and the debt component would be reclassified to current liabilities in our condensed consolidated balance sheet.

[0001628280-21-021632:mdna:109]
Share Buyback Program

[0001628280-21-021632:mdna:110]
On May 7, 2021, our board of directors approved the two year share buyback program, which authorizes the repurchase of up to $700.0 million of our own shares of common stock, in the open market or in privately negotiated transactions. In the fiscal first quarter of 2022, we repurchased 1.1 million shares of our common stock at an average price of $82.45 per share for an aggregate purchase price of $91.7 million.

[0001628280-21-021632:mdna:111]
Since the share buyback program was approved by the board of directors, we have repurchased in aggregate, a total of 4.2 million shares of our common stock at an average price of $79.05 per share for total proceeds of $332.7 million. All repurchased shares were retired immediately. The price, timing, amount, and method of such repurchases will be determined based on the valuation of market conditions and other factors, at prices determined to be attractive and in the best interests of both Lumentum and our stockholders.

[0001628280-21-021632:mdna:112]
Unrecognized Tax Benefits

[0001628280-21-021632:mdna:113]
As of October 2, 2021, our other non-current liabilities also include $24.7 million of unrecognized tax benefit for uncertain tax positions. We are unable to reliably estimate the timing of future payments related to uncertain tax positions.

[0001628280-21-021632:mdna:114]
Cash Flows

[0001628280-21-021632:mdna:115]
As of October 2, 2021, our balance of cash and cash equivalents decreased by $163.3 million, to $611.0 million from $774.3 million as of July 3, 2021. The decrease in cash and cash equivalents during the three months ended October 2, 2021 was due to lower cash provided by operating activities of $61.9 million, and higher cash used in investing activities of $116.9 million and financing activities of $108.3 million, respectively.

[0001628280-21-021632:mdna:116]
[same as prior period, unchanged from 0001633978-21-000009:mdna:127]

[0001628280-21-021632:mdna:117]
Cash provided by operating activities was $61.9 million during the three months ended October 2, 2021. Our net income was $81.5 million for the three months ended October 2, 2021. Cash provided by operating activities was also generated from $79.9 million of non-cash items (such as depreciation, stock-based compensation, amortization of intangibles, amortization of debt discount and debt issuance costs, and other non-cash charges), offset by $99.5 million of changes in our operating assets and liabilities. Changes in our operating assets and liabilities related primarily to an increase in accounts receivable of $50.4 million and inventories of $10.3 million, offset by a decrease in income taxes, net of $18.1 million, a decrease of accrued payroll and related expenses of $11.4 million, and a decrease in accounts payable of $10.5 million.

[0001628280-21-021632:mdna:118]
Cash provided by operating activities was $104.7 million during the three months ended September 26, 2020. Our net income was $67.1 million for the three months ended September 26, 2020. Cash provided by operating activities was generated primarily from $80.3 million of non-cash items (such as depreciation, stock-based compensation, amortization of intangibles, amortization of debt discount and debt issuance costs on our convertible notes, and other non-cash charges), offset by $42.7 million of changes in our operating assets and liabilities. Changes in our operating assets and liabilities related primarily to an increase in accounts receivable of $30.3 million and inventories of $22.9 million, offset by an increase in accrued expenses and other current and non-current liabilities of $16.3 million.

[0001628280-21-021632:mdna:119]
[same as prior period, unchanged from 0001633978-21-000009:mdna:130]

[0001628280-21-021632:mdna:120]
Cash used in investing activities of $116.9 million during the three months ended October 2, 2021 was primarily attributable to purchases of short-term investments, net of sales and maturities of $104.9 million, capital expenditures of $17.9 million, partially offset by proceeds from the sales of property, plant and equipment of $5.9 million.

[0001628280-21-021632:mdna:121]
Cash used in investing activities of $114.0 million during the three months ended September 26, 2020 was primarily attributable to purchases of short-term investments, net of sales and maturities of $88.2 million and capital expenditures of $26.3 million.

[0001628280-21-021632:mdna:122]
[same as prior period, unchanged from 0001633978-21-000009:mdna:133]

[0001628280-21-021632:mdna:123]
Cash used in financing activities of $108.3 million during the three months ended October 2, 2021 resulted primarily from the repurchase of shares of our common stock of $91.7 million and tax payments related to restricted stock of $16.6 million.

[0001628280-21-021632:mdna:124]
Cash used in financing activities of $19.2 million during the three months ended September 26, 2020 resulted primarily from tax payments related to restricted stock of $19.1 million.
