# LITE notes — 0001628280-24-038024


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001628280-24-038024:notes:1]
Portions of the information called for by Part III of this Annual Report on Form 10-K are hereby incorporated by reference from the definitive proxy statement for the registrant’s annual meeting of stockholders, which will be filed with the Securities and Exchange Commission not later than 120 days after the registrant’s fiscal year ended June 29, 2024.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001628280-24-038024:notes:2]
Note 1. Description of Business and Summary of Significant Accounting Policies

[0001628280-24-038024:notes:3]
Description of Business

[0001628280-24-038024:notes:4]
Lumentum Holdings Inc. (“we,” “us,” “our”, “Lumentum” or the “Company”) is an industry-leading provider of optical and photonic products essential to a range of cloud, artificial intelligence and machine learning (“AI/ML”), telecomunications, consumer, and industrial end-market applications. We operate in two end-market focused reportable segments, Cloud & Networking and Industrial Tech.

[0001628280-24-038024:notes:5]
Our Cloud & Networking products include a comprehensive portfolio of optical and photonic components, modules, and subsystems supplied to network operator and network equipment manufacturer customers building cloud data center infrastructure, including products for artificial intelligence and machine learning (“AI/ML”) and data center interconnect (“DCI”) applications, and communications service provider networks, including products for access (local), metro (intracity), long-haul (city-to-city and worldwide), and submarine (undersea) network infrastructure. Our Cloud & Networking products also support network equipment manufacturers building enterprise network infrastructure, including storage-area networks (“SANs”), local-area networks (“LANs”) and wide-area networks (“WANs”). Demand for our Cloud & Networking products is driven by the continual growth in network capacity required for cloud computing and services, including for AI/ML, streaming video and video conferencing, wireless and mobile devices, and internet of things (“IoT”).

[0001628280-24-038024:notes:6]
Our Industrial Tech products include solid-state lasers, kilowatt-class fiber lasers, ultrafast lasers, diode lasers, and gas lasers, which address applications in numerous end-markets. In the consumer end-market, our laser light sources are integrated into our customers’ 3D sensing cameras, which are used in mobile devices, payment kiosks, and other consumer electronics devices to enable applications including biometric identification, computational photography and virtual and augmented reality. In the automotive end-market, our lasers are used in our customers’ LiDAR and other optical sensor devices, which are increasingly being used in advanced driver assistance systems (“ADAS”) and in-cabin driver and occupant monitoring systems. In the industrial manufacturing end-market, our lasers are incorporated into our customers’ manufacturing machine tools used for the precision processing of materials in a range of industries including semiconductor device and microelectronics fabrication, electric vehicle and battery production, metal cutting and welding, and advanced manufacturing. Our products can also be used in the industrial end-market in imaging and sensing systems for process feedback and control, quality assurance, and waste reduction. Adoption of our products in the industrial end-market is driven by the needs of customers to advance semiconductor and microelectronics industry roadmaps, and by Industry 4.0/5.0 trends, including increasing manufacturing precision and flexibility and reducing waste and environmental impact. Demand for our products in the industrial end-market is driven by end-customer investments in manufacturing capacity. Our lasers also address certain semiconductor inspection and life-science applications.

[0001628280-24-038024:notes:7]
Basis of Presentation

[0001628280-24-038024:notes:8]
We have prepared the consolidated financial statements in accordance with U.S. generally accepted accounting principles (“GAAP”), which requires management to make estimates and assumptions that affect the amounts reported in our consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates. Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. These policies are inventory valuation, revenue recognition, income taxes, goodwill and business combinations.

[0001628280-24-038024:notes:9]
Prior to fiscal year 2024, we operated in two reportable segments consisting of Optical Communications (“OpComms”) and Commercial Lasers (“Lasers”). During the fiscal first quarter of 2024, we changed our organizational structure to better align with trends in our markets and our customer and product mix. Our new operating segments are Cloud & Networking and Industrial Tech. The Cloud & Networking segment includes the Telecom and Datacom product lines that were previously part of the OpComms segment. The Industrial Tech segment includes the previous Lasers segment and the Industrial & Consumer product lines that were previously part of the OpComms segment. Comparative prior period segment information has been recast to conform to the new segment structure and measures. The changes in our operating segments had no impact on our previously reported consolidated results of operations, financial condition, or cash flows. Refer to “Note 17. Operating Segments and Geographic Information”.

[0001628280-24-038024:notes:10]
Our business and operating results depend significantly on general market and economic conditions. The current global macroeconomic environment is volatile and continues to be adversely impacted by inflation, a dynamic supply chain and demand environment, and signs of a weaker macroeconomic environment impacting capital expenditures across our served

[0001628280-24-038024:notes:11]
markets. Additionally, instability in the global credit markets, capital expenditure reductions, unemployment and other labor issues, decline in stock markets, the instability in the geopolitical environment in many parts of the world, and the current global economic challenges continue to put pressure on our business and operating results.

[0001628280-24-038024:notes:12]
We are also continuously monitoring both the current developments in the ongoing Russia-Ukraine war including the related export controls and resulting sanctions imposed on Russia and Belarus by the U.S. and other countries, and the Israel-Hamas war. Additional factors such as increased inflation, escalating energy costs, constrained raw material availability, and the related costs increases, could continue to impact the global economy and our business.  Although the global implications of these wars are difficult to predict at this time, we do not presently foresee direct material adverse effects upon our business.

[0001628280-24-038024:notes:13]
Fiscal Years

[0001628280-24-038024:notes:14]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Every fifth or sixth fiscal year will have a 53-week period. The additional week in a 53-week year is added to the third quarter, making such quarter consist of 14 weeks. Our fiscal 2024, 2023 and 2022 were 52-week years, ending on June 29, 2024, July 1, 2023 and July 2, 2022, respectively.

[0001628280-24-038024:notes:15]
Principles of Consolidation

[0001628280-24-038024:notes:16]
The consolidated financial statements are prepared in accordance with GAAP and includes the accounts of Lumentum Holdings Inc. and its wholly owned subsidiaries. Intercompany transactions and balances are fully eliminated in consolidation.

[0001628280-24-038024:notes:17]
Business Combination

[0001628280-24-038024:notes:18]
On November 7, 2023, we completed the acquisition of Cloud Light Technology Limited (“Cloud Light”). On August 3, 2022, we completed the acquisition of NeoPhotonics Corporation (“NeoPhotonics”). On August 15, 2022, we completed the acquisition of IPG Photonics’ telecom transmission product lines. We have applied the acquisition method of accounting to account for these transactions in accordance with ASC Topic 805, Business Combinations. Our condensed consolidated financial statements include the operating results of the acquired entities from the acquisition close date. Refer to “Note 4. Business Combination”.

[0001628280-24-038024:notes:19]
Summary of Significant Accounting Policies

[0001628280-24-038024:notes:20]
Our significant accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. We believe that of our significant accounting policies described below, involve a greater degree of judgment and complexity and are the most critical to aid in fully understanding and evaluating our consolidated financial statements. These policies include inventory valuation, revenue recognition, income taxes, goodwill and business combinations. For a description of our critical accounting policies, also refer to “Management’s Discussion and Analysis of Financial Condition and Results of Operations”, Critical Accounting Policies and Estimates.

[0001628280-24-038024:notes:21]
Cash Equivalents

[0001628280-24-038024:notes:22]
We consider highly liquid fixed income securities with original maturities of three months or less at the time of purchase to be cash equivalents. As of June 29, 2024, our cash equivalents consist of money market funds, U.S. Agency securities and U.S. Treasury securities.

[0001628280-24-038024:notes:23]
Short-Term Investments

[0001628280-24-038024:notes:24]
We classify our investments in debt securities as available-for-sale and record these investments at fair value. Investments with an original maturity of three months or less at the date of purchase are considered cash equivalents, while all other investments are classified as short-term based on management’s intent and ability to use the funds in current operations. Unrealized gains and losses are reported as a component of other comprehensive income (loss). Realized gains and losses are determined based on the specific identification method, and are reflected as other income (expense), net in our consolidated statements of operations.

[0001628280-24-038024:notes:25]
We regularly review our investment portfolio to identify and evaluate investments that have indicators of possible impairment. Factors considered in determining whether a loss is other-than-temporary include, but are not limited to: the length of time and extent a security’s fair value has been below its cost, the financial condition and near-term prospects of the investee, the credit quality of the security’s issuer, likelihood of recovery and our intent and ability to hold the security for a period of time sufficient to allow for any anticipated recovery in value. For our debt instruments, we also evaluate whether we have the intent to sell the security, or it is more likely than not that we will be required to sell the security before recovery of its cost basis.

[0001628280-24-038024:notes:26]
Fair Value of Financial Instruments

[0001628280-24-038024:notes:27]
We define fair value as the price that would be received from selling an asset, or paid to transfer a liability, in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities which are required to be recorded at fair value, we consider the principal or most advantageous market in which to transact and the market-based risk. We apply fair value accounting for all financial assets and liabilities that are recognized or disclosed at fair value in the financial statements on a recurring basis. The carrying amounts reported in the consolidated financial statements approximate the fair value for cash, accounts receivable, accounts payable and accrued liabilities due to their short-term nature.

[0001628280-24-038024:notes:28]
Basic and Diluted Net Income (Loss) per Common Share

[0001628280-24-038024:notes:29]
Basic income (loss) per share is computed by dividing net income available to common stockholders by the weighted average number of common shares outstanding during the reporting period. The weighted average number of shares is calculated by taking the number of shares outstanding and weighting them by the amount of time that they were outstanding. Diluted income per share reflects the potential dilution that could occur if stock options, preferred stock, and other commitments to issue common stock were exercised or equity awards vest resulting in the issuance of common stock that could share in the earnings of the Company. Diluted loss per share is the same as basic loss per share during periods where net losses are incurred since the inclusion of the potential common stock equivalents would be anti-dilutive as a result of the net loss.

[0001628280-24-038024:notes:30]
Potentially dilutive common shares result from the assumed exercise of outstanding stock options, assumed vesting of outstanding equity awards, assumed issuance of stock under the employee stock purchase plan, and assumed conversion of our outstanding $1,050.0 million in aggregate principal amount of 2026 Notes, $861.0 million in aggregate principal amount of 2028 Notes, and $603.7 million in aggregate principle amount of 2029 Notes (collectively, the “convertible notes”). We used the treasury stock method for all convertible notes in the diluted net income per share calculation for the year ended July 2, 2022 as we had the ability and intent to settle the face value of the convertible notes in cash. Upon adoption of ASU 2020-06 on July 3, 2022, we used the if-converted method for all convertible notes in the diluted net income per share calculation.

[0001628280-24-038024:notes:31]
The dilutive effect of securities from the 2015 Equity Incentive Plan is reflected in diluted earnings per share by application of the treasury stock method, which includes consideration of unamortized share-based compensation expense and the dilutive effect of in-the-money options and non-vested restricted stock units. Under the treasury stock method, the amount the employee must pay for exercising stock options and the amount of unamortized share-based compensation expense are collectively assumed to be used to repurchase hypothetical shares. An increase in the fair value of our common stock can result in a greater dilutive effect from potentially dilutive awards.

[0001628280-24-038024:notes:32]
Anti-dilutive potential shares from 2015 Equity Incentive Plan are excluded from the calculation of diluted earnings per share if their exercise price exceeded the average market price during the period or the share-based awards were determined to be anti-dilutive based on applying the treasury stock method.

[0001628280-24-038024:notes:33]
Inventory Valuation

[0001628280-24-038024:notes:34]
Inventory is recorded at standard cost, which approximates actual cost computed on a first-in, first-out basis, not in excess of net realizable value. We assess the value of our inventory on a quarterly basis and write down those inventories which are obsolete or in excess of our forecasted demand to the lower of their cost or estimated net realizable value. Our estimates of forecasted demand are based upon our analysis and assumptions including, but not limited to, expected product lifecycles, product development plans and historical usage by product. Our product line management personnel play a key role in our excess review process by providing updated sales forecasts, managing product transitions and working with manufacturing to minimize excess inventory. If actual market conditions are less favorable than our forecasts, or actual demand from our customers is lower than our estimates, we may be required to record additional inventory write-downs. If actual market conditions are more favorable than anticipated, inventory previously written down may be sold, resulting in lower cost of sales and higher income from operations than expected in that period.

[0001628280-24-038024:notes:35]
Leases

[0001628280-24-038024:notes:36]
We determine if an arrangement is a lease at inception for arrangements with an initial term of more than 12 months, and classify it as either a finance or operating lease pursuant to Topic 842.

[0001628280-24-038024:notes:37]
Finance leases are generally those that allow us to substantially utilize or pay for the entire asset over its estimated useful life. Finance leases are recorded in property, plant and equipment, net, and finance lease liabilities within other current and other non-current liabilities on our consolidated balance sheets. We have lease arrangements with lease and non-lease

[0001628280-24-038024:notes:38]
components, and the non-lease components for our finance leases are accounted for separately, based on estimated stand-alone values, and are not included in the initial measurement of our finance lease assets and corresponding liabilities. Finance lease assets are amortized in operating expenses on a straight-line basis over the shorter of the estimated useful lives of the assets or the lease term, with the interest component included in interest expense and recognized using the effective interest method over the lease term.

[0001628280-24-038024:notes:39]
Operating leases are recorded in operating lease right-of-use assets, net, and operating lease liabilities, current and non-current on our consolidated balance sheets. For operating leases of buildings, we account for non-lease components, such as common area maintenance, as a component of the lease, and include it in the initial measurement of our operating lease assets and corresponding liabilities. Operating lease assets are amortized on a straight-line basis in operating expenses over the lease term.

[0001628280-24-038024:notes:40]
Our lease liabilities are recognized based on the present value of the remaining fixed lease payments, over the lease term, using a discount rate of similarly secured borrowings available to us. For the purpose of lease liability measurement, we consider only payments that are fixed and determinable at the time of commencement. Any variable payments that depend on an index or rate are expensed as incurred. Our lease terms may include options to extend when it is reasonably certain that we will exercise that option. Our lease assets also include any lease payments made and exclude any lease incentives received prior to commencement. Our lease assets are tested for impairment in the same manner as long-lived assets used in operations. We generally recognize sublease income on a straight-line basis over the sublease term.

[0001628280-24-038024:notes:41]
Revenue Recognition

[0001628280-24-038024:notes:42]
Pursuant to Topic 606, we recognize our revenues upon the application of the following steps:

[0001628280-24-038024:notes:43]
•identification of the contract, or contracts, with a customer;

[0001628280-24-038024:notes:44]
•identification of the performance obligations in the contract;

[0001628280-24-038024:notes:45]
•determination of the transaction price;

[0001628280-24-038024:notes:46]
•allocation of the transaction price to the performance obligations in the contract; and

[0001628280-24-038024:notes:47]
•recognition of revenues when, or as, the contractual performance obligations are satisfied.

[0001628280-24-038024:notes:48]
The majority of our revenue comes from product sales, consisting of sales of hardware products to our customers. Our revenue contracts generally include only one performance obligation. Revenues are recognized at a point in time when control of the promised goods or services are transferred to our customers upon shipment or delivery of goods or rendering of services, in an amount that reflects the consideration we expect to be entitled to in exchange for those goods or services. We have entered into vendor managed inventory (“VMI”) programs with our customers. Under these arrangements, we receive purchase orders from our customers, and the inventory is shipped to the VMI location upon receipt of the purchase order. The customer then pulls the inventory from the VMI hub based on its production needs. Revenue under VMI programs is recognized when control transfers to the customer, which is generally once the customer pulls the inventory from the hub.

[0001628280-24-038024:notes:49]
Revenue from all sales types is recognized at the transaction price. The transaction price is determined based on the consideration to which we will be entitled in exchange for transferring goods or services to the customer adjusted for estimated variable consideration, if any. We typically estimate the impact on the transaction price for discounts offered to the customers for early payments on receivables or net of accruals for estimated sales returns. These estimates are based on historical returns, analysis of credit memo data and other known factors. Actual returns could differ from these estimates. We allocate the transaction price to each distinct product based on its relative standalone selling price. The product price as specified on the purchase order is considered the standalone selling price as it is an observable input that depicts the price as if sold to a similar customer in similar circumstances.

[0001628280-24-038024:notes:50]
We exclude from revenue the taxes assessed by a governmental authority that are both imposed on and concurrent with a specific revenue-producing transaction, which are collected by us from a customer and deposited with the relevant government authority.

[0001628280-24-038024:notes:51]
Our revenue arrangements do not contain significant financing components as our standard payment terms are less than one year.

[0001628280-24-038024:notes:52]
If a customer pays consideration, or we have a right to an amount of consideration that is unconditional before we transfer a good or service to the customer, those amounts are classified as deferred revenue or deposits received from customers which are included in other current liabilities or other long-term liabilities when the payment is made or it is due, whichever is earlier.

[0001628280-24-038024:notes:53]
Transaction Price Allocated to the Remaining Performance Obligations

[0001628280-24-038024:notes:54]
Remaining performance obligations represent the transaction price allocated to performances obligations that are unsatisfied or partially unsatisfied as of the end of the reporting period. Unsatisfied and partially unsatisfied performance obligations consist of contract liabilities and non-cancellable backlog. Non-cancellable backlog includes goods and services for which customer purchase orders have been accepted that are scheduled or in the process of being scheduled for shipment. A portion of our revenue arises from vendor managed inventory arrangements where the timing and volume of customer utilization is difficult to predict.

[0001628280-24-038024:notes:55]
Deferred revenue as of June 29, 2024 and July 1, 2023 was $0.6 million and $2.1 million, respectively, which was recorded in other current liabilities in the consolidated balance sheets. During fiscal 2024 and fiscal 2023, we recognized $2.0 million and nil of revenue that was included in deferred revenue as of July 1, 2023 and July 2, 2022, respectively.

[0001628280-24-038024:notes:56]
Warranty

[0001628280-24-038024:notes:57]
Hardware products regularly include warranties to the end customers such that the product continues to function according to published specifications. We typically offer a twelve-month warranty for most of our products. However, in some instances depending upon the product, specific market, product line and geography in which we operate, and what is common in the industry, our warranties can vary and range from six months to five years. These standard warranties are assurance type warranties and do not offer any services in addition to the assurance that the product will continue working as specified. Therefore, warranties are not considered separate performance obligations in the arrangement.

[0001628280-24-038024:notes:58]
We provide reserves for the estimated costs of product warranties that we record as cost of sales at the time revenue is recognized. We estimate the costs of our warranty obligations based on our historical experience of known product failure rates, use of materials to repair or replace defective products and service delivery costs incurred in correcting product failures. In addition, from time-to-time, specific warranty accruals may be made if discrete technical problems arise.

[0001628280-24-038024:notes:59]
Shipping and Handling Costs

[0001628280-24-038024:notes:60]
We record shipping and handling costs related to revenue transactions within cost of sales as a period cost.

[0001628280-24-038024:notes:61]
Contract Costs

[0001628280-24-038024:notes:62]
We recognize the incremental direct costs of obtaining a contract, which consist of sales commissions, when control over the products they relate to transfers to the customer. Applying the practical expedient, we recognize commissions as expense when incurred, as the amortization period of the commission asset we would have otherwise recognized is less than one year.

[0001628280-24-038024:notes:63]
Contract Balances

[0001628280-24-038024:notes:64]
We record accounts receivable when we have an unconditional right to consideration. Contract liabilities are recorded when cash payments are received or due in advance of performance. Contract liabilities consist of advance payments and deferred revenue, where we have unsatisfied performance obligations. Contract liabilities are classified as deferred revenue and customer deposits and are included in other current liabilities within our consolidated balance sheet. Payment terms vary by customer. The time between invoicing and when payment is due is not significant. Refer to “Note 18. Revenue Recognition” for a presentation of changes in contract balances.

[0001628280-24-038024:notes:65]
Disaggregation of Revenue

[0001628280-24-038024:notes:66]
We disaggregate revenue by geography and by product. Refer to “Note 18. Revenue Recognition” for a presentation of disaggregated revenue. We do not present other levels of disaggregation, such as by type of products, customer, markets, contracts, duration of contracts, timing of transfer of control and sales channels, as this information is not used by our Chief Operating Decision Maker (“CODM”) to manage the business.

[0001628280-24-038024:notes:67]
Income Taxes

[0001628280-24-038024:notes:68]
In accordance with the authoritative guidance on accounting for income taxes, we recognize income taxes using an asset and liability approach. This approach requires the recognition of taxes payable or refundable for the current year and deferred

[0001628280-24-038024:notes:69]
tax liabilities and assets for the future tax consequences of events that have been recognized in our consolidated financial statements or tax returns. The measurement of current and deferred taxes is based on provisions of the enacted tax law, and the effects of future changes in tax laws or rates are not anticipated.

[0001628280-24-038024:notes:70]
The authoritative guidance provides for recognition of deferred tax assets if the realization of such deferred tax assets is more likely than not to occur based on an evaluation of both positive and negative evidence and the relative weight of the evidence. We consider future growth, forecasted earnings, future taxable income, the mix of earnings in the jurisdictions in which we operate, historical earnings, taxable income in prior years, if carry-back is permitted under the law, and prudent and feasible tax planning strategies in determining the need for a valuation allowance. In the event we were to determine that we would not be able to realize all or part of our net deferred tax assets in the future, an adjustment to the deferred tax assets valuation allowance would be charged to earnings in the period in which we make such a determination, or goodwill would be adjusted at our final determination of the valuation allowance related to an acquisition within the measurement period. If we later determine that it is more likely than not that the net deferred tax assets would be realized, we would reverse the applicable portion of the previously provided valuation allowance as an adjustment to earnings at such time.

[0001628280-24-038024:notes:71]
We are subject to income tax audits by the respective tax authorities of the jurisdictions in which we operate. The determination of our income tax liabilities in each of these jurisdictions requires the interpretation and application of complex, and sometimes uncertain, tax laws and regulations. The authoritative guidance on accounting for income taxes prescribes both recognition and measurement criteria that must be met for the benefit of a tax position to be recognized in the financial statements. If a tax position taken, or expected to be taken, in a tax return does not meet such recognition or measurement criteria, an unrecognized tax benefit liability is recorded.  If we ultimately determine that an unrecognized tax benefit liability is no longer necessary, we reverse the liability and recognize a tax benefit in the period in which it is determined that the unrecognized tax benefit liability is no longer necessary.

[0001628280-24-038024:notes:72]
The recognition and measurement of current taxes payable or refundable and deferred tax assets and liabilities requires that we make certain estimates and judgments. Changes to these estimates or a change in judgment may have a material impact on our tax provision in a future period.

[0001628280-24-038024:notes:73]
Property, Plant and Equipment

[0001628280-24-038024:notes:74]
Property, plant and equipment are stated at cost. Depreciation is computed by the straight-line method generally over the following estimated useful lives of the assets: 10 to 40 years for building and improvements, 3 to 10 years for machinery and equipment, and 2 to 5 years for furniture, fixtures, software and office equipment. Leasehold improvements are amortized using the straight-line method over the shorter of the estimated useful lives of the assets or the term of the lease, including the renewal option that we are reasonably certain to exercise.

[0001628280-24-038024:notes:75]
In accordance with the guidance for business combinations, we determine whether a transaction or event is a business combination, which requires that the assets acquired and liabilities assumed constitute a business. Each business combination is then accounted for by applying the acquisition method. If the assets acquired are not a business, we account for the transaction or event as an asset acquisition. Under both methods, we recognize the identifiable assets acquired, the liabilities assumed, and any noncontrolling interest in the acquired entity. We capitalize acquisition-related costs and fees associated with asset acquisitions and immediately expense acquisition-related costs and fees associated with business combinations.

[0001628280-24-038024:notes:76]
We allocate the fair value of purchase consideration to the tangible assets acquired, liabilities assumed and intangible assets acquired based on their estimated fair values. The excess of the fair value of purchase consideration over the fair values of these identifiable assets and liabilities is recorded as goodwill. When determining the fair values of assets acquired and liabilities assumed, we make significant estimates and assumptions, especially with respect to intangible assets. Critical estimates in valuing certain intangible assets include, but are not limited to, future expected cash flows from customer relationships and acquired developed technology and discount rates. Our estimates of fair value are based upon assumptions believed to be reasonable using the best information available. These assumptions are inherently uncertain and unpredictable and, as a result, actual results may differ materially from estimates. Certain estimates associated with the accounting for acquisitions may change as additional information becomes available regarding the assets acquired and liabilities assumed. Any change in facts and circumstances that existed as of the acquisition date and impacts to our preliminary estimates is recorded to goodwill if identified within the measurement period. Subsequent to the measurement period or our final determination of fair value of assets and liabilities, whichever is earlier, the adjustments will affect our earnings.

[0001628280-24-038024:notes:77]
We estimate the economic lives of certain acquired assets and these lives are used to calculate depreciation and amortization expense. If our estimates of the economic lives change, depreciation or amortization expenses could be accelerated or slowed.

[0001628280-24-038024:notes:78]
Goodwill

[0001628280-24-038024:notes:79]
Goodwill represents the excess of the purchase price of an acquired business over the fair value of the identifiable assets acquired and liabilities assumed. We test goodwill impairment on an annual basis in the fiscal fourth quarter and at any other time when events occur or circumstances indicate that the carrying amount of goodwill may not be recoverable.

[0001628280-24-038024:notes:80]
We have the option to first assess qualitative factors to determine whether it is necessary to perform the quantitative goodwill impairment test. The qualitative factors we assess include long-term prospects of our performance, share price trends and market capitalization, and Company specific events. Unanticipated events and circumstances may occur that affect the accuracy of our assumptions, estimates and judgments. For example, if the price of our common stock were to significantly decrease combined with other adverse changes in market conditions, thus indicating that the underlying fair value of our reporting units may have decreased, we may reassess the value of our goodwill in the period such circumstances were identified.

[0001628280-24-038024:notes:81]
If we determine that, as a result of the qualitative assessment, it is more likely than not (i.e., greater than 50% likelihood) that the fair value of a reporting unit is less than its carrying amount, we perform the quantitative test by estimating the fair value of our reporting units. If the carrying value of a reporting unit exceeds its fair value, we record goodwill impairment loss equal to the excess of the carrying value of the reporting unit’s goodwill over its fair value, not to exceed the carrying amount of goodwill. The fair value of each of our goodwill reporting units is generally estimated using a combination of public company multiples and discounted cash flow methodologies.

[0001628280-24-038024:notes:82]
Based on the impairment analysis performed in the fourth quarter of each year presented, the fair value of each of our reporting units substantially exceeded the carrying value; as such, our annual qualitative assessment did not indicate that a more detailed quantitative analysis was necessary.

[0001628280-24-038024:notes:83]
Intangible Assets

[0001628280-24-038024:notes:84]
Intangible assets consist primarily of intangible assets purchased through acquisitions. Purchased intangible assets include acquired developed technologies (developed and core technology), customer relationships, and order backlog. Intangible assets, with the exception of certain customer relationships, are amortized using the straight-line method over the estimated economic useful lives of the assets, which is the period during which expected cash flows support the fair value of such intangible assets. Certain customer relationships are amortized using an accelerated method of amortization over the expected customer lives, which more accurately reflects the pattern of realization of economic benefits expected to be obtained.

[0001628280-24-038024:notes:85]
Long-lived Asset Valuation

[0001628280-24-038024:notes:86]
We test long-lived assets for recoverability, at the asset group level, when events or changes in circumstances indicate that their carrying amount may not be recoverable. Circumstances which could trigger a review include, but are not limited to: significant decreases in the market price of the asset, significant adverse changes in the business climate or legal factors, accumulation of costs significantly in excess of the amount originally expected for the acquisition or construction of the asset, current period cash flow or operating losses combined with a history of losses or a forecast of continuing losses associated with the use of the asset, or current expectation that the asset will more likely than not be sold or disposed significantly before the end of its estimated useful life.

[0001628280-24-038024:notes:87]
Recoverability is assessed based on the difference between the carrying amount of the asset and the sum of the undiscounted cash flows expected to result from the use and the eventual disposal of the asset. An impairment loss is recognized when the carrying amount is not recoverable and exceeds fair value.

[0001628280-24-038024:notes:88]
Pension Benefits

[0001628280-24-038024:notes:89]
The Company sponsors various employee retirement plans, including defined contribution, defined benefit and other post-retirement plans.  Refer to “Note 15. Employee Retirement Plans” for more information.

[0001628280-24-038024:notes:90]
The funded status of our retirement-related benefit plan is measured as the difference between the fair value of plan assets and the benefit obligation at fiscal year end, the measurement date. The funded status of an underfunded benefit plan, of which the fair value of plan assets is less than the benefit obligation, is recognized as a non-current net pension liability in the consolidated balance sheets. For defined benefit pension plans, the benefit obligation is the projected benefit obligation (“PBO”) which represents the actuarial present value of benefits expected to be paid upon retirement.

[0001628280-24-038024:notes:91]
Net periodic pension cost (income) (“NPPC”) is recorded in the consolidated statements of operations and includes service cost, interest cost, expected return on plan assets, amortization of prior service cost and gains or losses previously recognized as a component of accumulated other comprehensive income. Service cost represents the actuarial present value of participant benefits attributed to services rendered by employees in the current year. Interest cost represents the time value of money cost associated with the passage of time. Gains or losses arise as a result of differences between actual experience and assumptions or as a result of changes in actuarial assumptions. Prior service cost or credits represent the cost of benefit improvements attributable to prior service granted in plan amendments. (Gains) losses and prior service cost (credit) that arise during the current year are first recognized as a component of accumulated other comprehensive income in the consolidated balances sheets, net of tax. Prior service cost is amortized as a component of NPPC over the average remaining service period of active plan participants starting at the date the plan amendment is adopted. Deferred actuarial gains or losses are subsequently recognized as a component of NPPC if they exceed the greater of 10% of PBO or the fair value of plan assets, with the excess amortized over the average remaining service period of active plan participants.

[0001628280-24-038024:notes:92]
The measurement of the benefit obligation and NPPC is based on our estimates and actuarial valuations, provided by third-party actuaries, which are approved by management. These valuations reflect the terms of the plans and use participant-specific information such as compensation, age and years of service, as well as certain assumptions, including estimates of discount rates, expected return on plan assets, rate of compensation increases, and mortality rates. We evaluate these assumptions annually at a minimum. In estimating the expected return on plan assets, we consider historical returns on plan assets, adjusted for forward-looking considerations, inflation assumptions and the impact of the active management of the plan’s invested assets.

[0001628280-24-038024:notes:93]
Concentration of Credit and Other Risks

[0001628280-24-038024:notes:94]
Financial instruments that potentially subject our business to concentration of credit risk consist primarily of cash, short-term investments, and trade receivables.

[0001628280-24-038024:notes:95]
Although the Company deposits its cash with financial institutions that management believes are of high credit quality, its deposits, at times, may exceed federally insured limits. The Company’s investment portfolio consists of investment grade securities diversified amongst security types, industries, and issuers. The Company’s investment policy limits the amount of credit exposure in the investment portfolio by imposing credit rating minimums and limiting purchases of a single issuer, security type, geography and industry, except for Treasury securities. The Company believes no significant concentration risk exists with respect to these investments.

[0001628280-24-038024:notes:96]
We perform credit evaluations of our customers’ financial condition and generally do not require collateral from our customers. These evaluations require significant judgment and are based on a variety of factors including, but not limited to, current economic trends, payment history, bad debt write-off experience, and financial review of the customer.

[0001628280-24-038024:notes:97]
We maintain an allowance for credit losses for estimated losses resulting from the inability of our customers to make required payments. When we become aware that a specific customer is unable to meet their financial obligations, we record a specific allowance to reflect the level of credit risk in the customer’s outstanding receivable balance. In addition, we record additional allowances based on certain percentages of aged receivable balances. These percentages take into account a variety of factors including, but not limited to, current economic trends, payment history and bad debt write-off experience. We classify bad debt expenses as selling, general and administrative expense.

[0001628280-24-038024:notes:98]
During fiscal 2024, 2023, and 2022, a few customers generated more than 10% of total net revenue. Refer to “Note 17. Operating Segments and Geographic Information” for more information.

[0001628280-24-038024:notes:99]
As of June 29, 2024, our accounts receivable from a single customer, which represented 10% or greater of the total accounts receivable, was concentrated with one customer, which represented 13% of gross accounts receivable. As of July 1, 2023, our accounts receivable from a single customer, which represented 10% or greater of the total accounts receivable, was concentrated with three customers, which individually represented 14%, 12% and 12% of gross accounts receivable, respectively.

[0001628280-24-038024:notes:100]
We rely on a limited number of suppliers for a number of key components contained in our products. We also rely on a limited number of significant independent contract manufacturers for the production of certain key components and subassemblies contained in our products.

[0001628280-24-038024:notes:101]
We generally use a rolling twelve months forecast based on anticipated product orders, customer forecasts, product order history and backlog to determine our materials requirements. Lead times for the parts and components that we order vary significantly and depend on factors such as the specific supplier, contract terms and demand for a component at a given time. If the forecast does not meet or if it exceeds actual demand, we may have excess or shortfalls of some materials and components, as well as excess inventory purchase commitments. We could experience reduced or delayed product shipments or incur additional inventory write-downs and cancellation charges or penalties, which would increase costs and could have a material adverse impact on our results of operations.

[0001628280-24-038024:notes:102]
Foreign Currency Translation

[0001628280-24-038024:notes:103]
In fiscal 2019, we established the functional currency for our worldwide operations as the U.S. dollar. Translation adjustments reported prior to December 10, 2018 remain as a component of accumulated other comprehensive income (loss) in our condensed consolidated balance sheets, until all or a part of the investment in the subsidiaries is sold or liquidated. In fiscal 2023, we acquired IPG telecom transmission product lines. The functional currency of the Brazilian entities acquired as part of this acquisition is the local currency.

[0001628280-24-038024:notes:104]
Translation adjustments reported prior to fiscal 2019, remain as a component of accumulated other comprehensive income in our consolidated balance sheet. The translated values for any non-monetary assets and liabilities as of the date we established the U.S. dollar as the functional currency became the new accounting basis for those assets. Accordingly, monetary assets and liabilities denominated in foreign currencies have been remeasured into U.S. dollars using the exchange rates in effect at the balance sheet date. Foreign currency re-measurement gains or losses are included in other income (expense), net in the consolidated statements of operations.

[0001628280-24-038024:notes:105]
Stock-based Compensation

[0001628280-24-038024:notes:106]
Compensation expense related to stock-based transactions is measured and recognized in the financial statements based on fair value at the grant date.

[0001628280-24-038024:notes:107]
Restricted stock units (“RSUs”) are grants of shares of our common stock, the vesting of which is based on the requisite service requirement. Generally, our RSUs are subject to forfeiture and expected to vest over one to four years. For new-hire grants, RSUs generally vest ratably on an annual basis over four years. For annual refresh grants, RSUs generally vest ratably on an annual, or combination of annual and quarterly, basis over three years.

[0001628280-24-038024:notes:108]
Restricted stock awards (“RSAs”) are grants of shares of our common stock that are subject to various restrictions, including restrictions on transferability and forfeiture provisions. RSAs are expected to vest over one to four years, and the shares acquired may not be transferred by the holder until the vesting conditions (if any) are satisfied.

[0001628280-24-038024:notes:109]
Performance stock units (“PSUs”) are grants of shares of our common stock that vest upon the achievement of certain performance and service conditions. We account for the fair value of PSUs using the closing market price of our common stock on the date of grant. We begin recognizing compensation expense when we conclude that it is probable that the performance conditions will be achieved. We reassess the probability of vesting at each reporting period and adjust our compensation cost based on this probability assessment. Our PSUs are subject to risk of forfeiture until performance and service conditions are satisfied and generally vest over three years.

[0001628280-24-038024:notes:110]
We estimate the fair value of the rights to acquire stock under our 2015 Employee Stock Purchase Plan (the “2015 Purchase Plan”) using the Black-Scholes option pricing formula. Our 2015 Purchase Plan provides for consecutive six-month offering periods. We recognize such compensation expense on a straight-line basis over the requisite service period. We calculate the volatility factor based on our historical stock prices.

[0001628280-24-038024:notes:111]
Treasury Stock

[0001628280-24-038024:notes:112]
Treasury stock is carried at cost. When we retire our treasury stock, any excess of the repurchase price paid over par value is allocated to retained earnings.

[0001628280-24-038024:notes:113]
Restructuring and Related Charges

[0001628280-24-038024:notes:114]
Costs associated with restructuring activities are recognized when they are obligated. However, in the case of leases, the expense is estimated and accrued when the property is vacated. Given the significance of, and the timing of the execution of such activities, this process is complex and involves periodic reassessments of estimates made from the time the property was vacated, including evaluating real estate market conditions for expected vacancy periods and sub-lease income. We recognize a liability for post-employment benefits for workforce reductions related to restructuring activities when payment is probable and the amount is reasonably estimable. Restructuring and related charges may also include charges related to write-offs of long lived assets related to significant restructuring initiatives.

[0001628280-24-038024:notes:115]
We continually evaluate the adequacy of the remaining liabilities under our restructuring initiatives. Although we believe that these estimates accurately reflect the costs of our restructuring plans, actual results may differ, thereby requiring us to record additional provisions or reverse a portion of such provisions.

[0001628280-24-038024:notes:116]
Refer to “Note 12. Restructuring and Related Charges”.

[0001628280-24-038024:notes:117]
Research and Development (“R&D”) Expense

[0001628280-24-038024:notes:118]
Costs related to R&D, which primarily consists of labor and benefits, supplies, facilities, consulting and outside service fees, are charged to expense as incurred.

[0001628280-24-038024:notes:119]
Loss Contingencies

[0001628280-24-038024:notes:120]
We are subject to the possibility of various loss contingencies arising in the ordinary course of business. We consider the likelihood of loss or impairment of an asset or the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss in determining loss contingencies. An estimated loss is accrued when it is probable that an asset has been impaired or a liability has been incurred and the amount of loss can be reasonably estimated. We regularly evaluate current information available to determine whether such accruals should be adjusted and whether new accruals are required.

[0001628280-24-038024:notes:121]
Asset Retirement Obligations (“ARO”)

[0001628280-24-038024:notes:122]
Our ARO are legal obligations associated with the retirement of long-lived assets pertaining to leasehold improvements. These liabilities are initially recorded at fair value and the related asset retirement costs are capitalized by increasing the carrying amount of the related assets by the same amount as the liability. Asset retirement costs are subsequently depreciated over the useful lives of the related assets. Subsequent to initial recognition, we record period-to-period changes in the ARO liability resulting from the passage of time and revisions to either the timing or the amount of the original estimate of undiscounted cash flows. We de-recognize ARO liabilities when the related obligations are settled.


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0001628280-24-038024:notes:123]
We determine fair value based on the fair value hierarchy, which requires an entity to maximize the use of observable inputs and minimize the use of unobservable inputs when measuring fair value. Fair value is defined as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. The fair value assumes that the transaction to sell the asset or transfer the liability occurs in the principal or most advantageous market for the asset or liability and establishes that the fair value of an asset or liability shall be determined based on the assumptions that market participants would use in pricing the asset or liability. The classification of a financial asset or liability within the hierarchy is based upon the lowest level input that is significant to the fair value measurement. The fair value hierarchy prioritizes the inputs into three levels that may be used to measure fair value:

[0001628280-24-038024:notes:124]
| Level 1: | Inputs are unadjusted quoted prices in active markets for identical assets or liabilities. |
| Level 2: | Inputs are quoted prices for similar assets and liabilities in active markets or inputs that are observable for the asset or liability, either directly or indirectly through market corroboration, for substantially the full term of the financial instrument. |
| Level 3: | Inputs are unobservable inputs based on our assumptions. |

[0001628280-24-038024:notes:125]
The fair value of our Level 1 financial instruments, such as money market funds and U.S. Treasury securities, which are traded in active markets, is based on quoted market prices for identical instruments. The fair value of our Level 2 fixed income securities is obtained from an independent pricing service, which may use quoted market prices for identical or comparable instruments or model driven valuations using observable market data or inputs corroborated by observable market data. Our marketable securities are held by custodians who obtain investment prices from a third-party pricing provider that incorporates standard inputs in various asset price models. Our procedures include controls to ensure that appropriate fair values are recorded, including comparing the fair values obtained from our pricing service against fair values obtained from another independent source.

[0001628280-24-038024:notes:126]
Our pension assets consist of multiple institutional funds (“pension funds”) of which the fair values are based on the quoted prices of the underlying funds. Pension funds are primarily classified as Level 2 assets since such funds are not directly traded in active markets. Refer to “Note 15. Employee Retirement Plans.”

[0001628280-24-038024:notes:127]
Assets Measured at Fair Value on a Non-Recurring Basis

[0001628280-24-038024:notes:128]
We periodically review our intangible and other long-lived assets for impairment whenever events or changes in circumstances indicate that the carrying amount of such assets may not be recoverable. Determination of recoverability is based on the lowest level of identifiable estimated undiscounted cash flows resulting from use of the asset and its eventual disposition. If not recoverable, an impairment loss would be calculated based on the excess of the carrying amount over the fair value.
Management utilizes various valuation methods, including an income approach, a market approach and a cost approach, to estimate the fair value of intangibles and other long-lived assets.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0001628280-24-038024:notes:129]
Contract Balances
We record accounts receivable when we have an unconditional right to consideration. Contract liabilities are recorded when cash payments are received or due in advance of performance. Contract liabilities consist of advance payments and deferred revenue, where we have unsatisfied performance obligations. Contract liabilities are classified as deferred revenue and customer deposits and are included in other current liabilities within our consolidated balance sheet. Payment terms vary by customer. The time between invoicing and when payment is due is not significant.
Disaggregation of Revenue
We disaggregate revenue by geography and by product. Refer to “Note 18. Revenue Recognition” for a presentation of disaggregated revenue. We do not present other levels of disaggregation, such as by type of products, customer, markets, contracts, duration of contracts, timing of transfer of control and sales channels, as this information is not used by our Chief Operating Decision Maker (“CODM”) to manage the business.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001628280-24-038024:notes:130]
Note 2. Recently Issued Accounting Pronouncements

[0001628280-24-038024:notes:131]
In March 2024, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) No. 2024-02: Codification Improvements - Amendments to Remove References to the Concepts Statements, which contains amendments to the Codification that remove references to various FASB Concepts Statements.  ASU 2024-02 is effective for fiscal years beginning after December 15, 2024, with early adoption permitted. We do not expect this ASU to have a material impact on our consolidated financial statements and disclosures.

[0001628280-24-038024:notes:132]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures, which requires disaggregated information about a reporting entity’s effective tax rate reconciliation as well as information on income tax paid. ASU 2023-09 is effective for fiscal years beginning after December 15, 2024, with early adoption permitted. We are currently evaluating the impact of this ASU on our income tax disclosures within the consolidated financial statements.
In November 2023, the FASB issued ASU 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures, which updates reportable segment disclosure requirements primarily through enhanced disclosures about significant segment expenses. ASU 2023-07 does not change how a public entity identifies its operating segments, aggregates those operating segments, or applies quantitative thresholds to determine its reportable segments. The update is effective for fiscal years beginning after December 15, 2023 and interim periods within fiscal years beginning after December 15, 2024, with early adoption permitted. The amendments should be applied retrospectively to all prior periods presented in the financial statements. We plan to adopt ASU 2023-07 in our annual financial statements of fiscal 2025 and interim financial statements of the first quarter of fiscal 2026. We are currently evaluating the impact of adopting this ASU on our consolidated financial statements and disclosures.


## us-gaap:EarningsPerShareTextBlock

[0001628280-24-038024:notes:133]
Note 3. Earnings Per Share

[0001628280-24-038024:notes:134]
The following table sets forth the computation of basic and diluted net income (loss) per share (in millions, except per share data):

[0001628280-24-038024:notes:135]
|  | Years Ended |
|  | June 29, 2024 |  | July 1, 2023 |  |  |  | July 2, 2022 |
| Numerator: |  |  |  |  |  |  |  |
| Net income (loss) - basic and diluted | $ | (546.5) |  |  | $ | (131.6) |  |  |  |  | $ | 198.9 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted average common shares outstanding - basic | 67.3 |  |  | 68.3 |  |  |  |  | 71.2 |  |
| Effect of dilutive securities from stock-based benefit plans | — |  |  | — |  |  |  |  | 0.6 |  |
| Shares issuable assuming conversion of the convertible notes | — |  |  | — |  |  |  |  | 2.4 |  |
| Weighted average common shares outstanding - diluted | 67.3 |  |  | 68.3 |  |  |  |  | 74.2 |  |
| Net income (loss) per share: |  |  |  |  |  |  |  |
| Basic | $ | (8.12) |  |  | $ | (1.93) |  |  |  |  | $ | 2.79 |  |
| Diluted | $ | (8.12) |  |  | $ | (1.93) |  |  |  |  | $ | 2.68 |  |

[0001628280-24-038024:notes:136]
Shares from stock-based benefit plans and shares issuable assuming conversion of our convertible notes are anti-dilutive for the year ended June 29, 2024 and July 1, 2023, therefore excluded from the calculation of diluted net loss per share, as the Company had net loss for these periods.

[0001628280-24-038024:notes:137]
Average anti-dilutive shares excluded from the calculation of diluted net loss per share for the year ended June 29, 2024 include 29.6 million shares related to the convertible notes, 4.1 million shares issuable under RSUs and PSUs, 0.2 million shares issuable under the 2015 Purchase Plan and 1.1 million shares outstanding related to stock options. Average anti-dilutive shares excluded from the calculation of diluted net loss per share for July 1, 2023 include 24.8 million shares related to the convertible notes, 3.2 million shares issuable under RSUs and PSUs and 0.2 million shares issuable under the 2015 Purchase Plan. Anti-dilutive shares excluded from the calculation of diluted net income per share for the year ended July 2, 2022 was 0.1 million. Refer to “Note 14. Equity”.

[0001628280-24-038024:notes:138]
As a result of our adoption of ASU 2020-06 in the first quarter of fiscal 2023, potentially dilutive common shares issuable upon conversion of our outstanding convertible notes are determined using the if-converted method. For periods prior to the adoption of ASU 2020-06, which include fiscal year 2022, our potentially dilutive common shares issuable upon conversion of our outstanding convertible notes are determined using the treasury stock method.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001628280-24-038024:notes:139]
Note 4. Business Combination

[0001628280-24-038024:notes:140]
Cloud Light Acquisition

[0001628280-24-038024:notes:141]
On October 29, 2023, we entered into a definitive merger agreement (the “Merger Agreement”) with Cloud Light. On November 7, 2023, we completed the acquisition of Cloud Light (the “Cloud Light Closing Date”). Cloud Light designs, markets, and manufactures advanced optical modules for data center applications. The acquisition enables us to be well-positioned to serve the growing needs of Cloud & Networking customers, particularly those customers focused on optimizing their data center infrastructure for the demands of AI/ML.

[0001628280-24-038024:notes:142]
We have applied the acquisition method of accounting in accordance with ASC 805 Business Combinations, with respect to the fair value of purchase price consideration and the identifiable assets and liabilities of Cloud Light, which have been measured at estimated fair value as of the Cloud Light Closing date. The following tables summarize the preliminary purchase price consideration (in millions):

[0001628280-24-038024:notes:143]
|  | Fair Value |
| Cash consideration (1) | $ | 705.0 |  |
| Share-based consideration (2) | 23.5 |  |
| Total purchase price consideration | $ | 728.5 |  |

[0001628280-24-038024:notes:144]
(1) Under the terms of the Merger Agreement, Cloud Light stockholders received $1.69 per share after adjusting for applicable withholding taxes, escrow fund and expense fund contributions, for each of the 409.4 million of shares outstanding at the Cloud Light Closing date. As a result, we transferred $691.7 million of cash consideration on the Cloud Light Closing date. Additionally, each of Cloud Light’s outstanding options was exchanged for a combination of up-front cash consideration and newly issued options (the “replacement options”). As a result, we transferred $13.3 million of cash consideration on the Cloud Light Closing date.

[0001628280-24-038024:notes:145]
(2) The  replacement options have a total fair value of $38.9 million as of the Cloud Light Closing date, of which $23.5 million attributable to pre-acquisition service is recorded as part of the purchase price consideration and the remaining $15.4 million is recorded as post-acquisition stock-based compensation expense over the vesting period of three years from the Cloud Light Closing date. In general, these options expire within 10 years from the Cloud Light Closing date. Refer to “Note 14. Equity”.

[0001628280-24-038024:notes:146]
The cash consideration of $705.0 million, which was funded by the cash balances of Lumentum, includes $75.8 million of cash held in an escrow fund for a period of 12 months following the Cloud Light Closing date to support Cloud Light’s indemnification obligations under the Merger Agreement. The consideration is subject to customary adjustment for working capital.

[0001628280-24-038024:notes:147]
We also incurred a total of $9.6 million of acquisition-related costs the year ended June 29, 2024, representing professional and other direct acquisition costs, which are recorded as selling, general and administrative expense in the consolidated statement of operations when incurred.

[0001628280-24-038024:notes:148]
We allocated the fair value of the purchase price consideration to the assets acquired and liabilities assumed as of the Cloud Light Closing date based on their estimated fair values. The excess of purchase price consideration over the fair value of net assets acquired is recorded as goodwill. Our preliminary allocation of the purchase price consideration to the assets acquired and liabilities assumed as of the Cloud Light Closing date is as follows (in millions):

[0001628280-24-038024:notes:149]
|  | Fair Value |
| Total purchase price consideration | $ | 728.5 |  |
| Assets acquired |  |
| Cash and cash equivalents | 4.1 |  |
| Short-term investments | 1.0 |  |
| Accounts receivable, net | 20.9 |  |
| Inventories | 71.8 |  |
| Prepayments and other current assets | 14.2 |  |
| Property, plant and equipment, net | 62.5 |  |
| Operating lease right-of-use assets, net | 3.7 |  |
| Other intangible assets, net (1) | 333.0 |  |
| Other non-current assets | 0.3 |  |
| Total assets | 511.5 |  |
| Liabilities assumed |  |
| Accounts payable | 45.7 |  |
| Accrued payroll and related expenses | 5.6 |  |
| Accrued expenses | 10.0 |  |
| Operating lease liabilities, current | 1.8 |  |
| Other current liabilities | 9.5 |  |
| Operating lease liabilities, non-current | 1.9 |  |
| Deferred tax liability | 60.1 |  |
| Other non-current liabilities | 9.1 |  |
| Total liabilities | 143.7 |  |
| Goodwill | $ | 360.7 |  |

[0001628280-24-038024:notes:150]
(1) Other intangible assets include developed technology of $170.0 million, customer relationship of $130.0 million, in-process research and development (“IPR&D”) of $16.0 million, order backlog of $14.0 million, and trade name and trademarks of $3.0 million. Refer to “Note 9. Goodwill and Other Intangible Assets”.

[0001628280-24-038024:notes:151]
The allocation of the purchase price to the assets acquired and liabilities assumed, including the residual amount allocated to goodwill, is based upon preliminary information and subject to change. The primary areas of the preliminary purchase price allocation that are not yet finalized relate to the working capital adjustments pursuant to the Merger Agreement, the fair value of inventories, property, plant and equipment, intangible assets, deferred tax assets and liabilities, and contingent liabilities, if any. Further adjustments may result before the end of the measurement period, which ends one year from the Cloud Light Closing date. During the measurement period, if new information is obtained about facts and circumstances that existed as of the Cloud Light Closing date that, if known, would have resulted in revised estimated values of assets acquired and liabilities assumed, we will revise the preliminary purchase price allocation. The effect of measurement period adjustments to the estimated fair values will be calculated as if the adjustments had been completed on the acquisition date. The impact of all changes that do not qualify as measurement period adjustments will be included in current period earnings.

[0001628280-24-038024:notes:152]
Goodwill from the Cloud Light acquisition has been assigned to the Cloud & Networking segment. The preliminary goodwill of $360.7 million arising from the acquisition is attributed to the expected revenue growth and synergies, including future cost efficiencies and other benefits that are expected to be generated by combining Lumentum and Cloud Light. None of the goodwill is expected to be deductible for local tax purposes. Refer to “Note 9. Goodwill and Other Intangible Assets.”

[0001628280-24-038024:notes:153]
Cloud Light contributed $199.5 million of our consolidated net revenue for the year ended June 29, 2024. Due to the continued integration of the combined businesses, as well as our corporate structure and the allocation of selling, general and administrative costs, it is impracticable to determine Cloud Light’s contribution to our earnings.

[0001628280-24-038024:notes:154]
Unaudited Supplemental Pro Forma Information

[0001628280-24-038024:notes:155]
The following unaudited supplemental pro forma information presents the combined results of operations for the years ended June 29, 2024 and July 1, 2023, respectively, as if the acquisition was completed on July 3, 2022, the first day of the fiscal year 2023. The unaudited supplemental pro forma financial information presented below is not necessarily indicative of the financial position or results of operations that would have been realized if the acquisition had been completed on the date indicated. The unaudited supplemental pro forma financial information does not reflect synergies that might have been achieved, nor is it indicative of future operating results or financial position.

[0001628280-24-038024:notes:156]
The unaudited pro forma financial information includes adjustments for: (i) amortization expense that would have been recognized related to the acquired intangible assets, (ii) depreciation expense that would have been recognized related to the acquired property, plant, and equipment, (iii) amortization of inventory fair value adjustment, (iv) acquisition related costs, such as third party transaction costs and restructuring costs, (v) stock-based compensation expense and (vi) the estimated income tax effect on the unaudited pro forma adjustments.

[0001628280-24-038024:notes:157]
The unaudited supplemental pro forma financial information for the periods presented is as follows (in millions):

[0001628280-24-038024:notes:158]
|  | Years Ended |  |
|  | June 29, 2024 |  | July 1, 2023 |  |
| Net revenue | $ | 1,447.9 |  |  | $ | 1,961.5 |  |  |
| Net loss | $ | 531.7 |  |  | $ | 180.1 |  |  |

[0001628280-24-038024:notes:159]
NeoPhotonics Acquisition

[0001628280-24-038024:notes:160]
On August 3, 2022, we completed the acquisition of NeoPhotonics. The total purchase price consideration of $934.4 million was funded by the cash balances of the combined company. The addition of NeoPhotonics expanded our opportunity in some of the fastest growing markets for optical components used in cloud and telecom network infrastructure.

[0001628280-24-038024:notes:161]
We have applied the acquisition method of accounting in accordance with ASC Topic 805, Business Combinations to account for this transaction and recorded a goodwill of $315.3 million arising from the acquisition, which has been assigned to the Cloud & Networking segment.

[0001628280-24-038024:notes:162]
We recorded $28.7 million of merger-related costs, representing professional and other direct acquisition costs, of which $8.3 million was incurred in fiscal year 2022 and $20.4 million was incurred in fiscal year 2023, which was recorded as selling, general and administrative expense in the condensed consolidated statements of operations.

[0001628280-24-038024:notes:163]
The following unaudited supplemental pro forma information (unaudited) presents the combined results of operations for the years ended July 1, 2023 and July 2, 2022, respectively, as if the acquisition was completed on July 4, 2021, the first day of fiscal 2022. The unaudited supplemental pro forma financial information is not necessarily indicative of the financial position or results of operations that would have been realized if the acquisition had been completed on the date indicated. The unaudited supplemental pro forma financial information does not reflect synergies that might have been achieved, nor is it indicative of future operating results or financial position. The unaudited pro forma financial information includes adjustments for: (i) amortization expense that would have been recognized related to the acquired intangible assets, (ii) depreciation expense that would have been recognized related to the acquired property, plant, and equipment, (iii) amortization of inventory fair value adjustment, (iv) acquisition related costs, such as third party transaction costs and restructuring costs, (v) stock-based compensation expense and (vi) the estimated income tax effect on the unaudited pro forma adjustments.

[0001628280-24-038024:notes:164]
|  |  |  | Years Ended |
|  |  |  |  |  | July 1, 2023 |  | July 2, 2022 |
| Net revenue |  |  |  |  | $ | 1,790.9 |  |  | $ | 2,061.2 |  |
| Net income (loss) |  |  |  |  | $ | (90.1) |  |  | $ | 77.2 |  |

[0001628280-24-038024:notes:165]
Acquisition of IPG Photonics’ Telecom Transmission Product Lines

[0001628280-24-038024:notes:166]
On August 15, 2022 (“IPG Closing date”), we completed a transaction to acquire IPG Photonics’ telecom transmission product lines (“IPG telecom transmission product lines”) that are used to develop and market products for use in telecommunications and datacenter infrastructure, including Digital Signal Processors (DSPs), ASICs and optical transceivers with a total purchase price of $55.9 million, which was paid in cash. This acquisition enables us to expand our business in the Cloud & Networking segment.

[0001628280-24-038024:notes:167]
We have applied the acquisition method of accounting in accordance with ASC Topic 805, Business Combinations to account for this transaction and recorded a goodwill of $10.9 million arising from the acquisition, which has been assigned to the Cloud & Networking segment. We recorded $2.0 million of merger-related costs, representing professional and other direct acquisition costs, of which $0.4 million was incurred in fiscal year 2022 and $1.6 million was incurred in fiscal year 2023, which was recorded as selling, general and administrative expense in the consolidated statements of operations.

[0001628280-24-038024:notes:168]
The unaudited pro forma financial information from the acquisition of the IPG telecom transmission product lines, assuming the acquisition was completed on the first day of fiscal 2022, as well as revenue and earnings generated during fiscal 2023, were not material for disclosure purposes.


## us-gaap:CashCashEquivalentsAndShortTermInvestmentsTextBlock

[0001628280-24-038024:notes:169]
Note 5. Cash, Cash Equivalents and Short-term Investments

[0001628280-24-038024:notes:170]
The following table summarizes our cash, cash equivalents and short-term investments by category for the periods presented (in millions):

[0001628280-24-038024:notes:171]
|  | Amortized Cost |  | Gross Unrealized Gains |  | Gross Unrealized Losses |  | Fair Value |
| June 29, 2024: |  |  |  |  |  |  |  |
| Cash | $ | 196.9 |  |  | $ | — |  |  | $ | — |  |  | $ | 196.9 |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | 15.9 |  |  | — |  |  | — |  |  | 15.9 |  |
| Money market funds | 223.9 |  |  | — |  |  | — |  |  | 223.9 |  |
| Total cash and cash equivalents | $ | 436.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 436.7 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 0.8 |  |  | $ | — |  |  | $ | — |  |  | $ | 0.8 |  |
| Commercial paper | 12.6 |  |  | — |  |  | — |  |  | 12.6 |  |
| Corporate debt securities | 244.5 |  |  | — |  |  | (0.6) |  |  | 243.9 |  |
| U.S. Agency securities | 81.2 |  |  | — |  |  | (0.3) |  |  | 80.9 |  |
| U.S. Treasury securities | 112.6 |  |  | — |  |  | (0.5) |  |  | 112.1 |  |
| Total short-term investments | $ | 451.7 |  |  | $ | — |  |  | $ | (1.4) |  |  | $ | 450.3 |  |
| July 1, 2023: |  |  |  |  |  |  |  |
| Cash | $ | 254.3 |  |  | $ | — |  |  | $ | — |  |  | $ | 254.3 |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Money market funds | 276.1 |  |  | — |  |  | — |  |  | 276.1 |  |
| U.S. Agency securities | 4.0 |  |  | — |  |  | — |  |  | 4.0 |  |
| U.S. Treasury securities | 324.6 |  |  | — |  |  | — |  |  | 324.6 |  |
| Total cash and cash equivalents | $ | 859.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 859.0 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 16.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 16.5 |  |
| Commercial paper | 132.9 |  |  | — |  |  | (0.2) |  |  | 132.7 |  |
| Corporate debt securities | 472.7 |  |  | — |  |  | (3.9) |  |  | 468.8 |  |
| U.S. Agency securities | 207.9 |  |  | — |  |  | (1.7) |  |  | 206.2 |  |
| U.S. Treasury securities | 332.4 |  |  | — |  |  | (2.0) |  |  | 330.4 |  |
| Total short-term investments | $ | 1,162.4 |  |  | $ | — |  |  | $ | (7.8) |  |  | $ | 1,154.6 |  |

[0001628280-24-038024:notes:172]
We review our investment portfolio to identify and evaluate investments that have indicators of possible impairment. Factors considered in determining whether a loss is other-than-temporary include, but are not limited to, the length of time and extent a security’s fair value has been below its cost, the financial condition and near-term prospects of the investee, the credit quality of the security’s issuer, likelihood of recovery and our intent and ability to hold the security for a period sufficient to allow for any anticipated recovery in value. For the debt instruments we own, we also evaluate whether we have the intent to sell the security or whether it is more likely than not that we will be required to sell the security before recovery of its cost basis. We have not recorded our unrealized losses on our short-term investments into income because we do not intend to sell nor is it more likely than not that we will be required to sell these investments prior to recovery of their amortized cost basis.

[0001628280-24-038024:notes:173]
We use the specific-identification method to determine any realized gains or losses from the sale of our short-term investments classified as available-for-sale. During fiscal 2024, 2023 and 2022, we did not realize significant gains or losses on a gross level from the sale of our short-term investments classified as available-for-sale.

[0001628280-24-038024:notes:174]
The components of other income, net are as follows for the years presented (in millions):

[0001628280-24-038024:notes:175]
|  |  |  | Years Ended |
|  |  |  | June 29, 2024 |  | July 1, 2023 |  | July 2, 2022 |
| Foreign exchange gains, net |  |  | $ | 0.8 |  |  | $ | 7.0 |  |  | $ | 6.1 |  |
| Interest and investment income |  |  | 61.3 |  |  | 40.8 |  |  | 6.1 |  |
| Other income (losses), net |  |  | — |  |  | 1.0 |  |  | (0.2) |  |
| Other income, net |  |  | $ | 62.1 |  |  | $ | 48.8 |  |  | $ | 12.0 |  |

[0001628280-24-038024:notes:176]
Included in the interest and investment income are $5.8 million, $6.7 million and $3.9 million of interest receivable as of June 29, 2024, July 1, 2023 and July 2, 2022, respectively, recorded as prepayments and other current assets within the consolidated balance sheets. We did not recognize an allowance for credit losses against the interest receivable in any of the periods presented as there were no such losses.

[0001628280-24-038024:notes:177]
Concurrent with the issuance of the 2029 Notes in June 2023, we used $132.8 million of the net proceeds to repurchase $125.0 million aggregate principal amount of the 2024 Notes. We recognized a gain of $1.0 million, which was recorded under other income, net on our consolidated statements of operations for the year ended July 1, 2023. Refer to “Note 10. Debt”.

[0001628280-24-038024:notes:178]
The following table summarizes unrealized losses on our cash equivalents and short-term investments by category that have been in a continuous unrealized loss position for more than 12 months and less than 12 months, respectively, as of the periods presented (in millions):

[0001628280-24-038024:notes:179]
|  | Continuous Loss Position For More Than 12 Months |  | Continuous Loss Position For Less Than 12 Months |  | Gross Unrealized Losses |  |  |  |  |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  |  |  |  |  |  |  |  |  |
| June 29, 2024: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | 62.3 |  |  | $ | (0.3) |  |  | $ | 12.6 |  |  | $ | — |  |  | $ | (0.3) |  |  |  |  |  |  |  |  |  |
| Commercial paper | — |  |  | — |  |  | 28.6 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 133.7 |  |  | (0.5) |  |  | 90.6 |  |  | (0.2) |  |  | (0.7) |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 72.3 |  |  | (0.4) |  |  | 39.7 |  |  | (0.1) |  |  | (0.5) |  |  |  |  |  |  |  |  |  |
| Total | $ | 268.3 |  |  | $ | (1.2) |  |  | $ | 171.5 |  |  | $ | (0.3) |  |  | $ | (1.5) |  |  |  |  |  |  |  |  |  |
| July 1, 2023: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | 39.6 |  |  | $ | (0.4) |  |  | $ | 170.6 |  |  | $ | (1.3) |  |  | $ | (1.7) |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | — |  |  | 7.7 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | — |  |  | — |  |  | 128.5 |  |  | (0.2) |  |  | (0.2) |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 93.6 |  |  | (1.2) |  |  | 358.9 |  |  | (2.7) |  |  | (3.9) |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 50.8 |  |  | (0.6) |  |  | 221.4 |  |  | (1.4) |  |  | (2.0) |  |  |  |  |  |  |  |  |  |
| Total | $ | 184.0 |  |  | $ | (2.2) |  |  | $ | 887.1 |  |  | $ | (5.6) |  |  | $ | (7.8) |  |  |  |  |  |  |  |  |  |

[0001628280-24-038024:notes:180]
The following table classifies our short-term investments by remaining maturities (in millions):

[0001628280-24-038024:notes:181]
|  | June 29, 2024 |  | July 1, 2023 |
|  | Amortized Cost |  | Fair Value |  | Amortized Cost |  | Fair Value |
| Due within 1 year | $ | 405.5 |  |  | $ | 404.1 |  |  | $ | 762.9 |  |  | $ | 759.1 |  |
| Due between 1 year to 5 years | 46.2 |  |  | 46.2 |  |  | 399.5 |  |  | 395.5 |  |
|  | $ | 451.7 |  |  | $ | 450.3 |  |  | $ | 1,162.4 |  |  | $ | 1,154.6 |  |

[0001628280-24-038024:notes:182]
All available-for-sale securities have been classified as current, based on management’s intent and ability to use the funds in current operations.


## us-gaap:FairValueDisclosuresTextBlock

[0001628280-24-038024:notes:183]
Note 6. Fair Value Measurements

[0001628280-24-038024:notes:184]
Financial assets measured at fair value on a recurring basis are summarized below (in millions):

[0001628280-24-038024:notes:185]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| June 29, 2024 (1) |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | — |  |  | $ | 15.9 |  |  | $ | — |  |  | $ | 15.9 |  |
| Money market funds | $ | 223.9 |  |  | $ | — |  |  | $ | — |  |  | $ | 223.9 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | 0.8 |  |  | — |  |  | 0.8 |  |
| Commercial paper | — |  |  | 12.6 |  |  | — |  |  | 12.6 |  |
| Corporate debt securities | — |  |  | 243.9 |  |  | — |  |  | 243.9 |  |
| U.S. Agency securities |  |  | 80.9 |  |  |  |  | 80.9 |  |
| U.S. Treasury securities | 112.1 |  |  | — |  |  | — |  |  | 112.1 |  |
| Total assets | $ | 336.0 |  |  | $ | 354.1 |  |  | $ | — |  |  | $ | 690.1 |  |

[0001628280-24-038024:notes:186]
(1)  Excludes $196.9 million in cash held in our bank accounts as of June 29, 2024.

[0001628280-24-038024:notes:187]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| July 1, 2023 (1) |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Money market funds | $ | 276.1 |  |  | $ | — |  |  | $ | — |  |  | 276.1 |  |
| U.S. Agency securities | — |  |  | 4.0 |  |  | — |  |  | 4.0 |  |
| U.S. Treasury securities | 324.6 |  |  | — |  |  | — |  |  | 324.6 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | 16.5 |  |  | — |  |  | 16.5 |  |
| Commercial paper | — |  |  | 132.7 |  |  | — |  |  | 132.7 |  |
| Corporate debt securities | — |  |  | 468.8 |  |  | — |  |  | 468.8 |  |
| U.S. Agency securities | — |  |  | 206.2 |  |  | — |  |  | 206.2 |  |
| U.S. Treasury securities | 330.4 |  |  | — |  |  | — |  |  | 330.4 |  |
| Total assets | $ | 931.1 |  |  | $ | 828.2 |  |  | $ | — |  |  | $ | 1,759.3 |  |

[0001628280-24-038024:notes:188]
(1)  Excludes $254.3 million in cash held in our bank accounts as of July 1, 2023.

[0001628280-24-038024:notes:189]
Financial Instruments Not Recorded at Fair Value on a Recurring Basis

[0001628280-24-038024:notes:190]
We report our financial instruments at fair value with the exception of the convertible notes, see “Note 10. Debt”. The estimated fair value of the convertible notes was determined based on the trading price of the convertible notes as of the last day of trading for the period. We consider the fair value of the convertible notes to be a Level 2 measurement as they are not actively traded in markets.

[0001628280-24-038024:notes:191]
The carrying amounts and estimated fair values of our convertible notes are as follows for the periods presented (in millions):

[0001628280-24-038024:notes:192]
|  | June 29, 2024 |  | July 1, 2023 |
|  | Carrying Amount |  | Estimated Fair Value |  | Carrying Amount |  | Estimated Fair Value |
| 2029 Notes | $ | 599.4 |  |  | $ | 588.8 |  |  | $ | 598.6 |  |  | $ | 625.2 |  |
| 2028 Notes | 856.6 |  |  | 680.2 |  |  | 855.5 |  |  | 677.8 |  |
| 2026 Notes | 1,047.2 |  |  | 948.3 |  |  | 1,045.9 |  |  | 933.2 |  |
| 2024 Notes | — |  |  | — |  |  | 311.6 |  |  | 345.2 |  |
|  | $ | 2,503.2 |  |  | $ | 2,217.3 |  |  | $ | 2,811.6 |  |  | $ | 2,581.4 |  |

[0001628280-24-038024:notes:193]
We periodically review our intangible and other long-lived assets for impairment whenever events or changes in circumstances indicate that the carrying amount of such assets may not be recoverable. Determination of recoverability is based on the lowest level of identifiable estimated undiscounted cash flows resulting from use of the asset and its eventual disposition. If not recoverable, an impairment loss would be calculated based on the excess of the carrying amount over the fair value.

[0001628280-24-038024:notes:194]
Management utilizes various valuation methods, including an income approach, a market approach and a cost approach, to estimate the fair value of intangibles and other long-lived assets. During the annual impairment testing performed in the fourth quarter of fiscal 2024, we concluded that our intangible and other long-lived assets were not impaired. We review our intangible and other long-lived assets for impairment at least annually in the fourth quarter of each fiscal year, or any indicators of impairment exist.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001628280-24-038024:notes:195]
Note 7. Balance Sheet Details

[0001628280-24-038024:notes:196]
Allowance for current expected credit losses

[0001628280-24-038024:notes:197]
We did not have any allowance for credit losses other than our allowance for uncollectible accounts receivable. As of June 29, 2024 and July 1, 2023, the allowance for credit losses on our trade receivables were $0.2 million and less than $0.1 million, respectively.

[0001628280-24-038024:notes:198]
Inventories

[0001628280-24-038024:notes:199]
The components of inventories were as follows (in millions):

[0001628280-24-038024:notes:200]
|  | June 29, 2024 |  | July 1, 2023 |
| Raw materials and purchased parts | $ | 196.9 |  |  | $ | 170.5 |  |
| Work in process | 101.6 |  |  | 103.2 |  |
| Finished goods | 99.9 |  |  | 134.9 |  |
| Inventories | $ | 398.4 |  |  | $ | 408.6 |  |

[0001628280-24-038024:notes:201]
In connection with the Cloud Light Acquisition, we recorded $71.8 million of inventory as of the Cloud Light Closing date. During the year ended June 29, 2024, we amortized and recognized as cost of sales in our consolidated statements of operations the entire $8.0 million of fair value step-up of inventory acquired from Cloud Light.

[0001628280-24-038024:notes:202]
In connection with the NeoPhotonics acquisition, we recorded $84.3 million of inventory as of the Cloud Light Closing date. During the year ended July 1, 2023, we amortized and recognized as cost of sales in our consolidated statements of operations the entire $17.8 million of fair value step-up of inventory acquired from NeoPhotonics.

[0001628280-24-038024:notes:203]
Property, plant and equipment, net

[0001628280-24-038024:notes:204]
The components of property, plant and equipment, net were as follows (in millions):

[0001628280-24-038024:notes:205]
|  | June 29, 2024 |  | July 1, 2023 |
| Land | $ | 75.2 |  |  | $ | 63.5 |  |
| Buildings and improvement | 215.1 |  |  | 170.3 |  |
| Machinery and equipment | 772.1 |  |  | 657.9 |  |
| Computer equipment and software | 44.9 |  |  | 41.4 |  |
| Furniture and fixtures | 14.3 |  |  | 10.2 |  |
| Leasehold improvements | 47.5 |  |  | 49.6 |  |
| Construction in progress | 71.1 |  |  | 69.2 |  |
|  | 1,240.2 |  |  | 1,062.1 |  |
| Less: Accumulated depreciation | (667.7) |  |  | (572.6) |  |
| Property, plant and equipment, net | $ | 572.5 |  |  | $ | 489.5 |  |

[0001628280-24-038024:notes:206]
Our construction in progress primarily includes machinery and equipment that we expect to place in service in the next 12 months.

[0001628280-24-038024:notes:207]
In connection with the Cloud Light acquisition, we assumed $62.5 million of property, plant and equipment as of the Cloud Light Closing date.

[0001628280-24-038024:notes:208]
In August 2023, we purchased land and buildings that we previously leased in the United Kingdom for a total purchase price of $23.3 million. Additionally, we capitalized $1.8 million of incremental direct costs for fees paid to third parties. We also recorded a $0.3 million reduction in the carrying value of buildings purchased related to the termination of leases for the purchased buildings. The total carrying value of assets purchased is $24.8 million at the purchase date, of which $11.8 million was allocated to the land and $13.0 million to the buildings.

[0001628280-24-038024:notes:209]
During fiscal 2024, 2023 and 2022, we recorded depreciation expense of $110.6 million, $106.6 million, and $81.6 million, respectively.

[0001628280-24-038024:notes:210]
Operating lease right-of-use assets, net

[0001628280-24-038024:notes:211]
Operating lease right-of-use assets, net were as follows (in millions):

[0001628280-24-038024:notes:212]
|  | June 29, 2024 |  | July 1, 2023 |
| Operating lease right-of-use assets | $ | 112.3 |  |  | $ | 116.5 |  |
| Less: accumulated amortization | (39.5) |  |  | (39.2) |  |
| Operating lease right-of-use assets, net | $ | 72.8 |  |  | $ | 77.3 |  |

[0001628280-24-038024:notes:213]
In connection with the Cloud Light acquisition, we acquired $3.7 million of right-of-use assets related to leases of real estate properties used as our manufacturing and office premises.  We accounted for these leases as operating leases and have the remaining lease term ranging from 1.5 to 2.6 years at the Cloud Light Closing date.

[0001628280-24-038024:notes:214]
In connection with the purchase of land and buildings in the United Kingdom in August 2023, we terminated our leases for the purchased buildings and recorded a $0.3 million of reduction in the carrying value of buildings purchased, as a result of derecognizing $4.8 million of net operating lease right-of-use asset, $2.4 million of operating lease liabilities, current, and $2.7 million of operating lease liabilities, non-current.

[0001628280-24-038024:notes:215]
Other current liabilities

[0001628280-24-038024:notes:216]
The components of other current liabilities were as follows (in millions):

[0001628280-24-038024:notes:217]
|  | June 29, 2024 |  | July 1, 2023 |
| Restructuring and related accrual (1) | $ | 11.1 |  |  | $ | 5.0 |  |
| Warranty reserve (2) | 13.2 |  |  | 6.8 |  |
| Deferred revenue and customer deposits | 0.6 |  |  | 2.1 |  |
| Income tax payable (3) | 13.2 |  |  | 28.0 |  |
| Other current liabilities | 3.0 |  |  | 5.9 |  |
| Other current liabilities | $ | 41.1 |  |  | $ | 47.8 |  |

[0001628280-24-038024:notes:218]
(1) Refer to “Note 12. Restructuring and Related Charges.”

[0001628280-24-038024:notes:219]
(2) Refer to “Note 16. Commitments and Contingencies.”

[0001628280-24-038024:notes:220]
(3) Refer to “Note 13. Income Taxes.”

[0001628280-24-038024:notes:221]
Other non-current liabilities

[0001628280-24-038024:notes:222]
The components of other non-current liabilities were as follows (in millions):

[0001628280-24-038024:notes:223]
|  | June 29, 2024 |  | July 1, 2023 |
| Asset retirement obligation | $ | 7.5 |  |  | $ | 8.2 |  |
| Pension and related accrual (1) | 7.5 |  |  | 9.6 |  |
| Unrecognized tax benefit | 83.0 |  |  | 64.4 |  |
| Other non-current liabilities | 5.4 |  |  | 9.2 |  |
| Other non-current liabilities | $ | 103.4 |  |  | $ | 91.4 |  |

[0001628280-24-038024:notes:224]
(1) We have defined benefit pension plans in Japan, Switzerland, and Thailand. Pension and related accrual of $7.5 million as of June 29, 2024 relates to $8.6 million of non-current portion of benefit obligation, offset by $1.2 million of funding for the pension plan in Switzerland. Pension and related accrual of $9.6 million as of July 1, 2023 relates to $10.2 million of non-current portion of benefit obligation, offset by $0.6 million of funding for the pension plan in Switzerland. We typically re-evaluate the assumptions related to the fair value of our defined benefit obligations annually in the fiscal fourth quarter and make any updates as necessary. Refer to “Note 15. Employee Retirement Plans”.


## us-gaap:LesseeFinanceLeasesTextBlock

[0001628280-24-038024:notes:225]
Note 8. Leases

[0001628280-24-038024:notes:226]
We lease certain real and personal property from unrelated third parties under non-cancellable operating leases that expire at various dates through fiscal 2033. These operating leases are primarily for administrative offices, research and development and manufacturing facilities, as well as sales offices in various countries around the world. Certain leases require us to pay property taxes, insurance and routine maintenance, and include escalation clauses. Many leases include one or more options to renew. We do not assume renewals in our determination of the lease term unless the renewals are deemed to be reasonably assured at lease commencement.

[0001628280-24-038024:notes:227]
As of June 29, 2024, we sublease a portion of our offices in the Japan, United Kingdom, the United States and Canada. These subleases will expire at various dates through fiscal year 2028. We anticipate receiving approximately $0.8 million in sublease income over the next fiscal year.

[0001628280-24-038024:notes:228]
The components of lease costs, lease term, and discount rate are as follows (in millions, except for weighted average data):

[0001628280-24-038024:notes:229]
|  | June 29, 2024 |  | July 1, 2023 |  | July 2, 2022 |
| Operating lease cost | $ | 16.8 |  |  | $ | 14.4 |  |  | $ | 13.0 |  |
| Short-term and variable lease cost | 4.6 |  |  | 2.7 |  |  | 2.0 |  |
| Sublease income | (2.0) |  |  | (2.6) |  |  | (3.0) |  |
| Total lease cost | $ | 19.4 |  |  | $ | 14.5 |  |  | $ | 12.0 |  |
| Weighted average remaining lease term (in years): |  |  |  |  |  |
| Operating leases | 5.2 |  | 5.8 |  | 6.9 |
| Weighted average discount rate (in percentages): |  |  |  |  |  |
| Operating leases | 3.5 | % |  | 3.1 | % |  | 3.0 | % |

[0001628280-24-038024:notes:230]
As of June 29, 2024, maturities of our operating lease liabilities, which do not include short-term leases and variable lease payments, were as follows (in millions):

[0001628280-24-038024:notes:231]
| Fiscal Years |  | Operating Leases (1) |  |  |  |  |
| 2025 |  | $ | 15.3 |  |  |  |  |  |
| 2026 |  | 12.9 |  |  |  |  |  |
| 2027 |  | 11.7 |  |  |  |  |  |
| 2028 |  | 8.0 |  |  |  |  |  |
| 2029 |  | 5.7 |  |  |  |  |  |
| Thereafter |  | 8.2 |  |  |  |  |  |
| Total minimum lease payments |  | 61.8 |  |  |  |  |  |
| Less: amount representing interest |  | (5.4) |  |  |  |  |  |
| Present value of total lease liabilities |  | $ | 56.4 |  |  |  |  |  |

[0001628280-24-038024:notes:232]
(1)  Non-cancellable sublease proceeds for fiscal 2025 of $0.8 million are not included in the table above.

[0001628280-24-038024:notes:233]
In July 2024, we purchased the land and building of our wafer fabrication facility located in Sagamihara, Japan for a total transaction price of $46.5 million including related fees and refundable consumption taxes. Our lease of the building at the premises, which was originally scheduled to end in March 2033, was terminated as a result of the purchase. We derecognized the related right-of-use assets of $31.9 million and lease liability of $17.4 million at the purchase completion date. Refer to “Note 19. Subsequent Events”.


## us-gaap:GoodwillDisclosureTextBlock

[0001628280-24-038024:notes:234]
Note 9. Goodwill and Other Intangible Assets

[0001628280-24-038024:notes:235]
In November 2023, we completed the acquisition of Cloud Light. We recognized preliminary goodwill of $360.7 million,

[0001628280-24-038024:notes:236]
which was allocated to the Cloud & Networking segment.

[0001628280-24-038024:notes:237]
In the first quarter of fiscal 2023, we completed two acquisitions, our acquisition of NeoPhotonics and the acquisition of IPG telecom transmission product lines. We recognized goodwill of $315.3 million related to the NeoPhotonics acquisition and $10.9 million related to the acquisition of the IPG telecom transmission product lines as of July 1, 2023. We allocated the entire goodwill amount in connection with these two acquisitions to the Cloud & Networking segment.

[0001628280-24-038024:notes:238]
The following table presents our goodwill balance by the reportable segments as of June 29, 2024 and July 1, 2023 (in millions):

[0001628280-24-038024:notes:239]
|  |  | Cloud & Networking |  | Industrial Tech |  | Total |
|  | Balance as of July 2, 2022 | $ | 357.7 |  |  | $ | 11.2 |  |  | $ | 368.9 |  |
|  | Acquisition of NeoPhotonics (1) | 315.3 |  |  | — |  |  | 315.3 |  |
|  | Acquisition of IPG telecom transmission product lines (2) | 10.9 |  |  | — |  |  | 10.9 |  |
|  | Balance as of July 1, 2023 | $ | 683.9 |  |  | $ | 11.2 |  |  | $ | 695.1 |  |
|  | Acquisition of Cloud Light (3) | 360.7 |  |  | — |  |  | 360.7 |  |
|  | Balances as of June 29, 2024 | $ | 1,044.6 |  |  | $ | 11.2 |  |  | $ | 1,055.8 |  |

[0001628280-24-038024:notes:240]
(1) We recorded $318.3 million of goodwill as of the acquisition date, and $3.0 million of measurement period adjustments to reduce goodwill during the year ended July 1, 2023.

[0001628280-24-038024:notes:241]
(2)  We recorded $6.5 million of goodwill as of the acquisition date, and $4.4 million of measurement period adjustments to increase goodwill during the year ended July 1, 2023.

[0001628280-24-038024:notes:242]
(3) We recorded $359.5 million of goodwill as of the acquisition date and $1.2 million of measurement period adjustments to increase goodwill during the year ended June 29, 2024.

[0001628280-24-038024:notes:243]
Impairment of Goodwill

[0001628280-24-038024:notes:244]
We review goodwill for impairment during the fourth quarter of each fiscal year or more frequently if events or circumstances indicate that an impairment loss may have occurred. Based on the impairment analysis performed in the fourth quarter of each year presented, the fair value of each of our reporting units substantially exceeded the carrying value; as such, our annual qualitative assessment did not indicate that a more detailed quantitative analysis was necessary.

[0001628280-24-038024:notes:245]
Other Intangibles

[0001628280-24-038024:notes:246]
Our intangible assets are amortized on a straight-line basis over the estimated useful lives, except for certain customer relationships, which are amortized using an accelerated method of amortization over the expected customer lives, more accurately reflecting the pattern of realization of economic benefits we expect to derive. Acquired developed technologies are amortized to cost of sales and research and development expenses. Acquired customer relationships are amortized to selling, general and administrative expenses in the consolidated statement of operations.

[0001628280-24-038024:notes:247]
IPR&D is initially capitalized at fair value as an intangible asset with an indefinite life and assessed for impairment thereafter. When an IPR&D project is completed, the IPR&D is reclassified to an amortizable purchased intangible asset and amortized over the asset’s estimated useful life.

[0001628280-24-038024:notes:248]
During the annual impairment testing performed in the fourth quarter of each year presented, we concluded that our intangible and other long-lived assets were not impaired at the asset group level. We review our intangible and other long-lived assets for impairment at least annually in the fourth quarter of each fiscal year, absent any interim indicators of impairment. There were no indicators of impairment at the asset group level during the years ended June 29, 2024 and July 1, 2023.

[0001628280-24-038024:notes:249]
In November 2023, we completed the acquisition of Cloud Light. The intangible assets acquired from the acquisition were as follows as of the acquisition date (in millions, except for weighted average amortization period):

[0001628280-24-038024:notes:250]
|  | Fair Value at the Acquisition Date |  | Weighted Average Amortization Period(Years) |
| Acquired developed technologies | $ | 170.0 |  |  | 7.0 |
| Customer relationships | 130.0 |  |  | 7.0 |
| In-process research and development | 16.0 |  |  | n/a |
| Order backlog | 14.0 |  |  | 1.0 |
| Trade name and trademarks | 3.0 |  |  | 1.2 |
| Total intangible assets | $ | 333.0 |  |  |  |

[0001628280-24-038024:notes:251]
During the year ended June 29, 2024, we reclassified $10.3 million of IPR&D intangible assets acquired from Cloud Light to acquired developed technologies for IPR&D projects that were completed during the period. We recorded $0.1 million of related amortization expense in our consolidated statements of operations during the year ended June 29, 2024.

[0001628280-24-038024:notes:252]
In connection with the acquisition of NeoPhotonics and the IPG telecom transmission product lines in fiscal 2023, we recorded $452.5 million of intangible assets. Refer to “Note 4. Business Combination”. The intangible assets acquired from the acquisitions were as follows as of the acquisition date (in millions, except for weighted average amortization period):

[0001628280-24-038024:notes:253]
|  | Fair value at the acquisition date |  | Weighted average amortization period(in years) |
|  | NeoPhotonics |  | IPG telecom transmission product lines |  | Total acquired |  |
| Acquired developed technologies | $ | 220.0 |  |  | $ | 8.6 |  |  | $ | 228.6 |  |  | 5.2 |
| Customer relationships | 144.5 |  |  | 2.3 |  |  | 146.8 |  |  | 5.9 |
| In-process research and development | 48.0 |  |  | 29.1 |  |  | 77.1 |  |  | n/a |
| Total intangible assets | $ | 412.5 |  |  | $ | 40.0 |  |  | $ | 452.5 |  |  |  |

[0001628280-24-038024:notes:254]
During the years ended June 29, 2024 and July 1, 2023, we reclassified $1.9 million and $23.3 million, respectively, of IPR&D intangible assets acquired from NeoPhotonics to acquired developed technologies for IPR&D projects that were completed during the periods. We recorded $0.3 million and $2.6 million of related amortization expense in our consolidated statements of operations during the years ended June 29, 2024 and July 1, 2023, respectively.

[0001628280-24-038024:notes:255]
During the year ended June 29, 2024, we discontinued our in-house development of coherent DSPs and RFICs. As a result, we recorded $35.8 million of restructuring and related charges during the fiscal fourth quarter of 2024, which includes $29.1 million write-off of IPR&D assets acquired as part of the acquisition of IPG telecom transmission product lines, as well as $6.7 million of contract exit costs and asset write-off. Refer to “Note 12. Restructuring and Related Charges”.

[0001628280-24-038024:notes:256]
During the year ended July 1, 2023, we recorded a total charge of $21.3 million to write-off acquired intangible assets, which includes $12.9 million of research and development expense for IPR&D intangible assets acquired from NeoPhotonics for projects we will no longer pursue, and $6.8 million of cost of sales for developed technologies acquired from IPG and $1.6 million of selling, general and administrative expense for customer relationship acquired from IPG primarily due to product discontinuation as well as changes in customer demand.

[0001628280-24-038024:notes:257]
The following tables present details of all of our intangibles, including those acquired in connection with our acquisitions in fiscal 2024 and fiscal 2023, as of the periods presented (in millions, except for weighted average remaining amortization period):

[0001628280-24-038024:notes:258]
| June 29, 2024 | Gross Carrying Amounts |  | Accumulated Amortization |  | Net Carrying Amounts |  | Weighted average remaining amortization period (years) |
| Acquired developed technologies | $ | 818.1 |  |  | $ | (473.0) |  |  | $ | 345.1 |  |  | 4.8 |
| Customer relationships | 419.8 |  |  | (169.4) |  |  | 250.4 |  |  | 4.9 |
| In-process research and development | 15.5 |  |  | — |  |  | 15.5 |  |  | n/a |
| Order backlog | 14.0 |  |  | (8.9) |  |  | 5.1 |  |  | 0.4 |
| Trade name and trademarks | 3.0 |  |  | (1.6) |  |  | 1.4 |  |  | 0.6 |
| Total intangible assets | $ | 1,270.4 |  |  | $ | (652.9) |  |  | $ | 617.5 |  |  |  |

[0001628280-24-038024:notes:259]
| July 1, 2023 | Gross Carrying Amounts |  | Accumulated Amortization |  | Net Carrying Amounts |  | Weighted average remaining amortization period (years) |
| Acquired developed technologies | $ | 630.9 |  |  | $ | (385.5) |  |  | $ | 245.4 |  |  | 4.2 |
| Customer relationships | 289.7 |  |  | (116.8) |  |  | 172.9 |  |  | 3.7 |
| In-process research and development | 40.9 |  |  | — |  |  | 40.9 |  |  | n/a |
| Total intangible assets | $ | 961.5 |  |  | $ | (502.3) |  |  | $ | 459.2 |  |  |  |

[0001628280-24-038024:notes:260]
During fiscal 2024, 2023 and 2022, we recorded $150.6 million, $127.7 million and $85.5 million, respectively, of amortization related to intangibles assets.

[0001628280-24-038024:notes:261]
The following table presents details of amortization for the periods presented (in millions):

[0001628280-24-038024:notes:262]
|  | Years ended |
|  | June 29, 2024 |  | July 1, 2023 |  |  |  | July 2, 2022 |
| Cost of sales | $ | 83.9 |  |  | $ | 84.4 |  |  |  |  | $ | 62.9 |  |
| Selling, general and administrative | 65.2 |  |  | 43.3 |  |  |  |  | 22.6 |  |
| Research and development | 1.5 |  |  | — |  |  |  |  | — |  |
| Total amortization of intangibles | $ | 150.6 |  |  | $ | 127.7 |  |  |  |  | $ | 85.5 |  |

[0001628280-24-038024:notes:263]
Based on the carrying amount of our intangible assets as of June 29, 2024, and assuming no future impairment of the underlying assets, the estimated future amortization is as follows (in millions):

[0001628280-24-038024:notes:264]
| Fiscal Years |  |
| 2025 | $ | 149.4 |  |
| 2026 | 133.3 |  |
| 2027 | 121.0 |  |
| 2028 | 81.5 |  |
| 2029 | 51.8 |  |
| Thereafter | 65.0 |  |
| Total | $ | 602.0 |  |

[0001628280-24-038024:notes:265]
The table above excludes in-process research and development intangible assets.


## us-gaap:ScheduleOfFiniteLivedIntangibleAssetsTableTextBlock

[0001628280-24-038024:notes:266]
The intangible assets acquired from the acquisitions were as follows as of the acquisition date (in millions, except for weighted average amortization period):


## us-gaap:DebtDisclosureTextBlock

[0001628280-24-038024:notes:267]
Note 10. Debt

[0001628280-24-038024:notes:268]
Convertible Notes

[0001628280-24-038024:notes:269]
2029 Notes

[0001628280-24-038024:notes:270]
On June 16, 2023, we issued $603.7 million in aggregate principal amount of 2029 Notes in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act of 1933, as amended. The 2029 Notes are governed by an indenture between the Company and U.S. Bank Trust Company National Association, (as successor in interest to U.S. Bank National Association), as a trustee (the “2029 Indenture”). The 2029 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001628280-24-038024:notes:271]
The net proceeds from the sale of the 2029 Notes was $599.4 million, after deducting $4.3 million of net issuance costs. In addition, we incurred $0.8 million of professional fees directly related to this transaction. Concurrent with the issuance of the 2029 Notes, we used $132.8 million of the net proceeds to repurchase $125.0 million aggregate principal amount of the 2024 Notes and $125.0 million of the net proceeds to repurchase our common stock in privately negotiated transactions. We intend to use the remaining net proceeds for general corporate purposes, which may include the repayment of our indebtedness, including any of our existing convertible notes, capital expenditures, working capital and potential acquisitions.

[0001628280-24-038024:notes:272]
The 2029 Notes bear interest at a rate of 1.50% per year, payable semi-annually in arrears on June 15 and December 15 of each year, beginning on December 15, 2023. The 2029 Notes will mature on December 15, 2029, unless earlier redeemed, repurchased by us, or converted pursuant to their terms.

[0001628280-24-038024:notes:273]
The initial conversion rate is 14.3808 shares of common stock per $1,000 principal amount of the 2029 Notes (which is equivalent to an initial conversion price of approximately $69.54 per share). The conversion rate is subject to adjustment upon the occurrence of certain events specified in the 2029 Indenture, but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert the 2029 Notes in connection with such make-whole fundamental change or notice of redemption.

[0001628280-24-038024:notes:274]
Prior to the close of business on the business day immediately preceding September 15, 2029, holders of the 2029 Notes may convert their 2029 Notes only under the following circumstances:

[0001628280-24-038024:notes:275]
•during any fiscal quarter commencing after September 30, 2023 (and only during such fiscal quarter), if the last reported sale price of the common stock for at least 20 trading days (whether or not consecutive) during the period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% if the applicable conversion price on each applicable trading day;

[0001628280-24-038024:notes:276]
•during the five consecutive business day period after any five consecutive trading day period (the “2029 measurement period”) in which the trading price per $1,000 principal amount of 2029 Notes for each trading day of the 2029 measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate on each such trading day;

[0001628280-24-038024:notes:277]
•if we call any or all of the 2029 Notes for redemption, at any time prior to the close of business on the second business day immediately preceding the redemption date; or

[0001628280-24-038024:notes:278]
•upon the occurrence of specified corporate events as specified in the 2029 Indenture.

[0001628280-24-038024:notes:279]
On or after September 15, 2029 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their 2029 Notes at any time. Upon conversion, we will satisfy our conversion obligation in cash, shares of common stock or a combination of cash and shares of common stock, at our election.

[0001628280-24-038024:notes:280]
We may redeem for cash all or any portion of the 2029 Notes, at our option (subject to the partial redemption limitation set forth in the 2029 Indenture), on or after June 22, 2026, if the last reported sale price of our  common stock has been at least 130% of the conversion price then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading-day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which we provide notice of redemption at a redemption price equal to 100% of the principal amount of the 2029 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. No sinking fund is provided for the 2029 Notes. If we elect to redeem fewer than all of the outstanding 2029 Notes, at least $100.0 million aggregate principal amount of the 2029 Notes must be outstanding and not subject to redemption as of the redemption notice date. Upon the occurrence of a fundamental change (as defined in the 2029 Indenture), holders may require us to repurchase all or a portion of their 2029 Notes for cash at a price equal to 100% of the principal amount of the 2029 Notes to be repurchased, plus any accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

[0001628280-24-038024:notes:281]
The entire 2029 Notes are recorded as convertible notes, non-current in our consolidated balance sheets as of June 29, 2024 and July 1, 2023, measured at amortized cost.

[0001628280-24-038024:notes:282]
2028 Notes

[0001628280-24-038024:notes:283]
In March 2022, we issued $861.0 million in aggregate principal amount of 2028 Notes in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act of 1933, as amended. The 2028 Notes are governed by an indenture between the Company and U.S. Bank Trust Company National Association (as successor in interest to U.S. Bank National Association), as a trustee (the “2028 Indenture”). The 2028 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001628280-24-038024:notes:284]
The net proceeds from the sale of the 2028 Notes was $854.8 million, after deducting $6.2 million in issuance costs. In addition, we incurred $0.7 million of professional fees directly related to this transaction.  Concurrent with the issuance of the 2028 Notes, we used $200.0 million of the net proceeds to repurchase our common stock in privately negotiated transactions.

[0001628280-24-038024:notes:285]
The 2028 Notes bear interest at a rate of 0.50% per year, payable semi-annually in arrears on June 15 and December 15 of each year, beginning on June 15, 2022. The 2028 Notes will mature on June 15, 2028, unless earlier redeemed, repurchased by us, or converted pursuant to their terms.

[0001628280-24-038024:notes:286]
The initial conversion rate is 7.6319 shares of common stock per $1,000 principal amount of the 2028 Notes (which is equivalent to an initial conversion price of approximately $131.03 per share). The conversion rate is subject to adjustment upon the occurrence of certain events specified in the 2028 Indenture, but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert the 2028 Notes in connection with such make-whole fundamental change or notice of redemption.

[0001628280-24-038024:notes:287]
Prior to the close of business on the business day immediately preceding March 15, 2028, holders of the 2028 Notes may convert their 2028 Notes only under the following circumstances:

[0001628280-24-038024:notes:288]
•during any fiscal quarter (and only during such fiscal quarter), if the last reported sale price of the common stock for at least 20 trading days (whether or not consecutive) during the 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% if the applicable conversion price, or $170.34 on each applicable trading day;

[0001628280-24-038024:notes:289]
•during the five consecutive business day period after any five consecutive trading day period (the “2028 measurement period”) in which the trading price per $1,000 principal amount of the 2028 Notes for each trading day of the 2028 measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate on each such trading day;

[0001628280-24-038024:notes:290]
•if we call any or all of the 2028 Notes for redemption, at any time prior to the close of business on the second business day immediately preceding the redemption date; or

[0001628280-24-038024:notes:291]
•upon the occurrence of specified corporate events as specified in the 2028 Indenture.

[0001628280-24-038024:notes:292]
On or after March 15, 2028 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their 2028 Notes at any time. Upon conversion, we may satisfy our conversion obligation in cash, shares of common stock or a combination of cash and shares of common stock, at our election.

[0001628280-24-038024:notes:293]
We may redeem for cash all or any portion of the 2028 Notes, at our option (subject to the partial redemption limitation set forth in the 2028 Indenture), on or after June 20, 2025, if the last reported sale price of its common stock has been at least 130% of the conversion price then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading-day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which we provide notice of redemption at a redemption price equal to 100% of the principal amount of the 2028 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. No sinking fund is provided for the 2028 Notes. If we elect to redeem fewer than all of the outstanding 2028 Notes, at least $100.0 million aggregate principal amount of the 2028 Notes must be outstanding and not subject to redemption as of the redemption notice date.  Upon the occurrence of a fundamental change (as defined in the 2028 Indenture), holders may require us to repurchase all or a portion of their 2028 Notes for cash at a price equal to 100% of the principal amount of the 2028 Notes to be repurchased, plus any accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

[0001628280-24-038024:notes:294]
We initially bifurcated the principal amount of the 2028 Notes into liability and equity components. The liability component of the 2028 Notes was initially valued at $629.8 million based on the contractual cash flow discounted at an appropriate comparable market on the non-convertible debt borrowing rate at the date of issuance, which was 5.7%, with the equity component representing the residual amount of the proceeds of $231.2 million, which was recorded as a debt discount. Upon adoption of ASU 2020-06 in the first quarter of fiscal 2023, our 2028 Notes were accounted for as a single liability measured at amortized cost.  The entire 2028 Notes are recorded as convertible notes, non-current in our consolidated balance sheets as of June 29, 2024 and July 1, 2023, measured at amortized cost.

[0001628280-24-038024:notes:295]
2026 Notes

[0001628280-24-038024:notes:296]
In December 2019, we issued $1,050.0 million in aggregate principal amount of the 2026 Notes in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act. The 2026 Notes are governed by an indenture between the Company and U.S. Bank Trust Company National Association (as successor in interest to U.S. Bank National Association), as trustee (the “2026 Indenture”). We used approximately $196.0 million of the net proceeds of the offering to repay in full all amounts outstanding under our term loan facility, and a portion of the net proceeds of the offering to purchase approximately $200.0 million of our common stock concurrently with the pricing of the offering in privately negotiated transactions. The 2026 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, the incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001628280-24-038024:notes:297]
The 2026 Notes bear interest at a rate of 0.50% per year, payable semi-annually in arrears on June 15 and December 15 of each year, beginning on June 15, 2020. The 2026 Notes will mature on December 15, 2026, unless earlier redeemed, repurchased by us, or converted pursuant to their terms.

[0001628280-24-038024:notes:298]
The initial conversion rate is 10.0711 shares of common stock per $1,000 principal amount of the 2026 Notes (which is equivalent to an initial conversion price of approximately $99.29 per share). The conversion rate is subject to adjustment upon the occurrence of certain events specified in the 2026 Indenture, but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares set forth in the 2026 Indenture or a holder that elects to convert the 2026 Notes in connection with such make-whole fundamental change or notice of redemption.

[0001628280-24-038024:notes:299]
Prior to the close of business on the business day immediately preceding September 15, 2026, holders of the 2026 Notes may convert their 2026 Notes only under the following circumstances:

[0001628280-24-038024:notes:300]
•during any fiscal quarter (and only during such fiscal quarter), if the last reported sale price of the common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price of the 2026 Notes, or $129.08 on each applicable trading day;

[0001628280-24-038024:notes:301]
•during the five business day period after any five consecutive trading day period (the "2026 measurement period") in which the trading price per $1,000 principal amount of the 2026 Notes for each trading day of the 2026 measurement period was less than 98% of the product of the last reported sale price of our common stock and the conversion rate for the 2026 Notes on each such trading day;

[0001628280-24-038024:notes:302]
•if we call any or all of the 2026 Notes for redemption, at any time prior to the close of business on the second business day immediately preceding the relevant redemption date; or

[0001628280-24-038024:notes:303]
•upon the occurrence of specified corporate events as specified in the 2026 Indenture.

[0001628280-24-038024:notes:304]
On or after September 15, 2026 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert the 2026 Notes at any time. Upon conversion, we may satisfy our conversion obligation in cash, shares of common stock or a combination of cash and shares of common stock, at our election.

[0001628280-24-038024:notes:305]
We may redeem for cash, for all or any portion of the 2026 Notes, at our option, on or after December 20, 2023, if the last reported sale price of its common stock has been at least 130% of the conversion price then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading-day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which we provide a notice of redemption at a redemption price equal to 100% of the principal amount of the 2026 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. No sinking fund is provided for the 2026 Notes. Upon the occurrence of a fundamental change (as defined in the 2026 Indenture), holders may require us to repurchase all or a portion of the 2026 Notes for cash at a price equal to 100% of the principal amount of the 2026 Notes to be repurchased, plus any accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

[0001628280-24-038024:notes:306]
We initially bifurcated the principal amount of the 2026 Notes into liability and equity components. The liability component of the 2026 Notes was valued at $734.8 million based on the contractual cash flows discounted at an appropriate comparable market non-convertible debt borrowing rate at the date of issuance of 5.8% with the equity component representing the residual amount of the proceeds of $315.2 million, which was recorded as a debt discount.  Upon adoption of ASU 2020-06 in the first quarter of fiscal 2023, our 2026 Notes were accounted for as a single liability measured at amortized cost. The entire 2026 Notes are recorded as convertible notes, non-current in our consolidated balance sheets as of June 29, 2024 and July 1, 2023, measured at amortized cost.

[0001628280-24-038024:notes:307]
2024 Notes

[0001628280-24-038024:notes:308]
In March 2017, we issued $450.0 million in aggregate principal amount of the 2024 Notes in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act. The 2024 Notes were governed by an indenture between the Company, and U.S. Bank Trust Company National Association (as successor in interest to U.S. Bank National Association), as trustee (the “2024 Indenture”). The 2024 Notes were unsecured and did not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001628280-24-038024:notes:309]
The 2024 Notes bore interest at a rate of 0.25% per year. Interest on the 2024 Notes was payable semi-annually in arrears on March 15 and September 15 of each year, beginning on September 15, 2017. The 2024 Notes matured on March 15, 2024.

[0001628280-24-038024:notes:310]
The initial conversion rate of the 2024 Notes was 16.4965 shares of common stock per $1,000 principal amount of 2024 Notes, which was equivalent to an initial conversion price of approximately $60.62 per share. The conversion rate was subject to adjustment upon the occurrence of certain specified events, but was not subject to adjustment for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change (as defined in the 2024 Indenture) or our issuance of a notice of redemption, we were required to, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elected to convert the 2024 Notes in connection with such make-whole fundamental change or notice of redemption.

[0001628280-24-038024:notes:311]
Prior to the close of business on the business day immediately preceding December 15, 2023, each holder of the 2024 Notes was able to convert their 2024 Notes only under the following circumstances:

[0001628280-24-038024:notes:312]
•during any fiscal quarter (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during the period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price, or $78.80 on each applicable trading day;

[0001628280-24-038024:notes:313]
•during the five consecutive business day period after any five consecutive trading day period (the “2024 measurement period”) in which the trading price per $1,000 principal amount of 2024 Notes for each trading day of such 2024 measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate on each such trading day;

[0001628280-24-038024:notes:314]
•upon the occurrence of specified corporate events as specified in the 2024 Indenture.

[0001628280-24-038024:notes:315]
On or after December 15, 2023 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders could convert their 2024 Notes at any time. In addition, upon the occurrence of a make-whole fundamental change (as defined in the 2024 Indenture), we were required to, in certain circumstances, increase the conversion rate by a number of additional shares set forth in the 2024 Indenture for a holder that elected to convert 2024 Notes in connection with such make-whole fundamental change.

[0001628280-24-038024:notes:316]
We could not redeem the 2024 Notes prior to their maturity date and no sinking fund was provided for the 2024 Notes. Upon the occurrence of a fundamental change, holders could require us to repurchase all or a portion of their 2024 Notes for cash at a price equal to 100% of the principal amount of the 2024 Notes to be repurchased, plus any accrued and unpaid interest.

[0001628280-24-038024:notes:317]
We considered the features embedded in the 2024 Notes other than the conversion feature, including the holders’ put feature, our call feature, and the make-whole feature, and concluded that they were not required to be bifurcated and accounted for separately from the host debt instrument.

[0001628280-24-038024:notes:318]
Prior to the Tax Matters Agreement settlement condition (“TMA settlement condition”), because we could only settle the 2024 Notes in cash, we determined that the conversion feature met the definition of a derivative liability. We separated the derivative liability from the host debt instrument based on the fair value of the derivative liability. As of the issuance date, March 8, 2017, the derivative liability fair value of $129.9 million was calculated using the binomial valuation approach. The residual principal amount of the 2024 Notes of $320.1 million before issuance costs was allocated to the debt component. We incurred approximately $7.7 million in transaction costs in connection with the issuance of the 2024 Notes. These costs were allocated to the debt component and recognized as a debt discount. We amortize the debt discount, including both the initial value of the derivative liability and the transaction costs, over the term of the 2024 Notes using the effective interest method. The effective interest rate of the 2024 Notes was 5.4% per year.

[0001628280-24-038024:notes:319]
During fiscal 2017, we satisfied the TMA settlement condition. As such, the value of the conversion option was no longer marked-to-market and was reclassified to additional paid-in capital within stockholders’ equity on our consolidated balance sheet. The value of the conversion option at the time of issuance was treated as an original issue discount for purposes of accounting for the debt component of the 2024 Notes. The debt component accreted up to the principal amount over the expected term of the debt. The adoption of ASU 2020-06 did not change the presentation of the 2024 Notes, as the conversion feature associated with the 2024 Notes continues to be classified within stockholders’ equity.

[0001628280-24-038024:notes:320]
Concurrent with the issuance of the 2029 Notes, we used $132.8 million of the net proceeds to repurchase $125.0 million aggregate principal amount of the 2024 Notes, which we accounted for as an extinguishment of liability. $13.5 million of the $132.8 million repurchase price was allocated to the conversion feature of the repurchased 2024 Notes, representing the fair value of the conversion feature at the date of the repurchase, and was recognized as a reduction of the stockholders’ equity. Refer to consolidated statements of stockholders’ equity. We recognized an extinguishment gain of $1.0 million related to the repurchase, which was recorded under other income, net on our consolidated statements of operations for the year ended July 1, 2023.  Additionally, since issuing the 2024 Notes, we have converted a total of approximately $1.9 million of principal amount of the 2024 Notes, with less than $0.1 million of principal amount converted during  the twelve months ended June 29, 2024.

[0001628280-24-038024:notes:321]
On March 15, 2024, the 2024 Notes maturity date, we fully repaid the remaining principal amount of $323.1 million. The conversion feature previously classified within stockholder’s equity was fully amortized as of the maturity date.

[0001628280-24-038024:notes:322]
Convertible Notes - Additional Disclosures

[0001628280-24-038024:notes:323]
Our convertible notes consisted of the following components as of the periods presented (in millions):

[0001628280-24-038024:notes:324]
| June 29, 2024 |  |  | 2026 Notes (1) |  | 2028 Notes (2) |  | 2029 Notes (3) |  | Total |
| Principal |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |  | $ | 603.7 |  |  | $ | 2,514.7 |  |
| Unamortized debt discount and debt issuance costs |  |  | (2.8) |  |  | (4.4) |  |  | (4.3) |  |  | (11.5) |  |
| Net carrying amount of the liability component |  |  | $ | 1,047.2 |  |  | $ | 856.6 |  |  | $ | 599.4 |  |  | $ | 2,503.2 |  |

[0001628280-24-038024:notes:325]
| July 1, 2023 | 2024 Notes |  | 2026 Notes (1) |  | 2028 Notes (2) |  | 2029 Notes (3) |  | Total |
| Principal | $ | 323.1 |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |  | $ | 603.7 |  |  | $ | 2,837.8 |  |
| Unamortized debt discount and debt issuance costs | (11.5) |  |  | (4.1) |  |  | (5.5) |  |  | (5.1) |  |  | (26.2) |  |
| Net carrying amount of the liability component | $ | 311.6 |  |  | $ | 1,045.9 |  |  | $ | 855.5 |  |  | $ | 598.6 |  |  | $ | 2,811.6 |  |

[0001628280-24-038024:notes:326]
(1) If the closing price of our stock exceeds $129.08 (or 130% of the conversion price of $99.29 for 20 of the last 30 trading days of any future quarter, the 2026 Notes would also become convertible at the option of the holders during the subsequent fiscal quarter and the debt would be reclassified to current liabilities in our consolidated balance sheets.

[0001628280-24-038024:notes:327]
(2) If the closing price of our stock exceeds $170.34 (or 130% of the conversion price of $131.03) for 20 of the last 30 trading days of any future quarter, the 2028 Notes would become convertible at the option of the holders during the subsequent fiscal quarter and the debt would be reclassified to current liabilities in our consolidated balance sheets.

[0001628280-24-038024:notes:328]
(3) If the closing price of our stock exceeds $90.40 (or 130% of the conversion price of $69.54) for 20 of the last 30 trading days of any future quarter, the 2029 Notes would become convertible at the option of the holders during the subsequent fiscal quarter and the debt would be reclassified to current liabilities in our consolidated balance sheets.

[0001628280-24-038024:notes:329]
The following table sets forth interest expense information related to our convertible notes for the periods presented (in millions):

[0001628280-24-038024:notes:330]
|  |  |  |  |  | June 29, 2024 |  | July 1, 2023 |  | July 2, 2022 |
| Contractual interest expense |  |  |  |  | $ | 19.2 |  |  | $ | 11.2 |  |  | $ | 7.8 |  |
| Amortization of the debt discount and debt issuance costs |  |  |  |  | 14.6 |  |  | 24.3 |  |  | 72.4 |  |
| Total interest expense |  |  |  |  | $ | 33.8 |  |  | $ | 35.5 |  |  | $ | 80.2 |  |

[0001628280-24-038024:notes:331]
The future interest and principal payments related to our convertible notes are as follows as of June 29, 2024 (in millions):

[0001628280-24-038024:notes:332]
| Fiscal Years |  |  | 2026 Notes |  | 2028 Notes |  | 2029 Notes |  | Total |
| 2025 |  |  | $ | 5.3 |  |  | $ | 4.3 |  |  | $ | 9.1 |  |  | $ | 18.7 |  |
| 2026 |  |  | 5.3 |  |  | 4.3 |  | 9.1 |  |  | 18.7 |  |
| 2027 |  |  | 1,052.5 |  |  | 4.3 |  | 9.1 |  |  | 1,065.9 |  |
| 2028 |  |  | — |  |  | 865.3 |  | 9.1 |  |  | 874.4 |  |
| 2029 |  |  | — |  |  | — |  |  | 617.1 |  |  | 617.1 |  |
| Total payments |  |  | $ | 1,063.1 |  |  | $ | 878.2 |  |  | $ | 653.5 |  |  | $ | 2,594.8 |  |

[0001628280-24-038024:notes:333]
The principal balances of our convertible notes are reflected in the payment periods in the table above based on their respective contractual maturities.

[0001628280-24-038024:notes:334]
Mitsubishi Bank Loans
In connection with our acquisition of NeoPhotonics, we assumed several loan agreements with MUFG Bank, Ltd. (the “Mitsubishi Bank Loans”) for an aggregate fair value of approximately $5.9 million, which was fully paid in fiscal 2023


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001628280-24-038024:notes:335]
Note 11. Accumulated Other Comprehensive Income

[0001628280-24-038024:notes:336]
Our accumulated other comprehensive income (loss) consists of the accumulated net unrealized gains or losses on foreign currency translation adjustments, defined benefit obligations, and available-for-sale securities.

[0001628280-24-038024:notes:337]
The changes in accumulated other comprehensive income (loss), net of tax, were as follows for the periods as presented (in millions):

[0001628280-24-038024:notes:338]
|  | Foreign currency translation adjustments, net of tax (1) |  | Defined benefit obligations, net of tax (2) |  | Unrealized gain (loss) on available-for-sale securities, net of tax (3) |  | Total |
| Ending balance as of July 3, 2021 | $ | 9.7 |  |  | $ | (1.4) |  |  | $ | (0.1) |  |  | $ | 8.2 |  |
| Other comprehensive income (loss) | — |  |  | 2.4 |  |  | (10.2) |  |  | (7.8) |  |
| Ending balance as of July 2, 2022 | $ | 9.7 |  |  | $ | 1.0 |  |  | $ | (10.3) |  |  | $ | 0.4 |  |
| Other comprehensive income (loss) | 0.7 |  |  | (1.4) |  |  | 4.4 |  |  | 3.7 |  |
| Ending balance as of July 1, 2023 | $ | 10.4 |  |  | $ | (0.4) |  |  | $ | (5.9) |  |  | $ | 4.1 |  |
| Other comprehensive income (loss) | (0.6) |  |  | 1.1 |  |  | 4.7 |  |  | 5.2 |  |
| Ending balance as of June 29, 2024 | $ | 9.8 |  |  | $ | 0.7 |  |  | $ | (1.2) |  |  | $ | 9.3 |  |

[0001628280-24-038024:notes:339]
(1) In fiscal 2019, as a result of significant changes in economic facts and circumstances, primarily due to the acquisition of Oclaro, we established the functional currency for our worldwide operations as the U.S. dollar. Translation adjustments reported prior to December 10, 2018 remain as a component of accumulated other comprehensive income in our consolidated balance sheets, until all or a part of the investment in the subsidiaries is sold or liquidated. In fiscal 2023, we acquired IPG telecom transmission product lines. The functional currency of the Brazilian entities acquired as part of this acquisition is the local currency.

[0001628280-24-038024:notes:340]
(2) We evaluate the assumptions over the fair value of our defined benefit obligations annually and make changes as necessary. During fiscal 2024, 2023 and 2022, our income (loss) on defined benefit obligations is presented net of tax of $0.4 million, nil, and $1.5 million, respectively.
(3) In fiscal 2024, 2023 and 2022, our unrealized gain (loss) on available-for-sale securities is presented net of tax of $1.7 million, $0.8 million and $2.8 million, respectively.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001628280-24-038024:notes:341]
Note 12. Restructuring and Related Charges

[0001628280-24-038024:notes:342]
We have initiated various strategic restructuring actions primarily to reduce costs, consolidate our operations, rationalize the manufacturing of our products and align our business in response to market conditions and as a result of our acquisitions.

[0001628280-24-038024:notes:343]
The following table summarizes the activities of restructuring and related charges during the periods presented (in millions):

[0001628280-24-038024:notes:344]
|  | Years Ended |  |  |
|  | June 29, 2024 |  | July 1, 2023 |  |  |  | July 2, 2022 |  |  |
| Balance as of beginning of period | $ | 5.0 |  |  | $ | — |  |  |  |  | $ | 5.7 |  |  |  |
| Charges (reversals), net | 72.6 |  |  | 28.1 |  |  |  |  | (1.1) |  |  |  |
| Payments | (66.5) |  |  | (23.1) |  |  |  |  | (4.6) |  |  |  |
| Balance as of end of period | $ | 11.1 |  |  | $ | 5.0 |  |  |  |  | $ | — |  |  |  |

[0001628280-24-038024:notes:345]
During the year ended June 29, 2024, we recorded restructuring and related charges of $72.6 million. We discontinued our in-house development of coherent DSPs and RFICs. As a result, we recorded $35.8 million of restructuring and related charges during the fiscal fourth quarter of 2024, which includes $29.1 million write-off of IPR&D assets, as well as $6.7 million of contract exit costs and asset write-offs. The remaining $36.8 million of restructuring and related charges are primarily due to company-wide cost reduction initiatives, as well as our integration efforts to consolidate our manufacturing sites. We have shut down our factories in China which were acquired as part of the NeoPhotonics acquisition and are ramping up production of most of the related products at our Thailand facility. We are also executing our plans to consolidate our wafer fabrication facilities in Japan.

[0001628280-24-038024:notes:346]
During the year ended July 1, 2023, we recorded restructuring and related charges of $28.1 million in our consolidated statements of operations, which was primarily attributable to company-wide integration efforts as a result of the NeoPhotonics acquisition, our cost reduction initiatives, as well as severance and employee-related benefits associated with NeoPhotonics’ executive severance and retention agreements. These agreements provide for payments and benefits upon an involuntary termination of employment under certain circumstances.

[0001628280-24-038024:notes:347]
During the year ended July 2, 2022, we recorded a net reversal to our restructuring and related charges  of  $1.1 million  in our consolidated statements of operations, which was primarily attributable to lower than anticipated employee severance charges due to retaining and re-assigning certain employees.

[0001628280-24-038024:notes:348]
Any changes in the estimates of executing our restructuring activities will be reflected in our future results of operations.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-24-038024:notes:349]
Note 13. Income Taxes

[0001628280-24-038024:notes:350]
Our income before income taxes consisted of the following (in millions):

[0001628280-24-038024:notes:351]
|  | Years Ended |
|  | June 29, 2024 |  | July 1, 2023 |  | July 2, 2022 |
| Domestic | $ | (219.6) |  |  | $ | (44.3) |  |  | $ | 77.5 |  |
| Foreign | (186.1) |  |  | (58.1) |  |  | 157.6 |  |
| Income before income taxes | $ | (405.7) |  |  | $ | (102.4) |  |  | $ | 235.1 |  |

[0001628280-24-038024:notes:352]
Our income tax provision consisted of the following (in millions):

[0001628280-24-038024:notes:353]
|  | Years Ended |
|  | June 29, 2024 |  | July 1, 2023 |  | July 2, 2022 |
| Federal: |  |  |  |  |  |
| Current | $ | (10.6) |  |  | $ | 12.9 |  |  | $ | 13.7 |  |
| Deferred | 124.0 |  |  | (22.5) |  |  | 1.0 |  |
|  | 113.4 |  |  | (9.6) |  |  | 14.7 |  |
| State: |  |  |  |  |  |
| Current | 1.3 |  |  | 0.9 |  |  | (0.1) |  |
| Deferred | (8.0) |  |  | (0.5) |  |  | 0.3 |  |
|  | (6.7) |  |  | 0.4 |  |  | 0.2 |  |
| Foreign: |  |  |  |  |  |
| Current | 52.1 |  |  | 55.3 |  |  | 46.8 |  |
| Deferred | (18.0) |  |  | (16.9) |  |  | (25.5) |  |
|  | 34.1 |  |  | 38.4 |  |  | 21.3 |  |
| Total income tax provision | $ | 140.8 |  |  | $ | 29.2 |  |  | $ | 36.2 |  |

[0001628280-24-038024:notes:354]
The provision for income taxes differs from the amount computed by applying the U.S. Federal statutory income tax rate to our income before provision for income taxes as follows (in millions):

[0001628280-24-038024:notes:355]
|  | Years Ended |
|  | June 29, 2024 |  | July 1, 2023 |  | July 2, 2022 |
| Income tax provision computed at federal statutory rate | $ | (85.2) |  |  | $ | (21.5) |  |  | $ | 49.4 |  |
| Foreign rate differential | 58.9 |  |  | 33.6 |  |  | (50.4) |  |
| Change in valuation allowance | 150.1 |  |  | (4.8) |  |  | 10.5 |  |
| Tax credits | (1.8) |  |  | (46.5) |  |  | (23.1) |  |
| Stock-based compensation | 17.8 |  |  | 19.1 |  |  | 9.6 |  |
| Permanent items | (3.2) |  |  | 2.9 |  |  | 0.6 |  |
| Transaction costs | 1.3 |  |  | 2.4 |  |  | — |  |
| Subpart F and GILTI | 0.2 |  |  | 44.2 |  |  | 28.2 |  |
| Unrecognized tax benefits | 11.7 |  |  | 8.6 |  |  | 4.1 |  |
| Change in Tax Rates | (9.9) |  |  | — |  |  | (1.2) |  |
| BEAT | — |  |  | (8.0) |  |  | 8.0 |  |
| Other | 0.9 |  |  | (0.8) |  |  | 0.5 |  |
| Total income tax provision | $ | 140.8 |  |  | $ | 29.2 |  |  | $ | 36.2 |  |
| Effective tax rate | (34.71) | % |  | (28.52) | % |  | 15.40 | % |

[0001628280-24-038024:notes:356]
Our provision for income taxes for fiscal 2024 differs from the 21% U.S. statutory rate primarily due to the income tax expense associated with the recognition of a valuation allowance on our U.S. federal and state deferred tax assets, earnings of our foreign subsidiaries being taxed at rates that differ from the U.S. statutory rate and non-deductible stock-based compensation. Additionally, our provision for income taxes includes changes in unrecognized tax benefits, partially offset by the income tax benefit from a change in the applicable statutory income tax rate in certain jurisdictions.

[0001628280-24-038024:notes:357]
Our provision for income taxes for fiscal 2023 differs from the 21% U.S. statutory rate primarily due to the income tax expense from foreign income inclusions in the U.S., earnings of our foreign subsidiaries being taxed at rates that differ from the U.S. statutory rate and non-deductible stock-based compensation. Additionally, our provision for income taxes includes income tax benefits from various tax credits and change in valuation allowance as it is more-likely-than-not that certain deferred tax assets will be realizable in the future. During fiscal 2023, we also effectuated certain tax planning actions which reduced the amount of BEAT for fiscal 2022.

[0001628280-24-038024:notes:358]
Our provision for income taxes for fiscal 2022 differs from the 21% U.S. statutory rate primarily due to the income tax benefit from earnings of our foreign subsidiaries being taxed at rates that differ from the U.S. statutory rate, offset by the tax expense from foreign income inclusions in U.S. Additionally, our provision for income taxes includes income tax benefits from various tax credits offset by an income tax expense from non-deductible stock-based compensation as well as change in valuation allowance as it is not more-likely-than-not that certain deferred tax assets will be realizable in the future.

[0001628280-24-038024:notes:359]
The components of our net deferred taxes consisted of the following (in millions):

[0001628280-24-038024:notes:360]
|  | Years Ended |
|  | June 29, 2024 |  | July 1, 2023 |  |  |
| Gross deferred tax assets: |  |  |  |  |  |
| Intangibles | $ | 27.0 |  |  | $ | 11.5 |  |  |  |
| Tax credit carryforwards | 109.3 |  |  | 84.3 |  |  |  |
| Net operating loss carryforwards | 226.0 |  |  | 218.6 |  |  |  |
| Inventories | 11.1 |  |  | 7.9 |  |  |  |
| Accruals and reserves | 14.1 |  |  | 11.5 |  |  |  |
| Fixed assets | 26.2 |  |  | 18.4 |  |  |  |
| Capital loss carryforwards | 11.2 |  |  | 13.9 |  |  |  |
| Capitalized and unclaimed R&D expenditure | 77.0 |  |  | 67.2 |  |  |  |
| Stock-based compensation | 5.9 |  |  | 8.3 |  |  |  |
| Lease liabilities | 13.4 |  |  | 13.8 |  |  |  |
| Other | 1.0 |  |  | 2.6 |  |  |  |
| Gross deferred tax assets | 522.2 |  |  | 458.0 |  |  |  |
| Valuation allowance | (490.4) |  |  | (303.4) |  |  |  |
| Deferred tax assets | 31.8 |  |  | 154.6 |  |  |  |
| Gross deferred tax liabilities: |  |  |  |  |  |
| Intangible amortization | (59.1) |  |  | (21.1) |  |  |  |
| Convertible notes | (0.1) |  |  | (3.4) |  |  |  |
| Right-of-use assets | (15.0) |  |  | (16.1) |  |  |  |
| Inventories | (2.2) |  |  |  |  |  |
| Other | (0.4) |  |  | (1.4) |  |  |  |
| Deferred tax liabilities | (76.8) |  |  | (42.0) |  |  |  |
| Total net deferred tax assets | $ | (45.0) |  |  | $ | 112.6 |  |  |  |

[0001628280-24-038024:notes:361]
We regularly assess our ability to realize our deferred tax assets on a quarterly basis and will establish a valuation allowance if it is more-likely-than-not that some portion of the deferred tax assets will not be realized. We weigh all available positive and negative evidence, including our earnings history and results of recent operations, reversals of deferred tax liabilities, projected future taxable income, and tax planning strategies. In fiscal 2024, after considering both positive and negative evidence, we determined that there is sufficient objectively verifiable negative evidence to conclude that it is not more-likely-than-not that our U.S. federal and states deferred tax assets are realizable in the future. As a result, we established a valuation allowance against such deferred tax assets resulting in an income tax expense of $150.1 million. We continue to maintain our valuation allowance on Canada and UK deferred tax assets, and a partial valuation allowance on our Slovenia deferred tax asset. The total valuation allowance against our deferred tax assets increased by $187.0 million in fiscal 2024. We will continue to assess the need for a valuation allowance against our remaining deferred tax assets and may increase or decrease our valuation allowance materially in the future. Based on the information currently available, we do not believe that a significant portion of our valuation allowance for the U.S., California, Canada, and UK will be released in the next 12 months. Such a release would result in the recognition of certain deferred tax assets and a decrease in the income tax expense for the period in which the release is recorded.

[0001628280-24-038024:notes:362]
As of June 29, 2024, the Company had federal and foreign net operating loss carryforwards of $336.4 million and $614.4 million, respectively. These carryforwards will begin to expire in the fiscal year ending 2025. The federal and foreign tax attributes carried forward are subject to various rules which impose limitations on the utilization. Additionally, the Company has federal, state, and foreign research and other tax credit carryforwards of $35.2 million, $84.9 million, and $36.9 million, respectively. The federal credits will begin to expire in the fiscal year ending 2025 and California credits can be carried forward indefinitely. The foreign tax credits will begin to expire in the fiscal year ending 2025. The Company’s U.S. federal and state net operating loss and credit carryforwards are subject to annual limitations due to ownership change provisions of Section 382 of the Internal Revenue Code and similar state provisions.

[0001628280-24-038024:notes:363]
We have certain tax incentives with respect to our operations in China. These tax incentives require compliance with certain conditions and expire at various dates through calendar year 2025. The impact of these tax incentives was an increase in net income of approximately $3.1 million, or $0.05 per share in fiscal 2024, $0.6 million, or $0.01 per share in fiscal 2023, and $0.3 million or $0.00 per share in fiscal year 2022. The Company has also obtained a tax holiday related to certain business activities in Thailand, but to date, has not met the requirements to obtain the benefits of the tax holiday. Accordingly, the earned income is subject to regular Thailand statutory rates.

[0001628280-24-038024:notes:364]
Current U.S. tax law generally provides greater flexibility for us to access and utilize our cash held by certain of our foreign subsidiaries and we intend to repatriate all or some of the earnings of our subsidiaries in the Cayman Islands, Japan, and Hong Kong. As to all other foreign subsidiaries, we intend to reinvest these earnings indefinitely in our foreign subsidiaries. As a result, U.S. income and foreign withholding taxes associated with the repatriation of $40.8 million of earnings from our foreign subsidiaries, other than the Cayman Islands, Japan, and Hong Kong subsidiaries, have not been provided for. We estimate that an additional $3.0 million of foreign withholding taxes would have to be provided if these earnings were repatriated back to the U.S. and such withholding taxes may be available as foreign tax credit or deduction to reduce U.S. tax liability.

[0001628280-24-038024:notes:365]
The aggregate changes in the balance of our unrecognized tax benefits between July 1, 2023 and June 29, 2024 are as follows (in millions):

[0001628280-24-038024:notes:366]
| Balance as of July 3, 2021 | $ | 62.1 |  |
| Increases based on tax positions related to prior year | 5.2 |  |
| Decreases based on tax positions related to prior year | (2.1) |  |
| Decreases related to Statute of Limitations | (9.8) |  |
| Additions based on tax positions related to current year | 6.5 |  |
| Decreases related to audit settlements | (0.2) |  |
| Balance as of July 2, 2022 | $ | 61.7 |  |
| Increases based on tax positions related to prior year | 2.8 |  |
| Decreases based on tax positions related to prior year | (5.5) |  |
| Decreases related to Statute of Limitations | (0.1) |  |
| Additions based on tax positions related to current year | 7.7 |  |
| Increases due to acquisition | 47.3 |  |
| Balance as of July 1, 2023 | $ | 113.9 |  |
| Increases based on tax positions related to prior year | 19.6 |  |
| Decreases based on tax positions related to prior year | (9.4) |  |
| Decreases related to Statute of Limitations | (24.8) |  |
| Additions based on tax positions related to current year | 7.3 |  |
| Increases due to acquisition | 9.1 |  |
| Balance as of June 29, 2024 | $ | 115.7 |  |

[0001628280-24-038024:notes:367]
As of June 29, 2024, we had $83.0 million of unrecognized tax benefits, which, if recognized, would affect the effective tax rate. We are subject to examination of income tax returns by various domestic and foreign tax authorities. The timing of resolutions and closures of tax audits is highly unpredictable. Although it is possible that certain tax audits may be concluded within the next 12 months, we cannot reasonably estimate the impact to tax expense and net income from tax exams that could be resolved or closed within next 12 months. However, we believe that we have adequately provided under GAAP for potential audit outcomes. Subject to audit timing and uncertainty, we expect the amount of unrecognized tax benefit that would become recognized due to expiration of the statute of limitations and affect the effective tax rate to be $3.7 million over the next 12 months.

[0001628280-24-038024:notes:368]
Our policy is to recognize accrued interest and penalties related to unrecognized tax benefits within the income tax provision. The amount of interest and penalties accrued as of June 29, 2024 and July 1, 2023 were $21.0 million and $15.2 million, respectively.

[0001628280-24-038024:notes:369]
The major tax jurisdictions where we file tax returns are the U.S. federal government, the state of California, Japan, the United Kingdom, Thailand, China and Canada. As of June 29, 2024, our fiscal 2012 to 2023 tax returns are open to potential

[0001628280-24-038024:notes:370]
examination in one or more jurisdictions. In addition, certain net operating loss and credit carryforwards may extend the ability of the tax authorities to examine our tax returns beyond the regular limits.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001628280-24-038024:notes:371]
Note 14. Equity

[0001628280-24-038024:notes:372]
Description of Lumentum Stock-Based Benefit Plans

[0001628280-24-038024:notes:373]
Equity Incentive Plan

[0001628280-24-038024:notes:374]
On November 17, 2023, our stockholders approved amendments to the Amended and Restated 2015 Equity Incentive Plan (the “2015 Plan”) to increase the number of shares of common stock reserved for issuance by an additional 3.0 million shares.

[0001628280-24-038024:notes:375]
As of June 29, 2024, we had 4.7 million shares subject to stock options, restricted stock units, restricted stock awards, and performance stock units issued and outstanding under the 2015 Plan. Restricted stock units, restricted stock awards, and performance stock units are performance-based, time-based or a combination of both and are expected to vest within four years. The fair value of these grants is based on the closing market price of our common stock on the date of grant. The exercise price for stock options is equal to the fair value of the underlying stock at the date of grant. We issue new shares of common stock upon exercise of stock options. Options generally have a vesting period of three years. As of June 29, 2024, 4.3 million shares of common stock under the 2015 Plan were available for grant.

[0001628280-24-038024:notes:376]
On November 28, 2023 we adopted and assumed the Cloud Light Share Option Scheme (the “Cloud Light Scheme”) in connection with the Cloud Light acquisition and we have reserved a total of 1.5 million shares of common stock for issuance thereunder, of which stock options covering 1.1 million shares were granted at the Cloud Light Closing date.

[0001628280-24-038024:notes:377]
Stock Options

[0001628280-24-038024:notes:378]
In connection with the acquisition of Cloud Light, each of Cloud Light’s outstanding options was exchanged for a combination of cash and options to acquire Lumentum common stock having equivalent value (the “replacement options”) using an exchange ratio of 0.04375 according to the terms in the Merger Agreement. At the Cloud Light Closing date, the replacement options covered 1.1 million shares with a weighted average grant date fair value of $34.63. These replacement options have a total fair value of $38.9 million as of the Closing date, of which $23.5 million attributable to pre-acquisition service was recorded as part of the purchase price consideration and the remaining $15.4 million is recorded as post-acquisition stock-based compensation expense over the vesting period of three years from the Cloud Light Closing date. Refer to “Note 4. Business Combination.”

[0001628280-24-038024:notes:379]
We estimate the fair value of the replacement options on the date of grant using the Black-Scholes option-pricing model. The assumptions used to estimate the fair value of the replacement options are as follows:

[0001628280-24-038024:notes:380]
|  | At the Acquisition Date |
| Expected terms (years) | 3.0 |
| Expected volatility | 45.0 | % |
| Risk-free interest rate | 5.0 | % |
| Dividend yield | — | % |

[0001628280-24-038024:notes:381]
Restricted Stock Units

[0001628280-24-038024:notes:382]
Restricted stock units (“RSUs”) under the 2015 Plan are grants of shares of our common stock, the vesting of which is based on the requisite service requirement. Generally, our RSUs are subject to forfeiture and are expected to vest within four years. For annual refresh grants, RSUs generally vest ratably on an annual, or combination of annual and quarterly, basis over three years.

[0001628280-24-038024:notes:383]
During fiscal 2024, our board of directors approved grants of 2.0 million shares which primarily vest over three years.

[0001628280-24-038024:notes:384]
In connection with the NeoPhotonics acquisition, we issued awards to certain NeoPhotonics employees, consisting of restricted stock units in exchange for their NeoPhotonics equity awards. The terms of these replacement awards are substantially similar to the original NeoPhotonics equity awards. The replacement awards consisted of 0.4 million restricted stock units with a grant date fair value of $93.4 per share, which represents our closing stock price on August 3, 2022, the acquisition closing date. The total fair value of these replacement awards is $40.2 million, $3.5 million of which is attributable to employee services rendered through the acquisition closing date and was recognized as a component of the purchase consideration. The remaining $36.7 million of the replacement awards is recorded as stock-based compensation over the remaining vesting period.

[0001628280-24-038024:notes:385]
Performance Stock Units

[0001628280-24-038024:notes:386]
Performance stock units (“PSUs”) under the 2015 Plan are grants of shares of our common stock that vest upon the achievement of certain performance and service conditions. We begin recognizing compensation expense when we conclude that it is probable that the performance conditions will be achieved. We reassess the probability of vesting at each reporting period and adjust our compensation cost based on this probability assessment. Our PSUs are subject to risk of forfeiture until performance and service conditions are satisfied and generally vest within three years.

[0001628280-24-038024:notes:387]
During fiscal 2024, our board of directors approved a grant of 0.3 million PSUs with an aggregate grant date fair value of $16.1 million to executive and non-executive employees as part of our revised Annual Incentive Plan. These PSUs are subject to performance targets and service conditions, with a vesting period of one year. The board of directors also approved a grant of 0.4 million PSUs with an aggregate grant date fair value of $20.8 million to certain executive officers and senior management. These PSUs will vest subject to the achievement of revenue targets and certain non-financial performance measurements, as well as service conditions, over three years.

[0001628280-24-038024:notes:388]
Employee Stock Purchase Plan

[0001628280-24-038024:notes:389]
The 2015 Purchase Plan provides eligible employees with the opportunity to acquire an ownership interest in the Company through periodic payroll deductions and provides a 15% purchase price discount as well as a 6-month look-back period. The 2015 Purchase Plan is structured as a qualified employee stock purchase plan under Section 423 of the Internal Revenue Code of 1986, as amended. The 2015 Purchase Plan will terminate upon the date on which all shares available for issuance have been sold. Of the 3.0 million shares authorized under the 2015 Purchase Plan, 0.7 million shares remained available for issuance as of June 29, 2024.

[0001628280-24-038024:notes:390]
Stock-Based Compensation

[0001628280-24-038024:notes:391]
The impact on our results of operations of recording stock-based compensation by function during the periods presented was as follows (in millions):

[0001628280-24-038024:notes:392]
|  | Years Ended |
|  | June 29, 2024 |  | July 1, 2023 |  |  |  |  | July 2, 2022 |
| Cost of sales | $ | 31.7 |  |  | $ | 30.1 |  |  |  |  |  | $ | 20.8 |  |
| Research and development | 38.1 |  |  | 41.4 |  |  |  |  |  | 22.1 |  |
| Selling, general and administrative | 59.0 |  |  | 76.9 |  |  |  |  |  | 60.2 |  |
| Total stock-based compensation | $ | 128.8 |  |  | $ | 148.4 |  |  |  |  |  | $ | 103.1 |  |

[0001628280-24-038024:notes:393]
Stock-based compensation for fiscal 2024, 2023 and 2022 includes $6.6 million, $16.0 million and $16.8 million, respectively, of expenses related to PSUs. The amount of stock-based compensation expense recognized in any one period related to PSUs can vary based on the achievement or anticipated achievement of the performance conditions. If the performance conditions are not met or not expected to be met, no compensation expense would be recognized on the underlying PSUs, and any previously recognized compensation expense related to those PSUs would be reversed.

[0001628280-24-038024:notes:394]
Total income tax benefit associated with stock-based compensation recognized in our consolidated statements of operations during the years presented was as follows (in millions):

[0001628280-24-038024:notes:395]
|  | Years Ended |
|  | June 29, 2024 |  | July 1, 2023 |  |  |  |  | July 2, 2022 |
| Income tax benefit associated with stock-based compensation | $ | 7.5 |  |  | $ | 10.4 |  |  |  |  |  | $ | 12.5 |  |

[0001628280-24-038024:notes:396]
Approximately $14.4 million and $14.2 million of stock-based compensation was capitalized to inventory as of June 29, 2024 and July 1, 2023, respectively.

[0001628280-24-038024:notes:397]
As of June 29, 2024, $118.8 million of stock-based compensation cost related to RSU awards granted to our employees remains to be amortized. This expense is expected to be recognized over an estimated amortization period of 1.8 years.

[0001628280-24-038024:notes:398]
Stock Award Activity

[0001628280-24-038024:notes:399]
The following table summarizes our awards activity in fiscal 2024, 2023 and 2022 (in millions, except per share amounts):

[0001628280-24-038024:notes:400]
|  |  |  |  |  | Stock Options |  | Restricted Stock Units |  |  |  | Performance Stock Units |
|  |  |  |  |  | Number of Shares |  | Weighted-Average Exercise Price per Share |  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |  |  |  |  |  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |
| Balance as of July 3, 2021 |  |  |  |  | — |  |  | $ | — |  |  | 1.8 |  |  | $ | 76.0 |  |  |  |  |  |  | 0.3 |  |  | $ | 75.7 |  |
| Granted |  |  |  |  | — |  |  | — |  |  | 1.5 |  |  | 87.8 |  |  |  |  |  |  | 0.2 |  |  | 85.7 |  |
| Vested/Exercised |  |  |  |  | — |  |  | — |  |  | (1.1) |  |  | 73.4 |  |  |  |  |  |  | (0.2) |  |  | 76.1 |  |
| Canceled |  |  |  |  | — |  |  | — |  |  | (0.2) |  |  | 79.9 |  |  |  |  |  |  | — |  |  | 58.7 |  |
| Balance as of July 2, 2022 |  |  |  |  | — |  |  | $ | — |  |  | 2.0 |  |  | $ | 85.9 |  |  |  |  |  |  | 0.3 |  |  | $ | 81.9 |  |
| Replacement Awards Issued |  |  |  |  | — |  |  | — |  |  | 0.4 |  |  | 93.4 |  |  |  |  |  |  | — |  |  | n/a |
| Granted |  |  |  |  | — |  |  |  |  | 1.8 |  |  | 85.1 |  |  |  |  |  |  | 0.6 |  |  | 87.9 |  |
| Vested/Exercised |  |  |  |  | — |  |  | — |  |  | (1.3) |  |  | 85.8 |  |  |  |  |  |  | (0.2) |  |  | 73.2 |  |
| Canceled |  |  |  |  | — |  |  | — |  |  | (0.3) |  |  | 87.7 |  |  |  |  |  |  | (0.1) |  |  | 89.2 |  |
| Balance as of July 1, 2023 |  |  |  |  | — |  |  | $ | — |  |  | 2.6 |  |  | $ | 85.0 |  |  |  |  |  |  | 0.6 |  |  | $ | 89.1 |  |
| Replacement options in connection with Cloud Light acquisition |  |  |  |  | 1.1 |  |  | $ | 34.6 |  |  | — |  |  | — |  |  |  |  |  |  | — |  |  | — |  |
| Granted |  |  |  |  | — |  |  | — |  |  | 2.0 |  |  | 52.2 |  |  |  |  |  |  | 0.7 |  |  | 52.8 |  |
| Vested/Exercised (1) |  |  |  |  | — |  |  | 8.2 |  |  | (1.3) |  |  | 85.7 |  |  |  |  |  |  | (0.1) |  |  | 87.7 |  |
| Canceled |  |  |  |  | — |  |  | — |  |  | (0.6) |  |  | 68.7 |  |  |  |  |  |  | (0.3) |  |  | 78.7 |  |
| Balance as of June 29, 2024 |  |  |  |  | 1.1 |  |  | $ | 34.6 |  |  | 2.7 |  |  | $ | 62.5 |  |  |  |  |  |  | 0.9 |  |  | $ | 65.5 |  |

[0001628280-24-038024:notes:401]
(1) Vested/exercised number of shares related to stock options is less than 0.1 million.

[0001628280-24-038024:notes:402]
A summary of awards available for grant for fiscal 2024, 2023 and 2022  is as follows (in millions):

[0001628280-24-038024:notes:403]
|  | Awards Available for Grant |
| Balance as of July 3, 2021 | 2.3 |  |
| Authorized | 3.0 |  |
| Granted | (1.7) |  |
| Canceled | 0.2 |  |
| Balance as of July 2, 2022 | 3.8 |  |
| Assumed in connection with NeoPhotonics acquisition | 0.4 |  |
| Replacement Awards | (0.4) |  |
| Authorized | 0.9 |  |
| Granted | (2.4) |  |
| Canceled | 0.4 |  |
| Balance as of July 1, 2023 | 2.7 |  |
| Authorized in connection with Cloud Light acquisition | 1.5 |  |
| Replacement options in connection with Cloud Light acquisition | (1.1) |  |
| Authorized | 3.0 |  |
| Granted | (2.7) |  |
| Canceled | 0.9 |  |
| Balance as of June 29, 2024 | 4.3 |  |

[0001628280-24-038024:notes:404]
Employee Stock Purchase Plan Activity

[0001628280-24-038024:notes:405]
The 2015 Purchase Plan expense for fiscal 2024, 2023 and 2022 was $4.7 million, $5.0 million, and $4.6 million, respectively. The expense related to the 2015 Purchase Plan is recorded on a straight-line basis over the relevant subscription period. There were 0.4 million, 0.3 million, and 0.2 million shares issued to employees through the 2015 Purchase Plan during fiscal 2024, 2023 and 2022, respectively.

[0001628280-24-038024:notes:406]
We estimate the fair value of the 2015 Purchase Plan shares on the date of grant using the Black-Scholes option-pricing model. The assumptions used to estimate the fair value of the 2015 Purchase Plan shares during the periods presented were as follows:

[0001628280-24-038024:notes:407]
|  | June 29, 2024 |  | July 1, 2023 |
| Expected term (years) | 0.5 |  | 0.5 |
| Expected volatility | 51.9 | % |  | 39.7 | % |
| Risk-free interest rate | 5.28 | % |  | 4.85 | % |
| Dividend yield | — | % |  | — | % |

[0001628280-24-038024:notes:408]
Repurchase and Retirement of Common Stock

[0001628280-24-038024:notes:409]
Repurchase Made in Connection with Convertible Note Offering

[0001628280-24-038024:notes:410]
In fiscal 2023, concurrent with the issuance of the 2029 Notes, we repurchased 2.3 million shares of our common stock in privately negotiated transactions at an average price of $53.49 per share for an aggregate purchase price of $125.0 million. We recorded the aggregate purchase price as a reduction of retained earnings within our consolidated balance sheet.  These shares were retired immediately.

[0001628280-24-038024:notes:411]
In fiscal 2022, concurrent with the issuance of the 2028 Notes, we repurchased 2.0 million shares of our common stock in privately negotiated transactions at an average price of $99.0 per share for an aggregate purchase price of approximately $200.0 million. We recorded the aggregate purchase price as a reduction of retained earnings within our consolidated balance sheet and retired these shares immediately.

[0001628280-24-038024:notes:412]
Share Buyback Program

[0001628280-24-038024:notes:413]
On May 7, 2021, our board of directors approved the 2021 share buyback program, which authorizes us to use up to $700.0 million to purchase our own shares of common stock.  On March 3, 2022, our board of directors approved an increase in our share buyback program, which authorizes us to use up to an aggregate amount of $1.0 billion (an increase from $700.0 million) to purchase our own shares of common stock through May 2024. On April 5, 2023, our board of directors approved a further increase in our share buyback program to authorize us to use up to an aggregate amount of $1.2 billion (an increase from $1.0 billion) to purchase our own shares of common stock through May 2025.

[0001628280-24-038024:notes:414]
During fiscal 2024, we did not repurchase any shares of our common stock as part of the share buyback program. During fiscal 2023, we repurchased 0.7 million shares of our common stock as part of the share buyback program at an average price of $65.03 per share for an aggregate purchase price of $40.5 million. Since the approval of the share buyback program by the board of directors, we have repurchased 7.7 million shares in aggregate at an average price of $81.66 per share for a total purchase price of $630.4 million. We recorded the $630.4 million of aggregate purchase price as a reduction of retained earnings within our consolidated balance sheets and immediately retired all repurchased shares. As of June 29, 2024, we have $569.6 million remaining under the share buyback program.

[0001628280-24-038024:notes:415]
The price, timing, amount, and method of future repurchases will be determined based on the evaluation of market conditions and other factors, at prices determined to be in the best interests of the Company and our stockholders. The stock buyback program may be suspended or terminated at any time.


## us-gaap:ScheduleOfShareBasedPaymentAwardEmployeeStockPurchasePlanValuationAssumptionsTableTextBlock

[0001628280-24-038024:notes:416]
The assumptions used to estimate the fair value of the replacement options are as follows:

[0001628280-24-038024:notes:417]
The assumptions used to estimate the fair value of the 2015 Purchase Plan shares during the periods presented were as follows:


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001628280-24-038024:notes:418]
Note 15. Employee Retirement Plans

[0001628280-24-038024:notes:419]
Defined Contribution Plans

[0001628280-24-038024:notes:420]
In the United States, the Company sponsors the Lumentum 401(k) Retirement Plan (the “401(k) Plan”), a defined contribution plan under the Employee Retirement Income Security Act of 1974 (“ERISA”), which provides retirement benefits for its eligible employees through tax deferred salary deductions. The 401(k) Plan allows employees to contribute up to 50% of their annual compensation, with contributions limited to $23,000 (or $30,500 for employees over 50 years of age) in calendar year 2024 as set by the Internal Revenue Service. Employees are eligible for matching contributions after completing 180 days of service. The Company’s match is contributed on a per-pay-period basis and is based on employees’ before-tax contributions and compensation each pay period. All matching contributions are made in cash and vest immediately under the 401(k) Plan. In fiscal 2024, 2023 and 2022, our contribution expense to the 401(k) Plan was $3.8 million, $3.8 million, and $3.7 million, respectively.

[0001628280-24-038024:notes:421]
We also have defined contribution plans in most of the other countries in which we operate, either as required by statutory law or as provided by the Company’s supplemental offering. Our contribution expense to all defined contribution plans outside the United States were $7.4 million, $8.1 million, and $7.7 million for fiscal 2024, 2023 and 2022, respectively.

[0001628280-24-038024:notes:422]
Defined Benefit Plans

[0001628280-24-038024:notes:423]
The Company sponsors defined benefit pension plans covering employees in Japan, Switzerland and Thailand. Pension plan benefits are based primarily on participants’ compensation and years of service credited as specified under the terms of each country’s plan. Employees are entitled to a lump sum benefit upon retirement or upon certain instances of termination.  The funding policy is consistent with the local requirements of each country.

[0001628280-24-038024:notes:424]
We account for our defined benefit obligations in accordance with the authoritative guidance which requires us to record our obligation to the participants, as well as the corresponding net periodic cost. We determine our obligation to the participants and our net periodic cost using actuarial valuations provided by third-party actuaries. As of June 29, 2024, our projected benefit obligations, net, in Japan, Switzerland and Thailand were $3.6 million, $2.4 million and $3.6 million, respectively. They were recorded in our consolidated balance sheets as accrued payroll and related expenses for the short-term portion while other non-current liabilities for the long-term portion, and represent the total projected benefit obligation (“PBO”) less the fair value of plan assets.

[0001628280-24-038024:notes:425]
As of June 29, 2024, the defined benefit plans in Switzerland were partially funded, while the defined benefit plans in Japan and Thailand were unfunded.

[0001628280-24-038024:notes:426]
The change in the benefit obligations of pension plans in Japan, Switzerland, and Thailand, and the change in plan assets in Switzerland were as follows (in millions):

[0001628280-24-038024:notes:427]
|  | June 29, 2024 |  | July 1, 2023 |
| Change in projected benefit obligation: |  |  |  |
| Benefit obligation at beginning of year | $ | 24.8 |  |  | $ | 17.5 |  |
| Assumed pension liability in Japan in connection with NeoPhotonics acquisition | — |  |  | 2.2 |  |
| Service cost | 1.9 |  |  | 1.7 |  |
| Interest cost | 0.4 |  |  | 0.3 |  |
| Plan participants’ contributions | 1.1 |  |  | 0.8 |  |
| Actuarial losses (1) | 0.4 |  |  | 0.6 |  |
| Net benefits payment | (3.3) |  |  | 1.0 |  |
| Plan amendments | (0.1) |  |  | (0.1) |  |
| Foreign exchange impact | (0.7) |  |  | 0.8 |  |
| Benefit obligation at end of year | $ | 24.5 |  |  | $ | 24.8 |  |
| Change in plan assets: |  |  |  |
| Fair value of plan assets at beginning of year | $ | 13.4 |  |  | $ | 9.8 |  |
| Actual return on plan assets | 0.8 |  |  | (0.5) |  |
| Employer contribution | 3.1 |  |  | 1.5 |  |
| Plan participants’ contribution | 1.1 |  |  | 0.8 |  |
| Net benefits payment | (3.3) |  |  | 1.0 |  |
| Foreign exchange impact | (0.2) |  |  | 0.8 |  |
| Fair value of plan assets at end of year | $ | 14.9 |  |  | $ | 13.4 |  |
| Funded status (2) | $ | (9.6) |  |  | $ | (11.4) |  |
| Changes in benefit obligations and plan assets recognized in other comprehensive income: |  |  |  |
| Prior service cost | $ | — |  |  | $ | — |  |
| Amortization of accumulated net actuarial loss | — |  |  | — |  |
| Settlement loss | (0.1) |  |  | — |  |
| Net actuarial loss (gain) | (0.1) |  |  | 1.4 |  |
|  | $ | (0.2) |  |  | $ | 1.4 |  |
| Accumulated benefit obligation | $ | 19.6 |  |  | $ | 20.0 |  |

[0001628280-24-038024:notes:428]
(1) Actuarial losses  are primarily driven by changes in discount rates.

[0001628280-24-038024:notes:429]
(2) The current portion of the projected benefit obligation is $1.0 million and $1.2 million, respectively, as of  June 29, 2024 and July 1, 2023, which was recorded under accrued payroll and related expenses in the consolidated balance sheets. The non-current portion of the projected benefit obligation is $8.6 million and $10.2 million, respectively, as of June 29, 2024 and July 1, 2023, which was recorded under other non-current liabilities in the consolidated balance sheets. Refer to “Note 7. Balance Sheet Details.”

[0001628280-24-038024:notes:430]
Net periodic pension costs in Japan, Switzerland and Thailand include the following components for the periods presented (in millions):

[0001628280-24-038024:notes:431]
|  | Years Ended |  |  |  |
|  | June 29, 2024 |  | July 1, 2023 |  | July 2, 2022 |  |  |  |
| Service cost | $ | 1.9 |  |  | $ | 1.7 |  |  | $ | 1.8 |  |  |  |  |
| Interest cost | 0.4 |  |  | 0.3 |  |  | 0.1 |  |  |  |  |
| Amortization of prior service cost | (0.1) |  |  | (0.1) |  |  | (0.1) |  |  |  |  |
| Expected return on plan assets | (0.4) |  |  | (0.3) |  |  | (0.2) |  |  |  |  |
| Amortization of net loss | — |  |  | — |  |  | 0.2 |  |  |  |  |
| Settlement losses | 0.1 |  |  | — |  |  | — |  |  |  |  |
| Net periodic pension cost | $ | 1.9 |  |  | $ | 1.6 |  |  | $ | 1.8 |  |  |  |  |

[0001628280-24-038024:notes:432]
Assumptions

[0001628280-24-038024:notes:433]
Underlying both the calculation of the projected benefit obligation and net periodic cost are actuarial valuations. These valuations use participant-specific information such as salary, age and assumptions about interest rates, compensation increases and other factors. At a minimum, we evaluate these assumptions annually and make changes as necessary.

[0001628280-24-038024:notes:434]
The discount rate reflects the estimated rate at which the pension benefits could be effectively settled. In developing the discount rate, we consider the yield available on an appropriate AA or AAA corporate bond index, adjusted to reflect the term of the plan’s liabilities.

[0001628280-24-038024:notes:435]
The expected return on assets was estimated by using the weighted average of the real expected long-term return (net of inflation) on the relevant classes of assets based on the target asset mix and adding the chosen inflation assumption.

[0001628280-24-038024:notes:436]
The following table summarizes the weighted-average assumptions used to determine net periodic cost and benefit obligation for our defined benefit plans in Japan, Switzerland and Thailand:

[0001628280-24-038024:notes:437]
|  | Years Ended |
|  | June 29, 2024 |  | July 1, 2023 |
| Assumptions used to determine net periodic cost: |  |  |  |
| Discount rate | 2.0 | % |  | 2.3 | % |
| Expected long-term return on plan assets | 3.0 | % |  | 2.5 | % |
| Salary increase rate | 3.8 | % |  | 4.1 | % |
| Assumptions used to determine benefit obligation at end of year: |  |  |  |
| Discount rate | 1.8 | % |  | 1.8 | % |
| Salary increase rate | 2.9 | % |  | 3.0 | % |

[0001628280-24-038024:notes:438]
Fair Value Measurement of Plan Assets

[0001628280-24-038024:notes:439]
The following table sets forth the plan assets of our defined benefit plan in Switzerland at fair value and the percentage of assets allocations as of June 29, 2024 and July 1, 2023 (in millions, except percentage data):

[0001628280-24-038024:notes:440]
|  |  |  |  |  |  | Fair value measurement as of June 29, 2024 |
|  | Target allocation | Total |  | Percentage of plan asset |  | Quoted prices in active markets for identical assets(Level 1) |  | Significant other observable inputs (Level 2) |
| Assets: |  |  |  |  |  |  |  |  |  |
| Global equity | 33 | % |  | $ | 5.1 |  |  | 32 | % |  | $ | — |  |  | $ | 5.1 |  |
| Fixed income | 30 | % |  | 4.2 |  |  | 30 | % |  | — |  |  | 4.2 |  |
| Alternative investment | 13 | % |  | 1.9 |  |  | 13 | % |  | — |  |  | 1.9 |  |
| Cash | 1 | % |  | 0.1 |  |  | 1 | % |  | 0.1 |  |  | — |  |
| Other assets | 23 | % |  | 3.6 |  |  | 24 | % |  | — |  |  | 3.6 |  |
| Total Assets | 100 | % |  | $ | 14.9 |  |  | 100 | % |  | $ | 0.1 |  |  | $ | 14.8 |  |

[0001628280-24-038024:notes:441]
|  |  |  |  |  |  | Fair value measurement as of July 1, 2023 |
|  | Target allocation |  | Total |  | Percentage of plan asset |  | Quoted prices in active markets for identical assets(Level 1) |  | Significant other observable inputs (Level 2) |
| Assets: |  |  |  |  |  |  |  |  |  |
| Global equity | 33 | % |  | $ | 4.4 |  |  | 32 | % |  | $ | — |  |  | $ | 4.4 |  |
| Fixed income | 32 | % |  | 4.0 |  |  | 30 | % |  | — |  |  | 4.0 |  |
| Alternative investment | 12 | % |  | 1.7 |  |  | 13 | % |  | — |  |  | 1.7 |  |
| Cash | 1 | % |  | 0.1 |  |  | 1 | % |  | 0.1 |  |  | — |  |
| Other assets | 22 | % |  | 3.2 |  |  | 24 | % |  | — |  |  | 3.2 |  |
| Total Assets | 100 | % |  | $ | 13.4 |  |  | 100 | % |  | $ | 0.1 |  |  | $ | 13.3 |  |

[0001628280-24-038024:notes:442]
Our pension assets consist of multiple institutional funds (“pension funds”) of which the fair values are based on the quoted prices of the underlying funds. Pension funds are classified as Level 2 assets since such funds are not directly traded in active markets. Global equity consists of several funds that invest primarily in Swiss and foreign equities; fixed income consists of several funds that invest primarily in investment grade domestic and overseas bonds; alternative investment consists of several funds that invest primarily in hedge funds, infrastructure funds and private equity and debt; and other assets consist of several funds that invest primarily in real estate funds.

[0001628280-24-038024:notes:443]
Future Benefit Payments

[0001628280-24-038024:notes:444]
We estimate our expected benefit payments to participants in the defined benefit pension plans based on the same assumptions used to measure our PBO at year-end which includes benefits attributable to estimated future compensation increases.

[0001628280-24-038024:notes:445]
The following benefit payments are estimated to be paid from our defined benefit pension plans (in millions):

[0001628280-24-038024:notes:446]
| Fiscal Years |  | Total |
| 2025 |  | $ | 1.8 |  |
| 2026 |  | 1.3 |  |
| 2027 |  | 1.3 |  |
| 2028 |  | 1.7 |  |
| 2029 |  | 1.4 |  |
| Next five years |  | 11.4 |  |
| Total expected benefit payments |  | $ | 18.9 |  |

[0001628280-24-038024:notes:447]
We expect to contribute $1.6 million to our defined benefit pension plans in fiscal 2025.


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0001628280-24-038024:notes:448]
Note 16. Commitments and Contingencies

[0001628280-24-038024:notes:449]
Purchase Obligations

[0001628280-24-038024:notes:450]
Purchase obligations of $475.1 million as of June 29, 2024 represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule and adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

[0001628280-24-038024:notes:451]
We depend on a limited number of contract manufacturers, subcontractors and suppliers for raw materials, packages and standard components. We generally purchase these single or limited source products through standard purchase orders or one-year supply agreements and have no significant long-term guaranteed supply agreements with these vendors. While we seek to maintain a sufficient safety stock of such products and maintain on-going communications with our suppliers to guard against interruptions or cessation of supply, our business and results of operations could be adversely affected by a stoppage or delay of supply, substitution of more expensive or less reliable products, receipt of defective parts or contaminated materials, increases in the price of such supplies, or our inability to obtain reduced pricing from our suppliers in response to competitive pressures.

[0001628280-24-038024:notes:452]
Product Warranties

[0001628280-24-038024:notes:453]
We provide reserves for the estimated costs of product warranties at the time revenue is recognized. We typically offer a twelve-month warranty for most of our products. However, in some instances depending upon the product, product components or application of our products by the end customer, our warranties can vary and generally range from six months to five years. We estimate the costs of our warranty obligations on an annualized basis based on our historical experience of known product failure rates, use of materials to repair or replace defective products, and service delivery costs incurred in correcting product failures. In addition, from time-to-time, specific warranty accruals may be made if unforeseen technical problems arise with specific products. We assess the adequacy of our recorded warranty liabilities and adjust the amounts as necessary.

[0001628280-24-038024:notes:454]
The following table presents the changes in our warranty reserve during the periods presented (in millions):

[0001628280-24-038024:notes:455]
|  | Years Ended |
|  | June 29, 2024 |  | July 1, 2023 |  |  |  |  |
| Balance as of beginning of period | $ | 6.8 |  |  | $ | 10.0 |  |  |  |  |  |
| Warranties assumed in NeoPhotonics acquisition | — |  |  | 0.7 |  |  |  |  |  |
| Warranties assumed in Cloud Light acquisition | 8.2 |  |  | — |  |  |  |  |  |
| Provision for warranty | 6.0 |  |  | 7.1 |  |  |  |  |  |
| Utilization of reserve | (7.8) |  |  | (11.0) |  |  |  |  |  |
| Balance as of end of period | $ | 13.2 |  |  | $ | 6.8 |  |  |  |  |  |

[0001628280-24-038024:notes:456]
Environmental Liabilities

[0001628280-24-038024:notes:457]
Our research and development, manufacturing and distribution operations involve the use of hazardous substances and are regulated under international, federal, state and local laws governing health and safety and the environment. We apply strict standards for protection of the environment and occupational health and safety to sites inside and outside the United States, even if not subject to regulations imposed by foreign governments. We believe that our properties and operations at our facilities comply in all material respects with applicable environmental laws and occupational health and safety laws. However, the risk of environmental liabilities cannot be completely eliminated and there can be no assurance that the application of environmental and health and safety laws will not require us to incur significant expenditures. We are also regulated under a number of international, federal, state and local laws regarding recycling, product packaging and product content requirements. The environmental and product content/disposal and recycling laws are gradually becoming more stringent and may cause us to incur significant expenditures in the future.

[0001628280-24-038024:notes:458]
Legal Proceedings

[0001628280-24-038024:notes:459]
We are subject to a variety of claims and suits that arise from time-to-time in the ordinary course of our business. In addition, we are subject to various legal matters, investigations, subpoenas, inquiries, audits, claims, and disputes, including with regulatory bodies and governmental agencies. While management currently believes that resolving claims against us, individually or in the aggregate, will not have a material adverse impact on our financial position, results of operations or

[0001628280-24-038024:notes:460]
statements of cash flows, these matters are subject to inherent uncertainties and management’s view of these matters may change in the future. We accrue for loss contingencies when it is both probable that we will incur the loss and when we can reasonably estimate the amount of the loss or range of loss.  During the year ended July 1, 2023, we recorded $7.8 million with respect to the pending settlement of certain non-ordinary course litigation matters under accrued expenses in our consolidated balance sheet, which has not been settled as of June 29, 2024.

[0001628280-24-038024:notes:461]
Oclaro Merger Litigation

[0001628280-24-038024:notes:462]
In connection with our acquisition of Oclaro in 2018, seven lawsuits were filed by purported stockholders of Oclaro challenging the proposed merger (the “Merger”). All but one was voluntarily dismissed after the Oclaro Merger closed. The remaining lawsuit, SaiSravan B. Karri v. Oclaro, Inc., et al., No. 3:18-cv-03435-JD (the “Karri Lawsuit”), was filed in the United States District Court for the Northern District of California and is styled as a class action.

[0001628280-24-038024:notes:463]
The Karri Lawsuit alleges, among other things, that Oclaro and its directors violated Section 14(a) of the Securities Exchange Act of 1934, as amended (the “Exchange Act”), and Rule 14a-9 promulgated thereunder by disseminating an incomplete and misleading Form S-4, including proxy statement/prospectus. The Karri Lawsuit further alleged that Oclaro’s directors violated Section 20(a) of the Exchange Act by failing to exercise proper control over the person(s) who violated Section 14(a) of the Exchange Act. The plaintiff in the Karri Lawsuit seeks, among other things, damages to be awarded to the plaintiff and any class, if a class is certified, and litigation costs, including attorneys’ fees.

[0001628280-24-038024:notes:464]
After the plaintiff in the Karri Lawsuit was appointed as lead plaintiff and his counsel as lead counsel, the plaintiff filed a first amended complaint on April 15, 2019. The first amended complaint, also named Lumentum as a defendant but Lumentum has since been dismissed from the action. On October 8, 2020, the court granted in part and denied in part the defendant’s motion to dismiss the first amended complaint. On December 1, 2020, defendants answered the first amended complaint. On September 17, 2021, lead plaintiff filed a second amended complaint. Defendants moved to stay discovery in light of the second amended complaint. On January 11, 2022, the Court struck the second amended complaint as untimely, terminated defendants’ motions to dismiss as moot, and lifted the stay. The case proceeded through fact and expert discovery.

[0001628280-24-038024:notes:465]
On August 16, 2022, the lead plaintiff moved for class certification and to be appointed class representative. Defendants opposed the motion. The action subsequently was stayed while the parties participated in a mediation. On January 18, 2023, the lead plaintiff filed a Notice of Settlement informing the court of an agreement in principle between the parties for a class-wide settlement of the Karri Lawsuit. On January 24, 2023, in light of the potential settlement, the court vacated all pretrial and trial dates and ordered the lead plaintiff to file a motion for preliminary approval of the settlement by March 17, 2023. The lead plaintiff filed his motion for preliminary approval of the settlement on March 16, 2023, and defendants filed a statement of non-opposition on March 30, 2023. On April 20, 2023, the court held a hearing on lead plaintiff’s motion for preliminary approval of the settlement. The court declined to grant lead plaintiff’s motion for preliminary approval and ordered lead plaintiff to file a revised motion by May 22, 2023. Lead plaintiff filed his Revised Motion for Preliminary Approval of Settlement (the “Amended Motion”) on May 22, 2023, defendants filed a response in support of the Amended Motion on June 5, 2023, and the lead plaintiff submitted his reply in further support of the Amended Motion on June 12, 2023. The hearing on the Amended Motion took place on August 17, 2023 and the court preliminarily approved the settlement and scheduled the fairness hearing for February 22, 2023. On November 2, 2023, lead plaintiff filed a Motion for an Award of Attorneys’ Fees and Expenses and Award to Class Representative Pursuant to 15 U.S.C. §78u-4(a)(4) (the “Fee Motion”) and on November 16, 2023, Defendants filed a response to the Fee Motion. On January 11, 2024, lead plaintiff filed a Motion for Final Approval of Class Action Settlement, for Certification of the Settlement Class and for Approval of the Plan of Allocation, and supporting papers.  On January 25, 2024, lead plaintiff filed a Reply in Support of Motions for Final Approval of Class Action Settlement and an Award of Attorneys’ Fees and Expenses. On July 12, 2024, the court entered an order approving the settlement in all respects and dismissing the action with prejudice. On July 26, 2024, the court entered an order awarding attorneys’ fees and expenses and service award to Karri as class representative. Pursuant to the order, the court awarded Karri attorneys’ fees in the amount of $5.1 million and expenses in the amount of $0.4 million, all to be paid from the settlement fund, subject to certain conditions.

[0001628280-24-038024:notes:466]
We recorded the court approved settlement amount of $15.3 million as accrued expenses in our condensed consolidated balance sheet as of June 29, 2024, of which $7.5 million represents the amount to be reimbursed by insurance and was recorded as prepayments and other current assets.

[0001628280-24-038024:notes:467]
NeoPhotonics Acquisition Litigation

[0001628280-24-038024:notes:468]
In connection with our acquisition of NeoPhotonics Corporation (“NeoPhotonics”) announced in November 2021, ten lawsuits (the “NeoPhotonics Lawsuits”) were filed by purported stockholders of NeoPhotonics challenging the acquisition. All of the NeoPhotonics Lawsuits have been dismissed.

[0001628280-24-038024:notes:469]
Indemnifications

[0001628280-24-038024:notes:470]
In the normal course of business, we enter into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown, because claims may be made against us in the future and we may record charges in the future as a result of these indemnification obligations. As of June 29, 2024, we did not have any material indemnification claims that were probable or reasonably possible.

[0001628280-24-038024:notes:471]
Audit Proceedings

[0001628280-24-038024:notes:472]
We are under audit by various domestic and foreign tax authorities with regards to income tax and indirect tax matters. In some, although not all cases, we have reserved for potential adjustments to our provision for income taxes and accrual of indirect taxes that may result from examinations by these tax authorities or final outcomes in judicial proceedings, and we believe that the final outcome of these examinations, agreements or judicial proceedings will not have a material effect on our results of operations. If events occur which indicate payment of these amounts is unnecessary, the reversal of the liabilities would result in the recognition of benefits in the period when we determine the liabilities are no longer necessary. If our estimates of the federal, state, and foreign income tax liabilities and indirect tax liabilities are less than the ultimate assessment, it could result in a further charge to expense.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001628280-24-038024:notes:473]
Note 17. Operating Segments and Geographic Information

[0001628280-24-038024:notes:474]
Prior to fiscal year 2024, we operated in two reportable segments consisting of Optical Communications (“OpComms”) and Commercial Lasers (“Lasers”). During the fiscal first quarter of 2024, our chief operating decision maker (“CODM”) implemented changes in how he organizes the business, allocates resources, and assesses performance. We changed our organizational structure to better align with trends in our markets and our customer and product mix. Our new operating segments are Cloud & Networking and Industrial Tech. The Cloud & Networking segment includes the Telecom & Datacom product lines that were previously part of the OpComms segment. The Industrial Tech segment includes previous Lasers segment and the Industrial & Consumer product lines that were previously part of the OpComms segment. The two operating segments were primarily determined based on how the CODM views and evaluates our operations. The CODM regularly reviews operating results to make decisions about resources to be allocated to the segments and to assess their performance.

[0001628280-24-038024:notes:475]
In conjunction with this change, our CODM now evaluates each segment’s performance and allocates resources based on segment revenue and segment profit, instead of gross profit, as our CODM believes segment profit is a more comprehensive profitability measure for each operating segment. Segment profit includes operating expenses directly managed by operating segments, including research and development, and direct sales and marketing expenses. Segment profit does not include stock-based compensation, acquisition or integration related costs, amortization and impairment of acquisition-related intangible assets, restructuring and related charges, and certain other charges. Additionally, we do not allocate corporate marketing and strategic marketing expenses and general and administrative expenses, as these expenses are not directly attributable to our operating segments.

[0001628280-24-038024:notes:476]
Comparative prior period segment information has been recast to conform to the new segment structure and segment profitability measure. The change in our operating segments had no impact on our previously reported consolidated results of operations, financial condition, or cash flows.

[0001628280-24-038024:notes:477]
We do not track all of our property, plant and equipment by operating segments. The geographic identification of these assets is set forth below.

[0001628280-24-038024:notes:478]
Cloud & Networking

[0001628280-24-038024:notes:479]
Our Cloud & Networking products include comprehensive portfolio of optical and photonic components, modules, and subsystems supplied to network operator and network equipment manufacturer customers building cloud data center infrastructure, including products for AI/ML and DCI applications, and communications service provider networks, including products for access (local), metro (intracity), long-haul (city-to-city and worldwide) and submarine (undersea) network infrastructure. Our Cloud & Networking products also support network equipment manufacturers building enterprise network infrastructure, including SANs, LANs, and WANs. These products enable the transmission and transport of data, video, and audio over high-capacity fiber-optic cables. We maintain leading positions in these fast-growing cloud & networking markets through our extensive product portfolio, including high-speed transceivers, reconfigurable optical add/drop multiplexers (“ROADMs”), coherent dense wavelength division multiplexing (“DWDM”) pluggable transceivers, and tunable small form-factor pluggable transceivers. We also sell laser chips for use in manufacturing of high-speed optical transceivers for use primarily inside data centers. Demand for our Cloud & Networking products is driven by the continual growth in network capacity required for cloud computing and services, including for AI/ML, streaming video and video conferencing, wireless and mobile services, and IoT.

[0001628280-24-038024:notes:480]
Industrial Tech

[0001628280-24-038024:notes:481]
Our Industrial Tech products include solid-state lasers, kilowatt-class fiber lasers, ultrafast lasers, diode lasers, and gas lasers,  which address applications  in numerous end-markets. In the consumer end-market, our laser light sources are integrated into our customers’ 3D sensing cameras, which are used in mobile devices, payment kiosks, and other consumer electronics devices to enable applications including biometric identification, computational photography and virtual and augmented reality. In the automotive end-market, our lasers are used in our customers’ LiDAR and other optical sensor devices, which are increasingly being used in advanced driver assistance systems (“ADAS”) and in-cabin driver and occupant monitoring systems. In the industrial manufacturing end-market, our lasers are incorporated into our customers’ manufacturing machine tools used for the precision processing of materials in a range of industries including semiconductor device and microelectronics fabrication, electric vehicle and battery production, metal cutting and welding, and advanced manufacturing. Our products can also be used in the industrial end-market in imaging and sensing systems for process feedback and control, quality assurance, and waste reduction. Adoption of our products in the industrial end-market is driven by the needs of customers to advance semiconductor and microelectronics industry roadmaps, and by Industry 4.0/5.0 trends, including increasing manufacturing precision and flexibility and reducing waste and environmental impact. Demand for our products in the industrial end-market is

[0001628280-24-038024:notes:482]
driven by end-customer investments in manufacturing capacity. Our lasers also address certain semiconductor inspection and life-science applications.

[0001628280-24-038024:notes:483]
Reportable Segments

[0001628280-24-038024:notes:484]
The two operating segments, Cloud & Networking and Industrial Tech, also represent our two reportable segments. Our CODM allocates resources and evaluates segment performance based on segment revenue and segment profit. The following table summarizes segment profit and a reconciliation to the consolidated income (loss) before income taxes for the periods presented (in millions). Comparative prior period segment information has been recast to conform to the new segment structure.

[0001628280-24-038024:notes:485]
Information on reportable segments utilized by our CODM is as follows (in millions):

[0001628280-24-038024:notes:486]
|  |  |  | Years Ended |
|  |  |  |  |  | June 29, 2024 |  | July 1, 2023 |  | July 2, 2022 |
| Net revenue: |  |  |  |  |  |  |  |  |  |
| Cloud & Networking |  |  |  |  | $ | 1,084.9 |  |  | $ | 1,322.5 |  |  | $ | 1,008.7 |  |
| Industrial Tech |  |  |  |  | 274.3 |  |  | 444.5 |  |  | 703.9 |  |
| Net revenue |  |  |  |  | $ | 1,359.2 |  |  | $ | 1,767.0 |  |  | $ | 1,712.6 |  |
| Segment profit: |  |  |  |  |  |  |  |  |  |
| Cloud & Networking |  |  |  |  | $ | 124.5 |  |  | $ | 313.2 |  |  | $ | 266.9 |  |
| Industrial Tech |  |  |  |  | 25.1 |  |  | 152.7 |  |  | 373.5 |  |
| Total segment profit |  |  |  |  | 149.6 |  |  | 465.9 |  |  | 640.4 |  |
| Unallocated corporate items: |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative (1) |  |  |  |  | (111.8) |  |  | (126.7) |  |  | (113.4) |  |
| Stock-based compensation |  |  |  |  | (128.8) |  |  | (136.5) |  |  | (103.1) |  |
| Stock-based compensation - acquisition related |  |  |  |  | — |  |  | (11.9) |  |  | — |  |
| Amortization of acquired intangibles |  |  |  |  | (150.6) |  |  | (127.7) |  |  | (85.5) |  |
| Amortization of acquired inventory fair value adjustments |  |  |  |  | (8.3) |  |  | (17.8) |  |  | — |  |
| Acquisition related costs |  |  |  |  | (13.3) |  |  | (11.5) |  |  | — |  |
| Integration related costs |  |  |  |  | (37.1) |  |  | (28.6) |  |  | — |  |
| Restructuring and related charges |  |  |  |  | (72.6) |  |  | (28.1) |  |  | 1.1 |  |
| Abnormal excess capacity (2) |  |  |  |  | (20.7) |  |  | — |  |  | — |  |
| Litigation matters |  |  |  |  | — |  |  | (7.8) |  |  | — |  |
| Intangible asset write-off |  |  |  |  | — |  |  | (21.3) |  |  | — |  |
| Other charges, net (3) |  |  |  |  | (40.4) |  |  | (63.7) |  |  | (36.2) |  |
| Interest expense |  |  |  |  | (33.8) |  |  | (35.5) |  |  | (80.2) |  |
| Other income, net (4) |  |  |  |  | 62.1 |  |  | 48.8 |  |  | 12.0 |  |
| Consolidated Income (loss) before income taxes |  |  |  |  | $ | (405.7) |  |  | $ | (102.4) |  |  | $ | 235.1 |  |

[0001628280-24-038024:notes:487]
(1) We do not allocate selling, general and administrative expenses that are not directly attributable to our operating segments.

[0001628280-24-038024:notes:488]
(2) Abnormal excess capacity for the twelve months ended June 29, 2024 represents excess capacity attributable to a near-term reduction in our manufacturing production, primarily driven by our non-recurring inventory reduction effort following the disruptions in the supply chain due to the COVID-19 pandemic and factory consolidation efforts.

[0001628280-24-038024:notes:489]
(3) Other charges, net for the year ended June 29, 2024 primarily relate to $11.2 million of net excess and obsolete inventory, $12.4 million of non-recurring legal and tax related fees, $4.9 million of incremental costs of sales related to components previously acquired from various brokers to satisfy customer demand and $3.4 million of one-time charge as a result of contract termination with one of our vendors due to a change in our manufacturing strategy, offset by various miscellaneous gains. The excess and obsolete inventory charges relate to charges that are not attributable to our operating segments due to their unusual nature, primarily those charges driven by U.S. trade restrictions whereby we are no longer able to sell certain products to one of our customers.

[0001628280-24-038024:notes:490]
Other charges, net for the year ended July 1, 2023 primarily relate to $32.5 million of incremental costs of sales related to components previously acquired from various brokers to satisfy customer demand, $12.5 million of non-recurring legal and professional fees, $5.4 million of excess and obsolete inventory charges primarily driven by synergies as a result of the NeoPhotonics integration and $2.7 million of excess and obsolete inventory charges driven by U.S. trade restrictions and the related decline in demand from Huawei.

[0001628280-24-038024:notes:491]
Other charges, net for the year ended July 2, 2022 primarily relate to $14.0 million of incremental costs of sales related to components previously acquired from various brokers to satisfy customer demand, $8.4 million of transaction costs related to the acquisition of NeoPhotonics and $9.4 million of professional service fees related to optimizing our international legal structure, offset by a $5.9 million gain from selling equipment that was no longer needed after we transferred certain product lines to new production facilities in fiscal 2021.

[0001628280-24-038024:notes:492]
(4) Other income, net for the year ended June 29, 2024 includes interest and investment income of $61.3 million, and foreign exchange gains, net of $0.8 million.

[0001628280-24-038024:notes:493]
Other income, net for the year ended July 1, 2023 includes interest and investment income of $40.8 million, foreign exchange gains, net of $7.0 million and other income, net of $1.0 million.

[0001628280-24-038024:notes:494]
Other income, net for the year ended July 2, 2022 includes interest and investment income of $6.1 million, foreign exchange gains, net of $6.1 million, offset by other expense, net of $0.2 million.

[0001628280-24-038024:notes:495]
Concentrations

[0001628280-24-038024:notes:496]
We operate in three geographic regions: Americas, Asia-Pacific, and EMEA (Europe, Middle East, and Africa). Net revenue is assigned to the geographic region and country where our product is initially shipped to. For example, certain customers may request shipment of our product to a contract manufacturer in one country, which may differ from the location of their end customers. The following table presents net revenue by the three geographic regions we operate in and net revenue from countries that represented 10% or more of our total net revenue (in millions, except percentage data):

[0001628280-24-038024:notes:497]
|  |  |  | Years Ended |  |
|  |  |  |  |  | June 29, 2024 |  | July 1, 2023 |  | July 2, 2022 |  |
|  |  |  |  |  |  |  |  |  | Amount |  | % to Total |  | Amount |  | % to Total |  | Amount |  | % to Total |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  |  |  |  |  |  |  |  | $ | 356.1 |  |  | 26.2 | % |  | $ | 241.3 |  |  | 13.7 | % |  | $ | 173.9 |  |  | 10.2 | % |  |
| Mexico |  |  |  |  |  |  |  |  | 91.7 |  |  | 6.7 |  |  | 180.0 |  |  | 10.2 |  |  | 160.9 |  |  | 9.4 |  |  |
| Other Americas |  |  |  |  |  |  |  |  | 3.4 |  |  | 0.3 |  |  | 9.3 |  |  | 0.5 |  |  | 12.1 |  |  | 0.7 |  |  |
| Total Americas |  |  |  |  |  |  |  |  | $ | 451.2 |  |  | 33.2 | % |  | $ | 430.6 |  |  | 24.4 | % |  | $ | 346.9 |  |  | 20.3 | % |  |
| Asia-Pacific: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Thailand |  |  |  |  |  |  |  |  | $ | 183.8 |  |  | 13.5 | % |  | $ | 269.0 |  |  | 15.2 | % |  | $ | 102.3 |  |  | 5.9 | % |  |
| Hong Kong |  |  |  |  |  |  |  |  | 261.9 |  |  | 19.3 |  |  | 246.7 |  |  | 14.0 |  |  | 458.2 |  |  | 26.7 |  |  |
| South Korea |  |  |  |  |  |  |  |  | 75.2 |  |  | 5.5 |  |  | 170.2 |  |  | 9.6 |  |  | 265.2 |  |  | 15.5 |  |  |
| Japan |  |  |  |  |  |  |  |  | 84.6 |  |  | 6.2 |  |  | 179.5 |  |  | 10.2 |  |  | 181.2 |  |  | 10.6 |  |  |
| Other Asia-Pacific |  |  |  |  |  |  |  |  | 174.3 |  |  | 12.9 |  |  | 276.3 |  |  | 15.6 |  |  | 242.4 |  |  | 14.2 |  |  |
| Total Asia-Pacific |  |  |  |  |  |  |  |  | $ | 779.8 |  |  | 57.4 | % |  | $ | 1,141.7 |  |  | 64.6 | % |  | $ | 1,249.3 |  |  | 72.9 | % |  |
| EMEA |  |  |  |  |  |  |  |  | $ | 128.2 |  |  | 9.4 | % |  | $ | 194.7 |  |  | 11.0 | % |  | $ | 116.4 |  |  | 6.8 | % |  |
| Total net revenue |  |  |  |  |  |  |  |  | $ | 1,359.2 |  |  | 100.0 | % |  | $ | 1,767.0 |  |  | 100.0 | % |  | $ | 1,712.6 |  |  | 100.0 | % |  |

[0001628280-24-038024:notes:498]
During the years ended June 29, 2024, July 1, 2023, and July 2, 2022, net revenue generated from a single customer which represented 10% or greater of total net revenue is summarized as follows:

[0001628280-24-038024:notes:499]
|  | Years Ended |
|  | June 29, 2024 |  | July 1, 2023 |  | July 2, 2022 |
| Customer A | 18.9 | % |  | * |  | * |
| Customer B | * |  | 12.1 | % |  | 28.7 | % |
| Customer C | 11.4 | % |  | 15.3 | % |  | 12.6 | % |
| Customer D | * |  | 10.5 | % |  | * |
| *Represents less than 10% of total net revenue |  |  |  |  |  |

[0001628280-24-038024:notes:500]
The following table sets forth accounts receivable from a single customer that represented 10% or greater of the total accounts receivable for the periods presented:

[0001628280-24-038024:notes:501]
|  | June 29, 2024 |  | July 1, 2023 |
| Customer 1 | 12.9 | % |  | * |
| Customer 2 | * |  | 14.3 | % |
| Customer 3 | * |  | 11.9 | % |
| Customer 4 | * |  | 11.9 | % |
| *Represents less than 10% of total accounts receivable |  |  |  |

[0001628280-24-038024:notes:502]
Long-lived assets, namely property, plant and equipment, net, were identified based on the physical location of the assets in the corresponding geographic areas as of the periods indicated (in millions):

[0001628280-24-038024:notes:503]
|  | June 29, 2024 |  | July 1, 2023 |
| Property, plant and equipment, net |  |  |  |
| United States | $ | 131.0 |  |  | $ | 134.7 |  |
| Thailand | 141.0 |  |  | 132.0 |  |
| Japan | 75.7 |  |  | 93.0 |  |
| United Kingdom | 83.8 |  |  | 38.2 |  |
| China | 85.7 |  |  | 42.1 |  |
| Other countries | 55.3 |  |  | 49.5 |  |
| Total property, plant and equipment, net | $ | 572.5 |  |  | $ | 489.5 |  |

[0001628280-24-038024:notes:504]
We purchase a portion of our inventory from contract manufacturers and vendors located primarily in Thailand, Taiwan and Malaysia. The following table sets forth inventory purchase from a single contract manufacturer that represented 10% or greater of our total net inventory purchases for the periods presented:

[0001628280-24-038024:notes:505]
|  | June 29, 2024 |  | July 1, 2023 |
| Contract Manufacturer A | 30.3 | % |  | 42.5% |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001628280-24-038024:notes:506]
The following table presents net revenue by the three geographic regions we operate in and net revenue from countries that represented 10% or more of our total net revenue (in millions, except percentage data):


## us-gaap:SchedulesOfConcentrationOfRiskByRiskFactorTextBlock

[0001628280-24-038024:notes:507]
The table below discloses our total net revenue attributable to each of our two reportable segments (in millions, except percentage data):

[0001628280-24-038024:notes:508]
|  |  |  | Years Ended |
|  |  |  | June 29, 2024 |  | July 1, 2023 |  | July 2, 2022 |
|  |  |  | Amount |  | % to Total |  | Amount |  | % to Total |  | Amount |  | % to Total |
| Cloud & Networking |  |  | $ | 1,084.9 |  |  | 79.8 | % |  | $ | 1,322.5 |  |  | 74.8 | % |  | $ | 1,008.7 |  |  | 58.9 | % |
| Industrial Tech |  |  | 274.3 |  |  | 20.2 | % |  | 444.5 |  |  | 25.2 | % |  | 703.9 |  |  | 41.1 | % |
| Net revenue |  |  | $ | 1,359.2 |  |  | 100.0 | % |  | $ | 1,767.0 |  |  | 100.0 | % |  | $ | 1,712.6 |  |  | 100.0 | % |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001628280-24-038024:notes:509]
Note 18. Revenue Recognition

[0001628280-24-038024:notes:510]
We disaggregate revenue by segment and by geography. We do not present other levels of disaggregation, such as by type of products, customer, markets, contracts, duration of contracts, timing of transfer of control and sales channels, as this information is not used by our CODM to manage the business.

[0001628280-24-038024:notes:511]
The following table reflects the changes in contract balances for the periods presented (in millions, except percentages):

[0001628280-24-038024:notes:512]
| Contract balances |  | Balance sheet location |  | June 29, 2024 |  | July 1, 2023 |  | Change |  | Percentage Change |
| Accounts receivable, net |  | Accounts receivable, net |  | $ | 194.7 |  |  | $ | 246.1 |  |  | $ | (51.4) |  |  | (20.9)% |
| Deferred revenue and customer deposits |  | Other current liabilities |  | $ | 0.6 |  |  | $ | 2.1 |  |  | $ | (1.5) |  |  | (71.4)% |


## us-gaap:SubsequentEventsTextBlock

[0001628280-24-038024:notes:513]
Note 19. Subsequent Events
In July 2024, we purchased the land and building of our wafer fabrication facility located in Sagamihara, Japan for a total transaction price of $46.5 million including related fees and refundable consumption taxes. Our lease of the building at the premises, which was originally scheduled to end in March 2033, was terminated as a result of the purchase. We derecognized the related right-of-use assets of $31.9 million and lease liability of $17.4 million at the purchase completion date. In connection with the transaction, we entered into a secured mortgage loan agreement with Sumitomo Mitsui Banking Corporation (“SMBC”) that provided us with a term loan in an aggregate principal amount of 6.4 billion Japanese yen (“JPY”), which is approximately $43.5 million based on the exchange rate on August 9 2024, the loan effective date. The loan requires monthly payment of principal totaling approximately 3.2 billion JPY and interest based on a fixed annual interest rate of 1.04%, with the remaining principle of approximately 3.2 billion JPY due on the loan maturity date of July 31, 2029


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001628280-24-038024:notes:514]
SCHEDULE II - VALUATION AND QUALIFYING ACCOUNTS

[0001628280-24-038024:notes:515]
|  | (in millions) |
|  | Balance at beginning of period |  |  |  | Increase (decrease) in Consolidated Statements of Operations |  | Write-offs and other adjustments |  |  |  | Balance at end of period |
| Allowance for credit losses: |  |  |  |  |  |  |  |  |  |  |  |
| Fiscal year ended June 29, 2024 | $ | — |  |  |  |  | $ | 0.2 |  |  | $ | — |  |  |  |  | $ | 0.2 |  |
| Fiscal year ended July 1, 2023 | $ | — |  |  |  |  | $ | — |  |  | $ | — |  |  |  |  | $ | — |  |
| Fiscal year ended July 2, 2022 | $ | 0.4 |  |  |  |  | $ | (0.1) |  |  | $ | (0.3) |  |  |  |  | $ | — |  |

[0001628280-24-038024:notes:516]
|  |  | (in millions) |
|  |  | Balance at beginning of period |  | Additions charged to costs/expenses (1) |  | Deductions credited to costs/expenses (2) |  | Balance at end of period |
| Deferred tax valuation allowance: |  |  |  |  |  |  |  |  |
| Fiscal year ended June 29, 2024 |  | $ | 303.4 |  |  | $ | 205.4 |  |  | $ | (18.4) |  |  | $ | 490.4 |  |
| Fiscal year ended July 1, 2023 |  | $ | 263.1 |  |  | $ | 42.7 |  |  | $ | (2.4) |  |  | $ | 303.4 |  |
| Fiscal year ended July 2, 2022 |  | $ | 269.5 |  |  | $ | 5.7 |  |  | $ | (12.1) |  |  | $ | 263.1 |  |

[0001628280-24-038024:notes:517]
(1) Additions include current year additions charged to expenses and current year build due to increases in net deferred tax assets, return to provision true-ups, other adjustments to deferred taxes.

[0001628280-24-038024:notes:518]
(2) Net deductions include current year releases credited to expenses and current year reductions due to decreases in net deferred tax assets, return to provision true-ups, other adjustments to deferred taxes.
