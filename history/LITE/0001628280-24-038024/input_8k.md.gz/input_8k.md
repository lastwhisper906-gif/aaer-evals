# LITE 8-K — 0001628280-24-037191 filed 2024-08-14

## item codes, every 8-K on or before 2024-08-21

- 2024-08-21 0001628280-24-037938 — 2.02, 9.01 — amendment of 0001628280-24-037191
- 2024-08-14 0001628280-24-037191 — 2.02, 9.01
- 2024-05-06 0001628280-24-020640 — 2.02, 9.01
- 2024-02-27 0001628280-24-006936 — 5.02
- 2024-02-08 0001628280-24-003789 — 2.02, 9.01
- 2024-01-18 0001628280-24-001551 — 9.01 — amendment of 0001193125-23-272452
- 2023-11-21 0001628280-23-039654 — 5.02, 5.07
- 2023-11-08 0001628280-23-037563 — 2.02, 9.01
- 2023-11-07 0001193125-23-272452 — 2.01, 8.01, 9.01
- 2023-10-30 0001193125-23-265658 — 1.01, 2.02, 9.01
- 2023-08-17 0001628280-23-029741 — 2.02, 9.01
- 2023-06-16 0001193125-23-168966 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2023-05-09 0001628280-23-016629 — 2.02, 9.01
- 2023-04-06 0001628280-23-010935 — 2.02, 8.01, 9.01
- 2023-02-24 0001193125-23-048742 — 5.02, 9.01
- 2023-02-09 0001628280-23-002866 — 2.02, 9.01
- 2022-11-21 0001628280-22-030473 — 5.02, 5.07, 9.01
- 2022-11-08 0001628280-22-028758 — 2.02, 9.01
- 2022-08-16 0001628280-22-022980 — 2.02, 9.01
- 2022-08-03 0001193125-22-210674 — 2.01, 8.01, 9.01
- 2022-07-29 0001193125-22-206587 — 8.01, 9.01
- 2022-05-04 0001628280-22-012145 — 2.02, 9.01
- 2022-03-08 0001193125-22-069350 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2022-02-03 0001628280-22-001736 — 2.02, 9.01
- 2022-01-21 0001193125-22-014413 — 8.01, 9.01
- 2021-11-23 0001628280-21-024070 — 5.02, 5.07
- 2021-11-05 0001193125-21-321796 — 1.01, 9.01
- 2021-11-04 0001628280-21-021618 — 2.02, 9.01
- 2021-11-04 0001193125-21-319601 — 8.01, 9.01
- 2021-08-18 0001628280-21-017219 — 2.02, 9.01
- 2021-06-08 0001633978-21-000030 — 5.02, 9.01
- 2021-05-12 0001633978-21-000008 — 2.02, 9.01
- 2021-03-10 0001193125-21-075438 — 1.01, 8.01, 9.01
- 2021-02-02 0001633978-21-000002 — 2.02, 9.01
- 2021-01-19 0001104659-21-005024 — 1.01, 2.02, 8.01, 9.01
- 2020-11-24 0001193125-20-302557 — 5.02, 5.07
- 2020-11-02 0001633978-20-000017 — 2.02, 9.01
- 2020-09-18 0001633978-20-000012 — 5.02, 9.01
- 2020-08-11 0001633978-20-000010 — 2.02, 9.01
- 2020-05-05 0001628280-20-006358 — 2.02, 9.01
- 2020-02-04 0001633978-20-000002 — 2.02, 9.01
- 2019-12-12 0001193125-19-312875 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2019-12-04 0001633978-19-000075 — 8.01
- 2019-11-20 0001633978-19-000074 — 5.07
- 2019-10-31 0001633978-19-000070 — 2.02, 9.01
- 2019-08-08 0001633978-19-000068 — 2.02, 9.01
- 2019-05-08 0001633978-19-000031 — 1.01
- 2019-05-07 0001633978-19-000029 — 2.02, 9.01
- 2019-02-15 0001633978-19-000005 — 9.01 — amendment of 0001193125-18-346211
- 2019-02-08 0001193125-19-031591 — 5.02, 9.01
- 2019-02-05 0001633978-19-000001 — 2.02, 9.01
- 2018-12-10 0001193125-18-346211 — 1.01, 2.01, 2.03, 5.02, 8.01, 9.01
- 2018-12-06 0001633978-18-000150 — 8.01
- 2018-11-14 0001633978-18-000139 — 5.07
- 2018-11-13 0001633978-18-000136 — 3.02
- 2018-11-13 0001633978-18-000132 — 7.01, 9.01
- 2018-11-01 0001628280-18-013238 — 2.02, 9.01
- 2018-08-08 0001633978-18-000056 — 2.02, 9.01
- 2018-06-08 0001193125-18-188241 — 5.02, 9.01
- 2018-05-02 0001633978-18-000029 — 2.02, 9.01
- 2018-03-12 0001193125-18-078154 — 1.01, 2.01, 8.01, 9.01
- 2018-02-06 0001628280-18-001082 — 2.02, 9.01
- 2017-11-08 0001633978-17-000133 — 5.02, 9.01
- 2017-11-07 0001633978-17-000131 — 5.07
- 2017-11-01 0001633978-17-000117 — 2.02, 9.01
- 2017-08-09 0001633978-17-000058 — 2.02, 9.01
- 2017-05-04 0001633978-17-000035 — 2.02, 9.01
- 2017-03-08 0001193125-17-074740 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2017-03-02 0001193125-17-066769 — 8.01, 9.01
- 2017-02-07 0001633978-17-000005 — 2.02, 9.01
- 2017-01-03 0001628280-17-000018 — 4.01, 9.01
- 2016-11-09 0001628280-16-021143 — 5.02, 5.07, 9.01
- 2016-10-27 0001628280-16-020382 — 2.02, 9.01
- 2016-08-09 0001628280-16-018811 — 2.02, 9.01
- 2016-06-21 0001628280-16-017201 — 8.01
- 2016-05-04 0001628280-16-015501 — 2.02, 9.01
- 2016-02-16 0001628280-16-011261 — 5.02, 9.01
- 2016-02-04 0001628280-16-010758 — 5.02, 9.01
- 2016-02-04 0001628280-16-010755 — 2.02, 9.01
- 2015-11-17 0001193125-15-378953 — 7.01
- 2015-11-10 0001628280-15-008606 — 2.02, 9.01
- 2015-09-28 0001193125-15-329665 — 8.01, 9.01
- 2015-08-11 0001193125-15-286405 — 7.01, 9.01
- 2015-08-06 0001193125-15-281219 — 1.01, 5.02, 5.03, 5.05, 8.01, 9.01
- 2015-08-03 0001193125-15-274808 — 5.03, 9.01

## late-filing notifications on or before 2024-08-21

- 2015-11-10 0001628280-15-008612 — NT 10-Q, for the period ended 2015-09-26
- 2015-09-28 0001193125-15-329672 — NT 10-K, for the period ended 2015-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001628280-24-037191:8k_2_02:1]
EX-99.1
2
lite_ex991xq4fy24.htm
EX-99.1

[0001628280-24-037191:8k_2_02:2]
Document

[0001628280-24-037191:8k_2_02:3]
NEWS RELEASE

[0001628280-24-037191:8k_2_02:4]
LUMENTUM ANNOUNCES FISCAL FOURTH QUARTER AND FULL YEAR 2024 RESULTS

[0001628280-24-037191:8k_2_02:5]
Fiscal Fourth Quarter Highlights:

[0001628280-24-037191:8k_2_02:6]
•Net revenue of $308.3 million

[0001628280-24-037191:8k_2_02:7]
•GAAP operating loss of 43.3%; Non-GAAP operating loss of 0.3%

[0001628280-24-037191:8k_2_02:8]
•GAAP diluted net loss per share of $3.72; Non-GAAP diluted net income per share of  $0.06

[0001628280-24-037191:8k_2_02:9]
Fiscal Year 2024 Highlights:

[0001628280-24-037191:8k_2_02:10]
•Net revenue of $1.36 billion

[0001628280-24-037191:8k_2_02:11]
•GAAP operating loss of 31.9%; Non-GAAP operating margin of 2.8%

[0001628280-24-037191:8k_2_02:12]
•GAAP diluted net loss per share of $8.12; Non-GAAP diluted net income per share of  $1.01

[0001628280-24-037191:8k_2_02:13]
San Jose, Calif., August 14, 2024 – Lumentum Holdings Inc. (“Lumentum” or the “Company”) today reported results for its fiscal fourth quarter and full year ended June 29, 2024.

[0001628280-24-037191:8k_2_02:14]
“We exceeded our guidance midpoints for both revenue and EPS in the fourth quarter. We booked record orders for datacom chips used in data center applications and saw emerging positive trends in the broader traditional networking market,” said Alan Lowe, President and CEO. “We are making significant progress executing our strategy to broaden our cloud and AI customer base, which will lead to accelerated growth in calendar year 2025.”

[0001628280-24-037191:8k_2_02:15]
Fiscal Fourth Quarter Highlights:

[0001628280-24-037191:8k_2_02:16]
Net revenue for the fiscal fourth quarter of 2024 was $308.3 million, with GAAP net loss of $252.5 million, or $3.72 per diluted share. Net revenue for the fiscal third quarter of 2024 was $366.5 million, with GAAP net loss of $127.0 million, or $1.88 per diluted share. Net revenue for the fiscal fourth quarter of 2023 was $370.8 million, with GAAP net loss of $60.2 million, or $0.88 per diluted share.

[0001628280-24-037191:8k_2_02:17]
Non-GAAP net income for fiscal fourth quarter of 2024 was $4.0 million, or $0.06 per diluted share. Non-GAAP net income for fiscal third quarter of 2024 was $19.6 million, or $0.29 per diluted share. Non-GAAP net income for the fiscal fourth quarter of 2023 was $40.2 million, or $0.59 per diluted share.

[0001628280-24-037191:8k_2_02:18]
The Company held $887.0 million in total cash, cash equivalents, and short-term investments at the end of the fiscal fourth quarter of 2024, an increase of $16.1 million from the third quarter of 2024.

[0001628280-24-037191:8k_2_02:19]
Full Fiscal Year 2024 Highlights:

[0001628280-24-037191:8k_2_02:20]
Net revenue for fiscal year 2024 was $1,359.2 million, with GAAP net loss of $546.5 million, or $8.12 per diluted share. Net revenue for fiscal year 2023 was $1,767.0 million, with GAAP net loss of $131.6 million, or $1.93 per diluted share.

[0001628280-24-037191:8k_2_02:21]
Non-GAAP net income for fiscal year 2024 was $68.7 million, or $1.01 per diluted share. Non-GAAP net income for fiscal year 2023 was $315.3 million, or $4.56 per diluted share.

[0001628280-24-037191:8k_2_02:22]
Cash from operations for the fiscal year of 2024 was $24.7 million.

[0001628280-24-037191:8k_2_02:23]
Financial Overview – Fiscal Fourth Quarter Ended June 29, 2024

[0001628280-24-037191:8k_2_02:24]
|  | GAAP Results ($ in millions) |
|  | Q4 |  | Q3 |  | Q4 |  | Change |
|  | FY 2024 |  | FY 2024 |  | FY 2023 |  | Q/Q |  | Y/Y |
| Net revenue | $ | 308.3 |  |  | $ | 366.5 |  |  | $ | 370.8 |  |  | (15.9)% |  | (16.9)% |
| GAAP gross margin | 16.6 | % |  | 16.2 | % |  | 24.2 | % |  | 40bps |  | (760)bps |
| GAAP operating loss | (43.3) | % |  | (31.3) | % |  | (15.1) | % |  | (1,200)bps |  | (2,820)bps |
|  | Non-GAAP Results ($ in millions) |
|  | Q4 |  | Q3 |  | Q4 |  | Change |
|  | FY 2024 |  | FY 2024 |  | FY 2023 |  | Q/Q |  | Y/Y |
| Net revenue | $ | 308.3 |  |  | $ | 366.5 |  |  | $ | 370.8 |  |  | (15.9)% |  | (16.9)% |
| Non-GAAP gross margin | 32.2 | % |  | 32.6 | % |  | 36.7 | % |  | (40)bps |  | (450)bps |
| Non-GAAP operating margin (loss) | (0.3) | % |  | 4.1 | % |  | 9.1 | % |  | (440)bps |  | (940)bps |

[0001628280-24-037191:8k_2_02:25]
|  | Net Revenue by Segment ($ in millions) |
|  | Q4 |  | % of |  | Q3 |  | Q4 |  | Change |
|  | FY 2024 |  | Net Revenue |  | FY 2024 |  | FY 2023 |  | Q/Q |  | Y/Y |
| Cloud & Networking | $ | 254.7 |  |  | 82.6 | % |  | $ | 313.8 |  |  | $ | 286.5 |  |  | (18.8) | % |  | (11.1) | % |
| Industrial Tech | 53.6 |  |  | 17.4 | % |  | 52.7 |  |  | 84.3 |  |  | 1.7 | % |  | (36.4) | % |
| Total | $ | 308.3 |  |  | 100.0 | % |  | $ | 366.5 |  |  | $ | 370.8 |  |  | (15.9) | % |  | (16.9) | % |

[0001628280-24-037191:8k_2_02:26]
Financial Overview – Fiscal Year Ended June 29, 2024

[0001628280-24-037191:8k_2_02:27]
|  | GAAP Results ($ in millions) |
|  | FY 2024 |  | FY 2023 |  | Change Y/Y |  |
| Net revenue | $ | 1,359.2 |  |  | $ | 1,767.0 |  |  | (23.1)% |  |
| Gross margin | 18.5 | % |  | 32.2 | % |  | (1,370)bps |  |
| Operating loss | (31.9) | % |  | (6.5) | % |  | (2,540)bps |  |

[0001628280-24-037191:8k_2_02:28]
|  | Non-GAAP Results ($ in millions) |
|  | FY 2024 |  | FY 2023 |  | Change Y/Y |  |
| Net revenue | $ | 1,359.2 |  |  | $ | 1,767.0 |  |  | (23.1)% |  |
| Gross margin | 33.0 | % |  | 43.2 | % |  | (1,020)bps |  |
| Operating margin | 2.8 | % |  | 19.2 | % |  | (1,640)bps |  |

[0001628280-24-037191:8k_2_02:29]
|  | Net Revenue by Segment ($ in millions) |
|  | FY 2024 |  | FY 2023 |  | Change Y/Y |  |
| Cloud & Networking | $ | 1,084.9 |  |  | $ | 1,322.5 |  |  | (18.0)% |  |
| Industrial Tech | 274.3 |  |  | 444.5 |  |  | (38.3)% |  |
| Total | $ | 1,359.2 |  |  | $ | 1,767.0 |  |  | (23.1)% |  |

[0001628280-24-037191:8k_2_02:30]
The tables above provide comparisons of quarterly and annual results to prior periods, including sequential quarterly and year-over-year changes. A reconciliation between GAAP and non-GAAP measures is contained in this release under the section titled “Use of Non-GAAP Financial Measures.”

[0001628280-24-037191:8k_2_02:31]
Business Outlook

[0001628280-24-037191:8k_2_02:32]
Lumentum expects the following for the fiscal first quarter of 2025:

[0001628280-24-037191:8k_2_02:33]
•Net revenue in the range of $315 million to $335 million

[0001628280-24-037191:8k_2_02:34]
•Non-GAAP operating margin of 0% - 3.0%

[0001628280-24-037191:8k_2_02:35]
•Non-GAAP diluted earnings per share of $0.07 to $0.17

[0001628280-24-037191:8k_2_02:36]
We have not provided reconciliations from GAAP to non-GAAP measures or the equivalent GAAP measure for non-GAAP measures in our outlook, as they cannot be provided without unreasonable effort. A large portion of non-GAAP adjustments, such as restructuring charges, stock-based compensation, non-GAAP income tax reconciling adjustments, acquisition related costs, and other costs and contingencies unrelated to current and future operations are by their nature highly volatile and we have low visibility as to the range that may be incurred in the future.

[0001628280-24-037191:8k_2_02:37]
Conference Call

[0001628280-24-037191:8k_2_02:38]
Lumentum will host a conference call today, August 14, 2024, at 2:30 pm PT / 5:30 pm ET to discuss its fiscal fourth quarter and full year results. A live webcast of the call will be available in the Investors section of the Lumentum website at http://investor.lumentum.com. To listen to the live conference call, dial (833) 470-1428 or (404) 975-4839 and reference the conference ID 819344. Supporting materials outlining the Company’s latest financial results will be posted on http://investor.lumentum.com under the “Events and Presentations” section concurrently with this earnings press release. Lumentum has used, and intends to continue to use, its Investor Relations website as means of disclosing material nonpublic information and for complying with its disclosure obligations under Regulation FD. This press release is being furnished as an exhibit to a Current Report on Form 8-K filed with the Securities and Exchange Commission and will be available at http://www.sec.gov/.

[0001628280-24-037191:8k_2_02:39]
About Lumentum

[0001628280-24-037191:8k_2_02:40]
Lumentum (NASDAQ: LITE) is a market-leading designer and manufacturer of innovative optical and photonic products enabling optical networking and laser applications worldwide. Lumentum optical components and subsystems are part of virtually every type of telecom, enterprise, and data center network. Lumentum lasers enable advanced manufacturing techniques and diverse applications including next-generation imaging and sensing capabilities. Lumentum is headquartered in San Jose, California with R&D, manufacturing, and sales offices worldwide. For more information, visit www.lumentum.com and follow Lumentum on LinkedIn, X (formerly known as Twitter), Facebook, Instagram and YouTube.

[0001628280-24-037191:8k_2_02:41]
Forward-Looking Statements

[0001628280-24-037191:8k_2_02:42]
Contact Information

[0001628280-24-037191:8k_2_02:43]
Investors:     Kathy Ta, (408) 750-3853; investor.relations@lumentum.com

[0001628280-24-037191:8k_2_02:44]
Media:         Noël Bilodeau, 408-439-2140; noel.bilodeau@lumentum.com

[0001628280-24-037191:8k_2_02:45]
Category:    Financial

[0001628280-24-037191:8k_2_02:46]
The following financial tables are presented in accordance with GAAP, unless otherwise specified.

[0001628280-24-037191:8k_2_02:47]
LUMENTUM HOLDINGS INC.

[0001628280-24-037191:8k_2_02:48]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001628280-24-037191:8k_2_02:49]
(in millions, except per share data)

[0001628280-24-037191:8k_2_02:50]
(unaudited)

[0001628280-24-037191:8k_2_02:51]
|  | Three Months Ended |  | Twelve Months Ended |
|  | June 29, 2024 |  | July 1, 2023 |  | June 29, 2024 |  | July 1, 2023 |
| Net revenue | $ | 308.3 |  |  | $ | 370.8 |  |  | $ | 1,359.2 |  |  | $ | 1,767.0 |  |
| Cost of sales | 234.9 |  |  | 263.2 |  |  | 1,023.8 |  |  | 1,113.6 |  |
| Amortization of acquired developed intangibles | 22.1 |  |  | 18.0 |  |  | 83.9 |  |  | 84.4 |  |
| Gross profit | 51.3 |  |  | 89.6 |  |  | 251.5 |  |  | 569.0 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 73.2 |  |  | 73.9 |  |  | 302.2 |  |  | 307.8 |  |
| Selling, general and administrative | 74.9 |  |  | 68.3 |  |  | 310.7 |  |  | 348.8 |  |
| Restructuring and related charges | 36.6 |  |  | 3.3 |  |  | 72.6 |  |  | 28.1 |  |
| Total operating expenses | 184.7 |  |  | 145.5 |  |  | 685.5 |  |  | 684.7 |  |
| Loss from operations | (133.4) |  |  | (55.9) |  |  | (434.0) |  |  | (115.7) |  |
| Interest expense | (5.4) |  |  | (9.4) |  |  | (33.8) |  |  | (35.5) |  |
| Other income, net | 11.3 |  |  | 19.9 |  |  | 62.1 |  |  | 48.8 |  |
| Loss before income taxes | (127.5) |  |  | (45.4) |  |  | (405.7) |  |  | (102.4) |  |
| Income tax provision | 125.0 |  |  | 14.8 |  |  | 140.8 |  |  | 29.2 |  |
| Net loss | $ | (252.5) |  |  | $ | (60.2) |  |  | $ | (546.5) |  |  | $ | (131.6) |  |
| Net loss per share: |  |  |  |  |  |  |  |
| Basic | $ | (3.72) |  |  | $ | (0.88) |  |  | $ | (8.12) |  |  | $ | (1.93) |  |
| Diluted | $ | (3.72) |  |  | $ | (0.88) |  |  | $ | (8.12) |  |  | $ | (1.93) |  |
| Shares used to compute net loss per share: |  |  |  |  |  |  |  |
| Basic | 67.8 |  |  | 68.3 |  |  | 67.3 |  |  | 68.3 |  |
| Diluted | 67.8 |  |  | 68.3 |  |  | 67.3 |  |  | 68.3 |  |

[0001628280-24-037191:8k_2_02:52]
LUMENTUM HOLDINGS INC.

[0001628280-24-037191:8k_2_02:53]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001628280-24-037191:8k_2_02:54]
(in millions, except per share data)

[0001628280-24-037191:8k_2_02:55]
(unaudited)

[0001628280-24-037191:8k_2_02:56]
|  | June 29, 2024 |  | July 1, 2023 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 436.7 |  |  | $ | 859.0 |  |
| Short-term investments | 450.3 |  |  | 1,154.6 |  |
| Accounts receivable, net | 194.7 |  |  | 246.1 |  |
| Inventories | 398.4 |  |  | 408.6 |  |
| Prepayments and other current assets | 110.0 |  |  | 109.6 |  |
| Total current assets | 1,590.1 |  |  | 2,777.9 |  |
| Property, plant and equipment, net | 572.5 |  |  | 489.5 |  |
| Operating lease right-of-use assets, net | 72.8 |  |  | 77.3 |  |
| Goodwill | 1,055.8 |  |  | 695.1 |  |
| Other intangible assets, net | 617.5 |  |  | 459.2 |  |
| Deferred tax asset | 10.7 |  |  | 116.3 |  |
| Other non-current assets | 12.5 |  |  | 16.8 |  |
| Total assets | $ | 3,931.9 |  |  | $ | 4,632.1 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 126.3 |  |  | $ | 169.4 |  |
| Accrued payroll and related expenses | 36.1 |  |  | 39.4 |  |
| Accrued expenses | 52.4 |  |  | 51.2 |  |
| Convertible notes, current | — |  |  | 311.6 |  |
| Operating lease liabilities, current | 13.4 |  |  | 14.4 |  |
| Other current liabilities | 41.1 |  |  | 47.8 |  |
| Total current liabilities | 269.3 |  |  | 633.8 |  |
| Convertible notes, non-current | 2,503.2 |  |  | 2,500.0 |  |
| Operating lease liabilities, non-current | 43.0 |  |  | 47.7 |  |
| Deferred tax liability | 55.7 |  |  | 3.4 |  |
| Other non-current liabilities | 103.4 |  |  | 91.4 |  |
| Total liabilities | 2,974.6 |  |  | 3,276.3 |  |
| Stockholders’ equity: |  |  |  |
| Common stock, $0.001 par value, 990 authorized shares; 67.9 and 66.4 shares issued and outstanding as of June 29, 2024 and July 1, 2023, respectively | 0.1 |  |  | 0.1 |  |
| Additional paid-in capital | 1,835.0 |  |  | 1,692.2 |  |
| Accumulated deficit | (887.1) |  |  | (340.6) |  |
| Accumulated other comprehensive income | 9.3 |  |  | 4.1 |  |
| Total stockholders’ equity | 957.3 |  |  | 1,355.8 |  |
| Total liabilities and stockholders’ equity | $ | 3,931.9 |  |  | $ | 4,632.1 |  |

[0001628280-24-037191:8k_2_02:57]
Use of Non-GAAP Financial Measures

[0001628280-24-037191:8k_2_02:58]
In this press release, Lumentum provides investors with certain non-GAAP financial measures: gross profit, gross margin, research and development expense, selling, general and administrative expense, operating margin (loss), income (loss) from operations, interest and other income (expense), net, income before income taxes, provision for income taxes, net income (loss), and net income (loss) per share on a non-GAAP basis, as well as the non-GAAP measures of EBITDA and Adjusted EBITDA. Lumentum believes this non-GAAP financial information provides additional insight into the Company’s on-going business operations and results, as well as cash generation, and has therefore chosen to provide this information to investors for a more consistent basis of comparison and to help them evaluate the results of the Company’s on-going operations and enable more meaningful period to period comparisons. In addition, the Company believes that providing certain of these measures allows investors to better understand the Company’s operating performance and cash flows and, importantly, to evaluate the methodology and information used by management to monitor, manage, evaluate and measure the Company’s business, results of operations, and cash flows. However, these measures may be different from non-GAAP measures used by other companies, limiting their usefulness for comparison purposes. The non-GAAP financial measures used in this press release should not be considered in isolation from measures of financial performance prepared in accordance with GAAP. Investors are cautioned that there are material limitations associated with the use of non-GAAP financial measures as an analytical tool. In particular, many of the adjustments to our GAAP financial measures reflect the exclusion of items that are recurring and will be reflected in our financial results for the foreseeable future. Further, these non-GAAP financial measures may not be comparable to similarly titled measurements reported by other companies.

[0001628280-24-037191:8k_2_02:59]
Our non-GAAP measures used in this press release exclude (i) stock-based compensation, (ii) acquisition related stock-based compensation, (iii) acquisition related costs, (iv) amortization of acquired intangibles, (v) amortization of acquired inventory fair value adjustments, (vi) restructuring and related charges, (vii) foreign exchange (gains) losses, net, (viii) non-cash interest expense on convertible notes, (ix) gain on repurchase of convertible notes, (x) non-recurring expenses related to litigation matters, (xi) intangible assets write-off, (xii) integration related costs, (xiii) abnormal excess capacity, (xiv) foreign exchange gains and losses, (xv) non-GAAP income tax reconciling adjustments, and (xvi) other (gains) charges related to non-recurring activities.

[0001628280-24-037191:8k_2_02:60]
We utilize a long-term projected non-GAAP tax rate to compute our non-GAAP income tax provision. The long-term projected non-GAAP tax rate is based on a multi-year projection of our estimated annual GAAP income tax forecast, adjusted to account for the tax effect of non-GAAP pretax adjustments as well as the effects of significant non-recurring and period specific tax items. Our non-GAAP tax provision for fiscal year 2024 is 14.5%. The difference between our GAAP income tax provision and our non-GAAP income tax provision is presented as non-GAAP income tax reconciling adjustments.

[0001628280-24-037191:8k_2_02:61]
A quantitative reconciliation between GAAP and non-GAAP financial data with respect to historical periods is included in the supplemental financial table attached to this press release.

[0001628280-24-037191:8k_2_02:62]
LUMENTUM HOLDINGS INC.

[0001628280-24-037191:8k_2_02:63]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001628280-24-037191:8k_2_02:64]
(in millions, except per share data)

[0001628280-24-037191:8k_2_02:65]
(unaudited)

[0001628280-24-037191:8k_2_02:66]
|  | Three Months Ended |  | Twelve Months Ended |
|  | June 29, 2024 |  | March 30, 2024 |  | July 1, 2023 |  | June 29, 2024 |  | July 1, 2023 |
| Gross profit on GAAP basis | $ | 51.3 |  |  | $ | 59.5 |  |  | $ | 89.6 |  |  | $ | 251.5 |  |  | $ | 569.0 |  |
| Stock-based compensation | 8.2 |  |  | 8.5 |  |  | 11.0 |  |  | 31.7 |  |  | 30.1 |  |
| Integration related costs | 4.6 |  |  | 6.4 |  |  | 2.6 |  |  | 24.5 |  |  | 12.1 |  |
| Amortization of acquired intangibles | 22.1 |  |  | 22.3 |  |  | 18.0 |  |  | 83.9 |  |  | 84.4 |  |
| Amortization of inventory fair value adjustments | — |  |  | 4.9 |  |  | — |  |  | 8.3 |  |  | 17.8 |  |
| Abnormal excess capacity (1) | 7.0 |  |  | 11.9 |  |  | — |  |  | 20.7 |  |  | — |  |
| Intangible asset write-off | — |  |  | — |  |  | 6.8 |  |  | — |  |  | 6.8 |  |
| Other charges, net (2) | 6.0 |  |  | 5.8 |  |  | 8.1 |  |  | 28.3 |  |  | 43.3 |  |
| Gross profit on non-GAAP basis | $ | 99.2 |  |  | $ | 119.3 |  |  | $ | 136.1 |  |  | $ | 448.9 |  |  | $ | 763.5 |  |
| Gross margin on non-GAAP basis | 32.2 | % |  | 32.6 | % |  | 36.7 | % |  | 33.0 | % |  | 43.2 | % |
| Research and development on GAAP basis | $ | 73.2 |  |  | $ | 77.2 |  |  | $ | 73.9 |  |  | $ | 302.2 |  |  | $ | 307.8 |  |
| Stock-based compensation | (8.0) |  |  | (9.8) |  |  | (10.2) |  |  | (38.1) |  |  | (41.4) |  |
| Integration related costs | — |  |  | (0.4) |  |  | (0.6) |  |  | (0.7) |  |  | (1.9) |  |
| Amortization of acquired intangibles | (0.4) |  |  | (0.4) |  |  | — |  |  | (1.5) |  |  | — |  |
| Intangible asset write-off | — |  |  | — |  |  | (1.4) |  |  | — |  |  | (12.9) |  |
| Acquisition related costs | — |  |  | — |  |  | — |  |  | (0.4) |  |  | — |  |
| Other charges, net | 0.1 |  |  | (0.4) |  |  | — |  |  | (1.1) |  |  | (2.6) |  |
| Research and development on non-GAAP basis | $ | 64.9 |  |  | $ | 66.2 |  |  | $ | 61.7 |  |  | $ | 260.4 |  |  | $ | 249.0 |  |
| Selling, general and administrative on GAAP basis | $ | 74.9 |  |  | $ | 77.7 |  |  | $ | 68.3 |  |  | $ | 310.7 |  |  | $ | 348.8 |  |
| Stock-based compensation | (14.3) |  |  | (13.3) |  |  | (10.9) |  |  | (59.0) |  |  | (65.0) |  |
| Stock-based compensation - acquisition related | — |  |  | — |  |  | — |  |  | — |  |  | (11.9) |  |
| Acquisition related (costs) reversal | 0.2 |  |  | (0.5) |  |  | 4.7 |  |  | (12.9) |  |  | (11.5) |  |
| Integration related costs | (2.8) |  |  | (3.4) |  |  | (6.2) |  |  | (11.9) |  |  | (14.6) |  |
| Litigation matters | — |  |  | — |  |  | — |  |  | — |  |  | (7.8) |  |
| Intangible asset write-off | — |  |  | — |  |  | (1.6) |  |  | — |  |  | (1.6) |  |
| Amortization of acquired intangibles | (19.4) |  |  | (19.4) |  |  | (11.4) |  |  | (65.2) |  |  | (43.3) |  |
| Other charges, net (2) | (3.5) |  |  | (3.0) |  |  | (2.2) |  |  | (11.0) |  |  | (17.8) |  |
| Selling, general and administrative on non-GAAP basis | $ | 35.1 |  |  | $ | 38.1 |  |  | $ | 40.7 |  |  | $ | 150.7 |  |  | $ | 175.3 |  |
| Loss from operations on GAAP basis | $ | (133.4) |  |  | $ | (114.6) |  |  | $ | (55.9) |  |  | $ | (434.0) |  |  | $ | (115.7) |  |
| Stock-based compensation | 30.5 |  |  | 31.6 |  |  | 32.1 |  |  | 128.8 |  |  | 136.5 |  |
| Stock-based compensation - acquisition related | — |  |  | — |  |  | — |  |  | — |  |  | 11.9 |  |
| Acquisition related costs (reversal) | (0.2) |  |  | 0.5 |  |  | (4.7) |  |  | 13.3 |  |  | 11.5 |  |
| Integration related costs | 7.4 |  |  | 10.2 |  |  | 9.4 |  |  | 37.1 |  |  | 28.6 |  |
| Litigation matters | — |  |  | — |  |  | — |  |  | — |  |  | 7.8 |  |
| Amortization of acquired intangibles | 41.9 |  |  | 42.1 |  |  | 29.4 |  |  | 150.6 |  |  | 127.7 |  |
| Amortization of inventory fair value adjustments | — |  |  | 4.9 |  |  | — |  |  | 8.3 |  |  | 17.8 |  |

[0001628280-24-037191:8k_2_02:67]
| Restructuring and related charges (3) | 36.6 |  |  | 19.2 |  |  | 3.3 |  |  | 72.6 |  |  | 28.1 |  |
| Intangible asset write-off | — |  |  | — |  |  | 9.8 |  |  | — |  |  | 21.3 |  |
| Abnormal excess capacity (1) | 7.0 |  |  | 11.9 |  |  | — |  |  | 20.7 |  |  | — |  |
| Other charges, net (2) | 9.4 |  |  | 9.2 |  |  | 10.3 |  |  | 40.4 |  |  | 63.7 |  |
| Income (loss) from operations on non-GAAP basis | $ | (0.8) |  |  | $ | 15.0 |  |  | $ | 33.7 |  |  | $ | 37.8 |  |  | $ | 339.2 |  |
| Operating margin (loss) on non-GAAP basis | (0.3) | % |  | 4.1 | % |  | 9.1 | % |  | 2.8 | % |  | 19.2 | % |
| Interest and other income, net on GAAP basis | $ | 5.9 |  |  | $ | 7.2 |  |  | $ | 10.5 |  |  | $ | 28.3 |  |  | $ | 13.3 |  |
| Foreign exchange gains, net | (1.2) |  |  | (3.7) |  |  | (2.6) |  |  | (0.7) |  |  | (7.0) |  |
| Gain on repurchase of convertible notes | — |  |  | — |  |  | (1.0) |  |  | — |  |  | (1.0) |  |
| Non-cash interest expense on convertible notes and other expenses | 0.7 |  |  | 4.5 |  |  | 6.4 |  |  | 14.9 |  |  | 24.3 |  |
| Interest and other income, net on non-GAAP basis | $ | 5.4 |  |  | $ | 8.0 |  |  | $ | 13.3 |  |  | $ | 42.5 |  |  | $ | 29.6 |  |
| Loss before income taxes on GAAP basis | $ | (127.5) |  |  | $ | (107.4) |  |  | $ | (45.4) |  |  | $ | (405.7) |  |  | $ | (102.4) |  |
| Stock-based compensation | 30.5 |  |  | 31.6 |  |  | 32.1 |  |  | 128.8 |  |  | 136.5 |  |
| Stock-based compensation - acquisition related | — |  |  | — |  |  | — |  |  | — |  |  | 11.9 |  |
| Acquisition related costs (reversal) | (0.2) |  |  | 0.5 |  |  | (4.7) |  |  | 13.3 |  |  | 11.5 |  |
| Integration related costs | 7.4 |  |  | 10.2 |  |  | 9.4 |  |  | 37.1 |  |  | 28.6 |  |
| Litigation matters | — |  |  | — |  |  | — |  |  | — |  |  | 7.8 |  |
| Amortization of acquired intangibles | 41.9 |  |  | 42.1 |  |  | 29.4 |  |  | 150.6 |  |  | 127.7 |  |
| Amortization of inventory fair value adjustments | — |  |  | 4.9 |  |  | — |  |  | 8.3 |  |  | 17.8 |  |
| Restructuring and related charges (3) | 36.6 |  |  | 19.2 |  |  | 3.3 |  |  | 72.6 |  |  | 28.1 |  |
| Abnormal excess capacity (1) | 7.0 |  |  | 11.9 |  |  | — |  |  | 20.7 |  |  | — |  |
| Intangible asset write-off | — |  |  | — |  |  | 9.8 |  |  | — |  |  | 21.3 |  |
| Foreign exchange gains, net | (1.2) |  |  | (3.7) |  |  | (2.6) |  |  | (0.7) |  |  | (7.0) |  |
| Gain on repurchase of convertible notes | — |  |  | — |  |  | (1.0) |  |  | — |  |  | (1.0) |  |
| Non-cash interest expense on convertible notes and other expenses | 0.7 |  |  | 4.5 |  |  | 6.4 |  |  | 14.9 |  |  | 24.3 |  |
| Other charges, net (2) | 9.4 |  |  | 9.2 |  |  | 10.3 |  |  | 40.4 |  |  | 63.7 |  |
| Income before income taxes on non-GAAP basis | $ | 4.6 |  |  | $ | 23.0 |  |  | $ | 47.0 |  |  | $ | 80.3 |  |  | $ | 368.8 |  |
| Income tax provision on GAAP basis | $ | 125.0 |  |  | $ | 19.6 |  |  | $ | 14.8 |  |  | $ | 140.8 |  |  | $ | 29.2 |  |
| Non-GAAP income tax reconciling adjustments (4) | (124.4) |  |  | (16.2) |  |  | (8.0) |  |  | (129.2) |  |  | 24.3 |  |
| Income tax provision on non-GAAP basis | $ | 0.6 |  |  | $ | 3.4 |  |  | $ | 6.8 |  |  | $ | 11.6 |  |  | $ | 53.5 |  |
| Net loss on GAAP basis | $ | (252.5) |  |  | (127.0) |  |  | (60.2) |  |  | $ | (546.5) |  |  | $ | (131.6) |  |
| Stock-based compensation | 30.5 |  |  | 31.6 |  |  | 32.1 |  |  | 128.8 |  |  | 136.5 |  |
| Stock-based compensation - acquisition related | — |  |  | — |  |  | — |  |  | — |  |  | 11.9 |  |
| Acquisition related costs (reversal) | (0.2) |  |  | 0.5 |  |  | (4.7) |  |  | 13.3 |  |  | 11.5 |  |
| Integration related costs | 7.4 |  |  | 10.2 |  |  | 9.4 |  |  | 37.1 |  |  | 28.6 |  |
| Litigation matters | — |  |  | — |  |  | — |  |  | — |  |  | 7.8 |  |
| Amortization of acquired intangibles | 41.9 |  |  | 42.1 |  |  | 29.4 |  |  | 150.6 |  |  | 127.7 |  |
| Amortization of inventory fair value adjustments | — |  |  | 4.9 |  |  | — |  |  | 8.3 |  |  | 17.8 |  |
| Restructuring and related charges (3) | 36.6 |  |  | 19.2 |  |  | 3.3 |  |  | 72.6 |  |  | 28.1 |  |
| Intangible asset write-off | — |  |  | — |  |  | 9.8 |  |  | — |  |  | 21.3 |  |

[0001628280-24-037191:8k_2_02:68]
| Abnormal excess capacity (1) | 7.0 |  |  | 11.9 |  |  | — |  |  | 20.7 |  |  | — |  |
| Foreign exchange gains, net | (1.2) |  |  | (3.7) |  |  | (2.6) |  |  | (0.7) |  |  | (7.0) |  |
| Gain on repurchase of convertible notes | — |  |  | — |  |  | (1.0) |  |  | — |  |  | (1.0) |  |
| Non-cash interest expense on convertible notes and other expenses | 0.7 |  |  | 4.5 |  |  | 6.4 |  |  | 14.9 |  |  | 24.3 |  |
| Other charges, net (2) | 9.4 |  |  | 9.2 |  |  | 10.3 |  |  | 40.4 |  |  | 63.7 |  |
| Non-GAAP income tax reconciling adjustments (4) | 124.4 |  |  | 16.2 |  |  | 8.0 |  |  | 129.2 |  |  | (24.3) |  |
| Net income on non-GAAP basis | $ | 4.0 |  |  | $ | 19.6 |  |  | $ | 40.2 |  |  | $ | 68.7 |  |  | $ | 315.3 |  |
| Net income per share on non-GAAP basis | $ | 0.06 |  |  | $ | 0.29 |  |  | $ | 0.59 |  |  | $ | 1.01 |  |  | $ | 4.56 |  |
| Shares used in per share calculation - diluted on GAAP basis | 67.8 |  |  | 67.5 |  |  | 68.3 |  |  | 67.3 |  |  | 68.3 |  |
| Non-GAAP adjustment (5) | 0.5 |  |  | 0.6 |  |  | 0.3 |  |  | 0.4 |  |  | 0.8 |  |
| Shares used in per share calculation - diluted on non-GAAP basis | 68.3 |  |  | 68.1 |  |  | 68.6 |  |  | 67.7 |  |  | 69.1 |  |

[0001628280-24-037191:8k_2_02:69]
(1) Abnormal excess capacity for the three and twelve months ended June 29, 2024 represents excess capacity attributable to a near-term reduction in our manufacturing production, primarily driven by our non-recurring inventory reduction effort following the disruptions in the supply chain due to the COVID-19 pandemic and factory consolidation efforts.

[0001628280-24-037191:8k_2_02:70]
(2) Other charges, net for the three months ended June 29, 2024 primarily relate to a $3.4 million one-time charge as a result of contract termination with one of our vendors due to a change in our manufacturing strategy, $2.2 million of non-recurring legal and tax related fees and $0.5 million of incremental costs of sales related to components previously acquired from various brokers to satisfy customer demand, offset by various miscellaneous gains. The excess and obsolete inventory charges relate to charges that are not attributable to our operating segments due to their unusual nature, primarily those charges driven by U.S. trade restrictions whereby we are no longer able to sell certain products to one of our customers.

[0001628280-24-037191:8k_2_02:71]
Other charges, net for the twelve months ended June 29, 2024 primarily relate to $11.2 million of net excess and obsolete inventory, $12.4 million of non-recurring legal and tax related fees, $4.9 million of incremental costs of sales related to components previously acquired from various brokers to satisfy customer demand and $3.4 million of one-time charge as a result of contract termination with one of our vendors due to a change in our manufacturing strategy, offset by various miscellaneous gains. The excess and obsolete inventory charges relate to charges that are not attributable to our operating segments due to their unusual nature, primarily those charges driven by U.S. trade restrictions whereby we are no longer able to sell certain products to one of our customers.

[0001628280-24-037191:8k_2_02:72]
(3) We discontinued in-house development of coherent digital signal processors (“DSPs”) and radio-frequency integrated circuits (“RFICs”). As a result, we recorded $35.8 million of restructuring and related charges during the fiscal fourth quarter of 2024, which includes a $29.1 million write-off of in-process research and development (“IPR&D”) assets, as well as $6.7 million of contract exit costs and asset write-off.

[0001628280-24-037191:8k_2_02:73]
(4) The non-GAAP income tax reconciling adjustments for the three months ended June 29, 2024 include $139.8 million of income tax expense due to recognizing a valuation allowance against our U.S. federal and state deferred tax assets.

[0001628280-24-037191:8k_2_02:74]
(5) Shares used for net income per share on non-GAAP basis include incremental dilutive shares that would occur upon conversion of our convertible notes assuming we settle the face value of the notes in cash as the Company intends, and shares related to restricted stock units (“RSUs”) and shares issuable under our Employee Stock Purchase Plan that are anti-dilutive on GAAP basis.

[0001628280-24-037191:8k_2_02:75]
LUMENTUM HOLDINGS INC.

[0001628280-24-037191:8k_2_02:76]
RECONCILIATION OF GAAP NET INCOME (LOSS) TO ADJUSTED EBITDA

[0001628280-24-037191:8k_2_02:77]
(in millions, except per share data)

[0001628280-24-037191:8k_2_02:78]
(unaudited)

[0001628280-24-037191:8k_2_02:79]
|  | Three Months Ended |  | Twelve Months Ended |
|  | June 29, 2024 |  | March 30, 2024 |  | July 1, 2023 |  | June 29, 2024 |  | July 1, 2023 |
| GAAP net loss | $ | (252.5) |  |  | $ | (127.0) |  |  | $ | (60.2) |  |  | $ | (546.5) |  |  | $ | (131.6) |  |
| Interest and other income, net | (5.9) |  |  | (7.2) |  |  | (10.5) |  |  | (28.3) |  |  | (13.3) |  |
| Income tax provision | 125.0 |  |  | 19.6 |  |  | 14.8 |  |  | 140.8 |  |  | 29.2 |  |
| Depreciation | 28.2 |  |  | 27.0 |  |  | 28.0 |  |  | 110.6 |  |  | 106.6 |  |
| Amortization of acquired intangibles | 41.9 |  |  | 42.1 |  |  | 29.4 |  |  | 150.6 |  |  | 127.7 |  |
| EBITDA | (63.3) |  |  | (45.5) |  |  | 1.5 |  |  | (172.8) |  |  | 118.6 |  |
| Amortization of inventory fair value adjustments | — |  |  | 4.9 |  |  | — |  |  | 8.3 |  |  | 17.8 |  |
| Restructuring and related charges | 36.6 |  |  | 19.2 |  |  | 3.3 |  |  | 72.6 |  |  | 28.1 |  |
| Stock-based compensation | 30.5 |  |  | 31.6 |  |  | 32.1 |  |  | 128.8 |  |  | 148.4 |  |
| Acquisition related costs | (0.2) |  |  | 0.5 |  |  | (4.7) |  |  | 13.3 |  |  | 11.5 |  |
| Integration related costs | 7.4 |  |  | 10.2 |  |  | 9.4 |  |  | 37.1 |  |  | 28.6 |  |
| Intangible asset write-off | — |  |  | — |  |  | 9.8 |  |  | — |  |  | 21.3 |  |
| Abnormal excess capacity | 7.0 |  |  | 11.9 |  |  | — |  |  | 20.7 |  |  | — |  |
| Other charges, net | 7.9 |  |  | 8.2 |  |  | 8.0 |  |  | 32.5 |  |  | 57.4 |  |
| Adjusted EBITDA | $ | 25.9 |  |  | $ | 41.0 |  |  | $ | 59.4 |  |  | $ | 140.5 |  |  | $ | 431.7 |  |
