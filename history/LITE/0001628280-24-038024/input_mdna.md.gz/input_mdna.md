# LITE MD&A — 0001628280-24-038024


## mdna

[0001628280-24-038024:mdna:1]
ITEM 7.    MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0001628280-24-038024:mdna:2]
You should read the following discussion in conjunction with the audited consolidated financial statements and the corresponding notes included elsewhere in this Annual Report. This Management’s Discussion and Analysis of Financial Condition and Results of Operations contains forward-looking statements. The matters discussed in these forward-looking statements are subject to risk, uncertainties and other factors that could cause actual results to differ materially from those made, projected or implied in the forward-looking statements. Refer to “Risk Factors” and “Forward-Looking Statements” for a discussion of the uncertainties, risks and assumptions associated with these statements.

[0001628280-24-038024:mdna:3]
Overview

[0001628280-24-038024:mdna:4]
We are an industry-leading provider of optical and photonic products defined by revenue and market share, essential to range of cloud, artificial intelligence and machine learning (“AI/ML”), telecommunications, consumer, and industrial end-market applications.

[0001628280-24-038024:mdna:5]
We believe the global markets in which Lumentum participates have fundamentally robust, long-term trends that will increase the need for our photonics products and technologies. We believe the world is becoming more reliant on ever-increasing amounts of data flowing through optical networks and data centers. Lumentum’s products and technology enable the scaling of cloud data centers and communications networks and to higher capacities. The advent of AI/ML has caused a dramatic surge in the growing demands on data networking in cloud data centers and accelerated the usage of optical components and modules. We expect that the accelerating shift to digital and virtual approaches to many aspects of work and life will continue into the future. Virtual meetings, video calls, and hybrid in-person and virtual environments for work and other aspects of life will continue to drive strong needs for bandwidth growth and present dynamic new challenges that our technology addresses. As manufacturers demand higher levels of precision, new materials, and factory and energy efficiency, suppliers of manufacturing tools globally are turning to laser-based approaches, including the types of lasers Lumentum supplies. Laser-based 3D sensing and LiDAR for security, industrial and automotive applications are rapidly developing markets. The technology enables computer vision applications that enhance security, safety, and new functionality in the electronic devices that people rely on every day. The use of LiDAR and in-cabin 3D sensing in automobile and delivery vehicles over time significantly adds to our long-term market opportunity. Additionally, we expect 3D-enabled machine vision solutions to expand significantly in industrial applications in the coming years.

[0001628280-24-038024:mdna:6]
To maintain and grow our market and technology leadership positions, we are continually investing in new and differentiated products and technologies and customer programs that address both nearer-term and longer-term growth opportunities, both organically and through acquisitions, as well as continually improving and optimizing our operations. Over many years, we have developed close relationships with market leading customers. We seek to use our core optical and photonic technology and our volume manufacturing capability to expand into attractive emerging markets that benefit from advantages that optical or photonics-based solutions provide.

[0001628280-24-038024:mdna:7]
Prior to fiscal year 2024, we operated in two reportable segments consisting of Optical Communications (“OpComms”) and Commercial Lasers (“Lasers”). During the fiscal first quarter of 2024, our chief operating decision maker (“CODM”) implemented changes in how he organizes the business, allocates resources, and assesses performance. We changed our organizational structure to better align with trends in our markets and our customer and product mix. Our new operating segments are Cloud & Networking and Industrial Tech. The Cloud & Networking segment includes the Telecom & Datacom product lines that were previously part of the OpComms segment. The Industrial Tech segment includes previous Lasers segment and the Industrial & Consumer product lines that were previously part of the OpComms segment. The two operating segments were primarily determined based on how the CODM views and evaluates our operations. The CODM regularly reviews operating results to make decisions about resources to be allocated to the segments and to assess their performance.

[0001628280-24-038024:mdna:8]
In conjunction with this change, our CODM now evaluates each segment’s performance and allocates resources based on segment revenue and segment profit, instead of gross profit, as our CODM believes segment profit is a more comprehensive profitability measure for each operating segment. Segment profit includes operating expenses directly managed by operating segments, including research and development, and direct sales and marketing expenses. Segment profit does not include stock-based compensation, acquisition or integration related costs, amortization and impairment of acquisition-related intangible assets, restructuring and related charges, and certain other charges. Additionally, we do not allocate corporate marketing and strategic marketing expenses and general and administrative expenses, as these expenses are not directly attributable to our operating segments.

[0001628280-24-038024:mdna:9]
Comparative prior period segment information has been recast to conform to the new segment structure and segment profitability measure. The change in our operating segments had no impact on our previously reported consolidated results of operations, financial condition, or cash flows.

[0001628280-24-038024:mdna:10]
Cloud & Networking

[0001628280-24-038024:mdna:11]
Our Cloud & Networking products include a comprehensive portfolio of optical and photonic components, modules, and subsystems supplied to network operator and network equipment manufacturer customers building cloud data center infrastructure, including products for artificial intelligence and machine learning (“AI/ML”) and data center interconnect (“DCI”) applications, and communications service provider networks, including products for access (local), metro (intracity), long-haul (city-to-city and worldwide), and submarine (undersea) network infrastructure. Our Cloud & Networking products also support network equipment manufacturers building enterprise network infrastructure, including storage-area networks (“SANs”), local-area networks (“LANs”) and wide-area networks (“WANs”). Demand for our Cloud & Networking products is driven by the continual growth in network capacity required for cloud computing and services, including for AI/ML, streaming video and video conferencing, wireless and mobile devices, and internet of things (“IoT”).

[0001628280-24-038024:mdna:12]
Industrial Tech

[0001628280-24-038024:mdna:13]
Our Industrial Tech products include solid-state lasers, kilowatt-class fiber lasers, ultrafast lasers, diode lasers, and gas lasers, which address applications in numerous end-markets. In the consumer end-market, our laser light sources are integrated into our customers’ 3D sensing cameras, which are used in mobile devices, payment kiosks, and other consumer electronics devices to enable applications including biometric identification, computational photography and virtual and augmented reality. In the automotive end-market, our lasers are used in our customers’ LiDAR and other optical sensor devices, which are increasingly being used in advanced driver assistance systems (“ADAS”) and in-cabin driver and occupant monitoring systems. In the industrial manufacturing end-market, our lasers are incorporated into our customers’ manufacturing machine tools used for the precision processing of materials in a range of industries including semiconductor device and microelectronics fabrication, electric vehicle and battery production, metal cutting and welding, and advanced manufacturing. Our products can also be used in the industrial end-market in imaging and sensing systems for process feedback and control, quality assurance, and waste reduction. Adoption of our products in the industrial end-market is driven by the needs of customers to advance semiconductor and microelectronics industry roadmaps, and by Industry 4.0/5.0 trends, including increasing manufacturing precision and flexibility and reducing waste and environmental impact. Demand for our products in the industrial end-market is driven by end-customer investments in manufacturing capacity. Our lasers also address certain semiconductor inspection and life-science applications.

[0001628280-24-038024:mdna:14]
Cloud Light Acquisition

[0001628280-24-038024:mdna:15]
On November 7, 2023 (the “Closing date”), we completed the acquisition of Cloud Light. Cloud Light designs, markets, and manufactures advanced optical modules for data center interconnect applications. The acquisition enables us to be well-positioned to serve the growing needs of cloud & networking customers, particularly those focused on optimizing their data center infrastructure for the demands of AI/ML. On the Closing date, we paid $705.0 million of total cash consideration to Cloud Light. Additionally, each of Cloud Light’s outstanding options was exchanged for a combination of cash and options to acquire Lumentum common stock having equivalent value (the “replacement options”). These replacement options have a total fair value of $38.9 million as of the Closing date, of which $23.5 million attributable to pre-acquisition service is recorded as part of the purchase price consideration and the remaining $15.4 million is recorded as post-acquisition stock-based compensation expense over the vesting period of three years from the Closing date. We also incurred a total of $9.6 million of merger-related costs, representing professional and other direct acquisition costs, which was recorded as general and administrative expense in the consolidated statement of operations for the year ended June 29, 2024. Refer to “Note 4. Business Combination” to the consolidated financial statements for additional information.

[0001628280-24-038024:mdna:16]
Supply Chain Constraints

[0001628280-24-038024:mdna:17]
Our business and our customers’ businesses have been negatively impacted by worldwide logistics and supply chain issues, including constraints on available cargo capabilities and limited availability of once broadly available supplies of both raw materials and finished components. COVID-19 also created dynamics in the semiconductor component supply chains that have led to shortages of the types of components we and our customers require in our products. Although the supply chain constraints started to improve in the latter half of fiscal 2023, we felt its ongoing effects in fiscal 2024, as described below, and these constraints or effects may impact our ability to supply our products to our customers and may reduce our revenue and profit margin if they continue or reoccur. In addition, if our customers are unable to procure needed semiconductor components, their demand for our products will decrease. Due to the global supply chain constraints, we had to incur incremental supply and procurement costs in order to increase our ability to fulfill demands from our customers.

[0001628280-24-038024:mdna:18]
In addition, in response to component shortages, certain of our customers accumulated inventory that they are now managing down as supply conditions improve. Accordingly, customer orders have declined in recent periods and certain customers have not taken the shipments we had originally projected due to their inventory management.  As customers manage their inventory down, our revenue has declined and our margins are adversely impacted as we are not able to fully recover

[0001628280-24-038024:mdna:19]
costs, such as underutilized manufacturing capacity, associated with the forecasted demand and we may incur excess and obsolescence charges from unsold inventory. In the fiscal fourth quarter of 2024, inventory reduced by $22.3 million compared to the fiscal third quarter of 2024, due to our focused effort to manage our production and inventory levels. Over the next several quarters, we plan to continue to manage our inventory closely and lower the days of inventory on hand.

[0001628280-24-038024:mdna:20]
For more information on risks associated with supply chain constraints and customer inventory, refer to Item 1A “Risk Factors” of this Annual Report.

[0001628280-24-038024:mdna:21]
Critical Accounting Policies and Estimates

[0001628280-24-038024:mdna:22]
Our consolidated financial statements are prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) as set forth in the Financial Accounting Standards Board’s Accounting Standards Codification (“ASC”). We also consider the various staff accounting bulletins and other applicable guidance issued by the United States Securities and Exchange Commission (“SEC”). GAAP, as set forth within the ASC, requires us to make certain estimates, judgments and assumptions. We believe that the estimates, judgments and assumptions upon which we rely are reasonable based upon information available to us at the time that we make these estimates, judgments and assumptions. These estimates, judgments and assumptions can affect the reported amounts of assets and liabilities as of the date of the financial statements as well as the reported amounts of revenues and expenses during the periods presented. To the extent there are differences between these estimates, judgments or assumptions and actual results, these difference will affect our financial statements. The accounting policies that reflect our more significant estimates, judgments and assumptions and which we believe are the most critical to aid in fully understanding and evaluating our reported financial results include the following:

[0001628280-24-038024:mdna:23]
•Inventory Valuation

[0001628280-24-038024:mdna:24]
•Revenue Recognition

[0001628280-24-038024:mdna:25]
•Income Taxes

[0001628280-24-038024:mdna:26]
•Business Combinations

[0001628280-24-038024:mdna:27]
•Goodwill and Intangible Assets - Impairment Assessment

[0001628280-24-038024:mdna:28]
Inventory Valuation

[0001628280-24-038024:mdna:29]
Our inventories are recorded at standard cost, which approximates actual cost computed on a first-in, first-out basis, not in excess of net realizable value. We assess the value of our inventories on a quarterly basis and write down those inventories which are obsolete or in excess of our forecasted demand to the lower of their cost or estimated net realizable value.

[0001628280-24-038024:mdna:30]
Our estimates of forecasted demand are based upon our analysis and assumptions including, but not limited to, expected product lifecycles, product development plans and historical usage by product. Our product line management personnel play a key role in our excess review process by providing updated sales forecasts, managing product transitions and working with manufacturing to minimize excess inventory. If actual market conditions are less favorable than our forecasts, or actual demand from our customers is lower than our estimates, we may be required to record additional inventory write-downs. If actual market conditions are more favorable than anticipated, inventories previously written down may be sold, resulting in lower cost of sales and higher income from operations than expected in that period.

[0001628280-24-038024:mdna:31]
Our inventories are sensitive to technical obsolescence in the near term due to the use in industries characterized by the continuous introduction of new product lines, rapid technological advances, and product obsolescence. Based on certain assumptions and judgments made from the information available at that time, we determine the amount of allowance for potential inventory obsolescence. If these estimates and related assumptions or the market changes, we may be required to record additional reserves. Historically, actual results have not varied materially from our estimates.

[0001628280-24-038024:mdna:32]
Revenue Recognition

[0001628280-24-038024:mdna:33]
Pursuant to Topic 606, we recognize our revenues upon the application of the following steps:

[0001628280-24-038024:mdna:34]
•identification of the contract, or contracts, with a customer;

[0001628280-24-038024:mdna:35]
•identification of the performance obligations in the contract;

[0001628280-24-038024:mdna:36]
•determination of the transaction price;

[0001628280-24-038024:mdna:37]
•allocation of the transaction price to the performance obligations in the contract; and

[0001628280-24-038024:mdna:38]
•recognition of revenues when, or as, the contractual performance obligations are satisfied.

[0001628280-24-038024:mdna:39]
The majority of our revenue comes from product sales, consisting of sales of hardware products to our customers. Our revenue contracts generally include only one performance obligation. Revenues are recognized at a point in time when control of the promised goods or services are transferred to our customers upon shipment or delivery of goods or rendering of services, in an amount that reflects the consideration we expect to be entitled to in exchange for those goods or services. We have entered into vendor managed inventory (“VMI”) programs with our customers. Under these arrangements, we receive purchase orders from our customers, and the inventory is shipped to the VMI location upon receipt of the purchase order. The customer then pulls the inventory from the VMI hub based on its production needs. Revenue under VMI programs is recognized when control transfers to the customer, which is generally once the customer pulls the inventory from the hub.

[0001628280-24-038024:mdna:40]
Revenue from all sales types is recognized at the transaction price. The transaction price is determined based on the consideration to which we will be entitled in exchange for transferring goods or services to the customer adjusted for estimated variable consideration, if any. We typically estimate the impact on the transaction price for discounts offered to the customers for early payments on receivables or net of accruals for estimated sales returns. These estimates are based on historical returns, analysis of credit memo data and other known factors. Actual returns could differ from these estimates. We allocate the transaction price to each distinct product based on its relative standalone selling price. The product price as specified on the purchase order is considered the standalone selling price as it is an observable input that depicts the price as if sold to a similar customer in similar circumstances.

[0001628280-24-038024:mdna:41]
We exclude from revenue the taxes assessed by a governmental authority that are both imposed on and concurrent with a specific revenue-producing transaction, which are collected by us from a customer and deposited with the relevant government authority.

[0001628280-24-038024:mdna:42]
Our revenue arrangements do not contain significant financing components as our standard payment terms are less than one year.

[0001628280-24-038024:mdna:43]
If a customer pays consideration, or we have a right to an amount of consideration that is unconditional before we transfer a good or service to the customer, those amounts are classified as deferred revenue or deposits received from customers which are included in other current liabilities or other long-term liabilities when the payment is made or it is due, whichever is earlier.

[0001628280-24-038024:mdna:44]
Transaction Price Allocated to the Remaining Performance Obligations

[0001628280-24-038024:mdna:45]
Remaining performance obligations represent the transaction price allocated to performances obligations that are unsatisfied or partially unsatisfied as of the end of the reporting period. Unsatisfied and partially unsatisfied performance obligations consist of contract liabilities and non-cancellable backlog. Non-cancellable backlog includes goods and services for which customer purchase orders have been accepted that are scheduled or in the process of being scheduled for shipment. A portion of our revenue arises from vendor managed inventory arrangements where the timing and volume of customer utilization is difficult to predict.

[0001628280-24-038024:mdna:46]
Warranty

[0001628280-24-038024:mdna:47]
Hardware products regularly include warranties to the end customers such that the product continues to function according to published specifications. We typically offer a twelve-month warranty for most of our products. However, in some instances depending upon the product, specific market, product line and geography in which we operate, and what is common in the industry, our warranties can vary and range from six months to five years. These standard warranties are assurance type warranties and do not offer any services in addition to the assurance that the product will continue working as specified. Therefore, warranties are not considered separate performance obligations in the arrangement.

[0001628280-24-038024:mdna:48]
We provide reserves for the estimated costs of product warranties that we record as cost of sales at the time revenue is recognized. We estimate the costs of our warranty obligations based on our historical experience of known product failure rates, use of materials to repair or replace defective products and service delivery costs incurred in correcting product failures. In addition, from time-to-time, specific warranty accruals may be made if discrete technical problems arise.

[0001628280-24-038024:mdna:49]
Shipping and Handling Costs

[0001628280-24-038024:mdna:50]
We record shipping and handling costs related to revenue transactions within cost of sales as a period cost.

[0001628280-24-038024:mdna:51]
Contract Costs

[0001628280-24-038024:mdna:52]
We recognize the incremental direct costs of obtaining a contract, which consist of sales commissions, when control over the products they relate to transfers to the customer. Applying the practical expedient, we recognize commissions as expense when incurred, as the amortization period of the commission asset we would have otherwise recognized is less than one year.

[0001628280-24-038024:mdna:53]
Contract Balances

[0001628280-24-038024:mdna:54]
We record accounts receivable when we have an unconditional right to consideration. Contract liabilities are recorded when cash payments are received or due in advance of performance. Contract liabilities consist of advance payments and deferred revenue, where we have unsatisfied performance obligations. Contract liabilities are classified as deferred revenue and customer deposits and are included in other current liabilities within our consolidated balance sheet. Payment terms vary by customer. The time between invoicing and when payment is due is not significant.

[0001628280-24-038024:mdna:55]
The following table reflects the changes in contract balances as of June 29, 2024 (in millions, except percentages):

[0001628280-24-038024:mdna:56]
| Contract balances | Balance sheet location | June 29, 2024 |  | July 1, 2023 |  | Change |  | Percentage Change |
| Accounts receivable, net | Accounts receivable, net | $ | 194.7 |  |  | $ | 246.1 |  |  | $ | (51.4) |  |  | (20.9) | % |
| Deferred revenue and customer deposits | Other current liabilities | $ | 0.6 |  |  | $ | 2.1 |  |  | $ | (1.5) |  |  | (71.4) | % |

[0001628280-24-038024:mdna:57]
Disaggregation of Revenue

[0001628280-24-038024:mdna:58]
We disaggregate revenue by geography and by product.  Refer to “Note 18. Revenue Recognition” to the consolidated financial statements for a presentation of disaggregated revenue. We do not present other levels of disaggregation, such as by type of products, customer, markets, contracts, duration of contracts, timing of transfer of control and sales channels, as this information is not used by our Chief Operating Decision Maker (“CODM”) to manage the business.

[0001628280-24-038024:mdna:59]
Income Taxes

[0001628280-24-038024:mdna:60]
In accordance with the authoritative guidance on accounting for income taxes, we recognize income taxes using an asset and liability approach. This approach requires the recognition of taxes payable or refundable for the current year and deferred tax liabilities and assets for the future tax consequences of events that have been recognized in our consolidated financial statements or tax returns. The measurement of current and deferred taxes is based on provisions of the enacted tax law, and the effects of future changes in tax laws or rates are not anticipated.

[0001628280-24-038024:mdna:61]
The authoritative guidance provides for recognition of deferred tax assets if the realization of such deferred tax assets is more likely than not to occur based on an evaluation of both positive and negative evidence and the relative weight of the evidence. We consider future growth, forecasted earnings, future taxable income, the mix of earnings in the jurisdictions in which we operate, historical earnings, taxable income in prior years, if carry-back is permitted under the law, and prudent and feasible tax planning strategies in determining the need for a valuation allowance. In the event we were to determine that we would not be able to realize all or part of our net deferred tax assets in the future, an adjustment to the deferred tax assets valuation allowance would be charged to earnings in the period in which we make such a determination, or goodwill would be adjusted at our final determination of the valuation allowance related to an acquisition within the measurement period. If we later determine that it is more likely than not that the net deferred tax assets would be realized, we would reverse the applicable portion of the previously provided valuation allowance as an adjustment to earnings at such time.

[0001628280-24-038024:mdna:62]
We are subject to income tax audits by the respective tax authorities of the jurisdictions in which we operate. The determination of our income tax liabilities in each of these jurisdictions requires the interpretation and application of complex, and sometimes uncertain, tax laws and regulations. The authoritative guidance on accounting for income taxes prescribes both recognition and measurement criteria that must be met for the benefit of a tax position to be recognized in the financial statements. If a tax position taken, or expected to be taken, in a tax return does not meet such recognition or measurement criteria, an unrecognized tax benefit liability is recorded.  If we ultimately determine that an unrecognized tax benefit liability is no longer necessary, we reverse the liability and recognize a tax benefit in the period in which it is determined that the unrecognized tax benefit liability is no longer necessary.

[0001628280-24-038024:mdna:63]
Our income tax provision is highly dependent upon the geographic distribution of our worldwide earnings or losses, tax laws and regulations in various jurisdictions, tax incentives, the availability of tax credits and loss carryforwards, and the effectiveness of our tax planning strategies. The application of tax laws and regulations is subject to legal and factual interpretation, judgment and uncertainty. Tax laws themselves are subject to change as a result of changes in fiscal policy, changes in legislation, and the evolution of regulations and court rulings and tax audits.

[0001628280-24-038024:mdna:64]
The recognition and measurement of current taxes payable or refundable and deferred tax assets and liabilities requires that we make certain estimates and judgments. Changes to these estimates or a change in judgment may have a material impact on our tax provision in a future period.

[0001628280-24-038024:mdna:65]
Business Combinations

[0001628280-24-038024:mdna:66]
In accordance with the guidance for business combinations, we determine whether a transaction or event is a business combination, which requires that the assets acquired and liabilities assumed constitute a business. Each business combination is then accounted for by applying the acquisition method. If the assets acquired are not a business, we account for the transaction or event as an asset acquisition. Under both methods, we recognize the identifiable assets acquired, the liabilities assumed, and noncontrolling interest, if any, in the acquired entity. We capitalize acquisition-related costs and fees associated with asset acquisitions and immediately expense acquisition-related costs and fees associated with business combinations.

[0001628280-24-038024:mdna:67]
We allocate the fair value of purchase consideration to assets acquired and liabilities assumed based on their estimated fair values at the acquisition date. The excess of the fair value of purchase consideration over the fair values of these identifiable assets and liabilities is recorded as goodwill. We make significant estimates and assumptions to determine assets acquired and liabilities assumed, in particular intangible assets and pre-acquisition contingencies, as applicable.

[0001628280-24-038024:mdna:68]
Critical estimates in valuing intangible assets include, but are not limited to, discount rates, the period required for customer revenues to mature, and future expected cash flows from customer relationships, acquired developed technology and acquired in-process research and development assets. Our estimates of fair value are based upon assumptions using the best information available. These assumptions are inherently uncertain and unpredictable and, as a result, actual results may differ materially from these estimates.

[0001628280-24-038024:mdna:69]
We may identify certain pre-acquisition contingencies as of the acquisition date and may extend our review and evaluation of these pre-acquisition contingencies throughout the measurement period in order to obtain sufficient information to assess whether these contingencies should be included as a part of the fair value of assets acquired and liabilities assumed and, if so, the amounts to be included.

[0001628280-24-038024:mdna:70]
Certain estimates associated with the accounting for acquisitions may change as additional information becomes available regarding the assets acquired and liabilities assumed. Any change in facts and circumstances that existed as of the acquisition date and impacts to our preliminary estimates is recorded to goodwill if identified within the measurement period. Subsequent to the measurement period or our final determination of fair value of assets and liabilities, whichever is earlier, the adjustments will affect our earnings. Although we believe that the assumptions and estimates we have made in the past have been reasonable and appropriate, they are based in part on historical experience and information obtained from the management of the acquired companies and are inherently uncertain. Unanticipated events and circumstances may occur that may affect the accuracy or validity of such assumptions, estimates or actual results.

[0001628280-24-038024:mdna:71]
Goodwill and Intangible Assets - Impairment Assessment

[0001628280-24-038024:mdna:72]
Goodwill represents the excess of the purchase price of an acquired business over the fair value of the identifiable assets acquired and liabilities assumed. We test goodwill impairment on an annual basis in the fiscal fourth quarter and at any other time when events occur or circumstances indicate that the carrying amount of goodwill may not be recoverable.

[0001628280-24-038024:mdna:73]
We have the option to first assess qualitative factors to determine whether it is necessary to perform the quantitative goodwill impairment test. The qualitative factors we assess include long-term prospects of our performance, share price trends and market capitalization, and Company specific events. Unanticipated events and circumstances may occur that affect the accuracy of our assumptions, estimates and judgments. For example, if the price of our common stock were to significantly decrease combined with other adverse changes in market conditions, thus indicating that the underlying fair value of our reporting units may have decreased, we may reassess the value of our goodwill in the period such circumstances were identified.

[0001628280-24-038024:mdna:74]
If we determine that, as a result of the qualitative assessment, it is more likely than not (i.e., greater than 50% likelihood) that the fair value of a reporting unit is less than its carrying amount, we perform the quantitative test by estimating the fair value of our reporting units. If the carrying value of a reporting unit exceeds its fair value, we record goodwill impairment loss equal to the excess of the carrying value of the reporting unit’s goodwill over its fair value, not to exceed the carrying amount of goodwill. Performing a quantitative goodwill impairment test includes the determination of the fair value of a reporting unit and involves significant estimates and assumptions. These estimates and assumptions include, among others, revenue growth rates and operating margins used to calculate projected future cash flows, risk-adjusted discount rates, future economic and market conditions, and the determination of appropriate market comparables.

[0001628280-24-038024:mdna:75]
We make judgments about the recoverability of purchased finite lived intangible assets whenever events or changes in circumstances indicate that impairment may exist. In such situations, we are required to evaluate whether the net book values of our finite lived intangible assets are recoverable. We determine whether finite lived intangible assets are recoverable based upon the forecasted future cash flows that are expected to be generated by the lowest level associated asset grouping. Assumptions and estimates about future values and remaining useful lives of our intangible assets are complex and subjective and include, among others, forecasted undiscounted cash flows to be generated by certain asset groupings. These assumptions and estimates can be affected by a variety of factors, including external factors such as industry and economic trends and internal factors such as changes in our business strategy and our internal forecasts.

[0001628280-24-038024:mdna:76]
Recently Issued Accounting Pronouncements

[0001628280-24-038024:mdna:77]
Refer to “Note 2. Recently Issued Accounting Pronouncements” to the consolidated financial statements.

[0001628280-24-038024:mdna:78]
48

[0001628280-24-038024:mdna:79]
Results of Operations

[0001628280-24-038024:mdna:80]
The results of operations for the periods presented are not necessarily indicative of results to be expected for future periods. The following table summarizes selected consolidated statements of operations items as a percentage of net revenue:

[0001628280-24-038024:mdna:81]
|  | Years Ended |
|  | June 29, 2024 |  | July 1, 2023 |  | July 2, 2022 |
| Segment net revenue: |  |  |  |  |  |
| Cloud & Networking | 79.8 | % |  | 74.8 | % |  | 58.9 | % |
| Industrial Tech | 20.2 |  |  | 25.2 |  |  | 41.1 |  |
| Net revenue | 100.0 |  |  | 100.0 |  |  | 100.0 |  |
| Cost of sales | 75.3 |  |  | 63.0 |  |  | 50.3 |  |
| Amortization of acquired developed intangibles | 6.2 |  |  | 4.8 |  |  | 3.7 |  |
| Gross profit | 18.5 |  |  | 32.2 |  |  | 46.0 |  |
| Operating expenses: |  |  |  |  |  |
| Research and development | 22.2 |  |  | 17.4 |  |  | 12.9 |  |
| Selling, general and administrative | 22.9 |  |  | 19.7 |  |  | 15.5 |  |
| Restructuring and related charges | 5.3 |  |  | 1.6 |  |  | (0.1) |  |
| Total operating expenses | 50.4 |  |  | 38.7 |  |  | 28.3 |  |
| Income (loss) from operations | (31.9) |  |  | (6.5) |  |  | 17.7 |  |
| Interest expense | (2.5) |  |  | (2.0) |  |  | (4.7) |  |
| Other income, net | 4.6 |  |  | 2.8 |  |  | 0.7 |  |
| Income (loss) before income taxes | (29.8) |  |  | (5.7) |  |  | 13.7 |  |
| Income tax provision | 10.4 |  |  | 1.7 |  |  | 2.1 |  |
| Net income (loss) | (40.2) | % |  | (7.4) | % |  | 11.6 | % |

[0001628280-24-038024:mdna:82]
Financial Data for Fiscal 2024, 2023, and 2022

[0001628280-24-038024:mdna:83]
The following table summarizes selected consolidated statements of operations items (in millions, except for percentages):

[0001628280-24-038024:mdna:84]
|  | 2024 |  | 2023 |  | Change |  | Percentage Change |  | 2023 |  | 2022 |  | Change |  | Percentage Change |
| Segment net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cloud & Networking | $ | 1,084.9 |  | $ | 1,322.5 |  | $ | (237.6) |  |  | (18.0) | % |  | $ | 1,322.5 |  | $ | 1,008.7 |  | $ | 313.8 |  |  | 31.1 | % |
| Industrial Tech | 274.3 |  | 444.5 |  | (170.2) |  |  | (38.3) |  |  | 444.5 |  | 703.9 |  | (259.4) |  |  | (36.9) |  |
| Net revenue | $ | 1,359.2 |  | $ | 1,767.0 |  | $ | (407.8) |  |  | (23.1) | % |  | $ | 1,767.0 |  | $ | 1,712.6 |  | $ | 54.4 |  |  | 3.2 | % |
| Gross profit | $ | 251.5 |  | $ | 569.0 |  | $ | (317.5) |  |  | (55.8) | % |  | $ | 569.0 |  | $ | 788.6 |  | $ | (219.6) |  |  | (27.8) | % |
| Gross margin | 18.5 | % |  | 32.2 | % |  |  |  |  |  | 32.2 | % |  | 46.0 | % |  |  |  |  |
| Research and development | $ | 302.2 |  | $ | 307.8 |  | $ | (5.6) |  | (1.8) | % |  | $ | 307.8 |  | $ | 220.7 |  | $ | 87.1 |  |  | 39.5 | % |
| Percentage of net revenue | 22.2 | % |  | 17.4 | % |  |  |  |  |  | 17.4 | % |  | 12.9 | % |  |  |  |  |
| Selling, general and administrative | $ | 310.7 |  | $ | 348.8 |  | $ | (38.1) |  |  | (10.9) | % |  | $ | 348.8 |  | $ | 265.7 |  | $ | 83.1 |  |  | 31.3 | % |
| Percentage of net revenue | 22.9 | % |  | 19.7 | % |  |  |  |  |  | 19.7 | % |  | 15.5 | % |  |  |  |  |
| Restructuring and related charges | $ | 72.6 |  | $ | 28.1 |  | $ | 44.5 |  |  | 158.4 | % |  | $ | 28.1 |  | $ | (1.1) |  | $ | 29.2 |  |  | n/a |
| Percentage of net revenue | 5.3 | % |  | 1.6 | % |  |  |  |  |  | 1.6 | % |  | (0.1) | % |  |  |  |  |

[0001628280-24-038024:mdna:85]
Net Revenue

[0001628280-24-038024:mdna:86]
Net revenue decreased by $407.8 million, or 23.1%, during fiscal 2024 as compared to fiscal 2023, due to a $237.6 million decrease in Cloud & Networking revenue and a $170.2 million decrease in Industrial Tech revenue.

[0001628280-24-038024:mdna:87]
The decrease in Cloud & Networking net revenue is primarily due to reduction in shipment primarily driven by U.S. export restrictions and reduction in demand associated with a build-up of inventory and resulting inventory management actions by our customers, offset by $199.5 million of revenue generated by Cloud Light. The decrease in Industrial Tech net revenue is primarily due to higher market competition, which reflects share normalization in the market, as well as reduction in demand associated with a build-up of inventory and resulting inventory management actions by our customers.

[0001628280-24-038024:mdna:88]
Net revenue increased by $54.4 million, or 3.2%, during fiscal 2023 as compared to fiscal 2022 due to a $313.8 million increase in Cloud & Networking revenue offset by a $259.4 million decrease in Industrial Tech revenue.

[0001628280-24-038024:mdna:89]
Cloud & Networking increased by $313.8 million during fiscal 2023 primarily due to $340.4 million of revenue attributable to the NeoPhotonics acquisition. Additionally, the supply chain shortage in fiscal 2022 was partially relieved, allowing us to meet more customer demand during fiscal 2023. The increase was offset by a $67.8 million decrease in revenue due to reduction in demand associated with inventory management and build-up at our customers and slowing of cloud data center customer capital spending. Industrial Tech decreased by $259.4 million primarily due to a $274.9 million decrease in imaging and sensing revenue driven by higher market competition and share normalization in the market, offset by a $15.1 million increase in industrial lasers revenue primarily due to a return in customer demand for our ultrafast and kilowatt class fiber lasers following a recovery in industrial production earlier in fiscal 2023 .

[0001628280-24-038024:mdna:90]
During our fiscal 2024, 2023 and 2022, net revenue generated from a single customer which represented 10% or greater of total net revenue is summarized as follows:

[0001628280-24-038024:mdna:91]
|  | Years Ended |
|  | June 29, 2024 |  | July 1, 2023 |  | July 2, 2022 |
| Google | 18.9 | % |  | * |  | * |
| Apple | * |  | 12.1 | % |  | 28.7 | % |
| Ciena | 11.4 | % |  | 15.3 | % |  | 12.6 | % |
| Nokia | * |  | 10.5 | % |  | * |
| *Represents less than 10% of total net revenue |  |  |  |  |  |

[0001628280-24-038024:mdna:92]
Revenue by Region

[0001628280-24-038024:mdna:93]
We operate in three geographic regions: Americas, Asia-Pacific, and EMEA (Europe, Middle East, and Africa). Net revenue is assigned to the geographic region and country where our product is initially shipped to. For example, certain customers may request shipment of our product to a contract manufacturer in one country, which may differ from the location of their end customers. The following table presents net revenue by the three geographic regions we operate in and net revenue from countries that represented 10% or more of our total net revenue (in millions, except percentage data):

[0001628280-24-038024:mdna:94]
|  |  |  | Years Ended |
|  |  |  |  |  | June 29, 2024 |  | July 1, 2023 |  | July 2, 2022 |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  |  |  |  |  |  |  |  | $ | 356.1 |  |  | 26.2 | % |  | $ | 241.3 |  |  | 13.7 | % |  | $ | 173.9 |  |  | 10.2 | % |
| Mexico |  |  |  |  |  |  |  |  | 91.7 |  |  | 6.7 |  |  | 180.0 |  |  | 10.2 |  |  | 160.9 |  |  | 9.4 |  |
| Other Americas |  |  |  |  |  |  |  |  | 3.4 |  |  | 0.3 |  |  | 9.3 |  |  | 0.5 |  |  | 12.1 |  |  | 0.7 |  |
| Total Americas |  |  |  |  |  |  |  |  | $ | 451.2 |  |  | 33.2 | % |  | $ | 430.6 |  |  | 24.4 | % |  | $ | 346.9 |  |  | 20.3 | % |
| Asia-Pacific: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Thailand |  |  |  |  |  |  |  |  | $ | 183.8 |  |  | 13.5 | % |  | $ | 269.0 |  |  | 15.2 | % |  | $ | 102.3 |  |  | 5.9 | % |
| Hong Kong |  |  |  |  |  |  |  |  | 261.9 |  |  | 19.3 |  |  | 246.7 |  |  | 14.0 |  |  | 458.2 |  |  | 26.7 |  |
| South Korea |  |  |  |  |  |  |  |  | 75.2 |  |  | 5.5 |  |  | 170.2 |  |  | 9.6 |  |  | 265.2 |  |  | 15.5 |  |
| Japan |  |  |  |  |  |  |  |  | 84.6 |  |  | 6.2 |  |  | 179.5 |  |  | 10.2 |  |  | 181.2 |  |  | 10.6 |  |
| Other Asia-Pacific |  |  |  |  |  |  |  |  | 174.3 |  |  | 12.9 |  |  | 276.3 |  |  | 15.6 |  |  | 242.4 |  |  | 14.2 |  |
| Total Asia-Pacific |  |  |  |  |  |  |  |  | $ | 779.8 |  |  | 57.4 | % |  | $ | 1,141.7 |  |  | 64.6 | % |  | $ | 1,249.3 |  |  | 72.9 | % |
| EMEA |  |  |  |  |  |  |  |  | $ | 128.2 |  |  | 9.4 | % |  | $ | 194.7 |  |  | 11.0 | % |  | $ | 116.4 |  |  | 6.8 | % |
| Total net revenue |  |  |  |  |  |  |  |  | $ | 1,359.2 |  |  | 100.0% |  | $ | 1,767.0 |  |  | 100.0% |  | $ | 1,712.6 |  |  | 100.0% |

[0001628280-24-038024:mdna:95]
During fiscal 2024, 2023 and 2022, net revenue from customers outside the United States, based on customer shipping location, represented 73.8%, 86.3% and 89.8% of net revenue, respectively.

[0001628280-24-038024:mdna:96]
Our net revenue is primarily denominated in U.S. dollars, including our net revenue from customers outside the United States as presented above. We expect revenue from customers outside of the United States to continue to be an important part of our overall net revenue and a focus for net revenue growth opportunities. However, regulatory and enforcement actions by the United States and other governmental agencies, as well as changes in tax and trade policies and tariffs, have impacted and may continue to adversely impact net revenue from customers outside the United States.

[0001628280-24-038024:mdna:97]
Gross Margin

[0001628280-24-038024:mdna:98]
Gross margin in fiscal 2024 decreased to 18.5% from 32.2% in fiscal 2023. The decrease was primarily due to lower revenue, which negatively impacted gross margin by 12.9%, as well as a less profitable mix of products as a result of the acquisition of Cloud Light, which negatively impacted gross margin by 1.1%. Gross margin in fiscal 2024 was also negatively impacted by 1.4% due to higher excess capacity as a result of our manufacturing synergy plans in connection with the NeoPhotonics integration, transferring product lines out of China due to U.S. export restrictions, and a drop in demand due to customers actively working to reduce their elevated inventory levels. Additionally, in fiscal 2024 we recorded $13.3 million of higher inventory excess and obsolescence charges primarily due to U.S. export restrictions whereby we are no longer able to sell certain products to one of our customers, and customer demand changes as a result of product transitions. Furthermore, in fiscal 2024, we recorded $12.4 million of higher integration related costs.  The decrease in gross margin was partially offset by $27.6 million of lower incremental costs of sales related to components acquired from various brokers at a premium to satisfy customer demand due to supply chain constraints and $9.5 million of lower amortization of acquired inventory.

[0001628280-24-038024:mdna:99]
Gross margin in fiscal 2023 decreased to 32.2% from 46.0% in fiscal 2022. The decrease was primarily due to a less profitable mix of products, including lower sales of sales of imaging and sensing products, which negatively impacted gross margin by 4.5%, as well as higher sales of lower margin telecom products due to the NeoPhotonics acquisition, which negatively impacted gross margin by 1.3%. Additionally, gross margin was negatively impacted by factory underutilization by 1.5% as a result of a drop in demand as customers actively work to reduce their elevated inventory levels. The lower gross margin was also driven by an aggregate of $21.5 million higher amortization of intangible assets due to the acquisition of NeoPhotonics and IPG telecom transmission product lines, $18.5 million higher incremental cost of sales related to components acquired from various brokers at a premium to satisfy customer demand due to supply chain constraints, $17.8 million of amortization of acquired inventory step-up, and $17.4 million of higher inventory excess and obsolete charges primarily due to company-wide integration efforts as a result of the NeoPhotonics acquisition and transitions to the next generation of products.

[0001628280-24-038024:mdna:100]
The markets in which we sell products are undergoing product, architectural and business model transitions, have high customer concentrations, are highly competitive, are price sensitive and/or are affected by customer seasonal and have variant

[0001628280-24-038024:mdna:101]
51

[0001628280-24-038024:mdna:102]
buying patterns. We expect these factors to result in variability of our gross margin, and our gross margins may be subject to increasing downward pressure due to these factors.

[0001628280-24-038024:mdna:103]
Segment Profit

[0001628280-24-038024:mdna:104]
|  | Years Ended |
|  | June 29, 2024 |  | July 1, 2023 |  | July 2, 2022 |
| Cloud & Networking | $ | 124.5 |  |  | $ | 313.2 |  |  | $ | 266.9 |  |
| Industrial Tech | 25.1 |  |  | 152.7 |  |  | 373.5 |  |

[0001628280-24-038024:mdna:105]
Cloud & Networking segment profit decreased by $188.7 million, or 60.2%, during fiscal 2024 as compared to fiscal 2023 primarily due to lower segment revenue and lower sales from telecom products, which negatively impacted segment profit by $215.4 million, offset by $23.2 million of segment profit from Cloud Light. Industrial Tech segment profit decreased by $127.6 million or 83.6%, during fiscal 2024 as compared to fiscal 2023 primarily due to lower segment revenue and a less profitable mix of products, including lower sales of higher margin imaging and sensing products due to increasing competition and share normalization, which negatively impacted segment profit by $76.3 million.

[0001628280-24-038024:mdna:106]
Cloud & Networking segment profit increased by $46.3 million, or 17.3%, during fiscal 2023 as compared to fiscal 2022 primarily due to higher sales from telecom products, which favorably impacted segment profit by $122.1 million, offset by lower sales from datacom products which negatively impacted segment profit by $75.8 million. Industrial Tech segment profit decreased by $220.8 million, or 59.1%, during fiscal 2023 as compared to fiscal 2022 primarily due to lower segment revenue and a less profitable mix of products, including lower sales of higher margin imaging and sensing products due to increasing competition and share normalization, which negatively impacted segment profit by $215.3 million.

[0001628280-24-038024:mdna:107]
Research and Development (“R&D”)

[0001628280-24-038024:mdna:108]
R&D expense decreased by $5.6 million, or 1.8%, in fiscal 2024 as compared to fiscal 2023. The decrease in R&D expense is primarily due to a charge of $12.9 million recorded during fiscal 2023 related to a write-off of in-process research and development intangible assets acquired from NeoPhotonics for projects that we subsequently decided not to pursue, offset by $8.6 million of higher spending primarily as a result of our acquisition of Cloud Light  during fiscal 2024.

[0001628280-24-038024:mdna:109]
R&D expense increased by $87.1 million, or 39.5%, in fiscal 2023 as compared to fiscal 2022. The increase in R&D expense is attributable to an increase in payroll and employee compensation related expenses due to additional headcount from the acquisition of NeoPhotonics and IPG telecom transmission product lines. In addition, we recognized a charge of $12.9 million during fiscal 2023 related to a write-off of in-process research and development intangible assets acquired from NeoPhotonics for projects that we subsequently decided not to pursue.

[0001628280-24-038024:mdna:110]
We believe that continuing our investments in R&D is critical to attaining our strategic objectives. Despite signs of a weaker macroeconomic environment, we plan to continue to invest in R&D and new products that we believe will further differentiate us in the marketplace.

[0001628280-24-038024:mdna:111]
Selling, General and Administrative (“SG&A”)

[0001628280-24-038024:mdna:112]
SG&A expense decreased by $38.1 million, or 10.9%, during fiscal 2024 as compared to fiscal 2023. The decrease in SG&A expense in fiscal 2024 was primarily driven by the overall reduction in payroll and employee compensation related expenses as a result of recent restructuring actions, $15.2 million of lower outside consultant costs as a result of business and system integrations efforts, $17.9 million of lower stock-based compensation primarily due to $11.9 million expense recognized in fiscal 2023 related to the accelerated awards as part of NeoPhotonics acquisition, and $7.8 million of expense with respect to the settlement of certain non-ordinary course litigation matters in fiscal 2023, offset by $21.9 million of incremental amortization of intangible assets associated with the Cloud Light acquisition.

[0001628280-24-038024:mdna:113]
SG&A expense increased by $83.1 million, or 31.3%, in fiscal 2023 as compared to fiscal 2022. The increase in SG&A expense was primarily driven by an increase in payroll and employee compensation related expenses due to additional headcount from the NeoPhotonics acquisition and higher stock-based compensation. The increase was also attributable to incremental facility costs and $20.7 million of incremental amortization of intangibles due to the acquisition of NeoPhotonics and IPG telecom transmission product lines. Additionally, in connection with the NeoPhotonics acquisition, certain equity awards for NeoPhotonics employees were accelerated. We recognized $11.9 million of stock-based compensation associated with the acceleration during the first quarter of fiscal year 2023. We also recognized $11.5 million of acquisition related costs, primarily professional service fees and retention expenses related to the acquisitions of NeoPhotonics and IPG telecom transmission product lines. Furthermore, we recognized $7.8 million of expense with respect to the pending settlement of certain non-ordinary course litigation matters.  For a description of our material pending legal proceedings, refer to “Note 16.

[0001628280-24-038024:mdna:114]
Commitments and Contingencies” to the consolidated financial statements.

[0001628280-24-038024:mdna:115]
From time-to-time, we incur expenses that are not part of our ordinary operations, such as mergers and acquisition-related and litigation expenses, which generally increase our SG&A expenses and potentially impact our profitability expectations in any particular period.

[0001628280-24-038024:mdna:116]
Restructuring and Related Charges

[0001628280-24-038024:mdna:117]
We have initiated various strategic restructuring events primarily intended to reduce costs, consolidate our operations, rationalize the manufacturing of our products and align our business in response to market conditions. We also took certain actions in connection with the integration of NeoPhotonics.

[0001628280-24-038024:mdna:118]
During fiscal 2024, we recorded restructuring and related charges of $72.6 million. We discontinued our in-house development of coherent DSPs and RFICs. As a result, we recorded $35.8 million of restructuring and related charges during the fiscal fourth quarter of 2024, which includes $29.1 million write-off of in-process research and development (“IPR&D) assets, as well as $6.7 million of contract exit costs and asset write-off. The remaining $36.8 million of restructuring and related charges are primarily due to company-wide cost reduction initiatives, as well as our integration efforts to consolidate our manufacturing sites. We have shut down our factories in China which were acquired as part of the NeoPhotonics acquisition and are ramping up production of most of the related products at our Thailand facility. We are also executing our plans to optimize our wafer fabrication facilities in Japan.

[0001628280-24-038024:mdna:119]
During fiscal 2023, we recorded restructuring and related charges of $28.1 million, which were primarily attributable to company-wide integration efforts as a result of the NeoPhotonics acquisition, our cost reduction initiatives, as well as severance and employee-related benefits associated with NeoPhotonics’ executive severance and retention agreements. These agreements provided for payments and benefits upon an involuntary termination of employment under certain circumstances.

[0001628280-24-038024:mdna:120]
During fiscal 2022, we recorded a net reversal to our restructuring and related charges of $1.1 million, which was attributable to lower than anticipated employee severance charges primarily as a result of retaining and re-assigning certain employees.

[0001628280-24-038024:mdna:121]
Refer to “Note 12. Restructuring and Related Charges” to the consolidated financial statements.

[0001628280-24-038024:mdna:122]
Interest Expense

[0001628280-24-038024:mdna:123]
Our interest expense is as follows for the years presented (in millions):

[0001628280-24-038024:mdna:124]
|  |  |  | Years Ended |
|  |  |  | June 29, 2024 |  | July 1, 2023 |  | July 2, 2022 |
| Interest expense |  |  | $ | 33.8 |  |  | $ | 35.5 |  |  | $ | 80.2 |  |

[0001628280-24-038024:mdna:125]
Interest expense is driven by the amortization of the debt discount and issuance costs of our convertible notes.

[0001628280-24-038024:mdna:126]
Interest expense in fiscal 2024 decreased by $1.7 million, or 4.8%, from fiscal 2023, primarily due to the repayment of our 2024 Notes (as defined below) in March 2024 upon maturity, partially offset by incremental interest expense from our 2029 Notes (as defined below) issued in June 2023.

[0001628280-24-038024:mdna:127]
Interest expense in fiscal 2023 decreased by $44.7 million, or 55.7%, from fiscal 2022, primarily due to the adoption of ASU 2020-06 in our first quarter of fiscal 2023, which requires us to record each of our 2026 Notes and 2028 Notes as a single liability, measured at amortized cost, eliminating the interest expense associated with the debt discount.

[0001628280-24-038024:mdna:128]
Other Income, Net

[0001628280-24-038024:mdna:129]
The components of other income, net are as follows for the years presented (in millions):

[0001628280-24-038024:mdna:130]
|  |  |  | Years Ended |  |
|  |  |  | June 29, 2024 |  | July 1, 2023 |  | July 2, 2022 |  |
| Foreign exchange gains, net |  |  | $ | 0.8 |  |  | $ | 7.0 |  |  | $ | 6.1 |  |  |
| Interest and investment income |  |  | 61.3 |  |  | 40.8 |  |  | 6.1 |  |  |
| Other income (expense), net |  |  | — |  |  | 1.0 |  |  | (0.2) |  |  |
| Other income, net |  |  | $ | 62.1 |  |  | $ | 48.8 |  |  | $ | 12.0 |  |  |

[0001628280-24-038024:mdna:131]
Other income, net in fiscal 2024 increased by $13.3 million from fiscal 2023 primarily due to $20.5 million of increase in interest and investment income driven by an increase in interest rates on our fixed income securities, offset by $6.2 million of lower foreign exchange gains, reflecting a more stable U.S. dollar. In fiscal 2023 the U.S. dollar strengthened significantly against several currencies including the Japanese Yen.

[0001628280-24-038024:mdna:132]
Other income, net in fiscal 2023 increased by $36.8 million from fiscal 2022 primarily due to $34.7 million of increase in interest and investment income driven by an increase in interest rates on our fixed income securities and $0.9 million of increase in net foreign exchange gain as a result of the strengthening of the U.S. dollar relative to most foreign currencies. Additionally, concurrent with the issuance of the 2029 Notes, we used $132.8 million of the net proceeds to repurchase $125.0 million aggregate principal amount of the 2024 Notes. We recognized a gain of $1.0 million related to the repurchase, which was recorded under other income, net in fiscal 2023.

[0001628280-24-038024:mdna:133]
Provision for Income Taxes

[0001628280-24-038024:mdna:134]
|  |  | Years Ended |
| (in millions) |  | June 29, 2024 |  | July 1, 2023 |  | July 2, 2022 |
| Income tax provision |  | $ | 140.8 |  |  | $ | 29.2 |  |  | $ | 36.2 |  |

[0001628280-24-038024:mdna:135]
Our provision for income taxes for fiscal 2024 differs from the 21% U.S. statutory rate primarily due to the income tax expense from current valuation allowance change as it is not more-likely-than-not that certain deferred tax assets will be realizable in the future, earnings of our foreign subsidiaries being taxed at rates that differ from the U.S. statutory rate and non-deductible stock-based compensation. Additionally, our provision for income taxes includes changes in unrecognized tax benefits offset by income tax benefits from tax rate changes.

[0001628280-24-038024:mdna:136]
Our  provision for income taxes for  fiscal 2023 differs from the 21% U.S. statutory rate primarily due to the income tax expense from foreign income inclusions in the U.S., earnings of our foreign subsidiaries being taxed at rates that differ from the U.S. statutory rate and non-deductible stock-based compensation. Additionally, our provision for income taxes includes income tax benefits from various tax credits and change in valuation allowance as it is more-likely-than-not that certain deferred tax assets will be realizable in the future. During fiscal 2023, we also effectuated certain tax planning actions which reduced the amount of Base Erosion Anti-Abuse Tax (BEAT) for fiscal 2022.

[0001628280-24-038024:mdna:137]
Our provision for income taxes for fiscal 2022 differs from the 21% U.S. statutory rate primarily due to the income tax benefit from earnings of our foreign subsidiaries being taxed at rates that differ from the U.S. statutory rate, offset by the tax expense from foreign income inclusions in the U.S. Additionally, our provision for income taxes includes income tax benefits from various tax credits, offset by an income tax expense from non-deductible stock-based compensation and change in valuation allowance as it is not more-likely-than-not that certain deferred tax assets will be realizable in the future.

[0001628280-24-038024:mdna:138]
Our provision for incomes taxes may be impacted by changes in the geographic mix of earnings, acquisitions, changes in the realizability of deferred tax assets, changes in our uncertain tax positions, the results of income tax audits, settlements with tax authorities, the expiration of statutes of limitations, the implementation of tax planning strategies, tax rulings, court decisions, and changes in tax laws and regulations.  It is also possible that significant negative or positive evidence may become available that causes us to change our conclusion regarding whether a valuation allowance is needed on certain of our deferred tax assets, which would affect our income tax provision in the period of such change.

[0001628280-24-038024:mdna:139]
We also evaluate changes to regulations and requirements in the international jurisdictions where we conduct our business. For additional information, refer to Part II Item 1A “Risk Factors”.

[0001628280-24-038024:mdna:140]
Defined Benefit Plans

[0001628280-24-038024:mdna:141]
The Company sponsors defined benefit pension plans covering employees in Japan, Switzerland, and Thailand. Pension plan benefits are based primarily on participants’ compensation and years of service credited as specified under the terms of each country’s plan. Employees are entitled to a lump sum benefit upon retirement or upon certain instances of termination.  The funding policy is consistent with the local requirements of each country. As of June 29, 2024, the defined benefit plans in Switzerland were partially funded, while defined benefit plans in Japan and Thailand were unfunded. As of June 29, 2024, our projected benefit obligations, net, in Japan, Switzerland, and Thailand were $3.6 million, $2.4 million and $3.6 million, respectively. They were recorded in our consolidated balance sheets as accrued payroll and related expenses for the current portion while other non-current liabilities for the non-current portion, and represent the total projected benefit obligation (“PBO”) less the fair value of plan assets.

[0001628280-24-038024:mdna:142]
A key actuarial assumption in calculating the net periodic cost and the PBO is the discount rate. Changes in the discount rate impact the interest cost component of the net periodic benefit cost calculation and PBO due to the fact that the PBO is calculated on a net present value basis. Decreases in the discount rate will generally increase pre-tax cost, recognized expense and the PBO. Increases in the discount rate tend to have the opposite effect. We estimate a 100 basis point decrease or increase in the discount rate would cause a corresponding increase or decrease of $4.0 million or $3.1 million, respectively, in the PBO based upon data as of June 29, 2024.

[0001628280-24-038024:mdna:143]
We expect to contribute $1.6 million to our defined benefit pension plans in fiscal 2025.

[0001628280-24-038024:mdna:144]
Financial Condition

[0001628280-24-038024:mdna:145]
Liquidity and Capital Resources

[0001628280-24-038024:mdna:146]
As of June 29, 2024 and July 1, 2023, our cash and cash equivalents were $436.7 million and $859.0 million, respectively. As of June 29, 2024 and July 1, 2023, our short-term investments of $450.3 million and $1,154.6 million, respectively, were all held in the United States. Cash equivalents and short-term investments are primarily comprised of money market funds, treasuries, agencies, high quality investment grade fixed income securities, certificates of deposit, and commercial paper. Our investment policy and strategy is focused on the preservation of capital and supporting our liquidity requirements.

[0001628280-24-038024:mdna:147]
The total amount of cash outside the United States held by the non-U.S. entities as of June 29, 2024 and July 1, 2023 was $306.9 million and $298.4 million, respectively, which was primarily held by entities incorporated in the United Kingdom, the British Virgin Islands, Japan, Hong Kong, China, Switzerland, the Cayman Islands, Thailand and Brazil. Although cash currently held in the United States, as well as cash generated in the United States from future operations, is expected to cover our normal operating requirements, a substantial amount of additional cash could be required for other purposes, such as capital expenditures to support our business and growth, including costs associated with increasing internal manufacturing capabilities, strategic transactions and partnerships, and future acquisitions.

[0001628280-24-038024:mdna:148]
Our intent is to indefinitely reinvest funds held outside the United States and, except for the funds held in the Cayman Islands, the British Virgin Islands, and Hong Kong, as well as certain subsidiaries in China and Japan, our current plans do not demonstrate a need to repatriate them to fund our domestic operations. However, if in the future, we encounter a significant need for liquidity domestically or at a particular location that we cannot fulfill through borrowings, equity offerings, or other internal or external sources, or the cost to bring back the money is not significant from a tax perspective, we may determine that cash repatriations are necessary or desirable. Repatriation could result in additional material taxes. These factors may cause us to have an overall tax rate higher than other companies or higher than our tax rates in the past. Additionally, if conditions warrant, we may seek to obtain additional financing through debt or equity sources. To the extent we issue additional shares, it may create dilution to our existing stockholders. However, any such financing may not be available on terms favorable to us or may not be available at all.

[0001628280-24-038024:mdna:149]
Beginning in fiscal 2023, the Tax Cuts and Jobs Act of 2017 requires taxpayers to capitalize research and development expenditures and amortize domestic expenditures over five years and foreign expenditures over fifteen years. This will delay deductibility of these expenses and potentially increase the amount of cash taxes we pay in the next several years.

[0001628280-24-038024:mdna:150]
Indebtedness

[0001628280-24-038024:mdna:151]
As of June 29, 2024, the net carrying amount of our 2029 Notes (as defined below) of $599.4 million, which have an aggregate principal balance of $603.7 million maturing in 2029, is presented in non-current liabilities in our condensed consolidated balance sheets. If the closing price of our stock exceeds $90.40 (130% of the conversion price of $69.54) for 20 of the last 30 trading days of any future quarter, the 2029 Notes would become convertible at the option of the holders during the subsequent fiscal quarter and the debt component would be reclassified to current liabilities.

[0001628280-24-038024:mdna:152]
As of June 29, 2024, the net carrying amount of our 2028 Notes (as defined below) of $856.6 million, which have an aggregate principal balance of $861.0 million maturing in 2028, is presented in non-current liabilities in our condensed consolidated balance sheets. If the closing price of our stock exceeds $170.34 (130% of the conversion price of $131.03) for 20 of the last 30 trading days of any future fiscal quarter, our 2028 Notes would become convertible at the option of the holders during the subsequent fiscal quarter and the debt component would be reclassified to current liabilities.

[0001628280-24-038024:mdna:153]
As of June 29, 2024, the net carrying amount of our 2026 Notes (as defined below) of $1,047.2 million, which have an aggregate principal balance of $1,050.0 maturing in 2026, is presented in non-current liabilities in our condensed consolidated balance sheets. If the closing price of our stock exceeds $129.08 (130% of the conversion price of $99.29) for 20 of the last 30 trading days of any future fiscal quarter, our 2026 Notes would become convertible at the option of the holders during the subsequent fiscal quarter and the debt component would be reclassified to current liabilities.

[0001628280-24-038024:mdna:154]
On March 15, 2024, our 0.25% Convertible Senior Notes due 2024 (the “2024 Notes”) reached maturity. We fully repaid the remaining principal amount of $323.1 million at the maturity date.

[0001628280-24-038024:mdna:155]
Refer to “Note 10. Debt” to the consolidated financial statements for more information.

[0001628280-24-038024:mdna:156]
Share Repurchases

[0001628280-24-038024:mdna:157]
Repurchase Made in Connection with Convertible Note Offering

[0001628280-24-038024:mdna:158]
In fiscal 2023, concurrent with the issuance of the 2029 Notes, we repurchased 2.3 million shares of our common stock in privately negotiated transactions at an average price of $53.49 per share for an aggregate purchase price of $125.0 million. We recorded the aggregate purchase price as a reduction of retained earnings within our consolidated balance sheet.  These shares were retired immediately.

[0001628280-24-038024:mdna:159]
In fiscal 2022, concurrent with the issuance of the 2028 Notes, we repurchased 2.0 million shares of our common stock in privately negotiated transactions at an average price of $99.0 per share for an aggregate purchase price of approximately $200.0 million. We recorded the aggregate purchase price as a reduction of retained earnings within our consolidated balance sheet and retired these shares immediately.

[0001628280-24-038024:mdna:160]
Share Buyback Program

[0001628280-24-038024:mdna:161]
We have a share buyback program that authorizes us to utilize up to an aggregate amount of $1.2 billion to purchase shares of our common stock through May 2025. During fiscal 2024, we did not repurchase any of our common stock. During fiscal 2023, we repurchased 0.7 million shares of our common stock as part of the share buyback program at an average price of $65.03 per share for an aggregate purchase price of $40.5 million.  During fiscal 2022, we repurchased 4.0 million shares of our common stock as part of the share buyback program at an average price of $87.21 per share for an aggregate purchase price of $348.9 million.

[0001628280-24-038024:mdna:162]
Since the board of directors initially approved the share buyback program, we have repurchased 7.7 million shares in aggregate at an average price of $81.66 per share for a total purchase price of $630.4 million. We recorded the $630.4 million aggregate purchase price as a reduction of retained earnings within our condensed consolidated balance sheet. All repurchased shares were retired immediately. As of June 29, 2024, we have $569.6 million remaining under the share buyback program.

[0001628280-24-038024:mdna:163]
The price, timing, amount, and method of future repurchases will be determined based on the evaluation of market conditions and other factors, at prices determined to be in the best interests of the Company and our stockholders. The stock buyback program may be suspended or terminated at any time.

[0001628280-24-038024:mdna:164]
Contractual Obligations

[0001628280-24-038024:mdna:165]
The following table summarizes our contractual obligations as of June 29, 2024, and the effect such obligations are expected to have on our liquidity and cash flow (in millions):

[0001628280-24-038024:mdna:166]
|  | Payments due |
|  | Total |  | Less than 1 year |  | More than 1 year |
| Contractual Obligations |  |  |  |  |  |
| Asset retirement obligations | $ | 7.5 |  |  | $ | 0.3 |  |  | $ | 7.2 |  |
| Operating lease liabilities, including imputed interest (1) | 61.8 |  |  | 15.3 |  |  | 46.5 |  |
| Pension plan contributions (2) | 1.6 |  |  | $ | 1.6 |  |  | — |  |
| Purchase obligations (3) | 475.1 |  |  | 418.0 |  |  | 57.1 |  |
| Convertible notes - principal (4) | 2,514.7 |  |  | — |  |  | 2,514.7 |  |
| Convertible notes - interest (4) | 80.1 |  |  | 18.7 |  |  | 61.4 |  |
| Total | $ | 3,140.8 |  |  | $ | 453.9 |  |  | $ | 2,686.9 |  |

[0001628280-24-038024:mdna:167]
(1) The amounts of operating lease liabilities do not include any sublease income amounts nor do they include payments for short-term leases or variable lease payments. As of June 29, 2024, we expect to receive sublease income of approximately $0.8 million over the next year. Refer to “Note 8. Leases” to the consolidated financial statements.

[0001628280-24-038024:mdna:168]
In July 2024, we purchased the land and building of our wafer fabrication facility located in Sagamihara, Japan for a total transaction price of $46.5 million including related fees and refundable consumption taxes. Our lease of the building at the premises, which was originally scheduled to end in March 2033, was terminated as a result of the purchase. We derecognized the related right-of-use assets of $31.9 million and lease liability of $17.4 million at the purchase completion date. Refer to “Note 19. Subsequent Events” to the consolidated financial statements.

[0001628280-24-038024:mdna:169]
(2) The amount of pension plan contributions represents planned contributions to our defined benefit plans. Although additional future contributions will be required, the amount and timing of these contributions will be affected by actuarial assumptions, the actual rate of returns on plan assets, the level of market interest rates, legislative changes, and the amount of voluntary contributions to the plan. Any contributions for the following fiscal year and later will depend on the value of the plan assets in the future and thus are uncertain. As such, we have not included any amounts beyond one year in the table above.  Refer to “Note 15. Employee Retirement Plans” to the consolidated financial statements.

[0001628280-24-038024:mdna:170]
(3) Purchase obligations represent legally binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Refer to “Note 16. Commitments and Contingencies” to the consolidated financial statements.

[0001628280-24-038024:mdna:171]
(4) The amounts related to convertible notes include principal and interest on our 0.50% Convertible Senior Notes due 2026 (the “2026 Notes”), principal and interest on our 0.50% Convertible Senior Notes due 2028 (the “2028 Notes”), and principal and interest on our 1.50% Convertible Senior Notes due 2029 (the “2029 Notes”). The 2026 Notes have a maturity date of December 15, 2026, the 2028 Notes have a maturity date of June 15, 2028, and the 2029 Notes have a maturity date of December 15, 2029. The principal balances of our convertible notes are reflected in the payment periods in the table above based on their respective contractual maturities assuming no conversions. On March 15, 2024, the maturity date of the 2024 Notes, we repaid the outstanding $323.1 million principal amount of the 2024 Notes in full. Refer to “Note 10. Debt” to the consolidated financial statements.

[0001628280-24-038024:mdna:172]
We do not have any off-balance sheet arrangements, as such term is defined in rules promulgated by the SEC, which have or are reasonably likely to have a current or future effect on our liquidity or capital resources that are material to investors.

[0001628280-24-038024:mdna:173]
Unrecognized Tax Benefits

[0001628280-24-038024:mdna:174]
As of June 29, 2024, our other non-current liabilities also include $83.0 million of unrecognized tax benefit for uncertain tax positions. We are unable to reliably estimate the timing of future payments related to uncertain tax positions.

[0001628280-24-038024:mdna:175]
Liquidity and Capital Resources Requirements

[0001628280-24-038024:mdna:176]
We believe that our cash and cash equivalents as of June 29, 2024, and cash flows from our operating activities will be sufficient to meet our liquidity and capital spending requirements for at least the next 12 months.

[0001628280-24-038024:mdna:177]
There are a number of factors that could positively or negatively impact our liquidity position, including:

[0001628280-24-038024:mdna:178]
•global economic conditions which affect demand for our products and services and impact the financial stability of our suppliers and customers, including the impact of uncertainty in the banking and financial services industries;

[0001628280-24-038024:mdna:179]
•fluctuations in demand for our products as a result of changes in regulations, tariffs or other trade barriers, and trade relations in general;

[0001628280-24-038024:mdna:180]
•changes in accounts receivable, inventory or other operating assets and liabilities, which affect our working capital;

[0001628280-24-038024:mdna:181]
•increase in capital expenditures to support our business and growth, including increases in manufacturing capacity;

[0001628280-24-038024:mdna:182]
•the tendency of customers to delay payments or to negotiate favorable payment terms to manage their own liquidity positions;

[0001628280-24-038024:mdna:183]
•timing of payments to our suppliers;

[0001628280-24-038024:mdna:184]
•volatility in fixed income and credit, which impact the liquidity and valuation of our investment portfolios;

[0001628280-24-038024:mdna:185]
•cost and availability of credit, which may impact available financing for us, our customers or others with whom we do business;

[0001628280-24-038024:mdna:186]
•volatility in foreign exchange markets, which impacts our financial results;

[0001628280-24-038024:mdna:187]
•possible investments or acquisitions of complementary businesses, products or technologies, or other strategic transactions or partnerships;

[0001628280-24-038024:mdna:188]
•issuance of debt or equity securities, or other financing transactions, including bank debt;

[0001628280-24-038024:mdna:189]
•potential funding of pension liabilities either voluntarily or as required by law or regulation;

[0001628280-24-038024:mdna:190]
•acquisitions or strategic transactions, in particular our recently completed acquisition of Cloud Light;

[0001628280-24-038024:mdna:191]
•the settlement of any conversion or redemption of our convertible notes in cash; and

[0001628280-24-038024:mdna:192]
•common stock repurchases under the share buyback program.

[0001628280-24-038024:mdna:193]
Cash Flows

[0001628280-24-038024:mdna:194]
Fiscal 2024

[0001628280-24-038024:mdna:195]
As of June 29, 2024, our consolidated balance of cash and cash equivalents decreased by $422.3 million, to $436.7 million from $859.0 million as of July 1, 2023. The decrease in cash and cash equivalents was due to cash used in financing activities of $332.7 million and cash used in investing activities of $114.3 million, partially offset by cash provided by operating activities of $24.7 million during the year ended June 29, 2024.

[0001628280-24-038024:mdna:196]
Cash provided by operating activities was $24.7 million during the year ended June 29, 2024, which reflects the net loss of $546.5 million and non-cash items of $432.4 million, partially offset by $138.8 million of changes in our operating assets and liabilities. Changes in operating assets and liabilities were primarily driven by a decrease in accounts payable of $89.7 million primarily due to lower inventory purchases and linearity of payments and a decrease in income tax liabilities of $77.7 million primarily due annual income tax payments in Japan, offset by a decrease in inventories of $73.8 million primarily due to reduced inventory level in our Cloud & Networking business and a decrease in accounts receivable of $72.3 million due to lower revenue.

[0001628280-24-038024:mdna:197]
Cash used in investing activities of $114.3 million during the year ended June 29, 2024 was primarily attributable to the acquisition of Cloud Light in the amount of $700.9 million, net of cash acquired, capital expenditures of $133.0 million and an intangible asset acquisition of $4.0 million, offset by net proceeds from short-term investments of $722.8 million and proceeds from sales of property and equipment of $0.8 million.

[0001628280-24-038024:mdna:198]
Cash used in financing activities of $332.7 million during the year ended June 29, 2024, was attributable to $323.1 million of repayment of the principal amount of 2024 Notes upon maturity, and tax payments related to the net share settlement of restricted stock units of $24.0 million, offset by $14.4 million of proceeds from employee stock plans.

[0001628280-24-038024:mdna:199]
Fiscal 2023

[0001628280-24-038024:mdna:200]
As of July 1, 2023, our consolidated balance of cash and cash equivalents decreased by $431.2 million, to $859.0 million from $1,290.2 million as of July 2, 2022. The decrease in cash and cash equivalents was due to cash used in investing activities of $874.0 million, partially offset by cash provided by financing activities of $263.0 million and cash provided by operating activities of $179.8 million during the year ended July 1, 2023.

[0001628280-24-038024:mdna:201]
Cash provided by operating activities was $179.8 million during the year ended July 1, 2023, which reflects the net loss of $131.6 million and non-cash items of $448.0 million, partially offset by $136.6 million of changes in our operating assets and liabilities. Changes in our operating assets and liabilities is mainly driven by an increase in inventories of $81.5 million primarily related to prebuild inventory and safety stock, a decrease in accounts payable of $74.0 million due to lower purchases from our contract manufacturers and linearity of payments, offset by a decrease in accounts receivable of $83.2 million primarily due to linearity of billings and timing of payments.

[0001628280-24-038024:mdna:202]
Cash used in investing activities of $874.0 million during the year ended July 1, 2023 was primarily attributable to the acquisition of NeoPhotonics and IPG telecom transmission product lines in the amount of $861.6 million, net of cash acquired and capital expenditures of $128.5 million, partially offset by net proceeds from short-term investments of $115.7 million.

[0001628280-24-038024:mdna:203]
Cash provided by financing activities of $263.0 million during the year ended July 1, 2023, was primarily a result of proceeds from the issuance of the 2029 Notes, net of issuance costs of $599.4 million, partially offset by the repurchase of shares of our common stock of $175.6 million, repurchase of our 2024 Notes of $132.8 million and tax payments related to the net share settlement of restricted stock of $37.2 million.

[0001628280-24-038024:mdna:204]
Fiscal 2022

[0001628280-24-038024:mdna:205]
As of July 2, 2022, our consolidated balance of cash and cash equivalents increased by $515.9 million, to $1,290.2 million from $774.3 million as of July 3, 2021. The increase in cash and cash equivalents was primarily due to cash provided by operating activities of $459.3 million and financing activities of $282.9 million, partially offset by cash used in investing activities of $226.3 million during the year ended July 2, 2022.

[0001628280-24-038024:mdna:206]
Cash provided by operating activities was $459.3 million during the year ended July 2, 2022, which reflects net income of $198.9 million and non-cash items of $351.0 million, partially offset by $90.6 million of changes in our operating assets and liabilities. Changes in our operating assets and liabilities are primarily due to an increase in inventories of $51.8 million mostly related to safety stock and components acquired from various brokers at a premium to satisfy customer demand due to supply chain constraints and an increase in accounts receivable of $49.2 million due to the timing of revenue booking and collections, offset by an increase in accounts payable of $47.0 million primarily driven by increase in inventory purchases.

[0001628280-24-038024:mdna:207]
Cash used in investing activities of $226.3 million during the year ended July 2, 2022 was attributable to net proceeds from short-term investments of $111.5 million, capital expenditures of $91.2 million, and a $30.0 million term loan provided to NeoPhotonics to support their on-going growth plans through the anticipated merger completion, partially offset by proceeds from the sales of property, plant and equipment of $6.4 million. The term loan to NeoPhotonics is described in “Note 4. Business Combination” to the consolidated financial statements.

[0001628280-24-038024:mdna:208]
Cash provided by financing activities of $282.9 million during the year ended July 2, 2022, was primarily a result of proceeds from the issuance of the 2028 Notes, net of issuance costs of $854.1 million and proceeds from employee stock plans of $13.5 million, partially offset by the repurchase of shares of our common stock of $543.9 million, tax payments related to the net share settlement of restricted stock of $39.0 million, and $1.8 million to settle conversion requests for the principal amount of the 2024 Notes.
