# LITE 8-K — 0001633978-18-000056 filed 2018-08-08

## item codes, every 8-K on or before 2018-08-28

- 2018-08-08 0001633978-18-000056 — 2.02, 9.01
- 2018-06-08 0001193125-18-188241 — 5.02, 9.01
- 2018-05-02 0001633978-18-000029 — 2.02, 9.01
- 2018-03-12 0001193125-18-078154 — 1.01, 2.01, 8.01, 9.01
- 2018-02-06 0001628280-18-001082 — 2.02, 9.01
- 2017-11-08 0001633978-17-000133 — 5.02, 9.01
- 2017-11-07 0001633978-17-000131 — 5.07
- 2017-11-01 0001633978-17-000117 — 2.02, 9.01
- 2017-08-09 0001633978-17-000058 — 2.02, 9.01
- 2017-05-04 0001633978-17-000035 — 2.02, 9.01
- 2017-03-08 0001193125-17-074740 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2017-03-02 0001193125-17-066769 — 8.01, 9.01
- 2017-02-07 0001633978-17-000005 — 2.02, 9.01
- 2017-01-03 0001628280-17-000018 — 4.01, 9.01
- 2016-11-09 0001628280-16-021143 — 5.02, 5.07, 9.01
- 2016-10-27 0001628280-16-020382 — 2.02, 9.01
- 2016-08-09 0001628280-16-018811 — 2.02, 9.01
- 2016-06-21 0001628280-16-017201 — 8.01
- 2016-05-04 0001628280-16-015501 — 2.02, 9.01
- 2016-02-16 0001628280-16-011261 — 5.02, 9.01
- 2016-02-04 0001628280-16-010758 — 5.02, 9.01
- 2016-02-04 0001628280-16-010755 — 2.02, 9.01
- 2015-11-17 0001193125-15-378953 — 7.01
- 2015-11-10 0001628280-15-008606 — 2.02, 9.01
- 2015-09-28 0001193125-15-329665 — 8.01, 9.01
- 2015-08-11 0001193125-15-286405 — 7.01, 9.01
- 2015-08-06 0001193125-15-281219 — 1.01, 5.02, 5.03, 5.05, 8.01, 9.01
- 2015-08-03 0001193125-15-274808 — 5.03, 9.01

## late-filing notifications on or before 2018-08-28

- 2015-11-10 0001628280-15-008612 — NT 10-Q, for the period ended 2015-09-26
- 2015-09-28 0001193125-15-329672 — NT 10-K, for the period ended 2015-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001633978-18-000056:8k_2_02:1]
EX-99.1
2
lite_ex991xq4fy18.htm
EXHIBIT 99.1

[0001633978-18-000056:8k_2_02:2]
Exhibit

[0001633978-18-000056:8k_2_02:3]
NEWS RELEASE

[0001633978-18-000056:8k_2_02:4]
LUMENTUM ANNOUNCES FISCAL FOURTH QUARTER AND FULL YEAR 2018 RESULTS

[0001633978-18-000056:8k_2_02:5]
Achieved record Net revenue of $1.25 billion, up 25% relative to the prior year, and record profitability for fiscal year 2018

[0001633978-18-000056:8k_2_02:6]
Fiscal Fourth Quarter Highlights:

[0001633978-18-000056:8k_2_02:7]
| • | Net revenue of $301.1 million |

[0001633978-18-000056:8k_2_02:8]
| • | GAAP Operating margin of 6.9%; Non-GAAP Operating margin of 17.8% |

[0001633978-18-000056:8k_2_02:9]
| • | GAAP diluted Net income per common share of $0.40; Non-GAAP diluted Net income per share of $0.95 |

[0001633978-18-000056:8k_2_02:10]
Milpitas, Calif., August 8, 2018 – Lumentum Holdings Inc. (“Lumentum” or the “Company”) today reported results for its fiscal fourth quarter and full year ended June 30, 2018.

[0001633978-18-000056:8k_2_02:11]
Net revenue for the fiscal fourth quarter 2018 was $301.1 million, with GAAP net income attributable to common stockholders of $25.7 million, or $0.40 per diluted share. Net revenue for fiscal third quarter 2018 was $298.8 million, with GAAP net income attributable to common stockholders of $2.4 million, or $0.04 per diluted share. Net revenue for the fiscal fourth quarter 2017 was $222.7 million, with GAAP net loss attributable to common stockholders of $(55.2) million, or $(0.90) per diluted share.

[0001633978-18-000056:8k_2_02:12]
Non-GAAP net income for the fiscal fourth quarter 2018 was $61.6 million, or $0.95 per diluted share. Non-GAAP net income for fiscal third quarter 2018 was $50.6 million, or $0.78 per diluted share. Non-GAAP net income for the fiscal fourth quarter 2017 was $25.0 million, or $0.39 per diluted share.

[0001633978-18-000056:8k_2_02:13]
The Company held $711.5 million in total cash and short-term investments at the end of the fiscal fourth quarter 2018.

[0001633978-18-000056:8k_2_02:14]
Net revenue for fiscal year 2018 was $1,247.7 million, with GAAP net income attributable to common stockholders of $241.5 million, or $3.82 per diluted share. Net revenue for fiscal year 2017 was $1,001.6 million, with GAAP net loss attributable to common stockholders of $(103.4) million, or $(1.71) per diluted share.

[0001633978-18-000056:8k_2_02:15]
Non-GAAP net income for fiscal year 2018 was $247.8 million or $3.82 per diluted share. Non-GAAP net income for fiscal year 2017 was $122.4 million, or $1.94 per diluted share.

[0001633978-18-000056:8k_2_02:16]
“Record revenues in TrueFlex® ROADMs, commercial lasers, and industrial pump lasers drove strong fourth quarter results, capping off a record fiscal 2018 that saw 25% year over year growth and 19.7% operating margins,” said Alan Lowe, President and CEO, “Our strategy of investing in differentiated products addressing multiple growing end-markets critically dependent on photonics drove our strong fiscal 2018 results and positions us well for the future.”

[0001633978-18-000056:8k_2_02:17]
Financial Overview – Fiscal Fourth Quarter Ended June 30, 2018

[0001633978-18-000056:8k_2_02:18]
|  | GAAP Results ($ in millions) |
|  | Q4 |  | Q3 |  | Q4 |  | Change |
|  | FY 2018 |  | FY 2018 |  | FY 2017 |  | Q/Q |  | Y/Y |
| Net revenue | $301.1 |  | $298.8 |  | $222.7 |  | 0.8% |  | 35.2% |
| Gross margin | 31.7% |  | 32.5% |  | 30.2% |  | (80)bps |  | 150bps |
| Operating margin | 6.9% |  | 8.5% |  | 1.8% |  | (160)bps |  | 510bps |
|  | Non-GAAP Results ($ in millions) |
|  | Q4 |  | Q3 |  | Q4 |  | Change |
|  | FY 2018 |  | FY 2018 |  | FY 2017 |  | Q/Q |  | Y/Y |
| Net revenue | $301.1 |  | $298.8 |  | $222.7 |  | 0.8% |  | 35.2% |
| Gross margin | 37.2% |  | 36.3% |  | 32.9% |  | 90bps |  | 430bps |
| Operating margin | 17.8% |  | 16.5% |  | 9.2% |  | 130bps |  | 860bps |

[0001633978-18-000056:8k_2_02:19]
|  | Net Revenue by Segment ($ in millions) |
|  | Q4 |  | % of |  | Q3 |  | Q4 |  | Change |
|  | FY 2018 |  | Net Revenue |  | FY 2018 |  | FY 2017 |  | Q/Q |  | Y/Y |
| Optical Communications | $244.9 |  | 81.3% |  | $246.3 |  | $186.8 |  | (0.6)% |  | 31.1% |
| Lasers | 56.2 |  | 18.7% |  | 52.5 |  | 35.9 |  | 7.0% |  | 56.5% |
| Total | $301.1 |  | 100.0% |  | $298.8 |  | $222.7 |  | 0.8% |  | 35.2% |

[0001633978-18-000056:8k_2_02:20]
Financial Overview – Fiscal Year Ended June 30, 2018

[0001633978-18-000056:8k_2_02:21]
|  | GAAP Results ($ in millions) |
|  | FY 2018 |  | FY 2017 |  | Change Y/Y |  |
| Net revenue | $1,247.7 |  | $1,001.6 |  | 24.6% |  |
| Gross margin | 34.6% |  | 31.8% |  | 280bps |  |
| Operating margin | 11.2% |  | 4.8% |  | 640bps |  |

[0001633978-18-000056:8k_2_02:22]
|  | Non-GAAP Results ($ in millions) |
|  | FY 2018 |  | FY 2017 |  | Change Y/Y |  |
| Net revenue | $1,247.7 |  | $1,001.6 |  | 24.6% |  |
| Gross margin | 38.9% |  | 34.7% |  | 420bps |  |
| Operating margin | 19.7% |  | 12.4% |  | 730bps |  |

[0001633978-18-000056:8k_2_02:23]
|  | Net Revenue by Segment ($ in millions) |
|  | FY 2018 |  | FY 2017 |  | Change Y/Y |  |
| Optical Communications | $1,059.2 |  | $857.8 |  | 23.5% |  |
| Lasers | 188.5 |  | 143.8 |  | 31.1% |  |
| Total | $1,247.7 |  | $1,001.6 |  | 24.6% |  |

[0001633978-18-000056:8k_2_02:24]
The tables above provide comparisons of quarterly and annual results to prior periods, including sequential quarterly and year-over-year changes. A reconciliation between GAAP and non-GAAP measures is contained in this release under the section titled “Use of Non-GAAP Financial Measures.”

[0001633978-18-000056:8k_2_02:25]
Business Outlook

[0001633978-18-000056:8k_2_02:26]
The Company expects the following for the fiscal first quarter 2019:

[0001633978-18-000056:8k_2_02:27]
•Net Revenue to be in the range of $340 million to $360 million

[0001633978-18-000056:8k_2_02:28]
•Non-GAAP Operating margin of 19% to 21%

[0001633978-18-000056:8k_2_02:29]
•Non-GAAP diluted earnings per share of $0.90 to $1.10

[0001633978-18-000056:8k_2_02:30]
Note:  Earnings per share based on approximately 65.5 million shares outstanding on a fully diluted basis

[0001633978-18-000056:8k_2_02:31]
Our projection of 65.5 million shares outstanding does not include the potentially dilutive effect of the convertible notes, as we have the ability and intent to settle the face value in cash; and therefore, we use the treasury stock method for calculating the dilutive impact of the 2024 Notes. The notes will have an impact on our diluted earnings per share when the average price of our common stock exceeds the conversion price of $60.62. Our guidance does not include results from Oclaro or shares issued in connection with the closing of our acquisition of Oclaro as we are unable to predict the timing of the closing.

[0001633978-18-000056:8k_2_02:32]
We have not provided reconciliations from GAAP to non-GAAP measures for our outlook. A large portion of non-GAAP adjustments, such as derivative liability adjustments, restructuring charges, stock-based compensation, litigation, acquisition related costs, non-cash income tax expense and credits, and other costs and contingencies unrelated to current and future operations are by their nature highly volatile and we have low visibility as to the range that may be incurred in the future. For example, in the fiscal second quarter of 2018, we had a credit of $207.0 million primarily related to a release of a U.S. valuation allowance, which was offset by a write-down of deferred tax assets in the amount of $83.0 million due to the lower corporate tax rate enacted under the 2017 “Tax Cuts and Jobs Act” reform.

[0001633978-18-000056:8k_2_02:33]
Conference Call

[0001633978-18-000056:8k_2_02:34]
Lumentum will host a conference call on August 8, 2018 at 5:30 am PT/8:30 am ET. A live webcast of the call and the replay will be available on the Lumentum website at http://investor.lumentum.com through August 15, 2018 at 11:59 pm ET. Supporting materials outlining the Company’s latest financial results will be posted on http://investor.lumentum.com under the “Events and Presentations” section concurrently with this earnings press release. This press release is being furnished as an exhibit to a Current Report on Form 8-K with the Securities and Exchange Commission and will be available at http://www.sec.gov/.

[0001633978-18-000056:8k_2_02:35]
About Lumentum

[0001633978-18-000056:8k_2_02:36]
Lumentum (NASDAQ: LITE) is a market-leading manufacturer of innovative optical and photonic products enabling optical networking and commercial laser customers worldwide. Lumentum’s optical components and subsystems are part of virtually every type of telecom, enterprise, and data center network. Lumentum’s commercial lasers enable advanced manufacturing techniques and diverse applications including next-generation 3D sensing capabilities. Lumentum is headquartered in Milpitas, California with R&D, manufacturing, and sales offices worldwide. For more information, visit https://www.lumentum.com/en.

[0001633978-18-000056:8k_2_02:37]
Forward-Looking Statements

[0001633978-18-000056:8k_2_02:38]
No Offer or Solicitation

[0001633978-18-000056:8k_2_02:39]
This communication is for informational purposes only and not intended to and does not constitute an offer to subscribe for, buy or sell, the solicitation of an offer to subscribe for, buy or sell or an invitation to subscribe for, buy or sell any securities or the solicitation of any vote or approval in any jurisdiction pursuant to or in connection with the proposed transaction or otherwise, nor shall there be any sale, issuance or transfer of securities in any jurisdiction in contravention of applicable law. No offer of securities shall be made except by means of a prospectus meeting the requirements of Section 10 of the Securities Act of 1933, as amended, and otherwise in accordance with applicable law.

[0001633978-18-000056:8k_2_02:40]
Additional Information and Where to Find It

[0001633978-18-000056:8k_2_02:41]
In connection with the proposed transaction between Lumentum Holdings, Inc. (“Lumentum”) and Oclaro, Inc. (“Oclaro”), Lumentum filed a registration statement on Form S-4 with the Securities and Exchange Commission (the “SEC”), which includes a proxy statement of Oclaro that also constitutes a prospectus of Lumentum. The registration statement was declared effective by the SEC on May 31, 2018, and Oclaro commenced mailing the definitive joint proxy statement/prospectus to stockholders of Oclaro on or about June 4, 2018, and the special meeting of the stockholders of Oclaro was held on July 10, 2018.

[0001633978-18-000056:8k_2_02:42]
LUMENTUM AND OCLARO URGE INVESTORS AND SECURITY HOLDERS TO READ THE DEFINITIVE PROXY STATEMENT/PROSPECTUS AND OTHER DOCUMENTS FILED WITH THE SECURITIES AND EXCHANGE COMMISSION CAREFULLY AND IN THEIR ENTIRETY BECAUSE THEY WILL CONTAIN IMPORTANT INFORMATION ABOUT THE PROPOSED TRANSACTION.

[0001633978-18-000056:8k_2_02:43]
Investors and security holders may obtain these materials and other documents filed with the Securities and Exchange Commission free of charge at the Securities and Exchange Commission’s website, www.sec.gov. Copies of documents filed with the Securities and Exchange Commission by Lumentum (when they become available) may be obtained free of charge on Lumentum’s website at www.lumentum.com or by directing a written request to Lumentum Holdings Inc., Investor Relations, 400 North McCarthy Boulevard, Milpitas, CA 95035. Copies of documents filed with the Securities and Exchange Commission by Oclaro (when they become available) may be obtained free of charge on Oclaro’s website at www.oclaro.com or by directing a written request to Oclaro, Inc. Investor Relations, 225 Charcot Avenue, San Jose, CA 95131.

[0001633978-18-000056:8k_2_02:44]
Contact Information

[0001633978-18-000056:8k_2_02:45]
Investors: Chris Coldren, 408-404-0606; investor.relations@lumentum.com

[0001633978-18-000056:8k_2_02:46]
Press: Greg Kaufman, 408-546-4593; media@lumentum.com

[0001633978-18-000056:8k_2_02:47]
The following financial tables are presented in accordance with GAAP, unless otherwise specified.

[0001633978-18-000056:8k_2_02:48]
LUMENTUM HOLDINGS INC.

[0001633978-18-000056:8k_2_02:49]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0001633978-18-000056:8k_2_02:50]
(in millions, except per share data)

[0001633978-18-000056:8k_2_02:51]
(unaudited)

[0001633978-18-000056:8k_2_02:52]
|  | Three Months Ended |  | Twelve Months Ended |
|  | June 30, 2018 |  | July 1, 2017 |  | June 30, 2018 |  | July 1, 2017 |
| Net revenue | $ | 301.1 |  |  | $ | 222.7 |  |  | $ | 1,247.7 |  |  | $ | 1,001.6 |  |
| Cost of sales | 204.8 |  |  | 154.0 |  |  | 812.4 |  |  | 677.0 |  |
| Amortization of acquired developed technologies | 0.8 |  |  | 1.4 |  |  | 3.2 |  |  | 6.5 |  |
| Gross profit | 95.5 |  |  | 67.3 |  |  | 432.1 |  |  | 318.1 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 38.5 |  |  | 35.4 |  |  | 156.8 |  |  | 148.3 |  |
| Selling, general and administrative | 32.7 |  |  | 26.0 |  |  | 128.2 |  |  | 110.2 |  |
| Restructuring and related charges | 3.4 |  |  | 2.0 |  |  | 7.2 |  |  | 12.0 |  |
| Total operating expenses | 74.6 |  |  | 63.4 |  |  | 292.2 |  |  | 270.5 |  |
| Income from operations | 20.9 |  |  | 3.9 |  |  | 139.9 |  |  | 47.6 |  |
| Unrealized gain (loss) on derivative liabilities | 7.8 |  |  | (29.7 | ) |  | (0.8 | ) |  | (104.2 | ) |
| Interest and other (expense) income, net | (1.0 | ) |  | (1.8 | ) |  | (9.7 | ) |  | (3.2 | ) |
| Income (loss) before income taxes | 27.7 |  |  | (27.6 | ) |  | 129.4 |  |  | (59.8 | ) |
| Provision for (benefit from) income taxes | (5.8 | ) |  | 27.3 |  |  | (118.7 | ) |  | 42.7 |  |
| Net income (loss) | 33.5 |  |  | (54.9 | ) |  | 248.1 |  |  | (102.5 | ) |
| Items reconciling net income (loss) to net income (loss) attributable to common stockholders: |  |  |  |  |  |  |  |
| Cumulative dividends on Series A Preferred Stock | (0.2 | ) |  | (0.3 | ) |  | (0.9 | ) |  | (0.9 | ) |
| Earnings allocated to Series A Preferred Stock | (0.8 | ) |  | $ | — |  |  | (5.7 | ) |  | $ | — |  |
| Net income (loss) attributable to common stockholders - Basic | $ | 32.5 |  |  | $ | (55.2 | ) |  | $ | 241.5 |  |  | $ | (103.4 | ) |
| Add: Earnings allocated to Series A Preferred Stock | 0.8 |  |  | — |  |  | — |  |  | — |  |
| Add/Less: Unrealized (gain) loss on derivative liability on Series A Preferred Stock | (7.8 | ) |  | — |  |  | — |  |  | — |  |
| Add: Cumulative dividends on Series A Preferred Stock | 0.2 |  |  | — |  |  | — |  |  | — |  |
| Net income (loss) attributable to common stockholders - Diluted (a) | $ | 25.7 |  |  | $ | (55.2 | ) |  | $ | 241.5 |  |  | $ | (103.4 | ) |
| Net income (loss) per share attributable to common stockholders: |  |  |  |  |  |  |  |
| Basic | $ | 0.52 |  |  | $ | (0.90 | ) |  | $ | 3.88 |  |  | $ | (1.71 | ) |
| Diluted | $ | 0.40 |  |  | $ | (0.90 | ) |  | $ | 3.82 |  |  | $ | (1.71 | ) |
| Shares used to compute net income (loss) per share attributable to common stockholders: |  |  |  |  |  |  |  |
| Basic | 62.7 |  |  | 61.3 |  |  | 62.3 |  |  | 60.6 |  |
| Diluted | 65.0 |  |  | 61.3 |  |  | 63.3 |  |  | 60.6 |  |

[0001633978-18-000056:8k_2_02:53]
(a) For the three months ended June 30, 2018, our diluted earnings per share attributable to common stockholders is calculated using the “if-converted” method because it is more dilutive, whereas for the twelve months ended June 30, 2018, our diluted earnings per share attributable to common stockholders is calculated using “two-class” method.

[0001633978-18-000056:8k_2_02:54]
LUMENTUM HOLDINGS INC.

[0001633978-18-000056:8k_2_02:55]
CONSOLIDATED BALANCE SHEETS

[0001633978-18-000056:8k_2_02:56]
(in millions, except share and per share data)

[0001633978-18-000056:8k_2_02:57]
(unaudited)

[0001633978-18-000056:8k_2_02:58]
|  | June 30, 2018 |  | July 1, 2017 |
| ASSETS |  |  |  |  |  |
| Current assets: |  |  |  |  |  |
| Cash and cash equivalents | $ | 397.3 |  |  | $ | 272.9 |  |
| Short-term investments | 314.2 |  |  | 282.4 |  |
| Accounts receivable, net | 197.1 |  |  | 166.3 |  |
| Inventories | 153.6 |  |  | 145.2 |  |
| Prepayments and other current assets | 65.0 |  |  | 63.5 |  |
| Total current assets | 1,127.2 |  |  | 930.3 |  |
| Property, plant and equipment, net | 306.9 |  |  | 273.5 |  |
| Goodwill and intangibles, net | 18.3 |  |  | 21.5 |  |
| Deferred income taxes, net | 125.6 |  |  | 3.9 |  |
| Other non-current assets | 3.5 |  |  | 3.7 |  |
| Total assets | $ | 1,581.5 |  |  | $ | 1,232.9 |  |
| LIABILITIES, REDEEMABLE CONVERTIBLE PREFERRED STOCK, AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 126.5 |  |  | $ | 114.8 |  |
| Accrued payroll and related expenses | 31.5 |  |  | 27.5 |  |
| Accrued expenses | 33.9 |  |  | 19.3 |  |
| Other current liabilities | 22.1 |  |  | 22.6 |  |
| Total current liabilities | 214.0 |  |  | 184.2 |  |
| Convertible notes | 334.2 |  |  | 317.5 |  |
| Derivative liability | 52.4 |  |  | 51.6 |  |
| Other non-current liabilities | 19.0 |  |  | 25.0 |  |
| Total liabilities | 619.6 |  |  | 578.3 |  |
| Redeemable convertible preferred stock: |  |  |  |
| Non-controlling interest redeemable convertible Series A Preferred Stock, $0.001 par value, 10,000,000 authorized shares; 35,805 shares issued and outstanding as of June 30, 2018 and July 1, 2017 | 35.8 |  |  | 35.8 |  |
| Total redeemable convertible preferred stock | 35.8 |  |  | 35.8 |  |
| Stockholders’ equity: |  |  |  |
| Common stock, $0.001 par value, 990,000,000 authorized shares, 62,790,087 and 61,476,103 shares issued and outstanding as of June 30, 2018 and July 1, 2017, respectively | 0.1 |  |  | 0.1 |  |
| Additional paid-in capital | 753.2 |  |  | 694.5 |  |
| Retained earnings | 166.4 |  |  | (83.2 | ) |
| Accumulated other comprehensive income | 6.4 |  |  | 7.4 |  |
| Total stockholders’ equity | 926.1 |  |  | 618.8 |  |
| Total liabilities, redeemable convertible preferred stock, and stockholders’ equity | $ | 1,581.5 |  |  | $ | 1,232.9 |  |

[0001633978-18-000056:8k_2_02:59]
Use of Non-GAAP Financial Measures

[0001633978-18-000056:8k_2_02:60]
In this press release, Lumentum provides investors with gross margin, operating margin, net income, and net income (loss) per share on a non-GAAP basis. Lumentum believes this non-GAAP financial information provides additional insight into the Company’s on-going performance and has therefore chosen to provide this information to investors for a more consistent basis of comparison and to help them evaluate the results of the Company’s on-going operations and enable more meaningful period to period comparisons. Specifically, the Company believes that providing this information allows investors to better understand the Company’s financial performance and, importantly, to evaluate the efficacy of the methodology and information used by management to evaluate and measure such operating performance.  However, these measures may be different from non-GAAP measures used by other companies, limiting their usefulness for comparison purposes. The non-GAAP financial measures used in this press release should not be considered in isolation from measures of financial performance prepared in accordance with GAAP. Investors are cautioned that there are material limitations associated with the use of non-GAAP financial measures as an analytical tool. In particular, many of the adjustments to our GAAP financial measures reflect the exclusion of items that are recurring and will be reflected in our financial results for the foreseeable future. Further, these non-GAAP financial measures may not be comparable to similarly titled measurements reported by other companies.

[0001633978-18-000056:8k_2_02:61]
Non-GAAP gross margin, non-GAAP operating margin, non-GAAP net income, and non-GAAP net income per share, Adjusted EBITDA, non-GAAP gross profit, non-GAAP operating income, non-GAAP income (loss) before income taxes and non-GAAP expenses exclude (i) stock-based compensation,(ii) acquisition related costs, (iii) other charges comprised mainly of set-up costs of our Thailand facility, including costs of transferring product lines to Thailand, as well as inventory write-downs due to cancelled programs and other costs and contingencies unrelated to current and future operations, (iv) amortization of acquired developed technologies, (v) workforce related charges such as severance, retention bonuses and employee relocation costs related to formal restructuring plans, (vi) non-cash interest expense, (vii) unrealized gain (loss) on derivative liability, (viii) non-cash income tax provision impacts, for example, a release of a U.S. valuation allowance, and the write down of deferred tax assets due to the 2017 Tax Cuts and Jobs Act. The presentation of these and other similar items in Lumentum’s non-GAAP financial results should not be interpreted as implying that these items are non-recurring, infrequent or unusual.

[0001633978-18-000056:8k_2_02:62]
A quantitative reconciliation between GAAP and non-GAAP financial data with respect to historical periods is included in the supplemental financial table attached to this press release.

[0001633978-18-000056:8k_2_02:63]
LUMENTUM HOLDINGS INC.

[0001633978-18-000056:8k_2_02:64]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001633978-18-000056:8k_2_02:65]
(in millions, except per share data)

[0001633978-18-000056:8k_2_02:66]
(unaudited)

[0001633978-18-000056:8k_2_02:67]
|  | Three Months Ended |  | Twelve Months Ended |
|  | June 30, 2018 |  | July 1, 2017 |  | June 30, 2018 |  | July 1, 2017 |
| Gross profit on GAAP basis | $ | 95.5 |  |  | $ | 67.3 |  |  | $ | 432.1 |  |  | $ | 318.1 |  |
| Stock-based compensation | 3.1 |  |  | 1.5 |  |  | 12.6 |  |  | 7.5 |  |
| Other charges related to non-recurring activities (a) | 12.7 |  |  | 3.0 |  |  | 37.2 |  |  | 15.1 |  |
| Amortization of acquired developed technologies | 0.8 |  |  | 1.4 |  |  | 3.2 |  |  | 6.5 |  |
| Gross profit on non-GAAP basis | $ | 112.1 |  |  | $ | 73.2 |  |  | $ | 485.1 |  |  | $ | 347.2 |  |
| Research and development on GAAP basis | $ | 38.5 |  |  | $ | 35.4 |  |  | $ | 156.8 |  |  | $ | 148.3 |  |
| Stock-based compensation | (3.7 | ) |  | (2.8 | ) |  | (14.2 | ) |  | (11.6 | ) |
| Other charges related to non-recurring activities | (0.6 | ) |  | (0.3 | ) |  | (2.0 | ) |  | (1.0 | ) |
| Research and development on non-GAAP basis | $ | 34.2 |  |  | $ | 32.3 |  |  | $ | 140.6 |  |  | $ | 135.7 |  |
| Selling, general and administrative on GAAP basis | $ | 32.7 |  |  | $ | 26.0 |  |  | $ | 128.2 |  |  | $ | 110.2 |  |
| Stock-based compensation | (4.9 | ) |  | (3.5 | ) |  | (20.0 | ) |  | (13.6 | ) |
| Acquisition related costs | (2.1 | ) |  | — |  |  | (4.8 | ) |  | — |  |
| Other charges related to non-recurring activities | (1.4 | ) |  | (2.0 | ) |  | (5.1 | ) |  | (9.1 | ) |
| Amortization of acquired developed technologies | — |  |  | — |  |  | — |  |  | (0.3 | ) |
| Selling, general and administrative on non-GAAP basis | $ | 24.3 |  |  | $ | 20.5 |  |  | $ | 98.3 |  |  | $ | 87.2 |  |
| Income from operations on GAAP basis | $ | 20.9 |  |  | $ | 3.9 |  |  | $ | 139.9 |  |  | $ | 47.6 |  |
| Stock-based compensation | 11.7 |  |  | 7.8 |  |  | 46.8 |  |  | 32.7 |  |
| Acquisition related costs | 2.1 |  |  | — |  |  | 4.8 |  |  | — |  |
| Other charges related to non-recurring activities (a) | 14.7 |  |  | 5.3 |  |  | 44.3 |  |  | 25.2 |  |
| Amortization of acquired developed technologies | 0.8 |  |  | 1.4 |  |  | 3.2 |  |  | 6.8 |  |
| Restructuring and related charges | 3.4 |  |  | 2.0 |  |  | 7.2 |  |  | 12.0 |  |
| Income from operations on non-GAAP basis | $ | 53.6 |  |  | $ | 20.4 |  |  | $ | 246.2 |  |  | $ | 124.3 |  |
| Interest and other (expense) income, net on GAAP basis | $ | (1.0 | ) |  | $ | (1.8 | ) |  | $ | (9.7 | ) |  | $ | (3.2 | ) |
| Non-cash other (income) expense | — |  |  | (1.4 | ) |  | (0.1 | ) |  | (1.7 | ) |
| Effective interest expense on convertible notes | 4.3 |  |  | 4.1 |  |  | 16.7 |  |  | 5.1 |  |
| Interest and other (expense) income, net on non-GAAP basis | $ | 3.3 |  |  | $ | 0.9 |  |  | $ | 6.9 |  |  | $ | 0.2 |  |
| Income (loss) before income taxes on GAAP basis | $ | 27.7 |  |  | $ | (27.6 | ) |  | $ | 129.4 |  |  | $ | (59.8 | ) |
| Stock-based compensation | 11.7 |  |  | 7.8 |  |  | 46.8 |  |  | 32.7 |  |
| Acquisition related costs | 2.1 |  |  | — |  |  | 4.8 |  |  | — |  |
| Other charges related to non-recurring activities (a) | 14.7 |  |  | 5.3 |  |  | 44.3 |  |  | 25.2 |  |
| Amortization of acquired developed technologies | 0.8 |  |  | 1.4 |  |  | 3.2 |  |  | 6.8 |  |
| Restructuring and related charges | 3.4 |  |  | 2.0 |  |  | 7.2 |  |  | 12.0 |  |
| Non-cash other (income) expense | — |  |  | (1.4 | ) |  | (0.1 | ) |  | (1.7 | ) |

[0001633978-18-000056:8k_2_02:68]
| Effective interest expense on convertible notes | 4.3 |  |  | 4.1 |  |  | 16.7 |  |  | 5.1 |  |
| Unrealized (gain) loss on derivative liabilities | (7.8 | ) |  | 29.7 |  |  | 0.8 |  |  | 104.2 |  |
| Income before income taxes on non-GAAP basis | $ | 56.9 |  |  | $ | 21.3 |  |  | $ | 253.1 |  |  | $ | 124.5 |  |
| Provision for (benefit from) income taxes on GAAP basis | $ | (5.8 | ) |  | $ | 27.3 |  |  | $ | (118.7 | ) |  | $ | 42.7 |  |
| Income tax adjustments (b) | 1.1 |  |  | (31.0 | ) |  | 124.0 |  |  | (40.6 | ) |
| Provision for (benefit from) income taxes on non-GAAP basis | $ | (4.7 | ) |  | $ | (3.7 | ) |  | $ | 5.3 |  |  | $ | 2.1 |  |
| Net income (loss) on GAAP basis | $ | 33.5 |  |  | $ | (54.9 | ) |  | $ | 248.1 |  |  | $ | (102.5 | ) |
| Stock-based compensation | 11.7 |  |  | 7.8 |  |  | 46.8 |  |  | 32.7 |  |
| Acquisition related costs | 2.1 |  |  | — |  |  | 4.8 |  |  | — |  |
| Other charges related to non-recurring activities (a) | 14.7 |  |  | 5.3 |  |  | 44.3 |  |  | 25.2 |  |
| Amortization of acquired developed technologies | 0.8 |  |  | 1.4 |  |  | 3.2 |  |  | 6.8 |  |
| Restructuring and related charges | 3.4 |  |  | 2.0 |  |  | 7.2 |  |  | 12.0 |  |
| Non-cash other (income) expense | — |  |  | (1.4 | ) |  | (0.1 | ) |  | (1.7 | ) |
| Effective interest expense on convertible notes | 4.3 |  |  | 4.1 |  |  | 16.7 |  |  | 5.1 |  |
| Unrealized (gain) loss on derivative liabilities | (7.8 | ) |  | 29.7 |  |  | 0.8 |  |  | 104.2 |  |
| Income tax adjustments (b) | (1.1 | ) |  | 31.0 |  |  | (124.0 | ) |  | 40.6 |  |
| Net income on non-GAAP basis | $ | 61.6 |  |  | $ | 25.0 |  |  | $ | 247.8 |  |  | $ | 122.4 |  |
| Net income per share on non-GAAP basis | $ | 0.95 |  |  | $ | 0.39 |  |  | $ | 3.82 |  |  | $ | 1.94 |  |
| Shares used in per share calculation - diluted on GAAP basis | 65.0 |  |  | 61.3 |  |  | 63.3 |  |  | 60.6 |  |
| Non-GAAP adjustment (c) | — |  |  | 1.0 |  |  | — |  |  | 1.0 |  |
| Effect of diluted securities from Series A Preferred Stock(d) | — |  |  | 1.5 |  |  | 1.5 |  |  | 1.5 |  |
| Shares used in per share calculation - diluted on non-GAAP basis | 65.0 |  |  | 63.8 |  |  | 64.8 |  |  | 63.1 |  |

[0001633978-18-000056:8k_2_02:69]
(a) The increase during the fiscal year ended June 30, 2018 primarily relates to set-up costs of our Thailand facility, including costs of transferring product lines to Thailand, as well as inventory write-downs due to cancelled programs.

[0001633978-18-000056:8k_2_02:70]
(b) The change during the fiscal year ended June 30, 2018 is primarily attributable to a credit of $207.0 million related to a release of a U.S. valuation allowance, which was offset by the write down of deferred tax assets due to the 2017 “Tax Cuts and Jobs Act” reform in the amount of $83.0 million.

[0001633978-18-000056:8k_2_02:71]
(c) This adjustment represents weighted-average potentially dilutive securities from our stock-based benefit plans excluded from the computation of diluted net loss per share attributable to common stockholders on a GAAP basis because the effect would have been anti-dilutive. This adjustment amount is added for the computation of diluted net income per share on a non-GAAP basis as we had a net income on a non-GAAP basis.

[0001633978-18-000056:8k_2_02:72]
(d) 1.5 million shares related to the potential conversion of the Series A Preferred Stock were added to the calculation of diluted shares available on a non-GAAP basis because their inclusion results in more dilutive earnings per share.

[0001633978-18-000056:8k_2_02:73]
LUMENTUM HOLDINGS INC.

[0001633978-18-000056:8k_2_02:74]
RECONCILIATION OF GAAP NET INCOME (LOSS) TO ADJUSTED EBITDA

[0001633978-18-000056:8k_2_02:75]
(in millions)

[0001633978-18-000056:8k_2_02:76]
(unaudited)

[0001633978-18-000056:8k_2_02:77]
|  | Three Months Ended |  | Twelve Months Ended |
|  | June 30, 2018 |  | July 1, 2017 |  | June 30, 2018 |  | July 1, 2017 |
| GAAP net income (loss) | $ | 33.5 |  |  | $ | (54.9 | ) |  | $ | 248.1 |  |  | $ | (102.5 | ) |
| Interest and other expense (income), net | 1.0 |  |  | 1.8 |  |  | 9.7 |  |  | 3.2 |  |
| Provision for (benefit from) income taxes (b) | (5.8 | ) |  | 27.3 |  |  | (118.7 | ) |  | 42.7 |  |
| Depreciation | 20.7 |  |  | 15.1 |  |  | 74.0 |  |  | 54.2 |  |
| Amortization of acquired developed technologies | 0.8 |  |  | 1.4 |  |  | 3.2 |  |  | 6.8 |  |
| EBITDA | 50.2 |  |  | (9.3 | ) |  | 216.3 |  |  | 4.4 |  |
| Restructuring and related charges | 3.4 |  |  | 2.0 |  |  | 7.2 |  |  | 12.0 |  |
| Stock-based compensation | 11.7 |  |  | 7.8 |  |  | 46.8 |  |  | 32.7 |  |
| Acquisition related costs | 2.1 |  |  | — |  |  | 4.8 |  |  | — |  |
| Other charges related to non-recurring activities (a) | 14.7 |  |  | 5.3 |  |  | 44.3 |  |  | 25.2 |  |
| Unrealized (gain) loss on derivative liabilities | (7.8 | ) |  | 29.7 |  |  | 0.8 |  |  | 104.2 |  |
| Adjusted EBITDA | $ | 74.3 |  |  | $ | 35.5 |  |  | $ | 320.2 |  |  | $ | 178.5 |  |

[0001633978-18-000056:8k_2_02:78]
(a) The increase during the fiscal year ended June 30, 2018 primarily relates to set-up costs of our Thailand facility, including costs of transferring product lines to Thailand, as well as inventory write-downs due to cancelled programs.

[0001633978-18-000056:8k_2_02:79]
(b) The change during the fiscal year ended June 30, 2018 is primarily attributable to a credit of $207.0 million related to a release of a U.S. valuation allowance, which was offset by the write down of deferred tax assets due to the 2017 “Tax Cuts and Jobs Act” reform in the amount of $83.0 million.
