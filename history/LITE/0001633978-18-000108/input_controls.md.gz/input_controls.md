# LITE 10-K controls and the auditor's report


## auditors_report

10-K auditors_report: 5 candidate headings, none whose body matches 'critical audit matter'.


## item_9a

[0001633978-18-000108:item_9a:1]
ITEM 9A.    CONTROLS AND PROCEDURES

[0001633978-18-000108:item_9a:2]
(a)    EVALUATION OF DISCLOSURE CONTROLS AND PROCEDURES

[0001633978-18-000108:item_9a:3]
Our management is responsible for establishing and maintaining adequate internal control over financial reporting. Management, with the participation of our chief executive officer and our chief financial officer, evaluated the effectiveness of our disclosure controls and procedures as of June 30, 2018. The term “disclosure controls and procedures,” as defined in Rules 13a-15 and 15d-15 under the Exchange Act, means controls and other procedures of a company that are designed to ensure that information required to be disclosed by a company in the reports that it files or submits under the Exchange Act is recorded, processed, summarized and reported within the time periods specified in the SEC’s rules and forms. Disclosure controls and procedures include, without limitation, controls and procedures designed to ensure that information required to be disclosed by a company in the reports that it files or submits under the Exchange Act is accumulated and communicated to the company’s management, including its principal executive and principal financial officers, as appropriate to allow timely decisions regarding required disclosure. Management recognizes that any controls and procedures, no matter how well designed and operated, can provide only reasonable assurance of achieving their objectives, and management necessarily applies its judgment in evaluating the cost-benefit relationship of possible controls and procedures. Based on the evaluation of our disclosure controls and procedures as of June 30, 2018, our chief executive officer and chief financial officer concluded that our disclosure controls and procedures were effective at a reasonable assurance level.

[0001633978-18-000108:item_9a:4]
(b)    MANAGEMENT’S REPORT ON INTERNAL CONTROL OVER FINANCIAL REPORTING

[0001633978-18-000108:item_9a:5]
Our management is responsible for establishing and maintaining adequate internal control over financial reporting (as defined in Rule 13a-15(f) under the Exchange Act). Management conducted an assessment of the effectiveness of our internal control over financial reporting based on the criteria set forth in Internal Control—Integrated Framework issued by the Committee of Sponsoring Organizations of the Treadway Commission (2013 framework). Based on the assessment, management has concluded that its internal control over financial reporting was effective as of June 30, 2018 to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements in accordance with U.S. GAAP.

[0001633978-18-000108:item_9a:6]
Deloitte & Touche LLP, the independent registered public accounting firm that audited the consolidated financial statements included in this Form 10-K, has issued a report, included herein, on the effectiveness of the Company’s internal control over financial reporting as of June 30, 2018.

[0001633978-18-000108:item_9a:7]
(c)     CHANGES IN INTERNAL CONTROL OVER FINANCIAL REPORTING

[0001633978-18-000108:item_9a:8]
There were no changes in our internal control over financial reporting identified in connection with the evaluation required by Rule 13a-15 and 15d-15 of the Exchange Act that occurred during the quarter ended June 30, 2018 that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.

[0001633978-18-000108:item_9a:9]
INHERENT LIMITATIONS ON EFFECTIVENESS OF CONTROLS

[0001633978-18-000108:item_9a:10]
Our management, including the CEO and CFO, recognizes that our disclosure controls and procedures or our internal control over financial reporting cannot prevent or detect all possible instances of errors and all fraud. A control system, no matter how well designed and operated, can provide only reasonable, not absolute, assurance that the control system’s objectives will be met. The design of a control system must reflect the fact that there are resource constraints, and the benefits of controls must be considered relative to their costs.

[0001633978-18-000108:item_9a:11]
105

[0001633978-18-000108:item_9a:12]
REPORT OF INDEPENDENT REGISTERED PUBLIC ACCOUNTING FIRM

[0001633978-18-000108:item_9a:13]
To the stockholders and the Board of Directors of Lumentum Holdings Inc.

[0001633978-18-000108:item_9a:14]
Opinion on Internal Control over Financial Reporting

[0001633978-18-000108:item_9a:15]
We have audited the internal control over financial reporting of Lumentum Holdings Inc. and subsidiaries (the “Company”) as of June 30, 2018, based on criteria established in Internal Control - Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (COSO). In our opinion, the Company maintained, in all material respects, effective internal control over financial reporting as of June 30, 2018, based on criteria established in Internal Control - Integrated Framework (2013) issued by COSO.

[0001633978-18-000108:item_9a:16]
We have also audited, in accordance with the standards of the Public Company Accounting Oversight Board (United States) (PCAOB), the consolidated financial statements as of and for the year ended June 30, 2018, of the Company and our report dated August 28, 2018, expressed an unqualified opinion on those financial statements.

[0001633978-18-000108:item_9a:17]
Basis for Opinion

[0001633978-18-000108:item_9a:18]
The Company’s management is responsible for maintaining effective internal control over financial reporting and for its assessment of the effectiveness of internal control over financial reporting, included in the accompanying Management's Annual report on Internal control over Financial Reporting. Our responsibility is to express an opinion on the Company’s internal control over financial reporting based on our audit. We are a public accounting firm registered with the PCAOB and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0001633978-18-000108:item_9a:19]
We conducted our audit in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audit to obtain reasonable assurance about whether effective internal control over financial reporting was maintained in all material respects. Our audit included obtaining an understanding of internal control over financial reporting, assessing the risk that a material weakness exists, testing and evaluating the design and operating effectiveness of internal control based on the assessed risk, and performing such other procedures as we considered necessary in the circumstances. We believe that our audit provides a reasonable basis for our opinion.

[0001633978-18-000108:item_9a:20]
Definition and Limitations of Internal Control over Financial Reporting

[0001633978-18-000108:item_9a:21]
A company’s internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. A company’s internal control over financial reporting includes those policies and procedures that (1) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the company; (2) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the company are being made only in accordance with authorizations of management and directors of the company; and (3) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the company’s assets that could have a material effect on the financial statements.

[0001633978-18-000108:item_9a:22]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0001633978-18-000108:item_9a:23]
/s/ DELOITTE & TOUCHE LLP

[0001633978-18-000108:item_9a:24]
San Jose, California

[0001633978-18-000108:item_9a:25]
August 28, 2018
