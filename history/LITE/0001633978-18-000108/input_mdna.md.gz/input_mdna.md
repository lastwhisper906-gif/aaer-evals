# LITE MD&A — 0001633978-18-000108


## mdna

[0001633978-18-000108:mdna:1]
Item 7. Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001633978-18-000108:mdna:2]
You should read the following discussion in conjunction with the audited consolidated financial statements and the corresponding notes included elsewhere in this Annual Report. This Management’s Discussion and Analysis of Financial Condition and Results of Operations contains forward-looking statements. The matters discussed in these forward-looking statements are subject to risk, uncertainties and other factors that could cause actual results to differ materially from those made, projected or implied in the forward-looking statements. Please see “Risk Factors” and “Forward-Looking Statements” for a discussion of the uncertainties, risks and assumptions associated with these statements.

[0001633978-18-000108:mdna:3]
Overview

[0001633978-18-000108:mdna:4]
We are an industry leading provider of optical and photonic products defined by revenue and market share addressing a range of end-market applications including optical communications and commercial lasers. We have two operating segments: OpComms and Lasers. The two operating segments were primarily determined based on how the Chief Operating Decision Maker (“CODM”) views and evaluates our operations. Operating results are regularly reviewed by the CODM to make decisions about resources to be allocated to the segments and to assess their performance. Other factors, including market separation and customer specific applications, go-to-market channels, products and manufacturing, are considered in determining the formation of these operating segments.

[0001633978-18-000108:mdna:5]
We see the world as becoming more reliant on ever-increasing amounts of data flowing through optical networks and data centers, which demand new networks and data centers to be built to satisfy this insatiable demand for data.  As higher levels of precision, new materials, factory and energy efficiency are being demanded by manufacturers, suppliers of manufacturing tools globally are turning more and more to laser based approaches, including the types of lasers Lumentum supplies. Laser based 3D sensing is a rapidly developing market. The technology enables computer vision applications that enhance security, safety, and new functionality in the electronic devices that people rely on every day. We believe the global markets in which Lumentum participates have fundamentally robust, long-term trends that increase the need for our photonics products and technologies.

[0001633978-18-000108:mdna:6]
During fiscal 2018, we made good progress on our key strategic objectives that accelerated growth, margin expansion, and customer and end-market diversification. We ramped new major product lines in 3D sensing for mobile devices and engaged numerous customers globally, which we believe will facilitate future product and customer expansion.

[0001633978-18-000108:mdna:7]
OpComms

[0001633978-18-000108:mdna:8]
Our OpComms products address the following markets: Telecom, Datacom and Consumer and Industrial.

[0001633978-18-000108:mdna:9]
Our OpComms products include a wide range of components, modules and subsystems to support and maintain customers including carrier networks for access (local), metro (intracity), long-haul (city-to-city and worldwide) and, submarine (undersea). Additionally, our products address enterprise, cloud, and data center applications, including SANs, LANs, and WANs. These products enable the transmission and transport of video, audio and text data over high-capacity fiber-optic cables. We maintain leading positions in these fast growing OpComms markets through our extensive product portfolio, including ROADMs, tunable 10-gigabit small form-factor pluggable transceivers and tunable small form-factor pluggable transceivers. Our 10G, 40G legacy transceivers and a growing portfolio of 100G pluggable transceivers support LAN/SAN/WAN needs and the cloud for customers building enterprise and hyperscale data center networks. Additionally, we are engaging customers in the sale of laser chips for use in the manufacture of high-speed transceivers.

[0001633978-18-000108:mdna:10]
In the Consumer and Industrial market, our OpComms products include laser light sources, which are integrated into 3D sensing platforms being used in applications for mobile devices, gaming, computers, and other consumer electronics devices. New emerging applications include virtual and augmented reality, as well as automotive and industrial segments. Our products include VCSELs and edge emitting lasers which are used in 3D sensing depth imaging systems. These systems simplify the way people interact with technology by enabling the use of natural user interfaces. Systems are used for biometric identification, surveillance, and process efficiency, among numerous other application spaces. Emerging applications for this technology include various mobile device applications, autonomous vehicles, self-navigating robotics and drones in industrial applications and 3D capture of objects coupled with 3D printing. In addition, our industrial diode lasers are used primarily as pump sources for pulsed and CW Fiber Lasers.

[0001633978-18-000108:mdna:11]
Our OpComms customers include Accelink, Alphabet (formerly Google), Apple, Arista, Arris, Ciena, Cisco Systems, Coriant, ECI, Facebook, FiberHome, Fujitsu, HiSilicon, Huawei Marine, Huawei Technologies, Infinera, Microsoft, NEC, Nokia Networks (including Alcatel-Lucent International), O-Net, Oplink, Padtec, TE Subcom, and Yahoo.

[0001633978-18-000108:mdna:12]
Lasers

[0001633978-18-000108:mdna:13]
Our Lasers products serve our customers in markets and applications such as sheet metal processing, general manufacturing, biotechnology, graphics and imaging, remote sensing, and precision machining such as drilling in printed circuit boards, wafer singulation, glass cutting and solar cell scribing.

[0001633978-18-000108:mdna:14]
Our Lasers products are used in a variety of OEM applications including diode-pumped solid-state, fiber, diode, direct-diode and gas lasers such as argon-ion and helium-neon lasers. Fiber lasers provide kW-class output powers combined with excellent beam quality and are used in sheet metal processing and metal welding applications. Diode-pumped solid-state lasers provide excellent beam quality, low noise and exceptional reliability and are used in biotechnology, graphics and imaging, remote sensing, materials processing and precision machining applications. Diode and direct-diode lasers address a wide variety of applications, including laser pumping, thermal exposure, illumination, ophthalmology, image recording, printing, plastic welding and selective soldering. Gas lasers such as argon-ion and helium-neon lasers provide a stable, low-cost and reliable solution over a wide range of operating conditions, making them well suited for complex, high-resolution OEM applications such as flow cytometry, DNA sequencing, graphics and imaging and semiconductor inspection.

[0001633978-18-000108:mdna:15]
We also provide high-powered and ultrafast lasers for the industrial and scientific markets. Manufacturers use high-power, ultrafast lasers to create micro parts for consumer electronics and to process semiconductor, LED, and other types of chips. Use of ultrafast lasers for micromachining applications is being driven primarily by the increasing use of consumer electronics and connected devices globally.

[0001633978-18-000108:mdna:16]
Our Lasers customers include Amada, ASML Holding, Beckman Coulter, Becton, Dickinson and Company, DISCO, Electro Scientific Industries, EO Technics, Han’s Laser Technology, and KLA-Tencor.

[0001633978-18-000108:mdna:17]
Acquisition of Oclaro

[0001633978-18-000108:mdna:18]
On March 11, 2018, we entered into an Agreement and Plan of Merger (the “Merger Agreement”) with Oclaro, Inc. (“Oclaro”), Prota Merger Sub, Inc., and Prota Merger, LLC, pursuant to which we will acquire Oclaro and Oclaro will become a wholly-owned subsidiary of Lumentum. In accordance with the terms of the Merger Agreement, each issued and outstanding share of Oclaro common stock will be exchanged for $5.60 in cash and 0.0636 of a share of Lumentum common stock, subject to the conditions and restrictions set forth in the Merger Agreement. The total transaction consideration was approximately $1.8 billion as of the date of the Merger Agreement. Oclaro stockholders will own approximately 16% of the combined company following the closing. Oclaro’s stockholders approved the Merger Agreement on July 10, 2018 and we have received approval for the transaction under the Hart-Scott Rodino Act in the United States. We are in the process of obtaining antitrust approval in China. The Merger Agreement contains certain termination rights for both Lumentum and Oclaro. The Merger Agreement further provides that upon termination of the Merger Agreement under specified circumstances relating to failure to obtain regulatory approvals, Lumentum may be required to pay Oclaro a termination fee of $80 million.

[0001633978-18-000108:mdna:19]
As of August 23, 2018, the total transaction consideration was expected to be approximately $1.7 billion, which would be funded by a combination of $700 million in Lumentum common stock, $500 million in new debt, and the remaining amount from the cash balances of the combined company.

[0001633978-18-000108:mdna:20]
Separation from JDSU

[0001633978-18-000108:mdna:21]
Lumentum Holdings Inc. was incorporated in Delaware as a wholly owned subsidiary of JDS Uniphase Corporation (“JDSU”) on February 10, 2015 and is comprised of the former communications and commercial optical products (“CCOP”) segment and the WaveReady product lines of JDSU. On August 1, 2015, we became an independent publicly-traded company through the distribution by JDSU to its stockholders of 80.1% of our outstanding common stock (the “Separation”).   Each JDSU stockholder of record as of the close of business on July 27, 2015 received one share of Lumentum common stock for every five shares of JDSU common stock held on the record date. JDSU was renamed Viavi in connection with the Separation and retained ownership of 19.9% of Lumentum’s outstanding shares. Since the Separation, Viavi has sold a significant portion of its shares and is no longer a significant shareholder of Lumentum.

[0001633978-18-000108:mdna:22]
On July 31, 2015, prior to the Separation, Viavi transferred substantially all of the assets and liabilities and operations of the CCOP segment and WaveReady product lines to Lumentum. Our financial statements for periods prior to the Separation were prepared on a stand-alone basis and were derived from Viavi’s consolidated financial statements and accounting records. For the period from June 28, 2015 to August 1, 2015, expenses were allocated to us using estimates that we consider to be a reasonable reflection of the utilization of services provided to or benefits received by us.

[0001633978-18-000108:mdna:23]
The consolidated financial statements include certain assets and liabilities that were historically held at the Viavi level but which were transferred to us in the Separation. Viavi’s debt and related interest expense were not attributed or allocated to us for

[0001633978-18-000108:mdna:24]
the periods presented since we are not the legal obligor of the debt and Viavi’s borrowings were not directly attributable to us. Certain intercompany transactions between us and Viavi were considered to be effectively settled in the consolidated financial statements at the time the transactions were recorded. The total net effect of the settlement of these intercompany transactions is reflected in our consolidated statements of cash flows as a financing activity and on the consolidated balance sheets as Viavi net investment.

[0001633978-18-000108:mdna:25]
The consolidated statements of operations include our direct expenses for cost of sales, R&D, sales and marketing, and administration as well as allocations of expenses arising from shared services and infrastructure provided by Viavi to us through the Separation. These allocated expenses include costs of information technology, human resources, accounting, legal, real estate and facilities, corporate marketing, insurance, treasury and other corporate and infrastructure services. In addition, other costs allocated to us include restructuring and stock-based compensation related to Viavi’s corporate and shared services employees as well as other public company costs. These expenses were allocated to us using estimates that we consider to be a reasonable reflection of the utilization of services provided to or benefits received by our business. The allocation methods include revenue, headcount, square footage, actual consumption and usage of services and others.

[0001633978-18-000108:mdna:26]
There were no allocations of expenses from Viavi for the fiscal years ended June 30, 2018 or July 1, 2017. Refer to “Note 3. Related Party Transactions” in the Notes to Consolidated Financial Statements for allocations during the fiscal year ended July 2, 2016.

[0001633978-18-000108:mdna:27]
Critical Accounting Policies and Estimates

[0001633978-18-000108:mdna:28]
The preparation of the consolidated financial statements in accordance with U.S. generally accepted accounting principles (“GAAP”) requires management to make estimates and assumptions that affect the amounts reported in our consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact us in the future, actual results may be different from the estimates. Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are short-term investments, impairment of marketable and non-marketable securities, inventory valuation, goodwill and intangibles, long-lived asset valuation, pension benefits, revenue recognition,  stock-based compensation, income taxes, restructuring, derivative liabilities,  business combinations, and warranty.

[0001633978-18-000108:mdna:29]
Our consolidated financial statements are prepared in accordance with GAAP as set forth in the Financial Accounting Standards Board’s Accounting Standards Codification (“ASC”), and we consider the various staff accounting bulletins and other applicable guidance issued by the United States Securities and Exchange Commission (“SEC”). GAAP, as set forth within the ASC, requires us to make certain estimates, judgments and assumptions. We believe that the estimates, judgments and assumptions upon which we rely are reasonable based upon information available to us at the time that these estimates, judgments and assumptions are made. These estimates, judgments and assumptions can affect the reported amounts of assets and liabilities as of the date of the financial statements as well as the reported amounts of revenues and expenses during the periods presented. To the extent there are differences between these estimates, judgments or assumptions and actual results, our financial statements will be affected. The accounting policies that reflect our more significant estimates, judgments and assumptions and which we believe are the most critical to aid in fully understanding and evaluating our reported financial results include the following:

[0001633978-18-000108:mdna:30]
| • | Inventory Valuation |

[0001633978-18-000108:mdna:31]
| • | Revenue Recognition |

[0001633978-18-000108:mdna:32]
| • | Income Taxes |

[0001633978-18-000108:mdna:33]
| • | Long-lived Asset Valuation |

[0001633978-18-000108:mdna:34]
| • | Warranty |

[0001633978-18-000108:mdna:35]
| • | Derivative Liability |

[0001633978-18-000108:mdna:36]
| • | Business Combinations |

[0001633978-18-000108:mdna:37]
| • | Goodwill |

[0001633978-18-000108:mdna:38]
On March 11, 2018, we entered into an Agreement and Plan of Merger with Oclaro, Prota Merger Sub, Inc., and Prota Merger, LLC, which was unanimously approved by the boards of directors of both Lumentum and Oclaro. The transaction is subject to customary closing conditions and is expected to close in the second half of calendar 2018. We added Business Combinations and Goodwill to our critical accounting policies and estimates in the third quarter of fiscal 2018.

[0001633978-18-000108:mdna:39]
Inventory Valuation

[0001633978-18-000108:mdna:40]
Inventory is valued at standard cost, which approximates actual cost computed on a first-in, first-out basis, not in excess of net realizable value. We assess the value of our inventory on a quarterly basis and write down those inventories which are obsolete or in excess of our forecasted usage to the lower of their cost or estimated net realizable value. Our estimates of realizable value

[0001633978-18-000108:mdna:41]
are based upon our analysis and assumptions including, but not limited to, forecasted sales levels and historical usage by product, expected product lifecycle, product development plans and future demand requirements. Our product line management personnel play a key role in our excess review process by providing updated sales forecasts, managing product transitions and working with manufacturing to minimize excess inventory. If actual market conditions are less favorable than our forecasts or actual demand from our customers is lower than our estimates, we may be required to record additional inventory write-downs. If actual market conditions are more favorable than anticipated, inventory previously written down may be sold, resulting in lower cost of sales and higher income from operations than expected in that period.

[0001633978-18-000108:mdna:42]
Revenue Recognition

[0001633978-18-000108:mdna:43]
During the periods presented, we recognized revenue when all four revenue recognition criteria have been met: (i) persuasive evidence of an arrangement exists, (ii) the product has been delivered or the service has been rendered, (iii) the price is fixed or determinable and (iv) collection is reasonably assured. Revenue from product sales is recorded when all of the foregoing conditions are met and risk of loss and title passes to the customer. Our products typically include a warranty and the estimated cost of product warranty claims, based on historical experience, is recorded at the time the sale is recognized. Sales to customers are generally not subject to price protection or return rights. The majority of our sales are made to OEMs, distributors, resellers and end-users.

[0001633978-18-000108:mdna:44]
We record as a reduction to revenues reserves for sales returns based upon historical experience rates and for any specific known customer amounts. We also provide certain distributors and OEMs with volume-pricing discounts, such as rebates and incentives, which are recorded as a reduction to revenues at the time of sale. Historically these volume discounts have not been significant. For revenue recognition changes related to implementation of ASU 2014-09, refer to “Note 2. Recent Accounting Pronouncements”.

[0001633978-18-000108:mdna:45]
Income Taxes

[0001633978-18-000108:mdna:46]
In accordance with the authoritative guidance on accounting for income taxes, we recognize income taxes using an asset and liability approach. This approach requires the recognition of taxes payable or refundable for the current year and deferred tax liabilities and assets for the future tax consequences of events that have been recognized in our consolidated financial statements or tax returns. The measurement of current and deferred taxes is based on provisions of the enacted tax law, and the effects of future changes in tax laws or rates are not anticipated.

[0001633978-18-000108:mdna:47]
The authoritative guidance provides for recognition of deferred tax assets if the realization of such deferred tax assets is more likely than not to occur based on an evaluation of both positive and negative evidence and the relative weight of the evidence. We consider future growth, forecasted earnings, future taxable income, the mix of earnings in the jurisdictions in which we operate, historical earnings, taxable income in prior years, if carryback is permitted under the law, and prudent and feasible tax planning strategies in determining the need for a valuation allowance. In the event we were to determine that we would not be able to realize all or part of our net deferred tax assets in the future, an adjustment to the deferred tax assets valuation allowance would be charged to earnings in the period in which we make such a determination, or goodwill would be adjusted at our final determination of the valuation allowance related to an acquisition within the measurement period. If we later determine that it is more likely than not that the net deferred tax assets would be realized, we would reverse the applicable portion of the previously provided valuation allowance as an adjustment to earnings at such time.

[0001633978-18-000108:mdna:48]
We are subject to income tax audits by the respective tax authorities of the jurisdictions in which we operate. The determination of our income tax liabilities in each of these jurisdictions requires the interpretation and application of complex, and sometimes uncertain, tax laws and regulations. The authoritative guidance on accounting for income taxes prescribes both recognition and measurement criteria that must be met for the benefit of a tax position to be recognized in the financial statements.  If a tax position taken, or expected to be taken, in a tax return does not meet such recognition or measurement criteria, an unrecognized tax benefit liability is recorded.  If we ultimately determine that an unrecognized tax benefit liability is no longer necessary, we reverse the liability and recognize a tax benefit in the period in which it is determined that the unrecognized tax benefit liability is no longer necessary.

[0001633978-18-000108:mdna:49]
The recognition and measurement of current taxes payable or refundable and deferred tax assets and liabilities requires that we make certain estimates and judgments. Changes to these estimates or a change in judgment may have a material impact on our tax provision in a future period.

[0001633978-18-000108:mdna:50]
Long-lived Asset Valuation

[0001633978-18-000108:mdna:51]
We test long-lived assets for recoverability, at the asset group level, when events or changes in circumstances indicate that their carrying amount may not be recoverable. Circumstances which could trigger a review include, but are not limited to: significant decreases in the market price of the asset, significant adverse changes in the business climate or legal factors, accumulation of

[0001633978-18-000108:mdna:52]
costs significantly in excess of the amount originally expected for the acquisition or construction of the asset, current period cash flow or operating losses combined with a history of losses or a forecast of continuing losses associated with the use of the asset, or current expectation that the asset will more likely than not be sold or disposed significantly before the end of its estimated useful life.

[0001633978-18-000108:mdna:53]
Recoverability is assessed based on the difference between the carrying amount of the asset and the sum of the undiscounted cash flows expected to result from the use and the eventual disposal of the asset. An impairment loss is recognized when the carrying amount is not recoverable and exceeds fair value.

[0001633978-18-000108:mdna:54]
Warranty

[0001633978-18-000108:mdna:55]
We provide reserves for the estimated costs of product warranties at the time revenue is recognized. We estimate the costs of our warranty obligations based on our historical experience of known product failure rates, use of materials to repair or replace defective products and service delivery costs incurred in correcting product failures. In addition, from time to time, specific warranty accruals may be made if unforeseen technical problems arise.

[0001633978-18-000108:mdna:56]
Derivative Liability

[0001633978-18-000108:mdna:57]
The Series A Preferred Stock issued by our subsidiary Lumentum Inc. is redeemable at the option of the holder after five years and classified as non-controlling interest redeemable convertible preferred stock in our consolidated balance sheet and is measured at its redemption value. The Series A Preferred Stock conversion feature is bifurcated from the Series A Preferred Stock and accounted for separately as a derivative liability. In March 2017, we issued $450.0 million in aggregate principal amount of 0.25% Convertible Senior Notes due in March 2024 (the “2024 Notes”), unless earlier repurchased by us or converted pursuant to their terms. Prior to the Tax Matters Agreement settlement condition (“TMA settlement condition”), because we could only settle the 2024 Notes in cash, we determined that the conversion feature met the definition of a derivative liability. We separated the derivative liability from the host debt instrument based on the fair value of the derivative liability. On June 29, 2017, we met the requirements to account for the conversion option of the 2024 Notes as equity and the conversion option is no longer marked to market. On a quarterly basis, the derivative liability for the Series A Preferred Stock is marked to market based on the fair value of the conversion feature, with the resulting income or loss recorded as unrealized loss on the derivative liabilities on our consolidated statements of operations. The determination of fair value includes various inputs, including volatility and interest rate assumptions. However, the change in the fair value of our common stock has the largest impact to the fair value of the derivatives. During fiscal 2018, 2017, and 2016, we recognized unrealized loss on derivative liabilities of $0.8 million, $104.2 million, and $0.6 million, respectively.

[0001633978-18-000108:mdna:58]
Business Combinations

[0001633978-18-000108:mdna:59]
In accordance with the guidance for business combinations, we determine whether a transaction or other event is a business combination, which requires that the assets acquired and liabilities assumed constitute a business. Each business combination is then accounted for by applying the acquisition method. If the assets acquired are not a business, we account for the transaction or other event as an asset acquisition. Under both methods, we recognize the identifiable assets acquired, the liabilities assumed, and any noncontrolling interest in the acquired entity. We capitalize acquisition-related costs and fees associated with asset acquisitions and immediately expense acquisition-related costs and fees associated with business combinations.

[0001633978-18-000108:mdna:60]
We allocate the fair value of purchase consideration to the tangible assets acquired, liabilities assumed and intangible assets acquired based on their estimated fair values. The excess of the fair value of purchase consideration over the fair values of these identifiable assets and liabilities is recorded as goodwill. When determining the fair values of assets acquired and liabilities assumed, we make significant estimates and assumptions, especially with respect to intangible assets. Critical estimates in valuing certain intangible assets include, but are not limited to, future expected cash flows from customer relationships and acquired developed technology and discount rates. Our estimates of fair value are based upon assumptions believed to be reasonable, but which are inherently uncertain and unpredictable and, as a result, actual results may differ materially from estimates. Other estimates associated with the accounting for acquisitions may change as additional information becomes available regarding the assets acquired and liabilities assumed. Any change in facts and circumstances that existed as of the acquisition date and impacts our preliminary estimates is recorded to goodwill if identified within the measurement period. Subsequent to the measurement period or our final determination of fair value of assets and liabilities whichever is earlier the adjustments will affect our earnings.

[0001633978-18-000108:mdna:61]
In addition, we estimate the economic lives of certain acquired assets and these lives are used to calculate depreciation and amortization expense. If our estimates of the economic lives change, depreciation or amortization expenses could be accelerated or slowed.

[0001633978-18-000108:mdna:62]
Goodwill

[0001633978-18-000108:mdna:63]
Goodwill represents the excess of the purchase price of an acquired business over the fair value of the identifiable assets acquired and liabilities assumed. We test for impairment of goodwill on an annual basis in the fourth quarter and at any other time when events occur or circumstances indicate that the carrying amount of goodwill may not be recoverable.

[0001633978-18-000108:mdna:64]
An entity has the option to first assess qualitative factors to determine whether it is necessary to perform the two-step quantitative goodwill impairment test. If an entity determines that as a result of the qualitative assessment that it is more likely than not (i.e., greater than 50% likelihood) that the fair value of a reporting unit is less than its carrying amount, then the quantitative test is required. Otherwise, no further testing is required. The two-step quantitative goodwill impairment test requires us to estimate the fair value of our reporting units. If the carrying value of a reporting unit exceeds its fair value, the goodwill of that reporting unit is potentially impaired and we proceed to step two of the impairment analysis. In step two of the analysis, we measure and record an impairment loss equal to the excess of the carrying value of the reporting unit’s goodwill over its implied fair value, if any.

[0001633978-18-000108:mdna:65]
Application of the goodwill impairment test requires judgments, including: identification of the reporting units, assigning assets and liabilities to reporting units, assigning goodwill to reporting units, a qualitative assessment to determine whether there are any impairment indicators, and determining the fair value of each reporting unit. We estimate the fair value of a reporting unit using market approach, income approach or a combination of market and income approach. Significant estimates in the market approach include: identifying similar companies with comparable business factors such as size, growth, profitability, risk and return on investment, and assessing comparable revenue and operating income multiples in estimating the fair value of the reporting unit. Significant estimates in the income approach include: future cash flows, discount rates.

[0001633978-18-000108:mdna:66]
We base our estimates on historical experience and on various assumptions about the future that we believe are reasonable based on available information. Unanticipated events and circumstances may occur that affect the accuracy of our assumptions, estimates and judgments. For example, if the price of our common stock were to significantly decrease combined with other adverse changes in market conditions, thus indicating that the underlying fair value of our reporting units may have decreased, we might be required to reassess the value of our goodwill in the period such circumstances were identified.

[0001633978-18-000108:mdna:67]
Based on the impairment analysis performed in the fourth quarter of each year presented, the fair value of our reporting unit substantially exceeded the carrying value; as such, our annual qualitative assessment did not indicate that a more detailed quantitative analysis was necessary.

[0001633978-18-000108:mdna:68]
In many cases, the accounting treatment of a particular transaction is specifically dictated by GAAP and does not require management’s judgment in its application. There are also areas in which management’s judgment in selecting among available alternatives would not produce a materially different result. Our senior management has reviewed our critical accounting policies and related disclosures with the Audit Committee of our board of directors.

[0001633978-18-000108:mdna:69]
Recently Issued Accounting Pronouncements

[0001633978-18-000108:mdna:70]
Refer to “Note 2. Recent Accounting Pronouncements” in the Notes to Consolidated Financial Statements.

[0001633978-18-000108:mdna:71]
RESULTS OF OPERATIONS

[0001633978-18-000108:mdna:72]
The results of operations for the periods presented are not necessarily indicative of results to be expected for future periods. The following table summarizes selected Consolidated Statements of Operations items as a percentage of net revenue:

[0001633978-18-000108:mdna:73]
|  | Years Ended |
|  | June 30, 2018 |  | July 1, 2017 |  | July 2, 2016 |
| Segment net revenue: |  |  |  |  |  |
| OpComms | 84.9 | % |  | 85.6 | % |  | 84.3 | % |
| Lasers | 15.1 |  |  | 14.4 |  |  | 15.7 |  |
| Net revenue | 100.0 |  |  | 100.0 |  |  | 100.0 |  |
| Cost of sales | 65.1 |  |  | 67.6 |  |  | 68.5 |  |
| Amortization of acquired developed technologies | 0.3 |  |  | 0.6 |  |  | 0.8 |  |
| Gross profit | 34.6 |  |  | 31.8 |  |  | 30.7 |  |
| Operating expenses: |  |  |  |  |  |
| Research and development | 12.6 |  |  | 14.8 |  |  | 15.6 |  |
| Selling, general and administrative | 10.3 |  |  | 11.0 |  |  | 13.0 |  |
| Restructuring and related charges | 0.6 |  |  | 1.2 |  |  | 0.8 |  |
| Total operating expenses | 23.4 |  |  | 27.0 |  |  | 29.4 |  |
| Income from operations | 11.2 |  |  | 4.8 |  |  | 1.3 |  |
| Unrealized loss on derivative liabilities | (0.1 | ) |  | (10.4 | ) |  | (0.1 | ) |
| Interest and other income (expense), net | (0.8 | ) |  | (0.3 | ) |  | (0.1 | ) |
| Income (loss) before income taxes | 10.4 |  |  | (6.0 | ) |  | 1.1 |  |
| Provision for (benefit from) income taxes | (9.5 | ) |  | 4.3 |  |  | 0.1 |  |
| Net income (loss) | 19.9 | % |  | (10.2 | )% |  | 1.0 | % |

[0001633978-18-000108:mdna:74]
Financial Data for Fiscal 2018, 2017 and 2016

[0001633978-18-000108:mdna:75]
The following table summarizes selected Consolidated Statements of Operations items (in millions, except for percentages):

[0001633978-18-000108:mdna:76]
|  | 2018 |  | 2017 |  | Change |  | Percentage Change |  | 2017 |  | 2016 |  | Change |  | Percentage Change |
| Segment net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| OpComms | $ | 1,059.2 |  |  | $ | 857.8 |  |  | $ | 201.4 |  |  | 23.5 | % |  | $ | 857.8 |  |  | $ | 761.3 |  |  | $ | 96.5 |  |  | 12.7 | % |
| Lasers | 188.5 |  |  | 143.8 |  |  | 44.7 |  |  | 31.1 |  |  | 143.8 |  |  | 141.7 |  |  | 2.1 |  |  | 1.5 |  |
| Net revenue | $ | 1,247.7 |  |  | $ | 1,001.6 |  |  | $ | 246.1 |  |  | 24.6 | % |  | $ | 1,001.6 |  |  | $ | 903.0 |  |  | $ | 98.6 |  |  | 10.9 | % |
| Gross profit | $ | 432.1 |  |  | $ | 318.1 |  |  | $ | 114.0 |  |  | 35.8 | % |  | $ | 318.1 |  |  | $ | 277.3 |  |  | $ | 40.8 |  |  | 14.7 | % |
| Gross margin | 34.6 | % |  | 31.8 | % |  |  |  |  |  | 31.8 | % |  | 30.7 | % |  |  |  |  |
| Research and development | $ | 156.8 |  |  | $ | 148.3 |  |  | $ | 8.5 |  |  | 5.7 | % |  | $ | 148.3 |  |  | $ | 141.1 |  |  | $ | 7.2 |  |  | 5.1 | % |
| Percentage of net revenue | 12.6 | % |  | 14.8 | % |  |  |  |  |  | 14.8 | % |  | 15.6 | % |  |  |  |  |
| Selling, general and administrative | $ | 128.2 |  |  | $ | 110.2 |  |  | $ | 18.0 |  |  | 16.3 | % |  | $ | 110.2 |  |  | $ | 117.3 |  |  | $ | (7.1 | ) |  | (6.1 | )% |
| Percentage of net revenue | 10.3 | % |  | 11.0 | % |  |  |  |  |  | 11.0 | % |  | 13.0 | % |  |  |  |  |
| Restructuring and related charges | $ | 7.2 |  |  | $ | 12.0 |  |  | $ | (4.8 | ) |  | (40.0 | )% |  | $ | 12.0 |  |  | $ | 7.4 |  |  | $ | 4.6 |  |  | 62.2 | % |
| Percentage of net revenue | 0.6 | % |  | 1.2 | % |  |  |  |  |  | 1.2 | % |  | 0.8 | % |  |  |  |  |

[0001633978-18-000108:mdna:77]
42

[0001633978-18-000108:mdna:78]
Net Revenue

[0001633978-18-000108:mdna:79]
Net revenue increased by $246.1 million, or 24.6% during fiscal 2018 compared to fiscal 2017. This increase was primarily due to record revenues in 3D sensing, TrueFlex® ROADMs, commercial lasers, and industrial diode lasers.

[0001633978-18-000108:mdna:80]
OpComms net revenue increased $201.4 million, or 23.5%, during fiscal 2018 compared to fiscal 2017, driven by increased sales of Consumer and Industrial products of $386.7 million, primarily in 3D sensing for mobile devices and engage numerous customers globally, partially offset by decreased sales of Telecom and Datacom products.

[0001633978-18-000108:mdna:81]
Lasers net revenue increased $44.7 million, or 31.1%, in fiscal 2018 compared to fiscal 2017, primarily due to increased sales of our kilowatt class fiber lasers. Growth was driven by strong demand from customers in both the micro and macro material processing markets.

[0001633978-18-000108:mdna:82]
Net revenue increased by $98.6 million, or 10.9%, during fiscal 2017 compared to fiscal 2016. This increase was primarily due to an increase in net revenue from our OpComms segment. OpComms net revenue increased $96.5 million, or 12.7%, during fiscal 2017 compared to fiscal 2016, driven by increases from Telecom and 100G Datacom products. Lasers net revenue increased $2.1 million, or 1.5%, in fiscal 2017 compared to fiscal 2016.

[0001633978-18-000108:mdna:83]
During our fiscal 2018, 2017, and 2016, net revenue generated from a single end customer that represented 10% or greater of total net revenue is summarized as follows:

[0001633978-18-000108:mdna:84]
|  | Years Ended |
|  | June 30, 2018 |  | July 1, 2017 |  | July 2, 2016 |
| APPLE | 30.0 | % |  | * |  |  | * |  |
| HUAWEI | 11.0 | % |  | 16.7 | % |  | 17.1 | % |
| CIENA | 11.0 | % |  | 18.5 | % |  | 17.1 | % |
| CISCO | * |  |  | 12.4 | % |  | 13.0 | % |
| *Represents less than 10% of total net revenue |  |  |  |  |  |

[0001633978-18-000108:mdna:85]
Revenue by Region

[0001633978-18-000108:mdna:86]
We operate in three geographic regions: Americas, Asia-Pacific and EMEA. Net revenue is assigned to the geographic region and country where our product is initially shipped. For example, certain customers may request shipment of our product to a contract manufacturer in one country, however, the location of the end customers may differ. The following table presents net revenue by the three geographic regions we operate in and net revenue from countries that represented 10% or more of our total net revenue (in millions, except for percentages):

[0001633978-18-000108:mdna:87]
|  | Years Ended |
|  | June 30, 2018 |  | July 1, 2017 |  | July 2, 2016 |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |
| United States | $ | 115.1 |  |  | 9.2 | % |  | $ | 147.9 |  |  | 14.8 | % |  | $ | 162.3 |  |  | 18.0 | % |
| Mexico | 145.8 |  |  | 11.7 |  |  | 185.1 |  |  | 18.5 |  |  | 112.9 |  |  | 12.5 |  |
| Other Americas | 7.0 |  |  | 0.6 |  |  | 9.2 |  |  | 0.9 |  |  | 19.6 |  |  | 2.2 |  |
| Total Americas | $ | 267.9 |  |  | 21.5 | % |  | $ | 342.2 |  |  | 34.2 | % |  | $ | 294.8 |  |  | 32.7 | % |
| Asia-Pacific: |  |  |  |  |  |  |  |  |  |  |  |
| Hong Kong | $ | 183.0 |  |  | 14.7 | % |  | $ | 226.7 |  |  | 22.6 | % |  | $ | 214.0 |  |  | 23.7 | % |
| Japan | 194.7 |  |  | 15.6 |  |  | 99.2 |  |  | 9.9 |  |  | 92.9 |  |  | 10.3 |  |
| South Korea | 146.1 |  |  | 11.7 |  |  | 4.9 |  |  | 0.5 |  |  | 3.8 |  |  | 0.4 |  |
| Other Asia-Pacific | 354.2 |  |  | 28.3 |  |  | 220.5 |  |  | 22.0 |  |  | 174.0 |  |  | 19.2 |  |
| Total Asia-Pacific | $ | 878.0 |  |  | 70.3 | % |  | $ | 551.3 |  |  | 55.0 | % |  | $ | 484.7 |  |  | 53.6 | % |
| EMEA | $ | 101.8 |  |  | 8.2 | % |  | $ | 108.1 |  |  | 10.8 | % |  | $ | 123.5 |  |  | 13.7 | % |
| Total net revenue | $ | 1,247.7 |  |  |  |  | $ | 1,001.6 |  |  |  |  | $ | 903.0 |  |  |  |

[0001633978-18-000108:mdna:88]
During fiscal 2018, 2017 and 2016, net revenue from customers outside the United States, based on customer shipping location, represented 90.8%, 85.2% and 82.0% of net revenue, respectively.

[0001633978-18-000108:mdna:89]
Our net revenue is primarily denominated in U.S. dollars, including our net revenue from customers outside the United States as presented above. We expect revenue from customers outside of the United States to continue to be an important part of our overall net revenue and an increasing focus for net revenue growth opportunities. However, regulatory and enforcement actions by U.S. and other governmental agencies, as well as changes in tax and trade policies and tariffs, may impact net revenue from customers outside the United States in future periods.

[0001633978-18-000108:mdna:90]
Gross Margin and Segment Gross Margin

[0001633978-18-000108:mdna:91]
The following table summarizes segment gross margin for fiscal 2018, 2017 and 2016 (in millions, except for percentages):

[0001633978-18-000108:mdna:92]
|  | Gross Profit |  | Gross Margin |
|  | 2018 |  | 2017 |  | 2016 |  | 2018 |  | 2017 |  | 2016 |
| OpComms | $ | 402.3 |  |  | $ | 287.3 |  |  | $ | 236.3 |  |  | 38.0 | % |  | 33.5 | % |  | 31.0 | % |
| Lasers | 82.8 |  |  | 59.9 |  |  | 61.4 |  |  | 43.9 | % |  | 41.7 | % |  | 43.3 | % |
| Segment total | $ | 485.1 |  |  | $ | 347.2 |  |  | $ | 297.7 |  |  | 38.9 | % |  | 34.7 | % |  | 33.0 | % |
| Unallocated corporate items (1) | (53.0 | ) |  | (29.1 | ) |  | (20.4 | ) |  |  |  |  |  |  |
| Total | $ | 432.1 |  |  | $ | 318.1 |  |  | $ | 277.3 |  |  | 34.6 | % |  | 31.8 | % |  | 30.7 | % |

[0001633978-18-000108:mdna:93]
(1) The unallocated corporate items for the years presented include the effects of amortization of acquired developed technologies, share-based compensation and certain other charges. We do not allocate these items to the gross margin for each segment because management does not include such information in measuring the performance of the operating segments.

[0001633978-18-000108:mdna:94]
The increase in unallocated corporate items during fiscal 2018 compared to fiscal 2017, primarily relates to set-up costs of our facility in Thailand, including costs of transferring the manufacturing of product lines to Thailand of $27.0 million in our fiscal 2018 compared to $1.8 million in fiscal 2017. The increase in unallocated corporate items during fiscal 2017 compared to fiscal 2016, primarily relates to inventory write-downs due to canceled programs not allocated to the segments of $7.9 million incurred in fiscal 2017.

[0001633978-18-000108:mdna:95]
Gross Margin

[0001633978-18-000108:mdna:96]
Gross margin in fiscal 2018 increased to 34.6% from 31.8% in fiscal 2017. The increase was primarily due to increased sales in our 3D sensing and lasers products, which have higher gross margins than the average for the Company. The increase was partially offset by underutilized capacity costs due to the decline in Telecom and Datacom demand, higher write-downs of excess and obsolete inventory of $1.2 million, as well as set-up costs of our facility in Thailand, including costs of transferring product lines to Thailand of $27.0 million in our fiscal 2018 compared to $1.8 million in fiscal 2017.

[0001633978-18-000108:mdna:97]
Gross margin in fiscal 2017 increased to 31.8% from 30.7% in fiscal 2016. This increase was primarily due to an increase in OpComms gross margins, partially offset by a decrease in Lasers gross margins.

[0001633978-18-000108:mdna:98]
We sell products in certain markets that are consolidating, undergoing product, architectural and business model transitions, have high customer concentrations, are highly competitive, are price sensitive and/or are affected by customer seasonal and mix variant buying patterns. We expect these factors to continue to result in variability of our gross margin.

[0001633978-18-000108:mdna:99]
Segment Gross Margin

[0001633978-18-000108:mdna:100]
OpComms

[0001633978-18-000108:mdna:101]
OpComms gross margin in fiscal 2018 increased to 38.0% from 33.5% in fiscal 2017. This increase was primarily due to increased sales of our 3D sensing products, which have higher gross margins than the average for the segment. The increase was partially offset by underutilized capacity costs due to the decline in Telecom and Datacom demand.

[0001633978-18-000108:mdna:102]
OpComms gross margin in fiscal 2017 increased to 33.5% from 31.0% in fiscal 2016. This increase was primarily due to higher revenue volume and product mix.

[0001633978-18-000108:mdna:103]
Lasers

[0001633978-18-000108:mdna:104]
Lasers gross margin in fiscal 2018 increased to 43.9% from 41.7% in fiscal 2017. This increase was primarily due to increased sales of solid state lasers products, which have higher gross margins than the average for the segment.

[0001633978-18-000108:mdna:105]
Lasers gross margin in fiscal 2017 decreased to 41.7% from 43.3% in fiscal 2016. This decrease was primarily due to higher manufacturing and warranty costs.

[0001633978-18-000108:mdna:106]
Research and Development

[0001633978-18-000108:mdna:107]
R&D expense increased by $8.5 million, or 5.7%, in fiscal 2018 compared to fiscal 2017. The increase in R&D expense was primarily due to the increase in stock-based compensation of $2.6 million and payroll related expense of $4.1 million, which includes an increase in variable incentive compensation of $2.9 million.

[0001633978-18-000108:mdna:108]
R&D expense increased by $7.2 million, or 5.1%, in fiscal 2017 compared to fiscal 2016. The increase in R&D expense was primarily due to the increase in the payroll related expense of $8.6 million, which includes an increase of stock-based compensation of $2.6 million. This was partially offset by higher partner reimbursements for development expense.

[0001633978-18-000108:mdna:109]
We believe that continuing our investments in R&D is critical to attaining our strategic objectives. We plan to continue to invest in R&D and new products that we believe will further differentiate us in the marketplace and expect our investment to increase in absolute dollars in future quarters.

[0001633978-18-000108:mdna:110]
Selling, General and Administrative

[0001633978-18-000108:mdna:111]
SG&A expense increased $18.0 million, or 16.3%, in fiscal 2018 compared to fiscal 2017. The increase was primarily attributable to increases in stock based compensation of $6.4 million and payroll related expense of $10.5 million, which includes

[0001633978-18-000108:mdna:112]
an increase in variable incentive compensation of $3.8 million. We also incurred $4.8 million of costs related to the planned acquisition of Oclaro during our fiscal 2018.

[0001633978-18-000108:mdna:113]
SG&A expense decreased $7.1 million, or 6.1%, in fiscal 2017 compared to fiscal 2016. The decrease was primarily a result of reduced separation related charges and restructuring expenses of $13.6 million.  This decrease was partially offset by an increase in payroll related expense of $7.8 million and an increase in stock-based compensation of $1.8 million.

[0001633978-18-000108:mdna:114]
We expect to experience in the future certain non-core expenses, such as mergers and acquisition-related expenses and litigation expenses, which will likely increase our SG&A expenses and potentially impact our profitability expectations in any particular quarter.

[0001633978-18-000108:mdna:115]
Restructuring and Related Charges

[0001633978-18-000108:mdna:116]
We have reduced costs through targeted restructuring efforts intended to consolidate our operations, rationalize the manufacturing of our products and align our business in response to market conditions. Refer to “Note 14. Restructuring and Related Charges” in the Notes to Consolidated Financial Statements.

[0001633978-18-000108:mdna:117]
During fiscal 2018, we recorded $7.2 million in restructuring and related charges in the consolidated statements of operations.

[0001633978-18-000108:mdna:118]
| • | During the fourth quarter of fiscal 2018, we initiated a new restructuring plan in order to realign the organization and enable further investment in key priority areas. As a result, a restructuring charge of $3.4 million was recorded for severance costs and employee benefits. In total, 52 employees in manufacturing, R&D and SG&A functions were terminated in connection with this new restructuring plan. |

[0001633978-18-000108:mdna:119]
| • | We also incurred restructuring and related charges of $3.8 million from restructuring plans approved prior to fiscal 2016 primarily related to the shut down of our manufacturing facility in Bloomfield, Connecticut as a result of the transfer of certain production processes into existing sites in the United States or to contract manufacturers. |

[0001633978-18-000108:mdna:120]
During fiscal 2017, we recorded $12.0 million in restructuring and related charges. Of the $12.0 million charge recorded during fiscal 2017, $2.1 million related to severance, retention and employee benefits.

[0001633978-18-000108:mdna:121]
During fiscal 2016, we recorded $7.7 million in restructuring and related charges.

[0001633978-18-000108:mdna:122]
| • | During the fourth quarter of fiscal 2016, management approved a plan to optimize operations and gain efficiencies throughout the organization. As a result, a restructuring charge of $0.7 million was recorded for severance and employee benefits during fiscal 2016. In total, 18 employees in manufacturing, R&D and SG&A functions were terminated in connection with this restructuring plan. Payments related to the remaining severance and benefits accrual have been paid in full. |

[0001633978-18-000108:mdna:123]
| • | We also incurred restructuring and related charges of $7.0 million from restructuring plans approved prior to fiscal 2016 primarily related to manufacturing transfer costs for transfer of certain production processes into existing sites in the United States or to contract manufacturers. |

[0001633978-18-000108:mdna:124]
Interest and Other Income (Expense), Net

[0001633978-18-000108:mdna:125]
The components of interest and other income (expense), net are as follows (in millions):

[0001633978-18-000108:mdna:126]
|  | Years Ended |
|  | June 30, 2018 |  | July 1, 2017 |  | July 2, 2016 |
| Interest expense | $ | (18.2 | ) |  | $ | (5.5 | ) |  | $ | (0.1 | ) |
| Foreign exchange gains (losses), net | (0.3 | ) |  | 0.6 |  |  | (0.9 | ) |
| Interest income | 8.5 |  |  | 1.1 |  |  | — |  |
| Other income (expense), net | 0.3 |  |  | 0.6 |  |  | (0.2 | ) |
| Interest and other income (expense), net | $ | (9.7 | ) |  | $ | (3.2 | ) |  | $ | (1.2 | ) |

[0001633978-18-000108:mdna:127]
During fiscal 2018, interest and other income (expense), net increased by $6.5 million compared to fiscal 2017, driven by amortization of the debt discount on the 2024 Notes of $16.7 million in our fiscal 2018 compared to $5.1 million in fiscal 2017, partially offset by interest income on the short-term investments and cash equivalents of $8.5 million in our fiscal 2018 compared to $1.1 million in fiscal 2017. Refer to “Note 11. Convertible Senior Notes”

[0001633978-18-000108:mdna:128]
Interest and other income (expense), net was $(3.2) million in fiscal 2017 as compared to $(1.2) million in fiscal 2016. The $2.0 million change was primarily due to amortization of the debt discount on the 2024 Notes in fiscal 2017 of $5.1 million offset by interest income on the short-term investments and cash equivalents of $1.1 million.

[0001633978-18-000108:mdna:129]
Unrealized Gain (Loss) on Derivative Liabilities

[0001633978-18-000108:mdna:130]
Unrealized loss on Series A Preferred Stock derivative liability amounted to $0.8 million, $41.3 million, and $0.6 million for the fiscal years 2018, 2017, and 2016, respectively. The change is primarily related to the change in the price of our underlying common stock and is reflected in the consolidated statements of operations as “Unrealized gain (loss) on derivative liabilities”. For further discussion of our derivative liability, see “Note 12. Derivative Liability” in the Notes to Consolidated Financial Statements.

[0001633978-18-000108:mdna:131]
Unrealized loss on the derivate liability from the 2024 Notes in the amount of $62.9 million is also included in the “Unrealized gain (loss) on derivative liabilities” of our consolidated statements of operations for the year ended July 1, 2017. On June 29, 2017, we met the requirements to account for the conversion option of the 2024 Notes as equity and the conversion option is no longer marked to market. Refer to “Note 11. Convertible Senior Notes” in the Notes to Consolidated Financial Statements.

[0001633978-18-000108:mdna:132]
Provision for (Benefit from) Income Taxes (in millions)

[0001633978-18-000108:mdna:133]
|  | Years Ended |
|  | June 30, 2018 |  | July 1, 2017 |  | July 2, 2016 |
| Provision for (benefit from) income taxes | $ | (118.7 | ) |  | $ | 42.7 |  |  | $ | 0.4 |  |

[0001633978-18-000108:mdna:134]
We recorded a provision (benefit) for income taxes of $(118.7) million, $42.7 million, and $0.4 million in fiscal 2018, 2017, and 2016, respectively.

[0001633978-18-000108:mdna:135]
Our provision for income taxes for fiscal 2018 differed from the tax provision based on the U.S. statutory federal income tax rate of approximately 28% as a result of $207.2 million of income tax benefit related to the release of valuation allowance against our U.S. federal and certain state deferred tax assets, partially offset by $80.5 million of income tax expense related to the remeasurement of our net deferred tax assets as a result of reduction in the U.S. federal corporate tax rate.  Our provision for income taxes was also impacted by the benefit our foreign income being taxed at lower rates than the U.S. statutory rate, as well as the benefit of research and development tax credits.

[0001633978-18-000108:mdna:136]
Our provision for income taxes for fiscal 2017 differed from the tax provision based on the then-U.S. statutory federal income tax rate of 35% primarily as a result of $36.5 million of income tax expense related to the non-deductible unrealized losses associated with the embedded derivatives for the Series A Preferred Stock and the 2024 Notes, as well as $8.4 million of unrecognized tax benefits, $4.9 million of non-deductible stock-based compensation, and $21.5 million of changes in the valuation allowance against our deferred tax assets.  Our provision for income taxes was also impacted by the benefit of our foreign income being taxed at lower rates than the U.S. statutory rate, as well as the income tax benefit of research and development tax credits.

[0001633978-18-000108:mdna:137]
Our effective tax rate of 4.1% in fiscal 2016 differed from the then-U.S. statutory federal income tax rate of 35%, primarily due to changes in the valuation allowance against our deferred tax assets, offset by the benefit of our foreign income being taxed at different rates than the U.S. statutory rates.

[0001633978-18-000108:mdna:138]
As of June 30, 2018, we had net deferred tax assets of $125.3 million, which were mainly comprised of goodwill and intangible assets related to tax assets established in the spin-off from JDSU.

[0001633978-18-000108:mdna:139]
During fiscal 2018, our subsidiary in Thailand operated under a tax holiday. The tax holiday will expire in fiscal 2025 unless extension is granted by the Thailand government and we continue to meet the requirements thereunder.  If we do not meet the tax holiday requirements or we decide not to extend the tax holiday, income earned in Thailand will be subject to higher statutory income tax rate, which may cause our effective tax rate to increase.

[0001633978-18-000108:mdna:140]
For further discussion of our income tax provision, see “Note 15. Income Taxes” in the Notes to Consolidated Financial Statements.

[0001633978-18-000108:mdna:141]
Contractual Obligations

[0001633978-18-000108:mdna:142]
The following table summarizes our contractual obligations as of June 30, 2018, and the effect such obligations are expected to have on our liquidity and cash flow over the next five years (in millions):

[0001633978-18-000108:mdna:143]
|  | Payments due by period |
|  | Total |  | Less than 1 year |  | 1 - 3 years |  | 3 - 5 years |  | More than 5 years |
| Contractual Obligations |  |  |  |  |  |  |  |  |  |
| Asset retirement obligations | $ | 2.7 |  |  | $ | — |  |  | $ | 1.0 |  |  | $ | 0.4 |  |  | $ | 1.3 |  |
| Purchase obligations (1) | 173.5 |  |  | 165.5 |  |  | 7.9 |  |  | — |  |  | 0.1 |  |
| Operating lease obligations (1) | 30.8 |  |  | 11.6 |  |  | 11.6 |  |  | 5.8 |  |  | 1.8 |  |
| Capital lease obligation (1) | 9.4 |  |  | 9.0 |  |  | 0.4 |  |  | — |  |  | — |  |
| Pension plan contributions (2) | 0.5 |  |  | 0.5 |  |  | — |  |  | — |  |  | — |  |
| 0.25% Convertible Senior Notes due 2024 | 450.0 |  |  | — |  |  | — |  |  | — |  |  | 450.0 |  |
| Interest on 2024 Notes (3) | 6.7 |  |  | 1.1 |  |  | 2.2 |  |  | 2.2 |  |  | 1.2 |  |
| Acquisition contingencies (4) | 3.0 |  |  | — |  |  | 3.0 |  |  | — |  |  | — |  |
| Total | $ | 676.6 |  |  | $ | 187.7 |  |  | $ | 26.1 |  |  | $ | 8.4 |  |  | $ | 454.4 |  |

[0001633978-18-000108:mdna:144]
(1) Refer to “Note 18. Commitments and Contingencies” in the Notes to Consolidated Financial Statements.

[0001633978-18-000108:mdna:145]
(2) Represents planned contributions to our pension plan. Although additional future contributions will be required, the amount and timing of these contributions will be affected by actuarial assumptions, the actual rate of returns on plan assets, the level of market interest rates, legislative changes, and the amount of voluntary contributions to the plan. Any contributions for the following fiscal year and later will depend on the value of the plan assets in the future and thus are uncertain. As such, we have not included any amounts beyond 1 year in the table above. Refer to “Note 17. Employee Benefit Plans” in the Notes to Consolidated Financial Statements.

[0001633978-18-000108:mdna:146]
(3) Includes interest on our 0.25% Convertible Senior Notes due 2024 through March 2024 as we have the right to redeem the 2024 Notes in whole or in part at any time on or after March 15, 2024. Refer to “Note 11. Convertible Senior Notes” in the Notes to Consolidated Financial Statements.

[0001633978-18-000108:mdna:147]
(4) Refer to “Note 9. Fair Value Measurements” in the Notes to Consolidated Financial Statements.

[0001633978-18-000108:mdna:148]
Purchase obligations represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements.

[0001633978-18-000108:mdna:149]
As of June 30, 2018, asset retirement obligations presented in the preceding table are included in other non-current liabilities on our consolidated balance sheet. As of June 30, 2018, our other non-current liabilities also include $6.1 million of unrecognized tax benefit for uncertain tax positions. We are unable to reliably estimate the timing of future payments related to uncertain tax positions and therefore have excluded them from the preceding table.

[0001633978-18-000108:mdna:150]
In addition to the obligations discussed above, at the time of the closing of the Oclaro acquisition, which is expected in the next fiscal year, we will be required to pay cash consideration as described further in “Acquisitions” below. We also expect to incur indebtedness in an aggregate principal amount of approximately $500 million pursuant to a senior secured term loan facility entered into in connection with the closing of the Oclaro acquisition.

[0001633978-18-000108:mdna:151]
Off-Balance Sheet Arrangements

[0001633978-18-000108:mdna:152]
We do not have any off-balance sheet arrangements, as such term is defined in rules promulgated by the SEC, that have or are reasonably likely to have a current or future effect on our financial condition, changes in financial condition, revenues or expenses, results of operations, liquidity, capital expenditures or capital resources that are material to investors.

[0001633978-18-000108:mdna:153]
Acquisitions

[0001633978-18-000108:mdna:154]
As part of our strategy, we are committed to the ongoing evaluation of strategic opportunities and, where appropriate, the acquisition of additional products, technologies or businesses that are complementary to, or broaden the markets for, our products.

[0001633978-18-000108:mdna:155]
We believe we have strengthened our business model by expanding our addressable markets, customer base and expertise, diversifying our product portfolio, and fortifying our core businesses through acquisitions as well as through organic initiatives.

[0001633978-18-000108:mdna:156]
On March 11, 2018, we entered into an Agreement and Plan of Merger (the “Merger Agreement”) with Oclaro, Inc. (“Oclaro”), Prota Merger Sub, Inc., and Prota Merger, LLC, pursuant to which we will acquire Oclaro and Oclaro will become a wholly-owned subsidiary of Lumentum. In accordance with the terms of the Merger Agreement, each issued and outstanding share of Oclaro common stock will be exchanged for $5.60 in cash and 0.0636 of a share of Lumentum common stock, subject to the conditions and restrictions set forth in the Merger Agreement. The total transaction consideration was approximately $1.8 billion as of the date of the Merger Agreement. Oclaro stockholders will own approximately 16% of the combined company following the closing. Oclaro’s stockholders approved the Merger Agreement on July 10, 2018 and we have received approval for the transaction under the Hart-Scott Rodino Act in the United States. We are in the process of obtaining antitrust approval in China. The Merger Agreement contains certain termination rights for both Lumentum and Oclaro. The Merger Agreement further provides that upon termination of the Merger Agreement under specified circumstances relating to failure to obtain regulatory approvals, Lumentum may be required to pay Oclaro a termination fee of $80 million.

[0001633978-18-000108:mdna:157]
As of August 23, 2018, the total transaction consideration was expected to be approximately $1.7 billion, which would be funded by a combination of $700 million in Lumentum common stock, $500 million in new debt, and the remaining amount from the cash balances of the combined company.

[0001633978-18-000108:mdna:158]
In February 2017, we completed the acquisition of a privately held company to enhance our manufacturing and vertical integration capabilities. We acquired all of the outstanding shares of the company for a total purchase consideration of $8.7 million.  In connection with the acquisition, we paid upfront cash consideration of $5.1 million, incurred liabilities of $2.7 million contingent upon the achievement of certain production targets being achieved within 36 months following the acquisition date, and retained $0.9 million of the purchase price as security for the seller’s indemnification obligations, which was fully paid to the seller subsequent to the year ended June 30, 2018.

[0001633978-18-000108:mdna:159]
Pension Benefits

[0001633978-18-000108:mdna:160]
As a result of acquiring Time-Bandwidth in January 2014, we have a pension plan for our employees in Switzerland. This plan is open to new participants and additional service costs are being accrued. The Switzerland plan is partially funded. As of June 30, 2018, our pension plan was under funded by $3.5 million since the projected benefit obligation (“PBO”) exceeded the fair value of the plan assets.

[0001633978-18-000108:mdna:161]
We expect to contribute $0.5 million to the Switzerland plan during fiscal 2019.

[0001633978-18-000108:mdna:162]
A key actuarial assumption in calculating the net periodic cost and the PBO is the discount rate. Changes in the discount rate impact the interest cost component of the net periodic benefit cost calculation and PBO due to the fact that the PBO is calculated on a net present value basis. Decreases in the discount rate will generally increase pre-tax cost, recognized expense and the PBO. Increases in the discount rate tend to have the opposite effect. We estimate a 50 basis point decrease or increase in the discount rate would cause a corresponding increase or decrease, respectively, in the PBO of $1.3 million or $(1.1) million, based upon data as of June 30, 2018.

[0001633978-18-000108:mdna:163]
Financial Condition

[0001633978-18-000108:mdna:164]
Liquidity and Capital Resources

[0001633978-18-000108:mdna:165]
As of June 30, 2018 and July 1, 2017, our cash and cash equivalents of $397.3 million and $272.9 million, respectively, were held predominantly in the United States. The total amount of cash outside the United States as of June 30, 2018 was $37.8 million, which was primarily held in Cayman Islands, Hong Kong, British Virgin Islands, Netherlands, Thailand, and Japan. Although the cash currently held in the United States as well as the cash generated in the United States from future operations is expected to cover our normal operating requirements, a substantial amount of additional cash could be required for other purposes, such as capital expenditures to support our business and growth, including costs associated with increasing internal manufacturing capabilities, such as our new Thailand facility, strategic transactions and partnerships, and acquisitions. Our intent is to indefinitely reinvest funds held outside the United States, except for the funds held in the Cayman Islands and Hong Kong, and our current plans do not demonstrate a need to repatriate them to fund our domestic operations. However, if in the future, we encounter a significant need for liquidity domestically or at a particular location that we cannot fulfill through borrowings, equity offerings, or other internal or external sources, or the cost to bring back the money is insignificant from a tax perspective, we may determine that cash repatriations are necessary or desirable. Repatriation could result in additional material taxes. These factors may cause us to have an overall tax rate higher than other companies or higher than our tax rates have been in the past. If conditions warrant, we may seek to obtain additional financing through debt or equity sources. To the extent we issue additional shares, our existing stockholders may be diluted. However, any such financing may not be available on terms favorable to us, or may not be available at all.

[0001633978-18-000108:mdna:166]
Fiscal 2018

[0001633978-18-000108:mdna:167]
As of June 30, 2018, our consolidated balance of cash and cash equivalents increased by $124.4 million, to $397.3 million from $272.9 million as of July 1, 2017. The increase in cash and cash equivalents was mainly due to cash provided by operating activities of $247.5 million during fiscal 2018 offset by purchases of short-term investments, net of sales of $33.8 million and capital expenditures of $93.2 million.

[0001633978-18-000108:mdna:168]
Cash provided by operating activities was $247.5 million for the year ended June 30, 2018, primarily resulting from $248.1 million of net income and $18.5 million of non-cash items (such as depreciation, stock-based compensation, amortization of intangibles, amortization of discount on the 2024 Notes, net of the release of the valuation allowance), offset by $19.1 million of changes in our operating assets and liabilities. Changes in our operating assets and liabilities related primarily to an increase in accounts receivable of $30.8 million, offset by an increase in accrued expenses and other current and non-current liabilities of $11.9 million.

[0001633978-18-000108:mdna:169]
Cash used in investing activities of $127.0 million for the year ended June 30, 2018, was primarily attributable to capital expenditures of $93.2 million and purchases of short-term investments, net of sales of $33.8 million.

[0001633978-18-000108:mdna:170]
Cash provided by financing activities was $3.8 million for the year ended June 30, 2018, resulting primarily from the issuance of common stock under the 2015 Employee Stock Purchase Plan of $9.2 million offset by repayment of capital lease obligation of $6.4 million.

[0001633978-18-000108:mdna:171]
Fiscal 2017

[0001633978-18-000108:mdna:172]
As of July 1, 2017, our consolidated balance of cash and cash equivalents increased by $115.8 million, to $272.9 million from $157.1 million as of July 2, 2016. The increase in cash and cash equivalents was mainly due to proceeds from the issuance of the 2024 Notes during fiscal 2017, offset by the purchases of short-term investments and property, plant and equipment.

[0001633978-18-000108:mdna:173]
Cash provided by operating activities was $85.0 million for the year ended July 1, 2017, primarily resulting from $102.5 million of net loss and $199.4 million of non-cash items such as depreciation, stock-based compensation, amortization of intangibles and unrealized loss on derivative liabilities, the impact of which was offset by changes in excess tax benefit associated with stock-based compensation. In addition, changes in our operating assets and liabilities of $11.9 million related primarily to an increase in inventories of $41.7 million and a decrease in accounts payable of $16.9 million related to non-cash items such as $10.0 million unpaid property, plant and equipment, offset by a decrease in income taxes, net of $42.7 million.

[0001633978-18-000108:mdna:174]
Cash used in investing activities was mainly for capital expenditures and purchases of short-term investments, net of sales of $138.1 million and $282.5 million, respectively, for the year ended July 1, 2017. Changes in investing cash flow in fiscal 2017 also related to the acquisition of a business for $5.1 million.

[0001633978-18-000108:mdna:175]
Cash provided by financing activities was $456.7 million for the year ended July 1, 2017, resulting primarily from proceeds of $442.3 million from the issuance of the 2024 Notes.

[0001633978-18-000108:mdna:176]
Fiscal 2016

[0001633978-18-000108:mdna:177]
As of July 2, 2016, our consolidated balance of cash and cash equivalents and short-term investments was $157.1 million, an increase of $142.3 million, or 961.5%, as compared to $14.8 million as of June 27, 2015.

[0001633978-18-000108:mdna:178]
Cash provided by operating activities was $86.6 million, primarily resulting from $9.3 million of net income, which included $80.7 million of non-cash items such as depreciation, stock-based compensation, derivative liability, amortization of intangibles and disposal of property, plant and equipment, offset by changes in operating assets and liabilities of $3.4 million. Changes in our operating assets and liabilities related primarily to an increase in accounts payable of $28.9 million, an increase in accounts receivable of $21.8 million, an increase in prepayments, other current and non-currents assets of $12.7 million, an increase in accrued payroll and related expenses of $9.2 million, a decrease in deferred taxes, net of $1.7 million, a decrease in income taxes payable of $1.7 million, an increase in inventories of $3.1 million and a decrease in accrued expenses and other current and non-current liabilities of $0.5 million.

[0001633978-18-000108:mdna:179]
Cash used in investing activities included $82.0 million of cash used for capital expenditures, primarily to expand our manufacturing capacity.

[0001633978-18-000108:mdna:180]
Cash provided by financing activities was $136.4 million, resulting primarily from net transfers from Viavi of $134.2 million at the Separation date.

[0001633978-18-000108:mdna:181]
Liquidity and Capital Resources Requirements

[0001633978-18-000108:mdna:182]
We believe that our cash and cash equivalents as of June 30, 2018, and cash flows from our operating activities will be sufficient to meet our liquidity and capital spending requirements for at least the next 12 months. However, if market conditions are favorable, we may evaluate alternatives to opportunistically pursue additional financing.

[0001633978-18-000108:mdna:183]
There are a number of factors that could positively or negatively impact our liquidity position, including:

[0001633978-18-000108:mdna:184]
| • | global economic conditions which affect demand for our products and services and impact the financial stability of our suppliers and customers; |

[0001633978-18-000108:mdna:185]
| • | changes in accounts receivable, inventory or other operating assets and liabilities, which affect our working capital; |

[0001633978-18-000108:mdna:186]
| • | increase in capital expenditures to support our business and growth; |

[0001633978-18-000108:mdna:187]
| • | the tendency of customers to delay payments or to negotiate favorable payment terms to manage their own liquidity positions; |

[0001633978-18-000108:mdna:188]
| • | timing of payments to our suppliers; |

[0001633978-18-000108:mdna:189]
| • | factoring or sale of accounts receivable; |

[0001633978-18-000108:mdna:190]
| • | volatility in fixed income and credit, which impact the liquidity and valuation of our investment portfolios; |

[0001633978-18-000108:mdna:191]
| • | volatility in foreign exchange markets, which impacts our financial results; |

[0001633978-18-000108:mdna:192]
| • | possible investments or acquisitions of complementary businesses, products or technologies, or other strategic transactions or partnerships; |

[0001633978-18-000108:mdna:193]
| • | issuance of debt or equity securities, or other financing transactions, including bank debt; |

[0001633978-18-000108:mdna:194]
| • | potential funding of pension liabilities either voluntarily or as required by law or regulation; and |

[0001633978-18-000108:mdna:195]
| • | settlement of any conversion or redemption of the 2024 Notes in cash. |

[0001633978-18-000108:mdna:196]
In March 2018, we entered into the Merger Agreement with Oclaro. Pursuant to the terms of the Merger Agreement, each issued and outstanding share of Oclaro common stock will be exchanged for $5.60 in cash and 0.0636 of a share of Lumentum common stock, subject to the conditions and restrictions set forth in the Merger Agreement. In connection with the acquisition of Oclaro, we have entered into a commitment letter with Deutsche Bank, pursuant to which, subject to the terms and conditions set forth therein, Deutsche Bank has committed to provide a senior secured term loan facility in an aggregate principal amount of $550 million, with a provision for additional senior secured term loans in an aggregate principal amount not to exceed $250 million.  As of August 23, 2018, the total transaction consideration was expected to be approximately $1.7 billion, which would be funded by a combination of $700 million in Lumentum common stock, $500 million in new debt, and the remaining amount from the cash balances of the combined company.
