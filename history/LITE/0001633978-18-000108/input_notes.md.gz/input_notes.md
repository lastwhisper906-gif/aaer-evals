# LITE notes — 0001633978-18-000108


## lite:AssetAcquisitionDisclosureTextBlock

[0001633978-18-000108:notes:1]
Note 6. Asset Acquisition

[0001633978-18-000108:notes:2]
On March 30, 2018, we entered into a Transition Services Agreement (“TSA”) with one of our contract manufacturers to wind down the production of our products at their facility in China and to facilitate an orderly transition of manufacturing to our manufacturing facility in Thailand, including the purchase of the manufacturing equipment. Under the terms of the TSA, we are required to pay $5.3 million in cash upon completion of certain milestones related to the purchase of equipment.

[0001633978-18-000108:notes:3]
We are also required to share cost of retention and severance, and to reimburse for certain other direct and indirect costs incurred by our contract manufacturer for transition services provided.

[0001633978-18-000108:notes:4]
As of June 30, 2018, the assets acquired under this TSA are not material.


## lite:ConcentrationOfCreditAndOtherRisksAndAllowanceForDoubtfulAccountsPolicyTextBlock

[0001633978-18-000108:notes:5]
Concentration of Credit and Other Risks

[0001633978-18-000108:notes:6]
Financial instruments that potentially subject our business to concentration of credit risk consist primarily of cash and cash equivalents and trade receivables. We perform credit evaluations of our customers’ financial condition and generally do not require collateral from our customers. These evaluations require significant judgment and are based on a variety of factors including, but not limited to, current economic trends, payment history, bad debt write-off experience, and financial review of the customer.

[0001633978-18-000108:notes:7]
Although the Company deposits its cash with financial institutions that management believes are of high credit quality, its deposits, at times, may exceed federally insured limits. The Company’s investment portfolio consists of investment grade securities diversified amongst security types, industries, and issuers. The Company’s investment policy limits the amount of credit exposure in the investment portfolio to a maximum of 5% to any one issuer, except for Treasury and Government Agencies securities, and the Company believes no significant concentration risk exists with respect to these investments.

[0001633978-18-000108:notes:8]
We maintain an allowance for doubtful accounts for estimated losses resulting from the inability of our customers to make required payments. When we become aware that a specific customer is unable to meet their financial obligations, we record a specific allowance to reflect the level of credit risk in the customer’s outstanding receivable balance. In addition, we record additional allowances based on certain percentages of aged receivable balances. These percentages take into account a variety of factors including, but not limited to, current economic trends, payment history and bad debt write-off experience. We classify bad debt expenses as selling, general and administrative (“SG&A”) expense.

[0001633978-18-000108:notes:9]
We have significant trade receivables concentrated in the telecommunications industry. While our allowance for doubtful accounts balance is based on historical loss experience along with anticipated economic trends, unanticipated financial instability in the telecommunications industry could lead to higher than anticipated losses.

[0001633978-18-000108:notes:10]
During fiscal 2018, 2017 and 2016, several customers generated more than 10% of total net revenue. Refer to “Note 19. Operating Segments and Geographic Information” in the Notes to Consolidated Financial Statements.

[0001633978-18-000108:notes:11]
As of June 30, 2018, two customers represented greater than 10% of total accounts receivable, net. As of July 1, 2017, one customer represented greater than 10% of total accounts receivable, net.

[0001633978-18-000108:notes:12]
We rely on a limited number of suppliers for a number of key components contained in our products. We also rely on a limited number of significant independent contract manufacturers for the production of certain key components and subassemblies contained in our products.

[0001633978-18-000108:notes:13]
We generally use a rolling twelve month forecast based on anticipated product orders, customer forecasts, product order history and backlog to determine our materials requirements. Lead times for the parts and components that we order vary significantly and depend on factors such as the specific supplier, contract terms and demand for a component at a given time. If the forecast does not meet or if it exceeds actual demand, we may have excess or shortfalls of some materials and components, as well as excess inventory purchase commitments. We could experience reduced or delayed product shipments or incur additional inventory write-downs and cancellation charges or penalties, which would increase costs and could have a material adverse impact on our results of operations.


## lite:PropertyPlantandEquipmentNetTableTextBlock

[0001633978-18-000108:notes:14]
The components of property, plant and equipment, net were as follows (in millions):

[0001633978-18-000108:notes:15]
|  | June 30, 2018 |  | July 1, 2017 (1) |
| Land | $ | 10.6 |  |  | $ | 10.6 |  |
| Buildings and improvement | 55.1 |  |  | 37.3 |  |
| Machinery and equipment (2) | 463.6 |  |  | 378.4 |  |
| Computer equipment and software | 26.3 |  |  | 26.2 |  |
| Furniture and fixtures | 2.2 |  |  | 3.6 |  |
| Leasehold improvements | 25.8 |  |  | 30.5 |  |
| Construction in progress | 52.6 |  |  | 84.6 |  |
|  | 636.2 |  |  | 571.2 |  |
| Less: Accumulated depreciation | (329.3 | ) |  | (297.7 | ) |
| Property, plant and equipment, net | $ | 306.9 |  |  | $ | 273.5 |  |

[0001633978-18-000108:notes:16]
(1) We have reclassified certain prior period amounts to conform to current period presentation.

[0001633978-18-000108:notes:17]
(2) In the first quarter of fiscal 2018, we started leasing equipment from a vendor and have accounted for the transaction as a capital lease. Included in the table above is our capital lease asset of $15.6 million, gross and depreciation expense of $5.2 million as of June 30, 2018.


## lite:ScheduleOfOtherLiabilitiesCurrentTableTextBlock

[0001633978-18-000108:notes:18]
The components of other current liabilities were as follows (in millions):

[0001633978-18-000108:notes:19]
|  | June 30, 2018 |  | July 1, 2017 |
| Warranty accrual (1) | $ | 6.6 |  |  | $ | 9.7 |  |
| Restructuring accrual and related charges (2) | 1.9 |  |  | 3.8 |  |
| Deferred revenue and customer deposits | 2.8 |  |  | 6.9 |  |
| Capital lease obligation (3) | 7.3 |  |  | — |  |
| Other current liabilities | 3.5 |  |  | 2.2 |  |
| Other current liabilities | $ | 22.1 |  |  | $ | 22.6 |  |

[0001633978-18-000108:notes:20]
(1) Refer to “Note 18. Commitments and Contingencies” in the Notes to Consolidated Financial Statements.

[0001633978-18-000108:notes:21]
(2) Refer to “Note 14. Restructuring and Related Charges” in the Notes to Consolidated Financial Statements.

[0001633978-18-000108:notes:22]
(3) As of June 30, 2018, an amount of $1.6 million related to a capital lease was recorded in accounts payable on the consolidated balance sheet. Refer to “Note 18. Commitments and Contingencies” in the Notes to Consolidated Financial Statements.


## lite:ScheduleOfOtherLiabilitiesNoncurrentTableTextBlock

[0001633978-18-000108:notes:23]
The components of other non-current liabilities were as follows (in millions):

[0001633978-18-000108:notes:24]
|  | June 30, 2018 |  | July 1, 2017 |
| Asset retirement obligations | $ | 2.7 |  |  | $ | 2.5 |  |
| Pension and related accrual | 3.5 |  |  | 3.9 |  |
| Deferred rent | 2.6 |  |  | 3.3 |  |
| Unrecognized tax benefit | 6.1 |  |  | 10.5 |  |
| Capital lease obligation (1) | 0.4 |  |  | — |  |
| Other non-current liabilities | 3.7 |  |  | 4.8 |  |
| Other non-current liabilities | $ | 19.0 |  |  | $ | 25.0 |  |


## lite:SharebasedCompensationArrangementbySharebasedPaymentAwardNumberofSharesAvailableforGrantTableTextBlock

[0001633978-18-000108:notes:25]
A summary of awards available for grant is as follows (in millions):

[0001633978-18-000108:notes:26]
|  | Awards Available for Grant |
| Balance as of June 27, 2015 | — |  |
| Authorized | 8.5 |  |
| Granted | (4.0 | ) |
| Canceled | 0.2 |  |
| Balance as of July 2, 2016 | 4.7 |  |
| Authorized | 3.0 |  |
| Granted | (1.3 | ) |
| Canceled | 0.2 |  |
| Balance as of July 1, 2017 | 6.6 |  |
| Granted | (1.2 | ) |
| Canceled | 0.2 |  |
| Balance as of June 30, 2018 | 5.6 |  |


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001633978-18-000108:notes:27]
SCHEDULE II - VALUATION AND QUALIFYING ACCOUNTS

[0001633978-18-000108:notes:28]
|  | (in millions) |
|  | Balance atBeginningof Period |  | Increase (decrease) toIncome Statement |  | WriteOffs |  | Balanceat End ofPeriod |
| Accounts receivable allowance: |  |  |  |  |  |  |  |
| Fiscal year ended June 30, 2018 | $ | 1.8 |  |  | $ | 0.9 |  |  | $ | (0.1 | ) |  | $ | 2.6 |  |
| Fiscal year ended July 1, 2017 | $ | 0.9 |  |  | $ | 1.0 |  |  | $ | (0.1 | ) |  | $ | 1.8 |  |
| Fiscal year ended July 2, 2016 | $ | 1.2 |  |  | $ | 0.6 |  |  | $ | (0.9 | ) |  | $ | 0.9 |  |

[0001633978-18-000108:notes:29]
|  |  | (in millions) |
| Description |  | Balance at Beginning of Period |  | Additions Charged to Expenses or Other Accounts* |  | Deductions Credited to Expenses or Other Accounts** |  | Balance at End of Period |
| Deferred tax valuation allowance: |  |  |  |  |  |  |  |  |
| Fiscal year ended June 30, 2018 |  | $ | 296.4 |  |  | $ | 234.1 |  |  | $ | (431.1 | ) |  | $ | 99.4 |  |
| Fiscal year ended July 1, 2017 |  | $ | 321.4 |  |  | $ | 16.7 |  |  | $ | (41.7 | ) |  | $ | 296.4 |  |
| Fiscal year ended July 2, 2016 |  | $ | 160.0 |  |  | $ | 214.3 |  |  | $ | (52.9 | ) |  | $ | 321.4 |  |

[0001633978-18-000108:notes:30]
*    Additions include current year additions charged to expenses and current year build due to increases in net deferred tax assets, return to provision true-ups, other adjustments to deferred taxes.

[0001633978-18-000108:notes:31]
**    Deductions include current year releases credited to expenses and current year reductions due to decreases in net deferred tax assets, return to provision true-ups, other adjustments to deferred taxes.


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001633978-18-000108:notes:32]
Basis of Presentation

[0001633978-18-000108:notes:33]
On July 31, 2015, prior to the Separation, Viavi transferred substantially all of the assets and liabilities and operations of the CCOP segment and WaveReady product lines to Lumentum. Financial statements for periods prior to the Separation were prepared on a stand-alone basis and were derived from Viavi’s consolidated financial statements and accounting records. The Company prepared consolidated financial statements for the period from June 28, 2015 to August 1, 2015 where expenses were allocated to us using estimates that we consider to be a reasonable reflection of the utilization of services provided to, or benefits received by, us. From August 1, 2015 to July 2, 2016, the Company prepared consolidated financial statements as an independent stand-alone basis pursuant to the rules and regulations of the SEC and are in conformity with U.S. GAAP. In the opinion of management, these consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments, which are necessary for a fair statement of the consolidated financial statements for the periods shown. The results of operations for such periods are not necessarily indicative of the results expected for the full year or for any future periods.

[0001633978-18-000108:notes:34]
On August 1, 2015, Lumentum became an independent publicly-traded company through the distribution by JDS Uniphase (“JDSU”) to its stockholders of 80.1% of our outstanding common stock (the “Separation”). Each JDSU stockholder of record as of the close of business on July 27, 2015 received one share of Lumentum common stock for every five shares of JDSU common stock held on the record date. JDSU was renamed Viavi and at the time of the distribution retained ownership of 19.9% of Lumentum’s outstanding shares. Lumentum was incorporated in Delaware as a wholly owned subsidiary of Viavi on February 10, 2015 and is comprised of the former communications and commercial optical products (“CCOP”) segment and WaveReady product lines of Viavi. Lumentum’s Registration Statement on Form 10 was declared effective by the SEC on July 16, 2015. Lumentum’s common stock began trading “regular-way” under the ticker “LITE” on the NASDAQ stock market on August 4, 2015.

[0001633978-18-000108:notes:35]
See “Note 3. Related Party Transactions” in the Notes to Consolidated Financial Statements regarding the relationships we had with Viavi.

[0001633978-18-000108:notes:36]
The preparation of the consolidated financial statements in accordance with GAAP in the United States requires management to make estimates and assumptions that affect the amounts reported in our consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates. Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are inventory valuation, revenue recognition, accounting for income taxes, long-lived asset valuation, warranty, valuation of derivative liability, business combinations, and valuation of goodwill.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001633978-18-000108:notes:37]
Note 1. Description of Business and Summary of Significant Accounting Policies

[0001633978-18-000108:notes:38]
Description of Business

[0001633978-18-000108:notes:39]
Lumentum (we, us, our or the Company) is an industry-leading provider of optical and photonic products defined by revenue and market share addressing a range of end market applications including OpComms and Lasers for manufacturing, inspection and life-science applications. We seek to use our core optical and photonic technology and our volume manufacturing capability to expand into attractive emerging markets that benefit from advantages that optical or photonics-based solutions provide, including 3D sensing for consumer electronics and diode light sources for a variety of consumer and industrial applications. The majority of our customers tend to be OEMs that incorporate our products into their products which then address end-market applications. For example, we sell fiber optic components that Network Equipment Manufacturers (“NEMs”) customers assemble into communications networking systems, which they sell to network service providers or enterprises with their own networks. Similarly, many of our customers for our Lasers products incorporate our products into tools they produce, which are used for manufacturing processes by their customers. For 3D sensing, we sell diode lasers to manufacturers of consumer electronics products for mobile, personal computing, and gaming who then integrate our devices within their products, for eventual resale to consumers and also into other industrial applications.

[0001633978-18-000108:notes:40]
On March 11, 2018, we entered into an Agreement and Plan of Merger (the “Merger Agreement”) with Oclaro, Prota Merger Sub, Inc., and Prota Merger, LLC, pursuant to which we will acquire Oclaro and Oclaro will become a wholly-owned subsidiary of Lumentum. In accordance with the terms of the Merger Agreement, each issued and outstanding share of Oclaro common stock will be exchanged for $5.60 in cash and 0.0636 of a share of Lumentum common stock, subject to the conditions and restrictions set forth in the Merger Agreement. The total transaction consideration was approximately $1.8 billion as of the date of the Merger Agreement. Oclaro stockholders will own approximately 16% of the combined company following the closing. Oclaro’s stockholders approved the Merger Agreement on July 10, 2018 and we have received approval for the transaction under the Hart-Scott Rodino Act in the United States. We are in the process of obtaining antitrust approval in China. The Merger Agreement contains certain termination rights for both Lumentum and Oclaro. The Merger Agreement further provides that upon termination of the Merger Agreement under specified circumstances relating to failure to obtain regulatory approvals, Lumentum may be required to pay Oclaro a termination fee of $80 million.

[0001633978-18-000108:notes:41]
As of August 23, 2018, the total transaction consideration was expected to be approximately $1.7 billion, which would be funded by a combination of $700 million in Lumentum common stock, $500 million in new debt, and the remaining amount from the cash balances of the combined company.

[0001633978-18-000108:notes:42]
In connection with the Merger Agreement, Lumentum entered into a commitment letter, dated as of March 11, 2018, with Deutsche Bank Securities Inc. and Deutsche Bank AG New York, New York Branch (“Deutsche Bank”), pursuant to which, subject to the terms and conditions set forth therein, Deutsche Bank has committed to provide a senior secured term loan facility in an aggregate principal amount of up to $550 million, with a provision for additional senior secured term loans in an aggregate principal amount not to exceed $250 million.

[0001633978-18-000108:notes:43]
The transaction is subject to customary closing conditions, including antitrust regulatory approval in China. The transaction is not subject to any financing condition. The transaction is expected to be completed in the second half of calendar 2018.

[0001633978-18-000108:notes:44]
Fiscal Years

[0001633978-18-000108:notes:45]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Our fiscal 2018 ended on June 30, 2018 and was a 52-week year. Our fiscal 2017 ended on July 1, 2017 and was a 53-week year. Our fiscal 2016 ended on July 2, 2016 and was a 52-week year.

[0001633978-18-000108:notes:46]
Principles of Consolidation

[0001633978-18-000108:notes:47]
These audited consolidated financial statements include the accounts of the Company and its wholly-owned subsidiaries.

[0001633978-18-000108:notes:48]
All inter-company transactions and balances have been eliminated in consolidation. All material transactions between us and other businesses of Viavi prior to Separation were reflected as net transfers to and from Viavi as a component of financing activities in the consolidated statements of cash flows.

[0001633978-18-000108:notes:49]
Certain prior period amounts have been reclassified to conform to the current year presentation on the notes to consolidated financial statements. The reclassification of the prior period amounts did not impact previously reported consolidated financial statements.

[0001633978-18-000108:notes:50]
Summary of Significant Accounting Policies

[0001633978-18-000108:notes:51]
Cash and Cash Equivalents

[0001633978-18-000108:notes:52]
We consider highly-liquid fixed income securities with original maturities of three months or less at the time of purchase to be cash equivalents. As of fiscal year ended June 30, 2018, cash and cash equivalents mainly consist of commercial papers, U.S. Treasury securities, and U.S. Agency securities. As of fiscal year ended July 1, 2017, our cash and cash equivalents did not include any investments with original maturities of three months or less.

[0001633978-18-000108:notes:53]
Short-term Investments

[0001633978-18-000108:notes:54]
We classify our investments in debt as available-for-sale and record these investments at fair value. Investments with an original maturity of three months or less at the date of purchase are considered cash equivalents, while all other investments are classified as short-term based on management’s intent and ability to use the funds in current operations. Unrealized gains and losses are reported as a component of other comprehensive loss. Realized gains and losses are determined based on the specific identification method, and are reflected as interest and other income (expense), net in our Consolidated Statements of Operations. We regularly review our investment portfolio to identify and evaluate investments that have indicators of possible impairment. Factors considered in determining whether a loss is other-than-temporary include, but are not limited to: the length of time and extent a security’s fair value has been below its cost, the financial condition and near-term prospects of the investee, the credit quality of the security’s issuer, likelihood of recovery and our intent and ability to hold the security for a period of time sufficient to allow for any anticipated recovery in value. For our debt instruments, we also evaluate whether we have the intent to sell the security or it is more likely than not that we will be required to sell the security before recovery of its cost basis.

[0001633978-18-000108:notes:55]
Impairment of Marketable and Non-Marketable Securities

[0001633978-18-000108:notes:56]
We periodically review our marketable and non-marketable securities for impairment. If we conclude that any of these investments are impaired, we determine whether such impairment is other-than-temporary. We consider factors such as the duration, severity and the reason for the decline in value, the potential recovery period and whether we intend to sell. For marketable debt securities, we also consider whether (i) it is more likely than not that we will be required to sell the debt securities before recovery of their amortized cost basis, and (ii) the amortized cost basis cannot be recovered as a result of credit losses. If any impairment is considered other-than-temporary, we will write-down the security to its fair value.

[0001633978-18-000108:notes:57]
Fair Value of Financial Instruments

[0001633978-18-000108:notes:58]
We define fair value as the price that would be received from selling an asset, or paid to transfer a liability, in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities which are required to be recorded at fair value, we consider the principal or most advantageous market in which to transact and the market-based risk. We apply fair value accounting for all financial assets and liabilities that are recognized or disclosed at fair value in the financial statements on a recurring basis. The carrying amounts reported in the consolidated financial statements approximate the fair value for cash and cash equivalents, accounts receivable, accounts payable and accrued liabilities due to their short-term nature.

[0001633978-18-000108:notes:59]
Basic and Diluted Net Income (Loss) per Common Share

[0001633978-18-000108:notes:60]
Basic income (loss) per share is computed by dividing net income (loss) available to common shareholders by the weighted average number of common shares outstanding during the reporting period. The weighted average number of shares is calculated by taking the number of shares outstanding and weighting them by the amount of time that they were outstanding.  Diluted earnings per share reflects the potential dilution that could occur if stock options, preferred stock, and other commitments to issue common stock were exercised or equity awards vest resulting in the issuance of common stock that could share in the earnings of the Company.

[0001633978-18-000108:notes:61]
Diluted loss per share is the same as basic loss per share during periods where net losses are incurred since the inclusion of the potential common stock equivalents would be anti-dilutive as a result of the net loss.

[0001633978-18-000108:notes:62]
Our Series A Preferred Stock is considered a participating security, which may participate in undistributed earnings with our common stock. The holders of our Preferred Stock would be entitled to share in dividends, on an as-converted basis, if the holders of our common stock were to receive dividends. We are required to use the two-class method when computing earnings per share as we have a security that qualifies as a participating security. The two-class method is an earnings allocation formula that determines earnings per share for each class of common stock and participating security according to dividends declared (or accumulated) and participation rights in undistributed earnings. In determining the amount of net earnings to allocate to common stockholders, earnings are allocated to both common and participating securities based on their respective weighted-average shares outstanding during the period. Diluted earnings per common share, when applicable, is computed using the more dilutive of the two-class method or the if-converted method. In periods of net loss, no effect is given to participating securities since they do not contractually participate in the losses of the Company.

[0001633978-18-000108:notes:63]
In March 2017, we issued $450 million in aggregate principal amount of 0.25% Convertible Senior Notes due in 2024 (the “2024 Notes”). We have the ability and intent to settle the $450 million face value of the 2024 Notes in cash. Therefore, we use the treasury stock method for calculating the dilutive impact of the 2024 Notes. The 2024 Notes will have no impact to diluted earnings per share until the average price of our common stock exceeds the conversion price of $60.62. Refer to “Note 11. Convertible Senior Notes” for details.

[0001633978-18-000108:notes:64]
The dilutive effect of securities from the 2015 Equity Incentive Plan is reflected in diluted earnings per share by application of the treasury stock method, which includes consideration of unamortized share-based compensation expense and the dilutive effect of in-the-money options and non-vested restricted stock units. Under the treasury stock method, the amount the employee must pay for exercising stock options and the amount of unamortized share-based compensation expense are collectively assumed to be used to repurchase hypothetical shares. An increase in the fair value of our common stock can result in a greater dilutive effect from potentially dilutive awards.

[0001633978-18-000108:notes:65]
Anti-dilutive potential shares from 2015 Equity Incentive Plan are excluded from the calculation of diluted earnings per share if their exercise price exceeded the average market price during the period or the share-based awards were determined to be anti-dilutive based on applying the treasury stock method.

[0001633978-18-000108:notes:66]
In periods when we have a net loss, all potentially dilutive securities are excluded from our calculation of earnings per share as their inclusion would have been anti-dilutive.

[0001633978-18-000108:notes:67]
Inventory Valuation

[0001633978-18-000108:notes:68]
Inventory is valued at standard cost, which approximates actual cost computed on a first-in, first-out basis, not in excess of net realizable value. We assess the value of our inventory on a quarterly basis and write down those inventories which are obsolete or in excess of our forecasted usage to the lower of their cost or estimated net realizable value. Our estimates of realizable value are based upon our analysis and assumptions including, but not limited to, forecasted sales levels and historical usage by product, expected product lifecycle, product development plans and future demand requirements. Our product line management personnel play a key role in our excess review process by providing updated sales forecasts, managing product transitions and working with manufacturing to minimize excess inventory. If actual market conditions are less favorable than our forecasts or actual demand from our customers is lower than our estimates, we may be required to record additional inventory write-downs. If actual market conditions are more favorable than anticipated, inventory previously written down may be sold, resulting in lower cost of sales and higher income from operations than expected in that period.

[0001633978-18-000108:notes:69]
Revenue Recognition

[0001633978-18-000108:notes:70]
During the periods presented, we recognized revenue when all four revenue recognition criteria have been met: (i) persuasive evidence of an arrangement exists, (ii) the product has been delivered or the service has been rendered, (iii) the price is fixed or determinable and (iv) collection is reasonably assured. Revenue from product sales is recorded when all of the foregoing conditions are met and risk of loss and title passes to the customer. Our products typically include a warranty and the estimated cost of product warranty claims, based on historical experience, is recorded at the time the sale is recognized. Sales to customers are generally not subject to price protection or return rights. The majority of our sales are made to OEMs, distributors, resellers and end-users.

[0001633978-18-000108:notes:71]
We record as a reduction to revenues reserves for sales returns based upon historical experience rates and for any specific known customer amounts. We also provide certain distributors and OEMs with volume-pricing discounts, such as rebates and incentives, which are recorded as a reduction to revenues at the time of sale. Historically these volume discounts have not been significant. For revenue recognition changes related to implementation of ASU 2014-09, refer to “Note 2. Recent Accounting Pronouncements”.

[0001633978-18-000108:notes:72]
Income Taxes

[0001633978-18-000108:notes:73]
In accordance with the authoritative guidance on accounting for income taxes, we recognize income taxes using an asset and liability approach. This approach requires the recognition of taxes payable or refundable for the current year and deferred tax liabilities and assets for the future tax consequences of events that have been recognized in our consolidated financial statements or tax returns. The measurement of current and deferred taxes is based on provisions of the enacted tax law, and the effects of future changes in tax laws or rates are not anticipated.

[0001633978-18-000108:notes:74]
The authoritative guidance provides for recognition of deferred tax assets if the realization of such deferred tax assets is more likely than not to occur based on an evaluation of both positive and negative evidence and the relative weight of the evidence. We consider future growth, forecasted earnings, future taxable income, the mix of earnings in the jurisdictions in which we operate, historical earnings, taxable income in prior years, if carryback is permitted under the law, and prudent and feasible tax planning strategies in determining the need for a valuation allowance. In the event we were to determine that we would not be able to realize all or part of our net deferred tax assets in the future, an adjustment to the deferred tax assets valuation allowance would be charged to earnings in the period in which we make such a determination, or goodwill would be adjusted at our final determination of the valuation allowance related to an acquisition within the measurement period. If we later determine that it is more likely than not that the net deferred tax assets would be realized, we would reverse the applicable portion of the previously provided valuation allowance as an adjustment to earnings at such time.

[0001633978-18-000108:notes:75]
We are subject to income tax audits by the respective tax authorities of the jurisdictions in which we operate. The determination of our income tax liabilities in each of these jurisdictions requires the interpretation and application of complex, and sometimes uncertain, tax laws and regulations. The authoritative guidance on accounting for income taxes prescribes both recognition and measurement criteria that must be met for the benefit of a tax position to be recognized in the financial statements.  If a tax position taken, or expected to be taken, in a tax return does not meet such recognition or measurement criteria, an unrecognized tax benefit liability is recorded.  If we ultimately determine that an unrecognized tax benefit liability is no longer necessary, we reverse the liability and recognize a tax benefit in the period in which it is determined that the unrecognized tax benefit liability is no longer necessary.

[0001633978-18-000108:notes:76]
The recognition and measurement of current taxes payable or refundable and deferred tax assets and liabilities requires that we make certain estimates and judgments. Changes to these estimates or a change in judgment may have a material impact on our tax provision in a future period.

[0001633978-18-000108:notes:77]
Property, Plant and Equipment

[0001633978-18-000108:notes:78]
Property, plant and equipment are stated at cost. Depreciation is computed by the straight-line method generally over the following estimated useful lives of the assets: 10 to 50 years for building and improvements, 3 to 5 years for machinery and equipment, and 2 to 5 years for furniture, fixtures, software and office equipment. Leasehold improvements are amortized using the straight-line method over the shorter of the estimated useful lives of the assets or the term of the lease.

[0001633978-18-000108:notes:79]
Goodwill

[0001633978-18-000108:notes:80]
Goodwill represents the excess of the purchase price of an acquired business over the fair value of the identifiable assets acquired and liabilities assumed. We test for impairment of goodwill on an annual basis in the fourth quarter and at any other time when events occur or circumstances indicate that the carrying amount of goodwill may not be recoverable.

[0001633978-18-000108:notes:81]
An entity has the option to first assess qualitative factors to determine whether it is necessary to perform the two-step quantitative goodwill impairment test. If an entity determines that as a result of the qualitative assessment that it is more likely than not (i.e., greater than 50% likelihood) that the fair value of a reporting unit is less than its carrying amount, then the quantitative test is required. Otherwise, no further testing is required. The two-step quantitative goodwill impairment test requires us to estimate the fair value of our reporting units. If the carrying value of a reporting unit exceeds its fair value, the goodwill of that reporting unit is potentially impaired and we proceed to step two of the impairment analysis. In step two of the analysis, we measure and record an impairment loss equal to the excess of the carrying value of the reporting unit’s goodwill over its implied fair value, if any.

[0001633978-18-000108:notes:82]
Application of the goodwill impairment test requires judgments, including: identification of the reporting units, assigning assets and liabilities to reporting units, assigning goodwill to reporting units, a qualitative assessment to determine whether there are any impairment indicators, and determining the fair value of each reporting unit. We estimate the fair value of a reporting unit using market approach, income approach or a combination of market and income approach. Significant estimates in the market approach include: identifying similar companies with comparable business factors such as size, growth, profitability, risk and return on investment, and assessing comparable revenue and operating income multiples in estimating the fair value of the reporting unit. Significant estimates in the income approach include: future cash flows, discount rates.

[0001633978-18-000108:notes:83]
We base our estimates on historical experience and on various assumptions about the future that we believe are reasonable based on available information. Unanticipated events and circumstances may occur that affect the accuracy of our assumptions, estimates and judgments. For example, if the price of our common stock were to significantly decrease combined with other adverse changes in market conditions, thus indicating that the underlying fair value of our reporting units may have decreased, we might be required to reassess the value of our goodwill in the period such circumstances were identified.

[0001633978-18-000108:notes:84]
Based on the impairment analysis performed in the fourth quarter of each year presented, the fair value of our reporting unit substantially exceeded the carrying value; as such, our annual qualitative assessment did not indicate that a more detailed quantitative analysis was necessary.

[0001633978-18-000108:notes:85]
Intangible Assets

[0001633978-18-000108:notes:86]
Intangible assets consist primarily of intangible assets purchased through acquisitions. Purchased intangible assets primarily include acquired developed technologies (developed and core technology). Intangible assets are amortized using the straight-line method over the estimated economic useful lives of the assets, which is the period during which expected cash flows support the fair value of such intangible assets.

[0001633978-18-000108:notes:87]
Long-lived Asset Valuation

[0001633978-18-000108:notes:88]
We test long-lived assets for recoverability, at the asset group level, when events or changes in circumstances indicate that their carrying amount may not be recoverable. Circumstances which could trigger a review include, but are not limited to: significant decreases in the market price of the asset, significant adverse changes in the business climate or legal factors, accumulation of costs significantly in excess of the amount originally expected for the acquisition or construction of the asset, current period cash flow or operating losses combined with a history of losses or a forecast of continuing losses associated with the use of the asset, or current expectation that the asset will more likely than not be sold or disposed significantly before the end of its estimated useful life.

[0001633978-18-000108:notes:89]
Recoverability is assessed based on the difference between the carrying amount of the asset and the sum of the undiscounted cash flows expected to result from the use and the eventual disposal of the asset. An impairment loss is recognized when the carrying amount is not recoverable and exceeds fair value.

[0001633978-18-000108:notes:90]
Pension Benefits

[0001633978-18-000108:notes:91]
The funded status of our retirement-related benefit plan is measured as the difference between the fair value of plan assets and the benefit obligation at fiscal year end, the measurement date. The funded status of an underfunded benefit plan, of which the fair value of plan assets is less than the benefit obligation, is recognized as a non-current net pension liability in the consolidated balance sheets unless the fair value of plan assets is not sufficient to cover the expected payments to be made over the next year (or operating cycle, if longer) from the measurement date. For defined benefit pension plans, the benefit obligation is the projected benefit obligation (“PBO”) which represents the actuarial present value of benefits expected to be paid upon retirement.

[0001633978-18-000108:notes:92]
Net periodic pension cost (income) (“NPPC”) is recorded in the consolidated statements of operations and includes service cost, interest cost, expected return on plan assets, amortization of prior service cost and (gains) losses previously recognized as a component of accumulated other comprehensive income. Service cost represents the actuarial present value of participant benefits attributed to services rendered by employees in the current year. Interest cost represents the time value of money cost associated with the passage of time. (Gains) losses arise as a result of differences between actual experience and assumptions or as a result of changes in actuarial assumptions. Prior service cost (credit) represents the cost of benefit improvements attributable to prior service granted in plan amendments. (Gains) losses and prior service cost (credit) that arise during the current year are first recognized as a component of accumulated other comprehensive income in the consolidated balances sheets, net of tax. Prior service cost is amortized as a component of NPPC over the average remaining service period of active plan participants starting at the date the plan amendment is adopted. Deferred actuarial (gains) losses are subsequently recognized as a component of NPPC if they exceed the greater of 10% of PBO or the fair value of plan assets, with the excess amortized over the average remaining service period of active plan participants.

[0001633978-18-000108:notes:93]
The measurement of the benefit obligation and NPPC is based on our estimates and actuarial valuations, provided by third-party actuaries, which are approved by management. These valuations reflect the terms of the plans and use participant-specific information such as compensation, age and years of service, as well as certain assumptions, including estimates of discount rates, expected return on plan assets, rate of compensation increases, and mortality rates. We evaluate these assumptions annually at a minimum. In estimating the expected return on plan assets, we consider historical returns on plan assets, adjusted for forward-looking considerations, inflation assumptions and the impact of the active management of the plan’s invested assets.

[0001633978-18-000108:notes:94]
Foreign Currency Translation

[0001633978-18-000108:notes:95]
Assets and liabilities of non-U.S. subsidiaries that operate in a local currency environment, where that local currency is the functional currency, are translated into U.S. dollars at exchange rates in effect at the balance sheet date, with the resulting translation adjustments directly recorded to a separate component of accumulated other comprehensive income, within the consolidated statements of redeemable convertible preferred stock, stockholders’ equity, and invested equity. Income and expense accounts are translated at the average exchange rates during the year. Gains and losses from re-measurement of monetary assets and liabilities denominated in currencies other than the respective functional currencies are included in the consolidated statements of operations as a component of interest and other income (expense), net. Net gains or (losses) resulting from foreign currency transactions, including hedging gains and losses that were previously allocated to us by Viavi, are reported in interest and other income (expense), net and were $0.3 million, $0.6 million and $(0.9) million during fiscal 2018, 2017 and 2016, respectively. There were no allocations of expenses from Viavi for the fiscal 2018 and 2017. Refer to “Note 3. Related Party Transactions” in the Notes to Consolidated Financial Statements for allocations from Viavi during fiscal 2016.

[0001633978-18-000108:notes:96]
Stock-based Compensation

[0001633978-18-000108:notes:97]
Compensation expense related to stock-based transactions is measured and recognized in the financial statements based on fair value at the grant date.

[0001633978-18-000108:notes:98]
Restricted stock units (“RSUs”) are grants of shares of our common stock, the vesting of which is based on the requisite service requirement. Generally, our RSUs are subject to forfeiture and expected to vest over one to four years. For new-hire grants, RSUs generally vest ratably on an annual basis over four years. For annual refresh grants, RSUs generally vest ratably on an annual, or combination of annual and quarterly, basis over three years.

[0001633978-18-000108:notes:99]
Restricted stock awards (“RSAs”) are grants of shares of our common stock that are subject to various restrictions, including restrictions on transferability and forfeiture provisions. RSAs are expected to vest over one to four years, and the shares acquired may not be transferred by the holder until the vesting conditions (if any) are satisfied.

[0001633978-18-000108:notes:100]
Performance stock units (“PSUs”) are grants of shares of our common stock that vest upon the achievement of certain performance and service conditions. We account for the fair value of PSUs using the closing market price of our common stock on the date of grant. We begin recognizing compensation expense when we conclude that it is probable that the performance conditions will be achieved. We reassess the probability of vesting at each reporting period and adjust our compensation cost based on this probability assessment. Our PSUs are subject to risk of forfeiture until performance and service conditions are satisfied and generally vest over three years.

[0001633978-18-000108:notes:101]
We estimate the fair value of the rights to acquire stock under our 2015 Employee Stock Purchase Plan (the “2015 Purchase Plan”) using the Black-Scholes option pricing formula. Our 2015 Purchase Plan provides for consecutive six-month offering periods. We recognize such compensation expense on a straight-line basis over the requisite service period. We calculate the volatility factor based on our historical stock prices.

[0001633978-18-000108:notes:102]
Restructuring Accrual

[0001633978-18-000108:notes:103]
Costs associated with restructuring activities are recognized when they are incurred. However, in the case of leases, the expense is estimated and accrued when the property is vacated. Given the significance of, and the timing of the execution of such activities, this process is complex and involves periodic reassessments of estimates made from the time the property was vacated, including evaluating real estate market conditions for expected vacancy periods and sub-lease income. We recognize a liability for post-employment benefits for workforce reductions related to restructuring activities when payment is probable and the amount is reasonably estimable. We continually evaluate the adequacy of the remaining liabilities under our restructuring initiatives. Although we believe that these estimates accurately reflect the costs of our restructuring plans, actual results may differ, thereby requiring us to record additional provisions or reverse a portion of such provisions. Refer to “Note 14. Restructuring and Related Charges” in the Notes to Consolidated Financial Statements.

[0001633978-18-000108:notes:104]
Derivative Liability

[0001633978-18-000108:notes:105]
The Series A Preferred Stock issued by our subsidiary Lumentum Inc. is redeemable at the option of the holder after five years and classified as non-controlling interest redeemable convertible preferred stock in our consolidated balance sheet and is measured at its redemption value. The Series A Preferred Stock conversion feature is bifurcated from the Series A Preferred Stock and accounted for separately as a derivative liability. In March 2017, we issued $450.0 million in aggregate principal amount of 2024 Notes, which are due in March 2024 unless earlier repurchased by us or converted pursuant to their terms. Prior to the Tax Matters Agreement settlement condition (“TMA settlement condition”), because we could only settle the 2024 Notes in cash, we determined that the conversion feature met the definition of a derivative liability. We separated the derivative liability from the host debt instrument based on the fair value of the derivative liability. On June 29, 2017, we met the requirements to account for the conversion option of the 2024 Notes as equity and the conversion option is no longer marked to market. On a quarterly basis, the derivative liability for the Series A Preferred Stock is marked to market based on the fair value of the conversion feature, with the resulting income or loss recorded as unrealized loss on the derivative liabilities on our consolidated statements of operations. The determination of fair value includes various inputs, including volatility and interest rate assumptions. However, the change in the fair value of our common stock has the largest impact to the fair value of the derivatives. During fiscal 2018, 2017, and 2016, we recognized unrealized loss on derivative liabilities of $0.8 million, $104.2 million, and $0.6 million, respectively.

[0001633978-18-000108:notes:106]
Business Combinations

[0001633978-18-000108:notes:107]
In accordance with the guidance for business combinations, we determine whether a transaction or other event is a business combination, which requires that the assets acquired and liabilities assumed constitute a business. Each business combination is then accounted for by applying the acquisition method. If the assets acquired are not a business, we account for the transaction or other event as an asset acquisition. Under both methods, we recognize the identifiable assets acquired, the liabilities assumed, and any noncontrolling interest in the acquired entity. We capitalize acquisition-related costs and fees associated with asset acquisitions and immediately expense acquisition-related costs and fees associated with business combinations.

[0001633978-18-000108:notes:108]
We allocate the fair value of purchase consideration to the tangible assets acquired, liabilities assumed and intangible assets acquired based on their estimated fair values. The excess of the fair value of purchase consideration over the fair values of these identifiable assets and liabilities is recorded as goodwill. When determining the fair values of assets acquired and liabilities assumed, we make significant estimates and assumptions, especially with respect to intangible assets. Critical estimates in valuing certain intangible assets include, but are not limited to, future expected cash flows from customer relationships and acquired developed technology and discount rates. Our estimates of fair value are based upon assumptions believed to be reasonable, but which are inherently uncertain and unpredictable and, as a result, actual results may differ materially from estimates. Other estimates associated with the accounting for acquisitions may change as additional information becomes available regarding the assets acquired and liabilities assumed. Any change in facts and circumstances that existed as of the acquisition date and impacts our preliminary estimates is recorded to goodwill if identified within the measurement period. Subsequent to the measurement period or our final determination of fair value of assets and liabilities whichever is earlier the adjustments will affect our earnings.

[0001633978-18-000108:notes:109]
In addition, we estimate the economic lives of certain acquired assets and these lives are used to calculate depreciation and amortization expense. If our estimates of the economic lives change, depreciation or amortization expenses could be accelerated or slowed.

[0001633978-18-000108:notes:110]
Warranty

[0001633978-18-000108:notes:111]
We provide reserves for the estimated costs of product warranties at the time revenue is recognized. We estimate the costs of our warranty obligations based on our historical experience of known product failure rates, use of materials to repair or replace defective products and service delivery costs incurred in correcting product failures. In addition, from time to time, specific warranty accruals may be made if unforeseen technical problems arise.

[0001633978-18-000108:notes:112]
Shipping and Handling Costs

[0001633978-18-000108:notes:113]
We record shipping and handling costs related to revenue transactions within cost of sales as a period cost for all periods presented.

[0001633978-18-000108:notes:114]
Research and Development (“R&D”) Expense

[0001633978-18-000108:notes:115]
Costs related to R&D, which primarily consists of labor and benefits, supplies, facilities, consulting and outside service fees, are charged to expense as incurred.

[0001633978-18-000108:notes:116]
Loss Contingencies

[0001633978-18-000108:notes:117]
We are subject to the possibility of various loss contingencies arising in the ordinary course of business. We consider the likelihood of loss or impairment of an asset or the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss in determining loss contingencies. An estimated loss is accrued when it is probable that an asset has been impaired or a liability has been incurred and the amount of loss can be reasonably estimated. We regularly evaluate current information available to determine whether such accruals should be adjusted and whether new accruals are required.

[0001633978-18-000108:notes:118]
Asset Retirement Obligations (“ARO”)

[0001633978-18-000108:notes:119]
Our ARO are legal obligations associated with the retirement of long-lived assets pertaining to leasehold improvements. These liabilities are initially recorded at fair value and the related asset retirement costs are capitalized by increasing the carrying amount of the related assets by the same amount as the liability. Asset retirement costs are subsequently depreciated over the useful lives of the related assets. Subsequent to initial recognition, we record period-to-period changes in the ARO liability resulting from the passage of time and revisions to either the timing or the amount of the original estimate of undiscounted cash flows. We derecognize ARO liabilities when the related obligations are settled.


## us-gaap:CashCashEquivalentsAndShortTermInvestmentsTextBlock

[0001633978-18-000108:notes:120]
Note 8. Cash, Cash Equivalents, and Short-term Investments

[0001633978-18-000108:notes:121]
Cash, cash equivalents and short-term investments

[0001633978-18-000108:notes:122]
The following table summarizes our cash, cash equivalents, and short-term investments by category for the periods presented (in millions):

[0001633978-18-000108:notes:123]
|  | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| June 30, 2018 |  |  |  |  |  |  |  |
| Cash | $ | 103.6 |  |  | $ | — |  |  | $ | — |  |  | $ | 103.6 |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | 3.0 |  |  | — |  |  | — |  |  | 3.0 |  |
| Commercial paper | 112.1 |  |  | — |  |  | — |  |  | 112.1 |  |
| Money market funds | 0.8 |  |  | — |  |  | — |  |  | 0.8 |  |
| U.S. Treasury securities | 143.6 |  |  | — |  |  | — |  |  | 143.6 |  |
| U.S. Agency securities | 34.2 |  |  | — |  |  | — |  |  | 34.2 |  |
| Total cash and cash equivalents | $ | 397.3 |  |  | $ | — |  |  | $ | — |  |  | $ | 397.3 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 7.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 7.5 |  |
| Commercial paper | 10.5 |  |  | — |  |  | — |  |  | 10.5 |  |
| Asset-backed securities | 68.0 |  |  | — |  |  | (0.2 | ) |  | 67.8 |  |
| Corporate debt securities | 220.6 |  |  | 0.1 |  |  | (1.5 | ) |  | 219.2 |  |
| Municipal bonds | 1.6 |  |  | — |  |  | — |  |  | 1.6 |  |
| Mortgage-backed securities | 4.2 |  |  | — |  |  | — |  |  | 4.2 |  |
| Foreign government bonds | 3.4 |  |  | — |  |  | — |  |  | 3.4 |  |
| Total short-term investments | $ | 315.8 |  |  | $ | 0.1 |  |  | $ | (1.7 | ) |  | $ | 314.2 |  |
| July 1, 2017 |  |  |  |  |  |  |  |
| Cash | $ | 201.3 |  |  | $ | — |  |  | $ | — |  |  | $ | 201.3 |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | 52.1 |  |  | — |  |  | — |  |  | 52.1 |  |
| Commercial paper | 14.7 |  |  | — |  |  | — |  |  | 14.7 |  |
| Money market funds | 4.8 |  |  | — |  |  | — |  |  | 4.8 |  |
| Total cash and cash equivalents | $ | 272.9 |  |  | $ | — |  |  | $ | — |  |  | $ | 272.9 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 202.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 202.1 |  |
| Asset-backed securities | 26.1 |  |  | — |  |  | — |  |  | 26.1 |  |
| Corporate debt securities | 46.4 |  |  | — |  |  | — |  |  | 46.4 |  |
| Municipal bonds | 4.9 |  |  | — |  |  | — |  |  | 4.9 |  |
| Foreign government bonds | 1.0 |  |  | — |  |  | — |  |  | 1.0 |  |
| U.S. Treasury securities | 1.9 |  |  | — |  |  | — |  |  | 1.9 |  |
| Total short-term investments | $ | 282.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 282.4 |  |

[0001633978-18-000108:notes:124]
We use the specific-identification method to determine any realized gains or losses from the sale of our short-term investments classified as available-for-sale. During fiscal 2018 and 2017, we did not realize significant gains or losses on a gross level from the sale of our short-term investments classified as available-for-sale.

[0001633978-18-000108:notes:125]
During our fiscal 2018 and 2017, our interest and other income (expense), net of $(9.7) million and $(3.2) million, includes interest income on the short-term investments and cash equivalents of $8.5 million and $1.1 million, respectively.

[0001633978-18-000108:notes:126]
The following table summarizes unrealized losses on our cash equivalents and short-term investments by category and length of time the investment has been in a continuous unrealized loss position as of the periods presented (in millions):

[0001633978-18-000108:notes:127]
|  | Less than 12 Months |  | 12 Months or Greater |  | Total |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| June 30, 2018 |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 5.4 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 5.4 |  |  | $ | — |  |
| Commercial paper | 8.5 |  |  | — |  |  | — |  |  | — |  |  | 8.5 |  |  | — |  |
| Asset-backed securities | 66.6 |  |  | (0.2 | ) |  | 0.3 |  |  | — |  |  | 66.9 |  |  | (0.2 | ) |
| Corporate debt securities | 188.6 |  |  | (1.5 | ) |  | 2.0 |  |  | — |  |  | 190.6 |  |  | (1.5 | ) |
| Municipal bonds | 0.6 |  |  | — |  |  | — |  |  | — |  |  | 0.6 |  |  | — |  |
| U.S. Agency securities | 4.0 |  |  | — |  |  | — |  |  | — |  |  | 4.0 |  |  | — |  |
| Foreign government bonds | 3.4 |  |  | — |  |  | — |  |  | — |  |  | 3.4 |  |  | — |  |
| Total | $ | 277.1 |  |  | $ | (1.7 | ) |  | $ | 2.3 |  |  | $ | — |  |  | $ | 279.4 |  |  | $ | (1.7 | ) |
| July 1, 2017 |  |  |  |  |  |  |  |  |  |  |  |
| Asset-backed securities | $ | 21.5 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 21.5 |  |  | $ | — |  |
| Corporate debt securities | 29.8 |  |  | — |  |  | — |  |  | — |  |  | 29.8 |  |  | — |  |
| Municipal bonds | 2.9 |  |  | — |  |  | — |  |  | — |  |  | 2.9 |  |  | — |  |
| Foreign government bonds | 1.0 |  |  | — |  |  | — |  |  | — |  |  | 1.0 |  |  | — |  |
| U.S. Treasury securities | 1.9 |  |  | — |  |  | — |  |  | — |  |  | 1.9 |  |  | — |  |
| Total | $ | 57.1 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 57.1 |  |  | $ | — |  |

[0001633978-18-000108:notes:128]
The following table classifies our short-term investments by contractual maturities (in millions):

[0001633978-18-000108:notes:129]
|  | June 30, 2018 |  | July 1, 2017 |
|  | Amortized Cost |  | Fair Value |  | Amortized Cost |  | Fair Value |
| Due in 1 year | $ | 150.1 |  |  | $ | 149.6 |  |  | $ | 231.6 |  |  | $ | 231.6 |  |
| Due in 1 year through 5 years | 157.2 |  |  | 156.1 |  |  | 48.4 |  |  | 48.4 |  |
| Due in 5 years through 10 years | 6.1 |  |  | 6.1 |  |  | 1.8 |  |  | 1.8 |  |
| Due after 10 years | 2.4 |  |  | 2.4 |  |  | 0.6 |  |  | 0.6 |  |
|  | $ | 315.8 |  |  | $ | 314.2 |  |  | $ | 282.4 |  |  | $ | 282.4 |  |

[0001633978-18-000108:notes:130]
All available-for-sale securities have been classified as current, based on management’s intent and ability to use the funds in current operations.


## us-gaap:ChangesInProjectedBenefitObligationsFairValueOfPlanAssetsAndFundedStatusOfPlanTableTextBlock

[0001633978-18-000108:notes:131]
The change in the benefit obligations and plan assets of the pension and benefits plan were as follows (in millions):

[0001633978-18-000108:notes:132]
|  | Pension Benefit Plan |
|  | 2018 |  | 2017 |
| Change in benefit obligation: |  |  |  |
| Benefit obligation at beginning of year | $ | 11.0 |  |  | $ | 8.2 |  |
| Service cost | 0.9 |  |  | 0.6 |  |
| Interest cost | 0.1 |  |  | — |  |
| Plan participants’ contribution | 0.5 |  |  | 0.5 |  |
| Actuarial (gains)/losses | (0.3 | ) |  | 0.5 |  |
| Benefits paid | 0.4 |  |  | 0.9 |  |
| Foreign exchange impact | (0.5 | ) |  | 0.3 |  |
| Benefit obligation at end of year | $ | 12.1 |  |  | $ | 11.0 |  |
| Change in plan assets: |  |  |  |
| Fair value of plan assets at beginning of year | $ | 7.1 |  |  | $ | 4.7 |  |
| Actual return on plan assets | 0.3 |  |  | 0.1 |  |
| Employer contribution | 0.5 |  |  | 0.8 |  |
| Plan participants’ contribution | 0.5 |  |  | 0.5 |  |
| Benefits paid | 0.4 |  |  | 0.9 |  |
| Foreign exchange impact | (0.2 | ) |  | 0.1 |  |
| Fair value of plan assets at end of year | $ | 8.6 |  |  | $ | 7.1 |  |
| Funded status (1) | $ | (3.5 | ) |  | $ | (3.9 | ) |
| Accumulated benefit obligation | $ | 11.0 |  |  | $ | 8.2 |  |

[0001633978-18-000108:notes:133]
(1) As of June 30, 2018 and July 1, 2017, $3.5 million and $3.9 million, related to a funded status of the pension obligation, respectively, are included in other non-current liabilities on our consolidated balance sheet. Refer to “Note 7. Balance Sheet Details” in the Notes to Consolidated Financial Statements.


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0001633978-18-000108:notes:134]
Note 18. Commitments and Contingencies

[0001633978-18-000108:notes:135]
Operating Leases

[0001633978-18-000108:notes:136]
We lease certain real and personal property from unrelated third parties under non-cancellable operating leases that expire at various dates through fiscal 2026. Certain leases require us to pay property taxes, insurance and routine maintenance, and include escalation clauses. As of June 30, 2018 the future minimum annual lease payments under non-cancellable operating leases were as follows (in millions):

[0001633978-18-000108:notes:137]
| Fiscal Years |  |
| 2019 | $ | 11.6 |  |
| 2020 | 6.5 |  |
| 2021 | 5.1 |  |
| 2022 | 3.4 |  |
| 2023 | 2.4 |  |
| Thereafter | 1.8 |  |
| Total minimum operating lease payments | $ | 30.8 |  |

[0001633978-18-000108:notes:138]
Rental expense relating to building and equipment was $12.1 million, $10.1 million, and $7.4 million in fiscal 2018, 2017 and 2016, respectively.

[0001633978-18-000108:notes:139]
Capital Lease

[0001633978-18-000108:notes:140]
As of June 30, 2018, equipment acquired under a capital lease agreement was $15.6 million. Our capital lease asset is included in property, plant and equipment, net in our consolidated balance sheets as of June 30, 2018. Amortization expense on this capital lease asset is recorded as depreciation expense and is included in cost of sales in our consolidated statements of operations during fiscal 2018. Our capital lease obligation is recorded at the lesser of the estimated fair market value of the leased property or the net present value of the aggregate future minimum lease payments and is included in other current liabilities and other non-current liabilities in our consolidated balance sheets as of June 30, 2018. Refer to “Note 7. Balance Sheet Details” for capital lease obligation amounts in other current liabilities and other non-current liabilities. Interest on these obligations is included in interest expense in our consolidated statements of operations.

[0001633978-18-000108:notes:141]
As of June 30, 2018 the future minimum annual lease payments under our capital lease were as follows (in millions):

[0001633978-18-000108:notes:142]
| Fiscal Years |  |
| 2019 | $ | 9.0 |  |
| 2020 | 0.4 |  |
| Total minimum capital lease payments | $ | 9.4 |  |
| Less: amount representing interest | $ | (0.1 | ) |
| Present value of capital lease obligation | $ | 9.3 |  |

[0001633978-18-000108:notes:143]
Acquisition Contingencies

[0001633978-18-000108:notes:144]
We incurred liabilities in the amount of $3.6 million in connection with the fiscal 2017 acquisition. The amount of $2.7 million is payable in 36 months following the acquisition date contingent upon meeting certain production targets. We also retained $0.9 million of the purchase price as security for any potential liabilities of the seller under the representations, warranties and indemnifications included in the purchase agreement, the amount was fully paid to the seller subsequent to the year ended June 30, 2018.

[0001633978-18-000108:notes:145]
In March 2018, we entered into the Merger Agreement to acquire Oclaro. As of August 23, 2018, the total transaction consideration was expected to be approximately $1.7 billion, which would be funded by a combination of $700 million in Lumentum common stock, $500 million in new debt, and the remaining amount from the cash balances of the combined company. We expect the acquisition to close in the second half of calendar 2018, subject to customary closing conditions.

[0001633978-18-000108:notes:146]
0.25% Convertible Senior Notes due 2024

[0001633978-18-000108:notes:147]
The future interest and principal payments related to the 2024 Notes are as follows as of June 30, 2018:

[0001633978-18-000108:notes:148]
| Fiscal Years |  |
| 2019 | $ | 1.1 |  |
| 2020 | 1.1 |  |
| 2021 | 1.1 |  |
| 2022 | 1.1 |  |
| 2023 | 1.1 |  |
| Thereafter | 451.2 |  |
| Total 2024 Notes payments | $ | 456.7 |  |

[0001633978-18-000108:notes:149]
Purchase Obligations

[0001633978-18-000108:notes:150]
Purchase obligations of $173.5 million as of June 30, 2018, represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule and adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

[0001633978-18-000108:notes:151]
We depend on a limited number of contract manufacturers, subcontractors and suppliers for raw materials, packages and standard components. We generally purchase these single or limited source products through standard purchase orders or one-year supply agreements and have no significant long-term guaranteed supply agreements with such vendors. While we seek to maintain a sufficient safety stock of such products and maintain on-going communications with our suppliers to guard against interruptions or cessation of supply, our business and results of operations could be adversely affected by a stoppage or delay of supply, substitution of more expensive or less reliable products, receipt of defective parts or contaminated materials, increases in the price of such supplies, or our inability to obtain reduced pricing from our suppliers in response to competitive pressures.

[0001633978-18-000108:notes:152]
Product Warranties

[0001633978-18-000108:notes:153]
We provide reserves for the estimated costs of product warranties at the time revenue is recognized. We typically offer a twelve month warranty for most of our products. However, in some instances depending upon the product, product component or application of our products by the end customer, our warranties can vary and generally range from six months to five years. We estimate the costs of our warranty obligations on an annualized basis based on our historical experience of known product failure rates, use of materials to repair or replace defective products and service delivery costs incurred in correcting product failures. In addition, from time to time, specific warranty accruals may be made if unforeseen technical problems arise with specific products. We assess the adequacy of our recorded warranty liabilities and adjust the amounts as necessary.

[0001633978-18-000108:notes:154]
The following table presents the changes in our warranty reserve during fiscal 2018 and fiscal 2017 (in millions):

[0001633978-18-000108:notes:155]
|  | Years Ended |
|  | June 30, 2018 |  | July 1, 2017 |
| Balance as of beginning of year | $ | 9.7 |  |  | $ | 2.8 |  |
| Provision for warranty (1) | 5.0 |  |  | 14.9 |  |
| Utilization of reserve | (8.1 | ) |  | (8.0 | ) |
| Balance as of year end | $ | 6.6 |  |  | $ | 9.7 |  |

[0001633978-18-000108:notes:156]
(1) This does not include a settlement payment of $5.1 million received from a vendor for a quality issue during fiscal 2018.

[0001633978-18-000108:notes:157]
Environmental Liabilities

[0001633978-18-000108:notes:158]
Our research and development (“R&D”), manufacturing and distribution operations involve the use of hazardous substances and are regulated under international, federal, state and local laws governing health and safety and the environment. We apply strict standards for protection of the environment and occupational health and safety to sites inside and outside the United States, even if not subject to regulations imposed by foreign governments. We believe that our properties and operations at our facilities comply in all material respects with applicable environmental laws and occupational health and safety laws. However, the risk of environmental liabilities cannot be completely eliminated and there can be no assurance that the application of environmental and health and safety laws will not require us to incur significant expenditures. We are also regulated under a number of international, federal, state and local laws regarding recycling, product packaging and product content requirements. The environmental, product content/disposal and recycling laws are gradually becoming more stringent and may cause us to incur significant expenditures in the future.

[0001633978-18-000108:notes:159]
In connection with the Separation, we agreed to indemnify Viavi for any liability associated with contamination from past operations at all properties transferred to us from Viavi, to the extent the resulting issues primarily related to our business.

[0001633978-18-000108:notes:160]
Legal Proceedings

[0001633978-18-000108:notes:161]
We are subject to a variety of claims and suits that arise from time to time in the ordinary course of our business. While management currently believes that resolving claims against us, individually or in the aggregate, will not have a material adverse impact on our financial position, results of operations or statements of cash flows, these matters are subject to inherent uncertainties and management’s view of these matters may change in the future. We accrue for loss contingencies when it is both probable that we will incur the loss and when we can reasonably estimate the amount of the loss or range of loss.

[0001633978-18-000108:notes:162]
Indemnifications

[0001633978-18-000108:notes:163]
In the normal course of business, we enter into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown because claims may be made against us in the future and we may record charges in the future as a result of these indemnification obligations. As of June 30, 2018, we did not have any material indemnification claims that were probable or reasonably possible.

[0001633978-18-000108:notes:164]
Audit Proceedings

[0001633978-18-000108:notes:165]
We are under audit by various domestic and foreign tax authorities with regards to income tax and indirect tax matters. In some, although not all cases, we have reserved for potential adjustments to our provision for income taxes and accrual of indirect taxes that may result from examinations by these tax authorities or final outcomes in judicial proceedings, and we believe that the final outcome of these examinations, agreements or judicial proceedings will not have a material effect on our results of operations. If events occur which indicate payment of these amounts is unnecessary, the reversal of the liabilities would result in the recognition of benefits in the period we determine the liabilities are no longer necessary. If our estimates of the federal, state, and foreign income tax liabilities and indirect tax liabilities are less than the ultimate assessment, it could result in a further charge to expense.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001633978-18-000108:notes:166]
Note 5. Accumulated Other Comprehensive Income (Loss)

[0001633978-18-000108:notes:167]
Our accumulated other comprehensive income (loss) consists of the accumulated net unrealized gains or losses on foreign currency translation adjustments, the defined benefit obligation, and available-for-sale securities.

[0001633978-18-000108:notes:168]
As of June 30, 2018 and July 1, 2017, balances for the components of accumulated other comprehensive income (loss) were as follows (in millions):

[0001633978-18-000108:notes:169]
|  | Foreign currency translation adjustments, net of tax |  | Defined benefit obligation, net of tax (1) |  | Unrealized gain (loss) on available-for-sale securities, net of tax |  | Total |
| Beginning balance as of June 27, 2015 | $ | 13.7 |  |  | $ | (1.2 | ) |  | $ | — |  |  | $ | 12.5 |  |
| Other comprehensive income (loss) | (2.0 | ) |  | (1.1 | ) |  | — |  |  | (3.1 | ) |
| Beginning balance as of July 2, 2016 | 11.7 |  |  | (2.3 | ) |  | — |  |  | 9.4 |  |
| Other comprehensive income (loss) | (1.2 | ) |  | (0.8 | ) |  | — |  |  | (2.0 | ) |
| Beginning balance as of July 1, 2017 | 10.5 |  |  | (3.1 | ) |  | — |  |  | 7.4 |  |
| Other comprehensive income (loss) | (0.2 | ) |  | 0.8 |  |  | (1.6 | ) |  | (1.0 | ) |
| Ending balance as of June 30, 2018 | $ | 10.3 |  |  | $ | (2.3 | ) |  | $ | (1.6 | ) |  | $ | 6.4 |  |

[0001633978-18-000108:notes:170]
(1) Refer to “Note 17. Employee Benefit Plans” in the Notes to Consolidated Financial Statements on the computation of net periodic cost for pension plans.


## us-gaap:ConvertibleDebtTableTextBlock

[0001633978-18-000108:notes:171]
The 2024 Notes consisted of the following components as of the years ended June 30, 2018 and July 1, 2017 (in millions):

[0001633978-18-000108:notes:172]
| Liability component: | June 30, 2018 |  | July 1, 2017 |
| Principal | $ | 450.0 |  |  | $ | 450.0 |  |
| Unamortized debt discount | (115.8 | ) |  | (132.5 | ) |
| Net carrying amount of the liability component | $ | 334.2 |  |  | $ | 317.5 |  |


## us-gaap:DebtDisclosureTextBlock

[0001633978-18-000108:notes:173]
Note 11. Convertible Senior Notes

[0001633978-18-000108:notes:174]
In March 2017, we issued the 2024 Notes in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act of 1933, as amended (the “Securities Act”). The 2024 Notes are governed by an indenture between the Company, as the issuer, and U.S. Bank National Association, as trustee (the “Indenture”). The 2024 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001633978-18-000108:notes:175]
The 2024 Notes bear interest at a rate of 0.25% per year. Interest on the 2024 Notes is payable semi-annually in arrears on March 15 and September 15 of each year, beginning on September 15, 2017. The 2024 Notes will mature on March 15, 2024, unless earlier repurchased by us or converted pursuant to their terms.

[0001633978-18-000108:notes:176]
The initial conversion rate of the 2024 Notes is 16.4965 shares of common stock per $1,000 principal amount of 2024 Notes, which is equivalent to an initial conversion price of approximately $60.62 per share, a 132.5% premium to the fair market value at the date of issuance. Prior to the close of business on the business day immediately preceding December 15, 2023, the 2024 Notes will be convertible only under the following circumstances: (1) during any fiscal quarter (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during the period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price, or $78.80, on each applicable trading day; (2) during the five consecutive business day period after any five consecutive trading day period (the “measurement period”) in which the trading price per $1,000 principal amount of notes for each trading day of such measurement period was less than 98% of the product of the last reported sale price of our  common stock and the applicable conversion rate on each such trading day; or (3) upon the occurrence of specified corporate events. On or after December 15, 2023 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their notes at any time. In addition, upon the occurrence of a make-whole fundamental change, we will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert 2024 Notes in connection with such make-whole fundamental change.

[0001633978-18-000108:notes:177]
We may not redeem the 2024 Notes prior to their maturity date and no sinking fund is provided for the 2024 Notes. Upon the occurrence of a fundamental change, holders may require us to repurchase all or a portion of their 2024 Notes for cash at a price equal to 100% of the principal amount of the 2024 Notes to be repurchased, plus any accrued and unpaid interest.

[0001633978-18-000108:notes:178]
We considered the features embedded in the 2024 Notes other than the conversion feature, including the holders’ put feature, our call feature, and the make-whole feature, and concluded that they are not required to be bifurcated and accounted for separately from the host debt instrument.

[0001633978-18-000108:notes:179]
Prior to the TMA settlement condition, because we could only settle the 2024 Notes in cash, we determined that the conversion feature met the definition of a derivative liability. We separated the derivative liability from the host debt instrument based on the fair value of the derivative liability. As of the issuance date, March 8, 2017, the derivative liability fair value of $129.9 million was calculated using the binomial valuation approach. The residual principal amount of the 2024 Notes of $320.1 million before issuance costs was allocated to the debt component. We incurred approximately $7.7 million in transaction costs in connection with the issuance of the 2024 Notes. These costs were allocated to the debt component and recognized as a debt discount. We amortize the debt discount, including both the initial value of the derivative liability and the transaction costs, over the term of the 2024 Notes using the effective interest method. The effective interest rate of the 2024 Notes is 5.4% per year. As of June 30, 2018, the remaining debt discount amortization period was 68 months.

[0001633978-18-000108:notes:180]
During the year ended July 1, 2017, we satisfied the TMA settlement condition. As such, the value of the conversion option will no longer be marked to market and was reclassified to additional paid-in capital within stockholders’ equity on our consolidated balance sheet. The value of the conversion option at the time of issuance will be treated as an original issue discount for purposes of accounting for the debt component of the notes. The debt component will accrete up to the principal amount over the expected term of the debt. These accounting standards do not affect the actual amount we are required to repay, and the amount shown in the table below for the notes is the aggregate principal amount of the notes and does not reflect the debt discount we will be required to recognize.

[0001633978-18-000108:notes:181]
The following table sets forth interest expense information related to the 2024 Notes for the periods presented (in millions, except percentages):

[0001633978-18-000108:notes:182]
|  | June 30, 2018 |  | July 1, 2017 |
| Contractual interest expense | $ | 1.2 |  |  | $ | 0.4 |  |
| Amortization of the debt discount | 16.7 |  |  | 5.1 |  |
| Total interest expense | $ | 17.9 |  |  | $ | 5.5 |  |
| Effective interest rate on the liability component | 5.4 | % |  | 5.4 | % |

[0001633978-18-000108:notes:183]
We have the ability and intent to settle the $450 million face value of the debt in cash. Therefore, we use the treasury stock method for calculating the dilutive impact of the debt. The 2024 Notes will have no impact to diluted earnings per share until the average price of our common stock exceeds the conversion price of $60.62.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001633978-18-000108:notes:184]
Note 12. Derivative Liability

[0001633978-18-000108:notes:185]
We estimate the fair value of the embedded derivative for the Series A Preferred Stock using the binomial lattice model. We applied the lattice model to value the embedded derivative using a “with-and-without method,” where the value of the Series A Preferred Stock, including the embedded derivative, is defined as the “with”, and the value of the Series A Preferred Stock, excluding the embedded derivative, is defined as the “without”. The lattice model requires the following inputs: (i) the Company's common stock price; (ii) conversion price; (iii) term; (iv) yield; (v) recovery rate for the Series A Preferred Stock; (vi) estimated stock volatility; and (vii) risk-free rate. The fair value of the embedded derivative was determined using Level 3 inputs under the fair value hierarchy (unobservable inputs). Changes in the inputs into this valuation model have a material impact in the estimated fair value of the embedded derivative. For example, a decrease (increase) in the stock price and the volatility results in a decrease (increase) in the estimated fair value of the embedded derivative. The changes in the fair value of the bifurcated embedded derivative for the Series A Preferred Stock are primarily related to the change in the price of our common stock and are reflected in the consolidated statements of operations as “Unrealized gain (loss) on derivative liabilities”. Unrealized loss on derivative liability for the Series A Preferred Stock amounted to $0.8 million, $41.3 million, and $0.6 million for the fiscal years ended June 30, 2018, July 1, 2017, and July 2, 2016, respectively.

[0001633978-18-000108:notes:186]
The following table provides a reconciliation of the fair value of the embedded derivative for the Series A Preferred Stock for the years ended June 30, 2018 and July 1, 2017 (in millions):

[0001633978-18-000108:notes:187]
|  | June 30, 2018 |  | July 1, 2017 |
| Balance as of beginning of period | $ | 51.6 |  |  | $ | 10.3 |  |
| Unrealized loss on the Series A Preferred Stock derivative liability | 0.8 |  |  | 41.3 |  |
| Balance as of end of period | $ | 52.4 |  |  | $ | 51.6 |  |

[0001633978-18-000108:notes:188]
The following table summarizes the assumptions used to determine the fair value of the embedded derivative for Series A Preferred Stock:

[0001633978-18-000108:notes:189]
|  | June 30, 2018 |  | July 1, 2017 |
| Stock price | $ | 57.90 |  |  | $ | 57.05 |  |
| Conversion price | $ | 24.63 |  |  | $ | 24.63 |  |
| Expected term (years) | 2.11 |  |  | 3.11 |  |
| Expected annual volatility | 50.0 | % |  | 47.5 | % |
| Risk-free rate | 2.53 | % |  | 1.57 | % |
| Preferred yield | 8.58 | % |  | 7.56 | % |

[0001633978-18-000108:notes:190]
On March 8, 2017, we issued $450 million in aggregate principal amount of 2024 Notes. On June 29, 2017, we satisfied the TMA settlement condition. As such, we met the requirements to account for the conversion option of the 2024 Notes as equity and the conversion option is no longer marked to market. Refer to “Note 11. Convertible Senior Notes” in the Notes to Consolidated Financial Statements.

[0001633978-18-000108:notes:191]
The following table provides a reconciliation of the fair value of the embedded derivative for the 2024 Notes for the year ended July 1, 2017 (in millions):

[0001633978-18-000108:notes:192]
|  | July 1, 2017 |
| Balance as of beginning of period | $ | — |  |
| Fair value of the embedded derivative for the 2024 Notes at issuance | 129.9 |  |
| Unrealized loss on the 2024 Notes derivative liability | 62.9 |  |
| Reclassification of the 2024 Notes derivative liability in connection with TMA settlement condition | (192.8 | ) |
| Balance as of end of period | $ | — |  |

[0001633978-18-000108:notes:193]
The following table summarizes the assumptions used to determine the fair value of the embedded derivative for the 2024 Notes at the issuance date and as of June 29, 2017, when we satisfied the TMA settlement condition:

[0001633978-18-000108:notes:194]
|  | June 29, 2017 |  | March 8, 2017 |
| Stock price | $ | 57.30 |  |  | $ | 45.50 |  |
| Conversion price | $ | 60.62 |  |  | $ | 60.62 |  |
| Expected term (years) | 6.7 |  |  | 7.0 |  |
| Expected annual volatility | 47.5 | % |  | 45.0 | % |
| Risk-free rate | 2.10 | % |  | 2.40 | % |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001633978-18-000108:notes:195]
Note 16. Stock-Based Compensation and Stock Plans

[0001633978-18-000108:notes:196]
Description of Lumentum Stock-Based Benefit Plans

[0001633978-18-000108:notes:197]
Stock Option Plans

[0001633978-18-000108:notes:198]
On June 23, 2015, we adopted, and the board of directors of JDSU approved, the 2015 Equity Incentive Plan (the “2015 Plan”) under which 8.5 million shares of our common stock were authorized for issuance, which was ratified by our board of directors in August 2015. In connection with our Separation from JDSU on July 31, 2015, outstanding JDSU equity-based awards held by service providers continuing in service after the Separation were converted into equity-based awards under the 2015 Plan reducing the number of shares remaining available for grant under the 2015 Plan. Immediately following our Separation from JDSU, 2.1 million shares of our common stock were reserved pursuant to outstanding equity-based awards under the 2015 Plan that were converted from JDSU equity-based awards.

[0001633978-18-000108:notes:199]
On November 4, 2016, our stockholders approved an amendment to increase the number of shares that may be issued under the 2015 Plan by 3.0 million shares, and certain other material terms of the 2015 Plan.

[0001633978-18-000108:notes:200]
As of June 30, 2018, we had 1.9 million shares subject to stock options, restricted stock units, restricted stock awards, and performance stock units issued and outstanding under the 2015 Plan. Restricted stock units, restricted stock awards, and performance stock units are performance-based, time-based or a combination of both and are expected to vest over one to four years. The fair value of these grants is based on the closing market price of our common stock on the date of award.

[0001633978-18-000108:notes:201]
The exercise price for stock options is equal to the fair value of the underlying stock at the date of grant. We issue new shares of common stock upon exercise of stock options. Options generally become exercisable over a three-year or four-year period and, if not exercised, expire from five to ten years after the date of grant.

[0001633978-18-000108:notes:202]
As of June 30, 2018, 5.6 million shares of common stock under the 2015 Plan were available for grant.

[0001633978-18-000108:notes:203]
Employee Stock Purchase Plan

[0001633978-18-000108:notes:204]
On June 23, 2015, we adopted, and the board of directors of JDSU approved, the 2015 Employee Stock Purchase Plan (the “2015 Purchase Plan”) under which 3.0 million shares of our common stock were authorized for issuance, which was ratified by our board of directors in August 2015. The 2015 Purchase Plan provides eligible employees with the opportunity to acquire an ownership interest in the Company through periodic payroll deductions and provides a 15% purchase price discount as well as a six-month look-back period. The 2015 Purchase Plan is structured as a qualified employee stock purchase plan under Section 423 of the Internal Revenue Code of 1986. However, the 2015 Purchase Plan is not intended to be a qualified pension, profit sharing or stock bonus plan under Section 401(a) of the Internal Revenue Code of 1986 and is not subject to the provisions of the Employee Retirement Income Security Act of 1974. The 2015 Purchase Plan will terminate upon the date on which all shares available for issuance have been sold. Of the 3.0 million shares authorized under the 2015 Purchase Plan, 2.3 million shares remained available for issuance as of June 30, 2018.

[0001633978-18-000108:notes:205]
Restricted Stock Units

[0001633978-18-000108:notes:206]
Restricted stock units (“RSUs”) under the 2015 Plan are grants of shares of our common stock, the vesting of which is based on the requisite service requirement. Generally, our RSUs are subject to forfeiture and expected to vest over one to four years. For annual refresh grants, RSUs generally vest ratably on an annual, or combination of annual and quarterly, basis over three years.

[0001633978-18-000108:notes:207]
Restricted Stock Awards

[0001633978-18-000108:notes:208]
Restricted stock awards (“RSAs”) under the 2015 Plan are grants of shares of our common stock that are subject to various restrictions, including restrictions on transferability and forfeiture provisions. RSAs are expected to vest over one to four years, and the shares acquired may not be transferred by the holder until the vesting conditions (if any) are satisfied.

[0001633978-18-000108:notes:209]
Performance Stock Units

[0001633978-18-000108:notes:210]
Performance stock units (“PSUs”) under the 2015 Plan are grants of shares of our common stock that vest upon the achievement of certain performance and service conditions. We begin recognizing compensation expense when we conclude that it is probable that the performance conditions will be achieved. We reassess the probability of vesting at each reporting period and adjust our compensation cost based on this probability assessment. Our PSUs are subject to risk of forfeiture until performance and service conditions are satisfied and generally vest over three years.

[0001633978-18-000108:notes:211]
During fiscal 2018, we granted 0.1 million PSUs to senior members of our management team and recorded $2.4 million expense related to these grants based on the revenue performance condition that was achieved in fiscal 2018.

[0001633978-18-000108:notes:212]
Stock-Based Compensation

[0001633978-18-000108:notes:213]
The impact on our results of operations of recording stock-based compensation by function for fiscal 2018, 2017 and 2016 was as follows (in millions):

[0001633978-18-000108:notes:214]
|  | Years Ended |
|  | June 30, 2018 |  | July 1, 2017 |  | July 2, 2016 |
| Cost of sales | $ | 12.6 |  |  | $ | 7.5 |  |  | $ | 6.1 |  |
| Research and development | 14.2 |  |  | 11.6 |  |  | 9.0 |  |
| Selling, general and administrative | 20.0 |  |  | 13.6 |  |  | 11.8 |  |
|  | $ | 46.8 |  |  | $ | 32.7 |  |  | $ | 26.9 |  |

[0001633978-18-000108:notes:215]
Approximately $2.6 million and $1.8 million of stock-based compensation was capitalized to inventory as of June 30, 2018 and July 1, 2017. The table above includes allocated stock-based compensation from Viavi of $2.0 million for fiscal 2016. There were no allocations to stock-based compensation from Viavi during the years ended June 30, 2018 and July 1, 2017. Refer to “Note 3. Related Party Transactions” in the Notes to Consolidated Financial Statements.

[0001633978-18-000108:notes:216]
Stock Option and Stock Award Activity

[0001633978-18-000108:notes:217]
We did not grant any stock options during fiscal 2018 or 2017. During fiscal 2018 and 2017, there were 44,784 options and 239,753 options exercised.

[0001633978-18-000108:notes:218]
As of June 30, 2018, there were no options outstanding under the 2015 Plan. As of June 30, 2018 and July 1, 2017, the total intrinsic value of options exercised by our employees was $0.9 million and $5.6 million, respectively.

[0001633978-18-000108:notes:219]
In connection with these exercises, the excess tax benefit realized during the year ended July 1, 2017 was $3.8 million. In fiscal 2018, due to adoption of ASU 2016-09, all excess tax benefits and deficiencies were recognized in the income tax provision in the consolidated statements of operations, rather than in additional paid-in-capital in the consolidated balance sheets. Refer to “Note 2. Recent Accounting Pronouncements” in the Notes to Consolidated Financial Statements for further discussion on the impact of the adoption of ASU 2016-09.

[0001633978-18-000108:notes:220]
The following table summarizes our awards activity in fiscal 2018, 2017, and 2016 (amounts in millions except per share amounts):

[0001633978-18-000108:notes:221]
|  | Options |  | Restricted Stock Units |  | Restricted Stock Awards |  | Performance Stock Units |
|  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |
| Unvested balance as of June 27, 2015 | 0.5 |  |  | $ | 19.01 |  |  | 1.5 |  |  | $ | 23.81 |  |  | — |  |  | $ | — |  |  | 0.2 |  |  | $ | 14.40 |  |
| Granted | — |  |  | — |  |  | 1.9 |  |  | 20.39 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Exercised / Vested | (0.2 | ) |  | 15.21 |  |  | (0.7 | ) |  | 23.77 |  |  | — |  |  | — |  |  | (0.1 | ) |  | 14.40 |  |
| Canceled | — |  |  | — |  |  | (0.2 | ) |  | 21.85 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Unvested balance as of July 2, 2016 | 0.3 |  |  | $ | 17.83 |  |  | 2.5 |  |  | $ | 21.31 |  |  | — |  |  | $ | — |  |  | 0.1 |  |  | $ | 14.40 |  |
| Granted | — |  |  | — |  |  | 1.0 |  |  | 35.57 |  |  | 0.3 |  |  | 32.51 |  |  | — |  |  | — |  |
| Exercised / Vested | (0.3 | ) |  | 14.29 |  |  | (1.4 | ) |  | 22.26 |  |  | — |  |  | — |  |  | (0.1 | ) |  | 14.40 |  |
| Canceled | — |  |  | — |  |  | (0.2 | ) |  | 23.78 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Unvested balance as of July 1, 2017 | — |  |  | $ | — |  |  | 1.9 |  |  | $ | 27.88 |  |  | 0.3 |  |  | $ | 32.51 |  |  | — |  |  | $ | — |  |
| Granted (1) | — |  |  | — |  |  | 1.1 |  |  | 54.52 |  |  | — |  |  | — |  |  | 0.1 |  |  | 52.00 |  |
| Vested | — |  |  | — |  |  | (1.1 | ) |  | 26.62 |  |  | (0.2 | ) |  | 32.51 |  |  | — |  |  | — |  |
| Canceled | — |  |  | — |  |  | (0.2 | ) |  | 38.82 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Unvested balance as of June 30, 2018 | — |  |  | $ | — |  |  | 1.7 |  |  | $ | 43.08 |  |  | 0.1 |  |  | $ | 32.51 |  |  | 0.1 |  |  | $ | 52.00 |  |

[0001633978-18-000108:notes:222]
(1) PSUs granted represent 100% of target goal; under the terms of the awards, the recipient may earn between 0% and 200% of the original grant. The performance condition has been achieved during the year ended June 30, 2018.

[0001633978-18-000108:notes:223]
As of June 30, 2018, $65.5 million of stock-based compensation cost related to awards granted to our employees remains to be amortized. That cost is expected to be recognized over an estimated amortization period of 1.8 years.

[0001633978-18-000108:notes:224]
Employee Stock Purchase Plan Activity

[0001633978-18-000108:notes:225]
The 2015 Purchase Plan expense for the years ended June 30, 2018 and July 1, 2017 was $3.3 million and $2.7 million, respectively. The expense related to the 2015 Purchase Plan is recorded on a straight-line basis over the relevant subscription period. During fiscal 2018 and 2017, there were 191,703 shares and 314,800 shares issued to employees through the 2015 Purchase Plan with the average fair market value at the purchase date of $48.50 and $25.64, respectively.

[0001633978-18-000108:notes:226]
We estimate the fair value of the 2015 Purchase Plan shares on the date of grant using the Black-Scholes option-pricing model. The assumptions used to estimate the fair value of the 2015 Purchase Plan shares to be issued during the periods presented were as follows:

[0001633978-18-000108:notes:227]
|  | June 30, 2018 |  | July 1, 2017 |
| Expected term (years) | 0.5 |  |  | 0.5 |  |
| Expected volatility | 58.8 | % |  | 46.0 | % |
| Risk-free interest rate | 2.02 | % |  | 0.62 | % |
| Dividend yield | — | % |  | — | % |


## us-gaap:EarningsPerShareTextBlock

[0001633978-18-000108:notes:228]
Note 4. Earnings Per Share

[0001633978-18-000108:notes:229]
The following table sets forth the computation of basic and diluted net income (loss) attributable to common stockholders per share (in millions, except per share data):

[0001633978-18-000108:notes:230]
|  | Years Ended |
|  | June 30, 2018 |  | July 1, 2017 |  | July 2, 2016 |
| Basic Earnings per Common Share |  |  |  |  |  |  |  |  |
| Net income (loss) | $ | 248.1 |  |  | $ | (102.5 | ) |  | $ | 9.3 |  |
| Less: Cumulative dividends on Series A Preferred Stock | (0.9 | ) |  | (0.9 | ) |  | (0.8 | ) |
| Less: Earnings allocated to Series A Preferred Stock | (5.7 | ) |  | — |  |  | — |  |
| Less: Accretion of Series A Preferred Stock | — |  |  | — |  |  | (11.7 | ) |
| Net income (loss) attributable to common stockholders - Basic | $ | 241.5 |  |  | $ | (103.4 | ) |  | $ | (3.2 | ) |
| Weighted average common shares outstanding including Series A Preferred Stock | 63.8 |  |  | 62.1 |  |  | 60.4 |  |
| Less: Weighted average Series A Preferred Stock | (1.5 | ) |  | (1.5 | ) |  | (1.3 | ) |
| Basic weighted average common shares outstanding | 62.3 |  |  | 60.6 |  |  | 59.1 |  |
| Net income (loss) per share attributable to common stockholders - Basic | $ | 3.88 |  |  | $ | (1.71 | ) |  | $ | (0.05 | ) |
| Diluted Earnings per Common Share |  |  |  |  |  |
| Net income (loss) attributable to common stockholders - Diluted | $ | 241.5 |  |  | $ | (103.4 | ) |  | $ | (3.2 | ) |
| Weighted average common shares outstanding for basic earnings per common share | 62.3 |  |  | 60.6 |  |  | 59.1 |  |
| Effect of dilutive securities from 2015 Equity Incentive Plan | 1.0 |  |  | — |  |  | — |  |
| Effect of diluted securities from Series A Preferred Stock | — |  |  | — |  |  | — |  |
| Diluted weighted average common shares outstanding | 63.3 |  |  | 60.6 |  |  | 59.1 |  |
| Net income (loss) per share attributable to common stockholders - Diluted | $ | 3.82 |  |  | $ | (1.71 | ) |  | $ | (0.05 | ) |

[0001633978-18-000108:notes:231]
On August 1, 2015, JDSU distributed 47.1 million shares, or 80.1% of the outstanding shares of the Company’s common stock to existing holders of JDSU common stock. The weighted average number of common stock outstanding is calculated as the number of shares of common stock outstanding immediately following the Separation, and the weighted average number of shares outstanding following the Separation through June 30, 2018. Diluted earnings (loss) per share is calculated by dividing net income for the period by the weighted average number of shares of common stock and potentially dilutive common stock outstanding for the period beginning after the Separation.

[0001633978-18-000108:notes:232]
In March 2017, we issued $450 million in aggregate principal amount of 2024 Notes. We have the ability and intent to settle the $450 million face value of the 2024 Notes in cash. Therefore, we use the treasury stock method for calculating the dilutive impact of the 2024 Notes. The 2024 Notes will have no impact to diluted earnings per share until the average price of our common stock exceeds the conversion price of $60.62. Refer to “Note 11. Convertible Senior Notes” for further discussion.

[0001633978-18-000108:notes:233]
For the year ended July 2, 2016, 1.2 million weighted average shares related to our 2015 Equity Incentive Plan were excluded from the calculation of diluted shares because their inclusion would have been anti-dilutive based on applying the treasury stock method. For the years ended June 30, 2018 and July 1, 2017, based on the treasury stock method, weighted average shares from 2015 Equity Incentive Plan excluded from the calculation of diluted shares were not material.

[0001633978-18-000108:notes:234]
For the years ended July 1, 2017 and July 2, 2016, 1.0 million and 0.8 million weighted average shares related to our 2015 Equity Incentive Plan, respectively, were excluded from the calculation of diluted shares due to the net loss reported in these periods.


## us-gaap:FairValueDisclosuresTextBlock

[0001633978-18-000108:notes:235]
Note 9. Fair Value Measurements

[0001633978-18-000108:notes:236]
We determine fair value based on the fair value hierarchy, which requires an entity to maximize the use of observable inputs and minimize the use of unobservable inputs when measuring fair value. Fair value is defined as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. The fair value assumes that the transaction to sell the asset or transfer the liability occurs in the principal or most advantageous market for the asset or liability and establishes that the fair value of an asset or liability shall be determined based on the assumptions that market participants would use in pricing the asset or liability. The classification of a financial asset or liability within the hierarchy is based upon the lowest level input that is significant to the fair value measurement. The fair value hierarchy prioritizes the inputs into three levels that may be used to measure fair value:

[0001633978-18-000108:notes:237]
| Level 1: | Inputs are unadjusted quoted prices in active markets for identical assets or liabilities. |
| Level 2: | Inputs are quoted prices for similar assets and liabilities in active markets or inputs that are observable for the asset or liability, either directly or indirectly through market corroboration, for substantially the full term of the financial instrument. |
| Level 3: | Inputs are unobservable inputs based on our assumptions. |

[0001633978-18-000108:notes:238]
The fair value of the Company’s Level 1 financial instruments, such as money market funds, which are traded in active markets, is based on quoted market prices for identical instruments. The fair value of the Company’s Level 2 fixed income securities is obtained from an independent pricing service, which may use quoted market prices for identical or comparable instruments or model driven valuations using observable market data or inputs corroborated by observable market data. Our marketable securities are held by custodians who obtain investment prices from a third-party pricing provider that incorporates standard inputs in various asset price models. The Company’s procedures include controls to ensure that appropriate fair values are recorded, including comparing the fair values obtained from the Company’s pricing service against fair values obtained from another independent source.

[0001633978-18-000108:notes:239]
We estimate the fair value of the embedded derivative for the Series A Preferred Stock using the binomial lattice model. The lattice model requires the various assumptions to be made to determine the fair value of the embedded derivatives. These assumptions represent Level 3 inputs. Refer to “Note 12. Derivative Liability” in the Notes to Consolidated Financial Statements.

[0001633978-18-000108:notes:240]
In February 2017, we completed the acquisition of a privately held company to enhance our manufacturing and vertical integration capabilities for a total purchase consideration of $8.7 million. We estimated the fair value of our Level 3 contingent consideration related to this acquisition at the present value of the expected contingent payments, determined using a probabilistic approach. We are required to reassess the fair value of contingent payments on a periodic basis. We estimated the likelihood of meeting the production targets at 90 percent and recorded the fair value of such contingent consideration in accrued liabilities on the consolidated balance sheet at the time of acquisition. There were no changes in the fair value of our contingent consideration during the years ended June 30, 2018 or July 1, 2017. This contingent consideration will result in a cash payment of $3.0 million, if and when the production targets are achieved, which we expect to occur within 36 months following the acquisition date.

[0001633978-18-000108:notes:241]
Our pension assets consist of multiple institutional funds (“pension funds”) of which the fair values are based on the quoted prices of the underlying funds. Pension funds are classified as Level 2 assets since such funds are not directly traded in active markets. Refer to “Note 17. Employee Benefit Plans” in the Notes to Consolidated Financial Statements.

[0001633978-18-000108:notes:242]
Financial assets and liabilities measured at fair value on a recurring basis are summarized below (in millions):

[0001633978-18-000108:notes:243]
| June 30, 2018 | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | — |  |  | $ | 3.0 |  |  | $ | — |  |  | $ | 3.0 |  |
| Commercial paper | — |  |  | 112.1 |  |  | — |  |  | 112.1 |  |
| Money market funds | 0.8 |  |  | — |  |  | — |  |  | 0.8 |  |
| U.S. Treasury securities | 143.6 |  |  | — |  |  | — |  |  | 143.6 |  |
| U.S. Agency securities | — |  |  | 34.2 |  |  | — |  |  | 34.2 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | 7.5 |  |  | — |  |  | 7.5 |  |
| Commercial paper | — |  |  | 10.5 |  |  | — |  |  | 10.5 |  |
| Asset-backed securities | — |  |  | 67.8 |  |  | — |  |  | 67.8 |  |
| Corporate debt securities | — |  |  | 219.2 |  |  | — |  |  | 219.2 |  |
| Municipal bonds | — |  |  | 1.6 |  |  | — |  |  | 1.6 |  |
| Mortgage-backed securities | — |  |  | 4.2 |  |  | — |  |  | 4.2 |  |
| Foreign government bonds | — |  |  | 3.4 |  |  | — |  |  | 3.4 |  |
| Total assets | $ | 144.4 |  |  | $ | 463.5 |  |  | $ | — |  |  | $ | 607.9 |  |
| Other accrued liabilities: |  |  |  |  |  |  |  |
| Derivative liability | $ | — |  |  | $ | — |  |  | $ | 52.4 |  |  | $ | 52.4 |  |
| Acquisition contingencies | — |  |  | — |  |  | 2.7 |  |  | 2.7 |  |
| Total other accrued liabilities | $ | — |  |  | $ | — |  |  | $ | 55.1 |  |  | $ | 55.1 |  |

[0001633978-18-000108:notes:244]
| July 1, 2017 | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | — |  |  | $ | 52.1 |  |  | $ | — |  |  | $ | 52.1 |  |
| Commercial paper | — |  |  | 14.7 |  |  | — |  |  | 14.7 |  |
| Money market funds | 4.8 |  |  | — |  |  | — |  |  | 4.8 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | 202.1 |  |  | — |  |  | 202.1 |  |
| Asset-backed securities | — |  |  | 26.1 |  |  | — |  |  | 26.1 |  |
| Corporate debt securities | — |  |  | 46.4 |  |  | — |  |  | 46.4 |  |
| Municipal bonds | — |  |  | 4.9 |  |  | — |  |  | 4.9 |  |
| Foreign government bonds | — |  |  | 1.0 |  |  | — |  |  | 1.0 |  |
| U.S. Treasury | 1.9 |  |  | — |  |  | — |  |  | 1.9 |  |
| Total assets | $ | 6.7 |  |  | $ | 347.3 |  |  | $ | — |  |  | $ | 354.0 |  |
| Other accrued liabilities: |  |  |  |  |  |  |  |
| Derivative liability | $ | — |  |  | $ | — |  |  | $ | 51.6 |  |  | $ | 51.6 |  |
| Acquisition contingencies | — |  |  | — |  |  | 2.7 |  |  | 2.7 |  |
| Total other accrued liabilities | $ | — |  |  | $ | — |  |  | $ | 54.3 |  |  | $ | 54.3 |  |

[0001633978-18-000108:notes:245]
Assets Measured at Fair Value on a Non-Recurring Basis

[0001633978-18-000108:notes:246]
We periodically review our intangible and other long-lived assets for impairment whenever events or changes in circumstances indicate that the carrying amount of such assets may not be recoverable. Determination of recoverability is based on the lowest level of identifiable estimated undiscounted cash flows resulting from use of the asset and its eventual disposition. If not recoverable, an impairment loss would be calculated based on the excess of the carrying amount over the fair value.

[0001633978-18-000108:notes:247]
Management utilizes various valuation methods, including an income approach, a market approach and a cost approach, to estimate the fair value of intangible and other long-lived assets. During the annual impairment testing performed in fiscal 2018, we concluded that our intangible and other long-lived assets were not impaired. No impairment charges were recorded in fiscal 2018, 2017, or 2016. Refer to “Note 13. Goodwill and Other Intangible Assets”.


## us-gaap:FiniteLivedIntangibleAssetsAmortizationExpenseTableTextBlock

[0001633978-18-000108:notes:248]
The following table presents details of amortization for the periods presented (in millions):

[0001633978-18-000108:notes:249]
|  | Years Ended |
|  | June 30, 2018 |  | July 1, 2017 |  | July 2, 2016 |
| Cost of sales | $ | 3.2 |  |  | $ | 6.5 |  |  | $ | 6.8 |  |
| Operating expense | — |  |  | 0.3 |  |  | 0.4 |  |
| Total | $ | 3.2 |  |  | $ | 6.8 |  |  | $ | 7.2 |  |


## us-gaap:GoodwillDisclosureTextBlock

[0001633978-18-000108:notes:250]
Note 13. Goodwill and Other Intangible Assets

[0001633978-18-000108:notes:251]
The following table presents the changes in goodwill by our reportable segments during the year ended June 30, 2018 (in millions):

[0001633978-18-000108:notes:252]
|  |  | Optical Communications |  | Commercial Lasers |  | Total |
| Balance as of July 2, 2016 | $ | — |  |  | $ | 5.4 |  |  | $ | 5.4 |  |
|  | Acquisition of a business | 5.6 |  |  | — |  |  | 5.6 |  |
|  | Foreign currency translation adjustment | 0.3 |  |  | 0.1 |  |  | 0.4 |  |
| Balance as of July 1, 2017 | $ | 5.9 |  |  | $ | 5.5 |  |  | $ | 11.4 |  |
|  | Foreign currency translation adjustment | — |  |  | (0.1 | ) |  | (0.1 | ) |
| Balance as of June 30, 2018 | $ | 5.9 |  |  | $ | 5.4 |  |  | $ | 11.3 |  |

[0001633978-18-000108:notes:253]
Impairment of Goodwill

[0001633978-18-000108:notes:254]
We review goodwill for impairment during the fourth quarter of each fiscal year or more frequently if events or circumstances indicate that an impairment loss may have occurred. During fiscal 2018, there have been no events or circumstances that have required us to perform an interim assessment of goodwill for impairment. In the fourth quarter of fiscal 2018, we completed the annual impairment test of goodwill, which indicated there was no goodwill impairment.

[0001633978-18-000108:notes:255]
Acquired Developed Technologies and Other Intangibles

[0001633978-18-000108:notes:256]
The following tables present details of our acquired developed technologies and other intangibles as of the periods presented (in millions):

[0001633978-18-000108:notes:257]
| June 30, 2018 | Gross Carrying Amount |  | Accumulated Amortization |  | Net |
| Acquired developed technologies | $ | 105.5 |  |  | $ | (98.5 | ) |  | $ | 7.0 |  |
| Other intangibles | 7.0 |  |  | (7.0 | ) |  | — |  |
| Total intangible assets | $ | 112.5 |  |  | $ | (105.5 | ) |  | $ | 7.0 |  |

[0001633978-18-000108:notes:258]
| July 1, 2017 | Gross Carrying Amount |  | Accumulated Amortization |  | Net |
| Acquired developed technologies | $ | 105.5 |  |  | $ | (95.4 | ) |  | $ | 10.1 |  |
| Other intangibles (1) | 7.0 |  |  | (7.0 | ) |  | — |  |
| Total intangible assets | $ | 112.5 |  |  | $ | (102.4 | ) |  | $ | 10.1 |  |

[0001633978-18-000108:notes:259]
The amounts in the table above include cumulative foreign currency translation adjustments, reflecting movement in the currencies of the underlying intangibles.

[0001633978-18-000108:notes:260]
During fiscal 2018, 2017 and 2016, we recorded $3.2 million, $6.8 million, and $7.2 million, respectively, of amortization related to acquired developed technologies and other intangibles. The following table presents details of amortization for the periods presented (in millions):

[0001633978-18-000108:notes:261]
Based on the carrying amount of acquired developed technologies as of June 30, 2018, and assuming no future impairment of the underlying assets, the estimated future amortization is as follows (in millions):

[0001633978-18-000108:notes:262]
| Fiscal Years |  |
| 2019 | $ | 3.0 |  |
| 2020 | 2.8 |  |
| 2021 | 0.5 |  |
| 2022 | 0.5 |  |
| Thereafter | 0.2 |  |
| Total amortization | $ | 7.0 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001633978-18-000108:notes:263]
Note 15. Income Taxes

[0001633978-18-000108:notes:264]
Our income (loss) before income taxes consisted of the following (in millions):

[0001633978-18-000108:notes:265]
|  | Years Ended |
|  | June 30, 2018 |  | July 1, 2017 |  | July 2, 2016 |
| Domestic | $ | 37.8 |  |  | $ | (78.4 | ) |  | $ | 60.7 |  |
| Foreign | 91.6 |  |  | 18.6 |  |  | (51.0 | ) |
| Income (loss) before income taxes | $ | 129.4 |  |  | $ | (59.8 | ) |  | $ | 9.7 |  |

[0001633978-18-000108:notes:266]
Our income tax (benefit) expense consisted of the following (in millions):

[0001633978-18-000108:notes:267]
|  | Years Ended |
|  | June 30, 2018 |  | July 1, 2017 |  | July 2, 2016 |
| Federal: |  |  |  |  |  |
| Current | $ | 1.2 |  |  | $ | 13.7 |  |  | $ | 1.6 |  |
| Deferred | (120.4 | ) |  | — |  |  | — |  |
|  | (119.2 | ) |  | 13.7 |  |  | 1.6 |  |
| State: |  |  |  |  |  |
| Current | 1.0 |  |  | 0.1 |  |  | 0.2 |  |
| Deferred | (1.3 | ) |  | — |  |  | — |  |
|  | (0.3 | ) |  | 0.1 |  |  | 0.2 |  |
| Foreign: |  |  |  |  |  |
| Current | 1.2 |  |  | 2.1 |  |  | 1.2 |  |
| Deferred | (0.4 | ) |  | 26.8 |  |  | (2.6 | ) |
|  | 0.8 |  |  | 28.9 |  |  | (1.4 | ) |
| Total income tax (benefit) expense | $ | (118.7 | ) |  | $ | 42.7 |  |  | $ | 0.4 |  |

[0001633978-18-000108:notes:268]
On December 22, 2017, the U.S. government enacted comprehensive tax legislation commonly referred to as the Tax Cuts and Jobs Act (the “Tax Act”). The Tax Act makes broad and complex changes to the U.S. tax code that affected our fiscal year ending June 30, 2018 including, but not limited to, (1) a reduction in the U.S. federal corporate tax rate; (2) a transition tax on certain deferred income of foreign subsidiaries that, if the taxpayer so elects, is payable over eight years; and (3) bonus depreciation that allows full expensing of qualified property. The Tax Act reduces the federal corporate tax rate to 21 percent effective January 1, 2018. Section 15 of the Internal Revenue Code stipulates that our fiscal year ending June 30, 2018 will have a blended corporate tax rate of 28 percent, which is based on the applicable tax rates before and after the Tax Act and the number of days in each period.

[0001633978-18-000108:notes:269]
The SEC staff issued SAB 118, which provides guidance on accounting for the tax effects of the Tax Act. SAB 118 provides a measurement period that should not extend beyond one year from the Tax Act enactment date for companies to complete the accounting under ASC 740. In accordance with SAB 118, a company must reflect the income tax effects of those aspects of the Tax Act for which the accounting under ASC 740 is complete. To the extent that a company’s accounting for certain income tax effects of the Tax Act is incomplete but it is able to determine a reasonable estimate, it must record a provisional estimate in the financial statements. If a company cannot determine a provisional estimate to be included in the financial statements, it should continue to apply ASC 740 on the basis of the provisions of the tax laws that were in effect immediately before the enactment of the Tax Act.

[0001633978-18-000108:notes:270]
Our accounting for the following elements of the Tax Act is incomplete. However, we were able to make reasonable estimates of certain effects and, therefore, recorded provisional adjustments as follows:

[0001633978-18-000108:notes:271]
| • | The Tax Act reduces the corporate tax rate to 21 percent, effective January 1, 2018. For certain of our deferred tax assets and deferred tax liabilities, we have recorded a provisional net decrease of deferred tax assets by $80.5 million (which we refined by $2.5 million decrease as of June 30, 2018 from our initial estimate in our second quarter of fiscal 2018 in accordance with SAB 118), with a corresponding net adjustment to deferred income tax expense of $80.5 million. While we are able to make a reasonable estimate of the impact of the reduction in corporate rate, it may be affected by other analyses related to the Tax Act, including, but not limited to, our calculation of deemed repatriation of deferred foreign income and the state tax effect of adjustments made to federal temporary differences. |

[0001633978-18-000108:notes:272]
| • | The Deemed Repatriation Transition Tax (“Transition Tax”) is a tax on previously untaxed accumulated and current earnings and profits (“E&P”) of certain of our foreign subsidiaries. To determine the amount of the Transition Tax, we must determine, in addition to other factors, the amount of post-1986 E&P of the relevant subsidiaries, as well as the amount of non-U.S. income taxes paid on such earnings. Our initial estimate of the Transition Tax is zero. We are continuing to gather additional information to more precisely compute the amount of the Transition Tax. |

[0001633978-18-000108:notes:273]
| • | Due to complexity of the new GILTI tax rules, we are continuing to evaluate this provision of the Tax Act and the application of ASC 740. We are allowed to make an accounting policy choice of either (1) treating taxes due on future U.S. inclusions in taxable income related to GILTI as a current-period expense when incurred (the “period cost method”) or (2) factoring such amounts into a company’s measurement of its deferred taxes (the “deferred method”). Our selection of an accounting policy with respect to the new GILTI tax rules will depend, in part, on analyzing our global income to determine whether we expect to have future U.S. inclusions in taxable income related to GILTI and, if so, what the impact is expected to be. Whether we expect to have future U.S. inclusions in taxable income related to GILTI depends not only on our current structure and estimated future results of global operations but also on our intent and ability to modify our structure and/or our business; as such, we are not yet able to reasonably estimate the effect of this provision of the Tax Act. Therefore, we have not made any adjustments related to potential GILTI tax in our financial statements and have not made a policy decision regarding whether to record deferred taxes on GILTI. |

[0001633978-18-000108:notes:274]
The net income tax expense related to the enactment of the Tax Act has been accounted for during fiscal 2018 based on provisional estimates pursuant to SAB 118. Subsequent adjustments, if any, will be accounted for in the period such adjustments are identified. The provisional estimates incorporate, among other factors, assumptions made based on interpretations of the Tax Act and existing tax laws and a range of historical financial and tax-specific facts and information.

[0001633978-18-000108:notes:275]
The Company’s effective tax rate differs from the U.S. Federal statutory income tax rate as follows (in millions):

[0001633978-18-000108:notes:276]
|  | Years Ended |
|  | June 30, 2018 |  | July 1, 2017 |  | July 2, 2016 |
| Income tax (benefit) expense computed at federal statutory rate | $ | 36.3 |  |  | $ | (20.9 | ) |  | $ | 3.4 |  |
| State taxes, net of federal benefit | (0.5 | ) |  | 0.1 |  |  | 0.1 |  |
| Foreign rate differential | (26.4 | ) |  | (4.8 | ) |  | 21.3 |  |
| Change in valuation allowance | (206.0 | ) |  | 21.5 |  |  | (29.4 | ) |
| U.S. Tax reform | 80.5 |  |  | — |  |  | — |  |
| Research and experimentation benefits and other tax credits | (11.0 | ) |  | (2.9 | ) |  | (4.4 | ) |
| Permanent items | (0.8 | ) |  | 0.3 |  |  | 0.7 |  |
| Stock-based compensation | (1.0 | ) |  | 4.9 |  |  | 4.3 |  |
| Fair value adjustment | 0.2 |  |  | 36.5 |  |  | — |  |
| Subpart F | 2.0 |  |  | — |  |  | 4.0 |  |
| Unrecognized tax benefits | 7.9 |  |  | 8.4 |  |  | — |  |
| Tax holiday | 2.1 |  |  | 0.1 |  |  | — |  |
| Return to provision | (1.8 | ) |  | (0.1 | ) |  | (0.1 | ) |
| Other | (0.2 | ) |  | (0.4 | ) |  | 0.5 |  |
| Total income tax (benefit) expense | $ | (118.7 | ) |  | $ | 42.7 |  |  | $ | 0.4 |  |

[0001633978-18-000108:notes:277]
The comparability of our operating results in fiscal 2018 compared to the corresponding prior year periods was impacted by the Tax Act, which reduces the U.S. federal corporate tax rate from 35% to 21%.

[0001633978-18-000108:notes:278]
During fiscal 2018, our provision for income taxes decreased primarily as a result of $207.2 million of income tax benefit related to the release of valuation allowance against our U.S. federal and certain state deferred tax assets, partially offset by $80.5 million of income tax expense related to the remeasurement of our net deferred tax assets as a result of reduction in the U.S. federal corporate tax rate. Our provision for income taxes was also impacted by  the benefit of our foreign income being taxed at lower rates than the U.S. statutory rate, as well as the benefit of research and development tax credits.

[0001633978-18-000108:notes:279]
The components of our net deferred taxes consisted of the following (in millions):

[0001633978-18-000108:notes:280]
|  | Years Ended |
|  | June 30, 2018 |  | July 1, 2017 |
| Gross deferred tax assets: |  |  |  |
| Intangibles | $ | 123.3 |  |  | $ | 217.4 |  |
| Tax credit carryforwards | 47.1 |  |  | 34.9 |  |
| Net operating loss carryforwards | 7.1 |  |  | 11.5 |  |
| Inventories | 12.4 |  |  | 11.7 |  |
| Accruals and reserves | 7.2 |  |  | 19.7 |  |
| Fixed assets | 10.1 |  |  | 11.4 |  |
| Capital loss carryforwards | 12.3 |  |  | 12.4 |  |
| Unclaimed research and experimental development expenditure | 25.6 |  |  | 23.0 |  |
| Other | 0.5 |  |  | 0.4 |  |
| Stock-based compensation | 3.5 |  |  | 3.1 |  |
| Gross deferred tax assets | 249.1 |  |  | 345.5 |  |
| Valuation allowance | (99.4 | ) |  | (296.4 | ) |
| Deferred tax assets | 149.7 |  |  | 49.1 |  |
| Gross deferred tax liabilities: |  |  |  |
| Intangible amortization | (0.8 | ) |  | (1.1 | ) |
| Convertible notes | (23.6 | ) |  | (44.4 | ) |
| Deferred tax liabilities | (24.4 | ) |  | (45.5 | ) |
| Total net deferred tax assets | $ | 125.3 |  |  | $ | 3.6 |  |

[0001633978-18-000108:notes:281]
As a result of certain realization requirements of ASC 718, the table of deferred tax assets and liabilities for fiscal 2017 does not include certain deferred tax assets that arose directly from (or the use of which was postponed by) tax deductions related to equity compensation that are greater than the compensation recognized for financial reporting. As a result of adopting ASU 2016-09 in fiscal 2018, $2.6 million of excess tax benefits that were not previously recognized because the related tax deduction had not reduced current taxes payable were recorded to retained earnings as of the beginning of fiscal 2018.

[0001633978-18-000108:notes:282]
We assess our ability to realize the deferred tax assets on a quarterly basis and establish a valuation allowance if the deferred tax assets are not more-likely-than-not to be realized. We weigh all available positive and negative evidence, including our earnings history and results of recent operations, reversals of deferred tax liabilities, projected future taxable income, and tax planning strategies.

[0001633978-18-000108:notes:283]
As of each reporting date, we consider new evidence, both positive and negative, that could affect our view of the future realization of deferred tax assets. During fiscal 2018, we determined that there is sufficient positive evidence to conclude that it is more-likely-than-not that the U.S. federal and certain states deferred tax assets are realizable. We, therefore, released the valuation allowance against our U.S. federal and certain states resulting in an income tax benefit of $207.2 million. The valuation allowance against our deferred tax assets decreased by $25.0 million in fiscal 2017 primarily due to the amortization of intangible assets, utilization of tax attributes, and the tax effects of the 2024 Notes.

[0001633978-18-000108:notes:284]
Due to the weight of negative evidence, we continue to maintain a full valuation allowance on our California and partial valuation allowance on our Canadian deferred tax assets.   In the event the Company determines that it will be able to realize all or part of the California or Canada deferred tax assets in the future, the valuation allowance will be reversed in the period in which the Company makes such determination. The release of a valuation allowance against deferred tax assets may cause greater volatility in the effective tax rate in the periods in which it is reversed. Based on the information currently available, we do not believe that a significant portion of our valuation allowance for California and Canada will be released in the next 12 months.  Such a release would result in the recognition of certain deferred tax assets and a decrease in the income tax expense for the period in which the release is recorded.

[0001633978-18-000108:notes:285]
As a result of certain capital funding, capital investments and hiring requirements, income from operations in Thailand was exempt from income tax in fiscal 2018.  Because the Thailand subsidiary incurred losses, the tax holiday had the effect of increasing the overall foreign taxes by $2.1 million for fiscal 2018. The loss of tax benefit due to the tax holiday on net income per share (diluted) was $0.03 for fiscal 2018.

[0001633978-18-000108:notes:286]
As of June 30, 2018, the Company had federal and foreign net operating loss carryforwards of $5.5 million and $24.3 million, respectively.  These carryforwards will begin to expire in the fiscal years ending 2022 and 2025, respectively. The federal net operating loss carryforwards are subject to Internal Revenue Code Section 382 which imposes limitations on annual utilization after a change of ownership.

[0001633978-18-000108:notes:287]
Additionally, the Company has federal, state, and foreign research and other tax credit carryforwards of $8.7 million, $17.7 million, and $45.4 million, respectively. The federal credits will begin to expire in the fiscal year ending 2037 and California credits can be carried forward indefinitely. The foreign tax credits will begin to expire in the fiscal year ending 2020.

[0001633978-18-000108:notes:288]
We expect the Tax Act to generally provide greater flexibility for us to access and utilize our cash, cash equivalent and marketable securities balances held by certain of our foreign subsidiaries as of January 1, 2018, as well as for prospective assets generated by these foreign subsidiaries’ future earnings and profits due to the creation of a quasi-territorial tax system that 1) generally allows companies to repatriate certain foreign source earnings without incurring additional U.S. income tax for such earnings generated after December 31, 2017 and 2) generally requires companies to pay a one-time transition tax on certain foreign subsidiary earnings generated prior to December 31, 2017 that, in substantial part, were previously tax deferred. In light of these changes, we intend to repatriate the earnings of our subsidiaries in the Cayman Islands and Hong Kong.  As to all other foreign subsidiaries, we intend to reinvest these earnings indefinitely outside of the U.S. As a result, U.S. income and foreign withholding taxes associated with the repatriation of $11.4 million of undistributed earnings of foreign subsidiaries, other than the Cayman Islands and Hong Kong subsidiaries, have not been provided for. We estimate that an additional $0.9 million of foreign withholding taxes would have to be provided if these earnings were repatriated back to the U.S.

[0001633978-18-000108:notes:289]
The aggregate changes in the balance of our unrecognized tax benefits between July 2, 2016 and June 30, 2018 is as follows (in millions):

[0001633978-18-000108:notes:290]
| Balance at July 2, 2016 | $ | 2.2 |  |
| Additions based on the tax positions related to the prior year | 1.6 |  |
| Additions based on tax positions related to current year | 9.5 |  |
| Balance at July 1, 2017 | $ | 13.3 |  |
| Additions based on the tax positions related to the prior year | 1.2 |  |
| Additions based on tax positions related to current year | 11.3 |  |
| Balance at June 30, 2018 | $ | 25.8 |  |

[0001633978-18-000108:notes:291]
Included in the balance of unrecognized tax benefits as of June 30, 2018 is $5.2 million of tax benefits that, if recognized, would result in tax benefit.

[0001633978-18-000108:notes:292]
Our policy is to recognize accrued interest and penalties related to unrecognized tax benefits within the income tax provision. The amount of interest and penalties accrued as of June 30, 2018 and July 1, 2017 were $0.9 million and $0.9 million, respectively.  During fiscal 2018, accrued interest and penalties increased by an immaterial amount.

[0001633978-18-000108:notes:293]
We file income tax returns in the US federal jurisdiction as well as many US states and foreign jurisdictions. The major tax jurisdictions where we file tax returns are the U.S. federal government, the state of California, Thailand and Canada. The U.S. federal corporation income tax returns beginning with fiscal 2015 tax year remain subject to examination by the Internal Revenue Service, or IRS. The California corporation income tax returns beginning with the fiscal year 2016 will remain subject to examination by the California Franchise Tax Board. The Canada corporation income tax returns beginning with the 2011 year remain subject to examination by the Canadian tax authorities. Fiscal years outside the normal statute of limitation remain open to audit by tax authorities due to tax attributes generated in those early years which have been carried forward and may be audited in subsequent years when utilized.

[0001633978-18-000108:notes:294]
We are subject to the continuous examination of income tax returns by various foreign tax authorities. The timing of resolutions and closures of tax audits is highly unpredictable. Given the uncertainty, it is reasonably possible that certain tax audits may be concluded within the next 12 months that could materially impact the balance of our gross unrecognized tax benefits. An estimate of the range of increase or decrease that could occur in the next twelve months cannot be made. However, the estimated impact to tax expense and net income from the resolution and closure of tax exams is not expected to be significant within the next 12 months.

[0001633978-18-000108:notes:295]
On July 24, 2018, the Ninth Circuit Court of Appeals (the “Court”) issued an opinion in Altera Corp. v. Commissioner requiring related parties in an intercompany cost sharing arrangement to share expenses related to share-based compensation. This opinion reversed the prior decision of the United States Tax Court. On August 7, 2018, the Court withdrew the opinion issued on July 24, 2018 to allow time for a reconstituted panel of judges to confer. We will continue to monitor the case.


## us-gaap:InvestmentPolicyTextBlock

[0001633978-18-000108:notes:296]
We use the specific-identification method to determine any realized gains or losses from the sale of our short-term investments classified as available-for-sale.


## us-gaap:MinorityInterestDisclosureTextBlock

[0001633978-18-000108:notes:297]
Note 10. Non-Controlling Interest Redeemable Convertible Preferred Stock

[0001633978-18-000108:notes:298]
On July 31, 2015, our wholly-owned subsidiary, Lumentum Inc., issued 40,000 shares of its Series A Preferred Stock to Viavi. Pursuant to a securities purchase agreement between the Company, Viavi and Amada, 35,805 shares of Series A Preferred Stock were sold by Viavi to Amada in August 2015. The remaining 4,195 shares of the Series A Preferred Stock were canceled. The Series A Preferred Stock is referred to as our Non-Controlling Interest Redeemable Convertible Preferred Stock within these consolidated financial statements.

[0001633978-18-000108:notes:299]
The Series A Preferred Stock is redeemable at the option of Amada after five years and classified as non-controlling interest redeemable convertible preferred stock in our consolidated balance sheet. The Series A Preferred Stock is measured at its redemption value. We recognized a $9.7 million increase in the value of the Series A Preferred Stock during the fiscal year ended July 2, 2016 to accrete to the redemption value of $35.8 million with a reduction to additional paid-in capital. The Series A Preferred Stock value of $35.8 million as of June 30, 2018 has not changed from prior year.

[0001633978-18-000108:notes:300]
The Series A Preferred Stock conversion feature is bifurcated from the Series A Preferred Stock and accounted for separately as a derivative liability.  The derivative liability is measured at fair value each reporting period with the change in fair value recorded in the consolidated statements of operations. Refer to “Note 12. Derivative Liability”.

[0001633978-18-000108:notes:301]
The following paragraphs describe the terms and conditions of the Series A Preferred Stock:

[0001633978-18-000108:notes:302]
Conversion

[0001633978-18-000108:notes:303]
The Series A Preferred Stock is convertible, at the option of the holder, into shares of our common stock commencing on the second anniversary of the closing of the securities purchase in August 2017 (absent a change of control of us or similar event) using a conversion price of $24.63, which is equal to 125% of the volume weighted average price per share of our common stock in the five “regular-way” trading days following the Separation.

[0001633978-18-000108:notes:304]
Liquidation

[0001633978-18-000108:notes:305]
Upon any liquidation, dissolution, or winding up of our business, whether voluntary or involuntary, holders of Series A Preferred Stock will be entitled to receive, in preference to holders of common stock or any other class or series of our outstanding capital stock ranking in any such event junior to the Series A Preferred Stock, an amount per share equal to the greater of (i) the Issuance Value of $1,000 per share for Series A Preferred Stock plus all accrued and unpaid dividends thereon (whether or not authorized or declared) through the date of payment and (ii) the amount as would have been payable had all Series A Preferred Stock been converted into common stock immediately prior to such liquidation event.

[0001633978-18-000108:notes:306]
If upon occurrence of any such event, our assets legally available for distribution are insufficient to permit payment of the aforementioned preferential amounts, then all of our assets legally available for distribution will be distributed ratably to the holders of the Series A Preferred Stock and to the holders of any other class or series of our capital stock ranking on parity with the Series A Preferred Stock.

[0001633978-18-000108:notes:307]
Voting Rights

[0001633978-18-000108:notes:308]
The shares of Series A Preferred Stock have no voting rights except as follows:

[0001633978-18-000108:notes:309]
| • | Authorize, approve, or make any change to the powers, preferences, privileges or rights of the Series A Preferred Stock; |

[0001633978-18-000108:notes:310]
| • | Authorize or issue any additional shares of Series A Preferred Stock or reduce the number of shares of Series A Preferred Stock; or |

[0001633978-18-000108:notes:311]
| • | Create, or hold capital stock in, any subsidiary that is not wholly-owned by the Company. |

[0001633978-18-000108:notes:312]
Dividends

[0001633978-18-000108:notes:313]
Holders of Series A Preferred Stock, in preference to holders of common stock or any other class or series of our outstanding capital stock ranking in any such event junior to the Series A Preferred Stock, are entitled to receive, when and as declared by the board of directors, quarterly cumulative cash dividends at the annual rate of 2.5% of the Issuance Value per share on each outstanding share of Series A Preferred Stock. The accrued dividends are payable on March 31, June 30, September 30 and December 31 of each year commencing on September 30, 2015.

[0001633978-18-000108:notes:314]
The accrued dividends as of June 30, 2018 and July 1, 2017 is $0.4 million and $0.2 million, respectively. During each of the years ended June 30, 2018 and July 1, 2017, we paid $0.7 million and $0.9 million, respectively, in dividends to the holders of Series A Preferred Stock.

[0001633978-18-000108:notes:315]
Redemption

[0001633978-18-000108:notes:316]
Optional redemption by the Company

[0001633978-18-000108:notes:317]
On or after the third anniversary in August 2018, we will have the option upon providing notice of not less than 30 calendar days to redeem for cash all (but not less than all) of the shares of Series A Preferred Stock at a redemption price equal to the Issuance Value plus the accrued and unpaid dividends on each share and any past due dividends, whether or not authorized or declared.

[0001633978-18-000108:notes:318]
Optional redemption by holders

[0001633978-18-000108:notes:319]
Commencing on the fifth anniversary of the Issuance Date of the Series A Preferred Stock upon providing notice of not less than 30 calendar days, each holder of Series A Preferred Stock may cause the Company to redeem for cash any number of shares of Series A Preferred Stock on any date at a redemption price for share redeemed equal to the Issuance Value plus the accrued and unpaid dividends on each share and any past due dividends, whether or not authorized or declared.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001633978-18-000108:notes:320]
Accounting Pronouncements Recently Adopted

[0001633978-18-000108:notes:321]
Effective July 2, 2017, we adopted Accounting Standards Update (“ASU”) 2016-09, Stock Compensation ASU 718 - Improvements to Employee Share-Based Payment Accounting. As a result of the adoption, in the first quarter of fiscal year 2018, we recorded on a modified retrospective basis a $2.6 million cumulative-effect adjustment to retained earnings for the recognition of excess tax benefits generated by the settlement of share-based awards in prior periods. We elected to account for forfeitures of equity awards when they occur. The change was applied on a modified retrospective basis with a cumulative-effect adjustment of approximately $0.2 million to retained earnings in the fiscal first quarter of 2018.

[0001633978-18-000108:notes:322]
All excess tax benefits and deficiencies are recognized in the income tax provision in the consolidated statements of operations prospectively, rather than in additional paid-in-capital in the consolidated balance sheets. In addition, the standard eliminates the requirement to defer recognition of excess tax benefits until they are realized through a reduction to income taxes payable. We present excess tax benefits as an operating activity in the consolidated statements of cash flows on a prospective basis.

[0001633978-18-000108:notes:323]
Accounting Pronouncements Not Yet Effective

[0001633978-18-000108:notes:324]
In January 2017, the Financial Accounting Standards Board (“FASB”) issued ASU 2017-01, Business Combinations (Topic 805), which clarifies the definition of a business. For accounting and financial reporting purposes, businesses are generally comprised of three elements; inputs, processes, and outputs. Integrated sets of assets and activities capable of providing these three elements may not always be considered a business, and the lack of one of the three elements does not always disqualify the set from being a business. The issuance of ASU 2017-01 provides a clarifying screen to determine when a set of assets and activities is not a business. Primarily, the screen requires that when substantially all of the fair value of the gross assets acquired is concentrated in a single identifiable asset or group of similar identifiable assets, the set is not a business. The amendments contained in ASU 2017-01 are effective for annual periods beginning after December 15, 2017, including interim periods within those periods. The accounting standard update will be effective for us beginning in the first quarter of fiscal 2019 and should be applied prospectively. The implementation of ASU 2017-01 will not have a material impact on our consolidated financial statements.

[0001633978-18-000108:notes:325]
In January 2017, FASB issued ASU 2017-04, Intangibles - Goodwill and Other (Topic 350): Simplifying the Accounting for Goodwill Impairment. ASU 2017-04 removes the requirement to perform a hypothetical purchase price allocation to measure goodwill impairment. A goodwill impairment charge will be the amount by which a reporting unit's carrying value exceeds its fair value, not to exceed the carrying amount of goodwill. The amendments contained in ASU 2017-04 are effective for interim and annual periods beginning after December 15, 2019, with early adoption permitted, which should be applied prospectively. We plan to adopt the accounting standard update in our first quarter of fiscal 2020. We do not believe the implementation of ASU 2017-04 will have a material impact on our consolidated financial statements.

[0001633978-18-000108:notes:326]
In October 2016, FASB issued ASU 2016-16, Accounting for Income Taxes: Intra-Entity Asset Transfers of Assets other than Inventory. The new guidance removes the prohibition in ASC 740 against the immediate recognition of the current and deferred income tax effects of intra-entity transfers of assets other than inventory. The new guidance will be effective for us in our first quarter of fiscal 2019. We do not believe that the adoption of ASU 2016-16 will have a material impact on our financial statements.

[0001633978-18-000108:notes:327]
In August 2016, FASB issued ASU 2016-15, Statement of Cash Flows (Topic 230): Classification of Certain Cash Receipts and Cash Payments, which clarifies how companies present and classify certain cash receipts and cash payments in the statement of cash flows. The amendments contained in ASU 2016-15 are effective for interim and annual periods beginning after December 15, 2017. The accounting standard update will be effective for us in the first quarter of fiscal 2019 and will be applied prospectively. If we elect to settle the principal amounts of our 2024 Notes (refer to “Note 11. Convertible Senior Notes”) in cash, the payment will be bifurcated between (i) cash outflows for operating activities of $137.6 million for the portion related to accreted interest attributable to debt discount, and (ii) financing activities for the remainder of $312.4 million.

[0001633978-18-000108:notes:328]
In February 2016, FASB issued ASU 2016-02, Leases. The new guidance generally requires an entity to recognize on its balance sheet operating and financing lease liabilities and corresponding right-of-use assets. The new guidance contained in ASU 2016-02 is effective for annual periods beginning after December 15, 2018, including interim periods within those periods, with early adoption permitted. The standard is effective for us in our first quarter of fiscal 2020 where we will be required to recognize and measure leases existing at, or entered into after, the beginning of the earliest comparative period presented using a modified retrospective approach, with an option to elect certain practical expedients. Based on our current lease portfolio, we estimate the value of leased assets and liabilities that may be recognized will be material. We are continuing to evaluate the impact of ASU 2016-02 which is subject to change.

[0001633978-18-000108:notes:329]
In May 2014, FASB issued ASU 2014-09, Revenue from Contracts with Customers (“ASU 2014-09”), which outlines a single, comprehensive model for entities to use in accounting for revenue arising from contracts with customers. The core principle of ASU 2014-09 is to recognize revenue when promised goods or services are transferred to customers in an amount that reflects the consideration that is expected to be received for those goods or services. ASU 2014-09 defines a five-step process to achieve this core principle and, accordingly, we expect more judgment and estimates may be required within the revenue recognition process than is required under the previous revenue recognition standard, including identifying performance obligations in the contract, estimating the amount of variable consideration to include in the transaction price and allocating the transaction price to each separate performance obligation. ASU 2014-09 is effective for us beginning on July 1, 2018. ASU 2014-09 permits two methods of adoption: retrospectively to each prior reporting period presented (the full retrospective method), or retrospectively with the cumulative effect of initially applying the guidance recognized at the date of initial application (the modified retrospective method). We elected to adopt ASU 2014-09 using the modified retrospective method and will apply the standard to contracts that are not completed as of July 1, 2018.

[0001633978-18-000108:notes:330]
We have completed our analysis of open revenue contracts as of July 1, 2018. Based on our assessment, the impact on revenue in our consolidated financial statements or disclosures is not material because under ASU 2014-09 we continue to recognize most revenue at the point-in-time when control transfers.

[0001633978-18-000108:notes:331]
In the preparation for the adoption of ASU 2014-09, we have implemented internal controls to enable the preparation of financial information and related disclosures in accordance with this standard.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001633978-18-000108:notes:332]
Note 17. Employee Benefit Plans

[0001633978-18-000108:notes:333]
Employee Retirement Plans

[0001633978-18-000108:notes:334]
In the United States, the Company sponsors the Lumentum 401(k) Retirement Plan (the “401(k) Plan”), a defined contribution plan under ERISA, which provides retirement benefits for its eligible employees through tax deferred salary deductions. The 401(k) Plan allows employees to contribute up to 50% of their annual compensation, with contributions limited to $18,500 in calendar year 2018 as set by the Internal Revenue Service.

[0001633978-18-000108:notes:335]
In Canada, the Company sponsors the Group Registered Retirement Savings (the “RRSP”) and Deferred Profit Sharing Plan (the “DPSP”), a defined contribution plan which provides retirement benefits for its eligible employees through tax deferred salary deductions.  The plan allows employees to contribute up to 5% of their eligible earnings in a pay period, with contributions limited to in calendar year 2018 up to $19,953 (1) for the RRSP and $10,079 (2) for the DPSP, per Canada Revenue Agency. The RRSP contributions in excess of 5% of earnings are not subject to an employer’s contributions.

[0001633978-18-000108:notes:336]
The Company also makes a matching contribution equal to 100% of employees’ before-tax contributions up to 3% of their compensation and 50% of employees’ before-tax contributions to the next 2% of their compensation.  The Company match is contributed on a per-pay-period basis and is based on employees’ before-tax contributions and compensation each pay period for both the United Stated and Canada retirement plans.

[0001633978-18-000108:notes:337]
Employees are eligible for match contributions after completing 180 days of service.  All matching contributions are made in cash and vest immediately under both retirement plans. In fiscal 2018 and 2017, we made matching contributions to the 401(k) Plan in the amount of $3.4 million and $4.0 million, respectively. In fiscal 2018 and 2017, we made matching contributions in the amount of $1.3 million and $0.7 million under our Canada retirement plan.

[0001633978-18-000108:notes:338]
(1) CA$26,230 converted to U.S. dollars using the applicable exchange rate on June 30, 2018 (i.e., $0.7713), the last business day of fiscal 2018.

[0001633978-18-000108:notes:339]
(2) CA$13,250 converted to U.S. dollars using the applicable exchange rate on June 30, 2018 (i.e., $0.7713), the last business day of fiscal 2018.

[0001633978-18-000108:notes:340]
Employee Defined Benefit Plans

[0001633978-18-000108:notes:341]
During the third quarter of fiscal 2014, we assumed a defined benefit plan in connection with the acquisition of Time-Bandwidth. Prior to the third quarter of fiscal 2014, we did not have any significant defined benefit plans. This plan, which covers certain Swiss employees, is open to new participants and additional service costs are being accrued. Benefits are generally based upon age and compensation. As of June 30, 2018, the plan was partially funded. Our policy for partially funded plans is to make contributions equal to or greater than the requirements prescribed by law or regulation. Future estimated benefit payments are summarized below. No other required contributions to this defined benefit plan are expected in fiscal 2018, but we can, at our discretion, make contributions to the plan.

[0001633978-18-000108:notes:342]
We account for our obligations under this pension plan in accordance with the authoritative guidance which requires us to record our obligation to the participants, as well as the corresponding net periodic cost. We determine our obligation to the participants and our net periodic cost principally using actuarial valuations provided by third-party actuaries. The net obligation of $3.5 million as of June 30, 2018 is recorded in our consolidated balance sheets as non-current liabilities and is reflective of the total PBO less the fair value of plan assets.

[0001633978-18-000108:notes:343]
Assumptions

[0001633978-18-000108:notes:344]
Underlying both the calculation of the PBO and net periodic cost are actuarial valuations. These valuations use participant-specific information such as salary, age and assumptions about interest rates, compensation increases and other factors. At a minimum, we evaluate these assumptions annually and make changes as necessary.

[0001633978-18-000108:notes:345]
The discount rate reflects the estimated rate at which the pension benefits could be effectively settled. In developing the discount rate, we consider the yield available on an appropriate AA corporate bond index, adjusted to reflect the term of the plan’s liabilities.

[0001633978-18-000108:notes:346]
The expected return on assets was estimated by using the weighted average of the real expected long-term return (net of inflation) on the relevant classes of assets based on the target asset mix and adding the chosen inflation assumption.

[0001633978-18-000108:notes:347]
The following table summarizes the assumptions used to determine net periodic cost and benefit obligation for the pension plan:

[0001633978-18-000108:notes:348]
|  | Pension Benefit Plans |
|  | 2018 |  | 2017 |
| Assumptions used to determine net periodic cost: |  |  |  |
| Discount rate | 0.7 | % |  | 0.2 | % |
| Expected long-term return on plan assets | 2.8 | % |  | 3.2 | % |
| Rate of pension increase | 2.3 | % |  | 2.3 | % |
| Assumptions used to determine benefit obligation at end of year: |  |  |  |
| Discount rate | 1.0 | % |  | 0.7 | % |
| Rate of pension increase | 2.3 | % |  | 2.3 | % |

[0001633978-18-000108:notes:349]
Fair Value Measurement of Plan Assets

[0001633978-18-000108:notes:350]
The following table sets forth the plan’s assets at fair value and the percentage of assets allocations as of June 30, 2018 (in millions, except percentage data).

[0001633978-18-000108:notes:351]
|  |  |  |  |  |  | Fair value measurement as of June 30, 2018 |
|  | Target Allocation | Total |  | Percentage of Plan Asset |  | Quoted Prices in Active Markets for Identical Assets |  | Significant Other Observable Inputs (Level 2) |
| Assets: |  |  |  |  |  |  |  |  |  |
| Global equity | 28 | % |  | $ | 2.4 |  |  | 28 | % |  | $ | — |  |  | $ | 2.4 |  |
| Fixed income | 30 | % |  | 2.8 |  |  | 33 | % |  | — |  |  | 2.8 |  |
| Alternative investment | 18 | % |  | 1.5 |  |  | 17 | % |  | — |  |  | 1.5 |  |
| Cash | 1 | % |  | 0.2 |  |  | 1 | % |  | 0.2 |  |  | — |  |
| Other | 23 | % |  | 1.7 |  |  | 21 | % |  | — |  |  | 1.7 |  |
| Total Assets |  |  | $ | 8.6 |  |  | 100 | % |  | $ | 0.2 |  |  | $ | 8.4 |  |

[0001633978-18-000108:notes:352]
The following table sets forth the plan’s assets at fair value and the percentage of assets allocations as of July 1, 2017 (in millions, except percentage data).

[0001633978-18-000108:notes:353]
|  |  |  |  |  |  | Fair value measurement as of July 1, 2017 |
|  | Target Allocation | Total |  | Percentage of Plan Asset |  | Quoted Prices in Active Markets for Identical Assets |  | Significant Other Observable Inputs (Level 2) |
| Assets: |  |  |  |  |  |  |  |  |  |
| Global equity | 24 | % |  | $ | 1.7 |  |  | 24 | % |  | $ | — |  |  | $ | 1.7 |  |
| Fixed income | 35 | % |  | 2.5 |  |  | 35 | % |  | — |  |  | 2.5 |  |
| Alternative investment | 15 | % |  | 1.6 |  |  | 23 | % |  | — |  |  | 1.6 |  |
| Cash | 1 | % |  | 0.1 |  |  | 1 | % |  | 0.1 |  |  | — |  |
| Other | 25 | % |  | 1.2 |  |  | 17 | % |  | — |  |  | 1.2 |  |
| Total Assets |  |  | $ | 7.1 |  |  | 100 | % |  | $ | 0.1 |  |  | $ | 7.0 |  |

[0001633978-18-000108:notes:354]
Our pension assets consist of multiple institutional funds (“pension funds”) of which the fair values are based on the quoted prices of the underlying funds. Pension funds are classified as Level 2 assets since such funds are not directly traded in active markets. Global equity consists of several funds that invest primarily in Swiss and foreign equities; fixed income consists of several funds that invest primarily in investment grade domestic and overseas bonds; Other consists of several funds that primarily invest in hedge fund, private equity, global real estate and infrastructure funds.

[0001633978-18-000108:notes:355]
Future Benefit Payments

[0001633978-18-000108:notes:356]
We estimate our expected benefit payments to defined benefit pension plan participants based on the same assumptions used to measure our PBO at year end which includes benefits attributable to estimated future compensation increases. Based on this approach, we expect future benefit payments to be $1.1 million during the 10 year period between fiscal 2019 and fiscal 2028 and the remaining $2.4 million of payments in fiscal years subsequent to fiscal 2028.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001633978-18-000108:notes:357]
Note 20. Quarterly Financial Information (unaudited)

[0001633978-18-000108:notes:358]
The following table presents our quarterly consolidated statements of operations for fiscal 2018 and 2017 (in millions, except per share data):

[0001633978-18-000108:notes:359]
|  | June 30, 2018 |  | March 31, 2018 |  | December 30, 2017 |  | September 30, 2017 |  | July 1, 2017 |  | April 1, 2017 |  | December 31, 2016 |  | October 1, 2016 |
| Net revenue | $ | 301.1 |  |  | $ | 298.8 |  |  | $ | 404.6 |  |  | $ | 243.2 |  |  | $ | 222.7 |  |  | $ | 255.8 |  |  | $ | 265.0 |  |  | $ | 258.1 |  |
| Cost of sales | 204.8 |  |  | 201.0 |  |  | 232.7 |  |  | 173.9 |  |  | 154.0 |  |  | 172.0 |  |  | 176.3 |  |  | 174.7 |  |
| Amortization of acquired developed technologies | 0.8 |  |  | 0.8 |  |  | 0.8 |  |  | 0.8 |  |  | 1.4 |  |  | 1.7 |  |  | 1.7 |  |  | 1.7 |  |
| Gross profit | 95.5 |  |  | 97.0 |  |  | 171.1 |  |  | 68.5 |  |  | 67.3 |  |  | 82.1 |  |  | 87.0 |  |  | 81.7 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 38.5 |  |  | 38.2 |  |  | 43.8 |  |  | 36.3 |  |  | 35.4 |  |  | 37.3 |  |  | 38.7 |  |  | 36.9 |  |
| Selling, general and administrative | 32.7 |  |  | 33.2 |  |  | 35.7 |  |  | 26.6 |  |  | 26.0 |  |  | 28.1 |  |  | 31.0 |  |  | 25.1 |  |
| Restructuring and related charges | 3.4 |  |  | 0.1 |  |  | 0.8 |  |  | 2.9 |  |  | 2.0 |  |  | 3.1 |  |  | 4.0 |  |  | 2.9 |  |
| Total operating expenses | 74.6 |  |  | 71.5 |  |  | 80.3 |  |  | 65.8 |  |  | 63.4 |  |  | 68.5 |  |  | 73.7 |  |  | 64.9 |  |
| Income from operations | 20.9 |  |  | 25.5 |  |  | 90.8 |  |  | 2.7 |  |  | 3.9 |  |  | 13.6 |  |  | 13.3 |  |  | 16.8 |  |
| Unrealized gain (loss) on derivative liabilities | 7.8 |  |  | (20.7 | ) |  | 7.9 |  |  | 4.2 |  |  | (29.7 | ) |  | (56.6 | ) |  | 4.8 |  |  | (22.7 | ) |
| Interest and other income (expense), net | (1.0 | ) |  | (2.1 | ) |  | (3.2 | ) |  | (3.4 | ) |  | (1.8 | ) |  | (1.4 | ) |  | (0.2 | ) |  | 0.2 |  |
| Income (loss) before income taxes | 27.7 |  |  | 2.7 |  |  | 95.5 |  |  | 3.5 |  |  | (27.6 | ) |  | (44.4 | ) |  | 17.9 |  |  | (5.7 | ) |
| Provision for (benefit from) income taxes | (5.8 | ) |  | — |  |  | (109.3 | ) |  | (3.6 | ) |  | 27.3 |  |  | 11.6 |  |  | 6.1 |  |  | (2.3 | ) |
| Net income (loss) | $ | 33.5 |  |  | $ | 2.7 |  |  | $ | 204.8 |  |  | $ | 7.1 |  |  | $ | (54.9 | ) |  | $ | (56.0 | ) |  | $ | 11.8 |  |  | $ | (3.4 | ) |
| Net income (loss) attributable to common stockholders - Basic | 32.5 |  |  | 2.4 |  |  | 199.8 |  |  | 6.7 |  |  | (55.2 | ) |  | (56.2 | ) |  | 11.3 |  |  | (3.6 | ) |
| Net income (loss) attributable to common stockholders - Diluted | 25.7 |  |  | 2.4 |  |  | 196.9 |  |  | 2.9 |  |  | (55.2 | ) |  | (56.2 | ) |  | 7.0 |  |  | (3.6 | ) |
| Net income (loss) per share attributable to common stockholders(1): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic | $ | 0.52 |  |  | $ | 0.04 |  |  | $ | 3.21 |  |  | $ | 0.11 |  |  | $ | (0.90 | ) |  | $ | (0.92 | ) |  | $ | 0.19 |  |  | $ | (0.06 | ) |
| Diluted | $ | 0.40 |  |  | $ | 0.04 |  |  | $ | 3.05 |  |  | $ | 0.04 |  |  | $ | (0.90 | ) |  | $ | (0.92 | ) |  | $ | 0.11 |  |  | $ | (0.06 | ) |
| Shares used to compute net income (loss) per share attributable to common stockholders: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic | 62.7 |  |  | 62.4 |  |  | 62.2 |  |  | 61.7 |  |  | 61.3 |  |  | 61.0 |  |  | 60.3 |  |  | 59.9 |  |
| Diluted | 65.0 |  |  | 63.3 |  |  | 64.6 |  |  | 64.5 |  |  | 61.3 |  |  | 61.0 |  |  | 62.7 |  |  | 59.9 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001633978-18-000108:notes:360]
Note 3. Related Party Transactions

[0001633978-18-000108:notes:361]
Transactions with Viavi

[0001633978-18-000108:notes:362]
Since October 2017, all transactions with Viavi were no longer related party transactions, as Viavi held less than 5% of our total shares outstanding.

[0001633978-18-000108:notes:363]
During the fiscal year ended July 1, 2017, we recognized revenue of $3.6 million from products sold to Viavi. During the fiscal year ended July 1, 2017, we recorded $0.5 million in research and development cost reimbursement and $0.7 million in sublease rental income. As of July 1, 2017, we had $0.1 million in trade accounts receivable due from Viavi and $0.5 million in other receivables from Viavi. As of July 1, 2017, we had $0.2 million in trade payables due to Viavi. During the fiscal year ended July 1, 2017, we recorded $0.6 million in other income, which resulted from a tax indemnification agreement between Lumentum and Viavi.  As a result, we had $0.6 million in other non-current assets due from Viavi as of July 1, 2017.

[0001633978-18-000108:notes:364]
During the fiscal year ended July 2, 2016, we recognized revenue of $3.3 million from products sold to Viavi. During the fiscal year ended July 2, 2016, we recorded $2.3 million in research and development cost reimbursement and $0.7 million in sublease rental income. As of July 2, 2016, we had $1.1 million in accounts receivable due from Viavi.

[0001633978-18-000108:notes:365]
Allocated Costs

[0001633978-18-000108:notes:366]
From June 28, 2015 to August 1, 2015, the Separation date, the consolidated statements of operations included our direct expenses for cost of sales, research and development, sales and marketing, and administration as well as allocations of expenses arising from shared services and infrastructure provided by Viavi to us. These allocated expenses include costs of information technology, human resources, accounting, legal, real estate and facilities, corporate marketing, insurance, treasury and other corporate and infrastructure services. In addition, other costs allocated to us include restructuring and stock-based compensation related to Viavi’s corporate and shared services employees and are included in the table below. These expenses were allocated to us using estimates that we consider to be a reasonable reflection of the utilization of services or benefits received by our business. The allocation methods include revenue, headcount, square footage, actual consumption and usage of services and others.

[0001633978-18-000108:notes:367]
There were no allocations of expenses from Viavi for the fiscal years ended June 30, 2018 or July 1, 2017. During the fiscal year ended July 2, 2016, allocated costs from Viavi included in the accompanying consolidated statements of operations were as follows (in millions):

[0001633978-18-000108:notes:368]
|  | July 2, 2016 |
| Selling, general and administrative | $ | 11.7 |  |
| Interest and other (income) expenses, net | (0.1 | ) |
| Interest expense | 0.1 |  |
| Total allocated costs | $ | 11.7 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001633978-18-000108:notes:369]
Note 14. Restructuring and Related Charges

[0001633978-18-000108:notes:370]
We have initiated various strategic restructuring events primarily intended to reduce costs, consolidate our operations, rationalize the manufacturing of our products and align our business in response to the market conditions. The following table summarizes the activity of restructuring and related charges during fiscal 2018, 2017 and 2016 (in millions):

[0001633978-18-000108:notes:371]
|  | Years Ended |
|  | June 30, 2018 |  | July 1, 2017 |  | July 2, 2016 |
| Balance as of beginning of period | $ | 3.8 |  |  | $ | 5.7 |  |  | $ | 6.0 |  |
| Charges | 7.2 |  |  | 12.0 |  |  | 7.7 |  |
| Payments | (9.1 | ) |  | (13.9 | ) |  | (8.0 | ) |
| Balance as of end of period | $ | 1.9 |  |  | $ | 3.8 |  |  | $ | 5.7 |  |

[0001633978-18-000108:notes:372]
During fiscal 2018, we recorded $7.2 million in restructuring and related charges in the consolidated statements of operations.

[0001633978-18-000108:notes:373]
| • | During the fourth quarter of fiscal 2018, we initiated a new restructuring plan in order to realign the organization and enable further investment in key priority areas. As a result, a restructuring charge of $3.4 million was recorded for severance costs and employee benefits. In total, there were 52 employees in manufacturing, R&D and SG&A functions that were terminated. |

[0001633978-18-000108:notes:374]
| • | We also incurred restructuring and related charges of $3.8 million from restructuring plans approved prior to fiscal 2016 primarily related to manufacturing facility in Bloomfield, Connecticut to transfer certain production processes into existing sites in the United States or to contract manufacturers. |

[0001633978-18-000108:notes:375]
During fiscal 2017 and 2016, we recorded $12.0 million and $7.7 million, respectively, in restructuring and related charges in the consolidated statements of operations. Of the $12.0 million and $7.7 million charge recorded during fiscal 2017 and fiscal 2016, $2.1 million and $2.1 million, respectively, related to severance, retention and employee benefits and there were no costs allocated to us by Viavi. Our restructuring charges include severance and benefit costs to eliminate a specified number of positions, facilities and equipment costs to vacate facilities and consolidate operations, and lease termination costs. The timing of associated cash payments is dependent upon the type of restructuring charge and can extend over multiple periods.


## us-gaap:ScheduleOfEntityWideDisclosureOnGeographicAreasLongLivedAssetsInIndividualForeignCountriesByCountryTextBlock

[0001633978-18-000108:notes:376]
Long-lived assets, namely net property, plant and equipment were identified based on the physical location of the assets in the corresponding geographic areas (in millions):

[0001633978-18-000108:notes:377]
|  | As of |
|  | June 30, 2018 |  | July 1, 2017 |
| Property, Plant and Equipment, net |  |  |  |
| United States | $ | 97.6 |  |  | $ | 88.2 |  |
| China | 70.0 |  |  | 82.5 |  |
| Thailand | 107.4 |  |  | 85.3 |  |
| Other countries | 31.9 |  |  | 17.5 |  |
| Total long-lived assets | $ | 306.9 |  |  | $ | 273.5 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001633978-18-000108:notes:378]
The components of inventories were as follows (in millions):

[0001633978-18-000108:notes:379]
|  | June 30, 2018 |  | July 1, 2017 |
| Finished goods | $ | 98.2 |  |  | $ | 71.7 |  |
| Work in process | 34.5 |  |  | 49.4 |  |
| Raw materials and purchased parts | 20.9 |  |  | 24.1 |  |
| Inventories | $ | 153.6 |  |  | $ | 145.2 |  |


## us-gaap:ScheduleOfOtherCurrentAssetsTableTextBlock

[0001633978-18-000108:notes:380]
The components of prepayments and other current assets were as follows (in millions):

[0001633978-18-000108:notes:381]
|  | June 30, 2018 |  | July 1, 2017 |
| Capitalized manufacturing overhead | $ | 20.5 |  |  | $ | 30.1 |  |
| Prepayments | 19.5 |  |  | 12.3 |  |
| Advances to contract manufacturers | 14.0 |  |  | 10.5 |  |
| Other current assets | 11.0 |  |  | 10.6 |  |
| Prepayments and other current assets | $ | 65.0 |  |  | $ | 63.5 |  |


## us-gaap:ScheduleOfRevenueByMajorCustomersByReportingSegmentsTableTextBlock

[0001633978-18-000108:notes:382]
During fiscal 2018, 2017 and 2016, net revenue generated from a single customer which represented 10% or greater of total net revenue is summarized as follows:

[0001633978-18-000108:notes:383]
|  | Years Ended |
|  | June 30, 2018 |  | July 1, 2017 |  | July 2, 2016 |
| Customer A | 30.0 | % |  | * |  |  | * |  |
| Customer B | 11.0 | % |  | 16.7 | % |  | 17.1 | % |
| Customer C | 11.0 | % |  | 18.5 | % |  | 17.1 | % |
| Customer D | * |  |  | 12.4 | % |  | 13.0 | % |
| *Represents less than 10% of total net revenue |  |  |  |  |  |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001633978-18-000108:notes:384]
The following table presents net revenue by the three geographic regions we operate in and net revenue from countries that represented 10% or more of our total net revenue (in millions, except percentage data):

[0001633978-18-000108:notes:385]
|  | Years Ended |
|  | June 30, 2018 |  | July 1, 2017 |  | July 2, 2016 |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |
| United States | $ | 115.1 |  |  | 9.2 | % |  | $ | 147.9 |  |  | 14.8 | % |  | $ | 162.3 |  |  | 18.0 | % |
| Mexico | 145.8 |  |  | 11.7 |  |  | 185.1 |  |  | 18.5 |  |  | 112.9 |  |  | 12.5 |  |
| Other Americas | 7.0 |  |  | 0.6 |  |  | 9.2 |  |  | 0.9 |  |  | 19.6 |  |  | 2.2 |  |
| Total Americas | $ | 267.9 |  |  | 21.5 | % |  | $ | 342.2 |  |  | 34.2 | % |  | $ | 294.8 |  |  | 32.7 | % |
| Asia-Pacific: |  |  |  |  |  |  |  |  |  |  |  |
| Hong Kong | $ | 183.0 |  |  | 14.7 | % |  | $ | 226.7 |  |  | 22.6 | % |  | $ | 214.0 |  |  | 23.7 | % |
| Japan | 194.7 |  |  | 15.6 |  |  | 99.2 |  |  | 9.9 |  |  | 92.9 |  |  | 10.3 |  |
| South Korea | 146.1 |  |  | 11.7 |  |  | 4.9 |  |  | 0.5 |  |  | 3.8 |  |  | 0.4 |  |
| Other Asia-Pacific | 354.2 |  |  | 28.3 |  |  | 220.5 |  |  | 22.0 |  |  | 174.0 |  |  | 19.2 |  |
| Total Asia-Pacific | $ | 878.0 |  |  | 70.3 | % |  | $ | 551.3 |  |  | 55.0 | % |  | $ | 484.7 |  |  | 53.6 | % |
| EMEA | $ | 101.8 |  |  | 8.2 | % |  | $ | 108.1 |  |  | 10.8 | % |  | $ | 123.5 |  |  | 13.7 | % |
| Total net revenue | $ | 1,247.7 |  |  |  |  | $ | 1,001.6 |  |  |  |  | $ | 903.0 |  |  |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001633978-18-000108:notes:386]
Information on reportable segments utilized by our CODM is as follows (in millions):

[0001633978-18-000108:notes:387]
|  | Years Ended |
|  | June 30, 2018 |  | July 1, 2017 |  | July 2, 2016 |
| Net revenue: |  |  |  |  |  |
| OpComms | $ | 1,059.2 |  |  | $ | 857.8 |  |  | $ | 761.3 |  |
| Lasers | 188.5 |  |  | 143.8 |  |  | 141.7 |  |
| Net revenue | $ | 1,247.7 |  |  | $ | 1,001.6 |  |  | $ | 903.0 |  |
| Gross profit: |  |  |  |  |  |
| OpComms | 402.3 |  |  | 287.3 |  |  | 236.3 |  |
| Lasers | 82.8 |  |  | 59.9 |  |  | 61.4 |  |
| Total segment gross profit | 485.1 |  |  | 347.2 |  |  | 297.7 |  |
| Unallocated corporate items: |  |  |  |  |  |
| Stock-based compensation | (12.6 | ) |  | (7.5 | ) |  | (6.1 | ) |
| Amortization of intangibles | (3.2 | ) |  | (6.5 | ) |  | (6.8 | ) |
| Other charges (1) | (37.2 | ) |  | (15.1 | ) |  | (7.5 | ) |
| Gross profit | $ | 432.1 |  |  | $ | 318.1 |  |  | $ | 277.3 |  |

[0001633978-18-000108:notes:388]
(1) The increase in “Other charges” of unallocated corporate items during fiscal 2018 compared to fiscal 2017, primarily relates to set-up costs of our facility in Thailand, including costs of transferring product lines to Thailand of $27.0 million in our fiscal 2018 compared to $1.8 million in fiscal 2017. The increase in “Other charges” of unallocated corporate items during fiscal 2017 compared to fiscal 2016, primarily relates to inventory write-downs due to canceled programs not allocated to the segments of $7.9 million incurred in fiscal 2017.


## us-gaap:SchedulesOfConcentrationOfRiskByRiskFactorTextBlock

[0001633978-18-000108:notes:389]
For the fiscal years ended 2018 and 2017, net inventory purchased from a single contract manufacturer which represented 10% or greater of total net purchases is summarized as follows:

[0001633978-18-000108:notes:390]
|  | June 30, 2018 |  | July 1, 2017 |
| Vendor A | 44.0 | % |  | 50.0 | % |
| Vendor B | 20.0 | % |  | 27.0 | % |
| Vendor C | 21.0 | % |  | * |  |
| Vendor D | * |  |  | 14.0 | % |
| *Represents less than 10% of total net purchases |  |  |  |

[0001633978-18-000108:notes:391]
The table below discloses the percentage of our total net revenue attributable to each of our two reportable segments. In addition, it discloses the percentage of our total net revenue attributable to our product offerings which serve the Telecom, Datacom, and Consumer and Industrial markets which accounted for 10% or more of our total net revenue during the periods presented:

[0001633978-18-000108:notes:392]
|  | Years Ended |
|  | June 30, 2018 |  | July 1, 2017 |  | July 2, 2016 |
| OpComms: |  | 84.9 | % |  |  | 85.6 | % |  |  | 84.3 | % |
| Telecom |  | 38.1 | % |  |  | 61.0 | % |  |  | 61.5 | % |
| Datacom |  | 12.1 | % |  |  | 20.1 | % |  |  | 18.1 | % |
| Consumer and Industrial |  | 34.7 | % |  |  | 4.5 | % |  |  | 4.7 | % |
| Lasers |  | 15.1 | % |  |  | 14.4 | % |  |  | 15.7 | % |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001633978-18-000108:notes:393]
Note 19. Operating Segments and Geographic Information

[0001633978-18-000108:notes:394]
Our chief executive officer is our Chief Operating Decision Maker (“CODM”). The CODM allocates resources to the segments based on their business prospects, competitive factors, net revenue and gross margin. We do not track all of our property, plant and equipment by operating segments. The geographic identification of these assets is set forth below.

[0001633978-18-000108:notes:395]
We are an industry leading provider of optical and photonic products defined by revenue and market share addressing a range of end-market applications including optical communications and commercial lasers. We have two operating segments, Optical Communications, which we refer to as OpComms, and Commercial Lasers, which we refer to as Lasers. Our OpComms products address the following markets: telecommunications (“Telecom”), data communications (“Datacom”), and consumer and industrial(“Consumer and Industrial”). The two operating segments were primarily determined based on how the CODM views and evaluates our operations. Operating results are regularly reviewed by the CODM to make decisions about resources to be allocated to the segments and to assess their performance. Other factors, including market separation and customer specific applications, go-to-market channels, products and manufacturing, are considered in determining the formation of these operating segments.

[0001633978-18-000108:notes:396]
OpComms

[0001633978-18-000108:notes:397]
Our OpComms products address the following markets: Telecom, Datacom and Consumer and Industrial.

[0001633978-18-000108:notes:398]
Our OpComms products include a wide range of components, modules and subsystems to support and maintain customers including carrier networks for access (local), metro (intracity), long-haul (city-to-city and worldwide) and, submarine (undersea). Additionally, our products address enterprise, cloud, and data center applications, including SANs, LANs, and WANs. These products enable the transmission and transport of video, audio and text data over high-capacity fiber-optic cables. We maintain leading positions in these fast growing OpComms markets through our extensive product portfolio, including ROADMs, tunable 10-gigabit small form-factor pluggable transceivers and tunable small form-factor pluggable transceivers. Our 10G, 40G legacy transceivers and a growing portfolio of 100G pluggable transceivers support LAN/SAN/WAN needs and the cloud for customers building enterprise and hyperscale data center networks. Additionally, we are engaging customers in the sale of laser chips for use in the manufacture of high-speed transceivers.

[0001633978-18-000108:notes:399]
In the Consumer and Industrial market, our OpComms products include laser light sources, which are integrated into 3D sensing platforms being used in applications for mobile devices, gaming, computers, and other consumer electronics devices. New emerging applications include virtual and augmented reality, as well as automotive and industrial segments. Our products include VCSELs and edge emitting lasers which are used in 3D sensing depth imaging systems. These systems simplify the way people interact with technology by enabling the use of natural user interfaces. Systems are used for biometric identification, surveillance, and process efficiency, among numerous other application spaces. Emerging applications for this technology include various mobile device applications, autonomous vehicles, self-navigating robotics and drones in industrial applications and 3D capture of objects coupled with 3D printing. In addition, our industrial diode lasers are used primarily as pump sources for pulsed and CW Fiber Lasers.

[0001633978-18-000108:notes:400]
Lasers

[0001633978-18-000108:notes:401]
Our Lasers products serve our customers in markets and applications such as sheet metal processing, general manufacturing, biotechnology, graphics and imaging, remote sensing, and precision machining such as drilling in printed circuit boards, wafer singulation, glass cutting and solar cell scribing.

[0001633978-18-000108:notes:402]
Our Lasers products are used in a variety of OEM applications including diode-pumped solid-state, fiber, diode, direct-diode and gas lasers such as argon-ion and helium-neon lasers. Fiber lasers provide kW-class output powers combined with excellent beam quality and are used in sheet metal processing and metal welding applications. Diode-pumped solid-state lasers provide excellent beam quality, low noise and exceptional reliability and are used in biotechnology, graphics and imaging, remote sensing, materials processing and precision machining applications. Diode and direct-diode lasers address a wide variety of applications, including laser pumping, thermal exposure, illumination, ophthalmology, image recording, printing, plastic welding and selective soldering. Gas lasers such as argon-ion and helium-neon lasers provide a stable, low-cost and reliable solution over a wide range of operating conditions, making them well suited for complex, high-resolution OEM applications such as flow cytometry, DNA sequencing, graphics and imaging and semiconductor inspection.

[0001633978-18-000108:notes:403]
We also provide high-powered and ultrafast lasers for the industrial and scientific markets. Manufacturers use high-power, ultrafast lasers to create micro parts for consumer electronics and to process semiconductor, LED, and other types of chips. Use of ultrafast lasers for micromachining applications is being driven primarily by the increasing use of consumer electronics and connected devices globally.

[0001633978-18-000108:notes:404]
We do not allocate research and development, sales and marketing, or general and administrative expenses to our segments because management does not include the information in its measurement of the performance of the operating segments. In addition, we do not allocate amortization and impairment of acquisition-related intangible assets, stock-based compensation and certain other charges impacting the gross margin of each segment because management does not include this information in its measurement of the performance of the operating segments.

[0001633978-18-000108:notes:405]
We operate in three geographic regions: Americas, Asia-Pacific, and EMEA (Europe, Middle East, and Africa). Net revenue is assigned to the geographic region and country where our product is initially shipped. For example, certain customers may request shipment of our product to a contract manufacturer in one country, which may differ from the location of their end customers. The following table presents net revenue by the three geographic regions we operate in and net revenue from countries that represented 10% or more of our total net revenue (in millions, except percentage data):

[0001633978-18-000108:notes:406]
In March 2017, we completed the purchase of a property in Thailand for additional manufacturing capacity of our future growth for approximately $9.9 million in cash. The building was valued at $5.5 million and the land was valued at $4.4 million. We are in the process of transitioning the manufacturing of our products with one of our contract manufacturers in China to this Thailand manufacturing facility.

[0001633978-18-000108:notes:407]
We purchase a substantial portion of our inventory from contract manufacturers and vendors located primarily in Taiwan, Thailand, and China. For the fiscal years ended 2018 and 2017, net inventory purchased from a single contract manufacturer which represented 10% or greater of total net purchases is summarized as follows:


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001633978-18-000108:notes:408]
Note 7. Balance Sheet Details

[0001633978-18-000108:notes:409]
Accounts receivable allowances

[0001633978-18-000108:notes:410]
As of June 30, 2018 and July 1, 2017, our accounts receivable allowance balance was $2.6 million and $1.8 million, respectively.

[0001633978-18-000108:notes:411]
Inventories

[0001633978-18-000108:notes:412]
Prepayments and other current assets

[0001633978-18-000108:notes:413]
Property, plant and equipment, net

[0001633978-18-000108:notes:414]
During fiscal 2018, 2017 and 2016, we recorded depreciation expense of $74.0 million, $54.2 million and $47.4 million, respectively.

[0001633978-18-000108:notes:415]
Our construction in progress primarily includes machinery and equipment that were purchased in order to increase our manufacturing capacity. We expect to place these assets in service in the next 12 months.

[0001633978-18-000108:notes:416]
Other current liabilities

[0001633978-18-000108:notes:417]
Other non-current liabilities
