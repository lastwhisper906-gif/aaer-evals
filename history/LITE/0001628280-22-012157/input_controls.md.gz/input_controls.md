# LITE 10-Q controls and the auditor's report


## item_4_controls

[0001628280-22-012157:item_4_controls:1]
ITEM 4. CONTROLS AND PROCEDURES

[0001628280-22-012157:item_4_controls:2]
(a) Evaluation of Disclosure Controls and Procedures

[0001628280-22-012157:item_4_controls:3]
Our management (with the participation of our Principal Executive Officer and Principal Financial Officer), as of the end of the period covered by this Quarterly Report, evaluated the effectiveness of our disclosure controls and procedures. Based on this evaluation, our Principal Executive Officer and Principal Financial Officer concluded that our “disclosure controls and procedures” (as defined in Rules 13a-15(e) and 15d-15(e) under the Securities Exchange Act of 1934, as amended (the “Exchange Act”)) were effective to provide reasonable assurance that the information required to be disclosed by us in our reports filed or submitted under the Exchange Act is recorded, processed, summarized, and reported within the time periods specified in the SEC’s rules and forms and is accumulated and communicated to our management as appropriate to allow timely decisions regarding required disclosure.

[0001628280-22-012157:item_4_controls:4]
(b) Changes in Internal Control over Financial Reporting

[0001628280-22-012157:item_4_controls:5]
There were no changes in our internal control over financial reporting as defined in Exchange Act Rules 13a-15(f) and 15d-15(f), identified in connection with the evaluation required by Exchange Act Rules 13a-15(d) or 15d-15(d) that occurred during our most recently completed fiscal quarter that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.

[0001628280-22-012157:item_4_controls:6]
(c) Inherent Limitations on Effectiveness of Controls

[0001628280-22-012157:item_4_controls:7]
Our management, including the CEO and CFO, recognizes that our disclosure controls and procedures or our internal control over financial reporting cannot prevent or detect all possible instances of errors and all fraud. A control system, no matter how well designed and operated, can provide only reasonable, not absolute, assurance that the control system's objectives will be met. The design of a control system must reflect the fact that there are resource constraints, and the benefits of controls must be considered relative to their costs.

[0001628280-22-012157:item_4_controls:8]
53
