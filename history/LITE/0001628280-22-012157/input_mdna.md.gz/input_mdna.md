# LITE MD&A — 0001628280-22-012157


## mdna

[0001628280-22-012157:mdna:1]
[same as prior period, unchanged from 0001628280-22-001745:mdna:1]

[0001628280-22-012157:mdna:2]
[same as prior period, unchanged from 0001628280-22-001745:mdna:2]

[0001628280-22-012157:mdna:3]
[same as prior period, unchanged from 0001628280-22-001745:mdna:3]

[0001628280-22-012157:mdna:4]
[same as prior period, unchanged from 0001628280-22-001745:mdna:4]

[0001628280-22-012157:mdna:5]
[same as prior period, unchanged from 0001628280-22-001745:mdna:5]

[0001628280-22-012157:mdna:6]
[same as prior period, unchanged from 0001628280-22-001745:mdna:6]

[0001628280-22-012157:mdna:7]
[same as prior period, unchanged from 0001628280-22-001745:mdna:7]

[0001628280-22-012157:mdna:8]
[same as prior period, unchanged from 0001628280-22-001745:mdna:8]

[0001628280-22-012157:mdna:9]
[same as prior period, unchanged from 0001628280-22-001745:mdna:9]

[0001628280-22-012157:mdna:10]
On November 4, 2021, Lumentum and NeoPhotonics Corporation (“NeoPhotonics”) announced a merger agreement (the “Merger Agreement”) pursuant to which Lumentum will acquire all of the outstanding shares of NeoPhotonics. Under the terms of the Merger Agreement, NeoPhotonics stockholders will receive $16.00 per share in cash for each NeoPhotonics share they own. As of April 2, 2022, the estimated total transaction consideration is expected to be approximately $918 million.  The cash consideration will be funded from the combined company’s balance sheet.

[0001628280-22-012157:mdna:11]
The Merger Agreement contains certain termination rights for both Lumentum and NeoPhotonics and provides that upon termination of the Merger Agreement under specified circumstances (including termination by NeoPhotonics to accept a superior proposal), NeoPhotonics may be required to pay Lumentum a termination fee of $27.5 million. The Merger Agreement further provides that if the Merger Agreement is terminated for failure to obtain antitrust approval, Lumentum may be required to pay NeoPhotonics a termination fee of $55.1 million; and if Lumentum takes certain specified actions, (including entering into any definitive agreement for an acquisition by stock purchase, merger, consolidation, amalgamation, purchase of assets, license or otherwise of any ownership interest or assets of any Person) that cause a material delay in, or results in the failure of, the consummation of the merger, Lumentum may be required to pay NeoPhotonics an additional termination fee of $36.7 million.

[0001628280-22-012157:mdna:12]
The Boards of Directors of Lumentum and NeoPhotonics have unanimously approved the transaction and the Merger Agreement.

[0001628280-22-012157:mdna:13]
The transaction is subject to customary closing conditions, including the absence of certain legal impediments and receipt of any required antitrust and regulatory approvals.  The transaction is not subject to any financing condition.  On January 21, 2022, the waiting period under the Hart-Scott-Rodino Antitrust Improvements Act of 1976, as amended, expired with respect to the proposed acquisition. The transaction was approved by the NeoPhotonics stockholders on February 1, 2022.  We expect the merger to be completed in the second half of calendar year 2022.

[0001628280-22-012157:mdna:14]
Under the terms of the Merger Agreement, Lumentum agreed to arrange for up to $50 million in interim debt financing that is unsecured, subordinated to NeoPhotonics’ existing secured credit facility with Wells Fargo, has a two-year term and bears interest at the Prime Rate.  On January 14, 2022, Lumentum and NeoPhotonics entered into a credit agreement pursuant to which Lumentum agreed to make delayed draw term loans (“loans”) to NeoPhotonics in an aggregate principal amount not to exceed $50.0 million to help fund capital expenditures and increased working capital associated with NeoPhotonics’ growth plans. During the three months ended April 2, 2022, the Company funded a $30.0 million loan request to NeoPhotonics, which bears interest at the Wall Street Journal “prime rate,” which was 3.5% as of April 2, 2022. The interest is payable monthly in arrears on the first day of each month. The loans will mature on January 14, 2024 unless earlier repaid or accelerated.

[0001628280-22-012157:mdna:15]
[same as prior period, unchanged from 0001628280-22-001745:mdna:14]

[0001628280-22-012157:mdna:16]
Since February 2020, the COVID-19 pandemic has caused public health officials to recommend, and governments to enact, precautions to mitigate the spread of the virus, including travel restrictions and bans, extensive social distancing guidelines, closure or restrictions on business and quarantine or other types of “shelter-in-place” orders in many regions of the world. The pandemic and these related responses continue to cause a global slowdown of economic activity (including a decrease in demand for a broad variety of goods and services), disruptions in global supply chains, labor shortages, and significant volatility and potential disruption of financial markets. The ultimate extent to which COVID-19 will impact our business depends on future developments, which are highly uncertain and very difficult to predict, including the effectiveness and utilization of vaccines for COVID-19 and its variants, the severity of COVID-19 and its variants, and the effectiveness of the actions to contain or limit their spread.

[0001628280-22-012157:mdna:17]
From the start of the COVID-19 pandemic, we proactively implemented preventative measures and protocols, which we continuously assess and update for changes in conditions and emerging trends. Some of these measures have included complying with local, state or federal orders that require employees to work from home, instructing employees to work from home in certain jurisdictions, limiting the number of employees onsite which slowed our manufacturing operations in certain countries, enhancing use of personal protective equipment and restricting non-critical business travel by our employees, enacting vaccine and testing mandates in certain jurisdictions, and implementing health and safety enhancements. These measures are intended to safeguard our team members, contractors, suppliers, customers, distributors, and communities, and to ensure business continuity. Currently, our major production facilities in Europe, Asia, and the United States remain open. At most of our locations, we have transitioned from business continuity plans to return-to-office plans while continuing to maintain high standards of employee safety and sanitization protocols.

[0001628280-22-012157:mdna:18]
In the geographies where we have operations, we have, in general and where applicable, been deemed an essential business and been permitted to continue manufacturing and conducting new product development operations in a more limited capacity during the pandemic. This stems from our critical role in global supply chains for the world’s communications and health-care systems. However, the pandemic continues to affect our suppliers and manufacturers who are experiencing component materials and labor shortages. Given the continually evolving situation, particularly in light of the recent Delta and Omicron variants, it is difficult to predict the magnitude and duration of the impact of the COVID-19 pandemic to our markets, its effects, or precisely when our ability to supply our products will return to full capacity. We are continuing to actively monitor the situation and may take further actions altering our business operations that we determine are in the best interests of our employees, customers, communities, business partners, suppliers and stockholders, or as required by federal, state, or local authorities. It is not clear what the potential effects any such alterations or modifications may have on our business, including the effects on our customers, employees and prospects, or on our financial results for the future.

[0001628280-22-012157:mdna:19]
Our primary strategic focus for several years has been technology and product leadership combined with close customer relationships in long-term healthy and growing markets. We believe this strategy is even more apt, and our long-term opportunity is not diminished, with COVID-19. We believe there are long-term opportunities, as the world’s experience with COVID-19 could drive an increasingly digital and virtual world, touching all aspects of life and work, that increasingly emphasizes the importance of communications systems, cloud services, augmented and virtual reality, and enhanced security. Additionally, ever advancing electronic devices are needed to consume, produce, and communicate digital and virtual content. All these trends could drive the need for higher volumes of higher performing optical devices that we could supply. As such, we expect to continue to invest strongly in new products, technology and customer programs.

[0001628280-22-012157:mdna:20]
For more information on risks associated with the COVID-19 outbreak and regulatory actions, see the section titled “Risk Factors” in Item 1A of Part II of this report.

[0001628280-22-012157:mdna:21]
Supply Chain Constraints

[0001628280-22-012157:mdna:22]
COVID-19 has also created dynamics in the semiconductor component supply chains that have led to shortages of the types of components we and our customers require in our products. These shortages have impacted our ability to meet demand and generate revenue from certain products in fiscal 2022 and, if our ability to procure needed semiconductor components does not improve, this will impact our ability to supply our products to our customers and may reduce our revenue and profit margin. In addition, if our customers are unable to procure needed semiconductor components, this could reduce their demand for our products and reduce our revenue. The impact of semiconductor component shortages may continue in the near term as supplier and customer buffer inventories and safety stocks are exhausted. Due to the global supply chain constraint, we have had to incur incremental supply and procurement costs in order to increase our ability to fulfill demands from our customers. These costs have increased our inventory balances as of April 2, 2022 and may decrease our gross margin in the near term. We expect component supply to be a challenge at least through the second quarter of fiscal 2023.  For more information on risks associated with supply chain constraints, see the section titled “Risk Factors” in Item 1A of Part II of this report.

[0001628280-22-012157:mdna:23]
[same as prior period, unchanged from 0001628280-22-001745:mdna:20]

[0001628280-22-012157:mdna:24]
[same as prior period, unchanged from 0001628280-22-001745:mdna:21]

[0001628280-22-012157:mdna:25]
[same as prior period, unchanged from 0001628280-22-001745:mdna:22]

[0001628280-22-012157:mdna:26]
[same as prior period, unchanged from 0001628280-22-001745:mdna:23]

[0001628280-22-012157:mdna:27]
[same as prior period, unchanged from 0001628280-22-001745:mdna:24]

[0001628280-22-012157:mdna:28]
[same as prior period, unchanged from 0001628280-22-001745:mdna:25]

[0001628280-22-012157:mdna:29]
[same as prior period, unchanged from 0001628280-22-001745:mdna:26]

[0001628280-22-012157:mdna:30]
[same as prior period, unchanged from 0001628280-22-001745:mdna:27]

[0001628280-22-012157:mdna:31]
Management’s Discussion and Analysis of Financial Condition and Results of Operations contained in Part II, Item 7 of our Annual Report on Form 10-K for our fiscal year ended July 3, 2021 provides a more complete discussion of our critical accounting policies and estimates. Other than our policies on Business Combinations and Goodwill there have been no significant changes to these policies during the nine months ended April 2, 2022.

[0001628280-22-012157:mdna:32]
[same as prior period, unchanged from 0001628280-22-001745:mdna:29]

[0001628280-22-012157:mdna:33]
[same as prior period, unchanged from 0001628280-22-001745:mdna:30]

[0001628280-22-012157:mdna:34]
We allocate the fair value of purchase consideration to the tangible assets acquired, liabilities assumed and intangible assets acquired based on their estimated fair values. The excess of the fair value of purchase consideration over the fair values of these identifiable assets and liabilities is recorded as goodwill. When determining the fair values of assets acquired and liabilities assumed, we make significant estimates and assumptions, especially with respect to intangible assets. Critical estimates in valuing certain intangible assets include, but are not limited to, future expected cash flows from customer relationships and acquired developed technology and discount rates. Our estimates of fair value are based upon assumptions believed to be reasonable using best information available. These assumptions are inherently uncertain and unpredictable and, as a result, actual results may differ materially from estimates. Certain estimates associated with the accounting for acquisitions may

[0001628280-22-012157:mdna:35]
change as additional information becomes available regarding the assets acquired and liabilities assumed. Any change in facts and circumstances that existed as of the acquisition date and impacts to our preliminary estimates is recorded to goodwill if identified within the measurement period. Subsequent to the measurement period or our final determination of fair value of assets and liabilities, whichever is earlier, the adjustments will affect our earnings.

[0001628280-22-012157:mdna:36]
[same as prior period, unchanged from 0001628280-22-001745:mdna:32]

[0001628280-22-012157:mdna:37]
[same as prior period, unchanged from 0001628280-22-001745:mdna:33]

[0001628280-22-012157:mdna:38]
[same as prior period, unchanged from 0001628280-22-001745:mdna:34]

[0001628280-22-012157:mdna:39]
[same as prior period, unchanged from 0001628280-22-001745:mdna:35]

[0001628280-22-012157:mdna:40]
If we determine that, as a result of the qualitative assessment, it is more likely than not (i.e., greater than 50% likelihood) that the fair value of a reporting unit is less than its carrying amount, we perform the quantitative test by estimating the fair value of our reporting units. If the carrying value of a reporting unit exceeds its fair value, we record goodwill impairment loss equal to the excess of the carrying value of the reporting unit’s goodwill over its fair value, not to exceed the carrying amount of goodwill. The fair value of each of our goodwill reporting units is generally estimated using a combination of public company multiples and discounted cash flow methodologies.

[0001628280-22-012157:mdna:41]
40

[0001628280-22-012157:mdna:42]
Recently Issued Accounting Pronouncements

[0001628280-22-012157:mdna:43]
Refer to “Note 2. Recently Issued Accounting Pronouncements” in the notes to condensed consolidated financial statements.

[0001628280-22-012157:mdna:44]
[same as prior period, unchanged from 0001628280-22-001745:mdna:40]

[0001628280-22-012157:mdna:45]
[same as prior period, unchanged from 0001628280-22-001745:mdna:41]

[0001628280-22-012157:mdna:46]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 2, 2022 |  | April 3, 2021 |  | April 2, 2022 |  | April 3, 2021 |
| Segment net revenue: |  |  |  |  |  |  |  |
| OpComms | 87.1 | % |  | 92.5 | % |  | 88.9 | % |  | 93.7 | % |
| Lasers | 12.9 |  |  | 7.5 |  |  | 11.1 |  |  | 6.3 |  |
| Net revenue | 100.0 |  |  | 100.0 |  |  | 100.0 |  |  | 100.0 |  |
| Cost of sales | 53.8 |  |  | 52.1 |  |  | 49.3 |  |  | 50.7 |  |
| Amortization of acquired developed intangibles | 3.9 |  |  | 3.8 |  |  | 3.7 |  |  | 3.4 |  |
| Gross profit | 42.3 |  |  | 44.1 |  |  | 47.0 |  |  | 45.9 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 14.3 |  |  | 13.6 |  |  | 12.7 |  |  | 11.9 |  |
| Selling, general and administrative | 16.1 |  |  | 15.6 |  |  | 15.2 |  |  | 13.6 |  |
| Restructuring and related charges | — |  |  | 0.7 |  |  | (0.1) |  |  | 0.2 |  |
| Merger termination fee and related costs, net | — |  |  | (49.5) |  |  | — |  |  | (15.4) |  |
| Total operating expenses | 30.5 |  |  | (19.5) |  |  | 27.8 |  |  | 10.3 |  |
| Income from operations | 11.8 |  |  | 63.6 |  |  | 19.2 |  |  | 35.6 |  |
| Interest expense | (5.0) |  |  | (3.9) |  |  | (4.2) |  |  | (3.6) |  |
| Other income (expense), net | 0.6 |  |  | 0.6 |  |  | 0.3 |  |  | 0.2 |  |
| Income before income taxes | 7.4 |  |  | 60.3 |  |  | 15.3 |  |  | 32.2 |  |
| Provision for income taxes | 0.8 |  |  | 6.5 |  |  | 2.6 |  |  | 4.4 |  |
| Net income | 6.6 | % |  | 53.8 | % |  | 12.7 | % |  | 27.8 | % |

[0001628280-22-012157:mdna:47]
Financial Data for the three and nine months ended April 2, 2022 and April 3, 2021

[0001628280-22-012157:mdna:48]
[same as prior period, unchanged from 0001628280-22-001745:mdna:44]

[0001628280-22-012157:mdna:49]
|  | Three Months Ended |  |  |  |  |  | Nine Months Ended |  |  |  |  |
|  | April 2, 2022 |  | April 3, 2021 |  | Change |  | Percentage Change |  | April 2, 2022 |  | April 3, 2021 |  | Change |  | Percentage Change |
| Segment net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| OpComms | $ | 344.2 |  |  | $ | 387.9 |  |  | $ | (43.7) |  |  | (11.3) | % |  | $ | 1,147.6 |  |  | $ | 1,265.5 |  |  | $ | (117.9) |  |  | (9.3) | % |
| Lasers | 51.2 |  |  | 31.6 |  |  | 19.6 |  |  | 62.0 |  |  | 142.9 |  |  | 85.2 |  |  | 57.7 |  |  | 67.7 |  |
| Net revenue | $ | 395.4 |  |  | $ | 419.5 |  |  | $ | (24.1) |  |  | (5.7) | % |  | $ | 1,290.5 |  |  | $ | 1,350.7 |  |  | $ | (60.2) |  |  | (4.5) | % |
| Gross profit | $ | 167.2 |  |  | $ | 185.0 |  |  | $ | (17.8) |  |  | (9.6) | % |  | $ | 606.9 |  |  | $ | 620.3 |  |  | $ | (13.4) |  |  | (2.2) | % |
| Gross margin | 42.3 | % |  | 44.1 | % |  |  |  |  |  | 47.0 | % |  | 45.9 | % |  |  |  |  |
| Research and development | $ | 56.7 |  |  | $ | 57.2 |  |  | $ | (0.5) |  |  | (0.9) | % |  | $ | 164.0 |  |  | $ | 160.4 |  |  | $ | 3.6 |  |  | 2.2 | % |
| Percentage of net revenue | 14.3 | % |  | 13.6 | % |  |  |  |  |  | 12.7 | % |  | 11.9 | % |  |  |  |  |
| Selling, general and administrative | $ | 63.8 |  |  | $ | 65.5 |  |  | $ | (1.7) |  |  | (2.6) | % |  | $ | 196.1 |  |  | $ | 183.1 |  |  | $ | 13.0 |  |  | 7.1 | % |
| Percentage of net revenue | 16.1 | % |  | 15.6 | % |  |  |  |  |  | 15.2 | % |  | 13.6 | % |  |  |  |  |
| Restructuring and related charges | $ | (0.1) |  |  | $ | 2.9 |  |  | $ | (3.0) |  |  | N/A |  | $ | (1.1) |  |  | $ | 3.1 |  |  | $ | (4.2) |  |  | N/A |
| Percentage of net revenue | — | % |  | 0.7 | % |  |  |  |  |  | (0.1) | % |  | 0.2 | % |  |  |  |  |
| Merger termination fee and related costs, net | $ | — |  |  | $ | (207.5) |  |  | $ | 207.5 |  |  | (100.0) | % |  | $ | — |  |  | $ | (207.5) |  |  | $ | 207.5 |  |  | (100.0) | % |
| Percentage of net revenue | — | % |  | (49.5) | % |  |  |  |  |  | — | % |  | (15.4) | % |  |  |  |  |

[0001628280-22-012157:mdna:50]
[same as prior period, unchanged from 0001628280-22-001745:mdna:46]

[0001628280-22-012157:mdna:51]
Net revenue decreased by $24.1 million, or 5.7%, during the three months ended April 2, 2022 compared to the three months ended April 3, 2021, due to a $43.7 million decrease in OpComms revenue, partially offset by a $19.6 million increase in Lasers revenue.

[0001628280-22-012157:mdna:52]
OpComms net revenue decreased by $43.7 million, or 11.3%, during the three months ended April 2, 2022 compared to the three months ended April 3, 2021. Within OpComms, Telecom and Datacom decreased by $12.3 million primarily a result of continued material and component shortages for our Telecom products. Industrial and Consumer decreased by $31.4 million primarily due to a decrease in average selling price for our chips as a result of a smaller chips design.

[0001628280-22-012157:mdna:53]
Lasers net revenue increased by $19.6 million, or 62.0%, during the three months ended April 2, 2022 compared to the three months ended April 3, 2021, primarily due to a return in customer demand for our kilowatt class fiber lasers following the recent recovery in industrial production.

[0001628280-22-012157:mdna:54]
Net revenue decreased by $60.2 million, or 4.5%, during the nine months ended April 2, 2022 compared to the nine months ended April 3, 2021, due to $117.9 million decrease in OpComms revenue, partially offset by $57.7 million increase in Lasers revenue.

[0001628280-22-012157:mdna:55]
OpComms net revenue decreased by $117.9 million, or 9.3%, during the nine months ended April 2, 2022 compared to the nine months ended April 3, 2021. Within OpComms, Telecom and Datacom decreased by $76.7 million primarily a result of continued material and component shortages and lower demand due to continued delays in 5G deployments, partially offset by an increase in revenue for our EML product driven by capacity growth to satisfy demand, as well as revenue increases for

[0001628280-22-012157:mdna:56]
10G Tunable, Coherent Component, and Pump Laser products. Industrial and Consumer decreased by $41.2 million primarily due to a decrease in average selling price for our chips as a result of a smaller chips design.

[0001628280-22-012157:mdna:57]
Lasers net revenue increased by $57.7 million, or 67.7%, during the nine months ended April 2, 2022 compared to the nine months ended April 3, 2021, primarily due to a return in customer demand for our kilowatt class fiber lasers following the COVID-19 disruption in fiscal 2021 and improved production utilization.

[0001628280-22-012157:mdna:58]
During the three and nine months ended April 2, 2022, our net revenue from a single customer, which represented 10.0% or greater of total net revenue was concentrated with two customers, who collectively accounted for 38% and 43% of our total net revenue, respectively.

[0001628280-22-012157:mdna:59]
During the three and nine months ended April 3, 2021, our net revenue from a single customer, which represented 10% or greater of total net revenue was concentrated with two and three customers, respectively, who collectively accounted for 44% and 53% of our total net revenue, respectively.

[0001628280-22-012157:mdna:60]
[same as prior period, unchanged from 0001628280-22-001745:mdna:55]

[0001628280-22-012157:mdna:61]
[same as prior period, unchanged from 0001628280-22-001745:mdna:56]

[0001628280-22-012157:mdna:62]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 2, 2022 |  | April 3, 2021 |  | April 2, 2022 |  | April 3, 2021 |
|  | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States | $ | 36.3 |  |  | 9.2 | % |  | $ | 38.2 |  |  | 9.1 | % |  | $ | 115.4 |  |  | 8.9 | % |  | $ | 98.2 |  |  | 7.3 | % |
| Mexico | 42.3 |  |  | 10.7 |  |  | 16.3 |  |  | 3.9 |  |  | 113.6 |  |  | 8.8 |  |  | 107.4 |  |  | 8.0 |  |
| Other Americas | 3.0 |  |  | 0.7 |  |  | 3.7 |  |  | 0.9 |  |  | 7.7 |  |  | 0.6 |  |  | 10.5 |  |  | 0.7 |  |
| Total Americas | $ | 81.6 |  |  | 20.6 | % |  | $ | 58.2 |  |  | 13.9 | % |  | $ | 236.7 |  |  | 18.3 | % |  | $ | 216.1 |  |  | 16.0 | % |
| Asia-Pacific: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Hong Kong | $ | 109.2 |  |  | 27.6 | % |  | $ | 134.2 |  |  | 32.0 | % |  | $ | 366.5 |  |  | 28.4 | % |  | $ | 426.6 |  |  | 31.6 | % |
| Philippines | 2.5 |  |  | 0.6 |  |  | 30.9 |  |  | 7.4 |  |  | 20.5 |  |  | 1.6 |  |  | 134.3 |  |  | 9.9 |  |
| South Korea | 50.3 |  |  | 12.7 |  |  | 63.3 |  |  | 15.1 |  |  | 233.3 |  |  | 18.1 |  |  | 185.3 |  |  | 13.7 |  |
| Japan | 44.5 |  |  | 11.3 |  |  | 32.6 |  |  | 7.7 |  |  | 137.3 |  |  | 10.6 |  |  | 81.0 |  |  | 6.0 |  |
| Other Asia-Pacific | 78.9 |  |  | 20.0 |  |  | 64.0 |  |  | 15.2 |  |  | 212.8 |  |  | 16.5 |  |  | 201.2 |  |  | 14.9 |  |
| Total Asia-Pacific | $ | 285.4 |  |  | 72.2 | % |  | $ | 325.0 |  |  | 77.4 | % |  | $ | 970.4 |  |  | 75.2 | % |  | $ | 1,028.4 |  |  | 76.1 | % |
| EMEA | $ | 28.4 |  |  | 7.2 | % |  | $ | 36.3 |  |  | 8.7 | % |  | $ | 83.4 |  |  | 6.5 | % |  | $ | 106.2 |  |  | 7.9 | % |
| Total net revenue | $ | 395.4 |  |  |  |  | $ | 419.5 |  |  |  |  | $ | 1,290.5 |  |  |  |  | $ | 1,350.7 |  |  |  |

[0001628280-22-012157:mdna:63]
For the three and nine months ended April 2, 2022, net revenue from customers outside the United States, based on customer shipping location, represented 90.8% and 91.1% of net revenue, respectively. For the three and nine months ended April 3, 2021, net revenue from customers outside the United States, based on customer shipping location, represented 90.9% and 92.7% of net revenue, respectively.

[0001628280-22-012157:mdna:64]
[same as prior period, unchanged from 0001628280-22-001745:mdna:59]

[0001628280-22-012157:mdna:65]
[same as prior period, unchanged from 0001628280-22-001745:mdna:61]

[0001628280-22-012157:mdna:66]
[same as prior period, unchanged from 0001628280-22-001745:mdna:62]

[0001628280-22-012157:mdna:67]
|  | Three Months Ended |  | Nine Months Ended |
|  | Gross Profit |  | Gross Margin |  | Gross Profit |  | Gross Margin |
|  | April 2, 2022 |  | April 3, 2021 |  | April 2, 2022 |  | April 3, 2021 |  | April 2, 2022 |  | April 3, 2021 |  | April 2, 2022 |  | April 3, 2021 |
| OpComms | $ | 168.5 |  |  | $ | 194.3 |  |  | 49.0 | % |  | 50.1 | % |  | $ | 596.2 |  |  | $ | 660.9 |  |  | 52.0 | % |  | 52.2 | % |
| Lasers | 27.1 |  |  | 14.9 |  |  | 52.9 | % |  | 47.2 | % |  | 74.1 |  |  | 39.4 |  |  | 51.9 | % |  | 46.2 | % |
| Segment total | $ | 195.6 |  |  | $ | 209.2 |  |  | 49.5 | % |  | 49.9 | % |  | $ | 670.3 |  |  | $ | 700.3 |  |  | 51.9 | % |  | 51.8 | % |
| Unallocated corporate items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation | (5.4) |  |  | (5.3) |  |  |  |  |  |  | (15.2) |  |  | (13.8) |  |  |  |  |  |
| Amortization of acquired intangibles | (15.6) |  |  | (15.8) |  |  |  |  |  |  | (47.3) |  |  | (45.8) |  |  |  |  |  |
| Inventory and fixed asset write down due to product line exits | — |  |  | — |  |  |  |  |  |  | (0.1) |  |  | (0.4) |  |  |  |  |  |
| Other (charges) gains (1) | (7.4) |  |  | (3.1) |  |  |  |  |  |  | (0.8) |  |  | (20.0) |  |  |  |  |  |
| Total | $ | 167.2 |  |  | $ | 185.0 |  |  | 42.3 | % |  | 44.1 | % |  | $ | 606.9 |  |  | $ | 620.3 |  |  | 47.0 | % |  | 45.9 | % |

[0001628280-22-012157:mdna:68]
(1)   Other (charges) gains of unallocated corporate items for the three months ended April 2, 2022 primarily relate to $5.8 million of charges to acquire components from various brokers to satisfy customer demand.

[0001628280-22-012157:mdna:69]
Other (charges) gains of unallocated corporate items for the nine months ended April 2, 2022 primarily relate to $5.8 million of charges to acquire components from various brokers to satisfy customer demand, offset by a $5.9 million gain as a result of selling equipment that was no longer needed after we transferred certain product lines to new production facilities in fiscal 2021.

[0001628280-22-012157:mdna:70]
Other (charges) gains of unallocated corporate items for the three and nine months ended April 3, 2021 relate to costs of transferring product lines to new production facilities, including Thailand, of $1.4 million and $6.5 million, respectively. We also incurred excess and obsolete inventory charges driven by U.S. trade restrictions and the related decline in demand from Huawei of $1.0 million and $7.7 million during the three and nine months ended April 3, 2021, respectively. Our excess and obsolete inventory charges related to Huawei were offset by $2.1 million of sales of inventory previously written down.  During the nine months ended April 3, 2021, there was also a $5.0 million fixed asset write-off associated with excess capacity related to our Fiber laser business.

[0001628280-22-012157:mdna:71]
[same as prior period, unchanged from 0001628280-22-001745:mdna:66]

[0001628280-22-012157:mdna:72]
[same as prior period, unchanged from 0001628280-22-001745:mdna:67]

[0001628280-22-012157:mdna:73]
Gross margin for the three months ended April 2, 2022 decreased to 42.3% from 44.1% for the three months ended April 3, 2021. The decrease was primarily driven by lower gross margin from the OpComms as a result of a less profitable mix of products, including lower sales of higher margin 3D sensing products; $5.8 million of charges to acquire components from various brokers to satisfy customer demand; and a temporary closure of our factory in China as a result of an increase in the number of COVID-19 cases as required by local government mandates.

[0001628280-22-012157:mdna:74]
Gross margin for the nine months ended April 2, 2022 increased to 47.0% from 45.9% for the nine months ended April 3, 2021, driven by higher gross margin from the Lasers segment due to the higher manufacturing levels and improved factory utilization as a result of return in customer demand for our kilowatt class fiber products following the recent recovery in industrial production, and $1.8 million in lower excess and obsolete inventory charges, as we took charges during the nine months ended April 3, 2021 driven by U.S. trade restrictions and the related decline in demand. However, these improvements in gross margin were partially offset by $5.8 million of charges to acquire components from various brokers to satisfy customer demand; and a temporary closure of our factory in China as a result of an increase in the number of COVID-19 cases as required by local government mandates.

[0001628280-22-012157:mdna:75]
[same as prior period, unchanged from 0001628280-22-001745:mdna:70]

[0001628280-22-012157:mdna:76]
Although the magnitude of the impact of COVID-19 on our business operations remains uncertain and difficult to predict, and this remains a highly dynamic situation, we have experienced, and we expect that we may continue to experience disruptions to our and our customers’ businesses that will adversely impact our business, financial condition and results of operations. Due to the global supply chain constraint, we have had to incur incremental supply and procurement costs in order to increase our ability to fulfill demands from our customers. These costs have increased our inventory balances as of April 2, 2022 and will decrease our gross margin in the near term.

[0001628280-22-012157:mdna:77]
[same as prior period, unchanged from 0001628280-22-001745:mdna:72]

[0001628280-22-012157:mdna:78]
[same as prior period, unchanged from 0001628280-22-001745:mdna:73]

[0001628280-22-012157:mdna:79]
OpComms gross margin for the three months ended April 2, 2022 decreased to 49.0% from 50.1% for the three months ended April 3, 2021. The decrease was primarily due to a less profitable mix of products, including lower sales of higher margin 3D sensing products.

[0001628280-22-012157:mdna:80]
OpComms gross margin for the nine months ended April 2, 2022 remained relatively flat at 52.0% from 52.2% for the nine months ended April 3, 2021.

[0001628280-22-012157:mdna:81]
[same as prior period, unchanged from 0001628280-22-001745:mdna:76]

[0001628280-22-012157:mdna:82]
Lasers gross margin for the three months ended April 2, 2022 increased to 52.9% from 47.2% for the three months ended April 3, 2021. The increase was primarily due to the higher manufacturing levels related to the return in customer demand for our kilowatt class fiber products, following the COVID-19 disruption in fiscal 2021.

[0001628280-22-012157:mdna:83]
Lasers gross margin for the nine months ended April 2, 2022 increased to 51.9% from 46.2% for the nine months ended April 3, 2021. The increase was primarily due to the higher manufacturing levels related to the return in customer demand for our kilowatt class fiber products, following the COVID-19 disruption in fiscal 2021.

[0001628280-22-012157:mdna:84]
[same as prior period, unchanged from 0001628280-22-001745:mdna:79]

[0001628280-22-012157:mdna:85]
R&D expense decreased by $0.5 million, or 0.9%, for the three months ended April 2, 2022 compared to the three months ended April 3, 2021, and increased by $3.6 million, or 2.2%, for the nine months ended April 2, 2022 compared to the nine months ended April 3, 2021. The increase in R&D expense for the nine months ended April 2, 2022 was primarily driven by $2.6 million increase in new product development activities in our factories, $0.9 million increase in share-based compensation, and lower non-recurring engineering reimbursements.

[0001628280-22-012157:mdna:86]
[same as prior period, unchanged from 0001628280-22-001745:mdna:81]

[0001628280-22-012157:mdna:87]
[same as prior period, unchanged from 0001628280-22-001745:mdna:82]

[0001628280-22-012157:mdna:88]
SG&A expense decreased by $1.7 million, or 2.6%, during the three months ended April 2, 2022 compared to the three months ended April 3, 2021, and increased by $13.0 million, or 7.1%, during the nine months ended April 2, 2022 compared to the nine months ended April 3, 2021. The increase in SG&A expense for the nine months ended April 2, 2022 was primarily due to a $9.5 million increase in outside services and professional fees related to the pending NeoPhotonics acquisition and increased investments in information technology and professional service fees related to optimizing our international legal structure, and a $1.1 million increase in share-based compensation primarily due to an increase in stock price and employee headcount.

[0001628280-22-012157:mdna:89]
[same as prior period, unchanged from 0001628280-22-001745:mdna:85]

[0001628280-22-012157:mdna:90]
[same as prior period, unchanged from 0001628280-22-001745:mdna:86]

[0001628280-22-012157:mdna:91]
[same as prior period, unchanged from 0001628280-22-001745:mdna:87]

[0001628280-22-012157:mdna:92]
During the nine months ended April 2, 2022, we recorded a net reversal to our restructuring and related charges of $1.1 million, which was attributable to lower than anticipated employee severance charges primarily as a result of retaining and re-assigning certain employees.

[0001628280-22-012157:mdna:93]
During the three and nine months ended April 3, 2021, we recorded $2.9 million and $3.1 million, respectively, in our condensed consolidated statements of operations for each period in restructuring and related charges in our condensed consolidated statements of operations. The charges were mainly attributable to severance charges associated with the decision to cease manufacturing of certain products in San Jose, California.

[0001628280-22-012157:mdna:94]
Merger Termination Fee and Related Costs, Net

[0001628280-22-012157:mdna:95]
On January 18, 2021, we entered into a merger agreement with Coherent, under which we would acquire all outstanding shares of Coherent common stock. In March 2021, Coherent terminated the merger agreement and paid us a termination fee of $217.6 million in accordance with the merger agreement. For each of the three and nine months ended April 3, 2021, we recorded $217.6 million gain related to the receipt of a termination fee from Coherent in March 2021 as a result of the termination of our merger agreement. This gain was offset by $10.1 million of Coherent acquisition related charges and presented as “merger termination fee and related costs, net” in our condensed consolidated statements of operations for the three and nine months ended April 3, 2021.

[0001628280-22-012157:mdna:96]
[same as prior period, unchanged from 0001628280-22-001745:mdna:90]

[0001628280-22-012157:mdna:97]
For the three months ended April 2, 2022 and April 3, 2021, we recorded interest expense of $19.7 million and $16.4 million, respectively, driven primarily by the amortization of the debt discount and issuance costs of our convertible notes.  The increase in interest expense for the three months ended April 2, 2022 compared to the three months ended April 3, 2021, is primarily a result of issuing $861.0 million in aggregate principal amount of 0.50% Convertible Notes due in 2028 in March 2022.

[0001628280-22-012157:mdna:98]
For the nine months ended April 2, 2022 and April 3, 2021, we recorded interest expense of $53.7 million and $48.7 million, respectively, driven primarily by the amortization of the debt discount and issuance costs of our convertible notes.   The increase in interest expense for the nine months ended April 2, 2022 compared to the nine months ended April 3, 2021, is primarily a result of issuing $861.0 million in aggregate principal amount of 0.50% Convertible Notes due in 2028 in March 2022.

[0001628280-22-012157:mdna:99]
[same as prior period, unchanged from 0001628280-22-001745:mdna:93]

[0001628280-22-012157:mdna:100]
[same as prior period, unchanged from 0001628280-22-001745:mdna:94]

[0001628280-22-012157:mdna:101]
|  | Three Months Ended |  | Nine Months Ended |  |  |
|  | April 2, 2022 |  | April 3, 2021 |  | April 2, 2022 |  | April 3, 2021 |  |  |
| Foreign exchange gains (losses), net | $ | 1.1 |  |  | $ | 1.3 |  |  | $ | 1.7 |  |  | $ | (3.8) |  |  |  |
| Interest and investment income | 1.1 |  |  | 1.0 |  |  | 2.3 |  |  | 4.9 |  |  |  |
| Other income (expense), net | — |  |  | 0.1 |  |  | (0.2) |  |  | 1.0 |  |  |  |
| Total other income (expense), net | $ | 2.2 |  |  | $ | 2.4 |  |  | $ | 3.8 |  |  | $ | 2.1 |  |  |  |

[0001628280-22-012157:mdna:102]
For the three months ended April 2, 2022, other income (expense), net decreased by $0.2 million.

[0001628280-22-012157:mdna:103]
For the nine months ended April 2, 2022, other income (expense), net increased by $1.7 million in income as compared to the nine months ended April 3, 2021, due to $5.5 million less in foreign exchange losses as a result of more stable exchange rates between the U.S. dollar and certain foreign currencies, partially offset by a $2.6 million decrease in interest and investment income as a result of our cash equivalent and investments acquired before COVID-19 maturing and being reinvested at lower yielding investments.

[0001628280-22-012157:mdna:104]
[same as prior period, unchanged from 0001628280-22-001745:mdna:98]

[0001628280-22-012157:mdna:105]
| (in millions) | Three Months Ended |  | Nine Months Ended |
|  | April 2, 2022 |  | April 3, 2021 |  | April 2, 2022 |  | April 3, 2021 |
| Provision for income taxes | $ | 3.3 |  |  | $ | 27.4 |  |  | $ | 33.8 |  |  | $ | 58.8 |  |

[0001628280-22-012157:mdna:106]
We recorded a tax provision of $3.3 million and $27.4 million for the three months ended April 2, 2022 and April 3, 2021, respectively. Our tax provision for the three months ended April 2, 2022  includes a discrete tax benefit of $2.0 million, primarily related to currency re-measurement of certain tax related accounts and excess tax benefit related to stock-based compensation that vested during the quarter.  Our tax provision for the three months ended April 3, 2021 includes a discrete tax expense of $16.8 million mainly from the tax expense associated with the Coherent termination fee partially offset by currency re-measurement of certain tax related accounts and return-to-provision differences.  Our estimated effective tax rate for fiscal 2022 differs from the 21% U.S. statutory rate primarily due to the income tax benefit from the earnings of our foreign subsidiaries being taxed at rates that differ from the U.S. statutory rate and U.S. federal R&D tax credits, partially offset by the income tax expense from the tax effect of Global Intangible Low-Taxed Income (“GILTI”), net of benefit for foreign tax credits, subpart F inclusion and non-deductible stock-based compensation.

[0001628280-22-012157:mdna:107]
[same as prior period, unchanged from 0001628280-22-001745:mdna:101]

[0001628280-22-012157:mdna:108]
[same as prior period, unchanged from 0001628280-22-001745:mdna:102]

[0001628280-22-012157:mdna:109]
As of April 2, 2022 and July 3, 2021, our cash and cash equivalents were $1,130.3 million and $774.3 million, respectively. As of April 2, 2022 and July 3, 2021, our short-term investments of $1,433.8 million and $1,171.7 million, respectively, were all invested in the United States. Cash equivalents and short-term investments are primarily comprised of money market funds, U.S. treasury securities, and commercial paper. Our investment policy and strategy is focused on the preservation of capital and supporting our liquidity requirements.

[0001628280-22-012157:mdna:110]
The total amount of cash outside the United States held by the non-United States entities as of April 2, 2022 and July 3, 2021 was $148.8 million and $113.3 million, respectively, which was primarily held by entities incorporated in the United Kingdom, the British Virgin Islands, Japan, Hong Kong, China, Canada and Thailand. Although the cash currently held in the United States, as well as the cash generated in the United States from future operations, is expected to cover our normal operating requirements, a substantial amount of additional cash could be required for other purposes, such as capital expenditures to support our business and growth, including costs associated with increasing internal manufacturing capabilities, particularly in our Thailand facility, strategic transactions and partnerships, and future acquisitions.

[0001628280-22-012157:mdna:111]
[same as prior period, unchanged from 0001628280-22-001745:mdna:106]

[0001628280-22-012157:mdna:112]
[same as prior period, unchanged from 0001628280-22-001745:mdna:107]

[0001628280-22-012157:mdna:113]
We believe that our cash and cash equivalents as of April 2, 2022 and cash flows from our operating activities will be sufficient to meet our liquidity and capital spending requirements for at least the next 12 months.

[0001628280-22-012157:mdna:114]
[same as prior period, unchanged from 0001628280-22-001745:mdna:109]

[0001628280-22-012157:mdna:115]
[same as prior period, unchanged from 0001628280-22-001745:mdna:110]

[0001628280-22-012157:mdna:116]
[same as prior period, unchanged from 0001628280-22-001745:mdna:111]

[0001628280-22-012157:mdna:117]
[same as prior period, unchanged from 0001628280-22-001745:mdna:112]

[0001628280-22-012157:mdna:118]
[same as prior period, unchanged from 0001628280-22-001745:mdna:113]

[0001628280-22-012157:mdna:119]
[same as prior period, unchanged from 0001628280-22-001745:mdna:114]

[0001628280-22-012157:mdna:120]
[same as prior period, unchanged from 0001628280-22-001745:mdna:115]

[0001628280-22-012157:mdna:121]
[same as prior period, unchanged from 0001628280-22-001745:mdna:116]

[0001628280-22-012157:mdna:122]
[same as prior period, unchanged from 0001628280-22-001745:mdna:117]

[0001628280-22-012157:mdna:123]
[same as prior period, unchanged from 0001628280-22-001745:mdna:118]

[0001628280-22-012157:mdna:124]
[same as prior period, unchanged from 0001628280-22-001745:mdna:119]

[0001628280-22-012157:mdna:125]
[same as prior period, unchanged from 0001628280-22-001745:mdna:120]

[0001628280-22-012157:mdna:126]
•the settlement of any conversion or redemption of the 2024 Notes, 2026 Notes and the 2028 Notes in cash;

[0001628280-22-012157:mdna:127]
[same as prior period, unchanged from 0001628280-22-001745:mdna:122]

[0001628280-22-012157:mdna:128]
[same as prior period, unchanged from 0001628280-22-001745:mdna:123]

[0001628280-22-012157:mdna:129]
[same as prior period, unchanged from 0001628280-22-001745:mdna:124]

[0001628280-22-012157:mdna:130]
The following table summarizes certain of our contractual obligations as of April 2, 2022, and the effect such obligations are expected to have on our liquidity and cash flow over the next five years (in millions):

[0001628280-22-012157:mdna:131]
|  | Payments due by period |
|  | Total |  | Less than 1 year |  | 1 - 3 years |  | 3 - 5 years |  | More than 5 years |
| Contractual Obligations |  |  |  |  |  |  |  |  |  |
| Asset retirement obligations | $ | 4.7 |  |  | $ | 0.5 |  |  | $ | 0.9 |  |  | $ | 1.2 |  |  | $ | 2.1 |  |
| Operating lease liabilities, including imputed interest (1) | 72.2 |  |  | 13.8 |  |  | 23.2 |  |  | 14.8 |  |  | 20.4 |  |
| Pension plan contributions (2) | 0.5 |  |  | 0.5 |  |  | — |  |  | — |  |  | — |  |
| Purchase obligations (3) | 345.6 |  |  | 313.6 |  |  | 32.0 |  |  | — |  |  | — |  |
| Convertible notes - principal (4) | 2,361.0 |  |  | 1.8 |  |  | 448.2 |  |  | 1,050.0 |  |  | 861.0 |  |
| Convertible notes - interest (4) | 55.6 |  |  | 9.7 |  |  | 24.6 |  |  | 19.1 |  |  | 2.2 |  |
| Total | $ | 2,839.6 |  |  | $ | 339.9 |  |  | $ | 528.9 |  |  | $ | 1,085.1 |  |  | $ | 885.7 |  |

[0001628280-22-012157:mdna:132]
(1) The amounts of operating lease liabilities in the table above do not include any sublease income amounts nor do they include payments for short-term leases or variable lease payments. As of April 2, 2022, we expect to receive sublease income of approximately $1.5 million over the next year. Refer to “Note 7. Leases” in the notes to condensed consolidated financial statements.

[0001628280-22-012157:mdna:133]
[same as prior period, unchanged from 0001628280-22-001745:mdna:128]

[0001628280-22-012157:mdna:134]
(3) Purchase obligations represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Refer to “Note 14. Commitments and Contingencies” in the notes to condensed consolidated financial statements.

[0001628280-22-012157:mdna:135]
(4) The amount includes principal and interest payment in cash on our 0.25% Convertible Notes due in 2024 (the “2024 Notes”) through March 2024; principal and interest on our 0.50% Convertible Notes due in 2026 (the “2026 Notes”) through December 2026; and principal and interest on our 0.50% Convertible Notes due in 2028 (the “2028 Notes” and together with the 2024 Notes and 2026 Notes, the “Notes”) through June 2028. The 2024 Notes have a maturity date of March 15, 2024, the 2026 Notes have a maturity date of December 15, 2026, and the 2028 Notes have a maturity date of June 15, 2028. The principal balances of our Notes are reflected in the payment periods in the table above based on their respective contractual maturities assuming no conversion. Refer to “Note 9. Debt” in the notes to condensed consolidated financial statements.

[0001628280-22-012157:mdna:136]
[same as prior period, unchanged from 0001628280-22-001745:mdna:131]

[0001628280-22-012157:mdna:137]
[same as prior period, unchanged from 0001628280-22-001745:mdna:132]

[0001628280-22-012157:mdna:138]
As of April 2, 2022, the debt component of our 2024 Notes of $406.1 million (principal balance of $450.0 million maturing in 2024) is presented in current liabilities in our condensed consolidated balance sheet since our stock price exceeded $78.80 for 20 of the last 30 trading days of the quarter ended April 2, 2022 and the 2024 Notes are convertible at the option of the holders. During the nine months ended April 2, 2022, we received and settled in cash, conversion requests of less than $0.1 million principal amount of the 2024 Notes. From April 1, 2022 through May 4, 2022, we received requests for conversion of approximately $1.8 million in principal amount of the 2024 Notes. Such conversion will be settled in the fourth quarter of fiscal 2022 with a combination of cash and shares of the Company’s common stock in accordance with the applicable indenture.

[0001628280-22-012157:mdna:139]
As of April 2, 2022, the debt component of our 2026 Notes of $820.8 million (principal balance of $1,050.0 million maturing in 2026) is presented in non-current liabilities. If the closing price of our stock exceeds $129.08 for 20 of the last 30 trading days of any future quarter, our 2026 Notes would also become convertible at the option of the holders and the debt component would be reclassified to current liabilities in our condensed consolidated balance sheet.

[0001628280-22-012157:mdna:140]
As of April 2, 2022, the debt component of our 2028 Notes of $626.8 million (principal balance of $861.0 million maturing in 2028) is presented in non-current liabilities. If the closing price of our stock exceeds $170.34 for 20 of the last 30 trading days in any fiscal quarter commencing after July 2, 2022, our 2028 Notes would also become convertible at the option of the holders and the debt component would be reclassified to current liabilities in our condensed consolidated balance sheet.

[0001628280-22-012157:mdna:141]
Share Repurchases

[0001628280-22-012157:mdna:142]
Repurchase Made in Connection with Convertible Note Offering

[0001628280-22-012157:mdna:143]
In the third quarter of fiscal year 2022, concurrent with the issuance of the 2028 Notes, we repurchased 2.0 million shares of our common stock in privately negotiated transactions at an average price of $99.0 per share for an aggregate purchase price of $200.0 million. We recorded the $200.0 million aggregate purchase price as a reduction of retained earnings within our condensed consolidated balance sheet.  These shares were retired immediately.

[0001628280-22-012157:mdna:144]
[same as prior period, unchanged from 0001628280-22-001745:mdna:135]

[0001628280-22-012157:mdna:145]
On May 7, 2021, our board of directors approved the 2021 share buyback program, which authorizes us to use up to $700.0 million to purchase our own shares of common stock. The 2021 share buyback program was authorized for 2 years. On March 3, 2022, our board of directors approved an increase in our share buyback program, which authorizes us to use up to an aggregate amount of $1.0 billion to purchase our own shares of common stock.

[0001628280-22-012157:mdna:146]
During the nine months ended April 2, 2022, we repurchased 2.7 million shares of our common stock at an average price of $89.80 per share for an aggregate purchase price of $245.5 million.

[0001628280-22-012157:mdna:147]
Since the 2021 share buyback program was approved by the board of directors, we have repurchased 5.8 million shares in aggregate at an average price of $83.45 per share for a total purchase price of $486.5 million. We recorded the $486.5 million aggregate purchase price as a reduction of retained earnings within our condensed consolidated balance sheet. All repurchased shares were retired immediately.

[0001628280-22-012157:mdna:148]
The price, timing, amount, and method of such repurchases will be determined based on the valuation of market conditions and other factors, at prices determined to be attractive and in the best interests of both Lumentum and our stockholders.

[0001628280-22-012157:mdna:149]
[same as prior period, unchanged from 0001628280-22-001745:mdna:138]

[0001628280-22-012157:mdna:150]
As of April 2, 2022, our other non-current liabilities also include $26.4 million of unrecognized tax benefit for uncertain tax positions. We are unable to reliably estimate the timing of future payments related to uncertain tax positions.

[0001628280-22-012157:mdna:151]
[same as prior period, unchanged from 0001628280-22-001745:mdna:140]

[0001628280-22-012157:mdna:152]
As of April 2, 2022, our balance of cash and cash equivalents increased by $356.0 million, to $1,130.3 million from $774.3 million as of July 3, 2021. The increase in cash and cash equivalents during the nine months ended April 2, 2022 was due to  cash provided by financing activities of $380.0 million and cash provided by operating activities of $345.0 million, partially offset by cash used in investing activities of $369.0 million.

[0001628280-22-012157:mdna:153]
[same as prior period, unchanged from 0001628280-22-001745:mdna:142]

[0001628280-22-012157:mdna:154]
Cash provided by operating activities was $345.0 million during the nine months ended April 2, 2022, which reflects net income of $164.2 million and non-cash items of $254.7 million for the nine months ended April 2, 2022, offset by $73.9 million change in operating assets and liabilities. Changes in our operating assets and liabilities related primarily to an increase in accounts receivable of $29.4 million, an increase in inventories of $26.5 million, and a decrease in income tax, net of $20.2 million.

[0001628280-22-012157:mdna:155]
Cash provided by operating activities was $614.5 million during the nine months ended April 3, 2021, which reflects net income of $375.8 million and non-cash items of $258.8 million for the nine months ended April 3, 2021, offset by $20.1 million change in operating assets and liabilities. Changes in our operating assets and liabilities related primarily to an increase in inventories of $20.2 million and a decrease in accounts payable of $41.6 million, offset by an increase in income taxes, net of $28.2 million.

[0001628280-22-012157:mdna:156]
[same as prior period, unchanged from 0001628280-22-001745:mdna:145]

[0001628280-22-012157:mdna:157]
Cash used in investing activities of $369.0 million during the nine months ended April 2, 2022 was attributable to purchases of short-term investments, net of sales and maturities of $282.8 million, capital expenditures of $62.6 million, and a $30.0 million term loan provided to NeoPhotonics to support their on-going growth plans through the anticipated merger completion, partially offset by proceeds from the sales of property, plant and equipment of $6.4 million.  The term loan to NeoPhotonics is described in Note 1 - Description of Business and Summary of Significant Accounting Policies - Business Combinations.

[0001628280-22-012157:mdna:158]
Cash used in investing activities of $196.3 million during the nine months ended April 3, 2021 was primarily attributable to purchases of short-term investments, net of sales and maturities of $121.2 million, capital expenditures of $66.4 million, and payment for asset acquisition of $10.0 million.

[0001628280-22-012157:mdna:159]
[same as prior period, unchanged from 0001628280-22-001745:mdna:148]

[0001628280-22-012157:mdna:160]
Cash provided by financing activities of $380.0 million during the nine months ended April 2, 2022 resulted from the proceeds from the issuance of 0.50% Convertible Notes due 2028, net of issuance costs of $854.8 million and proceeds from employee stock plans of $6.6 million, partially offset by the repurchase of shares of our common stock of $448.6 million and tax payments related to net share settlement of restricted stock of $32.8 million.

[0001628280-22-012157:mdna:161]
Cash used in financing activities of $28.5  million during the nine months ended April 3, 2021 resulted primarily from tax payments related to net share settlement of restricted stock of $33.8 million, offset by the proceeds from employee stock plans of $5.5 million.
