# LITE 8-K — 0001628280-22-012145 filed 2022-05-04

## item codes, every 8-K on or before 2022-05-04

- 2022-05-04 0001628280-22-012145 — 2.02, 9.01
- 2022-03-08 0001193125-22-069350 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2022-02-03 0001628280-22-001736 — 2.02, 9.01
- 2022-01-21 0001193125-22-014413 — 8.01, 9.01
- 2021-11-23 0001628280-21-024070 — 5.02, 5.07
- 2021-11-05 0001193125-21-321796 — 1.01, 9.01
- 2021-11-04 0001628280-21-021618 — 2.02, 9.01
- 2021-11-04 0001193125-21-319601 — 8.01, 9.01
- 2021-08-18 0001628280-21-017219 — 2.02, 9.01
- 2021-06-08 0001633978-21-000030 — 5.02, 9.01
- 2021-05-12 0001633978-21-000008 — 2.02, 9.01
- 2021-03-10 0001193125-21-075438 — 1.01, 8.01, 9.01
- 2021-02-02 0001633978-21-000002 — 2.02, 9.01
- 2021-01-19 0001104659-21-005024 — 1.01, 2.02, 8.01, 9.01
- 2020-11-24 0001193125-20-302557 — 5.02, 5.07
- 2020-11-02 0001633978-20-000017 — 2.02, 9.01
- 2020-09-18 0001633978-20-000012 — 5.02, 9.01
- 2020-08-11 0001633978-20-000010 — 2.02, 9.01
- 2020-05-05 0001628280-20-006358 — 2.02, 9.01
- 2020-02-04 0001633978-20-000002 — 2.02, 9.01
- 2019-12-12 0001193125-19-312875 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2019-12-04 0001633978-19-000075 — 8.01
- 2019-11-20 0001633978-19-000074 — 5.07
- 2019-10-31 0001633978-19-000070 — 2.02, 9.01
- 2019-08-08 0001633978-19-000068 — 2.02, 9.01
- 2019-05-08 0001633978-19-000031 — 1.01
- 2019-05-07 0001633978-19-000029 — 2.02, 9.01
- 2019-02-15 0001633978-19-000005 — 9.01 — amendment of 0001193125-18-346211
- 2019-02-08 0001193125-19-031591 — 5.02, 9.01
- 2019-02-05 0001633978-19-000001 — 2.02, 9.01
- 2018-12-10 0001193125-18-346211 — 1.01, 2.01, 2.03, 5.02, 8.01, 9.01
- 2018-12-06 0001633978-18-000150 — 8.01
- 2018-11-14 0001633978-18-000139 — 5.07
- 2018-11-13 0001633978-18-000136 — 3.02
- 2018-11-13 0001633978-18-000132 — 7.01, 9.01
- 2018-11-01 0001628280-18-013238 — 2.02, 9.01
- 2018-08-08 0001633978-18-000056 — 2.02, 9.01
- 2018-06-08 0001193125-18-188241 — 5.02, 9.01
- 2018-05-02 0001633978-18-000029 — 2.02, 9.01
- 2018-03-12 0001193125-18-078154 — 1.01, 2.01, 8.01, 9.01
- 2018-02-06 0001628280-18-001082 — 2.02, 9.01
- 2017-11-08 0001633978-17-000133 — 5.02, 9.01
- 2017-11-07 0001633978-17-000131 — 5.07
- 2017-11-01 0001633978-17-000117 — 2.02, 9.01
- 2017-08-09 0001633978-17-000058 — 2.02, 9.01
- 2017-05-04 0001633978-17-000035 — 2.02, 9.01
- 2017-03-08 0001193125-17-074740 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2017-03-02 0001193125-17-066769 — 8.01, 9.01
- 2017-02-07 0001633978-17-000005 — 2.02, 9.01
- 2017-01-03 0001628280-17-000018 — 4.01, 9.01
- 2016-11-09 0001628280-16-021143 — 5.02, 5.07, 9.01
- 2016-10-27 0001628280-16-020382 — 2.02, 9.01
- 2016-08-09 0001628280-16-018811 — 2.02, 9.01
- 2016-06-21 0001628280-16-017201 — 8.01
- 2016-05-04 0001628280-16-015501 — 2.02, 9.01
- 2016-02-16 0001628280-16-011261 — 5.02, 9.01
- 2016-02-04 0001628280-16-010758 — 5.02, 9.01
- 2016-02-04 0001628280-16-010755 — 2.02, 9.01
- 2015-11-17 0001193125-15-378953 — 7.01
- 2015-11-10 0001628280-15-008606 — 2.02, 9.01
- 2015-09-28 0001193125-15-329665 — 8.01, 9.01
- 2015-08-11 0001193125-15-286405 — 7.01, 9.01
- 2015-08-06 0001193125-15-281219 — 1.01, 5.02, 5.03, 5.05, 8.01, 9.01
- 2015-08-03 0001193125-15-274808 — 5.03, 9.01

## late-filing notifications on or before 2022-05-04

- 2015-11-10 0001628280-15-008612 — NT 10-Q, for the period ended 2015-09-26
- 2015-09-28 0001193125-15-329672 — NT 10-K, for the period ended 2015-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001628280-22-012145:8k_2_02:1]
EX-99.1
2
lite_ex991xq3fy22.htm
EX-99.1

[0001628280-22-012145:8k_2_02:2]
Document

[0001628280-22-012145:8k_2_02:3]
NEWS RELEASE

[0001628280-22-012145:8k_2_02:4]
LUMENTUM ANNOUNCES FISCAL THIRD QUARTER 2022 FINANCIAL RESULTS

[0001628280-22-012145:8k_2_02:5]
•Net revenue of $395.4 million

[0001628280-22-012145:8k_2_02:6]
•GAAP gross margin of 42.3%; Non-GAAP gross margin of 49.5%

[0001628280-22-012145:8k_2_02:7]
•GAAP operating margin of 11.8%; Non-GAAP operating margin of 26.5%

[0001628280-22-012145:8k_2_02:8]
•GAAP diluted net income per share of $0.35; Non-GAAP diluted net income per share of $1.19

[0001628280-22-012145:8k_2_02:9]
San Jose, Calif., May 4, 2022 – Lumentum Holdings Inc. (“Lumentum” or the “Company”) today reported results for its fiscal third quarter ended April 2, 2022.

[0001628280-22-012145:8k_2_02:10]
“Our results were at the high end of our guidance on all metrics in the third quarter due to solid execution on a global basis,” said Alan Lowe, President and CEO.  “Demand for our products continues to accelerate, and we now expect demand to outpace component supplies by more than $100 million in the fourth quarter.  Our fourth quarter revenue is expected to increase from the third quarter, primarily driven by Telecom product shipments.”

[0001628280-22-012145:8k_2_02:11]
Mr. Lowe added, “I am highly optimistic about our outlook and believe market inflections beneficial to Lumentum in our addressable markets will drive double-digit revenue growth in fiscal 2023 and beyond.”

[0001628280-22-012145:8k_2_02:12]
Fiscal Third Quarter Highlights:

[0001628280-22-012145:8k_2_02:13]
Net revenue for the fiscal third quarter of 2022 was $395.4 million, with GAAP net income of $26.0 million, or $0.35 per diluted share. Net revenue for the fiscal second quarter of 2022 was $446.7 million, with GAAP net income of $56.7 million, or $0.75 per diluted share. Net revenue for the fiscal third quarter of 2021 was $419.5 million, with GAAP net income of $225.5 million, or $2.85 per diluted share.

[0001628280-22-012145:8k_2_02:14]
Non-GAAP net income for the fiscal third quarter of 2022 was $88.9 million, or $1.19 per diluted share. Non-GAAP net income for the fiscal second quarter of 2022 was $120.2 million, or $1.60 per diluted share. Non-GAAP net income for the fiscal third quarter of 2021 was $99.7 million, or $1.26 per diluted share.

[0001628280-22-012145:8k_2_02:15]
The Company held $2,564.1 million in total cash, cash equivalents, and short-term investments at the end of the fiscal third quarter of 2022, up $541.7 million from the end of the fiscal second quarter of 2022. In March 2022, we issued $861.0 million in aggregate principal amount of 0.50% Convertible Notes due in 2028 (“the 2028 Notes”). The net proceeds from the sale of the 2028 Notes were $854.1 million, after deducting $6.9 million in issuance costs. Concurrent with the issuance of the 2028 Notes, we used $200.0 million of the net proceeds to repurchase 2.0 million shares of our common stock in privately negotiated transactions.  Cash from operations for the fiscal third quarter of 2022 was $76.6 million.  Additionally, we used $124.0 million to repurchase 1.3 million shares of our common stock. We have repurchased 7.8 million shares over the last twelve months.  We have $513.5 million remaining under the board-authorized share buyback program.

[0001628280-22-012145:8k_2_02:16]
Financial Overview – Fiscal Third Quarter Ended April 2, 2022

[0001628280-22-012145:8k_2_02:17]
|  | GAAP Results ($ in millions) |
|  | Q3 |  | Q2 |  | Q3 |  | Change |
|  | FY 2022 |  | FY 2022 |  | FY 2021 |  | Q/Q |  | Y/Y |
| Net revenue | $395.4 |  | $446.7 |  | $419.5 |  | (11.5)% |  | (5.7)% |
| Gross margin | 42.3% |  | 46.5% |  | 44.1% |  | (420)bps |  | (180)bps |
| Operating margin | 11.8% |  | 19.1% |  | 63.6% |  | (730)bps |  | (5,180)bps |
|  | Non-GAAP Results ($ in millions) |
|  | Q3 |  | Q2 |  | Q3 |  | Change |
|  | FY 2022 |  | FY 2022 |  | FY 2021 |  | Q/Q |  | Y/Y |
| Net revenue | $395.4 |  | $446.7 |  | $419.5 |  | (11.5)% |  | (5.7)% |
| Gross margin | 49.5% |  | 51.0% |  | 49.9% |  | (150)bps |  | (40)bps |
| Operating margin | 26.5% |  | 31.7% |  | 27.9% |  | (520)bps |  | (140)bps |

[0001628280-22-012145:8k_2_02:18]
|  | Net Revenue by Segment ($ in millions) |
|  | Q3 |  | % of |  | Q2 |  | Q3 |  | Change |
|  | FY 2022 |  | Net Revenue |  | FY 2022 |  | FY 2021 |  | Q/Q |  | Y/Y |
| Optical Communications | $ | 344.2 |  |  | 87.1 | % |  | $ | 397.4 |  |  | $ | 387.9 |  |  | (13.4) | % |  | (11.3) | % |
| Lasers | 51.2 |  |  | 12.9 | % |  | 49.3 |  |  | 31.6 |  |  | 3.9 | % |  | 62.0 | % |
| Total | $ | 395.4 |  |  | 100.0 | % |  | $ | 446.7 |  |  | $ | 419.5 |  |  | (11.5) | % |  | (5.7) | % |

[0001628280-22-012145:8k_2_02:19]
The tables above provide comparisons of quarterly results to prior periods, including sequential quarterly and year-over-year changes. A reconciliation between GAAP and non-GAAP measures is contained in this release under the section titled “Use of Non-GAAP Financial Measures.”

[0001628280-22-012145:8k_2_02:20]
Business Outlook

[0001628280-22-012145:8k_2_02:21]
Lumentum expects the following for the fiscal fourth quarter 2022:

[0001628280-22-012145:8k_2_02:22]
•Net revenue in the range of $405 million to $430 million

[0001628280-22-012145:8k_2_02:23]
•Non-GAAP operating margin of 26.5% to 28.0%

[0001628280-22-012145:8k_2_02:24]
•Non-GAAP diluted earnings per share of $1.25 to $1.40

[0001628280-22-012145:8k_2_02:25]
We have not provided reconciliations from GAAP to non-GAAP measures for our outlook. A large portion of non-GAAP adjustments, such as restructuring charges, stock-based compensation, non-cash income tax expense and credits, integration and acquisition related costs, inventory write down due to plans to exit certain product lines and other costs and contingencies unrelated to current and future operations are by their nature highly volatile and we have low visibility as to the range that may be incurred in the future.

[0001628280-22-012145:8k_2_02:26]
Related Announcement and Conference Call

[0001628280-22-012145:8k_2_02:27]
Lumentum will host a conference call today, May 4, 2022, at 5:30 am PT / 8:30 am ET to discuss its fiscal third quarter results.  A live webcast of the call and the replay will be available in the Investors section of the Lumentum website at http://investor.lumentum.com through May 11, 2022, at 9:00 pm PT / 12:00 am ET. To listen to the live conference call, dial (844) 200-6205 or (929) 526-1599 and reference the passcode 546724. To access the replay, dial (866) 813-9403 or (929) 458-6194 and reference the passcode 113347. Supporting materials outlining the Company’s latest financial results will be posted on http://investor.lumentum.com under the “Events and Presentations” section concurrently with this earnings press release. Lumentum has used, and intends to continue to use, its Investor Relations website as means of disclosing material nonpublic information and for complying with its disclosure obligations under Regulation FD. This press release is being furnished as an exhibit to a Current Report on Form 8-K filed with the Securities and Exchange Commission and will be available at http://www.sec.gov/.

[0001628280-22-012145:8k_2_02:28]
About Lumentum

[0001628280-22-012145:8k_2_02:29]
Lumentum (NASDAQ: LITE) is a market-leading designer and manufacturer of innovative optical and photonic products enabling optical networking and laser applications worldwide. Lumentum optical components and subsystems are part of virtually every type of telecom, enterprise, and data center network. Lumentum lasers enable advanced manufacturing techniques and diverse applications including next-generation 3D sensing capabilities. Lumentum is headquartered in San Jose, California with R&D, manufacturing, and sales offices worldwide. For more information, visit www.lumentum.com and follow Lumentum on LinkedIn, Twitter, Facebook, Instagram and YouTube.

[0001628280-22-012145:8k_2_02:30]
Forward-Looking Statements

[0001628280-22-012145:8k_2_02:31]
Contact Information

[0001628280-22-012145:8k_2_02:32]
Investors:    Kathy Ta, 408-750-3853; investor.relations@lumentum.com

[0001628280-22-012145:8k_2_02:33]
Media:        Sean Ogarrio, 408-546-5405; media@lumentum.com

[0001628280-22-012145:8k_2_02:34]
Category:    Financial

[0001628280-22-012145:8k_2_02:35]
The following financial tables are presented in accordance with GAAP, unless otherwise specified.

[0001628280-22-012145:8k_2_02:36]
LUMENTUM HOLDINGS INC.

[0001628280-22-012145:8k_2_02:37]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001628280-22-012145:8k_2_02:38]
(in millions, except per share data)

[0001628280-22-012145:8k_2_02:39]
(unaudited)

[0001628280-22-012145:8k_2_02:40]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 2, 2022 |  | April 3, 2021 |  | April 2, 2022 |  | April 3, 2021 |
| Net revenue | $ | 395.4 |  |  | $ | 419.5 |  |  | $ | 1,290.5 |  |  | $ | 1,350.7 |  |
| Cost of sales | 212.6 |  |  | 218.7 |  |  | 636.3 |  |  | 684.6 |  |
| Amortization of acquired developed intangibles | 15.6 |  |  | 15.8 |  |  | 47.3 |  |  | 45.8 |  |
| Gross profit | 167.2 |  |  | 185.0 |  |  | 606.9 |  |  | 620.3 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 56.7 |  |  | 57.2 |  |  | 164.0 |  |  | 160.4 |  |
| Selling, general and administrative | 63.8 |  |  | 65.5 |  |  | 196.1 |  |  | 183.1 |  |
| Restructuring and related charges | (0.1) |  |  | 2.9 |  |  | (1.1) |  |  | 3.1 |  |
| Merger termination fee and related costs, net | — |  |  | (207.5) |  |  | — |  |  | (207.5) |  |
| Total operating expenses | 120.4 |  |  | (81.9) |  |  | 359.0 |  |  | 139.1 |  |
| Income from operations | 46.8 |  |  | 266.9 |  |  | 247.9 |  |  | 481.2 |  |
| Interest expense | (19.7) |  |  | (16.4) |  |  | (53.7) |  |  | (48.7) |  |
| Other income (expense), net | 2.2 |  |  | 2.4 |  |  | 3.8 |  |  | 2.1 |  |
| Income before income taxes | 29.3 |  |  | 252.9 |  |  | 198.0 |  |  | 434.6 |  |
| Provision for income taxes | 3.3 |  |  | 27.4 |  |  | 33.8 |  |  | 58.8 |  |
| Net income | $ | 26.0 |  |  | $ | 225.5 |  |  | $ | 164.2 |  |  | $ | 375.8 |  |
| Net income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.37 |  |  | $ | 2.97 |  |  | $ | 2.28 |  |  | $ | 4.97 |  |
| Diluted | $ | 0.35 |  |  | $ | 2.85 |  |  | $ | 2.19 |  |  | $ | 4.78 |  |
| Shares used to compute net income per share: |  |  |  |  |  |  |  |
| Basic | 71.0 |  |  | 75.8 |  |  | 72.0 |  |  | 75.6 |  |
| Diluted | 74.5 |  |  | 79.2 |  |  | 75.1 |  |  | 78.6 |  |

[0001628280-22-012145:8k_2_02:41]
LUMENTUM HOLDINGS INC.

[0001628280-22-012145:8k_2_02:42]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001628280-22-012145:8k_2_02:43]
(in millions, except per share data)

[0001628280-22-012145:8k_2_02:44]
(unaudited)

[0001628280-22-012145:8k_2_02:45]
|  | April 2, 2022 |  | July 3, 2021 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 1,130.3 |  |  | $ | 774.3 |  |
| Short-term investments | 1,433.8 |  |  | 1,171.7 |  |
| Accounts receivable, net | 242.2 |  |  | 212.8 |  |
| Inventories | 224.0 |  |  | 196.4 |  |
| Prepayments and other current assets | 70.3 |  |  | 81.6 |  |
| Total current assets | 3,100.6 |  |  | 2,436.8 |  |
| Property, plant and equipment, net | 356.4 |  |  | 361.1 |  |
| Operating lease right-of-use assets, net | 74.3 |  |  | 67.4 |  |
| Goodwill | 368.9 |  |  | 368.9 |  |
| Other intangible assets, net | 176.9 |  |  | 241.2 |  |
| Deferred tax asset | 19.7 |  |  | 72.9 |  |
| Other non-current assets | 36.7 |  |  | 3.3 |  |
| Total assets | $ | 4,133.5 |  |  | $ | 3,551.6 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 126.8 |  |  | $ | 116.9 |  |
| Accrued payroll and related expenses | 47.5 |  |  | 54.3 |  |
| Accrued expenses | 36.7 |  |  | 33.1 |  |
| Convertible notes, current | 406.1 |  |  | 390.7 |  |
| Operating lease liabilities, current | 12.0 |  |  | 11.8 |  |
| Other current liabilities | 31.6 |  |  | 57.8 |  |
| Total current liabilities | 660.7 |  |  | 664.6 |  |
| Convertible notes, non-current | 1,447.6 |  |  | 789.8 |  |
| Operating lease liabilities, non-current | 52.8 |  |  | 47.6 |  |
| Deferred tax liability | 17.5 |  |  | 35.9 |  |
| Other non-current liabilities | 42.8 |  |  | 40.9 |  |
| Total liabilities | 2,221.4 |  |  | 1,578.8 |  |
| Stockholders’ equity: |  |  |  |
| Common stock, $0.001 par value, 990 authorized shares, 69.1 and 73.0 shares issued and outstanding as of April 2, 2022 and July 3, 2021, respectively | 0.1 |  |  | 0.1 |  |
| Additional paid-in capital | 1,973.7 |  |  | 1,743.6 |  |
| Retained earnings (accumulated deficit) | (60.5) |  |  | 220.9 |  |
| Accumulated other comprehensive income (loss) | (1.2) |  |  | 8.2 |  |
| Total stockholders’ equity | 1,912.1 |  |  | 1,972.8 |  |
| Total liabilities and stockholders’ equity | $ | 4,133.5 |  |  | $ | 3,551.6 |  |

[0001628280-22-012145:8k_2_02:46]
Use of Non-GAAP Financial Measures

[0001628280-22-012145:8k_2_02:47]
In this press release, Lumentum provides investors with certain non-GAAP financial measures: gross profit, gross margin, research and development expense, selling, general and administrative expense, operating margin, income from operations, interest and other income (expense), net, income before income taxes, provision for income taxes, net income, and net income per share on a non-GAAP basis, as well as the non-GAAP measures of EBITDA and Adjusted EBITDA. Lumentum believes this non-GAAP financial information provides additional insight into the Company’s ongoing business operations and results, as well as cash generation, and has therefore chosen to provide this information to investors for a more consistent basis of comparison and to help them evaluate the results of the Company’s ongoing operations and enable more meaningful period to period comparisons. In addition, the Company believes that providing certain of these measures allows investors to better understand the Company’s cash flows and, importantly, to evaluate the efficacy of the methodology and information used by management to evaluate and measure such cash flows. However, these measures may be different from non-GAAP measures used by other companies, limiting their usefulness for comparison purposes. The non-GAAP financial measures used in this press release should not be considered in isolation from measures of financial performance prepared in accordance with GAAP. Investors are cautioned that there are material limitations associated with the use of non-GAAP financial measures as an analytical tool. In particular, many of the adjustments to our GAAP financial measures reflect the exclusion of items that are recurring and will be reflected in our financial results for the foreseeable future. Further, these non-GAAP financial measures may not be comparable to similarly titled measurements reported by other companies.

[0001628280-22-012145:8k_2_02:48]
Our non-GAAP measures used in this press release exclude (i) stock-based compensation, (ii) gain on sale of product lines, (iii) integration related costs, (iv) inventory and fixed asset write down due to product line exits, (v) amortization of acquired intangibles, (vi) restructuring and related charges, (vii) merger termination fee related to our terminated Agreement with Coherent, (viii) foreign exchange (gains) losses, net, (ix) non-cash interest expense on convertible notes, (x) income tax impacts, and (xi) other (gains) charges related to non-recurring activities.

[0001628280-22-012145:8k_2_02:49]
A quantitative reconciliation between GAAP and non-GAAP financial data with respect to historical periods is included in the supplemental financial table attached to this press release.

[0001628280-22-012145:8k_2_02:50]
LUMENTUM HOLDINGS INC.

[0001628280-22-012145:8k_2_02:51]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001628280-22-012145:8k_2_02:52]
(in millions, except per share data)

[0001628280-22-012145:8k_2_02:53]
(unaudited)

[0001628280-22-012145:8k_2_02:54]
|  | Three Months Ended |  |  | Nine Months Ended |  |
|  | April 2, 2022 |  | January 1, 2022 |  | April 3, 2021 |  |  | April 2, 2022 |  | April 3, 2021 |  |
| Gross profit on GAAP basis | $ | 167.2 |  |  | $ | 207.5 |  |  | $ | 185.0 |  |  |  | $ | 606.9 |  |  | $ | 620.3 |  |  |
| Stock-based compensation | 5.4 |  |  | 5.2 |  |  | 5.3 |  |  |  | 15.2 |  |  | 13.8 |  |  |
| Inventory and fixed asset write down due to product line exits | — |  |  | 0.1 |  |  | — |  |  |  | 0.1 |  |  | 0.4 |  |  |
| Amortization of acquired intangibles | 15.6 |  |  | 15.9 |  |  | 15.8 |  |  |  | 47.3 |  |  | 45.8 |  |  |
| Other (gains) charges (1) | 7.4 |  |  | (0.7) |  |  | 3.1 |  |  |  | 0.8 |  |  | 20.0 |  |  |
| Gross profit on non-GAAP basis | $ | 195.6 |  |  | $ | 228.0 |  |  | $ | 209.2 |  |  |  | $ | 670.3 |  |  | $ | 700.3 |  |  |
| Gross margin on non-GAAP basis | 49.5 | % |  | 51.0 | % |  | 49.9 | % |  |  | 51.9 | % |  | 51.8 | % |  |
| Research and development on GAAP basis | $ | 56.7 |  |  | $ | 53.2 |  |  | $ | 57.2 |  |  |  | $ | 164.0 |  |  | $ | 160.4 |  |  |
| Stock-based compensation | (5.4) |  |  | (5.4) |  |  | (5.3) |  |  |  | (15.8) |  |  | (14.8) |  |  |
| Other gains (charges) | (0.6) |  |  | — |  |  | (0.6) |  |  |  | (0.7) |  |  | (0.6) |  |  |
| Research and development on non-GAAP basis | $ | 50.7 |  |  | $ | 47.8 |  |  | $ | 51.3 |  |  |  | $ | 147.5 |  |  | $ | 145.0 |  |  |
| Selling, general and administrative on GAAP basis | $ | 63.8 |  |  | $ | 69.0 |  |  | $ | 65.5 |  |  |  | $ | 196.1 |  |  | $ | 183.1 |  |  |
| Stock-based compensation | (12.5) |  |  | (16.7) |  |  | (14.5) |  |  |  | (44.4) |  |  | (40.1) |  |  |
| Integration related costs | — |  |  | — |  |  | (0.2) |  |  |  | — |  |  | (0.7) |  |  |
| Amortization of acquired intangibles | (5.8) |  |  | (5.6) |  |  | (6.2) |  |  |  | (17.0) |  |  | (17.8) |  |  |
| Other gains (charges) (2) | (5.5) |  |  | (8.1) |  |  | (3.8) |  |  |  | (17.3) |  |  | (8.7) |  |  |
| Selling, general and administrative on non-GAAP basis | $ | 40.0 |  |  | $ | 38.6 |  |  | $ | 40.8 |  |  |  | $ | 117.4 |  |  | $ | 115.8 |  |  |
| Income from operations on GAAP basis | $ | 46.8 |  |  | $ | 85.2 |  |  | $ | 266.9 |  |  |  | $ | 247.9 |  |  | $ | 481.2 |  |  |
| Stock-based compensation | 23.3 |  |  | 27.3 |  |  | 25.1 |  |  |  | 75.4 |  |  | 68.7 |  |  |
| Inventory and fixed asset write down due to product line exits | — |  |  | 0.1 |  |  | — |  |  |  | 0.1 |  |  | 0.4 |  |  |
| Integration related costs | — |  |  | — |  |  | 0.2 |  |  |  | — |  |  | 0.7 |  |  |
| Amortization of acquired intangibles | 21.4 |  |  | 21.5 |  |  | 22.0 |  |  |  | 64.3 |  |  | 63.6 |  |  |
| Restructuring and related charges | (0.1) |  |  | 0.1 |  |  | 2.9 |  |  |  | (1.1) |  |  | 3.1 |  |  |
| Merger termination fee and related costs, net | — |  |  | — |  |  | (207.5) |  |  |  | — |  |  | (207.5) |  |  |
| Other (gains) charges (1) (2) | 13.5 |  |  | 7.4 |  |  | 7.5 |  |  |  | 18.8 |  |  | 29.3 |  |  |
| Income from operations on non-GAAP basis | $ | 104.9 |  |  | $ | 141.6 |  |  | $ | 117.1 |  |  |  | $ | 405.4 |  |  | $ | 439.5 |  |  |
| Operating margin on non-GAAP basis | 26.5 | % |  | 31.7 | % |  | 27.9 | % |  |  | 31.4 | % |  | 32.5 | % |  |
| Interest and other expense, net on GAAP basis | $ | (17.5) |  |  | $ | (16.1) |  |  | $ | (14.0) |  |  |  | $ | (49.9) |  |  | $ | (46.6) |  |  |
| Gain on sale of product lines | — |  |  | — |  |  | — |  |  |  | — |  |  | (0.5) |  |  |
| Foreign exchange (gains) losses, net | (1.1) |  |  | (0.7) |  |  | (1.3) |  |  |  | (1.7) |  |  | 3.8 |  |  |
| Non-cash interest expense on convertible notes and other expenses | 17.7 |  |  | 15.8 |  |  | 14.8 |  |  |  | 48.8 |  |  | 43.9 |  |  |
| Interest and other income (expense), net on non-GAAP basis | $ | (0.9) |  |  | $ | (1.0) |  |  | $ | (0.5) |  |  |  | $ | (2.8) |  |  | $ | 0.6 |  |  |

[0001628280-22-012145:8k_2_02:55]
| Income before income taxes on GAAP basis | $ | 29.3 |  |  | $ | 69.1 |  |  | $ | 252.9 |  |  |  | $ | 198.0 |  |  | $ | 434.6 |  |  |
| Stock-based compensation | 23.3 |  |  | 27.3 |  |  | 25.1 |  |  |  | 75.4 |  |  | 68.7 |  |  |
| Inventory and fixed asset write down due to product line exits | — |  |  | 0.1 |  |  | — |  |  |  | 0.1 |  |  | 0.4 |  |  |
| Integration related costs | — |  |  | — |  |  | 0.2 |  |  |  | — |  |  | 0.7 |  |  |
| Amortization of acquired intangibles | 21.4 |  |  | 21.5 |  |  | 22.0 |  |  |  | 64.3 |  |  | 63.6 |  |  |
| Restructuring and related charges | (0.1) |  |  | 0.1 |  |  | 2.9 |  |  |  | (1.1) |  |  | 3.1 |  |  |
| Merger termination fee and related costs, net | — |  |  | — |  |  | (207.5) |  |  |  | — |  |  | (207.5) |  |  |
| Gain on sale of product lines | — |  |  | — |  |  | — |  |  |  | — |  |  | (0.5) |  |  |
| Foreign exchange (gains) losses, net | (1.1) |  |  | (0.7) |  |  | (1.3) |  |  |  | (1.7) |  |  | 3.8 |  |  |
| Non-cash interest expense on convertible notes and other expenses | 17.7 |  |  | 15.8 |  |  | 14.8 |  |  |  | 48.8 |  |  | 43.9 |  |  |
| Other (gains) charges (1) (2) | 13.5 |  |  | 7.4 |  |  | 7.5 |  |  |  | 18.8 |  |  | 29.3 |  |  |
| Income before income taxes on non-GAAP basis | $ | 104.0 |  |  | $ | 140.6 |  |  | $ | 116.6 |  |  |  | $ | 402.6 |  |  | $ | 440.1 |  |  |
| Provision for income taxes on GAAP basis | $ | 3.3 |  |  | $ | 12.4 |  |  | $ | 27.4 |  |  |  | $ | 33.8 |  |  | $ | 58.8 |  |  |
| Income tax adjustments (3) | 11.8 |  |  | 8.0 |  |  | (10.5) |  |  |  | 24.6 |  |  | 5.0 |  |  |
| Provision for income taxes on non-GAAP basis | $ | 15.1 |  |  | $ | 20.4 |  |  | $ | 16.9 |  |  |  | $ | 58.4 |  |  | $ | 63.8 |  |  |
| Net income on GAAP basis | $ | 26.0 |  |  | $ | 56.7 |  |  | $ | 225.5 |  |  |  | $ | 164.2 |  |  | $ | 375.8 |  |  |
| Stock-based compensation | 23.3 |  |  | 27.3 |  |  | 25.1 |  |  |  | 75.4 |  |  | 68.7 |  |  |
| Inventory and fixed asset write down due to product line exits | — |  |  | 0.1 |  |  | — |  |  |  | 0.1 |  |  | 0.4 |  |  |
| Integration related costs | — |  |  | — |  |  | 0.2 |  |  |  | — |  |  | 0.7 |  |  |
| Amortization of acquired intangibles | 21.4 |  |  | 21.5 |  |  | 22.0 |  |  |  | 64.3 |  |  | 63.6 |  |  |
| Restructuring and related charges | (0.1) |  |  | 0.1 |  |  | 2.9 |  |  |  | (1.1) |  |  | 3.1 |  |  |
| Merger termination fee and related costs, net | — |  |  | — |  |  | (207.5) |  |  |  | — |  |  | (207.5) |  |  |
| Gain on sale of product lines | — |  |  | — |  |  | — |  |  |  | — |  |  | (0.5) |  |  |
| Foreign exchange (gains) losses, net | (1.1) |  |  | (0.7) |  |  | (1.3) |  |  |  | (1.7) |  |  | 3.8 |  |  |
| Non-cash interest expense on convertible notes and other expenses | 17.7 |  |  | 15.8 |  |  | 14.8 |  |  |  | 48.8 |  |  | 43.9 |  |  |
| Income tax adjustments (3) | (11.8) |  |  | (8.0) |  |  | 10.5 |  |  |  | (24.6) |  |  | (5.0) |  |  |
| Other (gains) charges (1) (2) | 13.5 |  |  | 7.4 |  |  | 7.5 |  |  |  | 18.8 |  |  | 29.3 |  |  |
| Net income on non-GAAP basis | $ | 88.9 |  |  | $ | 120.2 |  |  | $ | 99.7 |  |  |  | $ | 344.2 |  |  | $ | 376.3 |  |  |
| Net income per share on non-GAAP basis | $ | 1.19 |  |  | $ | 1.60 |  |  | $ | 1.26 |  |  |  | $ | 4.58 |  |  | $ | 4.79 |  |  |
| Shares used in per share calculation - diluted on non-GAAP basis | 74.5 |  |  | 75.3 |  |  | 79.2 |  |  |  | 75.1 |  |  | 78.6 |  |  |

[0001628280-22-012145:8k_2_02:56]
(1) Other (gains) charges excluded from gross profit for the three months ended April 2, 2022 primarily relate to $5.8 million of charges to acquire components from various brokers to satisfy customer demand.

[0001628280-22-012145:8k_2_02:57]
Other (gains) charges excluded from gross profit for the nine months ended April 2, 2022 primarily relate to a $5.9 million gain  from equipment sales in connection with transferring product lines to new production facilities offset by $5.8 million of charges to acquire components from various brokers to satisfy customer demand.

[0001628280-22-012145:8k_2_02:58]
(2) Other charges excluded from selling, general and administrative expense for the three months ended April 2, 2022 primarily include $1.2 million of legal and advisory fees related to the pending acquisition of NeoPhotonics and $3.1 million of professional service fees related to optimizing our international legal structure.

[0001628280-22-012145:8k_2_02:59]
Other charges excluded from selling, general and administrative expense for the nine months ended April 2, 2022 primarily include $6.7 million of legal and advisory fees related to the pending acquisition of NeoPhotonics and $6.6 million of professional service fees related to optimizing our international legal structure.

[0001628280-22-012145:8k_2_02:60]
(3) In order to give a more meaningful perspective of our tax burden over a longer-term period, and in accordance with the SEC Non-GAAP Financial Measures Compliance  and  Disclosure  Interpretations,  beginning  in fiscal  fourth  quarter 2021,  Lumentum  changed  its  method  of  calculating  its  non-GAAP income  tax provision.  This change in methodology does not affect the Company’s non-GAAP operating profit, annual cash tax payments, or cash flows, but results in higher reported non-GAAP tax provisions. As such, income tax adjustments have been revised for the three and nine months ended April 3, 2021 in order to be comparable.

[0001628280-22-012145:8k_2_02:61]
LUMENTUM HOLDINGS INC.

[0001628280-22-012145:8k_2_02:62]
RECONCILIATION OF GAAP NET INCOME TO ADJUSTED EBITDA

[0001628280-22-012145:8k_2_02:63]
(in millions, except per share data)

[0001628280-22-012145:8k_2_02:64]
(unaudited)

[0001628280-22-012145:8k_2_02:65]
|  | Three Months Ended |  | Nine Months Ended |  |  |
|  | April 2, 2022 |  |  |  | January 1, 2022 |  | April 3, 2021 |  | April 2, 2022 |  | April 3, 2021 |  |  |  |  |
| GAAP Net income | $ | 26.0 |  |  |  |  | $ | 56.7 |  |  | $ | 225.5 |  |  | $ | 164.2 |  |  | $ | 375.8 |  |  |  |  |  |
| Interest and other expense, net | 17.5 |  |  |  |  | 16.1 |  |  | 14.0 |  |  | 49.9 |  |  | 46.6 |  |  |  |  |  |
| Provision for income taxes | 3.3 |  |  |  |  | 12.4 |  |  | 27.4 |  |  | 33.8 |  |  | 58.8 |  |  |  |  |  |
| Depreciation | 20.2 |  |  |  |  | 20.6 |  |  | 22.8 |  |  | 61.2 |  |  | 70.4 |  |  |  |  |  |
| Amortization of acquired intangibles | 21.4 |  |  |  |  | 21.5 |  |  | 22.0 |  |  | 64.3 |  |  | 63.6 |  |  |  |  |  |
| EBITDA | 88.4 |  |  |  |  | 127.3 |  |  | 311.7 |  |  | 373.4 |  |  | 615.2 |  |  |  |  |  |
| Restructuring and related charges | (0.1) |  |  |  |  | 0.1 |  |  | 2.9 |  |  | (1.1) |  |  | 3.1 |  |  |  |  |  |
| Stock-based compensation | 23.3 |  |  |  |  | 27.3 |  |  | 25.1 |  |  | 75.4 |  |  | 68.7 |  |  |  |  |  |
| Inventory and fixed asset write down due to product line exits | — |  |  |  |  | 0.1 |  |  | — |  |  | 0.1 |  |  | 0.4 |  |  |  |  |  |
| Integration related costs | — |  |  |  |  | — |  |  | 0.2 |  |  | — |  |  | 0.7 |  |  |  |  |  |
| Merger termination fee and related costs, net | — |  |  |  |  | — |  |  | (207.5) |  |  | — |  |  | (207.5) |  |  |  |  |  |
| Other (gains) charges | 13.5 |  |  |  |  | 7.6 |  |  | 5.9 |  |  | 18.8 |  |  | 22.9 |  |  |  |  |  |
| Adjusted EBITDA | $ | 125.1 |  |  |  |  | $ | 162.4 |  |  | $ | 138.3 |  |  | $ | 466.6 |  |  | $ | 503.5 |  |  |  |  |  |
