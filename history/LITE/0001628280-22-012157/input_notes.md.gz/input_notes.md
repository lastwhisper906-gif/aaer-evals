# LITE notes — 0001628280-22-012157


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001628280-22-012157:notes:1]
[same as prior period, unchanged from 0001628280-22-001745:notes:1]

[0001628280-22-012157:notes:2]
[same as prior period, unchanged from 0001628280-22-001745:notes:2]

[0001628280-22-012157:notes:3]
Lumentum Holdings Inc. (“we,” “us,” “our”, “Lumentum” or the “Company”) is an industry-leading provider of optical and photonic products defined by revenue and market share addressing a range of end market applications including Optical Communications (“OpComms”) and Commercial Lasers (“Lasers”) for manufacturing, inspection and life-science applications. We seek to use our core optical and photonic technology, and our volume manufacturing capability, to expand into attractive emerging markets that benefit from advantages that optical or photonics-based solutions provide, including 3D sensing for consumer electronics and diode light sources for a variety of consumer and industrial applications. The majority of our customers tend to be original equipment manufacturers (“OEMs”) that incorporate our products into their products which then address end-market applications. For example, we sell fiber optic components that network equipment manufacturers (“NEMs”) assemble into communications networking systems, which they sell to communications service providers, hyperscale cloud operators, and enterprises with their own networks. Similarly, many of our Lasers products customers incorporate our products into tools they produce, which are used for manufacturing processes by their customers. For 3D sensing, we sell diode lasers to manufacturers of consumer electronics products for mobile, personal computing, gaming, and other applications, including to the automotive industry, who then integrate our devices within their products, for eventual resale to consumers and also into other industrial applications.

[0001628280-22-012157:notes:4]
[same as prior period, unchanged from 0001628280-22-001745:notes:4]

[0001628280-22-012157:notes:5]
The accompanying condensed consolidated financial statements have been prepared in accordance with U.S. generally accepted accounting principles (“GAAP”), which requires management to make estimates and assumptions that affect the amounts reported in our condensed consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact us in the future, actual results may be different from the estimates. Operating results for the quarter ended April 2, 2022 are not necessarily indicative of the results that may be expected for the fiscal year ending July 2, 2022. In the opinion of the Company’s management, the information presented herein reflects all normal and recurring adjustments necessary for a fair presentation of our results of operations, financial position, stockholders’ equity and cash flows.

[0001628280-22-012157:notes:6]
[same as prior period, unchanged from 0001628280-22-001745:notes:6]

[0001628280-22-012157:notes:7]
We are now in the third year of the COVID-19 pandemic, and while the impact of the pandemic is lessening, new variants are causing continued concern. As these variants continue to emerge, efforts to mitigate or contain the impacts of the pandemic continue to evolve, and the duration and severity of the impact of the pandemic on our business and results of operations in future periods remain uncertain. The extent of the impact of COVID-19 on our operational and financial performance will depend on certain developments, including but not limited to the duration and spread of the pandemic and its variants, duration of local, state and federal issued public health orders in each jurisdiction where we operate or in which our customers and suppliers operate, impact on our customers and our sales cycles, impact on our supply chain and manufacturing partners, impact on our employees and impact on regional and worldwide economies and financial markets in general, all of which are uncertain and cannot be predicted. We assessed the potential impact that this pandemic has on our estimates as of April 2, 2022 and determined that there were no material impacts. However, due to the global supply chain constraint, we have had to incur incremental supply and procurement costs in order to fulfill demand from our customers. These higher costs have increased our inventory balances as of April 2, 2022 and may decrease our gross margin in the near term.

[0001628280-22-012157:notes:8]
We are also continuously monitoring developments in the ongoing conflict between Russia and Ukraine including the related export controls and resulting sanctions imposed on Russia by the U.S. and other countries.  Additional factors such as increased inflation, escalating energy costs, constrained raw material availability, and thus increasing costs could impact the global economy.  Although the global implications of the Russian/Ukraine conflict are difficult to predict at this time, we do not presently foresee direct material adverse effects upon our business.

[0001628280-22-012157:notes:9]
[same as prior period, unchanged from 0001628280-22-001745:notes:8]

[0001628280-22-012157:notes:10]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Every fifth or sixth fiscal year will have a 53-week period. The additional week in a 53-week year is added to the third quarter, making such quarter consist of 14 weeks. Our fiscal 2022 is a 52-week year ending on July 2, 2022, with the quarter ended April 2, 2022 being a 13-week quarterly period. Our fiscal 2021 was a 53-week year that ended on July 3, 2021, with the quarter ended April 3, 2021 being a 14-week quarterly period.

[0001628280-22-012157:notes:11]
[same as prior period, unchanged from 0001628280-22-001745:notes:10]

[0001628280-22-012157:notes:12]
[same as prior period, unchanged from 0001628280-22-001745:notes:11]

[0001628280-22-012157:notes:13]
Certain prior period amounts have been reclassified to conform to the current period presentation. The reclassification of the prior period amounts did not impact previously reported condensed consolidated financial statements.

[0001628280-22-012157:notes:14]
[same as prior period, unchanged from 0001628280-22-001745:notes:12]

[0001628280-22-012157:notes:15]
The condensed consolidated financial statements and accompanying related notes should be read in conjunction with the audited consolidated financial statements and related notes included in our Annual Report on Form 10-K for the fiscal year ended July 3, 2021. There have been no significant changes to our accounting policies during the three and nine months ended April 2, 2022.

[0001628280-22-012157:notes:16]
[same as prior period, unchanged from 0001628280-22-001745:notes:14]

[0001628280-22-012157:notes:17]
On November 4, 2021, Lumentum and NeoPhotonics Corporation (“NeoPhotonics”) announced a merger agreement (the “Merger Agreement”) pursuant to which Lumentum will acquire all outstanding shares of NeoPhotonics stock. Under the terms of the Merger Agreement, NeoPhotonics stockholders will receive $16.00 per share in cash for each NeoPhotonics share they own. As of April 2, 2022, the estimated total transaction consideration is expected to be approximately $918 million.  The cash consideration will be funded from the combined company’s balance sheet.

[0001628280-22-012157:notes:18]
The Merger Agreement contains certain termination rights for both Lumentum and NeoPhotonics and provides that upon termination of the Merger Agreement under specified circumstances (including termination by NeoPhotonics to accept a superior proposal), NeoPhotonics may be required to pay Lumentum a termination fee of $27.5 million. The Merger Agreement further provides that if the Merger Agreement is terminated for failure to obtain antitrust approval, Lumentum may be required to pay NeoPhotonics a termination fee of $55.1 million; and if Lumentum takes certain specified actions, (including entering into any definitive agreement for an acquisition by stock purchase, merger, consolidation, amalgamation, purchase of assets, license or otherwise of any ownership interest or assets of any Person) that cause a material delay in, or results in the failure of, the consummation of the Merger, Lumentum may be required to pay NeoPhotonics an additional termination fee of $36.7 million.

[0001628280-22-012157:notes:19]
The Boards of Directors of Lumentum and NeoPhotonics have unanimously approved the transaction and the Merger Agreement. On January 21, 2022, the waiting period under the Hart-Scott-Rodino Antitrust Improvements Act of 1976, as amended, expired with respect to the proposed acquisition. The transaction is subject to customary closing conditions, including the absence of certain legal impediments and receipt of any required antitrust and regulatory approvals. The transaction was approved by the NeoPhotonics stockholders on February 1, 2022. The transaction is not subject to any financing condition. We expect this transaction to be completed in the second half of calendar year 2022.

[0001628280-22-012157:notes:20]
In connection with the Merger Agreement, on January 14, 2022, Lumentum and NeoPhotonics entered into a credit agreement where Lumentum agreed to make term loans (“loans”) to NeoPhotonics in an aggregate principal amount not to exceed $50.0 million to help fund capital expenditures and increased working capital associated with NeoPhotonics’ growth plans. During the three months ended April 2, 2022, the Company funded a $30.0 million loan request to NeoPhotonics, which bears interest at the Wall Street Journal “prime rate,” which was 3.5% as of April 2, 2022. The interest is payable monthly in arrears on the first day of each month. The loans will mature on January 14, 2024 unless earlier repaid or accelerated.

[0001628280-22-012157:notes:21]
Termination of Coherent Merger Agreement

[0001628280-22-012157:notes:22]
On January 18, 2021, Lumentum and Coherent, Inc. (“Coherent”) entered into a merger agreement, under which Lumentum would acquire all outstanding shares of Coherent common stock. As of the date of the merger agreement, the total transaction consideration was approximately $5.7 billion. In March 2021, Coherent terminated the merger agreement and paid 
Lumentum a termination fee of $217.6 million in accordance with the merger agreement. This gain was offset by $10.1 million of acquisition related expenses and the net amount is presented as “merger termination fee and related costs, net” in our condensed consolidated statements of operations for the three and nine months ended April 3, 2021.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001628280-22-012157:notes:23]
Note 2. Recently Issued Accounting Pronouncements

[0001628280-22-012157:notes:24]
Accounting Pronouncements Recently Adopted

[0001628280-22-012157:notes:25]
In December 2019, the Financial Accounting Standard Board (“FASB”) issued Accounting Standards Update (“ASU”) 2019-12, Simplifying the Accounting for Income Taxes (Topic 740), which is intended to simplify various aspects related to accounting for income taxes by removing certain exceptions to the general principles in Topic 740 and which also clarifies and amends existing guidance to improve consistent application. ASU 2019-12 was effective for us at the beginning of fiscal year 2022, including interim periods within that reporting period. We adopted ASU 2019-12 in our first quarter of fiscal year 2022 on a prospective basis with no material impact to our condensed consolidated financial statements.

[0001628280-22-012157:notes:26]
Accounting Pronouncements Not Yet Effective

[0001628280-22-012157:notes:27]
In October 2021, the FASB issued ASU 2021-08, Business Combinations (Topic 805)—Accounting for Contract Assets and Contract Liabilities from Contracts with Customers. This ASU clarifies that an acquirer of a business should recognize and measure contract assets and contract liabilities in a business combination in accordance with Accounting Standards Codification (“ASC”) Topic 606, Revenue from Contracts with Customers. This ASU is expected to improve comparability for both the recognition and measurement of acquired revenue contracts with customers at the date of and after a business combination. The new guidance is effective for fiscal years beginning after December 15, 2022, with early adoption permitted. ASU 2021-08 is effective for us in our first quarter of fiscal year 2024.  The impact of the adoption of ASU 2021-08 will depend on the contract assets and liabilities acquired in a business combination after that date, unless early adopted.

[0001628280-22-012157:notes:28]
In August 2020, FASB issued ASU 2020-06, Debt—Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging—Contracts in Entity’s Own Equity (Subtopic 815-40): Accounting for Convertible Instruments and Contracts in an Entity’s Own Equity, which simplifies the accounting for convertible instruments by removing the separation models for (i) convertible debt with a cash conversion feature and (ii) convertible instruments with a beneficial conversion feature. As a result, a convertible debt instrument will be accounted for as a single liability measured at its amortized cost. Also, ASU 2020-06 requires the application of the if-converted method for calculating diluted earnings per share and the treasury stock method will be no longer available. The new guidance is effective for fiscal years beginning after December 15, 2021, with early adoption permitted no earlier than fiscal years beginning after December 15, 2020. ASU 2020-06 is effective for us in our first quarter of fiscal year 2023. We intend to adopt ASU 2020-06 on a modified retrospective basis. ASU 2020-06 will impact our accounting treatment for our convertible notes (as defined in Note 9). We currently separate our convertible notes into their liability and equity components. Following our adoption of ASU 2020-06, the previously bifurcated equity component may be recombined with the liability component, resulting in a single liability classified instrument. The carrying value of our convertible notes at transition will be determined by recalculating the basis of the convertible notes as if the convertible notes had not been bifurcated at issuance. Issuance costs related to the convertible notes that was initially allocated to the equity component will be reclassified from additional paid-in capital to the liability component, and the amortization of the debt issuance and debt discount will be recalculated through the transition date. The adoption of this guidance will result in a reduction in our additional paid-in capital, an increase in our convertible note liability balance, and a reduction to our accumulated deficit as of the transition date.  In addition, we estimate that our diluted share count will increase and interest expense will decrease upon adoption of this standard.


## us-gaap:EarningsPerShareTextBlock

[0001628280-22-012157:notes:29]
[same as prior period, unchanged from 0001628280-22-001745:notes:24]

[0001628280-22-012157:notes:30]
[same as prior period, unchanged from 0001628280-22-001745:notes:25]

[0001628280-22-012157:notes:31]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 2, 2022 |  | April 3, 2021 |  | April 2, 2022 |  | April 3, 2021 |  |
| Numerator: |  |  |  |  |  |  |  |  |
| Net income - basic and diluted | $ | 26.0 |  |  | $ | 225.5 |  |  | $ | 164.2 |  |  | $ | 375.8 |  |  |
| Denominator: |  |  |  |  |  |  |  |  |
| Weighted average common shares outstanding - basic | 71.0 |  |  | 75.8 |  |  | 72.0 |  |  | 75.6 |  |  |
| Effect of dilutive securities from stock-based benefit plans | 0.7 |  |  | 0.8 |  |  | 0.6 |  |  | 0.8 |  |  |
| Shares issuable assuming conversion of the 2024 Notes | 2.8 |  |  | 2.6 |  |  | 2.5 |  |  | 2.2 |  |  |
| Weighted average common shares outstanding - diluted | 74.5 |  |  | 79.2 |  |  | 75.1 |  |  | 78.6 |  |  |
| Net income per share: |  |  |  |  |  |  |  |  |
| Basic | $ | 0.37 |  |  | $ | 2.97 |  |  | $ | 2.28 |  |  | $ | 4.97 |  |  |
| Diluted | $ | 0.35 |  |  | $ | 2.85 |  |  | $ | 2.19 |  |  | $ | 4.78 |  |  |

[0001628280-22-012157:notes:32]
[same as prior period, unchanged from 0001628280-22-001745:notes:27]

[0001628280-22-012157:notes:33]
[same as prior period, unchanged from 0001628280-22-001745:notes:28]

[0001628280-22-012157:notes:34]
•The 2026 Notes and the 2028 Notes will have no impact on diluted earnings per share until the average price of our common stock exceeds the conversion price of $99.29 and $131.03, respectively.

[0001628280-22-012157:notes:35]
•The potentially dilutive shares resulting from the 2024 Notes were included in the calculation of diluted income per share for the three and nine months ended April 2, 2022 and April 3, 2021, respectively, since the average price of our common stock exceeded the conversion price of $60.62 in all periods.

[0001628280-22-012157:notes:36]
Anti-dilutive potential shares are excluded from the calculation of diluted earnings per share if their exercise price exceeded the average market price during the period or the share-based awards were determined to be anti-dilutive based on applying the treasury stock method. Anti-dilutive shares excluded from the calculation of diluted earnings per share were less than 0.1 million for each of the three and nine months ended April 2, 2022. Anti-dilutive shares excluded from the calculation of diluted earnings per share were less than 0.1 million and 0.5 million shares for the three and nine months ended April 3, 2021, respectively.


## us-gaap:CashCashEquivalentsAndShortTermInvestmentsTextBlock

[0001628280-22-012157:notes:37]
[same as prior period, unchanged from 0001628280-22-001745:notes:32]

[0001628280-22-012157:notes:38]
[same as prior period, unchanged from 0001628280-22-001745:notes:33]

[0001628280-22-012157:notes:39]
|  | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| April 2, 2022: |  |  |  |  |  |  |  |
| Cash | $ | 149.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 149.4 |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | 291.9 |  |  | — |  |  | — |  |  | 291.9 |  |
| Corporate debt securities | 10.2 |  |  | — |  |  | — |  |  | 10.2 |  |
| Money market funds | 178.4 |  |  | — |  |  | — |  |  | 178.4 |  |
| U.S. Treasury securities | 500.4 |  |  | — |  |  | — |  |  | 500.4 |  |
| Total cash and cash equivalents | $ | 1,130.3 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,130.3 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 11.3 |  |  | $ | — |  |  | $ | — |  |  | $ | 11.3 |  |
| Commercial paper | 99.4 |  |  | — |  |  | (0.1) |  |  | 99.3 |  |
| Corporate debt securities | 649.7 |  |  | — |  |  | (6.6) |  |  | 643.1 |  |
| Municipal bonds | 1.0 |  |  | — |  |  | — |  |  | 1.0 |  |
| U.S. Agency securities | 65.2 |  |  | — |  |  | (1.2) |  |  | 64.0 |  |
| U.S. Treasury securities | 618.5 |  |  | 0.1 |  |  | (3.5) |  |  | 615.1 |  |
| Total short-term investments | $ | 1,445.1 |  |  | $ | 0.1 |  |  | $ | (11.4) |  |  | $ | 1,433.8 |  |
| July 3, 2021: |  |  |  |  |  |  |  |
| Cash | $ | 128.3 |  |  | $ | — |  |  | $ | — |  |  | $ | 128.3 |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | 7.5 |  |  | — |  |  | — |  |  | 7.5 |  |
| Corporate debt securities | 7.0 |  |  | — |  |  | — |  |  | 7.0 |  |
| Money market funds | 631.5 |  |  | — |  |  | — |  |  | 631.5 |  |
| Total cash and cash equivalents | $ | 774.3 |  |  | $ | — |  |  | $ | — |  |  | $ | 774.3 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 28.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 28.5 |  |
| Commercial paper | 136.7 |  |  | — |  |  | — |  |  | 136.7 |  |
| Corporate debt securities | 626.0 |  |  | 0.3 |  |  | (0.4) |  |  | 625.9 |  |
| Municipal bonds | 1.0 |  |  | — |  |  | — |  |  | 1.0 |  |
| U.S. Agency securities | 29.3 |  |  | — |  |  | — |  |  | 29.3 |  |
| U.S. Treasury securities | 350.3 |  |  | — |  |  | — |  |  | 350.3 |  |
| Total short-term investments | $ | 1,171.8 |  |  | $ | 0.3 |  |  | $ | (0.4) |  |  | $ | 1,171.7 |  |

[0001628280-22-012157:notes:40]
We review our investment portfolio to identify and evaluate investments that have indicators of possible impairment. Factors considered in determining whether a loss is other-than-temporary include, but are not limited to: the length of time and extent a security’s fair value has been below its cost, the financial condition and near-term prospects of the investee, the credit quality of the security’s issuer, likelihood of recovery and our intent and ability to hold the security for a period of time sufficient to allow for any anticipated recovery in value. For our debt instruments, we also evaluate whether we have the intent to sell the security or whether it is more likely than not that we will be required to sell the security before recovery of its cost basis. We have not recorded our unrealized losses on our short-term investments into income because we do not intend to sell nor is it more likely than not that we will be required to sell these investments prior to recovery of their amortized cost basis.

[0001628280-22-012157:notes:41]
We use the specific-identification method to determine any realized gains or losses from the sale of our short-term investments classified as available-for-sale. During the three and nine months ended April 2, 2022 and April 3, 2021, we did not realize significant gains or losses on a gross level from the sale of our short-term investments classified as available-for-sale.

[0001628280-22-012157:notes:42]
During the three and nine months ended April 2, 2022, our other income (expense), net was $2.2 million income and $3.8 million income, respectively, which includes interest and investment income on cash equivalents and short-term investments of $1.1 million and $2.3 million, respectively. During the three and nine months ended April 3, 2021, our other income (expense), net was $2.4 million and $2.1 million, respectively, which includes interest and investment income on cash equivalents and short-term investments of $1.0 million and $4.9 million, respectively.

[0001628280-22-012157:notes:43]
As of April 2, 2022 and July 3, 2021, we recorded interest receivables of $4.1 million and $4.1 million, respectively, in prepayments and other current assets within the condensed consolidated balance sheets. We did not recognize an allowance for credit losses against interest receivables in any of the periods presented as there were no such losses.

[0001628280-22-012157:notes:44]
As of April 2, 2022 and July 3, 2021, the Company does not have any cash equivalents and short-term investments that have been in a continuous unrealized gain or loss position for more than 12 months as of the periods presented. The following table summarizes unrealized losses on our cash equivalents and short-term investments by category that have been in a continuous unrealized loss position for less than 12 months as of the periods presented (in millions):

[0001628280-22-012157:notes:45]
|  | Fair Value |  | Unrealized Losses |  |  |  |  |  |  |  |  |
| April 2, 2022: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | 64.0 |  |  | (1.2) |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | 11.3 |  |  | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | 253.3 |  |  | (0.1) |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 639.3 |  |  | (6.6) |  |  |  |  |  |  |  |  |  |
| Municipal bonds | 1.0 |  |  | — |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 566.3 |  |  | (3.5) |  |  |  |  |  |  |  |  |  |
| Total | $ | 1,535.2 |  |  | $ | (11.4) |  |  |  |  |  |  |  |  |  |
| July 3, 2021: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | 28.3 |  |  | $ | — |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | 6.0 |  |  | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | 43.0 |  |  | — |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 432.3 |  |  | (0.4) |  |  |  |  |  |  |  |  |  |
| Municipal bonds | 1.0 |  |  | — |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 106.9 |  |  | — |  |  |  |  |  |  |  |  |  |
| Total | $ | 617.5 |  |  | $ | (0.4) |  |  |  |  |  |  |  |  |  |

[0001628280-22-012157:notes:46]
[same as prior period, unchanged from 0001628280-22-001745:notes:40]

[0001628280-22-012157:notes:47]
|  | April 2, 2022 |  | July 3, 2021 |
|  | Amortized Cost |  | Fair Value |  | Amortized Cost |  | Fair Value |
| Due in 1 year | $ | 1,044.6 |  |  | $ | 1,039.1 |  |  | $ | 587.0 |  |  | $ | 587.1 |  |
| Due in 1 year through 5 years | 400.5 |  |  | 394.7 |  |  | 584.8 |  |  | 584.6 |  |
|  | $ | 1,445.1 |  |  | $ | 1,433.8 |  |  | $ | 1,171.8 |  |  | $ | 1,171.7 |  |

[0001628280-22-012157:notes:48]
[same as prior period, unchanged from 0001628280-22-001745:notes:42]


## us-gaap:FairValueDisclosuresTextBlock

[0001628280-22-012157:notes:49]
[same as prior period, unchanged from 0001628280-22-001745:notes:43]

[0001628280-22-012157:notes:50]
[same as prior period, unchanged from 0001628280-22-001745:notes:44]

[0001628280-22-012157:notes:51]
[same as prior period, unchanged from 0001628280-22-001745:notes:45]

[0001628280-22-012157:notes:52]
[same as prior period, unchanged from 0001628280-22-001745:notes:46]

[0001628280-22-012157:notes:53]
[same as prior period, unchanged from 0001628280-22-001745:notes:47]

[0001628280-22-012157:notes:54]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| April 2, 2022: (1) |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | — |  |  | $ | 291.9 |  |  | $ | — |  |  | $ | 291.9 |  |
| Corporate debt securities | — |  |  | 10.2 |  |  | — |  |  | 10.2 |  |
| Money market funds | 178.4 |  |  | — |  |  | — |  |  | 178.4 |  |
| U.S. Treasury securities | 500.4 |  |  | — |  |  | — |  |  | 500.4 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | 11.3 |  |  | — |  |  | 11.3 |  |
| Commercial paper | — |  |  | 99.3 |  |  | — |  |  | 99.3 |  |
| Corporate debt securities | — |  |  | 643.1 |  |  | — |  |  | 643.1 |  |
| Municipal bonds | — |  |  | 1.0 |  |  | — |  |  | 1.0 |  |
| U.S. Agency securities | — |  |  | 64.0 |  |  | — |  |  | 64.0 |  |
| U.S. Treasury securities | 615.1 |  |  | — |  |  | — |  |  | 615.1 |  |
| Total assets | $ | 1,293.9 |  |  | $ | 1,120.8 |  |  | $ | — |  |  | $ | 2,414.7 |  |

[0001628280-22-012157:notes:55]
(1)  Excludes $149.4 million in cash held in our bank accounts as of April 2, 2022.

[0001628280-22-012157:notes:56]
[same as prior period, unchanged from 0001628280-22-001745:notes:50]

[0001628280-22-012157:notes:57]
[same as prior period, unchanged from 0001628280-22-001745:notes:51]

[0001628280-22-012157:notes:58]
[same as prior period, unchanged from 0001628280-22-001745:notes:52]

[0001628280-22-012157:notes:59]
We report our financial instruments at fair value with the exception of the 2028 Notes, 2026 Notes and the 2024 Notes. The estimated fair value of the notes was determined based on the trading price of the notes as of the last day of trading for the period. We consider the fair value of the notes to be a Level 2 measurement as they are not actively traded in markets.

[0001628280-22-012157:notes:60]
The carrying amounts and estimated fair values of the 2028 Notes, 2026 Notes and the 2024 Notes are as follows for the periods presented (in millions):

[0001628280-22-012157:notes:61]
|  | April 2, 2022 |  | July 3, 2021 |
|  | Carrying Amount |  | Estimated Fair Value |  | Carrying Amount |  | Estimated Fair Value |
| 2028 Notes | $ | 626.8 |  |  | $ | 831.3 |  |  | $ | — |  |  | $ | — |  |
| 2026 Notes | 820.8 |  |  | 1,208.0 |  |  | 789.8 |  |  | 1,146.1 |  |
| 2024 Notes | 406.1 |  |  | 728.4 |  |  | 390.7 |  |  | 669.3 |  |
|  | $ | 1,853.7 |  |  | $ | 2,767.7 |  |  | $ | 1,180.5 |  |  | $ | 1,815.4 |  |

[0001628280-22-012157:notes:62]
[same as prior period, unchanged from 0001628280-22-001745:notes:56]

[0001628280-22-012157:notes:63]
[same as prior period, unchanged from 0001628280-22-001745:notes:57]

[0001628280-22-012157:notes:64]
Management utilizes various valuation methods, including an income approach, a market approach and a cost approach, to estimate the fair value of intangibles and other long-lived assets. During the annual impairment testing performed in the fourth quarter of fiscal 2021, we concluded that our intangible and other long-lived assets were not impaired. We review our intangible and other long-lived assets for impairment at least annually in the fourth quarter of each fiscal year, absent any interim indicators of impairment.  There were no indicators of impairment during the nine months ended April 2, 2022.


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0001628280-22-012157:notes:65]
[same as prior period, unchanged from 0001628280-22-001745:notes:59]


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001628280-22-012157:notes:66]
[same as prior period, unchanged from 0001628280-22-001745:notes:60]

[0001628280-22-012157:notes:67]
[same as prior period, unchanged from 0001628280-22-001745:notes:61]

[0001628280-22-012157:notes:68]
We did not have any allowance for credit losses other than our allowance for uncollectible accounts receivable. As of April 2, 2022 and July 3, 2021, the allowance for credit losses on our trade receivables was $0.2 million and $0.4 million, respectively.

[0001628280-22-012157:notes:69]
[same as prior period, unchanged from 0001628280-22-001745:notes:63]

[0001628280-22-012157:notes:70]
[same as prior period, unchanged from 0001628280-22-001745:notes:64]

[0001628280-22-012157:notes:71]
|  | April 2, 2022 |  | July 3, 2021 |
| Raw materials and purchased parts | $ | 78.0 |  |  | $ | 64.4 |  |
| Work in process | 99.8 |  |  | 79.0 |  |
| Finished goods | 46.2 |  |  | 53.0 |  |
| Inventories | $ | 224.0 |  |  | $ | 196.4 |  |

[0001628280-22-012157:notes:72]
[same as prior period, unchanged from 0001628280-22-001745:notes:66]

[0001628280-22-012157:notes:73]
[same as prior period, unchanged from 0001628280-22-001745:notes:67]

[0001628280-22-012157:notes:74]
|  | April 2, 2022 |  | July 3, 2021 |
| Operating lease right-of-use assets | $ | 101.0 |  |  | $ | 87.3 |  |
| Less: accumulated amortization | (26.7) |  |  | (19.9) |  |
| Operating lease right-of-use assets, net | $ | 74.3 |  |  | $ | 67.4 |  |

[0001628280-22-012157:notes:75]
[same as prior period, unchanged from 0001628280-22-001745:notes:69]

[0001628280-22-012157:notes:76]
[same as prior period, unchanged from 0001628280-22-001745:notes:70]

[0001628280-22-012157:notes:77]
|  | April 2, 2022 |  | July 3, 2021 |
| Land | $ | 49.4 |  |  | $ | 38.2 |  |
| Buildings and improvement | 98.9 |  |  | 92.7 |  |
| Machinery and equipment | 535.8 |  |  | 498.3 |  |
| Computer equipment and software | 31.0 |  |  | 28.6 |  |
| Furniture and fixtures | 8.8 |  |  | 8.8 |  |
| Leasehold improvements | 35.4 |  |  | 33.9 |  |
| Finance lease right-of-use assets | — |  |  | 28.1 |  |
| Construction in progress | 45.0 |  |  | 43.4 |  |
|  | 804.3 |  |  | 772.0 |  |
| Less: Accumulated depreciation | (447.9) |  |  | (410.9) |  |
| Property, plant and equipment, net | $ | 356.4 |  |  | $ | 361.1 |  |

[0001628280-22-012157:notes:78]
As of April 2, 2022, finance lease assets are fully amortized and there are no outstanding finance lease liabilities.

[0001628280-22-012157:notes:79]
During the nine months ended April 2, 2022, we purchased land and buildings in Thailand and Slovenia with a fair value of $15.1 million in order to expand our manufacturing capacity.

[0001628280-22-012157:notes:80]
During the three and nine months ended April 2, 2022, we recorded depreciation expense of $20.2 million and $61.2 million, respectively. During the three and nine months ended April 3, 2021, we recorded depreciation expense of $22.8 million and $70.4 million, respectively.

[0001628280-22-012157:notes:81]
[same as prior period, unchanged from 0001628280-22-001745:notes:75]

[0001628280-22-012157:notes:82]
[same as prior period, unchanged from 0001628280-22-001745:notes:76]

[0001628280-22-012157:notes:83]
[same as prior period, unchanged from 0001628280-22-001745:notes:77]

[0001628280-22-012157:notes:84]
|  | April 2, 2022 |  | July 3, 2021 |
| Restructuring accrual and related charges (1) | $ | 0.1 |  |  | $ | 5.7 |  |
| Warranty accrual (2) | 9.1 |  |  | 5.0 |  |
| Deferred revenue and customer deposits | — |  |  | 0.6 |  |
| Income tax payable (3) | 17.1 |  |  | 43.5 |  |
| Other current liabilities | 5.3 |  |  | 3.0 |  |
| Other current liabilities | $ | 31.6 |  |  | $ | 57.8 |  |

[0001628280-22-012157:notes:85]
[same as prior period, unchanged from 0001628280-22-001745:notes:79]

[0001628280-22-012157:notes:86]
(2) Refer to “Note 14. Commitments and Contingencies.”

[0001628280-22-012157:notes:87]
[same as prior period, unchanged from 0001628280-22-001745:notes:81]

[0001628280-22-012157:notes:88]
[same as prior period, unchanged from 0001628280-22-001745:notes:82]

[0001628280-22-012157:notes:89]
[same as prior period, unchanged from 0001628280-22-001745:notes:83]

[0001628280-22-012157:notes:90]
|  | April 2, 2022 |  | July 3, 2021 |
| Asset retirement obligations | $ | 4.7 |  |  | $ | 4.7 |  |
| Pension and related accrual (1) | 11.2 |  |  | 10.8 |  |
| Unrecognized tax benefit | 26.4 |  |  | 23.0 |  |
| Other non-current liabilities | 0.5 |  |  | 2.4 |  |
| Other non-current liabilities | $ | 42.8 |  |  | $ | 40.9 |  |

[0001628280-22-012157:notes:91]
(1) We have defined benefit pension plans in Japan, Switzerland, and Thailand. As of April 2, 2022, the projected benefit obligations, net of plan assets, in Japan, Switzerland and Thailand were $2.8 million, $4.9 million and $3.5 million, respectively. As of July 3, 2021, the projected benefit obligations, net of plan assets, in Japan, Switzerland and Thailand were $2.9 million, $4.8 million and $3.1 million, respectively. We typically re-evaluate the assumptions related to the fair value of our defined benefit obligations annually and make any updates as necessary.


## us-gaap:LesseeFinanceLeasesTextBlock

[0001628280-22-012157:notes:92]
[same as prior period, unchanged from 0001628280-22-001745:notes:86]

[0001628280-22-012157:notes:93]
[same as prior period, unchanged from 0001628280-22-001745:notes:87]

[0001628280-22-012157:notes:94]
As of April 2, 2022, we sublease certain floors of our offices in the United Kingdom, the United States, Canada and Japan. These subleases will expire at various dates through fiscal year 2023. We anticipate receiving approximately $1.5 million in sublease income over the next year.

[0001628280-22-012157:notes:95]
[same as prior period, unchanged from 0001628280-22-001745:notes:89]

[0001628280-22-012157:notes:96]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 2, 2022 |  | April 3, 2021 |  | April 2, 2022 |  | April 3, 2021 |
| (in millions, except for weighted average data) |  |  |  |  |  |  |  |
| Finance lease cost | $ | — |  |  | $ | 0.1 |  |  | $ | — |  |  | $ | 0.4 |  |
| Operating lease cost | 3.3 |  |  | 3.4 |  |  | 10.0 |  |  | 10.6 |  |
| Variable lease cost | 0.3 |  |  | 0.5 |  |  | 1.1 |  |  | 1.5 |  |
| Short-term lease cost | 0.2 |  |  | 0.6 |  |  | 0.4 |  |  | 1.9 |  |
| Sublease income | (0.8) |  |  | (0.7) |  |  | (2.4) |  |  | (2.1) |  |
| Total lease cost | $ | 3.0 |  |  | $ | 3.9 |  |  | $ | 9.1 |  |  | $ | 12.3 |  |
|  |  |  |  |  | April 2, 2022 |  | July 3, 2021 |
| Weighted average remaining lease term (in years): |  |  |  |  |  |  |  |
| Operating leases |  |  |  |  | 7.1 |  | 7.5 |
| Weighted average discount rate (in percentages): |  |  |  |  |  |  |  |
| Operating leases |  |  |  |  | 3.0 | % |  | 3.5 | % |

[0001628280-22-012157:notes:97]
As of April 2, 2022, maturities of our operating lease liabilities, which do not include short-term leases and variable lease payments, were as follows (in millions):

[0001628280-22-012157:notes:98]
| Fiscal Years |  | Operating Leases (1) |  |  |  |  |
| Remainder of 2022 |  | $ | 3.5 |  |  |  |  |  |
| 2023 |  | 13.4 |  |  |  |  |  |
| 2024 |  | 12.8 |  |  |  |  |  |
| 2025 |  | 9.4 |  |  |  |  |  |
| 2026 |  | 7.9 |  |  |  |  |  |
| Thereafter |  | 25.2 |  |  |  |  |  |
| Total minimum lease payments |  | $ | 72.2 |  |  |  |  |  |
| Less: amount representing interest |  | (7.4) |  |  |  |  |  |
| Present value of total lease liabilities |  | $ | 64.8 |  |  |  |  |  |

[0001628280-22-012157:notes:99]
(1) Non-cancellable sublease proceeds for the remainder of fiscal 2022 and 2023 of $0.8 million and $0.7 million, respectively, are not included in the table above.


## us-gaap:GoodwillDisclosureTextBlock

[0001628280-22-012157:notes:100]
[same as prior period, unchanged from 0001628280-22-001745:notes:94]

[0001628280-22-012157:notes:101]
[same as prior period, unchanged from 0001628280-22-001745:notes:95]

[0001628280-22-012157:notes:102]
The following table presents our goodwill balance by reportable segments as of April 2, 2022 and July 3, 2021 (in millions):

[0001628280-22-012157:notes:103]
|  | Optical Communications |  | Commercial Lasers |  | Total |
| Balance as of April 2, 2022 and July 3, 2021 | $ | 363.5 |  |  | $ | 5.4 |  |  | $ | 368.9 |  |

[0001628280-22-012157:notes:104]
[same as prior period, unchanged from 0001628280-22-001745:notes:98]

[0001628280-22-012157:notes:105]
We review goodwill for impairment during the fourth quarter of each fiscal year or more frequently if events or circumstances indicate that an impairment loss may have occurred. In the fourth quarter of fiscal 2021, we completed the annual impairment test of goodwill, which indicated there was no goodwill impairment. There were no indicators of goodwill impairment during the three and nine months ended April 2, 2022.

[0001628280-22-012157:notes:106]
[same as prior period, unchanged from 0001628280-22-001745:notes:100]

[0001628280-22-012157:notes:107]
[same as prior period, unchanged from 0001628280-22-001745:notes:101]

[0001628280-22-012157:notes:108]
In-process research and development (“IPR&D”) is initially capitalized at fair value as an intangible asset with an indefinite life and assessed for impairment thereafter. When an IPR&D project is completed, the IPR&D is reclassified as an amortizable purchased intangible asset and amortized over the asset’s estimated useful life.

[0001628280-22-012157:notes:109]
[same as prior period, unchanged from 0001628280-22-001745:notes:103]

[0001628280-22-012157:notes:110]
| April 2, 2022 | Gross Carrying Amounts |  | Accumulated Amortization |  | Net Carrying Amounts |  | Weighted average remaining amortization period (years) |
| Acquired developed technologies | $ | 390.3 |  |  | $ | (287.5) |  |  | $ | 102.8 |  |  | 2.5 |
| Customer relationships | 145.0 |  |  | (70.9) |  |  | 74.1 |  |  | 4.7 |
| Order backlog | 22.0 |  |  | (22.0) |  |  | — |  |  | — |
| Other intangibles | 2.7 |  |  | (2.7) |  |  | — |  |  | — |
| Total intangible assets | $ | 560.0 |  |  | $ | (383.1) |  |  | $ | 176.9 |  |  |  |

[0001628280-22-012157:notes:111]
[same as prior period, unchanged from 0001628280-22-001745:notes:105]

[0001628280-22-012157:notes:112]
[same as prior period, unchanged from 0001628280-22-001745:notes:106]

[0001628280-22-012157:notes:113]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 2, 2022 |  | April 3, 2021 |  | April 2, 2022 |  | April 3, 2021 |
| Cost of sales | $ | 15.6 |  |  | $ | 15.8 |  |  | $ | 47.3 |  |  | $ | 45.8 |  |
| Selling, general and administrative | 5.8 |  |  | 6.2 |  |  | 17.0 |  |  | 17.8 |  |
| Total amortization of intangibles | $ | 21.4 |  |  | $ | 22.0 |  |  | $ | 64.3 |  |  | $ | 63.6 |  |

[0001628280-22-012157:notes:114]
Based on the carrying amount of our acquired developed technologies and other intangibles as of April 2, 2022, and assuming no future impairment of the underlying assets, the estimated future amortization is as follows (in millions):

[0001628280-22-012157:notes:115]
| Fiscal Years |  |
| Remainder of 2022 | $ | 21.2 |  |
| 2023 | 61.9 |  |
| 2024 | 40.5 |  |
| 2025 | 27.7 |  |
| 2026 | 18.1 |  |
| Thereafter | 7.5 |  |
| Total future amortization | $ | 176.9 |  |


## us-gaap:DebtDisclosureTextBlock

[0001628280-22-012157:notes:116]
Note 9. Debt

[0001628280-22-012157:notes:117]
Convertible Notes

[0001628280-22-012157:notes:118]
2028 Notes

[0001628280-22-012157:notes:119]
In March 2022, we issued $861.0 million in aggregate principal amount of 0.50% Convertible Notes due in 2028 (the “2028 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act of 1933, as amended (the “Securities Act”). The 2028 Notes are governed by an indenture between the Company and U.S. Bank Trust Company National Association (as successor in interest to U.S. Bank National Association), as a trustee (the “2028 Indenture”). The 2028 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001628280-22-012157:notes:120]
The net proceeds from the sale of the 2028 Notes was $854.8 million, after deducting $6.2 million in issuance costs. In addition, we incurred $0.7 million in professional fees in connection with this transaction.  Concurrent with the issuance of the 2028 Notes, we used $200.0 million of the net proceeds to repurchase our common stock in privately negotiated transactions. We intend to use the remaining net proceeds for general corporate purposes, which may include capital expenditures and working capital.

[0001628280-22-012157:notes:121]
The 2028 Notes bear interest at a rate of 0.50% per year, payable semi-annually in arrears on June 15 and December 15 of each year, beginning on June 15, 2022. The 2028 Notes will mature on June 15, 2028, unless earlier redeemed, repurchased by us, or converted pursuant to the terms.

[0001628280-22-012157:notes:122]
The initial conversion rate is 7.6319 shares of common stock per $1,000 principal amount of the 2028 Notes (which is equivalent to an initial conversion price of approximately $131.03 per share). The conversion rate is subject to adjustment upon the occurrence of certain specified events, but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert the 2028 Notes in connection with such make-whole fundamental change or notice of redemption.

[0001628280-22-012157:notes:123]
Prior to the close of business on the business day immediately preceding March 15, 2028, holders of the 2028 Notes may convert their 2028 Notes only under the following circumstances:

[0001628280-22-012157:notes:124]
•during any fiscal quarter commencing after July 2, 2022 (and only during such fiscal quarter), if the last reported sale price of the Company’s common stock for at least 20 trading days (whether or not consecutive) during the 30

[0001628280-22-012157:notes:125]
consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% if the applicable conversion price on each applicable trading day;

[0001628280-22-012157:notes:126]
•during the five consecutive business day period after any five consecutive trading day period (the “measurement period”) in which the trading price per $1,000 principal amount of the 2028 Notes for each trading day of such measurement was less than 98% of the product of the last reported sale price of the Company’s common stock and the applicable conversion rate on each such trading day;

[0001628280-22-012157:notes:127]
•if the Company calls any or all of the 2028 Notes for redemption, at any time prior to the close of business on the second business day immediately preceding the redemption date; or

[0001628280-22-012157:notes:128]
•upon the occurrence of specified corporate events, as specified in the 2028 Indentures.

[0001628280-22-012157:notes:129]
On or after March 15, 2028 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their 2028 Notes at any time. Upon conversion, we may satisfy our conversion obligation in cash, shares of common stock or a combination of cash and shares of common stock, at our election.

[0001628280-22-012157:notes:130]
We may redeem for cash all or any of the 2028 Notes, at our option (subject to the partial redemption limitation set forth in the 2028 Indenture), on or after June 20, 2025, if the last reported sale price of its common stock has been at least 130% of the conversion price then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading-day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which the Company provides notice of redemption at a redemption price equal to 100% of the principal amount of the 2028 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. No sinking fund is provided for the 2028 Notes. If we elect to redeem fewer than all of the outstanding 2028 Notes, at least $100.0 million aggregate principal amount of the 2028 Notes must be outstanding and not subject to redemption as of the redemption notice date.  Upon the occurrence of a fundamental change (as defined in the 2028 Indenture), holders may require the Company to repurchase all or a portion of their 2028 Notes for cash at a price equal to 100% of the principal amount of the 2028 Notes to be repurchased, plus any accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

[0001628280-22-012157:notes:131]
We bifurcated the principal amount of the 2028 Notes into liability and equity components.  The liability component of the 2028 Notes was valued at $629.8 million based on the contractual cash flow discounted at an appropriate comparable market on non-convertible debt borrowing rate at the date of issuance, which was 5.7%, with the equity component representing the residual amount of the proceeds of $231.2 million, which was recorded as a debt discount.  The issuance and other related costs of $6.9 million were allocated pro rata based on the relative carrying amounts of the liability and equity components.

[0001628280-22-012157:notes:132]
The debt discount and debt issuance costs attributable to the liability component will be amortized to interest expense using an effective interest rate of 5.7% over the expected life of the 2028 Notes.  Debt issuance costs attributable to the equity component are netted against the equity component in stockholders’ equity, and the equity component is not remeasured as long as it continues to meet the conditions for equity classification.

[0001628280-22-012157:notes:133]
2026 Notes

[0001628280-22-012157:notes:134]
In December 2019, we issued $1,050.0 million in aggregate principal amount of 0.50% Convertible Notes due in 2026 (the “2026 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities. The 2026 Notes are governed by an indenture between the Company and U.S. Bank Trust Company National Association (as successor in interest to U.S. Bank National Association, as a trustee (the “2026 Indenture”). We used approximately $196.0 million of the net proceeds of the offering to repay in full all amounts outstanding under our term loan credit facility, and a portion of the net proceeds of the offering to purchase approximately $200.0 million of our common stock concurrently with the pricing of the offering in privately negotiated transactions. The 2026 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001628280-22-012157:notes:135]
The 2026 Notes bear interest at a rate of 0.50% per year, payable semi-annually in arrears on June 15 and December 15 of each year, beginning on June 15, 2020. The 2026 Notes will mature on December 15, 2026, unless earlier redeemed, repurchased by us, or converted pursuant to their terms.

[0001628280-22-012157:notes:136]
The initial conversion rate is 10.0711 shares of common stock per $1,000 principal amount of the 2026 Notes (which is equivalent to an initial conversion price of approximately $99.29 per share). The conversion rate is subject to adjustment upon the occurrence of certain specified events but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert the 2026 Notes in connection with such make-whole fundamental change or notice of redemption.

[0001628280-22-012157:notes:137]
Prior to the close of business on the business day immediately preceding September 15, 2026, holders of the 2026 Notes may convert their 2026 Notes only under certain circumstances discussed in detail in our Annual Report on Form 10-K for the year ended July 3, 2021.

[0001628280-22-012157:notes:138]
2024 Notes

[0001628280-22-012157:notes:139]
In March 2017, we issued $450 million of 0.25% Convertible Notes due in 2024 (the “2024 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act. The 2024 Notes are governed by an indenture between the Company, as the issuer, and U.S. Bank Trust Company National Association (as successor in interest to U.S. Bank National Association), as trustee (the “2024 Indenture”). The 2024 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001628280-22-012157:notes:140]
The 2024 Notes bear interest at a rate of 0.25% per year. Interest on the 2024 Notes is payable semi-annually in arrears on March 15 and September 15 of each year, beginning on September 15, 2017. The 2024 Notes will mature on March 15, 2024, unless earlier repurchased by us or converted pursuant to their terms.

[0001628280-22-012157:notes:141]
The initial conversion rate of the 2024 Notes is 16.4965 shares of common stock per $1,000 principal amount of 2024 Notes, which is equivalent to an initial conversion price of approximately $60.62 per share. Prior to the close of business on the business day immediately preceding December 15, 2023, each holder of the 2024 Notes may convert their 2024 Notes only under certain circumstances discussed in detail in our Annual Report on Form 10-K for the year ended July 3, 2021.

[0001628280-22-012157:notes:142]
During the nine months ended April 2, 2022, we received and settled in cash, conversion requests of less than $0.1 million principal amount of the 2024 Notes. From April 1, 2022 through May 4, 2022, we received requests for conversion of approximately $1.8 million in principal amount of the 2024 Notes. Such conversion will be settled in the fourth quarter of fiscal 2022 with a combination of cash and shares of the Company’s common stock in accordance with the applicable indenture.

[0001628280-22-012157:notes:143]
Our convertible notes consisted of the following components as of the periods presented (in millions):

[0001628280-22-012157:notes:144]
| Liability component: | April 2, 2022 |  | July 3, 2021 |
|  | 2024 Notes (1) |  | 2026 Notes (2) |  | 2028 Notes (3) |  | 2024 Notes |  | 2026 Notes |
| Principal | $ | 450.0 |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |  | $ | 450.0 |  |  | $ | 1,050.0 |  |
| Unamortized debt discount and issuance costs | (43.9) |  |  | (229.2) |  |  | (234.2) |  |  | (59.3) |  |  | (260.2) |  |
| Net carrying amount of the liability component | $ | 406.1 |  |  | $ | 820.8 |  |  | $ | 626.8 |  |  | $ | 390.7 |  |  | $ | 789.8 |  |

[0001628280-22-012157:notes:145]
(1) Since the closing price of our stock exceeded $78.80 (or 130% of the conversion price of $60.62) for 20 of the last 30 trading days of the third quarter of fiscal 2022, the 2024 Notes have become convertible at the option of the holders. Therefore, the debt component of our 2024 Notes as of April 2, 2022 has been classified as current liabilities in our condensed consolidated balance sheet.

[0001628280-22-012157:notes:146]
(2) If the closing price of our stock exceeds $129.08 (or 130% of the conversion price of $99.29) for 20 of the last 30 trading days of any future quarter, our 2026 Notes would also become convertible at the option of the holders and the debt component would be reclassified to current liabilities in our condensed consolidated balance sheet.

[0001628280-22-012157:notes:147]
(3) During any fiscal quarter commencing after July 2, 2022, if the closing price of our stock exceeds $170.34 (or 130% of the conversion price of $131.03) for 20 of the last 30 trading days of such quarter, our 2028 Notes would also become convertible at the option of the holders and the debt component would be reclassified to current liabilities in our condensed consolidated balance sheet.

[0001628280-22-012157:notes:148]
The following table sets forth interest expense information related to the convertible notes for the periods presented (in millions):

[0001628280-22-012157:notes:149]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 2, 2022 |  | April 3, 2021 |  | April 2, 2022 |  | April 3, 2021 |
| Contractual interest expense | $ | 1.9 |  |  | $ | 1.6 |  |  | $ | 5.1 |  |  | $ | 4.8 |  |
| Amortization of the debt discount and debt issuance costs | 17.8 |  |  | 14.8 |  |  | 48.6 |  |  | 43.9 |  |
| Total interest expense | $ | 19.7 |  |  | $ | 16.4 |  |  | $ | 53.7 |  |  | $ | 48.7 |  |

[0001628280-22-012157:notes:150]
The future interest and principal payments related to our convertible notes are as follows as of April 2, 2022 (in millions):

[0001628280-22-012157:notes:151]
| Fiscal Years | 2024 Notes |  | 2026 Notes |  | 2028 Notes |  | Total |
| Remainder of 2022 | $ | 1.8 |  |  | $ | 2.7 |  |  | $ | 1.2 |  |  | $ | 5.7 |  |
| 2023 | 1.1 |  |  | 5.3 |  |  | 4.3 |  |  | 10.7 |  |
| 2024 | 449.4 |  |  | 5.3 |  |  | 4.3 |  |  | 459.0 |  |
| 2025 | — |  |  | 5.3 |  |  | 4.3 |  |  | 9.6 |  |
| 2026 | — |  |  | 5.3 |  |  | 4.3 |  |  | 9.6 |  |
| Thereafter | — |  |  | 1,052.4 |  |  | 869.6 |  |  | 1,922.0 |  |
| Total convertible notes payments | $ | 452.3 |  |  | $ | 1,076.3 |  |  | $ | 888.0 |  |  | $ | 2,416.6 |  |

[0001628280-22-012157:notes:152]
The principal balances of our Notes are reflected in the payment periods in the table above based on their respective contractual maturities.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001628280-22-012157:notes:153]
Note 10. Accumulated Other Comprehensive Income (Loss)

[0001628280-22-012157:notes:154]
[same as prior period, unchanged from 0001628280-22-001745:notes:133]

[0001628280-22-012157:notes:155]
[same as prior period, unchanged from 0001628280-22-001745:notes:134]

[0001628280-22-012157:notes:156]
|  | Foreign currency translation adjustments, net of tax (1) |  | Defined benefit obligations, net of tax (2) |  | Unrealized gain (loss) on available-for-sale securities, net of tax |  |  |  | Total |
| Beginning balance as of July 3, 2021 | $ | 9.7 |  |  | $ | (1.4) |  |  | $ | (0.1) |  |  |  |  | $ | 8.2 |  |
| Other comprehensive income | — |  |  | — |  |  | 0.3 |  |  |  |  | 0.3 |  |
| Ending balance as of October 2, 2021 | 9.7 |  |  | (1.4) |  |  | 0.2 |  |  |  |  | 8.5 |  |
| Other comprehensive loss | — |  |  | — |  |  | (2.3) |  |  |  |  | (2.3) |  |
| Ending balance as of January 1, 2022 | 9.7 |  |  | (1.4) |  |  | (2.1) |  |  |  |  | 6.2 |  |
| Other comprehensive loss | — |  |  | (0.5) |  |  | (6.9) |  |  |  |  | (7.4) |  |
| Ending balance as of April 2, 2022 | $ | 9.7 |  |  | $ | (1.9) |  |  | $ | (9.0) |  |  |  |  | $ | (1.2) |  |
|  | Foreign currency translation adjustments, net of tax (1) |  | Defined benefit obligations, net of tax (2) |  | Unrealized gain (loss) on available-for-sale securities, net of tax |  |  |  | Total |
| Beginning balance as of June 27, 2020 | $ | 9.7 |  |  | $ | (4.2) |  |  | $ | 2.4 |  |  |  |  | $ | 7.9 |  |
| Other comprehensive loss | — |  |  | — |  |  | (1.5) |  |  |  |  | (1.5) |  |
| Ending balance as of September 26, 2020 | 9.7 |  |  | (4.2) |  |  | 0.9 |  |  |  |  | 6.4 |  |
| Other comprehensive loss | — |  |  | — |  |  | (0.4) |  |  |  |  | (0.4) |  |
| Ending balance as of December 26, 2020 | 9.7 |  |  | (4.2) |  |  | 0.5 |  |  |  |  | 6.0 |  |
| Other comprehensive loss | — |  |  | — |  |  | (0.3) |  |  |  |  | (0.3) |  |
| Ending balance as of April 3, 2021 | $ | 9.7 |  |  | $ | (4.2) |  |  | $ | 0.2 |  |  |  |  | $ | 5.7 |  |

[0001628280-22-012157:notes:157]
[same as prior period, unchanged from 0001628280-22-001745:notes:136]

[0001628280-22-012157:notes:158]
[same as prior period, unchanged from 0001628280-22-001745:notes:137]


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001628280-22-012157:notes:159]
[same as prior period, unchanged from 0001628280-22-001745:notes:138]

[0001628280-22-012157:notes:160]
[same as prior period, unchanged from 0001628280-22-001745:notes:139]

[0001628280-22-012157:notes:161]
[same as prior period, unchanged from 0001628280-22-001745:notes:140]

[0001628280-22-012157:notes:162]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 2, 2022 |  | April 3, 2021 |  | April 2, 2022 |  | April 3, 2021 |
| Balance as of beginning of period | $ | 0.3 |  |  | $ | 4.6 |  |  | $ | 5.7 |  |  | $ | 5.2 |  |
| Charges (reversals), net | (0.1) |  |  | 2.9 |  |  | (1.1) |  |  | 3.1 |  |
| Payments | (0.1) |  |  | (3.3) |  |  | (4.5) |  |  | (4.1) |  |
| Balance as of end of period | $ | 0.1 |  |  | $ | 4.2 |  |  | $ | 0.1 |  |  | $ | 4.2 |  |

[0001628280-22-012157:notes:163]
During the nine months ended April 2, 2022, we recorded a net reversal to our restructuring and related charges of $1.1 million in our condensed consolidated statements of operations which was primarily attributable to lower than anticipated employee severance charges due to retaining and re-assigning certain employees.

[0001628280-22-012157:notes:164]
During the three and nine months ended April 3, 2021, we recorded restructuring and related charges of $2.9 million and $3.1 million, respectively, in our condensed consolidated statements of operations. The charges were mainly attributable to severance charges associated with the decision to cease manufacturing of certain products in San Jose, California.

[0001628280-22-012157:notes:165]
[same as prior period, unchanged from 0001628280-22-001745:notes:144]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-22-012157:notes:166]
[same as prior period, unchanged from 0001628280-22-001745:notes:145]

[0001628280-22-012157:notes:167]
[same as prior period, unchanged from 0001628280-22-001745:notes:146]

[0001628280-22-012157:notes:168]
We recorded a tax provision of $3.3 million and $33.8 million for the three and nine months ended April 2, 2022, respectively. Our tax provision for the three months ended April 2, 2022 includes a discrete tax benefit of $2.0 million, primarily related to currency re-measurement of certain tax related accounts and excess tax benefit related to stock-based compensation that vested during the quarter. Our estimated effective tax rate for fiscal 2022 differs from the 21% U.S. statutory rate primarily due to the income tax benefit from the earnings of our foreign subsidiaries being taxed at rates that differ from the U.S. statutory rate and U.S. federal R&D tax credits, partially offset by the income tax expense from the tax effect of Global Intangible Low-Taxed Income (“GILTI”), net of benefit for foreign tax credits, subpart F inclusion and non-deductible stock-based compensation.

[0001628280-22-012157:notes:169]
As of April 2, 2022, we had $26.8 million of unrecognized tax benefits, which, if recognized, would affect the effective tax rate. We are subject to examination of income tax returns by various domestic and foreign tax authorities. The timing of resolution and closure of tax audits is highly unpredictable. Although it is possible that certain ongoing tax audits may be concluded within the next 12 months, we cannot reasonably estimate the impact to tax expense and net income from tax exams that could be resolved or closed within the next 12 months. Subject to audit timing and uncertainty, we expect the amount of unrecognized tax benefit that would become recognized due to expiration of the statute of limitations and affect the effective tax rate to decrease by $3.6 million over the next 12 months.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001628280-22-012157:notes:170]
[same as prior period, unchanged from 0001628280-22-001745:notes:149]

[0001628280-22-012157:notes:171]
[same as prior period, unchanged from 0001628280-22-001745:notes:150]

[0001628280-22-012157:notes:172]
[same as prior period, unchanged from 0001628280-22-001745:notes:151]

[0001628280-22-012157:notes:173]
[same as prior period, unchanged from 0001628280-22-001745:notes:152]

[0001628280-22-012157:notes:174]
As of April 2, 2022, we had 2.5 million shares subject to restricted stock units and performance stock units issued and outstanding under the 2015 Plan. Restricted stock units and performance stock units are performance-based, time-based or a combination of both. The fair value of these grants is based on the closing market price of our common stock on the date of award.

[0001628280-22-012157:notes:175]
As of April 2, 2022, 3.9 million shares of common stock under the 2015 Plan were available for grant.

[0001628280-22-012157:notes:176]
[same as prior period, unchanged from 0001628280-22-001745:notes:155]

[0001628280-22-012157:notes:177]
[same as prior period, unchanged from 0001628280-22-001745:notes:156]

[0001628280-22-012157:notes:178]
During the nine months ended April 2, 2022, our board of directors approved grants of 1.4 million shares which primarily vest over three years.

[0001628280-22-012157:notes:179]
[same as prior period, unchanged from 0001628280-22-001745:notes:158]

[0001628280-22-012157:notes:180]
[same as prior period, unchanged from 0001628280-22-001745:notes:159]

[0001628280-22-012157:notes:181]
During the nine months ended April 2, 2022, our board of directors approved a grant of 0.2 million PSUs with an aggregate grant date fair value of $16.7 million to certain executive officers and senior management. These PSUs will vest subject to the achievement of 3-year revenue targets and certain non-financial performance measurement, as well as service conditions.

[0001628280-22-012157:notes:182]
[same as prior period, unchanged from 0001628280-22-001745:notes:161]

[0001628280-22-012157:notes:183]
Our 2015 Employee Stock Purchase Plan (the “2015 Purchase Plan”) provides eligible employees with the opportunity to acquire an ownership interest in the Company through periodic payroll deductions and provides a 15% purchase price discount as well as a 6-month look-back period. The 2015 Purchase Plan is structured as a qualified employee stock purchase plan under Section 423 of the Internal Revenue Code of 1986, as amended. The 2015 Purchase Plan will terminate upon the date on which all shares available for issuance have been sold. Of the 3.0 million shares authorized under the 2015 Purchase Plan, 1.5 million shares remained available for issuance as of April 2, 2022.

[0001628280-22-012157:notes:184]
[same as prior period, unchanged from 0001628280-22-001745:notes:163]

[0001628280-22-012157:notes:185]
[same as prior period, unchanged from 0001628280-22-001745:notes:164]

[0001628280-22-012157:notes:186]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 2, 2022 |  | April 3, 2021 |  | April 2, 2022 |  | April 3, 2021 |
| Cost of sales | $ | 5.4 |  |  | $ | 5.3 |  |  | $ | 15.2 |  |  | $ | 13.8 |  |
| Research and development | 5.4 |  |  | 5.3 |  |  | 15.8 |  |  | 14.8 |  |
| Selling, general and administrative | 12.5 |  |  | 14.5 |  |  | 44.4 |  |  | 40.1 |  |
| Total stock-based compensation | $ | 23.3 |  |  | $ | 25.1 |  |  | $ | 75.4 |  |  | $ | 68.7 |  |

[0001628280-22-012157:notes:187]
Included in stock-based compensation for the three and nine months ended April 2, 2022, is $2.2 million and $11.5 million, respectively, of stock-based compensation costs related to PSUs. Included in stock-based compensation for the three and nine months ended April 3, 2021, is $4.7 million and $11.9 million, respectively, of stock-based compensation costs related to PSUs. The amount of stock-based compensation expense recognized in any one period related to PSUs can vary based on the achievement or anticipated achievement of the performance conditions. If the performance conditions are not met or not expected to be met, no compensation cost would be recognized on the underlying PSUs, and any previously recognized compensation expense related to those PSUs would be reversed.

[0001628280-22-012157:notes:188]
[same as prior period, unchanged from 0001628280-22-001745:notes:167]

[0001628280-22-012157:notes:189]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 2, 2022 |  | April 3, 2021 |  | April 2, 2022 |  | April 3, 2021 |
| Income tax benefit associated with stock-based compensation | $ | 2.7 |  |  | $ | 3.4 |  |  | $ | 10.9 |  |  | $ | 12.2 |  |

[0001628280-22-012157:notes:190]
Approximately $5.6 million and $4.6 million of stock-based compensation was capitalized to inventory as of April 2, 2022 and July 3, 2021, respectively.

[0001628280-22-012157:notes:191]
[same as prior period, unchanged from 0001628280-22-001745:notes:170]

[0001628280-22-012157:notes:192]
The following table summarizes our award activity for the nine months ended April 2, 2022 (in millions, except per share amounts):

[0001628280-22-012157:notes:193]
|  |  |  | Restricted Stock Units |  | Performance Stock Units |
|  |  |  |  |  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |
| Balance as of July 3, 2021 |  |  |  |  | 1.8 |  |  | $ | 76.02 |  |  | 0.3 |  |  | $ | 75.68 |  |
| Granted |  |  |  |  | 1.4 |  |  | 87.92 |  |  | 0.2 |  |  | 85.72 |  |
| Vested |  |  |  |  | (0.9) |  |  | 73.71 |  |  | (0.1) |  |  | 76.43 |  |
| Canceled |  |  |  |  | (0.2) |  |  | 78.65 |  |  | — |  |  | 58.65 |  |
| Balance as of April 2, 2022 |  |  |  |  | 2.1 |  |  | $ | 84.70 |  |  | 0.4 |  |  | $ | 81.27 |  |

[0001628280-22-012157:notes:194]
As of April 2, 2022, $151.9 million of stock-based compensation cost related to RSU awards granted to our employees remains to be amortized. That cost is expected to be recognized over an estimated amortization period of 2.0 years.

[0001628280-22-012157:notes:195]
[same as prior period, unchanged from 0001628280-22-001745:notes:174]

[0001628280-22-012157:notes:196]
|  | Awards Available for Grant |
| Balance as of July 3, 2021 | 2.3 |  |
| Authorized | 3.0 |  |
| Granted | (1.6) |  |
| Canceled | 0.2 |  |
| Balance as of April 2, 2022 | 3.9 |  |

[0001628280-22-012157:notes:197]
[same as prior period, unchanged from 0001628280-22-001745:notes:176]

[0001628280-22-012157:notes:198]
The 2015 Purchase Plan expense for the three and nine months ended April 2, 2022 was $1.0 million and $3.1 million, respectively. The 2015 Purchase Plan expense for the three and nine months ended April 3, 2021 was $1.2 million and $3.5 million, respectively. The expense related to the 2015 Purchase Plan is recorded on a straight-line basis over the relevant subscription period. During the nine months ended April 2, 2022, there were 0.1 million shares issued to employees through the 2015 Purchase Plan. During the nine months ended April 3, 2021, there were 0.1 million shares issued to employees through the 2015 Purchase Plan.

[0001628280-22-012157:notes:199]
[same as prior period, unchanged from 0001628280-22-001745:notes:178]

[0001628280-22-012157:notes:200]
Repurchase Made in Connection with Convertible Note Offering

[0001628280-22-012157:notes:201]
In the third quarter of fiscal year 2022, concurrent with the issuance of the 2028 Notes, we repurchased 2.0 million shares of our common stock in privately negotiated transactions at an average price of $99.0 per share for an aggregate purchase price of $200.0 million. We recorded the $200.0 million aggregate purchase price as a reduction of retained earnings within our condensed consolidated balance sheet.  These shares were retired immediately.

[0001628280-22-012157:notes:202]
Share Buyback Program

[0001628280-22-012157:notes:203]
On May 7, 2021, our board of directors approved the 2021 share buyback program, which authorizes us to use up to $700.0 million to purchase our own shares of common stock. The 2021 share buyback program was authorized for 2 years.  On March 3, 2022, our board of directors approved an increase in our share buyback program, which authorizes us to use up to an aggregate amount of $1.0 billion (an increase from $700.0 million) to purchase our own shares of common stock through May 2024, but may be suspended or terminated by the board of directors at any time.

[0001628280-22-012157:notes:204]
During the nine months ended April 2, 2022, we repurchased 2.7 million shares of our common stock at an average price of $89.80 per share for an aggregate purchase price of $245.5 million.

[0001628280-22-012157:notes:205]
Since the share buyback program was approved by the board of directors, we have repurchased 5.8 million shares in aggregate at an average price of $83.45 per share for a total purchase price of $486.5 million. We recorded the $486.5 million aggregate purchase price as a reduction of retained earnings within our condensed consolidated balance sheet. All repurchased shares were retired immediately.

[0001628280-22-012157:notes:206]
The price, timing, amount, and method of such repurchases will be determined based on the valuation of market conditions and other factors, at prices determined to be attractive and in the best interests of both Lumentum and our stockholders.


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0001628280-22-012157:notes:207]
Note 14. Commitments and Contingencies

[0001628280-22-012157:notes:208]
Purchase Obligations

[0001628280-22-012157:notes:209]
Purchase obligations of $345.6 million as of April 2, 2022, represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements.

[0001628280-22-012157:notes:210]
Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule and adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

[0001628280-22-012157:notes:211]
We depend on a limited number of contract manufacturers, subcontractors and suppliers for raw materials, packages and standard components. We generally purchase these single or limited source products through standard purchase orders or one-year supply agreements and have no significant long-term guaranteed supply agreements with such vendors. While we seek to maintain a sufficient safety stock of such products and maintain on-going communications with our suppliers to guard against interruptions or cessation of supply, our business and results of operations could be adversely affected by a stoppage or delay of supply, substitution of more expensive or less reliable products, receipt of defective parts or contaminated materials, increases in the price of such supplies, or our inability to obtain reduced pricing from our suppliers in response to competitive pressures.

[0001628280-22-012157:notes:212]
Product Warranties

[0001628280-22-012157:notes:213]
We provide reserves for the estimated costs of product warranties at the time revenue is recognized. We typically offer a twelve month warranty for most of our products. However, in some instances depending upon the product, product components or application of our products by the end customer, our warranties can vary and generally range from six months to five years. We estimate the costs of our warranty obligations on an annualized basis based on our historical experience of known product failure rates, use of materials to repair or replace defective products and service delivery costs incurred in correcting product failures. In addition, from time to time, specific warranty accruals may be made if unforeseen technical problems arise with specific products. We assess the adequacy of our recorded warranty liabilities and adjust the amounts as necessary.

[0001628280-22-012157:notes:214]
The following table presents the changes in our warranty reserve for the periods presented (in millions):

[0001628280-22-012157:notes:215]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 2, 2022 |  | April 3, 2021 |  | April 2, 2022 |  | April 3, 2021 |
| Balance as of beginning of period | $ | 8.6 |  |  | $ | 5.7 |  |  | $ | 5.0 |  |  | $ | 5.0 |  |
| Provision for warranty | 1.5 |  |  | 1.7 |  |  | 7.0 |  |  | 5.8 |  |
| Utilization of reserve | (1.0) |  |  | (1.8) |  |  | (2.9) |  |  | (5.2) |  |
| Balance as of end of period | $ | 9.1 |  |  | $ | 5.6 |  |  | $ | 9.1 |  |  | $ | 5.6 |  |

[0001628280-22-012157:notes:216]
Environmental Liabilities

[0001628280-22-012157:notes:217]
Our research and development (“R&D”), manufacturing and distribution operations involve the use of hazardous substances and are regulated under international, federal, state and local laws governing health and safety and the environment. We apply strict standards for protection of the environment and occupational health and safety to sites inside and outside the United States, even if not subject to regulations imposed by foreign governments. We believe that our properties and operations at our facilities comply in all material respects with applicable environmental laws and occupational health and safety laws. However, the risk of environmental liabilities cannot be completely eliminated and there can be no assurance that the application of environmental and health and safety laws will not require us to incur significant expenditures. We are also regulated under a number of international, federal, state and local laws regarding recycling, product packaging and product content requirements. The environmental, product content/disposal and recycling laws are gradually becoming more stringent and may cause us to incur significant expenditures in the future.

[0001628280-22-012157:notes:218]
Legal Proceedings

[0001628280-22-012157:notes:219]
We are subject to a variety of claims and suits that arise from time to time in the ordinary course of our business. While management currently believes that resolving claims against us, individually or in the aggregate, will not have a material adverse impact on our financial position, results of operations or statements of cash flows, these matters are subject to inherent uncertainties and management’s view of these matters may change in the future. We accrue for loss contingencies when it is both probable that we will incur the loss and when we can reasonably estimate the amount of the loss or range of loss.

[0001628280-22-012157:notes:220]
Oclaro Merger Litigation

[0001628280-22-012157:notes:221]
In connection with our acquisition of Oclaro, seven lawsuits were filed by purported stockholders of Oclaro challenging the proposed merger (the “Merger”). Two of the seven suits were putative class actions filed against Oclaro, its directors, Lumentum, Prota Merger Sub, Inc. and Prota Merger, LLC: Nicholas Neinast v. Oclaro, Inc., et al., No. 3:18-cv-03112-VC, in the United States District Court for the Northern District of California (filed May 24, 2018) (the “Neinast Lawsuit”); and Adam Franchi v. Oclaro, Inc., et al., No. 1:18-cv-00817-GMS, in the United States District Court for the District of Delaware (filed June 9, 2018) (the “Franchi Lawsuit”). Both the Neinstat Lawsuit and the Franchi Lawsuit were voluntarily dismissed with prejudice.

[0001628280-22-012157:notes:222]
The other five suits, styled as Gerald F. Wordehoff v. Oclaro, Inc., et al., No. 5:18-cv-03148-NC (the “Wordehoff Lawsuit”), Walter Ryan v. Oclaro, Inc., et al., No. 3:18-cv-03174-VC (the “Ryan Lawsuit”), Jayme Walker v. Oclaro, Inc., et al., No. 5:18-cv-03203-EJD (the “Walker Lawsuit”), Kevin Garcia v. Oclaro, Inc., et al., No. 5:18-cv-03262-VKD (the “Garcia Lawsuit”), and SaiSravan B. Karri v. Oclaro, Inc., et al., No. 3:18-cv-03435-JD (the “Karri Lawsuit” and, together with the other six lawsuits, the “Lawsuits”), were filed in the United States District Court for the Northern District of California on May 25, 2018, May 29, 2018, May 30, 2018, May 31, 2018, and June 9, 2018, respectively. These five Lawsuits named Oclaro and its directors as defendants only and did not name Lumentum. The Wordehoff, Ryan, Walker, and Garcia Lawsuits have been voluntarily dismissed, and the Wordehoff, Ryan, and Walker dismissals were with prejudice. The Karri Lawsuit has not yet been dismissed. The Ryan Lawsuit was, and the Karri Lawsuit is, a putative class action.

[0001628280-22-012157:notes:223]
The Lawsuits generally alleged, among other things, that Oclaro and its directors violated Section 14(a) of the Securities Exchange Act of 1934, as amended (the “Exchange Act”), and Rule 14a-9 promulgated thereunder by disseminating an incomplete and misleading Form S-4, including proxy statement/prospectus. The Lawsuits further alleged that Oclaro’s directors violated Section 20(a) of the Exchange Act by failing to exercise proper control over the person(s) who violated Section 14(a) of the Exchange Act.

[0001628280-22-012157:notes:224]
The remaining Lawsuit (the Karri Lawsuit) currently purports to seek, among other things, damages to be awarded to the plaintiff and any class, if a class is certified, and litigation costs, including attorneys’ fees.  A lead plaintiff and counsel has been selected, and an amended complaint was filed on April 15, 2019, which also named Lumentum as a defendant. A motion to dismiss the amended complaint was granted in part and denied in part by the court on October 8, 2020. On December 1, 2020, defendants answered the amended complaint. On December 23, 2020, defendants filed a motion for leave to file a motion for reconsideration of the Court’s October 8th order on the motion to dismiss, which was denied on January 29, 2021. On June 22, 2021, the Court granted the parties’ stipulation to dismiss Lumentum as a defendant from the action.  On September 17, 2021, lead plaintiff filed a second amended complaint (“SAC”). Defendants moved to stay discovery in light of the SAC, and on January 11, 2022 the Court struck the SAC as untimely, terminated defendants’ motions to dismiss as moot, and lifted the stay.  The Karri Lawsuit remains pending with the parties currently in discovery. Defendants intend to defend the Karri Lawsuit vigorously.

[0001628280-22-012157:notes:225]
NeoPhotonics Merger Litigation

[0001628280-22-012157:notes:226]
In connection with our planned acquisition of NeoPhotonics Corporation (“NeoPhotonics”) announced in November 2021, ten lawsuits (the “NeoPhotonics Lawsuits”) were filed by purported stockholders of NeoPhotonics challenging the proposed merger (the “NeoPhotonics Merger”).  Four of the NeoPhotonics Lawsuits, styled as Elaine Wang v. NeoPhotonics Corporation, et al., No. 1:21-cv-10338, Heather Smith v. NeoPhotonics Corporation, et al., No. 1:21-cv-10698, Matthew Hopkins v. NeoPhotonics Corporation, et al., No. 1:21-cv-10725, and John Ryan v. NeoPhotonics Corporation, et al., No. 1:22-cv-00046, were filed in the United States District Court for the Southern District of New York on December 3, 2021, December 14, 2021, December 15, 2021, and January 4, 2022, respectively.  Three of the NeoPhotonics Lawsuits, styled as Mengsheng Ku v. NeoPhotonics Corporation, et al., No. 5:21-cv-09479, Stephen Bushansky v. NeoPhotonics Corporation, et al., No. 5:21-cv-09825, and James Parshall v. NeoPhotonics Corporation, et al., No. 5:22-cv-00055, were filed in the United States District Court for the Northern District of New York on December 8, 2021, December 20, 2021, and January 5, 2022, respectively. One NeoPhotonics Lawsuit, styled as James Hendrickson v. NeoPhotonics Corporation, et al., No. 1:21-cv-06919, was filed in the United States District Court for the Eastern District of New York on December 15, 2021. One NeoPhotonics Lawsuit, styled as Alex Ciccotelli v. NeoPhotonics Corporation, et al., No. 2:21-cv-05611, was filed in the United States District Court for the Eastern District of Pennsylvania on December 23, 2021. One NeoPhotonics Lawsuit, styled as Christopher Taylor v. NeoPhotonics Corporation, et al., No. 1:22-cv-00002, was filed in the United States District Court for the District of Delaware on January 3, 2022.

[0001628280-22-012157:notes:227]
These ten NeoPhotonics Lawsuits name NeoPhotonics and its directors as defendants and do not name Lumentum.

[0001628280-22-012157:notes:228]
The NeoPhotonics Lawsuits generally allege, among other things, that NeoPhotonics and its directors violated Section 14(a) of the Exchange Act, Rule 14a-9 promulgated thereunder, and 17 C.F.R. § 244.100 by disseminating an incomplete and misleading Preliminary Proxy Statement on Schedule 14A, filed with the SEC on December 1, 2021 regarding the NeoPhotonics Merger. The NeoPhotonics Lawsuits further allege that NeoPhotonics’ directors violated Section 20(a) of the Exchange Act by failing to exercise proper control over the person(s) who violated Section 14(a) of the Exchange Act. The complaints seek injunctive relief, rescission or rescissory damages, dissemination of a proxy statement that discloses certain information requested by the plaintiffs, and an award of plaintiffs’ costs, including attorneys’ fees and expenses.

[0001628280-22-012157:notes:229]
Indemnifications

[0001628280-22-012157:notes:230]
In the normal course of business, we enter into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown because claims may be made against us in the future, and we may record charges in the future as a result of these indemnification obligations. As of April 2, 2022, we did not have any material indemnification claims that were probable or reasonably possible.

[0001628280-22-012157:notes:231]
Audit Proceedings

[0001628280-22-012157:notes:232]
We are under audit by various domestic and foreign tax authorities with regards to income tax and indirect tax matters. In some, although not all cases, we have reserved for potential adjustments to our provision for income taxes and accrual of indirect taxes that may result from examinations by these tax authorities or final outcomes in judicial proceedings, and we believe that the final outcome of these examinations, agreements or judicial proceedings will not have a material effect on our results of operations. If events occur which indicate payment of these amounts is unnecessary, the reversal of the liabilities would result in the recognition of benefits in the period we determine the liabilities are no longer necessary. If our estimates of the federal, state, and foreign income tax liabilities and indirect tax liabilities are less than the ultimate assessment, it could result in a further charge to expense.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001628280-22-012157:notes:233]
[same as prior period, unchanged from 0001628280-22-001745:notes:207]

[0001628280-22-012157:notes:234]
[same as prior period, unchanged from 0001628280-22-001745:notes:208]

[0001628280-22-012157:notes:235]
We are an industry leading provider of optical and photonic products defined by revenue and market share addressing a range of end-market applications including optical communications and commercial lasers. We have two operating segments, Optical Communications, which we refer to as OpComms, and Commercial Lasers, which we refer to as Lasers. Our OpComms products address the following markets: telecommunications and data communications (“Telecom and Datacom”), and consumer and industrial (“Consumer and Industrial”). The two operating segments were primarily determined based on how the CODM views and evaluates our operations. Operating results are regularly reviewed by the CODM to make decisions about resources to be allocated to the segments and to assess their performance. Other factors, including market separation and customer specific applications, go-to-market channels, products and manufacturing, are considered in determining the formation of these operating segments.

[0001628280-22-012157:notes:236]
[same as prior period, unchanged from 0001628280-22-001745:notes:210]

[0001628280-22-012157:notes:237]
[same as prior period, unchanged from 0001628280-22-001745:notes:211]

[0001628280-22-012157:notes:238]
[same as prior period, unchanged from 0001628280-22-001745:notes:212]

[0001628280-22-012157:notes:239]
[same as prior period, unchanged from 0001628280-22-001745:notes:213]

[0001628280-22-012157:notes:240]
[same as prior period, unchanged from 0001628280-22-001745:notes:214]

[0001628280-22-012157:notes:241]
[same as prior period, unchanged from 0001628280-22-001745:notes:215]

[0001628280-22-012157:notes:242]
[same as prior period, unchanged from 0001628280-22-001745:notes:216]

[0001628280-22-012157:notes:243]
[same as prior period, unchanged from 0001628280-22-001745:notes:217]

[0001628280-22-012157:notes:244]
[same as prior period, unchanged from 0001628280-22-001745:notes:218]

[0001628280-22-012157:notes:245]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 2, 2022 |  | April 3, 2021 |  | April 2, 2022 |  | April 3, 2021 |
| Net revenue: |  |  |  |  |  |  |  |
| OpComms | $ | 344.2 |  |  | $ | 387.9 |  |  | $ | 1,147.6 |  |  | $ | 1,265.5 |  |
| Lasers | 51.2 |  |  | 31.6 |  |  | 142.9 |  |  | 85.2 |  |
| Net revenue | $ | 395.4 |  |  | $ | 419.5 |  |  | $ | 1,290.5 |  |  | $ | 1,350.7 |  |
| Gross profit: |  |  |  |  |  |  |  |
| OpComms | $ | 168.5 |  |  | $ | 194.3 |  |  | $ | 596.2 |  |  | $ | 660.9 |  |
| Lasers | 27.1 |  |  | 14.9 |  |  | 74.1 |  |  | 39.4 |  |
| Total segment gross profit | 195.6 |  |  | 209.2 |  |  | 670.3 |  |  | 700.3 |  |
| Unallocated corporate items: |  |  |  |  |  |  |  |
| Stock-based compensation | (5.4) |  |  | (5.3) |  |  | (15.2) |  |  | (13.8) |  |
| Amortization of acquired intangibles | (15.6) |  |  | (15.8) |  |  | (47.3) |  |  | (45.8) |  |
| Inventory and fixed asset write down due toproduct line exits | — |  |  | — |  |  | (0.1) |  |  | (0.4) |  |
| Other (charges) gains (1) | (7.4) |  |  | (3.1) |  |  | (0.8) |  |  | (20.0) |  |
| Gross profit | $ | 167.2 |  |  | $ | 185.0 |  |  | $ | 606.9 |  |  | $ | 620.3 |  |

[0001628280-22-012157:notes:246]
(1)   Other (charges) gains of unallocated corporate items for the three months ended April 2, 2022 primarily relate to $5.8 million of charges to acquire components from various brokers to satisfy customer demand.

[0001628280-22-012157:notes:247]
Other (charges) gains of unallocated corporate items for the nine months ended April 2, 2022 primarily relate to $5.8 million of charges to acquire components from various brokers to satisfy customer demand, offset by a $5.9 million gain as a result of selling equipment that was no longer needed after we transferred certain product lines to new production facilities in fiscal 2021.

[0001628280-22-012157:notes:248]
Other (charges) gains of unallocated corporate items for the three and nine months ended April 3, 2021 relate to costs of transferring product lines to new production facilities, including Thailand of $1.4 million and $6.5 million, respectively. We also incurred excess and obsolete inventory charges driven by U.S. trade restrictions and the related decline in demand from Huawei of $1.0 million and $7.7 million during the three and nine months ended April 3, 2021, respectively. Our excess and obsolete inventory charges related to Huawei were offset by $2.1 million of sale of inventory previously written down during the three and nine months ended April 3, 2021. During the nine months ended April 3, 2021, there was also a $5.0 million fixed asset write-off associated with excess capacity related to our Fiber laser business.

[0001628280-22-012157:notes:249]
We operate in three geographic regions: Americas, Asia-Pacific, and EMEA (Europe, Middle East, and Africa). Net revenue is assigned to the geographic region and country where our product is initially shipped. For example, certain customers may request shipment of our product to a contract manufacturer in one country, which may differ from the location of their end customers. The following table presents net revenue by the three geographic regions we operate in and net revenue from countries that generally represented 10% or more of our total net revenue (in millions, except percentage data):

[0001628280-22-012157:notes:250]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 2, 2022 |  | April 3, 2021 |  | April 2, 2022 |  | April 3, 2021 |
|  | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States | $ | 36.3 |  |  | 9.2 | % |  | $ | 38.2 |  |  | 9.1 | % |  | $ | 115.4 |  |  | 8.9 | % |  | $ | 98.2 |  |  | 7.3 | % |
| Mexico | 42.3 |  |  | 10.7 |  |  | 16.3 |  |  | 3.9 |  |  | 113.6 |  |  | 8.8 |  |  | 107.4 |  |  | 8.0 |  |
| Other Americas | 3.0 |  |  | 0.7 |  |  | 3.7 |  |  | 0.9 |  |  | 7.7 |  |  | 0.6 |  |  | 10.5 |  |  | 0.7 |  |
| Total Americas | $ | 81.6 |  |  | 20.6 | % |  | $ | 58.2 |  |  | 13.9 | % |  | $ | 236.7 |  |  | 18.3 | % |  | $ | 216.1 |  |  | 16.0 | % |
| Asia-Pacific: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Hong Kong | $ | 109.2 |  |  | 27.6 | % |  | $ | 134.2 |  |  | 32.0 | % |  | $ | 366.5 |  |  | 28.4 | % |  | $ | 426.6 |  |  | 31.6 | % |
| Philippines | 2.5 |  |  | 0.6 |  |  | 30.9 |  |  | 7.4 |  |  | 20.5 |  |  | 1.6 |  |  | 134.3 |  |  | 9.9 |  |
| South Korea | 50.3 |  |  | 12.7 |  |  | 63.3 |  |  | 15.1 |  |  | 233.3 |  |  | 18.1 |  |  | 185.3 |  |  | 13.7 |  |
| Japan | 44.5 |  |  | 11.3 |  |  | 32.6 |  |  | 7.7 |  |  | 137.3 |  |  | 10.6 |  |  | 81.0 |  |  | 6.0 |  |
| Other Asia-Pacific | 78.9 |  |  | 20.0 |  |  | 64.0 |  |  | 15.2 |  |  | 212.8 |  |  | 16.5 |  |  | 201.2 |  |  | 14.9 |  |
| Total Asia-Pacific | $ | 285.4 |  |  | 72.2 | % |  | $ | 325.0 |  |  | 77.4 | % |  | $ | 970.4 |  |  | 75.2 | % |  | $ | 1,028.4 |  |  | 76.1 | % |
| EMEA | $ | 28.4 |  |  | 7.2 | % |  | $ | 36.3 |  |  | 8.7 | % |  | $ | 83.4 |  |  | 6.5 | % |  | $ | 106.2 |  |  | 7.9 | % |
| Total net revenue | $ | 395.4 |  |  |  |  | $ | 419.5 |  |  |  |  | $ | 1,290.5 |  |  |  |  | $ | 1,350.7 |  |  |  |

[0001628280-22-012157:notes:251]
During the three and nine months ended April 2, 2022 compared to the three and nine months ended April 3, 2021, net revenue from Japan increased and net revenue from Philippines decreased due to changes in our customers’ chosen module integrator for specific new products.

[0001628280-22-012157:notes:252]
During the three and nine months ended April 2, 2022, our net revenue from a single customer, who represented 10% or greater of total net revenue was concentrated with two customers, who collectively accounted for 38% and 43% of our total net revenue, respectively. During the three and nine months ended April 3, 2021, our net revenue from a single customer, which represented 10% or greater of total net revenue was concentrated with two and three customers who collectively accounted for 44% and 53% of our total net revenue, respectively.

[0001628280-22-012157:notes:253]
Our accounts receivable was concentrated with one customer as of April 2, 2022, who represented 12% of gross accounts receivable, compared with two customers as of July 3, 2021, who represented 17% and 14% of gross accounts receivable, respectively.

[0001628280-22-012157:notes:254]
[same as prior period, unchanged from 0001628280-22-001745:notes:227]

[0001628280-22-012157:notes:255]
|  | April 2, 2022 |  | July 3, 2021 |
| Property, plant and equipment, net |  |  |  |
| United States | $ | 111.1 |  |  | $ | 116.7 |  |
| Thailand | 100.9 |  |  | 103.9 |  |
| China | 35.8 |  |  | 41.3 |  |
| Japan | 36.9 |  |  | 36.4 |  |
| Other countries | 71.7 |  |  | 62.8 |  |
| Total property, plant and equipment, net | $ | 356.4 |  |  | $ | 361.1 |  |

[0001628280-22-012157:notes:256]
We purchase a portion of our inventory from contract manufacturers and vendors located primarily in Taiwan, Thailand and Malaysia. During the three and nine months ended April 2, 2022, our net inventory purchases from a single contract manufacturer, which represented 10% or greater of total net purchases, were concentrated with two contract manufacturers, who collectively accounted for 52% and 58% of total net inventory purchases, respectively. During the three and nine months ended April 3, 2021, our net inventory purchases from a single contract manufacturer, which represented 10% or greater of total net purchases, were concentrated with two contract manufacturers, who collectively accounted for 62% and 64% of total net inventory purchases, respectively.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001628280-22-012157:notes:257]
[same as prior period, unchanged from 0001628280-22-001745:notes:230]

[0001628280-22-012157:notes:258]
[same as prior period, unchanged from 0001628280-22-001745:notes:231]

[0001628280-22-012157:notes:259]
[same as prior period, unchanged from 0001628280-22-001745:notes:232]

[0001628280-22-012157:notes:260]
[same as prior period, unchanged from 0001628280-22-001745:notes:233]

[0001628280-22-012157:notes:261]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 2, 2022 |  | April 3, 2021 |  | April 2, 2022 |  | April 3, 2021 |
| OpComms: |  |  |  |  |  |  |  |  |  |  |  |
| Telecom and Datacom | $ | 243.5 |  | 61.6 | % |  | $ | 255.8 |  | 61.0 | % |  | $ | 726.6 |  | 56.3 | % |  | $ | 803.3 |  | 59.5 | % |
| Industrial and Consumer | 100.7 |  | 25.5 |  |  | 132.1 |  | 31.5 | % |  | 421.0 |  | 32.6 |  |  | 462.2 |  | 34.2 | % |
| Total OpComms | $ | 344.2 |  | 87.1 | % |  | $ | 387.9 |  | 92.5 | % |  | $ | 1,147.6 |  | 88.9 | % |  | $ | 1,265.5 |  | 93.7 | % |
| Lasers | 51.2 |  | 12.9 | % |  | 31.6 |  | 7.5 | % |  | 142.9 |  | 11.1 |  |  | 85.2 |  | 6.3 |  |
| Net Revenue | $ | 395.4 |  |  |  | $ | 419.5 |  |  |  | $ | 1,290.5 |  |  |  | $ | 1,350.7 |  |  |

[0001628280-22-012157:notes:262]
[same as prior period, unchanged from 0001628280-22-001745:notes:235]

[0001628280-22-012157:notes:263]
The following table reflects the changes in contract balances for the periods presented (in millions, except percentages):

[0001628280-22-012157:notes:264]
| Contract balances |  | Balance sheet location |  | April 2, 2022 |  | July 3, 2021 |  | Change |  | Percentage Change |
| Accounts receivable, net |  | Accounts receivable, net |  | $ | 242.2 |  |  | $ | 212.8 |  |  | $ | 29.4 |  |  | 13.8 | % |
| Deferred revenue and customer deposits |  | Other current liabilities |  | $ | — |  |  | $ | 0.6 |  |  | $ | (0.6) |  |  | (100.0) | % |
