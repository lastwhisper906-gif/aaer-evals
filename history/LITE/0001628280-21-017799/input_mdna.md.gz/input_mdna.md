# LITE MD&A — 0001628280-21-017799


## mdna

[0001628280-21-017799:mdna:1]
ITEM 7.    MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0001628280-21-017799:mdna:2]
You should read the following discussion in conjunction with the audited consolidated financial statements and the corresponding notes included elsewhere in this Annual Report. This Management’s Discussion and Analysis of Financial Condition and Results of Operations contains forward-looking statements. The matters discussed in these forward-looking statements are subject to risk, uncertainties and other factors that could cause actual results to differ materially from those made, projected or implied in the forward-looking statements. Please see “Risk Factors” and “Forward-Looking Statements” for a discussion of the uncertainties, risks and assumptions associated with these statements.

[0001628280-21-017799:mdna:3]
Overview

[0001628280-21-017799:mdna:4]
We are an industry-leading provider of optical and photonic products, defined by revenue and market share, addressing a range of end-market applications including Optical Communications, which we refer to as OpComms, and Lasers for manufacturing, inspection and life-science applications. We have two operating segments, OpComms and Lasers. The two operating segments were primarily determined based on how the Chief Operating Decision Maker (“CODM”) views and evaluates our operations. Operating results are regularly reviewed by the CODM to make decisions about resources to be allocated to the segments and to assess their performance. Other factors, including market separation and customer specific applications, go-to-market channels, products and manufacturing, are considered in determining the formation of these operating segments.

[0001628280-21-017799:mdna:5]
We believe the global markets in which Lumentum participates have fundamentally robust, long-term trends that increase the need for our photonics products and technologies. We believe the world is becoming more reliant on ever-increasing amounts of data flowing through optical networks and data centers. Lumentum’s products and technology enable the scaling of these optical networks and data centers to higher capacities. We expect the accelerating shift to digital and virtual approaches to all aspects of work and life that is driving staggering amounts of data in the world’s networks and cloud datacenters will continue into the future. Virtual meetings, video calls, and hybrid in-person and virtual environments for work and other aspects of life will continue to drive strong needs for bandwidth growth and present dynamic new technology challenges that our technology addresses. As manufacturers demand higher levels of precision, new materials, and factory and energy efficiency, suppliers of manufacturing tools globally are turning to laser-based approaches, including the types of lasers Lumentum supplies. Laser-based 3D sensing and LiDAR for security, industrial and automotive applications are rapidly developing markets. The technology enables computer vision applications that enhance security, safety, and new functionality in the electronic devices that people rely on every day. The use of LiDAR and in-cabin 3D sensing in automobile and delivery vehicles over time significantly adds to our long-term market opportunity. Frictionless and contactless biometric security and access control is of increasing focus globally given the world’s experience with the COVID-19 pandemic. Additionally, we expect 3D-enabled machine vision solutions to expand significantly in industrial applications in the coming years.

[0001628280-21-017799:mdna:6]
On December 10, 2018, we completed the acquisition of Oclaro, a provider of optical components and modules for the long-haul, metro and data center markets. Refer to “Note 4. Business Combinations” in the notes to consolidated financial statements for further discussion of the merger.

[0001628280-21-017799:mdna:7]
To maintain and grow our market and technology leadership positions, we are continually investing in new and differentiated products and technologies and customer programs that address both nearer-term and longer-term growth opportunities, as well as continually improving and optimizing our operations. Over many years, we have developed close relationships with market leading customers. We seek to use our core optical and photonic technology and our volume manufacturing capability to expand into attractive emerging markets that benefit from advantages that optical or photonics-based solutions provide.

[0001628280-21-017799:mdna:8]
OpComms

[0001628280-21-017799:mdna:9]
Our OpComms products address the following markets: Telecom, Datacom and Consumer and Industrial.

[0001628280-21-017799:mdna:10]
Our OpComms products include a wide range of components, modules and subsystems to support customers including carrier networks for access (local), metro (intracity), long-haul (city-to-city and worldwide) and submarine (undersea) applications. Additionally, our products address enterprise, cloud, and data center applications, including storage-access networks (“SANs”), local-area networks (“LANs”) and wide-area networks (“WANs”). These products enable the transmission and transport of video, audio and data over high-capacity fiber-optic cables. We maintain leading positions in these fast growing OpComms markets through our extensive product portfolio, including reconfigurable optical add/drop multiplexers (“ROADMs”), coherent dense wavelength division multiplexing (“DWDM”) pluggable transceivers, and tunable small form-factor pluggable transceivers. We also sell laser chips for use in manufacturing of high-speed Datacom transceivers.In the Consumer and Industrial market, our OpComms products include laser light sources, which are integrated into 3D sensing

[0001628280-21-017799:mdna:11]
platforms being used in applications for mobile devices, gaming, computers, and other consumer electronics devices. New emerging applications include virtual and augmented reality, as well as automotive and industrial segments. Our products include vertical cavity surface emitting lasers (“VCSELs”) and edge emitting lasers which are used in 3D sensing depth imaging systems. These systems simplify the way people interact with technology by enabling the use of natural user interfaces. Systems are used for biometric identification, surveillance, and process efficiency, among numerous other application spaces. Emerging applications for this technology include various mobile device applications, autonomous vehicles, self-navigating robotics and drones in industrial applications and 3D capture of objects coupled with 3D printing. In addition, our industrial diode lasers are used primarily as pump sources for pulsed and kilowatt class fiber lasers.

[0001628280-21-017799:mdna:12]
Our OpComms customers include Alphabet, Apple, Ciena, Cisco Systems (which acquired Acacia Communications on March 1, 2021, another customer of ours), Huawei Technologies (including HiSilicon), Infinera, Innolight, NEC, Nokia Networks (including Alcatel-Lucent International), and ZTE.

[0001628280-21-017799:mdna:13]
Following the acquisition of Oclaro, during our fiscal 2019, we made several strategic changes to our OpComms business to better position it for growth and profitability. These changes included attaining acquisition cost synergies related to redundant capabilities and divestiture of Telecom lithium niobate modulators and Datacom transceiver modules because of their muted growth and profitability trends. These changes were substantially completed in fiscal 2020. Our strategy of  focusing on the development and sale of Datacom chips has enabled us to participate in the growth of the Datacom and 5G wireless markets.

[0001628280-21-017799:mdna:14]
Related to the strategic changes in our OpComms business, we entered into two strategic transactions to sell some of the discontinued product lines. In the second quarter of fiscal year 2020, we entered into an agreement with Advanced Fiber Resources (Zhuhai) Ltd. (“AFR”), a leading provider of passive optical components, to sell the assets associated with certain Lithium Niobate product lines manufactured by our San Donato site for $17.0 million. The transaction was closed in the third quarter of fiscal year 2020. On April 18, 2019, we closed a transaction selling many of our Datacom transceiver module product lines to Cambridge Industries Group (“CIG”). For further information regarding this transaction, refer to “Note 5. Assets and Liabilities Held For Sale” in the notes to consolidated financial statements.

[0001628280-21-017799:mdna:15]
Lasers

[0001628280-21-017799:mdna:16]
Our Lasers products serve our customers in markets and applications such as sheet metal processing, general manufacturing, biotechnology, graphics and imaging, remote sensing, and precision machining such as drilling in printed circuit boards, wafer singulation, glass cutting and solar cell scribing.

[0001628280-21-017799:mdna:17]
Our Lasers products are used in a variety of OEM applications including diode-pumped solid-state, fiber, diode, direct-diode and gas lasers such as argon-ion and helium-neon lasers. Fiber lasers provide kW-class output powers combined with excellent beam quality and are used in sheet metal processing and metal welding applications. Diode-pumped solid-state lasers provide excellent beam quality, low noise and exceptional reliability and are used in biotechnology, graphics and imaging, remote sensing, materials processing and precision machining applications. Diode and direct-diode lasers address a wide variety of applications, including laser pumping, thermal exposure, illumination, ophthalmology, image recording, printing, plastic welding and selective soldering. Gas lasers such as argon-ion and helium-neon lasers provide a stable, low-cost and reliable solution over a wide range of operating conditions, making them well-suited for complex, high-resolution OEM applications such as flow cytometry, DNA sequencing, graphics and imaging and semiconductor inspection.

[0001628280-21-017799:mdna:18]
We also provide high-powered and ultrafast lasers for the industrial and scientific markets. Manufacturers use high-power, ultrafast lasers to create micro parts for consumer electronics and to process semiconductor, LED, and other types of chips. Use of ultrafast lasers for micromachining applications is being driven primarily by the increasing use of consumer electronics and connected devices globally.

[0001628280-21-017799:mdna:19]
Our Lasers customers include Amada, ASML Holding, Beckman Coulter, DISCO, Electro Scientific Industries (acquired by MKS Instruments in February 2019), Han’s Laser Technology, KLA-Tencor, Lasertec, Life Technologies, and NR Electric.

[0001628280-21-017799:mdna:20]
Termination of Coherent Merger Agreement

[0001628280-21-017799:mdna:21]
On January 18, 2021, we entered into a merger agreement with Coherent, under which we would acquire all outstanding shares of Coherent common stock. In March 2021, Coherent terminated the merger agreement and paid us a termination fee of $217.6 million in accordance with the merger agreement. This gain was offset by $10.1 million of acquisition related expenses and the net amount is presented as “merger termination fee and related costs, net” in our Consolidated Statement of Operations for the year ended July 3, 2021.

[0001628280-21-017799:mdna:22]
Impact of COVID-19 to our Business

[0001628280-21-017799:mdna:23]
The COVID-19 pandemic has caused public health officials to recommend, and governments to enact, precautions to mitigate the spread of the virus, including travel restrictions and bans, extensive social distancing guidelines, closure or restrictions on business and quarantine or other types of “shelter-in-place” orders in many regions of the world. The pandemic and these related responses have caused, and are expected to continue to cause a global slowdown of economic activity (including a decrease in demand for a broad variety of goods and services), disruptions in global supply chains and significant volatility and potential disruption of financial markets. We have adopted several measures in response to the COVID-19 outbreak including complying with local, state or federal orders that require employees to work from home, instructing employees to work from home in certain jurisdictions, limiting the number of employees onsite which slowed our manufacturing operations in certain countries, enhanced use of personal protective equipment and restricting non-critical business travel by our employees.

[0001628280-21-017799:mdna:24]
In the geographies we have operations, we have, in general, been deemed an essential business and been permitted to continue manufacturing and providing new product development operations in a more limited capacity during the pandemic. This stems from our critical role in global supply chains for the world’s communications and health-care systems. Given the continually evolving situation, it is difficult to predict the magnitude and duration of the impact of the COVID-19 pandemic to our markets or precisely when our ability to supply our products will return to full capacity. We are continuing to actively monitor the situation and may take further actions altering our business operations that we determine are in the best interests of our employees, customers, communities, business partners, suppliers, and stockholders, or as required by federal, state, or local authorities. It is not clear what the potential effects any such alterations or modifications may have on our business, including the effects on our customers, employees, and prospects, or on our financial results for fiscal year 2022.

[0001628280-21-017799:mdna:25]
We are actively monitoring the evolving impact of the coronavirus outbreak. The extent to which our operations will continue to be impacted by the outbreak will depend largely on future developments, which are highly uncertain and cannot be accurately predicted, including new information which may emerge concerning the severity of the outbreak and additional variants, the speed, efficacy, and acceptance of vaccine distributions, variant strains of the virus, actions by government authorities and private businesses to contain the severity of the outbreak and emerging variants in various geographies and the speed and trajectory of any recovery from the impact of the pandemic, among other things.

[0001628280-21-017799:mdna:26]
COVID-19 has also created dynamics in the semiconductor component supply chains that have led to shortages of the types of components we and our customers require in our products. These shortages are expected to impact our ability to generate revenue from certain products in early fiscal 2022 and, if our ability to procure needed semiconductor components does not improve, this will impact our ability to supply our products to our customers and may reduce our revenue and profit margin. In addition, if our customers are unable to procure needed semiconductor components, this could reduce their demand for our products and reduce our revenue. The impact of semiconductor component shortages may increase in the near term as supplier and customer buffer inventories and safety stocks are exhausted.

[0001628280-21-017799:mdna:27]
Our primary strategic focus for several years has been technology and product leadership combined with close customer relationships in long-term healthy and growing markets. We believe this strategy is even more apt, and our long-term opportunity is not diminished, with COVID-19. We believe there are long-term opportunities, as the world’s experience with COVID-19 is driving an increasingly digital and virtual world touching all aspects of life and work that increasingly emphasizes communications systems, cloud services, augmented and virtual reality, and enhanced security. Additionally, ever advancing electronic devices are needed to consume, produce, and communicate digital and virtual content. All these trends could drive the need for higher volumes of higher performing optical devices that we could supply. As such, we expect to continue to invest strongly in new products, technology, and customer programs.

[0001628280-21-017799:mdna:28]
For more information on risks associated with the COVID-19 outbreak and regulatory actions, see the section titled “Risk Factors” in Item 1A of Part I.

[0001628280-21-017799:mdna:29]
Critical Accounting Policies and Estimates

[0001628280-21-017799:mdna:30]
Our consolidated financial statements are prepared in accordance with U.S. generally accepted accounting principles (“GAAP”) as set forth in the Financial Accounting Standards Board’s Accounting Standards Codification (“ASC”), and we consider the various staff accounting bulletins and other applicable guidance issued by the United States Securities and Exchange Commission (“SEC”). GAAP, as set forth within the ASC, requires us to make certain estimates, judgments and assumptions. We believe that the estimates, judgments and assumptions upon which we rely are reasonable based upon information available to us at the time that these estimates, judgments and assumptions are made. These estimates, judgments and assumptions can affect the reported amounts of assets and liabilities as of the date of the financial statements as well as the reported amounts of revenues and expenses during the periods presented. To the extent there are differences between these estimates, judgments or assumptions and actual results, our financial statements will be affected. The accounting policies that

[0001628280-21-017799:mdna:31]
reflect our more significant estimates, judgments and assumptions and which we believe are the most critical to aid in fully understanding and evaluating our reported financial results include the following:

[0001628280-21-017799:mdna:32]
•Inventory Valuation

[0001628280-21-017799:mdna:33]
•Revenue Recognition

[0001628280-21-017799:mdna:34]
•Income Taxes

[0001628280-21-017799:mdna:35]
•Long-lived Asset Valuation

[0001628280-21-017799:mdna:36]
•Goodwill

[0001628280-21-017799:mdna:37]
There have been no significant changes to our significant accounting policies as of and for the year ended July 3, 2021.

[0001628280-21-017799:mdna:38]
Inventory Valuation

[0001628280-21-017799:mdna:39]
Inventory is recorded at standard cost, which approximates actual cost computed on a first-in, first-out basis, not in excess of net realizable value. We assess the value of our inventory on a quarterly basis and write down those inventories which are obsolete or in excess of our forecasted demand to the lower of their cost or estimated net realizable value. Our estimates of forecasted demand are based upon our analysis and assumptions including, but not limited to, expected product lifecycles, product development plans and historical usage by product. Our product line management personnel play a key role in our excess review process by providing updated sales forecasts, managing product transitions and working with manufacturing to minimize excess inventory. If actual market conditions are less favorable than our forecasts, or actual demand from our customers is lower than our estimates, we may be required to record additional inventory write-downs. If actual market conditions are more favorable than anticipated, inventory previously written down may be sold, resulting in lower cost of sales and higher income from operations than expected in that period.

[0001628280-21-017799:mdna:40]
Revenue Recognition

[0001628280-21-017799:mdna:41]
Pursuant to Topic 606, our revenues are recognized upon the application of the following steps:

[0001628280-21-017799:mdna:42]
•identification of the contract, or contracts, with a customer;

[0001628280-21-017799:mdna:43]
•identification of the performance obligations in the contract;

[0001628280-21-017799:mdna:44]
•determination of the transaction price;

[0001628280-21-017799:mdna:45]
•allocation of the transaction price to the performance obligations in the contract; and

[0001628280-21-017799:mdna:46]
•recognition of revenues when, or as, the contractual performance obligations are satisfied.

[0001628280-21-017799:mdna:47]
The majority of our revenue comes from product sales, consisting of sales of Lasers and OpComms hardware products to our customers. Our revenue contracts generally include only one performance obligation. Revenues are recognized at a point in time when control of the promised goods or services are transferred to our customers upon shipment or delivery, in an amount that reflects the consideration we expect to be entitled to in exchange for those goods or services. We have entered into vendor managed inventory (“VMI”) programs with our customers. Under these arrangements, we receive purchase orders from our customers, and the inventory is shipped to the VMI location upon receipt of the purchase order. The customer then pulls the inventory from the VMI hub based on its production needs. Revenue under VMI programs is recognized when control transfers to the customer, which is generally once the customer pulls the inventory from the hub.

[0001628280-21-017799:mdna:48]
Revenue from all sales types is recognized at the transaction price. The transaction price is determined based on the consideration to which we will be entitled in exchange for transferring goods or services to the customer, adjusted for estimated variable consideration, if any. We typically estimate the impact on the transaction price for discounts offered to the customer for early payments on receivables or net of accruals for estimated sales returns. These estimates are based on historical returns, analysis of credit memo data and other known factors. Actual returns could differ from these estimates. We allocate the transaction price to each distinct product based on its relative standalone selling price. The product price as specified on the purchase order is considered the standalone selling price as it is an observable input that depicts the price as if sold to a similar customer in similar circumstances.

[0001628280-21-017799:mdna:49]
Taxes assessed by a governmental authority that are both imposed on and concurrent with a specific revenue-producing transaction, that are collected by us from a customer and deposited with the relevant government authority, are excluded from revenue. Our revenue arrangements do not contain significant financing components as our standard payment terms are less than one year.

[0001628280-21-017799:mdna:50]
If a customer pays consideration, or if we have a right to an amount of consideration that is unconditional before we transfer a good or service to the customer, those amounts are classified as deferred revenue or deposits received from customers which are included in other current liabilities or other long-term liabilities when the payment is made or when it is due, whichever is earlier.

[0001628280-21-017799:mdna:51]
Transaction Price Allocated to the Remaining Performance Obligations

[0001628280-21-017799:mdna:52]
Remaining performance obligations represent the transaction price allocated to performance obligations that are unsatisfied or partially unsatisfied as of the end of the reporting period. Unsatisfied and partially unsatisfied performance obligations consist of contract liabilities and non-cancellable backlog. Non-cancellable backlog includes goods and services for which customer purchase orders have been accepted that are scheduled or in the process of being scheduled for shipment. A portion of our revenue arises from vendor-managed inventory arrangements where the timing and volume of customer utilization is difficult to predict.

[0001628280-21-017799:mdna:53]
Warranty

[0001628280-21-017799:mdna:54]
Hardware products regularly include warranties to the end customers such that the product continues to function according to published specifications. We typically offer a twelve-month warranty for most of our products. However, in some instances depending upon the product, specific market, product line and geography in which we operate, and what is common in the industry, our warranties can vary and range from six months to five years. These standard warranties are assurance type warranties and do not offer any services in addition to the assurance that the product will continue working as specified. Therefore, warranties are not considered separate performance obligations in the arrangement. Instead, the expected cost of the warranty is accrued as expense in accordance with authoritative guidance.

[0001628280-21-017799:mdna:55]
We provide reserves for the estimated costs of product warranties at the time revenue is recognized. We estimate the costs of our warranty obligations based on our historical experience of known product failure rates, use of materials to repair or replace defective products and service delivery costs incurred in correcting product failures. In addition, from time to time, specific warranty accruals may be made if unforeseen technical problems arise.

[0001628280-21-017799:mdna:56]
Shipping and Handling Costs

[0001628280-21-017799:mdna:57]
We record shipping and handling costs related to revenue transactions within cost of sales as a period cost.

[0001628280-21-017799:mdna:58]
Contract Costs

[0001628280-21-017799:mdna:59]
We recognize the incremental direct costs of obtaining a contract, which consist of sales commissions, when control over the products they relate to transfers to the customer. Applying the practical expedient, we recognize commissions as expense when incurred, as the amortization period of the commission asset we would have otherwise recognized is less than one year.

[0001628280-21-017799:mdna:60]
Contract Balances

[0001628280-21-017799:mdna:61]
We record accounts receivable when we have an unconditional right to consideration. Contract liabilities are recorded when cash payments are received or due in advance of performance. Contract liabilities consist of advance payments and deferred revenue, where we have unsatisfied performance obligations. Contract liabilities are classified as deferred revenue and customer deposits, and are included in other current liabilities within our Consolidated Balance Sheet. Payment terms vary by customer. The time between invoicing and when payment is due is not significant.

[0001628280-21-017799:mdna:62]
The following table reflects the changes in contract balances as of July 3, 2021 (in millions, except percentages):

[0001628280-21-017799:mdna:63]
| Contract balances | Balance sheet location | July 3, 2021 |  | June 27, 2020 |  | Change |  | Percentage Change |
| Accounts receivable, net | Accounts receivable, net | $212.8 |  | $233.5 |  | $(20.7) |  | (8.9)% |
| Deferred revenue and customer deposits | Other current liabilities | $0.6 |  | $1.9 |  | $(1.3) |  | (68.4)% |

[0001628280-21-017799:mdna:64]
Disaggregation of Revenue

[0001628280-21-017799:mdna:65]
We disaggregate revenue by geography and by product. Refer to “Note 20. Operating Segments and Geographic Information” for a presentation of disaggregated revenue. We do not present other levels of disaggregation, such as by type of products, customer, markets, contracts, duration of contracts, timing of transfer of control and sales channels, as this information is not used by our CODM to manage the business.

[0001628280-21-017799:mdna:66]
Income Taxes

[0001628280-21-017799:mdna:67]
In accordance with the authoritative guidance on accounting for income taxes, we recognize income taxes using an asset and liability approach. This approach requires the recognition of taxes payable or refundable for the current year and deferred tax liabilities and assets for the future tax consequences of events that have been recognized in our consolidated financial

[0001628280-21-017799:mdna:68]
statements or tax returns. The measurement of current and deferred taxes is based on provisions of the enacted tax law, and the effects of future changes in tax laws or rates are not anticipated.

[0001628280-21-017799:mdna:69]
The authoritative guidance provides for recognition of deferred tax assets if the realization of such deferred tax assets is more likely than not to occur based on an evaluation of both positive and negative evidence and the relative weight of the evidence. We consider future growth, forecasted earnings, future taxable income, the mix of earnings in the jurisdictions in which we operate, historical earnings, taxable income in prior years, if carryback is permitted under the law, and prudent and feasible tax planning strategies in determining the need for a valuation allowance. In the event we were to determine that we would not be able to realize all or part of our net deferred tax assets in the future, an adjustment to the deferred tax assets valuation allowance would be charged to earnings in the period in which we make such a determination, or goodwill would be adjusted at our final determination of the valuation allowance related to an acquisition within the measurement period. If we later determine that it is more likely than not that the net deferred tax assets would be realized, we would reverse the applicable portion of the previously provided valuation allowance as an adjustment to earnings at such time.

[0001628280-21-017799:mdna:70]
We are subject to income tax audits by the respective tax authorities of the jurisdictions in which we operate. The determination of our income tax liabilities in each of these jurisdictions requires the interpretation and application of complex, and sometimes uncertain, tax laws and regulations. The authoritative guidance on accounting for income taxes prescribes both recognition and measurement criteria that must be met for the benefit of a tax position to be recognized in the financial statements.  If a tax position taken, or expected to be taken, in a tax return does not meet such recognition or measurement criteria, an unrecognized tax benefit liability is recorded.  If we ultimately determine that an unrecognized tax benefit liability is no longer necessary, we reverse the liability and recognize a tax benefit in the period in which it is determined that the unrecognized tax benefit liability is no longer necessary.

[0001628280-21-017799:mdna:71]
The recognition and measurement of current taxes payable or refundable and deferred tax assets and liabilities requires that we make certain estimates and judgments. Changes to these estimates or a change in judgment may have a material impact on our tax provision in a future period.

[0001628280-21-017799:mdna:72]
Long-lived Asset Valuation

[0001628280-21-017799:mdna:73]
We test long-lived assets for recoverability, at the asset group level, when events or changes in circumstances indicate that their carrying amount may not be recoverable. Circumstances which could trigger a review include, but are not limited to: significant decreases in the market price of the asset, significant adverse changes in the business climate or legal factors, accumulation of costs significantly in excess of the amount originally expected for the acquisition or construction of the asset, current period cash flow or operating losses combined with a history of losses or a forecast of continuing losses associated with the use of the asset, or current expectation that the asset will more likely than not be sold or disposed significantly before the end of its estimated useful life.

[0001628280-21-017799:mdna:74]
Recoverability is assessed based on the difference between the carrying amount of the asset and the sum of the undiscounted cash flows expected to result from the use and the eventual disposal of the asset. An impairment loss is recognized when the carrying amount is not recoverable and exceeds fair value.

[0001628280-21-017799:mdna:75]
Goodwill

[0001628280-21-017799:mdna:76]
Goodwill represents the excess of the purchase price of an acquired business over the fair value of the identifiable assets acquired and liabilities assumed. We test for impairment of goodwill on an annual basis in the fourth quarter and at any other time when events occur or circumstances indicate that the carrying amount of goodwill may not be recoverable.

[0001628280-21-017799:mdna:77]
We have the option to first assess qualitative factors to determine whether it is necessary to perform the quantitative goodwill impairment test. The qualitative factors we assess include long-term prospects of our performance, share price trends and market capitalization, and Company specific events. Unanticipated events and circumstances may occur that affect the accuracy of our assumptions, estimates and judgments. For example, if the price of our common stock were to significantly decrease combined with other adverse changes in market conditions, thus indicating that the underlying fair value of our reporting units may have decreased, we might be required to reassess the value of our goodwill in the period such circumstances were identified.

[0001628280-21-017799:mdna:78]
If we determine that as a result of the qualitative assessment that it is more likely than not (i.e., greater than 50% likelihood) that the fair value of a reporting unit is less than its carrying amount, then the quantitative test is required. Otherwise, no further testing is required. The quantitative goodwill impairment test requires us to estimate the fair value of our reporting units. If the carrying value of a reporting unit exceeds its fair value, the goodwill of that reporting unit is potentially impaired and we record an impairment loss equal to the excess of the carrying value of the reporting unit’s goodwill over its fair value, not to exceed the carrying amount of goodwill. The fair value of each of our goodwill reporting units is generally estimated using a combination of public company multiples and discounted cash flow methodologies.

[0001628280-21-017799:mdna:79]
Based on the impairment analysis performed in the fourth quarter of each year presented, the fair value of our reporting units substantially exceeded the carrying value; as such, our annual qualitative assessment did not indicate that a more detailed quantitative analysis was necessary.

[0001628280-21-017799:mdna:80]
In many cases, the accounting treatment of a particular transaction is specifically dictated by GAAP and does not require management’s judgment in its application. There are also areas in which management’s judgment in selecting among available alternatives would not produce a materially different result. Our senior management has reviewed our critical accounting policies and related disclosures with the Audit Committee of our board of directors.

[0001628280-21-017799:mdna:81]
Recently Issued Accounting Pronouncements

[0001628280-21-017799:mdna:82]
Refer to “Note 2. Recently Issued Accounting Pronouncements” in the notes to consolidated financial statements.

[0001628280-21-017799:mdna:83]
Results of Operations

[0001628280-21-017799:mdna:84]
The results of operations for the periods presented are not necessarily indicative of results to be expected for future periods. The following table summarizes selected Consolidated Statements of Operations items as a percentage of net revenue:

[0001628280-21-017799:mdna:85]
|  | Years Ended |
|  | July 3, 2021 |  | June 27, 2020 |  | June 29, 2019 |
| Segment net revenue: |  |  |  |  |  |
| OpComms | 93.0 | % |  | 90.3 | % |  | 87.5 | % |
| Lasers | 7.0 |  |  | 9.7 |  |  | 12.5 |  |
| Net revenue | 100.0 |  |  | 100.0 |  |  | 100.0 |  |
| Cost of sales | 51.5 |  |  | 58.1 |  |  | 69.8 |  |
| Amortization of acquired developed intangibles | 3.5 |  |  | 3.2 |  |  | 3.0 |  |
| Gross profit | 44.9 |  |  | 38.7 |  |  | 27.2 |  |
| Operating expenses: |  |  |  |  |  |
| Research and development | 12.3 |  |  | 11.8 |  |  | 11.8 |  |
| Selling, general and administrative | 13.9 |  |  | 14.0 |  |  | 12.8 |  |
| Restructuring and related charges | 0.4 |  |  | 0.5 |  |  | 2.0 |  |
| Merger termination fee and related costs, net | (11.9) |  |  | — |  |  | — |  |
| Impairment charges | — |  |  | 0.3 |  |  | 2.0 |  |
| Total operating expenses | 14.7 |  |  | 26.6 |  |  | 28.6 |  |
| Income (loss) from operations | 30.2 |  |  | 12.2 |  |  | (1.4) |  |
| Unrealized gain on derivative liability | — |  |  | — |  |  | 0.6 |  |
| Interest expense | (3.8) |  |  | (3.6) |  |  | (2.3) |  |
| Other income (expense), net | 0.2 |  |  | 1.9 |  |  | 1.0 |  |
| Income (loss) before income taxes | 26.6 |  |  | 10.4 |  |  | (2.1) |  |
| Provision for income taxes | 3.8 |  |  | 2.3 |  |  | 0.2 |  |
| Net income (loss) | 22.8 | % |  | 8.1 | % |  | (2.3) | % |

[0001628280-21-017799:mdna:86]
Financial Data for Fiscal 2021, 2020 and 2019

[0001628280-21-017799:mdna:87]
The following table summarizes selected Consolidated Statements of Operations items (in millions, except for percentages):

[0001628280-21-017799:mdna:88]
|  | 2021 |  | 2020 |  | Change |  | Percentage Change |  | 2020 |  | 2019 |  | Change |  | Percentage Change |
| Segment net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| OpComms | $ | 1,620.7 |  |  | $ | 1,515.1 |  |  | $ | 105.6 |  |  | 7.0 | % |  | $ | 1,515.1 |  |  | $ | 1,370.2 |  |  | $ | 144.9 |  |  | 10.6 | % |
| Lasers | 122.1 |  |  | 163.5 |  |  | (41.4) |  |  | (25.3) |  |  | 163.5 |  |  | 195.1 |  |  | (31.6) |  |  | (16.2) |  |
| Net revenue | $ | 1,742.8 |  |  | $ | 1,678.6 |  |  | $ | 64.2 |  |  | 3.8 | % |  | $ | 1,678.6 |  |  | $ | 1,565.3 |  |  | $ | 113.3 |  |  | 7.2 | % |
| Gross profit | $ | 783.1 |  |  | $ | 650.2 |  |  | $ | 132.9 |  |  | 20.4 | % |  | $ | 650.2 |  |  | $ | 425.9 |  |  | $ | 224.3 |  |  | 52.7 | % |
| Gross margin | 44.9 | % |  | 38.7 | % |  |  |  |  |  | 38.7 | % |  | 27.2 | % |  |  |  |  |
| Research and development | $ | 214.5 |  |  | $ | 198.6 |  |  | $ | 15.9 |  |  | 8.0 | % |  | $ | 198.6 |  |  | $ | 184.6 |  |  | $ | 14.0 |  |  | 7.6 | % |
| Percentage of net revenue | 12.3 | % |  | 11.8 | % |  |  |  |  |  | 11.8 | % |  | 11.8 | % |  |  |  |  |
| Selling, general and administrative | $ | 241.4 |  |  | $ | 235.2 |  |  | $ | 6.2 |  |  | 2.6 | % |  | $ | 235.2 |  |  | $ | 200.3 |  |  | $ | 34.9 |  |  | 17.4 | % |
| Percentage of net revenue | 13.9 | % |  | 14.0 | % |  |  |  |  |  | 14.0 | % |  | 12.8 | % |  |  |  |  |
| Restructuring and related charges | $ | 7.7 |  |  | $ | 8.0 |  |  | $ | (0.3) |  |  | (3.8) | % |  | $ | 8.0 |  |  | $ | 31.9 |  |  | $ | (23.9) |  |  | (74.9) | % |
| Percentage of net revenue | 0.4 | % |  | 0.5 | % |  |  |  |  |  | 0.5 | % |  | 2.0 | % |  |  |  |  |
| Merger termination fee and related costs, net | $ | (207.5) |  |  | $ | — |  |  | $ | (207.5) |  |  | 100.0 | % |  | $ | — |  |  | $ | — |  |  | 0 |  | — | % |
| Percentage of net revenue | (11.9) | % |  | — | % |  |  |  |  |  | — | % |  | — | % |  |  |  |  |
| Impairment charges | $ | — |  |  | $ | 4.3 |  |  | $ | (4.3) |  |  | (100.0) | % |  | $ | 4.3 |  |  | $ | 30.7 |  |  | $ | (26.4) |  |  | (86.0) | % |
| Percentage of net revenue | — | % |  | 0.3 | % |  |  |  |  |  | 0.3 | % |  | 2.0 | % |  |  |  |  |

[0001628280-21-017799:mdna:89]
Net Revenue

[0001628280-21-017799:mdna:90]
Net revenue increased by $64.2 million, or 3.8%, during fiscal 2021 compared to fiscal 2020. This increase was primarily due to $105.6 million higher OpComms net revenue, offset by of $41.4 million lower sales of Lasers.

[0001628280-21-017799:mdna:91]
OpComms net revenue increased by $105.6 million, or 7.0%, during fiscal 2021 compared to fiscal 2020.  Within OpComms, sales of Industrial and Consumer increased $67.7 million and Telecom and Datacom products increased by $37.9 million. The Industrial and Consumer increase was primarily driven by an expansion of the available market due to an increased dollar content of 3D sensing lasers and higher adoption rates of 3D sensing in consumer electronic devices compared with the prior year.  Telecom and Datacom increased by $37.9 million primarily due to market growth and recovery from the impact of COVID-19 supply constraints. Revenue from EML chips for datacenters increased by more than $40.0 million in fiscal 2021 compared to fiscal 2020. These increases, along with growth in Transport product lines, more than offset the $57.2 million of lower sales from product lines we are exiting, such as Datacom transceiver modules and certain Lithium Niobate product lines. These results also include a deferral of $14.8 million of revenue due to delays in 5G deployments in China.

[0001628280-21-017799:mdna:92]
Lasers net revenue decreased by $41.4 million, or 25.3%, during fiscal 2021 compared to fiscal 2020, primarily due to  the reduced customer demand for our kilowatt class fiber lasers as a result of COVID-19.

[0001628280-21-017799:mdna:93]
Net revenue increased by $113.3 million, or 7.2%, during fiscal 2020 compared to fiscal 2019. This increase was primarily due to the increased sales of Telecom and Datacom of $68.9 million and Consumer and Industrial of $76.0 million, offset by decreased sales of Lasers of $31.6 million.

[0001628280-21-017799:mdna:94]
OpComms net revenue increased by $144.9 million, or 10.6%, during fiscal 2020 compared to fiscal 2019, primarily driven by increased sales of Telecom and Datacom products, driven by the acquisition of Oclaro, as well as increased sales in 3D sensing products for mobile devices.

[0001628280-21-017799:mdna:95]
Lasers net revenue decreased by $31.6 million, or 16.2%, during fiscal 2020 compared to fiscal 2019, primarily due to decreased sales of our kilowatt class fiber lasers.

[0001628280-21-017799:mdna:96]
During our fiscal 2021, 2020 and 2019, net revenue generated from a single customer which represented 10% or greater of total net revenue is summarized as follows:

[0001628280-21-017799:mdna:97]
|  | Years Ended |
|  | July 3, 2021 |  | June 27, 2020 |  | June 29, 2019 |
| Apple | 30.2 | % |  | 26.0 | % |  | 21.0 | % |
| Huawei | 10.8 | % |  | 13.2 | % |  | 15.2 | % |
| Ciena | 10.1 | % |  | * |  | 13.7 | % |
| *Represents less than 10% of total net revenue. |  |  |  |  |  |

[0001628280-21-017799:mdna:98]
Revenue by Region

[0001628280-21-017799:mdna:99]
We operate in three geographic regions: Americas, Asia-Pacific and EMEA. Net revenue is assigned to the geographic region and country where our product is initially shipped. For example, certain customers may request shipment of our product to a contract manufacturer in one country; however, the location of the end customers may differ. The following table presents net revenue by the three geographic regions we operate in and net revenue from countries within those regions that generally represented 10% or more of our total net revenue (in millions, except for percentages):

[0001628280-21-017799:mdna:100]
|  |  |  | Years Ended |
|  |  |  |  |  | July 3, 2021 |  | June 27, 2020 |  | June 29, 2019 |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  |  |  |  |  |  |  |  | $ | 133.4 |  |  | 7.7 | % |  | $ | 149.8 |  |  | 8.9 | % |  | $ | 100.9 |  |  | 6.4 | % |
| Mexico |  |  |  |  |  |  |  |  | 134.8 |  |  | 7.7 |  |  | 122.8 |  |  | 7.3 |  |  | 214.9 |  |  | 13.7 |  |
| Other Americas |  |  |  |  |  |  |  |  | 12.1 |  |  | 0.7 |  |  | 5.5 |  |  | 0.3 |  |  | 4.3 |  |  | 0.3 |  |
| Total Americas |  |  |  |  |  |  |  |  | $ | 280.3 |  |  | 16.1 | % |  | $ | 278.1 |  |  | 16.5 | % |  | $ | 320.1 |  |  | 20.4 | % |
| Asia-Pacific: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Hong Kong |  |  |  |  |  |  |  |  | $ | 546.3 |  |  | 31.3 | % |  | $ | 532.0 |  |  | 31.8 | % |  | $ | 387.9 |  |  | 24.8 | % |
| Philippines |  |  |  |  |  |  |  |  | 148.6 |  |  | 8.5 |  |  | 56.3 |  |  | 3.4 |  |  | 52.2 |  |  | 3.3 |  |
| South Korea |  |  |  |  |  |  |  |  | 240.0 |  |  | 13.8 |  |  | 260.9 |  |  | 15.5 |  |  | 162.4 |  |  | 10.4 |  |
| Japan |  |  |  |  |  |  |  |  | 114.7 |  |  | 6.6 |  |  | 137.9 |  |  | 8.2 |  |  | 176.0 |  |  | 11.2 |  |
| Other Asia-Pacific |  |  |  |  |  |  |  |  | 272.7 |  |  | 15.7 |  |  | 289.7 |  |  | 17.2 |  |  | 303.9 |  |  | 19.4 |  |
| Total Asia-Pacific |  |  |  |  |  |  |  |  | $ | 1,322.3 |  |  | 75.9 | % |  | $ | 1,276.8 |  |  | 76.1 | % |  | $ | 1,082.4 |  |  | 69.1 | % |
| EMEA |  |  |  |  |  |  |  |  | $ | 140.2 |  |  | 8.0 | % |  | $ | 123.7 |  |  | 7.4 | % |  | $ | 162.8 |  |  | 10.5 | % |
| Total net revenue |  |  |  |  |  |  |  |  | $ | 1,742.8 |  |  |  |  | $ | 1,678.6 |  |  |  |  | $ | 1,565.3 |  |  |  |

[0001628280-21-017799:mdna:101]
During fiscal 2021, 2020 and 2019, net revenue from customers outside the United States, based on customer shipping location, represented 92.3%, 91.1% and 93.6% of net revenue, respectively.

[0001628280-21-017799:mdna:102]
During fiscal 2021 compared to fiscal 2020, our net revenue from the Philippines grew due to an introduction of a new product to one of our large customers.

[0001628280-21-017799:mdna:103]
Gross Margin and Segment Gross Margin

[0001628280-21-017799:mdna:104]
The following table summarizes segment gross profit and gross margin for fiscal 2021, 2020 and 2019 (in millions, except for percentages):

[0001628280-21-017799:mdna:105]
|  | Gross Profit |  | Gross Margin |
|  | Years Ended |  | Years Ended |
|  | 2021 |  | 2020 |  | 2019 |  | 2021 |  | 2020 |  | 2019 |
| OpComms | $ | 830.2 |  |  | $ | 704.0 |  |  | $ | 534.1 |  |  | 51.2 | % |  | 46.5 | % |  | 39.0 | % |
| Lasers | 57.3 |  |  | 76.2 |  |  | 84.4 |  |  | 46.9 | % |  | 46.6 | % |  | 43.3 | % |
| Segment total | $ | 887.5 |  |  | $ | 780.2 |  |  | $ | 618.5 |  |  | 50.9 | % |  | 46.5 | % |  | 39.5 | % |
| Unallocated corporate items: |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation | (19.2) |  |  | (16.1) |  |  | (15.1) |  |  |  |  |  |  |  |
| Amortization of acquired intangibles | (61.7) |  |  | (53.8) |  |  | (46.6) |  |  |  |  |  |  |  |
| Amortization of inventory fair value adjustments | — |  |  | (5.8) |  |  | (54.6) |  |  |  |  |  |  |  |
| Inventory and fixed asset write down due to product line exits (1) | (0.4) |  |  | (7.0) |  |  | (20.8) |  |  |  |  |  |  |  |
| Integration related costs | — |  |  | (4.9) |  |  | (6.6) |  |  |  |  |  |  |  |
| Other charges (2) | (23.1) |  |  | (42.4) |  |  | (48.9) |  |  |  |  |  |  |  |
| Total | $ | 783.1 |  |  | $ | 650.2 |  |  | $ | 425.9 |  |  | 44.9 | % |  | 38.7 | % |  | 27.2 | % |

[0001628280-21-017799:mdna:106]
(1) In fiscal year 2021, 2020 and 2019, we recorded inventory and fixed assets write down charges of $0.4 million,  $7.0 million and $20.8 million related to the decision to exit the Datacom module and Lithium Niobate product lines.

[0001628280-21-017799:mdna:107]
(2) “Other charges” of unallocated corporate items for the year ended July 3, 2021 and June 27, 2020, primarily include costs of transferring product lines to new production facilities, including Thailand of $6.9 million and $11.5 million, respectively. We also incurred excess and obsolete inventory charges of $7.7 million and $12.8 million driven by the decline in demand from Huawei during the year ended July 3, 2021 and June 27, 2020, respectively. In addition, for the year ended July 3, 2021 and June 27, 2020, we incurred $5.0 million and $6.2 million impairment charges associated with excess capacity related to our Fiber laser business, respectively. Other charges for the year ended June 29, 2019, primarily include costs of transferring product lines to Thailand of $45.8 million.

[0001628280-21-017799:mdna:108]
The unallocated corporate items for the periods presented include the effects of amortization of acquired developed technologies and other intangibles, share-based compensation and certain other charges. We do not allocate these items to the gross margin for each segment because management does not include such information in measuring the performance of the operating segments.

[0001628280-21-017799:mdna:109]
Gross Margin

[0001628280-21-017799:mdna:110]
Gross margin in fiscal 2021 increased to 44.9% from 38.7% in fiscal 2020, due to both higher OpComms and Lasers segment gross margins.  The increase was primarily driven by a higher mix of higher margin product lines, particularly due to increased revenue of 3D sensing, pump lasers and High-Reliability (“HiRel”) components products, which have higher than average margins.

[0001628280-21-017799:mdna:111]
Gross margin in fiscal 2020 increased to 38.7% from 27.2% in fiscal 2019. The increase was primarily driven by better gross margins within Telecom, due to the acquisition of Oclaro, better gross margins within Datacom, due to the sale and exit of our Datacom transceiver module business which historically generated lower margins, increased revenue of our Datacom chip products, which have higher margins, and increased revenue of 3D sensing products for mobile devices, which have higher margins. In addition, in fiscal 2020, we had lower amortization of fair value adjustments related to the Oclaro acquisition of $48.8 million, as well as lower inventory and fixed asset write down charges due to product lines exit of $13.8 million.

[0001628280-21-017799:mdna:112]
We sell products in certain markets that are consolidating, undergoing product, architectural and business model transitions, have high customer concentrations, are highly competitive, are price sensitive and/or are affected by customer seasonal and mix variant buying patterns. We expect these factors to continue to result in variability of our gross margin.

[0001628280-21-017799:mdna:113]
Although the magnitude of the impact of COVID-19 on our business operations remains uncertain and difficult to predict, and this remains a highly dynamic situation, we have experienced, and we expect that we may continue to experience disruptions to our and our customers’ businesses that will adversely impact our business, financial condition and results of operations.

[0001628280-21-017799:mdna:114]
Segment Gross Margin

[0001628280-21-017799:mdna:115]
OpComms

[0001628280-21-017799:mdna:116]
OpComms gross margin in fiscal 2021 increased to 51.2% from 46.5% in fiscal 2020. The increase was primarily due to higher manufacturing volumes, a more profitable mix of products, including higher sales of higher margin Datacom and 3D sensing chips, pump lasers, and HiRel components products.  We also benefited from exiting lower margin product lines, such as Datacom transceiver module and Lithium Niobate modulator products, as well as from ongoing operational improvements.

[0001628280-21-017799:mdna:117]
OpComms gross margin in fiscal 2020 increased to 46.5% from 39.0% in fiscal 2019. The increase was primarily driven by better gross margins within Telecom, due to the acquisition of Oclaro, better gross margins within Datacom, due to the sale of our lower margin Datacom transceiver module business and increased revenue of our higher margin Datacom chip products, and increased revenue of 3D sensing products for mobile devices.

[0001628280-21-017799:mdna:118]
Lasers

[0001628280-21-017799:mdna:119]
Lasers gross margin in fiscal 2021 increased to 46.9% from 46.6% in fiscal 2020. This increase was primarily driven by the streamlining of our manufacturing supply chain related to our kilowatt class fiber products over the past year, offset by the impact of lower manufacturing levels related to COVID-19 reducing customer demand for our kilowatt class fiber products.

[0001628280-21-017799:mdna:120]
Lasers gross margin in fiscal 2020 increased to 46.6% from 43.3% in fiscal 2019. This increase was primarily driven by the streamlining of our manufacturing supply chain related to our kilowatt class fiber products.

[0001628280-21-017799:mdna:121]
Research and Development (“R&D”)

[0001628280-21-017799:mdna:122]
R&D expense increased by $15.9 million, or 8.0%, in fiscal 2021 compared to fiscal 2020. The increase in R&D expense was primarily due to an increase in payroll related expense and stock-based compensation partially due to the additional week in fiscal year 2021, offset by a decrease in R&D materials, as well as a reduction in discretionary travel, primarily due to COVID-19 restrictions.

[0001628280-21-017799:mdna:123]
R&D expense increased by $14.0 million, or 7.6%, in fiscal 2020 compared to fiscal 2019. The increase in R&D expense was primarily due to an increase of $10.7 million in payroll related expense, mainly due to the acquisition of Oclaro, partially offset by the sale of our Datacom transceiver module business. In addition, we had an increase of $7.6 million in investments in key product lines and R&D materials. These increases were offset by $2.8 million higher non-recurring engineering credits from customers and government grants.

[0001628280-21-017799:mdna:124]
We believe that continuing our investments in R&D is critical to attaining our strategic objectives. Despite the uncertainty related to COVID-19 and the global economic outlook, we plan to continue to invest in R&D and new products that we believe will further differentiate us in the marketplace and expect our investment in R&D to increase in absolute dollars in future quarters.

[0001628280-21-017799:mdna:125]
Selling, General and Administrative (“SG&A”)

[0001628280-21-017799:mdna:126]
SG&A expense increased by $6.2 million, or 2.6%, in fiscal 2021 compared to fiscal 2020. The increase in SG&A expense was primarily due to an increase in payroll related expense due to incremental headcount and additional week in fiscal year 2021, an increase in stock-based compensation, and an increase in legal expenses, offset by lower discretionary travel and trade shows, primarily due to COVID-19 restrictions. In addition, during the fourth quarter of fiscal 2021, we sold land and building located in San Jose, California for $23.0 million and recognized a $8.3 million gain in SG&A.

[0001628280-21-017799:mdna:127]
SG&A expense increased by $34.9 million, or 17.4%, in fiscal 2020 compared to fiscal 2019. The increase in SG&A expense was primarily due to the increase in amortization of intangibles of $16.8 million and integration related costs of $9.2 million as a result of the Oclaro acquisition, as well as the increase in payroll related expense of $16.2 million, offset by lower discretionary travel and trade shows of $2.6 million, partially due to COVID-19 restrictions in third and fourth quarters of fiscal 2020.

[0001628280-21-017799:mdna:128]
From time to time, we expect to incur non-core expenses, such as mergers and acquisition-related expenses and litigation expenses, which will likely increase our SG&A expenses and potentially impact our profitability expectations in any particular quarter.

[0001628280-21-017799:mdna:129]
Restructuring and Related Charges

[0001628280-21-017799:mdna:130]
We have initiated various strategic restructuring events primarily intended to reduce costs, consolidate our operations, rationalize the manufacturing of our products and align our business in response to market conditions.

[0001628280-21-017799:mdna:131]
During fiscal 2021, we recorded $7.7 million in restructuring and related charges in our Consolidated Statements of Operations. The charges were mainly attributable to severance charges associated with the decision to move certain manufacturing from San Jose, California, as well as other cost reduction measures taken across the Company impacting all regions.

[0001628280-21-017799:mdna:132]
During fiscal 2020, we recorded $8.0 million in restructuring and related charges in our Consolidated Statements of Operations. The charges were mainly attributable to severance charges associated with the decision to move certain manufacturing from San Jose, California to our facility in Thailand.

[0001628280-21-017799:mdna:133]
During fiscal 2019, we recorded $31.9 million in restructuring and related charges in our Consolidated Statements of Operations, primarily attributable to severance and employee related benefits associated with the wind down of operations for Lithium Niobate modulators and Datacom modules of $21.1 million. In fiscal 2019, we also recorded $1.6 million of lease restructuring charges for the former Oclaro corporate headquarters and restructuring charges primarily associated with acquisition related synergies. In addition, the charges included severance and employee related benefits associated with Oclaro’s executive severance and retention agreements. These retention agreements provided, under certain circumstances, for payments and benefits upon an involuntary termination of employment.

[0001628280-21-017799:mdna:134]
Refer to “Note 14. Restructuring and Related Charges” in the notes to consolidated financial statements.

[0001628280-21-017799:mdna:135]
Merger Termination Fee and Related Costs, Net

[0001628280-21-017799:mdna:136]
On January 18, 2021, we entered into a merger agreement with Coherent, under which we would acquire all outstanding shares of Coherent common stock. In March 2021, Coherent terminated the merger agreement and paid us a termination fee of $217.6 million in accordance with the merger agreement. For the year ended July 3, 2021, we recorded $217.6 million gain related to the receipt of a termination fee from Coherent in March 2021 as a result of the termination of our merger agreement. This gain was offset by $10.1 million of Coherent acquisition related charges and presented as “merger termination fee and related costs, net” in our Consolidated Statements of Operations for the year ended July 3, 2021.

[0001628280-21-017799:mdna:137]
Impairment Charges

[0001628280-21-017799:mdna:138]
In the third quarter of fiscal 2019, we announced our plan to discontinue the development and manufacturing of future Datacom transceiver modules which impacted the California and China based Datacom module teams. As a result of these actions, we recorded impairment charges of $4.3 million and $30.7 million in fiscal 2020 and 2019, respectively, to our long-lived assets that were not deemed to be useful. While we expect strong growth in Datacom volumes in the future, gross margins at the transceiver market level are lower due to extreme competition. Following the Oclaro acquisition, we have a differentiated leadership position across a range of photonic chips on which the Datacom, wireless, and access markets critically rely.

[0001628280-21-017799:mdna:139]
We have had no impairments in fiscal 2021.

[0001628280-21-017799:mdna:140]
Interest Expense

[0001628280-21-017799:mdna:141]
The components of interest expense are as follows for the years presented (in millions):

[0001628280-21-017799:mdna:142]
|  |  |  | Years Ended |
|  |  |  | July 3, 2021 |  | June 27, 2020 |  | June 29, 2019 |
| Interest expense |  |  | $ | (66.7) |  |  | $ | (61.2) |  |  | $ | (36.3) |  |

[0001628280-21-017799:mdna:143]
For fiscal 2021, we recorded interest expense of $66.7 million. The increase in interest expense during fiscal 2021 as compared to fiscal 2020 was mainly driven by the increase in amortization of the debt discount and contractual interest expense of our 2026 Notes issued in December 2019, offset by the decrease in contractual interest expense on our term loan facility (which we repaid in full in the second quarter of fiscal 2020) and a loss on early extinguishment of debt.

[0001628280-21-017799:mdna:144]
For fiscal 2020, we recorded interest expense of $61.2 million. The increase in interest expense during fiscal 2020 as compared to fiscal 2019 was mainly driven by the increase in amortization of the debt discount and contractual interest expense due to the issuance of our 0.50% Convertible Notes due in 2026 (the “2026 Notes”), as well as the loss on early extinguishment of debt of $8.0 million, which represents the write-off of the issuance costs in conjunction with payback of our term loan facility in the second quarter of fiscal 2020.

[0001628280-21-017799:mdna:145]
Other Income, Net

[0001628280-21-017799:mdna:146]
The components of other income (expense), net are as follows for the years presented (in millions):

[0001628280-21-017799:mdna:147]
|  |  |  | Years Ended |  |
|  |  |  | July 3, 2021 |  | June 27, 2020 |  | June 29, 2019 |  |
| Foreign exchange losses, net |  |  | $ | (4.4) |  |  | $ | (1.4) |  |  | $ | (0.6) |  |  |
| Interest and investment income |  |  | 5.7 |  |  | 15.8 |  |  | 13.9 |  |  |
| Other income, net |  |  | 1.5 |  |  | 17.0 |  |  | 2.5 |  |  |
| Total other income (expense), net |  |  | $ | 2.8 |  |  | $ | 31.4 |  |  | $ | 15.8 |  |  |

[0001628280-21-017799:mdna:148]
During fiscal 2021, other income, net decreased by $28.6 million as compared to fiscal 2020 , mainly driven by a gain on the sale of Lithium Niobate modulators business of $13.8 million completed in fiscal 2020 and $10.1 million decrease in interest and investment income due to lower returns from our short-term investments at lower interest rates.

[0001628280-21-017799:mdna:149]
During fiscal 2020, other income, net increased by $15.6 million as compared to fiscal 2019, mainly driven by a gain on the sale of Lithium Niobate modulators business of $13.8 million, completed in fiscal 2020.

[0001628280-21-017799:mdna:150]
Unrealized Gain on Derivative Liability

[0001628280-21-017799:mdna:151]
Unrealized gain on Series A Preferred Stock derivative liability amounted to $8.8 million in fiscal 2019. On November 2, 2018, all 35,805 shares of our Series A Preferred Stock were converted to common stock with the outstanding balance of the embedded derivative liability reclassified to additional paid in capital. Due to this conversion, no further adjustments are required.

[0001628280-21-017799:mdna:152]
For further discussion of our derivative liability, see “Note 11. Non-Controlling Interest Redeemable Convertible Preferred Stock and Derivative Liability” in the notes to consolidated financial statements.

[0001628280-21-017799:mdna:153]
Provision for Income Taxes:

[0001628280-21-017799:mdna:154]
|  |  | Years Ended |
| (in millions) |  | July 3, 2021 |  | June 27, 2020 |  | June 29, 2019 |
| Provision for income taxes |  | $ | 65.8 |  |  | $ | 38.8 |  |  | $ | 3.1 |  |

[0001628280-21-017799:mdna:155]
Our provision for income taxes for fiscal 2021 differs from the 21% U.S. statutory rate primarily due to income tax benefit from earnings of our foreign subsidiaries being taxed at rates that differ from the U.S. statutory rate, which is offset by the tax expense from U.S. income inclusions from Subpart F and GILTI. Further our provision for income taxes includes an income tax benefit from various tax credits and non-U.S. statutory rate changes enacted during the year, offset by an income tax expense from non-deductible stock-based compensation as well as change in valuation allowance because it is not more-likely-than-not that certain deferred tax assets will be realizable in the future.

[0001628280-21-017799:mdna:156]
Our provision for income taxes for fiscal 2020 differs from the 21% U.S. statutory rate primarily due to the income tax benefit of the earnings of our foreign subsidiaries being taxed at rates that differ from the U.S. statutory rate and certain tax credits, which is offset by the tax expense from U.S. income inclusions from Subpart F and GILTI.  Further our provision for income taxes includes an income tax expense from changes in our valuation allowance because it is not more-likely-than-not that certain deferred tax assets will be realized in the future.

[0001628280-21-017799:mdna:157]
Our provision for income taxes for fiscal 2019 differs from the 21% U.S. statutory rate primarily due to the income tax benefit of the earnings of our foreign subsidiaries being taxed at rates that differ from the U.S. statutory rate and tax credits, which is offset by the tax expense from U.S. income inclusions from Subpart F and GILTI.

[0001628280-21-017799:mdna:158]
Contractual Obligations

[0001628280-21-017799:mdna:159]
The following table summarizes our contractual obligations as of July 3, 2021, and the effect such obligations are expected to have on our liquidity and cash flow over the next five years (in millions):

[0001628280-21-017799:mdna:160]
|  | Payments due by period |
|  | Total |  | Less than 1 year |  | 1 - 3 years |  | 3 - 5 years |  | More than 5 years |
| Contractual Obligations |  |  |  |  |  |  |  |  |  |
| Asset retirement obligations | $ | 4.7 |  |  | $ | — |  |  | $ | 1.6 |  |  | $ | 1.7 |  |  | $ | 1.4 |  |
| Operating lease liabilities, including imputed interest (1) | 67.4 |  |  | 14.0 |  |  | 21.7 |  |  | 11.7 |  |  | 20.0 |  |
| Pension plan contributions (2) | 1.0 |  |  | 1.0 |  |  | — |  |  | — |  |  | — |  |
| Purchase obligations (3) | 224.5 |  |  | 211.0 |  |  | 13.4 |  |  | 0.1 |  |  | — |  |
| Convertible notes - principal (4) | 1,500.0 |  |  | — |  |  | 450.0 |  |  | — |  |  | 1,050.0 |  |
| Convertible notes - interest (4) | 32.3 |  |  | 6.4 |  |  | 12.8 |  |  | 10.5 |  |  | 2.6 |  |
| Total | $ | 1,829.9 |  |  | $ | 232.4 |  |  | $ | 499.5 |  |  | $ | 24.0 |  |  | $ | 1,074.0 |  |

[0001628280-21-017799:mdna:161]
(1)  The amounts of operating lease liabilities in the table above do not include any sublease income amounts nor do they include payments for short-term leases or variable lease payments. As of July 3, 2021, we expect to receive sublease income of approximately $3.6 million over the next three years. Refer to “Note 9. Leases” in the notes to consolidated financial statements.

[0001628280-21-017799:mdna:162]
(2) The amount in the preceding table represents planned contributions to our defined benefit plans. Although additional future contributions will be required, the amount and timing of these contributions will be affected by actuarial assumptions, the actual rate of returns on plan assets, the level of market interest rates, legislative changes, and the amount of voluntary contributions to the plan. Any contributions for the following fiscal year and later will depend on the value of the plan assets in the future and thus are uncertain. As such, we have not included any amounts beyond one year in the table above.  Refer to “Note 18. Employee Retirement Plans” in the notes to consolidated financial statements.

[0001628280-21-017799:mdna:163]
(3) Purchase obligations represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Refer to “Note 19. Commitments and Contingencies” in the notes to consolidated financial statements.

[0001628280-21-017799:mdna:164]
(4)  Includes principal and interest on our 0.25% Convertible Notes due in 2024 (the “2024 Notes”) through March 2024, and principal and interest on our 0.50% Convertible Notes due in 2026 (the “2026 Notes” and together with the 2024 Notes, the “Notes”) through December 2026. We have the right to redeem the 2024 Notes and the 2026 Notes in whole or in part at any time on or after March 15, 2024 and on or after December 15, 2026, respectively. The principal balances of our Notes are reflected in the payment periods in the table above based on their respective contractual maturities assuming no conversion.  Refer to “Note 12. Debt” in the notes to consolidated financial statements.

[0001628280-21-017799:mdna:165]
As of July 3, 2021, our other non-current liabilities also include $23.0 million of unrecognized tax benefit for uncertain tax positions. We are unable to reliably estimate the timing of future payments related to uncertain tax positions and therefore have excluded them from the preceding table.

[0001628280-21-017799:mdna:166]
Off-Balance Sheet Arrangements

[0001628280-21-017799:mdna:167]
We do not have any off-balance sheet arrangements, as such term is defined in rules promulgated by the SEC, that have or are reasonably likely to have a current or future effect on our financial condition, changes in financial condition, revenues or expenses, results of operations, liquidity, capital expenditures or capital resources that are material to investors.

[0001628280-21-017799:mdna:168]
Defined Benefit Plans

[0001628280-21-017799:mdna:169]
The Company sponsors defined benefit pension plans covering employees in Japan, Switzerland, and Thailand. Pension plan benefits are based primarily on participants’ compensation and years of service credited as specified under the terms of each country’s plan. Employees are entitled to a lump sum benefit upon retirement or upon certain instances of termination.  The funding policy is consistent with the local requirements of each country. As of July 3, 2021, a defined benefit plan in Switzerland was partially funded, while defined benefit plans in Japan and Thailand were unfunded. As of July 3, 2021, our projected benefit obligations, net in Japan, Switzerland, and Thailand were $2.9 million, $4.8 million, and $3.1 million,

[0001628280-21-017799:mdna:170]
respectively. They were recorded in our Consolidated Balance Sheets as other non-current liabilities and represent the total projected benefit obligation (“PBO”) less the fair value of plan assets.

[0001628280-21-017799:mdna:171]
A key actuarial assumption in calculating the net periodic cost and the PBO is the discount rate. Changes in the discount rate impact the interest cost component of the net periodic benefit cost calculation and PBO due to the fact that the PBO is calculated on a net present value basis. Decreases in the discount rate will generally increase pre-tax cost, recognized expense and the PBO. Increases in the discount rate tend to have the opposite effect. We estimate a 100 basis point decrease or increase in the discount rate would cause a corresponding increase or decrease, respectively, in the PBO of $4.1 million or $(3.5) million, based upon data as of July 3, 2021.

[0001628280-21-017799:mdna:172]
We expect to contribute $1.0 million to our defined benefit pension plans in fiscal 2022.

[0001628280-21-017799:mdna:173]
Financial Condition

[0001628280-21-017799:mdna:174]
Liquidity and Capital Resources

[0001628280-21-017799:mdna:175]
As of July 3, 2021 and June 27, 2020, our cash and cash equivalents of $774.3 million and $298.0 million, respectively, were largely held in the United States. As of July 3, 2021 and June 27, 2020, our short-term investments of $1,171.7 million and $1,255.8 million, respectively, were all held in the United States. Cash equivalents and short-term investments are primarily comprised of money market funds, treasuries, agencies, high quality investment grade fixed income securities, certificates of deposit, and commercial paper. Our investment policy and strategy is focused on the preservation of capital and supporting our liquidity requirements.

[0001628280-21-017799:mdna:176]
The total amount of cash outside the United States held by the non-US entities as of July 3, 2021 was $113.3 million, which was primarily held by entities incorporated in the United Kingdom, the British Virgin Islands, Japan, Hong Kong, China, Canada, and Thailand. Although the cash currently held in the United States as well as the cash generated in the United States from future operations is expected to cover our normal operating requirements, a substantial amount of additional cash could be required for other purposes, such as capital expenditures to support our business and growth, including costs associated with increasing internal manufacturing capabilities, particularly in our Thailand facility, strategic transactions and partnerships, and future acquisitions.

[0001628280-21-017799:mdna:177]
Our intent is to indefinitely reinvest funds held outside the United States and, except for the funds held in the Cayman Islands, the British Virgin Islands, Japan and Hong Kong, our current plans do not demonstrate a need to repatriate them to fund our domestic operations. However, if in the future, we encounter a significant need for liquidity domestically or at a particular location that we cannot fulfill through borrowings, equity offerings, or other internal or external sources, or the cost to bring back the money is not significant from a tax perspective, we may determine that cash repatriations are necessary or desirable. Repatriation could result in additional material taxes. These factors may cause us to have an overall tax rate higher than other companies or higher than our tax rates have been in the past. Additionally, if conditions warrant, we may seek to obtain additional financing through debt or equity sources. To the extent we issue additional shares, our existing stockholders may be diluted. However, any such financing may not be available on terms favorable to us, or may not be available at all.

[0001628280-21-017799:mdna:178]
As of July 3, 2021, the debt component of our 2024 Notes of $390.7 million (principal balance of $450 million maturing in 2024) is presented in short-term liabilities since our stock price exceeded $78.80 for 20 of the last 30 trading days of the quarter ended July 3, 2021 and the 2024 Notes are convertible at the option of the holders. During the year ended July 3, 2021, we received conversion requests for less than $0.1 million principal amount of the 2024 Notes, which were settled in cash in the fourth quarter of fiscal 2021. If the closing price of our stock exceeds $129.08 for 20 of the last 30 trading days of any future quarter, our 2026 Notes would also become convertible at the option of the holders and the debt component would be reclassified to current liabilities in our Consolidated Balance Sheet.

[0001628280-21-017799:mdna:179]
On May 7, 2021, our board of directors approved the two year share buyback program, which authorizes the repurchase of up to $700.0 million of our own shares of common stock, in the open market or in privately negotiated transactions. In the fiscal fourth quarter of 2021, we repurchased 3.1 million shares of our common stock at an average price of $77.84 per share for an aggregate purchase price of $241.0 million. These shares were retired immediately. The price, timing, amount, and method of such repurchases will be determined based on the valuation of market conditions and other factors, at prices determined to be attractive and in the best interests of both Lumentum and our stockholders.

[0001628280-21-017799:mdna:180]
Liquidity and Capital Resources Requirements

[0001628280-21-017799:mdna:181]
We believe that our cash and cash equivalents as of July 3, 2021, and cash flows from our operating activities will be sufficient to meet our liquidity and capital spending requirements for at least the next 12 months. However, if market conditions are favorable, we may evaluate alternatives to opportunistically pursue additional financing.

[0001628280-21-017799:mdna:182]
There are a number of factors that could positively or negatively impact our liquidity position, including:

[0001628280-21-017799:mdna:183]
•global economic conditions which affect demand for our products and services and impact the financial stability of our suppliers and customers, including the impact of COVID-19;

[0001628280-21-017799:mdna:184]
•fluctuations in demand for our products as a result of changes in regulations, tariffs or other trade barriers, and trade relations in general;

[0001628280-21-017799:mdna:185]
•changes in accounts receivable, inventory or other operating assets and liabilities, which affect our working capital;

[0001628280-21-017799:mdna:186]
•increase in capital expenditures to support our business and growth;

[0001628280-21-017799:mdna:187]
•the tendency of customers to delay payments or to negotiate favorable payment terms to manage their own liquidity positions;

[0001628280-21-017799:mdna:188]
•timing of payments to our suppliers;

[0001628280-21-017799:mdna:189]
•volatility in fixed income and credit, which impact the liquidity and valuation of our investment portfolios;

[0001628280-21-017799:mdna:190]
•volatility in foreign exchange markets, which impacts our financial results;

[0001628280-21-017799:mdna:191]
•possible investments or acquisitions of complementary businesses, products or technologies, or other strategic transactions or partnerships;

[0001628280-21-017799:mdna:192]
•issuance of debt or equity securities, or other financing transactions, including bank debt;

[0001628280-21-017799:mdna:193]
•potential funding of pension liabilities either voluntarily or as required by law or regulation; and

[0001628280-21-017799:mdna:194]
•the settlement of any conversion or redemption of the 2024 Notes and the 2026 Notes in cash.

[0001628280-21-017799:mdna:195]
•common stock repurchase under 2021 share buyback program,

[0001628280-21-017799:mdna:196]
Fiscal 2021

[0001628280-21-017799:mdna:197]
As of July 3, 2021, our consolidated balance of cash and cash equivalents increased by $476.3 million, to $774.3 million from $298.0 million as of June 27, 2020. The increase in cash and cash equivalents was mainly due to cash provided by operating activities of $738.7 million and investing activities of $1.0 million, offset by cash used in financing activities of $263.4 million during the year ended July 3, 2021.

[0001628280-21-017799:mdna:198]
Cash provided by operating activities was $738.7 million during the year ended July 3, 2021.  Our net income was $397.3 million for  the year ended July 3, 2021 and included the merger termination fee paid by Coherent, net of related costs of $207.5 million. Cash provided by operating activities was also generated from $339.9 million of non-cash items (such as depreciation, stock-based compensation, amortization of intangibles, amortization of debt discount and debt issuance costs on our Notes, and other non-cash charges), offset by $1.5 million of changes in our operating assets and liabilities.

[0001628280-21-017799:mdna:199]
Cash provided by investing activities of $1.0 million during the year ended July 3, 2021 was primarily attributable to proceeds from maturities and sales of short-term investment, net of purchases of $71.2 million and proceeds from sales of product lines of $1.3 million and sales of property and equipment of $23.3 million. However, we had capital expenditures of $84.8 million and a payment for an asset acquisition of $10.0 million.

[0001628280-21-017799:mdna:200]
Cash used in financing activities of $263.4 million during the year ended July 3, 2021, was primarily resulted from the repurchase of shares of our common stock of $236.0 million and tax payments related to restricted stock of $39.7 million, offset by the proceeds from employee stock plans of $12.6 million.

[0001628280-21-017799:mdna:201]
Fiscal 2020

[0001628280-21-017799:mdna:202]
As of June 27, 2020, our consolidated balance of cash and cash equivalents decreased by $134.6 million, to $298.0 million from $432.6 million as of June 29, 2019. The decrease in cash and cash equivalents was mainly due to cash used in investing activities of $987.7 million, offset by cash provided by operating activities of $524.3 million and cash provided by financing activities of $328.8 million during the year ended June 27, 2020.

[0001628280-21-017799:mdna:203]
Cash provided by operating activities of $524.3 million during the year ended June 27, 2020, primarily resulted from $323.4 million of non-cash items (such as depreciation, stock-based compensation, amortization of intangibles, amortization of debt discount and debt issuance costs on our term loan and the Notes, and other non-cash items), net income of $135.5 million, and $65.4 million of changes in our operating assets and liabilities.

[0001628280-21-017799:mdna:204]
Cash used in investing activities of $987.7 million during the year ended June 27, 2020, was primarily attributable to purchases of short-term investments, net of sales and maturities of $917.8 million. In addition, we had capital expenditures of $86.0 million, payment for asset acquisitions of $4.0 million, offset by proceeds from sales of product lines of $20.1 million.

[0001628280-21-017799:mdna:205]
Cash provided by financing activities of $328.8 million during the year ended June 27, 2020, primarily resulted from the proceeds of the issuance of the 2026 Notes of $1,042.2 million, net of issuance costs, offset by repayment of our term loan facility of $497.5 million and the repurchase of shares of our common stock of $200.0 million.

[0001628280-21-017799:mdna:206]
Fiscal 2019

[0001628280-21-017799:mdna:207]
As of June 29, 2019, our consolidated balance of cash and cash equivalents increased by $35.3 million, to $432.6 million from $397.3 million as of June 30, 2018. The increase in cash and cash equivalents was mainly due to cash provided by financing activities of $485.1 million, primarily related to $490.8 million in proceeds from a term loan, net of debt issuance costs, used to fund the Oclaro acquisition, and cash provided by operating activities of $330.1 million during the year ended June 29, 2019; which was offset by cash used in investing activities of $779.7 million, principally related to net cash of $619.8 million paid to acquire Oclaro.

[0001628280-21-017799:mdna:208]
Cash provided by operating activities of $330.1 million during the year ended June 29, 2019, primarily resulted from $314.4 million of non-cash items (such as depreciation, stock-based compensation, amortization of intangibles, amortization of discount on the 2024 Notes, amortization of the debt issuance costs on the term loan, amortization of fair value adjustment in connection with the acquisition of Oclaro, impairment charges, net of unrealized gain on derivative liability and other non-cash items) and $52.1 million of changes in our operating assets and liabilities, offset by our net loss of $36.4 million.

[0001628280-21-017799:mdna:209]
Cash used in investing activities of $779.7 million during the year ended June 29, 2019, was primarily attributable to $619.8 million paid to acquire all outstanding shares of common stock of Oclaro, net of cash received through the acquisition of Oclaro. In addition, we had capital expenditures of $166.0 million (mainly attributable to the purchase of the property for $54.6 million), payment for asset acquisitions of $1.3 million, purchases of short-term investments, net of sales of $18.1 million, offset by proceeds from sales of product lines of $25.5 million.

[0001628280-21-017799:mdna:210]
Cash provided by financing activities of $485.1 million during the year ended June 29, 2019, primarily resulted from $490.8 million of proceeds from a term loan, net of debt issuance costs, used to partially finance the Oclaro acquisition, offset by the repayment of a term loan of $2.5 million. In addition, we received $9.3 million from the issuance of common stock under our employee stock plan, offset by the repayment of finance lease obligations of $8.8 million, tax payments related to restricted stock of $2.4 million, a payment of an acquisition related holdback of $1.0 million, and dividend payments on our Series A Preferred Stock of $0.7 million.
