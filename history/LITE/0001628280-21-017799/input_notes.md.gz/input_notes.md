# LITE notes — 0001628280-21-017799


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001628280-21-017799:notes:1]
Portions of the information called for by Part III of this Annual Report on Form 10-K is hereby incorporated by reference from the definitive proxy statement for the Registrant’s annual meeting of stockholders, which will be filed with the Securities and Exchange Commission not later than 120 days after the Registrant’s fiscal year ended July 3, 2021.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001628280-21-017799:notes:2]
Note 1. Description of Business and Summary of Significant Accounting Policies

[0001628280-21-017799:notes:3]
Description of Business

[0001628280-21-017799:notes:4]
Lumentum Holdings Inc. (“we,” “us,” “our”, “Lumentum” or the “Company”) is an industry-leading provider of optical and photonic products defined by revenue and market share addressing a range of end market applications including Optical Communications (“OpComms”) and Commercial Lasers (“Lasers”) for manufacturing, inspection and life-science applications. We seek to use our core optical and photonic technology, and our volume manufacturing capability, to expand into attractive emerging markets that benefit from advantages that optical or photonics-based solutions provide, including 3D sensing for consumer electronics and diode light sources for a variety of consumer and industrial applications. The majority of our customers tend to be original equipment manufacturers (“OEMs”) that incorporate our products into their products which then address end-market applications. For example, we sell fiber optic components that network equipment manufacturers (“NEMs”) assemble into communications networking systems, which they sell to network service providers, operators or enterprises with their own networks. Similarly, many of our customers for our Lasers products incorporate our products into tools they produce, which are used for manufacturing processes by their customers. For 3D sensing, we sell diode lasers to manufacturers of consumer electronics products for mobile, personal computing, gaming, and other applications who then integrate our devices within their products, for eventual resale to consumers and also into other industrial applications.

[0001628280-21-017799:notes:5]
Basis of Presentation

[0001628280-21-017799:notes:6]
The preparation of the consolidated financial statements in accordance with U.S. generally accepted accounting principles (“GAAP”) requires management to make estimates and assumptions that affect the amounts reported in our consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates. Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are inventory valuation, revenue recognition, income taxes, long-lived asset valuation and goodwill.

[0001628280-21-017799:notes:7]
The COVID-19 pandemic has created and may continue to create significant uncertainty in global financial markets, which has disrupted and harmed, and may continue to disrupt and harm, the Company's business, financial condition, and results of operations. The extent of the impact of COVID-19 on the Company's operational and financial performance will depend on certain developments, including but not limited to the duration and spread of the outbreak, duration of local, state and federal issued public health orders in each jurisdiction where we operate or in which our customers and suppliers operate, impact on our customers and our sales cycles, impact on our supply chain and manufacturing partners, impact on our employees and impact on regional and worldwide economies and financial markets in general, all of which are uncertain and cannot be predicted. The Company assessed the potential impact that this pandemic has on our estimates as of July 3, 2021 and through the date of this report and determined that there were no material impacts.

[0001628280-21-017799:notes:8]
Fiscal Years

[0001628280-21-017799:notes:9]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Every fifth or sixth fiscal year will have a 53-week period. The additional week in a 53-week year is added to the third quarter, making such quarter consist of 14 weeks. Our fiscal 2021 is a 53-week year, ending on July 3, 2021. Our fiscal 2020 and 2019 ended on June 27, 2020 and  June 29, 2019, respectively, and were 52-week years.

[0001628280-21-017799:notes:10]
Principles of Consolidation

[0001628280-21-017799:notes:11]
The consolidated financial statements are prepared in accordance with GAAP and includes the accounts of Lumentum Holdings Inc. and its wholly-owned subsidiaries. Intercompany transactions and balances are fully eliminated in consolidation.

[0001628280-21-017799:notes:12]
On December 10, 2018, we completed our merger with Oclaro, Inc. (“Oclaro”), a provider of optical components and modules for the long-haul, metro and data center markets. Our consolidated financial statements include the operating results of Oclaro beginning from the date of acquisition. Refer to “Note 4. Business Combinations” for further discussion of the merger.

[0001628280-21-017799:notes:13]
Termination of Coherent Merger Agreement

[0001628280-21-017799:notes:14]
On January 18, 2021, Lumentum and Coherent, Inc. (“Coherent”) entered into a merger agreement (the “merger agreement”), under which Lumentum would acquire all outstanding shares of Coherent common stock. As of the date of the

[0001628280-21-017799:notes:15]
merger agreement, the total transaction consideration was approximately $5.7 billion. In March 2021, Coherent terminated the merger agreement and paid Lumentum a termination fee of $217.6 million in accordance with the merger agreement. This gain was offset by $10.1 million of acquisition-related expenses and the net amount is presented as “merger termination fee and related costs, net” in our Consolidated Statement of Operations for the year ended July 3, 2021.

[0001628280-21-017799:notes:16]
Summary of Significant Accounting Policies

[0001628280-21-017799:notes:17]
Our significant accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. We believe that of our significant accounting policies described below, involve a greater degree of judgment and complexity and are the most critical to aid in fully understanding and evaluating our consolidated financial statements. These policies include inventory valuation, revenue recognition, income taxes, long-lived asset valuation and goodwill. For a description of our critical accounting policies, also refer to “Management’s Discussion and Analysis of Financial Condition and Results of Operations”, Critical Accounting Policies and Estimates.

[0001628280-21-017799:notes:18]
Cash Equivalents

[0001628280-21-017799:notes:19]
We consider highly-liquid fixed income securities with original maturities of three months or less at the time of purchase to be cash equivalents. As of fiscal year ended July 3, 2021, our cash equivalents consist of money market funds, corporate debt securities, and commercial paper.

[0001628280-21-017799:notes:20]
Short-Term Investments

[0001628280-21-017799:notes:21]
We classify our investments in debt securities as available-for-sale and record these investments at fair value. Investments with an original maturity of three months or less at the date of purchase are considered cash equivalents, while all other investments are classified as short-term based on management’s intent and ability to use the funds in current operations. Unrealized gains and losses are reported as a component of other comprehensive income (loss). Realized gains and losses are determined based on the specific identification method, and are reflected as other income (expense), net in our Consolidated Statements of Operations.

[0001628280-21-017799:notes:22]
We regularly review our investment portfolio to identify and evaluate investments that have indicators of possible impairment. Factors considered in determining whether a loss is other-than-temporary include, but are not limited to: the length of time and extent a security’s fair value has been below its cost, the financial condition and near-term prospects of the investee, the credit quality of the security’s issuer, likelihood of recovery and our intent and ability to hold the security for a period of time sufficient to allow for any anticipated recovery in value. For our debt instruments, we also evaluate whether we have the intent to sell the security or it is more likely than not that we will be required to sell the security before recovery of its cost basis.

[0001628280-21-017799:notes:23]
Fair Value of Financial Instruments

[0001628280-21-017799:notes:24]
We define fair value as the price that would be received from selling an asset, or paid to transfer a liability, in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities which are required to be recorded at fair value, we consider the principal or most advantageous market in which to transact and the market-based risk. We apply fair value accounting for all financial assets and liabilities that are recognized or disclosed at fair value in the financial statements on a recurring basis. The carrying amounts reported in the consolidated financial statements approximate the fair value for cash, accounts receivable, accounts payable and accrued liabilities due to their short-term nature.

[0001628280-21-017799:notes:25]
Basic and Diluted Net Income (Loss) per Common Share

[0001628280-21-017799:notes:26]
Basic income (loss) per share is computed by dividing net income (loss) available to common stockholders by the weighted average number of common shares outstanding during the reporting period. The weighted average number of shares is calculated by taking the number of shares outstanding and weighting them by the amount of time that they were outstanding.  Diluted earnings per share reflects the potential dilution that could occur if stock options, preferred stock, and other commitments to issue common stock were exercised or equity awards vest resulting in the issuance of common stock that could share in the earnings of the Company.

[0001628280-21-017799:notes:27]
Diluted loss per share is the same as basic loss per share during periods where net losses are incurred since the inclusion of the potential common stock equivalents would be anti-dilutive as a result of the net loss.

[0001628280-21-017799:notes:28]
Our Series A Preferred Stock was considered a participating security where the holders of Series A Preferred Stock had the right to participate in undistributed earnings with holders of common stock. On November 2, 2018, the remaining 35,805 shares of our Series A Preferred Stock were converted into 1.5 million shares of our common stock. Refer to “Note 11. Non-Controlling Interest Redeemable Convertible Preferred Stock and Derivative Liability” for further discussion. Prior to conversion, the holders of our Series A Preferred Stock were entitled to share in dividends, on an as-converted basis, if the holders of our common stock were to receive dividends. Up through the date of conversion, we used the two-class method to compute earnings per share. The two-class method is an earnings allocation formula that determines earnings per share for each class of common stock and participating security according to dividends declared (or accumulated) and participation rights in undistributed earnings. In determining the amount of net earnings to allocate to common stockholders, earnings are allocated to both common and participating securities based on their respective weighted-average shares outstanding during the period. Diluted earnings per common share is calculated similar to basic earnings per common share except that it gives effect to all potentially dilutive common stock equivalents outstanding for the period, using the treasury stock method.

[0001628280-21-017799:notes:29]
Potentially dilutive common shares result from the assumed exercise of outstanding stock options, assumed vesting of outstanding equity awards, assumed issuance of stock under the employee stock purchase plan, and assumed conversion of our outstanding $450.0 million in aggregate principal amount of 0.25% Convertible Notes due in 2024 (the “2024 Notes”) and $1,050.0 million in aggregate principal amount of 0.50% Convertible Notes due in 2026 (the “2026 Notes” and together with the 2024 Notes, the “convertible notes”), all using the treasury stock method as we have the ability and intent to settle the face value of the convertible notes in cash.

[0001628280-21-017799:notes:30]
The dilutive effect of securities from the 2015 Equity Incentive Plan is reflected in diluted earnings per share by application of the treasury stock method, which includes consideration of unamortized share-based compensation expense and the dilutive effect of in-the-money options and non-vested restricted stock units. Under the treasury stock method, the amount the employee must pay for exercising stock options and the amount of unamortized share-based compensation expense are collectively assumed to be used to repurchase hypothetical shares. An increase in the fair value of our common stock can result in a greater dilutive effect from potentially dilutive awards.

[0001628280-21-017799:notes:31]
Anti-dilutive potential shares from 2015 Equity Incentive Plan are excluded from the calculation of diluted earnings per share if their exercise price exceeded the average market price during the period or the share-based awards were determined to be anti-dilutive based on applying the treasury stock method.

[0001628280-21-017799:notes:32]
Inventory Valuation

[0001628280-21-017799:notes:33]
Inventory is recorded at standard cost, which approximates actual cost computed on a first-in, first-out basis, not in excess of net realizable value. We assess the value of our inventory on a quarterly basis and write down those inventories which are obsolete or in excess of our forecasted demand to the lower of their cost or estimated net realizable value. Our estimates of forecasted demand are based upon our analysis and assumptions including, but not limited to, expected product lifecycles, product development plans and historical usage by product. Our product line management personnel play a key role in our excess review process by providing updated sales forecasts, managing product transitions and working with manufacturing to minimize excess inventory. If actual market conditions are less favorable than our forecasts, or actual demand from our customers is lower than our estimates, we may be required to record additional inventory write-downs. If actual market conditions are more favorable than anticipated, inventory previously written down may be sold, resulting in lower cost of sales and higher income from operations than expected in that period.

[0001628280-21-017799:notes:34]
Leases

[0001628280-21-017799:notes:35]
We adopted Topic 842 on June 30, 2019, the first day of fiscal year 2020, using the modified retrospective transition approach.

[0001628280-21-017799:notes:36]
We determine if an arrangement is a lease at inception for arrangements with an initial term of more than 12 months, and classify it as either a finance or operating lease.

[0001628280-21-017799:notes:37]
Finance leases are generally those that allow us to substantially utilize or pay for the entire asset over its estimated useful life. Finance leases are recorded in property, plant and equipment, net, and finance lease liabilities within other current and other non-current liabilities on our Consolidated Balance Sheets. We have lease arrangements with lease and non-lease components, and the non-lease components for our finance leases are accounted for separately, based on estimated stand-alone values, and are not included in the initial measurement of our finance lease assets and corresponding liabilities. Finance lease assets are amortized in operating expenses on a straight-line basis over the shorter of the estimated useful lives of the assets or

[0001628280-21-017799:notes:38]
the lease term, with the interest component included in interest expense and recognized using the effective interest method over the lease term.

[0001628280-21-017799:notes:39]
Operating leases are recorded in operating lease right-of-use assets, net, and operating lease liabilities, current and non-current on our Consolidated Balance Sheets. For operating leases of buildings, we account for non-lease components, such as common area maintenance, as a component of the lease, and include it in the initial measurement of our operating lease assets and corresponding liabilities. Operating lease assets are amortized on a straight-line basis in operating expenses over the lease term.

[0001628280-21-017799:notes:40]
Our lease liabilities are recognized based on the present value of the remaining fixed lease payments, over the lease term, using a discount rate of similarly secured borrowings available to us. For the purpose of lease liability measurement, we consider only payments that are fixed and determinable at the time of commencement. Any variable payments that depend on an index or rate are expensed as incurred. Our lease terms may include options to extend when it is reasonably certain that we will exercise that option. Our lease assets also include any lease payments made and exclude any lease incentives received prior to commencement. Our lease assets are tested for impairment in the same manner as long-lived assets used in operations. We generally recognize sublease income on a straight-line basis over the sublease term.

[0001628280-21-017799:notes:41]
Revenue Recognition

[0001628280-21-017799:notes:42]
Pursuant to Topic 606, our revenues are recognized upon the application of the following steps:

[0001628280-21-017799:notes:43]
•identification of the contract, or contracts, with a customer;

[0001628280-21-017799:notes:44]
•identification of the performance obligations in the contract;

[0001628280-21-017799:notes:45]
•determination of the transaction price;

[0001628280-21-017799:notes:46]
•allocation of the transaction price to the performance obligations in the contract; and

[0001628280-21-017799:notes:47]
•recognition of revenues when, or as, the contractual performance obligations are satisfied.

[0001628280-21-017799:notes:48]
The majority of our revenue comes from product sales, consisting of sales of Lasers and OpComms hardware products to our customers. Our revenue contracts generally include only one performance obligation. Revenues are recognized at a point in time when control of the promised goods or services are transferred to our customers upon shipment or delivery of goods or rendering of services, in an amount that reflects the consideration we expect to be entitled to in exchange for those goods or services. We have entered into vendor managed inventory (“VMI”) programs with our customers. Under these arrangements, we receive purchase orders from our customers, and the inventory is shipped to the VMI location upon receipt of the purchase order. The customer then pulls the inventory from the VMI hub based on its production needs. Revenue under VMI programs is recognized when control transfers to the customer, which is generally once the customer pulls the inventory from the hub.

[0001628280-21-017799:notes:49]
Revenue from all sales types is recognized at the transaction price. The transaction price is determined based on the consideration to which we will be entitled in exchange for transferring goods or services to the customer adjusted for estimated variable consideration, if any. We typically estimate the impact on the transaction price for discounts offered to the customers for early payments on receivables or net of accruals for estimated sales returns. These estimates are based on historical returns, analysis of credit memo data and other known factors. Actual returns could differ from these estimates. We allocate the transaction price to each distinct product based on its relative standalone selling price. The product price as specified on the purchase order is considered the standalone selling price as it is an observable input that depicts the price as if sold to a similar customer in similar circumstances.

[0001628280-21-017799:notes:50]
Taxes assessed by a governmental authority that are both imposed on and concurrent with a specific revenue-producing transaction, that are collected by us from a customer and deposited with the relevant government authority, are excluded from revenue.

[0001628280-21-017799:notes:51]
Our revenue arrangements do not contain significant financing components as our standard payment terms are less than one year.

[0001628280-21-017799:notes:52]
If a customer pays consideration, or the Company has a right to an amount of consideration that is unconditional before we transfer a good or service to the customer, those amounts are classified as deferred revenue or deposits received from customers which are included in other current liabilities or other long-term liabilities when the payment is made or it is due, whichever is earlier.

[0001628280-21-017799:notes:53]
Transaction Price Allocated to the Remaining Performance Obligations

[0001628280-21-017799:notes:54]
Remaining performance obligations represent the transaction price allocated to performances obligations that are unsatisfied or partially unsatisfied as of the end of the reporting period. Unsatisfied and partially unsatisfied performance obligations consist of contract liabilities and non-cancellable backlog. Non-cancellable backlog includes goods and services for which customer purchase orders have been accepted that are scheduled or in the process of being scheduled for shipment. A portion of our revenue arises from vendor managed inventory arrangements where the timing and volume of customer utilization is difficult to predict.

[0001628280-21-017799:notes:55]
Deferred revenue at July 3, 2021 and June 27, 2020 was $0.6 million and $1.9 million, respectively, which was recorded in other current liabilities within the Consolidated Balance Sheets. During fiscal year 2021 and 2020, we recognized $1.7 million  and $1.1 million of revenue that was included in deferred revenue as of June 27, 2020 and June 29, 2019, respectively.

[0001628280-21-017799:notes:56]
Warranty

[0001628280-21-017799:notes:57]
Hardware products regularly include warranties to the end customers such that the product continues to function according to published specifications. We typically offer a twelve month warranty for most of our products. However, in some instances depending upon the product, specific market, product line and geography in which we operate, and what is common in the industry, our warranties can vary and range from six months to five years. These standard warranties are assurance type warranties and do not offer any services in addition to the assurance that the product will continue working as specified. Therefore, warranties are not considered separate performance obligations in the arrangement. Instead, the expected cost of warranty is accrued as expense in accordance with authoritative guidance.

[0001628280-21-017799:notes:58]
We provide reserves for the estimated costs of product warranties at the time revenue is recognized. We estimate the costs of our warranty obligations based on our historical experience of known product failure rates, use of materials to repair or replace defective products and service delivery costs incurred in correcting product failures. In addition, from time to time, specific warranty accruals may be made if unforeseen technical problems arise.

[0001628280-21-017799:notes:59]
Shipping and Handling Costs

[0001628280-21-017799:notes:60]
We record shipping and handling costs related to revenue transactions within cost of sales as a period cost.

[0001628280-21-017799:notes:61]
Contract Costs

[0001628280-21-017799:notes:62]
The Company recognizes the incremental direct costs of obtaining a contract, which consist of sales commissions, when control over the products they relate to transfers to the customer. Applying the practical expedient, the Company recognizes commissions as expense when incurred, as the amortization period of the commission asset the Company would have otherwise recognized is less than one year.

[0001628280-21-017799:notes:63]
Contract Balances

[0001628280-21-017799:notes:64]
The Company records accounts receivable when it has an unconditional right to consideration. Contract liabilities are recorded when cash payments are received or due in advance of performance. Contract liabilities consist of advance payments and deferred revenue, where the Company has unsatisfied performance obligations. Contract liabilities are classified as deferred revenue and customer deposits, and are included in other current liabilities within our Consolidated Balance Sheet. Payment terms vary by customer. The time between invoicing and when payment is due is not significant.

[0001628280-21-017799:notes:65]
The following table reflects the changes in contract balances as of July 3, 2021 (in millions, except percentages):

[0001628280-21-017799:notes:66]
| Contract balances | Balance sheet location | July 3, 2021 |  | June 27, 2020 |  | Change |  | Percentage Change |
| Accounts receivable, net | Accounts receivable, net | $212.8 |  | $233.5 |  | $(20.7) |  | (8.9)% |
| Deferred revenue and customer deposits | Other current liabilities | $0.6 |  | $1.9 |  | $(1.3) |  | (68.4)% |

[0001628280-21-017799:notes:67]
Disaggregation of Revenue

[0001628280-21-017799:notes:68]
We disaggregate revenue by geography and by product. Refer to “Note 20. Operating Segments and Geographic Information” for a presentation of disaggregated revenue. We do not present other levels of disaggregation, such as by type of products, customer, markets, contracts, duration of contracts, timing of transfer of control and sales channels, as this information is not used by our Chief Operating Decision Maker to manage the business.

[0001628280-21-017799:notes:69]
Income Taxes

[0001628280-21-017799:notes:70]
In accordance with the authoritative guidance on accounting for income taxes, we recognize income taxes using an asset and liability approach. This approach requires the recognition of taxes payable or refundable for the current year and deferred tax liabilities and assets for the future tax consequences of events that have been recognized in our consolidated financial statements or tax returns. The measurement of current and deferred taxes is based on provisions of the enacted tax law, and the effects of future changes in tax laws or rates are not anticipated.

[0001628280-21-017799:notes:71]
The authoritative guidance provides for recognition of deferred tax assets if the realization of such deferred tax assets is more likely than not to occur based on an evaluation of both positive and negative evidence and the relative weight of the evidence. We consider future growth, forecasted earnings, future taxable income, the mix of earnings in the jurisdictions in which we operate, historical earnings, taxable income in prior years, if carryback is permitted under the law, and prudent and feasible tax planning strategies in determining the need for a valuation allowance. In the event we were to determine that we would not be able to realize all or part of our net deferred tax assets in the future, an adjustment to the deferred tax assets valuation allowance would be charged to earnings in the period in which we make such a determination, or goodwill would be adjusted at our final determination of the valuation allowance related to an acquisition within the measurement period. If we later determine that it is more likely than not that the net deferred tax assets would be realized, we would reverse the applicable portion of the previously provided valuation allowance as an adjustment to earnings at such time.

[0001628280-21-017799:notes:72]
We are subject to income tax audits by the respective tax authorities of the jurisdictions in which we operate. The determination of our income tax liabilities in each of these jurisdictions requires the interpretation and application of complex, and sometimes uncertain, tax laws and regulations. The authoritative guidance on accounting for income taxes prescribes both recognition and measurement criteria that must be met for the benefit of a tax position to be recognized in the financial statements. If a tax position taken, or expected to be taken, in a tax return does not meet such recognition or measurement criteria, an unrecognized tax benefit liability is recorded.  If we ultimately determine that an unrecognized tax benefit liability is no longer necessary, we reverse the liability and recognize a tax benefit in the period in which it is determined that the unrecognized tax benefit liability is no longer necessary.

[0001628280-21-017799:notes:73]
The recognition and measurement of current taxes payable or refundable and deferred tax assets and liabilities requires that we make certain estimates and judgments. Changes to these estimates or a change in judgment may have a material impact on our tax provision in a future period.

[0001628280-21-017799:notes:74]
Property, Plant and Equipment

[0001628280-21-017799:notes:75]
Property, plant and equipment are stated at cost. Depreciation is computed by the straight-line method generally over the following estimated useful lives of the assets: 10 to 40 years for building and improvements, 3 to 5 years for machinery and equipment, and 2 to 5 years for furniture, fixtures, software and office equipment. Leasehold improvements are amortized using the straight-line method over the shorter of the estimated useful lives of the assets or the term of the lease.

[0001628280-21-017799:notes:76]
Goodwill

[0001628280-21-017799:notes:77]
Goodwill represents the excess of the purchase price of an acquired business over the fair value of the identifiable assets acquired and liabilities assumed. We test for impairment of goodwill on an annual basis in the fourth quarter and at any other time when events occur or circumstances indicate that the carrying amount of goodwill may not be recoverable.

[0001628280-21-017799:notes:78]
We have the option to first assess qualitative factors to determine whether it is necessary to perform the quantitative goodwill impairment test. The qualitative factors we assess include long-term prospects of our performance, share price trends and market capitalization, and Company specific events. Unanticipated events and circumstances may occur that affect the accuracy of our assumptions, estimates and judgments. For example, if the price of our common stock were to significantly decrease combined with other adverse changes in market conditions, thus indicating that the underlying fair value of our reporting units may have decreased, we might be required to reassess the value of our goodwill in the period such circumstances were identified.

[0001628280-21-017799:notes:79]
If we determine that as a result of the qualitative assessment that it is more likely than not (i.e., greater than 50% likelihood) that the fair value of a reporting unit is less than its carrying amount, then the quantitative test is required. Otherwise, no further testing is required. The quantitative goodwill impairment test requires us to estimate the fair value of our reporting units. If the carrying value of a reporting unit exceeds its fair value, the goodwill of that reporting unit is potentially impaired and we record an impairment loss equal to the excess of the carrying value of the reporting unit over its fair value, not

[0001628280-21-017799:notes:80]
to exceed the carrying amount of goodwill. The fair value of each of our goodwill reporting units is generally estimated using a combination of public company multiples and discounted cash flow methodologies.

[0001628280-21-017799:notes:81]
Based on the impairment analysis performed in the fourth quarter of each year presented, the fair value of each of our reporting units substantially exceeded the carrying value; as such, our annual qualitative assessment did not indicate that a more detailed quantitative analysis was necessary.

[0001628280-21-017799:notes:82]
Intangible Assets

[0001628280-21-017799:notes:83]
Intangible assets consist primarily of intangible assets purchased through acquisitions. Purchased intangible assets include acquired developed technologies (developed and core technology), customer relationships, in-process research and development, and order backlog. Intangible assets, with the exception of customer relationships and order backlog, are amortized using the straight-line method over the estimated economic useful lives of the assets, which is the period during which expected cash flows support the fair value of such intangible assets. Customer relationships and order backlog are amortized using an accelerated method of amortization over the expected customer lives, which more accurately reflects the pattern of realization of economic benefits expected to be obtained.

[0001628280-21-017799:notes:84]
Long-lived Asset Valuation

[0001628280-21-017799:notes:85]
We test long-lived assets for recoverability, at the asset group level, when events or changes in circumstances indicate that their carrying amount may not be recoverable. Circumstances which could trigger a review include, but are not limited to: significant decreases in the market price of the asset, significant adverse changes in the business climate or legal factors, accumulation of costs significantly in excess of the amount originally expected for the acquisition or construction of the asset, current period cash flow or operating losses combined with a history of losses or a forecast of continuing losses associated with the use of the asset, or current expectation that the asset will more likely than not be sold or disposed significantly before the end of its estimated useful life.

[0001628280-21-017799:notes:86]
Recoverability is assessed based on the difference between the carrying amount of the asset and the sum of the undiscounted cash flows expected to result from the use and the eventual disposal of the asset. An impairment loss is recognized when the carrying amount is not recoverable and exceeds fair value.

[0001628280-21-017799:notes:87]
Pension Benefits

[0001628280-21-017799:notes:88]
The Company sponsors various employee retirement plans, including defined contribution, defined benefit and other post-retirement plans.  See “Note 18. Employee Retirement Plans” for more information.

[0001628280-21-017799:notes:89]
The funded status of our retirement-related benefit plan is measured as the difference between the fair value of plan assets and the benefit obligation at fiscal year end, the measurement date. The funded status of an underfunded benefit plan, of which the fair value of plan assets is less than the benefit obligation, is recognized as a non-current net pension liability in the Consolidated Balance Sheets. For defined benefit pension plans, the benefit obligation is the projected benefit obligation (“PBO”) which represents the actuarial present value of benefits expected to be paid upon retirement.

[0001628280-21-017799:notes:90]
Net periodic pension cost (income) (“NPPC”) is recorded in the Consolidated Statements of Operations and includes service cost, interest cost, expected return on plan assets, amortization of prior service cost and (gains) losses previously recognized as a component of accumulated other comprehensive income. Service cost represents the actuarial present value of participant benefits attributed to services rendered by employees in the current year. Interest cost represents the time value of money cost associated with the passage of time. (Gains) losses arise as a result of differences between actual experience and assumptions or as a result of changes in actuarial assumptions. Prior service cost (credit) represents the cost of benefit improvements attributable to prior service granted in plan amendments. (Gains) losses and prior service cost (credit) that arise during the current year are first recognized as a component of accumulated other comprehensive income in the consolidated balances sheets, net of tax. Prior service cost is amortized as a component of NPPC over the average remaining service period of active plan participants starting at the date the plan amendment is adopted. Deferred actuarial (gains) losses are subsequently recognized as a component of NPPC if they exceed the greater of 10% of PBO or the fair value of plan assets, with the excess amortized over the average remaining service period of active plan participants.

[0001628280-21-017799:notes:91]
The measurement of the benefit obligation and NPPC is based on our estimates and actuarial valuations, provided by third-party actuaries, which are approved by management. These valuations reflect the terms of the plans and use participant-specific information such as compensation, age and years of service, as well as certain assumptions, including estimates of discount rates, expected return on plan assets, rate of compensation increases, and mortality rates. We evaluate these assumptions

[0001628280-21-017799:notes:92]
annually at a minimum. In estimating the expected return on plan assets, we consider historical returns on plan assets, adjusted for forward-looking considerations, inflation assumptions and the impact of the active management of the plan’s invested assets.

[0001628280-21-017799:notes:93]
Concentration of Credit and Other Risks

[0001628280-21-017799:notes:94]
Financial instruments that potentially subject our business to concentration of credit risk consist primarily of cash, short-term investments, and trade receivables.

[0001628280-21-017799:notes:95]
Although the Company deposits its cash with financial institutions that management believes are of high credit quality, its deposits, at times, may exceed federally insured limits. The Company’s investment portfolio consists of investment grade securities diversified amongst security types, industries, and issuers. The Company’s investment policy limits the amount of credit exposure in the investment portfolio by imposing credit rating minimums and limiting purchases of a single issuer, security type, geography and industry, except for Treasury securities. The Company believes no significant concentration risk exists with respect to these investments.

[0001628280-21-017799:notes:96]
We perform credit evaluations of our customers’ financial condition and generally do not require collateral from our customers. These evaluations require significant judgment and are based on a variety of factors including, but not limited to, current economic trends, payment history, bad debt write-off experience, and financial review of the customer.

[0001628280-21-017799:notes:97]
We maintain an allowance for credit losses for estimated losses resulting from the inability of our customers to make required payments. When we become aware that a specific customer is unable to meet their financial obligations, we record a specific allowance to reflect the level of credit risk in the customer’s outstanding receivable balance. In addition, we record additional allowances based on certain percentages of aged receivable balances. These percentages take into account a variety of factors including, but not limited to, current economic trends, payment history and bad debt write-off experience. We classify bad debt expenses as selling, general and administrative expense.

[0001628280-21-017799:notes:98]
During fiscal 2021, 2020, and 2019, a few customers generated more than 10% of total net revenue. Refer to “Note 20. Operating Segments and Geographic Information” in the Notes to Consolidated Financial Statements.

[0001628280-21-017799:notes:99]
Our accounts receivable was concentrated with two customers as of July 3, 2021, which individually represented 17% and 14% of gross accounts receivable, respectively, and collectively represented 31% of the gross accounts receivable balance, compared with one customer as of June 27, 2020, which represented 14% of gross accounts receivable.

[0001628280-21-017799:notes:100]
We rely on a limited number of suppliers for a number of key components contained in our products. We also rely on a limited number of significant independent contract manufacturers for the production of certain key components and subassemblies contained in our products.

[0001628280-21-017799:notes:101]
We generally use a rolling twelve months forecast based on anticipated product orders, customer forecasts, product order history and backlog to determine our materials requirements. Lead times for the parts and components that we order vary significantly and depend on factors such as the specific supplier, contract terms and demand for a component at a given time. If the forecast does not meet or if it exceeds actual demand, we may have excess or shortfalls of some materials and components, as well as excess inventory purchase commitments. We could experience reduced or delayed product shipments or incur additional inventory write-downs and cancellation charges or penalties, which would increase costs and could have a material adverse impact on our results of operations.

[0001628280-21-017799:notes:102]
Foreign Currency Translation

[0001628280-21-017799:notes:103]
Concurrent with the acquisition of Oclaro on December 10, 2018, we established the functional currency for our worldwide operations as the U.S. dollar. The change in our functional currency is a result of significant changes in economic facts and circumstances, primarily the acquisition of Oclaro, a U.S. dollar-denominated functional currency company. The combined business, which required the integration of our supply chain, manufacturing operations and sales organization, will predominantly use the U.S. dollar, including when negotiating customer and major supplier contracts.

[0001628280-21-017799:notes:104]
Translation adjustments reported prior to December 10, 2018, remain as a component of accumulated other comprehensive income in our Consolidated Balance Sheet. The translated values for any non-monetary assets and liabilities as of December 10, 2018 become the new accounting basis for those assets. Accordingly, monetary assets and liabilities denominated in foreign currencies have been remeasured into U.S. dollars using the exchange rates in effect at the balance sheet date. Foreign currency re-measurement gains (losses) are included in other income (expense), net in the Consolidated Statements of Operations.

[0001628280-21-017799:notes:105]
Stock-based Compensation

[0001628280-21-017799:notes:106]
Compensation expense related to stock-based transactions is measured and recognized in the financial statements based on fair value at the grant date.

[0001628280-21-017799:notes:107]
Restricted stock units (“RSUs”) are grants of shares of our common stock, the vesting of which is based on the requisite service requirement. Generally, our RSUs are subject to forfeiture and expected to vest over one to four years. For new-hire grants, RSUs generally vest ratably on an annual basis over four years. For annual refresh grants, RSUs generally vest ratably on an annual, or combination of annual and quarterly, basis over three years.

[0001628280-21-017799:notes:108]
Restricted stock awards (“RSAs”) are grants of shares of our common stock that are subject to various restrictions, including restrictions on transferability and forfeiture provisions. RSAs are expected to vest over one to four years, and the shares acquired may not be transferred by the holder until the vesting conditions (if any) are satisfied.

[0001628280-21-017799:notes:109]
Performance stock units (“PSUs”) are grants of shares of our common stock that vest upon the achievement of certain performance and service conditions. We account for the fair value of PSUs using the closing market price of our common stock on the date of grant. We begin recognizing compensation expense when we conclude that it is probable that the performance conditions will be achieved. We reassess the probability of vesting at each reporting period and adjust our compensation cost based on this probability assessment. Our PSUs are subject to risk of forfeiture until performance and service conditions are satisfied and generally vest over three years.

[0001628280-21-017799:notes:110]
We estimate the fair value of the rights to acquire stock under our 2015 Employee Stock Purchase Plan (the “2015 Purchase Plan”) using the Black-Scholes option pricing formula. Our 2015 Purchase Plan provides for consecutive six-month offering periods. We recognize such compensation expense on a straight-line basis over the requisite service period. We calculate the volatility factor based on our historical stock prices.

[0001628280-21-017799:notes:111]
Restructuring and Related Charges

[0001628280-21-017799:notes:112]
Costs associated with restructuring activities are recognized when they are obligated. However, in the case of leases, the expense is estimated and accrued when the property is vacated. Given the significance of, and the timing of the execution of such activities, this process is complex and involves periodic reassessments of estimates made from the time the property was vacated, including evaluating real estate market conditions for expected vacancy periods and sub-lease income. We recognize a liability for post-employment benefits for workforce reductions related to restructuring activities when payment is probable and the amount is reasonably estimable. We continually evaluate the adequacy of the remaining liabilities under our restructuring initiatives. Although we believe that these estimates accurately reflect the costs of our restructuring plans, actual results may differ, thereby requiring us to record additional provisions or reverse a portion of such provisions. Refer to “Note 14. Restructuring and Related Charges” in the Notes to Consolidated Financial Statements.

[0001628280-21-017799:notes:113]
Business Combinations

[0001628280-21-017799:notes:114]
In accordance with the guidance for business combinations, we determine whether a transaction or other event is a business combination, which requires that the assets acquired and liabilities assumed constitute a business. Each business combination is then accounted for by applying the acquisition method. If the assets acquired are not a business, we account for the transaction or other event as an asset acquisition. Under both methods, we recognize the identifiable assets acquired, the liabilities assumed, and any noncontrolling interest in the acquired entity. We capitalize acquisition-related costs and fees associated with asset acquisitions and immediately expense acquisition-related costs and fees associated with business combinations.

[0001628280-21-017799:notes:115]
We allocate the fair value of purchase consideration to the tangible assets acquired, liabilities assumed and intangible assets acquired based on their estimated fair values. The excess of the fair value of purchase consideration over the fair values of these identifiable assets and liabilities is recorded as goodwill. When determining the fair values of assets acquired and liabilities assumed, we make significant estimates and assumptions, especially with respect to intangible assets. Critical estimates in valuing certain intangible assets include, but are not limited to, future expected cash flows from customer relationships and acquired developed technology and discount rates. Our estimates of fair value are based upon assumptions believed to be reasonable, but which are inherently uncertain and unpredictable and, as a result, actual results may differ materially from estimates. Other estimates associated with the accounting for acquisitions may change as additional information becomes available regarding the assets acquired and liabilities assumed. Any change in facts and circumstances that existed as of the acquisition date and impacts our preliminary estimates is recorded to goodwill if identified within the measurement period. Subsequent to the measurement period or our final determination of fair value of assets and liabilities whichever is earlier the adjustments will affect our earnings.

[0001628280-21-017799:notes:116]
In addition, we estimate the economic lives of certain acquired assets and these lives are used to calculate depreciation and amortization expense. If our estimates of the economic lives change, depreciation or amortization expenses could be accelerated or slowed.

[0001628280-21-017799:notes:117]
Research and Development (“R&D”) Expense

[0001628280-21-017799:notes:118]
Costs related to R&D, which primarily consists of labor and benefits, supplies, facilities, consulting and outside service fees, are charged to expense as incurred.

[0001628280-21-017799:notes:119]
Loss Contingencies

[0001628280-21-017799:notes:120]
We are subject to the possibility of various loss contingencies arising in the ordinary course of business. We consider the likelihood of loss or impairment of an asset or the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss in determining loss contingencies. An estimated loss is accrued when it is probable that an asset has been impaired or a liability has been incurred and the amount of loss can be reasonably estimated. We regularly evaluate current information available to determine whether such accruals should be adjusted and whether new accruals are required.

[0001628280-21-017799:notes:121]
Asset Retirement Obligations (“ARO”)

[0001628280-21-017799:notes:122]
Our ARO are legal obligations associated with the retirement of long-lived assets pertaining to leasehold improvements. These liabilities are initially recorded at fair value and the related asset retirement costs are capitalized by increasing the carrying amount of the related assets by the same amount as the liability. Asset retirement costs are subsequently depreciated over the useful lives of the related assets. Subsequent to initial recognition, we record period-to-period changes in the ARO liability resulting from the passage of time and revisions to either the timing or the amount of the original estimate of undiscounted cash flows. We derecognize ARO liabilities when the related obligations are settled.


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0001628280-21-017799:notes:123]
We determine fair value based on the fair value hierarchy, which requires an entity to maximize the use of observable inputs and minimize the use of unobservable inputs when measuring fair value. Fair value is defined as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. The fair value assumes that the transaction to sell the asset or transfer the liability occurs in the principal or most advantageous market for the asset or liability and establishes that the fair value of an asset or liability shall be determined based on the assumptions that market participants would use in pricing the asset or liability. The classification of a financial asset or liability within the hierarchy is based upon the lowest level input that is significant to the fair value measurement. The fair value hierarchy prioritizes the inputs into three levels that may be used to measure fair value:

[0001628280-21-017799:notes:124]
| Level 1: | Inputs are unadjusted quoted prices in active markets for identical assets or liabilities. |
| Level 2: | Inputs are quoted prices for similar assets and liabilities in active markets or inputs that are observable for the asset or liability, either directly or indirectly through market corroboration, for substantially the full term of the financial instrument. |
| Level 3: | Inputs are unobservable inputs based on our assumptions. |

[0001628280-21-017799:notes:125]
The fair value of our Level 1 financial instruments, such as money market funds and U.S. Treasury securities, which are traded in active markets, is based on quoted market prices for identical instruments. The fair value of our Level 2 fixed income securities is obtained from an independent pricing service, which may use quoted market prices for identical or comparable instruments or model driven valuations using observable market data or inputs corroborated by observable market data. Our marketable securities are held by custodians who obtain investment prices from a third-party pricing provider that incorporates standard inputs in various asset price models. Our procedures include controls to ensure that appropriate fair values are recorded, including comparing the fair values obtained from our pricing service against fair values obtained from another independent source.

[0001628280-21-017799:notes:126]
Our pension assets consist of multiple institutional funds (“pension funds”) of which the fair values are based on the quoted prices of the underlying funds. Pension funds are mainly classified as Level 2 assets since such funds are not directly traded in active markets. Refer to “Note 18. Employee Retirement Plans.”

[0001628280-21-017799:notes:127]
Assets Measured at Fair Value on a Non-Recurring Basis

[0001628280-21-017799:notes:128]
We periodically review our intangible and other long-lived assets for impairment whenever events or changes in circumstances indicate that the carrying amount of such assets may not be recoverable. Determination of recoverability is based on the lowest level of identifiable estimated undiscounted cash flows resulting from use of the asset and its eventual disposition. If not recoverable, an impairment loss would be calculated based on the excess of the carrying amount over the fair value.
Management utilizes various valuation methods, including an income approach, a market approach and a cost approach, to estimate the fair value of intangibles and other long-lived assets.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0001628280-21-017799:notes:129]
Contract Balances
The Company records accounts receivable when it has an unconditional right to consideration. Contract liabilities are recorded when cash payments are received or due in advance of performance. Contract liabilities consist of advance payments and deferred revenue, where the Company has unsatisfied performance obligations. Contract liabilities are classified as deferred revenue and customer deposits, and are included in other current liabilities within our Consolidated Balance Sheet. Payment terms vary by customer. The time between invoicing and when payment is due is not significant.Disaggregation of RevenueWe disaggregate revenue by geography and by product. Refer to “Note 20. Operating Segments and Geographic Information” for a presentation of disaggregated revenue. We do not present other levels of disaggregation, such as by type of products, customer, markets, contracts, duration of contracts, timing of transfer of control and sales channels, as this information is not used by our Chief Operating Decision Maker to manage the business.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001628280-21-017799:notes:130]
Note 2. Recently Issued Accounting Pronouncements

[0001628280-21-017799:notes:131]
Accounting Pronouncements Recently Adopted

[0001628280-21-017799:notes:132]
In August 2018, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU") 2018-14, Compensation-Retirement Benefits-Defined Benefit Plans-General (Topic 715-20): Disclosure Framework-Changes to the Disclosure Requirements for Defined Benefit Plans. ASU 2018-14 modifies the disclosure requirements for defined benefit pension plans and other post-retirement benefit plans. The new guidance is effective for fiscal years ending after December 15, 2020, with early adoption permitted. ASU 2018-14 should be applied retrospectively to all periods presented and was effective for us in our fourth quarter of fiscal year 2021 as ASU 2018-14 does not amend the interim disclosure requirements. We have included all the required disclosures in the “Note 18. Employee Retirement Plans”.

[0001628280-21-017799:notes:133]
In August 2018, FASB issued ASU 2018-13, Fair Value Measurement (Topic 820): Disclosure Framework-Changes to the Disclosure Requirements for Fair Value Measurement. ASU 2018-13 modifies the disclosure requirements on transfers between Level 1 and Level 2, valuation processes of Level 3 fair value measurements, and the categorization by level for items that are not measured at fair value, but for which the fair value is required to be disclosed. We adopted ASU 2018-13 in the first quarter of fiscal 2021 with no impact to our consolidated financial statements.

[0001628280-21-017799:notes:134]
In August 2018, FASB issued ASU 2018-15, Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40): Customer's Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract. This standard requires capitalization of the implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software. Further, the standard also requires the Company to expense the capitalized implementation costs of a hosting arrangement over the term of the hosting arrangement. We adopted ASU 2018-15 in the first quarter of fiscal 2021 with no impact to our consolidated financial statements.

[0001628280-21-017799:notes:135]
In June 2016, FASB issued ASU 2016-13, Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments and a subsequent amendment, ASU 2018-19 (collectively, Topic 326). Topic 326 requires measurement and recognition of expected credit losses for financial assets held. We adopted ASU 2016-13 using the modified-retrospective approach in the first quarter of fiscal 2021 with no material impact to our consolidated financial statements.

[0001628280-21-017799:notes:136]
With the adoption of Topic 326, we are now assessing whether unrealized losses have resulted from a credit loss or other factors. We believe none of our unrealized losses on available-for-sale investments were other-than temporary or were attributable to credit losses as of July 3, 2021 and June 27, 2020. We review our available-for-sale investments on a quarterly

[0001628280-21-017799:notes:137]
basis to identify a potential other-than-temporary impairment. The investments with unrealized losses consisted primarily of corporate debt securities, and given the extent of the unrealized loss positions, the issuers' high credit ratings and the near-term market conditions, we believe our unrealized losses are temporary. We also do not have an intent to sell our investments and would not be required to sell them before they recover.

[0001628280-21-017799:notes:138]
The adoption of Topic 326 did not significantly change our approach to the valuation of trade receivables. We determine whether there is an expected loss on our accounts receivable by reviewing all available data, including our customers' latest available financial statements, their credit standing and historical collection experience, as well as current and future market and economic conditions. As of July 3, 2021 and June 27, 2020, the allowance for credit losses on our trade receivables was $0.4 million and $1.8 million, respectively.

[0001628280-21-017799:notes:139]
Accounting Pronouncements Not Yet Effective

[0001628280-21-017799:notes:140]
In August 2020, FASB issued ASU 2020-06, Debt—Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging—Contracts in Entity’s Own Equity (Subtopic 815-40): Accounting for Convertible Instruments and Contracts in an Entity’s Own Equity, which simplifies the accounting for convertible instruments by removing the separation models for (1) convertible debt with a cash conversion feature and (2) convertible instruments with a beneficial conversion feature. As a result, a convertible debt instrument will be accounted for as a single liability measured at its amortized cost. Also, ASU 2020-06 requires the application of the if-converted method for calculating diluted earnings per share and the treasury stock method will be no longer available. The new guidance is effective for fiscal years beginning after December 15, 2021, with early adoption permitted no earlier than fiscal years beginning after December 15, 2020. ASU 2020-06 is effective for us in our first quarter of fiscal year 2023. We are currently evaluating the impact of ASU 2020-06 on our consolidated financial statements.

[0001628280-21-017799:notes:141]
In December 2019, FASB issued ASU 2019-12, Simplifying the Accounting for Income Taxes (Topic 740), which is intended to simplify various aspects related to accounting for income taxes by removing certain exceptions to the general principles in Topic 740 and which also clarifies and amends existing guidance to improve consistent application. ASU 2019-12 is effective for us at the beginning of fiscal year 2022, including interim periods within that reporting period, although early adoption is permitted. We are currently evaluating the impact of ASU 2019-12 on our consolidated financial statements.


## us-gaap:EarningsPerShareTextBlock

[0001628280-21-017799:notes:142]
Note 3. Earnings Per Share

[0001628280-21-017799:notes:143]
The following table sets forth the computation of basic and diluted net income (loss) attributable to common stockholders per share (in millions, except per share data):

[0001628280-21-017799:notes:144]
|  | Years Ended |
|  | July 3, 2021 |  | June 27, 2020 |  |  |  | June 29, 2019 |
| Basic Earnings per Common Share |  |  |  |  |  |  |  |
| Net income (loss) | $ | 397.3 |  |  | $ | 135.5 |  |  |  |  | $ | (36.4) |  |
| Less: Cumulative dividends on Series A Preferred Stock | — |  |  | — |  |  |  |  | (0.3) |  |
| Less: Earnings allocated to Series A Preferred Stock | — |  |  | — |  |  |  |  | (1.2) |  |
| Net income (loss) attributable to common stockholders - Basic | $ | 397.3 |  |  | $ | 135.5 |  |  |  |  | $ | (37.9) |  |
| Basic weighted average common shares outstanding | 75.4 |  |  | 75.9 |  |  |  |  | 70.7 |  |
| Net income (loss) per share attributable to common stockholders - Basic | $ | 5.27 |  |  | $ | 1.79 |  |  |  |  | $ | (0.54) |  |
| Diluted Earnings per Common Share |  |  |  |  |  |  |  |
| Net income (loss) attributable to common stockholders - Diluted | $ | 397.3 |  |  | $ | 135.5 |  |  |  |  | $ | (37.9) |  |
| Weighted average common shares outstanding for basic earnings per common share | 75.4 |  |  | 75.9 |  |  |  |  | 70.7 |  |
| Effect of dilutive securities from 2015 Equity Incentive Plan | 0.8 |  |  | 0.8 |  |  |  |  | — |  |
| Shares issuable assuming conversion of the 2024 Notes | 2.2 |  |  | 0.9 |  |  |  |  | — |  |
| Diluted weighted average common shares outstanding | 78.4 |  |  | 77.6 |  |  |  |  | 70.7 |  |
| Net income (loss) per share attributable to common stockholders: |  |  |  |  |  |  |  |
| Basic | $ | 5.27 |  |  | $ | 1.79 |  |  |  |  | $ | (0.54) |  |
| Diluted | $ | 5.07 |  |  | $ | 1.75 |  |  |  |  | $ | (0.54) |  |

[0001628280-21-017799:notes:145]
For the year ended June 29, 2019, our diluted loss per share attributable to common stockholders is the same as basic loss per share as we are in net loss position.

[0001628280-21-017799:notes:146]
Our Series A Preferred Stock was considered a participating security, meaning that it had the right to participate in undistributed earnings with our common stock. On November 2, 2018, the remaining 35,805 shares of our Series A Preferred Stock were converted into 1.5 million shares of our common stock. Refer to “Note 11. Non-Controlling Interest Redeemable Convertible Preferred Stock and Derivative Liability” for further discussion. Prior to conversion, the holders of our Series A Preferred Stock were entitled to share in dividends, on an as-converted basis, if the holders of our common stock were to receive dividends.  Through the date of conversion, we used the two-class method to compute earnings per share. The two-class method is an earnings allocation formula that determines earnings per share for each class of common stock and participating security according to dividends declared (or accumulated) and participation rights in undistributed earnings. In determining the amount of net earnings to allocate to common stockholders, earnings are allocated to both common and participating securities based on their respective weighted-average shares outstanding during the period. Diluted earnings per common share is calculated similar to basic earnings per common share except that it gives effect to all potentially dilutive common stock equivalents outstanding for the period, using the treasury stock method. Diluted earnings per common share is computed using the more dilutive of the treasury stock method or the if-converted method.

[0001628280-21-017799:notes:147]
Potentially dilutive common shares result from the assumed exercise of outstanding stock options, assumed vesting of outstanding equity awards, assumed issuance of stock under the employee stock purchase plan, and assumed conversion of our outstanding convertible notes, all using the treasury stock method.

[0001628280-21-017799:notes:148]
We have the ability and intent to settle the face value of our convertible notes in cash. Therefore, we use the treasury stock method for calculating the dilutive impact of the convertible notes. The 2026 Notes (as defined in “Note 12. Debt") does not impact diluted earnings per share until the average price of our common stock exceeds the conversion price of $99.29. The potentially dilutive shares resulting from the 2024 Notes were included in the calculation of diluted income per share for the

[0001628280-21-017799:notes:149]
year ended July 3, 2021 and June 27, 2020 since the average price of our common stock exceeded the conversion price of $60.62. Refer to “Note 12. Debt” for further discussion of convertible notes.

[0001628280-21-017799:notes:150]
Anti-dilutive potential shares are excluded from the calculation of diluted earnings per share if their exercise price exceeded the average market price during the period or the share-based awards were determined to be anti-dilutive based on applying the treasury stock method. Anti-dilutive shares excluded from the calculation of diluted earnings per share were 0.5 million and 0.4 million for the year ended July 3, 2021 and June 27, 2020, respectively. During the year ended June 29, 2019, 0.6 million of potentially dilutive securities were excluded from the computation of diluted earnings per share due to net loss generated for the period, since the effect would have been anti-dilutive.


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0001628280-21-017799:notes:151]
Note 4. Business Combinations

[0001628280-21-017799:notes:152]
On December 10, 2018, we acquired all of the outstanding common stock of Oclaro, a provider of optical components and modules for the long-haul, metro and data center markets. Oclaro’s products provide differentiated solutions for optical networks and high-speed interconnects driving the next wave of streaming video, cloud computing, application virtualization and other bandwidth-intensive and high-speed applications. This acquisition strengthened our product portfolio, including gaining Oclaro’s indium phosphide laser and photonic integrated circuit and coherent component and module capabilities; broadens our revenue mix; and positions us strongly to meet the future needs of our customers.

[0001628280-21-017799:notes:153]
Pursuant to the merger agreement, Prota Merger Sub, Inc., a Delaware corporation and a wholly owned subsidiary of Lumentum (“Merger Sub”), merged with and into Oclaro (the “Merger”), with Oclaro surviving the Merger. Each outstanding share of Oclaro common stock, par value $0.01 per share, was automatically converted into the right to receive the following consideration (collectively, the “Merger Consideration”), without interest:

[0001628280-21-017799:notes:154]
•$5.60 in cash (the “Cash Consideration”) and;

[0001628280-21-017799:notes:155]
•0.0636 of a share of Lumentum common stock, par value $0.001 per share (the “Exchange Ratio”)

[0001628280-21-017799:notes:156]
The total fair value of consideration given in connection with the acquisition of Oclaro consisted of the following:

[0001628280-21-017799:notes:157]
|  | Shares | Per Share | Total Consideration(in millions) |
| Cash paid for outstanding Oclaro common stock |  |  | $ | 964.8 |  |
| Lumentum common shares issued to Oclaro stockholders | 10,941,436 |  | $ | 41.80 |  | 457.4 |  |
| Replacement equity awards for Oclaro equity awards |  |  | 2.7 |  |
| Total consideration |  |  | $ | 1,424.9 |  |

[0001628280-21-017799:notes:158]
The total transaction consideration was $1.4 billion, which was funded by the issuance of Lumentum common stock, new debt, and cash balances of the combined company. We also recorded $18.3 million in acquisition-related costs in the year ended June 29, 2019, representing professional and other direct acquisition costs. These costs were recorded within selling, general and administrative expenses and within interest and other income (expense), net in our Consolidated Statements of Operations. The Company also incurred $9.3 million of debt financing costs which has been recorded as a contra liability. Refer to “Note 12. Debt.”

[0001628280-21-017799:notes:159]
The final purchase price allocation is as follows (in millions):

[0001628280-21-017799:notes:160]
|  |  |  | FinalAs AdjustedJune 29, 2019 |
| Cash and cash equivalents |  |  | $ | 345.0 |  |
| Accounts receivable, net |  |  | 68.0 |  |
| Inventories |  |  | 155.0 |  |
| Prepayments and other current assets |  |  | 33.7 |  |
| Property, plant and equipment, net |  |  | 134.7 |  |
| Intangibles |  |  | 444.0 |  |
| Deferred income tax asset |  |  | 42.6 |  |
| Other non-current assets |  |  | 16.6 |  |
| Accounts payable |  |  | (57.8) |  |
| Accrued payroll and related expenses |  |  | (11.4) |  |
| Accrued expenses |  |  | (8.3) |  |
| Other current liabilities |  |  | (6.1) |  |
| Deferred tax liability |  |  | (75.8) |  |
| Other non-current liabilities |  |  | (12.9) |  |
| Goodwill |  |  | 357.6 |  |
| Total purchase price |  |  | $ | 1,424.9 |  |

[0001628280-21-017799:notes:161]
Goodwill and intangibles have been assigned to the OpComms segment. Goodwill of $357.6 million arising from the acquisition is attributed to the expected synergies, including future cost efficiencies, and other benefits that are expected to be generated by combining Lumentum and Oclaro. Substantially all of the goodwill recognized is not expected to be deductible for tax purposes. See “Note 10. Goodwill and Other Intangible Assets” for more information on goodwill and In-process research and development (IPR&D).

[0001628280-21-017799:notes:162]
Supplemental Pro Forma Information

[0001628280-21-017799:notes:163]
The supplemental pro forma financial information presented below is for illustrative purposes only and is not necessarily indicative of the financial position or results of operations that would have been realized if the acquisition had been completed on the date indicated, does not reflect synergies that might have been achieved, nor is it indicative of future operating results or financial position. The pro forma adjustments are based upon currently available information and certain assumptions we believe are reasonable under the circumstances.

[0001628280-21-017799:notes:164]
The following supplemental pro forma information presents the combined results of operations for the year June 29, 2019, as if Oclaro had been acquired as of the beginning of fiscal year 2019. The supplemental pro forma information includes adjustments to amortization and depreciation for acquired intangible assets and property and equipment, adjustments to share-based compensation expense, the fair value adjustments on the inventories acquired, transaction costs, interest expense and amortization of the term loan debt issuance costs.

[0001628280-21-017799:notes:165]
The unaudited supplemental pro forma financial information for the periods presented is as follows (in millions):

[0001628280-21-017799:notes:166]
|  |  |  | Year Ended |
|  |  |  | June 29, 2019 |
| Net revenue |  |  | $ | 1,779.4 |  |
| Net income |  |  | 21.5 |  |


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001628280-21-017799:notes:167]
Note 5. Assets Held For Sale and Related Dispositions

[0001628280-21-017799:notes:168]
We continually evaluate our existing portfolio of businesses to maximize long-term stockholder value. We consider assets and liabilities as held-for-sale when management approves and commits to a plan to actively market assets or a group of assets for sale. Assets held-for-sale are recorded initially at the lower of its carrying value or its estimated fair value, less estimated costs to sell. Upon designation as an asset held-for-sale, we discontinue recording depreciation expense on such asset.

[0001628280-21-017799:notes:169]
Sale of Land and Building

[0001628280-21-017799:notes:170]
In fiscal year 2021, we made a decision to cease manufacturing of certain products at a manufacturing facility that we owned in San Jose, California.  During the fourth quarter of fiscal 2021, we shut down the manufacturing site and sold the related land and building for $23.0 million and recognized a gain of $8.3 million, which was recorded as an offset to selling, general and administrative expenses in our Consolidated Statement of Operations as of July 3, 2021.

[0001628280-21-017799:notes:171]
Sale of Lithium Niobate modulators

[0001628280-21-017799:notes:172]
Following our acquisition of Oclaro, we announced our plan to discontinue development and manufacturing of Lithium Niobate modulators and wind down these operations in our San Donato, Italy site. In fiscal year 2020, we sold our assets associated with certain Lithium Niobate product lines manufactured by our San Donato site for $17.0 million to Advanced Fiber Resources (Zhuhai) Ltd. (“AFR”) and recognized a gain of $13.8 million, which was recorded in other income (expense), net in the Consolidated Statements of Operations.

[0001628280-21-017799:notes:173]
In fiscal year 2020, we also sold certain assets that did not have any carrying value, including licenses to manufacture specific Lithium Niobate products and recognized a gain of $0.7 million, which was recorded in our other income (expense), net in the Consolidated Statements of Operations.

[0001628280-21-017799:notes:174]
With the close of these transactions, our telecom transmission product strategy is now focused on Indium Phosphide photonic integrated circuits, as well as components and modules that incorporate these Indium Phosphide photonic integrated circuits.

[0001628280-21-017799:notes:175]
Datacom transceiver modules

[0001628280-21-017799:notes:176]
Following our acquisition of Oclaro, in the third quarter of fiscal 2019, we completed the sale of our Datacom transceiver module business based in Sagamihara, Japan and the transfer of related employees to CIG for $25.5 million in net cash. These product lines were initially acquired by us through the acquisition of Oclaro. This business did not meet the criteria for assets held-for-sale under the relevant accounting guidance as of December 10, 2018, the date of our acquisition of Oclaro, in our purchase price allocation. The assets and liabilities transferred to CIG were $33.5 million and $7.0 million, respectively.

[0001628280-21-017799:notes:177]
As of June 29, 2019, we had $4.9 million of long-lived assets related to our plan to discontinue the development of future Datacom transceiver modules. As these assets were not deemed to be useful, we retired them from active use and classified them as held-for-sale within prepayments and other current assets on our Consolidated Balance Sheet. This is a result of the strategic change we made in the third quarter of fiscal year 2019 when we announced the exit from the Datacom transceiver modules and investments in the new Datacom chips development. In fiscal year 2020, we sold $3.0 million and impaired $1.6 million of these Datacom assets held-for-sale. In fiscal year 2021, we sold the remaining $0.3 million of these assets held-for-sale.

[0001628280-21-017799:notes:178]
Other assets held-for-sale
 As of July 3, 2021, we recorded $0.4 million of land, building, and improvements as assets held-for-sale for one of our manufacturing sites in Slovenia.


## us-gaap:CashCashEquivalentsAndShortTermInvestmentsTextBlock

[0001628280-21-017799:notes:179]
Note 6. Cash, Cash Equivalents and Short-term Investments

[0001628280-21-017799:notes:180]
The following table summarizes our cash, cash equivalents and short-term investments by category for the periods presented (in millions):

[0001628280-21-017799:notes:181]
|  | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| July 3, 2021: |  |  |  |  |  |  |  |
| Cash | $ | 128.3 |  |  | $ | — |  |  | $ | — |  |  | $ | 128.3 |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | 7.5 |  |  | — |  |  | — |  |  | 7.5 |  |
| Corporate debt securities | 7.0 |  |  |  |  |  |  | 7.0 |  |
| Money market funds | 631.5 |  |  | — |  |  | — |  |  | 631.5 |  |
| Total cash and cash equivalents | $ | 774.3 |  |  | $ | — |  |  | $ | — |  |  | $ | 774.3 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 28.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 28.5 |  |
| Commercial paper | 136.7 |  |  | — |  |  | — |  |  | 136.7 |  |
| Corporate debt securities | 626.0 |  |  | 0.3 |  |  | (0.4) |  |  | 625.9 |  |
| Municipal bonds | 1.0 |  |  | — |  |  | — |  |  | 1.0 |  |
| U.S. Agency securities | 29.3 |  |  | — |  |  | — |  |  | 29.3 |  |
| U.S. Treasury securities | 350.3 |  |  | — |  |  | — |  |  | 350.3 |  |
| Total short-term investments | $ | 1,171.8 |  |  | $ | 0.3 |  |  | $ | (0.4) |  |  | $ | 1,171.7 |  |
| June 27, 2020: |  |  |  |  |  |  |  |
| Cash | $ | 114.2 |  |  | $ | — |  |  | $ | — |  |  | $ | 114.2 |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Money market funds | 159.6 |  |  | — |  |  | — |  |  | 159.6 |  |
| U.S. Treasury securities | 24.2 |  |  | — |  |  | — |  |  | 24.2 |  |
| Total cash and cash equivalents | $ | 298.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 298.0 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 12.9 |  |  | $ | — |  |  | $ | — |  |  | $ | 12.9 |  |
| Commercial paper | 179.9 |  |  | 0.3 |  |  | — |  |  | 180.2 |  |
| Corporate debt securities | 435.0 |  |  | 1.7 |  |  | (0.1) |  |  | 436.6 |  |
| Foreign government bonds | 1.7 |  |  | — |  |  | — |  |  | 1.7 |  |
| U.S. Agency securities | 59.5 |  |  | — |  |  | — |  |  | 59.5 |  |
| U.S. Treasury securities | 563.9 |  |  | 1.0 |  |  | — |  |  | 564.9 |  |
| Total short-term investments | $ | 1,252.9 |  |  | $ | 3.0 |  |  | $ | (0.1) |  |  | $ | 1,255.8 |  |

[0001628280-21-017799:notes:182]
We use the specific-identification method to determine any realized gains or losses from the sale of our short-term investments classified as available-for-sale. During fiscal 2021, 2020 and 2019, we did not realize significant gains or losses on a gross level from the sale of our short-term investments classified as available-for-sale.

[0001628280-21-017799:notes:183]
The components of other income (expense), net are as follows for the years presented (in millions):

[0001628280-21-017799:notes:184]
|  |  |  | Years Ended |
|  |  |  | July 3, 2021 |  | June 27, 2020 |  | June 29, 2019 |
| Foreign exchange losses, net |  |  | $ | (4.4) |  |  | $ | (1.4) |  |  | $ | (0.6) |  |
| Interest and investment income |  |  | 5.7 |  |  | 15.8 |  |  | 13.9 |  |
| Other income, net |  |  | 1.5 |  |  | 17.0 |  |  | 2.5 |  |
| Total other income (expense), net |  |  | $ | 2.8 |  |  | $ | 31.4 |  |  | $ | 15.8 |  |

[0001628280-21-017799:notes:185]
Other income, net in fiscal 2020 includes a gain on the sale of Lithium Niobate modulators business of $13.8 million and a gain on the sale of certain assets used to manufacture specific Lithium Niobate products of $0.7 million. Refer to “Note 5. Assets Held For Sale and Related Dispositions”.

[0001628280-21-017799:notes:186]
Included in the interest and investment income are $4.1 million and $4.3 million of interest receivable as of July 3, 2021 and June 27, 2020, respectively, recorded in prepayments and other current assets within the Consolidated Balance Sheets. We did not recognize an allowance for credit losses against the interest receivable in any of the periods presented as there were no such losses.

[0001628280-21-017799:notes:187]
As of July 3, 2021, the Company does not have any cash equivalents and short-term investments that have been in a continuous unrealized gain or loss position for more than 12 months as of the periods presented. The following table summarizes unrealized losses on our cash equivalents and short-term investments by category that have been in a continuous unrealized loss position for less than 12 months as of the periods presented (in millions):

[0001628280-21-017799:notes:188]
|  | Fair Value |  | Unrealized Losses |  |  |  |  |  |  |  |  |
| July 3, 2021: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | 28.3 |  |  | $ | — |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | 6.0 |  |  |  |  |  |  |  |  |  |  |  |
| Commercial paper | 43.0 |  |  | — |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 432.3 |  |  | (0.4) |  |  |  |  |  |  |  |  |  |
| Municipal bonds | 1.0 |  |  | — |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 106.9 |  |  | — |  |  |  |  |  |  |  |  |  |
| Total | $ | 617.5 |  |  | $ | (0.4) |  |  |  |  |  |  |  |  |  |
| June 27, 2020: |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 3.1 |  |  | $ | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | 51.1 |  |  | — |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 96.5 |  |  | (0.1) |  |  |  |  |  |  |  |  |  |
| Foreign government bonds | 1.7 |  |  | — |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | 47.0 |  |  | — |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 159.8 |  |  | — |  |  |  |  |  |  |  |  |  |
| Total | $ | 359.2 |  |  | $ | (0.1) |  |  |  |  |  |  |  |  |  |

[0001628280-21-017799:notes:189]
As of July 3, 2021 and June 27, 2020, we have no unrealized loss positions on our cash equivalents and short-term investments that extend for a period of greater than 12 months.

[0001628280-21-017799:notes:190]
The following table classifies our short-term investments by contractual maturities (in millions):

[0001628280-21-017799:notes:191]
|  | July 3, 2021 |  | June 27, 2020 |
|  | Amortized Cost |  | Fair Value |  | Amortized Cost |  | Fair Value |
| Due within 1 year | $ | 587.0 |  |  | $ | 587.1 |  |  | $ | 1,237.4 |  |  | $ | 1,239.9 |  |
| Due between 1 year to 5 years | 584.8 |  |  | 584.6 |  |  | 15.5 |  |  | 15.9 |  |
|  | $ | 1,171.8 |  |  | $ | 1,171.7 |  |  | $ | 1,252.9 |  |  | $ | 1,255.8 |  |

[0001628280-21-017799:notes:192]
All available-for-sale securities have been classified as current, based on management’s intent and ability to use the funds in current operations.


## us-gaap:FairValueDisclosuresTextBlock

[0001628280-21-017799:notes:193]
Note 7. Fair Value Measurements

[0001628280-21-017799:notes:194]
Financial assets measured at fair value on a recurring basis are summarized below (in millions):

[0001628280-21-017799:notes:195]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| July 3, 2021 (1) |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | — |  |  | $ | 7.5 |  |  | $ | — |  |  | $ | 7.5 |  |
| Corporate debt securities | — |  |  | 7.0 |  |  | — |  |  | 7.0 |  |
| Money market funds | 631.5 |  |  | — |  |  | — |  |  | 631.5 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | 28.5 |  |  | — |  |  | 28.5 |  |
| Commercial paper | — |  |  | 136.7 |  |  | — |  |  | 136.7 |  |
| Corporate debt securities | — |  |  | 625.9 |  |  | — |  |  | 625.9 |  |
| Municipal bonds | — |  |  | 1.0 |  |  | — |  |  | 1.0 |  |
| U.S. Agency securities | — |  |  | 29.3 |  |  | — |  |  | 29.3 |  |
| U.S. Treasury securities | 350.3 |  |  | — |  |  | — |  |  | 350.3 |  |
| Total assets | $ | 981.8 |  |  | $ | 835.9 |  |  | $ | — |  |  | $ | 1,817.7 |  |

[0001628280-21-017799:notes:196]
(1)  Excludes $128.3 million in cash held in our bank accounts as of July 3, 2021.

[0001628280-21-017799:notes:197]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| June 27, 2020: (1) |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Money market funds | $ | 159.6 |  |  | $ | — |  |  | $ | — |  |  | $ | 159.6 |  |
| U.S. Treasury securities | 24.2 |  |  | — |  |  | — |  |  | 24.2 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | 12.9 |  |  | — |  |  | 12.9 |  |
| Commercial paper | — |  |  | 180.2 |  |  | — |  |  | 180.2 |  |
| Corporate debt securities | — |  |  | 436.6 |  |  | — |  |  | 436.6 |  |
| Foreign government bonds | — |  |  | 1.7 |  |  | — |  |  | 1.7 |  |
| U.S. Agency securities | — |  |  | 59.5 |  |  | — |  |  | 59.5 |  |
| U.S. Treasury securities | 564.9 |  |  | — |  |  | — |  |  | 564.9 |  |
| Total assets | $ | 748.7 |  |  | $ | 690.9 |  |  | $ | — |  |  | $ | 1,439.6 |  |

[0001628280-21-017799:notes:198]
(1)  Excludes $114.2 million in cash held in our bank accounts as of June 27, 2020.

[0001628280-21-017799:notes:199]
Financial Instruments Not Recorded at Fair Value on a Recurring Basis

[0001628280-21-017799:notes:200]
We report our financial instruments at fair value with the exception of the 2026 Notes and the 2024 Notes (“Note 12. Debt”). The estimated fair value of the notes was determined based on the trading price of the notes as of the last day of trading for the period. We consider the fair value of the notes to be a Level 2 measurement as they are not actively traded in markets.

[0001628280-21-017799:notes:201]
The carrying amounts and estimated fair values of the 2026 Notes and the 2024 Notes are as follows for the periods presented (in millions):

[0001628280-21-017799:notes:202]
|  | July 3, 2021 |  | June 27, 2020 |
|  | Carrying Amount |  | Estimated Fair Value |  | Carrying Amount |  | Estimated Fair Value |
| 2026 Notes | $ | 789.8 |  |  | $ | 1,146.1 |  |  | $ | 749.7 |  |  | $ | 1,070.2 |  |
| 2024 Notes | 390.7 |  |  | 669.3 |  |  | 370.6 |  |  | 620.0 |  |
|  | $ | 1,180.5 |  |  | $ | 1,815.4 |  |  | $ | 1,120.3 |  |  | $ | 1,690.2 |  |

[0001628280-21-017799:notes:203]
We periodically review our intangible and other long-lived assets for impairment whenever events or changes in circumstances indicate that the carrying amount of such assets may not be recoverable. Determination of recoverability is based on the lowest level of identifiable estimated undiscounted cash flows resulting from use of the asset and its eventual disposition. If not recoverable, an impairment loss would be calculated based on the excess of the carrying amount over the fair value.

[0001628280-21-017799:notes:204]
Management utilizes various valuation methods, including an income approach, a market approach and a cost approach, to estimate the fair value of intangibles and other long-lived assets. During the annual impairment testing performed in the fourth quarter of fiscal 2021, we concluded that our intangible and other long-lived assets were not impaired. We review our intangible and other long-lived assets for impairment at least annually in the fourth quarter of each fiscal year, absent any interim indicators of impairment.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001628280-21-017799:notes:205]
Note 8. Balance Sheet Details

[0001628280-21-017799:notes:206]
Allowance for current expected credit losses

[0001628280-21-017799:notes:207]
We did not have any allowance for credit losses other than our allowance for uncollectible accounts receivable. As of July 3, 2021 and June 27, 2020, the allowance for credit losses on our trade receivables was $0.4 million and $1.8 million, respectively.

[0001628280-21-017799:notes:208]
Inventories

[0001628280-21-017799:notes:209]
The components of inventories were as follows (in millions):

[0001628280-21-017799:notes:210]
|  | July 3, 2021 |  | June 27, 2020 |
| Raw materials and purchased parts | $ | 64.4 |  |  | $ | 57.9 |  |
| Work in process | 79.0 |  |  | 67.6 |  |
| Finished goods | 53.0 |  |  | 63.4 |  |
| Inventories | $ | 196.4 |  |  | $ | 188.9 |  |

[0001628280-21-017799:notes:211]
Operating lease right-of-use assets, net

[0001628280-21-017799:notes:212]
Operating lease right-of-use assets, net were as follows (in millions):

[0001628280-21-017799:notes:213]
|  | July 3, 2021 |  | June 27, 2020 |
| Operating lease right-of-use assets | $ | 87.3 |  |  | $ | 90.3 |  |
| Less: accumulated amortization | (19.9) |  |  | (11.6) |  |
| Operating lease right-of-use assets, net | $ | 67.4 |  |  | $ | 78.7 |  |

[0001628280-21-017799:notes:214]
Property, plant and equipment, net

[0001628280-21-017799:notes:215]
The components of property, plant and equipment, net were as follows (in millions):

[0001628280-21-017799:notes:216]
|  | July 3, 2021 |  | June 27, 2020 |
| Land | $ | 38.2 |  |  | $ | 44.1 |  |
| Buildings and improvement | 92.7 |  |  | 114.8 |  |
| Machinery and equipment | 498.3 |  |  | 487.0 |  |
| Computer equipment and software | 28.6 |  |  | 27.5 |  |
| Furniture and fixtures | 8.8 |  |  | 7.2 |  |
| Leasehold improvements | 33.9 |  |  | 27.8 |  |
| Finance lease right-of-use assets | 28.1 |  |  | 28.1 |  |
| Construction in progress | 43.4 |  |  | 54.7 |  |
|  | 772.0 |  |  | 791.2 |  |
| Less: Accumulated depreciation | (410.9) |  |  | (398.2) |  |
| Property, plant and equipment, net | $ | 361.1 |  |  | $ | 393.0 |  |

[0001628280-21-017799:notes:217]
During fiscal 2021, 2020 and 2019, we recorded depreciation expense of $91.4 million, $113.3 million, and $102.9 million, respectively.

[0001628280-21-017799:notes:218]
During the fourth quarter of fiscal 2021, we sold land and building located in San Jose, California for $23.0 million and recognized a gain of $8.3 million, which was recorded as an offset to selling, general and administrative expenses in our Consolidated Statement of Operations as of July 3, 2021.

[0001628280-21-017799:notes:219]
Our construction in progress primarily includes machinery and equipment that we expect to place in service in the next 12 months.

[0001628280-21-017799:notes:220]
Other current liabilities

[0001628280-21-017799:notes:221]
The components of other current liabilities were as follows (in millions):

[0001628280-21-017799:notes:222]
|  | July 3, 2021 |  | June 27, 2020 |
| Restructuring accrual and related charges (1) | $ | 5.7 |  |  | $ | 5.2 |  |
| Warranty accrual (2) | 5.0 |  |  | 5.0 |  |
| Deferred revenue and customer deposits | 0.6 |  |  | 1.9 |  |
| Finance lease liabilities, current | — |  |  | 0.6 |  |
| Income tax payable (3) | 43.5 |  |  | 28.8 |  |
| Other current liabilities | 3.0 |  |  | 2.8 |  |
| Other current liabilities | $ | 57.8 |  |  | $ | 44.3 |  |

[0001628280-21-017799:notes:223]
(1) Refer to “Note 14. Restructuring and Related Charges.”

[0001628280-21-017799:notes:224]
(2) Refer to “Note 19. Commitments and Contingencies.”

[0001628280-21-017799:notes:225]
(3) Refer to “Note 16. Income Taxes.”

[0001628280-21-017799:notes:226]
Other non-current liabilities

[0001628280-21-017799:notes:227]
The components of other non-current liabilities were as follows (in millions):

[0001628280-21-017799:notes:228]
|  | July 3, 2021 |  | June 27, 2020 |
| Asset retirement obligation | $ | 4.7 |  |  | $ | 4.6 |  |
| Pension and related accrual (1) | 10.8 |  |  | 11.8 |  |
| Unrecognized tax benefit | 23.0 |  |  | 17.3 |  |
| Other non-current liabilities | 2.4 |  |  | 2.3 |  |
| Other non-current liabilities | $ | 40.9 |  |  | $ | 36.0 |  |

[0001628280-21-017799:notes:229]
(1) We have defined benefit pension plans in Japan, Switzerland, and Thailand. As of July 3, 2021, the projected benefit obligations, net of plan assets, in Japan, Switzerland, and Thailand were $2.9 million, $4.8 million, and $3.1 million, respectively. As of June 27, 2020, the projected benefit obligations, net of plan assets, in Japan, Switzerland and Thailand were $2.9 million, $6.4 million and $2.5 million, respectively.


## us-gaap:LesseeFinanceLeasesTextBlock

[0001628280-21-017799:notes:230]
Note 9. Leases

[0001628280-21-017799:notes:231]
In February 2016, FASB issued ASU 2016-02, Leases (Topic 842) and subsequent amendments to the initial guidance: ASU 2017-13, ASU 2018-10, ASU 2018-11, ASU 2018-20 and ASU 2019-01 (collectively, Topic 842). Effective June 30, 2019, we adopted Topic 842, using the modified retrospective transition approach. We applied the new guidance to all leases existing as of the date of adoption. Our reported results beginning with the first quarter of fiscal 2020 reflect the application of Topic 842, while prior period amounts have not been adjusted and continue to be reported in accordance with our historical accounting under Topic 840.

[0001628280-21-017799:notes:232]
We elected the practical expedient package permitted under the transition approach. As such, we did not reassess whether any expired or existing contracts are or contain leases, we did not reassess our historical lease classification, and we did not reassess our initial direct costs for any leases that existed prior to June 30, 2019. We have also elected to combine lease and non-lease components at a portfolio level for our operating leases of buildings and not to report leases with an initial term of 12 months or less on our balance sheet.

[0001628280-21-017799:notes:233]
As of the date of adoption, we recognized operating lease assets of $91.5 million, with corresponding operating lease liabilities of $81.5 million on the Consolidated Balance Sheets. The difference between the operating lease right-of-use assets and operating lease liabilities primarily represents the existing asset recognized in relation to the favorable terms of an operating lease acquired through a business combination offset by our deferred rent and ASC 420 “cease-use” balances. All existing leases that were classified as capital leases under Topic 840 are classified as finance leases under the new guidance. As of adoption, we recognized finance lease assets of $12.4 million in property, plant and equipment, net, with corresponding finance lease liabilities of $12.4 million on the Consolidated Balance Sheets. For further information regarding the impact of Topic 842 adoption, see “Note 1. Description of Business and Summary of Significant Accounting Policies”.

[0001628280-21-017799:notes:234]
We lease certain real and personal property from unrelated third parties under non-cancellable operating leases that expire at various dates through fiscal 2033. These operating leases are mainly for administrative offices, research-and-development and manufacturing facilities, as well as sales offices in various countries around the world. Certain leases require us to pay property taxes, insurance and routine maintenance, and include escalation clauses. Many leases include one or more options to renew. We do not assume renewals in our determination of the lease term unless the renewals are deemed to be reasonably assured at lease commencement.

[0001628280-21-017799:notes:235]
We also have various finance leases of servers and certain other equipment for our operations. These arrangements are typically for two to four years.

[0001628280-21-017799:notes:236]
As of July 3, 2021, we sublease a portion of our offices in the United Kingdom, the United States, Canada, and Japan. These subleases will expire at various dates through fiscal year 2023. We anticipate receiving approximately $3.6 million in sublease income over the next two years.

[0001628280-21-017799:notes:237]
The components of lease costs, lease term, and discount rate are as follows (in millions):

[0001628280-21-017799:notes:238]
|  | July 3, 2021 |  | June 27, 2020 |
| Finance lease cost: |  |  |  |
| Amortization of right-of-use assets | $ | 0.5 |  |  | $ | 16.3 |  |
| Interest | — |  |  | 0.1 |  |
| Operating lease cost | 14.1 |  |  | 15.5 |  |
| Short-term and variable lease cost | 4.3 |  |  | 4.4 |  |
| Sublease income | (2.8) |  |  | (2.6) |  |
| Total lease cost | $ | 16.1 |  |  | $ | 33.7 |  |
| Weighted average remaining lease term (in years): |  |  |  |
| Operating leases | 7.5 |  | 8.6 |
| Finance leases | — |  | 1.0 |
| Weighted average discount rate: |  |  |  |
| Operating leases | 3.5 | % |  | 3.5 | % |
| Finance leases | — | % |  | 4.4 | % |

[0001628280-21-017799:notes:239]
As of July 3, 2021, maturities of our operating lease liabilities, which do not include short-term leases and variable lease payments, were as follows (in millions):

[0001628280-21-017799:notes:240]
| Fiscal Years |  | Operating Leases (1) |  |  |  |  |
| 2022 |  | $ | 14.0 |  |  |  |  |  |
| 2023 |  | 11.8 |  |  |  |  |  |
| 2024 |  | 9.9 |  |  |  |  |  |
| 2025 |  | 6.5 |  |  |  |  |  |
| 2026 |  | 5.2 |  |  |  |  |  |
| Thereafter |  | 20.0 |  |  |  |  |  |
| Total minimum lease payments |  | $ | 67.4 |  |  |  |  |  |
| Less: amount representing interest |  | (8.0) |  |  |  |  |  |
| Present value of total lease liabilities |  | $ | 59.4 |  |  |  |  |  |

[0001628280-21-017799:notes:241]
As of July 3, 2021, finance lease assets are fully amortized and there are no outstanding finance lease liabilities.

[0001628280-21-017799:notes:242]
(1)  Non-cancellable sublease proceeds for fiscal 2022 and 2023 of $2.8 million and $0.8 million, respectively, are not included in the table above.


## us-gaap:GoodwillDisclosureTextBlock

[0001628280-21-017799:notes:243]
Note 10. Goodwill and Other Intangible Assets

[0001628280-21-017799:notes:244]
The following table presents our goodwill balance by the reportable segments as of July 3, 2021 and June 27, 2020 (in millions):

[0001628280-21-017799:notes:245]
|  |  | Optical Communications |  | Commercial Lasers |  | Total |
| Balance as of July 3, 2021 and June 27, 2020 | $ | 363.5 |  |  | $ | 5.4 |  |  | $ | 368.9 |  |

[0001628280-21-017799:notes:246]
Impairment of Goodwill

[0001628280-21-017799:notes:247]
We review goodwill for impairment during the fourth quarter of each fiscal year or more frequently if events or circumstances indicate that an impairment loss may have occurred. Based on the impairment analysis performed in the fourth quarter of each year presented, the fair value of each of our reporting units substantially exceeded the carrying value; as such, our annual qualitative assessment did not indicate that a more detailed quantitative analysis was necessary.

[0001628280-21-017799:notes:248]
Other Intangibles

[0001628280-21-017799:notes:249]
In connection with our acquisition of Oclaro in fiscal year 2019, we recorded $443.0 million as the fair value of the acquired developed technologies and other intangible assets. This amount excludes $1.0 million of in-process research and development assets that were subsequently sold to CIG.

[0001628280-21-017799:notes:250]
The intangible assets are amortized on a straight-line basis over the estimated useful lives, except for customer relationships and order backlog, which are amortized using an accelerated method of amortization over the expected customer lives, which more accurately reflects the pattern of realization of economic benefits expected to be obtained. Acquired developed technologies and order backlog are amortized to cost of sales and customer relationships is amortized to selling, general and administrative. IPR&D” is initially capitalized at fair value as an intangible asset with an indefinite life and assessed for impairment thereafter. When an IPR&D project is completed, the IPR&D is reclassified as an amortizable purchased intangible asset and amortized over the asset’s estimated useful life.

[0001628280-21-017799:notes:251]
The following tables present details of our other intangibles as of the periods presented (in millions, except for weighted average remaining amortization period):

[0001628280-21-017799:notes:252]
| July 3, 2021 | Gross Carrying Amounts |  | Accumulated Amortization |  | Net Carrying Amounts |  | Weighted average remaining amortization period (years) |
| Acquired developed technologies | $ | 390.3 |  |  | $ | (238.6) |  |  | $ | 151.7 |  |  | 3.0 |
| Customer relationships | 145.0 |  |  | (55.5) |  |  | 89.5 |  |  | 5.4 |
| Order backlog | 22.0 |  |  | (22.0) |  |  | — |  |  | — |
| Other intangibles | 2.7 |  |  | (2.7) |  |  | — |  |  | — |
| Total intangible assets | $ | 560.0 |  |  | $ | (318.8) |  |  | $ | 241.2 |  |  |  |

[0001628280-21-017799:notes:253]
The table above excludes fully amortized intangibles of $5.5 million that were written off against accumulated amortization during the year ended July 3, 2021.

[0001628280-21-017799:notes:254]
During the year ended July 3, 2021, we completed our remaining IPR&D projects and reclassified $10.0 million from IPR&D to acquired developed technologies. This amount will be amortized over the assets’ estimated useful life of 3 years.

[0001628280-21-017799:notes:255]
During the year ended July 3, 2021, we purchased intellectual property from a third party for a total consideration of $10.0 million. These intangible assets have an estimated useful life of 5 years.

[0001628280-21-017799:notes:256]
| June 27, 2020 | Gross Carrying Amounts |  | Accumulated Amortization |  | Net Carrying Amounts |  | Weighted average remaining amortization period (years) |
| Acquired developed technologies | $ | 371.5 |  |  | $ | (176.9) |  |  | $ | 194.6 |  |  | 3.7 |
| Customer relationships | 149.3 |  |  | (37.1) |  |  | 112.2 |  |  | 6.5 |
| In-process research and development | 10.0 |  |  | — |  |  | 10.0 |  |  | n/a |
| Order backlog | 22.0 |  |  | (22.0) |  |  | — |  |  | — |
| Other intangibles | 2.7 |  |  | (2.7) |  |  | — |  |  | — |
| Total intangible assets | $ | 555.5 |  |  | $ | (238.7) |  |  | $ | 316.8 |  |  |  |

[0001628280-21-017799:notes:257]
During the year ended June 27, 2020, we completed $84.0 million of IPR&D projects, and reclassified the value assigned to these projects to acquired developed technologies. The amount will be amortized over the assets’ estimated useful life of 4 to 7 years.

[0001628280-21-017799:notes:258]
During fiscal 2021, 2020 and 2019, we recorded $85.7 million, $78.6 million, and $54.6 million, respectively, of amortization related to intangibles assets.

[0001628280-21-017799:notes:259]
The following table presents details of amortization for the periods presented (in millions):

[0001628280-21-017799:notes:260]
|  | Years ended |
|  | July 3, 2021 |  | June 27, 2020 |  |  |  | June 29, 2019 |
| Cost of sales | $ | 61.7 |  |  | $ | 53.8 |  |  |  |  | $ | 46.6 |  |
| Selling, general and administrative | 24.0 |  |  | 24.8 |  |  |  |  | 8.0 |  |
| Total amortization of intangibles | $ | 85.7 |  |  | $ | 78.6 |  |  |  |  | $ | 54.6 |  |

[0001628280-21-017799:notes:261]
Based on the carrying amount of our acquired developed technologies and other intangibles as of July 3, 2021, and assuming no future impairment of the underlying assets, the estimated future amortization is as follows (in millions):

[0001628280-21-017799:notes:262]
| Fiscal Years |  |
| 2022 | $ | 85.4 |  |
| 2023 | 61.9 |  |
| 2024 | 40.5 |  |
| 2025 | 27.7 |  |
| 2026 | 18.1 |  |
| Thereafter | 7.6 |  |
| Total | $ | 241.2 |  |


## lite:NoncontrollingInterestAndDerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001628280-21-017799:notes:263]
Note 11. Non-Controlling Interest Redeemable Convertible Preferred Stock and Derivative Liability

[0001628280-21-017799:notes:264]
On July 31, 2015, our wholly-owned subsidiary, Lumentum Inc., issued 40,000 shares of its Series A Preferred Stock to Viavi Solutions Inc. (“Viavi”). Pursuant to a securities purchase agreement between us, Viavi and Amada Holdings Co., Ltd. (“Amada”), 35,805 shares of Series A Preferred Stock were sold by Viavi to Amada in August 2015. The remaining 4,195 shares of the Series A Preferred Stock were canceled. The Series A Preferred Stock was referred to as our Non-Controlling Interest Redeemable Convertible Preferred Stock of $35.8 million on our Consolidated Statements of Redeemable Convertible Preferred Stock and Stockholders’ Equity  through the date of conversion in fiscal 2019.

[0001628280-21-017799:notes:265]
On October 15, 2018, we issued a 30-day notice of intent to the holders of Series A Preferred Stock to convert all shares of Series A Preferred Stock at a conversion price equal to the Issuance Value divided by $24.63 plus the accrued and unpaid dividends on each share and any past due dividends, whether or not authorized or declared. On November 2, 2018, we received notice from Amada of their intent to convert the Series A Preferred Stock and we issued 1.5 million shares of our common stock to Amada upon the conversion of the 35,805 shares of Series A Preferred Stock and recorded $79.4 million in additional paid in capital in the balance sheet.

[0001628280-21-017799:notes:266]
Through the date of conversion, holders of Series A Preferred Stock, in preference to holders of common stock or any other class or series of our outstanding capital stock ranking in any such event junior to the Series A Preferred Stock, were entitled to receive, when and as declared by the board of directors, quarterly cumulative cash dividends at the annual rate of 2.5% of the Issuance Value per share on each outstanding share of Series A Preferred Stock. The accrued dividends were payable on March 31, June 30, September 30 and December 31 of each year commencing on September 30, 2015. During the year ended June 29, 2019, we paid $0.7 million in dividends to the holders of Series A Preferred Stock.

[0001628280-21-017799:notes:267]
Through the date of conversion, the Series A Preferred Stock conversion feature was bifurcated from the Series A Preferred Stock and accounted for separately as a derivative liability. The derivative liability was measured at fair value each reporting period, and at the date of conversion, with the change in fair value recorded in the Consolidated Statements of Operations.

[0001628280-21-017799:notes:268]
The following table provides a reconciliation of the fair value of the embedded derivative for the Series A Preferred Stock for the year ended June 29, 2019 (in millions):

[0001628280-21-017799:notes:269]
|  |  |  |  |  | Year Ended |  |  |
|  |  |  |  |  |  |  | June 29, 2019 |  |  |
| Balance as of beginning of period |  |  |  |  |  |  | $ | 52.4 |  |  |  |
| Unrealized gain on the Series A Preferred Stock derivative liability up through the conversion date |  |  |  |  |  |  | (8.8) |  |  |  |
| Settlement of the derivative liability upon conversion of Series A Preferred Stock |  |  |  |  |  |  | (43.6) |  |  |  |
| Balance as of end of period |  |  |  |  |  |  | $ | — |  |  |  |


## us-gaap:DebtDisclosureTextBlock

[0001628280-21-017799:notes:270]
Note 12. Debt

[0001628280-21-017799:notes:271]
Convertible Notes

[0001628280-21-017799:notes:272]
2026 Notes

[0001628280-21-017799:notes:273]
In December 2019, we issued $1,050.0 million in aggregate principal amount of the 2026 Notes in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act of 1933, as amended (the “Securities Act”). The 2026 Notes are governed by an indenture between the Company and U.S. Bank National Association (the “2026 Indenture”). We used approximately $196.0 million of the net proceeds of the offering to repay in full all amounts outstanding under our term loan facility, and a portion of the net proceeds of the offering to purchase approximately $200.0 million of our common stock concurrently with the pricing of the offering in privately negotiated transactions. The 2026 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, the incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001628280-21-017799:notes:274]
The 2026 Notes bear interest at a rate of 0.50% per year, payable semi-annually in arrears on June 15 and December 15 of each year, beginning on June 15, 2020. The 2026 Notes will mature on December 15, 2026, unless earlier redeemed, repurchased by us, or converted pursuant to their terms.

[0001628280-21-017799:notes:275]
The initial conversion rate is 10.0711 shares of common stock per $1,000 principal amount of the 2026 Notes (which is equivalent to an initial conversion price of approximately $99.29 per share). The conversion rate is subject to adjustment upon the occurrence of certain events specified in the 2026 Indenture but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares set forth in the 2026 Indenture or a holder that elects to convert the 2026 Notes in connection with such make-whole fundamental change or notice of redemption.

[0001628280-21-017799:notes:276]
Prior to the close of business on the business day immediately preceding September 15, 2026, holders of the 2026 Notes may convert their 2026 Notes only under the following circumstances:

[0001628280-21-017799:notes:277]
•during any fiscal quarter commencing after the fiscal quarter ended on March 28, 2020 (and only during such fiscal quarter), if the last reported sale price of the common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price of the 2026 Notes, or $129.08 on each applicable trading day;

[0001628280-21-017799:notes:278]
•during the five business day period after any five consecutive trading day period (the "2026 measurement period") in which the trading price per $1,000 principal amount of the 2026 Notes for each trading day of the 2026 measurement period was less than 98% of the product of the last reported sale price of our common stock and the conversion rate for the notes on each such trading day;

[0001628280-21-017799:notes:279]
•if we call any or all of the 2026 Notes for redemption, at any time prior to the close of business on the second business day immediately preceding the relevant redemption date; or

[0001628280-21-017799:notes:280]
•upon the occurrence of specified corporate events, as specified in each indenture governing the 2026 Notes.

[0001628280-21-017799:notes:281]
On or after September 15, 2026 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert the 2026 Notes at any time. Upon conversion, we may satisfy our conversion obligation in cash, shares of common stock or a combination of cash and shares of common stock, at our election.

[0001628280-21-017799:notes:282]
We may redeem for cash, stock or combination of both for all or any portion of the 2026 Notes, at our option, on or after December 20, 2023, if the last reported sale price of its common stock has been at least 130% of the conversion price then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading-day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which we provide a notice of redemption at a redemption price equal to 100% of the principal amount of the 2026 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. No sinking fund is provided for the 2026 Notes. Upon the occurrence of a fundamental change (as defined in the 2026 Indenture), holders may require us to repurchase all or a portion of the 2026 Notes for cash at a price equal to 100% of the principal amount of the 2026 Notes to be repurchased, plus any accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

[0001628280-21-017799:notes:283]
In accordance with accounting for debt with conversions and other options, we bifurcated the principal amount of the 2026 Notes into liability and equity components. The liability component of the 2026 Notes was valued at $734.8 million based on the contractual cash flows discounted at an appropriate comparable market non-convertible debt borrowing rate at the date of issuance of 5.8% with the equity component representing the residual amount of the proceeds of $315.2 million, which was recorded as a debt discount.

[0001628280-21-017799:notes:284]
We incurred approximately $7.8 million in transaction costs in connection with the issuance of the 2026 Notes and these costs were allocated pro rata based on the relative carrying amounts of the liability and equity components. The debt discount and debt issuance costs attributable to the liability component will be amortized to interest expense using an effective interest rate of 5.8% over the expected life of the 2026 Notes. Debt issuance costs attributable to the equity component are netted with the equity component in stockholders’ equity, and the equity component is not remeasured as long as it continues to meet the conditions for equity classification.

[0001628280-21-017799:notes:285]
2024 Notes

[0001628280-21-017799:notes:286]
In March 2017, we issued $450.0 million of the 2024 Notes in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act. The 2024 Notes are governed by an indenture between the Company, as the issuer, and U.S. Bank National Association, as trustee (the “2024 Indenture”). The 2024 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001628280-21-017799:notes:287]
The 2024 Notes bear interest at a rate of 0.25% per year. Interest on the 2024 Notes is payable semi-annually in arrears on March 15 and September 15 of each year, beginning on September 15, 2017. The 2024 Notes will mature on March 15, 2024, unless earlier repurchased by us or converted pursuant to their terms.

[0001628280-21-017799:notes:288]
The initial conversion rate of the 2024 Notes is 16.4965 shares of common stock per $1,000 principal amount of 2024 Notes, which is equivalent to an initial conversion price of approximately $60.62 per share, a 132.5% premium to the fair market value at the date of issuance. Prior to the close of business on the business day immediately preceding December 15, 2023, each holder of the 2024 Notes may convert their 2024 Notes only under the following circumstances:

[0001628280-21-017799:notes:289]
•during any fiscal quarter (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during the period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price, or $78.80 on each applicable trading day;

[0001628280-21-017799:notes:290]
•during the five consecutive business day period after any five consecutive trading day period (the “2024 measurement period”) in which the trading price per $1,000 principal amount of notes for each trading day of such 2024 measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate on each such trading day;

[0001628280-21-017799:notes:291]
•upon the occurrence of specified corporate events.

[0001628280-21-017799:notes:292]
On or after December 15, 2023 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their 2024 Notes at any time. In addition, upon the occurrence of a make-whole fundamental change (as defined in the 2024 Indenture), we will, in certain circumstances, increase the conversion rate by a number of additional shares set forth in the 2024 Indenture for a holder that elects to convert 2024 Notes in connection with such make-whole fundamental change.

[0001628280-21-017799:notes:293]
We may not redeem the 2024 Notes prior to their maturity date and no sinking fund is provided for the 2024 Notes. Upon the occurrence of a fundamental change, holders may require us to repurchase all or a portion of their 2024 Notes for cash at a price equal to 100% of the principal amount of the 2024 Notes to be repurchased, plus any accrued and unpaid interest.

[0001628280-21-017799:notes:294]
We considered the features embedded in the 2024 Notes other than the conversion feature, including the holders’ put feature, our call feature, and the make-whole feature, and concluded that they are not required to be bifurcated and accounted for separately from the host debt instrument.

[0001628280-21-017799:notes:295]
Prior to the Tax Matters Agreement settlement condition (“TMA settlement condition”), because we could only settle the 2024 Notes in cash, we determined that the conversion feature met the definition of a derivative liability. We separated the derivative liability from the host debt instrument based on the fair value of the derivative liability. As of the issuance date, March 8, 2017, the derivative liability fair value of $129.9 million was calculated using the binomial valuation approach. The residual principal amount of the 2024 Notes of $320.1 million before issuance costs was allocated to the debt component. We incurred approximately $7.7 million in transaction costs in connection with the issuance of the 2024 Notes. These costs were allocated to the debt component and recognized as a debt discount. We amortize the debt discount, including both the initial value of the derivative liability and the transaction costs, over the term of the 2024 Notes using the effective interest method. The effective interest rate of the 2024 Notes is 5.4% per year.

[0001628280-21-017799:notes:296]
During the fiscal year ended July 1, 2017, we satisfied the TMA settlement condition. As such, the value of the conversion option is no longer marked to market and was reclassified to additional paid-in capital within stockholders’ equity on our Consolidated Balance Sheet. The value of the conversion option at the time of issuance will be treated as an original issue discount for purposes of accounting for the debt component of the notes. The debt component will accrete up to the principal amount over the expected term of the debt.

[0001628280-21-017799:notes:297]
Our convertible notes consisted of the following components as of the periods presented (in millions):

[0001628280-21-017799:notes:298]
| Liability component: | July 3, 2021 |  | June 27, 2020 |
|  | 2024 Notes (1) |  | 2026 Notes |  | 2024 Notes |  | 2026 Notes |
| Principal | $ | 450.0 |  |  | $ | 1,050.0 |  |  | $ | 450.0 |  |  | $ | 1,050.0 |  |
| Unamortized debt discount and debt issuance costs | (59.3) |  |  | (260.2) |  |  | (79.4) |  |  | (300.3) |  |
| Net carrying amount of the liability component | $ | 390.7 |  |  | $ | 789.8 |  |  | $ | 370.6 |  |  | $ | 749.7 |  |

[0001628280-21-017799:notes:299]
(1) Since the closing price of our stock exceeded $78.80 (or 130% of the conversion price of $60.62) for 20 of the last 30 trading days of the fourth quarter of fiscal 2021, the 2024 Notes have become convertible at the option of the holders. Therefore, the debt component of our 2024 Notes as of July 3, 2021 has been classified as current liabilities in our Consolidated Balance Sheet.

[0001628280-21-017799:notes:300]
If the closing price of our stock exceeds $129.08 (or 130% of the conversion price of $99.29) for 20 of the last 30 trading days of any future quarter, our 2026 Notes would also become convertible at the option of the holders and the debt component would be reclassified to current liabilities in our Consolidated Balance Sheet.

[0001628280-21-017799:notes:301]
The following table sets forth interest expense information related to the convertible notes for the periods presented (in millions):

[0001628280-21-017799:notes:302]
|  |  |  |  |  | July 3, 2021 |  | June 27, 2020 |  | June 29, 2019 |
| Contractual interest expense |  |  |  |  | $ | 6.5 |  |  | $ | 3.9 |  |  | $ | 1.1 |  |
| Amortization of the debt discount and debt issuance costs |  |  |  |  | 60.2 |  |  | 39.1 |  |  | 17.7 |  |
| Total interest expense |  |  |  |  | $ | 66.7 |  |  | $ | 43.0 |  |  | $ | 18.8 |  |

[0001628280-21-017799:notes:303]
The future interest and principal payments related to our convertible notes are as follows as of July 3, 2021 (in millions):

[0001628280-21-017799:notes:304]
| Fiscal Years | 2024 Notes |  | 2026 Notes |  | Total |
| 2022 | $ | 1.1 |  |  | $ | 5.3 |  |  | $ | 6.4 |  |
| 2023 | 1.1 |  |  | 5.2 |  |  | 6.3 |  |
| 2024 | 451.2 |  |  | 5.3 |  |  | 456.5 |  |
| 2025 | — |  |  | 5.2 |  |  | 5.2 |  |
| 2026 | — |  |  | 5.3 |  |  | 5.3 |  |
| Thereafter | — |  |  | 1,052.6 |  |  | 1,052.6 |  |
| Total convertible notes payments | $ | 453.4 |  |  | $ | 1,078.9 |  |  | $ | 1,532.3 |  |

[0001628280-21-017799:notes:305]
The principal balances of our Notes are reflected in the payment periods in the table above based on their respective contractual maturities. As discussed above, during the year ended July 3, 2021, the 2024 Notes became convertible at the option of the holders. We received conversion requests of less than $0.1 million, which was settled in cash in the fourth quarter of fiscal 2021.

[0001628280-21-017799:notes:306]
Term Loan Facility

[0001628280-21-017799:notes:307]
In December 2018, concurrent with the closing of the Oclaro merger, we entered into a credit agreement providing for a term loan facility (the “Term Loan Facility”) in an aggregate principal amount of $500.0 million. and we drew in full the term loans available under the Term Loan Facility on the closing date of the Oclaro merger. In the second quarter of fiscal 2020, we repaid, in full, all amounts outstanding under our Term Loan Facility. During the year ended June 27, 2020, we incurred $18.1 million of interest expense on this Term Loan Facility, which includes an $8.0 million loss on the early extinguishment of debt.

[0001628280-21-017799:notes:308]
Other Interest Expense
For the year ended June 27, 2020, we recorded $0.1 million interest expense related to our finance leases.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001628280-21-017799:notes:309]
Note 13. Accumulated Other Comprehensive Income

[0001628280-21-017799:notes:310]
Our accumulated other comprehensive income consists of the accumulated net unrealized gains or losses on foreign currency translation adjustments, defined benefit obligations, and available-for-sale securities.

[0001628280-21-017799:notes:311]
The changes in accumulated other comprehensive income, net of tax were as follows for the periods as presented (in millions):

[0001628280-21-017799:notes:312]
|  | Foreign currency translation adjustments, net of tax (1) |  | Defined benefit obligations, net of tax (2) |  | Unrealized gain (loss) on available-for-sale securities, net of tax (3) |  | Total |
| Ending balance as of June 30, 2018 | $ | 10.3 |  |  | $ | (2.3) |  |  | $ | (1.6) |  |  | $ | 6.4 |  |
| Other comprehensive income (loss) | (0.6) |  |  | (1.2) |  |  | 2.5 |  |  | 0.7 |  |
| Ending balance as of June 29, 2019 | 9.7 |  |  | (3.5) |  |  | 0.9 |  |  | 7.1 |  |
| Other comprehensive income (loss) | — |  |  | (0.7) |  |  | 1.5 |  |  | 0.8 |  |
| Ending balance as of June 27, 2020 | 9.7 |  |  | (4.2) |  |  | 2.4 |  |  | 7.9 |  |
| Other comprehensive income (loss) | — |  |  | 2.8 |  |  | (2.5) |  |  | 0.3 |  |
| Ending balance as of July 3, 2021 | $ | 9.7 |  |  | $ | (1.4) |  |  | $ | (0.1) |  |  | $ | 8.2 |  |

[0001628280-21-017799:notes:313]
(1) In fiscal 2019, as a result of significant changes in economic facts and circumstances, primarily due to the acquisition of Oclaro, we established the functional currency for our worldwide operations as the U.S. dollar. Translation adjustments reported prior to December 10, 2018, remain as a component of accumulated other comprehensive income in our Consolidated Balance Sheets, until all or a part of the investment in the subsidiaries is sold or liquidated.
(2) We evaluate the assumptions over the fair value of our defined benefit obligations annually and make changes as necessary.  During each of fiscal 2021, 2020, and 2019, our income (loss) on defined benefit obligations is presented net of tax of $0.0 million, $0.2 million, and $0.2 million, respectively.(3) In fiscal 2021, 2020 and 2019, our unrealized gain (loss) on available-for-sale securities is presented net of tax of $(0.5) million, $0.3 million and $0.2 million, respectively.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001628280-21-017799:notes:314]
Note 14. Restructuring and Related Charges

[0001628280-21-017799:notes:315]
We have initiated various strategic restructuring actions primarily intended to reduce costs, consolidate our operations, rationalize the manufacturing of our products and align our business in response to market conditions.

[0001628280-21-017799:notes:316]
The following table summarizes the activity of restructuring and related charges during the periods presented (in millions):

[0001628280-21-017799:notes:317]
|  | Years Ended |  |  |
|  | July 3, 2021 |  | June 27, 2020 |  |  |  | June 29, 2019 |  |  |
| Balance as of beginning of period | $ | 5.2 |  |  | $ | 14.6 |  |  |  |  | $ | 1.9 |  |  |  |
| Charges | 7.7 |  |  | 8.0 |  |  |  |  | 31.9 |  |  |  |
| Payments | (7.2) |  |  | (17.4) |  |  |  |  | (19.2) |  |  |  |
| Balance as of end of period | $ | 5.7 |  |  | $ | 5.2 |  |  |  |  | $ | 14.6 |  |  |  |

[0001628280-21-017799:notes:318]
During fiscal 2021, we recorded restructuring and related charges of $7.7 million in our Consolidated Statements of Operations. The charges were mainly attributable to severance charges associated with the decision to cease manufacturing of certain products in San Jose, California, as well as other cost reduction measures taken across the Company impacting all regions.

[0001628280-21-017799:notes:319]
During fiscal 2020, we recorded $8.0 million in restructuring and related charges in our Consolidated Statements of Operations. The charges were mainly attributable to severance charges associated with the decision to move certain manufacturing from San Jose, California to our facility in Thailand and other third party vendors.

[0001628280-21-017799:notes:320]
During fiscal 2019, we recorded $31.9 million in restructuring and related charges in our Consolidated Statements of Operations, primarily attributable to severance and employee related benefits associated with the wind down of operations for Lithium Niobate modulators and Datacom modules of $21.1 million. In addition, the charges included severance and employee related benefits associated with Oclaro’s executive severance and retention agreements. These retention agreements provided, under certain circumstances, for payments and benefits upon an involuntary termination of employment. In fiscal 2019, we also recorded $1.6 million of lease restructuring charges for the former Oclaro corporate headquarters and restructuring charges primarily associated with acquisition related synergies.

[0001628280-21-017799:notes:321]
Any changes in the estimates of executing our restructuring activities will be reflected in our future results of operations.


## us-gaap:AssetImpairmentChargesTextBlock

[0001628280-21-017799:notes:322]
Note 15. Impairment and Other Charges

[0001628280-21-017799:notes:323]
Impairment Charges Associated with Exist of Product Lines

[0001628280-21-017799:notes:324]
The following table summarizes the activity of  impairment charges during the periods presented (in millions):

[0001628280-21-017799:notes:325]
|  |  | Years Ended |
|  |  |  |  | July 3, 2021 |  | June 27, 2020 |  | June 29, 2019 |
| Impairment charges |  |  |  | $ | — |  |  | $ | 4.3 |  |  | $ | 30.7 |  |

[0001628280-21-017799:notes:326]
In the third quarter of fiscal 2019, we announced our plan to discontinue the development and manufacturing of Datacom transceiver modules which impacted the California and China based Datacom module teams. As a result of these actions, we recorded impairment charges of $4.3 million and $30.7 million in fiscal 2020 and 2019, respectively, related to our long-lived assets that were not deemed to be useful. While we expect strong growth in Datacom volumes in the future, gross margins at the transceiver market level are lower due to extreme competition. Following the Oclaro acquisition, we have a differentiated leadership position across a range of photonic chips on which the Datacom, wireless, and access markets critically rely.

[0001628280-21-017799:notes:327]
In fiscal 2020 and 2019, we also recorded inventory and fixed asset write-down charges of $7.0 million and $20.8 million, respectively, related to the decision to exit the Datacom module and Lithium Niobate product lines in our cost of goods sold in

[0001628280-21-017799:notes:328]
our Consolidated Statements of Operations. Refer to “Note 5. Assets Held For Sale and Related Dispositions” for details on the exit from these product lines.

[0001628280-21-017799:notes:329]
These actions do not qualify as discontinued operations for disclosure purposes as they do not represent a strategic shift having a major effect on an entity’s operations and financial results.

[0001628280-21-017799:notes:330]
Other Losses on Property, Plant and Equipment

[0001628280-21-017799:notes:331]
We recorded fixed assets losses, mainly attributable to the retirement and disposal of fixed assets, net of proceed received, and not associated with the exit from product lines. The impact of such losses on our results of operations by function during the periods presented was as follows (in millions):

[0001628280-21-017799:notes:332]
|  | Years Ended |
|  | July 3, 2021 |  | June 27, 2020 |  |  |  |  | June 29, 2019 |
| Cost of sales | $ | 9.3 |  |  | $ | 16.1 |  |  |  |  |  | $ | 2.2 |  |
| Research and development | 0.3 |  |  | 0.8 |  |  |  |  |  | — |  |
| Selling, general and administrative (1) | (7.2) |  |  | 0.6 |  |  |  |  |  | — |  |
|  | $ | 2.4 |  |  | $ | 17.5 |  |  |  |  |  | $ | 2.2 |  |

[0001628280-21-017799:notes:333]
(1)  In fiscal year 2021, we made a decision to cease manufacturing of certain products at a manufacturing facility that we owned in San Jose, California.  During the fourth quarter of fiscal 2021, we shut down the manufacturing site and sold the related land and building for $23.0 million and recognized a gain of $8.3 million, which was recorded as an offset to operating expenses.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-21-017799:notes:334]
Note 16. Income Taxes

[0001628280-21-017799:notes:335]
Our income (loss) before income taxes consisted of the following (in millions):

[0001628280-21-017799:notes:336]
|  | Years Ended |
|  | July 3, 2021 |  | June 27, 2020 |  | June 29, 2019 |
| Domestic | $ | 314.9 |  |  | $ | (33.1) |  |  | $ | (21.9) |  |
| Foreign | 148.2 |  |  | 207.4 |  |  | (11.4) |  |
| Income (loss) before income taxes | $ | 463.1 |  |  | $ | 174.3 |  |  | $ | (33.3) |  |

[0001628280-21-017799:notes:337]
Our income tax provision consisted of the following (in millions):

[0001628280-21-017799:notes:338]
|  | Years Ended |
|  | July 3, 2021 |  | June 27, 2020 |  | June 29, 2019 |
| Federal: |  |  |  |  |  |
| Current | $ | 30.5 |  |  | $ | 2.9 |  |  | $ | 13.8 |  |
| Deferred | 9.2 |  |  | 19.3 |  |  | (0.1) |  |
|  | 39.7 |  |  | 22.2 |  |  | 13.7 |  |
| State: |  |  |  |  |  |
| Current | 1.7 |  |  | 0.1 |  |  | 0.1 |  |
| Deferred | (0.3) |  |  | (0.4) |  |  | 0.4 |  |
|  | 1.4 |  |  | (0.3) |  |  | 0.5 |  |
| Foreign: |  |  |  |  |  |
| Current | 36.5 |  |  | 23.4 |  |  | 10.3 |  |
| Deferred | (11.8) |  |  | (6.5) |  |  | (21.4) |  |
|  | 24.7 |  |  | 16.9 |  |  | (11.1) |  |
| Total income tax provision | $ | 65.8 |  |  | $ | 38.8 |  |  | $ | 3.1 |  |

[0001628280-21-017799:notes:339]
The provision for income taxes differs from the amount computed by applying the U.S. Federal statutory income tax rate to our income before provision for income taxes as follows (in millions):

[0001628280-21-017799:notes:340]
|  | Years Ended |
|  | July 3, 2021 |  | June 27, 2020 |  | June 29, 2019 |
| Income tax (benefit) provision computed at federal statutory rate | $ | 97.3 |  |  | $ | 36.6 |  |  | $ | (7.0) |  |
| Foreign rate differential | (50.4) |  |  | (24.6) |  |  | (17.8) |  |
| Change in valuation allowance | 45.4 |  |  | 13.4 |  |  | 7.4 |  |
| Tax credits | (31.8) |  |  | (10.2) |  |  | (7.1) |  |
| Stock-based compensation | 5.6 |  |  | 4.8 |  |  | 5.9 |  |
| Subpart F and GILTI | 42.1 |  |  | 22.9 |  |  | 13.4 |  |
| Unrecognized tax benefits | (3.7) |  |  | (1.7) |  |  | 4.8 |  |
| Change in Non-US Statutory Tax Rates | (35.8) |  |  | (2.8) |  |  | — |  |
| Other | (2.9) |  |  | 0.4 |  |  | 0.5 |  |
| Audit settlement | — |  |  | — |  |  | 3.0 |  |
| Total income tax provision | $ | 65.8 |  |  | $ | 38.8 |  |  | $ | 3.1 |  |
| Effective tax rate | 14.22 | % |  | 22.26 | % |  | (9.31) | % |

[0001628280-21-017799:notes:341]
Our provision for income taxes for fiscal 2021 differs from the 21% U.S. statutory rate primarily due to income tax benefit from earnings of our foreign subsidiaries being taxed at rates that differ from the U.S. statutory rate, which is offset by the tax expense from U.S. income inclusions from Subpart F and GILTI. Further our provision for income taxes includes an income tax benefit from various tax credits and non-U.S. statutory rate changes enacted during the year, offset by an income tax expense from non-deductible stock-based compensation as well as change in valuation allowance because it is not more-likely-than-not that certain deferred tax assets will be realizable in the future.

[0001628280-21-017799:notes:342]
Our provision for income taxes for fiscal 2020 differs from the 21% U.S. statutory rate primarily due to the income tax benefit of the earnings of our foreign subsidiaries being taxed at rates that differ from the U.S. statutory rate and certain tax credits, which is offset by the tax expense from U.S. income inclusions from Subpart F and GILTI.  Further our provision for income taxes includes an income tax expense from changes in our valuation allowance because it is not more-likely-than-not that certain deferred tax assets will be realized in the future.

[0001628280-21-017799:notes:343]
Our provision for income taxes for fiscal 2019 differs from the 21% U.S. statutory rate primarily due to the income tax benefit of the earnings of our foreign subsidiaries being taxed at rates that differ from the U.S. statutory rate and tax credits, which is offset by the tax expense from U.S. income inclusions from Subpart F and GILTI.

[0001628280-21-017799:notes:344]
The components of our net deferred taxes consisted of the following (in millions):

[0001628280-21-017799:notes:345]
|  | Years Ended |
|  | July 3, 2021 |  | June 27, 2020 |  |  |
| Gross deferred tax assets: |  |  |  |  |  |
| Intangibles | $ | 92.0 |  |  | $ | 101.1 |  |  |  |
| Tax credit carryforwards | 75.3 |  |  | 67.8 |  |  |  |
| Net operating loss carryforwards | 172.7 |  |  | 129.8 |  |  |  |
| Inventories | 6.8 |  |  | 7.4 |  |  |  |
| Accruals and reserves | 10.6 |  |  | 13.1 |  |  |  |
| Fixed assets | 23.9 |  |  | 23.2 |  |  |  |
| Capital loss carryforwards | 12.6 |  |  | 11.5 |  |  |  |
| Unclaimed research and experimental development expenditure | 42.1 |  |  | 33.4 |  |  |  |
| Stock-based compensation | 5.1 |  |  | 3.6 |  |  |  |
| Lease liabilities | 16.3 |  |  | 17.7 |  |  |  |
| Other | 0.3 |  |  | 0.2 |  |  |  |
| Gross deferred tax assets | 457.7 |  |  | 408.8 |  |  |  |
| Valuation allowance | (272.4) |  |  | (200.8) |  |  |  |
| Deferred tax assets | 185.3 |  |  | 208.0 |  |  |  |
| Gross deferred tax liabilities: |  |  |  |  |  |
| Intangible amortization | (59.6) |  |  | (68.5) |  |  |  |
| Convertible notes | (68.0) |  |  | (79.4) |  |  |  |
| Right-of-use assets | (19.6) |  |  | (21.3) |  |  |  |
| Other | (1.1) |  |  | (4.1) |  |  |  |
| Deferred tax liabilities | (148.3) |  |  | (173.3) |  |  |  |
| Total net deferred tax assets | $ | 37.0 |  |  | $ | 34.7 |  |  |  |

[0001628280-21-017799:notes:346]
We assess our ability to realize the deferred tax assets on a quarterly basis and establish a valuation allowance if the deferred tax assets are not more-likely-than-not to be realized. We weigh all available positive and negative evidence, including our earnings history and results of recent operations, reversals of deferred tax liabilities, projected future taxable income, and tax planning strategies. As of each reporting date, we consider new evidence, both positive and negative, that could affect our view of the future realization of deferred tax assets. For fiscal 2021, we continue to maintain a valuation allowance against certain deferred tax assets as, due to the weight of available negative evidence, it is not more-likely-than-not that such deferred tax assets will be realized in the future. Our valuation allowance is related to our  California, Thailand, Canada, and UK deferred tax assets, and partial valuation allowance on our federal deferred tax asset related to foreign tax credits. In the event the Company determines that it will be able to realize all or part of the deferred tax assets in the future, the valuation allowance will be reversed in the period in which the Company makes such determination. Based on the information currently available, we do not believe that a significant portion of our valuation allowance for the U.S., California, Thailand, Canada, and UK will be released in the next 12 months. Such a release would result in the recognition of certain deferred tax assets and a decrease in the income tax expense for the period in which the release is recorded.

[0001628280-21-017799:notes:347]
As of July 3, 2021, the Company had federal and foreign net operating loss carryforwards of $121.0 million and $583.3 million, respectively. These carryforwards will begin to expire in fiscal 2022. The federal and foreign tax attributes carried forward are subject to various rules which impose limitations on the utilization.

[0001628280-21-017799:notes:348]
Additionally, the Company has federal, state, and foreign research and other tax credit carryforwards of $6.3 million, $47.0 million, and $45.2 million, respectively. The federal credits will begin to expire in the fiscal year ending 2033 and California credits can be carried forward indefinitely. The foreign tax credits began to expire in the fiscal year ending 2022.

[0001628280-21-017799:notes:349]
Current U.S. tax law generally provides greater flexibility for us to access and utilize our cash held by certain of our foreign subsidiaries and we intend to repatriate all or some of the earnings of our subsidiaries in the Cayman Islands, Japan, and Hong Kong. As to all other foreign subsidiaries, we intend to reinvest these earnings indefinitely in our foreign subsidiaries. As a result, U.S. income and foreign withholding taxes associated with the repatriation of $18.3 million of earnings from our

[0001628280-21-017799:notes:350]
foreign subsidiaries, other than the Cayman Islands, Japan, and Hong Kong subsidiaries, have not been provided for. We estimate that an additional $1.0 million of foreign withholding taxes would have to be provided if these earnings were repatriated back to the U.S. and such withholding taxes may be available as foreign tax credit or deduction to reduce U.S. tax liability.

[0001628280-21-017799:notes:351]
The aggregate changes in the balance of our unrecognized tax benefits between June 29, 2019 and July 3, 2021 are as follows (in millions):

[0001628280-21-017799:notes:352]
| Balance at June 29, 2019 | $ | 58.0 |  |
| Decreases based on the tax positions related to the prior year | (8.2) |  |
| Decreases related to settlement with Tax Authorities | (2.0) |  |
| Additions based on tax positions related to current year | 7.7 |  |
| Balance at June 27, 2020 | $ | 55.5 |  |
| Increases based on tax positions related to prior year | 6.8 |  |
| Decreases based on tax positions related to prior year | (1.6) |  |
| Decreases related to Statute of Limitations | (5.1) |  |
| Additions based on tax positions related to current year | 6.5 |  |
| Balance at July 3, 2021 | $ | 62.1 |  |

[0001628280-21-017799:notes:353]
As of July 3, 2021, we had $23.0 million of unrecognized tax benefits, which, if recognized, would affect the effective tax rate. We are subject to examination of income tax returns by various domestic and foreign tax authorities. The timing of resolutions and closures of tax audits is highly unpredictable. Although it is possible that certain tax audits may be concluded within the next 12 months, we cannot reasonably estimate the impact to tax expense and net income from tax exams that could be resolved or closed within next 12 months. However, we believe that we have adequately provided under GAAP for potential audit outcomes. Subject to audit timing and uncertainty, we expect the amount of unrecognized tax benefit that would become recognized due to expiration of the statute of limitations and affect the effective tax rate to be $3.8 million over the next 12 months.

[0001628280-21-017799:notes:354]
The Company has obtained the tax holiday related to certain business activities but to date, has not met the requirements to obtain the benefits of the tax holiday. Accordingly, the earned income is subject to normal Thailand statutory tax rates.

[0001628280-21-017799:notes:355]
Our policy is to recognize accrued interest and penalties related to unrecognized tax benefits within the income tax provision. The amount of interest and penalties accrued as of July 3, 2021 and June 27, 2020 were $1.4 million and $1.4 million, respectively.

[0001628280-21-017799:notes:356]
The major tax jurisdictions where we file tax returns are the U.S. federal government, the state of California, Japan, the United Kingdom, Thailand, China and Canada. As of July 3, 2021, our fiscal 2011 to 2021 tax returns are open to potential examination in one or more jurisdictions. In addition, certain net operating loss and credit carryforwards may extend the ability of the tax authorities to examine our tax returns beyond the regular limits.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001628280-21-017799:notes:357]
Note 17. Equity

[0001628280-21-017799:notes:358]
Description of Lumentum Stock-Based Benefit Plans

[0001628280-21-017799:notes:359]
Equity Incentive Plan

[0001628280-21-017799:notes:360]
As of July 3, 2021, we had 2.0 million shares subject to restricted stock units, restricted stock awards, and performance stock units issued and outstanding under the 2015 Equity Incentive Plan (the “2015 Plan”).

[0001628280-21-017799:notes:361]
Restricted stock units, restricted stock awards, and performance stock units are performance-based, time-based or a combination of both and are expected to vest over one to four years. The fair value of these grants is based on the closing market.

[0001628280-21-017799:notes:362]
As of July 3, 2021, 2.3 million shares of common stock under the 2015 Plan were available for grant.

[0001628280-21-017799:notes:363]
Replacement Awards

[0001628280-21-017799:notes:364]
In connection with the acquisition of Oclaro, we issued equity awards to Oclaro employees (“replacement awards”) in exchange for their Oclaro equity awards. As of July 3, 2021, we had 0.1 million of unvested shares subject to restricted stock units under the replacement awards.

[0001628280-21-017799:notes:365]
Restricted Stock Units

[0001628280-21-017799:notes:366]
Restricted stock units (“RSUs”) under the 2015 Plan are grants of shares of our common stock, the vesting of which is based on the requisite service requirement. Generally, our RSUs are subject to forfeiture and are expected to vest over one to four years. For annual refresh grants, RSUs generally vest ratably on an annual, or combination of annual and quarterly, basis over three years.

[0001628280-21-017799:notes:367]
Restricted Stock Awards

[0001628280-21-017799:notes:368]
Restricted stock awards (“RSAs”) under the 2015 Plan are grants of shares of our common stock that are subject to various restrictions, including restrictions on transferability and forfeiture provisions. RSAs usually vest over one to four years, and the shares acquired may not be transferred by the holder until the vesting conditions (if any) are satisfied.

[0001628280-21-017799:notes:369]
Performance Stock Units

[0001628280-21-017799:notes:370]
Performance stock units (“PSUs”) under the 2015 Plan are grants of shares of our common stock that vest upon the achievement of certain performance and service conditions. We begin recognizing compensation expense when we conclude that it is probable that the performance conditions will be achieved. We reassess the probability of vesting at each reporting period and adjust our compensation cost based on this probability assessment. Our PSUs are subject to risk of forfeiture until performance and service conditions are satisfied and generally vest over three years.

[0001628280-21-017799:notes:371]
Employee Stock Purchase Plan

[0001628280-21-017799:notes:372]
Our 2015 Employee Stock Purchase Plan (the “2015 Purchase Plan”)  provides eligible employees with the opportunity to acquire an ownership interest in the Company through periodic payroll deductions and provides a 15% purchase price discount as well as a 6-month look-back period. The 2015 Purchase Plan is structured as a qualified employee stock purchase plan under Section 423 of the Internal Revenue Code of 1986, as amended. The 2015 Purchase Plan will terminate upon the date on which all shares available for issuance have been sold. Of the 3.0 million shares authorized under the 2015 Purchase Plan, 1.6 million shares remained available for issuance as of July 3, 2021.

[0001628280-21-017799:notes:373]
Stock-Based Compensation

[0001628280-21-017799:notes:374]
The impact on our results of operations of recording stock-based compensation by function during the periods presented was as follows (in millions):

[0001628280-21-017799:notes:375]
|  | Years Ended |
|  | July 3, 2021 |  | June 27, 2020 |  |  |  |  | June 29, 2019 |
| Cost of sales | $ | 19.2 |  |  | $ | 16.1 |  |  |  |  |  | $ | 15.1 |  |
| Research and development | 19.5 |  |  | 15.9 |  |  |  |  |  | 13.8 |  |
| Selling, general and administrative | 54.2 |  |  | 41.2 |  |  |  |  |  | 41.8 |  |
|  | $ | 92.9 |  |  | $ | 73.2 |  |  |  |  |  | $ | 70.7 |  |

[0001628280-21-017799:notes:376]
Total income tax benefit associated with stock-based compensation recognized in our Consolidated Statements of Operations during the years presented was as follows (in millions):

[0001628280-21-017799:notes:377]
|  | Years Ended |
|  | July 3, 2021 |  | June 27, 2020 |  |  |  |  | June 29, 2019 |
| Income tax benefit associated with stock-based compensation | $ | 14.6 |  |  | $ | 10.6 |  |  |  |  |  | $ | 8.9 |  |

[0001628280-21-017799:notes:378]
Approximately $4.6 million and $3.6 million of stock-based compensation was capitalized to inventory as of July 3, 2021 and June 27, 2020, respectively.

[0001628280-21-017799:notes:379]
As of July 3, 2021, $129.8 million of stock-based compensation cost related to awards granted to our employees remains to be amortized. That cost is expected to be recognized over an estimated amortization period of 1.7 years.

[0001628280-21-017799:notes:380]
In fiscal 2019, in connection with the acquisition of Oclaro, we accelerated certain equity awards for Oclaro employees. The total stock-based compensation expense associated with the acceleration of equity awards was $15.2 million, of which $10.0 million was settled in cash in our second quarter of fiscal 2019. Refer to “Note 4. Business Combinations.”

[0001628280-21-017799:notes:381]
Stock Award Activity

[0001628280-21-017799:notes:382]
As of July 3, 2021, there were less than 0.05 million stock options outstanding under the 2015 Plan, all of which were replacement awards issued in connection with the Oclaro acquisition.

[0001628280-21-017799:notes:383]
The following table summarizes our awards activity in fiscal 2021, 2020, and 2019 (in millions, except per share amounts):

[0001628280-21-017799:notes:384]
|  |  |  |  |  |  |  | Restricted Stock Units |  | Restricted Stock Awards |  | Performance Stock Units |
|  |  |  |  |  |  |  |  |  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |
| Balance as of June 30, 2018 |  |  |  |  |  |  |  |  | 1.7 |  |  | $ | 43.1 |  |  | 0.1 |  |  | $ | 32.5 |  |  | 0.1 |  |  | $ | 52.0 |  |
| Assumed in Oclaro merger |  |  |  |  |  |  |  |  | 1.0 |  |  | 41.8 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Granted |  |  |  |  |  |  |  |  | 1.0 |  |  | 60.3 |  |  | — |  |  | — |  |  | 0.2 |  |  | 55.9 |  |
| Vested/Exercised |  |  |  |  |  |  |  |  | (1.0) |  |  | 41.5 |  |  | (0.1) |  |  | 32.5 |  |  | (0.1) |  |  | 49.0 |  |
| Canceled |  |  |  |  |  |  |  |  | (0.5) |  |  | 50.2 |  |  | — |  |  | 32.8 |  |  | — |  |  | 53.8 |  |
| Balance as of June 29, 2019 |  |  |  |  |  |  |  |  | 2.2 |  |  | $ | 52.4 |  |  | — |  |  | $ | 32.5 |  |  | 0.2 |  |  | $ | 56.0 |  |
| Granted |  |  |  |  |  |  |  |  | 1.1 |  |  | 60.3 |  |  | — |  |  | — |  |  | 0.2 |  |  | 61.9 |  |
| Vested/Exercised |  |  |  |  |  |  |  |  | (1.2) |  |  | 52.1 |  |  | — |  |  | 32.4 |  |  | (0.1) |  |  | 54.7 |  |
| Canceled |  |  |  |  |  |  |  |  | (0.2) |  |  | 52.3 |  |  | — |  |  | — |  |  | — |  |  | 57.3 |  |
| Balance as of June 27, 2020 |  |  |  |  |  |  |  |  | 1.9 |  |  | $ | 56.6 |  |  | — |  |  | $ | — |  |  | 0.3 |  |  | $ | 60.6 |  |
| Granted |  |  |  |  |  |  |  |  | 1.2 |  |  | 86.6 |  |  | — |  |  | — |  |  | 0.2 |  |  | 86.7 |  |
| Vested/Exercised |  |  |  |  |  |  |  |  | (1.1) |  |  | 56.5 |  |  | — |  |  | — |  |  | (0.2) |  |  | 57.8 |  |
| Canceled |  |  |  |  |  |  |  |  | (0.2) |  |  | 67.1 |  |  | — |  |  | — |  |  | — |  |  | 70.0 |  |
| Balance as of July 3, 2021 |  |  |  |  |  |  |  |  | 1.8 |  |  | $ | 76.0 |  |  | — |  |  | $ | — |  |  | 0.3 |  |  | $ | 75.7 |  |

[0001628280-21-017799:notes:385]
A summary of awards available for grant for fiscal 2021, 2020 and 2019 is as follows (in millions):

[0001628280-21-017799:notes:386]
|  | Awards Available for Grant |
| Balance as of June 30, 2018 | 5.6 |  |
| Granted | (1.2) |  |
| Canceled | 0.3 |  |
| Balance as of June 29, 2019 | 4.7 |  |
| Granted | (1.3) |  |
| Canceled | 0.1 |  |
| Balance as of June 27, 2020 | 3.5 |  |
| Granted | (1.4) |  |
| Canceled | 0.2 |  |
| Balance as of July 3, 2021 | 2.3 |  |

[0001628280-21-017799:notes:387]
Employee Stock Purchase Plan Activity

[0001628280-21-017799:notes:388]
The 2015 Purchase Plan expense for fiscal 2021, 2020 and 2019 was $4.6 million, $3.5 million, and $3.6 million, respectively. The expense related to the 2015 Purchase Plan is recorded on a straight-line basis over the relevant subscription period. During fiscal 2021, 2020, and 2019, there were 0.2 million, 0.2 million, and 0.3 million shares issued to employees through the 2015 Purchase Plan.

[0001628280-21-017799:notes:389]
We estimate the fair value of the 2015 Purchase Plan shares on the date of grant using the Black-Scholes option-pricing model. The assumptions used to estimate the fair value of the 2015 Purchase Plan shares during the periods presented were as follows:

[0001628280-21-017799:notes:390]
|  | July 3, 2021 |  | June 27, 2020 |
| Expected term (years) | 0.5 |  | 0.5 |
| Expected volatility | 46.6 | % |  | 56.0 | % |
| Risk-free interest rate | 0.07 | % |  | 0.87 | % |
| Dividend yield | — | % |  | — | % |

[0001628280-21-017799:notes:391]
Repurchase and Retirement of Common Stock

[0001628280-21-017799:notes:392]
In December 2019, concurrently with the issuance of the 2026 Notes, we repurchased 2.9 million shares of our common stock in privately negotiated transactions at an average price of $69.68 per share for an aggregate purchase price of $200.0 million. These shares were retired immediately.

[0001628280-21-017799:notes:393]
On May 7, 2021, our board of directors approved the 2021 share buyback program, which authorizes us to use up to $700.0 million to purchase our own shares of common stock. The buyback program is authorized for 2 years but may be suspended or terminated by the board of directors at any time.  In the fiscal fourth quarter of 2021, we repurchased 3.1 million shares of our common stock at an average price of $77.84 per share for an aggregate purchase price of $241.0 million. These shares were retired immediately. We recorded the $241.0 million aggregate purchase price as a reduction of retained earnings.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001628280-21-017799:notes:394]
Note 18. Employee Retirement Plans

[0001628280-21-017799:notes:395]
Defined Contribution Plans

[0001628280-21-017799:notes:396]
In the United States, the Company sponsors the Lumentum 401(k) Retirement Plan (the “401(k) Plan”), a defined contribution plan under the Employee Retirement Income Security Act of 1974 (“ERISA”), which provides retirement benefits for its eligible employees through tax deferred salary deductions. The 401(k) Plan allows employees to contribute up to 50% of their annual compensation, with contributions limited to $19,500 (or $26,000 for employees over 50 years of age) in calendar year 2020 as set by the Internal Revenue Service. Employees are eligible for matching contributions after completing 180 days of service. The Company’s match is contributed on a per-pay-period basis and is based on employees’ before-tax contributions and compensation each pay period. All matching contributions are made in cash and vest immediately under the 401(k) Plan. In fiscal 2021, 2020, and 2019, our contribution expense to the 401(k) Plan was $3.5 million, $3.8 million, and $3.7 million, respectively.

[0001628280-21-017799:notes:397]
We also have defined contribution plans in most of the other countries in which we operate, either as required by statutory law or as provided by the Company’s supplemental offering. Our contribution expense to all defined contribution plans outside the United States were $8.3 million, $6.7 million, and $4.8 million for fiscal years 2021, 2020, and 2019, respectively.

[0001628280-21-017799:notes:398]
Defined Benefit Plans

[0001628280-21-017799:notes:399]
The Company sponsors defined benefit pension plans covering employees in Japan, Switzerland, and Thailand. Pension plan benefits are based primarily on participants’ compensation and years of service credited as specified under the terms of each country’s plan. Employees are entitled to a lump sum benefit upon retirement or upon certain instances of termination.  The funding policy is consistent with the local requirements of each country.

[0001628280-21-017799:notes:400]
We account for our defined benefit obligations in accordance with the authoritative guidance which requires us to record our obligation to the participants, as well as the corresponding net periodic cost. We determine our obligation to the participants and our net periodic cost principally using actuarial valuations provided by third-party actuaries. As of July 3, 2021, our projected benefit obligations, net, in Japan, Switzerland, and Thailand were $2.9 million, $4.8 million, and $3.1 million,

[0001628280-21-017799:notes:401]
respectively. They were recorded in our Consolidated Balance Sheets as other non-current liabilities and represent the total projected benefit obligation (“PBO”) less the fair value of plan assets.

[0001628280-21-017799:notes:402]
As of July 3, 2021, the defined benefit plan in Switzerland was partially funded, while the defined benefit plans in Japan and Thailand were unfunded.

[0001628280-21-017799:notes:403]
The change in the benefit obligations of pension plans in Japan, Switzerland, and Thailand, and the change in plan assets in Switzerland were as follows (in millions):

[0001628280-21-017799:notes:404]
|  | July 3, 2021 |  | June 27, 2020 |
| Change in projected benefit obligation: |  |  |  |
| Benefit obligation at beginning of year | $ | 20.9 |  |  | $ | 16.1 |  |
| Service cost | 2.0 |  |  | 3.5 |  |
| Interest cost | 0.1 |  |  | 0.2 |  |
| Plan participants’ contributions | 0.5 |  |  | 0.5 |  |
| Actuarial (gains) losses | (1.2) |  |  | 0.9 |  |
| Benefits paid | (1.7) |  |  | (0.7) |  |
| Foreign exchange impact | — |  |  | 0.4 |  |
| Benefit obligation at end of year | $ | 20.6 |  |  | $ | 20.9 |  |
| Change in plan assets: |  |  |  |
| Fair value of plan assets at beginning of year | $ | 9.1 |  |  | $ | 8.3 |  |
| Actual return on plan assets | 1.2 |  |  | — |  |
| Employer contribution | 0.5 |  |  | 0.6 |  |
| Plan participants’ contribution | 0.5 |  |  | 0.6 |  |
| Benefits paid | (1.5) |  |  | (0.7) |  |
| Foreign exchange impact | — |  |  | 0.3 |  |
| Fair value of plan assets at end of year | $ | 9.8 |  |  | $ | 9.1 |  |
| Funded status (1) | $ | (10.8) |  |  | $ | (11.8) |  |
| Changes in benefit obligations and plan assets recognized in other comprehensive income: |  |  |  |
| Prior service cost | $ | 0.1 |  |  | $ | — |  |
| Amortization of accumulated net actuarial gain (loss) | (0.4) |  |  | (0.3) |  |
| Net actuarial (gain) loss | (2.2) |  |  | 1.2 |  |
| Loss recognized due to settlement | (0.3) |  |  | — |  |
|  | $ | (2.8) |  |  | $ | 0.9 |  |
| Accumulated benefit obligation | $ | 16.5 |  |  | $ | 17.8 |  |

[0001628280-21-017799:notes:405]
(1) As of July 3, 2021 and June 27, 2020, $10.8 million and $11.8 million were recorded in other non-current liabilities on our Consolidated Balance Sheets, respectively, to account for the PBO. Refer to “Note 8. Balance Sheet Details” in the Notes to Consolidated Financial Statements.

[0001628280-21-017799:notes:406]
Net periodic pension costs in Japan, Switzerland, and Thailand include the following components for the periods presented (in millions):

[0001628280-21-017799:notes:407]
|  | Years Ended |  |  |  |
|  | July 3, 2021 |  | June 27, 2020 |  | June 29, 2019 |  |  |  |
| Service cost | $ | 2.0 |  |  | $ | 3.5 |  |  | $ | 1.2 |  |  |  |  |
| Interest cost | 0.1 |  |  | 0.2 |  |  | 0.1 |  |  |  |  |
| Amortization of prior service cost | (0.1) |  |  | — |  |  | — |  |  |  |  |
| Expected return on plan assets | (0.3) |  |  | (0.3) |  |  | (0.3) |  |  |  |  |
| Amortization of net loss | 0.3 |  |  | 0.3 |  |  | 0.1 |  |  |  |  |
| Settlement losses | 0.3 |  |  | — |  |  | — |  |  |  |  |
| Net periodic pension cost | $ | 2.3 |  |  | $ | 3.7 |  |  | $ | 1.1 |  |  |  |  |

[0001628280-21-017799:notes:408]
Assumptions

[0001628280-21-017799:notes:409]
Underlying both the calculation of the PBO and net periodic cost are actuarial valuations. These valuations use participant-specific information such as salary, age and assumptions about interest rates, compensation increases and other factors. At a minimum, we evaluate these assumptions annually and make changes as necessary.

[0001628280-21-017799:notes:410]
The discount rate reflects the estimated rate at which the pension benefits could be effectively settled. In developing the discount rate, we consider the yield available on an appropriate AA or AAA corporate bond index, adjusted to reflect the term of the plan’s liabilities.

[0001628280-21-017799:notes:411]
The expected return on assets was estimated by using the weighted average of the real expected long-term return (net of inflation) on the relevant classes of assets based on the target asset mix and adding the chosen inflation assumption.

[0001628280-21-017799:notes:412]
The following table summarizes the weighted-average assumptions used to determine net periodic cost and benefit obligation for our defined benefit plans in Japan, Switzerland, and Thailand:

[0001628280-21-017799:notes:413]
|  | Years Ended |
|  | July 3, 2021 |  | June 27, 2020 |
| Assumptions used to determine net periodic cost: |  |  |  |
| Discount rate | 0.6 | % |  | 0.8 | % |
| Expected long-term return on plan assets | 2.7 | % |  | 3.2 | % |
| Salary increase rate | 3.4 | % |  | 4.1 | % |
| Assumptions used to determine benefit obligation at end of year: |  |  |  |
| Discount rate | 0.7 | % |  | 0.4 | % |
| Salary increase rate | 2.9 | % |  | 2.7 | % |

[0001628280-21-017799:notes:414]
Fair Value Measurement of Plan Assets

[0001628280-21-017799:notes:415]
The following table sets forth the plan assets of our defined benefit plan in Switzerland at fair value and the percentage of assets allocations as of July 3, 2021 and June 27, 2020 (in millions, except percentage data):

[0001628280-21-017799:notes:416]
|  |  |  |  |  |  | Fair Value Measurement as of July 3, 2021 |
|  | Target Allocation | Total |  | Percentage of Plan Asset |  | Quoted Prices in Active Markets for Identical Assets(Level 1) |  | Significant Other Observable Inputs (Level 2) |
| Assets: |  |  |  |  |  |  |  |  |  |
| Global equity | 31 | % |  | $ | 3.0 |  |  | 30 | % |  | $ | — |  |  | $ | 3.0 |  |
| Fixed income | 31 | % |  | 3.0 |  |  | 29 | % |  | — |  |  | 3.0 |  |
| Alternative investment | 15 | % |  | 1.5 |  |  | 18 | % |  | — |  |  | 1.5 |  |
| Cash | 1 | % |  | 0.1 |  |  | 1 | % |  | 0.1 |  |  | — |  |
| Other assets | 22 | % |  | 2.2 |  |  | 22 | % |  | — |  |  | 2.2 |  |
| Total Assets | 100 | % |  | $ | 9.8 |  |  | 100 | % |  | $ | 0.1 |  |  | $ | 9.7 |  |

[0001628280-21-017799:notes:417]
|  |  |  |  |  |  | Fair Value Measurement as of June 27, 2020 |
|  | Target Allocation | Total |  | Percentage of Plan Asset |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  | Significant Other Observable Inputs (Level 2) |
| Assets: |  |  |  |  |  |  |  |  |  |
| Global equity | 29 | % |  | $ | 2.6 |  |  | 28 | % |  | $ | — |  |  | $ | 2.6 |  |
| Fixed income | 33 | % |  | 3.0 |  |  | 30 | % |  | — |  |  | 3.0 |  |
| Alternative investment | 16 | % |  | 1.5 |  |  | 21 | % |  | — |  |  | 1.5 |  |
| Cash | 2 | % |  | 0.2 |  |  | 1 | % |  | 0.2 |  |  | — |  |
| Other assets | 20 | % |  | 1.8 |  |  | 20 | % |  | — |  |  | 1.8 |  |
| Total Assets | 100 | % |  | $ | 9.1 |  |  | 100 | % |  | $ | 0.2 |  |  | $ | 8.9 |  |

[0001628280-21-017799:notes:418]
Our pension assets consist of multiple institutional funds (“pension funds”) of which the fair values are based on the quoted prices of the underlying funds. Pension funds are classified as Level 2 assets since such funds are not directly traded in active markets. Global equity consists of several funds that invest primarily in Swiss and foreign equities; fixed income consists of several funds that invest primarily in investment grade domestic and overseas bonds; other assets consist of several funds that primarily invest in hedge fund, private equity, global real estate and infrastructure funds.

[0001628280-21-017799:notes:419]
Future Benefit Payments

[0001628280-21-017799:notes:420]
We estimate our expected benefit payments to participants in the defined benefit pension plans based on the same assumptions used to measure our PBO at year-end which includes benefits attributable to estimated future compensation increases.

[0001628280-21-017799:notes:421]
The following benefit payments are estimated to be paid from our defined benefit pension plans (in millions):

[0001628280-21-017799:notes:422]
| Fiscal Years |  | Total |
| 2022 |  | $ | 1.0 |  |
| 2023 |  | 0.8 |  |
| 2024 |  | 0.7 |  |
| 2025 |  | 1.0 |  |
| 2026 |  | 0.8 |  |
| Next five years |  | 6.0 |  |

[0001628280-21-017799:notes:423]
We expect to contribute $1.0 million to our defined benefit pension plans in fiscal 2022.


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0001628280-21-017799:notes:424]
Note 19. Commitments and Contingencies

[0001628280-21-017799:notes:425]
Purchase Obligations

[0001628280-21-017799:notes:426]
Purchase obligations of $224.5 million as of July 3, 2021, represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements.

[0001628280-21-017799:notes:427]
Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule and adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

[0001628280-21-017799:notes:428]
We depend on a limited number of contract manufacturers, subcontractors and suppliers for raw materials, packages and standard components. We generally purchase these single or limited source products through standard purchase orders or one-year supply agreements and have no significant long-term guaranteed supply agreements with such vendors. While we seek to maintain a sufficient safety stock of such products and maintain on-going communications with our suppliers to guard against interruptions or cessation of supply, our business and results of operations could be adversely affected by a stoppage or delay of supply, substitution of more expensive or less reliable products, receipt of defective parts or contaminated materials, increases in the price of such supplies, or our inability to obtain reduced pricing from our suppliers in response to competitive pressures.

[0001628280-21-017799:notes:429]
Product Warranties

[0001628280-21-017799:notes:430]
We provide reserves for the estimated costs of product warranties at the time revenue is recognized. We typically offer a twelve month warranty for most of our products. However, in some instances depending upon the product, product components or application of our products by the end customer, our warranties can vary and generally range from six months to five years. We estimate the costs of our warranty obligations on an annualized basis based on our historical experience of known product failure rates, use of materials to repair or replace defective products and service delivery costs incurred in correcting product failures. In addition, from time to time, specific warranty accruals may be made if unforeseen technical problems arise with specific products. We assess the adequacy of our recorded warranty liabilities and adjust the amounts as necessary.

[0001628280-21-017799:notes:431]
The following table presents the changes in our warranty reserve during the periods presented (in millions):

[0001628280-21-017799:notes:432]
|  | Years Ended |
|  | July 3, 2021 |  | June 27, 2020 |  |  |  |  |
| Balance as of beginning of period | $ | 5.0 |  |  | $ | 7.5 |  |  |  |  |  |
| Provision for warranty | 7.1 |  |  | 2.9 |  |  |  |  |  |
| Utilization of reserve | (7.1) |  |  | (5.4) |  |  |  |  |  |
| Balance as of end of period | $ | 5.0 |  |  | $ | 5.0 |  |  |  |  |  |

[0001628280-21-017799:notes:433]
Environmental Liabilities

[0001628280-21-017799:notes:434]
Our research and development (“R&D”), manufacturing and distribution operations involve the use of hazardous substances and are regulated under international, federal, state and local laws governing health and safety and the environment. We apply strict standards for protection of the environment and occupational health and safety to sites inside and outside the United States, even if not subject to regulations imposed by foreign governments. We believe that our properties and operations at our facilities comply in all material respects with applicable environmental laws and occupational health and safety laws. However, the risk of environmental liabilities cannot be completely eliminated and there can be no assurance that the application of environmental and health and safety laws will not require us to incur significant expenditures. We are also regulated under a number of international, federal, state and local laws regarding recycling, product packaging and product content requirements. The environmental, product content/disposal and recycling laws are gradually becoming more stringent and may cause us to incur significant expenditures in the future.

[0001628280-21-017799:notes:435]
Legal Proceedings

[0001628280-21-017799:notes:436]
We are subject to a variety of claims and suits that arise from time to time in the ordinary course of our business. While management currently believes that resolving claims against us, individually or in the aggregate, will not have a material adverse impact on our financial position, results of operations or statements of cash flows, these matters are subject to inherent uncertainties and management’s view of these matters may change in the future. We accrue for loss contingencies when it is both probable that we will incur the loss and when we can reasonably estimate the amount of the loss or range of loss.

[0001628280-21-017799:notes:437]
Merger Litigation

[0001628280-21-017799:notes:438]
In connection with our acquisition of Oclaro, seven lawsuits were filed by purported stockholders of Oclaro challenging the proposed merger (the “Merger”). Two of the seven suits were putative class actions filed against Oclaro, its directors, Lumentum, Prota Merger Sub, Inc. and Prota Merger, LLC: Nicholas Neinast v. Oclaro, Inc., et al., No. 3:18-cv-03112-VC, in the United States District Court for the Northern District of California (filed May 24, 2018) (the “Neinast Lawsuit”); and Adam Franchi v. Oclaro, Inc., et al., No. 1:18-cv-00817-GMS, in the United States District Court for the District of Delaware (filed June 9, 2018) (the “Franchi Lawsuit”). Both the Neinstat Lawsuit and the Franchi Lawsuit were voluntarily dismissed with prejudice.

[0001628280-21-017799:notes:439]
The other five suits, styled as Gerald F. Wordehoff v. Oclaro, Inc., et al., No. 5:18-cv-03148-NC (the “Wordehoff Lawsuit”), Walter Ryan v. Oclaro, Inc., et al., No. 3:18-cv-03174-VC (the “Ryan Lawsuit”), Jayme Walker v. Oclaro, Inc., et al., No. 5:18-cv-03203-EJD (the “Walker Lawsuit”), Kevin Garcia v. Oclaro, Inc., et al., No. 5:18-cv-03262-VKD (the “Garcia Lawsuit”), and SaiSravan B. Karri v. Oclaro, Inc., et al., No. 3:18-cv-03435-JD (the “Karri Lawsuit” and, together with the other six lawsuits, the “Lawsuits”), were filed in the United States District Court for the Northern District of California on May 25, 2018, May 29, 2018, May 30, 2018, May 31, 2018, and June 9, 2018, respectively. These five Lawsuits named Oclaro and its directors as defendants only and did not name Lumentum. The Wordehoff, Ryan, Walker, and Garcia Lawsuits have been voluntarily dismissed, and the Wordehoff, Ryan, and Walker dismissals were with prejudice. The Karri Lawsuit has not yet been dismissed. The Ryan Lawsuit was, and the Karri Lawsuit is, a putative class action.

[0001628280-21-017799:notes:440]
The Lawsuits generally alleged, among other things, that Oclaro and its directors violated Section 14(a) of the Securities Exchange Act of 1934, as amended (the “Exchange Act”), and Rule 14a-9 promulgated thereunder by disseminating an incomplete and misleading Form S-4, including proxy statement/prospectus. The Lawsuits further alleged that Oclaro’s directors violated Section 20(a) of the Exchange Act by failing to exercise proper control over the person(s) who violated Section 14(a) of the Exchange Act.

[0001628280-21-017799:notes:441]
The remaining Lawsuit (the Karri Lawsuit) currently purports to seek, among other things, damages to be awarded to the plaintiff and any class, if a class is certified, and litigation costs, including attorneys’ fees.  A lead plaintiff and counsel has been selected, and an amended complaint was filed on April 15, 2019, which also names Lumentum as a defendant. A motion to dismiss the amended complaint was granted in part and denied in part by the court on October 8, 2020. On December 1, 2020, defendants answered the amended complaint.  On December 23, 2020, defendants filed a motion for leave to file a motion for reconsideration of the Court’s October 8 order on the motion to dismiss, which was denied on January 29, 2021. The Karri Lawsuit remains pending with the parties currently in discovery. Defendants intend to defend the Karri Lawsuit vigorously.

[0001628280-21-017799:notes:442]
Indemnifications

[0001628280-21-017799:notes:443]
In the normal course of business, we enter into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown because claims may be made against us in the future and we may record charges in the future as a result of these indemnification obligations. As of July 3, 2021, we did not have any material indemnification claims that were probable or reasonably possible.

[0001628280-21-017799:notes:444]
Audit Proceedings

[0001628280-21-017799:notes:445]
We are under audit by various domestic and foreign tax authorities with regards to income tax and indirect tax matters. In some, although not all cases, we have reserved for potential adjustments to our provision for income taxes and accrual of indirect taxes that may result from examinations by these tax authorities or final outcomes in judicial proceedings, and we believe that the final outcome of these examinations, agreements or judicial proceedings will not have a material effect on our results of operations. If events occur which indicate payment of these amounts is unnecessary, the reversal of the liabilities would result in the recognition of benefits in the period we determine the liabilities are no longer necessary. If our estimates of the federal, state, and foreign income tax liabilities and indirect tax liabilities are less than the ultimate assessment, it could result in a further charge to expense.
In connection with our acquisition of Oclaro, in fiscal 2019, we recorded $1.1 million in Malaysia Goods and Services Tax (“GST”) refund claims within prepaid expenses and other current assets in our Consolidated Balance Sheet. The refund claim represented an initial claim of $2.5 million of GST, net of reserves, that was previously denied by the Malaysian tax authorities in 2016. During the year ended June 27, 2020, we were able to favorably resolve this audit and received refunds for all of our outstanding GST claims.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001628280-21-017799:notes:446]
Note 20. Operating Segments and Geographic Information

[0001628280-21-017799:notes:447]
Our chief executive officer is our Chief Operating Decision Maker (“CODM”). The CODM allocates resources to the segments based on their business prospects, competitive factors, net revenue and gross margin. We do not track all of our property, plant and equipment by operating segments. The geographic identification of these assets is set forth below.

[0001628280-21-017799:notes:448]
We are an industry leading provider of optical and photonic products defined by revenue and market share addressing a range of end-market applications including optical communications and commercial lasers. We have two operating segments, Optical Communications, which we refer to as OpComms, and Commercial Lasers, which we refer to as Lasers. Our OpComms products address the following markets: telecommunications and data communications (“Telecom and Datacom”), and consumer and industrial (“Consumer and Industrial”), and include product lines from the acquisition of Oclaro. The two operating segments were primarily determined based on how the CODM views and evaluates our operations. Operating results are regularly reviewed by the CODM to make decisions about resources to be allocated to the segments and to assess their performance. Other factors, including market separation and customer specific applications, go-to-market channels, products and manufacturing, are considered in determining the formation of these operating segments.

[0001628280-21-017799:notes:449]
OpComms

[0001628280-21-017799:notes:450]
Our OpComms products include a wide range of components, modules and subsystems to support customers including carrier networks for access (local), metro (intracity), long-haul (city-to-city and worldwide) and submarine (undersea) applications. Additionally, our products address enterprise, cloud, and data center applications, including storage-access networks (“SANs”), local-area networks (“LANs”) and wide-area networks (“WANs”). These products enable the transmission and transport of video, audio and data over high-capacity fiber-optic cables. We maintain leading positions in these fast growing OpComms markets through our extensive product portfolio, including reconfigurable optical add/drop multiplexers (“ROADMs”), coherent dense wavelength division multiplexing (“DWDM”) pluggable transceivers, and tunable small form-factor pluggable transceivers. We also sell laser chips for use in manufacturing of high-speed Datacom transceivers.

[0001628280-21-017799:notes:451]
In the Consumer and Industrial market, our OpComms diode laser products include vertical cavity surface emitting lasers (“VCSELs”) and edge emitting lasers. In the Consumer end-market, our laser light sources are integrated into 3D sensing cameras which are used in applications in mobile devices, gaming, payment kiosks, computers, and other consumer electronics devices. Applications include biometric identification, computational photography, virtual and augmented reality, and natural user interfaces. Emerging applications for our lasers include automotive safety systems, LiDAR for advanced driver assistance systems in automobiles and autonomous vehicles, self-navigating robotics and drones in industrial applications, and 3D capture of objects coupled with 3D imaging or printing. In the industrial end-market, our diode lasers are used primarily as pump sources for pulsed and kilowatt class fiber lasers.

[0001628280-21-017799:notes:452]
Lasers

[0001628280-21-017799:notes:453]
Our Lasers products serve our customers in markets and applications such as sheet metal processing, general manufacturing, biotechnology, graphics and imaging, remote sensing, and precision machining such as drilling in printed circuit boards, wafer singulation, glass cutting and solar cell scribing.

[0001628280-21-017799:notes:454]
Our Lasers products are used in a variety of OEM applications including diode-pumped solid-state, fiber, diode, direct-diode and gas lasers such as argon-ion and helium-neon lasers. Fiber lasers provide kW-class output powers combined with excellent beam quality and are used in sheet metal processing and metal welding applications. Diode-pumped solid-state lasers provide excellent beam quality, low noise and exceptional reliability and are used in biotechnology, graphics and imaging, remote sensing, materials processing and precision machining applications. Diode and direct-diode lasers address a wide variety of applications, including laser pumping, thermal exposure, illumination, ophthalmology, image recording, printing, plastic welding and selective soldering. Gas lasers such as argon-ion and helium-neon lasers provide a stable, low-cost and reliable solution over a wide range of operating conditions, making them well-suited for complex, high-resolution OEM applications such as flow cytometry, DNA sequencing, graphics and imaging and semiconductor inspection.

[0001628280-21-017799:notes:455]
We also provide high-powered and ultrafast lasers for the industrial and scientific markets. Manufacturers use high-power, ultrafast lasers to create micro parts for consumer electronics and to process semiconductor, LED, and other types of chips. Use of ultrafast lasers for micromachining applications is being driven primarily by the increasing use of consumer electronics and connected devices globally.

[0001628280-21-017799:notes:456]
We do not allocate research and development, sales and marketing, or general and administrative expenses to our segments because management does not include the information in its measurement of the performance of the operating segments. In addition, we do not allocate amortization and impairment of acquisition-related intangible assets, stock-based compensation and certain other charges impacting the gross margin of each segment because management does not include this information in its measurement of the performance of the operating segments.

[0001628280-21-017799:notes:457]
Information on reportable segments utilized by our CODM is as follows (in millions):

[0001628280-21-017799:notes:458]
|  |  |  | Years Ended |
|  |  |  |  |  | July 3, 2021 |  | June 27, 2020 |  | June 29, 2019 |
| Net revenue: |  |  |  |  |  |  |  |  |  |
| OpComms |  |  |  |  | $ | 1,620.7 |  |  | $ | 1,515.1 |  |  | $ | 1,370.2 |  |
| Lasers |  |  |  |  | 122.1 |  |  | 163.5 |  |  | 195.1 |  |
| Net revenue |  |  |  |  | $ | 1,742.8 |  |  | $ | 1,678.6 |  |  | $ | 1,565.3 |  |
| Gross profit: |  |  |  |  |  |  |  |  |  |
| OpComms |  |  |  |  | $ | 830.2 |  |  | $ | 704.0 |  |  | $ | 534.1 |  |
| Lasers |  |  |  |  | 57.3 |  |  | 76.2 |  |  | 84.4 |  |
| Total segment gross profit |  |  |  |  | 887.5 |  |  | 780.2 |  |  | 618.5 |  |
| Unallocated corporate items: |  |  |  |  |  |  |  |  |  |
| Stock-based compensation |  |  |  |  | (19.2) |  |  | (16.1) |  |  | (15.1) |  |
| Amortization of acquired intangibles |  |  |  |  | (61.7) |  |  | (53.8) |  |  | (46.6) |  |
| Amortization of inventory fair value adjustments |  |  |  |  | — |  |  | (5.8) |  |  | (54.6) |  |
| Inventory and fixed asset write down due to product line exits (1) |  |  |  |  | (0.4) |  |  | (7.0) |  |  | (20.8) |  |
| Integration related costs |  |  |  |  | — |  |  | (4.9) |  |  | (6.6) |  |
| Other charges (2) |  |  |  |  | (23.1) |  |  | (42.4) |  |  | (48.9) |  |
| Gross profit |  |  |  |  | $ | 783.1 |  |  | $ | 650.2 |  |  | $ | 425.9 |  |

[0001628280-21-017799:notes:459]
(1) In fiscal 2021, 2020 and 2019, we recorded inventory and fixed assets write down charges of $0.4 million,  $7.0 million and $20.8 million related to the decision to exit the Datacom module and Lithium Niobate product lines.

[0001628280-21-017799:notes:460]
(2) “Other charges” of unallocated corporate items for the year ended July 3, 2021 and June 27, 2020, primarily include costs of transferring product lines to new production facilities, including Thailand of $6.9 million and $11.5 million, respectively. We also incurred excess and obsolete inventory charges of $7.7 million and $12.8 million driven by the decline in demand from Huawei during the year ended July 3, 2021 and June 27, 2020, respectively. In addition, for

[0001628280-21-017799:notes:461]
the year ended July 3, 2021 and June 27, 2020, we incurred $5.0 million and $6.2 million impairment charges associated with excess capacity related to our Fiber laser business, respectively. Other charges for the year ended June 29, 2019, primarily include costs of transferring product lines to Thailand of $45.8 million.

[0001628280-21-017799:notes:462]
We disaggregate revenue by product and by geography. We do not present other levels of disaggregation, such as by type of products, customer, markets, contracts, duration of contracts, timing of transfer of control and sales channels, as this information is not used by our CODM to manage the business.

[0001628280-21-017799:notes:463]
The table below discloses our total net revenue attributable to each of our two reportable segments. In addition, the table sets forth the percentage of our total net revenue attributable to our product offerings which serve Telecom and Datacom, and Consumer and Industrial markets which accounted for 10% or more of our total net revenue during the periods presented (in millions, except percentage data):

[0001628280-21-017799:notes:464]
|  |  |  | Years Ended |
|  |  |  | July 3, 2021 |  | June 27, 2020 |  | June 29, 2019 |
| OpComms: |  |  |  |  |  |  |  |  |  |  |
| Telecom and Datacom |  |  | $ | 1,059.7 |  | 60.8 | % |  | $ | 1,021.8 |  | 60.9 | % |  | $ | 952.9 |  | 60.8 | % |
| Consumer and Industrial |  |  | 561.0 |  | 32.2 | % |  | 493.3 |  | 29.4 | % |  | 417.3 |  | 26.7 | % |
| Total OpComms |  |  | $ | 1,620.7 |  | 93.0 | % |  | $ | 1,515.1 |  | 90.3 | % |  | $ | 1,370.2 |  | 87.5 | % |
| Lasers |  |  | 122.1 |  | 7.0 | % |  | 163.5 |  | 9.7 | % |  | 195.1 |  | 12.5 | % |
| Net Revenue |  |  | $ | 1,742.8 |  |  |  | $ | 1,678.6 |  |  |  | $ | 1,565.3 |  |  |

[0001628280-21-017799:notes:465]
We operate in three geographic regions: Americas, Asia-Pacific, and EMEA (Europe, Middle East, and Africa). Net revenue is assigned to the geographic region and country where our product is initially shipped. For example, certain customers may request shipment of our product to a contract manufacturer in one country, which may differ from the location of their end customers. The following table presents net revenue by the three geographic regions we operate in and net revenue from countries that represented 10% or more of our total net revenue (in millions, except percentage data):

[0001628280-21-017799:notes:466]
|  |  |  | Years Ended |  |
|  |  |  |  |  | July 3, 2021 |  | June 27, 2020 |  | June 29, 2019 |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States |  |  |  |  |  |  |  |  | $ | 133.4 |  |  | 7.7 | % |  | $ | 149.8 |  |  | 8.9 | % |  | $ | 100.9 |  |  | 6.4 | % |  |
| Mexico |  |  |  |  |  |  |  |  | 134.8 |  |  | 7.7 |  |  | 122.8 |  |  | 7.3 |  |  | 214.9 |  |  | 13.7 |  |  |
| Other Americas |  |  |  |  |  |  |  |  | 12.1 |  |  | 0.7 |  |  | 5.5 |  |  | 0.3 |  |  | 4.3 |  |  | 0.3 |  |  |
| Total Americas |  |  |  |  |  |  |  |  | $ | 280.3 |  |  | 16.1 | % |  | $ | 278.1 |  |  | 16.5 | % |  | $ | 320.1 |  |  | 20.4 | % |  |
| Asia-Pacific: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Hong Kong |  |  |  |  |  |  |  |  | $ | 546.3 |  |  | 31.3 | % |  | $ | 532.0 |  |  | 31.8 | % |  | $ | 387.9 |  |  | 24.8 | % |  |
| Philippines |  |  |  |  |  |  |  |  | 148.6 |  |  | 8.5 |  |  | 56.3 |  |  | 3.4 |  |  | 52.2 |  |  | 3.3 |  |  |
| South Korea |  |  |  |  |  |  |  |  | 240.0 |  |  | 13.8 |  |  | 260.9 |  |  | 15.5 |  |  | 162.4 |  |  | 10.4 |  |  |
| Japan |  |  |  |  |  |  |  |  | 114.7 |  |  | 6.6 |  |  | 137.9 |  |  | 8.2 |  |  | 176.0 |  |  | 11.2 |  |  |
| Other Asia-Pacific |  |  |  |  |  |  |  |  | 272.7 |  |  | 15.7 |  |  | 289.7 |  |  | 17.2 |  |  | 303.9 |  |  | 19.4 |  |  |
| Total Asia-Pacific |  |  |  |  |  |  |  |  | $ | 1,322.3 |  |  | 75.9 | % |  | $ | 1,276.8 |  |  | 76.1 | % |  | $ | 1,082.4 |  |  | 69.1 | % |  |
| EMEA |  |  |  |  |  |  |  |  | $ | 140.2 |  |  | 8.0 | % |  | $ | 123.7 |  |  | 7.4 | % |  | $ | 162.8 |  |  | 10.5 | % |  |
| Total net revenue |  |  |  |  |  |  |  |  | $ | 1,742.8 |  |  |  |  | $ | 1,678.6 |  |  |  |  | $ | 1,565.3 |  |  |  |  |

[0001628280-21-017799:notes:467]
During fiscal 2021 compared to fiscal 2020, our net revenue from the Philippines grew due to an introduction of a new product to one of our large customers.

[0001628280-21-017799:notes:468]
During the years ended July 3, 2021, June 27, 2020, and June 29, 2019, net revenue generated from a single customer which represented 10% or greater of total net revenue is summarized as follows:

[0001628280-21-017799:notes:469]
|  | Years Ended |
|  | July 3, 2021 |  | June 27, 2020 |  | June 29, 2019 |
| Customer A | 30.2 | % |  | 26.0 | % |  | 21.0 | % |
| Customer B | 10.8 | % |  | 13.2 | % |  | 15.2 | % |
| Customer C | 10.1 |  |  | * |  | 13.7 | % |
| *Represents less than 10% of total net revenue. |  |  |  |  |  |

[0001628280-21-017799:notes:470]
Our accounts receivable was concentrated with two customers as of July 3, 2021, which individually represented 17% and 14% of gross accounts receivable, respectively, and collectively accounted for 31% of the total gross accounts receivable, compared with one customer as of June 27, 2020, who represented 14% of gross accounts receivable, respectively.

[0001628280-21-017799:notes:471]
Long-lived assets, namely property, plant and equipment, net, were identified based on the physical location of the assets in the corresponding geographic areas as of the periods indicated (in millions):

[0001628280-21-017799:notes:472]
|  | July 3, 2021 |  | June 27, 2020 |
| Thailand | $ | 103.9 |  |  | $ | 122.6 |  |
| United States | 116.7 |  |  | 139.1 |  |
| China | 41.3 |  |  | 43.2 |  |
| Japan | 36.4 |  |  | 32.3 |  |
| Other countries | 62.8 |  |  | 55.8 |  |
| Total long-lived assets | $ | 361.1 |  |  | $ | 393.0 |  |

[0001628280-21-017799:notes:473]
We purchase a substantial portion of our inventory from contract manufacturers and vendors located primarily in Taiwan, Thailand, and Malaysia. During fiscal 2021, 2020, and 2019, our total net inventory purchases from contract manufacturers represented approximately 40%, 39%, and 46% of our total cost of sales, respectively. During fiscal 2021, 2020, and 2019, our net inventory purchases, which represented 10% or greater of total net purchases, were concentrated with two, two and three contract manufacturers, respectively.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001628280-21-017799:notes:474]
Note 21. Quarterly Financial Information (Unaudited)

[0001628280-21-017799:notes:475]
The following table presents our quarterly Consolidated Statements of Operations for fiscal 2021 and 2020 (in millions, except per share data):

[0001628280-21-017799:notes:476]
|  | July 3, 2021 |  | April 3, 2021 (1) |  | December 26, 2020 |  | September 26, 2020 |  | June 27, 2020 |  | March 28, 2020 |  | December 28, 2019 |  | September 28, 2019 |  |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue | $ | 392.1 |  |  | $ | 419.5 |  |  | $ | 478.8 |  |  | $ | 452.4 |  |  | $ | 368.1 |  |  | $ | 402.8 |  |  | $ | 457.8 |  |  | $ | 449.9 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of sales | 213.4 |  |  | 218.7 |  |  | 234.2 |  |  | 231.7 |  |  | 217.4 |  |  | 231.2 |  |  | 256.3 |  |  | 269.7 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of acquired developed intangibles | 15.9 |  |  | 15.8 |  |  | 15.0 |  |  | 15.0 |  |  | 15.0 |  |  | 13.9 |  |  | 12.4 |  |  | 12.5 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Gross profit | 162.8 |  |  | 185.0 |  |  | 229.6 |  |  | 205.7 |  |  | 135.7 |  |  | 157.7 |  |  | 189.1 |  |  | 167.7 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 54.1 |  |  | 57.2 |  |  | 52.8 |  |  | 50.4 |  |  | 49.0 |  |  | 48.7 |  |  | 51.0 |  |  | 49.9 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative | 58.3 |  |  | 65.5 |  |  | 61.3 |  |  | 56.3 |  |  | 54.8 |  |  | 61.3 |  |  | 62.4 |  |  | 56.7 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring and related charges | 4.6 |  |  | 2.9 |  |  | 0.2 |  |  | — |  |  | 3.1 |  |  | 2.7 |  |  | 0.9 |  |  | 1.3 |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0001628280-21-017799:notes:477]
| Merger termination fee and related costs, net | — |  |  | (207.5) |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Impairment charges | — |  |  | — |  |  | — |  |  | — |  |  | 1.8 |  |  | 2.5 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total operating expenses | 117.0 |  |  | (81.9) |  |  | 114.3 |  |  | 106.7 |  |  | 108.7 |  |  | 115.2 |  |  | 114.3 |  |  | 107.9 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income from operations | 45.8 |  |  | 266.9 |  |  | 115.3 |  |  | 99.0 |  |  | 27.0 |  |  | 42.5 |  |  | 74.8 |  |  | 59.8 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense | (18.0) |  |  | (16.4) |  |  | (16.3) |  |  | (16.0) |  |  | (15.9) |  |  | (15.6) |  |  | (18.3) |  |  | (11.4) |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other income (expense), net | 0.7 |  |  | 2.4 |  |  | (0.9) |  |  | 0.6 |  |  | 3.5 |  |  | 21.7 |  |  | 1.2 |  |  | 5.0 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income before income taxes | 28.5 |  |  | 252.9 |  |  | 98.1 |  |  | 83.6 |  |  | 14.6 |  |  | 48.6 |  |  | 57.7 |  |  | 53.4 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Provision for income taxes | 7.0 |  |  | 27.4 |  |  | 14.9 |  |  | 16.5 |  |  | 19.2 |  |  | 5.2 |  |  | 8.6 |  |  | 5.8 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) | $ | 21.5 |  |  | $ | 225.5 |  |  | $ | 83.2 |  |  | $ | 67.1 |  |  | $ | (4.6) |  |  | $ | 43.4 |  |  | $ | 49.1 |  |  | $ | 47.6 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) attributable to common stockholders - Basic and Diluted | $ | 21.5 |  |  | $ | 225.5 |  |  | $ | 83.2 |  |  | $ | 67.1 |  |  | $ | (4.6) |  |  | $ | 43.4 |  |  | $ | 49.1 |  |  | $ | 47.6 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) per share attributable to common stockholders: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic | $ | 0.29 |  |  | $ | 2.97 |  |  | $ | 1.10 |  |  | $ | 0.89 |  |  | $ | (0.06) |  |  | $ | 0.58 |  |  | $ | 0.64 |  |  | $ | 0.62 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Diluted | $ | 0.28 |  |  | $ | 2.85 |  |  | $ | 1.06 |  |  | $ | 0.86 |  |  | $ | (0.06) |  |  | $ | 0.56 |  |  | $ | 0.63 |  |  | $ | 0.61 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Shares used to compute net income (loss) per share attributable to common stockholders: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic | 74.8 |  |  | 75.8 |  |  | 75.6 |  |  | 75.3 |  |  | 75.0 |  |  | 74.8 |  |  | 76.8 |  |  | 76.9 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Diluted | 77.5 |  |  | 79.2 |  |  | 78.4 |  |  | 78.2 |  |  | 75.0 |  |  | 77.5 |  |  | 78.0 |  |  | 77.6 |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0001628280-21-017799:notes:478]
(1)  In March 2021, Coherent terminated the merger agreement and paid Lumentum a termination fee of $217.6 million in accordance with the merger agreement. This gain was offset by $10.1 million of acquisition related expenses and the net amount is presented as “merger termination fee and related costs, net” in our Consolidated Statement of Operations for the three and twelve months ended July 3, 2021.


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001628280-21-017799:notes:479]
SCHEDULE II - VALUATION AND QUALIFYING ACCOUNTS

[0001628280-21-017799:notes:480]
|  | (in millions) |
|  | Balance atBeginningof Period |  | Assumed in Oclaro Acquisition |  | Increase (decrease) in Consolidated Statements of Operations |  | WriteOffs and Other Adjustments |  |  |  | Balanceat End ofPeriod |
| Allowance for credit losses: |  |  |  |  |  |  |  |  |  |  |  |
| Fiscal year ended July 3, 2021 | $ | 1.8 |  |  | $ | — |  |  | $ | 0.2 |  |  | $ | (1.6) |  |  |  |  | $ | 0.4 |  |
| Fiscal year ended June 27, 2020 | $ | 4.5 |  |  | $ | — |  |  | $ | 0.1 |  |  | $ | (2.8) |  |  |  |  | $ | 1.8 |  |
| Fiscal year ended June 29, 2019 | $ | 2.6 |  |  | $ | 3.3 |  |  | $ | (0.2) |  |  | $ | (1.2) |  |  |  |  | $ | 4.5 |  |

[0001628280-21-017799:notes:481]
|  |  | (in millions) |
|  |  | Balance at Beginning of Period |  | Additions Charged to Costs/Expenses 1 |  | Deductions Credited to Costs/Expenses 2 |  | Balance at End of Period |
| Deferred tax valuation allowance: |  |  |  |  |  |  |  |  |
| Fiscal year ended July 3, 2021 |  | $ | 200.8 |  |  | $ | 68.7 |  |  | $ | — |  |  | $ | 269.5 |  |
| Fiscal year ended June 27, 2020 3 |  | $ | 190.3 |  |  | $ | 12.7 |  |  | $ | (2.2) |  |  | $ | 200.8 |  |
| Fiscal year ended June 29, 2019 3 |  | $ | 99.4 |  |  | $ | 93.5 |  |  | $ | (2.6) |  |  | $ | 190.3 |  |

[0001628280-21-017799:notes:482]
(1) Additions include current year additions charged to expenses and current year build due to increases in net deferred tax assets, return to provision true-ups, other adjustments to deferred taxes.

[0001628280-21-017799:notes:483]
(2) Net deductions include current year releases credited to expenses and current year reductions due to decreases in net deferred tax assets, return to provision true-ups, other adjustments to deferred taxes.

[0001628280-21-017799:notes:484]
(3) Certain prior period amounts have been reclassified to conform to current year presentation on a jurisdiction by jurisdiction basis.
