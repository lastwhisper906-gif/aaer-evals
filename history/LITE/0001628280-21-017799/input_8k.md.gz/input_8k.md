# LITE 8-K — 0001628280-21-017219 filed 2021-08-18

## item codes, every 8-K on or before 2021-08-31

- 2021-08-18 0001628280-21-017219 — 2.02, 9.01
- 2021-06-08 0001633978-21-000030 — 5.02, 9.01
- 2021-05-12 0001633978-21-000008 — 2.02, 9.01
- 2021-03-10 0001193125-21-075438 — 1.01, 8.01, 9.01
- 2021-02-02 0001633978-21-000002 — 2.02, 9.01
- 2021-01-19 0001104659-21-005024 — 1.01, 2.02, 8.01, 9.01
- 2020-11-24 0001193125-20-302557 — 5.02, 5.07
- 2020-11-02 0001633978-20-000017 — 2.02, 9.01
- 2020-09-18 0001633978-20-000012 — 5.02, 9.01
- 2020-08-11 0001633978-20-000010 — 2.02, 9.01
- 2020-05-05 0001628280-20-006358 — 2.02, 9.01
- 2020-02-04 0001633978-20-000002 — 2.02, 9.01
- 2019-12-12 0001193125-19-312875 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2019-12-04 0001633978-19-000075 — 8.01
- 2019-11-20 0001633978-19-000074 — 5.07
- 2019-10-31 0001633978-19-000070 — 2.02, 9.01
- 2019-08-08 0001633978-19-000068 — 2.02, 9.01
- 2019-05-08 0001633978-19-000031 — 1.01
- 2019-05-07 0001633978-19-000029 — 2.02, 9.01
- 2019-02-15 0001633978-19-000005 — 9.01 — amendment of 0001193125-18-346211
- 2019-02-08 0001193125-19-031591 — 5.02, 9.01
- 2019-02-05 0001633978-19-000001 — 2.02, 9.01
- 2018-12-10 0001193125-18-346211 — 1.01, 2.01, 2.03, 5.02, 8.01, 9.01
- 2018-12-06 0001633978-18-000150 — 8.01
- 2018-11-14 0001633978-18-000139 — 5.07
- 2018-11-13 0001633978-18-000136 — 3.02
- 2018-11-13 0001633978-18-000132 — 7.01, 9.01
- 2018-11-01 0001628280-18-013238 — 2.02, 9.01
- 2018-08-08 0001633978-18-000056 — 2.02, 9.01
- 2018-06-08 0001193125-18-188241 — 5.02, 9.01
- 2018-05-02 0001633978-18-000029 — 2.02, 9.01
- 2018-03-12 0001193125-18-078154 — 1.01, 2.01, 8.01, 9.01
- 2018-02-06 0001628280-18-001082 — 2.02, 9.01
- 2017-11-08 0001633978-17-000133 — 5.02, 9.01
- 2017-11-07 0001633978-17-000131 — 5.07
- 2017-11-01 0001633978-17-000117 — 2.02, 9.01
- 2017-08-09 0001633978-17-000058 — 2.02, 9.01
- 2017-05-04 0001633978-17-000035 — 2.02, 9.01
- 2017-03-08 0001193125-17-074740 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2017-03-02 0001193125-17-066769 — 8.01, 9.01
- 2017-02-07 0001633978-17-000005 — 2.02, 9.01
- 2017-01-03 0001628280-17-000018 — 4.01, 9.01
- 2016-11-09 0001628280-16-021143 — 5.02, 5.07, 9.01
- 2016-10-27 0001628280-16-020382 — 2.02, 9.01
- 2016-08-09 0001628280-16-018811 — 2.02, 9.01
- 2016-06-21 0001628280-16-017201 — 8.01
- 2016-05-04 0001628280-16-015501 — 2.02, 9.01
- 2016-02-16 0001628280-16-011261 — 5.02, 9.01
- 2016-02-04 0001628280-16-010758 — 5.02, 9.01
- 2016-02-04 0001628280-16-010755 — 2.02, 9.01
- 2015-11-17 0001193125-15-378953 — 7.01
- 2015-11-10 0001628280-15-008606 — 2.02, 9.01
- 2015-09-28 0001193125-15-329665 — 8.01, 9.01
- 2015-08-11 0001193125-15-286405 — 7.01, 9.01
- 2015-08-06 0001193125-15-281219 — 1.01, 5.02, 5.03, 5.05, 8.01, 9.01
- 2015-08-03 0001193125-15-274808 — 5.03, 9.01

## late-filing notifications on or before 2021-08-31

- 2015-11-10 0001628280-15-008612 — NT 10-Q, for the period ended 2015-09-26
- 2015-09-28 0001193125-15-329672 — NT 10-K, for the period ended 2015-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001628280-21-017219:8k_2_02:1]
EX-99.1
2
lite_ex991xq4fy21.htm
EX-99.1

[0001628280-21-017219:8k_2_02:2]
Document

[0001628280-21-017219:8k_2_02:3]
NEWS RELEASE

[0001628280-21-017219:8k_2_02:4]
LUMENTUM ANNOUNCES FISCAL FOURTH QUARTER AND FULL YEAR 2021 RESULTS

[0001628280-21-017219:8k_2_02:5]
Fiscal Fourth Quarter Highlights:

[0001628280-21-017219:8k_2_02:6]
•Net revenue of $392.1 million

[0001628280-21-017219:8k_2_02:7]
•GAAP operating margin of 11.7%; Non-GAAP operating margin of 24.6%

[0001628280-21-017219:8k_2_02:8]
•GAAP diluted net income per share of $0.28; Non-GAAP diluted net income per share of  $1.15 using the “prior method” or $1.06 using the “new method” of calculating our Non-GAAP tax provision (1)

[0001628280-21-017219:8k_2_02:9]
Fiscal Year 2021 Highlights:

[0001628280-21-017219:8k_2_02:10]
•Record net revenue of $1.74 billion

[0001628280-21-017219:8k_2_02:11]
•GAAP operating margin of 30.2%; Non-GAAP operating margin of 30.8%

[0001628280-21-017219:8k_2_02:12]
•GAAP diluted net income per share of $5.07; Non-GAAP diluted net income per share of  $6.31 using the “prior method”  or $5.84 using the “new method” of calculating our Non-GAAP tax provision  (1)

[0001628280-21-017219:8k_2_02:13]
San Jose, Calif., August 18, 2021 – Lumentum Holdings Inc. (“Lumentum” or the “Company”) today reported results for its fiscal fourth quarter and full year ended July 3, 2021.

[0001628280-21-017219:8k_2_02:14]
“The fourth quarter capped off a record fiscal 2021 with strong demand for our products that resulted in a book to bill of 1.2,” said Alan Lowe, President and CEO. “While demand continues to grow into the first quarter, shortages of critical semiconductor components are negatively impacting our first quarter revenue outlook by more than $30 million.”

[0001628280-21-017219:8k_2_02:15]
Mr. Lowe added, “We believe, however, the continuing shift in our demand mix towards differentiated products that enable next generation customer solutions is a leading indicator for growth over the coming years.”

[0001628280-21-017219:8k_2_02:16]
“By all financial measures fiscal 2021 was our best year yet, with record revenue, earnings per share, and margins, the latter achieving our previously announced target model,” said Wajid Ali, Executive Vice-President and CFO. “Due to confidence in our long-term financial performance, during the fourth quarter we repurchased 3.1 million shares, or 4% of our shares outstanding, using $241 million of our current $700 million share buyback program.”

[0001628280-21-017219:8k_2_02:17]
_________________________

[0001628280-21-017219:8k_2_02:18]
(1) In order to give a more meaningful perspective of our tax burden over a longer-term period, and in accordance with the SEC Non-GAAP Financial Measures Compliance and Disclosure Interpretations, beginning in our fiscal fourth quarter, Lumentum is changing its method of calculating its non-GAAP income tax provision. For this quarter only, Lumentum will provide its non-GAAP tax provisions using both the prior method, focused on current year taxes, and a new method. This change in methodology will not affect the Company’s non-GAAP operating profit, annual cash tax payments, or cash flows, but should result in higher reported non-GAAP tax provisions.

[0001628280-21-017219:8k_2_02:19]
Fiscal Fourth Quarter Highlights:

[0001628280-21-017219:8k_2_02:20]
Net revenue for the fiscal fourth quarter of 2021 was $392.1 million, with GAAP net income attributable to common stockholders of $21.5 million, or $0.28 per diluted share. Net revenue for the fiscal third quarter of 2021 was $419.5 million, with GAAP net income of $225.5 million, or $2.85 per diluted share. Net revenue for the fiscal fourth quarter of 2020 was $368.1 million, with GAAP net loss attributable to common stockholders of $(4.6) million, or $(0.06) per diluted share.

[0001628280-21-017219:8k_2_02:21]
Using the prior method of calculating non-GAAP income taxes, non-GAAP net income for the fiscal fourth quarter of 2021 was $89.5 million, or $1.15 per diluted share. Using the prior method of calculating non-GAAP income taxes, non-GAAP net income for the fiscal fourth quarter of 2020 was $91.7 million, or $1.18 per diluted share.

[0001628280-21-017219:8k_2_02:22]
Using the new method of calculating non-GAAP income taxes, non-GAAP net income for the fiscal fourth quarter of 2021 was $81.9 million, or $1.06 per diluted share. Using the new method of calculating non-GAAP income taxes, non-GAAP net income for the fiscal fourth quarter of 2020 was $80.1 million, or $1.03 per diluted share.

[0001628280-21-017219:8k_2_02:23]
The Company held $1,946.0 million in total cash, cash equivalents, and short-term investments at the end of the fiscal fourth quarter of 2021, down $108.6 million from the third quarter of 2021.

[0001628280-21-017219:8k_2_02:24]
Full Fiscal Year 2021 Highlights:

[0001628280-21-017219:8k_2_02:25]
Net revenue for fiscal year 2021 was $1,742.8 million, with GAAP net income attributable to common stockholders of $397.3 million, or $5.07 per diluted share. Net revenue for fiscal year 2020 was $1,678.6 million, with GAAP net income attributable to common stockholders of $135.5 million, or $1.75 per diluted share.

[0001628280-21-017219:8k_2_02:26]
Using the prior method of calculating non-GAAP income taxes, non-GAAP net income for fiscal year 2021 was $495.0 million, or $6.31 per diluted share.  Under the prior method of calculating non-GAAP income taxes, non-GAAP net income for fiscal year 2020 was $420.5 million, or $5.42 per diluted share.

[0001628280-21-017219:8k_2_02:27]
Using the new method of calculating non-GAAP income taxes, non-GAAP net income for fiscal year 2021 was $458.2 million, or  $5.84 per diluted share.  Using the new method of calculating non-GAAP income taxes, non-GAAP net income for fiscal year 2020 was $384.3 million, or $4.95 per diluted share.

[0001628280-21-017219:8k_2_02:28]
The Company held $1,946.0 million in total cash, cash equivalents, and short-term investments at the end of the fiscal fourth quarter of 2021, up $392.2 million from the fourth quarter of 2020.

[0001628280-21-017219:8k_2_02:29]
Financial Overview – Fiscal Fourth Quarter Ended July 3, 2021

[0001628280-21-017219:8k_2_02:30]
|  | GAAP Results ($ in millions) |
|  | Q4 |  | Q3 |  | Q4 |  | Change |
|  | FY 2021 |  | FY 2021 |  | FY 2020 |  | Q/Q |  | Y/Y |
| Net revenue | $ | 392.1 |  |  | $ | 419.5 |  |  | $ | 368.1 |  |  | (6.5)% |  | 6.5% |
| Gross margin | 41.5 | % |  | 44.1 | % |  | 36.9 | % |  | (260)bps |  | 460bps |
| Operating margin | 11.7 | % |  | 63.6 | % |  | 7.3 | % |  | (5,190)bps |  | 440bps |
|  | Non-GAAP Results ($ in millions) |
|  | Q4 |  | Q3 |  | Q4 |  | Change |
|  | FY 2021 |  | FY 2021 |  | FY 2020 |  | Q/Q |  | Y/Y |
| Net revenue | $ | 392.1 |  |  | $ | 419.5 |  |  | $ | 368.1 |  |  | (6.5)% |  | 6.5% |
| Gross margin | 47.7 | % |  | 49.9 | % |  | 47.2 | % |  | (220)bps |  | 50bps |
| Operating margin | 24.6 | % |  | 27.9 | % |  | 24.8 | % |  | (330)bps |  | (20)bps |

[0001628280-21-017219:8k_2_02:31]
|  | Net Revenue by Segment ($ in millions) |
|  | Q4 |  | % of |  | Q3 |  | Q4 |  | Change |
|  | FY 2021 |  | Net Revenue |  | FY 2021 |  | FY 2020 |  | Q/Q |  | Y/Y |
| Optical Communications | $ | 355.2 |  |  | 90.6 | % |  | $ | 387.9 |  |  | $ | 330.3 |  |  | (8.4) | % |  | 7.5 | % |
| Lasers | 36.9 |  |  | 9.4 | % |  | 31.6 |  |  | 37.8 |  |  | 16.8 | % |  | (2.4) | % |
| Total | $ | 392.1 |  |  | 100.0 | % |  | $ | 419.5 |  |  | $ | 368.1 |  |  | (6.5) | % |  | 6.5 | % |

[0001628280-21-017219:8k_2_02:32]
Financial Overview – Fiscal Year Ended July 3, 2021

[0001628280-21-017219:8k_2_02:33]
|  | GAAP Results ($ in millions) |
|  | FY 2021 |  | FY 2020 |  | Change Y/Y |  |
| Net revenue | $ | 1,742.8 |  |  | $ | 1,678.6 |  |  | 3.8% |  |
| Gross margin | 44.9 | % |  | 38.7 | % |  | 620bps |  |
| Operating margin | 30.2 | % |  | 12.2 | % |  | 1,800bps |  |

[0001628280-21-017219:8k_2_02:34]
|  | Non-GAAP Results ($ in millions) |
|  | FY 2021 |  | FY 2020 |  | Change Y/Y |  |
| Net revenue | $ | 1,742.8 |  |  | $ | 1,678.6 |  |  | 3.8% |  |
| Gross margin | 50.9 | % |  | 46.5 | % |  | 440bps |  |
| Operating margin | 30.8 | % |  | 26.6 | % |  | 420bps |  |

[0001628280-21-017219:8k_2_02:35]
|  | Net Revenue by Segment ($ in millions) |
|  | FY 2021 |  | FY 2020 |  | Change Y/Y |  |
| Optical Communications | $ | 1,620.7 |  |  | $ | 1,515.1 |  |  | 7.0% |  |
| Lasers | 122.1 |  |  | 163.5 |  |  | (25.3)% |  |
| Total | $ | 1,742.8 |  |  | $ | 1,678.6 |  |  | 3.8% |  |

[0001628280-21-017219:8k_2_02:36]
The tables above provide comparisons of quarterly and annual results to prior periods, including sequential quarterly and year-over-year changes. A reconciliation between GAAP and non-GAAP measures is contained in this release under the section titled “Use of Non-GAAP Financial Measures.”

[0001628280-21-017219:8k_2_02:37]
Business Outlook

[0001628280-21-017219:8k_2_02:38]
Lumentum expects the following for the fiscal first quarter of 2022:

[0001628280-21-017219:8k_2_02:39]
•Net revenue in the range of $430 million to $445 million

[0001628280-21-017219:8k_2_02:40]
•Non-GAAP operating margin of 30.5% to 32.5%

[0001628280-21-017219:8k_2_02:41]
•Non-GAAP diluted earnings per share of $1.47 to $1.61

[0001628280-21-017219:8k_2_02:42]
We have not provided reconciliations from GAAP to non-GAAP measures for our outlook. A large portion of non-GAAP adjustments, such as restructuring charges, stock-based compensation, non-cash income tax expense and credits, integration related costs, inventory write down due to plans to exit certain product lines and other costs and contingencies unrelated to current and future operations are by their nature highly volatile and we have low visibility as to the range that may be incurred in the future.

[0001628280-21-017219:8k_2_02:43]
Conference Call

[0001628280-21-017219:8k_2_02:44]
Lumentum will host a conference call on August 18, 2021, at 5:30 am PT/8:30 am ET. A live webcast of the call and the replay will be available on the Lumentum website at http://investor.lumentum.com through August 25, 2021, at 8:59 pm PT. To listen to the live conference call, dial (844) 802-2439 or (412) 902-4275 and reference the passcode 10158822. To access the replay, dial (877) 344-7529 or (412) 317-0088 and reference the passcode 10158822. Supporting materials outlining the Company’s latest financial results will be posted on http://investor.lumentum.com under the “Events and Presentations” section concurrently with this earnings press release. Lumentum has used, and intends to continue to use, its Investor Relations website as means of disclosing material nonpublic information and for complying with its disclosure obligations under Regulation FD. This press release is being furnished as an exhibit to a Current Report on Form 8-K filed with the Securities and Exchange Commission and will be available at http://www.sec.gov/.

[0001628280-21-017219:8k_2_02:45]
About Lumentum

[0001628280-21-017219:8k_2_02:46]
Lumentum (NASDAQ: LITE) is a market-leading designer and manufacturer of innovative optical and photonic products enabling optical networking and laser applications worldwide. Lumentum optical components and subsystems are part of virtually every type of telecom, enterprise, and data center network. Lumentum lasers enable advanced manufacturing techniques and diverse applications including next-generation 3D sensing capabilities. Lumentum is headquartered in San Jose, California with R&D, manufacturing, and sales offices worldwide. For more information, visit www.lumentum.com.

[0001628280-21-017219:8k_2_02:47]
Forward-Looking Statements

[0001628280-21-017219:8k_2_02:48]
Category: Financial

[0001628280-21-017219:8k_2_02:49]
Contact Information

[0001628280-21-017219:8k_2_02:50]
Investors:     Jim Fanucchi, 408-404-5400; investor.relations@lumentum.com

[0001628280-21-017219:8k_2_02:51]
Media:         Sean Ogarrio, 408-546-5405; media@lumentum.com

[0001628280-21-017219:8k_2_02:52]
The following financial tables are presented in accordance with GAAP, unless otherwise specified.

[0001628280-21-017219:8k_2_02:53]
LUMENTUM HOLDINGS INC.

[0001628280-21-017219:8k_2_02:54]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001628280-21-017219:8k_2_02:55]
(in millions, except per share data)

[0001628280-21-017219:8k_2_02:56]
(unaudited)

[0001628280-21-017219:8k_2_02:57]
|  | Three Months Ended |  | Twelve Months Ended |
|  | July 3, 2021 |  | June 27, 2020 |  | July 3, 2021 |  | June 27, 2020 |
| Net revenue | $ | 392.1 |  |  | $ | 368.1 |  |  | $ | 1,742.8 |  |  | $ | 1,678.6 |  |
| Cost of sales | 213.4 |  |  | 217.4 |  |  | 898.0 |  |  | 974.6 |  |
| Amortization of acquired developed intangibles | 15.9 |  |  | 15.0 |  |  | 61.7 |  |  | 53.8 |  |
| Gross profit | 162.8 |  |  | 135.7 |  |  | 783.1 |  |  | 650.2 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 54.1 |  |  | 49.0 |  |  | 214.5 |  |  | 198.6 |  |
| Selling, general and administrative | 58.3 |  |  | 54.8 |  |  | 241.4 |  |  | 235.2 |  |
| Restructuring and related charges | 4.6 |  |  | 3.1 |  |  | 7.7 |  |  | 8.0 |  |
| Merger termination fee and related costs, net | — |  |  | — |  |  | (207.5) |  |  | — |  |
| Impairment charges | — |  |  | 1.8 |  |  | — |  |  | 4.3 |  |
| Total operating expenses | 117.0 |  |  | 108.7 |  |  | 256.1 |  |  | 446.1 |  |
| Income from operations | 45.8 |  |  | 27.0 |  |  | 527.0 |  |  | 204.1 |  |
| Interest expense | (18.0) |  |  | (15.9) |  |  | (66.7) |  |  | (61.2) |  |
| Other income, net | 0.7 |  |  | 3.5 |  |  | 2.8 |  |  | 31.4 |  |
| Income before income taxes | 28.5 |  |  | 14.6 |  |  | 463.1 |  |  | 174.3 |  |
| Provision for income taxes | 7.0 |  |  | 19.2 |  |  | 65.8 |  |  | 38.8 |  |
| Net income (loss) | $ | 21.5 |  |  | $ | (4.6) |  |  | $ | 397.3 |  |  | $ | 135.5 |  |
| Net income (loss) per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.29 |  |  | $ | (0.06) |  |  | $ | 5.27 |  |  | $ | 1.79 |  |
| Diluted | $ | 0.28 |  |  | $ | (0.06) |  |  | $ | 5.07 |  |  | $ | 1.75 |  |
| Shares used to compute net income (loss) per share: |  |  |  |  |  |  |  |
| Basic | 74.8 |  |  | 75.0 |  |  | 75.4 |  |  | 75.9 |  |
| Diluted | 77.5 |  |  | 75.0 |  |  | 78.4 |  |  | 77.6 |  |

[0001628280-21-017219:8k_2_02:58]
LUMENTUM HOLDINGS INC.

[0001628280-21-017219:8k_2_02:59]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001628280-21-017219:8k_2_02:60]
(in millions, except per share data)

[0001628280-21-017219:8k_2_02:61]
(unaudited)

[0001628280-21-017219:8k_2_02:62]
|  | July 3, 2021 |  | June 27, 2020 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 774.3 |  |  | $ | 298.0 |  |
| Short-term investments | 1,171.7 |  |  | 1,255.8 |  |
| Accounts receivable, net | 212.8 |  |  | 233.5 |  |
| Inventories | 196.4 |  |  | 188.9 |  |
| Prepayments and other current assets | 81.6 |  |  | 73.8 |  |
| Total current assets | 2,436.8 |  |  | 2,050.0 |  |
| Property, plant and equipment, net | 361.1 |  |  | 393.0 |  |
| Operating lease right-of-use assets, net | 67.4 |  |  | 78.7 |  |
| Goodwill | 368.9 |  |  | 368.9 |  |
| Other intangible assets, net | 241.2 |  |  | 316.8 |  |
| Deferred tax asset | 72.9 |  |  | 81.2 |  |
| Other non-current assets | 3.3 |  |  | 4.0 |  |
| Total assets | $ | 3,551.6 |  |  | $ | 3,292.6 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 116.9 |  |  | $ | 150.8 |  |
| Accrued payroll and related expenses | 54.3 |  |  | 53.4 |  |
| Accrued expenses | 33.1 |  |  | 23.7 |  |
| Convertible notes, current | 390.7 |  |  | — |  |
| Operating lease liabilities, current | 11.8 |  |  | 10.8 |  |
| Other current liabilities | 57.8 |  |  | 44.3 |  |
| Total current liabilities | 664.6 |  |  | 283.0 |  |
| Convertible notes, non-current | 789.8 |  |  | 1,120.3 |  |
| Operating lease liabilities, non-current | 47.6 |  |  | 57.6 |  |
| Deferred tax liability | 35.9 |  |  | 46.5 |  |
| Other non-current liabilities | 40.9 |  |  | 36.0 |  |
| Total liabilities | 1,578.8 |  |  | 1,543.4 |  |
| Stockholders’ equity: |  |  |  |
| Common stock, $0.001 par value, 990 authorized shares; 73.0 and 75.1 shares issued and outstanding as of July 3, 2021 and June 27, 2020, respectively | 0.1 |  |  | 0.1 |  |
| Additional paid-in capital | 1,743.6 |  |  | 1,676.6 |  |
| Retained earnings | 220.9 |  |  | 64.6 |  |
| Accumulated other comprehensive income | 8.2 |  |  | 7.9 |  |
| Total stockholders’ equity | 1,972.8 |  |  | 1,749.2 |  |
| Total liabilities and stockholders’ equity | $ | 3,551.6 |  |  | $ | 3,292.6 |  |

[0001628280-21-017219:8k_2_02:63]
Use of Non-GAAP Financial Measures

[0001628280-21-017219:8k_2_02:64]
In this press release, Lumentum provides investors with gross margin, gross profit, research and development expense, selling, general and administrative expense, operating margin, operating income, interest and other income (expense), net, income before income taxes, provision for taxes, net income, and net income per share on a non-GAAP basis as well as the non-GAAP measures of EBITDA and Adjusted EBITDA. Lumentum believes this non-GAAP financial information provides additional insight into the Company’s on-going business operations and results, as well as cash generation, and has therefore chosen to provide this information to investors for a more consistent basis of comparison and to help them evaluate the results of the Company’s on-going operations and enable more meaningful period to period comparisons. In addition, the Company believes that providing certain of these measures allow investors to better understand the Company’s cash flows and, importantly, to evaluate the efficacy of the methodology and information used by management to evaluate and measure such cash flows. However, these measures may be different from non-GAAP measures used by other companies, limiting their usefulness for comparison purposes. The non-GAAP financial measures used in this press release should not be considered in isolation from measures of financial performance prepared in accordance with GAAP. Investors are cautioned that there are material limitations associated with the use of non-GAAP financial measures as an analytical tool. In particular, many of the adjustments to our GAAP financial measures reflect the exclusion of items that are recurring and will be reflected in our financial results for the foreseeable future. Further, these non-GAAP financial measures may not be comparable to similarly titled measurements reported by other companies.

[0001628280-21-017219:8k_2_02:65]
Non-GAAP gross margin, non-GAAP gross profit, non-GAAP expenses, non-GAAP operating margin, non-GAAP operating income, non-GAAP income before income taxes, non-GAAP net income, and non-GAAP net income per share and Adjusted EBITDA exclude (i) stock-based compensation, (ii) inventory write-downs and fixed asset impairment due to cancelled programs, plans to exit certain lines of business and other costs and contingencies unrelated to current and future operations, (iii) acquisition and disposition related costs, (iv) integration related costs, (v) amortization of acquired intangibles, (vi) amortization of inventory fair value adjustments, (vii) expenses related to COVID-19 outbreak, (viii) restructuring and related charges, (ix) the termination fee we received in connection with the termination of our proposed merger agreement with Coherent, net of acquisition related charges, (x) impairment charge, (xi) gain on sale of product lines, (xii) foreign exchange (gains) losses, net, (xiii) non-cash interest expense, and (xiv) other charges, which include transferring product lines to Thailand, excess and obsolete inventory charges driven by U.S. trade restrictions and the related decline in demand from Huawei, and litigation related expenses. The presentation of these and other similar items in Lumentum’s non-GAAP financial results should not be interpreted as implying that these items are non-recurring, infrequent or unusual.

[0001628280-21-017219:8k_2_02:66]
A quantitative reconciliation between GAAP and non-GAAP financial data with respect to historical periods is included in the supplemental financial table attached to this press release.

[0001628280-21-017219:8k_2_02:67]
LUMENTUM HOLDINGS INC.

[0001628280-21-017219:8k_2_02:68]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001628280-21-017219:8k_2_02:69]
(in millions, except per share data)

[0001628280-21-017219:8k_2_02:70]
(unaudited)

[0001628280-21-017219:8k_2_02:71]
|  | Three Months Ended |  | Twelve Months Ended |
|  | July 3, 2021 |  | April 3, 2021 |  | June 27, 2020 |  | July 3, 2021 |  | June 27, 2020 |
| Gross profit on GAAP basis | $ | 162.8 |  |  | $ | 185.0 |  |  | $ | 135.7 |  |  | $ | 783.1 |  |  | $ | 650.2 |  |
| Stock-based compensation | 5.4 |  |  | 5.3 |  |  | 3.5 |  |  | 19.2 |  |  | 16.1 |  |
| Inventory and fixed asset write down due to product line exits | — |  |  | — |  |  | 1.0 |  |  | 0.4 |  |  | 7.0 |  |
| Integration related costs | — |  |  | — |  |  | 1.8 |  |  | — |  |  | 4.9 |  |
| Amortization of acquired intangibles | 15.9 |  |  | 15.8 |  |  | 15.0 |  |  | 61.7 |  |  | 53.8 |  |
| Amortization of inventory fair value adjustments | — |  |  | — |  |  | — |  |  | — |  |  | 5.8 |  |
| Expenses related to COVID-19 outbreak (1) | — |  |  | — |  |  | 5.0 |  |  | — |  |  | 6.6 |  |
| Other charges (2) | 3.1 |  |  | 3.1 |  |  | 11.9 |  |  | 23.1 |  |  | 35.8 |  |
| Gross profit on non-GAAP basis | $ | 187.2 |  |  | $ | 209.2 |  |  | $ | 173.9 |  |  | $ | 887.5 |  |  | $ | 780.2 |  |
| Gross margin on non-GAAP basis | 47.7 | % |  | 49.9 | % |  | 47.2 | % |  | 50.9 | % |  | 46.5 | % |
| Research and development on GAAP basis | $ | 54.1 |  |  | $ | 57.2 |  |  | $ | 49.0 |  |  | $ | 214.5 |  |  | $ | 198.6 |  |
| Stock-based compensation | (4.7) |  |  | (5.3) |  |  | (3.8) |  |  | (19.5) |  |  | (15.9) |  |
| Expenses related to COVID-19 outbreak (1) | — |  |  | — |  |  | (0.5) |  |  | — |  |  | (0.5) |  |
| Other gains (charges) | (0.3) |  |  | (0.6) |  |  | 1.2 |  |  | (0.9) |  |  | 1.1 |  |
| Research and development on non-GAAP basis | $ | 49.1 |  |  | $ | 51.3 |  |  | $ | 45.9 |  |  | $ | 194.1 |  |  | $ | 183.3 |  |
| Selling, general and administrative on GAAP basis | $ | 58.3 |  |  | $ | 65.5 |  |  | $ | 54.8 |  |  | $ | 241.4 |  |  | $ | 235.2 |  |
| Stock-based compensation | (14.1) |  |  | (14.5) |  |  | (9.8) |  |  | (54.2) |  |  | (41.2) |  |
| Integration related costs | — |  |  | (0.2) |  |  | (1.1) |  |  | (0.7) |  |  | (12.2) |  |
| Amortization of acquired intangibles | (6.2) |  |  | (6.2) |  |  | (6.2) |  |  | (24.0) |  |  | (24.8) |  |
| Other gains (charges) (3) | 3.5 |  |  | (3.8) |  |  | (1.1) |  |  | (5.2) |  |  | (6.9) |  |
| Selling, general and administrative on non-GAAP basis | $ | 41.5 |  |  | $ | 40.8 |  |  | $ | 36.6 |  |  | $ | 157.3 |  |  | $ | 150.1 |  |
| Income from operations on GAAP basis | $ | 45.8 |  |  | $ | 266.9 |  |  | $ | 27.0 |  |  | $ | 527.0 |  |  | $ | 204.1 |  |
| Stock-based compensation | 24.2 |  |  | 25.1 |  |  | 17.1 |  |  | 92.9 |  |  | 73.2 |  |
| Inventory and fixed asset write down due to product line exits | — |  |  | — |  |  | 1.0 |  |  | 0.4 |  |  | 7.0 |  |
| Integration related costs | — |  |  | 0.2 |  |  | 2.9 |  |  | 0.7 |  |  | 17.1 |  |
| Amortization of acquired intangibles | 22.1 |  |  | 22.0 |  |  | 21.2 |  |  | 85.7 |  |  | 78.6 |  |
| Amortization of fair inventory value adjustments | — |  |  | — |  |  | — |  |  | — |  |  | 5.8 |  |
| Restructuring and related charges | 4.6 |  |  | 2.9 |  |  | 3.1 |  |  | 7.7 |  |  | 8.0 |  |
| Merger termination fee and related costs, net (4) | — |  |  | (207.5) |  |  | — |  |  | (207.5) |  |  | — |  |
| Expenses related to COVID-19 outbreak (1) | — |  |  | — |  |  | 5.5 |  |  | — |  |  | 7.1 |  |
| Impairment charge (5) | — |  |  | — |  |  | 1.8 |  |  | — |  |  | 4.3 |  |
| Other (gains) charges | (0.1) |  |  | 7.5 |  |  | 11.8 |  |  | 29.2 |  |  | 41.6 |  |
| Income from operations on non-GAAP basis | $ | 96.6 |  |  | $ | 117.1 |  |  | $ | 91.4 |  |  | $ | 536.1 |  |  | $ | 446.8 |  |
| Operating margin on non-GAAP basis | 24.6 | % |  | 27.9 | % |  | 24.8 | % |  | 30.8 | % |  | 26.6 | % |

[0001628280-21-017219:8k_2_02:72]
| Interest and other (expense) income, net on GAAP basis | $ | (17.3) |  |  | $ | (14.0) |  |  | $ | (12.4) |  |  | $ | (63.9) |  |  | $ | (29.8) |  |
| Other interest and (income) expense adjustments | — |  |  | — |  |  | — |  |  | — |  |  | (2.0) |  |
| Gain on sale of product lines | (0.2) |  |  | — |  |  | (0.7) |  |  | (0.7) |  |  | (14.5) |  |
| Foreign exchange (gains) losses, net | 0.6 |  |  | (1.3) |  |  | 1.1 |  |  | 4.4 |  |  | 1.4 |  |
| Non-cash interest expense on convertible notes and term loan | 16.2 |  |  | 14.8 |  |  | 14.3 |  |  | 60.1 |  |  | 47.6 |  |
| Interest and other (expense) income, net on non-GAAP basis | $ | (0.7) |  |  | $ | (0.5) |  |  | $ | 2.3 |  |  | $ | (0.1) |  |  | $ | 2.7 |  |
| Income before income taxes on GAAP basis | $ | 28.5 |  |  | $ | 252.9 |  |  | $ | 14.6 |  |  | $ | 463.1 |  |  | $ | 174.3 |  |
| Stock-based compensation | 24.2 |  |  | 25.1 |  |  | 17.1 |  |  | 92.9 |  |  | 73.2 |  |
| Inventory and fixed asset write down due to product line exits | — |  |  | — |  |  | 1.0 |  |  | 0.4 |  |  | 7.0 |  |
| Integration related costs | — |  |  | 0.2 |  |  | 2.9 |  |  | 0.7 |  |  | 17.1 |  |
| Amortization of acquired intangibles | 22.1 |  |  | 22.0 |  |  | 21.2 |  |  | 85.7 |  |  | 78.6 |  |
| Amortization of inventory fair value adjustments | — |  |  | — |  |  | — |  |  | — |  |  | 5.8 |  |
| Restructuring and related charges | 4.6 |  |  | 2.9 |  |  | 3.1 |  |  | 7.7 |  |  | 8.0 |  |
| Merger termination fee and related costs, net (4) | — |  |  | (207.5) |  |  | — |  |  | (207.5) |  |  | — |  |
| Expenses related to COVID-19 outbreak (1) | — |  |  | — |  |  | 5.5 |  |  | — |  |  | 7.1 |  |
| Impairment charge (5) | — |  |  | — |  |  | 1.8 |  |  | — |  |  | 4.3 |  |
| Other interest and (income) expense adjustments | — |  |  | — |  |  | — |  |  | — |  |  | (2.0) |  |
| Gain on sale of product lines | (0.2) |  |  | — |  |  | (0.7) |  |  | (0.7) |  |  | (14.5) |  |
| Foreign exchange (gains) losses, net | 0.6 |  |  | (1.3) |  |  | 1.1 |  |  | 4.4 |  |  | 1.4 |  |
| Non-cash interest expense on convertible notes and term loan | 16.2 |  |  | 14.8 |  |  | 14.3 |  |  | 60.1 |  |  | 47.6 |  |
| Other (gains) charges | (0.1) |  |  | 7.5 |  |  | 11.8 |  |  | 29.2 |  |  | 41.6 |  |
| Income before income taxes on non-GAAP basis | $ | 95.9 |  |  | $ | 116.6 |  |  | $ | 93.7 |  |  | $ | 536.0 |  |  | $ | 449.5 |  |

[0001628280-21-017219:8k_2_02:73]
|  |  | (Prior Method) |  | (New Method) |
|  |  | Three Months Ended |  | Twelve Months Ended |  | Three Months Ended |  | Twelve Months Ended |
|  |  | July 3, 2021 |  | April 3, 2021 |  | June 27, 2020 |  | July 3, 2021 |  | June 27, 2020 |  | July 3, 2021 |  | April 3, 2021 |  | June 27, 2020 |  | July 3, 2021 |  | June 27, 2020 |
| Provision for income taxes on GAAP basis |  | $ | 7.0 |  |  | $ | 27.4 |  |  | $ | 19.2 |  |  | $ | 65.8 |  |  | $ | 38.8 |  |  | $ | 7.0 |  |  | $ | 27.4 |  |  | $ | 19.2 |  |  | $ | 65.8 |  |  | $ | 38.8 |  |
| Income tax adjustments |  | (0.6) |  |  | (21.4) |  |  | (17.2) |  |  | (24.8) |  | (9.8) |  |  | 7.0 |  |  | (10.5) |  |  | (5.6) |  |  | 12.0 |  |  | 26.4 |  |
| Provision for income taxes on non-GAAP basis |  | $ | 6.4 |  |  | $ | 6.0 |  |  | $ | 2.0 |  |  | $ | 41.0 |  |  | $ | 29.0 |  |  | $ | 14.0 |  |  | $ | 16.9 |  |  | $ | 13.6 |  |  | $ | 77.8 |  |  | $ | 65.2 |  |
| Net income (loss) on GAAP basis |  | $ | 21.5 |  |  | $ | 225.5 |  |  | $ | (4.6) |  |  | $ | 397.3 |  |  | $ | 135.5 |  |  | $ | 21.5 |  |  | $ | 225.5 |  |  | $ | (4.6) |  |  | $ | 397.3 |  |  | $ | 135.5 |  |
| Stock-based compensation |  | 24.2 |  |  | 25.1 |  |  | 17.1 |  |  | 92.9 |  |  | 73.2 |  |  | 24.2 |  |  | 25.1 |  |  | 17.1 |  |  | 92.9 |  |  | 73.2 |  |
| Inventory and fixed asset write down due to product line exits |  | — |  |  | — |  |  | 1.0 |  |  | 0.4 |  |  | 7.0 |  |  | — |  |  | — |  |  | 1.0 |  |  | 0.4 |  |  | 7.0 |  |
| Integration related costs |  | — |  |  | 0.2 |  |  | 2.9 |  |  | 0.7 |  |  | 17.1 |  |  | — |  |  | 0.2 |  |  | 2.9 |  |  | 0.7 |  |  | 17.1 |  |
| Amortization of acquired intangibles |  | 22.1 |  |  | 22.0 |  |  | 21.2 |  |  | 85.7 |  |  | 78.6 |  |  | 22.1 |  |  | 22.0 |  |  | 21.2 |  |  | 85.7 |  |  | 78.6 |  |
| Amortization of inventory fair value adjustments |  | — |  |  | — |  |  | — |  |  | — |  |  | 5.8 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 5.8 |  |
| Restructuring and related charges |  | 4.6 |  |  | 2.9 |  |  | 3.1 |  |  | 7.7 |  |  | 8.0 |  |  | 4.6 |  |  | 2.9 |  |  | 3.1 |  |  | 7.7 |  |  | 8.0 |  |
| Merger termination fee and related costs, net (4) |  | — |  |  | (207.5) |  |  | — |  |  | (207.5) |  |  | — |  |  | — |  |  | (207.5) |  |  | — |  |  | (207.5) |  |  | — |  |
| Expenses related to COVID-19 outbreak (1) |  | — |  |  | — |  |  | 5.5 |  |  | — |  |  | 7.1 |  |  | — |  |  | — |  |  | 5.5 |  |  | — |  |  | 7.1 |  |
| Impairment charge (5) |  | — |  |  | — |  |  | 1.8 |  |  | — |  |  | 4.3 |  |  | — |  |  | — |  |  | 1.8 |  |  | — |  |  | 4.3 |  |
| Other interest and (income) expense adjustments |  | — |  |  | — |  |  | — |  |  | — |  |  | (2.0) |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (2.0) |  |
| Gain on sale of product lines |  | (0.2) |  |  | — |  |  | (0.7) |  |  | (0.7) |  |  | (14.5) |  |  | (0.2) |  |  | — |  |  | (0.7) |  |  | (0.7) |  |  | (14.5) |  |
| Foreign exchange (gains) losses, net |  | 0.6 |  |  | (1.3) |  |  | 1.1 |  |  | 4.4 |  |  | 1.4 |  |  | 0.6 |  |  | (1.3) |  |  | 1.1 |  |  | 4.4 |  |  | 1.4 |  |
| Non-cash interest expense on convertible notes and term loan |  | 16.2 |  |  | 14.8 |  |  | 14.3 |  |  | 60.1 |  |  | 47.6 |  |  | 16.2 |  |  | 14.8 |  |  | 14.3 |  |  | 60.1 |  |  | 47.6 |  |
| Other (gains) charges |  | (0.1) |  |  | 7.5 |  |  | 11.8 |  |  | 29.2 |  |  | 41.6 |  |  | (0.1) |  |  | 7.5 |  |  | 11.8 |  |  | 29.2 |  |  | 41.6 |  |
| Income tax adjustments |  | 0.6 |  |  | 21.4 |  |  | 17.2 |  |  | 24.8 |  | 9.8 |  |  | (7.0) |  |  | 10.5 |  |  | 5.6 |  |  | (12.0) |  |  | (26.4) |  |
| Net income on non-GAAP basis |  | $ | 89.5 |  |  | $ | 110.6 |  |  | $ | 91.7 |  |  | $ | 495.0 |  |  | $ | 420.5 |  |  | $ | 81.9 |  |  | $ | 99.7 |  |  | $ | 80.1 |  |  | $ | 458.2 |  |  | $ | 384.3 |  |
| Net income per share on non-GAAP basis |  | $ | 1.15 |  |  | $ | 1.40 |  |  | $ | 1.18 |  |  | $ | 6.31 |  |  | $ | 5.42 |  |  | $ | 1.06 |  |  | $ | 1.26 |  |  | $ | 1.03 |  |  | $ | 5.84 |  |  | $ | 4.95 |  |
| Shares used in per share calculation - diluted on GAAP basis |  | 77.5 |  |  | 79.2 |  |  | 75.0 |  |  | 78.4 |  |  | 77.6 |  |  | 77.5 |  |  | 79.2 |  |  | 75.0 |  |  | 78.4 |  |  | 77.6 |  |

[0001628280-21-017219:8k_2_02:74]
| Non-GAAP adjustment (6) |  | — |  |  | — |  |  | 2.5 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 2.5 |  |  | — |  |  | — |  |
| Shares used in per share calculation - diluted on non-GAAP basis |  | 77.5 |  |  | 79.2 |  |  | 77.5 |  |  | 78.4 |  |  | 77.6 |  |  | 77.5 |  |  | 79.2 |  |  | 77.5 |  |  | 78.4 |  |  | 77.6 |  |

[0001628280-21-017219:8k_2_02:75]
In order to give a more meaningful perspective of our tax burden over a longer-term period, and in accordance with the SEC Non-GAAP Financial Measures Compliance and Disclosure Interpretations, beginning in our fiscal fourth quarter, Lumentum is changing its method of calculating its non-GAAP income tax provision. For this quarter only, Lumentum will provide its non-GAAP tax provisions using both the prior method, focused on current year taxes, and a new method. This change in methodology will not affect the Company’s non-GAAP operating profit, annual cash tax payments, or cash flows, but should result in higher reported non-GAAP tax provisions.

[0001628280-21-017219:8k_2_02:76]
(1) During the three and twelve months ended June 27, 2020, we recorded expenses of $5.5 million and $7.1 million, respectively, related to the COVID-19 outbreak, which included incremental costs for payroll expense such as overtime pay, pay for employees who are not working, facilities costs such as gloves, masks and temperature gauges, and under-utilized capacity at certain facilities, in which manufacturing output was impacted. These COVID-19 related costs were partially offset by benefits realized from government credits for employers’ payroll tax.

[0001628280-21-017219:8k_2_02:77]
(2) Other charges excluded from gross profit on non-GAAP basis for the three and twelve months ended July 3, 2021 include costs of transferring product lines to new production facilities of $0.4 million and $6.9 million, respectively. In addition, during the three and twelve months ended July 3, 2021, we incurred a $2.8 million write-down of an idle asset. During the three months ended July 3, 2021, we benefited from a $1.1 million sale of inventory to Huawei that was previously written down due to U.S. trade restrictions and the related decline in demand. We incurred excess and obsolete inventory charges related to the decline in demand from Huawei of $4.5 million during the twelve months ended July 3, 2021. During the twelve months ended July 3, 2021, we recorded $5.0 million impairment charge associated with excess capacity related to our Fiber laser business.

[0001628280-21-017219:8k_2_02:78]
Other charges excluded from gross profit on a non-GAAP basis for the three and twelve months ended June 27, 2020, primarily include costs of transferring product lines to new production facilities, including Thailand of $3.0 million and $11.5 million, respectively. We also incurred excess and obsolete inventory charges driven by the decline in demand from Huawei $12.8 million during the twelve months ended June 27, 2020. In addition, during the three months ended  June 27, 2020,  we incurred $6.2 million impairment charges associated with excess capacity related to our Fiber laser business.

[0001628280-21-017219:8k_2_02:79]
(3) Other gains (charges) excluded from selling, general and administrative on non-GAAP basis for the three and twelve months ended July 3, 2021 include an $8.3 million gain on the sale of land and building in San Jose, California.

[0001628280-21-017219:8k_2_02:80]
(4) For the twelve months ended July 3, 2021, we recorded a $217.6 million gain related to the receipt of a termination fee from Coherent in March 2021 as a result of the termination of our merger agreement. This gain was offset by $10.1 million of Coherent acquisition related charges.

[0001628280-21-017219:8k_2_02:81]
(5) For the three and twelve months ended June 27, 2020, we recorded impairment charges of $1.8 million and $4.3 million, respectively for property, plant and equipment related to the decision to exit the Datacom module product line.

[0001628280-21-017219:8k_2_02:82]
(6) This adjustment represents weighted-average potentially dilutive securities from our stock-based benefit plans excluded from the computation of diluted net loss per share attributable to common stockholders on a GAAP basis because the effect would have been anti-dilutive. This adjustment amount is added for the computation of diluted net income per share on a non-GAAP basis as we had a net income on a non-GAAP basis.

[0001628280-21-017219:8k_2_02:83]
LUMENTUM HOLDINGS INC.

[0001628280-21-017219:8k_2_02:84]
RECONCILIATION OF GAAP NET INCOME (LOSS) TO ADJUSTED EBITDA

[0001628280-21-017219:8k_2_02:85]
(in millions, except per share data)

[0001628280-21-017219:8k_2_02:86]
(unaudited)

[0001628280-21-017219:8k_2_02:87]
|  | Three Months Ended |  | Twelve Months Ended |
|  | July 3, 2021 |  | April 3, 2021 |  | June 27, 2020 |  | July 3, 2021 |  | June 27, 2020 |
| GAAP net income (loss) | $ | 21.5 |  |  | $ | 225.5 |  |  | $ | (4.6) |  |  | $ | 397.3 |  |  | $ | 135.5 |  |
| Interest and other expense (income), net | 17.3 |  |  | 14.0 |  |  | 12.4 |  |  | 63.9 |  |  | 29.8 |  |
| Provision for income taxes | 7.0 |  |  | 27.4 |  |  | 19.2 |  |  | 65.8 |  |  | 38.8 |  |
| Depreciation | 21.0 |  |  | 22.8 |  |  | 25.5 |  |  | 91.4 |  |  | 113.3 |  |
| Amortization of acquired intangibles | 22.1 |  |  | 22.0 |  |  | 21.2 |  |  | 85.7 |  |  | 78.6 |  |
| EBITDA | 88.9 |  |  | 311.7 |  |  | 73.7 |  |  | 704.1 |  |  | 396.0 |  |
| Amortization of inventory fair value adjustments | — |  |  | — |  |  | — |  |  | — |  |  | 5.8 |  |
| Restructuring and related charges | 4.6 |  |  | 2.9 |  |  | 3.1 |  |  | 7.7 |  |  | 8.0 |  |
| Stock-based compensation | 24.2 |  |  | 25.1 |  |  | 17.1 |  |  | 92.9 |  |  | 73.2 |  |
| Inventory and fixed asset write down due to product line exits | — |  |  | — |  |  | 1.0 |  |  | 0.4 |  |  | 7.0 |  |
| Integration related costs | — |  |  | 0.2 |  |  | 2.9 |  |  | 0.7 |  |  | 17.1 |  |
| Merger termination fee and related costs, net | — |  |  | (207.5) |  |  | — |  |  | (207.5) |  |  | — |  |
| Impairment charges | — |  |  | — |  |  | 1.8 |  |  | — |  |  | 4.3 |  |
| Expenses related to COVID-19 outbreak | — |  |  | — |  |  | 5.5 |  |  | — |  |  | 7.1 |  |
| Other (gains) and charges | (0.2) |  |  | 5.9 |  |  | 10.0 |  |  | 22.7 |  |  | 32.6 |  |
| Adjusted EBITDA | $ | 117.5 |  |  | $ | 138.3 |  |  | $ | 115.1 |  |  | $ | 621.0 |  |  | $ | 551.1 |  |
