# LITE MD&A — 0001628280-16-010773


## mdna

[0001628280-16-010773:mdna:1]
[same as prior period, unchanged from 0001564590-15-010839:mdna:1]

[0001628280-16-010773:mdna:2]
[same as prior period, unchanged from 0001564590-15-010839:mdna:2]

[0001628280-16-010773:mdna:3]
| • | our expectations regarding demand for our products, including continued trends in end-user behavior and technological advancements that may drive such demand; |

[0001628280-16-010773:mdna:4]
| • | our belief that we are well positioned to benefit from certain industry trends and advancements, and our expectations of the role we will play in those advancements; |

[0001628280-16-010773:mdna:5]
| • | our plans for growth and innovation opportunities; |

[0001628280-16-010773:mdna:6]
| • | our corporate and financial reporting structure; |

[0001628280-16-010773:mdna:7]
| • | expectations regarding our expenses and cost structure; |

[0001628280-16-010773:mdna:8]
| • | financial projections and expectations, including profitability of certain business units, plans to reduce costs and improve efficiencies, the effects of seasonality on certain business units, continued reliance on key customers for a significant portion of our revenue, future sources of revenue, competition and pricing pressures, future revenue from international customers, our future liquidity and cash flow requirements, the future impact of certain accounting pronouncements and our estimation of the potential impact and materiality of litigation; |

[0001628280-16-010773:mdna:9]
| • | our expectations related to our net revenue mix, including net revenue growth opportunities; |

[0001628280-16-010773:mdna:10]
| • | our plans for continued development, use and protection of our intellectual property; |

[0001628280-16-010773:mdna:11]
| • | our strategies for achieving our current business objectives, including related risks and uncertainties; |

[0001628280-16-010773:mdna:12]
| • | our plans or expectations relating to investments, acquisitions, partnerships and other strategic opportunities; |

[0001628280-16-010773:mdna:13]
| • | our research and development plans and the expected impact of such plans on our financial performance; |

[0001628280-16-010773:mdna:14]
| • | our expectations related to our products, including costs associated with the development of new products, product yields, quality and other issues; and |

[0001628280-16-010773:mdna:15]
| • | market risks facing our business and our market-risk management strategies. |

[0001628280-16-010773:mdna:16]
[same as prior period, unchanged from 0001564590-15-010839:mdna:16]

[0001628280-16-010773:mdna:17]
[same as prior period, unchanged from 0001564590-15-010839:mdna:17]

[0001628280-16-010773:mdna:18]
[same as prior period, unchanged from 0001564590-15-010839:mdna:18]

[0001628280-16-010773:mdna:19]
On July 31, 2015, prior to the Separation, Viavi transferred substantially all of the assets and liabilities and operations of the communications and commercial optical products (“CCOP”) segment and WaveReady product lines to Lumentum (the “Capitalization”). Combined financial statements for periods prior to the Capitalization were prepared on a stand-alone basis and were derived from Viavi’s consolidated financial statements and accounting records. For the period from June 28, 2015 to August 1, 2015, expenses were allocated to us using estimates that we consider to be a reasonable reflection of the utilization of services provided to or benefits received by us.

[0001628280-16-010773:mdna:20]
[same as prior period, unchanged from 0001564590-15-010839:mdna:20]

[0001628280-16-010773:mdna:21]
[same as prior period, unchanged from 0001564590-15-010839:mdna:21]

[0001628280-16-010773:mdna:22]
[same as prior period, unchanged from 0001564590-15-010839:mdna:22]

[0001628280-16-010773:mdna:23]
We are an industry leading provider of optical and photonic products defined by revenue and market share addressing a range of end-market applications including Datacom and Telecom networking and commercial lasers for manufacturing, inspection and life-science applications. We are using our core optical and photonic technology and our volume manufacturing capability to expand into attractive emerging markets that benefit from advantages that optical or photonics-based solutions provide, including 3-D sensing for consumer electronics and diode light sources for a variety of consumer and industrial applications.

[0001628280-16-010773:mdna:24]
[same as prior period, unchanged from 0001564590-15-010839:mdna:24]

[0001628280-16-010773:mdna:25]
•Optical Communications (“OpComms”)

[0001628280-16-010773:mdna:26]
•Commercial Lasers (“Lasers”)

[0001628280-16-010773:mdna:27]
[same as prior period, unchanged from 0001564590-15-010839:mdna:27]

[0001628280-16-010773:mdna:28]
[same as prior period, unchanged from 0001564590-15-010839:mdna:28]

[0001628280-16-010773:mdna:29]
[same as prior period, unchanged from 0001564590-15-010839:mdna:29]

[0001628280-16-010773:mdna:30]
Our OpComms products include a wide range of components, modules and subsystems to support and maintain customers in our two primary markets: Telecom and Datacom. The Telecom market includes carrier networks for access (local), metro (intracity), long-haul (city-to-city and worldwide) and submarine (undersea) networks. The Datacom market addresses enterprise, cloud and data center applications, including storage-access networks (“SANs”), local-area networks (“LANs”) and Ethernet wide-area networks (“WANs”). These products enable the transmission and transport of video, audio and text data over high-capacity

[0001628280-16-010773:mdna:31]
fiber-optic cables. We maintain leading positions in the fastest-growing OpComms markets, including reconfigurable optical add/drop multiplexers (“ROADMs”), tunable 10-gigabit small form-factor pluggable transceivers and tunable small form-factor pluggables. Our growing portfolio of pluggable transceivers supports LAN/SAN needs and the cloud for customers building proprietary data center networks.

[0001628280-16-010773:mdna:32]
[same as prior period, unchanged from 0001564590-15-010839:mdna:31]

[0001628280-16-010773:mdna:33]
Our OpComms customers include Ciena Corporation, Cisco Systems, Inc., Coriant GmbH, Fujitsu Network Communications, Inc., Google Inc., Huawei Technologies Co Ltd., Microsoft Corporation, and Nokia Corporation.

[0001628280-16-010773:mdna:34]
[same as prior period, unchanged from 0001564590-15-010839:mdna:33]

[0001628280-16-010773:mdna:35]
[same as prior period, unchanged from 0001564590-15-010839:mdna:34]

[0001628280-16-010773:mdna:36]
[same as prior period, unchanged from 0001564590-15-010839:mdna:35]

[0001628280-16-010773:mdna:37]
[same as prior period, unchanged from 0001564590-15-010839:mdna:36]

[0001628280-16-010773:mdna:38]
[same as prior period, unchanged from 0001564590-15-010839:mdna:37]

[0001628280-16-010773:mdna:39]
[same as prior period, unchanged from 0001564590-15-010839:mdna:38]

[0001628280-16-010773:mdna:40]
In the opinion of Management, the consolidated financial statements included in this Form 10-Q contain all normal recurring adjustments necessary to state fairly our consolidated balance sheet as of December 26, 2015, our consolidated statements of operations and consolidated statements of comprehensive income (loss) for the three and six months ended December 26, 2015 and December 27, 2014, and our consolidated statements of cash flows for the six months ended December 26, 2015 and December 27, 2014.

[0001628280-16-010773:mdna:41]
[same as prior period, unchanged from 0001564590-15-010839:mdna:40]

[0001628280-16-010773:mdna:42]
For a description of the critical accounting policies that affect our more significant judgments and estimates used in the preparation of our consolidated financial statements, refer to Item 7 "Management’s Discussion and Analysis of Financial Condition and Results of Operations" in our Amendment No. 1 to Fiscal 2015 Annual Report on Form 10-K/A filed with the Securities and Exchange Commission (“SEC”) and “Note 1. Description of Business and Summary of Significant Accounting Policies” to the consolidated financial statements included in this Form 10-Q.

[0001628280-16-010773:mdna:43]
Recently Issued Accounting Pronouncements

[0001628280-16-010773:mdna:44]
Refer to “Note 2. Recently Issued Accounting Pronouncements" to the consolidated financial statements included in this Form 10-Q regarding the effect of certain recent accounting pronouncements on our consolidated financial statements.

[0001628280-16-010773:mdna:45]
[same as prior period, unchanged from 0001564590-15-010839:mdna:44]

[0001628280-16-010773:mdna:46]
[same as prior period, unchanged from 0001564590-15-010839:mdna:45]

[0001628280-16-010773:mdna:47]
|  | Three Months Ended |  | Six Months Ended |
|  | December 26, 2015 |  | December 27, 2014 |  | December 26, 2015 |  | December 27, 2014 |
| Segment net revenue: |  |  |  |  |  |  |  |
| OpComms | 85.1 | % |  | 81.3 | % |  | 84.2 | % |  | 81.0 | % |
| Lasers | 14.9 |  |  | 18.7 |  |  | 15.8 |  |  | 19.0 |  |
| Net revenue | 100.0 |  |  | 100.0 |  |  | 100.0 |  |  | 100.0 |  |
| Cost of sales | 68.0 |  |  | 67.3 |  |  | 67.9 |  |  | 67.2 |  |
| Amortization of acquired technologies | 0.8 |  |  | 0.9 |  |  | 0.8 |  |  | 0.9 |  |
| Gross profit | 31.2 |  |  | 31.8 |  |  | 31.3 |  |  | 31.9 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 16.1 |  |  | 16.7 |  |  | 16.1 |  |  | 16.3 |  |
| Selling, general and administrative | 11.8 |  |  | 14.8 |  |  | 13.9 |  |  | 13.9 |  |
| Restructuring and related charges | 0.5 |  |  | 1.8 |  |  | 0.5 |  |  | 1.3 |  |
| Total operating expenses | 28.4 |  |  | 33.3 |  |  | 30.5 |  |  | 31.5 |  |
| Income (loss) from operations | 2.8 |  |  | (1.5 | ) |  | 0.9 |  |  | 0.5 |  |
| Unrealized loss on derivative liability | (1.1 | ) |  | — |  |  | — |  |  | — |  |
| Interest and other (expense) income, net | (0.2 | ) |  | — |  |  | (0.2 | ) |  | (0.1 | ) |
| Income (loss) before taxes | 1.5 |  |  | (1.6 | ) |  | 0.6 |  |  | 0.4 |  |
| Provision for income taxes | 0.2 |  |  | 0.4 |  |  | — |  |  | 0.3 |  |
| Net income (loss) | 1.3 | % |  | (1.9 | )% |  | 0.6 | % |  | 0.0 | % |

[0001628280-16-010773:mdna:48]
25

[0001628280-16-010773:mdna:49]
Financial Data for the three and six months ended December 26, 2015 and December 27, 2014

[0001628280-16-010773:mdna:50]
[same as prior period, unchanged from 0001564590-15-010839:mdna:49]

[0001628280-16-010773:mdna:51]
|  | Three Months Ended |  |  |  |  |  | Six Months Ended |  |  |  |  |
|  | December 26, 2015 |  | December 27, 2014 |  | Change |  | Percentage Change |  | December 26, 2015 |  | December 27, 2014 |  | Change |  | Percentage Change |
| Segment net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| OpComms | $ | 185.8 |  |  | $ | 171.1 |  |  | $ | 14.7 |  |  | 8.6 | % |  | $ | 362.9 |  |  | $ | 348.0 |  |  | $ | 14.9 |  |  | 4.3 | % |
| Lasers | 32.5 |  |  | 39.4 |  |  | (6.9 | ) |  | (17.5 | )% |  | 68.0 |  |  | 81.5 |  |  | (13.5 | ) |  | (16.6 | ) |
| Net revenue | $ | 218.3 |  |  | $ | 210.5 |  |  | $ | 7.8 |  |  | 3.7 | % |  | $ | 430.9 |  |  | $ | 429.5 |  |  | $ | 1.4 |  |  | 0.3 | % |
| Gross profit | $ | 68.1 |  |  | $ | 66.9 |  |  | $ | 1.2 |  |  | 1.8 | % |  | $ | 135.0 |  |  | $ | 137.2 |  |  | $ | (2.2 | ) |  | (1.6 | )% |
| Gross margin | 31.2 | % |  | 31.8 | % |  |  |  |  |  | 31.3 | % |  | 31.9 | % |  |  |  |  |
| Research and development | 35.0 |  |  | 35.1 |  |  | (0.1 | ) |  | (0.3 | )% |  | 69.4 |  |  | 70.1 |  |  | (0.7 | ) |  | (1.0 | )% |
| Percentage of net revenue | 16.0 | % |  | 16.7 | % |  |  |  |  |  | 16.1 | % |  | 16.3 | % |  |  |  |  |
| Selling, general and administrative | 25.8 |  |  | 31.2 |  |  | (5.4 | ) |  | (17.3 | )% |  | 59.8 |  |  | 59.5 |  |  | 0.3 |  |  | 0.5 | % |
| Percentage of net revenue | 11.8 | % |  | 14.8 | % |  |  |  |  |  | 13.9 | % |  | 13.9 | % |  |  |  |  |
| Restructuring and related charges | 1.1 |  |  | 3.8 |  |  | (2.7 | ) |  | (71.1 | )% |  | 2.1 |  |  | 5.6 |  |  | (3.5 | ) |  | (62.5 | )% |
| Percentage of net revenue | 0.5 | % |  | 1.8 | % |  |  |  |  |  | 0.5 | % |  | 1.3 | % |  |  |  |  |

[0001628280-16-010773:mdna:52]
[same as prior period, unchanged from 0001564590-15-010839:mdna:51]

[0001628280-16-010773:mdna:53]
Net revenue increased by $7.8 million, or 3.7%, during the three months ended December 26, 2015 compared to the same period a year ago. This increase was primarily due to an increase in net revenue from our OpComms segment, partially offset by a decrease in net revenue from our Lasers segment.

[0001628280-16-010773:mdna:54]
OpComms net revenue increased $14.7 million, or 8.6%, during the three months ended December 26, 2015 compared to the same period a year ago. This increase was primarily driven by $15.0 million of net revenue increases resulting primarily from increased sales of Transport and 3D Sensing products for the telecom and Consumer and Industrial end markets.

[0001628280-16-010773:mdna:55]
Lasers net revenue decreased $6.9 million, or 17.5%, during the three months ended December 26, 2015 compared to the same period a year ago. This decrease was primarily due to lower revenue from our fiber laser products.

[0001628280-16-010773:mdna:56]
Net revenue increased by $1.4 million, or 0.3%, during the six months ended December 26, 2015 compared to the same period a year ago. This increase was primarily due to an increase in net revenue from our OpComms segment, partially offset by a decrease in net revenue from our Lasers segment.

[0001628280-16-010773:mdna:57]
OpComms net revenue increased $14.9 million, or 4.3%, during the six months ended December 26, 2015 compared to the same period a year ago. This increase was driven by $14.4 million of net revenue increases resulting primarily from increased sales of products for the telecom and datacom end markets.

[0001628280-16-010773:mdna:58]
Lasers net revenue decreased $13.5 million, or 16.6%, during the six months ended December 26, 2015 compared to the same period a year ago. This decrease was primarily due to decreased revenue from solid-state lasers driven by lower market demand.

[0001628280-16-010773:mdna:59]
[same as prior period, unchanged from 0001564590-15-010839:mdna:55]

[0001628280-16-010773:mdna:60]
[same as prior period, unchanged from 0001564590-15-010839:mdna:56]

[0001628280-16-010773:mdna:61]
|  | Three Months Ended |  | Six Months Ended |
|  | December 26, 2015 |  | December 27, 2014 |  | December 26, 2015 |  | December 27, 2014 |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States | $ | 28.0 |  |  | 12.8 | % |  | $ | 41.1 |  |  | 19.5 | % |  | $ | 62.5 |  |  | 14.5 | % |  | $ | 83.5 |  |  | 19.4 | % |
| Mexico | 36.5 |  |  | 16.7 |  |  | 23.6 |  |  | 11.2 |  |  | 78.3 |  |  | 18.2 |  |  | 50.1 |  |  | 11.7 |  |
| Other Americas | 5.0 |  |  | 2.3 |  |  | 7.5 |  |  | 3.6 |  |  | 12.8 |  |  | 3.0 |  |  | 13.8 |  |  | 3.2 |  |
| Total Americas | $ | 69.5 |  |  | 31.8 | % |  | $ | 72.2 |  |  | 34.3 | % |  | $ | 153.6 |  |  | 35.7 | % |  | $ | 147.4 |  |  | 34.3 | % |
| Asia-Pacific: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Hong Kong | $ | 51.8 |  |  | 23.8 | % |  | $ | 34.0 |  |  | 16.1 | % |  | $ | 82.6 |  |  | 19.1 | % |  | $ | 62.7 |  |  | 14.6 | % |
| Japan | 21.0 |  |  | 9.6 |  |  | 34.9 |  |  | 16.6 |  |  | 46.0 |  |  | 10.7 |  |  | 70.8 |  |  | 16.5 |  |
| Thailand | 25.5 |  |  | 11.7 |  |  | 14.7 |  |  | 7.0 |  |  | 44.0 |  |  | 10.2 |  |  | 29.7 |  |  | 6.9 |  |
| Other Asia-Pacific | 20.8 |  |  | 9.5 |  |  | 23.9 |  |  | 11.4 |  |  | 42.3 |  |  | 9.8 |  |  | 50.0 |  |  | 11.7 |  |
| Total Asia-Pacific | $ | 119.1 |  |  | 54.6 | % |  | $ | 107.5 |  |  | 51.1 | % |  | $ | 214.9 |  |  | 49.8 | % |  | $ | 213.2 |  |  | 49.7 | % |
| EMEA | $ | 29.7 |  |  | 13.6 | % |  | $ | 30.8 |  |  | 14.6 | % |  | $ | 62.4 |  |  | 14.5 | % |  | $ | 68.9 |  |  | 16.0 | % |
| Total net revenue | $ | 218.3 |  |  |  |  | $ | 210.5 |  |  |  |  | $ | 430.9 |  |  |  |  | $ | 429.5 |  |  |  |

[0001628280-16-010773:mdna:62]
Net revenue from customers outside the United States, based on customer shipping location, during the three months ended December 26, 2015 and December 27, 2014, represented 87.2% and 80.5% of net revenue, respectively. Net revenue from customers outside the United States, based on customer shipping location, during the six months ended  December 26, 2015 and December 27, 2014, represented 85.5% and 80.6% of net revenue, respectively. Our net revenue is primarily denominated in U.S. dollars, including our net revenue from customers outside the United States as presented above. We expect revenue from customers outside of the United States to continue to be an important part of our overall net revenue and an increasing focus for net revenue growth opportunities.

[0001628280-16-010773:mdna:63]
[same as prior period, unchanged from 0001564590-15-010839:mdna:59]

[0001628280-16-010773:mdna:64]
The following table summarizes segment gross margin and combined gross margin for the three and six months ended December 26, 2015 and December 27, 2014 (in millions, except for percentages):

[0001628280-16-010773:mdna:65]
|  | Gross Profit |  | Gross Margin |  | Gross Profit |  | Gross Margin |
|  | Three Months Ended |  | Three Months Ended |  | Six Months Ended |  | Six Months Ended |
|  | December 26, 2015 |  | December 27, 2014 |  | December 26, 2015 |  | December 27, 2014 |  | December 26, 2015 |  | December 27, 2014 |  | December 26, 2015 |  | December 27, 2014 |
| OpComms | $ | 57.1 |  |  | $ | 50.4 |  |  | 30.7 | % |  | 29.5 | % |  | $ | 112.7 |  |  | $ | 103.2 |  |  | 31.1 | % |  | 29.7 | % |
| Lasers | 14.2 |  |  | 20.1 |  |  | 43.7 | % |  | 51.0 | % |  | 28.4 |  |  | 41.4 |  |  | 41.8 | % |  | 50.8 | % |
| Segment total | $ | 71.3 |  |  | $ | 70.5 |  |  | 32.7 | % |  | 33.5 | % |  | $ | 141.1 |  |  | $ | 144.6 |  |  | 32.7 | % |  | 33.7 | % |
| Unallocated corporate items (1) | (3.2 | ) |  | (3.6 | ) |  |  |  |  |  | (6.1 | ) |  | (7.4 | ) |  |  |  |  |
| Total | $ | 68.1 |  |  | $ | 66.9 |  |  | 31.2 | % |  | 31.8 | % |  | $ | 135.0 |  |  | $ | 137.2 |  |  | 31.3 | % |  | 31.9 | % |

[0001628280-16-010773:mdna:66]
| (1) | The unallocated corporate items for the periods presented include the effects of amortization of acquired developed technology, intangible assets, share-based compensation and certain other charges related to non-recurring activities. We do not allocate these items to the gross margin for each segment because Management does not include such information in measuring the performance of the operating segments. |

[0001628280-16-010773:mdna:67]
[same as prior period, unchanged from 0001564590-15-010839:mdna:64]

[0001628280-16-010773:mdna:68]
Gross margin decreased 0.6 percentage points from 31.8% in the same period a year ago to 31.2% in the three months ended

[0001628280-16-010773:mdna:69]
27

[0001628280-16-010773:mdna:70]
December 26, 2015. This decrease was primarily due to decreases in Lasers gross margins, partially offset by an increase in OpComms gross margins.

[0001628280-16-010773:mdna:71]
Gross margin decreased 0.6 percentage points from 31.9% in the same period a year ago to 31.3% in the six months ended December 26, 2015. This decrease was primarily due to decreases in Lasers gross margins, partially offset by an increase in OpComms gross margins.

[0001628280-16-010773:mdna:72]
[same as prior period, unchanged from 0001564590-15-010839:mdna:66]

[0001628280-16-010773:mdna:73]
[same as prior period, unchanged from 0001564590-15-010839:mdna:67]

[0001628280-16-010773:mdna:74]
[same as prior period, unchanged from 0001564590-15-010839:mdna:68]

[0001628280-16-010773:mdna:75]
OpComms gross margin increased 1.2 percentage points to 30.7% in the three months ended December 26, 2015 from 29.5% in the same period a year ago. This increase was primarily due to cost reductions and higher volume leading to better absorption.

[0001628280-16-010773:mdna:76]
OpComms gross margin increased 1.4 percentage points to 31.1% in the six months ended December 26, 2015 from 29.7% in the same period a year ago. This increase was primarily due to improved manufacturing cost absorption from higher volume and cost reductions.

[0001628280-16-010773:mdna:77]
[same as prior period, unchanged from 0001564590-15-010839:mdna:70]

[0001628280-16-010773:mdna:78]
Lasers gross margin decreased 7.3 percentage points to 43.7% in the three months ended December 26, 2015 from 51.0% in the same period a year ago. This decrease was primarily due to product mix and lower revenue volume.

[0001628280-16-010773:mdna:79]
Lasers gross margin decreased 9.0 percentage points to 41.8% in the six months ended December 26, 2015 from 50.8% in the same period a year ago. This decrease was primarily due to product mix and lower revenue volume.

[0001628280-16-010773:mdna:80]
[same as prior period, unchanged from 0001564590-15-010839:mdna:72]

[0001628280-16-010773:mdna:81]
R&D expense decreased $0.1 million, or 0.3%, for the three months ended December 26, 2015 compared to the same period a year ago. The decrease was primarily due to a decrease in employee-related costs resulting from the lower headcount from the closure of the Serangoon office in Singapore and a reduction of employees in North America.

[0001628280-16-010773:mdna:82]
R&D expense decreased $0.7 million, or 1.0%, for the six months ended December 26, 2015 compared to the same period a year ago. The decrease was primarily due to a decrease in employee-related costs resulting from the lower headcount from the closure of the Serangoon office in Singapore and a reduction of employees in North America.

[0001628280-16-010773:mdna:83]
[same as prior period, unchanged from 0001564590-15-010839:mdna:74]

[0001628280-16-010773:mdna:84]
[same as prior period, unchanged from 0001564590-15-010839:mdna:75]

[0001628280-16-010773:mdna:85]
SG&A expense decreased by $5.4 million, or 17.3%, in the three months ended December 26, 2015 compared to the same period a year ago. This decrease was primarily due to our stand-alone SG&A expense during the three months ended December 26, 2015 being lower than Viavi's SG&A allocation for the three months ended December 27, 2014.

[0001628280-16-010773:mdna:86]
SG&A expense increased by $0.3 million, or 0.5%, in the six months ended December 26, 2015 compared to the same period  a year ago. This increase was primarily due to separation-related costs allocated to us from Viavi that were only present in the six months ended December 26, 2015.

[0001628280-16-010773:mdna:87]
We intend to continue to focus on reducing our SG&A expenses as a percentage of net revenue. However, we may experience certain non-core expenses in the future, such as mergers and acquisitions-related expenses and litigation expenses, which could increase our SG&A expenses and potentially impact our profitability expectations in any particular quarter.

[0001628280-16-010773:mdna:88]
[same as prior period, unchanged from 0001564590-15-010839:mdna:78]

[0001628280-16-010773:mdna:89]
[same as prior period, unchanged from 0001564590-15-010839:mdna:79]

[0001628280-16-010773:mdna:90]
As of December 26, 2015, our total restructuring accrual was $4.3 million. During the three and six months ended December 26, 2015, we recorded $1.1 million and $2.1 million, respectively, in restructuring charges. These charges are primarily due to a previously announced restructuring plan for our Bloomfield, Connecticut site for severance and benefits. Refer to “Note 10. Restructuring and Related Charges” to the consolidated financial statements included in this Form 10-Q for more information.

[0001628280-16-010773:mdna:91]
During the three and six months ended December 27, 2014, we recorded $3.8 million and $5.6 million, respectively, in restructuring and related charges. The charges are primarily due to the allocated costs of restructuring and related charges related to Viavi's corporate and shared services employees and the severance and benefit costs for Robbinsville Closure Plan approved in the first quarter of fiscal 2015.

[0001628280-16-010773:mdna:92]
Our Ottawa lease obligation is net of sublease income of approximately $0.8 million. Our ability to generate sublease income, as well as our ability to terminate lease obligations and recognize the anticipated related savings, is highly dependent upon economic conditions, particularly commercial real estate market conditions in certain geographies, at the time we negotiate the lease termination and sublease arrangements with third parties, as well as the performances by such third parties of their respective obligations. While the amount we have accrued represents the best estimate of the remaining obligations we expect to incur in connection with these plans, estimates are subject to change. Routine adjustments may be required in the future as conditions and facts change through the implementation period. If macroeconomic conditions decline, particularly as they pertain to the commercial real estate market, or if, for any reason, tenants under subleases fail to perform their obligations, we may be required to reduce estimated future sublease income and adjust the estimated amounts of future settlement agreements, and accordingly, increase estimated costs to exit certain facilities. Amounts related to the lease expense, net of anticipated sublease proceeds, will be paid over the respective lease terms through the third quarter of fiscal 2018.

[0001628280-16-010773:mdna:93]
Unrealized Loss on Derivative Liability

[0001628280-16-010773:mdna:94]
The Series A Preferred Stock includes a conversion feature that was bifurcated and separately accounted for as a derivative liability measured at fair value upon inception with subsequent changes in fair value recognized in earnings. The proceeds from issuance was allocated first to the separated conversion feature based on its fair value, with the residual proceeds allocated to the Series A Preferred Stock. The unrealized loss on derivative liability relates to the subsequent changes in the fair value of the derivative liability. During the three and six months ended December 26, 2015, the unrealized loss was $2.4 million and $0.2 million, respectively, and is reflected in our consolidated statements of operations.

[0001628280-16-010773:mdna:95]
[same as prior period, unchanged from 0001564590-15-010839:mdna:85]

[0001628280-16-010773:mdna:96]
[same as prior period, unchanged from 0001564590-15-010839:mdna:86]

[0001628280-16-010773:mdna:97]
Interest and other income (expense), net was $(0.5) million during the three months ended December 26, 2015 as compared to $(0.1) million during the same period a year ago.

[0001628280-16-010773:mdna:98]
Interest and other income (expense), net was $(0.7) million during the six months ended December 26, 2015 as compared to $(0.4) million during the same period a year ago.

[0001628280-16-010773:mdna:99]
Provision for Income Taxes

[0001628280-16-010773:mdna:100]
We recorded a tax provision of $0.5 million and $0.2 million for the three and six months ended December 26, 2015, and $0.8 million and $1.4 million for the three and six months ended December 27, 2014.  The quarterly provision for income taxes is based on the estimated annual effective tax rate, plus any discrete items for the respective year. During the three months ended September 26, 2015, we recognized a net benefit of $0.3 million of true-up adjustments in our foreign jurisdictions.

[0001628280-16-010773:mdna:101]
The difference between the provision for income taxes that would be derived by applying the statutory rate to our income (loss) before income taxes and the provision for income taxes recorded was primarily attributable to the difference in foreign tax rates, utilization of US tax attributes that were subject to a full valuation allowance, and certain Canadian tax incentives.

[0001628280-16-010773:mdna:102]
[same as prior period, unchanged from 0001564590-15-010839:mdna:91]

[0001628280-16-010773:mdna:103]
The following table summarizes our contractual obligations at December 26, 2015, and the effect such obligations are expected to have on our liquidity and cash flow over the next five years (in millions):

[0001628280-16-010773:mdna:104]
|  | Payments due by period |
|  | Total |  | Less than 1 year |  | 1 - 3 years |  | 3 - 5 years |  | More than 5 years |
| Contractual Obligations |  |  |  |  |  |  |  |  |  |
| Asset retirement obligations—expected cash payments | $ | 2.3 |  |  | $ | 0.2 |  |  | $ | 0.6 |  |  | $ | 0.3 |  |  | $ | 1.2 |  |
| Purchase obligations (1) | 145.5 |  |  | 130.3 |  |  | 13.8 |  |  | 1.4 |  |  | — |  |
| Operating lease obligations (1) | 23.0 |  |  | 2.9 |  |  | 10.2 |  |  | 4.9 |  |  | 5.0 |  |
| Pension and post-retirement benefit payments | 2.6 |  |  | — |  |  | 0.1 |  |  | 0.1 |  |  | 2.4 |  |
| Total | $ | 173.4 |  |  | $ | 133.4 |  |  | $ | 24.7 |  |  | $ | 6.7 |  |  | $ | 8.6 |  |

[0001628280-16-010773:mdna:105]
(1) Refer to “Note 13. Commitments and Contingencies” to the consolidated financial statements included in this Form 10-Q for more information.

[0001628280-16-010773:mdna:106]
As of December 26, 2015, other current liabilities and other non-current liabilities on the consolidated balance sheets includes $0.5 million and $0.3 million, respectively, for restructuring and related activities in connection with our operating lease obligations disclosed above.

[0001628280-16-010773:mdna:107]
Purchase obligations represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Of the $145.5 million of purchase obligations as of December 26, 2015, $57.7 million are related to inventory and the other $87.8 million are non-inventory items of which $8.7 million is committed to Viavi.

[0001628280-16-010773:mdna:108]
As of December 26, 2015, our other non-current liabilities primarily relate to asset retirement obligations and pension which are presented in various lines in the preceding table.

[0001628280-16-010773:mdna:109]
[same as prior period, unchanged from 0001564590-15-010839:mdna:98]

[0001628280-16-010773:mdna:110]
[same as prior period, unchanged from 0001564590-15-010839:mdna:99]

[0001628280-16-010773:mdna:111]
[same as prior period, unchanged from 0001564590-15-010839:mdna:100]

[0001628280-16-010773:mdna:112]
[same as prior period, unchanged from 0001564590-15-010839:mdna:101]

[0001628280-16-010773:mdna:113]
As of December 26, 2015 and June 27, 2015, our cash and cash equivalents of $161.9 million and $14.5 million, respectively, were held predominantly in the United States, Cayman Islands, Canada, China and Japan. Although the cash generated in the United States from future operations is expected to cover our normal operating requirements, a substantial amount of additional cash could be required for other purposes, such as dividends that may be declared, future stock repurchase programs or acquisitions. Our intent is to indefinitely reinvest these funds outside the United States and our current plans do not demonstrate a need to repatriate them to fund our domestic operations. However, if in the future, we encounter a significant need for liquidity domestically or at a particular location that we cannot fulfill through borrowings, equity offerings, or other internal or external sources, we may determine that cash repatriations are necessary. Repatriation could result in additional material U.S. federal and state income tax payments in future years. Such adverse consequences would occur, for example, if the transfer of cash into the United States is taxed and no foreign tax credit is available to offset the U.S. tax liability, resulting in higher taxes. These factors may cause us to have an overall tax rate higher than other companies or higher than our tax rates have been in the past.

[0001628280-16-010773:mdna:114]
As of December 26, 2015, our consolidated balance of cash and cash equivalents increased by $147.4 million, to $161.9 million from $14.5 million as of June 27, 2015. The increase in cash and cash equivalents was a result of the initial capitalization from Viavi and cash generated from operations.

[0001628280-16-010773:mdna:115]
[same as prior period, unchanged from 0001564590-15-010839:mdna:104]

[0001628280-16-010773:mdna:116]
Cash provided by operating activities was $53.0 million during the six months ended December 26, 2015, primarily resulting from $2.6 million of net income and $40.4 million of non-cash items such as depreciation, stock-based compensation, amortization of intangibles and unrealized loss on derivative liability, and changes in operating assets and liabilities of $10.0 million. Changes in our operating assets and liabilities related primarily to an increase in accounts payable of $18.2 million, an increase in accrued payroll and related expenses of $13.6 million, an increase  in accrued expenses and other current and non-current liabilities of $3.3 million, an increase in accounts receivable of $11.1 million, an increase in inventories of $9.7 million, and an increase in other current and non-current assets of $5.2 million.

[0001628280-16-010773:mdna:117]
Cash provided by operating activities was $16.0 million during the six months ended December 27, 2014, primarily resulting from $0.2 million of net income and $34.3 million of non-cash items such as depreciation, stock-based compensation, and amortization of intangibles, offset by changes in operating assets and liabilities of $18.5 million. Changes in our operating assets and liabilities related primarily to an increase in accounts receivable of $16.9 million, an increase in other current and non-currents assets of $7.9 million, a decrease in accrued expenses and other current and non-current liabilities of $1.3 million, an increase in inventories of $1.0 million, an increase in accrued payroll and related expenses of $3.7 million, an increase in accounts payable of $3.0 million, and an increase in deferred taxes of $2.2 million.

[0001628280-16-010773:mdna:118]
[same as prior period, unchanged from 0001564590-15-010839:mdna:107]

[0001628280-16-010773:mdna:119]
Cash used in investing activities was for capital expenditures of $35.7 million and $24.7 million during the six months ended December 26, 2015 and December 27, 2014, respectively.

[0001628280-16-010773:mdna:120]
[same as prior period, unchanged from 0001564590-15-010839:mdna:109]

[0001628280-16-010773:mdna:121]
Cash provided by financing activities was $130.1 million during the six months ended December 26, 2015 resulting primarily from net transfers from Viavi.

[0001628280-16-010773:mdna:122]
Cash provided by financing activities was $9.8 million during the six months ended December 27, 2014 resulting primarily from net transfers from Viavi.

[0001628280-16-010773:mdna:123]
[same as prior period, unchanged from 0001564590-15-010839:mdna:112]

[0001628280-16-010773:mdna:124]
We believe that the cash on hand of $161.9 million as of December 26, 2015, combined with expected cash flows from our operating activities, will be sufficient to meet our liquidity and capital spending requirements for at least the next 12 months. However, there are a number of factors that could positively or negatively impact our liquidity position, including:

[0001628280-16-010773:mdna:125]
| • | global economic conditions which affect demand for our products and services and impact the financial stability of our suppliers and customers; |

[0001628280-16-010773:mdna:126]
| • | changes in accounts receivable, inventory or other operating assets and liabilities which affect our working capital; |

[0001628280-16-010773:mdna:127]
| • | increase in capital expenditures to support the revenue growth opportunity of our business; |

[0001628280-16-010773:mdna:128]
| • | the tendency of customers to delay payments or to negotiate favorable payment terms to manage their own liquidity positions; |

[0001628280-16-010773:mdna:129]
| • | timing of payments to our suppliers; |

[0001628280-16-010773:mdna:130]
| • | factoring or sale of accounts receivable; |

[0001628280-16-010773:mdna:131]
| • | volatility in fixed income and credit which impact the liquidity and valuation of our investment portfolios; |

[0001628280-16-010773:mdna:132]
| • | volatility in foreign exchange markets which impacts our financial results; |

[0001628280-16-010773:mdna:133]
| • | possible investments or acquisitions of complementary businesses, products or technologies; |

[0001628280-16-010773:mdna:134]
| • | issuance of debt or equity securities; and |

[0001628280-16-010773:mdna:135]
| • | potential funding of pension liabilities either voluntarily or as required by law or regulation. |
