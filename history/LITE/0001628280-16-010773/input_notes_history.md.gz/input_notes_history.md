# LITE note change history — 0001564590-15-010839 → 0001628280-16-010773


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: title_similarity, score: 1.0

- changed (2016-02-04):
[0001628280-16-010773:note_history:1]
We lease certain real and personal property from unrelated third parties under non-cancellable operating leases that expire at various dates through fiscal 2026. Certain leases require us to pay property taxes, insurance and routine maintenance, and include escalation clauses. As of December 26, 2015 the future minimum annual lease payments under non-cancellable operating leases were as follows (in millions):
  (was, 2015-11-17, similarity 0.9913):
[0001564590-15-010839:note_history:1]
We lease certain real and personal property from unrelated third parties under non-cancellable operating leases that expire at various dates through fiscal 2026. Certain leases require us to pay property taxes, insurance and routine maintenance, and include escalation clauses. As of September 26, 2015 the future minimum annual lease payments under non-cancellable operating leases were as follows (in millions):

- changed (2016-02-04):
[0001628280-16-010773:note_history:2]
| Remainder of 2016 | $ | 2.9 |  |
| 2017 | 5.6 |  |
| 2018 | 4.6 |  |
| 2019 | 3.0 |  |
| 2020 | 1.9 |  |
| Thereafter | 5.0 |  |
| Total minimum operating lease payments | $ | 23.0 |  |
  (was, 2015-11-17, similarity 0.8765):
[0001564590-15-010839:note_history:2]
| Remainder of 2016 |  | $ | 4.6 |  |
| 2017 |  |  | 5.7 |  |
| 2018 |  |  | 4.6 |  |
| 2019 |  |  | 3.0 |  |
| 2020 |  |  | 1.9 |  |
| Thereafter |  |  | 5.1 |  |
| Total minimum operating lease payments |  | $ | 24.9 |  |

- changed (2016-02-04):
[0001628280-16-010773:note_history:3]
Included in the future minimum lease payments table above is $0.8 million related to lease commitments in connection with our restructuring and related activities. Refer to "Note 10. Restructuring and Related Charges" for more information.
  (was, 2015-11-17, similarity 0.9915):
[0001564590-15-010839:note_history:3]
Included in the future minimum lease payments table above is $1.0 million related to lease commitments in connection with our restructuring and related activities. Refer to “Note 9. Restructuring and Related Charges” for more information.

- changed (2016-02-04):
[0001628280-16-010773:note_history:4]
Purchase obligations of $145.5 million as of December 26, 2015, represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule and adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.
  (was, 2015-11-17, similarity 0.9939):
[0001564590-15-010839:note_history:4]
Purchase obligations of $151.8 million as of September 26, 2015, represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule and adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

- changed (2016-02-04):
[0001628280-16-010773:note_history:5]
The following table presents the changes in our warranty reserve during the three and six months ended December 26, 2015 and December 27, 2014 (in millions):
  (was, 2015-11-17, similarity 0.9375):
[0001564590-15-010839:note_history:5]
The following table presents the changes in our warranty reserve during the three months ended September 26, 2015 and September 27, 2014 (in millions):

- added (2016-02-04):
[0001628280-16-010773:note_history:6]
|  | Three Months Ended |  | Six Months Ended |
|  | December 26, 2015 |  | December 27, 2014 |  | December 26, 2015 |  | December 27, 2014 |
| Balance as of beginning of period | $ | 2.5 |  |  | $ | 2.4 |  |  | $ | 2.8 |  |  | $ | 2.7 |  |
| Provision for warranty | 0.8 |  |  | 0.9 |  |  | 1.7 |  |  | 1.5 |  |
| Utilization of reserve | (0.3 | ) |  | (1.2 | ) |  | (1.5 | ) |  | (2.1 | ) |
| Adjustments related to pre-existing warranties (including changes in estimates) | 0.1 |  |  | (0.1 | ) |  | 0.1 |  |  | (0.1 | ) |
| Balance as of end of period | $ | 3.1 |  |  | $ | 2.0 |  |  | $ | 3.1 |  |  | $ | 2.0 |  |

- removed (2016-02-04):
[0001564590-15-010839:note_history:7]
|  |  | Three Months Ended |  |
|  |  | September 26, 2015 |  |  | September 27, 2014 |  |
| Balance as of beginning of period |  | $ | 2.8 |  |  | $ | 2.7 |  |
| Provision for warranty |  |  | 0.9 |  |  |  | 0.6 |  |
| Utilization of reserve |  |  | (1.2 | ) |  |  | (0.9 | ) |
| Balance as of end of period |  | $ | 2.5 |  |  | $ | 2.4 |  |


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2016-02-04):
[0001628280-16-010773:note_history:8]
Lumentum Holdings Inc. (“we”, “our” or “Lumentum”) is an industry leading provider of optical and photonic products defined by revenue and market share addressing a range of end market applications including data communications (“Datacom”) and telecommunications (“Telecom”) networking and commercial lasers (“commercial lasers”) for manufacturing, inspection and life-science applications. We are using our core optical and photonic technology and our volume manufacturing capability to expand into attractive emerging markets that benefit from advantages that optical or photonics-based solutions provide, including 3-D sensing for consumer electronics and diode light sources for a variety of consumer and industrial applications. The majority of our customers tend to be original equipment manufacturers (“OEMs”) that incorporate our products into their products which then address end-market applications. For example, we sell fiber optic components that our network equipment manufacturer (“NEM”) customers assemble into communications networking systems, which they sell to network service providers or enterprises with their own networks. Similarly, many of our customers for our Lasers products incorporate our products into tools they produce, which are used for manufacturing processes by their customers.

- changed (2016-02-04):
[0001628280-16-010773:note_history:9]
On July 31, 2015, prior to the Separation, Viavi transferred substantially all of the assets and liabilities and operations of the communications and commercial optical products (“CCOP”) segment and WaveReady product lines to Lumentum (the “Capitalization"). Combined financial statements for periods prior to the Capitalization were prepared on a stand-alone basis and were derived from Viavi’s consolidated financial statements and accounting records. For the period from June 28, 2015 to August 1, 2015, expenses were allocated to us using estimates that we consider to be a reasonable reflection of the utilization of services provided to or benefits received by us.
  (was, 2015-11-17, similarity 0.8806):
[0001564590-15-010839:note_history:9]
On July 31, 2015, prior to the Separation, Viavi transferred substantially all of the assets and liabilities and operations of the communications and commercial optical products (“CCOP”) segment and WaveReady product lines to Lumentum (the “Capitalization"). Combined financial statements for periods prior to the Capitalization were prepared on a stand-alone basis and were derived from Viavi’s consolidated financial statements and accounting records. For the three months ended September 26, 2015, expenses were allocated to us using estimates that we consider to be a reasonable reflection of the utilization of services provided to or benefits received by us.

- changed (2016-02-04):
[0001628280-16-010773:note_history:10]
See "Note 3. Related Party Transactions" in the consolidated financial statements for further information regarding the relationships we had with Viavi and other Viavi entities.
  (was, 2015-11-17, similarity 0.9886):
[0001564590-15-010839:note_history:10]
See “Note 3. Related Party Transactions” in the consolidated financial statements for further information regarding the relationships we had with Viavi and other Viavi entities.

- changed (2016-02-04):
[0001628280-16-010773:note_history:11]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Our fiscal 2016 is a 53-week year ending on July 2, 2016 and our third quarter of fiscal 2016 will include one additional week. Our fiscal 2015 ended on June 27, 2015 and was a 52-week year.
  (was, 2015-11-17, similarity 0.7552):
[0001564590-15-010839:note_history:11]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Our fiscal 2016 is a 53-week year ending on July 2, 2016. Our fiscal 2015 ended on June 27, 2015 and was a 52-week year. Our fiscal 2014 ended on June 28, 2014 and was a 52-week year.

- changed (2016-02-04):
[0001628280-16-010773:note_history:12]
Principles of Combination and Consolidation
  (was, 2015-11-17, similarity 0.7714):
[0001564590-15-010839:note_history:12]
Principles of Consolidation

- changed (2016-02-04):
[0001628280-16-010773:note_history:13]
The consolidated financial statements include certain assets and liabilities that were historically held at the Viavi level which were specifically identifiable or otherwise attributable to us. All intra-company transactions within our business were eliminated. All material transactions between us and other businesses of Viavi prior to separation were reflected as net transfers to and from Viavi as a component of financing activities in the consolidated statement of cash flows.
  (was, 2015-11-17, similarity 0.9238):
[0001564590-15-010839:note_history:13]
The consolidated financial statements include certain assets and liabilities that were historically held at the Viavi level which were specifically identifiable or otherwise attributable to us. All intra-company transactions within our business were eliminated. All significant transactions between us and other businesses of Viavi prior to separation were reflected as net transfers to and from Viavi in the consolidated statement of stockholders’ equity and as a component of financing activities in the consolidated statement of cash flows

- changed (2016-02-04):
[0001628280-16-010773:note_history:14]
There have been no material changes in our significant accounting policies during the six months ended December 26, 2015 compared to the significant accounting policies described in our Annual Report on Form 10-K/A for the fiscal year ended June 27, 2015. The accompanying unaudited interim consolidated financial statements and accompanying related notes should be read in conjunction with the consolidated financial statements and related notes included in our Annual Report on Form 10-K/A for the fiscal year ended June 27, 2015.
  (was, 2015-11-17, similarity 0.9582):
[0001564590-15-010839:note_history:14]
There have been no material changes in our significant accounting policies during the three months ended September 26, 2015 compared to the significant accounting policies described in our Annual Report on Form 10-K/A for the fiscal year ended June 27, 2015. The accompanying unaudited interim consolidated financial statements and accompanying related notes should be read in conjunction with the consolidated financial statements and related notes included in our Annual Report on Form 10-K/A for the fiscal year ended June 27, 2015.

- added (2016-02-04):
[0001628280-16-010773:note_history:15]
Correction of Immaterial Error

- added (2016-02-04):
[0001628280-16-010773:note_history:16]
During the three and six months ended December 26, 2015, we identified an error relating to the determination of the accretion amount of Series A preferred stock for the three months ended September 26, 2015 in which the accretion of the discount related to issuance cost of $2.0 million was excluded. As a result, our net loss attributable to common stockholders and basic and diluted net loss per share attributable to common stockholders included in our quarterly report on Form 10-Q ("Form 10-Q") for the three months ended September 26, 2015 was understated by $2.0 million and $0.03 per basic and diluted share, respectively, and the correction of the error in the three months ended December 26, 2015 was an understatement of net income per share attributable to common stockholders by $2.0 million and $0.03 per basic and diluted share. In addition, this error resulted in an understatement of our mezzanine equity and an overstatement of our stockholders' equity by $2.0 million as of September 26, 2015 as included in the Form 10-Q. This error did not impact any annual or other interim periods and has no impact to the net income. We assessed the materiality of this error on the three and six months ended December 26, 2015 and as of September 26, 2015 and the three months ended September 26, 2015 unaudited consolidated financial statements in accordance with the SEC's Staff Accounting Bulletin No.99 and No.108, based on an analysis of quantitative and qualitative factors, determined that this error was not material to our unaudited consolidated financial statements as of September 30, 2015 and for the three months ended September 26, 2015 and the three and six months ended December 26, 2015. Therefore, our unaudited consolidated financial statements as of September 26, 2015 and for the three months ended September 26, 2015 can continue to be relied upon and an amendment of our previously filed Form 10-Q is not required. However, for comparability, the corrected amounts will be revised in the fiscal 2017 Form 10-Qs that will contain such financial information.

- removed (2016-02-04):
[0001564590-15-010839:note_history:17]
We are an industry leading provider of optical and photonic products addressing a range of end markets including data communications (“Datacom”) and telecommunications (“Telecom”) networking, and industrial and commercial lasers (“commercial lasers”) for manufacturing, inspection and life-science applications.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2016-02-04):
[0001628280-16-010773:note_history:18]
On July 31, 2015, the Company entered into a Supply Agreement with Viavi providing that each party will supply certain products at pre-determined prices, and providing Viavi with research and development services at cost plus a specified markup. The Company has also agreed to supply office space via a sublease agreement to Viavi. The sublease income and research and development cost reimbursements are each recorded as contra operating expenses in the Consolidated Statements of Operations for the six months ended December 26, 2015.
  (was, 2015-11-17, similarity 0.9591):
[0001564590-15-010839:note_history:18]
On July 31, 2015, the Company entered into a Supply Agreement with Viavi providing that each party will supply certain products at pre-determined prices, and providing Viavi with research and development services at cost plus a specified markup. The Company has also agreed to supply office space via a sublease agreement to Viavi. The sublease income and research and development cost reimbursements are each recorded as contra operating expenses in the Consolidated Statements of Operations for the three months ended September 26, 2015.

- added (2016-02-04):
[0001628280-16-010773:note_history:19]
The Supply Agreement contains a $15.0 million purchase commitment with Viavi for certain products, and for the three and six months ended December 26, 2015, the Company purchased $6.5 million in product from Viavi against the $15.0 million purchase commitment. During the three and six months ended December 26, 2015, the Company recognized revenue of $0.7 million and  $1.5 million, respectively, due to products sold to Viavi. For the three and six months ended December 26, 2015, the Company recorded $0.7 million and $1.2 million, respectively, in research and development cost reimbursement and $0.2 million and $0.3 million, respectively, in sublease rental income. As of December 26, 2015, the Company had $1.0 million in accounts receivable due from Viavi.

- changed (2016-02-04):
[0001628280-16-010773:note_history:20]
| a) | Contribution Agreement which identifies the assets to be transferred, the liabilities to be assumed and the contracts to be assigned and it provides for when and how these transfers, assumptions and assignments will occur. |
  (was, 2015-11-17, similarity 0.9957):
[0001564590-15-010839:note_history:20]
|  | a) | Contribution Agreement which identifies the assets to be transferred, the liabilities to be assumed and the contracts to be assigned and it provides for when and how these transfers, assumptions and assignments will occur. |

- changed (2016-02-04):
[0001628280-16-010773:note_history:21]
| b) | Separation and Distribution Agreement which governs the separation of the Lumentum business and other matters related to Lumentum’s relationship with Viavi. |
  (was, 2015-11-17, similarity 0.994):
[0001564590-15-010839:note_history:21]
|  | b) | Separation and Distribution Agreement which governs the separation of the Lumentum business and other matters related to Lumentum’s relationship with Viavi. |

- changed (2016-02-04):
[0001628280-16-010773:note_history:22]
| c) | Tax Matters Agreement which governs the respective rights, responsibilities and obligations of Lumentum and Viavi with respect to tax liabilities and benefits, attributes, proceedings, returns and certain other tax matters. |
  (was, 2015-11-17, similarity 0.9957):
[0001564590-15-010839:note_history:22]
|  | c) | Tax Matters Agreement which governs the respective rights, responsibilities and obligations of Lumentum and Viavi with respect to tax liabilities and benefits, attributes, proceedings, returns and certain other tax matters. |

- changed (2016-02-04):
[0001628280-16-010773:note_history:23]
| d) | Employee Matters Agreement which governs the compensation and employee benefit obligations with respect to the current and former employees of Lumentum and Viavi, the treatment of equity based compensation and generally allocates liabilities and responsibilities relating to employee compensation, benefit plans and programs. The Employee Matters Agreement provides that employees of Lumentum will participate in benefit plans sponsored or maintained by Lumentum. |
  (was, 2015-11-17, similarity 0.9979):
[0001564590-15-010839:note_history:23]
|  | d) | Employee Matters Agreement which governs the compensation and employee benefit obligations with respect to the current and former employees of Lumentum and Viavi, the treatment of equity based compensation and generally allocates liabilities and responsibilities relating to employee compensation, benefit plans and programs. The Employee Matters Agreement provides that employees of Lumentum will participate in benefit plans sponsored or maintained by Lumentum. |

- changed (2016-02-04):
[0001628280-16-010773:note_history:24]
| e) | Securities Purchase Agreement, which also includes Amada Holdings Co., Ltd. (“Amada”) as a party, which sets forth the terms for the sale by Viavi to Amada of shares of Series A Preferred Stock of Lumentum Inc., our wholly-owned subsidiary, following the Separation. |
  (was, 2015-11-17, similarity 0.9964):
[0001564590-15-010839:note_history:24]
|  | e) | Securities Purchase Agreement, which also includes Amada Holdings Co., Ltd. (“Amada”) as a party, which sets forth the terms for the sale by Viavi to Amada of shares of Series A Preferred Stock of Lumentum Inc., our wholly-owned subsidiary, following the Separation. |

- changed (2016-02-04):
[0001628280-16-010773:note_history:25]
| f) | Intellectual Property Matters Agreement which outlines the intellectual property rights of Lumentum and Viavi following the Separation, as well as non-compete restrictions between Viavi and Lumentum. |
  (was, 2015-11-17, similarity 0.9952):
[0001564590-15-010839:note_history:25]
|  | f) | Intellectual Property Matters Agreement which outlines the intellectual property rights of Lumentum and Viavi following the Separation, as well as non-compete restrictions between Viavi and Lumentum. |

- added (2016-02-04):
[0001628280-16-010773:note_history:26]
|  | Three Months Ended |  | Six Months Ended |
|  | December 26, 2015 |  | December 27, 2014 |  | December 26, 2015 |  | December 27, 2014 |
| Selling, general and administrative | $ | — |  |  | $ | 19.8 |  |  | $ | 11.7 |  |  | $ | 36.6 |  |
| Restructuring and related charges | — |  |  | 3.2 |  |  | — |  |  | 3.2 |  |
| Interest and other (income) expenses, net | — |  |  | (0.1 | ) |  | (0.1 | ) |  | — |  |
| Interest expense | — |  |  | 0.2 |  |  | 0.1 |  |  | 0.4 |  |
| Total allocated costs | $ | — |  |  | $ | 23.1 |  |  | $ | 11.7 |  |  | $ | 40.2 |  |

- removed (2016-02-04):
[0001564590-15-010839:note_history:27]
The Supply Agreement contains a $15.0 million purchase commitment with Viavi for certain products, and for the three months ended September 26, 2015, the Company has made no purchases against this commitment. During this period, the Company recognized revenue of $0.8 million due to products sold to Viavi. Subsequent to September 26, 2015, the Company purchased $4.6 million in product from Viavi against the $15.0 million purchase commitment. For the three months ended September 26, 2015, the Company recorded $0.5 million in research and development cost reimbursement and $0.1 million in sublease rental income. As of September 26, 2015, the Company had $0.8 million in accounts receivable due from .

- removed (2016-02-04):
[0001564590-15-010839:note_history:28]
|  |  | Three Months Ended |  |
|  |  | September 26, 2015 |  |  | September 27, 2014 |  |
| Selling, general and administrative |  |  | 11.7 |  |  |  | 16.8 |  |
| Interest and other (income) expenses, net |  |  | (0.1 | ) |  |  | 0.1 |  |
| Interest expense |  |  | 0.1 |  |  |  | 0.2 |  |
| Total allocated costs |  | $ | 11.7 |  |  | $ | 17.1 |  |


## us-gaap:ScheduleOfRelatedPartyTransactionsTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- added (2016-02-04):
[0001628280-16-010773:note_history:29]
|  | Three Months Ended |  | Six Months Ended |
|  | December 26, 2015 |  | December 27, 2014 |  | December 26, 2015 |  | December 27, 2014 |
| Selling, general and administrative | $ | — |  |  | $ | 19.8 |  |  | $ | 11.7 |  |  | $ | 36.6 |  |
| Restructuring and related charges | — |  |  | 3.2 |  |  | — |  |  | 3.2 |  |
| Interest and other (income) expenses, net | — |  |  | (0.1 | ) |  | (0.1 | ) |  | — |  |
| Interest expense | — |  |  | 0.2 |  |  | 0.1 |  |  | 0.4 |  |
| Total allocated costs | $ | — |  |  | $ | 23.1 |  |  | $ | 11.7 |  |  | $ | 40.2 |  |

- removed (2016-02-04):
[0001564590-15-010839:note_history:30]
|  |  | Three Months Ended |  |
|  |  | September 26, 2015 |  |  | September 27, 2014 |  |
| Selling, general and administrative |  |  | 11.7 |  |  |  | 16.8 |  |
| Interest and other (income) expenses, net |  |  | (0.1 | ) |  |  | 0.1 |  |
| Interest expense |  |  | 0.1 |  |  |  | 0.2 |  |
| Total allocated costs |  | $ | 11.7 |  |  | $ | 17.1 |  |
