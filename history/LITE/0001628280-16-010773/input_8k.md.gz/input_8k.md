# LITE 8-K — 0001628280-16-010755 filed 2016-02-04

## item codes, every 8-K on or before 2016-02-04

- 2016-02-04 0001628280-16-010758 — 5.02, 9.01
- 2016-02-04 0001628280-16-010755 — 2.02, 9.01
- 2015-11-17 0001193125-15-378953 — 7.01
- 2015-11-10 0001628280-15-008606 — 2.02, 9.01
- 2015-09-28 0001193125-15-329665 — 8.01, 9.01
- 2015-08-11 0001193125-15-286405 — 7.01, 9.01
- 2015-08-06 0001193125-15-281219 — 1.01, 5.02, 5.03, 5.05, 8.01, 9.01
- 2015-08-03 0001193125-15-274808 — 5.03, 9.01

## late-filing notifications on or before 2016-02-04

- 2015-11-10 0001628280-15-008612 — NT 10-Q, for the period ended 2015-09-26
- 2015-09-28 0001193125-15-329672 — NT 10-K, for the period ended 2015-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001628280-16-010755:8k_2_02:1]
EX-99.1
2
lite_ex991xq2fy16.htm
EXHIBIT 99.1

[0001628280-16-010755:8k_2_02:2]
Exhibit

[0001628280-16-010755:8k_2_02:3]
Exhibit 99.1

[0001628280-16-010755:8k_2_02:4]
NEWS RELEASE

[0001628280-16-010755:8k_2_02:5]
LUMENTUM ANNOUNCES FISCAL SECOND QUARTER 2016 RESULTS

[0001628280-16-010755:8k_2_02:6]
| • | Net Revenue of $218.3 million exceeded mid-point of guidance |

[0001628280-16-010755:8k_2_02:7]
| • | Non-GAAP Operating margin of 9.0% exceeding mid-point of guidance; GAAP Operating margin of 2.8% |

[0001628280-16-010755:8k_2_02:8]
| • | Non-GAAP Net income per share of $0.31 exceeded upper-end of guidance; GAAP Net income per share of $0.05(a) |

[0001628280-16-010755:8k_2_02:9]
Milpitas, Calif., February 4, 2016 – Lumentum Holdings Inc. ("Lumentum") today reported results for its fiscal second quarter ended December 26, 2015.

[0001628280-16-010755:8k_2_02:10]
Net revenue for the fiscal second quarter 2016 was $218.3 million, with GAAP net income of $2.8 million, or $0.05 per share. Prior quarter net revenue was $212.6 million, with GAAP net loss of $(0.2) million, or $0.00 per share. Net revenue for the fiscal second quarter 2015 was $210.5 million, with GAAP net loss of $(4.1) million, or $(0.07) per share.

[0001628280-16-010755:8k_2_02:11]
Non-GAAP net income for the fiscal second quarter 2016 was $19.1 million or $0.31 per share. Prior quarter non-GAAP net income was $14.8 million, or $0.25 per share. Fiscal second quarter 2015 non-GAAP net income was $13.9 million, or $0.24 per share. The Company held $161.9 million in total cash at the end of the quarter, which increased by $19.8 million sequentially, and remains debt-free.

[0001628280-16-010755:8k_2_02:12]
“We delivered solid fiscal second quarter results,” said Alan Lowe, president and CEO. “We continue to see strong demand for our 100G datacom products, especially, our first to volume QSFP28 2km products. During the fiscal second quarter 2016, our ROADM revenue grew 44% sequentially and 103% year-over-year as a result of our focus on innovation and the broad market adoption of our TrueFlexTM products. Bookings were strong during the fiscal second quarter and this strength has continued through the first month of the fiscal third quarter.”

[0001628280-16-010755:8k_2_02:13]
Financial Overview – Fiscal Second Quarter Ended December 26, 2015

[0001628280-16-010755:8k_2_02:14]
|  | GAAP Results ($ in millions) |
|  | Q2 |  | Q1 |  | Q2 |  | Change |
|  | FY 2016 |  | FY 2016 |  | FY2015 |  | Q/Q |  | Y/Y |
| Net revenue | $ | 218.3 |  |  | $ | 212.6 |  |  | $ | 210.5 |  |  | 2.7 | % |  | 3.7 | % |
| Gross margin | 31.2 | % |  | 31.5 | % |  | 31.8 | % |  | (30)bps |  |  | (60)bps |  |
| Operating margin | 2.8 | % |  | (1.2 | )% |  | (1.5 | )% |  | 400bps |  |  | 430bps |  |
|  | Non-GAAP Results ($ in millions) |
|  | Q2 |  | Q1 |  | Q2 |  | Change |
|  | FY 2016 |  | FY 2016 |  | FY2015 |  | Q/Q |  | Y/Y |
| Net revenue | $ | 218.3 |  |  | $ | 212.6 |  |  | $ | 210.5 |  |  | 2.7 | % |  | 3.7 | % |
| Gross margin | 32.7 | % |  | 32.8 | % |  | 33.5 | % |  | (10)bps |  |  | (80)bps |  |
| Operating margin | 9.0 | % |  | 7.1 | % |  | 6.6 | % |  | 190bps |  |  | 240bps |  |

[0001628280-16-010755:8k_2_02:15]
|  | Net Revenue by Segment |
|  | Q2 |  | % of |  | Q1 |  | Q2 |  | Change |
|  | FY 2016 |  | Net Revenue |  | FY 2016 |  | FY 2015 |  | Q/Q |  | Y/Y |
| Optical Communications | $ | 185.8 |  |  | 85.1 | % |  | $ | 177.1 |  |  | $ | 171.1 |  |  | 4.9 | % |  | 8.6 | % |
| Lasers | 32.5 |  |  | 14.9 | % |  | 35.5 |  |  | 39.4 |  |  | (8.5 | )% |  | (17.5 | )% |
| Total | $ | 218.3 |  |  | 100.0 | % |  | $ | 212.6 |  |  | $ | 210.5 |  |  | 2.7 | % |  | 3.7 | % |

[0001628280-16-010755:8k_2_02:16]
The tables above provide comparisons of quarterly results to prior periods, including sequential quarterly and year-over-year changes. A reconciliation between GAAP and non-GAAP measures is contained in this release under the section titled “Use of Non-GAAP Financial Measures.”

[0001628280-16-010755:8k_2_02:17]
Business Outlook

[0001628280-16-010755:8k_2_02:18]
For the fiscal third quarter 2016, the Company expects net revenue to be in the range of $222 million to $232 million, non-GAAP operating margin to be 8.0% to 9.5%, and non-GAAP earnings per share to be $0.28 to $0.34 per share, based on approximately 61 million shares on a fully diluted basis. These estimates are based upon a fourteen week fiscal quarter as we will have fifty-three weeks for fiscal year 2016.

[0001628280-16-010755:8k_2_02:19]
Conference Call

[0001628280-16-010755:8k_2_02:20]
Lumentum will host a conference call on February 4, 2016 at 1:30pm PT/4:30pm ET. A live webcast of the call and the replay will be available on the Lumentum website at http://investor.lumentum.com. The Company will post supporting materials outlining the Company’s latest financial results on http://investor.lumentum.com under the “Events and Presentations” section concurrently with this earnings press release. This press release is being furnished as a Current Report on Form 8-K with the Securities and Exchange Commission, and will be available at http://www.sec.gov/.

[0001628280-16-010755:8k_2_02:21]
About Lumentum

[0001628280-16-010755:8k_2_02:22]
Lumentum (NASDAQ: LITE) is a market-leading manufacturer of innovative optical and photonic products enabling optical networking and commercial laser customers worldwide. Lumentum’s optical components and subsystems are part of virtually every type of telecom, enterprise, and data center network. Lumentum’s commercial lasers enable advanced manufacturing techniques and diverse applications including next-generation 3D sensing capabilities. Lumentum is headquartered in Milpitas, California with R&D, manufacturing, and sales offices worldwide.  For more information, visit https://www.lumentum.com/en.

[0001628280-16-010755:8k_2_02:23]
Forward-Looking Statements

[0001628280-16-010755:8k_2_02:24]
Contact Information

[0001628280-16-010755:8k_2_02:25]
Investors: Chris Coldren, 408-404-0606; investor.relations@lumentum.com

[0001628280-16-010755:8k_2_02:26]
Press: Greg Kaufman, 408-546-4235; media@lumentum.com

[0001628280-16-010755:8k_2_02:27]
The following financial tables are presented in accordance with GAAP, unless otherwise specified.

[0001628280-16-010755:8k_2_02:28]
LUMENTUM HOLDINGS INC.

[0001628280-16-010755:8k_2_02:29]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0001628280-16-010755:8k_2_02:30]
(in millions, except per share data)

[0001628280-16-010755:8k_2_02:31]
(unaudited)

[0001628280-16-010755:8k_2_02:32]
|  | Three Months Ended |  | Six Months Ended |
|  | December 26, 2015 |  | December 27, 2014 |  | December 26, 2015 |  | December 27, 2014 |
| Net revenue | $ | 218.3 |  |  | $ | 210.5 |  |  | $ | 430.9 |  |  | $ | 429.5 |  |
| Cost of sales | 148.5 |  |  | 141.7 |  |  | 292.5 |  |  | 288.5 |  |
| Amortization of acquired technologies | 1.7 |  |  | 1.9 |  |  | 3.4 |  |  | 3.8 |  |
| Gross profit | 68.1 |  |  | 66.9 |  |  | 135.0 |  |  | 137.2 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 35.0 |  |  | 35.1 |  |  | 69.4 |  |  | 70.1 |  |
| Selling, general and administrative | 25.8 |  |  | 31.2 |  |  | 59.8 |  |  | 59.5 |  |
| Restructuring and related charges | 1.1 |  |  | 3.8 |  |  | 2.1 |  |  | 5.6 |  |
| Total operating expenses | 61.9 |  |  | 70.1 |  |  | 131.3 |  |  | 135.2 |  |
| Income (loss) from operations | 6.2 |  |  | (3.2 | ) |  | 3.7 |  |  | 2.0 |  |
| Unrealized loss on derivative liability | (2.4 | ) |  | — |  |  | (0.2 | ) |  | — |  |
| Interest and other (expense) income, net | (0.5 | ) |  | (0.1 | ) |  | (0.7 | ) |  | (0.4 | ) |
| Income (loss) before income taxes | 3.3 |  |  | (3.3 | ) |  | 2.8 |  |  | 1.6 |  |
| Provision for income taxes | 0.5 |  |  | 0.8 |  |  | 0.2 |  |  | 1.4 |  |
| Net income (loss) | 2.8 |  |  | (4.1 | ) |  | 2.6 |  |  | 0.2 |  |
| Net income (loss) per share:(a) |  |  |  |  |  |  |  |
| Basic | $ | 0.05 |  |  | $ | (0.07 | ) |  | $ | 0.04 |  |  | $ | — |  |
| Diluted | $ | 0.05 |  |  | $ | (0.07 | ) |  | $ | 0.04 |  |  | $ | — |  |
| Items reconciling net income (loss) to net income (loss) available to common shareholders: |  |  |  |  |  |  |  |
| Cumulative dividends on Series A preferred stock | (0.2 | ) |  | — |  |  | (0.3 | ) |  | — |  |
| Adjustment for Series A preferred stock redemption value | (2.0 | ) |  | — |  |  | (11.7 | ) |  | — |  |
| Net income (loss) available to common shareholders | $ | 0.6 |  |  | $ | (4.1 | ) |  | $ | (9.4 | ) |  | $ | 0.2 |  |
| Net income (loss) available to common shareholders per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.01 |  |  | $ | (0.07 | ) |  | $ | (0.16 | ) |  | $ | — |  |
| Diluted | $ | 0.01 |  |  | $ | (0.07 | ) |  | $ | (0.16 | ) |  | $ | — |  |
| Shares used in per share calculation:(a) |  |  |  |  |  |  |  |
| Basic | 59.0 |  |  | 58.8 |  |  | 58.9 |  |  | 58.8 |  |
| Diluted | 59.2 |  |  | 58.8 |  |  | 58.9 |  |  | 58.8 |  |

[0001628280-16-010755:8k_2_02:33]
| (a) | On August 1, 2015, JDSU distributed 47.1 million shares, or 80.1% of the outstanding shares of common stock of Lumentum to existing holders of JDSU common stock. JDSU was renamed Viavi Solutions Inc. and at the time of the distribution, retained 11.7 million shares, or 19.9% of Lumentum’s outstanding shares. Basic and diluted net income (loss) per share for the three and six months ended December 27, 2014 are calculated using the shares of Lumentum common stock outstanding on August 1, 2015. |

[0001628280-16-010755:8k_2_02:34]
LUMENTUM HOLDINGS INC.

[0001628280-16-010755:8k_2_02:35]
CONSOLIDATED BALANCE SHEETS

[0001628280-16-010755:8k_2_02:36]
(in millions, except share and per share data)

[0001628280-16-010755:8k_2_02:37]
(unaudited)

[0001628280-16-010755:8k_2_02:38]
|  | December 26, 2015 |  | June 27, 2015 |
| ASSETS |  |  |  |  |  |
| Current assets: |  |  |  |  |  |
| Cash and cash equivalents | $ | 161.9 |  |  | $ | 14.5 |  |
| Accounts receivable, net | 159.1 |  |  | 150.5 |  |
| Inventories | 107.3 |  |  | 99.7 |  |
| Prepayments and other current assets | 50.4 |  |  | 46.1 |  |
| Total current assets | 478.7 |  |  | 310.8 |  |
| Property, plant and equipment, net | 151.4 |  |  | 143.2 |  |
| Goodwill and intangibles, net | 23.6 |  |  | 27.4 |  |
| Deferred income taxes, net | 27.7 |  |  | 30.3 |  |
| Other non-current assets | 0.6 |  |  | 0.9 |  |
| Total assets | $ | 682.0 |  |  | 512.6 |  |
| LIABILITIES, MEZZANINE EQUITY AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 95.2 |  |  | $ | 77.9 |  |
| Accrued payroll and related expenses | 30.7 |  |  | 17.7 |  |
| Income taxes payable | 4.0 |  |  | 3.7 |  |
| Accrued expenses | 15.7 |  |  | 11.5 |  |
| Other current liabilities | 11.8 |  |  | 11.4 |  |
| Total current liabilities | 157.4 |  |  | 122.2 |  |
| Derivative liability | 9.9 |  |  | — |  |
| Other non-current liabilities | 8.0 |  |  | 9.8 |  |
| Total liabilities | 175.3 |  |  | 132.0 |  |
| Mezzanine equity: |  |  |  |
| Non-controlling Interest Redeemable convertible Series A preferred stock, $0.001 par value, 10,000,000 authorized shares; 35,805 shares issued and outstanding as of December 26, 2015, and no shares issued and outstanding as of June 27, 2015 | 35.8 |  |  | — |  |
| Total mezzanine equity | 35.8 |  |  | — |  |
| Stockholders’ equity: |  |  |  |
| Viavi net investment | — |  |  | 368.1 |  |
| Common stock, $0.001 par value, 990,000,000 authorized shares, 59,081,186 shares issued and outstanding as of December 26, 2015, and no shares issued and outstanding as of June 27, 2015 | 0.1 |  |  | — |  |
| Additional paid-in capital | 451.3 |  |  | — |  |
| Retained earnings | 14.0 |  |  | — |  |
| Accumulated other comprehensive income | 5.5 |  |  | 12.5 |  |
| Total stockholders’ equity | 470.9 |  |  | 380.6 |  |
| Total liabilities, mezzanine equity and stockholders’ equity | $ | 682.0 |  |  | $ | 512.6 |  |

[0001628280-16-010755:8k_2_02:39]
Use of Non-GAAP Financial Measures

[0001628280-16-010755:8k_2_02:40]
In this press release, Lumentum provides investors with gross margin, operating margin, net income, net income (loss) per share and segment revenue on a non-GAAP basis. Lumentum believes this non-GAAP financial information provides additional insight into the Company's on-going performance and has therefore chosen to provide this information to investors for a more consistent basis of comparison and to help them evaluate the results of the Company's on-going operations and enable more meaningful period to period comparisons. Specifically, the Company believes that providing this information allows investors to better understand the Company’s financial performance and, importantly, to evaluate the efficacy of the methodology and information used by management to evaluate and measure such operating performance.  However, these measures may be different from non-GAAP measures used by other companies, limiting their usefulness for comparison purposes. The non-GAAP financial measures used in this press release should not be considered in isolation from measures of financial performance prepared in accordance with GAAP. Investors are cautioned that there are material limitations associated with the use of non-GAAP financial measures as an analytical tool. In particular, many of the adjustments to our GAAP financial measures reflect the exclusion of items that are recurring and will be reflected in our financial results for the foreseeable future.

[0001628280-16-010755:8k_2_02:41]
Non-GAAP gross margin, non-GAAP operating margin, non-GAAP net income (loss), and non-GAAP net income (loss) per share, and Adjusted EBITDA exclude (i) workforce related charges such as severance, retention bonuses and employee relocation costs related to formal restructuring plans, (ii) costs for facilities not required for ongoing operations, and costs related to the relocation of certain equipment from these facilities and/or contract manufacturer facilities, (iii) stock-based compensation, (iv) amortization of intangibles, and (v) other non-recurring charges comprising mainly of one-time acquisition, integration, litigation and other costs and contingencies unrelated to current and future operations including post-separation activities such as small site consolidations, reorganizations, insourcing or outsourcing of activities, severance related costs and transition related costs for the separation from Viavi. Management does not believe that these items are reflective of the Company's underlying operating performance. The presentation of these and other similar items in Lumentum's non-GAAP financial results should not be interpreted as implying that these items are non-recurring, infrequent or unusual.

[0001628280-16-010755:8k_2_02:42]
A quantitative reconciliation between GAAP and non-GAAP financial data with respect to historical periods is included in the supplemental financial table attached to this press release. The Company has not reconciled its projections of non-GAAP earnings per share.  As items that impact net loss are out of the Company's control and/or cannot be reasonably predicted, Lumentum has determined that a quantitative reconciliation of forward-looking non-GAAP financial measures to their most directly comparable GAAP financial measures cannot be provided without unreasonable efforts.

[0001628280-16-010755:8k_2_02:43]
LUMENTUM HOLDINGS INC.

[0001628280-16-010755:8k_2_02:44]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001628280-16-010755:8k_2_02:45]
(in millions, except per share data)

[0001628280-16-010755:8k_2_02:46]
(unaudited)

[0001628280-16-010755:8k_2_02:47]
|  | Three Months Ended |  | Six Months Ended |
|  | December 26, 2015 |  | December 27, 2014 |  | December 26, 2015 |  | December 27, 2014 |
| Gross profit on GAAP basis | $ | 68.1 |  |  | $ | 66.9 |  |  | $ | 135.0 |  |  | $ | 137.2 |  |
| Stock-based compensation | 1.5 |  |  | 1.2 |  |  | 2.7 |  |  | 2.6 |  |
| Other charges related to non-recurring activities | — |  |  | 0.5 |  |  | — |  |  | 1.0 |  |
| Amortization of acquired developed technologies | 1.7 |  |  | 1.9 |  |  | 3.4 |  |  | 3.8 |  |
| Gross profit on non-GAAP basis | $ | 71.3 |  |  | $ | 70.5 |  |  | $ | 141.1 |  |  | $ | 144.6 |  |
| Research and development on GAAP basis | $ | 35.0 |  |  | $ | 35.1 |  |  | $ | 69.4 |  |  | $ | 70.1 |  |
| Stock-based compensation | (2.3 | ) |  | (1.8 | ) |  | (4.2 | ) |  | (3.7 | ) |
| Other charges related to non-recurring activities | — |  |  | — |  |  | (0.6 | ) |  | — |  |
| Research and development on non-GAAP basis | $ | 32.7 |  |  | $ | 33.3 |  |  | $ | 64.6 |  |  | $ | 66.4 |  |
| Selling, general and administrative on GAAP basis | $ | 25.8 |  |  | $ | 31.2 |  |  | $ | 59.8 |  |  | $ | 59.5 |  |
| Stock-based compensation | (2.5 | ) |  | (3.7 | ) |  | (5.9 | ) |  | (7.3 | ) |
| Other charges related to non-recurring activities | (4.2 | ) |  | (4.0 | ) |  | (12.0 | ) |  | (4.4 | ) |
| Amortization of intangibles | (0.1 | ) |  | (0.1 | ) |  | (0.2 | ) |  | (0.2 | ) |
| Selling, general and administrative on non-GAAP basis | $ | 19.0 |  |  | $ | 23.4 |  |  | $ | 41.7 |  |  | $ | 47.6 |  |
| Restructuring and related charges on GAAP basis | $ | 1.1 |  |  | $ | 3.8 |  |  | $ | 2.1 |  |  | $ | 5.6 |  |
| Restructuring and related charges | (1.1 | ) |  | (3.8 | ) |  | (2.1 | ) |  | (5.6 | ) |
| Restructuring and related charges on non-GAAP basis | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Income (loss) from operations on GAAP basis | $ | 6.2 |  |  | $ | (3.2 | ) |  | $ | 3.7 |  |  | $ | 2.0 |  |
| Stock-based compensation | 6.3 |  |  | 6.7 |  |  | 12.8 |  |  | 13.6 |  |
| Other charges related to non-recurring activities | 4.2 |  |  | 4.5 |  |  | 12.6 |  |  | 5.4 |  |
| Amortization of intangibles | 1.8 |  |  | 2.0 |  |  | 3.6 |  |  | 4.0 |  |
| Restructuring and related charges | 1.1 |  |  | 3.8 |  |  | 2.1 |  |  | 5.6 |  |
| Income (loss) from operations on non-GAAP basis | $ | 19.6 |  |  | $ | 13.8 |  |  | $ | 34.8 |  |  | $ | 30.6 |  |
| Unrealized loss on derivative liability on GAAP basis | $ | (2.4 | ) |  | $ | — |  |  | $ | (0.2 | ) |  | $ | — |  |
| Unrealized loss on derivative liability | 2.4 |  |  | — |  |  | 0.2 |  |  | — |  |
| Unrealized loss on derivative liability on non-GAAP basis | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Income (loss) before income taxes on GAAP basis | $ | 3.3 |  |  | $ | (3.3 | ) |  | $ | 2.8 |  |  | $ | 1.6 |  |
| Stock-based compensation | 6.3 |  |  | 6.7 |  |  | 12.8 |  |  | 13.6 |  |
| Other charges related to non-recurring activities | 4.2 |  |  | 4.5 |  |  | 12.6 |  |  | 5.4 |  |
| Amortization of intangibles | 1.8 |  |  | 2.0 |  |  | 3.6 |  |  | 4.0 |  |
| Restructuring and related charges | 1.1 |  |  | 3.8 |  |  | 2.1 |  |  | 5.6 |  |
| Unrealized loss on derivative liability | 2.4 |  |  | — |  |  | 0.2 |  |  | — |  |

[0001628280-16-010755:8k_2_02:48]
| Income (loss) before income taxes on non-GAAP basis | $ | 19.1 |  |  | $ | 13.7 |  |  | $ | 34.1 |  |  | $ | 30.2 |  |
| Provision for income taxes on GAAP basis | $ | 0.5 |  |  | $ | 0.8 |  |  | $ | 0.2 |  |  | $ | 1.4 |  |
| Non-cash income tax (benefit) expense | (0.5 | ) |  | (1.0 | ) |  | — |  |  | (1.8 | ) |
| Provision (benefit) for income taxes on non-GAAP basis | $ | — |  |  | $ | (0.2 | ) |  | $ | 0.2 |  |  | $ | (0.4 | ) |
| Net income (loss) on GAAP basis | $ | 2.8 |  |  | $ | (4.1 | ) |  | $ | 2.6 |  |  | $ | 0.2 |  |
| Stock-based compensation | 6.3 |  |  | 6.7 |  |  | 12.8 |  |  | 13.6 |  |
| Other charges related to non-recurring activities | 4.2 |  |  | 4.5 |  |  | 12.6 |  |  | 5.4 |  |
| Amortization of intangibles | 1.8 |  |  | 2.0 |  |  | 3.6 |  |  | 4.0 |  |
| Restructuring and related charges | 1.1 |  |  | 3.8 |  |  | 2.1 |  |  | 5.6 |  |
| Unrealized loss on derivative liability | 2.4 |  |  | — |  |  | 0.2 |  |  | — |  |
| Non-cash income tax (benefit) expense | 0.5 |  |  | 1.0 |  |  | — |  |  | 1.8 |  |
| Net income on non-GAAP basis | $ | 19.1 |  |  | $ | 13.9 |  |  | $ | 33.9 |  |  | $ | 30.6 |  |
| Net income per share on non-GAAP basis | $ | 0.31 |  |  | $ | 0.24 |  |  | $ | 0.56 |  |  | $ | 0.52 |  |
| Shares used in per share calculation - diluted on GAAP basis | 59.2 |  |  | 58.8 |  |  | 58.9 |  |  | 58.8 |  |
| Non-GAAP adjustment (b) | 1.5 |  |  | — |  |  | 1.4 |  |  | — |  |
| Shares used in per share calculation - diluted on non-GAAP basis | 60.7 |  |  | 58.8 |  |  | 60.3 |  |  | 58.8 |  |

[0001628280-16-010755:8k_2_02:49]
| (b) | This adjustment represents weighted-average potentially dilutive securities excluded from the computation of diluted net loss per share attributable to common stockholders on GAAP basis because the effect would have been anti-dilutive. This adjustment amount is added for the computation of diluted net income per share on non-GAAP basis as we had a net income on non-GAAP basis for the six months ended December 26, 2015. |

[0001628280-16-010755:8k_2_02:50]
LUMENTUM HOLDINGS INC.

[0001628280-16-010755:8k_2_02:51]
RECONCILIATION OF GAAP NET INCOME (LOSS) TO ADJUSTED EBITDA

[0001628280-16-010755:8k_2_02:52]
(in millions)

[0001628280-16-010755:8k_2_02:53]
(unaudited)

[0001628280-16-010755:8k_2_02:54]
|  | Three Months Ended |  | Six Months Ended |
|  | December 26, 2015 |  | December 27, 2014 |  | December 26, 2015 |  | December 27, 2014 |
| GAAP net income (loss) | $ | 2.8 |  |  | $ | (4.1 | ) |  | $ | 2.6 |  |  | $ | 0.2 |  |
| Interest and other (expense) income, net | 0.5 |  |  | 0.1 |  |  | 0.7 |  |  | 0.4 |  |
| Provision for income taxes | 0.5 |  |  | 0.8 |  |  | 0.2 |  |  | 1.4 |  |
| Depreciation | 12.1 |  |  | 10.8 |  |  | 23.8 |  |  | 21.2 |  |
| Amortization | 1.8 |  |  | 2.0 |  |  | 3.6 |  |  | 4.0 |  |
| EBITDA | 17.7 |  |  | 9.6 |  |  | 30.9 |  |  | 27.2 |  |
| Costs related to restructuring and related charges | 1.1 |  |  | 3.8 |  |  | 2.1 |  |  | 5.6 |  |
| Costs related to stock-based compensation | 6.3 |  |  | 6.7 |  |  | 12.8 |  |  | 13.6 |  |
| Costs related to other non-recurring activities | 4.2 |  |  | 4.5 |  |  | 12.6 |  |  | 5.4 |  |
| Adjusted EBITDA | $ | 29.3 |  |  | $ | 24.6 |  |  | $ | 58.4 |  |  | $ | 51.8 |  |
