# LITE 10-Q controls and the auditor's report


## item_4_controls

[0001628280-16-010773:item_4_controls:1]
Item 4. Controls and Procedures

[0001628280-16-010773:item_4_controls:2]
Disclosure Controls and Procedures: Management, with the participation of our principal executive officer and principal financial officer, has evaluated the effectiveness of our disclosure controls and procedures (as such term is defined in Rules 13a-15(e) and 15d-15(e) under the Securities Exchange Act of 1934, as amended (the “Exchange Act”)) as of the end of the period covered by this report. Based on such evaluation, our principle executive officer and principal financial officer have concluded that, as of the end of such period, our disclosure controls and procedures were effective.

[0001628280-16-010773:item_4_controls:3]
Internal Control Over Financial Reporting: There have not been any changes in our internal control over financial reporting (as such term is defined in Rules 13a-15(f) and 15d-15(f) under the Exchange Act) during the most recent fiscal quarter that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.

[0001628280-16-010773:item_4_controls:4]
33
