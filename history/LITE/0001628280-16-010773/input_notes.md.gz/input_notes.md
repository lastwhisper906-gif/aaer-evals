# LITE notes — 0001628280-16-010773


## lite:PropertyPlantandEquipmentNetTableTextBlock

[0001628280-16-010773:notes:1]
The components of property, plant and equipment, net were as follows (in millions):

[0001628280-16-010773:notes:2]
|  | December 26,2015 |  | June 27,2015 |
| Land | $ | 5.9 |  |  | $ | 5.9 |  |
| Buildings and improvement | 28.7 |  |  | 28.6 |  |
| Machinery and equipment | 335.2 |  |  | 326.4 |  |
| Furniture and fixtures and software | 31.4 |  |  | 8.0 |  |
| Leasehold improvements | 28.7 |  |  | 20.5 |  |
| Construction in progress | 35.0 |  |  | 26.8 |  |
|  | 464.9 |  |  | 416.2 |  |
| Less: Accumulated depreciation | (313.5 | ) |  | (273.0 | ) |
| Property, plant and equipment, net | $ | 151.4 |  |  | $ | 143.2 |  |


## lite:ScheduleOfOtherLiabilitiesCurrentTableTextBlock

[0001628280-16-010773:notes:3]
The components of other current liabilities were as follows (in millions):

[0001628280-16-010773:notes:4]
|  | December 26,2015 |  | June 27,2015 |
| Restructuring accrual and related charges | $ | 4.3 |  |  | $ | 3.2 |  |
| Warranty accrual | 3.1 |  |  | 2.8 |  |
| Others | 4.4 |  |  | 5.4 |  |
| Other current liabilities | $ | 11.8 |  |  | $ | 11.4 |  |


## lite:ScheduleOfOtherLiabilitiesNoncurrentTableTextBlock

[0001628280-16-010773:notes:5]
The components of other non-current liabilities were as follows (in millions):

[0001628280-16-010773:notes:6]
|  | December 26,2015 |  | June 27,2015 |
| Asset retirement obligation | 2.1 |  |  | 1.8 |  |
| Pension and related accruals | 2.6 |  |  | 2.1 |  |
| Deferred rent | 1.5 |  |  | 1.7 |  |
| Restructuring accrual and related charges | — |  |  | 1.7 |  |
| Other non-current liabilities | 1.8 |  |  | 2.5 |  |
| Other non-current liabilities | $ | 8.0 |  |  | $ | 9.8 |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001628280-16-010773:notes:7]
Note 7. Balance Sheet Components

[0001628280-16-010773:notes:8]
[same as prior period, unchanged from 0001564590-15-010839:notes:52]

[0001628280-16-010773:notes:9]
As of December 26, 2015, our accounts receivable allowance was $0.7 million. Our accounts receivable allowance as of June 27, 2015 was $1.2 million.

[0001628280-16-010773:notes:10]
[same as prior period, unchanged from 0001564590-15-010839:notes:54]

[0001628280-16-010773:notes:11]
[same as prior period, unchanged from 0001564590-15-010839:notes:55]

[0001628280-16-010773:notes:12]
|  | December 26,2015 |  | June 27,2015 |
| Finished goods | $ | 50.8 |  |  | $ | 60.1 |  |
| Work in process | 26.3 |  |  | 23.4 |  |
| Raw materials and purchased parts | 30.2 |  |  | 16.2 |  |
| Inventories | $ | 107.3 |  |  | $ | 99.7 |  |

[0001628280-16-010773:notes:13]
During the three and six months ended December 26, 2015, we wrote off $0.6 million and $1.1 million of inventory, respectively.

[0001628280-16-010773:notes:14]
During the three and six months ended December 27, 2014, we wrote off $1.4 million and $2.0 million of inventory, respectively.

[0001628280-16-010773:notes:15]
[same as prior period, unchanged from 0001564590-15-010839:notes:58]

[0001628280-16-010773:notes:16]
[same as prior period, unchanged from 0001564590-15-010839:notes:59]

[0001628280-16-010773:notes:17]
|  | December 26,2015 |  | June 27,2015 |
| Prepayments | $ | 28.5 |  |  | $ | 20.4 |  |
| Advances to contract manufacturers | 8.7 |  |  | 9.5 |  |
| Due from Viavi, net | 1.0 |  |  | — |  |
| Other current assets | 12.2 |  |  | 16.2 |  |
| Prepayments and other current assets | $ | 50.4 |  |  | $ | 46.1 |  |

[0001628280-16-010773:notes:18]
Amount due from Viavi, net represents certain obligations to be reimbursed from Viavi, net of payables, pursuant to the Separation and Distribution Agreement and Contribution Agreement.

[0001628280-16-010773:notes:19]
[same as prior period, unchanged from 0001564590-15-010839:notes:62]

[0001628280-16-010773:notes:20]
[same as prior period, unchanged from 0001564590-15-010839:notes:66]

[0001628280-16-010773:notes:21]
[same as prior period, unchanged from 0001564590-15-010839:notes:69]


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001628280-16-010773:notes:22]
Basis of Presentation

[0001628280-16-010773:notes:23]
On August 1, 2015, Lumentum became an independent publicly-traded company through the distribution by JDSU to its stockholders of 80.1% of our outstanding common stock (the “Separation”). Each JDSU stockholder of record as of the close of business on July 27, 2015 received one share of Lumentum common stock for every five shares of JDSU common stock held on the record date. JDSU was renamed Viavi and at the time of the distribution retained ownership of 19.9% of Lumentum’s outstanding shares. Lumentum was incorporated in Delaware as a wholly owned subsidiary of Viavi on February 10, 2015 and is comprised of the former communications and commercial optical products (“CCOP”) segment and WaveReady product lines of Viavi. Lumentum’s Registration Statement on Form 10 was declared effective by the U.S. Securities and Exchange Commission (“SEC”) on July 16, 2015. Lumentum’s common stock began trading “regular-way” under the ticker “LITE” on the NASDAQ stock market on August 4, 2015.

[0001628280-16-010773:notes:24]
On July 31, 2015, prior to the Separation, Viavi transferred substantially all of the assets and liabilities and operations of the communications and commercial optical products (“CCOP”) segment and WaveReady product lines to Lumentum (the “Capitalization"). Combined financial statements for periods prior to the Capitalization were prepared on a stand-alone basis and were derived from Viavi’s consolidated financial statements and accounting records. For the period from June 28, 2015 to August 1, 2015, expenses were allocated to us using estimates that we consider to be a reasonable reflection of the utilization of services provided to or benefits received by us.

[0001628280-16-010773:notes:25]
The preparation of the consolidated financial statements in accordance with GAAP in the U.S. requires management to make estimates and assumptions that affect the amounts reported in our consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact the company in the future, actual results may be different from the estimates. Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are revenue recognition, inventory valuation, allocation methods and allocated expenses from Viavi, valuation of goodwill and other intangible assets, share-based compensation, retirement and post-retirement plan assumptions, restructuring, warranty and accounting for income taxes.

[0001628280-16-010773:notes:26]
See "Note 3. Related Party Transactions" in the consolidated financial statements for further information regarding the relationships we had with Viavi and other Viavi entities.

[0001628280-16-010773:notes:27]
Our consolidated financial statements have been prepared pursuant to the rules and regulations of the SEC and are in conformity with U.S. generally accepted accounting principles (“U.S. GAAP”). In the opinion of management, these consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments, which are necessary for a fair statement of the consolidated financial statements for the periods shown. The results of operations for such periods are not necessarily indicative of the results expected for the full year or for any future periods.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001628280-16-010773:notes:28]
[same as prior period, unchanged from 0001564590-15-010839:notes:48]

[0001628280-16-010773:notes:29]
[same as prior period, unchanged from 0001564590-15-010839:notes:49]

[0001628280-16-010773:notes:30]
On January 27, 2014 ("Time-Bandwidth Closing Date"), we completed the acquisition of Time-Bandwidth Products, Inc. ("Time-Bandwidth"), a privately-held company headquartered in Switzerland. Time-Bandwidth is a provider of high-powered and ultrafast lasers for industrial and scientific markets. We acquired all outstanding shares of Time-Bandwidth for a purchase price consideration of $15.0 million in cash, including a holdback amount of approximately $2.3 million which had been withheld to satisfy potential breaches of representations and warranties. During the first quarter of fiscal 2016, and after the separation from Viavi, we released the holdback amount of $2.3 million following the eighteen-month anniversary of the Time-Bandwidth Closing Date. The payment is classified as a financing activity within the consolidated statements of cash flows for the six months ended   December 26, 2015.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001628280-16-010773:notes:31]
[same as prior period, unchanged from 0001564590-15-010839:notes:2]

[0001628280-16-010773:notes:32]
[same as prior period, unchanged from 0001564590-15-010839:notes:3]

[0001628280-16-010773:notes:33]
Lumentum Holdings Inc. (“we”, “our” or “Lumentum”) is an industry leading provider of optical and photonic products defined by revenue and market share addressing a range of end market applications including data communications (“Datacom”) and telecommunications (“Telecom”) networking and commercial lasers (“commercial lasers”) for manufacturing, inspection and life-science applications. We are using our core optical and photonic technology and our volume manufacturing capability to expand into attractive emerging markets that benefit from advantages that optical or photonics-based solutions provide, including 3-D sensing for consumer electronics and diode light sources for a variety of consumer and industrial applications. The majority of our customers tend to be original equipment manufacturers (“OEMs”) that incorporate our products into their products which then address end-market applications. For example, we sell fiber optic components that our network equipment manufacturer (“NEM”) customers assemble into communications networking systems, which they sell to network service providers or enterprises with their own networks. Similarly, many of our customers for our Lasers products incorporate our products into tools they produce, which are used for manufacturing processes by their customers.

[0001628280-16-010773:notes:34]
[same as prior period, unchanged from 0001564590-15-010839:notes:11]

[0001628280-16-010773:notes:35]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Our fiscal 2016 is a 53-week year ending on July 2, 2016 and our third quarter of fiscal 2016 will include one additional week. Our fiscal 2015 ended on June 27, 2015 and was a 52-week year.

[0001628280-16-010773:notes:36]
Principles of Combination and Consolidation

[0001628280-16-010773:notes:37]
The consolidated financial statements include certain assets and liabilities that were historically held at the Viavi level which were specifically identifiable or otherwise attributable to us. All intra-company transactions within our business were eliminated. All material transactions between us and other businesses of Viavi prior to separation were reflected as net transfers to and from Viavi as a component of financing activities in the consolidated statement of cash flows.

[0001628280-16-010773:notes:38]
[same as prior period, unchanged from 0001564590-15-010839:notes:15]

[0001628280-16-010773:notes:39]
The preparation of our consolidated financial statements in conformity with U.S. GAAP requires Management to make estimates and assumptions that affect the reported amount of assets and liabilities at the date of the financial statements, the reported amount of net revenue and expenses and the disclosure of commitments and contingencies during the reporting periods. We base estimates on historical experience and on various assumptions about the future believed to be reasonable based on available information. Our reported financial position or results of operations may be materially different under changed conditions or when using different estimates and assumptions, particularly with respect to significant accounting policies. If estimates or assumptions differ from actual results, subsequent periods are adjusted to reflect more current information.

[0001628280-16-010773:notes:40]
[same as prior period, unchanged from 0001564590-15-010839:notes:17]

[0001628280-16-010773:notes:41]
There have been no material changes in our significant accounting policies during the six months ended December 26, 2015 compared to the significant accounting policies described in our Annual Report on Form 10-K/A for the fiscal year ended June 27, 2015. The accompanying unaudited interim consolidated financial statements and accompanying related notes should be read in conjunction with the consolidated financial statements and related notes included in our Annual Report on Form 10-K/A for the fiscal year ended June 27, 2015.

[0001628280-16-010773:notes:42]
Correction of Immaterial Error

[0001628280-16-010773:notes:43]
During the three and six months ended December 26, 2015, we identified an error relating to the determination of the accretion amount of Series A preferred stock for the three months ended September 26, 2015 in which the accretion of the discount related to issuance cost of $2.0 million was excluded. As a result, our net loss attributable to common stockholders and basic and diluted net loss per share attributable to common stockholders included in our quarterly report on Form 10-Q ("Form 10-Q") for the three months ended September 26, 2015 was understated by $2.0 million and $0.03 per basic and diluted share, respectively, and the correction of the error in the three months ended December 26, 2015 was an understatement of net income per share attributable to common stockholders by $2.0 million and $0.03 per basic and diluted share. In addition, this error resulted in an understatement of our mezzanine equity and an overstatement of our stockholders' equity by $2.0 million as of September 26, 2015 as included in the Form 10-Q. This error did not impact any annual or other interim periods and has no impact to the net income. We assessed the materiality of this error on the three and six months ended December 26, 2015 and as of September 26, 2015 and the three months ended September 26, 2015 unaudited consolidated financial statements in accordance with the SEC's Staff Accounting Bulletin No.99 and No.108, based on an analysis of quantitative and qualitative factors, determined that this error was not material to our unaudited consolidated financial statements as of September 30, 2015 and for the three months ended September 26, 2015 and the three and six months ended December 26, 2015. Therefore, our unaudited consolidated financial statements as of September 26, 2015 and for the three months ended September 26, 2015 can continue to be relied upon and an amendment of our previously filed Form 10-Q is not required. However, for comparability, the corrected amounts will be revised in the fiscal 2017 Form 10-Qs that will contain such financial information.


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0001628280-16-010773:notes:44]
Note 13. Commitments and Contingencies

[0001628280-16-010773:notes:45]
Operating Leases

[0001628280-16-010773:notes:46]
We lease certain real and personal property from unrelated third parties under non-cancellable operating leases that expire at various dates through fiscal 2026. Certain leases require us to pay property taxes, insurance and routine maintenance, and include escalation clauses. As of December 26, 2015 the future minimum annual lease payments under non-cancellable operating leases were as follows (in millions):

[0001628280-16-010773:notes:47]
| Remainder of 2016 | $ | 2.9 |  |
| 2017 | 5.6 |  |
| 2018 | 4.6 |  |
| 2019 | 3.0 |  |
| 2020 | 1.9 |  |
| Thereafter | 5.0 |  |
| Total minimum operating lease payments | $ | 23.0 |  |

[0001628280-16-010773:notes:48]
Included in the future minimum lease payments table above is $0.8 million related to lease commitments in connection with our restructuring and related activities. Refer to "Note 10. Restructuring and Related Charges" for more information.

[0001628280-16-010773:notes:49]
Purchase Obligations

[0001628280-16-010773:notes:50]
Purchase obligations of $145.5 million as of December 26, 2015, represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule and adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

[0001628280-16-010773:notes:51]
We depend on a limited number of contract manufacturers, subcontractors and suppliers for raw materials, packages and standard components. We generally purchase these single or limited source products through standard purchase orders or one-year supply agreements and have no significant long-term guaranteed supply agreements with such vendors. While we seek to maintain a sufficient safety stock of such products and maintain on-going communications with our suppliers to guard against interruptions or cessation of supply, our business and results of operations could be adversely affected by a stoppage or delay of supply, substitution of more expensive or less reliable products, receipt of defective parts or contaminated materials, increases in the price of such supplies, or our inability to obtain reduced pricing from our suppliers in response to competitive pressures.

[0001628280-16-010773:notes:52]
Product Warranties

[0001628280-16-010773:notes:53]
We provide reserves for the estimated costs of product warranties at the time revenue is recognized. We typically offer a twelve month warranty for most of our products. However, in some instances depending upon the product, product component or application of our products by the end customer, our warranties can vary and generally range from six to thirty-six months. We estimate the costs of our warranty obligations on an annualized basis based on our historical experience of known product failure rates, use of materials to repair or replace defective products and service delivery costs incurred in correcting product failures. In addition, from time to time, specific warranty accruals may be made if unforeseen technical problems arise with specific products. We assess the adequacy of our recorded warranty liabilities and adjust the amounts as necessary.

[0001628280-16-010773:notes:54]
The following table presents the changes in our warranty reserve during the three and six months ended December 26, 2015 and December 27, 2014 (in millions):

[0001628280-16-010773:notes:55]
|  | Three Months Ended |  | Six Months Ended |
|  | December 26, 2015 |  | December 27, 2014 |  | December 26, 2015 |  | December 27, 2014 |
| Balance as of beginning of period | $ | 2.5 |  |  | $ | 2.4 |  |  | $ | 2.8 |  |  | $ | 2.7 |  |
| Provision for warranty | 0.8 |  |  | 0.9 |  |  | 1.7 |  |  | 1.5 |  |
| Utilization of reserve | (0.3 | ) |  | (1.2 | ) |  | (1.5 | ) |  | (2.1 | ) |
| Adjustments related to pre-existing warranties (including changes in estimates) | 0.1 |  |  | (0.1 | ) |  | 0.1 |  |  | (0.1 | ) |
| Balance as of end of period | $ | 3.1 |  |  | $ | 2.0 |  |  | $ | 3.1 |  |  | $ | 2.0 |  |

[0001628280-16-010773:notes:56]
Environmental Liabilities

[0001628280-16-010773:notes:57]
Our R&D, manufacturing and distribution operations involve the use of hazardous substances and are regulated under international, federal, state and local laws governing health and safety and the environment. We apply strict standards for protection of the environment and occupational health and safety to sites inside and outside the United States, even if not subject to regulation imposed by foreign governments. We believe that our properties and operations at our facilities comply in all material respects with applicable environmental laws and occupational health and safety laws. However, the risk of environmental liabilities cannot be completely eliminated and there can be no assurance that the application of environmental and health and safety laws will not require us to incur significant expenditures. We are also regulated under a number of international, federal, state and local laws regarding recycling, product packaging and product content requirements. The environmental, product content/disposal and recycling laws are gradually becoming more stringent and may cause us to incur significant expenditures in the future.

[0001628280-16-010773:notes:58]
In connection with the Separation, we agreed to indemnify Viavi for any liability associated with contamination from past operations at all properties transferred to us from Viavi, to the extent the resulting issues primarily related to our business.

[0001628280-16-010773:notes:59]
Legal Proceedings

[0001628280-16-010773:notes:60]
We are subject to a variety of claims and suits that arise from time to time in the ordinary course of our business. While Management currently believes that resolving claims against us, individually or in the aggregate, will not have a material adverse impact on our financial position, results of operations or statement of cash flows, these matters are subject to inherent uncertainties and management's view of these matters may change in the future. Were an unfavorable final outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the effect becomes reasonably estimable.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001628280-16-010773:notes:61]
Note 5. Accumulated Other Comprehensive (Loss) Income

[0001628280-16-010773:notes:62]
Our accumulated other comprehensive (loss) income consists of the cumulative foreign currency translation adjustments and defined benefit obligation adjustments.

[0001628280-16-010773:notes:63]
At December 26, 2015 and June 27, 2015, balances for the components of accumulated other comprehensive income were as follows (in millions):

[0001628280-16-010773:notes:64]
|  | Foreign currency translation adjustments, net of tax |  | Defined benefit obligation, net of tax |  | Total |
| Beginning balance as of June 27, 2015 | $ | 13.7 |  |  | $ | (1.2 | ) |  | $ | 12.5 |  |
| Other comprehensive loss | (7.0 | ) |  | — |  |  | (7.0 | ) |
| Ending balance as of December 26, 2015 | $ | 6.7 |  |  | $ | (1.2 | ) |  | $ | 5.5 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001628280-16-010773:notes:65]
Note 8. Derivative Liability

[0001628280-16-010773:notes:66]
We estimate the fair value of the embedded derivative for the Series A preferred stock using the binomial lattice model. We applied the binomial lattice model to value the embedded derivative using a "with-and-without method," where the value of the Series A preferred stock including the embedded derivative, is defined as the "with", and the value of the Series A preferred stock excluding the embedded derivative, is defined as the "without". This method estimates the value of the embedded derivative by looking at the difference in the values between the Series A preferred stock with the embedded derivative and the value of the Series A preferred stock without the embedded derivative. The lattice model requires the following inputs: (i) the Company's common stock price; (ii) conversion price; (iii) term; (iv) yield; (v) recovery rate; (vi) estimated stock volatility; and (vii) risk-free rate. The fair value of the embedded derivative was determined using level 3 inputs under the fair value hierarchy (unobservable inputs). Changes in the inputs into this valuation model have a significant impact in the estimated fair value of the embedded derivative. For example, a decrease (increase) in the stock price results in a decrease (increase) in the estimated fair value of the embedded derivative. The changes in the fair value of the bifurcated embedded derivative of $2.4 million and $0.2 million for the three and six months ended December 26, 2015, respectively, is primarily related to the change in the price of the Company's underlying common stock and is reflected in the consolidated statements of operations as "Unrealized loss on derivative liability".


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001628280-16-010773:notes:67]
[same as prior period, unchanged from 0001564590-15-010839:notes:113]

[0001628280-16-010773:notes:68]
[same as prior period, unchanged from 0001564590-15-010839:notes:114]

[0001628280-16-010773:notes:69]
Prior to the Separation, we participated in Viavi’s stock-based benefit plans and recorded stock-based compensation based on the equity awards granted to our employees as well as an allocation of expenses from Viavi’s employees in shared services functions. Upon the Separation, outstanding employee stock options, Restricted Stock Units (RSUs) and Restricted Stock Units based on market conditions previously issued to our employees under the Viavi equity plans were converted into proportionately equivalent Lumentum equity awards under our 2015 Equity Incentive Plan, using a formula designed to preserve the fair value of the awards immediately prior to the Separation. All other terms of the awards remain unchanged. During the first quarter of fiscal 2016, the Restricted Stock Units based on market conditions were modified to performance-based RSUs, and the impact of the modification resulted in additional expenses of $0.1 million.

[0001628280-16-010773:notes:70]
The impact on our results of operations of recording stock-based compensation by function for the three and six months ended December 26, 2015 and December 27, 2014 was as follows (in millions):

[0001628280-16-010773:notes:71]
|  | Three Months Ended |  | Six Months Ended |
|  | December 26, 2015 |  | December 27, 2014 |  | December 26, 2015 |  | December 27, 2014 |
| Cost of sales | $ | 1.5 |  |  | $ | 1.2 |  |  | $ | 2.7 |  |  | $ | 2.6 |  |
| Research and development | 2.3 |  |  | 1.8 |  |  | 4.2 |  |  | 3.7 |  |
| Selling, general and administrative | 2.5 |  |  | 3.7 |  |  | 5.9 |  |  | 7.3 |  |
|  | $ | 6.3 |  |  | $ | 6.7 |  |  | $ | 12.8 |  |  | $ | 13.6 |  |

[0001628280-16-010773:notes:72]
Approximately $1.1 million of stock-based compensation was capitalized in inventory at December 26, 2015. The table above includes allocated stock-based compensation from Viavi of $1.9 million for the three months ended December 27, 2014, and $0.5 million and $3.9 million for the six months ended December 26, 2015 and December 27, 2014, respectively.

[0001628280-16-010773:notes:73]
[same as prior period, unchanged from 0001564590-15-010839:notes:119]

[0001628280-16-010773:notes:74]
We granted no stock options during fiscal 2016 and 2015. The total intrinsic value of options exercised by our employees during the three and six months ended December 26, 2015 was $0.1 million.

[0001628280-16-010773:notes:75]
[same as prior period, unchanged from 0001564590-15-010839:notes:121]

[0001628280-16-010773:notes:76]
During the six months ended December 26, 2015, we granted 1.8 million RSUs, of which 41,000 also have performance conditions. The aggregate grant-date fair value of time-based RSUs and performance-based RSUs are $35.0 million and $0.8 million, respectively. The majority of the time-based RSUs vests over three years, with 33.3% vesting after one year and the balance vesting quarterly over the remaining two years. The vesting of the performance based RSUs is over three years and contingent upon the achievement of specific revenue targets and the employee’s continued service. The performance based RSU shares have a target number of shares, and the actual number of shares awarded upon vesting may be higher or lower depending upon the level of achievement of the performance conditions.

[0001628280-16-010773:notes:77]
A summary of the status of our outstanding RSUs as of December 26, 2015 and changes during the six months ended December 26, 2015 is presented below (amount in millions):

[0001628280-16-010773:notes:78]
|  | Full Value Awards |
|  | Time-based shares |  | Performance-based shares |  | Total number of shares |
| Outstanding at June 27, 2015, as converted | 1.5 |  |  | 0.2 |  |  | 1.7 |  |
| Awards granted | 1.8 |  |  | — |  |  | 1.8 |  |
| Awards vested | (0.4 | ) |  | (0.1 | ) |  | (0.5 | ) |
| Awards cancelled | (0.1 | ) |  | — |  |  | (0.1 | ) |
| Outstanding at December 26, 2015 | 2.8 |  |  | 0.1 |  |  | 2.9 |  |

[0001628280-16-010773:notes:79]
As of December 26, 2015, $49.1 million of unrecognized stock-based compensation cost related to RSUs remains to be amortized. That cost is expected to be recognized over an estimated amortization period of 2.3 years.

[0001628280-16-010773:notes:80]
RSUs are converted into shares upon vesting. Shares equivalent in value to the minimum statutory withholding tax on the vested shares are withheld by the Company at the employees discretion for the payment of such taxes. During the six months ended December 26, 2015 and December 27, 2014, the Company paid $3.9 million and $4.5 million for employee withholding taxes, respectively, and classified the payments as operating cash outflows in the consolidated statements of cash flows.

[0001628280-16-010773:notes:81]
Employee Stock Purchase Plans

[0001628280-16-010773:notes:82]
In June 2015, the Company adopted the 2015 Employee Stock Purchase Plan (the “Plan”). The Plan, which became effective June 23, 2015, provides eligible employees, consultants and directors of the Company and one or more of its parent or subsidiary companies with the opportunity to acquire a proprietary interest in the Company through participation in a plan designed to qualify as an employee stock purchase plan under Section 423 of the Internal Revenue Code. The Plan will terminate on the date on which all shares available for issuance have been sold. The first offering period is from November 17, 2015 to May 15, 2016. The Plan provides a 15% discount on the lesser of (i) the fair market value of a share on the date of purchase or (ii) the fair market value of a share on the commencement date of the purchase period.


## us-gaap:EarningsPerShareTextBlock

[0001628280-16-010773:notes:83]
[same as prior period, unchanged from 0001564590-15-010839:notes:35]

[0001628280-16-010773:notes:84]
[same as prior period, unchanged from 0001564590-15-010839:notes:36]

[0001628280-16-010773:notes:85]
|  | Three Months Ended |  | Six Months Ended |
|  | December 26, 2015 |  | December 27, 2014 |  | December 26, 2015 |  | December 27, 2014 |
| Numerator: |  |  |  |  |  |  |  |  |
| Net income (loss) | $ | 2.8 |  |  | $ | (4.1 | ) |  | $ | 2.6 |  |  | $ | 0.2 |  |
| Less: Cumulative dividends on Series A Preferred Stock | (0.2 | ) |  | — |  |  | (0.3 | ) |  | — |  |
| Less: Accretion of Series A Preferred Stock | (2.0 | ) |  | — |  |  | (11.7 | ) |  | — |  |
| Net income (loss) available to common stockholders | $ | 0.6 |  |  | $ | (4.1 | ) |  | $ | (9.4 | ) |  | $ | 0.2 |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average number of common shares outstanding |  |  |  |  |  |  |  |
| Basic | 59.0 |  |  | 58.8 |  |  | 58.9 |  |  | 58.8 |  |
| Effect of dilutive securities from stock-based benefit plans | 0.2 |  |  | — |  |  | — |  |  | — |  |
| Diluted | 59.2 |  |  | 58.8 |  |  | 58.9 |  |  | 58.8 |  |
| Net income (loss) per share attributable to common stockholders: |  |  |  |  |  |  |  |
| Basic | $ | 0.01 |  |  | $ | (0.07 | ) |  | $ | (0.16 | ) |  | $ | — |  |
| Diluted | $ | 0.01 |  |  | $ | (0.07 | ) |  | $ | (0.16 | ) |  | $ | — |  |

[0001628280-16-010773:notes:86]
On August 1, 2015, JDS Uniphase Corporation (“JDSU”) distributed 47.1 million shares, or 80.1% of the outstanding shares of common stock of Lumentum Holdings Inc. (“we”, “our” or “Lumentum”) to existing holders of JDSU common stock. JDSU was renamed Viavi Solutions Inc. (“Viavi”) and at the time of the distribution, retained 11.7 million shares, or 19.9% of Lumentum's outstanding shares. The weighted average number of common shares outstanding is calculated as the number of shares of common stock outstanding immediately following the Separation, and the weighted average number of shares outstanding following the Separation through December 26, 2015. Diluted earnings per share is calculated by dividing net income for the period by the weighted average number of shares of common stock and potentially dilutive common stock outstanding for the period beginning after the Separation. Basic and diluted net income (loss) per share for the three and six months ended December 27, 2014 is calculated using the shares of Lumentum common stock outstanding on August 1, 2015, as if such shares were outstanding for the entire period.

[0001628280-16-010773:notes:87]
[same as prior period, unchanged from 0001564590-15-010839:notes:39]

[0001628280-16-010773:notes:88]
[same as prior period, unchanged from 0001564590-15-010839:notes:40]

[0001628280-16-010773:notes:89]
[same as prior period, unchanged from 0001564590-15-010839:notes:41]

[0001628280-16-010773:notes:90]
The following table sets forth the weighted-average potentially dilutive securities excluded from the computation of the diluted net income (loss) per share because the effect would have been anti-dilutive (in millions):

[0001628280-16-010773:notes:91]
|  | Three Months Ended |  | Six Months Ended |
|  | December 26, 2015 |  | December 26, 2015 |
| Restricted stock units | — |  |  | 0.1 |  |
| Redeemable convertible preferred stock | 1.5 |  |  | 1.2 |  |
| Stock options and employee stock purchase plan | — |  |  | 0.1 |  |
| Total potentially dilutive securities | 1.5 |  |  | 1.4 |  |


## us-gaap:FiniteLivedIntangibleAssetsAmortizationExpenseTableTextBlock

[0001628280-16-010773:notes:92]
The following table presents details of our amortization relating to acquired developed technology and other intangibles (in millions):

[0001628280-16-010773:notes:93]
|  | Three Months Ended |  | Six Months Ended |
|  | December 26, 2015 |  | December 27, 2014 |  | December 26, 2015 |  | December 27, 2014 |
| Cost of sales | $ | 1.7 |  |  | $ | 1.9 |  |  | $ | 3.4 |  |  | $ | 3.8 |  |
| Operating expense | 0.1 |  |  | 0.1 |  |  | 0.2 |  |  | 0.2 |  |
| Total | $ | 1.8 |  |  | $ | 2.0 |  |  | $ | 3.6 |  |  | $ | 4.0 |  |


## us-gaap:GoodwillDisclosureTextBlock

[0001628280-16-010773:notes:94]
Note 9. Goodwill and Other Intangible Assets

[0001628280-16-010773:notes:95]
Goodwill

[0001628280-16-010773:notes:96]
The following table presents the changes in goodwill allocated to the Lasers reportable segment during the six months ended December 26, 2015 (in millions):

[0001628280-16-010773:notes:97]
|  | Lasers |  | Total |
| Balance as of June 27, 2015 | $ | 5.6 |  |  | $ | 5.6 |  |
| Currency translation and other adjustments | (0.1 | ) |  | (0.1 | ) |
| Balance as of December 26, 2015 | $ | 5.5 |  |  | $ | 5.5 |  |

[0001628280-16-010773:notes:98]
We review goodwill for impairment during the fourth quarter of each fiscal year or more frequently if events or circumstances indicate that an impairment loss may have occurred. In the fourth quarter of fiscal 2015, we completed the annual impairment test of goodwill, which indicated there was no goodwill impairment. During the six months ended December 26, 2015, there have been no events or circumstances that have required us to perform an interim assessment of goodwill for impairment.

[0001628280-16-010773:notes:99]
Acquired Developed Technology and Other Intangibles

[0001628280-16-010773:notes:100]
The following tables present details of our acquired developed technology and other intangibles (in millions):

[0001628280-16-010773:notes:101]
| As of December 26, 2015 | Gross Carrying Amount |  | Accumulated Amortization |  | Net |
| Acquired developed technology | $ | 103.1 |  |  | $ | (85.6 | ) |  | $ | 17.5 |  |
| Other | 9.4 |  |  | (8.8 | ) |  | 0.6 |  |
| Total Intangibles | $ | 112.5 |  |  | $ | (94.4 | ) |  | $ | 18.1 |  |

[0001628280-16-010773:notes:102]
| As of June 27, 2015 | Gross Carrying Amount |  | Accumulated Amortization |  | Net |
| Acquired developed technology | $ | 103.2 |  |  | $ | (82.2 | ) |  | $ | 21.0 |  |
| Other | 9.4 |  |  | (8.6 | ) |  | 0.8 |  |
| Total Intangibles | $ | 112.6 |  |  | $ | (90.8 | ) |  | $ | 21.8 |  |

[0001628280-16-010773:notes:103]
During the three and six months ended December 26, 2015, the Company recorded $1.8 million and $3.6 million, respectively, of amortization expense relating to acquired developed technology and other intangibles.

[0001628280-16-010773:notes:104]
During the three and six months ended December 27, 2014, the Company recorded $2.0 million and $4.0 million, respectively, of amortization expense relating to acquired developed technology and other intangibles.

[0001628280-16-010773:notes:105]
Based on the carrying amount of acquired developed technology and other intangibles as of December 26, 2015, and assuming no future impairment of the underlying assets, the estimated future amortization is as follows (in millions):

[0001628280-16-010773:notes:106]
| Fiscal Years |  |
| Remainder of 2016 | $ | 3.5 |  |
| 2017 | 6.7 |  |
| 2018 | 2.8 |  |
| 2019 | 2.6 |  |
| 2020 | 1.0 |  |
| Thereafter | 1.5 |  |
| Total amortization | $ | 18.1 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-16-010773:notes:107]
Note 11. Income Taxes

[0001628280-16-010773:notes:108]
The Company recorded a tax provision of $0.5 million and $0.2 million for the three and six months ended December 26, 2015, respectively. The Company recorded a tax provision of $0.8 million and $1.4 million for the three and six months ended December 27, 2014. The quarterly provision for income taxes is based on the estimated annual effective tax rate, plus any discrete items for the respective year. During the three months ended September 26, 2015, we recognized a net benefit of $0.3 million of true-up adjustments in our foreign jurisdictions.

[0001628280-16-010773:notes:109]
The Company updates its estimated annual effective tax rate at the end of each quarterly period. The estimate takes into account the estimates for annual pre-tax income, the geographic mix of pre-tax income and interpretations of tax laws. The difference between the provision for income taxes that would be derived by applying the statutory rate to the Company’s income (loss) before income taxes and the provision for income taxes recorded for the three and six months ended December 26, 2015 and December 27, 2014 was primarily attributable to the difference in foreign tax rates, utilization of US tax attributes that were subject to a full valuation allowance, and certain Canadian tax incentives.

[0001628280-16-010773:notes:110]
In November 2015, the FASB issued ASU 2015-17, “Balance Sheet Classification of Deferred Taxes”, which simplifies the presentation of deferred income taxes. This ASU requires that deferred tax assets and liabilities be classified as non-current in a statement of financial position. We early adopted ASU 2015-17 effective December 26, 2015 on a prospective basis. Adoption of this ASU resulted in the reclassification of our net current deferred tax asset of $0.1 million to the net non-current deferred tax asset, and the current deferred tax liability of $0.5 million to the non-current deferred tax liability on our Consolidated Balance Sheet as of December 26, 2015. No prior periods were retrospectively adjusted.

[0001628280-16-010773:notes:111]
The Company’s net deferred tax assets relate predominantly to the Canadian tax jurisdiction and the Company has a partial valuation allowance against these deferred tax assets. The Company weighed both positive and negative evidence and determined that due to the limited carryover period of certain tax attributes in Canada, there is a continued need for a partial valuation allowance against these deferred tax assets as of December 26, 2015. Should the Company determine that it needs to adjust the valuation allowance, the adjustment may have a material impact to net income in the period such determination is made.

[0001628280-16-010773:notes:112]
The Company also evaluates the realizability of its U.S. net deferred tax assets based on all available evidence, both positive and negative, on a quarterly basis. The realization of net deferred tax assets is dependent on the Company’s ability to generate sufficient future taxable income during periods prior to the expiration of tax attributes to fully utilize these assets. The Company weighed both positive and negative evidence and determined that due to cumulative losses in the U.S., there is a continued need for a full valuation allowance against the U.S. deferred tax assets as of December 26, 2015.

[0001628280-16-010773:notes:113]
[same as prior period, unchanged from 0001564590-15-010839:notes:87]

[0001628280-16-010773:notes:114]
In addition, the Company is in the process of evaluating its international operational footprint, which could result in future changes to the Company’s legal entity structure and operating model. A wholly-owned foreign subsidiary of the Company acquired certain rights to sell the existing products and also those products to be developed or licensed in the future and will also share in the research and development cost. The existing rights were transferred to its wholly-owned foreign subsidiary prior to the Separation. As a result of these changes, the Company expects that an increasing percentage of its consolidated pre-tax income will be derived from, and reinvested in, its foreign operations. The Company anticipates that this pre-tax income will be subject to foreign tax at relatively lower tax rates when compared to the U.S. federal statutory tax rate and as a consequence, the Company’s effective income tax rate is expected to be lower than the U.S. federal statutory rate.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001628280-16-010773:notes:115]
In January 2016, the Financial Accounting Standards Board (“FASB”) issued guidance related to recognition and measurement of financial assets and financial liabilities. This guidance addresses certain aspects of recognition, measurement, presentation, and disclosure of financial statements. The guidance is effective for us in the first quarter of fiscal 2019. We are evaluating the impact of adopting this new accounting guidance on our consolidated financial statements.

[0001628280-16-010773:notes:116]
In November 2015, the FASB issued guidance related to balance sheet classification of deferred taxes. This guidance will require that deferred tax liabilities and assets be classified as noncurrent in a classified statement of financial position. The guidance is effective for us in the first quarter of fiscal 2018. Earlier application is permitted as of the beginning of an interim or annual reporting period. We early adopted this guidance effective December 26, 2015 on a prospective basis. No prior periods were retrospectively adjusted. Refer to "Note 11. Income Taxes" for more information.

[0001628280-16-010773:notes:117]
In July 2015, the FASB issued guidance to change the subsequent measurement of inventory from lower of cost or market to lower of cost and net realizable value. The guidance is effective for us in the first quarter of fiscal 2018. Earlier application is permitted as of the beginning of an interim or annual reporting period. We are evaluating the impact of adopting this new accounting guidance on our consolidated financial statements.

[0001628280-16-010773:notes:118]
In May 2015, the FASB issued guidance to remove the requirement to categorize within the fair value hierarchy all investments for which fair value is measured using a net asset value per share practical expedient. The guidance is effective for us in the first quarter of fiscal 2017 and may apply to certain pension assets. The guidance will be applied retrospectively and earlier adoption is permitted. We are evaluating the impact of adopting this new accounting guidance on our consolidated financial statements.

[0001628280-16-010773:notes:119]
In April 2015, the FASB issued new authoritative guidance to provide a practical expedient that permits the entity to measure defined benefit plan assets and obligations using the month-end that is closest to the entity’s fiscal year-end and apply that practical expedient consistently from year to year. This guidance is effective for us in the first quarter of fiscal 2017. Prospective application is required, and early adoption is permitted. We are evaluating the impact of adopting this new accounting guidance on our consolidated financial statements.

[0001628280-16-010773:notes:120]
In May 2014, the FASB issued new authoritative guidance related to revenue recognition. This guidance will replace current U.S. GAAP guidance on this topic and eliminate industry-specific guidance. The new revenue recognition guidance provides a unified model to determine when and how revenue is recognized. The core principle is that a company should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration for which the entity expects to be entitled in exchange for those goods or services. This guidance allows for either full retrospective adoption or modified retrospective adoption. The FASB deferred the effective date for this guidance by one year to December 15, 2017 for annual reporting periods beginning after that. Earlier application of this guidance is permitted but not before the original date of December 15, 2016. We are evaluating the impact that this new accounting guidance will have on our consolidated financial statements and the related disclosures.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001628280-16-010773:notes:121]
Note 3. Related Party Transactions

[0001628280-16-010773:notes:122]
Transactions with Viavi

[0001628280-16-010773:notes:123]
Agreements with Viavi

[0001628280-16-010773:notes:124]
On July 31, 2015, the Company entered into a Supply Agreement with Viavi providing that each party will supply certain products at pre-determined prices, and providing Viavi with research and development services at cost plus a specified markup. The Company has also agreed to supply office space via a sublease agreement to Viavi. The sublease income and research and development cost reimbursements are each recorded as contra operating expenses in the Consolidated Statements of Operations for the six months ended December 26, 2015.

[0001628280-16-010773:notes:125]
The Supply Agreement contains a $15.0 million purchase commitment with Viavi for certain products, and for the three and six months ended December 26, 2015, the Company purchased $6.5 million in product from Viavi against the $15.0 million purchase commitment. During the three and six months ended December 26, 2015, the Company recognized revenue of $0.7 million and  $1.5 million, respectively, due to products sold to Viavi. For the three and six months ended December 26, 2015, the Company recorded $0.7 million and $1.2 million, respectively, in research and development cost reimbursement and $0.2 million and $0.3 million, respectively, in sublease rental income. As of December 26, 2015, the Company had $1.0 million in accounts receivable due from Viavi.

[0001628280-16-010773:notes:126]
On July 31, 2015, the Company also entered into the following agreements with Viavi:

[0001628280-16-010773:notes:127]
| a) | Contribution Agreement which identifies the assets to be transferred, the liabilities to be assumed and the contracts to be assigned and it provides for when and how these transfers, assumptions and assignments will occur. |

[0001628280-16-010773:notes:128]
| b) | Separation and Distribution Agreement which governs the separation of the Lumentum business and other matters related to Lumentum’s relationship with Viavi. |

[0001628280-16-010773:notes:129]
| c) | Tax Matters Agreement which governs the respective rights, responsibilities and obligations of Lumentum and Viavi with respect to tax liabilities and benefits, attributes, proceedings, returns and certain other tax matters. |

[0001628280-16-010773:notes:130]
| d) | Employee Matters Agreement which governs the compensation and employee benefit obligations with respect to the current and former employees of Lumentum and Viavi, the treatment of equity based compensation and generally allocates liabilities and responsibilities relating to employee compensation, benefit plans and programs. The Employee Matters Agreement provides that employees of Lumentum will participate in benefit plans sponsored or maintained by Lumentum. |

[0001628280-16-010773:notes:131]
| e) | Securities Purchase Agreement, which also includes Amada Holdings Co., Ltd. (“Amada”) as a party, which sets forth the terms for the sale by Viavi to Amada of shares of Series A Preferred Stock of Lumentum Inc., our wholly-owned subsidiary, following the Separation. |

[0001628280-16-010773:notes:132]
| f) | Intellectual Property Matters Agreement which outlines the intellectual property rights of Lumentum and Viavi following the Separation, as well as non-compete restrictions between Viavi and Lumentum. |

[0001628280-16-010773:notes:133]
Allocated Costs

[0001628280-16-010773:notes:134]
The consolidated statements of operations includes our direct expenses for cost of sales, research and development, sales and marketing, and administration as well as allocations of expenses arising from shared services and infrastructure provided by Viavi to us. These allocated expenses include costs of information technology, human resources, accounting, legal, real estate and facilities, corporate marketing, insurance, treasury and other corporate and infrastructure services. In addition, other costs allocated to us include restructuring and stock-based compensation related to Viavi’s corporate and shared services employees and are included in the table below. These expenses are allocated to us using estimates that we consider to be a reasonable reflection of the utilization of services or benefits received by our business. The allocation methods include revenue, headcount, square footage, actual consumption and usage of services and others.

[0001628280-16-010773:notes:135]
Allocated costs included in the accompanying consolidated statements of operations are as follows (in millions):

[0001628280-16-010773:notes:136]
|  | Three Months Ended |  | Six Months Ended |
|  | December 26, 2015 |  | December 27, 2014 |  | December 26, 2015 |  | December 27, 2014 |
| Selling, general and administrative | $ | — |  |  | $ | 19.8 |  |  | $ | 11.7 |  |  | $ | 36.6 |  |
| Restructuring and related charges | — |  |  | 3.2 |  |  | — |  |  | 3.2 |  |
| Interest and other (income) expenses, net | — |  |  | (0.1 | ) |  | (0.1 | ) |  | — |  |
| Interest expense | — |  |  | 0.2 |  |  | 0.1 |  |  | 0.4 |  |
| Total allocated costs | $ | — |  |  | $ | 23.1 |  |  | $ | 11.7 |  |  | $ | 40.2 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001628280-16-010773:notes:137]
Note 10. Restructuring and Related Charges

[0001628280-16-010773:notes:138]
We have initiated various strategic restructuring events primarily intended to reduce costs and align our business in response to the market conditions. As of December 26, 2015 and June 27, 2015, our total restructuring and related charges accrual was $4.3 million and $4.9 million, respectively. During the three and six months ended December 26, 2015, we recorded $1.1 million and $2.1 million, respectively, in restructuring and related charges in the consolidated statements of operations. During the three and six months ended December 27, 2014, we recorded $3.8 million and $5.6 million, respectively, in restructuring and related charges in the consolidated statements of operations. Our restructuring charges include severance and benefit costs to eliminate a specified number of positions, facilities and equipment costs to vacate facilities and consolidate operations, and lease termination costs. The timing of associated cash payments is dependent upon the type of restructuring charge and can extend over multiple periods.

[0001628280-16-010773:notes:139]
[same as prior period, unchanged from 0001564590-15-010839:notes:74]

[0001628280-16-010773:notes:140]
The adjustments to the accrued restructuring expenses related to all of our restructuring plans described below for the three and six months ended December 26, 2015, were as follows (in millions):

[0001628280-16-010773:notes:141]
|  | Balance June 27,2015 |  | Accrued |  | Cash Settlements |  | BalanceDecember 26,2015 |
| Fiscal 2015 Plans |  |  |  |  |  |  |  |
| Separation Restructuring Plan (Workforce Reduction) | $ | 4.6 |  |  | $ | 0.7 |  |  | $ | (1.4 | ) |  | $ | 3.9 |  |
| Fiscal 2013 Plans |  |  |  |  |  |  |  |
| Other Plans | 0.3 |  |  | 0.1 |  |  | — |  |  | 0.4 |  |
| Total | $ | 4.9 |  |  | $ | 0.8 |  |  | $ | (1.4 | ) |  | $ | 4.3 |  |

[0001628280-16-010773:notes:142]
As of December 26, 2015, all of the $4.3 million accrual was included in other current liabilities on the consolidated balance sheets. As of June 27, 2015, $3.2 million was included in other current liabilities, and $1.7 million was included in other non-current liabilities on the consolidated balance sheets.

[0001628280-16-010773:notes:143]
Fiscal 2015 Plans

[0001628280-16-010773:notes:144]
[same as prior period, unchanged from 0001564590-15-010839:notes:76]

[0001628280-16-010773:notes:145]
During the second and fourth quarter of fiscal 2015, Management approved restructuring plans impacting our Optical Communications (“OpComms”) segment to optimize manufacturing operations and gain efficiencies which include closing the Bloomfield, Connecticut site and consolidating roles and responsibilities across functions as we move forward with our separation plan. As a result, approximately 200 employees in manufacturing, R&D and SG&A functions located in North America, Europe and Asia will be impacted. For the three and six months ended December 26, 2015, the Company recorded $(0.3) million and $0.7 million, respectively, of expenses for adjusting severance and retention costs related to the restructuring plan implemented in the fourth quarter of 2015. Payments related to the remaining severance and benefits accrual are expected to be paid through fiscal year 2017.

[0001628280-16-010773:notes:146]
[same as prior period, unchanged from 0001564590-15-010839:notes:80]

[0001628280-16-010773:notes:147]
During fiscal 2008, we recorded lease exit charges, net of assumed sub-lease income related to our Ottawa facility which was included in selling, general and administrative expenses as the space was never occupied and we had no need for the space in the foreseeable future due to changes in business requirements.  For the three and six months ended December 26, 2015, we had cash settlements of $0.2 million and $0.3 million, respectively. The fair value of the remaining contractual obligations, net of sublease income is $0.8 million and $1.1 million as of December 26, 2015 and June 27, 2015, respectively. As of December 26, 2015 and June 27, 2015, $0.5 million and $0.6 million was included in other current liabilities, and $0.3 million and $0.5 million in other non-current liabilities, respectively, on the consolidated balance sheets. The payments related to these lease costs are expected to be paid by the end of the third quarter of fiscal 2018.


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001628280-16-010773:notes:148]
The following table presents net revenue by the three geographic regions we operate in and net revenue from countries that exceeded 10% of our total net revenue  (in millions, except for percentages) :

[0001628280-16-010773:notes:149]
|  | Three Months Ended |  | Six Months Ended |
|  | December 26, 2015 |  | December 27, 2014 |  | December 26, 2015 |  | December 27, 2014 |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States | $ | 28.0 |  |  | 12.8 | % |  | $ | 41.1 |  |  | 19.5 | % |  | $ | 62.5 |  |  | 14.5 | % |  | $ | 83.5 |  |  | 19.4 | % |
| Mexico | 36.5 |  |  | 16.7 |  |  | 23.6 |  |  | 11.2 |  |  | 78.3 |  |  | 18.2 |  |  | 50.1 |  |  | 11.7 |  |
| Other Americas | 5.0 |  |  | 2.3 |  |  | 7.5 |  |  | 3.6 |  |  | 12.8 |  |  | 3.0 |  |  | 13.8 |  |  | 3.2 |  |
| Total Americas | $ | 69.5 |  |  | 31.8 | % |  | $ | 72.2 |  |  | 34.3 | % |  | $ | 153.6 |  |  | 35.7 | % |  | $ | 147.4 |  |  | 34.3 | % |
| Asia-Pacific: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Hong Kong | $ | 51.8 |  |  | 23.8 | % |  | $ | 34.0 |  |  | 16.1 | % |  | $ | 82.6 |  |  | 19.1 | % |  | $ | 62.7 |  |  | 14.6 | % |
| Japan | 21.0 |  |  | 9.6 |  |  | 34.9 |  |  | 16.6 |  |  | 46.0 |  |  | 10.7 |  |  | 70.8 |  |  | 16.5 |  |
| Thailand | 25.5 |  |  | 11.7 |  |  | 14.7 |  |  | 7.0 |  |  | 44.0 |  |  | 10.2 |  |  | 29.7 |  |  | 6.9 |  |
| Other Asia-Pacific | 20.8 |  |  | 9.5 |  |  | 23.9 |  |  | 11.4 |  |  | 42.3 |  |  | 9.8 |  |  | 50.0 |  |  | 11.7 |  |
| Total Asia-Pacific | $ | 119.1 |  |  | 54.6 | % |  | $ | 107.5 |  |  | 51.1 | % |  | $ | 214.9 |  |  | 49.8 | % |  | $ | 213.2 |  |  | 49.7 | % |
| EMEA | $ | 29.7 |  |  | 13.6 | % |  | $ | 30.8 |  |  | 14.6 | % |  | $ | 62.4 |  |  | 14.5 | % |  | $ | 68.9 |  |  | 16.0 | % |
| Total net revenue | $ | 218.3 |  |  |  |  | $ | 210.5 |  |  |  |  | $ | 430.9 |  |  |  |  | $ | 429.5 |  |  |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001628280-16-010773:notes:150]
Information on reportable segments utilized by our CODM is as follows (in millions):

[0001628280-16-010773:notes:151]
|  | Three Months Ended |  | Six Months Ended |
|  | December 26, 2015 |  | December 27, 2014 |  | December 26, 2015 |  | December 27, 2014 |
| Net revenue: |  |  |  |  |  |  |  |
| OpComms | $ | 185.8 |  |  | $ | 171.1 |  |  | $ | 362.9 |  |  | $ | 348.0 |  |
| Lasers | 32.5 |  |  | 39.4 |  |  | 68.0 |  |  | 81.5 |  |
| Net revenue | $ | 218.3 |  |  | $ | 210.5 |  |  | $ | 430.9 |  |  | $ | 429.5 |  |
| Gross profit: |  |  |  |  |  |  |  |
| OpComms | 57.1 |  |  | 50.4 |  |  | 112.7 |  |  | 103.2 |  |
| Lasers | 14.2 |  |  | 20.1 |  |  | 28.4 |  |  | 41.4 |  |
| Total segment gross profit | 71.3 |  |  | 70.5 |  |  | 141.1 |  |  | 144.6 |  |
| Unallocated amounts: |  |  |  |  |  |  |  |
| Stock-based compensation | (1.5 | ) |  | (1.2 | ) |  | (2.7 | ) |  | (2.6 | ) |
| Amortization of intangibles | (1.7 | ) |  | (1.9 | ) |  | (3.4 | ) |  | (3.8 | ) |
| Other charges related to non-recurring activities | — |  |  | (0.5 | ) |  | — |  |  | (1.0 | ) |
| Gross profit | $ | 68.1 |  |  | $ | 66.9 |  |  | $ | 135.0 |  |  | $ | 137.2 |  |


## us-gaap:SchedulesOfConcentrationOfRiskByRiskFactorTextBlock

[0001628280-16-010773:notes:152]
The table below discloses the percentage of our total net revenue attributable to each of our two reportable segments. In addition, it discloses the percentage of our total net revenue attributable to our product offerings which serve the Telecom, Datacom and consumer and industrial ("Consumer and Industrial"):

[0001628280-16-010773:notes:153]
|  | Three Months Ended |  | Six Months Ended |
|  | December 26, 2015 |  | December 27, 2014 |  | December 26, 2015 (a) |  | December 27, 2014 |
| Optical Communications: | 85.1 | % |  | 81.3 | % |  | 84.2 | % |  | 81.0 | % |
| Telecom | 63.1 | % |  | 59.8 | % |  | 62.8 | % |  | 60.8 | % |
| Datacom | 16.0 | % |  | 16.8 | % |  | 16.4 | % |  | 15.3 | % |
| Consumer and Industrial | 6.0 | % |  | 4.7 | % |  | 5.0 | % |  | 4.9 | % |
| Lasers | 14.9 | % |  | 18.7 | % |  | 15.8 | % |  | 19.0 | % |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001628280-16-010773:notes:154]
[same as prior period, unchanged from 0001564590-15-010839:notes:144]

[0001628280-16-010773:notes:155]
Our chief executive officer is our Chief Operating Decision Maker ("CODM"). The CODM allocates resources to the segments based on their business prospects, competitive factors, net revenue and gross margin.

[0001628280-16-010773:notes:156]
We are an industry leading provider of optical and photonic products defined by revenue and market share addressing a range of end-market applications including optical communications and commercial lasers. We have two operating segments, OpComms and Commercial Lasers ("Lasers"). The two operating segments were primarily determined based on how the CODM views and evaluates our operations. Operating results are regularly reviewed by the CODM to make decisions about resources to be allocated to the segments and to assess their performance. Other factors, including market separation and customer specific applications, go-to-market channels, products and manufacturing, are considered in determining the formation of these operating segments.

[0001628280-16-010773:notes:157]
[same as prior period, unchanged from 0001564590-15-010839:notes:147]

[0001628280-16-010773:notes:158]
| (i) | OpComms: Our OpComms portfolio includes products used by Telecom and Datacom network equipment manufacturers (“NEMs”) and both traditional and cloud/data center service providers. These products enable the transmission and transport of video, audio and text data over high-capacity fiber optic cables. Transmission products primarily consist of optical transceivers, optical transponders, and their supporting components such as modulators and source lasers, including innovative products such as the Tunable Small Form-factor Pluggable Plus transceiver. Transport products primarily consist of modules or sub-systems containing optical amplifiers, reconfigurable optical add/drop multiplexers (“ROADMs”) or Wavelength Selective Switches, Optical Channel Monitors and their supporting components. Our products for 3-D sensing applications, formerly referred to as our gesture recognition products, include light source products. Customer solutions containing our 3-D sensing products let a person control electronic or computer devices with natural body or hand gestures instead of using a remote, mouse or other device. |

[0001628280-16-010773:notes:159]
| (ii) | Commercial Lasers: Our Lasers products serve customers in markets and applications such as manufacturing, biotechnology, graphics and imaging, remote sensing, and precision machining such as drilling in printed circuit boards, wafer singulation and solar cell scribing. These products include diode, direct-diode, diode-pumped solid-state, fiber and gas lasers. In addition, our photonic power products include fiber optic-based systems for delivering and measuring electrical power. |

[0001628280-16-010773:notes:160]
[same as prior period, unchanged from 0001564590-15-010839:notes:150]

[0001628280-16-010773:notes:161]
We operate in three geographic regions: Americas, Asia-Pacific and Europe, Middle East and Africa (“EMEA”). Net revenue is assigned to the geographic region and country where our product is initially shipped. For example, certain customers may request shipment of our product to a contract manufacturer in one country, which may differ from the location of their end customers. The following table presents net revenue by the three geographic regions we operate in and net revenue from countries that exceeded 10% of our total net revenue  (in millions, except for percentages) :

[0001628280-16-010773:notes:162]
During the six months ended December 26, 2015 and December 27, 2014, net revenue from customers outside the U.S., based on customer shipping location, represented 85.5% and 80.6% of net revenue, respectively. During the three months ended December 26, 2015 and December 27, 2014, net revenue from customers outside the U.S., based on customer shipping location, represented 87.2% and 80.5% of net revenue, respectively. Our net revenue is primarily denominated in U.S. dollars, including our net revenue from customers outside the United States as presented above.
