# LITE MD&A — 0001628280-18-013240


## mdna

[0001628280-18-013240:mdna:1]
[same as prior period, unchanged from 0001633978-18-000030:mdna:1]

[0001628280-18-013240:mdna:2]
[same as prior period, unchanged from 0001633978-18-000030:mdna:2]

[0001628280-18-013240:mdna:3]
[same as prior period, unchanged from 0001633978-18-000030:mdna:3]

[0001628280-18-013240:mdna:4]
[same as prior period, unchanged from 0001633978-18-000030:mdna:4]

[0001628280-18-013240:mdna:5]
[same as prior period, unchanged from 0001633978-18-000030:mdna:5]

[0001628280-18-013240:mdna:6]
We see the world as becoming more reliant on ever-increasing amounts of data flowing through optical networks and data centers, which demand new networks and data centers to be built to satisfy this insatiable demand for data. As higher levels of precision, new materials, factory and energy efficiency are being demanded by manufacturers, suppliers of manufacturing tools globally are turning more and more to laser based approaches, including the types of lasers Lumentum supplies. Laser based 3D sensing is a rapidly developing market. The technology enables computer vision applications that enhance security, safety, and new functionality in the electronic devices that people rely on every day. We believe the global markets in which Lumentum participates have fundamentally robust, long-term trends that increase the need for our photonics products and technologies.

[0001628280-18-013240:mdna:7]
On March 11, 2018, we entered into an Agreement and Plan of Merger (the “Merger Agreement”) with Oclaro, Inc. (“Oclaro”), Prota Merger Sub, Inc., and Prota Merger, LLC, pursuant to which we will acquire Oclaro and Oclaro will become a wholly-owned subsidiary of Lumentum. In accordance with the terms of the Merger Agreement, each issued and outstanding share of Oclaro common stock will be exchanged for $5.60 in cash and 0.0636 of a share of Lumentum common stock, subject to the conditions and restrictions set forth in the Merger Agreement. The total transaction consideration was approximately $1.8 billion as of the date of the Merger Agreement. Oclaro stockholders are expected to own approximately 16% of the combined company following the closing. Oclaro’s stockholders approved the Merger Agreement on July 10, 2018 and we have received approval for the transaction under the Hart-Scott Rodino Act in the United States. We are in the process of obtaining antitrust approval in China. The Merger Agreement contains certain termination rights for both Lumentum and Oclaro. The Merger Agreement further provides that upon termination of the Merger Agreement under specified circumstances relating to failure to obtain regulatory approvals, Lumentum may be required to pay Oclaro a termination fee of $80 million.

[0001628280-18-013240:mdna:8]
As of October 26, 2018, the total transaction consideration was expected to be approximately $1.6 billion, which would be funded by a combination of $600 million in Lumentum common stock, $500 million in new debt, and the remaining amount from the cash balances of the combined company.

[0001628280-18-013240:mdna:9]
[same as prior period, unchanged from 0001633978-18-000030:mdna:10]

[0001628280-18-013240:mdna:10]
[same as prior period, unchanged from 0001633978-18-000030:mdna:11]

[0001628280-18-013240:mdna:11]
[same as prior period, unchanged from 0001633978-18-000030:mdna:12]

[0001628280-18-013240:mdna:12]
[same as prior period, unchanged from 0001633978-18-000030:mdna:13]

[0001628280-18-013240:mdna:13]
[same as prior period, unchanged from 0001633978-18-000030:mdna:14]

[0001628280-18-013240:mdna:14]
[same as prior period, unchanged from 0001633978-18-000030:mdna:15]

[0001628280-18-013240:mdna:15]
[same as prior period, unchanged from 0001633978-18-000030:mdna:16]

[0001628280-18-013240:mdna:16]
[same as prior period, unchanged from 0001633978-18-000030:mdna:17]

[0001628280-18-013240:mdna:17]
[same as prior period, unchanged from 0001633978-18-000030:mdna:18]

[0001628280-18-013240:mdna:18]
[same as prior period, unchanged from 0001633978-18-000030:mdna:19]

[0001628280-18-013240:mdna:19]
Except for the accounting policies for revenue recognition and the related accounts updated as a result of adopting ASU 2014-09 (Topic 606), there have been no significant changes to our significant accounting policies as of and for the three months ended September 29, 2018, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the year ended June 30, 2018. Refer to “Note 1. Description of Business and Summary of Significant Accounting Policies” for the details of ASU 2014-09 (Topic 606) adoption. Management’s Discussion and Analysis of Financial Condition and Results of Operations contained in Part II, Item 7 of our Annual Report on Form 10-K for our fiscal year ended June 30, 2018 provides a more complete discussion of our critical accounting policies and estimates.

[0001628280-18-013240:mdna:20]
Recently Issued Accounting Pronouncements

[0001628280-18-013240:mdna:21]
Refer to “Note 2. Recently Issued Accounting Pronouncements” in the Notes to Unaudited Condensed Consolidated Financial Statements.

[0001628280-18-013240:mdna:22]
33

[0001628280-18-013240:mdna:23]
[same as prior period, unchanged from 0001633978-18-000030:mdna:41]

[0001628280-18-013240:mdna:24]
[same as prior period, unchanged from 0001633978-18-000030:mdna:42]

[0001628280-18-013240:mdna:25]
|  | Three Months Ended |
|  | September 29, 2018 |  | September 30, 2017 |
| Segment net revenue: |  |  |  |
| OpComms | 87.6 | % |  | 85.5 | % |
| Lasers | 12.4 |  |  | 14.5 |  |
| Net revenue | 100.0 |  |  | 100.0 |  |
| Cost of sales | 64.2 |  |  | 71.5 |  |
| Amortization of acquired developed technologies | 0.2 |  |  | 0.3 |  |
| Gross profit | 35.6 |  |  | 28.2 |  |
| Operating expenses: |  |  |  |
| Research and development | 9.8 |  |  | 14.9 |  |
| Selling, general and administrative | 9.3 |  |  | 10.9 |  |
| Restructuring and related charges | 0.4 |  |  | 1.2 |  |
| Total operating expenses | 19.5 |  |  | 27.0 |  |
| Income from operations | 16.1 |  |  | 1.2 |  |
| Unrealized gain (loss) on derivative liability | (0.6 | ) |  | 1.7 |  |
| Interest and other income (expense), net | (0.7 | ) |  | (1.4 | ) |
| Income before income taxes | 14.9 |  |  | 1.5 |  |
| Provision for (benefit from) income taxes | 1.5 |  |  | (1.4 | ) |
| Net income | 13.4 | % |  | 2.9 | % |

[0001628280-18-013240:mdna:26]
Financial Data for the three months ended September 29, 2018 and September 30, 2017

[0001628280-18-013240:mdna:27]
[same as prior period, unchanged from 0001633978-18-000030:mdna:45]

[0001628280-18-013240:mdna:28]
|  | Three Months Ended |  |  |  |  |
|  | September 29, 2018 |  | September 30, 2017 |  | Change |  | Percentage Change |
| Segment net revenue: |  |  |  |  |  |  |  |
| OpComms | $ | 310.1 |  |  | $ | 207.9 |  |  | $ | 102.2 |  |  | 49.2 | % |
| Lasers | 44.0 |  |  | 35.3 |  |  | 8.7 |  |  | 24.6 |  |
| Net revenue | $ | 354.1 |  |  | $ | 243.2 |  |  | $ | 110.9 |  |  | 45.6 | % |
| Gross profit | $ | 126.0 |  |  | $ | 68.5 |  |  | $ | 57.5 |  |  | 83.9 | % |
| Gross margin | 35.6 | % |  | 28.2 | % |  |  |  |  |
| Research and development | $ | 34.6 |  |  | $ | 36.3 |  |  | $ | (1.7 | ) |  | (4.7 | )% |
| Percentage of net revenue | 9.8 | % |  | 14.9 | % |  |  |  |  |
| Selling, general and administrative | $ | 33.0 |  |  | $ | 26.6 |  |  | $ | 6.4 |  |  | 24.1 | % |
| Percentage of net revenue | 9.3 | % |  | 10.9 | % |  |  |  |  |
| Restructuring and related charges | $ | 1.3 |  |  | $ | 2.9 |  |  | $ | (1.6 | ) |  | (55.2 | )% |
| Percentage of net revenue | 0.4 | % |  | 1.2 | % |  |  |  |  |

[0001628280-18-013240:mdna:29]
[same as prior period, unchanged from 0001633978-18-000030:mdna:47]

[0001628280-18-013240:mdna:30]
Net revenue increased by $110.9 million, or 45.6%, during the three months ended September 29, 2018 compared to the three months ended September 30, 2017. This increase was primarily due to increased sales in 3D sensing, Telecom, and Lasers products.

[0001628280-18-013240:mdna:31]
OpComms net revenue increased by $102.2 million, or 49.2%, during the three months ended September 29, 2018 compared to the three months ended September 30, 2017, driven by increased sales of Telecom products of $32.5 million and of Consumer and Industrial products of $80.7 million, primarily in 3D sensing for mobile devices, partially offset by decreased sales of Datacom products of $11.0 million.

[0001628280-18-013240:mdna:32]
Lasers net revenue increased by $8.7 million, or 24.6%, during the three months ended September 29, 2018 compared to the three months ended September 30, 2017, primarily due to increased sales of our kilowatt class fiber lasers, offset by lower sales of our solid state lasers.

[0001628280-18-013240:mdna:33]
During the three months ended September 29, 2018 and September 30, 2017, net revenue generated from a single customer which represented 10% or greater of total net revenue is summarized as follows:

[0001628280-18-013240:mdna:34]
|  | Three Months Ended |
|  | September 29, 2018 |  | September 30, 2017 |
| Customer A | 30.5 | % |  | 16.3 | % |
| Customer B | 15.0 | % |  | * |  |
| Customer C | 13.0 | % |  | 14.2 | % |
| Customer D | * |  |  | 10.4 | % |
| *Represents less than 10% of total net revenue |  |  |  |

[0001628280-18-013240:mdna:35]
[same as prior period, unchanged from 0001633978-18-000030:mdna:53]

[0001628280-18-013240:mdna:36]
We operate in three geographic regions: Americas, Asia-Pacific and EMEA. Net revenue is assigned to the geographic region and country where our product is initially shipped. For example, certain customers may request shipment of our product to a contract manufacturer in one country, however, the location of the end customers may differ. The following table presents net revenue by the three geographic regions we operate in and net revenue from countries within those regions that represented 10% or more of our total net revenue (in millions, except for percentages):

[0001628280-18-013240:mdna:37]
|  | Three Months Ended |
|  | September 29, 2018 |  | September 30, 2017 |
| Net revenue: |  |  |  |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |
| United States | $ | 21.9 |  |  | 6.2 | % |  | $ | 33.6 |  |  | 13.8 | % |
| Mexico | 56.3 |  |  | 15.9 |  |  | 24.8 |  |  | 10.3 |  |
| Other Americas | 0.9 |  |  | 0.3 |  |  | 2.2 |  |  | 0.9 |  |
| Total Americas | $ | 79.1 |  |  | 22.4 | % |  | $ | 60.6 |  |  | 25.0 | % |
| Asia-Pacific: |  |  |  |  |  |  |  |
| Hong Kong | $ | 65.5 |  |  | 18.5 | % |  | $ | 48.9 |  |  | 20.1 | % |
| Japan | 36.1 |  |  | 10.2 |  |  | 34.1 |  |  | 14.0 |  |
| South Korea | 70.0 |  |  | 19.8 |  |  | 10.9 |  |  | 4.5 |  |
| Other Asia-Pacific | 74.1 |  |  | 20.9 |  |  | 63.3 |  |  | 26.0 |  |
| Total Asia-Pacific | $ | 245.7 |  |  | 69.4 | % |  | $ | 157.2 |  |  | 64.6 | % |
| EMEA | $ | 29.3 |  |  | 8.2 | % |  | $ | 25.4 |  |  | 10.4 | % |
| Total net revenue | $ | 354.1 |  |  |  |  | $ | 243.2 |  |  |  |

[0001628280-18-013240:mdna:38]
During the three months ended September 29, 2018 and September 30, 2017, net revenue from customers outside the United States, based on customer shipping location, represented 93.8% and 86.2% of net revenue, respectively. Our net revenue from Mexico increased due to increased demand for our ROADM products from one of our large customers who manufactures in Mexico, while net revenue from Hong Kong and South Korea grew due to our 3D sensing ramp for mobile devices.

[0001628280-18-013240:mdna:39]
[same as prior period, unchanged from 0001633978-18-000030:mdna:57]

[0001628280-18-013240:mdna:40]
[same as prior period, unchanged from 0001633978-18-000030:mdna:58]

[0001628280-18-013240:mdna:41]
The following table summarizes segment gross margin for the three months ended September 29, 2018 and September 30, 2017 (in millions, except for percentages):

[0001628280-18-013240:mdna:42]
|  | Gross Profit |  | Gross Margin |
|  | Three Months Ended |  | Three Months Ended |
|  | September 29, 2018 |  | September 30, 2017 |  | September 29, 2018 |  | September 30, 2017 |
| OpComms | $ | 124.9 |  |  | $ | 72.1 |  |  | 40.3 | % |  | 34.7 | % |
| Lasers | 17.7 |  |  | 10.6 |  |  | 40.2 | % |  | 30.0 | % |
| Segment total | $ | 142.6 |  |  | $ | 82.7 |  |  | 40.3 | % |  | 34.0 | % |
| Unallocated corporate items (1) | (16.6 | ) |  | (14.2 | ) |  |  |  |  |
| Total | $ | 126.0 |  |  | $ | 68.5 |  |  | 35.6 | % |  | 28.2 | % |

[0001628280-18-013240:mdna:43]
(1) The unallocated corporate items for the periods presented include the effects of amortization of acquired developed technologies, share-based compensation and certain other charges. We do not allocate these items to the gross margin for each segment because management does not include such information in measuring the performance of the operating segments.

[0001628280-18-013240:mdna:44]
Other charges of unallocated corporate items for the three months ended September 29, 2018 primarily include set-up costs of our facility in Thailand, including costs of transferring product lines to Thailand of $12.7 million. During the three months ended September 30, 2017, other charges of unallocated corporate items primarily consisted of set-up costs of our facility in Thailand of $3.1 million, as well as inventory write-downs due to canceled programs not allocated to the segments of $7.0 million.

[0001628280-18-013240:mdna:45]
[same as prior period, unchanged from 0001633978-18-000030:mdna:62]

[0001628280-18-013240:mdna:46]
Gross margin during the three months ended September 29, 2018 increased to 35.6% from 28.2% during the three months ended September 30, 2017. The increase was primarily due to increased sales in our 3D sensing and lasers products, which have higher gross margins than the average for the Company, as well as lower sales of Datacom products, which have lower gross margins than the average for the Company.

[0001628280-18-013240:mdna:47]
[same as prior period, unchanged from 0001633978-18-000030:mdna:65]

[0001628280-18-013240:mdna:48]
[same as prior period, unchanged from 0001633978-18-000030:mdna:66]

[0001628280-18-013240:mdna:49]
[same as prior period, unchanged from 0001633978-18-000030:mdna:67]

[0001628280-18-013240:mdna:50]
OpComms gross margin during the three months ended September 29, 2018 increased to 40.3% from 34.7% during the three months ended September 30, 2017. This increase was primarily due to increased sales of our 3D sensing and ROADM products, which have higher gross margins than the averages for this segment.

[0001628280-18-013240:mdna:51]
[same as prior period, unchanged from 0001633978-18-000030:mdna:70]

[0001628280-18-013240:mdna:52]
Lasers gross margin during the three months ended September 29, 2018 increased to 40.2% from 30.0% during the three months ended September 30, 2017. This increase was primarily due to increased revenue and manufacturing utilization for our kilowatt class fiber lasers products.

[0001628280-18-013240:mdna:53]
[same as prior period, unchanged from 0001633978-18-000030:mdna:73]

[0001628280-18-013240:mdna:54]
R&D expense decreased by $1.7 million, or 4.7%, during the three months ended September 29, 2018 compared to the three months ended September 30, 2017. The decrease in R&D expense was primarily due to a decrease in stock-based compensation of $0.3 million and payroll related expense of $1.1 million.

[0001628280-18-013240:mdna:55]
[same as prior period, unchanged from 0001633978-18-000030:mdna:76]

[0001628280-18-013240:mdna:56]
[same as prior period, unchanged from 0001633978-18-000030:mdna:77]

[0001628280-18-013240:mdna:57]
SG&A expense increased by $6.4 million, or 24.1%, during the three months ended September 29, 2018 compared to the three months ended September 30, 2017. The increase was primarily attributable to $1.1 million of costs related to the planned acquisition of Oclaro, an increase in stock-based compensation of $1.2 million and an increase in payroll related expense of $2.4 million, which includes an increase in variable incentive compensation of $1.2 million.

[0001628280-18-013240:mdna:58]
We expect to experience in the future certain non-core expenses, such as mergers and acquisition-related expenses and litigation expenses, which will likely increase our SG&A expenses and potentially impact our profitability expectations in any particular quarter.

[0001628280-18-013240:mdna:59]
[same as prior period, unchanged from 0001633978-18-000030:mdna:81]

[0001628280-18-013240:mdna:60]
[same as prior period, unchanged from 0001633978-18-000030:mdna:82]

[0001628280-18-013240:mdna:61]
During the three months ended September 29, 2018, we recorded $1.3 million in restructuring and related charges in the condensed consolidated statements of operations, primarily attributable to severance and employee related benefits. On September 5, 2018, we implemented an internal re-organization in order to extend market leadership position by strengthening product quality, to develop new enabling technologies required to support a winning long-term portfolio roadmap, and to develop commercial proposals and NPI priorities to maintain and grow our position while driving new customer and eco-system partner engagements.

[0001628280-18-013240:mdna:62]
During the three months ended September 30, 2017, we recorded $2.9 million in restructuring and related charges in the condensed consolidated statements of operations, of which $(0.1) million was severance costs and $3.0 million related to cost to vacate facilities, lease termination costs, and temporary labor, payroll tax, and other related costs connected with employee benefits, materials used in set up and production activities.

[0001628280-18-013240:mdna:63]
[same as prior period, unchanged from 0001633978-18-000030:mdna:85]

[0001628280-18-013240:mdna:64]
[same as prior period, unchanged from 0001633978-18-000030:mdna:86]

[0001628280-18-013240:mdna:65]
|  | Three Months Ended |
|  | September 29, 2018 |  | September 30, 2017 |
| Interest expense | $ | (5.1 | ) |  | $ | (4.4 | ) |
| Foreign exchange gains (losses), net | (0.3 | ) |  | (0.4 | ) |
| Interest income | 2.7 |  |  | 1.5 |  |
| Other income (expense), net | 0.3 |  |  | (0.1 | ) |
| Interest and other income (expense), net | $ | (2.4 | ) |  | $ | (3.4 | ) |

[0001628280-18-013240:mdna:66]
For the three months ended September 29, 2018, interest and other income (expense), net improved by $1.0 million compared to the three months ended September 30, 2017, mainly driven by increased interest income on our short-term investments and cash equivalents of $1.2 million.

[0001628280-18-013240:mdna:67]
Unrealized Gain (Loss) on Derivative Liability

[0001628280-18-013240:mdna:68]
Unrealized gain (loss) on Series A Preferred Stock derivative liability amounted to $(2.1) million and $4.2 million for the three months ended September 29, 2018 and September 30, 2017, respectively. The change is primarily related to the change in the price of our underlying common stock and is reflected in the condensed consolidated statements of operations as “Unrealized gain (loss) on derivative liability”. For further discussion of our derivative liability, see “Note 11. Derivative Liability” in the Notes to Unaudited Condensed Consolidated Financial Statements.

[0001628280-18-013240:mdna:69]
[same as prior period, unchanged from 0001633978-18-000030:mdna:92]

[0001628280-18-013240:mdna:70]
|  | Three Months Ended |
|  | September 29, 2018 |  | September 30, 2017 |
| Provision for (benefit from) income taxes | $ | 5.2 |  |  | $ | (3.6 | ) |

[0001628280-18-013240:mdna:71]
The comparability of our operating results in the first quarter of fiscal 2019 compared to the corresponding prior year period was impacted by the U.S. Tax Cuts and Jobs Act of 2017 (the Tax Act), which was enacted on December 22, 2017. The Tax Act introduced significant changes to U.S. income tax law including reducing the U.S. federal statutory tax rate from 35% to 21% and new taxes on certain foreign-sourced earnings and certain intercompany payments. Due to the timing of the enactment and the complexity involved in applying the provisions of the Tax Act, we made reasonable estimates of the effects and recorded provisional amounts in our financial statements as of fiscal 2018 in accordance with SEC Staff Accounting Bulletin No. 118 (SAB 118). No further adjustments were made to the provisional amounts in the first quarter of fiscal 2019. The accounting for the tax effects of the Tax Act will be completed within the measurement period in accordance with SAB 118.

[0001628280-18-013240:mdna:72]
Our tax provision for interim periods is determined using an estimate of our annual effective tax rate, adjusted for discrete items, if any, that arise during the period. Each quarter, we update our estimate of the annual effective tax rate, and if the estimated annual effective tax rate changes, we make a cumulative adjustment in such period.

[0001628280-18-013240:mdna:73]
Our quarterly tax provision, and estimate of our annual effective tax rate, is subject to variation due to several factors, including variability in pre-tax income (or loss), the mix of jurisdictions to which such income relates, changes in how we do business, and tax law developments. Our estimated effective tax rate for the year differs from the 21% U.S. statutory rate primarily due to the benefit of foreign earnings of our subsidiaries being taxed at rates lower than the U.S. statutory rate.

[0001628280-18-013240:mdna:74]
We recorded a tax expense of $5.2 million for the three months ended September 29, 2018.  Our provision for income taxes for the three months September 29, 2018 varied from the 21% U.S. statutory rate primarily due to earnings in our foreign subsidiaries, the U.S. research and development tax credit, and the tax effects of stock-based compensation, partially offset by the tax effect of GILTI and subpart F income inclusion.

[0001628280-18-013240:mdna:75]
We recorded a tax benefit of $(3.6) million for the three months ended September 30, 2017. Our provision for income taxes for the three months ended September 30, 2017 varied from the previous U.S. federal statutory income tax rate of 35% primarily due to earnings in foreign operations, the tax benefit from excess stock-based compensation deductions, and the non-taxable unrealized gain from the embedded derivatives for the Series A Preferred Stock.

[0001628280-18-013240:mdna:76]
As of September 29, 2018, we had $9.0 million of unrecognized tax benefits, which, if recognized, would affect the effective tax rate. We are subject to examination of income tax returns by various domestic and foreign tax authorities. The timing of resolutions and closures of tax audits is highly unpredictable. Given the uncertainty, it is reasonably possible that certain tax audits may be concluded within the next 12 months. An estimate of the range of increase or decrease that could occur in the next twelve months cannot be made. However, the estimated impact to tax expense and net income from the resolution and closure of tax exams is not expected to be significant within the next 12 months.

[0001628280-18-013240:mdna:77]
On July 24, 2018, the Ninth Circuit Court of Appeals (the “Court”) issued an opinion in Altera Corp. v. Commissioner requiring related parties in an intercompany cost sharing arrangement to share expenses related to share-based compensation. This opinion reversed the prior decision of the United States Tax Court. On August 7, 2018, the Court withdrew the opinion issued on July 24, 2018 to allow time for a reconstituted panel of judges to confer. We will continue to monitor the case and potential impact to our consolidated financial statements.

[0001628280-18-013240:mdna:78]
We operate under a tax holiday in Thailand, which could be effective through fiscal year 2025, and may be extended if certain additional requirements are satisfied.  The tax holiday is conditional upon our meeting certain employment and investment thresholds. The tax holiday had insignificant impact on our foreign taxes and on net income per share (diluted) for the fiscal year ended June 30, 2018 and for the three months ended September 29, 2018.

[0001628280-18-013240:mdna:79]
[same as prior period, unchanged from 0001633978-18-000030:mdna:108]

[0001628280-18-013240:mdna:80]
[same as prior period, unchanged from 0001633978-18-000030:mdna:109]

[0001628280-18-013240:mdna:81]
The following table summarizes our contractual obligations as of September 29, 2018, and the effect such obligations are expected to have on our liquidity and cash flow over the next five years (in millions):

[0001628280-18-013240:mdna:82]
|  | Payments due by period |
|  | Total |  | Less than 1 year |  | 1 - 3 years |  | 3 - 5 years |  | More than 5 years |
| Contractual Obligations |  |  |  |  |  |  |  |  |  |
| Asset retirement obligations | $ | 2.7 |  |  | $ | — |  |  | $ | 1.0 |  |  | $ | 0.4 |  |  | $ | 1.3 |  |
| Purchase obligations (1) | 206.5 |  |  | 203.5 |  |  | 3.0 |  |  | — |  |  | — |  |
| Operating lease obligations (1) | 28.0 |  |  | 10.4 |  |  | 10.8 |  |  | 5.3 |  |  | 1.5 |  |
| Capital lease obligation (1) | 7.1 |  |  | 7.1 |  |  | — |  |  | — |  |  | — |  |
| Pension plan contributions (2) | 0.5 |  |  | 0.5 |  |  | — |  |  | — |  |  | — |  |
| 0.25% Convertible Senior Notes due 2024 | 450.0 |  |  | — |  |  | — |  |  | — |  |  | 450.0 |  |
| Interest on 2024 Notes (3) | 6.2 |  |  | 1.1 |  |  | 2.2 |  |  | 2.2 |  |  | 0.7 |  |
| Acquisition contingencies (4) | 3.0 |  |  | 3.0 |  |  | — |  |  | — |  |  | — |  |
| Total | $ | 704.0 |  |  | $ | 225.6 |  |  | $ | 17.0 |  |  | $ | 7.9 |  |  | $ | 453.5 |  |

[0001628280-18-013240:mdna:83]
(1) Refer to “Note 16. Commitments and Contingencies” in the Notes to Unaudited Condensed Consolidated Financial Statements.

[0001628280-18-013240:mdna:84]
[same as prior period, unchanged from 0001633978-18-000030:mdna:113]

[0001628280-18-013240:mdna:85]
(3) Includes interest on our 0.25% Convertible Senior Notes due 2024 through March 2024 as we have the right to redeem the 2024 Notes in whole or in part at any time on or after March 15, 2024. Refer to “Note 10. Convertible Senior Notes” in the Notes to Unaudited Condensed Consolidated Financial Statements.

[0001628280-18-013240:mdna:86]
[same as prior period, unchanged from 0001633978-18-000030:mdna:115]

[0001628280-18-013240:mdna:87]
[same as prior period, unchanged from 0001633978-18-000030:mdna:116]

[0001628280-18-013240:mdna:88]
As of September 29, 2018, asset retirement obligations presented in the preceding table are included in other non-current liabilities on our unaudited condensed consolidated balance sheet. As of September 29, 2018, our other non-current liabilities also include $9.0 million of unrecognized tax benefit for uncertain tax positions. We are unable to reliably estimate the timing of future payments related to uncertain tax positions and therefore have excluded them from the preceding table.

[0001628280-18-013240:mdna:89]
In addition to the obligations discussed above, at the time of the closing of the Oclaro acquisition (which is expected to be completed by December 11, 2018, or no later than March 11, 2019 if we have not received antitrust approvals by December 11, 2018), we will be required to pay cash consideration as described further in “Acquisitions” below. We also expect to incur indebtedness in an aggregate principal amount of approximately $500 million pursuant to a senior secured term loan facility entered into in connection with the closing of the Oclaro acquisition.

[0001628280-18-013240:mdna:90]
[same as prior period, unchanged from 0001633978-18-000030:mdna:120]

[0001628280-18-013240:mdna:91]
[same as prior period, unchanged from 0001633978-18-000030:mdna:121]

[0001628280-18-013240:mdna:92]
Acquisitions

[0001628280-18-013240:mdna:93]
As part of our strategy, we are committed to the ongoing evaluation of strategic opportunities and, where appropriate, the acquisition of additional products, technologies or businesses that are complementary to, or broaden the markets for, our products. We believe we have strengthened our business model by expanding our addressable markets, customer base and expertise, diversifying our product portfolio, and fortifying our core businesses through acquisitions as well as through organic initiatives. On March 11, 2018, we entered into an Agreement and Plan of Merger (the “Merger Agreement”) with Oclaro, Inc. (“Oclaro”), Prota Merger Sub, Inc., and Prota Merger, LLC, pursuant to which we will acquire Oclaro and Oclaro will become a wholly-owned subsidiary of Lumentum. In accordance with the terms of the Merger Agreement, each issued and outstanding share of Oclaro common stock will be exchanged for $5.60 in cash and 0.0636 of a share of Lumentum common stock, subject to the conditions and restrictions set forth in the Merger Agreement. The total transaction consideration was approximately $1.8 billion as of the date of the Merger Agreement. Oclaro stockholders are expected to own approximately 16% of the combined company following the closing. Oclaro’s stockholders approved the Merger Agreement on July 10, 2018 and we have received approval for the transaction under the Hart-Scott Rodino Act in the United States. We are in the process of obtaining antitrust approval in China. The Merger Agreement contains certain termination rights for both Lumentum and Oclaro. The Merger Agreement further provides that upon termination of the Merger Agreement under specified circumstances relating to failure to obtain regulatory approvals, Lumentum may be required to pay Oclaro a termination fee of $80 million.

[0001628280-18-013240:mdna:94]
In connection with the Merger Agreement, Lumentum entered into a commitment letter, dated as of March 11, 2018, with Deutsche Bank Securities Inc. and Deutsche Bank AG New York Branch (“Deutsche Bank”), pursuant to which, subject to the terms and conditions set forth therein, Deutsche Bank has committed to provide a senior secured term loan facility in an aggregate principal amount of up to $550 million.

[0001628280-18-013240:mdna:95]
As of October 26, 2018, the total transaction consideration was expected to be approximately $1.6 billion, which would be funded by a combination of $600 million in Lumentum common stock, $500 million in new debt, and the remaining amount from the cash balances of the combined company.

[0001628280-18-013240:mdna:96]
Our commitment letter and related documentation with Deutsche Bank requires payment of a ticking fee to Deutsche Bank. The ticking fee accrues at a rate of (a) commencing on the 31st day following the date on which the term loans were allocated to members of the lending syndicate (the “Allocation Date”), 1.25% per annum, and (b) commencing on the 61st day following the Allocation Date, 2.5% per annum, in each case, based on an aggregate principal amount of term loan commitments provided by Deutsche Bank under the commitment letter.  The Allocation Date occurred on August 8, 2018 and, as of September 29, 2018, we had not borrowed any funds under the senior secured term loan facility. Accordingly, we began to incur ticking fees on the $500 million of term loan commitments on September 8, 2018. We expensed $0.4 million related to the ticking fee, which is included in interest expense in our condensed consolidated statements of operations for the three months ended September 29, 2018.

[0001628280-18-013240:mdna:97]
During the three months ended September 29, 2018, we also incurred $0.9 million of debt issuance costs in connection with the above facility which were capitalized and recorded in other non-current assets on our condensed consolidated balance sheet. These costs will be recorded as contra liability when the debt is drawn and will be amortized to interest expense using the effective interest rate method from the issuance date through the end of the term of the loan.

[0001628280-18-013240:mdna:98]
[same as prior period, unchanged from 0001633978-18-000030:mdna:122]

[0001628280-18-013240:mdna:99]
[same as prior period, unchanged from 0001633978-18-000030:mdna:123]

[0001628280-18-013240:mdna:100]
As of September 29, 2018 and June 30, 2018, our cash and cash equivalents of $459.4 million and $397.3 million, respectively, were held predominantly in the United States. The total amount of cash outside the United States as of September 29, 2018 was $52.1 million, which was primarily held in Hong Kong, Cayman Islands, Thailand, Canada, and British Virgin Islands. Although the cash currently held in the United States as well as the cash generated in the United States from future operations is expected to cover our normal operating requirements, a substantial amount of additional cash could be required for other purposes, such as capital expenditures to support our business and growth, including costs associated with increasing internal manufacturing capabilities, such as our new Thailand facility, strategic transactions and partnerships, and acquisitions. Our intent is to indefinitely reinvest funds held outside the United States, except for the funds held in the Cayman Islands and Hong Kong, and our current plans do not demonstrate a need to repatriate them to fund our domestic operations. However, if in the future, we encounter a significant need for liquidity domestically or at a particular location that we cannot fulfill through borrowings, equity offerings, or other internal or external sources, or the cost to bring back the money is insignificant from a tax perspective, we may determine that cash repatriations are necessary or desirable. Repatriation could result in additional material taxes. These factors may cause us to have an overall tax rate higher than other companies or higher than our tax rates have been in the past. If conditions warrant, we may seek to obtain additional financing through debt or equity sources. To the extent we issue additional shares, our existing stockholders may be diluted. However, any such financing may not be available on terms favorable to us, or may not be available at all.

[0001628280-18-013240:mdna:101]
41

[0001628280-18-013240:mdna:102]
As of September 29, 2018, our consolidated balance of cash and cash equivalents increased by $62.1 million, to $459.4 million from $397.3 million as of June 30, 2018. The increase in cash and cash equivalents was mainly due to cash provided by operating activities of $57.2 million during the three months ended September 29, 2018.

[0001628280-18-013240:mdna:103]
[same as prior period, unchanged from 0001633978-18-000030:mdna:126]

[0001628280-18-013240:mdna:104]
Cash provided by operating activities was $57.2 million during the three months ended September 29, 2018, primarily resulting from $47.4 million of net income and $37.7 million of non-cash items (such as depreciation, stock-based compensation, unrealized loss on derivative liability, amortization of intangibles, amortization of discount on the 2024 Notes), offset by $27.9 million of changes in our operating assets and liabilities. Changes in our operating assets and liabilities related primarily to an increase in accounts receivable of $41.9 million offset by a decrease in inventories of $15.3 million.

[0001628280-18-013240:mdna:105]
[same as prior period, unchanged from 0001633978-18-000030:mdna:129]

[0001628280-18-013240:mdna:106]
Cash provided by investing activities of $9.5 million during the three months ended September 29, 2018 was primarily attributable to sales of short-term investments, net of purchases of $39.8 million offset by capital expenditures of $29.6 million.

[0001628280-18-013240:mdna:107]
[same as prior period, unchanged from 0001633978-18-000030:mdna:132]

[0001628280-18-013240:mdna:108]
Cash used in financing activities of $4.6 million during the three months ended September 29, 2018 resulted primarily from a repayment of a capital lease obligation of $2.3 million, payment of debt issuance costs of $0.9 million, and payment of acquisition related holdback of $1.0 million.

[0001628280-18-013240:mdna:109]
[same as prior period, unchanged from 0001633978-18-000030:mdna:134]

[0001628280-18-013240:mdna:110]
We believe that our cash and cash equivalents as of September 29, 2018, and cash flows from our operating activities will be sufficient to meet our liquidity and capital spending requirements for at least the next 12 months. However, if market conditions are favorable, we may evaluate alternatives to opportunistically pursue additional financing.

[0001628280-18-013240:mdna:111]
[same as prior period, unchanged from 0001633978-18-000030:mdna:136]

[0001628280-18-013240:mdna:112]
[same as prior period, unchanged from 0001633978-18-000030:mdna:137]

[0001628280-18-013240:mdna:113]
[same as prior period, unchanged from 0001633978-18-000030:mdna:138]

[0001628280-18-013240:mdna:114]
[same as prior period, unchanged from 0001633978-18-000030:mdna:139]

[0001628280-18-013240:mdna:115]
[same as prior period, unchanged from 0001633978-18-000030:mdna:140]

[0001628280-18-013240:mdna:116]
[same as prior period, unchanged from 0001633978-18-000030:mdna:141]

[0001628280-18-013240:mdna:117]
[same as prior period, unchanged from 0001633978-18-000030:mdna:142]

[0001628280-18-013240:mdna:118]
[same as prior period, unchanged from 0001633978-18-000030:mdna:143]

[0001628280-18-013240:mdna:119]
[same as prior period, unchanged from 0001633978-18-000030:mdna:144]

[0001628280-18-013240:mdna:120]
[same as prior period, unchanged from 0001633978-18-000030:mdna:145]

[0001628280-18-013240:mdna:121]
[same as prior period, unchanged from 0001633978-18-000030:mdna:146]

[0001628280-18-013240:mdna:122]
[same as prior period, unchanged from 0001633978-18-000030:mdna:147]

[0001628280-18-013240:mdna:123]
| • | the settlement of any conversion or redemption of the 2024 Notes in cash. |

[0001628280-18-013240:mdna:124]
In March 2018, we entered into the Merger Agreement with Oclaro. Pursuant to the terms of the Merger Agreement, each issued and outstanding share of Oclaro common stock will be exchanged for $5.60 in cash and 0.0636 of a share of Lumentum common stock, subject to the conditions and restrictions set forth in the Merger Agreement. In connection with the acquisition of Oclaro, we have entered into a commitment letter with Deutsche Bank, pursuant to which, subject to the terms and conditions set forth therein, Deutsche Bank has committed to provide a senior secured term loan facility in an aggregate principal amount of $550 million.

[0001628280-18-013240:mdna:125]
As of October 26, 2018, the total transaction consideration was expected to be approximately $1.6 billion, which would be funded by a combination of $600 million in Lumentum common stock, $500 million in new debt, and the remaining amount from the cash balances of the combined company.

[0001628280-18-013240:mdna:126]
43
