# LITE notes — 0001628280-18-013240


## lite:AssetAcquisitionDisclosureTextBlock

[0001628280-18-013240:notes:1]
[same as prior period, unchanged from 0001633978-18-000030:notes:1]

[0001628280-18-013240:notes:2]
On March 30, 2018, we entered into a Transition Services Agreement (“TSA”) with one of our contract manufacturers to wind down the production of our products at their facility in China and to facilitate an orderly transition of manufacturing to either our manufacturing facility in Thailand or our third party contract manufacturers, including the purchase of the manufacturing equipment. Under the terms of the TSA, we are required to pay $5.3 million in cash upon completion of certain milestones related to the purchase of equipment. During the three months ended September 29, 2018, we paid $0.7 million for the manufacturing equipment acquired under this TSA. This amount is included in construction in progress on our condensed consolidated balance sheet as of September 29, 2018.

[0001628280-18-013240:notes:3]
[same as prior period, unchanged from 0001633978-18-000030:notes:3]


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001628280-18-013240:notes:4]
[same as prior period, unchanged from 0001633978-18-000030:notes:22]

[0001628280-18-013240:notes:5]
The preparation of the condensed consolidated financial statements in accordance with U.S. generally accepted accounting principles (“GAAP”) requires management to make estimates and assumptions that affect the amounts reported in our condensed consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates. Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001628280-18-013240:notes:6]
[same as prior period, unchanged from 0001633978-18-000030:notes:24]

[0001628280-18-013240:notes:7]
[same as prior period, unchanged from 0001633978-18-000030:notes:25]

[0001628280-18-013240:notes:8]
Lumentum (we, us, our or the Company) is an industry-leading provider of optical and photonic products defined by revenue and market share addressing a range of end market applications including OpComms and Lasers for manufacturing, inspection and life-science applications. We seek to use our core optical and photonic technology and our volume manufacturing capability to expand into attractive emerging markets that benefit from advantages that optical or photonics based solutions provide, including 3D sensing for consumer electronics and diode light sources for a variety of consumer and industrial applications. The majority of our customers tend to be OEMs that incorporate our products into their products which then address end-market applications. For example, we sell fiber optic components that Network Equipment Manufacturers (“NEMs”) customers assemble into communications networking systems, which they sell to network service providers or enterprises with their own networks. Similarly, many of our customers for our Lasers products incorporate our products into tools they produce, which are used for manufacturing processes by their customers. For 3D sensing, we sell diode lasers to manufacturers of consumer electronics products for mobile, personal computing, and gaming who then integrate our devices within their products, for eventual resale to consumers and also into other industrial applications.

[0001628280-18-013240:notes:9]
The preparation of the condensed consolidated financial statements in accordance with U.S. generally accepted accounting principles (“GAAP”) requires management to make estimates and assumptions that affect the amounts reported in our condensed consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates. Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are inventory valuation, revenue recognition, income taxes, long-lived asset valuation, warranty, derivative liability, business combinations, and goodwill.

[0001628280-18-013240:notes:10]
On March 11, 2018, we entered into an Agreement and Plan of Merger (the “Merger Agreement”) with Oclaro, Prota Merger Sub, Inc., and Prota Merger, LLC, pursuant to which we will acquire Oclaro and Oclaro will become a wholly-owned subsidiary of Lumentum. In accordance with the terms of the Merger Agreement, each issued and outstanding share of Oclaro common stock will be exchanged for $5.60 in cash and 0.0636 of a share of Lumentum common stock, subject to the conditions and restrictions set forth in the Merger Agreement. The total transaction consideration was approximately $1.8 billion as of the date of the Merger Agreement. Oclaro stockholders are expected to own approximately 16% of the combined company following the closing. Oclaro’s stockholders approved the Merger Agreement on July 10, 2018 and we have received approval for the transaction under the Hart-Scott Rodino Act in the United States. We are in the process of obtaining antitrust approval in China. The Merger Agreement contains certain termination rights for both Lumentum and Oclaro. The Merger Agreement further provides that upon termination of the Merger Agreement under specified circumstances relating to failure to obtain regulatory approvals by March 11, 2019, Lumentum may be required to pay Oclaro a termination fee of $80 million.

[0001628280-18-013240:notes:11]
In connection with the Merger Agreement, Lumentum entered into a commitment letter, dated as of March 11, 2018, with Deutsche Bank Securities Inc. and Deutsche Bank AG New York Branch (“Deutsche Bank”), pursuant to which, subject to the terms and conditions set forth therein, Deutsche Bank has committed to provide a senior secured term loan facility in an aggregate principal amount of up to $550 million.

[0001628280-18-013240:notes:12]
As of October 26, 2018, the total transaction consideration was expected to be approximately $1.6 billion, which would be funded by a combination of $600 million in Lumentum common stock, $500 million in new debt, and the remaining amount from the cash balances of the combined company.

[0001628280-18-013240:notes:13]
Our commitment letter and related documentation with Deutsche Bank requires payment of a ticking fee to Deutsche Bank. The ticking fee accrues at a rate of (a) commencing on the 31st day following the date on which the term loans were allocated to members of the lending syndicate (the “Allocation Date”), 1.25% per annum, and (b) commencing on the 61st day following the Allocation Date, 2.5% per annum, in each case, based on an aggregate principal amount of term loan commitments provided by Deutsche Bank under the commitment letter.  The Allocation Date occurred on August 8, 2018 and, as of September 29, 2018, we had not borrowed any funds under the senior secured term loan facility. Accordingly, we began to incur ticking fees on the $500 million of term loan commitments on September 8, 2018. We expensed $0.4 million related to the ticking fee, which is included in interest expense in our condensed consolidated statements of operations for the three months ended September 29, 2018.

[0001628280-18-013240:notes:14]
During the three months ended September 29, 2018, we also incurred $0.9 million of debt issuance costs in connection with the above facility which were capitalized and recorded in other non-current assets on our condensed consolidated balance sheet. These costs will be recorded as contra liability when the debt is drawn and will be amortized to interest expense using the effective interest rate method from the issuance date through the end of the term of the loan.

[0001628280-18-013240:notes:15]
The transaction is subject to customary closing conditions, including antitrust regulatory approval in China. The transaction is not subject to any financing condition. Although we anticipate that the transaction will be be completed by December 11, 2018, the termination date of the merger agreement will be automatically extended to March 11, 2019, subject to certain conditions set forth in the Merger Agreement.

[0001628280-18-013240:notes:16]
[same as prior period, unchanged from 0001633978-18-000030:notes:31]

[0001628280-18-013240:notes:17]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Our fiscal 2019 is a 52-week year ending on June 29, 2019. Our fiscal 2018 was a 52-week year and ended on June 30, 2018.

[0001628280-18-013240:notes:18]
[same as prior period, unchanged from 0001633978-18-000030:notes:33]

[0001628280-18-013240:notes:19]
[same as prior period, unchanged from 0001633978-18-000030:notes:34]

[0001628280-18-013240:notes:20]
Certain prior period amounts have been reclassified to conform to the current year presentation on the notes to condensed consolidated financial statements. The reclassification of the prior period amounts did not impact previously reported condensed consolidated financial statements.

[0001628280-18-013240:notes:21]
[same as prior period, unchanged from 0001633978-18-000030:notes:35]

[0001628280-18-013240:notes:22]
The accompanying interim unaudited condensed consolidated financial statements and accompanying related notes should be read in conjunction with the audited consolidated financial statements and related notes included in our Annual Report on Form 10-K for the fiscal year ended June 30, 2018.

[0001628280-18-013240:notes:23]
Except for the accounting policies for revenue recognition and adoption of Accounting Standard Update (“ASU”) 2014-09, Revenue from Contracts with Customers (Topic 606), there have been no significant changes to our significant accounting policies as of and for the three months ended September 29, 2018, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the year ended June 30, 2018.

[0001628280-18-013240:notes:24]
Adoption of Topic 606

[0001628280-18-013240:notes:25]
Revenue Recognition Policy

[0001628280-18-013240:notes:26]
Pursuant to Topic 606, our revenues are recognized upon the application of the following steps:

[0001628280-18-013240:notes:27]
| • | identification of the contract, or contracts, with a customer; |

[0001628280-18-013240:notes:28]
| • | identification of the performance obligations in the contract; |

[0001628280-18-013240:notes:29]
| • | determination of the transaction price; |

[0001628280-18-013240:notes:30]
| • | allocation of the transaction price to the performance obligations in the contract; and |

[0001628280-18-013240:notes:31]
| • | recognition of revenues when, or as, the contractual performance obligations are satisfied |

[0001628280-18-013240:notes:32]
The majority of our revenue comes from product sales, consisting of sales of Lasers and OpComms hardware products to our customers. Our revenue contracts generally include only one performance obligation. Revenues are recognized at a point in time when control of the promised goods or services is transferred to our customers upon shipment or delivery, in an amount that reflects the consideration we expect to be entitled to in exchange for those goods or services. We have entered into vendor managed inventory (“VMI”) programs with our customers. Under these arrangements, we receive purchase orders from our customers, and the inventory is shipped to the VMI location upon receipt of the purchase order. The customer then pulls the inventory from the VMI hub based on its production needs. Revenue under VMI programs is recognized when control transfers to the customer, which is generally upon pull of inventory by the customer from the hub.

[0001628280-18-013240:notes:33]
Revenue from all sales types is recognized at transaction price. The transaction price is determined based on the consideration to which we will be entitled in exchange for transferring goods or services to the customer adjusted for estimated variable consideration, if any. We typically estimate the transaction price impact of discounts offered to the customers for early payments on receivables or net of accruals for estimated sales returns. These estimates are based on historical returns, analysis of credit memo data and other known factors. Actual returns could differ from these estimates. We allocate the transaction price to each distinct product based on its relative standalone selling price. The product price as specified on the purchase order is considered the standalone selling price as it is an observable input that depicts the price as if sold to a similar customer in similar circumstances.

[0001628280-18-013240:notes:34]
Taxes assessed by a governmental authority that are both imposed on and concurrent with a specific revenue-producing transaction, that are collected by us from a customer and deposited with the relevant government authority, are excluded from revenue. Our revenue arrangements do not contain significant financing components as our standard payment terms are less than one year.

[0001628280-18-013240:notes:35]
If a customer pays consideration, or Lumentum has a right to an amount of consideration that is unconditional before we transfer a good or service to the customer, those amounts are classified as deferred income/advances received from customers which are included in other current liabilities or other long-term liabilities when the payment is made or it is due, whichever is earlier.

[0001628280-18-013240:notes:36]
Transaction Price Allocated to the Remaining Performance Obligations

[0001628280-18-013240:notes:37]
Remaining performance obligations represent the transaction price allocated to performances obligations that are unsatisfied or partially unsatisfied as of the end of the reporting period. Unsatisfied and partially unsatisfied performance obligations consist of contract liabilities and non-cancellable backlog. Non-cancellable backlog includes goods and services for which customer purchase orders have been accepted that are scheduled or in the process of being scheduled for shipment.

[0001628280-18-013240:notes:38]
The following table includes estimated revenue expected to be recognized in the future for backlog related performance obligations that are unsatisfied (or partially unsatisfied) as of September 29, 2018:

[0001628280-18-013240:notes:39]
|  | Less than 1 year | 1-2 years | Greater than 2 years | Total |
| Performance Obligations | $384.8 | $22.7 | $0.4 | $407.9 |

[0001628280-18-013240:notes:40]
Warranty

[0001628280-18-013240:notes:41]
Hardware products regularly include warranties to the end customers such that the product continues to function according to published specifications. We typically offer a twelve month warranty for most of our products. However, in some instances depending upon the product, specific market, product line and geography we deal in, and what is common in the industry, our warranties can vary and range from six months to five years. These standard warranties are assurance type warranties and do not offer any services in addition to the assurance that the product will continue working as specified. Therefore, warranties are not considered separate performance obligations in the arrangement. Instead, the expected cost of warranty is accrued as expense in accordance with authoritative guidance.

[0001628280-18-013240:notes:42]
We provide reserves for the estimated costs of product warranties at the time revenue is recognized. We estimate the costs of our warranty obligations based on our historical experience of known product failure rates, use of materials to repair or replace defective products and service delivery costs incurred in correcting product failures. In addition, from time to time, specific warranty accruals may be made if unforeseen technical problems arise.

[0001628280-18-013240:notes:43]
Shipping and Handling Costs

[0001628280-18-013240:notes:44]
We record shipping and handling costs related to revenue transactions within cost of sales as a period cost.

[0001628280-18-013240:notes:45]
Contract Costs

[0001628280-18-013240:notes:46]
The Company recognizes the incremental direct costs of obtaining a contract, which consist of sales commissions, when control over the products they relate to transfers to the customer. Applying the practical expedient, the Company recognizes commissions as expense when incurred, as the amortization period of the commission asset the Company would have otherwise recognized is less than one year.

[0001628280-18-013240:notes:47]
Contract Balances

[0001628280-18-013240:notes:48]
The Company records accounts receivable when it has an unconditional right to consideration. Contract liabilities are recorded when cash payments are received or due in advance of performance. Contract liabilities consist of advance payments and deferred revenue, where the Company has unsatisfied performance obligations. Contract liabilities are classified as deferred revenue and customer deposits and included in other current liabilities of our condensed consolidated balance sheet. Payment terms vary by customer. The time between invoicing and when payment is due is not significant.

[0001628280-18-013240:notes:49]
The following table reflects the changes in contract balances for the three months ended September 30, 2018:

[0001628280-18-013240:notes:50]
| Contract balances | Balance sheet location | September 29, 2018 |  | June 30, 2018 |  | Change |  | Percentage Change |
| Accounts receivable, net | Accounts receivable, net | $239.6 |  | $197.1 |  | $42.5 |  | 21.6% |
| Deferred revenue and customer deposits | Other current liabilities | $2.6 |  | $2.8 |  | $(0.2) |  | (7.1)% |

[0001628280-18-013240:notes:51]
During the three months ended September 29, 2018, deferred revenue and customer deposits decreased primarily due to revenue recognized for the satisfaction of performance obligation over time in the amount of $0.4 million.

[0001628280-18-013240:notes:52]
Disaggregation of Revenue

[0001628280-18-013240:notes:53]
We disaggregate revenue by geography and by product, no other level of disaggregation is required considering the type of products, customer, markets, contracts, duration of contracts, timing of transfer of control and sales channels, based on the information that our chief operating decision maker uses to manage the business.


## us-gaap:CashCashEquivalentsAndShortTermInvestmentsTextBlock

[0001628280-18-013240:notes:54]
[same as prior period, unchanged from 0001633978-18-000030:notes:39]

[0001628280-18-013240:notes:55]
[same as prior period, unchanged from 0001633978-18-000030:notes:40]

[0001628280-18-013240:notes:56]
The following table summarizes our cash, cash equivalents, and short-term investments by category for the periods presented (in millions):

[0001628280-18-013240:notes:57]
|  | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| September 29, 2018: |  |  |  |  |  |  |  |
| Cash | $ | 149.9 |  |  | $ | — |  |  | $ | — |  |  | $ | 149.9 |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | 3.6 |  |  | — |  |  | — |  |  | 3.6 |  |
| Money market funds | 286.5 |  |  | — |  |  | — |  |  | 286.5 |  |
| U.S. Treasury | 19.4 |  |  | — |  |  | — |  |  | 19.4 |  |
| Total cash and cash equivalents | $ | 459.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 459.4 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Commercial paper | $ | 6.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 6.7 |  |
| Asset-backed securities | 58.5 |  |  | — |  |  | (0.2 | ) |  | 58.3 |  |
| Corporate debt securities | 202.4 |  |  | 0.1 |  |  | (1.1 | ) |  | 201.4 |  |
| Municipal bonds | 0.4 |  |  | — |  |  | — |  |  | 0.4 |  |
| Mortgage-backed securities | 3.0 |  |  | — |  |  | — |  |  | 3.0 |  |
| Foreign government bonds | 5.1 |  |  | — |  |  | — |  |  | 5.1 |  |
| Total short-term investments | $ | 276.1 |  |  | $ | 0.1 |  |  | $ | (1.3 | ) |  | $ | 274.9 |  |
| June 30, 2018: |  |  |  |  |  |  |  |
| Cash | $ | 103.6 |  |  | $ | — |  |  | $ | — |  |  | $ | 103.6 |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | 3.0 |  |  | — |  |  | — |  |  | 3.0 |  |
| Commercial paper | 112.1 |  |  | — |  |  | — |  |  | 112.1 |  |
| Money market funds | 0.8 |  |  | — |  |  | — |  |  | 0.8 |  |
| U.S. Treasury securities | 143.6 |  |  | — |  |  | — |  |  | 143.6 |  |
| U.S. Agency securities | 34.2 |  |  | — |  |  | — |  |  | 34.2 |  |
| Total cash and cash equivalents | $ | 397.3 |  |  | $ | — |  |  | $ | — |  |  | $ | 397.3 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 7.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 7.5 |  |
| Commercial paper | 10.5 |  |  | — |  |  | — |  |  | 10.5 |  |
| Asset-backed securities | 68.0 |  |  | — |  |  | (0.2 | ) |  | 67.8 |  |
| Corporate debt securities | 220.6 |  |  | 0.1 |  |  | (1.5 | ) |  | 219.2 |  |
| Municipal bonds | 1.6 |  |  | — |  |  | — |  |  | 1.6 |  |
| Mortgage-backed securities | 4.2 |  |  | — |  |  | — |  |  | 4.2 |  |
| Foreign government bonds | 3.4 |  |  | — |  |  | — |  |  | 3.4 |  |
| Total short-term investments | $ | 315.8 |  |  | $ | 0.1 |  |  | $ | (1.7 | ) |  | $ | 314.2 |  |

[0001628280-18-013240:notes:58]
We use the specific-identification method to determine any realized gains or losses from the sale of our short-term investments classified as available-for-sale. During the three months ended September 29, 2018 and September 30, 2017, we did not realize significant gains or losses on a gross level from the sale of our short-term investments classified as available-for-sale.

[0001628280-18-013240:notes:59]
During the three months ended September 29, 2018 and September 30, 2017, our interest and other income (expense), net of $(2.4) million and $(3.4) million, includes interest income on the short-term investments and cash equivalents of $2.7 million and $1.5 million, respectively.

[0001628280-18-013240:notes:60]
The following table summarizes unrealized losses on our cash equivalents and short-term investments by category and length of time the investment has been in a continuous unrealized loss position as of the periods presented (in millions):

[0001628280-18-013240:notes:61]
|  | Less than 12 months |  | 12 Months or Greater |  | Total |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| September 29, 2018: |  |  |  |  |  |  |  |  |  |  |  |
| Commercial paper | $ | 6.1 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 6.1 |  |  | $ | — |  |
| Asset-backed securities | 48.4 |  |  | (0.2 | ) |  | 8.5 |  |  | — |  |  | 56.9 |  |  | (0.2 | ) |
| Corporate debt securities | 113.3 |  |  | (0.8 | ) |  | 46.9 |  |  | (0.3 | ) |  | 160.2 |  |  | (1.1 | ) |
| Mortgage-backed securities | 2.8 |  |  | — |  |  | — |  |  | — |  |  | 2.8 |  |  | — |  |
| Foreign government bonds | 4.1 |  |  | — |  |  | — |  |  | — |  |  | 4.1 |  |  | — |  |
| Total | $ | 174.7 |  |  | $ | (1.0 | ) |  | $ | 55.4 |  |  | $ | (0.3 | ) |  | $ | 230.1 |  |  | $ | (1.3 | ) |
| June 30, 2018: |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 5.4 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 5.4 |  |  | $ | — |  |
| Commercial paper | 8.5 |  |  | — |  |  | — |  |  | — |  |  | 8.5 |  |  | — |  |
| Asset-backed securities | 66.6 |  |  | (0.2 | ) |  | 0.3 |  |  | — |  |  | 66.9 |  |  | (0.2 | ) |
| Corporate debt securities | 188.6 |  |  | (1.5 | ) |  | 2.0 |  |  | — |  |  | 190.6 |  |  | (1.5 | ) |
| Municipal bonds | 0.6 |  |  | — |  |  | — |  |  | — |  |  | 0.6 |  |  | — |  |
| U.S. Agency securities | 4.0 |  |  | — |  |  | — |  |  | — |  |  | 4.0 |  |  | — |  |
| Foreign government bonds | 3.4 |  |  | — |  |  | — |  |  | — |  |  | 3.4 |  |  | — |  |
| Total | $ | 277.1 |  |  | $ | (1.7 | ) |  | $ | 2.3 |  |  | $ | — |  |  | $ | 279.4 |  |  | $ | (1.7 | ) |

[0001628280-18-013240:notes:62]
[same as prior period, unchanged from 0001633978-18-000030:notes:42]

[0001628280-18-013240:notes:63]
|  | September 29, 2018 |  | June 30, 2018 |
|  | Amortized Cost |  | Fair Value |  | Amortized Cost |  | Fair Value |
| Due in 1 year | $ | 150.0 |  |  | $ | 149.5 |  |  | $ | 150.1 |  |  | $ | 149.6 |  |
| Due in 1 year through 5 years | 119.4 |  |  | 118.7 |  |  | 157.2 |  |  | 156.1 |  |
| Due in 5 years through 10 years | 4.9 |  |  | 4.9 |  |  | 6.1 |  |  | 6.1 |  |
| Due after 10 years | 1.8 |  |  | 1.8 |  |  | 2.4 |  |  | 2.4 |  |
|  | $ | 276.1 |  |  | $ | 274.9 |  |  | $ | 315.8 |  |  | $ | 314.2 |  |

[0001628280-18-013240:notes:64]
[same as prior period, unchanged from 0001633978-18-000030:notes:44]


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0001628280-18-013240:notes:65]
Note 16. Commitments and Contingencies

[0001628280-18-013240:notes:66]
Operating Leases

[0001628280-18-013240:notes:67]
We lease certain real and personal property from unrelated third parties under non-cancellable operating leases that expire at various dates through fiscal 2026. Certain leases require us to pay property taxes, insurance and routine maintenance, and include escalation clauses. As of September 29, 2018, the future minimum annual lease payments under non-cancellable operating leases were as follows (in millions):

[0001628280-18-013240:notes:68]
| Fiscal Years |  |
| Remainder of 2019 | $ | 8.8 |  |
| 2020 | 6.5 |  |
| 2021 | 5.1 |  |
| 2022 | 3.4 |  |
| 2023 | 2.4 |  |
| Thereafter | 1.8 |  |
| Total minimum operating lease payments | $ | 28.0 |  |

[0001628280-18-013240:notes:69]
During the three months ended September 29, 2018 and September 30, 2017, rental expense relating to building and equipment was $2.8 million and $3.4 million, respectively.

[0001628280-18-013240:notes:70]
Capital Lease

[0001628280-18-013240:notes:71]
As of September 29, 2018, equipment acquired under a capital lease agreement was $15.6 million. Our capital lease asset is included in property, plant and equipment, net in our condensed consolidated balance sheets as of September 29, 2018. Amortization expense on this capital lease asset is recorded as depreciation expense and is included in cost of sales in our condensed consolidated statements of operations for the three months ended September 29, 2018. Our capital lease obligation is recorded at the lesser of the estimated fair market value of the leased property or the net present value of the aggregate future minimum lease payments and is included in other current liabilities and other non-current liabilities in our condensed consolidated balance sheets as of September 29, 2018. Refer to “Note 6. Balance Sheet Details” for capital lease obligation amounts in other current liabilities and other non-current liabilities. Interest on these obligations is included in interest expense in our condensed consolidated statements of operations.

[0001628280-18-013240:notes:72]
As of September 29, 2018 the future minimum annual lease payments under our capital lease were as follows (in millions):

[0001628280-18-013240:notes:73]
| Fiscal Years |  |
| Remainder of 2019 | $ | 6.7 |  |
| 2020 | 0.4 |  |
| Total minimum capital lease payments | $ | 7.1 |  |
| Less: amount representing interest | $ | (0.1 | ) |
| Present value of capital lease obligation | $ | 7.0 |  |

[0001628280-18-013240:notes:74]
Acquisition Contingencies

[0001628280-18-013240:notes:75]
At the time of acquisition in February 2017, we incurred liabilities in the amount of $3.6 million. The amount of up to $3.0 million is expected to be paid within the following 12 months contingent upon meeting certain production targets, and is included in other current liabilities on our consolidated balance sheet as of September 29, 2018. We retained $1.0 million of the purchase price as security for any potential liabilities of the seller under the representations, warranties and indemnifications included in the purchase agreement. The amount of $1.0 million was fully paid to the seller during the three months ended September 29, 2018.

[0001628280-18-013240:notes:76]
0.25% Convertible Senior Notes due 2024

[0001628280-18-013240:notes:77]
The future interest and principal payments related to the 2024 Notes are as follows as of September 29, 2018:

[0001628280-18-013240:notes:78]
| Fiscal Years |  |
| Remainder of 2019 | $ | 0.6 |  |
| 2020 | 1.1 |  |
| 2021 | 1.1 |  |
| 2022 | 1.1 |  |
| 2023 | 1.1 |  |
| Thereafter | 451.2 |  |
| Total 2024 Notes payments | $ | 456.2 |  |

[0001628280-18-013240:notes:79]
Purchase Obligations

[0001628280-18-013240:notes:80]
Purchase obligations of $206.5 million as of September 29, 2018, represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule and adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

[0001628280-18-013240:notes:81]
We depend on a limited number of contract manufacturers, subcontractors and suppliers for raw materials, packages and standard components. We generally purchase these single or limited source products through standard purchase orders or one-year supply agreements and have no significant long-term guaranteed supply agreements with such vendors. While we seek to maintain a sufficient safety stock of such products and maintain on-going communications with our suppliers to guard against interruptions or cessation of supply, our business and results of operations could be adversely affected by a stoppage or delay of supply, substitution of more expensive or less reliable products, receipt of defective parts or contaminated materials, increases in the price of such supplies, or our inability to obtain reduced pricing from our suppliers in response to competitive pressures.

[0001628280-18-013240:notes:82]
Product Warranties

[0001628280-18-013240:notes:83]
We provide reserves for the estimated costs of product warranties at the time revenue is recognized. We typically offer a twelve month warranty for most of our products. However, in some instances depending upon the product, product component or application of our products by the end customer, our warranties can vary and generally range from six months to five years. We estimate the costs of our warranty obligations on an annualized basis based on our historical experience of known product failure rates, use of materials to repair or replace defective products and service delivery costs incurred in correcting product failures. In addition, from time to time, specific warranty accruals may be made if unforeseen technical problems arise with specific products. We assess the adequacy of our recorded warranty liabilities and adjust the amounts as necessary.

[0001628280-18-013240:notes:84]
The following table presents the changes in our warranty reserve during the three months ended September 29, 2018 and September 30, 2017 (in millions):

[0001628280-18-013240:notes:85]
|  | Three Months Ended |
|  | September 29, 2018 |  | September 30, 2017 |
| Balance as of beginning of period | $ | 6.6 |  |  | $ | 9.7 |  |
| Provision for warranty | 1.2 |  |  | 1.0 |  |
| Utilization of reserve | (1.2 | ) |  | (1.3 | ) |
| Balance as of end of period | $ | 6.6 |  |  | $ | 9.4 |  |

[0001628280-18-013240:notes:86]
Environmental Liabilities

[0001628280-18-013240:notes:87]
Our research and development (“R&D”), manufacturing and distribution operations involve the use of hazardous substances and are regulated under international, federal, state and local laws governing health and safety and the environment. We apply strict standards for protection of the environment and occupational health and safety to sites inside and outside the United States, even if not subject to regulations imposed by foreign governments. We believe that our properties and operations at our facilities comply in all material respects with applicable environmental laws and occupational health and safety laws. However, the risk of environmental liabilities cannot be completely eliminated and there can be no assurance that the application of environmental and health and safety laws will not require us to incur significant expenditures. We are also regulated under a number of international, federal, state and local laws regarding recycling, product packaging and product content requirements. The environmental, product content/disposal and recycling laws are gradually becoming more stringent and may cause us to incur significant expenditures in the future.

[0001628280-18-013240:notes:88]
In connection with the Separation, we agreed to indemnify Viavi for any liability associated with contamination from past operations at all properties transferred to us from Viavi, to the extent the resulting issues primarily related to our business.

[0001628280-18-013240:notes:89]
Legal Proceedings

[0001628280-18-013240:notes:90]
We are subject to a variety of claims and suits that arise from time to time in the ordinary course of our business. While management currently believes that resolving claims against us, individually or in the aggregate, will not have a material adverse impact on our financial position, results of operations or statements of cash flows, these matters are subject to inherent uncertainties and management’s view of these matters may change in the future. We accrue for loss contingencies when it is both probable that we will incur the loss and when we can reasonably estimate the amount of the loss or range of loss.

[0001628280-18-013240:notes:91]
Indemnifications

[0001628280-18-013240:notes:92]
In the normal course of business, we enter into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown because claims may be made against us in the future and we may record charges in the future as a result of these indemnification obligations. As of September 29, 2018, we did not have any material indemnification claims that were probable or reasonably possible.

[0001628280-18-013240:notes:93]
Audit Proceedings

[0001628280-18-013240:notes:94]
We are under audit by various domestic and foreign tax authorities with regards to income tax and indirect tax matters. In some, although not all cases, we have reserved for potential adjustments to our provision for income taxes and accrual of indirect taxes that may result from examinations by these tax authorities or final outcomes in judicial proceedings, and we believe that the final outcome of these examinations, agreements or judicial proceedings will not have a material effect on our results of operations. If events occur which indicate payment of these amounts is unnecessary, the reversal of the liabilities would result in the recognition of benefits in the period we determine the liabilities are no longer necessary. If our estimates of the federal, state, and foreign income tax liabilities and indirect tax liabilities are less than the ultimate assessment, it could result in a further charge to expense.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001628280-18-013240:notes:95]
[same as prior period, unchanged from 0001633978-18-000030:notes:74]

[0001628280-18-013240:notes:96]
[same as prior period, unchanged from 0001633978-18-000030:notes:75]

[0001628280-18-013240:notes:97]
As of September 29, 2018 and June 30, 2018, balances for the components of accumulated other comprehensive income (loss) were as follows (in millions):

[0001628280-18-013240:notes:98]
|  | Foreign currency translation adjustments, net of tax |  | Defined benefit obligation, net of tax (1) |  | Unrealized gain (loss) on available-for-sale securities, net of tax |  | Total |
| Beginning balance as of June 30, 2018 | $ | 10.3 |  |  | $ | (2.3 | ) |  | $ | (1.6 | ) |  | $ | 6.4 |  |
| Other comprehensive income | 0.1 |  |  | — |  |  | 0.4 |  |  | 0.5 |  |
| Ending balance as of September 29, 2018 | $ | 10.4 |  |  | $ | (2.3 | ) |  | $ | (1.2 | ) |  | $ | 6.9 |  |

[0001628280-18-013240:notes:99]
(1) We evaluate the assumptions over the fair value of our defined benefit obligation annually and make changes as necessary.


## us-gaap:ConvertibleDebtTableTextBlock

[0001628280-18-013240:notes:100]
The 2024 Notes consisted of the following components as of the periods presented (in millions):

[0001628280-18-013240:notes:101]
| Liability component: | September 29, 2018 |  | June 30, 2018 |
| Principal | $ | 450.0 |  |  | $ | 450.0 |  |
| Unamortized debt discount | (111.5 | ) |  | (115.8 | ) |
| Net carrying amount of the liability component | $ | 338.5 |  |  | $ | 334.2 |  |


## us-gaap:DebtDisclosureTextBlock

[0001628280-18-013240:notes:102]
Note 10. Convertible Senior Notes

[0001628280-18-013240:notes:103]
In March 2017, we issued the 2024 Notes in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act of 1933, as amended (the “Securities Act”). The 2024 Notes are governed by an indenture between the Company, as the issuer, and U.S. Bank National Association, as trustee (the “Indenture”). The 2024 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001628280-18-013240:notes:104]
The 2024 Notes bear interest at a rate of 0.25% per year. Interest on the 2024 Notes is payable semi-annually in arrears on March 15 and September 15 of each year, beginning on September 15, 2017. The 2024 Notes will mature on March 15, 2024, unless earlier repurchased by us or converted pursuant to their terms.

[0001628280-18-013240:notes:105]
The initial conversion rate of the 2024 Notes is 16.4965 shares of common stock per $1,000 principal amount of 2024 Notes, which is equivalent to an initial conversion price of approximately $60.62 per share, a 132.5% premium to the fair market value at the date of issuance. Prior to the close of business on the business day immediately preceding December 15, 2023, the 2024 Notes will be convertible only under the following circumstances: (1) during any fiscal quarter (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during the period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price, or $78.80 on each applicable trading day; (2) during the five consecutive business day period after any five consecutive trading day period (the “measurement period”) in which the trading price per $1,000 principal amount of notes for each trading day of such measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate on each such trading day; or (3) upon the occurrence of specified corporate events. On or after December 15, 2023 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their notes at any time. In addition, upon the occurrence of a make-whole fundamental change, we will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert 2024 Notes in connection with such make-whole fundamental change.

[0001628280-18-013240:notes:106]
We may not redeem the 2024 Notes prior to their maturity date and no sinking fund is provided for the 2024 Notes. Upon the occurrence of a fundamental change, holders may require us to repurchase all or a portion of their 2024 Notes for cash at a price equal to 100% of the principal amount of the 2024 Notes to be repurchased, plus any accrued and unpaid interest.

[0001628280-18-013240:notes:107]
We considered the features embedded in the 2024 Notes other than the conversion feature, including the holders’ put feature, our call feature, and the make-whole feature, and concluded that they are not required to be bifurcated and accounted for separately from the host debt instrument.

[0001628280-18-013240:notes:108]
Prior to the Tax Matters Agreement settlement condition (“TMA settlement condition”), because we could only settle the 2024 Notes in cash, we determined that the conversion feature met the definition of a derivative liability. We separated the derivative liability from the host debt instrument based on the fair value of the derivative liability. As of the issuance date, March 8, 2017, the derivative liability fair value of $129.9 million was calculated using the binomial valuation approach. The residual principal amount of the 2024 Notes of $320.1 million before issuance costs was allocated to the debt component. We incurred approximately $7.7 million in transaction costs in connection with the issuance of the 2024 Notes. These costs were allocated to the debt component and recognized as a debt discount. We amortize the debt discount, including both the initial value of the derivative liability and the transaction costs, over the term of the 2024 Notes using the effective interest method. The effective interest rate of the 2024 Notes is 5.4% per year. As of September 29, 2018, the remaining debt discount amortization period was 65 months.

[0001628280-18-013240:notes:109]
During the year ended July 1, 2017, we satisfied the TMA settlement condition. As such, the value of the conversion option will no longer be marked to market and was reclassified to additional paid-in capital within stockholders’ equity on our condensed consolidated balance sheet. The value of the conversion option at the time of issuance will be treated as an original issue discount for purposes of accounting for the debt component of the notes. The debt component will accrete up to the principal amount over the expected term of the debt. These accounting standards do not affect the actual amount we are required to repay, and the amount shown in the table below for the notes is the aggregate principal amount of the notes and does not reflect the debt discount we will be required to recognize.

[0001628280-18-013240:notes:110]
The following table sets forth interest expense information related to the 2024 Notes for the periods presented (in millions, except percentages):

[0001628280-18-013240:notes:111]
|  | Three Months Ended |
| (in millions, except percentages) | September 29, 2018 |  | September 30, 2017 |
| Contractual interest expense | $ | 0.3 |  |  | $ | 0.3 |  |
| Amortization of the debt discount | 4.3 |  |  | 4.1 |  |
| Total interest expense | $ | 4.6 |  |  | $ | 4.4 |  |
| Effective interest rate on the liability component | 5.4 | % |  | 5.4 | % |

[0001628280-18-013240:notes:112]
We have the ability and intent to settle the $450 million face value of the debt in cash. Therefore, we use the treasury stock method for calculating the dilutive impact of the debt. The 2024 Notes will have no impact to diluted earnings per share until the average price of our common stock exceeds the conversion price of $60.62.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001628280-18-013240:notes:113]
[same as prior period, unchanged from 0001633978-18-000030:notes:92]

[0001628280-18-013240:notes:114]
We estimate the fair value of the embedded derivative for the Series A Preferred Stock using the binomial lattice model. We applied the lattice model to value the embedded derivative using a “with-and-without method,” where the value of the Series A Preferred Stock, including the embedded derivative, is defined as the “with”, and the value of the Series A Preferred Stock, excluding the embedded derivative, is defined as the “without”. The lattice model requires the following inputs: (i) the Company's common stock price; (ii) conversion price; (iii) term; (iv) yield; (v) recovery rate for the Series A Preferred Stock; (vi) estimated stock volatility; and (vii) risk-free rate. The fair value of the embedded derivative was determined using Level 3 inputs under the fair value hierarchy (unobservable inputs). Changes in the inputs into this valuation model have a material impact in the estimated fair value of the embedded derivative. For example, a decrease (increase) in the stock price and the volatility results in a decrease (increase) in the estimated fair value of the embedded derivative. The changes in the fair value of the bifurcated embedded derivative for the Series A Preferred Stock are primarily related to the change in the price of our common stock and are reflected in the condensed consolidated statements of operations as “Unrealized gain (loss) on derivative liability”. Unrealized gain (loss) on derivative liability for the Series A Preferred Stock amounted to $(2.1) million and $4.2 million for the three months ended September 29, 2018 and September 30, 2017, respectively.

[0001628280-18-013240:notes:115]
The following table provides a reconciliation of the fair value of the embedded derivative for the Series A Preferred Stock for the three months ended September 29, 2018 and September 30, 2017 (in millions):

[0001628280-18-013240:notes:116]
|  | Three Months Ended |
|  | September 29, 2018 |  | September 30, 2017 |
| Balance as of beginning of period | $ | 52.4 |  |  | $ | 51.6 |  |
| Unrealized (gain) loss on the Series A Preferred Stock derivative liability | 2.1 |  |  | (4.2 | ) |
| Balance as of end of period | $ | 54.5 |  |  | $ | 47.4 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001628280-18-013240:notes:117]
[same as prior period, unchanged from 0001633978-18-000030:notes:99]

[0001628280-18-013240:notes:118]
[same as prior period, unchanged from 0001633978-18-000030:notes:100]

[0001628280-18-013240:notes:119]
Equity Incentive Plan

[0001628280-18-013240:notes:120]
[same as prior period, unchanged from 0001633978-18-000030:notes:102]

[0001628280-18-013240:notes:121]
[same as prior period, unchanged from 0001633978-18-000030:notes:103]

[0001628280-18-013240:notes:122]
As of September 29, 2018, we had 2.0 million shares subject to restricted stock units, restricted stock awards, and performance stock units issued and outstanding under the 2015 Plan. Restricted stock units, restricted stock awards, and performance stock units are performance-based, time-based or a combination of both and are expected to vest over one to four years. The fair value of these grants is based on the closing market price of our common stock on the date of award.

[0001628280-18-013240:notes:123]
[same as prior period, unchanged from 0001633978-18-000030:notes:105]

[0001628280-18-013240:notes:124]
As of September 29, 2018, 5.0 million shares of common stock under the 2015 Plan were available for grant.

[0001628280-18-013240:notes:125]
[same as prior period, unchanged from 0001633978-18-000030:notes:109]

[0001628280-18-013240:notes:126]
Restricted stock units (“RSUs”) under the 2015 Plan are grants of shares of our common stock, the vesting of which is based on the requisite service requirement. Generally, our RSUs are subject to forfeiture and expected to vest over one to four years. For annual refresh grants, RSUs generally vest ratably on an annual, or combination of annual and quarterly, basis over three years.

[0001628280-18-013240:notes:127]
[same as prior period, unchanged from 0001633978-18-000030:notes:111]

[0001628280-18-013240:notes:128]
[same as prior period, unchanged from 0001633978-18-000030:notes:112]

[0001628280-18-013240:notes:129]
[same as prior period, unchanged from 0001633978-18-000030:notes:113]

[0001628280-18-013240:notes:130]
[same as prior period, unchanged from 0001633978-18-000030:notes:114]

[0001628280-18-013240:notes:131]
During the three months ended September 29, 2018, our board of directors preliminary approved the grant of 0.2 million PSUs to senior members of our management team. The grant date has not been established for these awards as the performance targets will only be set and approved by our board in the quarter ending December 29, 2018. As such, no stock-based compensation has been recorded for these grants during the three months ended September 29, 2018.

[0001628280-18-013240:notes:132]
[same as prior period, unchanged from 0001633978-18-000030:notes:107]

[0001628280-18-013240:notes:133]
On June 23, 2015, we adopted, and the board of directors of JDSU approved, the 2015 Employee Stock Purchase Plan (the “2015 Purchase Plan”) under which 3.0 million shares of our common stock were authorized for issuance, which was ratified by our board of directors in August 2015. The 2015 Purchase Plan provides eligible employees with the opportunity to acquire an ownership interest in the Company through periodic payroll deductions and provides a 15% purchase price discount as well as a six-month look-back period. The 2015 Purchase Plan is structured as a qualified employee stock purchase plan under Section 423 of the Internal Revenue Code of 1986. However, the 2015 Purchase Plan is not intended to be a qualified pension, profit sharing or stock bonus plan under Section 401(a) of the Internal Revenue Code of 1986 and is not subject to the provisions of the Employee Retirement Income Security Act of 1974. The 2015 Purchase Plan will terminate upon the date on which all shares available for issuance have been sold. Of the 3.0 million shares authorized under the 2015 Purchase Plan, 2.3 million shares remained available for issuance as of September 29, 2018.

[0001628280-18-013240:notes:134]
[same as prior period, unchanged from 0001633978-18-000030:notes:116]

[0001628280-18-013240:notes:135]
The impact on our results of operations of recording stock-based compensation by function for the three months ended September 29, 2018 and September 30, 2017 was as follows (in millions):

[0001628280-18-013240:notes:136]
|  | Three Months Ended |
|  | September 29, 2018 |  | September 30, 2017 |
| Cost of sales | $ | 3.3 |  |  | $ | 2.7 |  |
| Research and development | 2.8 |  |  | 3.1 |  |
| Selling, general and administrative | 4.7 |  |  | 3.5 |  |
|  | $ | 10.8 |  |  | $ | 9.3 |  |

[0001628280-18-013240:notes:137]
Approximately $2.1 million and $2.6 million of stock-based compensation was capitalized to inventory as of September 29, 2018 and June 30, 2018, respectively.

[0001628280-18-013240:notes:138]
[same as prior period, unchanged from 0001633978-18-000030:notes:120]

[0001628280-18-013240:notes:139]
We did not grant any stock options during the three months ended September 29, 2018 and September 30, 2017. As of September 29, 2018 and June 30, 2018, there were no options outstanding under the 2015 Plan.

[0001628280-18-013240:notes:140]
During the three months ended September 30, 2017, there were 40,270 options exercised by our employees with the total intrinsic value of $0.7 million.

[0001628280-18-013240:notes:141]
The following table summarizes our awards activity for the three months ended September 29, 2018 (in millions, except per share amounts):

[0001628280-18-013240:notes:142]
|  | Restricted Stock Units |  | Restricted Stock Awards |  | Performance Stock Units |
|  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |  | Number of Shares (1) |  | Weighted-Average Grant Date Fair Value per Share |
| Unvested balance as of beginning of period | 1.7 |  |  | $ | 43.1 |  |  | 0.1 |  |  | $ | 32.5 |  |  | 0.2 |  |  | $ | 52.0 |  |
| Granted | 0.7 |  |  | 67.8 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Vested | (0.5 | ) |  | 38.4 |  |  | — |  |  | — |  |  | (0.1 | ) |  | 52.0 |  |
| Canceled | (0.1 | ) |  | 49.6 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Unvested balance as of end of period | 1.8 |  |  | $ | 55.2 |  |  | 0.1 |  |  | $ | 32.5 |  |  | 0.1 |  |  | $ | — |  |

[0001628280-18-013240:notes:143]
(1) In fiscal 2018, we granted 0.1 million PSUs to senior members of our management team subject to revenue performance condition. The number of awards granted in fiscal 2018 represented 100% of target goal; under the terms of the awards, the recipient could earn between 0% and 200% of the original grant. The performance condition was achieved in fiscal 2018. During the three months ended September 29, 2018, our board of directors approved an increase in the original number of PSUs based on the actual achievement.

[0001628280-18-013240:notes:144]
As of September 29, 2018, $97.8 million of stock-based compensation cost related to awards granted to our employees remains to be amortized. That cost is expected to be recognized over an estimated amortization period of 2.1 years.

[0001628280-18-013240:notes:145]
A summary of awards available for grant is as follows (in millions):

[0001628280-18-013240:notes:146]
|  | Awards Available for Grant |
| Balance as of beginning of period | 5.6 |  |
| Granted | (0.7 | ) |
| Canceled | 0.1 |  |
| Balance as of end of period | 5.0 |  |

[0001628280-18-013240:notes:147]
[same as prior period, unchanged from 0001633978-18-000030:notes:127]

[0001628280-18-013240:notes:148]
The 2015 Purchase Plan expense for the three months ended September 29, 2018 and September 30, 2017 was $1.0 million and $0.8 million, respectively. The expense related to the 2015 Purchase Plan is recorded on a straight-line basis over the relevant subscription period. During the three months ended September 29, 2018 and September 30, 2017, there were no shares issued to employees through the 2015 Purchase Plan.

[0001628280-18-013240:notes:149]
We estimate the fair value of the 2015 Purchase Plan shares on the date of grant using the Black-Scholes option-pricing model. During the three months ended September 29, 2018 and September 30, 2017, the assumptions used to estimate the fair value of the 2015 Purchase Plan shares to be issued were as follows:

[0001628280-18-013240:notes:150]
|  | September 29, 2018 |  | September 30, 2017 |
| Expected term (years) | 0.5 |  |  | 0.5 |  |
| Expected volatility | 58.8 | % |  | 53.0 | % |
| Risk-free interest rate | 2.02 | % |  | 1.02 | % |
| Dividend yield | — | % |  | — | % |


## us-gaap:EarningsPerShareTextBlock

[0001628280-18-013240:notes:151]
[same as prior period, unchanged from 0001633978-18-000030:notes:132]

[0001628280-18-013240:notes:152]
The following table sets forth the computation of basic and diluted net income attributable to common stockholders per share (in millions, except per share data):

[0001628280-18-013240:notes:153]
|  | Three Months Ended |
|  | September 29, 2018 |  | September 30, 2017 |
| Basic Earnings per Common Share |  |  |  |  |  |
| Net income | $ | 47.4 |  |  | $ | 7.1 |  |
| Less: Cumulative dividends on Series A Preferred Stock | (0.2 | ) |  | (0.2 | ) |
| Less: Earnings allocated to Series A Preferred Stock | (1.1 | ) |  | (0.2 | ) |
| Net income attributable to common stockholders - Basic | $ | 46.1 |  |  | $ | 6.7 |  |
| Weighted average common shares outstanding including Series A Preferred Stock | 64.6 |  |  | 63.2 |  |
| Less: Weighted average Series A Preferred Stock | (1.5 | ) |  | (1.5 | ) |
| Basic weighted average common shares outstanding | 63.1 |  |  | 61.7 |  |
| Net income per share attributable to common stockholders - Basic | $ | 0.73 |  |  | $ | 0.11 |  |
| Diluted Earnings per Common Share |  |  |  |
| Net income attributable to common stockholders - Basic | $ | 46.1 |  |  | $ | 6.7 |  |
| Add: Earnings allocated to Series A Preferred Stock | — |  |  | 0.2 |  |
| Add/Less: Unrealized (gain) loss on derivative liability on Series A Preferred Stock | — |  |  | (4.2 | ) |
| Add: Cumulative dividends on Series A Preferred Stock | — |  |  | 0.2 |  |
| Net income attributable to common stockholders - Diluted (a) | $ | 46.1 |  |  | $ | 2.9 |  |
| Weighted average common shares outstanding for basic earnings per common share | 63.1 |  |  | 61.7 |  |
| Effect of dilutive securities from 2015 Equity Incentive Plan | 0.8 |  |  | 1.3 |  |
| Effect of dilutive securities from Series A Preferred Stock | — |  |  | 1.5 |  |
| Diluted weighted average common shares outstanding | 63.9 |  |  | 64.5 |  |
| Net income per share attributable to common stockholders - Diluted | $ | 0.72 |  |  | $ | 0.04 |  |

[0001628280-18-013240:notes:154]
(a) For the three months ended September 30, 2017, our diluted earnings per share attributable to common stockholders is calculated using the if-converted method because it is more dilutive, whereas for the three months ended September 29, 2018, our diluted earnings per share attributable to common stockholders is calculated using the treasury stock method.

[0001628280-18-013240:notes:155]
Our Series A Preferred Stock is considered a participating security, which may participate in undistributed earnings with our common stock. The holders of our Preferred Stock would be entitled to share in dividends, on an as-converted basis, if the holders of our common stock were to receive dividends. We are required to use the two-class method when computing earnings per share as we have a security that qualifies as a participating security. The two-class method is an earnings allocation formula that determines earnings per share for each class of common stock and participating security according to dividends declared (or accumulated) and participation rights in undistributed earnings. In determining the amount of net earnings to allocate to common stockholders, earnings are allocated to both common and participating securities based on their respective weighted-average shares outstanding during the period. Under the two-class method, basic earnings per common share is calculated by dividing the net income (loss) attributable to common stockholders by the weighted-average number of shares of common stock outstanding for the period. The diluted earnings per common share is calculated similarly to basic earnings per common share except that it gives effect to all potentially dilutive common stock equivalents outstanding for the period using the treasury stock method. Diluted earnings per common share, when applicable, is computed using the more dilutive of the treasury stock method or the if-converted method. In periods of net loss, no effect is given to participating securities since they do not contractually participate in the losses of the Company.

[0001628280-18-013240:notes:156]
In March 2017, we issued $450 million in aggregate principal amount of 0.25% Convertible Senior Notes due in 2024 (the “2024 Notes”). We have the ability and intent to settle the $450 million face value of the 2024 Notes in cash. Therefore, we use the treasury stock method for calculating the dilutive impact of the 2024 Notes. The 2024 Notes will have no impact to diluted earnings per share until the average price of our common stock exceeds the conversion price of $60.62. Refer to “Note 10. Convertible Senior Notes” for further discussion.

[0001628280-18-013240:notes:157]
The dilutive effect of securities from the 2015 Equity Incentive Plan is reflected in diluted earnings per share by application of the treasury stock method, which includes consideration of unamortized share-based compensation expense and the dilutive effect of in-the-money options and non-vested restricted stock units. Under the treasury stock method, the amount the employee must pay for exercising stock options and the amount of unamortized share-based compensation expense are collectively assumed to be used to repurchase hypothetical shares. An increase in the fair value of our common stock can result in a greater dilutive effect from potentially dilutive awards.

[0001628280-18-013240:notes:158]
Anti-dilutive potential shares from 2015 Equity Incentive Plan are excluded from the calculation of diluted earnings per share if their exercise price exceeded the average market price during the period or the share-based awards were determined to be anti-dilutive based on applying the treasury stock method.


## us-gaap:FairValueDisclosuresTextBlock

[0001628280-18-013240:notes:159]
[same as prior period, unchanged from 0001633978-18-000030:notes:139]

[0001628280-18-013240:notes:160]
[same as prior period, unchanged from 0001633978-18-000030:notes:140]

[0001628280-18-013240:notes:161]
[same as prior period, unchanged from 0001633978-18-000030:notes:141]

[0001628280-18-013240:notes:162]
[same as prior period, unchanged from 0001633978-18-000030:notes:142]

[0001628280-18-013240:notes:163]
[same as prior period, unchanged from 0001633978-18-000030:notes:143]

[0001628280-18-013240:notes:164]
In February 2017, we completed the acquisition of a privately held company to enhance our manufacturing and vertical integration capabilities for a total purchase consideration of $8.7 million. We estimated the fair value of our Level 3 contingent consideration related to this acquisition at the present value of the expected contingent payments, determined using a probabilistic approach. We are required to reassess the fair value of contingent payments on a periodic basis. We estimated the likelihood of meeting the production targets at 90 percent and recorded the fair value of such contingent consideration in other current liabilities on the condensed consolidated balance sheet as of September 29, 2018. This contingent consideration will result in a cash payment of $3.0 million, if and when the production targets are achieved, which we expect to occur within the following 12 months. There was no change in the fair value of our contingent consideration during the three months ended September 29, 2018 and September 30, 2017.

[0001628280-18-013240:notes:165]
[same as prior period, unchanged from 0001633978-18-000030:notes:145]

[0001628280-18-013240:notes:166]
[same as prior period, unchanged from 0001633978-18-000030:notes:146]

[0001628280-18-013240:notes:167]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| September 29, 2018: |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | — |  |  | $ | 3.6 |  |  | $ | — |  |  | $ | 3.6 |  |
| Money market funds | 286.5 |  |  | — |  |  | — |  |  | 286.5 |  |
| U.S. Treasury | 19.4 |  |  | — |  |  | — |  |  | 19.4 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Commercial paper | — |  |  | 6.7 |  |  | — |  |  | 6.7 |  |
| Asset-backed securities | — |  |  | 58.3 |  |  | — |  |  | 58.3 |  |
| Corporate debt securities | — |  |  | 201.4 |  |  | — |  |  | 201.4 |  |
| Municipal bonds | — |  |  | 0.4 |  |  | — |  |  | 0.4 |  |
| Mortgage-backed securities | — |  |  | 3.0 |  |  | — |  |  | 3.0 |  |
| Foreign government bonds | — |  |  | 5.1 |  |  | — |  |  | 5.1 |  |
| Total assets | $ | 305.9 |  |  | $ | 278.5 |  |  | $ | — |  |  | $ | 584.4 |  |
| Other accrued liabilities: |  |  |  |  |  |  |  |
| Derivative liability | $ | — |  |  | $ | — |  |  | $ | 54.5 |  |  | $ | 54.5 |  |
| Acquisition contingencies | — |  |  | — |  |  | 2.7 |  |  | 2.7 |  |
| Total other accrued liabilities | $ | — |  |  | $ | — |  |  | $ | 57.2 |  |  | $ | 57.2 |  |

[0001628280-18-013240:notes:168]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| June 30, 2018: |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | — |  |  | $ | 3.0 |  |  | $ | — |  |  | $ | 3.0 |  |
| Commercial paper | — |  |  | 112.1 |  |  | — |  |  | 112.1 |  |
| Money market funds | 0.8 |  |  | — |  |  | — |  |  | 0.8 |  |
| U.S. Treasury securities | 143.6 |  |  | — |  |  | — |  |  | 143.6 |  |
| U.S. Agency securities | — |  |  | 34.2 |  |  | — |  |  | 34.2 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | 7.5 |  |  | — |  |  | 7.5 |  |
| Commercial paper | — |  |  | 10.5 |  |  | — |  |  | 10.5 |  |
| Asset-backed securities | — |  |  | 67.8 |  |  | — |  |  | 67.8 |  |
| Corporate debt securities | — |  |  | 219.2 |  |  | — |  |  | 219.2 |  |
| Municipal bonds | — |  |  | 1.6 |  |  | — |  |  | 1.6 |  |
| Mortgage-backed securities | — |  |  | 4.2 |  |  | — |  |  | 4.2 |  |
| Foreign government bonds | — |  |  | 3.4 |  |  | — |  |  | 3.4 |  |
| Total assets | $ | 144.4 |  |  | $ | 463.5 |  |  | $ | — |  |  | $ | 607.9 |  |
| Other accrued liabilities: |  |  |  |  |  |  |  |
| Derivative liability | $ | — |  |  | $ | — |  |  | $ | 52.4 |  |  | $ | 52.4 |  |
| Acquisition contingencies | — |  |  | — |  |  | 2.7 |  |  | 2.7 |  |
| Total other accrued liabilities | $ | — |  |  | $ | — |  |  | $ | 55.1 |  |  | $ | 55.1 |  |

[0001628280-18-013240:notes:169]
[same as prior period, unchanged from 0001633978-18-000030:notes:149]

[0001628280-18-013240:notes:170]
[same as prior period, unchanged from 0001633978-18-000030:notes:150]

[0001628280-18-013240:notes:171]
Management utilizes various valuation methods, including an income approach, a market approach and a cost approach, to estimate the fair value of intangible and other long-lived assets. During the annual impairment testing performed in fiscal 2018, we concluded that our intangible and other long-lived assets were not impaired. No impairment charges were recorded during the three months ended September 29, 2018 and September 30, 2017. Refer to “Note 12. Goodwill and Other Intangible Assets”.


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0001628280-18-013240:notes:172]
Management utilizes various valuation methods, including an income approach, a market approach and a cost approach, to estimate the fair value of intangible and other long-lived assets.


## us-gaap:FiniteLivedIntangibleAssetsAmortizationExpenseTableTextBlock

[0001628280-18-013240:notes:173]
[same as prior period, unchanged from 0001633978-18-000030:notes:152]

[0001628280-18-013240:notes:174]
|  | Three Months Ended |
|  | September 29, 2018 |  | September 30, 2017 |
| Cost of sales | $ | 0.8 |  |  | $ | 0.8 |  |
| Total | $ | 0.8 |  |  | $ | 0.8 |  |


## us-gaap:GoodwillDisclosureTextBlock

[0001628280-18-013240:notes:175]
[same as prior period, unchanged from 0001633978-18-000030:notes:154]

[0001628280-18-013240:notes:176]
[same as prior period, unchanged from 0001633978-18-000030:notes:155]

[0001628280-18-013240:notes:177]
The following table presents the changes in goodwill by our reportable segments during the three months ended September 29, 2018 (in millions):

[0001628280-18-013240:notes:178]
|  | Optical Communications |  | Commercial Lasers |  | Total |
| Balance as of beginning of period | $ | 5.9 |  |  | $ | 5.4 |  |  | $ | 11.3 |  |
| Foreign currency translation adjustment | — |  |  | — |  |  | — |  |
| Balance as of end of period | $ | 5.9 |  |  | $ | 5.4 |  |  | $ | 11.3 |  |

[0001628280-18-013240:notes:179]
The following table presents the changes in goodwill by our reportable segments during the three months ended September 30, 2017 (in millions):

[0001628280-18-013240:notes:180]
|  | Optical Communications |  | Commercial Lasers |  | Total |
| Balance as of beginning of period | $ | 5.9 |  |  | $ | 5.5 |  |  | $ | 11.4 |  |
| Foreign currency translation adjustment | 0.2 |  |  | (0.1 | ) |  | 0.1 |  |
| Balance as of end of period | $ | 6.1 |  |  | $ | 5.4 |  |  | $ | 11.5 |  |

[0001628280-18-013240:notes:181]
[same as prior period, unchanged from 0001633978-18-000030:notes:158]

[0001628280-18-013240:notes:182]
We review goodwill for impairment during the fourth quarter of each fiscal year or more frequently if events or circumstances indicate that an impairment loss may have occurred. In the fourth quarter of fiscal 2018, we completed the annual impairment test of goodwill, which indicated there was no goodwill impairment. During the three months ended September 29, 2018 and September 30, 2017, there have been no events or circumstances that have required us to perform an interim assessment of goodwill for impairment.

[0001628280-18-013240:notes:183]
Acquired Developed Technologies and Other Intangibles

[0001628280-18-013240:notes:184]
The following tables present details of our acquired developed technologies and other intangibles as of the periods presented (in millions):

[0001628280-18-013240:notes:185]
| September 29, 2018: | Gross Carrying Amount |  | Accumulated Amortization |  | Net |
| Acquired developed technologies | $ | 105.6 |  |  | $ | (99.3 | ) |  | $ | 6.3 |  |
| Other intangibles | 7.0 |  |  | (7.0 | ) |  | — |  |
| Total intangible assets | $ | 112.6 |  |  | $ | (106.3 | ) |  | $ | 6.3 |  |

[0001628280-18-013240:notes:186]
| June 30, 2018: | Gross Carrying Amount |  | Accumulated Amortization |  | Net |
| Acquired developed technologies | $ | 105.5 |  |  | $ | (98.5 | ) |  | $ | 7.0 |  |
| Other intangibles | 7.0 |  |  | (7.0 | ) |  | — |  |
| Total intangible assets | $ | 112.5 |  |  | $ | (105.5 | ) |  | $ | 7.0 |  |

[0001628280-18-013240:notes:187]
[same as prior period, unchanged from 0001633978-18-000030:notes:164]

[0001628280-18-013240:notes:188]
During the three months ended September 29, 2018 and September 30, 2017, we recorded $0.8 million and $0.8 million, respectively, of amortization related to acquired developed technologies.

[0001628280-18-013240:notes:189]
Based on the carrying amount of acquired developed technologies as of September 29, 2018, and assuming no future impairment of the underlying assets, the estimated future amortization is as follows (in millions):

[0001628280-18-013240:notes:190]
| Fiscal Years |  |
| Remainder of 2019 | $ | 2.2 |  |
| 2020 | 2.9 |  |
| 2021 | 0.5 |  |
| 2022 | 0.5 |  |
| Thereafter | 0.2 |  |
| Total amortization | $ | 6.3 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-18-013240:notes:191]
[same as prior period, unchanged from 0001633978-18-000030:notes:169]

[0001628280-18-013240:notes:192]
The comparability of our operating results in the first quarter of fiscal 2019 compared to the corresponding prior year period was impacted by the U.S. Tax Cuts and Jobs Act of 2017 (the Tax Act), which was enacted on December 22, 2017. The Tax Act introduced significant changes to U.S. income tax law including reducing the U.S. federal statutory tax rate from 35% to 21% and imposing new taxes on certain foreign-sourced earnings and certain intercompany payments. Due to the timing of the enactment and the complexity involved in applying the provisions of the Tax Act, we made reasonable estimates of the effects and recorded provisional amounts in our financial statements as of fiscal 2018 in accordance with SEC Staff Accounting Bulletin No. 118 (SAB 118). No further adjustments were made to the provisional amounts in the first quarter of fiscal 2019. The accounting for the tax effects of the Tax Act will be completed within the measurement period in accordance with SAB 118.

[0001628280-18-013240:notes:193]
[same as prior period, unchanged from 0001633978-18-000030:notes:170]

[0001628280-18-013240:notes:194]
Our quarterly tax provision, and estimate of our annual effective tax rate, is subject to variation due to several factors, including variability in pre-tax income (or loss), the mix of jurisdictions to which such income relates, changes in how we do business, and tax law developments. Our estimated effective tax rate for the year differs from the 21% U.S. statutory rate primarily due to the benefit of foreign earnings of our subsidiaries being taxed at rates lower than the U.S. statutory rate.

[0001628280-18-013240:notes:195]
We recorded a tax expense of $5.2 million for the three months ended September 29, 2018. Our provision for income taxes for the three months September 29, 2018 varied from the 21% U.S. statutory rate primarily due to earnings in our foreign subsidiaries, the U.S. research and development tax credit, and the tax effects of stock-based compensation, partially offset by the tax effect of Global Intangible Low-Taxed Income (GILTI) and subpart F income inclusion.

[0001628280-18-013240:notes:196]
We recorded a tax benefit of $(3.6) million for the three months ended September 30, 2017. Our provision for income taxes for the three months ended September 30, 2017 varied from the previous U.S. federal statutory income tax rate of 35% primarily due to earnings in foreign operations, the tax benefit from excess stock-based compensation deductions, and the non-taxable unrealized gain from the embedded derivatives for the Series A Preferred Stock.

[0001628280-18-013240:notes:197]
As of September 29, 2018, we had $9.0 million of unrecognized tax benefits, which, if recognized, would affect the effective tax rate. We are subject to examination of income tax returns by various domestic and foreign tax authorities. The timing of resolutions and closures of tax audits is highly unpredictable. Given the uncertainty, it is reasonably possible that certain tax audits may be concluded within the next 12 months. An estimate of the range of increase or decrease that could occur in the next twelve months cannot be made. However, the estimated impact to tax expense and net income from the resolution and closure of tax exams is not expected to be significant within the next 12 months.

[0001628280-18-013240:notes:198]
On July 24, 2018, the Ninth Circuit Court of Appeals (the “Court”) issued an opinion in Altera Corp. v. Commissioner requiring related parties in an intercompany cost sharing arrangement to share expenses related to share-based compensation. This opinion reversed the prior decision of the United States Tax Court. On August 7, 2018, the Court withdrew the opinion issued on July 24, 2018 to allow time for a reconstituted panel of judges to confer. We will continue to monitor the case and potential impact to our consolidated financial statements.


## us-gaap:MinorityInterestDisclosureTextBlock

[0001628280-18-013240:notes:199]
[same as prior period, unchanged from 0001633978-18-000030:notes:186]

[0001628280-18-013240:notes:200]
[same as prior period, unchanged from 0001633978-18-000030:notes:187]

[0001628280-18-013240:notes:201]
The Series A Preferred Stock is redeemable at the option of Amada after five years and classified as non-controlling interest redeemable convertible preferred stock in our condensed consolidated balance sheet. The Series A Preferred Stock is measured at its redemption value. The Series A Preferred Stock value of $35.8 million as of September 29, 2018 has not changed from the prior year.

[0001628280-18-013240:notes:202]
[same as prior period, unchanged from 0001633978-18-000030:notes:189]

[0001628280-18-013240:notes:203]
[same as prior period, unchanged from 0001633978-18-000030:notes:190]

[0001628280-18-013240:notes:204]
[same as prior period, unchanged from 0001633978-18-000030:notes:191]

[0001628280-18-013240:notes:205]
The Series A Preferred Stock is convertible, at the option of the holder, into shares of our common stock commencing on the second anniversary of the closing of the securities purchase in August 2017 (absent a change of control of us or similar event) using a conversion price of $24.63, which is equal to 125% of the volume weighted average price per share of our common stock in the five “regular-way” trading days following our separation from JDS Uniphase Corporation (“JDSU” and now, Viavi) in August 2015 (the “Separation”).

[0001628280-18-013240:notes:206]
[same as prior period, unchanged from 0001633978-18-000030:notes:193]

[0001628280-18-013240:notes:207]
[same as prior period, unchanged from 0001633978-18-000030:notes:194]

[0001628280-18-013240:notes:208]
[same as prior period, unchanged from 0001633978-18-000030:notes:195]

[0001628280-18-013240:notes:209]
[same as prior period, unchanged from 0001633978-18-000030:notes:196]

[0001628280-18-013240:notes:210]
[same as prior period, unchanged from 0001633978-18-000030:notes:197]

[0001628280-18-013240:notes:211]
[same as prior period, unchanged from 0001633978-18-000030:notes:198]

[0001628280-18-013240:notes:212]
[same as prior period, unchanged from 0001633978-18-000030:notes:199]

[0001628280-18-013240:notes:213]
[same as prior period, unchanged from 0001633978-18-000030:notes:200]

[0001628280-18-013240:notes:214]
[same as prior period, unchanged from 0001633978-18-000030:notes:201]

[0001628280-18-013240:notes:215]
[same as prior period, unchanged from 0001633978-18-000030:notes:202]

[0001628280-18-013240:notes:216]
The accrued dividends as of September 29, 2018 and June 30, 2018 were $0.2 million and $0.4 million, respectively. During the three months ended September 29, 2018 and September 30, 2017, we paid $0.4 million and $0.2 million, respectively, in dividends to the holders of Series A Preferred Stock.

[0001628280-18-013240:notes:217]
[same as prior period, unchanged from 0001633978-18-000030:notes:205]

[0001628280-18-013240:notes:218]
[same as prior period, unchanged from 0001633978-18-000030:notes:206]

[0001628280-18-013240:notes:219]
On or after the third anniversary, which occurred in August 2018, we have the option upon providing notice of not less than 30 calendar days to redeem for cash all (but not less than all) of the shares of Series A Preferred Stock at a redemption price equal to the Issuance Value plus the accrued and unpaid dividends on each share and any past due dividends, whether or not authorized or declared.

[0001628280-18-013240:notes:220]
On October 15, 2018, we issued a 30-day notice of intent to the holders of Series A Preferred Stock to redeem all shares of Series A Preferred Stock. We expect the holders of Series A Preferred Stock to exercise their right to convert by November 14, 2018.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001628280-18-013240:notes:221]
Accounting Pronouncements Recently Adopted

[0001628280-18-013240:notes:222]
In May 2014, the Financial Accounting Standards Board (“FASB”) issued ASU 2014-09 (Topic 606), which amended the existing accounting standards for revenue recognition. Topic 606 outlines a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers. The guidance is effective for annual reporting periods including interim reporting periods beginning after December 15, 2017. On July 1, 2018, we adopted Topic 606 using the modified retrospective method applied to all contracts that are not completed contracts at the date of initial adoption (i.e., July 1, 2018). Results for reporting periods after July 1, 2018 are presented under Topic 606, while prior period amounts are not adjusted and continue to be reported in accordance with our historic accounting under Topic 605. The adoption of Topic 606 did not have a material impact on the nature and timing of our revenues, condensed consolidated statements of operations, cash flows, and balance sheet and therefore, we do not present results for the three months ended September 29, 2018 under Topic 605. Refer to “Note 1. Description of Business and Summary of Significant Accounting Policies” for the changes in our accounting policies due to adoption of Topic 606.

[0001628280-18-013240:notes:223]
Select condensed consolidated balance sheet line items, as if we had adopted Topic 606 in previous years, are summarized below as of the periods presented:

[0001628280-18-013240:notes:224]
|  | June 30, 2018 |  | Adjustments |  | July 1, 2018 |
| Assets: |  |  |  |  |  |
| Accounts receivable, net | $ | 197.1 |  |  | $ | 0.6 |  |  | $ | 197.7 |  |
| Inventories | 153.6 |  |  | (1.2 | ) |  | 152.4 |  |
| Stockholders’ equity: |  |  |  |  |  |
| Retained earnings | $ | 166.4 |  |  | $ | (0.6 | ) |  | $ | 165.8 |  |

[0001628280-18-013240:notes:225]
In August 2016, FASB issued ASU 2016-15, Statement of Cash Flows (Topic 230): Classification of Certain Cash Receipts and Cash Payments, which clarifies how companies present and classify certain cash receipts and cash payments in the statement of cash flows. The amendments contained in ASU 2016-15 are effective for interim and annual periods beginning after December 15, 2017. We adopted ASU 2016-15 on July 1, 2018 on a prospective basis. The application of ASU 2016-15 will have a material impact on our consolidated financial statements if we elect to settle the principal amounts of our 2024 Notes (refer to “Note 10. Convertible Senior Notes”) in cash. The principal repayment will be bifurcated between (i) cash outflows for operating activities of $137.6 million for the portion related to accreted interest attributable to debt discount, and (ii) financing activities for the remainder of $312.4 million.

[0001628280-18-013240:notes:226]
In January 2017, FASB issued ASU 2017-01, Business Combinations (Topic 805), which clarifies the definition of a business. For accounting and financial reporting purposes, businesses are generally comprised of three elements; inputs, processes, and outputs. Integrated sets of assets and activities capable of providing these three elements may not always be considered a business, and the lack of one of the three elements does not always disqualify the set from being a business. The issuance of ASU 2017-01 provides a clarifying screen to determine when a set of assets and activities is not a business. Primarily, the screen requires that when substantially all of the fair value of the gross assets acquired is concentrated in a single identifiable asset or group of similar identifiable assets, the set is not a business. The amendments contained in ASU 2017-01 are effective for annual periods beginning after December 15, 2017, including interim periods within those periods. We adopted ASU 2017-01 on July 1, 2018 on a prospective basis. The implementation of ASU 2017-01 did not have an impact on our financial statements.

[0001628280-18-013240:notes:227]
In October 2016, FASB issued ASU 2016-16, Accounting for Income Taxes: Intra-Entity Asset Transfers of Assets other than Inventory. The new guidance removes the prohibition in ASC 740 against the immediate recognition of the current and deferred income tax effects of intra-entity transfers of assets other than inventory. The new guidance became effective for us in the first quarter of our fiscal 2019. The adoption of ASU 2016-16 did not have a material impact on our financial statements.

[0001628280-18-013240:notes:228]
Accounting Pronouncements Not Yet Effective

[0001628280-18-013240:notes:229]
In August 2018, the Securities and Exchange Commission (“SEC”) adopted amendments to certain disclosure requirements in Securities Act Release No. 33-10532, Disclosure Update and Simplification. The amendments will become effective on November 5, 2018. The SEC staff subsequently indicated that it would not object if a filer’s first presentation of changes in shareholders’ equity is included in its Form 10-Q for the quarter that begins after the final rule’s effective date. Among the amendments is the requirement to present the changes in shareholders’ equity in the interim financial statements (either in a separate statement or footnote) in quarterly reports on Form 10-Q. The analysis should present a reconciliation of the beginning balance to the ending balance of each period for which a consolidated statement of operations is required to be filed. We will include the first presentation of changes in stockholders’ equity on Form 10-Q in our third quarter of fiscal 2019.

[0001628280-18-013240:notes:230]
In August 2018, FASB issued ASU 2018-15, Intangibles-Goodwill and Other-Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract. ASU 2018-15 requires an entity in a hosting arrangement that is a service contract to follow the guidance in Subtopic 350-40 to determine which implementation costs to capitalize as an asset related to the service contract and which costs to expense. Implementation costs capitalized must be expensed over the term of the hosting arrangement, including the period covered by an option to extend the arrangement. The standard is effective for fiscal years beginning after December 15, 2019, and interim periods within those fiscal years, and should be applied either retrospectively or prospectively to all implementation costs incurred after the date of adoption. Early adoption is permitted, including adoption in any interim period, for all entities. ASU 2018-15 is effective for us in our first quarter of fiscal 2021. We are currently evaluating the impact of ASU 2018-15 on our consolidated financial statements.

[0001628280-18-013240:notes:231]
In August 2018, FASB issued ASU 2018-14, Compensation-Retirement Benefits-Defined Benefit Plans-General (Topic 715-20): Disclosure Framework-Changes to the Disclosure Requirements for Defined Benefit Plans. ASU 2018-14 modifies the disclosure requirements for defined benefit pension plans and other postretirement benefit plans. The new guidance is effective for fiscal years ending after December 15, 2020 and early adoption is permitted. ASU 2018-14 should be applied retrospectively to all periods presented and is effective for us in our first quarter of fiscal 2022. We are currently evaluating the impact of ASU 2018-14 on our consolidated financial statements.

[0001628280-18-013240:notes:232]
In August 2018, FASB issued ASU 2018-13, Fair Value Measurement (Topic 820): Disclosure Framework-Changes to the Disclosure Requirements for Fair Value Measurement. ASU 2018-13 modifies the disclosure requirements for fair value measurements. The new guidance is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. Entities are permitted to early adopt any removed or modified disclosures upon issuance of ASU 2018-13 and delay adoption of the additional disclosures until the effective date. The standard is effective for us in our first quarter of fiscal 2021. We are currently evaluating the impact of ASU 2018-13 on our consolidated financial statements and related disclosures.

[0001628280-18-013240:notes:233]
In February 2018, FASB issued ASU 2018-02, Income Statement-Reporting Comprehensive Income (Topic 220): Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income, which allows companies to reclassify stranded tax effects resulting from the Tax Act, from accumulated other comprehensive income to retained earnings. The guidance also requires certain new disclosures regardless of the election. The amendments in ASU 2018-02 are effective for all entities for fiscal years beginning after December 15, 2018, and interim periods within those fiscal years. Early adoption is permitted, including adoption in any interim period. ASU 2018-02 is effective for us in the first quarter of fiscal 2020. We are currently evaluating the impact of our pending adoption of ASU 2018-02 on our consolidated financial statements.

[0001628280-18-013240:notes:234]
In January 2017, FASB issued ASU 2017-04, Intangibles - Goodwill and Other (Topic 350): Simplifying the Accounting for Goodwill Impairment. ASU 2017-04 removes the requirement to perform a hypothetical purchase price allocation to measure goodwill impairment. A goodwill impairment charge will be the amount by which a reporting unit's carrying value exceeds its fair value, not to exceed the carrying amount of goodwill. The amendments contained in ASU 2017-04 are effective for interim and annual periods beginning after December 15, 2019, with early adoption permitted, which should be applied prospectively. We plan to adopt the accounting standard update in our first quarter of fiscal 2020. We are currently evaluating the impact of ASU 2017-04 on our consolidated financial statements.

[0001628280-18-013240:notes:235]
In February 2016, FASB issued ASU 2016-02, Leases. The new guidance generally requires an entity to recognize on its balance sheet operating and financing lease liabilities and corresponding right-of-use assets. The new guidance contained in ASU 2016-02 is effective for annual periods beginning after December 15, 2018, including interim periods within those periods, with early adoption permitted. The standard is effective for us in our first quarter of fiscal 2020 where we will be required to recognize and measure leases existing at, or entered into after, the beginning of the earliest comparative period presented using a modified retrospective approach, with an option to elect certain practical expedients. Based on our current lease portfolio, we estimate the value of leased assets and liabilities that may be recognized will be material. We are continuing to evaluate the impact of ASU 2016-02 which is subject to change.


## us-gaap:OtherCurrentLiabilitiesTableTextBlock

[0001628280-18-013240:notes:236]
The components of other current liabilities were as follows (in millions):

[0001628280-18-013240:notes:237]
|  | September 29, 2018 |  | June 30, 2018 |
| Warranty accrual (1) | $ | 6.6 |  |  | $ | 6.6 |  |
| Restructuring accrual and related charges (2) | 1.6 |  |  | 1.9 |  |
| Deferred revenue and customer deposits | 2.6 |  |  | 2.8 |  |
| Capital lease obligation (3) | 5.4 |  |  | 7.3 |  |
| Other current liabilities | 4.8 |  |  | 3.5 |  |
| Other current liabilities | $ | 21.0 |  |  | $ | 22.1 |  |

[0001628280-18-013240:notes:238]
(1) Refer to “Note 16. Commitments and Contingencies” in the Notes to Unaudited Condensed Consolidated Financial Statements.

[0001628280-18-013240:notes:239]
(2) Refer to “Note 13. Restructuring and Related Charges” in the Notes to Unaudited Condensed Consolidated Financial Statements.

[0001628280-18-013240:notes:240]
(3) As of September 29, 2018, an amount of $1.6 million related to a capital lease was recorded in accounts payable on the condensed consolidated balance sheet. Refer to “Note 16. Commitments and Contingencies” in the Notes to Unaudited Condensed Consolidated Financial Statements.


## us-gaap:OtherNoncurrentLiabilitiesTableTextBlock

[0001628280-18-013240:notes:241]
The components of other non-current liabilities were as follows (in millions):

[0001628280-18-013240:notes:242]
|  | September 29, 2018 |  | June 30, 2018 |
| Asset retirement obligation | $ | 2.7 |  |  | $ | 2.7 |  |
| Pension and related accrual | 3.7 |  |  | 3.5 |  |
| Deferred rent | 2.5 |  |  | 2.6 |  |
| Unrecognized tax benefit | 9.0 |  |  | 6.1 |  |
| Capital lease obligation (1) | — |  |  | 0.4 |  |
| Other non-current liabilities | 0.9 |  |  | 3.7 |  |
| Other non-current liabilities | $ | 18.8 |  |  | $ | 19.0 |  |


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001628280-18-013240:notes:243]
The components of property, plant and equipment, net were as follows (in millions):

[0001628280-18-013240:notes:244]
|  | September 29, 2018 |  | June 30, 2018 |
| Land | $ | 10.6 |  |  | $ | 10.6 |  |
| Buildings and improvement | 59.4 |  |  | 55.1 |  |
| Machinery and equipment (1) | 476.0 |  |  | 463.6 |  |
| Computer equipment and software | 26.5 |  |  | 26.3 |  |
| Furniture and fixtures | 2.9 |  |  | 2.2 |  |
| Leasehold improvements | 27.0 |  |  | 25.8 |  |
| Construction in progress | 59.9 |  |  | 52.6 |  |
|  | 662.3 |  |  | 636.2 |  |
| Less: Accumulated depreciation | (343.7 | ) |  | (329.3 | ) |
| Property, plant and equipment, net | $ | 318.6 |  |  | $ | 306.9 |  |

[0001628280-18-013240:notes:245]
(1) In fiscal 2018, we started leasing equipment from a vendor and have accounted for the transaction as a capital lease. Included in the table above is our capital lease asset of $15.6 million, gross and depreciation expense of $6.7 million as of September 29, 2018.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001628280-18-013240:notes:246]
[same as prior period, unchanged from 0001633978-18-000030:notes:218]

[0001628280-18-013240:notes:247]
We have initiated various strategic restructuring events primarily intended to reduce costs, consolidate our operations, rationalize the manufacturing of our products and align our business in response to the market conditions. The following table summarizes the activity of restructuring and related charges during the three months ended September 29, 2018 and September 30, 2017 (in millions):

[0001628280-18-013240:notes:248]
|  | Three Months Ended |
|  | September 29, 2018 |  | September 30, 2017 |
| Balance as of beginning of period | $ | 1.9 |  |  | $ | 3.8 |  |
| Charges | 1.3 |  |  | 2.9 |  |
| Payments | (1.6 | ) |  | (5.4 | ) |
| Balance as of end of period | $ | 1.6 |  |  | $ | 1.3 |  |

[0001628280-18-013240:notes:249]
During the three months ended September 29, 2018, we recorded $1.3 million in restructuring and related charges in the condensed consolidated statements of operations, primarily attributable to severance and employee related benefits. On September 5, 2018, we implemented an internal re-organization in order to extend our market leadership position by strengthening product quality, to develop new enabling technologies required to support a winning long-term portfolio roadmap, and to develop commercial proposals and new product introduction (“NPI”) priorities to maintain and grow our position while driving new customer and eco-system partner engagements.

[0001628280-18-013240:notes:250]
During the three months ended September 30, 2017, we recorded $2.9 million in restructuring and related charges in the condensed consolidated statements of operations, of which $(0.1) million was severance costs and $3.0 million related to cost to vacate facilities, lease termination costs, and temporary labor, payroll tax, and other related costs connected with employee benefits, materials used in set up and production activities.


## us-gaap:ScheduleOfEntityWideDisclosureOnGeographicAreasLongLivedAssetsInIndividualForeignCountriesByCountryTextBlock

[0001628280-18-013240:notes:251]
[same as prior period, unchanged from 0001633978-18-000030:notes:223]

[0001628280-18-013240:notes:252]
|  | As of |
|  | September 29, 2018 |  | June 30, 2018 |
| Property, Plant and Equipment, net |  |  |  |
| United States | $ | 103.6 |  |  | $ | 97.6 |  |
| China | 62.1 |  |  | 70.0 |  |
| Thailand | 131.3 |  |  | 107.4 |  |
| Other countries | 21.6 |  |  | 31.9 |  |
| Total long-lived assets | $ | 318.6 |  |  | $ | 306.9 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001628280-18-013240:notes:253]
[same as prior period, unchanged from 0001633978-18-000030:notes:225]

[0001628280-18-013240:notes:254]
|  | September 29, 2018 |  | June 30, 2018 |
| Finished goods | $ | 80.7 |  |  | $ | 98.2 |  |
| Work in process | 32.9 |  |  | 34.5 |  |
| Raw materials and purchased parts | 23.0 |  |  | 20.9 |  |
| Inventories | $ | 136.6 |  |  | $ | 153.6 |  |


## us-gaap:ScheduleOfOtherCurrentAssetsTableTextBlock

[0001628280-18-013240:notes:255]
[same as prior period, unchanged from 0001633978-18-000030:notes:227]

[0001628280-18-013240:notes:256]
|  | September 29, 2018 |  | June 30, 2018 |
| Capitalized manufacturing overhead | $ | 18.3 |  |  | $ | 20.5 |  |
| Prepayments | 22.3 |  |  | 19.5 |  |
| Advances to contract manufacturers | 13.7 |  |  | 14.0 |  |
| Other current assets | 16.3 |  |  | 11.0 |  |
| Prepayments and other current assets | $ | 70.6 |  |  | $ | 65.0 |  |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001628280-18-013240:notes:257]
The following table presents net revenue by the three geographic regions we operate in and net revenue from countries that represented 10% or more of our total net revenue (in millions, except percentage data):

[0001628280-18-013240:notes:258]
|  | Three Months Ended |
|  | September 29, 2018 |  | September 30, 2017 |
| Net revenue: |  |  |  |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |
| United States | $ | 21.9 |  |  | 6.2 | % |  | $ | 33.6 |  |  | 13.8 | % |
| Mexico | 56.3 |  |  | 15.9 |  |  | 24.8 |  |  | 10.3 |  |
| Other Americas | 0.9 |  |  | 0.3 |  |  | 2.2 |  |  | 0.9 |  |
| Total Americas | $ | 79.1 |  |  | 22.4 | % |  | $ | 60.6 |  |  | 25.0 | % |
| Asia-Pacific: |  |  |  |  |  |  |  |
| Hong Kong | $ | 65.5 |  |  | 18.5 | % |  | $ | 48.9 |  |  | 20.1 | % |
| Japan | 36.1 |  |  | 10.2 |  |  | 34.1 |  |  | 14.0 |  |
| South Korea | 70.0 |  |  | 19.8 |  |  | 10.9 |  |  | 4.5 |  |
| Other Asia-Pacific | 74.1 |  |  | 20.9 |  |  | 63.3 |  |  | 26.0 |  |
| Total Asia-Pacific | $ | 245.7 |  |  | 69.4 | % |  | $ | 157.2 |  |  | 64.6 | % |
| EMEA | $ | 29.3 |  |  | 8.2 | % |  | $ | 25.4 |  |  | 10.4 | % |
| Total net revenue | $ | 354.1 |  |  |  |  | $ | 243.2 |  |  |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001628280-18-013240:notes:259]
[same as prior period, unchanged from 0001633978-18-000030:notes:231]

[0001628280-18-013240:notes:260]
|  | Three Months Ended |
|  | September 29, 2018 |  | September 30, 2017 |
| Net revenue: |  |  |  |
| OpComms | $ | 310.1 |  |  | $ | 207.9 |  |
| Lasers | 44.0 |  |  | 35.3 |  |
| Net revenue | $ | 354.1 |  |  | $ | 243.2 |  |
| Gross profit: |  |  |  |
| OpComms | 124.9 |  |  | 72.1 |  |
| Lasers | 17.7 |  |  | 10.6 |  |
| Total segment gross profit | 142.6 |  |  | 82.7 |  |
| Unallocated corporate items: |  |  |  |
| Stock-based compensation | (3.3 | ) |  | (2.7 | ) |
| Amortization of intangibles | (0.8 | ) |  | (0.8 | ) |
| Other charges (1) | (12.5 | ) |  | (10.7 | ) |
| Gross profit | $ | 126.0 |  |  | $ | 68.5 |  |

[0001628280-18-013240:notes:261]
(1) “Other charges” of unallocated corporate items for the three months ended September 29, 2018 primarily include set-up costs of our facility in Thailand, including costs of transferring product lines to Thailand of $12.7 million. During the three months ended September 30, 2017, “other charges” of unallocated corporate items primarily consisted of set-up costs of our facility in Thailand of $3.1 million, as well as inventory write-downs due to canceled programs not allocated to the segments of $7.0 million.


## us-gaap:SchedulesOfConcentrationOfRiskByRiskFactorTextBlock

[0001628280-18-013240:notes:262]
During the three months ended September 29, 2018 and September 30, 2017, net inventory purchased from a single contract manufacturer which represented 10% or greater of total net purchases is summarized as follows:

[0001628280-18-013240:notes:263]
|  | Three Months Ended |
|  | September 29, 2018 |  | September 30, 2017 |
| Vendor A | 51.5 | % |  | 44.9 | % |
| Vendor B | 25.1 | % |  | 25.7 | % |
| Vendor C | * |  |  | 10.9 | % |
| *Represents less than 10% of total net purchases |  |  |  |

[0001628280-18-013240:notes:264]
The table below discloses our total net revenue attributable to each of our two reportable segments. In addition, it discloses the percentage of our total net revenue attributable to our product offerings which serve the Telecom, Datacom, and Consumer and Industrial markets which accounted for 10% or more of our total net revenue during the periods presented:

[0001628280-18-013240:notes:265]
|  | Three Months Ended |
|  | September 29, 2018 |  | September 30, 2017 |
| OpComms: | $ | 310.1 |  |  | $ | 207.9 |  |
| Telecom | 142.9 |  |  | 110.4 |  |
| Datacom | 34.2 |  |  | 45.2 |  |
| Consumer and Industrial | 133.0 |  |  | 52.3 |  |
| Lasers | $ | 44.0 |  |  | $ | 35.3 |  |

[0001628280-18-013240:notes:266]
During the three months ended September 29, 2018 and September 30, 2017, net revenue generated from a single customer which represented 10% or greater of total net revenue is summarized as follows:

[0001628280-18-013240:notes:267]
|  | Three Months Ended |
|  | September 29, 2018 |  | September 30, 2017 |
| Customer A | 30.5 | % |  | 16.3 | % |
| Customer B | 15.0 | % |  | * |  |
| Customer C | 13.0 | % |  | 14.2 | % |
| Customer D | * |  |  | 10.4 | % |
| *Represents less than 10% of total net revenue |  |  |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001628280-18-013240:notes:268]
[same as prior period, unchanged from 0001633978-18-000030:notes:240]

[0001628280-18-013240:notes:269]
Our chief executive officer is our Chief Operating Decision Maker (“CODM”). The CODM allocates resources to the segments based on their business prospects, competitive factors, net revenue and gross margin. We do not track all of our property, plant and equipment by operating segments. The geographic identification of these assets is set forth below.

[0001628280-18-013240:notes:270]
We are an industry leading provider of optical and photonic products defined by revenue and market share addressing a range of end-market applications including optical communications and commercial lasers. We have two operating segments, Optical Communications, which we refer to as OpComms, and Commercial Lasers, which we refer to as Lasers. Our OpComms products address the following markets: telecommunications (“Telecom”), data communications (“Datacom”), and consumer and industrial (“Consumer and Industrial”). The two operating segments were primarily determined based on how the CODM views and evaluates our operations. Operating results are regularly reviewed by the CODM to make decisions about resources to be allocated to the segments and to assess their performance. Other factors, including market separation and customer specific applications, go-to-market channels, products and manufacturing, are considered in determining the formation of these operating segments.

[0001628280-18-013240:notes:271]
[same as prior period, unchanged from 0001633978-18-000030:notes:243]

[0001628280-18-013240:notes:272]
We operate in three geographic regions: Americas, Asia-Pacific, and EMEA (Europe, Middle East, and Africa). Net revenue is assigned to the geographic region and country where our product is initially shipped. For example, certain customers may request shipment of our product to a contract manufacturer in one country, which may differ from the location of their end customers. The following table presents net revenue by the three geographic regions we operate in and net revenue from countries that represented 10% or more of our total net revenue (in millions, except percentage data):

[0001628280-18-013240:notes:273]
Our net revenue from Mexico increased due to increased demand for our ROADM products from one of our large customers who manufactures in Mexico, while net revenue from Hong Kong and South Korea grew due to our 3D sensing ramp for mobile devices.

[0001628280-18-013240:notes:274]
We purchase a substantial portion of our inventory from contract manufacturers and vendors located primarily in Taiwan, Thailand, and China. During the three months ended September 29, 2018 and September 30, 2017, net inventory purchased from a single contract manufacturer which represented 10% or greater of total net purchases is summarized as follows:


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001628280-18-013240:notes:275]
[same as prior period, unchanged from 0001633978-18-000030:notes:246]

[0001628280-18-013240:notes:276]
[same as prior period, unchanged from 0001633978-18-000030:notes:247]

[0001628280-18-013240:notes:277]
As of September 29, 2018 and June 30, 2018, our accounts receivable allowance balance was $2.1 million and $2.6 million, respectively.

[0001628280-18-013240:notes:278]
[same as prior period, unchanged from 0001633978-18-000030:notes:249]

[0001628280-18-013240:notes:279]
[same as prior period, unchanged from 0001633978-18-000030:notes:250]

[0001628280-18-013240:notes:280]
[same as prior period, unchanged from 0001633978-18-000030:notes:251]

[0001628280-18-013240:notes:281]
During the three months ended September 29, 2018 and September 30, 2017, we recorded depreciation expense of $19.7 million and $16.7 million, respectively.

[0001628280-18-013240:notes:282]
[same as prior period, unchanged from 0001633978-18-000030:notes:253]

[0001628280-18-013240:notes:283]
[same as prior period, unchanged from 0001633978-18-000030:notes:254]

[0001628280-18-013240:notes:284]
[same as prior period, unchanged from 0001633978-18-000030:notes:255]
