# LITE note change history — 0001633978-18-000030 → 0001628280-18-013240


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2018-11-01):
[0001628280-18-013240:note_history:1]
We lease certain real and personal property from unrelated third parties under non-cancellable operating leases that expire at various dates through fiscal 2026. Certain leases require us to pay property taxes, insurance and routine maintenance, and include escalation clauses. As of September 29, 2018, the future minimum annual lease payments under non-cancellable operating leases were as follows (in millions):
  (was, 2018-05-02, similarity 0.9826):
[0001633978-18-000030:note_history:1]
We lease certain real and personal property from unrelated third parties under non-cancellable operating leases that expire at various dates through fiscal 2026. Certain leases require us to pay property taxes, insurance and routine maintenance, and include escalation clauses. As of March 31, 2018, the future minimum annual lease payments under non-cancellable operating leases were as follows (in millions):

- added (2018-11-01):
[0001628280-18-013240:note_history:2]
During the three months ended September 29, 2018 and September 30, 2017, rental expense relating to building and equipment was $2.8 million and $3.4 million, respectively.

- changed (2018-11-01):
[0001628280-18-013240:note_history:3]
As of September 29, 2018, equipment acquired under a capital lease agreement was $15.6 million. Our capital lease asset is included in property, plant and equipment, net in our condensed consolidated balance sheets as of September 29, 2018. Amortization expense on this capital lease asset is recorded as depreciation expense and is included in cost of sales in our condensed consolidated statements of operations for the three months ended September 29, 2018. Our capital lease obligation is recorded at the lesser of the estimated fair market value of the leased property or the net present value of the aggregate future minimum lease payments and is included in other current liabilities and other non-current liabilities in our condensed consolidated balance sheets as of September 29, 2018. Refer to “Note 6. Balance Sheet Details” for capital lease obligation amounts in other current liabilities and other non-current liabilities. Interest on these obligations is included in interest expense in our condensed consolidated statements of operations.
  (was, 2018-05-02, similarity 0.7113):
[0001633978-18-000030:note_history:3]
As of March 31, 2018, equipment acquired under a capital lease agreement was $15.6 million. Our capital lease asset is included in property, plant and equipment, net in our condensed consolidated balance sheets as of March 31, 2018. Amortization expense on this capital lease asset is recorded as depreciation expense and is included in cost of sales in our condensed consolidated statements of operations for the three and nine months ended March 31, 2018. Our capital lease obligation is recorded at the lesser of the estimated fair market value of the leased property or the net present value of the aggregate future minimum lease payments and is included in other current liabilities and other non-current liabilities in our condensed consolidated balance sheets as of March 31, 2018. Refer to “Note 6. Balance Sheet Details” for capital lease obligation amounts in other current liabilities and other non-current liabilities. Interest on these obligations is included in interest expense in our condensed consolidated statements of operations.

- changed (2018-11-01):
[0001628280-18-013240:note_history:4]
As of September 29, 2018 the future minimum annual lease payments under our capital lease were as follows (in millions):
  (was, 2018-05-02, similarity 0.9558):
[0001633978-18-000030:note_history:4]
As of March 31, 2018 the future minimum annual lease payments under our capital lease were as follows (in millions):

- changed (2018-11-01):
[0001628280-18-013240:note_history:5]
| Fiscal Years |  |
| Remainder of 2019 | $ | 6.7 |  |
| 2020 | 0.4 |  |
| Total minimum capital lease payments | $ | 7.1 |  |
| Less: amount representing interest | $ | (0.1 | ) |
| Present value of capital lease obligation | $ | 7.0 |  |
  (was, 2018-05-02, similarity 0.9732):
[0001633978-18-000030:note_history:5]
| Fiscal Years |  |
| Remainder of 2018 | $ | 4.7 |  |
| 2019 | 7.5 |  |
| 2020 | 0.4 |  |
| Total minimum capital lease payments | $ | 12.6 |  |
| Less: amount representing interest | $ | (0.3 | ) |
| Present value of capital lease obligation | $ | 12.3 |  |

- added (2018-11-01):
[0001628280-18-013240:note_history:6]
At the time of acquisition in February 2017, we incurred liabilities in the amount of $3.6 million. The amount of up to $3.0 million is expected to be paid within the following 12 months contingent upon meeting certain production targets, and is included in other current liabilities on our consolidated balance sheet as of September 29, 2018. We retained $1.0 million of the purchase price as security for any potential liabilities of the seller under the representations, warranties and indemnifications included in the purchase agreement. The amount of $1.0 million was fully paid to the seller during the three months ended September 29, 2018.

- changed (2018-11-01):
[0001628280-18-013240:note_history:7]
The future interest and principal payments related to the 2024 Notes are as follows as of September 29, 2018:
  (was, 2018-05-02, similarity 0.9495):
[0001633978-18-000030:note_history:7]
The future interest and principal payments related to the 2024 Notes are as follows as of March 31, 2018:

- changed (2018-11-01):
[0001628280-18-013240:note_history:8]
| Fiscal Years |  |
| Remainder of 2019 | $ | 0.6 |  |
| 2020 | 1.1 |  |
| 2021 | 1.1 |  |
| 2022 | 1.1 |  |
| 2023 | 1.1 |  |
| Thereafter | 451.2 |  |
| Total 2024 Notes payments | $ | 456.2 |  |
  (was, 2018-05-02, similarity 0.911):
[0001633978-18-000030:note_history:8]
| Fiscal Years |  |
| 2019 | $ | 1.1 |  |
| 2020 | 1.1 |  |
| 2021 | 1.1 |  |
| 2022 | 1.1 |  |
| Thereafter | 451.7 |  |
| Total 2024 Notes payments | $ | 456.1 |  |

- changed (2018-11-01):
[0001628280-18-013240:note_history:9]
Purchase obligations of $206.5 million as of September 29, 2018, represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule and adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.
  (was, 2018-05-02, similarity 0.9877):
[0001633978-18-000030:note_history:9]
Purchase obligations of $187.1 million as of March 31, 2018, represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule and adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

- changed (2018-11-01):
[0001628280-18-013240:note_history:10]
The following table presents the changes in our warranty reserve during the three months ended September 29, 2018 and September 30, 2017 (in millions):
  (was, 2018-05-02, similarity 0.8975):
[0001633978-18-000030:note_history:10]
The following table presents the changes in our warranty reserve during the three and nine months ended March 31, 2018 and April 1, 2017 (in millions):

- added (2018-11-01):
[0001628280-18-013240:note_history:11]
|  | Three Months Ended |
|  | September 29, 2018 |  | September 30, 2017 |
| Balance as of beginning of period | $ | 6.6 |  |  | $ | 9.7 |  |
| Provision for warranty | 1.2 |  |  | 1.0 |  |
| Utilization of reserve | (1.2 | ) |  | (1.3 | ) |
| Balance as of end of period | $ | 6.6 |  |  | $ | 9.4 |  |

- changed (2018-11-01):
[0001628280-18-013240:note_history:12]
In the normal course of business, we enter into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown because claims may be made against us in the future and we may record charges in the future as a result of these indemnification obligations. As of September 29, 2018, we did not have any material indemnification claims that were probable or reasonably possible.
  (was, 2018-05-02, similarity 0.793):
[0001633978-18-000030:note_history:12]
In the normal course of business, we enter into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown because claims may be made against us in the future and we may record charges in the future as a result of these indemnification obligations. As of March 31, 2018, we did not have any material indemnification claims that were probable or reasonably possible.

- added (2018-11-01):
[0001628280-18-013240:note_history:13]
Audit Proceedings

- added (2018-11-01):
[0001628280-18-013240:note_history:14]
We are under audit by various domestic and foreign tax authorities with regards to income tax and indirect tax matters. In some, although not all cases, we have reserved for potential adjustments to our provision for income taxes and accrual of indirect taxes that may result from examinations by these tax authorities or final outcomes in judicial proceedings, and we believe that the final outcome of these examinations, agreements or judicial proceedings will not have a material effect on our results of operations. If events occur which indicate payment of these amounts is unnecessary, the reversal of the liabilities would result in the recognition of benefits in the period we determine the liabilities are no longer necessary. If our estimates of the federal, state, and foreign income tax liabilities and indirect tax liabilities are less than the ultimate assessment, it could result in a further charge to expense.

- removed (2018-11-01):
[0001633978-18-000030:note_history:15]
During the three and nine months ended March 31, 2018, rental expense relating to building and equipment was $2.8 million and $9.2 million, respectively. During the three and nine months ended April 1, 2017, rental expense relating to building and equipment was $2.6 million and $7.0 million, respectively.

- removed (2018-11-01):
[0001633978-18-000030:note_history:16]
We incurred liabilities in the amount of $3.6 million in connection with the fiscal 2017 acquisition. The amount of $2.7 million is payable 36 months following the acquisition date contingent upon meeting certain production targets. We retained $0.9 million of the purchase price as security for any potential liabilities of the seller under the representations, warranties and indemnifications included in the purchase agreement, which amount less any amounts required to cover seller’s indemnification obligations is payable to the seller at the 15 month anniversary of the close date.

- removed (2018-11-01):
[0001633978-18-000030:note_history:17]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, 2018 |  | April 1, 2017 |  | March 31, 2018 |  | April 1, 2017 |
| Balance as of beginning of period | $ | 9.9 |  |  | $ | 8.7 |  |  | $ | 9.7 |  |  | $ | 2.8 |  |
| Provision for warranty (1) | 2.0 |  |  | 0.6 |  |  | 4.9 |  |  | 9.3 |  |
| Utilization of reserve | (4.9 | ) |  | (1.2 | ) |  | (7.6 | ) |  | (4.0 | ) |
| Balance as of end of period | $ | 7.0 |  |  | $ | 8.1 |  |  | $ | 7.0 |  |  | $ | 8.1 |  |

- removed (2018-11-01):
[0001633978-18-000030:note_history:18]
(1) This does not include a settlement payment of $5.1 million received from a vendor for a quality issue during the three months ended March 31, 2018.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2018-11-01):
[0001628280-18-013240:note_history:19]
Lumentum (we, us, our or the Company) is an industry-leading provider of optical and photonic products defined by revenue and market share addressing a range of end market applications including OpComms and Lasers for manufacturing, inspection and life-science applications. We seek to use our core optical and photonic technology and our volume manufacturing capability to expand into attractive emerging markets that benefit from advantages that optical or photonics based solutions provide, including 3D sensing for consumer electronics and diode light sources for a variety of consumer and industrial applications. The majority of our customers tend to be OEMs that incorporate our products into their products which then address end-market applications. For example, we sell fiber optic components that Network Equipment Manufacturers (“NEMs”) customers assemble into communications networking systems, which they sell to network service providers or enterprises with their own networks. Similarly, many of our customers for our Lasers products incorporate our products into tools they produce, which are used for manufacturing processes by their customers. For 3D sensing, we sell diode lasers to manufacturers of consumer electronics products for mobile, personal computing, and gaming who then integrate our devices within their products, for eventual resale to consumers and also into other industrial applications.

- changed (2018-11-01):
[0001628280-18-013240:note_history:20]
The preparation of the condensed consolidated financial statements in accordance with U.S. generally accepted accounting principles (“GAAP”) requires management to make estimates and assumptions that affect the amounts reported in our condensed consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates. Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are inventory valuation, revenue recognition, income taxes, long-lived asset valuation, warranty, derivative liability, business combinations, and goodwill.
  (was, 2018-05-02, similarity 0.885):
[0001633978-18-000030:note_history:20]
The preparation of the condensed consolidated financial statements in accordance with U.S. generally accepted accounting principles (“GAAP”) requires management to make estimates and assumptions that affect the amounts reported in our condensed consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates. Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are revenue recognition, inventory valuation, derivative liability valuation, long-lived asset valuation, warranty and accounting for income taxes.

- added (2018-11-01):
[0001628280-18-013240:note_history:21]
On March 11, 2018, we entered into an Agreement and Plan of Merger (the “Merger Agreement”) with Oclaro, Prota Merger Sub, Inc., and Prota Merger, LLC, pursuant to which we will acquire Oclaro and Oclaro will become a wholly-owned subsidiary of Lumentum. In accordance with the terms of the Merger Agreement, each issued and outstanding share of Oclaro common stock will be exchanged for $5.60 in cash and 0.0636 of a share of Lumentum common stock, subject to the conditions and restrictions set forth in the Merger Agreement. The total transaction consideration was approximately $1.8 billion as of the date of the Merger Agreement. Oclaro stockholders are expected to own approximately 16% of the combined company following the closing. Oclaro’s stockholders approved the Merger Agreement on July 10, 2018 and we have received approval for the transaction under the Hart-Scott Rodino Act in the United States. We are in the process of obtaining antitrust approval in China. The Merger Agreement contains certain termination rights for both Lumentum and Oclaro. The Merger Agreement further provides that upon termination of the Merger Agreement under specified circumstances relating to failure to obtain regulatory approvals by March 11, 2019, Lumentum may be required to pay Oclaro a termination fee of $80 million.

- added (2018-11-01):
[0001628280-18-013240:note_history:22]
In connection with the Merger Agreement, Lumentum entered into a commitment letter, dated as of March 11, 2018, with Deutsche Bank Securities Inc. and Deutsche Bank AG New York Branch (“Deutsche Bank”), pursuant to which, subject to the terms and conditions set forth therein, Deutsche Bank has committed to provide a senior secured term loan facility in an aggregate principal amount of up to $550 million.

- added (2018-11-01):
[0001628280-18-013240:note_history:23]
As of October 26, 2018, the total transaction consideration was expected to be approximately $1.6 billion, which would be funded by a combination of $600 million in Lumentum common stock, $500 million in new debt, and the remaining amount from the cash balances of the combined company.

- added (2018-11-01):
[0001628280-18-013240:note_history:24]
Our commitment letter and related documentation with Deutsche Bank requires payment of a ticking fee to Deutsche Bank. The ticking fee accrues at a rate of (a) commencing on the 31st day following the date on which the term loans were allocated to members of the lending syndicate (the “Allocation Date”), 1.25% per annum, and (b) commencing on the 61st day following the Allocation Date, 2.5% per annum, in each case, based on an aggregate principal amount of term loan commitments provided by Deutsche Bank under the commitment letter.  The Allocation Date occurred on August 8, 2018 and, as of September 29, 2018, we had not borrowed any funds under the senior secured term loan facility. Accordingly, we began to incur ticking fees on the $500 million of term loan commitments on September 8, 2018. We expensed $0.4 million related to the ticking fee, which is included in interest expense in our condensed consolidated statements of operations for the three months ended September 29, 2018.

- added (2018-11-01):
[0001628280-18-013240:note_history:25]
During the three months ended September 29, 2018, we also incurred $0.9 million of debt issuance costs in connection with the above facility which were capitalized and recorded in other non-current assets on our condensed consolidated balance sheet. These costs will be recorded as contra liability when the debt is drawn and will be amortized to interest expense using the effective interest rate method from the issuance date through the end of the term of the loan.

- added (2018-11-01):
[0001628280-18-013240:note_history:26]
The transaction is subject to customary closing conditions, including antitrust regulatory approval in China. The transaction is not subject to any financing condition. Although we anticipate that the transaction will be be completed by December 11, 2018, the termination date of the merger agreement will be automatically extended to March 11, 2019, subject to certain conditions set forth in the Merger Agreement.

- changed (2018-11-01):
[0001628280-18-013240:note_history:27]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Our fiscal 2019 is a 52-week year ending on June 29, 2019. Our fiscal 2018 was a 52-week year and ended on June 30, 2018.
  (was, 2018-05-02, similarity 0.9888):
[0001633978-18-000030:note_history:27]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Our fiscal 2018 is a 52-week year ending on June 30, 2018. Our fiscal 2017 was a 52-week year and ended on July 1, 2017.

- added (2018-11-01):
[0001628280-18-013240:note_history:28]
Certain prior period amounts have been reclassified to conform to the current year presentation on the notes to condensed consolidated financial statements. The reclassification of the prior period amounts did not impact previously reported condensed consolidated financial statements.

- changed (2018-11-01):
[0001628280-18-013240:note_history:29]
The accompanying interim unaudited condensed consolidated financial statements and accompanying related notes should be read in conjunction with the audited consolidated financial statements and related notes included in our Annual Report on Form 10-K for the fiscal year ended June 30, 2018.
  (was, 2018-05-02, similarity 0.993):
[0001633978-18-000030:note_history:29]
The accompanying interim unaudited condensed consolidated financial statements and accompanying related notes should be read in conjunction with the audited consolidated financial statements and related notes included in our Annual Report on Form 10-K for the fiscal year ended July 1, 2017.

- added (2018-11-01):
[0001628280-18-013240:note_history:30]
Except for the accounting policies for revenue recognition and adoption of Accounting Standard Update (“ASU”) 2014-09, Revenue from Contracts with Customers (Topic 606), there have been no significant changes to our significant accounting policies as of and for the three months ended September 29, 2018, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the year ended June 30, 2018.

- added (2018-11-01):
[0001628280-18-013240:note_history:31]
Adoption of Topic 606

- added (2018-11-01):
[0001628280-18-013240:note_history:32]
Revenue Recognition Policy

- added (2018-11-01):
[0001628280-18-013240:note_history:33]
Pursuant to Topic 606, our revenues are recognized upon the application of the following steps:

- added (2018-11-01):
[0001628280-18-013240:note_history:34]
| • | identification of the contract, or contracts, with a customer; |

- added (2018-11-01):
[0001628280-18-013240:note_history:35]
| • | identification of the performance obligations in the contract; |

- added (2018-11-01):
[0001628280-18-013240:note_history:36]
| • | determination of the transaction price; |

- added (2018-11-01):
[0001628280-18-013240:note_history:37]
| • | allocation of the transaction price to the performance obligations in the contract; and |

- added (2018-11-01):
[0001628280-18-013240:note_history:38]
| • | recognition of revenues when, or as, the contractual performance obligations are satisfied |

- added (2018-11-01):
[0001628280-18-013240:note_history:39]
The majority of our revenue comes from product sales, consisting of sales of Lasers and OpComms hardware products to our customers. Our revenue contracts generally include only one performance obligation. Revenues are recognized at a point in time when control of the promised goods or services is transferred to our customers upon shipment or delivery, in an amount that reflects the consideration we expect to be entitled to in exchange for those goods or services. We have entered into vendor managed inventory (“VMI”) programs with our customers. Under these arrangements, we receive purchase orders from our customers, and the inventory is shipped to the VMI location upon receipt of the purchase order. The customer then pulls the inventory from the VMI hub based on its production needs. Revenue under VMI programs is recognized when control transfers to the customer, which is generally upon pull of inventory by the customer from the hub.

- added (2018-11-01):
[0001628280-18-013240:note_history:40]
Revenue from all sales types is recognized at transaction price. The transaction price is determined based on the consideration to which we will be entitled in exchange for transferring goods or services to the customer adjusted for estimated variable consideration, if any. We typically estimate the transaction price impact of discounts offered to the customers for early payments on receivables or net of accruals for estimated sales returns. These estimates are based on historical returns, analysis of credit memo data and other known factors. Actual returns could differ from these estimates. We allocate the transaction price to each distinct product based on its relative standalone selling price. The product price as specified on the purchase order is considered the standalone selling price as it is an observable input that depicts the price as if sold to a similar customer in similar circumstances.

- added (2018-11-01):
[0001628280-18-013240:note_history:41]
Taxes assessed by a governmental authority that are both imposed on and concurrent with a specific revenue-producing transaction, that are collected by us from a customer and deposited with the relevant government authority, are excluded from revenue. Our revenue arrangements do not contain significant financing components as our standard payment terms are less than one year.

- added (2018-11-01):
[0001628280-18-013240:note_history:42]
If a customer pays consideration, or Lumentum has a right to an amount of consideration that is unconditional before we transfer a good or service to the customer, those amounts are classified as deferred income/advances received from customers which are included in other current liabilities or other long-term liabilities when the payment is made or it is due, whichever is earlier.

- added (2018-11-01):
[0001628280-18-013240:note_history:43]
Transaction Price Allocated to the Remaining Performance Obligations

- added (2018-11-01):
[0001628280-18-013240:note_history:44]
Remaining performance obligations represent the transaction price allocated to performances obligations that are unsatisfied or partially unsatisfied as of the end of the reporting period. Unsatisfied and partially unsatisfied performance obligations consist of contract liabilities and non-cancellable backlog. Non-cancellable backlog includes goods and services for which customer purchase orders have been accepted that are scheduled or in the process of being scheduled for shipment.

- added (2018-11-01):
[0001628280-18-013240:note_history:45]
The following table includes estimated revenue expected to be recognized in the future for backlog related performance obligations that are unsatisfied (or partially unsatisfied) as of September 29, 2018:

- added (2018-11-01):
[0001628280-18-013240:note_history:46]
|  | Less than 1 year | 1-2 years | Greater than 2 years | Total |
| Performance Obligations | $384.8 | $22.7 | $0.4 | $407.9 |

- added (2018-11-01):
[0001628280-18-013240:note_history:47]
Warranty

- added (2018-11-01):
[0001628280-18-013240:note_history:48]
Hardware products regularly include warranties to the end customers such that the product continues to function according to published specifications. We typically offer a twelve month warranty for most of our products. However, in some instances depending upon the product, specific market, product line and geography we deal in, and what is common in the industry, our warranties can vary and range from six months to five years. These standard warranties are assurance type warranties and do not offer any services in addition to the assurance that the product will continue working as specified. Therefore, warranties are not considered separate performance obligations in the arrangement. Instead, the expected cost of warranty is accrued as expense in accordance with authoritative guidance.

- added (2018-11-01):
[0001628280-18-013240:note_history:49]
We provide reserves for the estimated costs of product warranties at the time revenue is recognized. We estimate the costs of our warranty obligations based on our historical experience of known product failure rates, use of materials to repair or replace defective products and service delivery costs incurred in correcting product failures. In addition, from time to time, specific warranty accruals may be made if unforeseen technical problems arise.

- added (2018-11-01):
[0001628280-18-013240:note_history:50]
Shipping and Handling Costs

- added (2018-11-01):
[0001628280-18-013240:note_history:51]
We record shipping and handling costs related to revenue transactions within cost of sales as a period cost.

- added (2018-11-01):
[0001628280-18-013240:note_history:52]
Contract Costs

- added (2018-11-01):
[0001628280-18-013240:note_history:53]
The Company recognizes the incremental direct costs of obtaining a contract, which consist of sales commissions, when control over the products they relate to transfers to the customer. Applying the practical expedient, the Company recognizes commissions as expense when incurred, as the amortization period of the commission asset the Company would have otherwise recognized is less than one year.

- added (2018-11-01):
[0001628280-18-013240:note_history:54]
Contract Balances

- added (2018-11-01):
[0001628280-18-013240:note_history:55]
The Company records accounts receivable when it has an unconditional right to consideration. Contract liabilities are recorded when cash payments are received or due in advance of performance. Contract liabilities consist of advance payments and deferred revenue, where the Company has unsatisfied performance obligations. Contract liabilities are classified as deferred revenue and customer deposits and included in other current liabilities of our condensed consolidated balance sheet. Payment terms vary by customer. The time between invoicing and when payment is due is not significant.

- added (2018-11-01):
[0001628280-18-013240:note_history:56]
The following table reflects the changes in contract balances for the three months ended September 30, 2018:

- added (2018-11-01):
[0001628280-18-013240:note_history:57]
| Contract balances | Balance sheet location | September 29, 2018 |  | June 30, 2018 |  | Change |  | Percentage Change |
| Accounts receivable, net | Accounts receivable, net | $239.6 |  | $197.1 |  | $42.5 |  | 21.6% |
| Deferred revenue and customer deposits | Other current liabilities | $2.6 |  | $2.8 |  | $(0.2) |  | (7.1)% |

- added (2018-11-01):
[0001628280-18-013240:note_history:58]
During the three months ended September 29, 2018, deferred revenue and customer deposits decreased primarily due to revenue recognized for the satisfaction of performance obligation over time in the amount of $0.4 million.

- added (2018-11-01):
[0001628280-18-013240:note_history:59]
Disaggregation of Revenue

- added (2018-11-01):
[0001628280-18-013240:note_history:60]
We disaggregate revenue by geography and by product, no other level of disaggregation is required considering the type of products, customer, markets, contracts, duration of contracts, timing of transfer of control and sales channels, based on the information that our chief operating decision maker uses to manage the business.

- removed (2018-11-01):
[0001633978-18-000030:note_history:61]
Lumentum (we, us, our or the Company) is an industry-leading provider of optical and photonic products defined by revenue and market share addressing a range of end market applications including Optical Communications (“OpComms”) and Commercial Lasers (“Lasers”) for manufacturing, inspection and life-science applications. We seek to use our core optical and photonic technology and our volume manufacturing capability to expand into attractive emerging markets that benefit from advantages that optical or photonics-based solutions provide, including 3D sensing for consumer electronics and diode light sources for a variety of consumer and industrial applications. The majority of our customers tend to be original equipment manufacturers (“OEMs”) that incorporate our products into their products which then address end-market applications. For example, we sell fiber optic components that our network equipment manufacturer (“NEM”) customers assemble into communications networking systems, which they sell to network service providers or enterprises with their own networks. Similarly, many of our customers for our Lasers products incorporate our products into tools they produce, which are used for manufacturing processes by their customers. For 3D sensing, we sell diode lasers to manufacturers of consumer electronics products for mobile, personal computing, gaming, and other applications, who then integrate our devices within their products, for eventual resale to consumers.

- removed (2018-11-01):
[0001633978-18-000030:note_history:62]
On March 11, 2018, Lumentum and Oclaro, Inc. ("Oclaro") entered into a Merger Agreement (the “Merger Agreement”), unanimously approved by the boards of directors of both companies, under which Lumentum will acquire all outstanding shares of Oclaro common stock. Each share of Oclaro common stock will be exchanged for $5.60 in cash and 0.0636 shares of Lumentum common stock, subject to the terms of the Merger Agreement. The total transaction consideration was approximately $1.8 billion as of the date of the Merger Agreement. Oclaro stockholders will own approximately 16% of the combined company at closing. The Merger Agreement contains certain termination rights for both Lumentum and Oclaro. The Merger Agreement further provides that upon termination of the Merger Agreement under specified circumstances relating to failure to obtain regulatory approvals, Lumentum may be required to pay Oclaro a termination fee of $80 million.

- removed (2018-11-01):
[0001633978-18-000030:note_history:63]
The total transaction consideration will be funded by a combination of cash from the combined company of approximately $416 million, $550 million in new debt, and $859 million in Lumentum common stock.

- removed (2018-11-01):
[0001633978-18-000030:note_history:64]
Lumentum entered into a commitment letter with Deutsche Bank Securities Inc. and Deutsche Bank AG New York, New York Branch (“Deutsche Bank”), pursuant to which, subject to the terms and conditions set forth therein, Deutsche Bank has committed to provide a senior secured term loan facility in an aggregate principal amount of $550 million, with a provision for additional senior secured term loans in an aggregate principal amount not to exceed $250 million.

- removed (2018-11-01):
[0001633978-18-000030:note_history:65]
The transaction is subject to customary closing conditions, including the approval of Oclaro stockholders and antitrust regulatory approval in the United States and China. Under the Hart-Scott-Rodino Antitrust Improvements Act of 1976, as amended (the “HSR Act”), Lumentum and Oclaro are required to make pre-merger notification filings and to await the expiration or early termination of the statutory waiting period prior to completing the Merger.  Lumentum and Oclaro submitted pre-merger notification filings under the HSR Act on March 23, 2018 and received early termination of the waiting period on April 4, 2018. The transaction is not subject to any financing condition. The transaction is expected to be completed in the second half of calendar 2018.

- removed (2018-11-01):
[0001633978-18-000030:note_history:66]
Effective July 2, 2017, we adopted Accounting Standards Update (“ASU”) 2016-09, Stock Compensation ASU 718 - Improvements to Employee Share-Based Payment Accounting. As a result of the adoption, in the first quarter of fiscal year 2018, we recorded on a modified retrospective basis a $2.6 million cumulative-effect adjustment to retained earnings for the recognition of excess tax benefits generated by the settlement of share-based awards in prior periods. We elected to account for forfeitures of equity awards when they occur. The change was applied on a modified retrospective basis with a cumulative-effect adjustment of approximately $0.2 million to retained earnings in the fiscal first quarter of 2018.

- removed (2018-11-01):
[0001633978-18-000030:note_history:67]
All excess tax benefits and deficiencies are recognized in the income tax provision in the condensed consolidated statements of operations prospectively, rather than in additional paid-in-capital in the condensed consolidated balance sheets. In addition, the standard eliminates the requirement to defer recognition of excess tax benefits until they are realized through a reduction to income taxes payable. We present excess tax benefits as an operating activity in the condensed consolidated statements of cash flows on a prospective basis.


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-11-01):
[0001628280-18-013240:note_history:68]
The 2024 Notes consisted of the following components as of the periods presented (in millions):
  (was, 2018-05-02, similarity 0.6584):
[0001633978-18-000030:note_history:68]
As of March 31, 2018, the 2024 Notes consisted of the following (in millions):

- added (2018-11-01):
[0001628280-18-013240:note_history:69]
| Liability component: | September 29, 2018 |  | June 30, 2018 |
| Principal | $ | 450.0 |  |  | $ | 450.0 |  |
| Unamortized debt discount | (111.5 | ) |  | (115.8 | ) |
| Net carrying amount of the liability component | $ | 338.5 |  |  | $ | 334.2 |  |

- removed (2018-11-01):
[0001633978-18-000030:note_history:70]
| Liability component: | March 31, 2018 |  | July 1, 2017 |
| Principal | $ | 450.0 |  |  | $ | 450.0 |  |
| Unamortized debt discount | (120.1 | ) |  | (132.5 | ) |
| Net carrying amount of the liability component | $ | 329.9 |  |  | $ | 317.5 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-11-01):
[0001628280-18-013240:note_history:71]
The initial conversion rate of the 2024 Notes is 16.4965 shares of common stock per $1,000 principal amount of 2024 Notes, which is equivalent to an initial conversion price of approximately $60.62 per share, a 132.5% premium to the fair market value at the date of issuance. Prior to the close of business on the business day immediately preceding December 15, 2023, the 2024 Notes will be convertible only under the following circumstances: (1) during any fiscal quarter (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during the period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price, or $78.80 on each applicable trading day; (2) during the five consecutive business day period after any five consecutive trading day period (the “measurement period”) in which the trading price per $1,000 principal amount of notes for each trading day of such measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate on each such trading day; or (3) upon the occurrence of specified corporate events. On or after December 15, 2023 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their notes at any time. In addition, upon the occurrence of a make-whole fundamental change, we will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert 2024 Notes in connection with such make-whole fundamental change.
  (was, 2018-05-02, similarity 0.9979):
[0001633978-18-000030:note_history:71]
The initial conversion rate of the 2024 Notes is 16.4965 shares of common stock per $1,000 principal amount of 2024 Notes, which is equivalent to an initial conversion price of approximately $60.62 per share, a 132.5% premium to the fair market value at the date of issuance. Prior to the close of business on the business day immediately preceding December 15, 2023, the 2024 Notes will be convertible only under the following circumstances: (1) during any fiscal quarter (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during the period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price on each applicable trading day; (2) during the five consecutive business day period after any five consecutive trading day period (the “measurement period”) in which the trading price per $1,000 principal amount of notes for each trading day of such measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate on each such trading day; or (3) upon the occurrence of specified corporate events. On or after December 15, 2023 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their notes at any time. In addition, upon the occurrence of a make-whole fundamental change, we will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert 2024 Notes in connection with such make-whole fundamental change.

- changed (2018-11-01):
[0001628280-18-013240:note_history:72]
Prior to the Tax Matters Agreement settlement condition (“TMA settlement condition”), because we could only settle the 2024 Notes in cash, we determined that the conversion feature met the definition of a derivative liability. We separated the derivative liability from the host debt instrument based on the fair value of the derivative liability. As of the issuance date, March 8, 2017, the derivative liability fair value of $129.9 million was calculated using the binomial valuation approach. The residual principal amount of the 2024 Notes of $320.1 million before issuance costs was allocated to the debt component. We incurred approximately $7.7 million in transaction costs in connection with the issuance of the 2024 Notes. These costs were allocated to the debt component and recognized as a debt discount. We amortize the debt discount, including both the initial value of the derivative liability and the transaction costs, over the term of the 2024 Notes using the effective interest method. The effective interest rate of the 2024 Notes is 5.4% per year. As of September 29, 2018, the remaining debt discount amortization period was 65 months.
  (was, 2018-05-02, similarity 0.9525):
[0001633978-18-000030:note_history:72]
Prior to the Tax Matters Agreement settlement condition (“TMA settlement condition”), because we could only settle the 2024 Notes in cash, we determined that the conversion feature met the definition of a derivative liability. We separated the derivative liability from the host debt instrument based on the fair value of the derivative liability. As of the issuance date, March 8, 2017, the derivative liability fair value of $129.9 million was calculated using the binomial valuation approach. The residual principal amount of the 2024 Notes of $320.1 million before issuance costs was allocated to the debt component. We incurred approximately $7.7 million in transaction costs in connection with the issuance of the 2024 Notes. These costs were allocated to the debt component and recognized as a debt discount. We amortize the debt discount, including both the initial value of the derivative liability and the transaction costs, over the term of the 2024 Notes using the effective interest method. The effective interest rate of the 2024 Notes is 5.4% per year. As of March 31, 2018, the remaining debt discount amortization period was 71 months.

- changed (2018-11-01):
[0001628280-18-013240:note_history:73]
During the year ended July 1, 2017, we satisfied the TMA settlement condition. As such, the value of the conversion option will no longer be marked to market and was reclassified to additional paid-in capital within stockholders’ equity on our condensed consolidated balance sheet. The value of the conversion option at the time of issuance will be treated as an original issue discount for purposes of accounting for the debt component of the notes. The debt component will accrete up to the principal amount over the expected term of the debt. These accounting standards do not affect the actual amount we are required to repay, and the amount shown in the table below for the notes is the aggregate principal amount of the notes and does not reflect the debt discount we will be required to recognize.
  (was, 2018-05-02, similarity 0.9994):
[0001633978-18-000030:note_history:73]
During the year ended July 1, 2017, we satisfied the TMA settlement conditions. As such, the value of the conversion option will no longer be marked to market and was reclassified to additional paid-in capital within stockholders’ equity on our condensed consolidated balance sheet. The value of the conversion option at the time of issuance will be treated as an original issue discount for purposes of accounting for the debt component of the notes. The debt component will accrete up to the principal amount over the expected term of the debt. These accounting standards do not affect the actual amount we are required to repay, and the amount shown in the table below for the notes is the aggregate principal amount of the notes and does not reflect the debt discount we will be required to recognize.

- changed (2018-11-01):
[0001628280-18-013240:note_history:74]
The 2024 Notes consisted of the following components as of the periods presented (in millions):
  (was, 2018-05-02, similarity 0.6584):
[0001633978-18-000030:note_history:74]
As of March 31, 2018, the 2024 Notes consisted of the following (in millions):

- added (2018-11-01):
[0001628280-18-013240:note_history:75]
| Liability component: | September 29, 2018 |  | June 30, 2018 |
| Principal | $ | 450.0 |  |  | $ | 450.0 |  |
| Unamortized debt discount | (111.5 | ) |  | (115.8 | ) |
| Net carrying amount of the liability component | $ | 338.5 |  |  | $ | 334.2 |  |

- changed (2018-11-01):
[0001628280-18-013240:note_history:76]
The following table sets forth interest expense information related to the 2024 Notes for the periods presented (in millions, except percentages):
  (was, 2018-05-02, similarity 0.7721):
[0001633978-18-000030:note_history:76]
The following table sets forth interest expense information related to the 2024 Notes for the three and nine months ended March 31, 2018:

- changed (2018-11-01):
[0001628280-18-013240:note_history:77]
|  | Three Months Ended |
| (in millions, except percentages) | September 29, 2018 |  | September 30, 2017 |
| Contractual interest expense | $ | 0.3 |  |  | $ | 0.3 |  |
| Amortization of the debt discount | 4.3 |  |  | 4.1 |  |
| Total interest expense | $ | 4.6 |  |  | $ | 4.4 |  |
| Effective interest rate on the liability component | 5.4 | % |  | 5.4 | % |
  (was, 2018-05-02, similarity 0.8492):
[0001633978-18-000030:note_history:77]
|  | March 31, 2018 |
| (in millions, except percentages) | Three Months Ended |  | Nine Months Ended |
| Contractual interest expense | $ | 0.3 |  |  | $ | 0.9 |  |
| Amortization of the debt discount | 4.2 |  |  | 12.4 |  |
| Total interest expense | $ | 4.5 |  |  | $ | 13.3 |  |
| Effective interest rate on the liability component | 5.4 | % |  | 5.4 | % |

- removed (2018-11-01):
[0001633978-18-000030:note_history:78]
| Liability component: | March 31, 2018 |  | July 1, 2017 |
| Principal | $ | 450.0 |  |  | $ | 450.0 |  |
| Unamortized debt discount | (120.1 | ) |  | (132.5 | ) |
| Net carrying amount of the liability component | $ | 329.9 |  |  | $ | 317.5 |  |


## us-gaap:DebtSecuritiesAvailableForSaleUnrealizedLossPositionFairValueTableTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2018-11-01):
[0001628280-18-013240:note_history:79]
The following table summarizes unrealized losses on our cash equivalents and short-term investments by category and length of time the investment has been in a continuous unrealized loss position as of the periods presented (in millions):

- added (2018-11-01):
[0001628280-18-013240:note_history:80]
|  | Less than 12 months |  | 12 Months or Greater |  | Total |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| September 29, 2018: |  |  |  |  |  |  |  |  |  |  |  |
| Commercial paper | $ | 6.1 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 6.1 |  |  | $ | — |  |
| Asset-backed securities | 48.4 |  |  | (0.2 | ) |  | 8.5 |  |  | — |  |  | 56.9 |  |  | (0.2 | ) |
| Corporate debt securities | 113.3 |  |  | (0.8 | ) |  | 46.9 |  |  | (0.3 | ) |  | 160.2 |  |  | (1.1 | ) |
| Mortgage-backed securities | 2.8 |  |  | — |  |  | — |  |  | — |  |  | 2.8 |  |  | — |  |
| Foreign government bonds | 4.1 |  |  | — |  |  | — |  |  | — |  |  | 4.1 |  |  | — |  |
| Total | $ | 174.7 |  |  | $ | (1.0 | ) |  | $ | 55.4 |  |  | $ | (0.3 | ) |  | $ | 230.1 |  |  | $ | (1.3 | ) |
| June 30, 2018: |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 5.4 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 5.4 |  |  | $ | — |  |
| Commercial paper | 8.5 |  |  | — |  |  | — |  |  | — |  |  | 8.5 |  |  | — |  |
| Asset-backed securities | 66.6 |  |  | (0.2 | ) |  | 0.3 |  |  | — |  |  | 66.9 |  |  | (0.2 | ) |
| Corporate debt securities | 188.6 |  |  | (1.5 | ) |  | 2.0 |  |  | — |  |  | 190.6 |  |  | (1.5 | ) |
| Municipal bonds | 0.6 |  |  | — |  |  | — |  |  | — |  |  | 0.6 |  |  | — |  |
| U.S. Agency securities | 4.0 |  |  | — |  |  | — |  |  | — |  |  | 4.0 |  |  | — |  |
| Foreign government bonds | 3.4 |  |  | — |  |  | — |  |  | — |  |  | 3.4 |  |  | — |  |
| Total | $ | 277.1 |  |  | $ | (1.7 | ) |  | $ | 2.3 |  |  | $ | — |  |  | $ | 279.4 |  |  | $ | (1.7 | ) |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-11-01):
[0001628280-18-013240:note_history:81]
The future interest and principal payments related to the 2024 Notes are as follows as of September 29, 2018:
  (was, 2018-05-02, similarity 0.9495):
[0001633978-18-000030:note_history:81]
The future interest and principal payments related to the 2024 Notes are as follows as of March 31, 2018:

- changed (2018-11-01):
[0001628280-18-013240:note_history:82]
| Fiscal Years |  |
| Remainder of 2019 | $ | 0.6 |  |
| 2020 | 1.1 |  |
| 2021 | 1.1 |  |
| 2022 | 1.1 |  |
| 2023 | 1.1 |  |
| Thereafter | 451.2 |  |
| Total 2024 Notes payments | $ | 456.2 |  |
  (was, 2018-05-02, similarity 0.911):
[0001633978-18-000030:note_history:82]
| Fiscal Years |  |
| 2019 | $ | 1.1 |  |
| 2020 | 1.1 |  |
| 2021 | 1.1 |  |
| 2022 | 1.1 |  |
| Thereafter | 451.7 |  |
| Total 2024 Notes payments | $ | 456.1 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2018-11-01):
[0001628280-18-013240:note_history:83]
Shipping and Handling Costs

- added (2018-11-01):
[0001628280-18-013240:note_history:84]
We record shipping and handling costs related to revenue transactions within cost of sales as a period cost.

- added (2018-11-01):
[0001628280-18-013240:note_history:85]
Contract Costs

- added (2018-11-01):
[0001628280-18-013240:note_history:86]
The Company recognizes the incremental direct costs of obtaining a contract, which consist of sales commissions, when control over the products they relate to transfers to the customer. Applying the practical expedient, the Company recognizes commissions as expense when incurred, as the amortization period of the commission asset the Company would have otherwise recognized is less than one year.

- added (2018-11-01):
[0001628280-18-013240:note_history:87]
Contract Balances

- added (2018-11-01):
[0001628280-18-013240:note_history:88]
The Company records accounts receivable when it has an unconditional right to consideration. Contract liabilities are recorded when cash payments are received or due in advance of performance. Contract liabilities consist of advance payments and deferred revenue, where the Company has unsatisfied performance obligations. Contract liabilities are classified as deferred revenue and customer deposits and included in other current liabilities of our condensed consolidated balance sheet. Payment terms vary by customer. The time between invoicing and when payment is due is not significant.

- added (2018-11-01):
[0001628280-18-013240:note_history:89]
Revenue Recognition Policy

- added (2018-11-01):
[0001628280-18-013240:note_history:90]
Pursuant to Topic 606, our revenues are recognized upon the application of the following steps:

- added (2018-11-01):
[0001628280-18-013240:note_history:91]
| • | identification of the contract, or contracts, with a customer; |

- added (2018-11-01):
[0001628280-18-013240:note_history:92]
| • | identification of the performance obligations in the contract; |

- added (2018-11-01):
[0001628280-18-013240:note_history:93]
| • | determination of the transaction price; |

- added (2018-11-01):
[0001628280-18-013240:note_history:94]
| • | allocation of the transaction price to the performance obligations in the contract; and |

- added (2018-11-01):
[0001628280-18-013240:note_history:95]
| • | recognition of revenues when, or as, the contractual performance obligations are satisfied |

- added (2018-11-01):
[0001628280-18-013240:note_history:96]
The majority of our revenue comes from product sales, consisting of sales of Lasers and OpComms hardware products to our customers. Our revenue contracts generally include only one performance obligation. Revenues are recognized at a point in time when control of the promised goods or services is transferred to our customers upon shipment or delivery, in an amount that reflects the consideration we expect to be entitled to in exchange for those goods or services. We have entered into vendor managed inventory (“VMI”) programs with our customers. Under these arrangements, we receive purchase orders from our customers, and the inventory is shipped to the VMI location upon receipt of the purchase order. The customer then pulls the inventory from the VMI hub based on its production needs. Revenue under VMI programs is recognized when control transfers to the customer, which is generally upon pull of inventory by the customer from the hub.

- added (2018-11-01):
[0001628280-18-013240:note_history:97]
Revenue from all sales types is recognized at transaction price. The transaction price is determined based on the consideration to which we will be entitled in exchange for transferring goods or services to the customer adjusted for estimated variable consideration, if any. We typically estimate the transaction price impact of discounts offered to the customers for early payments on receivables or net of accruals for estimated sales returns. These estimates are based on historical returns, analysis of credit memo data and other known factors. Actual returns could differ from these estimates. We allocate the transaction price to each distinct product based on its relative standalone selling price. The product price as specified on the purchase order is considered the standalone selling price as it is an observable input that depicts the price as if sold to a similar customer in similar circumstances.

- added (2018-11-01):
[0001628280-18-013240:note_history:98]
Taxes assessed by a governmental authority that are both imposed on and concurrent with a specific revenue-producing transaction, that are collected by us from a customer and deposited with the relevant government authority, are excluded from revenue. Our revenue arrangements do not contain significant financing components as our standard payment terms are less than one year.

- added (2018-11-01):
[0001628280-18-013240:note_history:99]
If a customer pays consideration, or Lumentum has a right to an amount of consideration that is unconditional before we transfer a good or service to the customer, those amounts are classified as deferred income/advances received from customers which are included in other current liabilities or other long-term liabilities when the payment is made or it is due, whichever is earlier.

- added (2018-11-01):
[0001628280-18-013240:note_history:100]
Transaction Price Allocated to the Remaining Performance Obligations

- added (2018-11-01):
[0001628280-18-013240:note_history:101]
Remaining performance obligations represent the transaction price allocated to performances obligations that are unsatisfied or partially unsatisfied as of the end of the reporting period. Unsatisfied and partially unsatisfied performance obligations consist of contract liabilities and non-cancellable backlog. Non-cancellable backlog includes goods and services for which customer purchase orders have been accepted that are scheduled or in the process of being scheduled for shipment.

- added (2018-11-01):
[0001628280-18-013240:note_history:102]
Disaggregation of Revenue

- added (2018-11-01):
[0001628280-18-013240:note_history:103]
We disaggregate revenue by geography and by product, no other level of disaggregation is required considering the type of products, customer, markets, contracts, duration of contracts, timing of transfer of control and sales channels, based on the information that our chief operating decision maker uses to manage the business.
