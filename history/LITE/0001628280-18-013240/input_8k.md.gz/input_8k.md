# LITE 8-K — 0001628280-18-013238 filed 2018-11-01

## item codes, every 8-K on or before 2018-11-01

- 2018-11-01 0001628280-18-013238 — 2.02, 9.01
- 2018-08-08 0001633978-18-000056 — 2.02, 9.01
- 2018-06-08 0001193125-18-188241 — 5.02, 9.01
- 2018-05-02 0001633978-18-000029 — 2.02, 9.01
- 2018-03-12 0001193125-18-078154 — 1.01, 2.01, 8.01, 9.01
- 2018-02-06 0001628280-18-001082 — 2.02, 9.01
- 2017-11-08 0001633978-17-000133 — 5.02, 9.01
- 2017-11-07 0001633978-17-000131 — 5.07
- 2017-11-01 0001633978-17-000117 — 2.02, 9.01
- 2017-08-09 0001633978-17-000058 — 2.02, 9.01
- 2017-05-04 0001633978-17-000035 — 2.02, 9.01
- 2017-03-08 0001193125-17-074740 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2017-03-02 0001193125-17-066769 — 8.01, 9.01
- 2017-02-07 0001633978-17-000005 — 2.02, 9.01
- 2017-01-03 0001628280-17-000018 — 4.01, 9.01
- 2016-11-09 0001628280-16-021143 — 5.02, 5.07, 9.01
- 2016-10-27 0001628280-16-020382 — 2.02, 9.01
- 2016-08-09 0001628280-16-018811 — 2.02, 9.01
- 2016-06-21 0001628280-16-017201 — 8.01
- 2016-05-04 0001628280-16-015501 — 2.02, 9.01
- 2016-02-16 0001628280-16-011261 — 5.02, 9.01
- 2016-02-04 0001628280-16-010758 — 5.02, 9.01
- 2016-02-04 0001628280-16-010755 — 2.02, 9.01
- 2015-11-17 0001193125-15-378953 — 7.01
- 2015-11-10 0001628280-15-008606 — 2.02, 9.01
- 2015-09-28 0001193125-15-329665 — 8.01, 9.01
- 2015-08-11 0001193125-15-286405 — 7.01, 9.01
- 2015-08-06 0001193125-15-281219 — 1.01, 5.02, 5.03, 5.05, 8.01, 9.01
- 2015-08-03 0001193125-15-274808 — 5.03, 9.01

## late-filing notifications on or before 2018-11-01

- 2015-11-10 0001628280-15-008612 — NT 10-Q, for the period ended 2015-09-26
- 2015-09-28 0001193125-15-329672 — NT 10-K, for the period ended 2015-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001628280-18-013238:8k_2_02:1]
EX-99.1
2
lite_ex991xq1fy19.htm
EXHIBIT 99.1

[0001628280-18-013238:8k_2_02:2]
Exhibit

[0001628280-18-013238:8k_2_02:3]
NEWS RELEASE

[0001628280-18-013238:8k_2_02:4]
LUMENTUM ANNOUNCES FISCAL FIRST QUARTER 2019 RESULTS

[0001628280-18-013238:8k_2_02:5]
Fiscal First Quarter Highlights:

[0001628280-18-013238:8k_2_02:6]
| • | Net revenue of $354.1 million |

[0001628280-18-013238:8k_2_02:7]
| • | GAAP operating margin of 16.1%; Non-GAAP operating margin of 23.9% |

[0001628280-18-013238:8k_2_02:8]
| • | GAAP diluted net income per share of $0.72; Non-GAAP diluted net income per share of $1.31 |

[0001628280-18-013238:8k_2_02:9]
Milpitas, Calif., November 1, 2018 – Lumentum Holdings Inc. (“Lumentum” or the “Company”) today reported results for its fiscal first quarter ended September 29, 2018.

[0001628280-18-013238:8k_2_02:10]
Net revenue for the fiscal first quarter of 2019 was $354.1 million, with GAAP net income attributable to common stockholders of $46.1 million, or $0.72 per diluted share. Net revenue for the fiscal fourth quarter of 2018 was $301.1 million, with GAAP net income attributable to common stockholders of $25.7 million, or $0.40 per diluted share. Net revenue for the fiscal first quarter of 2018 was $243.2 million, with GAAP net income attributable to common stockholders of $2.9 million, or $0.04 per diluted share.

[0001628280-18-013238:8k_2_02:11]
Non-GAAP net income for the fiscal first quarter of 2019 was $85.8 million, or $1.31 per diluted share. Non-GAAP net income for the fiscal fourth quarter of 2018 was $61.6 million, or $0.95 per diluted share. Non-GAAP net income for the fiscal first quarter of 2018 was $27.8 million, or $0.43 per diluted share.

[0001628280-18-013238:8k_2_02:12]
The Company held $734.3 million in total cash and short-term investments at the end of the fiscal first quarter of 2019.

[0001628280-18-013238:8k_2_02:13]
“Strong telecom and fiber laser demand, along with 3D sensing expansion across multiple customers and their products drove solid first quarter results,” said Alan Lowe, President and CEO. “Revenues were up more than 45% relative to the prior year, and we saw new record revenues in ROADMs and fiber lasers.  Our strategic investments in differentiated products targeting growth markets reliant on photonics have proven successful and position us well for the years to come.”

[0001628280-18-013238:8k_2_02:14]
Financial Overview – Fiscal First Quarter Ended September 29, 2018

[0001628280-18-013238:8k_2_02:15]
|  | GAAP Results ($ in millions) |
|  | Q1 |  | Q4 |  | Q1 |  | Change |
|  | FY 2019 |  | FY 2018 |  | FY 2018 |  | Q/Q |  | Y/Y |
| Net revenue | $354.1 |  | $301.1 |  | $243.2 |  | 17.6% |  | 45.6% |
| Gross margin | 35.6% |  | 31.7% |  | 28.2% |  | 3.9% |  | 7.4% |
| Operating margin | 16.1% |  | 6.9% |  | 1.1% |  | 9.2% |  | 15.0% |
|  | Non-GAAP Results ($ in millions) |
|  | Q1 |  | Q4 |  | Q1 |  | Change |
|  | FY 2019 |  | FY 2018 |  | FY 2018 |  | Q/Q |  | Y/Y |
| Net revenue | $354.1 |  | $301.1 |  | $243.2 |  | 17.6% |  | 45.6% |
| Gross margin | 40.3% |  | 37.2% |  | 34.0% |  | 3.1% |  | 6.3% |
| Operating margin | 23.9% |  | 17.8% |  | 11.8% |  | 6.1% |  | 12.1% |

[0001628280-18-013238:8k_2_02:16]
|  | Net Revenue by Segment ($ in millions) |
|  | Q1 |  | % of |  | Q4 |  | Q1 |  | Change |
|  | FY 2019 |  | Net Revenue |  | FY 2018 |  | FY 2018 |  | Q/Q |  | Y/Y |
| Optical Communications | $310.1 |  | 87.6% |  | $244.9 |  | $207.9 |  | 26.6% |  | 49.2% |
| Lasers | 44.0 |  | 12.4% |  | 56.2 |  | 35.3 |  | (21.7)% |  | 24.6% |
| Total | $354.1 |  | 100.0% |  | $301.1 |  | $243.2 |  | 17.6% |  | 45.6% |

[0001628280-18-013238:8k_2_02:17]
The tables above provide comparisons of quarterly results to prior periods, including sequential quarterly and year-over-year changes. A reconciliation between GAAP and non-GAAP measures is contained in this release under the section titled “Use of Non-GAAP Financial Measures.”

[0001628280-18-013238:8k_2_02:18]
On July 1, 2018, we adopted Accounting Standards Update (ASU) 2014-09, Revenue from Contracts with Customers (Topic 606) using the modified retrospective method applied to all contracts that are not completed contracts at the date of initial adoption(i.e., July 1, 2018). Results for reporting periods after July 1, 2018 are presented under Topic 606, while prior period amounts are not adjusted and continue to be reported in accordance with our historic accounting under Topic 605. The adoption of Topic 606 did not have a material impact on the nature and timing of our revenues, consolidated statements of operations, cash flows, and balance sheet and therefore, we do not present results for the three months ended September 29, 2018 under Topic 605.

[0001628280-18-013238:8k_2_02:19]
Business Outlook

[0001628280-18-013238:8k_2_02:20]
The Company expects the following for the fiscal second quarter 2019:

[0001628280-18-013238:8k_2_02:21]
•Net revenue to be in the range of $405 million to $430 million

[0001628280-18-013238:8k_2_02:22]
•Non-GAAP operating margin of 28.0% to 30.0%

[0001628280-18-013238:8k_2_02:23]
•Non-GAAP diluted earnings per share of $1.60 to $1.75

[0001628280-18-013238:8k_2_02:24]
Note:  Earnings per share based on approximately 65.9 million shares outstanding on a fully diluted basis

[0001628280-18-013238:8k_2_02:25]
Our projection of 65.9 million shares outstanding does not include the potentially dilutive effect of the convertible notes, as we have the ability and intent to settle the face value in cash; and therefore, we use the treasury stock method for calculating the dilutive impact of the 2024 Notes. The notes will have an impact on our diluted earnings per share when the average price of our common stock exceeds the conversion price of $60.62. Our guidance does not include results from Oclaro or shares issued in connection with the closing of our acquisition of Oclaro as we are unable to predict the timing of the closing.

[0001628280-18-013238:8k_2_02:26]
We have not provided reconciliations from GAAP to non-GAAP measures for our outlook. A large portion of non-GAAP adjustments, such as derivative liability adjustments, restructuring charges, stock-based compensation, litigation, acquisition-related costs, non-cash income tax expense and credits, and other costs and contingencies unrelated to current and future operations are by their nature highly volatile and we have low visibility as to the range that may be incurred in the future. For example, in the fiscal second quarter of 2018, we had a credit of $207.0 million primarily related to a release of a U.S. valuation allowance, which was offset by a write-down of deferred tax assets in the amount of $83.0 million due to the lower corporate tax rate enacted under the 2017 “Tax Cuts and Jobs Act” reform.

[0001628280-18-013238:8k_2_02:27]
Conference Call

[0001628280-18-013238:8k_2_02:28]
Lumentum will host a conference call on November 1, 2018, at 5:30 am PT/8:30 am ET. A live webcast of the call and the replay will be available on the Lumentum website at http://investor.lumentum.com through November 8, 2018, at 11:59 pm ET. Supporting materials outlining the Company’s latest financial results will be posted on http://investor.lumentum.com under the “Events and Presentations” section concurrently with this earnings press release. This press release is being furnished as an exhibit to a Current Report on Form 8-K filed with the Securities and Exchange Commission and will be available at http://www.sec.gov/.

[0001628280-18-013238:8k_2_02:29]
About Lumentum

[0001628280-18-013238:8k_2_02:30]
Lumentum (NASDAQ: LITE) is a market-leading manufacturer of innovative optical and photonic products enabling optical networking and commercial laser customers worldwide. Lumentum’s optical components and subsystems are part of virtually every type of telecom, enterprise, and data center network. Lumentum’s commercial lasers enable advanced manufacturing techniques and diverse applications including next-generation 3D sensing capabilities. Lumentum is headquartered in Milpitas, California with R&D, manufacturing, and sales offices worldwide.  For more information, visit https://www.lumentum.com/en.

[0001628280-18-013238:8k_2_02:31]
Forward-Looking Statements

[0001628280-18-013238:8k_2_02:32]
to differ materially from those projected. Among the factors that could cause actual results to differ from those contemplated are: (a) quarter-over-quarter product mix fluctuations which can materially impact profitability measures due to the broad gross margin ranges across our portfolio; (b) continued decline of average selling prices across our businesses; (c) effects of seasonality; (d) the ability of our suppliers and contract manufacturers to meet production and delivery requirements for our forecasted demand; (e) inherent uncertainty related to global markets, including the imposition of tariffs or other duties, and the effect of such markets on demand for our products; (f) changes in customer demand; (g) our ability to attract and retain new customers, particularly in the 3D sensing market; (h) the risk that the Oclaro transaction does not close, due to the failure of one or more conditions to closing or the failure of the businesses (including personnel) to be integrated successfully after closing; (i) the risk that synergies and non-GAAP earnings accretion will not be realized or realized to the extent anticipated; (j) uncertainty as to the market value of the Lumentum shares to be issued as consideration in the Oclaro merger; (k) the risk that required governmental approvals of the Oclaro merger (including China antitrust approvals) will not be obtained or that such approvals will be delayed beyond current expectations; (l) the risk that following the Oclaro transaction, Lumentum’s financing or operating strategies will not be successful; (m) litigation in respect of Lumentum or Oclaro or the merger; and (n) disruption from the Oclaro merger making it more difficult to maintain customer, supplier, key personnel and other strategic relationships. For more information on these and other risks, please refer to the “Risk Factors” section included in the Company’s Quarterly Report on Form 10-Q for the fiscal first quarter ended September 29, 2018, filed with the Securities and Exchange Commission, in the S-4, as amended, filed by Lumentum with the Securities and Exchange Commission which was declared effective May 31, 2018, in connection with the Oclaro transaction and in the documents which are incorporated by reference therein, and in the Company’s other filings with the Securities and Exchange Commission, including the Company’s Annual Report on Form 10-K for the fiscal year ended June 30, 2018, filed by Lumentum with the Securities and Exchange Commission on August 28, 2018. The forward-looking statements and preliminary financial results contained in this press release are made as of the date hereof and the Company assumes no obligation to update such statements, except as required by applicable law.

[0001628280-18-013238:8k_2_02:33]
No Offer or Solicitation

[0001628280-18-013238:8k_2_02:34]
This communication is for informational purposes only and not intended to and does not constitute an offer to subscribe for, buy or sell, the solicitation of an offer to subscribe for, buy or sell or an invitation to subscribe for, buy or sell any securities or the solicitation of any vote or approval in any jurisdiction pursuant to or in connection with the proposed Oclaro transaction or otherwise, nor shall there be any sale, issuance or transfer of securities in any jurisdiction in contravention of applicable law. No offer of securities shall be made except by means of a prospectus meeting the requirements of Section 10 of the Securities Act of 1933, as amended, and otherwise in accordance with applicable law.

[0001628280-18-013238:8k_2_02:35]
Additional Information and Where to Find It

[0001628280-18-013238:8k_2_02:36]
In connection with the proposed transaction between Lumentum Holdings Inc. (“Lumentum”) and Oclaro, Inc. (“Oclaro”), Lumentum filed a registration statement on Form S-4 with the Securities and Exchange Commission (the “SEC”), which includes a proxy statement of Oclaro that also constitutes a prospectus of Lumentum. The registration statement was declared effective by the SEC on May 31, 2018, and Oclaro commenced mailing the definitive joint proxy statement/prospectus to stockholders of Oclaro on or about June 4, 2018, and the special meeting of the stockholders of Oclaro was held on July 10, 2018.

[0001628280-18-013238:8k_2_02:37]
LUMENTUM AND OCLARO URGE INVESTORS AND SECURITY HOLDERS TO READ THE DEFINITIVE PROXY STATEMENT/PROSPECTUS AND OTHER DOCUMENTS FILED WITH THE SECURITIES AND EXCHANGE COMMISSION CAREFULLY AND IN THEIR ENTIRETY BECAUSE THEY CONTAIN IMPORTANT INFORMATION ABOUT THE PROPOSED TRANSACTION.

[0001628280-18-013238:8k_2_02:38]
Investors and security holders may obtain these materials and other documents filed with the Securities and Exchange Commission free of charge at the Securities and Exchange Commission’s website, www.sec.gov. Copies of documents filed with the Securities and Exchange Commission by Lumentum (when they become available) may be obtained free of charge on Lumentum’s website at www.lumentum.com or by directing a written request to Lumentum Holdings Inc., Investor Relations, 400 North McCarthy Boulevard, Milpitas, CA 95035. Copies of documents filed with the Securities and Exchange Commission by Oclaro (when they become available) may be obtained free of charge on Oclaro’s website at www.oclaro.com or by directing a written request to Oclaro, Inc. Investor Relations, 225 Charcot Avenue, San Jose, CA 95131.

[0001628280-18-013238:8k_2_02:39]
Contact Information

[0001628280-18-013238:8k_2_02:40]
Investors: Chris Coldren, 408-404-0606; investor.relations@lumentum.com

[0001628280-18-013238:8k_2_02:41]
Press: Greg Kaufman, 408-546-4593; media@lumentum.com

[0001628280-18-013238:8k_2_02:42]
The following financial tables are presented in accordance with GAAP, unless otherwise specified.

[0001628280-18-013238:8k_2_02:43]
LUMENTUM HOLDINGS INC.

[0001628280-18-013238:8k_2_02:44]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0001628280-18-013238:8k_2_02:45]
(in millions, except per share data)

[0001628280-18-013238:8k_2_02:46]
(unaudited)

[0001628280-18-013238:8k_2_02:47]
|  | Three Months Ended |
|  | September 29, 2018 |  | September 30, 2017 |
| Net revenue | $ | 354.1 |  |  | $ | 243.2 |  |
| Cost of sales | 227.3 |  |  | 173.9 |  |
| Amortization of acquired developed technologies | 0.8 |  |  | 0.8 |  |
| Gross profit | 126.0 |  |  | 68.5 |  |
| Operating expenses: |  |  |  |
| Research and development | 34.6 |  |  | 36.3 |  |
| Selling, general and administrative | 33.0 |  |  | 26.6 |  |
| Restructuring and related charges | 1.3 |  |  | 2.9 |  |
| Total operating expenses | 68.9 |  |  | 65.8 |  |
| Income from operations | 57.1 |  |  | 2.7 |  |
| Unrealized gain (loss) on derivative liability | (2.1 | ) |  | 4.2 |  |
| Interest and other income (expense), net | (2.4 | ) |  | (3.4 | ) |
| Income before income taxes | 52.6 |  |  | 3.5 |  |
| Provision for (benefit from) income taxes | 5.2 |  |  | (3.6 | ) |
| Net income | 47.4 |  |  | 7.1 |  |
| Items reconciling net income to net income attributable to common stockholders: |  |  |  |
| Cumulative dividends on Series A Preferred Stock | (0.2 | ) |  | (0.2 | ) |
| Earnings allocated to Series A Preferred Stock | (1.1 | ) |  | (0.2 | ) |
| Net income attributable to common stockholders - Basic | $ | 46.1 |  |  | $ | 6.7 |  |
| Add: Earnings allocated to Series A Preferred Stock | — |  |  | 0.2 |  |
| Add/Less: Unrealized (gain) loss on derivative liability on Series A Preferred Stock | — |  |  | (4.2 | ) |
| Add: Cumulative dividends on Series A Preferred Stock | — |  |  | 0.2 |  |
| Net income attributable to common stockholders - Diluted (a) | $ | 46.1 |  |  | $ | 2.9 |  |
| Net income per share attributable to common stockholders: |  |  |  |
| Basic | $ | 0.73 |  |  | $ | 0.11 |  |
| Diluted | $ | 0.72 |  |  | $ | 0.04 |  |
| Shares used to compute net income per share attributable to common stockholders: |  |  |  |
| Basic | 63.1 |  |  | 61.7 |  |
| Diluted | 63.9 |  |  | 64.5 |  |

[0001628280-18-013238:8k_2_02:48]
(a) For the three months ended September 30, 2017, our diluted earnings per share attributable to common stockholders is calculated using the if-converted method because it is more dilutive, whereas for the three months ended September 29, 2018, our diluted earnings per share attributable to common stockholders is calculated using the treasury stock method.

[0001628280-18-013238:8k_2_02:49]
LUMENTUM HOLDINGS INC.

[0001628280-18-013238:8k_2_02:50]
CONSOLIDATED BALANCE SHEETS

[0001628280-18-013238:8k_2_02:51]
(in millions, except share and per share data)

[0001628280-18-013238:8k_2_02:52]
(unaudited)

[0001628280-18-013238:8k_2_02:53]
|  | September 29, 2018 |  | June 30, 2018 |
| ASSETS |  |  |  |  |  |
| Current assets: |  |  |  |  |  |
| Cash and cash equivalents | $ | 459.4 |  |  | $ | 397.3 |  |
| Short-term investments | 274.9 |  |  | 314.2 |  |
| Accounts receivable, net | 239.6 |  |  | 197.1 |  |
| Inventories | 136.6 |  |  | 153.6 |  |
| Prepayments and other current assets | 70.6 |  |  | 65.0 |  |
| Total current assets | 1,181.1 |  |  | 1,127.2 |  |
| Property, plant and equipment, net | 318.6 |  |  | 306.9 |  |
| Goodwill and intangibles, net | 17.6 |  |  | 18.3 |  |
| Deferred income taxes | 122.0 |  |  | 125.6 |  |
| Other non-current assets | 5.7 |  |  | 3.5 |  |
| Total assets | $ | 1,645.0 |  |  | $ | 1,581.5 |  |
| LIABILITIES, REDEEMABLE CONVERTIBLE PREFERRED STOCK, AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 127.6 |  |  | $ | 126.5 |  |
| Accrued payroll and related expenses | 30.3 |  |  | 31.5 |  |
| Accrued expenses | 35.0 |  |  | 33.9 |  |
| Other current liabilities | 21.0 |  |  | 22.1 |  |
| Total current liabilities | 213.9 |  |  | 214.0 |  |
| Convertible notes | 338.5 |  |  | 334.2 |  |
| Derivative liability | 54.5 |  |  | 52.4 |  |
| Other non-current liabilities | 18.8 |  |  | 19.0 |  |
| Total liabilities | 625.7 |  |  | 619.6 |  |
| Redeemable convertible preferred stock: |  |  |  |
| Non-controlling interest redeemable convertible Series A Preferred Stock, $0.001 par value, 10,000,000 authorized shares; 35,805 shares issued and outstanding as of September 29, 2018 and June 30, 2018 | 35.8 |  |  | 35.8 |  |
| Total redeemable convertible preferred stock | 35.8 |  |  | 35.8 |  |
| Stockholders’ equity: |  |  |  |
| Common stock, $0.001 par value, 990,000,000 authorized shares, 63,346,678 and 62,790,087 shares issued and outstanding as of September 29, 2018 and June 30, 2018, respectively | 0.1 |  |  | 0.1 |  |
| Additional paid-in capital | 763.5 |  |  | 753.2 |  |
| Retained earnings | 213.0 |  |  | 166.4 |  |
| Accumulated other comprehensive income | 6.9 |  |  | 6.4 |  |
| Total stockholders’ equity | 983.5 |  |  | 926.1 |  |
| Total liabilities, redeemable convertible preferred stock, and stockholders’ equity | $ | 1,645.0 |  |  | $ | 1,581.5 |  |

[0001628280-18-013238:8k_2_02:54]
Use of Non-GAAP Financial Measures

[0001628280-18-013238:8k_2_02:55]
In this press release, Lumentum provides investors with gross margin, operating margin, net income, and net income (loss) per share on a non-GAAP basis. Lumentum believes this non-GAAP financial information provides additional insight into the Company’s on-going performance and has therefore chosen to provide this information to investors for a more consistent basis of comparison and to help them evaluate the results of the Company’s on-going operations and enable more meaningful period to period comparisons. Specifically, the Company believes that providing this information allows investors to better understand the Company’s financial performance and, importantly, to evaluate the efficacy of the methodology and information used by management to evaluate and measure such operating performance. However, these measures may be different from non-GAAP measures used by other companies, limiting their usefulness for comparison purposes. The non-GAAP financial measures used in this press release should not be considered in isolation from measures of financial performance prepared in accordance with GAAP. Investors are cautioned that there are material limitations associated with the use of non-GAAP financial measures as an analytical tool. In particular, many of the adjustments to our GAAP financial measures reflect the exclusion of items that are recurring and will be reflected in our financial results for the foreseeable future. Further, these non-GAAP financial measures may not be comparable to similarly titled measurements reported by other companies.

[0001628280-18-013238:8k_2_02:56]
Non-GAAP gross margin, non-GAAP operating margin, non-GAAP net income, and non-GAAP net income per share, non-GAAP gross profit, non-GAAP operating income, non-GAAP income (loss) before income taxes and non-GAAP expenses exclude (i) stock-based compensation, (ii) acquisition related costs, (iii) other charges comprised mainly of set-up costs of our Thailand facility, including costs of transferring product lines to Thailand, as well as inventory write-downs due to cancelled programs and other costs and contingencies unrelated to current and future operations, (iv) amortization of acquired developed technologies, (v) workforce related charges such as severance, retention bonuses and employee relocation costs related to formal restructuring plans, (vi) non-cash interest expense, (vii) unrealized gain (loss) on derivative liability, and (viii) non-cash income tax provision impacts, for example, a release of a U.S. valuation allowance, and the write down of deferred tax assets due to the 2017 Tax Cuts and Jobs Act. The presentation of these and other similar items in Lumentum’s non-GAAP financial results should not be interpreted as implying that these items are non-recurring, infrequent or unusual.

[0001628280-18-013238:8k_2_02:57]
A quantitative reconciliation between GAAP and non-GAAP financial data with respect to historical periods is included in the supplemental financial table attached to this press release.

[0001628280-18-013238:8k_2_02:58]
LUMENTUM HOLDINGS INC.

[0001628280-18-013238:8k_2_02:59]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001628280-18-013238:8k_2_02:60]
(in millions, except per share data)

[0001628280-18-013238:8k_2_02:61]
(unaudited)

[0001628280-18-013238:8k_2_02:62]
|  | Three Months Ended |
|  | September 29, 2018 |  | September 30, 2017 |
| Gross profit on GAAP basis | $ | 126.0 |  |  | $ | 68.5 |  |
| Stock-based compensation | 3.3 |  |  | 2.7 |  |
| Other charges related to non-recurring activities (1) | 12.5 |  |  | 10.7 |  |
| Amortization of acquired developed technologies | 0.8 |  |  | 0.8 |  |
| Gross profit on non-GAAP basis | $ | 142.6 |  |  | $ | 82.7 |  |
| Research and development on GAAP basis | $ | 34.6 |  |  | $ | 36.3 |  |
| Stock-based compensation | (2.8 | ) |  | (3.1 | ) |
| Other charges related to non-recurring activities | (0.2 | ) |  | (0.7 | ) |
| Research and development on non-GAAP basis | $ | 31.6 |  |  | $ | 32.5 |  |
| Selling, general and administrative on GAAP basis | $ | 33.0 |  |  | $ | 26.6 |  |
| Stock-based compensation | (4.7 | ) |  | (3.5 | ) |
| Acquisition related costs | (1.1 | ) |  | — |  |
| Other charges related to non-recurring activities | (0.9 | ) |  | (1.5 | ) |
| Amortization of acquired developed technologies | — |  |  | — |  |
| Selling, general and administrative on non-GAAP basis | $ | 26.3 |  |  | $ | 21.6 |  |
| Income from operations on GAAP basis | $ | 57.1 |  |  | $ | 2.7 |  |
| Stock-based compensation | 10.8 |  |  | 9.3 |  |
| Acquisition related costs | 1.1 |  |  | — |  |
| Other charges related to non-recurring activities | 13.6 |  |  | 12.9 |  |
| Amortization of acquired developed technologies | 0.8 |  |  | 0.8 |  |
| Restructuring and related charges | 1.3 |  |  | 2.9 |  |
| Income from operations on non-GAAP basis | $ | 84.7 |  |  | $ | 28.6 |  |
| Interest and other (expense) income, net on GAAP basis | $ | (2.4 | ) |  | $ | (3.4 | ) |
| Other interest and (income) expense adjustments | (0.2 | ) |  | — |  |
| Effective interest expense on convertible notes | 4.3 |  |  | 4.1 |  |
| Interest and other (expense) income, net on non-GAAP basis | $ | 1.7 |  |  | $ | 0.7 |  |
| Income before income taxes on GAAP basis | $ | 52.6 |  |  | $ | 3.5 |  |
| Stock-based compensation | 10.8 |  |  | 9.3 |  |
| Acquisition related costs | 1.1 |  |  | — |  |
| Other charges related to non-recurring activities | 13.6 |  |  | 12.9 |  |
| Amortization of acquired developed technologies | 0.8 |  |  | 0.8 |  |
| Restructuring and related charges | 1.3 |  |  | 2.9 |  |
| Other interest and (income) expense adjustments | (0.2 | ) |  | — |  |
| Effective interest expense on convertible notes | 4.3 |  |  | 4.1 |  |

[0001628280-18-013238:8k_2_02:63]
| Unrealized (gain) loss on derivative liability | 2.1 |  |  | (4.2 | ) |
| Income before income taxes on non-GAAP basis | $ | 86.4 |  |  | $ | 29.3 |  |
| Provision for (benefit from) income taxes on GAAP basis | $ | 5.2 |  |  | $ | (3.6 | ) |
| Income tax adjustments | (4.6 | ) |  | 5.1 |  |
| Provision for (benefit from) income taxes on non-GAAP basis | $ | 0.6 |  |  | $ | 1.5 |  |
| Net income on GAAP basis | $ | 47.4 |  |  | $ | 7.1 |  |
| Stock-based compensation | 10.8 |  |  | 9.3 |  |
| Acquisition related costs | 1.1 |  |  | — |  |
| Other charges related to non-recurring activities | 13.6 |  |  | 12.9 |  |
| Amortization of acquired developed technologies | 0.8 |  |  | 0.8 |  |
| Restructuring and related charges | 1.3 |  |  | 2.9 |  |
| Other interest and (income) expense adjustments | (0.2 | ) |  | — |  |
| Effective interest expense on convertible notes | 4.3 |  |  | 4.1 |  |
| Unrealized (gain) loss on derivative liability | 2.1 |  |  | (4.2 | ) |
| Income tax adjustments | 4.6 |  |  | (5.1 | ) |
| Net income on non-GAAP basis | $ | 85.8 |  |  | $ | 27.8 |  |
| Net income per share on non-GAAP basis | $ | 1.31 |  |  | $ | 0.43 |  |
| Shares used in per share calculation - diluted on GAAP basis | 63.9 |  |  | 64.5 |  |
| Effect of diluted securities from Series A Preferred Stock (2) | 1.5 |  |  | — |  |
| Shares used in per share calculation - diluted on non-GAAP basis | 65.4 |  |  | 64.5 |  |

[0001628280-18-013238:8k_2_02:64]
(1) For the three months ended September 29, 2018, other charges related to non-recurring activities primarily include set-up costs of our facility in Thailand, including costs of transferring product lines to Thailand of $12.7 million. For the three months ended September 30, 2017, other charges related to non-recurring activities primarily include set-up costs of our facility in Thailand of $3.1 million, as well as inventory write-downs due to canceled programs not allocated to the segments of $7.0 million.

[0001628280-18-013238:8k_2_02:65]
(2) For the three months ended September 29, 2018, 1.5 million shares related to the potential conversion of the Series A Preferred Stock were added to the calculation of diluted shares available on a non-GAAP basis because their inclusion results in more dilutive earnings per share.

[0001628280-18-013238:8k_2_02:66]
LUMENTUM HOLDINGS INC.

[0001628280-18-013238:8k_2_02:67]
RECONCILIATION OF GAAP NET INCOME (LOSS) TO EBITDA

[0001628280-18-013238:8k_2_02:68]
(in millions)

[0001628280-18-013238:8k_2_02:69]
(unaudited)

[0001628280-18-013238:8k_2_02:70]
|  | Three Months Ended |
|  | September 29, 2018 |  | September 30, 2017 |
| GAAP net income | $ | 47.4 |  |  | $ | 7.1 |  |
| Interest and other expense (income), net | 2.4 |  |  | 3.4 |  |
| Provision for (benefit from) income taxes | 5.2 |  |  | (3.6 | ) |
| Depreciation | 19.7 |  |  | 16.7 |  |
| Amortization of acquired developed technologies | 0.8 |  |  | 0.8 |  |
| EBITDA | $ | 75.5 |  |  | $ | 24.4 |  |
