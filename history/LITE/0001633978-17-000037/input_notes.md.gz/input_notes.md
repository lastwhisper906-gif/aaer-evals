# LITE notes — 0001633978-17-000037


## lite:PropertyPlantandEquipmentNetTableTextBlock

[0001633978-17-000037:notes:1]
[same as prior period, unchanged from 0001633978-17-000006:notes:1]

[0001633978-17-000037:notes:2]
|  | April 1, 2017 |  | July 2, 2016 |
| Land | $ | 10.5 |  |  | $ | 5.9 |  |
| Buildings and improvement | 35.7 |  |  | 28.9 |  |
| Machinery and equipment | 443.2 |  |  | 378.5 |  |
| Furniture and fixtures and software | 33.0 |  |  | 32.2 |  |
| Leasehold improvements | 29.8 |  |  | 28.6 |  |
| Construction in progress | 65.1 |  |  | 44.1 |  |
|  | 617.3 |  |  | 518.2 |  |
| Less: Accumulated depreciation | (370.7 | ) |  | (334.8 | ) |
| Property, plant and equipment, net | $ | 246.6 |  |  | $ | 183.4 |  |


## lite:ScheduleOfOtherLiabilitiesCurrentTableTextBlock

[0001633978-17-000037:notes:3]
[same as prior period, unchanged from 0001633978-17-000006:notes:3]

[0001633978-17-000037:notes:4]
|  | April 1, 2017 |  | July 2, 2016 |
| Warranty accrual (Note 15) | $ | 8.1 |  |  | $ | 2.8 |  |
| Restructuring accrual and related charges (Note 12) | 5.3 |  |  | 5.5 |  |
| Deferred revenue | 4.6 |  |  | 2.7 |  |
| Others | 1.2 |  |  | 1.1 |  |
| Other current liabilities | $ | 19.2 |  |  | $ | 12.1 |  |


## lite:ScheduleOfOtherLiabilitiesNoncurrentTableTextBlock

[0001633978-17-000037:notes:5]
[same as prior period, unchanged from 0001633978-17-000006:notes:5]

[0001633978-17-000037:notes:6]
|  | April 1, 2017 |  | July 2, 2016 |
| Asset retirement obligation | $ | 2.1 |  |  | $ | 2.3 |  |
| Pension and related accrual | 3.4 |  |  | 3.5 |  |
| Deferred rent | 3.2 |  |  | 1.6 |  |
| Restructuring accrual and related charges | — |  |  | 0.2 |  |
| Unrecognized tax benefit | 6.2 |  |  | 0.1 |  |
| Other non-current liabilities | 5.0 |  |  | 1.4 |  |
| Other non-current liabilities | $ | 19.9 |  |  | $ | 9.1 |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001633978-17-000037:notes:7]
Note 7. Balance Sheet and Other Details

[0001633978-17-000037:notes:8]
[same as prior period, unchanged from 0001633978-17-000006:notes:8]

[0001633978-17-000037:notes:9]
[same as prior period, unchanged from 0001633978-17-000006:notes:9]

[0001633978-17-000037:notes:10]
|  | April 1, 2017 |  | July 2, 2016 |
| Finished goods | $ | 58.2 |  |  | $ | 46.1 |  |
| Work in process | 35.6 |  |  | 25.5 |  |
| Raw materials and purchased parts | 23.1 |  |  | 29.0 |  |
| Inventories | $ | 116.9 |  |  | $ | 100.6 |  |

[0001633978-17-000037:notes:11]
[same as prior period, unchanged from 0001633978-17-000006:notes:11]

[0001633978-17-000037:notes:12]
[same as prior period, unchanged from 0001633978-17-000006:notes:12]

[0001633978-17-000037:notes:13]
|  | April 1, 2017 |  | July 2, 2016 |
| Capitalized manufacturing overhead | $ | 33.1 |  |  | $ | 27.3 |  |
| Prepayments | 8.6 |  |  | 6.4 |  |
| Advances to contract manufacturers | 10.3 |  |  | 10.3 |  |
| Due from (to) Viavi, net | — |  |  | 2.0 |  |
| Other current assets | 9.4 |  |  | 15.3 |  |
| Prepayments and other current assets | $ | 61.4 |  |  | $ | 61.3 |  |

[0001633978-17-000037:notes:14]
[same as prior period, unchanged from 0001633978-17-000006:notes:14]

[0001633978-17-000037:notes:15]
[same as prior period, unchanged from 0001633978-17-000006:notes:15]

[0001633978-17-000037:notes:16]
During the three and nine months ended April 1, 2017, we recorded depreciation expense of $14.1 million and $39.1 million, respectively. During the three and nine months ended April 2, 2016, we recorded depreciation expense of $11.3 million and $35.1 million, respectively. Our construction in progress includes primarily machinery and equipment that was purchased to increase our manufacturing capacity. We expect to place these assets in service in next 12 months.

[0001633978-17-000037:notes:17]
[same as prior period, unchanged from 0001633978-17-000006:notes:17]

[0001633978-17-000037:notes:18]
[same as prior period, unchanged from 0001633978-17-000006:notes:18]


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001633978-17-000037:notes:19]
[same as prior period, unchanged from 0001633978-17-000006:notes:19]

[0001633978-17-000037:notes:20]
[same as prior period, unchanged from 0001633978-17-000006:notes:20]

[0001633978-17-000037:notes:21]
On July 31, 2015, prior to the Separation (as described below), JDSU transferred substantially all of the assets and liabilities and operations of the CCOP segment and WaveReady product lines to Lumentum. Financial statements for periods prior to the Separation were prepared on a stand-alone basis and were derived from JDSU’s consolidated financial statements and accounting records. The Company prepared consolidated financial statements for the period from June 28, 2015 to August 1, 2015 where expenses were allocated to the Company using estimates that it considers to be a reasonable reflection of the utilization of services provided to, or benefits received by, the Company. Since August 1, 2015, the Company has prepared consolidated financial statements as an independent stand-alone basis pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (SEC) and are in conformity with generally accepted accounting principles in the United States (GAAP). In the opinion of management, these consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments, which are necessary for a fair statement of the consolidated financial statements for the periods shown. The results of operations for such periods are not necessarily indicative of the results expected for the full year or for any future periods.

[0001633978-17-000037:notes:22]
[same as prior period, unchanged from 0001633978-17-000006:notes:22]


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001633978-17-000037:notes:23]
Note 6. Mergers and Acquisitions

[0001633978-17-000037:notes:24]
In February 2017, we completed the acquisition of a privately held company to enhance our manufacturing and vertical integration capabilities. We acquired all of the outstanding shares of the company.  In connection with the acquisition, we paid upfront cash consideration of $5.1 million, incurred liabilities of $2.7 million contingent upon the achievement of certain production targets being achieved within 36 months following the acquisition date, and retained $0.9 million of the purchase price as security for the seller’s indemnification obligations under the purchase agreement. This resulted in total purchase consideration of $8.7 million.

[0001633978-17-000037:notes:25]
The Company estimated the acquisition date fair value of the contingent consideration as the present value of the expected contingent payments, determined using a probabilistic approach. The Company is required to reassess the fair value of contingent payments on a periodic basis. The Company estimated the likelihood of meeting the production targets at 90 percent and recorded the fair value of such contingent consideration in accrued liabilities on the interim consolidated balance sheet as of April 1, 2017. This contingent consideration will result in a cash payment of $3.0 million, if and when the production targets are achieved.

[0001633978-17-000037:notes:26]
The amount retained to cover any potential liabilities is payable at the 15 month anniversary of the close date. The Company is currently unaware of any claims that would be made against this amount and anticipates that it will be paid in full on the due date.

[0001633978-17-000037:notes:27]
We recorded the assets acquired and liabilities assumed at their estimated fair values, with the difference between the fair value of the net assets acquired and the purchase consideration reflected in goodwill. The following table reflects the preliminary fair values of assets acquired and liabilities assumed (in millions):

[0001633978-17-000037:notes:28]
| Cash and cash equivalents | $ | — |  |
| Accounts receivable, net | 0.1 |  |
| Inventories | 1.9 |  |
| Prepayments and other current assets | 0.2 |  |
| Property, plant and equipment, net | 0.8 |  |
| Developed technology | 2.4 |  |
| Goodwill | 5.6 |  |
| Accounts payable | (0.4 | ) |
| Accrued expenses and payroll | (0.2 | ) |
| Deferred revenue | (1.1 | ) |
| Deferred tax liability | (0.6 | ) |
| Total value of assets acquired and liabilities assumed | $ | 8.7 |  |

[0001633978-17-000037:notes:29]
As of the acquisition date, developed technology of the target business had an estimated useful life of six years. The goodwill is primarily attributed to the synergies expected to be realized following the acquisition and the assembled workforce. Goodwill has been assigned to the Optical Communications segment and is not deductible for tax purposes.

[0001633978-17-000037:notes:30]
Results of operations of the business acquired have been included in our consolidated financial statements subsequent to the date of acquisition. Pro forma statements have not been presented because they are not material to our consolidated results of operations.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001633978-17-000037:notes:31]
[same as prior period, unchanged from 0001633978-17-000006:notes:23]

[0001633978-17-000037:notes:32]
[same as prior period, unchanged from 0001633978-17-000006:notes:24]

[0001633978-17-000037:notes:33]
[same as prior period, unchanged from 0001633978-17-000006:notes:25]

[0001633978-17-000037:notes:34]
As of April 1, 2017, Viavi held a total of 0.4 million shares of our common stock, which is under 1% of our total shares outstanding.

[0001633978-17-000037:notes:35]
See "Note 3. Related Party Transactions" in the Notes to Unaudited Consolidated Financial Statements regarding the relationships we have with Viavi.

[0001633978-17-000037:notes:36]
[same as prior period, unchanged from 0001633978-17-000006:notes:29]

[0001633978-17-000037:notes:37]
[same as prior period, unchanged from 0001633978-17-000006:notes:30]

[0001633978-17-000037:notes:38]
[same as prior period, unchanged from 0001633978-17-000006:notes:31]

[0001633978-17-000037:notes:39]
[same as prior period, unchanged from 0001633978-17-000006:notes:32]

[0001633978-17-000037:notes:40]
[same as prior period, unchanged from 0001633978-17-000006:notes:33]

[0001633978-17-000037:notes:41]
The preparation of our consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amount of assets and liabilities at the date of the financial statements, the reported amount of net revenue and expenses and the disclosure of commitments and contingencies during the reporting periods. We base estimates on historical experience and on various assumptions about the future believed to be reasonable based on available information. On an ongoing basis, the Company evaluates its estimates, including those related to revenue recognition, inventory valuation, allocation methods and allocated expenses from Viavi, valuation of goodwill and other intangible assets, stock-based compensation, retirement and post-retirement plan assumptions, restructuring, warranty, valuation of derivative liabilities, and accounting for income taxes. Our reported financial position or results of operations may be materially different under changed conditions or when using different estimates and assumptions, particularly with respect to significant accounting policies. If estimates or assumptions differ from actual results, subsequent periods are adjusted to reflect more current information.

[0001633978-17-000037:notes:42]
[same as prior period, unchanged from 0001633978-17-000006:notes:35]

[0001633978-17-000037:notes:43]
Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are revenue recognition, inventory valuation, allocation methods and allocated expenses from Viavi, valuation of goodwill and other intangible assets, stock-based compensation, retirement and post-retirement plan assumptions, restructuring, warranty, valuation of derivative liabilities, and accounting for income taxes.

[0001633978-17-000037:notes:44]
There have been no material changes in our significant accounting policies during the nine months ended April 1, 2017 compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 2, 2016. The accompanying unaudited interim consolidated financial statements and accompanying related notes should be read in conjunction with the consolidated financial statements and related notes included in our Annual Report on Form 10-K for the fiscal year ended July 2, 2016.


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0001633978-17-000037:notes:45]
Note 15. Commitments and Contingencies

[0001633978-17-000037:notes:46]
Operating Leases

[0001633978-17-000037:notes:47]
We lease certain real and personal property from unrelated third parties under non-cancellable operating leases that expire at various dates through fiscal 2026. Certain leases require us to pay property taxes, insurance and routine maintenance, and include escalation clauses. As of April 1, 2017, the future minimum annual lease payments under non-cancellable operating leases were as follows (in millions):

[0001633978-17-000037:notes:48]
| Remainder of 2017 | $ | 1.7 |  |
| 2018 | 6.5 |  |
| 2019 | 6.0 |  |
| 2020 | 4.6 |  |
| 2021 | 3.6 |  |
| Thereafter | 6.9 |  |
| Total minimum operating lease payments | $ | 29.3 |  |

[0001633978-17-000037:notes:49]
Included in the future minimum lease payments table above is $0.5 million related to lease commitments in connection with our restructuring and related activities. Refer to "Note 12. Restructuring and Related Charges" in the Notes to Unaudited  Consolidated Financial Statements.

[0001633978-17-000037:notes:50]
Acquisition Contingencies

[0001633978-17-000037:notes:51]
The Company incurred contingent liabilities in the amount of $3.6 million in connection with the February 2017 acquisition. The amount of $2.7 million is payable in 36 months following the acquisition date contingent upon meeting certain production targets. The Company retained $0.9 million of the purchase price to cover any potential liabilities under the representations, warranties and indemnifications included in the purchase agreement, the amount is payable at the 15 month anniversary of the close date. Refer to "Note 6. Mergers and Acquisitions".

[0001633978-17-000037:notes:52]
0.25% Convertible Senior Notes due 2024

[0001633978-17-000037:notes:53]
The future interest and principal payments related to the Notes are as follows as of April 1, 2017:

[0001633978-17-000037:notes:54]
| Remainder of 2017 | $ | — |  |
| 2018 | 1.2 |  |
| 2019 | 1.1 |  |
| 2020 | 1.1 |  |
| 2021 | 1.1 |  |
| Thereafter | 452.8 |  |
| Total Notes payments | $ | 457.3 |  |

[0001633978-17-000037:notes:55]
Purchase Obligations

[0001633978-17-000037:notes:56]
Purchase obligations of $110.5 million as of April 1, 2017, represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule and adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

[0001633978-17-000037:notes:57]
We depend on a limited number of contract manufacturers, subcontractors and suppliers for raw materials, packages and standard components. We generally purchase these single or limited source products through standard purchase orders or one-year supply agreements and have no significant long-term guaranteed supply agreements with such vendors. While we seek to maintain a sufficient safety stock of such products and maintain on-going communications with our suppliers to guard against interruptions or cessation of supply, our business and results of operations could be adversely affected by a stoppage or delay of supply, substitution of more expensive or less reliable products, receipt of defective parts or contaminated materials, increases in the price of such supplies, or our inability to obtain reduced pricing from our suppliers in response to competitive pressures.

[0001633978-17-000037:notes:58]
Product Warranties

[0001633978-17-000037:notes:59]
We provide reserves for the estimated costs of product warranties at the time revenue is recognized. We typically offer a twelve month warranty for most of our products. However, in some instances depending upon the product, product component or application of our products by the end customer, our warranties can vary and generally range from six months to five years. We estimate the costs of our warranty obligations on an annualized basis based on our historical experience of known product failure rates, use of materials to repair or replace defective products and service delivery costs incurred in correcting product failures. In addition, from time to time, specific warranty accruals may be made if unforeseen technical problems arise with specific products. We assess the adequacy of our recorded warranty liabilities and adjust the amounts as necessary.

[0001633978-17-000037:notes:60]
The following table presents the changes in our warranty reserve during the three and nine months ended April 1, 2017 and April 2, 2016 (in millions):

[0001633978-17-000037:notes:61]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 1, 2017 |  | April 2, 2016 |  | April 1, 2017 |  | April 2, 2016 |
| Balance as of beginning of period | $ | 8.7 |  |  | $ | 3.1 |  |  | $ | 2.8 |  |  | $ | 2.8 |  |
| Provision for warranty | 0.6 |  |  | 0.8 |  |  | 9.3 |  |  | 2.5 |  |
| Utilization of reserve | (1.2 | ) |  | (0.8 | ) |  | (4.0 | ) |  | (2.3 | ) |
| Adjustments related to pre-existing warranties (includingchanges in estimates) | — |  |  | (1.3 | ) |  | — |  |  | (1.2 | ) |
| Balance as of period end | $ | 8.1 |  |  | $ | 1.8 |  |  | $ | 8.1 |  |  | $ | 1.8 |  |

[0001633978-17-000037:notes:62]
Environmental Liabilities

[0001633978-17-000037:notes:63]
Our research and development ("R&D"), manufacturing and distribution operations involve the use of hazardous substances and are regulated under international, federal, state and local laws governing health and safety and the environment. We apply strict standards for protection of the environment and occupational health and safety to sites inside and outside the United States, even if not subject to regulations imposed by foreign governments. We believe that our properties and operations at our facilities comply in all material respects with applicable environmental laws and occupational health and safety laws. However, the risk of environmental liabilities cannot be completely eliminated and there can be no assurance that the application of environmental and health and safety laws will not require us to incur significant expenditures. We are also regulated under a number of international, federal, state and local laws regarding recycling, product packaging and product content requirements. The environmental, product content/disposal and recycling laws are gradually becoming more stringent and may cause us to incur significant expenditures in the future.

[0001633978-17-000037:notes:64]
Legal Proceedings

[0001633978-17-000037:notes:65]
We are subject to a variety of claims and suits that arise from time to time in the ordinary course of our business. While management currently believes that resolving claims against us, individually or in the aggregate, will not have a material adverse impact on our financial position, results of operations or statements of cash flows, these matters are subject to inherent uncertainties and management's view of these matters may change in the future. Were an unfavorable final outcome to occur, there exists the possibility of a material adverse impact on our financial position, results of operations or cash flows for the period in which the effect becomes reasonably estimable.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001633978-17-000037:notes:66]
[same as prior period, unchanged from 0001633978-17-000006:notes:53]

[0001633978-17-000037:notes:67]
[same as prior period, unchanged from 0001633978-17-000006:notes:54]

[0001633978-17-000037:notes:68]
As of April 1, 2017 and July 2, 2016, balances for the components of accumulated other comprehensive income were as follows (in millions):

[0001633978-17-000037:notes:69]
|  | Foreign currency translation adjustments |  | Defined benefit obligation, net of tax |  | Total |
| Beginning balance as of July 2, 2016 | $ | 11.7 |  |  | $ | (2.3 | ) |  | $ | 9.4 |  |
| Other comprehensive loss | (2.7 | ) |  | — |  |  | (2.7 | ) |
| Ending balance as of April 1, 2017 | $ | 9.0 |  |  | $ | (2.3 | ) |  | $ | 6.7 |  |

[0001633978-17-000037:notes:70]
The Company evaluates the assumptions over fair value of defined benefit obligation annually and makes changes as necessary.


## us-gaap:ConvertibleDebtTableTextBlock

[0001633978-17-000037:notes:71]
As of April 1, 2017, the Notes consisted of the following (in millions):

[0001633978-17-000037:notes:72]
| Liability component: | April 1, 2017 |
| Principal | $ | 450.0 |  |
| Unamortized debt discount | (136.6 | ) |
| Net carrying amount of the liability component | $ | 313.4 |  |
| Carrying amount of the embedded derivative liability | $ | 168.6 |  |


## us-gaap:DebtDisclosureTextBlock

[0001633978-17-000037:notes:73]
Note 9. Convertible Senior Notes

[0001633978-17-000037:notes:74]
On March 8, 2017, the Company issued $450.0 million aggregate principal amount of 0.25% Convertible Senior Notes due 2024 (the “Notes”), in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act of 1933, as amended (the “Securities Act”). The Notes are governed by an indenture between the Company, as the issuer, and U.S. Bank National Association, as trustee (the “Indenture”).  The Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by the Company.

[0001633978-17-000037:notes:75]
The Notes will bear interest at a rate of 0.25% per year.  Interest on the Notes is payable semi-annually in arrears on March 15 and September 15 of each year, beginning on September 15, 2017. The Notes will mature on March 15, 2024, unless earlier repurchased by the Company or converted pursuant to their terms.

[0001633978-17-000037:notes:76]
The initial conversion rate of the Notes is 16.4965 shares of common stock per $1,000 principal amount of Notes, which is equivalent to an initial conversion price of approximately $60.62 per share, a 132.5% premium to the fair market value at the date of issuance. Prior to the close of business on the business day immediately preceding December 15, 2023, the Notes will be convertible only under the following circumstances: (1) during any fiscal quarter commencing after July 1, 2017 (and only during such fiscal quarter), if the last reported sale price of the Company’s common stock for at least 20 trading days (whether or not consecutive) during the period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price on each applicable trading day; (2) during the five consecutive business day period after any five consecutive trading day period (the “measurement period”) in which the trading price per $1,000 principal amount of notes for each trading day of such measurement period was less than 98% of the product of the last reported sale price of the Company’s common stock and the applicable conversion rate on each such trading day; or (3) upon the occurrence of specified corporate events. On or after December 15, 2023 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their notes at any time. In addition, upon the occurrence of a make-whole fundamental change, the Company will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert its Notes in connection with such make-whole fundamental change.

[0001633978-17-000037:notes:77]
Until such time as the Company satisfies the Tax Matters Agreement settlement condition (“TMA settlement condition”, as described below), the Company is required to satisfy its conversion obligation solely in cash.  However, if the Company has satisfied the TMA share settlement condition, the Company may satisfy its conversion obligation in cash, shares of the Company’s common stock or a combination of cash and shares of the Company’s common stock, at the Company’s election.

[0001633978-17-000037:notes:78]
The TMA settlement condition can be met by the Company either receiving (i) an opinion of a nationally recognized accounting firm selected by the Company and Viavi by mutual consent to the effect that the issuance of the Notes and the shares of Common Stock upon conversion of the Notes (assuming for each such purpose that Physical Settlement applies and the maximum number of Additional Shares have been added to the Conversion Rate) does not result in the imposition or incurrence of certain taxes upon Viavi, the Company, their respective Affiliates or any third party to which any of Viavi, the Company or their respective Affiliates is or may become liable in connection with the failure of the Separation to qualify as a transaction in which no income, gain or loss is recognized under Section 355 and Section 368(A)(1)(D) of the Internal Revenue Code of 1986, as amended (the “Code”) (including any tax resulting from the application of Section 355(d) or Section 355(e) of the Code to the Separation but only to the extent such tax is not reduced by a tax asset) or (ii) the consent of Viavi to the issuance of the Notes and the shares of Common Stock upon conversion of the Notes (assuming for each such purpose that Physical Settlement applies and the maximum number of Additional Shares have been added to the Conversion Rate), in each case, in a manner that the Company has determined satisfies the requirements of the Tax Matters Agreement with Viavi. All capitalized terms not previously defined have the definitions set forth in the Indenture.

[0001633978-17-000037:notes:79]
The Company may not redeem the Notes prior to their maturity date and no sinking fund is provided for the Notes. Upon the occurrence of a fundamental change, holders may require the Company to repurchase all or a portion of their Notes for cash at a price equal to 100% of the principal amount of the Notes to be repurchased, plus any accrued and unpaid interest.

[0001633978-17-000037:notes:80]
The Company considered the features embedded in the notes other than the conversion feature, including the holders' put feature, the Company's call feature, and the make-whole feature, and concluded that they are not required to be bifurcated and accounted for separately from the host debt instrument.

[0001633978-17-000037:notes:81]
Because the Company can only settle the notes in cash until the TMA settlement condition is met, the Company determined that the conversion feature meets the definition of a derivative liability.  The Company separated the derivative liability from the host debt instrument based on the fair value of the derivative liability. As of the issuance date, March 8, 2017, the derivative liability fair value of $129.9 million was calculated using the binomial valuation approach. The residual principal amount of the notes of $320.1 million before issuance costs was allocated to the debt component. The Company incurred approximately $7.7 million in transaction costs in connection with the issuance of the notes. These costs were allocated to the debt component and recognized as a debt discount. The Company amortizes the debt discount, including both the initial value of the derivative liability and the transaction costs, over the term of the Notes using the effective interest method. The effective interest rate of the Notes is 5.4% per year. As of April 1, 2017, the remaining debt discount amortization period was 83 months.

[0001633978-17-000037:notes:82]
The carrying value of the derivative liability related to the Notes as of April 1, 2017 was $168.6 million. Refer to "Note 10. Derivative Liabilities".

[0001633978-17-000037:notes:83]
The following table sets forth interest expense information related to the 2024 Notes:

[0001633978-17-000037:notes:84]
|  | Three Months Ended |  | Nine Months Ended |
| (in millions, except percentages) | April 1, 2017 |  | April 2, 2016 |  | April 1, 2017 |  | April 2, 2016 |
| Contractual interest expense | $ | 0.1 |  |  | — |  |  | $ | 0.1 |  |  | — |  |
| Amortization of the debt discount | 1.0 |  |  | — |  |  | 1.0 |  |  | — |  |
| Total interest cost | $ | 1.1 |  |  | — |  |  | $ | 1.1 |  |  | — |  |
| Effective interest rate on the liability component | 5.4 | % |  | — | % |  | 5.4 | % |  | — | % |

[0001633978-17-000037:notes:85]
The Notes  have no impact to diluted earnings per share during the three and nine months ended April 1, 2017, as the Company has to settle the Notes in cash until the TMA settlement condition is met. If the TMA settlement condition is met, we intend to apply the treasury stock method to determine the potential dilutive effect of the Notes as a result of the Company’s intent and ability to settle the principal amount of the Notes in cash.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001633978-17-000037:notes:86]
Note 10. Derivative Liabilities

[0001633978-17-000037:notes:87]
We estimate the fair value of the embedded derivatives for the Series A Preferred Stock and Notes  using the binomial lattice model. We applied the lattice model to value the embedded derivatives using a "with-and-without method," where the value of the Series A Preferred Stock or Notes, including the embedded derivative, is defined as the "with", and the value of the Series A Preferred Stock or Notes, excluding the embedded derivative, is defined as the "without". The lattice model requires the following inputs: (i) the Company's common stock price; (ii) conversion price; (iii) term; (iv) yield; (v) recovery rate for the Series A Preferred Stock; (vi) estimated stock volatility; and (vii) risk-free rate. The fair value of the embedded derivative was determined using level 3 inputs under the fair value hierarchy (unobservable inputs). Changes in the inputs into this valuation model have a material impact in the estimated fair value of the embedded derivative. For example, a decrease (increase) in the stock price and the volatility results in a decrease (increase) in the estimated fair value of the embedded derivative. The changes in the fair value of the bifurcated embedded derivatives for the Series A Preferred Stock and Notes are primarily related to the change in the price of the Company's underlying common stock and are reflected in the consolidated statements of operations as "Unrealized loss on derivative liabilities".  Unrealized loss on derivative liabilities amounted to $56.6 million and $74.5 million for the three and nine months ended April 1, 2017, respectively, and $4.8 million and $5.0 million for the three and nine months ended April 2, 2016, respectively.

[0001633978-17-000037:notes:88]
The Company is required to reassess the fair value of contingent payments on a quarterly basis. The following table provides a reconciliation of the fair value of the embedded derivatives for the Series A Preferred Stock and Notes  measured by significant unobservable inputs (Level 3) for the three and nine months ended April 1, 2017:

[0001633978-17-000037:notes:89]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 1, 2017 |  | April 2, 2016 |  | April 1, 2017 |  | April 2, 2016 |
| (in millions) |  |  |  |  |  |  |  |  |
| Balance as of beginning of period |  | $ | 28.2 |  |  | $ | 9.9 |  |  | $ | 10.3 |  |  | $ | — |  |
| Fair value of the embedded derivative for the Series A Preferred Stock at issuance |  | — |  |  | — |  |  | — |  |  | 9.7 |  |
| Fair value of the embedded derivative for the Notes at issuance |  | 129.9 |  |  | — |  |  | 129.9 |  |  | — |  |
| Unrealized loss on the Notes derivative liability |  | 38.7 |  |  | — |  |  | 38.7 |  |  | — |  |
| Unrealized loss on the Series A Preferred Stock derivative liability |  | 17.9 |  |  | 4.8 |  |  | 35.8 |  |  | 5.0 |  |
| Balance as of end of period |  | $ | 214.7 |  |  | $ | 14.7 |  |  | $ | 214.7 |  |  | $ | 14.7 |  |

[0001633978-17-000037:notes:90]
The following table summarizes the assumptions used to determine the fair value of the embedded derivative for the Notes at the issuance date and as of April 1, 2017:

[0001633978-17-000037:notes:91]
|  |  | April 1, 2017 |  | March 8, 2017 |
| Stock price |  | $ | 53.35 |  |  | $ | 45.50 |  |
| Conversion price |  | $ | 60.60 |  |  | $ | 60.60 |  |
| Expected term (years) |  | 7 |  |  | 7 |  |
| Expected annual volatility |  | 45.0 | % |  | 45.0 | % |
| Risk-free rate |  | 2.22 | % |  | 2.40 | % |

[0001633978-17-000037:notes:92]
The following table summarizes the assumptions used to determine the fair value of the embedded derivative for Series A Preferred Stock:

[0001633978-17-000037:notes:93]
|  |  | April 1, 2017 |  | July 2, 2016 |
| Stock price |  | $ | 53.35 |  |  | $ | 23.65 |  |
| Conversion price |  | $ | 24.63 |  |  | $ | 24.63 |  |
| Expected term (years) |  | 3.36 |  |  | 4.11 |  |
| Expected annual volatility |  | 45.0 | % |  | 40.0 | % |
| Risk-free rate |  | 1.58 | % |  | 0.96 | % |
| Preferred yield |  | 8.13 | % |  | 8.84 | % |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001633978-17-000037:notes:94]
Note 14. Stock-Based Compensation and Stock Plans

[0001633978-17-000037:notes:95]
[same as prior period, unchanged from 0001633978-17-000006:notes:64]

[0001633978-17-000037:notes:96]
[same as prior period, unchanged from 0001633978-17-000006:notes:65]

[0001633978-17-000037:notes:97]
On June 23, 2015, the board of directors of JDSU approved, and subsequently, our sole stockholder adopted, the 2015 Equity Incentive Plan (the "2015 Plan") under which 8.5 million shares of our Common Stock were authorized for issuance. The 2015 Plan was ratified by the Company’s board of directors on July 31, 2015.  In connection with our Separation from JDSU on August 1, 2015, outstanding JDSU equity-based awards, held by employees continuing employment with the Company after the Separation, were converted into equity-based awards under the 2015 Plan, reducing the number of shares remaining available for grant under the 2015 Plan.  As of immediately following our Separation from JDSU, 2.1 million shares of our Common Stock were subject to outstanding equity-based awards under the 2015 Plan that were converted from JDSU equity-based awards.

[0001633978-17-000037:notes:98]
[same as prior period, unchanged from 0001633978-17-000006:notes:67]

[0001633978-17-000037:notes:99]
As of April 1, 2017, the Company had 2.6 million stock options, performance stock units, restricted stock awards, and restricted stock units outstanding under the 2015 Plan. Performance stock units, restricted stock awards, and restricted stock units are performance-based, time-based or a combination of both and are expected to vest over one to four years. The fair value of the time-based performance stock units, restricted stock awards, or restricted stock units is based on the closing market price of the Company’s common stock on the date of award.

[0001633978-17-000037:notes:100]
The exercise price for stock options is equal to the fair value of the underlying stock at the date of grant. The Company issues new shares of common stock upon exercise of stock options. Options generally become exercisable over a three-year or four-year period and, if not exercised, expire from five to ten years after the date of grant. As of April 1, 2017, 6.6 million shares of common stock under the 2015 Plan were available for grant.

[0001633978-17-000037:notes:101]
[same as prior period, unchanged from 0001633978-17-000006:notes:70]

[0001633978-17-000037:notes:102]
On June 23, 2015, the board of directors of JDSU approved, and subsequently, our sole stockholder adopted, the 2015 Employee Stock Purchase Plan (the “2015 Purchase Plan”) under which 3.0 million shares of our Common Stock were authorized for issuance. The 2015 Purchase Plan was ratified by our board of directors on July 31, 2015. The 2015 Purchase Plan provides eligible employees with the opportunity to acquire an ownership interest in the Company through periodic payroll deductions and provides a 15% purchase price discount as well as a six-month look-back period. The 2015 Purchase Plan is structured as a qualified employee stock purchase plan under Section 423 of the Code. However, the 2015 Purchase Plan is not intended to be a qualified pension, profit sharing or stock bonus plan under Section 401(a) of the Internal Revenue Code of 1986 and is not subject to the provisions of the Employee Retirement Income Security Act of 1974. The 2015 Purchase Plan will terminate upon the date on which all shares available for issuance have been sold. Of the 3.0 million shares authorized under the 2015 Purchase Plan, 2.6 million shares remained available for issuance as of April 1, 2017.

[0001633978-17-000037:notes:103]
[same as prior period, unchanged from 0001633978-17-000006:notes:72]

[0001633978-17-000037:notes:104]
Each restricted stock unit (“RSU”) granted under the 2015 Plan is a bookkeeping entry representing an amount equal to the fair market value of one share. RSUs result in a payment to a holders if any performance goals or other vesting criteria are achieved or the awards otherwise vest.  The administrator determines in its sole discretion whether an award will be settled in stock, cash, or a combination of both.

[0001633978-17-000037:notes:105]
[same as prior period, unchanged from 0001633978-17-000006:notes:74]

[0001633978-17-000037:notes:106]
[same as prior period, unchanged from 0001633978-17-000006:notes:75]

[0001633978-17-000037:notes:107]
Restricted stock awards (“RSAs”) under the 2015 Plan are grants of shares of our common stock that are subject to various restrictions, including restrictions on transferability and forfeiture provisions. Restricted stock awards are expected to vest over one to four years, and the shares acquired may not be transferred by the holder until the vesting conditions (if any) are satisfied.

[0001633978-17-000037:notes:108]
[same as prior period, unchanged from 0001633978-17-000006:notes:77]

[0001633978-17-000037:notes:109]
The impact on our results of operations of recording stock-based compensation by function for the three and nine months ended April 1, 2017 and April 2, 2016 was as follows (in millions):

[0001633978-17-000037:notes:110]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 1, 2017 |  | April 2, 2016 |  | April 1, 2017 |  | April 2, 2016 |
| Cost of sales | $ | 1.9 |  |  | $ | 2.2 |  |  | $ | 6.0 |  |  | $ | 4.9 |  |
| Research and development | 3.0 |  |  | 2.5 |  |  | 8.8 |  |  | 6.7 |  |
| Selling, general and administrative | 3.2 |  |  | 3.5 |  |  | 10.2 |  |  | 9.4 |  |
|  | $ | 8.1 |  |  | $ | 8.2 |  |  | $ | 25.0 |  |  | $ | 21.0 |  |

[0001633978-17-000037:notes:111]
Approximately $1.2 million and $1.2 million of stock-based compensation was capitalized to inventory as of April 1, 2017 and July 2, 2016, respectively. The table above includes allocated stock-based compensation from Viavi of $0.5 million for the nine months ended April 2, 2016. There were no allocations to stock-based compensation from Viavi during the nine months ended April 1, 2017. Refer to "Note 3. Related Party Transactions" in the Notes to Unaudited Consolidated Financial Statements.

[0001633978-17-000037:notes:112]
[same as prior period, unchanged from 0001633978-17-000006:notes:81]

[0001633978-17-000037:notes:113]
We granted no stock options during the three and nine months ended April 1, 2017. The total intrinsic value of options exercised by our employees during the three and nine months ended April 1, 2017 was $1.0 million and $4.6 million, respectively. The total intrinsic value of options exercised by our employees during the three and nine months ended April 2, 2016 was $0.6 million and $0.7 million, respectively.

[0001633978-17-000037:notes:114]
In connection with these exercises, the tax benefit realized during the three and nine months ended April 1, 2017 was $2.3 million and $5.2 million, respectively. For the three and nine months ended April 2, 2016 there was no tax benefit related to options exercised.

[0001633978-17-000037:notes:115]
As of April 1, 2017, $50.2 million of stock-based compensation cost related to RSUs, performance stock units (“PSUs”), and RSAs granted to our employees remains to be amortized. That cost is expected to be recognized over an estimated amortization period of 2 years.

[0001633978-17-000037:notes:116]
The following table summarizes our stock option, RSA, and RSU activities during the three and nine months ended April 1, 2017 (amount in millions except per share amounts):

[0001633978-17-000037:notes:117]
|  | Available for Grant |  | Options Outstanding |  | Restricted Stock Units/Awards Outstanding |
|  |  | Number of Shares |  | Weighted-Average Exercise Price |  | Number of Shares (PSU) |  | Number of Shares(RSU/RSA) |  | Weighted-Average Grant Date Fair Value |
| Balances as of July 2, 2016 | 4.7 |  |  | 0.3 |  |  | $ | 17.83 |  |  | 0.1 |  |  | 2.5 |  |  | $ | 21.04 |  |
| Authorized | 3.0 |  |  |  |  |  |  |  |  |  |  |  |
| Granted | (1.3 | ) |  | — |  |  | — |  |  | — |  |  | 1.3 |  |  | 34.09 |  |
| Exercised / Vested | — |  |  | (0.2 | ) |  | 14.61 |  |  | (0.1 | ) |  | (1.1 | ) |  | 21.30 |  |
| Canceled | 0.2 |  |  | — |  |  | — |  |  | — |  |  | (0.2 | ) |  | 23.10 |  |
| Balances as of April 1, 2017 | 6.6 |  |  | 0.1 |  |  | 28.33 |  |  | — |  |  | 2.5 |  |  | 27.70 |  |
| Vested and expected to vest |  |  | 0.1 |  |  | $ | 28.33 |  |  | — |  |  | 2.3 |  |  | $ | 27.62 |  |

[0001633978-17-000037:notes:118]
[same as prior period, unchanged from 0001633978-17-000006:notes:87]

[0001633978-17-000037:notes:119]
The ESPP expense we recorded for the three and nine months ended April 1, 2017 was $0.7 million and $2.0 million, respectively. The expense related to the plan is recorded on a straight-line basis over the relevant subscription period. During the three and nine months ended April 1, 2017, there were 188,864 shares issued to employees through the ESPP program in one offering period from May 16, 2016 to November 15, 2016.

[0001633978-17-000037:notes:120]
The first offering period for 2015 Purchase Plan was from November 17, 2015 to May 15, 2016. The ESPP expense recorded for the three and nine months ended April 2, 2016 amounted to $0.6 million and $0.8 million, respectively.


## us-gaap:EarningsPerShareTextBlock

[0001633978-17-000037:notes:121]
[same as prior period, unchanged from 0001633978-17-000006:notes:89]

[0001633978-17-000037:notes:122]
[same as prior period, unchanged from 0001633978-17-000006:notes:90]

[0001633978-17-000037:notes:123]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 1, 2017 |  | April 2, 2016 |  | April 1, 2017 |  | April 2, 2016 |
| Numerator: |  |  |  |  |  |  |  |  |  |  |
| Net loss | $ | (56.0 | ) |  | $ | (7.6 | ) |  | $ | (47.6 | ) |  | $ | (5.0 | ) |
| Less: Cumulative dividends on Series A Preferred Stock | (0.2 | ) |  | (0.3 | ) |  | (0.6 | ) |  | (0.6 | ) |
| Less: Accretion of Series A Preferred Stock | — |  |  | — |  |  | — |  |  | (11.7 | ) |
| Net loss attributable to common stockholders | $ | (56.2 | ) |  | $ | (7.9 | ) |  | $ | (48.2 | ) |  | $ | (17.3 | ) |
| Denominator: |  |  |  |  |  |  |  |
| Weighted-average number of common shares outstanding |  |  |  |  |  |  |  |
| Basic | 61.0 |  |  | 59.2 |  |  | 60.4 |  |  | 59.0 |  |
| Diluted | 61.0 |  |  | 59.2 |  |  | 60.4 |  |  | 59.0 |  |
| Net loss per share attributable to common stockholders: |  |  |  |  |  |  |  |
| Basic | $ | (0.92 | ) |  | $ | (0.13 | ) |  | $ | (0.80 | ) |  | $ | (0.29 | ) |
| Diluted | $ | (0.92 | ) |  | $ | (0.13 | ) |  | $ | (0.80 | ) |  | $ | (0.29 | ) |

[0001633978-17-000037:notes:124]
On August 1, 2015, JDSU distributed 47.1 million shares, or 80.1% of the outstanding shares of the Company's common stock to existing holders of JDSU common stock. The weighted average number of common stock outstanding is calculated as the number of shares of common stock outstanding immediately following the Separation through April 2, 2016, and the weighted average number of shares outstanding following the Separation through April 1, 2017. Diluted earnings per share is calculated by dividing net income attributable to common stockholders for the period by the weighted average number of shares of common stock and potentially dilutive common stock outstanding for the period beginning after the Separation.

[0001633978-17-000037:notes:125]
[same as prior period, unchanged from 0001633978-17-000006:notes:93]

[0001633978-17-000037:notes:126]
[same as prior period, unchanged from 0001633978-17-000006:notes:94]

[0001633978-17-000037:notes:127]
The Senior Convertible Notes have no impact to diluted earnings per share during the three and nine months ended April 1, 2017, as the Company has to settle the Notes in cash until the Tax Matters Agreement settlement condition is met. If the TMA settlement condition is met, we intend to apply the treasury stock method to determine the potential dilutive effect of the Notes as a result of the Company’s intent and ability to settle the principle amount of the Notes in Cash. Refer to "Note 9. Convertible Senior Notes" for further discussion.


## us-gaap:FiniteLivedIntangibleAssetsAmortizationExpenseTableTextBlock

[0001633978-17-000037:notes:128]
[same as prior period, unchanged from 0001633978-17-000006:notes:95]

[0001633978-17-000037:notes:129]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 1, 2017 |  | April 2, 2016 |  | April 1, 2017 |  | April 2, 2016 |
| Cost of sales | $ | 1.7 |  |  | $ | 1.7 |  |  | $ | 5.1 |  |  | $ | 5.1 |  |
| Operating expense | 0.1 |  |  | 0.1 |  |  | 0.3 |  |  | 0.3 |  |
| Total | $ | 1.8 |  |  | $ | 1.8 |  |  | $ | 5.4 |  |  | $ | 5.4 |  |


## us-gaap:GoodwillDisclosureTextBlock

[0001633978-17-000037:notes:130]
Note 11. Goodwill and Other Intangible Assets

[0001633978-17-000037:notes:131]
[same as prior period, unchanged from 0001633978-17-000006:notes:98]

[0001633978-17-000037:notes:132]
The following table presents the changes in goodwill by operating segments during the nine months ended April 1, 2017 (in millions):

[0001633978-17-000037:notes:133]
|  |  | Optical Communications |  | Commercial Lasers |  | Total |
| Balance as of July 2, 2016 | $ | — |  |  | $ | 5.4 |  |  | $ | 5.4 |  |
|  | Addition | 5.6 |  |  | — |  |  | 5.6 |  |
|  | Currency translation | — |  |  | (0.2 | ) |  | (0.2 | ) |
| Balance as of April 1, 2017 | $ | 5.6 |  |  | $ | 5.2 |  |  | $ | 10.8 |  |

[0001633978-17-000037:notes:134]
[same as prior period, unchanged from 0001633978-17-000006:notes:101]

[0001633978-17-000037:notes:135]
We review goodwill for impairment during the fourth quarter of each fiscal year or more frequently if events or circumstances indicate that an impairment loss may have occurred. In the fourth quarter of fiscal 2016, we completed the annual impairment test of goodwill, which indicated there was no goodwill impairment. During the three and nine months ended April 1, 2017, there have been no events or circumstances that have required us to perform an interim assessment of goodwill for impairment.

[0001633978-17-000037:notes:136]
[same as prior period, unchanged from 0001633978-17-000006:notes:103]

[0001633978-17-000037:notes:137]
We allocated acquired developed technology and other intangibles resulting from past acquisitions to our Commercial Lasers operating segment.

[0001633978-17-000037:notes:138]
In the fiscal third quarter of 2017, we completed the acquisition with $2.4 million acquired developed technology which was allocated to Optical Communications operating segment. The following tables present details of our acquired developed technology and other intangibles (in millions):

[0001633978-17-000037:notes:139]
| As of April 1, 2017 | Gross Carrying Amount |  | Accumulated Amortization |  | Net |
| Acquired developed technology | $ | 105.2 |  |  | $ | (93.9 | ) |  | $ | 11.3 |  |
| Other | 9.4 |  |  | (9.2 | ) |  | 0.2 |  |
| Total Intangibles | $ | 114.6 |  |  | $ | (103.1 | ) |  | $ | 11.5 |  |

[0001633978-17-000037:notes:140]
[same as prior period, unchanged from 0001633978-17-000006:notes:106]

[0001633978-17-000037:notes:141]
During the three and nine months ended April 1, 2017, the Company recorded $1.8 million and $5.4 million, respectively, of amortization related to acquired developed technology and other intangibles.

[0001633978-17-000037:notes:142]
During the three and nine months ended April 2, 2016, the Company recorded $1.8 million and $5.4 million, respectively, of amortization expense relating to acquired developed technology and other intangibles.

[0001633978-17-000037:notes:143]
Based on the carrying amount of acquired developed technology and other intangibles as of April 1, 2017, and assuming no future impairment of the underlying assets, the estimated future amortization is as follows (in millions):

[0001633978-17-000037:notes:144]
| Remainder of 2017 | $ | 1.8 |  |
| 2018 | 3.2 |  |
| 2019 | 3.0 |  |
| 2020 | 2.5 |  |
| Thereafter | 1.0 |  |
| Total amortization | $ | 11.5 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001633978-17-000037:notes:145]
Note 13. Income Taxes

[0001633978-17-000037:notes:146]
The effective tax rate was (26.1)% and (47.8)% for the three and nine months ended April 1, 2017, respectively.  The amounts differ from the statutory rate of 35.0% primarily due to the non-deductible unrealized loss from the embedded derivatives for the Series A Preferred Stock and the Notes, non-deductible stock-based compensation and partially offset by foreign rate differential, R&D tax credits and the utilization of U.S. deferred tax assets that were subject to a full valuation allowance.

[0001633978-17-000037:notes:147]
The Company recorded a tax provision of $11.6 million and $15.4 million for the three and nine months ended April 1, 2017, respectively. The Company recorded a tax provision of $0.1 million and $0.3 million for the three and nine months ended April 2, 2016, respectively. The quarterly provision for income taxes is based on the estimated annual effective tax rate, plus any discrete items for the respective year. The Company updates its estimated annual effective tax rate at the end of each quarterly period and which takes into account estimates of annual pre-tax income, the geographical mix of pre-tax income, and permanent book-to-tax differences.

[0001633978-17-000037:notes:148]
The Company’s tax provision for both the three and nine months ended April 1, 2017, was primarily due to the discrete impact of the non-deductible unrealized loss from the embedded derivatives for the Series A Preferred Stock and the Notes, non-deductible stock-based compensation and partially offset by foreign rate differential, R&D tax credits and the utilization of U.S. deferred tax assets that were subject to a full valuation allowance.

[0001633978-17-000037:notes:149]
The Company’s tax provision for both the three and nine months ended April 2, 2016 was primarily attributable to the utilization of U.S. tax attributes that were subject to a full valuation allowance, and certain Canadian tax incentives.

[0001633978-17-000037:notes:150]
The Company’s net deferred tax assets relate predominantly to the Canadian tax jurisdiction for which it has recognized a partial valuation allowance against such deferred tax assets. The Company weighed all available positive and negative evidence and determined that due to the limited carryover period of certain tax attributes in Canada, there is a continued need for a partial valuation allowance against these deferred tax assets as of April 1, 2017. The change in the Company’s valuation allowance position in the future may have a material impact to net income in the period such adjustment is made.

[0001633978-17-000037:notes:151]
The Company also evaluates the ability to realize its U.S. net deferred tax assets based upon all available evidence, both positive and negative, on a quarterly basis. The realization of net deferred tax assets is dependent on the Company’s ability to generate sufficient future taxable income during periods prior to the expiration of tax attributes to fully utilize these assets. The Company weighed all available positive and negative evidence and determined that due to cumulative losses in the United States, there is a continued need for a full valuation allowance against the U.S. deferred tax assets as of April 1, 2017.

[0001633978-17-000037:notes:152]
As of April 1, 2017 and April 2, 2016, the Company has $6.2 million and $0.1 million, respectively, in its liability for unrecognized tax benefits, which, if recognized, would affect the effective tax rate. The Company is routinely subject to various federal, state and foreign audits by taxing authorities. The timing for the resolution and closure of tax audits is highly unpredictable. Given the uncertainty, it is reasonably possible that certain tax audits may be concluded within the next 12 months that could materially impact the balance of our gross unrecognized tax benefits. The estimated impact to tax expense and net income from the resolution and closure of tax exams is not expected to be significant within the next 12 months.


## us-gaap:MinorityInterestDisclosureTextBlock

[0001633978-17-000037:notes:153]
Note 8. Non-Controlling Interest Redeemable Convertible Preferred Stock

[0001633978-17-000037:notes:154]
[same as prior period, unchanged from 0001633978-17-000006:notes:121]

[0001633978-17-000037:notes:155]
The Series A Preferred Stock is redeemable at the option of Amada after five years and classified as non-controlling interest redeemable convertible preferred stock in our consolidated balance sheet. The Series A Preferred Stock is measured at its redemption value.  The Series A Preferred Stock value of $35.8 million as of December 26, 2015 has not changed from prior periods. The Series A Preferred Stock conversion feature is bifurcated from the Series A Preferred Stock and accounted for separately as a derivative liability.  The derivative liability is measured at fair value each reporting period with the change in fair value recorded in the consolidated statements of operations. See "Note 10. Derivative Liabilities" in the Notes to Unaudited Consolidated Financial Statements regarding the derivative liability for the Series A Preferred Stock.

[0001633978-17-000037:notes:156]
[same as prior period, unchanged from 0001633978-17-000006:notes:123]

[0001633978-17-000037:notes:157]
[same as prior period, unchanged from 0001633978-17-000006:notes:124]

[0001633978-17-000037:notes:158]
[same as prior period, unchanged from 0001633978-17-000006:notes:125]

[0001633978-17-000037:notes:159]
[same as prior period, unchanged from 0001633978-17-000006:notes:126]

[0001633978-17-000037:notes:160]
[same as prior period, unchanged from 0001633978-17-000006:notes:127]

[0001633978-17-000037:notes:161]
[same as prior period, unchanged from 0001633978-17-000006:notes:128]

[0001633978-17-000037:notes:162]
[same as prior period, unchanged from 0001633978-17-000006:notes:129]

[0001633978-17-000037:notes:163]
[same as prior period, unchanged from 0001633978-17-000006:notes:130]

[0001633978-17-000037:notes:164]
[same as prior period, unchanged from 0001633978-17-000006:notes:131]

[0001633978-17-000037:notes:165]
[same as prior period, unchanged from 0001633978-17-000006:notes:132]

[0001633978-17-000037:notes:166]
[same as prior period, unchanged from 0001633978-17-000006:notes:133]

[0001633978-17-000037:notes:167]
[same as prior period, unchanged from 0001633978-17-000006:notes:134]

[0001633978-17-000037:notes:168]
[same as prior period, unchanged from 0001633978-17-000006:notes:135]

[0001633978-17-000037:notes:169]
The accrued dividends as of April 1, 2017 and July 2, 2016 are $0.2 million and $0.2 million, respectively. Dividends paid were $0.6 million and $0.3 million for the nine months ended April 1, 2017 and April 2, 2016, respectively.

[0001633978-17-000037:notes:170]
[same as prior period, unchanged from 0001633978-17-000006:notes:137]

[0001633978-17-000037:notes:171]
[same as prior period, unchanged from 0001633978-17-000006:notes:138]

[0001633978-17-000037:notes:172]
[same as prior period, unchanged from 0001633978-17-000006:notes:139]

[0001633978-17-000037:notes:173]
[same as prior period, unchanged from 0001633978-17-000006:notes:140]

[0001633978-17-000037:notes:174]
[same as prior period, unchanged from 0001633978-17-000006:notes:141]


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001633978-17-000037:notes:175]
In October 2016, FASB issued ASU 2016-16, Accounting for Income Taxes: Intra-Entity Asset Transfers of Assets other than Inventory. The new guidance removes the prohibition in ASC 740 against the immediate recognition of the current and deferred income tax effects of intra-entity transfers of assets other than inventory. The new guidance will be effective for us in our first quarter of fiscal 2019. We are currently evaluating the impact of our pending adoption of ASU 2016-16 on our consolidated financial statements.

[0001633978-17-000037:notes:176]
In August 2016, FASB issued ASU 2016-15, Statement of Cash Flows (Topic 230): Classification of Certain Cash Receipts and Cash Payments, which clarifies how companies present and classify certain cash receipts and cash payments in the statement of cash flows. ASU 2016-15 is effective for us in our first quarter of fiscal 2019 and earlier adoption is permitted. We are currently evaluating the impact of our pending adoption of ASU 2016-15 on our consolidated financial statements.

[0001633978-17-000037:notes:177]
In March 2016, FASB issued ASU 2016-09, Stock Compensation ASU 718 - Improvements to Employee Share-Based Payment Accounting. This guidance simplifies various aspects related to how share-based payments are accounted for and presented in the financial statements. This guidance is effective for fiscal years, and interim periods within those years, beginning after December 15, 2016. The Company will adopt this standard in fiscal year 2018. The Company has not yet determined the effect that the adoption of this standard will have on its consolidated financial statements or results of operations.

[0001633978-17-000037:notes:178]
In February 2016, FASB issued ASU 2016-02, Leases. The new guidance generally requires an entity to recognize on its balance sheet operating and financing lease liabilities and corresponding right-of-use assets. The standard is effective for us in our first quarter of fiscal 2020 and early adoption is permitted. The Company is currently evaluating the impact of the adoption of ASU 2016-02 on its consolidated financial statements.

[0001633978-17-000037:notes:179]
In January 2016, FASB issued ASU 2016-01, Recognition and Measurement of Financial Assets and Financial Liabilities (Subtopic 825-10) (“ASU 2016-01”). The new standard provides guidance for the recognition, measurement, presentation and disclosure of financial instruments. This guidance is effective for annual and interim periods beginning after December 15, 2017 and early adoption is not permitted. The Company is currently evaluating the impact of the adoption of ASU 2016-01 on its consolidated financial statements.

[0001633978-17-000037:notes:180]
In April 2015, FASB issued ASU 2015-04 Compensation-Retirement Benefits to provide a practical expedient that permits the entity to measure defined benefit plan assets and obligations using the month-end that is closest to the entity’s fiscal year-end and apply that practical expedient consistently from year to year. The Company adopted this guidance effective first quarter of fiscal 2017 on a prospective basis. No prior periods were retrospectively adjusted. The Company does not believe this standard will have a material impact on its consolidated financial statements or the related footnote disclosures. The change will not have a material impact on its consolidated financial position, results of operations and cash flows.

[0001633978-17-000037:notes:181]
In May 2014, FASB issued ASU 2014-09, Revenue from Contracts with Customers, which amended the existing accounting standards for revenue recognition. ASU 2014-09 establishes principles for recognizing revenue upon the transfer of promised goods or services to customers, in an amount that reflects the consideration expected to be received in exchange for those goods or services. The new standard requires that reporting companies disclose the nature, amount, timing and uncertainty of revenue and cash flows arising from contracts with customers. On July 9, 2015, FASB agreed to delay the effective date by one year and, accordingly, the new standard is effective for the Company beginning in the first quarter of fiscal 2018. Early adoption is permitted, but not before the original effective date of the standard. The new standard is required to be applied retrospectively to each prior reporting period presented or retrospectively with the cumulative effect of initially applying it recognized at the date of initial application. The standard is effective for us for our first quarter of fiscal 2019.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001633978-17-000037:notes:182]
Note 3. Related Party Transactions

[0001633978-17-000037:notes:183]
Transactions with Viavi

[0001633978-17-000037:notes:184]
During the three and nine months ended April 1, 2017, the Company recognized revenue of $1.0 million and $2.5 million, respectively, from products sold to Viavi. During the three and nine months ended April 2, 2016, the Company recognized revenue of $0.9 million and $2.4 million, respectively, for products sold to Viavi.

[0001633978-17-000037:notes:185]
During the three and nine months ended April 1, 2017, the Company recorded $0.1 million and $0.5 million, respectively, in research and development cost reimbursement from Viavi. For the three and nine months ended April 2, 2016, the Company recorded $0.5 million and $1.7 million, respectively, in research and development cost reimbursement.

[0001633978-17-000037:notes:186]
During the three and nine months ended April 1, 2017, the Company recorded $0.2 million and $0.6 million, respectively, in sublease rental income from Viavi. For the three and nine months ended April 2, 2016, the Company recorded and $0.2 million and $0.5 million, respectively, in sublease rental income from Viavi.

[0001633978-17-000037:notes:187]
As of April 1, 2017 and July 2, 2016, the Company had $0.5 million and $1.1 million, respectively, in trade accounts receivable due from Viavi. The Company did not have any trade payables due to Viavi as of  April 1, 2017 or July 2, 2016.

[0001633978-17-000037:notes:188]
As of April 1, 2017, the Company had $0.1 million in other payables due to Viavi. As of July 2, 2016, the Company had $2.0 million in other receivables from Viavi. The Company had no other receivables from Viavi as of April 1, 2017 or other payables due to Viavi as of July 2, 2016.

[0001633978-17-000037:notes:189]
On July 31, 2015, the Company also entered into the following agreements with Viavi:

[0001633978-17-000037:notes:190]
| a) | Contribution Agreement which identified the assets transferred, the liabilities assumed and the contracts assigned and which provided for when and how these transfers, assumptions and assignments would occur. |

[0001633978-17-000037:notes:191]
| b) | Separation and Distribution Agreement which governs the Separation of the Lumentum business and other matters related to Lumentum’s relationship with Viavi. |

[0001633978-17-000037:notes:192]
| c) | Tax Matters Agreement which governs the respective rights, responsibilities and obligations of Lumentum and Viavi with respect to tax liabilities and benefits, attributes, proceedings, returns and certain other tax matters. |

[0001633978-17-000037:notes:193]
| d) | Employee Matters Agreement which governs the compensation and employee benefit obligations with respect to the current and former employees of Lumentum and Viavi, the treatment of equity based compensation and generally allocates liabilities and responsibilities relating to employee compensation, benefit plans and programs. The Employee Matters Agreement provides that employees of Lumentum will participate in benefit plans sponsored or maintained by Lumentum. |

[0001633978-17-000037:notes:194]
| e) | Securities Purchase Agreement, which also includes Amada Holdings Co., Ltd. (“Amada”) as a party, which sets forth the terms for the sale by Viavi to Amada of shares of Series A Preferred Stock (the "Series A Preferred Stock") of Lumentum Inc., our wholly-owned subsidiary, following the Separation. |

[0001633978-17-000037:notes:195]
| f) | Intellectual Property Matters Agreement which outlines the intellectual property rights of Lumentum and Viavi following the Separation, as well as non-compete restrictions between Viavi and Lumentum. |

[0001633978-17-000037:notes:196]
Allocated Costs

[0001633978-17-000037:notes:197]
From June 28, 2015 to August 1, 2015, the effective date of the Separation, the consolidated statements of operations included the Company's direct expenses for cost of sales, research and development, sales and marketing, and administration as well as allocations of expenses arising from shared services and infrastructure provided by Viavi to the Company. These allocated expenses include costs of information technology, human resources, accounting, legal, real estate and facilities, corporate marketing, insurance, treasury and other corporate and infrastructure services. In addition, other costs allocated to the Company include restructuring and stock-based compensation related to Viavi’s corporate and shared services employees and are included in the table below. These expenses were allocated to the Company using estimates that we consider to be a reasonable reflection of the utilization of services or benefits received by our business. The allocation methods include revenue, headcount, square footage, actual consumption and usage of services and others.

[0001633978-17-000037:notes:198]
There were no allocations of expenses from Viavi for the three and nine months ended April 1, 2017, and the three months ended April 2, 2016. During the nine months ended April 2, 2016, allocated costs from Viavi included in the accompanying consolidated statements of operations were as follows (in millions):

[0001633978-17-000037:notes:199]
|  | Nine Months Ended |
|  | April 2, 2016 |
| Selling, general and administrative expenses | $ | 11.7 |  |
| Interest and other (income) expenses, net | (0.1 | ) |
| Interest expense | 0.1 |  |
| Total allocated expenses | $ | 11.7 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001633978-17-000037:notes:200]
Note 12. Restructuring and Related Charges

[0001633978-17-000037:notes:201]
We have initiated various strategic restructuring events primarily intended to reduce costs, consolidate our operations, optimize the manufacturing of our products and align our business in response to the market conditions. As of April 1, 2017 and July 2, 2016, our total restructuring accrual was $5.3 million and $5.7 million, respectively.

[0001633978-17-000037:notes:202]
During the three and nine months ended April 1, 2017, we recorded $3.1 million and $10.0 million, respectively, in restructuring and related charges in the consolidated statements of operations. Of the $3.1 million and $10.0 million charge recorded during the three months and nine months ended April 1, 2017, $0.4 million and $2.0 million, respectively, was related to severance, retention, lease termination costs, and employee benefits; and $2.7 million and $7.8 million, respectively, was related to other restructuring related charges which include relocation costs, equipment set-up costs, product qualification costs, facilities, and equipment costs to vacate facilities and consolidate operations. The timing of cash payments associated with these restructuring related charges and exit costs is dependent upon the type of restructuring charge and can extend over multiple periods.

[0001633978-17-000037:notes:203]
As of April 2, 2016, our total restructuring accrual was $3.8 million. During the three and nine months ended April 2, 2016, we recorded $1.8 million and $3.9 million, respectively, in restructuring and related charges in the consolidated statements of operations. Of the $1.8 million and $3.9 million charge recorded during the three months and nine months ended April 1, 2017, $0.4 million and $1.7 million, respectively, was related to severance, retention, lease termination costs, and employee benefits; and $1.4 million and $2.2 million, respectively, was related to other restructuring related charges which include relocation costs, equipment set-up costs, product qualification costs, facilities, and equipment costs to vacate facilities and consolidate operations. The timing of cash payments associated with these restructuring related charges and exit costs is dependent upon the type of restructuring charge and can extend over multiple periods.

[0001633978-17-000037:notes:204]
[same as prior period, unchanged from 0001633978-17-000006:notes:170]

[0001633978-17-000037:notes:205]
The adjustments to the restructuring accrual related to all of our restructuring plans described below as of April 1, 2017, were as follows (in millions):

[0001633978-17-000037:notes:206]
|  | Fiscal 2015 & earlier Restructuring Plan |  | Fiscal 2016 Restructuring Plan |  |  |
|  | Restructuring Charges |  | Exit Costs |  | Other Charges |  | Restructuring Charges |  | Total |
| Liability as of July 2, 2016 | $ | 4.5 |  |  | $ | 0.5 |  |  | $ | — |  |  | $ | 0.7 |  |  | $ | 5.7 |  |
| Charges | 2.2 |  |  | — |  |  | 7.8 |  |  | — |  |  | 10.0 |  |
| Payments | (1.8 | ) |  | (0.1 | ) |  | (7.8 | ) |  | (0.7 | ) |  | (10.4 | ) |
| Liability as of April 1, 2017 | $ | 4.9 |  |  | $ | 0.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 5.3 |  |

[0001633978-17-000037:notes:207]
As of April 1, 2017, our restructuring liability includes $5.3 million in short-term other current liabilities. Our consolidated balance sheets do not have any non-current restructuring liabilities as of April 1, 2017.

[0001633978-17-000037:notes:208]
[same as prior period, unchanged from 0001633978-17-000006:notes:174]


## us-gaap:ScheduleOfEntityWideDisclosureOnGeographicAreasLongLivedAssetsInIndividualForeignCountriesByCountryTextBlock

[0001633978-17-000037:notes:209]
[same as prior period, unchanged from 0001633978-17-000006:notes:175]

[0001633978-17-000037:notes:210]
|  | April 1, 2017 |  | July 2, 2016 |
| Property, Plant and Equipment, net |  |  |  |
| United States | $ | 85.2 |  |  | $ | 69.0 |  |
| Canada | 14.8 |  |  | 21.4 |  |
| China | 71.6 |  |  | 46.6 |  |
| Thailand | 70.9 |  |  | 43.8 |  |
| Other Asia-Pacific | 1.6 |  |  | 0.2 |  |
| EMEA | 2.5 |  |  | 2.4 |  |
| Total Property, Plant and Equipment, net | $ | 246.6 |  |  | $ | 183.4 |  |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001633978-17-000037:notes:211]
[same as prior period, unchanged from 0001633978-17-000006:notes:177]

[0001633978-17-000037:notes:212]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 1, 2017 |  | April 2, 2016 |  | April 1, 2017 |  | April 2, 2016 |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States | $ | 34.7 |  |  | 13.6 | % |  | $ | 28.8 |  |  | 12.5 | % |  | $ | 106.2 |  |  | 13.6 | % |  | $ | 91.3 |  |  | 13.8 | % |
| Mexico | 70.0 |  |  | 27.4 |  |  | 34.4 |  |  | 14.9 |  |  | 158.5 |  |  | 20.3 |  |  | 112.7 |  |  | 17.0 |  |
| Other Americas | 1.5 |  |  | 0.6 |  |  | 5.1 |  |  | 2.2 |  |  | 7.4 |  |  | 1.0 |  |  | 17.9 |  |  | 2.7 |  |
| Total Americas | $ | 106.2 |  |  | 41.6 | % |  | $ | 68.3 |  |  | 29.6 | % |  | $ | 272.1 |  |  | 34.9 | % |  | $ | 221.9 |  |  | 33.5 | % |
| Asia-Pacific: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Hong Kong | $ | 47.2 |  |  | 18.5 | % |  | $ | 67.9 |  |  | 29.5 | % |  | $ | 181.2 |  |  | 23.3 | % |  | $ | 150.5 |  |  | 22.7 | % |
| Japan | 25.9 |  |  | 10.1 |  |  | 19.8 |  |  | 8.6 |  |  | 78.5 |  |  | 10.1 |  |  | 65.8 |  |  | 10.0 |  |
| Thailand | 21.3 |  |  | 8.3 |  |  | 20.5 |  |  | 8.9 |  |  | 66.8 |  |  | 8.6 |  |  | 64.5 |  |  | 9.8 |  |
| Other Asia-Pacific | 25.1 |  |  | 9.8 |  |  | 27.0 |  |  | 11.7 |  |  | 98.0 |  |  | 12.6 |  |  | 69.3 |  |  | 10.5 |  |
| Total Asia-Pacific | $ | 119.5 |  |  | 46.7 | % |  | $ | 135.2 |  |  | 58.7 | % |  | $ | 424.5 |  |  | 54.6 | % |  | $ | 350.1 |  |  | 53.0 | % |
| EMEA | $ | 30.1 |  |  | 11.8 | % |  | $ | 26.9 |  |  | 11.7 | % |  | $ | 82.3 |  |  | 10.6 | % |  | $ | 89.3 |  |  | 13.5 | % |
| Total net revenue | $ | 255.8 |  |  |  |  | $ | 230.4 |  |  |  |  | $ | 778.9 |  |  |  |  | $ | 661.3 |  |  |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001633978-17-000037:notes:213]
[same as prior period, unchanged from 0001633978-17-000006:notes:179]

[0001633978-17-000037:notes:214]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 1, 2017 |  | April 2, 2016 |  | April 1, 2017 |  | April 2, 2016 |
| Net revenue: |  |  |  |  |  |  |  |
| OpComms | $ | 216.1 |  |  | $ | 197.2 |  |  | $ | 671.0 |  |  | $ | 560.1 |  |
| Lasers | 39.7 |  |  | 33.2 |  |  | 107.9 |  |  | 101.2 |  |
| Net revenue | $ | 255.8 |  |  | $ | 230.4 |  |  | $ | 778.9 |  |  | $ | 661.3 |  |
| Gross profit: |  |  |  |  |  |  |  |
| OpComms | 71.5 |  |  | 58.7 |  |  | 229.2 |  |  | 171.4 |  |
| Lasers | 16.4 |  |  | 15.5 |  |  | 44.8 |  |  | 43.9 |  |
| Total segment gross profit | 87.9 |  |  | 74.2 |  |  | 274.0 |  |  | 215.3 |  |
| Unallocated amounts: |  |  |  |  |  |  |  |
| Stock-based compensation | (1.9 | ) |  | (2.2 | ) |  | (6.0 | ) |  | (4.9 | ) |
| Amortization of intangibles | (1.7 | ) |  | (1.7 | ) |  | (5.1 | ) |  | (5.1 | ) |
| Other charges | (2.2 | ) |  | (7.5 | ) |  | (12.1 | ) |  | (7.5 | ) |
| Gross profit | $ | 82.1 |  |  | $ | 62.8 |  |  | $ | 250.8 |  |  | $ | 197.8 |  |


## us-gaap:SchedulesOfConcentrationOfRiskByRiskFactorTextBlock

[0001633978-17-000037:notes:215]
The table below discloses the percentage of our total net revenue attributable to each of our two reportable segments. In addition, it discloses the percentage of our total net revenue attributable to our product offerings which serve the Telecom, Datacom and Consumer and Industrial markets which accounted for more than 10% or more of our total net revenue during the last three fiscal years:

[0001633978-17-000037:notes:216]
|  |  |  | Three Months Ended |  | Nine Months Ended |
|  |  |  | April 1, 2017 |  | April 2, 2016 |  | April 1, 2017 |  | April 2, 2016 |
| OpComms: |  |  | 84.5 | % |  | 85.6 | % |  | 86.1 | % |  | 84.7 | % |
| Telecom |  |  | 64.5 | % |  | 60.7 | % |  | 63.0 | % |  | 62.0 | % |
| Datacom |  |  | 15.2 | % |  | 19.8 | % |  | 19.4 | % |  | 17.6 | % |
| Consumer and Industrial |  |  | 4.8 | % |  | 5.1 | % |  | 3.7 | % |  | 5.1 | % |
| Lasers |  |  | 15.5 | % |  | 14.4 | % |  | 13.9 | % |  | 15.3 | % |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001633978-17-000037:notes:217]
Note 16. Operating Segments and Geographic Information

[0001633978-17-000037:notes:218]
[same as prior period, unchanged from 0001633978-17-000006:notes:184]

[0001633978-17-000037:notes:219]
[same as prior period, unchanged from 0001633978-17-000006:notes:185]

[0001633978-17-000037:notes:220]
[same as prior period, unchanged from 0001633978-17-000006:notes:186]

[0001633978-17-000037:notes:221]
[same as prior period, unchanged from 0001633978-17-000006:notes:187]

[0001633978-17-000037:notes:222]
[same as prior period, unchanged from 0001633978-17-000006:notes:188]

[0001633978-17-000037:notes:223]
[same as prior period, unchanged from 0001633978-17-000006:notes:189]

[0001633978-17-000037:notes:224]
[same as prior period, unchanged from 0001633978-17-000006:notes:190]

[0001633978-17-000037:notes:225]
Our Lasers products serve our customers in markets and applications such as manufacturing, biotechnology, graphics and imaging, remote sensing, and precision machining such as drilling in printed circuit boards, wafer singulation and solar cell scribing.

[0001633978-17-000037:notes:226]
Our Laser products include diode-pumped solid-state, fiber, diode, direct-diode and gas lasers such as argon-ion and helium-neon lasers. Diode-pumped solid-state and fiber lasers provide excellent beam quality, low noise and exceptional reliability and are used in biotechnology, graphics and imaging, remote sensing, materials processing and precision machining applications. Diode and direct-diode lasers address a wide variety of applications, including laser pumping, thermal exposure, illumination, ophthalmology, image recording, printing, plastic welding and selective soldering. Gas lasers such as argon-ion and helium-neon lasers provide a stable, low-cost and reliable solution over a wide range of operating conditions, making them well suited for complex, high-resolution OEM applications such as flow cytometry, DNA sequencing, graphics and imaging and semiconductor inspection.

[0001633978-17-000037:notes:227]
We also provide high-powered and ultrafast lasers for the industrial and scientific markets. Manufacturers use high-power, ultrafast lasers to create micro parts for consumer electronics and to process glass, semiconductor, LED, and other types of materials. Use of ultrafast lasers for micromachining applications is being driven primarily by the increasing use of consumer electronics and connected devices globally.

[0001633978-17-000037:notes:228]
[same as prior period, unchanged from 0001633978-17-000006:notes:194]

[0001633978-17-000037:notes:229]
[same as prior period, unchanged from 0001633978-17-000006:notes:195]

[0001633978-17-000037:notes:230]
[same as prior period, unchanged from 0001633978-17-000006:notes:196]
