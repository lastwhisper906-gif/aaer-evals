# LITE MD&A — 0001633978-17-000037


## mdna

[0001633978-17-000037:mdna:1]
[same as prior period, unchanged from 0001633978-17-000006:mdna:1]

[0001633978-17-000037:mdna:2]
[same as prior period, unchanged from 0001633978-17-000006:mdna:2]

[0001633978-17-000037:mdna:3]
[same as prior period, unchanged from 0001633978-17-000006:mdna:3]

[0001633978-17-000037:mdna:4]
[same as prior period, unchanged from 0001633978-17-000006:mdna:4]

[0001633978-17-000037:mdna:5]
[same as prior period, unchanged from 0001633978-17-000006:mdna:5]

[0001633978-17-000037:mdna:6]
[same as prior period, unchanged from 0001633978-17-000006:mdna:6]

[0001633978-17-000037:mdna:7]
Our OpComms products address the following markets: telecommunications ("Telecom"), data communications ("Datacom"), and Consumer and Industrial markets.

[0001633978-17-000037:mdna:8]
[same as prior period, unchanged from 0001633978-17-000006:mdna:8]

[0001633978-17-000037:mdna:9]
[same as prior period, unchanged from 0001633978-17-000006:mdna:9]

[0001633978-17-000037:mdna:10]
Our OpComms customers include Alphabet Inc. (formerly Google), Ciena Corporation, Cisco Systems, Inc., Coriant GmbH, Fujitsu, Huawei Technologies Co. Ltd., Microsoft Corporation and Nokia Networks (including Alcatel-Lucent International).

[0001633978-17-000037:mdna:11]
[same as prior period, unchanged from 0001633978-17-000006:mdna:11]

[0001633978-17-000037:mdna:12]
[same as prior period, unchanged from 0001633978-17-000006:mdna:12]

[0001633978-17-000037:mdna:13]
[same as prior period, unchanged from 0001633978-17-000006:mdna:13]

[0001633978-17-000037:mdna:14]
[same as prior period, unchanged from 0001633978-17-000006:mdna:14]

[0001633978-17-000037:mdna:15]
[same as prior period, unchanged from 0001633978-17-000006:mdna:15]

[0001633978-17-000037:mdna:16]
[same as prior period, unchanged from 0001633978-17-000006:mdna:16]

[0001633978-17-000037:mdna:17]
[same as prior period, unchanged from 0001633978-17-000006:mdna:17]

[0001633978-17-000037:mdna:18]
[same as prior period, unchanged from 0001633978-17-000006:mdna:18]

[0001633978-17-000037:mdna:19]
[same as prior period, unchanged from 0001633978-17-000006:mdna:19]

[0001633978-17-000037:mdna:20]
[same as prior period, unchanged from 0001633978-17-000006:mdna:20]

[0001633978-17-000037:mdna:21]
[same as prior period, unchanged from 0001633978-17-000006:mdna:21]

[0001633978-17-000037:mdna:22]
[same as prior period, unchanged from 0001633978-17-000006:mdna:22]

[0001633978-17-000037:mdna:23]
[same as prior period, unchanged from 0001633978-17-000006:mdna:23]

[0001633978-17-000037:mdna:24]
| • | Derivative Liabilities |

[0001633978-17-000037:mdna:25]
[same as prior period, unchanged from 0001633978-17-000006:mdna:25]

[0001633978-17-000037:mdna:26]
Except as set forth below, during the third quarter of fiscal 2017, there were no significant changes to our critical accounting policies and estimates.  Management’s Discussion and Analysis of Financial Condition and Results of Operations contained in Part II, Item 7 of our Annual Report on Form 10-K for our fiscal year ended July 2, 2016 provides a more complete discussion of our critical accounting policies and estimates.

[0001633978-17-000037:mdna:27]
Derivative Liabilities

[0001633978-17-000037:mdna:28]
We have determined derivative liabilities to be one of our critical accounting policies. The Series A Preferred Stock is redeemable at the option of the holder after five years and classified as non-controlling interest redeemable convertible preferred stock in our combined and consolidated balance sheet and is measured at its redemption value. The Series A Preferred Stock conversion feature is bifurcated from the Series A Preferred Stock and accounted for separately as a derivative liability. In March 2017, we issued $450.0 million in aggregate principal amount of 0.25% Convertible Senior Notes due in March 2024 (the "Notes"), unless earlier repurchased by us or converted pursuant to their terms. We separated the derivative liability from the host debt instrument based on the fair value of the derivative liability.

[0001633978-17-000037:mdna:29]
On a quarterly basis, the derivative liabilities are marked to market based on the fair value of the conversion features, with the resulting income or loss recorded as unrealized loss on derivative liabilities on our consolidated statements of operations.  The determination of fair value includes various inputs, including volatility and interest rate assumptions. However, the change in the fair value of our common stock has the largest impact to the fair value of the derivatives.

[0001633978-17-000037:mdna:30]
Business Combinations

[0001633978-17-000037:mdna:31]
We allocate the fair value of purchase consideration to the tangible assets acquired, liabilities assumed and intangible assets acquired based on their estimated fair values. The excess of the fair value of purchase consideration over the fair values of these identifiable assets and liabilities is recorded as goodwill. When determining the fair values of assets acquired and liabilities assumed, management makes significant estimates and assumptions, especially with respect to intangible assets. Critical estimates in valuing certain intangible assets include, but are not limited to, future expected cash flows from customer relationships and acquired developed technology and discount rates. Management’s estimates of fair value are based upon assumptions believed to be reasonable, but which are inherently uncertain and unpredictable and, as a result, actual results may differ materially from estimates. Other estimates associated with the accounting for acquisitions may change as additional information becomes available regarding the assets acquired and liabilities assumed.

[0001633978-17-000037:mdna:32]
[same as prior period, unchanged from 0001633978-17-000006:mdna:28]

[0001633978-17-000037:mdna:33]
Recently Issued Accounting Pronouncements

[0001633978-17-000037:mdna:34]
Refer to "Note 2. Recently Issued Accounting Pronouncements" in the Notes to Unaudited  Consolidated Financial Statements.

[0001633978-17-000037:mdna:35]
[same as prior period, unchanged from 0001633978-17-000006:mdna:32]

[0001633978-17-000037:mdna:36]
[same as prior period, unchanged from 0001633978-17-000006:mdna:33]

[0001633978-17-000037:mdna:37]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 1, 2017 |  | April 2, 2016 |  | April 1, 2017 |  | April 2, 2016 |
| Segment net revenue: |  |  |  |  |  |  |  |
| OpComms | 84.5 | % |  | 85.6 | % |  | 86.1 | % |  | 84.7 | % |
| Lasers | 15.5 |  |  | 14.4 |  |  | 13.9 |  |  | 15.3 |  |
| Net revenue | 100.0 |  |  | 100.0 |  |  | 100.0 |  |  | 100.0 |  |
| Cost of sales | 67.2 |  |  | 72.0 |  |  | 67.1 |  |  | 69.3 |  |
| Amortization of acquired technologies | 0.7 |  |  | 0.7 |  |  | 0.7 |  |  | 0.8 |  |
| Gross profit | 32.1 |  |  | 27.3 |  |  | 32.2 |  |  | 29.9 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 14.6 |  |  | 15.3 |  |  | 14.5 |  |  | 15.8 |  |
| Selling, general and administrative | 11.0 |  |  | 12.2 |  |  | 10.8 |  |  | 13.3 |  |
| Restructuring and related charges | 1.2 |  |  | 0.8 |  |  | 1.3 |  |  | 0.6 |  |
| Total operating expenses | 26.8 |  |  | 28.3 |  |  | 26.6 |  |  | 29.7 |  |
| Income (loss) from operations | 5.3 |  |  | (1.0 | ) |  | 5.6 |  |  | 0.2 |  |
| Unrealized loss on derivative liabilities | (22.1 | ) |  | (2.1 | ) |  | (9.6 | ) |  | (0.8 | ) |
| Interest and other expenses, net | (0.5 | ) |  | (0.2 | ) |  | (0.2 | ) |  | (0.2 | ) |
| Loss before income taxes | (17.3 | ) |  | (3.3 | ) |  | (4.2 | ) |  | (0.8 | ) |
| Provision for income taxes | 4.5 |  |  | — |  |  | 2.0 |  |  | — |  |
| Net loss | (21.8 | )% |  | (3.3 | )% |  | (6.2 | )% |  | (0.8 | )% |

[0001633978-17-000037:mdna:38]
Financial Data for the three and nine months ended April 1, 2017 and April 2, 2016

[0001633978-17-000037:mdna:39]
32

[0001633978-17-000037:mdna:40]
[same as prior period, unchanged from 0001633978-17-000006:mdna:37]

[0001633978-17-000037:mdna:41]
|  | Three Months Ended |  |  |  |  |  | Nine Months Ended |  |  |  |  |
|  | April 1, 2017 |  | April 2, 2016 |  | Change |  | Percentage Change |  | April 1, 2017 |  | April 2, 2016 |  | Change |  | Percentage Change |
| Segment net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| OpComms | $ | 216.1 |  |  | $ | 197.2 |  |  | $ | 18.9 |  |  | 9.6 | % |  | $ | 671.0 |  |  | $ | 560.1 |  |  | $ | 110.9 |  |  | 19.8 | % |
| Lasers | 39.7 |  |  | 33.2 |  |  | 6.5 |  |  | 19.6 |  |  | 107.9 |  |  | 101.2 |  |  | 6.7 |  |  | 6.6 |  |
| Net revenue | $ | 255.8 |  |  | $ | 230.4 |  |  | $ | 25.4 |  |  | 11.0 | % |  | $ | 778.9 |  |  | $ | 661.3 |  |  | $ | 117.6 |  |  | 17.8 | % |
| Gross profit | $ | 82.1 |  |  | $ | 62.8 |  |  | $ | 19.3 |  |  | 30.7 | % |  | $ | 250.8 |  |  | $ | 197.8 |  |  | $ | 53.0 |  |  | 26.8 | % |
| Gross margin | 32.1 | % |  | 27.3 | % |  |  |  |  |  | 32.2 | % |  | 29.9 | % |  |  |  |  |
| Research and development | 37.3 |  |  | 35.3 |  |  | 2.0 |  |  | 5.7 | % |  | 112.9 |  |  | 104.7 |  |  | 8.2 |  |  | 7.8 | % |
| Percentage of net revenue | 14.6 | % |  | 15.3 | % |  |  |  |  |  | 14.5 | % |  | 15.8 | % |  |  |  |  |
| Selling, general and administrative | 28.1 |  |  | 28.0 |  |  | 0.1 |  |  | 0.4 | % |  | 84.2 |  |  | 87.8 |  |  | (3.6 | ) |  | (4.1 | )% |
| Percentage of net revenue | 11.0 | % |  | 12.2 | % |  |  |  |  |  | 10.8 | % |  | 13.3 | % |  |  |  |  |
| Restructuring and related charges | 3.1 |  |  | 1.8 |  |  | 1.3 |  |  | 72.2 | % |  | 10.0 |  |  | 3.9 |  |  | 6.1 |  |  | 156.4 | % |
| Percentage of net revenue | 1.2 | % |  | 0.8 | % |  |  |  |  |  | 1.3 | % |  | 0.6 | % |  |  |  |  |

[0001633978-17-000037:mdna:42]
[same as prior period, unchanged from 0001633978-17-000006:mdna:39]

[0001633978-17-000037:mdna:43]
Net revenue increased by $25.4 million, or 11.0%, during the three months ended April 1, 2017 compared to the three months ended April 2, 2016, driven by an increase in net revenue from our OpComms segment. Also, the three and nine months ended April 2, 2016 included revenue for one additional week.

[0001633978-17-000037:mdna:44]
OpComms net revenue increased by $18.9 million, or 9.6%, during the three months ended April 1, 2017 compared to the three months ended April 2, 2016, driven by an increase in demand for our super-transport blade and modulator products. In addition, the Company shipped significant amounts of next generation 100G transceivers during the three months ended April 1, 2017.

[0001633978-17-000037:mdna:45]
Lasers net revenue increased by $6.5 million, or 19.6%, during the three months ended April 1, 2017 compared to the three months ended April 2, 2016, driven by an increase in demand for our fiber laser products.

[0001633978-17-000037:mdna:46]
Net revenue increased by $117.6 million, or 17.8%, during the nine months ended April 1, 2017 compared to the nine months ended April 2, 2016, driven by  an increase in net revenue from our OpComms segment.

[0001633978-17-000037:mdna:47]
OpComms net revenue increased by $110.9 million, or 19.8%, during the nine months ended April 1, 2017 compared to the nine months ended April 2, 2016, driven by an increase in demand for our 100G datacom and super-transport blade products.

[0001633978-17-000037:mdna:48]
Lasers net revenue increased by $6.7 million, or 6.6%, during the nine months ended April 1, 2017 compared to the nine months ended April 2, 2016, driven by  an increase in demand for our fiber lasers products.

[0001633978-17-000037:mdna:49]
[same as prior period, unchanged from 0001633978-17-000006:mdna:46]

[0001633978-17-000037:mdna:50]
We operate in three geographic regions: Americas, Asia-Pacific and EMEA. Net revenue is assigned to the geographic region and country where our product is initially shipped. For example, certain customers may request shipment of our product to a contract manufacturer in one country, but the location of the end customers may differ. The following table presents net revenue and percentage of total revenue by the three geographic regions we operate in and net revenue from countries that represented 10% or more of our total net revenue (in millions, except for percentages):

[0001633978-17-000037:mdna:51]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 1, 2017 |  | April 2, 2016 |  | April 1, 2017 |  | April 2, 2016 |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States | $ | 34.7 |  |  | 13.6 | % |  | $ | 28.8 |  |  | 12.5 | % |  | $ | 106.2 |  |  | 13.6 | % |  | $ | 91.3 |  |  | 13.8 | % |
| Mexico | 70.0 |  |  | 27.4 |  |  | 34.4 |  |  | 14.9 |  |  | 158.5 |  |  | 20.3 |  |  | 112.7 |  |  | 17.0 |  |
| Other Americas | 1.5 |  |  | 0.6 |  |  | 5.1 |  |  | 2.2 |  |  | 7.4 |  |  | 1.0 |  |  | 17.9 |  |  | 2.7 |  |
| Total Americas | $ | 106.2 |  |  | 41.6 | % |  | $ | 68.3 |  |  | 29.6 | % |  | $ | 272.1 |  |  | 34.9 | % |  | $ | 221.9 |  |  | 33.5 | % |
| Asia-Pacific: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Hong Kong | $ | 47.2 |  |  | 18.5 | % |  | $ | 67.9 |  |  | 29.5 | % |  | $ | 181.2 |  |  | 23.3 |  |  | $ | 150.5 |  |  | 22.7 | % |
| Japan | 25.9 |  |  | 10.1 |  |  | 19.8 |  |  | 8.6 |  |  | 78.5 |  |  | 10.1 |  |  | 65.8 |  |  | 10.0 |  |
| Thailand | 21.3 |  |  | 8.3 |  |  | 20.5 |  |  | 8.9 |  |  | 66.8 |  |  | 8.6 |  |  | 64.5 |  |  | 9.8 |  |
| Other Asia-Pacific | 25.1 |  |  | 9.8 |  |  | 27.0 |  |  | 11.7 |  |  | 98.0 |  |  | 12.6 |  |  | 69.3 |  |  | 10.5 |  |
| Total Asia-Pacific | $ | 119.5 |  |  | 46.7 | % |  | $ | 135.2 |  |  | 58.7 | % |  | $ | 424.5 |  |  | 54.6 | % |  | $ | 350.1 |  |  | 53.0 | % |
| EMEA | $ | 30.1 |  |  | 11.8 | % |  | $ | 26.9 |  |  | 11.7 | % |  | $ | 82.3 |  |  | 10.6 | % |  | $ | 89.3 |  |  | 13.5 | % |
| Total net revenue | $ | 255.8 |  |  |  |  | $ | 230.4 |  |  |  |  | $ | 778.9 |  |  |  |  | $ | 661.3 |  |  |  |

[0001633978-17-000037:mdna:52]
[same as prior period, unchanged from 0001633978-17-000006:mdna:49]

[0001633978-17-000037:mdna:53]
[same as prior period, unchanged from 0001633978-17-000006:mdna:50]

[0001633978-17-000037:mdna:54]
The following table summarizes segment gross margin for the three and nine months ended April 1, 2017 and April 2, 2016 (in millions, except for percentages):

[0001633978-17-000037:mdna:55]
|  |  | Gross Margin |  |  |  | Gross Margin |
|  | Three Months Ended |  | Three Months Ended |  | Nine Months Ended |  | Nine Months Ended |
|  | April 1, 2017 |  | April 2, 2016 |  | April 1, 2017 |  | April 2, 2016 |  | April 1, 2017 |  | April 2, 2016 |  | April 1, 2017 |  | April 2, 2016 |
| OpComms | $ | 71.5 |  |  | $ | 58.7 |  |  | 33.1 | % |  | 29.8 | % |  | $ | 229.2 |  |  | $ | 171.4 |  |  | 34.2 | % |  | 30.6 | % |
| Lasers | 16.4 |  |  | 15.5 |  |  | 41.3 | % |  | 46.7 | % |  | 44.8 |  |  | 43.9 |  |  | 41.5 | % |  | 43.4 | % |
| Segment total | $ | 87.9 |  |  | $ | 74.2 |  |  | 34.4 | % |  | 32.2 | % |  | $ | 274.0 |  |  | $ | 215.3 |  |  | 35.2 | % |  | 32.6 | % |
| Unallocated corporate items (1) | (5.8 | ) |  | (11.4 | ) |  |  |  |  |  | (23.2 | ) |  | (17.5 | ) |  |  |  |  |
| Total | $ | 82.1 |  |  | $ | 62.8 |  |  | 32.1 | % |  | 27.3 | % |  | $ | 250.8 |  |  | $ | 197.8 |  |  | 32.2 | % |  | 29.9 | % |

[0001633978-17-000037:mdna:56]
[same as prior period, unchanged from 0001633978-17-000006:mdna:53]

[0001633978-17-000037:mdna:57]
[same as prior period, unchanged from 0001633978-17-000006:mdna:54]

[0001633978-17-000037:mdna:58]
We sell products in certain markets that are consolidating, undergoing product, architectural and business model transitions, have high customer concentrations, are highly competitive (increasingly due to Asia-Pacific-based competition), are price sensitive and/or are affected by customer seasonal and mix variant buying patterns. There is also variation in product margin among our products, therefore small variations in product mix, which can be difficult to predict, can have a significant effect on our gross margins. We expect these factors to continue to result in variability of our gross margin.

[0001633978-17-000037:mdna:59]
[same as prior period, unchanged from 0001633978-17-000006:mdna:56]

[0001633978-17-000037:mdna:60]
[same as prior period, unchanged from 0001633978-17-000006:mdna:57]

[0001633978-17-000037:mdna:61]
OpComms gross margin during the three months ended April 1, 2017 increased by 3.3% to 33.1% from 29.8% in the three months ended April 2, 2016. The improvement was primarily due to higher volume and improved product mix.

[0001633978-17-000037:mdna:62]
OpComms gross margin during the nine months ended April 1, 2017 increased by 3.6% to 34.2% from 30.6% in the nine months ended April 2, 2016. The improvement was primarily due to higher volume and improved product mix.

[0001633978-17-000037:mdna:63]
[same as prior period, unchanged from 0001633978-17-000006:mdna:60]

[0001633978-17-000037:mdna:64]
Lasers gross margin during the three months ended April 1, 2017 compared to the three months ended April 2, 2016 decreased by 5.4% to 41.3% from 46.7% mainly due to higher manufacturing costs.

[0001633978-17-000037:mdna:65]
Lasers gross margin during the nine months ended April 1, 2017 compared to the nine months ended April 2, 2016 decreased by 1.9% to 41.5% from 43.4% mainly due to higher manufacturing and warranty costs.

[0001633978-17-000037:mdna:66]
[same as prior period, unchanged from 0001633978-17-000006:mdna:63]

[0001633978-17-000037:mdna:67]
R&D expense increased by $2.0 million, or 5.7%, for the three months ended April 1, 2017 compared to the three months ended April 2, 2016. The increase in R&D expense was primarily due to the payroll related expense of $1.6 million during the three months ended April 1, 2017, which includes an increase of stock-based compensation of $0.5 million.

[0001633978-17-000037:mdna:68]
R&D expense increased by $8.2 million, or 7.8%, for the nine months ended April 1, 2017 compared to the nine months ended April 2, 2016. The increase in R&D expense was primarily due to an increase in payroll related expenses of $7.6 million during the nine months ended April 1, 2017, which includes an increase of stock-based compensation of $2.1 million .

[0001633978-17-000037:mdna:69]
[same as prior period, unchanged from 0001633978-17-000006:mdna:66]

[0001633978-17-000037:mdna:70]
[same as prior period, unchanged from 0001633978-17-000006:mdna:67]

[0001633978-17-000037:mdna:71]
SG&A expense was relatively flat during the three months ended April 1, 2017 compared to the three months ended April 2, 2016. An increase in payroll related expenses of $1.5 million during the three months ended April 1, 2017, was mostly offset by lower outside consultant expenses.

[0001633978-17-000037:mdna:72]
SG&A expense decreased by $3.6 million, or 4.1%, during the nine months ended April 1, 2017 compared to the nine months ended April 2, 2016. The decrease was a result of reduced utilization of outside consultants and separation related expenses of $10.0 million, partially offset by an increase in payroll related expense of $7.0 million, which includes an increase of stock-based compensation of $0.8 million.

[0001633978-17-000037:mdna:73]
We may experience in the future, certain non-core expenses, such as mergers and acquisitions-related expenses and litigation expenses, which could increase our SG&A expenses and potentially impact our profitability expectations in any particular quarter.

[0001633978-17-000037:mdna:74]
[same as prior period, unchanged from 0001633978-17-000006:mdna:71]

[0001633978-17-000037:mdna:75]
We have reduced costs through targeted restructuring efforts intended to consolidate our operations, optimize the manufacturing of our products and align our business in response to market conditions. As of April 1, 2017, we estimate annualized cost savings of $13.7 million from our restructuring actions to date, excluding any one-time charge as a result of the restructuring activities described below. Refer to "Note 12. Restructuring and Related Charges" in the Notes to Unaudited  Consolidated Financial Statements.

[0001633978-17-000037:mdna:76]
As of April 1, 2017, our total restructuring accrual was $5.3 million. During the three and nine months ended April 1, 2017, we recorded $3.1 million and $10.0 million, respectively, in restructuring and related charges. Of the $3.1 million and $10.0 million charge recorded during the three months and nine months ended April 1, 2017, $0.4 million and $2.2 million, respectively, was

[0001633978-17-000037:mdna:77]
related to severance, retention, lease termination costs, and employee benefits, and $2.7 million and $7.8 million, respectively, was related to other restructuring related charges which include relocation costs, equipment set-up costs, product qualification costs, facilities, and equipment costs to vacate facilities and consolidate operations. The timing of cash payments associated with these restructuring related charges and exit costs is dependent upon the type of restructuring charge and can extend over multiple periods.

[0001633978-17-000037:mdna:78]
As of April 2, 2016, our total restructuring accrual was $3.8 million. During the three and nine months ended April 2, 2016, we recorded $1.8 million and $3.9 million, respectively, in restructuring charges. These charges are primarily due to a previously announced restructuring plan for our Bloomfield, Connecticut site for severance and benefits. Refer to “Note 12. Restructuring and Related Charges” in the Notes to Unaudited  Consolidated Financial Statements.

[0001633978-17-000037:mdna:79]
[same as prior period, unchanged from 0001633978-17-000006:mdna:77]

[0001633978-17-000037:mdna:80]
Interest and other income (expense), net is comprised substantially of gains and losses associated with the re-measurement of non-functional currency denominated monetary assets and liabilities, as well as amortization of the debt discount on the Notes.

[0001633978-17-000037:mdna:81]
Interest and other income (expense), net was $(1.4) million during each of the three and nine months ended April 1, 2017 as compared to $(0.4) million and $(1.1) million, respectively, for the three and nine months ended April 2, 2016. The change was primarily due to amortization of the debt discount on the Notes in the amount of  $1.1 million for the three and nine months ended April 1, 2017.

[0001633978-17-000037:mdna:82]
[same as prior period, unchanged from 0001633978-17-000006:mdna:80]

[0001633978-17-000037:mdna:83]
Unrealized loss on Series A Preferred Stock derivative liability amounted to $17.9 million and $35.8 million for the three and nine months ended April 1, 2017, respectively, and $4.8 million and $5.0 million for the three and nine months ended April 2, 2016, respectively. Unrealized loss on the Notes derivative liability for the three and nine months ended April 1, 2017 was $38.7 million. The change is primarily related to the change in the price of the Company's underlying common stock and is reflected in the consolidated statements of operations as "Unrealized gain (loss) on derivative liabilities".

[0001633978-17-000037:mdna:84]
For further discussion of our derivative liabilities, see "Note 10. Derivative Liabilities" in the Notes to Unaudited  Consolidated Financial Statements.

[0001633978-17-000037:mdna:85]
[same as prior period, unchanged from 0001633978-17-000006:mdna:83]

[0001633978-17-000037:mdna:86]
The effective tax rate was (26.1)% and (47.8)% for the three and nine months ended April 1, 2017, respectively.  The amounts differ from the statutory rate of 35.0% primarily due to the non-deductible unrealized loss from the embedded derivatives for the Series A Preferred Stock and the Notes, non-deductible stock-based compensation and partially offset by foreign rate differential, R&D tax credits and the utilization of U.S. deferred tax assets that were subject to a full valuation allowance.

[0001633978-17-000037:mdna:87]
The Company recorded a tax provision of $11.6 million and $15.4 million for the three and nine months ended April 1, 2017, respectively. The Company recorded a tax provision of $0.1 million and $0.3 million for the three and nine months ended April 2, 2016, respectively.

[0001633978-17-000037:mdna:88]
The Company’s tax provision for both the three and nine months ended April 1, 2017 was primarily due to the discrete impact of the non-deductible unrealized loss from the embedded derivatives for the Series A Preferred Stock and the Notes, non-deductible stock-based compensation and partially offset by foreign rate differential, R&D tax credits and the utilization of U.S. deferred tax assets that were subject to a full valuation allowance.

[0001633978-17-000037:mdna:89]
The Company's tax provision for both the three and nine months ended April 2, 2016 was primarily attributable to the utilization of U.S. tax attributes that were subject to a full valuation allowance, and certain Canadian tax incentives.

[0001633978-17-000037:mdna:90]
For further discussion of our income tax provision, see "Note 13. Income Taxes" in the Notes to Unaudited  Consolidated Financial Statements.

[0001633978-17-000037:mdna:91]
[same as prior period, unchanged from 0001633978-17-000006:mdna:89]

[0001633978-17-000037:mdna:92]
The following table summarizes our contractual obligations at April 1, 2017, and the effect such obligations are expected to have on our liquidity and cash flow over the next five years (in millions):

[0001633978-17-000037:mdna:93]
|  | Payments due by period |
| Contractual Obligations | Total |  | Less than 1 year |  | 1 - 3 years |  | 3 - 5 years |  | More than 5 years |
| Asset retirement obligations—expected cash payments | $ | 2.4 |  |  | $ | 0.4 |  |  | $ | 0.4 |  |  | $ | 0.2 |  |  | $ | 1.4 |  |
| Purchase obligations (1) | 110.5 |  |  | 105.9 |  |  | 4.5 |  |  | 0.1 |  |  | — |  |
| Operating lease obligations (1) | 29.3 |  |  | 6.6 |  |  | 11.0 |  |  | 7.0 |  |  | 4.7 |  |
| Pension and post-retirement benefit payments | 3.4 |  |  | — |  |  | — |  |  | 0.2 |  |  | 3.2 |  |
| 0.25% Convertible Senior Notes due 2024 | 450.0 |  |  | — |  |  | — |  |  | — |  |  | 450.0 |  |
| Interest on 2024 Notes (2) | 7.3 |  |  | 1.2 |  |  | 2.2 |  |  | 2.3 |  |  | 1.6 |  |
| Acquisition contingencies | 3.6 |  |  | — |  |  | 3.6 |  |  | — |  |  | — |  |
| Total | $ | 606.5 |  |  | $ | 114.1 |  |  | $ | 21.7 |  |  | $ | 9.8 |  |  | $ | 460.9 |  |

[0001633978-17-000037:mdna:94]
(1) Refer to "Note 15. Commitments and Contingencies" in the Notes to Unaudited  Consolidated Financial Statements.

[0001633978-17-000037:mdna:95]
(2) Includes interest on our 0.25% Convertible Senior Notes due 2024 through September 2023 as we have the right to redeem the notes in whole or in part at any time on or after March 15, 2024.

[0001633978-17-000037:mdna:96]
As of April 1, 2017, other current liabilities on the consolidated balance sheet include $0.5 million for restructuring and related activities in connection with our operating lease obligations disclosed above.

[0001633978-17-000037:mdna:97]
Purchase obligations represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements.

[0001633978-17-000037:mdna:98]
As of April 1, 2017, our other non-current liabilities primarily relate to asset retirement obligations and pension which are presented in various lines in the preceding table.

[0001633978-17-000037:mdna:99]
The table above does not include potential redemption of our redeemable convertible preferred stock with a $35.8 million face value, plus any accrued and unpaid interest, as there is no set maturity date. If the holder of our redeemable convertible preferred stock does not execute its conversion option, or if it is unable to do so before the third anniversary of the date of issuance, we may choose to redeem the preferred stock for $35.8 million. In addition, on the fifth anniversary date of the issuance, the holder of our redeemable convertible preferred stock may elect to redeem the preferred stock for $35.8 million.

[0001633978-17-000037:mdna:100]
[same as prior period, unchanged from 0001633978-17-000006:mdna:91]

[0001633978-17-000037:mdna:101]
[same as prior period, unchanged from 0001633978-17-000006:mdna:92]

[0001633978-17-000037:mdna:102]
[same as prior period, unchanged from 0001633978-17-000006:mdna:93]

[0001633978-17-000037:mdna:103]
[same as prior period, unchanged from 0001633978-17-000006:mdna:94]

[0001633978-17-000037:mdna:104]
As of April 1, 2017 and July 2, 2016, our cash and cash equivalents of $577.9 million and $157.1 million, respectively, held predominantly in the United States. The total amount of cash outside the United States as of April 1, 2017 is $70.8 million, which is held in Cayman Islands, Canada, China and Japan. Although the cash currently held in the United States as well as the cash  generated in the United States from future operations is expected to cover our normal operating requirements, a substantial amount of additional cash could be required for other purposes, such as capital expenditures to support our business and growth, including costs associated with increasing internal manufacturing capabilities, strategic transactions and partnerships, acquisitions, dividends that may be declared, and future stock repurchase programs. Our intent is to indefinitely reinvest funds held outside the United States and our current plans do not demonstrate a need to repatriate them to fund our domestic operations. However, if in the future, we encounter a significant need for liquidity domestically or at a particular location that we cannot fulfill through borrowings, equity offerings, or other internal or external sources, we may determine that cash repatriations are necessary. Repatriation could result in additional material U.S. federal and state income tax payments in future years. Such adverse consequences would occur, for example, if the transfer of cash into the United States is taxed and no foreign tax credit is available to offset the U.S. tax liability, resulting in higher taxes. These factors may cause us to have an overall tax rate higher than other companies or higher than our

[0001633978-17-000037:mdna:105]
tax rates have been in the past. If conditions warrant, we may seek to obtain additional financing through debt or equity sources. To the extent we issue additional shares, our existing stockholders may be diluted. However, any such financing may not be available on terms favorable to us, or may not be available at all.

[0001633978-17-000037:mdna:106]
As of April 1, 2017, our consolidated balance of cash and cash equivalents increased by $420.8 million, to $577.9 million from $157.1 million as of July 2, 2016. The increase in cash and cash equivalents was mainly due to proceeds from the issuance of the Notes during the nine months ended April 1, 2017. Refer to "Note 9. Convertible Senior Notes" in the Notes to the Consolidated Financial Statements.

[0001633978-17-000037:mdna:107]
[same as prior period, unchanged from 0001633978-17-000006:mdna:97]

[0001633978-17-000037:mdna:108]
Cash provided by operating activities was $71.9 million during the nine months ended April 1, 2017, primarily resulting from $47.6 million of net loss and $143.7 million of non-cash items such as depreciation, stock-based compensation, amortization of intangibles, unrealized loss on derivative liabilities, offset by changes in excess tax benefit associated with stock-based compensation and changes in operating assets and liabilities of $24.2 million. Changes in our operating assets and liabilities related primarily to an increase in accounts receivable of $14.9 million due to the timing of collections, an increase in inventories of $14.0 million, an increase in accounts payable of $18.2 million related to such non-cash items as $15 million unpaid property, plant and equipment and $0.9 million issuance costs in accounts payable, offset by an increase in accrued expenses and other current and non-current liabilities of $15.1 million and an increase in income taxes payable of $15.0 million.

[0001633978-17-000037:mdna:109]
Cash provided by operating activities was $73.5 million during the nine months ended April 2, 2016, primarily resulting from $5.0 million of net loss and $66.6 million of non-cash items such as depreciation, stock-based compensation, amortization of intangibles and unrealized loss on derivative liabilities, and changes in operating assets and liabilities of $11.9 million. Changes in our operating assets and liabilities related primarily to an increase in accounts payable of $32.7 million, an increase in accrued payroll and related expenses of $9.7 million, an increase in accrued expenses and other current and non-current liabilities of $3.5 million, an increase in accounts receivable of $11.6 million, an increase in inventories of $9.6 million, and an increase in other current and non-current assets of $11.0 million.

[0001633978-17-000037:mdna:110]
[same as prior period, unchanged from 0001633978-17-000006:mdna:100]

[0001633978-17-000037:mdna:111]
Cash used in investing activities was mainly for capital expenditures of $100.0 million and $63.4 million during the nine months ended April 1, 2017 and April 2, 2016, respectively. During the nine months ended April 1, 2017, changes in investing cash flow also related to the acquisition of a business, $5.1 million of the purchase price for such business was paid during the nine months ended April 1, 2017.

[0001633978-17-000037:mdna:112]
[same as prior period, unchanged from 0001633978-17-000006:mdna:102]

[0001633978-17-000037:mdna:113]
Cash provided by financing activities was $454.7 million during the nine months ended April 1, 2017, consisting primarily from proceeds of $443.2 million from the issuance of the Notes.

[0001633978-17-000037:mdna:114]
Cash provided by financing activities was $131.4 million during the nine months ended April 2, 2016 resulting primarily from net transfers from Viavi.

[0001633978-17-000037:mdna:115]
[same as prior period, unchanged from 0001633978-17-000006:mdna:105]

[0001633978-17-000037:mdna:116]
We expect our primary liquidity and capital spending requirements over at least the next 12 months to be the funding of our operating activities and capital expenditures. We believe that our cash and cash equivalents as of April 1, 2017, and cash flows from our operating activities will be sufficient to meet our liquidity and capital spending requirements for at least the next 12 months. However, if market conditions are favorable, we may evaluate alternatives to opportunistically pursue additional financing.

[0001633978-17-000037:mdna:117]
[same as prior period, unchanged from 0001633978-17-000006:mdna:107]

[0001633978-17-000037:mdna:118]
[same as prior period, unchanged from 0001633978-17-000006:mdna:108]

[0001633978-17-000037:mdna:119]
[same as prior period, unchanged from 0001633978-17-000006:mdna:109]

[0001633978-17-000037:mdna:120]
[same as prior period, unchanged from 0001633978-17-000006:mdna:110]

[0001633978-17-000037:mdna:121]
[same as prior period, unchanged from 0001633978-17-000006:mdna:111]

[0001633978-17-000037:mdna:122]
[same as prior period, unchanged from 0001633978-17-000006:mdna:112]

[0001633978-17-000037:mdna:123]
[same as prior period, unchanged from 0001633978-17-000006:mdna:113]

[0001633978-17-000037:mdna:124]
[same as prior period, unchanged from 0001633978-17-000006:mdna:114]

[0001633978-17-000037:mdna:125]
[same as prior period, unchanged from 0001633978-17-000006:mdna:115]

[0001633978-17-000037:mdna:126]
[same as prior period, unchanged from 0001633978-17-000006:mdna:116]

[0001633978-17-000037:mdna:127]
| • | issuance of debt or equity securities, or other financing transactions, including bank debt; |

[0001633978-17-000037:mdna:128]
| • | potential funding of pension liabilities either voluntarily or as required by law or regulation; and |

[0001633978-17-000037:mdna:129]
| • | the settlement of any conversion or redemption of the Notes in cash. |

[0001633978-17-000037:mdna:130]
39
