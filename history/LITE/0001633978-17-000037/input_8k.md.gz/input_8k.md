# LITE 8-K — 0001633978-17-000035 filed 2017-05-04

## item codes, every 8-K on or before 2017-05-04

- 2017-05-04 0001633978-17-000035 — 2.02, 9.01
- 2017-03-08 0001193125-17-074740 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2017-03-02 0001193125-17-066769 — 8.01, 9.01
- 2017-02-07 0001633978-17-000005 — 2.02, 9.01
- 2017-01-03 0001628280-17-000018 — 4.01, 9.01
- 2016-11-09 0001628280-16-021143 — 5.02, 5.07, 9.01
- 2016-10-27 0001628280-16-020382 — 2.02, 9.01
- 2016-08-09 0001628280-16-018811 — 2.02, 9.01
- 2016-06-21 0001628280-16-017201 — 8.01
- 2016-05-04 0001628280-16-015501 — 2.02, 9.01
- 2016-02-16 0001628280-16-011261 — 5.02, 9.01
- 2016-02-04 0001628280-16-010758 — 5.02, 9.01
- 2016-02-04 0001628280-16-010755 — 2.02, 9.01
- 2015-11-17 0001193125-15-378953 — 7.01
- 2015-11-10 0001628280-15-008606 — 2.02, 9.01
- 2015-09-28 0001193125-15-329665 — 8.01, 9.01
- 2015-08-11 0001193125-15-286405 — 7.01, 9.01
- 2015-08-06 0001193125-15-281219 — 1.01, 5.02, 5.03, 5.05, 8.01, 9.01
- 2015-08-03 0001193125-15-274808 — 5.03, 9.01

## late-filing notifications on or before 2017-05-04

- 2015-11-10 0001628280-15-008612 — NT 10-Q, for the period ended 2015-09-26
- 2015-09-28 0001193125-15-329672 — NT 10-K, for the period ended 2015-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001633978-17-000035:8k_2_02:1]
EX-99.1
2
liteex991q3fy17.htm
EXHIBIT 99.1

[0001633978-17-000035:8k_2_02:2]
Exhibit

[0001633978-17-000035:8k_2_02:3]
NEWS RELEASE

[0001633978-17-000035:8k_2_02:4]
LUMENTUM ANNOUNCES FISCAL THIRD QUARTER 2017 RESULTS

[0001633978-17-000035:8k_2_02:5]
Fiscal Third Quarter Results

[0001633978-17-000035:8k_2_02:6]
| • | Net Revenue of $255.8 million increased 11% year-over-year |

[0001633978-17-000035:8k_2_02:7]
| • | GAAP Operating margin of 5.3%; Non-GAAP Operating margin of 12.6% |

[0001633978-17-000035:8k_2_02:8]
| • | GAAP diluted Net loss per share of $(0.92); Non-GAAP diluted Net income per share of $0.49 |

[0001633978-17-000035:8k_2_02:9]
Milpitas, Calif., May 4, 2017 – Lumentum Holdings Inc. ("Lumentum" or the "Company") today reported results for its fiscal third quarter ended April 1, 2017.

[0001633978-17-000035:8k_2_02:10]
Net revenue for the fiscal third quarter of 2017 was $255.8 million, with GAAP net loss of $(56.0) million or $(0.92) per diluted share. Net revenue for the fiscal second quarter of 2017 was $265.0 million, with GAAP net income of $11.8 million, or $0.19 per diluted share. Net revenue for the fiscal third quarter of 2016 was $230.4 million, with GAAP net loss of $(7.6) million, or $(0.13) per diluted share.

[0001633978-17-000035:8k_2_02:11]
Non-GAAP net income for the fiscal third quarter of 2017 was $30.8 million or $0.49 per diluted share. Non-GAAP net income for the fiscal second quarter of 2017 was $35.9 million, or $0.57 per diluted share. Non-GAAP net income for the fiscal third quarter of 2016 was $19.7 million, or $0.32 per diluted share. The Company held $577.9 million in total cash and cash equivalents at the end of the fiscal third quarter of 2017.

[0001633978-17-000035:8k_2_02:12]
"During the third quarter we made solid progress on our strategic goals in each of our markets," said Alan Lowe, president and CEO. "Our revenue from 100G QSFP28 transceivers targeting hyperscale datacenter applications picked up materially, we shipped record levels of next generation TrueFlex® ROADMs, our commercial lasers business returned to growth, and we made substantial progress on 3D sensing for mobile devices applications."

[0001633978-17-000035:8k_2_02:13]
"Late in the third quarter we saw demand from China slow significantly, and this softness persisted through April. Despite this near-term softness, we remain optimistic about our longer-term outlook. Demand continues to grow for bandwidth across the world’s datacenters and communications networks. Manufacturers are increasingly adopting advanced laser-based techniques. And, leaders in next generation consumer electronics, as well as the automotive industry, are looking to 3D sensing to enable new applications," concluded Mr. Lowe.

[0001633978-17-000035:8k_2_02:14]
Financial Overview – Fiscal Third Quarter Ended April 1, 2017

[0001633978-17-000035:8k_2_02:15]
|  | GAAP Results ($ in millions) |
|  | Q3 |  | Q2 |  | Q3 |  | Change |
|  | FY 2017 |  | FY 2017 |  | FY 2016 |  | Q/Q |  | Y/Y |
| Net revenue | $255.8 |  | $265.0 |  | $230.4 |  | (3.5)% |  | 11.0% |
| Gross margin | 32.1% |  | 32.8% |  | 27.3% |  | (70)bps |  | 480bps |
| Operating margin | 5.3% |  | 5.0% |  | (1.0)% |  | 30bps |  | 630bps |
|  | Non-GAAP Results ($ in millions) |
|  | Q3 |  | Q2 |  | Q3 |  | Change |
|  | FY 2017 |  | FY 2017 |  | FY 2016 |  | Q/Q |  | Y/Y |
| Net revenue | $255.8 |  | $265.0 |  | $230.4 |  | (3.5)% |  | 11.0% |
| Gross margin | 34.4% |  | 36.9% |  | 32.2% |  | (250)bps |  | 220bps |
| Operating margin | 12.6% |  | 14.7% |  | 8.8% |  | (210)bps |  | 380bps |

[0001633978-17-000035:8k_2_02:16]
|  | Net Revenue by Segment ($ in millions) |
|  | Q3 |  | % of |  | Q2 |  | Q3 |  | Change |
|  | FY 2017 |  | Net Revenue |  | FY 2017 |  | FY 2016 |  | Q/Q |  | Y/Y |
| Optical Communications | $ | 216.1 |  |  | 84.5 | % |  | $ | 236.6 |  |  | $ | 197.2 |  |  | (8.7 | )% |  | 9.6 | % |
| Lasers | 39.7 |  |  | 15.5 | % |  | 28.4 |  |  | 33.2 |  |  | 39.8 | % |  | 19.6 | % |
| Total | $ | 255.8 |  |  | 100.0 | % |  | $ | 265.0 |  |  | $ | 230.4 |  |  | (3.5 | )% |  | 11.0 | % |

[0001633978-17-000035:8k_2_02:17]
The tables above provide comparisons of quarterly results to prior periods, including sequential quarterly and year-over-year changes. A reconciliation between GAAP and non-GAAP measures is contained in this release under the section titled "Use of Non-GAAP Financial Measures."

[0001633978-17-000035:8k_2_02:18]
Business Outlook

[0001633978-17-000035:8k_2_02:19]
For the fiscal fourth quarter of 2017, the Company expects net revenue to be in the range of $220 million to $235 million, non-GAAP operating margin to be 9.0% to 11.0%, and non-GAAP diluted earnings per share to be $0.30 to $0.40 per share, based on approximately 63.7 million shares outstanding on a fully diluted basis.

[0001633978-17-000035:8k_2_02:20]
We have not provided reconciliations from GAAP to non-GAAP measures for our outlook. A large portion of non-GAAP adjustments, such as derivative liabilities adjustments, restructuring, stock-based compensation, litigation, and other costs and contingencies unrelated to current and future operations are by their nature highly volatile and we have low visibility as to the range that may be incurred in the future. For example, the unrealized gain or loss on the derivative liabilities for Convertible Senior Notes (the “convertible notes”) issued in March 2017 and Series A Preferred Stock in our fiscal third quarter of 2017 was a loss of $56.6 million, as compared to a gain on the derivative liability for Series A Preferred Stock of $4.8 million in the fiscal second quarter of 2017. These liabilities are revalued based on the fair market value of our common stock on the last day of each fiscal quarter, which is difficult to predict and subject to change.

[0001633978-17-000035:8k_2_02:21]
Conference Call

[0001633978-17-000035:8k_2_02:22]
Lumentum will host a conference call on May 4, 2017 at 5:30am PT/8:30am ET. A live webcast of the call and the replay will be available on the Lumentum website at http://investor.lumentum.com. Supporting materials outlining the Company’s latest financial results will be posted on http://investor.lumentum.com under the "Events and Presentations" section concurrently with this earnings press release. This press release will be available on our website at http://investor.lumentum.com under the "Financial News Releases" section and is also being furnished as a Current Report on Form 8-K with the Securities and Exchange Commission and will be available at http://www.sec.gov/.

[0001633978-17-000035:8k_2_02:23]
About Lumentum

[0001633978-17-000035:8k_2_02:24]
Lumentum (NASDAQ: LITE) is a market-leading manufacturer of innovative optical and photonic products enabling optical networking and commercial laser customers worldwide. Lumentum’s optical components and subsystems are part of virtually every type of telecom, enterprise, and data center network. Lumentum’s commercial lasers enable advanced manufacturing techniques and diverse applications including next-generation 3D sensing capabilities. Lumentum is headquartered in Milpitas, California with R&D, manufacturing, and sales offices worldwide.  For more information, visit https://www.lumentum.com/en.

[0001633978-17-000035:8k_2_02:25]
Forward-Looking Statements

[0001633978-17-000035:8k_2_02:26]
products; (f) various risks related to our business, including in relation to competition, production and sales, and (g) risks related to our separation from Viavi Solutions (formerly JDS Uniphase). All forward-looking statements involve risks and uncertainties that could cause actual events and terms to differ materially from those set forth herein, including those related to our business and growth opportunities.

[0001633978-17-000035:8k_2_02:27]
For more information on these and other risks, please refer to the "Risk Factors" section included in the Company’s 10-Q for the quarter ended April 1, 2017 filed with the Securities and Exchange Commission, and the Company’s other filings with the Securities and Exchange Commission. The forward-looking statements and preliminary financial results contained in this press release are made as of the date hereof and the Company assumes no obligation to update such statements, except as required by applicable law.

[0001633978-17-000035:8k_2_02:28]
Contact Information

[0001633978-17-000035:8k_2_02:29]
Investors: Chris Coldren, 408-404-0606; investor.relations@lumentum.com

[0001633978-17-000035:8k_2_02:30]
Press: Greg Kaufman, 408-546-4593; media@lumentum.com

[0001633978-17-000035:8k_2_02:31]
The following financial tables are presented in accordance with GAAP, unless otherwise specified.

[0001633978-17-000035:8k_2_02:32]
LUMENTUM HOLDINGS INC.

[0001633978-17-000035:8k_2_02:33]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0001633978-17-000035:8k_2_02:34]
(in millions, except per share data)

[0001633978-17-000035:8k_2_02:35]
(unaudited)

[0001633978-17-000035:8k_2_02:36]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 1, 2017 |  | April 2, 2016 |  | April 1, 2017 |  | April 2, 2016 |
| Net revenue | $ | 255.8 |  |  | $ | 230.4 |  |  | $ | 778.9 |  |  | $ | 661.3 |  |
| Cost of sales | 172.0 |  |  | 165.9 |  |  | 523.0 |  |  | 458.4 |  |
| Amortization of acquired technologies | 1.7 |  |  | 1.7 |  |  | 5.1 |  |  | 5.1 |  |
| Gross profit | 82.1 |  |  | 62.8 |  |  | 250.8 |  |  | 197.8 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 37.3 |  |  | 35.3 |  |  | 112.9 |  |  | 104.7 |  |
| Selling, general and administrative | 28.1 |  |  | 28.0 |  |  | 84.2 |  |  | 87.8 |  |
| Restructuring and related charges | 3.1 |  |  | 1.8 |  |  | 10.0 |  |  | 3.9 |  |
| Total operating expenses | 68.5 |  |  | 65.1 |  |  | 207.1 |  |  | 196.4 |  |
| Income (loss) from operations | 13.6 |  |  | (2.3 | ) |  | 43.7 |  |  | 1.4 |  |
| Unrealized loss on derivative liabilities | (56.6 | ) |  | (4.8 | ) |  | (74.5 | ) |  | (5.0 | ) |
| Interest and other expenses, net | (1.4 | ) |  | (0.4 | ) |  | (1.4 | ) |  | (1.1 | ) |
| Loss before income taxes | (44.4 | ) |  | (7.5 | ) |  | (32.2 | ) |  | (4.7 | ) |
| Provision for income taxes | 11.6 |  |  | 0.1 |  |  | 15.4 |  |  | 0.3 |  |
| Net loss | (56.0 | ) |  | (7.6 | ) |  | (47.6 | ) |  | (5.0 | ) |
| Net loss per share: |  |  |  |  |  |  |  |
| Basic | $ | (0.92 | ) |  | $ | (0.13 | ) |  | $ | (0.79 | ) |  | $ | (0.08 | ) |
| Diluted | $ | (0.92 | ) |  | $ | (0.13 | ) |  | $ | (0.79 | ) |  | $ | (0.08 | ) |
| Items reconciling net loss to net loss available to common stockholders: |  |  |  |  |  |  |  |
| Dividends on Series A preferred stock | (0.2 | ) |  | (0.3 | ) |  | (0.6 | ) |  | (0.6 | ) |
| Adjustment for Series A preferred stock redemption value | — |  |  | — |  |  | — |  |  | (11.7 | ) |
| Net loss available to common stockholders | $ | (56.2 | ) |  | $ | (7.9 | ) |  | $ | (48.2 | ) |  | $ | (17.3 | ) |
| Net loss available to common stockholders per share: |  |  |  |  |  |  |  |
| Basic | $ | (0.92 | ) |  | $ | (0.13 | ) |  | $ | (0.80 | ) |  | $ | (0.29 | ) |
| Diluted | $ | (0.92 | ) |  | $ | (0.13 | ) |  | $ | (0.80 | ) |  | $ | (0.29 | ) |
| Shares used in per share calculation: |  |  |  |  |  |  |  |
| Basic | 61.0 |  |  | 59.2 |  |  | 60.4 |  |  | 59.0 |  |
| Diluted | 61.0 |  |  | 59.2 |  |  | 60.4 |  |  | 59.0 |  |

[0001633978-17-000035:8k_2_02:37]
LUMENTUM HOLDINGS INC.

[0001633978-17-000035:8k_2_02:38]
CONSOLIDATED BALANCE SHEETS

[0001633978-17-000035:8k_2_02:39]
(in millions, except share and per share data)

[0001633978-17-000035:8k_2_02:40]
(unaudited)

[0001633978-17-000035:8k_2_02:41]
|  | April 1, 2017 |  | July 2, 2016 |
| ASSETS |  |  |  |  |  |
| Current assets: |  |  |  |  |  |
| Cash and cash equivalents | $ | 577.9 |  |  | $ | 157.1 |  |
| Accounts receivable, net of allowance for doubtful accounts of $1.5 and $0.9 as of April 1, 2017 and July 2, 2016, respectively | 185.4 |  |  | 170.5 |  |
| Inventories | 116.9 |  |  | 100.6 |  |
| Prepayments and other current assets | 61.4 |  |  | 61.3 |  |
| Total current assets | 941.6 |  |  | 489.5 |  |
| Property, plant and equipment, net | 246.6 |  |  | 183.4 |  |
| Goodwill and intangibles, net | 22.3 |  |  | 19.9 |  |
| Deferred income taxes, net | 31.1 |  |  | 31.9 |  |
| Other non-current assets | 2.9 |  |  | 1.6 |  |
| Total assets | $ | 1,244.5 |  |  | $ | 726.3 |  |
| LIABILITIES, REDEEMABLE CONVERTIBLE PREFERRED STOCK, AND EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 118.4 |  |  | $ | 118.3 |  |
| Accrued payroll and related expenses | 31.1 |  |  | 26.5 |  |
| Income taxes payable | 0.4 |  |  | 1.9 |  |
| Accrued expenses | 23.0 |  |  | 14.9 |  |
| Other current liabilities | 19.2 |  |  | 12.1 |  |
| Total current liabilities | 192.1 |  |  | 173.7 |  |
| Convertible note | 313.4 |  |  | — |  |
| Derivative liabilities | 214.7 |  |  | 10.3 |  |
| Other non-current liabilities | 19.9 |  |  | 9.1 |  |
| Total liabilities | 740.1 |  |  | 193.1 |  |
| Redeemable convertible preferred stock: |  |  |  |
| Non-controlling interest redeemable convertible Series A preferred stock, $0.001 par value, 10,000,000 authorized shares; 35,805 shares issued and outstanding as of April 1, 2017, and July 2, 2016 | 35.8 |  |  | 35.8 |  |
| Total redeemable convertible preferred stock | 35.8 |  |  | 35.8 |  |
| Stockholders’ equity: |  |  |  |
| Common stock, $0.001 par value, 990,000,000 shares authorized, 61,105,106 and 59,580,596 shares issued and outstanding as of April 1, 2017, and July 2, 2016, respectively | 0.1 |  |  | 0.1 |  |
| Additional paid-in capital | 489.8 |  |  | 467.7 |  |
| Retained earnings (deficit) | (28.0 | ) |  | 20.2 |  |
| Accumulated other comprehensive income | 6.7 |  |  | 9.4 |  |
| Total stockholders’ equity | 468.6 |  |  | 497.4 |  |
| Total liabilities and stockholders' equity | $ | 1,244.5 |  |  | $ | 726.3 |  |

[0001633978-17-000035:8k_2_02:42]
Use of Non-GAAP Financial Measures

[0001633978-17-000035:8k_2_02:43]
In this press release, Lumentum provides investors with gross margin, operating margin, net income, net income per share and Adjusted EBITDA on a non-GAAP basis. Lumentum also provides supplemental gross profit, income (loss) before income taxes and certain expenses (collectively “non-GAAP expenses”) on a non-GAAP basis. Lumentum believes this non-GAAP financial information provides additional insight into the Company's on-going performance and has therefore chosen to provide this information to investors for a more consistent basis of comparison and to help them evaluate the results of the Company's on-going operations and enable more meaningful period to period comparisons. Specifically, the Company believes that providing this information allows investors to better understand the Company’s financial performance and, importantly, to evaluate the efficacy of the methodology and information used by management to evaluate and measure such operating performance.  However, these measures may be different from non-GAAP measures used by other companies, limiting their usefulness for comparison purposes. The non-GAAP financial measures used in this press release should not be considered in isolation from measures of financial performance prepared in accordance with GAAP. Investors are cautioned that there are material limitations associated with the use of non-GAAP financial measures as an analytical tool. In particular, many of the adjustments to our GAAP financial measures reflect the exclusion of items that are recurring and will be reflected in our financial results for the foreseeable future. Further, these non-GAAP financial measures may not be comparable to similarly titled measurements reported by other companies.

[0001633978-17-000035:8k_2_02:44]
Non-GAAP gross margin, non-GAAP operating margin, non-GAAP net income, and non-GAAP net income per share, Adjusted EBITDA, non-GAAP gross profit, income (loss) before income taxes and non-GAAP expenses exclude (i) workforce related charges such as severance, retention bonuses and employee relocation costs related to formal restructuring plans, (ii) costs for facilities not required for ongoing operations, and costs related to the relocation of certain equipment from these facilities and/or contract manufacturer facilities, (iii) stock-based compensation, (iv) amortization of intangibles, (v)amortization of acquired developed technologies, (vi) non-cash interest expense, (vii) unrealized loss on derivative liabilities, and (viii) warranty charges related to our vendor quality issues with expected future recoveries and (ix) other charges comprising mainly of one-time provision for excess and obsolete inventory, acquisition, integration, litigation and other costs and contingencies unrelated to current and future operations including post-separation activities such as small site consolidations, reorganizations, insourcing or outsourcing of activities, severance related costs and transition related costs for the separation from Viavi. In the fiscal third quarter of 2017, we issued $450 million in aggregate principal amount of convertible senior notes (the “convertible notes”). As of the last day of the third quarter, the Company could only satisfy its conversion obligations in cash.  Accordingly, the conversion option of the convertible notes is accounted for as a derivative liability under GAAP and therefore, fluctuates with the fair market value of our stock price as of the end of the quarter.  Subject to the satisfaction of certain conditions set forth more fully in the indenture governing the convertible notes, the Company will evaluate the conversion option and if the Company meets the requirements to account for the conversion option as equity, the conversion option will no longer be marked to market, and will be reclassified to equity. Management does not believe that these items are reflective of the Company's underlying operating performance. The presentation of these and other similar items in Lumentum's non-GAAP financial results should not be interpreted as implying that these items are non-recurring, infrequent or unusual.

[0001633978-17-000035:8k_2_02:45]
A quantitative reconciliation between GAAP and non-GAAP financial data with respect to historical periods is included in the supplemental financial table attached to this press release. The Company has not reconciled its projections of non-GAAP earnings per share.  As items that impact net loss are out of the Company's control and/or cannot be reasonably predicted, Lumentum has determined that a quantitative reconciliation of forward-looking non-GAAP financial measures to their most directly comparable GAAP financial measures cannot be provided without unreasonable efforts.

[0001633978-17-000035:8k_2_02:46]
LUMENTUM HOLDINGS INC.

[0001633978-17-000035:8k_2_02:47]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001633978-17-000035:8k_2_02:48]
(in millions, except per share data)

[0001633978-17-000035:8k_2_02:49]
(unaudited)

[0001633978-17-000035:8k_2_02:50]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 1, 2017 |  | April 2, 2016 |  | April 1, 2017 |  | April 2, 2016 |
| Gross profit on GAAP basis | $ | 82.1 |  |  | $ | 62.8 |  |  | $ | 250.8 |  |  | $ | 197.8 |  |
| Stock-based compensation | 1.9 |  |  | 2.2 |  |  | 6.0 |  |  | 4.9 |  |
| Other charges related to non-recurring activities | 2.2 |  |  | 7.5 |  |  | 12.1 |  |  | 7.5 |  |
| Amortization of intangibles | 1.7 |  |  | 1.7 |  |  | 5.1 |  |  | 5.1 |  |
| Gross profit on non-GAAP basis | $ | 87.9 |  |  | $ | 74.2 |  |  | $ | 274.0 |  |  | $ | 215.3 |  |
| Research and development on GAAP basis | $ | 37.3 |  |  | $ | 35.3 |  |  | $ | 112.9 |  |  | $ | 104.7 |  |
| Stock-based compensation | (3.0 | ) |  | (2.5 | ) |  | (8.8 | ) |  | (6.7 | ) |
| Other charges related to non-recurring activities | (0.1 | ) |  | — |  |  | (0.7 | ) |  | (0.6 | ) |
| Research and development on non-GAAP basis | $ | 34.2 |  |  | $ | 32.8 |  |  | $ | 103.4 |  |  | $ | 97.4 |  |
| Selling, general and administrative on GAAP basis | $ | 28.1 |  |  | $ | 28.0 |  |  | $ | 84.2 |  |  | $ | 87.8 |  |
| Stock-based compensation | (3.2 | ) |  | (3.4 | ) |  | (10.1 | ) |  | (9.3 | ) |
| Other charges related to non-recurring activities | (3.3 | ) |  | (3.4 | ) |  | (7.1 | ) |  | (15.4 | ) |
| Amortization of intangibles | (0.1 | ) |  | (0.1 | ) |  | (0.3 | ) |  | (0.3 | ) |
| Selling, general and administrative on non-GAAP basis | $ | 21.5 |  |  | $ | 21.1 |  |  | $ | 66.7 |  |  | $ | 62.8 |  |
| Income (loss) from operations on GAAP basis | $ | 13.6 |  |  | $ | (2.3 | ) |  | $ | 43.7 |  |  | $ | 1.4 |  |
| Stock-based compensation | 8.1 |  |  | 8.1 |  |  | 24.9 |  |  | 20.9 |  |
| Other charges related to non-recurring activities | 5.6 |  |  | 10.9 |  |  | 19.9 |  |  | 23.5 |  |
| Amortization of intangibles | 1.8 |  |  | 1.8 |  |  | 5.4 |  |  | 5.4 |  |
| Restructuring and related charges | 3.1 |  |  | 1.8 |  |  | 10.0 |  |  | 3.9 |  |
| Income from operations on non-GAAP basis | $ | 32.2 |  |  | $ | 20.3 |  |  | $ | 103.9 |  |  | $ | 55.1 |  |
| Loss before income taxes on GAAP basis | $ | (44.4 | ) |  | $ | (7.5 | ) |  | $ | (32.2 | ) |  | $ | (4.7 | ) |
| Stock-based compensation | 8.1 |  |  | 8.1 |  |  | 24.9 |  |  | 20.9 |  |
| Other charges related to non-recurring activities | 5.6 |  |  | 10.9 |  |  | 19.9 |  |  | 23.5 |  |
| Amortization of intangibles | 1.8 |  |  | 1.8 |  |  | 5.4 |  |  | 5.4 |  |
| Restructuring and related charges | 3.1 |  |  | 1.8 |  |  | 10.0 |  |  | 3.9 |  |
| Non-cash other income (expense) | (0.1 | ) |  | — |  |  | (0.3 | ) |  | — |  |
| Effective interest expense on Convertible note | 1.0 |  |  | — |  |  | 1.0 |  |  | — |  |
| Unrealized loss on derivative liabilities | 56.6 |  |  | 4.8 |  |  | 74.5 |  |  | 5.0 |  |
| Income before income taxes on non-GAAP basis | $ | 31.7 |  |  | $ | 19.9 |  |  | $ | 103.2 |  |  | $ | 54.0 |  |
| Provision for income taxes on GAAP basis | $ | 11.6 |  |  | $ | 0.1 |  |  | $ | 15.4 |  |  | $ | 0.3 |  |
| Impact of non-GAAP income tax benefit (expense) | (10.7 | ) |  | 0.1 |  |  | (9.6 | ) |  | 0.1 |  |
| Provision for income taxes on non-GAAP basis | $ | 0.9 |  |  | $ | 0.2 |  |  | $ | 5.8 |  |  | $ | 0.4 |  |
| Net loss on GAAP basis | $ | (56.0 | ) |  | $ | (7.6 | ) |  | $ | (47.6 | ) |  | $ | (5.0 | ) |

[0001633978-17-000035:8k_2_02:51]
| Stock-based compensation | 8.1 |  |  | 8.1 |  |  | 24.9 |  |  | 20.9 |  |
| Other charges related to non-recurring activities | 5.6 |  |  | 10.9 |  |  | 19.9 |  |  | 23.5 |  |
| Amortization of intangibles | 1.8 |  |  | 1.8 |  |  | 5.4 |  |  | 5.4 |  |
| Restructuring and related charges | 3.1 |  |  | 1.8 |  |  | 10.0 |  |  | 3.9 |  |
| Non-cash other income (expense) | (0.1 | ) |  | — |  |  | (0.3 | ) |  | — |  |
| Effective interest expense on Convertible note | 1.0 |  |  | — |  |  | 1.0 |  |  | — |  |
| Unrealized loss on derivative liabilities | 56.6 |  |  | 4.8 |  |  | 74.5 |  |  | 5.0 |  |
| Impact of non-GAAP income tax benefit (expense) | 10.7 |  |  | (0.1 | ) |  | 9.6 |  |  | (0.1 | ) |
| Net income on non-GAAP basis | $ | 30.8 |  |  | $ | 19.7 |  |  | $ | 97.4 |  |  | $ | 53.6 |  |
| Net income per share on non-GAAP basis | $ | 0.49 |  |  | $ | 0.32 |  |  | $ | 1.55 |  |  | $ | 0.88 |  |
| Shares used in per share calculation - diluted on GAAP basis | 61.0 |  |  | 59.2 |  |  | 60.4 |  |  | 59.0 |  |
| Non-GAAP adjustment (a) | 2.4 |  |  | 2.3 |  |  | 2.5 |  |  | 1.9 |  |
| Shares used in per share calculation - diluted on non-GAAP basis | 63.4 |  |  | 61.5 |  |  | 62.9 |  |  | 60.9 |  |

[0001633978-17-000035:8k_2_02:52]
(a) This adjustment represents weighted-average potentially dilutive securities excluded from the computation of diluted net loss per share attributable to common stockholders on GAAP basis because the effect would have been antidilutive. This adjustment amount is added for the computation of diluted net income per share on non-GAAP basis as we had a net income on non-GAAP basis for all periods presented.

[0001633978-17-000035:8k_2_02:53]
LUMENTUM HOLDINGS INC.

[0001633978-17-000035:8k_2_02:54]
RECONCILIATION OF GAAP NET INCOME (LOSS) TO ADJUSTED EBITDA

[0001633978-17-000035:8k_2_02:55]
(in millions)

[0001633978-17-000035:8k_2_02:56]
(unaudited)

[0001633978-17-000035:8k_2_02:57]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 1, 2017 |  | April 2, 2016 |  | April 1, 2017 |  | April 2, 2016 |
| GAAP net loss | $ | (56.0 | ) |  | $ | (7.6 | ) |  | $ | (47.6 | ) |  | $ | (5.0 | ) |
| Interest and other expense (income), net | 1.4 |  |  | 0.4 |  |  | 1.4 |  |  | 1.1 |  |
| Provision for income taxes | 11.6 |  |  | 0.1 |  |  | 15.4 |  |  | 0.3 |  |
| Depreciation | 14.1 |  |  | 11.3 |  |  | 39.1 |  |  | 35.1 |  |
| Amortization | 1.8 |  |  | 1.8 |  |  | 5.4 |  |  | 5.4 |  |
| EBITDA | (27.1 | ) |  | 6.0 |  |  | 13.7 |  |  | 36.9 |  |
| Restructuring and related charges | 3.1 |  |  | 1.8 |  |  | 10.0 |  |  | 3.9 |  |
| Stock-based compensation | 8.1 |  |  | 8.1 |  |  | 24.9 |  |  | 20.9 |  |
| Other charges related to non-recurring activities | 5.6 |  |  | 10.9 |  |  | 19.9 |  |  | 23.5 |  |
| Unrealized loss on derivative liabilities | 56.6 |  |  | 4.8 |  |  | 74.5 |  |  | 5.0 |  |
| Adjusted EBITDA | $ | 46.3 |  |  | $ | 31.6 |  |  | $ | 143.0 |  |  | $ | 90.2 |  |
