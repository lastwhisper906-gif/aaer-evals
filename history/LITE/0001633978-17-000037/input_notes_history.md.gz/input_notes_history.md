# LITE note change history — 0001633978-17-000006 → 0001633978-17-000037


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2017-05-04):
[0001633978-17-000037:note_history:1]
We lease certain real and personal property from unrelated third parties under non-cancellable operating leases that expire at various dates through fiscal 2026. Certain leases require us to pay property taxes, insurance and routine maintenance, and include escalation clauses. As of April 1, 2017, the future minimum annual lease payments under non-cancellable operating leases were as follows (in millions):
  (was, 2017-02-07, similarity 0.9838):
[0001633978-17-000006:note_history:1]
We lease certain real and personal property from unrelated third parties under non-cancellable operating leases that expire at various dates through fiscal 2026. Certain leases require us to pay property taxes, insurance and routine maintenance, and include escalation clauses. As of December 31, 2016, the future minimum annual lease payments under non-cancellable operating leases were as follows (in millions):

- changed (2017-05-04):
[0001633978-17-000037:note_history:2]
Included in the future minimum lease payments table above is $0.5 million related to lease commitments in connection with our restructuring and related activities. Refer to "Note 12. Restructuring and Related Charges" in the Notes to Unaudited  Consolidated Financial Statements.
  (was, 2017-02-07, similarity 0.9814):
[0001633978-17-000006:note_history:2]
Included in the future minimum lease payments table above is $0.3 million related to lease commitments in connection with our restructuring and related activities. Refer to "Note 10. Restructuring and Related Charges" in the Notes to Consolidated Financial Statements.

- added (2017-05-04):
[0001633978-17-000037:note_history:3]
Acquisition Contingencies

- added (2017-05-04):
[0001633978-17-000037:note_history:4]
The Company incurred contingent liabilities in the amount of $3.6 million in connection with the February 2017 acquisition. The amount of $2.7 million is payable in 36 months following the acquisition date contingent upon meeting certain production targets. The Company retained $0.9 million of the purchase price to cover any potential liabilities under the representations, warranties and indemnifications included in the purchase agreement, the amount is payable at the 15 month anniversary of the close date. Refer to "Note 6. Mergers and Acquisitions".

- added (2017-05-04):
[0001633978-17-000037:note_history:5]
0.25% Convertible Senior Notes due 2024

- added (2017-05-04):
[0001633978-17-000037:note_history:6]
The future interest and principal payments related to the Notes are as follows as of April 1, 2017:

- added (2017-05-04):
[0001633978-17-000037:note_history:7]
| Remainder of 2017 | $ | — |  |
| 2018 | 1.2 |  |
| 2019 | 1.1 |  |
| 2020 | 1.1 |  |
| 2021 | 1.1 |  |
| Thereafter | 452.8 |  |
| Total Notes payments | $ | 457.3 |  |

- changed (2017-05-04):
[0001633978-17-000037:note_history:8]
Purchase obligations of $110.5 million as of April 1, 2017, represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule and adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.
  (was, 2017-02-07, similarity 0.9886):
[0001633978-17-000006:note_history:8]
Purchase obligations of $122.3 million as of December 31, 2016, represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule and adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

- added (2017-05-04):
[0001633978-17-000037:note_history:9]
We provide reserves for the estimated costs of product warranties at the time revenue is recognized. We typically offer a twelve month warranty for most of our products. However, in some instances depending upon the product, product component or application of our products by the end customer, our warranties can vary and generally range from six months to five years. We estimate the costs of our warranty obligations on an annualized basis based on our historical experience of known product failure rates, use of materials to repair or replace defective products and service delivery costs incurred in correcting product failures. In addition, from time to time, specific warranty accruals may be made if unforeseen technical problems arise with specific products. We assess the adequacy of our recorded warranty liabilities and adjust the amounts as necessary.

- changed (2017-05-04):
[0001633978-17-000037:note_history:10]
The following table presents the changes in our warranty reserve during the three and nine months ended April 1, 2017 and April 2, 2016 (in millions):
  (was, 2017-02-07, similarity 0.9066):
[0001633978-17-000006:note_history:10]
The following table presents the changes in our warranty reserve during the three and six months ended December 31, 2016 and December 26, 2015 (in millions):

- changed (2017-05-04):
[0001633978-17-000037:note_history:11]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 1, 2017 |  | April 2, 2016 |  | April 1, 2017 |  | April 2, 2016 |
| Balance as of beginning of period | $ | 8.7 |  |  | $ | 3.1 |  |  | $ | 2.8 |  |  | $ | 2.8 |  |
| Provision for warranty | 0.6 |  |  | 0.8 |  |  | 9.3 |  |  | 2.5 |  |
| Utilization of reserve | (1.2 | ) |  | (0.8 | ) |  | (4.0 | ) |  | (2.3 | ) |
| Adjustments related to pre-existing warranties (includingchanges in estimates) | — |  |  | (1.3 | ) |  | — |  |  | (1.2 | ) |
| Balance as of period end | $ | 8.1 |  |  | $ | 1.8 |  |  | $ | 8.1 |  |  | $ | 1.8 |  |
  (was, 2017-02-07, similarity 0.8717):
[0001633978-17-000006:note_history:11]
|  | Three Months Ended |  | Six Months Ended |
|  | December 31, 2016 |  | December 26, 2015 |  | December 31, 2016 |  | December 26, 2015 |
| Balance as of beginning of period | $ | 5.4 |  |  | $ | 2.5 |  |  | $ | 2.8 |  |  | $ | 2.8 |  |
| Provision for warranty | 4.9 |  |  | 0.8 |  |  | 8.7 |  |  | 1.7 |  |
| Utilization of reserve | (1.6 | ) |  | (0.3 | ) |  | (2.8 | ) |  | (1.5 | ) |
| Adjustments related to pre-existing warranties (includingchanges in estimates) | — |  |  | 0.1 |  |  | — |  |  | 0.1 |  |
| Balance as of period end | $ | 8.7 |  |  | $ | 3.1 |  |  | $ | 8.7 |  |  | $ | 3.1 |  |

- changed (2017-05-04):
[0001633978-17-000037:note_history:12]
Our research and development ("R&D"), manufacturing and distribution operations involve the use of hazardous substances and are regulated under international, federal, state and local laws governing health and safety and the environment. We apply strict standards for protection of the environment and occupational health and safety to sites inside and outside the United States, even if not subject to regulations imposed by foreign governments. We believe that our properties and operations at our facilities comply in all material respects with applicable environmental laws and occupational health and safety laws. However, the risk of environmental liabilities cannot be completely eliminated and there can be no assurance that the application of environmental and health and safety laws will not require us to incur significant expenditures. We are also regulated under a number of international, federal, state and local laws regarding recycling, product packaging and product content requirements. The environmental, product content/disposal and recycling laws are gradually becoming more stringent and may cause us to incur significant expenditures in the future.
  (was, 2017-02-07, similarity 0.9875):
[0001633978-17-000006:note_history:12]
Our R&D, manufacturing and distribution operations involve the use of hazardous substances and are regulated under international, federal, state and local laws governing health and safety and the environment. We apply strict standards for protection of the environment and occupational health and safety to sites inside and outside the United States, even if not subject to regulations imposed by foreign governments. We believe that our properties and operations at our facilities comply in all material respects with applicable environmental laws and occupational health and safety laws. However, the risk of environmental liabilities cannot be completely eliminated and there can be no assurance that the application of environmental and health and safety laws will not require us to incur significant expenditures. We are also regulated under a number of international, federal, state and local laws regarding recycling, product packaging and product content requirements. The environmental, product content/disposal and recycling laws are gradually becoming more stringent and may cause us to incur significant expenditures in the future.

- removed (2017-05-04):
[0001633978-17-000006:note_history:13]
We provide reserves for the estimated costs of product warranties at the time revenue is recognized. We typically offer a twelve month warranty for most of our products. However, in some instances depending upon the product, product component or application of our products by the end customer, our warranties can vary and generally range from six months to 5 years. We estimate the costs of our warranty obligations on an annualized basis based on our historical experience of known product failure rates, use of materials to repair or replace defective products and service delivery costs incurred in correcting product failures. In addition, from time to time, specific warranty accruals may be made if unforeseen technical problems arise with specific products. We assess the adequacy of our recorded warranty liabilities and adjust the amounts as necessary.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2017-05-04):
[0001633978-17-000037:note_history:14]
On July 31, 2015, prior to the Separation (as described below), JDSU transferred substantially all of the assets and liabilities and operations of the CCOP segment and WaveReady product lines to Lumentum. Financial statements for periods prior to the Separation were prepared on a stand-alone basis and were derived from JDSU’s consolidated financial statements and accounting records. The Company prepared consolidated financial statements for the period from June 28, 2015 to August 1, 2015 where expenses were allocated to the Company using estimates that it considers to be a reasonable reflection of the utilization of services provided to, or benefits received by, the Company. Since August 1, 2015, the Company has prepared consolidated financial statements as an independent stand-alone basis pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (SEC) and are in conformity with generally accepted accounting principles in the United States (GAAP). In the opinion of management, these consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments, which are necessary for a fair statement of the consolidated financial statements for the periods shown. The results of operations for such periods are not necessarily indicative of the results expected for the full year or for any future periods.
  (was, 2017-02-07, similarity 0.9985):
[0001633978-17-000006:note_history:14]
On July 31, 2015, prior to the Separation (as described below), JDSU transferred substantially all of the assets and liabilities and operations of the CCOP segment and WaveReady product lines to Lumentum. Financial statements for periods prior to the Separation were prepared on a stand-alone basis and were derived from JDSU’s consolidated financial statements and accounting records. The Company prepared consolidated financial statements for the period from June 28, 2015 to August 1, 2015 where expenses were allocated to the Company using estimates that it considers to be a reasonable reflection of the utilization of services provided to, or benefits received by, the Company. Since August 1, 2015, the Company has prepared consolidated financial statements as an independent stand-alone basis pursuant to the rules and regulations of the the U.S. Securities and Exchange Commission (SEC) and are in conformity with generally accepted accounting principles in the United States (GAAP). In the opinion of management, these consolidated financial statements reflect all adjustments, consisting only of normal recurring adjustments, which are necessary for a fair statement of the consolidated financial statements for the periods shown. The results of operations for such periods are not necessarily indicative of the results expected for the full year or for any future periods.

- changed (2017-05-04):
[0001633978-17-000037:note_history:15]
As of April 1, 2017, Viavi held a total of 0.4 million shares of our common stock, which is under 1% of our total shares outstanding.
  (was, 2017-02-07, similarity 0.9569):
[0001633978-17-000006:note_history:15]
As of December 31, 2016, Viavi held a total of 1.7 million shares of our common stock, which is under 5% of our total shares outstanding.

- changed (2017-05-04):
[0001633978-17-000037:note_history:16]
See "Note 3. Related Party Transactions" in the Notes to Unaudited Consolidated Financial Statements regarding the relationships we have with Viavi.
  (was, 2017-02-07, similarity 0.9648):
[0001633978-17-000006:note_history:16]
See "Note 3. Related Party Transactions" in the Notes to Consolidated Financial Statements regarding the relationships we have with Viavi.

- added (2017-05-04):
[0001633978-17-000037:note_history:17]
The preparation of our consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amount of assets and liabilities at the date of the financial statements, the reported amount of net revenue and expenses and the disclosure of commitments and contingencies during the reporting periods. We base estimates on historical experience and on various assumptions about the future believed to be reasonable based on available information. On an ongoing basis, the Company evaluates its estimates, including those related to revenue recognition, inventory valuation, allocation methods and allocated expenses from Viavi, valuation of goodwill and other intangible assets, stock-based compensation, retirement and post-retirement plan assumptions, restructuring, warranty, valuation of derivative liabilities, and accounting for income taxes. Our reported financial position or results of operations may be materially different under changed conditions or when using different estimates and assumptions, particularly with respect to significant accounting policies. If estimates or assumptions differ from actual results, subsequent periods are adjusted to reflect more current information.

- changed (2017-05-04):
[0001633978-17-000037:note_history:18]
Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are revenue recognition, inventory valuation, allocation methods and allocated expenses from Viavi, valuation of goodwill and other intangible assets, stock-based compensation, retirement and post-retirement plan assumptions, restructuring, warranty, valuation of derivative liabilities, and accounting for income taxes.
  (was, 2017-02-07, similarity 0.637):
[0001633978-17-000006:note_history:18]
The preparation of the consolidated financial statements in accordance with GAAP in the United States requires management to make estimates and assumptions that affect the amounts reported in our consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact the Company in the future, actual results may be different from the estimates. Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are revenue recognition, inventory valuation, allocation methods and allocated expenses from Viavi, valuation of goodwill and other intangible assets, stock-based compensation, retirement and post-retirement plan assumptions, restructuring, warranty, valuation of derivative liability, and accounting for income taxes.

- changed (2017-05-04):
[0001633978-17-000037:note_history:19]
There have been no material changes in our significant accounting policies during the nine months ended April 1, 2017 compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 2, 2016. The accompanying unaudited interim consolidated financial statements and accompanying related notes should be read in conjunction with the consolidated financial statements and related notes included in our Annual Report on Form 10-K for the fiscal year ended July 2, 2016.
  (was, 2017-02-07, similarity 0.9528):
[0001633978-17-000006:note_history:19]
There have been no material changes in our significant accounting policies during the six months ended December 31, 2016 compared to the significant accounting policies described in our Annual Report on Form 10-K for the fiscal year ended July 2, 2016. The accompanying unaudited interim consolidated financial statements and accompanying related notes should be read in conjunction with the consolidated financial statements and related notes included in our Annual Report on Form 10-K for the fiscal year ended July 2, 2016.

- removed (2017-05-04):
[0001633978-17-000006:note_history:20]
The preparation of our consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amount of assets and liabilities at the date of the financial statements, the reported amount of net revenue and expenses and the disclosure of commitments and contingencies during the reporting periods. We base estimates on historical experience and on various assumptions about the future believed to be reasonable based on available information. Our reported financial position or results of operations may be materially different under changed conditions or when using different estimates and assumptions, particularly with respect to significant accounting policies. If estimates or assumptions differ from actual results, subsequent periods are adjusted to reflect more current information.


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2017-05-04):
[0001633978-17-000037:note_history:21]
As of April 1, 2017, the Notes consisted of the following (in millions):

- added (2017-05-04):
[0001633978-17-000037:note_history:22]
| Liability component: | April 1, 2017 |
| Principal | $ | 450.0 |  |
| Unamortized debt discount | (136.6 | ) |
| Net carrying amount of the liability component | $ | 313.4 |  |
| Carrying amount of the embedded derivative liability | $ | 168.6 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2017-05-04):
[0001633978-17-000037:note_history:23]
Note 9. Convertible Senior Notes

- added (2017-05-04):
[0001633978-17-000037:note_history:24]
On March 8, 2017, the Company issued $450.0 million aggregate principal amount of 0.25% Convertible Senior Notes due 2024 (the “Notes”), in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act of 1933, as amended (the “Securities Act”). The Notes are governed by an indenture between the Company, as the issuer, and U.S. Bank National Association, as trustee (the “Indenture”).  The Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by the Company.

- added (2017-05-04):
[0001633978-17-000037:note_history:25]
The Notes will bear interest at a rate of 0.25% per year.  Interest on the Notes is payable semi-annually in arrears on March 15 and September 15 of each year, beginning on September 15, 2017. The Notes will mature on March 15, 2024, unless earlier repurchased by the Company or converted pursuant to their terms.

- added (2017-05-04):
[0001633978-17-000037:note_history:26]
The initial conversion rate of the Notes is 16.4965 shares of common stock per $1,000 principal amount of Notes, which is equivalent to an initial conversion price of approximately $60.62 per share, a 132.5% premium to the fair market value at the date of issuance. Prior to the close of business on the business day immediately preceding December 15, 2023, the Notes will be convertible only under the following circumstances: (1) during any fiscal quarter commencing after July 1, 2017 (and only during such fiscal quarter), if the last reported sale price of the Company’s common stock for at least 20 trading days (whether or not consecutive) during the period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price on each applicable trading day; (2) during the five consecutive business day period after any five consecutive trading day period (the “measurement period”) in which the trading price per $1,000 principal amount of notes for each trading day of such measurement period was less than 98% of the product of the last reported sale price of the Company’s common stock and the applicable conversion rate on each such trading day; or (3) upon the occurrence of specified corporate events. On or after December 15, 2023 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their notes at any time. In addition, upon the occurrence of a make-whole fundamental change, the Company will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert its Notes in connection with such make-whole fundamental change.

- added (2017-05-04):
[0001633978-17-000037:note_history:27]
Until such time as the Company satisfies the Tax Matters Agreement settlement condition (“TMA settlement condition”, as described below), the Company is required to satisfy its conversion obligation solely in cash.  However, if the Company has satisfied the TMA share settlement condition, the Company may satisfy its conversion obligation in cash, shares of the Company’s common stock or a combination of cash and shares of the Company’s common stock, at the Company’s election.

- added (2017-05-04):
[0001633978-17-000037:note_history:28]
The TMA settlement condition can be met by the Company either receiving (i) an opinion of a nationally recognized accounting firm selected by the Company and Viavi by mutual consent to the effect that the issuance of the Notes and the shares of Common Stock upon conversion of the Notes (assuming for each such purpose that Physical Settlement applies and the maximum number of Additional Shares have been added to the Conversion Rate) does not result in the imposition or incurrence of certain taxes upon Viavi, the Company, their respective Affiliates or any third party to which any of Viavi, the Company or their respective Affiliates is or may become liable in connection with the failure of the Separation to qualify as a transaction in which no income, gain or loss is recognized under Section 355 and Section 368(A)(1)(D) of the Internal Revenue Code of 1986, as amended (the “Code”) (including any tax resulting from the application of Section 355(d) or Section 355(e) of the Code to the Separation but only to the extent such tax is not reduced by a tax asset) or (ii) the consent of Viavi to the issuance of the Notes and the shares of Common Stock upon conversion of the Notes (assuming for each such purpose that Physical Settlement applies and the maximum number of Additional Shares have been added to the Conversion Rate), in each case, in a manner that the Company has determined satisfies the requirements of the Tax Matters Agreement with Viavi. All capitalized terms not previously defined have the definitions set forth in the Indenture.

- added (2017-05-04):
[0001633978-17-000037:note_history:29]
The Company may not redeem the Notes prior to their maturity date and no sinking fund is provided for the Notes. Upon the occurrence of a fundamental change, holders may require the Company to repurchase all or a portion of their Notes for cash at a price equal to 100% of the principal amount of the Notes to be repurchased, plus any accrued and unpaid interest.

- added (2017-05-04):
[0001633978-17-000037:note_history:30]
The Company considered the features embedded in the notes other than the conversion feature, including the holders' put feature, the Company's call feature, and the make-whole feature, and concluded that they are not required to be bifurcated and accounted for separately from the host debt instrument.

- added (2017-05-04):
[0001633978-17-000037:note_history:31]
Because the Company can only settle the notes in cash until the TMA settlement condition is met, the Company determined that the conversion feature meets the definition of a derivative liability.  The Company separated the derivative liability from the host debt instrument based on the fair value of the derivative liability. As of the issuance date, March 8, 2017, the derivative liability fair value of $129.9 million was calculated using the binomial valuation approach. The residual principal amount of the notes of $320.1 million before issuance costs was allocated to the debt component. The Company incurred approximately $7.7 million in transaction costs in connection with the issuance of the notes. These costs were allocated to the debt component and recognized as a debt discount. The Company amortizes the debt discount, including both the initial value of the derivative liability and the transaction costs, over the term of the Notes using the effective interest method. The effective interest rate of the Notes is 5.4% per year. As of April 1, 2017, the remaining debt discount amortization period was 83 months.

- added (2017-05-04):
[0001633978-17-000037:note_history:32]
As of April 1, 2017, the Notes consisted of the following (in millions):

- added (2017-05-04):
[0001633978-17-000037:note_history:33]
| Liability component: | April 1, 2017 |
| Principal | $ | 450.0 |  |
| Unamortized debt discount | (136.6 | ) |
| Net carrying amount of the liability component | $ | 313.4 |  |
| Carrying amount of the embedded derivative liability | $ | 168.6 |  |

- added (2017-05-04):
[0001633978-17-000037:note_history:34]
The carrying value of the derivative liability related to the Notes as of April 1, 2017 was $168.6 million. Refer to "Note 10. Derivative Liabilities".

- added (2017-05-04):
[0001633978-17-000037:note_history:35]
The following table sets forth interest expense information related to the 2024 Notes:

- added (2017-05-04):
[0001633978-17-000037:note_history:36]
|  | Three Months Ended |  | Nine Months Ended |
| (in millions, except percentages) | April 1, 2017 |  | April 2, 2016 |  | April 1, 2017 |  | April 2, 2016 |
| Contractual interest expense | $ | 0.1 |  |  | — |  |  | $ | 0.1 |  |  | — |  |
| Amortization of the debt discount | 1.0 |  |  | — |  |  | 1.0 |  |  | — |  |
| Total interest cost | $ | 1.1 |  |  | — |  |  | $ | 1.1 |  |  | — |  |
| Effective interest rate on the liability component | 5.4 | % |  | — | % |  | 5.4 | % |  | — | % |

- added (2017-05-04):
[0001633978-17-000037:note_history:37]
The Notes  have no impact to diluted earnings per share during the three and nine months ended April 1, 2017, as the Company has to settle the Notes in cash until the TMA settlement condition is met. If the TMA settlement condition is met, we intend to apply the treasury stock method to determine the potential dilutive effect of the Notes as a result of the Company’s intent and ability to settle the principal amount of the Notes in cash.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2017-05-04):
[0001633978-17-000037:note_history:38]
During the three and nine months ended April 1, 2017, the Company recognized revenue of $1.0 million and $2.5 million, respectively, from products sold to Viavi. During the three and nine months ended April 2, 2016, the Company recognized revenue of $0.9 million and $2.4 million, respectively, for products sold to Viavi.
  (was, 2017-02-07, similarity 0.8431):
[0001633978-17-000006:note_history:38]
During the three and six months ended December 31, 2016, the Company recognized revenue of $0.9 million and $1.5 million, respectively, from products sold to Viavi. During the three and six months ended December 26, 2015, the Company recognized revenue of $0.7 million and $1.5 million, respectively, for products sold to Viavi.

- added (2017-05-04):
[0001633978-17-000037:note_history:39]
During the three and nine months ended April 1, 2017, the Company recorded $0.1 million and $0.5 million, respectively, in research and development cost reimbursement from Viavi. For the three and nine months ended April 2, 2016, the Company recorded $0.5 million and $1.7 million, respectively, in research and development cost reimbursement.

- added (2017-05-04):
[0001633978-17-000037:note_history:40]
During the three and nine months ended April 1, 2017, the Company recorded $0.2 million and $0.6 million, respectively, in sublease rental income from Viavi. For the three and nine months ended April 2, 2016, the Company recorded and $0.2 million and $0.5 million, respectively, in sublease rental income from Viavi.

- changed (2017-05-04):
[0001633978-17-000037:note_history:41]
As of April 1, 2017 and July 2, 2016, the Company had $0.5 million and $1.1 million, respectively, in trade accounts receivable due from Viavi. The Company did not have any trade payables due to Viavi as of  April 1, 2017 or July 2, 2016.
  (was, 2017-02-07, similarity 0.7241):
[0001633978-17-000006:note_history:41]
As of December 31, 2016 and July 2, 2016, the Company had $0.4 million and $1.1 million, respectively, in trade accounts receivable due from Viavi.

- added (2017-05-04):
[0001633978-17-000037:note_history:42]
As of April 1, 2017, the Company had $0.1 million in other payables due to Viavi. As of July 2, 2016, the Company had $2.0 million in other receivables from Viavi. The Company had no other receivables from Viavi as of April 1, 2017 or other payables due to Viavi as of July 2, 2016.

- changed (2017-05-04):
[0001633978-17-000037:note_history:43]
There were no allocations of expenses from Viavi for the three and nine months ended April 1, 2017, and the three months ended April 2, 2016. During the nine months ended April 2, 2016, allocated costs from Viavi included in the accompanying consolidated statements of operations were as follows (in millions):
  (was, 2017-02-07, similarity 0.7102):
[0001633978-17-000006:note_history:43]
There were no allocations of expenses from Viavi for the three and six months ended December 31, 2016, and the three months ended December 26, 2015. During the six months ended December 26, 2015, allocated costs from Viavi included in the accompanying consolidated statements of operations were as follows (in millions):

- added (2017-05-04):
[0001633978-17-000037:note_history:44]
|  | Nine Months Ended |
|  | April 2, 2016 |
| Selling, general and administrative expenses | $ | 11.7 |  |
| Interest and other (income) expenses, net | (0.1 | ) |
| Interest expense | 0.1 |  |
| Total allocated expenses | $ | 11.7 |  |

- removed (2017-05-04):
[0001633978-17-000006:note_history:45]
During the three months ended December 31, 2016, the Company did not record any research and development cost reimbursement from Viavi. During the six months ended December 31, 2016, the Company recorded $0.4 million in research and development cost reimbursement from Viavi. For the three and six months ended December 26, 2015, the Company recorded $0.7 million and $1.2 million, respectively, in research and development cost reimbursement.

- removed (2017-05-04):
[0001633978-17-000006:note_history:46]
During the three and six months ended December 31, 2016, the Company recorded $0.2 million and $0.4 million, respectively, in sublease rental income. For the three and six months ended December 26, 2015, the Company recorded and $0.2 million and $0.3 million, respectively, in sublease rental income.

- removed (2017-05-04):
[0001633978-17-000006:note_history:47]
As of December 31, 2016 and July 2, 2016, the Company had $0.3 million in payables due to Viavi and $2.0 million in other receivables from Viavi, respectively.

- removed (2017-05-04):
[0001633978-17-000006:note_history:48]
|  | Six Months Ended |
|  | December 26, 2015 |
| Selling, general and administrative | 11.7 |  |
| Interest and other (income) expenses, net | (0.1 | ) |
| Interest expense | 0.1 |  |
| Total allocated costs | $ | 11.7 |  |


## us-gaap:ScheduleOfRelatedPartyTransactionsTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2017-05-04):
[0001633978-17-000037:note_history:49]
During the nine months ended April 2, 2016, allocated costs from Viavi included in the accompanying consolidated statements of operations were as follows (in millions):
  (was, 2017-02-07, similarity 0.9512):
[0001633978-17-000006:note_history:49]
During the six months ended December 26, 2015, allocated costs from Viavi included in the accompanying consolidated statements of operations were as follows (in millions):

- added (2017-05-04):
[0001633978-17-000037:note_history:50]
|  | Nine Months Ended |
|  | April 2, 2016 |
| Selling, general and administrative expenses | $ | 11.7 |  |
| Interest and other (income) expenses, net | (0.1 | ) |
| Interest expense | 0.1 |  |
| Total allocated expenses | $ | 11.7 |  |

- removed (2017-05-04):
[0001633978-17-000006:note_history:51]
|  | Six Months Ended |
|  | December 26, 2015 |
| Selling, general and administrative | 11.7 |  |
| Interest and other (income) expenses, net | (0.1 | ) |
| Interest expense | 0.1 |  |
| Total allocated costs | $ | 11.7 |  |
