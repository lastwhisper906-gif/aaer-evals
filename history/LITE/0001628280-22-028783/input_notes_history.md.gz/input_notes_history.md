# LITE note change history — 0001628280-22-012157 → 0001628280-22-028783


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2022-11-08):
[0001628280-22-028783:note_history:1]
Purchase obligations of $416.2 million as of October 1, 2022, represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. In addition, we assumed certain purchase orders in connection with our merger with NeoPhotonics for the purchase of inventory and other items in the ordinary course of its business.  Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule and adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

- added (2022-11-08):
[0001628280-22-028783:note_history:2]
|  | Three Months Ended |  |  |
|  | October 1, 2022 |  | October 2, 2021 |  |  |  |  |
| Balance as of beginning of period | $ | 10.0 |  |  | $ | 5.0 |  |  |  |  |  |
| Warranties assumed in NeoPhotonics merger | 0.7 |  |  | — |  |  |  |  |  |
| Provision for warranty | 1.5 |  |  | 1.7 |  |  |  |  |  |
| Utilization of reserve | (2.1) |  |  | (1.6) |  |  |  |  |  |
| Balance as of end of period | $ | 10.1 |  |  | $ | 5.1 |  |  |  |  |  |

- changed (2022-11-08):
[0001628280-22-028783:note_history:3]
Our research and development, manufacturing and distribution operations involve the use of hazardous substances and are regulated under international, federal, state and local laws governing health and safety and the environment. We apply strict standards for protection of the environment and occupational health and safety to sites inside and outside the United States, even if not subject to regulations imposed by foreign governments. We believe that our properties and operations at our facilities comply in all material respects with applicable environmental laws and occupational health and safety laws. However, the risk of environmental liabilities cannot be completely eliminated and there can be no assurance that the application of environmental and health and safety laws will not require us to incur significant expenditures. We are also regulated under a number of international, federal, state and local laws regarding recycling, product packaging and product content requirements. The environmental, product content/disposal and recycling laws are gradually becoming more stringent and may cause us to incur significant expenditures in the future.
  (was, 2022-05-04, similarity 0.9966):
[0001628280-22-012157:note_history:3]
Our research and development (“R&D”), manufacturing and distribution operations involve the use of hazardous substances and are regulated under international, federal, state and local laws governing health and safety and the environment. We apply strict standards for protection of the environment and occupational health and safety to sites inside and outside the United States, even if not subject to regulations imposed by foreign governments. We believe that our properties and operations at our facilities comply in all material respects with applicable environmental laws and occupational health and safety laws. However, the risk of environmental liabilities cannot be completely eliminated and there can be no assurance that the application of environmental and health and safety laws will not require us to incur significant expenditures. We are also regulated under a number of international, federal, state and local laws regarding recycling, product packaging and product content requirements. The environmental, product content/disposal and recycling laws are gradually becoming more stringent and may cause us to incur significant expenditures in the future.

- changed (2022-11-08):
[0001628280-22-028783:note_history:4]
We are subject to a variety of claims and suits that arise from time to time in the ordinary course of our business. While management currently believes that resolving claims against us, individually or in the aggregate, will not have a material adverse impact on our financial position, results of operations or statements of cash flows, these matters are subject to inherent
  (was, 2022-05-04, similarity 0.7565):
[0001628280-22-012157:note_history:4]
We are subject to a variety of claims and suits that arise from time to time in the ordinary course of our business. While management currently believes that resolving claims against us, individually or in the aggregate, will not have a material adverse impact on our financial position, results of operations or statements of cash flows, these matters are subject to inherent uncertainties and management’s view of these matters may change in the future. We accrue for loss contingencies when it is both probable that we will incur the loss and when we can reasonably estimate the amount of the loss or range of loss.

- added (2022-11-08):
[0001628280-22-028783:note_history:5]
uncertainties and management’s view of these matters may change in the future. We accrue for loss contingencies when it is both probable that we will incur the loss and when we can reasonably estimate the amount of the loss or range of loss.

- added (2022-11-08):
[0001628280-22-028783:note_history:6]
In connection with our acquisition of Oclaro in 2018, seven lawsuits were filed by purported stockholders of Oclaro challenging the proposed merger (the “Merger”). All but one was voluntarily dismissed after the Oclaro Merger closed.  The remaining lawsuit, SaiSravan B. Karri v. Oclaro, Inc., et al., No. 3:18-cv-03435-JD (the “Karri Lawsuit”), was filed in the United States District Court for the Northern District of California and is styled as a class action.

- changed (2022-11-08):
[0001628280-22-028783:note_history:7]
The Karri Lawsuit alleges, among other things, that Oclaro and its directors violated Section 14(a) of the Securities Exchange Act of 1934, as amended (the “Exchange Act”), and Rule 14a-9 promulgated thereunder by disseminating an incomplete and misleading Form S-4, including proxy statement/prospectus. The Karri Lawsuit further alleged that Oclaro’s directors violated Section 20(a) of the Exchange Act by failing to exercise proper control over the person(s) who violated Section 14(a) of the Exchange Act. The plaintiff in the Karri Lawsuit seeks, among other things, damages to be awarded to the plaintiff and any class, if a class is certified, and litigation costs, including attorneys’ fees.
  (was, 2022-05-04, similarity 0.807):
[0001628280-22-012157:note_history:7]
The Lawsuits generally alleged, among other things, that Oclaro and its directors violated Section 14(a) of the Securities Exchange Act of 1934, as amended (the “Exchange Act”), and Rule 14a-9 promulgated thereunder by disseminating an incomplete and misleading Form S-4, including proxy statement/prospectus. The Lawsuits further alleged that Oclaro’s directors violated Section 20(a) of the Exchange Act by failing to exercise proper control over the person(s) who violated Section 14(a) of the Exchange Act.

- added (2022-11-08):
[0001628280-22-028783:note_history:8]
After the plaintiff in the Karri Lawsuit was appointed as lead plaintiff and his counsel as lead counsel, the plaintiff filed a first amended complaint on April 15, 2019.  The first amended complaint, also named Lumentum as a defendant but Lumentum has since been dismissed from the action.  On October 8, 2020, the court granted in part and denied in part the defendant’s motion to dismiss the first amended complaint. On December 1, 2020, defendants answered the first amended complaint. On September 17, 2021, lead plaintiff filed a second amended complaint. Defendants moved to stay discovery in light of the second amended complaint. On January 11, 2022 the Court struck the second amended complaint as untimely, terminated defendants’ motions to dismiss as moot, and lifted the stay.

- added (2022-11-08):
[0001628280-22-028783:note_history:9]
On August 16, 2022, Plaintiff moved for class certification and to be appointed class representative.  Defendants opposed the motion.  A hearing on the motion is scheduled for November 17, 2022.  Defendants intend to continue to defend the Karri Lawsuit vigorously.

- added (2022-11-08):
[0001628280-22-028783:note_history:10]
In connection with our planned acquisition of NeoPhotonics Corporation (“NeoPhotonics”) announced in November 2021, ten lawsuits (the “NeoPhotonics Lawsuits”) were filed by purported stockholders of NeoPhotonics challenging the proposed merger (the “NeoPhotonics Merger”).  All of the NeoPhotonics Lawsuits have been dismissed.

- changed (2022-11-08):
[0001628280-22-028783:note_history:11]
In the normal course of business, we enter into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown because claims may be made against us in the future, and we may record charges in the future as a result of these indemnification obligations. As of October 1, 2022, we did not have any material indemnification claims that were probable or reasonably possible.
  (was, 2022-05-04, similarity 0.9868):
[0001628280-22-012157:note_history:11]
In the normal course of business, we enter into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown because claims may be made against us in the future, and we may record charges in the future as a result of these indemnification obligations. As of April 2, 2022, we did not have any material indemnification claims that were probable or reasonably possible.

- removed (2022-11-08):
[0001628280-22-012157:note_history:12]
Purchase obligations of $345.6 million as of April 2, 2022, represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements.

- removed (2022-11-08):
[0001628280-22-012157:note_history:13]
Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule and adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

- removed (2022-11-08):
[0001628280-22-012157:note_history:14]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 2, 2022 |  | April 3, 2021 |  | April 2, 2022 |  | April 3, 2021 |
| Balance as of beginning of period | $ | 8.6 |  |  | $ | 5.7 |  |  | $ | 5.0 |  |  | $ | 5.0 |  |
| Provision for warranty | 1.5 |  |  | 1.7 |  |  | 7.0 |  |  | 5.8 |  |
| Utilization of reserve | (1.0) |  |  | (1.8) |  |  | (2.9) |  |  | (5.2) |  |
| Balance as of end of period | $ | 9.1 |  |  | $ | 5.6 |  |  | $ | 9.1 |  |  | $ | 5.6 |  |

- removed (2022-11-08):
[0001628280-22-012157:note_history:15]
In connection with our acquisition of Oclaro, seven lawsuits were filed by purported stockholders of Oclaro challenging the proposed merger (the “Merger”). Two of the seven suits were putative class actions filed against Oclaro, its directors, Lumentum, Prota Merger Sub, Inc. and Prota Merger, LLC: Nicholas Neinast v. Oclaro, Inc., et al., No. 3:18-cv-03112-VC, in the United States District Court for the Northern District of California (filed May 24, 2018) (the “Neinast Lawsuit”); and Adam Franchi v. Oclaro, Inc., et al., No. 1:18-cv-00817-GMS, in the United States District Court for the District of Delaware (filed June 9, 2018) (the “Franchi Lawsuit”). Both the Neinstat Lawsuit and the Franchi Lawsuit were voluntarily dismissed with prejudice.

- removed (2022-11-08):
[0001628280-22-012157:note_history:16]
The other five suits, styled as Gerald F. Wordehoff v. Oclaro, Inc., et al., No. 5:18-cv-03148-NC (the “Wordehoff Lawsuit”), Walter Ryan v. Oclaro, Inc., et al., No. 3:18-cv-03174-VC (the “Ryan Lawsuit”), Jayme Walker v. Oclaro, Inc., et al., No. 5:18-cv-03203-EJD (the “Walker Lawsuit”), Kevin Garcia v. Oclaro, Inc., et al., No. 5:18-cv-03262-VKD (the “Garcia Lawsuit”), and SaiSravan B. Karri v. Oclaro, Inc., et al., No. 3:18-cv-03435-JD (the “Karri Lawsuit” and, together with the other six lawsuits, the “Lawsuits”), were filed in the United States District Court for the Northern District of California on May 25, 2018, May 29, 2018, May 30, 2018, May 31, 2018, and June 9, 2018, respectively. These five Lawsuits named Oclaro and its directors as defendants only and did not name Lumentum. The Wordehoff, Ryan, Walker, and Garcia Lawsuits have been voluntarily dismissed, and the Wordehoff, Ryan, and Walker dismissals were with prejudice. The Karri Lawsuit has not yet been dismissed. The Ryan Lawsuit was, and the Karri Lawsuit is, a putative class action.

- removed (2022-11-08):
[0001628280-22-012157:note_history:17]
The remaining Lawsuit (the Karri Lawsuit) currently purports to seek, among other things, damages to be awarded to the plaintiff and any class, if a class is certified, and litigation costs, including attorneys’ fees.  A lead plaintiff and counsel has been selected, and an amended complaint was filed on April 15, 2019, which also named Lumentum as a defendant. A motion to dismiss the amended complaint was granted in part and denied in part by the court on October 8, 2020. On December 1, 2020, defendants answered the amended complaint. On December 23, 2020, defendants filed a motion for leave to file a motion for reconsideration of the Court’s October 8th order on the motion to dismiss, which was denied on January 29, 2021. On June 22, 2021, the Court granted the parties’ stipulation to dismiss Lumentum as a defendant from the action.  On September 17, 2021, lead plaintiff filed a second amended complaint (“SAC”). Defendants moved to stay discovery in light of the SAC, and on January 11, 2022 the Court struck the SAC as untimely, terminated defendants’ motions to dismiss as moot, and lifted the stay.  The Karri Lawsuit remains pending with the parties currently in discovery. Defendants intend to defend the Karri Lawsuit vigorously.

- removed (2022-11-08):
[0001628280-22-012157:note_history:18]
In connection with our planned acquisition of NeoPhotonics Corporation (“NeoPhotonics”) announced in November 2021, ten lawsuits (the “NeoPhotonics Lawsuits”) were filed by purported stockholders of NeoPhotonics challenging the proposed merger (the “NeoPhotonics Merger”).  Four of the NeoPhotonics Lawsuits, styled as Elaine Wang v. NeoPhotonics Corporation, et al., No. 1:21-cv-10338, Heather Smith v. NeoPhotonics Corporation, et al., No. 1:21-cv-10698, Matthew Hopkins v. NeoPhotonics Corporation, et al., No. 1:21-cv-10725, and John Ryan v. NeoPhotonics Corporation, et al., No. 1:22-cv-00046, were filed in the United States District Court for the Southern District of New York on December 3, 2021, December 14, 2021, December 15, 2021, and January 4, 2022, respectively.  Three of the NeoPhotonics Lawsuits, styled as Mengsheng Ku v. NeoPhotonics Corporation, et al., No. 5:21-cv-09479, Stephen Bushansky v. NeoPhotonics Corporation, et al., No. 5:21-cv-09825, and James Parshall v. NeoPhotonics Corporation, et al., No. 5:22-cv-00055, were filed in the United States District Court for the Northern District of New York on December 8, 2021, December 20, 2021, and January 5, 2022, respectively. One NeoPhotonics Lawsuit, styled as James Hendrickson v. NeoPhotonics Corporation, et al., No. 1:21-cv-06919, was filed in the United States District Court for the Eastern District of New York on December 15, 2021. One NeoPhotonics Lawsuit, styled as Alex Ciccotelli v. NeoPhotonics Corporation, et al., No. 2:21-cv-05611, was filed in the United States District Court for the Eastern District of Pennsylvania on December 23, 2021. One NeoPhotonics Lawsuit, styled as Christopher Taylor v. NeoPhotonics Corporation, et al., No. 1:22-cv-00002, was filed in the United States District Court for the District of Delaware on January 3, 2022.

- removed (2022-11-08):
[0001628280-22-012157:note_history:19]
These ten NeoPhotonics Lawsuits name NeoPhotonics and its directors as defendants and do not name Lumentum.

- removed (2022-11-08):
[0001628280-22-012157:note_history:20]
The NeoPhotonics Lawsuits generally allege, among other things, that NeoPhotonics and its directors violated Section 14(a) of the Exchange Act, Rule 14a-9 promulgated thereunder, and 17 C.F.R. § 244.100 by disseminating an incomplete and misleading Preliminary Proxy Statement on Schedule 14A, filed with the SEC on December 1, 2021 regarding the NeoPhotonics Merger. The NeoPhotonics Lawsuits further allege that NeoPhotonics’ directors violated Section 20(a) of the Exchange Act by failing to exercise proper control over the person(s) who violated Section 14(a) of the Exchange Act. The complaints seek injunctive relief, rescission or rescissory damages, dissemination of a proxy statement that discloses certain information requested by the plaintiffs, and an award of plaintiffs’ costs, including attorneys’ fees and expenses.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2022-11-08):
[0001628280-22-028783:note_history:21]
Lumentum Holdings Inc. (“we,” “us,” “our”, “Lumentum” or the “Company”) is an industry-leading provider of optical and photonic products defined by revenue and market share addressing a range of end market applications including Optical Communications (“OpComms”) and Commercial Lasers (“Lasers”) for manufacturing, inspection and life-science applications. We seek to use our core optical and photonic technology, and our volume manufacturing capability, to expand into attractive emerging markets that benefit from advantages that optical or photonics-based solutions provide, including 3D sensing for consumer electronics and diode light sources for a variety of consumer and industrial applications. The majority of our customers are currently as well as historically original equipment manufacturers (“OEMs”) that incorporate our products into their products which then address end-market applications. For example, we sell fiber optic components that network equipment manufacturers (“NEMs”) assemble into communications networking systems, which they sell to communications service providers, hyperscale cloud operators, and enterprises with their own networks. Similarly, many of our Lasers products customers incorporate our products into tools they produce, which are used for manufacturing processes by their customers. For 3D sensing, we sell diode lasers to manufacturers of consumer electronics products for mobile, personal computing, gaming, and other applications, including to the automotive industry, who then integrate our devices within their products, for eventual resale to consumers and also into other industrial applications.
  (was, 2022-05-04, similarity 0.9856):
[0001628280-22-012157:note_history:21]
Lumentum Holdings Inc. (“we,” “us,” “our”, “Lumentum” or the “Company”) is an industry-leading provider of optical and photonic products defined by revenue and market share addressing a range of end market applications including Optical Communications (“OpComms”) and Commercial Lasers (“Lasers”) for manufacturing, inspection and life-science applications. We seek to use our core optical and photonic technology, and our volume manufacturing capability, to expand into attractive emerging markets that benefit from advantages that optical or photonics-based solutions provide, including 3D sensing for consumer electronics and diode light sources for a variety of consumer and industrial applications. The majority of our customers tend to be original equipment manufacturers (“OEMs”) that incorporate our products into their products which then address end-market applications. For example, we sell fiber optic components that network equipment manufacturers (“NEMs”) assemble into communications networking systems, which they sell to communications service providers, hyperscale cloud operators, and enterprises with their own networks. Similarly, many of our Lasers products customers incorporate our products into tools they produce, which are used for manufacturing processes by their customers. For 3D sensing, we sell diode lasers to manufacturers of consumer electronics products for mobile, personal computing, gaming, and other applications, including to the automotive industry, who then integrate our devices within their products, for eventual resale to consumers and also into other industrial applications.

- changed (2022-11-08):
[0001628280-22-028783:note_history:22]
The accompanying condensed consolidated financial statements have been prepared in accordance with U.S. generally accepted accounting principles (“GAAP”), which requires management to make estimates and assumptions that affect the amounts reported in our condensed consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact us in the future, actual results may be different from the estimates. Operating results for the quarter ended October 1, 2022 are not necessarily indicative of the results that may be expected for the fiscal year ending July 1, 2023. In the opinion of the Company’s management, the information presented herein reflects all normal and recurring adjustments necessary for a fair presentation of our results of operations, financial position, stockholders’ equity and cash flows. Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are inventory valuation, revenue recognition, income taxes, goodwill and business combinations.
  (was, 2022-05-04, similarity 0.6003):
[0001628280-22-012157:note_history:22]
The accompanying condensed consolidated financial statements have been prepared in accordance with U.S. generally accepted accounting principles (“GAAP”), which requires management to make estimates and assumptions that affect the amounts reported in our condensed consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact us in the future, actual results may be different from the estimates. Operating results for the quarter ended April 2, 2022 are not necessarily indicative of the results that may be expected for the fiscal year ending July 2, 2022. In the opinion of the Company’s management, the information presented herein reflects all normal and recurring adjustments necessary for a fair presentation of our results of operations, financial position, stockholders’ equity and cash flows.

- changed (2022-11-08):
[0001628280-22-028783:note_history:23]
While the impact of COVID-19 pandemic is lessening, the duration and severity of the impact of the pandemic on our business and results of operations in future periods remain uncertain. The extent of the impact of COVID-19 on our operational and financial performance will depend on certain developments, including but not limited to the duration and spread of the pandemic and its variants, implementation and duration of local, state and federal issued public health orders in each jurisdiction where we operate or in which our customers and suppliers operate, impact on our customers and our sales cycles, impact on our supply chain and manufacturing partners, impact on our employees and impact on regional and worldwide economies and financial markets in general, all of which are uncertain and cannot be predicted. We assessed the potential impact that this pandemic has on our estimates as of October 1, 2022 and determined that there were no material impacts. However, due to the global supply chain constraint, we have had to incur incremental supply and procurement costs in order to fulfill demand from our customers.  As of October 1, 2022, our inventory balance includes $21.9 million of incremental supply procurement costs.
  (was, 2022-05-04, similarity 0.6544):
[0001628280-22-012157:note_history:23]
We are now in the third year of the COVID-19 pandemic, and while the impact of the pandemic is lessening, new variants are causing continued concern. As these variants continue to emerge, efforts to mitigate or contain the impacts of the pandemic continue to evolve, and the duration and severity of the impact of the pandemic on our business and results of operations in future periods remain uncertain. The extent of the impact of COVID-19 on our operational and financial performance will depend on certain developments, including but not limited to the duration and spread of the pandemic and its variants, duration of local, state and federal issued public health orders in each jurisdiction where we operate or in which our customers and suppliers operate, impact on our customers and our sales cycles, impact on our supply chain and manufacturing partners, impact on our employees and impact on regional and worldwide economies and financial markets in general, all of which are uncertain and cannot be predicted. We assessed the potential impact that this pandemic has on our estimates as of April 2, 2022 and determined that there were no material impacts. However, due to the global supply chain constraint, we have had to incur incremental supply and procurement costs in order to fulfill demand from our customers. These higher costs have increased our inventory balances as of April 2, 2022 and may decrease our gross margin in the near term.

- changed (2022-11-08):
[0001628280-22-028783:note_history:24]
Business Combinations
  (was, 2022-05-04, similarity 0.9756):
[0001628280-22-012157:note_history:24]
Business Combination

- added (2022-11-08):
[0001628280-22-028783:note_history:25]
On August 3, 2022, we completed a merger with NeoPhotonics Corporation (“NeoPhotonics”). Our condensed consolidated financial statements include the operating results of NeoPhotonics for the period from the date of the closing of the merger through October 1, 2022. We have applied the acquisition method of accounting in accordance with ASC 805 Business Combinations to account for this transaction. Refer to “Note 4. Business Combinations” for further discussion of the merger.

- added (2022-11-08):
[0001628280-22-028783:note_history:26]
On August 15, 2022, we completed a transaction to acquire IPG Photonics’ telecom transmission product lines. Our condensed consolidated financial statements include the operating results of this business unit for the period from the date of the acquisition through October 1, 2022. We have applied the acquisition method of accounting in accordance with ASC 805 Business Combinations to account for this transaction. Refer to “Note 4. Business Combinations” for further discussion of this acquisition.

- changed (2022-11-08):
[0001628280-22-028783:note_history:27]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Every fifth or sixth fiscal year will have a 53-week period. The additional week in a 53-week year is added to the third quarter, making such quarter consist of 14 weeks. Our fiscal 2023 is a 52-week year ending on July 1, 2023, with the quarter ended October 1, 2022 being a 13-week quarterly period. Our fiscal 2022 was a 52-week year that ended on July 2, 2022, with the quarter ended October 2, 2021 being a 13-week quarterly period.
  (was, 2022-05-04, similarity 0.7407):
[0001628280-22-012157:note_history:27]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Every fifth or sixth fiscal year will have a 53-week period. The additional week in a 53-week year is added to the third quarter, making such quarter consist of 14 weeks. Our fiscal 2022 is a 52-week year ending on July 2, 2022, with the quarter ended April 2, 2022 being a 13-week quarterly period. Our fiscal 2021 was a 53-week year that ended on July 3, 2021, with the quarter ended April 3, 2021 being a 14-week quarterly period.

- changed (2022-11-08):
[0001628280-22-028783:note_history:28]
These interim unaudited condensed consolidated financial statements include the accounts of Lumentum Holdings Inc. and its wholly-owned subsidiaries. All inter-company transactions and balances are eliminated in consolidation.
  (was, 2022-05-04, similarity 0.9252):
[0001628280-22-012157:note_history:28]
These interim unaudited condensed consolidated financial statements include the accounts of the Company and its wholly-owned subsidiaries. All inter-company transactions and balances are eliminated in consolidation.

- added (2022-11-08):
[0001628280-22-028783:note_history:29]
The condensed consolidated financial statements and accompanying related notes should be read in conjunction with the audited consolidated financial statements and related notes included in our Annual Report on Form 10-K for the fiscal year ended July 2, 2022. 
Except for the accounting policies for convertible instruments as a result of our adoption of Accounting Standards Update (“ASU”) 2020-06, Debt—Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging—Contracts in Entity’s Own Equity (Subtopic 815-40): Accounting for Convertible Instruments and Contracts in an Entity’s Own Equity, there have been no significant changes to our accounting policies during the three months ended October 1, 2022.

- removed (2022-11-08):
[0001628280-22-012157:note_history:30]
Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are inventory valuation, revenue recognition, income taxes, long-lived asset valuation, goodwill and business combination.

- removed (2022-11-08):
[0001628280-22-012157:note_history:31]
The condensed consolidated financial statements and accompanying related notes should be read in conjunction with the audited consolidated financial statements and related notes included in our Annual Report on Form 10-K for the fiscal year ended July 3, 2021. There have been no significant changes to our accounting policies during the three and nine months ended April 2, 2022.

- removed (2022-11-08):
[0001628280-22-012157:note_history:32]
On November 4, 2021, Lumentum and NeoPhotonics Corporation (“NeoPhotonics”) announced a merger agreement (the “Merger Agreement”) pursuant to which Lumentum will acquire all outstanding shares of NeoPhotonics stock. Under the terms of the Merger Agreement, NeoPhotonics stockholders will receive $16.00 per share in cash for each NeoPhotonics share they own. As of April 2, 2022, the estimated total transaction consideration is expected to be approximately $918 million.  The cash consideration will be funded from the combined company’s balance sheet.

- removed (2022-11-08):
[0001628280-22-012157:note_history:33]
The Merger Agreement contains certain termination rights for both Lumentum and NeoPhotonics and provides that upon termination of the Merger Agreement under specified circumstances (including termination by NeoPhotonics to accept a superior proposal), NeoPhotonics may be required to pay Lumentum a termination fee of $27.5 million. The Merger Agreement further provides that if the Merger Agreement is terminated for failure to obtain antitrust approval, Lumentum may be required to pay NeoPhotonics a termination fee of $55.1 million; and if Lumentum takes certain specified actions, (including entering into any definitive agreement for an acquisition by stock purchase, merger, consolidation, amalgamation, purchase of assets, license or otherwise of any ownership interest or assets of any Person) that cause a material delay in, or results in the failure of, the consummation of the Merger, Lumentum may be required to pay NeoPhotonics an additional termination fee of $36.7 million.

- removed (2022-11-08):
[0001628280-22-012157:note_history:34]
The Boards of Directors of Lumentum and NeoPhotonics have unanimously approved the transaction and the Merger Agreement. On January 21, 2022, the waiting period under the Hart-Scott-Rodino Antitrust Improvements Act of 1976, as amended, expired with respect to the proposed acquisition. The transaction is subject to customary closing conditions, including the absence of certain legal impediments and receipt of any required antitrust and regulatory approvals. The transaction was approved by the NeoPhotonics stockholders on February 1, 2022. The transaction is not subject to any financing condition. We expect this transaction to be completed in the second half of calendar year 2022.

- removed (2022-11-08):
[0001628280-22-012157:note_history:35]
In connection with the Merger Agreement, on January 14, 2022, Lumentum and NeoPhotonics entered into a credit agreement where Lumentum agreed to make term loans (“loans”) to NeoPhotonics in an aggregate principal amount not to exceed $50.0 million to help fund capital expenditures and increased working capital associated with NeoPhotonics’ growth plans. During the three months ended April 2, 2022, the Company funded a $30.0 million loan request to NeoPhotonics, which bears interest at the Wall Street Journal “prime rate,” which was 3.5% as of April 2, 2022. The interest is payable monthly in arrears on the first day of each month. The loans will mature on January 14, 2024 unless earlier repaid or accelerated.

- removed (2022-11-08):
[0001628280-22-012157:note_history:36]
Termination of Coherent Merger Agreement

- removed (2022-11-08):
[0001628280-22-012157:note_history:37]
On January 18, 2021, Lumentum and Coherent, Inc. (“Coherent”) entered into a merger agreement, under which Lumentum would acquire all outstanding shares of Coherent common stock. As of the date of the merger agreement, the total transaction consideration was approximately $5.7 billion. In March 2021, Coherent terminated the merger agreement and paid 
Lumentum a termination fee of $217.6 million in accordance with the merger agreement. This gain was offset by $10.1 million of acquisition related expenses and the net amount is presented as “merger termination fee and related costs, net” in our condensed consolidated statements of operations for the three and nine months ended April 3, 2021.


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-11-08):
[0001628280-22-028783:note_history:38]
| Liability component: | October 1, 2022 |  | July 2, 2022 |
|  | 2024 Notes (1) |  | 2026 Notes (2) |  | 2028 Notes (3) |  | 2024 Notes (1) |  | 2026 Notes (2) |  | 2028 Notes (3) |
| Principal | $ | 448.1 |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |  | $ | 448.1 |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |
| Unamortized debt discount and issuance costs | (32.9) |  |  | (5.0) |  |  | (6.5) |  |  | (38.2) |  |  | (218.6) |  |  | (226.3) |  |
| Net carrying amount of the liability component | $ | 415.2 |  |  | $ | 1,045.0 |  |  | $ | 854.5 |  |  | $ | 409.9 |  |  | $ | 831.4 |  |  | $ | 634.7 |  |
  (was, 2022-05-04, similarity 0.8956):
[0001628280-22-012157:note_history:38]
| Liability component: | April 2, 2022 |  | July 3, 2021 |
|  | 2024 Notes (1) |  | 2026 Notes (2) |  | 2028 Notes (3) |  | 2024 Notes |  | 2026 Notes |
| Principal | $ | 450.0 |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |  | $ | 450.0 |  |  | $ | 1,050.0 |  |
| Unamortized debt discount and issuance costs | (43.9) |  |  | (229.2) |  |  | (234.2) |  |  | (59.3) |  |  | (260.2) |  |
| Net carrying amount of the liability component | $ | 406.1 |  |  | $ | 820.8 |  |  | $ | 626.8 |  |  | $ | 390.7 |  |  | $ | 789.8 |  |

- added (2022-11-08):
[0001628280-22-028783:note_history:39]
(1) If the closing price of our stock exceeds $78.80 (or 130% of the conversion price of $60.62) for 20 of the last 30 trading days of any future quarter, our 2024 Notes would become convertible at the option of the holders. During the fourth quarter of fiscal 2022, the 2024 Notes were convertible at the option of the holders and therefore, the debt component of our 2024 Notes was classified as current liabilities in our condensed consolidated balance sheet. While the 2024 Notes will not be convertible during the second quarter of fiscal 2023, as our stock price did not exceed $78.80 for 20 of the last 30 trading days of the quarter ended October 1, 2022, we continue to classify the 2024 Notes in current liabilities as this presentation provides consistency and better comparability with our prior periods.

- changed (2022-11-08):
[0001628280-22-028783:note_history:40]
(2) If the closing price of our stock exceeds $129.08 (or 130% of the conversion price of $99.29) for 20 of the last 30 trading days of any future quarter, our 2026 Notes would become convertible at the option of the holders and the debt would be reclassified to current liabilities in our condensed consolidated balance sheet.
  (was, 2022-05-04, similarity 0.9765):
[0001628280-22-012157:note_history:40]
(2) If the closing price of our stock exceeds $129.08 (or 130% of the conversion price of $99.29) for 20 of the last 30 trading days of any future quarter, our 2026 Notes would also become convertible at the option of the holders and the debt component would be reclassified to current liabilities in our condensed consolidated balance sheet.

- changed (2022-11-08):
[0001628280-22-028783:note_history:41]
(3) If the closing price of our stock exceeds $170.34 (or 130% of the conversion price of $131.03) for 20 of the last 30 trading days of such quarter, our 2028 Notes would become convertible at the option of the holders and the debt would be reclassified to current liabilities in our condensed consolidated balance sheet.
  (was, 2022-05-04, similarity 0.8685):
[0001628280-22-012157:note_history:41]
(3) During any fiscal quarter commencing after July 2, 2022, if the closing price of our stock exceeds $170.34 (or 130% of the conversion price of $131.03) for 20 of the last 30 trading days of such quarter, our 2028 Notes would also become convertible at the option of the holders and the debt component would be reclassified to current liabilities in our condensed consolidated balance sheet.

- removed (2022-11-08):
[0001628280-22-012157:note_history:42]
(1) Since the closing price of our stock exceeded $78.80 (or 130% of the conversion price of $60.62) for 20 of the last 30 trading days of the third quarter of fiscal 2022, the 2024 Notes have become convertible at the option of the holders. Therefore, the debt component of our 2024 Notes as of April 2, 2022 has been classified as current liabilities in our condensed consolidated balance sheet.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-11-08):
[0001628280-22-028783:note_history:43]
•during any fiscal quarter commencing after July 2, 2022 (and only during such fiscal quarter), if the last reported sale price of the Company’s common stock for at least 20 trading days (whether or not consecutive) during the 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price, or $170.34, on each applicable trading day;
  (was, 2022-05-04, similarity 0.6851):
[0001628280-22-012157:note_history:43]
•during any fiscal quarter commencing after July 2, 2022 (and only during such fiscal quarter), if the last reported sale price of the Company’s common stock for at least 20 trading days (whether or not consecutive) during the 30

- changed (2022-11-08):
[0001628280-22-028783:note_history:44]
We may redeem for cash all or any of the 2028 Notes, at our option (subject to the partial redemption limitation set forth in the 2028 Indenture), on or after June 20, 2025, if the last reported sale price of its common stock has been at least 130% of the conversion price then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading-day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which the Company provides notice of redemption at a redemption price equal to 100% of the principal amount of the 2028 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. No sinking fund is provided for the 2028 Notes. If we elect to redeem fewer than all of the outstanding 2028 Notes, at least $100.0 million aggregate principal amount of the 2028 Notes must be outstanding and not subject to redemption as of the redemption notice date. Upon the occurrence of a fundamental change (as defined in the 2028 Indenture), holders may require the Company to
  (was, 2022-05-04, similarity 0.9031):
[0001628280-22-012157:note_history:44]
We may redeem for cash all or any of the 2028 Notes, at our option (subject to the partial redemption limitation set forth in the 2028 Indenture), on or after June 20, 2025, if the last reported sale price of its common stock has been at least 130% of the conversion price then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading-day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which the Company provides notice of redemption at a redemption price equal to 100% of the principal amount of the 2028 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. No sinking fund is provided for the 2028 Notes. If we elect to redeem fewer than all of the outstanding 2028 Notes, at least $100.0 million aggregate principal amount of the 2028 Notes must be outstanding and not subject to redemption as of the redemption notice date.  Upon the occurrence of a fundamental change (as defined in the 2028 Indenture), holders may require the Company to repurchase all or a portion of their 2028 Notes for cash at a price equal to 100% of the principal amount of the 2028 Notes to be repurchased, plus any accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

- added (2022-11-08):
[0001628280-22-028783:note_history:45]
repurchase all or a portion of their 2028 Notes for cash at a price equal to 100% of the principal amount of the 2028 Notes to be repurchased, plus any accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

- changed (2022-11-08):
[0001628280-22-028783:note_history:46]
We initially bifurcated the principal amount of the 2028 Notes into liability and equity components. The liability component of the 2028 Notes was initially valued at $629.8 million based on the contractual cash flow discounted at an appropriate comparable market on non-convertible debt borrowing rate at the date of issuance, which was 5.7%, with the equity component representing the residual amount of the proceeds of $231.2 million, which was recorded as a debt discount. Upon adoption of ASU 2020-06 in the first quarter of fiscal 2023, our 2028 Notes were accounted for as a single liability measured at amortized cost. Refer to “Note 2. Recently Issued Accounting Pronouncement” for the detailed adoption impact.
  (was, 2022-05-04, similarity 0.6921):
[0001628280-22-012157:note_history:46]
We bifurcated the principal amount of the 2028 Notes into liability and equity components.  The liability component of the 2028 Notes was valued at $629.8 million based on the contractual cash flow discounted at an appropriate comparable market on non-convertible debt borrowing rate at the date of issuance, which was 5.7%, with the equity component representing the residual amount of the proceeds of $231.2 million, which was recorded as a debt discount.  The issuance and other related costs of $6.9 million were allocated pro rata based on the relative carrying amounts of the liability and equity components.

- changed (2022-11-08):
[0001628280-22-028783:note_history:47]
In December 2019, we issued $1,050.0 million in aggregate principal amount of 0.50% Convertible Notes due in 2026 (the “2026 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act. The 2026 Notes are governed by an indenture between the Company and U.S. Bank Trust Company National Association (as successor in interest to U.S. Bank National Association, as a trustee (the “2026 Indenture”). We used approximately $196.0 million of the net proceeds of the offering to repay in full all amounts outstanding under our term loan credit facility, and a portion of the net proceeds of the offering to purchase approximately $200.0 million of our common stock concurrently with the pricing of the offering in privately negotiated transactions. The 2026 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.
  (was, 2022-05-04, similarity 0.9979):
[0001628280-22-012157:note_history:47]
In December 2019, we issued $1,050.0 million in aggregate principal amount of 0.50% Convertible Notes due in 2026 (the “2026 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities. The 2026 Notes are governed by an indenture between the Company and U.S. Bank Trust Company National Association (as successor in interest to U.S. Bank National Association, as a trustee (the “2026 Indenture”). We used approximately $196.0 million of the net proceeds of the offering to repay in full all amounts outstanding under our term loan credit facility, and a portion of the net proceeds of the offering to purchase approximately $200.0 million of our common stock concurrently with the pricing of the offering in privately negotiated transactions. The 2026 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

- changed (2022-11-08):
[0001628280-22-028783:note_history:48]
The initial conversion rate is 10.0711 shares of common stock per $1,000 principal amount of the 2026 Notes (which is equivalent to an initial conversion price of approximately $99.29 per share). The conversion rate is subject to adjustment upon the occurrence of certain events specified in the 2026 Indenture but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares set forth in the 2026 Indenture or a holder that elects to convert the 2026 Notes in connection with such make-whole fundamental change or notice of redemption.
  (was, 2022-05-04, similarity 0.9498):
[0001628280-22-012157:note_history:48]
The initial conversion rate is 10.0711 shares of common stock per $1,000 principal amount of the 2026 Notes (which is equivalent to an initial conversion price of approximately $99.29 per share). The conversion rate is subject to adjustment upon the occurrence of certain specified events but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert the 2026 Notes in connection with such make-whole fundamental change or notice of redemption.

- changed (2022-11-08):
[0001628280-22-028783:note_history:49]
Prior to the close of business on the business day immediately preceding September 15, 2026, holders of the 2026 Notes may convert their 2026 Notes only under the following circumstances:
  (was, 2022-05-04, similarity 0.6934):
[0001628280-22-012157:note_history:49]
Prior to the close of business on the business day immediately preceding September 15, 2026, holders of the 2026 Notes may convert their 2026 Notes only under certain circumstances discussed in detail in our Annual Report on Form 10-K for the year ended July 3, 2021.

- changed (2022-11-08):
[0001628280-22-028783:note_history:50]
•during any fiscal quarter (and only during such fiscal quarter), if the last reported sale price of the common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price of the 2026 Notes, or $129.08 on each applicable trading day;
  (was, 2022-05-04, similarity 0.6156):
[0001628280-22-012157:note_history:50]
consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% if the applicable conversion price on each applicable trading day;

- added (2022-11-08):
[0001628280-22-028783:note_history:51]
•during the five business day period after any five consecutive trading day period (the "2026 measurement period") in which the trading price per $1,000 principal amount of the 2026 Notes for each trading day of the 2026 measurement period was less than 98% of the product of the last reported sale price of our common stock and the conversion rate for the 2026 Notes on each such trading day;

- added (2022-11-08):
[0001628280-22-028783:note_history:52]
•if we call any or all of the 2026 Notes for redemption, at any time prior to the close of business on the second business day immediately preceding the relevant redemption date; or

- added (2022-11-08):
[0001628280-22-028783:note_history:53]
•upon the occurrence of specified corporate events.

- added (2022-11-08):
[0001628280-22-028783:note_history:54]
On or after September 15, 2026 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert the 2026 Notes at any time. Upon conversion, we may satisfy our conversion obligation in cash, shares of common stock or a combination of cash and shares of common stock, at our election.

- added (2022-11-08):
[0001628280-22-028783:note_history:55]
We may redeem for cash, for all or any portion of the 2026 Notes, at our option, on or after December 20, 2023, if the last reported sale price of its common stock has been at least 130% of the conversion price then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading-day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which we provide a notice of redemption at a redemption price equal to 100% of the principal amount of the 2026 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. No sinking fund is provided for the 2026 Notes. Upon the occurrence of a fundamental change (as defined in the 2026 Indenture), holders may require us to repurchase all or a portion of the 2026 Notes for cash at a

- added (2022-11-08):
[0001628280-22-028783:note_history:56]
price equal to 100% of the principal amount of the 2026 Notes to be repurchased, plus any accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

- added (2022-11-08):
[0001628280-22-028783:note_history:57]
We initially bifurcated the principal amount of the 2026 Notes into liability and equity components. The liability component of the 2026 Notes was initially valued at $734.8 million based on the contractual cash flows discounted at an appropriate comparable market non-convertible debt borrowing rate at the date of issuance of 5.8% with the equity component representing the residual amount of the proceeds of $315.2 million, which was recorded as a debt discount. Upon adoption of ASU 2020-06 in the first quarter of fiscal 2023, our 2026 Notes were accounted for as a single liability measured at amortized cost.  Refer to “Note 2. Recently Issued Accounting Pronouncement” for the detailed adoption impact.

- changed (2022-11-08):
[0001628280-22-028783:note_history:58]
In March 2017, we issued $450.0 million in aggregate principal amount 2024 Notes in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act. The 2024 Notes are governed by an indenture between the Company, as the issuer, and U.S. Bank Trust Company National Association (as successor in interest to U.S. Bank National Association), as trustee (the “2024 Indenture”). The 2024 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.
  (was, 2022-05-04, similarity 0.9285):
[0001628280-22-012157:note_history:58]
In March 2017, we issued $450 million of 0.25% Convertible Notes due in 2024 (the “2024 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act. The 2024 Notes are governed by an indenture between the Company, as the issuer, and U.S. Bank Trust Company National Association (as successor in interest to U.S. Bank National Association), as trustee (the “2024 Indenture”). The 2024 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

- added (2022-11-08):
[0001628280-22-028783:note_history:59]
The initial conversion rate of the 2024 Notes is 16.4965 shares of common stock per $1,000 principal amount of 2024 Notes, which is equivalent to an initial conversion price of approximately $60.62 per share, a 132.5% premium to the fair market value at the date of issuance.  Prior to the close of business on the business day immediately preceding December 15, 2023, each holder of the 2024 Notes may convert their 2024 Notes only under the following circumstances:

- added (2022-11-08):
[0001628280-22-028783:note_history:60]
•during any fiscal quarter (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during the period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price, or $78.80 on each applicable trading day;

- added (2022-11-08):
[0001628280-22-028783:note_history:61]
•during the five consecutive business day period after any five consecutive trading day period (the “2024 measurement period”) in which the trading price per $1,000 principal amount of 2024 Notes for each trading day of such 2024 measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate on each such trading day;

- added (2022-11-08):
[0001628280-22-028783:note_history:62]
•upon the occurrence of specified corporate events.

- added (2022-11-08):
[0001628280-22-028783:note_history:63]
On or after December 15, 2023 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their 2024 Notes at any time. In addition, upon the occurrence of a make-whole fundamental change (as defined in the 2024 Indenture), we will, in certain circumstances, increase the conversion rate by a number of additional shares set forth in the 2024 Indenture for a holder that elects to convert 2024 Notes in connection with such make-whole fundamental change.

- added (2022-11-08):
[0001628280-22-028783:note_history:64]
We may not redeem the 2024 Notes prior to their maturity date and no sinking fund is provided for the 2024 Notes. Upon the occurrence of a fundamental change, holders may require us to repurchase all or a portion of their 2024 Notes for cash at a price equal to 100% of the principal amount of the 2024 Notes to be repurchased, plus any accrued and unpaid interest.

- added (2022-11-08):
[0001628280-22-028783:note_history:65]
During the three months ended October 1, 2022, we received conversion requests of less than $0.1 million principal amount of the 2024 Notes, which we settled with cash in accordance with the 2024 Indenture. Since issuing the 2024 Notes, we have converted a total of approximately $1.9 million principal amount of the 2024 Notes. The remaining principal amount of the 2024 Notes as of October 1, 2022 was $448.1 million.

- added (2022-11-08):
[0001628280-22-028783:note_history:66]
We considered the features embedded in the 2024 Notes other than the conversion feature, including the holders’ put feature, our call feature, and the make-whole feature, and concluded that they are not required to be bifurcated and accounted for separately from the host debt instrument. Prior to the Tax Matters Agreement settlement condition (“TMA settlement condition”), because we could only settle the 2024 Notes in cash, we determined that the conversion feature met the definition of a derivative liability. We separated the derivative liability from the host debt instrument based on the fair value of the derivative liability. During fiscal 2017, we satisfied the TMA settlement condition. As such, the value of the conversion option

- added (2022-11-08):
[0001628280-22-028783:note_history:67]
is no longer marked-to-market and was reclassified to additional paid-in capital within stockholders’ equity on our condensed consolidated balance sheets. The adoption of ASU 2020-06 did not change the presentation of the 2024 Notes, as the conversion feature associated with the 2024 Notes continues to be classified within stockholders’ equity.

- added (2022-11-08):
[0001628280-22-028783:note_history:68]
Convertible Notes - Additional Disclosures

- changed (2022-11-08):
[0001628280-22-028783:note_history:69]
| Liability component: | October 1, 2022 |  | July 2, 2022 |
|  | 2024 Notes (1) |  | 2026 Notes (2) |  | 2028 Notes (3) |  | 2024 Notes (1) |  | 2026 Notes (2) |  | 2028 Notes (3) |
| Principal | $ | 448.1 |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |  | $ | 448.1 |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |
| Unamortized debt discount and issuance costs | (32.9) |  |  | (5.0) |  |  | (6.5) |  |  | (38.2) |  |  | (218.6) |  |  | (226.3) |  |
| Net carrying amount of the liability component | $ | 415.2 |  |  | $ | 1,045.0 |  |  | $ | 854.5 |  |  | $ | 409.9 |  |  | $ | 831.4 |  |  | $ | 634.7 |  |
  (was, 2022-05-04, similarity 0.8956):
[0001628280-22-012157:note_history:69]
| Liability component: | April 2, 2022 |  | July 3, 2021 |
|  | 2024 Notes (1) |  | 2026 Notes (2) |  | 2028 Notes (3) |  | 2024 Notes |  | 2026 Notes |
| Principal | $ | 450.0 |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |  | $ | 450.0 |  |  | $ | 1,050.0 |  |
| Unamortized debt discount and issuance costs | (43.9) |  |  | (229.2) |  |  | (234.2) |  |  | (59.3) |  |  | (260.2) |  |
| Net carrying amount of the liability component | $ | 406.1 |  |  | $ | 820.8 |  |  | $ | 626.8 |  |  | $ | 390.7 |  |  | $ | 789.8 |  |

- added (2022-11-08):
[0001628280-22-028783:note_history:70]
(1) If the closing price of our stock exceeds $78.80 (or 130% of the conversion price of $60.62) for 20 of the last 30 trading days of any future quarter, our 2024 Notes would become convertible at the option of the holders. During the fourth quarter of fiscal 2022, the 2024 Notes were convertible at the option of the holders and therefore, the debt component of our 2024 Notes was classified as current liabilities in our condensed consolidated balance sheet. While the 2024 Notes will not be convertible during the second quarter of fiscal 2023, as our stock price did not exceed $78.80 for 20 of the last 30 trading days of the quarter ended October 1, 2022, we continue to classify the 2024 Notes in current liabilities as this presentation provides consistency and better comparability with our prior periods.

- changed (2022-11-08):
[0001628280-22-028783:note_history:71]
(2) If the closing price of our stock exceeds $129.08 (or 130% of the conversion price of $99.29) for 20 of the last 30 trading days of any future quarter, our 2026 Notes would become convertible at the option of the holders and the debt would be reclassified to current liabilities in our condensed consolidated balance sheet.
  (was, 2022-05-04, similarity 0.9765):
[0001628280-22-012157:note_history:71]
(2) If the closing price of our stock exceeds $129.08 (or 130% of the conversion price of $99.29) for 20 of the last 30 trading days of any future quarter, our 2026 Notes would also become convertible at the option of the holders and the debt component would be reclassified to current liabilities in our condensed consolidated balance sheet.

- changed (2022-11-08):
[0001628280-22-028783:note_history:72]
(3) If the closing price of our stock exceeds $170.34 (or 130% of the conversion price of $131.03) for 20 of the last 30 trading days of such quarter, our 2028 Notes would become convertible at the option of the holders and the debt would be reclassified to current liabilities in our condensed consolidated balance sheet.
  (was, 2022-05-04, similarity 0.8685):
[0001628280-22-012157:note_history:72]
(3) During any fiscal quarter commencing after July 2, 2022, if the closing price of our stock exceeds $170.34 (or 130% of the conversion price of $131.03) for 20 of the last 30 trading days of such quarter, our 2028 Notes would also become convertible at the option of the holders and the debt component would be reclassified to current liabilities in our condensed consolidated balance sheet.

- added (2022-11-08):
[0001628280-22-028783:note_history:73]
|  | Three Months Ended |  |  |
|  | October 1, 2022 |  | October 2, 2021 |  |  |  |  |
| Contractual interest expense | $ | 2.7 |  |  | $ | 1.6 |  |  |  |  |  |
| Amortization of the debt discount and debt issuance costs | 5.7 |  |  | 15.3 |  |  |  |  |  |
| Total interest expense | $ | 8.4 |  |  | $ | 16.9 |  |  |  |  |  |

- changed (2022-11-08):
[0001628280-22-028783:note_history:74]
The future interest and principal payments related to our convertible notes are as follows as of October 1, 2022 (in millions):
  (was, 2022-05-04, similarity 0.959):
[0001628280-22-012157:note_history:74]
The future interest and principal payments related to our convertible notes are as follows as of April 2, 2022 (in millions):

- changed (2022-11-08):
[0001628280-22-028783:note_history:75]
| Fiscal Years | 2024 Notes |  | 2026 Notes |  | 2028 Notes |  | Total |
| Remainder of 2023 | $ | 0.6 |  |  | $ | 5.3 |  |  | $ | 4.3 |  |  | $ | 10.2 |  |
| 2024 | 449.2 |  |  | 5.3 |  |  | 4.3 |  |  | 458.8 |  |
| 2025 | — |  |  | 5.3 |  |  | 4.3 |  |  | 9.6 |  |
| 2026 | — |  |  | 5.3 |  |  | 4.3 |  |  | 9.6 |  |
| 2027 | — |  |  | 1,052.4 |  |  | 869.6 |  |  | 1,922.0 |  |
| Total convertible notes payments | $ | 449.8 |  |  | $ | 1,073.6 |  |  | $ | 886.8 |  |  | $ | 2,410.2 |  |
  (was, 2022-05-04, similarity 0.9372):
[0001628280-22-012157:note_history:75]
| Fiscal Years | 2024 Notes |  | 2026 Notes |  | 2028 Notes |  | Total |
| Remainder of 2022 | $ | 1.8 |  |  | $ | 2.7 |  |  | $ | 1.2 |  |  | $ | 5.7 |  |
| 2023 | 1.1 |  |  | 5.3 |  |  | 4.3 |  |  | 10.7 |  |
| 2024 | 449.4 |  |  | 5.3 |  |  | 4.3 |  |  | 459.0 |  |
| 2025 | — |  |  | 5.3 |  |  | 4.3 |  |  | 9.6 |  |
| 2026 | — |  |  | 5.3 |  |  | 4.3 |  |  | 9.6 |  |
| Thereafter | — |  |  | 1,052.4 |  |  | 869.6 |  |  | 1,922.0 |  |
| Total convertible notes payments | $ | 452.3 |  |  | $ | 1,076.3 |  |  | $ | 888.0 |  |  | $ | 2,416.6 |  |

- changed (2022-11-08):
[0001628280-22-028783:note_history:76]
The principal balances of our convertible notes are reflected in the payment periods in the table above based on their respective contractual maturities.
  (was, 2022-05-04, similarity 0.9592):
[0001628280-22-012157:note_history:76]
The principal balances of our Notes are reflected in the payment periods in the table above based on their respective contractual maturities.

- added (2022-11-08):
[0001628280-22-028783:note_history:77]
Mitsubishi Bank Loans

- added (2022-11-08):
[0001628280-22-028783:note_history:78]
In connection with our merger of NeoPhotonics, we assumed several loan agreements with MUFG Bank, Ltd. (the “Mitsubishi Bank”).

- added (2022-11-08):
[0001628280-22-028783:note_history:79]
In February 2015, NeoPhotonics entered into a loan agreement with Mitsubishi Bank, that provided for a term loan in the aggregate principal amount of 1.0 billion JPY (approximately $6.9 million based on the exchange rate on October 1, 2022) (the “2015 Mitsubishi Bank Loan”). The 2015 Mitsubishi Bank Loan is secured by a mortgage on certain real property and buildings owned by NeoPhotonic’s Japanese subsidiary. The 2015 Mitsubishi Bank Loan accrues interest and is paid monthly based upon the annual rate of the monthly Tokyo Interbank Offer Rate ("TIBOR") plus 1.40%.  The term loan requires equal monthly payments of principal equal to 8.3 million JPY (approximately $0.1 million based on the exchange rate on October 1, 2022) until the maturity date of February 25, 2025, with a lump sum payment of the balance of 8.4 million JPY (approximately $0.1 million based on the exchange rate on October 1, 2022) on the maturity date.  The outstanding principal balance for the 2015 Mitsubishi Bank Loan was 241.7 million JPY (approximately $1.6 million) as of October 1, 2022.

- added (2022-11-08):
[0001628280-22-028783:note_history:80]
In March 2017, NeoPhotonics entered into a loan agreement with Mitsubishi Bank for a term loan of 690.0 million JPY (approximately $4.8 million based on the exchange rate on October 1, 2022) (the “2017 Mitsubishi Bank Loan”) to acquire manufacturing equipment for its Japanese subsidiary. This loan is secured by the manufacturing equipment owned by the NeoPhotonics' subsidiary in Japan. Interest on the 2017 Mitsubishi Bank Loan is based on the annual rate of the monthly TIBOR rate plus 1.00%. The 2017 Mitsubishi Bank Loan matures on March 29, 2024 and requires monthly interest and principal payments over 72 months commencing in April 2018. The outstanding principal balance for the 2017 Mitsubishi Bank Loan was 172.5 million JPY (approximately $1.3 million) as of October 1, 2022.

- added (2022-11-08):
[0001628280-22-028783:note_history:81]
In January 2018, NeoPhotonics entered into a term loan agreement with Mitsubishi Bank and The Yamanashi Chuo Bank, Ltd. for a term loan in the aggregate principal amount of 850.0 million JPY (approximately $5.9 million based on the exchange rate on October 1, 2022) (the “2018 Mitsubishi Bank Loan”). The purpose of this term loan was to obtain machinery for the core parts of the manufacturing line and payments for related expenses by NeoPhotonics' subsidiary in Japan. This term loan requires no additional security. Interest on the term loan is based upon the annual rate of the three months TIBOR rate plus 1.00%. The term loan requires quarterly interest payments, along with the principal payments, over 82 months commencing in April 2018. The outstanding principal balance for the 2018 Mitsubishi Bank Loan was approximately 303.6 million JPY (approximately $2.1 million) as of October 1, 2022.

- added (2022-11-08):
[0001628280-22-028783:note_history:82]
All of these term loans contain customary representations and warranties, and customary affirmative and negative covenants applicable to NeoPhotonics’ Japanese subsidiary, including, among other things, restrictions on cessation in business, management, mergers or acquisitions. These term loans contain customary covenants relating to minimum net assets, maximum ordinary loss and a coverage ratio covenant. We are in compliance with the related covenants for all these term loans as of October 1, 2022.

- added (2022-11-08):
[0001628280-22-028783:note_history:83]
We intend to repay all amounts outstanding under the 2015 Mitsubishi Bank Loan, 2017 Mitsubishi Bank Loan and 2018 Mitsubishi Bank Loan during fiscal year 2023. As such, we presented these term loans within short term debt in our condensed consolidated balance sheet.

- removed (2022-11-08):
[0001628280-22-012157:note_history:84]
The debt discount and debt issuance costs attributable to the liability component will be amortized to interest expense using an effective interest rate of 5.7% over the expected life of the 2028 Notes.  Debt issuance costs attributable to the equity component are netted against the equity component in stockholders’ equity, and the equity component is not remeasured as long as it continues to meet the conditions for equity classification.

- removed (2022-11-08):
[0001628280-22-012157:note_history:85]
The initial conversion rate of the 2024 Notes is 16.4965 shares of common stock per $1,000 principal amount of 2024 Notes, which is equivalent to an initial conversion price of approximately $60.62 per share. Prior to the close of business on the business day immediately preceding December 15, 2023, each holder of the 2024 Notes may convert their 2024 Notes only under certain circumstances discussed in detail in our Annual Report on Form 10-K for the year ended July 3, 2021.

- removed (2022-11-08):
[0001628280-22-012157:note_history:86]
During the nine months ended April 2, 2022, we received and settled in cash, conversion requests of less than $0.1 million principal amount of the 2024 Notes. From April 1, 2022 through May 4, 2022, we received requests for conversion of approximately $1.8 million in principal amount of the 2024 Notes. Such conversion will be settled in the fourth quarter of fiscal 2022 with a combination of cash and shares of the Company’s common stock in accordance with the applicable indenture.

- removed (2022-11-08):
[0001628280-22-012157:note_history:87]
Convertible Notes

- removed (2022-11-08):
[0001628280-22-012157:note_history:88]
(1) Since the closing price of our stock exceeded $78.80 (or 130% of the conversion price of $60.62) for 20 of the last 30 trading days of the third quarter of fiscal 2022, the 2024 Notes have become convertible at the option of the holders. Therefore, the debt component of our 2024 Notes as of April 2, 2022 has been classified as current liabilities in our condensed consolidated balance sheet.

- removed (2022-11-08):
[0001628280-22-012157:note_history:89]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 2, 2022 |  | April 3, 2021 |  | April 2, 2022 |  | April 3, 2021 |
| Contractual interest expense | $ | 1.9 |  |  | $ | 1.6 |  |  | $ | 5.1 |  |  | $ | 4.8 |  |
| Amortization of the debt discount and debt issuance costs | 17.8 |  |  | 14.8 |  |  | 48.6 |  |  | 43.9 |  |
| Total interest expense | $ | 19.7 |  |  | $ | 16.4 |  |  | $ | 53.7 |  |  | $ | 48.7 |  |


## us-gaap:DebtSecuritiesAvailableForSaleUnrealizedLossPositionFairValueTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-11-08):
[0001628280-22-028783:note_history:90]
|  | Fair Value |  | Unrealized Losses |  |  |  |  |  |  |  |  |
| October 1, 2022: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | 86.4 |  |  | (1.8) |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | 6.4 |  |  | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | 90.2 |  |  | (0.4) |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 334.4 |  |  | (5.0) |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 262.5 |  |  | (3.7) |  |  |  |  |  |  |  |  |  |
| Total | $ | 779.9 |  |  | $ | (10.9) |  |  |  |  |  |  |  |  |  |
| July 2, 2022: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | 73.7 |  |  | $ | (1.4) |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | 16.2 |  |  | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | 130.7 |  |  | (0.4) |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 473.2 |  |  | (6.5) |  |  |  |  |  |  |  |  |  |
| Municipal bonds | 1.0 |  |  | — |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 366.0 |  |  | (4.2) |  |  |  |  |  |  |  |  |  |
| Total | $ | 1,060.8 |  |  | $ | (12.5) |  |  |  |  |  |  |  |  |  |
  (was, 2022-05-04, similarity 0.7534):
[0001628280-22-012157:note_history:90]
|  | Fair Value |  | Unrealized Losses |  |  |  |  |  |  |  |  |
| April 2, 2022: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | 64.0 |  |  | (1.2) |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | 11.3 |  |  | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | 253.3 |  |  | (0.1) |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 639.3 |  |  | (6.6) |  |  |  |  |  |  |  |  |  |
| Municipal bonds | 1.0 |  |  | — |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 566.3 |  |  | (3.5) |  |  |  |  |  |  |  |  |  |
| Total | $ | 1,535.2 |  |  | $ | (11.4) |  |  |  |  |  |  |  |  |  |
| July 3, 2021: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | 28.3 |  |  | $ | — |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | 6.0 |  |  | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | 43.0 |  |  | — |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 432.3 |  |  | (0.4) |  |  |  |  |  |  |  |  |  |
| Municipal bonds | 1.0 |  |  | — |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 106.9 |  |  | — |  |  |  |  |  |  |  |  |  |
| Total | $ | 617.5 |  |  | $ | (0.4) |  |  |  |  |  |  |  |  |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-11-08):
[0001628280-22-028783:note_history:91]
The future interest and principal payments related to our convertible notes are as follows as of October 1, 2022 (in millions):
  (was, 2022-05-04, similarity 0.959):
[0001628280-22-012157:note_history:91]
The future interest and principal payments related to our convertible notes are as follows as of April 2, 2022 (in millions):

- changed (2022-11-08):
[0001628280-22-028783:note_history:92]
| Fiscal Years | 2024 Notes |  | 2026 Notes |  | 2028 Notes |  | Total |
| Remainder of 2023 | $ | 0.6 |  |  | $ | 5.3 |  |  | $ | 4.3 |  |  | $ | 10.2 |  |
| 2024 | 449.2 |  |  | 5.3 |  |  | 4.3 |  |  | 458.8 |  |
| 2025 | — |  |  | 5.3 |  |  | 4.3 |  |  | 9.6 |  |
| 2026 | — |  |  | 5.3 |  |  | 4.3 |  |  | 9.6 |  |
| 2027 | — |  |  | 1,052.4 |  |  | 869.6 |  |  | 1,922.0 |  |
| Total convertible notes payments | $ | 449.8 |  |  | $ | 1,073.6 |  |  | $ | 886.8 |  |  | $ | 2,410.2 |  |
  (was, 2022-05-04, similarity 0.9372):
[0001628280-22-012157:note_history:92]
| Fiscal Years | 2024 Notes |  | 2026 Notes |  | 2028 Notes |  | Total |
| Remainder of 2022 | $ | 1.8 |  |  | $ | 2.7 |  |  | $ | 1.2 |  |  | $ | 5.7 |  |
| 2023 | 1.1 |  |  | 5.3 |  |  | 4.3 |  |  | 10.7 |  |
| 2024 | 449.4 |  |  | 5.3 |  |  | 4.3 |  |  | 459.0 |  |
| 2025 | — |  |  | 5.3 |  |  | 4.3 |  |  | 9.6 |  |
| 2026 | — |  |  | 5.3 |  |  | 4.3 |  |  | 9.6 |  |
| Thereafter | — |  |  | 1,052.4 |  |  | 869.6 |  |  | 1,922.0 |  |
| Total convertible notes payments | $ | 452.3 |  |  | $ | 1,076.3 |  |  | $ | 888.0 |  |  | $ | 2,416.6 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-11-08):
[0001628280-22-028783:note_history:93]
The table below discloses our total net revenue attributable to each of our two reportable segments. In addition, the table sets forth the percentage of our total net revenue attributable to our product offerings that serve Telecom and Datacom, and Consumer and Industrial markets  accounted for 10% or more of our total net revenue during the periods presented (in millions, except percentage data):
  (was, 2022-05-04, similarity 0.9813):
[0001628280-22-012157:note_history:93]
The table below discloses our total net revenue attributable to each of our two reportable segments. In addition, the table sets forth the percentage of our total net revenue attributable to our product offerings which serve Telecom and Datacom, and Consumer and Industrial markets which accounted for 10% or more of our total net revenue during the periods presented (in millions, except percentage data):

- changed (2022-11-08):
[0001628280-22-028783:note_history:94]
|  | Three Months Ended |  |  |
|  | October 1, 2022 |  | October 2, 2021 |  |  |  |  |
| OpComms: |  |  |  |  |  |  |  |  |  |  |  |
| Telecom and Datacom | $ | 360.1 |  | 71.1 | % |  | $ | 216.0 |  | 48.2 | % |  |  |  |  |  |  |
| Industrial and Consumer | 93.3 |  | 18.4 |  |  | 190.0 |  | 42.3 | % |  |  |  |  |  |  |
| Total OpComms | $ | 453.4 |  | 89.5 | % |  | $ | 406.0 |  | 90.5 | % |  |  |  |  |  |  |
| Lasers | 53.4 |  | 10.5 | % |  | 42.4 |  | 9.5 | % |  |  |  |  |  |  |
| Net Revenue | $ | 506.8 |  |  |  | $ | 448.4 |  |  |  |  |  |  |  |  |
  (was, 2022-05-04, similarity 0.6098):
[0001628280-22-012157:note_history:94]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 2, 2022 |  | April 3, 2021 |  | April 2, 2022 |  | April 3, 2021 |
| OpComms: |  |  |  |  |  |  |  |  |  |  |  |
| Telecom and Datacom | $ | 243.5 |  | 61.6 | % |  | $ | 255.8 |  | 61.0 | % |  | $ | 726.6 |  | 56.3 | % |  | $ | 803.3 |  | 59.5 | % |
| Industrial and Consumer | 100.7 |  | 25.5 |  |  | 132.1 |  | 31.5 | % |  | 421.0 |  | 32.6 |  |  | 462.2 |  | 34.2 | % |
| Total OpComms | $ | 344.2 |  | 87.1 | % |  | $ | 387.9 |  | 92.5 | % |  | $ | 1,147.6 |  | 88.9 | % |  | $ | 1,265.5 |  | 93.7 | % |
| Lasers | 51.2 |  | 12.9 | % |  | 31.6 |  | 7.5 | % |  | 142.9 |  | 11.1 |  |  | 85.2 |  | 6.3 |  |
| Net Revenue | $ | 395.4 |  |  |  | $ | 419.5 |  |  |  | $ | 1,290.5 |  |  |  | $ | 1,350.7 |  |  |

- changed (2022-11-08):
[0001628280-22-028783:note_history:95]
| Contract balances |  | Balance sheet location |  | October 1, 2022 |  | July 2, 2022 |  | Change |  | Percentage Change |
| Accounts receivable, net |  | Accounts receivable, net |  | $ | 340.5 |  |  | $ | 262.0 |  |  | $ | 78.5 |  |  | 30.0 | % |
| Deferred revenue and customer deposits |  | Other current liabilities |  | $ | 1.1 |  |  | $ | — |  |  | $ | 1.1 |  |  | n/a |
  (was, 2022-05-04, similarity 0.9219):
[0001628280-22-012157:note_history:95]
| Contract balances |  | Balance sheet location |  | April 2, 2022 |  | July 3, 2021 |  | Change |  | Percentage Change |
| Accounts receivable, net |  | Accounts receivable, net |  | $ | 242.2 |  |  | $ | 212.8 |  |  | $ | 29.4 |  |  | 13.8 | % |
| Deferred revenue and customer deposits |  | Other current liabilities |  | $ | — |  |  | $ | 0.6 |  |  | $ | (0.6) |  |  | (100.0) | % |
