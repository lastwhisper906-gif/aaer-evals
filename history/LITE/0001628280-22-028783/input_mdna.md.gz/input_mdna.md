# LITE MD&A — 0001628280-22-028783


## mdna

[0001628280-22-028783:mdna:1]
[same as prior period, unchanged from 0001628280-22-012157:mdna:1]

[0001628280-22-028783:mdna:2]
[same as prior period, unchanged from 0001628280-22-012157:mdna:2]

[0001628280-22-028783:mdna:3]
[same as prior period, unchanged from 0001628280-22-012157:mdna:3]

[0001628280-22-028783:mdna:4]
[same as prior period, unchanged from 0001628280-22-012157:mdna:4]

[0001628280-22-028783:mdna:5]
[same as prior period, unchanged from 0001628280-22-012157:mdna:5]

[0001628280-22-028783:mdna:6]
[same as prior period, unchanged from 0001628280-22-012157:mdna:6]

[0001628280-22-028783:mdna:7]
We believe the global markets in which Lumentum participates have fundamentally robust, long-term trends that increase the need for our photonics products and technologies. We believe the world is becoming more reliant on ever-increasing amounts of data flowing through optical networks and data centers. Lumentum’s products and technology enable the scaling of these optical networks and data centers to higher capacities. We expect the accelerating shift to digital and virtual approaches to all aspects of work and life that is driving staggering amounts of data in the world’s networks and cloud datacenters will continue into the future. Virtual meetings, video calls, and hybrid in-person and virtual environments for work and other aspects of life will continue to drive strong needs for bandwidth growth and present dynamic new challenges that our technology addresses. As manufacturers demand higher levels of precision, new materials, and factory and energy efficiency, suppliers of manufacturing tools globally are turning to laser-based approaches, including the types of lasers Lumentum supplies. Laser-based 3D sensing and LiDAR for security, industrial and automotive applications are rapidly developing markets. The technology enables computer vision applications that enhance security, safety, and new functionality in the electronic devices that people rely on every day. The use of LiDAR and in-cabin 3D sensing in automobile and delivery vehicles over time significantly adds to our long-term market opportunity. Frictionless and contactless biometric security and access control is of increasing focus globally given the world’s experience with the COVID-19 pandemic. Additionally, we expect 3D-enabled machine vision solutions to expand significantly in industrial applications in the coming years.

[0001628280-22-028783:mdna:8]
[same as prior period, unchanged from 0001628280-22-012157:mdna:8]

[0001628280-22-028783:mdna:9]
38

[0001628280-22-028783:mdna:10]
Mergers and Acquisitions

[0001628280-22-028783:mdna:11]
NeoPhontonics Merger

[0001628280-22-028783:mdna:12]
On August 3, 2022 (the “Closing date”), we completed our merger with NeoPhotonics Corporation (“NeoPhotonics”). The addition of NeoPhotonics expands our opportunity in some of the fastest growing markets for optical components used in cloud and telecom network infrastructure. We expect the integrated company to be better positioned to serve the needs of a global customer base who are increasingly utilizing photonics to accelerate the shift to digital and virtual approaches to work and life, the proliferation of IoT, 5G, and next-generation mobile networks, and the transition to advanced cloud computing architectures.

[0001628280-22-028783:mdna:13]
Under the terms of the Merger Agreement, NeoPhotonics stockholders received $16.00 per share for each of the NeoPhotonics common stock they own at the Closing date. As a result, we paid $867.3 million of cash consideration to shareholders of NeoPhotonics on the Closing Date.

[0001628280-22-028783:mdna:14]
As contemplated by the Merger Agreement, on January 14, 2022, Lumentum and NeoPhotonics entered into a credit agreement where Lumentum agreed to make term loans (“loans”) to NeoPhotonics in an aggregate principal amount not to exceed $50.0 million to help fund capital expenditures and increase working capital associated with NeoPhotonics’ growth plans. During fiscal 2022, we funded a $30.0 million loan request to NeoPhotonics. On August 1, 2022, we funded an additional $20.0 million loan request to NeoPhotonics. The interest was payable monthly in arrears on the first day of each month. The loans would have matured on January 14, 2024 unless earlier repaid or accelerated. The $50.0 million loans in aggregate were included as part of the total purchase price consideration.

[0001628280-22-028783:mdna:15]
We paid $22.6 million cash consideration to shareholders of NeoPhotonics for the vested and accelerated NeoPhotonics equity awards, of which $13.6 million was allocated to the purchase price consideration. The remaining $9.0 million related to the payment of change-in-control provisions for certain executives, which were recognized as post-combination expenses due to the dual-trigger nature of the arrangements. Additionally, we issued replacement equity awards (the “Replacement Awards”) in settlement of certain NeoPhotonics equity awards that did not become vested at the Closing date, with the total  fair value of $40.2 million based on our closing stock price on the Closing date. The portion of Replacement Awards attributed to pre-merger service was recorded as part of the consideration transferred, which was $3.5 million.

[0001628280-22-028783:mdna:16]
The total transaction consideration of $934.4 million was funded by the cash balances of the combined company. We also recorded $20.9 million of merger-related costs, representing professional and other direct acquisition costs. Of the $20.9 million of merger-related costs, $12.6 million was incurred during the three months ended October 1, 2022 and was recorded as selling, general and administrative expense in the consolidated statement of operations.

[0001628280-22-028783:mdna:17]
Refer to “Note 4. Business Combinations” in the notes to condensed consolidated financial statements for additional information regarding the merger with NeoPhotonics.

[0001628280-22-028783:mdna:18]
Acquisition of IPG Photonics’ Telecom Transmission Product Lines

[0001628280-22-028783:mdna:19]
On August 15, 2022, we completed a transaction to acquire IPG Photonics’ telecom transmission product lines that develops and markets products for use in telecommunications and datacenter infrastructure, including Digital Signal Processors (DSPs), ASICs and optical transceivers. This acquisition will enable us to expand our business in the OpComms segment. The total purchase price is $55.9 million, which was paid in cash. Refer to “Note 4. Business Combinations” in the notes to condensed consolidated financial statements for additional information regarding the acquisition of these product lines.

[0001628280-22-028783:mdna:20]
We evaluate strategic opportunities regularly and, where appropriate, may acquire additional businesses, products, or technologies that are complementary to, or broaden the markets for our products. We believe we have strengthened our business model by expanding our addressable markets, customer base and expertise, diversifying our product portfolio and fortifying our core businesses from acquisitions as well as through organic initiatives.

[0001628280-22-028783:mdna:21]
Impact of COVID-19 to Our Business

[0001628280-22-028783:mdna:22]
Since February 2020, the COVID-19 pandemic has caused public health officials to recommend, and governments to enact, precautions to mitigate the spread of the virus, including travel restrictions and bans, extensive social distancing guidelines, closure or restrictions on business and quarantine or other types of “shelter-in-place” orders in many regions of the world. The pandemic and these related responses continue to cause a global slowdown of economic activity (including a decrease in demand for a broad variety of goods and services), disruptions in global supply chains, labor shortages, and significant volatility and potential disruption of financial markets. The ultimate extent to which COVID-19 will impact our business depends on future developments, which are highly uncertain and very difficult to predict, including the effectiveness

[0001628280-22-028783:mdna:23]
and utilization of vaccines for COVID-19 and its variants, the severity of COVID-19 and its variants, and the effectiveness of the actions to contain or limit their spread.

[0001628280-22-028783:mdna:24]
[same as prior period, unchanged from 0001628280-22-012157:mdna:17]

[0001628280-22-028783:mdna:25]
In the geographies where we have operations, we have, in general and where applicable, been deemed an essential business and been permitted to continue manufacturing and conducting new product development operations in a more limited capacity during the pandemic. This stems from our critical role in global supply chains for the world’s communications and health-care systems. However, the pandemic continues to affect our suppliers and manufacturers who are experiencing component materials and labor shortages. Given the continually evolving situation, particularly in light of the potential emergence of new variants, it is difficult to predict the magnitude and duration of the impact of the COVID-19 pandemic to our markets, its effects, or precisely when our ability to supply our products will return to full capacity. We are continuing to actively monitor the situation and may take further actions altering our business operations that we determine are in the best interests of our employees, customers, communities, business partners, suppliers and stockholders, or as required by federal, state, or local authorities. It is not clear what the potential effects any such alterations or modifications may have on our business, including the effects on our customers, employees and prospects, or on our financial results for the future.

[0001628280-22-028783:mdna:26]
[same as prior period, unchanged from 0001628280-22-012157:mdna:19]

[0001628280-22-028783:mdna:27]
[same as prior period, unchanged from 0001628280-22-012157:mdna:20]

[0001628280-22-028783:mdna:28]
[same as prior period, unchanged from 0001628280-22-012157:mdna:21]

[0001628280-22-028783:mdna:29]
Our business and our customers’ businesses have been negatively impacted by worldwide logistics and supply chain issues, including constraints on available cargo capabilities and limited availability of once broadly available supplies of both raw materials and finished components. COVID-19 has also created dynamics in the semiconductor component supply chains that have led to shortages of the types of components we and our customers require in our products. These shortages have impacted our ability to meet demand and generate revenue from certain products in fiscal 2022 and, they continue to impact our ability to meet demand today. If our ability to procure needed semiconductor components does not improve, our ability to supply our products to our customers will be impacted and our revenue and profit margin may be reduced. In addition, if our customers are unable to procure needed semiconductor components, this could reduce their demand for our products and reduce our revenue. The impact of semiconductor component shortages may continue in the near term as supplier and customer buffer inventories and safety stocks are exhausted. Due to the global supply chain constraints, we have had to incur incremental supply and procurement costs in order to increase our ability to fulfill demands from our customers. These costs have increased our inventory balances as of October 1, 2022 and may decrease our gross margin in the near term. We expect component supply to be a challenge at least into the second half of fiscal 2023.

[0001628280-22-028783:mdna:30]
For more information on risks associated with supply chain constraints, see the section titled “Risk Factors” in Item 1A of Part II of this report.

[0001628280-22-028783:mdna:31]
[same as prior period, unchanged from 0001628280-22-012157:mdna:23]

[0001628280-22-028783:mdna:32]
[same as prior period, unchanged from 0001628280-22-012157:mdna:24]

[0001628280-22-028783:mdna:33]
[same as prior period, unchanged from 0001628280-22-012157:mdna:25]

[0001628280-22-028783:mdna:34]
[same as prior period, unchanged from 0001628280-22-012157:mdna:26]

[0001628280-22-028783:mdna:35]
[same as prior period, unchanged from 0001628280-22-012157:mdna:27]

[0001628280-22-028783:mdna:36]
[same as prior period, unchanged from 0001628280-22-012157:mdna:28]

[0001628280-22-028783:mdna:37]
[same as prior period, unchanged from 0001628280-22-012157:mdna:29]

[0001628280-22-028783:mdna:38]
Management’s Discussion and Analysis of Financial Condition and Results of Operations contained in Part II, Item 7 of our Annual Report on Form 10-K for our fiscal year ended July 2, 2022 provides a complete discussion of our critical accounting policies and estimates. There have been no changes to these policies during the three months ended October 1, 2022.

[0001628280-22-028783:mdna:39]
Recently Issued Accounting Pronouncements

[0001628280-22-028783:mdna:40]
Refer to “Note 2. Recently Issued Accounting Pronouncements” in the notes to condensed consolidated financial statements.

[0001628280-22-028783:mdna:41]
[same as prior period, unchanged from 0001628280-22-012157:mdna:44]

[0001628280-22-028783:mdna:42]
[same as prior period, unchanged from 0001628280-22-012157:mdna:45]

[0001628280-22-028783:mdna:43]
|  | Three Months Ended |  |  |
|  | October 1, 2022 |  | October 2, 2021 |  |  |  |  |
| Segment net revenue: |  |  |  |  |  |  |  |
| OpComms | 89.5 | % |  | 90.5 | % |  |  |  |  |
| Lasers | 10.5 |  |  | 9.5 |  |  |  |  |  |
| Net revenue | 100.0 |  |  | 100.0 |  |  |  |  |  |
| Cost of sales | 55.8 |  |  | 44.7 |  |  |  |  |  |
| Amortization of acquired developed intangibles | 4.5 |  |  | 3.5 |  |  |  |  |  |
| Gross profit | 39.7 |  |  | 51.8 |  |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 14.3 |  |  | 12.1 |  |  |  |  |  |
| Selling, general and administrative | 20.9 |  |  | 14.1 |  |  |  |  |  |
| Restructuring and related charges | 1.8 |  |  | (0.2) |  |  |  |  |  |
| Total operating expenses | 37.0 |  |  | 25.9 |  |  |  |  |  |
| Income from operations | 2.7 |  |  | 25.8 |  |  |  |  |  |
| Interest expense | (1.7) |  |  | (3.8) |  |  |  |  |  |
| Other income (expense), net | 2.7 |  |  | 0.1 |  |  |  |  |  |
| Income before income taxes | 3.7 |  |  | 22.2 |  |  |  |  |  |
| Provision for income taxes | 3.8 |  |  | 4.0 |  |  |  |  |  |
| Net income (loss) | (0.1) | % |  | 18.2 | % |  |  |  |  |

[0001628280-22-028783:mdna:44]
42

[0001628280-22-028783:mdna:45]
Financial Data for the three months ended October 1, 2022 and October 2, 2021

[0001628280-22-028783:mdna:46]
[same as prior period, unchanged from 0001628280-22-012157:mdna:48]

[0001628280-22-028783:mdna:47]
|  | Three Months Ended |  |  |  |  |  |  |  |  |  |  |
|  | October 1, 2022 |  | October 2, 2021 |  | Change |  | Percentage Change |  |  |  |  |  |  |  |  |
| Segment net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| OpComms | $ | 453.4 |  |  | $ | 406.0 |  |  | $ | 47.4 |  |  | 11.7 | % |  |  |  |  |  |  |  |  |
| Lasers | 53.4 |  |  | 42.4 |  |  | 11.0 |  |  | 25.9 |  |  |  |  |  |  |  |  |  |
| Net revenue | $ | 506.8 |  |  | $ | 448.4 |  |  | $ | 58.4 |  |  | 13.0 | % |  |  |  |  |  |  |  |  |
| Gross profit | $ | 201.2 |  |  | $ | 232.2 |  |  | $ | (31.0) |  |  | (13.4) | % |  |  |  |  |  |  |  |  |
| Gross margin | 39.7 | % |  | 51.8 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | $ | 72.7 |  |  | $ | 54.1 |  |  | $ | 18.6 |  |  | 34.4 | % |  |  |  |  |  |  |  |  |
| Percentage of net revenue | 14.3 | % |  | 12.1 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general and administrative | $ | 105.7 |  |  | $ | 63.3 |  |  | $ | 42.4 |  |  | 67.0 | % |  |  |  |  |  |  |  |  |
| Percentage of net revenue | 20.9 | % |  | 14.1 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring and related charges | $ | 9.3 |  |  | $ | (1.1) |  |  | $ | 10.4 |  |  | N/A |  |  |  |  |  |  |  |  |
| Percentage of net revenue | 1.8 | % |  | (0.2) | % |  |  |  |  |  |  |  |  |  |  |  |  |

[0001628280-22-028783:mdna:48]
[same as prior period, unchanged from 0001628280-22-012157:mdna:50]

[0001628280-22-028783:mdna:49]
Net revenue increased by $58.4 million, or 13.0%, during the three months ended October 1, 2022 compared to the three months ended October 2, 2021, due to a $47.4 million increase in OpComms revenue and a $11.0 million increase in Lasers revenue.

[0001628280-22-028783:mdna:50]
OpComms net revenue increased by $47.4 million, or 11.7%, during the three months ended October 1, 2022 compared to the three months ended October 2, 2021. Within OpComms, Telecom and Datacom increased by $144.1 million, primarily due an aggregate of $73.8 million of revenue generated by NeoPhotonics and the IPG Photonics’ telecom transmission product lines from the respective acquisition dates. Additionally, the supply shortage in fiscal 2022 was partially relieved, allowing us to meet more customer demand during the first quarter of fiscal year 2023. Industrial and Consumer decreased by $96.7 million primarily due to higher market competition in the first quarter of fiscal 2023 as compared to the first quarter of fiscal 2022 and reflects share normalization in the market.

[0001628280-22-028783:mdna:51]
Lasers net revenue increased by $11.0 million, or 25.9%, during the three months ended October 1, 2022 compared to the three months ended October 2, 2021, primarily due to a return in customer demand for our kilowatt class fiber lasers following a recovery in industrial production.

[0001628280-22-028783:mdna:52]
During the three months ended October 1, 2022, our net revenue from a single customer, which represented 10.0% or greater of total net revenue was concentrated with two customers, which collectively accounted for 34% of our total net revenue.

[0001628280-22-028783:mdna:53]
During the three months ended October 2, 2021, our net revenue from a single customer, which represented 10% or greater of total net revenue was concentrated with one customer, which accounted for 41% of our total net revenue.

[0001628280-22-028783:mdna:54]
[same as prior period, unchanged from 0001628280-22-012157:mdna:60]

[0001628280-22-028783:mdna:55]
[same as prior period, unchanged from 0001628280-22-012157:mdna:61]

[0001628280-22-028783:mdna:56]
|  | Three Months Ended |  |  |
|  | October 1, 2022 |  | October 2, 2021 |  |  |  |  |
|  | Amount |  | % of Total |  | Amount |  | % of Total |  |  |  |  |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States | $ | 62.2 |  |  | 12.3 | % |  | $ | 28.1 |  |  | 6.3 | % |  |  |  |  |  |  |  |  |
| Other Americas | 59.8 |  |  | 11.8 |  |  | 35.0 |  |  | 7.8 |  |  |  |  |  |  |  |  |  |
| Total Americas | $ | 122.0 |  |  | 24.1 | % |  | $ | 63.1 |  |  | 14.1 | % |  |  |  |  |  |  |  |  |
| Asia-Pacific: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Hong Kong | $ | 77.6 |  |  | 15.3 | % |  | $ | 142.3 |  |  | 31.7 | % |  |  |  |  |  |  |  |  |
| South Korea | 67.7 |  |  | 13.4 |  |  | 105.1 |  |  | 23.4 |  |  |  |  |  |  |  |  |  |
| Thailand | 57.5 |  |  | 11.3 |  |  | 17.1 |  |  | 3.8 |  |  |  |  |  |  |  |  |  |
| Other Asia-Pacific | 133.7 |  |  | 26.4 |  |  | 95.0 |  |  | 21.2 |  |  |  |  |  |  |  |  |  |
| Total Asia-Pacific | $ | 336.5 |  |  | 66.4 | % |  | $ | 359.5 |  |  | 80.1 | % |  |  |  |  |  |  |  |  |
| EMEA | $ | 48.3 |  |  | 9.5 | % |  | $ | 25.8 |  |  | 5.8 | % |  |  |  |  |  |  |  |  |
| Total net revenue | $ | 506.8 |  |  |  |  | $ | 448.4 |  |  |  |  |  |  |  |  |  |  |  |

[0001628280-22-028783:mdna:57]
For the three months ended October 1, 2022 and October 2, 2021, net revenue from customers outside the United States, based on customer shipping location, represented 87.7% and 93.7% of net revenue, respectively.

[0001628280-22-028783:mdna:58]
[same as prior period, unchanged from 0001628280-22-012157:mdna:64]

[0001628280-22-028783:mdna:59]
[same as prior period, unchanged from 0001628280-22-012157:mdna:65]

[0001628280-22-028783:mdna:60]
[same as prior period, unchanged from 0001628280-22-012157:mdna:66]

[0001628280-22-028783:mdna:61]
|  | Three Months Ended |  |  |
|  | Gross Profit |  | Gross Margin |  |  |  |  |
|  | October 1, 2022 |  | October 2, 2021 |  | October 1, 2022 |  | October 2, 2021 |  |  |  |  |  |  |  |  |
| OpComms | $ | 216.0 |  |  | $ | 225.9 |  |  | 47.6 | % |  | 55.6 | % |  |  |  |  |  |  |  |  |
| Lasers | 28.1 |  |  | 20.8 |  |  | 52.6 | % |  | 49.1 | % |  |  |  |  |  |  |  |  |
| Segment total | $ | 244.1 |  |  | $ | 246.7 |  |  | 48.2 | % |  | 55.0 | % |  |  |  |  |  |  |  |  |
| Unallocated corporate items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation | (5.5) |  |  | (4.6) |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of acquired intangibles | (22.9) |  |  | (15.8) |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of acquired inventory fair value adjustments | (4.6) |  |  | — |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other (charges) gains (1) | (9.9) |  |  | 5.9 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total | $ | 201.2 |  |  | $ | 232.2 |  |  | 39.7 | % |  | 51.8 | % |  |  |  |  |  |  |  |  |

[0001628280-22-028783:mdna:62]
(1)   Other (charges) gains of unallocated corporate items for the three months ended October 1, 2022 primarily relate to $7.3 million of charges to acquire components from various brokers to satisfy customer demand.

[0001628280-22-028783:mdna:63]
Other (charges) gains of unallocated corporate items for the three months ended October 2, 2021 relate to $5.9 million of gain as a result of selling equipment that was no longer needed after we transferred certain product lines to new production facilities in fiscal 2021.

[0001628280-22-028783:mdna:64]
The unallocated corporate items for the periods presented include the effects of amortization of acquired developed technologies and other intangibles, amortization of acquired inventory fair value adjustments, share-based compensation and certain other charges. We do not allocate these items to the gross margin for each segment because management does not include such information in measuring the performance of the operating segments.

[0001628280-22-028783:mdna:65]
[same as prior period, unchanged from 0001628280-22-012157:mdna:72]

[0001628280-22-028783:mdna:66]
Gross margin for the three months ended October 1, 2022 decreased to 39.7% from 51.8% for the three months ended October 2, 2021. The decrease was primarily driven by lower gross margin from our OpComms segment. The lower gross margin was also a result of an aggregate $7.1 million higher amortization of intangible assets acquired in the NeoPhotonics merger and the acquisition of IPG Photonics’ telecom transmission product lines, $4.6 million of amortization of acquired inventory, and $7.3 million of charges to acquire components from various brokers to satisfy customer demand during the first quarter of fiscal year 2023. Additionally, gross margin for the three months ended October 2, 2021 includes $5.9 million of gain as a result of selling equipment that was no longer needed after we transferred certain product lines to new production facilities.

[0001628280-22-028783:mdna:67]
[same as prior period, unchanged from 0001628280-22-012157:mdna:75]

[0001628280-22-028783:mdna:68]
Due to the global supply chain constraint, we have had to incur incremental supply and procurement costs in order to increase our ability to fulfill demands from our customers. As of October 1, 2022, our inventory balance includes $21.9 million of incremental supply procurement costs.

[0001628280-22-028783:mdna:69]
[same as prior period, unchanged from 0001628280-22-012157:mdna:77]

[0001628280-22-028783:mdna:70]
[same as prior period, unchanged from 0001628280-22-012157:mdna:78]

[0001628280-22-028783:mdna:71]
OpComms gross margin for the three months ended October 1, 2022 decreased to 47.6% from 55.6% for the three months ended October 2, 2021. The decrease was primarily due to a less profitable mix of products, including lower sales of higher margin 3D sensing products, as well as higher sales of telecom transmission products due to the merger with NeoPhotonics, which have lower margins than our average OpComms margins.

[0001628280-22-028783:mdna:72]
[same as prior period, unchanged from 0001628280-22-012157:mdna:81]

[0001628280-22-028783:mdna:73]
Lasers gross margin for the three months ended October 1, 2022 increased to 52.6% from 49.1% for the three months ended October 2, 2021. The increase was primarily due to the higher manufacturing levels and improved factory utilization as a result of return in customer demand for our kilowatt class fiber products following the recent recovery in industrial production.

[0001628280-22-028783:mdna:74]
[same as prior period, unchanged from 0001628280-22-012157:mdna:84]

[0001628280-22-028783:mdna:75]
R&D expense increased by $18.6 million, or 34.4%, for the three months ended October 1, 2022 compared to the three months ended October 2, 2021. The increase in R&D expense for the three months ended October 1, 2022 was primarily driven by an increase in payroll, stock-based compensation and other compensation related expenses due to additional headcount from the merger with NeoPhotonics and the acquisition of IPG Photonics’ telecom transmission product lines.

[0001628280-22-028783:mdna:76]
[same as prior period, unchanged from 0001628280-22-012157:mdna:86]

[0001628280-22-028783:mdna:77]
[same as prior period, unchanged from 0001628280-22-012157:mdna:87]

[0001628280-22-028783:mdna:78]
SG&A expense increased by $42.4 million, or 67.0%, during the three months ended October 1, 2022 compared to the three months ended October 2, 2021. The increase in SG&A expense for the three months ended October 1, 2022 was primarily driven by an increase in payroll and employee compensation related expenses due to additional headcount from the merger with NeoPhotonics and higher stock-based compensation. In connection with the NeoPhotonics merger, certain equity awards for NeoPhotonics employees were accelerated. The total stock-based compensation associated with the acceleration was $11.9 million for the three months ended October 1, 2022. In addition, we incurred $16.2 million merger and acquisition related costs, primarily professional service fees and retention expenses related to the NeoPhotonics merger and the acquisition of IPG

[0001628280-22-028783:mdna:79]
Photonics’ telecom transmission product lines, and $3.7 million of amortization of intangibles acquired as part of these acquisitions.

[0001628280-22-028783:mdna:80]
From time to time, we incur non-recurring expenses, such as mergers and acquisition-related expenses, which generally increase our SG&A expenses and potentially impact our profitability expectations in any particular quarter.

[0001628280-22-028783:mdna:81]
[same as prior period, unchanged from 0001628280-22-012157:mdna:90]

[0001628280-22-028783:mdna:82]
We have initiated various strategic restructuring events primarily intended to reduce costs, consolidate our operations, rationalize the manufacturing of our products and align our business in response to market conditions and as a result of our merger with NeoPhotonics on August 3, 2022.

[0001628280-22-028783:mdna:83]
During the three months ended October 1, 2022, we recorded restructuring and related charges of $9.3 million, which was primarily attributable to severance and employee-related benefits associated with NeoPhotonics’ executive severance and retention agreements. These retention agreements provide, under certain circumstances, for payments and benefits upon an involuntary termination of employment.

[0001628280-22-028783:mdna:84]
During the three months ended October 2, 2021, we recorded a net reversal to our restructuring and related charges of $1.1 million in our condensed consolidated statements of operations which was attributable to lower than anticipated employee severance charges primarily as a result of retaining and re-assigning certain employees.

[0001628280-22-028783:mdna:85]
[same as prior period, unchanged from 0001628280-22-012157:mdna:96]

[0001628280-22-028783:mdna:86]
For the three months ended October 1, 2022 and October 2, 2021, we recorded interest expense of $8.5 million and $16.9 million, respectively, driven primarily by the amortization of the debt discount and issuance costs of our convertible notes.  The decrease in interest expense for the three months ended October 1, 2022 compared to the three months ended October 2, 2021, is primarily a result of the adoption of ASU 2020-06 in our first quarter of fiscal 2023, which requires us to treat our 2026 Notes and 2028 Notes as a single liability measured at amortized cost, eliminating the interest expense associated with the debt discount.

[0001628280-22-028783:mdna:87]
[same as prior period, unchanged from 0001628280-22-012157:mdna:99]

[0001628280-22-028783:mdna:88]
[same as prior period, unchanged from 0001628280-22-012157:mdna:100]

[0001628280-22-028783:mdna:89]
|  | Three Months Ended |  |  |  |  |
|  | October 1, 2022 |  | October 2, 2021 |  |  |  |  |  |  |
| Foreign exchange gains (losses), net | $ | 9.0 |  |  | $ | (0.1) |  |  |  |  |  |  |  |
| Interest and investment income | 4.8 |  |  | 0.6 |  |  |  |  |  |  |  |
| Other income (expense), net | — |  |  | 0.1 |  |  |  |  |  |  |  |
| Total other income (expense), net | $ | 13.8 |  |  | $ | 0.6 |  |  |  |  |  |  |  |

[0001628280-22-028783:mdna:90]
For the three months ended October 1, 2022, other income (expense), net increased by $13.2 million, primarily due to $9.1 million more in foreign exchange gains as a result of a strengthening U.S. dollar relative to other foreign currencies, and an increase in interest and investment income of $4.2 million from an increase in interest rates on our U.S. Treasury securities.

[0001628280-22-028783:mdna:91]
[same as prior period, unchanged from 0001628280-22-012157:mdna:104]

[0001628280-22-028783:mdna:92]
| (in millions) | Three Months Ended |  |  |
|  | October 1, 2022 |  | October 2, 2021 |  |  |  |  |
| Provision for income taxes | $ | 19.2 |  |  | $ | 18.1 |  |  |  |  |  |

[0001628280-22-028783:mdna:93]
We recorded a tax provision of $19.2 million and $18.1 million for the three months ended October 1, 2022 and October 2, 2021, respectively. Our tax provision for the three months ended October 1, 2022 includes a discrete tax expense of $13.1 million, primarily related to the international restructuring and currency re-measurement of certain tax related accounts, partially offset by the tax benefit from tax rate changes. Our tax provision for the three months ended October 2, 2021 includes a discrete tax expense of $1.1 million,  primarily related to return-to-provision differences.

[0001628280-22-028783:mdna:94]
Our estimated effective tax rate for fiscal 2023 also differs from the 21% U.S. statutory rate primarily due to the income tax tax expense from the tax effect of Global Intangible Low-Taxed Income (“GILTI”), net of benefit for foreign tax credits, subpart F inclusion and non-deductible stock-based compensation, partially offset by the income tax benefit from the earnings of our foreign subsidiaries being taxed at rates that differ from the U.S. statutory rate, and U.S. federal R&D tax credits.

[0001628280-22-028783:mdna:95]
On August 1, 2022, the Company completed an international restructuring that included the intra-entity transfer of certain intellectual property and other assets used in the business among various subsidiaries.  The international restructuring aligns the global economic ownership of the Company’s intellectual property rights with the Company’s current and future business operations.  The international restructuring resulted in an income tax expense for the fiscal first quarter of approximately $15.7 million, which is primarily the tax effect of the intra-entity transfers of the intellectual property.

[0001628280-22-028783:mdna:96]
On August 9, 2002, President Biden signed into law the CHIPS and Science Act, and on August 9, 2022, the Inflation Reduction Act.  The new legislation provide tax incentives as well as impose a 15% minimum tax on certain corporation’s book income and a 1% excise tax on certain stock buybacks. While we may be subject to the new excise tax on certain stock buybacks in years after fiscal 2023 if our net repurchase exceeds the $1.0 million annual threshold, the enactment of both the CHIPS and Science ACT as well as the Inflation Reduction Act did not result in any material adjustments to our income tax provision for the period ended October 1, 2022.

[0001628280-22-028783:mdna:97]
[same as prior period, unchanged from 0001628280-22-012157:mdna:107]

[0001628280-22-028783:mdna:98]
[same as prior period, unchanged from 0001628280-22-012157:mdna:108]

[0001628280-22-028783:mdna:99]
As of October 1, 2022 and July 2, 2022, our cash and cash equivalents were $605.3 million and $1,290.2 million, respectively. As of October 1, 2022 and July 2, 2022, our short-term investments of $1,019.6 million and $1,258.8 million, respectively, were all held in the United States. Cash equivalents and short-term investments are primarily comprised of money market funds, treasuries, agencies, high quality investment grade fixed income securities, certificates of deposit and commercial paper. Our investment policy and strategy is focused on the preservation of capital and supporting our liquidity requirements.

[0001628280-22-028783:mdna:100]
The total amount of cash held by the non-United States entities as of October 1, 2022 and July 2, 2022 was $379.7 million and $216.1 million, respectively, which was primarily held by entities incorporated in the United Kingdom, the British Virgin Islands, Japan, Hong Kong, China, Canada and Thailand. Although the cash currently held in the United States, as well as the cash generated in the United States from future operations, is expected to cover our normal operating requirements, a substantial amount of additional cash could be required for other purposes, such as capital expenditures to support our business and growth, including costs associated with increasing internal manufacturing capabilities, particularly in our Thailand facility, strategic transactions and partnerships, and future acquisitions.

[0001628280-22-028783:mdna:101]
[same as prior period, unchanged from 0001628280-22-012157:mdna:111]

[0001628280-22-028783:mdna:102]
Further, the United States recently introduced a 1% excise tax on stock buybacks and a 15% alternative minimum tax on adjusted financial statement income.  We are evaluating the impact of the excise tax to us. Many countries, and organizations such as the Organization for Economic Cooperation and Development have proposed implementing changes to existing tax laws, including a proposed global minimum tax of 15%. Any of these developments or changes in federal, state, or international tax laws or tax rulings could adversely affect our effective tax rate and our operating results.

[0001628280-22-028783:mdna:103]
[same as prior period, unchanged from 0001628280-22-012157:mdna:112]

[0001628280-22-028783:mdna:104]
We believe that our cash and cash equivalents as of October 1, 2022 and cash flows from our operating activities will be sufficient to meet our liquidity and capital spending requirements for at least the next 12 months.

[0001628280-22-028783:mdna:105]
[same as prior period, unchanged from 0001628280-22-012157:mdna:114]

[0001628280-22-028783:mdna:106]
[same as prior period, unchanged from 0001628280-22-012157:mdna:115]

[0001628280-22-028783:mdna:107]
[same as prior period, unchanged from 0001628280-22-012157:mdna:116]

[0001628280-22-028783:mdna:108]
[same as prior period, unchanged from 0001628280-22-012157:mdna:117]

[0001628280-22-028783:mdna:109]
•increase in capital expenditures to support our business and growth, including increases in manufacturing capacity;

[0001628280-22-028783:mdna:110]
[same as prior period, unchanged from 0001628280-22-012157:mdna:119]

[0001628280-22-028783:mdna:111]
[same as prior period, unchanged from 0001628280-22-012157:mdna:120]

[0001628280-22-028783:mdna:112]
[same as prior period, unchanged from 0001628280-22-012157:mdna:121]

[0001628280-22-028783:mdna:113]
[same as prior period, unchanged from 0001628280-22-012157:mdna:122]

[0001628280-22-028783:mdna:114]
•possible investments or acquisitions of complementary businesses, products or technologies, or other strategic transactions or partnerships;

[0001628280-22-028783:mdna:115]
[same as prior period, unchanged from 0001628280-22-012157:mdna:124]

[0001628280-22-028783:mdna:116]
•potential funding of pension liabilities either voluntarily or as required by law or regulation;

[0001628280-22-028783:mdna:117]
•other acquisitions or strategic transactions;

[0001628280-22-028783:mdna:118]
•the settlement of any conversion or redemption of the 2024 Notes, 2026 Notes and the 2028 Notes in cash; and

[0001628280-22-028783:mdna:119]
•common stock repurchases under the 2021 share buyback program.

[0001628280-22-028783:mdna:120]
Contractual Obligations

[0001628280-22-028783:mdna:121]
The following table summarizes certain of our contractual obligations as of October 1, 2022, and the effect such obligations are expected to have on our liquidity and cash flow over the next five years (in millions):

[0001628280-22-028783:mdna:122]
|  | Payments due by period |
|  | Total |  | Less than 1 year |  | More than 1 year |  |  |  |  |
| Contractual Obligations |  |  |  |  |  |  |  |  |  |
| Asset retirement obligations | $ | 8.0 |  |  | $ | 0.5 |  |  | $ | 7.5 |  |  |  |  |  |
| Operating lease liabilities, including imputed interest (1) | 77.9 |  |  | 15.1 |  |  | 62.8 |  |  |  |  |  |
| Pension plan contributions (2) | 1.4 |  |  | 1.4 |  |  | — |  |  |  |  |  |
| Purchase obligations (3) | 416.2 |  |  | 374.1 |  |  | 42.1 |  |  |  |  |  |
| Term loans | 4.9 |  |  | 4.9 |  |  | — |  |  |  |  |  |
| Convertible notes - principal (4) | 2,359.1 |  |  | — |  |  | 2,359.1 |  |  |  |  |  |
| Convertible notes - interest (4) | 51.1 |  |  | 10.6 |  |  | 40.5 |  |  |  |  |  |
| Total | $ | 2,918.6 |  |  | $ | 406.6 |  |  | $ | 2,512.0 |  |  |  |  |  |

[0001628280-22-028783:mdna:123]
(1) The amounts of operating lease liabilities in the table above do not include any sublease income amounts nor do they include payments for short-term leases or variable lease payments. As of October 1, 2022, we expect to receive sublease income of approximately $4.6 million over the sublease periods.

[0001628280-22-028783:mdna:124]
(2) The amount represents planned contributions to our defined benefit plans. Although additional future contributions will be required, the amount and timing of these contributions will be affected by actuarial assumptions, the actual rate of returns on plan assets, the level of market interest rates, legislative changes, and the amount of voluntary contributions to the plan. Any contributions for the following fiscal year and later will depend on the value of the plan assets in the future and thus are uncertain. As such, we have not included any amounts beyond one year in the table above.

[0001628280-22-028783:mdna:125]
(3) Purchase obligations represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Refer to “Note 14. Commitments and Contingencies” in the notes to condensed consolidated financial statements.

[0001628280-22-028783:mdna:126]
(4) The amount includes principal and interest payment in cash on our 0.25% Convertible Notes due in 2024 (the “2024 Notes”); principal and interest on our 0.50% Convertible Notes due in 2026 (the “2026 Notes”); and principal and interest on our 0.50% Convertible Notes due in 2028. The 2024 Notes have a maturity date of March 15, 2024, the 2026 Notes have a maturity date of December 15, 2026, and the 2028 Notes have a maturity date of June 15, 2028. The principal balances of our convertible notes are reflected in the payment periods in the table above based on their respective contractual maturities assuming no conversion. Refer to “Note 9. Debt” in the notes to condensed consolidated financial statements.

[0001628280-22-028783:mdna:127]
[same as prior period, unchanged from 0001628280-22-012157:mdna:136]

[0001628280-22-028783:mdna:128]
[same as prior period, unchanged from 0001628280-22-012157:mdna:137]

[0001628280-22-028783:mdna:129]
As of October 1, 2022, our 2024 Notes of $415.2 million (principal balance of $448.1 million maturing in 2024) is presented in current liabilities in our condensed consolidated balance sheets. While the 2024 Notes will not be convertible during the second quarter of fiscal 2023 as our stock price did not exceed $78.80 for 20 of the last 30 trading days of the quarter ended October 1, 2022, we do expect that the 2024 Notes will again become convertible at the option of the holders during future quarters in fiscal 2023, and as such, continue to classify the debt in current liabilities. During the three months ended October 1, 2022, we received conversion requests of less than $0.1 million principal amount of the 2024 Notes, which we settled with cash in accordance with the 2024 Indenture. Since issuing the 2024 Notes, we have converted a total of approximately $1.9 million principal amount of the 2024 Notes. The remaining principal amount of the 2024 Notes as of October 1, 2022 was $448.1 million.

[0001628280-22-028783:mdna:130]
As of October 1, 2022, our 2026 Notes of $1,045.0 million (principal balance of $1,050.0 million maturing in 2026) is presented in non-current liabilities in our condensed consolidated balance sheets. If the closing price of our stock exceeds $129.08 for 20 of the last 30 trading days of any future quarter, our 2026 Notes would also become convertible at the option of the holders and the debt would be reclassified to current liabilities in our condensed consolidated balance sheet.

[0001628280-22-028783:mdna:131]
As of October 1, 2022, our 2028 Notes of $854.5 million (principal balance of $861.0 million maturing in 2028) is presented in non-current liabilities in our condensed consolidated balance sheets. If the closing price of our stock exceeds $170.34 for 20 of the last 30 trading days of any future quarter, our 2028 Notes would also become convertible at the option of the holders and the debt would be reclassified to current liabilities in our condensed consolidated balance sheet.

[0001628280-22-028783:mdna:132]
As of October 1, 2022, we presented our term loans that we assumed in connection with our merger with NeoPhotonics, within current liabilities in our condensed consolidated balance sheet.

[0001628280-22-028783:mdna:133]
[same as prior period, unchanged from 0001628280-22-012157:mdna:141]

[0001628280-22-028783:mdna:134]
On May 7, 2021, our board of directors approved the 2021 share buyback program, which authorizes us to use up to $700.0 million to purchase our own shares of common stock. On March 3, 2022, our board of directors approved an increase in our share buyback program, which authorizes us to use up to an aggregate amount of $1.0 billion (an increase from $700.0 million) to purchase our own shares of common stock through May 2024, but may be suspended or terminated by the board of directors at any time.

[0001628280-22-028783:mdna:135]
During the three months ended October 1, 2022, we repurchased 0.3 million shares of our common stock at an average price of $89.80 per share for an aggregate purchase price of $25.7 million.

[0001628280-22-028783:mdna:136]
Since the share buyback program was approved by the board of directors, we have repurchased 7.4 million shares in aggregate at an average price of $83.38 per share for a total purchase price of $615.5 million. We recorded the $615.5 million aggregate purchase price as a reduction of retained earnings within our condensed consolidated balance sheet. All repurchased shares were retired immediately.

[0001628280-22-028783:mdna:137]
The price, timing, amount, and method of such repurchases will be determined based on the valuation of market conditions and other factors, at prices determined to be attractive and in the best interests of both the Company and our stockholders.

[0001628280-22-028783:mdna:138]
[same as prior period, unchanged from 0001628280-22-012157:mdna:149]

[0001628280-22-028783:mdna:139]
As of October 1, 2022, our other non-current liabilities also include $50.9 million of unrecognized tax benefit for uncertain tax positions. We are unable to reliably estimate the timing of future payments related to uncertain tax positions.

[0001628280-22-028783:mdna:140]
[same as prior period, unchanged from 0001628280-22-012157:mdna:151]

[0001628280-22-028783:mdna:141]
Our balance of cash and cash equivalents decreased by $684.9 million, from $1,290.2 million as of July 2, 2022 to $605.3 million as of October 1, 2022. The decrease in cash and cash equivalents during the three months ended October 1, 2022 was

[0001628280-22-028783:mdna:142]
due to cash used in investing activities of $646.6 million and financing activities of $59.1 million, partially offset by cash provided by operating activities of $20.8 million.

[0001628280-22-028783:mdna:143]
[same as prior period, unchanged from 0001628280-22-012157:mdna:153]

[0001628280-22-028783:mdna:144]
Cash provided by operating activities was $20.8 million during the three months ended October 1, 2022, which reflects a net loss of $0.4 million and non-cash items of $111.7 million for the three months ended October 1, 2022, offset by $90.5 million changes in our operating assets and liabilities.

[0001628280-22-028783:mdna:145]
Cash provided by operating activities was $61.9 million during the three months ended October 2, 2021. Our net income was $81.5 million for the three months ended October 2, 2021. Cash provided by operating activities was also generated from $79.9 million of non-cash items (such as depreciation, stock-based compensation, amortization of intangibles, amortization of debt discount and debt issuance costs, and other non-cash charges), offset by $99.5 million of changes in our operating assets and liabilities.

[0001628280-22-028783:mdna:146]
[same as prior period, unchanged from 0001628280-22-012157:mdna:156]

[0001628280-22-028783:mdna:147]
Cash used in investing activities of $646.6 million during the three months ended October 1, 2022 was attributable to the acquisition of NeoPhotonics and IPG Photonics’ telecom transmission product lines in the amount of $860.8 million, net of cash acquired, and capital expenditures of $22.9 million, partially offset by net proceeds from sales or maturities of short-term investments of $237.1 million.

[0001628280-22-028783:mdna:148]
Cash used in investing activities of $116.9 million during the three months ended October 2, 2021 was primarily attributable to purchases of short-term investments, net of sales and maturities of $104.9 million, capital expenditures of $17.9 million, partially offset by proceeds from the sales of property, plant and equipment of $5.9 million.

[0001628280-22-028783:mdna:149]
[same as prior period, unchanged from 0001628280-22-012157:mdna:159]

[0001628280-22-028783:mdna:150]
Cash used in financing activities of $59.1 million during the three months ended October 1, 2022 was driven by the repurchase of shares of our common stock of $35.8 million and tax payments related to net share settlement of restricted stock of $22.4 million.

[0001628280-22-028783:mdna:151]
Cash used in financing activities of $108.3 million during the three months ended October 2, 2021 resulted primarily from the repurchase of shares of our common stock of $91.7 million and tax payments related to restricted stock of $16.6 million.
