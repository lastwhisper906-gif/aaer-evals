# LITE notes — 0001628280-22-028783


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001628280-22-028783:notes:1]
[same as prior period, unchanged from 0001628280-22-012157:notes:1]

[0001628280-22-028783:notes:2]
[same as prior period, unchanged from 0001628280-22-012157:notes:2]

[0001628280-22-028783:notes:3]
Lumentum Holdings Inc. (“we,” “us,” “our”, “Lumentum” or the “Company”) is an industry-leading provider of optical and photonic products defined by revenue and market share addressing a range of end market applications including Optical Communications (“OpComms”) and Commercial Lasers (“Lasers”) for manufacturing, inspection and life-science applications. We seek to use our core optical and photonic technology, and our volume manufacturing capability, to expand into attractive emerging markets that benefit from advantages that optical or photonics-based solutions provide, including 3D sensing for consumer electronics and diode light sources for a variety of consumer and industrial applications. The majority of our customers are currently as well as historically original equipment manufacturers (“OEMs”) that incorporate our products into their products which then address end-market applications. For example, we sell fiber optic components that network equipment manufacturers (“NEMs”) assemble into communications networking systems, which they sell to communications service providers, hyperscale cloud operators, and enterprises with their own networks. Similarly, many of our Lasers products customers incorporate our products into tools they produce, which are used for manufacturing processes by their customers. For 3D sensing, we sell diode lasers to manufacturers of consumer electronics products for mobile, personal computing, gaming, and other applications, including to the automotive industry, who then integrate our devices within their products, for eventual resale to consumers and also into other industrial applications.

[0001628280-22-028783:notes:4]
[same as prior period, unchanged from 0001628280-22-012157:notes:4]

[0001628280-22-028783:notes:5]
The accompanying condensed consolidated financial statements have been prepared in accordance with U.S. generally accepted accounting principles (“GAAP”), which requires management to make estimates and assumptions that affect the amounts reported in our condensed consolidated financial statements and accompanying notes. Management bases its estimates on historical experience and various other assumptions believed to be reasonable. Although these estimates are based on management’s best knowledge of current events and actions that may impact us in the future, actual results may be different from the estimates. Operating results for the quarter ended October 1, 2022 are not necessarily indicative of the results that may be expected for the fiscal year ending July 1, 2023. In the opinion of the Company’s management, the information presented herein reflects all normal and recurring adjustments necessary for a fair presentation of our results of operations, financial position, stockholders’ equity and cash flows. Our critical accounting policies are those that affect our financial statements materially and involve difficult, subjective or complex judgments by management. Those policies are inventory valuation, revenue recognition, income taxes, goodwill and business combinations.

[0001628280-22-028783:notes:6]
While the impact of COVID-19 pandemic is lessening, the duration and severity of the impact of the pandemic on our business and results of operations in future periods remain uncertain. The extent of the impact of COVID-19 on our operational and financial performance will depend on certain developments, including but not limited to the duration and spread of the pandemic and its variants, implementation and duration of local, state and federal issued public health orders in each jurisdiction where we operate or in which our customers and suppliers operate, impact on our customers and our sales cycles, impact on our supply chain and manufacturing partners, impact on our employees and impact on regional and worldwide economies and financial markets in general, all of which are uncertain and cannot be predicted. We assessed the potential impact that this pandemic has on our estimates as of October 1, 2022 and determined that there were no material impacts. However, due to the global supply chain constraint, we have had to incur incremental supply and procurement costs in order to fulfill demand from our customers.  As of October 1, 2022, our inventory balance includes $21.9 million of incremental supply procurement costs.

[0001628280-22-028783:notes:7]
We are also continuously monitoring developments in the ongoing conflict between Russia and Ukraine including the related export controls and resulting sanctions imposed on Russia by the U.S. and other countries. Additional factors such as increased inflation, escalating energy costs, constrained raw material availability, and thus increasing costs could impact the global economy. Although the global implications of the Russian/Ukraine conflict are difficult to predict at this time, we do not presently foresee direct material adverse effects upon our business.

[0001628280-22-028783:notes:8]
Business Combinations

[0001628280-22-028783:notes:9]
On August 3, 2022, we completed a merger with NeoPhotonics Corporation (“NeoPhotonics”). Our condensed consolidated financial statements include the operating results of NeoPhotonics for the period from the date of the closing of the merger through October 1, 2022. We have applied the acquisition method of accounting in accordance with ASC 805 Business Combinations to account for this transaction. Refer to “Note 4. Business Combinations” for further discussion of the merger.

[0001628280-22-028783:notes:10]
On August 15, 2022, we completed a transaction to acquire IPG Photonics’ telecom transmission product lines. Our condensed consolidated financial statements include the operating results of this business unit for the period from the date of the acquisition through October 1, 2022. We have applied the acquisition method of accounting in accordance with ASC 805 Business Combinations to account for this transaction. Refer to “Note 4. Business Combinations” for further discussion of this acquisition.

[0001628280-22-028783:notes:11]
[same as prior period, unchanged from 0001628280-22-012157:notes:9]

[0001628280-22-028783:notes:12]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Every fifth or sixth fiscal year will have a 53-week period. The additional week in a 53-week year is added to the third quarter, making such quarter consist of 14 weeks. Our fiscal 2023 is a 52-week year ending on July 1, 2023, with the quarter ended October 1, 2022 being a 13-week quarterly period. Our fiscal 2022 was a 52-week year that ended on July 2, 2022, with the quarter ended October 2, 2021 being a 13-week quarterly period.

[0001628280-22-028783:notes:13]
[same as prior period, unchanged from 0001628280-22-012157:notes:11]

[0001628280-22-028783:notes:14]
These interim unaudited condensed consolidated financial statements include the accounts of Lumentum Holdings Inc. and its wholly-owned subsidiaries. All inter-company transactions and balances are eliminated in consolidation.

[0001628280-22-028783:notes:15]
[same as prior period, unchanged from 0001628280-22-012157:notes:13]

[0001628280-22-028783:notes:16]
[same as prior period, unchanged from 0001628280-22-012157:notes:14]

[0001628280-22-028783:notes:17]
The condensed consolidated financial statements and accompanying related notes should be read in conjunction with the audited consolidated financial statements and related notes included in our Annual Report on Form 10-K for the fiscal year ended July 2, 2022. 
Except for the accounting policies for convertible instruments as a result of our adoption of Accounting Standards Update (“ASU”) 2020-06, Debt—Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging—Contracts in Entity’s Own Equity (Subtopic 815-40): Accounting for Convertible Instruments and Contracts in an Entity’s Own Equity, there have been no significant changes to our accounting policies during the three months ended October 1, 2022.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001628280-22-028783:notes:18]
Note 2. Recently Issued Accounting Pronouncements

[0001628280-22-028783:notes:19]
Accounting Pronouncements Recently Adopted

[0001628280-22-028783:notes:20]
In October 2021, the Financial Accounting Standards Board (“FASB”) issued ASU 2021-08, Business Combinations (Topic 805)—Accounting for Contract Assets and Contract Liabilities from Contracts with Customers. This ASU clarifies that an acquirer of a business should recognize and measure contract assets and contract liabilities in a business combination in accordance with Accounting Standards Codification (“ASC”) Topic 606, Revenue from Contracts with Customers. This ASU is expected to improve comparability for both the recognition and measurement of acquired revenue contracts with customers at the date of and after a business combination. The new guidance is effective for fiscal years beginning after December 15, 2022, with early adoption permitted. ASU 2021-08 is effective for us in our first quarter of fiscal year 2024. We early adopted the new standard in the first quarter of fiscal 2023 in connection with the merger with NeoPhotonics Corporation (“NeoPhotonics”), noting no material impact to our condensed consolidated financial statements as of and for the period ended October 1, 2022.

[0001628280-22-028783:notes:21]
In August 2020, the FASB issued ASU 2020-06, Debt—Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging—Contracts in Entity’s Own Equity (Subtopic 815-40): Accounting for Convertible Instruments and Contracts in an Entity’s Own Equity, which simplifies the accounting for convertible instruments by removing the separation models for (i) convertible debt with a cash conversion feature and (ii) convertible instruments with a beneficial conversion feature. As a result, a convertible debt instrument is accounted for as a single liability measured at its amortized cost. ASU 2020-06 also requires the application of the if-converted method for calculating diluted earnings per share. We adopted the standard as of July 3, 2022, using the modified retrospective approach. Upon adoption, our 2026 Notes and 2028 Notes were accounted for as a single liability measured at amortized cost, resulting in: (i) an increase to the convertible notes liability balance of $433.0 million to reflect the full principal amount of the convertible notes outstanding, net of issuance costs; (ii) a reduction to additional paid-in capital, net of estimated income tax effects, of $426.5 million, to remove the equity component separately recorded for the conversion features associated with the convertible notes; (iii) an increase to deferred tax assets, net of $92.1 million; and (iv) a cumulative-effect adjustment of $85.6 million, net of estimated income tax effects, to decrease the accumulated deficit. In addition, the adoption requires the use of the if-converted method for all convertible notes in the diluted net income per share calculation and the inclusion of the effect of potential share settlement of the convertible notes, if the effect is more dilutive. There was no impact to diluted earnings per share for the three months ended October 1, 2022, as the inclusion of potential shares of common stock related to the convertible notes was anti-dilutive. Refer to “Note 9. Debt” for further information.

[0001628280-22-028783:notes:22]
The following table sets forth the impact upon adoption of ASU 2020-06 as of July 3, 2022 (in millions):

[0001628280-22-028783:notes:23]
|  |  | Short Term Debt - 2024 Notes |  | Long Term Debt - 2026 Notes |  | Long Term Debt - 2028 Notes |  | Additional Paid-In Capital |  | Accumulated Deficit |  | Deferred Tax Asset (Liability), net |
| Balances pre-adoption of ASC 2020-06 |  | $ | 409.9 |  |  | $ | 831.4 |  |  | $ | 634.7 |  |  | $ | 2,003.6 |  |  | $ | 129.1 |  |  | $ | 12.9 |  |
| Reclassify amounts from equity to debt |  | — |  |  | 312.9 |  |  | 229.3 |  |  | (542.2) |  |  | — |  |  | — |  |
| Adjustment for interest accretion |  | — |  |  | (99.5) |  |  | (9.7) |  |  | — |  |  | (109.2) |  |  | — |  |
| Tax effect |  | — |  |  | — |  |  | — |  |  | 115.7 |  |  | 23.6 |  |  | 92.1 |  |
| Balances upon adoption of ASC 2020-06 |  | $ | 409.9 |  |  | $ | 1,044.8 |  |  | $ | 854.3 |  |  | $ | 1,577.1 |  |  | $ | 43.5 |  |  | $ | 105.0 |  |


## us-gaap:EarningsPerShareTextBlock

[0001628280-22-028783:notes:24]
[same as prior period, unchanged from 0001628280-22-012157:notes:29]

[0001628280-22-028783:notes:25]
The following table sets forth the computation of basic and diluted net income (loss) per share (in millions, except per share data):

[0001628280-22-028783:notes:26]
|  | Three Months Ended |  |  |
|  | October 1, 2022 |  | October 2, 2021 |  |  |
| Numerator: |  |  |  |  |  |
| Net income (loss) - basic and diluted | $ | (0.4) |  |  | $ | 81.5 |  |  |  |
| Denominator: |  |  |  |  |  |
| Weighted average common shares outstanding - basic | 68.1 |  |  | 72.7 |  |  |  |
| Effect of dilutive securities from 2015 Equity Incentive Plan | — |  |  | 0.6 |  |  |  |
| Shares issuable assuming conversion of the convertible notes | — |  |  | 2.1 |  |  |  |
| Weighted average common shares outstanding - diluted | 68.1 |  |  | 75.4 |  |  |  |
| Net income (loss) per share: |  |  |  |  |  |
| Basic | $ | (0.01) |  |  | $ | 1.12 |  |  |  |
| Diluted | $ | (0.01) |  |  | $ | 1.08 |  |  |  |

[0001628280-22-028783:notes:27]
Upon adoption of ASU 2020-06 in the first quarter of fiscal 2023, potentially dilutive common shares issuable upon conversion of our outstanding 2024 Notes, 2026 Notes and 2028 Notes (collectively referred to as the “Convertible Notes”)  are determined using the if-converted method. Anti-dilutive shares excluded from the calculation of diluted net income (loss) per share for the three months ended October 1, 2022 include 28.4 million shares related to Convertible Notes and 0.5 million shares related to restricted stock units (“RSUs”) under the 2015 Equity Incentive Plan and shares to be purchased under the Employee Stock Purchase Plan (the “2015 Purchase Plan”). Refer to “Note 13. Equity.”

[0001628280-22-028783:notes:28]
Periods prior to the adoption of ASU 2020-06, which includes the first quarter of fiscal 2022, our potentially dilutive common shares issuable upon conversion of our outstanding convertible notes are determined using the treasury stock method. Anti-dilutive shares excluded from the calculation of diluted net income (loss) per share for the three months ended October 2, 2021 include 0.4 million shares related to RSUs and the 2015 Purchase Plan.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001628280-22-028783:notes:29]
Note 4. Business Combinations

[0001628280-22-028783:notes:30]
NeoPhotonics Merger

[0001628280-22-028783:notes:31]
On November 3, 2021, we entered into an Agreement and Plan of Merger (the “Merger Agreement”) with NeoPhotonics and Neptune Merger Sub, Inc. On August 3, 2022 (the “Closing date”), we completed the acquisition of NeoPhotonics through the consummation of the merger and, accordingly, we acquired all of the issued and outstanding common stock of NeoPhotonics. The addition of NeoPhotonics expands our opportunity in some of the fastest growing markets for optical components used in cloud and telecom network infrastructure. We expect the integrated company to be better positioned to serve the needs of a global customer base who are increasingly utilizing photonics to accelerate the shift to digital and virtual approaches to work and life, the proliferation of IoT, 5G, and next-generation mobile networks, and the transition to advanced cloud computing architectures.

[0001628280-22-028783:notes:32]
We have applied the acquisition method of accounting in accordance with ASC 805 Business Combinations, with respect to the fair value of purchase price consideration and the identifiable assets and liabilities of NeoPhotonics, which have been measured at estimated fair value as of the Closing date. The following tables summarize the total purchase price consideration (in millions):

[0001628280-22-028783:notes:33]
|  | Fair Value |
| Cash consideration for outstanding NeoPhotonics common stock (1) | $ | 867.3 |  |
| Settlement of pre-existing relationship (loan to NeoPhotonics) (2) | 50.0 |  |
| Share-based compensation (3) | 17.1 |  |
| Total purchase price consideration | $ | 934.4 |  |

[0001628280-22-028783:notes:34]
(1) Under the terms of the Merger Agreement, NeoPhotonics stockholders received $16.00 per share for each of the 54.2 million NeoPhotonics common stock outstanding at the Closing date. As a result, we paid $867.3 million of cash consideration to shareholders of NeoPhotonics on the Closing Date.

[0001628280-22-028783:notes:35]
(2) As contemplated by the Merger Agreement, on January 14, 2022, Lumentum and NeoPhotonics entered into a credit agreement where Lumentum agreed to make term loans (“loans”) to NeoPhotonics in an aggregate principal amount not to exceed $50.0 million to help fund capital expenditures and increase working capital associated with NeoPhotonics’ growth plans. During fiscal 2022, the Company funded a $30.0 million loan request to NeoPhotonics. On August 1, 2022, we funded an additional $20.0 million loan request to NeoPhotonics. The interest was payable monthly in arrears on the first day of each month. The loans would have matured on January 14, 2024 unless earlier repaid or accelerated. The $50.0 million loans in aggregate were included as part of the total purchase price consideration.

[0001628280-22-028783:notes:36]
(3) We paid $22.6 million cash consideration to holders of vested NeoPhotonics equity awards as of closing, of which $13.6 million was allocated to the purchase price consideration and $9.0 million was expensed immediately after the Closing date. Additionally, we issued replacement equity awards (the “Replacement Awards”) in settlement of certain NeoPhotonics equity awards that did not become vested at the Closing date, with the total  fair value of $40.2 million based on our closing stock price on the Closing date. The portion of Replacement Awards attributed to pre-merger service was recorded as part of the consideration transferred, which was $3.5 million.

[0001628280-22-028783:notes:37]
The total transaction consideration of $934.4 million was funded by the cash balances of the combined company. We also recorded $20.9 million of merger-related costs, representing professional and other direct acquisition costs. Of the $20.9 million of merger-related costs, $12.6 million was incurred during the three months ended October 1, 2022 and was recorded as selling, general and administrative expense in the consolidated statement of operations.

[0001628280-22-028783:notes:38]
We allocated the fair value of the purchase price consideration to the assets acquired and liabilities assumed as of the Closing date based on their estimated fair values. The excess of purchase price consideration over the fair value of net assets acquired is recorded as goodwill. Our preliminary allocation of the purchase price consideration to the assets acquired and liabilities assumed as of the Closing date is as follows (in millions):

[0001628280-22-028783:notes:39]
|  | Fair Value |
| Total purchase price consideration | $ | 934.4 |  |
| Assets acquired |  |
| Cash and cash equivalents | $ | 92.9 |  |
| Accounts receivable, net | 66.5 |  |
| Inventories | 85.3 |  |
| Prepayments and other current assets | 24.2 |  |
| Property, plant and equipment, net | 106.6 |  |
| Operating lease right-of-use assets, net | 16.9 |  |
| Other intangible assets, net (1) | 412.5 |  |
| Other non-current assets | 1.9 |  |
| Total assets | 806.8 |  |
| Liabilities assumed |  |
| Accounts payable | 79.6 |  |
| Accrued payroll and related expenses | 12.0 |  |
| Accrued expenses | 4.1 |  |
| Other current liabilities | 10.6 |  |
| Operating lease liabilities, current | 2.8 |  |
| Operating lease liabilities, non-current | 13.2 |  |
| Deferred tax liability | 40.1 |  |
| Other non-current liabilities | 28.3 |  |
| Total liabilities | 190.7 |  |
| Goodwill | $ | 318.3 |  |

[0001628280-22-028783:notes:40]
(1) Other intangible assets include customer relationship of $144.5 million, developed technology of $220.0 million, and in-process research and development (“IPR&D”) of $48.0 million. Refer to “Note 8. Goodwill and Other Intangible Assets” for more information.

[0001628280-22-028783:notes:41]
The allocation of the purchase price to the assets acquired and liabilities assumed, including the residual amount allocated to goodwill, is based upon preliminary information and subject to change. The primary areas of the preliminary purchase price allocation that are not yet finalized relate to the fair value of inventories, property, plant and equipment, intangible assets, deferred tax assets and liabilities, and contingent liabilities. Further adjustments may result before the end of the measurement period, which ends one year from the Closing date. During the measurement period, if new information is obtained about facts and circumstances that existed as of the Closing date that, if known, would have resulted in revised estimated values of assets acquired and liabilities assumed, we will revise the preliminary purchase price allocation. The effect of measurement period adjustments to the estimated fair values will be calculated as if the adjustments had been completed on the acquisition date. The impact of all changes that do not qualify as measurement period adjustments will be included in current period earnings.

[0001628280-22-028783:notes:42]
Goodwill has been assigned to the OpComms segment. The preliminary goodwill of $318.3 million arising from the acquisition is attributed to the expected synergies, including future cost efficiencies and other benefits that are expected to be generated by combining Lumentum and NeoPhotonics. None of the goodwill is expected to be deductible for local tax purposes.  Refer to “Note 8. Goodwill and Other Intangible Assets.”

[0001628280-22-028783:notes:43]
From the Closing date, NeoPhotonics contributed $72.8 million of our consolidated net revenue for the three months ended October 1, 2022. Due to the continued integration of the combined businesses, as well as our corporate structure and the allocation of selling, general and administrative costs, it is impractical to determine NeoPhotonics’ contribution to our earnings.

[0001628280-22-028783:notes:44]
Supplemental Pro Forma Information

[0001628280-22-028783:notes:45]
The following supplemental pro forma information presents the combined results of operations for the three months ended October 1, 2022 and October 2, 2021, as if the merger was completed at the beginning of fiscal 2022. The supplemental pro forma financial information presented below is not necessarily indicative of the financial position or results of operations that would have been realized if the acquisition had been completed on the date indicated. The supplemental pro forma financial information does not reflect synergies that might have been achieved, nor is it indicative of future operating results or financial position.

[0001628280-22-028783:notes:46]
The pro forma financial information includes adjustments for: (i) additional amortization expense that would have been recognized related to the acquired intangible assets, (ii) additional depreciation expense that would have been recognized related to the acquired property, plant, and equipment, (iii) additional cost of sales related to the inventory valuation adjustment, (iv) acquisition related costs, such as third party transaction costs and restructuring costs, (vi) stock-based compensation expense and (vi) the estimated income tax effect on the pro forma adjustments.

[0001628280-22-028783:notes:47]
The supplemental pro forma financial information for the periods presented is as follows (in millions):

[0001628280-22-028783:notes:48]
|  |  |  | Three Months Ended |
|  |  |  | October 1, 2022 |  | October 2, 2021 |
| Net revenue |  |  | $ | 530.7 |  |  | $ | 532.1 |  |
| Net income |  |  | 32.4 |  |  | 22.2 |  |

[0001628280-22-028783:notes:49]
Acquisition of IPG Photonics’ Telecom Transmission Product Lines

[0001628280-22-028783:notes:50]
On August 15, 2022 (“IPG Closing date”), we completed a transaction to acquire IPG Photonics’ telecom transmission product lines that develops and markets products for use in telecommunications and datacenter infrastructure, including Digital Signal Processors (DSPs), ASICs and optical transceivers. This acquisition will enable us to expand our business in the OpComms segment.

[0001628280-22-028783:notes:51]
We have applied the acquisition method of accounting in accordance with ASC 805 Business Combinations to account for this transaction. The total purchase price is $55.9 million, which was paid in cash. Our preliminary allocation of the purchase price consideration includes $29.1 million of in-process research and development (“IPR&D”), $8.6 million of developed technology, $2.3 million of customer relationships, $9.4 million of other net assets and liabilities, resulting in preliminary goodwill of $6.5 million. The allocation of the purchase price to the assets acquired and liabilities assumed, including the residual amount allocated to goodwill, is based upon preliminary information and adjustments may result before the end of the measurement period, which ends one year from the IPG Closing date.

[0001628280-22-028783:notes:52]
We incurred $1.4 million transaction costs during the three months ended October 1, 2022, which was recorded as selling, general and administrative expense in the condensed consolidated statement of operations.

[0001628280-22-028783:notes:53]
The pro forma financial information from the IPG Photonics’ telecom transmission product lines, assuming the acquisition had occurred as of the beginning of the fiscal year prior to the fiscal year of the acquisition, as well as revenue and earnings generated during the current fiscal year, were not material for disclosure purposes.


## us-gaap:CashCashEquivalentsAndShortTermInvestmentsTextBlock

[0001628280-22-028783:notes:54]
Note 5. Cash, Cash Equivalents and Short-term Investments

[0001628280-22-028783:notes:55]
[same as prior period, unchanged from 0001628280-22-012157:notes:38]

[0001628280-22-028783:notes:56]
|  | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| October 1, 2022: |  |  |  |  |  |  |  |
| Cash | $ | 326.9 |  |  | $ | — |  |  | $ | — |  |  | $ | 326.9 |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | 24.5 |  |  | — |  |  | — |  |  | 24.5 |  |
| Money market funds | 221.1 |  |  | — |  |  | — |  |  | 221.1 |  |
| U.S. Agency securities | 9.0 |  |  | — |  |  | — |  |  | 9.0 |  |
| U.S. Treasury securities | 23.8 |  |  | — |  |  | — |  |  | 23.8 |  |
| Total cash and cash equivalents | $ | 605.3 |  |  | $ | — |  |  | $ | — |  |  | $ | 605.3 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 33.3 |  |  | $ | — |  |  | $ | — |  |  | $ | 33.3 |  |
| Commercial paper | 66.1 |  |  | — |  |  | (0.4) |  |  | 65.7 |  |
| Corporate debt securities | 492.4 |  |  | — |  |  | (7.6) |  |  | 484.8 |  |
| Municipal bonds | 1.0 |  |  | — |  |  | — |  |  | 1.0 |  |
| U.S. Agency securities | 87.5 |  |  | — |  |  | (1.8) |  |  | 85.7 |  |
| U.S. Treasury securities | 353.2 |  |  | 0.1 |  |  | (4.2) |  |  | 349.1 |  |
| Total short-term investments | $ | 1,033.5 |  |  | $ | 0.1 |  |  | $ | (14.0) |  |  | $ | 1,019.6 |  |
| July 2, 2022: |  |  |  |  |  |  |  |
| Cash | $ | 235.9 |  |  | $ | — |  |  | $ | — |  |  | $ | 235.9 |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | 23.6 |  |  | — |  |  | — |  |  | 23.6 |  |
| Money market funds | 1,000.2 |  |  | — |  |  | — |  |  | 1,000.2 |  |
| U.S. Agency securities | 8.0 |  |  | — |  |  | — |  |  | 8.0 |  |
| U.S. Treasury securities | 22.5 |  |  |  |  | — |  |  | 22.5 |  |
| Total cash and cash equivalents | $ | 1,290.2 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,290.2 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 28.3 |  |  | $ | — |  |  | $ | — |  |  | $ | 28.3 |  |
| Commercial paper | 107.4 |  |  | — |  |  | (0.4) |  |  | 107.0 |  |
| Corporate debt securities | 539.9 |  |  |  |  | (7.4) |  |  | 532.5 |  |
| Municipal bonds | 1.0 |  |  | — |  |  | — |  |  | 1.0 |  |
| U.S. Agency securities | 67.1 |  |  | — |  |  | (1.4) |  |  | 65.7 |  |
| U.S. Treasury securities | 528.2 |  |  | 0.3 |  |  | (4.2) |  |  | 524.3 |  |
| Total short-term investments | $ | 1,271.9 |  |  | $ | 0.3 |  |  | $ | (13.4) |  |  | $ | 1,258.8 |  |

[0001628280-22-028783:notes:57]
We review our investment portfolio to identify and evaluate investments that have indicators of possible impairment. Factors considered in determining whether a loss is other-than-temporary include, but are not limited to, the length of time and extent a security’s fair value has been below its cost, the financial condition and near-term prospects of the investee, the credit quality of the security’s issuer, likelihood of recovery and our intent and ability to hold the security for a period of time sufficient to allow for any anticipated recovery in value. For our debt instruments, we also evaluate whether we have the intent to sell the security or whether it is more likely than not that we will be required to sell the security before recovery of its cost basis. We have not recorded our unrealized losses on our short-term investments into income because we do not intend to sell nor is it more likely than not that we will be required to sell these investments prior to recovery of their amortized cost basis.

[0001628280-22-028783:notes:58]
We use the specific-identification method to determine any realized gains or losses from the sale of our short-term investments classified as available-for-sale. During the three months ended October 1, 2022 and October 2, 2021, we did not realize significant gains or losses on a gross level from the sale of our short-term investments classified as available-for-sale.

[0001628280-22-028783:notes:59]
During the three months ended October 1, 2022 and October 2, 2021, our other income (expense), net was $13.8 million income and $0.6 million income, respectively, which includes interest and investment income on cash equivalents and short-term investments of $4.8 million and $0.6 million, respectively.

[0001628280-22-028783:notes:60]
As of October 1, 2022 and July 2, 2022, we recorded interest receivables of $3.9 million and $3.9 million, respectively, in prepayments and other current assets within the condensed consolidated balance sheets. We did not recognize an allowance for credit losses against interest receivables in any of the periods presented as there were no such losses.

[0001628280-22-028783:notes:61]
As of October 1, 2022, we had corporate debt securities and U.S. government bonds of $148.9 million and $19.7 million, respectively, that have been in a continuous unrealized loss position for more than 12 months with an unrealized loss position of $2.6 million and $0.4 million, respectively.  As of July 2, 2022, we had corporate debt securities of $57.4 million that have been in a continuous loss position for more than 12 months with an unrealized loss position of $0.9 million.

[0001628280-22-028783:notes:62]
The following table summarizes unrealized losses on our cash equivalents and short-term investments by category that have been in a continuous unrealized loss position for less than 12 months as of the periods presented (in millions):

[0001628280-22-028783:notes:63]
|  | Fair Value |  | Unrealized Losses |  |  |  |  |  |  |  |  |
| October 1, 2022: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | 86.4 |  |  | (1.8) |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | 6.4 |  |  | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | 90.2 |  |  | (0.4) |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 334.4 |  |  | (5.0) |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 262.5 |  |  | (3.7) |  |  |  |  |  |  |  |  |  |
| Total | $ | 779.9 |  |  | $ | (10.9) |  |  |  |  |  |  |  |  |  |
| July 2, 2022: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | 73.7 |  |  | $ | (1.4) |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | 16.2 |  |  | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | 130.7 |  |  | (0.4) |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 473.2 |  |  | (6.5) |  |  |  |  |  |  |  |  |  |
| Municipal bonds | 1.0 |  |  | — |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 366.0 |  |  | (4.2) |  |  |  |  |  |  |  |  |  |
| Total | $ | 1,060.8 |  |  | $ | (12.5) |  |  |  |  |  |  |  |  |  |

[0001628280-22-028783:notes:64]
[same as prior period, unchanged from 0001628280-22-012157:notes:46]

[0001628280-22-028783:notes:65]
|  | October 1, 2022 |  | July 2, 2022 |
|  | Amortized Cost |  | Fair Value |  | Amortized Cost |  | Fair Value |
| Due in 1 year | $ | 831.3 |  |  | $ | 821.2 |  |  | $ | 1,010.9 |  |  | $ | 1,002.2 |  |
| Due in 1 year through 5 years | 202.2 |  |  | 198.4 |  |  | 261.0 |  |  | 256.6 |  |
|  | $ | 1,033.5 |  |  | $ | 1,019.6 |  |  | $ | 1,271.9 |  |  | $ | 1,258.8 |  |

[0001628280-22-028783:notes:66]
[same as prior period, unchanged from 0001628280-22-012157:notes:48]


## us-gaap:FairValueDisclosuresTextBlock

[0001628280-22-028783:notes:67]
Note 6. Fair Value Measurements

[0001628280-22-028783:notes:68]
[same as prior period, unchanged from 0001628280-22-012157:notes:50]

[0001628280-22-028783:notes:69]
[same as prior period, unchanged from 0001628280-22-012157:notes:51]

[0001628280-22-028783:notes:70]
[same as prior period, unchanged from 0001628280-22-012157:notes:52]

[0001628280-22-028783:notes:71]
[same as prior period, unchanged from 0001628280-22-012157:notes:53]

[0001628280-22-028783:notes:72]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| October 1, 2022: (1) |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | — |  |  | $ | 24.5 |  |  | $ | — |  |  | $ | 24.5 |  |
| Money market funds | 221.1 |  |  | — |  |  | — |  |  | 221.1 |  |
| U.S. Agency securities | — |  |  | 9.0 |  |  | — |  |  | 9.0 |  |
| U.S. Treasury securities | 23.8 |  |  | — |  |  | — |  |  | 23.8 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | 33.3 |  |  | — |  |  | 33.3 |  |
| Commercial paper | — |  |  | 65.7 |  |  | — |  |  | 65.7 |  |
| Corporate debt securities | — |  |  | 484.8 |  |  | — |  |  | 484.8 |  |
| Municipal bonds | — |  |  | 1.0 |  |  | — |  |  | 1.0 |  |
| U.S. Agency securities | — |  |  | 85.7 |  |  | — |  |  | 85.7 |  |
| U.S. Treasury securities | 349.1 |  |  | — |  |  | — |  |  | 349.1 |  |
| Total assets | $ | 594.0 |  |  | $ | 704.0 |  |  | $ | — |  |  | $ | 1,298.0 |  |

[0001628280-22-028783:notes:73]
(1)  Excludes $326.9 million in cash held in our bank accounts as of October 1, 2022.

[0001628280-22-028783:notes:74]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| July 2, 2022: (1) |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | — |  |  | $ | 23.6 |  |  | $ | — |  |  | $ | 23.6 |  |
| Money market funds | 1,000.2 |  |  | — |  |  | — |  |  | 1,000.2 |  |
| U.S. Agency securities | — |  |  | 8.0 |  |  | — |  |  | 8.0 |  |
| U.S. Treasury securities | 22.5 |  |  | — |  |  | — |  |  | 22.5 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | 28.3 |  |  | — |  |  | 28.3 |  |
| Commercial paper | — |  |  | 107.0 |  |  | — |  |  | 107.0 |  |
| Corporate debt securities | — |  |  | 532.5 |  |  | — |  |  | 532.5 |  |
| Municipal bonds | — |  |  | 1.0 |  |  | — |  |  | 1.0 |  |
| U.S. Agency securities | — |  |  | 65.7 |  |  | — |  |  | 65.7 |  |
| U.S. Treasury securities | 524.3 |  |  | — |  |  | — |  |  | 524.3 |  |
| Total assets | $ | 1,547.0 |  |  | $ | 766.1 |  |  | $ | — |  |  | $ | 2,313.1 |  |

[0001628280-22-028783:notes:75]
(1)  Excludes $235.9 million in cash held in our bank accounts as of July 2, 2022.

[0001628280-22-028783:notes:76]
[same as prior period, unchanged from 0001628280-22-012157:notes:58]

[0001628280-22-028783:notes:77]
We report our financial instruments at fair value with the exception of the 2028 Notes, 2026 Notes and 2024 Notes. The estimated fair value of the convertible notes was determined based on the trading price of the convertible notes as of the last day of trading for the period. We consider the fair value of the notes to be a Level 2 measurement as they are not actively traded in markets.

[0001628280-22-028783:notes:78]
The carrying amounts and estimated fair values of the 2028 Notes, 2026 Notes and 2024 Notes are as follows for the periods presented (in millions):

[0001628280-22-028783:notes:79]
|  | October 1, 2022 |  | July 2, 2022 |
|  | Carrying Amount |  | Estimated Fair Value |  | Carrying Amount |  | Estimated Fair Value |
| 2028 Notes | $ | 854.5 |  |  | $ | 691.4 |  |  | $ | 634.7 |  |  | $ | 735.7 |  |
| 2026 Notes | 1,045.0 |  |  | 983.8 |  |  | 831.4 |  |  | 1,065.0 |  |
| 2024 Notes | 415.2 |  |  | 553.9 |  |  | 409.9 |  |  | 614.2 |  |
|  | $ | 2,314.7 |  |  | $ | 2,229.1 |  |  | $ | 1,876.0 |  |  | $ | 2,414.9 |  |

[0001628280-22-028783:notes:80]
[same as prior period, unchanged from 0001628280-22-012157:notes:62]

[0001628280-22-028783:notes:81]
[same as prior period, unchanged from 0001628280-22-012157:notes:63]

[0001628280-22-028783:notes:82]
Management utilizes various valuation methods, including an income approach, a market approach and a cost approach, to estimate the fair value of intangibles and other long-lived assets. During the annual impairment testing performed in the fourth quarter of fiscal 2022, we concluded that our intangible and other long-lived assets were not impaired. We review our intangible and other long-lived assets for impairment at least annually in the fourth quarter of each fiscal year, absent any interim indicators of impairment. There were no indicators of impairment during the three months ended October 1, 2022.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001628280-22-028783:notes:83]
Note 7. Balance Sheet Details

[0001628280-22-028783:notes:84]
Allowance for Current Expected Credit Losses

[0001628280-22-028783:notes:85]
We did not have any allowance for credit losses other than our allowance for uncollectible accounts receivable. As of October 1, 2022 and July 2, 2022, the allowance for credit losses on our trade receivables was $0.1 million and $0.1 million, respectively.

[0001628280-22-028783:notes:86]
[same as prior period, unchanged from 0001628280-22-012157:notes:69]

[0001628280-22-028783:notes:87]
[same as prior period, unchanged from 0001628280-22-012157:notes:70]

[0001628280-22-028783:notes:88]
|  | October 1, 2022 |  | July 2, 2022 |
| Raw materials and purchased parts | $ | 150.6 |  |  | $ | 98.9 |  |
| Work in process | 133.3 |  |  | 92.2 |  |
| Finished goods | 82.3 |  |  | 59.0 |  |
| Inventories | $ | 366.2 |  |  | $ | 250.1 |  |

[0001628280-22-028783:notes:89]
The inventory balance as of October 1, 2022 includes $80.7 million inventory from the merger with NeoPhotonics, net of amortization of fair value step-up of $4.6 million during the three months ended October 1, 2022.

[0001628280-22-028783:notes:90]
Operating Lease Right-of-Use Assets

[0001628280-22-028783:notes:91]
[same as prior period, unchanged from 0001628280-22-012157:notes:73]

[0001628280-22-028783:notes:92]
|  | October 1, 2022 |  | July 2, 2022 |
| Operating lease right-of-use assets | $ | 120.7 |  |  | $ | 102.1 |  |
| Less: accumulated amortization | (31.3) |  |  | (28.5) |  |
| Operating lease right-of-use assets, net | $ | 89.4 |  |  | $ | 73.6 |  |

[0001628280-22-028783:notes:93]
In connection with the NeoPhotonics merger, we acquired $16.9 million right-of-use assets related to leases of real estate properties used as our manufacturing and R&D premises. These leases are accounted for as operating leases and have the remaining lease term ranging from 3.8 to 6.4 years years at the merger Closing date.

[0001628280-22-028783:notes:94]
Property, Plant and Equipment, Net

[0001628280-22-028783:notes:95]
[same as prior period, unchanged from 0001628280-22-012157:notes:76]

[0001628280-22-028783:notes:96]
|  | October 1, 2022 |  | July 2, 2022 |
| Land | $ | 63.3 |  |  | $ | 49.7 |  |
| Buildings and improvement | 142.7 |  |  | 105.3 |  |
| Machinery and equipment | 614.4 |  |  | 548.8 |  |
| Computer equipment and software | 35.5 |  |  | 31.3 |  |
| Furniture and fixtures | 9.7 |  |  | 8.9 |  |
| Leasehold improvements | 44.6 |  |  | 35.7 |  |
| Construction in progress | 56.4 |  |  | 47.0 |  |
|  | 966.6 |  |  | 826.7 |  |
| Less: Accumulated depreciation | (488.6) |  |  | (466.2) |  |
| Property, plant and equipment, net | $ | 478.0 |  |  | $ | 360.5 |  |

[0001628280-22-028783:notes:97]
In connection with our merger with NeoPhotonics, we assumed $106.6 million of property, plant and equipment, net.

[0001628280-22-028783:notes:98]
[same as prior period, unchanged from 0001628280-22-012157:notes:81]

[0001628280-22-028783:notes:99]
During the three months ended October 1, 2022 and October 2, 2021, we recorded depreciation expense of $24.5 million and $20.4 million, respectively.

[0001628280-22-028783:notes:100]
Other Current Liabilities

[0001628280-22-028783:notes:101]
[same as prior period, unchanged from 0001628280-22-012157:notes:83]

[0001628280-22-028783:notes:102]
|  | October 1, 2022 |  | July 2, 2022 |
| Restructuring accrual and related charges (1) | $ | 3.1 |  |  | $ | — |  |
| Warranty accrual | 10.1 |  |  | 10.0 |  |
| Income tax payable (2) | 27.0 |  |  | 26.0 |  |
| Other current liabilities | 8.1 |  |  | 3.4 |  |
| Other current liabilities | $ | 48.3 |  |  | $ | 39.4 |  |

[0001628280-22-028783:notes:103]
[same as prior period, unchanged from 0001628280-22-012157:notes:85]

[0001628280-22-028783:notes:104]
(2) Refer to “Note 12. Income Taxes.”

[0001628280-22-028783:notes:105]
Other Non-Current Liabilities

[0001628280-22-028783:notes:106]
[same as prior period, unchanged from 0001628280-22-012157:notes:89]

[0001628280-22-028783:notes:107]
|  | October 1, 2022 |  | July 2, 2022 |
| Asset retirement obligations | $ | 8.0 |  |  | $ | 4.6 |  |
| Pension and related accrual (1) | 9.4 |  |  | 7.7 |  |
| Unrecognized tax benefit | 50.9 |  |  | 30.5 |  |
| Other non-current liabilities | 7.6 |  |  | 0.1 |  |
| Other non-current liabilities | $ | 75.9 |  |  | $ | 42.9 |  |

[0001628280-22-028783:notes:108]
(1) We have defined benefit pension plans in Japan, Switzerland, and Thailand. In connection with our merger with NeoPhotonics, we assumed an additional defined benefit plan covering employees in Japan. As of October 1, 2022, the projected benefit obligations, net of plan assets, in Japan, Switzerland and Thailand were $4.3 million, $1.7 million and $3.4 million, respectively. As of July 2, 2022, the projected benefit obligations, net of plan assets, in Japan, Switzerland and Thailand were $2.6 million, $1.7 million and $3.4 million, respectively. We typically re-evaluate the assumptions related to the fair value of our defined benefit obligations annually and make any updates as necessary.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001628280-22-028783:notes:109]
Note 8. Goodwill and Other Intangible Assets

[0001628280-22-028783:notes:110]
Goodwill

[0001628280-22-028783:notes:111]
In the first quarter of fiscal 2023, we completed two acquisitions, our merger with NeoPhotonics and the acquisition of IPG Photonics’ telecom transmission product lines. As of the acquisition dates, we recognized goodwill in the amount of $318.3 million related to the NeoPhotonics merger and $6.5 million related to the acquisition of the IPG Photonics’ telecom transmission product lines. We  allocated the entire goodwill amount in connection with the acquisitions to the OpComms segment.

[0001628280-22-028783:notes:112]
The following table presents the changes in goodwill by reportable segments during the three months ended October 1, 2022 (in millions):

[0001628280-22-028783:notes:113]
|  | Optical Communications |  | Commercial Lasers |  | Total |
| Balance as of July 2, 2022 | $ | 363.5 |  |  | $ | 5.4 |  |  | $ | 368.9 |  |
| Acquisition of NeoPhotonics | 318.3 |  |  | — |  |  | 318.3 |  |
| Acquisition of IPG Photonics’ Telecom Transmission Product Lines | 6.5 |  |  | — |  |  | 6.5 |  |
| Balance as of October 1, 2022 | $ | 688.3 |  |  | $ | 5.4 |  |  | $ | 693.7 |  |

[0001628280-22-028783:notes:114]
Impairment of Goodwill

[0001628280-22-028783:notes:115]
We review goodwill for impairment during the fourth quarter of each fiscal year or more frequently if events or circumstances indicate that an impairment loss may have occurred. In the fourth quarter of fiscal 2022, we completed the annual impairment test of goodwill, which indicated there was no goodwill impairment. There were no indicators of goodwill impairment during the three months ended October 1, 2022.

[0001628280-22-028783:notes:116]
Other Intangibles

[0001628280-22-028783:notes:117]
The intangible assets are amortized on a straight-line basis over the estimated useful lives, except for customer relationships, which are amortized using an accelerated method of amortization over the expected customer lives, more accurately reflecting the pattern of realization of economic benefits expected to be obtained. Acquired developed technologies are amortized to cost of sales and customer relationships are amortized to selling, general and administrative expenses in the consolidated statement of operations.

[0001628280-22-028783:notes:118]
In-process research and development (IPR&D) is initially capitalized at fair value as an intangible asset with an indefinite life and assessed for impairment thereafter. When an IPR&D project is completed, the IPR&D is reclassified as an amortizable purchased intangible asset and amortized over the asset’s estimated useful life.

[0001628280-22-028783:notes:119]
In the first quarter of fiscal 2023, we recorded the preliminary fair value of acquired intangible assets of $412.5 million related to the merger with NeoPhotonics and $40.0 million related to the acquisition of IPG Photonics’ telecom transmission product lines (“IPG product lines”). Refer to “Note 4. Business Combinations.”

[0001628280-22-028783:notes:120]
The intangible assets acquired from the acquisitions in the first quarter of fiscal 2023 were as follows (in millions, except for weighted average amortization periods):

[0001628280-22-028783:notes:121]
|  | Preliminary fair value at the acquisition date |  | Weighted average amortization period(in years) |
|  | NeoPhotonics |  | IPG product lines |  | Total acquired |  |
| Acquired developed technologies | $ | 220.0 |  |  | $ | 8.6 |  |  | $ | 228.6 |  |  | 5.2 |
| Customer relationships | 144.5 |  |  | 2.3 |  |  | 146.8 |  |  | 5.9 |
| In-process research and development | 48.0 |  |  | 29.1 |  |  | 77.1 |  |  | n/a |
|  | $ | 412.5 |  |  | $ | 40.0 |  |  | $ | 452.5 |  |  |  |

[0001628280-22-028783:notes:122]
The following tables present details of our other intangibles, including those acquired in connection with our acquisitions in the first quarter of fiscal 2023, as of the periods presented (in millions, except for weighted average remaining amortization period):

[0001628280-22-028783:notes:123]
| October 1, 2022 | Gross Carrying Amounts |  | Accumulated Amortization |  | Net Carrying Amounts |  | Weighted average remaining amortization period (years) |
| Acquired developed technologies | $ | 618.9 |  |  | $ | (327.0) |  |  | $ | 291.9 |  |  | 4.9 |
| Customer relationships | 291.8 |  |  | (84.8) |  |  | 207.0 |  |  | 5.5 |
| In-process research and development | 77.1 |  |  | — |  |  | 77.1 |  |  | n/a |
| Total intangible assets | $ | 987.8 |  |  | $ | (411.8) |  |  | $ | 576.0 |  |  |  |

[0001628280-22-028783:notes:124]
| July 2, 2022 | Gross Carrying Amounts |  | Accumulated Amortization |  | Net Carrying Amounts |  | Weighted average remaining amortization period (years) |
| Acquired developed technologies | $ | 390.3 |  |  | $ | (303.6) |  |  | $ | 86.7 |  |  | 2.5 |
| Customer relationships | 145.0 |  |  | (76.0) |  |  | 69.0 |  |  | 4.4 |
| Total intangible assets | $ | 535.3 |  |  | $ | (379.6) |  |  | $ | 155.7 |  |  |  |

[0001628280-22-028783:notes:125]
The following table presents details of amortization for the periods presented (in millions):

[0001628280-22-028783:notes:126]
|  | Three Months Ended |  |  |
|  | October 1, 2022 |  | October 2, 2021 |  |  |  |  |
| Cost of sales | $ | 22.9 |  |  | $ | 15.8 |  |  |  |  |  |
| Selling, general and administrative | 9.3 |  |  | 5.6 |  |  |  |  |  |
| Total amortization of intangibles | $ | 32.2 |  |  | $ | 21.4 |  |  |  |  |  |

[0001628280-22-028783:notes:127]
Based on the carrying amount of our acquired developed technologies and customer relationships as of October 1, 2022, and assuming no future impairment of the underlying assets, the estimated future amortization is as follows (in millions):

[0001628280-22-028783:notes:128]
| Fiscal Years |  |
| Remainder of 2023 | $ | 93.6 |  |
| 2024 | 110.2 |  |
| 2025 | 97.3 |  |
| 2026 | 84.9 |  |
| 2027 | 73.0 |  |
| Thereafter | 39.9 |  |
| Total future amortization | $ | 498.9 |  |


## us-gaap:DebtDisclosureTextBlock

[0001628280-22-028783:notes:129]
Note 9. Debt

[0001628280-22-028783:notes:130]
Convertible Notes

[0001628280-22-028783:notes:131]
2028 Notes

[0001628280-22-028783:notes:132]
In March 2022, we issued $861.0 million in aggregate principal amount of 0.50% Convertible Notes due in 2028 (the “2028 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act of 1933, as amended (the “Securities Act”). The 2028 Notes are governed by an indenture between the Company and U.S. Bank Trust Company National Association (as successor in interest to U.S. Bank National Association), as a trustee (the “2028 Indenture”). The 2028 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001628280-22-028783:notes:133]
The net proceeds from the sale of the 2028 Notes was $854.8 million, after deducting $6.2 million in issuance costs. In addition, we incurred $0.7 million in professional fees in connection with this transaction. Concurrent with the issuance of the 2028 Notes, we used $200.0 million of the net proceeds to repurchase our common stock in privately negotiated transactions. We intend to use the remaining net proceeds for general corporate purposes, which may include capital expenditures and working capital.

[0001628280-22-028783:notes:134]
The 2028 Notes bear interest at a rate of 0.50% per year, payable semi-annually in arrears on June 15 and December 15 of each year, beginning on June 15, 2022. The 2028 Notes will mature on June 15, 2028, unless earlier redeemed, repurchased by us, or converted pursuant to the terms.

[0001628280-22-028783:notes:135]
The initial conversion rate is 7.6319 shares of common stock per $1,000 principal amount of the 2028 Notes (which is equivalent to an initial conversion price of approximately $131.03 per share). The conversion rate is subject to adjustment upon the occurrence of certain specified events, but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert the 2028 Notes in connection with such make-whole fundamental change or notice of redemption.

[0001628280-22-028783:notes:136]
Prior to the close of business on the business day immediately preceding March 15, 2028, holders of the 2028 Notes may convert their 2028 Notes only under the following circumstances:

[0001628280-22-028783:notes:137]
•during any fiscal quarter commencing after July 2, 2022 (and only during such fiscal quarter), if the last reported sale price of the Company’s common stock for at least 20 trading days (whether or not consecutive) during the 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price, or $170.34, on each applicable trading day;

[0001628280-22-028783:notes:138]
•during the five consecutive business day period after any five consecutive trading day period (the “measurement period”) in which the trading price per $1,000 principal amount of the 2028 Notes for each trading day of such measurement was less than 98% of the product of the last reported sale price of the Company’s common stock and the applicable conversion rate on each such trading day;

[0001628280-22-028783:notes:139]
•if the Company calls any or all of the 2028 Notes for redemption, at any time prior to the close of business on the second business day immediately preceding the redemption date; or

[0001628280-22-028783:notes:140]
•upon the occurrence of specified corporate events, as specified in the 2028 Indentures.

[0001628280-22-028783:notes:141]
On or after March 15, 2028 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their 2028 Notes at any time. Upon conversion, we may satisfy our conversion obligation in cash, shares of common stock or a combination of cash and shares of common stock, at our election.

[0001628280-22-028783:notes:142]
We may redeem for cash all or any of the 2028 Notes, at our option (subject to the partial redemption limitation set forth in the 2028 Indenture), on or after June 20, 2025, if the last reported sale price of its common stock has been at least 130% of the conversion price then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading-day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which the Company provides notice of redemption at a redemption price equal to 100% of the principal amount of the 2028 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. No sinking fund is provided for the 2028 Notes. If we elect to redeem fewer than all of the outstanding 2028 Notes, at least $100.0 million aggregate principal amount of the 2028 Notes must be outstanding and not subject to redemption as of the redemption notice date. Upon the occurrence of a fundamental change (as defined in the 2028 Indenture), holders may require the Company to

[0001628280-22-028783:notes:143]
repurchase all or a portion of their 2028 Notes for cash at a price equal to 100% of the principal amount of the 2028 Notes to be repurchased, plus any accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

[0001628280-22-028783:notes:144]
We initially bifurcated the principal amount of the 2028 Notes into liability and equity components. The liability component of the 2028 Notes was initially valued at $629.8 million based on the contractual cash flow discounted at an appropriate comparable market on non-convertible debt borrowing rate at the date of issuance, which was 5.7%, with the equity component representing the residual amount of the proceeds of $231.2 million, which was recorded as a debt discount. Upon adoption of ASU 2020-06 in the first quarter of fiscal 2023, our 2028 Notes were accounted for as a single liability measured at amortized cost. Refer to “Note 2. Recently Issued Accounting Pronouncement” for the detailed adoption impact.

[0001628280-22-028783:notes:145]
2026 Notes

[0001628280-22-028783:notes:146]
In December 2019, we issued $1,050.0 million in aggregate principal amount of 0.50% Convertible Notes due in 2026 (the “2026 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act. The 2026 Notes are governed by an indenture between the Company and U.S. Bank Trust Company National Association (as successor in interest to U.S. Bank National Association, as a trustee (the “2026 Indenture”). We used approximately $196.0 million of the net proceeds of the offering to repay in full all amounts outstanding under our term loan credit facility, and a portion of the net proceeds of the offering to purchase approximately $200.0 million of our common stock concurrently with the pricing of the offering in privately negotiated transactions. The 2026 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001628280-22-028783:notes:147]
The 2026 Notes bear interest at a rate of 0.50% per year, payable semi-annually in arrears on June 15 and December 15 of each year, beginning on June 15, 2020. The 2026 Notes will mature on December 15, 2026, unless earlier redeemed, repurchased by us, or converted pursuant to their terms.

[0001628280-22-028783:notes:148]
The initial conversion rate is 10.0711 shares of common stock per $1,000 principal amount of the 2026 Notes (which is equivalent to an initial conversion price of approximately $99.29 per share). The conversion rate is subject to adjustment upon the occurrence of certain events specified in the 2026 Indenture but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares set forth in the 2026 Indenture or a holder that elects to convert the 2026 Notes in connection with such make-whole fundamental change or notice of redemption.

[0001628280-22-028783:notes:149]
Prior to the close of business on the business day immediately preceding September 15, 2026, holders of the 2026 Notes may convert their 2026 Notes only under the following circumstances:

[0001628280-22-028783:notes:150]
•during any fiscal quarter (and only during such fiscal quarter), if the last reported sale price of the common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price of the 2026 Notes, or $129.08 on each applicable trading day;

[0001628280-22-028783:notes:151]
•during the five business day period after any five consecutive trading day period (the "2026 measurement period") in which the trading price per $1,000 principal amount of the 2026 Notes for each trading day of the 2026 measurement period was less than 98% of the product of the last reported sale price of our common stock and the conversion rate for the 2026 Notes on each such trading day;

[0001628280-22-028783:notes:152]
•if we call any or all of the 2026 Notes for redemption, at any time prior to the close of business on the second business day immediately preceding the relevant redemption date; or

[0001628280-22-028783:notes:153]
•upon the occurrence of specified corporate events.

[0001628280-22-028783:notes:154]
On or after September 15, 2026 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert the 2026 Notes at any time. Upon conversion, we may satisfy our conversion obligation in cash, shares of common stock or a combination of cash and shares of common stock, at our election.

[0001628280-22-028783:notes:155]
We may redeem for cash, for all or any portion of the 2026 Notes, at our option, on or after December 20, 2023, if the last reported sale price of its common stock has been at least 130% of the conversion price then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading-day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which we provide a notice of redemption at a redemption price equal to 100% of the principal amount of the 2026 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. No sinking fund is provided for the 2026 Notes. Upon the occurrence of a fundamental change (as defined in the 2026 Indenture), holders may require us to repurchase all or a portion of the 2026 Notes for cash at a

[0001628280-22-028783:notes:156]
price equal to 100% of the principal amount of the 2026 Notes to be repurchased, plus any accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

[0001628280-22-028783:notes:157]
We initially bifurcated the principal amount of the 2026 Notes into liability and equity components. The liability component of the 2026 Notes was initially valued at $734.8 million based on the contractual cash flows discounted at an appropriate comparable market non-convertible debt borrowing rate at the date of issuance of 5.8% with the equity component representing the residual amount of the proceeds of $315.2 million, which was recorded as a debt discount. Upon adoption of ASU 2020-06 in the first quarter of fiscal 2023, our 2026 Notes were accounted for as a single liability measured at amortized cost.  Refer to “Note 2. Recently Issued Accounting Pronouncement” for the detailed adoption impact.

[0001628280-22-028783:notes:158]
2024 Notes

[0001628280-22-028783:notes:159]
In March 2017, we issued $450.0 million in aggregate principal amount 2024 Notes in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act. The 2024 Notes are governed by an indenture between the Company, as the issuer, and U.S. Bank Trust Company National Association (as successor in interest to U.S. Bank National Association), as trustee (the “2024 Indenture”). The 2024 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001628280-22-028783:notes:160]
The 2024 Notes bear interest at a rate of 0.25% per year. Interest on the 2024 Notes is payable semi-annually in arrears on March 15 and September 15 of each year, beginning on September 15, 2017. The 2024 Notes will mature on March 15, 2024, unless earlier repurchased by us or converted pursuant to their terms.

[0001628280-22-028783:notes:161]
The initial conversion rate of the 2024 Notes is 16.4965 shares of common stock per $1,000 principal amount of 2024 Notes, which is equivalent to an initial conversion price of approximately $60.62 per share, a 132.5% premium to the fair market value at the date of issuance.  Prior to the close of business on the business day immediately preceding December 15, 2023, each holder of the 2024 Notes may convert their 2024 Notes only under the following circumstances:

[0001628280-22-028783:notes:162]
•during any fiscal quarter (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during the period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price, or $78.80 on each applicable trading day;

[0001628280-22-028783:notes:163]
•during the five consecutive business day period after any five consecutive trading day period (the “2024 measurement period”) in which the trading price per $1,000 principal amount of 2024 Notes for each trading day of such 2024 measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate on each such trading day;

[0001628280-22-028783:notes:164]
On or after December 15, 2023 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their 2024 Notes at any time. In addition, upon the occurrence of a make-whole fundamental change (as defined in the 2024 Indenture), we will, in certain circumstances, increase the conversion rate by a number of additional shares set forth in the 2024 Indenture for a holder that elects to convert 2024 Notes in connection with such make-whole fundamental change.

[0001628280-22-028783:notes:165]
We may not redeem the 2024 Notes prior to their maturity date and no sinking fund is provided for the 2024 Notes. Upon the occurrence of a fundamental change, holders may require us to repurchase all or a portion of their 2024 Notes for cash at a price equal to 100% of the principal amount of the 2024 Notes to be repurchased, plus any accrued and unpaid interest.

[0001628280-22-028783:notes:166]
During the three months ended October 1, 2022, we received conversion requests of less than $0.1 million principal amount of the 2024 Notes, which we settled with cash in accordance with the 2024 Indenture. Since issuing the 2024 Notes, we have converted a total of approximately $1.9 million principal amount of the 2024 Notes. The remaining principal amount of the 2024 Notes as of October 1, 2022 was $448.1 million.

[0001628280-22-028783:notes:167]
We considered the features embedded in the 2024 Notes other than the conversion feature, including the holders’ put feature, our call feature, and the make-whole feature, and concluded that they are not required to be bifurcated and accounted for separately from the host debt instrument. Prior to the Tax Matters Agreement settlement condition (“TMA settlement condition”), because we could only settle the 2024 Notes in cash, we determined that the conversion feature met the definition of a derivative liability. We separated the derivative liability from the host debt instrument based on the fair value of the derivative liability. During fiscal 2017, we satisfied the TMA settlement condition. As such, the value of the conversion option

[0001628280-22-028783:notes:168]
is no longer marked-to-market and was reclassified to additional paid-in capital within stockholders’ equity on our condensed consolidated balance sheets. The adoption of ASU 2020-06 did not change the presentation of the 2024 Notes, as the conversion feature associated with the 2024 Notes continues to be classified within stockholders’ equity.

[0001628280-22-028783:notes:169]
Convertible Notes - Additional Disclosures

[0001628280-22-028783:notes:170]
Our convertible notes consisted of the following components as of the periods presented (in millions):

[0001628280-22-028783:notes:171]
| Liability component: | October 1, 2022 |  | July 2, 2022 |
|  | 2024 Notes (1) |  | 2026 Notes (2) |  | 2028 Notes (3) |  | 2024 Notes (1) |  | 2026 Notes (2) |  | 2028 Notes (3) |
| Principal | $ | 448.1 |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |  | $ | 448.1 |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |
| Unamortized debt discount and issuance costs | (32.9) |  |  | (5.0) |  |  | (6.5) |  |  | (38.2) |  |  | (218.6) |  |  | (226.3) |  |
| Net carrying amount of the liability component | $ | 415.2 |  |  | $ | 1,045.0 |  |  | $ | 854.5 |  |  | $ | 409.9 |  |  | $ | 831.4 |  |  | $ | 634.7 |  |

[0001628280-22-028783:notes:172]
(1) If the closing price of our stock exceeds $78.80 (or 130% of the conversion price of $60.62) for 20 of the last 30 trading days of any future quarter, our 2024 Notes would become convertible at the option of the holders. During the fourth quarter of fiscal 2022, the 2024 Notes were convertible at the option of the holders and therefore, the debt component of our 2024 Notes was classified as current liabilities in our condensed consolidated balance sheet. While the 2024 Notes will not be convertible during the second quarter of fiscal 2023, as our stock price did not exceed $78.80 for 20 of the last 30 trading days of the quarter ended October 1, 2022, we continue to classify the 2024 Notes in current liabilities as this presentation provides consistency and better comparability with our prior periods.

[0001628280-22-028783:notes:173]
(2) If the closing price of our stock exceeds $129.08 (or 130% of the conversion price of $99.29) for 20 of the last 30 trading days of any future quarter, our 2026 Notes would become convertible at the option of the holders and the debt would be reclassified to current liabilities in our condensed consolidated balance sheet.

[0001628280-22-028783:notes:174]
(3) If the closing price of our stock exceeds $170.34 (or 130% of the conversion price of $131.03) for 20 of the last 30 trading days of such quarter, our 2028 Notes would become convertible at the option of the holders and the debt would be reclassified to current liabilities in our condensed consolidated balance sheet.

[0001628280-22-028783:notes:175]
The following table sets forth interest expense information related to the convertible notes for the periods presented (in millions):

[0001628280-22-028783:notes:176]
|  | Three Months Ended |  |  |
|  | October 1, 2022 |  | October 2, 2021 |  |  |  |  |
| Contractual interest expense | $ | 2.7 |  |  | $ | 1.6 |  |  |  |  |  |
| Amortization of the debt discount and debt issuance costs | 5.7 |  |  | 15.3 |  |  |  |  |  |
| Total interest expense | $ | 8.4 |  |  | $ | 16.9 |  |  |  |  |  |

[0001628280-22-028783:notes:177]
The future interest and principal payments related to our convertible notes are as follows as of October 1, 2022 (in millions):

[0001628280-22-028783:notes:178]
| Fiscal Years | 2024 Notes |  | 2026 Notes |  | 2028 Notes |  | Total |
| Remainder of 2023 | $ | 0.6 |  |  | $ | 5.3 |  |  | $ | 4.3 |  |  | $ | 10.2 |  |
| 2024 | 449.2 |  |  | 5.3 |  |  | 4.3 |  |  | 458.8 |  |
| 2025 | — |  |  | 5.3 |  |  | 4.3 |  |  | 9.6 |  |
| 2026 | — |  |  | 5.3 |  |  | 4.3 |  |  | 9.6 |  |
| 2027 | — |  |  | 1,052.4 |  |  | 869.6 |  |  | 1,922.0 |  |
| Total convertible notes payments | $ | 449.8 |  |  | $ | 1,073.6 |  |  | $ | 886.8 |  |  | $ | 2,410.2 |  |

[0001628280-22-028783:notes:179]
The principal balances of our convertible notes are reflected in the payment periods in the table above based on their respective contractual maturities.

[0001628280-22-028783:notes:180]
Mitsubishi Bank Loans

[0001628280-22-028783:notes:181]
In connection with our merger of NeoPhotonics, we assumed several loan agreements with MUFG Bank, Ltd. (the “Mitsubishi Bank”).

[0001628280-22-028783:notes:182]
In February 2015, NeoPhotonics entered into a loan agreement with Mitsubishi Bank, that provided for a term loan in the aggregate principal amount of 1.0 billion JPY (approximately $6.9 million based on the exchange rate on October 1, 2022) (the “2015 Mitsubishi Bank Loan”). The 2015 Mitsubishi Bank Loan is secured by a mortgage on certain real property and buildings owned by NeoPhotonic’s Japanese subsidiary. The 2015 Mitsubishi Bank Loan accrues interest and is paid monthly based upon the annual rate of the monthly Tokyo Interbank Offer Rate ("TIBOR") plus 1.40%.  The term loan requires equal monthly payments of principal equal to 8.3 million JPY (approximately $0.1 million based on the exchange rate on October 1, 2022) until the maturity date of February 25, 2025, with a lump sum payment of the balance of 8.4 million JPY (approximately $0.1 million based on the exchange rate on October 1, 2022) on the maturity date.  The outstanding principal balance for the 2015 Mitsubishi Bank Loan was 241.7 million JPY (approximately $1.6 million) as of October 1, 2022.

[0001628280-22-028783:notes:183]
In March 2017, NeoPhotonics entered into a loan agreement with Mitsubishi Bank for a term loan of 690.0 million JPY (approximately $4.8 million based on the exchange rate on October 1, 2022) (the “2017 Mitsubishi Bank Loan”) to acquire manufacturing equipment for its Japanese subsidiary. This loan is secured by the manufacturing equipment owned by the NeoPhotonics' subsidiary in Japan. Interest on the 2017 Mitsubishi Bank Loan is based on the annual rate of the monthly TIBOR rate plus 1.00%. The 2017 Mitsubishi Bank Loan matures on March 29, 2024 and requires monthly interest and principal payments over 72 months commencing in April 2018. The outstanding principal balance for the 2017 Mitsubishi Bank Loan was 172.5 million JPY (approximately $1.3 million) as of October 1, 2022.

[0001628280-22-028783:notes:184]
In January 2018, NeoPhotonics entered into a term loan agreement with Mitsubishi Bank and The Yamanashi Chuo Bank, Ltd. for a term loan in the aggregate principal amount of 850.0 million JPY (approximately $5.9 million based on the exchange rate on October 1, 2022) (the “2018 Mitsubishi Bank Loan”). The purpose of this term loan was to obtain machinery for the core parts of the manufacturing line and payments for related expenses by NeoPhotonics' subsidiary in Japan. This term loan requires no additional security. Interest on the term loan is based upon the annual rate of the three months TIBOR rate plus 1.00%. The term loan requires quarterly interest payments, along with the principal payments, over 82 months commencing in April 2018. The outstanding principal balance for the 2018 Mitsubishi Bank Loan was approximately 303.6 million JPY (approximately $2.1 million) as of October 1, 2022.

[0001628280-22-028783:notes:185]
All of these term loans contain customary representations and warranties, and customary affirmative and negative covenants applicable to NeoPhotonics’ Japanese subsidiary, including, among other things, restrictions on cessation in business, management, mergers or acquisitions. These term loans contain customary covenants relating to minimum net assets, maximum ordinary loss and a coverage ratio covenant. We are in compliance with the related covenants for all these term loans as of October 1, 2022.

[0001628280-22-028783:notes:186]
We intend to repay all amounts outstanding under the 2015 Mitsubishi Bank Loan, 2017 Mitsubishi Bank Loan and 2018 Mitsubishi Bank Loan during fiscal year 2023. As such, we presented these term loans within short term debt in our condensed consolidated balance sheet.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001628280-22-028783:notes:187]
[same as prior period, unchanged from 0001628280-22-012157:notes:153]

[0001628280-22-028783:notes:188]
[same as prior period, unchanged from 0001628280-22-012157:notes:154]

[0001628280-22-028783:notes:189]
[same as prior period, unchanged from 0001628280-22-012157:notes:155]

[0001628280-22-028783:notes:190]
|  | Foreign currency translation adjustments, net of tax (1) |  | Defined benefit obligations, net of tax (2) |  | Unrealized gain (loss) on available-for-sale securities, net of tax |  |  |  | Total |
| Beginning balance as of July 2, 2022 | $ | 9.7 |  |  | $ | 1.0 |  |  | $ | (10.3) |  |  |  |  | $ | 0.4 |  |
| Other comprehensive loss | — |  |  | — |  |  | (0.6) |  |  |  |  | (0.6) |  |
| Ending balance as of October 1, 2022 | 9.7 |  |  | 1.0 |  |  | (10.9) |  |  |  |  | (0.2) |  |
|  | Foreign currency translation adjustments, net of tax (1) |  | Defined benefit obligations, net of tax (2) |  | Unrealized gain (loss) on available-for-sale securities, net of tax |  |  |  | Total |
| Beginning balance as of July 3, 2021 | $ | 9.7 |  |  | $ | (1.4) |  |  | $ | (0.1) |  |  |  |  | $ | 8.2 |  |
| Other comprehensive income | — |  |  | — |  |  | 0.3 |  |  |  |  | 0.3 |  |
| Ending balance as of October 2, 2021 | 9.7 |  |  | (1.4) |  |  | 0.2 |  |  |  |  | 8.5 |  |

[0001628280-22-028783:notes:191]
(1) In fiscal 2019, we established the functional currency for our worldwide operations as the U.S. dollar. Translation adjustments reported prior to December 10, 2018 remain as a component of accumulated other comprehensive income (loss) in our condensed consolidated balance sheets, until all or a part of the investment in the subsidiaries is sold or liquidated.

[0001628280-22-028783:notes:192]
[same as prior period, unchanged from 0001628280-22-012157:notes:158]


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001628280-22-028783:notes:193]
[same as prior period, unchanged from 0001628280-22-012157:notes:159]

[0001628280-22-028783:notes:194]
We have initiated various strategic restructuring actions primarily intended to reduce costs, consolidate our operations, rationalize the manufacturing of our products and align our business in response to market conditions and as a result of our acquisitions in the first quarter of fiscal 2023.

[0001628280-22-028783:notes:195]
[same as prior period, unchanged from 0001628280-22-012157:notes:161]

[0001628280-22-028783:notes:196]
|  | Three Months Ended |  |  |
|  | October 1, 2022 |  | October 2, 2021 |  |  |  |  |
| Balance as of beginning of period | $ | — |  |  | $ | 5.7 |  |  |  |  |  |
| Charges (reversals), net | 9.3 |  |  | (1.1) |  |  |  |  |  |
| Payments | (6.2) |  |  | (3.8) |  |  |  |  |  |
| Balance as of end of period | $ | 3.1 |  |  | $ | 0.8 |  |  |  |  |  |

[0001628280-22-028783:notes:197]
During the three months ended October 1, 2022, we recorded restructuring and related charges of $9.3 million in our condensed consolidated statements of operations which was primarily attributable to severance and employee-related benefits associated with NeoPhotonics’ executive severance and retention agreements. These retention agreements provide, under certain circumstances, for payments and benefits upon an involuntary termination of employment. We made $6.2 million of payments in connection with these agreements during the three months ended October 1, 2022.

[0001628280-22-028783:notes:198]
During the three months ended October 2, 2021, we recorded a net reversal to our restructuring and related charges of $1.1 million in our condensed consolidated statements of operations, which was attributable to lower than anticipated employee severance charges primarily as a result of retaining and re-assigning certain employees.

[0001628280-22-028783:notes:199]
[same as prior period, unchanged from 0001628280-22-012157:notes:165]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-22-028783:notes:200]
[same as prior period, unchanged from 0001628280-22-012157:notes:166]

[0001628280-22-028783:notes:201]
[same as prior period, unchanged from 0001628280-22-012157:notes:167]

[0001628280-22-028783:notes:202]
We recorded a tax provision of $19.2 million and $18.1 million for the three months ended October 1, 2022 and October 2, 2021, respectively. Our tax provision for the three months ended October 1, 2022 includes a discrete tax expense of $13.1 million, primarily related to the international restructuring and currency re-measurement of certain tax related accounts, partially offset by the tax benefit from tax rate changes. Our estimated effective tax rate for fiscal 2023 also differs from the 21% U.S. statutory rate primarily due to the income tax expense from the tax effect of Global Intangible Low-Taxed Income (“GILTI”), net of benefit for foreign tax credits, subpart F inclusion and non-deductible stock-based compensation, partially offset by the income tax benefit from the earnings of our foreign subsidiaries being taxed at rates that differ from the U.S. statutory rate, and U.S. federal R&D tax credits.

[0001628280-22-028783:notes:203]
As of October 1, 2022, we had $53.8 million of unrecognized tax benefits, which, if recognized, would affect the effective tax rate. We are subject to examination of income tax returns by various domestic and foreign tax authorities. The timing of resolution and closure of tax audits is highly unpredictable. Although it is possible that certain ongoing tax audits may be concluded within the next 12 months, we cannot reasonably estimate the impact to tax expense and net income from tax exams that could be resolved or closed within the next 12 months. Subject to audit timing and uncertainty, we expect the amount of unrecognized tax benefit that would become recognized due to expiration of the statute of limitations and affect the effective tax rate to decrease by $0.5 million over the next 12 months.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001628280-22-028783:notes:204]
[same as prior period, unchanged from 0001628280-22-012157:notes:170]

[0001628280-22-028783:notes:205]
[same as prior period, unchanged from 0001628280-22-012157:notes:171]

[0001628280-22-028783:notes:206]
[same as prior period, unchanged from 0001628280-22-012157:notes:172]

[0001628280-22-028783:notes:207]
As of October 1, 2022, we had 4.1 million shares subject to restricted stock units, restricted stock awards, and performance stock units issued and outstanding under the 2015 Equity Incentive Plan (“2015 Plan”). These grants are performance-based, time-based or a combination of both and are expected to vest over one to four years. The fair value of these grants is based on the closing market price of our common stock on the date of grant. As of October 1, 2022, 1.9 million shares of common stock under the 2015 Plan were available for grant.

[0001628280-22-028783:notes:208]
Replacement Awards

[0001628280-22-028783:notes:209]
In connection with the merger with NeoPhotonics, we issued equity awards to certain NeoPhotonics employees, consisting of restricted stock units (the “Replacement Awards”) in exchange for their NeoPhotonics equity awards. The terms of these Replacement Awards are substantially similar to the original NeoPhotonics equity awards. The Replacement Awards consisted of 0.4 million restricted stock units with a grant date fair value of $93.4 per share, which represents our closing stock price on the Closing date. The total fair value of these Replacement Awards is $40.2 million, $3.5 million of which is attributed to employee services rendered through August 3, 2022, the merger Closing date, and was recognized as a component of the merger consideration. The remaining fair value of the Replacement Awards is recorded as stock-based compensation over the remaining vesting period. Refer to “Note 4. Business Combinations.”

[0001628280-22-028783:notes:210]
[same as prior period, unchanged from 0001628280-22-012157:notes:176]

[0001628280-22-028783:notes:211]
[same as prior period, unchanged from 0001628280-22-012157:notes:177]

[0001628280-22-028783:notes:212]
During the three months ended October 1, 2022, our board of directors approved grants of 1.5 million RSUs which primarily vest over three years. In addition, we issued 0.4 million RSUs that were issued as part of the Replacement Awards in connection with the merger with NeoPhotonics as described above.

[0001628280-22-028783:notes:213]
[same as prior period, unchanged from 0001628280-22-012157:notes:179]

[0001628280-22-028783:notes:214]
Performance stock units (“PSUs”) under the 2015 Plan are grants of shares of our common stock that vest upon the achievement of certain performance and service conditions. We begin recognizing compensation expense when we conclude that it is probable that the performance conditions will be achieved. We reassess the probability of vesting at each reporting period and adjust our compensation cost based on this probability assessment. Our PSUs are subject to risk of forfeiture until performance and service conditions are satisfied and generally vest between one and three years.

[0001628280-22-028783:notes:215]
During the three months ended October 1, 2022, 0.3 million PSUs were issued to executive and certain non-executive employees as part of our revised Annual Incentive Plan. These PSUs have an aggregate grant date fair value of $26.0 million and are subject to performance targets and service conditions, and vest over a one-year period. The board of directors also approved a grant of 0.2 million PSUs with an aggregate grant date fair value of $22.6 million to certain executive officers and senior management. These PSUs will vest subject to the achievement of revenue targets and certain non-financial performance measurement, as well as service conditions, over three years.

[0001628280-22-028783:notes:216]
[same as prior period, unchanged from 0001628280-22-012157:notes:182]

[0001628280-22-028783:notes:217]
Our 2015 Employee Stock Purchase Plan (the “2015 Purchase Plan”) provides eligible employees with the opportunity to acquire an ownership interest in the Company through periodic payroll deductions and provides a 15% purchase price discount as well as a 6-month look-back period. The 2015 Purchase Plan is structured as a qualified employee stock purchase plan under Section 423 of the Internal Revenue Code of 1986, as amended. The 2015 Purchase Plan will terminate upon the date on which all shares available for issuance have been sold. Of the 3.0 million shares authorized under the 2015 Purchase Plan, 1.4 million shares remained available for issuance as of October 1, 2022.

[0001628280-22-028783:notes:218]
[same as prior period, unchanged from 0001628280-22-012157:notes:184]

[0001628280-22-028783:notes:219]
[same as prior period, unchanged from 0001628280-22-012157:notes:185]

[0001628280-22-028783:notes:220]
|  | Three Months Ended |  |  |
|  | October 1, 2022 |  | October 2, 2021 |  |  |  |  |
| Cost of sales | $ | 5.5 |  |  | $ | 4.6 |  |  |  |  |  |
| Research and development | 9.6 |  |  | 5.0 |  |  |  |  |  |
| Selling, general and administrative | 31.5 |  |  | 15.2 |  |  |  |  |  |
| Total stock-based compensation | $ | 46.6 |  |  | $ | 24.8 |  |  |  |  |  |

[0001628280-22-028783:notes:221]
In connection with the NeoPhotonics merger, certain equity awards for NeoPhotonics employees were accelerated. The total stock-based compensation associated with the acceleration was $11.9 million for the three months ended October 1, 2022, of which $9.0 million was settled in cash. Refer to “Note 4. Business Combinations.”

[0001628280-22-028783:notes:222]
Included in stock-based compensation for the three months ended October 1, 2022 and October 2, 2021, is $8.8 million and $4.7 million of stock-based compensation costs related to PSUs, respectively. The amount of stock-based compensation expense recognized in any one period related to PSUs can vary based on the achievement or anticipated achievement of the performance conditions. If the performance conditions are not met or not expected to be met, no compensation cost would be recognized on the underlying PSUs, and any previously recognized compensation expense related to those PSUs would be reversed.

[0001628280-22-028783:notes:223]
[same as prior period, unchanged from 0001628280-22-012157:notes:188]

[0001628280-22-028783:notes:224]
|  | Three Months Ended |  |  |
|  | October 1, 2022 |  | October 2, 2021 |  |  |  |  |
| Income tax benefit associated with stock-based compensation | $ | 5.1 |  |  | $ | 4.0 |  |  |  |  |  |

[0001628280-22-028783:notes:225]
Approximately $10.3 million and $6.4 million of stock-based compensation was capitalized to inventory as of October 1, 2022 and July 2, 2022, respectively.

[0001628280-22-028783:notes:226]
As of October 1, 2022, $266.5 million of stock-based compensation cost related to RSU awards remains to be amortized. That RSU cost is expected to be recognized over an estimated amortization period of 2.3 years.

[0001628280-22-028783:notes:227]
[same as prior period, unchanged from 0001628280-22-012157:notes:191]

[0001628280-22-028783:notes:228]
The following table summarizes our award activity for the three months ended October 1, 2022 (in millions, except per share amounts):

[0001628280-22-028783:notes:229]
|  |  |  |  |  | Restricted Stock Units |  | Performance Stock Units |
|  |  |  |  |  |  |  |  |  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |
| Balance as of July 2, 2022 |  |  |  |  |  |  |  |  | 2.0 |  |  | $ | 85.9 |  |  | 0.3 |  |  | $ | 81.9 |  |
| Replacement Awards Issued |  |  |  |  |  |  |  |  | 0.4 |  |  | 93.4 |  |  | — |  |  | — |  |
| Granted |  |  |  |  |  |  |  |  | 1.5 |  |  | 89.2 |  |  | 0.5 |  |  | 88.3 |  |
| Vested |  |  |  |  |  |  |  |  | (0.5) |  |  | 81.7 |  |  | (0.1) |  |  | 68.8 |  |
| Canceled |  |  |  |  |  |  |  |  | (0.1) |  |  | 85.0 |  |  | — |  |  | 82.6 |  |
| Balance as of October 1, 2022 |  |  |  |  |  |  |  |  | 3.3 |  |  | $ | 88.9 |  |  | 0.7 |  |  | $ | 89.3 |  |

[0001628280-22-028783:notes:230]
[same as prior period, unchanged from 0001628280-22-012157:notes:195]

[0001628280-22-028783:notes:231]
|  | Awards Available for Grant |
| Balance as of July 2, 2022 | 3.8 |  |
| Assumed in connection with NeoPhotonics merger | 0.4 |  |
| Replacement Awards | (0.4) |  |
| Granted | (2.0) |  |
| Canceled | 0.1 |  |
| Balance as of October 1, 2022 | 1.9 |  |

[0001628280-22-028783:notes:232]
[same as prior period, unchanged from 0001628280-22-012157:notes:197]

[0001628280-22-028783:notes:233]
The 2015 Purchase Plan expense for the three months ended October 1, 2022 and October 2, 2021 was $1.2 million and $1.2 million, respectively. The expense related to the 2015 Purchase Plan is recorded on a straight-line basis over the relevant subscription period. During the three months ended October 1, 2022 and October 2, 2021, there were no shares issued to employees through the 2015 Purchase Plan.

[0001628280-22-028783:notes:234]
[same as prior period, unchanged from 0001628280-22-012157:notes:199]

[0001628280-22-028783:notes:235]
On May 7, 2021, our board of directors approved the 2021 share buyback program, which authorizes us to use up to $700.0 million to purchase our own shares of common stock. On March 3, 2022, our board of directors approved an increase in our share buyback program, which authorizes us to use up to an aggregate amount of $1.0 billion (an increase from $700.0 million) to purchase our own shares of common stock through May 2024, but may be suspended or terminated by the board of directors at any time.

[0001628280-22-028783:notes:236]
During the three months ended October 1, 2022, we repurchased 0.3 million shares of our common stock at an average price of $89.80 per share for an aggregate purchase price of $25.7 million.

[0001628280-22-028783:notes:237]
Since the share buyback program was approved by the board of directors, we have repurchased 7.4 million shares in aggregate at an average price of $83.38 per share for a total purchase price of $615.5 million. We recorded the $615.5 million aggregate purchase price as a reduction of retained earnings within our condensed consolidated balance sheet. All repurchased shares were retired immediately.

[0001628280-22-028783:notes:238]
The price, timing, amount, and method of future repurchases will be determined based on the valuation of market conditions and other factors, at prices determined to be attractive and in the best interests of both the Company and our stockholders.


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0001628280-22-028783:notes:239]
Note 14. Commitments and Contingencies

[0001628280-22-028783:notes:240]
Purchase Obligations

[0001628280-22-028783:notes:241]
Purchase obligations of $416.2 million as of October 1, 2022, represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. In addition, we assumed certain purchase orders in connection with our merger with NeoPhotonics for the purchase of inventory and other items in the ordinary course of its business.  Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule and adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

[0001628280-22-028783:notes:242]
We depend on a limited number of contract manufacturers, subcontractors and suppliers for raw materials, packages and standard components. We generally purchase these single or limited source products through standard purchase orders or one-year supply agreements and have no significant long-term guaranteed supply agreements with such vendors. While we seek to maintain a sufficient safety stock of such products and maintain on-going communications with our suppliers to guard against interruptions or cessation of supply, our business and results of operations could be adversely affected by a stoppage or delay of supply, substitution of more expensive or less reliable products, receipt of defective parts or contaminated materials, increases in the price of such supplies, or our inability to obtain reduced pricing from our suppliers in response to competitive pressures.

[0001628280-22-028783:notes:243]
Product Warranties

[0001628280-22-028783:notes:244]
We provide reserves for the estimated costs of product warranties at the time revenue is recognized. We typically offer a twelve month warranty for most of our products. However, in some instances depending upon the product, product components or application of our products by the end customer, our warranties can vary and generally range from six months to five years. We estimate the costs of our warranty obligations on an annualized basis based on our historical experience of known product failure rates, use of materials to repair or replace defective products and service delivery costs incurred in correcting product failures. In addition, from time to time, specific warranty accruals may be made if unforeseen technical problems arise with specific products. We assess the adequacy of our recorded warranty liabilities and adjust the amounts as necessary.

[0001628280-22-028783:notes:245]
The following table presents the changes in our warranty reserve for the periods presented (in millions):

[0001628280-22-028783:notes:246]
|  | Three Months Ended |  |  |
|  | October 1, 2022 |  | October 2, 2021 |  |  |  |  |
| Balance as of beginning of period | $ | 10.0 |  |  | $ | 5.0 |  |  |  |  |  |
| Warranties assumed in NeoPhotonics merger | 0.7 |  |  | — |  |  |  |  |  |
| Provision for warranty | 1.5 |  |  | 1.7 |  |  |  |  |  |
| Utilization of reserve | (2.1) |  |  | (1.6) |  |  |  |  |  |
| Balance as of end of period | $ | 10.1 |  |  | $ | 5.1 |  |  |  |  |  |

[0001628280-22-028783:notes:247]
Environmental Liabilities

[0001628280-22-028783:notes:248]
Our research and development, manufacturing and distribution operations involve the use of hazardous substances and are regulated under international, federal, state and local laws governing health and safety and the environment. We apply strict standards for protection of the environment and occupational health and safety to sites inside and outside the United States, even if not subject to regulations imposed by foreign governments. We believe that our properties and operations at our facilities comply in all material respects with applicable environmental laws and occupational health and safety laws. However, the risk of environmental liabilities cannot be completely eliminated and there can be no assurance that the application of environmental and health and safety laws will not require us to incur significant expenditures. We are also regulated under a number of international, federal, state and local laws regarding recycling, product packaging and product content requirements. The environmental, product content/disposal and recycling laws are gradually becoming more stringent and may cause us to incur significant expenditures in the future.

[0001628280-22-028783:notes:249]
Legal Proceedings

[0001628280-22-028783:notes:250]
We are subject to a variety of claims and suits that arise from time to time in the ordinary course of our business. While management currently believes that resolving claims against us, individually or in the aggregate, will not have a material adverse impact on our financial position, results of operations or statements of cash flows, these matters are subject to inherent

[0001628280-22-028783:notes:251]
uncertainties and management’s view of these matters may change in the future. We accrue for loss contingencies when it is both probable that we will incur the loss and when we can reasonably estimate the amount of the loss or range of loss.

[0001628280-22-028783:notes:252]
Oclaro Merger Litigation

[0001628280-22-028783:notes:253]
In connection with our acquisition of Oclaro in 2018, seven lawsuits were filed by purported stockholders of Oclaro challenging the proposed merger (the “Merger”). All but one was voluntarily dismissed after the Oclaro Merger closed.  The remaining lawsuit, SaiSravan B. Karri v. Oclaro, Inc., et al., No. 3:18-cv-03435-JD (the “Karri Lawsuit”), was filed in the United States District Court for the Northern District of California and is styled as a class action.

[0001628280-22-028783:notes:254]
The Karri Lawsuit alleges, among other things, that Oclaro and its directors violated Section 14(a) of the Securities Exchange Act of 1934, as amended (the “Exchange Act”), and Rule 14a-9 promulgated thereunder by disseminating an incomplete and misleading Form S-4, including proxy statement/prospectus. The Karri Lawsuit further alleged that Oclaro’s directors violated Section 20(a) of the Exchange Act by failing to exercise proper control over the person(s) who violated Section 14(a) of the Exchange Act. The plaintiff in the Karri Lawsuit seeks, among other things, damages to be awarded to the plaintiff and any class, if a class is certified, and litigation costs, including attorneys’ fees.

[0001628280-22-028783:notes:255]
After the plaintiff in the Karri Lawsuit was appointed as lead plaintiff and his counsel as lead counsel, the plaintiff filed a first amended complaint on April 15, 2019.  The first amended complaint, also named Lumentum as a defendant but Lumentum has since been dismissed from the action.  On October 8, 2020, the court granted in part and denied in part the defendant’s motion to dismiss the first amended complaint. On December 1, 2020, defendants answered the first amended complaint. On September 17, 2021, lead plaintiff filed a second amended complaint. Defendants moved to stay discovery in light of the second amended complaint. On January 11, 2022 the Court struck the second amended complaint as untimely, terminated defendants’ motions to dismiss as moot, and lifted the stay.

[0001628280-22-028783:notes:256]
On August 16, 2022, Plaintiff moved for class certification and to be appointed class representative.  Defendants opposed the motion.  A hearing on the motion is scheduled for November 17, 2022.  Defendants intend to continue to defend the Karri Lawsuit vigorously.

[0001628280-22-028783:notes:257]
NeoPhotonics Merger Litigation

[0001628280-22-028783:notes:258]
In connection with our planned acquisition of NeoPhotonics Corporation (“NeoPhotonics”) announced in November 2021, ten lawsuits (the “NeoPhotonics Lawsuits”) were filed by purported stockholders of NeoPhotonics challenging the proposed merger (the “NeoPhotonics Merger”).  All of the NeoPhotonics Lawsuits have been dismissed.

[0001628280-22-028783:notes:259]
Indemnifications

[0001628280-22-028783:notes:260]
In the normal course of business, we enter into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown because claims may be made against us in the future, and we may record charges in the future as a result of these indemnification obligations. As of October 1, 2022, we did not have any material indemnification claims that were probable or reasonably possible.

[0001628280-22-028783:notes:261]
Audit Proceedings

[0001628280-22-028783:notes:262]
We are under audit by various domestic and foreign tax authorities with regards to income tax and indirect tax matters. In some, although not all cases, we have reserved for potential adjustments to our provision for income taxes and accrual of indirect taxes that may result from examinations by these tax authorities or final outcomes in judicial proceedings, and we believe that the final outcome of these examinations, agreements or judicial proceedings will not have a material effect on our results of operations. If events occur which indicate payment of these amounts is unnecessary, the reversal of the liabilities would result in the recognition of benefits in the period we determine the liabilities are no longer necessary. If our estimates of the federal, state, and foreign income tax liabilities and indirect tax liabilities are less than the ultimate assessment, it could result in a further charge to expense.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001628280-22-028783:notes:263]
[same as prior period, unchanged from 0001628280-22-012157:notes:233]

[0001628280-22-028783:notes:264]
[same as prior period, unchanged from 0001628280-22-012157:notes:234]

[0001628280-22-028783:notes:265]
We are an industry leading provider of optical and photonic products defined by revenue and market share addressing a range of end-market applications including optical communications and commercial lasers. We have two operating segments, Optical Communications, which we refer to as OpComms, and Commercial Lasers, which we refer to as Lasers. Our OpComms products address the following markets: telecommunications and data communications (“Telecom and Datacom”), and consumer and industrial (“Consumer and Industrial”), and include product lines from the recent merger of NeoPhotonics and the acquisition of IPG Photonics’ telecom transmission product lines. The two operating segments were primarily determined based on how the CODM views and evaluates our operations. The CODM regularly reviews operating results to make decisions about resources to be allocated to the segments and to assess their performance. Other factors, including market separation and customer specific applications, go-to-market channels, products and manufacturing, are considered in determining the formation of these operating segments.

[0001628280-22-028783:notes:266]
[same as prior period, unchanged from 0001628280-22-012157:notes:236]

[0001628280-22-028783:notes:267]
[same as prior period, unchanged from 0001628280-22-012157:notes:237]

[0001628280-22-028783:notes:268]
[same as prior period, unchanged from 0001628280-22-012157:notes:238]

[0001628280-22-028783:notes:269]
[same as prior period, unchanged from 0001628280-22-012157:notes:239]

[0001628280-22-028783:notes:270]
[same as prior period, unchanged from 0001628280-22-012157:notes:240]

[0001628280-22-028783:notes:271]
[same as prior period, unchanged from 0001628280-22-012157:notes:241]

[0001628280-22-028783:notes:272]
[same as prior period, unchanged from 0001628280-22-012157:notes:242]

[0001628280-22-028783:notes:273]
Reportable Segments

[0001628280-22-028783:notes:274]
[same as prior period, unchanged from 0001628280-22-012157:notes:243]

[0001628280-22-028783:notes:275]
[same as prior period, unchanged from 0001628280-22-012157:notes:244]

[0001628280-22-028783:notes:276]
|  | Three Months Ended |  |  |
|  | October 1, 2022 |  | October 2, 2021 |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |
| OpComms | $ | 453.4 |  |  | $ | 406.0 |  |  |  |  |  |
| Lasers | 53.4 |  |  | 42.4 |  |  |  |  |  |
| Net revenue | $ | 506.8 |  |  | $ | 448.4 |  |  |  |  |  |
| Gross profit: |  |  |  |  |  |  |  |
| OpComms | $ | 216.0 |  |  | $ | 225.9 |  |  |  |  |  |
| Lasers | 28.1 |  |  | 20.8 |  |  |  |  |  |
| Total segment gross profit | 244.1 |  |  | 246.7 |  |  |  |  |  |
| Unallocated corporate items: |  |  |  |  |  |  |  |
| Stock-based compensation | (5.5) |  |  | (4.6) |  |  |  |  |  |
| Amortization of acquired intangibles | (22.9) |  |  | (15.8) |  |  |  |  |  |
| Amortization of acquired inventory fair value adjustments | (4.6) |  |  | — |  |  |  |  |  |
| Other (charges) gains (1) | (9.9) |  |  | 5.9 |  |  |  |  |  |
| Gross profit | $ | 201.2 |  |  | $ | 232.2 |  |  |  |  |  |

[0001628280-22-028783:notes:277]
(1)   Other (charges) gains of unallocated corporate items for the three months ended October 1, 2022 primarily relate to $7.3 million of charges to acquire components from various brokers to satisfy customer demand.

[0001628280-22-028783:notes:278]
Other (charges) gains of unallocated corporate items for the three months ended October 2, 2021 primarily relate to $5.9 million of gain as a result of selling equipment that was no longer needed after we transferred certain product lines to new production facilities in fiscal 2021.

[0001628280-22-028783:notes:279]
Concentrations

[0001628280-22-028783:notes:280]
[same as prior period, unchanged from 0001628280-22-012157:notes:249]

[0001628280-22-028783:notes:281]
|  | Three Months Ended |  |  |
|  | October 1, 2022 |  | October 2, 2021 |  |  |  |  |
|  | Amount |  | % of Total |  | Amount |  | % of Total |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States | $ | 62.2 |  |  | 12.3 | % |  | $ | 28.1 |  |  | 6.3 | % |  |  |  |  |  |  |  |  |
| Other Americas | 59.8 |  |  | 11.8 |  |  | 35.0 |  |  | 7.8 |  |  |  |  |  |  |  |  |  |
| Total Americas | $ | 122.0 |  |  | 24.1 | % |  | $ | 63.1 |  |  | 14.1 | % |  |  |  |  |  |  |  |  |
| Asia-Pacific: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Hong Kong | $ | 77.6 |  |  | 15.3 | % |  | $ | 142.3 |  |  | 31.7 | % |  |  |  |  |  |  |  |  |
| South Korea | 67.7 |  |  | 13.4 |  |  | 105.1 |  |  | 23.4 |  |  |  |  |  |  |  |  |  |
| Thailand | 57.5 |  |  | 11.3 |  |  | 17.1 |  |  | 3.8 |  |  |  |  |  |  |  |  |  |
| Other Asia-Pacific | 133.7 |  |  | 26.4 |  |  | 95.0 |  |  | 21.2 |  |  |  |  |  |  |  |  |  |
| Total Asia-Pacific | $ | 336.5 |  |  | 66.4 | % |  | $ | 359.5 |  |  | 80.1 | % |  |  |  |  |  |  |  |  |
| EMEA | $ | 48.3 |  |  | 9.5 | % |  | $ | 25.8 |  |  | 5.8 | % |  |  |  |  |  |  |  |  |
| Total net revenue | $ | 506.8 |  |  |  |  | $ | 448.4 |  |  |  |  |  |  |  |  |  |  |  |

[0001628280-22-028783:notes:282]
During the three months ended October 1, 2022, our net revenue from a single customer, which represented 10% or greater of the total net revenue, was concentrated with two customers, who collectively accounted for 34% of our total net revenue. During the three months ended October 2, 2021, our net revenue from a single customer, which represented 10% or greater of total net revenue was concentrated with one customer, who accounted for 41% of our total net revenue.

[0001628280-22-028783:notes:283]
As of October 1, 2022, our accounts receivable from a single customer, which represented 10% or greater of the total accounts receivable, was concentrated with two customers, which individually represented 13% and 11% of gross accounts receivable, respectively. As of July 2, 2022, our accounts receivable from a single customer, which represented 10% or greater of the total accounts receivable, was concentrated with two customers, which individually represented 10% and 10% of gross accounts receivable, respectively.

[0001628280-22-028783:notes:284]
[same as prior period, unchanged from 0001628280-22-012157:notes:254]

[0001628280-22-028783:notes:285]
|  | October 1, 2022 |  | July 2, 2022 |
| Property, plant and equipment, net |  |  |  |
| United States | $ | 136.9 |  |  | $ | 107.8 |  |
| Thailand | 118.0 |  |  | 107.6 |  |
| Japan | 89.2 |  |  | 38.9 |  |
| China | 58.4 |  |  | 32.7 |  |
| Other countries | 75.5 |  |  | 73.5 |  |
| Total property, plant and equipment, net | $ | 478.0 |  |  | $ | 360.5 |  |

[0001628280-22-028783:notes:286]
We purchase a portion of our inventory from contract manufacturers and vendors located primarily in Taiwan, Thailand and Malaysia. During the three months ended October 1, 2022 and October 2, 2021, our net inventory purchases from a single contract manufacturer, which represented 10% or greater of our total net inventory purchases, were concentrated with two contract manufacturers. These two contract manufacturers collectively accounted for 51% of the total net inventory purchases during the three months ended October 1, 2022 and 64% of the total net inventory purchases during the three months ended October 2, 2021.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001628280-22-028783:notes:287]
[same as prior period, unchanged from 0001628280-22-012157:notes:257]

[0001628280-22-028783:notes:288]
[same as prior period, unchanged from 0001628280-22-012157:notes:258]

[0001628280-22-028783:notes:289]
[same as prior period, unchanged from 0001628280-22-012157:notes:259]

[0001628280-22-028783:notes:290]
The table below discloses our total net revenue attributable to each of our two reportable segments. In addition, the table sets forth the percentage of our total net revenue attributable to our product offerings that serve Telecom and Datacom, and Consumer and Industrial markets  accounted for 10% or more of our total net revenue during the periods presented (in millions, except percentage data):

[0001628280-22-028783:notes:291]
|  | Three Months Ended |  |  |
|  | October 1, 2022 |  | October 2, 2021 |  |  |  |  |
| OpComms: |  |  |  |  |  |  |  |  |  |  |  |
| Telecom and Datacom | $ | 360.1 |  | 71.1 | % |  | $ | 216.0 |  | 48.2 | % |  |  |  |  |  |  |
| Industrial and Consumer | 93.3 |  | 18.4 |  |  | 190.0 |  | 42.3 | % |  |  |  |  |  |  |
| Total OpComms | $ | 453.4 |  | 89.5 | % |  | $ | 406.0 |  | 90.5 | % |  |  |  |  |  |  |
| Lasers | 53.4 |  | 10.5 | % |  | 42.4 |  | 9.5 | % |  |  |  |  |  |  |
| Net Revenue | $ | 506.8 |  |  |  | $ | 448.4 |  |  |  |  |  |  |  |  |

[0001628280-22-028783:notes:292]
[same as prior period, unchanged from 0001628280-22-012157:notes:262]

[0001628280-22-028783:notes:293]
[same as prior period, unchanged from 0001628280-22-012157:notes:263]

[0001628280-22-028783:notes:294]
| Contract balances |  | Balance sheet location |  | October 1, 2022 |  | July 2, 2022 |  | Change |  | Percentage Change |
| Accounts receivable, net |  | Accounts receivable, net |  | $ | 340.5 |  |  | $ | 262.0 |  |  | $ | 78.5 |  |  | 30.0 | % |
| Deferred revenue and customer deposits |  | Other current liabilities |  | $ | 1.1 |  |  | $ | — |  |  | $ | 1.1 |  |  | n/a |
