# LITE 8-K — 0001628280-22-028758 filed 2022-11-08

## item codes, every 8-K on or before 2022-11-08

- 2022-11-08 0001628280-22-028758 — 2.02, 9.01
- 2022-08-16 0001628280-22-022980 — 2.02, 9.01
- 2022-08-03 0001193125-22-210674 — 2.01, 8.01, 9.01
- 2022-07-29 0001193125-22-206587 — 8.01, 9.01
- 2022-05-04 0001628280-22-012145 — 2.02, 9.01
- 2022-03-08 0001193125-22-069350 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2022-02-03 0001628280-22-001736 — 2.02, 9.01
- 2022-01-21 0001193125-22-014413 — 8.01, 9.01
- 2021-11-23 0001628280-21-024070 — 5.02, 5.07
- 2021-11-05 0001193125-21-321796 — 1.01, 9.01
- 2021-11-04 0001628280-21-021618 — 2.02, 9.01
- 2021-11-04 0001193125-21-319601 — 8.01, 9.01
- 2021-08-18 0001628280-21-017219 — 2.02, 9.01
- 2021-06-08 0001633978-21-000030 — 5.02, 9.01
- 2021-05-12 0001633978-21-000008 — 2.02, 9.01
- 2021-03-10 0001193125-21-075438 — 1.01, 8.01, 9.01
- 2021-02-02 0001633978-21-000002 — 2.02, 9.01
- 2021-01-19 0001104659-21-005024 — 1.01, 2.02, 8.01, 9.01
- 2020-11-24 0001193125-20-302557 — 5.02, 5.07
- 2020-11-02 0001633978-20-000017 — 2.02, 9.01
- 2020-09-18 0001633978-20-000012 — 5.02, 9.01
- 2020-08-11 0001633978-20-000010 — 2.02, 9.01
- 2020-05-05 0001628280-20-006358 — 2.02, 9.01
- 2020-02-04 0001633978-20-000002 — 2.02, 9.01
- 2019-12-12 0001193125-19-312875 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2019-12-04 0001633978-19-000075 — 8.01
- 2019-11-20 0001633978-19-000074 — 5.07
- 2019-10-31 0001633978-19-000070 — 2.02, 9.01
- 2019-08-08 0001633978-19-000068 — 2.02, 9.01
- 2019-05-08 0001633978-19-000031 — 1.01
- 2019-05-07 0001633978-19-000029 — 2.02, 9.01
- 2019-02-15 0001633978-19-000005 — 9.01 — amendment of 0001193125-18-346211
- 2019-02-08 0001193125-19-031591 — 5.02, 9.01
- 2019-02-05 0001633978-19-000001 — 2.02, 9.01
- 2018-12-10 0001193125-18-346211 — 1.01, 2.01, 2.03, 5.02, 8.01, 9.01
- 2018-12-06 0001633978-18-000150 — 8.01
- 2018-11-14 0001633978-18-000139 — 5.07
- 2018-11-13 0001633978-18-000136 — 3.02
- 2018-11-13 0001633978-18-000132 — 7.01, 9.01
- 2018-11-01 0001628280-18-013238 — 2.02, 9.01
- 2018-08-08 0001633978-18-000056 — 2.02, 9.01
- 2018-06-08 0001193125-18-188241 — 5.02, 9.01
- 2018-05-02 0001633978-18-000029 — 2.02, 9.01
- 2018-03-12 0001193125-18-078154 — 1.01, 2.01, 8.01, 9.01
- 2018-02-06 0001628280-18-001082 — 2.02, 9.01
- 2017-11-08 0001633978-17-000133 — 5.02, 9.01
- 2017-11-07 0001633978-17-000131 — 5.07
- 2017-11-01 0001633978-17-000117 — 2.02, 9.01
- 2017-08-09 0001633978-17-000058 — 2.02, 9.01
- 2017-05-04 0001633978-17-000035 — 2.02, 9.01
- 2017-03-08 0001193125-17-074740 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2017-03-02 0001193125-17-066769 — 8.01, 9.01
- 2017-02-07 0001633978-17-000005 — 2.02, 9.01
- 2017-01-03 0001628280-17-000018 — 4.01, 9.01
- 2016-11-09 0001628280-16-021143 — 5.02, 5.07, 9.01
- 2016-10-27 0001628280-16-020382 — 2.02, 9.01
- 2016-08-09 0001628280-16-018811 — 2.02, 9.01
- 2016-06-21 0001628280-16-017201 — 8.01
- 2016-05-04 0001628280-16-015501 — 2.02, 9.01
- 2016-02-16 0001628280-16-011261 — 5.02, 9.01
- 2016-02-04 0001628280-16-010758 — 5.02, 9.01
- 2016-02-04 0001628280-16-010755 — 2.02, 9.01
- 2015-11-17 0001193125-15-378953 — 7.01
- 2015-11-10 0001628280-15-008606 — 2.02, 9.01
- 2015-09-28 0001193125-15-329665 — 8.01, 9.01
- 2015-08-11 0001193125-15-286405 — 7.01, 9.01
- 2015-08-06 0001193125-15-281219 — 1.01, 5.02, 5.03, 5.05, 8.01, 9.01
- 2015-08-03 0001193125-15-274808 — 5.03, 9.01

## late-filing notifications on or before 2022-11-08

- 2015-11-10 0001628280-15-008612 — NT 10-Q, for the period ended 2015-09-26
- 2015-09-28 0001193125-15-329672 — NT 10-K, for the period ended 2015-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001628280-22-028758:8k_2_02:1]
EX-99.1
2
lite_ex991xq1fy23.htm
EX-99.1

[0001628280-22-028758:8k_2_02:2]
Document

[0001628280-22-028758:8k_2_02:3]
NEWS RELEASE

[0001628280-22-028758:8k_2_02:4]
LUMENTUM ANNOUNCES FISCAL FIRST QUARTER 2023 FINANCIAL RESULTS

[0001628280-22-028758:8k_2_02:5]
•Net revenue of $506.8 million

[0001628280-22-028758:8k_2_02:6]
•GAAP gross margin of 39.7%; Non-GAAP gross margin of 48.2%

[0001628280-22-028758:8k_2_02:7]
•GAAP operating margin of 2.7%; Non-GAAP operating margin of 27.1%

[0001628280-22-028758:8k_2_02:8]
•GAAP diluted net loss per share of $0.01; Non-GAAP diluted net income per share of $1.69

[0001628280-22-028758:8k_2_02:9]
San Jose, Calif., November 8, 2022 – Lumentum Holdings Inc. (“Lumentum” or the “Company”) today reported results for its fiscal first quarter ended October 1, 2022.

[0001628280-22-028758:8k_2_02:10]
“Solid execution drove first quarter revenue above the midpoint of our guidance, earnings per share to the high end of our range, and operating margin above guidance,” said Alan Lowe, President and CEO. “Demand is robust from our Telecom and Industrial Lasers customers. Looking forward, and consistent with industry trends, supply of specific IC components has not materialized as quickly as expected, and we now expect these shortages to continue into our fiscal 2024. Also, our near-term Datacom and 3D sensing outlook is lower than our prior projections.”

[0001628280-22-028758:8k_2_02:11]
Mr. Lowe added, “The closing of our two announced acquisitions in the first quarter position us to accelerate long-term technology trends in advanced networking hardware and adjacent markets, and expand our share in the growing telecom infrastructure market. Since closing these acquisitions, we have even higher confidence in accomplishing our goals. We look forward to sharing more on our progress in the coming quarters.”

[0001628280-22-028758:8k_2_02:12]
Fiscal First Quarter Highlights:

[0001628280-22-028758:8k_2_02:13]
Net revenue for the fiscal first quarter of 2023 was $506.8 million, with GAAP net loss of $0.4 million, or $0.01 loss per diluted share. Net revenue for the fiscal fourth quarter of 2022 was $422.1 million, with GAAP net income of $34.7 million, or $0.49 per diluted share. Net revenue for the fiscal first quarter of 2022 was $448.4 million, with GAAP net income of $81.5 million, or $1.08 per diluted share.

[0001628280-22-028758:8k_2_02:14]
Non-GAAP net income for the fiscal first quarter of 2023 was $119.2 million, or $1.69 per diluted share. Non-GAAP net income for fiscal fourth quarter of 2022 was $105.0 million, or $1.47 per diluted share. Non-GAAP net income for the fiscal first quarter of 2022 was $135.1 million, or $1.79 per diluted share.

[0001628280-22-028758:8k_2_02:15]
The Company held $1,624.9 million in total cash, cash equivalents, and short-term investments at the end of the fiscal first quarter of 2023, down $924.1 million from the end of the fiscal fourth quarter of 2022. In August 2022, we completed our merger with NeoPhotonics and the acquisition of IPG Photonics’ telecom transmission product lines for an aggregate purchase price consideration of $990.3 million. Additionally, the Company used $25.7 million of cash for the repurchase of shares of its common stock. As of October 1, 2022, the Company has $384.5 million remaining under the board-authorized share buyback program. Cash from operations for the fiscal first quarter of 2023 was $20.8 million.

[0001628280-22-028758:8k_2_02:16]
Financial Overview – Fiscal First Quarter Ended October 1, 2022

[0001628280-22-028758:8k_2_02:17]
|  | GAAP Results ($ in millions) |
|  | Q1 |  | Q4 |  | Q1 |  | Change |
|  | FY 2023 |  | FY 2022 |  | FY 2022 |  | Q/Q |  | Y/Y |
| Net revenue | $506.8 |  | $422.1 |  | $448.4 |  | 20.1% |  | 13.0% |
| Gross margin | 39.7% |  | 43.0% |  | 51.8% |  | (330)bps |  | (1,210)bps |
| Operating margin | 2.7% |  | 13.1% |  | 25.8% |  | (1,040)bps |  | (2,310)bps |
|  | Non-GAAP Results ($ in millions) |
|  | Q1 |  | Q4 |  | Q1 |  | Change |
|  | FY 2023 |  | FY 2022 |  | FY 2022 |  | Q/Q |  | Y/Y |
| Net revenue | $506.8 |  | $422.1 |  | $448.4 |  | 20.1% |  | 13.0% |
| Gross margin | 48.2% |  | 50.4% |  | 55.0% |  | (220)bps |  | (680)bps |
| Operating margin | 27.1% |  | 28.8% |  | 35.4% |  | (170)bps |  | (830)bps |

[0001628280-22-028758:8k_2_02:18]
|  | Net Revenue by Segment ($ in millions) |
|  | Q1 |  | % of |  | Q4 |  | Q1 |  | Change |
|  | FY 2023 |  | Net Revenue |  | FY 2022 |  | FY 2022 |  | Q/Q |  | Y/Y |
| Optical Communications | $ | 453.4 |  |  | 89.5 | % |  | $ | 370.9 |  |  | $ | 406.0 |  |  | 22.2 | % |  | 11.7 | % |
| Lasers | 53.4 |  |  | 10.5 | % |  | 51.2 |  |  | 42.4 |  |  | 4.3 | % |  | 25.9 | % |
| Total | $ | 506.8 |  |  | 100.0 | % |  | $ | 422.1 |  |  | $ | 448.4 |  |  | 20.1 | % |  | 13.0 | % |

[0001628280-22-028758:8k_2_02:19]
The tables above provide comparisons of quarterly results to prior periods, including sequential quarterly and year-over-year changes. A reconciliation between GAAP and non-GAAP measures is contained in this release under the section titled “Use of Non-GAAP Financial Measures.”

[0001628280-22-028758:8k_2_02:20]
Business Outlook

[0001628280-22-028758:8k_2_02:21]
Lumentum expects the following for the fiscal second quarter 2023:

[0001628280-22-028758:8k_2_02:22]
•Net revenue in the range of $490 million to $520 million

[0001628280-22-028758:8k_2_02:23]
•Non-GAAP operating margin of 20% to 22%

[0001628280-22-028758:8k_2_02:24]
•Non-GAAP diluted earnings per share of $1.20 to $1.45

[0001628280-22-028758:8k_2_02:25]
We have not provided reconciliations from GAAP to non-GAAP measures for our outlook. A large portion of non-GAAP adjustments, such as restructuring charges, stock-based compensation, income tax expense and credits, acquisition related costs, and other costs and contingencies unrelated to current and future operations are by their nature highly volatile and we have low visibility as to the range that may be incurred in the future.

[0001628280-22-028758:8k_2_02:26]
Related Announcement and Conference Call

[0001628280-22-028758:8k_2_02:27]
Lumentum will host a conference call today, November 8, 2022, at 5:30 am PT / 8:30 am ET to discuss its fiscal first quarter results.  A live webcast of the call and the replay will be available in the Investors section of the Lumentum website at http://investor.lumentum.com through November 15, 2022, at 9:00 pm PT / 12:00 am ET. To listen to the live conference call, dial (844) 200-6205 or (929) 526-1599 and reference the passcode 214134. To access the replay, dial (866) 813-9403 or (929) 458-6194 and reference the passcode 019687. Supporting materials outlining the Company’s latest financial results will be posted on http://investor.lumentum.com under the “Events and Presentations” section concurrently with this earnings press release. Lumentum has used, and intends to continue to use, its Investor Relations website as means of disclosing material nonpublic information and for complying with its disclosure obligations under Regulation FD. This press release is being furnished as an exhibit to a Current Report on Form 8-K filed with the Securities and Exchange Commission and will be available at http://www.sec.gov/.

[0001628280-22-028758:8k_2_02:28]
About Lumentum

[0001628280-22-028758:8k_2_02:29]
Lumentum (NASDAQ: LITE) is a market-leading designer and manufacturer of innovative optical and photonic products enabling optical networking and laser applications worldwide. Lumentum optical components and subsystems are part of virtually every type of telecom, enterprise, and data center network. Lumentum lasers enable advanced manufacturing techniques and diverse applications including next-generation 3D sensing capabilities. Lumentum is headquartered in San Jose, California with R&D, manufacturing, and sales offices worldwide. For more information, visit www.lumentum.com and follow Lumentum on LinkedIn, Twitter, Facebook, Instagram and YouTube.

[0001628280-22-028758:8k_2_02:30]
Forward-Looking Statements

[0001628280-22-028758:8k_2_02:31]
.

[0001628280-22-028758:8k_2_02:32]
Contact Information

[0001628280-22-028758:8k_2_02:33]
Investors:    Kathy Ta, 408-750-3853; investor.relations@lumentum.com

[0001628280-22-028758:8k_2_02:34]
Media:        Sean Ogarrio, 408-546-5405; media@lumentum.com

[0001628280-22-028758:8k_2_02:35]
Category:    Financial

[0001628280-22-028758:8k_2_02:36]
The following financial tables are presented in accordance with GAAP, unless otherwise specified.

[0001628280-22-028758:8k_2_02:37]
LUMENTUM HOLDINGS INC.

[0001628280-22-028758:8k_2_02:38]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001628280-22-028758:8k_2_02:39]
(in millions, except per share data)

[0001628280-22-028758:8k_2_02:40]
(unaudited)

[0001628280-22-028758:8k_2_02:41]
|  | Three Months Ended |  |  |
|  | October 1, 2022 |  | October 2, 2021 |  |  |  |  |
| Net revenue | $ | 506.8 |  |  | $ | 448.4 |  |  |  |  |  |
| Cost of sales | 282.6 |  |  | 200.4 |  |  |  |  |  |
| Amortization of acquired developed intangibles | 23.0 |  |  | 15.8 |  |  |  |  |  |
| Gross profit | 201.2 |  |  | 232.2 |  |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 72.7 |  |  | 54.1 |  |  |  |  |  |
| Selling, general and administrative | 105.7 |  |  | 63.3 |  |  |  |  |  |
| Restructuring and related charges | 9.3 |  |  | (1.1) |  |  |  |  |  |
| Total operating expenses | 187.7 |  |  | 116.3 |  |  |  |  |  |
| Income from operations | 13.5 |  |  | 115.9 |  |  |  |  |  |
| Interest expense | (8.5) |  |  | (16.9) |  |  |  |  |  |
| Other income (expense), net | 13.8 |  |  | 0.6 |  |  |  |  |  |
| Income before income taxes | 18.8 |  |  | 99.6 |  |  |  |  |  |
| Provision for income taxes | 19.2 |  |  | 18.1 |  |  |  |  |  |
| Net income (loss) | $ | (0.4) |  |  | $ | 81.5 |  |  |  |  |  |
| Net income (loss) per share: |  |  |  |  |  |  |  |
| Basic | $ | (0.01) |  |  | $ | 1.12 |  |  |  |  |  |
| Diluted | $ | (0.01) |  |  | $ | 1.08 |  |  |  |  |  |
| Shares used to compute net income (loss) per share: |  |  |  |  |  |  |  |
| Basic | 68.1 |  |  | 72.7 |  |  |  |  |  |
| Diluted | 68.1 |  |  | 75.4 |  |  |  |  |  |

[0001628280-22-028758:8k_2_02:42]
LUMENTUM HOLDINGS INC.

[0001628280-22-028758:8k_2_02:43]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001628280-22-028758:8k_2_02:44]
(in millions, except per share data)

[0001628280-22-028758:8k_2_02:45]
(unaudited)

[0001628280-22-028758:8k_2_02:46]
|  | October 1, 2022 |  | July 2, 2022 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 605.3 |  |  | $ | 1,290.2 |  |
| Short-term investments | 1,019.6 |  |  | 1,258.8 |  |
| Accounts receivable, net | 340.5 |  |  | 262.0 |  |
| Inventories | 366.2 |  |  | 250.1 |  |
| Prepayments and other current assets | 106.8 |  |  | 78.1 |  |
| Total current assets | 2,438.4 |  |  | 3,139.2 |  |
| Property, plant and equipment, net | 478.0 |  |  | 360.5 |  |
| Operating lease right-of-use assets, net | 89.4 |  |  | 73.6 |  |
| Goodwill | 693.7 |  |  | 368.9 |  |
| Other intangible assets, net | 576.0 |  |  | 155.7 |  |
| Deferred tax asset | 100.5 |  |  | 27.0 |  |
| Other non-current assets | 11.4 |  |  | 37.3 |  |
| Total assets | $ | 4,387.4 |  |  | $ | 4,162.2 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 205.7 |  |  | $ | 156.7 |  |
| Accrued payroll and related expenses | 62.2 |  |  | 54.6 |  |
| Accrued expenses | 52.8 |  |  | 44.7 |  |
| Short term debt | 420.2 |  |  | 409.9 |  |
| Operating lease liabilities, current | 13.6 |  |  | 11.2 |  |
| Other current liabilities | 48.3 |  |  | 39.4 |  |
| Total current liabilities | 802.8 |  |  | 716.5 |  |
| Long term debt | 1,899.5 |  |  | 1,466.1 |  |
| Operating lease liabilities, non-current | 58.0 |  |  | 48.8 |  |
| Deferred tax liability | 24.8 |  |  | 12.9 |  |
| Other non-current liabilities | 75.9 |  |  | 42.9 |  |
| Total liabilities | 2,861.0 |  |  | 2,287.2 |  |
| Stockholders’ equity: |  |  |  |
| Common stock, $0.001 par value, 990 authorized shares, 68.2 and 68.0 shares issued and outstanding as of October 1, 2022 and July 2, 2022, respectively | 0.1 |  |  | 0.1 |  |
| Additional paid-in capital | 1,596.1 |  |  | 2,003.6 |  |
| Accumulated deficit | (69.6) |  |  | (129.1) |  |
| Accumulated other comprehensive income (loss) | (0.2) |  |  | 0.4 |  |
| Total stockholders’ equity | 1,526.4 |  |  | 1,875.0 |  |
| Total liabilities and stockholders’ equity | $ | 4,387.4 |  |  | $ | 4,162.2 |  |

[0001628280-22-028758:8k_2_02:47]
Use of Non-GAAP Financial Measures

[0001628280-22-028758:8k_2_02:48]
In this press release, Lumentum provides investors with certain non-GAAP financial measures: gross profit, gross margin, research and development expense, selling, general and administrative expense, operating margin, income from operations, interest and other income (expense), net, income before income taxes, provision for income taxes, net income (loss), and net income (loss) per share on a non-GAAP basis, as well as the non-GAAP measures of EBITDA and Adjusted EBITDA. Lumentum believes this non-GAAP financial information provides additional insight into the Company’s ongoing business operations and results, as well as cash generation, and has therefore chosen to provide this information to investors for a more consistent basis of comparison and to help them evaluate the results of the Company’s ongoing operations and enable more meaningful period to period comparisons. In addition, the Company believes that providing certain of these measures allows investors to better understand the Company’s cash flows and, importantly, to evaluate the efficacy of the methodology and information used by management to evaluate and measure such cash flows. However, these measures may be different from non-GAAP measures used by other companies, limiting their usefulness for comparison purposes. The non-GAAP financial measures used in this press release should not be considered in isolation from measures of financial performance prepared in accordance with GAAP. Investors are cautioned that there are material limitations associated with the use of non-GAAP financial measures as an analytical tool. In particular, many of the adjustments to our GAAP financial measures reflect the exclusion of items that are recurring and will be reflected in our financial results for the foreseeable future. Further, these non-GAAP financial measures may not be comparable to similarly titled measurements reported by other companies.

[0001628280-22-028758:8k_2_02:49]
Our non-GAAP measures used in this press release exclude (i) stock-based compensation, (ii) acquisition related costs,  (iii) amortization of acquired intangibles, (iv) amortization of acquired inventory fair value adjustments, (v) restructuring and related charges, (vi) foreign exchange (gains) losses, net, (vii) non-cash interest expense on convertible notes and other expenses, (viii) income tax adjustments, and (ix) other (gains) charges related to non-recurring activities.

[0001628280-22-028758:8k_2_02:50]
A quantitative reconciliation between GAAP and non-GAAP financial data with respect to historical periods is included in the supplemental financial table attached to this press release.

[0001628280-22-028758:8k_2_02:51]
LUMENTUM HOLDINGS INC.

[0001628280-22-028758:8k_2_02:52]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001628280-22-028758:8k_2_02:53]
(in millions, except per share data)

[0001628280-22-028758:8k_2_02:54]
(unaudited)

[0001628280-22-028758:8k_2_02:55]
|  | Three Months Ended |  |  |  |  |
|  | October 1, 2022 |  | July 2, 2022 |  | October 2, 2021 |  |  |  |  |  |  |
| Gross profit on GAAP basis | $ | 201.2 |  |  | $ | 181.7 |  |  | $ | 232.2 |  |  |  |  |  |  |  |
| Stock-based compensation | 5.5 |  |  | 5.6 |  |  | 4.6 |  |  |  |  |  |  |  |
| Amortization of acquired intangibles | 22.9 |  |  | 15.6 |  |  | 15.8 |  |  |  |  |  |  |  |
| Amortization of acquired inventory fair value adjustments | 4.6 |  |  | — |  |  | — |  |  |  |  |  |  |  |
| Other (gains) charges (1) | 9.9 |  |  | 9.8 |  |  | (5.9) |  |  |  |  |  |  |  |
| Gross profit on non-GAAP basis | $ | 244.1 |  |  | $ | 212.7 |  |  | $ | 246.7 |  |  |  |  |  |  |  |
| Gross margin on non-GAAP basis | 48.2 | % |  | 50.4 | % |  | 55.0 | % |  |  |  |  |  |  |
| Research and development on GAAP basis | $ | 72.7 |  |  | $ | 56.7 |  |  | $ | 54.1 |  |  |  |  |  |  |  |
| Stock-based compensation | (9.6) |  |  | (6.3) |  |  | (5.0) |  |  |  |  |  |  |  |
| Other (charges) | (2.3) |  |  | (0.3) |  |  | (0.1) |  |  |  |  |  |  |  |
| Research and development on non-GAAP basis | $ | 60.8 |  |  | $ | 50.1 |  |  | $ | 49.0 |  |  |  |  |  |  |  |
| Selling, general and administrative on GAAP basis | $ | 105.7 |  |  | $ | 69.6 |  |  | $ | 63.3 |  |  |  |  |  |  |  |
| Stock-based compensation | (19.6) |  |  | (15.8) |  |  | (15.2) |  |  |  |  |  |  |  |
| Stock-based compensation - acquisition related (2) | (11.9) |  |  | — |  |  | — |  |  |  |  |  |  |  |
| Acquisition related costs (3) | (16.2) |  |  | — |  |  | — |  |  |  |  |  |  |  |
| Amortization of acquired intangibles | (9.3) |  |  | (5.6) |  |  | (5.6) |  |  |  |  |  |  |  |
| Other (charges) | (2.8) |  |  | (7.2) |  |  | (3.7) |  |  |  |  |  |  |  |
| Selling, general and administrative on non-GAAP basis | $ | 45.9 |  |  | $ | 41.0 |  |  | $ | 38.8 |  |  |  |  |  |  |  |
| Income from operations on GAAP basis | $ | 13.5 |  |  | $ | 55.4 |  |  | $ | 115.9 |  |  |  |  |  |  |  |
| Stock-based compensation | 34.7 |  |  | 27.7 |  |  | 24.8 |  |  |  |  |  |  |  |
| Stock-based compensation - acquisition related (2) | 11.9 |  |  | — |  |  | — |  |  |  |  |  |  |  |
| Acquisition related costs (3) | 16.2 |  |  | — |  |  | — |  |  |  |  |  |  |  |
| Amortization of acquired intangibles | 32.2 |  |  | 21.2 |  |  | 21.4 |  |  |  |  |  |  |  |
| Amortization of acquired inventory fair value adjustments | 4.6 |  |  | — |  |  | — |  |  |  |  |  |  |  |
| Restructuring and related charges (4) | 9.3 |  |  | — |  |  | (1.1) |  |  |  |  |  |  |  |
| Other (gains) charges | 15.0 |  |  | 17.3 |  |  | (2.1) |  |  |  |  |  |  |  |
| Income from operations on non-GAAP basis | $ | 137.4 |  |  | $ | 121.6 |  |  | $ | 158.9 |  |  |  |  |  |  |  |
| Operating margin on non-GAAP basis | 27.1 | % |  | 28.8 | % |  | 35.4 | % |  |  |  |  |  |  |
| Interest and other income (expense), net on GAAP basis | $ | 5.3 |  |  | $ | (18.3) |  |  | $ | (16.3) |  |  |  |  |  |  |  |
| Foreign exchange (gains) losses, net | (9.0) |  |  | (4.4) |  |  | 0.1 |  |  |  |  |  |  |  |
| Non-cash interest expense on convertible notes and other expenses | 5.7 |  |  | 23.9 |  |  | 15.3 |  |  |  |  |  |  |  |
| Interest and other income (expense), net on non-GAAP basis | $ | 2.0 |  |  | $ | 1.2 |  |  | $ | (0.9) |  |  |  |  |  |  |  |
| Income before income taxes on GAAP basis | $ | 18.8 |  |  | $ | 37.1 |  |  | $ | 99.6 |  |  |  |  |  |  |  |

[0001628280-22-028758:8k_2_02:56]
| Stock-based compensation | 34.7 |  |  | 27.7 |  |  | 24.8 |  |  |  |  |  |  |  |
| Stock-based compensation - acquisition related (2) | 11.9 |  |  | — |  |  | — |  |  |  |  |  |  |  |
| Acquisition related costs (3) | 16.2 |  |  | — |  |  | — |  |  |  |  |  |  |  |
| Amortization of acquired intangibles | 32.2 |  |  | 21.2 |  |  | 21.4 |  |  |  |  |  |  |  |
| Amortization of acquired inventory fair value adjustments | 4.6 |  |  | — |  |  | — |  |  |  |  |  |  |  |
| Restructuring and related charges (4) | 9.3 |  |  | — |  |  | (1.1) |  |  |  |  |  |  |  |
| Foreign exchange (gains) losses, net | (9.0) |  |  | (4.4) |  |  | 0.1 |  |  |  |  |  |  |  |
| Non-cash interest expense on convertible notes and other expenses | 5.7 |  |  | 23.9 |  |  | 15.3 |  |  |  |  |  |  |  |
| Other (gains) charges | 15.0 |  |  | 17.3 |  |  | (2.1) |  |  |  |  |  |  |  |
| Income before income taxes on non-GAAP basis | $ | 139.4 |  |  | $ | 122.8 |  |  | $ | 158.0 |  |  |  |  |  |  |  |
| Provision for income taxes on GAAP basis | $ | 19.2 |  |  | $ | 2.4 |  |  | $ | 18.1 |  |  |  |  |  |  |  |
| Income tax adjustments | 1.0 |  |  | 15.4 |  |  | 4.8 |  |  |  |  |  |  |  |
| Provision for income taxes on non-GAAP basis | $ | 20.2 |  |  | $ | 17.8 |  |  | $ | 22.9 |  |  |  |  |  |  |  |
| Net income (loss) on GAAP basis | $ | (0.4) |  |  | $ | 34.7 |  |  | $ | 81.5 |  |  |  |  |  |  |  |
| Stock-based compensation | 34.7 |  |  | 27.7 |  |  | 24.8 |  |  |  |  |  |  |  |
| Stock-based compensation - acquisition related (2) | 11.9 |  |  | — |  |  | — |  |  |  |  |  |  |  |
| Acquisition related costs (3) | 16.2 |  |  | — |  |  | — |  |  |  |  |  |  |  |
| Amortization of acquired intangibles | 32.2 |  |  | 21.2 |  |  | 21.4 |  |  |  |  |  |  |  |
| Amortization of acquired inventory fair value adjustments | 4.6 |  |  | — |  |  | — |  |  |  |  |  |  |  |
| Restructuring and related charges (4) | 9.3 |  |  | — |  |  | (1.1) |  |  |  |  |  |  |  |
| Foreign exchange (gains) losses, net | (9.0) |  |  | (4.4) |  |  | 0.1 |  |  |  |  |  |  |  |
| Non-cash interest expense on convertible notes and other expenses | 5.7 |  |  | 23.9 |  |  | 15.3 |  |  |  |  |  |  |  |
| Income tax adjustments | (1.0) |  |  | (15.4) |  |  | (4.8) |  |  |  |  |  |  |  |
| Other (gains) charges | 15.0 |  |  | 17.3 |  |  | (2.1) |  |  |  |  |  |  |  |
| Net income on non-GAAP basis | $ | 119.2 |  |  | $ | 105.0 |  |  | $ | 135.1 |  |  |  |  |  |  |  |
| Net income per share on non-GAAP basis | $ | 1.69 |  |  | $ | 1.47 |  |  | $ | 1.79 |  |  |  |  |  |  |  |
| Shares used in per share calculation - diluted on GAAP basis | 68.1 |  |  | 71.5 |  |  | 75.4 |  |  |  |  |  |  |  |
| Non-GAAP adjustment (5) | 2.5 |  |  | — |  |  | — |  |  |  |  |  |  |  |
| Shares used in per share calculation - diluted on non-GAAP basis | 70.6 |  |  | 71.5 |  |  | 75.4 |  |  |  |  |  |  |  |

[0001628280-22-028758:8k_2_02:57]
(1)  Other charges excluded in deriving non-GAAP gross profit for the three months ended October 1, 2022 primarily relate to $7.3 million of incremental charges to acquire components from various brokers to satisfy customer demand.

[0001628280-22-028758:8k_2_02:58]
(2)   In connection with the NeoPhotonics merger, certain equity awards for NeoPhotonics employees were accelerated. The total stock-based compensation associated with the acceleration was $11.9 million for the three months ended October 1, 2022, of which $9.0 million was settled in cash.

[0001628280-22-028758:8k_2_02:59]
(3) Acquisition related costs of $16.2 million mainly includes professional, advisory and legal service fees related to the merger with NeoPhotonics and the acquisition of IPG Photonics’ telecom transmission product lines during the three months ended October 1, 2022.

[0001628280-22-028758:8k_2_02:60]
(4)  The $9.3 million restructuring charges for the three months ended October 1, 2022 is primarily attributable to severance and employee related benefits related to the merger with NeoPhotonics.

[0001628280-22-028758:8k_2_02:61]
(5) Shares used for net income per share on non-GAAP basis includes 2.5 million incremental shares, which mainly relate to the dilution that would occur for our convertible notes assuming we settle the face value of the notes in cash as the company intends.

[0001628280-22-028758:8k_2_02:62]
LUMENTUM HOLDINGS INC.

[0001628280-22-028758:8k_2_02:63]
RECONCILIATION OF GAAP NET INCOME TO ADJUSTED EBITDA

[0001628280-22-028758:8k_2_02:64]
(in millions, except per share data)

[0001628280-22-028758:8k_2_02:65]
(unaudited)

[0001628280-22-028758:8k_2_02:66]
|  | Three Months Ended |  |  |  |  |
|  | October 1, 2022 |  |  |  | July 2, 2022 |  | October 2, 2021 |  |  |  |  |  |  |  |  |
| GAAP net income (loss) | $ | (0.4) |  |  |  |  | $ | 34.7 |  |  | $ | 81.5 |  |  |  |  |  |  |  |  |  |
| Interest and other expense, net | (5.3) |  |  |  |  | 18.3 |  |  | 16.3 |  |  |  |  |  |  |  |  |  |
| Provision for income taxes | 19.2 |  |  |  |  | 2.4 |  |  | 18.1 |  |  |  |  |  |  |  |  |  |
| Depreciation | 24.5 |  |  |  |  | 20.4 |  |  | 20.4 |  |  |  |  |  |  |  |  |  |
| Amortization of acquired intangibles | 32.2 |  |  |  |  | 21.2 |  |  | 21.4 |  |  |  |  |  |  |  |  |  |
| EBITDA | 70.2 |  |  |  |  | 97.0 |  |  | 157.7 |  |  |  |  |  |  |  |  |  |
| Amortization of inventory fair value adjustments | 4.6 |  |  |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Restructuring and related charges | 9.3 |  |  |  |  | — |  |  | (1.1) |  |  |  |  |  |  |  |  |  |
| Stock-based compensation | 46.6 |  |  |  |  | 27.7 |  |  | 24.8 |  |  |  |  |  |  |  |  |  |
| Acquisition related costs | 16.2 |  |  |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Other (gains) charges | 15.0 |  |  |  |  | 17.3 |  |  | (1.9) |  |  |  |  |  |  |  |  |  |
| Adjusted EBITDA | $ | 161.9 |  |  |  |  | $ | 142.0 |  |  | $ | 179.5 |  |  |  |  |  |  |  |  |  |
