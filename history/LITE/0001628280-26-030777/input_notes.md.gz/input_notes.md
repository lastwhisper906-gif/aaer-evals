# LITE notes — 0001628280-26-030777


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001628280-26-030777:notes:1]
[same as prior period, unchanged from 0001628280-26-005129:notes:1]

[0001628280-26-030777:notes:2]
[same as prior period, unchanged from 0001628280-26-005129:notes:2]

[0001628280-26-030777:notes:3]
[same as prior period, unchanged from 0001628280-26-005129:notes:3]

[0001628280-26-030777:notes:4]
[same as prior period, unchanged from 0001628280-26-005129:notes:4]

[0001628280-26-030777:notes:5]
[same as prior period, unchanged from 0001628280-26-005129:notes:5]

[0001628280-26-030777:notes:6]
[same as prior period, unchanged from 0001628280-26-005129:notes:6]

[0001628280-26-030777:notes:7]
[same as prior period, unchanged from 0001628280-26-005129:notes:7]

[0001628280-26-030777:notes:8]
[same as prior period, unchanged from 0001628280-26-005129:notes:8]

[0001628280-26-030777:notes:9]
[same as prior period, unchanged from 0001628280-26-005129:notes:9]

[0001628280-26-030777:notes:10]
[same as prior period, unchanged from 0001628280-26-005129:notes:10]

[0001628280-26-030777:notes:11]
The Company is actively monitoring and assessing the ongoing global trade environment, particularly with respect to recent changes in trade restrictions and tariff regulations. We have assessed the potential impacts of heightened restrictions and tariffs on our allowance for credit losses, the carrying value of our goodwill and other long-lived assets, inventory valuation, and revenue recognition. While we have determined there was not a material impact to our condensed consolidated financial statements as of March 28, 2026 and for the three and nine months ended March 28, 2026, import tariffs and other trade restrictions implemented by the U.S. and other countries, as currently in effect and/or proposed, could have a material impact on our results for the remainder of fiscal year 2026 and in the future. The impact of tariffs is dependent upon negotiations with customers and suppliers and other mitigation efforts and potential further changes in global trade policies, including higher tariffs in the U.S. or other countries.

[0001628280-26-030777:notes:12]
[same as prior period, unchanged from 0001628280-26-005129:notes:17]

[0001628280-26-030777:notes:13]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Every fifth or sixth fiscal year will have a 53-week period. The additional week in a 53-week year is added to the third quarter, making such quarter consist of 14 weeks. Our fiscal year 2026 is a 52-week year ending on June 27, 2026, with the quarter ended March 28, 2026 being a 13-week quarterly period. Our fiscal year 2025 was a 52-week year that ended on June 28, 2025, with the quarter ended March 29, 2025 being a 13-week quarterly period. Our fiscal year 2027 ending on July 3, 2027 has a 53-week period.

[0001628280-26-030777:notes:14]
[same as prior period, unchanged from 0001628280-26-005129:notes:19]

[0001628280-26-030777:notes:15]
The condensed consolidated financial statements are prepared in accordance with GAAP and include the accounts of Lumentum Holdings Inc. and its wholly owned subsidiaries. All inter-company transactions and balances are eliminated in consolidation.

[0001628280-26-030777:notes:16]
[same as prior period, unchanged from 0001628280-26-005129:notes:21]

[0001628280-26-030777:notes:17]
The condensed consolidated financial statements and accompanying notes should be read in conjunction with the audited consolidated financial statements and accompanying notes included in our Annual Report on Form 10-K for the fiscal year ended June 28, 2025. There were no significant changes to our accounting policies during the nine months ended March 28, 2026, except as noted below:

[0001628280-26-030777:notes:18]
[same as prior period, unchanged from 0001628280-26-005129:notes:23]

[0001628280-26-030777:notes:19]
[same as prior period, unchanged from 0001628280-26-005129:notes:24]

[0001628280-26-030777:notes:20]
[same as prior period, unchanged from 0001628280-26-005129:notes:25]

[0001628280-26-030777:notes:21]
[same as prior period, unchanged from 0001628280-26-005129:notes:26]

[0001628280-26-030777:notes:22]
[same as prior period, unchanged from 0001628280-26-005129:notes:27]

[0001628280-26-030777:notes:23]
[same as prior period, unchanged from 0001628280-26-005129:notes:28]

[0001628280-26-030777:notes:24]
[same as prior period, unchanged from 0001628280-26-005129:notes:29]

[0001628280-26-030777:notes:25]
[same as prior period, unchanged from 0001628280-26-005129:notes:30]


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001628280-26-030777:notes:26]
Note 2. Recently Issued Accounting Pronouncements

[0001628280-26-030777:notes:27]
Accounting Pronouncements Recently Adopted

[0001628280-26-030777:notes:28]
In November 2024, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) No. 2024-04, Debt with Conversion and Other Options (Subtopic 470-20): Induced Conversions of Convertible Debt Instruments, which clarifies the requirements related to accounting for the settlement of a debt as an induced conversion. ASU No. 2024-04 is intended to improve the relevance and consistency in application of the induced conversion guidance in Subtopic 470-20 for convertible debt instruments with cash conversion features and debt instruments that are not currently convertible, when the face value of the debt is settled in cash. We have early adopted ASU No. 2024-04 in the first quarter of fiscal year 2026 and applied the accounting in the partial repurchase of our 2026 Notes in September 2025. Refer to “Note 9. Debt” for detailed discussion of this transaction.

[0001628280-26-030777:notes:29]
In December 2023, the FASB issued ASU No. 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures, which requires disaggregated information about a reporting entity’s effective tax rate reconciliation as well as information on income tax paid. ASU No. 2023-09 is effective for fiscal years beginning after December 15, 2024, with early adoption permitted. We have adopted ASU No. 2023-09 beginning in fiscal year 2026; however, it has no material impact on our condensed consolidated financial statements and disclosures for the three and nine months ended March 28, 2026.

[0001628280-26-030777:notes:30]
In March 2024, the FASB issued ASU No. 2024-02: Codification Improvements - Amendments to Remove References to the Concepts Statements, which contains amendments to the Codification that remove references to various FASB Concepts Statements. We have adopted ASU No. 2024-02 in the first quarter of fiscal year 2026 and it did not have a material impact on our condensed consolidated financial statements and disclosures as a result of the adoption.

[0001628280-26-030777:notes:31]
Accounting Pronouncements Not Yet Effective

[0001628280-26-030777:notes:32]
In December 2025, the FASB issued ASU No. 2025-12, Codification Improvements, the purpose of which is to update the codification for a broad range of topics arising from technical corrections, unintended applications of the codification, clarifications, and other minor improvements. ASU No. 2025-12 is effective for fiscal years beginning after December 15, 2026, with early adoption permitted. We plan to adopt ASU No. 2025-12 in the first quarter of fiscal year 2028. We are currently evaluating the impact of this ASU on our financial statements and disclosures.

[0001628280-26-030777:notes:33]
In December 2025, the FASB issued ASU No. 2025-11, Interim Reporting (Topic 270), which is intended to improve the navigability of the interim reporting guidance in ASC 270 and clarify when it applies. ASU No. 2025-11 is effective for fiscal years beginning after December 15, 2027, with early adoption permitted. We plan to adopt ASU No. 2025-11 in the first quarter of fiscal year 2029. We are currently evaluating the impact of this ASU on our financial statements and disclosures.

[0001628280-26-030777:notes:34]
In December 2025, the FASB issued ASU No. 2025-10, Government Grants (Topic 832), which adds guidance to ASC 832 on the recognition, measurement, and presentation of government grants. ASU No. 2025-10 is effective for fiscal years beginning after December 15, 2028, with early adoption permitted. We are currently evaluating the impact of this ASU on our financial statements and disclosures.

[0001628280-26-030777:notes:35]
In November 2025, the FASB issued ASU No. 2025-09, Derivatives and Hedging (Topic 815), which amends certain aspects of the hedge accounting guidance in ASC 815, including the risk assessment for cash flow hedges, hedging forecasted interest payments on choose-your-rate debt instruments, cash flow hedges of nonfinancial forecasted transactions, net written options as hedging instruments, and dual hedges of foreign currency denominated debt instruments. ASU No. 2025-09 is effective for fiscal years beginning after December 15, 2026, with early adoption permitted. We plan to adopt ASU No. 2025-09 in the first quarter of fiscal year 2028. We are currently evaluating the impact of this ASU on our financial statements and disclosures.

[0001628280-26-030777:notes:36]
In November 2025, the FASB issued ASU No. 2025-08, Financial Instruments—Credit Losses (Topic 326), which amends the guidance in ASC 326 on the accounting for certain purchased loans. ASU No. 2025-08 is effective for fiscal years beginning after December 15, 2026, with early adoption permitted. We plan to adopt ASU No. 2025-08 in the first quarter of fiscal year 2028. We are currently evaluating the impact of this ASU on our financial statements and disclosures.

[0001628280-26-030777:notes:37]
In September 2025, the FASB issued ASU No. 2025-07, Derivatives and Hedging (Topic 815) and Revenue from Contracts with Customers (Topic 606), which refines the scope of the guidance on derivatives in ASC 815 and clarifies the guidance on share-based payments from a customer in ASC 606. ASU No. 2025-07 is effective for fiscal years beginning after December 15, 2026, with early adoption permitted. We plan to adopt ASU No. 2025-07 in the first quarter of fiscal year 2028. We are currently evaluating the impact of this ASU on our financial statements and disclosures.

[0001628280-26-030777:notes:38]
In September 2025, the FASB issued ASU No. 2025-06, Intangibles—Goodwill and Other—Internal-Use Software (Sub-topic 350-40), Targeted Improvements to the Accounting for Internal-Use Software, which amends certain aspects of the accounting for and disclosure of software costs under ASC 350-40. The amendments also supersede the guidance on Web site development costs in ASC 350-50 and relocate that guidance, along with the recognition requirements for development costs specific to Web sites, to ASC 350-40. ASU No. 2025-06 is effective for fiscal years beginning after December 15, 2027, with early adoption permitted. We plan to adopt ASU No. 2025-06 in the first quarter of fiscal year 2029. We are currently evaluating the impact of this ASU on our financial statements and disclosures.

[0001628280-26-030777:notes:39]
In July 2025, the FASB issued ASU No. 2025-05, Financial Instruments - Credit Losses (Topic 326), Measurement of Credit Losses for Accounts Receivable and Contract Assets, which amends ASC 326-20 to provide a practical expedient for all entities, related to the estimation of expected credit losses for current accounts receivable and current contract assets that arise from transactions accounted for under ASC 606. ASU No. 2025-05 is effective for fiscal years beginning after December 15, 2025, with early adoption permitted. We plan to adopt ASU No. 2025-05 in the first quarter of fiscal year 2027. We are currently evaluating the impact of this ASU on our financial statements and disclosures.

[0001628280-26-030777:notes:40]
In May 2025, the FASB issued ASU No. 2025-04, Compensation - Stock Compensation (Topic 718) and Revenue from Contracts with Customers (Topic 606), which is intended to reduce diversity in practice and improve existing guidance, primarily by revising the definition of a “performance condition” and eliminating forfeiture policy election for service conditions associated with share-based consideration payable to a customer. In addition, ASU No. 2025-04 clarifies that the guidance in ASC 606 on the variable consideration constraints does not apply to share-based consideration payable to a customer regardless of whether an award’s grant date has occurred (as determined under ASC 718). ASU No. 2025-04 is

[0001628280-26-030777:notes:41]
effective for fiscal years beginning after December 15, 2026, with early adoption permitted. We plan to adopt ASU No. 2025-04 in the first quarter of fiscal year 2028. We are currently evaluating the impact of this ASU on our financial statements and disclosures.

[0001628280-26-030777:notes:42]
In May 2025, the FASB issued ASU No. 2025-03, Business Combinations (Topic 805) and Consolidation (Topic 810), which revises the guidance in ASC 805 to clarify that, in determining the accounting acquirer in a business combination that is effected primarily by exchanging equity interests in which a VIE is acquired, an entity would be required to consider the factors in ASC 805-10-55-12 through 55-15. Previously, the accounting acquirer in such transactions was always the primarily beneficiary. ASU No. 2025-03 is effective for fiscal years beginning after December 15, 2026, with early adoption permitted. We plan to adopt ASU No. 2025-03 in the first quarter of fiscal year 2028. We are currently evaluating the impact of this ASU on our financial statements and disclosures.

[0001628280-26-030777:notes:43]
In November 2024, the FASB issued ASU No. 2024-03, Reporting Comprehensive Income - Expense Disaggregation Disclosures (Subtopic 220-40), which requires disaggregation of certain expense captions into specified categories in disclosures within the footnotes to the financial statements. In January 2025, the FASB issued ASU No. 2025-01, which revises the effective date of ASU No. 2024-03, to clarify that all public business entities are required to adopt the guidance in annual reporting periods beginning after December 15, 2026, and interim periods within annual reporting periods beginning after December 15, 2027, with early adoption permitted. We plan to adopt ASU No. 2024-03 in the first quarter of fiscal year 2028. We are currently evaluating the impact of this ASU on our financial statements and disclosures.


## us-gaap:EarningsPerShareTextBlock

[0001628280-26-030777:notes:44]
[same as prior period, unchanged from 0001628280-26-005129:notes:53]

[0001628280-26-030777:notes:45]
We calculate basic earnings (loss) per common share pursuant to the two-class method as a result of the issuance of the Series A Convertible Preferred Stock (the “Preferred Stock”) in March 2026. The Preferred Stock is entitled to receive dividends on an as-converted basis in the same manner as holders of common stock and is therefore considered a participating security. Accordingly, the Company applies the two-class method in computing basic earnings per share. Under the two-class method, net income is allocated to common stockholders and participating securities based on their respective rights to receive dividends as if all earnings for the period had been distributed. As the Preferred Stock participates on an as-converted basis, earnings are allocated pro rata based on the total number of common shares outstanding and the as-converted shares of Preferred Stock.

[0001628280-26-030777:notes:46]
Diluted earnings (loss) per common share is calculated using the more dilutive of the two-class method or if-converted method. The two-class method uses net income available to common shareholders and assumes conversion of all potential shares other than the participating securities. The if-converted method uses net income and assumes conversion of all potential shares including the participating securities. For diluted earnings per share, the Company applies the if-converted method, under which the Preferred Stock is assumed to have been converted into common stock at the date of issuance, and the related shares are included in diluted weighted-average shares outstanding. Refer to Note 13. Equity for more details.

[0001628280-26-030777:notes:47]
The following table sets forth the computation of basic and diluted net income (loss) per common share under the two-class or as-converted method (in millions, except per share data):

[0001628280-26-030777:notes:48]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 28, 2026 |  | March 29, 2025 |  | March 28, 2026 |  | March 29, 2025 |
| Basic income (loss) per common share: |  |  |  |  |  |  |  |
| Net income | $ | 144.2 |  |  | $ | (44.1) |  |  | $ | 226.6 |  |  | $ | (187.4) |  |
| Income allocated to Series A Convertible Preferred Stock | (1.7) |  |  | — |  |  | (0.9) |  |  | — |  |
| Net income available to common shareholders | $ | 142.5 |  |  | $ | (44.1) |  |  | $ | 225.7 |  |  | $ | (187.4) |  |
| Weighted average basic shares outstanding | 71.5 |  |  | 69.3 |  |  | 71.0 |  |  | 68.8 |  |
| Basic income (loss) per common share | $ | 1.99 |  |  | $ | (0.64) |  |  | $ | 3.18 |  |  | $ | (2.72) |  |
| Diluted income (loss) per common share: |  |  |  |  |  |  |  |
| Numerator: |  |  |  |  |  |  |  |
| Net income (loss) | $ | 144.2 |  |  | $ | (44.1) |  |  | $ | 226.6 |  |  | $ | (187.4) |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted average common shares outstanding - basic | 71.5 |  |  | 69.3 |  |  | 71.0 |  |  | 68.8 |  |
| Effect of dilutive securities from Series A Convertible Preferred Stock | 0.9 |  |  | — |  |  | 0.3 |  |  | — |  |
| Effect of dilutive securities from ESPP | — |  |  | — |  |  | 0.1 |  |  | — |  |
| Effect of dilutive securities from stock options | 0.3 |  |  | — |  |  | 0.3 |  |  | — |  |
| Effect of dilutive securities from RSUs and PSUs | 2.7 |  |  | — |  |  | 2.3 |  |  | — |  |
| Shares issuable assuming conversion of the convertible notes | 20.8 |  |  | — |  |  | 13.4 |  |  | — |  |
| Weighted average common shares outstanding - diluted | 96.2 |  |  | 69.3 |  |  | 87.4 |  |  | 68.8 |  |
| Diluted income (loss) per common share | $ | 1.50 |  |  | $ | (0.64) |  |  | $ | 2.59 |  |  | $ | (2.72) |  |

[0001628280-26-030777:notes:49]
[same as prior period, unchanged from 0001628280-26-005129:notes:56]

[0001628280-26-030777:notes:50]
[same as prior period, unchanged from 0001628280-26-005129:notes:57]

[0001628280-26-030777:notes:51]
Our outstanding capped call options are anti-dilutive under GAAP as they are specifically designed to mitigate the dilutive impact of the 2032 Notes, such that no dilution will occur until the capped call price is exceeded. Refer to “Note 9. Debt” for more details. There were no other material anti-dilutive shares excluded from the calculation of diluted net income per share during the three and nine months ended March 28, 2026.

[0001628280-26-030777:notes:52]
Average anti-dilutive shares excluded from the calculation of diluted net loss per share for the three months ended March 29, 2025 include 4.2 million shares issuable under restricted stock units (“RSUs”) and performance stock units (“PSUs”), 0.1 million shares issuable under the Employee Stock Purchase Plan (the “ESPP”), and 0.8 million shares outstanding related to stock options. Average anti-dilutive shares excluded from the calculation of diluted net loss per share for the nine months ended March 29, 2025 include 0.6 million shares related to convertible notes, 4.5 million shares issuable under RSUs and PSUs, 0.1 million shares issuable under the ESPP, and 0.9 million shares outstanding related to stock options. In addition, the calculation of diluted net loss per share excludes the impact of our convertible notes under the if-converted method as we recognized net loss during the three and nine months ended March 29, 2025.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001628280-26-030777:notes:53]
[same as prior period, unchanged from 0001628280-26-005129:notes:60]

[0001628280-26-030777:notes:54]
Manufacturing Facility  Acquisition

[0001628280-26-030777:notes:55]
On March 17, 2026, we acquired a manufacturing facility in Greensboro, North Carolina for $38.0 million in cash from a third party. The acquired business mainly included land and building, machinery and equipment and an assembled workforce. As part of the transaction, we also entered into a transitional supply agreement (the “supply agreement”) with the third party wherein we will be acting as an agent whereby we will manufacture wafers for the third party for approximately 15 months. The third party is primarily responsible for fulfillment, has discretion in establishing pricing, and bears inventory and credit risk. Accordingly, revenue is recognized on a net basis, representing the amount of consideration or reasonable margin to which we expect to be entitled in exchange for arranging for the specified goods or services to be provided.

[0001628280-26-030777:notes:56]
We have applied the acquisition method of accounting in accordance with ASC 805 Business Combinations for this transaction, with respect to the fair value of purchase price consideration and the identifiable assets and liabilities acquired, including the supply agreement, which have been measured at estimated fair value as of the acquisition date. We allocated the fair value of the purchase price consideration to the assets acquired and liabilities assumed as of the acquisition date based on their estimated fair values. The excess of purchase price consideration over the fair value of net assets acquired is recorded as goodwill. Our preliminary allocation of the purchase price consideration to the assets acquired and liabilities assumed as of the acquisition date is as follows (in millions):

[0001628280-26-030777:notes:57]
|  | Fair Value |
| Total purchase price consideration | $ | 38.0 |  |
| Assets acquired |  |
| Property, plant and equipment, net | 39.5 |  |
| Liabilities assumed |  |
| Other liabilities (1) | 6.9 |  |
| Goodwill | $ | 5.4 |  |

[0001628280-26-030777:notes:58]
(1) Since the supply agreement is priced at a discount below its fair market value, we accounted for it as a below-market contract liability, which will be amortized and recorded as revenue over the term of the supply agreement. During the three and nine months ended March 28, 2026, we have recognized approximately $0.4 million of this amount to net revenue. Refer to “Note 16. Revenue Recognition” for further details.

[0001628280-26-030777:notes:59]
The goodwill of $5.4 million arising from this acquisition has been attributed to the value of the assembled workforce and the strategic benefits associated with acquiring an operational fabrication facility to expand our capacity. None of the goodwill is expected to be deductible for local tax purposes. Refer to “Note 8. Goodwill and Other Intangible Assets.”

[0001628280-26-030777:notes:60]
We also incurred a total of $0.4 million acquisition-related costs representing professional and other direct acquisition costs, which are recorded as selling, general and administrative expense in our consolidated statement of operations during the three and nine months ended March 28, 2026.

[0001628280-26-030777:notes:61]
Cloud Light Acquisition
On November 7, 2023, we completed the acquisition of Cloud Light Technology Limited (“Cloud Light”). In accordance with a definitive merger agreement, dated as of October 29, 2023, between the Company and Cloud Light, cash consideration included $75.8 million of cash held in an escrow fund to support Cloud Light’s indemnification obligations and customary adjustment for working capital. In November 2025, the Company and the former shareholders of Cloud Light mutually agreed to settle outstanding indemnification claims for $27.5 million and signed a settlement agreement releasing the balance of the escrow fund to the former Cloud Light shareholders and releasing them of their indemnification obligations. Since the measurement period has expired, we recorded the settlement amount of $27.5 million as other income, net in our condensed consolidated statements of operations for the nine months ended March 28, 2026.


## us-gaap:CashCashEquivalentsAndShortTermInvestmentsTextBlock

[0001628280-26-030777:notes:62]
[same as prior period, unchanged from 0001628280-26-005129:notes:62]

[0001628280-26-030777:notes:63]
[same as prior period, unchanged from 0001628280-26-005129:notes:63]

[0001628280-26-030777:notes:64]
|  | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| March 28, 2026: |  |  |  |  |  |  |  |
| Cash | $ | 517.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 517.7 |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | 281.5 |  |  | — |  |  | — |  |  | 281.5 |  |
| Money market funds | 1,818.6 |  |  | — |  |  | — |  |  | 1,818.6 |  |
| Total cash and cash equivalents | $ | 2,617.8 |  |  | $ | — |  |  | $ | — |  |  | $ | 2,617.8 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Commercial paper | 21.6 |  |  | — |  |  | — |  |  | 21.6 |  |
| Corporate debt securities | 304.2 |  |  | 0.1 |  |  | (1.1) |  |  | 303.2 |  |
| U.S. Agency securities | 127.1 |  |  | — |  |  | (0.2) |  |  | 126.9 |  |
| U.S. Treasury securities | 102.9 |  |  | 0.1 |  |  | (0.2) |  |  | 102.8 |  |
| Total short-term investments | $ | 555.8 |  |  | $ | 0.2 |  |  | $ | (1.5) |  |  | $ | 554.5 |  |
| June 28, 2025: |  |  |  |  |  |  |  |
| Cash | $ | 349.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 349.5 |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | 2.5 |  |  | — |  |  | — |  |  | 2.5 |  |
| Money market funds | 161.7 |  |  | — |  |  | — |  |  | 161.7 |  |
| U.S. Treasury securities | 7.0 |  |  | — |  |  | — |  |  | 7.0 |  |
| Total cash and cash equivalents | $ | 520.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 520.7 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Commercial paper | $ | 2.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 2.7 |  |
| Corporate debt securities | 210.9 |  |  | 0.3 |  |  | (0.1) |  |  | 211.1 |  |
| U.S. Agency securities | 67.6 |  |  | 0.1 |  |  | — |  |  | 67.7 |  |
| U.S. Treasury securities | 74.8 |  |  | 0.1 |  |  | — |  |  | 74.9 |  |
| Total short-term investments | $ | 356.0 |  |  | $ | 0.5 |  |  | $ | (0.1) |  |  | $ | 356.4 |  |

[0001628280-26-030777:notes:65]
[same as prior period, unchanged from 0001628280-26-005129:notes:65]

[0001628280-26-030777:notes:66]
We use the specific-identification method to determine any realized gains or losses from the sale of our short-term investments classified as available-for-sale. During the three and nine months ended March 28, 2026, we did not realize significant gains or losses on a gross level from the sale of our short-term investments classified as available-for-sale.

[0001628280-26-030777:notes:67]
During the three and nine months ended March 28, 2026, our other income, net was $15.5 million and $30.7 million, respectively, which includes interest and investment income on cash equivalents and short-term investments of $14.9 million and $35.1 million, respectively.

[0001628280-26-030777:notes:68]
During the three and nine months ended March 29, 2025, our other income, net was $4.2 million and $27.8 million, respectively, which includes interest and investment income on cash equivalents and short-term investments of $7.8 million and $26.2 million, respectively.

[0001628280-26-030777:notes:69]
As of March 28, 2026 and June 28, 2025, we recorded interest receivables of $10.9 million and $5.2 million, respectively, included in prepayments and other current assets within the condensed consolidated balance sheets. We did not recognize an allowance for credit losses against interest receivables in any of the periods presented.

[0001628280-26-030777:notes:70]
[same as prior period, unchanged from 0001628280-26-005129:notes:70]

[0001628280-26-030777:notes:71]
|  | Continuous Loss Position for More Than 12 Months |  | Continuous Loss Position for Less Than 12 Months |  | Gross Unrealized Losses |  |  |  |  |  |  |  |  |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  |  |  |  |  |  |  |  |  |
| March 28, 2026: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | — |  |  | $ | — |  |  | $ | 99.7 |  |  | $ | (0.2) |  |  | $ | (0.2) |  |  |  |  |  |  |  |  |  |
| Commercial paper | — |  |  | — |  |  | 21.6 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | — |  |  | — |  |  | 244.9 |  |  | (1.1) |  |  | (1.1) |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | — |  |  | — |  |  | 67.1 |  |  | (0.2) |  |  | (0.2) |  |  |  |  |  |  |  |  |  |
| Total | $ | — |  |  | $ | — |  |  | $ | 433.3 |  |  | $ | (1.5) |  |  | $ | (1.5) |  |  |  |  |  |  |  |  |  |
| June 28, 2025: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | — |  |  | $ | — |  |  | $ | 24.5 |  |  | $ | — |  |  | $ | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | — |  |  | — |  |  | 5.2 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | — |  |  | — |  |  | 73.8 |  |  | (0.1) |  |  | (0.1) |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | — |  |  | — |  |  | 35.3 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Total | $ | — |  |  | $ | — |  |  | $ | 138.8 |  |  | $ | (0.1) |  |  | $ | (0.1) |  |  |  |  |  |  |  |  |  |

[0001628280-26-030777:notes:72]
[same as prior period, unchanged from 0001628280-26-005129:notes:72]

[0001628280-26-030777:notes:73]
|  | March 28, 2026 |  | June 28, 2025 |
|  | Amortized Cost |  | Fair Value |  | Amortized Cost |  | Fair Value |
| Due within 1 year | $ | 209.0 |  |  | $ | 209.1 |  |  | $ | 139.9 |  |  | $ | 140.0 |  |
| Due in 1 year to 5 years | 346.8 |  |  | 345.4 |  |  | 216.1 |  |  | 216.4 |  |
| Total | $ | 555.8 |  |  | $ | 554.5 |  |  | $ | 356.0 |  |  | $ | 356.4 |  |

[0001628280-26-030777:notes:74]
[same as prior period, unchanged from 0001628280-26-005129:notes:74]


## us-gaap:FairValueDisclosuresTextBlock

[0001628280-26-030777:notes:75]
[same as prior period, unchanged from 0001628280-26-005129:notes:75]

[0001628280-26-030777:notes:76]
[same as prior period, unchanged from 0001628280-26-005129:notes:76]

[0001628280-26-030777:notes:77]
[same as prior period, unchanged from 0001628280-26-005129:notes:77]

[0001628280-26-030777:notes:78]
[same as prior period, unchanged from 0001628280-26-005129:notes:78]

[0001628280-26-030777:notes:79]
[same as prior period, unchanged from 0001628280-26-005129:notes:79]

[0001628280-26-030777:notes:80]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| March 28, 2026: (1) |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 281.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 281.5 |  |
| Money market funds | 1,818.6 |  |  | — |  |  | — |  |  | 1,818.6 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Commercial paper | — |  |  | 21.6 |  |  | — |  |  | 21.6 |  |
| Corporate debt securities | — |  |  | 303.2 |  |  | — |  |  | 303.2 |  |
| U.S. Agency securities | — |  |  | 126.9 |  |  | — |  |  | 126.9 |  |
| U.S. Treasury securities | 102.8 |  |  | — |  |  | — |  |  | 102.8 |  |
| Total assets | $ | 2,202.9 |  |  | $ | 451.7 |  |  | $ | — |  |  | $ | 2,654.6 |  |

[0001628280-26-030777:notes:81]
(1)  Excludes $517.7 million in cash held in our bank accounts as of March 28, 2026.

[0001628280-26-030777:notes:82]
[same as prior period, unchanged from 0001628280-26-005129:notes:82]

[0001628280-26-030777:notes:83]
[same as prior period, unchanged from 0001628280-26-005129:notes:83]

[0001628280-26-030777:notes:84]
[same as prior period, unchanged from 0001628280-26-005129:notes:84]

[0001628280-26-030777:notes:85]
[same as prior period, unchanged from 0001628280-26-005129:notes:85]

[0001628280-26-030777:notes:86]
The carrying amounts and estimated fair values of the convertible notes are as follows for the periods presented (in millions):

[0001628280-26-030777:notes:87]
|  | March 28, 2026 |  | June 28, 2025 |
|  | Carrying Amount |  | Estimated Fair Value |  | Carrying Amount |  | Estimated Fair Value |
| 2032 Notes | $ | 1,255.7 |  |  | $ | 4,867.2 |  |  | $ | — |  |  | $ | — |  |
| 2029 Notes | 600.9 |  |  | 6,262.3 |  |  | 600.2 |  |  | 925.5 |  |
| 2028 Notes | 858.5 |  |  | 4,617.2 |  |  | 857.7 |  |  | 890.2 |  |
| 2026 Notes | 468.3 |  |  | 3,328.0 |  |  | 1,048.3 |  |  | 1,233.3 |  |
|  | $ | 3,183.4 |  |  | $ | 19,074.7 |  |  | $ | 2,506.2 |  |  | $ | 3,049.0 |  |

[0001628280-26-030777:notes:88]
As of March 28, 2026, the fair value of our Japan term loans in aggregate is lower than the carrying value by approximately $1.3 million.

[0001628280-26-030777:notes:89]
[same as prior period, unchanged from 0001628280-26-005129:notes:87]

[0001628280-26-030777:notes:90]
[same as prior period, unchanged from 0001628280-26-005129:notes:88]

[0001628280-26-030777:notes:91]
Management utilizes various valuation methods, including an income approach, a market approach and a cost approach, to estimate the fair value of intangibles and other long-lived assets. During the annual impairment testing performed in the fourth quarter of fiscal year 2025, we concluded that there was no impairment of our intangible and other long-lived assets. We review our intangible and other long-lived assets for impairment at least annually in the fourth quarter of each fiscal year, absent any interim indicators of impairment. During the three and nine months ended March 28, 2026, we recorded $0.2 million and $11.9 million in impairment charges, respectively, to write-down certain assets held for sale to fair value less cost to sell in our condensed consolidated statements of operations. There were no other indicators of impairment during the three and nine months ended March 28, 2026.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001628280-26-030777:notes:92]
[same as prior period, unchanged from 0001628280-26-005129:notes:90]

[0001628280-26-030777:notes:93]
[same as prior period, unchanged from 0001628280-26-005129:notes:91]

[0001628280-26-030777:notes:94]
We did not have any allowance for credit losses other than our allowance for uncollectible accounts receivable. As of March 28, 2026 and June 28, 2025, the allowance for credit losses on our trade receivables was $3.4 million and $3.5 million, respectively.

[0001628280-26-030777:notes:95]
[same as prior period, unchanged from 0001628280-26-005129:notes:93]

[0001628280-26-030777:notes:96]
[same as prior period, unchanged from 0001628280-26-005129:notes:94]

[0001628280-26-030777:notes:97]
|  | March 28, 2026 |  | June 28, 2025 |
| Raw materials and purchased parts | $ | 321.1 |  |  | $ | 253.2 |  |
| Work in process | 224.8 |  |  | 159.1 |  |
| Finished goods | 86.9 |  |  | 57.8 |  |
| Inventories | $ | 632.8 |  |  | $ | 470.1 |  |

[0001628280-26-030777:notes:98]
[same as prior period, unchanged from 0001628280-26-005129:notes:96]

[0001628280-26-030777:notes:99]
[same as prior period, unchanged from 0001628280-26-005129:notes:97]

[0001628280-26-030777:notes:100]
|  | March 28, 2026 |  | June 28, 2025 |
| Land | $ | 92.1 |  |  | $ | 108.6 |  |
| Buildings and improvements | 280.9 |  |  | 270.4 |  |
| Machinery and equipment | 1,059.7 |  |  | 848.8 |  |
| Computer equipment and software | 42.4 |  |  | 39.1 |  |
| Furniture and fixtures | 13.0 |  |  | 14.7 |  |
| Leasehold improvements | 48.3 |  |  | 45.9 |  |
| Construction in progress | 248.4 |  |  | 152.3 |  |
|  | 1,784.8 |  |  | 1,479.8 |  |
| Less: Accumulated depreciation | (820.5) |  |  | (753.4) |  |
| Property, plant and equipment, net | $ | 964.3 |  |  | $ | 726.4 |  |

[0001628280-26-030777:notes:101]
[same as prior period, unchanged from 0001628280-26-005129:notes:99]

[0001628280-26-030777:notes:102]
In connection with our acquisition of a business in March 2026, we recorded approximately $39.5 million of property, plant and equipment in our condensed consolidated balance sheets. Refer to “Note 4. Business Combinations” for details.

[0001628280-26-030777:notes:103]
In March 2026, we completed the sale of two commercial real estate properties located in San Jose, California. The properties consist of commercial buildings used by us for office, research and development and manufacturing support activities. The agreement provided for a cash purchase price of $43.0 million and included a short-term rental arrangement under which we will continue to occupy the properties through July 1, 2026. We recorded a loss on sale of $0.2 million and $7.7 million during the three and nine months ended March 28, 2026, respectively, which is included in the selling, general and administrative expenses in our condensed consolidated statements of operations.

[0001628280-26-030777:notes:104]
On December 17, 2024, we entered into an agreement to sell our net assets in an entity in Shenzhen, China. On March 5, 2025, we completed the sale and received net proceeds of $47.8 million, which was net of cash of $17.6 million and direct selling costs of $1.1 million. The net assets sold consist primarily of building, building improvements and land rights as of December 17, 2024 with a net carrying value of $12.9 million, and were used for manufacturing and research and development activities. As a result, we recognized a gain on sale of facility of $34.9 million, which was recorded in our condensed consolidated statements of operations for the three and nine months ended March 29, 2025. We paid $4.4 million of withholding taxes on this sale transaction, which is recorded as part of the income tax provision for the three and nine months ended March 29, 2025. We also incurred $0.7 million of indirect selling expenses related to this transaction, which was

[0001628280-26-030777:notes:105]
recorded as part of selling, general and administrative expenses in our condensed consolidated statements of operations in the three and nine months ended March 29, 2025.

[0001628280-26-030777:notes:106]
[same as prior period, unchanged from 0001628280-26-005129:notes:104]

[0001628280-26-030777:notes:107]
In addition, in connection with the sale of our Brazilian entities, we recorded a gain on sale of approximately $1.6 million recorded in selling, general and administrative expenses in our condensed consolidated statements of operations during the nine months ended March 28, 2026.

[0001628280-26-030777:notes:108]
During the three and nine months ended March 28, 2026, we recorded depreciation expense of $32.8 million and $91.2 million, respectively.

[0001628280-26-030777:notes:109]
[same as prior period, unchanged from 0001628280-26-005129:notes:107]

[0001628280-26-030777:notes:110]
[same as prior period, unchanged from 0001628280-26-005129:notes:108]

[0001628280-26-030777:notes:111]
|  | March 28, 2026 |  | June 28, 2025 |
| Operating lease right-of-use assets | $ | 57.1 |  |  | $ | 54.4 |  |
| Less: accumulated amortization | (30.1) |  |  | (26.5) |  |
| Operating lease right-of-use assets, net | $ | 27.0 |  |  | $ | 27.9 |  |

[0001628280-26-030777:notes:112]
[same as prior period, unchanged from 0001628280-26-005129:notes:110]

[0001628280-26-030777:notes:113]
[same as prior period, unchanged from 0001628280-26-005129:notes:111]

[0001628280-26-030777:notes:114]
[same as prior period, unchanged from 0001628280-26-005129:notes:112]

[0001628280-26-030777:notes:115]
|  | March 28, 2026 |  | June 28, 2025 |
| Restructuring accrual and related charges (1) | $ | 2.0 |  |  | $ | 2.5 |  |
| Warranty reserve (2) | 25.0 |  |  | 14.4 |  |
| Deferred revenue and customer deposits (3) | 7.3 |  |  | 0.7 |  |
| Income tax payable (4) | 22.4 |  |  | 29.1 |  |
| Other current liabilities | 6.2 |  |  | 6.4 |  |
| Other current liabilities | $ | 62.9 |  |  | $ | 53.1 |  |

[0001628280-26-030777:notes:116]
[same as prior period, unchanged from 0001628280-26-005129:notes:114]

[0001628280-26-030777:notes:117]
(2) Refer to “Note 14. Commitments and Contingencies.”

[0001628280-26-030777:notes:118]
(3) Refer to “Note 16. Revenue Recognition.”

[0001628280-26-030777:notes:119]
(4) Refer to “Note 12. Income Taxes.”

[0001628280-26-030777:notes:120]
[same as prior period, unchanged from 0001628280-26-005129:notes:117]

[0001628280-26-030777:notes:121]
[same as prior period, unchanged from 0001628280-26-005129:notes:118]

[0001628280-26-030777:notes:122]
|  | March 28, 2026 |  | June 28, 2025 |
| Asset retirement obligations | $ | 7.1 |  |  | $ | 7.1 |  |
| Pension and related accruals (1) | 11.4 |  |  | 9.7 |  |
| Unrecognized tax benefit (2) | 67.6 |  |  | 55.6 |  |
| Other non-current liabilities (2) | 35.1 |  |  | 25.4 |  |
| Other non-current liabilities | $ | 121.2 |  |  | $ | 97.8 |  |

[0001628280-26-030777:notes:123]
(1) We have defined benefit pension plans in Japan, Switzerland, and Thailand. Pension and related accrual of $11.4 million as of March 28, 2026 represents $11.8 million of non-current portion of benefit obligation, offset by $0.4 million of funding for the pension plan in Switzerland. Pension and related accrual of $9.7 million as of June 28, 2025 relates to $11.0 million of non-current portion of benefit obligation, offset by $1.3 million of funding for the pension plan in Switzerland. We typically re-evaluate the assumptions related to the fair value of our defined benefit obligations annually in the fiscal fourth quarter and make any updates as necessary. During the three and nine months ended March 28, 2026, our contribution expense to the 401(k) Plan in the United States was $1.2 million and $2.3 million, respectively. During the three and nine months ended March 29, 2025, our contribution expense to the 401(k) Plan in the United States was $1.1 million and $2.4 million, respectively. Our contribution expense to all defined contribution plans outside the United States was $2.7 million and $7.9 million during the three and nine months ended March 28, 2026, respectively. Our contribution expense to all defined contribution plans outside the United States was $2.3 million and $6.1 million during the three and nine months ended March 29, 2025, respectively.
 (2) We have reclassified a $21.4 million unrecognized tax position to other non-current liabilities in the condensed consolidated balance sheets as of the year ended June 28, 2025 for an indemnification liability related to the sale of certain assets. This does not impact our results of operations for the year ended June 28, 2025.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001628280-26-030777:notes:124]
[same as prior period, unchanged from 0001628280-26-005129:notes:121]

[0001628280-26-030777:notes:125]
The following table presents our goodwill balances as of March 28, 2026 and June 28, 2025 (in millions):

[0001628280-26-030777:notes:126]
|  |  | Amount |
|  | Balance as of June 28, 2025 | $ | 1,060.9 |  |
|  | Acquisition of a business (1) | 5.4 |  |
|  | Balances as of March 28, 2026 | $ | 1,066.3 |  |

[0001628280-26-030777:notes:127]
(1) On March 17, 2026, we acquired a manufacturing facility in Greensboro, North Carolina. The acquired business mainly included land and building, machinery and equipment and an assembled workforce, offset by the liabilities assumed. The goodwill of $5.4 million arising from this acquisition is attributed to the value of the assembled workforce and the strategic benefits associated with acquiring an operational fabrication facility to expand our capacity. Refer to “Note 4. Business Combinations” for details.

[0001628280-26-030777:notes:128]
[same as prior period, unchanged from 0001628280-26-005129:notes:122]

[0001628280-26-030777:notes:129]
We review goodwill for impairment during the fourth quarter of each fiscal year or more frequently if events or circumstances indicate that an impairment loss may have occurred. In the fourth quarter of fiscal 2025, we completed the annual impairment test of goodwill, which indicated there was no goodwill impairment.

[0001628280-26-030777:notes:130]
During the quarter ended March 28, 2026, the Company completed a reorganization of its business units, which resulted in changes to its reporting unit structure. As a result of this reorganization, the Company performed an interim qualitative assessment of goodwill for its reporting units. In performing the assessment, the Company evaluated relevant events and circumstances, including changes in the composition of reporting units, financial performance, and other entity-specific and macroeconomic factors. Based on this assessment, it was not more likely than not that the fair value of any of the reporting units was less than its carrying amount. Accordingly, no goodwill impairment charge was recognized during the three and nine months ended March 28, 2026. We will continue to monitor for events or changes in circumstances that could indicate a potential impairment of goodwill in future periods.

[0001628280-26-030777:notes:131]
[same as prior period, unchanged from 0001628280-26-005129:notes:124]

[0001628280-26-030777:notes:132]
[same as prior period, unchanged from 0001628280-26-005129:notes:125]

[0001628280-26-030777:notes:133]
In-process research and development (“IPR&D”) is initially capitalized at fair value as an intangible asset with an indefinite life and assessed for impairment thereafter. When an IPR&D project is completed, the IPR&D is reclassified to acquired developed technologies intangible asset and amortized over the asset’s estimated useful life.

[0001628280-26-030777:notes:134]
During the annual impairment testing performed in the fourth quarter of fiscal year 2025, we concluded that our intangible and other long-lived assets were not impaired at the asset group level. We review our intangible and other long-lived assets for impairment at least annually in the fourth quarter of each fiscal year, absent any interim indicators of impairment. There were no indicators of impairment at the asset group level during the three and nine months ended March 28, 2026.

[0001628280-26-030777:notes:135]
[same as prior period, unchanged from 0001628280-26-005129:notes:128]

[0001628280-26-030777:notes:136]
| March 28, 2026 | Gross Carrying Amounts |  | Accumulated Amortization |  | Net Carrying Amounts |  | Weighted Average Remaining Amortization Period (Years) |
| Acquired developed technologies | $ | 828.4 |  |  | $ | (619.1) |  |  | $ | 209.3 |  |  | 3.6 |
| Customer relationships | 419.5 |  |  | (268.4) |  |  | 151.1 |  |  | 3.5 |
| In-process research and development | 2.5 |  |  | — |  |  | 2.5 |  |  | n/a |
| Order backlog | 14.0 |  |  | (14.0) |  |  | — |  |  | — |
| Trade name and trademarks | 3.0 |  |  | (3.0) |  |  | — |  |  | — |
| Total intangible assets | $ | 1,267.4 |  |  | $ | (904.5) |  |  | $ | 362.9 |  |  |  |

[0001628280-26-030777:notes:137]
[same as prior period, unchanged from 0001628280-26-005129:notes:130]

[0001628280-26-030777:notes:138]
[same as prior period, unchanged from 0001628280-26-005129:notes:131]

[0001628280-26-030777:notes:139]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 28, 2026 |  | March 29, 2025 |  | March 28, 2026 |  | March 29, 2025 |
| Cost of sales | $ | 19.3 |  |  | $ | 19.0 |  |  | $ | 58.4 |  |  | $ | 62.9 |  |
| Research and development | 0.5 |  |  | 0.4 |  |  | 1.3 |  |  | 1.2 |  |
| Selling, general and administrative | 14.0 |  |  | 15.0 |  |  | 42.5 |  |  | 51.0 |  |
| Total amortization of intangibles | $ | 33.8 |  |  | $ | 34.4 |  |  | $ | 102.2 |  |  | $ | 115.1 |  |

[0001628280-26-030777:notes:140]
Based on the carrying amount of our acquired intangible assets except in-process research and development as of March 28, 2026, and assuming no future impairment of the underlying assets, the estimated future amortization is as follows (in millions):

[0001628280-26-030777:notes:141]
| Fiscal Years |  |
| Remainder of 2026 | $ | 33.5 |  |
| 2027 | 123.6 |  |
| 2028 | 83.0 |  |
| 2029 | 52.6 |  |
| 2030 | 46.5 |  |
| Thereafter | 21.2 |  |
| Total future amortization | $ | 360.4 |  |


## us-gaap:DebtDisclosureTextBlock

[0001628280-26-030777:notes:142]
Note 9. Debt

[0001628280-26-030777:notes:143]
Our debt consists of the following:

[0001628280-26-030777:notes:144]
|  | March 28, 2026 |  | June 28, 2025 |
|  | Short-term |  | Long-term |  | Total |  | Short-term |  | Long-term |  | Total |
| Convertible notes (1) | $ | 3,183.4 |  |  | $ | — |  |  | $ | 3,183.4 |  |  | $ | — |  |  | $ | 2,506.2 |  |  | $ | 2,506.2 |  |
| Term loans | 55.2 |  |  | 43.2 |  |  | 98.4 |  |  | 10.6 |  |  | 56.4 |  |  | 67.0 |  |
| Total | $ | 3,238.6 |  |  | $ | 43.2 |  |  | $ | 3,281.8 |  |  | $ | 10.6 |  |  | $ | 2,562.6 |  |  | $ | 2,573.2 |  |

[0001628280-26-030777:notes:145]
(1) Since the closing price of our stock was at least 130% of the applicable conversion price for each series of Notes for 20 of the last 30 trading days of our second and third quarters of fiscal year 2026, all of our Notes remain convertible at the option of the holders during the fourth quarter of fiscal year 2026. The outstanding Notes are recorded as short-term debt, which is presented as current liabilities in our condensed consolidated balance sheets as of March 28, 2026, net of unamortized debt issuance costs. If the Notes are converted by holders, we are required to satisfy our conversion obligations with respect to each series of converted Notes by paying cash equal to the principal amounts of such series of converted Notes and paying or delivering, as the case may be, cash, shares of common stock, or a combination of cash and shares of common stock, at our election, with respect to any conversion value in excess thereof. The outstanding Notes are recorded as convertible notes, non-current in our consolidated balance sheets as of June 28, 2025, net of unamortized debt issuance costs.

[0001628280-26-030777:notes:146]
As of April 30, 2026, we have received early conversion requests totaling $500.8 million aggregate principal amount of the Notes,  which will be settled in cash and the conversion value in excess thereof will be settled in shares of common stock in accordance with Indenture governing the applicable series of Notes. In the three and nine months ended March 28, 2026, the aggregate principal amount of the Notes settled in cash was $0.1 million and $0.2 million, respectively.

[0001628280-26-030777:notes:147]
On April 7, 2026, we entered into privately negotiated exchange arrangements with certain holders of our 2026 Notes and 2029 Notes. Pursuant to these agreements, we issued an aggregate of approximately 5.7 million shares of our common stock in exchange for approximately $264.8 million and $209.8 million aggregate principal amount of the 2026 Notes and 2029 Notes, respectively, and the related conversion value in excess of the principal amounts thereof. The issuance of common stock in the exchange transactions resulted in incremental dilution of approximately 0.6 million shares of common stock related to the principal amounts. Refer to “Note 17. Subsequent Event” for further details.

[0001628280-26-030777:notes:148]
The table below summarizes the applicable conversion price and the equivalent 130% of the conversion price of each series of Notes  (per share amount):

[0001628280-26-030777:notes:149]
|  | Conversion Price |  | 130% of Conversion Price |
| 2032 Notes | $ | 187.77 |  |  | $ | 244.10 |  |
| 2029 Notes | 69.54 |  |  | 90.40 |  |
| 2028 Notes | 131.03 |  |  | 170.34 |  |
| 2026 Notes | 99.29 |  |  | 129.08 |  |

[0001628280-26-030777:notes:150]
Convertible Notes

[0001628280-26-030777:notes:151]
2032 Notes

[0001628280-26-030777:notes:152]
On September 8, 2025, we issued $1,265.0 million in aggregate principal amounts of 0.375% Convertible Senior Notes due in 2032 (“2032 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act of 1933, as amended (the “Securities Act”). The 2032 Notes are governed by an indenture between the Company and U.S. Bank Trust Company, National Association, as trustee (the “2032 Indenture”). The 2032 Notes are unsecured, rank equally with all of the Company’s existing senior unsecured indebtedness, including the Company’s outstanding 0.50% Convertible Senior Notes due 2026, 0.50% Convertible Senior Notes due 2028, and 1.50% Convertible Senior Notes due 2029, and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001628280-26-030777:notes:153]
The net proceeds from the sale of the 2032 Notes was approximately $1,254.7 million, after deducting $10.3 million of debt issuance costs. Concurrent with the issuance of the 2032 Notes, we used $843.1 million of the net proceeds to repurchase $581.1 million aggregate principal amounts of the 0.50% Convertible Senior Notes due in 2026 and $102.0 million of the net proceeds to pay the cost of the 2032 Capped Call Options. We intend to use the remaining net proceeds for general corporate purposes, which may include the repayment or repurchase of our indebtedness, including any of our existing convertible notes, capital expenditures, working capital and potential acquisitions.

[0001628280-26-030777:notes:154]
The 2032 Notes bear interest at a rate of 0.375% per year, payable semi-annually in arrears on March 15 and September 15 of each year, beginning on March 15, 2026. The 2032 Notes will mature on March 15, 2032, unless earlier redeemed, repurchased by us, or converted pursuant to their terms.

[0001628280-26-030777:notes:155]
The initial conversion rate is 5.3257 shares of common stock per $1,000 principal amounts of the 2032 Notes (which is equivalent to an initial conversion price of approximately $187.77 per share). The conversion rate is subject to adjustment upon the occurrence of certain events specified in the 2032 Indenture but will not be adjusted for any accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change (as defined in the 2032 Indenture) or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert the 2032 Notes in connection with such make-whole fundamental change or notice of redemption.

[0001628280-26-030777:notes:156]
Prior to the close of business on the business day immediately preceding December 15, 2031, holders of the 2032 Notes may convert their 2032 Notes only under the following circumstances:

[0001628280-26-030777:notes:157]
•during any fiscal quarter commencing after December 27, 2025 (and only during such fiscal quarter), if the last reported sale price of the common stock for at least 20 trading days (whether or not consecutive) during the period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price of the 2032 Notes, or $244.10, on each applicable trading day;

[0001628280-26-030777:notes:158]
•during the five consecutive business day period after any five consecutive trading day period (the “2032 measurement period”) in which the trading price per $1,000 principal amounts of 2032 Notes for each trading day of the 2032 measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate on each such trading day;

[0001628280-26-030777:notes:159]
•if we call any or all of the 2032 Notes for redemption, at any time prior to the close of business on the second scheduled trading day immediately preceding the redemption date; or

[0001628280-26-030777:notes:160]
•upon the occurrence of specified corporate events as specified in the 2032 Indenture.

[0001628280-26-030777:notes:161]
On or after December 15, 2031 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their 2032 Notes at any time. Upon conversion, we are required to satisfy our conversion obligation with respect to such converted 2032 Notes by paying cash equal to the principal amounts of such converted 2032 Notes and paying or delivering, as the case may be, cash, shares of common stock or a combination of cash and shares of common stock, at our election, with respect to any conversion value in excess thereof, if any.

[0001628280-26-030777:notes:162]
We may redeem for cash all or any portion of the 2032 Notes, at our option (subject to the partial redemption limitation set forth in the 2032 Indenture), on or after March 20, 2029, if the last reported sale price of our common stock has been at least 130% of the conversion price then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading-day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which we provide notice of redemption at a redemption price equal to 100% of the principal amounts of the 2032 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. No sinking fund is provided for the 2032 Notes. If we elect to redeem fewer than all of the outstanding 2032 Notes, at least $100.0 million aggregate principal amount of the 2032 Notes must be outstanding and not subject to redemption as of the redemption notice date. Upon the occurrence of a fundamental change (as defined in the 2032 Indenture), holders may require us to repurchase all or a portion of their 2032 Notes for cash at a price equal to 100% of the principal amount of the 2032 Notes to be repurchased, plus any accrued and unpaid interest to, but excluding, the fundamental change repurchase date. Upon conversion, we are required to satisfy our conversion obligation with respect to such converted 2032 Notes by paying cash equal to the principal amounts of such converted 2032 Notes and paying or delivering, as the case may be, cash, shares of common stock or a combination of cash and shares of common stock, at our election, with respect to any conversion value in excess thereof, if any.

[0001628280-26-030777:notes:163]
Since the closing price of our stock exceeded $244.10 (or 130% of the conversion price of $187.77) for 20 of the last 30 trading days of our second and third quarters of fiscal year 2026, our 2032 Notes remain convertible at the option of the holders during the fourth quarter of fiscal year 2026. Therefore, the entire aggregate principal amounts of the 2032 Notes outstanding is recorded as short-term debt, which is presented as a current liability in our consolidated balance sheets as of March 28, 2026, net of unamortized debt issuance costs.

[0001628280-26-030777:notes:164]
As of April 30, 2026, we have not received any early conversion requests with respect to the 2032 Notes.

[0001628280-26-030777:notes:165]
2032 Capped Call Options

[0001628280-26-030777:notes:166]
In September 2025, in connection with the issuances of the 2032 Notes, the Company entered into privately negotiated capped call transactions (the “2032 Capped Call Options”) with certain financial institutions (the “2032 Capped Call Counterparties”). The 2032 Capped Call Options cover, subject to anti-dilution adjustments substantially similar to those applicable to the 2032 Notes, the number of shares of our common stock that initially underlie the 2032 Notes and are generally expected to reduce potential dilution to the Company’s common stock upon any conversion of 2032 Notes and/or offset any cash payments the Company would be required to make in excess of the principal amounts of converted 2032 Notes, as the case may be, with such reduction and/or offset subject to a cap. The cap price of the 2032 Capped Call Options was initially $268.24 per share, and is subject to certain adjustments under the terms of the 2032 Capped Call Options. If the market price per share of our common stock, as measured under the terms of the 2032 Capped Call Options, exceeds the cap price of the 2032 Capped Call Options, there would be dilution and/or there would not be an offset of any potential cash payments in excess of the principal amounts of converted 2032 Notes, in each case, to the extent that such market price exceeds the cap price of the 2032 Capped Call Options.

[0001628280-26-030777:notes:167]
Each of the 2032 Capped Call Options was executed pursuant to a separate agreement entered into by the Company and each of the 2032 Capped Call Counterparties. The 2032 Capped Call Options are not part of the terms of the 2032 Notes and will not affect any holder’s rights under the 2032 Notes. Holders of the 2032 Notes will not have any rights with respect to the 2032 Capped Call Options. The Company concluded that the 2032 Capped Call Options met the criteria for equity classification because they were indexed to the Company’s common stock and the Company has the discretion to settle the 2032 Capped Call Options by the Company receiving shares or cash subsequent to March 20, 2029. As a result, the $102.0 million amount paid was recorded as a reduction to additional paid-in capital within the Company’s condensed consolidated balance sheets as of March 28, 2026, along with the offsetting associated current tax impact of $2.0 million.

[0001628280-26-030777:notes:168]
The Company made a tax election to integrate the 2032 Notes and the 2032 Capped Call Options for federal income tax purposes pursuant to applicable U.S. Treasury Regulations. Accordingly, the $102.0 million gross cost of the purchased 2032 Capped Call Options will be deductible for income tax purposes as original issue discount interest over the term of the 2032 Notes. As a result, the Company established a deferred income tax asset of $24.4 million at inception, with a corresponding valuation allowance as it is not more-likely-than-not that our U.S. deferred tax assets are realizable in the future. As of March 28, 2026, we have recognized a current tax impact of $2.0 million, which is recorded as an increase to additional paid-in capital within the Company’s condensed consolidated balance sheets.

[0001628280-26-030777:notes:169]
2029 Notes

[0001628280-26-030777:notes:170]
On June 16, 2023, we issued $603.7 million in aggregate principal amounts of 1.50% Convertible Senior Notes due in 2029 (“2029 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act. The 2029 Notes are governed by an indenture between the Company and U.S. Bank Trust Company, National Association, as trustee (the “2029 Indenture”). The 2029 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001628280-26-030777:notes:171]
The 2029 Notes bear interest at a rate of 1.50% per year, payable semi-annually in arrears on June 15 and December 15 of each year. The 2029 Notes will mature on December 15, 2029, unless earlier redeemed, repurchased by us, or converted pursuant to their terms.

[0001628280-26-030777:notes:172]
The initial conversion rate is 14.3808 shares of common stock per $1,000 principal amounts of the 2029 Notes (which is equivalent to an initial conversion price of approximately $69.54 per share). The conversion rate is subject to adjustment upon the occurrence of certain events specified in the 2029 Indenture but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change (as defined in the 2029 Indenture) or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert the 2029 Notes in connection with such make-whole fundamental change or notice of redemption.

[0001628280-26-030777:notes:173]
Prior to the close of business on the business day immediately preceding September 15, 2029, holders of the 2029 Notes may convert their 2029 Notes only under the following circumstances:

[0001628280-26-030777:notes:174]
•during any fiscal quarter (and only during such fiscal quarter), if the last reported sale price of the common stock for at least 20 trading days (whether or not consecutive) during the period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price of the 2029 Notes, or $90.40, on each applicable trading day;

[0001628280-26-030777:notes:175]
•during the five consecutive business day period after any five consecutive trading day period (the “2029 measurement period”) in which the trading price per $1,000 principal amounts of 2029 Notes for each trading day of the 2029 measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate on each such trading day;

[0001628280-26-030777:notes:176]
•if we call any or all of the 2029 Notes for redemption, at any time prior to the close of business on the second business day immediately preceding the redemption date; or

[0001628280-26-030777:notes:177]
•upon the occurrence of specified corporate events as specified in the 2029 Indenture.

[0001628280-26-030777:notes:178]
On or after September 15, 2029 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their 2029 Notes at any time. Following our irrevocable settlement method election made on September 25, 2024, upon conversion, we are required to satisfy our conversion obligation with respect to such converted 2029 Notes by delivering cash equal to the principal amounts of such converted 2029 Notes and cash, shares of common stock or a combination of cash and shares of common stock, at our election, with respect to any conversion value in excess thereof.

[0001628280-26-030777:notes:179]
We may redeem for cash all or any portion of the 2029 Notes, at our option (subject to the partial redemption limitation set forth in the 2029 Indenture), on or after June 22, 2026, if the last reported sale price of our common stock has been at least 130% of the conversion price then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading-day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which we provide notice of redemption at a redemption price equal to 100% of the principal amounts of the 2029 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. No sinking fund is provided for the 2029 Notes. If we elect to redeem fewer than all of the outstanding 2029 Notes, at least $100.0 million aggregate principal amounts of the 2029 Notes must be outstanding and not subject to redemption as of the redemption notice date. Upon the occurrence of a fundamental change (as defined in the 2029 Indenture), holders may require us to repurchase all

[0001628280-26-030777:notes:180]
or a portion of their 2029 Notes for cash at a price equal to 100% of the principal amounts of the 2029 Notes to be repurchased, plus any accrued and unpaid interest to, but excluding, the fundamental change repurchase date. Following our irrevocable settlement method election made on September 25, 2024, upon conversion, we are required to satisfy our conversion obligation with respect to such converted 2029 Notes by paying cash equal to the principal amounts of such converted 2029 Notes and paying or delivering, as the case may be, cash, shares of common stock or a combination of cash and shares of common stock, at our election, with respect to any conversion value in excess thereof.

[0001628280-26-030777:notes:181]
Since the closing price of our stock exceeded $90.40 (or 130% of the conversion price of $69.54) for 20 of the last 30 trading days of our first through third quarters of fiscal year 2026, our 2029 Notes remain convertible at the option of the holders during the fourth quarter of fiscal year 2026. Therefore, the remaining aggregate principal amounts of the 2029 Notes outstanding is recorded as short-term debt, which is presented as a current liability in our consolidated balance sheets as of March 28, 2026, net of unamortized debt issuance costs, while the entire aggregate principal amounts of the 2029 Notes outstanding is recorded as convertible notes, non-current in our consolidated balance sheets as of June 28, 2025, net of unamortized debt issuance costs.

[0001628280-26-030777:notes:182]
As of April 30, 2026, we have received early conversion requests totaling $325.2 million aggregate principal amount of the 2029 Notes, which will be settled in cash and the conversion value in excess thereof will be settled in shares of common stock in accordance with the 2029 Indenture. In the three and nine months ended March 28, 2026, the aggregate principal amount of the 2029 Notes settled in cash was not material for either period.

[0001628280-26-030777:notes:183]
2028 Notes

[0001628280-26-030777:notes:184]
In March 2022, we issued $861.0 million in aggregate principal amounts of 0.50% Convertible Senior Notes due in 2028 (the “2028 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act. The 2028 Notes are governed by an indenture between the Company and U.S. Bank Trust Company, National Association, as trustee (the “2028 Indenture”). The 2028 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001628280-26-030777:notes:185]
The 2028 Notes bear interest at a rate of 0.50% per year, payable semi-annually in arrears on June 15 and December 15 of each year. The 2028 Notes will mature on June 15, 2028, unless earlier redeemed, repurchased by us, or converted pursuant to their terms.

[0001628280-26-030777:notes:186]
The initial conversion rate is 7.6319 shares of common stock per $1,000 principal amounts of the 2028 Notes (which is equivalent to an initial conversion price of approximately $131.03 per share). The conversion rate is subject to adjustment upon the occurrence of certain specified events, but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change (as defined in the 2028 Indenture) or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert the 2028 Notes in connection with such make-whole fundamental change or notice of redemption.

[0001628280-26-030777:notes:187]
Prior to the close of business on the business day immediately preceding March 15, 2028, holders of the 2028 Notes may convert their 2028 Notes only under the following circumstances:

[0001628280-26-030777:notes:188]
•during any fiscal quarter (and only during such fiscal quarter), if the last reported sale price of the Company’s common stock for at least 20 trading days (whether or not consecutive) during the 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price, or $170.34, on each applicable trading day;

[0001628280-26-030777:notes:189]
•during the five consecutive business day period after any five consecutive trading day period (the “measurement period”) in which the trading price per $1,000 principal amounts of the 2028 Notes for each trading day of such measurement period was less than 98% of the product of the last reported sale price of the Company’s common stock and the applicable conversion rate on each such trading day;

[0001628280-26-030777:notes:190]
•if the Company calls any or all of the 2028 Notes for redemption, at any time prior to the close of business on the second business day immediately preceding the redemption date; or

[0001628280-26-030777:notes:191]
•upon the occurrence of specified corporate events, as specified in the 2028 Indenture.

[0001628280-26-030777:notes:192]
On or after March 15, 2028 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their 2028 Notes at any time. Following our irrevocable settlement method election made on September 25, 2024, upon conversion, we are required to satisfy our conversion obligation with respect to such converted 2028 Notes by paying cash equal to the principal amounts of such converted 2028 Notes and paying or delivering, as the case may be, cash, shares of common stock or a combination of cash and shares of common stock, at our election, with respect to any conversion value in excess thereof, if any.

[0001628280-26-030777:notes:193]
We may redeem for cash all or any portion of the 2028 Notes, at our option (subject to the partial redemption limitation set forth in the 2028 Indenture), on or after June 20, 2025, if the last reported sale price of its common stock has been at least 130% of the conversion price then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading-day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which the Company provides notice of redemption at a redemption price equal to 100% of the principal amounts of the 2028 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. No sinking fund is provided for the 2028 Notes. If we elect to redeem fewer than all of the outstanding 2028 Notes, at least $100.0 million aggregate principal amounts of the 2028 Notes must be outstanding and not subject to redemption as of the redemption notice date. Upon the occurrence of a fundamental change (as defined in the 2028 Indenture), holders may require the Company to repurchase all or a portion of their 2028 Notes for cash at a price equal to 100% of the principal amounts of the 2028 Notes to be repurchased, plus any accrued and unpaid interest to, but excluding, the fundamental change repurchase date. Following our irrevocable settlement method election made on September 25, 2024, upon conversion, we are required to satisfy our conversion obligation with respect to such converted 2028 Notes by paying cash equal to the principal amount of such converted 2028 Notes and paying or delivering, as the case may be, cash, shares of common stock or a combination of cash and shares of common stock, at our election, with respect to any conversion value in excess thereof, if any.

[0001628280-26-030777:notes:194]
We initially bifurcated the principal amounts of the 2028 Notes into liability and equity components. The liability component of the 2028 Notes was initially valued at $629.8 million based on the contractual cash flow discounted at an appropriate comparable market on non-convertible debt borrowing rate at the date of issuance, which was 5.7%, with the equity component representing the residual amount of the proceeds of $231.2 million, which was recorded as a debt discount. Upon adoption of ASU 2020-06 in the first quarter of fiscal year 2023, our 2028 Notes were accounted for as a single liability, net of unamortized debt issuance costs.

[0001628280-26-030777:notes:195]
Since the closing price of our stock exceeded $170.34 (or 130% of the conversion price of $131.03) for 20 of the last 30 trading days of our second and third quarters of fiscal year 2026, our 2028 Notes remain convertible at the option of the holders during the fourth quarter of fiscal year 2026. Therefore, the entire aggregate principal amounts of the 2028 Notes outstanding is recorded as short-term debt, which is presented as a current liability in our consolidated balance sheets as of March 28, 2026, net of unamortized debt issuance costs, while the entire aggregate principal amounts of the 2028 Notes outstanding is recorded as convertible notes, non-current in our consolidated balance sheets as of June 28, 2025, net of unamortized debt issuance costs.

[0001628280-26-030777:notes:196]
As of April 30, 2026, we have received early conversion requests totaling $23.5 million aggregate principal amount of the 2028 Notes, which will be settled in cash and the conversion value in excess thereof will be settled in shares of common stock in accordance with the 2028 Indenture. In the three and nine months ended March 28, 2026, none of the principal amount of the 2028 Notes was settled in cash.

[0001628280-26-030777:notes:197]
2026 Notes

[0001628280-26-030777:notes:198]
In December 2019, we issued $1,050.0 million in aggregate principal amounts of 0.50% Convertible Senior Notes due in 2026 (the “2026 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act. The 2026 Notes are governed by an indenture between the Company and U.S. Bank Trust Company, National Association (as successor in interest to U.S. Bank National Association), as trustee (as supplemented by the First Supplemental Indenture, dated as of September 25, 2024, the “2026 Indenture”). The 2026 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001628280-26-030777:notes:199]
The 2026 Notes bear interest at a rate of 0.50% per year, payable semi-annually in arrears on June 15 and December 15 of each year. The 2026 Notes will mature on December 15, 2026, unless earlier redeemed, repurchased by us, or converted pursuant to their terms.

[0001628280-26-030777:notes:200]
The initial conversion rate is 10.0711 shares of common stock per $1,000 principal amounts of the 2026 Notes (which is equivalent to an initial conversion price of approximately $99.29 per share). The conversion rate is subject to adjustment upon the occurrence of certain events specified in the 2026 Indenture but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change (as defined in the 2026 Indenture) or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares set forth in the 2026 Indenture or a holder that elects to convert the 2026 Notes in connection with such make-whole fundamental change or notice of redemption.

[0001628280-26-030777:notes:201]
Prior to the close of business on the business day immediately preceding September 15, 2026, holders of the 2026 Notes may convert their 2026 Notes only under the following circumstances:

[0001628280-26-030777:notes:202]
•during any fiscal quarter (and only during such fiscal quarter), if the last reported sale price of the common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price of the 2026 Notes, or $129.08 on each applicable trading day;

[0001628280-26-030777:notes:203]
•during the five consecutive business day period after any five consecutive trading day period (the “2026 measurement period”) in which the trading price per $1,000 principal amounts of the 2026 Notes for each trading day of the 2026 measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate for the 2026 Notes on each such trading day;

[0001628280-26-030777:notes:204]
•if we call any or all of the 2026 Notes for redemption, at any time prior to the close of business on the second business day immediately preceding the relevant redemption date; or

[0001628280-26-030777:notes:205]
•upon the occurrence of specified corporate events.

[0001628280-26-030777:notes:206]
On or after September 15, 2026 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their 2026 Notes at any time. Following our entry into the First Supplemental Indenture, dated as of September 25, 2024, to the 2026 Indenture, upon conversion, we are required to satisfy our conversion obligation with respect to such converted 2026 Notes by paying cash equal to the principal amounts of such converted 2026 Notes and paying or delivering, as the case may be, cash, shares of common stock or a combination of cash and shares of common stock, at our election, with respect to any conversion value in excess thereof, if any.

[0001628280-26-030777:notes:207]
We may redeem for cash, all or any portion of the 2026 Notes, at our option, on or after December 20, 2023, if the last reported sale price of its common stock has been at least 130% of the conversion price then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading-day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which we provide a notice of redemption at a redemption price equal to 100% of the principal amounts of the 2026 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. No sinking fund is provided for the 2026 Notes. Upon the occurrence of a fundamental change (as defined in the 2026 Indenture), holders may require us to repurchase all or a portion of the 2026 Notes for cash at a price equal to 100% of the principal amounts of the 2026 Notes to be repurchased, plus any accrued and unpaid interest to, but excluding, the fundamental change repurchase date. Following our entry into the First Supplemental Indenture, dated as of September 25, 2024, to the 2026 Indenture, upon conversion, we are required to satisfy our conversion obligation with respect to such converted 2026 Notes by paying cash equal to the principal amounts of such converted 2026 Notes and paying or delivering, as the case may be, cash, shares of common stock or a combination of cash and shares of common stock, at our election, with respect to any conversion value in excess thereof, if any.

[0001628280-26-030777:notes:208]
We initially bifurcated the principal amounts of the 2026 Notes into liability and equity components. The liability component of the 2026 Notes was initially valued at $734.8 million based on the contractual cash flows discounted at an appropriate comparable market non-convertible debt borrowing rate at the date of issuance of 5.8% with the equity component representing the residual amount of the proceeds of $315.2 million, which was recorded as a debt discount. Upon adoption of ASU 2020-06 in the first quarter of fiscal year 2023, our 2026 Notes were accounted for as a single liability, net of unamortized debt issuance costs.

[0001628280-26-030777:notes:209]
Concurrent with the issuance of the 2032 Notes, we used approximately $843.1 million of the net proceeds to repurchase $581.1 million aggregate principal amounts of the 2026 Notes. We also paid $0.7 million of the related accrued interest. We have adopted and applied ASU 2024-04, Debt with Conversion and Other Options: Induced Conversions of Convertible Debt Instruments. We determined that this transaction met the requirements for the settlement of debt as an induced conversion. Accordingly, we recorded $256.9 million, which represents the fair value increase in the fair value of the debt, as a reduction to additional paid-in capital within the Company’s consolidated Balance Sheets as of March 28, 2026, and recognized an inducement expense of $5.9 million in our consolidated statements of operations during the three and nine months ended March 28, 2026, which represents the excess of fair value of the total consideration over the fair value of securities issuable pursuant to the original conversion terms.

[0001628280-26-030777:notes:210]
Since the closing price of our stock exceeded $129.08 (or 130% of the conversion price of $99.29) for 20 of the last 30 trading days of our first through third quarters of fiscal year 2026, our 2026 Notes remain convertible at the option of the holders during the fourth quarter of fiscal year 2026. Therefore, the 2026 Notes outstanding are recorded as short-term debt, which is presented as current liabilities in our consolidated balance sheets as of March 28, 2026, net of unamortized debt issuance costs. The entire aggregate amount of the 2026 Notes outstanding is recorded as convertible notes, non-current in our consolidated balance sheets as of June 28, 2025, net of unamortized debt issuance costs.

[0001628280-26-030777:notes:211]
As of April 30, 2026, we have received early conversion requests totaling $152.1 million aggregate principal amount of the 2026 Notes, which will be settled in cash and the conversion value in excess thereof will be settled in shares of common stock in accordance with the 2026 Indenture. In the three and nine months ended March 28, 2026, the aggregate principal amount of the 2026 Notes settled in cash was $0.1 million and $0.2 million, respectively.

[0001628280-26-030777:notes:212]
Our convertible notes consisted of the following components as of the periods presented (in millions):

[0001628280-26-030777:notes:213]
| March 28, 2026 | 2026 Notes |  | 2028 Notes |  | 2029 Notes |  | 2032 Notes |  | Total |  |  |  |  |  |
| Principal | $ | 468.7 |  |  | $ | 861.0 |  |  | $ | 603.7 |  |  | $ | 1,265.0 |  |  | $ | 3,198.4 |  |  |  |  |  |  |
| Unamortized debt issuance costs | (0.4) |  |  | (2.5) |  |  | (2.8) |  |  | (9.3) |  |  | (15.0) |  |  |  |  |  |  |
| Net carrying amount of the liability component | $ | 468.3 |  |  | $ | 858.5 |  |  | $ | 600.9 |  |  | $ | 1,255.7 |  |  | $ | 3,183.4 |  |  |  |  |  |  |

[0001628280-26-030777:notes:214]
| June 28, 2025 |  |  | 2026 Notes |  | 2028 Notes |  | 2029 Notes |  | Total |
| Principal |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |  | $ | 603.7 |  |  | $ | 2,514.7 |  |
| Unamortized debt issuance costs |  |  | (1.7) |  |  | (3.3) |  |  | (3.5) |  |  | (8.5) |  |
| Net carrying amount of the liability component |  |  | $ | 1,048.3 |  |  | $ | 857.7 |  |  | $ | 600.2 |  |  | $ | 2,506.2 |  |

[0001628280-26-030777:notes:215]
The following table sets forth interest expense information related to the convertible notes for the periods presented (in millions):

[0001628280-26-030777:notes:216]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 28, 2026 |  | March 29, 2025 |  | March 28, 2026 |  | March 29, 2025 |
| Contractual interest expense | $ | 4.9 |  |  | $ | 4.7 |  |  | $ | 14.6 |  |  | $ | 14.0 |  |
| Amortization of debt issuance costs | 1.0 |  |  | 0.8 |  |  | 2.9 |  |  | 2.3 |  |
| Total interest expense | $ | 5.9 |  |  | $ | 5.5 |  |  | $ | 17.5 |  |  | $ | 16.3 |  |

[0001628280-26-030777:notes:217]
The future interest and principal payments related to our convertible notes are as follows as of March 28, 2026 (in millions):

[0001628280-26-030777:notes:218]
| Fiscal Years | 2026 Notes |  | 2028 Notes |  | 2029 Notes |  | 2032 Notes |  | Total |
| 2026 | $ | 1.0 |  |  | $ | 2.1 |  |  | $ | 3.9 |  |  | $ | — |  |  | $ | 7.0 |  |
| 2027 | 469.7 |  |  | 4.3 |  |  | 6.7 |  |  | 4.7 |  |  | 485.4 |  |
| 2028 | — |  |  | 865.3 |  |  | 6.7 |  |  | 4.7 |  |  | 876.7 |  |
| 2029 | — |  |  | — |  |  | 6.7 |  |  | 4.7 |  |  | 11.4 |  |
| 2030 | — |  |  | — |  |  | 607.1 |  |  | 4.7 |  |  | 611.8 |  |
| Thereafter | — |  |  | — |  |  | — |  |  | 1,274.5 |  |  | 1,274.5 |  |
| Total payments | $ | 470.7 |  |  | $ | 871.7 |  |  | $ | 631.1 |  |  | $ | 1,293.3 |  |  | $ | 3,266.8 |  |

[0001628280-26-030777:notes:219]
The principal balances of our convertible notes are reflected in the payment periods in the table above based on their respective contractual maturities.

[0001628280-26-030777:notes:220]
Term Loans

[0001628280-26-030777:notes:221]
SMBC Term Loan

[0001628280-26-030777:notes:222]
On August 9, 2024, we entered into a term loan agreement (the “SMBC 2029 Term Loan”) with Sumitomo Mitsui Banking Corporation (“SMBC”). The SMBC 2029 Term Loan provides an aggregate principal amount of 6.4 billion Japanese yen (“JPY”). The loan requires monthly principal payments of approximately 53.3 million JPY, from August 31, 2024 to June 30, 2029 and interest based on a fixed annual interest rate of 0.88%, with the remaining principal of approximately 3.3 billion JPY due on the loan maturity date of July 31, 2029. Under the loan agreement, we cannot prepay the outstanding loan without SMBC’s approval. In the event we prepay the outstanding loan with SMBC’s approval, we shall pay SMBC a settlement amount calculated pursuant to the terms of the loan agreement. The SMBC 2029 Term Loan is secured by the real estate owned in Sagamihara, Japan.

[0001628280-26-030777:notes:223]
On December 18, 2025, we entered into another term loan agreement (the “SMBC 2026 Term Loan”) with SMBC. The SMBC 2026 Term Loan provides an aggregate principal amount of 7.5 billion JPY. The loan requires monthly principal payments of 125.0 million JPY and interest based on a fixed annual interest rate of 1.44%, with the remaining principal of approximately 6.1 billion JPY due on the loan maturity date of December 19, 2026, subject to repayment pitch of 60 months. Under the loan agreement, we cannot prepay the outstanding loan without SMBC’s approval. In the event the Company prepays the outstanding loan with SMBC’s approval, we shall pay SMBC a settlement amount calculated pursuant to the terms of the loan agreement. The SMBC 2026 Term Loan is secured by the real estate owned in Sagamihara, Japan.

[0001628280-26-030777:notes:224]
The SMBC 2029 Term Loan and the SMBC 2026 Term Loan are collectively referred to as SMBC Term Loans. We are expected to maintain a debt service coverage ratio of at least 1.2 for our Japan entity for fiscal year 2026 and maintains a U.S. dollar deposit account with a balance, translated into JPY, equal to or greater than the outstanding principal amount of the SMBC 2026 Term Loan both in accordance with the terms of the SMBC term loan agreements.

[0001628280-26-030777:notes:225]
As of March 28, 2026, we had $78.9 million in principal amount outstanding in SMBC Term Loans, of which the short-term portion of $49.6 million is recorded as current liabilities while the long-term portion of $29.3 million is recorded as long-term debt in our condensed consolidated balance sheets.

[0001628280-26-030777:notes:226]
Mizuho Term Loan

[0001628280-26-030777:notes:227]
On September 20, 2024, we entered into a term loan agreement (the “Mizuho Term Loan”) with Mizuho Bank, Ltd. (“Mizuho”), in order to finance our planned manufacturing expansions. The Mizuho Term Loan provides for borrowings of 4.5 billion JPY with a 5-year term from the funding date September 20, 2024. The loan requires quarterly principal payments of approximately 225.0 million JPY commencing on December 20, 2024 with the final payment on September 20, 2029. The Mizuho Term Loan bears interest at a fixed annual rate of 0.90%. The Mizuho Term Loan is secured by the real estate assets owned by NeoPhotonics Semiconductor GK. The Mizuho Term Loan agreement requires that we and certain of our domestic subsidiaries comply with covenants relating to customary matters, including obtaining approval from Mizuho prior to transferring, creating a security interest, or disposing of the collateral assets; obtaining approval from Mizuho prior to a business transfer, business acquisition, corporate reorganization or changes such as mergers, company splits, share exchanges or share transfers or capital structure changes; obtaining approval from Mizuho prior to changing our indirect ownership in Lumentum Japan, Inc; and obtaining approval from Mizuho prior to a distribution of dividends by Lumentum Japan, Inc. to its shareholders. In addition, under the Mizuho Term Loan, we maintain certain balance in U.S. dollar time and savings deposit accounts in accordance with the terms of the Mizuho Term Loan Agreement.

[0001628280-26-030777:notes:228]
As of March 28, 2026, we had $19.5 million in principal amount outstanding, of which the short-term portion of $5.6 million is recorded as current liabilities while the long-term portion of $13.9 million is recorded as long-term debt in our condensed consolidated balance sheets.

[0001628280-26-030777:notes:229]
The SMBC Term Loan and the Mizuho Term Loan are collectively referred to as Japan Term Loans.

[0001628280-26-030777:notes:230]
Revolving Credit Facility

[0001628280-26-030777:notes:231]
On December 19, 2025, we entered into a credit agreement (the “Credit Agreement”) with the lenders party thereto and Wells Fargo Bank, National Association, as administrative and collateral agent. The Credit Agreement provides for a senior secured revolving credit facility in an aggregate principal amount of $400.0 million, including a $23.0 million sublimit for the issuance of letters of credit. The Credit Agreement provides that we have the right at any time and from time to time to incur one or more incremental revolving commitments and/or incremental term loans up to an unlimited amount, subject to certain customary conditions precedent and other requirements. The proceeds of the loans under the Credit Agreement may be used for working capital and general corporate purposes.

[0001628280-26-030777:notes:232]
Revolving loans under the Credit Agreement may be borrowed, repaid and reborrowed, without premium or penalty (subject to customary breakage costs), until their maturity date under the Credit Agreement, at which time all amounts borrowed must be repaid. Revolving loans under the Credit Agreement will mature on December 19, 2030, subject to earlier maturity on the date that is 91 days prior to the final scheduled maturity date of our existing outstanding convertible notes, if on such date, we are unable to satisfy certain liquidity and/or total net leverage requirements.

[0001628280-26-030777:notes:233]
At the Company’s option, borrowings bear interest at either a base rate plus an applicable margin ranging from 0.50% to 1.50%, or a term Secured Overnight Financing Rate (“SOFR”) plus a margin ranging from 1.50% to 2.50%, in each case with such margin based upon the Company’s secured net leverage ratio, as determined in accordance with the terms of the Credit Agreement. Interest is payable quarterly in arrears with respect to borrowings bearing interest at the alternate base rate or on the last day of an interest period, but at least every three months, with respect to borrowings bearing interest at a term SOFR rate. The Company is required to pay to the Administrative Agent for the account of each Lender a commitment fee on a quarterly basis in an amount equal to 0.15% to 0.35% (depending on the Company’s secured net leverage ratio) of unused availability under the revolving facility. The Company is also obligated to pay other fees customary for revolving credit facilities of this size and type.

[0001628280-26-030777:notes:234]
The Credit Agreement contains customary representations, warranties, affirmative and negative covenants, and events of default. The negative covenants include, among others, restrictions on liens, investments, indebtedness, fundamental changes, restricted payments, transactions with affiliates and prepayments of subordinated debt, all subject to certain exceptions. In addition, the Credit Agreement contains financial covenants, tested at the end of each fiscal quarter, requiring us to maintain a secured net leverage ratio of less than or equal to 3.25:1.00, subject to a 0.50:1.00 step-up for four fiscal quarters in connection with a material acquisition, and an interest coverage ratio of no less than 3.00:1.00.

[0001628280-26-030777:notes:235]
The obligations under the Credit Agreement are required to be guaranteed by certain of our material domestic subsidiaries and are secured by substantially all of our and subsidiary guarantors assets, subject to customary exceptions.

[0001628280-26-030777:notes:236]
As of March 28, 2026, there were no borrowings outstanding under the revolving credit facility. 
We incurred financing costs of about $2.4 million in connection with the revolving credit facility, which was presented as other non-current assets in our condensed consolidated balance sheets and are amortized to interest expense over the term of the facility. As of March 28, 2026, the remaining unamortized financing costs was about $2.3 million.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001628280-26-030777:notes:237]
[same as prior period, unchanged from 0001628280-26-005129:notes:220]

[0001628280-26-030777:notes:238]
[same as prior period, unchanged from 0001628280-26-005129:notes:221]

[0001628280-26-030777:notes:239]
[same as prior period, unchanged from 0001628280-26-005129:notes:222]

[0001628280-26-030777:notes:240]
|  | Foreign Currency Translation Adjustments, Net of Tax (1) |  | Defined Benefit Obligations, Net of Tax (2) |  | Unrealized Gain on Available-for-Sale Securities, Net of Tax (3) |  |  |  | Total |
| Beginning balance as of June 28, 2025 | $ | 9.9 |  |  | $ | (1.6) |  |  | $ | 0.7 |  |  |  |  | $ | 9.0 |  |
| Other comprehensive gain (loss), net | (0.3) |  |  | — |  |  | 0.4 |  |  |  |  | 0.1 |  |
| Ending balance as of September 27, 2025 | $ | 9.6 |  |  | $ | (1.6) |  |  | $ | 1.1 |  |  |  |  | $ | 9.1 |  |
| Other comprehensive gain, net | — |  |  | — |  |  | 0.3 |  |  |  |  | 0.3 |  |
| Ending balance as of December 27, 2025 | $ | 9.6 |  |  | $ | (1.6) |  |  | $ | 1.4 |  |  |  |  | $ | 9.4 |  |
| Other comprehensive loss, net | — |  |  | — |  |  | (2.4) |  |  |  |  | (2.4) |  |
| Ending balance as of March 28, 2026 | $ | 9.6 |  |  | $ | (1.6) |  |  | $ | (1.0) |  |  |  |  | $ | 7.0 |  |
|  | Foreign Currency Translation Adjustments, Net of Tax (1) |  | Defined Benefit Obligations, Net of Tax (2) |  | Unrealized Gain (Loss) on Available-for-Sale Securities, Net of Tax (3) |  |  |  | Total |
| Beginning balance as of June 29, 2024 | $ | 9.8 |  |  | $ | 0.7 |  |  | $ | (1.2) |  |  |  |  | $ | 9.3 |  |
| Other comprehensive gain, net | — |  |  | — |  |  | 2.3 |  |  |  |  | 2.3 |  |
| Ending balance as of September 28, 2024 | $ | 9.8 |  |  | $ | 0.7 |  |  | $ | 1.1 |  |  |  |  | $ | 11.6 |  |
| Other comprehensive loss, net | (0.3) |  |  | — |  |  | (1.1) |  |  |  |  | (1.4) |  |
| Ending balance as of December 28, 2024 | $ | 9.5 |  |  | $ | 0.7 |  |  | $ | — |  |  |  |  | $ | 10.2 |  |
| Other comprehensive loss, net | 0.3 |  |  | — |  |  | 0.6 |  |  |  |  | 0.9 |  |
| Ending balance as of March 29, 2025 | $ | 9.8 |  |  | $ | 0.7 |  |  | $ | 0.6 |  |  |  |  | $ | 11.1 |  |

[0001628280-26-030777:notes:241]
[same as prior period, unchanged from 0001628280-26-005129:notes:224]

[0001628280-26-030777:notes:242]
[same as prior period, unchanged from 0001628280-26-005129:notes:225]

[0001628280-26-030777:notes:243]
(3) For the three and nine months ended March 28, 2026, our unrealized gain on available-for-sale securities is presented net of tax of nil for both periods.

[0001628280-26-030777:notes:244]
For the three and nine months ended March 29, 2025, our unrealized gain (loss) on available-for-sale securities is presented net of tax of nil for both periods.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001628280-26-030777:notes:245]
[same as prior period, unchanged from 0001628280-26-005129:notes:228]

[0001628280-26-030777:notes:246]
[same as prior period, unchanged from 0001628280-26-005129:notes:229]

[0001628280-26-030777:notes:247]
[same as prior period, unchanged from 0001628280-26-005129:notes:230]

[0001628280-26-030777:notes:248]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 28, 2026 |  | March 29, 2025 |  | March 28, 2026 |  | March 29, 2025 |
| Balance as of beginning of period | $ | 2.2 |  |  | $ | 1.5 |  |  | $ | 2.5 |  |  | $ | 11.1 |  |
| Charges | 1.1 |  |  | 7.2 |  |  | 9.0 |  |  | 17.6 |  |
| Payments and other adjustments | (1.3) |  |  | (6.8) |  |  | (9.5) |  |  | (26.8) |  |
| Balance as of end of period | $ | 2.0 |  |  | $ | 1.9 |  |  | $ | 2.0 |  |  | $ | 1.9 |  |

[0001628280-26-030777:notes:249]
During the three and nine months ended March 28, 2026, we recorded restructuring and related charges of  $1.1 million and $9.0 million, respectively, primarily related to a reduction in force during the period in order to enhance operational efficiency and realign our investments toward the most critical initiatives.

[0001628280-26-030777:notes:250]
During the three and nine months ended March 29, 2025, we recorded restructuring and related charges of $7.2 million and $17.6 million, respectively mainly due to our integration efforts and cost reduction initiatives. Restructuring charges for the three months ended March 29, 2025 primarily related to $5.7 million of assets written-off including property, plant and equipment, prepayments and other current assets as well as $1.4 million of charges for other contractual commitments associated with site closures driven by restructuring initiatives announced in April 2025 that will allow us to focus on other market opportunities including cloud and AI markets. Restructuring charges for the nine months ended March 29, 2025 include $12.4 million of assets written-off including property, plant and equipment, prepayments and other current assets primarily due to efforts to consolidate our sites and focus on other market opportunities including cloud and AI markets. In addition, we also recorded $3.0 million of charges related to the discontinuation of our in-house development of coherent Digital Signal Processors (“DSPs”) and Radio Frequency Integrated Circuits (“RFICs”).

[0001628280-26-030777:notes:251]
[same as prior period, unchanged from 0001628280-26-005129:notes:234]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-26-030777:notes:252]
[same as prior period, unchanged from 0001628280-26-005129:notes:235]

[0001628280-26-030777:notes:253]
[same as prior period, unchanged from 0001628280-26-005129:notes:236]

[0001628280-26-030777:notes:254]
We recorded a tax provision of $39.6 million and $58.9 million for the three and nine months ended March 28, 2026. Our tax provision for the three months ended March 28, 2026 includes a discrete tax benefit of 7.3 million primarily related to the tax benefit from a windfall in connection with stock-based compensation vested during the quarter and return-to-provision differences, partially offset by the tax expense related to the remeasurement of certain tax-related accounts. Our tax provision for the nine months ended March 28, 2026 includes a discrete tax expense of $6.8 million, primarily related to the tax benefit from a windfall in connection with stock-based compensation vested during the period, return-to-provision differences and the revaluation of deferred tax balances,  partially offset by the tax expense associated with income from a claim settlement, the currency remeasurement of certain tax-related accounts, and interest accruals on uncertain tax positions.

[0001628280-26-030777:notes:255]
We recorded a tax provision of $4.9 million and $26.7 million for the three and nine months ended March 29, 2025, respectively. Our tax provision for the three months ended March 29, 2025 is primarily attributable to the income tax expense from uncertain tax positions and withholding taxes, partially offset by the tax benefit from prior year changes in uncertain tax positions. Our tax provision for the nine months ended March 29, 2025 is primarily attributable to the income tax expense from pre-tax earnings, uncertain tax positions, interest on uncertain tax positions, foreign return-to-provision differences and withholding taxes, partially offset by the tax benefit from prior year changes in uncertain tax positions.

[0001628280-26-030777:notes:256]
Our estimated effective tax rate for the nine months ended March 28, 2026 differs from the 21% U.S. statutory rate primarily due to the income tax expense from foreign income inclusions in the U.S., current year valuation allowance change, and changes in unrecognized tax benefits, partially offset by the income tax benefit from foreign rate differential and various income tax credits.

[0001628280-26-030777:notes:257]
We regularly assess our ability to realize our deferred tax assets on a quarterly basis and will establish a valuation allowance if it is more-likely-than-not that some portion of the deferred tax assets will not be realized. As of March 28, 2026, we maintain a full valuation allowance on U.S. federal and state and certain foreign deferred tax assets. We will continue to assess the need for a valuation allowance against our remaining deferred tax assets and may increase or decrease our valuation allowance materially in the future.

[0001628280-26-030777:notes:258]
As of March 28, 2026, we had $70.4 million of unrecognized tax benefits, which, if recognized, would affect the effective tax rate. We are subject to examination of income tax returns by various domestic and foreign tax authorities. The timing of resolution and closure of these tax examinations is highly unpredictable. Although it is possible that certain ongoing tax examinations may be concluded within the next 12 months, we cannot reasonably estimate the impact to tax expense and net income from tax examinations that could be resolved or closed within the next 12 months. Subject to audit timing and uncertainty, we expect the amount of unrecognized tax benefit that would become recognized due to expiration of the statute of limitations and affect the effective tax rate to decrease by $3.4 million over the next 12 months.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001628280-26-030777:notes:259]
[same as prior period, unchanged from 0001628280-26-005129:notes:242]

[0001628280-26-030777:notes:260]
Series A Convertible Preferred Stock

[0001628280-26-030777:notes:261]
On March 2, 2026, we completed the issuance and sale of approximately 2.9 million shares of our Series A Convertible Preferred Stock, par value $0.001 per share (the “Series A Preferred Stock”) to NVIDIA Corporation (“NVIDIA”), in a private placement pursuant to a Securities Purchase Agreement. The shares of Series A Preferred Stock were sold at a price of $695.31 per share for an aggregate purchase price of $2.0 billion in cash. The Series A Preferred Stock has the following terms which are set forth in the Certificate of Designation filed with the Secretary of State of the State of Delaware (the “Certificate of Designation”):

[0001628280-26-030777:notes:262]
Conversion. The Series A Preferred Stock will convert on a one-for-one basis into shares of our common stock (i) at the option of the holder, provided, that, no holder may exercise this conversion right until the expiration or termination of the applicable waiting period (or any extension thereof) under the Hart-Scott-Rodino Antitrust Improvements Act of 1976, as amended, and the rules and regulations promulgated thereunder or (ii) automatically immediately before the closing of a qualified sale. A qualified sale is defined as the bona fide sale of the Series A Preferred Stock to the Company or a non-affiliate of the holder.

[0001628280-26-030777:notes:263]
Dividends. Each holder of Series A Preferred Stock will be entitled to receive dividends in the same manner as holders of our common stock, as determined on an as-converted basis, assuming all outstanding shares of Series A Preferred Stock have converted pursuant to the terms of the Certificate of Designation as of immediately prior to the record date of the applicable dividend.

[0001628280-26-030777:notes:264]
Voting Rights. Other than with respect to the election of directors, for which the Series A Preferred Stock will not be entitled to vote, holders of Series A Preferred Stock will vote together with holders of our common stock on an as-converted basis. We may not alter or change adversely the powers, preferences or rights of the Series A Preferred Stock or alter or amend the Certificate of Designation without the affirmative vote or consent of a majority of the outstanding shares of Series A Preferred Stock.

[0001628280-26-030777:notes:265]
Dissolution, Liquidation or Winding Up. In connection with a dissolution, liquidation or winding up of the Company, distributions to our stockholders shall be made among the holders of Series A Preferred Stock and our common stock pro rata in proportion to number of shares held by each such holder. All shares of Series A Preferred Stock shall be treated as if they had been converted to our common stock pursuant to the terms of the Certificate of Designation immediately prior to such event.

[0001628280-26-030777:notes:266]
No Preemptive or Redemption Rights. The holders of Series A Preferred Stock have no preemptive or redemption rights.

[0001628280-26-030777:notes:267]
[same as prior period, unchanged from 0001628280-26-005129:notes:243]

[0001628280-26-030777:notes:268]
[same as prior period, unchanged from 0001628280-26-005129:notes:244]

[0001628280-26-030777:notes:269]
We adopted the 2015 Equity Incentive Plan (the “2015 Plan”) in connection with our separation from JDS Uniphase Corporation (“JDSU” and now, Viavi Solutions Inc.) in July 2015. The 2015 Plan provided for the grant of incentive stock options, within the meaning of Section 422 of the Internal Revenue Code, to our employees and any parent and subsidiary corporations’ employees, and for the grant of nonstatutory stock options (“stock options”), restricted stock awards (“RSAs”), restricted stock units (“RSUs”), stock appreciation rights (“SARs”), performance units (“PSUs”) and performance shares to our employees, directors and consultants and any parent or subsidiary corporations’ employees and consultants.

[0001628280-26-030777:notes:270]
On November 28, 2023, we adopted and assumed the Amended and Restated Share Option Scheme of Cloud Light Optoelectronics Limited (the “Cloud Light Scheme” and together with the 2015 Plan, the “Prior Plans”) in connection with the Cloud Light acquisition. The Cloud Light Scheme provides for the grant of stock options, RSAs, RSUs, SARs, and performance shares to eligible employees and other service providers.

[0001628280-26-030777:notes:271]
[same as prior period, unchanged from 0001628280-26-005129:notes:247]

[0001628280-26-030777:notes:272]
[same as prior period, unchanged from 0001628280-26-005129:notes:248]

[0001628280-26-030777:notes:273]
As of March 28, 2026, we had 3.4 million shares subject to stock options, RSUs, RSAs, and PSUs issued and outstanding under the Equity Incentive Plans. RSUs and PSUs are performance-based, market-based and time-based or any combination thereof and are expected to vest within four years. As of March 28, 2026, 3.4 million shares of common stock under the Equity Incentive Plans were available for grant.

[0001628280-26-030777:notes:274]
[same as prior period, unchanged from 0001628280-26-005129:notes:250]

[0001628280-26-030777:notes:275]
[same as prior period, unchanged from 0001628280-26-005129:notes:251]

[0001628280-26-030777:notes:276]
[same as prior period, unchanged from 0001628280-26-005129:notes:252]

[0001628280-26-030777:notes:277]
[same as prior period, unchanged from 0001628280-26-005129:notes:253]

[0001628280-26-030777:notes:278]
During the nine months ended March 28, 2026, our board of directors approved grants of 1.1 million RSUs, which primarily vest over three years. The fair value of these grants is based on the closing market price of our common stock on the grant date.

[0001628280-26-030777:notes:279]
[same as prior period, unchanged from 0001628280-26-005129:notes:255]

[0001628280-26-030777:notes:280]
[same as prior period, unchanged from 0001628280-26-005129:notes:256]

[0001628280-26-030777:notes:281]
During the nine months ended March 28, 2026, our board of directors granted 0.1 million PSUs with an aggregate grant date fair value of $13.7 million to certain executive officers and senior management. These PSUs will vest subject to the achievement of earnings per share targets, as well as service conditions, over three years. The number of shares may be increased or decreased based on the results of these measurement targets ranging between 0% and 200% in accordance with the terms established at the date of grant. In addition, the board of directors also approved a grant of 0.1 million PSUs with an aggregate grant date fair value of $33.0 million to certain executive officers and senior management. These PSUs will vest subject to the achievement of the Company’s total shareholder return (or “TSR”) relative to specified peer group, as well as service conditions, over three years. The number of shares that ultimately vest may be increased or decreased based on the results of these measurement targets ranging between 0% and 200% in accordance with the terms established at the date of grant. The Company estimated the grant date fair value of these PSU awards using a Monte-Carlo simulation model, which was calculated at $282.85 per share.

[0001628280-26-030777:notes:282]
[same as prior period, unchanged from 0001628280-26-005129:notes:258]

[0001628280-26-030777:notes:283]
[same as prior period, unchanged from 0001628280-26-005129:notes:259]

[0001628280-26-030777:notes:284]
Our ESPP provides eligible employees with the opportunity to acquire an ownership interest in the Company through periodic payroll deductions and provides a 15% purchase price discount as well as a 6-month look-back period. The ESPP is structured as a qualified employee stock purchase plan under Section 423 of the Internal Revenue Code of 1986, as amended. The ESPP will terminate upon the date on which all shares available for issuance have been sold. We estimate the fair value of the ESPP shares on the date of grant using the Black-Scholes option-pricing model. Of the 3.0 million shares authorized under the ESPP, 0.3 million shares remained available for issuance as of March 28, 2026.

[0001628280-26-030777:notes:285]
[same as prior period, unchanged from 0001628280-26-005129:notes:261]

[0001628280-26-030777:notes:286]
[same as prior period, unchanged from 0001628280-26-005129:notes:262]

[0001628280-26-030777:notes:287]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 28, 2026 |  | March 29, 2025 |  | March 28, 2026 |  | March 29, 2025 |
| Cost of sales | $ | 9.2 |  |  | $ | 9.2 |  |  | $ | 30.7 |  |  | $ | 28.1 |  |
| Research and development | 9.4 |  |  | 11.2 |  |  | 29.0 |  |  | 31.9 |  |
| Selling, general and administrative | 23.0 |  |  | 42.4 |  |  | 69.7 |  |  | 77.2 |  |
| Total stock-based compensation | $ | 41.6 |  |  | $ | 62.8 |  |  | $ | 129.4 |  |  | $ | 137.2 |  |

[0001628280-26-030777:notes:288]
[same as prior period, unchanged from 0001628280-26-005129:notes:264]

[0001628280-26-030777:notes:289]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 28, 2026 |  | March 29, 2025 |  | March 28, 2026 |  | March 29, 2025 |
| RSUs | $ | 28.5 |  |  | $ | 31.5 |  |  | $ | 81.1 |  |  | $ | 80.3 |  |
| AIP PSUs | — |  |  | 8.3 |  |  | 4.8 |  |  | 21.9 |  |
| TSR PSUs | 4.5 |  |  | 1.0 |  |  | 12.0 |  |  | 1.6 |  |
| Other PSUs | 5.9 |  |  | 19.4 |  |  | 21.3 |  |  | 24.7 |  |
| Total PSUs | 10.4 |  |  | 28.7 |  |  | 38.1 |  |  | 48.2 |  |
| Options | 1.0 |  |  | 1.3 |  |  | 3.6 |  |  | 3.9 |  |
| ESPP | 1.3 |  |  | 1.2 |  |  | 4.1 |  |  | 3.4 |  |
| Sub-total | 41.2 |  |  | 62.7 |  |  | 126.9 |  |  | 135.8 |  |
| Change in stock-based compensation capitalized to inventory | 0.4 |  |  | 0.1 |  |  | 2.5 |  |  | 1.4 |  |
| Total stock-based compensation | $ | 41.6 |  |  | $ | 62.8 |  |  | $ | 129.4 |  |  | $ | 137.2 |  |

[0001628280-26-030777:notes:290]
During the three and nine months ended March 28, 2026, we recorded $10.4 million and $38.1 million of stock-based compensation related to PSUs, respectively. During the three and nine months ended March 29, 2025, we recorded $28.7 million and $48.2 million of stock-based compensation related to PSUs, respectively, which includes about $18.2 million of additional stock-compensation resulting from modifications as discussed below on both periods.

[0001628280-26-030777:notes:291]
On February 2, 2025, the Company and our former President and Chief Executive Officer mutually agreed to modify the terms of previously granted equity awards by changing the level of remaining service condition required for vesting. In accordance with ASC 718, Compensation - Stock Compensation, the Company accounted for the change as a modification as the Company determined the remaining service conditions were non-substantive. For awards that vested on February 20, 2025, the separation date, we recognized compensation expense equal to the sum of the remaining unrecognized grant-date fair value amounting to $9.0 million during the three and nine months ended March 29, 2025. For awards that vested on December 15, 2025, the termination date, we recognized compensation expense equal to the sum of the remaining unrecognized grant-date fair value and any incremental fair value resulting from the modification of $19.2 million during the three and nine months ended March 29, 2025.

[0001628280-26-030777:notes:292]
[same as prior period, unchanged from 0001628280-26-005129:notes:267]

[0001628280-26-030777:notes:293]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 28, 2026 |  | March 29, 2025 |  | March 28, 2026 |  | March 29, 2025 |
| Income tax benefit associated with stock-based compensation | $ | 14.2 |  |  | $ | 5.4 |  |  | $ | 24.5 |  |  | $ | 11.5 |  |

[0001628280-26-030777:notes:294]
Approximately $12.1 million and $14.6 million of stock-based compensation was capitalized to inventory as of March 28, 2026 and June 28, 2025, respectively.

[0001628280-26-030777:notes:295]
The table below summarizes the unrecognized stock-based compensation cost related to unvested shares and the weighted-average period over which it is expected to be recognized as of March 28, 2026:

[0001628280-26-030777:notes:296]
|  | Unrecognized stock-based compensation (in millions) |  | Weighted-average period(in years) |
| RSUs | $ | 167.1 |  |  | 1.9 |
| PSUs | 83.2 |  |  | 2.2 |
| Stock options | 2.3 |  |  | 0.6 |
| ESPP | 0.7 |  |  | 0.1 |

[0001628280-26-030777:notes:297]
[same as prior period, unchanged from 0001628280-26-005129:notes:272]

[0001628280-26-030777:notes:298]
The following table summarizes our award activities for the nine months ended March 28, 2026 (in millions):

[0001628280-26-030777:notes:299]
|  | Stock Options |  | Restricted Stock Units |  | Performance Stock Units |  |  |  |  |
|  | Number of Shares |  | Weighted-Average Exercise Price per Share |  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |  |  |  |  |
| Balance as of June 28, 2025 | 0.6 |  |  | $ | 8.1 |  |  | 2.6 |  |  | $ | 59.9 |  |  | 1.6 |  |  | $ | 61.0 |  |  |  |  |  |
| Granted | — |  |  | — |  |  | 1.1 |  |  | 138.0 |  |  | 0.2 |  |  | 120.4 |  |  |  |  |  |
| Vested/Exercised | (0.3) |  |  | 7.9 |  |  | (1.2) |  |  | 61.8 |  |  | (0.9) |  |  | 57.0 |  |  |  |  |  |
| Canceled/Forfeited | — |  |  | — |  |  | (0.2) |  |  | 68.0 |  |  | (0.1) |  |  | 82.2 |  |  |  |  |  |
| Balance as of March 28, 2026 | 0.3 |  |  | $ | 8.1 |  |  | 2.3 |  |  | $ | 95.6 |  |  | 0.8 |  |  | $ | 82.5 |  |  |  |  |  |

[0001628280-26-030777:notes:300]
[same as prior period, unchanged from 0001628280-26-005129:notes:275]

[0001628280-26-030777:notes:301]
|  | Awards Available for Grant |
| Balance as of June 28, 2025 | 2.6 |  |
| Authorized | 3.2 |  |
| Removed | (1.4) |  |
| Granted | (1.3) |  |
| Canceled/Forfeited | 0.3 |  |
| Balance as of March 28, 2026 | 3.4 |  |

[0001628280-26-030777:notes:302]
[same as prior period, unchanged from 0001628280-26-005129:notes:277]

[0001628280-26-030777:notes:303]
The ESPP expense for the three and nine months ended March 28, 2026 was $1.3 million and $4.1 million, respectively. The ESPP expense for the three and nine months ended March 29, 2025 was $1.2 million and $3.4 million, respectively. The expense related to the ESPP is recorded on a straight-line basis over the relevant subscription period.

[0001628280-26-030777:notes:304]
During the nine months ended March 28, 2026 and March 29, 2025, there were 0.1 million and 0.2 million shares issued to employees through the ESPP, respectively.


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0001628280-26-030777:notes:305]
Note 14. Commitments and Contingencies

[0001628280-26-030777:notes:306]
Purchase Obligations

[0001628280-26-030777:notes:307]
Our purchase obligations of $1,795.6 million as of March 28, 2026 represent legally binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule and adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

[0001628280-26-030777:notes:308]
We depend on a limited number of contract manufacturers, subcontractors and suppliers for raw materials, packages and standard components. We generally purchase these single or limited source products through standard purchase orders or one-year supply agreements and have no significant long-term guaranteed supply agreements with these vendors. While we seek to maintain a sufficient safety stock of such products and maintain on-going communications with our suppliers to guard against interruptions or cessation of supply, our business and results of operations could be adversely affected by a stoppage or delay of supply, substitution of more expensive or less reliable products, receipt of defective parts or contaminated materials, increases in the price of such supplies, or our inability to obtain reduced pricing from our suppliers in response to competitive pressures. In addition, the imposition of tariffs on certain imported goods and materials may increase our costs and place upward pressure on the cost of sales.

[0001628280-26-030777:notes:309]
Product Warranties

[0001628280-26-030777:notes:310]
We provide reserves for the estimated costs of product warranties at the time revenue is recognized. We typically offer a twelve-month warranty for most of our products. However, in some instances depending upon the product, product components or application of our products by the end customer, our warranties can vary and generally range from six months to five years. We estimate the costs of our warranty obligations on an annualized basis based on our historical experience of known product failure rates, use of materials to repair or replace defective products, and service delivery costs incurred in correcting product failures. In addition, from time-to-time, specific warranty accruals may be made if unforeseen technical problems arise with specific products. We assess the adequacy of our recorded warranty liabilities and adjust the amounts as necessary.

[0001628280-26-030777:notes:311]
The following table presents the changes in our warranty reserve for the periods presented (in millions):

[0001628280-26-030777:notes:312]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 28, 2026 |  | March 29, 2025 |  | March 28, 2026 |  | March 29, 2025 |
| Balance as of beginning of period | $ | 22.7 |  |  | $ | 12.8 |  |  | $ | 14.4 |  |  | $ | 13.2 |  |
| Warranties assumed in Cloud Light acquisition | — |  |  | — |  |  | — |  |  | 0.8 |  |
| Provision for warranty (1) | 4.4 |  |  | 1.8 |  |  | 20.7 |  |  | 6.2 |  |
| Utilization of reserve, net | (2.1) |  |  | (1.6) |  |  | (10.1) |  |  | (7.2) |  |
| Balance as of end of period | $ | 25.0 |  |  | $ | 13.0 |  |  | $ | 25.0 |  |  | $ | 13.0 |  |

[0001628280-26-030777:notes:313]
(1) During the nine months ended March 28, 2026, we recorded $9.8 million of warranty expense associated with Cloud Light’s legacy products in our condensed consolidated statements of operations.

[0001628280-26-030777:notes:314]
Environmental Liabilities

[0001628280-26-030777:notes:315]
Our research and development, manufacturing and distribution operations involve the use of hazardous substances and are regulated under international, federal, state and local laws governing health and safety and the environment. We apply strict standards for protection of the environment and occupational health and safety to sites inside and outside the United States, even if not subject to regulations imposed by foreign governments. We believe that our properties and operations at our facilities comply in all material respects with applicable environmental laws and occupational health and safety laws. However, the risk of environmental liabilities cannot be completely eliminated and there can be no assurance that the application of environmental and health and safety laws will not require us to incur significant expenditures. We are also regulated under a number of international, federal, state and local laws regarding recycling, product packaging and product content requirements. The environmental and product content/disposal and recycling laws are gradually becoming more stringent and may cause us to incur significant expenditures in the future.

[0001628280-26-030777:notes:316]
Legal Proceedings

[0001628280-26-030777:notes:317]
We are subject to a variety of claims and suits that arise from time-to-time in the ordinary course of our business. While management currently believes that resolving claims against us, individually or in the aggregate, will not have a material adverse impact on our financial position, results of operations or statements of cash flows, these matters are subject to inherent uncertainties and management’s view of these matters may change in the future. We accrue for loss contingencies when it is both probable that we will incur the loss and when we can reasonably estimate the amount of the loss or range of loss. As of March 28, 2026, the accrual for expected settlement of litigation matters was not material.

[0001628280-26-030777:notes:318]
Regulatory Matters

[0001628280-26-030777:notes:319]
In August 2024, we received inquiries from the Bureau of Industry and Security of the U.S. Department of Commerce (“BIS”) and Department of Justice (“DOJ”) following our voluntary disclosure to BIS in December 2023, and supplemented in April 2024. We continue to cooperate with both agencies on this matter. We are unable to predict the likely outcome of these matters.

[0001628280-26-030777:notes:320]
Indemnifications

[0001628280-26-030777:notes:321]
In the normal course of business, we enter into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown, because claims may be made against us in the future, and we may record charges in the future as a result of these indemnification obligations.

[0001628280-26-030777:notes:322]
On March 5, 2025, we completed a sale of net assets located in an entity in Shenzhen, China. We have reclassified a $21.4 million unrecognized tax position to other non-current liabilities in the condensed consolidated balance sheets as of June 28, 2025 for an indemnification liability related to the sale of certain assets. This does not impact our results of operations for the year ended June 28, 2025. We did not have any other material indemnification claims that were probable or reasonably possible.

[0001628280-26-030777:notes:323]
Audit Proceedings

[0001628280-26-030777:notes:324]
We are under audit by various domestic and foreign tax authorities with regards to income tax and indirect tax matters. In some, although not all cases, we have reserved for potential adjustments to our provision for income taxes and accrual of indirect taxes that may result from examinations by these tax authorities or final outcomes in judicial proceedings, and we believe that the final outcome of these examinations, agreements or judicial proceedings will not have a material effect on our results of operations. If events occur which indicate payment of these amounts is unnecessary, the reversal of the liabilities would result in the recognition of benefits in the period when we determine the liabilities are no longer necessary. If our estimates of the federal, state, and foreign income tax liabilities and indirect tax liabilities are less than the ultimate assessment, it could result in a further charge to expense.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001628280-26-030777:notes:325]
[same as prior period, unchanged from 0001628280-26-005129:notes:299]

[0001628280-26-030777:notes:326]
[same as prior period, unchanged from 0001628280-26-005129:notes:300]

[0001628280-26-030777:notes:327]
[same as prior period, unchanged from 0001628280-26-005129:notes:301]

[0001628280-26-030777:notes:328]
[same as prior period, unchanged from 0001628280-26-005129:notes:302]

[0001628280-26-030777:notes:329]
[same as prior period, unchanged from 0001628280-26-005129:notes:303]

[0001628280-26-030777:notes:330]
[same as prior period, unchanged from 0001628280-26-005129:notes:304]

[0001628280-26-030777:notes:331]
[same as prior period, unchanged from 0001628280-26-005129:notes:305]

[0001628280-26-030777:notes:332]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 28, 2026 |  | March 29, 2025 |  | March 28, 2026 |  | March 29, 2025 |
|  | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States | $ | 185.9 |  |  | 23.0 | % |  | $ | 70.5 |  |  | 16.6 | % |  | $ | 424.3 |  |  | 21.1 | % |  | $ | 213.5 |  |  | 18.3 | % |
| Mexico | 103.4 |  |  | 12.8 |  |  | 38.8 |  |  | 9.1 |  |  | 279.6 |  |  | 13.9 |  |  | 110.1 |  |  | 9.5 |  |
| Other Americas | 1.6 |  |  | 0.2 |  |  | 6.4 |  |  | 1.5 |  |  | 12.2 |  |  | 0.7 |  |  | 13.5 |  |  | 1.2 |  |
| Total Americas | $ | 290.9 |  |  | 36.0 | % |  | $ | 115.7 |  |  | 27.2 | % |  | $ | 716.1 |  |  | 35.7 | % |  | $ | 337.1 |  |  | 29.0 | % |
| Asia-Pacific: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Hong Kong | $ | 136.0 |  |  | 16.8 | % |  | $ | 96.5 |  |  | 22.7 | % |  | $ | 347.8 |  |  | 17.3 | % |  | $ | 285.7 |  |  | 24.5 | % |
| Thailand | 176.8 |  |  | 21.9 |  |  | 79.1 |  |  | 18.6 |  |  | 408.9 |  |  | 20.4 |  |  | 206.3 |  |  | 17.7 |  |
| China | 70.2 |  |  | 8.7 |  |  | 31.4 |  |  | 7.4 |  |  | 174.1 |  |  | 8.7 |  |  | 64.1 |  |  | 5.5 |  |
| Japan | 29.2 |  |  | 3.6 |  |  | 20.8 |  |  | 4.9 |  |  | 74.0 |  |  | 3.7 |  |  | 56.1 |  |  | 4.8 |  |
| Other Asia-Pacific | 52.7 |  |  | 6.5 |  |  | 39.4 |  |  | 9.3 |  |  | 157.9 |  |  | 7.8 |  |  | 101.3 |  |  | 8.7 |  |
| Total Asia-Pacific | $ | 464.9 |  |  | 57.5 | % |  | $ | 267.2 |  |  | 62.9 | % |  | $ | 1,162.7 |  |  | 57.9 | % |  | $ | 713.5 |  |  | 61.2 | % |
| EMEA | $ | 52.6 |  |  | 6.5 | % |  | $ | 42.3 |  |  | 9.9 | % |  | $ | 128.9 |  |  | 6.4 | % |  | $ | 113.7 |  |  | 9.8 | % |
| Total net revenue | $ | 808.4 |  |  | 100.0 | % |  | $ | 425.2 |  |  | 100.0 | % |  | $ | 2,007.7 |  |  | 100.0 | % |  | $ | 1,164.3 |  |  | 100.0 | % |

[0001628280-26-030777:notes:333]
During the three months ended March 28, 2026, two customers individually accounted for 26% and 12% of our total revenue, respectively. During the nine months ended March 28, 2026, two customers individually accounted for 24% and 16% of our total net revenue, respectively. We had no other customers that represented 10% or greater of our total net revenue.

[0001628280-26-030777:notes:334]
During the three months ended March 29, 2025, two customers individually accounted for 17%, 15% of our total revenue, respectively. During the nine months ended March 29, 2025, three customers individually accounted for 16%, 14%, and 10% of our total net revenue, respectively. We had no other customers that represented 10% or greater of our total net revenue.

[0001628280-26-030777:notes:335]
As of March 28, 2026, two customers individually accounted for 25% and 10% of gross accounts receivable, respectively. As of June 28, 2025, two customers individually accounted for 13% and 11% of gross accounts receivable, respectively. We had no other customers that represented 10% or greater of our gross accounts receivable.

[0001628280-26-030777:notes:336]
[same as prior period, unchanged from 0001628280-26-005129:notes:310]

[0001628280-26-030777:notes:337]
|  | March 28, 2026 |  | June 28, 2025 |
| Property, plant and equipment, net |  |  |  |
| United States | $ | 130.0 |  |  | $ | 123.0 |  |
| Thailand | 328.4 |  |  | 218.6 |  |
| Japan | 205.7 |  |  | 144.3 |  |
| United Kingdom | 129.4 |  |  | 109.4 |  |
| China | 118.2 |  |  | 76.8 |  |
| Other countries | 52.6 |  |  | 54.3 |  |
| Total property, plant and equipment, net | $ | 964.3 |  |  | $ | 726.4 |  |

[0001628280-26-030777:notes:338]
We purchase a portion of our inventory from contract manufacturers that are located primarily in Thailand, Taiwan, and Malaysia. During the three and nine months ended March 28, 2026, our net inventory purchases from a single contract manufacturer that represented 10% or greater of our total net inventory purchases were concentrated with one contract manufacturer, who accounted for 19% of the total net inventory purchases, for each period. During the three and nine months ended March 29, 2025, our net inventory purchases from a single contract manufacturer that represented 10% or greater of our total net inventory purchases were concentrated with one contract manufacturer, who accounted for 27% and 27% of the total net inventory purchases, respectively.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001628280-26-030777:notes:339]
[same as prior period, unchanged from 0001628280-26-005129:notes:313]

[0001628280-26-030777:notes:340]
[same as prior period, unchanged from 0001628280-26-005129:notes:314]

[0001628280-26-030777:notes:341]
[same as prior period, unchanged from 0001628280-26-005129:notes:315]

[0001628280-26-030777:notes:342]
[same as prior period, unchanged from 0001628280-26-005129:notes:316]

[0001628280-26-030777:notes:343]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 28, 2026 |  | March 29, 2025 |  | March 28, 2026 |  | March 29, 2025 |
|  | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |
| Components | 533.3 |  |  | 66.0 | % |  | 300.8 |  |  | 70.7 | % |  | 1,356.2 |  |  | 67.5 | % |  | $ | 795.9 |  |  | 68.4 | % |
| Systems | 275.1 |  |  | 34.0 | % |  | 124.4 |  |  | 29.3 | % |  | 651.5 |  |  | 32.5 | % |  | 368.4 |  |  | 31.6 | % |
| Net revenue | $ | 808.4 |  |  | 100.0 | % |  | $ | 425.2 |  |  | 100.0 | % |  | $ | 2,007.7 |  |  | 100.0 | % |  | $ | 1,164.3 |  |  | 100.0 | % |

[0001628280-26-030777:notes:344]
[same as prior period, unchanged from 0001628280-26-005129:notes:318]

[0001628280-26-030777:notes:345]
[same as prior period, unchanged from 0001628280-26-005129:notes:319]

[0001628280-26-030777:notes:346]
[same as prior period, unchanged from 0001628280-26-005129:notes:320]

[0001628280-26-030777:notes:347]
[same as prior period, unchanged from 0001628280-26-005129:notes:321]

[0001628280-26-030777:notes:348]
| Contract balances |  | Balance sheet location |  | March 28, 2026 |  | June 28, 2025 |  | Change |  | Percentage Change |
| Accounts receivable, net |  | Accounts receivable, net |  | $ | 441.6 |  |  | $ | 250.0 |  |  | $ | 191.6 |  |  | 76.6 | % |
| Deferred revenue and customer deposits (1) |  | Other current liabilities |  | $ | 7.3 |  |  | $ | 0.7 |  |  | $ | 6.6 |  |  | 942.9 | % |
| Deferred revenue and customer deposits (1) |  | Other non-current liabilities |  | $ | 2.2 |  |  | $ | — |  |  | $ | 2.2 |  |  | n/a |

[0001628280-26-030777:notes:349]
(1) We recorded the total $6.9 million of below-market contract liability related to our acquisition of a business in March 2026 in our consolidated balance sheets, wherein about $6.1 million was recorded as other current liabilities and about $0.8 million was recorded as other non-current liabilities, which will be amortized and recorded as revenue over the term of the supply agreement. During the three and nine months ended March 28, 2026, we have recognized approximately $0.4 million of this amount to revenue. Refer to “Note 4. Business Combinations” for details.


## us-gaap:SubsequentEventsTextBlock

[0001628280-26-030777:notes:350]
Note 17. Subsequent Event

[0001628280-26-030777:notes:351]
On April 7, 2026, we entered into privately negotiated exchange agreements with certain holders of our 2026 Notes and 2029 Notes (collectively referred to as the “Exchanged Notes”). The exchange transactions closed in April 2026. Pursuant to these agreements, we issued in aggregate of approximately 5.7 million shares of our common stock in exchange for approximately $474.6 million aggregate principal amounts of the Exchanged Notes and related conversion value in excess of the principal amounts thereof. The Company did not receive any cash proceeds from the exchange transactions. Following the closing of the exchange transactions (after taking into account early conversion requests that have been received, but not yet settled, as of April 30, 2026), approximately $52.0 million aggregate principal amounts of the 2026 Notes and approximately $68.8 million aggregate principal amounts of the 2029 Notes remain outstanding, in each case, with terms unchanged. The Exchanged Notes were canceled upon settlement, and the issuance of common stock in the exchange transactions resulted in incremental dilution of 0.6 million shares of common stock related to the principal amounts.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001628280-26-030777:notes:352]
On February 6, 2026, Brian Lillie, a member of our board of directors, adopted a Rule 10b5-1 trading arrangement providing for the sale from time to time of an aggregate of up to 12,000 shares of our common stock. The trading arrangement is intended to satisfy the affirmative defense in Rule 10b5-1(c). The duration of the trading arrangement is until February 6, 2027, or earlier if all transactions under the trading arrangement are completed.

[0001628280-26-030777:notes:353]
On February 12, 2026, Pamela Fletcher, our director, adopted a Rule 10b5-1 trading arrangement providing for the sale from time to time of an aggregate of up to 3,155 shares of our common stock. The trading arrangement is intended to satisfy the affirmative defense in Rule 10b5-1(c). The duration of the trading arrangement is until February 12, 2027, or earlier if all transactions under the trading arrangement are completed.

[0001628280-26-030777:notes:354]
On February 23, 2026, Paul Lundstrom, a member of our board of directors, adopted a Rule 10b5-1 trading arrangement providing for the sale from time to time of an aggregate of up to 1,000 shares of our common stock. The actual number of shares sold under the trading arrangement will be subject to vesting of the RSUs subject to the trading arrangement. The trading arrangement is intended to satisfy the affirmative defense in Rule 10b5-1(c). The duration of the trading arrangement is until February 23, 2027, or earlier if all transactions under the trading arrangement are completed.

[0001628280-26-030777:notes:355]
On February 26, 2026, Jae Kim, our Senior Vice President, General Counsel and Secretary, adopted a Rule 10b5-1 trading arrangement providing for the sale from time to time of an aggregate of up to 38,594 shares of our common stock (based on PSUs vesting at target). The actual number of shares sold under the trading arrangement will depend on achievement of performance targets applicable to the PSUs subject to the trading arrangement, be subject to vesting of the PSUs and RSUs subject to the trading arrangement, depend on shares acquired through employee stock purchase plan (“ESPP”) subject to the trading arrangement, and be net of shares withheld for taxes upon vesting and settlement of the PSUs, RSUs and ESPP shares subject to the trading arrangement. The trading arrangement is intended to satisfy the affirmative defense in Rule 10b5-1(c). The duration of the trading arrangement is until February 8, 2027, or earlier if all transactions under the trading arrangement are completed.

[0001628280-26-030777:notes:356]
On February 27, 2026, Issac Harris, a member of our board of directors and our Interim Chief Procurement Officer, adopted a Rule 10b5-1 trading arrangement providing for the sale from time to time of an aggregate of up to 5,416 shares of our common stock. The trading arrangement is intended to satisfy the affirmative defense in Rule 10b5-1(c). The duration of the trading arrangement is until February 27, 2027, or earlier if all transactions under the trading arrangement are completed.
