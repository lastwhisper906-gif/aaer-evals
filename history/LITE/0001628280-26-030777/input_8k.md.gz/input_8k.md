# LITE 8-K — 0001628280-26-030530 filed 2026-05-05

## item codes, every 8-K on or before 2026-05-06

- 2026-05-05 0001628280-26-030530 — 2.02, 9.01
- 2026-04-08 0001193125-26-146256 — 3.02
- 2026-03-02 0001193125-26-085412 — 3.02, 5.03, 7.01, 9.01
- 2026-02-03 0001628280-26-005005 — 2.02, 9.01
- 2026-01-05 0001193125-26-002602 — 5.02
- 2025-12-22 0001193125-25-328691 — 1.01, 2.03, 9.01
- 2025-12-15 0001628280-25-057025 — 5.02, 9.01
- 2025-11-24 0001628280-25-053795 — 5.02, 5.07, 9.01
- 2025-11-04 0001628280-25-048860 — 2.02, 9.01
- 2025-09-08 0001193125-25-198329 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2025-08-12 0001628280-25-039896 — 2.02, 9.01
- 2025-06-03 0001628280-25-029086 — 7.01, 9.01
- 2025-05-06 0001628280-25-022709 — 2.02, 9.01
- 2025-02-06 0001628280-25-004265 — 2.02, 9.01
- 2025-02-03 0001193125-25-019371 — 2.02, 5.02, 9.01
- 2024-12-12 0001193125-24-277338 — 5.02, 9.01
- 2024-11-22 0001628280-24-048886 — 5.02, 5.07, 9.01
- 2024-11-07 0001628280-24-046302 — 2.02, 9.01
- 2024-08-21 0001628280-24-037938 — 2.02, 9.01 — amendment of 0001628280-24-037191
- 2024-08-14 0001628280-24-037191 — 2.02, 9.01
- 2024-05-06 0001628280-24-020640 — 2.02, 9.01
- 2024-02-27 0001628280-24-006936 — 5.02
- 2024-02-08 0001628280-24-003789 — 2.02, 9.01
- 2024-01-18 0001628280-24-001551 — 9.01 — amendment of 0001193125-23-272452
- 2023-11-21 0001628280-23-039654 — 5.02, 5.07
- 2023-11-08 0001628280-23-037563 — 2.02, 9.01
- 2023-11-07 0001193125-23-272452 — 2.01, 8.01, 9.01
- 2023-10-30 0001193125-23-265658 — 1.01, 2.02, 9.01
- 2023-08-17 0001628280-23-029741 — 2.02, 9.01
- 2023-06-16 0001193125-23-168966 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2023-05-09 0001628280-23-016629 — 2.02, 9.01
- 2023-04-06 0001628280-23-010935 — 2.02, 8.01, 9.01
- 2023-02-24 0001193125-23-048742 — 5.02, 9.01
- 2023-02-09 0001628280-23-002866 — 2.02, 9.01
- 2022-11-21 0001628280-22-030473 — 5.02, 5.07, 9.01
- 2022-11-08 0001628280-22-028758 — 2.02, 9.01
- 2022-08-16 0001628280-22-022980 — 2.02, 9.01
- 2022-08-03 0001193125-22-210674 — 2.01, 8.01, 9.01
- 2022-07-29 0001193125-22-206587 — 8.01, 9.01
- 2022-05-04 0001628280-22-012145 — 2.02, 9.01
- 2022-03-08 0001193125-22-069350 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2022-02-03 0001628280-22-001736 — 2.02, 9.01
- 2022-01-21 0001193125-22-014413 — 8.01, 9.01
- 2021-11-23 0001628280-21-024070 — 5.02, 5.07
- 2021-11-05 0001193125-21-321796 — 1.01, 9.01
- 2021-11-04 0001628280-21-021618 — 2.02, 9.01
- 2021-11-04 0001193125-21-319601 — 8.01, 9.01
- 2021-08-18 0001628280-21-017219 — 2.02, 9.01
- 2021-06-08 0001633978-21-000030 — 5.02, 9.01
- 2021-05-12 0001633978-21-000008 — 2.02, 9.01
- 2021-03-10 0001193125-21-075438 — 1.01, 8.01, 9.01
- 2021-02-02 0001633978-21-000002 — 2.02, 9.01
- 2021-01-19 0001104659-21-005024 — 1.01, 2.02, 8.01, 9.01
- 2020-11-24 0001193125-20-302557 — 5.02, 5.07
- 2020-11-02 0001633978-20-000017 — 2.02, 9.01
- 2020-09-18 0001633978-20-000012 — 5.02, 9.01
- 2020-08-11 0001633978-20-000010 — 2.02, 9.01
- 2020-05-05 0001628280-20-006358 — 2.02, 9.01
- 2020-02-04 0001633978-20-000002 — 2.02, 9.01
- 2019-12-12 0001193125-19-312875 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2019-12-04 0001633978-19-000075 — 8.01
- 2019-11-20 0001633978-19-000074 — 5.07
- 2019-10-31 0001633978-19-000070 — 2.02, 9.01
- 2019-08-08 0001633978-19-000068 — 2.02, 9.01
- 2019-05-08 0001633978-19-000031 — 1.01
- 2019-05-07 0001633978-19-000029 — 2.02, 9.01
- 2019-02-15 0001633978-19-000005 — 9.01 — amendment of 0001193125-18-346211
- 2019-02-08 0001193125-19-031591 — 5.02, 9.01
- 2019-02-05 0001633978-19-000001 — 2.02, 9.01
- 2018-12-10 0001193125-18-346211 — 1.01, 2.01, 2.03, 5.02, 8.01, 9.01
- 2018-12-06 0001633978-18-000150 — 8.01
- 2018-11-14 0001633978-18-000139 — 5.07
- 2018-11-13 0001633978-18-000136 — 3.02
- 2018-11-13 0001633978-18-000132 — 7.01, 9.01
- 2018-11-01 0001628280-18-013238 — 2.02, 9.01
- 2018-08-08 0001633978-18-000056 — 2.02, 9.01
- 2018-06-08 0001193125-18-188241 — 5.02, 9.01
- 2018-05-02 0001633978-18-000029 — 2.02, 9.01
- 2018-03-12 0001193125-18-078154 — 1.01, 2.01, 8.01, 9.01
- 2018-02-06 0001628280-18-001082 — 2.02, 9.01
- 2017-11-08 0001633978-17-000133 — 5.02, 9.01
- 2017-11-07 0001633978-17-000131 — 5.07
- 2017-11-01 0001633978-17-000117 — 2.02, 9.01
- 2017-08-09 0001633978-17-000058 — 2.02, 9.01
- 2017-05-04 0001633978-17-000035 — 2.02, 9.01
- 2017-03-08 0001193125-17-074740 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2017-03-02 0001193125-17-066769 — 8.01, 9.01
- 2017-02-07 0001633978-17-000005 — 2.02, 9.01
- 2017-01-03 0001628280-17-000018 — 4.01, 9.01
- 2016-11-09 0001628280-16-021143 — 5.02, 5.07, 9.01
- 2016-10-27 0001628280-16-020382 — 2.02, 9.01
- 2016-08-09 0001628280-16-018811 — 2.02, 9.01
- 2016-06-21 0001628280-16-017201 — 8.01
- 2016-05-04 0001628280-16-015501 — 2.02, 9.01
- 2016-02-16 0001628280-16-011261 — 5.02, 9.01
- 2016-02-04 0001628280-16-010758 — 5.02, 9.01
- 2016-02-04 0001628280-16-010755 — 2.02, 9.01
- 2015-11-17 0001193125-15-378953 — 7.01
- 2015-11-10 0001628280-15-008606 — 2.02, 9.01
- 2015-09-28 0001193125-15-329665 — 8.01, 9.01
- 2015-08-11 0001193125-15-286405 — 7.01, 9.01
- 2015-08-06 0001193125-15-281219 — 1.01, 5.02, 5.03, 5.05, 8.01, 9.01
- 2015-08-03 0001193125-15-274808 — 5.03, 9.01

## late-filing notifications on or before 2026-05-06

- 2015-11-10 0001628280-15-008612 — NT 10-Q, for the period ended 2015-09-26
- 2015-09-28 0001193125-15-329672 — NT 10-K, for the period ended 2015-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001628280-26-030530:8k_2_02:1]
EX-99.1
2
lite_ex991xq3fy26.htm
EX-99.1

[0001628280-26-030530:8k_2_02:2]
Document

[0001628280-26-030530:8k_2_02:3]
NEWS RELEASE

[0001628280-26-030530:8k_2_02:4]
LUMENTUM ANNOUNCES THIRD QUARTER OF FISCAL YEAR 2026 FINANCIAL RESULTS

[0001628280-26-030530:8k_2_02:5]
•Net revenue of $808.4 million

[0001628280-26-030530:8k_2_02:6]
•GAAP gross margin of 44.2%; Non-GAAP gross margin of 47.9%

[0001628280-26-030530:8k_2_02:7]
•GAAP operating margin of 21.6%; Non-GAAP operating margin of 32.2%

[0001628280-26-030530:8k_2_02:8]
•GAAP diluted net income per share of $1.50; Non-GAAP diluted net income per share of $2.37

[0001628280-26-030530:8k_2_02:9]
San Jose, Calif., May 5, 2026 – Lumentum Holdings Inc. (“Lumentum” or the “Company”) today reported results for its fiscal third quarter ended March 28, 2026.

[0001628280-26-030530:8k_2_02:10]
“Lumentum delivered an exceptional third quarter, with revenue growing 90% year over year to a record $808 million. While our top line growth continues to garner headlines, the more impressive part of our recent performance has been our margin expansion. In fiscal Q3, gross margin improved by 540 basis points on quarter and operating margin by 700 basis points,” said President and CEO Michael Hurlston.

[0001628280-26-030530:8k_2_02:11]
“Margin improvement has been driven by many factors including operational rigor, pricing discipline, and product mix. This quarter, mix was aided by strength in laser chips, but also by a less-heralded part of our portfolio, ‘scale-across’ components, which include our pump lasers and narrow linewidth laser assemblies. As our key growth drivers of co-packaged optics and optical circuit switches begin to kick in, we would expect further increases in earnings power.”

[0001628280-26-030530:8k_2_02:12]
Fiscal Third Quarter Highlights:

[0001628280-26-030530:8k_2_02:13]
Net revenue for the third quarter of fiscal year 2026 was $808.4 million, with GAAP net income of $144.2 million, or $1.50 per diluted share. Net revenue for the second quarter of fiscal year 2026 was 665.5 million, with GAAP net income of $78.2 million, or $0.89 per diluted share. Net revenue for the third quarter of fiscal year 2025 was 425.2 million, with GAAP net loss of $44.1 million, or $0.64 per diluted share.

[0001628280-26-030530:8k_2_02:14]
Non-GAAP net income for the third quarter of fiscal year 2026 was $225.7 million, or $2.37 per diluted share. Non-GAAP net income for the second quarter of fiscal year 2026 was $143.9 million, or $1.67 per diluted share. Non-GAAP net income for the third quarter of fiscal year 2025 was $40.9 million, or $0.57 per diluted share.

[0001628280-26-030530:8k_2_02:15]
The Company held $3,172.3 million in total cash, cash equivalents, and short-term investments at the end of the third quarter of fiscal year 2026, up $2,017.0 million from the end of the second quarter of fiscal year 2026 primarily due to the proceeds from the issuance of Series A Convertible Preferred Stock in March 2026.

[0001628280-26-030530:8k_2_02:16]
Financial Overview – Fiscal Third Quarter Ended March 28, 2026

[0001628280-26-030530:8k_2_02:17]
|  | GAAP Results ($ in millions) |
|  | Q3 |  | Q2 |  | Q3 |  | Change |
|  | FY 2026 |  | FY 2026 |  | FY 2025 |  | Q/Q |  | Y/Y |
| Net revenue | $ | 808.4 |  |  | $ | 665.5 |  |  | $ | 425.2 |  |  | 21.5% |  | 90.1% |
| GAAP gross margin | 44.2 | % |  | 36.1 | % |  | 28.8 | % |  | 810 | bps |  | 1,540 | bps |
| GAAP operating margin (loss) | 21.6 | % |  | 9.7 | % |  | (8.9) | % |  | 1,190 | bps |  | 3,050 | bps |
|  | Non-GAAP Results ($ in millions) |
|  | Q3 |  | Q2 |  | Q3 |  | Change |
|  | FY 2026 |  | FY 2026 |  | FY 2025 |  | Q/Q |  | Y/Y |
| Net revenue | $ | 808.4 |  |  | $ | 665.5 |  |  | $ | 425.2 |  |  | 21.5% |  | 90.1% |
| Non-GAAP gross margin | 47.9 | % |  | 42.5 | % |  | 35.2 | % |  | 540 | bps |  | 1,270 | bps |
| Non-GAAP operating margin | 32.2 | % |  | 25.2 | % |  | 10.8 | % |  | 700 | bps |  | 2,140 | bps |

[0001628280-26-030530:8k_2_02:18]
|  | Net Revenue by Product Type ($ in millions) |  |  |  |  |
|  | Q3 |  | % of |  | Q2 |  | Q3 |  | Change |  |  |  |  |
|  | FY 2026 |  | Net Revenue |  | FY 2026 |  | FY 2025 |  | Q/Q |  | Y/Y |  |  |  |  |
| Components | $ | 533.3 |  |  | 66.0 | % |  | $ | 443.7 |  |  | $ | 300.8 |  |  | 20.2% |  | 77.3% |  |  |  |  |
| Systems | 275.1 |  |  | 34.0 | % |  | 221.8 |  |  | 124.4 |  |  | 24.0% |  | 121.1% |  |  |  |  |
| Total | $ | 808.4 |  |  | 100.0 | % |  | $ | 665.5 |  |  | $ | 425.2 |  |  | 21.5% |  | 90.1% |  |  |  |  |

[0001628280-26-030530:8k_2_02:19]
The tables above provide comparisons of quarterly results to prior periods, including sequential quarterly and year-over-year changes. A reconciliation between GAAP and non-GAAP measures is contained in this release under the section titled “Use of Non-GAAP Financial Measures.”

[0001628280-26-030530:8k_2_02:20]
Business Outlook

[0001628280-26-030530:8k_2_02:21]
Lumentum expects the following for the fourth quarter of fiscal year 2026:

[0001628280-26-030530:8k_2_02:22]
•Net revenue in the range of $960 million to $1.01 billion

[0001628280-26-030530:8k_2_02:23]
•Non-GAAP operating margin of 35.0% to 36.0%

[0001628280-26-030530:8k_2_02:24]
•Non-GAAP diluted earnings per share of $2.85 to $3.05

[0001628280-26-030530:8k_2_02:25]
We have not provided reconciliations from GAAP to non-GAAP financial measures or the equivalent GAAP measure for non-GAAP financial measures in our outlook, as they cannot be provided without unreasonable effort. A large portion of non-GAAP adjustments, such as stock-based compensation and related payroll expenses, acquisition related costs, net, integration related costs, restructuring and related charges (reversals), non-GAAP income tax reconciling adjustments, and other non-GAAP adjustments are by their nature highly volatile and we have low visibility as to the range that may be incurred in the future.

[0001628280-26-030530:8k_2_02:26]
Related Announcement and Conference Call

[0001628280-26-030530:8k_2_02:27]
Lumentum will host a conference call today, May 5, 2026, at 2:00 pm PT / 5:00 pm ET to discuss its third quarter of fiscal year 2026 results. A live webcast of the call and replay will be available in the Investors section of the Lumentum website at http://investor.lumentum.com. The earnings press release will be posted at http://investor.lumentum.com under the “News Releases” section. Supporting materials outlining the Company’s latest financial results will be posted on http://investor.lumentum.com under the “Events” section concurrently with this earnings press release. Lumentum has used, and intends to continue to use, its Investor Relations website as means of disclosing material nonpublic information and for complying with its disclosure obligations under Regulation FD. This press release is being furnished as an exhibit to a Current Report on Form 8-K filed with the Securities and Exchange Commission and will be available at http://www.sec.gov/.

[0001628280-26-030530:8k_2_02:28]
About Lumentum

[0001628280-26-030530:8k_2_02:29]
Lumentum (NASDAQ: LITE) is a global leader in optical and photonic technologies that power the networks and infrastructure behind AI, cloud computing, and next-generation communications. Built on decades of photonics innovation, Lumentum delivers high-performance lasers, modules, and optical subsystems that enable scalable, energy-efficient data center connectivity, advanced telecom networks, industrial manufacturing, and sensing applications. Headquartered in San Jose, California, the company operates R&D, manufacturing, and sales facilities worldwide. Learn more at www.lumentum.com.

[0001628280-26-030530:8k_2_02:30]
Forward-Looking Statements

[0001628280-26-030530:8k_2_02:31]
Contact Information

[0001628280-26-030530:8k_2_02:32]
Investors:    Kathy Ta, +1.408.750.3853; investor.relations@lumentum.com

[0001628280-26-030530:8k_2_02:33]
Media:        Victoria McDonald, +408.404.0636; media@lumentum.com

[0001628280-26-030530:8k_2_02:34]
Category:    Financial

[0001628280-26-030530:8k_2_02:35]
The following financial tables are presented in accordance with GAAP, unless otherwise specified.

[0001628280-26-030530:8k_2_02:36]
LUMENTUM HOLDINGS INC.

[0001628280-26-030530:8k_2_02:37]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001628280-26-030530:8k_2_02:38]
(in millions, except per share data)

[0001628280-26-030530:8k_2_02:39]
(unaudited)

[0001628280-26-030530:8k_2_02:40]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 28, 2026 |  | March 29, 2025 |  | March 28, 2026 |  | March 29, 2025 |
| Net revenue | $ | 808.4 |  |  | $ | 425.2 |  |  | $ | 2,007.7 |  |  | $ | 1,164.3 |  |
| Cost of sales | 432.1 |  |  | 283.7 |  |  | 1,170.7 |  |  | 801.4 |  |
| Amortization of acquired developed intangibles | 19.3 |  |  | 19.0 |  |  | 58.4 |  |  | 62.9 |  |
| Gross profit | 357.0 |  |  | 122.5 |  |  | 778.6 |  |  | 300.0 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 90.6 |  |  | 75.9 |  |  | 252.1 |  |  | 224.4 |  |
| Selling, general and administrative | 90.8 |  |  | 112.0 |  |  | 272.0 |  |  | 264.6 |  |
| Restructuring and related charges | 1.1 |  |  | 7.2 |  |  | 9.0 |  |  | 17.6 |  |
| Gain on sale of facility | — |  |  | (34.9) |  |  | — |  |  | (34.9) |  |
| Total operating expenses | 182.5 |  |  | 160.2 |  |  | 533.1 |  |  | 471.7 |  |
| Income (loss) from operations | 174.5 |  |  | (37.7) |  |  | 245.5 |  |  | (171.7) |  |
| Escrow settlement | — |  |  | — |  |  | 27.5 |  |  | — |  |
| Interest expense | (6.2) |  |  | (5.7) |  |  | (18.2) |  |  | (16.8) |  |
| Other income, net | 15.5 |  |  | 4.2 |  |  | 30.7 |  |  | 27.8 |  |
| Total other income (expense), net | 9.3 |  |  | (1.5) |  |  | 40.0 |  |  | 11.0 |  |
| Income (loss) before income taxes | 183.8 |  |  | (39.2) |  |  | 285.5 |  |  | (160.7) |  |
| Income tax provision | 39.6 |  |  | 4.9 |  |  | 58.9 |  |  | 26.7 |  |
| Net income (loss) | 144.2 |  |  | (44.1) |  |  | 226.6 |  |  | (187.4) |  |
| Income allocated to participating securities | (1.7) |  |  | — |  |  | (0.9) |  |  | — |  |
| Net income (loss) available to common shareholders | $ | 142.5 |  |  | $ | (44.1) |  |  | $ | 225.7 |  |  | $ | (187.4) |  |
| Net income (loss) per common share: |  |  |  |  |  |  |  |
| Basic | $ | 1.99 |  |  | $ | (0.64) |  |  | $ | 3.18 |  |  | $ | (2.72) |  |
| Diluted | $ | 1.50 |  |  | $ | (0.64) |  |  | $ | 2.59 |  |  | $ | (2.72) |  |
| Shares used to compute net income (loss) per common share: |  |  |  |  |  |  |  |
| Basic | 71.5 |  |  | 69.3 |  |  | 71.0 |  |  | 68.8 |  |
| Diluted | 96.2 |  |  | 69.3 |  |  | 87.4 |  |  | 68.8 |  |

[0001628280-26-030530:8k_2_02:41]
LUMENTUM HOLDINGS INC.

[0001628280-26-030530:8k_2_02:42]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001628280-26-030530:8k_2_02:43]
(in millions, except per share data)

[0001628280-26-030530:8k_2_02:44]
(unaudited)

[0001628280-26-030530:8k_2_02:45]
|  | March 28, 2026 |  | June 28, 2025 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 2,617.8 |  |  | $ | 520.7 |  |
| Short-term investments | 554.5 |  |  | 356.4 |  |
| Accounts receivable, net | 441.6 |  |  | 250.0 |  |
| Inventories | 632.8 |  |  | 470.1 |  |
| Prepayments and other current assets | 149.0 |  |  | 120.1 |  |
| Total current assets | 4,395.7 |  |  | 1,717.3 |  |
| Property, plant and equipment, net | 964.3 |  |  | 726.4 |  |
| Operating lease right-of-use assets, net | 27.0 |  |  | 27.9 |  |
| Goodwill | 1,066.3 |  |  | 1,060.9 |  |
| Other intangible assets, net | 362.9 |  |  | 465.1 |  |
| Deferred tax asset | 197.9 |  |  | 210.3 |  |
| Other non-current assets | 13.8 |  |  | 10.8 |  |
| Total assets | $ | 7,027.9 |  |  | $ | 4,218.7 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 392.7 |  |  | $ | 225.2 |  |
| Accrued payroll and related expenses | 109.7 |  |  | 57.9 |  |
| Accrued expenses | 48.9 |  |  | 34.6 |  |
| Current portion of long-term debt | 3,238.6 |  |  | 10.6 |  |
| Operating lease liabilities, current | 12.5 |  |  | 11.4 |  |
| Other current liabilities | 62.9 |  |  | 53.1 |  |
| Total current liabilities | 3,865.3 |  |  | 392.8 |  |
| Long-term debt | 43.2 |  |  | 2,562.6 |  |
| Operating lease liabilities, non-current | 19.4 |  |  | 23.6 |  |
| Deferred tax liability | 5.4 |  |  | 7.2 |  |
| Other non-current liabilities | 121.2 |  |  | 97.8 |  |
| Total liabilities | 4,054.5 |  |  | 3,084.0 |  |
| Commitments and contingencies |  |  |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock, $0.001 par value, 10 authorized shares, 2.9 shares and zero shares issued and outstanding as of March 28, 2026 and June 28, 2025, respectively | — |  |  | — |  |
| Common stock, $0.001 par value, 990 authorized shares, 71.7 shares and 69.8 shares issued and outstanding as of March 28, 2026 and June 28, 2025, respectively | 0.1 |  |  | 0.1 |  |
| Additional paid-in capital | 3,600.9 |  |  | 1,986.8 |  |
| Accumulated deficit | (634.6) |  |  | (861.2) |  |
| Accumulated other comprehensive income | 7.0 |  |  | 9.0 |  |
| Total stockholders’ equity | 2,973.4 |  |  | 1,134.7 |  |
| Total liabilities and stockholders’ equity | $ | 7,027.9 |  |  | $ | 4,218.7 |  |

[0001628280-26-030530:8k_2_02:46]
Use of Non-GAAP Financial Measures

[0001628280-26-030530:8k_2_02:47]
In this press release, Lumentum provides investors with certain non-GAAP financial measures: gross profit, gross margin, research and development expense, selling, general and administrative expense, operating margin, income (loss) from operations, other income (expense), net, income before income taxes, provision for income taxes, net income (loss), shares used in per share calculation, and net income (loss) per share on a non-GAAP basis, as well as the non-GAAP measures of EBITDA and Adjusted EBITDA. Lumentum believes this non-GAAP financial information provides additional insight into the Company’s on-going business operations and results, and has therefore chosen to provide this information to investors for a more consistent basis of comparison and to help them evaluate the results of the Company’s on-going operations and enable more meaningful period to period comparisons. In addition, the Company believes that providing certain of these measures allows investors to better understand the Company’s operating performance and, importantly, to evaluate the methodology and information used by management to monitor, manage, evaluate and measure the Company’s business and results of operations. However, investors are cautioned that there are material limitations associated with the use of non-GAAP financial measures as an analytical tool. In particular, many of the adjustments to our GAAP financial measures reflect the exclusion of items that are recurring and will be reflected in our financial results for the foreseeable future. Moreover, the non-GAAP financial measures we present may be different from non-GAAP financial measures used by other companies or may not be comparable to similarly titled measurements reported by other companies, limiting their usefulness for comparison purposes. We do not consider non-GAAP financial measures to be a substitute for, or superior to, the information provided by GAAP financial measures, and the non-GAAP financial measures used in this press release should not be considered in isolation from measures of financial performance prepared in accordance with GAAP.

[0001628280-26-030530:8k_2_02:48]
Our non-GAAP measures used in this press release exclude (i) stock-based compensation and related payroll taxes, (ii) acquisition related costs, net (iii) integration related costs, (iv) amortization of acquired intangibles, (v) restructuring and related charges (reversals), (vi) intangible assets write-off, (vii) gain on sale of facility, (viii) escrow settlement, (ix) acquisition-related warranty provision, (x) inducement expense, (xi) foreign exchange (gains) losses, net, (xii) non-cash interest expense, (xiii) non-GAAP income tax reconciling adjustments, and (xiv) other charges or income related to non-recurring activities.

[0001628280-26-030530:8k_2_02:49]
We utilize a long-term projected non-GAAP tax rate to compute our non-GAAP income tax provision. The long-term projected non-GAAP tax rate is based on a multi-year projection of our estimated annual GAAP income tax forecast, adjusted to account for the tax effect of non-GAAP pretax adjustments as well as the effects of significant non-recurring and period specific tax items. Our non-GAAP tax provision for fiscal year 2026 is 16.5%. The difference between our GAAP income tax provision and our non-GAAP income tax provision is presented as non-GAAP income tax reconciling adjustments.

[0001628280-26-030530:8k_2_02:50]
A quantitative reconciliation between GAAP and non-GAAP financial data is included in the supplemental financial table attached to this press release.

[0001628280-26-030530:8k_2_02:51]
LUMENTUM HOLDINGS INC.

[0001628280-26-030530:8k_2_02:52]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001628280-26-030530:8k_2_02:53]
(in millions, except per share data)

[0001628280-26-030530:8k_2_02:54]
(unaudited)

[0001628280-26-030530:8k_2_02:55]
|  | Three Months Ended |  | Nine Months Ended |  |
|  | March 28, 2026 |  | December 27, 2025 |  | March 29, 2025 |  | March 28, 2026 |  | March 29, 2025 |  |
| Gross profit on GAAP basis | $ | 357.0 |  |  | $ | 240.1 |  |  | $ | 122.5 |  |  | $ | 778.6 |  |  | $ | 300.0 |  |  |
| Stock-based compensation and related payroll taxes (1) | 10.5 |  |  | 13.3 |  |  | 9.2 |  |  | 33.5 |  |  | 28.1 |  |  |
| Amortization of acquired intangibles | 19.3 |  |  | 19.6 |  |  | 19.0 |  |  | 58.4 |  |  | 62.9 |  |  |
| Integration related costs | 0.2 |  |  | — |  |  | — |  |  | 0.2 |  |  | 2.3 |  |  |
| Acquisition-related warranty provision (4) | — |  |  | 9.8 |  |  | — |  |  | 9.8 |  |  | — |  |  |
| Other income, net | (0.1) |  |  | (0.2) |  |  | (1.2) |  |  | (0.7) |  |  | (3.4) |  |  |
| Gross profit on non-GAAP basis | $ | 386.9 |  |  | $ | 282.6 |  |  | $ | 149.5 |  |  | $ | 879.8 |  |  | $ | 389.9 |  |  |
| Gross margin on non-GAAP basis | 47.9 | % |  | 42.5 | % |  | 35.2 | % |  | 43.8 | % |  | 33.5 | % |  |
| Research and development on GAAP basis | $ | 90.6 |  |  | $ | 80.1 |  |  | $ | 75.9 |  |  | $ | 252.1 |  |  | $ | 224.4 |  |  |
| Stock-based compensation and related payroll taxes (1) | (11.5) |  |  | (9.8) |  |  | (11.2) |  |  | (33.3) |  |  | (31.9) |  |  |
| Amortization of acquired intangibles | (0.5) |  |  | (0.4) |  |  | (0.4) |  |  | (1.3) |  |  | (1.2) |  |  |
| Integration related costs | (0.2) |  |  | — |  |  | (0.3) |  |  | (0.2) |  |  | (0.3) |  |  |
| Intangible assets write-off | — |  |  | — |  |  | (0.7) |  |  | — |  |  | (2.6) |  |  |
| Research and development on non-GAAP basis | $ | 78.4 |  |  | $ | 69.9 |  |  | $ | 63.3 |  |  | $ | 217.3 |  |  | $ | 188.4 |  |  |
| Selling, general and administrative on GAAP basis | $ | 90.8 |  |  | $ | 96.1 |  |  | $ | 112.0 |  |  | $ | 272.0 |  |  | $ | 264.6 |  |  |
| Stock-based compensation and related payroll taxes (1) | (24.8) |  |  | (24.8) |  |  | (42.4) |  |  | (74.4) |  |  | (77.2) |  |  |
| Amortization of acquired intangibles | (14.0) |  |  | (14.0) |  |  | (15.0) |  |  | (42.5) |  |  | (51.0) |  |  |
| Acquisition related costs (2) | (0.4) |  |  | (0.4) |  |  | (0.5) |  |  | (2.1) |  |  | (0.5) |  |  |
| Integration related costs | (1.0) |  |  | (1.3) |  |  | (1.1) |  |  | (1.5) |  |  | (5.3) |  |  |
| Other charges, net (6) | (2.8) |  |  | (10.6) |  |  | (12.9) |  |  | (17.2) |  |  | (16.9) |  |  |
| Selling, general and administrative on non-GAAP basis | $ | 47.8 |  |  | $ | 45.0 |  |  | $ | 40.1 |  |  | $ | 134.3 |  |  | $ | 113.7 |  |  |
| Income (loss) from operations on GAAP basis | $ | 174.5 |  |  | $ | 64.3 |  |  | $ | (37.7) |  |  | $ | 245.5 |  |  | $ | (171.7) |  |  |
| Stock-based compensation and related payroll taxes (1) | 46.8 |  |  | 47.9 |  |  | 62.8 |  |  | 141.2 |  |  | 137.2 |  |  |
| Amortization of acquired intangibles | 33.8 |  |  | 34.0 |  |  | 34.4 |  |  | 102.2 |  |  | 115.1 |  |  |
| Acquisition related costs (2) | 0.4 |  |  | 0.4 |  |  | 0.5 |  |  | 2.1 |  |  | 0.5 |  |  |
| Integration related costs | 1.4 |  |  | 1.3 |  |  | 1.4 |  |  | 1.9 |  |  | 7.9 |  |  |
| Restructuring and related charges (reversals) (3) | 1.1 |  |  | (0.4) |  |  | 7.2 |  |  | 9.0 |  |  | 17.6 |  |  |
| Intangible assets write-off | — |  |  | — |  |  | 0.7 |  |  | — |  |  | 2.6 |  |  |
| Acquisition-related warranty provision (4) | — |  |  | 9.8 |  |  | — |  |  | 9.8 |  |  | — |  |  |
| Gain on sale of facility (4) | — |  |  | — |  |  | (34.9) |  |  | — |  |  | (34.9) |  |  |
| Other charges, net (6) | 2.7 |  |  | 10.4 |  |  | 11.7 |  |  | 16.5 |  |  | 13.5 |  |  |
| Income from operations on non-GAAP basis | $ | 260.7 |  |  | $ | 167.7 |  |  | $ | 46.1 |  |  | $ | 528.2 |  |  | $ | 87.8 |  |  |
| Operating margin on non-GAAP basis | 32.2 | % |  | 25.2 | % |  | 10.8 | % |  | 26.3 | % |  | 7.5 | % |  |
| Total other income (expense), net on GAAP basis | $ | 9.3 |  |  | $ | 32.2 |  |  | $ | (1.5) |  |  | $ | 40.0 |  |  | $ | 11.0 |  |  |
| Acquisition related income (2) | — |  |  | (1.8) |  |  | — |  |  | (1.8) |  |  | — |  |  |

[0001628280-26-030530:8k_2_02:56]
| Escrow settlement (4) | — |  |  | (27.5) |  |  | — |  |  | (27.5) |  |  | — |  |  |
| Inducement expense (5) | — |  |  | — |  |  | — |  |  | 5.9 |  |  | — |  |  |
| Foreign exchange (gains) losses, net | (0.8) |  |  | 0.6 |  |  | 3.6 |  |  | (1.7) |  |  | (1.6) |  |  |
| Non-cash interest expense | 1.1 |  |  | 1.1 |  |  | 0.8 |  |  | 3.0 |  |  | 2.3 |  |  |
| Total other income, net on non-GAAP basis | $ | 9.6 |  |  | $ | 4.6 |  |  | $ | 2.9 |  |  | $ | 17.9 |  |  | $ | 11.7 |  |  |
| Income (loss) before income taxes on GAAP basis | $ | 183.8 |  |  | $ | 96.5 |  |  | $ | (39.2) |  |  | $ | 285.5 |  |  | $ | (160.7) |  |  |
| Stock-based compensation and related payroll taxes (1) | 46.8 |  |  | 47.9 |  |  | 62.8 |  |  | 141.2 |  |  | 137.2 |  |  |
| Acquisition related costs, net (2) | 0.4 |  |  | (1.4) |  |  | 0.5 |  |  | 0.3 |  |  | 0.5 |  |  |
| Integration related costs | 1.4 |  |  | 1.3 |  |  | 1.4 |  |  | 1.9 |  |  | 7.9 |  |  |
| Amortization of acquired intangibles | 33.8 |  |  | 34.0 |  |  | 34.4 |  |  | 102.2 |  |  | 115.1 |  |  |
| Restructuring and related charges (reversals) (3) | 1.1 |  |  | (0.4) |  |  | 7.2 |  |  | 9.0 |  |  | 17.6 |  |  |
| Escrow settlement (4) | — |  |  | (27.5) |  |  | — |  |  | (27.5) |  |  | — |  |  |
| Acquisition-related warranty provision (4) | — |  |  | 9.8 |  |  | — |  |  | 9.8 |  |  | — |  |  |
| Gain on sale of facility (4) | — |  |  | — |  |  | (34.9) |  |  | — |  |  | (34.9) |  |  |
| Inducement expense (5) | — |  |  | — |  |  | — |  |  | 5.9 |  |  | — |  |  |
| Intangible assets write-off | — |  |  | — |  |  | 0.7 |  |  | — |  |  | 2.6 |  |  |
| Foreign exchange (gains) losses, net | (0.8) |  |  | 0.6 |  |  | 3.6 |  |  | (1.7) |  |  | (1.6) |  |  |
| Non-cash interest expense | 1.1 |  |  | 1.1 |  |  | 0.8 |  |  | 3.0 |  |  | 2.3 |  |  |
| Other charges, net (6) | 2.7 |  |  | 10.4 |  |  | 11.7 |  |  | 16.5 |  |  | 13.5 |  |  |
| Income before income taxes on non-GAAP basis | $ | 270.3 |  |  | $ | 172.3 |  |  | $ | 49.0 |  |  | $ | 546.1 |  |  | $ | 99.5 |  |  |
| Income tax provision on GAAP basis | $ | 39.6 |  |  | $ | 18.3 |  |  | $ | 4.9 |  |  | $ | 58.9 |  |  | $ | 26.7 |  |  |
| Non-GAAP income tax reconciling adjustments | 5.0 |  |  | 10.1 |  |  | 3.2 |  |  | 31.2 |  |  | (10.3) |  |  |
| Income tax provision on non-GAAP basis | $ | 44.6 |  |  | $ | 28.4 |  |  | $ | 8.1 |  |  | $ | 90.1 |  |  | $ | 16.4 |  |  |
| Net income (loss) on GAAP basis | $ | 144.2 |  |  | $ | 78.2 |  |  | $ | (44.1) |  |  | $ | 226.6 |  |  | $ | (187.4) |  |  |
| Stock-based compensation and related payroll taxes (1) | 46.8 |  |  | 47.9 |  |  | 62.8 |  |  | 141.2 |  |  | 137.2 |  |  |
| Acquisition related costs, net (2) | 0.4 |  |  | (1.4) |  |  | 0.5 |  |  | 0.3 |  |  | 0.5 |  |  |
| Integration related costs | 1.4 |  |  | 1.3 |  |  | 1.4 |  |  | 1.9 |  |  | 7.9 |  |  |
| Amortization of acquired intangibles | 33.8 |  |  | 34.0 |  |  | 34.4 |  |  | 102.2 |  |  | 115.1 |  |  |
| Restructuring and related charges (reversals) (3) | 1.1 |  |  | (0.4) |  |  | 7.2 |  |  | 9.0 |  |  | 17.6 |  |  |
| Intangible assets write-off | — |  |  | — |  |  | 0.7 |  |  | — |  |  | 2.6 |  |  |
| Gain on sale of facility (4) | — |  |  | — |  |  | (34.9) |  |  | — |  |  | (34.9) |  |  |
| Escrow settlement (4) | — |  |  | (27.5) |  |  | — |  |  | (27.5) |  |  | — |  |  |
| Acquisition-related warranty provision (4) | — |  |  | 9.8 |  |  | — |  |  | 9.8 |  |  | — |  |  |
| Inducement expense (5) | — |  |  | — |  |  | — |  |  | 5.9 |  |  | — |  |  |
| Foreign exchange (gains) losses, net | (0.8) |  |  | 0.6 |  |  | 3.6 |  |  | (1.7) |  |  | (1.6) |  |  |
| Non-cash interest expense | 1.1 |  |  | 1.1 |  |  | 0.8 |  |  | 3.0 |  |  | 2.3 |  |  |
| Non-GAAP income tax reconciling adjustments | (5.0) |  |  | (10.1) |  |  | (3.2) |  |  | (31.2) |  |  | 10.3 |  |  |
| Other charges, net (6) | 2.7 |  |  | 10.4 |  |  | 11.7 |  |  | 16.5 |  |  | 13.5 |  |  |
| Net income on non-GAAP basis | $ | 225.7 |  |  | $ | 143.9 |  |  | $ | 40.9 |  |  | $ | 456.0 |  |  | $ | 83.1 |  |  |
| Net income per share on non-GAAP basis | $ | 2.37 |  |  | $ | 1.67 |  |  | $ | 0.57 |  |  | $ | 5.27 |  |  | $ | 1.17 |  |  |
| Shares used in per share calculation - diluted on GAAP basis | 96.2 |  |  | 87.8 |  |  | 69.3 |  |  | 87.4 |  |  | 68.8 |  |  |

[0001628280-26-030530:8k_2_02:57]
| Non-GAAP adjustment (7) | (1.0) |  |  | (1.7) |  |  | 2.9 |  |  | (0.9) |  |  | 2.1 |  |  |
| Shares used in per share calculation - diluted on non-GAAP basis | 95.2 |  |  | 86.1 |  |  | 72.2 |  |  | 86.5 |  |  | 70.9 |  |  |

[0001628280-26-030530:8k_2_02:58]
(1) Stock-based compensation and related payroll taxes for the three and nine months ended March 28, 2026 includes $5.2 million and $11.8 million of payroll taxes on stock-based compensation, respectively.

[0001628280-26-030530:8k_2_02:59]
(2) Acquisition related costs, net for the three months ended March 28, 2026 represent $0.4 million of legal expenses and other professional fees incurred related to an acquisition of a business in March 2026 in selling, general and administrative expenses.

[0001628280-26-030530:8k_2_02:60]
Acquisition related costs, net for the nine months ended March 28, 2026 represent legal expenses incurred related to Cloud Light escrow settlement of $1.7 million and $0.4 million of legal expenses and other professional fees incurred related to an acquisition of a business in March 2026 in selling, general and administrative expenses offset by $1.8 million of interest income from the Cloud Light escrow fund in other income, net.

[0001628280-26-030530:8k_2_02:61]
(3) During the three and nine months ended March 28, 2026, we recorded restructuring and related charges of  $1.1 million and $9.0 million, respectively, primarily related to a reduction in force during the period in order to enhance operational efficiency and realign our investments toward the most critical initiatives.

[0001628280-26-030530:8k_2_02:62]
(4) During the nine months ended March 28, 2026, we completed the settlement process with the sellers on the escrow agreement for the acquisition of Cloud Light. We believe the completion of this settlement represents a non-recurring activity as it relates directly to an acquisition. The settlement of $27.5 million, recorded in escrow settlement, for the nine months ended March 28, 2026 represents the mutually agreed escrow settlement associated with indemnification obligations and working capital adjustments, including warranty adjustments, under the Cloud Light Merger agreement. Acquisition-related warranty provision relates to  $9.8 million of warranty expense associated with Cloud Light’s legacy products is recorded in cost of sales. As the measurement period for U.S. GAAP expired, these amounts were all included in our condensed consolidated results of operations on a GAAP basis as no further adjustments to the purchase consideration of Cloud Light can be made. Therefore, for non-GAAP reporting purposes, we have removed the net benefit of $17.7 million for the nine months ended March 28, 2026.

[0001628280-26-030530:8k_2_02:63]
(5) Inducement expense on the partial repurchase of our 2026 Notes for the nine months ended March 28, 2026 represents the excess of fair value of the total consideration over the fair value of securities issuable pursuant to the original conversion terms.

[0001628280-26-030530:8k_2_02:64]
(6) Other charges, net for the three months ended March 28, 2026 mostly relates to $2.5 million of legal fees primarily related to non-ordinary course legal matters in selling and general and administrative expenses.

[0001628280-26-030530:8k_2_02:65]
Other charges, net for the nine months ended March 28, 2026 mainly includes legal fees of $9.0 million primarily related to non-ordinary course legal matters and an impairment charge of $7.7 million to write-down assets held for sale to fair value less cost to sell in selling, general and administrative expenses.

[0001628280-26-030530:8k_2_02:66]
(7) The adjustment for the three and nine months ended March 28, 2026 represents the impact of the capped call options. Our outstanding capped call options are anti-dilutive as they are specifically designed to mitigate the dilutive impact of the 2032 Notes, such that no dilution will occur until the capped call price is exceeded. Therefore, we  included the 1.0 million and 0.9 million shares anti-dilutive impact of the capped call from the calculation of non-GAAP diluted shares in the three and nine months ended March 28, 2026 to provide investors with useful information in evaluating our performance on a per share basis.

[0001628280-26-030530:8k_2_02:67]
We calculate basic earnings (loss) per common share pursuant to the two-class method as a result of the issuance of the Series A Convertible Preferred Stock (the “Preferred Stock”) in March 2026. The Preferred Stock is entitled to receive dividends on an as-converted basis in the same manner as holders of common stock and is therefore considered a participating security. As the Preferred Stock participates on an as-converted basis, earnings are allocated pro rata based on the total number of common shares outstanding and the as-converted shares of Preferred Stock.

[0001628280-26-030530:8k_2_02:68]
Diluted earnings (loss) per common share is calculated using the more dilutive of the two-class method or if-converted method. The Company applies the if-converted method, under which the Preferred Stock is assumed to have been converted into common stock at the date of issuance, and the related shares are included in diluted weighted-average shares outstanding.

[0001628280-26-030530:8k_2_02:69]
LUMENTUM HOLDINGS INC.

[0001628280-26-030530:8k_2_02:70]
RECONCILIATION OF GAAP NET INCOME TO ADJUSTED EBITDA

[0001628280-26-030530:8k_2_02:71]
(in millions, except per share data)

[0001628280-26-030530:8k_2_02:72]
(unaudited)

[0001628280-26-030530:8k_2_02:73]
|  | Three Months Ended |  |  |  | Nine Months Ended |
|  | March 28, 2026 |  |  |  | December 27, 2025 |  | March 29, 2025 |  |  |  |  |  | March 28, 2026 |  | March 29, 2025 |
| GAAP net income (loss) | $ | 144.2 |  |  |  |  | $ | 78.2 |  |  | $ | (44.1) |  |  |  |  |  |  | $ | 226.6 |  |  | $ | (187.4) |  |
| Other income (expense), net | (9.3) |  |  |  |  | (32.2) |  |  | 1.5 |  |  |  |  |  |  | (40.0) |  |  | (11.0) |  |
| Income tax provision | 39.6 |  |  |  |  | 18.3 |  |  | 4.9 |  |  |  |  |  |  | 58.9 |  |  | 26.7 |  |
| Depreciation | 32.8 |  |  |  |  | 30.6 |  |  | 25.0 |  |  |  |  |  |  | 91.2 |  |  | 77.9 |  |
| Amortization of acquired intangibles | 33.8 |  |  |  |  | 34.0 |  |  | 34.4 |  |  |  |  |  |  | 102.2 |  |  | 115.1 |  |
| EBITDA | 241.1 |  |  |  |  | 128.9 |  |  | 21.7 |  |  |  |  |  |  | 438.9 |  |  | 21.3 |  |
| Restructuring and related charges (reversals) | 1.1 |  |  |  |  | (0.4) |  |  | 7.2 |  |  |  |  |  |  | 9.0 |  |  | 17.6 |  |
| Stock-based compensation and related payroll taxes | 46.8 |  |  |  |  | 47.9 |  |  | 62.8 |  |  |  |  |  |  | 141.2 |  |  | 137.2 |  |
| Acquisition related costs, net | 0.4 |  |  |  |  | 0.4 |  |  | 0.5 |  |  |  |  |  |  | 2.1 |  |  | 0.5 |  |
| Acquisition-related warranty provision | — |  |  |  |  | 9.8 |  |  | — |  |  |  |  |  |  | 9.8 |  |  | — |  |
| Integration related costs | 1.4 |  |  |  |  | 1.3 |  |  | 1.4 |  |  |  |  |  |  | 1.9 |  |  | 7.9 |  |
| Intangible asset write-off | — |  |  |  |  | — |  |  | 0.7 |  |  |  |  |  | — |  |  | 2.6 |  |
| Gain on sale of facility | — |  |  |  |  | — |  |  | (34.9) |  |  |  |  |  |  | — |  |  | (34.9) |  |
| Other charges, net | 2.7 |  |  |  |  | 10.4 |  |  | 11.6 |  |  |  |  |  |  | 16.5 |  |  | 13.3 |  |
| Adjusted EBITDA | $ | 293.5 |  |  |  |  | $ | 198.3 |  |  | $ | 71.0 |  |  |  |  |  |  | $ | 619.4 |  |  | $ | 165.5 |  |
