# LITE MD&A — 0001628280-26-030777


## mdna

[0001628280-26-030777:mdna:1]
[same as prior period, unchanged from 0001628280-26-005129:mdna:1]

[0001628280-26-030777:mdna:2]
[same as prior period, unchanged from 0001628280-26-005129:mdna:2]

[0001628280-26-030777:mdna:3]
[same as prior period, unchanged from 0001628280-26-005129:mdna:3]

[0001628280-26-030777:mdna:4]
49

[0001628280-26-030777:mdna:5]
[same as prior period, unchanged from 0001628280-26-005129:mdna:5]

[0001628280-26-030777:mdna:6]
[same as prior period, unchanged from 0001628280-26-005129:mdna:6]

[0001628280-26-030777:mdna:7]
[same as prior period, unchanged from 0001628280-26-005129:mdna:7]

[0001628280-26-030777:mdna:8]
[same as prior period, unchanged from 0001628280-26-005129:mdna:8]

[0001628280-26-030777:mdna:9]
[same as prior period, unchanged from 0001628280-26-005129:mdna:9]

[0001628280-26-030777:mdna:10]
[same as prior period, unchanged from 0001628280-26-005129:mdna:10]

[0001628280-26-030777:mdna:11]
[same as prior period, unchanged from 0001628280-26-005129:mdna:11]

[0001628280-26-030777:mdna:12]
[same as prior period, unchanged from 0001628280-26-005129:mdna:12]

[0001628280-26-030777:mdna:13]
[same as prior period, unchanged from 0001628280-26-005129:mdna:13]

[0001628280-26-030777:mdna:14]
[same as prior period, unchanged from 0001628280-26-005129:mdna:14]

[0001628280-26-030777:mdna:15]
[same as prior period, unchanged from 0001628280-26-005129:mdna:15]

[0001628280-26-030777:mdna:16]
Through fiscal year 2024, we experienced significant fluctuations in demand as customers delayed projected shipments or built up inventory in response to supply shortages and then brought down inventories as supply chain constraints eased. Our revenue fluctuated in response to these changes in demand and our margins were adversely impacted as we were not able to fully recover costs, such as underutilized manufacturing capacity. However, beginning in the first quarter of fiscal year 2025, network equipment manufacturers normalized inventory levels and we have seen increasing demand from AI and cloud customers as they continue to expand their data centers. In fiscal year 2026, we have continued to experience increasing demand, driven in part by the continued advances in cloud and AI infrastructure. This demand is outpacing our current supply which has required us to make decisions on supply allocation. We are investing in manufacturing capacity, both internally and with contract manufacturers, to meet demand.

[0001628280-26-030777:mdna:17]
[same as prior period, unchanged from 0001628280-26-005129:mdna:17]

[0001628280-26-030777:mdna:18]
[same as prior period, unchanged from 0001628280-26-005129:mdna:18]

[0001628280-26-030777:mdna:19]
[same as prior period, unchanged from 0001628280-26-005129:mdna:19]

[0001628280-26-030777:mdna:20]
[same as prior period, unchanged from 0001628280-26-005129:mdna:20]

[0001628280-26-030777:mdna:21]
[same as prior period, unchanged from 0001628280-26-005129:mdna:21]

[0001628280-26-030777:mdna:22]
[same as prior period, unchanged from 0001628280-26-005129:mdna:22]

[0001628280-26-030777:mdna:23]
[same as prior period, unchanged from 0001628280-26-005129:mdna:23]

[0001628280-26-030777:mdna:24]
[same as prior period, unchanged from 0001628280-26-005129:mdna:24]

[0001628280-26-030777:mdna:25]
[same as prior period, unchanged from 0001628280-26-005129:mdna:25]

[0001628280-26-030777:mdna:26]
[same as prior period, unchanged from 0001628280-26-005129:mdna:26]

[0001628280-26-030777:mdna:27]
[same as prior period, unchanged from 0001628280-26-005129:mdna:27]

[0001628280-26-030777:mdna:28]
Management’s Discussion and Analysis of Financial Condition and Results of Operations contained in Part II, Item 7 of our Annual Report on Form 10-K for our fiscal year ended June 28, 2025 provides a complete discussion of our critical accounting policies and estimates. There have been no changes to these policies during the three and nine months ended March 28, 2026, except as noted below:

[0001628280-26-030777:mdna:29]
[same as prior period, unchanged from 0001628280-26-005129:mdna:29]

[0001628280-26-030777:mdna:30]
[same as prior period, unchanged from 0001628280-26-005129:mdna:30]

[0001628280-26-030777:mdna:31]
[same as prior period, unchanged from 0001628280-26-005129:mdna:31]

[0001628280-26-030777:mdna:32]
[same as prior period, unchanged from 0001628280-26-005129:mdna:32]

[0001628280-26-030777:mdna:33]
[same as prior period, unchanged from 0001628280-26-005129:mdna:33]

[0001628280-26-030777:mdna:34]
[same as prior period, unchanged from 0001628280-26-005129:mdna:34]

[0001628280-26-030777:mdna:35]
[same as prior period, unchanged from 0001628280-26-005129:mdna:35]

[0001628280-26-030777:mdna:36]
[same as prior period, unchanged from 0001628280-26-005129:mdna:36]

[0001628280-26-030777:mdna:37]
Recently Issued Accounting Pronouncements

[0001628280-26-030777:mdna:38]
Refer to “Note 2. Recently Issued Accounting Pronouncements” in the notes to condensed consolidated financial statements.

[0001628280-26-030777:mdna:39]
[same as prior period, unchanged from 0001628280-26-005129:mdna:39]

[0001628280-26-030777:mdna:40]
[same as prior period, unchanged from 0001628280-26-005129:mdna:40]

[0001628280-26-030777:mdna:41]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 28, 2026 |  | March 29, 2025 |  | March 28, 2026 |  | March 29, 2025 |
| Net revenue by type of products: |  |  |  |  |  |  |  |
| Components | 66.0 | % |  | 70.7 | % |  | 67.5 | % |  | 68.4 | % |
| Systems | 34.0 |  |  | 29.3 |  |  | 32.5 |  |  | 31.6 |  |
| Net revenue | 100.0 |  |  | 100.0 |  |  | 100.0 |  |  | 100.0 |  |
| Cost of sales | 53.4 |  |  | 66.7 |  |  | 58.3 |  |  | 68.8 |  |
| Amortization of acquired developed intangibles | 2.4 |  |  | 4.5 |  |  | 2.9 |  |  | 5.4 |  |
| Gross profit | 44.2 |  |  | 28.8 |  |  | 38.8 |  |  | 25.8 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 11.2 |  |  | 17.9 |  |  | 12.6 |  |  | 19.3 |  |
| Selling, general and administrative | 11.2 |  |  | 26.3 |  |  | 13.5 |  |  | 22.7 |  |
| Restructuring and related charges | 0.2 |  |  | 1.7 |  |  | 0.5 |  |  | 1.5 |  |
| Gain on sale of facility | — |  |  | (8.2) |  |  | — |  |  | (3.0) |  |
| Total operating expenses | 22.6 |  |  | 37.7 |  |  | 26.6 |  |  | 40.5 |  |
| Income (loss) from operations | 21.6 |  |  | (8.9) |  |  | 12.2 |  |  | (14.7) |  |
| Escrow settlement | — |  |  | — |  |  | 1.4 |  |  | — |  |
| Interest expense | (0.8) |  |  | (1.3) |  |  | (0.9) |  |  | (1.5) |  |
| Other income, net | 1.9 |  |  | 1.0 |  |  | 1.5 |  |  | 2.4 |  |
| Income (loss) before income taxes | 22.7 |  |  | (9.2) |  |  | 14.2 |  |  | (13.8) |  |
| Income tax provision | 4.9 |  |  | 1.2 |  |  | 2.9 |  |  | 2.3 |  |
| Net income (loss) | 17.8 | % |  | (10.4) | % |  | 11.3 | % |  | (16.1) | % |

[0001628280-26-030777:mdna:42]
Financial data for the three months ended March 28, 2026

[0001628280-26-030777:mdna:43]
[same as prior period, unchanged from 0001628280-26-005129:mdna:43]

[0001628280-26-030777:mdna:44]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 28, 2026 |  | March 29, 2025 |  | Change |  | Percentage Change |  | March 28, 2026 |  | March 29, 2025 |  | Change |  | Percentage Change |
| Net revenue by type of products: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Components | $ | 533.3 |  |  | $ | 300.8 |  |  | $ | 232.5 |  |  | 77.3 | % |  | $ | 1,356.2 |  |  | $ | 795.9 |  |  | $ | 560.3 |  |  | 70.4 | % |
| System | 275.1 |  |  | 124.4 |  |  | 150.7 |  |  | 121.1 | % |  | 651.5 |  |  | 368.4 |  |  | 283.1 |  |  | 76.8 | % |
| Net revenue | $ | 808.4 |  |  | $ | 425.2 |  |  | $ | 383.2 |  |  | 90.1 | % |  | $ | 2,007.7 |  |  | $ | 1,164.3 |  |  | $ | 843.4 |  |  | 72.4 | % |
| Gross profit | $ | 357.0 |  |  | $ | 122.5 |  |  | $ | 234.5 |  |  | 191.4 | % |  | $ | 778.6 |  |  | $ | 300.0 |  |  | $ | 478.6 |  |  | 159.5 | % |
| Gross margin | 44.2 | % |  | 28.8 | % |  |  |  |  |  | 38.8 | % |  | 25.8 | % |  |  |  |  |
| Research and development | $ | 90.6 |  |  | $ | 75.9 |  |  | $ | 14.7 |  |  | 19.4 | % |  | $ | 252.1 |  |  | $ | 224.4 |  |  | $ | 27.7 |  |  | 12.3 | % |
| Percentage of net revenue | 11.2 | % |  | 17.9 | % |  |  |  |  |  | 12.6 | % |  | 19.3 | % |  |  |  |  |
| Selling, general and administrative | $ | 90.8 |  |  | $ | 112.0 |  |  | $ | (21.2) |  |  | (18.9) | % |  | $ | 272.0 |  |  | $ | 264.6 |  |  | $ | 7.4 |  |  | 2.8 | % |
| Percentage of net revenue | 11.2 | % |  | 26.3 | % |  |  |  |  |  | 13.5 | % |  | 22.7 | % |  |  |  |  |
| Restructuring and related charges (reversals) | $ | 1.1 |  |  | $ | 7.2 |  |  | $ | (6.1) |  |  | (84.7) | % |  | $ | 9.0 |  |  | $ | 17.6 |  |  | $ | (8.6) |  |  | (48.9) | % |
| Percentage of net revenue | 0.2 | % |  | 1.7 | % |  |  |  |  |  | 0.4 | % |  | 1.5 | % |  |  |  |  |
| Gain on sale of facility | $ | — |  |  | $ | (34.9) |  |  | $ | 34.9 |  |  | (100.0) | % |  | $ | — |  |  | $ | (34.9) |  |  | $ | 34.9 |  |  | (100.0) | % |
| Percentage of net revenue | — | % |  | (8.2) | % |  |  |  |  |  | — | % |  | (3.0) | % |  |  |  |  |

[0001628280-26-030777:mdna:45]
54

[0001628280-26-030777:mdna:46]
[same as prior period, unchanged from 0001628280-26-005129:mdna:46]

[0001628280-26-030777:mdna:47]
Net revenue increased by $383.2 million, or 90.1%, during the three months ended March 28, 2026 compared to the three months ended March 29, 2025, driven by a $232.5 million increase in Components products and $150.7 million increase in Systems products.

[0001628280-26-030777:mdna:48]
The increase in Components products was primarily driven by the ramp of laser chip and laser assembly product shipments to support strong, broad-based demand across intra-data center, data center interconnect, and long-haul applications. Additionally, a slight increase in average selling prices of laser chip products contributed to the increase in Components revenue driven primarily by a shift to 200G lane speeds. The remaining approximately 12% of Components revenue growth was due to an increase in shipment volume of data transport products, encompassing line subsystems solutions for long-haul terrestrial networks and charge pump products used in sub-sea network installations.

[0001628280-26-030777:mdna:49]
The increase in our Systems products was primarily driven by our cloud transceiver product lines which increased by more than $137.0 million due to higher shipment volume, partially offset by lower average selling prices. We also continued the initial phase of optical circuit switch shipments, which contributed more than $25.0 million in revenue during the three months ended March 28, 2026, and we remain on track for manufacturing expansion over the coming quarters to support future growth.

[0001628280-26-030777:mdna:50]
Net revenue increased by $843.4 million, or 72.4%, during the nine months ended March 28, 2026 compared to the nine months ended March 29, 2025, driven by a $560.3 million increase in Components products and a $283.1 million increase in Systems products.

[0001628280-26-030777:mdna:51]
The increase in Components products was primarily driven by the ramp of laser chip and laser assembly product shipments to support strong, broad-based demand across intra-data center, data center interconnect, and long-haul applications. Additionally, a slight increase in average selling prices of laser chip products contributed to the increase in Components revenue driven primarily by a shift to 200G lane speeds. The remaining approximately 19% of Components revenue growth was due to an increase in shipment volume of data transport products, encompassing line subsystems solutions for long-haul terrestrial networks and charge pump products used in sub-sea network installations.

[0001628280-26-030777:mdna:52]
The increase in our System products was primarily driven by our cloud transceiver product lines which increased by more than $268.0 million due to an increase in shipment volume, partially offset by lower average selling prices. We also continued the initial phase of optical circuit switch shipments, which contributed more than $38.0 million of revenue during the nine months ended March 28, 2026.

[0001628280-26-030777:mdna:53]
During the three months ended March 28, 2026, two customers individually accounted for 26% and 12% of our total revenue, respectively. During the nine months ended March 28, 2026, two customers individually accounted for 24% and 16% of our total net revenue, respectively. We had no other customers that represented 10% or greater of our total net revenue.

[0001628280-26-030777:mdna:54]
[same as prior period, unchanged from 0001628280-26-005129:mdna:52]

[0001628280-26-030777:mdna:55]
[same as prior period, unchanged from 0001628280-26-005129:mdna:53]

[0001628280-26-030777:mdna:56]
[same as prior period, unchanged from 0001628280-26-005129:mdna:54]

[0001628280-26-030777:mdna:57]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 28, 2026 |  | March 29, 2025 |  | March 28, 2026 |  | March 29, 2025 |
|  | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States | $ | 185.9 |  |  | 23.0 | % |  | $ | 70.5 |  |  | 16.6 | % |  | $ | 424.3 |  |  | 21.1 | % |  | $ | 213.5 |  |  | 18.3 | % |
| Mexico | 103.4 |  |  | 12.8 |  |  | 38.8 |  |  | 9.1 |  |  | 279.6 |  |  | 13.9 |  |  | 110.1 |  |  | 9.5 |  |
| Other Americas | 1.6 |  |  | 0.2 |  |  | 6.4 |  |  | 1.5 |  |  | 12.2 |  |  | 0.7 |  |  | 13.5 |  |  | 1.2 |  |
| Total Americas | $ | 290.9 |  |  | 36.0 | % |  | $ | 115.7 |  |  | 27.2 | % |  | $ | 716.1 |  |  | 35.7 | % |  | $ | 337.1 |  |  | 29.0 | % |
| Asia-Pacific: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Hong Kong | $ | 136.0 |  |  | 16.8 | % |  | $ | 96.5 |  |  | 22.7 | % |  | $ | 347.8 |  |  | 17.3 | % |  | $ | 285.7 |  |  | 24.5 | % |
| Thailand | 176.8 |  |  | 21.9 |  |  | 79.1 |  |  | 18.6 |  |  | 408.9 |  |  | 20.4 |  |  | 206.3 |  |  | 17.7 |  |
| China | 70.2 |  |  | 8.7 |  |  | 31.4 |  |  | 7.4 |  |  | 174.1 |  |  | 8.7 |  |  | 64.1 |  |  | 5.5 |  |
| Japan | 29.2 |  |  | 3.6 |  |  | 20.8 |  |  | 4.9 |  |  | 74.0 |  |  | 3.7 |  |  | 56.1 |  |  | 4.8 |  |
| Other Asia-Pacific | 52.7 |  |  | 6.5 |  |  | 39.4 |  |  | 9.3 |  |  | 157.9 |  |  | 7.8 |  |  | 101.3 |  |  | 8.7 |  |
| Total Asia-Pacific | $ | 464.9 |  |  | 57.5 | % |  | $ | 267.2 |  |  | 62.9 | % |  | $ | 1,162.7 |  |  | 57.9 | % |  | $ | 713.5 |  |  | 61.2 | % |
| EMEA | $ | 52.6 |  |  | 6.5 | % |  | $ | 42.3 |  |  | 9.9 | % |  | $ | 128.9 |  |  | 6.4 | % |  | $ | 113.7 |  |  | 9.8 | % |
| Total net revenue | $ | 808.4 |  |  | 100.0 | % |  | $ | 425.2 |  |  | 100.0 | % |  | $ | 2,007.7 |  |  | 100.0 | % |  | $ | 1,164.3 |  |  | 100.0 | % |

[0001628280-26-030777:mdna:58]
For the three and nine months ended March 28, 2026, net revenue from customers outside the United States, based on customer shipping locations, represented 77.0% and 78.9% of net revenue, respectively.

[0001628280-26-030777:mdna:59]
[same as prior period, unchanged from 0001628280-26-005129:mdna:57]

[0001628280-26-030777:mdna:60]
[same as prior period, unchanged from 0001628280-26-005129:mdna:58]

[0001628280-26-030777:mdna:61]
Gross margin for the three months ended March 28, 2026 increased to 44.2% from 28.8% for the three months ended March 29, 2025, primarily driven by the positive impact of higher revenue from our laser chip, laser assembly, and data transport products. Approximately 46% of the gross margin increase was driven by lower manufacturing costs as a percentage of revenue, primarily due to higher internal factory utilization. Additionally, 37% of the gross margin increase was driven by a mix shift to higher margin products. The remaining 17% increase in gross margin relates to the decrease in amortization of acquired intangibles as a percentage of revenue.

[0001628280-26-030777:mdna:62]
Gross margin for the nine months ended March 28, 2026 increased to 38.8% from 25.8% for the nine months ended March 29, 2025, primarily driven by the positive impact of higher revenue from our laser chip, laser assembly, and data transport products. Approximately 57% of the gross margin increase was driven by lower manufacturing costs as a percentage of revenue, primarily due to higher internal factory utilization. Additionally, 23% of the gross margin increase was driven by was driven by a mix shift to higher margin products. The remaining 20% increase in gross margin relates to the decrease in amortization of acquired intangibles as a percentage of revenue.

[0001628280-26-030777:mdna:63]
[same as prior period, unchanged from 0001628280-26-005129:mdna:61]

[0001628280-26-030777:mdna:64]
[same as prior period, unchanged from 0001628280-26-005129:mdna:62]

[0001628280-26-030777:mdna:65]
R&D expense increased by $14.7 million, or 19.4% for the three months ended March 28, 2026 compared to the three months ended March 29, 2025, primarily due to a $6.8 million increase in our cash incentive compensation due to higher revenue and profit levels and prior year annual incentive plan was mostly stock-based, $5.3 million increase in charges related to new R&D programs, and $2.9 million in employee benefits and taxes driven by higher headcount. This was partially offset by a $1.8 million decrease in stock-based compensation as prior year as prior year annual incentive plan was mostly stock-based.

[0001628280-26-030777:mdna:66]
R&D expense increased by $27.7 million, or 12.3% for the nine months ended March 28, 2026 compared to the nine months ended March 29, 2025, primarily due to a $18.3 million increase in our cash incentive compensation due to higher revenue and profit levels and prior year annual incentive plan was mostly stock-based, and a $7.2 million increase in payroll related expenses primarily driven by equity-related taxes. In addition, incremental investments related to new R&D programs were partially offset by a decrease in stock-based compensation.

[0001628280-26-030777:mdna:67]
[same as prior period, unchanged from 0001628280-26-005129:mdna:65]

[0001628280-26-030777:mdna:68]
[same as prior period, unchanged from 0001628280-26-005129:mdna:66]

[0001628280-26-030777:mdna:69]
SG&A expense decreased by $21.2 million, or 18.9%, during the three months ended March 28, 2026 compared to the three months ended March 29, 2025, primarily due to a decrease of $20.4 million in stock-based compensation driven by equity award modifications as well as $5.2 million of severance and sign-on payments, all related to executive employee transitions that occurred in the three months ended March 29, 2025. In addition, we also recognized a $3.1 million bad debt expense during the three months ended March 29, 2025. We did not have similar transactions and no similar charges were incurred during the three months ended March 28, 2026.  These decreases were partially offset by a $6.2 million increase payroll related expenses in the three months ended March 28, 2026 driven by our cash incentive compensation due to higher revenue and profit levels and equity-related taxes.

[0001628280-26-030777:mdna:70]
SG&A expense increased by $7.4 million, or 2.8%, during the nine months ended March 28, 2026 compared to the nine months ended March 29, 2025, primarily due to a $14.2 million increase in our cash incentive compensation due to higher revenue and profit levels and prior year annual incentive plan was mostly stock-based, a $9.4 million increase in employee benefits and taxes primarily driven by equity-related taxes, a $7.7 million loss on sale of our two commercial buildings and a $5.8 million increase in legal fees. These increases were partially offset by a decrease of $12.9 million in amortization of intangible assets as certain assets were fully amortized, a decrease of $8.4 million in stock-based compensation driven by equity award modifications as well as $5.2 million of severance and sign-on payments, all related to executive employee transitions incurred in the prior year period, and a $3.4 million reduction in bad debt expense.

[0001628280-26-030777:mdna:71]
From time-to-time, we incur expenses that are not part of our ordinary operations, such as mergers and acquisition-related and litigation expenses, which generally increase our SG&A expenses and potentially impact our profitability expectations in any particular period.

[0001628280-26-030777:mdna:72]
[same as prior period, unchanged from 0001628280-26-005129:mdna:70]

[0001628280-26-030777:mdna:73]
[same as prior period, unchanged from 0001628280-26-005129:mdna:71]

[0001628280-26-030777:mdna:74]
During the three and nine months ended March 28, 2026, we recorded restructuring and related charges of  $1.1 million and $9.0 million, respectively, primarily related to a reduction in force during the period in order to enhance operational efficiency and realign our investments toward the most critical initiatives.

[0001628280-26-030777:mdna:75]
Gain on Sale of Facility

[0001628280-26-030777:mdna:76]
In the three months ended March 29, 2025, we completed the sale of our net assets in an entity in Shenzhen, China and received net proceeds of $47.8 million, which was net of cash of $17.6 million and direct selling costs of $1.1 million. The net assets sold consist primarily of building, building improvements and land rights as of December 17, 2024 with a net carrying value of $12.9 million, and were used for manufacturing and research and development activities. As a result, we recognized a gain on sale of facility of $34.9 million, which was recorded in our condensed consolidated statements of operations for the three and nine months ended March 29, 2025. We paid $4.4 million of withholding taxes on this sale transaction, which is recorded as part of the income tax provision for the three and nine months ended March 29, 2025. We also incurred $0.4 million and $0.7 million of indirect selling expenses related to this transaction, which was recorded as part of selling, general and administrative expenses in our condensed consolidated statements of operations for the three and nine months ended March 29, 2025.

[0001628280-26-030777:mdna:77]
[same as prior period, unchanged from 0001628280-26-005129:mdna:73]

[0001628280-26-030777:mdna:78]
On November 7, 2023, we completed the acquisition of Cloud Light Technology Limited (“Cloud Light”). In accordance with a definitive merger agreement, dated as of October 29, 2023, between the Company and Cloud Light, cash consideration included $75.8 million of cash held in an escrow fund to support Cloud Light’s indemnification obligations and customary adjustment for working capital. In November 2025, the Company and the former shareholders of Cloud Light mutually agreed to settle outstanding indemnification claims for $27.5 million and signed a settlement agreement releasing the balance of the escrow fund to the former Cloud Light shareholders and releasing them of their indemnification obligations. Since the measurement period has expired, we recorded the settlement amount of $27.5 million as other income, net in our condensed consolidated statements of operations for the nine months ended March 28, 2026.

[0001628280-26-030777:mdna:79]
[same as prior period, unchanged from 0001628280-26-005129:mdna:75]

[0001628280-26-030777:mdna:80]
For the three months ended March 28, 2026 and March 29, 2025, we recorded interest expense of $6.2 million and $5.7 million, respectively. The increase in interest expense for the three months ended March 28, 2026 is mainly due to the issuance of the 2032 Notes in September 2025.

[0001628280-26-030777:mdna:81]
For the nine months ended March 28, 2026 and March 29, 2025, we recorded interest expense of $18.2 million and $16.8 million, respectively. The increase in interest expense for the nine months ended March 28, 2026 is mainly due to the issuance of the 2032 Notes in September 2025. Interest expense is primarily driven by the amortization of the debt issuance costs of our convertible notes.

[0001628280-26-030777:mdna:82]
[same as prior period, unchanged from 0001628280-26-005129:mdna:78]

[0001628280-26-030777:mdna:83]
[same as prior period, unchanged from 0001628280-26-005129:mdna:79]

[0001628280-26-030777:mdna:84]
|  | Three Months Ended |  | Nine Months Ended |  |  |
|  | March 28, 2026 |  | March 29, 2025 |  | March 28, 2026 |  | March 29, 2025 |  |  |
| Foreign exchange and other gains (losses), net | $ | 0.8 |  |  | $ | (3.6) |  |  | $ | 1.7 |  |  | $ | 1.6 |  |  |  |
| Interest and investment income, net | 14.9 |  |  | 7.8 |  |  | 35.1 |  |  | 26.2 |  |  |  |
| Inducement expense and others | (0.2) |  |  | — |  |  | (6.1) |  |  | — |  |  |  |
| Total other income, net | $ | 15.5 |  |  | $ | 4.2 |  |  | $ | 30.7 |  |  | $ | 27.8 |  |  |  |

[0001628280-26-030777:mdna:85]
Other income, net for the three months ended March 28, 2026 increased by $11.3 million compared to the three months ended March 29, 2025 primarily due to an increase of $7.1 million in interest and investment income driven by the $2.0 billion proceeds from issuance of Series A Convertible Preferred Stock, which was invested in money market funds, and a decrease in net foreign exchange loss of $4.4 million as the U.S. dollar strengthened against the Japanese Yen, which is the underlying currency for our term loans.

[0001628280-26-030777:mdna:86]
Other income, net for the nine months ended March 28, 2026 increased by $2.9 million from the nine months ended March 29, 2025 primarily due to an increase of $8.9 million in interest and investment income driven by the $2.0 billion proceeds from issuance of Series A Convertible Preferred Stock, which was invested in money market funds, and a $2.0 million interest and investment income related to the Cloud Light escrow settlement. This was offset by a $5.9 million inducement expense related to the partial repurchase of 2026 Notes.

[0001628280-26-030777:mdna:87]
[same as prior period, unchanged from 0001628280-26-005129:mdna:83]

[0001628280-26-030777:mdna:88]
[same as prior period, unchanged from 0001628280-26-005129:mdna:84]

[0001628280-26-030777:mdna:89]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 28, 2026 |  | March 29, 2025 |  | March 28, 2026 |  | March 29, 2025 |
| Income tax provision | $ | 39.6 |  |  | $ | 4.9 |  |  | $ | 58.9 |  |  | $ | 26.7 |  |

[0001628280-26-030777:mdna:90]
We recorded a tax provision of $39.6 million and $58.9 million for the three and nine months ended March 28, 2026. Our tax provision for the three months ended March 28, 2026 includes a discrete tax benefit of 7.3 million primarily related to the tax benefit from a windfall in connection with stock-based compensation vested during the quarter and return-to-provision differences, partially offset by the tax expense related to the remeasurement of certain tax-related accounts. Our tax provision for the nine months ended March 28, 2026 includes a discrete tax expense of $6.8 million, primarily related to the tax benefit from a windfall in connection with stock-based compensation vested during the period, return-to-provision differences and the revaluation of deferred tax balances,  partially offset by the tax expense associated with income from a claim settlement, the currency remeasurement of certain tax-related accounts, and interest accruals on uncertain tax positions.

[0001628280-26-030777:mdna:91]
Our estimated effective tax rate for the nine months ended March 28, 2026 differs from the 21% U.S. statutory rate primarily due to the income tax expense from foreign income inclusions in the U.S., current year valuation allowance change, and changes in unrecognized tax benefits, partially offset by the income tax benefit from foreign rate differential and various income tax credits.

[0001628280-26-030777:mdna:92]
We regularly assess our ability to realize our deferred tax assets on a quarterly basis and will establish a valuation allowance if it is more-likely-than-not that some portion of the deferred tax assets will not be realized. As of March 28, 2026, we maintain a full valuation allowance on U.S. federal and state and certain foreign deferred tax assets. Due to cumulative losses over recent years and based on all available evidence, we determined that it is more likely than not that our U.S. deferred tax assets will not be realized. However, given our current and anticipated future earnings, we believe there is a reasonable possibility that within the next twelve months, sufficient positive evidence may become available to support a release of all or a significant portion of the U.S. valuation allowance. The release of the valuation allowance would result in the recognition of certain deferred tax assets and a decrease to income tax expense for the period in which the release is recorded. The exact timing and amount of the valuation allowance released are subject to change and are based on the level of profitability that we are able to achieve and can reasonably forecast, as well as other positive and negative evidence.

[0001628280-26-030777:mdna:93]
[same as prior period, unchanged from 0001628280-26-005129:mdna:89]

[0001628280-26-030777:mdna:94]
[same as prior period, unchanged from 0001628280-26-005129:mdna:90]

[0001628280-26-030777:mdna:95]
[same as prior period, unchanged from 0001628280-26-005129:mdna:91]

[0001628280-26-030777:mdna:96]
[same as prior period, unchanged from 0001628280-26-005129:mdna:92]

[0001628280-26-030777:mdna:97]
As of March 28, 2026 and June 28, 2025, our cash and cash equivalents were $2,617.8 million and $520.7 million, respectively. As of March 28, 2026 and June 28, 2025, our short-term investments of $554.5 million and $356.4 million, respectively, were all held in the United States. Cash equivalents and short-term investments are primarily comprised of money market funds, treasuries, agencies, high quality investment grade fixed income securities, certificates of deposit, and commercial paper. Our investment policy and strategy provide for diversification of investments and is focused on the preservation of capital and supporting our liquidity requirements.

[0001628280-26-030777:mdna:98]
The total amount of cash held by the non-United States entities as of March 28, 2026 and June 28, 2025 was $375.2 million and $398.3 million, respectively, which was primarily held by entities incorporated in the United Kingdom, Japan, Hong Kong, China, Switzerland, and Thailand. Although cash currently held in the United States, as well as cash generated in the United States from future operations, is expected to cover our normal operating requirements, a substantial amount of additional cash could be required for other purposes, such as capital expenditures to support our business and growth, including costs associated with increasing internal manufacturing capabilities, strategic transactions and partnerships, and future acquisitions.

[0001628280-26-030777:mdna:99]
Our intent is to indefinitely reinvest funds held outside the United States. Except for the funds held in the Cayman Islands, the British Virgin Islands, Hong Kong and Japan, our current plans do not demonstrate a need to repatriate them to fund our U.S. operations. However, if in the future, we encounter a significant need for liquidity domestically or at a particular location that we cannot fulfill through borrowings, equity offerings, or other internal or external sources, or the cost to bring back the money is not significant from a tax perspective, we may determine that cash repatriations are necessary or desirable. Repatriation could result in additional taxes that are material. These factors may cause us to have an overall tax rate higher than other companies or higher than our tax rates in the past. Additionally, if conditions warrant, we may seek to obtain additional financing through debt or equity sources. To the extent we issue additional shares, it may create dilution to our existing stockholders. However, any such financing may not be available on terms favorable to us or may not be available at all.

[0001628280-26-030777:mdna:100]
Beginning in fiscal year 2023, the Tax Cuts and Jobs Act of 2017 requires taxpayers to capitalize research and development expenditures and amortize domestic expenditures over five years and foreign expenditures over fifteen years. The One Big Beautiful Bill Act (“OBBBA”) enacted in July 2025 eliminates capitalization of domestic research and development expenditures for taxable years beginning on or after January 1, 2025, but retains the requirement to amortize foreign research and development expenditures over 15 years. In addition, the OBBBA permits all taxpayers who paid or incurred domestic research and development expenses in tax years beginning on or after January 1, 2022 and before January 1, 2025 to elect to deduct any remaining unamortized amount over a one-year period or ratably over a two-year period (at the taxpayer’s election), accelerating the benefit of such expenses. We have evaluated these changes during the three and nine months ended March 28, 2026, and the impact to our tax provision during these periods is not material.

[0001628280-26-030777:mdna:101]
[same as prior period, unchanged from 0001628280-26-005129:mdna:97]

[0001628280-26-030777:mdna:102]
We believe that our cash and cash equivalents as of March 28, 2026, available borrowing capacity under our Credit Agreement, and cash flows from our operating activities will be sufficient to meet our liquidity and capital spending requirements for at least the next 12 months.

[0001628280-26-030777:mdna:103]
[same as prior period, unchanged from 0001628280-26-005129:mdna:99]

[0001628280-26-030777:mdna:104]
[same as prior period, unchanged from 0001628280-26-005129:mdna:100]

[0001628280-26-030777:mdna:105]
[same as prior period, unchanged from 0001628280-26-005129:mdna:101]

[0001628280-26-030777:mdna:106]
[same as prior period, unchanged from 0001628280-26-005129:mdna:102]

[0001628280-26-030777:mdna:107]
[same as prior period, unchanged from 0001628280-26-005129:mdna:103]

[0001628280-26-030777:mdna:108]
[same as prior period, unchanged from 0001628280-26-005129:mdna:104]

[0001628280-26-030777:mdna:109]
•the tendency of customers to delay payments or to negotiate favorable payment terms to manage their own liquidity positions;

[0001628280-26-030777:mdna:110]
[same as prior period, unchanged from 0001628280-26-005129:mdna:107]

[0001628280-26-030777:mdna:111]
[same as prior period, unchanged from 0001628280-26-005129:mdna:108]

[0001628280-26-030777:mdna:112]
[same as prior period, unchanged from 0001628280-26-005129:mdna:109]

[0001628280-26-030777:mdna:113]
[same as prior period, unchanged from 0001628280-26-005129:mdna:110]

[0001628280-26-030777:mdna:114]
[same as prior period, unchanged from 0001628280-26-005129:mdna:111]

[0001628280-26-030777:mdna:115]
[same as prior period, unchanged from 0001628280-26-005129:mdna:112]

[0001628280-26-030777:mdna:116]
[same as prior period, unchanged from 0001628280-26-005129:mdna:113]

[0001628280-26-030777:mdna:117]
[same as prior period, unchanged from 0001628280-26-005129:mdna:114]

[0001628280-26-030777:mdna:118]
[same as prior period, unchanged from 0001628280-26-005129:mdna:115]

[0001628280-26-030777:mdna:119]
The following table summarizes our contractual obligations as of March 28, 2026, and the effect such obligations are expected to have on our liquidity and cash flow (in millions):

[0001628280-26-030777:mdna:120]
|  | Payments Due |
|  | Total |  | Less Than 1 Year |  | More Than 1 Year |  |  |  |  |
| Contractual Obligations |  |  |  |  |  |  |  |  |  |
| Asset retirement obligations | $ | 7.1 |  |  | $ | — |  |  | $ | 7.1 |  |  |  |  |  |
| Operating lease liabilities, including imputed interest (1) | 34.0 |  |  | 13.6 |  |  | 20.4 |  |  |  |  |  |
| Pension plan contributions (2) | 2.0 |  |  | 2.0 |  |  | — |  |  |  |  |  |
| Purchase obligations (3) | 1,795.6 |  |  | 1,629.9 |  |  | 165.7 |  |  |  |  |  |
| Term loans - principal (5) | 98.4 |  |  | 55.2 |  |  | 43.2 |  |  |  |  |  |
| Term loans - interest (5) | 1.6 |  |  | 0.9 |  |  | 0.7 |  |  |  |  |  |
| Convertible notes - principal (4) | 3,198.4 |  |  | 468.7 |  |  | 2,729.7 |  |  |  |  |  |
| Convertible notes - interest (4) | 68.4 |  |  | 18.2 |  |  | 50.2 |  |  |  |  |  |
| Others | 14.9 |  |  | 3.9 |  |  | 11.0 |  |  |  |  |  |
| Total | $ | 5,220.4 |  |  | $ | 2,192.4 |  |  | $ | 3,028.0 |  |  |  |  |  |

[0001628280-26-030777:mdna:121]
(1) The amounts of operating lease liabilities do not include any sublease income nor do they include payments for short-term leases or variable lease payments. As of March 28, 2026, we expect to receive sublease income of approximately $1.7 million over the remaining sublease periods.

[0001628280-26-030777:mdna:122]
[same as prior period, unchanged from 0001628280-26-005129:mdna:119]

[0001628280-26-030777:mdna:123]
(3) Purchase obligations represent legally binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Refer to “Note 14. Commitments and Contingencies” in the notes to condensed consolidated financial statements.

[0001628280-26-030777:mdna:124]
(4) The amounts related to convertible notes include principal and interest on our 0.50% Convertible Senior Notes due 2026 (the “2026 Notes”), principal and interest on our 0.50% Convertible Senior Notes due 2028 (the “2028 Notes”), principal and interest on our 1.50% Convertible Senior Notes due 2029 (the “2029 Notes”), and principal and interest on our 0.375% Convertible Senior Notes due 2032 (the “2032 Notes”). The 2026 Notes have a maturity date of December 15, 2026, the 2028 Notes have a maturity date of June 15, 2028, the 2029 Notes have a maturity date of December 15, 2029, and the 2032 Notes have a maturity date of March 15, 2032. The principal balances of our convertible notes are reflected in the payment periods in the table above based on their respective contractual maturities, which may be accelerated if the holders elect to convert the notes prior to maturity. The principal amounts of all of our outstanding convertible notes must be settled in cash. The actual cash settlement may be higher if we decide to settle the conversion value in excess of the principal amounts in cash, rather than issuing shares of common stock. Refer to “Note 9. Debt” and “Note 17. Subsequent Event” for further details.

[0001628280-26-030777:mdna:125]
[same as prior period, unchanged from 0001628280-26-005129:mdna:122]

[0001628280-26-030777:mdna:126]
[same as prior period, unchanged from 0001628280-26-005129:mdna:123]

[0001628280-26-030777:mdna:127]
[same as prior period, unchanged from 0001628280-26-005129:mdna:124]

[0001628280-26-030777:mdna:128]
[same as prior period, unchanged from 0001628280-26-005129:mdna:126]

[0001628280-26-030777:mdna:129]
|  | March 28, 2026 |  | June 28, 2025 |
|  | Carrying Amount |  | Estimated Fair Value |  | Carrying Amount |  | Estimated Fair Value |
| 2032 Notes | $ | 1,255.7 |  |  | $ | 4,867.2 |  |  | $ | — |  |  | $ | — |  |
| 2029 Notes | 600.9 |  |  | 6,262.3 |  |  | 600.2 |  |  | 925.5 |  |
| 2028 Notes | 858.5 |  |  | 4,617.2 |  |  | 857.7 |  |  | 890.2 |  |
| 2026 Notes | 468.3 |  |  | 3,328.0 |  |  | 1,048.3 |  |  | 1,233.3 |  |
|  | $ | 3,183.4 |  |  | $ | 19,074.7 |  |  | $ | 2,506.2 |  |  | $ | 3,049.0 |  |

[0001628280-26-030777:mdna:130]
[same as prior period, unchanged from 0001628280-26-005129:mdna:130]

[0001628280-26-030777:mdna:131]
[same as prior period, unchanged from 0001628280-26-005129:mdna:131]

[0001628280-26-030777:mdna:132]
(1) Since the closing price of our stock was at least 130% of the applicable conversion price for each series of Notes for 20 of the last 30 trading days of our second and third quarters of fiscal year 2026, all of our Notes remain convertible at the option of the holders during the fourth quarter of fiscal year 2026. The outstanding Notes are recorded as short-term debt, which is presented as current liabilities in our condensed consolidated balance sheets as of March 28, 2026, net of unamortized debt issuance costs. If the Notes are converted by holders, we are required to satisfy our conversion obligations with respect to each series of converted Notes by paying cash equal to the principal amounts of such series of converted Notes and paying or delivering, as the case may be, cash, shares of common stock, or a combination of cash and shares of common stock, at our election, with respect to any conversion value in excess thereof. The outstanding Notes are recorded as convertible notes, non-current in our consolidated balance sheets as of June 28, 2025, net of unamortized debt issuance costs.

[0001628280-26-030777:mdna:133]
As of April 30, 2026, we have received early conversion requests totaling $500.8 million aggregate principal amount of the Notes,  which will be settled in cash and the conversion value in excess thereof will be settled in shares of common stock in accordance with Indenture governing the applicable series of Notes. In the three and nine months ended March 28, 2026, the aggregate principal amount of the Notes settled in cash was $0.1 million and $0.2 million, respectively.

[0001628280-26-030777:mdna:134]
On April 7, 2026, we entered into privately negotiated exchange arrangements with certain holders of our 2026 Notes and 2029 Notes. Pursuant to these agreements, we issued an aggregate of approximately 5.7 million shares of our common stock in exchange for approximately $264.8 million and $209.8 million aggregate principal amount of the 2026 Notes and 2029 Notes, respectively, and the related conversion value in excess of the principal amounts thereof. The issuance of common stock in the exchange transactions resulted in incremental dilution of approximately 0.6 million shares of common stock related to the principal amounts. Refer to “Note 17. Subsequent Event” for further details.

[0001628280-26-030777:mdna:135]
The principal amount outstanding of our Japan Term Loans are as follows for the periods presented (in millions):

[0001628280-26-030777:mdna:136]
|  | March 28, 2026 |  | June 28, 2025 |
|  | Short-term |  | Long-term |  | Total |  | Short-term |  | Long-term |  | Total |
| SMBC Term Loans | $ | 49.6 |  |  | $ | 29.3 |  |  | $ | 78.9 |  |  | $ | 4.4 |  |  | $ | 36.2 |  |  | $ | 40.6 |  |
| Mizuho Term Loan | 5.6 |  |  | 13.9 |  |  | 19.5 |  |  | 6.2 |  |  | 20.2 |  |  | 26.4 |  |
| Total | $ | 55.2 |  |  | $ | 43.2 |  |  | $ | 98.4 |  |  | $ | 10.6 |  |  | $ | 56.4 |  |  | $ | 67.0 |  |

[0001628280-26-030777:mdna:137]
The short-term portion of the Japan Term Loans is recorded as current liabilities while the long-term portion is recorded as long-term debt in the Company’s condensed consolidated balance sheets.

[0001628280-26-030777:mdna:138]
On December 19, 2025, we entered into a Credit Agreement providing for a senior secured revolving credit facility in an aggregate principal amount of $400.0 million, including a $23.0 million sublimit for the issuance of letters of credit. As of March 28, 2026, there were no borrowings outstanding under the revolving credit facility. For additional information regarding the Credit Agreement, refer to “Note 9. Debt”, in the condensed consolidated financial statements included in Part 1, Item 1 of this Quarterly Report on Form 10-Q. For additional information, refer to “Part II. Item 1A. Risk Factors”.

[0001628280-26-030777:mdna:139]
[same as prior period, unchanged from 0001628280-26-005129:mdna:136]

[0001628280-26-030777:mdna:140]
As of March 28, 2026 and June 28, 2025, our other non-current liabilities include unrecognized tax benefit for uncertain tax positions of $67.6 million and $55.6 million, respectively. We are unable to reliably estimate the timing of future payments related to uncertain tax positions.

[0001628280-26-030777:mdna:141]
[same as prior period, unchanged from 0001628280-26-005129:mdna:138]

[0001628280-26-030777:mdna:142]
Our balance of cash and cash equivalents increased by $2,097.1 million from $520.7 million as of June 28, 2025 to $2,617.8 million as of March 28, 2026. The increase in cash and cash equivalents during the nine months ended March 28, 2026 was due to cash from operating activities of $388.4 million and cash from financing activities of $2,189.8 million, offset by cash used in investing activities of $481.1 million.

[0001628280-26-030777:mdna:143]
[same as prior period, unchanged from 0001628280-26-005129:mdna:140]

[0001628280-26-030777:mdna:144]
Cash from operating activities was $388.4 million during the nine months ended March 28, 2026, which reflects a net income of $226.6 million and non-cash items of $335.9 million, offset by changes in operating assets and liabilities of $174.1 million. Changes in operating assets and liabilities were primarily driven by an increase in accounts payable of $109.4 million primarily due to higher inventory purchases and capital expenditures, an increase of $51.8 million in accrued payroll and related expenses mainly driven by our accrual for employee cash bonuses and outstanding payroll taxes mainly related to stock-based compensation, and an increase of $28.2 million in accrued expenses and other current and non-current liabilities driven by contractual liabilities and increase in provision for warranty reserves, and increase in income tax liabilities by $17.9 million primarily due to income tax provision for the nine months ended March 28, 2026, offset by an increase in accounts receivable of $191.5 million mainly driven by higher revenue, an increase of $165.2 million in inventories driven by inventory builds to support market demand and an increase of $22.5 million in prepayments and other current and non-current assets primarily driven by increase in value-added-tax receivables due to higher capital expenditures and inventory purchases and an increase in interest receivables driven by the $1,999.7 million of net proceeds from the issuance of Series A Convertible Preferred Stock, which was invested in money market funds.

[0001628280-26-030777:mdna:145]
Cash from operating activities was $62.3 million during the nine months ended March 29, 2025, which reflects a net loss of $187.4 million, offset by non-cash items of $309.4 million and changes in operating assets and liabilities of $59.7 million. Changes in operating assets and liabilities were primarily driven by an increase in accounts payable of $44.9 million primarily due to higher inventory purchases and capital expenditures, an increase of $6.9 million in accrued payroll and related expenses mainly driven by our accrual on employee annual incentive plan, and an increase in income tax liabilities of $16.8 million primarily due to income tax provision for the nine months ended March 29, 2025, offset by an increase in accounts receivable of $64.4 million mainly driven by higher revenue, an increase of $25.7 million in inventories driven by inventory builds to support market demand, an increase of $21.7 million in prepayments and other current and non-current assets related mainly to value-added-tax receivables driven by higher recent capital expenditures and inventory purchases and a decrease of $15.3 million in accrued expenses and other current and non-current liabilities driven by payment of the net settlement amount of the Oclaro merger litigation and restructuring related payments.

[0001628280-26-030777:mdna:146]
Cash used in investing activities of $481.1 million during the nine months ended March 28, 2026 was attributable to capital expenditures of $284.5 million, net payments from sales or maturities of short-term investments of $198.2 million and payment for acquisition of a business of $38.0 million, offset by $39.6 million proceeds from sale of assets.

[0001628280-26-030777:mdna:147]
Cash used in investing activities of $24.7 million during the nine months ended March 29, 2025 was attributable to capital expenditures of $177.1 million, offset by net proceeds from sales or maturities of short-term investments of $104.3 million, $47.8 million of proceeds from sale of facility, net of cash transferred and selling costs, and proceeds from sales of property and equipment of $0.3 million.

[0001628280-26-030777:mdna:148]
[same as prior period, unchanged from 0001628280-26-005129:mdna:146]

[0001628280-26-030777:mdna:149]
Cash from financing activities of $2,189.8 million during the nine months ended March 28, 2026 was attributable to $1,999.7 million of net proceeds from the issuance of Series A Convertible Preferred Stock, $1,254.7 million of net proceeds from the issuance of our 2032 Notes, $47.9 million of proceeds from SMBC term loans and $9.2 million of proceeds from employee stock plans, offset by payments for the partial repurchase of the 2026 Notes of approximately $843.1 million, payments for the 2032 Capped Call Options of $102.0 million, tax payments related to net share settlement of restricted stock of $164.2 million, $9.2 million of principal payments on term loans, $2.4 million payments for financing costs related to our revolving credit facility, and $0.8 million of payments for Notes conversions.

[0001628280-26-030777:mdna:150]
Cash used in financing activities of $42.1 million during the nine months ended March 29, 2025 was attributable to $76.5 million of proceeds from SMBC and Mizuho term loans and $8.3 million of proceeds from employee stock plans, offset by tax payments related to net share settlement of restricted stock of $36.3 million, payment for an intangible asset acquisition holdback of $1.0 million and $5.4 million of principal payments on term loans.

[0001628280-26-030777:mdna:151]
64
