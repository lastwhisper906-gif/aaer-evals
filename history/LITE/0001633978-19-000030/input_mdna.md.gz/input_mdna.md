# LITE MD&A — 0001633978-19-000030


## mdna

[0001633978-19-000030:mdna:1]
[same as prior period, unchanged from 0001633978-19-000002:mdna:1]

[0001633978-19-000030:mdna:2]
You should read the following discussion in conjunction with the unaudited condensed consolidated financial statements and the corresponding notes included elsewhere in this Quarterly Report on Form 10-Q (this “Quarterly Report”). This Management’s

[0001633978-19-000030:mdna:3]
Discussion and Analysis of Financial Condition and Results of Operations contains forward-looking statements. The matters discussed in these forward-looking statements are subject to risk, uncertainties and other factors that could cause actual results to differ materially from those made, projected or implied in the forward-looking statements. Please see “Risk Factors” and “Forward-Looking Statements” for a discussion of the uncertainties, risks and assumptions associated with these statements.

[0001633978-19-000030:mdna:4]
[same as prior period, unchanged from 0001633978-19-000002:mdna:3]

[0001633978-19-000030:mdna:5]
47

[0001633978-19-000030:mdna:6]
[same as prior period, unchanged from 0001633978-19-000002:mdna:5]

[0001633978-19-000030:mdna:7]
[same as prior period, unchanged from 0001633978-19-000002:mdna:6]

[0001633978-19-000030:mdna:8]
[same as prior period, unchanged from 0001633978-19-000002:mdna:7]

[0001633978-19-000030:mdna:9]
On December 10, 2018, we completed the acquisition of Oclaro, a provider of optical components and modules for the long-haul, metro and data center markets. In accordance with the terms of the Merger Agreement, each issued and outstanding share of Oclaro common stock was automatically converted into the right to receive (i) $5.60 in cash and (ii) 0.0636 of a share of Lumentum common stock. The total transaction consideration was $1.4 billion, which was funded through the issuance of Lumentum common stock, new debt (refer to “Note 6. Goodwill and Other Intangible Assets”), and cash balances of the combined company. Refer to “Note 5. Business Combination” in the notes to condensed consolidated financial statements for further discussion of the merger.

[0001633978-19-000030:mdna:10]
During the second quarter ended March 30, 2019, we recorded $20.9 million in restructuring and related charges in our condensed consolidated statements of operations, attributable to severance and employee related benefits associated with Oclaro’s executive severance and retention agreements. These retention agreements provide, under certain circumstances, for payments and benefits upon an involuntary termination of employment, including following a change in control of Oclaro. The payments and benefits payable under these arrangements in the event of a change in control of Oclaro are subject to a “double trigger,” meaning that both a change in control of Oclaro and a subsequent involuntary termination of employment are required. In other words, the change in control of Oclaro does not by itself trigger any payments or benefits. Instead, payments and benefits are paid only if the employment of the employee is subsequently terminated without “cause” (or the employee resigns for “good reason”)  during a specified period following the change in control. We  incurred total expense of  $20.9 million, of which $5.7 million relates to cash severance as part of our Restructuring expense, refer to “Note 14. Restructuring and Related Charges” and $15.2 million relates to acceleration of equity awards, refer to “Note 17. Stock-Based Compensation and Stock Plans.”

[0001633978-19-000030:mdna:11]
During the third quarter of fiscal 2019, we announced two business decisions.  First, we are rationalizing overlapping product lines and related teams from the acquisition which we expect to have minimal impact to revenue but should result in gross margin improvement over time.  Second, we are discontinuing various legacy Telecom product lines of the combined company whose growth and profitability outlook are inconsistent with our goals.  This product rationalization process will take approximately 9-12 months to minimize the impact to our customers. On the product lines we are exiting, we don’t expect much revenue decline over the next several quarters as we satisfy customer last time buy needs.  With the exit from the business of selling Datacom transceivers, we recorded an impairment charge of $30.7 million to our Long-lived assets that were not deemed to be useful and were retired from active use and classified as held-for-sale. These assets were valued at fair value less cost to sell. We also recorded Inventory write down charges of $20.8 million as cost of goods sold in our condensed consolidated statements of operations. These actions do not qualify as discontinued operations for disclosure purposes as they do not represent a strategic shift having a major effect on an entity’s operations and financial results,   refer to “Note 15. Impairment Charges.”

[0001633978-19-000030:mdna:12]
In March we also announced the sale of many of our Datacom product lines to CIG.  This transaction closed on April 18, 2019, refer to “Note 5. Business Combinations”.  Since the announcement of the transaction, we have seen increased interest from new customers for our Datacom chips as we will no longer be their competitors at the transceiver level.  We expect Datacom transceiver sales to ramp down to zero over the next few months, though we are trying to move as quickly as possible on this ramp down.  We are investing in new Datacom chip development and expect sales of these chips to customers serving the Datacom and 5G markets will grow over time.

[0001633978-19-000030:mdna:13]
[same as prior period, unchanged from 0001633978-19-000002:mdna:10]

[0001633978-19-000030:mdna:14]
[same as prior period, unchanged from 0001633978-19-000002:mdna:11]

[0001633978-19-000030:mdna:15]
[same as prior period, unchanged from 0001633978-19-000002:mdna:12]

[0001633978-19-000030:mdna:16]
[same as prior period, unchanged from 0001633978-19-000002:mdna:13]

[0001633978-19-000030:mdna:17]
[same as prior period, unchanged from 0001633978-19-000002:mdna:14]

[0001633978-19-000030:mdna:18]
[same as prior period, unchanged from 0001633978-19-000002:mdna:15]

[0001633978-19-000030:mdna:19]
[same as prior period, unchanged from 0001633978-19-000002:mdna:16]

[0001633978-19-000030:mdna:20]
[same as prior period, unchanged from 0001633978-19-000002:mdna:17]

[0001633978-19-000030:mdna:21]
[same as prior period, unchanged from 0001633978-19-000002:mdna:18]

[0001633978-19-000030:mdna:22]
[same as prior period, unchanged from 0001633978-19-000002:mdna:19]

[0001633978-19-000030:mdna:23]
Except for (i) the accounting policies for revenue recognition and the related accounts updated as a result of adopting ASU 2014-09 (Topic 606) and (ii) the change in our functional currency, from certain foreign currencies to the reporting currency, there have been no significant changes to our significant accounting policies as of and for the nine months ended March 30, 2019, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the year ended June 30, 2018. Refer to “Note 1. Description of Business and Summary of Significant Accounting Policies” for the details of ASU 2014-09 (Topic 606) adoption and our transition to the U.S. dollar as our functional currency. Management’s Discussion and Analysis of Financial Condition and Results of Operations contained in Part II, Item 7 of our Annual Report on Form 10-K for our fiscal year ended June 30, 2018 provides a more complete discussion of our critical accounting policies and estimates.

[0001633978-19-000030:mdna:24]
Recently Issued Accounting Pronouncements

[0001633978-19-000030:mdna:25]
Refer to “Note 2. Recently Issued Accounting Pronouncements” in the notes to condensed consolidated financial statements.

[0001633978-19-000030:mdna:26]
[same as prior period, unchanged from 0001633978-19-000002:mdna:24]

[0001633978-19-000030:mdna:27]
[same as prior period, unchanged from 0001633978-19-000002:mdna:25]

[0001633978-19-000030:mdna:28]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 30, 2019 |  | March 31, 2018 |  | March 30, 2019 |  | March 31, 2018 |
| Segment net revenue: |  |  |  |  |  |  |  |
| OpComms | 87.3 | % |  | 82.4 | % |  | 87.3 | % |  | 86.0 | % |
| Lasers | 12.7 |  |  | 17.6 |  |  | 12.7 |  |  | 14.0 |  |
| Net revenue | 100.0 |  |  | 100.0 |  |  | 100.0 |  |  | 100.0 |  |
| Cost of sales | 73.1 |  |  | 67.3 |  |  | 67.9 |  |  | 64.2 |  |
| Amortization of acquired developed technologies | 6.5 |  |  | 0.3 |  |  | 2.9 |  |  | 0.3 |  |
| Gross profit | 20.4 |  |  | 32.4 |  |  | 29.2 |  |  | 35.5 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 13.3 |  |  | 12.8 |  |  | 11.6 |  |  | 12.5 |  |
| Selling, general and administrative | 12.8 |  |  | 11.1 |  |  | 13.0 |  |  | 10.1 |  |
| Restructuring and related charges | 4.9 |  |  | — |  |  | 2.6 |  |  | 0.4 |  |
| Impairment charge | 7.0 |  |  | — |  |  | 2.7 |  |  | — |  |
| Total operating expenses | 38.0 |  |  | 23.9 |  |  | 29.9 |  |  | 23.0 |  |
| Income/(loss) from operations | (17.6 | ) |  | 8.5 |  |  | (0.7 | ) |  | 12.5 |  |
| Unrealized gain (loss) on derivative liability | — |  |  | (6.9 | ) |  | 0.8 |  |  | (0.9 | ) |
| Interest and other income (expense), net | (1.4 | ) |  | (0.7 | ) |  | (1.1 | ) |  | (0.9 | ) |
| Income/(loss) before income taxes | (19.0 | ) |  | 0.9 |  |  | (1.0 | ) |  | 10.7 |  |
| Provision for (benefit from) income taxes | (1.9 | ) |  | — |  |  | (0.1 | ) |  | (11.9 | ) |
| Net income/(loss) | (17.1 | )% |  | 0.9 | % |  | (0.9 | )% |  | 22.6 | % |

[0001633978-19-000030:mdna:29]
50

[0001633978-19-000030:mdna:30]
Financial Data for the three and nine months ended March 30, 2019 and March 31, 2018

[0001633978-19-000030:mdna:31]
[same as prior period, unchanged from 0001633978-19-000002:mdna:28]

[0001633978-19-000030:mdna:32]
|  | Three Months Ended |  |  |  |  |  | Nine Months Ended |  |  |  |  |
|  | March 30, 2019 |  | March 31, 2018 |  | Change |  | Percentage Change |  | March 30, 2019 |  | March 31, 2018 |  | Change |  | Percentage Change |
| Segment net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| OpComms | $ | 377.9 |  |  | $ | 246.3 |  |  | $ | 131.6 |  |  | 53.4 | % |  | $ | 1,013.4 |  |  | $ | 814.3 |  |  | $ | 199.1 |  |  | 24.5 | % |
| Lasers | 55.0 |  |  | 52.5 |  |  | 2.5 |  |  | 4.8 |  |  | 147.3 |  |  | 132.3 |  |  | 15.0 |  |  | 11.3 |  |
| Net revenue | $ | 432.9 |  |  | $ | 298.8 |  |  | $ | 134.1 |  |  | 44.9 | % |  | $ | 1,160.7 |  |  | $ | 946.6 |  |  | $ | 214.1 |  |  | 22.6 | % |
| Gross profit | $ | 88.3 |  |  | $ | 97.0 |  |  | $ | (8.7 | ) |  | (9.0 | )% |  | $ | 339.1 |  |  | $ | 336.6 |  |  | $ | 2.5 |  |  | 0.7 | % |
| Gross margin | 20.4 | % |  | 32.5 | % |  |  |  |  |  | 29.2 | % |  | 35.6 | % |  |  |  |  |
| Research and development | $ | 57.7 |  |  | $ | 38.2 |  |  | $ | 19.5 |  |  | 51.0 | % |  | $ | 135.1 |  |  | $ | 118.3 |  |  | $ | 16.8 |  |  | 14.2 | % |
| Percentage of net revenue | 13.3 | % |  | 12.8 | % |  |  |  |  |  | 11.6 | % |  | 12.5 | % |  |  |  |  |
| Selling, general and administrative | $ | 55.2 |  |  | $ | 33.2 |  |  | $ | 22.0 |  |  | 66.3 | % |  | $ | 150.9 |  |  | $ | 95.5 |  |  | $ | 55.4 |  |  | 58.0 | % |
| Percentage of net revenue | 12.8 | % |  | 11.1 | % |  |  |  |  |  | 13.0 | % |  | 10.1 | % |  |  |  |  |
| Restructuring and related charges | $ | 21.1 |  |  | $ | 0.1 |  |  | $ | 21.0 |  |  | n/a |  | $ | 30.2 |  |  | $ | 3.8 |  |  | $ | 26.4 |  |  | n/a |
| Percentage of net revenue | 4.9 | % |  | — | % |  |  |  |  |  | 2.6 | % |  | 0.4 | % |  |  |  |  |
| Impairment charge | $ | 30.7 |  |  | — |  |  | 30.7 |  |  | 100.0 | % |  | 30.7 |  |  | — |  |  | 30.7 |  |  | 100.0 | % |
| Percentage of net revenue | 7.0 | % |  | N/A |  |  |  |  |  |  | 2.6 | % |  | N/A |  |  |  |  |  |

[0001633978-19-000030:mdna:33]
[same as prior period, unchanged from 0001633978-19-000002:mdna:30]

[0001633978-19-000030:mdna:34]
Net revenue increased by $134.1 million, or 44.9%, during the three months ended March 30, 2019 compared to the three months ended March 31, 2018. This increase was primarily due to the recent acquisition of Oclaro and organic growth in our Telecom business.

[0001633978-19-000030:mdna:35]
OpComms net revenue increased by $131.6 million, or 53.4%, during the three months ended March 30, 2019 compared to the three months ended March 31, 2018, primarily driven by increased sales of  Telecom products of $120.8 million, $75.9 million due to the recent acquisition of Oclaro and $45.0 million due to organic growth primarily driven by ROADM’s.

[0001633978-19-000030:mdna:36]
Lasers net revenue increased by $2.5 million, or 4.8%, during the three months ended March 30, 2019 compared to the three months ended March 31, 2018, primarily due to increased sales of our kilowatt class fiber lasers, offset by lower sales of our solid state lasers products.

[0001633978-19-000030:mdna:37]
Net revenue increased by $214.1 million, or 22.6%, during the nine months ended March 30, 2019 compared to the nine months ended March 31, 2018. This increase was primarily due to the recent acquisition of Oclaro and organic growth in our Telecom business.

[0001633978-19-000030:mdna:38]
OpComms net revenue increased by $199.1 million, or 24.5%, during the nine months ended March 30, 2019 compared to the nine months ended March 31, 2018, primarily driven by increased sales of  Telecom Products of $215.6 million, $122.4 million due to organic growth primarily driven by ROADM’s and $93.2 million due to the recent acquisition of Oclaro.

[0001633978-19-000030:mdna:39]
Lasers net revenue increased by $15.0 million, or 11.3%, during the nine months ended March 30, 2019 compared to the nine months ended March 31, 2018, primarily due to increased sales of our kilowatt class fiber lasers, offset by lower sales of our solid state lasers products.

[0001633978-19-000030:mdna:40]
During the three and nine months ended March 30, 2019 and March 31, 2018, net revenue generated from a single customer which represented 10% or greater of total net revenue is summarized as follows:

[0001633978-19-000030:mdna:41]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 30, 2019 |  | March 31, 2018 |  | March 30, 2019 |  | March 31, 2018 |
| Customer A | 18.4 | % |  | 11.9 | % |  | 15.3 | % |  | 11.1 | % |
| Customer B | 13.4 | % |  | 24.9 | % |  | 22.7 | % |  | 33.3 | % |
| Customer C | 12.0 | % |  | 12.9 | % |  | 13.9 | % |  | 9.3 | % |

[0001633978-19-000030:mdna:42]
[same as prior period, unchanged from 0001633978-19-000002:mdna:39]

[0001633978-19-000030:mdna:43]
[same as prior period, unchanged from 0001633978-19-000002:mdna:40]

[0001633978-19-000030:mdna:44]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 30, 2019 |  | March 31, 2018 |  | March 30, 2019 |  | March 31, 2018 |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States | $ | 29.7 |  |  | 6.9 | % |  | $ | 26.8 |  |  | 9.0 | % |  | $ | 72.3 |  |  | 6.2 | % |  | $ | 86.3 |  |  | 9.1 | % |
| Mexico | 53.5 |  |  | 12.4 |  |  | 41.7 |  |  | 14.0 |  |  | 164.8 |  |  | 14.2 |  |  | 97.1 |  |  | 10.3 |  |
| Other Americas | 0.9 |  |  | 0.2 |  |  | 1.5 |  |  | 0.5 |  |  | 2.7 |  |  | 0.2 |  |  | 5.7 |  |  | 0.6 |  |
| Total Americas | $ | 84.1 |  |  | 19.4 | % |  | $ | 70.0 |  |  | 23.5 | % |  | $ | 239.8 |  |  | 20.6 | % |  | $ | 189.1 |  |  | 20.0 | % |
| Asia-Pacific: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Hong Kong | $ | 124.1 |  |  | 28.6 | % |  | $ | 38.7 |  |  | 13.0 | % |  | $ | 289.6 |  |  | 25.0 | % |  | $ | 133.3 |  |  | 14.1 | % |
| Japan | 50.0 |  |  | 11.6 |  |  | 34.1 |  |  | 11.4 |  |  | 129.2 |  |  | 11.1 |  |  | 157.6 |  |  | 16.6 |  |
| South Korea | 23.6 |  |  | 5.5 |  |  | 28.8 |  |  | 9.6 |  |  | 154.9 |  |  | 13.3 |  |  | 126.3 |  |  | 13.3 |  |
| Other Asia-Pacific | 98.4 |  |  | 22.7 |  |  | 103.9 |  |  | 34.8 |  |  | 234.4 |  |  | 20.2 |  |  | 266.1 |  |  | 28.1 |  |
| Total Asia-Pacific | $ | 296.1 |  |  | 68.4 | % |  | $ | 205.5 |  |  | 68.8 | % |  | $ | 808.1 |  |  | 69.6 | % |  | $ | 683.3 |  |  | 72.1 | % |
| EMEA | $ | 52.7 |  |  | 12.2 | % |  | $ | 23.3 |  |  | 7.8 | % |  | $ | 112.8 |  |  | 9.7 | % |  | $ | 74.2 |  |  | 7.8 | % |
| Total net revenue | $ | 432.9 |  |  |  |  |  | $ | 298.8 |  |  |  |  |  | $ | 1,160.7 |  |  |  |  |  | $ | 946.6 |  |  |  |  |

[0001633978-19-000030:mdna:45]
During the three months ended March 30, 2019 and March 31, 2018, net revenue from customers outside the United States, based on customer shipping location, represented  93.1% and 91.0% of net revenue, respectively. Our net revenue from Mexico increased due to increased demand for our ROADM products from one of our large customers who manufactures in Mexico,while net revenue from Hong Kong grew due to a change in shipment destination of a large portion of our 3D sensing products for mobile devices.

[0001633978-19-000030:mdna:46]
52

[0001633978-19-000030:mdna:47]
During the nine months ended March 30, 2019 and March 31, 2018, net revenue from customers outside the United States, based on customer shipping location, represented 93.8% and 90.9% of net revenue, respectively. Our net revenue from Mexico increased due to increased demand for our ROADM products from one of our large customers who manufactures in Mexico, while net revenue from Hong Kong grew due to a change in shipment destination of a large portion of our 3D sensing products for mobile devices.

[0001633978-19-000030:mdna:48]
[same as prior period, unchanged from 0001633978-19-000002:mdna:45]

[0001633978-19-000030:mdna:49]
[same as prior period, unchanged from 0001633978-19-000002:mdna:46]

[0001633978-19-000030:mdna:50]
The following table summarizes segment gross margin for the three and nine months ended March 30, 2019 and March 31, 2018 (in millions, except for percentages):

[0001633978-19-000030:mdna:51]
|  | Gross Profit |  | Gross Margin |  | Gross Profit |  | Gross Margin |
|  | Three Months Ended |  | Three Months Ended |  | Nine Months Ended |  | Nine Months Ended |
|  | March 30, 2019 |  | March 31, 2018 |  | March 30, 2019 |  | March 31, 2018 |  | March 30, 2019 |  | March 31, 2018 |  | March 30, 2019 |  | March 31, 2018 |
| OpComms | $ | 143.5 |  |  | $ | 83.1 |  |  | 38.0 | % |  | 33.7 | % |  | $ | 397.5 |  |  | $ | 317.1 |  |  | 39.2 | % |  | 38.9 | % |
| Lasers | 25.3 |  |  | 25.4 |  |  | 46.0 | % |  | 48.4 | % |  | 63.6 |  |  | 55.9 |  |  | 43.2 | % |  | 42.3 | % |
| Segment total | $ | 168.8 |  |  | $ | 108.5 |  |  | 39.0 | % |  | 36.3 | % |  | $ | 461.1 |  |  | $ | 373.0 |  |  | 39.7 | % |  | 39.4 | % |
| Unallocated corporate items (1) | (80.5 | ) |  | (11.5 | ) |  |  |  |  |  | (122.0 | ) |  | (36.4 | ) |  |  |  |  |
| Total | $ | 88.3 |  |  | $ | 97.0 |  |  | 20.4 | % |  | 32.5 | % |  | $ | 339.1 |  |  | $ | 336.6 |  |  | 29.2 | % |  | 35.6 | % |

[0001633978-19-000030:mdna:52]
[same as prior period, unchanged from 0001633978-19-000002:mdna:49]

[0001633978-19-000030:mdna:53]
Other charges of unallocated corporate items for the three and nine months ended March 30, 2019 primarily include set-up costs of our facility in Thailand, including costs of transferring product lines to Thailand of $12.0 million and $37.8 million, respectively. During each of  the three and nine months ended March 31, 2018, “other charges” of unallocated corporate items primarily consisted of set-up costs of our facility in Thailand of $9.1 million and $15.9 million respectively.

[0001633978-19-000030:mdna:54]
[same as prior period, unchanged from 0001633978-19-000002:mdna:51]

[0001633978-19-000030:mdna:55]
Gross margin during the three months ended March 30, 2019 decreased to 20.4% from 32.5% during the three months ended March 31, 2018. The decrease was primarily due to amortization costs related to the recent acquisition of Oclaro and inventory write down charges of $20.8 million due to exit of Datacom module product line.

[0001633978-19-000030:mdna:56]
Gross margin during the nine months ended March 30, 2019 decreased to 29.2% from 35.6% during the nine months ended March 31, 2018. The decrease was primarily due to amortization costs related to the recent acquisition of Oclaro as well as increased costs related to startup and inventory write down charges of $20.8 million due to exit of Datacom module product line.

[0001633978-19-000030:mdna:57]
[same as prior period, unchanged from 0001633978-19-000002:mdna:54]

[0001633978-19-000030:mdna:58]
[same as prior period, unchanged from 0001633978-19-000002:mdna:55]

[0001633978-19-000030:mdna:59]
[same as prior period, unchanged from 0001633978-19-000002:mdna:56]

[0001633978-19-000030:mdna:60]
OpComms gross margin during the three months ended March 30, 2019 increased to 38.0% from 33.7% during the three months ended March 31, 2018. This increase was primarily due to increased sales of our ROADM products, which have higher gross margins than the averages for this segment as well as increased sales of our transmission products due to the recent acquisition of Oclaro which have higher gross margins than previous transmission products.

[0001633978-19-000030:mdna:61]
OpComms gross margin during the nine months ended March 30, 2019 increased to 39.2% from 38.9% during the nine months ended March 31, 2018. This increase was primarily due to increased sales of our ROADM products, which have higher gross margins than the averages for this segment as well as increased sales of our Transmission products due to the recent acquisition of Oclaro which have higher gross margins than previous transmission products.  This was partially offset by decreased sales of our 3D sensing products which have higher gross margins than the averages for this segment.

[0001633978-19-000030:mdna:62]
[same as prior period, unchanged from 0001633978-19-000002:mdna:59]

[0001633978-19-000030:mdna:63]
Lasers gross margin during the three months ended March 30, 2019 decreased to 46.0% from 48.4% during the three months ended March 31, 2018. This decrease was primarily due to decreased sales of our Solid State products which have higher gross margins than the averages for this segment. This was partially offset by increased revenue and manufacturing utilization for our kilowatt class fiber products.

[0001633978-19-000030:mdna:64]
Lasers gross margin during the nine months ended March 30, 2019 increased to 43.2% from 42.3% during the nine months ended March 31, 2018. This increase was primarily due to increased revenue and manufacturing utilization for our kilowatt class fiber lasers products partially offset by decreased sales of our Solid State products.

[0001633978-19-000030:mdna:65]
[same as prior period, unchanged from 0001633978-19-000002:mdna:62]

[0001633978-19-000030:mdna:66]
R&D expense increased by $19.5 million, or 51.0%, during the three months ended March 30, 2019 compared to the three months ended March 31, 2018. The increase in R&D expense was primarily due to the recent acquisition of Oclaro. Employee-related costs, which includes variable incentive compensation was higher and  we invested in key product lines and R&D materials.

[0001633978-19-000030:mdna:67]
R&D expense increased by $16.8 million, or 14.2%, during the nine months ended March 30, 2019 compared to the nine months ended March 31, 2018. The increase in R&D expense was primarily due to the recent acquisition of Oclaro. Employee-related costs, which includes variable incentive compensation was higher and we invested in key product lines.

[0001633978-19-000030:mdna:68]
[same as prior period, unchanged from 0001633978-19-000002:mdna:65]

[0001633978-19-000030:mdna:69]
[same as prior period, unchanged from 0001633978-19-000002:mdna:66]

[0001633978-19-000030:mdna:70]
SG&A expense increased by $22.0 million, or 66.3%, during the three months ended March 30, 2019 compared to the three months ended March 31, 2018. The increase was primarily attributable to the recent acquisition of Oclaro, including an incremental stock-based compensation charge of $3.3 million and a $3.6 million increase in amortization of intangibles.

[0001633978-19-000030:mdna:71]
SG&A expense increased by $55.4 million, or 58.0%, during the nine months ended March 30, 2019 compared to the nine months ended March 31, 2018. The increase was primarily attributable to $13.3 million in charges related to the acceleration of equity awards under certain Oclaro executive severance and retention agreements and $9.0 million related to the success fee on the closing of the Oclaro transaction. In addition to the recent acquisition of Oclaro caused an increase in payroll related expense of $6.0 million, which includes an increase in variable incentive compensation of $1.2 million, incremental stock-based compensation charge of $5.6 million and $3.6 million of costs related to the amortization of intangibles.

[0001633978-19-000030:mdna:72]
We expect to experience in the future certain non-core expenses, such as mergers and acquisition-related expenses and litigation expenses, which will likely increase our SG&A expenses and potentially impact our profitability expectations in any particular quarter.

[0001633978-19-000030:mdna:73]
[same as prior period, unchanged from 0001633978-19-000002:mdna:70]

[0001633978-19-000030:mdna:74]
[same as prior period, unchanged from 0001633978-19-000002:mdna:71]

[0001633978-19-000030:mdna:75]
During the three and nine months ended March 30, 2019, we recorded $21.1 million and $30.2 million, respectively, in restructuring and related charges in our condensed consolidated statements of operations, primarily attributable to severance and employee related benefits associated with the wind down of operations for Lithium Niobate modulators and Datacom modules resulting in an $18.0 million severance charges and $1.6 million of lease restructuring charges. During the three and nine months ended  March 30, 2019, we also recorded restructuring charges primarily associated with acquisition related synergies.  In addition, the nine month period charges included severance and employee related benefits associated with Oclaro’s executive severance and retention agreements. These retention agreements provide, under certain circumstances, for payments and benefits upon an involuntary termination of employment.

[0001633978-19-000030:mdna:76]
Refer to “Note 14. Restructuring and Related Charges” in the notes to condensed consolidated financial statements.

[0001633978-19-000030:mdna:77]
During the three and nine months ended March 31, 2018, we recorded $0.1 million and $3.8 million, respectively, in restructuring and related charges in our condensed consolidated statements of operations, primarily attributable to costs to vacate facilities, temporary labor and employee-related benefits, as well as costs for materials used in set up and production activities. We incurred no additional costs related to severance during the three and nine months ended March 31, 2018.

[0001633978-19-000030:mdna:78]
Impairment charges

[0001633978-19-000030:mdna:79]
In March 2019 we announced our plan to discontinue the development of future Datacom transceiver products which impacted the Milpitas and Shenzhen Datacom module teams. While we expect strong growth in Datacom volumes in the future, the market at the transceiver level is gross margin challenged due to extreme competition.  Following the Oclaro acquisition, we have a differentiated leadership position across a range of photonic chips on which the Datacom, wireless, and access markets critically rely.

[0001633978-19-000030:mdna:80]
During each of the three and nine months ended March 30, 2019, we recorded $30.7 million in long lived asset impairment charges in connection with the above plan. Refer to “Note 9. Balance Sheet and Other Details” and “Note 15. Impairment Charges” in the notes to condensed consolidated financial statements.

[0001633978-19-000030:mdna:81]
[same as prior period, unchanged from 0001633978-19-000002:mdna:75]

[0001633978-19-000030:mdna:82]
[same as prior period, unchanged from 0001633978-19-000002:mdna:76]

[0001633978-19-000030:mdna:83]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 30, 2019 |  | March 31, 2018 |  | March 30, 2019 |  | March 31, 2018 |
| Interest expense | $ | (11.3 | ) |  | $ | (4.6 | ) |  | $ | (24.9 | ) |  | $ | (13.6 | ) |
| Foreign exchange gains (losses), net | (1.0 | ) |  | (0.1 | ) |  | (1.0 | ) |  | (0.8 | ) |
| Interest income | 3.9 |  |  | 2.5 |  |  | 10.0 |  |  | 5.7 |  |
| Other income (expense), net | 2.3 |  |  | 0.1 |  |  | 2.7 |  |  | — |  |
| Interest and other income (expense), net | $ | (6.1 | ) |  | $ | (2.1 | ) |  | $ | (13.2 | ) |  | $ | (8.7 | ) |

[0001633978-19-000030:mdna:84]
For the three months ended March 30, 2019, interest and other income (expense), net increased by $4.0 million in expense as compared to the three months ended March 31, 2018, mainly driven by ticking fees and interest expense on our term loan that we entered into during the second quarter of fiscal 2019, partially offset by other income.

[0001633978-19-000030:mdna:85]
For the nine months ended March 30, 2019, interest and other income (expense), net increased by $4.5 million in expense as compared to the nine months ended March 31, 2018, mainly driven by increased interest expense on our term loan that we entered into during the second quarter of fiscal 2019, partially offset by interest income.

[0001633978-19-000030:mdna:86]
[same as prior period, unchanged from 0001633978-19-000002:mdna:80]

[0001633978-19-000030:mdna:87]
Unrealized gain (loss) on Series A Preferred Stock derivative liability amounted to zero and $8.8 million for the three and nine months ended March 30, 2019, respectively, as compared to $(20.7) million and $(8.6) million for the three and nine months ended March 31, 2018, respectively. The changes are primarily related to the change in the price of our underlying common stock and are reflected in the condensed consolidated statements of operations as “unrealized gain (loss) on derivative liability”.  We do not expect any gains or loss in the future due to the conversion of the Series A Preferred Stock to common stock on November 2, 2018. For further discussion of our derivative liability, see “Note 12. Non-Controlling Interest Redeemable Convertible Preferred Stock and Derivative Liability” in the notes to condensed consolidated financial statements.

[0001633978-19-000030:mdna:88]
[same as prior period, unchanged from 0001633978-19-000002:mdna:82]

[0001633978-19-000030:mdna:89]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 30, 2019 |  | March 31, 2018 |  | March 30, 2019 |  | March 31, 2018 |
| Provision for (benefit from) income taxes | $ | (8.2 | ) |  | $ | — |  |  | $ | (1.6 | ) |  | $ | (112.9 | ) |

[0001633978-19-000030:mdna:90]
The comparability of our operating results in the first three quarters of fiscal 2019 compared to the corresponding prior year period was impacted by the U.S. Tax Cuts and Jobs Act of 2017 (the “Tax Act”), which was enacted on December 22, 2017. The Tax Act introduced significant changes to U.S. income tax law including reducing the U.S. federal statutory tax rate from 35% to 21% and imposing new taxes on certain foreign-sourced earnings and certain intercompany payments. Due to the timing of the enactment and the complexity involved in applying the provisions of the Tax Act, we made reasonable estimates of the effects and recorded provisional amounts in our financial statements as of fiscal 2018 in accordance with SEC Staff Accounting Bulletin No. 118 (“SAB 118”). During the period ended December 29, 2018, we completed our accounting for the Tax Act with no material adjustment to our provisional estimates recorded.

[0001633978-19-000030:mdna:91]
We recorded a tax benefit of $(8.2) million and $(1.6) million for the three months ended March 30, 2019, respectively. Our estimated effective tax rate for the fiscal 2019 differs from the 21% U.S. statutory rate primarily due to the income tax benefit of the earnings of our foreign subsidiaries being taxed at rates that differ from the U.S. statutory rate as well as the U.S. federal R&D tax credit, partially offset by the income tax expense from non-deductible stock-based compensation and the tax effect of Global Intangible Low-Taxed Income (“GILTI”), Base Erosion and Anti-Abuse Tax (“BEAT”) and subpart F inclusion.

[0001633978-19-000030:mdna:92]
We recorded an immaterial tax benefit and a tax benefit of  $112.9 million for the three and nine months ended March 31, 2018, respectively.

[0001633978-19-000030:mdna:93]
We operate under a tax holiday in Thailand, which could be effective through fiscal year 2025, and may be extended if certain additional requirements are satisfied. The tax holiday is conditional upon our meeting certain employment and investment thresholds. The tax holiday had an insignificant impact on our foreign taxes and on net income per share (diluted) for the fiscal year ended June 30, 2018 and for the three and nine months ended March 30, 2019. Refer to “Note 16. Income Taxes”.

[0001633978-19-000030:mdna:94]
[same as prior period, unchanged from 0001633978-19-000002:mdna:92]

[0001633978-19-000030:mdna:95]
The following table summarizes our contractual obligations as of March 30, 2019, and the effect such obligations are expected to have on our liquidity and cash flow over the next five years (in millions):

[0001633978-19-000030:mdna:96]
|  | Payments due by period |
|  | Total |  | Less than 1 year |  | 1 - 3 years |  | 3 - 5 years |  | More than 5 years |
| Contractual Obligations |  |  |  |  |  |  |  |  |  |
| Acquisition contingencies (1) | $ | 3.0 |  |  | $ | 3.0 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Asset retirement obligations | 5.4 |  |  | — |  |  | 1.0 |  |  | 0.6 |  |  | 3.8 |  |
| Capital lease obligations (2) | 3.3 |  |  | 3.2 |  |  | 0.1 |  |  | — |  |  | — |  |
| Operating lease obligations (2) | 105.2 |  |  | 18.7 |  |  | 30.4 |  |  | 41.4 |  |  | 14.7 |  |
| Pension plan contributions (3) | 2.4 |  |  | 2.4 |  |  | — |  |  | — |  |  | — |  |
| Purchase obligations (4) | 208.0 |  |  | 206.0 |  |  | 1.9 |  |  | 0.1 |  |  | — |  |
| Term loan - principal (5) | 498.7 |  |  | 5.0 |  |  | 10.0 |  |  | 10.0 |  |  | 473.7 |  |
| Term loan - interest (5) | 158.0 |  |  | 24.3 |  |  | 47.8 |  |  | 46.9 |  |  | 39.0 |  |
| Convertible notes - principal (6) | 450.0 |  |  | — |  |  | — |  |  | — |  |  | 450.0 |  |
| Convertible notes - interest (7) | 5.6 |  |  | 1.2 |  |  | 2.2 |  |  | 2.2 |  |  | — |  |
| Total | $ | 1,439.6 |  |  | $ | 263.8 |  |  | $ | 93.4 |  |  | $ | 101.2 |  |  | $ | 981.2 |  |

[0001633978-19-000030:mdna:97]
(1) Refer to “Note 11. Fair Value Measurements” in the notes to condensed consolidated financial statements.

[0001633978-19-000030:mdna:98]
(2) Refer to “Note 18. Commitments and Contingencies” in the notes to condensed consolidated financial statements.

[0001633978-19-000030:mdna:99]
[same as prior period, unchanged from 0001633978-19-000002:mdna:97]

[0001633978-19-000030:mdna:100]
[same as prior period, unchanged from 0001633978-19-000002:mdna:98]

[0001633978-19-000030:mdna:101]
[same as prior period, unchanged from 0001633978-19-000002:mdna:99]

[0001633978-19-000030:mdna:102]
(4) Purchase obligations represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Refer to “Note 18. Commitments and Contingencies” in the notes to condensed consolidated financial statements.

[0001633978-19-000030:mdna:103]
(5) We incurred indebtedness in an aggregate principal amount of $500.0 million pursuant to a senior secured Term Loan Facility that we entered into in connection with the closing of the Oclaro acquisition on December 10, 2018. The amounts of interest included in the table above is based on current interest rates.

[0001633978-19-000030:mdna:104]
(6) Refer to “Note 13. Convertible Notes” in the notes to condensed consolidated financial statements.

[0001633978-19-000030:mdna:105]
(7) Includes interest on our 0.25% Convertible Notes due in 2024 through March 2024 as we have the right to redeem the 2024 Notes in whole or in part at any time on or after March 15, 2024. Refer to “Note 13. Convertible Notes” in the notes to condensed consolidated financial statements.

[0001633978-19-000030:mdna:106]
As of March 30, 2019, our other non-current liabilities also include $6.7 million of unrecognized tax benefit for uncertain tax positions. We are unable to reliably estimate the timing of future payments related to uncertain tax positions and therefore have excluded them from the preceding table.

[0001633978-19-000030:mdna:107]
[same as prior period, unchanged from 0001633978-19-000002:mdna:105]

[0001633978-19-000030:mdna:108]
[same as prior period, unchanged from 0001633978-19-000002:mdna:106]

[0001633978-19-000030:mdna:109]
[same as prior period, unchanged from 0001633978-19-000002:mdna:107]

[0001633978-19-000030:mdna:110]
[same as prior period, unchanged from 0001633978-19-000002:mdna:108]

[0001633978-19-000030:mdna:111]
As of March 30, 2019 and June 30, 2018, our cash and cash equivalents of $357.3 million and $397.3 million, respectively, were largely held in the United States. The total amount of cash outside the United States as of March 30, 2019 was $102.8 million, which was primarily held by entities incorporated in Japan, the United Kingdom, Thailand, the British Virgin Islands, Hongkong and Switzerland. Although the cash currently held in the United States as well as the cash generated in the United States from future operations is expected to cover our normal operating requirements, a substantial amount of additional cash could be required for other purposes, such as capital expenditures to support our business and growth, including costs associated with increasing internal manufacturing capabilities, such as our new Thailand facility, strategic transactions and partnerships, and acquisitions, such as our acquisition of Oclaro. Our intent is to indefinitely reinvest funds held outside the United States, except for the funds held in the Cayman Islands and Hong Kong, and our current plans do not demonstrate a need to repatriate them to fund our domestic operations. However, if in the future, we encounter a significant need for liquidity domestically or at a particular location that we cannot fulfill through borrowings, equity offerings, or other internal or external sources, or the cost to bring back the money is insignificant from a tax perspective, we may determine that cash repatriations are necessary or desirable. Repatriation could result in additional material taxes. These factors may cause us to have an overall tax rate higher than other companies or higher than our tax rates have been in the past. If conditions warrant, we may seek to obtain additional financing through debt or equity sources. To the extent we issue additional shares, our existing stockholders may be diluted. However, any such financing may not be available on terms favorable to us, or may not be available at all.

[0001633978-19-000030:mdna:112]
As of March 30, 2019, our consolidated balance of cash and cash equivalents, including cash classified within assets held -for-sale, decreased by $39.0 million, to $358.3 million from $397.3 million as of June 30, 2018. The decrease in cash and cash equivalents was mainly due to cash used in investing activities of $725.3 million, principally related to cash used to acquire Oclaro; partially offset by cash provided by financing activities of $484.1 million, primarily related to $490.8 million in proceeds from a term loan, net of debt issuance costs, used to fund the Oclaro acquisition, and cash provided by operating activities of $202.4 million during the nine months ended March 30, 2019.

[0001633978-19-000030:mdna:113]
[same as prior period, unchanged from 0001633978-19-000002:mdna:111]

[0001633978-19-000030:mdna:114]
Cash provided by operating activities was $202.4 million during the nine months ended March 30, 2019. Our net loss was $10.6 million for the nine months ended March 30, 2019. Cash provided by operating activities was generated primarily from  $210.0 million of non-cash items (such as depreciation, stock-based compensation, unrealized (gain)/loss on derivative liability, amortization of intangibles, amortization of discount on the 2024 Notes, amortization of the debt issuance costs on the term loan, amortization of fair value adjustment in connection with the acquisition of Oclaro, net amortization of discounts and premium on investments, and impairment charges and others), and $3.0 million of changes in our operating assets and liabilities.

[0001633978-19-000030:mdna:115]
Cash provided by operating activities was $209.9 million during the nine months ended March 31, 2018, primarily resulting from $214.6 million of net income, offset by $11.4 million of non-cash items (such as depreciation, stock-based compensation, amortization of intangibles, amortization of discount on the 2024 Notes, net of the release of the valuation allowance and unrealized loss on derivative liability), and $6.7 million of changes in our operating assets and liabilities. Changes in our operating assets and liabilities related primarily to an increase in accrued expenses and other current and non-current liabilities of $12.9 million offset by a decrease in accounts payable of $15.9 million.

[0001633978-19-000030:mdna:116]
[same as prior period, unchanged from 0001633978-19-000002:mdna:115]

[0001633978-19-000030:mdna:117]
Cash used in investing activities of $725.3 million during the nine months ended March 30, 2019, was primarily attributable to $619.8 million in cash payments to acquire all outstanding shares of common stock of Oclaro, net of cash received through the acquisition of Oclaro. In addition we had capital expenditures of $80.5 million, payment for asset acquisition of $1.3 million, and purchase of short-term investments, net of sales of  $23.7 million

[0001633978-19-000030:mdna:118]
Cash used in investing activities of $308.7 million during the nine months ended March 31, 2018, was primarily attributable to capital expenditures of $72.9 million and purchases of short-term investments, net of sales and maturities of $235.8 million.

[0001633978-19-000030:mdna:119]
[same as prior period, unchanged from 0001633978-19-000002:mdna:118]

[0001633978-19-000030:mdna:120]
Cash provided by financing activities of $484.1 million during the nine months ended March 30, 2019, primarily resulted from $490.8 million of proceeds from a term loan, net of debt issuance costs, used to partially finance the Oclaro acquisition, $4.7 million from the issuance of common stock under the employee stock plan; partially offset by the repayment of capital lease obligations of $6.1 million, tax payments related to restricted stock of $2.4 million,  a payment of an acquisition related holdback of $1.0 million, and dividend payments on our Series A Preferred Stock of $0.7 million.

[0001633978-19-000030:mdna:121]
During the nine months ended March 31, 2018, cash provided by financing activities of $1.9 million, resulted primarily from the issuance of common stock under the employee stock plan.

[0001633978-19-000030:mdna:122]
[same as prior period, unchanged from 0001633978-19-000002:mdna:121]

[0001633978-19-000030:mdna:123]
We believe that our cash and cash equivalents as of March 30, 2019, and cash flows from our operating activities will be sufficient to meet our liquidity and capital spending requirements for at least the next 12 months. However, if market conditions are favorable, we may evaluate alternatives to opportunistically pursue additional financing.

[0001633978-19-000030:mdna:124]
[same as prior period, unchanged from 0001633978-19-000002:mdna:123]

[0001633978-19-000030:mdna:125]
[same as prior period, unchanged from 0001633978-19-000002:mdna:124]

[0001633978-19-000030:mdna:126]
[same as prior period, unchanged from 0001633978-19-000002:mdna:125]

[0001633978-19-000030:mdna:127]
[same as prior period, unchanged from 0001633978-19-000002:mdna:126]

[0001633978-19-000030:mdna:128]
[same as prior period, unchanged from 0001633978-19-000002:mdna:127]

[0001633978-19-000030:mdna:129]
[same as prior period, unchanged from 0001633978-19-000002:mdna:128]

[0001633978-19-000030:mdna:130]
[same as prior period, unchanged from 0001633978-19-000002:mdna:129]

[0001633978-19-000030:mdna:131]
[same as prior period, unchanged from 0001633978-19-000002:mdna:130]

[0001633978-19-000030:mdna:132]
[same as prior period, unchanged from 0001633978-19-000002:mdna:131]

[0001633978-19-000030:mdna:133]
[same as prior period, unchanged from 0001633978-19-000002:mdna:132]

[0001633978-19-000030:mdna:134]
[same as prior period, unchanged from 0001633978-19-000002:mdna:133]

[0001633978-19-000030:mdna:135]
[same as prior period, unchanged from 0001633978-19-000002:mdna:134]

[0001633978-19-000030:mdna:136]
[same as prior period, unchanged from 0001633978-19-000002:mdna:135]

[0001633978-19-000030:mdna:137]
[same as prior period, unchanged from 0001633978-19-000002:mdna:136]
