# LITE notes — 0001633978-19-000030


## lite:AssetAcquisitionDisclosureTextBlock

[0001633978-19-000030:notes:1]
Note 8. Asset Acquisition

[0001633978-19-000030:notes:2]
On March 30, 2018, we entered into a Transition Services Agreement (“TSA”) with one of our contract manufacturers to wind down the production of our products at their facility in China and to facilitate an orderly transition of manufacturing to either our manufacturing facility in Thailand or our third party contract manufacturers, including the purchase of the manufacturing equipment. Under the terms of the TSA, we are required to pay $5.3 million in cash upon completion of certain milestones related to the purchase of equipment. During the nine months ended March 30, 2019, we paid $1.3 million and accrued an additional $3.0 million for the manufacturing equipment acquired under this TSA. This amount is included in machinery and equipment within property, plant and equipment in our condensed consolidated balance sheet as of March 30, 2019.

[0001633978-19-000030:notes:3]
[same as prior period, unchanged from 0001633978-19-000002:notes:3]


## lite:NoncontrollingInterestAndDerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001633978-19-000030:notes:4]
Note 12. Non-Controlling Interest Redeemable Convertible Preferred Stock and Derivative Liability

[0001633978-19-000030:notes:5]
On July 31, 2015, our wholly-owned subsidiary, Lumentum Inc., issued 40,000 shares of its Series A Preferred Stock to Viavi Solutions Inc. (“Viavi”). Pursuant to a securities purchase agreement between us, Viavi and Amada Holdings Co., Ltd. (“Amada”), 35,805 shares of Series A Preferred Stock were sold by Viavi to Amada in August 2015. The remaining 4,195 shares of the Series A Preferred Stock were canceled.

[0001633978-19-000030:notes:6]
As of June 30, 2018, the Series A Preferred Stock was referred to as our Non-Controlling Interest Redeemable Convertible Preferred Stock within these condensed consolidated financial statements, and was recorded at $35.8 million.

[0001633978-19-000030:notes:7]
On October 15, 2018, we issued a 30-day notice of intent to the holders of Series A Preferred Stock to convert all shares of Series A Preferred Stock at a conversion price equal to the Issuance Value divided by $24.63 plus the accrued and unpaid dividends on each share and any past due dividends, whether or not authorized or declared. On November 2, 2018, we received notice from Amada of their intent to convert the Series A Preferred Stock and we issued 1.5 million shares of our common stock to Amada upon the conversion of the 35,805 shares of Series A Preferred Stock and recorded $79.4 million in additional paid in capital in the condensed consolidated balance sheet as of March 30, 2019.

[0001633978-19-000030:notes:8]
Up through the date of conversion, the Series A Preferred Stock conversion feature is bifurcated from the Series A Preferred Stock and accounted for separately as a derivative liability. The derivative liability is measured at fair value each reporting period, and at the date of conversion, with the change in fair value recorded in the condensed consolidated statements of operations. We estimated the fair value of the embedded derivative using the binomial lattice model. We applied the binomial lattice model to value the embedded derivative using a “with-and-without method,” where the value of the Series A Preferred Stock, including the embedded derivative, is defined as the “with”, and the value of the Series A Preferred Stock, excluding the embedded derivative, is defined as the “without”. The binomial lattice model requires the following inputs: (i) the Company's common stock price; (ii) conversion price; (iii) term; (iv) yield; (v) recovery rate for the Series A Preferred Stock; (vi) estimated stock volatility; and (vii) risk-free rate. The fair value of the embedded derivative was determined using Level 3 inputs under the fair value hierarchy (unobservable inputs). Changes in the inputs into this valuation model have a material impact in the estimated fair value of the embedded derivative. For example, a decrease (increase) in the stock price and the volatility results in a decrease (increase) in the estimated fair value of the embedded derivative. The changes in the fair value of the bifurcated embedded derivative for the Series A Preferred Stock are primarily related to the change in the price of our common stock and are reflected in the condensed consolidated statements of operations as “Unrealized gain (loss) on derivative liability.”

[0001633978-19-000030:notes:9]
Up through the date of conversion, holders of Series A Preferred Stock, in preference to holders of common stock or any other class or series of our outstanding capital stock ranking in any such event junior to the Series A Preferred Stock, were entitled to receive, when and as declared by the board of directors, quarterly cumulative cash dividends at the annual rate of 2.5% of the Issuance Value per share on each outstanding share of Series A Preferred Stock. The accrued dividends were payable on March 31, June 30, September 30 and December 31 of each year commencing on September 30, 2015. The accrued dividends as of November 2, 2018, the effective date of the conversion of all outstanding Series A Preferred Stock, and June 30, 2018 were $0.3 million and $0.4 million, respectively. During the three and nine months ended March 30, 2019, we paid zero and $0.7 million, respectively, in dividends to the holders of Series A Preferred Stock. During the three and nine months ended March 31, 2018, we paid $0.5 million and $0.7 million, respectively, in dividends to the holders of Series A Preferred Stock.

[0001633978-19-000030:notes:10]
Prior to the conversion of the Series A Preferred Stock on November 2, 2018, we marked to market the embedded derivative, resulting in a gain of $10.9 million. The gain (loss) on derivative liability for the Series A Preferred Stock up through the conversion date of November 2, 2018, amounted to a $10.9 million gain with zero and $8.8 million gain recorded for the three and nine months ended March 30, 2019, respectively. In connection with the conversion of the Series A Preferred Stock we also recorded $79.4 million in additional paid in capital within the condensed consolidated balance sheet as of March 30, 2019.

[0001633978-19-000030:notes:11]
Unrealized gain (loss) on derivative liability for the Series A Preferred Stock amounted to a $(20.7) million loss and a $(8.6) million loss for the three and nine months ended March 31, 2018, respectively.

[0001633978-19-000030:notes:12]
The following table provides a reconciliation of the fair value of the embedded derivative for the Series A Preferred Stock for the three and nine months ended March 30, 2019 and March 31, 2018 (in millions):

[0001633978-19-000030:notes:13]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 30, 2019 |  | March 31, 2018 |  | March 30, 2019 |  | March 31, 2018 |
| Balance as of beginning of period | $ | — |  |  | $ | (39.5 | ) |  | $ | 52.4 |  |  | $ | (51.6 | ) |
| Unrealized (gain) loss on the Series A Preferred Stock derivative liability up through the conversion date | — |  |  | (20.7 | ) |  | (8.8 | ) |  | (8.6 | ) |
| Settlement of the derivative liability upon conversion of Series A Preferred Stock | — |  |  | — |  |  | (43.6 | ) |  | — |  |
| Balance as of end of period | $ | — |  |  | $ | (60.2 | ) |  | $ | — |  |  | $ | (60.2 | ) |


## lite:ScheduleOfAssetImpairmentChargesTableTextBlock

[0001633978-19-000030:notes:14]
The following table summarizes the activity of  impairment charges during the three and nine months ended March 30, 2019 and March 31, 2018 (in millions):

[0001633978-19-000030:notes:15]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 30, 2019 |  | March 31, 2018 |  | March 30, 2019 |  | March 31, 2018 |
| Impairment charges | $ | 30.7 |  |  | $ | — |  |  | $ | 30.7 |  |  | $ | — |  |


## us-gaap:AssetImpairmentChargesTextBlock

[0001633978-19-000030:notes:16]
Note 15. Impairment Charges

[0001633978-19-000030:notes:17]
As previously discussed in “Note 14. Restructuring and Related Charges”, we have announced plans to discontinue the development of future Datacom transceiver products. As a result of these actions we recorded an impairment charge of $30.7 million to our Long-lived assets that were not deemed to be useful and were retired from active use and classified as held-for-sale. These assets were valued at fair value less cost to sell. We classified the assets within Level 3 of the fair value hierarchy and applied fair value accounting on a non-recurring basis.

[0001633978-19-000030:notes:18]
We also recorded Inventory write down charges of $20.8 million as cost of goods sold in our condensed consolidated statements of operations.

[0001633978-19-000030:notes:19]
These actions do not qualify as discontinued operations for disclosure purposes as they do not represent a strategic shift having a major effect on an entity’s operations and financial results.

[0001633978-19-000030:notes:20]
Refer to “Note 5. Business Combination”, “Note 9. Balance Sheet and Other Details”, “Note 11. Fair Value Measurements” and “Note 14. Restructuring and Related Charges” for details.


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001633978-19-000030:notes:21]
[same as prior period, unchanged from 0001633978-19-000002:notes:4]

[0001633978-19-000030:notes:22]
[same as prior period, unchanged from 0001633978-19-000002:notes:5]

[0001633978-19-000030:notes:23]
On December 10, 2018, the Company completed its merger with Oclaro, Inc. (“Oclaro”), a provider of optical components and modules for the long-haul, metro and data center markets. Our condensed consolidated financial statements include the operating results of Oclaro for the period from the date of acquisition through March 30, 2019. Refer to “Note 5. Business Combination” for further discussion of the merger.


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0001633978-19-000030:notes:24]
[same as prior period, unchanged from 0001633978-19-000002:notes:7]

[0001633978-19-000030:notes:25]
|  | Nine Months Ended |
|  | March 30, 2019 |  | March 31, 2018 |
| Net revenue | $ | 1,374.8 |  |  | $ | 1,368.8 |  |
| Net income (loss) | (18.2 | ) |  | 161.5 |  |


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001633978-19-000030:notes:26]
[same as prior period, unchanged from 0001633978-19-000002:notes:29]

[0001633978-19-000030:notes:27]
[same as prior period, unchanged from 0001633978-19-000002:notes:30]

[0001633978-19-000030:notes:28]
[same as prior period, unchanged from 0001633978-19-000002:notes:31]

[0001633978-19-000030:notes:29]
[same as prior period, unchanged from 0001633978-19-000002:notes:32]

[0001633978-19-000030:notes:30]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Our fiscal 2019 is a 52-week year ending on June 29, 2019, with the quarter ended March 30, 2019 being a 13-week quarterly period. Our fiscal 2018 was a 52-week year that ended on June 30, 2018, with the quarter ended March 31, 2018 being a 13-week quarterly period.

[0001633978-19-000030:notes:31]
[same as prior period, unchanged from 0001633978-19-000002:notes:34]

[0001633978-19-000030:notes:32]
[same as prior period, unchanged from 0001633978-19-000002:notes:35]

[0001633978-19-000030:notes:33]
Certain  prior  period  amounts  have  been  reclassified  to  conform  to  the  current  year  presentation  in  the  notes  to  the  condensed  consolidated  financial statements.  The  reclassification  of  the  prior  period  amounts  did  not  impact  previously  reported  condensed  consolidated  financial  statements.

[0001633978-19-000030:notes:34]
[same as prior period, unchanged from 0001633978-19-000002:notes:37]

[0001633978-19-000030:notes:35]
[same as prior period, unchanged from 0001633978-19-000002:notes:38]

[0001633978-19-000030:notes:36]
Except for the accounting policies for (i) revenue recognition and the adoption of Accounting Standards Update (“ASU”) 2014-09, Revenue from Contracts with Customers (Topic 606), and (ii) the change in our functional currency, from certain foreign currencies to the reporting currency, there have been no significant changes to our significant accounting policies as of and for the nine months ended March 30, 2019, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the year ended June 30, 2018.

[0001633978-19-000030:notes:37]
[same as prior period, unchanged from 0001633978-19-000002:notes:40]

[0001633978-19-000030:notes:38]
[same as prior period, unchanged from 0001633978-19-000002:notes:41]

[0001633978-19-000030:notes:39]
[same as prior period, unchanged from 0001633978-19-000002:notes:42]

[0001633978-19-000030:notes:40]
[same as prior period, unchanged from 0001633978-19-000002:notes:43]

[0001633978-19-000030:notes:41]
[same as prior period, unchanged from 0001633978-19-000002:notes:44]

[0001633978-19-000030:notes:42]
[same as prior period, unchanged from 0001633978-19-000002:notes:45]

[0001633978-19-000030:notes:43]
[same as prior period, unchanged from 0001633978-19-000002:notes:46]

[0001633978-19-000030:notes:44]
[same as prior period, unchanged from 0001633978-19-000002:notes:47]

[0001633978-19-000030:notes:45]
[same as prior period, unchanged from 0001633978-19-000002:notes:48]

[0001633978-19-000030:notes:46]
[same as prior period, unchanged from 0001633978-19-000002:notes:49]

[0001633978-19-000030:notes:47]
[same as prior period, unchanged from 0001633978-19-000002:notes:50]

[0001633978-19-000030:notes:48]
[same as prior period, unchanged from 0001633978-19-000002:notes:51]

[0001633978-19-000030:notes:49]
[same as prior period, unchanged from 0001633978-19-000002:notes:52]

[0001633978-19-000030:notes:50]
[same as prior period, unchanged from 0001633978-19-000002:notes:53]

[0001633978-19-000030:notes:51]
The following table includes estimated revenue expected to be recognized in the future for backlog related performance obligations that are unsatisfied as of March 30, 2019 (in millions):

[0001633978-19-000030:notes:52]
|  | Less than 1 year | 1-2 years | Greater than 2 years | Total |
| Performance Obligations | $531.5 | $7.7 | $— | $539.2 |

[0001633978-19-000030:notes:53]
[same as prior period, unchanged from 0001633978-19-000002:notes:56]

[0001633978-19-000030:notes:54]
[same as prior period, unchanged from 0001633978-19-000002:notes:57]

[0001633978-19-000030:notes:55]
[same as prior period, unchanged from 0001633978-19-000002:notes:58]

[0001633978-19-000030:notes:56]
[same as prior period, unchanged from 0001633978-19-000002:notes:59]

[0001633978-19-000030:notes:57]
[same as prior period, unchanged from 0001633978-19-000002:notes:60]

[0001633978-19-000030:notes:58]
[same as prior period, unchanged from 0001633978-19-000002:notes:61]

[0001633978-19-000030:notes:59]
[same as prior period, unchanged from 0001633978-19-000002:notes:62]

[0001633978-19-000030:notes:60]
[same as prior period, unchanged from 0001633978-19-000002:notes:63]

[0001633978-19-000030:notes:61]
[same as prior period, unchanged from 0001633978-19-000002:notes:64]

[0001633978-19-000030:notes:62]
The following table reflects the changes in contract balances as of March 30, 2019 (in millions, except percentages):

[0001633978-19-000030:notes:63]
| Contract balances | Balance sheet location | March 30, 2019 |  | June 30, 2018 |  | Change |  | Percentage Change |
| Accounts receivable, net | Accounts receivable, net | $302.9 |  | $197.1 |  | $105.8 |  | 53.7% |
| Deferred revenue and customer deposits | Other current liabilities | $4.2 |  | $2.8 |  | $1.4 |  | 50.0% |

[0001633978-19-000030:notes:64]
[same as prior period, unchanged from 0001633978-19-000002:notes:67]

[0001633978-19-000030:notes:65]
[same as prior period, unchanged from 0001633978-19-000002:notes:68]

[0001633978-19-000030:notes:66]
[same as prior period, unchanged from 0001633978-19-000002:notes:69]

[0001633978-19-000030:notes:67]
Concurrent with the acquisition of Oclaro, on December 10, 2018, we established the functional currency for our worldwide operations as the U.S. dollar. The change in our functional currency is a result of significant changes in economic facts and circumstances, primarily the acquisition of Oclaro, a U.S. dollar-denominated functional currency company. The combined business, which requires the integration of our supply chain, manufacturing operations and sales organization, will predominantly use the U.S. dollar, including when negotiating customer and major supplier contracts.

[0001633978-19-000030:notes:68]
Translation adjustments reported prior to December 10, 2018, remain as a component of accumulated other comprehensive income in our condensed consolidated balance sheet. The translated values for any non-monetary assets and liabilities as of December 10, 2018 become the new accounting basis for those assets. Accordingly, monetary assets and liabilities denominated in foreign currencies have been remeasured into U.S. dollars using the exchange rates in effect at the balance sheet date. Foreign currency re-measurement gains (losses) are included in interest and other income (expense), net.


## us-gaap:CashCashEquivalentsAndShortTermInvestmentsTextBlock

[0001633978-19-000030:notes:69]
Note 10. Cash, Cash Equivalents and Short-term Investments

[0001633978-19-000030:notes:70]
[same as prior period, unchanged from 0001633978-19-000002:notes:73]

[0001633978-19-000030:notes:71]
|  | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| March 30, 2019: |  |  |  |  |  |  |  |
| Cash (1) | $ | 298.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 298.5 |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | 26.0 |  |  | — |  |  | — |  |  | 26.0 |  |
| Money market funds | 10.3 |  |  | — |  |  | — |  |  | 10.3 |  |
| U.S. Treasury securities | 23.5 |  |  | — |  |  | — |  |  | 23.5 |  |
| Total cash and cash equivalents | $ | 358.3 |  |  | $ | — |  |  | $ | — |  |  | $ | 358.3 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Commercial paper | $ | 19.3 |  |  | $ | — |  |  | $ | — |  |  | $ | 19.3 |  |
| Asset-backed securities | 70.6 |  |  | 0.1 |  |  | — |  |  | 70.7 |  |
| Corporate debt securities | 212.2 |  |  | 0.4 |  |  | (0.3 | ) |  | 212.3 |  |
| Municipal bonds | 1.3 |  |  | — |  |  | — |  |  | 1.3 |  |
| Mortgage-backed securities | 4.7 |  |  | — |  |  | — |  |  | 4.7 |  |
| Foreign government bonds | 5.5 |  |  | — |  |  | — |  |  | 5.5 |  |
| U.S. Treasury securities | 26.4 |  |  | — |  |  | — |  |  | 26.4 |  |
| Total short-term investments | $ | 340.0 |  |  | $ | 0.5 |  |  | $ | (0.3 | ) |  | $ | 340.2 |  |
| June 30, 2018: |  |  |  |  |  |  |  |
| Cash | $ | 103.6 |  |  | $ | — |  |  | $ | — |  |  | $ | 103.6 |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | 3.0 |  |  | — |  |  | — |  |  | 3.0 |  |
| Commercial paper | 112.1 |  |  | — |  |  | — |  |  | 112.1 |  |
| Money market funds | 0.8 |  |  | — |  |  | — |  |  | 0.8 |  |
| U.S. Treasury securities | 143.6 |  |  | — |  |  | — |  |  | 143.6 |  |
| U.S. Agency securities | 34.2 |  |  | — |  |  | — |  |  | 34.2 |  |
| Total cash and cash equivalents | $ | 397.3 |  |  | $ | — |  |  | $ | — |  |  | $ | 397.3 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 7.5 |  |  | $ | — |  |  | $ | — |  |  | $ | 7.5 |  |
| Commercial paper | 10.5 |  |  | — |  |  | — |  |  | 10.5 |  |
| Asset-backed securities | 68.0 |  |  | — |  |  | (0.2 | ) |  | 67.8 |  |
| Corporate debt securities | 220.6 |  |  | 0.1 |  |  | (1.5 | ) |  | 219.2 |  |
| Municipal bonds | 1.6 |  |  | — |  |  | — |  |  | 1.6 |  |
| Mortgage-backed securities | 4.2 |  |  | — |  |  | — |  |  | 4.2 |  |
| Foreign government bonds | 3.4 |  |  | — |  |  | — |  |  | 3.4 |  |
| Total short-term investments | $ | 315.8 |  |  | $ | 0.1 |  |  | $ | (1.7 | ) |  | $ | 314.2 |  |

[0001633978-19-000030:notes:72]
(1) For the nine months period ended on March 30, 2019, our Cash balance at end of period includes $1.0 million cash classified as assets held-for-sale.

[0001633978-19-000030:notes:73]
We use the specific-identification method to determine any realized gains or losses from the sale of our short-term investments classified as available-for-sale. During the three and nine months ended March 30, 2019 and March 31, 2018, we did not realize significant gains or losses on a gross level from the sale of our short-term investments classified as available-for-sale.

[0001633978-19-000030:notes:74]
During the three and nine months ended March 30, 2019, our interest and other income (expense), net was $6.1 million  expense and $13.2 million expense, respectively, and includes interest income on cash equivalents and short-term investments of $3.9 million and $10.0 million, respectively. During the three and nine months ended March 31, 2018, our interest and other income (expense), net was $2.1 million expense and $8.7 million expense, respectively, and includes interest income on cash equivalents and short-term investments of $2.5 million and $5.7 million, respectively.

[0001633978-19-000030:notes:75]
[same as prior period, unchanged from 0001633978-19-000002:notes:77]

[0001633978-19-000030:notes:76]
|  | Less than 12 months |  | 12 Months or Greater |  | Total |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| March 30, 2019: |  |  |  |  |  |  |  |  |  |  |  |
| Commercial paper | $ | 5.9 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 5.9 |  |  | $ | — |  |
| Asset-backed securities | 13.1 |  |  | — |  |  | 15.9 |  |  | — |  |  | 29.0 |  |  | — |  |
| Corporate debt securities | 15.4 |  |  | (0.1 | ) |  | 84.8 |  |  | (0.2 | ) |  | 100.2 |  |  | (0.3 | ) |
| Foreign government bonds | 1.7 |  |  | — |  |  | 2.1 |  |  | — |  |  | 3.8 |  |  | — |  |
| U.S. government bonds | 14.8 |  |  | — |  |  | — |  |  | — |  |  | 14.8 |  |  | — |  |
| Total | $ | 50.9 |  |  | $ | (0.1 | ) |  | $ | 102.8 |  |  | $ | (0.2 | ) |  | $ | 153.7 |  |  | $ | (0.3 | ) |
| June 30, 2018: |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 5.4 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 5.4 |  |  | $ | — |  |
| Commercial paper | 8.5 |  |  | — |  |  | — |  |  | — |  |  | 8.5 |  |  | — |  |
| Asset-backed securities | 66.6 |  |  | (0.2 | ) |  | 0.3 |  |  | — |  |  | 66.9 |  |  | (0.2 | ) |
| Corporate debt securities | 188.6 |  |  | (1.5 | ) |  | 2.0 |  |  | — |  |  | 190.6 |  |  | (1.5 | ) |
| Municipal bonds | 0.6 |  |  | — |  |  | — |  |  | — |  |  | 0.6 |  |  | — |  |
| U.S. Agency securities | 4.0 |  |  | — |  |  | — |  |  | — |  |  | 4.0 |  |  | — |  |
| Foreign government bonds | 3.4 |  |  | — |  |  | — |  |  | — |  |  | 3.4 |  |  | — |  |
| Total | $ | 277.1 |  |  | $ | (1.7 | ) |  | $ | 2.3 |  |  | $ | — |  |  | $ | 279.4 |  |  | $ | (1.7 | ) |

[0001633978-19-000030:notes:77]
[same as prior period, unchanged from 0001633978-19-000002:notes:79]

[0001633978-19-000030:notes:78]
|  | March 30, 2019 |  | June 30, 2018 |
|  | Amortized Cost |  | Fair Value |  | Amortized Cost |  | Fair Value |
| Due in 1 year | $ | 186.1 |  |  | $ | 186.0 |  |  | $ | 150.1 |  |  | $ | 149.6 |  |
| Due in 1 year through 5 years | 145.8 |  |  | 146.1 |  |  | 157.2 |  |  | 156.1 |  |
| Due in 5 years through 10 years | 7.1 |  |  | 7.1 |  |  | 6.1 |  |  | 6.1 |  |
| Due after 10 years | 1.0 |  |  | 1.0 |  |  | 2.4 |  |  | 2.4 |  |
|  | $ | 340.0 |  |  | $ | 340.2 |  |  | $ | 315.8 |  |  | $ | 314.2 |  |

[0001633978-19-000030:notes:79]
[same as prior period, unchanged from 0001633978-19-000002:notes:81]


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0001633978-19-000030:notes:80]
Note 18. Commitments and Contingencies

[0001633978-19-000030:notes:81]
Operating Leases

[0001633978-19-000030:notes:82]
We lease certain real and personal property from unrelated third parties under non-cancellable operating leases that expire at various dates through fiscal 2033. Certain leases require us to pay property taxes, insurance and routine maintenance, and include escalation clauses. As a result of our acquisition of Oclaro on December 10, 2018, we assumed operating leases with future minimum annual lease payments of $83.2 million as of March 30, 2019.

[0001633978-19-000030:notes:83]
As of March 30, 2019, the total future minimum annual lease payments under non-cancellable operating leases were as follows (in millions):

[0001633978-19-000030:notes:84]
| Fiscal Years |  |
| Remainder of 2019 | $ | 5.2 |  |
| 2020 | 18.0 |  |
| 2021 | 15.2 |  |
| 2022 | 14.1 |  |
| 2023 | 12.8 |  |
| Thereafter | 39.9 |  |
| Total minimum operating lease payments | $ | 105.2 |  |

[0001633978-19-000030:notes:85]
During the three and nine months ended March 30, 2019, rental expense relating to building and equipment was $5.2 million and $11.2 million, respectively. During the three and nine months ended March 31, 2018, rental expense relating to building and equipment was $2.8 million and $9.2 million, respectively.

[0001633978-19-000030:notes:86]
Capital Leases

[0001633978-19-000030:notes:87]
As of March 30, 2019, equipment acquired under capital lease agreements, including those assumed as part of the Oclaro acquisition, was $16.4 million. Our capital lease assets are included in property, plant and equipment, net in our condensed consolidated balance sheets as of March 30, 2019. Amortization expense on these capital lease assets are recorded as depreciation expense and is included in cost of sales in our condensed consolidated statements of operations for the three and nine months ended March 30, 2019 and March 31, 2018. Our capital lease obligations are recorded at the lesser of the estimated fair market value of the leased property or the net present value of the aggregate future minimum lease payments and is included in other current liabilities and other non-current liabilities in our condensed consolidated balance sheets as of March 30, 2019. Refer to “Note 9. Balance Sheet Details” for capital lease obligation amounts in other current liabilities and other non-current liabilities. Interest on these obligations is included in interest expense in our condensed consolidated statements of operations.

[0001633978-19-000030:notes:88]
As of March 30, 2019 the future minimum annual lease payments under our capital leases were as follows (in millions):

[0001633978-19-000030:notes:89]
| Fiscal Years |  |
| Remainder of 2019 | $ | 2.7 |  |
| 2020 | 0.5 |  |
| 2021 | 0.1 |  |
| Total minimum capital lease payments | $ | 3.3 |  |
| Less: amount representing interest | $ | (0.1 | ) |
| Present value of capital lease obligation | $ | 3.2 |  |

[0001633978-19-000030:notes:90]
Acquisition Contingencies

[0001633978-19-000030:notes:91]
In February 2017, we incurred liabilities in the amount of $3.6 million related to an acquisition of a privately held company. The amount of up to $3.0 million is expected to be paid within the following 12 months contingent upon meeting certain production targets, and is included in other current liabilities on our consolidated balance sheet as of March 30, 2019.

[0001633978-19-000030:notes:92]
We also retained $1.0 million of the purchase price as security for any potential liabilities of the seller under the representations, warranties and indemnifications included in the purchase agreement. The $1.0 million was fully paid to the seller during the nine months ended March 30, 2019.

[0001633978-19-000030:notes:93]
Term Loan

[0001633978-19-000030:notes:94]
The estimated future interest and principal payments related to the term loan are as follows as of March 30, 2019:

[0001633978-19-000030:notes:95]
| Fiscal Years |  |
| Remainder of 2019 | $ | 7.4 |  |
| 2020 | 29.2 |  |
| 2021 | 29.0 |  |
| 2022 | 28.7 |  |
| 2023 | 28.5 |  |
| Thereafter | 533.9 |  |
| Total term loan payments | $ | 656.7 |  |

[0001633978-19-000030:notes:96]
0.25% Convertible Notes due 2024

[0001633978-19-000030:notes:97]
The future interest and principal payments related to the 2024 Notes are as follows as of March 30, 2019:

[0001633978-19-000030:notes:98]
| Fiscal Years |  |
| Remainder of 2019 | $ | — |  |
| 2020 | 1.1 |  |
| 2021 | 1.1 |  |
| 2022 | 1.1 |  |
| 2023 | 1.1 |  |
| Thereafter | 451.2 |  |
| Total 2024 Notes payments | $ | 455.6 |  |

[0001633978-19-000030:notes:99]
Purchase Obligations

[0001633978-19-000030:notes:100]
Purchase obligations of $208.0 million as of March 30, 2019, represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements.

[0001633978-19-000030:notes:101]
Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule and adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

[0001633978-19-000030:notes:102]
We depend on a limited number of contract manufacturers, subcontractors and suppliers for raw materials, packages and standard components. We generally purchase these single or limited source products through standard purchase orders or one-year supply agreements and have no significant long-term guaranteed supply agreements with such vendors. While we seek to maintain a sufficient safety stock of such products and maintain on-going communications with our suppliers to guard against interruptions or cessation of supply, our business and results of operations could be adversely affected by a stoppage or delay of supply, substitution of more expensive or less reliable products, receipt of defective parts or contaminated materials, increases in the price of such supplies, or our inability to obtain reduced pricing from our suppliers in response to competitive pressures.

[0001633978-19-000030:notes:103]
Product Warranties

[0001633978-19-000030:notes:104]
We provide reserves for the estimated costs of product warranties at the time revenue is recognized. We typically offer a twelve month warranty for most of our products. However, in some instances depending upon the product, product component or application of our products by the end customer, our warranties can vary and generally range from six months to five years. We estimate the costs of our warranty obligations on an annualized basis based on our historical experience of known product failure rates, use of materials to repair or replace defective products and service delivery costs incurred in correcting product failures. In addition, from time to time, specific warranty accruals may be made if unforeseen technical problems arise with specific products. We assess the adequacy of our recorded warranty liabilities and adjust the amounts as necessary.

[0001633978-19-000030:notes:105]
The following table presents the changes in our warranty reserve during the three and nine months ended March 30, 2019 and March 31, 2018 (in millions):

[0001633978-19-000030:notes:106]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 30, 2019 |  | March 31, 2018 |  | March 30, 2019 |  | March 31, 2018 |
| Balance as of beginning of period | $ | 9.7 |  |  | $ | 9.9 |  |  | $ | 6.6 |  |  | $ | 9.7 |  |
| Warranties assumed in Oclaro acquisition | — |  |  | — |  |  | 3.8 |  |  | — |  |
| Provision for warranty | 1.5 |  |  | 2.0 |  |  | 3.4 |  |  | 4.9 |  |
| Utilization of reserve | (1.4 | ) |  | (4.9 | ) |  | (4.0 | ) |  | (7.6 | ) |
| Balance as of end of period | $ | 9.8 |  |  | $ | 7.0 |  |  | $ | 9.8 |  |  | $ | 7.0 |  |

[0001633978-19-000030:notes:107]
Environmental Liabilities

[0001633978-19-000030:notes:108]
Our research and development (“R&D”), manufacturing and distribution operations involve the use of hazardous substances and are regulated under international, federal, state and local laws governing health and safety and the environment. We apply strict standards for protection of the environment and occupational health and safety to sites inside and outside the United States, even if not subject to regulations imposed by foreign governments. We believe that our properties and operations at our facilities comply in all material respects with applicable environmental laws and occupational health and safety laws. However, the risk of environmental liabilities cannot be completely eliminated and there can be no assurance that the application of environmental and health and safety laws will not require us to incur significant expenditures. We are also regulated under a number of international, federal, state and local laws regarding recycling, product packaging and product content requirements. The environmental, product content/disposal and recycling laws are gradually becoming more stringent and may cause us to incur significant expenditures in the future.

[0001633978-19-000030:notes:109]
Legal Proceedings

[0001633978-19-000030:notes:110]
We are subject to a variety of claims and suits that arise from time to time in the ordinary course of our business. While management currently believes that resolving claims against us, individually or in the aggregate, will not have a material adverse impact on our financial position, results of operations or statements of cash flows, these matters are subject to inherent uncertainties and management’s view of these matters may change in the future. We accrue for loss contingencies when it is both probable that we will incur the loss and when we can reasonably estimate the amount of the loss or range of loss. As of March 30, 2019, we did not have any material claims or proceedings that were probable or reasonably possible.

[0001633978-19-000030:notes:111]
Merger Litigation

[0001633978-19-000030:notes:112]
In connection with our acquisition of Oclaro, seven lawsuits were filed by purported stockholders of Oclaro challenging the proposed merger (the “Merger”). Two of the seven suits were putative class actions filed against Oclaro, its directors, Lumentum, Prota Merger Sub, Inc. and Prota Merger, LLC: Nicholas Neinast v. Oclaro, Inc., et al., No. 3:18-cv-03112-VC, in the United States District Court for the Northern District of California (filed May 24, 2018) (the “Neinast Lawsuit”); and Adam Franchi v. Oclaro, Inc., et al., No. 1:18-cv-00817-GMS, in the United States District Court for the District of Delaware (filed June 9, 2018) (the “Franchi Lawsuit). Both the Neinstat Lawsuit and the Franchi Lawsuit were voluntarily dismissed with prejudice.

[0001633978-19-000030:notes:113]
The other five suits, styled as Gerald F. Wordehoff v. Oclaro, Inc., et al., No. 5:18-cv-03148-NC (the “Wordehoff Lawsuit”), Walter Ryan v. Oclaro, Inc., et al., No. 3:18-cv-03174-VC (the “Ryan Lawsuit”), Jayme Walker v. Oclaro, Inc., et al., No. 5:18-cv-03203-EJD (the “Walker Lawsuit”), Kevin Garcia v. Oclaro, Inc., et al., No. 5:18-cv-03262-VKD (the “Garcia Lawsuit”), and SaiSravan B. Karri v. Oclaro, Inc., et al., No. 3:18-cv-03435-JD (the “Karri Lawsuit” and, together with the other six lawsuits, the “Lawsuits”), were filed in the United States District Court for the Northern District of California on May 25, 2018, May 29, 2018, May 30, 2018, May 31, 2018, and June 9, 2018, respectively. These five Lawsuits named Oclaro and its directors as defendants only and did not name Lumentum. The Wordehoff, Ryan, Walker, and Garcia Lawsuits have been voluntarily dismissed, and the Wordehoff, Ryan, and Walker dismissals were with prejudice. The Karri Lawsuit has not yet been dismissed. The Ryan Lawsuit was, and the Karri Lawsuit is, a putative class action.

[0001633978-19-000030:notes:114]
The Lawsuits generally alleged, among other things, that Oclaro and its directors violated Section 14(a) of the Securities Exchange Act of 1934, as amended (the “Exchange Act”), and Rule 14a-9 promulgated thereunder by disseminating an incomplete and misleading Form S-4, including proxy statement/prospectus. The Lawsuits further alleged that Oclaro’s directors violated Section 20(a) of the Exchange Act by failing to exercise proper control over the person(s) who violated Section 14(a) of the Exchange Act.

[0001633978-19-000030:notes:115]
The remaining Lawsuit (the Karri Lawsuit) currently purports to seek, among other things, damages to be awarded to the plaintiff and any class if the Merger is consummated, and litigation costs, including attorneys’ fees. The defendants intend to defend the Karri Lawsuit vigorously.

[0001633978-19-000030:notes:116]
Indemnifications

[0001633978-19-000030:notes:117]
In the normal course of business, we enter into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown because claims may be made against us in the future and we may record charges in the future as a result of these indemnification obligations. As of March 30, 2019, we did not have any material indemnification claims that were probable or reasonably possible.

[0001633978-19-000030:notes:118]
Audit Proceedings

[0001633978-19-000030:notes:119]
We are under audit by various domestic and foreign tax authorities with regards to income tax and indirect tax matters. In some, although not all cases, we have reserved for potential adjustments to our provision for income taxes and accrual of indirect taxes that may result from examinations by these tax authorities or final outcomes in judicial proceedings, and we believe that the final outcome of these examinations, agreements or judicial proceedings will not have a material effect on our results of operations. If events occur which indicate payment of these amounts is unnecessary, the reversal of the liabilities would result in the recognition of benefits in the period we determine the liabilities are no longer necessary. If our estimates of the federal, state, and foreign income tax liabilities and indirect tax liabilities are less than the ultimate assessment, it could result in a further charge to expense.

[0001633978-19-000030:notes:120]
In connection with our acquisition of Oclaro, we recorded $1.1 million in Malaysia Goods and Services Tax (“GST”) refund claims within prepaid expenses and other current assets in our condensed consolidated balance sheet at March 30, 2019. The refund claim represents an initial claim of $2.5 million of GST, net of reserves, that were previously denied by the Malaysian tax authorities in 2016. We are currently appealing the denial of these claims, and believe that additional options may be available to us if we do not obtain a favorable resolution. Although we have taken action to minimize the impact of the GST with respect to our ongoing operations, we believe it is reasonably possible that, ultimately, we may not be able to recover some of these GST amounts.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001633978-19-000030:notes:121]
[same as prior period, unchanged from 0001633978-19-000002:notes:125]

[0001633978-19-000030:notes:122]
[same as prior period, unchanged from 0001633978-19-000002:notes:126]

[0001633978-19-000030:notes:123]
As of March 30, 2019 and June 30, 2018, balances for the components of accumulated other comprehensive income (loss) were as follows (in millions):

[0001633978-19-000030:notes:124]
|  | Foreign currency translation adjustments, net of tax |  | Defined benefit obligations, net of tax (1) |  | Unrealized gain (loss) on available-for-sale securities, net of tax |  | Total |
| Beginning balance as of June 30, 2018 | $ | 10.3 |  |  | $ | (2.3 | ) |  | $ | (1.6 | ) |  | $ | 6.4 |  |
| Other comprehensive income (loss) | (0.6 | ) |  | (0.1 | ) |  | 1.8 |  |  | 1.1 |  |
| Ending balance as of March 30, 2019 | $ | 9.7 |  |  | $ | (2.4 | ) |  | $ | 0.2 |  |  | $ | 7.5 |  |

[0001633978-19-000030:notes:125]
[same as prior period, unchanged from 0001633978-19-000002:notes:129]


## us-gaap:ConvertibleDebtTableTextBlock

[0001633978-19-000030:notes:126]
The 2024 Notes consisted of the following components as of the periods presented (in millions):

[0001633978-19-000030:notes:127]
| Liability component: | March 30, 2019 |  | June 30, 2018 |
| Principal | $ | 450.0 |  |  | $ | 450.0 |  |
| Unamortized debt discount | (102.6 | ) |  | (115.8 | ) |
| Net carrying amount of the liability component | $ | 347.4 |  |  | $ | 334.2 |  |


## us-gaap:DebtDisclosureTextBlock

[0001633978-19-000030:notes:128]
Note 13. Convertible Notes

[0001633978-19-000030:notes:129]
In March 2017, we issued the 2024 Notes in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act of 1933, as amended (the “Securities Act”). The 2024 Notes are governed by an indenture between the Company, as the issuer, and U.S. Bank National Association, as trustee (the “Indenture”). The 2024 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001633978-19-000030:notes:130]
The 2024 Notes bear interest at a rate of 0.25% per year. Interest on the 2024 Notes is payable semi-annually in arrears on March 15 and September 15 of each year, beginning on September 15, 2017. The 2024 Notes will mature on March 15, 2024, unless earlier repurchased by us or converted pursuant to their terms.

[0001633978-19-000030:notes:131]
The initial conversion rate of the 2024 Notes is 16.4965 shares of common stock per $1,000 principal amount of 2024 Notes, which is equivalent to an initial conversion price of approximately $60.62 per share, a 132.5% premium to the fair market value at the date of issuance. Prior to the close of business on the business day immediately preceding December 15, 2023, the 2024 Notes will be convertible only under the following circumstances: (1) during any fiscal quarter (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during the period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price, or $78.80 on each applicable trading day; (2) during the five consecutive business day period after any five consecutive trading day period (the “measurement period”) in which the trading price per $1,000 principal amount of notes for each trading day of such measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate on each such trading day; or (3) upon the occurrence of specified corporate events. On or after December 15, 2023 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their notes at any time. In addition, upon the occurrence of a make-whole fundamental change, we will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert 2024 Notes in connection with such make-whole fundamental change.

[0001633978-19-000030:notes:132]
We may not redeem the 2024 Notes prior to their maturity date and no sinking fund is provided for the 2024 Notes. Upon the occurrence of a fundamental change, holders may require us to repurchase all or a portion of their 2024 Notes for cash at a price equal to 100% of the principal amount of the 2024 Notes to be repurchased, plus any accrued and unpaid interest.

[0001633978-19-000030:notes:133]
We considered the features embedded in the 2024 Notes other than the conversion feature, including the holders’ put feature, our call feature, and the make-whole feature, and concluded that they are not required to be bifurcated and accounted for separately from the host debt instrument.

[0001633978-19-000030:notes:134]
Prior to the Tax Matters Agreement settlement condition (“TMA settlement condition”), because we could only settle the 2024 Notes in cash, we determined that the conversion feature met the definition of a derivative liability. We separated the derivative liability from the host debt instrument based on the fair value of the derivative liability. As of the issuance date, March 8, 2017, the derivative liability fair value of $129.9 million was calculated using the binomial valuation approach. The residual principal amount of the 2024 Notes of $320.1 million before issuance costs was allocated to the debt component. We incurred approximately $7.7 million in transaction costs in connection with the issuance of the 2024 Notes. These costs were allocated to the debt component and recognized as a debt discount. We amortize the debt discount, including both the initial value of the derivative liability and the transaction costs, over the term of the 2024 Notes using the effective interest method. The effective interest rate of the 2024 Notes is 5.4% per year. As of March 30, 2019, the remaining debt discount amortization period was 59 months.

[0001633978-19-000030:notes:135]
During the year ended July 1, 2017, we satisfied the TMA settlement condition. As such, the value of the conversion option will no longer be marked to market and was reclassified to additional paid-in capital within stockholders’ equity on our condensed consolidated balance sheet. The value of the conversion option at the time of issuance will be treated as an original issue discount for purposes of accounting for the debt component of the notes. The debt component will accrete up to the principal amount over the expected term of the debt. These accounting standards do not affect the actual amount we are required to repay, and the amount shown in the table below for the notes is the aggregate principal amount of the notes and does not reflect the debt discount we will be required to recognize.

[0001633978-19-000030:notes:136]
The following table sets forth interest expense information related to the 2024 Notes for the periods presented (in millions, except percentages):

[0001633978-19-000030:notes:137]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 30, 2019 |  | March 31, 2018 |  | March 30, 2019 |  | March 31, 2018 |
| Contractual interest expense | $ | 0.3 |  |  | $ | 0.3 |  |  | $ | 0.9 |  |  | $ | 0.9 |  |
| Amortization of the debt discount | 4.5 |  |  | 4.2 |  |  | 13.2 |  |  | 12.4 |  |
| Total interest expense | $ | 4.8 |  |  | $ | 4.5 |  |  | $ | 14.1 |  |  | $ | 13.3 |  |
| Effective interest rate on the liability component | 5.4 | % |  | 5.4 | % |  | 5.4 | % |  | 5.4 | % |

[0001633978-19-000030:notes:138]
We have the ability and intent to settle the $450 million face value of the debt in cash. Therefore, we use the treasury stock method for calculating the dilutive impact of the debt. The 2024 Notes will have no impact to diluted earnings per share until the average price of our common stock exceeds the conversion price of $60.62.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001633978-19-000030:notes:139]
[same as prior period, unchanged from 0001633978-19-000002:notes:148]

[0001633978-19-000030:notes:140]
[same as prior period, unchanged from 0001633978-19-000002:notes:149]

[0001633978-19-000030:notes:141]
[same as prior period, unchanged from 0001633978-19-000002:notes:150]

[0001633978-19-000030:notes:142]
As of March 30, 2019, we had 2.8 million shares subject to stock options, restricted stock units, restricted stock awards, and performance stock units issued and outstanding under the 2015 Equity Incentive Plan (the “2015 Plan”).

[0001633978-19-000030:notes:143]
[same as prior period, unchanged from 0001633978-19-000002:notes:152]

[0001633978-19-000030:notes:144]
As of March 30, 2019, 3.7 million shares of common stock under the 2015 Plan were available for grant.

[0001633978-19-000030:notes:145]
[same as prior period, unchanged from 0001633978-19-000002:notes:154]

[0001633978-19-000030:notes:146]
[same as prior period, unchanged from 0001633978-19-000002:notes:155]

[0001633978-19-000030:notes:147]
[same as prior period, unchanged from 0001633978-19-000002:notes:156]

[0001633978-19-000030:notes:148]
[same as prior period, unchanged from 0001633978-19-000002:notes:157]

[0001633978-19-000030:notes:149]
[same as prior period, unchanged from 0001633978-19-000002:notes:158]

[0001633978-19-000030:notes:150]
[same as prior period, unchanged from 0001633978-19-000002:notes:159]

[0001633978-19-000030:notes:151]
[same as prior period, unchanged from 0001633978-19-000002:notes:160]

[0001633978-19-000030:notes:152]
[same as prior period, unchanged from 0001633978-19-000002:notes:161]

[0001633978-19-000030:notes:153]
In November 2018, our board of directors approved the grant of 0.2 million PSUs to senior members of our management team. We determined that the achievement of the performance conditions was probable as of March 30, 2019, and as such, began recording stock-based compensation associated with these PSUs.

[0001633978-19-000030:notes:154]
[same as prior period, unchanged from 0001633978-19-000002:notes:163]

[0001633978-19-000030:notes:155]
Our 2015 Employee Stock Purchase Plan (the “2015 Purchase Plan”)  provides eligible employees with the opportunity to acquire an ownership interest in the Company through periodic payroll deductions and provides a 15% purchase price discount as well as a six-month look-back period. The 2015 Purchase Plan is structured as a qualified employee stock purchase plan under Section 423 of the Internal Revenue Code of 1986. However, the 2015 Purchase Plan is not intended to be a qualified pension, profit sharing or stock bonus plan under Section 401(a) of the Internal Revenue Code of 1986 and is not subject to the provisions of the Employee Retirement Income Security Act of 1974. The 2015 Purchase Plan will terminate upon the date on which all shares available for issuance have been sold. Of the 3.0 million shares authorized under the 2015 Purchase Plan, 2.2 million shares remained available for issuance as of March 30, 2019.

[0001633978-19-000030:notes:156]
[same as prior period, unchanged from 0001633978-19-000002:notes:165]

[0001633978-19-000030:notes:157]
The impact on our results of operations of recording stock-based compensation by function for the three and nine months ended March 30, 2019 and March 31, 2018 was as follows (in millions):

[0001633978-19-000030:notes:158]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 30, 2019 |  | March 31, 2018 |  | March 30, 2019 |  | March 31, 2018 |
| Cost of sales | $ | 3.2 |  |  | $ | 2.4 |  |  | $ | 11.7 |  |  | $ | 9.5 |  |
| Research and development | 4.5 |  |  | 3.6 |  |  | 10.7 |  |  | 10.5 |  |
| Selling, general and administrative | 8.3 |  |  | 5.0 |  |  | 34.1 |  |  | 15.1 |  |
|  | $ | 16.0 |  |  | $ | 11.0 |  |  | $ | 56.5 |  |  | $ | 35.1 |  |

[0001633978-19-000030:notes:159]
Approximately $4.0 million and $2.6 million of stock-based compensation was capitalized to inventory as of March 30, 2019 and June 30, 2018, respectively.

[0001633978-19-000030:notes:160]
[same as prior period, unchanged from 0001633978-19-000002:notes:169]

[0001633978-19-000030:notes:161]
[same as prior period, unchanged from 0001633978-19-000002:notes:170]

[0001633978-19-000030:notes:162]
We did not grant any stock options during the three and nine months ended March 30, 2019 and March 31, 2018, other than those assumed in connection with the Oclaro merger. As of March 30, 2019, there were less than 0.1 million stock options outstanding under the 2015 Plan, all of which were replacement awards issued in connection with the Oclaro acquisition.

[0001633978-19-000030:notes:163]
The following table summarizes our awards activity for the nine months ended March 30, 2019 (in millions, except per share amounts):

[0001633978-19-000030:notes:164]
|  | Stock Options |  | Restricted Stock Units |  | Restricted Stock Awards |  | Performance Stock Units |
|  | Number of Shares |  | Weighted-Average Exercise Price |  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |  | Number of Shares (1) |  | Weighted-Average Grant Date Fair Value per Share |
| Balance at beginning of period | — |  |  | $ | — |  |  | 1.7 |  |  | $ | 43.1 |  |  | 0.1 |  |  | $ | 32.5 |  |  | 0.1 |  |  | $ | 52.0 |  |
| Assumed in Oclaro merger | * |  |  | 34.3 |  |  | 1.0 |  |  | 41.8 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Granted | — |  |  | — |  |  | 1.0 |  |  | 60.6 |  |  | — |  |  | — |  |  | 0.2 |  |  | 55.9 |  |
| Vested/Exercised | * |  |  | 20.5 |  |  | (0.9 | ) |  | 40.6 |  |  | (0.1 | ) |  | 32.5 |  |  | (0.1 | ) |  | 48.3 |  |
| Canceled | — |  |  | — |  |  | (0.3 | ) |  | 51.4 |  |  | * |  |  | 32.8 |  |  | * |  |  | 53.8 |  |
| Balance at end of period | * |  |  | $ | 36.1 |  |  | 2.5 |  |  | $ | 50.9 |  |  | * |  |  | $ | 32.5 |  |  | 0.2 |  |  | $ | 55.8 |  |

[0001633978-19-000030:notes:165]
* Less than 0.05 million

[0001633978-19-000030:notes:166]
[same as prior period, unchanged from 0001633978-19-000002:notes:176]

[0001633978-19-000030:notes:167]
As of March 30, 2019, $117.5 million of stock-based compensation cost related to awards granted to our employees remains to be amortized. That cost is expected to be recognized over an estimated amortization period of 2.2 years.

[0001633978-19-000030:notes:168]
[same as prior period, unchanged from 0001633978-19-000002:notes:178]

[0001633978-19-000030:notes:169]
|  | Awards Available for Grant |
| Balance as of beginning of period | 5.6 |  |
| Replacement awards in connection with Oclaro acquisition | (1.0 | ) |
| Granted | (1.2 | ) |
| Canceled | 0.3 |  |
| Balance as of end of period | 3.7 |  |

[0001633978-19-000030:notes:170]
[same as prior period, unchanged from 0001633978-19-000002:notes:180]

[0001633978-19-000030:notes:171]
The 2015 Purchase Plan expense for the three and nine months ended March 30, 2019 was $1.1 million and $2.9 million, respectively. The 2015 Purchase Plan expense for the three and nine months ended March 31, 2018 was $0.8 million and $2.4 million, respectively. The expense related to the 2015 Purchase Plan is recorded on a straight-line basis over the relevant subscription period. During the three and nine months ended March 30, 2019 there were zero and 0.1 million shares issued to employees through the 2015 Purchase Plan. During  the nine months ended March 31, 2018, there were 0.1 million shares issued to employees through the 2015 Purchase Plan.

[0001633978-19-000030:notes:172]
We estimate the fair value of the 2015 Purchase Plan shares on the date of grant using the Black-Scholes option-pricing model. During the three and nine months ended March 30, 2019 and March 31, 2018, the assumptions used to estimate the fair value of the 2015 Purchase Plan shares to be issued were as follows:

[0001633978-19-000030:notes:173]
|  | March 30, 2019 |  | March 31, 2018 |
| Expected term (years) | 0.5 |  |  | 0.5 |  |
| Expected volatility | 71.3 | % |  | 49.9 | % |
| Risk-free interest rate | 2.52 | % |  | 1.42 | % |
| Dividend yield | — | % |  | — | % |


## us-gaap:EarningsPerShareTextBlock

[0001633978-19-000030:notes:174]
[same as prior period, unchanged from 0001633978-19-000002:notes:184]

[0001633978-19-000030:notes:175]
[same as prior period, unchanged from 0001633978-19-000002:notes:185]

[0001633978-19-000030:notes:176]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 30, 2019 |  | March 31, 2018 |  | March 30, 2019 |  | March 31, 2018 |
| Basic Earnings per Common Share |  |  |  |  |  |  |  |  |  |  |
| Net income/(loss) | $ | (74.3 | ) |  | $ | 2.7 |  |  | $ | (10.6 | ) |  | $ | 214.6 |  |
| Less: Cumulative dividends on Series A Preferred Stock | — |  |  | (0.2 | ) |  | (0.3 | ) |  | (0.7 | ) |
| Less: Earnings allocated to Series A Preferred Stock | — |  |  | (0.1 | ) |  | (1.2 | ) |  | (4.9 | ) |
| Net income/(loss) attributable to common stockholders - Basic | $ | (74.3 | ) |  | $ | 2.4 |  |  | $ | (12.1 | ) |  | $ | 209.0 |  |
| Weighted average common shares outstanding including Series A Preferred Stock | 76.2 |  |  | 63.9 |  |  | 69.4 |  |  | 63.6 |  |
| Less: Weighted average Series A Preferred Stock | — |  |  | (1.5 | ) |  | (0.7 | ) |  | (1.5 | ) |
| Basic weighted average common shares outstanding | 76.2 |  |  | 62.4 |  |  | 68.7 |  |  | 62.1 |  |
| Net income/(loss) per share attributable to common stockholders - Basic | $ | (0.98 | ) |  | $ | 0.04 |  |  | $ | (0.18 | ) |  | $ | 3.37 |  |
| Diluted Earnings per Common Share |  |  |  |  |  |  |  |
| Net income/(loss) attributable to common stockholders - Basic | $ | (74.3 | ) |  | $ | 2.4 |  |  | $ | (12.1 | ) |  | $ | 209.0 |  |
| Add: Earnings allocated to Series A Preferred Stock | — |  |  | — |  |  | — |  |  | — |  |
| Add/Less: Unrealized (gain) loss on derivative liability on Series A Preferred Stock | — |  |  | — |  |  | — |  |  | — |  |
| Add: Cumulative dividends on Series A Preferred Stock | — |  |  | — |  |  | — |  |  | — |  |
| Net income/(loss) attributable to common stockholders - Diluted (a) | $ | (74.3 | ) |  | $ | 2.4 |  |  | $ | (12.1 | ) |  | $ | 209.0 |  |
| Weighted average common shares outstanding for basic earnings per common share | 76.2 |  |  | 62.4 |  |  | 68.7 |  |  | 62.1 |  |
| Effect of dilutive securities from 2015 Equity Incentive Plan | — |  |  | 0.9 |  |  | — |  |  | 1.1 |  |
| Effect of dilutive securities from Series A Preferred Stock | — |  |  | — |  |  | — |  |  | — |  |
| Diluted weighted average common shares outstanding | 76.2 |  |  | 63.3 |  |  | 68.7 |  |  | 63.2 |  |
| Net income/(loss) per share attributable to common stockholders - Diluted | $ | (0.98 | ) |  | $ | 0.04 |  |  | $ | (0.18 | ) |  | $ | 3.31 |  |

[0001633978-19-000030:notes:177]
(a) For the three and nine months ended March 30, 2019, our diluted earnings per share attributable to common stockholders is the same as basic EPS. For the three and nine months ended March 31, 2018, our diluted net loss per share attributable to common stockholders is calculated using the treasury stock method because it is more dilutive than the if-converted method.

[0001633978-19-000030:notes:178]
Our Series A Preferred Stock was considered a participating security, meaning that it had the right to participate in undistributed earnings with our common stock. Prior to conversion, the holders of our Series A Preferred Stock were entitled to share in dividends, on an as-converted basis, if the holders of our common stock were to receive dividends. On November 2, 2018, the remaining 35,805 shares of our Series A Preferred Stock were converted and we issued 1.5 million shares of our common stock. Refer to “Note 12. Non-Controlling Interest Redeemable Convertible Preferred Stock” for further discussion.

[0001633978-19-000030:notes:179]
We used the two-class method to compute earnings per share. The two-class method is an earnings allocation formula that determines earnings per share for each class of common stock and participating security according to dividends declared (or accumulated) and participation rights in undistributed earnings. In determining the amount of net earnings to allocate to common stockholders, earnings are allocated to both common and participating securities based on their respective weighted-average shares outstanding during the period. Diluted earnings per common share is calculated similar to basic earnings per common share except that it gives effect to all potentially dilutive common stock equivalents outstanding for the period, using the treasury stock method. Potentially dilutive common shares result from the assumed exercise of outstanding stock options, assumed vesting of outstanding equity awards, assumed issuance of stock under the employee stock purchase plan, and assumed conversion of our outstanding $450 million in aggregate principal amount of 0.25% Convertible Notes due in 2024 (the “2024 Notes”), all using the treasury stock method. We have the ability and intent to settle the $450 million face value of the 2024 Notes in cash. Therefore, we use the treasury stock method for calculating the dilutive impact of the 2024 Notes. The 2024 Notes will have no impact on diluted earnings per share until the average price of our common stock exceeds the conversion price of $60.62. Refer to “Note 13. Convertible Notes” for further discussion. Diluted earnings per common share is computed using the more dilutive of the treasury stock method or the if-converted method.

[0001633978-19-000030:notes:180]
[same as prior period, unchanged from 0001633978-19-000002:notes:190]


## us-gaap:FairValueDisclosuresTextBlock

[0001633978-19-000030:notes:181]
Note 11. Fair Value Measurements

[0001633978-19-000030:notes:182]
[same as prior period, unchanged from 0001633978-19-000002:notes:192]

[0001633978-19-000030:notes:183]
[same as prior period, unchanged from 0001633978-19-000002:notes:193]

[0001633978-19-000030:notes:184]
[same as prior period, unchanged from 0001633978-19-000002:notes:194]

[0001633978-19-000030:notes:185]
Prior to the conversion of the Series A Preferred Stock in the second quarter of fiscal 2019, we estimated the fair value of the embedded derivative for the Series A Preferred Stock using the binomial lattice model to be $43.6 million. The binomial lattice model requires various assumptions to be made to determine the fair value of the embedded derivatives. These assumptions represent Level 3 inputs. Refer to “Note 12. Non-Controlling Interest Redeemable Convertible Preferred Stock and Derivative Liability.” Upon the conversion of the Series A Preferred Stock and the settlement of the Series A Preferred Stock and the embedded derivative, we recorded $79.4 million in additional paid in capital in the condensed consolidated balance sheet as of December 29, 2018.

[0001633978-19-000030:notes:186]
In February 2017, we completed the acquisition of a privately held company to enhance our manufacturing and vertical integration capabilities for a total purchase consideration of $8.7 million. We estimated the fair value of our Level 3 contingent consideration related to this acquisition at the present value of the expected contingent payments, determined using a probabilistic approach. We are required to reassess the fair value of contingent payments on a periodic basis. We estimated the likelihood of meeting the production targets at 90 percent and recorded the fair value of such contingent consideration in other current liabilities on the condensed consolidated balance sheet as of March 30, 2019. This contingent consideration will result in a cash payment of $3.0 million (based on the exchange rate as of the acquisition date), if and when the production targets are achieved, which we expect to occur within the following 12 months. There was no change in the fair value of our contingent consideration during the three and nine months ended March 30, 2019 and March 31, 2018.

[0001633978-19-000030:notes:187]
[same as prior period, unchanged from 0001633978-19-000002:notes:197]

[0001633978-19-000030:notes:188]
[same as prior period, unchanged from 0001633978-19-000002:notes:198]

[0001633978-19-000030:notes:189]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| March 30, 2019: (1) |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | — |  |  | $ | 26.0 |  |  | $ | — |  |  | $ | 26.0 |  |
| Money market funds | 10.3 |  |  | — |  |  | — |  |  | 10.3 |  |
| U.S. Treasury securities | 23.5 |  |  | — |  |  | — |  |  | 23.5 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Commercial paper | — |  |  | 19.3 |  |  | — |  |  | 19.3 |  |
| Asset-backed securities | — |  |  | 70.7 |  |  | — |  |  | 70.7 |  |
| Corporate debt securities | — |  |  | 212.3 |  |  | — |  |  | 212.3 |  |
| Municipal bonds | — |  |  | 1.3 |  |  | — |  |  | 1.3 |  |
| Mortgage-backed securities | — |  |  | 4.7 |  |  | — |  |  | 4.7 |  |
| Foreign government bonds | — |  |  | 5.5 |  |  | — |  |  | 5.5 |  |
| U.S. Treasury securities | 26.4 |  |  | — |  |  | — |  |  | 26.4 |  |
| Total assets | $ | 60.2 |  |  | $ | 339.8 |  |  | $ | — |  |  | $ | 400.0 |  |
| Other current liabilities: |  |  |  |  |  |  |  |
| Acquisition contingencies | $ | — |  |  | $ | — |  |  | $ | 2.7 |  |  | $ | 2.7 |  |
| Total other accrued liabilities | $ | — |  |  | $ | — |  |  | $ | 2.7 |  |  | $ | 2.7 |  |

[0001633978-19-000030:notes:190]
(1)  Excludes $298.5 million in cash held in our bank accounts at March 30, 2019.

[0001633978-19-000030:notes:191]
Based on quoted market prices as of  March 30, 2019, the fair value of the Convertible Notes (Note 13) was approximately $529.8 million, determined using Level 2 inputs as they are not actively traded in markets.

[0001633978-19-000030:notes:192]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| June 30, 2018: (1) |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | — |  |  | $ | 3.0 |  |  | $ | — |  |  | $ | 3.0 |  |
| Commercial paper | — |  |  | 112.1 |  |  | — |  |  | 112.1 |  |
| Money market funds | 0.8 |  |  | — |  |  | — |  |  | 0.8 |  |
| U.S. Treasury securities | 143.6 |  |  | — |  |  | — |  |  | 143.6 |  |
| U.S. Agency securities | — |  |  | 34.2 |  |  | — |  |  | 34.2 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | 7.5 |  |  | — |  |  | 7.5 |  |
| Commercial paper | — |  |  | 10.5 |  |  | — |  |  | 10.5 |  |
| Asset-backed securities | — |  |  | 67.8 |  |  | — |  |  | 67.8 |  |
| Corporate debt securities | — |  |  | 219.2 |  |  | — |  |  | 219.2 |  |
| Municipal bonds | — |  |  | 1.6 |  |  | — |  |  | 1.6 |  |
| Mortgage-backed securities | — |  |  | 4.2 |  |  | — |  |  | 4.2 |  |
| Foreign government bonds | — |  |  | 3.4 |  |  | — |  |  | 3.4 |  |
| Total assets | $ | 144.4 |  |  | $ | 463.5 |  |  | $ | — |  |  | $ | 607.9 |  |
| Other accrued liabilities: |  |  |  |  |  |  |  |
| Derivative liability | $ | — |  |  | $ | — |  |  | $ | 52.4 |  |  | $ | 52.4 |  |
| Acquisition contingencies | — |  |  | — |  |  | 2.7 |  |  | 2.7 |  |
| Total other accrued liabilities | $ | — |  |  | $ | — |  |  | $ | 55.1 |  |  | $ | 55.1 |  |

[0001633978-19-000030:notes:193]
[same as prior period, unchanged from 0001633978-19-000002:notes:202]

[0001633978-19-000030:notes:194]
[same as prior period, unchanged from 0001633978-19-000002:notes:203]

[0001633978-19-000030:notes:195]
[same as prior period, unchanged from 0001633978-19-000002:notes:204]

[0001633978-19-000030:notes:196]
[same as prior period, unchanged from 0001633978-19-000002:notes:205]

[0001633978-19-000030:notes:197]
We also valued certain long-lived assets at fair value on a non-recurring basis as of March 30, 2019 as part of our long-lived asset impairment testing and recorded an impairment charge of $30.7 million during the three and nine months ended March 30, 2019. Fair value was determined by utilizing a market approach incorporating both observable and unobservable inputs, and are deemed to be Level 3 fair value inputs. Refer to “Note 5. Business Combination” and “Note 15. Impairment Charges.”


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0001633978-19-000030:notes:198]
[same as prior period, unchanged from 0001633978-19-000002:notes:207]


## us-gaap:FiniteLivedIntangibleAssetsAmortizationExpenseTableTextBlock

[0001633978-19-000030:notes:199]
[same as prior period, unchanged from 0001633978-19-000002:notes:208]

[0001633978-19-000030:notes:200]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 30, 2019 |  | March 31, 2018 |  | March 30, 2019 |  | March 31, 2018 |
| Cost of sales | $ | 28.1 |  |  | $ | 0.8 |  |  | $ | 33.3 |  |  | $ | 2.4 |  |
| Selling, general and administrative | 3.6 |  |  | — |  |  | 4.4 |  |  | — |  |
| Total | $ | 31.7 |  |  | $ | 0.8 |  |  | $ | 37.7 |  |  | $ | 2.4 |  |


## us-gaap:GoodwillDisclosureTextBlock

[0001633978-19-000030:notes:201]
Note 6. Goodwill and Other Intangible Assets

[0001633978-19-000030:notes:202]
[same as prior period, unchanged from 0001633978-19-000002:notes:211]

[0001633978-19-000030:notes:203]
On December 10, 2018, we completed the merger with Oclaro. We recognized goodwill in the amount of $348.5 million for the acquisition of Oclaro and allocated it to our OpComms segment. The following table presents the changes in goodwill by our reportable segments during the nine months ended March 30, 2019 (in millions):

[0001633978-19-000030:notes:204]
|  | Optical Communications |  | Commercial Lasers |  | Total |
| Balance as of December 29, 2018 | $ | 5.9 |  |  | $ | 5.4 |  |  | $ | 11.3 |  |
| Acquisition of Oclaro | 333.4 |  |  | — |  |  | 333.4 |  |
| Measurement period adjustments (1) | 15.1 |  |  | — |  |  | 15.1 |  |
| Balance as of March 30, 2019 | $ | 354.4 |  |  | $ | 5.4 |  |  | $ | 359.8 |  |

[0001633978-19-000030:notes:205]
(1) Refer to “Note 5. Business Combination” for details of these measurement period adjustments.

[0001633978-19-000030:notes:206]
[same as prior period, unchanged from 0001633978-19-000002:notes:214]

[0001633978-19-000030:notes:207]
We review goodwill for impairment during the fourth quarter of each fiscal year or more frequently if events or circumstances indicate that an impairment loss may have occurred. In the fourth quarter of fiscal 2018, we completed the annual impairment test of goodwill, which indicated there was no goodwill impairment. During the three and nine months ended March 30, 2019 and March 31, 2018, there have been no events or circumstances that have required us to perform an interim assessment of goodwill for impairment.

[0001633978-19-000030:notes:208]
[same as prior period, unchanged from 0001633978-19-000002:notes:216]

[0001633978-19-000030:notes:209]
In connection with our acquisition of Oclaro on December 10, 2018, we recorded $443.0 million as our preliminary estimate of the fair value of the acquired developed technologies and other intangible assets. The intangible assets acquired from Oclaro consist of the following:

[0001633978-19-000030:notes:210]
| Intangible |  | Fair value(in millions) |  | Weighted average amortization period(in years) |
| Acquired developed technologies |  | $ | 182.0 |  |  | 4.4 years |
| Customer relationships |  | 145.0 |  |  | 8 years |
| In-process research and development (1) |  | 94.0 |  |  | n/a |
| Order backlog |  | 22.0 |  |  | 1 year |
| Total intangible assets (1) |  | $ | 443.0 |  |  |  |

[0001633978-19-000030:notes:211]
(1) The intangible balance at March 30, 2019 excludes $1.0 million In-process research and development assets classified as assets held-for-sale.

[0001633978-19-000030:notes:212]
The intangible assets are amortized on a straight-line basis over the estimated useful lives, except for customer relationships and order backlog, which are amortized using an accelerated method of amortization over the expected customer lives, which more accurately reflects the pattern of realization of economic benefits expected to be obtained. Acquired developed technologies and order backlog are amortized to cost of sales and customer relationships is amortized to selling, general and administrative. IPR&D is initially capitalized at fair value as an intangible asset with an indefinite life and assessed for impairment thereafter. When an IPR&D project is completed, the IPR&D is reclassified as an amortizable purchased intangible asset and amortized over the asset’s estimated useful life expected to range between 4 to 9 years.

[0001633978-19-000030:notes:213]
[same as prior period, unchanged from 0001633978-19-000002:notes:220]

[0001633978-19-000030:notes:214]
| March 30, 2019: | Gross Carrying Amount |  | Accumulated Amortization |  | Net |
| Acquired developed technologies | $ | 287.5 |  |  | $ | (113.8 | ) |  | $ | 173.7 |  |
| Customer relationships and order backlog | 171.3 |  |  | (26.7 | ) |  | 144.6 |  |
| In-process research and development (1) | 94.0 |  |  | — |  |  | 94.0 |  |
| Other intangibles | 2.7 |  |  | (2.7 | ) |  | — |  |
| Total intangible assets (1) | $ | 555.5 |  |  | $ | (143.2 | ) |  | $ | 412.3 |  |

[0001633978-19-000030:notes:215]
[same as prior period, unchanged from 0001633978-19-000002:notes:222]

[0001633978-19-000030:notes:216]
[same as prior period, unchanged from 0001633978-19-000002:notes:223]

[0001633978-19-000030:notes:217]
During the three and nine months ended March 30, 2019, we recorded $31.7 million and $37.7 million, respectively, of amortization related to intangibles assets. During the three and nine months ended March 31, 2018, we recorded $0.8 million and $2.4 million, respectively, of amortization related to acquired developed technologies.

[0001633978-19-000030:notes:218]
Based on the carrying amount of our acquired developed technologies and other intangibles, excluding IPR&D, as of March 30, 2019, and assuming no future impairment of the underlying assets, the estimated future amortization is as follows (in millions):

[0001633978-19-000030:notes:219]
| Fiscal Years |  |
| Remainder of 2019 | $ | 16.9 |  |
| 2020 | 71.9 |  |
| 2021 | 66.3 |  |
| 2022 | 63.6 |  |
| Thereafter | 99.6 |  |
| Total | $ | 318.3 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001633978-19-000030:notes:220]
[same as prior period, unchanged from 0001633978-19-000002:notes:227]

[0001633978-19-000030:notes:221]
The comparability of our operating results in the first three quarters of fiscal 2019 compared to the corresponding prior year period was impacted by the U.S. Tax Cuts and Jobs Act of 2017 (the “Tax Act”), which was enacted on December 22, 2017. The Tax Act introduced significant changes to U.S. income tax law including reducing the U.S. federal statutory tax rate from 35% to 21% and imposing new taxes on certain foreign-sourced earnings and certain intercompany payments. Due to the timing of the enactment and the complexity involved in applying the provisions of the Tax Act, we made reasonable estimates of the effects and recorded provisional amounts in our financial statements as of fiscal 2018 in accordance with SEC Staff Accounting Bulletin No. 118 (“SAB 118”). During the period ended December 29, 2018, we completed our accounting for the Tax Act with no material adjustment to our provisional estimates recorded.

[0001633978-19-000030:notes:222]
Our tax provision for interim periods is determined using an estimate of our annual effective tax rate, adjusted for discrete items, if any, that arise during the period. Each quarter, we update our estimate of the annual effective tax rate, and if the estimated annual effective tax rate changes, we make a cumulative adjustment in such period. Our quarterly tax provision and estimate of our annual effective tax rate are subject to variation due to several factors, including variability in pre-tax income (or loss), the mix of jurisdictions to which such income relates, changes in how we do business, and tax law developments

[0001633978-19-000030:notes:223]
We recorded a tax benefit of $8.2 million and $1.6 million for the three and nine months ended March 30, 2019, respectively. Our estimated effective tax rate for the fiscal 2019 differs from the 21% U.S. statutory rate primarily due to the income tax benefit of the earnings of our foreign subsidiaries being taxed at rates that differ from the U.S. statutory rate as well as the U.S. federal R&D tax credit, partially offset by the income tax expense from non-deductible stock-based compensation and the tax effect of Global Intangible Low-Taxed Income (“GILTI”), Base Erosion and Anti-Abuse Tax (“BEAT”), and subpart F inclusion.

[0001633978-19-000030:notes:224]
We recorded an immaterial tax benefit and a tax benefit of $112.9 million for the three and nine months ended March 31, 2018, respectively.

[0001633978-19-000030:notes:225]
As of March 30, 2019, we had $6.7 million of unrecognized tax benefits, which, if recognized, would affect the effective tax rate. We are subject to examination of income tax returns by various domestic and foreign tax authorities. The timing of resolutions and closures of tax audits is highly unpredictable. Although it is possible that certain tax audits may be concluded within the next 12 months, we cannot reasonably estimate the impact to tax expense and net income from tax exams that could be resolved or closed within next 12 months. Subject to audit timing and uncertainty, we expect our unrecognized tax benefit amount that could affect the effective tax rate to remain materially unchanged over the next 12 months. During the three months ended March 30, 2019, we settled the Canadian income tax examination for fiscal years 2000 and 2001, which resulted in a $1.5 million decrease in unrecognized tax benefit compared to prior quarter.  As a result of the expiration of the statute of limitations for our affiliates in Germany (fiscal years 2012 and 2013) and Luxembourg (fiscal year 2013), $0.9 million of unrecognized tax benefit was reversed during the three months ended March 30, 2019.

[0001633978-19-000030:notes:226]
We have a research and development cost sharing arrangement with one of our foreign affiliates. On July 24, 2018, the Ninth Circuit Court of Appeals (the “Court”) issued an opinion in Altera Corp. v. Commissioner requiring related parties in an intercompany cost sharing arrangement to share expenses related to stock-based compensation. This opinion reversed the prior decision of the United States Tax Court. On August 7, 2018, the Court withdrew the opinion issued on July 24, 2018 to allow time for a reconstituted panel of judges to confer. We will continue to monitor the case and potential impact to our consolidated financial statements.


## us-gaap:InterestIncomeAndInterestExpenseDisclosureTableTextBlock

[0001633978-19-000030:notes:227]
[same as prior period, unchanged from 0001633978-19-000002:notes:235]

[0001633978-19-000030:notes:228]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 30, 2019 |  | March 31, 2018 |  | March 30, 2019 |  | March 31, 2018 |
| Contractual interest expense | $ | 6.2 |  |  | $ | — |  |  | $ | 10.2 |  |  | $ | — |  |
| Amortization of the debt issuance costs | 0.4 |  |  | — |  |  | 0.5 |  |  | — |  |
| Total interest expense | $ | 6.6 |  |  | $ | — |  |  | $ | 10.7 |  |  | $ | — |  |


## us-gaap:LongTermDebtTextBlock

[0001633978-19-000030:notes:229]
Note 7. Term Loan Facility

[0001633978-19-000030:notes:230]
On March 11, 2018, in connection with the Oclaro merger, Lumentum entered into a commitment letter with Deutsche Bank Securities Inc. and Deutsche Bank AG New York Branch (“Deutsche Bank”), pursuant to which, Deutsche Bank committed to provide a senior secured term loan facility to finance the merger.

[0001633978-19-000030:notes:231]
On December 10, 2018 (the “Closing Date”), concurrent with the closing of the Oclaro merger, Lumentum entered into a Credit and Guarantee Agreement (the “Credit Agreement”), by and among Lumentum, certain subsidiaries of Lumentum, the lenders party thereto, and Deutsche Bank, as administrative agent and collateral agent for the lenders. The Credit Agreement provides for a senior secured term loan facility (the “Term Loan Facility”) in an aggregate principal amount of $500.0 million. The term loans available under the Term Loan Facility were fully drawn on the Closing Date and the proceeds of the term loans were used to consummate the merger and pay fees and expenses in connection with the merger and the Term Loan Facility.

[0001633978-19-000030:notes:232]
The term loans will mature on the seventh anniversary of the Closing Date, at which time all outstanding principal and accrued and unpaid interest on the term loans must be repaid.  Commencing on the last business day of the first full fiscal quarter after the Closing Date, the term loans will amortize in equal quarterly installments equal to 0.25% of the original principal amount of the Term Loans, with the balance payable due on December 10, 2025, the maturity date. We are required to make mandatory prepayments of the outstanding principal amount of term loans with the net cash proceeds from the disposition of certain assets and the receipt of insurance proceeds upon certain casualty and condemnation events, in each case, to the extent in excess of the certain threshold amounts and to the extent not reinvested within a specified time period. We are also required to make mandatory prepayments of the outstanding principal amount of term loans from the incurrence of certain types of indebtedness and from any excess cash flow beyond stated threshold amounts. We have the right to prepay the term loans, in whole or in part, at any time without premium or penalty, subject to certain limitations and a 1.00% soft call premium applicable during the first six months following the Closing Date.

[0001633978-19-000030:notes:233]
The term loans bear interest at a rate equal to an applicable margin plus, at our option, either (a) a base rate equal to the highest of (i) the prime rate then in effect, (ii) the federal funds rate, plus 0.50% and (iii) an adjusted LIBOR rate determined on the basis of a one-month interest period, plus 1.0%, subject to a floor of 0.0%, or (b) an adjusted LIBOR rate, subject to a floor of 0.0%. The applicable margin with respect to the initial term loans is equal to 2.50% in the case of LIBOR rate loans and 1.50% in the case of base rate loans. The applicable margin is adjusted following the first full fiscal quarter after the Closing Date, if our first lien net leverage ratio is equal to or less than 0.50:1.00, to 2.25% in the case of LIBOR rate loans and 1.25% in the case of base rate loans. During the three and nine months ended March 30, 2019, we recorded interest expense of $6.5 million and $8.0 million respectively related to the initial term loans, which is included in interest and other income (expense), net in our condensed consolidated statements of operations.

[0001633978-19-000030:notes:234]
The commitment letter with Deutsche Bank required payment of a ticking fee. During the three and nine months ended March 30, 2019, we recorded total expenses in connection with the ticking fee of zero and $2.7 million, respectively. This ticking fee expense is included in interest and other income (expense), net in our condensed consolidated statements of operations. During the three and nine months ended March 30, 2019 we paid $1.3 million of principal on the term loan.

[0001633978-19-000030:notes:235]
The Credit Agreement permits us to add one or more incremental term loan facilities. Incremental loans are subject to certain additional conditions, including, without limitation, obtaining additional commitments from the lenders then party to the Credit Agreement or from new lenders.

[0001633978-19-000030:notes:236]
Our obligations under the Credit Agreement are required to be guaranteed by certain of our domestic subsidiaries meeting materiality thresholds set forth in the Credit Agreement. Such obligations, including the guaranties, are secured by substantially all of the assets of Lumentum and Lumentum’s subsidiary guarantors (other than customarily excluded assets) pursuant to a Pledge and Security Agreement, dated as of December 10, 2018, by and among Lumentum and Deutsche Bank.

[0001633978-19-000030:notes:237]
The Credit Agreement contains customary affirmative and negative covenants, including covenants limiting the ability of Lumentum and its restricted subsidiaries to, among other things, incur debt, grant liens, undergo certain fundamental changes, make investments, make certain restricted payments, dispose of assets, and enter into transactions with affiliates, in each case, subject to limitations and exceptions set forth in the Credit Agreement. The Credit Agreement also contains customary events of default that include, among other things, certain payment defaults, cross defaults to other indebtedness, covenant defaults, change of control defaults, judgment defaults, and bankruptcy and insolvency defaults. If an event of default exists, the lenders may require the immediate payment of all obligations under the Credit Agreement, and may exercise certain other rights and remedies provided for under the Credit Agreement, the other loan documents and applicable law. As of March 30, 2019, we were in compliance with all of the covenants.

[0001633978-19-000030:notes:238]
We incurred $9.3 million of debt issuance costs in connection with the Term Loan Facility which were capitalized and recorded as a contra liability in our condensed consolidated balance sheet. These costs will be amortized to interest expense using the effective interest rate method from the issuance date of December 10, 2018, through the end of the term of the loan. As of March 30, 2019, the effective interest rate is 5.27% and the stated interest rate is 4.99%.

[0001633978-19-000030:notes:239]
The following table sets forth balance sheet information related to the term loan at March 30, 2019 (in millions):

[0001633978-19-000030:notes:240]
|  | March 30, 2019 |
| Principal | $ | 500.0 |  |
| Repayment of principal | (1.3 | ) |
| Unamortized value of the debt issuance costs | (8.8 | ) |
| Net carrying value | $ | 489.9 |  |
| Term loan, current | $ | 5.0 |  |
| Term loan, non-current | $ | 484.9 |  |


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0001633978-19-000030:notes:241]
Note 5. Business Combination

[0001633978-19-000030:notes:242]
On December 10, 2018, we acquired all of the outstanding common stock of Oclaro, a provider of optical components and modules for the long-haul, metro and data center markets. Oclaro’s products provide differentiated solutions for optical networks and high-speed interconnects driving the next wave of streaming video, cloud computing, application virtualization and other bandwidth-intensive and high-speed applications. This acquisition strengthens our product portfolio, including gaining Oclaro’s leading indium phosphide laser and photonic integrated circuit and coherent component and module capabilities; broadens our revenue mix; and positions us strongly to meet the future needs of our customers.

[0001633978-19-000030:notes:243]
Pursuant to the merger agreement, Prota Merger Sub, Inc., a Delaware corporation and a wholly owned subsidiary of Lumentum (“Merger Sub”), merged with and into Oclaro (the “Merger”), with Oclaro surviving the Merger. Each outstanding share of Oclaro common stock, par value $0.01 per share, was automatically converted into the right to receive the following consideration (collectively, the “Merger Consideration”), without interest:

[0001633978-19-000030:notes:244]
•$5.60 in cash (the “Cash Consideration”) and;

[0001633978-19-000030:notes:245]
| • | 0.0636 of a share of Lumentum common stock, par value $0.001 per share (the “Exchange Ratio”). |

[0001633978-19-000030:notes:246]
The total fair value of consideration given in connection with the acquisition of Oclaro consisted of the following:

[0001633978-19-000030:notes:247]
|  | Shares | Per Share | Total Consideration(in millions) |
| Cash paid for outstanding Oclaro common stock |  |  | $ | 964.8 |  |
| Lumentum common shares issued to Oclaro stockholders | 10,941,436 |  | $ | 41.80 |  | 457.4 |  |
| Replacement equity awards for Oclaro equity awards |  |  | 2.7 |  |
| Total consideration |  |  | $ | 1,424.9 |  |

[0001633978-19-000030:notes:248]
Each Oclaro restricted stock unit award (“Oclaro RSU”) that did not become vested at the close of the transaction was converted into a Lumentum restricted stock unit award (a “Lumentum RSU”) with similar terms and conditions, including vesting, that were applicable to such Oclaro RSU, at a ratio of one Oclaro share to 0.1933 shares of Lumentum common stock. The 0.1933 ratio was determined based on the sum of (i) the 0.0636 shares of common stock received by Oclaro common stockholders for every one share of Oclaro common stock, plus (ii) the $5.60 per share received by Oclaro common stockholders, divided by $43.189 (Lumentum’s average closing price for the 10 trading days ending on December 4, 2018, the third trading day prior to the Closing Date).

[0001633978-19-000030:notes:249]
Each Oclaro stock option (“Oclaro Option”), whether vested or unvested, was converted into a Lumentum stock option (“Lumentum Option”) with similar terms and conditions, including vesting, that were applicable to such Oclaro Option, except that (i) the number of shares subject to the Lumentum Option equals the number of Oclaro shares subject to such Oclaro Option multiplied by 0.1933 and (ii) the exercise price of the Lumentum Option equals the exercise price per share of the Oclaro Option divided by 0.1933. Any Oclaro Option that was held by non-employees was cancelled and converted into the right to receive the Merger Consideration for each net option share covered by such Oclaro Option, subject to applicable withholding taxes.

[0001633978-19-000030:notes:250]
In addition, each Oclaro restricted stock award (“Oclaro Restricted Stock Award”) and Oclaro RSU that became vested with the close of the transaction was converted into the right to receive the Merger Consideration.

[0001633978-19-000030:notes:251]
The total transaction consideration was $1.4 billion, which was funded by the issuance of Lumentum common stock, new debt (refer to “Note 6. Goodwill and Other Intangible Assets”), and cash balances of the combined company. We also recorded $2.2 million and $18.1 million, respectively, in acquisition-related costs in each of the three and nine months ended March 30, 2019, representing professional and other direct acquisition costs. These costs are recorded within selling, general and administrative operating expense and within interest and other income (expense), net in our condensed consolidated statements of operations. The Company also incurred $9.3 million of debt financing costs which has been recorded as a contra liability. “Refer to Note 7. Term Loan Facility.”

[0001633978-19-000030:notes:252]
From the acquisition date, Oclaro contributed $119.3 million and $148.9 million, respectively of our consolidated net revenue for each of the three and nine months ended March 30, 2019. Due to the continued integration of the combined businesses, it is impractical to determine Oclaro’s contribution to our net income.

[0001633978-19-000030:notes:253]
We allocated the fair value of the purchase consideration to the tangible assets, liabilities and intangible assets acquired, including in-process research and development, or IPR&D, generally based on their estimated fair values. The excess purchase price over those fair values is recorded as goodwill. IPR&D is initially capitalized at fair value as an intangible asset with an indefinite life  and assessed for impairment thereafter. When an IPR&D project is completed, the IPR&D is reclassified as an amortizable purchased intangible asset and amortized over the asset’s estimated useful life.  Our valuation assumptions of acquired assets and assumed liabilities require significant estimates, especially with respect to intangible assets. Our preliminary allocation of the purchase price of Oclaro, based on the estimated fair values of the assets acquired and liabilities assumed as of the acquisition date, is as follows (in millions):

[0001633978-19-000030:notes:254]
|  | Purchase Price Allocation |
|  | Previously reported | Measurement period adjustments | As adjusted |
| Cash and cash equivalents | $ | 345.0 |  | $ | — |  | $ | 345.0 |  |
| Accounts receivable, net | 68.0 |  |  | 68.0 |  |
| Inventories | 153.2 |  | 0.9 |  | 154.1 |  |
| Prepayments and other current assets | 33.7 |  |  | 33.7 |  |
| Property, plant and equipment, net | 128.6 |  | 6.7 |  | 135.3 |  |
| Intangibles | 444.0 |  |  | 444.0 |  |
| Deferred income tax asset | 54.1 |  |  | 54.1 |  |
| Other non-current assets | 16.6 |  |  | 16.6 |  |
| Accounts payable | (57.8 | ) |  | (57.8 | ) |
| Accrued payroll and related expenses | (11.4 | ) |  | (11.4 | ) |
| Accrued expenses | (8.3 | ) |  | (8.3 | ) |
| Other current liabilities | (8.1 | ) |  | (8.1 | ) |
| Deferred tax liability | (55.8 | ) | (20.1 | ) | (75.9 | ) |
| Other non-current liabilities | (10.3 | ) | (2.6 | ) | (12.9 | ) |
| Goodwill | 333.4 |  | 15.1 |  | 348.5 |  |
| Total purchase price | $ | 1,424.9 |  | $ | — |  | $ | 1,424.9 |  |

[0001633978-19-000030:notes:255]
The provisional amounts presented in the table above pertained to the preliminary purchase price allocation reported in our Form 10-Q for the quarter ended December 29, 2018. The measurement period adjustments were primarily related to the announcement of an agreement with Cambridge Industries Group (CIG) in which we will sell them several product lines within our Datacom business based in Sagamihara, Japan as well as transfer the related employees. This business was acquired on December 10, 2018 as part of the acquisition of Oclaro. These assets and liabilities were recorded at fair value less cost to sell and the adjustments to fair value were recorded as measurement period adjustments. As a result of these fair value adjustments to assets and liabilities we also recorded tax adjustment of $2 million. The measurement period adjustment also included  an adjustment of $18.1 million to deferred tax asset valuation allowances on the completion of additional analysis.

[0001633978-19-000030:notes:256]
We do not believe that the measurement period adjustments had a material impact on our consolidated statements of operations, balance sheets or cash flows in any periods previously reported.

[0001633978-19-000030:notes:257]
The merger consideration allocation set forth herein is preliminary and may be revised as additional information becomes available during the measurement period which could be up to 12 months from the closing date of the acquisition. Any such revisions or changes may be material.

[0001633978-19-000030:notes:258]
Goodwill and intangibles have been assigned to the OpComms segment. The preliminary goodwill of $348.5 million arising from the acquisition is attributed to the expected synergies, including future cost efficiencies, and other benefits that are expected to be generated by combining Lumentum and Oclaro. Substantially all of the goodwill recognized is not expected to be deductible for tax purposes. See “Note 6. Goodwill and Other Intangible Assets” for more information on goodwill and IPR&D.

[0001633978-19-000030:notes:259]
During the second quarter of fiscal 2019, we recorded $20.9 million in restructuring and stock-based compensation expense in our condensed consolidated statements of operations, attributable to severance and employee related benefits associated with Oclaro’s executive severance and retention agreements. These retention agreements provide, under certain circumstances, for payments and benefits upon an involuntary termination of employment, including following a change in control of Oclaro. The payments and benefits payable under these arrangements in the event of a change in control of Oclaro are subject to a “double trigger,” meaning that both a change in control of Oclaro and a subsequent involuntary termination of employment by Lumentum are required.  In other words, the change in control of Oclaro does not by itself trigger any payments or benefits. Instead, payments and benefits are paid only if the employment of the employee is subsequently terminated without “cause” (or the employee resigns for “good reason”) during a specified period following the change in control. We incurred total expense of $20.9 million during the second quarter of fiscal 2019, of which $5.7 million relates to cash severance as part of our restructuring expense which is recorded within restructuring and related charges in our condensed consolidated statements of operations (refer to “Note 14. Restructuring and Related Charges”) and $15.2 million relates to the acceleration of equity awards which is recorded within both cost of sales and selling, general and administrative expense, in our condensed consolidated statements of operations (refer to “Note 17. Stock-Based Compensation and Stock Plans”).

[0001633978-19-000030:notes:260]
We continually evaluate our existing portfolio of businesses to maximize long-term shareholder value. As discussed above,  we  announced an agreement with Cambridge Industries Group (CIG) in which we will sell them several product lines within our Datacom business based in Sagamihara, Japan as well as transfer the related employees.  The transaction was completed on April 18, 2019, and as part of the transaction, we will also provide transition services to CIG for a period of up to 24 months and the cost of these services will be reimbursed to us by CIG. The purpose of these services is to provide short-term assistance to the buyer in assuming the operations of the purchased business. The transaction is subject to customary closing conditions.

[0001633978-19-000030:notes:261]
The Company considers assets and liabilities as held-for-sale when management approves and commits to a plan to actively market assets or group of assets for sale. Assets held-for-sale are recorded initially at the lower of its carrying value or its estimated fair value, less estimated costs to sell. Upon designation as an asset held-for-sale, the Company discontinues recording depreciation expense on such asset.

[0001633978-19-000030:notes:262]
This transaction did not meet the criteria for assets held-for-sale under the relevant accounting guidance as of December 10, 2018, the date of our acquisition of Oclaro, in our purchase price allocation. The assets and liabilities are classified as assets held-for-sale on our consolidated balance sheet as of March 30, 2019 and carried at fair value less costs to sell.

[0001633978-19-000030:notes:263]
Assets and liabilities classified as held-for-sale as of result of this disposition on March 30, 2019 were as follows (in millions):

[0001633978-19-000030:notes:264]
|  | March 30, 2019 |
| Assets held-for-sale |  |  |
| Cash | $ | 1.0 |  |
| Inventories | 5.1 |  |
| Other Intangible assets | 1.0 |  |
| Property, plant and equipment, net | 26.5 |  |
| Total | $ | 33.6 |  |
| Liabilities held-for-sale |  |
| Retirement obligation | $ | 4.5 |  |
| Capital lease obligation | 1.0 |
| Other liabilities | 0.9 |
| Total | $ | 6.4 |  |
| Net | $ | 27.2 |  |

[0001633978-19-000030:notes:265]
The fair values were determined in the preliminary allocation of the Oclaro acquisition, adjusted for operating activity since December 10, 2018, and based on standard valuation techniques with inputs that are unobservable and significant to the overall fair value measurement, refer to “Note 9. “Balance Sheet and Other Details”.

[0001633978-19-000030:notes:266]
Supplemental Pro Forma Information

[0001633978-19-000030:notes:267]
The supplemental pro forma financial information presented below is for illustrative purposes only and is not necessarily indicative of the financial position or results of operations that would have been realized if the acquisition had been completed on the date indicated, does not reflect synergies that might have been achieved, nor is it indicative of future operating results or financial position. The pro forma adjustments are based upon currently available information and certain assumptions we believe are reasonable under the circumstances.

[0001633978-19-000030:notes:268]
The following supplemental pro forma information presents the combined results of operations for the nine months ended March 30, 2019 and March 31, 2018, as if Oclaro had been acquired as of the beginning of fiscal year 2018. The supplemental pro forma information includes adjustments to amortization and depreciation for acquired intangible assets and property and equipment, adjustments to share-based compensation expense, the fair value adjustments on the inventories acquired, transaction costs, interest expense and amortization of the term loan debt issuance costs. For fiscal year 2018, nonrecurring pro forma adjustments directly attributable to the Oclaro acquisition included (i) restructuring and stock-based compensation expense of $20.9 million, (ii) the purchase accounting effect of inventories acquired of $60.3 million and (iii) transaction costs of $25.2 million.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001633978-19-000030:notes:269]
Accounting Pronouncements Recently Adopted

[0001633978-19-000030:notes:270]
In May 2014, the Financial Accounting Standards Board (“FASB”) issued ASU 2014-09 (Topic 606), which amended the existing accounting standards for revenue recognition. Topic 606 outlines a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers. The guidance is effective for annual reporting periods including interim reporting periods beginning after December 15, 2017. On July 1, 2018, we adopted Topic 606 using the modified retrospective method applied to all contracts that are not completed contracts at the date of initial adoption (i.e., July 1, 2018). Results for reporting periods after July 1, 2018 are presented under Topic 606, while prior period amounts are not adjusted and continue to be reported in accordance with our historical accounting under Topic 605. The adoption of Topic 606 did not have a material impact on the nature and timing of our revenues, condensed consolidated statements of operations, cash flows, and balance sheets and therefore, we do not present results for the three and nine months ended March 30, 2019 under Topic 605. Refer to “Note 1. Description of Business and Summary of Significant Accounting Policies” for the changes in our accounting policies due to adoption of Topic 606.

[0001633978-19-000030:notes:271]
Select condensed consolidated balance sheet line items, as if we had adopted Topic 606 prior to July 1, 2018 are summarized below as of the periods presented (in millions):

[0001633978-19-000030:notes:272]
|  | June 30, 2018 |  | Adjustments |  | July 1, 2018 |
| Assets: |  |  |  |  |  |
| Accounts receivable, net | $ | 197.1 |  |  | $ | 0.6 |  |  | $ | 197.7 |  |
| Inventories | 153.6 |  |  | (1.2 | ) |  | 152.4 |  |
| Stockholders’ equity: |  |  |  |  |  |
| Retained earnings | $ | 166.4 |  |  | $ | (0.6 | ) |  | $ | 165.8 |  |

[0001633978-19-000030:notes:273]
In August 2016, FASB issued ASU 2016-15, Statement of Cash Flows (Topic 230): Classification of Certain Cash Receipts and Cash Payments, which clarifies how companies present and classify certain cash receipts and cash payments in the statement of cash flows. The amendments contained in ASU 2016-15 are effective for interim and annual periods beginning after December 15, 2017. We adopted ASU 2016-15 on July 1, 2018 on a prospective basis. The application of ASU 2016-15 will have a material impact on our consolidated financial statements if we elect to settle the principal amounts of our 2024 Notes (refer to “Note 13. Convertible Notes”) in cash and on repayment of the term loan (refer to “Note 7. Term Loan Facility”). The principal repayment will be bifurcated between (i) cash outflows for operating activities of $146.9 million for the portion related to accreted interest attributable to debt discount, and (ii) financing activities for the remainder of $803.1 million.

[0001633978-19-000030:notes:274]
In January 2017, FASB issued ASU 2017-01, Business Combinations (Topic 805), which clarifies the definition of a business. For accounting and financial reporting purposes, businesses are generally comprised of three elements; inputs, processes, and outputs. Integrated sets of assets and activities capable of providing these three elements may not always be considered a business, and the lack of one of the three elements does not always disqualify the set from being a business. The issuance of ASU 2017-01 provides a clarifying test to determine when a set of assets and activities is not a business. Primarily, the test requires that when substantially all of the fair value of the gross assets acquired is concentrated in a single identifiable asset or group of similar identifiable assets, the set is not a business. The amendments contained in ASU 2017-01 are effective for annual periods beginning after December 15, 2017, including interim periods within those periods. We adopted ASU 2017-01 on July 1, 2018 on a prospective basis. The implementation of ASU 2017-01 did not have an impact on our condensed consolidated financial statements.

[0001633978-19-000030:notes:275]
In October 2016, FASB issued ASU 2016-16, Accounting for Income Taxes: Intra-Entity Asset Transfers of Assets other than Inventory. The new guidance removes the prohibition in ASC 740 against the immediate recognition of the current and deferred income tax effects of intra-entity transfers of assets other than inventory. The new guidance became effective for us in the first quarter of our fiscal 2019. The adoption of ASU 2016-16 did not have a material impact on our financial statements.

[0001633978-19-000030:notes:276]
In August 2018, FASB issued ASU 2018-15, Intangibles-Goodwill and Other-Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract. ASU 2018-15 requires an entity in a hosting arrangement that is a service contract to follow the guidance in Subtopic 350-40 to determine which implementation costs to capitalize as an asset related to the service contract and which costs to expense. Implementation costs capitalized must be expensed over the term of the hosting arrangement, including the period covered by an option to extend the arrangement. The standard is effective for fiscal years beginning after December 15, 2019, and interim periods within those fiscal years, and should be applied either retrospectively or prospectively to all implementation costs incurred after the date of adoption. Early adoption is permitted, including adoption in any interim period, for all entities. We early adopted ASU 2018-15, which did not have a material impact on our financial statements.

[0001633978-19-000030:notes:277]
In August 2018, the Securities and Exchange Commission (“SEC”) adopted amendments to certain disclosure requirements in Securities Act Release No. 33-10532, Disclosure Update and Simplification. The amendments became effective on November 5, 2018.  Among the amendments is the requirement to present the changes in shareholders’ equity in the interim financial statements (either in a separate statement or footnote) in quarterly reports on Form 10-Q. The analysis should present a reconciliation of the beginning balance to the ending balance of each period for which a consolidated statement of operations is required to be filed. The final rule was effective on November 5, 2018. The Company has adopted the final rule as of March 30, 2019, and has included a reconciliation of the changes in statements of redeemable convertible preferred stock, stockholders' equity, and invested equity in this Form 10-Q.

[0001633978-19-000030:notes:278]
Accounting Pronouncements Not Yet Effective

[0001633978-19-000030:notes:279]
In August 2018, FASB issued ASU 2018-14, Compensation-Retirement Benefits-Defined Benefit Plans-General (Topic 715-20): Disclosure Framework-Changes to the Disclosure Requirements for Defined Benefit Plans. ASU 2018-14 modifies the disclosure requirements for defined benefit pension plans and other postretirement benefit plans. The new guidance is effective for fiscal years ending after December 15, 2020 and early adoption is permitted. ASU 2018-14 should be applied retrospectively to all periods presented and is effective for us in our first quarter of fiscal 2022. We are currently evaluating the impact of ASU 2018-14 on our consolidated financial statements.

[0001633978-19-000030:notes:280]
In August 2018, FASB issued ASU 2018-13, Fair Value Measurement (Topic 820): Disclosure Framework-Changes to the Disclosure Requirements for Fair Value Measurement. ASU 2018-13 modifies the disclosure requirements for fair value measurements. The new guidance is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. Entities are permitted to early adopt any removed or modified disclosures upon issuance of ASU 2018-13 and delay adoption of the additional disclosures until the effective date. The standard is effective for us in our first quarter of fiscal 2021. We are currently evaluating the impact of ASU 2018-13 on our consolidated financial statements and related disclosures.

[0001633978-19-000030:notes:281]
In February 2018, FASB issued ASU 2018-02, Income Statement-Reporting Comprehensive Income (Topic 220): Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income, which allows companies to reclassify stranded tax effects resulting from the Tax Act, from accumulated other comprehensive income to retained earnings. The guidance also requires certain new disclosures regardless of the election. The amendments in ASU 2018-02 are effective for all entities for fiscal years beginning after December 15, 2018, and interim periods within those fiscal years. Early adoption is permitted, including adoption in any interim period. ASU 2018-02 is effective for us in the first quarter of fiscal 2020. We are currently evaluating the impact of our pending adoption of ASU 2018-02 on our consolidated financial statements.

[0001633978-19-000030:notes:282]
In January 2017, FASB issued ASU 2017-04, Intangibles - Goodwill and Other (Topic 350): Simplifying the Accounting for Goodwill Impairment. ASU 2017-04 removes the requirement to perform a hypothetical purchase price allocation to measure goodwill impairment. A goodwill impairment charge will be the amount by which a reporting unit's carrying value exceeds its fair value, not to exceed the carrying amount of goodwill. The amendments contained in ASU 2017-04 are effective for interim and annual periods beginning after December 15, 2019, with early adoption permitted, which should be applied prospectively. We plan to adopt the accounting standard update in our first quarter of fiscal 2020. We are currently evaluating the impact of ASU 2017-04 on our consolidated financial statements.

[0001633978-19-000030:notes:283]
In June 2016, FASB issued ASU 2016-13, Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments and a subsequent amendment, ASU 2018-19 (collectively, Topic 326). Topic 326 requires measurement and recognition of expected credit losses for financial assets held. Topic 326 is effective for annual periods beginning after December 15, 2019, including interim periods within those periods, with early adoption permitted. We are currently evaluating the impact of our pending adoption of Topic 326 on our consolidated financial statements.

[0001633978-19-000030:notes:284]
In February 2016, FASB issued ASU 2016-02, Leases (Topic 842) and subsequent amendments to the initial guidance: ASU 2017-13, ASU 2018-10, ASU 2018-11 and ASU 2018-20 (collectively, Topic 842). The new guidance generally requires an entity to recognize on its balance sheet operating and financing lease liabilities and corresponding right-of-use assets. The new guidance contained in Topic 842 is effective for annual periods beginning after December 15, 2018, including interim periods within those periods, with early adoption permitted. The standard is effective for us in our first quarter of fiscal 2020 and provides an optional transition method that allows entities to apply the standard prospectively, with any cumulative-effect adjustment recorded to opening retained earnings in the period of adoption. We expect to adopt the new standard using this optional transition method.  We have also elected the practical expedients to not reassess prior conclusions related to contracts containing leases, lease classification, and initial direct costs for contracts that existed prior to adoption date. Based on our current lease portfolio, we estimate the value of leased assets and liabilities that may be recognized will be material. We are continuing to evaluate the impact of Topic 842 which is subject to change.


## us-gaap:OtherCurrentLiabilitiesTableTextBlock

[0001633978-19-000030:notes:285]
[same as prior period, unchanged from 0001633978-19-000002:notes:271]

[0001633978-19-000030:notes:286]
|  | March 30, 2019 |  | June 30, 2018 |
| Warranty accrual (1) | $ | 9.8 |  |  | $ | 6.6 |  |
| Restructuring accrual and related charges (2) | 18.0 |  |  | 1.9 |  |
| Deferred revenue and customer deposits | 4.2 |  |  | 2.8 |  |
| Capital lease obligation (3) | 0.8 |  |  | 7.3 |  |
| Income tax payable (4) | 8.5 |  |  | 0.7 |  |
| Other current liabilities | 5.4 |  |  | 2.8 |  |
| Other current liabilities (5) | $ | 46.7 |  |  | $ | 22.1 |  |

[0001633978-19-000030:notes:287]
(1) Refer to “Note 18. Commitments and Contingencies.”

[0001633978-19-000030:notes:288]
(2) Refer to “Note 14. Restructuring and Related Charges.”

[0001633978-19-000030:notes:289]
(3) In addition to the $0.8 million of capital lease obligations recorded within other current liabilities, we also recorded $2.3 million within accounts payable and $0.1 million within other non-current liabilities in the condensed consolidated balance sheet as of March 30, 2019. Refer to “Note 18. Commitments and Contingencies.”

[0001633978-19-000030:notes:290]
[same as prior period, unchanged from 0001633978-19-000002:notes:276]

[0001633978-19-000030:notes:291]
(5) Other current liabilities balance at March 30, 2019 does not include liabilities classified as held-for-sale. Refer to “Note 5. Business Combination”.


## us-gaap:OtherNoncurrentLiabilitiesTableTextBlock

[0001633978-19-000030:notes:292]
[same as prior period, unchanged from 0001633978-19-000002:notes:277]

[0001633978-19-000030:notes:293]
|  | March 30, 2019 |  | June 30, 2018 |
| Asset retirement obligation | $ | 5.4 |  |  | $ | 2.7 |  |
| Pension and related accrual (1) | 6.4 |  |  | 3.5 |  |
| Deferred rent | 2.4 |  |  | 2.6 |  |
| Unrecognized tax benefit | 6.7 |  |  | 6.1 |  |
| Capital lease obligation | 0.1 |  |  | 0.4 |  |
| Others | 0.4 |  |  | 3.4 |  |
| Other non-current liabilities (2) | $ | 21.4 |  |  | $ | 18.7 |  |

[0001633978-19-000030:notes:294]
(1) In connection with our acquisition of Oclaro, we assumed a defined benefit plan, which covers certain Japan employees. As of March 30, 2019, we recorded $2.9 million in other non-current liabilities in our condensed consolidated balance sheet to account for the projected benefit obligations.

[0001633978-19-000030:notes:295]
(2) Other non-current liabilities balance at March 30, 2019 does not include non-current liabilities classified as held-for-sale. Refer to “Note 5. Business Combination”.


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001633978-19-000030:notes:296]
[same as prior period, unchanged from 0001633978-19-000002:notes:280]

[0001633978-19-000030:notes:297]
|  | March 30, 2019 |  | June 30, 2018 |
| Land | $ | 10.6 |  |  | $ | 10.6 |  |
| Buildings and improvement | 72.9 |  |  | 55.1 |  |
| Machinery and equipment (1) | 502.7 |  |  | 463.6 |  |
| Computer equipment and software | 32.5 |  |  | 26.3 |  |
| Furniture and fixtures | 4.1 |  |  | 2.2 |  |
| Leasehold improvements | 31.4 |  |  | 25.8 |  |
| Construction in progress | 59.5 |  |  | 52.6 |  |
|  | 713.7 |  |  | 636.2 |  |
| Less: Accumulated depreciation (1) | (323.1 | ) |  | (329.3 | ) |
| Property, plant and equipment, net (2) | $ | 390.6 |  |  | $ | 306.9 |  |

[0001633978-19-000030:notes:298]
(1) In fiscal 2018, we started leasing equipment from a vendor and have accounted for the transaction as a capital lease.  Included in the table above are our capital lease assets of $16.4 million, gross and $9.8 million in accumulated depreciation as of March 30, 2019, and $15.6 million, gross and $5.2 million in accumulated depreciation as of June 30, 2018.

[0001633978-19-000030:notes:299]
During the three and nine months ended March 30, 2019, we recorded depreciation expense of $29.0 million and $74.7 million, respectively. During the three and nine months ended March 31, 2018, we recorded depreciation expense of $18.4 million and $53.3 million, respectively.

[0001633978-19-000030:notes:300]
Our construction in progress primarily includes machinery and equipment that were purchased for the set-up costs at our facility in Thailand and ramp new product lines. We expect to place these assets in service in the next 12 months.

[0001633978-19-000030:notes:301]
(2) The property, plant and equipment balance at March 30, 2019 does not include $31.4 million classified as assets held-for-sale, which includes $4.9 million related exit of our Datacom modules and $26.5 million related to CIG agreement. Refer to “Note 15. Impairment” and “Note 5. Business Combination”.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001633978-19-000030:notes:302]
Note 14. Restructuring and Related Charges

[0001633978-19-000030:notes:303]
We have initiated various strategic restructuring actions primarily intended to reduce costs, consolidate our operations, rationalize the manufacturing of our products and align our business in response to market conditions and as a result of our acquisition of Oclaro on December 10, 2018.

[0001633978-19-000030:notes:304]
The following table summarizes the activity of restructuring and related charges during the three and nine months ended March 30, 2019 and March 31, 2018 (in millions):

[0001633978-19-000030:notes:305]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 30, 2019 |  | March 31, 2018 |  | March 30, 2019 |  | March 31, 2018 |
| Balance as of beginning of period | $ | 3.5 |  |  | $ | 0.4 |  |  | $ | 1.9 |  |  | $ | 3.8 |  |
| Charges | 21.1 |  |  | 0.1 |  |  | 30.2 |  |  | 3.8 |  |
| Payments | (6.6 | ) |  | (0.5 | ) |  | (14.1 | ) |  | (7.6 | ) |
| Balance as of end of period | $ | 18.0 |  |  | $ | — |  |  | $ | 18.0 |  |  | $ | — |  |

[0001633978-19-000030:notes:306]
In our effort to continually maximize long-term shareholder value, following our acquisition of Oclaro, on March 5, 2019, we announced our plan to discontinue development and manufacturing of Lithium Niobate modulators.  A plan to wind down operations over the next few quarters was announced to employees in San Donato, Italy. The development and manufacturing will also be discontinued in our San Jose, California manufacturing locations over an extended period of time  in order to facilitate  our customers transition to new products.

[0001633978-19-000030:notes:307]
We also announced our plan to discontinue the development of future Datacom transceiver products which impacted our Milpitas and Shenzhen Datacom module teams. While we expect strong growth in Datacom volumes in the future, the market at the transceiver level is gross margin challenged due to extreme competition.  Following the Oclaro acquisition, we have a differentiated leadership position across a range of photonic chips on which the Datacom, wireless, and access markets critically rely.

[0001633978-19-000030:notes:308]
In connection with the restructuring plan, the Company calculated the fair value of the facilities-related charges of $1.6 million based on estimated future discounted cash flows which included the amount and timing of estimated sublease rental receipts that the Company could reasonably obtain over the remaining lease term and the discount rate.

[0001633978-19-000030:notes:309]
During the three and nine months ended March 30, 2019, we recorded $21.1 million and $30.2 million, respectively, in restructuring and related charges in our condensed consolidated statements of operations, primarily attributable to severance and employee related benefits associated with the wind down of operations for Lithium Niobate modulators and Datacom modules resulting in $18.0 million of severance charges and $1.6 million of lease restructuring charges.  During the three and nine months ended March 30, 2019, we also recorded restructuring charges primarily associated with acquisition related synergies.  In addition, the nine month period charges included severance and employee related benefits associated with Oclaro’s executive severance and retention agreements. These retention agreements provide, under certain circumstances, for payments and benefits upon an involuntary termination of employment.

[0001633978-19-000030:notes:310]
During the three and nine months ended March 31, 2018, we recorded $0.1 million and $3.8 million, respectively, in restructuring and related charges in our condensed consolidated statements of operations, primarily attributable to costs to vacate facilities, temporary labor and employee-related benefits, as well as costs for materials used in set up and production activities. We incurred no additional costs related to severance during the three and nine months ended March 31, 2018.

[0001633978-19-000030:notes:311]
[same as prior period, unchanged from 0001633978-19-000002:notes:290]


## us-gaap:ScheduleOfBusinessAcquisitionsByAcquisitionTextBlock

[0001633978-19-000030:notes:312]
[same as prior period, unchanged from 0001633978-19-000002:notes:291]


## us-gaap:ScheduleOfEntityWideDisclosureOnGeographicAreasLongLivedAssetsInIndividualForeignCountriesByCountryTextBlock

[0001633978-19-000030:notes:313]
[same as prior period, unchanged from 0001633978-19-000002:notes:292]

[0001633978-19-000030:notes:314]
|  | March 30, 2019 |  | June 30, 2018 |
| Property, Plant and Equipment, net |  |  |  |
| United States | $ | 101.6 |  |  | $ | 97.6 |  |
| China | 37.9 |  |  | 70.0 |  |
| Japan | 32.7 |  |  | 0.5 |  |
| Thailand | 148.8 |  |  | 107.4 |  |
| Other countries | 69.6 |  |  | 31.4 |  |
| Total long-lived assets | $ | 390.6 |  |  | $ | 306.9 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001633978-19-000030:notes:315]
[same as prior period, unchanged from 0001633978-19-000002:notes:294]

[0001633978-19-000030:notes:316]
|  | March 30, 2019 |  | June 30, 2018 |
| Finished goods | $ | 94.9 |  |  | $ | 98.2 |  |
| Work in process | 121.3 |  |  | 34.5 |  |
| Raw materials and purchased parts | 56.0 |  |  | 20.9 |  |
| Inventories (1) (2) | $ | 272.2 |  |  | $ | 153.6 |  |

[0001633978-19-000030:notes:317]
(1) The inventory balance at March 30, 2019 includes $44.5 million, net of amortization, related to the inventory step-up adjustment from the Oclaro acquisition.

[0001633978-19-000030:notes:318]
(2) The inventory balance at March 30, 2019 does not include $5.1 million classified as assets held-for-sale. Refer to “Note 5. Business Combination”.


## us-gaap:ScheduleOfOtherCurrentAssetsTableTextBlock

[0001633978-19-000030:notes:319]
[same as prior period, unchanged from 0001633978-19-000002:notes:296]

[0001633978-19-000030:notes:320]
|  | March 30, 2019 |  | June 30, 2018 |
| Capitalized manufacturing overhead | $ | 14.1 |  |  | $ | 20.5 |  |
| Prepayments | 28.8 |  |  | 19.5 |  |
| Advances to contract manufacturers | 8.3 |  |  | 14.0 |  |
| Value added tax receivable | 13.0 |  |  | 4.0 |  |
| Vendor receivable | 13.8 |  |  | 4.3 |  |
| Other current assets | 29.0 |  |  | 2.7 |  |
| Prepayments and other current assets | $ | 107.0 |  |  | $ | 65.0 |  |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0001633978-19-000030:notes:321]
[same as prior period, unchanged from 0001633978-19-000002:notes:298]

[0001633978-19-000030:notes:322]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 30, 2019 |  | March 31, 2018 |  | March 30, 2019 |  | March 31, 2018 |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States | $ | 29.7 |  |  | 6.9 | % |  | $ | 26.8 |  |  | 9.0 | % |  | $ | 72.3 |  |  | 6.2 | % |  | $ | 86.3 |  |  | 9.1 | % |
| Mexico | 53.5 |  |  | 12.4 | % |  | 41.7 |  |  | 14.0 | % |  | 164.8 |  |  | 14.2 | % |  | 97.1 |  |  | 10.3 | % |
| Other Americas | 0.9 |  |  | 0.2 | % |  | 1.5 |  |  | 0.5 | % |  | 2.7 |  |  | 0.2 | % |  | 5.7 |  |  | 0.6 | % |
| Total Americas | $ | 84.1 |  |  | 19.4 | % |  | $ | 70.0 |  |  | 23.5 | % |  | $ | 239.8 |  |  | 20.6 | % |  | $ | 189.1 |  |  | 20.0 | % |
| Asia-Pacific: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Hong Kong | $ | 124.1 |  |  | 28.6 | % |  | $ | 38.7 |  |  | 13.0 | % |  | $ | 289.6 |  |  | 25.0 | % |  | $ | 133.3 |  |  | 14.1 | % |
| Japan | 50.0 |  |  | 11.6 | % |  | 34.1 |  |  | 11.4 | % |  | 129.2 |  |  | 11.1 | % |  | 157.6 |  |  | 16.6 | % |
| South Korea | 23.6 |  |  | 5.5 | % |  | 28.8 |  |  | 9.6 | % |  | 154.9 |  |  | 13.3 | % |  | 126.3 |  |  | 13.3 | % |
| Other Asia-Pacific | 98.4 |  |  | 22.7 | % |  | 103.9 |  |  | 34.8 | % |  | 234.4 |  |  | 20.2 | % |  | 266.1 |  |  | 28.1 | % |
| Total Asia-Pacific | $ | 296.1 |  |  | 68.5 | % |  | $ | 205.5 |  |  | 68.8 | % |  | $ | 808.1 |  |  | 69.6 | % |  | $ | 683.3 |  |  | 72.1 | % |
| EMEA | $ | 52.7 |  |  | 12.2 | % |  | $ | 23.3 |  |  | 7.8 | % |  | $ | 112.8 |  |  | 9.7 | % |  | $ | 74.2 |  |  | 7.8 | % |
| Total net revenue | $ | 432.9 |  |  |  |  | $ | 298.8 |  |  |  |  | $ | 1,160.7 |  |  |  |  | $ | 946.6 |  |  |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001633978-19-000030:notes:323]
[same as prior period, unchanged from 0001633978-19-000002:notes:300]

[0001633978-19-000030:notes:324]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 30, 2019 |  | March 31, 2018 |  | March 30, 2019 |  | March 31, 2018 |
| Net revenue: |  |  |  |  |  |  |  |
| OpComms | $ | 377.9 |  |  | $ | 246.3 |  |  | $ | 1,013.4 |  |  | $ | 814.3 |  |
| Lasers | 55.0 |  |  | 52.5 |  |  | 147.3 |  |  | 132.3 |  |
| Net revenue | $ | 432.9 |  |  | $ | 298.8 |  |  | $ | 1,160.7 |  |  | $ | 946.6 |  |
| Gross profit: |  |  |  |  |  |  |  |
| OpComms | 143.5 |  |  | 83.1 |  |  | 397.5 |  |  | 317.1 |  |
| Lasers | 25.3 |  |  | 25.4 |  |  | 63.6 |  |  | 55.9 |  |
| Total segment gross profit | 168.8 |  |  | 108.5 |  |  | 461.1 |  |  | 373.0 |  |
| Unallocated corporate items: |  |  |  |  |  |  |  |
| Stock-based compensation | (3.2 | ) |  | (2.4 | ) |  | (11.7 | ) |  | (9.5 | ) |
| Amortization of intangibles | (28.1 | ) |  | (0.8 | ) |  | (33.3 | ) |  | (2.4 | ) |
| Amortization of inventory step up | (14.5 | ) |  | — |  |  | (15.8 | ) |  | — |  |
| Inventory write down due to product line exit | (19.4 | ) |  | — |  |  | (19.4 | ) |  | (7.0 | ) |
| Integration related costs | (2.8 | ) |  | — |  |  | (2.8 | ) |  | — |  |
| Other charges (1) | (12.5 | ) |  | (8.3 | ) |  | (39.0 | ) |  | (17.5 | ) |
| Gross profit | $ | 88.3 |  |  | $ | 97.0 |  |  | $ | 339.1 |  |  | $ | 336.6 |  |

[0001633978-19-000030:notes:325]
(1) “Other charges” of unallocated corporate items for the three and nine months ended March 30, 2019 primarily include costs of transferring product lines to Thailand of $12.0 million and $38.7 million, respectively. During each of the three and nine months ended March 31, 2018, “other charges” of unallocated corporate items primarily consisted of set-up costs of our facility in Thailand of $9.1 million and $15.9 million, respectively.


## us-gaap:SchedulesOfConcentrationOfRiskByRiskFactorTextBlock

[0001633978-19-000030:notes:326]
[same as prior period, unchanged from 0001633978-19-000002:notes:307]

[0001633978-19-000030:notes:327]
|  | Three Months Ended |  |  | Nine Months Ended |  |
|  | March 30, 2019 |  | March 31, 2018 |  | March 30, 2019 |  | March 31, 2018 |
| OpComms: | $ | 377.9 |  | 87.3 | % |  | $ | 246.3 |  | 82.4 | % |  | $ | 1,013.4 |  | 87.3 | % |  | $ | 814.3 |  | 86.0 | % |
| Telecom | 243.4 |  | 56.3 | % |  | 122.6 |  | 41.0 | % |  | 558.8 |  | 48.1 | % |  | 343.2 |  | 36.3 | % |
| Datacom | 57.3 |  | 13.2 | % |  | 36.3 |  | 12.1 | % |  | 124.9 |  | 10.8 | % |  | 115.9 |  | 12.2 | % |
| Consumer and Industrial | 77.2 |  | 17.8 | % |  | 87.4 |  | 29.3 | % |  | 329.7 |  | 28.4 | % |  | 355.2 |  | 37.5 | % |
| Lasers | $ | 55.0 |  | 12.7 | % |  | $ | 52.5 |  | 17.6 | % |  | $ | 147.3 |  | 12.7 | % |  | $ | 132.3 |  | 14.0 | % |

[0001633978-19-000030:notes:328]
During the three and nine months ended March 30, 2019 and March 31, 2018, net inventory purchased from a single contract manufacturer which represented 10% or greater of total net purchases is summarized as follows:

[0001633978-19-000030:notes:329]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 30, 2019 |  | March 31, 2018 |  | March 30, 2019 |  | March 31, 2018 |
| Vendor A | 60.0 | % |  | 48.0 | % |  | 54.0 | % |  | 42.0 | % |
| Vendor B | 14.0 | % |  | 19.0 | % |  | 19.0 | % |  | 19.0 | % |
| Vendor C | 11.0 | % |  | 18.0 | % |  | 12.0 | % |  | 23.0 | % |

[0001633978-19-000030:notes:330]
During the three and nine months ended March 30, 2019 and March 31, 2018, net revenue generated from a single customer which represented 10% or greater of total net revenue is summarized as follows:

[0001633978-19-000030:notes:331]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 30, 2019 |  | March 31, 2018 |  | March 30, 2019 |  | March 31, 2018 |
| Customer A | 18.4 | % |  | 11.9 | % |  | 15.3 | % |  | 11.1 | % |
| Customer B | 13.4 | % |  | 24.9 | % |  | 22.7 | % |  | 33.3 | % |
| Customer C | 12.0 | % |  | 12.9 | % |  | 13.9 | % |  | 9.3 | % |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001633978-19-000030:notes:332]
[same as prior period, unchanged from 0001633978-19-000002:notes:309]

[0001633978-19-000030:notes:333]
[same as prior period, unchanged from 0001633978-19-000002:notes:310]

[0001633978-19-000030:notes:334]
[same as prior period, unchanged from 0001633978-19-000002:notes:311]

[0001633978-19-000030:notes:335]
[same as prior period, unchanged from 0001633978-19-000002:notes:312]

[0001633978-19-000030:notes:336]
[same as prior period, unchanged from 0001633978-19-000002:notes:313]

[0001633978-19-000030:notes:337]
Our net revenue from Mexico increased due to increased demand for our ROADM products from one of our large customers who manufactures in Mexico, while net revenue from Hong Kong grew due to a change in shipment destination of a large portion of our 3D sensing products for mobile devices.

[0001633978-19-000030:notes:338]
Our accounts receivable was concentrated with one customer at March 30, 2019, who represented 17% of gross accounts receivable, respectively, compared with two customers at June 30, 2018, who represented 11% and 10% of gross accounts receivable, respectively.

[0001633978-19-000030:notes:339]
We purchase a substantial portion of our inventory from contract manufacturers and vendors located primarily in Taiwan, Thailand, and China. During the three and nine months ended March 30, 2019 and March 31, 2018, net inventory purchased from a single contract manufacturer which represented 10% or greater of total net purchases is summarized as follows:


## us-gaap:SubsequentEventsTextBlock

[0001633978-19-000030:notes:340]
Note 20. Subsequent Event

[0001633978-19-000030:notes:341]
On May 6, 2019,  the Company entered into an agreement for the purchase of property located in San Jose, California. The total purchase price for the property is $54.0 million.  The Purchase Agreement contains customary representations, warranties and covenants of the parties and the closing of the purchase is expected to occur during the Company’s fourth fiscal quarter of 2019 and is subject to conditions typical for a transaction of this type.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001633978-19-000030:notes:342]
Note 9. Balance Sheet Details

[0001633978-19-000030:notes:343]
[same as prior period, unchanged from 0001633978-19-000002:notes:318]

[0001633978-19-000030:notes:344]
As of March 30, 2019 and June 30, 2018, our accounts receivable allowance balance was $2.1 million and $2.6 million respectively.

[0001633978-19-000030:notes:345]
[same as prior period, unchanged from 0001633978-19-000002:notes:320]

[0001633978-19-000030:notes:346]
[same as prior period, unchanged from 0001633978-19-000002:notes:322]

[0001633978-19-000030:notes:347]
[same as prior period, unchanged from 0001633978-19-000002:notes:323]

[0001633978-19-000030:notes:348]
[same as prior period, unchanged from 0001633978-19-000002:notes:326]

[0001633978-19-000030:notes:349]
[same as prior period, unchanged from 0001633978-19-000002:notes:327]
