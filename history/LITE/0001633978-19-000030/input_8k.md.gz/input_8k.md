# LITE 8-K — 0001633978-19-000029 filed 2019-05-07

## item codes, every 8-K on or before 2019-05-07

- 2019-05-07 0001633978-19-000029 — 2.02, 9.01
- 2019-02-15 0001633978-19-000005 — 9.01 — amendment of 0001193125-18-346211
- 2019-02-08 0001193125-19-031591 — 5.02, 9.01
- 2019-02-05 0001633978-19-000001 — 2.02, 9.01
- 2018-12-10 0001193125-18-346211 — 1.01, 2.01, 2.03, 5.02, 8.01, 9.01
- 2018-12-06 0001633978-18-000150 — 8.01
- 2018-11-14 0001633978-18-000139 — 5.07
- 2018-11-13 0001633978-18-000136 — 3.02
- 2018-11-13 0001633978-18-000132 — 7.01, 9.01
- 2018-11-01 0001628280-18-013238 — 2.02, 9.01
- 2018-08-08 0001633978-18-000056 — 2.02, 9.01
- 2018-06-08 0001193125-18-188241 — 5.02, 9.01
- 2018-05-02 0001633978-18-000029 — 2.02, 9.01
- 2018-03-12 0001193125-18-078154 — 1.01, 2.01, 8.01, 9.01
- 2018-02-06 0001628280-18-001082 — 2.02, 9.01
- 2017-11-08 0001633978-17-000133 — 5.02, 9.01
- 2017-11-07 0001633978-17-000131 — 5.07
- 2017-11-01 0001633978-17-000117 — 2.02, 9.01
- 2017-08-09 0001633978-17-000058 — 2.02, 9.01
- 2017-05-04 0001633978-17-000035 — 2.02, 9.01
- 2017-03-08 0001193125-17-074740 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2017-03-02 0001193125-17-066769 — 8.01, 9.01
- 2017-02-07 0001633978-17-000005 — 2.02, 9.01
- 2017-01-03 0001628280-17-000018 — 4.01, 9.01
- 2016-11-09 0001628280-16-021143 — 5.02, 5.07, 9.01
- 2016-10-27 0001628280-16-020382 — 2.02, 9.01
- 2016-08-09 0001628280-16-018811 — 2.02, 9.01
- 2016-06-21 0001628280-16-017201 — 8.01
- 2016-05-04 0001628280-16-015501 — 2.02, 9.01
- 2016-02-16 0001628280-16-011261 — 5.02, 9.01
- 2016-02-04 0001628280-16-010758 — 5.02, 9.01
- 2016-02-04 0001628280-16-010755 — 2.02, 9.01
- 2015-11-17 0001193125-15-378953 — 7.01
- 2015-11-10 0001628280-15-008606 — 2.02, 9.01
- 2015-09-28 0001193125-15-329665 — 8.01, 9.01
- 2015-08-11 0001193125-15-286405 — 7.01, 9.01
- 2015-08-06 0001193125-15-281219 — 1.01, 5.02, 5.03, 5.05, 8.01, 9.01
- 2015-08-03 0001193125-15-274808 — 5.03, 9.01

## late-filing notifications on or before 2019-05-07

- 2015-11-10 0001628280-15-008612 — NT 10-Q, for the period ended 2015-09-26
- 2015-09-28 0001193125-15-329672 — NT 10-K, for the period ended 2015-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001633978-19-000029:8k_2_02:1]
EX-99.1
2
lite_ex991xq3fy19.htm
EXHIBIT 99.1

[0001633978-19-000029:8k_2_02:2]
Exhibit

[0001633978-19-000029:8k_2_02:3]
NEWS RELEASE

[0001633978-19-000029:8k_2_02:4]
LUMENTUM ANNOUNCES FISCAL THIRD QUARTER 2019 RESULTS

[0001633978-19-000029:8k_2_02:5]
| • | Net revenue of $432.9 million |

[0001633978-19-000029:8k_2_02:6]
| • | GAAP operating margin (loss) of (17.6)%; Non-GAAP operating margin of 17.8% |

[0001633978-19-000029:8k_2_02:7]
| • | GAAP diluted net loss per share of $(0.98); Non-GAAP diluted net income per share of $0.91 |

[0001633978-19-000029:8k_2_02:8]
| • | Results include full quarter of Oclaro acquisition and GAAP results include the impact of restructuring, write-downs and other charges related to a shift in datacom strategy and actions to attain acquisition synergies |

[0001633978-19-000029:8k_2_02:9]
Milpitas, Calif., May 7, 2019 – Lumentum Holdings Inc. (“Lumentum” or the “Company”) today reported results for its fiscal third quarter ended March 30, 2019.

[0001633978-19-000029:8k_2_02:10]
Net revenue for the fiscal third quarter of 2019 was $432.9 million, with GAAP net loss attributable to common stockholders of $(74.3) million, or $(0.98) per diluted share. Net revenue for the fiscal second quarter of 2019 was $373.7 million, with GAAP net income attributable to common stockholders of $5.4 million, or $0.08 per diluted share. Net revenue for the fiscal third quarter of 2018 was $298.8 million, with GAAP net income attributable to common stockholders of $2.4 million, or $0.04 per diluted share.

[0001633978-19-000029:8k_2_02:11]
Non-GAAP net income for the fiscal third quarter of 2019 was $69.9 million, or $0.91 per diluted share. Non-GAAP net income for the fiscal second quarter of 2019 was $78.3 million, or $1.15 per diluted share. Non-GAAP net income for the fiscal third quarter of 2018 was $50.6 million, or $0.78 per diluted share.

[0001633978-19-000029:8k_2_02:12]
The Company held $697.5 million in total cash and short-term investments at the end of the fiscal third quarter of 2019.

[0001633978-19-000029:8k_2_02:13]
“The third quarter continued a theme that started more than a year ago for our ROADM and fiber laser product lines. For the fifth quarter in a row, we achieved double digit sequential, quarterly revenue growth and new record revenues for these product lines driven by strong customer demand for our new and differentiated products,” said Alan Lowe, President and CEO. “The third quarter was the first full quarter since completion of the acquisition of Oclaro.  We made solid progress on integrating the companies and attaining synergies, including the divestiture and planned exit of certain datacom product lines.  This continued progress results in our fourth quarter projected operating margins being sequentially higher on lower revenues after the divestiture and positions us well for achieving our long-term strategic goals.”

[0001633978-19-000029:8k_2_02:14]
Financial Overview – Fiscal Third Quarter Ended March 30, 2019

[0001633978-19-000029:8k_2_02:15]
|  | GAAP Results ($ in millions) |
|  | Q3 |  | Q2 |  | Q3 |  | Change |
|  | FY 2019 |  | FY 2019 |  | FY 2018 |  | Q/Q |  | Y/Y |
| Net revenue | $432.9 |  | $373.7 |  | $298.8 |  | 15.8% |  | 44.9% |
| Gross margin | 20.4% |  | 33.4% |  | 32.5% |  | (1300)bps |  | (1210)bps |
| Operating margin (loss) | (17.6)% |  | 3.1% |  | 8.5% |  | (2070)bps |  | (2610)bps |
|  | Non-GAAP Results ($ in millions) |
|  | Q3 |  | Q2 |  | Q3 |  | Change |
|  | FY 2019 |  | FY 2019 |  | FY 2018 |  | Q/Q |  | Y/Y |
| Net revenue | $432.9 |  | $373.7 |  | $298.8 |  | 15.8% |  | 44.9% |
| Gross margin | 39.0% |  | 40.1% |  | 36.3% |  | (110)bps |  | 270bps |
| Operating margin | 17.8% |  | 22.0% |  | 16.5% |  | (420)bps |  | ‘130bps |

[0001633978-19-000029:8k_2_02:16]
|  | Net Revenue by Segment ($ in millions) |
|  | Q3 |  | % of |  | Q2 |  | Q3 |  | Change |
|  | FY 2019 |  | Net Revenue |  | FY 2019 |  | FY 2018 |  | Q/Q |  | Y/Y |
| Optical Communications | $377.9 |  | 87.3% |  | $325.4 |  | $246.3 |  | 16.1% |  | 53.4% |
| Lasers | 55.0 |  | 12.7% |  | 48.3 |  | 52.5 |  | 13.9% |  | 4.8% |
| Total | $432.9 |  | 100.0% |  | $373.7 |  | $298.8 |  | 15.8% |  | 44.9% |

[0001633978-19-000029:8k_2_02:17]
The tables above provide comparisons of quarterly results to prior periods, including sequential quarterly and year-over-year changes. A reconciliation between GAAP and non-GAAP measures is contained in this release under the section titled “Use of Non-GAAP Financial Measures.”

[0001633978-19-000029:8k_2_02:18]
On July 1, 2018, we adopted Accounting Standards Update (ASU) 2014-09, Revenue from Contracts with Customers (Topic 606) using the modified retrospective method applied to all contracts that are not completed contracts at the date of initial adoption(i.e., July 1, 2018). Results for reporting periods after July 1, 2018 are presented under Topic 606, while prior period amounts are not adjusted and continue to be reported in accordance with our historic accounting under Topic 605. The adoption of Topic 606 did not have a material impact on the nature and timing of our revenues, consolidated statements of operations, cash flows, and balance sheet and therefore, we do not present results for the three and nine months ended March 30, 2019 under Topic 605.

[0001633978-19-000029:8k_2_02:19]
Business Outlook For Fiscal Fourth Quarter 2019

[0001633978-19-000029:8k_2_02:20]
During the fiscal third quarter and in the fiscal fourth quarter to date, Lumentum executed a series of strategic actions related to a shift in its datacom strategy to focus on photonic chip sales.  These strategic actions include completing the divestiture of certain datacom product lines to Cambridge Industries Group (CIG) on April 18, 2019.  A result of these strategic actions is lower on-going revenue from its datacom product lines.

[0001633978-19-000029:8k_2_02:21]
Lumentum expects the following for the fiscal fourth quarter 2019:

[0001633978-19-000029:8k_2_02:22]
•Net revenue in the range of $405 million to $425 million which includes a $20 million to $25 million reduction from recent datacom strategic actions

[0001633978-19-000029:8k_2_02:23]
•Non-GAAP operating margin of 18.0% to 20.0%

[0001633978-19-000029:8k_2_02:24]
•Non-GAAP diluted earnings per share of $0.85 to $1.00

[0001633978-19-000029:8k_2_02:25]
We have not provided reconciliations from GAAP to non-GAAP measures for our outlook. A large portion of non-GAAP adjustments, such as derivative liability adjustments, restructuring charges, stock-based compensation, acquisition-related costs, non-cash income tax expense and credits, transferring product lines to Thailand, amortization of fair value adjustments, impairment charges, inventory write down due to plans to exit certain product lines and other costs and contingencies unrelated to current and future operations are by their nature highly volatile and we have low visibility as to the range that may be incurred in the future. For example, in the fiscal second quarter of 2018, we had a credit of $207.0 million primarily related to a release of a U.S. valuation allowance, which was offset by a write-down of deferred tax assets in the amount of $83.0 million due to the lower corporate tax rate enacted under the 2017 “Tax Cuts and Jobs Act” reform.

[0001633978-19-000029:8k_2_02:26]
Conference Call

[0001633978-19-000029:8k_2_02:27]
Lumentum will host a conference call on May 7, 2019, at 5:30 am PT/8:30 am ET. A live webcast of the call and the replay will be available on the Lumentum website at http://investor.lumentum.com through May 14, 2019, at 11:59 pm ET. Supporting materials outlining the Company’s latest financial results will be posted on http://investor.lumentum.com under the “Events and Presentations” section concurrently with this earnings press release. This press release is being furnished as an exhibit to a Current Report on Form 8-K filed with the Securities and Exchange Commission and will be available at http://www.sec.gov/.

[0001633978-19-000029:8k_2_02:28]
About Lumentum

[0001633978-19-000029:8k_2_02:29]
Lumentum (NASDAQ: LITE) is a market-leading designer and manufacturer of innovative optical and photonic products enabling optical networking and laser applications worldwide.  Lumentum’s optical components and subsystems are part of virtually every type of telecom, enterprise, and data center network.  Lumentum’s lasers enable advanced manufacturing techniques and

[0001633978-19-000029:8k_2_02:30]
diverse applications including next-generation 3D sensing capabilities.  Lumentum is headquartered in Milpitas, California with R&D, manufacturing, and sales offices worldwide.  For more information, visit www.lumentum.com.

[0001633978-19-000029:8k_2_02:31]
Forward-Looking Statements

[0001633978-19-000029:8k_2_02:32]
Contact Information

[0001633978-19-000029:8k_2_02:33]
Investors:     Chris Coldren, 408-404-0606; investor.relations@lumentum.com

[0001633978-19-000029:8k_2_02:34]
Jim Fanucchi, 408-404-5400; investor.relations@lumentum.com

[0001633978-19-000029:8k_2_02:35]
Media:         Sean Ogarrio, 408-404-5400; media@lumentum.com

[0001633978-19-000029:8k_2_02:36]
The following financial tables are presented in accordance with GAAP, unless otherwise specified.

[0001633978-19-000029:8k_2_02:37]
LUMENTUM HOLDINGS INC.

[0001633978-19-000029:8k_2_02:38]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001633978-19-000029:8k_2_02:39]
(in millions, except per share data)

[0001633978-19-000029:8k_2_02:40]
(unaudited)

[0001633978-19-000029:8k_2_02:41]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 30, 2019 |  | March 31, 2018 |  | March 30, 2019 |  | March 31, 2018 |
| Net revenue | $ | 432.9 |  |  | $ | 298.8 |  |  | $ | 1,160.7 |  |  | $ | 946.6 |  |
| Cost of sales | 316.5 |  |  | 201.0 |  |  | 788.3 |  |  | 607.6 |  |
| Amortization of acquired intangibles | 28.1 |  |  | 0.8 |  |  | 33.3 |  |  | 2.4 |  |
| Gross profit | 88.3 |  |  | 97.0 |  |  | 339.1 |  |  | 336.6 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 57.7 |  |  | 38.2 |  |  | 135.1 |  |  | 118.3 |  |
| Selling, general and administrative | 55.2 |  |  | 33.2 |  |  | 150.9 |  |  | 95.5 |  |
| Restructuring and related charges | 21.1 |  |  | 0.1 |  |  | 30.2 |  |  | 3.8 |  |
| Impairment | 30.7 |  |  | — |  |  | 30.7 |  |  | — |  |
| Total operating expenses | 164.7 |  |  | 71.5 |  |  | 346.9 |  |  | 217.6 |  |
| Income/(loss) from operations | (76.4 | ) |  | 25.5 |  |  | (7.8 | ) |  | 119.0 |  |
| Unrealized gain (loss) on derivative liability | — |  |  | (20.7 | ) |  | 8.8 |  |  | (8.6 | ) |
| Interest and other income (expense), net | (6.1 | ) |  | (2.1 | ) |  | (13.2 | ) |  | (8.7 | ) |
| Income/(loss) before income taxes | (82.5 | ) |  | 2.7 |  |  | (12.2 | ) |  | 101.7 |  |
| Provision for (benefit from) income taxes | (8.2 | ) |  | — |  |  | (1.6 | ) |  | (112.9 | ) |
| Net income/(loss) | (74.3 | ) |  | 2.7 |  |  | (10.6 | ) |  | 214.6 |  |
| Items reconciling net income/(loss) to net income/(loss) attributable to common stockholders: |  |  |  |  |  |  |  |
| Less: Cumulative dividends on Series A Preferred Stock | — |  |  | (0.2 | ) |  | (0.3 | ) |  | (0.7 | ) |
| Less: Earnings allocated to Series A Preferred Stock | — |  |  | (0.1 | ) |  | (1.2 | ) |  | (4.9 | ) |
| Net income/(loss) attributable to common stockholders - Basic | $ | (74.3 | ) |  | $ | 2.4 |  |  | $ | (12.1 | ) |  | $ | 209.0 |  |
| Add: Earnings allocated to Series A Preferred Stock | — |  |  | — |  |  | — |  |  | — |  |
| Add/Less: Unrealized (gain) loss on derivative liability on Series A Preferred Stock | — |  |  | — |  |  | — |  |  | — |  |
| Add: Cumulative dividends on Series A Preferred Stock | — |  |  | — |  |  | — |  |  | — |  |
| Net income/(loss) attributable to common stockholders - Diluted (a) | $ | (74.3 | ) |  | $ | 2.4 |  |  | $ | (12.1 | ) |  | $ | 209.0 |  |
| Net income/(loss) per share attributable to common stockholders: |  |  |  |  |  |  |  |
| Basic | $ | (0.98 | ) |  | $ | 0.04 |  |  | $ | (0.18 | ) |  | $ | 3.37 |  |
| Diluted | $ | (0.98 | ) |  | $ | 0.04 |  |  | $ | (0.18 | ) |  | $ | 3.31 |  |
| Shares used to compute net income/(loss) per share attributable to common stockholders: |  |  |  |  |  |  |  |
| Basic | 76.2 |  |  | 62.4 |  |  | 68.7 |  |  | 62.1 |  |
| Diluted | 76.2 |  |  | 63.3 |  |  | 68.7 |  |  | 63.2 |  |

[0001633978-19-000029:8k_2_02:42]
(a)  For the three and nine months ended March 30, 2019, our diluted earnings per share attributable to common stockholders is the same as basic EPS. For the three and nine months ended March 31, 2018, our diluted earnings per share attributable to common stockholders is calculated using the treasury stock method because it is more dilutive than the if-converted method.

[0001633978-19-000029:8k_2_02:43]
LUMENTUM HOLDINGS INC.

[0001633978-19-000029:8k_2_02:44]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001633978-19-000029:8k_2_02:45]
(in millions, except share and per share data)

[0001633978-19-000029:8k_2_02:46]
(unaudited)

[0001633978-19-000029:8k_2_02:47]
|  | March 30, 2019 |  | June 30, 2018 |
| ASSETS |  |  |  |  |  |
| Current assets: |  |  |  |  |  |
| Cash and cash equivalents | $ | 357.3 |  |  | $ | 397.3 |  |
| Short-term investments | 340.2 |  |  | 314.2 |  |
| Accounts receivable, net | 302.9 |  |  | 197.1 |  |
| Inventories | 272.2 |  |  | 153.6 |  |
| Prepayments and other current assets | 107.0 |  |  | 65.0 |  |
| Assets held-for-sale | 38.5 |  |  | — |  |
| Total current assets | 1,418.1 |  |  | 1,127.2 |  |
| Property, plant and equipment, net | 390.6 |  |  | 306.9 |  |
| Goodwill | 359.8 |  |  | 11.3 |  |
| Other intangible assets, net | 412.3 |  |  | 7.0 |  |
| Deferred income taxes | 172.2 |  |  | 125.6 |  |
| Other non-current assets | 18.4 |  |  | 3.5 |  |
| Total assets | $ | 2,771.4 |  |  | $ | 1,581.5 |  |
| LIABILITIES, REDEEMABLE CONVERTIBLE PREFERRED STOCK AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 204.1 |  |  | $ | 126.5 |  |
| Accrued payroll and related expenses | 41.4 |  |  | 31.5 |  |
| Accrued expenses | 54.4 |  |  | 33.9 |  |
| Term loan, current | 5.0 |  |  | — |  |
| Other current liabilities | 46.7 |  |  | 22.1 |  |
| Liabilities held-for-sale | 6.4 |  |  | — |  |
| Total current liabilities | 358.0 |  |  | 214.0 |  |
| Convertible notes | 347.4 |  |  | 334.2 |  |
| Term loan, non-current | 484.9 |  |  | — |  |
| Derivative liability | — |  |  | 52.4 |  |
| Deferred tax liability | 55.8 |  |  | 0.3 |  |
| Other non-current liabilities | 21.4 |  |  | 18.7 |  |
| Total liabilities | 1,267.5 |  |  | 619.6 |  |
| Redeemable convertible preferred stock: |  |  |  |
| Non-controlling interest redeemable convertible Series A Preferred Stock, $0.001 par value, 10,000,000 authorized shares; zero and 35,805 shares issued and outstanding as of March 30, 2019 and June 30, 2018, respectively | — |  |  | 35.8 |  |
| Total redeemable convertible preferred stock | — |  |  | 35.8 |  |
| Stockholders’ equity: |  |  |  |
| Common stock, $0.001 par value, 990,000,000 authorized shares, 76,349,298 and 62,790,087 shares issued and outstanding as of March 30, 2019 and June 30, 2018, respectively | 0.1 |  |  | 0.1 |  |
| Additional paid-in capital | 1,341.4 |  |  | 753.2 |  |
| Retained earnings | 154.9 |  |  | 166.4 |  |
| Accumulated other comprehensive income | 7.5 |  |  | 6.4 |  |
| Total stockholders’ equity | 1,503.9 |  |  | 926.1 |  |
| Total liabilities, redeemable convertible preferred stock, and stockholders’ equity | $ | 2,771.4 |  |  | $ | 1,581.5 |  |

[0001633978-19-000029:8k_2_02:48]
Use of Non-GAAP Financial Measures

[0001633978-19-000029:8k_2_02:49]
In this press release, Lumentum provides investors with gross margin, gross profit, operating margin, operating income, income (loss) before income taxes and certain expenses, net income, and net income (loss) per share on a non-GAAP basis. Lumentum believes this non-GAAP financial information provides additional insight into the Company’s on-going cash generation and has therefore chosen to provide this information to investors for a more consistent basis of comparison and to help them evaluate the results of the Company’s on-going operations and enable more meaningful period to period comparisons. Specifically, the Company believes that providing this information allows investors to better understand the Company’s cash flows and, importantly, to evaluate the efficacy of the methodology and information used by management to evaluate and measure such cash flows. However, these measures may be different from non-GAAP measures used by other companies, limiting their usefulness for comparison purposes. The non-GAAP financial measures used in this press release should not be considered in isolation from measures of financial performance prepared in accordance with GAAP. Investors are cautioned that there are material limitations associated with the use of non-GAAP financial measures as an analytical tool. In particular, many of the adjustments to our GAAP financial measures reflect the exclusion of items that are recurring and will be reflected in our financial results for the foreseeable future. Further, these non-GAAP financial measures may not be comparable to similarly titled measurements reported by other companies.

[0001633978-19-000029:8k_2_02:50]
Non-GAAP gross margin, non-GAAP gross profit, non-GAAP expenses, non-GAAP operating margin, non-GAAP operating income, non-GAAP income (loss) before income taxes, non-GAAP net income, and non-GAAP net income per share exclude (i) stock-based compensation, (ii) acquisition related costs, (iii) inventory write-downs due to cancelled programs, plans to exit certain lines of business and other costs and contingencies unrelated to current and future operations, (iv) amortization of acquired intangibles, (v) restructuring and related charges, (vi) amortization of fair value adjustments, (vii) non-cash interest expense, (viii) unrealized gain (loss) on derivative liability, (ix) transferring product lines to Thailand, (x) impairment charges and (xi) non-cash income tax provision impacts, for example, a release of a U.S. valuation allowance, and the write down of deferred tax assets due to the 2017 Tax Cuts and Jobs Act. The presentation of these and other similar items in Lumentum’s non-GAAP financial results should not be interpreted as implying that these items are non-recurring, infrequent or unusual.

[0001633978-19-000029:8k_2_02:51]
A quantitative reconciliation between GAAP and non-GAAP financial data with respect to historical periods is included in the supplemental financial table attached to this press release.

[0001633978-19-000029:8k_2_02:52]
LUMENTUM HOLDINGS INC.

[0001633978-19-000029:8k_2_02:53]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001633978-19-000029:8k_2_02:54]
(in millions, except per share data)

[0001633978-19-000029:8k_2_02:55]
(unaudited)

[0001633978-19-000029:8k_2_02:56]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 30, 2019 |  | March 31, 2018 |  | March 30, 2019 |  | March 31, 2018 |
| Gross profit on GAAP basis | $ | 88.3 |  |  | $ | 97.0 |  |  | $ | 339.1 |  |  | $ | 336.6 |  |
| Stock-based compensation (3) | 3.2 |  |  | 2.4 |  |  | 11.7 |  |  | 9.5 |  |
| Inventory write down due to product line exit (7) | 19.4 |  |  | — |  |  | 19.4 |  |  | 7.0 |  |
| Integration related costs | 2.8 |  |  | — |  |  | 2.8 |  |  | — |  |
| Amortization of acquired intangibles | 28.1 |  |  | 0.8 |  |  | 33.3 |  |  | 2.4 |  |
| Amortization of fair value adjustments (4) | 14.5 |  |  | — |  |  | 15.8 |  |  | — |  |
| Other charges (1) | 12.5 |  |  | 8.3 |  |  | 39.0 |  |  | 17.5 |  |
| Gross profit on non-GAAP basis | $ | 168.8 |  |  | $ | 108.5 |  |  | $ | 461.1 |  |  | $ | 373.0 |  |
| Research and development on GAAP basis | $ | 57.7 |  |  | $ | 38.2 |  |  | $ | 135.1 |  |  | $ | 118.3 |  |
| Stock-based compensation (3) | (4.5 | ) |  | (3.6 | ) |  | (10.7 | ) |  | (10.5 | ) |
| Other charges | (0.4 | ) |  | 0.4 |  |  | (0.7 | ) |  | (1.4 | ) |
| Research and development on non-GAAP basis | $ | 52.8 |  |  | $ | 35.0 |  |  | $ | 123.7 |  |  | $ | 106.4 |  |
| Selling, general and administrative on GAAP basis | $ | 55.2 |  |  | $ | 33.2 |  |  | $ | 150.9 |  |  | $ | 95.5 |  |
| Stock-based compensation (3) | (8.3 | ) |  | (5.0 | ) |  | (34.1 | ) |  | (15.1 | ) |
| Acquisition related costs | (2.2 | ) |  | (2.7 | ) |  | (15.3 | ) |  | (2.7 | ) |
| Integration related costs | (1.3 | ) |  | — |  |  | (1.3 | ) |  | — |  |
| Amortization of acquired intangibles | (3.6 | ) |  | — |  |  | (4.4 | ) |  | — |  |
| Other charges | (0.8 | ) |  | (1.4 | ) |  | (2.3 | ) |  | (3.7 | ) |
| Selling, general and administrative on non-GAAP basis | $ | 39.0 |  |  | $ | 24.1 |  |  | $ | 93.5 |  |  | $ | 74.0 |  |
| Income/(loss) from operations on GAAP basis | $ | (76.4 | ) |  | $ | 25.5 |  |  | $ | (7.8 | ) |  | $ | 119.0 |  |
| Stock-based compensation (3) | 16.0 |  |  | 11.0 |  |  | 56.5 |  |  | 35.1 |  |
| Acquisition related costs | 2.2 |  |  | 2.7 |  |  | 15.3 |  |  | 2.7 |  |
| Integration related costs | 4.1 |  |  | — |  |  | 4.1 |  |  | — |  |
| Inventory write down due to product line exit (7) | 19.4 |  |  | — |  |  | 19.4 |  |  | 7.0 |  |
| Amortization of acquired intangibles | 31.7 |  |  | 0.8 |  |  | 37.7 |  |  | 2.4 |  |
| Amortization of fair value adjustments (4) | 14.5 |  |  | — |  |  | 15.8 |  |  | — |  |
| Restructuring and related charges (2) | 21.1 |  |  | 0.1 |  |  | 30.2 |  |  | 3.8 |  |
| Impairment charge (6) | 30.7 |  |  | — |  |  | 30.7 |  |  | — |  |
| Other charges (1) | 13.7 |  |  | 9.3 |  |  | 42.0 |  |  | 22.6 |  |
| Income from operations on non-GAAP basis | $ | 77.0 |  |  | $ | 49.4 |  |  | $ | 243.9 |  |  | $ | 192.6 |  |
| Interest and other (expense) income, net on GAAP basis | $ | (6.1 | ) |  | $ | (2.1 | ) |  | $ | (13.2 | ) |  | $ | (8.7 | ) |
| Other interest and (income) expense adjustments (5) | (2.5 | ) |  | (0.1 | ) |  | (0.5 | ) |  | (0.1 | ) |
| Non-cash interest expense on convertible notes and term loan | 4.8 |  |  | 4.2 |  |  | 13.6 |  |  | 12.4 |  |
| Interest and other (expense) income, net on non-GAAP basis | $ | (3.8 | ) |  | $ | 2.0 |  |  | $ | (0.1 | ) |  | $ | 3.6 |  |

[0001633978-19-000029:8k_2_02:57]
| Income/(loss) before income taxes on GAAP basis | $ | (82.5 | ) |  | $ | 2.7 |  |  | $ | (12.2 | ) |  | $ | 101.7 |  |
| Stock-based compensation (3) | 16.0 |  |  | 11.0 |  |  | 56.5 |  |  | 35.1 |  |
| Acquisition related costs | 2.2 |  |  | 2.7 |  |  | 15.3 |  |  | 2.7 |  |
| Integration related costs | 4.1 |  |  | — |  |  | 4.1 |  |  | — |  |
| Inventory write down due to product line exit (7) | 19.4 |  |  | — |  |  | 19.4 |  |  | 7.0 |  |
| Amortization of acquired intangibles | 31.7 |  |  | 0.8 |  |  | 37.7 |  |  | 2.4 |  |
| Amortization of fair value adjustments (4) | 14.5 |  |  | — |  |  | 15.8 |  |  | — |  |
| Restructuring and related charges (2) | 21.1 |  |  | 0.1 |  |  | 30.2 |  |  | 3.8 |  |
| Impairment charge (6) | 30.7 |  |  | — |  |  | 30.7 |  |  | — |  |
| Other interest and (income) expense adjustments (5) | (2.5 | ) |  | (0.1 | ) |  | (0.5 | ) |  | (0.1 | ) |
| Non-cash interest expense on convertible notes and term loan | 4.8 |  |  | 4.2 |  |  | 13.6 |  |  | 12.4 |  |
| Unrealized (gain) loss on derivative liability | — |  |  | 20.7 |  |  | (8.8 | ) |  | 8.6 |  |
| Other charges (1) | 13.7 |  |  | 9.3 |  |  | 42.0 |  |  | 22.6 |  |
| Income before income taxes on non-GAAP basis | $ | 73.2 |  |  | $ | 51.4 |  |  | $ | 243.8 |  |  | $ | 196.2 |  |
| Provision for (benefit from) income taxes on GAAP basis | $ | (8.2 | ) |  | $ | — |  |  | $ | (1.6 | ) |  | $ | (112.9 | ) |
| Income tax adjustments | 11.5 |  |  | 0.8 |  |  | 11.4 |  |  | 122.9 |  |
| Provision for (benefit from) income taxes on non-GAAP basis | $ | 3.3 |  |  | $ | 0.8 |  |  | $ | 9.8 |  |  | $ | 10.0 |  |
| Net income/(loss) on GAAP basis | $ | (74.3 | ) |  | $ | 2.7 |  |  | $ | (10.6 | ) |  | $ | 214.6 |  |
| Stock-based compensation (3) | 16.0 |  |  | 11.0 |  |  | 56.5 |  |  | 35.1 |  |
| Acquisition related costs | 2.2 |  |  | 2.7 |  |  | 15.3 |  |  | 2.7 |  |
| Integration related costs | 4.1 |  |  | — |  |  | 4.1 |  |  | — |  |
| Inventory write down due to product line exit (7) | 19.4 |  |  | — |  |  | 19.4 |  |  | 7.0 |  |
| Amortization of acquired intangibles | 31.7 |  |  | 0.8 |  |  | 37.7 |  |  | 2.4 |  |
| Amortization of fair value adjustments (4) | 14.5 |  |  | — |  |  | 15.8 |  |  | — |  |
| Restructuring and related charges (2) | 21.1 |  |  | 0.1 |  |  | 30.2 |  |  | 3.8 |  |
| Other interest and (income) expense adjustments (5) | (2.5 | ) |  | (0.1 | ) |  | (0.5 | ) |  | (0.1 | ) |
| Non-cash interest expense on convertible notes and term loan | 4.8 |  |  | 4.2 |  |  | 13.6 |  |  | 12.4 |  |
| Unrealized (gain) loss on derivative liability | — |  |  | 20.7 |  |  | (8.8 | ) |  | 8.6 |  |
| Impairment charge (6) | 30.7 |  |  | — |  |  | 30.7 |  |  | — |  |
| Income tax adjustments | (11.5 | ) |  | (0.8 | ) |  | (11.4 | ) |  | (122.9 | ) |
| Other charges (1) | 13.7 |  |  | 9.3 |  |  | 42.0 |  |  | 22.6 |  |
| Net income on non-GAAP basis | $ | 69.9 |  |  | $ | 50.6 |  |  | $ | 234.0 |  |  | $ | 186.2 |  |
| Net income per share on non-GAAP basis | $ | 0.91 |  |  | $ | 0.78 |  |  | $ | 3.34 |  |  | $ | 2.88 |  |
| Shares used in per share calculation - diluted on GAAP basis | 76.2 |  |  | 63.3 |  |  | 68.7 |  |  | 63.2 |  |
| Non-GAAP adjustment (8) | 0.5 |  |  | — |  |  | 0.6 |  |  | — |  |
| Effect of diluted securities from Series A Preferred Stock (9) | — |  |  | 1.5 |  |  | 0.7 |  |  | 1.5 |  |
| Shares used in per share calculation - diluted on non-GAAP basis | 76.7 |  |  | 64.8 |  |  | 70.0 |  |  | 64.7 |  |

[0001633978-19-000029:8k_2_02:58]
(1) Other charges for the three and nine months ended March 30, 2019, primarily include costs of transferring product lines to Thailand of $12.6 million and $40.8 million, respectively. Other charges for the three and nine months ended March 31, 2018, primarily includes set-up costs for our facility in Thailand of $9.5 million and $17.6 million respectively as well as inventory write-downs due to canceled programs and business sanctions.

[0001633978-19-000029:8k_2_02:59]
(2) During the three and nine months ended March 30, 2019 we recorded restructuring and related charges of $21.1 million, primarily in connection with the decision to exit Lithium Niobate and Datacom module product lines. During the nine months ended March 30, 2019 we also recorded restructuring and related charges of $5.7 million primarily attributable to severance and employee related benefits associated with Oclaro’s executive severance and retention agreements

[0001633978-19-000029:8k_2_02:60]
(3) During the nine months ended March 30, 2019 we recorded stock-based compensation of $15.2 million primarily attributable to severance and employee related benefits associated with Oclaro’s executive severance and retention agreements.

[0001633978-19-000029:8k_2_02:61]
(4) In connection with the acquisition of Oclaro, we recorded a fair value adjustment of $60.3 million to inventory, resulting in $14.5 million and $15.8 million of amortization expense of the fair value adjustment during the three and nine months ended March 30, 2019, respectively.

[0001633978-19-000029:8k_2_02:62]
(5) For the three and nine months ended March 30, 2019, interest and other (expense) income includes a one-time benefit of $2.5 million related to a non-trade reimbursement.

[0001633978-19-000029:8k_2_02:63]
(6) For each of  the three and nine months ended March 30, 2019, we recorded an impairment charge of $30.7 million of Property Plant and Equipment, related to the decision to exit the Datacom module product line.

[0001633978-19-000029:8k_2_02:64]
(7) For each of the three and nine months ended March 30, 2019, we recorded an inventory write down charge of $19.4 million, related to the decision to exit the Datacom module product line.

[0001633978-19-000029:8k_2_02:65]
(8) This adjustment represents weighted-average potentially dilutive securities from our stock-based benefit plans excluded from the computation of diluted net loss per share attributable to common stockholders on a GAAP basis because the effect would have been anti-dilutive. This adjustment amount is added for the computation of diluted net income per share on a non-GAAP basis as we had a net income on a non-GAAP basis.

[0001633978-19-000029:8k_2_02:66]
(9) For the three and nine months ended March  31, 2018, 1.5 million shares related to the potential conversion of the Series A Preferred Stock were added to the calculation of diluted shares available on a non-GAAP basis because their inclusion results in more dilutive earnings per share.

[0001633978-19-000029:8k_2_02:67]
LUMENTUM HOLDINGS INC.

[0001633978-19-000029:8k_2_02:68]
RECONCILIATION OF GAAP NET INCOME (LOSS) TO EBITDA

[0001633978-19-000029:8k_2_02:69]
(in millions, except per share data)

[0001633978-19-000029:8k_2_02:70]
(unaudited)

[0001633978-19-000029:8k_2_02:71]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 30, 2019 |  | March 31, 2018 |  | March 30, 2019 |  | March 31, 2018 |
| GAAP Net income/(loss) | $ | (74.3 | ) |  | $ | 2.7 |  |  | $ | (10.6 | ) |  | $ | 214.6 |  |
| Interest and other expense (income), net | 6.1 |  |  | 2.1 |  |  | 13.2 |  |  | 8.7 |  |
| Provision for (benefit from) income taxes | (8.2 | ) |  | — |  |  | (1.6 | ) |  | (112.9 | ) |
| Depreciation | 29.0 |  |  | 18.4 |  |  | 74.7 |  |  | 53.3 |  |
| Amortization of acquired intangibles | 31.7 |  |  | 0.8 |  |  | 37.7 |  |  | 2.4 |  |
| EBITDA | (15.7 | ) |  | 24.0 |  |  | 113.4 |  |  | 166.1 |  |
| Amortization of fair value adjustments | 14.5 |  |  | — |  |  | 15.8 |  |  | — |  |
| Restructuring and related charges | 21.1 |  |  | 0.1 |  |  | 30.2 |  |  | 3.8 |  |
| Stock-based compensation | 16.0 |  |  | 11.0 |  |  | 56.5 |  |  | 35.1 |  |
| Acquisition related costs | 2.2 |  |  | 2.7 |  |  | 15.3 |  |  | 2.7 |  |
| Other charges | 13.7 |  |  | 9.3 |  |  | 42.0 |  |  | 29.6 |  |
| Unrealized gain/(loss) on derivative liabilities | — |  |  | 20.7 |  |  | (8.8 | ) |  | 8.6 |  |
| Inventory write down due to product line exit | 19.4 |  |  | — |  |  | 19.4 |  |  | — |  |
| Integration related costs | 4.1 |  |  | — |  |  | 4.1 |  |  | — |  |
| Impairment charges | 30.7 |  |  | — |  |  | 30.7 |  |  | — |  |
| Adjusted EBITDA | $ | 106.0 |  |  | $ | 67.8 |  |  | $ | 318.6 |  |  | $ | 245.9 |  |
