# LITE note change history — 0001633978-19-000002 → 0001633978-19-000030


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2019-05-07):
[0001633978-19-000030:note_history:1]
We lease certain real and personal property from unrelated third parties under non-cancellable operating leases that expire at various dates through fiscal 2033. Certain leases require us to pay property taxes, insurance and routine maintenance, and include escalation clauses. As a result of our acquisition of Oclaro on December 10, 2018, we assumed operating leases with future minimum annual lease payments of $83.2 million as of March 30, 2019.
  (was, 2019-02-07, similarity 0.9799):
[0001633978-19-000002:note_history:1]
We lease certain real and personal property from unrelated third parties under non-cancellable operating leases that expire at various dates through fiscal 2033. Certain leases require us to pay property taxes, insurance and routine maintenance, and include escalation clauses. As a result of our acquisition of Oclaro on December 10, 2018, we assumed operating leases with future minimum annual lease payments of $81.9 million.

- changed (2019-05-07):
[0001633978-19-000030:note_history:2]
As of March 30, 2019, the total future minimum annual lease payments under non-cancellable operating leases were as follows (in millions):
  (was, 2019-02-07, similarity 0.9663):
[0001633978-19-000002:note_history:2]
As of December 29, 2018, the total future minimum annual lease payments under non-cancellable operating leases were as follows (in millions):

- changed (2019-05-07):
[0001633978-19-000030:note_history:3]
During the three and nine months ended March 30, 2019, rental expense relating to building and equipment was $5.2 million and $11.2 million, respectively. During the three and nine months ended March 31, 2018, rental expense relating to building and equipment was $2.8 million and $9.2 million, respectively.
  (was, 2019-02-07, similarity 0.8339):
[0001633978-19-000002:note_history:3]
During the three and six months ended December 29, 2018, rental expense relating to building and equipment was $3.2 million and $6.0 million, respectively. During the three and six months ended December 30, 2017, rental expense relating to building and equipment was $3.0 million and $6.4 million, respectively.

- changed (2019-05-07):
[0001633978-19-000030:note_history:4]
As of March 30, 2019, equipment acquired under capital lease agreements, including those assumed as part of the Oclaro acquisition, was $16.4 million. Our capital lease assets are included in property, plant and equipment, net in our condensed consolidated balance sheets as of March 30, 2019. Amortization expense on these capital lease assets are recorded as depreciation expense and is included in cost of sales in our condensed consolidated statements of operations for the three and nine months ended March 30, 2019 and March 31, 2018. Our capital lease obligations are recorded at the lesser of the estimated fair market value of the leased property or the net present value of the aggregate future minimum lease payments and is included in other current liabilities and other non-current liabilities in our condensed consolidated balance sheets as of March 30, 2019. Refer to “Note 9. Balance Sheet Details” for capital lease obligation amounts in other current liabilities and other non-current liabilities. Interest on these obligations is included in interest expense in our condensed consolidated statements of operations.
  (was, 2019-02-07, similarity 0.9548):
[0001633978-19-000002:note_history:4]
As of December 29, 2018, equipment acquired under capital lease agreements, including those assumed as part of the Oclaro acquisition, was $17.5 million. Our capital lease assets are included in property, plant and equipment, net in our condensed consolidated balance sheets as of December 29, 2018. Amortization expense on these capital lease assets are recorded as depreciation expense and is included in cost of sales in our condensed consolidated statements of operations for the three and six months ended December 29, 2018 and December 30, 2017. Our capital lease obligations are recorded at the lesser of the estimated fair market value of the leased property or the net present value of the aggregate future minimum lease payments and is included in other current liabilities and other non-current liabilities in our condensed consolidated balance sheets as of December 29, 2018. Refer to “Note 8. Balance Sheet Details” for capital lease obligation amounts in other current liabilities and other non-current liabilities. Interest on these obligations is included in interest expense in our condensed consolidated statements of operations.

- changed (2019-05-07):
[0001633978-19-000030:note_history:5]
As of March 30, 2019 the future minimum annual lease payments under our capital leases were as follows (in millions):
  (was, 2019-02-07, similarity 0.9604):
[0001633978-19-000002:note_history:5]
As of December 29, 2018 the future minimum annual lease payments under our capital leases were as follows (in millions):

- changed (2019-05-07):
[0001633978-19-000030:note_history:6]
In February 2017, we incurred liabilities in the amount of $3.6 million related to an acquisition of a privately held company. The amount of up to $3.0 million is expected to be paid within the following 12 months contingent upon meeting certain production targets, and is included in other current liabilities on our consolidated balance sheet as of March 30, 2019.
  (was, 2019-02-07, similarity 0.9702):
[0001633978-19-000002:note_history:6]
In February 2017, we incurred liabilities in the amount of $3.6 million related to an acquisition of a privately held company. The amount of up to $3.0 million is expected to be paid within the following 12 months contingent upon meeting certain production targets, and is included in other current liabilities on our consolidated balance sheet as of December 29, 2018.

- changed (2019-05-07):
[0001633978-19-000030:note_history:7]
We also retained $1.0 million of the purchase price as security for any potential liabilities of the seller under the representations, warranties and indemnifications included in the purchase agreement. The $1.0 million was fully paid to the seller during the nine months ended March 30, 2019.
  (was, 2019-02-07, similarity 0.9014):
[0001633978-19-000002:note_history:7]
We also retained $1.0 million of the purchase price as security for any potential liabilities of the seller under the representations, warranties and indemnifications included in the purchase agreement. The $1.0 million was fully paid to the seller during the six months ended December 29, 2018.

- changed (2019-05-07):
[0001633978-19-000030:note_history:8]
The estimated future interest and principal payments related to the term loan are as follows as of March 30, 2019:
  (was, 2019-02-07, similarity 0.9593):
[0001633978-19-000002:note_history:8]
The estimated future interest and principal payments related to the term loan are as follows as of December 29, 2018:

- changed (2019-05-07):
[0001633978-19-000030:note_history:9]
0.25% Convertible Notes due 2024
  (was, 2019-02-07, similarity 0.8814):
[0001633978-19-000002:note_history:9]
0.25% Convertible Senior Notes due 2024

- changed (2019-05-07):
[0001633978-19-000030:note_history:10]
The future interest and principal payments related to the 2024 Notes are as follows as of March 30, 2019:
  (was, 2019-02-07, similarity 0.9543):
[0001633978-19-000002:note_history:10]
The future interest and principal payments related to the 2024 Notes are as follows as of December 29, 2018:

- changed (2019-05-07):
[0001633978-19-000030:note_history:11]
| Fiscal Years |  |
| Remainder of 2019 | $ | — |  |
| 2020 | 1.1 |  |
| 2021 | 1.1 |  |
| 2022 | 1.1 |  |
| 2023 | 1.1 |  |
| Thereafter | 451.2 |  |
| Total 2024 Notes payments | $ | 455.6 |  |
  (was, 2019-02-07, similarity 0.9935):
[0001633978-19-000002:note_history:11]
| Fiscal Years |  |
| Remainder of 2019 | $ | 0.6 |  |
| 2020 | 1.1 |  |
| 2021 | 1.1 |  |
| 2022 | 1.1 |  |
| 2023 | 1.1 |  |
| Thereafter | 451.2 |  |
| Total 2024 Notes payments | $ | 456.2 |  |

- changed (2019-05-07):
[0001633978-19-000030:note_history:12]
Purchase obligations of $208.0 million as of March 30, 2019, represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements.
  (was, 2019-02-07, similarity 0.7107):
[0001633978-19-000002:note_history:12]
Purchase obligations of $281.8 million as of December 29, 2018, represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Included in the $281.8 million are approximately $85.9 million in purchase commitments assumed in connection with our acquisition of Oclaro on December 10, 2018.

- changed (2019-05-07):
[0001633978-19-000030:note_history:13]
The following table presents the changes in our warranty reserve during the three and nine months ended March 30, 2019 and March 31, 2018 (in millions):
  (was, 2019-02-07, similarity 0.9204):
[0001633978-19-000002:note_history:13]
The following table presents the changes in our warranty reserve during the three and six months ended December 29, 2018 and December 30, 2017 (in millions):

- changed (2019-05-07):
[0001633978-19-000030:note_history:14]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 30, 2019 |  | March 31, 2018 |  | March 30, 2019 |  | March 31, 2018 |
| Balance as of beginning of period | $ | 9.7 |  |  | $ | 9.9 |  |  | $ | 6.6 |  |  | $ | 9.7 |  |
| Warranties assumed in Oclaro acquisition | — |  |  | — |  |  | 3.8 |  |  | — |  |
| Provision for warranty | 1.5 |  |  | 2.0 |  |  | 3.4 |  |  | 4.9 |  |
| Utilization of reserve | (1.4 | ) |  | (4.9 | ) |  | (4.0 | ) |  | (7.6 | ) |
| Balance as of end of period | $ | 9.8 |  |  | $ | 7.0 |  |  | $ | 9.8 |  |  | $ | 7.0 |  |
  (was, 2019-02-07, similarity 0.8466):
[0001633978-19-000002:note_history:14]
|  | Three Months Ended |  | Six Months Ended |
|  | December 29, 2018 |  | December 30, 2017 |  | December 29, 2018 |  | December 30, 2017 |
| Balance as of beginning of period | $ | 6.6 |  |  | $ | 9.4 |  |  | $ | 6.6 |  |  | $ | 9.7 |  |
| Warranties assumed in Oclaro acquisition | 3.8 |  |  | — |  |  | 3.8 |  |  | — |  |
| Provision for warranty | 0.7 |  |  | 1.9 |  |  | 1.9 |  |  | 2.9 |  |
| Utilization of reserve | (1.4 | ) |  | (1.4 | ) |  | (2.6 | ) |  | (2.7 | ) |
| Balance as of end of period | $ | 9.7 |  |  | $ | 9.9 |  |  | $ | 9.7 |  |  | $ | 9.9 |  |

- changed (2019-05-07):
[0001633978-19-000030:note_history:15]
We are subject to a variety of claims and suits that arise from time to time in the ordinary course of our business. While management currently believes that resolving claims against us, individually or in the aggregate, will not have a material adverse impact on our financial position, results of operations or statements of cash flows, these matters are subject to inherent uncertainties and management’s view of these matters may change in the future. We accrue for loss contingencies when it is both probable that we will incur the loss and when we can reasonably estimate the amount of the loss or range of loss. As of March 30, 2019, we did not have any material claims or proceedings that were probable or reasonably possible.
  (was, 2019-02-07, similarity 0.9183):
[0001633978-19-000002:note_history:15]
We are subject to a variety of claims and suits that arise from time to time in the ordinary course of our business. While management currently believes that resolving claims against us, individually or in the aggregate, will not have a material adverse impact on our financial position, results of operations or statements of cash flows, these matters are subject to inherent uncertainties and management’s view of these matters may change in the future. We accrue for loss contingencies when it is both probable that we will incur the loss and when we can reasonably estimate the amount of the loss or range of loss.

- changed (2019-05-07):
[0001633978-19-000030:note_history:16]
In the normal course of business, we enter into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown because claims may be made against us in the future and we may record charges in the future as a result of these indemnification obligations. As of March 30, 2019, we did not have any material indemnification claims that were probable or reasonably possible.
  (was, 2019-02-07, similarity 0.9857):
[0001633978-19-000002:note_history:16]
In the normal course of business, we enter into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown because claims may be made against us in the future and we may record charges in the future as a result of these indemnification obligations. As of December 29, 2018, we did not have any material indemnification claims that were probable or reasonably possible.

- added (2019-05-07):
[0001633978-19-000030:note_history:17]
In connection with our acquisition of Oclaro, we recorded $1.1 million in Malaysia Goods and Services Tax (“GST”) refund claims within prepaid expenses and other current assets in our condensed consolidated balance sheet at March 30, 2019. The refund claim represents an initial claim of $2.5 million of GST, net of reserves, that were previously denied by the Malaysian tax authorities in 2016. We are currently appealing the denial of these claims, and believe that additional options may be available to us if we do not obtain a favorable resolution. Although we have taken action to minimize the impact of the GST with respect to our ongoing operations, we believe it is reasonably possible that, ultimately, we may not be able to recover some of these GST amounts.

- removed (2019-05-07):
[0001633978-19-000002:note_history:18]
In connection with our acquisition of Oclaro, we assumed capital leases related to plant and machinery. This capital lease extends through October 2020, after which time the ownership of the equipment transfers from the lessor to us. During the lease term, we are required to make equal installments of principal and interest, payable quarterly. Interest on this capital lease accrues at 1.15 percent per annum.

- removed (2019-05-07):
[0001633978-19-000002:note_history:19]
In connection with the Separation, we agreed to indemnify Viavi for any liability associated with contamination from past operations at all properties transferred to us from Viavi, to the extent the resulting issues primarily related to our business.

- removed (2019-05-07):
[0001633978-19-000002:note_history:20]
In connection with our acquisition of Oclaro, we recorded $0.7 million in Malaysia Goods and Services Tax (“GST”) refund claims within prepaid expenses and other current assets in our condensed consolidated balance sheet at December 29, 2018. The refund claim represents an initial claim of $2.5 million of Malaysia GST refund claims that were preliminarily denied by the Malaysian tax authorities in 2016. We are currently appealing the denial of these claims, and believe that additional options may be available to us if we do not obtain a favorable resolution. Although we have taken action to minimize the impact of the GST with respect to our ongoing operations, we believe it is reasonably possible that, ultimately, we may not be able to recover some of these GST amounts.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2019-05-07):
[0001633978-19-000030:note_history:21]
On December 10, 2018, the Company completed its merger with Oclaro, Inc. (“Oclaro”), a provider of optical components and modules for the long-haul, metro and data center markets. Our condensed consolidated financial statements include the operating results of Oclaro for the period from the date of acquisition through March 30, 2019. Refer to “Note 5. Business Combination” for further discussion of the merger.
  (was, 2019-02-07, similarity 0.9838):
[0001633978-19-000002:note_history:21]
On December 10, 2018, the Company completed its merger with Oclaro, Inc. (“Oclaro”), a provider of optical components and modules for the long-haul, metro and data center markets. Our condensed consolidated financial statements include the operating results of Oclaro for the period from the date of acquisition through December 29, 2018. Refer to “Note 5. Business Combination” for further discussion of the merger.

- changed (2019-05-07):
[0001633978-19-000030:note_history:22]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Our fiscal 2019 is a 52-week year ending on June 29, 2019, with the quarter ended March 30, 2019 being a 13-week quarterly period. Our fiscal 2018 was a 52-week year that ended on June 30, 2018, with the quarter ended March 31, 2018 being a 13-week quarterly period.
  (was, 2019-02-07, similarity 0.9333):
[0001633978-19-000002:note_history:22]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Our fiscal 2019 is a 52-week year ending on June 29, 2019, with the quarter ended December 29, 2018 being a 13-week quarterly period. Our fiscal 2018 was a 52-week year that ended on June 30, 2018, with the quarter ended December 30, 2017 being a 13-week quarterly period.

- added (2019-05-07):
[0001633978-19-000030:note_history:23]
Certain  prior  period  amounts  have  been  reclassified  to  conform  to  the  current  year  presentation  in  the  notes  to  the  condensed  consolidated  financial statements.  The  reclassification  of  the  prior  period  amounts  did  not  impact  previously  reported  condensed  consolidated  financial  statements.

- changed (2019-05-07):
[0001633978-19-000030:note_history:24]
Except for the accounting policies for (i) revenue recognition and the adoption of Accounting Standards Update (“ASU”) 2014-09, Revenue from Contracts with Customers (Topic 606), and (ii) the change in our functional currency, from certain foreign currencies to the reporting currency, there have been no significant changes to our significant accounting policies as of and for the nine months ended March 30, 2019, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the year ended June 30, 2018.
  (was, 2019-02-07, similarity 0.9543):
[0001633978-19-000002:note_history:24]
Except for the accounting policies for (i) revenue recognition and the adoption of Accounting Standards Update (“ASU”) 2014-09, Revenue from Contracts with Customers (Topic 606), and (ii) the change in our functional currency, from certain foreign currencies to the reporting currency, there have been no significant changes to our significant accounting policies as of and for the six months ended December 29, 2018, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the year ended June 30, 2018.

- changed (2019-05-07):
[0001633978-19-000030:note_history:25]
The following table includes estimated revenue expected to be recognized in the future for backlog related performance obligations that are unsatisfied as of March 30, 2019 (in millions):
  (was, 2019-02-07, similarity 0.9755):
[0001633978-19-000002:note_history:25]
The following table includes estimated revenue expected to be recognized in the future for backlog related performance obligations that are unsatisfied as of December 29, 2018 (in millions):

- changed (2019-05-07):
[0001633978-19-000030:note_history:26]
|  | Less than 1 year | 1-2 years | Greater than 2 years | Total |
| Performance Obligations | $531.5 | $7.7 | $— | $539.2 |
  (was, 2019-02-07, similarity 0.9912):
[0001633978-19-000002:note_history:26]
|  | Less than 1 year | 1-2 years | Greater than 2 years | Total |
| Performance Obligations | $550.1 | $11.0 | $0.3 | $561.4 |

- changed (2019-05-07):
[0001633978-19-000030:note_history:27]
The following table reflects the changes in contract balances as of March 30, 2019 (in millions, except percentages):
  (was, 2019-02-07, similarity 0.8618):
[0001633978-19-000002:note_history:27]
The following table reflects the changes in contract balances for the six months ended December 29, 2018 (in millions, except percentages):

- changed (2019-05-07):
[0001633978-19-000030:note_history:28]
| Contract balances | Balance sheet location | March 30, 2019 |  | June 30, 2018 |  | Change |  | Percentage Change |
| Accounts receivable, net | Accounts receivable, net | $302.9 |  | $197.1 |  | $105.8 |  | 53.7% |
| Deferred revenue and customer deposits | Other current liabilities | $4.2 |  | $2.8 |  | $1.4 |  | 50.0% |
  (was, 2019-02-07, similarity 0.9807):
[0001633978-19-000002:note_history:28]
| Contract balances | Balance sheet location | December 29, 2018 |  | June 30, 2018 |  | Change |  | Percentage Change |
| Accounts receivable, net | Accounts receivable, net | $266.5 |  | $197.1 |  | $69.4 |  | 35.2% |
| Deferred revenue and customer deposits | Other current liabilities | $3.9 |  | $2.8 |  | $1.1 |  | 39.3% |

- changed (2019-05-07):
[0001633978-19-000030:note_history:29]
Concurrent with the acquisition of Oclaro, on December 10, 2018, we established the functional currency for our worldwide operations as the U.S. dollar. The change in our functional currency is a result of significant changes in economic facts and circumstances, primarily the acquisition of Oclaro, a U.S. dollar-denominated functional currency company. The combined business, which requires the integration of our supply chain, manufacturing operations and sales organization, will predominantly use the U.S. dollar, including when negotiating customer and major supplier contracts.
  (was, 2019-02-07, similarity 0.9617):
[0001633978-19-000002:note_history:29]
Concurrent with the acquisition of Oclaro, on December 10, 2018, we established the functional currency for our worldwide operations as the U.S. dollar. The change in our functional currency is a result of significant changes in economic facts and circumstances, primarily the acquisition of Oclaro, a U.S. dollar-denominated functional currency company. The combined business, which requires the integration of our supply chain, manufacturing operations and sales organization, will predominantly use the U.S. dollar, including when negotiating customer and supplier contracts.

- changed (2019-05-07):
[0001633978-19-000030:note_history:30]
Translation adjustments reported prior to December 10, 2018, remain as a component of accumulated other comprehensive income in our condensed consolidated balance sheet. The translated values for any non-monetary assets and liabilities as of December 10, 2018 become the new accounting basis for those assets. Accordingly, monetary assets and liabilities denominated in foreign currencies have been remeasured into U.S. dollars using the exchange rates in effect at the balance sheet date. Foreign currency re-measurement gains (losses) are included in interest and other income (expense), net.
  (was, 2019-02-07, similarity 0.9839):
[0001633978-19-000002:note_history:30]
Translation adjustments reported prior to December 10, 2018, remain as a component of accumulated other comprehensive income in our condensed consolidated balance sheet. The translated values for any non-monetary assets and liabilities as of December 10, 2018 become the new accounting basis for those assets. Accordingly, monetary assets and liabilities denominated in foreign currencies have been remeasured into U.S. dollars using the exchange rates in effect at the balance sheet date. Foreign currency re-measurement gains (losses) are included in interest and other income (expense), net from December 10, 2018.

- removed (2019-05-07):
[0001633978-19-000002:note_history:31]
Certain prior period amounts have been reclassified to conform to the current year presentation in the notes to the condensed consolidated financial statements. The reclassification of the prior period amounts did not impact previously reported condensed consolidated financial statements, except for the presentation of net income attributable to common stockholders and net income per share attributable to common stockholders for the three and six months ended December 30, 2017. The adjustments are a result of using the two-class method to compute earnings per share for the impact of our Series A Preferred Stock outstanding. Refer to “Note 3. Earnings Per Share” for further details.


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2019-05-07):
[0001633978-19-000030:note_history:32]
| Liability component: | March 30, 2019 |  | June 30, 2018 |
| Principal | $ | 450.0 |  |  | $ | 450.0 |  |
| Unamortized debt discount | (102.6 | ) |  | (115.8 | ) |
| Net carrying amount of the liability component | $ | 347.4 |  |  | $ | 334.2 |  |

- removed (2019-05-07):
[0001633978-19-000002:note_history:33]
| Liability component: | December 29, 2018 |  | June 30, 2018 |
| Principal | $ | 450.0 |  |  | $ | 450.0 |  |
| Unamortized debt discount | (107.1 | ) |  | (115.8 | ) |
| Net carrying amount of the liability component | $ | 342.9 |  |  | $ | 334.2 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-05-07):
[0001633978-19-000030:note_history:34]
Note 13. Convertible Notes
  (was, 2019-02-07, similarity 0.8727):
[0001633978-19-000002:note_history:34]
Note 12. Convertible Senior Notes

- changed (2019-05-07):
[0001633978-19-000030:note_history:35]
Prior to the Tax Matters Agreement settlement condition (“TMA settlement condition”), because we could only settle the 2024 Notes in cash, we determined that the conversion feature met the definition of a derivative liability. We separated the derivative liability from the host debt instrument based on the fair value of the derivative liability. As of the issuance date, March 8, 2017, the derivative liability fair value of $129.9 million was calculated using the binomial valuation approach. The residual principal amount of the 2024 Notes of $320.1 million before issuance costs was allocated to the debt component. We incurred approximately $7.7 million in transaction costs in connection with the issuance of the 2024 Notes. These costs were allocated to the debt component and recognized as a debt discount. We amortize the debt discount, including both the initial value of the derivative liability and the transaction costs, over the term of the 2024 Notes using the effective interest method. The effective interest rate of the 2024 Notes is 5.4% per year. As of March 30, 2019, the remaining debt discount amortization period was 59 months.
  (was, 2019-02-07, similarity 0.9942):
[0001633978-19-000002:note_history:35]
Prior to the Tax Matters Agreement settlement condition (“TMA settlement condition”), because we could only settle the 2024 Notes in cash, we determined that the conversion feature met the definition of a derivative liability. We separated the derivative liability from the host debt instrument based on the fair value of the derivative liability. As of the issuance date, March 8, 2017, the derivative liability fair value of $129.9 million was calculated using the binomial valuation approach. The residual principal amount of the 2024 Notes of $320.1 million before issuance costs was allocated to the debt component. We incurred approximately $7.7 million in transaction costs in connection with the issuance of the 2024 Notes. These costs were allocated to the debt component and recognized as a debt discount. We amortize the debt discount, including both the initial value of the derivative liability and the transaction costs, over the term of the 2024 Notes using the effective interest method. The effective interest rate of the 2024 Notes is 5.4% per year. As of December 29, 2018, the remaining debt discount amortization period was 62 months.

- added (2019-05-07):
[0001633978-19-000030:note_history:36]
| Liability component: | March 30, 2019 |  | June 30, 2018 |
| Principal | $ | 450.0 |  |  | $ | 450.0 |  |
| Unamortized debt discount | (102.6 | ) |  | (115.8 | ) |
| Net carrying amount of the liability component | $ | 347.4 |  |  | $ | 334.2 |  |

- changed (2019-05-07):
[0001633978-19-000030:note_history:37]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 30, 2019 |  | March 31, 2018 |  | March 30, 2019 |  | March 31, 2018 |
| Contractual interest expense | $ | 0.3 |  |  | $ | 0.3 |  |  | $ | 0.9 |  |  | $ | 0.9 |  |
| Amortization of the debt discount | 4.5 |  |  | 4.2 |  |  | 13.2 |  |  | 12.4 |  |
| Total interest expense | $ | 4.8 |  |  | $ | 4.5 |  |  | $ | 14.1 |  |  | $ | 13.3 |  |
| Effective interest rate on the liability component | 5.4 | % |  | 5.4 | % |  | 5.4 | % |  | 5.4 | % |
  (was, 2019-02-07, similarity 0.8663):
[0001633978-19-000002:note_history:37]
|  | Three Months Ended |  | Six Months Ended |
|  | December 29, 2018 |  | December 30, 2017 |  | December 29, 2018 |  | December 30, 2017 |
| Contractual interest expense | $ | 0.3 |  |  | $ | 0.3 |  |  | $ | 0.6 |  |  | $ | 0.6 |  |
| Amortization of the debt discount | 4.4 |  |  | 4.1 |  |  | 8.7 |  |  | 8.2 |  |
| Total interest expense | $ | 4.7 |  |  | $ | 4.4 |  |  | $ | 9.3 |  |  | $ | 8.8 |  |
| Effective interest rate on the liability component | 5.4 | % |  | 5.4 | % |  | 5.4 | % |  | 5.4 | % |

- removed (2019-05-07):
[0001633978-19-000002:note_history:38]
| Liability component: | December 29, 2018 |  | June 30, 2018 |
| Principal | $ | 450.0 |  |  | $ | 450.0 |  |
| Unamortized debt discount | (107.1 | ) |  | (115.8 | ) |
| Net carrying amount of the liability component | $ | 342.9 |  |  | $ | 334.2 |  |


## us-gaap:DebtSecuritiesAvailableForSaleUnrealizedLossPositionFairValueTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-05-07):
[0001633978-19-000030:note_history:39]
|  | Less than 12 months |  | 12 Months or Greater |  | Total |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| March 30, 2019: |  |  |  |  |  |  |  |  |  |  |  |
| Commercial paper | $ | 5.9 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 5.9 |  |  | $ | — |  |
| Asset-backed securities | 13.1 |  |  | — |  |  | 15.9 |  |  | — |  |  | 29.0 |  |  | — |  |
| Corporate debt securities | 15.4 |  |  | (0.1 | ) |  | 84.8 |  |  | (0.2 | ) |  | 100.2 |  |  | (0.3 | ) |
| Foreign government bonds | 1.7 |  |  | — |  |  | 2.1 |  |  | — |  |  | 3.8 |  |  | — |  |
| U.S. government bonds | 14.8 |  |  | — |  |  | — |  |  | — |  |  | 14.8 |  |  | — |  |
| Total | $ | 50.9 |  |  | $ | (0.1 | ) |  | $ | 102.8 |  |  | $ | (0.2 | ) |  | $ | 153.7 |  |  | $ | (0.3 | ) |
| June 30, 2018: |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 5.4 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 5.4 |  |  | $ | — |  |
| Commercial paper | 8.5 |  |  | — |  |  | — |  |  | — |  |  | 8.5 |  |  | — |  |
| Asset-backed securities | 66.6 |  |  | (0.2 | ) |  | 0.3 |  |  | — |  |  | 66.9 |  |  | (0.2 | ) |
| Corporate debt securities | 188.6 |  |  | (1.5 | ) |  | 2.0 |  |  | — |  |  | 190.6 |  |  | (1.5 | ) |
| Municipal bonds | 0.6 |  |  | — |  |  | — |  |  | — |  |  | 0.6 |  |  | — |  |
| U.S. Agency securities | 4.0 |  |  | — |  |  | — |  |  | — |  |  | 4.0 |  |  | — |  |
| Foreign government bonds | 3.4 |  |  | — |  |  | — |  |  | — |  |  | 3.4 |  |  | — |  |
| Total | $ | 277.1 |  |  | $ | (1.7 | ) |  | $ | 2.3 |  |  | $ | — |  |  | $ | 279.4 |  |  | $ | (1.7 | ) |
  (was, 2019-02-07, similarity 0.9135):
[0001633978-19-000002:note_history:39]
|  | Less than 12 months |  | 12 Months or Greater |  | Total |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| December 29, 2018: |  |  |  |  |  |  |  |  |  |  |  |
| Commercial paper | $ | 12.8 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 12.8 |  |  | $ | — |  |
| Asset-backed securities | 32.1 |  |  | (0.1 | ) |  | 12.3 |  |  | — |  |  | 44.4 |  |  | (0.1 | ) |
| Corporate debt securities | 101.1 |  |  | (0.4 | ) |  | 88.1 |  |  | (0.7 | ) |  | 189.2 |  |  | (1.1 | ) |
| Mortgage-backed securities | 0.1 |  |  | — |  |  | — |  |  | — |  |  | 0.1 |  |  | — |  |
| Foreign government bonds | 2.9 |  |  | — |  |  | 2.1 |  |  | — |  |  | 5.0 |  |  | — |  |
| Total | $ | 149.0 |  |  | $ | (0.5 | ) |  | $ | 102.5 |  |  | $ | (0.7 | ) |  | $ | 251.5 |  |  | $ | (1.2 | ) |
| June 30, 2018: |  |  |  |  |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 5.4 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 5.4 |  |  | $ | — |  |
| Commercial paper | 8.5 |  |  | — |  |  | — |  |  | — |  |  | 8.5 |  |  | — |  |
| Asset-backed securities | 66.6 |  |  | (0.2 | ) |  | 0.3 |  |  | — |  |  | 66.9 |  |  | (0.2 | ) |
| Corporate debt securities | 188.6 |  |  | (1.5 | ) |  | 2.0 |  |  | — |  |  | 190.6 |  |  | (1.5 | ) |
| Municipal bonds | 0.6 |  |  | — |  |  | — |  |  | — |  |  | 0.6 |  |  | — |  |
| U.S. Agency securities | 4.0 |  |  | — |  |  | — |  |  | — |  |  | 4.0 |  |  | — |  |
| Foreign government bonds | 3.4 |  |  | — |  |  | — |  |  | — |  |  | 3.4 |  |  | — |  |
| Total | $ | 277.1 |  |  | $ | (1.7 | ) |  | $ | 2.3 |  |  | $ | — |  |  | $ | 279.4 |  |  | $ | (1.7 | ) |


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-05-07):
[0001633978-19-000030:note_history:40]
The term loans bear interest at a rate equal to an applicable margin plus, at our option, either (a) a base rate equal to the highest of (i) the prime rate then in effect, (ii) the federal funds rate, plus 0.50% and (iii) an adjusted LIBOR rate determined on the basis of a one-month interest period, plus 1.0%, subject to a floor of 0.0%, or (b) an adjusted LIBOR rate, subject to a floor of 0.0%. The applicable margin with respect to the initial term loans is equal to 2.50% in the case of LIBOR rate loans and 1.50% in the case of base rate loans. The applicable margin is adjusted following the first full fiscal quarter after the Closing Date, if our first lien net leverage ratio is equal to or less than 0.50:1.00, to 2.25% in the case of LIBOR rate loans and 1.25% in the case of base rate loans. During the three and nine months ended March 30, 2019, we recorded interest expense of $6.5 million and $8.0 million respectively related to the initial term loans, which is included in interest and other income (expense), net in our condensed consolidated statements of operations.
  (was, 2019-02-07, similarity 0.9634):
[0001633978-19-000002:note_history:40]
The term loans bear interest at a rate equal to an applicable margin plus, at our option, either (a) a base rate equal to the highest of (i) the prime rate then in effect, (ii) the federal funds rate, plus 0.50% and (iii) an adjusted LIBOR rate determined on the basis of a one-month interest period, plus 1.0%, subject to a floor of 0.0%, or (b) an adjusted LIBOR rate, subject to a floor of 0.0%. The applicable margin with respect to the initial term loans is equal to 2.50% in the case of LIBOR rate loans and 1.50% in the case of base rate loans. The applicable margin is adjusted following the first full fiscal quarter after the Closing Date, if our first lien net leverage ratio is equal to or less than 0.50:1.00, to 2.25% in the case of LIBOR rate loans and 1.25% in the case of base rate loans. During the three and six months ended December 29, 2018, we recorded interest expense of $1.4 million related to the initial term loans, which is included in interest and other income (expense), net in our condensed consolidated statements of operations.

- changed (2019-05-07):
[0001633978-19-000030:note_history:41]
The commitment letter with Deutsche Bank required payment of a ticking fee. During the three and nine months ended March 30, 2019, we recorded total expenses in connection with the ticking fee of zero and $2.7 million, respectively. This ticking fee expense is included in interest and other income (expense), net in our condensed consolidated statements of operations. During the three and nine months ended March 30, 2019 we paid $1.3 million of principal on the term loan.
  (was, 2019-02-07, similarity 0.7937):
[0001633978-19-000002:note_history:41]
The commitment letter with Deutsche Bank required payment of a ticking fee. During the three and six months ended December 29, 2018, we recorded total expenses in connection with the ticking fee of $2.3 million and $2.7 million, respectively. This ticking fee expense is included in interest and other income (expense), net in our condensed consolidated statements of operations.

- changed (2019-05-07):
[0001633978-19-000030:note_history:42]
The Credit Agreement contains customary affirmative and negative covenants, including covenants limiting the ability of Lumentum and its restricted subsidiaries to, among other things, incur debt, grant liens, undergo certain fundamental changes, make investments, make certain restricted payments, dispose of assets, and enter into transactions with affiliates, in each case, subject to limitations and exceptions set forth in the Credit Agreement. The Credit Agreement also contains customary events of default that include, among other things, certain payment defaults, cross defaults to other indebtedness, covenant defaults, change of control defaults, judgment defaults, and bankruptcy and insolvency defaults. If an event of default exists, the lenders may require the immediate payment of all obligations under the Credit Agreement, and may exercise certain other rights and remedies provided for under the Credit Agreement, the other loan documents and applicable law. As of March 30, 2019, we were in compliance with all of the covenants.
  (was, 2019-02-07, similarity 0.9938):
[0001633978-19-000002:note_history:42]
The Credit Agreement contains customary affirmative and negative covenants, including covenants limiting the ability of Lumentum and its restricted subsidiaries to, among other things, incur debt, grant liens, undergo certain fundamental changes, make investments, make certain restricted payments, dispose of assets, and enter into transactions with affiliates, in each case, subject to limitations and exceptions set forth in the Credit Agreement. The Credit Agreement also contains customary events of default that include, among other things, certain payment defaults, cross defaults to other indebtedness, covenant defaults, change of control defaults, judgment defaults, and bankruptcy and insolvency defaults. If an event of default exists, the lenders may require the immediate payment of all obligations under the Credit Agreement, and may exercise certain other rights and remedies provided for under the Credit Agreement, the other loan documents and applicable law. As of December 29, 2018, we were in compliance with all of the covenants.

- changed (2019-05-07):
[0001633978-19-000030:note_history:43]
We incurred $9.3 million of debt issuance costs in connection with the Term Loan Facility which were capitalized and recorded as a contra liability in our condensed consolidated balance sheet. These costs will be amortized to interest expense using the effective interest rate method from the issuance date of December 10, 2018, through the end of the term of the loan. As of March 30, 2019, the effective interest rate is 5.27% and the stated interest rate is 4.99%.
  (was, 2019-02-07, similarity 0.9855):
[0001633978-19-000002:note_history:43]
We incurred $9.3 million of debt issuance costs in connection with the Term Loan Facility which were capitalized and recorded as a contra liability in our condensed consolidated balance sheet. These costs will be amortized to interest expense using the effective interest rate method from the issuance date of December 10, 2018, through the end of the term of the loan. As of December 29, 2018, the effective interest rate is 5.16% and the stated interest rate is 4.89%.

- changed (2019-05-07):
[0001633978-19-000030:note_history:44]
The following table sets forth balance sheet information related to the term loan at March 30, 2019 (in millions):
  (was, 2019-02-07, similarity 0.9593):
[0001633978-19-000002:note_history:44]
The following table sets forth balance sheet information related to the term loan at December 29, 2018 (in millions):

- added (2019-05-07):
[0001633978-19-000030:note_history:45]
|  | March 30, 2019 |
| Principal | $ | 500.0 |  |
| Repayment of principal | (1.3 | ) |
| Unamortized value of the debt issuance costs | (8.8 | ) |
| Net carrying value | $ | 489.9 |  |
| Term loan, current | $ | 5.0 |  |
| Term loan, non-current | $ | 484.9 |  |

- changed (2019-05-07):
[0001633978-19-000030:note_history:46]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 30, 2019 |  | March 31, 2018 |  | March 30, 2019 |  | March 31, 2018 |
| Contractual interest expense | $ | 6.2 |  |  | $ | — |  |  | $ | 10.2 |  |  | $ | — |  |
| Amortization of the debt issuance costs | 0.4 |  |  | — |  |  | 0.5 |  |  | — |  |
| Total interest expense | $ | 6.6 |  |  | $ | — |  |  | $ | 10.7 |  |  | $ | — |  |
  (was, 2019-02-07, similarity 0.8316):
[0001633978-19-000002:note_history:46]
|  | Three Months Ended |  | Six Months Ended |
|  | December 29, 2018 |  | December 30, 2017 |  | December 29, 2018 |  | December 30, 2017 |
| Contractual interest expense | $ | 3.7 |  |  | $ | — |  |  | $ | 4.1 |  |  | $ | — |  |
| Amortization of the debt issuance costs | 0.1 |  |  | — |  |  | 0.1 |  |  | — |  |
| Total interest expense | $ | 3.8 |  |  | $ | — |  |  | $ | 4.2 |  |  | $ | — |  |

- removed (2019-05-07):
[0001633978-19-000002:note_history:47]
|  | December 29, 2018 |
| Principal | $ | 500.0 |  |
| Unamortized value of the debt issuance costs | (9.2 | ) |
| Net carrying value | $ | 490.8 |  |
| Term loan, current | $ | 5.0 |  |
| Term loan, non-current | $ | 485.8 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-05-07):
[0001633978-19-000030:note_history:48]
The following table sets forth balance sheet information related to the term loan at March 30, 2019 (in millions):
  (was, 2019-02-07, similarity 0.9593):
[0001633978-19-000002:note_history:48]
The following table sets forth balance sheet information related to the term loan at December 29, 2018 (in millions):

- added (2019-05-07):
[0001633978-19-000030:note_history:49]
|  | March 30, 2019 |
| Principal | $ | 500.0 |  |
| Repayment of principal | (1.3 | ) |
| Unamortized value of the debt issuance costs | (8.8 | ) |
| Net carrying value | $ | 489.9 |  |
| Term loan, current | $ | 5.0 |  |
| Term loan, non-current | $ | 484.9 |  |

- removed (2019-05-07):
[0001633978-19-000002:note_history:50]
|  | December 29, 2018 |
| Principal | $ | 500.0 |  |
| Unamortized value of the debt issuance costs | (9.2 | ) |
| Net carrying value | $ | 490.8 |  |
| Term loan, current | $ | 5.0 |  |
| Term loan, non-current | $ | 485.8 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-05-07):
[0001633978-19-000030:note_history:51]
The future interest and principal payments related to the 2024 Notes are as follows as of March 30, 2019:
  (was, 2019-02-07, similarity 0.9543):
[0001633978-19-000002:note_history:51]
The future interest and principal payments related to the 2024 Notes are as follows as of December 29, 2018:

- changed (2019-05-07):
[0001633978-19-000030:note_history:52]
| Fiscal Years |  |
| Remainder of 2019 | $ | — |  |
| 2020 | 1.1 |  |
| 2021 | 1.1 |  |
| 2022 | 1.1 |  |
| 2023 | 1.1 |  |
| Thereafter | 451.2 |  |
| Total 2024 Notes payments | $ | 455.6 |  |
  (was, 2019-02-07, similarity 0.9935):
[0001633978-19-000002:note_history:52]
| Fiscal Years |  |
| Remainder of 2019 | $ | 0.6 |  |
| 2020 | 1.1 |  |
| 2021 | 1.1 |  |
| 2022 | 1.1 |  |
| 2023 | 1.1 |  |
| Thereafter | 451.2 |  |
| Total 2024 Notes payments | $ | 456.2 |  |

- changed (2019-05-07):
[0001633978-19-000030:note_history:53]
The estimated future interest and principal payments related to the term loan are as follows as of March 30, 2019:
  (was, 2019-02-07, similarity 0.9593):
[0001633978-19-000002:note_history:53]
The estimated future interest and principal payments related to the term loan are as follows as of December 29, 2018:


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-05-07):
[0001633978-19-000030:note_history:54]
| Contract balances | Balance sheet location | March 30, 2019 |  | June 30, 2018 |  | Change |  | Percentage Change |
| Accounts receivable, net | Accounts receivable, net | $302.9 |  | $197.1 |  | $105.8 |  | 53.7% |
| Deferred revenue and customer deposits | Other current liabilities | $4.2 |  | $2.8 |  | $1.4 |  | 50.0% |
  (was, 2019-02-07, similarity 0.9807):
[0001633978-19-000002:note_history:54]
| Contract balances | Balance sheet location | December 29, 2018 |  | June 30, 2018 |  | Change |  | Percentage Change |
| Accounts receivable, net | Accounts receivable, net | $266.5 |  | $197.1 |  | $69.4 |  | 35.2% |
| Deferred revenue and customer deposits | Other current liabilities | $3.9 |  | $2.8 |  | $1.1 |  | 39.3% |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2019-05-07):
[0001633978-19-000030:note_history:55]
Note 20. Subsequent Event

- added (2019-05-07):
[0001633978-19-000030:note_history:56]
On May 6, 2019,  the Company entered into an agreement for the purchase of property located in San Jose, California. The total purchase price for the property is $54.0 million.  The Purchase Agreement contains customary representations, warranties and covenants of the parties and the closing of the purchase is expected to occur during the Company’s fourth fiscal quarter of 2019 and is subject to conditions typical for a transaction of this type.
