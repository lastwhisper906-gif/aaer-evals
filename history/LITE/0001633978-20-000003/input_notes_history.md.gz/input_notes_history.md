# LITE note change history — 0001633978-19-000071 → 0001633978-20-000003


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2020-02-04):
[0001633978-20-000003:note_history:1]
In February 2017, as a result of the acquisition of a privately held company, we incurred the contingent liability of $3.0 million. This liability is recorded in other current liabilities within our condensed consolidated balance sheet as of December 28, 2019.

- changed (2020-02-04):
[0001633978-20-000003:note_history:2]
Purchase obligations of $289.5 million as of December 28, 2019, represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements.
  (was, 2019-10-31, similarity 0.9831):
[0001633978-19-000071:note_history:2]
Purchase obligations of $277.6 million as of September 28, 2019, represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements.

- changed (2020-02-04):
[0001633978-20-000003:note_history:3]
We provide reserves for the estimated costs of product warranties at the time revenue is recognized. We typically offer a twelve month warranty for most of our products. However, in some instances depending upon the product, product components or application of our products by the end customer, our warranties can vary and generally range from six months to five years. We estimate the costs of our warranty obligations on an annualized basis based on our historical experience of known product failure rates, use of materials to repair or replace defective products and service delivery costs incurred in correcting product failures. In addition, from time to time, specific warranty accruals may be made if unforeseen technical problems arise with specific products. We assess the adequacy of our recorded warranty liabilities and adjust the amounts as necessary.
  (was, 2019-10-31, similarity 0.9994):
[0001633978-19-000071:note_history:3]
We provide reserves for the estimated costs of product warranties at the time revenue is recognized. We typically offer a twelve month warranty for most of our products. However, in some instances depending upon the product, product component or application of our products by the end customer, our warranties can vary and generally range from six months to five years. We estimate the costs of our warranty obligations on an annualized basis based on our historical experience of known product failure rates, use of materials to repair or replace defective products and service delivery costs incurred in correcting product failures. In addition, from time to time, specific warranty accruals may be made if unforeseen technical problems arise with specific products. We assess the adequacy of our recorded warranty liabilities and adjust the amounts as necessary.

- changed (2020-02-04):
[0001633978-20-000003:note_history:4]
The following table presents the changes in our warranty reserve during the three and six months ended December 28, 2019 and December 29, 2018 (in millions):
  (was, 2019-10-31, similarity 0.9375):
[0001633978-19-000071:note_history:4]
The following table presents the changes in our warranty reserve during the three months ended September 28, 2019 and September 29, 2018 (in millions):

- added (2020-02-04):
[0001633978-20-000003:note_history:5]
|  | Three Months Ended |  | Six Months Ended |
|  | December 28, 2019 |  | December 29, 2018 |  | December 28, 2019 |  | December 29, 2018 |
| Balance as of beginning of period | $ | 7.0 |  |  | $ | 6.6 |  |  | $ | 7.5 |  |  | $ | 6.6 |  |
| Warranties assumed in Oclaro acquisition | — |  |  | 3.8 |  |  | — |  |  | 3.8 |  |
| Provision for warranty | 0.6 |  |  | 0.7 |  |  | 1.8 |  |  | 1.9 |  |
| Utilization of reserve | (0.8 | ) |  | (1.4 | ) |  | (2.5 | ) |  | (2.6 | ) |
| Balance as of end of period | $ | 6.8 |  |  | $ | 9.7 |  |  | $ | 6.8 |  |  | $ | 9.7 |  |

- changed (2020-02-04):
[0001633978-20-000003:note_history:6]
We are subject to a variety of claims and suits that arise from time to time in the ordinary course of our business. While management currently believes that resolving claims against us, individually or in the aggregate, will not have a material adverse impact on our financial position, results of operations or statements of cash flows, these matters are subject to inherent uncertainties and management’s view of these matters may change in the future. We accrue for loss contingencies when it is both probable that we will incur the loss and when we can reasonably estimate the amount of the loss or range of loss. As of December 28, 2019, we did not have any material claims or proceedings that were probable or reasonably possible.
  (was, 2019-10-31, similarity 0.9952):
[0001633978-19-000071:note_history:6]
We are subject to a variety of claims and suits that arise from time to time in the ordinary course of our business. While management currently believes that resolving claims against us, individually or in the aggregate, will not have a material adverse impact on our financial position, results of operations or statements of cash flows, these matters are subject to inherent uncertainties and management’s view of these matters may change in the future. We accrue for loss contingencies when it is both probable that we will incur the loss and when we can reasonably estimate the amount of the loss or range of loss. As of September 28, 2019, we did not have any material claims or proceedings that were probable or reasonably possible.

- changed (2020-02-04):
[0001633978-20-000003:note_history:7]
The remaining Lawsuit (the Karri Lawsuit) currently purports to seek, among other things, damages to be awarded to the plaintiff and any class, if a class is certified, and litigation costs, including attorneys’ fees.  A lead plaintiff and counsel has been selected, and an amended complaint was filed on April 15, 2019, which also names Lumentum as a defendant.  A motion to dismiss the amended complaint has been fully briefed and is currently pending, and defendants intend to defend the Karri Lawsuit vigorously.
  (was, 2019-10-31, similarity 0.9881):
[0001633978-19-000071:note_history:7]
The remaining Lawsuit (the Karri Lawsuit) currently purports to seek, among other things, damages to be awarded to the plaintiff and any class, if a class is certified, and litigation costs, including attorneys’ fees.  A lead plaintiff and counsel has been selected, and an amended complaint was filed on April 15, 2019, which also names Lumentum as a defendant.  A motion to dismiss the amended complaint has been filed and is currently pending, and defendants intend to defend the Karri Lawsuit vigorously.

- changed (2020-02-04):
[0001633978-20-000003:note_history:8]
In the normal course of business, we enter into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown because claims may be made against us in the future and we may record charges in the future as a result of these indemnification obligations. As of December 28, 2019, we did not have any material indemnification claims that were probable or reasonably possible.
  (was, 2019-10-31, similarity 0.9923):
[0001633978-19-000071:note_history:8]
In the normal course of business, we enter into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown because claims may be made against us in the future and we may record charges in the future as a result of these indemnification obligations. As of September 28, 2019, we did not have any material indemnification claims that were probable or reasonably possible.

- changed (2020-02-04):
[0001633978-20-000003:note_history:9]
We are under audit by various domestic and foreign tax authorities with regards to income tax and indirect tax matters. In some, although not all cases, we have reserved for potential adjustments to our provision for income taxes and accrual of indirect taxes that may result from examinations by these tax authorities or final outcomes in judicial proceedings, and we believe that the final outcome of these examinations, agreements or judicial proceedings will not have a material effect on our results of operations. If events occur which indicate payment of these amounts is unnecessary, the reversal of the liabilities would result in the recognition of benefits in the period we determine the liabilities are no longer necessary. If our estimates of the federal, state, and foreign income tax liabilities and indirect tax liabilities are less than the ultimate assessment, it could result in a further charge to expense.
  (was, 2019-10-31, similarity 0.7504):
[0001633978-19-000071:note_history:9]
We are under audit by various domestic and foreign tax authorities with regards to income tax and indirect tax matters. In some, although not all cases, we have reserved for potential adjustments to our provision for income taxes and accrual of indirect taxes that may result from examinations by these tax authorities or final outcomes in judicial proceedings, and we believe that the final outcome of these examinations, agreements or judicial proceedings will not have a material effect on our results of operations. If events occur which indicate payment of these amounts is unnecessary, the reversal of the liabilities would result in the recognition of benefits in the period we determine the liabilities are no longer necessary. If our estimates of the federal, state, and foreign income tax liabilities and indirect tax liabilities are less than the ultimate assessment, it could result in a further charge to expense.
In connection with our acquisition of Oclaro, we recorded $1.1 million in Malaysia Goods and Services Tax (“GST”) refund claims within prepaid expenses and other current assets in our condensed consolidated balance sheet. The refund claim represents an initial claim of $2.5 million of GST, net of reserves, that were previously denied by the Malaysian tax authorities in 2016. During the three months ended September 28, 2019, we were able to favorably resolve this audit and we received refunds for the majority of our outstanding GST claims, with the remaining amounts expected to be received in our second quarter of fiscal 2020.

- added (2020-02-04):
[0001633978-20-000003:note_history:10]
In connection with our acquisition of Oclaro, we recorded $1.1 million in Malaysia Goods and Services Tax (“GST”) refund claims within prepaid expenses and other current assets in our condensed consolidated balance sheet. The refund claim represents an initial claim of $2.5 million of GST, net of reserves, that were previously denied by the Malaysian tax authorities in 2016. 
During the six months ended December 28, 2019, we were able to favorably resolve this audit and received refunds for all of our outstanding GST claims.

- removed (2020-02-04):
[0001633978-19-000071:note_history:11]
In February 2017, we incurred liabilities in the amount of $3.6 million related to an acquisition of a privately held company (based on the exchange rate at the date of acquisition). The purchase price retainer for the seller’s indemnification obligations was paid to the seller in fiscal 2019, and the contingent liability of $3.0 million (actual payment is subject to the then applicable exchange rate) is expected to be paid within the next 12 months contingent upon meeting certain production targets. We estimated the fair value of the contingent consideration to be $3.0 million and recorded this amount in other current liabilities within our condensed consolidated balance sheet as of September 28, 2019.

- removed (2020-02-04):
[0001633978-19-000071:note_history:12]
Term Loan

- removed (2020-02-04):
[0001633978-19-000071:note_history:13]
The estimated future interest and principal payments related to the term loan are as follows as of September 28, 2019 (in millions):

- removed (2020-02-04):
[0001633978-19-000071:note_history:14]
| Fiscal Years |  |
| Remainder of 2020 | $ | 31.0 |  |
| 2021 | 27.6 |  |
| 2022 | 27.3 |  |
| 2023 | 27.1 |  |
| 2024 | 26.9 |  |
| Thereafter | 497.1 |  |
| Total term loan payments | $ | 637.0 |  |

- removed (2020-02-04):
[0001633978-19-000071:note_history:15]
0.25% Convertible Notes due 2024

- removed (2020-02-04):
[0001633978-19-000071:note_history:16]
The future interest and principal payments related to the 2024 Notes are as follows as of September 28, 2019 (in millions):

- removed (2020-02-04):
[0001633978-19-000071:note_history:17]
| Fiscal Years |  |
| Remainder of 2020 | $ | 0.5 |  |
| 2021 | 1.1 |  |
| 2022 | 1.1 |  |
| 2023 | 1.1 |  |
| 2024 | 451.2 |  |
| Thereafter | — |  |
| Total 2024 Notes payments | $ | 455.0 |  |

- removed (2020-02-04):
[0001633978-19-000071:note_history:18]
|  | Three Months Ended |
|  | September 28, 2019 |  | September 29, 2018 |
| Balance as of beginning of period | $ | 7.5 |  |  | $ | 6.6 |  |
| Provision for warranty | 1.2 |  |  | 1.2 |  |
| Utilization of reserve | (1.7 | ) |  | (1.2 | ) |
| Balance as of end of period | $ | 7.0 |  |  | $ | 6.6 |  |


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2020-02-04):
[0001633978-20-000003:note_history:19]
Lumentum (“we,” “us,” “our” or the “Company”) is an industry-leading provider of optical and photonic products defined by revenue and market share addressing a range of end market applications including Optical Communications (“OpComms”) and Lasers for manufacturing, inspection and life-science applications. We seek to use our core optical and photonic technology and our volume manufacturing capability to expand into attractive emerging markets that benefit from advantages that optical or photonics based solutions provide, including 3D sensing for consumer electronics and diode light sources for a variety of consumer and industrial applications. The majority of our customers tend to be Original Equipment Manufacturers (“OEMs”) that incorporate our products into their products which then address end-market applications. For example, we sell fiber optic components that Network Equipment Manufacturers’ (“NEMs”) customers assemble into communications networking systems, which they sell to network service providers or enterprises with their own networks. Similarly, many of our customers for our Lasers products incorporate our products into tools they produce, which are used for manufacturing processes by their customers. For 3D sensing, we sell diode lasers to manufacturers of consumer electronics products for mobile, personal computing, gaming, and other applications who then integrate our devices within their products, for eventual resale to consumers and also into other industrial applications. Further, we have begun shipping prototype units of diode lasers and optical subassemblies containing diode lasers and other optical devices to automotive customers for sensing and LiDAR applications.
  (was, 2019-10-31, similarity 0.8151):
[0001633978-19-000071:note_history:19]
Lumentum (“we,” “us,” “our” or the “Company”) is an industry-leading provider of optical and photonic products defined by revenue and market share addressing a range of end market applications including Optical Communications (“OpComms”) and Lasers for manufacturing, inspection and life-science applications. We seek to use our core optical and photonic technology and our volume manufacturing capability to expand into attractive emerging markets that benefit from advantages that optical or photonics based solutions provide, including 3D sensing for consumer electronics and diode light sources for a variety of consumer and industrial applications. The majority of our customers tend to be Original Equipment Manufacturers (“OEMs”) that incorporate our products into their products which then address end-market applications. For example, we sell fiber optic components that Network Equipment Manufacturers’ (“NEMs”) customers assemble into communications networking systems, which they sell to network service providers or enterprises with their own networks. Similarly, many of our customers for our Lasers products incorporate our products into tools they produce, which are used for manufacturing processes by their customers. For 3D sensing, we sell diode lasers to manufacturers of consumer electronics products for mobile, personal computing, and gaming who then integrate our devices within their products, for eventual resale to consumers and also into other industrial applications. Further, we are starting to sell diode lasers and optical subassemblies containing diode lasers and other optical devices to automotive customers for sensing and LiDAR applications.

- added (2020-02-04):
[0001633978-20-000003:note_history:20]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Every fifth or sixth fiscal year will have a 53-week period. The additional week in a 53-week year is added to the third quarter, making such quarter consist of 14 weeks. Our fiscal 2021 will be a 53-week year. Our fiscal 2020 is a 52-week year ending on June 27, 2020, with the quarter ended December 28, 2019 being a 13-week quarterly period. Our fiscal 2019 was a 52-week year that ended on June 29, 2019, with the quarter ended December 29, 2018 being a 13-week quarterly period.

- changed (2020-02-04):
[0001633978-20-000003:note_history:21]
Except for the accounting policies for lease accounting as a result of the adoption of Accounting Standards Update (“ASU”) 2016-02, Leases (Topic 842), there have been no significant changes to our significant accounting policies as of and for the three months ended December 28, 2019, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the year ended June 29, 2019.
  (was, 2019-10-31, similarity 0.7688):
[0001633978-19-000071:note_history:21]
Except for the accounting policies for lease accounting as a result of the adoption of Accounting Standards Update (“ASU”) 2016-02, Leases (Topic 842), there have been no significant changes to our significant accounting policies as of and for the three

- changed (2020-02-04):
[0001633978-20-000003:note_history:22]
On June 30, 2019, the first day of fiscal year 2020, we adopted Topic 842, using the modified retrospective transition approach. Refer to “Note 2. Recently Issued Accounting Pronouncements” regarding the impact of adoption.
  (was, 2019-10-31, similarity 0.9199):
[0001633978-19-000071:note_history:22]
On June 30, 2019, we adopted Topic 842, using the modified retrospective transition approach. Refer to “Note 2. Recently Issued Accounting Pronouncements” regarding the impact of adoption.

- removed (2020-02-04):
[0001633978-19-000071:note_history:23]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Our fiscal 2020 is a 52-week year ending on June 27, 2020, with the quarter ended September 28, 2019 being a 13-week quarterly period. Our fiscal 2019 was a 52-week year that ended on June 29, 2019, with the quarter ended September 29, 2018 being a 13-week quarterly period.

- removed (2020-02-04):
[0001633978-19-000071:note_history:24]
months ended September 28, 2019, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the year ended June 29, 2019.


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-02-04):
[0001633978-20-000003:note_history:25]
Our convertible notes consisted of the following components as of the periods presented (in millions):
  (was, 2019-10-31, similarity 0.9072):
[0001633978-19-000071:note_history:25]
The 2024 Notes consisted of the following components as of the periods presented (in millions):

- added (2020-02-04):
[0001633978-20-000003:note_history:26]
| Liability component: | December 28, 2019 |  | June 29, 2019 |
|  | 2024 Notes |  | 2026 Notes |  | 2024 Notes |
| Principal | $ | 450.0 |  |  | $ | 1,050.0 |  |  | $ | 450.0 |  |
| Unamortized debt discount and debt issuance costs | (88.9 | ) |  | (319.1 | ) |  | (98.1 | ) |
| Net carrying amount of the liability component | $ | 361.1 |  |  | $ | 730.9 |  |  | $ | 351.9 |  |

- removed (2020-02-04):
[0001633978-19-000071:note_history:27]
| Liability component: | September 28, 2019 |  | June 29, 2019 |
| Principal | $ | 450.0 |  |  | $ | 450.0 |  |
| Unamortized debt discount | (93.5 | ) |  | (98.1 | ) |
| Net carrying amount of the liability component | $ | 356.5 |  |  | $ | 351.9 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2020-02-04):
[0001633978-20-000003:note_history:28]
Note 12. Debt

- added (2020-02-04):
[0001633978-20-000003:note_history:29]
2026 Notes

- added (2020-02-04):
[0001633978-20-000003:note_history:30]
In December 2019, we issued $1,050.0 million in aggregate principal amount of the 2026 Notes in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act of 1933, as amended (the “Securities Act”). The 2026 Notes are governed by an indenture between the Company and U.S. Bank National Association (the “2026 Indenture”). We used approximately $196 million of the net proceeds of the offering to repay in full all amounts outstanding under our term loan credit facility, and a portion of the net proceeds of the offering to purchase approximately $200 million of our common stock concurrently with the pricing of the offering in privately negotiated transactions. The 2026 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

- added (2020-02-04):
[0001633978-20-000003:note_history:31]
The 2026 Notes will bear interest at a rate of 0.50% per year, payable semi-annually in arrears on June 15 and December 15 of each year, beginning on June 15, 2020. The 2026 Notes will mature on December 15, 2026, unless earlier redeemed, repurchased by us, or converted pursuant to their terms.

- added (2020-02-04):
[0001633978-20-000003:note_history:32]
The initial conversion rate is 10.0711 shares of common stock per $1,000 principal amount of the 2026 Notes (which is equivalent to an initial conversion price of approximately $99.29 per share). The conversion rate is subject to adjustment upon the occurrence of certain specified events but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert the 2026 Notes in connection with such make-whole fundamental change or notice of redemption.

- added (2020-02-04):
[0001633978-20-000003:note_history:33]
Prior to the close of business on the business day immediately preceding September 15, 2026, holders of the 2026 Notes may convert their 2026 Notes only under the following circumstances:

- added (2020-02-04):
[0001633978-20-000003:note_history:34]
| • | during any fiscal quarter commencing after the fiscal quarter ended on March 28, 2020 (and only during such fiscal quarter), if the last reported sale price of the common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price of the 2026 Notes on each applicable trading day; |

- added (2020-02-04):
[0001633978-20-000003:note_history:35]
| • | during the five business day period after any five consecutive trading day period (the "2026 measurement period") in which the trading price per $1,000 principal amount of the 2026 Notes for each trading day of the 2026 measurement period was less than 98% of the product of the last reported sale price of our common stock and the conversion rate for the notes on each such trading day; |

- added (2020-02-04):
[0001633978-20-000003:note_history:36]
| • | if we call any or all of the 2026 Notes for redemption, at any time prior to the close of business on the second business day immediately preceding the relevant redemption date; or |

- added (2020-02-04):
[0001633978-20-000003:note_history:37]
| • | upon the occurrence of specified corporate events, as specified in each indenture governing the 2026 Notes. |

- added (2020-02-04):
[0001633978-20-000003:note_history:38]
On or after September 15, 2026 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert the 2026 Notes at any time. Upon conversion, we may satisfy our conversion obligation in cash, shares of common stock or a combination of cash and shares of common stock, at our election.

- added (2020-02-04):
[0001633978-20-000003:note_history:39]
We may redeem for cash, stock or combination of both for all or any portion of the 2026 Notes, at our option, on or after December 20, 2023, if the last reported sale price of its common stock has been at least 130% of the conversion price then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading-day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which we provide a notice of redemption at a redemption price equal to 100% of the principal amount of the 2026 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. No sinking fund is provided for the 2026 Notes. Upon the occurrence of a fundamental change (as defined in the 2026 Indenture), holders may require us to repurchase all or a portion of the 2026 Notes for cash at a price equal to 100% of the principal amount of the 2026 Notes to be repurchased, plus any accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

- added (2020-02-04):
[0001633978-20-000003:note_history:40]
In accordance with accounting for debt with conversions and other options, we bifurcated the principal amount of the 2026 Notes into liability and equity components. The liability component of the 2026 Notes was valued at $734.8 million based on the contractual cash flows discounted at an appropriate comparable market non-convertible debt borrowing rate at the date of issuance of 5.8% with the equity component representing the residual amount of the proceeds of $315.2 million, which was recorded as a debt discount.

- added (2020-02-04):
[0001633978-20-000003:note_history:41]
We incurred approximately $7.8 million in transaction costs in connection with the issuance of the 2026 Notes and these costs were allocated pro rata based on the relative carrying amounts of the liability and equity components. The debt discount and debt issuance costs attributable to the liability component will be amortized to interest expense using an effective interest rate of 5.8% over the expected life of the 2026 Notes. Debt issuance costs attributable to the equity component are netted with the equity component in stockholders’ equity, and the equity component is not remeasured as long as it continues to meet the conditions for equity classification.

- added (2020-02-04):
[0001633978-20-000003:note_history:42]
2024 Notes

- changed (2020-02-04):
[0001633978-20-000003:note_history:43]
In March 2017, we issued the 2024 Notes in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act. The 2024 Notes are governed by an indenture between the Company, as the issuer, and U.S. Bank National Association, as trustee (the “2024 Indenture”). The 2024 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.
  (was, 2019-10-31, similarity 0.6337):
[0001633978-19-000071:note_history:43]
In March 2017, we issued the 2024 Notes in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act of 1933, as amended (the “Securities Act”). The 2024 Notes are governed by an indenture between the Company, as the issuer, and U.S. Bank National Association, as trustee (the “Indenture”). The 2024 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

- added (2020-02-04):
[0001633978-20-000003:note_history:44]
The initial conversion rate of the 2024 Notes is 16.4965 shares of common stock per $1,000 principal amount of 2024 Notes, which is equivalent to an initial conversion price of approximately $60.62 per share, a 132.5% premium to the fair market value at the date of issuance.

- added (2020-02-04):
[0001633978-20-000003:note_history:45]
Prior to the close of business on the business day immediately preceding December 15, 2023, each holder of the 2024 Notes may convert their 2024 Notes only under the following circumstances:

- added (2020-02-04):
[0001633978-20-000003:note_history:46]
| • | during any fiscal quarter (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during the period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price, or $78.80 on each applicable trading day; |

- added (2020-02-04):
[0001633978-20-000003:note_history:47]
| • | during the five consecutive business day period after any five consecutive trading day period (the “measurement period”) in which the trading price per $1,000 principal amount of notes for each trading day of such measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate on each such trading day; or |

- added (2020-02-04):
[0001633978-20-000003:note_history:48]
| • | upon the occurrence of specified corporate events. |

- added (2020-02-04):
[0001633978-20-000003:note_history:49]
On or after December 15, 2023 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their 2024 Notes at any time. In addition, upon the occurrence of a make-whole fundamental

- added (2020-02-04):
[0001633978-20-000003:note_history:50]
change  (as defined in the 2024 Indenture), we will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert 2024 Notes in connection with such make-whole fundamental change.

- changed (2020-02-04):
[0001633978-20-000003:note_history:51]
Prior to the Tax Matters Agreement settlement condition (“TMA settlement condition”), because we could only settle the 2024 Notes in cash, we determined that the conversion feature met the definition of a derivative liability. We separated the derivative liability from the host debt instrument based on the fair value of the derivative liability. As of the issuance date, March 8, 2017, the derivative liability fair value of $129.9 million was calculated using the binomial valuation approach. The residual principal amount of the 2024 Notes of $320.1 million before issuance costs was allocated to the debt component. We incurred approximately $7.7 million in transaction costs in connection with the issuance of the 2024 Notes. These costs were allocated to the debt component and recognized as a debt discount. We amortize the debt discount, including both the initial value of the derivative liability and the transaction costs, over the term of the 2024 Notes using the effective interest method. The effective interest rate of the 2024 Notes is 5.4% per year.
  (was, 2019-10-31, similarity 0.9619):
[0001633978-19-000071:note_history:51]
Prior to the Tax Matters Agreement settlement condition (“TMA settlement condition”), because we could only settle the 2024 Notes in cash, we determined that the conversion feature met the definition of a derivative liability. We separated the derivative liability from the host debt instrument based on the fair value of the derivative liability. As of the issuance date, March 8, 2017, the derivative liability fair value of $129.9 million was calculated using the binomial valuation approach. The residual principal amount of the 2024 Notes of $320.1 million before issuance costs was allocated to the debt component. We incurred approximately $7.7 million in transaction costs in connection with the issuance of the 2024 Notes. These costs were allocated to the debt component and recognized as a debt discount. We amortize the debt discount, including both the initial value of the derivative liability and the transaction costs, over the term of the 2024 Notes using the effective interest method. The effective interest rate of the 2024 Notes is 5.4% per year. As of September 28, 2019, the remaining debt discount amortization period was 53 months.

- changed (2020-02-04):
[0001633978-20-000003:note_history:52]
During the fiscal year ended July 1, 2017, we satisfied the TMA settlement condition. As such, the value of the conversion option will no longer be marked to market and was reclassified to additional paid-in capital within stockholders’ equity on our condensed consolidated balance sheet. The value of the conversion option at the time of issuance will be treated as an original issue discount for purposes of accounting for the debt component of the 2024 Notes. The debt component will accrete up to the principal amount over the expected term of the debt.
  (was, 2019-10-31, similarity 0.9573):
[0001633978-19-000071:note_history:52]
During the fiscal year ended July 1, 2017, we satisfied the TMA settlement condition. As such, the value of the conversion option will no longer be marked to market and was reclassified to additional paid-in capital within stockholders’ equity on our condensed consolidated balance sheet. The value of the conversion option at the time of issuance will be treated as an original issue discount for purposes of accounting for the debt component of the notes. The debt component will accrete up to the principal

- changed (2020-02-04):
[0001633978-20-000003:note_history:53]
Our convertible notes consisted of the following components as of the periods presented (in millions):
  (was, 2019-10-31, similarity 0.9072):
[0001633978-19-000071:note_history:53]
The 2024 Notes consisted of the following components as of the periods presented (in millions):

- added (2020-02-04):
[0001633978-20-000003:note_history:54]
| Liability component: | December 28, 2019 |  | June 29, 2019 |
|  | 2024 Notes |  | 2026 Notes |  | 2024 Notes |
| Principal | $ | 450.0 |  |  | $ | 1,050.0 |  |  | $ | 450.0 |  |
| Unamortized debt discount and debt issuance costs | (88.9 | ) |  | (319.1 | ) |  | (98.1 | ) |
| Net carrying amount of the liability component | $ | 361.1 |  |  | $ | 730.9 |  |  | $ | 351.9 |  |

- changed (2020-02-04):
[0001633978-20-000003:note_history:55]
The following table sets forth interest expense information related to the convertible notes for the periods presented (in millions, except percentages):
  (was, 2019-10-31, similarity 0.9595):
[0001633978-19-000071:note_history:55]
The following table sets forth interest expense information related to the 2024 Notes for the periods presented (in millions, except percentages):

- added (2020-02-04):
[0001633978-20-000003:note_history:56]
|  | Three Months Ended |  | Six Months Ended |
|  | December 28, 2019 |  | December 29, 2018 |  | December 28, 2019 |  | December 29, 2018 |
| Contractual interest expense | $ | 0.5 |  |  | $ | 0.3 |  |  | $ | 0.7 |  |  | $ | 0.6 |  |
| Amortization of the debt discount and debt issuance costs | 6.2 |  |  | 4.4 |  |  | 10.8 |  |  | 8.7 |  |
| Total interest expense | $ | 6.7 |  |  | $ | 4.7 |  |  | $ | 11.5 |  |  | $ | 9.3 |  |

- added (2020-02-04):
[0001633978-20-000003:note_history:57]
The future interest and principal payments related to our convertible notes are as follows as of December 28, 2019 (in millions):

- added (2020-02-04):
[0001633978-20-000003:note_history:58]
| Fiscal Years | 2024 Notes |  | 2026 Notes |  | Total |
| Remainder of 2020 | $ | 0.5 |  |  | $ | 2.7 |  |  | $ | 3.2 |  |
| 2021 | 1.1 |  |  | 5.2 |  |  | 6.3 |  |
| 2022 | 1.1 |  |  | 5.3 |  |  | 6.4 |  |
| 2023 | 1.1 |  |  | 5.2 |  |  | 6.3 |  |
| 2024 | 451.2 |  |  | 5.3 |  |  | 456.5 |  |
| Thereafter | — |  |  | 1,063.1 |  |  | 1,063.1 |  |
| Total convertible notes payments | $ | 455.0 |  |  | $ | 1,086.8 |  |  | $ | 1,541.8 |  |

- changed (2020-02-04):
[0001633978-20-000003:note_history:59]
In fiscal 2019, we incurred $9.3 million of debt issuance costs in connection with the Term Loan Facility which were capitalized and recorded as a contra liability in our condensed consolidated balance sheet. These costs were amortized to interest expense using the effective interest rate method from the issuance date of December 10, 2018.
  (was, 2019-10-31, similarity 0.8056):
[0001633978-19-000071:note_history:59]
We incurred $9.3 million of debt issuance costs in connection with the Term Loan Facility which were capitalized and recorded as a contra liability in our condensed consolidated balance sheet. These costs will be amortized to interest expense using the effective interest rate method from the issuance date of December 10, 2018, through the end of the term of the loan. As of September 28, 2019, the effective interest rate was 4.88% and the stated interest rate was 4.61%.

- added (2020-02-04):
[0001633978-20-000003:note_history:60]
In the second quarter of fiscal 2020, we repaid, in full, all amounts outstanding under our Term Loan Facility. We incurred $8.0 million loss for the unamortized debt issuance costs as a result of this full repayment.

- changed (2020-02-04):
[0001633978-20-000003:note_history:61]
The following table sets forth interest expense information related to the term loan for the periods presented (in millions):
  (was, 2019-10-31, similarity 0.8039):
[0001633978-19-000071:note_history:61]
The following table sets forth interest expense information related to the term loan, including interest expense associated with the ticking fee, for the periods presented (in millions):

- added (2020-02-04):
[0001633978-20-000003:note_history:62]
|  | Three Months Ended |  | Six Months Ended |
|  | December 28, 2019 |  | December 29, 2018 |  | December 28, 2019 |  | December 29, 2018 |
| Contractual interest expense | $ | 3.4 |  |  | $ | 3.7 |  |  | $ | 9.6 |  |  | $ | 4.1 |  |
| Amortization of the debt issuance costs | 0.2 |  |  | 0.1 |  |  | 0.5 |  |  | 0.1 |  |
| Loss on early extinguishment of debt | 8.0 |  |  | — |  |  | 8.0 |  |  | — |  |
| Total interest expense | $ | 11.6 |  |  | $ | 3.8 |  |  | $ | 18.1 |  |  | $ | 4.2 |  |

- added (2020-02-04):
[0001633978-20-000003:note_history:63]
For the six months ended December 28, 2019, we also recorded $0.1 million interest expense related to our finance leases.

- added (2020-02-04):
[0001633978-20-000003:note_history:64]
|  | December 28, 2019 |  | June 29, 2019 |
| Principal | $ | 497.5 |  |  | $ | 500.0 |  |
| Repayment of principal | (497.5 | ) |  | (2.5 | ) |
| Unamortized value of the debt issuance costs | — |  |  | (8.5 | ) |
| Net carrying value | $ | — |  |  | $ | 489.0 |  |
| Term loan, current | $ | — |  |  | $ | 5.0 |  |
| Term loan, non-current | $ | — |  |  | $ | 484.0 |  |

- removed (2020-02-04):
[0001633978-19-000071:note_history:65]
The initial conversion rate of the 2024 Notes is 16.4965 shares of common stock per $1,000 principal amount of 2024 Notes, which is equivalent to an initial conversion price of approximately $60.62 per share, a 132.5% premium to the fair market value at the date of issuance. Prior to the close of business on the business day immediately preceding December 15, 2023, the 2024 Notes will be convertible only under the following circumstances: (1) during any fiscal quarter (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during the period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price, or $78.80 on each applicable trading day; (2) during the five consecutive business day period after any five consecutive trading day period (the “measurement period”) in which the trading price per $1,000 principal amount of notes for each trading day of such measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate on each such trading day; or (3) upon the occurrence of specified corporate events. On or after December 15, 2023 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their notes at any time. In addition, upon the occurrence of a make-whole fundamental change, we will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert 2024 Notes in connection with such make-whole fundamental change.

- removed (2020-02-04):
[0001633978-19-000071:note_history:66]
amount over the expected term of the debt. These accounting standards do not affect the actual amount we are required to repay, and the amount shown in the table below for the notes is the aggregate principal amount of the notes and does not reflect the debt discount we will be required to recognize.

- removed (2020-02-04):
[0001633978-19-000071:note_history:67]
| Liability component: | September 28, 2019 |  | June 29, 2019 |
| Principal | $ | 450.0 |  |  | $ | 450.0 |  |
| Unamortized debt discount | (93.5 | ) |  | (98.1 | ) |
| Net carrying amount of the liability component | $ | 356.5 |  |  | $ | 351.9 |  |

- removed (2020-02-04):
[0001633978-19-000071:note_history:68]
|  | Three Months Ended |
|  | September 28, 2019 |  | September 29, 2018 |
| Contractual interest expense | $ | 0.3 |  |  | $ | 0.3 |  |
| Amortization of the debt discount | 4.6 |  |  | 4.3 |  |
| Total interest expense | $ | 4.9 |  |  | $ | 4.6 |  |
| Effective interest rate on the liability component | 5.4 | % |  | 5.4 | % |

- removed (2020-02-04):
[0001633978-19-000071:note_history:69]
We have the ability and intent to settle the $450 million face value of the debt in cash. Therefore, we use the treasury stock method for calculating the dilutive impact of the debt. The 2024 Notes will have no impact to diluted earnings per share until the average price of our common stock exceeds the conversion price of $60.62.

- removed (2020-02-04):
[0001633978-19-000071:note_history:70]
On March 11, 2018, in connection with the Oclaro merger, we entered into a commitment letter with Deutsche Bank Securities Inc. and Deutsche Bank AG New York Branch (“Deutsche Bank”), pursuant to which Deutsche Bank committed to provide a senior secured term loan facility to finance the merger.

- removed (2020-02-04):
[0001633978-19-000071:note_history:71]
The term loans will mature on the seventh anniversary of the Closing Date, at which time all outstanding principal and accrued and unpaid interest on the term loans must be repaid.  Commencing on the last business day of the first full fiscal quarter after the Closing Date, the term loans will amortize in equal quarterly installments equal to 0.25% of the original principal amount of the Term Loans, with the balance payable due on December 10, 2025, the maturity date. We are required to make mandatory prepayments of the outstanding principal amount of term loans with the net cash proceeds from the disposition of certain assets and the receipt of insurance proceeds upon certain casualty and condemnation events, in each case, to the extent in excess of the certain threshold amounts and to the extent not reinvested within a specified time period. We are also required to make mandatory prepayments of the outstanding principal amount of term loans from the incurrence of certain types of indebtedness and from any excess cash flow beyond stated threshold amounts. We have the right to prepay the term loans, in whole or in part, at any time without premium or penalty, subject to certain limitations and a 1.00% soft call premium applicable during the first six months following the Closing Date.

- removed (2020-02-04):
[0001633978-19-000071:note_history:72]
The term loans bear interest at a rate equal to an applicable margin plus, at our option, either (a) a base rate equal to the highest of (i) the prime rate then in effect, (ii) the federal funds rate, plus 0.50% and (iii) an adjusted LIBOR rate determined on the basis of a one-month interest period, plus 1.0%, subject to a floor of 0.0%, or (b) an adjusted LIBOR rate, subject to a floor of 0.0%. The applicable margin with respect to the initial term loans is equal to 2.50% in the case of LIBOR rate loans and 1.50% in the case of base rate loans. The applicable margin is adjusted following the first full fiscal quarter after the Closing Date, if our

- removed (2020-02-04):
[0001633978-19-000071:note_history:73]
first lien net leverage ratio is equal to or less than 0.50:1.00, to 2.25% in the case of LIBOR rate loans and 1.25% in the case of base rate loans. During the three months ended September 28, 2019, we recorded a contractual interest expense of $6.1 million related to the term loans, which is included in interest expense in our condensed consolidated statements of operations.

- removed (2020-02-04):
[0001633978-19-000071:note_history:74]
The commitment letter with Deutsche Bank required payment of a ticking fee. During the three months ended September 29, 2018, we recorded total expenses in connection with the ticking fee of $0.4 million. This ticking fee expense was included in interest expense in our condensed consolidated statements of operations.

- removed (2020-02-04):
[0001633978-19-000071:note_history:75]
The Credit Agreement permits us to add one or more incremental term loan facilities. Incremental loans are subject to certain additional conditions, including, without limitation, obtaining additional commitments from the lenders then party to the Credit Agreement or from new lenders.

- removed (2020-02-04):
[0001633978-19-000071:note_history:76]
Our obligations under the Credit Agreement are required to be guaranteed by certain of our domestic subsidiaries meeting materiality thresholds set forth in the Credit Agreement. Such obligations, including the guaranties, are secured by substantially all of the assets of Lumentum and Lumentum’s subsidiary guarantors (other than customarily excluded assets) pursuant to a Pledge and Security Agreement, dated as of December 10, 2018, by and among Lumentum and Deutsche Bank.

- removed (2020-02-04):
[0001633978-19-000071:note_history:77]
The Credit Agreement contains customary affirmative and negative covenants, including covenants limiting the ability of Lumentum and its restricted subsidiaries to, among other things, incur debt, grant liens, undergo certain fundamental changes, make investments, make certain restricted payments, dispose of assets, and enter into transactions with affiliates, in each case, subject to limitations and exceptions set forth in the Credit Agreement. The Credit Agreement also contains customary events of default that include, among other things, certain payment defaults, cross defaults to other indebtedness, covenant defaults, change of control defaults, judgment defaults, and bankruptcy and insolvency defaults. If an event of default exists, the lenders may require the immediate payment of all obligations under the Credit Agreement, and may exercise certain other rights and remedies provided for under the Credit Agreement, the other loan documents and applicable law. As of September 28, 2019, we were in compliance with all of the covenants.

- removed (2020-02-04):
[0001633978-19-000071:note_history:78]
|  | September 28, 2019 |  | June 29, 2019 |
| Principal | $ | 497.5 |  |  | $ | 500.0 |  |
| Repayment of principal | — |  |  | (2.5 | ) |
| Unamortized value of the debt issuance costs | (8.2 | ) |  | (8.5 | ) |
| Net carrying value | $ | 489.3 |  |  | $ | 489.0 |  |
| Term loan, current | $ | 6.2 |  |  | $ | 5.0 |  |
| Term loan, non-current | $ | 483.1 |  |  | $ | 484.0 |  |

- removed (2020-02-04):
[0001633978-19-000071:note_history:79]
|  | Three Months Ended |
|  | September 28, 2019 |  | September 29, 2018 |
| Contractual interest expense | $ | 6.1 |  |  | $ | 0.4 |  |
| Amortization of the debt issuance costs | 0.3 |  |  | — |  |
| Total interest expense | $ | 6.4 |  |  | $ | 0.4 |  |


## us-gaap:DebtSecuritiesAvailableForSaleUnrealizedLossPositionFairValueTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-02-04):
[0001633978-20-000003:note_history:80]
|  | Less than 12 months |  | 12 Months or Greater |  | Total |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| December 28, 2019: |  |  |  |  |  |  |  |  |  |  |  |
| Asset-backed securities | $ | 2.3 |  |  | $ | — |  |  | $ | 0.1 |  |  | $ | — |  |  | $ | 2.4 |  |  | $ | — |  |
| Corporate debt securities | 17.3 |  |  | — |  |  | — |  |  | — |  |  | 17.3 |  |  | — |  |
| Total | $ | 19.6 |  |  | $ | — |  |  | $ | 0.1 |  |  | $ | — |  |  | $ | 19.7 |  |  | $ | — |  |
| June 29, 2019: |  |  |  |  |  |  |  |  |  |  |  |
| Asset-backed securities | $ | 4.2 |  |  | $ | — |  |  | $ | 5.9 |  |  | $ | — |  |  | $ | 10.1 |  |  | $ | — |  |
| Corporate debt securities | 9.6 |  |  | — |  |  | 35.9 |  |  | (0.1 | ) |  | 45.5 |  |  | (0.1 | ) |
| Foreign government bonds | — |  |  | — |  |  | 2.1 |  |  | — |  |  | 2.1 |  |  | — |  |
| U.S. government bonds | 6.9 |  |  | — |  |  | — |  |  | — |  |  | 6.9 |  |  | — |  |
| Total | $ | 20.7 |  |  | $ | — |  |  | $ | 43.9 |  |  | $ | (0.1 | ) |  | $ | 64.6 |  |  | $ | (0.1 | ) |
  (was, 2019-10-31, similarity 0.8321):
[0001633978-19-000071:note_history:80]
|  | Less than 12 months |  | 12 Months or Greater |  | Total |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| September 28, 2019: |  |  |  |  |  |  |  |  |  |  |  |
| Commercial paper | $ | 3.8 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 3.8 |  |  | $ | — |  |
| Asset-backed securities | 0.7 |  |  | — |  |  | 2.1 |  |  | — |  |  | 2.8 |  |  | — |  |
| Corporate debt securities | 5.2 |  |  | — |  |  | 6.9 |  |  | — |  |  | 12.1 |  |  | — |  |
| Foreign government bonds | — |  |  | — |  |  | 2.2 |  |  | — |  |  | 2.2 |  |  | — |  |
| U.S. government bonds | 6.9 |  |  | — |  |  | — |  |  | — |  |  | 6.9 |  |  | — |  |
| Total | $ | 16.6 |  |  | $ | — |  |  | $ | 11.2 |  |  | $ | — |  |  | $ | 27.8 |  |  | $ | — |  |
| June 29, 2019: |  |  |  |  |  |  |  |  |  |  |  |
| Asset-backed securities | $ | 4.2 |  |  | $ | — |  |  | $ | 5.9 |  |  | $ | — |  |  | $ | 10.1 |  |  | $ | — |  |
| Corporate debt securities | 9.6 |  |  | — |  |  | 35.9 |  |  | (0.1 | ) |  | 45.5 |  |  | (0.1 | ) |
| Foreign government bonds | — |  |  | — |  |  | 2.1 |  |  | — |  |  | 2.1 |  |  | — |  |
| U.S. government bonds | 6.9 |  |  | — |  |  | — |  |  | — |  |  | 6.9 |  |  | — |  |
| Total | $ | 20.7 |  |  | $ | — |  |  | $ | 43.9 |  |  | $ | (0.1 | ) |  | $ | 64.6 |  |  | $ | (0.1 | ) |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-02-04):
[0001633978-20-000003:note_history:81]
The following table sets forth balance sheet information related to the term loan as of the periods presented (in millions):
  (was, 2019-10-31, similarity 0.996):
[0001633978-19-000071:note_history:81]
The following table sets forth balance sheet information related to the term loan as of the periods presented (in millions)

- added (2020-02-04):
[0001633978-20-000003:note_history:82]
|  | December 28, 2019 |  | June 29, 2019 |
| Principal | $ | 497.5 |  |  | $ | 500.0 |  |
| Repayment of principal | (497.5 | ) |  | (2.5 | ) |
| Unamortized value of the debt issuance costs | — |  |  | (8.5 | ) |
| Net carrying value | $ | — |  |  | $ | 489.0 |  |
| Term loan, current | $ | — |  |  | $ | 5.0 |  |
| Term loan, non-current | $ | — |  |  | $ | 484.0 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-02-04):
[0001633978-20-000003:note_history:83]
The future interest and principal payments related to our convertible notes are as follows as of December 28, 2019 (in millions):
  (was, 2019-10-31, similarity 0.9038):
[0001633978-19-000071:note_history:83]
The future interest and principal payments related to the 2024 Notes are as follows as of September 28, 2019 (in millions):

- changed (2020-02-04):
[0001633978-20-000003:note_history:84]
| Fiscal Years | 2024 Notes |  | 2026 Notes |  | Total |
| Remainder of 2020 | $ | 0.5 |  |  | $ | 2.7 |  |  | $ | 3.2 |  |
| 2021 | 1.1 |  |  | 5.2 |  |  | 6.3 |  |
| 2022 | 1.1 |  |  | 5.3 |  |  | 6.4 |  |
| 2023 | 1.1 |  |  | 5.2 |  |  | 6.3 |  |
| 2024 | 451.2 |  |  | 5.3 |  |  | 456.5 |  |
| Thereafter | — |  |  | 1,063.1 |  |  | 1,063.1 |  |
| Total convertible notes payments | $ | 455.0 |  |  | $ | 1,086.8 |  |  | $ | 1,541.8 |  |
  (was, 2019-10-31, similarity 0.6414):
[0001633978-19-000071:note_history:84]
| Fiscal Years |  |
| Remainder of 2020 | $ | 0.5 |  |
| 2021 | 1.1 |  |
| 2022 | 1.1 |  |
| 2023 | 1.1 |  |
| 2024 | 451.2 |  |
| Thereafter | — |  |
| Total 2024 Notes payments | $ | 455.0 |  |

- removed (2020-02-04):
[0001633978-19-000071:note_history:85]
The estimated future interest and principal payments related to the term loan are as follows as of September 28, 2019 (in millions):

- removed (2020-02-04):
[0001633978-19-000071:note_history:86]
| Fiscal Years |  |
| Remainder of 2020 | $ | 31.0 |  |
| 2021 | 27.6 |  |
| 2022 | 27.3 |  |
| 2023 | 27.1 |  |
| 2024 | 26.9 |  |
| Thereafter | 497.1 |  |
| Total term loan payments | $ | 637.0 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2020-02-04):
[0001633978-19-000071:note_history:87]
Note 19. Subsequent Event

- removed (2020-02-04):
[0001633978-19-000071:note_history:88]
On October 30, 2019, we made a voluntary pre-payment of principal amount under our term loan facility of $150.0 million. As a result of the early payment of the term loan, we will recognize a loss on early extinguishment of debt of approximately $2.5 million in our second quarter of fiscal 2020, which will be recorded in our interest expense.
