# LITE MD&A — 0001633978-20-000003


## mdna

[0001633978-20-000003:mdna:1]
[same as prior period, unchanged from 0001633978-19-000071:mdna:1]

[0001633978-20-000003:mdna:2]
[same as prior period, unchanged from 0001633978-19-000071:mdna:2]

[0001633978-20-000003:mdna:3]
[same as prior period, unchanged from 0001633978-19-000071:mdna:3]

[0001633978-20-000003:mdna:4]
[same as prior period, unchanged from 0001633978-19-000071:mdna:26]

[0001633978-20-000003:mdna:5]
[same as prior period, unchanged from 0001633978-19-000071:mdna:4]

[0001633978-20-000003:mdna:6]
[same as prior period, unchanged from 0001633978-19-000071:mdna:5]

[0001633978-20-000003:mdna:7]
We believe the world is becoming more reliant on ever-increasing amounts of data flowing through optical networks and data centers, which demand new networks and data centers to be built to satisfy this insatiable demand for data. As higher levels of precision, new materials, factory and energy efficiency are being demanded by manufacturers, suppliers of manufacturing tools globally are turning more and more to laser based approaches, including the types of lasers Lumentum supplies. Laser based 3D sensing is a rapidly developing market. The technology enables computer vision applications that enhance security, safety, and new functionality in the electronic devices that people rely on every day. We believe the global markets in which Lumentum participates have fundamentally robust, long-term trends that increase the need for our photonics products and technologies.

[0001633978-20-000003:mdna:8]
On December 10, 2018, we completed the acquisition of Oclaro, a provider of optical components and modules for the long-haul, metro and data center markets. The total transaction consideration was $1.4 billion, which was funded through the issuance of Lumentum common stock, new debt (refer to “Note 12. Debt”), and cash balances of the combined company. Refer to “Note 4. Business Combinations” in the notes to condensed consolidated financial statements for further discussion of the merger.

[0001633978-20-000003:mdna:9]
Following the acquisition of Oclaro, during our fiscal 2019, we began making several strategic changes to our OpComms business as follows:

[0001633978-20-000003:mdna:10]
•First, for overlapping products as a result of the acquisition, we are transitioning to a common lower cost design and manufacturing platform, which we expect will result in gross margin improvement over time. In addition, we have been continually reducing redundant expenses as we integrate Oclaro’s operations into those of Lumentum, which is contributed to gross margin and operating margin improvements since the acquisition close.

[0001633978-20-000003:mdna:11]
•Second, we announced our plan to discontinue certain Telecom product lines, notably Lithium Niobate modulators, that we believe have muted growth and profitability trends that are inconsistent with our long-term model. We expect that these transitions will be completed in our fiscal 2021. For the Telecom product lines we are exiting, we are continuing to sell these products to our customers in fiscal 2020 but volumes will ramp down in the second half of the year. In the second quarter of fiscal year 2020, we entered into an agreement with Advanced Fiber Resources (Zhuhai) Ltd. ("AFR"), a leading provider of passive optical components, whereby AFR will acquire the assets associated with certain Lithium Niobate product lines manufactured by our San Donato site for $17 million. The transaction was closed in the third quarter of fiscal year 2020. For further information regarding this transaction, refer to “Note 5. Assets and Liabilities Held For Sale” in the notes to condensed consolidated financial statements. Development and manufacturing will also be discontinued in our San Jose, California manufacturing locations within the next few quarters in order to facilitate our customers’ transition to new products. We expect our Indium Phosphide photonic integrated circuits will continue to replace Lithium Niobate modulators over time.

[0001633978-20-000003:mdna:12]
•Third, we announced we are discontinuing our Datacom transceiver module product lines also due to muted growth and profitability trends, inconsistent with our long-term model.  Related to this, we sold many of our Datacom transceiver module product lines to Cambridge Industries Group (“CIG”).  This transaction closed on April 18, 2019. For further information regarding this transaction, refer to “Note 4. Business Combinations” in the notes to condensed consolidated financial statements. We expect Datacom transceiver modules sales to ramp down to zero during fiscal year 2020. We are investing in new Datacom chip development and expect sales of these chips to customers serving the Datacom and 5G wireless markets will grow over time. With the exit from the business of selling Datacom transceiver modules in fiscal 2019, we recorded an impairment charge to our long-lived assets that were not deemed to be useful, as they were retired from active use and classified as held-for-sale for $4.9 million on our balance sheet.

[0001633978-20-000003:mdna:13]
[same as prior period, unchanged from 0001633978-19-000071:mdna:12]

[0001633978-20-000003:mdna:14]
[same as prior period, unchanged from 0001633978-19-000071:mdna:13]

[0001633978-20-000003:mdna:15]
[same as prior period, unchanged from 0001633978-19-000071:mdna:14]

[0001633978-20-000003:mdna:16]
[same as prior period, unchanged from 0001633978-19-000071:mdna:15]

[0001633978-20-000003:mdna:17]
[same as prior period, unchanged from 0001633978-19-000071:mdna:16]

[0001633978-20-000003:mdna:18]
[same as prior period, unchanged from 0001633978-19-000071:mdna:17]

[0001633978-20-000003:mdna:19]
[same as prior period, unchanged from 0001633978-19-000071:mdna:18]

[0001633978-20-000003:mdna:20]
[same as prior period, unchanged from 0001633978-19-000071:mdna:19]

[0001633978-20-000003:mdna:21]
Except for the adoption of ASU 2016-02, Leases (Topic 842) and the resulting changes in our accounting policies and disclosures for lease accounting, there have been no significant changes to our significant accounting policies as of and for the three months ended December 28, 2019, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the year ended June 29, 2019. Refer to “Note 1. Description of Business and Summary of Significant Accounting Policies” for the details of ASU 2016-02 (Topic 842) adoption. Management’s Discussion and Analysis of Financial Condition and Results of Operations contained in Part II, Item 7 of our Annual Report on Form 10-K for our fiscal year ended June 29, 2019 provides a more complete discussion of our critical accounting policies and estimates.

[0001633978-20-000003:mdna:22]
Recently Issued Accounting Pronouncements

[0001633978-20-000003:mdna:23]
Refer to “Note 2. Recently Issued Accounting Pronouncements” in the notes to condensed consolidated financial statements.

[0001633978-20-000003:mdna:24]
[same as prior period, unchanged from 0001633978-19-000071:mdna:23]

[0001633978-20-000003:mdna:25]
[same as prior period, unchanged from 0001633978-19-000071:mdna:24]

[0001633978-20-000003:mdna:26]
|  | Three Months Ended |  | Six Months Ended |
|  | December 28, 2019 |  | December 29, 2018 |  | December 28, 2019 |  | December 29, 2018 |
| Segment net revenue: |  |  |  |  |  |  |  |
| OpComms | 89.4 | % |  | 87.1 | % |  | 90.9 | % |  | 87.3 | % |
| Lasers | 10.6 |  |  | 12.9 |  |  | 9.1 |  |  | 12.7 |  |
| Net revenue | 100.0 |  |  | 100.0 |  |  | 100.0 |  |  | 100.0 |  |
| Cost of sales | 56.0 |  |  | 65.4 |  |  | 57.9 |  |  | 64.8 |  |
| Amortization of acquired developed technologies | 2.7 |  |  | 1.2 |  |  | 2.7 |  |  | 0.7 |  |
| Gross profit | 41.3 |  |  | 33.4 |  |  | 39.3 |  |  | 34.5 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 11.1 |  |  | 11.5 |  |  | 11.1 |  |  | 10.6 |  |
| Selling, general and administrative | 13.6 |  |  | 16.8 |  |  | 13.1 |  |  | 13.1 |  |
| Restructuring and related charges | 0.2 |  |  | 2.1 |  |  | 0.2 |  |  | 1.3 |  |
| Total operating expenses | 25.0 |  |  | 30.3 |  |  | 24.5 |  |  | 25.0 |  |
| Income from operations | 16.3 |  |  | 3.1 |  |  | 14.8 |  |  | 9.4 |  |
| Unrealized gain on derivative liability | — |  |  | 2.9 |  |  | — |  |  | 1.2 |  |
| Interest expense | (4.0 | ) |  | (2.3 | ) |  | (3.3 | ) |  | (1.9 | ) |
| Other income (expense), net | 0.3 |  |  | 1.0 |  |  | 0.7 |  |  | 0.9 |  |
| Income before income taxes | 12.6 |  |  | 4.7 |  |  | 12.2 |  |  | 9.7 |  |
| Provision for income taxes | 1.9 |  |  | 0.4 |  |  | 1.6 |  |  | 0.9 |  |
| Net income | 10.7 | % |  | 4.4 | % |  | 10.7 | % |  | 8.8 | % |

[0001633978-20-000003:mdna:27]
42

[0001633978-20-000003:mdna:28]
Financial Data for the three and six months ended December 28, 2019 and December 29, 2018

[0001633978-20-000003:mdna:29]
[same as prior period, unchanged from 0001633978-19-000071:mdna:28]

[0001633978-20-000003:mdna:30]
|  | Three Months Ended |  |  |  |  |  | Six Months Ended |  |  |  |  |
|  | December 28, 2019 |  | December 29, 2018 |  | Change |  | Percentage Change |  | December 28, 2019 |  | December 29, 2018 |  | Change |  | Percentage Change |
| Segment net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| OpComms | $ | 409.4 |  |  | $ | 325.4 |  |  | $ | 84.0 |  |  | 25.8 | % |  | $ | 825.5 |  |  | $ | 635.5 |  |  | $ | 190.0 |  |  | 29.9 | % |
| Lasers | 48.4 |  |  | 48.3 |  |  | 0.1 |  |  | 0.2 |  |  | 82.2 |  |  | 92.3 |  |  | (10.1 | ) |  | (10.9 | ) |
| Net revenue | $ | 457.8 |  |  | $ | 373.7 |  |  | $ | 84.1 |  |  | 22.5 | % |  | $ | 907.7 |  |  | $ | 727.8 |  |  | $ | 179.9 |  |  | 24.7 | % |
| Gross profit | $ | 189.1 |  |  | $ | 124.8 |  |  | $ | 64.3 |  |  | 51.5 | % |  | $ | 356.8 |  |  | $ | 250.8 |  |  | $ | 106.0 |  |  | 42.3 | % |
| Gross margin | 41.3 | % |  | 33.4 | % |  |  |  |  |  | 39.3 | % |  | 34.5 | % |  |  |  |  |
| Research and development | $ | 51.0 |  |  | $ | 42.8 |  |  | $ | 8.2 |  |  | 19.2 | % |  | $ | 100.9 |  |  | $ | 77.4 |  |  | $ | 23.5 |  |  | 30.4 | % |
| Percentage of net revenue | 11.1 | % |  | 11.5 | % |  |  |  |  |  | 11.1 | % |  | 10.6 | % |  |  |  |  |
| Selling, general and administrative | $ | 62.4 |  |  | $ | 62.7 |  |  | $ | (0.3 | ) |  | (0.5 | )% |  | $ | 119.1 |  |  | $ | 95.7 |  |  | $ | 23.4 |  |  | 24.5 | % |
| Percentage of net revenue | 13.6 | % |  | 16.8 | % |  |  |  |  |  | 13.1 | % |  | 13.1 | % |  |  |  |  |
| Restructuring and related charges | $ | 0.9 |  |  | $ | 7.8 |  |  | $ | (6.9 | ) |  | (88.5 | )% |  | $ | 2.2 |  |  | $ | 9.1 |  |  | $ | (6.9 | ) |  | (75.8 | )% |
| Percentage of net revenue | 0.2 | % |  | 2.1 | % |  |  |  |  |  | 0.2 | % |  | 1.3 | % |  |  |  |  |

[0001633978-20-000003:mdna:31]
[same as prior period, unchanged from 0001633978-19-000071:mdna:30]

[0001633978-20-000003:mdna:32]
Net revenue increased by $84.1 million, or 22.5%, during the three months ended December 28, 2019 compared to the three months ended December 29, 2018. This increase was primarily due to the acquisition of Oclaro in the second quarter of fiscal 2019, as well as increased sales in our Consumer and Industrial business.

[0001633978-20-000003:mdna:33]
OpComms net revenue increased by $84.0 million, or 25.8%, during the three months ended December 28, 2019 compared to the three months ended December 29, 2018, primarily driven by increased sales of Telecom and Datacom products of $60.4 million due to the acquisition of Oclaro, and Consumer and Industrial products of $23.6 million.

[0001633978-20-000003:mdna:34]
Lasers net revenue remained approximately flat during the three months ended December 28, 2019 compared to the three months ended December 29, 2018. Higher service revenue during the three months ended December 28, 2019 was offset by lower revenue from kilowatt class fiber lasers.

[0001633978-20-000003:mdna:35]
Net revenue increased by $179.9 million, or 24.7%, during the six months ended December 28, 2019 compared to the six months ended December 29, 2018. This increase was primarily due to increased sales in Telecom products, driven by the acquisition of Oclaro, as well as increased sales in 3D sensing products.  These increases were offset by lower sales of Datacom products primarily due to the sale of our Datacom transceiver module business in the fourth quarter of fiscal year 2019.

[0001633978-20-000003:mdna:36]
OpComms net revenue increased by $190.0 million, or 29.9%, during the six months ended December 28, 2019 compared to the six months ended December 29, 2018. This increase was primarily due to increased sales in Telecom products, driven by the acquisition of Oclaro, as well as increased sales in 3D sensing products. These increases were offset by lower sales of Datacom products due to the sale of our Datacom transceiver module business in the fourth quarter of fiscal year 2019.

[0001633978-20-000003:mdna:37]
Lasers net revenue decreased by $10.1 million, or 10.9%, during the six months ended December 28, 2019 compared to the six months ended December 29, 2018, primarily due to decreased sales of our kilowatt class fiber lasers.

[0001633978-20-000003:mdna:38]
During the three and six months ended December 28, 2019, our net revenue was concentrated with two customers, who collectively accounted for 41% and 44% of our total net revenue, respectively.

[0001633978-20-000003:mdna:39]
During the three and six months ended December 29, 2018, our net revenue was concentrated with three customers, who collectively accounted for 55% and 57% of our total net revenue, respectively.

[0001633978-20-000003:mdna:40]
[same as prior period, unchanged from 0001633978-19-000071:mdna:35]

[0001633978-20-000003:mdna:41]
[same as prior period, unchanged from 0001633978-19-000071:mdna:36]

[0001633978-20-000003:mdna:42]
|  | Three Months Ended |  | Six Months Ended |
|  | December 28, 2019 |  | December 29, 2018 |  | December 28, 2019 |  | December 29, 2018 |
|  | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States | $ | 43.4 |  |  | 9.5 | % |  | $ | 20.7 |  |  | 5.6 | % |  | $ | 80.3 |  |  | 8.8 | % |  | $ | 42.6 |  |  | 5.9 | % |
| Mexico | 26.2 |  |  | 5.7 |  |  | 55.0 |  |  | 14.7 |  |  | 55.1 |  |  | 6.1 |  |  | 111.3 |  |  | 15.3 |  |
| Other Americas | 0.7 |  |  | 0.2 |  |  | 0.9 |  |  | 0.2 |  |  | 1.8 |  |  | 0.2 |  |  | 1.8 |  |  | 0.2 |  |
| Total Americas | $ | 70.3 |  |  | 15.4 | % |  | $ | 76.6 |  |  | 20.5 | % |  | $ | 137.2 |  |  | 15.1 | % |  | $ | 155.7 |  |  | 21.4 | % |
| Asia-Pacific: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Hong Kong | $ | 144.5 |  |  | 31.6 | % |  | $ | 99.9 |  |  | 26.7 | % |  | $ | 278.3 |  |  | 30.7 | % |  | $ | 165.5 |  |  | 22.7 | % |
| South Korea | 85.0 |  |  | 18.6 |  |  | 61.3 |  |  | 16.4 |  |  | 176.6 |  |  | 19.5 |  |  | 131.3 |  |  | 18.0 |  |
| Japan | 42.1 |  |  | 9.2 |  |  | 43.2 |  |  | 11.6 |  |  | 74.6 |  |  | 8.2 |  |  | 79.2 |  |  | 10.9 |  |
| Other Asia-Pacific | 78.8 |  |  | 17.2 |  |  | 61.8 |  |  | 16.5 |  |  | 171.6 |  |  | 18.9 |  |  | 136.0 |  |  | 18.7 |  |
| Total Asia-Pacific | $ | 350.4 |  |  | 76.6 | % |  | $ | 266.2 |  |  | 71.2 | % |  | $ | 701.1 |  |  | 77.3 | % |  | $ | 512.0 |  |  | 70.3 | % |
| EMEA | $ | 37.1 |  |  | 8.0 | % |  | $ | 30.9 |  |  | 8.3 | % |  | $ | 69.4 |  |  | 7.6 | % |  | $ | 60.1 |  |  | 8.3 | % |
| Total net revenue | $ | 457.8 |  |  |  |  |  | $ | 373.7 |  |  |  |  |  | $ | 907.7 |  |  |  |  |  | $ | 727.8 |  |  |  |  |

[0001633978-20-000003:mdna:43]
For the three and six months ended December 28, 2019, net revenue from customers outside the United States, based on customer shipping location, represented 90.5% and 91.2% of net revenue, respectively. Our net revenue from Hong Kong grew due to increased sales of our 3D sensing products for mobile devices shipped to one of our large customers.

[0001633978-20-000003:mdna:44]
For the three and six months ended December 29, 2018, net revenue from customers outside the United States, based on customer shipping location, represented 94.4% and 94.1% of net revenue, respectively. Our net revenue from Hong Kong grew due to increased sales of our 3D sensing products for mobile devices shipped to one of our large customers.

[0001633978-20-000003:mdna:45]
[same as prior period, unchanged from 0001633978-19-000071:mdna:39]

[0001633978-20-000003:mdna:46]
[same as prior period, unchanged from 0001633978-19-000071:mdna:41]

[0001633978-20-000003:mdna:47]
The following table summarizes segment gross margin for the three and six months ended December 28, 2019 and December 29, 2018 (in millions, except for percentages):

[0001633978-20-000003:mdna:48]
|  | Three Months Ended |  | Six Months Ended |
|  | Gross Profit |  | Gross Margin |  | Gross Profit |  | Gross Margin |
|  | December 28, 2019 |  | December 29, 2018 |  | December 28, 2019 |  | December 29, 2018 |  | December 28, 2019 |  | December 29, 2018 |  | December 28, 2019 |  | December 29, 2018 |
| OpComms | $ | 196.4 |  |  | $ | 129.1 |  |  | 48.0 | % |  | 39.7 | % |  | $ | 388.3 |  |  | $ | 254.0 |  |  | 47.0 | % |  | 40.0 | % |
| Lasers | 20.4 |  |  | 20.6 |  |  | 42.1 | % |  | 42.7 | % |  | 34.6 |  |  | 38.3 |  |  | 42.1 | % |  | 41.5 | % |
| Segment total | $ | 216.8 |  |  | $ | 149.7 |  |  | 47.4 | % |  | 40.1 | % |  | $ | 422.9 |  |  | $ | 292.3 |  |  | 46.6 | % |  | 40.2 | % |
| Unallocated corporate items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation | (4.1 | ) |  | (5.2 | ) |  |  |  |  |  | (8.3 | ) |  | (8.5 | ) |  |  |  |  |
| Amortization of acquired intangibles | (12.4 | ) |  | (4.4 | ) |  |  |  |  |  | (24.9 | ) |  | (5.2 | ) |  |  |  |  |
| Amortization of fair value adjustments | (2.1 | ) |  | (1.3 | ) |  |  |  |  |  | (4.3 | ) |  | (1.3 | ) |  |  |  |  |
| Inventory write down and fixed asset impairment due to product lines exit | (2.6 | ) |  | — |  |  |  |  |  |  | (3.7 | ) |  | — |  |  |  |  |  |
| Integration related costs | — |  |  | — |  |  |  |  |  |  | (3.4 | ) |  | — |  |  |  |  |  |
| Other charges (1) | (6.5 | ) |  | (14.0 | ) |  |  |  |  |  | (21.5 | ) |  | (26.5 | ) |  |  |  |  |
| Total | $ | 189.1 |  |  | $ | 124.8 |  |  | 41.3 | % |  | 33.4 | % |  | $ | 356.8 |  |  | $ | 250.8 |  |  | 39.3 | % |  | 34.5 | % |

[0001633978-20-000003:mdna:49]
(1) “Other charges” of unallocated corporate items for the three and six months ended December 28, 2019 primarily include costs of transferring product lines to new production facilities, including Thailand of $2.0 million and $8.1 million, respectively. We also incurred excess and obsolete inventory charges driven by the decline in demand from Huawei of $6.0 million and $12.7 million during the three and six months ended December 28, 2019. During the three and six months ended December 29, 2018, “other charges” of unallocated corporate items including costs of transferring product lines to Thailand of $14.5 million and $27.2 million, respectively.

[0001633978-20-000003:mdna:50]
[same as prior period, unchanged from 0001633978-19-000071:mdna:45]

[0001633978-20-000003:mdna:51]
[same as prior period, unchanged from 0001633978-19-000071:mdna:46]

[0001633978-20-000003:mdna:52]
Gross margin for the three months ended December 28, 2019 increased to 41.3% from 33.4% for the three months ended December 29, 2018. The increase was primarily driven by better gross margins within Telecom, better gross margins within Datacom, due to the sale of our Datacom transceiver module business, and better gross margins within 3D sensing products.

[0001633978-20-000003:mdna:53]
Gross margin for the six months ended December 28, 2019 increased to 39.3% from 34.5% for the six months ended December 29, 2018. The increase was primarily driven by better gross margins within Telecom, due to the acquisition of Oclaro, and better gross margins within Datacom, due to the sale of our Datacom transceiver module business.

[0001633978-20-000003:mdna:54]
[same as prior period, unchanged from 0001633978-19-000071:mdna:48]

[0001633978-20-000003:mdna:55]
[same as prior period, unchanged from 0001633978-19-000071:mdna:49]

[0001633978-20-000003:mdna:56]
[same as prior period, unchanged from 0001633978-19-000071:mdna:50]

[0001633978-20-000003:mdna:57]
OpComms gross margin for the three months ended December 28, 2019 increased to 48.0% from 39.7% for the three months ended December 29, 2018. The increase was primarily driven by better gross margins within Telecom, better gross margins within Datacom, due to the sale of our Datacom transceiver module business, and better gross margins within 3D sensing products.

[0001633978-20-000003:mdna:58]
OpComms gross margin for the six months ended December 28, 2019 increased to 47.0% from 40.0% for the six months ended December 29, 2018. The increase was primarily driven by better gross margins within Telecom, due to the acquisition of Oclaro, and better gross margins within Datacom, due to the sale of our Datacom transceiver module business.

[0001633978-20-000003:mdna:59]
[same as prior period, unchanged from 0001633978-19-000071:mdna:52]

[0001633978-20-000003:mdna:60]
Lasers gross margin for the three months ended December 28, 2019 decreased to 42.1% from 42.7% for the three months ended December 29, 2018. This decrease was primarily driven by timing of inventory builds for kilowatt Fiber lasers.  We brought our production in house over the past year, and therefore the cost fluctuates depending on the inventory production levels.

[0001633978-20-000003:mdna:61]
Lasers gross margin for the six months ended December 28, 2019 increased to 42.1% from 41.5% for the six months ended December 29, 2018. This increase was primarily driven by the streamlining of our manufacturing supply chain related to our kilowatt class fiber products.

[0001633978-20-000003:mdna:62]
[same as prior period, unchanged from 0001633978-19-000071:mdna:54]

[0001633978-20-000003:mdna:63]
R&D expense increased by $8.2 million, or 19.2%, for the three months ended December 28, 2019 compared to the three months ended December 29, 2018. The increase in R&D expense was primarily due to the increase in payroll related expense of $4.6 million attributable to the acquisition of Oclaro, partially offset by the sale of our Datacom transceiver module business. In addition, we saw an increase of $5.1 million in investments in key product lines and R&D materials, offset by $2.3 million of higher non-recurring engineering credits from customers.

[0001633978-20-000003:mdna:64]
R&D expense increased by $23.5 million, or 30.4%, for the six months ended December 28, 2019 compared to the six months ended December 29, 2018. The increase in R&D expense was primarily due to the increase of $11.8 million in investments in key product lines and R&D materials. In addition, payroll related expense increased $10.6 million due to the acquisition of Oclaro, partially offset by the sale of our Datacom transceiver module business.

[0001633978-20-000003:mdna:65]
[same as prior period, unchanged from 0001633978-19-000071:mdna:56]

[0001633978-20-000003:mdna:66]
[same as prior period, unchanged from 0001633978-19-000071:mdna:57]

[0001633978-20-000003:mdna:67]
SG&A expense decreased by $0.3 million, or 0.5%, during the three months ended December 28, 2019 compared to the three months ended December 29, 2018. As a result of the acquisition of Oclaro, during the three months ended December 29, 2018, we recorded $13.3 million in charges related to the acceleration of equity awards under certain Oclaro executive severance and retention agreements and $9.0 million related to the success fee on the closing of the Oclaro transaction. During the three months ended December 28, 2019, these charges were offset by $4.0 million higher payroll related expense, integration related costs of $2.9 million, and amortization of intangibles of $6.2 million, all attributable to the acquisition of Oclaro. Other professional fees increased by $5.2 million and stock-based compensation expense increased by $4.5 million.

[0001633978-20-000003:mdna:68]
SG&A expense increased by $23.4 million, or 24.5%, during the six months ended December 28, 2019 compared to the six months ended December 29, 2018. As a result of the acquisition of Oclaro, during the six months ended December 29, 2018, we recorded $13.3 million in charges related to the acceleration of equity awards under certain Oclaro executive severance and retention agreements and $9.0 million related to the success fee on the closing of the Oclaro transaction. During the six months ended December 28, 2019, these charges were offset by $2.8 million higher stock-based compensation of Oclaro assumed grants, integration related costs of $6.1 million, and amortization of intangibles of $12.5 million, all attributable to the acquisition of Oclaro. We also incurred $10.2 million higher other professional fees and $7.8 million higher payroll related expense.

[0001633978-20-000003:mdna:69]
From time to time, we expect to incur non-core expenses, such as mergers and acquisition-related expenses and litigation expenses, which will likely increase our SG&A expenses and potentially impact our profitability expectations in any particular quarter.

[0001633978-20-000003:mdna:70]
[same as prior period, unchanged from 0001633978-19-000071:mdna:60]

[0001633978-20-000003:mdna:71]
[same as prior period, unchanged from 0001633978-19-000071:mdna:61]

[0001633978-20-000003:mdna:72]
During the three and six months ended December 28, 2019, we recorded $0.9 million and $2.2 million, respectively, in restructuring and related charges in our condensed consolidated statements of operations. The charges were mainly attributable to severance charges associated with ongoing acquisition related synergies.

[0001633978-20-000003:mdna:73]
During the three and six months ended December 29, 2018, we recorded $7.8 million and $9.1 million, respectively, in restructuring and related charges in our condensed consolidated statements of operations, primarily attributable to severance and employee related benefits associated with Oclaro’s executive severance and retention agreements. These retention agreements provided, under certain circumstances, for payments and benefits upon an involuntary termination of employment. We made $5.7 million of payments in connection with these agreements during the three and six months ended December 29, 2018. We also implemented an internal reorganization during the first quarter of fiscal 2019 in order to extend our market leadership position by strengthening product quality, to develop new enabling technologies required to support a long-term portfolio roadmap, and to develop commercial proposals and new product introduction priorities to maintain and grow our position while driving new customer and ecosystem partner engagements. In connection with this reorganization, we recorded restructuring and related charges of $1.3 million related to severance and employee related benefits during the three and six months ended December 29, 2018.

[0001633978-20-000003:mdna:74]
[same as prior period, unchanged from 0001633978-19-000071:mdna:65]

[0001633978-20-000003:mdna:75]
[same as prior period, unchanged from 0001633978-19-000071:mdna:66]

[0001633978-20-000003:mdna:76]
For the three months ended December 28, 2019 and December 29, 2018, we recorded interest expense of $18.3 million and $8.5 million, respectively. The increase in interest expense during the three months ended December 28, 2019 as compared to the three months ended December 29, 2018 was mainly driven by the loss on early extinguishment of debt of $8.0 million, which represents the write-off of the issuance costs in conjunction with payback of our term loan facility and interest expense incurred from our new 2026 notes.

[0001633978-20-000003:mdna:77]
For the six months ended December 28, 2019 and December 29, 2018, we recorded interest expense of $29.7 million and $13.6 million, respectively. The increase in interest expense during the six months ended December 28, 2019 as compared to the six months ended December 29, 2018 was mainly driven by the $8.0 million loss on early extinguishment of debt discussed above and we incurred the contractual interest expense on our term loan facility of $9.6 million in the second quarter of fiscal 2020 compared to $4.1 million in the second quarter of fiscal 2019.

[0001633978-20-000003:mdna:78]
[same as prior period, unchanged from 0001633978-19-000071:mdna:68]

[0001633978-20-000003:mdna:79]
[same as prior period, unchanged from 0001633978-19-000071:mdna:69]

[0001633978-20-000003:mdna:80]
|  | Three Months Ended |  | Six Months Ended |
|  | December 28, 2019 |  | December 29, 2018 |  | December 28, 2019 |  | December 29, 2018 |
| Foreign exchange gains (losses), net | $ | (2.1 | ) |  | $ | 0.3 |  |  | $ | (1.0 | ) |  | $ | — |  |
| Interest income | 3.4 |  |  | 3.4 |  |  | 7.4 |  |  | 6.1 |  |
| Other income (expense), net | (0.1 | ) |  | 0.1 |  |  | (0.2 | ) |  | 0.4 |  |
| Total other income (expense), net | $ | 1.2 |  |  | $ | 3.8 |  |  | $ | 6.2 |  |  | $ | 6.5 |  |

[0001633978-20-000003:mdna:81]
For the three months ended December 28, 2019, other income (expense), net decreased by $2.6 million in income as compared to the three months ended December 29, 2018, mainly driven by foreign exchange losses due to the weaker U.S. dollar.

[0001633978-20-000003:mdna:82]
For the six months ended December 28, 2019, other income (expense), net decreased by $0.3 million in income as compared to the six months ended December 29, 2018, mainly driven by foreign exchange losses due to the weaker U.S. dollar, offset by an increase in interest income on our cash equivalents and short-term investments.

[0001633978-20-000003:mdna:83]
Unrealized Gain on Derivative Liability

[0001633978-20-000003:mdna:84]
Unrealized gain on Series A Preferred Stock derivative liability was zero and $10.9 million for the three months ended December 28, 2019 and December 29, 2018, respectively, and zero and $8.8 million for the six months ended December 28, 2019 and December 29, 2018, respectively. On November 2, 2018, all 35,805 shares of our Series A Preferred Stock were converted to common stock with the outstanding balance of the embedded derivative liability reclassified to additional paid in capital. There will be no further adjustments to “unrealized gain (loss) on derivative liability” due to this conversion. For further discussion of our derivative liability, see “Note 11. Non-Controlling Interest Redeemable Convertible Preferred Stock and Derivative Liability” in the notes to condensed consolidated financial statements.

[0001633978-20-000003:mdna:85]
[same as prior period, unchanged from 0001633978-19-000071:mdna:74]

[0001633978-20-000003:mdna:86]
| (in millions) | Three Months Ended |  | Six Months Ended |
|  | December 28, 2019 |  | December 29, 2018 |  | December 28, 2019 |  | December 29, 2018 |
| Provision for income taxes | $ | 8.6 |  |  | $ | 1.4 |  |  | $ | 14.4 |  |  | $ | 6.6 |  |

[0001633978-20-000003:mdna:87]
We recorded a tax provision of $8.6 million and $1.4 million for the three months ended December 28, 2019 and December 29, 2018, respectively, and $14.4 million and $6.6 million for the six months ended December 28, 2019 and December 29, 2018, respectively. Our estimated effective tax rate for fiscal 2020 differs from the 21% U.S. statutory rate primarily due to the income tax benefit of the earnings of our foreign subsidiaries being taxed at rates that differ from the U.S. statutory rate as well as the U.S. federal R&D and foreign tax credits, partially offset by the income tax expense from non-deductible stock-based compensation and the tax effect of Global Intangible Low-Taxed Income (“GILTI”), Base Erosion and Anti-Abuse Tax (“BEAT”) and subpart F inclusion.

[0001633978-20-000003:mdna:88]
[same as prior period, unchanged from 0001633978-19-000071:mdna:77]

[0001633978-20-000003:mdna:89]
The following table summarizes our contractual obligations as of December 28, 2019, and the effect such obligations are expected to have on our liquidity and cash flow over the next five years (in millions):

[0001633978-20-000003:mdna:90]
|  | Payments due by period |
|  | Total |  | Less than 1 year |  | 1 - 3 years |  | 3 - 5 years |  | More than 5 years |
| Contractual Obligations |  |  |  |  |  |  |  |  |  |
| Acquisition contingency (1) | $ | 3.0 |  |  | $ | 3.0 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Asset retirement obligations | 4.9 |  |  | — |  |  | 0.8 |  |  | 1.9 |  |  | 2.2 |  |
| Finance lease liabilities, including imputed interest | 7.3 |  |  | 7.1 |  |  | 0.2 |  |  | — |  |  | — |  |
| Operating lease liabilities, including imputed interest (2) | 84.9 |  |  | 10.3 |  |  | 25.6 |  |  | 19.4 |  |  | 29.6 |  |
| Pension plan contributions (3) | 0.6 |  |  | 0.6 |  |  | — |  |  | — |  |  | — |  |
| Purchase obligations (4) | 289.5 |  |  | 281.8 |  |  | 7.3 |  |  | 0.4 |  |  | — |  |
| Convertible notes - principal (5) | 1,500.0 |  |  | — |  |  | — |  |  | 450.0 |  |  | 1,050.0 |  |
| Convertible notes - interest (5) | 41.8 |  |  | 6.4 |  |  | 12.7 |  |  | 12.2 |  |  | 10.5 |  |
| Total | $ | 1,932.0 |  |  | $ | 309.2 |  |  | $ | 46.6 |  |  | $ | 483.9 |  |  | $ | 1,092.3 |  |

[0001633978-20-000003:mdna:91]
(1) Refer to “Note 7. Fair Value Measurements” in the notes to condensed consolidated financial statements.

[0001633978-20-000003:mdna:92]
(2) The amounts of operating lease liabilities in the table above do not include any sublease income amounts nor do they include payments for short-term leases or variable lease payments. As of December 28, 2019, we expect to receive sublease income of approximately $6.6 million over the next three years.

[0001633978-20-000003:mdna:93]
(3) In connection with our acquisitions of Oclaro in fiscal 2019 and Time-Bandwidth Products Inc. in fiscal 2014, we assumed defined benefit plans for Japan and Switzerland employees, respectively. The Switzerland Plan is partially funded. The Japan Plan is unfunded. The amount in the preceding table represents planned contributions to our defined benefit plans. Although additional future contributions will be required, the amount and timing of these contributions will be affected by actuarial assumptions, the

[0001633978-20-000003:mdna:94]
actual rate of returns on plan assets, the level of market interest rates, legislative changes, and the amount of voluntary contributions to the plan. Any contributions for the following fiscal year and later will depend on the value of the plan assets in the future and thus are uncertain. As such, we have not included any amounts beyond one year in the table above.

[0001633978-20-000003:mdna:95]
(4) Purchase obligations represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Refer to “Note 17. Commitments and Contingencies” in the notes to condensed consolidated financial statements.

[0001633978-20-000003:mdna:96]
(5) Includes principal and interest on our 0.25% Convertible Notes due in 2024 (the “2024 Notes”) through March 2024, and principal and interest on our 0.50% Convertible Notes due in 2026 (the “2026 Notes”) through December 2026. We have the right to redeem the 2024 Notes and the 2026 Notes in whole or in part at any time on or after March 15, 2024 and on or after December 15, 2026, respectively. Refer to “Note 12. Debt” in the notes to condensed consolidated financial statements.

[0001633978-20-000003:mdna:97]
As of December 28, 2019, our other non-current liabilities also include $19.0 million of unrecognized tax benefit for uncertain tax positions. We are unable to reliably estimate the timing of future payments related to uncertain tax positions and therefore have excluded them from the preceding table.

[0001633978-20-000003:mdna:98]
[same as prior period, unchanged from 0001633978-19-000071:mdna:87]

[0001633978-20-000003:mdna:99]
[same as prior period, unchanged from 0001633978-19-000071:mdna:88]

[0001633978-20-000003:mdna:100]
[same as prior period, unchanged from 0001633978-19-000071:mdna:89]

[0001633978-20-000003:mdna:101]
[same as prior period, unchanged from 0001633978-19-000071:mdna:90]

[0001633978-20-000003:mdna:102]
As of December 28, 2019 and June 29, 2019, our cash and cash equivalents of $1,085.0 million and $432.6 million, respectively, were largely held in the United States. The total amount of cash outside the United States as of December 28, 2019 was $66.8 million, which was primarily held by entities incorporated in Japan, the United Kingdom, the British Virgin Islands, and China. Although the cash currently held in the United States as well as the cash generated in the United States from future operations is expected to cover our normal operating requirements, a substantial amount of additional cash could be required for other purposes, such as capital expenditures to support our business and growth, including costs associated with increasing internal manufacturing capabilities, particularly in our Thailand facility, strategic transactions and partnerships, and future acquisitions. Our intent is to indefinitely reinvest funds held outside the United States, except for the funds held in the Cayman Islands, Japan and Hong Kong, and our current plans do not demonstrate a need to repatriate them to fund our domestic operations. However, if in the future, we encounter a significant need for liquidity domestically or at a particular location that we cannot fulfill through borrowings, equity offerings, or other internal or external sources, or the cost to bring back the money is insignificant from a tax perspective, we may determine that cash repatriations are necessary or desirable. Repatriation could result in additional material taxes. These factors may cause us to have an overall tax rate higher than other companies or higher than our tax rates have been in the past. If conditions warrant, we may seek to obtain additional financing through debt or equity sources. To the extent we issue additional shares, our existing stockholders may be diluted. However, any such financing may not be available on terms favorable to us, or may not be available at all.

[0001633978-20-000003:mdna:103]
As of December 28, 2019, our condensed consolidated balance of cash and cash equivalents increased by $652.4 million, to $1,085.0 million from $432.6 million as of June 29, 2019. The increase in cash and cash equivalents was mainly due to cash provided by financing activities of $344.8 million, cash provided by operating activities of $249.8 million, and cash provided by investing activities of $57.8 million during the six months ended December 28, 2019.

[0001633978-20-000003:mdna:104]
As of December 29, 2018, our consolidated balance of cash and cash equivalents decreased by $26.0 million, to $371.3 million from $397.3 million as of June 30, 2018. The decrease in cash and cash equivalents was mainly due to cash used in investing activities of $672.4 million, principally related to cash used to acquire Oclaro; partially offset by cash provided by financing activities of $487.0 million, primarily related to $491.0 million in proceeds from a term loan, net of debt issuance costs, used to fund the Oclaro acquisition, and cash provided by operating activities of $159.6 million during the six months ended December 29, 2018.

[0001633978-20-000003:mdna:105]
[same as prior period, unchanged from 0001633978-19-000071:mdna:93]

[0001633978-20-000003:mdna:106]
Cash provided by operating activities was $249.8 million during the six months ended December 28, 2019. Our net income was $96.7 million for the six months ended December 28, 2019. Cash provided by operating activities was generated primarily from $162.4 million of non-cash items (such as depreciation, stock-based compensation, amortization of intangibles, amortization

[0001633978-20-000003:mdna:107]
of debt discount and debt issuance costs on our term loans and convertible notes, and other non-cash charges), offset by $9.3 million of changes in our operating assets and liabilities. Changes in our operating assets and liabilities related primarily to an increase in accounts receivable of $54.0 million offset by a decrease in inventories of $44.3 million.

[0001633978-20-000003:mdna:108]
Cash provided by operating activities was $159.6 million during the six months ended December 29, 2018, primarily resulting from $63.7 million of net income, $83.4 million of non-cash items (such as depreciation, stock-based compensation, unrealized loss on derivative liability, amortization of intangibles, amortization of discount on the 2024 Notes, amortization of the debt issuance costs on the term loan, and amortization of the inventory fair value adjustment in connection with the acquisition of Oclaro), and $12.5 million of changes in our operating assets and liabilities. Changes in our operating assets and liabilities related primarily to an increase in accounts payable of $16.5 million, a change in income taxes, net of $5.8 million, an increase in accrued expenses and other current and non-current liabilities of $2.8 million and a decrease in inventories of $0.5 million, partially offset by an increase of prepayments and other current and non-current assets of $10.7 million, an increase of accounts receivable of $0.8 million and a decrease in accrued payroll and related expenses of $1.6 million.

[0001633978-20-000003:mdna:109]
[same as prior period, unchanged from 0001633978-19-000071:mdna:96]

[0001633978-20-000003:mdna:110]
Cash provided by investing activities of $57.8 million during the six months ended December 28, 2019 was primarily attributable to sales of short-term investments, net of purchases of $105.7 million, offset by capital expenditures of $47.4 million and payment for asset acquisition of $3.0 million.

[0001633978-20-000003:mdna:111]
Cash used in investing activities of $672.4 million during the six months ended December 29, 2018, was primarily attributable to $619.8 million in cash payments to acquire all outstanding shares of common stock of Oclaro, net of cash received through the acquisition of Oclaro. In addition we had capital expenditures of $53.9 million, partially offset by sales of short-term investments, net of purchases of $2.0 million.

[0001633978-20-000003:mdna:112]
[same as prior period, unchanged from 0001633978-19-000071:mdna:99]

[0001633978-20-000003:mdna:113]
Cash provided by financing activities of $344.8 million during the six months ended December 28, 2019 resulted primarily from the proceeds of the issuance of the 2026 Notes of $1,042.9 million, net of issuance costs, offset by the repurchase of shares of our common stock of $200.0 million and repayment of our term loan facility of $497.5 million.

[0001633978-20-000003:mdna:114]
Cash provided by financing activities of $487.0 million during the six months ended December 29, 2018 primarily resulted from $491.0 million of proceeds from a term loan, net of debt issuance costs, used to partially finance the Oclaro acquisition, and $4.7 million from the issuance of common stock under our employee stock plan; partially offset by tax payments related to restricted stock of $2.4 million, the repayment of capital lease obligations of $4.6 million, a payment of an acquisition related holdback of $1.0 million, and dividend payments on our Series A Preferred Stock of $0.7 million.

[0001633978-20-000003:mdna:115]
[same as prior period, unchanged from 0001633978-19-000071:mdna:102]

[0001633978-20-000003:mdna:116]
We believe that our cash and cash equivalents as of December 28, 2019 and cash flows from our operating activities will be sufficient to meet our liquidity and capital spending requirements for at least the next 12 months. However, if market conditions are favorable, we may evaluate alternatives to opportunistically pursue additional financing.

[0001633978-20-000003:mdna:117]
[same as prior period, unchanged from 0001633978-19-000071:mdna:104]

[0001633978-20-000003:mdna:118]
[same as prior period, unchanged from 0001633978-19-000071:mdna:105]

[0001633978-20-000003:mdna:119]
| • | fluctuations in demand for our products as a result of changes in regulations, tariffs or other trade barriers, and trade relations in general; |

[0001633978-20-000003:mdna:120]
[same as prior period, unchanged from 0001633978-19-000071:mdna:106]

[0001633978-20-000003:mdna:121]
[same as prior period, unchanged from 0001633978-19-000071:mdna:107]

[0001633978-20-000003:mdna:122]
[same as prior period, unchanged from 0001633978-19-000071:mdna:108]

[0001633978-20-000003:mdna:123]
[same as prior period, unchanged from 0001633978-19-000071:mdna:109]

[0001633978-20-000003:mdna:124]
[same as prior period, unchanged from 0001633978-19-000071:mdna:110]

[0001633978-20-000003:mdna:125]
[same as prior period, unchanged from 0001633978-19-000071:mdna:111]

[0001633978-20-000003:mdna:126]
[same as prior period, unchanged from 0001633978-19-000071:mdna:112]

[0001633978-20-000003:mdna:127]
[same as prior period, unchanged from 0001633978-19-000071:mdna:113]

[0001633978-20-000003:mdna:128]
[same as prior period, unchanged from 0001633978-19-000071:mdna:114]

[0001633978-20-000003:mdna:129]
[same as prior period, unchanged from 0001633978-19-000071:mdna:116]

[0001633978-20-000003:mdna:130]
| • | the settlement of any conversion or redemption of the 2024 Notes and the 2026 Notes in cash. |

[0001633978-20-000003:mdna:131]
51
