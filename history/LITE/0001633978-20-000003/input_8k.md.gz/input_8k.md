# LITE 8-K — 0001633978-20-000002 filed 2020-02-04

## item codes, every 8-K on or before 2020-02-04

- 2020-02-04 0001633978-20-000002 — 2.02, 9.01
- 2019-12-12 0001193125-19-312875 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2019-12-04 0001633978-19-000075 — 8.01
- 2019-11-20 0001633978-19-000074 — 5.07
- 2019-10-31 0001633978-19-000070 — 2.02, 9.01
- 2019-08-08 0001633978-19-000068 — 2.02, 9.01
- 2019-05-08 0001633978-19-000031 — 1.01
- 2019-05-07 0001633978-19-000029 — 2.02, 9.01
- 2019-02-15 0001633978-19-000005 — 9.01 — amendment of 0001193125-18-346211
- 2019-02-08 0001193125-19-031591 — 5.02, 9.01
- 2019-02-05 0001633978-19-000001 — 2.02, 9.01
- 2018-12-10 0001193125-18-346211 — 1.01, 2.01, 2.03, 5.02, 8.01, 9.01
- 2018-12-06 0001633978-18-000150 — 8.01
- 2018-11-14 0001633978-18-000139 — 5.07
- 2018-11-13 0001633978-18-000136 — 3.02
- 2018-11-13 0001633978-18-000132 — 7.01, 9.01
- 2018-11-01 0001628280-18-013238 — 2.02, 9.01
- 2018-08-08 0001633978-18-000056 — 2.02, 9.01
- 2018-06-08 0001193125-18-188241 — 5.02, 9.01
- 2018-05-02 0001633978-18-000029 — 2.02, 9.01
- 2018-03-12 0001193125-18-078154 — 1.01, 2.01, 8.01, 9.01
- 2018-02-06 0001628280-18-001082 — 2.02, 9.01
- 2017-11-08 0001633978-17-000133 — 5.02, 9.01
- 2017-11-07 0001633978-17-000131 — 5.07
- 2017-11-01 0001633978-17-000117 — 2.02, 9.01
- 2017-08-09 0001633978-17-000058 — 2.02, 9.01
- 2017-05-04 0001633978-17-000035 — 2.02, 9.01
- 2017-03-08 0001193125-17-074740 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2017-03-02 0001193125-17-066769 — 8.01, 9.01
- 2017-02-07 0001633978-17-000005 — 2.02, 9.01
- 2017-01-03 0001628280-17-000018 — 4.01, 9.01
- 2016-11-09 0001628280-16-021143 — 5.02, 5.07, 9.01
- 2016-10-27 0001628280-16-020382 — 2.02, 9.01
- 2016-08-09 0001628280-16-018811 — 2.02, 9.01
- 2016-06-21 0001628280-16-017201 — 8.01
- 2016-05-04 0001628280-16-015501 — 2.02, 9.01
- 2016-02-16 0001628280-16-011261 — 5.02, 9.01
- 2016-02-04 0001628280-16-010758 — 5.02, 9.01
- 2016-02-04 0001628280-16-010755 — 2.02, 9.01
- 2015-11-17 0001193125-15-378953 — 7.01
- 2015-11-10 0001628280-15-008606 — 2.02, 9.01
- 2015-09-28 0001193125-15-329665 — 8.01, 9.01
- 2015-08-11 0001193125-15-286405 — 7.01, 9.01
- 2015-08-06 0001193125-15-281219 — 1.01, 5.02, 5.03, 5.05, 8.01, 9.01
- 2015-08-03 0001193125-15-274808 — 5.03, 9.01

## late-filing notifications on or before 2020-02-04

- 2015-11-10 0001628280-15-008612 — NT 10-Q, for the period ended 2015-09-26
- 2015-09-28 0001193125-15-329672 — NT 10-K, for the period ended 2015-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001633978-20-000002:8k_2_02:1]
EX-99.1
2
liteex991q2fy20.htm
EXHIBIT 99.1

[0001633978-20-000002:8k_2_02:2]
Exhibit

[0001633978-20-000002:8k_2_02:3]
NEWS RELEASE

[0001633978-20-000002:8k_2_02:4]
LUMENTUM ANNOUNCES FISCAL SECOND QUARTER 2020 FINANCIAL RESULTS

[0001633978-20-000002:8k_2_02:5]
| • | Net revenue of $457.8 million |

[0001633978-20-000002:8k_2_02:6]
| • | GAAP operating margin of 16.3%; Non-GAAP operating margin of 28.8% |

[0001633978-20-000002:8k_2_02:7]
| • | GAAP diluted net income per share of $0.63; Non-GAAP diluted net income per share of $1.53 |

[0001633978-20-000002:8k_2_02:8]
San Jose, Calif., February 4, 2020 – Lumentum Holdings Inc. (“Lumentum” or the “Company”) today reported results for its fiscal second quarter of 2020 ended December 28, 2019.

[0001633978-20-000002:8k_2_02:9]
Net revenue for the fiscal second quarter of 2020 was $457.8 million, with GAAP net income of $49.1 million, or $0.63 per diluted share. Net revenue for the fiscal first quarter of 2020 was $449.9 million, with GAAP net income of $47.6 million, or $0.61 per diluted share. Net revenue for the fiscal second quarter of 2019 was $373.7 million, with GAAP net income attributable to common stockholders of $5.4 million, or $0.08 per diluted share.

[0001633978-20-000002:8k_2_02:10]
Non-GAAP net income for the fiscal second quarter of 2020 was $119.4 million, or $1.53 per diluted share.  Non-GAAP net income for the fiscal first quarter of 2020 was $111.4 million, or $1.44 per diluted share.  Non-GAAP net income for the fiscal second quarter of 2019 was $78.0 million, or $1.15 per diluted share.

[0001633978-20-000002:8k_2_02:11]
The Company held $1,315.6 million in total cash and short-term investments at the end of the fiscal second quarter of 2020.

[0001633978-20-000002:8k_2_02:12]
“The themes of the prior quarter - strong customer demand for our differentiated products, an improving financial model due to increasing levels of new and innovative products and increasing scale and acquisition synergies - drove new record revenue, gross margin and operating margin in the second quarter,” said Alan Lowe, President and CEO. “Adding to these themes in calendar year 2020, we are seeing telecom transport demand strengthening, we are ramping our DCO modules now and expect 400G and above products to ramp later in the year, and we expect a strong expansion of the market for world-facing 3D sensing lasers.”

[0001633978-20-000002:8k_2_02:13]
Financial Overview – Fiscal Second Quarter Ended December 28, 2019

[0001633978-20-000002:8k_2_02:14]
|  | GAAP Results ($ in millions) |
|  | Q2 |  | Q1 |  | Q2 |  | Change |
|  | FY 2020 |  | FY 2020 |  | FY 2019 |  | Q/Q |  | Y/Y |
| Net revenue | $457.8 |  | $449.9 |  | $373.7 |  | 1.8% |  | 22.5% |
| Gross margin | 41.3% |  | 37.3% |  | 33.4% |  | 400bps |  | 790bps |
| Operating margin | 16.3% |  | 13.3% |  | 3.1% |  | 300bps |  | 1,320bps |
|  | Non-GAAP Results ($ in millions) |
|  | Q2 |  | Q1 |  | Q2 |  | Change |
|  | FY 2020 |  | FY 2020 |  | FY 2019 |  | Q/Q |  | Y/Y |
| Net revenue | $457.8 |  | $449.9 |  | $373.7 |  | 1.8% |  | 22.5% |
| Gross margin | 47.4% |  | 45.8% |  | 40.1% |  | 160bps |  | 730bps |
| Operating margin | 28.8% |  | 27.3% |  | 22.0% |  | 150bps |  | 680bps |

[0001633978-20-000002:8k_2_02:15]
|  | Net Revenue by Segment ($ in millions) |
|  | Q2 |  | % of |  | Q1 |  | Q2 |  | Change |
|  | FY 2020 |  | Net Revenue |  | FY 2020 |  | FY 2019 |  | Q/Q |  | Y/Y |
| Optical Communications | $ | 409.4 |  |  | 89.4 | % |  | $ | 416.1 |  |  | $ | 325.4 |  |  | (1.6 | )% |  | 25.8 | % |
| Lasers | 48.4 |  |  | 10.6 | % |  | 33.8 |  |  | 48.3 |  |  | 43.2 | % |  | 0.2 | % |
| Total | $ | 457.8 |  |  | 100.0 | % |  | $ | 449.9 |  |  | $ | 373.7 |  |  | 1.8 | % |  | 22.5 | % |

[0001633978-20-000002:8k_2_02:16]
The tables above provide comparisons of quarterly results to prior periods, including sequential quarterly and year-over-year changes. A reconciliation between GAAP and non-GAAP measures is contained in this release under the section titled “Use of Non-GAAP Financial Measures.”

[0001633978-20-000002:8k_2_02:17]
Effective June 30, 2019, we adopted Topic 842, using the modified retrospective transition approach. We applied the new guidance to all leases existing as of the date of adoption. Our reported results for the first and second quarters of fiscal 2020 reflect the application of Topic 842, while fiscal 2019 amounts have not been adjusted and continue to be reported in accordance with our historical accounting under Topic 840.

[0001633978-20-000002:8k_2_02:18]
Business Outlook

[0001633978-20-000002:8k_2_02:19]
The projections we are providing today incorporate an approximate $15 million to $20 million reduction in revenue at the mid-point, and a wider than normal revenue range, due to the anticipated impact of the 2019 novel coronavirus outbreak.

[0001633978-20-000002:8k_2_02:20]
Lumentum expects the following for the fiscal third quarter 2020:

[0001633978-20-000002:8k_2_02:21]
•Net revenue in the range of $400 million to $425 million

[0001633978-20-000002:8k_2_02:22]
•Non-GAAP operating margin of 21% to 23%

[0001633978-20-000002:8k_2_02:23]
•Non-GAAP diluted earnings per share of $1.00 to $1.17

[0001633978-20-000002:8k_2_02:24]
We have not provided reconciliations from GAAP to non-GAAP measures for our outlook. A large portion of non-GAAP adjustments, such as restructuring charges, stock-based compensation, acquisition-related costs, non-cash income tax expense and credits, amortization of fair value adjustments, integration related costs, impairment charges, inventory write down due to plans to exit certain product lines and other costs and contingencies unrelated to current and future operations are by their nature highly volatile and we have low visibility as to the range that may be incurred in the future.

[0001633978-20-000002:8k_2_02:25]
Conference Call

[0001633978-20-000002:8k_2_02:26]
Lumentum will host a conference call on February 4, 2020, at 5:30 am PT/8:30 am ET. A live webcast of the call and the replay will be available on the Lumentum website at http://investor.lumentum.com through February 11, 2020, at 11:59 pm ET. To listen to the live conference call, dial (833) 287-7900 or (647) 689-4464 and reference the passcode 8884386.  A replay of the conference call will be available through February 11, 2020. To access the replay, dial (800) 585-8367 or (416) 621-4642. The passcode for the replay is 8884386. Supporting materials outlining the Company’s latest financial results will be posted on http://investor.lumentum.com under the “Events and Presentations” section concurrently with this earnings press release. This press release is being furnished as an exhibit to a Current Report on Form 8-K filed with the Securities and Exchange Commission and will be available at http://www.sec.gov/.

[0001633978-20-000002:8k_2_02:27]
About Lumentum

[0001633978-20-000002:8k_2_02:28]
Lumentum (NASDAQ: LITE) is a market-leading designer and manufacturer of innovative optical and photonic products enabling optical networking and laser applications worldwide.  Lumentum’s optical components and subsystems are part of virtually every type of telecom, enterprise, and data center network.  Lumentum’s lasers enable advanced manufacturing techniques and diverse applications including next-generation 3D sensing capabilities. Lumentum is headquartered in San Jose, California with R&D, manufacturing, and sales offices worldwide.  For more information, visit www.lumentum.com.

[0001633978-20-000002:8k_2_02:29]
Forward-Looking Statements

[0001633978-20-000002:8k_2_02:30]
markets on demand for our products; (f) changes in customer demand; (g) our ability to attract and retain new customers, particularly in the 3D sensing market; (h) the risk that synergies and non-GAAP earnings accretion related to the acquisition of Oclaro will not be realized or realized to the extent anticipated or that we will incur significant costs and charges to achieve such synergies; (i) the risk that Lumentum’s financing or operating strategies will not be successful; and (j) disruption related to the acquisition and integration of Oclaro making it more difficult to maintain customer, supplier, key personnel and other strategic relationships. For more information on these and other risks, please refer to the “Risk Factors” section included in the Company’s Quarterly Report on Form 10-Q for the fiscal quarter ended December 28, 2019 to be filed with the Securities and Exchange Commission, and in the Company’s other filings with the Securities and Exchange Commission, including the Company’s Annual Report on Form 10-K for the fiscal year ended June 29, 2019, filed by Lumentum with the Securities and Exchange Commission on August 27, 2019. The forward-looking statements and preliminary financial results contained in this press release are made as of the date hereof and the Company assumes no obligation to update such statements, except as required by applicable law.

[0001633978-20-000002:8k_2_02:31]
Contact Information

[0001633978-20-000002:8k_2_02:32]
Investors:            Jim Fanucchi, 408-404-5400; investor.relations@lumentum.com

[0001633978-20-000002:8k_2_02:33]
Media:         Sean Ogarrio, 408-404-5400; media@lumentum.com

[0001633978-20-000002:8k_2_02:34]
The following financial tables are presented in accordance with GAAP, unless otherwise specified.

[0001633978-20-000002:8k_2_02:35]
LUMENTUM HOLDINGS INC.

[0001633978-20-000002:8k_2_02:36]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001633978-20-000002:8k_2_02:37]
(in millions, except per share data)

[0001633978-20-000002:8k_2_02:38]
(unaudited)

[0001633978-20-000002:8k_2_02:39]
|  | Three Months Ended |  | Six Months Ended |
|  | December 28, 2019 |  | December 29, 2018 |  | December 28, 2019 |  | December 29, 2018 |
| Net revenue | $ | 457.8 |  |  | $ | 373.7 |  |  | $ | 907.7 |  |  | $ | 727.8 |  |
| Cost of sales | 256.3 |  |  | 244.5 |  |  | 526.0 |  |  | 471.8 |  |
| Amortization of acquired developed intangibles | 12.4 |  |  | 4.4 |  |  | 24.9 |  |  | 5.2 |  |
| Gross profit | 189.1 |  |  | 124.8 |  |  | 356.8 |  |  | 250.8 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 51.0 |  |  | 42.8 |  |  | 100.9 |  |  | 77.4 |  |
| Selling, general and administrative | 62.4 |  |  | 62.7 |  |  | 119.1 |  |  | 95.7 |  |
| Restructuring and related charges | 0.9 |  |  | 7.8 |  |  | 2.2 |  |  | 9.1 |  |
| Total operating expenses | 114.3 |  |  | 113.3 |  |  | 222.2 |  |  | 182.2 |  |
| Income from operations | 74.8 |  |  | 11.5 |  |  | 134.6 |  |  | 68.6 |  |
| Unrealized gain on derivative liability | — |  |  | 10.9 |  |  | — |  |  | 8.8 |  |
| Interest expense | (18.3 | ) |  | (8.5 | ) |  | (29.7 | ) |  | (13.6 | ) |
| Other income (expense), net | 1.2 |  |  | 3.8 |  |  | 6.2 |  |  | 6.5 |  |
| Income before income taxes | 57.7 |  |  | 17.7 |  |  | 111.1 |  |  | 70.3 |  |
| Provision for income taxes | 8.6 |  |  | 1.4 |  |  | 14.4 |  |  | 6.6 |  |
| Net income | $ | 49.1 |  |  | $ | 16.3 |  |  | $ | 96.7 |  |  | $ | 63.7 |  |
| Items reconciling net income to net income attributable to common stockholders: |  |  |  |  |  |  |  |
| Less: Cumulative dividends on Series A Preferred Stock | — |  |  | (0.1 | ) |  | — |  |  | (0.3 | ) |
| Less: Earnings allocated to Series A Preferred Stock | — |  |  | (0.1 | ) |  | — |  |  | (1.2 | ) |
| Net income attributable to common stockholders - Basic | $ | 49.1 |  |  | $ | 16.1 |  |  | $ | 96.7 |  |  | $ | 62.2 |  |
| Add: Earnings allocated to Series A Preferred Stock | — |  |  | 0.1 |  |  | — |  |  | 1.2 |  |
| Less: Unrealized gain on derivative liability on Series A Preferred Stock | — |  |  | (10.9 | ) |  | — |  |  | (8.8 | ) |
| Add: Cumulative dividends on Series A Preferred Stock | — |  |  | 0.1 |  |  | — |  |  | 0.3 |  |
| Net income attributable to common stockholders - Diluted | $ | 49.1 |  |  | $ | 5.4 |  |  | $ | 96.7 |  |  | $ | 54.9 |  |
| Net income per share attributable to common stockholders: |  |  |  |  |  |  |  |
| Basic | $ | 0.64 |  |  | $ | 0.24 |  |  | $ | 1.26 |  |  | $ | 0.96 |  |
| Diluted | $ | 0.63 |  |  | $ | 0.08 |  |  | $ | 1.24 |  |  | $ | 0.82 |  |
| Shares used to compute net income per share attributable to common stockholders: |  |  |  |  |  |  |  |
| Basic | 76.8 |  |  | 66.8 |  |  | 76.9 |  |  | 65.0 |  |
| Diluted | 78.0 |  |  | 67.8 |  |  | 77.8 |  |  | 66.6 |  |

[0001633978-20-000002:8k_2_02:40]
LUMENTUM HOLDINGS INC.

[0001633978-20-000002:8k_2_02:41]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001633978-20-000002:8k_2_02:42]
(in millions, except share and per share data)

[0001633978-20-000002:8k_2_02:43]
|  | December 28, 2019 |  | June 29, 2019 |
| ASSETS |  |  |  |  |  |
| Current assets: |  |  |  |  |  |
| Cash and cash equivalents | $ | 1,085.0 |  |  | $ | 432.6 |  |
| Short-term investments | 230.6 |  |  | 335.9 |  |
| Accounts receivable, net | 292.0 |  |  | 238.0 |  |
| Inventories | 179.6 |  |  | 228.8 |  |
| Prepayments and other current assets | 95.8 |  |  | 97.5 |  |
| Total current assets | 1,883.0 |  |  | 1,332.8 |  |
| Property, plant and equipment, net | 421.0 |  |  | 433.3 |  |
| Operating lease right-of-use assets, net | 84.7 |  |  | — |  |
| Goodwill | 368.9 |  |  | 368.9 |  |
| Other intangible assets, net | 358.0 |  |  | 395.4 |  |
| Deferred income taxes | 101.1 |  |  | 169.6 |  |
| Other non-current assets | 4.5 |  |  | 16.6 |  |
| Total assets | $ | 3,221.2 |  |  | $ | 2,716.6 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 143.7 |  |  | $ | 160.8 |  |
| Accrued payroll and related expenses | 53.7 |  |  | 42.3 |  |
| Accrued expenses | 37.2 |  |  | 46.7 |  |
| Term loan, current | — |  |  | 5.0 |  |
| Operating lease liabilities, current | 11.7 |  |  | — |  |
| Other current liabilities | 57.9 |  |  | 39.2 |  |
| Total current liabilities | 304.2 |  |  | 294.0 |  |
| Convertible notes | 1,092 |  |  | 351.9 |  |
| Term loan, non-current | — |  |  | 484.0 |  |
| Operating lease liabilities, non-current | 62.5 |  |  | — |  |
| Deferred tax liability | 47.9 |  |  | 55.9 |  |
| Other non-current liabilities | 33.0 |  |  | 33.7 |  |
| Total liabilities | 1,539.6 |  |  | 1,219.5 |  |
| Commitments and contingencies |  |  |  |
| Stockholders’ equity: |  |  |  |
| Common stock, $0.001 par value, 990,000,000 authorized shares, 74,716,401 and 76,653,478 shares issued and outstanding as of December 28, 2019 and June 29, 2019, respectively | 0.1 |  |  | 0.1 |  |
| Additional paid-in capital | 1,648.7 |  |  | 1,360.8 |  |
| Retained earnings | 25.8 |  |  | 129.1 |  |
| Accumulated other comprehensive income | 7.0 |  |  | 7.1 |  |
| Total stockholders’ equity | 1,681.6 |  |  | 1,497.1 |  |
| Total liabilities and stockholders’ equity | $ | 3,221.2 |  |  | $ | 2,716.6 |  |

[0001633978-20-000002:8k_2_02:44]
Use of Non-GAAP Financial Measures

[0001633978-20-000002:8k_2_02:45]
In this press release, Lumentum provides investors with gross margin, gross profit, research and development expense, selling, general and administrative expense, operating margin, operating income, interest and other income (expense), net, income before income taxes and certain expenses, provision for taxes, net income , and net income per share on a non-GAAP basis as well as the non-GAAP measure of Adjusted EBITDA. Lumentum believes this non-GAAP financial information provides additional insight into the Company’s on-going business operations and results, as well as cash generation and has therefore chosen to provide this information to investors for a more consistent basis of comparison and to help them evaluate the results of the Company’s on-going operations and enable more meaningful period to period comparisons. Specifically, the Company believes that providing this information allows investors to better understand the Company’s cash flows and, importantly, to evaluate the efficacy of the methodology and information used by management to evaluate and measure such cash flows. However, these measures may be different from non-GAAP measures used by other companies, limiting their usefulness for comparison purposes. The non-GAAP financial measures used in this press release should not be considered in isolation from measures of financial performance prepared in accordance with GAAP. Investors are cautioned that there are material limitations associated with the use of non-GAAP financial measures as an analytical tool. In particular, many of the adjustments to our GAAP financial measures reflect the exclusion of items that are recurring and will be reflected in our financial results for the foreseeable future. Further, these non-GAAP financial measures may not be comparable to similarly titled measurements reported by other companies.

[0001633978-20-000002:8k_2_02:46]
Non-GAAP gross margin, non-GAAP gross profit, non-GAAP expenses, non-GAAP operating margin, non-GAAP operating income, non-GAAP income before income taxes, non-GAAP net income, and non-GAAP net income per share exclude (i) stock-based compensation, (ii) inventory write-downs and fixed asset impairment due to cancelled programs, plans to exit certain lines of business and other costs and contingencies unrelated to current and future operations, (iii) acquisition related costs, (iv) integration related costs, (v) amortization of acquired intangibles, (vi) amortization of fair value adjustments, (vii) restructuring and related charges, (viii) non-cash interest expense, (ix) foreign exchange (gains) losses, net, (x) unrealized gain (loss) on derivative liability, (xi) transferring product lines to Thailand, (xii) excess and obsolete inventory charges driven by the decline in demand from Huawei, and (xiii) non-cash income tax provision impacts. The presentation of these and other similar items in Lumentum’s non-GAAP financial results should not be interpreted as implying that these items are non-recurring, infrequent or unusual.

[0001633978-20-000002:8k_2_02:47]
A quantitative reconciliation between GAAP and non-GAAP financial data with respect to historical periods is included in the supplemental financial table attached to this press release.

[0001633978-20-000002:8k_2_02:48]
LUMENTUM HOLDINGS INC.

[0001633978-20-000002:8k_2_02:49]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001633978-20-000002:8k_2_02:50]
(in millions, except per share data)

[0001633978-20-000002:8k_2_02:51]
(unaudited)

[0001633978-20-000002:8k_2_02:52]
|  | Three Months Ended |  | Six Months Ended |  |
|  | December 28, 2019 |  | September 28, 2019 |  | December 29, 2018 |  | December 28, 2019 |  | December 29, 2018 |  |
| Gross profit on GAAP basis | $ | 189.1 |  |  | $ | 167.7 |  |  | $ | 124.8 |  |  | $ | 356.8 |  |  | $ | 250.8 |  |  |
| Stock-based compensation | 4.1 |  |  | 4.2 |  |  | 5.2 |  |  | 8.3 |  |  | 8.5 |  |  |
| Inventory write down and fixed asset impairment due to product lines exit (3) | 2.6 |  |  | 1.1 |  |  | — |  |  | 3.7 |  |  | — |  |  |
| Integration related costs | — |  |  | 3.4 |  |  | — |  |  | 3.4 |  |  | — |  |  |
| Amortization of acquired intangibles | 12.4 |  |  | 12.5 |  |  | 4.4 |  |  | 24.9 |  |  | 5.2 |  |  |
| Amortization of fair value adjustments (2) | 2.1 |  |  | 2.2 |  |  | 1.3 |  |  | 4.3 |  |  | 1.3 |  |  |
| Other charges (1) | 6.5 |  |  | 15.0 |  |  | 14.0 |  |  | 21.5 |  |  | 26.5 |  |  |
| Gross profit on non-GAAP basis | $ | 216.8 |  |  | $ | 206.1 |  |  | $ | 149.7 |  |  | $ | 422.9 |  |  | $ | 292.3 |  |  |
| Gross margin on non-GAAP basis | 47.4 | % |  | 45.8 | % |  | 40.1 | % |  | 46.6 | % |  | 40.2 | % |  |
| Research and development on GAAP basis | $ | 51.0 |  |  | $ | 49.9 |  |  | $ | 42.8 |  |  | $ | 100.9 |  |  | $ | 77.4 |  |  |
| Stock-based compensation | (4.1 | ) |  | (3.8 | ) |  | (3.4 | ) |  | (7.9 | ) |  | (6.2 | ) |  |
| Other charges | (0.1 | ) |  | 0.2 |  |  | (0.1 | ) |  | 0.1 |  |  | (0.3 | ) |  |
| Research and development on non-GAAP basis | $ | 46.8 |  |  | $ | 46.3 |  |  | $ | 39.3 |  |  | $ | 93.1 |  |  | $ | 70.9 |  |  |
| Selling, general and administrative on GAAP basis | $ | 62.4 |  |  | $ | 56.7 |  |  | $ | 62.7 |  |  | $ | 119.1 |  |  | $ | 95.7 |  |  |
| Stock-based compensation | (12.0 | ) |  | (8.7 | ) |  | (21.1 | ) |  | (20.7 | ) |  | (25.8 | ) |  |
| Acquisition related costs | — |  |  | — |  |  | (12.0 | ) |  | — |  |  | (13.1 | ) |  |
| Integration related costs | (2.9 | ) |  | (3.2 | ) |  | — |  |  | (6.1 | ) |  | — |  |  |
| Amortization of acquired intangibles | (6.2 | ) |  | (6.3 | ) |  | (0.8 | ) |  | (12.5 | ) |  | (0.8 | ) |  |
| Other charges | (3.3 | ) |  | (1.4 | ) |  | (0.6 | ) |  | (4.7 | ) |  | (1.5 | ) |  |
| Selling, general and administrative on non-GAAP basis | $ | 38.0 |  |  | $ | 37.1 |  |  | $ | 28.2 |  |  | $ | 75.1 |  |  | $ | 54.5 |  |  |
| Income from operations on GAAP basis | $ | 74.8 |  |  | $ | 59.8 |  |  | $ | 11.5 |  |  | $ | 134.6 |  |  | $ | 68.6 |  |  |
| Stock-based compensation | 20.2 |  |  | 16.7 |  |  | 29.7 |  |  | 36.9 |  |  | 40.5 |  |  |
| Inventory write down and fixed asset impairment due to product lines exit (3) | 2.6 |  |  | 1.1 |  |  | — |  |  | 3.7 |  |  | — |  |  |
| Acquisition related costs | — |  |  | — |  |  | 12.0 |  |  | — |  |  | 13.1 |  |  |
| Integration related costs | 2.9 |  |  | 6.6 |  |  | — |  |  | 9.5 |  |  | — |  |  |
| Amortization of acquired intangibles | 18.6 |  |  | 18.8 |  |  | 5.2 |  |  | 37.4 |  |  | 6.0 |  |  |
| Amortization of fair value adjustments (2) | 2.1 |  |  | 2.2 |  |  | 1.3 |  |  | 4.3 |  |  | 1.3 |  |  |
| Restructuring and related charges | 0.9 |  |  | 1.3 |  |  | 7.8 |  |  | 2.2 |  |  | 9.1 |  |  |
| Other charges | 9.9 |  |  | 16.2 |  |  | 14.7 |  |  | 26.1 |  |  | 28.3 |  |  |
| Income from operations on non-GAAP basis | $ | 132.0 |  |  | $ | 122.7 |  |  | $ | 82.2 |  |  | $ | 254.7 |  |  | $ | 166.9 |  |  |
| Operating margin on non-GAAP basis | 28.8 | % |  | 27.3 | % |  | 22.0 | % |  | 28.1 | % |  | 22.9 | % |  |
| Interest and other income (expense), net on GAAP basis | $ | (17.1 | ) |  | $ | (6.4 | ) |  | $ | (4.7 | ) |  | $ | (23.5 | ) |  | $ | (7.1 | ) |  |
| Other interest and (income) expense adjustments | — |  |  | — |  |  | 2.2 |  |  | — |  |  | 2.0 |  |  |

[0001633978-20-000002:8k_2_02:53]
| Foreign exchange (gains) losses, net (4) | 2.1 |  |  | (1.1 | ) |  | (0.3 | ) |  | 1.0 |  |  | — |  |  |
| Non-cash interest expense on convertible notes and term loan | 14.4 |  |  | 4.9 |  |  | 4.5 |  |  | 19.3 |  |  | 8.8 |  |  |
| Interest and other income (expense), net on non-GAAP basis | $ | (0.6 | ) |  | $ | (2.6 | ) |  | $ | 1.7 |  |  | $ | (3.2 | ) |  | $ | 3.7 |  |  |
| Income before income taxes on GAAP basis | $ | 57.7 |  |  | $ | 53.4 |  |  | $ | 17.7 |  |  | $ | 111.1 |  |  | $ | 70.3 |  |  |
| Stock-based compensation | 20.2 |  |  | 16.7 |  |  | 29.7 |  |  | 36.9 |  |  | 40.5 |  |  |
| Inventory write down and fixed asset impairment due to product lines exit (3) | 2.6 |  |  | 1.1 |  |  | — |  |  | 3.7 |  |  | — |  |  |
| Acquisition related costs | — |  |  | — |  |  | 12.0 |  |  | — |  |  | 13.1 |  |  |
| Integration related costs | 2.9 |  |  | 6.6 |  |  | — |  |  | 9.5 |  |  | — |  |  |
| Amortization of acquired intangibles | 18.6 |  |  | 18.8 |  |  | 5.2 |  |  | 37.4 |  |  | 6.0 |  |  |
| Amortization of fair value adjustments (2) | 2.1 |  |  | 2.2 |  |  | 1.3 |  |  | 4.3 |  |  | 1.3 |  |  |
| Restructuring and related charges | 0.9 |  |  | 1.3 |  |  | 7.8 |  |  | 2.2 |  |  | 9.1 |  |  |
| Other interest and (income) expense adjustments | — |  |  | — |  |  | 2.2 |  |  | — |  |  | 2.0 |  |  |
| Foreign exchange (gains) losses, net (4) | 2.1 |  |  | (1.1 | ) |  | (0.3 | ) |  | 1.0 |  |  | — |  |  |
| Non-cash interest expense on convertible notes and term loan | 14.4 |  |  | 4.9 |  |  | 4.5 |  |  | 19.3 |  |  | 8.8 |  |  |
| Unrealized gain on derivative liability | — |  |  | — |  |  | (10.9 | ) |  | — |  |  | (8.8 | ) |  |
| Other charges | 9.9 |  |  | 16.2 |  |  | 14.7 |  |  | 26.1 |  |  | 28.3 |  |  |
| Income before income taxes on non-GAAP basis | $ | 131.4 |  |  | $ | 120.1 |  |  | $ | 83.9 |  |  | $ | 251.5 |  |  | $ | 170.6 |  |  |
| Provision for income taxes on GAAP basis | $ | 8.6 |  |  | $ | 5.8 |  |  | $ | 1.4 |  |  | $ | 14.4 |  |  | $ | 6.6 |  |  |
| Income tax adjustments | 3.4 |  |  | 2.9 |  |  | 4.5 |  |  | 6.3 |  |  | (0.1 | ) |  |
| Provision for income taxes on non-GAAP basis | $ | 12.0 |  |  | $ | 8.7 |  |  | $ | 5.9 |  |  | $ | 20.7 |  |  | $ | 6.5 |  |  |
| Net income on GAAP basis | $ | 49.1 |  |  | $ | 47.6 |  |  | $ | 16.3 |  |  | $ | 96.7 |  |  | $ | 63.7 |  |  |
| Stock-based compensation | 20.2 |  |  | 16.7 |  |  | 29.7 |  |  | 36.9 |  |  | 40.5 |  |  |
| Inventory write down and fixed asset impairment due to product lines exit (3) | 2.6 |  |  | 1.1 |  |  | — |  |  | 3.7 |  |  | — |  |  |
| Acquisition related costs | — |  |  | — |  |  | 12.0 |  |  | — |  |  | 13.1 |  |  |
| Integration related costs | 2.9 |  |  | 6.6 |  |  | — |  |  | 9.5 |  |  | — |  |  |
| Amortization of acquired intangibles | 18.6 |  |  | 18.8 |  |  | 5.2 |  |  | 37.4 |  |  | 6.0 |  |  |
| Amortization of fair value adjustments (2) | 2.1 |  |  | 2.2 |  |  | 1.3 |  |  | 4.3 |  |  | 1.3 |  |  |
| Restructuring and related charges | 0.9 |  |  | 1.3 |  |  | 7.8 |  |  | 2.2 |  |  | 9.1 |  |  |
| Other interest and (income) expense adjustments | — |  |  | — |  |  | 2.2 |  |  | — |  |  | 2.0 |  |  |
| Foreign exchange (gains) losses, net (4) | 2.1 |  |  | (1.1 | ) |  | (0.3 | ) |  | 1.0 |  |  | — |  |  |
| Non-cash interest expense on convertible notes and term loan | 14.4 |  |  | 4.9 |  |  | 4.5 |  |  | 19.3 |  |  | 8.8 |  |  |
| Unrealized gain on derivative liability | — |  |  | — |  |  | (10.9 | ) |  | — |  |  | (8.8 | ) |  |
| Other charges | 9.9 |  |  | 16.2 |  |  | 14.7 |  |  | 26.1 |  |  | 28.3 |  |  |
| Income tax adjustments | (3.4 | ) |  | (2.9 | ) |  | (4.5 | ) |  | (6.3 | ) |  | 0.1 |  |  |
| Net income on non-GAAP basis | $ | 119.4 |  |  | $ | 111.4 |  |  | $ | 78.0 |  | (4) | $ | 230.8 |  |  | $ | 164.1 |  | (4) |
| Net income per share on non-GAAP basis | $ | 1.53 |  |  | $ | 1.44 |  |  | $ | 1.15 |  | (4) | $ | 2.97 |  |  | $ | 2.46 |  | (4) |
| Shares used in per share calculation - diluted on GAAP basis and non-GAAP basis | 78.0 |  |  | 77.6 |  |  | 67.8 |  |  | 77.8 |  |  | 66.6 |  |  |

[0001633978-20-000002:8k_2_02:54]
(1) Other charges for the three and six months ended December 28, 2019, primarily include costs of transferring product lines to new production facilities, including Thailand of $2.0 million and $8.1 million, respectively. We also incurred excess and obsolete inventory charges driven by the decline in demand from Huawei of $6.0 million and $12.7 million during the three and six months ended December 28, 2019. Other charges for the three and six months ended December 29, 2018, including costs of transferring product lines to Thailand of $14.5 million and $27.2 million, respectively.

[0001633978-20-000002:8k_2_02:55]
(2) In connection with the acquisition of Oclaro in fiscal 2019, we recorded a fair value adjustment of $60.3 million to inventory, resulting in $2.1 million and $4.3 million of amortization expense of the fair value adjustment during the three and six months ended December 28, 2019, respectively.

[0001633978-20-000002:8k_2_02:56]
(3) For the three and six months ended December 28, 2019, we recorded an inventory write down charge and fixed assets impairment of $2.6 million and $3.7 million, respectively, related to the decision to exit the Datacom module and Lithium Niobate product lines.

[0001633978-20-000002:8k_2_02:57]
(4) The non-GAAP financial measures for the three and six months ended December 29, 2018 have been adjusted to conform to the current period presentation, by removing foreign exchange (gains) losses, net.

[0001633978-20-000002:8k_2_02:58]
LUMENTUM HOLDINGS INC.

[0001633978-20-000002:8k_2_02:59]
RECONCILIATION OF GAAP NET INCOME TO EBITDA

[0001633978-20-000002:8k_2_02:60]
(in millions, except per share data)

[0001633978-20-000002:8k_2_02:61]
(unaudited)

[0001633978-20-000002:8k_2_02:62]
|  | Three Months Ended |  | Six Months Ended |
|  | December 28, 2019 |  | September 28, 2019 |  | December 28, 2019 |  | December 29, 2018 |
| GAAP Net income | $ | 49.1 |  |  | $ | 47.6 |  |  | $ | 96.7 |  |  | $ | 63.7 |  |
| Interest and other expense (income), net | 17.1 |  |  | 6.4 |  |  | 23.5 |  |  | 7.1 |  |
| Provision for income taxes | 8.6 |  |  | 5.8 |  |  | 14.4 |  |  | 6.6 |  |
| Depreciation | 28.7 |  |  | 31.6 |  |  | 60.3 |  |  | 45.7 |  |
| Amortization of acquired intangibles | 18.6 |  |  | 18.8 |  |  | 37.4 |  |  | 6.0 |  |
| EBITDA | 122.1 |  |  | 110.2 |  |  | 232.3 |  |  | 129.1 |  |
| Amortization of fair value adjustments | 2.1 |  |  | 2.2 |  |  | 4.3 |  |  | 1.3 |  |
| Restructuring and related charges | 0.9 |  |  | 1.3 |  |  | 2.2 |  |  | 9.1 |  |
| Stock-based compensation | 20.2 |  |  | 16.7 |  |  | 36.9 |  |  | 40.5 |  |
| Acquisition related costs | — |  |  | — |  |  | — |  |  | 13.1 |  |
| Unrealized gain on derivative liability | — |  |  | — |  |  | — |  |  | (8.8 | ) |
| Inventory write down and fixed asset impairment due to product lines exit | 2.6 |  |  | 1.1 |  |  | 3.7 |  |  | — |  |
| Integration related costs | 2.9 |  |  | 6.6 |  |  | 9.5 |  |  | — |  |
| Other charges | 9.9 |  |  | 16.2 |  |  | 26.1 |  |  | 28.3 |  |
| Adjusted EBITDA | $ | 160.7 |  |  | $ | 154.3 |  |  | $ | 315.0 |  |  | $ | 212.6 |  |
