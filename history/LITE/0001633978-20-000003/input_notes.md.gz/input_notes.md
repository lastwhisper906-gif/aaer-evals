# LITE notes — 0001633978-20-000003


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001633978-20-000003:notes:1]
[same as prior period, unchanged from 0001633978-19-000071:notes:1]

[0001633978-20-000003:notes:2]
[same as prior period, unchanged from 0001633978-19-000071:notes:2]

[0001633978-20-000003:notes:3]
Lumentum (“we,” “us,” “our” or the “Company”) is an industry-leading provider of optical and photonic products defined by revenue and market share addressing a range of end market applications including Optical Communications (“OpComms”) and Lasers for manufacturing, inspection and life-science applications. We seek to use our core optical and photonic technology and our volume manufacturing capability to expand into attractive emerging markets that benefit from advantages that optical or photonics based solutions provide, including 3D sensing for consumer electronics and diode light sources for a variety of consumer and industrial applications. The majority of our customers tend to be Original Equipment Manufacturers (“OEMs”) that incorporate our products into their products which then address end-market applications. For example, we sell fiber optic components that Network Equipment Manufacturers’ (“NEMs”) customers assemble into communications networking systems, which they sell to network service providers or enterprises with their own networks. Similarly, many of our customers for our Lasers products incorporate our products into tools they produce, which are used for manufacturing processes by their customers. For 3D sensing, we sell diode lasers to manufacturers of consumer electronics products for mobile, personal computing, gaming, and other applications who then integrate our devices within their products, for eventual resale to consumers and also into other industrial applications. Further, we have begun shipping prototype units of diode lasers and optical subassemblies containing diode lasers and other optical devices to automotive customers for sensing and LiDAR applications.

[0001633978-20-000003:notes:4]
[same as prior period, unchanged from 0001633978-19-000071:notes:4]

[0001633978-20-000003:notes:5]
[same as prior period, unchanged from 0001633978-19-000071:notes:5]

[0001633978-20-000003:notes:6]
[same as prior period, unchanged from 0001633978-19-000071:notes:6]

[0001633978-20-000003:notes:7]
[same as prior period, unchanged from 0001633978-19-000071:notes:7]

[0001633978-20-000003:notes:8]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Every fifth or sixth fiscal year will have a 53-week period. The additional week in a 53-week year is added to the third quarter, making such quarter consist of 14 weeks. Our fiscal 2021 will be a 53-week year. Our fiscal 2020 is a 52-week year ending on June 27, 2020, with the quarter ended December 28, 2019 being a 13-week quarterly period. Our fiscal 2019 was a 52-week year that ended on June 29, 2019, with the quarter ended December 29, 2018 being a 13-week quarterly period.

[0001633978-20-000003:notes:9]
[same as prior period, unchanged from 0001633978-19-000071:notes:9]

[0001633978-20-000003:notes:10]
[same as prior period, unchanged from 0001633978-19-000071:notes:10]

[0001633978-20-000003:notes:11]
Certain prior period amounts have been reclassified to conform to the current period presentation, including the reclassification of capital lease obligations that existed as of June 29, 2019 to finance lease liabilities within other current liabilities and other non-current liabilities in our condensed consolidated balance sheets, as a result of the adoption of the new accounting guidance for leases. Refer to “Note 2. Recently Issued Accounting Pronouncements” for details. The reclassification of the prior period amounts did not impact previously reported condensed consolidated financial statements.

[0001633978-20-000003:notes:12]
[same as prior period, unchanged from 0001633978-19-000071:notes:12]

[0001633978-20-000003:notes:13]
[same as prior period, unchanged from 0001633978-19-000071:notes:13]

[0001633978-20-000003:notes:14]
Except for the accounting policies for lease accounting as a result of the adoption of Accounting Standards Update (“ASU”) 2016-02, Leases (Topic 842), there have been no significant changes to our significant accounting policies as of and for the three months ended December 28, 2019, as compared to the significant accounting policies described in our Annual Report on Form 10-K for the year ended June 29, 2019.

[0001633978-20-000003:notes:15]
[same as prior period, unchanged from 0001633978-19-000071:notes:16]

[0001633978-20-000003:notes:16]
On June 30, 2019, the first day of fiscal year 2020, we adopted Topic 842, using the modified retrospective transition approach. Refer to “Note 2. Recently Issued Accounting Pronouncements” regarding the impact of adoption.

[0001633978-20-000003:notes:17]
[same as prior period, unchanged from 0001633978-19-000071:notes:18]

[0001633978-20-000003:notes:18]
[same as prior period, unchanged from 0001633978-19-000071:notes:19]

[0001633978-20-000003:notes:19]
[same as prior period, unchanged from 0001633978-19-000071:notes:20]

[0001633978-20-000003:notes:20]
[same as prior period, unchanged from 0001633978-19-000071:notes:21]


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001633978-20-000003:notes:21]
Accounting Pronouncements Recently Adopted

[0001633978-20-000003:notes:22]
Effective June 30, 2019, we adopted Topic 842, using the modified retrospective transition approach. We applied the new guidance to all leases existing as of the date of adoption. Our reported results beginning with the first quarter of fiscal 2020 reflect the application of Topic 842, while prior period amounts have not been adjusted and continue to be reported in accordance with our historical accounting under Topic 840.

[0001633978-20-000003:notes:23]
We elected the practical expedient package permitted under the transition approach. As such, we did not reassess whether any expired or existing contracts are or contain leases, we did not reassess our historical lease classification, and we did not reassess our initial direct costs for any leases that existed prior to June 30, 2019. We have also elected to combine lease and non-lease components at a portfolio level for our operating leases of buildings and not to report leases with an initial term of 12 months or less on our balance sheet.

[0001633978-20-000003:notes:24]
As of the date of adoption, we recognized operating lease assets of $91.5 million, with corresponding operating lease liabilities of $81.5 million on the condensed consolidated balance sheets. The difference between the operating lease right-of-use assets and operating lease liabilities primarily represents the existing asset recognized in relation to the favorable terms of an operating lease acquired through a business combination offset by our deferred rent and ASC 420 “cease-use” balances.

[0001633978-20-000003:notes:25]
All existing leases that were classified as capital leases under Topic 840 are classified as finance leases under the new guidance. As of adoption, we recognized finance lease assets of $12.4 million in property, plant and equipment, net, with corresponding finance lease liabilities of $12.4 million on the condensed consolidated balance sheets. For further information regarding the impact of Topic 842 adoption, see “Note 1. Description of Business and Summary of Significant Accounting Policies” and “Note 9. Leases”.

[0001633978-20-000003:notes:26]
In February 2018, FASB issued ASU 2018-02, Income Statement-Reporting Comprehensive Income (Topic 220): Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income, which allows companies to reclassify stranded tax effects resulting from the U.S. Tax Cuts and Jobs Act of 2017 (the “Tax Act”), from accumulated other comprehensive income to retained earnings. The guidance also requires certain new disclosures regardless of the election. The amendments in ASU 2018-02 are effective for all entities for fiscal years beginning after December 15, 2018, and interim periods within those fiscal years. We adopted ASU 2018-02 in the first quarter of fiscal 2020 with no impact to our condensed consolidated financial statements.

[0001633978-20-000003:notes:27]
In January 2017, FASB issued ASU 2017-04, Intangibles - Goodwill and Other (Topic 350): Simplifying the Accounting for Goodwill Impairment. ASU 2017-04 removes the requirement to perform a hypothetical purchase price allocation to measure goodwill impairment. A goodwill impairment charge will be the amount by which a reporting unit's carrying value exceeds its fair value, not to exceed the carrying amount of goodwill. The amendments contained in ASU 2017-04 are effective for interim and annual periods beginning after December 15, 2019, with early adoption permitted, which should be applied prospectively. We early adopted ASU 2017-04 in our first quarter of fiscal 2020. The implementation of ASU 2017-04 did not have an impact on our condensed consolidated financial statements.

[0001633978-20-000003:notes:28]
Accounting Pronouncements Not Yet Effective

[0001633978-20-000003:notes:29]
In December 2019, FASB issued ASU 2019-12, Simplifying the Accounting for Income Taxes (Topic 740), which is intended to simplify various aspects related to accounting for income taxes by removing certain exceptions to the general principles in Topic 740 and which also clarifies and amends existing guidance to improve consistent application. ASU 2019-12 is effective for us at the beginning of fiscal 2022, including interim periods within that reporting period, although early adoption is permitted. We are currently evaluating the impact of ASU 2019-12 on our condensed consolidated financial statements.

[0001633978-20-000003:notes:30]
In August 2018, FASB issued ASU 2018-14, Compensation-Retirement Benefits-Defined Benefit Plans-General (Topic 715-20): Disclosure Framework-Changes to the Disclosure Requirements for Defined Benefit Plans. ASU 2018-14 modifies the disclosure requirements for defined benefit pension plans and other post-retirement benefit plans. The new guidance is effective for fiscal years ending after December 15, 2020, with early adoption permitted. ASU 2018-14 should be applied retrospectively to all periods presented and is effective for us in our first quarter of fiscal 2022. We are currently evaluating the impact of ASU 2018-14 on our condensed consolidated financial statements.

[0001633978-20-000003:notes:31]
In August 2018, FASB issued ASU 2018-13, Fair Value Measurement (Topic 820): Disclosure Framework-Changes to the Disclosure Requirements for Fair Value Measurement. ASU 2018-13 modifies the disclosure requirements for fair value measurements. The new guidance is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019, with early adoption permitted. ASU 2018-13 requires that certain of the amendments be applied prospectively, while other amendments should be applied retrospectively to all periods presented. ASU 2018-13 is effective for us in our first quarter of fiscal 2021. We are currently evaluating the impact of ASU 2018-13 on our condensed consolidated financial statements and related disclosures.

[0001633978-20-000003:notes:32]
In June 2016, FASB issued ASU 2016-13, Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments and a subsequent amendment, ASU 2018-19 (collectively, Topic 326). Topic 326 requires measurement and recognition of expected credit losses for financial assets held. Topic 326 is effective for annual periods beginning after December 15, 2019, including interim periods within those periods, with early adoption permitted. ASU 2016-13 is effective for us in our first quarter of fiscal 2021. We are currently evaluating the impact of our pending adoption of Topic 326 on our condensed consolidated financial statements.


## us-gaap:EarningsPerShareTextBlock

[0001633978-20-000003:notes:33]
[same as prior period, unchanged from 0001633978-19-000071:notes:33]

[0001633978-20-000003:notes:34]
[same as prior period, unchanged from 0001633978-19-000071:notes:34]

[0001633978-20-000003:notes:35]
|  | Three Months Ended |  | Six Months Ended |
|  | December 28, 2019 |  | December 29, 2018 |  | December 28, 2019 |  | December 29, 2018 |
| Basic Earnings per Common Share |  |  |  |  |  |  |  |  |  |  |
| Net income | $ | 49.1 |  |  | $ | 16.3 |  |  | $ | 96.7 |  |  | $ | 63.7 |  |
| Less: Cumulative dividends on Series A Preferred Stock | — |  |  | (0.1 | ) |  | — |  |  | (0.3 | ) |
| Less: Earnings allocated to Series A Preferred Stock | — |  |  | (0.1 | ) |  | — |  |  | (1.2 | ) |
| Net income attributable to common stockholders - Basic | $ | 49.1 |  |  | $ | 16.1 |  |  | $ | 96.7 |  |  | $ | 62.2 |  |
| Weighted average common shares outstanding including Series A Preferred Stock | 76.8 |  |  | 67.3 |  |  | 76.9 |  |  | 66.0 |  |
| Less: Weighted average Series A Preferred Stock | — |  |  | (0.5 | ) |  | — |  |  | (1.0 | ) |
| Basic weighted average common shares outstanding | 76.8 |  |  | 66.8 |  |  | 76.9 |  |  | 65.0 |  |
| Net income per share attributable to common stockholders - Basic | $ | 0.64 |  |  | $ | 0.24 |  |  | $ | 1.26 |  |  | $ | 0.96 |  |
| Diluted Earnings per Common Share |  |  |  |  |  |  |  |
| Net income attributable to common stockholders - Basic | $ | 49.1 |  |  | $ | 16.1 |  |  | $ | 96.7 |  |  | $ | 62.2 |  |
| Add: Earnings allocated to Series A Preferred Stock | — |  |  | 0.1 |  |  | — |  |  | 1.2 |  |
| Less: Unrealized gain on derivative liability on Series A Preferred Stock | — |  |  | (10.9 | ) |  | — |  |  | (8.8 | ) |
| Add: Cumulative dividends on Series A Preferred Stock | — |  |  | 0.1 |  |  | — |  |  | 0.3 |  |
| Net income attributable to common stockholders - Diluted | $ | 49.1 |  |  | $ | 5.4 |  |  | $ | 96.7 |  |  | $ | 54.9 |  |
| Weighted average common shares outstanding for basic earnings per common share | 76.8 |  |  | 66.8 |  |  | 76.9 |  |  | 65.0 |  |
| Effect of dilutive securities from 2015 Equity Incentive Plan | 0.7 |  |  | 0.5 |  |  | 0.7 |  |  | 0.6 |  |
| Effect of dilutive securities from Series A Preferred Stock | — |  |  | 0.5 |  |  | — |  |  | 1.0 |  |
| Shares issuable assuming conversion of the 2024 Notes | 0.5 |  |  | — |  |  | 0.2 |  |  | — |  |
| Diluted weighted average common shares outstanding | 78.0 |  |  | 67.8 |  |  | 77.8 |  |  | 66.6 |  |
| Net income per share attributable to common stockholders - Diluted | $ | 0.63 |  |  | $ | 0.08 |  |  | $ | 1.24 |  |  | $ | 0.82 |  |

[0001633978-20-000003:notes:36]
Our Series A Preferred Stock was considered a participating security, meaning that it had the right to participate in undistributed earnings with our common stock. On November 2, 2018, the remaining 35,805 shares of our Series A Preferred Stock were converted into 1.5 million shares of our common stock. Refer to “Note 11. Non-Controlling Interest Redeemable Convertible Preferred Stock and Derivative Liability” for further discussion. Prior to conversion, the holders of our Series A Preferred Stock were entitled to share in dividends, on an as-converted basis, if the holders of our common stock were to receive dividends. Through the date of conversion, we used the two-class method to compute earnings per share. The two-class method is an earnings allocation formula that determines earnings per share for each class of common stock and participating security according to dividends declared (or accumulated) and participation rights in undistributed earnings. In determining the amount of net earnings to allocate to common stockholders, earnings are allocated to both common and participating securities based on their respective weighted-average shares outstanding during the period. Diluted earnings per common share is calculated similar to basic earnings per common share except that it gives effect to all potentially dilutive common stock equivalents outstanding for the period, using the treasury stock method. Diluted earnings per common share is computed using the more dilutive of the treasury stock method or the if-converted method.

[0001633978-20-000003:notes:37]
Potentially dilutive common shares result from the assumed exercise of outstanding stock options, assumed vesting of outstanding equity awards, assumed issuance of stock under the employee stock purchase plan, and assumed conversion of our outstanding $450 million in aggregate principal amount of 0.25% Convertible Notes due in 2024 (the “2024 Notes”) and $1,050 million in aggregate principal amount of 0.50% Convertible Notes due in 2026 (the “2026 Notes” and together with the 2024 Notes, the “convertible notes”), all using the treasury stock method.

[0001633978-20-000003:notes:38]
We have the ability and intent to settle the face value of our convertible notes in cash. Therefore, we use the treasury stock method for calculating the dilutive impact of the convertible notes. The 2026 Notes will have no impact on diluted earnings per share until the average price of our common stock exceeds the conversion price of $99.29. The potentially dilutive shares resulting from the 2024 Notes were included in the calculation of diluted income per share for the three months ended December 28, 2019 since the average price of our common stock exceeded the conversion price of $60.62. Refer to “Note 12. Debt” for further discussion.

[0001633978-20-000003:notes:39]
Anti-dilutive potential shares from the 2015 Equity Incentive Plan are excluded from the calculation of diluted earnings per share if their exercise price exceeded the average market price during the period or the share-based awards were determined to be anti-dilutive based on applying the treasury stock method. Anti-dilutive shares excluded from the calculation of diluted earnings per share were not material for the three and six months ended December 28, 2019, respectively.


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0001633978-20-000003:notes:40]
[same as prior period, unchanged from 0001633978-19-000071:notes:40]

[0001633978-20-000003:notes:41]
[same as prior period, unchanged from 0001633978-19-000071:notes:41]

[0001633978-20-000003:notes:42]
[same as prior period, unchanged from 0001633978-19-000071:notes:42]

[0001633978-20-000003:notes:43]
[same as prior period, unchanged from 0001633978-19-000071:notes:43]

[0001633978-20-000003:notes:44]
The total transaction consideration was funded by the issuance of Lumentum common stock, new debt, and cash balances of the combined company.

[0001633978-20-000003:notes:45]
Our allocation of the purchase price of Oclaro based on the estimated fair values of the assets acquired and liabilities assumed is as follows (in millions):

[0001633978-20-000003:notes:46]
[same as prior period, unchanged from 0001633978-19-000071:notes:46]

[0001633978-20-000003:notes:47]
The amounts presented in the table above pertained to the preliminary purchase price allocation reported in our Form 10-K for the year ended June 29, 2019, filed with the Securities and Exchange Commission on August 27, 2019. There have been no measurement period adjustments during the three and six months ended December 28, 2019.

[0001633978-20-000003:notes:48]
On April 18, 2019, we completed the sale of our Datacom transceiver module business based in Sagamihara, Japan and the transfer of related employees to Cambridge Industries Group (“CIG”) for $25.5 million in net cash. These product lines were initially acquired by us through the acquisition of Oclaro. This business did not meet the criteria for assets held-for-sale under the relevant accounting guidance as of December 10, 2018, the date of our acquisition of Oclaro, in our purchase price allocation. The assets and liabilities transferred to CIG were $33.5 million and $7.0 million, respectively.

[0001633978-20-000003:notes:49]
[same as prior period, unchanged from 0001633978-19-000071:notes:50]

[0001633978-20-000003:notes:50]
[same as prior period, unchanged from 0001633978-19-000071:notes:51]

[0001633978-20-000003:notes:51]
The following supplemental pro forma information presents the combined results of operations for the six months ended December 29, 2018, as if Oclaro had been acquired as of the beginning of fiscal year 2018. The supplemental pro forma information includes adjustments to amortization and depreciation for acquired intangible assets and property and equipment, adjustments to share-based compensation expense, the fair value adjustments on the inventories acquired, transaction costs, interest expense and amortization of the term loan debt issuance costs.

[0001633978-20-000003:notes:52]
[same as prior period, unchanged from 0001633978-19-000071:notes:53]

[0001633978-20-000003:notes:53]
|  | Six Months Ended |
|  | December 29, 2018 |
| Net revenue | $ | 941.8 |  |
| Net income | 32.7 |  |


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001633978-20-000003:notes:54]
Note 5. Assets and Liabilities Held For Sale

[0001633978-20-000003:notes:55]
We continually evaluate our existing portfolio of businesses to maximize long-term shareholder value. Following our acquisition of Oclaro, we announced our plan to discontinue development and manufacturing of Lithium Niobate modulators and wind down these operations in our San Donato, Italy site. In the second quarter of fiscal year 2020, we entered into an agreement with Advanced Fiber Resources (Zhuhai) Ltd. ("AFR"), a leading provider of passive optical components, whereby AFR will acquire the assets associated with certain Lithium Niobate product lines manufactured by our San Donato site for $17 million. In connection with our agreement with AFR, we received $2.5 million of the purchase price as an advance in the second quarter of fiscal year 2020.

[0001633978-20-000003:notes:56]
In the third quarter of fiscal year 2020, we completed the sale of Lithium Niobate modulators business in San Donato, Italy to AFR and received the proceeds of $12.8 million, with the remaining holdback of $1.7 million to be received within the next two months. With the close of this transaction, our telecom transmission product strategy will now be focused on Indium Phosphide photonic integrated circuits.

[0001633978-20-000003:notes:57]
Also, included in the table below is $4.9 million of long-lived assets related to our plan to discontinue the development of future Datacom transceiver modules. As these assets were not deemed to be useful, we retired them from active use and classified them as held-for-sale on our balance sheet. This is a result of the strategic change we made in the third quarter of fiscal year 2019 when we announced the exit from the Datacom transceiver modules and investments in the new Datacom chips development.

[0001633978-20-000003:notes:58]
We consider assets and liabilities as held-for-sale when management approves and commits to a plan to actively market assets or a group of assets for sale. Assets held-for-sale are recorded initially at the lower of its carrying value or its estimated fair value, less estimated costs to sell. Upon designation as an asset held-for-sale, we discontinue recording depreciation expense on such asset.

[0001633978-20-000003:notes:59]
Assets and liabilities classified as held-for-sale as of December 28, 2019 were as follows (in millions):

[0001633978-20-000003:notes:60]
|  | December 28, 2019 |  | June 29, 2019 |
| Assets held-for-sale |  |  |  |
| Inventories | $ | 0.5 |  |  | $ | — |  |
| Property, plant and equipment, net | 7.0 |  |  | 4.9 |  |
| Operating lease right-of-use assets, net | 2.4 |  |  | — |  |
| Total | $ | 9.9 |  |  | $ | 4.9 |  |
| Liabilities held-for-sale |  |  |  |
| Operating lease liabilities | $ | 2.8 |  |  | $ | — |  |
| Asset retirement obligation | 0.7 |  |  | — |  |
| Total | $ | 3.5 |  |  | $ | — |  |
| Net | $ | 6.4 |  |  | $ | 4.9 |  |


## us-gaap:CashCashEquivalentsAndShortTermInvestmentsTextBlock

[0001633978-20-000003:notes:61]
Note 6. Cash, Cash Equivalents and Short-term Investments

[0001633978-20-000003:notes:62]
[same as prior period, unchanged from 0001633978-19-000071:notes:56]

[0001633978-20-000003:notes:63]
|  | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| December 28, 2019: |  |  |  |  |  |  |  |
| Cash | $ | 157.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 157.7 |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | 3.5 |  |  | — |  |  | — |  |  | 3.5 |  |
| Commercial paper | 91.8 |  |  | — |  |  | — |  |  | 91.8 |  |
| Corporate debt securities | 13.2 |  |  | — |  |  | — |  |  | 13.2 |  |
| Money market funds | 774.3 |  |  | — |  |  | — |  |  | 774.3 |  |
| U.S. Agency securities | 44.5 |  |  | — |  |  | — |  |  | 44.5 |  |
| Total cash and cash equivalents | $ | 1,085.0 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,085.0 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 1.9 |  |  | $ | — |  |  | $ | — |  |  | $ | 1.9 |  |
| Commercial paper | 5.5 |  |  | — |  |  | — |  |  | 5.5 |  |
| Asset-backed securities | 31.8 |  |  | 0.2 |  |  | — |  |  | 32.0 |  |
| Corporate debt securities | 159.7 |  |  | 0.8 |  |  | — |  |  | 160.5 |  |
| Mortgage-backed securities | 5.2 |  |  | — |  |  | — |  |  | 5.2 |  |
| Foreign government bonds | 4.1 |  |  | — |  |  | — |  |  | 4.1 |  |
| U.S. Treasury securities | 21.4 |  |  | — |  |  | — |  |  | 21.4 |  |
| Total short-term investments | $ | 229.6 |  |  | $ | 1.0 |  |  | $ | — |  |  | $ | 230.6 |  |
| June 29, 2019: |  |  |  |  |  |  |  |
| Cash | $ | 213.8 |  |  | $ | — |  |  | $ | — |  |  | $ | 213.8 |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | 37.4 |  |  | — |  |  | — |  |  | 37.4 |  |
| Money market funds | 168.1 |  |  | — |  |  | — |  |  | 168.1 |  |
| U.S. Treasury securities | 13.3 |  |  | — |  |  | — |  |  | 13.3 |  |
| Total cash and cash equivalents | $ | 432.6 |  |  | $ | — |  |  | $ | — |  |  | $ | 432.6 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 1.9 |  |  | $ | — |  |  | $ | — |  |  | $ | 1.9 |  |
| Commercial paper | 22.3 |  |  | — |  |  | — |  |  | 22.3 |  |
| Asset-backed securities | 54.9 |  |  | 0.2 |  |  | — |  |  | 55.1 |  |
| Corporate debt securities | 207.6 |  |  | 0.9 |  |  | (0.1 | ) |  | 208.4 |  |
| Municipal bonds | 1.3 |  |  | — |  |  | — |  |  | 1.3 |  |
| Mortgage-backed securities | 6.6 |  |  | — |  |  | — |  |  | 6.6 |  |
| Foreign government bonds | 6.2 |  |  | — |  |  | — |  |  | 6.2 |  |
| U.S. Agency securities | 4.6 |  |  | — |  |  | — |  |  | 4.6 |  |
| U.S. Treasury securities | 29.4 |  |  | 0.1 |  |  | — |  |  | 29.5 |  |
| Total short-term investments | $ | 334.8 |  |  | $ | 1.2 |  |  | $ | (0.1 | ) |  | $ | 335.9 |  |

[0001633978-20-000003:notes:64]
We use the specific-identification method to determine any realized gains or losses from the sale of our short-term investments classified as available-for-sale. During the three and six months ended December 28, 2019 and December 29, 2018, we did not realize significant gains or losses on a gross level from the sale of our short-term investments classified as available-for-sale.

[0001633978-20-000003:notes:65]
During the three and six months ended December 28, 2019, our other income (expense), net was $1.2 million and $6.2 million, respectively, and includes interest income on cash equivalents and short-term investments of $3.4 million and $7.4 million, respectively. During the three and six months ended December 29, 2018, our other income (expense), net was $3.8 million and $6.5 million, respectively, and includes interest income on cash equivalents and short-term investments of $3.4 million and $6.1 million, respectively.

[0001633978-20-000003:notes:66]
[same as prior period, unchanged from 0001633978-19-000071:notes:60]

[0001633978-20-000003:notes:67]
|  | Less than 12 months |  | 12 Months or Greater |  | Total |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |
| December 28, 2019: |  |  |  |  |  |  |  |  |  |  |  |
| Asset-backed securities | $ | 2.3 |  |  | $ | — |  |  | $ | 0.1 |  |  | $ | — |  |  | $ | 2.4 |  |  | $ | — |  |
| Corporate debt securities | 17.3 |  |  | — |  |  | — |  |  | — |  |  | 17.3 |  |  | — |  |
| Total | $ | 19.6 |  |  | $ | — |  |  | $ | 0.1 |  |  | $ | — |  |  | $ | 19.7 |  |  | $ | — |  |
| June 29, 2019: |  |  |  |  |  |  |  |  |  |  |  |
| Asset-backed securities | $ | 4.2 |  |  | $ | — |  |  | $ | 5.9 |  |  | $ | — |  |  | $ | 10.1 |  |  | $ | — |  |
| Corporate debt securities | 9.6 |  |  | — |  |  | 35.9 |  |  | (0.1 | ) |  | 45.5 |  |  | (0.1 | ) |
| Foreign government bonds | — |  |  | — |  |  | 2.1 |  |  | — |  |  | 2.1 |  |  | — |  |
| U.S. government bonds | 6.9 |  |  | — |  |  | — |  |  | — |  |  | 6.9 |  |  | — |  |
| Total | $ | 20.7 |  |  | $ | — |  |  | $ | 43.9 |  |  | $ | (0.1 | ) |  | $ | 64.6 |  |  | $ | (0.1 | ) |

[0001633978-20-000003:notes:68]
[same as prior period, unchanged from 0001633978-19-000071:notes:62]

[0001633978-20-000003:notes:69]
|  | December 28, 2019 |  | June 29, 2019 |
|  | Amortized Cost |  | Fair Value |  | Amortized Cost |  | Fair Value |
| Due in 1 year | $ | 120.6 |  |  | $ | 120.9 |  |  | $ | 178.9 |  |  | $ | 179.1 |  |
| Due in 1 year through 5 years | 105.2 |  |  | 105.9 |  |  | 148.1 |  |  | 149.0 |  |
| Due in 5 years through 10 years | 3.0 |  |  | 3.0 |  |  | 6.0 |  |  | 6.0 |  |
| Due after 10 years | 0.8 |  |  | 0.8 |  |  | 1.8 |  |  | 1.8 |  |
|  | $ | 229.6 |  |  | $ | 230.6 |  |  | $ | 334.8 |  |  | $ | 335.9 |  |

[0001633978-20-000003:notes:70]
[same as prior period, unchanged from 0001633978-19-000071:notes:64]


## us-gaap:FairValueDisclosuresTextBlock

[0001633978-20-000003:notes:71]
Note 7. Fair Value Measurements

[0001633978-20-000003:notes:72]
[same as prior period, unchanged from 0001633978-19-000071:notes:66]

[0001633978-20-000003:notes:73]
[same as prior period, unchanged from 0001633978-19-000071:notes:67]

[0001633978-20-000003:notes:74]
[same as prior period, unchanged from 0001633978-19-000071:notes:68]

[0001633978-20-000003:notes:75]
In February 2017, we completed the acquisition of a privately held company to enhance our manufacturing and vertical integration capabilities for a total purchase consideration of $8.7 million. We estimated the fair value of our Level 3 contingent consideration related to this acquisition at the present value of the expected contingent payments, determined using a probabilistic approach. We are required to reassess the fair value of contingent payments on a periodic basis. We recorded $3.0 million of the fair value of such contingent consideration in other current liabilities on the condensed consolidated balance sheet as of December 28, 2019.

[0001633978-20-000003:notes:76]
Based on quoted market prices as of December 28, 2019, the fair values of the 2026 Notes and the 2024 Notes (refer to “Note 12. Debt”) were approximately $1.1 billion and $656.7 million, respectively, determined using Level 2 inputs as they are not actively traded in markets.

[0001633978-20-000003:notes:77]
[same as prior period, unchanged from 0001633978-19-000071:notes:72]

[0001633978-20-000003:notes:78]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| December 28, 2019: (1) |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | — |  |  | $ | 3.5 |  |  | $ | — |  |  | $ | 3.5 |  |
| Commercial paper | — |  |  | 91.8 |  |  | — |  |  | 91.8 |  |
| Corporate debt securities | — |  |  | 13.2 |  |  | — |  |  | 13.2 |  |
| Money market funds | 774.3 |  |  | — |  |  | — |  |  | 774.3 |  |
| U.S. Agency securities | — |  |  | 44.5 |  |  | — |  |  | 44.5 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | 1.9 |  |  | — |  |  | 1.9 |  |
| Commercial paper | — |  |  | 5.5 |  |  | — |  |  | 5.5 |  |
| Asset-backed securities | — |  |  | 32.0 |  |  | — |  |  | 32.0 |  |
| Corporate debt securities | — |  |  | 160.5 |  |  | — |  |  | 160.5 |  |
| Mortgage-backed securities | — |  |  | 5.2 |  |  | — |  |  | 5.2 |  |
| Foreign government bonds | — |  |  | 4.1 |  |  | — |  |  | 4.1 |  |
| U.S. Treasury securities | 21.4 |  |  | — |  |  | — |  |  | 21.4 |  |
| Total assets | $ | 795.7 |  |  | $ | 362.2 |  |  | $ | — |  |  | $ | 1,157.9 |  |
| Other current liabilities: |  |  |  |  |  |  |  |
| Acquisition contingency | $ | — |  |  | $ | — |  |  | $ | 3.0 |  |  | $ | 3.0 |  |
| Total other accrued liabilities | $ | — |  |  | $ | — |  |  | $ | 3.0 |  |  | $ | 3.0 |  |

[0001633978-20-000003:notes:79]
(1)  Excludes $157.7 million in cash held in our bank accounts at December 28, 2019.

[0001633978-20-000003:notes:80]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| June 29, 2019: (1) |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | $ | — |  |  | $ | 37.4 |  |  | $ | — |  |  | $ | 37.4 |  |
| Money market funds | 168.1 |  |  | — |  |  | — |  |  | 168.1 |  |
| U.S. Treasury securities | 13.3 |  |  | — |  |  | — |  |  | 13.3 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | — |  |  | 1.9 |  |  | — |  |  | 1.9 |  |
| Commercial paper | — |  |  | 22.3 |  |  | — |  |  | 22.3 |  |
| Asset-backed securities | — |  |  | 55.1 |  |  | — |  |  | 55.1 |  |
| Corporate debt securities | — |  |  | 208.4 |  |  | — |  |  | 208.4 |  |
| Municipal bonds | — |  |  | 1.3 |  |  | — |  |  | 1.3 |  |
| Mortgage-backed securities | — |  |  | 6.6 |  |  | — |  |  | 6.6 |  |
| Foreign government bonds | — |  |  | 6.2 |  |  | — |  |  | 6.2 |  |
| U.S. Agency securities | — |  |  | 4.6 |  |  | — |  |  | 4.6 |  |
| U.S. Treasury securities | 29.5 |  |  | — |  |  | — |  |  | 29.5 |  |
| Total assets | $ | 210.9 |  |  | $ | 343.8 |  |  | $ | — |  |  | $ | 554.7 |  |
| Other accrued liabilities: |  |  |  |  |  |  |  |
| Acquisition contingency | $ | — |  |  | $ | — |  |  | $ | 2.7 |  |  | $ | 2.7 |  |
| Total other accrued liabilities | $ | — |  |  | $ | — |  |  | $ | 2.7 |  |  | $ | 2.7 |  |

[0001633978-20-000003:notes:81]
[same as prior period, unchanged from 0001633978-19-000071:notes:76]

[0001633978-20-000003:notes:82]
[same as prior period, unchanged from 0001633978-19-000071:notes:77]

[0001633978-20-000003:notes:83]
[same as prior period, unchanged from 0001633978-19-000071:notes:78]

[0001633978-20-000003:notes:84]
[same as prior period, unchanged from 0001633978-19-000071:notes:79]

[0001633978-20-000003:notes:85]
No impairment charges were recorded during the three and six months ended December 28, 2019 and December 29, 2018. Refer to “Note 10. Goodwill and Other Intangible Assets”.


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0001633978-20-000003:notes:86]
[same as prior period, unchanged from 0001633978-19-000071:notes:81]


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001633978-20-000003:notes:87]
Note 8. Balance Sheet Details

[0001633978-20-000003:notes:88]
[same as prior period, unchanged from 0001633978-19-000071:notes:82]

[0001633978-20-000003:notes:89]
As of December 28, 2019 and June 29, 2019, our accounts receivable allowance balance was $4.5 million for each of the periods presented.

[0001633978-20-000003:notes:90]
[same as prior period, unchanged from 0001633978-19-000071:notes:84]

[0001633978-20-000003:notes:91]
[same as prior period, unchanged from 0001633978-19-000071:notes:85]

[0001633978-20-000003:notes:92]
|  | December 28, 2019 |  | June 29, 2019 |
| Raw materials and purchased parts | $ | 60.4 |  |  | $ | 78.3 |  |
| Work in process | 72.0 |  |  | 72.5 |  |
| Finished goods | 47.2 |  |  | 78.0 |  |
| Inventories (1) | $ | 179.6 |  |  | $ | 228.8 |  |

[0001633978-20-000003:notes:93]
(1) The inventory balance as of December 28, 2019 and June 29, 2019 includes $1.4 million and $5.7 million, net of amortization, related to the inventory step-up adjustment from the Oclaro acquisition, respectively.

[0001633978-20-000003:notes:94]
[same as prior period, unchanged from 0001633978-19-000071:notes:88]

[0001633978-20-000003:notes:95]
[same as prior period, unchanged from 0001633978-19-000071:notes:89]

[0001633978-20-000003:notes:96]
|  | December 28, 2019 |  | June 29, 2019 |
| Prepayments | $ | 30.9 |  |  | $ | 32.4 |  |
| Vendor receivable | 37.8 |  |  | 36.3 |  |
| Value added tax receivable | 13.8 |  |  | 11.9 |  |
| Advances to contract manufacturers | — |  |  | 8.7 |  |
| Assets held-for-sale | 9.9 |  |  | 4.9 |  |
| Other current assets | 3.4 |  |  | 3.3 |  |
| Prepayments and other current assets | $ | 95.8 |  |  | $ | 97.5 |  |

[0001633978-20-000003:notes:97]
[same as prior period, unchanged from 0001633978-19-000071:notes:91]

[0001633978-20-000003:notes:98]
[same as prior period, unchanged from 0001633978-19-000071:notes:92]

[0001633978-20-000003:notes:99]
|  | December 28, 2019 |
| Operating lease right-of-use assets | $ | 90.3 |  |
| Less: accumulated amortization | (5.6 | ) |
| Operating lease right-of-use assets, net | $ | 84.7 |  |

[0001633978-20-000003:notes:100]
[same as prior period, unchanged from 0001633978-19-000071:notes:94]

[0001633978-20-000003:notes:101]
[same as prior period, unchanged from 0001633978-19-000071:notes:95]

[0001633978-20-000003:notes:102]
|  | December 28, 2019 |  | June 29, 2019 |
| Land | $ | 44.2 |  |  | $ | 44.2 |  |
| Buildings and improvement | 113.9 |  |  | 103.7 |  |
| Machinery and equipment (1) | 515.0 |  |  | 500.5 |  |
| Computer equipment and software | 23.6 |  |  | 25.4 |  |
| Furniture and fixtures | 5.7 |  |  | 4.9 |  |
| Leasehold improvements | 23.9 |  |  | 31.2 |  |
| Finance lease right-of-use assets (1) | 28.3 |  |  | 16.0 |  |
| Construction in progress | 47.5 |  |  | 46.8 |  |
|  | 802.1 |  |  | 772.7 |  |
| Less: Accumulated depreciation (1) | (381.1 | ) |  | (339.4 | ) |
| Property, plant and equipment, net | $ | 421.0 |  |  | $ | 433.3 |  |

[0001633978-20-000003:notes:103]
(1) Included in the table above is our equipment acquired under finance leases. As of December 28, 2019 and June 29, 2019, the accumulated depreciation of finance lease right-of-use assets was $19.4 million and $11.2 million, respectively. For fiscal 2019 in accordance with Topic 842, we have reclassified $16.0 million of equipment acquired under finance leases from machinery and equipment to finance lease right-of-use assets to conform to current period presentation.

[0001633978-20-000003:notes:104]
During the three and six months ended December 28, 2019, we recorded depreciation expense of $28.7 million and $60.3 million, respectively. During the three and six months ended December 29, 2018, we recorded depreciation expense of $26.0 million and $45.7 million, respectively.

[0001633978-20-000003:notes:105]
Included in these amounts were depreciation expense for equipment acquired under finance leases in the amount of $4.3 million and $8.2 million for the three and six months ended December 28, 2019, respectively, and $1.5 million and $3.0 million for the three and six months ended December 29, 2018, respectively.

[0001633978-20-000003:notes:106]
In fiscal 2019, we purchased a property in San Jose, California for $54.6 million in cash. We relocated our corporate headquarters to this new San Jose location in the second quarter of fiscal 2020. The allocations of value were $21.7 million to buildings and improvement and $32.9 million to the land.

[0001633978-20-000003:notes:107]
[same as prior period, unchanged from 0001633978-19-000071:notes:100]

[0001633978-20-000003:notes:108]
[same as prior period, unchanged from 0001633978-19-000071:notes:101]

[0001633978-20-000003:notes:109]
[same as prior period, unchanged from 0001633978-19-000071:notes:102]

[0001633978-20-000003:notes:110]
|  | December 28, 2019 |  | June 29, 2019 |
| Restructuring accrual and related charges (1) | $ | 5.0 |  |  | $ | 14.6 |  |
| Warranty accrual (2) | 6.8 |  |  | 7.5 |  |
| Deferred revenue and customer deposits | 1.8 |  |  | 2.9 |  |
| Finance lease liabilities, current (3) | 7.1 |  |  | 0.4 |  |
| Income tax payable (4) | 25.4 |  |  | 8.7 |  |
| Other current liabilities | 11.8 |  |  | 5.1 |  |
| Other current liabilities | $ | 57.9 |  |  | $ | 39.2 |  |

[0001633978-20-000003:notes:111]
[same as prior period, unchanged from 0001633978-19-000071:notes:104]

[0001633978-20-000003:notes:112]
(2) Refer to “Note 17. Commitments and Contingencies.”

[0001633978-20-000003:notes:113]
(3) For fiscal 2019 in accordance with Topic 842, we have reclassified amounts from capital lease obligations to finance lease liabilities to conform to current period presentation. In addition to the $7.1 million of finance lease liabilities recorded within other current liabilities as of December 28, 2019, we also recorded $0.2 million within other non-current liabilities in the condensed consolidated balance sheet. Refer to “Note 9. Leases.”

[0001633978-20-000003:notes:114]
[same as prior period, unchanged from 0001633978-19-000071:notes:107]

[0001633978-20-000003:notes:115]
[same as prior period, unchanged from 0001633978-19-000071:notes:108]

[0001633978-20-000003:notes:116]
[same as prior period, unchanged from 0001633978-19-000071:notes:109]

[0001633978-20-000003:notes:117]
|  | December 28, 2019 |  | June 29, 2019 |
| Asset retirement obligations | $ | 4.9 |  |  | $ | 4.5 |  |
| Pension and related accrual (1) | 8.4 |  |  | 7.9 |  |
| Deferred rent | — |  |  | 2.2 |  |
| Unrecognized tax benefit | 19.0 |  |  | 18.7 |  |
| Finance lease liabilities, non-current | 0.2 |  |  | — |  |
| Other non-current liabilities | 0.5 |  |  | 0.4 |  |
| Other non-current liabilities | $ | 33.0 |  |  | $ | 33.7 |  |

[0001633978-20-000003:notes:118]
(1) In connection with our acquisitions of Oclaro in fiscal 2019 and Time-Bandwidth  Products Inc. in fiscal 2014, we assumed defined benefit plans for Japan and Switzerland employees, respectively. As of December 28, 2019, the projected benefit obligations for Japanese and Swiss employees were $3.0 million and $5.4 million, respectively. As of June 29, 2019, the projected benefit obligations for Japanese and Swiss employees were $2.8 million and $5.0 million, respectively. Pension and related accruals as of June 29, 2019 also include $0.1 million attributable to post-retirement benefits for executives.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001633978-20-000003:notes:119]
Note 9. Leases

[0001633978-20-000003:notes:120]
[same as prior period, unchanged from 0001633978-19-000071:notes:113]

[0001633978-20-000003:notes:121]
[same as prior period, unchanged from 0001633978-19-000071:notes:114]

[0001633978-20-000003:notes:122]
As of December 28, 2019, we sublease certain floors of our offices in the United Kingdom, the United States, Canada, and Japan. These subleases will expire at various dates by fiscal year 2023. We anticipate receiving approximately $6.6 million in sublease income over the next three years.

[0001633978-20-000003:notes:123]
[same as prior period, unchanged from 0001633978-19-000071:notes:116]

[0001633978-20-000003:notes:124]
|  | Three Months Ended |  | Six Months Ended |
|  | December 28, 2019 |  | December 28, 2019 |
| Finance lease cost (in millions): |  |  |  |
| Amortization of right-of-use assets | $ | 4.3 |  |  | $ | 8.2 |  |
| Interest | — |  |  | 0.1 |  |
| Operating lease cost | 4.0 |  |  | 8.0 |  |
| Variable lease cost | 0.5 |  |  | 1.1 |  |
| Short-term lease cost | 0.5 |  |  | 1.0 |  |
| Sublease income | (0.6 | ) |  | (1.2 | ) |
| Total lease cost | $ | 8.7 |  |  | $ | 17.2 |  |
| Weighted average remaining lease term (in years): |  |  |  |
| Operating leases |  |  | 9.2 |  |
| Finance leases |  |  | 0.6 |  |
| Weighted average discount rate: |  |  |  |
| Operating leases |  |  | 3.46 | % |
| Finance leases |  |  | 4.38 | % |

[0001633978-20-000003:notes:125]
As of December 28, 2019, maturities of our operating and finance lease liabilities, which do not include short-term leases and variable lease payments, were as follows (in millions):

[0001633978-20-000003:notes:126]
| Fiscal Years |  | Operating Leases (1) |  | Finance Leases |  | Total |
| Remainder of 2020 |  | $ | 6.9 |  |  | $ | 6.7 |  |  | $ | 13.6 |  |
| 2021 |  | 13.3 |  |  | 0.6 |  |  | 13.9 |  |
| 2022 |  | 12.5 |  |  | — |  |  | 12.5 |  |
| 2023 |  | 11.3 |  |  | — |  |  | 11.3 |  |
| 2024 |  | 9.6 |  |  | — |  |  | 9.6 |  |
| Thereafter |  | 31.3 |  |  | — |  |  | 31.3 |  |
| Total minimum lease payments |  | $ | 84.9 |  |  | $ | 7.3 |  |  | $ | 92.2 |  |
| Less: amount representing interest |  | (10.7 | ) |  | — |  |  | (10.7 | ) |
| Present value of total lease liabilities |  | $ | 74.2 |  |  | $ | 7.3 |  |  | $ | 81.5 |  |

[0001633978-20-000003:notes:127]
(1) Non-cancellable sublease proceeds for the remainder of fiscal 2020, and fiscal 2021, 2022, and 2023 of $1.4 million, $2.4 million, $2.2 million, and $0.6 million, respectively, are not included in the table above.

[0001633978-20-000003:notes:128]
[same as prior period, unchanged from 0001633978-19-000071:notes:121]

[0001633978-20-000003:notes:129]
[same as prior period, unchanged from 0001633978-19-000071:notes:122]


## us-gaap:GoodwillDisclosureTextBlock

[0001633978-20-000003:notes:130]
Note 10. Goodwill and Other Intangible Assets

[0001633978-20-000003:notes:131]
[same as prior period, unchanged from 0001633978-19-000071:notes:123]

[0001633978-20-000003:notes:132]
On December 10, 2018, we completed the acquisition of Oclaro. We recognized goodwill in the amount of $357.6 million for the acquisition of Oclaro and allocated it to our OpComms segment. There have been no measurement periods or other adjustments to goodwill during the three and six months ended December 28, 2019. The following table presents our goodwill balance by the reportable segments as of December 28, 2019 (in millions):

[0001633978-20-000003:notes:133]
|  | Optical Communications |  | Commercial Lasers |  | Total |
| Balance as of December 28, 2019 | $ | 363.5 |  |  | $ | 5.4 |  |  | $ | 368.9 |  |

[0001633978-20-000003:notes:134]
[same as prior period, unchanged from 0001633978-19-000071:notes:126]

[0001633978-20-000003:notes:135]
We review goodwill for impairment during the fourth quarter of each fiscal year or more frequently if events or circumstances indicate that an impairment loss may have occurred. In the fourth quarter of fiscal 2019, we completed the annual impairment test of goodwill, which indicated there was no goodwill impairment. During the three and six months ended December 28, 2019, there have been no events or circumstances that have required us to perform an interim assessment of goodwill for impairment.

[0001633978-20-000003:notes:136]
[same as prior period, unchanged from 0001633978-19-000071:notes:128]

[0001633978-20-000003:notes:137]
In connection with our acquisition of Oclaro in fiscal year 2019, we recorded $443.0 million as the fair value of the acquired developed technologies and other intangible assets. This amount excludes $1.0 million of in-process research and development assets that were subsequently sold to CIG. Refer to “Note 4. Business Combinations”.

[0001633978-20-000003:notes:138]
[same as prior period, unchanged from 0001633978-19-000071:notes:131]

[0001633978-20-000003:notes:139]
The following tables present details of our other intangibles, including those acquired in connection with the Oclaro acquisition, as of the periods presented (in millions, except for weighted average remaining amortization period):

[0001633978-20-000003:notes:140]
| December 28, 2019 | Gross Carrying Amounts |  | Accumulated Amortization |  | Net Carrying Amounts |  | Weighted average remaining amortization period (years) |
| Acquired developed technologies (1) | $ | 339.5 |  |  | $ | (148.1 | ) |  | $ | 191.4 |  |  | 3.8 |
| Customer relationships | 149.3 |  |  | (24.7 | ) |  | 124.6 |  |  | 7.0 |
| In-process research and development (1) | 42.0 |  |  | — |  |  | 42.0 |  |  | n/a |
| Order backlog | 22.0 |  |  | (22.0 | ) |  | — |  |  | — |
| Other intangibles | 2.7 |  |  | (2.7 | ) |  | — |  |  | — |
| Total intangible assets | $ | 555.5 |  |  | $ | (197.5 | ) |  | $ | 358.0 |  |  |  |

[0001633978-20-000003:notes:141]
(1) In the second quarter of fiscal year 2020, we completed $52 million of IPR&D projects and reclassified the value assigned to them to acquired developed technologies. The amount will be amortized over the assets’ estimated useful life of 4 to 5 years.

[0001633978-20-000003:notes:142]
| June 29, 2019 | Gross Carrying Amounts |  | Accumulated Amortization |  | Net Carrying Amounts |  | Weighted average remaining amortization period (years) |
| Acquired developed technologies | $ | 287.5 |  |  | $ | (125.2 | ) |  | $ | 162.3 |  |  | 3.8 |
| Customer relationships | 149.3 |  |  | (12.3 | ) |  | 137.0 |  |  | 7.5 |
| In-process research and development | 94.0 |  |  | — |  |  | 94.0 |  |  | n/a |
| Order backlog | 22.0 |  |  | (19.9 | ) |  | 2.1 |  |  | 0.5 |
| Other intangibles | 2.7 |  |  | (2.7 | ) |  | — |  |  | — |
| Total intangible assets | $ | 555.5 |  |  | $ | (160.1 | ) |  | $ | 395.4 |  |  |  |

[0001633978-20-000003:notes:143]
[same as prior period, unchanged from 0001633978-19-000071:notes:136]

[0001633978-20-000003:notes:144]
|  | Three Months Ended |  | Six Months Ended |
|  | December 28, 2019 |  | December 29, 2018 |  | December 28, 2019 |  | December 29, 2018 |
| Cost of sales | $ | 12.4 |  |  | $ | 4.4 |  |  | $ | 24.9 |  |  | $ | 5.2 |  |
| Selling, general and administrative | 6.2 |  |  | 0.8 |  |  | 12.5 |  |  | 0.8 |  |
| Total amortization of intangibles | $ | 18.6 |  |  | $ | 5.2 |  |  | $ | 37.4 |  |  | $ | 6.0 |  |

[0001633978-20-000003:notes:145]
Based on the carrying amount of our acquired developed technologies and other intangibles, excluding IPR&D, as of December 28, 2019, and assuming no future impairment of the underlying assets, the estimated future amortization is as follows (in millions):

[0001633978-20-000003:notes:146]
| Fiscal Years |  |
| Remainder of 2020 | $ | 39.7 |  |
| 2021 | 77.2 |  |
| 2022 | 74.6 |  |
| 2023 | 51.1 |  |
| 2024 | 32.0 |  |
| Thereafter | 41.4 |  |
| Total future amortization | $ | 316.0 |  |


## lite:NoncontrollingInterestAndDerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001633978-20-000003:notes:147]
Note 11. Non-Controlling Interest Redeemable Convertible Preferred Stock and Derivative Liability

[0001633978-20-000003:notes:148]
[same as prior period, unchanged from 0001633978-19-000071:notes:140]

[0001633978-20-000003:notes:149]
[same as prior period, unchanged from 0001633978-19-000071:notes:141]

[0001633978-20-000003:notes:150]
[same as prior period, unchanged from 0001633978-19-000071:notes:142]

[0001633978-20-000003:notes:151]
Through the date of conversion, the Series A Preferred Stock conversion feature was bifurcated from the Series A Preferred Stock and accounted for separately as a derivative liability. The derivative liability was measured at fair value each reporting period, and at the date of conversion, with the change in fair value recorded in the condensed consolidated statements of operations.

[0001633978-20-000003:notes:152]
Through the date of conversion, holders of Series A Preferred Stock, in preference to holders of common stock or any other class or series of our outstanding capital stock ranking in any such event junior to the Series A Preferred Stock, were entitled to receive, when and as declared by the board of directors, quarterly cumulative cash dividends at the annual rate of 2.5% of the Issuance Value per share on each outstanding share of Series A Preferred Stock. The accrued dividends were payable on March 31, June 30, September 30 and December 31 of each year commencing on September 30, 2015. The accrued dividends as of November 2, 2018, the effective date of the conversion of all outstanding Series A Preferred Stock, was $0.3 million. During the three months ended December 29, 2018, we paid $0.4 million in dividends to the holders of Series A Preferred Stock.

[0001633978-20-000003:notes:153]
Prior to the conversion of the Series A Preferred Stock on November 2, 2018, we marked to market the embedded derivative, resulting in a gain of $10.9 million in our second quarter of fiscal 2019. In connection with the conversion of the Series A Preferred Stock on November 2, 2018, we also recorded $79.4 million in additional paid in capital which is reflected within the condensed consolidated balance sheets as of December 28, 2019 and June 29, 2019. For the six months ended December 29, 2018, we recorded $8.8 million  unrealized gain to our condensed consolidated statements of operations.


## us-gaap:DebtDisclosureTextBlock

[0001633978-20-000003:notes:154]
Note 12. Debt

[0001633978-20-000003:notes:155]
Convertible Notes

[0001633978-20-000003:notes:156]
2026 Notes

[0001633978-20-000003:notes:157]
In December 2019, we issued $1,050.0 million in aggregate principal amount of the 2026 Notes in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act of 1933, as amended (the “Securities Act”). The 2026 Notes are governed by an indenture between the Company and U.S. Bank National Association (the “2026 Indenture”). We used approximately $196 million of the net proceeds of the offering to repay in full all amounts outstanding under our term loan credit facility, and a portion of the net proceeds of the offering to purchase approximately $200 million of our common stock concurrently with the pricing of the offering in privately negotiated transactions. The 2026 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001633978-20-000003:notes:158]
The 2026 Notes will bear interest at a rate of 0.50% per year, payable semi-annually in arrears on June 15 and December 15 of each year, beginning on June 15, 2020. The 2026 Notes will mature on December 15, 2026, unless earlier redeemed, repurchased by us, or converted pursuant to their terms.

[0001633978-20-000003:notes:159]
The initial conversion rate is 10.0711 shares of common stock per $1,000 principal amount of the 2026 Notes (which is equivalent to an initial conversion price of approximately $99.29 per share). The conversion rate is subject to adjustment upon the occurrence of certain specified events but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert the 2026 Notes in connection with such make-whole fundamental change or notice of redemption.

[0001633978-20-000003:notes:160]
Prior to the close of business on the business day immediately preceding September 15, 2026, holders of the 2026 Notes may convert their 2026 Notes only under the following circumstances:

[0001633978-20-000003:notes:161]
| • | during any fiscal quarter commencing after the fiscal quarter ended on March 28, 2020 (and only during such fiscal quarter), if the last reported sale price of the common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price of the 2026 Notes on each applicable trading day; |

[0001633978-20-000003:notes:162]
| • | during the five business day period after any five consecutive trading day period (the "2026 measurement period") in which the trading price per $1,000 principal amount of the 2026 Notes for each trading day of the 2026 measurement period was less than 98% of the product of the last reported sale price of our common stock and the conversion rate for the notes on each such trading day; |

[0001633978-20-000003:notes:163]
| • | if we call any or all of the 2026 Notes for redemption, at any time prior to the close of business on the second business day immediately preceding the relevant redemption date; or |

[0001633978-20-000003:notes:164]
| • | upon the occurrence of specified corporate events, as specified in each indenture governing the 2026 Notes. |

[0001633978-20-000003:notes:165]
On or after September 15, 2026 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert the 2026 Notes at any time. Upon conversion, we may satisfy our conversion obligation in cash, shares of common stock or a combination of cash and shares of common stock, at our election.

[0001633978-20-000003:notes:166]
We may redeem for cash, stock or combination of both for all or any portion of the 2026 Notes, at our option, on or after December 20, 2023, if the last reported sale price of its common stock has been at least 130% of the conversion price then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading-day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which we provide a notice of redemption at a redemption price equal to 100% of the principal amount of the 2026 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. No sinking fund is provided for the 2026 Notes. Upon the occurrence of a fundamental change (as defined in the 2026 Indenture), holders may require us to repurchase all or a portion of the 2026 Notes for cash at a price equal to 100% of the principal amount of the 2026 Notes to be repurchased, plus any accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

[0001633978-20-000003:notes:167]
In accordance with accounting for debt with conversions and other options, we bifurcated the principal amount of the 2026 Notes into liability and equity components. The liability component of the 2026 Notes was valued at $734.8 million based on the contractual cash flows discounted at an appropriate comparable market non-convertible debt borrowing rate at the date of issuance of 5.8% with the equity component representing the residual amount of the proceeds of $315.2 million, which was recorded as a debt discount.

[0001633978-20-000003:notes:168]
We incurred approximately $7.8 million in transaction costs in connection with the issuance of the 2026 Notes and these costs were allocated pro rata based on the relative carrying amounts of the liability and equity components. The debt discount and debt issuance costs attributable to the liability component will be amortized to interest expense using an effective interest rate of 5.8% over the expected life of the 2026 Notes. Debt issuance costs attributable to the equity component are netted with the equity component in stockholders’ equity, and the equity component is not remeasured as long as it continues to meet the conditions for equity classification.

[0001633978-20-000003:notes:169]
2024 Notes

[0001633978-20-000003:notes:170]
In March 2017, we issued the 2024 Notes in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act. The 2024 Notes are governed by an indenture between the Company, as the issuer, and U.S. Bank National Association, as trustee (the “2024 Indenture”). The 2024 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001633978-20-000003:notes:171]
The 2024 Notes bear interest at a rate of 0.25% per year. Interest on the 2024 Notes is payable semi-annually in arrears on March 15 and September 15 of each year, beginning on September 15, 2017. The 2024 Notes will mature on March 15, 2024, unless earlier repurchased by us or converted pursuant to their terms.

[0001633978-20-000003:notes:172]
The initial conversion rate of the 2024 Notes is 16.4965 shares of common stock per $1,000 principal amount of 2024 Notes, which is equivalent to an initial conversion price of approximately $60.62 per share, a 132.5% premium to the fair market value at the date of issuance.

[0001633978-20-000003:notes:173]
Prior to the close of business on the business day immediately preceding December 15, 2023, each holder of the 2024 Notes may convert their 2024 Notes only under the following circumstances:

[0001633978-20-000003:notes:174]
| • | during any fiscal quarter (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during the period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price, or $78.80 on each applicable trading day; |

[0001633978-20-000003:notes:175]
| • | during the five consecutive business day period after any five consecutive trading day period (the “measurement period”) in which the trading price per $1,000 principal amount of notes for each trading day of such measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate on each such trading day; or |

[0001633978-20-000003:notes:176]
| • | upon the occurrence of specified corporate events. |

[0001633978-20-000003:notes:177]
On or after December 15, 2023 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their 2024 Notes at any time. In addition, upon the occurrence of a make-whole fundamental

[0001633978-20-000003:notes:178]
change  (as defined in the 2024 Indenture), we will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert 2024 Notes in connection with such make-whole fundamental change.

[0001633978-20-000003:notes:179]
We may not redeem the 2024 Notes prior to their maturity date and no sinking fund is provided for the 2024 Notes. Upon the occurrence of a fundamental change, holders may require us to repurchase all or a portion of their 2024 Notes for cash at a price equal to 100% of the principal amount of the 2024 Notes to be repurchased, plus any accrued and unpaid interest.

[0001633978-20-000003:notes:180]
We considered the features embedded in the 2024 Notes other than the conversion feature, including the holders’ put feature, our call feature, and the make-whole feature, and concluded that they are not required to be bifurcated and accounted for separately from the host debt instrument.

[0001633978-20-000003:notes:181]
Prior to the Tax Matters Agreement settlement condition (“TMA settlement condition”), because we could only settle the 2024 Notes in cash, we determined that the conversion feature met the definition of a derivative liability. We separated the derivative liability from the host debt instrument based on the fair value of the derivative liability. As of the issuance date, March 8, 2017, the derivative liability fair value of $129.9 million was calculated using the binomial valuation approach. The residual principal amount of the 2024 Notes of $320.1 million before issuance costs was allocated to the debt component. We incurred approximately $7.7 million in transaction costs in connection with the issuance of the 2024 Notes. These costs were allocated to the debt component and recognized as a debt discount. We amortize the debt discount, including both the initial value of the derivative liability and the transaction costs, over the term of the 2024 Notes using the effective interest method. The effective interest rate of the 2024 Notes is 5.4% per year.

[0001633978-20-000003:notes:182]
During the fiscal year ended July 1, 2017, we satisfied the TMA settlement condition. As such, the value of the conversion option will no longer be marked to market and was reclassified to additional paid-in capital within stockholders’ equity on our condensed consolidated balance sheet. The value of the conversion option at the time of issuance will be treated as an original issue discount for purposes of accounting for the debt component of the 2024 Notes. The debt component will accrete up to the principal amount over the expected term of the debt.

[0001633978-20-000003:notes:183]
Our convertible notes consisted of the following components as of the periods presented (in millions):

[0001633978-20-000003:notes:184]
| Liability component: | December 28, 2019 |  | June 29, 2019 |
|  | 2024 Notes |  | 2026 Notes |  | 2024 Notes |
| Principal | $ | 450.0 |  |  | $ | 1,050.0 |  |  | $ | 450.0 |  |
| Unamortized debt discount and debt issuance costs | (88.9 | ) |  | (319.1 | ) |  | (98.1 | ) |
| Net carrying amount of the liability component | $ | 361.1 |  |  | $ | 730.9 |  |  | $ | 351.9 |  |

[0001633978-20-000003:notes:185]
The following table sets forth interest expense information related to the convertible notes for the periods presented (in millions, except percentages):

[0001633978-20-000003:notes:186]
|  | Three Months Ended |  | Six Months Ended |
|  | December 28, 2019 |  | December 29, 2018 |  | December 28, 2019 |  | December 29, 2018 |
| Contractual interest expense | $ | 0.5 |  |  | $ | 0.3 |  |  | $ | 0.7 |  |  | $ | 0.6 |  |
| Amortization of the debt discount and debt issuance costs | 6.2 |  |  | 4.4 |  |  | 10.8 |  |  | 8.7 |  |
| Total interest expense | $ | 6.7 |  |  | $ | 4.7 |  |  | $ | 11.5 |  |  | $ | 9.3 |  |

[0001633978-20-000003:notes:187]
The future interest and principal payments related to our convertible notes are as follows as of December 28, 2019 (in millions):

[0001633978-20-000003:notes:188]
| Fiscal Years | 2024 Notes |  | 2026 Notes |  | Total |
| Remainder of 2020 | $ | 0.5 |  |  | $ | 2.7 |  |  | $ | 3.2 |  |
| 2021 | 1.1 |  |  | 5.2 |  |  | 6.3 |  |
| 2022 | 1.1 |  |  | 5.3 |  |  | 6.4 |  |
| 2023 | 1.1 |  |  | 5.2 |  |  | 6.3 |  |
| 2024 | 451.2 |  |  | 5.3 |  |  | 456.5 |  |
| Thereafter | — |  |  | 1,063.1 |  |  | 1,063.1 |  |
| Total convertible notes payments | $ | 455.0 |  |  | $ | 1,086.8 |  |  | $ | 1,541.8 |  |

[0001633978-20-000003:notes:189]
Term Loan Facility

[0001633978-20-000003:notes:190]
On December 10, 2018 (the “Closing Date”), concurrent with the closing of the Oclaro merger, we entered into a Credit and Guarantee Agreement (the “Credit Agreement”), by and among us, certain of our subsidiaries, the lenders party thereto, and Deutsche Bank, as administrative agent and collateral agent for the lenders. The Credit Agreement provides for a senior secured term loan facility (the “Term Loan Facility”) in an aggregate principal amount of $500.0 million. The term loans available under the Term Loan Facility were fully drawn on the Closing Date and the proceeds of the term loans were used to consummate the merger and pay fees and expenses in connection with the merger and the Term Loan Facility.

[0001633978-20-000003:notes:191]
In fiscal 2019, we incurred $9.3 million of debt issuance costs in connection with the Term Loan Facility which were capitalized and recorded as a contra liability in our condensed consolidated balance sheet. These costs were amortized to interest expense using the effective interest rate method from the issuance date of December 10, 2018.

[0001633978-20-000003:notes:192]
In the second quarter of fiscal 2020, we repaid, in full, all amounts outstanding under our Term Loan Facility. We incurred $8.0 million loss for the unamortized debt issuance costs as a result of this full repayment.

[0001633978-20-000003:notes:193]
The following table sets forth interest expense information related to the term loan for the periods presented (in millions):

[0001633978-20-000003:notes:194]
|  | Three Months Ended |  | Six Months Ended |
|  | December 28, 2019 |  | December 29, 2018 |  | December 28, 2019 |  | December 29, 2018 |
| Contractual interest expense | $ | 3.4 |  |  | $ | 3.7 |  |  | $ | 9.6 |  |  | $ | 4.1 |  |
| Amortization of the debt issuance costs | 0.2 |  |  | 0.1 |  |  | 0.5 |  |  | 0.1 |  |
| Loss on early extinguishment of debt | 8.0 |  |  | — |  |  | 8.0 |  |  | — |  |
| Total interest expense | $ | 11.6 |  |  | $ | 3.8 |  |  | $ | 18.1 |  |  | $ | 4.2 |  |

[0001633978-20-000003:notes:195]
For the six months ended December 28, 2019, we also recorded $0.1 million interest expense related to our finance leases.

[0001633978-20-000003:notes:196]
The following table sets forth balance sheet information related to the term loan as of the periods presented (in millions):

[0001633978-20-000003:notes:197]
|  | December 28, 2019 |  | June 29, 2019 |
| Principal | $ | 497.5 |  |  | $ | 500.0 |  |
| Repayment of principal | (497.5 | ) |  | (2.5 | ) |
| Unamortized value of the debt issuance costs | — |  |  | (8.5 | ) |
| Net carrying value | $ | — |  |  | $ | 489.0 |  |
| Term loan, current | $ | — |  |  | $ | 5.0 |  |
| Term loan, non-current | $ | — |  |  | $ | 484.0 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001633978-20-000003:notes:198]
[same as prior period, unchanged from 0001633978-19-000071:notes:180]

[0001633978-20-000003:notes:199]
[same as prior period, unchanged from 0001633978-19-000071:notes:181]

[0001633978-20-000003:notes:200]
[same as prior period, unchanged from 0001633978-19-000071:notes:182]

[0001633978-20-000003:notes:201]
|  | Foreign currency translation adjustments, net of tax (1) |  | Defined benefit obligations, net of tax (2) |  | Unrealized gain (loss) on available-for-sale securities, net of tax (3) |  | Total |
| Beginning balance as of June 29, 2019 | $ | 9.7 |  |  | $ | (3.5 | ) |  | $ | 0.9 |  |  | $ | 7.1 |  |
| Other comprehensive income (4) | — |  |  | — |  |  | 0.1 |  |  | 0.1 |  |
| Ending balance as of September 28, 2019 | 9.7 |  |  | (3.5 | ) |  | 1.0 |  |  | 7.2 |  |
| Other comprehensive loss | — |  |  | — |  |  | (0.2 | ) |  | (0.2 | ) |
| Ending balance as of December 28, 2019 | $ | 9.7 |  |  | $ | (3.5 | ) |  | $ | 0.8 |  |  | $ | 7.0 |  |
| Beginning balance as of June 30, 2018 | $ | 10.3 |  |  | $ | (2.3 | ) |  | $ | (1.6 | ) |  | $ | 6.4 |  |
| Other comprehensive income (4) | 0.1 |  |  | — |  |  | 0.4 |  |  | 0.5 |  |
| Ending balance as of September 29, 2018 | 10.4 |  |  | (2.3 | ) |  | (1.2 | ) |  | 6.9 |  |
| Other comprehensive income (loss) | (0.7 | ) |  | (0.1 | ) |  | 0.1 |  |  | (0.7 | ) |
| Ending balance as of December 29, 2018 | $ | 9.7 |  |  | $ | (2.4 | ) |  | $ | (1.1 | ) |  | $ | 6.2 |  |

[0001633978-20-000003:notes:202]
[same as prior period, unchanged from 0001633978-19-000071:notes:184]

[0001633978-20-000003:notes:203]
[same as prior period, unchanged from 0001633978-19-000071:notes:185]

[0001633978-20-000003:notes:204]
(3) As of June 29, 2019 and September 28, 2019, unrealized gain on available-for-sale securities is presented in the table above as net of tax of $0.2 million.

[0001633978-20-000003:notes:205]
[same as prior period, unchanged from 0001633978-19-000071:notes:187]


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001633978-20-000003:notes:206]
[same as prior period, unchanged from 0001633978-19-000071:notes:188]

[0001633978-20-000003:notes:207]
[same as prior period, unchanged from 0001633978-19-000071:notes:189]

[0001633978-20-000003:notes:208]
The following table summarizes the activity of restructuring and related charges during the three and six months ended December 28, 2019 and December 29, 2018 (in millions):

[0001633978-20-000003:notes:209]
|  | Three Months Ended |  | Six Months Ended |
|  | December 28, 2019 |  | December 29, 2018 |  | December 28, 2019 |  | December 29, 2018 |
| Balance as of beginning of period | $ | 10.7 |  |  | $ | 1.6 |  |  | $ | 14.6 |  |  | $ | 1.9 |  |
| Charges | 0.9 |  |  | 7.8 |  |  | 2.2 |  |  | 9.1 |  |
| Payments | (6.6 | ) |  | (5.9 | ) |  | (11.8 | ) |  | (7.5 | ) |
| Balance as of end of period | $ | 5.0 |  |  | $ | 3.5 |  |  | $ | 5.0 |  |  | $ | 3.5 |  |

[0001633978-20-000003:notes:210]
During the three and six months ended December 28, 2019, we recorded $0.9 million and $2.2 million, respectively, in restructuring and related charges in our condensed consolidated statements of operations. The charges were mainly attributable to severance charges associated with ongoing acquisition related synergies.

[0001633978-20-000003:notes:211]
During the three and six months ended December 29, 2018, we recorded $7.8 million and $9.1 million, respectively, in restructuring and related charges in our condensed consolidated statements of operations, primarily attributable to severance and employee related benefits associated with Oclaro’s executive severance and retention agreements. These retention agreements provided, under certain circumstances, for payments and benefits upon an involuntary termination of employment. We made $5.7 million of payments in connection with these agreements during the three and six months ended December 29, 2018. We also

[0001633978-20-000003:notes:212]
implemented an internal reorganization in order to extend our market leadership position by strengthening product quality, to develop new enabling technologies required to support a long-term portfolio roadmap, and to develop commercial proposals and new product introduction priorities to maintain and grow our position while driving new customer and ecosystem partner engagements. In connection with this reorganization, we recorded restructuring and related charges of $1.3 million during the three and six months ended December 29, 2018 related to severance and employee related benefits.

[0001633978-20-000003:notes:213]
[same as prior period, unchanged from 0001633978-19-000071:notes:195]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001633978-20-000003:notes:214]
[same as prior period, unchanged from 0001633978-19-000071:notes:196]

[0001633978-20-000003:notes:215]
[same as prior period, unchanged from 0001633978-19-000071:notes:197]

[0001633978-20-000003:notes:216]
We recorded a tax provision of $8.6 million and $14.4 million for the three and six months ended December 28, 2019, respectively. Our estimated effective tax rate for the fiscal 2020 differs from the 21% U.S. statutory rate primarily due to the income tax benefit of the earnings of our foreign subsidiaries being taxed at rates that differ from the U.S. statutory rate as well as the U.S. federal R&D and foreign  tax credits, partially offset by the income tax expense from non-deductible stock-based compensation and the tax effect of Global Intangible Low-Taxed Income (“GILTI”), Base Erosion and Anti-Abuse Tax (“BEAT”), and subpart F inclusion.

[0001633978-20-000003:notes:217]
As of December 28, 2019, we had $19.0 million of unrecognized tax benefits, which, if recognized, would affect the effective tax rate. We are subject to examination of income tax returns by various domestic and foreign tax authorities. The timing of commencement, resolution and closure of tax audits is highly unpredictable. Although it is possible that certain ongoing tax audits may be concluded within the next 12 months, we cannot reasonably estimate the impact to tax expense and net income from tax exams that could be resolved or closed within the next 12 months. Subject to audit timing and uncertainty, we expect our unrecognized tax benefit amount that could affect the effective tax rate to decrease by $5.3 million over the next 12 months.

[0001633978-20-000003:notes:218]
[same as prior period, unchanged from 0001633978-19-000071:notes:200]

[0001633978-20-000003:notes:219]
On June 7, 2019, the U.S. Court of Appeals for the Ninth Circuit, reversing a previous decision of the U.S. Tax Court, held that the U.S. Treasury Department’s regulations requiring the inclusion of stock-based compensation expense in a taxpayer’s cost-sharing calculations were valid. On November 12, 2019, the U.S. Court of Appeals for the Ninth Circuit denied the en banc rehearing request filed by the taxpayer on July 22, 2019. Our financial statements have been prepared consistent with this outcome, but we will continue to monitor any ongoing developments, including a potential appeal to the U.S. Supreme Court, to determine if future changes are required.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001633978-20-000003:notes:220]
Note 16. Stockholders' Equity

[0001633978-20-000003:notes:221]
[same as prior period, unchanged from 0001633978-19-000071:notes:204]

[0001633978-20-000003:notes:222]
[same as prior period, unchanged from 0001633978-19-000071:notes:205]

[0001633978-20-000003:notes:223]
As of December 28, 2019, we had 2.6 million shares subject to stock options, restricted stock units, restricted stock awards, and performance stock units issued and outstanding under the 2015 Equity Incentive Plan (the “2015 Plan”).

[0001633978-20-000003:notes:224]
[same as prior period, unchanged from 0001633978-19-000071:notes:207]

[0001633978-20-000003:notes:225]
As of December 28, 2019, 3.6 million shares of common stock under the 2015 Plan were available for grant.

[0001633978-20-000003:notes:226]
[same as prior period, unchanged from 0001633978-19-000071:notes:209]

[0001633978-20-000003:notes:227]
Restricted stock units (“RSUs”) under the 2015 Plan are grants of shares of our common stock, the vesting of which is based on the requisite service requirement. Generally, our RSUs are subject to forfeiture and are expected to vest over one to four years. For annual refresh grants, RSUs generally vest ratably on an annual, or combination of annual and quarterly, basis over three years.

[0001633978-20-000003:notes:228]
[same as prior period, unchanged from 0001633978-19-000071:notes:211]

[0001633978-20-000003:notes:229]
[same as prior period, unchanged from 0001633978-19-000071:notes:212]

[0001633978-20-000003:notes:230]
[same as prior period, unchanged from 0001633978-19-000071:notes:213]

[0001633978-20-000003:notes:231]
[same as prior period, unchanged from 0001633978-19-000071:notes:214]

[0001633978-20-000003:notes:232]
[same as prior period, unchanged from 0001633978-19-000071:notes:215]

[0001633978-20-000003:notes:233]
Our 2015 Employee Stock Purchase Plan (the “2015 Purchase Plan”) provides eligible employees with the opportunity to acquire an ownership interest in the Company through periodic payroll deductions and provides a 15% purchase price discount as well as a six-month look-back period. The 2015 Purchase Plan is structured as a qualified employee stock purchase plan under Section 423 of the Internal Revenue Code of 1986. The 2015 Purchase Plan will terminate upon the date on which all shares available for issuance have been sold. Of the 3.0 million shares authorized under the 2015 Purchase Plan, 1.9 million shares remained available for issuance as of December 28, 2019.

[0001633978-20-000003:notes:234]
Stock-Based Compensation Expense

[0001633978-20-000003:notes:235]
The impact on our results of operations of recording stock-based compensation by function for the three and six months ended December 28, 2019 was as follows (in millions):

[0001633978-20-000003:notes:236]
|  | Three Months Ended |  | Six Months Ended |
|  | December 28, 2019 |  | December 29, 2018 |  | December 28, 2019 |  | December 29, 2018 |
| Cost of sales | $ | 4.1 |  |  | $ | 5.2 |  |  | $ | 8.3 |  |  | $ | 8.5 |  |
| Research and development | 4.1 |  |  | 3.4 |  |  | 7.9 |  |  | 6.2 |  |
| Selling, general and administrative | 12.0 |  |  | 21.1 |  |  | 20.7 |  |  | 25.8 |  |
| Total stock-based compensation | $ | 20.2 |  |  | $ | 29.7 |  |  | $ | 36.9 |  |  | $ | 40.5 |  |

[0001633978-20-000003:notes:237]
[same as prior period, unchanged from 0001633978-19-000071:notes:221]

[0001633978-20-000003:notes:238]
|  | Three Months Ended |  | Six Months Ended |
|  | December 28, 2019 |  | December 29, 2018 |  | December 28, 2019 |  | December 29, 2018 |
| Income tax benefit associated with stock-based compensation | $ | 3.8 |  |  | $ | 3.8 |  |  | $ | 6.6 |  |  | $ | 6.6 |  |

[0001633978-20-000003:notes:239]
Approximately $3.4 million and $3.5 million of stock-based compensation was capitalized to inventory as of December 28, 2019 and June 29, 2019, respectively.

[0001633978-20-000003:notes:240]
Stock Award Activity

[0001633978-20-000003:notes:241]
The following table summarizes our awards activity for the six months ended December 28, 2019 (in millions, except per share amounts):

[0001633978-20-000003:notes:242]
|  |  | Restricted Stock Units |  | Restricted Stock Awards |  | Performance Stock Units |
|  |  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |
| Balance as of June 29, 2019 |  | 2.2 |  |  | $ | 52.4 |  |  | — |  |  | $ | 32.5 |  |  | 0.2 |  |  | $ | 56.0 |  |
| Granted |  | 1.0 |  |  | 59.0 |  |  | — |  |  | — |  |  | 0.2 |  |  | 61.9 |  |
| Vested/Exercised |  | (0.7 | ) |  | 52.9 |  |  | — |  |  | 32.5 |  |  | (0.1 | ) |  | 55.2 |  |
| Canceled |  | (0.2 | ) |  | 52.0 |  |  | — |  |  | — |  |  | — |  |  | 57.3 |  |
| Balance as of December 28, 2019 |  | 2.3 |  |  | $ | 55.2 |  |  | — |  |  | $ | — |  |  | 0.3 |  |  | $ | 59.6 |  |

[0001633978-20-000003:notes:243]
As of December 28, 2019, $134.0 million of stock-based compensation cost related to awards granted to our employees remains to be amortized. That cost is expected to be recognized over an estimated amortization period of 2.0 years.

[0001633978-20-000003:notes:244]
[same as prior period, unchanged from 0001633978-19-000071:notes:228]

[0001633978-20-000003:notes:245]
|  | Awards Available for Grant |
| Balance as of June 29, 2019 | 4.7 |  |
| Granted | (1.2 | ) |
| Canceled | 0.1 |  |
| Balance as of December 28, 2019 | 3.6 |  |

[0001633978-20-000003:notes:246]
[same as prior period, unchanged from 0001633978-19-000071:notes:230]

[0001633978-20-000003:notes:247]
The 2015 Purchase Plan expense for each of the three months ended December 28, 2019 and December 29, 2018 was $0.8 million. The 2015 Purchase Plan expense for the six months ended December 28, 2019 and December 29, 2018 was $1.7 million and $1.8 million, respectively.  The expense related to the 2015 Purchase Plan is recorded on a straight-line basis over the relevant subscription period. During the three and six months ended December 28, 2019 there were 0.1 million shares issued to employees through the 2015 Purchase Plan.

[0001633978-20-000003:notes:248]
We estimate the fair value of the 2015 Purchase Plan shares on the date of grant using the Black-Scholes option-pricing model. During each of the three and six months ended December 28, 2019 and December 29, 2018, the assumptions used to estimate the fair value of the 2015 Purchase Plan shares to be issued were as follows:

[0001633978-20-000003:notes:249]
|  | December 28, 2019 |  | December 29, 2018 |
| Expected term (years) | 0.5 |  |  | 0.5 |  |
| Expected volatility | 44.6 | % |  | 71.3 | % |
| Risk-free interest rate | 1.59 | % |  | 2.52 | % |
| Dividend yield | — | % |  | — | % |

[0001633978-20-000003:notes:250]
Repurchase and Retirement of Common Stock

[0001633978-20-000003:notes:251]
In the second quarter of fiscal year 2020, concurrently with the issuance of the 2026 Notes, we repurchased 2.9 million shares of our common stock in privately negotiated transactions at an average price of $69.68 per share for an aggregate purchase price of $200 million. These shares were retired immediately.


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0001633978-20-000003:notes:252]
Note 17. Commitments and Contingencies

[0001633978-20-000003:notes:253]
Acquisition Contingencies

[0001633978-20-000003:notes:254]
In February 2017, as a result of the acquisition of a privately held company, we incurred the contingent liability of $3.0 million. This liability is recorded in other current liabilities within our condensed consolidated balance sheet as of December 28, 2019.

[0001633978-20-000003:notes:255]
Purchase Obligations

[0001633978-20-000003:notes:256]
Purchase obligations of $289.5 million as of December 28, 2019, represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements.

[0001633978-20-000003:notes:257]
Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule and adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

[0001633978-20-000003:notes:258]
We depend on a limited number of contract manufacturers, subcontractors and suppliers for raw materials, packages and standard components. We generally purchase these single or limited source products through standard purchase orders or one-year supply agreements and have no significant long-term guaranteed supply agreements with such vendors. While we seek to maintain a sufficient safety stock of such products and maintain on-going communications with our suppliers to guard against interruptions or cessation of supply, our business and results of operations could be adversely affected by a stoppage or delay of supply, substitution of more expensive or less reliable products, receipt of defective parts or contaminated materials, increases in the price of such supplies, or our inability to obtain reduced pricing from our suppliers in response to competitive pressures.

[0001633978-20-000003:notes:259]
Product Warranties

[0001633978-20-000003:notes:260]
We provide reserves for the estimated costs of product warranties at the time revenue is recognized. We typically offer a twelve month warranty for most of our products. However, in some instances depending upon the product, product components or application of our products by the end customer, our warranties can vary and generally range from six months to five years. We estimate the costs of our warranty obligations on an annualized basis based on our historical experience of known product failure rates, use of materials to repair or replace defective products and service delivery costs incurred in correcting product failures. In addition, from time to time, specific warranty accruals may be made if unforeseen technical problems arise with specific products. We assess the adequacy of our recorded warranty liabilities and adjust the amounts as necessary.

[0001633978-20-000003:notes:261]
The following table presents the changes in our warranty reserve during the three and six months ended December 28, 2019 and December 29, 2018 (in millions):

[0001633978-20-000003:notes:262]
|  | Three Months Ended |  | Six Months Ended |
|  | December 28, 2019 |  | December 29, 2018 |  | December 28, 2019 |  | December 29, 2018 |
| Balance as of beginning of period | $ | 7.0 |  |  | $ | 6.6 |  |  | $ | 7.5 |  |  | $ | 6.6 |  |
| Warranties assumed in Oclaro acquisition | — |  |  | 3.8 |  |  | — |  |  | 3.8 |  |
| Provision for warranty | 0.6 |  |  | 0.7 |  |  | 1.8 |  |  | 1.9 |  |
| Utilization of reserve | (0.8 | ) |  | (1.4 | ) |  | (2.5 | ) |  | (2.6 | ) |
| Balance as of end of period | $ | 6.8 |  |  | $ | 9.7 |  |  | $ | 6.8 |  |  | $ | 9.7 |  |

[0001633978-20-000003:notes:263]
Environmental Liabilities

[0001633978-20-000003:notes:264]
Our research and development (“R&D”), manufacturing and distribution operations involve the use of hazardous substances and are regulated under international, federal, state and local laws governing health and safety and the environment. We apply strict standards for protection of the environment and occupational health and safety to sites inside and outside the United States, even if not subject to regulations imposed by foreign governments. We believe that our properties and operations at our facilities comply in all material respects with applicable environmental laws and occupational health and safety laws. However, the risk of environmental liabilities cannot be completely eliminated and there can be no assurance that the application of environmental and health and safety laws will not require us to incur significant expenditures. We are also regulated under a number of international, federal, state and local laws regarding recycling, product packaging and product content requirements. The environmental, product content/disposal and recycling laws are gradually becoming more stringent and may cause us to incur significant expenditures in the future.

[0001633978-20-000003:notes:265]
Legal Proceedings

[0001633978-20-000003:notes:266]
We are subject to a variety of claims and suits that arise from time to time in the ordinary course of our business. While management currently believes that resolving claims against us, individually or in the aggregate, will not have a material adverse impact on our financial position, results of operations or statements of cash flows, these matters are subject to inherent uncertainties and management’s view of these matters may change in the future. We accrue for loss contingencies when it is both probable that we will incur the loss and when we can reasonably estimate the amount of the loss or range of loss. As of December 28, 2019, we did not have any material claims or proceedings that were probable or reasonably possible.

[0001633978-20-000003:notes:267]
Merger Litigation

[0001633978-20-000003:notes:268]
In connection with our acquisition of Oclaro, seven lawsuits were filed by purported stockholders of Oclaro challenging the proposed merger (the “Merger”). Two of the seven suits were putative class actions filed against Oclaro, its directors, Lumentum, Prota Merger Sub, Inc. and Prota Merger, LLC: Nicholas Neinast v. Oclaro, Inc., et al., No. 3:18-cv-03112-VC, in the United States District Court for the Northern District of California (filed May 24, 2018) (the “Neinast Lawsuit”); and Adam Franchi v. Oclaro, Inc., et al., No. 1:18-cv-00817-GMS, in the United States District Court for the District of Delaware (filed June 9, 2018) (the “Franchi Lawsuit”). Both the Neinstat Lawsuit and the Franchi Lawsuit were voluntarily dismissed with prejudice.

[0001633978-20-000003:notes:269]
The other five suits, styled as Gerald F. Wordehoff v. Oclaro, Inc., et al., No. 5:18-cv-03148-NC (the “Wordehoff Lawsuit”), Walter Ryan v. Oclaro, Inc., et al., No. 3:18-cv-03174-VC (the “Ryan Lawsuit”), Jayme Walker v. Oclaro, Inc., et al., No. 5:18-cv-03203-EJD (the “Walker Lawsuit”), Kevin Garcia v. Oclaro, Inc., et al., No. 5:18-cv-03262-VKD (the “Garcia Lawsuit”), and SaiSravan B. Karri v. Oclaro, Inc., et al., No. 3:18-cv-03435-JD (the “Karri Lawsuit” and, together with the other six lawsuits, the “Lawsuits”), were filed in the United States District Court for the Northern District of California on May 25, 2018, May 29, 2018, May 30, 2018, May 31, 2018, and June 9, 2018, respectively. These five Lawsuits named Oclaro and its directors as defendants only and did not name Lumentum. The Wordehoff, Ryan, Walker, and Garcia Lawsuits have been voluntarily dismissed, and the Wordehoff, Ryan, and Walker dismissals were with prejudice. The Karri Lawsuit has not yet been dismissed. The Ryan Lawsuit was, and the Karri Lawsuit is, a putative class action.

[0001633978-20-000003:notes:270]
The Lawsuits generally alleged, among other things, that Oclaro and its directors violated Section 14(a) of the Securities Exchange Act of 1934, as amended (the “Exchange Act”), and Rule 14a-9 promulgated thereunder by disseminating an incomplete and misleading Form S-4, including proxy statement/prospectus. The Lawsuits further alleged that Oclaro’s directors violated Section 20(a) of the Exchange Act by failing to exercise proper control over the person(s) who violated Section 14(a) of the Exchange Act.

[0001633978-20-000003:notes:271]
The remaining Lawsuit (the Karri Lawsuit) currently purports to seek, among other things, damages to be awarded to the plaintiff and any class, if a class is certified, and litigation costs, including attorneys’ fees.  A lead plaintiff and counsel has been selected, and an amended complaint was filed on April 15, 2019, which also names Lumentum as a defendant.  A motion to dismiss the amended complaint has been fully briefed and is currently pending, and defendants intend to defend the Karri Lawsuit vigorously.

[0001633978-20-000003:notes:272]
Indemnifications

[0001633978-20-000003:notes:273]
In the normal course of business, we enter into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown because claims may be made against us in the future and we may record charges in the future as a result of these indemnification obligations. As of December 28, 2019, we did not have any material indemnification claims that were probable or reasonably possible.

[0001633978-20-000003:notes:274]
Audit Proceedings

[0001633978-20-000003:notes:275]
We are under audit by various domestic and foreign tax authorities with regards to income tax and indirect tax matters. In some, although not all cases, we have reserved for potential adjustments to our provision for income taxes and accrual of indirect taxes that may result from examinations by these tax authorities or final outcomes in judicial proceedings, and we believe that the final outcome of these examinations, agreements or judicial proceedings will not have a material effect on our results of operations. If events occur which indicate payment of these amounts is unnecessary, the reversal of the liabilities would result in the recognition of benefits in the period we determine the liabilities are no longer necessary. If our estimates of the federal, state, and foreign income tax liabilities and indirect tax liabilities are less than the ultimate assessment, it could result in a further charge to expense.

[0001633978-20-000003:notes:276]
In connection with our acquisition of Oclaro, we recorded $1.1 million in Malaysia Goods and Services Tax (“GST”) refund claims within prepaid expenses and other current assets in our condensed consolidated balance sheet. The refund claim represents an initial claim of $2.5 million of GST, net of reserves, that were previously denied by the Malaysian tax authorities in 2016. 
During the six months ended December 28, 2019, we were able to favorably resolve this audit and received refunds for all of our outstanding GST claims.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001633978-20-000003:notes:277]
[same as prior period, unchanged from 0001633978-19-000071:notes:265]

[0001633978-20-000003:notes:278]
[same as prior period, unchanged from 0001633978-19-000071:notes:266]

[0001633978-20-000003:notes:279]
[same as prior period, unchanged from 0001633978-19-000071:notes:267]

[0001633978-20-000003:notes:280]
[same as prior period, unchanged from 0001633978-19-000071:notes:268]

[0001633978-20-000003:notes:281]
[same as prior period, unchanged from 0001633978-19-000071:notes:269]

[0001633978-20-000003:notes:282]
|  | Three Months Ended |  | Six Months Ended |
|  | December 28, 2019 |  | December 29, 2018 |  | December 28, 2019 |  | December 29, 2018 |
| Net revenue: |  |  |  |  |  |  |  |
| OpComms | $ | 409.4 |  |  | $ | 325.4 |  |  | $ | 825.5 |  |  | $ | 635.5 |  |
| Lasers | 48.4 |  |  | 48.3 |  |  | 82.2 |  |  | 92.3 |  |
| Net revenue | $ | 457.8 |  |  | $ | 373.7 |  |  | $ | 907.7 |  |  | $ | 727.8 |  |
| Gross profit: |  |  |  |  |  |  |  |
| OpComms | $ | 196.4 |  |  | $ | 129.1 |  |  | $ | 388.3 |  |  | $ | 254.0 |  |
| Lasers | 20.4 |  |  | 20.6 |  |  | 34.6 |  |  | 38.3 |  |
| Total segment gross profit | 216.8 |  |  | 149.7 |  |  | 422.9 |  |  | 292.3 |  |
| Unallocated corporate items: |  |  |  |  |  |  |  |
| Stock-based compensation | (4.1 | ) |  | (5.2 | ) |  | (8.3 | ) |  | (8.5 | ) |
| Amortization of acquired intangibles | (12.4 | ) |  | (4.4 | ) |  | (24.9 | ) |  | (5.2 | ) |
| Amortization of fair value adjustments | (2.1 | ) |  | — |  |  | (4.3 | ) |  | — |  |
| Inventory write down and fixed asset impairment due to product lines exit | (2.6 | ) |  | — |  |  | (3.7 | ) |  | — |  |
| Integration related costs | — |  |  | — |  |  | (3.4 | ) |  | — |  |
| Other charges (1) | (6.5 | ) |  | (15.3 | ) |  | (21.5 | ) |  | (27.8 | ) |
| Gross profit | $ | 189.1 |  |  | $ | 124.8 |  |  | $ | 356.8 |  |  | $ | 250.8 |  |

[0001633978-20-000003:notes:283]
(1) “Other charges” of unallocated corporate items for the three and six months ended December 28, 2019 primarily include costs of transferring product lines to new production facilities, including Thailand of $2.0 million and $8.1 million, respectively. We also incurred excess and obsolete inventory charges driven by the decline in demand from Huawei of $6.0 million and $12.7 million during the three and six months ended December 28, 2019. During the three and six months ended December 29, 2018, “other charges” of unallocated corporate items including costs of transferring product lines to Thailand of $14.5 million and $27.2 million, respectively.

[0001633978-20-000003:notes:284]
[same as prior period, unchanged from 0001633978-19-000071:notes:272]

[0001633978-20-000003:notes:285]
[same as prior period, unchanged from 0001633978-19-000071:notes:273]

[0001633978-20-000003:notes:286]
[same as prior period, unchanged from 0001633978-19-000071:notes:274]

[0001633978-20-000003:notes:287]
|  | Three Months Ended |  | Six Months Ended |
|  | December 28, 2019 |  | December 29, 2018 |  | December 28, 2019 |  | December 29, 2018 |
| OpComms: |  |  |  |  |  |  |  |  |  |  |  |
| Telecom and Datacom | $ | 266.3 |  | 58.2 | % |  | $ | 205.9 |  | 55.1 | % |  | $ | 514.4 |  | 56.6 | % |  | $ | 383.0 |  | 52.6 | % |
| Consumer and Industrial | 143.1 |  | 31.2 |  |  | 119.5 |  | 32.0 |  |  | 311.1 |  | 34.3 |  |  | 252.5 |  | 34.7 |  |
| Total OpComms | $ | 409.4 |  | 89.4 | % |  | $ | 325.4 |  | 87.1 | % |  | $ | 825.5 |  | 90.9 | % |  | $ | 635.5 |  | 87.3 | % |
| Lasers | 48.4 |  | 10.6 |  |  | 48.3 |  | 12.9 |  |  | 82.2 |  | 9.1 |  |  | 92.3 |  | 12.7 |  |
| Total Revenue | $ | 457.8 |  |  |  |  | $ | 373.7 |  |  |  | $ | 907.7 |  |  |  | $ | 727.8 |  |  |

[0001633978-20-000003:notes:288]
[same as prior period, unchanged from 0001633978-19-000071:notes:276]

[0001633978-20-000003:notes:289]
|  | Three Months Ended |  | Six Months Ended |
|  | December 28, 2019 |  | December 29, 2018 |  | December 28, 2019 |  | December 29, 2018 |
|  | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States | $ | 43.4 |  |  | 9.5 | % |  | $ | 20.7 |  |  | 5.6 | % |  | $ | 80.3 |  |  | 8.8 | % |  | $ | 42.6 |  |  | 5.9 | % |
| Mexico | 26.2 |  |  | 5.7 |  |  | 55.0 |  |  | 14.7 |  |  | 55.1 |  |  | 6.1 |  |  | 111.3 |  |  | 15.3 |  |
| Other Americas | 0.7 |  |  | 0.2 |  |  | 0.9 |  |  | 0.2 |  |  | 1.8 |  |  | 0.2 |  |  | 1.8 |  |  | 0.2 |  |
| Total Americas | $ | 70.3 |  |  | 15.4 | % |  | $ | 76.6 |  |  | 20.5 | % |  | $ | 137.2 |  |  | 15.1 | % |  | $ | 155.7 |  |  | 21.4 | % |
| Asia-Pacific: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Hong Kong | $ | 144.5 |  |  | 31.6 | % |  | $ | 99.9 |  |  | 26.7 | % |  | $ | 278.3 |  |  | 30.7 | % |  | $ | 165.5 |  |  | 22.7 | % |
| South Korea | 85.0 |  |  | 18.6 |  |  | 61.3 |  |  | 16.4 |  |  | 176.6 |  |  | 19.5 |  |  | 131.3 |  |  | 18.0 |  |
| Japan | 42.1 |  |  | 9.2 |  |  | 43.2 |  |  | 11.6 |  |  | 74.6 |  |  | 8.2 |  |  | 79.2 |  |  | 10.9 |  |
| Other Asia-Pacific | 78.8 |  |  | 17.2 |  |  | 61.8 |  |  | 16.5 |  |  | 171.6 |  |  | 18.9 |  |  | 136.0 |  |  | 18.7 |  |
| Total Asia-Pacific | $ | 350.4 |  |  | 76.6 | % |  | $ | 266.2 |  |  | 71.2 | % |  | $ | 701.1 |  |  | 77.3 | % |  | $ | 512.0 |  |  | 70.3 | % |
| EMEA | $ | 37.1 |  |  | 8.0 | % |  | $ | 30.9 |  |  | 8.3 | % |  | $ | 69.4 |  |  | 7.6 | % |  | $ | 60.1 |  |  | 8.3 | % |
| Total net revenue | $ | 457.8 |  |  |  |  |  | $ | 373.7 |  |  |  |  |  | $ | 907.7 |  |  |  |  |  | $ | 727.8 |  |  |  |  |

[0001633978-20-000003:notes:290]
During the three and six months ended December 28, 2019, net revenue from customers outside the United States, based on customer shipping location, represented 90.5% and 91.2% of net revenue, respectively. Our net revenue from Hong Kong grew due to increased sales of our 3D sensing products for mobile devices shipped to one of our large customers.

[0001633978-20-000003:notes:291]
During the three and six months ended December 29, 2018, net revenue from customers outside the United States, based on customer shipping location, represented 94.4% and 94.1% of net revenue, respectively. Our net revenue from Hong Kong grew due to increased sales of our 3D sensing products for mobile devices shipped to one of our large customers.

[0001633978-20-000003:notes:292]
[same as prior period, unchanged from 0001633978-19-000071:notes:279]

[0001633978-20-000003:notes:293]
The following table includes estimated revenue expected to be recognized in the future for backlog related performance obligations that are unsatisfied as of December 28, 2019 (in millions):

[0001633978-20-000003:notes:294]
|  | Less than 1 year | 1-2 years | Greater than 2 years | Total |
| Performance obligations | $456.4 | $7.8 | $— | $464.2 |

[0001633978-20-000003:notes:295]
[same as prior period, unchanged from 0001633978-19-000071:notes:282]

[0001633978-20-000003:notes:296]
The following table reflects the changes in contract balances as of December 28, 2019 (in millions, except percentages):

[0001633978-20-000003:notes:297]
| Contract balances | Balance sheet location | December 28, 2019 |  | June 29, 2019 |  | Change |  | Percentage Change |
| Accounts receivable, net | Accounts receivable, net | $292.0 |  | $238.0 |  | $54.0 |  | 22.7% |
| Deferred revenue and customer deposits | Other current liabilities | $1.8 |  | $2.9 |  | $(1.1) |  | (37.9)% |

[0001633978-20-000003:notes:298]
During the three and six months ended December 28, 2019, our net revenue was concentrated with two customers, who collectively accounted for 41% and 44% of our total net revenue, respectively.

[0001633978-20-000003:notes:299]
During the three and six months ended December 29, 2018, our net revenue was concentrated with three customers, who collectively accounted for 55% and 57% of our total net revenue, respectively.

[0001633978-20-000003:notes:300]
As of December 28, 2019 and June 29, 2019, our accounts receivable balance was concentrated with three customers, who collectively represented 39% and 44% of gross accounts receivable, respectively.

[0001633978-20-000003:notes:301]
[same as prior period, unchanged from 0001633978-19-000071:notes:287]

[0001633978-20-000003:notes:302]
|  | December 28, 2019 |  | June 29, 2019 |
| Property, plant and equipment, net |  |  |  |
| United States | $ | 149.6 |  |  | $ | 156.2 |  |
| Thailand | 140.2 |  |  | 157.1 |  |
| China | 46.7 |  |  | 33.5 |  |
| Japan | 28.6 |  |  | 28.3 |  |
| Other countries | 55.9 |  |  | 58.2 |  |
| Total long-lived assets | $ | 421.0 |  |  | $ | 433.3 |  |

[0001633978-20-000003:notes:303]
We purchase a substantial portion of our inventory from contract manufacturers and vendors located primarily in Taiwan, Thailand, and Malaysia. During the three and six months ended December 28, 2019, net inventory purchases which represented 10% or greater of total net purchases, were concentrated with three and two contract manufacturers, who collectively accounted for 87% and 78% of total net inventory purchases, respectively. During the three and six months ended December 29, 2018, net inventory purchases were concentrated with three contract manufacturers, who collectively accounted for 87% and 85% of total net inventory purchases, respectively.
