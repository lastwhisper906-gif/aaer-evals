# LITE MD&A — 0001628280-25-004288


## mdna

[0001628280-25-004288:mdna:1]
[same as prior period, unchanged from 0001628280-24-046443:mdna:1]

[0001628280-25-004288:mdna:2]
[same as prior period, unchanged from 0001628280-24-046443:mdna:2]

[0001628280-25-004288:mdna:3]
[same as prior period, unchanged from 0001628280-24-046443:mdna:3]

[0001628280-25-004288:mdna:4]
43

[0001628280-25-004288:mdna:5]
[same as prior period, unchanged from 0001628280-24-046443:mdna:5]

[0001628280-25-004288:mdna:6]
[same as prior period, unchanged from 0001628280-24-046443:mdna:6]

[0001628280-25-004288:mdna:7]
[same as prior period, unchanged from 0001628280-24-046443:mdna:7]

[0001628280-25-004288:mdna:8]
[same as prior period, unchanged from 0001628280-24-046443:mdna:8]

[0001628280-25-004288:mdna:9]
[same as prior period, unchanged from 0001628280-24-046443:mdna:9]

[0001628280-25-004288:mdna:10]
[same as prior period, unchanged from 0001628280-24-046443:mdna:10]

[0001628280-25-004288:mdna:11]
[same as prior period, unchanged from 0001628280-24-046443:mdna:11]

[0001628280-25-004288:mdna:12]
[same as prior period, unchanged from 0001628280-24-046443:mdna:12]

[0001628280-25-004288:mdna:13]
[same as prior period, unchanged from 0001628280-24-046443:mdna:13]

[0001628280-25-004288:mdna:14]
[same as prior period, unchanged from 0001628280-24-046443:mdna:14]

[0001628280-25-004288:mdna:15]
[same as prior period, unchanged from 0001628280-24-046443:mdna:15]

[0001628280-25-004288:mdna:16]
[same as prior period, unchanged from 0001628280-24-046443:mdna:16]

[0001628280-25-004288:mdna:17]
[same as prior period, unchanged from 0001628280-24-046443:mdna:17]

[0001628280-25-004288:mdna:18]
[same as prior period, unchanged from 0001628280-24-046443:mdna:18]

[0001628280-25-004288:mdna:19]
Our business and our customers’ businesses were negatively impacted by worldwide logistics and supply chain issues during the COVID-19 pandemic, including constraints on available cargo capabilities and limited availability of once broadly available supplies of both raw materials and finished components. COVID-19 also created dynamics in the semiconductor component supply chains that have led to shortages of the types of components we and our customers require in our products. Although the supply chain constraints started to improve in the latter half of fiscal 2023, we felt its ongoing effects in fiscal 2024, as described below, and these constraints or effects may impact our ability to supply our products to our customers and may reduce our revenue and profit margin if they reoccur. In addition, if our customers are unable to procure needed semiconductor components, their demand for our products will decrease. Due to the global supply chain constraints, we have had to incur incremental supply and procurement costs in order to increase our ability to fulfill demands from our customers.

[0001628280-25-004288:mdna:20]
In addition, in response to component shortages, certain of our customers accumulated inventory that they began managing down in fiscal year 2024 as supply conditions improved. Customers who had built up large inventories when supply chains were tight brought down inventories as supply chain constraints eased and in some cases these customers delayed projected shipments, which caused our revenue to decline and our margins have been adversely impacted as we have not able to fully recover costs, such as underutilized manufacturing capacity. However, we have recently seen signs of inventory normalization at network equipment manufacturers since the first fiscal quarter of 2025 and have seen continued improvement in the second fiscal quarter of 2025.

[0001628280-25-004288:mdna:21]
[same as prior period, unchanged from 0001628280-24-046443:mdna:21]

[0001628280-25-004288:mdna:22]
[same as prior period, unchanged from 0001628280-24-046443:mdna:22]

[0001628280-25-004288:mdna:23]
[same as prior period, unchanged from 0001628280-24-046443:mdna:23]

[0001628280-25-004288:mdna:24]
[same as prior period, unchanged from 0001628280-24-046443:mdna:24]

[0001628280-25-004288:mdna:25]
[same as prior period, unchanged from 0001628280-24-046443:mdna:25]

[0001628280-25-004288:mdna:26]
[same as prior period, unchanged from 0001628280-24-046443:mdna:26]

[0001628280-25-004288:mdna:27]
[same as prior period, unchanged from 0001628280-24-046443:mdna:27]

[0001628280-25-004288:mdna:28]
[same as prior period, unchanged from 0001628280-24-046443:mdna:28]

[0001628280-25-004288:mdna:29]
Management’s Discussion and Analysis of Financial Condition and Results of Operations contained in Part II, Item 7 of our Annual Report on Form 10-K for our fiscal year ended June 29, 2024 provides a complete discussion of our critical accounting policies and estimates. There have been no changes to these policies during the three and six months ended December 28, 2024.

[0001628280-25-004288:mdna:30]
Recently Issued Accounting Pronouncements

[0001628280-25-004288:mdna:31]
Refer to “Note 2. Recently Issued Accounting Pronouncements” in the notes to condensed consolidated financial statements.

[0001628280-25-004288:mdna:32]
[same as prior period, unchanged from 0001628280-24-046443:mdna:32]

[0001628280-25-004288:mdna:33]
[same as prior period, unchanged from 0001628280-24-046443:mdna:33]

[0001628280-25-004288:mdna:34]
|  | Three Months Ended |  | Six Months Ended |
|  | December 28, 2024 |  | December 30, 2023 |  | December 28, 2024 |  | December 30, 2023 |
| Segment net revenue: |  |  |  |  |  |  |  |
| Cloud & Networking | 84.3 | % |  | 78.2 | % |  | 84.1 | % |  | 75.5 | % |
| Industrial Tech | 15.7 |  |  | 21.8 |  |  | 15.9 |  |  | 24.5 |  |
| Net revenue | 100.0 |  |  | 100.0 |  |  | 100.0 |  |  | 100.0 |  |
| Cost of sales | 69.9 |  |  | 76.7 |  |  | 70.0 |  |  | 73.6 |  |
| Amortization of acquired developed intangibles | 5.3 |  |  | 5.9 |  |  | 6.0 |  |  | 5.8 |  |
| Gross profit | 24.8 |  |  | 17.4 |  |  | 24.0 |  |  | 20.6 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 18.4 |  |  | 21.3 |  |  | 20.1 |  |  | 22.2 |  |
| Selling, general and administrative | 19.0 |  |  | 23.2 |  |  | 20.6 |  |  | 23.1 |  |
| Restructuring and related charges | 0.2 |  |  | 1.6 |  |  | 1.4 |  |  | 2.5 |  |
| Total operating expenses | 37.6 |  |  | 46.1 |  |  | 42.1 |  |  | 47.8 |  |
| Loss from operations | (12.8) |  |  | (28.7) |  |  | (18.1) |  |  | (27.2) |  |
| Interest expense | (1.4) |  |  | (2.7) |  |  | (1.5) |  |  | (2.8) |  |
| Other income, net | 3.7 |  |  | 3.7 |  |  | 3.2 |  |  | 5.0 |  |
| Loss before income taxes | (10.5) |  |  | (27.7) |  |  | (16.4) |  |  | (25.0) |  |
| Income tax provision (benefit) | 4.6 |  |  | (0.7) |  |  | 3.0 |  |  | (0.6) |  |
| Net loss | (15.1) | % |  | (27.0) | % |  | (19.4) | % |  | (24.4) | % |

[0001628280-25-004288:mdna:35]
47

[0001628280-25-004288:mdna:36]
Financial data for the three and six months ended December 28, 2024

[0001628280-25-004288:mdna:37]
[same as prior period, unchanged from 0001628280-24-046443:mdna:37]

[0001628280-25-004288:mdna:38]
|  | Three Months Ended |  | Six Months Ended |
|  | December 28, 2024 |  | December 30, 2023 |  | Change |  | Percentage Change |  | December 28, 2024 |  | December 30, 2023 |  | Change |  | Percentage Change |
| Segment net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cloud & Networking | $ | 339.2 |  |  | 286.7 |  |  | $ | 52.5 |  |  | 18.3 | % |  | $ | 621.5 |  |  | $ | 516.4 |  |  | $ | 105.1 |  |  | 20.4 | % |
| Industrial Tech | 63.0 |  |  | 80.1 |  |  | (17.1) |  |  | (21.3) | % |  | 117.6 |  |  | 168.0 |  |  | (50.4) |  |  | (30.0) | % |
| Net revenue | $ | 402.2 |  |  | $ | 366.8 |  |  | $ | 35.4 |  |  | 9.7 | % |  | $ | 739.1 |  |  | $ | 684.4 |  |  | $ | 54.7 |  |  | 8.0 | % |
| Gross profit | $ | 99.6 |  |  | $ | 64.0 |  |  | $ | 35.6 |  |  | 55.6 | % |  | $ | 177.5 |  |  | $ | 140.7 |  |  | $ | 36.8 |  |  | 26.2 | % |
| Gross margin | 24.8 | % |  | 17.4 | % |  |  |  |  |  | 24.0 | % |  | 20.6 | % |  |  |  |  |
| Research and development | $ | 74.2 |  |  | $ | 78.3 |  |  | $ | (4.1) |  |  | (5.2) | % |  | $ | 148.5 |  |  | $ | 151.8 |  |  | $ | (3.3) |  |  | (2.2) | % |
| Percentage of net revenue | 18.4 | % |  | 21.3 | % |  |  |  |  |  | 20.1 | % |  | 22.2 | % |  |  |  |  |
| Selling, general and administrative | $ | 76.3 |  |  | $ | 85.1 |  |  | $ | (8.8) |  |  | (10.3) | % |  | $ | 152.6 |  |  | $ | 158.1 |  |  | $ | (5.5) |  |  | (3.5) | % |
| Percentage of net revenue | 19.0 | % |  | 23.2 | % |  |  |  |  |  | 20.6 | % |  | 23.1 | % |  |  |  |  |
| Restructuring and related charges | $ | 0.7 |  |  | $ | 5.8 |  |  | $ | (5.1) |  |  | (87.9) | % |  | $ | 10.4 |  |  | $ | 16.8 |  |  | $ | (6.4) |  |  | (38.1) | % |
| Percentage of net revenue | 0.2 | % |  | 1.6 | % |  |  |  |  |  | 1.4 | % |  | 2.4 | % |  |  |  |  |

[0001628280-25-004288:mdna:39]
48

[0001628280-25-004288:mdna:40]
[same as prior period, unchanged from 0001628280-24-046443:mdna:40]

[0001628280-25-004288:mdna:41]
Net revenue increased by $35.4 million, or 9.7%, during the three months ended December 28, 2024 compared to the three months ended December 30, 2023, driven by a $52.5 million increase in Cloud & Networking revenue offset by a  $17.1 million decrease in Industrial Tech revenue. The increase in Cloud & Networking net revenue is primarily due to higher revenue from cloud and AI/ML customers, which increased by $34.5 million. In addition, we recognized an increase in revenue of $30.1 million from network equipment manufacturers due to the start of market recovery and the related inventory normalization. This was partially offset by a reduction in shipments to a specific customer in China driven by U.S. trade restrictions. The decrease in Industrial Tech net revenue is primarily due to higher market competition in the consumer end-market for our imaging and sensing products.

[0001628280-25-004288:mdna:42]
Net revenue increased by $54.7 million, or 8.0%, during the six months ended December 28, 2024 compared to the six months ended December 30, 2023, driven by a $105.1 million increase in Cloud & Networking revenue offset by a  $50.4 million decrease in Industrial Tech revenue. The increase in Cloud & Networking net revenue is primarily due to higher revenue from cloud and AI/ML customers, which increased by $111.0 million, inclusive of revenue from Cloud Light, which we acquired in the second quarter of fiscal 2024. In addition, we recognized an increase in revenue of $38.0 million from network equipment manufacturers due to the start of market recovery and the related inventory normalization. This was partially offset by a reduction in shipments to a specific customer in China driven by U.S. trade restrictions. The decrease in Industrial Tech net revenue is primarily due to higher market competition in the consumer end-market for our imaging and sensing products.

[0001628280-25-004288:mdna:43]
During the three months ended December 28, 2024, three customers individually accounted for 16%, 14% and 11% of our total revenue, respectively. During the six months ended December 28, 2024, three customers individually accounted for 15%, 13% and 10% of our total net revenue, respectively. We had no other customers that represented 10% or greater of our total net revenue.

[0001628280-25-004288:mdna:44]
During the three months ended December 30, 2023, three customers individually accounted for 19%, 13% and 11% of our total revenue, respectively. During the six months ended December 30, 2023, three customers individually accounted for 14%, 12% and 12% of our total net revenue, respectively. We had no other customers that represented 10% or greater of our total net revenue.

[0001628280-25-004288:mdna:45]
[same as prior period, unchanged from 0001628280-24-046443:mdna:43]

[0001628280-25-004288:mdna:46]
[same as prior period, unchanged from 0001628280-24-046443:mdna:44]

[0001628280-25-004288:mdna:47]
[same as prior period, unchanged from 0001628280-24-046443:mdna:45]

[0001628280-25-004288:mdna:48]
|  | Three Months Ended |  | Six Months Ended |
|  | December 28, 2024 |  | December 30, 2023 |  | December 28, 2024 |  | December 30, 2023 |
|  | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States | $ | 77.6 |  |  | 19.3 | % |  | $ | 103.0 |  |  | 28.1 | % |  | $ | 143.0 |  |  | 19.3 | % |  | $ | 144.1 |  |  | 21.0 | % |
| Mexico | 37.4 |  |  | 9.3 |  |  | 31.4 |  |  | 8.6 |  |  | 71.3 |  |  | 9.6 |  |  | 55.1 |  |  | 8.1 |  |
| Other Americas | 4.2 |  |  | 1.0 |  |  | 0.8 |  |  | 0.2 |  |  | 7.1 |  |  | 1.0 |  |  | 2.0 |  |  | 0.3 |  |
| Total Americas | $ | 119.2 |  |  | 29.6 | % |  | $ | 135.2 |  |  | 36.9 | % |  | $ | 221.4 |  |  | 29.9 | % |  | $ | 201.2 |  |  | 29.4 | % |
| Asia-Pacific: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Hong Kong | $ | 100.5 |  |  | 25.0 | % |  | $ | 65.7 |  |  | 17.9 | % |  | $ | 189.2 |  |  | 25.6 | % |  | $ | 130.6 |  |  | 19.1 | % |
| South Korea | 6.8 |  |  | 1.7 |  |  | 20.8 |  |  | 5.7 |  |  | 15.6 |  |  | 2.1 |  |  | 45.8 |  |  | 6.7 |  |
| Japan | 18.4 |  |  | 4.5 |  |  | 25.9 |  |  | 7.1 |  |  | 35.3 |  |  | 4.8 |  |  | 51.3 |  |  | 7.5 |  |
| Thailand | 74.7 |  |  | 18.6 |  |  | 39.3 |  |  | 10.7 |  |  | 127.2 |  |  | 17.2 |  |  | 103.5 |  |  | 15.1 |  |
| Other Asia-Pacific | 41.8 |  |  | 10.4 |  |  | 49.5 |  |  | 13.4 |  |  | 79.0 |  |  | 10.7 |  |  | 89.0 |  |  | 13.0 |  |
| Total Asia-Pacific | $ | 242.2 |  |  | 60.2 | % |  | $ | 201.2 |  |  | 54.8 | % |  | $ | 446.3 |  |  | 60.4 | % |  | $ | 420.2 |  |  | 61.4 | % |
| EMEA | $ | 40.8 |  |  | 10.2 | % |  | $ | 30.4 |  |  | 8.3 | % |  | $ | 71.4 |  |  | 9.7 | % |  | $ | 63.0 |  |  | 9.2 | % |
| Total net revenue | $ | 402.2 |  |  | 100.0 | % |  | $ | 366.8 |  |  | 100.0 | % |  | $ | 739.1 |  |  | 100.0 | % |  | $ | 684.4 |  |  | 100.0 | % |

[0001628280-25-004288:mdna:49]
For the three and six months ended December 28, 2024, net revenue from customers outside the United States, based on customer shipping location, represented 80.7% and 80.7% of net revenue, respectively.

[0001628280-25-004288:mdna:50]
For the three and six months ended December 30, 2023, net revenue from customers outside the United States, based on customer shipping location, represented 71.9% and 79.0% of net revenue, respectively.

[0001628280-25-004288:mdna:51]
[same as prior period, unchanged from 0001628280-24-046443:mdna:48]

[0001628280-25-004288:mdna:52]
[same as prior period, unchanged from 0001628280-24-046443:mdna:49]

[0001628280-25-004288:mdna:53]
Gross margin for the three months ended December 28, 2024 increased to 24.8% from 17.4% for the three months ended December 30, 2023. The increase was driven by a $10.8 million reduction in excess and obsolete inventory charges during the three months ended December 28, 2024 primarily driven by the U.S. trade restrictions imposed during the three months ended December 30, 2023 whereby we were no longer able to sell certain products to one of our customers. In addition, costs incurred during the three months ended December 28, 2024 related to the acquisition of Cloud Light, including integration costs and amortization of inventory fair value adjustments decreased by $10.6 million compared to the prior period. Within our segments, our Cloud & Networking segment gross margin increased during the three months ended December 28, 2024 due to higher revenue and better factory utilization driven by increased production of products for sale to network equipment manufacturer

[0001628280-25-004288:mdna:54]
customers, which positively impacted gross margin by approximately 1.5%. Industrial Tech segment gross margin decreased during the three months ended December 28, 2024 primarily due to lower sales of imaging and sensing products into consumer electronic customers, which negatively impacted our gross margin by approximately 1%.

[0001628280-25-004288:mdna:55]
Gross margin for the six months ended December 28, 2024 increased to 24.0% from 20.6% for the six months ended December 30, 2023. The increase was driven by a $19.2 million reduction in excess and obsolete inventory charges during the six months ended December 28, 2024 primarily driven by the U.S. trade restrictions imposed during the three months ended December 30, 2023 whereby we were no longer able to sell certain products to one of our customers. In addition, costs incurred during the six months ended December 28, 2024 related to the acquisition of Cloud Light, including integration costs and amortization of inventory fair value adjustments were $12.7 million lower compared to the prior year period. Our Cloud & Networking segment gross margin was approximately flat. Industrial Tech segment gross margin decrease during the six months ended December 28, 2024 primarily due to lower sales of imaging and sensing products to consumer electronics customers, which negatively impacted our gross margin by approximately 1%.

[0001628280-25-004288:mdna:56]
[same as prior period, unchanged from 0001628280-24-046443:mdna:51]

[0001628280-25-004288:mdna:57]
[same as prior period, unchanged from 0001628280-24-046443:mdna:52]

[0001628280-25-004288:mdna:58]
[same as prior period, unchanged from 0001628280-24-046443:mdna:53]

[0001628280-25-004288:mdna:59]
|  | Three Months Ended |  | Six Months Ended |  |  |  |  |
|  | December 28, 2024 |  | December 30, 2023 |  | December 28, 2024 |  | December 30, 2023 |  |  |  |  |
| Cloud & Networking | $ | 54.9 |  |  | 29.1 |  |  | $ | 91.4 |  |  | $ | 53.0 |  |  |  |  |  |
| Industrial Tech | 3.9 |  |  | 12.7 |  |  | 6.1 |  |  | 28.0 |  |  |  |  |  |

[0001628280-25-004288:mdna:60]
Cloud & Networking segment profit increased by $25.8 million, or 88.7%, during the three months ended December 28, 2024 as compared to the three months ended December 30, 2023 primarily due to higher sales of our products to both cloud and AI/ML customers and to network equipment manufacturer customers. Industrial Tech segment profit decreased by $8.8 million, or 69.3%, during the three months ended December 28, 2024 as compared to the three months ended December 30, 2023 primarily due to lower revenue, mainly from sales of imaging and sensing products to consumer electronics customers.

[0001628280-25-004288:mdna:61]
Cloud & Networking segment profit increased by $38.4 million, or 72.5%, during the six months ended December 28, 2024 as compared to the six months ended December 30, 2023 primarily due to higher sales of our products to both cloud and AI/ML customers. Industrial Tech segment profit decreased by $21.9 million, or 78.2%, during the six months ended December 28, 2024 as compared to the six months ended December 30, 2023 primarily due to lower revenue, mainly from sales of imaging and sensing products.

[0001628280-25-004288:mdna:62]
[same as prior period, unchanged from 0001628280-24-046443:mdna:56]

[0001628280-25-004288:mdna:63]
R&D expense decreased by $4.1 million, or 5.2% for the three months ended December 28, 2024 compared to the three months ended December 30, 2023, primarily due to $2.2 million of lower spending in software and computer supplies used for R&D purposes and lower payroll and other compensation related expenses due to lower headcount as a result of restructuring actions primarily due to the discontinuation of our in-house development of coherent DSPs and RFICs. This was partially offset by $1.7 million of higher depreciation expense.

[0001628280-25-004288:mdna:64]
R&D expense decreased by $3.3 million, or 2.2% for the six months ended December 28, 2024 compared to the six months ended December 30, 2023. The decrease in R&D expense for the six months ended December 30, 2023 was primarily driven by lower payroll and other compensation related expenses due to lower headcount as a result of restructuring actions primarily due to the discontinuation of our in-house development of coherent DSPs and RFICs. This was partially offset by $2.5 million of higher spending in software and computer supplies used for R&D purposes and lower funding from customers and $2.2 million of higher depreciation expense.

[0001628280-25-004288:mdna:65]
[same as prior period, unchanged from 0001628280-24-046443:mdna:58]

[0001628280-25-004288:mdna:66]
[same as prior period, unchanged from 0001628280-24-046443:mdna:59]

[0001628280-25-004288:mdna:67]
SG&A expense decreased by $8.8 million, or 10.3%, during the three months ended December 28, 2024 compared to the three months ended December 30, 2023. The decrease was driven by $9.2 million of lower acquisition costs and outside consultant costs as a result of business and system integrations efforts as well as a reduction in payroll related expenses as a result of restructuring actions in the prior periods. This was partially offset by a $2.6 million increase in stock-based compensation expense and $1.4 million of incremental amortization of intangible assets associated with the Cloud Light acquisition.

[0001628280-25-004288:mdna:68]
SG&A expense decreased by $5.5 million, or 3.5%, during the six months ended December 28, 2024 compared to the six months ended December 30, 2023. The decrease was primarily driven by $12.6 million of lower acquisition costs related to Cloud Light, which we acquired in second quarter of fiscal year 2024, as well as a reduction in payroll related expenses as a result of restructuring actions in the prior periods. This was partially offset by $9.6 million of incremental amortization of intangible assets associated with the Cloud Light acquisition and a $3.4 million increase in stock-based compensation expense.

[0001628280-25-004288:mdna:69]
From time-to-time, we incur expenses that are not part of our ordinary operations, such as mergers and acquisition-related and litigation expenses, which generally increase our SG&A expenses and potentially impact our profitability expectations in any particular period.

[0001628280-25-004288:mdna:70]
[same as prior period, unchanged from 0001628280-24-046443:mdna:63]

[0001628280-25-004288:mdna:71]
[same as prior period, unchanged from 0001628280-24-046443:mdna:64]

[0001628280-25-004288:mdna:72]
During the three and six months ended December 28, 2024, we recorded restructuring and related charges of $0.7 million and $10.4 million, respectively mainly due to our integration efforts and cost reduction initiatives. Restructuring charges for the six months ended December 28, 2024 includes $6.2 million of asset write-offs primarily due to integration efforts to consolidate our sites, $3.0 million of charges related to the discontinuation of our in-house development of coherent DSPs and RFICs and the remaining restructuring charges due to company-wide cost reduction initiatives.

[0001628280-25-004288:mdna:73]
During the three and six months ended December 30, 2023, we recorded restructuring and related charges of $5.8 million and $16.8 million, respectively, primarily due to company-wide cost reduction initiatives, as well as our integration efforts as a result of the NeoPhotonics acquisition in August 2022.

[0001628280-25-004288:mdna:74]
[same as prior period, unchanged from 0001628280-24-046443:mdna:67]

[0001628280-25-004288:mdna:75]
For the three months ended December 28, 2024 and December 30, 2023, we recorded interest expense of $5.6 million and $9.7 million, respectively. For the six months ended December 28, 2024 and December 30, 2023, we recorded interest expense of $11.1 million and $19.4 million, respectively. Interest expense is primarily driven by the amortization of the debt discount and issuance costs of our convertible notes. The decrease in interest expense for the three and six months ended December 28, 2024 is mainly due to the repayment of our 2024 Notes (as defined below) upon maturity in March 2024.

[0001628280-25-004288:mdna:76]
[same as prior period, unchanged from 0001628280-24-046443:mdna:69]

[0001628280-25-004288:mdna:77]
[same as prior period, unchanged from 0001628280-24-046443:mdna:70]

[0001628280-25-004288:mdna:78]
|  | Three Months Ended |  | Six Months Ended |  |  |
|  | December 28, 2024 |  | December 30, 2023 |  | December 28, 2024 |  | December 30, 2023 |  |  |
| Foreign exchange and other gains (losses), net | $ | 5.9 |  |  | $ | (3.7) |  |  | $ | 5.2 |  |  | $ | (4.2) |  |  |  |
| Interest and investment income, net | 9.0 |  |  | 17.1 |  |  | 18.4 |  |  | 38.8 |  |  |  |
| Total other income, net | $ | 14.9 |  |  | $ | 13.4 |  |  | $ | 23.6 |  |  | $ | 34.6 |  |  |  |

[0001628280-25-004288:mdna:79]
Other income, net for the three months ended December 28, 2024 increased by $1.5 million compared to the three months ended December 30, 2023 due to the decrease of foreign exchange losses of $9.6 million mainly driven by the Japan term loans denominated in Japanese Yen, which weakened relative to the U.S. dollar during the three months ended December 28, 2024 partially offset by a decrease of $8.1 million in interest and investment income driven by lower short term investment balances, as we used cash to purchase Cloud Light as well as the repayment of the 2024 Notes in March 2024.

[0001628280-25-004288:mdna:80]
Other income, net for the six months ended December 28, 2024 decreased by $11.0 million from the six months ended December 30, 2023 due to $20.4 million of decrease in interest and investment income driven by lower short term investment balances, as we used cash to purchase Cloud Light as well as the repayment of the 2024 Notes in March 2024, offset by a decrease in foreign exchange losses of $9.4 million mainly driven by the Japan term loans denominated in Japanese Yen, which weakened relative to the U.S. dollar during the six months ended December 30, 2023.

[0001628280-25-004288:mdna:81]
[same as prior period, unchanged from 0001628280-24-046443:mdna:73]

[0001628280-25-004288:mdna:82]
[same as prior period, unchanged from 0001628280-24-046443:mdna:74]

[0001628280-25-004288:mdna:83]
|  | Three Months Ended |  | Six Months Ended |
|  | December 28, 2024 |  | December 30, 2023 |  | December 28, 2024 |  | December 30, 2023 |
| Income tax provision (benefit) | $ | 18.6 |  |  | $ | (2.4) |  |  | $ | 21.8 |  |  | $ | (3.8) |  |

[0001628280-25-004288:mdna:84]
We recorded a tax provision of $18.6 million and $21.8 million for the three and six months ended December 28, 2024, respectively. Our tax provision for the three months ended December 28, 2024 is primarily attributable to the income tax expense from pre-tax earnings, interest on uncertain tax positions and withholding taxes, partially offset by the tax benefit from prior year changes in uncertain tax positions. Our tax provision for the six months ended December 28, 2024 is primarily attributable to the income tax expense from pre-tax earnings, interest on uncertain tax positions, foreign return to provision differences and withholding taxes, partially offset by the tax benefit from prior year changes in uncertain tax positions.

[0001628280-25-004288:mdna:85]
We recorded a tax benefit of $2.4 million and $3.8 million for the three and six months ended December 30, 2023, respectively. Our tax benefit for the three months ended December 30, 2023 includes a discrete tax expense of $3.4 million, primarily related to a shortfall in connection with stock-based compensation vested during the quarter, interest on uncertain tax positions and currency re-measurements. Our tax benefit for the six months ended December 30, 2023 includes a discrete tax expense of $1.6 million, primarily related to a shortfall in connection with stock-based compensation vested during the quarter, foreign return to provision differences and interest on unrecognized tax positions, partially offset by the tax benefit from changes in prior year uncertain tax positions.

[0001628280-25-004288:mdna:86]
Our estimated effective tax rate for the three months ended December 28, 2024 differs from the 21% U.S. statutory rate primarily due to the income tax expense from foreign rate differential, non-deductible stock-based compensation, and current year valuation allowance changes, partially offset by the income tax benefit from various income tax credits.

[0001628280-25-004288:mdna:87]
We regularly assess our ability to realize our deferred tax assets on a quarterly basis and will establish a valuation allowance if it is more-likely-than-not that some portion of the deferred tax assets will not be realized. As of December 28, 2024, we maintain a full valuation allowance on U.S. federal and state and certain foreign deferred tax assets. We will continue to assess the need for a valuation allowance against our remaining deferred tax assets and may increase or decrease our valuation allowance materially in the future.

[0001628280-25-004288:mdna:88]
[same as prior period, unchanged from 0001628280-24-046443:mdna:79]

[0001628280-25-004288:mdna:89]
[same as prior period, unchanged from 0001628280-24-046443:mdna:80]

[0001628280-25-004288:mdna:90]
[same as prior period, unchanged from 0001628280-24-046443:mdna:81]

[0001628280-25-004288:mdna:91]
[same as prior period, unchanged from 0001628280-24-046443:mdna:82]

[0001628280-25-004288:mdna:92]
As of December 28, 2024 and June 29, 2024, our cash and cash equivalents were $479.7 million and $436.7 million, respectively. As of December 28, 2024 and June 29, 2024, our short-term investments of $417.0 million and $450.3 million, respectively, were all held in the United States. Cash equivalents and short-term investments are primarily comprised of money market funds, treasuries, agencies, high quality investment grade fixed income securities, certificates of deposit and commercial paper. Our investment policy and strategy provide for diversification of investments and is focused on the preservation of capital and supporting our liquidity requirements.

[0001628280-25-004288:mdna:93]
The total amount of cash held by the non-United States entities as of December 28, 2024 and June 29, 2024 was $343.9 million and $306.9 million, respectively, which was primarily held by entities incorporated in the United Kingdom, the British Virgin Islands, Japan, Hong Kong, China, Switzerland, the Cayman Islands, Thailand and Brazil. Although cash currently held in the United States, as well as cash generated in the United States from future operations, is expected to cover our normal operating requirements, a substantial amount of additional cash could be required for other purposes, such as capital expenditures to support our business and growth, including costs associated with increasing internal manufacturing capabilities, strategic transactions and partnerships, and future acquisitions.

[0001628280-25-004288:mdna:94]
[same as prior period, unchanged from 0001628280-24-046443:mdna:85]

[0001628280-25-004288:mdna:95]
[same as prior period, unchanged from 0001628280-24-046443:mdna:86]

[0001628280-25-004288:mdna:96]
We believe that our cash and cash equivalents as of December 28, 2024 and cash flows from our operating activities will be sufficient to meet our liquidity and capital spending requirements for at least the next 12 months.

[0001628280-25-004288:mdna:97]
[same as prior period, unchanged from 0001628280-24-046443:mdna:88]

[0001628280-25-004288:mdna:98]
[same as prior period, unchanged from 0001628280-24-046443:mdna:89]

[0001628280-25-004288:mdna:99]
[same as prior period, unchanged from 0001628280-24-046443:mdna:90]

[0001628280-25-004288:mdna:100]
[same as prior period, unchanged from 0001628280-24-046443:mdna:91]

[0001628280-25-004288:mdna:101]
[same as prior period, unchanged from 0001628280-24-046443:mdna:92]

[0001628280-25-004288:mdna:102]
[same as prior period, unchanged from 0001628280-24-046443:mdna:93]

[0001628280-25-004288:mdna:103]
[same as prior period, unchanged from 0001628280-24-046443:mdna:94]

[0001628280-25-004288:mdna:104]
[same as prior period, unchanged from 0001628280-24-046443:mdna:95]

[0001628280-25-004288:mdna:105]
[same as prior period, unchanged from 0001628280-24-046443:mdna:96]

[0001628280-25-004288:mdna:106]
[same as prior period, unchanged from 0001628280-24-046443:mdna:97]

[0001628280-25-004288:mdna:107]
[same as prior period, unchanged from 0001628280-24-046443:mdna:98]

[0001628280-25-004288:mdna:108]
[same as prior period, unchanged from 0001628280-24-046443:mdna:99]

[0001628280-25-004288:mdna:109]
[same as prior period, unchanged from 0001628280-24-046443:mdna:100]

[0001628280-25-004288:mdna:110]
•acquisitions or strategic transactions, in particular the Cloud Light acquisition;

[0001628280-25-004288:mdna:111]
•the settlement of any conversion or redemption of our convertible notes in cash;

[0001628280-25-004288:mdna:112]
•the timing of settlement or other resolution of legal contingencies; and

[0001628280-25-004288:mdna:113]
[same as prior period, unchanged from 0001628280-24-046443:mdna:103]

[0001628280-25-004288:mdna:114]
[same as prior period, unchanged from 0001628280-24-046443:mdna:104]

[0001628280-25-004288:mdna:115]
The following table summarizes our contractual obligations as of December 28, 2024, and the effect such obligations are expected to have on our liquidity and cash flow (in millions):

[0001628280-25-004288:mdna:116]
|  | Payments Due |
|  | Total |  | Less Than 1 Year |  | More Than 1 Year |  |  |  |  |
| Contractual Obligations |  |  |  |  |  |  |  |  |  |
| Asset retirement obligations | $ | 7.0 |  |  | $ | — |  |  | $ | 7.0 |  |  |  |  |  |
| Operating lease liabilities, including imputed interest (1) | 40.2 |  |  | 12.7 |  |  | 27.5 |  |  |  |  |  |
| Pension plan contributions (2) | 1.6 |  |  | 1.6 |  |  | — |  |  |  |  |  |
| Purchase obligations (3) | 620.1 |  |  | 578.1 |  |  | 42.0 |  |  |  |  |  |
| Term loans - principal (5) | 66.3 |  |  | 9.8 |  |  | 56.5 |  |  |  |  |  |
| Term loans - interest (5) | 1.9 |  |  | 0.6 |  |  | 1.3 |  |  |  |  |  |
| Convertible notes - principal (4) | 2,514.7 |  |  | — |  |  | 2,514.7 |  |  |  |  |  |
| Convertible notes - interest (4) | 70.9 |  |  | 18.7 |  |  | 52.2 |  |  |  |  |  |
| Total | $ | 3,322.7 |  |  | $ | 621.5 |  |  | $ | 2,701.2 |  |  |  |  |  |

[0001628280-25-004288:mdna:117]
(1) The amounts of operating lease liabilities do not include any sublease income amounts nor do they include payments for short-term leases or variable lease payments. As of December 28, 2024, we expect to receive sublease income of approximately $2.6 million over the sublease periods.

[0001628280-25-004288:mdna:118]
[same as prior period, unchanged from 0001628280-24-046443:mdna:108]

[0001628280-25-004288:mdna:119]
(3) Purchase obligations represent legally binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Refer to “Note 14. Commitments and Contingencies” in the notes to condensed consolidated financial statements.

[0001628280-25-004288:mdna:120]
(4) The amounts related to convertible notes include principal and interest on our 0.50% Convertible Senior Notes due 2026 (the “2026 Notes”), principal and interest on our 0.50% Convertible Senior Notes due 2028 (the “2028 Notes”), and principal and interest on our 1.50% Convertible Senior Notes due 2029 (the “2029 Notes”). The 2026 Notes have a maturity date of December 15, 2026, the 2028 Notes have a maturity date of June 15, 2028, and the 2029 Notes have a maturity date of December 15, 2029. The principal balances of our convertible notes are reflected in the payment periods in the table above based on their respective contractual maturities assuming no conversions.

[0001628280-25-004288:mdna:121]
[same as prior period, unchanged from 0001628280-24-046443:mdna:111]

[0001628280-25-004288:mdna:122]
[same as prior period, unchanged from 0001628280-24-046443:mdna:112]

[0001628280-25-004288:mdna:123]
[same as prior period, unchanged from 0001628280-24-046443:mdna:113]

[0001628280-25-004288:mdna:124]
As of December 28, 2024, the net carrying amount of our 2029 Notes of $599.9 million (principal balance of $603.7 million maturing in 2029) is presented in non-current liabilities. If the closing price of our stock exceeds $90.40 (or 130% of the conversion price of $69.54) for 20 of the last 30 trading days of any future quarter, our 2029 Notes would become convertible at the option of the holders during the subsequent fiscal quarter and the debt would be reclassified to current liabilities in our consolidated balance sheets.

[0001628280-25-004288:mdna:125]
As of December 28, 2024, the net carrying amount of our 2028 Notes of $857.1 million (which have an aggregate principal amount of $861.0 million outstanding that matures in 2028) is presented in non-current liabilities in our condensed consolidated balance sheets. If the closing price of our stock exceeds $170.34 (or 130% of the conversion price of $131.03) for 20 of the last 30 trading days of any future fiscal quarter, our 2028 Notes would become convertible at the option of the holders during the subsequent fiscal quarter and the debt would be reclassified to current liabilities in our condensed consolidated balance sheet.

[0001628280-25-004288:mdna:126]
As of December 28, 2024, the net carrying amount of our 2026 Notes of $1,047.7 million (which have an aggregate principal amount of $1,050.0 million outstanding that matures in 2026) is presented in non-current liabilities in our condensed consolidated balance sheets. If the closing price of our stock exceeds $129.08 (or 130% of the conversion price of $99.29) for 20 of the last 30 trading days of any future fiscal quarter, our 2026 Notes would become convertible at the option of the holders during the subsequent fiscal quarter and the debt would be reclassified to current liabilities in our condensed consolidated balance sheet.

[0001628280-25-004288:mdna:127]
As of December 28, 2024, the Company has $39.2 million in principal amount outstanding on our SMBC term loan, of which the short-term portion of $4.1 million is recorded as current liabilities while the long-term portion of $35.1 million is recorded as long-term debt in the Company’s condensed consolidated balance sheets.

[0001628280-25-004288:mdna:128]
As of December 28, 2024, the Company has $27.1 million in principal amount outstanding on our Mizuho term loan, of which the short-term portion of $5.7 million is recorded as current liabilities while the long-term portion of $21.4 million is recorded as long-term debt in the Company’s condensed consolidated balance sheets.

[0001628280-25-004288:mdna:129]
[same as prior period, unchanged from 0001628280-24-046443:mdna:120]

[0001628280-25-004288:mdna:130]
We have a share buyback program that authorizes us to utilize up to an aggregate amount of $1.2 billion to purchase our own shares of common stock through May 2025. During the six months ended December 28, 2024, we did not repurchase any shares of our common stock. Since the board of directors initially approved the share buyback program, we have repurchased 7.7 million shares in aggregate at an average price of $81.66 per share for a total purchase price of $630.4 million. We recorded the $630.4 million aggregate purchase price as a reduction of retained earnings within our condensed consolidated balance sheet. All repurchased shares were retired immediately. As of December 28, 2024, we have $569.6 million remaining under the share buyback program.

[0001628280-25-004288:mdna:131]
[same as prior period, unchanged from 0001628280-24-046443:mdna:123]

[0001628280-25-004288:mdna:132]
[same as prior period, unchanged from 0001628280-24-046443:mdna:124]

[0001628280-25-004288:mdna:133]
As of December 28, 2024 and June 29, 2024, our other non-current liabilities include unrecognized tax benefit for uncertain tax positions of $95.5 million and $83.0 million, respectively. We are unable to reliably estimate the timing of future payments related to uncertain tax positions.

[0001628280-25-004288:mdna:134]
[same as prior period, unchanged from 0001628280-24-046443:mdna:126]

[0001628280-25-004288:mdna:135]
Our balance of cash and cash equivalents increased by $43.0 million from $436.7 million as of June 29, 2024 to $479.7 million as of December 28, 2024. The increase in cash and cash equivalents during the six months ended December 28, 2024 was due to cash from operating activities of $63.9 million and cash from financing activities of $56.9 million, offset by cash used in investing activities of $77.8 million.

[0001628280-25-004288:mdna:136]
[same as prior period, unchanged from 0001628280-24-046443:mdna:128]

[0001628280-25-004288:mdna:137]
Cash from operating activities was $63.9 million during the six months ended December 28, 2024, which reflects a net loss of $143.3 million, offset by non-cash items of $209.1 million and changes in operating assets and liabilities of $1.9 million. Changes in operating assets and liabilities were primarily driven by an increase in accounts payable of $38.7 million primarily due to higher inventory purchases and capital expenditures and an increase in income tax liabilities of $28.5 million primarily due to income tax provision for the six months ended December 28, 2024, offset by an increase of $15.0 million in prepayments and other current and non-current assets related mainly to value-added-tax receivables driven by higher recent capital expenditures and inventory purchases, and a decrease of $19.9 million in accrued expenses and other current and non-current liabilities primarily due to payment of the net settlement amount of the Oclaro merger litigation.

[0001628280-25-004288:mdna:138]
Cash used in operating activities was $3.8 million during the six months ended December 30, 2023, which reflects a net loss of $167.0 million and non-cash items of $194.7 million, offset by $31.5 million of changes in our operating assets and liabilities. Changes in our operating assets and liabilities were primarily driven by a decrease in accounts payable of $51.1 million primarily due to lower purchases from our contract manufactures and linearity of payments, and a decrease in income taxes of $26.6 million primarily due annual income tax payable in Japan, offset by a decrease in accounts receivable of $18.7 million due to lower revenue and a decrease in inventories of $7.5 million primarily due to reduced inventory level in our Cloud & Networking business.

[0001628280-25-004288:mdna:139]
[same as prior period, unchanged from 0001628280-24-046443:mdna:131]

[0001628280-25-004288:mdna:140]
Cash used in investing activities of $77.8 million during the six months ended December 28, 2024 was attributable to capital expenditures of $114.3 million, offset by net proceeds from sales or maturities of short-term investments of $36.3 million and proceeds from sales of property and equipment of $0.2 million.

[0001628280-25-004288:mdna:141]
Cash used in investing activities of $377.1 million during the six months ended December 30, 2023 was attributable to cash used in the acquisition of Cloud Light of $700.9 million, net of cash acquired, capital expenditures of $88.8 million, and an intangible asset acquisition of $3.0 million, offset by net proceeds from sales or maturities of short-term investments of $415.4 million and proceeds from sales of property and equipment of $0.2 million.

[0001628280-25-004288:mdna:142]
[same as prior period, unchanged from 0001628280-24-046443:mdna:134]

[0001628280-25-004288:mdna:143]
Cash from financing activities of $56.9 million during the six months ended December 28, 2024 was attributable to $76.5 million of proceeds from SMBC and Mizuho term loans and $8.1 million of proceeds from employee stock plans, offset by tax payments related to net share settlement of restricted stock of $23.8 million, payment for an intangible asset acquisition holdback of $1.0 million and $2.9 million of principal payments on term loans.

[0001628280-25-004288:mdna:144]
Cash used in financing activities of $8.8 million during the six months ended December 30, 2023 was attributable to tax payments related to net share settlement of restricted stock of $16.1 million, offset by $7.3 million of proceeds from employee stock plans.
