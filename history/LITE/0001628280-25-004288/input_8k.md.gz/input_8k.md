# LITE 8-K — 0001628280-25-004265 filed 2025-02-06

## item codes, every 8-K on or before 2025-02-06

- 2025-02-06 0001628280-25-004265 — 2.02, 9.01
- 2025-02-03 0001193125-25-019371 — 2.02, 5.02, 9.01
- 2024-12-12 0001193125-24-277338 — 5.02, 9.01
- 2024-11-22 0001628280-24-048886 — 5.02, 5.07, 9.01
- 2024-11-07 0001628280-24-046302 — 2.02, 9.01
- 2024-08-21 0001628280-24-037938 — 2.02, 9.01 — amendment of 0001628280-24-037191
- 2024-08-14 0001628280-24-037191 — 2.02, 9.01
- 2024-05-06 0001628280-24-020640 — 2.02, 9.01
- 2024-02-27 0001628280-24-006936 — 5.02
- 2024-02-08 0001628280-24-003789 — 2.02, 9.01
- 2024-01-18 0001628280-24-001551 — 9.01 — amendment of 0001193125-23-272452
- 2023-11-21 0001628280-23-039654 — 5.02, 5.07
- 2023-11-08 0001628280-23-037563 — 2.02, 9.01
- 2023-11-07 0001193125-23-272452 — 2.01, 8.01, 9.01
- 2023-10-30 0001193125-23-265658 — 1.01, 2.02, 9.01
- 2023-08-17 0001628280-23-029741 — 2.02, 9.01
- 2023-06-16 0001193125-23-168966 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2023-05-09 0001628280-23-016629 — 2.02, 9.01
- 2023-04-06 0001628280-23-010935 — 2.02, 8.01, 9.01
- 2023-02-24 0001193125-23-048742 — 5.02, 9.01
- 2023-02-09 0001628280-23-002866 — 2.02, 9.01
- 2022-11-21 0001628280-22-030473 — 5.02, 5.07, 9.01
- 2022-11-08 0001628280-22-028758 — 2.02, 9.01
- 2022-08-16 0001628280-22-022980 — 2.02, 9.01
- 2022-08-03 0001193125-22-210674 — 2.01, 8.01, 9.01
- 2022-07-29 0001193125-22-206587 — 8.01, 9.01
- 2022-05-04 0001628280-22-012145 — 2.02, 9.01
- 2022-03-08 0001193125-22-069350 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2022-02-03 0001628280-22-001736 — 2.02, 9.01
- 2022-01-21 0001193125-22-014413 — 8.01, 9.01
- 2021-11-23 0001628280-21-024070 — 5.02, 5.07
- 2021-11-05 0001193125-21-321796 — 1.01, 9.01
- 2021-11-04 0001628280-21-021618 — 2.02, 9.01
- 2021-11-04 0001193125-21-319601 — 8.01, 9.01
- 2021-08-18 0001628280-21-017219 — 2.02, 9.01
- 2021-06-08 0001633978-21-000030 — 5.02, 9.01
- 2021-05-12 0001633978-21-000008 — 2.02, 9.01
- 2021-03-10 0001193125-21-075438 — 1.01, 8.01, 9.01
- 2021-02-02 0001633978-21-000002 — 2.02, 9.01
- 2021-01-19 0001104659-21-005024 — 1.01, 2.02, 8.01, 9.01
- 2020-11-24 0001193125-20-302557 — 5.02, 5.07
- 2020-11-02 0001633978-20-000017 — 2.02, 9.01
- 2020-09-18 0001633978-20-000012 — 5.02, 9.01
- 2020-08-11 0001633978-20-000010 — 2.02, 9.01
- 2020-05-05 0001628280-20-006358 — 2.02, 9.01
- 2020-02-04 0001633978-20-000002 — 2.02, 9.01
- 2019-12-12 0001193125-19-312875 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2019-12-04 0001633978-19-000075 — 8.01
- 2019-11-20 0001633978-19-000074 — 5.07
- 2019-10-31 0001633978-19-000070 — 2.02, 9.01
- 2019-08-08 0001633978-19-000068 — 2.02, 9.01
- 2019-05-08 0001633978-19-000031 — 1.01
- 2019-05-07 0001633978-19-000029 — 2.02, 9.01
- 2019-02-15 0001633978-19-000005 — 9.01 — amendment of 0001193125-18-346211
- 2019-02-08 0001193125-19-031591 — 5.02, 9.01
- 2019-02-05 0001633978-19-000001 — 2.02, 9.01
- 2018-12-10 0001193125-18-346211 — 1.01, 2.01, 2.03, 5.02, 8.01, 9.01
- 2018-12-06 0001633978-18-000150 — 8.01
- 2018-11-14 0001633978-18-000139 — 5.07
- 2018-11-13 0001633978-18-000136 — 3.02
- 2018-11-13 0001633978-18-000132 — 7.01, 9.01
- 2018-11-01 0001628280-18-013238 — 2.02, 9.01
- 2018-08-08 0001633978-18-000056 — 2.02, 9.01
- 2018-06-08 0001193125-18-188241 — 5.02, 9.01
- 2018-05-02 0001633978-18-000029 — 2.02, 9.01
- 2018-03-12 0001193125-18-078154 — 1.01, 2.01, 8.01, 9.01
- 2018-02-06 0001628280-18-001082 — 2.02, 9.01
- 2017-11-08 0001633978-17-000133 — 5.02, 9.01
- 2017-11-07 0001633978-17-000131 — 5.07
- 2017-11-01 0001633978-17-000117 — 2.02, 9.01
- 2017-08-09 0001633978-17-000058 — 2.02, 9.01
- 2017-05-04 0001633978-17-000035 — 2.02, 9.01
- 2017-03-08 0001193125-17-074740 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2017-03-02 0001193125-17-066769 — 8.01, 9.01
- 2017-02-07 0001633978-17-000005 — 2.02, 9.01
- 2017-01-03 0001628280-17-000018 — 4.01, 9.01
- 2016-11-09 0001628280-16-021143 — 5.02, 5.07, 9.01
- 2016-10-27 0001628280-16-020382 — 2.02, 9.01
- 2016-08-09 0001628280-16-018811 — 2.02, 9.01
- 2016-06-21 0001628280-16-017201 — 8.01
- 2016-05-04 0001628280-16-015501 — 2.02, 9.01
- 2016-02-16 0001628280-16-011261 — 5.02, 9.01
- 2016-02-04 0001628280-16-010758 — 5.02, 9.01
- 2016-02-04 0001628280-16-010755 — 2.02, 9.01
- 2015-11-17 0001193125-15-378953 — 7.01
- 2015-11-10 0001628280-15-008606 — 2.02, 9.01
- 2015-09-28 0001193125-15-329665 — 8.01, 9.01
- 2015-08-11 0001193125-15-286405 — 7.01, 9.01
- 2015-08-06 0001193125-15-281219 — 1.01, 5.02, 5.03, 5.05, 8.01, 9.01
- 2015-08-03 0001193125-15-274808 — 5.03, 9.01

## late-filing notifications on or before 2025-02-06

- 2015-11-10 0001628280-15-008612 — NT 10-Q, for the period ended 2015-09-26
- 2015-09-28 0001193125-15-329672 — NT 10-K, for the period ended 2015-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001628280-25-004265:8k_2_02:1]
EX-99.1
2
lite_ex991xq2fy25.htm
EX-99.1

[0001628280-25-004265:8k_2_02:2]
Document

[0001628280-25-004265:8k_2_02:3]
NEWS RELEASE

[0001628280-25-004265:8k_2_02:4]
LUMENTUM ANNOUNCES FISCAL SECOND QUARTER 2025 FINANCIAL RESULTS

[0001628280-25-004265:8k_2_02:5]
•Net revenue of $402.2 million

[0001628280-25-004265:8k_2_02:6]
•GAAP gross margin of 24.8%; Non-GAAP gross margin of 32.3%

[0001628280-25-004265:8k_2_02:7]
•GAAP operating loss of 12.8%; Non-GAAP operating margin of 7.9%

[0001628280-25-004265:8k_2_02:8]
•GAAP diluted net loss per share of $0.88; Non-GAAP diluted net income per share of $0.42

[0001628280-25-004265:8k_2_02:9]
San Jose, Calif., February 6, 2025 – Lumentum Holdings Inc. (“Lumentum” or the “Company”) today reported results for its fiscal second quarter ended December 28, 2024.

[0001628280-25-004265:8k_2_02:10]
“In the second quarter, we exceeded the high end of our guidance ranges for both revenue and earnings per share, driven by strong demand in the cloud end market. This is an exciting time for Lumentum as we position ourselves to capitalize on expanding cloud opportunities and the recovery of the broader networking market. Our foundational technologies enable us to win in these markets,” said Alan Lowe, President and CEO. “With our strong market position and improving industry trends, we remain confident in achieving our previously stated goal of reaching $500 million in quarterly revenue by the end of calendar year 2025.”

[0001628280-25-004265:8k_2_02:11]
“On a personal note, serving as Lumentum’s President and CEO over the last decade has been the highlight of my career, and I am deeply grateful to our talented team for their dedication. I look forward to continuing my role on the Lumentum Board and serving as an advisor to ensure a smooth transition to Michael Hurlston,” concluded Mr. Lowe.

[0001628280-25-004265:8k_2_02:12]
Fiscal Second Quarter Highlights:

[0001628280-25-004265:8k_2_02:13]
Net revenue for the fiscal second quarter of 2025 was $402.2 million, with GAAP net loss of $60.9 million, or $0.88 per diluted share. Net revenue for the fiscal first quarter of 2025 was $336.9 million, with GAAP net loss of $82.4 million, or $1.21 per diluted share. Net revenue for the fiscal second quarter of 2024 was $366.8 million, with GAAP net loss of $99.1 million, or $1.47 per diluted share.

[0001628280-25-004265:8k_2_02:14]
Non-GAAP net income for the fiscal second quarter of 2025 was $30.0 million, or $0.42 per diluted share. Non-GAAP net income for the fiscal first quarter of 2025 was $12.2 million, or $0.18 per diluted share. Non-GAAP net income for the second quarter of 2024 was $16.4 million, or $0.24 per diluted share(1).

[0001628280-25-004265:8k_2_02:15]
The Company held $896.7 million in total cash, cash equivalents, and short-term investments at the end of the fiscal second quarter of 2025, down $19.4 million from the end of the fiscal first quarter of 2025.

[0001628280-25-004265:8k_2_02:16]
Financial Overview – Fiscal Second Quarter Ended December 28, 2024

[0001628280-25-004265:8k_2_02:17]
|  | GAAP Results ($ in millions) |
|  | Q2 |  | Q1 |  | Q2 |  | Change |
|  | FY 2025 |  | FY 2025 |  | FY 2024 |  | Q/Q |  | Y/Y |
| Net revenue | $ | 402.2 |  |  | $ | 336.9 |  |  | $ | 366.8 |  |  | 19.4% |  | 9.7% |
| GAAP gross margin | 24.8 | % |  | 23.1 | % |  | 17.4 | % |  | 170 | bps |  | 740 | bps |
| GAAP operating loss | (12.8) | % |  | (24.5) | % |  | (28.7) | % |  | 1,170 | bps |  | 1,590 | bps |
|  | Non-GAAP Results ($ in millions) |
|  | Q2 |  | Q1 |  | Q2 |  | Change |
|  | FY 2025 |  | FY 2025 |  | FY 2024 (1) |  | Q/Q |  | Y/Y |
| Net revenue | $ | 402.2 |  |  | $ | 336.9 |  |  | $ | 366.8 |  |  | 19.4% |  | 9.7% |
| Non-GAAP gross margin | 32.3 | % |  | 32.8 | % |  | 31.4 | % |  | (50) | bps |  | 90 | bps |
| Non-GAAP operating margin | 7.9 | % |  | 3.0 | % |  | 1.9 | % |  | 490 | bps |  | 600 | bps |

[0001628280-25-004265:8k_2_02:18]
|  | Net Revenue by Segment ($ in millions) |  |  |  |  |
|  | Q2 |  | % of |  | Q1 |  | Q2 |  | Change |  |  |  |  |
|  | FY 2025 |  | Net Revenue |  | FY 2025 |  | FY 2024 |  | Q/Q |  | Y/Y |  |  |  |  |
| Cloud & Networking | $ | 339.2 |  |  | 84.3 | % |  | $ | 282.3 |  |  | $ | 286.7 |  |  | 20.2% |  | 18.3% |  |  |  |  |
| Industrial Tech | 63.0 |  |  | 15.7 | % |  | 54.6 |  |  | 80.1 |  |  | 15.4% |  | (21.3)% |  |  |  |  |
| Total | $ | 402.2 |  |  | 100.0 | % |  | $ | 336.9 |  |  | $ | 366.8 |  |  | 19.4% |  | 9.7% |  |  |  |  |

[0001628280-25-004265:8k_2_02:19]
(1) During the first fiscal quarter of 2025, the Company refined its methodology to report non-GAAP measures.  The change does not impact the Company’s financial position, cash flows, or GAAP consolidated results of operations. Prior period non-GAAP financial measures presented in this press release have been recast to conform to the current presentation.

[0001628280-25-004265:8k_2_02:20]
The tables above provide comparisons of quarterly results to prior periods, including sequential quarterly and year-over-year changes. A reconciliation between GAAP and non-GAAP measures is contained in this release under the section titled “Use of Non-GAAP Financial Measures.”

[0001628280-25-004265:8k_2_02:21]
Business Outlook

[0001628280-25-004265:8k_2_02:22]
Lumentum expects the following for the fiscal third quarter 2025:

[0001628280-25-004265:8k_2_02:23]
•Net revenue in the range of $410 million to $425 million

[0001628280-25-004265:8k_2_02:24]
•Non-GAAP operating margin of 9.5% to 10.5%

[0001628280-25-004265:8k_2_02:25]
•Non-GAAP diluted earnings per share of $0.47 to $0.53

[0001628280-25-004265:8k_2_02:26]
We have not provided reconciliations from GAAP to non-GAAP measures or the equivalent GAAP measure for non-GAAP measures in our outlook, as they cannot be provided without unreasonable effort. A large portion of non-GAAP adjustments, such as restructuring charges, stock-based compensation, non-GAAP income tax reconciling adjustments, acquisition related costs, and other costs and contingencies unrelated to current and future operations are by their nature highly volatile and we have low visibility as to the range that may be incurred in the future.

[0001628280-25-004265:8k_2_02:27]
Related Announcement and Conference Call

[0001628280-25-004265:8k_2_02:28]
Lumentum will host a conference call today, February 6, 2025, at 2:00 pm PT / 5:00 pm ET to discuss its fiscal second quarter results. A live webcast of the call will be available in the Investors section of the Lumentum website at http://investor.lumentum.com. To listen to the live conference call, dial (833) 470-1428 or (404) 975-4839 and reference the conference ID 360050. Supporting materials outlining the Company’s latest financial results will be posted on http://investor.lumentum.com under the “Events and Presentations” section concurrently with this earnings press release. Lumentum has used, and intends to continue to use, its Investor Relations website as means of disclosing material nonpublic information and for complying with its disclosure obligations under Regulation FD. This press release is being furnished as an exhibit to a Current Report on Form 8-K filed with the Securities and Exchange Commission and will be available at http://www.sec.gov/.

[0001628280-25-004265:8k_2_02:29]
About Lumentum

[0001628280-25-004265:8k_2_02:30]
Lumentum (NASDAQ: LITE) is a market-leading designer and manufacturer of innovative optical and photonic products enabling optical networking and laser applications worldwide. Lumentum optical components and subsystems are part of virtually every type of telecom, enterprise, and data center network. Lumentum lasers enable advanced manufacturing techniques and diverse applications including next-generation imaging and sensing capabilities. Lumentum is headquartered in San Jose, California with R&D, manufacturing, and sales offices worldwide. For more information, visit www.lumentum.com and follow Lumentum on LinkedIn, X (formerly known as Twitter), Facebook, Instagram and YouTube.

[0001628280-25-004265:8k_2_02:31]
Forward-Looking Statements

[0001628280-25-004265:8k_2_02:32]
Contact Information

[0001628280-25-004265:8k_2_02:33]
Investors:    Kathy Ta, (408) 750-3853; investor.relations@lumentum.com

[0001628280-25-004265:8k_2_02:34]
Media:        Noël Bilodeau, 408-439-2140; noel.bilodeau@lumentum.com

[0001628280-25-004265:8k_2_02:35]
Category:    Financial

[0001628280-25-004265:8k_2_02:36]
The following financial tables are presented in accordance with GAAP, unless otherwise specified.

[0001628280-25-004265:8k_2_02:37]
LUMENTUM HOLDINGS INC.

[0001628280-25-004265:8k_2_02:38]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001628280-25-004265:8k_2_02:39]
(in millions, except per share data)

[0001628280-25-004265:8k_2_02:40]
(unaudited)

[0001628280-25-004265:8k_2_02:41]
|  | Three Months Ended |  | Six Months Ended |
|  | December 28, 2024 |  | December 30, 2023 |  | December 28, 2024 |  | December 30, 2023 |
| Net revenue | $ | 402.2 |  |  | $ | 366.8 |  |  | $ | 739.1 |  |  | $ | 684.4 |  |
| Cost of sales | 281.2 |  |  | 281.3 |  |  | 517.7 |  |  | 504.2 |  |
| Amortization of acquired developed intangibles | 21.4 |  |  | 21.5 |  |  | 43.9 |  |  | 39.5 |  |
| Gross profit | 99.6 |  |  | 64.0 |  |  | 177.5 |  |  | 140.7 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 74.2 |  |  | 78.3 |  |  | 148.5 |  |  | 151.8 |  |
| Selling, general and administrative | 76.3 |  |  | 85.1 |  |  | 152.6 |  |  | 158.1 |  |
| Restructuring and related charges | 0.7 |  |  | 5.8 |  |  | 10.4 |  |  | 16.8 |  |
| Total operating expenses | 151.2 |  |  | 169.2 |  |  | 311.5 |  |  | 326.7 |  |
| Loss from operations | (51.6) |  |  | (105.2) |  |  | (134.0) |  |  | (186.0) |  |
| Interest expense | (5.6) |  |  | (9.7) |  |  | (11.1) |  |  | (19.4) |  |
| Other income, net | 14.9 |  |  | 13.4 |  |  | 23.6 |  |  | 34.6 |  |
| Loss before income taxes | (42.3) |  |  | (101.5) |  |  | (121.5) |  |  | (170.8) |  |
| Income tax provision (benefit) | 18.6 |  |  | (2.4) |  |  | 21.8 |  |  | (3.8) |  |
| Net loss | $ | (60.9) |  |  | $ | (99.1) |  |  | $ | (143.3) |  |  | $ | (167.0) |  |
| Net loss per share: |  |  |  |  |  |  |  |
| Basic | $ | (0.88) |  |  | $ | (1.47) |  |  | $ | (2.09) |  |  | $ | (2.49) |  |
| Diluted | $ | (0.88) |  |  | $ | (1.47) |  |  | $ | (2.09) |  |  | $ | (2.49) |  |
| Shares used to compute net loss per share: |  |  |  |  |  |  |  |
| Basic | 68.9 |  |  | 67.2 |  |  | 68.6 |  |  | 67.0 |  |
| Diluted | 68.9 |  |  | 67.2 |  |  | 68.6 |  |  | 67.0 |  |

[0001628280-25-004265:8k_2_02:42]
LUMENTUM HOLDINGS INC.

[0001628280-25-004265:8k_2_02:43]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001628280-25-004265:8k_2_02:44]
(in millions, except per share data)

[0001628280-25-004265:8k_2_02:45]
(unaudited)

[0001628280-25-004265:8k_2_02:46]
|  | December 28, 2024 |  | June 29, 2024 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 479.7 |  |  | $ | 436.7 |  |
| Short-term investments | 417.0 |  |  | 450.3 |  |
| Accounts receivable, net | 226.9 |  |  | 194.7 |  |
| Inventories | 402.3 |  |  | 398.4 |  |
| Prepayments and other current assets | 125.5 |  |  | 110.0 |  |
| Total current assets | 1,651.4 |  |  | 1,590.1 |  |
| Property, plant and equipment, net | 663.4 |  |  | 572.5 |  |
| Operating lease right-of-use assets, net | 32.9 |  |  | 72.8 |  |
| Goodwill | 1,060.9 |  |  | 1,055.8 |  |
| Other intangible assets, net | 534.9 |  |  | 617.5 |  |
| Deferred tax asset | 11.0 |  |  | 10.7 |  |
| Other non-current assets | 11.6 |  |  | 12.5 |  |
| Total assets | $ | 3,966.1 |  |  | $ | 3,931.9 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 184.7 |  |  | $ | 126.3 |  |
| Accrued payroll and related expenses | 40.1 |  |  | 36.1 |  |
| Accrued expenses | 46.2 |  |  | 52.4 |  |
| Current portion of long-term debt | 9.8 |  |  | — |  |
| Operating lease liabilities, current | 11.2 |  |  | 13.4 |  |
| Other current liabilities | 54.9 |  |  | 41.1 |  |
| Total current liabilities | 346.9 |  |  | 269.3 |  |
| Long-term debt | 2,561.2 |  |  | 2,503.2 |  |
| Operating lease liabilities, non-current | 26.1 |  |  | 43.0 |  |
| Deferred tax liability | 45.4 |  |  | 55.7 |  |
| Other non-current liabilities | 114.2 |  |  | 103.4 |  |
| Total liabilities | 3,093.8 |  |  | 2,974.6 |  |
| Stockholders’ equity: |  |  |  |
| Common stock, $0.001 par value, 990 authorized shares, 69.1 and 67.9 shares issued and outstanding as of December 28, 2024 and June 29, 2024, respectively | 0.1 |  |  | 0.1 |  |
| Additional paid-in capital | 1,892.4 |  |  | 1,835.0 |  |
| Accumulated deficit | (1,030.4) |  |  | (887.1) |  |
| Accumulated other comprehensive income | 10.2 |  |  | 9.3 |  |
| Total stockholders’ equity | 872.3 |  |  | 957.3 |  |
| Total liabilities and stockholders’ equity | $ | 3,966.1 |  |  | $ | 3,931.9 |  |

[0001628280-25-004265:8k_2_02:47]
Use of Non-GAAP Financial Measures

[0001628280-25-004265:8k_2_02:48]
In this press release, Lumentum provides investors with certain non-GAAP financial measures: gross profit, gross margin, research and development expense, selling, general and administrative expense, operating margin, income from operations, interest and other income (expense), net, income before income taxes, provision for income taxes, net income (loss), and net income (loss) per share on a non-GAAP basis, as well as the non-GAAP measures of EBITDA and Adjusted EBITDA. Lumentum believes this non-GAAP financial information provides additional insight into the Company’s on-going business operations and results, and has therefore chosen to provide this information to investors for a more consistent basis of comparison and to help them evaluate the results of the Company’s on-going operations and enable more meaningful period to period comparisons. In addition, the Company believes that providing certain of these measures allows investors to better understand the Company’s operating performance and importantly, to evaluate the methodology and information used by management to monitor, manage, evaluate and measure the Company’s business and results of operations. However, these measures may be different from non-GAAP measures used by other companies, limiting their usefulness for comparison purposes. The non-GAAP financial measures used in this press release should not be considered in isolation from measures of financial performance prepared in accordance with GAAP. Investors are cautioned that there are material limitations associated with the use of non-GAAP financial measures as an analytical tool. In particular, many of the adjustments to our GAAP financial measures reflect the exclusion of items that are recurring and will be reflected in our financial results for the foreseeable future. Further, these non-GAAP financial measures may not be comparable to similarly titled measurements reported by other companies.

[0001628280-25-004265:8k_2_02:49]
Our non-GAAP measures used in this press release exclude (i) stock-based compensation, (ii) acquisition related costs, (iii) amortization of acquired intangibles, (iv) amortization of acquired inventory fair value, (v) restructuring and related charges, (vi) foreign exchange (gains) losses, net, (vii) non-cash interest expense on convertible notes, (viii) intangible assets write-off, (ix) integration related costs, (x) non-GAAP income tax reconciling adjustments, and (xi) other charges or income related to non-recurring activities.

[0001628280-25-004265:8k_2_02:50]
We utilize a long-term projected non-GAAP tax rate to compute our non-GAAP income tax provision. The long-term projected non-GAAP tax rate is based on a multi-year projection of our estimated annual GAAP income tax forecast, adjusted to account for the tax effect of non-GAAP pretax adjustments as well as the effects of significant non-recurring and period specific tax items. Our non-GAAP tax provision for fiscal 2025 is 16.5%. The difference between our GAAP income tax provision and our non-GAAP income tax provision is presented as non-GAAP income tax reconciling adjustments.

[0001628280-25-004265:8k_2_02:51]
A quantitative reconciliation between GAAP and non-GAAP financial data with respect to historical periods is included in the supplemental financial table attached to this press release.

[0001628280-25-004265:8k_2_02:52]
LUMENTUM HOLDINGS INC.

[0001628280-25-004265:8k_2_02:53]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001628280-25-004265:8k_2_02:54]
(in millions, except per share data)

[0001628280-25-004265:8k_2_02:55]
(unaudited)

[0001628280-25-004265:8k_2_02:56]
|  | Three Months Ended |  | Six Months Ended |  |
|  | December 28, 2024 |  | September 28, 2024 |  | December 30, 2023 (1) |  | December 28, 2024 |  | December 30, 2023 (1) |  |
| Gross profit on GAAP basis | $ | 99.6 |  |  | $ | 77.9 |  |  | $ | 64.0 |  |  | $ | 177.5 |  |  | $ | 140.7 |  |  |
| Stock-based compensation | 9.2 |  |  | 9.7 |  |  | 9.0 |  |  | 18.9 |  |  | 15.0 |  |  |
| Amortization of acquired intangibles | 21.4 |  |  | 22.5 |  |  | 21.5 |  |  | 43.9 |  |  | 39.5 |  |  |
| Amortization of acquired inventory fair value adjustments | — |  |  | — |  |  | 3.4 |  |  | — |  |  | 3.4 |  |  |
| Integration related costs | 1.1 |  |  | 1.2 |  |  | 8.3 |  |  | 2.3 |  |  | 11.6 |  |  |
| Other charges (income), net | (1.3) |  |  | (0.9) |  |  | 8.9 |  |  | (2.2) |  |  | 9.2 |  |  |
| Gross profit on non-GAAP basis | $ | 130.0 |  |  | $ | 110.4 |  |  | $ | 115.1 |  |  | $ | 240.4 |  |  | $ | 219.4 |  |  |
| Gross margin on non-GAAP basis | 32.3 | % |  | 32.8 | % |  | 31.4 | % |  | 32.5 | % |  | 32.1 | % |  |
| Research and development on GAAP basis | $ | 74.2 |  |  | $ | 74.3 |  |  | $ | 78.3 |  |  | $ | 148.5 |  |  | 151.8 |  |  |
| Stock-based compensation | (11.4) |  |  | (9.3) |  |  | (10.0) |  |  | (20.7) |  |  | (20.3) |  |  |
| Amortization of acquired intangibles | (0.4) |  |  | (0.4) |  |  | (0.4) |  |  | (0.8) |  |  | (0.7) |  |  |
| Acquisition related costs | — |  |  | — |  |  | (0.1) |  |  | — |  |  | (0.4) |  |  |
| Integration related costs | — |  |  | — |  |  | 0.7 |  |  | — |  |  | 0.3 |  |  |
| Intangible asset write-off | — |  |  | (1.9) |  |  | — |  |  | (1.9) |  |  | — |  |  |
| Other income (charges), net | — |  |  | — |  |  | (0.1) |  |  | — |  |  | (0.8) |  |  |
| Research and development on non-GAAP basis | $ | 62.4 |  |  | $ | 62.7 |  |  | $ | 68.4 |  |  | $ | 125.1 |  |  | $ | 129.9 |  |  |
| Selling, general and administrative on GAAP basis | $ | 76.3 |  |  | $ | 76.3 |  |  | $ | 85.1 |  |  | $ | 152.6 |  |  | $ | 158.1 |  |  |
| Stock-based compensation | (18.2) |  |  | (16.6) |  |  | (15.6) |  |  | (34.8) |  |  | (31.4) |  |  |
| Amortization of acquired intangibles | (17.2) |  |  | (18.8) |  |  | (15.7) |  |  | (36.0) |  |  | (26.4) |  |  |
| Acquisition related costs | — |  |  | — |  |  | (8.9) |  |  | — |  |  | (12.6) |  |  |
| Integration related costs | (2.0) |  |  | (2.2) |  |  | (1.6) |  |  | (4.2) |  |  | (3.9) |  |  |
| Other (charges) income, net | (3.0) |  |  | (1.0) |  |  | (3.5) |  |  | (4.0) |  |  | (3.2) |  |  |
| Selling, general and administrative on non-GAAP basis | $ | 35.9 |  |  | $ | 37.7 |  |  | $ | 39.8 |  |  | $ | 73.6 |  |  | $ | 80.6 |  |  |
| Loss from operations on GAAP basis | $ | (51.6) |  |  | $ | (82.4) |  |  | $ | (105.2) |  |  | $ | (134.0) |  |  | $ | (186.0) |  |  |
| Stock-based compensation | 38.8 |  |  | 35.6 |  |  | 34.6 |  |  | 74.4 |  |  | 66.7 |  |  |
| Amortization of acquired intangibles | 39.0 |  |  | 41.7 |  |  | 37.6 |  |  | 80.7 |  |  | 66.6 |  |  |
| Amortization of acquired inventory fair value adjustments | — |  |  | — |  |  | 3.4 |  |  | — |  |  | 3.4 |  |  |
| Acquisition related costs | — |  |  | — |  |  | 9.0 |  |  | — |  |  | 13.0 |  |  |
| Integration related costs | 3.1 |  |  | 3.4 |  |  | 9.2 |  |  | 6.5 |  |  | 15.2 |  |  |
| Restructuring and related charges | 0.7 |  |  | 9.7 |  |  | 5.8 |  |  | 10.4 |  |  | 16.8 |  |  |
| Intangible asset write-off | — |  |  | 1.9 |  |  | — |  |  | 1.9 |  |  | — |  |  |
| Other charges, net | 1.7 |  |  | 0.1 |  |  | 12.5 |  |  | 1.8 |  |  | 13.2 |  |  |
| Income from operations on non-GAAP basis | $ | 31.7 |  |  | $ | 10.0 |  |  | $ | 6.9 |  |  | $ | 41.7 |  |  | $ | 8.9 |  |  |
| Operating margin on non-GAAP basis | 7.9 | % |  | 3.0 | % |  | 1.9 | % |  | 5.6 | % |  | 1.3 | % |  |
| Interest and other income, net on GAAP basis | $ | 9.3 |  |  | $ | 3.2 |  |  | $ | 3.7 |  |  | $ | 12.5 |  |  | $ | 15.2 |  |  |
| Foreign exchange (gains) losses, net | (5.9) |  |  | 0.7 |  |  | 3.8 |  |  | (5.2) |  |  | 4.2 |  |  |

[0001628280-25-004265:8k_2_02:57]
| Non-cash interest expense on convertible notes and other income and expenses, net | 0.8 |  |  | 0.7 |  |  | 4.8 |  |  | 1.5 |  |  | 9.7 |  |  |
| Interest and other income, net on non-GAAP basis | $ | 4.2 |  |  | $ | 4.6 |  |  | $ | 12.3 |  |  | $ | 8.8 |  |  | $ | 29.1 |  |  |
| Loss before income taxes on GAAP basis | $ | (42.3) |  |  | $ | (79.2) |  |  | $ | (101.5) |  |  | $ | (121.5) |  |  | $ | (170.8) |  |  |
| Stock-based compensation | 38.8 |  |  | 35.6 |  |  | 34.6 |  |  | 74.4 |  |  | 66.7 |  |  |
| Acquisition related costs | — |  |  | — |  |  | 9.0 |  |  | — |  |  | 13.0 |  |  |
| Integration related costs | 3.1 |  |  | 3.4 |  |  | 9.2 |  |  | 6.5 |  |  | 15.2 |  |  |
| Amortization of acquired intangibles | 39.0 |  |  | 41.7 |  |  | 37.6 |  |  | 80.7 |  |  | 66.6 |  |  |
| Amortization of acquired inventory fair value adjustments | — |  |  | — |  |  | 3.4 |  |  | — |  |  | 3.4 |  |  |
| Restructuring and related charges | 0.7 |  |  | 9.7 |  |  | 5.8 |  |  | 10.4 |  |  | 16.8 |  |  |
| Intangible asset write-off | — |  |  | 1.9 |  |  | — |  |  | 1.9 |  |  | — |  |  |
| Foreign exchange (gains) losses, net | (5.9) |  |  | 0.7 |  |  | 3.8 |  |  | (5.2) |  |  | 4.2 |  |  |
| Non-cash interest expense on convertible notes and other income and expenses, net | 0.8 |  |  | 0.7 |  |  | 4.8 |  |  | 1.5 |  |  | 9.7 |  |  |
| Other charges, net | 1.7 |  |  | 0.1 |  |  | 12.5 |  |  | 1.8 |  |  | 13.2 |  |  |
| Income before income taxes on non-GAAP basis | $ | 35.9 |  |  | $ | 14.6 |  |  | $ | 19.2 |  |  | $ | 50.5 |  |  | $ | 38.0 |  |  |
| Income tax provision (benefit) on GAAP basis | $ | 18.6 |  |  | $ | 3.2 |  |  | $ | (2.4) |  |  | $ | 21.8 |  |  | $ | (3.8) |  |  |
| Non-GAAP income tax reconciling adjustments | (12.7) |  |  | (0.8) |  |  | 5.2 |  |  | (13.5) |  |  | 9.3 |  |  |
| Income tax provision on non-GAAP basis | $ | 5.9 |  |  | $ | 2.4 |  |  | $ | 2.8 |  |  | $ | 8.3 |  |  | $ | 5.5 |  |  |
| Net loss on GAAP basis | $ | (60.9) |  |  | $ | (82.4) |  |  | $ | (99.1) |  |  | $ | (143.3) |  |  | $ | (167.0) |  |  |
| Stock-based compensation | 38.8 |  |  | 35.6 |  |  | 34.6 |  |  | 74.4 |  |  | 66.7 |  |  |
| Acquisition related costs | — |  |  | — |  |  | 9.0 |  |  | — |  |  | 13.0 |  |  |
| Integration related costs | 3.1 |  |  | 3.4 |  |  | 9.2 |  |  | 6.5 |  |  | 15.2 |  |  |
| Amortization of acquired intangibles | 39.0 |  |  | 41.7 |  |  | 37.6 |  |  | 80.7 |  |  | 66.6 |  |  |
| Amortization of acquired inventory fair value adjustments | — |  |  | — |  |  | 3.4 |  |  | — |  |  | 3.4 |  |  |
| Restructuring and related charges | 0.7 |  |  | 9.7 |  |  | 5.8 |  |  | 10.4 |  |  | 16.8 |  |  |
| Intangible asset write-off | — |  |  | 1.9 |  |  | — |  |  | 1.9 |  |  | — |  |  |
| Foreign exchange (gains) losses, net | (5.9) |  |  | 0.7 |  |  | 3.8 |  |  | (5.2) |  |  | 4.2 |  |  |
| Non-cash interest expense on convertible notes and other income and expenses, net | 0.8 |  |  | 0.7 |  |  | 4.8 |  |  | 1.5 |  |  | 9.7 |  |  |
| Non-GAAP income tax reconciling adjustments | 12.7 |  |  | 0.8 |  |  | (5.2) |  |  | 13.5 |  |  | (9.3) |  |  |
| Other charges, net | 1.7 |  |  | 0.1 |  |  | 12.5 |  |  | 1.8 |  |  | 13.2 |  |  |
| Net income on non-GAAP basis | $ | 30.0 |  |  | $ | 12.2 |  |  | $ | 16.4 |  |  | $ | 42.2 |  |  | $ | 32.5 |  |  |
| Net income per share on non-GAAP basis | $ | 0.42 |  |  | $ | 0.18 |  |  | $ | 0.24 |  |  | $ | 0.60 |  |  | $ | 0.48 |  |  |
| Shares used in per share calculation - diluted on GAAP basis | 68.9 |  |  | 68.3 |  |  | 67.2 |  |  | 68.6 |  |  | 67.0 |  |  |
| Non-GAAP adjustment (2) | 2.7 |  |  | 0.8 |  |  | 0.2 |  |  | 1.8 |  |  | 0.3 |  |  |
| Shares used in per share calculation - diluted on non-GAAP basis | 71.6 |  |  | 69.1 |  |  | 67.4 |  |  | 70.4 |  |  | 67.3 |  |  |

[0001628280-25-004265:8k_2_02:58]
(1) During the first fiscal quarter of 2025, the Company refined its methodology to report non-GAAP measures.  The change does not impact the Company’s financial position, cash flows, or GAAP consolidated results of operations. Prior period non-GAAP financial measures and the associated GAAP to non-GAAP reconciliations presented in this press release have been recast to conform to the current presentation.

[0001628280-25-004265:8k_2_02:59]
(2) The adjustment represents the dilutive impact of equity-based compensation awards in accordance with the treasury stock method and dilutive shares from our convertible debt instruments under the if-converted method, which are anti-dilutive for GAAP purposes as we recognized a GAAP net loss.

[0001628280-25-004265:8k_2_02:60]
LUMENTUM HOLDINGS INC.

[0001628280-25-004265:8k_2_02:61]
RECONCILIATION OF GAAP NET INCOME TO ADJUSTED EBITDA

[0001628280-25-004265:8k_2_02:62]
(in millions, except per share data)

[0001628280-25-004265:8k_2_02:63]
(unaudited)

[0001628280-25-004265:8k_2_02:64]
|  | Three Months Ended |  |  |  | Six Months Ended |
|  | December 28, 2024 |  |  |  | September 28, 2024 |  | December 30, 2023 (1) |  |  |  |  |  | December 28, 2024 |  | December 30, 2023 (1) |
| GAAP net loss | $ | (60.9) |  |  |  |  | $ | (82.4) |  |  | $ | (99.1) |  |  |  |  |  |  | $ | (143.3) |  |  | $ | (167.0) |  |
| Interest and other expense, net | (9.3) |  |  |  |  | (3.2) |  |  | (3.7) |  |  |  |  |  |  | (12.5) |  |  | (15.2) |  |
| Income tax provision (benefit) | 18.6 |  |  |  |  | 3.2 |  |  | (2.4) |  |  |  |  |  |  | 21.8 |  |  | (3.8) |  |
| Depreciation | 25.9 |  |  |  |  | 27.0 |  |  | 27.2 |  |  |  |  |  |  | 52.9 |  |  | 55.4 |  |
| Amortization of acquired intangibles | 39.0 |  |  |  |  | 41.7 |  |  | 37.6 |  |  |  |  |  |  | 80.7 |  |  | 66.6 |  |
| EBITDA | 13.3 |  |  |  |  | (13.7) |  |  | (40.4) |  |  |  |  |  |  | (0.4) |  |  | (64.0) |  |
| Amortization of inventory fair value adjustments | — |  |  |  |  | — |  |  | 3.4 |  |  |  |  |  |  | — |  |  | 3.4 |  |
| Restructuring and related charges | 0.7 |  |  |  |  | 9.7 |  |  | 5.8 |  |  |  |  |  |  | 10.4 |  |  | 16.8 |  |
| Stock-based compensation | 38.8 |  |  |  |  | 35.6 |  |  | 34.6 |  |  |  |  |  |  | 74.4 |  |  | 66.7 |  |
| Acquisition related costs | — |  |  |  |  | — |  |  | 9.0 |  |  |  |  |  |  | — |  |  | 13.0 |  |
| Integration related costs | 3.1 |  |  |  |  | 3.4 |  |  | 9.2 |  |  |  |  |  |  | 6.5 |  |  | 15.2 |  |
| Intangible asset write-off | — |  |  |  | 1.9 |  |  | — |  |  |  |  |  |  | 1.9 |  |  | — |  |
| Other charges (gains), net | 1.7 |  |  |  |  | 0.1 |  |  | 11.3 |  |  |  |  |  |  | 1.8 |  |  | 7.8 |  |
| Adjusted EBITDA | $ | 57.6 |  |  |  |  | $ | 37.0 |  |  | $ | 32.9 |  |  |  |  |  |  | $ | 94.6 |  |  | $ | 58.9 |  |

[0001628280-25-004265:8k_2_02:65]
(1) During the first fiscal quarter of 2025, the Company refined its methodology to report non-GAAP measures.  The change does not impact the Company’s financial position, cash flows, or GAAP consolidated results of operations. Prior period non-GAAP financial measures and the associated GAAP to non-GAAP reconciliations presented in this press release have been recast to conform to the current presentation.
