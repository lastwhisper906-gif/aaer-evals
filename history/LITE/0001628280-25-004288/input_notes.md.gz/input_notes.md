# LITE notes — 0001628280-25-004288


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001628280-25-004288:notes:1]
[same as prior period, unchanged from 0001628280-24-046443:notes:1]

[0001628280-25-004288:notes:2]
[same as prior period, unchanged from 0001628280-24-046443:notes:2]

[0001628280-25-004288:notes:3]
[same as prior period, unchanged from 0001628280-24-046443:notes:3]

[0001628280-25-004288:notes:4]
[same as prior period, unchanged from 0001628280-24-046443:notes:4]

[0001628280-25-004288:notes:5]
[same as prior period, unchanged from 0001628280-24-046443:notes:5]

[0001628280-25-004288:notes:6]
[same as prior period, unchanged from 0001628280-24-046443:notes:6]

[0001628280-25-004288:notes:7]
[same as prior period, unchanged from 0001628280-24-046443:notes:7]

[0001628280-25-004288:notes:8]
[same as prior period, unchanged from 0001628280-24-046443:notes:8]

[0001628280-25-004288:notes:9]
[same as prior period, unchanged from 0001628280-24-046443:notes:9]

[0001628280-25-004288:notes:10]
[same as prior period, unchanged from 0001628280-24-046443:notes:10]

[0001628280-25-004288:notes:11]
[same as prior period, unchanged from 0001628280-24-046443:notes:11]

[0001628280-25-004288:notes:12]
[same as prior period, unchanged from 0001628280-24-046443:notes:12]

[0001628280-25-004288:notes:13]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Every fifth or sixth fiscal year will have a 53-week period. The additional week in a 53-week year is added to the third quarter, making such quarter consist of 14 weeks. Our fiscal 2025 is a 52-week year ending on June 28, 2025, with the quarter ended December 28, 2024 being a 13-week quarterly period. Our fiscal 2024 was a 52-week year that ended on June 29, 2024, with the quarter ended December 30, 2023 being a 13-week quarterly period.

[0001628280-25-004288:notes:14]
[same as prior period, unchanged from 0001628280-24-046443:notes:14]

[0001628280-25-004288:notes:15]
[same as prior period, unchanged from 0001628280-24-046443:notes:15]

[0001628280-25-004288:notes:16]
Accounting Policies

[0001628280-25-004288:notes:17]
The condensed consolidated financial statements and accompanying notes should be read in conjunction with the audited consolidated financial statements and accompanying notes included in our Annual Report on Form 10-K for the fiscal year ended June 29, 2024. There were no significant changes to our accounting policies during the six months ended December 28, 2024.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001628280-25-004288:notes:18]
Note 2. Recently Issued Accounting Pronouncements

[0001628280-25-004288:notes:19]
In November 2024, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) No. 2024-04, Debt with Conversion and Other Options (Subtopic 470-20): Induced Conversions of Convertible Debt Instruments, which clarify the requirements related to accounting for the settlement of a debt as an induced conversion. ASU 2024-04 is intended to improve the relevance and consistency in application of the induced conversion guidance in Subtopic 470-20 for convertible debt instruments with cash conversion features and debt instruments that are not currently convertible.  ASU 2024-04 is effective for fiscal years beginning after December 15, 2025, with early adoption permitted. We plan to adopt ASU 2024-04 in the first quarter of fiscal year 2026. We are currently evaluating the impact of this ASU on our financial statements and disclosures.

[0001628280-25-004288:notes:20]
In November 2024, the FASB issued ASU 2024-03, Reporting Comprehensive Income - Expense Disaggregation Disclosures (Subtopic 220-40), which requires disaggregation of certain expense captions into specified categories in disclosures within the footnotes to the financial statements. ASU 2024-03 is effective for fiscal years beginning after December 15, 2026, with early adoption permitted. We plan to adopt ASU 2024-04 in the first quarter of fiscal year 2027. We are currently evaluating the impact of this ASU on our financial statements and disclosures.

[0001628280-25-004288:notes:21]
In March 2024, the FASB issued ASU 2024-02: Codification Improvements - Amendments to Remove References to the Concepts Statements, which contains amendments to the Codification that remove references to various FASB Concepts Statements.  ASU 2024-02 is effective for fiscal years beginning after December 15, 2024, with early adoption permitted. We do not expect this ASU to have a material impact on our consolidated financial statements and disclosures.

[0001628280-25-004288:notes:22]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures, which requires disaggregated information about a reporting entity’s effective tax rate reconciliation as well as information on income tax paid. ASU 2023-09 is effective for fiscal years beginning after December 15, 2024, with early adoption permitted. We are currently evaluating the impact of this ASU on our income tax disclosures within the consolidated financial statements.

[0001628280-25-004288:notes:23]
In November 2023, the FASB issued ASU 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures, which updates reportable segment disclosure requirements primarily through enhanced disclosures about significant segment expenses. ASU 2023-07 does not change how a public entity identifies its operating segments, aggregates those operating segments, or applies quantitative thresholds to determine its reportable segments. The update is effective for fiscal years beginning after December 15, 2023 and interim periods within fiscal years beginning after December 15, 2024, with early adoption permitted. The amendments should be applied retrospectively to all prior periods presented in the financial statements. We plan to adopt ASU 2023-07 in the fiscal fourth quarter of 2025. We are currently evaluating the impact of adopting this ASU on our consolidated financial statements and disclosures.


## us-gaap:EarningsPerShareTextBlock

[0001628280-25-004288:notes:24]
[same as prior period, unchanged from 0001628280-24-046443:notes:21]

[0001628280-25-004288:notes:25]
[same as prior period, unchanged from 0001628280-24-046443:notes:22]

[0001628280-25-004288:notes:26]
|  | Three Months Ended |  | Six Months Ended |
|  | December 28, 2024 |  | December 30, 2023 |  | December 28, 2024 |  | December 30, 2023 |
| Numerator: |  |  |  |  |  |  |  |
| Net loss - basic and diluted | $ | (60.9) |  |  | $ | (99.1) |  |  | $ | (143.3) |  |  | $ | (167.0) |  |
| Denominator: |  |  |  |  |  |  |  |
| Weighted average common shares outstanding - basic and diluted | 68.9 |  |  | 67.2 |  |  | 68.6 |  |  | 67.0 |  |
| Net loss per share: |  |  |  |  |  |  |  |
| Basic | $ | (0.88) |  |  | $ | (1.47) |  |  | $ | (2.09) |  |  | $ | (2.49) |  |
| Diluted | $ | (0.88) |  |  | $ | (1.47) |  |  | $ | (2.09) |  |  | $ | (2.49) |  |

[0001628280-25-004288:notes:27]
Anti-dilutive shares excluded from the calculation of diluted net loss per share for the three months ended December 28, 2024 include 4.4 million shares issuable under restricted stock units (“RSUs”) and performance stock units (“PSUs”), 0.1 million shares issuable under the Employee Stock Purchase Plan (the “2015 Purchase Plan”), and 0.8 million shares outstanding related to stock options.  In addition, the calculation of diluted net loss per share excludes the impact of our convertible notes under the if-converted method as we recognized net loss. Average anti-dilutive shares excluded from the calculation of diluted net loss per share for the six months ended December 28, 2024 include 0.5 million shares related to convertible notes, 4.6 million shares issuable under RSUs and PSUs, 0.1 million shares issuable under the 2015 Purchase Plan, and 0.9 million shares outstanding related to stock options. Refer to “Note 13. Equity.”

[0001628280-25-004288:notes:28]
Anti-dilutive shares excluded from the calculation of diluted net loss per share for the three months ended December 30, 2023 include 31.2 million shares related to convertible notes, 4.4 million shares issuable under RSUs and PSUs, and 0.2 million shares issuable under the 2015 Purchase Plan, and 1.1 million shares outstanding related to stock options. Average anti-dilutive shares excluded from the calculation of diluted net loss per share for the six months ended December 30, 2023 include 31.2 million shares related to convertible notes, 4.5 million shares issuable under RSUs and PSUs, 0.2 million shares issuable under the 2015 Purchase Plan, and 1.1 million shares outstanding related to stock options.
Potentially dilutive common shares issuable upon conversion of our outstanding convertible notes are determined using the if-converted method.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001628280-25-004288:notes:29]
[same as prior period, unchanged from 0001628280-24-046443:notes:26]

[0001628280-25-004288:notes:30]
[same as prior period, unchanged from 0001628280-24-046443:notes:27]

[0001628280-25-004288:notes:31]
[same as prior period, unchanged from 0001628280-24-046443:notes:28]

[0001628280-25-004288:notes:32]
[same as prior period, unchanged from 0001628280-24-046443:notes:29]

[0001628280-25-004288:notes:33]
[same as prior period, unchanged from 0001628280-24-046443:notes:30]

[0001628280-25-004288:notes:34]
[same as prior period, unchanged from 0001628280-24-046443:notes:31]

[0001628280-25-004288:notes:35]
[same as prior period, unchanged from 0001628280-24-046443:notes:32]

[0001628280-25-004288:notes:36]
The cash consideration of $705.0 million, which was funded by the cash balances of Lumentum, includes $75.8 million of cash held in an escrow fund to support Cloud Light’s indemnification obligations under the Merger Agreement and customary adjustment for working capital.  Since the measurement period expired, any future adjustments will be included in our earnings.  No amount of the escrow funds have been released as the parties have not mutually agreed upon the indemnification obligation and working capital adjustment.

[0001628280-25-004288:notes:37]
We incurred a total of $9.6 million of acquisition-related costs in fiscal year 2024, of which $9.2 million was incurred during the six months ended December 30, 2023, representing professional and other direct acquisition costs, which are recorded as selling, general and administrative expense in the condensed consolidated statement of operations when incurred.

[0001628280-25-004288:notes:38]
[same as prior period, unchanged from 0001628280-24-046443:notes:35]

[0001628280-25-004288:notes:39]
[same as prior period, unchanged from 0001628280-24-046443:notes:36]

[0001628280-25-004288:notes:40]
[same as prior period, unchanged from 0001628280-24-046443:notes:37]

[0001628280-25-004288:notes:41]
[same as prior period, unchanged from 0001628280-24-046443:notes:38]

[0001628280-25-004288:notes:42]
Due to the integration of the combined businesses, including our sales and customer service organizations, operations teams and manufacturing facilities, it is impracticable to determine Cloud Light’s contribution to our revenue and earnings for the three and six months ended December 28, 2024.

[0001628280-25-004288:notes:43]
[same as prior period, unchanged from 0001628280-24-046443:notes:40]

[0001628280-25-004288:notes:44]
The following supplemental pro forma information presents the combined results of operations for the three and six months ended December 28, 2024 and December 30, 2023, as if the acquisition was completed on July 3, 2022, the first day of the fiscal year 2023. The supplemental pro forma financial information presented below is not necessarily indicative of the financial position or results of operations that would have been realized if the acquisition had been completed on the date indicated. The supplemental pro forma financial information does not reflect synergies that might have been achieved, nor is it indicative of future operating results or financial position.

[0001628280-25-004288:notes:45]
[same as prior period, unchanged from 0001628280-24-046443:notes:42]

[0001628280-25-004288:notes:46]
[same as prior period, unchanged from 0001628280-24-046443:notes:43]

[0001628280-25-004288:notes:47]
|  | Three Months Ended |  | Six Months Ended |
|  | December 28, 2024 |  | December 30, 2023 |  | December 28, 2024 |  | December 30, 2023 |
| Net revenue | $ | 402.2 |  |  | $ | 386.5 |  |  | $ | 739.1 |  |  | $ | 773.1 |  |
| Net loss | $ | (58.3) |  |  | $ | (96.3) |  |  | $ | (137.2) |  |  | $ | (159.9) |  |


## us-gaap:CashCashEquivalentsAndShortTermInvestmentsTextBlock

[0001628280-25-004288:notes:48]
[same as prior period, unchanged from 0001628280-24-046443:notes:45]

[0001628280-25-004288:notes:49]
[same as prior period, unchanged from 0001628280-24-046443:notes:46]

[0001628280-25-004288:notes:50]
|  | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | Fair Value |
| December 28, 2024: |  |  |  |  |  |  |  |
| Cash | $ | 337.8 |  |  | $ | — |  |  | $ | — |  |  | $ | 337.8 |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Money market funds | 130.9 |  |  | — |  |  | — |  |  | 130.9 |  |
| U.S. Treasury securities | 11.0 |  |  | — |  |  | — |  |  | 11.0 |  |
| Total cash and cash equivalents | $ | 479.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 479.7 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Commercial paper | $ | 13.2 |  |  | $ | — |  |  | $ | — |  |  | $ | 13.2 |  |
| Corporate debt securities | 241.5 |  |  | 0.3 |  |  | (0.5) |  |  | 241.3 |  |
| U.S. Agency securities | 49.5 |  |  | — |  |  | (0.1) |  |  | 49.4 |  |
| U.S. Treasury securities | 113.2 |  |  | — |  |  | (0.1) |  |  | 113.1 |  |
| Total short-term investments | $ | 417.4 |  |  | $ | 0.3 |  |  | $ | (0.7) |  |  | $ | 417.0 |  |
| June 29, 2024: |  |  |  |  |  |  |  |
| Cash | $ | 196.9 |  |  | $ | — |  |  | $ | — |  |  | $ | 196.9 |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Commercial paper | 15.9 |  |  | — |  |  | — |  |  | 15.9 |  |
| Money market funds | 223.9 |  |  | — |  |  | — |  |  | 223.9 |  |
| Total cash and cash equivalents | $ | 436.7 |  |  | $ | — |  |  | $ | — |  |  | $ | 436.7 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Certificates of deposit | $ | 0.8 |  |  | $ | — |  |  | $ | — |  |  | $ | 0.8 |  |
| Commercial paper | 12.6 |  |  | — |  |  | — |  |  | 12.6 |  |
| Corporate debt securities | 244.5 |  |  | — |  |  | (0.6) |  |  | 243.9 |  |
| U.S. Agency securities | 81.2 |  |  | — |  |  | (0.3) |  |  | 80.9 |  |
| U.S. Treasury securities | 112.6 |  |  | — |  |  | (0.5) |  |  | 112.1 |  |
| Total short-term investments | $ | 451.7 |  |  | $ | — |  |  | $ | (1.4) |  |  | $ | 450.3 |  |

[0001628280-25-004288:notes:51]
[same as prior period, unchanged from 0001628280-24-046443:notes:48]

[0001628280-25-004288:notes:52]
We use the specific-identification method to determine any realized gains or losses from the sale of our short-term investments classified as available-for-sale. During the three and six months ended December 28, 2024 and December 30, 2023, we did not realize significant gains or losses on a gross level from the sale of our short-term investments classified as available-for-sale.

[0001628280-25-004288:notes:53]
During the three and six months ended December 28, 2024, our other income, net was $14.9 million and $23.6 million, respectively, which includes interest and investment income on cash equivalents and short-term investments of $9.0 million and $18.4 million, respectively.

[0001628280-25-004288:notes:54]
During the three and six months ended December 30, 2023, our other income, net was $13.4 million, and $34.6 million, respectively, which includes interest and investment income on cash equivalents and short-term investments of $17.1 million and $38.8 million, respectively.

[0001628280-25-004288:notes:55]
As of December 28, 2024 and June 29, 2024, we recorded interest receivables of $6.4 million and $5.8 million, respectively, in prepayments and other current assets within the condensed consolidated balance sheets. We did not recognize an allowance for credit losses against interest receivables in any of the periods presented, as there were no such losses.

[0001628280-25-004288:notes:56]
[same as prior period, unchanged from 0001628280-24-046443:notes:52]

[0001628280-25-004288:notes:57]
|  | Continuous Loss Position for More Than 12 Months |  | Continuous Loss Position for Less Than 12 Months |  | Gross Unrealized Losses |  |  |  |  |  |  |  |  |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  |  |  |  |  |  |  |  |  |
| December 28, 2024: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | — |  |  | $ | — |  |  | $ | 36.4 |  |  | $ | (0.1) |  |  | $ | (0.1) |  |  |  |  |  |  |  |  |  |
| Commercial paper | — |  |  | — |  |  | 7.1 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 31.7 |  |  | — |  |  | 104.4 |  |  | (0.5) |  |  | (0.5) |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 58.6 |  |  | — |  |  | 28.0 |  |  | (0.1) |  |  | (0.1) |  |  |  |  |  |  |  |  |  |
| Total | $ | 90.3 |  |  | $ | — |  |  | $ | 175.9 |  |  | $ | (0.7) |  |  | $ | (0.7) |  |  |  |  |  |  |  |  |  |
| June 29, 2024: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | 62.3 |  |  | $ | (0.3) |  |  | $ | 12.6 |  |  | $ | — |  |  | $ | (0.3) |  |  |  |  |  |  |  |  |  |
| Commercial paper | — |  |  | — |  |  | 28.6 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 133.7 |  |  | (0.5) |  |  | 90.6 |  |  | (0.2) |  |  | (0.7) |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 72.3 |  |  | (0.4) |  |  | 39.7 |  |  | (0.1) |  |  | (0.5) |  |  |  |  |  |  |  |  |  |
| Total | $ | 268.3 |  |  | $ | (1.2) |  |  | $ | 171.5 |  |  | $ | (0.3) |  |  | $ | (1.5) |  |  |  |  |  |  |  |  |  |

[0001628280-25-004288:notes:58]
[same as prior period, unchanged from 0001628280-24-046443:notes:54]

[0001628280-25-004288:notes:59]
|  | December 28, 2024 |  | June 29, 2024 |
|  | Amortized Cost |  | Fair Value |  | Amortized Cost |  | Fair Value |
| Due within 1 year | $ | 265.8 |  |  | $ | 265.9 |  |  | $ | 405.5 |  |  | $ | 404.1 |  |
| Due in 1 year to 5 years | 151.6 |  |  | 151.1 |  |  | 46.2 |  |  | 46.2 |  |
| Total | $ | 417.4 |  |  | $ | 417.0 |  |  | $ | 451.7 |  |  | $ | 450.3 |  |

[0001628280-25-004288:notes:60]
[same as prior period, unchanged from 0001628280-24-046443:notes:56]


## us-gaap:FairValueDisclosuresTextBlock

[0001628280-25-004288:notes:61]
[same as prior period, unchanged from 0001628280-24-046443:notes:57]

[0001628280-25-004288:notes:62]
[same as prior period, unchanged from 0001628280-24-046443:notes:58]

[0001628280-25-004288:notes:63]
[same as prior period, unchanged from 0001628280-24-046443:notes:59]

[0001628280-25-004288:notes:64]
[same as prior period, unchanged from 0001628280-24-046443:notes:60]

[0001628280-25-004288:notes:65]
[same as prior period, unchanged from 0001628280-24-046443:notes:61]

[0001628280-25-004288:notes:66]
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| December 28, 2024: (1) |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |
| Money market funds | $ | 130.9 |  |  | $ | — |  |  | $ | — |  |  | $ | 130.9 |  |
| U.S. Treasury securities | 11.0 |  |  | — |  |  | — |  |  | 11.0 |  |
| Short-term investments: |  |  |  |  |  |  |  |
| Commercial paper | — |  |  | 13.2 |  |  | — |  |  | 13.2 |  |
| Corporate debt securities | — |  |  | 241.2 |  |  | — |  |  | 241.2 |  |
| U.S. Agency securities | — |  |  | 49.5 |  |  | — |  |  | 49.5 |  |
| U.S. Treasury securities | 113.1 |  |  | — |  |  | — |  |  | 113.1 |  |
| Total assets | $ | 255.0 |  |  | $ | 303.9 |  |  | $ | — |  |  | $ | 558.9 |  |

[0001628280-25-004288:notes:67]
(1)  Excludes $337.8 million in cash held in our bank accounts as of December 28, 2024.

[0001628280-25-004288:notes:68]
[same as prior period, unchanged from 0001628280-24-046443:notes:64]

[0001628280-25-004288:notes:69]
[same as prior period, unchanged from 0001628280-24-046443:notes:65]

[0001628280-25-004288:notes:70]
[same as prior period, unchanged from 0001628280-24-046443:notes:66]

[0001628280-25-004288:notes:71]
[same as prior period, unchanged from 0001628280-24-046443:notes:67]

[0001628280-25-004288:notes:72]
[same as prior period, unchanged from 0001628280-24-046443:notes:68]

[0001628280-25-004288:notes:73]
|  | December 28, 2024 |  | June 29, 2024 |
|  | Carrying Amount |  | Estimated Fair Value |  | Carrying Amount |  | Estimated Fair Value |
| 2029 Notes | $ | 599.9 |  |  | $ | 845.7 |  |  | $ | 599.4 |  |  | $ | 588.8 |  |
| 2028 Notes | 857.1 |  |  | 833.5 |  |  | 856.6 |  |  | 680.2 |  |
| 2026 Notes | 1,047.7 |  |  | 1,158.5 |  |  | 1,047.2 |  |  | 948.3 |  |
|  | $ | 2,504.7 |  |  | $ | 2,837.7 |  |  | $ | 2,503.2 |  |  | $ | 2,217.3 |  |

[0001628280-25-004288:notes:74]
[same as prior period, unchanged from 0001628280-24-046443:notes:70]

[0001628280-25-004288:notes:75]
[same as prior period, unchanged from 0001628280-24-046443:notes:71]

[0001628280-25-004288:notes:76]
Management utilizes various valuation methods, including an income approach, a market approach and a cost approach, to estimate the fair value of intangibles and other long-lived assets. During the annual impairment testing performed in the fourth quarter of fiscal 2024, we concluded that there was no impairment of our intangible and other long-lived assets. We review our intangible and other long-lived assets for impairment at least annually in the fourth quarter of each fiscal year, absent any interim indicators of impairment. There were no indicators of impairment during the three and six months ended December 28, 2024.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001628280-25-004288:notes:77]
[same as prior period, unchanged from 0001628280-24-046443:notes:73]

[0001628280-25-004288:notes:78]
[same as prior period, unchanged from 0001628280-24-046443:notes:74]

[0001628280-25-004288:notes:79]
We did not have any allowance for credit losses other than our allowance for uncollectible accounts receivable. As of December 28, 2024 and June 29, 2024, the allowance for credit losses on our trade receivables was $0.5 million and $0.2 million, respectively.

[0001628280-25-004288:notes:80]
[same as prior period, unchanged from 0001628280-24-046443:notes:76]

[0001628280-25-004288:notes:81]
[same as prior period, unchanged from 0001628280-24-046443:notes:77]

[0001628280-25-004288:notes:82]
|  | December 28, 2024 |  | June 29, 2024 |
| Raw materials and purchased parts | $ | 208.5 |  |  | $ | 196.9 |  |
| Work in process | 121.5 |  |  | 101.6 |  |
| Finished goods | 72.3 |  |  | 99.9 |  |
| Inventories | $ | 402.3 |  |  | $ | 398.4 |  |

[0001628280-25-004288:notes:83]
[same as prior period, unchanged from 0001628280-24-046443:notes:80]

[0001628280-25-004288:notes:84]
[same as prior period, unchanged from 0001628280-24-046443:notes:81]

[0001628280-25-004288:notes:85]
|  | December 28, 2024 |  | June 29, 2024 |
| Land | $ | 108.6 |  |  | $ | 75.2 |  |
| Buildings and improvements | 240.0 |  |  | 215.1 |  |
| Machinery and equipment | 793.3 |  |  | 772.1 |  |
| Computer equipment and software | 44.1 |  |  | 44.9 |  |
| Furniture and fixtures | 14.0 |  |  | 14.3 |  |
| Leasehold improvements | 44.6 |  |  | 47.5 |  |
| Construction in progress | 131.7 |  |  | 71.1 |  |
|  | 1,376.3 |  |  | 1,240.2 |  |
| Less: Accumulated depreciation | (712.9) |  |  | (667.7) |  |
| Property, plant and equipment, net | $ | 663.4 |  |  | $ | 572.5 |  |

[0001628280-25-004288:notes:86]
[same as prior period, unchanged from 0001628280-24-046443:notes:84]

[0001628280-25-004288:notes:87]
On December 17, 2024, the Company entered into an agreement to sell its assets in an entity in Shenzhen, China for 350 million Chinese Yuan Renminbi (or about $48 million). The assets consist primarily of building, building improvements and land rights as of December 17, 2024 with a net carrying value of $14.0 million, and were used by Cloud and Networking segment for manufacturing and research and development activities. As a result, the Company reclassified these assets to “Assets Held for Sale” in accordance with accounting standard ASC 360-10-45-9 and the amount is presented as prepayments and other current assets on the condensed consolidated balance sheets as of December 28, 2024. This reclassification was based on management’s decision to actively market the assets for sale and its expectation that the sale will be completed within one year. The sale is expected to be completed by the end of fiscal 2025, subject to customary approvals and closing conditions.

[0001628280-25-004288:notes:88]
Assets held-for-sale are recorded initially at the lower of its carrying value or its estimated fair value, less estimated costs to sell. No impairment loss was recognized, as the fair value less cost to sell exceeded the carrying value. Upon designation as an asset held-for-sale, we discontinue recording depreciation expense on such assets. During the three months ended December 28, 2024, we incurred about $0.3 million of selling expenses, which is recorded in selling, general and administrative expenses in the condensed consolidated statements of operations.

[0001628280-25-004288:notes:89]
[same as prior period, unchanged from 0001628280-24-046443:notes:85]

[0001628280-25-004288:notes:90]
[same as prior period, unchanged from 0001628280-24-046443:notes:86]

[0001628280-25-004288:notes:91]
During the three and six months ended December 28, 2024, we recorded depreciation expense of $25.9 million and $52.9 million, respectively.

[0001628280-25-004288:notes:92]
[same as prior period, unchanged from 0001628280-24-046443:notes:88]

[0001628280-25-004288:notes:93]
[same as prior period, unchanged from 0001628280-24-046443:notes:89]

[0001628280-25-004288:notes:94]
|  | December 28, 2024 |  | June 29, 2024 |
| Operating lease right-of-use assets | $ | 66.0 |  |  | $ | 112.3 |  |
| Less: accumulated amortization | (33.1) |  |  | (39.5) |  |
| Operating lease right-of-use assets, net | $ | 32.9 |  |  | $ | 72.8 |  |

[0001628280-25-004288:notes:95]
In connection with our integration efforts to consolidate our sites, we recorded restructuring charges for various sites and reduced our operating lease right-of-use assets by $5.5 million during the six months ended December 28, 2024.

[0001628280-25-004288:notes:96]
[same as prior period, unchanged from 0001628280-24-046443:notes:92]

[0001628280-25-004288:notes:97]
[same as prior period, unchanged from 0001628280-24-046443:notes:93]

[0001628280-25-004288:notes:98]
[same as prior period, unchanged from 0001628280-24-046443:notes:94]

[0001628280-25-004288:notes:99]
[same as prior period, unchanged from 0001628280-24-046443:notes:95]

[0001628280-25-004288:notes:100]
[same as prior period, unchanged from 0001628280-24-046443:notes:96]

[0001628280-25-004288:notes:101]
|  | December 28, 2024 |  | June 29, 2024 |
| Restructuring accrual and related charges (1) | $ | 1.5 |  |  | $ | 11.1 |  |
| Warranty reserve (2) | 12.8 |  |  | 13.2 |  |
| Deferred revenue and customer deposits | 0.7 |  |  | 0.6 |  |
| Income tax payable (3) | 33.1 |  |  | 13.2 |  |
| Other current liabilities | 6.8 |  |  | 3.0 |  |
| Other current liabilities | $ | 54.9 |  |  | $ | 41.1 |  |

[0001628280-25-004288:notes:102]
[same as prior period, unchanged from 0001628280-24-046443:notes:98]

[0001628280-25-004288:notes:103]
(2) Refer to “Note 14. Commitments and Contingencies.”

[0001628280-25-004288:notes:104]
[same as prior period, unchanged from 0001628280-24-046443:notes:100]

[0001628280-25-004288:notes:105]
[same as prior period, unchanged from 0001628280-24-046443:notes:101]

[0001628280-25-004288:notes:106]
[same as prior period, unchanged from 0001628280-24-046443:notes:102]

[0001628280-25-004288:notes:107]
|  | December 28, 2024 |  | June 29, 2024 |
| Asset retirement obligations | $ | 7.0 |  |  | $ | 7.5 |  |
| Pension and related accruals (1) | 6.2 |  |  | 7.5 |  |
| Unrecognized tax benefit | 95.5 |  |  | 83.0 |  |
| Other non-current liabilities | 5.5 |  |  | 5.4 |  |
| Other non-current liabilities | $ | 114.2 |  |  | $ | 103.4 |  |

[0001628280-25-004288:notes:108]
(1) We have defined benefit pension plans in Japan, Switzerland, and Thailand. Pension and related accrual of $6.2 million as of December 28, 2024 represents $8.0 million of non-current portion of benefit obligation, offset by $1.8 million  of funding for the pension plan in Switzerland. Pension and related accrual of $7.5 million as of June 29, 2024 relates to $8.6 million of non-current portion of benefit obligation, offset by $1.2 million of funding for the pension plan in Switzerland. We typically re-evaluate the assumptions related to the fair value of our defined benefit obligations annually in the fiscal fourth quarter and make any updates as necessary. During the three and six months ended December 28, 2024, our contribution expense to the 401(k) Plan in the United States was $0.4 million and $1.2 million, respectively. During the three and six months ended December 30, 2023, our contribution expense to the 401(k) Plan in the United States was $0.5 million and $1.4 million, respectively. Our contribution expense to all defined contribution plans outside the United States were $2.0 million and $3.8 million during the three and six months ended December 28, 2024, respectively. Our contribution expense to all defined contribution plans outside the United States were $1.8 million and $3.9 million during the three and six months ended December 30, 2023, respectively.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001628280-25-004288:notes:109]
[same as prior period, unchanged from 0001628280-24-046443:notes:105]

[0001628280-25-004288:notes:110]
[same as prior period, unchanged from 0001628280-24-046443:notes:106]

[0001628280-25-004288:notes:111]
[same as prior period, unchanged from 0001628280-24-046443:notes:107]

[0001628280-25-004288:notes:112]
The following table presents goodwill by reportable segments as of December 28, 2024 and June 29, 2024 (in millions):

[0001628280-25-004288:notes:113]
|  | Cloud & Networking |  | Industrial Tech |  | Total |
| Balances as of June 29, 2024 | $ | 1,044.6 |  |  | $ | 11.2 |  |  | $ | 1,055.8 |  |
| Acquisition of Cloud Light (1) | 5.1 |  |  | — |  |  | 5.1 |  |
| Balances as of December 28, 2024 | $ | 1,049.7 |  |  | $ | 11.2 |  |  | $ | 1,060.9 |  |

[0001628280-25-004288:notes:114]
(1) During the six months ended December 28, 2024, we adjusted the purchase price allocation and recorded a $5.1 million increase to goodwill. The primary adjustment to the opening balance sheet relates to income tax liabilities which were not known in previous periods.

[0001628280-25-004288:notes:115]
[same as prior period, unchanged from 0001628280-24-046443:notes:111]

[0001628280-25-004288:notes:116]
We review goodwill for impairment during the fourth quarter of each fiscal year or more frequently if events or circumstances indicate that an impairment loss may have occurred. In the fourth quarter of fiscal 2024, we completed the annual impairment test of goodwill, which indicated there was no goodwill impairment. There were no indicators of goodwill impairment during the three and six months ended December 28, 2024.

[0001628280-25-004288:notes:117]
[same as prior period, unchanged from 0001628280-24-046443:notes:113]

[0001628280-25-004288:notes:118]
[same as prior period, unchanged from 0001628280-24-046443:notes:114]

[0001628280-25-004288:notes:119]
[same as prior period, unchanged from 0001628280-24-046443:notes:115]

[0001628280-25-004288:notes:120]
During the annual impairment testing performed in the fourth quarter of fiscal 2024, we concluded that our intangible and other long-lived assets were not impaired at the asset group level. We review our intangible and other long-lived assets for impairment at least annually in the fourth quarter of each fiscal year, absent any interim indicators of impairment. There were no indicators of impairment at the asset group level during the three and six months ended December 28, 2024.

[0001628280-25-004288:notes:121]
[same as prior period, unchanged from 0001628280-24-046443:notes:117]

[0001628280-25-004288:notes:122]
[same as prior period, unchanged from 0001628280-24-046443:notes:118]

[0001628280-25-004288:notes:123]
[same as prior period, unchanged from 0001628280-24-046443:notes:119]

[0001628280-25-004288:notes:124]
[same as prior period, unchanged from 0001628280-24-046443:notes:120]

[0001628280-25-004288:notes:125]
| December 28, 2024 | Gross Carrying Amounts |  | Accumulated Amortization |  | Net Carrying Amounts |  | Weighted Average Remaining Amortization Period (Years) |
| Acquired developed technologies | $ | 818.1 |  |  | $ | (518.8) |  |  | $ | 299.3 |  |  | 4.5 |
| Customer relationships | 419.8 |  |  | (198.0) |  |  | 221.8 |  |  | 4.5 |
| In-process research and development | 13.6 |  |  | — |  |  | 13.6 |  |  | n/a |
| Order backlog | 14.0 |  |  | (14.0) |  |  | — |  |  | — |
| Trade name and trademarks | 3.0 |  |  | (2.8) |  |  | 0.2 |  |  | 0.1 |
| Total intangible assets | $ | 1,268.5 |  |  | $ | (733.6) |  |  | $ | 534.9 |  |  |  |

[0001628280-25-004288:notes:126]
[same as prior period, unchanged from 0001628280-24-046443:notes:122]

[0001628280-25-004288:notes:127]
[same as prior period, unchanged from 0001628280-24-046443:notes:123]

[0001628280-25-004288:notes:128]
|  | Three Months Ended |  | Six Months Ended |
|  | December 28, 2024 |  | December 30, 2023 |  | December 28, 2024 |  | December 30, 2023 |
| Cost of sales | $ | 21.4 |  |  | $ | 21.5 |  |  | $ | 43.9 |  |  | $ | 39.5 |  |
| Research and development | 0.4 |  |  | 0.4 |  |  | 0.8 |  |  | 0.7 |  |
| Selling, general and administrative | 17.2 |  |  | 15.7 |  |  | 36.0 |  |  | 26.4 |  |
| Total amortization of intangibles | $ | 39.0 |  |  | $ | 37.6 |  |  | $ | 80.7 |  |  | $ | 66.6 |  |

[0001628280-25-004288:notes:129]
Based on the carrying amount of our acquired intangible assets except in-process research and development as of December 28, 2024, and assuming no future impairment of the underlying assets, the estimated future amortization is as follows (in millions):

[0001628280-25-004288:notes:130]
| Fiscal Years |  |
| Remainder of 2025 | $ | 68.6 |  |
| 2026 | 133.3 |  |
| 2027 | 121.0 |  |
| 2028 | 81.5 |  |
| 2029 | 51.8 |  |
| Thereafter | 65.1 |  |
| Total future amortization | $ | 521.3 |  |


## us-gaap:ScheduleOfFiniteLivedIntangibleAssetsTableTextBlock

[0001628280-25-004288:notes:131]
[same as prior period, unchanged from 0001628280-24-046443:notes:127]


## us-gaap:DebtDisclosureTextBlock

[0001628280-25-004288:notes:132]
Note 9. Debt

[0001628280-25-004288:notes:133]
Convertible Notes

[0001628280-25-004288:notes:134]
2029 Notes

[0001628280-25-004288:notes:135]
On June 16, 2023, we issued $603.7 million in aggregate principal amount of 1.50% Convertible Senior Notes due in 2029 (“2029 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act of 1933, as amended. The 2029 Notes are governed by an indenture between the Company and U.S. Bank Trust Company, National Association, (as successor in interest to U.S. Bank National Association), as a trustee (the “2029 Indenture”). The 2029 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001628280-25-004288:notes:136]
The net proceeds from the sale of the 2029 Notes was $599.4 million, after deducting $4.3 million of net issuance costs. In addition, we incurred $0.8 million of professional fees directly related to this transaction. Concurrent with the issuance of the 2029 Notes, we used $132.8 million of the net proceeds to repurchase $125.0 million aggregate principal amount of the 0.25% convertible senior notes due in 2024 and $125.0 million of the net proceeds to repurchase our common stock in privately negotiated transactions. We intend to use the remaining net proceeds for general corporate purposes, which may include the repayment of our indebtedness, including any of our existing convertible notes, capital expenditures, working capital and potential acquisitions.

[0001628280-25-004288:notes:137]
The 2029 Notes bear interest at a rate of 1.50% per year, payable semi-annually in arrears on June 15 and December 15 of each year. The 2029 Notes will mature on December 15, 2029, unless earlier redeemed, repurchased by us, or converted pursuant to their terms.

[0001628280-25-004288:notes:138]
The initial conversion rate is 14.3808 shares of common stock per $1,000 principal amount of the 2029 Notes (which is equivalent to an initial conversion price of approximately $69.54 per share). The conversion rate is subject to adjustment upon the occurrence of certain events specified in the 2029 Indenture but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert the 2029 Notes in connection with such make-whole fundamental change or notice of redemption.

[0001628280-25-004288:notes:139]
Prior to the close of business on the business day immediately preceding September 15, 2029, holders of the 2029 Notes may convert their 2029 Notes only under the following circumstances:

[0001628280-25-004288:notes:140]
•during any fiscal quarter commencing after September 30, 2023 (and only during such fiscal quarter), if the last reported sale price of the common stock for at least 20 trading days (whether or not consecutive) during the period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price of the 2029 Notes, or $90.40, on each applicable trading day;

[0001628280-25-004288:notes:141]
•during the five consecutive business day period after any five consecutive trading day period (the “2029 measurement period”) in which the trading price per $1,000 principal amount of 2029 Notes for each trading day of the 2029 measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate on each such trading day;

[0001628280-25-004288:notes:142]
•if we call any or all of the 2029 Notes for redemption, at any time prior to the close of business on the second business day immediately preceding the redemption date; or

[0001628280-25-004288:notes:143]
•upon the occurrence of specified corporate events as specified in the 2029 Indenture.

[0001628280-25-004288:notes:144]
On or after September 15, 2029 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their 2029 Notes at any time. Following our irrevocable settlement method election made on September 25, 2024, upon conversion, we are required to satisfy our conversion obligation with respect to such converted 2029 Notes by delivering cash equal to the principal amount of such converted 2029 Notes and cash, shares of common stock or a combination of cash and shares of common stock, at our election, with respect to any conversion value in excess thereof.

[0001628280-25-004288:notes:145]
We may redeem for cash all or any portion of the 2029 Notes, at our option (subject to the partial redemption limitation set forth in the 2029 Indenture), on or after June 22, 2026, if the last reported sale price of our  common stock has been at least 130% of the conversion price then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading-day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which we provide notice of redemption at a redemption price equal to 100% of the principal amount of the 2029 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. No sinking fund is provided for the 2029 Notes. If we elect to redeem fewer than all of the outstanding 2029 Notes, at least $100.0 million aggregate principal amount of the 2029 Notes must be outstanding and not subject to redemption as of the redemption notice date. Upon the occurrence of a fundamental change (as defined in the 2029 Indenture), holders may require us to repurchase all or a portion of their 2029 Notes for cash at a price equal to 100% of the principal amount of the 2029 Notes to be repurchased, plus any accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

[0001628280-25-004288:notes:146]
The entire 2029 Notes are recorded as convertible notes, non-current in our consolidated balance sheets as of December 28, 2024 and June 29, 2024, measured at amortized cost.

[0001628280-25-004288:notes:147]
2028 Notes

[0001628280-25-004288:notes:148]
In March 2022, we issued $861.0 million in aggregate principal amount of 0.50% Convertible Senior Notes due in 2028 (the “2028 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act of 1933, as amended (the “Securities Act”). The 2028 Notes are governed by an indenture between the Company and U.S. Bank Trust Company, National Association (as successor in interest to U.S. Bank National Association), as trustee (the “2028 Indenture”). The 2028 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001628280-25-004288:notes:149]
The net proceeds from the sale of the 2028 Notes was $854.8 million, after deducting $6.2 million in issuance costs. In addition, we incurred $0.7 million in professional fees in connection with this transaction. Concurrent with the issuance of the 2028 Notes, we used $200.0 million of the net proceeds to repurchase our common stock in privately negotiated transactions.

[0001628280-25-004288:notes:150]
The 2028 Notes bear interest at a rate of 0.50% per year, payable semi-annually in arrears on June 15 and December 15 of each year. The 2028 Notes will mature on June 15, 2028, unless earlier redeemed, repurchased by us, or converted pursuant to their terms.

[0001628280-25-004288:notes:151]
The initial conversion rate is 7.6319 shares of common stock per $1,000 principal amount of the 2028 Notes (which is equivalent to an initial conversion price of approximately $131.03 per share). The conversion rate is subject to adjustment upon the occurrence of certain specified events, but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change (as defined in the 2028 Indenture) or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elects to convert the 2028 Notes in connection with such make-whole fundamental change or notice of redemption.

[0001628280-25-004288:notes:152]
Prior to the close of business on the business day immediately preceding March 15, 2028, holders of the 2028 Notes may convert their 2028 Notes only under the following circumstances:

[0001628280-25-004288:notes:153]
•during any fiscal quarter (and only during such fiscal quarter), if the last reported sale price of the Company’s common stock for at least 20 trading days (whether or not consecutive) during the 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price, or $170.34, on each applicable trading day;

[0001628280-25-004288:notes:154]
•during the five consecutive business day period after any five consecutive trading day period (the “measurement period”) in which the trading price per $1,000 principal amount of the 2028 Notes for each trading day of such measurement period was less than 98% of the product of the last reported sale price of the Company’s common stock and the applicable conversion rate on each such trading day;

[0001628280-25-004288:notes:155]
•if the Company calls any or all of the 2028 Notes for redemption, at any time prior to the close of business on the second business day immediately preceding the redemption date; or

[0001628280-25-004288:notes:156]
•upon the occurrence of specified corporate events, as specified in the 2028 Indenture.

[0001628280-25-004288:notes:157]
On or after March 15, 2028 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their 2028 Notes at any time. Following our irrevocable settlement method election made on September 25, 2024, upon conversion, we are required to satisfy our conversion obligation with respect to such converted 2028 Notes by delivering cash equal to the principal amount of such converted 2028 Notes and cash, shares of common stock or a combination of cash and shares of common stock, at our election, with respect to any conversion value in excess thereof.

[0001628280-25-004288:notes:158]
We may redeem for cash all or any portion of the 2028 Notes, at our option (subject to the partial redemption limitation set forth in the 2028 Indenture), on or after June 20, 2025, if the last reported sale price of its common stock has been at least 130% of the conversion price then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading-day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which the Company provides notice of redemption at a redemption price equal to 100% of the principal amount of the 2028 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. No sinking fund is provided for the 2028 Notes. If we elect to redeem fewer than all of the outstanding 2028 Notes, at least $100.0 million aggregate principal amount of the 2028 Notes must be outstanding and not subject to redemption as of the redemption notice date. Upon the occurrence of a fundamental change (as defined in the 2028 Indenture), holders may require the Company to repurchase all or a portion of their 2028 Notes for cash at a price equal to 100% of the principal amount of the 2028 Notes to be repurchased, plus any accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

[0001628280-25-004288:notes:159]
We initially bifurcated the principal amount of the 2028 Notes into liability and equity components. The liability component of the 2028 Notes was initially valued at $629.8 million based on the contractual cash flow discounted at an appropriate comparable market on non-convertible debt borrowing rate at the date of issuance, which was 5.7%, with the equity component representing the residual amount of the proceeds of $231.2 million, which was recorded as a debt discount. Upon adoption of ASU 2020-06 in the first quarter of fiscal 2023, our 2028 Notes were accounted for as a single liability measured at amortized cost. The entire 2028 Notes are recorded as convertible notes, non-current in our consolidated balance sheets as of December 28, 2024 and June 29, 2024, measured at amortized cost.

[0001628280-25-004288:notes:160]
2026 Notes

[0001628280-25-004288:notes:161]
In December 2019, we issued $1,050.0 million in aggregate principal amount of 0.50% Convertible Senior Notes due in 2026 (the “2026 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act. The 2026 Notes are governed by an indenture between the Company and U.S. Bank Trust Company, National Association as successor in interest to U.S. Bank National Association, as trustee (as supplemented by the First Supplemental Indenture, dated as of September 25, 2024, the “2026 Indenture”). We used approximately $196.0 million of the net proceeds of the offering to repay in full all amounts outstanding under our term loan credit facility, and a portion of the net proceeds of the offering to purchase approximately $200.0 million of our common stock concurrently with the pricing of the offering in privately

[0001628280-25-004288:notes:162]
negotiated transactions. The 2026 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001628280-25-004288:notes:163]
The 2026 Notes bear interest at a rate of 0.50% per year, payable semi-annually in arrears on June 15 and December 15 of each year. The 2026 Notes will mature on December 15, 2026, unless earlier redeemed, repurchased by us, or converted pursuant to their terms.

[0001628280-25-004288:notes:164]
The initial conversion rate is 10.0711 shares of common stock per $1,000 principal amount of the 2026 Notes (which is equivalent to an initial conversion price of approximately $99.29 per share). The conversion rate is subject to adjustment upon the occurrence of certain events specified in the 2026 Indenture but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change (as defined in the 2026 Indenture) or our issuance of a notice of redemption, we will, in certain circumstances, increase the conversion rate by a number of additional shares set forth in the 2026 Indenture or a holder that elects to convert the 2026 Notes in connection with such make-whole fundamental change or notice of redemption.

[0001628280-25-004288:notes:165]
Prior to the close of business on the business day immediately preceding September 15, 2026, holders of the 2026 Notes may convert their 2026 Notes only under the following circumstances:

[0001628280-25-004288:notes:166]
•during any fiscal quarter (and only during such fiscal quarter), if the last reported sale price of the common stock for at least 20 trading days (whether or not consecutive) during a period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the conversion price of the 2026 Notes, or $129.08 on each applicable trading day;

[0001628280-25-004288:notes:167]
•during the five consecutive business day period after any five consecutive trading day period (the “2026 measurement period”) in which the trading price per $1,000 principal amount of the 2026 Notes for each trading day of the 2026 measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate for the 2026 Notes on each such trading day;

[0001628280-25-004288:notes:168]
•if we call any or all of the 2026 Notes for redemption, at any time prior to the close of business on the second business day immediately preceding the relevant redemption date; or

[0001628280-25-004288:notes:169]
•upon the occurrence of specified corporate events.

[0001628280-25-004288:notes:170]
On or after September 15, 2026 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders may convert their 2026 Notes at any time. Following our entry into the First Supplemental Indenture, dated as of September 25, 2024, to the 2026 Indenture, upon conversion, we are required to satisfy our conversion obligation with respect to such converted 2026 Notes by delivering cash equal to the principal amount of such converted 2026 Notes and cash, shares of common stock or a combination of cash and shares of common stock, at our election, with respect to any conversion value in excess thereof.

[0001628280-25-004288:notes:171]
We may redeem for cash, all or any portion of the 2026 Notes, at our option, on or after December 20, 2023, if the last reported sale price of its common stock has been at least 130% of the conversion price then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading-day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which we provide a notice of redemption at a redemption price equal to 100% of the principal amount of the 2026 Notes to be redeemed, plus accrued and unpaid interest to, but excluding, the redemption date. No sinking fund is provided for the 2026 Notes. Upon the occurrence of a fundamental change (as defined in the 2026 Indenture), holders may require us to repurchase all or a portion of the 2026 Notes for cash at a price equal to 100% of the principal amount of the 2026 Notes to be repurchased, plus any accrued and unpaid interest to, but excluding, the fundamental change repurchase date.

[0001628280-25-004288:notes:172]
We initially bifurcated the principal amount of the 2026 Notes into liability and equity components. The liability component of the 2026 Notes was initially valued at $734.8 million based on the contractual cash flows discounted at an appropriate comparable market non-convertible debt borrowing rate at the date of issuance of 5.8% with the equity component representing the residual amount of the proceeds of $315.2 million, which was recorded as a debt discount. Upon adoption of ASU 2020-06 in the first quarter of fiscal 2023, our 2026 Notes were accounted for as a single liability measured at amortized cost. The entire 2026 Notes are recorded as convertible notes, non-current in our consolidated balance sheets as of December 28, 2024 and June 29, 2024, measured at amortized cost.

[0001628280-25-004288:notes:173]
2024 Notes

[0001628280-25-004288:notes:174]
In March 2017, we issued $450.0 million in aggregate principal amount of 0.25% convertible senior notes due in 2024 (the “2024 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act. The 2024 Notes were governed by an indenture between the Company, as the issuer, and U.S. Bank Trust Company National Association (as successor in interest to U.S. Bank National Association), as trustee (the “2024 Indenture”). The 2024 Notes were unsecured and did not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

[0001628280-25-004288:notes:175]
The 2024 Notes bore interest at a rate of 0.25% per year. Interest on the 2024 Notes was payable semi-annually in arrears on March 15 and September 15 of each year. The 2024 Notes matured on March 15, 2024.

[0001628280-25-004288:notes:176]
The initial conversion rate of the 2024 Notes was 16.4965 shares of common stock per $1,000 principal amount of 2024 Notes, which was equivalent to an initial conversion price of approximately $60.62 per share. The conversion rate was subject to adjustment upon the occurrence of certain specified events but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change (as defined in the 2024 Indenture) or our issuance of a notice of redemption, we were required to, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elected to convert the 2024 Notes in connection with such make-whole fundamental change or notice of redemption.

[0001628280-25-004288:notes:177]
Prior to the close of business on the business day immediately preceding December 15, 2023, each holder of the 2024 Notes was able to convert their 2024 Notes only under the following circumstances:

[0001628280-25-004288:notes:178]
•during any fiscal quarter (and only during such fiscal quarter), if the last reported sale price of our common stock for at least 20 trading days (whether or not consecutive) during the period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter was greater than or equal to 130% of the applicable conversion price, or $78.80 on each applicable trading day;

[0001628280-25-004288:notes:179]
•during the five consecutive business day period after any five consecutive trading day period (the “2024 measurement period”) in which the trading price per $1,000 principal amount of 2024 Notes for each trading day of such 2024 measurement period was less than 98% of the product of the last reported sale price of our common stock and the applicable conversion rate for the 2024 Notes on each such trading day; or

[0001628280-25-004288:notes:180]
On or after December 15, 2023 until the close of business on the second scheduled trading day immediately preceding the maturity date, holders could convert their 2024 Notes at any time. In addition, upon the occurrence of a make-whole fundamental change (as defined in the 2024 Indenture), we were required to, in certain circumstances, increase the conversion rate by a number of additional shares set forth in the 2024 Indenture for a holder that elected to convert 2024 Notes in connection with such make-whole fundamental change.

[0001628280-25-004288:notes:181]
We could not redeem the 2024 Notes prior to their maturity date and no sinking fund was provided for the 2024 Notes. Upon the occurrence of a fundamental change (as defined in the 2024 Indenture), holders could require us to repurchase all or a portion of their 2024 Notes for cash at a price equal to 100% of the principal amount of the 2024 Notes to be repurchased, plus any accrued and unpaid interest.

[0001628280-25-004288:notes:182]
We considered the features embedded in the 2024 Notes other than the conversion feature, including the holders’ put feature, our call feature, and the make-whole feature, and concluded that they are not required to be bifurcated and accounted for separately from the host debt instrument.

[0001628280-25-004288:notes:183]
Prior to the Tax Matters Agreement settlement condition (“TMA settlement condition”), because we could only settle the 2024 Notes in cash, we determined that the conversion feature met the definition of a derivative liability. We separated the derivative liability from the host debt instrument based on the fair value of the derivative liability. As of the issuance date, March 8, 2017, the derivative liability fair value of $129.9 million was calculated using the binomial valuation approach. The residual principal amount of the 2024 Notes of $320.1 million before issuance costs was allocated to the debt component. We incurred approximately $7.7 million in transaction costs in connection with the issuance of the 2024 Notes. These costs were allocated to the debt component and recognized as a debt discount. We amortized the debt discount, including both the initial value of the derivative liability and the transaction costs, over the term of the 2024 Notes using the effective interest method. The effective interest rate of the 2024 Notes was 5.4% per year.

[0001628280-25-004288:notes:184]
During fiscal 2017, we satisfied the TMA settlement condition. As such, the value of the conversion option was no longer marked-to-market and was reclassified to additional paid-in capital within stockholders’ equity on our condensed consolidated balance sheets. The value of the conversion option at the time of issuance was treated as an original issue discount for purposes of accounting for the debt component of the 2024 Notes. The debt component accreted up to the original amount over the term of the debt. The adoption of ASU 2020-06 did not change the presentation of the 2024 Notes, as the conversion feature associated with the 2024 Notes was classified within stockholders’ equity.

[0001628280-25-004288:notes:185]
Concurrent with the issuance of the 2029 Notes in June 2023, we used $132.8 million of the net proceeds to repurchase $125.0 million aggregate principal amount of the 2024 Notes, which we accounted for as an extinguishment of liability. $13.5 million of the $132.8 million repurchase price was allocated to the conversion feature of the repurchased 2024 Notes, representing the fair value of the conversion feature at the date of the repurchase, and was recognized as a reduction of the stockholders’ equity. Additionally, since issuing the 2024 Notes, we converted a total of approximately $1.9 million of principal amount of the 2024 Notes, with less than $0.1 million of principle amount converted during the three and six months ended December 28, 2024.

[0001628280-25-004288:notes:186]
On March 15, 2024, the 2024 Notes maturity date, we fully repaid the remaining principal amount of $323.1 million. The conversion feature previously classified within stockholder’s equity was fully amortized as of the maturity date.

[0001628280-25-004288:notes:187]
Convertible Notes - Additional Disclosures

[0001628280-25-004288:notes:188]
On September 25, 2024, Lumentum entered into the First Supplemental Indenture to the 2029 Indenture, 2028 Indenture and 2026 Indenture, pursuant to which we irrevocably elected to settle the principal amounts of the 2029 Notes, 2028 Notes and 2026 Notes in cash. Any amounts due above the principal may be settled in cash, equity, or any combination thereof at the election of the Company.

[0001628280-25-004288:notes:189]
Our convertible notes consisted of the following components as of the periods presented (in millions):

[0001628280-25-004288:notes:190]
| December 28, 2024 |  |  | 2026 Notes (1) |  | 2028 Notes (2) |  | 2029 Notes (3) |  | Total |  |  |  |  |  |
| Principal |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |  | $ | 603.7 |  |  | $ | 2,514.7 |  |  |  |  |  |  |
| Unamortized debt discount and debt issuance costs |  |  | (2.3) |  |  | (3.9) |  |  | (3.8) |  |  | (10.0) |  |  |  |  |  |  |
| Net carrying amount of the liability component |  |  | $ | 1,047.7 |  |  | $ | 857.1 |  |  | $ | 599.9 |  |  | $ | 2,504.7 |  |  |  |  |  |  |

[0001628280-25-004288:notes:191]
| June 29, 2024 |  |  | 2026 Notes (1) |  | 2028 Notes (2) |  | 2029 Notes (3) |  | Total |
| Principal |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |  | $ | 603.7 |  |  | $ | 2,514.7 |  |
| Unamortized debt discount and debt issuance costs |  |  | (2.8) |  |  | (4.4) |  |  | (4.3) |  |  | (11.5) |  |
| Net carrying amount of the liability component |  |  | $ | 1,047.2 |  |  | $ | 856.6 |  |  | $ | 599.4 |  |  | $ | 2,503.2 |  |

[0001628280-25-004288:notes:192]
(1) If the closing price of our stock exceeds $129.08 (or 130% of the conversion price of $99.29) for 20 of the last 30 trading days of any future fiscal quarter, our 2026 Notes would become convertible at the option of the holders during the subsequent fiscal quarter and the debt would be reclassified to current liabilities in our condensed consolidated balance sheet.

[0001628280-25-004288:notes:193]
(2) If the closing price of our stock exceeds $170.34 (or 130% of the conversion price of $131.03) for 20 of the last 30 trading days of any future fiscal quarter, our 2028 Notes would become convertible at the option of the holders during the subsequent fiscal quarter and the debt would be reclassified to current liabilities in our condensed consolidated balance sheet.

[0001628280-25-004288:notes:194]
(3) If the closing price of our stock exceeds $90.40 (or 130% of the conversion price of $69.54) for 20 of the last 30 trading days of any future quarter, our 2029 Notes would become convertible at the option of the holders during the subsequent fiscal quarter and the debt would be reclassified to current liabilities in our consolidated balance sheets.

[0001628280-25-004288:notes:195]
The following table sets forth interest expense information related to the convertible notes for the periods presented (in millions):

[0001628280-25-004288:notes:196]
|  | Three Months Ended |  | Six Months Ended |
|  | December 28, 2024 |  | December 30, 2023 |  | December 28, 2024 |  | December 30, 2023 |
| Contractual interest expense | $ | 4.6 |  |  | $ | 4.9 |  |  | $ | 9.3 |  |  | $ | 9.7 |  |
| Amortization of the debt discount and debt issuance costs | 0.8 |  |  | 4.8 |  |  | 1.5 |  |  | 9.7 |  |
| Total interest expense | $ | 5.4 |  |  | $ | 9.7 |  |  | $ | 10.8 |  |  | $ | 19.4 |  |

[0001628280-25-004288:notes:197]
The future interest and principal payments related to our convertible notes are as follows as of December 28, 2024 (in millions):

[0001628280-25-004288:notes:198]
| Fiscal Years |  |  | 2026 Notes |  | 2028 Notes |  | 2029 Notes |  | Total |
| 2025 |  |  | $ | 2.7 |  |  | $ | 2.2 |  |  | $ | 4.6 |  |  | $ | 9.5 |  |
| 2026 |  |  | 5.3 |  |  | 4.3 |  |  | 9.1 |  |  | 18.7 |  |
| 2027 |  |  | 1,052.5 |  |  | 4.3 |  |  | 9.1 |  |  | 1,065.9 |  |
| 2028 |  |  | — |  |  | 865.3 |  |  | 9.1 |  |  | 874.4 |  |
| 2029 |  |  | — |  |  | — |  |  | 617.1 |  |  | 617.1 |  |
| Total payments |  |  | $ | 1,060.5 |  |  | $ | 876.1 |  |  | $ | 649.0 |  |  | $ | 2,585.6 |  |

[0001628280-25-004288:notes:199]
The principal balances of our convertible notes are reflected in the payment periods in the table above based on their respective contractual maturities.

[0001628280-25-004288:notes:200]
Term Loans

[0001628280-25-004288:notes:201]
SMBC Term Loan

[0001628280-25-004288:notes:202]
On August 9, 2024, the Company entered into a term loan agreement with Sumitomo Mitsui Banking Corporation (“SMBC”). The SMBC term loan provides an aggregate principal amount of 6.4 billion Japanese yen (“JPY”). The loan requires monthly payments of the principal amounting to approximately 53.3 million JPY, which commenced on August 31, 2024 totaling approximately 3.1 billion JPY and interest based on a fixed annual interest rate of 0.88%, with the remaining principal of approximately 3.3 billion JPY due on the loan maturity date of July 31, 2029. Under the loan agreement, the Company cannot prepay the outstanding loan without SMBC’s approval.  In the event the Company prepays the outstanding loan with SMBC’s approval, the Company shall pay SMBC settlement money pursuant to the loan agreement. The term loan is secured by the real estate owned in Sagamihara, Japan.

[0001628280-25-004288:notes:203]
As of December 28, 2024, the Company has $39.2 million in principal amount outstanding, of which the short-term portion of $4.1 million is recorded as current liabilities while the long-term portion of $35.1 million is recorded as long-term debt in the Company’s condensed consolidated balance sheets.

[0001628280-25-004288:notes:204]
Mizuho Term Loan

[0001628280-25-004288:notes:205]
On September 20, 2024, the Company entered into a loan agreement with Mizuho Bank, Ltd. (the “Mizuho Term Loan”), in order to finance our planned manufacturing expansions. The Mizuho Term Loan provides for borrowings of 4.5 billion JPY with a 5-year term from the funding date September 20, 2024. The loan requires quarterly principal payments of approximately 225.0 million JPY commencing on December 20, 2024 with the final payment on September 20, 2029. The Mizuho Term Loan bears a fixed annual interest rate of 0.90%. The term loan is secured by the real estate assets owned by NeoPhotonics Semiconductor GK. The Mizuho Term Loan agreement requires that the Company and certain domestic subsidiaries comply with covenants relating to customary matters, including obtaining prior approval from lender in case of transferring, creating a security interest, or disposing the collateral assets; obtaining prior approval from lender in case of business transfer, business acquisition, corporate reorganization or changes as mergers, company splits, share exchanges or share transfers or capital structure changes; obtaining prior approval of the lender in case Lumentum Holdings Inc. changes its indirect ownership in Lumentum Japan, Inc; and obtaining prior approval from the lender in case Lumentum Japan, Inc. distributes dividends to its shareholders.

[0001628280-25-004288:notes:206]
As of December 28, 2024, the Company has $27.1 million in principal amount outstanding, of which the short-term portion of $5.7 million is recorded as current liabilities while the long-term portion of $21.4 million is recorded as long-term debt in the Company’s condensed consolidated balance sheets.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001628280-25-004288:notes:207]
[same as prior period, unchanged from 0001628280-24-046443:notes:205]

[0001628280-25-004288:notes:208]
Our accumulated other comprehensive income (loss), net of tax, consists of the accumulated net unrealized gains or losses on foreign currency translation adjustments, defined benefit obligations and available-for-sale securities.

[0001628280-25-004288:notes:209]
[same as prior period, unchanged from 0001628280-24-046443:notes:207]

[0001628280-25-004288:notes:210]
|  | Foreign Currency Translation Adjustments, Net of Tax (1) |  | Defined Benefit Obligations, Net of Tax (2) |  | Unrealized Gain (Loss) on Available-for-Sale Securities, Net of Tax (3) |  |  |  | Total |
| Beginning balance as of June 29, 2024 | $ | 9.8 |  |  | $ | 0.7 |  |  | $ | (1.2) |  |  |  |  | $ | 9.3 |  |
| Other comprehensive gain, net | — |  |  | — |  |  | 2.3 |  |  |  |  | 2.3 |  |
| Ending balance as of September 28, 2024 | $ | 9.8 |  |  | $ | 0.7 |  |  | $ | 1.1 |  |  |  |  | $ | 11.6 |  |
| Other comprehensive loss, net | (0.3) |  |  | — |  |  | (1.1) |  |  |  |  | (1.4) |  |
| Ending balance as of December 28, 2024 | $ | 9.5 |  |  | $ | 0.7 |  |  | $ | — |  |  |  |  | $ | 10.2 |  |
|  | Foreign Currency Translation Adjustments, Net of Tax (1) |  | Defined Benefit Obligations, Net of Tax (2) |  | Unrealized Gain (Loss) on Available-for-Sale Securities, Net of Tax (3) |  |  |  | Total |
| Beginning balance as of July 1, 2023 | $ | 10.4 |  |  | $ | (0.4) |  |  | $ | (5.9) |  |  |  |  | $ | 4.1 |  |
| Other comprehensive gain (loss), net | (0.2) |  |  | — |  |  | 1.3 |  |  |  |  | 1.1 |  |
| Ending balance as of September 30, 2023 | $ | 10.2 |  |  | $ | (0.4) |  |  | $ | (4.6) |  |  |  |  | $ | 5.2 |  |
| Other comprehensive gain, net | 0.2 |  |  | — |  |  | 3.8 |  |  |  |  | 4.0 |  |
| Ending balance as of December 30, 2023 | $ | 10.4 |  |  | $ | (0.4) |  |  | $ | (0.8) |  |  |  |  | $ | 9.2 |  |

[0001628280-25-004288:notes:211]
[same as prior period, unchanged from 0001628280-24-046443:notes:209]

[0001628280-25-004288:notes:212]
[same as prior period, unchanged from 0001628280-24-046443:notes:210]

[0001628280-25-004288:notes:213]
(3) For the three and six months ended December 28, 2024, our unrealized loss on available-for-sale securities is presented net of tax of nil for both periods.

[0001628280-25-004288:notes:214]
For the three and six months ended December 30, 2023, our unrealized loss on available-for-sale securities is presented net of tax of  $1.0 million and $1.4 million, respectively.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001628280-25-004288:notes:215]
[same as prior period, unchanged from 0001628280-24-046443:notes:213]

[0001628280-25-004288:notes:216]
[same as prior period, unchanged from 0001628280-24-046443:notes:214]

[0001628280-25-004288:notes:217]
[same as prior period, unchanged from 0001628280-24-046443:notes:215]

[0001628280-25-004288:notes:218]
|  | Three Months Ended |  | Six Months Ended |
|  | December 28, 2024 |  | December 30, 2023 |  | December 28, 2024 |  | December 30, 2023 |
| Balance as of beginning of period | $ | 6.3 |  |  | $ | 9.3 |  |  | $ | 11.1 |  |  | $ | 5.0 |  |
| Charges | 0.7 |  |  | 5.8 |  |  | 10.4 |  |  | 16.8 |  |
| Payments and other adjustments | (5.5) |  |  | (4.9) |  |  | (20.0) |  |  | (11.6) |  |
| Balance as of end of period | $ | 1.5 |  |  | $ | 10.2 |  |  | $ | 1.5 |  |  | $ | 10.2 |  |

[0001628280-25-004288:notes:219]
During the three and six months ended December 28, 2024, we recorded restructuring and related charges of $0.7 million and $10.4 million, respectively mainly due to our integration efforts and cost reduction initiatives. Restructuring charges for the six months ended December 28, 2024 includes $6.2 million of asset write-offs primarily due to integration efforts to consolidate our sites, $3.0 million of charges related to the discontinuation of our in-house development of coherent Digital Signal Processors (“DSPs”) and Radio Frequency Integrated Circuits (“RFICs”) and the remaining restructuring charges due to company-wide cost reduction initiatives.

[0001628280-25-004288:notes:220]
During the three and six months ended December 30, 2023, we recorded restructuring and related charges of $5.8 million and $16.8 million, respectively, primarily due to company-wide cost reduction initiatives, as well as our integration efforts as a result of the NeoPhotonics acquisition in August 2022.

[0001628280-25-004288:notes:221]
[same as prior period, unchanged from 0001628280-24-046443:notes:220]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-25-004288:notes:222]
[same as prior period, unchanged from 0001628280-24-046443:notes:221]

[0001628280-25-004288:notes:223]
Our tax provision for interim periods has generally been determined using an estimate of our annual effective tax rate, adjusted for discrete items, if any, that arise during the period.  However, when a reliable estimate cannot be made, the actual tax or benefit applicable may be reported as a discrete item in the interim period. For the three and six months ended December 28, 2024, we concluded that the use of the discrete method was more appropriate than the annual effective tax rate method, because the estimated annual effective tax rate is not reliable due to its sensitivity to minimal changes in forecasted annual pre-tax earnings.  As a result, we have computed our tax provision using the discrete method as though the six-month period was the annual period.

[0001628280-25-004288:notes:224]
We recorded a tax provision of $18.6 million and $21.8 million for the three and six months ended December 28, 2024, respectively. Our tax provision for the three months ended December 28, 2024 is primarily attributable to the income tax expense from pre-tax earnings, interest on uncertain tax positions and withholding taxes, partially offset by the tax benefit from prior year changes in uncertain tax positions. Our tax provision for the six months ended December 28, 2024 is primarily attributable to the income tax expense from pre-tax earnings, interest on uncertain tax positions, foreign return to provision differences and withholding taxes, partially offset by the tax benefit from prior year changes in uncertain tax positions.

[0001628280-25-004288:notes:225]
We recorded a tax benefit of $2.4 million and $3.8 million for the three and six months ended December 30, 2023, respectively. Our tax benefit for the three months ended December 30, 2023 includes a discrete tax expense of $3.4 million, primarily related to a shortfall in connection with stock-based compensation vested during the quarter, interest on uncertain tax positions and currency re-measurements. Our tax benefit for the six months ended December 30, 2023 includes a discrete tax expense of $1.6 million, primarily related to a shortfall in connection with stock-based compensation vested during the quarter, foreign return to provision differences and interest on unrecognized tax positions, partially offset by the tax benefit from changes in prior year uncertain tax positions.

[0001628280-25-004288:notes:226]
Our estimated effective tax rate for the three months ended December 28, 2024 differs from the 21% U.S. statutory rate primarily due to the income tax expense from foreign rate differential, non-deductible stock-based compensation, and current year valuation allowance changes, partially offset by the income tax benefit from various income tax credits.

[0001628280-25-004288:notes:227]
We regularly assess our ability to realize our deferred tax assets on a quarterly basis and will establish a valuation allowance if it is more-likely-than-not that some portion of the deferred tax assets will not be realized. As of December 28, 2024, we maintain a full valuation allowance on U.S. federal and state and certain foreign deferred tax assets. We will continue to assess the need for a valuation allowance against our remaining deferred tax assets and may increase or decrease our valuation allowance materially in the future.

[0001628280-25-004288:notes:228]
As of December 28, 2024, we had $95.5 million of unrecognized tax benefits, which, if recognized, would affect the effective tax rate. We are subject to examination of income tax returns by various domestic and foreign tax authorities. The timing of resolution and closure of these tax examinations is highly unpredictable. Although it is possible that certain ongoing tax examinations may be concluded within the next 12 months, we cannot reasonably estimate the impact to tax expense and net income from tax examinations that could be resolved or closed within the next 12 months. Subject to audit timing and uncertainty, we expect the amount of unrecognized tax benefit that would become recognized due to expiration of the statute of limitations and affect the effective tax rate to decrease by $3.7 million over the next 12 months.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001628280-25-004288:notes:229]
[same as prior period, unchanged from 0001628280-24-046443:notes:228]

[0001628280-25-004288:notes:230]
[same as prior period, unchanged from 0001628280-24-046443:notes:229]

[0001628280-25-004288:notes:231]
[same as prior period, unchanged from 0001628280-24-046443:notes:230]

[0001628280-25-004288:notes:232]
On November 17, 2023, our stockholders approved amendments to the Amended and Restated Equity Incentive Plan (the “2015 Plan”) to increase the number of shares of common stock reserved for issuance by an additional 3.0 million shares. On November 20, 2024, our stockholders approved an amendment to the 2015 Plan to extend the expiration date of the 2015 Plan by one year until June 23, 2026.

[0001628280-25-004288:notes:233]
As of December 28, 2024, we had 5.2 million shares subject to stock options, restricted stock units, restricted stock awards, and performance stock units issued and outstanding under the 2015 Plan. Restricted stock units, restricted stock awards, and performance stock units are performance-based, time-based or a combination of both and are expected to vest within four years. The fair value of these grants is based on the closing market price of our common stock on the date of grant. The exercise price for stock options is equal to the fair value of the underlying stock at the date of grant. We issue new shares of common stock upon exercise of stock options. Options generally have vesting period of three years. As of December 28, 2024, 2.3 million shares of common stock under the 2015 Plan were available for grant.

[0001628280-25-004288:notes:234]
[same as prior period, unchanged from 0001628280-24-046443:notes:234]

[0001628280-25-004288:notes:235]
In connection with the acquisition of Cloud Light, each of Cloud Light’s outstanding options was exchanged for a combination of cash and options to acquire Lumentum common stock having equivalent value (the “replacement options”) using an exchange ratio of 0.04375 according to the terms in the Merger Agreement. At the Cloud Light Closing Date, the replacement options consisted of 1.1 million options with a weighted average grant date fair value of $34.63. These replacement options have a total fair value of $38.9 million as of the Closing date, of which $23.5 million attributed to pre-acquisition service was recorded as part of purchase price consideration and the remaining $15.4 million will be recorded as post-acquisition stock-based compensation expense over the vesting period of three years from the Cloud Light Closing Date. Refer to “Note 4. Business Combinations.”

[0001628280-25-004288:notes:236]
[same as prior period, unchanged from 0001628280-24-046443:notes:236]

[0001628280-25-004288:notes:237]
[same as prior period, unchanged from 0001628280-24-046443:notes:237]

[0001628280-25-004288:notes:238]
[same as prior period, unchanged from 0001628280-24-046443:notes:238]

[0001628280-25-004288:notes:239]
[same as prior period, unchanged from 0001628280-24-046443:notes:239]

[0001628280-25-004288:notes:240]
During the six months ended December 28, 2024, our board of directors approved grants of 1.5 million RSUs, which primarily vest over three years.

[0001628280-25-004288:notes:241]
[same as prior period, unchanged from 0001628280-24-046443:notes:241]

[0001628280-25-004288:notes:242]
Performance stock units (“PSUs”) under the 2015 Plan are grants of shares of our common stock that vest upon the achievement of certain performance and service conditions. For PSUs with performance-based conditions, we begin recognizing compensation expense when we conclude that it is probable that the performance conditions will be achieved. We reassess the probability of vesting at each reporting period and adjust our compensation cost based on this probability assessment. For PSUs with market-based conditions, the compensation expense is recognized ratably over the requisite service period regardless of whether or not the market condition is satisfied, provided the requisite service is rendered. Our PSUs are subject to risk of forfeiture until performance and service conditions are satisfied and generally vest within three years.

[0001628280-25-004288:notes:243]
During the six months ended December 28, 2024, we granted 0.7 million PSUs with an aggregate grant date fair value of $39.8 million to executive and non-executive employees as part of our revised Annual Incentive Plan. These PSUs are subject to performance targets and service conditions, with a vesting period of one year. We also granted 0.4 million PSUs with an aggregate grant date fair value of $21.2 million to certain executive officers and senior management. These PSUs will vest subject to the achievement of revenue targets, certain non-financial performance measurements and the Company’s total shareholder return (or “TSR”) relative to a specified peer group, as well as service conditions, over three years. The number of shares may be increased or decreased based on the results of these measurement targets ranging between 0% and 300% in accordance with the terms established at the date of grant. Approximately 25% of the 0.4 million PSUs granted during the six months ended December 28, 2024 will vest based on the Company’s relative TSR. The Company estimated the grant date fair value of TSR awards using a Monte-Carlo simulation model, which was calculated at $70.57 per share.

[0001628280-25-004288:notes:244]
[same as prior period, unchanged from 0001628280-24-046443:notes:244]

[0001628280-25-004288:notes:245]
Our 2015 Purchase Plan provides eligible employees with the opportunity to acquire an ownership interest in the Company through periodic payroll deductions and provides a 15% purchase price discount as well as a 6-month look-back period. The 2015 Purchase Plan is structured as a qualified employee stock purchase plan under Section 423 of the Internal Revenue Code of 1986, as amended. The 2015 Purchase Plan will terminate upon the date on which all shares available for issuance have been sold. Of the 3.0 million shares authorized under the 2015 Purchase Plan, 0.5 million shares remained available for issuance as of December 28, 2024.

[0001628280-25-004288:notes:246]
[same as prior period, unchanged from 0001628280-24-046443:notes:246]

[0001628280-25-004288:notes:247]
[same as prior period, unchanged from 0001628280-24-046443:notes:247]

[0001628280-25-004288:notes:248]
|  | Three Months Ended |  | Six Months Ended |
|  | December 28, 2024 |  | December 30, 2023 |  | December 28, 2024 |  | December 30, 2023 |
| Cost of sales | $ | 9.2 |  |  | $ | 9.0 |  |  | $ | 18.9 |  |  | $ | 15.0 |  |
| Research and development | 11.4 |  |  | 10.0 |  |  | 20.7 |  |  | 20.3 |  |
| Selling, general and administrative | 18.2 |  |  | 15.6 |  |  | 34.8 |  |  | 31.4 |  |
| Total stock-based compensation | $ | 38.8 |  |  | $ | 34.6 |  |  | $ | 74.4 |  |  | $ | 66.7 |  |

[0001628280-25-004288:notes:249]
During the three and six months ended December 28, 2024, we recorded $12.2 million and $19.5 million of stock-based compensation related to PSUs, respectively. During the three months ended December 30, 2023, we recorded $0.2 million of net reversal of stock-based compensation related to PSUs due to decline in anticipated achievement of performance conditions. During the six months ended December 30, 2023, we recorded $4.5 million of stock-based compensation related to PSUs. For PSUs with performance-based conditions, the amount of stock-based compensation expense recognized in any one period related to PSUs can vary based on the achievement or anticipated achievement of the performance conditions. If the

[0001628280-25-004288:notes:250]
performance conditions are not met or not expected to be met, no compensation cost would be recognized on the underlying PSUs, and any previously recognized compensation expense related to those PSUs would be reversed.

[0001628280-25-004288:notes:251]
[same as prior period, unchanged from 0001628280-24-046443:notes:250]

[0001628280-25-004288:notes:252]
|  | Three Months Ended |  | Six Months Ended |
|  | December 28, 2024 |  | December 30, 2023 |  | December 28, 2024 |  | December 30, 2023 |
| Income tax benefit associated with stock-based compensation | $ | 4.7 |  |  | $ | 0.6 |  |  | $ | 6.1 |  |  | $ | 2.5 |  |

[0001628280-25-004288:notes:253]
Approximately $13.1 million and $14.4 million of stock-based compensation was capitalized to inventory as of December 28, 2024 and June 29, 2024, respectively.

[0001628280-25-004288:notes:254]
As of December 28, 2024, $149.1 million of stock-based compensation cost related to RSU awards remains to be amortized, which is expected to be recognized over an estimated amortization period of 2.1 years.

[0001628280-25-004288:notes:255]
[same as prior period, unchanged from 0001628280-24-046443:notes:254]

[0001628280-25-004288:notes:256]
The following table summarizes our award activities for the six months ended December 28, 2024 (in millions):

[0001628280-25-004288:notes:257]
|  | Stock Options |  | Restricted Stock Units |  | Performance Stock Units |  |  |  |  |
|  | Number of Shares |  | Weighted-Average Exercise Price per Share |  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |  | Number of Shares |  | Weighted-Average Grant Date Fair Value per Share |  |  |  |  |
| Balance as of June 29, 2024 | 1.1 |  |  | $ | 8.0 |  |  | 2.7 |  |  | $ | 62.5 |  |  | 0.9 |  |  | $ | 65.5 |  |  |  |  |  |
| Granted | — |  |  | — |  |  | 1.5 |  |  | 57.3 |  |  | 1.1 |  |  | 56.5 |  |  |  |  |  |
| Vested/Exercised | (0.3) |  |  | 7.8 |  |  | (1.1) |  |  | 64.8 |  |  | (0.1) |  |  | 79.8 |  |  |  |  |  |
| Canceled | — |  |  | — |  |  | (0.2) |  |  | 61.2 |  |  | (0.4) |  |  | 62.0 |  |  |  |  |  |
| Balance as of December 28, 2024 | 0.8 |  |  | $ | 8.0 |  |  | 2.9 |  |  | $ | 58.9 |  |  | 1.5 |  |  | $ | 59.2 |  |  |  |  |  |

[0001628280-25-004288:notes:258]
[same as prior period, unchanged from 0001628280-24-046443:notes:257]

[0001628280-25-004288:notes:259]
|  | Awards Available for Grant |
| Balance as of June 29, 2024 | 4.3 |  |
| Granted | (2.6) |  |
| Canceled | 0.6 |  |
| Balance as of December 28, 2024 | 2.3 |  |

[0001628280-25-004288:notes:260]
[same as prior period, unchanged from 0001628280-24-046443:notes:259]

[0001628280-25-004288:notes:261]
The 2015 Purchase Plan expense for the three and six months ended December 28, 2024 was $1.0 million and $2.2 million, respectively. The 2015 Purchase Plan expense for the three and six months ended December 30, 2023 was $1.0 million and $2.2 million, respectively. The expense related to the 2015 Purchase Plan is recorded on a straight-line basis over the relevant subscription period.

[0001628280-25-004288:notes:262]
During the six months ended December 28, 2024 and December 30, 2023, there were 0.2 million and 0.2 million shares issued to employees through the 2015 Purchase Plan, respectively.

[0001628280-25-004288:notes:263]
[same as prior period, unchanged from 0001628280-24-046443:notes:262]

[0001628280-25-004288:notes:264]
[same as prior period, unchanged from 0001628280-24-046443:notes:263]

[0001628280-25-004288:notes:265]
We have a share buyback program that authorizes us to utilize up to an aggregate amount of $1.2 billion to purchase our own shares of common stock through May 2025. During the six months ended December 28, 2024 and December 30, 2023, we did not repurchase any shares of our common stock. Since the board of directors initially approved the share buyback program, we have repurchased 7.7 million shares in aggregate at an average price of $81.66 per share for a total purchase price of $630.4 million. We recorded the $630.4 million aggregate purchase price as a reduction of retained earnings within our condensed consolidated balance sheet and immediately retired all repurchased shares. As of December 28, 2024, we have $569.6 million remaining under the share buyback program.

[0001628280-25-004288:notes:266]
[same as prior period, unchanged from 0001628280-24-046443:notes:265]


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0001628280-25-004288:notes:267]
Note 14. Commitments and Contingencies

[0001628280-25-004288:notes:268]
Purchase Obligations

[0001628280-25-004288:notes:269]
Our purchase obligations of $620.1 million as of December 28, 2024 represent legally binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule and adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

[0001628280-25-004288:notes:270]
We depend on a limited number of contract manufacturers, subcontractors and suppliers for raw materials, packages and standard components. We generally purchase these single or limited source products through standard purchase orders or one-year supply agreements and have no significant long-term guaranteed supply agreements with these vendors. While we seek to maintain a sufficient safety stock of such products and maintain on-going communications with our suppliers to guard against interruptions or cessation of supply, our business and results of operations could be adversely affected by a stoppage or delay of supply, substitution of more expensive or less reliable products, receipt of defective parts or contaminated materials, increases in the price of such supplies, or our inability to obtain reduced pricing from our suppliers in response to competitive pressures.

[0001628280-25-004288:notes:271]
Product Warranties

[0001628280-25-004288:notes:272]
We provide reserves for the estimated costs of product warranties at the time revenue is recognized. We typically offer a twelve-month warranty for most of our products. However, in some instances depending upon the product, product components or application of our products by the end customer, our warranties can vary and generally range from six months to five years. We estimate the costs of our warranty obligations on an annualized basis based on our historical experience of known product failure rates, use of materials to repair or replace defective products, and service delivery costs incurred in correcting product failures. In addition, from time-to-time, specific warranty accruals may be made if unforeseen technical problems arise with specific products. We assess the adequacy of our recorded warranty liabilities and adjust the amounts as necessary.

[0001628280-25-004288:notes:273]
The following table presents the changes in our warranty reserve for the periods presented (in millions):

[0001628280-25-004288:notes:274]
|  | Three Months Ended |  | Six Months Ended |
|  | December 28, 2024 |  | December 30, 2023 |  | December 28, 2024 |  | December 30, 2023 |
| Balance as of beginning of period | $ | 13.2 |  |  | $ | 5.5 |  |  | $ | 13.2 |  |  | $ | 6.8 |  |
| Warranties assumed in Cloud Light acquisition | — |  |  | 5.2 |  |  | 0.8 |  |  | 5.2 |  |
| Provision for warranty | 2.0 |  |  | 0.8 |  |  | 4.4 |  |  | 1.0 |  |
| Utilization of reserve, net | (2.4) |  |  | (1.4) |  |  | (5.6) |  |  | (2.9) |  |
| Balance as of end of period | $ | 12.8 |  |  | $ | 10.1 |  |  | $ | 12.8 |  |  | $ | 10.1 |  |

[0001628280-25-004288:notes:275]
Environmental Liabilities

[0001628280-25-004288:notes:276]
Our research and development, manufacturing and distribution operations involve the use of hazardous substances and are regulated under international, federal, state and local laws governing health and safety and the environment. We apply strict standards for protection of the environment and occupational health and safety to sites inside and outside the United States, even if not subject to regulations imposed by foreign governments. We believe that our properties and operations at our facilities comply in all material respects with applicable environmental laws and occupational health and safety laws. However, the risk of environmental liabilities cannot be completely eliminated and there can be no assurance that the application of environmental and health and safety laws will not require us to incur significant expenditures. We are also regulated under a number of international, federal, state and local laws regarding recycling, product packaging and product content requirements. The environmental and product content/disposal and recycling laws are gradually becoming more stringent and may cause us to incur significant expenditures in the future.

[0001628280-25-004288:notes:277]
Legal Proceedings

[0001628280-25-004288:notes:278]
We are subject to a variety of claims and suits that arise from time-to-time in the ordinary course of our business. While management currently believes that resolving claims against us, individually or in the aggregate, will not have a material adverse impact on our financial position, results of operations or statements of cash flows, these matters are subject to inherent uncertainties and management’s view of these matters may change in the future. We accrue for loss contingencies when it is both probable that we will incur the loss and when we can reasonably estimate the amount of the loss or range of loss. As of December 28, 2024, we have accrued $1.2 million with respect to settlement of certain non-ordinary course litigation matters.

[0001628280-25-004288:notes:279]
Oclaro Merger Litigation

[0001628280-25-004288:notes:280]
In connection with our acquisition of Oclaro in 2018, seven lawsuits were filed by purported stockholders of Oclaro challenging the proposed merger (the “Merger”). All but one was voluntarily dismissed after the Oclaro Merger closed. The remaining lawsuit, SaiSravan B. Karri v. Oclaro, Inc., et al., No. 3:18-cv-03435-JD (the “Karri Lawsuit”), was filed in the United States District Court for the Northern District of California and was styled as a class action.

[0001628280-25-004288:notes:281]
The Karri Lawsuit alleged, among other things, that Oclaro and its directors violated Section 14(a) of the Securities Exchange Act of 1934, as amended (the “Exchange Act”), and Rule 14a-9 promulgated thereunder by disseminating an incomplete and misleading Form S-4, including proxy statement/prospectus. The Karri Lawsuit further alleged that Oclaro’s directors violated Section 20(a) of the Exchange Act by failing to exercise proper control over the person(s) who violated Section 14(a) of the Exchange Act. The plaintiff in the Karri Lawsuit sought, among other things, damages to be awarded to the plaintiff and any class, if a class is certified, and litigation costs, including attorneys’ fees.

[0001628280-25-004288:notes:282]
The case proceeded through fact and expert discovery and the parties subsequently reached an agreement for a class-wide settlement of the Karri Lawsuit that provided for a payment of $15.3 million to the members of the class. On August 17, 2023, the court preliminarily approved the settlement. In March 2024, the court finally approved the settlement.

[0001628280-25-004288:notes:283]
We recorded the court approved settlement amount of $15.3 million as accrued expenses in our condensed consolidated balance sheet as of June 29, 2024, of which $7.5 million represents the amount to be reimbursed by insurance and was recorded as prepayments and other current assets. As of September 28, 2024, this litigation matter was settled and all amounts were paid.

[0001628280-25-004288:notes:284]
Regulatory Matters

[0001628280-25-004288:notes:285]
In August 2024, the Company received inquiries from the Bureau of Industry and Security of the U.S. Department of Commerce (“BIS”) and Department of Justice (“DOJ”) following the Company’s voluntary disclosure to BIS in December 2023, and supplemented in April 2024. The Company continues to cooperate with both agencies on this matter.  The Company is unable to predict the likely outcome of these matters.

[0001628280-25-004288:notes:286]
Indemnifications

[0001628280-25-004288:notes:287]
In the normal course of business, we enter into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown, because claims may be made against us in the future, and we may record charges in the future as a result of these indemnification obligations. As of December 28, 2024, we did not have any material indemnification claims that were probable or reasonably possible.

[0001628280-25-004288:notes:288]
Audit Proceedings

[0001628280-25-004288:notes:289]
We are under audit by various domestic and foreign tax authorities with regards to income tax and indirect tax matters. In some, although not all cases, we have reserved for potential adjustments to our provision for income taxes and accrual of indirect taxes that may result from examinations by these tax authorities or final outcomes in judicial proceedings, and we believe that the final outcome of these examinations, agreements or judicial proceedings will not have a material effect on our results of operations. If events occur which indicate payment of these amounts is unnecessary, the reversal of the liabilities would result in the recognition of benefits in the period when we determine the liabilities are no longer necessary. If our estimates of the federal, state, and foreign income tax liabilities and indirect tax liabilities are less than the ultimate assessment, it could result in a further charge to expense.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001628280-25-004288:notes:290]
[same as prior period, unchanged from 0001628280-24-046443:notes:290]

[0001628280-25-004288:notes:291]
[same as prior period, unchanged from 0001628280-24-046443:notes:291]

[0001628280-25-004288:notes:292]
[same as prior period, unchanged from 0001628280-24-046443:notes:292]

[0001628280-25-004288:notes:293]
[same as prior period, unchanged from 0001628280-24-046443:notes:293]

[0001628280-25-004288:notes:294]
[same as prior period, unchanged from 0001628280-24-046443:notes:294]

[0001628280-25-004288:notes:295]
[same as prior period, unchanged from 0001628280-24-046443:notes:295]

[0001628280-25-004288:notes:296]
[same as prior period, unchanged from 0001628280-24-046443:notes:296]

[0001628280-25-004288:notes:297]
Our Industrial Tech products include short pulse solid-state lasers, kilowatt-class fiber lasers, ultrafast lasers, diode lasers, and gas lasers,  which address applications in numerous end-markets. In the consumer end-market, our laser light sources are integrated into our customers’ 3D sensing cameras, which are used in mobile devices, payment kiosks, and other consumer electronics devices to enable applications including biometric identification, computational photography and virtual and augmented reality. In the automotive end-market, our lasers are used in our customers’ LiDAR and other optical sensor devices, which are increasingly being used in advanced driver assistance systems (“ADAS”) and in-cabin driver and occupant monitoring systems. In the industrial manufacturing end-market, our lasers are incorporated into our customers’ manufacturing machine tools used for the precision processing of materials in a range of industries including semiconductor device and microelectronics fabrication, electric vehicle and battery production, metal cutting and welding, and advanced manufacturing. Our products can also be used in the industrial end-market in imaging and sensing systems for process feedback and control, quality assurance, and waste reduction. Adoption of our products in the industrial end-market is driven by the needs of customers to advance semiconductor and microelectronics industry roadmaps, and by Industry 4.0/5.0 trends, including increasing manufacturing precision and flexibility and reducing waste and environmental impact. Demand for our products in the industrial end-market is driven by end-customer investments in manufacturing capacity. Our lasers also address certain

[0001628280-25-004288:notes:298]
semiconductor inspection and life-science applications.

[0001628280-25-004288:notes:299]
[same as prior period, unchanged from 0001628280-24-046443:notes:298]

[0001628280-25-004288:notes:300]
[same as prior period, unchanged from 0001628280-24-046443:notes:299]

[0001628280-25-004288:notes:301]
|  | Three Months Ended |  | Six Months Ended |
|  | December 28, 2024 |  | December 30, 2023 |  | December 28, 2024 |  | December 30, 2023 |
| Net revenue: |  |  |  |  |  |  |  |
| Cloud & Networking | $ | 339.2 |  |  | $ | 286.7 |  |  | $ | 621.5 |  |  | $ | 516.4 |  |
| Industrial Tech | 63.0 |  |  | 80.1 |  |  | 117.6 |  |  | 168.0 |  |
| Net revenue | $ | 402.2 |  |  | $ | 366.8 |  |  | $ | 739.1 |  |  | $ | 684.4 |  |
| Segment profit (loss): |  |  |  |  |  |  |  |
| Cloud & Networking | $ | 54.9 |  |  | $ | 29.1 |  |  | $ | 91.4 |  |  | $ | 53.0 |  |
| Industrial Tech | 3.9 |  |  | 12.7 |  |  | 6.1 |  |  | 28.0 |  |
| Total segment profit | 58.8 |  |  | 41.8 |  |  | $ | 97.5 |  |  | 81.0 |  |
| Unallocated corporate items: |  |  |  |  |  |  |  |
| Selling, general and administrative (1) | (27.1) |  |  | (28.8) |  |  | (55.8) |  |  | (57.4) |  |
| Stock-based compensation | (38.8) |  |  | (34.6) |  |  | (74.4) |  |  | (66.7) |  |
| Amortization of acquired intangibles | (39.0) |  |  | (37.6) |  |  | (80.7) |  |  | (66.6) |  |
| Amortization of acquired inventory fair value adjustments | — |  |  | (3.4) |  |  | — |  |  | (3.4) |  |
| Acquisition related costs | — |  |  | (9.0) |  |  | — |  |  | (13.0) |  |
| Integration related costs | (3.1) |  |  | (11.6) |  |  | (6.5) |  |  | (22.9) |  |
| Restructuring and related charges | (0.7) |  |  | (5.8) |  |  | (10.4) |  |  | (16.8) |  |
| Abnormal excess capacity | — |  |  | (1.8) |  |  | — |  |  | (1.8) |  |
| Intangible asset write-off | — |  |  | — |  |  | (1.9) |  |  | — |  |
| Other charges, net | (1.7) |  |  | (14.4) |  |  | (1.8) |  |  | (18.4) |  |
| Interest expense | (5.6) |  |  | (9.7) |  |  | (11.1) |  |  | (19.4) |  |
| Other income, net (2) | 14.9 |  |  | 13.4 |  |  | 23.6 |  |  | 34.6 |  |
| Consolidated loss before income taxes | $ | (42.3) |  |  | $ | (101.5) |  |  | $ | (121.5) |  |  | $ | (170.8) |  |

[0001628280-25-004288:notes:302]
(1) We do not allocate certain selling, general and administrative expenses that are not directly attributable to our operating segments.

[0001628280-25-004288:notes:303]
(2) Other income, net for the three months ended December 28, 2024 includes interest and investment income of $9.0 million, and foreign exchange and other gains, net of $5.9 million.  Other income, net for the six months ended December 28, 2024 includes interest and investment income of $18.4 million, and foreign exchange and other gain, net of $5.2 million.

[0001628280-25-004288:notes:304]
Other income, net for the three months ended December 30, 2023 includes interest and investment income of $17.1 million, offset by foreign exchange and other loss, net of $3.7 million. Other income, net for the six months ended December 30, 2023 includes interest and investment income of $38.8 million, offset by foreign exchange and other loss, net of $4.2 million.

[0001628280-25-004288:notes:305]
[same as prior period, unchanged from 0001628280-24-046443:notes:304]

[0001628280-25-004288:notes:306]
[same as prior period, unchanged from 0001628280-24-046443:notes:305]

[0001628280-25-004288:notes:307]
[same as prior period, unchanged from 0001628280-24-046443:notes:306]

[0001628280-25-004288:notes:308]
|  | Three Months Ended |  | Six Months Ended |
|  | December 28, 2024 |  | December 30, 2023 |  | December 28, 2024 |  | December 30, 2023 |
|  | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| United States | $ | 77.6 |  |  | 19.3 | % |  | $ | 103.0 |  |  | 28.1 | % |  | $ | 143.0 |  |  | 19.3 | % |  | $ | 144.1 |  |  | 21.0 | % |
| Mexico | 37.4 |  |  | 9.3 |  |  | 31.4 |  |  | 8.6 |  |  | 71.3 |  |  | 9.6 |  |  | 55.1 |  |  | 8.1 |  |
| Other Americas | 4.2 |  |  | 1.0 |  |  | 0.8 |  |  | 0.2 |  |  | 7.1 |  |  | 1.0 |  |  | 2.0 |  |  | 0.3 |  |
| Total Americas | $ | 119.2 |  |  | 29.6 | % |  | $ | 135.2 |  |  | 36.9 | % |  | $ | 221.4 |  |  | 29.9 | % |  | $ | 201.2 |  |  | 29.4 | % |
| Asia-Pacific: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Hong Kong | $ | 100.5 |  |  | 25.0 | % |  | $ | 65.7 |  |  | 17.9 | % |  | $ | 189.2 |  |  | 25.6 | % |  | $ | 130.6 |  |  | 19.1 | % |
| South Korea | 6.8 |  |  | 1.7 |  |  | 20.8 |  |  | 5.7 |  |  | 15.6 |  |  | 2.1 |  |  | 45.8 |  |  | 6.7 |  |
| Japan | 18.4 |  |  | 4.5 |  |  | 25.9 |  |  | 7.1 |  |  | 35.3 |  |  | 4.8 |  |  | 51.3 |  |  | 7.5 |  |
| Thailand | 74.7 |  |  | 18.6 |  |  | 39.3 |  |  | 10.7 |  |  | 127.2 |  |  | 17.2 |  |  | 103.5 |  |  | 15.1 |  |
| Other Asia-Pacific | 41.8 |  |  | 10.4 |  |  | 49.5 |  |  | 13.4 |  |  | 79.0 |  |  | 10.7 |  |  | 89.0 |  |  | 13.0 |  |
| Total Asia-Pacific | $ | 242.2 |  |  | 60.2 | % |  | $ | 201.2 |  |  | 54.8 | % |  | $ | 446.3 |  |  | 60.4 | % |  | $ | 420.2 |  |  | 61.4 | % |
| EMEA | $ | 40.8 |  |  | 10.2 | % |  | $ | 30.4 |  |  | 8.3 | % |  | $ | 71.4 |  |  | 9.7 | % |  | $ | 63.0 |  |  | 9.2 | % |
| Total net revenue | $ | 402.2 |  |  | 100.0 | % |  | $ | 366.8 |  |  | 100.0 | % |  | $ | 739.1 |  |  | 100.0 | % |  | $ | 684.4 |  |  | 100.0 | % |

[0001628280-25-004288:notes:309]
During the three months ended December 28, 2024, three customers individually accounted for 16%, 14% and 11% of our total revenue, respectively. During the six months ended December 28, 2024, three customers individually accounted for 15%, 13% and 10% of our total net revenue, respectively. We had no other customers that represented 10% or greater of our total net revenue.

[0001628280-25-004288:notes:310]
During the three months ended December 30, 2023, three customers individually accounted for 19%, 13% and 11% of our total revenue, respectively. During the six months ended December 30, 2023, three customers individually accounted for 14%, 12% and 12% of our total net revenue, respectively. We had no other customers that represented 10% or greater of our total net revenue.

[0001628280-25-004288:notes:311]
As of December 28, 2024, two customers individually accounted for 13% and 11% of gross accounts receivable, respectively. As of June 29, 2024, one customer individually accounted for 13% of gross accounts receivable. We had no other customers that represented 10% or greater of our gross accounts receivable.

[0001628280-25-004288:notes:312]
[same as prior period, unchanged from 0001628280-24-046443:notes:310]

[0001628280-25-004288:notes:313]
|  | December 28, 2024 |  | June 29, 2024 |
| Property, plant and equipment, net |  |  |  |
| United States | $ | 125.1 |  |  | $ | 131.0 |  |
| Thailand | 177.3 |  |  | 141.0 |  |
| Japan | 132.4 |  |  | 75.7 |  |
| United Kingdom | 92.3 |  |  | 83.8 |  |
| China | 72.4 |  |  | 85.7 |  |
| Other countries | 63.9 |  |  | 55.3 |  |
| Total property, plant and equipment, net | $ | 663.4 |  |  | $ | 572.5 |  |

[0001628280-25-004288:notes:314]
We purchase a portion of our inventory from contract manufacturers that are located primarily in Thailand, Taiwan, and Malaysia. During the three and six months ended December 28, 2024, our net inventory purchases from a single contract manufacturer that represented 10% or greater of our total net inventory purchases were concentrated with one contract manufacturer, who accounted for 27% and 27% of the total net inventory purchases, respectively. During the three and six months ended December 30, 2023, our net inventory purchases from a single contract manufacturer that represented 10% or greater of our total net inventory purchases were concentrated with one contract manufacturer, who accounted for 33% and 43% of the total net inventory purchases, respectively.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001628280-25-004288:notes:315]
[same as prior period, unchanged from 0001628280-24-046443:notes:313]

[0001628280-25-004288:notes:316]
[same as prior period, unchanged from 0001628280-24-046443:notes:314]

[0001628280-25-004288:notes:317]
[same as prior period, unchanged from 0001628280-24-046443:notes:315]

[0001628280-25-004288:notes:318]
[same as prior period, unchanged from 0001628280-24-046443:notes:316]

[0001628280-25-004288:notes:319]
|  | Three Months Ended |  | Six Months Ended |
|  | December 28, 2024 |  | December 30, 2023 |  | December 28, 2024 |  | December 30, 2023 |
|  | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |
| Cloud & Networking | $ | 339.2 |  |  | 84.3 | % |  | 286.7 |  |  | 78.2 | % |  | $ | 621.5 |  |  | 84.1 | % |  | $ | 516.4 |  |  | 75.5 | % |
| Industrial Tech | 63.0 |  |  | 15.7 | % |  | 80.1 |  |  | 21.8 | % |  | 117.6 |  |  | 15.9 | % |  | 168.0 |  |  | 24.5 | % |
| Net revenue | $ | 402.2 |  |  | 100.0 | % |  | $ | 366.8 |  |  | 100.0 | % |  | $ | 739.1 |  |  | 100.0 | % |  | $ | 684.4 |  |  | 100.0 | % |

[0001628280-25-004288:notes:320]
[same as prior period, unchanged from 0001628280-24-046443:notes:318]

[0001628280-25-004288:notes:321]
[same as prior period, unchanged from 0001628280-24-046443:notes:319]

[0001628280-25-004288:notes:322]
| Contract balances |  | Balance sheet location |  | December 28, 2024 |  | June 29, 2024 |  | Change |  | Percentage Change |
| Accounts receivable, net |  | Accounts receivable, net |  | $ | 226.9 |  |  | $ | 194.7 |  |  | $ | 32.2 |  |  | 16.5 | % |
| Deferred revenue and customer deposits |  | Other current liabilities |  | $ | 0.7 |  |  | $ | 0.6 |  |  | $ | 0.1 |  |  | 16.7 | % |


## us-gaap:SubsequentEventsTextBlock

[0001628280-25-004288:notes:323]
Note 17. Subsequent Event

[0001628280-25-004288:notes:324]
On February 3, 2025, the Company announced that the Company’s board of directors (the “Board) had appointed Michael Hurlston as President and Chief Executive Officer (“CEO”) of the Company, effective February 7, 2025. Mr. Hurlston will succeed Alan Lowe, the Company’s President and CEO, who is stepping down and retiring as President and CEO effective as of the end of day February 6, 2025. Mr. Lowe will remain on the Board until the end of the Company’s fiscal year 2025 and will serve as an advisor to the Company until December 15, 2025. Mr. Hurlston has also been appointed to the Board effective as of February 7, 2025.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001628280-25-004288:notes:325]
On November 20, 2024, Alan Lowe, our President and Chief Executive Officer and a member of our board of directors, adopted a Rule 10b5-1 trading arrangement providing for the sale from time to time of an aggregate of up to 120,000 shares of our common stock. The actual number of shares sold under the trading arrangement will depend on achievement of performance targets applicable to the performance stock units (“PSUs”) subject to the trading arrangement and be net of shares withheld for taxes upon vesting and settlement of the PSUs subject to the trading arrangement. The trading arrangement is intended to satisfy the affirmative defense in Rule 10b5-1(c). The duration of the trading arrangement is until February 19, 2026, or earlier if all transactions under the trading arrangement are completed.
