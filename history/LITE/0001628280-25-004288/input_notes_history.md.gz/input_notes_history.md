# LITE note change history — 0001628280-24-046443 → 0001628280-25-004288


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-02-06):
[0001628280-25-004288:note_history:1]
Our purchase obligations of $620.1 million as of December 28, 2024 represent legally binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule and adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.
  (was, 2024-11-08, similarity 0.7522):
[0001628280-24-046443:note_history:1]
Our purchase obligations of $589.2 million as of September 28, 2024 represent legally binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, the terms generally allow the option to cancel, reschedule and

- changed (2025-02-06):
[0001628280-25-004288:note_history:2]
|  | Three Months Ended |  | Six Months Ended |
|  | December 28, 2024 |  | December 30, 2023 |  | December 28, 2024 |  | December 30, 2023 |
| Balance as of beginning of period | $ | 13.2 |  |  | $ | 5.5 |  |  | $ | 13.2 |  |  | $ | 6.8 |  |
| Warranties assumed in Cloud Light acquisition | — |  |  | 5.2 |  |  | 0.8 |  |  | 5.2 |  |
| Provision for warranty | 2.0 |  |  | 0.8 |  |  | 4.4 |  |  | 1.0 |  |
| Utilization of reserve, net | (2.4) |  |  | (1.4) |  |  | (5.6) |  |  | (2.9) |  |
| Balance as of end of period | $ | 12.8 |  |  | $ | 10.1 |  |  | $ | 12.8 |  |  | $ | 10.1 |  |
  (was, 2024-11-08, similarity 0.7197):
[0001628280-24-046443:note_history:2]
|  | Three Months Ended |  |  |
|  | September 28, 2024 |  | September 30, 2023 |  |  |  |  |
| Balance as of beginning of period | $ | 13.2 |  |  | $ | 6.8 |  |  |  |  |  |
| Warranties assumed in Cloud Light acquisition | 0.8 |  |  | — |  |  |  |  |  |
| Provision for warranty | 2.4 |  |  | 0.2 |  |  |  |  |  |
| Utilization of reserve, net | (3.2) |  |  | (1.5) |  |  |  |  |  |
| Balance as of end of period | $ | 13.2 |  |  | $ | 5.5 |  |  |  |  |  |

- changed (2025-02-06):
[0001628280-25-004288:note_history:3]
We are subject to a variety of claims and suits that arise from time-to-time in the ordinary course of our business. While management currently believes that resolving claims against us, individually or in the aggregate, will not have a material adverse impact on our financial position, results of operations or statements of cash flows, these matters are subject to inherent uncertainties and management’s view of these matters may change in the future. We accrue for loss contingencies when it is both probable that we will incur the loss and when we can reasonably estimate the amount of the loss or range of loss. As of December 28, 2024, we have accrued $1.2 million with respect to settlement of certain non-ordinary course litigation matters.
  (was, 2024-11-08, similarity 0.9276):
[0001628280-24-046443:note_history:3]
We are subject to a variety of claims and suits that arise from time-to-time in the ordinary course of our business. While management currently believes that resolving claims against us, individually or in the aggregate, will not have a material adverse impact on our financial position, results of operations or statements of cash flows, these matters are subject to inherent uncertainties and management’s view of these matters may change in the future. We accrue for loss contingencies when it is both probable that we will incur the loss and when we can reasonably estimate the amount of the loss or range of loss. During the year ended June 29, 2024, we recorded $7.8 million with respect to the pending settlement of certain non-ordinary course litigation matters which has been settled as of September 28, 2024.

- changed (2025-02-06):
[0001628280-25-004288:note_history:4]
We recorded the court approved settlement amount of $15.3 million as accrued expenses in our condensed consolidated balance sheet as of June 29, 2024, of which $7.5 million represents the amount to be reimbursed by insurance and was recorded as prepayments and other current assets. As of September 28, 2024, this litigation matter was settled and all amounts were paid.
  (was, 2024-11-08, similarity 0.9255):
[0001628280-24-046443:note_history:4]
We recorded the court approved settlement amount of $15.3 million as accrued expenses in our condensed consolidated balance sheet as of June 29, 2024, of which $7.5 million represents the amount to be reimbursed by insurance and was recorded as prepayments and other current assets. As of September 28, 2024, this litigation matter has been settled.

- changed (2025-02-06):
[0001628280-25-004288:note_history:5]
In the normal course of business, we enter into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown, because claims may be made against us in the future, and we may record charges in the future as a result of these indemnification obligations. As of December 28, 2024, we did not have any material indemnification claims that were probable or reasonably possible.
  (was, 2024-11-08, similarity 0.9923):
[0001628280-24-046443:note_history:5]
In the normal course of business, we enter into agreements that contain a variety of representations and warranties and provide for general indemnification. Exposure under these agreements is unknown, because claims may be made against us in the future, and we may record charges in the future as a result of these indemnification obligations. As of September 28, 2024, we did not have any material indemnification claims that were probable or reasonably possible.

- removed (2025-02-06):
[0001628280-24-046443:note_history:6]
adjust the requirements based on our business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2025-02-06):
[0001628280-25-004288:note_history:7]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Every fifth or sixth fiscal year will have a 53-week period. The additional week in a 53-week year is added to the third quarter, making such quarter consist of 14 weeks. Our fiscal 2025 is a 52-week year ending on June 28, 2025, with the quarter ended December 28, 2024 being a 13-week quarterly period. Our fiscal 2024 was a 52-week year that ended on June 29, 2024, with the quarter ended December 30, 2023 being a 13-week quarterly period.
  (was, 2024-11-08, similarity 0.9856):
[0001628280-24-046443:note_history:7]
We utilize a 52-53 week fiscal year ending on the Saturday closest to June 30th. Every fifth or sixth fiscal year will have a 53-week period. The additional week in a 53-week year is added to the third quarter, making such quarter consist of 14 weeks. Our fiscal 2025 is a 52-week year ending on June 28, 2025, with the quarter ended September 28, 2024 being a 13-week quarterly period. Our fiscal 2024 was a 52-week year that ended on June 29, 2024, with the quarter ended September 30, 2023 being a 13-week quarterly period.

- added (2025-02-06):
[0001628280-25-004288:note_history:8]
Accounting Policies

- changed (2025-02-06):
[0001628280-25-004288:note_history:9]
The condensed consolidated financial statements and accompanying notes should be read in conjunction with the audited consolidated financial statements and accompanying notes included in our Annual Report on Form 10-K for the fiscal year ended June 29, 2024. There were no significant changes to our accounting policies during the six months ended December 28, 2024.
  (was, 2024-11-08, similarity 0.9136):
[0001628280-24-046443:note_history:9]
Accounting Policies
The condensed consolidated financial statements and accompanying notes should be read in conjunction with the audited consolidated financial statements and accompanying notes included in our Annual Report on Form 10-K for the fiscal year ended June 29, 2024. There were no significant changes to our accounting policies during the three months ended September 28, 2024


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-02-06):
[0001628280-25-004288:note_history:10]
| December 28, 2024 |  |  | 2026 Notes (1) |  | 2028 Notes (2) |  | 2029 Notes (3) |  | Total |  |  |  |  |  |
| Principal |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |  | $ | 603.7 |  |  | $ | 2,514.7 |  |  |  |  |  |  |
| Unamortized debt discount and debt issuance costs |  |  | (2.3) |  |  | (3.9) |  |  | (3.8) |  |  | (10.0) |  |  |  |  |  |  |
| Net carrying amount of the liability component |  |  | $ | 1,047.7 |  |  | $ | 857.1 |  |  | $ | 599.9 |  |  | $ | 2,504.7 |  |  |  |  |  |  |
  (was, 2024-11-08, similarity 0.9907):
[0001628280-24-046443:note_history:10]
| September 28, 2024 |  |  | 2026 Notes (1) |  | 2028 Notes (2) |  | 2029 Notes (3) |  | Total |  |  |  |  |  |
| Principal |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |  | $ | 603.7 |  |  | $ | 2,514.7 |  |  |  |  |  |  |
| Unamortized debt discount and debt issuance costs |  |  | (2.6) |  |  | (4.1) |  |  | (4.1) |  |  | (10.8) |  |  |  |  |  |  |
| Net carrying amount of the liability component |  |  | $ | 1,047.4 |  |  | $ | 856.9 |  |  | $ | 599.6 |  |  | $ | 2,503.9 |  |  |  |  |  |  |

- changed (2025-02-06):
[0001628280-25-004288:note_history:11]
(3) If the closing price of our stock exceeds $90.40 (or 130% of the conversion price of $69.54) for 20 of the last 30 trading days of any future quarter, our 2029 Notes would become convertible at the option of the holders during the subsequent fiscal quarter and the debt would be reclassified to current liabilities in our consolidated balance sheets.
  (was, 2024-11-08, similarity 0.9912):
[0001628280-24-046443:note_history:11]
(3) If the closing price of our stock exceeds $90.40 (or 130% of the conversion price of $69.54) for 20 of the last 30 trading days of any future quarter, the 2029 Notes would become convertible at the option of the holders during the subsequent fiscal quarter and the debt would be reclassified to current liabilities in our consolidated balance sheets.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2025-02-06):
[0001628280-25-004288:note_history:12]
The net proceeds from the sale of the 2029 Notes was $599.4 million, after deducting $4.3 million of net issuance costs. In addition, we incurred $0.8 million of professional fees directly related to this transaction. Concurrent with the issuance of the 2029 Notes, we used $132.8 million of the net proceeds to repurchase $125.0 million aggregate principal amount of the 0.25% convertible senior notes due in 2024 and $125.0 million of the net proceeds to repurchase our common stock in privately negotiated transactions. We intend to use the remaining net proceeds for general corporate purposes, which may include the repayment of our indebtedness, including any of our existing convertible notes, capital expenditures, working capital and potential acquisitions.

- changed (2025-02-06):
[0001628280-25-004288:note_history:13]
•during any fiscal quarter commencing after September 30, 2023 (and only during such fiscal quarter), if the last reported sale price of the common stock for at least 20 trading days (whether or not consecutive) during the period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% of the applicable conversion price of the 2029 Notes, or $90.40, on each applicable trading day;
  (was, 2024-11-08, similarity 0.9725):
[0001628280-24-046443:note_history:13]
•during any fiscal quarter commencing after September 30, 2023 (and only during such fiscal quarter), if the last reported sale price of the common stock for at least 20 trading days (whether or not consecutive) during the period of 30 consecutive trading days ending on the last trading day of the immediately preceding fiscal quarter is greater than or equal to 130% if the applicable conversion price on each applicable trading day;

- changed (2025-02-06):
[0001628280-25-004288:note_history:14]
The entire 2029 Notes are recorded as convertible notes, non-current in our consolidated balance sheets as of December 28, 2024 and June 29, 2024, measured at amortized cost.
  (was, 2024-11-08, similarity 0.9844):
[0001628280-24-046443:note_history:14]
The entire 2029 Notes are recorded as convertible notes, non-current in our consolidated balance sheets as of September 28, 2024 and June 29, 2024, measured at amortized cost.

- changed (2025-02-06):
[0001628280-25-004288:note_history:15]
•during the five consecutive business day period after any five consecutive trading day period (the “measurement period”) in which the trading price per $1,000 principal amount of the 2028 Notes for each trading day of such measurement period was less than 98% of the product of the last reported sale price of the Company’s common stock and the applicable conversion rate on each such trading day;
  (was, 2024-11-08, similarity 0.7129):
[0001628280-24-046443:note_history:15]
•during the five consecutive business day period after any five consecutive trading day period (the “measurement period”) in which the trading price per $1,000 principal amount of the 2028 Notes for each trading day of such

- changed (2025-02-06):
[0001628280-25-004288:note_history:16]
We initially bifurcated the principal amount of the 2028 Notes into liability and equity components. The liability component of the 2028 Notes was initially valued at $629.8 million based on the contractual cash flow discounted at an appropriate comparable market on non-convertible debt borrowing rate at the date of issuance, which was 5.7%, with the equity component representing the residual amount of the proceeds of $231.2 million, which was recorded as a debt discount. Upon adoption of ASU 2020-06 in the first quarter of fiscal 2023, our 2028 Notes were accounted for as a single liability measured at amortized cost. The entire 2028 Notes are recorded as convertible notes, non-current in our consolidated balance sheets as of December 28, 2024 and June 29, 2024, measured at amortized cost.
  (was, 2024-11-08, similarity 0.9954):
[0001628280-24-046443:note_history:16]
We initially bifurcated the principal amount of the 2028 Notes into liability and equity components. The liability component of the 2028 Notes was initially valued at $629.8 million based on the contractual cash flow discounted at an appropriate comparable market on non-convertible debt borrowing rate at the date of issuance, which was 5.7%, with the equity component representing the residual amount of the proceeds of $231.2 million, which was recorded as a debt discount. Upon adoption of ASU 2020-06 in the first quarter of fiscal 2023, our 2028 Notes were accounted for as a single liability measured at amortized cost. The entire 2028 Notes are recorded as convertible notes, non-current in our consolidated balance sheets as of September 28, 2024 and June 29, 2024, measured at amortized cost.

- changed (2025-02-06):
[0001628280-25-004288:note_history:17]
In December 2019, we issued $1,050.0 million in aggregate principal amount of 0.50% Convertible Senior Notes due in 2026 (the “2026 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act. The 2026 Notes are governed by an indenture between the Company and U.S. Bank Trust Company, National Association as successor in interest to U.S. Bank National Association, as trustee (as supplemented by the First Supplemental Indenture, dated as of September 25, 2024, the “2026 Indenture”). We used approximately $196.0 million of the net proceeds of the offering to repay in full all amounts outstanding under our term loan credit facility, and a portion of the net proceeds of the offering to purchase approximately $200.0 million of our common stock concurrently with the pricing of the offering in privately
  (was, 2024-11-08, similarity 0.88):
[0001628280-24-046443:note_history:17]
In December 2019, we issued $1,050.0 million in aggregate principal amount of 0.50% Convertible Senior Notes due in 2026 (the “2026 Notes”) in a private placement to qualified institutional buyers pursuant to Rule 144A under the Securities Act. The 2026 Notes are governed by an indenture between the Company and U.S. Bank Trust Company, National Association (as successor in interest to U.S. Bank National Association, as trustee (as supplemented by the First Supplemental Indenture, dated as of September 25, 2024, the “2026 Indenture”). We used approximately $196.0 million of the net proceeds of the offering to repay in full all amounts outstanding under our term loan credit facility, and a portion of the net proceeds of the offering to purchase approximately $200.0 million of our common stock concurrently with the pricing of the offering in privately negotiated transactions. The 2026 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

- added (2025-02-06):
[0001628280-25-004288:note_history:18]
negotiated transactions. The 2026 Notes are unsecured and do not contain any financial covenants, restrictions on dividends, incurrence of senior debt or other indebtedness, or the issuance or repurchase of securities by us.

- changed (2025-02-06):
[0001628280-25-004288:note_history:19]
We initially bifurcated the principal amount of the 2026 Notes into liability and equity components. The liability component of the 2026 Notes was initially valued at $734.8 million based on the contractual cash flows discounted at an appropriate comparable market non-convertible debt borrowing rate at the date of issuance of 5.8% with the equity component representing the residual amount of the proceeds of $315.2 million, which was recorded as a debt discount. Upon adoption of ASU 2020-06 in the first quarter of fiscal 2023, our 2026 Notes were accounted for as a single liability measured at amortized cost. The entire 2026 Notes are recorded as convertible notes, non-current in our consolidated balance sheets as of December 28, 2024 and June 29, 2024, measured at amortized cost.
  (was, 2024-11-08, similarity 0.9953):
[0001628280-24-046443:note_history:19]
We initially bifurcated the principal amount of the 2026 Notes into liability and equity components. The liability component of the 2026 Notes was initially valued at $734.8 million based on the contractual cash flows discounted at an appropriate comparable market non-convertible debt borrowing rate at the date of issuance of 5.8% with the equity component representing the residual amount of the proceeds of $315.2 million, which was recorded as a debt discount. Upon adoption of ASU 2020-06 in the first quarter of fiscal 2023, our 2026 Notes were accounted for as a single liability measured at amortized cost. The entire 2026 Notes are recorded as convertible notes, non-current in our consolidated balance sheets as of September 28, 2024 and June 29, 2024, measured at amortized cost.

- changed (2025-02-06):
[0001628280-25-004288:note_history:20]
The initial conversion rate of the 2024 Notes was 16.4965 shares of common stock per $1,000 principal amount of 2024 Notes, which was equivalent to an initial conversion price of approximately $60.62 per share. The conversion rate was subject to adjustment upon the occurrence of certain specified events but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change (as defined in the 2024 Indenture) or our issuance of a notice of redemption, we were required to, in certain circumstances, increase the conversion rate by a number of additional shares for a holder that elected to convert the 2024 Notes in connection with such make-whole fundamental change or notice of redemption.
  (was, 2024-11-08, similarity 0.8969):
[0001628280-24-046443:note_history:20]
The initial conversion rate of the 2024 Notes was 16.4965 shares of common stock per $1,000 principal amount of 2024 Notes, which was equivalent to an initial conversion price of approximately $60.62 per share. The conversion rate was subject to adjustment upon the occurrence of certain specified events but will not be adjusted for accrued and unpaid interest. In addition, upon the occurrence of a make-whole fundamental change (as defined in the 2024 Indenture) or our issuance of a notice of redemption, we were required to, in certain circumstances, increase the conversion rate by a number of additional

- changed (2025-02-06):
[0001628280-25-004288:note_history:21]
Concurrent with the issuance of the 2029 Notes in June 2023, we used $132.8 million of the net proceeds to repurchase $125.0 million aggregate principal amount of the 2024 Notes, which we accounted for as an extinguishment of liability. $13.5 million of the $132.8 million repurchase price was allocated to the conversion feature of the repurchased 2024 Notes, representing the fair value of the conversion feature at the date of the repurchase, and was recognized as a reduction of the stockholders’ equity. Additionally, since issuing the 2024 Notes, we converted a total of approximately $1.9 million of principal amount of the 2024 Notes, with less than $0.1 million of principle amount converted during the three and six months ended December 28, 2024.
  (was, 2024-11-08, similarity 0.9711):
[0001628280-24-046443:note_history:21]
Concurrent with the issuance of the 2029 Notes in June 2023, we used $132.8 million of the net proceeds to repurchase $125.0 million aggregate principal amount of the 2024 Notes, which we accounted for as an extinguishment of liability. $13.5 million of the $132.8 million repurchase price was allocated to the conversion feature of the repurchased 2024 Notes, representing the fair value of the conversion feature at the date of the repurchase, and was recognized as a reduction of the stockholders’ equity. Additionally, since issuing the 2024 Notes, we converted a total of approximately $1.9 million of principal amount of the 2024 Notes, with less than $0.1 million of principle amount converted during the three months ended September 28, 2024.

- changed (2025-02-06):
[0001628280-25-004288:note_history:22]
On March 15, 2024, the 2024 Notes maturity date, we fully repaid the remaining principal amount of $323.1 million. The conversion feature previously classified within stockholder’s equity was fully amortized as of the maturity date.
  (was, 2024-11-08, similarity 0.6807):
[0001628280-24-046443:note_history:22]
conversion feature previously classified within stockholder’s equity was fully amortized as of the maturity date.

- changed (2025-02-06):
[0001628280-25-004288:note_history:23]
| December 28, 2024 |  |  | 2026 Notes (1) |  | 2028 Notes (2) |  | 2029 Notes (3) |  | Total |  |  |  |  |  |
| Principal |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |  | $ | 603.7 |  |  | $ | 2,514.7 |  |  |  |  |  |  |
| Unamortized debt discount and debt issuance costs |  |  | (2.3) |  |  | (3.9) |  |  | (3.8) |  |  | (10.0) |  |  |  |  |  |  |
| Net carrying amount of the liability component |  |  | $ | 1,047.7 |  |  | $ | 857.1 |  |  | $ | 599.9 |  |  | $ | 2,504.7 |  |  |  |  |  |  |
  (was, 2024-11-08, similarity 0.9907):
[0001628280-24-046443:note_history:23]
| September 28, 2024 |  |  | 2026 Notes (1) |  | 2028 Notes (2) |  | 2029 Notes (3) |  | Total |  |  |  |  |  |
| Principal |  |  | $ | 1,050.0 |  |  | $ | 861.0 |  |  | $ | 603.7 |  |  | $ | 2,514.7 |  |  |  |  |  |  |
| Unamortized debt discount and debt issuance costs |  |  | (2.6) |  |  | (4.1) |  |  | (4.1) |  |  | (10.8) |  |  |  |  |  |  |
| Net carrying amount of the liability component |  |  | $ | 1,047.4 |  |  | $ | 856.9 |  |  | $ | 599.6 |  |  | $ | 2,503.9 |  |  |  |  |  |  |

- changed (2025-02-06):
[0001628280-25-004288:note_history:24]
(3) If the closing price of our stock exceeds $90.40 (or 130% of the conversion price of $69.54) for 20 of the last 30 trading days of any future quarter, our 2029 Notes would become convertible at the option of the holders during the subsequent fiscal quarter and the debt would be reclassified to current liabilities in our consolidated balance sheets.
  (was, 2024-11-08, similarity 0.9912):
[0001628280-24-046443:note_history:24]
(3) If the closing price of our stock exceeds $90.40 (or 130% of the conversion price of $69.54) for 20 of the last 30 trading days of any future quarter, the 2029 Notes would become convertible at the option of the holders during the subsequent fiscal quarter and the debt would be reclassified to current liabilities in our consolidated balance sheets.

- added (2025-02-06):
[0001628280-25-004288:note_history:25]
|  | Three Months Ended |  | Six Months Ended |
|  | December 28, 2024 |  | December 30, 2023 |  | December 28, 2024 |  | December 30, 2023 |
| Contractual interest expense | $ | 4.6 |  |  | $ | 4.9 |  |  | $ | 9.3 |  |  | $ | 9.7 |  |
| Amortization of the debt discount and debt issuance costs | 0.8 |  |  | 4.8 |  |  | 1.5 |  |  | 9.7 |  |
| Total interest expense | $ | 5.4 |  |  | $ | 9.7 |  |  | $ | 10.8 |  |  | $ | 19.4 |  |

- changed (2025-02-06):
[0001628280-25-004288:note_history:26]
The future interest and principal payments related to our convertible notes are as follows as of December 28, 2024 (in millions):
  (was, 2024-11-08, similarity 0.9799):
[0001628280-24-046443:note_history:26]
The future interest and principal payments related to our convertible notes are as follows as of September 28, 2024 (in millions):

- changed (2025-02-06):
[0001628280-25-004288:note_history:27]
As of December 28, 2024, the Company has $39.2 million in principal amount outstanding, of which the short-term portion of $4.1 million is recorded as current liabilities while the long-term portion of $35.1 million is recorded as long-term debt in the Company’s condensed consolidated balance sheets.
  (was, 2024-11-08, similarity 0.9878):
[0001628280-24-046443:note_history:27]
As of September 28, 2024, the Company has $44.5 million in principal amount outstanding, of which the short-term portion of $4.5 million is recorded as current liabilities while the long-term portion of $40.0 million is recorded as long-term debt in the Company’s condensed consolidated balance sheets.

- changed (2025-02-06):
[0001628280-25-004288:note_history:28]
As of December 28, 2024, the Company has $27.1 million in principal amount outstanding, of which the short-term portion of $5.7 million is recorded as current liabilities while the long-term portion of $21.4 million is recorded as long-term debt in the Company’s condensed consolidated balance sheets.
  (was, 2024-11-08, similarity 0.9878):
[0001628280-24-046443:note_history:28]
As of September 28, 2024, the Company has $31.6 million in principal amount outstanding, of which the short-term portion of $6.3 million is recorded as current liabilities while the long-term portion of $25.3 million is recorded as long-term debt in the Company’s condensed consolidated balance sheets.

- removed (2025-02-06):
[0001628280-24-046443:note_history:29]
The net proceeds from the sale of the 2029 Notes was $599.4 million, after deducting $4.3 million of net issuance costs. In addition, we incurred $0.8 million of professional fees directly related to this transaction. Concurrent with the issuance of the 2029 Notes, we used $132.8 million of the net proceeds to repurchase $125.0 million aggregate principal amount of the 2024 Notes and $125.0 million of the net proceeds to repurchase our common stock in privately negotiated transactions. We intend to use the remaining net proceeds for general corporate purposes, which may include the repayment of our indebtedness, including any of our existing convertible notes, capital expenditures, working capital and potential acquisitions.

- removed (2025-02-06):
[0001628280-24-046443:note_history:30]
measurement period was less than 98% of the product of the last reported sale price of the Company’s common stock and the applicable conversion rate on each such trading day;

- removed (2025-02-06):
[0001628280-24-046443:note_history:31]
shares for a holder that elected to convert the 2024 Notes in connection with such make-whole fundamental change or notice of redemption.

- removed (2025-02-06):
[0001628280-24-046443:note_history:32]
On March 15, 2024, the 2024 Notes maturity date, we fully repaid the remaining principal amount of $323.1 million. The

- removed (2025-02-06):
[0001628280-24-046443:note_history:33]
|  | Three Months Ended |  |  |
|  | September 28, 2024 |  | September 30, 2023 |  |  |  |  |
| Contractual interest expense | $ | 4.7 |  |  | $ | 4.8 |  |  |  |  |  |
| Amortization of the debt discount and debt issuance costs | 0.7 |  |  | 4.9 |  |  |  |  |  |
| Total interest expense | $ | 5.4 |  |  | $ | 9.7 |  |  |  |  |  |


## us-gaap:DebtSecuritiesAvailableForSaleUnrealizedLossPositionFairValueTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-02-06):
[0001628280-25-004288:note_history:34]
|  | Continuous Loss Position for More Than 12 Months |  | Continuous Loss Position for Less Than 12 Months |  | Gross Unrealized Losses |  |  |  |  |  |  |  |  |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  |  |  |  |  |  |  |  |  |
| December 28, 2024: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | — |  |  | $ | — |  |  | $ | 36.4 |  |  | $ | (0.1) |  |  | $ | (0.1) |  |  |  |  |  |  |  |  |  |
| Commercial paper | — |  |  | — |  |  | 7.1 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 31.7 |  |  | — |  |  | 104.4 |  |  | (0.5) |  |  | (0.5) |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 58.6 |  |  | — |  |  | 28.0 |  |  | (0.1) |  |  | (0.1) |  |  |  |  |  |  |  |  |  |
| Total | $ | 90.3 |  |  | $ | — |  |  | $ | 175.9 |  |  | $ | (0.7) |  |  | $ | (0.7) |  |  |  |  |  |  |  |  |  |
| June 29, 2024: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | 62.3 |  |  | $ | (0.3) |  |  | $ | 12.6 |  |  | $ | — |  |  | $ | (0.3) |  |  |  |  |  |  |  |  |  |
| Commercial paper | — |  |  | — |  |  | 28.6 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 133.7 |  |  | (0.5) |  |  | 90.6 |  |  | (0.2) |  |  | (0.7) |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 72.3 |  |  | (0.4) |  |  | 39.7 |  |  | (0.1) |  |  | (0.5) |  |  |  |  |  |  |  |  |  |
| Total | $ | 268.3 |  |  | $ | (1.2) |  |  | $ | 171.5 |  |  | $ | (0.3) |  |  | $ | (1.5) |  |  |  |  |  |  |  |  |  |
  (was, 2024-11-08, similarity 0.8562):
[0001628280-24-046443:note_history:34]
|  | Continuous Loss Position for More Than 12 Months |  | Continuous Loss Position for Less Than 12 Months |  | Gross Unrealized Losses |  |  |  |  |  |  |  |  |
|  | Fair Value |  | Unrealized Losses |  | Fair Value |  | Unrealized Losses |  |  |  |  |  |  |  |  |  |
| September 28, 2024: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | 44.6 |  |  | $ | — |  |  | $ | 4.0 |  |  | $ | — |  |  | $ | — |  |  |  |  |  |  |  |  |  |
| Commercial paper | — |  |  | — |  |  | 7.5 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 67.1 |  |  | (0.1) |  |  | 18.0 |  |  | — |  |  | (0.1) |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 68.4 |  |  | (0.1) |  |  | 22.5 |  |  | — |  |  | (0.1) |  |  |  |  |  |  |  |  |  |
| Total | $ | 180.1 |  |  | $ | (0.2) |  |  | $ | 52.0 |  |  | $ | — |  |  | $ | (0.2) |  |  |  |  |  |  |  |  |  |
| June 29, 2024: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. Agency securities | $ | 62.3 |  |  | $ | (0.3) |  |  | $ | 12.6 |  |  | $ | — |  |  | $ | (0.3) |  |  |  |  |  |  |  |  |  |
| Commercial paper | — |  |  | — |  |  | 28.6 |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | 133.7 |  |  | (0.5) |  |  | 90.6 |  |  | (0.2) |  |  | (0.7) |  |  |  |  |  |  |  |  |  |
| U.S. government bonds | 72.3 |  |  | (0.4) |  |  | 39.7 |  |  | (0.1) |  |  | (0.5) |  |  |  |  |  |  |  |  |  |
| Total | $ | 268.3 |  |  | $ | (1.2) |  |  | $ | 171.5 |  |  | $ | (0.3) |  |  | $ | (1.5) |  |  |  |  |  |  |  |  |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-02-06):
[0001628280-25-004288:note_history:35]
The future interest and principal payments related to our convertible notes are as follows as of December 28, 2024 (in millions):
  (was, 2024-11-08, similarity 0.9799):
[0001628280-24-046443:note_history:35]
The future interest and principal payments related to our convertible notes are as follows as of September 28, 2024 (in millions):


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-02-06):
[0001628280-25-004288:note_history:36]
|  | Three Months Ended |  | Six Months Ended |
|  | December 28, 2024 |  | December 30, 2023 |  | December 28, 2024 |  | December 30, 2023 |
|  | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |  | Amount |  | % of Total |
| Cloud & Networking | $ | 339.2 |  |  | 84.3 | % |  | 286.7 |  |  | 78.2 | % |  | $ | 621.5 |  |  | 84.1 | % |  | $ | 516.4 |  |  | 75.5 | % |
| Industrial Tech | 63.0 |  |  | 15.7 | % |  | 80.1 |  |  | 21.8 | % |  | 117.6 |  |  | 15.9 | % |  | 168.0 |  |  | 24.5 | % |
| Net revenue | $ | 402.2 |  |  | 100.0 | % |  | $ | 366.8 |  |  | 100.0 | % |  | $ | 739.1 |  |  | 100.0 | % |  | $ | 684.4 |  |  | 100.0 | % |
  (was, 2024-11-08, similarity 0.6569):
[0001628280-24-046443:note_history:36]
|  | Three Months Ended |  |  |
|  | September 28, 2024 |  | September 30, 2023 |  |  |  |  |
|  | Amount |  | % of Total |  | Amount |  | % of Total |  |  |  |  |  |  |  |  |
| Cloud & Networking | $ | 282.3 |  |  | 83.8 | % |  | 229.7 |  |  | 72.3 | % |  |  |  |  |  |  |  |  |
| Industrial Tech | 54.6 |  |  | 16.2 | % |  | 87.9 |  |  | 27.7 | % |  |  |  |  |  |  |  |  |
| Net revenue | $ | 336.9 |  |  | 100.0 | % |  | $ | 317.6 |  |  | 100.0 | % |  |  |  |  |  |  |  |  |

- added (2025-02-06):
[0001628280-25-004288:note_history:37]
| Contract balances |  | Balance sheet location |  | December 28, 2024 |  | June 29, 2024 |  | Change |  | Percentage Change |
| Accounts receivable, net |  | Accounts receivable, net |  | $ | 226.9 |  |  | $ | 194.7 |  |  | $ | 32.2 |  |  | 16.5 | % |
| Deferred revenue and customer deposits |  | Other current liabilities |  | $ | 0.7 |  |  | $ | 0.6 |  |  | $ | 0.1 |  |  | 16.7 | % |

- removed (2025-02-06):
[0001628280-24-046443:note_history:38]
| Contract balances |  | Balance sheet location |  | September 28, 2024 |  | June 29, 2024 |  | Change |  | Percentage Change |
| Accounts receivable, net |  | Accounts receivable, net |  | $ | 198.5 |  |  | $ | 194.7 |  |  | $ | 3.8 |  |  | 2.0 | % |
| Deferred revenue and customer deposits |  | Other current liabilities |  | $ | 0.6 |  |  | $ | 0.6 |  |  | $ | — |  |  | — | % |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2025-02-06):
[0001628280-25-004288:note_history:39]
Note 17. Subsequent Event

- added (2025-02-06):
[0001628280-25-004288:note_history:40]
On February 3, 2025, the Company announced that the Company’s board of directors (the “Board) had appointed Michael Hurlston as President and Chief Executive Officer (“CEO”) of the Company, effective February 7, 2025. Mr. Hurlston will succeed Alan Lowe, the Company’s President and CEO, who is stepping down and retiring as President and CEO effective as of the end of day February 6, 2025. Mr. Lowe will remain on the Board until the end of the Company’s fiscal year 2025 and will serve as an advisor to the Company until December 15, 2025. Mr. Hurlston has also been appointed to the Board effective as of February 7, 2025.
