# CARR MD&A — 0001783180-22-000034


## mdna

[0001783180-22-000034:mdna:1]
[same as prior period, unchanged from 0001783180-21-000065:mdna:1]

[0001783180-22-000034:mdna:2]
[same as prior period, unchanged from 0001783180-21-000065:mdna:2]

[0001783180-22-000034:mdna:3]
[same as prior period, unchanged from 0001783180-21-000065:mdna:3]

[0001783180-22-000034:mdna:4]
Carrier is a leading global provider of healthy, safe, sustainable and intelligent building and cold chain solutions. Our portfolio includes industry-leading brands such as Carrier, Automated Logic, Carrier Transicold, Kidde, Edwards and LenelS2 that offer innovative HVAC, refrigeration, fire, security and building automation technologies to help make the world safer and more comfortable. We also provide a broad array of related building services, including audit, design, installation, system integration, repair, maintenance and monitoring. Our operations are classified into three segments: HVAC, Refrigeration and Fire & Security.

[0001783180-22-000034:mdna:5]
[same as prior period, unchanged from 0001783180-21-000065:mdna:5]

[0001783180-22-000034:mdna:6]
[same as prior period, unchanged from 0001783180-21-000065:mdna:6]

[0001783180-22-000034:mdna:7]
[same as prior period, unchanged from 0001783180-21-000065:mdna:7]

[0001783180-22-000034:mdna:8]
Russia's Invasion of Ukraine

[0001783180-22-000034:mdna:9]
In February 2022, Russian forces launched a military action against Ukraine. As a result, the European Union, United States, the United Kingdom and other countries have imposed sanctions that have increased global economic and political uncertainty. We operate in Russia through a Russia-based subsidiary and a joint venture which represent less than 1% of our total assets and revenue. On March 10, 2022, we announced that we were suspending business operations in Russia. We will honor existing contractual obligations, where possible, in a manner that fully complies with all sanctions and trade controls that have been imposed, but we will not pursue new business opportunities. While neither Russia nor Ukraine constitute a material portion of our business, the conflict could lead to disruption, instability and volatility in global markets and industries that could negatively impact our results of operations. We continue to monitor the evolving impacts of this conflict and its effect on the global economy and geopolitical landscape.

[0001783180-22-000034:mdna:10]
[same as prior period, unchanged from 0001783180-21-000065:mdna:8]

[0001783180-22-000034:mdna:11]
[same as prior period, unchanged from 0001783180-21-000065:mdna:9]

[0001783180-22-000034:mdna:12]
[same as prior period, unchanged from 0001783180-21-000065:mdna:10]

[0001783180-22-000034:mdna:13]
[same as prior period, unchanged from 0001783180-21-000065:mdna:11]

[0001783180-22-000034:mdna:14]
On January 3, 2022, we completed the Chubb Sale for net proceeds of $2.9 billion. Chubb, reported within our Fire & Security segment, delivers essential fire safety and security solutions from design and installation to monitoring, service and

[0001783180-22-000034:mdna:15]
maintenance across more than 17 countries around the globe. We recognized a gain on the sale of $1.1 billion which is subject to working capital and other adjustments as provided in the sale agreement.

[0001783180-22-000034:mdna:16]
[same as prior period, unchanged from 0001783180-21-000065:mdna:17]

[0001783180-22-000034:mdna:17]
In early 2020, the World Health Organization declared the outbreak of a respiratory disease known as COVID-19 as a global pandemic. In response, many countries implemented containment and mitigation measures to combat the outbreak, which severely restricted the level of economic activity and caused a significant contraction in the global economy. As a result, we took several preemptive actions to manage liquidity, preserve the health and safety of our employees and customers as well as maintain the continuity of our operations. The preparation of financial statements requires management to use judgments in making estimates and assumptions based on the relevant information available at the end of each period, which can have a significant effect on reported amounts. However, due to significant uncertainty surrounding the pandemic, including a resurgence in cases and the spread of COVID-19 variants, management's judgments could change. While our results of operations, cash flows and financial condition could be negatively impacted, the extent of any continuing impact cannot be estimated with certainty at this time.

[0001783180-22-000034:mdna:18]
[same as prior period, unchanged from 0001783180-21-000065:mdna:20]

[0001783180-22-000034:mdna:19]
Preparation of our financial statements requires management to make estimates and assumptions that affect the reported amounts of assets, liabilities, sales and expenses. We believe that the most complex and sensitive judgments, because of their potential significance to the Unaudited Condensed Consolidated Financial Statements, result primarily from the need to make estimates about the effects of matters that are inherently uncertain. In "Management’s Discussion and Analysis of Financial Condition and Results of Operations" of our 2021 Form 10-K, we describe the significant accounting estimates and policies used in the preparation of the Unaudited Condensed Consolidated Financial Statements. There have been no significant changes in our critical accounting estimates.

[0001783180-22-000034:mdna:20]
[same as prior period, unchanged from 0001783180-21-000065:mdna:23]

[0001783180-22-000034:mdna:21]
Three Months Ended March 31, 2022 Compared with the Three Months Ended March 31, 2021

[0001783180-22-000034:mdna:22]
As a result of the Chubb Sale, we do not beneficially own any shares of Chubb common stock and no longer consolidate Chubb in our financial statements as of January 3, 2022. Therefore, this Management’s Discussion and Analysis of Financial Condition and Results of Operations only includes the financial results of Chubb in periods prior to the date of sale. As a result, prior period results may not be comparable to the current period. See Note 16 - Divestitures in the Notes to the Unaudited Condensed Consolidated Financial Statements for additional information.

[0001783180-22-000034:mdna:23]
The following represents our consolidated net sales and operating results:

[0001783180-22-000034:mdna:24]
|  |  | For the Three Months Ended March 31, |  |  |  |  |  |  |
| (In millions) |  | 2022 |  | 2021 |  | Period Change |  | % Change |  |  |  |  |  |  |
| Net sales |  | $ | 4,654 |  |  | $ | 4,699 |  |  | $ | (45) |  |  | (1) | % |  |  |  |  |  |  |
| Cost of products and services sold |  | (3,361) |  |  | (3,305) |  |  | (56) |  |  | 2 | % |  |  |  |  |  |  |
| Gross margin |  | 1,293 |  |  | 1,394 |  |  | (101) |  |  | (7) | % |  |  |  |  |  |  |
| Operating expenses |  | 444 |  |  | (823) |  |  | 1,267 |  |  | (154) | % |  |  |  |  |  |  |
| Operating profit |  | 1,737 |  |  | 571 |  |  | 1,166 |  |  | 204 | % |  |  |  |  |  |  |
| Non-operating income (expenses), net |  | (49) |  |  | (75) |  |  | 26 |  |  | (35) | % |  |  |  |  |  |  |
| Income from operations before income taxes |  | 1,688 |  |  | 496 |  |  | 1,192 |  |  | 240 | % |  |  |  |  |  |  |
| Income tax expense |  | (301) |  |  | (104) |  |  | (197) |  |  | 189 | % |  |  |  |  |  |  |
| Net income from operations |  | 1,387 |  |  | 392 |  |  | 995 |  |  | 254 | % |  |  |  |  |  |  |
| Less: Non-controlling interest in subsidiaries' earnings from operations |  | 8 |  |  | 8 |  |  | — |  |  | — | % |  |  |  |  |  |  |
| Net income attributable to common shareowners |  | $ | 1,379 |  |  | $ | 384 |  |  | $ | 995 |  |  | 259 | % |  |  |  |  |  |  |

[0001783180-22-000034:mdna:25]
26

[0001783180-22-000034:mdna:26]
[same as prior period, unchanged from 0001783180-21-000065:mdna:26]

[0001783180-22-000034:mdna:27]
For the three months ended March 31, 2022, Net sales were $4.7 billion, a 1% decrease compared with the same period of 2021. The components of the year-over-year change were as follows:

[0001783180-22-000034:mdna:28]
|  |  |  |  | For the Three Months Ended March 31, 2022 |  |  |  |  |
| Organic |  |  |  | 10 | % |  |  |  |  |
| Foreign currency translation |  |  |  | (1) | % |  |  |  |  |
| Acquisitions and divestitures, net |  |  |  | (10) | % |  |  |  |  |
| Total % change |  |  |  | (1) | % |  |  |  |  |

[0001783180-22-000034:mdna:29]
We continue to benefit from strong demand for energy-efficient, digitalized products and healthy building solutions. During the three months ended March 31, 2022, pricing improvements and higher volumes increased organic sales by 10% compared with the same period of 2021. The organic increase was primarily driven by our HVAC segment with continued strong demand in our North America residential and light commercial business and improved global end-markets in our Commercial HVAC business. Pricing improvements in our Fire & Security segment were the primary driver of growth compared with the prior year while supply chain and logistic constraints continue to be challenging. Refrigeration results were flat as certain supply chain and logistic constraints impacted sales. Refer to "Segment Review" below for a discussion of Net sales by segment.

[0001783180-22-000034:mdna:30]
[same as prior period, unchanged from 0001783180-21-000065:mdna:30]

[0001783180-22-000034:mdna:31]
For the three months ended March 31, 2022, gross margin was $1.3 billion, a 7% decrease compared with the same period of 2021. The components were as follows:

[0001783180-22-000034:mdna:32]
|  |  |  |  | For the Three Months Ended March 31, |  |  |  |  |
| (In millions) |  |  |  |  |  | 2022 |  | 2021 |  |  |  |  |
| Net sales |  |  |  |  |  | $ | 4,654 |  |  | $ | 4,699 |  |  |  |  |  |
| Cost of products and services sold |  |  |  |  |  | (3,361) |  |  | (3,305) |  |  |  |  |  |
| Gross margin |  |  |  |  |  | $ | 1,293 |  |  | $ | 1,394 |  |  |  |  |  |
| Percentage of net sales |  |  |  |  |  | 27.8 | % |  | 29.7 | % |  |  |  |  |

[0001783180-22-000034:mdna:33]
The decrease in gross margin was primarily driven by the Chubb Sale which contributed $170 million of gross margin during the three months ended March 31, 2021. In addition, each of our segments continued to be impacted by the rising cost for commodities and components used in our products, certain supply chain constraints and higher freight costs. These impacts were offset by strong demand, price improvements and our continued focus on productivity initiatives. As a result, gross margin as a percentage of Net sales decreased by 190 basis points compared with the same period of 2021, which included a 20 basis point impact on gross margin as a percentage of Net sales due to the Chubb Sale.

[0001783180-22-000034:mdna:34]
[same as prior period, unchanged from 0001783180-21-000065:mdna:34]

[0001783180-22-000034:mdna:35]
For the three months ended March 31, 2022, operating expenses, including Equity method investment net earnings, were $444 million, a 154% decrease compared with the same period of 2021. The components were as follows:

[0001783180-22-000034:mdna:36]
|  |  |  |  | For the Three Months Ended March 31, |  |  |  |  |
| (In millions) |  |  |  |  |  | 2022 |  | 2021 |  |  |  |  |
| Selling, general and administrative |  |  |  |  |  | $ | (601) |  |  | $ | (743) |  |  |  |  |  |
| Research and development |  |  |  |  |  | (125) |  |  | (121) |  |  |  |  |  |
| Equity method investment net earnings |  |  |  |  |  | 58 |  |  | 38 |  |  |  |  |  |
| Other income (expense), net |  |  |  |  |  | 1,112 |  |  | 3 |  |  |  |  |  |
| Total operating expenses |  |  |  |  |  | $ | 444 |  |  | $ | (823) |  |  |  |  |  |
| Percentage of net sales |  |  |  |  |  | (9.5) | % |  | 17.5 | % |  |  |  |  |

[0001783180-22-000034:mdna:37]
For the three months ended March 31, 2022, Selling, general and administrative expenses were $601 million, a 19% decrease

[0001783180-22-000034:mdna:38]
compared with the same period of 2021. The decrease is primarily due to the Chubb Sale on January 3, 2022. In addition, lower restructuring charges and the benefit provided by changes in the fair value of cash-settled equity awards further contributed to the decrease. In addition, the three months ended March 31, 2021 included $16 million of costs related to the Separation.

[0001783180-22-000034:mdna:39]
[same as prior period, unchanged from 0001783180-21-000065:mdna:38]

[0001783180-22-000034:mdna:40]
Investments over which we do not exercise control, but have significant influence, are accounted for using the equity method of accounting. For the three months ended March 31, 2022, Equity method investment net earnings were $58 million, a 53% increase compared with the same period of 2021. The increase was primarily related to higher earnings in HVAC joint ventures in Asia and North America.

[0001783180-22-000034:mdna:41]
Other income (expense), net primarily includes the impact of gains and losses related to the sale of businesses or interests in our equity method investments, foreign currency gains and losses on transactions that are denominated in a currency other than an entity's functional currency and hedging-related activities. During the three months ended March 31, 2022, we completed the Chubb Sale and recognized a net gain on the sale of $1.1 billion.

[0001783180-22-000034:mdna:42]
[same as prior period, unchanged from 0001783180-21-000065:mdna:41]

[0001783180-22-000034:mdna:43]
For the three months ended March 31, 2022, Non-operating income (expenses), net were $49 million, a 35% increase compared with the same period of 2021. The components were as follows:

[0001783180-22-000034:mdna:44]
|  |  |  |  | For the Three Months Ended March 31, |
| (In millions) |  |  |  |  |  | 2022 |  | 2021 |
| Non-service pension (expense) benefit |  |  |  |  |  | $ | (1) |  |  | $ | 18 |  |
| Interest expense |  |  |  |  |  | $ | (87) |  |  | $ | (96) |  |
| Interest income |  |  |  |  |  | 39 |  |  | 3 |  |
| Interest (expense) income, net |  |  |  |  |  | $ | (48) |  |  | $ | (93) |  |
| Non-operating income (expenses), net |  |  |  |  |  | $ | (49) |  |  | $ | (75) |  |

[0001783180-22-000034:mdna:45]
Non-operating income (expenses), net includes the results from activities other than normal business operations such as interest expense, interest income and the non-service components of pension and post-retirement obligations. For the three months ended March 31, 2022, Interest expense was $87 million, a 9% decrease compared with the same period of 2021. During the three months ended March 31, 2022, we completed tender offers to repurchase approximately $1.15 billion aggregate principal of our 2.242% Notes due 2025 and 2.493% Notes due 2027. Upon settlement, we wrote off $5 million of unamortized deferred financing costs in Interest expense and recognized a net gain of $33 million in Interest income. During the three months ended March 31, 2021, we incurred a make-whole premium of $17 million and wrote-off $2 million of unamortized deferred financing costs in Interest expense as a result of the redemption of our $500 million 1.923% Notes originally due in February 2023.

[0001783180-22-000034:mdna:46]
[same as prior period, unchanged from 0001783180-21-000065:mdna:45]

[0001783180-22-000034:mdna:47]
|  |  |  | For the Three Months Ended March 31, |  |  |
|  |  |  |  |  | 2022 |  | 2021 |  |  |  |  |
| Effective tax rate |  |  |  |  | 17.8 | % |  | 21.0 | % |  |  |  |  |

[0001783180-22-000034:mdna:48]
The Company accounts for income tax expense in accordance with ASC 740, which requires an estimate of the annual effective income tax rate for the full year to be applied to the respective interim period, taking into account year-to-date amounts and projected results for the full year. The effective tax rate was 17.8% for the three months ended March 31, 2022 compared with 21.0% for the three months ended March 31, 2021. The year-over-year decrease was primarily driven by a lower effective tax rate on the Chubb gain compared with our U.S. statutory rate and a favorable tax adjustment of $32 million associated with

[0001783180-22-000034:mdna:49]
foreign tax credits generated and expected to be utilized in the current year. The three months ended March 31, 2021 included a favorable tax adjustment of $21 million resulting from the re-organization of a German subsidiary.

[0001783180-22-000034:mdna:50]
[same as prior period, unchanged from 0001783180-21-000065:mdna:74]

[0001783180-22-000034:mdna:51]
Three Months Ended March 31, 2022 Compared with Three Months Ended March 31, 2021

[0001783180-22-000034:mdna:52]
| Summary performance for each of our segments is as follows: |
|  | Net Sales |  | Operating Profit |  | Operating Profit Margin |
|  | For the Three Months Ended March 31, |  | For the Three Months Ended March 31, |  | For the Three Months Ended March 31, |
| (In millions) | 2022 |  | 2021 |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| HVAC | $ | 2,970 |  |  | $ | 2,486 |  |  | $ | 470 |  |  | $ | 365 |  |  | 15.8 | % |  | 14.7 | % |
| Refrigeration | 976 |  |  | 1,005 |  |  | 107 |  |  | 127 |  |  | 11.0 | % |  | 12.6 | % |
| Fire & Security | 818 |  |  | 1,304 |  |  | 1,218 |  |  | 150 |  |  | 148.9 | % |  | 11.5 | % |
| Total segment | $ | 4,764 |  |  | $ | 4,795 |  |  | $ | 1,795 |  |  | $ | 642 |  |  | 37.7 | % |  | 13.4 | % |

[0001783180-22-000034:mdna:53]
[same as prior period, unchanged from 0001783180-21-000065:mdna:84]

[0001783180-22-000034:mdna:54]
For the three months ended March 31, 2022, Net sales in our HVAC segment were $3.0 billion, a 19% increase compared with the same period of 2021. The components of the year-over-year change were as follows:

[0001783180-22-000034:mdna:55]
|  |  | Net Sales |
| Organic |  | 18 | % |
| Foreign currency translation |  | (2) | % |
| Acquisitions and divestitures, net |  | 3 | % |
| Total % change in Net sales |  | 19 | % |

[0001783180-22-000034:mdna:56]
The organic increase in Net sales of 18% was driven by strong results across each of the segment's businesses compared with the prior year. Increased sales in our North America residential and light commercial business (26%) were driven by pricing improvements and strong end-market demand. Increased sales in our Commercial HVAC business (9%) benefited from pricing improvements and ongoing customer demand as our end-markets continue to improve from the COVID-19 pandemic. The business saw growth in each region, although sales in China were tempered by additional restrictions as a result of a resurgence of COVID-19 cases. While current demand remains strong, supply chain and logistics constraints continue to be challenging, negatively impacting our sales and results of operations. In addition, results for 2021 reflected a significant rebound in demand after initial weakness associated with the COVID-19 pandemic.

[0001783180-22-000034:mdna:57]
On June 1, 2021, the Commercial HVAC business acquired a 70% controlling stake in Guangdong Giwee Group and its subsidiaries ("Giwee") and subsequently acquired the remaining 30% ownership interest on September 7, 2021. Giwee is a China-based manufacturer offering a portfolio of HVAC products including variable refrigerant flow, modular chillers and light commercial air conditioners. The results of Giwee has been included in our Unaudited Condensed Consolidated Financial Statements since the date of acquisition. The transaction added 2% to Net sales during the three months ended March 31, 2022.

[0001783180-22-000034:mdna:58]
For the three months ended March 31, 2022, Operating profit in our HVAC segment was $470 million, a 29% increase compared with the same period of 2021. The components of the year-over-year change were as follows:

[0001783180-22-000034:mdna:59]
|  |  |  | Operating Profit |
| Operational |  |  | 30 | % |
| Acquisitions and divestitures, net |  |  | (1) | % |
| Total % change in Operating profit |  |  | 29 | % |

[0001783180-22-000034:mdna:60]
The operational profit increase of 30% was primarily attributable to pricing improvements and higher sales volumes compared with the prior year. Higher earnings from equity method investments in North America and Asia also benefited operational profit. These amounts were partially offset by higher costs for commodities and components used in our products and higher freight and logistic costs. In addition, higher selling, general and administrative costs further impacted operating profit.

[0001783180-22-000034:mdna:61]
[same as prior period, unchanged from 0001783180-21-000065:mdna:22]

[0001783180-22-000034:mdna:62]
[same as prior period, unchanged from 0001783180-21-000065:mdna:94]

[0001783180-22-000034:mdna:63]
For the three months ended March 31, 2022, Net sales in our Refrigeration segment were $976 million, a 3% decrease compared with the same period of 2021. The components of the year-over-year change were as follows:

[0001783180-22-000034:mdna:64]
|  |  | Net Sales |
| Organic |  | 1 | % |
| Foreign currency translation |  | (4) | % |
| Total % change in Net sales |  | (3) | % |

[0001783180-22-000034:mdna:65]
Organic sales increased 1% during the three months ended March 31, 2022 compared with the prior year. Commercial refrigeration sales increased (5%) primarily due to pricing improvements and strong demand. These amounts were partially offset by continued supply chain constraints. Transport refrigeration sales decreased (1%) compared with the prior year. The three months ended March 31, 2021 reflected a significant rebound in demand associated with the cyclical decline that began in late 2019 as well as the demand for global transportation and COVID-19 vaccine-related cargo monitoring. While current demand remains strong, supply chain and logistics constraints continue to be challenging, negatively impacting our sales and results of operations.

[0001783180-22-000034:mdna:66]
For the three months ended March 31, 2022, Operating profit in our Refrigeration segment was $107 million, a 16% decrease compared with the same period of 2021. The components of the year-over-year change were as follows:

[0001783180-22-000034:mdna:67]
|  |  |  | Operating Profit |
| Operational |  |  | (10) | % |
| Foreign currency translation |  |  | (4) | % |
| Restructuring |  |  | 2 | % |
| Other |  |  | (4) | % |
| Total % change in Operating profit |  |  | (16) | % |

[0001783180-22-000034:mdna:68]
The decrease in operational profit of 10% was primarily attributable to higher costs for commodities and components used in our products and higher freight and logistic costs compared with the prior year. These amounts were partially offset by pricing improvements and favorable productivity initiatives that benefited factory costs. Higher selling costs and research and development activities further impacted operational profit as the segment had incremental investments in expanding its sales force and product development.

[0001783180-22-000034:mdna:69]
[same as prior period, unchanged from 0001783180-21-000065:mdna:102]

[0001783180-22-000034:mdna:70]
For the three months ended March 31, 2022, Net sales in our Fire & Security segment were $818 million, a 37% decrease compared with the same period of 2021. The components of the year-over-year change were as follows:

[0001783180-22-000034:mdna:71]
|  |  | Net Sales |
| Organic |  | 4 | % |
| Foreign currency translation |  | (1) | % |
| Acquisitions and divestitures, net |  | (40) | % |
| Total % change in Net sales |  | (37) | % |

[0001783180-22-000034:mdna:72]
The organic increase in Net sales of 4% was primarily driven by pricing improvements and continued strong demand across our businesses. The segment primarily saw growth in Europe and the Americas as sales in Asia were tempered by additional restrictions as a result of a resurgence of COVID-19 cases. While current demand remains strong, supply chain constraints continue to be challenging, negatively impacting our sales and results of operations.

[0001783180-22-000034:mdna:73]
Acquisitions and divestitures, net primarily relates to the Chubb Sale completed on January 3, 2022. During the three months ended March 31, 2021, Net sales in our Fire & Security segment were $1.3 billion, which included $548 million from our Chubb business. Absent the results of Chubb, Net sales increased 8% from $755 million to $818 million.

[0001783180-22-000034:mdna:74]
30

[0001783180-22-000034:mdna:75]
For the three months ended March 31, 2022, Operating profit in our Fire & Security segment was $1.2 billion, a 712% increase compared with the same period of 2021. The components of the year-over-year change were as follows:

[0001783180-22-000034:mdna:76]
|  |  |  | Operating Profit |
| Operational |  |  | (7) | % |
| Acquisitions and divestitures, net |  |  | (25) | % |
| Restructuring |  |  | 3 | % |
| Other |  |  | 741 | % |
| Total % change in Operating profit |  |  | 712 | % |

[0001783180-22-000034:mdna:77]
The decrease in operational profit of 7% was primarily attributable to higher costs for commodities and components used in our products and higher freight and logistics costs. In addition, unfavorable mix further impacted results compared with the prior year. These amounts were partially offset by pricing improvements.

[0001783180-22-000034:mdna:78]
Amounts reported in Other represent the net gain on the Chubb Sale of $1.1 billion completed on January 3, 2022. The gain was partially offset by transaction costs associated with this divestiture.

[0001783180-22-000034:mdna:79]
[same as prior period, unchanged from 0001783180-21-000065:mdna:139]

[0001783180-22-000034:mdna:80]
[same as prior period, unchanged from 0001783180-21-000065:mdna:140]

[0001783180-22-000034:mdna:81]
As of March 31, 2022, we had cash and cash equivalents of $3.6 billion, of which approximately 23% was held by our foreign subsidiaries. We manage our worldwide cash requirements by reviewing available funds and the cost effectiveness with which we can access funds held by foreign subsidiaries. On occasion, we are required to maintain cash deposits in connection with contractual obligations related to acquisitions, divestitures or other legal obligations. As of March 31, 2022 and December 31, 2021, the amount of such restricted cash was approximately $18 million and $39 million, respectively.

[0001783180-22-000034:mdna:82]
We maintain a $2.0 billion unsecured, unsubordinated commercial paper program which can be used for general corporate purposes, including working capital and potential acquisitions. In addition, we maintain our $2.0 billion Revolving Credit Facility that matures on April 3, 2025 which supports our commercial paper borrowing program and cash requirements. The Revolving Credit Facility has a commitment fee of 0.125% that is charged on unused commitments. Borrowings under the Revolving Credit Facility are available in U.S. Dollars, Euros and Pounds Sterling and bear interest at a variable interest rate plus a ratings-based margin, which was 125 basis points as of March 31, 2022. As of March 31, 2022, we had no borrowings outstanding under our commercial paper program and our Revolving Credit Facility.

[0001783180-22-000034:mdna:83]
We continue to actively manage and strengthen our business portfolio to meet the current and future needs of our customers. This is accomplished through research and development activities with a focus on new product development and new technology innovation as well as sustaining activities with a focus on improving existing products and reducing production costs. We also pursue potential acquisitions to complement existing products and services to enhance our product portfolio. In addition, we routinely conduct discussions, evaluate targets and enter into agreements regarding possible acquisitions, divestitures, joint ventures and equity investments to manage our business portfolio.

[0001783180-22-000034:mdna:84]
[same as prior period, unchanged from 0001783180-21-000065:mdna:144]

[0001783180-22-000034:mdna:85]
The Revolving Credit Facility and the indentures for the Long-term notes contain affirmative and negative covenants customary for financings of these types, which among other things, limit our ability to incur additional liens, to make certain fundamental changes and to enter into sale and leaseback transactions. As of March 31, 2022, we were in compliance with the covenants under the agreements governing our outstanding indebtedness.

[0001783180-22-000034:mdna:86]
The following table presents our credit ratings and outlook as of March 31, 2022:

[0001783180-22-000034:mdna:87]
[same as prior period, unchanged from 0001783180-21-000065:mdna:147]

[0001783180-22-000034:mdna:88]
(1) The long-term rating for S&P was affirmed on May 14, 2021, and for Moody's on March 30, 2022. Fitch's long-term rating was affirmed on June 3, 2021.

[0001783180-22-000034:mdna:89]
(2) S&P revised its outlook to stable from negative on May 14, 2021.

[0001783180-22-000034:mdna:90]
[same as prior period, unchanged from 0001783180-21-000065:mdna:150]

[0001783180-22-000034:mdna:91]
| (In millions) |  | March 31,2022 |  | December 31,2021 |
| Cash and cash equivalents |  | $ | 3,604 |  |  | $ | 2,987 |  |
| Total debt |  | $ | 8,561 |  |  | $ | 9,696 |  |
| Total equity |  | $ | 7,430 |  |  | $ | 7,094 |  |
| Net debt (total debt less cash and cash equivalents) |  | $ | 4,957 |  |  | $ | 6,709 |  |
| Total capitalization (total debt plus total equity) |  | $ | 15,991 |  |  | $ | 16,790 |  |
| Net capitalization (total debt plus total equity less cash and cash equivalents) |  | $ | 12,387 |  |  | $ | 13,803 |  |
| Total debt to total capitalization |  | 54 | % |  | 58 | % |
| Net debt to net capitalization |  | 40 | % |  | 49 | % |

[0001783180-22-000034:mdna:92]
Borrowings and Lines of Credit

[0001783180-22-000034:mdna:93]
Our short-term obligations primarily consist of current maturities of long-term debt. Our long-term obligations primarily consist of long-term notes with maturity dates ranging between 2025 and 2050. Interest payments related to Long-term Notes are expected to approximate $247 million per year, reflecting an approximate weighted-average interest rate of 2.95%. Any borrowings from the Revolving Credit Facility are subject to variable interest rates. See Note 5 – Borrowings and Lines of Credit in the Notes to the Unaudited Condensed Consolidated Financial Statements for additional information regarding the terms of our long-term debt obligations.

[0001783180-22-000034:mdna:94]
On March 15, 2022, we commenced tender offers to repurchase up to $1.15 billion aggregate principal of our 2.242% Notes due 2025 and 2.493% Notes due 2027. The tender offers included payment of applicable accrued and unpaid interest up to the settlement date, along with a fixed spread for early repayment. Based on participation, we elected to settle the tender offers on March 30, 2022. The aggregate principal amount of Senior Notes validly tendered and accepted was approximately $1.15 billion and included $800 million of Notes due 2025 and $350 million of Notes due 2027. Upon settlement, we recognized a net gain of $33 million and wrote off $5 million of unamortized deferred financing costs.

[0001783180-22-000034:mdna:95]
Acquisitions and Divestitures

[0001783180-22-000034:mdna:96]
On January 3, 2022, we completed the Chubb Sale for net proceeds of $2.9 billion, subject to customary working capital and other adjustments. Consistent with our capital allocation strategy, the net proceeds will be used to fund investments in organic and inorganic growth initiatives and capital returns to shareowners as well as for general corporate purposes.

[0001783180-22-000034:mdna:97]
During the three months ended March 31, 2022, we acquired consolidated businesses and minority-owned businesses. The aggregate cash paid for acquisitions, net of cash acquired, totaled $9 million and was funded through cash on hand. See Note 15 – Acquisitions for additional information.

[0001783180-22-000034:mdna:98]
On February 6, 2022, we entered into a binding agreement to acquire a majority ownership stake in TCC for approximately $900 million. The transaction is expected to close by the end of the third quarter of 2022, subject to customary closing conditions, including regulatory approvals. Upon closing, Toshiba Corporation will retain a 5% ownership interest in TCC. The acquisition is expected to be funded through a combination of cash on hand and a $400 million Yen denominated term loan.

[0001783180-22-000034:mdna:99]
Share Repurchase Program

[0001783180-22-000034:mdna:100]
On July 27, 2021, our Board of Directors approved a share repurchase program authorizing the repurchase of up to $2.1 billion of our outstanding common stock. The share repurchase program allows us to repurchase shares from time to time subject to market conditions and at our discretion in the open market or through one or more other public or private transactions and subject to compliance with certain tax obligations.

[0001783180-22-000034:mdna:101]
On December 14, 2021, we entered into the ASR Agreement to repurchase $500 million of our common stock pursuant to our existing share repurchase program. In accordance with the ASR Agreement, we received initial delivery of 7.6 million shares on January 4, 2022, representing approximately 80% of the expected share repurchases. The final number of shares under the ASR Agreement was based on the daily average of the volume-weighted average share price of our common stock over the term of the ASR Agreement. Upon final settlement, we received an additional 2.7 million shares on February 8, 2022 and recognized $500 million in Treasury stock as a reduction in equity.

[0001783180-22-000034:mdna:102]
During the three months ended March 31, 2022, we repurchased 15.7 million shares of our common stock which included shares repurchased under the ASR Agreement. The total aggregate purchase price was $741 million. Shares repurchased are held in Treasury stock in the Unaudited Condensed Consolidated Balance Sheet.

[0001783180-22-000034:mdna:103]
Dividends

[0001783180-22-000034:mdna:104]
We paid dividends on common stock during the three months ended March 31, 2022, totaling $129 million. On April 14, 2022, the Board of Directors declared a dividend of $0.15 per share of common stock payable on May 19, 2022 to shareowners of record at the close of business on April 29, 2022.

[0001783180-22-000034:mdna:105]
Discussion of Cash Flows

[0001783180-22-000034:mdna:106]
|  |  | For the Three Months Ended March 31, |
| (In millions) |  | 2022 |  | 2021 |
| Net cash flows provided by (used in): |  |  |  |  |
| Operating activities |  | $ | (202) |  |  | $ | 184 |  |
| Investing activities |  | 2,820 |  |  | (49) |  |
| Financing activities |  | (2,020) |  |  | (643) |  |
| Effect of foreign exchange rate changes on cash and cash equivalents |  | (1) |  |  | (9) |  |
| Net increase (decrease) in cash and cash equivalents and restricted cash |  | $ | 597 |  |  | $ | (517) |  |

[0001783180-22-000034:mdna:107]
Cash flows from operating activities primarily represent inflows and outflows associated with our operations. Primary activities include net income from operations adjusted for non-cash transactions, working capital changes and changes in other assets and liabilities. The year-over-year decrease in net cash provided by operating activities was primarily driven by higher working capital balances during the current period. Continued strong demand and an increase of safety stock due to supply chain constraints led to higher inventory balances. In addition, higher accounts receivable balances due to increased sales more than offset higher accounts payable balances.

[0001783180-22-000034:mdna:108]
Cash flows from investing activities primarily represent inflows and outflows associated with long-term assets. Primary activities include capital expenditures, acquisitions, divestitures and proceeds from the sale of fixed assets. During the three months ended March 31, 2022, net cash provided by investing activities was $2.8 billion. The primary driver of the inflow related to the net proceeds from the Chubb Sale. This amount was partially offset by the acquisition of several businesses and minority-owned businesses, which totaled $9 million, net of cash acquired and $56 million of capital expenditures. During the three months ended March 31, 2021, net cash provided by investing activities was $49 million. The primary driver of the outflow related to capital expenditures of $53 million. This amount was partially offset by the settlement of derivative contracts of $8 million.

[0001783180-22-000034:mdna:109]
Cash flows from financing activities primarily represent inflows and outflows associated with equity or borrowings. During the three months ended March 31, 2022, net cash used in financing activities was $2.0 billion. The primary driver of the outflow related to the settlement of our tender offers for $1.15 billion. In addition, we paid $129 million in dividends to our common shareowners and paid $734 million to repurchase shares of our common stock. During the three months ended March 31, 2021, net cash used in financing activities was $643 million. The primary driver of the outflow related to the redemption of Long-term notes of $500 million. In addition, we paid $104 million in dividends to our common shareowners and paid $36 million to repurchase shares of our common stock.
