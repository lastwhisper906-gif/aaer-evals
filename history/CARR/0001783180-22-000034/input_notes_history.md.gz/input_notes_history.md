# CARR note change history — 0001783180-21-000065 → 0001783180-22-000034


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-04-28):
[0001783180-22-000034:note_history:1]
COMMITMENTS AND CONTINGENT LIABILITIES
The Company is involved in various litigation, claims and administrative proceedings, including those related to environmental and legal matters (including asbestos). In accordance with ASC 450, Contingencies, the Company records accruals for loss contingencies when it is probable that a liability will be incurred and the amount of the loss can be reasonably estimated. These accruals are generally based upon a range of possible outcomes. If no amount within the range is a better estimate than any other, the Company accrues the minimum amount. In addition, these estimates are reviewed periodically and adjusted to reflect additional information when it becomes available. The Company is unable to predict the final outcome of the following matters based on the information currently available, except as otherwise noted. However, the Company does not believe that the resolution of any of these matters will have a material adverse effect upon the Company's competitive position, results of operations, cash flows or financial condition.
  (was, 2021-10-28, similarity 0.9954):
[0001783180-21-000065:note_history:1]
COMMITMENTS AND CONTINGENT LIABILITIES
The Company is involved in various litigation, claims and administrative proceedings, including those related to environmental and legal matters (including asbestos). In accordance with ASC 450, Contingencies ("ASC 450"), the Company records accruals for loss contingencies when it is probable that a liability will be incurred and the amount of the loss can be reasonably estimated. These accruals are generally based upon a range of possible outcomes. If no amount within the range is a better estimate than any other, the Company accrues the minimum amount. In addition, these estimates are reviewed periodically and adjusted to reflect additional information when it becomes available. The Company is unable to predict the final outcome of the following matters based on the information currently available, except as otherwise noted. However, the Company does not believe that the resolution of any of these matters will have a material adverse effect upon the Company's competitive position, results of operations, cash flows or financial condition.

- changed (2022-04-28):
[0001783180-22-000034:note_history:2]
The Company’s operations are subject to environmental regulation by various authorities. The Company has accrued for the costs of environmental remediation activities, including but not limited to investigatory, remediation, operating and maintenance costs and performance guarantees. The most likely cost to be incurred is accrued based on an evaluation of currently available facts with respect to individual sites, including technology required to remediate, current laws and regulations and prior remediation experience.
  (was, 2021-10-28, similarity 0.6523):
[0001783180-21-000065:note_history:2]
The Company’s operations are subject to environmental regulation by various authorities. The Company has accrued for the costs of environmental remediation activities, including but not limited to investigatory, remediation, operating and maintenance costs and performance guarantees, and the Company periodically reassesses these amounts. Management believes

- changed (2022-04-28):
[0001783180-22-000034:note_history:3]
The outstanding liabilities for environmental obligations are as follows:
  (was, 2021-10-28, similarity 0.6058):
[0001783180-21-000065:note_history:3]
that the likelihood of incurring losses materially in excess of the amounts accrued is remote. The outstanding liabilities for environmental obligations are as follows:

- changed (2022-04-28):
[0001783180-22-000034:note_history:4]
| (In millions) |  | March 31,2022 |  | December 31, 2021 |
| Environmental reserves included in Accrued liabilities |  | $ | 29 |  |  | $ | 29 |  |
| Environmental reserves included in Other long-term liabilities |  | 189 |  |  | 191 |  |
| Total Environmental reserves |  | $ | 218 |  |  | $ | 220 |  |
  (was, 2021-10-28, similarity 0.9742):
[0001783180-21-000065:note_history:4]
| (In millions) |  | September 30,2021 |  | December 31, 2020 |
| Environmental reserves included in Accrued liabilities |  | $ | 19 |  |  | $ | 26 |  |
| Environmental reserves included in Other long-term liabilities |  | 202 |  |  | 213 |  |
| Total Environmental reserves |  | $ | 221 |  |  | $ | 239 |  |

- added (2022-04-28):
[0001783180-22-000034:note_history:5]
For sites with multiple responsible parties, the Company considers its likely proportionate share of the anticipated remediation costs and the ability of other parties to fulfill their obligations in establishing a provision for these costs. Accrued environmental liabilities are not reduced by potential insurance reimbursements and are undiscounted.

- added (2022-04-28):
[0001783180-22-000034:note_history:6]
The Company has been named as a defendant in lawsuits alleging personal injury as a result of exposure to asbestos allegedly integrated into certain Carrier products or business premises. While the Company has never manufactured asbestos and no longer incorporates it into any currently-manufactured products, certain products that the Company no longer manufactures

- changed (2022-04-28):
[0001783180-22-000034:note_history:7]
contained components incorporating asbestos. A substantial majority of these asbestos-related claims have been dismissed without payment or have been covered in full or in part by insurance or other forms of indemnity. Additional cases were litigated and settled without any insurance reimbursement. The amounts involved in asbestos-related claims were not material individually or in the aggregate in any period.
  (was, 2021-10-28, similarity 0.6047):
[0001783180-21-000065:note_history:7]
The Company and its consolidated subsidiaries have been named as defendants in lawsuits alleging personal injury as a result of exposure to asbestos allegedly integrated into certain Carrier products or business premises. While the Company has never manufactured asbestos and no longer incorporates it into any currently-manufactured products, certain products that the Company no longer manufactures contained components incorporating asbestos. A substantial majority of these asbestos-related claims have been dismissed without payment or have been covered in full or in part by insurance or other forms of indemnity. Additional cases were litigated and settled without any insurance reimbursement. The amounts involved in asbestos-related claims were not material individually or in the aggregate in any period.

- changed (2022-04-28):
[0001783180-22-000034:note_history:8]
The Company had asbestos liabilities and related insurance recoveries as follows:
  (was, 2021-10-28, similarity 0.9342):
[0001783180-21-000065:note_history:8]
The Company had asbestos liabilities and related recoveries as follows:

- changed (2022-04-28):
[0001783180-22-000034:note_history:9]
| (In millions) |  | March 31,2022 |  | December 31,2021 |
| Asbestos liabilities included in Accrued liabilities |  | $ | 17 |  |  | $ | 17 |  |
| Asbestos liabilities included in Other long-term liabilities |  | 219 |  |  | 220 |  |
| Total Asbestos liabilities |  | $ | 236 |  |  | $ | 237 |  |
| Asbestos-related recoveries included in Other assets, current |  | $ | 5 |  |  | $ | 5 |  |
| Asbestos-related recoveries included in Other assets |  | 92 |  |  | 93 |  |
| Total Asbestos-related recoveries |  | $ | 97 |  |  | $ | 98 |  |
  (was, 2021-10-28, similarity 0.9877):
[0001783180-21-000065:note_history:9]
| (In millions) |  | September 30,2021 |  | December 31,2020 |
| Asbestos liabilities included in Accrued liabilities |  | $ | 17 |  |  | $ | 17 |  |
| Asbestos liabilities included in Other long-term liabilities |  | 221 |  |  | 228 |  |
| Total Asbestos liabilities |  | $ | 238 |  |  | $ | 245 |  |
| Asbestos-related recoveries included in Other assets, current |  | $ | 5 |  |  | $ | 6 |  |
| Asbestos-related recoveries included in Other assets |  | 93 |  |  | 97 |  |
| Total Asbestos-related recoveries |  | $ | 98 |  |  | $ | 103 |  |

- changed (2022-04-28):
[0001783180-22-000034:note_history:10]
The amounts recorded for asbestos-related liabilities are based on currently available information and assumptions that the Company believes are reasonable and are made with input from outside actuarial experts. These amounts are undiscounted and exclude the Company’s legal fees to defend the asbestos claims, which are expensed as incurred. In addition, the Company has recorded insurance recovery receivables for probable asbestos-related recoveries.
  (was, 2021-10-28, similarity 0.9113):
[0001783180-21-000065:note_history:10]
The amounts recorded for asbestos-related liabilities are based on currently available information and assumptions that the Company believes are reasonable and are made with input from outside actuarial experts. Where no amount within a range of estimates is more likely, the minimum is accrued. These amounts are undiscounted and exclude the Company’s legal fees to defend the asbestos claims, which are expensed as incurred. In addition, the Company has recorded an insurance recovery receivable for probable asbestos-related recoveries.

- changed (2022-04-28):
[0001783180-22-000034:note_history:11]
On August 12, 2020, several former employees of UTC or its subsidiaries filed a putative class action complaint (the "Complaint") in the United States District Court for the District of Connecticut against Raytheon Technologies Corporation, Carrier, Otis, the former members of the UTC Board of Directors and the members of the Carrier and Otis Boards of Directors (Geraud Darnis, et al. v. Raytheon Technologies Corporation, et al.). The Complaint challenges the method by which UTC equity awards were converted to UTC, Carrier and Otis equity awards following the Separation and the Distribution. Defendants moved to dismiss the Complaint. Plaintiffs amended their Complaint on September 13, 2021 ("the Amended Complaint"). The Amended Complaint, now with Raytheon, Carrier and Otis as the only defendants, asserts that the defendants are liable for breach of certain equity compensation plans and for breach of the implied covenant of good faith and fair dealing. The Amended Complaint also seeks specific performance. Carrier believes that the claims against the Company are without merit. Defendants moved to dismiss the Amended Complaint on October 13, 2021. The motion was fully briefed as of December 3, 2021. The court has not scheduled arguments or decided the motion.
  (was, 2021-10-28, similarity 0.913):
[0001783180-21-000065:note_history:11]
On August 12, 2020, several former employees of UTC or its subsidiaries filed a putative class action complaint (the "Complaint") in the United States District Court for the District of Connecticut against Raytheon Technologies Corporation, Carrier, Otis, the former members of the UTC Board of Directors and the members of the Carrier and Otis Boards of Directors (Geraud Darnis, et al. v. Raytheon Technologies Corporation, et al.). The Complaint challenges the method by which UTC equity awards were converted to UTC, Carrier and Otis equity awards following the Separation and the Distribution. Defendants moved to dismiss the Complaint. Plaintiffs amended their Complaint on September 13, 2021. The amended Complaint, now with Raytheon, Carrier and Otis as the only defendants, asserts that the defendants are liable for breach of certain equity compensation plans and for breach of the implied covenant of good faith and fair dealing. The Amended Complaint also seeks specific performance. Carrier believes that the claims against the Company are without merit.

- added (2022-04-28):
[0001783180-22-000034:note_history:12]
As of March 31, 2022, the Company has been named as a defendant in more than 2,200 lawsuits filed by individuals in or removed to the federal courts of the United States alleging that the historic use of Aqueous Film Forming Foam ("AFFF") caused personal injuries and/or property damage. The Company has also been named as a defendant in more than 160 lawsuits filed by several U.S. states, municipalities and water utilities in or removed to U.S. federal courts alleging that the historic use of AFFF caused contamination of property and water supplies. In December 2018, the U.S. Judicial Panel on Multidistrict Litigation transferred and consolidated all AFFF cases pending in the U.S. federal courts against the Company and others to the U.S. District Court for the District of South Carolina ("MDL Court") for pre-trial proceedings ("MDL Proceedings"). The individual plaintiffs in the MDL Proceedings generally seek damages for alleged personal injuries, medical monitoring and diminution in property value and injunctive relief to remediate alleged contamination of water supplies. The U.S. state, municipal and water utility plaintiffs in the MDL Proceedings generally seek damages and costs related to the remediation of public property and water supplies.

- changed (2022-04-28):
[0001783180-22-000034:note_history:13]
AFFF is a firefighting foam, developed beginning in the late 1960s pursuant to U.S. military specification, used to extinguish certain types of hydrocarbon-fueled fires primarily at military bases and airports. AFFF was manufactured by several companies, including National Foam and Angus Fire. UTC first entered the AFFF business with the acquisition of National Foam and Angus Fire in 2005 as part of the acquisition of Kidde. In 2013, Kidde divested the National Foam and Angus Fire businesses to a third party. The Company acquired Kidde as part of its separation from UTC in April 2020. During the eight-year period of its operation by Kidde, National Foam manufactured AFFF for sale to government (including the U.S. federal government) and non-government customers in the U.S. at a single facility located in West Chester, Pennsylvania
  (was, 2021-10-28, similarity 0.6604):
[0001783180-21-000065:note_history:13]
AFFF is a firefighting foam, developed beginning in the late 1960s pursuant to U.S. military specification, used to extinguish certain types of hydrocarbon-fueled fires primarily at military bases and airports. AFFF was manufactured by several companies, including National Foam and Angus Fire. UTC first entered the AFFF business with the acquisition of National Foam and Angus Fire in 2005 as part of the acquisition of Kidde. In 2013, Kidde divested the National Foam and Angus Fire businesses to a third party. The Company acquired Kidde as part of its separation from UTC in April 2020. During the eight year period of its operation by Kidde, National Foam manufactured AFFF for sale to government (including the U.S. federal government) and non-government customers in the U.S. at a single facility located in West Chester, Pennsylvania ("Pennsylvania Site"). During the same period, Angus Fire manufactured AFFF for sale outside the United States at a single facility located in Bentham, England.

- added (2022-04-28):
[0001783180-22-000034:note_history:14]
("Pennsylvania Site"). During the same period, Angus Fire manufactured AFFF for sale outside the United States at a single facility located in Bentham, England.

- added (2022-04-28):
[0001783180-22-000034:note_history:15]
General liability discovery in the MDL Proceedings continues. Preliminary stage discovery in ten "bellwether" water provider cases was concluded and three of these cases were selected for tier two site-specific discovery. That discovery is ongoing. The MDL Court previously established a briefing schedule with respect to certain aspects of the government contractor defense, potentially applicable to AFFF sold to or used by the U.S. government or other customers requiring product manufactured to meet military specification, with briefing to conclude at the end of January 2022 with a hearing to follow in late March. In late March the MDL Court postponed the planned hearing and called for briefing on additional elements of the government contractor defense. Briefing will continue through July 1, 2022.

- changed (2022-04-28):
[0001783180-22-000034:note_history:16]
Outside of the MDL Proceedings, the Company and other defendants are also party to six lawsuits in U.S. state courts brought by oil refining companies alleging product liability claims related to legacy sales of AFFF and seeking damages for the costs to replace the product and for property damage. In addition, the Company and other defendants are party to two actions related to the Pennsylvania Site in which the plaintiff water utility company seeks remediation costs related to the alleged contamination of the local water supply.
  (was, 2021-10-28, similarity 0.9925):
[0001783180-21-000065:note_history:16]
Outside of the MDL Proceedings, the Company and other defendants are also party to six lawsuits in U.S. state courts brought by oil refining companies alleging product liability claims related to legacy sales of AFFF and seeking damages for the costs to replace the product and for property damage. In addition, the Company and other defendants are party to two actions related to the Pennsylvania Site in which the plaintiff water utility seeks remediation costs related to the alleged contamination of the local water supply.

- changed (2022-04-28):
[0001783180-22-000034:note_history:17]
The Company believes that it has meritorious defenses to the claims in the MDL Proceedings and the other AFFF lawsuits. Based on the 2013 agreement for the sale of National Foam and Angus Fire, the Company is pursuing indemnification against these claims from the purchaser and current owner of National Foam and Angus Fire. The Company also is pursuing insurance coverage for these claims. At this time, however, given the numerous factual, scientific and legal issues to be resolved relating to these claims, the Company is unable to assess the probability of liability or to reasonably estimate the damages, if any, to be allocated to the Company, if one or more plaintiffs were to prevail in these cases. There can be no assurance that any such future exposure will not be material in any period.
  (was, 2021-10-28, similarity 0.7506):
[0001783180-21-000065:note_history:17]
The Company believes that it has meritorious defenses to the claims in the MDL Proceedings and the other AFFF lawsuits. Based on the 2013 agreement for the sale of National Foam and Angus Fire, the Company is pursuing indemnification against these claims from the purchaser and current owner of National Foam and Angus Fire. The Company is also pursuing insurance coverage for these claims. At this time, however, given the numerous factual, scientific and legal issues to be resolved relating

- added (2022-04-28):
[0001783180-22-000034:note_history:18]
Under the Tax Matters Agreement relating to the Separation, the Company is responsible to UTC for its share of the Tax Cuts and Jobs Act ("TCJA") transition tax associated with foreign undistributed earnings as of December 31, 2017. As a result, a liability of $417 million is included within the accompanying Unaudited Condensed Consolidated Balance Sheet within Other Long-Term Liabilities as of March 31, 2022. This obligation is expected to be settled in annual installments ending in April 2026 with the next installment of $34 million due in 2023. The Company believes that the likelihood of incurring losses materially in excess of this amount is remote.

- changed (2022-04-28):
[0001783180-22-000034:note_history:19]
The Company has other commitments and contingent liabilities related to legal proceedings, self-insurance programs and matters arising in the ordinary course of business. The Company accrues for contingencies generally based upon a range of
  (was, 2021-10-28, similarity 0.7921):
[0001783180-21-000065:note_history:19]
The Company has other commitments and contingent liabilities related to legal proceedings, self-insurance programs and matters arising in the ordinary course of business. The Company accrues for contingencies generally based upon a range of possible outcomes. If no amount within the range is a better estimate than any other, the Company accrues the minimum amount.

- added (2022-04-28):
[0001783180-22-000034:note_history:20]
possible outcomes. If no amount within the range is a better estimate than any other, the Company accrues the minimum amount.

- removed (2022-04-28):
[0001783180-21-000065:note_history:21]
As of September 30, 2021, the Company has been named as a defendant in 1,629 lawsuits filed by individuals in or removed to the federal courts of the United States alleging that the historic use of Aqueous Film Forming Foam ("AFFF") caused personal injuries and/or property damage. The Company has also been named as a defendant in 149 lawsuits filed by several U.S. states, municipalities and water utilities in or removed to U.S. federal courts alleging that the historic use of AFFF caused

- removed (2022-04-28):
[0001783180-21-000065:note_history:22]
contamination of property and water supplies. In December 2018, the U.S. Judicial Panel on Multidistrict Litigation transferred and consolidated all AFFF cases pending in the U.S. federal courts against the Company and others to the U.S. District Court for the District of South Carolina ("MDL Court") for pre-trial proceedings ("MDL Proceedings"). The individual plaintiffs in the MDL Proceedings generally seek damages for alleged personal injuries, medical monitoring and diminution in property value and injunctive relief to remediate alleged contamination of water supplies. The U.S. state, municipal and water utility plaintiffs in the MDL Proceedings generally seek damages and costs related to the remediation of public property and water supplies.

- removed (2022-04-28):
[0001783180-21-000065:note_history:23]
General liability discovery in the MDL Proceedings continues. The parties are also currently conducting preliminary stage discovery with respect to ten "bellwether" water provider cases, which are scheduled to conclude by October 2021. At that point, the MDL Court intends to reduce that pool to three cases, after which the parties will conduct expanded fact and expert discovery and pursue dispositive motions, followed by trials to commence in 2023. The MDL Court has established a briefing schedule with respect to certain aspects of the government contractor defense, potentially applicable to AFFF sold to or used by the U.S. federal government or other customers requiring product manufactured to meet military specification, such that all briefs will be filed by late January 2022 with a hearing to follow thereafter.

- removed (2022-04-28):
[0001783180-21-000065:note_history:24]
to these claims, the Company is unable to assess the probability of liability or to reasonably estimate the damages, if any, to be allocated to the Company, if one or more plaintiffs were to prevail in these cases, and there can be no assurance that any such future exposure will not be material in any period.

- removed (2022-04-28):
[0001783180-21-000065:note_history:25]
Under the TMA, the Company is responsible to UTC for its share of the Tax Cuts and Jobs Act ("TCJA") transition tax associated with foreign undistributed earnings as of December 31, 2017. As a result, a liability of $453 million is included within the accompanying Unaudited Condensed Consolidated Balance Sheet as of September 30, 2021. This obligation is expected to be settled in annual installments ending in April 2026 with the next installment of $36 million included within Accrued Liabilities. The Company believes that the likelihood of incurring losses materially in excess of this amount is remote.


## us-gaap:ScheduleOfEnvironmentalLossContingenciesBySiteTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-04-28):
[0001783180-22-000034:note_history:26]
| (In millions) |  | March 31,2022 |  | December 31, 2021 |
| Environmental reserves included in Accrued liabilities |  | $ | 29 |  |  | $ | 29 |  |
| Environmental reserves included in Other long-term liabilities |  | 189 |  |  | 191 |  |
| Total Environmental reserves |  | $ | 218 |  |  | $ | 220 |  |
  (was, 2021-10-28, similarity 0.9742):
[0001783180-21-000065:note_history:26]
| (In millions) |  | September 30,2021 |  | December 31, 2020 |
| Environmental reserves included in Accrued liabilities |  | $ | 19 |  |  | $ | 26 |  |
| Environmental reserves included in Other long-term liabilities |  | 202 |  |  | 213 |  |
| Total Environmental reserves |  | $ | 221 |  |  | $ | 239 |  |


## us-gaap:ScheduleOfLossContingenciesByContingencyTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-04-28):
[0001783180-22-000034:note_history:27]
The Company had asbestos liabilities and related insurance recoveries as follows:
  (was, 2021-10-28, similarity 0.9342):
[0001783180-21-000065:note_history:27]
The Company had asbestos liabilities and related recoveries as follows:

- changed (2022-04-28):
[0001783180-22-000034:note_history:28]
| (In millions) |  | March 31,2022 |  | December 31,2021 |
| Asbestos liabilities included in Accrued liabilities |  | $ | 17 |  |  | $ | 17 |  |
| Asbestos liabilities included in Other long-term liabilities |  | 219 |  |  | 220 |  |
| Total Asbestos liabilities |  | $ | 236 |  |  | $ | 237 |  |
| Asbestos-related recoveries included in Other assets, current |  | $ | 5 |  |  | $ | 5 |  |
| Asbestos-related recoveries included in Other assets |  | 92 |  |  | 93 |  |
| Total Asbestos-related recoveries |  | $ | 97 |  |  | $ | 98 |  |
  (was, 2021-10-28, similarity 0.9877):
[0001783180-21-000065:note_history:28]
| (In millions) |  | September 30,2021 |  | December 31,2020 |
| Asbestos liabilities included in Accrued liabilities |  | $ | 17 |  |  | $ | 17 |  |
| Asbestos liabilities included in Other long-term liabilities |  | 221 |  |  | 228 |  |
| Total Asbestos liabilities |  | $ | 238 |  |  | $ | 245 |  |
| Asbestos-related recoveries included in Other assets, current |  | $ | 5 |  |  | $ | 6 |  |
| Asbestos-related recoveries included in Other assets |  | 93 |  |  | 97 |  |
| Total Asbestos-related recoveries |  | $ | 98 |  |  | $ | 103 |  |


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2022-04-28):
[0001783180-22-000034:note_history:29]
Sale of Chubb Fire & Security Business

- added (2022-04-28):
[0001783180-22-000034:note_history:30]
On July 26, 2021, the Company entered into a stock purchase agreement to sell its Chubb Fire and Security business ("Chubb") to APi Group Corporation ("APi"). As a result, the assets and liabilities of Chubb are presented as held for sale on the accompanying Unaudited Condensed Consolidated Balance Sheet as of December 31, 2021 and recorded at the lower of their carrying value or fair value less estimated cost to sell. The sale of Chubb was completed on January 3, 2022 (the "Chubb Sale"). See Note 16 - Divestitures for additional information.

- added (2022-04-28):
[0001783180-22-000034:note_history:31]
Separation from United Technologies

- added (2022-04-28):
[0001783180-22-000034:note_history:32]
On April 3, 2020, United Technologies Corporation, since renamed Raytheon Technologies Corporation ("UTC"), completed the spin-off of the Company into an independent, publicly traded company (the "Separation") through a pro-rata distribution (the "Distribution") on a one-for-one basis of all of the outstanding shares of common stock of the Company to UTC shareowners who held shares of UTC common stock as of the close of business on March 19, 2020, the record date of the Distribution. The Company incurred separation-related costs including employee-related costs, costs to establish certain stand-alone functions, information technology systems, professional service fees and other costs associated with becoming an independent, publicly traded company. These costs are primarily recorded in Selling, general and administrative in the Unaudited Condensed Consolidated Statement of Operations and totaled $16 million for the three months ended March 31, 2021.

- changed (2022-04-28):
[0001783180-22-000034:note_history:33]
Recently Issued and Adopted Accounting Pronouncements
  (was, 2021-10-28, similarity 0.8842):
[0001783180-21-000065:note_history:33]
Recently Adopted Accounting Pronouncements

- changed (2022-04-28):
[0001783180-22-000034:note_history:34]
The Financial Accounting Standards Board ("FASB") Accounting Standards Codification ("ASC") is the sole source of authoritative U.S. GAAP other than SEC issued rules and regulations that apply only to SEC registrants. The FASB issues Accounting Standards Updates ("ASU") to communicate changes to the codification. The Company considers the applicability and impact of all ASUs. ASUs pending adoption were assessed and determined to be either not applicable or not expected to have a material impact on the Unaudited Condensed Consolidated Financial Statements.
  (was, 2021-10-28, similarity 0.8602):
[0001783180-21-000065:note_history:34]
The Financial Accounting Standards Board ("FASB") Accounting Standards Codification ("ASC") is the sole source of authoritative U.S. GAAP other than SEC issued rules and regulations that apply only to SEC registrants. The FASB issues Accounting Standards Updates ("ASU") to communicate changes to the codification. The Company considers the applicability and impact of all ASUs. ASUs not referenced below were assessed and determined to be either not applicable or are not expected to have a material impact on the Unaudited Condensed Consolidated Financial Statements.

- removed (2022-04-28):
[0001783180-21-000065:note_history:35]
The Company's financial statements for the periods prior to the Separation and the Distribution are prepared on a "carve-out" basis and include all amounts directly attributable to the Company. Net cash transfers and other property transferred between UTC and the Company, including related party receivables and payables between the Company and other UTC affiliates, are presented as Net transfers to UTC. In addition, the financial statements include allocations of costs for administrative functions and services performed on behalf of the Company by centralized groups within UTC. All allocations and estimates in the Unaudited Condensed Consolidated Financial Statements are based on assumptions that management believes are reasonable. The Company's financial statements for the periods subsequent to April 3, 2020 are consolidated financial statements based on the reported results of Carrier as a stand-alone company.

- removed (2022-04-28):
[0001783180-21-000065:note_history:36]
Held for Sale

- removed (2022-04-28):
[0001783180-21-000065:note_history:37]
On July 26, 2021, the Company entered into a stock purchase agreement to sell its Chubb Fire and Security business ("Chubb") to APi Group Corporation ("APi"). The transaction is expected to close late in the fourth quarter of 2021 or early in the first quarter of 2022, subject to regulatory approvals, required works council approval in France and customary closing conditions. In accordance with U.S. GAAP, the assets and liabilities of Chubb have been classified as held for sale on the accompanying Unaudited Condensed Consolidated Balance Sheet as of September 30, 2021 and recorded at the lower of their carrying value or fair value less estimated cost to sell. See Note 16 - Divestitures for additional information.

- removed (2022-04-28):
[0001783180-21-000065:note_history:38]
In December 2019, the FASB issued ASU 2019-12, Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes ("ASU 2019-12"), which simplifies certain aspects of income tax accounting guidance in ASC 740, Income Taxes ("ASC 740") reducing the complexity of its application while maintaining or improving the usefulness of the information required to be reported. The ASU eliminates certain exceptions from ASC 740 including: intra-period tax allocation, deferred tax liabilities related to outside basis differences and year-to-date loss in interim periods, among others. ASU 2019-12 was effective for periods beginning after December 15, 2020, including interim periods therein with early adoption permitted. The Company adopted this ASU on January 1, 2021 with no material impact on the Unaudited Condensed Consolidated Financial Statements.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2022-04-28):
[0001783180-22-000034:note_history:39]
DESCRIPTION OF THE BUSINESS 
Carrier Global Corporation is a leading global provider of healthy, safe, sustainable and intelligent building and cold chain solutions. The Company's portfolio includes industry-leading brands such as Carrier, Automated Logic, Carrier Transicold, Kidde, Edwards and LenelS2 that offer innovative heating, ventilating, air conditioning ("HVAC"), refrigeration, fire, security and building automation technologies to help make the world safer and more comfortable. The Company also provides a broad array of related building services, including audit, design, installation, system integration, repair, maintenance and monitoring.

- changed (2022-04-28):
[0001783180-22-000034:note_history:40]
In the opinion of management, the accompanying Unaudited Condensed Consolidated Financial Statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission (the "SEC"). These Unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for 2021 filed with the SEC on February 8, 2022 (the "2021 Form 10-K").
  (was, 2021-10-28, similarity 0.8314):
[0001783180-21-000065:note_history:40]
DESCRIPTION OF THE BUSINESS 
Carrier Global Corporation is a leading global provider of heating, ventilating, air conditioning ("HVAC"), refrigeration and fire and security solutions. The Company also provides a broad array of related building services, including audit, design, installation, system integration, repair, maintenance and monitoring. In the opinion of management, the accompanying Unaudited Condensed Consolidated Financial Statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission (the "SEC"). These Unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for 2020 filed with the SEC on February 9, 2021 (the "2020 Form 10-K").

- added (2022-04-28):
[0001783180-22-000034:note_history:41]
In early 2020, the World Health Organization declared the outbreak of a respiratory disease known as COVID-19 as a global pandemic. In response, many countries implemented containment and mitigation measures to combat the outbreak, which severely restricted the level of economic activity and caused a significant contraction in the global economy. As a result, the Company took several preemptive actions to manage liquidity, preserve the health and safety of its employees and customers as well as maintain the continuity of its operations. The preparation of financial statements requires management to use judgments in making estimates and assumptions based on the relevant information available at the end of each period, which can have a significant effect on reported amounts. However, due to significant uncertainty surrounding the pandemic, including a resurgence in cases and the spread of COVID-19 variants, management's judgments could change. While the Company's results of operations, cash flows and financial condition could be negatively impacted, the extent of any continuing impact cannot be estimated with certainty at this time.

- removed (2022-04-28):
[0001783180-21-000065:note_history:42]
On April 3, 2020 (the "Distribution Date"), United Technologies Corporation, since renamed Raytheon Technologies Corporation ("UTC"), completed the spin-off of the Company into an independent, publicly traded company (the "Separation") through a pro-rata distribution (the "Distribution") on a one-for-one basis of all of the outstanding shares of common stock of the Company to UTC shareowners who held shares of UTC common stock as of the close of business on March 19, 2020, the record date of the Distribution. In connection with the Separation, the Company issued an aggregate principal balance of $11.0 billion of debt and transferred approximately $10.9 billion of cash to UTC on February 27, 2020 and March 27, 2020. On April 1, 2020 and April 2, 2020, the Company received cash contributions totaling $590 million from UTC related to the Separation.

- removed (2022-04-28):
[0001783180-21-000065:note_history:43]
In connection with the Separation, the Company entered into several agreements with UTC and Otis Worldwide Corporation ("Otis") that govern various aspects of the relationship among the Company, UTC and Otis following the Separation and the Distribution, including a transition services agreement ("TSA"), a tax matters agreement ("TMA"), an employee matters agreement and an intellectual property agreement that cover services such as information technology, tax, finance and human resources. In addition, the Company incurred separation-related costs including employee-related costs, costs to establish certain stand-alone functions, information technology systems, professional service fees and other costs associated with becoming an independent, publicly traded company. These costs are primarily recorded in Selling, general and administrative in the Unaudited Condensed Consolidated Statement of Operations and totaled $24 million for the three months ended September 30, 2020. Costs for the nine months ended September 30, 2021 and 2020 were $19 million and $92 million, respectively. The TSA expired on March 31, 2021.

- removed (2022-04-28):
[0001783180-21-000065:note_history:44]
In early 2020, the World Health Organization declared the outbreak of a respiratory disease known as COVID-19 as a global pandemic. In response, many countries implemented containment and mitigation measures to combat the outbreak, which severely restricted the level of economic activity and caused a significant contraction in the global economy. As a result, the Company temporarily closed or reduced production at manufacturing facilities across the globe to ensure employee safety and instructed non-essential employees to work from home. In addition, the Company took several preemptive actions during 2020 to manage liquidity as demand for its products decreased. Despite the adverse impacts of the pandemic on the Company’s results beginning in the first quarter of 2020, manufacturing operations resumed and several restorative actions were completed during 2020, including the reinstatement of annual merit-based salary increases and continued investment to support the Company's strategic priorities.

- removed (2022-04-28):
[0001783180-21-000065:note_history:45]
The Company continues to focus its efforts on preserving the health and safety of its employees and customers as well as maintaining the continuity of its operations. In addition, the Company continues to actively monitor its liquidity position and working capital needs and believes that its overall capital resources and liquidity position are adequate. The preparation of financial statements requires management to use judgments in making estimates and assumptions based on the relevant information available at the end of each period, which can have a significant effect on reported amounts. However, due to significant uncertainty surrounding the pandemic, including a resurgence in cases and the spread of COVID-19 variants, management's judgments could change. While the Company's results of operations, cash flows and financial condition could be negatively impacted, the extent of any continuing impact cannot be estimated with certainty at this time.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-04-28):
[0001783180-22-000034:note_history:46]
| (In millions) |  |  |  | March 31,2022 |  | December 31,2021 |
| 2.242% Notes due February 15, 2025 |  |  |  | $ | 1,200 |  |  | $ | 2,000 |  |
| 2.493% Notes due February 15, 2027 |  |  |  | 900 |  |  | 1,250 |  |
| 2.722% Notes due February 15, 2030 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.700% Notes due February 15, 2031 |  |  |  | 750 |  |  | 750 |  |
| 3.377% Notes due April 5, 2040 |  |  |  | 1,500 |  |  | 1,500 |  |
| 3.577% Notes due April 5, 2050 |  |  |  | 2,000 |  |  | 2,000 |  |
| Total Long-term notes |  |  |  | 8,350 |  |  | 9,500 |  |
| Other debt (including project financing obligations and finance leases) |  |  |  | 275 |  |  | 267 |  |
| Discounts and debt issuance costs |  |  |  | (64) |  |  | (71) |  |
| Total debt |  |  |  | 8,561 |  |  | 9,696 |  |
| Less: current portion of long-term debt |  |  |  | 256 |  |  | 183 |  |
| Long-term debt, net of current portion |  |  |  | $ | 8,305 |  |  | $ | 9,513 |  |
  (was, 2021-10-28, similarity 0.9495):
[0001783180-21-000065:note_history:46]
| (In millions) |  |  |  | September 30,2021 |  | December 31,2020 |
| 1.923% Notes due February 15, 2023 |  |  |  | $ | — |  | (1) | $ | 500 |  |
| 2.242% Notes due February 15, 2025 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.493% Notes due February 15, 2027 |  |  |  | 1,250 |  |  | 1,250 |  |
| 2.722% Notes due February 15, 2030 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.700% Notes due February 15, 2031 |  |  |  | 750 |  |  | 750 |  |
| 3.377% Notes due April 5, 2040 |  |  |  | 1,500 |  |  | 1,500 |  |
| 3.577% Notes due April 5, 2050 |  |  |  | 2,000 |  |  | 2,000 |  |
| Total long-term Notes |  |  |  | 9,500 |  |  | 10,000 |  |
| Other debt (including project financing obligations and finance leases) |  |  |  | 261 |  |  | 308 |  |
| Discounts and debt issuance costs |  |  |  | (73) |  |  | (81) |  |
| Total debt |  |  |  | 9,688 |  |  | 10,227 |  |
| Less: current portion of long-term debt |  |  |  | 130 |  |  | 191 |  |
| Long-term debt, net of current portion |  |  |  | $ | 9,558 |  |  | $ | 10,036 |  |

- changed (2022-04-28):
[0001783180-22-000034:note_history:47]
On February 10, 2020, the Company entered into a revolving credit agreement with various banks permitting aggregate borrowings of up to $2.0 billion pursuant to an unsecured, unsubordinated revolving credit facility that matures on April 3, 2025 (the "Revolving Credit Facility"). The Revolving Credit Facility supports the Company's commercial paper program and cash requirements of the Company. A commitment fee of 0.125% is charged on unused commitments. Borrowings under the Revolving Credit Facility are available in U.S. Dollars, Euros and Pounds Sterling and bear interest at a variable interest rate plus a ratings-based margin, which was 125 basis points as of March 31, 2022. As of March 31, 2022, there were no borrowings outstanding under the Revolving Credit Facility.
  (was, 2021-10-28, similarity 0.9574):
[0001783180-21-000065:note_history:47]
On February 10, 2020, the Company entered into a revolving credit agreement with various banks permitting aggregate borrowings of up to $2.0 billion pursuant to an unsecured, unsubordinated revolving credit facility that matures on April 3, 2025 (the "Revolving Credit Facility"). The Revolving Credit Facility supports the Company's commercial paper program and cash requirements of the Company. A commitment fee of 0.125% is charged on unused commitments. Borrowings under the Revolving Credit Facility are available in U.S. Dollars, Euros and Pounds Sterling and bear interest at a variable interest rate based on LIBOR plus a ratings-based margin, which was 125 basis points as of September 30, 2021. As of September 30, 2021, there were no borrowings outstanding under the Revolving Credit Facility.

- changed (2022-04-28):
[0001783180-22-000034:note_history:48]
The Company has a $2.0 billion unsecured, unsubordinated commercial paper program, which can be used for general corporate purposes, including the funding of working capital and potential acquisitions. As of March 31, 2022, there were no borrowings outstanding under the commercial paper program.
  (was, 2021-10-28, similarity 0.94):
[0001783180-21-000065:note_history:48]
As of September 30, 2021, the Company had a $2.0 billion unsecured, unsubordinated commercial paper program, which can be used for general corporate purposes, including the funding of working capital and potential acquisitions. As of September 30, 2021, there were no borrowings outstanding under the commercial paper program.

- changed (2022-04-28):
[0001783180-22-000034:note_history:49]
The Company is involved in several long-term construction contracts in which it arranges project financing with certain customers. As a result, the Company issued $14 million and $46 million of debt during the three months ended March 31, 2022 and 2021, respectively. Long-term debt repayments associated with these financing arrangements during the three months ended March 31, 2022 and 2021 were $8 million and $53 million, respectively.
  (was, 2021-10-28, similarity 0.8791):
[0001783180-21-000065:note_history:49]
The Company is involved in several long-term construction contracts in which it arranges project financing with certain customers. As a result, the Company issued $108 million and $102 million of debt during the nine months ended September 30, 2021 and 2020, respectively. Long-term debt repayments associated with these financing arrangements during the nine months ended September 30, 2021 and 2020 were $170 million and $124 million, respectively.

- added (2022-04-28):
[0001783180-22-000034:note_history:50]
The Revolving Credit Facility and the indenture for the Long-term notes contain affirmative and negative covenants customary for financings of these types, which, among other things, limit the Company's ability to incur additional liens, to make certain fundamental changes and to enter into sale and leaseback transactions. As of March 31, 2022, the Company was in compliance with the covenants under the agreements governing its outstanding indebtedness.

- added (2022-04-28):
[0001783180-22-000034:note_history:51]
Tender Offers

- added (2022-04-28):
[0001783180-22-000034:note_history:52]
On March 15, 2022, the Company commenced tender offers to purchase up to $1.15 billion ("Aggregate Tender Cap") aggregate principal of the Company's 2.242% Notes due 2025 and 2.493% Notes due 2027 (together, the "Senior Notes"). The tender offers included payment of applicable accrued and unpaid interest up to the settlement date, along with a fixed spread for early repayment. Based on participation, the Company elected to settle the tender offers on March 30, 2022. The aggregate principal amount of Senior Notes validly tendered and accepted was approximately $1.15 billion, which included $800 million of Notes due 2025 and $350 million of Notes due 2027. Upon settlement, the Company recognized a net gain of $33 million and wrote off $5 million of unamortized deferred financing costs within Interest (expense) income, net on the accompanying Unaudited Condensed Consolidated Statement of Operations.

- removed (2022-04-28):
[0001783180-21-000065:note_history:53]
(1) In February 2021, the Company prepaid the 1.923% Notes due in February 2023 and incurred a $17 million make-whole premium upon prepayment and wrote-off $2 million of the remaining unamortized deferred financing costs

- removed (2022-04-28):
[0001783180-21-000065:note_history:54]
The Revolving Credit Facility and the indenture for the long-term notes contain affirmative and negative covenants customary for financings of these types which, among other things, limit the Company's ability to incur additional liens, to make certain fundamental changes and to enter into sale and leaseback transactions. On June 2, 2020, the Company entered into an amendment of the Revolving Credit Facility, under which certain terms of the facility were amended for a period beginning on June 2, 2020 and ending on December 30, 2021 (the "Covenant Modification"). The Company terminated the Covenant Modification effective as of August 27, 2021 in accordance with the procedure for termination set forth in the revolving credit agreement, which returned the consolidated leverage ratio covenant to the limit in effect prior to the Covenant Modification. As 
of September 30, 2021, the Company was in compliance with the covenants under the agreements governing its outstanding indebtedness.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-04-28):
[0001783180-22-000034:note_history:55]
| (In millions) |  |  |  | March 31,2022 |  | December 31,2021 |
| 2.242% Notes due February 15, 2025 |  |  |  | $ | 1,200 |  |  | $ | 2,000 |  |
| 2.493% Notes due February 15, 2027 |  |  |  | 900 |  |  | 1,250 |  |
| 2.722% Notes due February 15, 2030 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.700% Notes due February 15, 2031 |  |  |  | 750 |  |  | 750 |  |
| 3.377% Notes due April 5, 2040 |  |  |  | 1,500 |  |  | 1,500 |  |
| 3.577% Notes due April 5, 2050 |  |  |  | 2,000 |  |  | 2,000 |  |
| Total Long-term notes |  |  |  | 8,350 |  |  | 9,500 |  |
| Other debt (including project financing obligations and finance leases) |  |  |  | 275 |  |  | 267 |  |
| Discounts and debt issuance costs |  |  |  | (64) |  |  | (71) |  |
| Total debt |  |  |  | 8,561 |  |  | 9,696 |  |
| Less: current portion of long-term debt |  |  |  | 256 |  |  | 183 |  |
| Long-term debt, net of current portion |  |  |  | $ | 8,305 |  |  | $ | 9,513 |  |
  (was, 2021-10-28, similarity 0.9495):
[0001783180-21-000065:note_history:55]
| (In millions) |  |  |  | September 30,2021 |  | December 31,2020 |
| 1.923% Notes due February 15, 2023 |  |  |  | $ | — |  | (1) | $ | 500 |  |
| 2.242% Notes due February 15, 2025 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.493% Notes due February 15, 2027 |  |  |  | 1,250 |  |  | 1,250 |  |
| 2.722% Notes due February 15, 2030 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.700% Notes due February 15, 2031 |  |  |  | 750 |  |  | 750 |  |
| 3.377% Notes due April 5, 2040 |  |  |  | 1,500 |  |  | 1,500 |  |
| 3.577% Notes due April 5, 2050 |  |  |  | 2,000 |  |  | 2,000 |  |
| Total long-term Notes |  |  |  | 9,500 |  |  | 10,000 |  |
| Other debt (including project financing obligations and finance leases) |  |  |  | 261 |  |  | 308 |  |
| Discounts and debt issuance costs |  |  |  | (73) |  |  | (81) |  |
| Total debt |  |  |  | 9,688 |  |  | 10,227 |  |
| Less: current portion of long-term debt |  |  |  | 130 |  |  | 191 |  |
| Long-term debt, net of current portion |  |  |  | $ | 9,558 |  |  | $ | 10,036 |  |

- removed (2022-04-28):
[0001783180-21-000065:note_history:56]
(1) In February 2021, the Company prepaid the 1.923% Notes due in February 2023 and incurred a $17 million make-whole premium upon prepayment and wrote-off $2 million of the remaining unamortized deferred financing costs


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- added (2022-04-28):
[0001783180-22-000034:note_history:57]
|  |  |  |  | For the Three Months Ended March 31, |
| (In millions) |  |  |  |  |  | 2022 |  | 2021 |
| Sales to equity method investees included in Product sales |  |  |  |  |  | $ | 624 |  |  | $ | 468 |  |
| Purchases from equity method investees included in Cost of products sold |  |  |  |  |  | $ | 110 |  |  | $ | 75 |  |

- added (2022-04-28):
[0001783180-22-000034:note_history:58]
| (In millions) |  | March 31,2022 |  | December 31, 2021 |
| Receivables from equity method investees included in Accounts receivable, net |  | $ | 228 |  |  | $ | 150 |  |
| Payables to equity method investees included in Accounts payable |  | $ | 49 |  |  | $ | 51 |  |

- removed (2022-04-28):
[0001783180-21-000065:note_history:59]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
| (In millions) |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Sales to equity method investees included in Product sales |  | $ | 556 |  |  | $ | 576 |  |  | $ | 1,675 |  |  | $ | 1,400 |  |
| Purchases from equity method investees included in Cost of products sold |  | $ | 93 |  |  | $ | 70 |  |  | $ | 266 |  |  | $ | 213 |  |

- removed (2022-04-28):
[0001783180-21-000065:note_history:60]
| (In millions) |  | September 30,2021 |  | December 31, 2020 |
| Receivables from equity method investees included in Accounts receivable, net |  | $ | 253 |  |  | $ | 161 |  |
| Payables to equity method investees included in Accounts payable |  | $ | 55 |  |  | $ | 38 |  |

- removed (2022-04-28):
[0001783180-21-000065:note_history:61]
The Company periodically reviews the carrying value of its equity method investments to determine if there has been an other-than-temporary decline in fair value. During the three months ended March 31, 2020, the Company determined that indicators of impairment existed for a minority owned joint venture investment and performed a valuation of this investment using a discounted cash flow method. The Company determined that the loss in value was other-than-temporary due to a reduction in sales and earnings that were primarily driven by a deterioration in the oil and gas industry (the joint venture's primary market) and by the impact of the COVID-19 pandemic. As a result, the Company recorded a non-cash, other-than-temporary impairment charge of $71 million on this investment during the three months ended March 31, 2020, which is included in Other income (expense), net on the accompanying Unaudited Condensed Consolidated Statement of Operations.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-04-28):
[0001783180-22-000034:note_history:62]
|  |  |  |  | For the Three Months Ended March 31, |
| (In millions) |  |  |  |  |  | 2022 |  | 2021 |
| Sales Type |  |  |  |  |  |  |  |  |
| Product |  |  |  |  |  | $ | 2,639 |  |  | $ | 2,147 |  |
| Service |  |  |  |  |  | 331 |  |  | 339 |  |
| HVAC sales |  |  |  |  |  | 2,970 |  |  | 2,486 |  |
| Product |  |  |  |  |  | 867 |  |  | 892 |  |
| Service |  |  |  |  |  | 109 |  |  | 113 |  |
| Refrigeration sales |  |  |  |  |  | 976 |  |  | 1,005 |  |
| Product |  |  |  |  |  | 771 |  |  | 919 |  |
| Service |  |  |  |  |  | 47 |  |  | 385 |  |
| Fire & Security sales |  |  |  |  |  | 818 |  |  | 1,304 |  |
| Total segment sales |  |  |  |  |  | 4,764 |  |  | 4,795 |  |
| Eliminations and other |  |  |  |  |  | (110) |  |  | (96) |  |
| Net sales |  |  |  |  |  | $ | 4,654 |  |  | $ | 4,699 |  |
  (was, 2021-10-28, similarity 0.8116):
[0001783180-21-000065:note_history:62]
|  |  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
| (In millions) |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Sales Type |  |  |  |  |  |  |  |  |
| Product |  | $ | 2,702 |  |  | $ | 2,547 |  |  | $ | 7,606 |  |  | $ | 6,180 |  |
| Service |  | 352 |  |  | 345 |  |  | 1,054 |  |  | 962 |  |
| HVAC sales |  | 3,054 |  |  | 2,892 |  |  | 8,660 |  |  | 7,142 |  |
| Product |  | 894 |  |  | 771 |  |  | 2,701 |  |  | 2,093 |  |
| Service |  | 117 |  |  | 105 |  |  | 336 |  |  | 291 |  |
| Refrigeration sales |  | 1,011 |  |  | 876 |  |  | 3,037 |  |  | 2,384 |  |
| Product |  | 1,012 |  |  | 965 |  |  | 2,943 |  |  | 2,587 |  |
| Service |  | 365 |  |  | 359 |  |  | 1,141 |  |  | 1,000 |  |
| Fire & Security sales |  | 1,377 |  |  | 1,324 |  |  | 4,084 |  |  | 3,587 |  |
| Total segment sales |  | 5,442 |  |  | 5,092 |  |  | 15,781 |  |  | 13,113 |  |
| Eliminations and other |  | (101) |  |  | (90) |  |  | (301) |  |  | (251) |  |
| Net sales |  | $ | 5,341 |  |  | $ | 5,002 |  |  | $ | 15,480 |  |  | $ | 12,862 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2022-04-28):
[0001783180-22-000034:note_history:63]
The Company accounts for revenue in accordance with ASC 606: Revenue from Contracts with Customers. Revenue is recognized when control of a good or service promised in a contract (i.e., performance obligation) is transferred to a customer. Control is obtained when a customer has the ability to direct the use of and obtain substantially all of the remaining benefits from that good or service. A significant portion of the Company's performance obligations are recognized at a point-in-time when control of the product transfers to the customer, which is generally at the time of shipment. The remaining portion of the Company’s performance obligations are recognized over time as the customer simultaneously obtains control as the Company performs work under a contract, or if the product being produced for the customer has no alternative use and the Company has a contractual right to payment.The timing of revenue recognition, billings and cash collections results in contract assets and contract liabilities. Contract assets relate to the conditional right to consideration for any completed performance under a contract when costs are incurred in excess of billings under the percentage-of-completion methodology. Contract liabilities relate to payments received in advance of performance under a contract or when the Company has a right to consideration that is conditioned upon transfer of a good or service to a customer. Contract liabilities are recognized as revenue as (or when) the Company performs under the contract.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-04-28):
[0001783180-22-000034:note_history:64]
REVENUE RECOGNITION 
The Company accounts for revenue in accordance with ASC 606: Revenue from Contracts with Customers. Revenue is recognized when control of a good or service promised in a contract (i.e., performance obligation) is transferred to a customer. Control is obtained when a customer has the ability to direct the use of and obtain substantially all of the remaining benefits from that good or service. A significant portion of the Company's performance obligations are recognized at a point-in-time when control of the product transfers to the customer, which is generally at the time of shipment. The remaining portion of the Company’s performance obligations are recognized over time as the customer simultaneously obtains control as the Company performs work under a contract, or if the product being produced for the customer has no alternative use and the Company has a contractual right to payment.
  (was, 2021-10-28, similarity 0.9049):
[0001783180-21-000065:note_history:64]
REVENUE RECOGNITION The Company recognizes revenue when control of a good or service promised in a contract (i.e., performance obligation) is transferred to a customer. Control is obtained when a customer has the ability to direct the use of and obtain substantially all of the remaining benefit from that good or service. A significant portion of the Company's performance obligations are recognized at a point-in-time when control of the product transfers to the customer, which is generally at the time of shipment. The remaining portion of the Company's performance obligations are recognized over time as the customer simultaneously obtains control as the Company performs work under a contract, or if the product being produced for the customer has no alternative use and the Company has a contractual right to payment. 
Sales disaggregated by product and service are as follows:

- added (2022-04-28):
[0001783180-22-000034:note_history:65]
Sales disaggregated by product and service are as follows:

- changed (2022-04-28):
[0001783180-22-000034:note_history:66]
|  |  |  |  | For the Three Months Ended March 31, |
| (In millions) |  |  |  |  |  | 2022 |  | 2021 |
| Sales Type |  |  |  |  |  |  |  |  |
| Product |  |  |  |  |  | $ | 2,639 |  |  | $ | 2,147 |  |
| Service |  |  |  |  |  | 331 |  |  | 339 |  |
| HVAC sales |  |  |  |  |  | 2,970 |  |  | 2,486 |  |
| Product |  |  |  |  |  | 867 |  |  | 892 |  |
| Service |  |  |  |  |  | 109 |  |  | 113 |  |
| Refrigeration sales |  |  |  |  |  | 976 |  |  | 1,005 |  |
| Product |  |  |  |  |  | 771 |  |  | 919 |  |
| Service |  |  |  |  |  | 47 |  |  | 385 |  |
| Fire & Security sales |  |  |  |  |  | 818 |  |  | 1,304 |  |
| Total segment sales |  |  |  |  |  | 4,764 |  |  | 4,795 |  |
| Eliminations and other |  |  |  |  |  | (110) |  |  | (96) |  |
| Net sales |  |  |  |  |  | $ | 4,654 |  |  | $ | 4,699 |  |
  (was, 2021-10-28, similarity 0.8116):
[0001783180-21-000065:note_history:66]
|  |  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
| (In millions) |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Sales Type |  |  |  |  |  |  |  |  |
| Product |  | $ | 2,702 |  |  | $ | 2,547 |  |  | $ | 7,606 |  |  | $ | 6,180 |  |
| Service |  | 352 |  |  | 345 |  |  | 1,054 |  |  | 962 |  |
| HVAC sales |  | 3,054 |  |  | 2,892 |  |  | 8,660 |  |  | 7,142 |  |
| Product |  | 894 |  |  | 771 |  |  | 2,701 |  |  | 2,093 |  |
| Service |  | 117 |  |  | 105 |  |  | 336 |  |  | 291 |  |
| Refrigeration sales |  | 1,011 |  |  | 876 |  |  | 3,037 |  |  | 2,384 |  |
| Product |  | 1,012 |  |  | 965 |  |  | 2,943 |  |  | 2,587 |  |
| Service |  | 365 |  |  | 359 |  |  | 1,141 |  |  | 1,000 |  |
| Fire & Security sales |  | 1,377 |  |  | 1,324 |  |  | 4,084 |  |  | 3,587 |  |
| Total segment sales |  | 5,442 |  |  | 5,092 |  |  | 15,781 |  |  | 13,113 |  |
| Eliminations and other |  | (101) |  |  | (90) |  |  | (301) |  |  | (251) |  |
| Net sales |  | $ | 5,341 |  |  | $ | 5,002 |  |  | $ | 15,480 |  |  | $ | 12,862 |  |

- changed (2022-04-28):
[0001783180-22-000034:note_history:67]
Total contract assets and contract liabilities consisted of the following:
  (was, 2021-10-28, similarity 0.6788):
[0001783180-21-000065:note_history:67]
Total contract assets and liabilities arising from contracts with customers are as follows:

- added (2022-04-28):
[0001783180-22-000034:note_history:68]
| (In millions) |  | March 31, 2022 |  | December 31, 2021 |
| Contract assets, current |  | $ | 655 |  |  | $ | 503 |  |
| Contract assets, non-current (included within Other assets) |  | 15 |  |  | 70 |  |
| Total contract assets |  | 670 |  |  | 573 |  |
| Contract liabilities, current |  | (426) |  |  | (415) |  |
| Contract liabilities, non-current (included within Other long-term liabilities) |  | (169) |  |  | (165) |  |
| Total contract liabilities |  | (595) |  |  | (580) |  |
| Net contract assets |  | $ | 75 |  |  | $ | (7) |  |

- changed (2022-04-28):
[0001783180-22-000034:note_history:69]
The timing of revenue recognition, billings and cash collections results in contract assets and contract liabilities. Contract assets relate to the conditional right to consideration for any completed performance under a contract when costs are incurred in excess of billings under the percentage-of-completion methodology. Contract liabilities relate to payments received in advance of performance under a contract or when the Company has a right to consideration that is conditioned upon transfer of a good or service to a customer. Contract liabilities are recognized as revenue as (or when) the Company performs under the contract. 
The Company recognized revenue of $157 million during the three months ended March 31, 2022 that related to contract liabilities as of January 1, 2022. The Company expects a majority of its current contract liabilities at the end of the period to be recognized as revenue in the next 12 months.
  (was, 2021-10-28, similarity 0.9634):
[0001783180-21-000065:note_history:69]
The timing of revenue recognition, billings and cash collections results in contract assets and contract liabilities. Contract assets relate to the conditional right to consideration for any completed performance under a contract when costs are incurred in excess of billings under the percentage-of-completion methodology. Contract liabilities relate to payments received in advance of performance under the contract or when the Company has a right to consideration that is conditioned upon transfer of a good or service to the customer. Contract liabilities are recognized as revenue as (or when) the Company performs under the contract. The Company recognized revenue of $337 million during the nine months ended September 30, 2021 that related to contract liabilities as of January 1, 2021. The Company expects a majority of its contract liabilities at the end of the period to be recognized as revenue in the next 12 months.

- removed (2022-04-28):
[0001783180-21-000065:note_history:70]
| (In millions) |  | September 30,2021 |  | December 31,2020 |
| Contract assets, current |  | $ | 502 |  |  | $ | 656 |  |
| Contract assets, non-current (included within Other assets) |  | 119 |  |  | 98 |  |
| Total contract assets |  | 621 |  |  | 754 |  |
| Contract liabilities, current |  | 418 |  |  | 512 |  |
| Contract liabilities, non-current (included within Other long-term liabilities) |  | 169 |  |  | 165 |  |
| Total contract liabilities |  | 587 |  |  | 677 |  |
| Net contract assets |  | $ | 34 |  |  | $ | 77 |  |
