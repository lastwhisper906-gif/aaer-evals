# CARR 8-K — 0001783180-22-000032 filed 2022-04-28

## item codes, every 8-K on or before 2022-04-28

- 2022-04-28 0001783180-22-000032 — 2.02, 9.01
- 2022-04-15 0001783180-22-000024 — 5.07, 9.01
- 2022-02-08 0001783180-22-000008 — 2.02, 9.01
- 2022-02-07 0000950142-22-000510 — 8.01, 9.01
- 2022-01-03 0000950142-22-000023 — 8.01, 9.01
- 2021-12-17 0001783180-21-000071 — 5.02, 7.01, 9.01
- 2021-11-23 0001783180-21-000068 — 5.03, 9.01
- 2021-10-28 0001783180-21-000062 — 2.02, 9.01
- 2021-08-27 0001783180-21-000056 — 8.01
- 2021-07-30 0001783180-21-000053 — 1.01
- 2021-07-29 0001783180-21-000049 — 2.02, 8.01, 9.01
- 2021-07-27 0000950142-21-002448 — 8.01, 9.01
- 2021-07-15 0000950142-21-002362 — 5.02, 9.01
- 2021-06-09 0000950142-21-001885 — 5.02, 9.01
- 2021-04-29 0001783180-21-000029 — 2.02, 9.01
- 2021-04-22 0001140361-21-013889 — 5.02, 9.01
- 2021-04-20 0001783180-21-000021 — 5.07, 9.01
- 2021-04-19 0000950142-21-001308 — 8.01, 9.01
- 2021-02-09 0001783180-21-000009 — 2.02, 9.01
- 2021-02-05 0001140361-21-003513 — 8.01, 9.01
- 2020-12-23 0001140361-20-029419 — 7.01, 9.01
- 2020-12-22 0001140361-20-029097 — 8.01
- 2020-12-14 0001140361-20-028246 — 5.03, 9.01
- 2020-12-07 0001140361-20-027515 — 1.01, 7.01, 9.01
- 2020-10-29 0001783180-20-000063 — 2.02, 9.01
- 2020-10-19 0001140361-20-023241 — 5.02, 7.01, 9.01
- 2020-09-23 0001140361-20-021220 — 8.01, 9.01
- 2020-09-22 0001140361-20-021124 — 8.01, 9.01
- 2020-07-30 0001783180-20-000045 — 2.02, 9.01
- 2020-06-19 0001140361-20-014325 — 1.01, 2.03, 9.01
- 2020-06-16 0001140361-20-013880 — 8.01, 9.01
- 2020-06-03 0001140361-20-012939 — 1.01, 9.01
- 2020-05-08 0001783180-20-000013 — 2.02, 9.01
- 2020-04-03 0001140361-20-007888 — 1.01, 5.02, 5.03, 5.05, 7.01, 9.01
- 2020-03-16 0001140361-20-005868 — 8.01, 9.01

## late-filing notifications on or before 2022-04-28

- none on or before 2022-04-28

## item 2.02 — earnings release, exhibit 99.1

[0001783180-22-000032:8k_2_02:1]
EX-99
2
a991-q12022earningsexhibit.htm
EX-99

[0001783180-22-000032:8k_2_02:2]
Document

[0001783180-22-000032:8k_2_02:3]
Exhibit 99

[0001783180-22-000032:8k_2_02:4]
Carrier Reports First Quarter 2022 Results

[0001783180-22-000032:8k_2_02:5]
•Net sales down 1% versus 2021 driven by the Chubb divestiture; organic sales up 10%

[0001783180-22-000032:8k_2_02:6]
•GAAP EPS of $1.58 and adjusted EPS of $0.54

[0001783180-22-000032:8k_2_02:7]
•Operating margin up over 2,500 basis points due to the gain on the sale of Chubb; adjusted operating margin expansion of 110 basis points

[0001783180-22-000032:8k_2_02:8]
•Price/cost neutral

[0001783180-22-000032:8k_2_02:9]
•Net cash outflows from operating activities were $202 million and free cash flow usage was $258 million

[0001783180-22-000032:8k_2_02:10]
•Reaffirming full-year 2022 outlook for sales, adjusted operating margin, adjusted EPS and free cash flow*

[0001783180-22-000032:8k_2_02:11]
PALM BEACH GARDENS, Fla., April 28, 2022 – Carrier Global Corporation (NYSE:CARR), leading global provider of healthy, safe, sustainable and intelligent building and cold chain solutions, today reported financial results for the first quarter of 2022 and reiterated its full year outlook.

[0001783180-22-000032:8k_2_02:12]
“Demand for our innovative solutions was strong in the first quarter as customers leverage our differentiated offerings to improve indoor environments and achieve their sustainability goals,” said Carrier Chairman & CEO Dave Gitlin. “This drove double-digit organic sales growth and strong adjusted operating margin expansion, both of which exceeded our expectations. We are encouraged by this momentum and confident that key secular trends and our differentiated life-cycle solutions will drive continued strong growth.”

[0001783180-22-000032:8k_2_02:13]
First Quarter 2022 Results

[0001783180-22-000032:8k_2_02:14]
Carrier’s first quarter sales of $4.7 billion were down 1% compared to the prior year and organic sales grew 10% over the same period. Excluding Chubb sales from the first quarter of 2021, sales were up about 12%. Sales strength continued in the HVAC segment, with North America residential, light commercial, and controls all up over 20% in the quarter. Refrigeration sales were up 1% organically despite the difficult comparison against

[0001783180-22-000032:8k_2_02:15]
1

[0001783180-22-000032:8k_2_02:16]
a record quarter for the Container business in 2021. Sales for the Fire and Security segment were up 4% organically. Excluding Chubb sales from the first quarter of 2021, Fire and Security segment sales were up 8%.

[0001783180-22-000032:8k_2_02:17]
GAAP operating profit in the quarter of $1.7 billion was up over 200% from last year driven by the gain on the sale of Chubb and adjusted operating profit of $650 million was up 7%. Better than expected price realization helped mitigate continued supply chain challenges related to cost and availability headwinds. Price/cost was neutral in the first quarter.

[0001783180-22-000032:8k_2_02:18]
Net income was $1.4 billion and adjusted net income was $473 million. GAAP EPS was $1.58 and adjusted EPS was $0.54. Net cash flows used in operating activities were $202 million and capital expenditures were $56 million, resulting in a free cash outflow of $258 million. The outflow was driven by working capital increases including the normal seasonal inventory build and the impact of supply chain challenges. During the first-quarter, Carrier repurchased $741 million of its common stock, repurchased $1.15 billion of its long-term notes and received $2.9 billion in cash proceeds from the divestiture of Chubb.

[0001783180-22-000032:8k_2_02:19]
Full-Year 2022 Outlook**

[0001783180-22-000032:8k_2_02:20]
Carrier reaffirmed the following outlook for 2022, excluding the pending Toshiba acquisition:

[0001783180-22-000032:8k_2_02:21]
|  |  | 2022 Outlook |  |  |
|  |  | ~$20B |  |  |
| Sales |  | Organic* up HSD |  |  |
|  |  | FX ~(1%) |  |  |
|  |  | Acquisitions ~1% |  |  |
|  |  | Divestitures ~(10%) |  |  |
| Adjusted Operating Margin * |  | Up ~75 bps Y/Y |  |  |
| Adjusted EPS * |  | $2.20 - $2.30 |  |  |
| Free Cash Flow * |  | ~$1.65B |  |  |
|  |  | Includes ~$200M in tax payments on Chubb gain |  |  |

[0001783180-22-000032:8k_2_02:22]
*Note: When the company provides expectations for organic sales, adjusted operating profit, adjusted operating margin, adjusted EPS and free cash flow on a forward-looking basis, a reconciliation of the differences between the non-GAAP expectations and the corresponding GAAP measures generally is not available without unreasonable effort. See “Use and Definitions of Non-GAAP Financial Measures” below for additional information.

[0001783180-22-000032:8k_2_02:23]
**As of April 28, 2022

[0001783180-22-000032:8k_2_02:24]
2

[0001783180-22-000032:8k_2_02:25]
Conference Call

[0001783180-22-000032:8k_2_02:26]
Carrier will host a webcast of its earnings conference call today, Thursday, April 28, 2022, at 8:30 a.m. ET. To access the webcast, visit the Events & Presentations section of the Carrier Investor Relations site at ir.carrier.com/news-and-events/events-and-presentations or to listen to the earnings call by phone, dial (877) 742-9091.

[0001783180-22-000032:8k_2_02:27]
Cautionary Statement

[0001783180-22-000032:8k_2_02:28]
This communication contains statements which, to the extent they are not statements of historical or present fact, constitute "forward-looking statements" under the securities laws. These forward-looking statements are intended to provide management's current expectations or plans for Carrier's future operating and financial performance, based on assumptions currently believed to be valid. Forward-looking statements can be identified by the use of words such as "believe," "expect," "expectations," "plans," "strategy," "prospects," "estimate," "project," "target," "anticipate," "will," "should," "see," "guidance," "outlook," "confident," "scenario" and other words of similar meaning in connection with a discussion of future operating or financial performance or the separation from United Technologies Corporation (the "Separation"), since renamed Raytheon Technologies Corporation. Forward-looking statements may include, among other things, statements relating to future sales, earnings, cash flow, results of operations, uses of cash, share repurchases, tax rates and other measures of financial performance or potential future plans, strategies or transactions of Carrier, the estimated costs associated with the Separation, Carrier's plans with respect to its indebtedness and other statements that are not historical facts. All forward-looking statements involve risks, uncertainties and other factors that may cause actual results to differ materially from those expressed or implied in the forward-looking statements. For additional information on identifying factors that may cause actual results to vary materially from those stated in forward-looking statements, see Carrier's reports on Forms 10-K, 10-Q and 8-K filed with or furnished to the U.S. Securities and Exchange Commission from time to time. Any forward-looking statement speaks only as of the date on which it is made, and Carrier assumes no obligation to update or revise such statement, whether as a result of new information, future events or otherwise, except as required by applicable law.

[0001783180-22-000032:8k_2_02:29]
3

[0001783180-22-000032:8k_2_02:30]
Contact:                        Media Inquiries

[0001783180-22-000032:8k_2_02:31]
Danielle Canzanella

[0001783180-22-000032:8k_2_02:32]
561-365-1101

[0001783180-22-000032:8k_2_02:33]
Danielle.Canzanella@Carrier.com

[0001783180-22-000032:8k_2_02:34]
Investor Relations

[0001783180-22-000032:8k_2_02:35]
Sam Pearlstein

[0001783180-22-000032:8k_2_02:36]
561-365-2251

[0001783180-22-000032:8k_2_02:37]
Sam.Pearlstein@Carrier.com

[0001783180-22-000032:8k_2_02:38]
4

[0001783180-22-000032:8k_2_02:39]
SELECTED FINANCIAL DATA, NON-GAAP MEASURES AND DEFINITIONS

[0001783180-22-000032:8k_2_02:40]
Following are tables that present selected financial data of Carrier Global Corporation (“Carrier”). Also included are reconciliations of non-GAAP measures to their most comparable GAAP measures.

[0001783180-22-000032:8k_2_02:41]
Use and Definitions of Non-GAAP Financial Measures

[0001783180-22-000032:8k_2_02:42]
Carrier reports its financial results in accordance with accounting principles generally accepted in the United States ("GAAP").

[0001783180-22-000032:8k_2_02:43]
We supplement the reporting of our financial information determined under GAAP with certain non-GAAP financial information. The non-GAAP information presented provides investors with additional useful information, but should not be considered in isolation or as substitutes for the related GAAP measures. Moreover, other companies may define non-GAAP measures differently, which limits the usefulness of these measures for comparisons with such other companies. We encourage investors to review our financial statements and publicly filed reports in their entirety and not to rely on any single financial measure. A reconciliation of the non-GAAP measures to the corresponding amounts prepared in accordance with GAAP appears in the tables attached to this release. The tables provide additional information as to the items and amounts that have been excluded from the adjusted measures.

[0001783180-22-000032:8k_2_02:44]
Organic sales, adjusted operating profit, adjusted operating margin, incremental margins / earnings conversion, earnings before interest, taxes and depreciation and amortization (“EBITDA”), adjusted EBITDA, adjusted net income, adjusted earnings per share (“EPS”), the adjusted effective tax rate, and net debt are non-GAAP financial measures.

[0001783180-22-000032:8k_2_02:45]
Organic sales represents consolidated net sales (a GAAP measure), excluding the impact of foreign currency translation, acquisitions and divestitures completed in the preceding twelve months and other significant items of a nonoperational nature (hereinafter referred to as “other significant items”). Adjusted operating profit represents operating profit (a GAAP measure), excluding restructuring costs and other significant items. Adjusted operating margin represents adjusted operating profit as a percentage of net sales (a GAAP measure). Incremental margins / earnings conversion represents the year-over-year change in adjusted operating profit divided by the year-over-year change in net sales. EBITDA represents net income attributable to common shareholders (a GAAP measure), adjusted for interest income and expense, income tax expense, and depreciation and amortization. Adjusted EBITDA represents EBITDA, as calculated above, excluding non-service pension benefit, non-controlling interest in subsidiaries’ earnings from operations, restructuring costs and other significant items. Adjusted net income represents net income attributable to common shareowners (a GAAP measure), excluding restructuring costs and other significant items. Adjusted EPS represents diluted earnings per share (a GAAP measure), excluding restructuring costs and other significant items. The adjusted effective tax rate represents the effective tax rate (a GAAP measure), excluding restructuring costs and other significant items. Net debt represents long-term debt (a GAAP measure) less cash and cash equivalents. For the business segments, when applicable, adjustments of operating profit and operating margins represent operating profit, excluding restructuring and other significant items.

[0001783180-22-000032:8k_2_02:46]
Free cash flow is a non-GAAP financial measure that represents net cash flows provided by operating activities (a GAAP measure) less capital expenditures. Management believes free cash flow is a useful measure of liquidity and an additional basis for assessing Carrier’s ability to fund its activities, including the financing of acquisitions, debt service, repurchases of Carrier's common stock and distribution of earnings to shareowners.

[0001783180-22-000032:8k_2_02:47]
When we provide our expectations for organic sales, adjusted operating profit, adjusted operating margin, adjusted effective tax rate, incremental margins/earnings conversion, adjusted EPS and free cash flow on a forward-looking basis, a reconciliation of the differences between the non-GAAP expectations and the corresponding GAAP measures (expected net sales, operating profit, operating margin, effective tax rate, incremental operating margin, diluted EPS and net cash flows provided by operating activities) generally is not available without unreasonable effort due to potentially high variability, complexity and low visibility as to the items that would be excluded from the GAAP measure in the relevant future period, such as unusual gains and losses, the ultimate outcome of pending litigation, fluctuations in foreign currency exchange rates, the impact and timing of potential acquisitions and divestitures, future restructuring costs, and other structural changes or their probable significance. The variability of the excluded items may have a significant, and potentially unpredictable, impact on our future GAAP results.

[0001783180-22-000032:8k_2_02:48]
5

[0001783180-22-000032:8k_2_02:49]
Carrier Global Corporation

[0001783180-22-000032:8k_2_02:50]
Condensed Consolidated Statement of Operations

[0001783180-22-000032:8k_2_02:51]
|  |  |  |  |  | (Unaudited) |
|  |  |  | For the Three Months Ended March 31, |
| (In millions, except per share amounts) |  |  |  |  | 2022 |  | 2021 |
| Net sales: |  |  |  |  |  |  |  |
| Product sales |  |  |  |  | $ | 4,170 |  |  | $ | 3,864 |  |
| Service sales |  |  |  |  | 484 |  |  | 835 |  |
| Total Net sales |  |  |  |  | 4,654 |  |  | 4,699 |  |
| Costs and expenses |  |  |  |  |  |  |  |
| Cost of products sold |  |  |  |  | (2,998) |  |  | (2,724) |  |
| Cost of services sold |  |  |  |  | (363) |  |  | (581) |  |
| Research and development |  |  |  |  | (125) |  |  | (121) |  |
| Selling, general and administrative |  |  |  |  | (601) |  |  | (743) |  |
| Total Costs and expenses |  |  |  |  | (4,087) |  |  | (4,169) |  |
| Equity method investment net earnings |  |  |  |  | 58 |  |  | 38 |  |
| Other income (expense), net |  |  |  |  | 1,112 |  |  | 3 |  |
| Operating profit |  |  |  |  | 1,737 |  |  | 571 |  |
| Non-service pension (expense) benefit |  |  |  |  | (1) |  |  | 18 |  |
| Interest (expense) income, net |  |  |  |  | (48) |  |  | (93) |  |
| Income from operations before income taxes |  |  |  |  | 1,688 |  |  | 496 |  |
| Income tax (expense) benefit |  |  |  |  | (301) |  |  | (104) |  |
| Net income from operations |  |  |  |  | 1,387 |  |  | 392 |  |
| Less: Non-controlling interest in subsidiaries' earnings from operations |  |  |  |  | 8 |  |  | 8 |  |
| Net income attributable to common shareowners |  |  |  |  | $ | 1,379 |  |  | $ | 384 |  |
| Earnings per share |  |  |  |  |  |  |  |
| Basic |  |  |  |  | $ | 1.62 |  |  | $ | 0.44 |  |
| Diluted |  |  |  |  | $ | 1.58 |  |  | $ | 0.43 |  |
| Weighted average number of shares outstanding |  |  |  |  |  |  |  |
| Basic |  |  |  |  | 853.3 |  | 869.3 |
| Diluted |  |  |  |  | 874.1 |  | 889.8 |

[0001783180-22-000032:8k_2_02:52]
6

[0001783180-22-000032:8k_2_02:53]
Carrier Global Corporation

[0001783180-22-000032:8k_2_02:54]
Condensed Consolidated Balance Sheet

[0001783180-22-000032:8k_2_02:55]
|  |  | (Unaudited) |
| (In millions) |  | March 31, 2022 |  | December 31, 2021 |
| Assets |  |  |  |  |
| Cash and cash equivalents |  | $ | 3,604 |  |  | $ | 2,987 |  |
| Accounts receivable, net |  | 2,599 |  |  | 2,403 |  |
| Contract assets, current |  | 655 |  |  | 503 |  |
| Inventories, net |  | 2,358 |  |  | 1,970 |  |
| Assets held for sale |  | — |  |  | 3,168 |  |
| Other assets, current |  | 386 |  |  | 376 |  |
| Total current assets |  | 9,602 |  |  | 11,407 |  |
| Future income tax benefits |  | 517 |  |  | 563 |  |
| Fixed assets, net |  | 1,825 |  |  | 1,826 |  |
| Operating lease right-of-use assets |  | 596 |  |  | 640 |  |
| Intangible assets, net |  | 488 |  |  | 509 |  |
| Goodwill |  | 9,288 |  |  | 9,349 |  |
| Pension and post-retirement assets |  | 37 |  |  | 43 |  |
| Equity method investments |  | 1,638 |  |  | 1,593 |  |
| Other assets |  | 202 |  |  | 242 |  |
| Total Assets |  | $ | 24,193 |  |  | $ | 26,172 |  |
| Liabilities and Equity |  |  |  |  |
| Accounts payable |  | $ | 2,519 |  |  | $ | 2,334 |  |
| Accrued liabilities |  | 2,330 |  |  | 2,561 |  |
| Contract liabilities, current |  | 426 |  |  | 415 |  |
| Liabilities held for sale |  | — |  |  | 1,134 |  |
| Current portion of long-term debt |  | 256 |  |  | 183 |  |
| Total current liabilities |  | 5,531 |  |  | 6,627 |  |
| Long-term debt |  | 8,305 |  |  | 9,513 |  |
| Future pension and post-retirement obligations |  | 376 |  |  | 380 |  |
| Future income tax obligations |  | 366 |  |  | 354 |  |
| Operating lease liabilities |  | 491 |  |  | 527 |  |
| Other long-term liabilities |  | 1,694 |  |  | 1,677 |  |
| Total Liabilities |  | 16,763 |  |  | 19,078 |  |
| Equity |  |  |  |  |
| Common stock |  | 9 |  |  | 9 |  |
| Treasury stock |  | (1,270) |  |  | (529) |  |
| Additional paid-in capital |  | 5,415 |  |  | 5,411 |  |
| Retained earnings |  | 4,244 |  |  | 2,865 |  |
| Accumulated other comprehensive loss |  | (1,297) |  |  | (989) |  |
| Non-controlling interest |  | 329 |  |  | 327 |  |
| Total Equity |  | 7,430 |  |  | 7,094 |  |
| Total Liabilities and Equity |  | $ | 24,193 |  |  | $ | 26,172 |  |

[0001783180-22-000032:8k_2_02:56]
7

[0001783180-22-000032:8k_2_02:57]
Carrier Global Corporation

[0001783180-22-000032:8k_2_02:58]
Condensed Consolidated Statement of Cash Flows

[0001783180-22-000032:8k_2_02:59]
|  |  |  |  | (Unaudited) |
|  |  |  | For the Three Months Ended March 31, |
| (In millions) |  |  |  |  | 2022 |  | 2021 |
| Operating Activities |  |  |  |  |  |  |  |
| Net income from operations |  |  |  |  | $ | 1,387 |  |  | $ | 392 |  |
| Adjustments to reconcile net income to net cash flows from operating activities: |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  |  |  | 79 |  |  | 83 |  |
| Deferred income tax provision |  |  |  |  | 48 |  |  | (2) |  |
| Stock-based compensation costs |  |  |  |  | 21 |  |  | 19 |  |
| Equity method investment net earnings |  |  |  |  | (58) |  |  | (38) |  |
| Distributions from equity method investments |  |  |  |  | 11 |  |  | 12 |  |
| (Gain) loss on extinguishment of debt |  |  |  |  | (36) |  |  | — |  |
| (Gain) loss on sale of investments |  |  |  |  | (1,112) |  |  | — |  |
| Changes in operating assets and liabilities |  |  |  |  |  |  |  |
| Accounts receivable, net |  |  |  |  | (207) |  |  | (83) |  |
| Contract assets, current |  |  |  |  | (154) |  |  | (44) |  |
| Inventories, net |  |  |  |  | (390) |  |  | (248) |  |
| Other assets, current |  |  |  |  | (15) |  |  | (23) |  |
| Accounts payable and accrued liabilities |  |  |  |  | 132 |  |  | 151 |  |
| Contract liabilities, current |  |  |  |  | 13 |  |  | 39 |  |
| Defined benefit plan contributions |  |  |  |  | (4) |  |  | (24) |  |
| Other operating activities, net |  |  |  |  | 83 |  |  | (50) |  |
| Net cash flows provided by (used in) operating activities |  |  |  |  | (202) |  |  | 184 |  |
| Investing Activities |  |  |  |  |  |  |  |
| Capital expenditures |  |  |  |  | (56) |  |  | (53) |  |
| Investments in businesses, net of cash acquired |  |  |  |  | (9) |  |  | (6) |  |
| Disposition of businesses |  |  |  |  | 2,935 |  |  | — |  |
| Settlement of derivative contracts, net |  |  |  |  | (32) |  |  | 8 |  |
| Other investing activities, net |  |  |  |  | (18) |  |  | 2 |  |
| Net cash flows provided by (used in) investing activities |  |  |  |  | 2,820 |  |  | (49) |  |
| Financing Activities |  |  |  |  |  |  |  |
| Increase (decrease) in short-term borrowings, net |  |  |  |  | (33) |  |  | 28 |  |
| Issuance of long-term debt |  |  |  |  | 14 |  |  | 51 |  |
| Repayment of long-term debt |  |  |  |  | (1,123) |  |  | (570) |  |
| Repurchases of common stock |  |  |  |  | (734) |  |  | (36) |  |
| Dividends paid on common stock |  |  |  |  | (129) |  |  | (104) |  |
| Dividends paid to non-controlling interest |  |  |  |  | — |  |  | (5) |  |
| Other financing activities, net |  |  |  |  | (15) |  |  | (7) |  |
| Net cash flows provided by (used in) financing activities |  |  |  |  | (2,020) |  |  | (643) |  |
| Effect of foreign exchange rate changes on cash and cash equivalents |  |  |  |  | (1) |  |  | (9) |  |
| Net increase (decrease) in cash and cash equivalents and restricted cash |  |  |  |  | 597 |  |  | (517) |  |
| Cash, cash equivalents and restricted cash, beginning of period |  |  |  |  | 3,025 |  |  | 3,120 |  |
| Cash, cash equivalents and restricted cash, end of period |  |  |  |  | 3,622 |  |  | 2,603 |  |
| Less: restricted cash |  |  |  |  | 18 |  |  | 4 |  |
| Cash and cash equivalents, end of period |  |  |  |  | $ | 3,604 |  |  | $ | 2,599 |  |

[0001783180-22-000032:8k_2_02:60]
8

[0001783180-22-000032:8k_2_02:61]
Carrier Global Corporation

[0001783180-22-000032:8k_2_02:62]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP)

[0001783180-22-000032:8k_2_02:63]
Operating Profit

[0001783180-22-000032:8k_2_02:64]
|  | (Unaudited) |
|  | For the Three Months Ended March 31, 2022 |
| (In millions) | HVAC |  | Refrigeration |  | Fire & Security |  | Eliminations and Other |  | General Corporate Expenses |  | Carrier |
| Net sales | $ | 2,970 |  |  | $ | 976 |  |  | $ | 818 |  |  | $ | (110) |  |  | $ | — |  |  | $ | 4,654 |  |
| Segment operating profit | $ | 470 |  |  | $ | 107 |  |  | $ | 1,218 |  |  | $ | (24) |  |  | $ | (34) |  |  | $ | 1,737 |  |
| Reported operating margin | 15.8 | % |  | 11.0 | % |  | 148.9 | % |  |  |  |  |  | 37.3 | % |
| Adjustments to segment operating profit: |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring costs | $ | 4 |  |  | $ | — |  |  | $ | 6 |  |  | $ | — |  |  | $ | — |  |  | $ | 10 |  |
| Chubb gain | — |  |  | — |  |  | (1,112) |  |  | — |  |  | — |  |  | (1,112) |  |
| Acquisition and other related costs | — |  |  | — |  |  | — |  |  | — |  |  | 6 |  |  | 6 |  |
| Russia/Ukraine asset impairment | — |  |  | 5 |  |  | 4 |  |  | — |  |  | — |  |  | 9 |  |
| Total adjustments to operating profit | $ | 4 |  |  | $ | 5 |  |  | $ | (1,102) |  |  | $ | — |  |  | $ | 6 |  |  | $ | (1,087) |  |
| Adjusted operating profit | $ | 474 |  |  | $ | 112 |  |  | $ | 116 |  |  | $ | (24) |  |  | $ | (28) |  |  | $ | 650 |  |
| Adjusted operating margin | 16.0 | % |  | 11.5 | % |  | 14.2 | % |  |  |  |  |  | 14.0 | % |

[0001783180-22-000032:8k_2_02:65]
|  | (Unaudited) |
|  | For the Three Months Ended March 31, 2021 |
| (In millions) | HVAC |  | Refrigeration |  | Fire & Security |  | Eliminations and Other |  | General Corporate Expenses |  | Carrier |
| Net sales | $ | 2,486 |  |  | $ | 1,005 |  |  | $ | 1,304 |  |  | $ | (96) |  |  | $ | — |  |  | $ | 4,699 |  |
| Segment operating profit | $ | 365 |  |  | $ | 127 |  |  | $ | 150 |  |  | $ | (40) |  |  | $ | (31) |  |  | $ | 571 |  |
| Reported operating margin | 14.7 | % |  | 12.6 | % |  | 11.5 | % |  |  |  |  |  | 12.2 | % |
| Adjustments to segment operating profit: |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring costs | $ | 4 |  |  | $ | 2 |  |  | $ | 11 |  |  | $ | — |  |  | $ | 1 |  |  | $ | 18 |  |
| Chubb transaction costs | — |  |  | — |  |  | 3 |  |  | — |  |  | — |  |  | 3 |  |
| Separation costs | — |  |  | — |  |  | — |  |  | 15 |  |  | 1 |  | 16 |  |
| Total adjustments to operating profit | $ | 4 |  |  | $ | 2 |  |  | $ | 14 |  |  | $ | 15 |  |  | $ | 2 |  |  | $ | 37 |  |
| Adjusted operating profit | $ | 369 |  |  | $ | 129 |  |  | $ | 164 |  |  | $ | (25) |  |  | $ | (29) |  |  | $ | 608 |  |
| Adjusted operating margin | 14.8 | % |  | 12.8 | % |  | 12.6 | % |  |  |  |  |  | 12.9 | % |

[0001783180-22-000032:8k_2_02:66]
9

[0001783180-22-000032:8k_2_02:67]
Carrier Global Corporation

[0001783180-22-000032:8k_2_02:68]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP) Results

[0001783180-22-000032:8k_2_02:69]
Net Income, Earnings Per Share, and Effective Tax Rate

[0001783180-22-000032:8k_2_02:70]
|  |  |  |  |  |  |  | (Unaudited) |
|  |  |  | For the Three Months Ended March 31, 2022 |
| (In millions, except per share amounts) |  |  |  |  |  |  | Reported |  | Adjustments |  | Adjusted |
| Net sales |  |  |  |  |  |  | $ | 4,654 |  |  | $ | — |  |  | $ | 4,654 |  |
| Operating profit |  |  |  |  |  |  | $ | 1,737 |  |  | (1,087) |  | a | $ | 650 |  |
| Operating margin |  |  |  |  |  |  | 37.3 | % |  |  |  | 14.0 | % |
| Income from operations before income taxes |  |  |  |  |  |  | $ | 1,688 |  |  | (1,115) |  | a,b | $ | 573 |  |
| Income tax expense |  |  |  |  |  |  | $ | (301) |  |  | 209 |  | c | $ | (92) |  |
| Income tax rate |  |  |  |  |  |  | 17.8 | % |  |  |  | 16.0 | % |
| Net income attributable to common shareowners |  |  |  |  |  |  | $ | 1,379 |  |  | $ | (906) |  |  | $ | 473 |  |
| Summary of Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring costs |  |  |  |  |  |  |  |  | $ | 10 |  | a |  |
| Chubb (gain) loss |  |  |  |  |  |  |  |  | (1,112) |  | a |  |
| Acquisition and other |  |  |  |  |  |  |  |  | 6 |  | a |  |
| Russia/Ukraine asset impairment |  |  |  |  |  |  |  |  | 9 |  | a |  |
| Debt extinguishment (gain), net (1) |  |  |  |  |  |  |  |  | (28) |  | b |  |
| Total adjustments |  |  |  |  |  |  |  |  | $ | (1,115) |  |  |  |
| Tax effect on adjustments above |  |  |  |  |  |  |  |  | $ | 209 |  |  |  |
| Total tax adjustments |  |  |  |  |  |  |  |  | $ | 209 |  | c |  |
| Shares outstanding - Diluted |  |  |  |  |  |  | 874.1 |  |  |  |  | 874.1 |  |
| Earnings per share - Diluted |  |  |  |  |  |  | $ | 1.58 |  |  |  |  | $ | 0.54 |  |

[0001783180-22-000032:8k_2_02:71]
(1) The Company repurchased approximately $1.15 billion of aggregate principal senior notes on March 30, 2022 and recognized a net gain of $33 million and wrote-off $5 million of unamortized deferred financing costs in Interest (expense) income, net on the accompanying Unaudited Condensed Consolidated Statement of Operations.

[0001783180-22-000032:8k_2_02:72]
10

[0001783180-22-000032:8k_2_02:73]
Carrier Global Corporation

[0001783180-22-000032:8k_2_02:74]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP) Results

[0001783180-22-000032:8k_2_02:75]
Net Income, Earnings Per Share, and Effective Tax Rate

[0001783180-22-000032:8k_2_02:76]
|  |  |  |  |  |  |  | (Unaudited) |
|  |  |  | For the Three Months Ended March 31, 2021 |
| (In millions, except per share amounts) |  |  |  |  |  |  | Reported |  | Adjustments |  | Adjusted |
| Net sales |  |  |  |  |  |  | $ | 4,699 |  |  | $ | — |  |  | $ | 4,699 |  |
| Operating profit |  |  |  |  |  |  | $ | 571 |  |  | 37 |  | a | $ | 608 |  |
| Operating margin |  |  |  |  |  |  | 12.2 | % |  |  |  | 12.9 | % |
| Income from operations before income taxes |  |  |  |  |  |  | $ | 496 |  |  | 56 |  | a,b | $ | 552 |  |
| Income tax expense |  |  |  |  |  |  | $ | (104) |  |  | (13) |  | c | $ | (117) |  |
| Income tax rate |  |  |  |  |  |  | 21.0 | % |  |  |  | 21.1 | % |
| Net income attributable to common shareowners |  |  |  |  |  |  | $ | 384 |  |  | $ | 43 |  |  | $ | 427 |  |
| Summary of Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring costs |  |  |  |  |  |  |  |  | $ | 18 |  | a |  |
| Separation costs |  |  |  |  |  |  |  |  | 16 |  | a |  |
| Acquisition and other related costs |  |  |  |  |  |  |  |  | 3 |  | a |  |
| Debt issuance costs |  |  |  |  |  |  |  |  | 19 |  | b |  |
| Total adjustments |  |  |  |  |  |  |  |  | $ | 56 |  |  |  |
| Tax effect on adjustments above |  |  |  |  |  |  |  |  | $ | (13) |  |  |  |
| Total tax adjustments |  |  |  |  |  |  |  |  | $ | (13) |  | c |  |
| Shares outstanding - Diluted |  |  |  |  |  |  | 889.8 |  |  |  |  | 889.8 |  |
| Earnings per share - Diluted |  |  |  |  |  |  | $ | 0.43 |  |  |  |  | $ | 0.48 |  |

[0001783180-22-000032:8k_2_02:77]
11

[0001783180-22-000032:8k_2_02:78]
Carrier Global Corporation

[0001783180-22-000032:8k_2_02:79]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP) Results

[0001783180-22-000032:8k_2_02:80]
Components of Changes in Net Sales

[0001783180-22-000032:8k_2_02:81]
| For the Three Months Ended March 31, 2022 Compared with the Three Months Ended March 31, 2021 |
|  | (Unaudited) |
|  | Factors Contributing to Total % change in Net Sales |
|  | Organic |  | FX Translation |  | Acquisitions / Divestitures, net |  | Other |  | Total |
| HVAC | 18 | % |  | (2) | % |  | 3 | % |  | — | % |  | 19 | % |
| Refrigeration | 1 | % |  | (4) | % |  | — | % |  | — | % |  | (3) | % |
| Fire & Security | 4 | % |  | (1) | % |  | (40) | % |  | — | % |  | (37) | % |
| Consolidated | 10 | % |  | (1) | % |  | (10) | % |  | — | % |  | (1) | % |

[0001783180-22-000032:8k_2_02:82]
Carrier Global Corporation

[0001783180-22-000032:8k_2_02:83]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP) Results

[0001783180-22-000032:8k_2_02:84]
Net Sales Excluding Impact of Chubb

[0001783180-22-000032:8k_2_02:85]
|  | (Unaudited) |
|  | For the Three Months Ended March 31, 2021 |
|  | Carrier |  | Fire and Security |
| Net Sales: |  |  |  |
| Reported | $ | 4,699 |  |  | $ | 1,304 |  |
| Chubb | (548) |  |  | (548) |  |
| Net sales excluding impact of Chubb | $ | 4,151 |  |  | $ | 756 |  |
| Percentage increase in Net sales excluding impact of Chubb | 12 | % |  | 8 | % |

[0001783180-22-000032:8k_2_02:86]
Free Cash Flow Reconciliation

[0001783180-22-000032:8k_2_02:87]
|  |  | (Unaudited) |
|  |  | Q1 |  | Q2 |  | Q3 |  | Q4 |  | FY |  | Q1 |  |  |  |  |
| (In millions) |  | 2021 |  | 2021 |  | 2021 |  | 2021 |  | 2021 |  | 2022 |  |  |  |  |
| Net cash flows provided by (used in) operating activities |  | $ | 184 |  |  | $ | 561 |  |  | $ | 579 |  |  | $ | 913 |  |  | $ | 2,237 |  |  | $ | (202) |  |  |  |  |  |
| Less: Capital expenditures |  | 53 |  |  | 79 |  |  | 74 |  |  | 138 |  | 344 |  |  | 56 |  |  |  |  |  |
| Free cash flow |  | $ | 131 |  |  | $ | 482 |  |  | $ | 505 |  |  | $ | 775 |  |  | $ | 1,893 |  |  | $ | (258) |  |  |  |  |  |

[0001783180-22-000032:8k_2_02:88]
12

[0001783180-22-000032:8k_2_02:89]
Net Debt Reconciliation

[0001783180-22-000032:8k_2_02:90]
|  |  | (Unaudited) |
| (In millions) |  | March 31, 2022 |  | December 31, 2021 |
| Long-term debt |  | $ | 8,305 |  |  | $ | 9,513 |  |
| Current portion of long-term debt |  | 256 |  |  | 183 |  |
| Less: Cash and cash equivalents |  | 3,604 |  |  | 2,987 |  |
| Net debt |  | $ | 4,957 |  |  | $ | 6,709 |  |

[0001783180-22-000032:8k_2_02:91]
13
