# CARR notes — 0001783180-22-000034


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001783180-22-000034:notes:1]
DESCRIPTION OF THE BUSINESS 
Carrier Global Corporation is a leading global provider of healthy, safe, sustainable and intelligent building and cold chain solutions. The Company's portfolio includes industry-leading brands such as Carrier, Automated Logic, Carrier Transicold, Kidde, Edwards and LenelS2 that offer innovative heating, ventilating, air conditioning ("HVAC"), refrigeration, fire, security and building automation technologies to help make the world safer and more comfortable. The Company also provides a broad array of related building services, including audit, design, installation, system integration, repair, maintenance and monitoring.

[0001783180-22-000034:notes:2]
In the opinion of management, the accompanying Unaudited Condensed Consolidated Financial Statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission (the "SEC"). These Unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for 2021 filed with the SEC on February 8, 2022 (the "2021 Form 10-K").

[0001783180-22-000034:notes:3]
[same as prior period, unchanged from 0001783180-21-000065:notes:4]

[0001783180-22-000034:notes:4]
In early 2020, the World Health Organization declared the outbreak of a respiratory disease known as COVID-19 as a global pandemic. In response, many countries implemented containment and mitigation measures to combat the outbreak, which severely restricted the level of economic activity and caused a significant contraction in the global economy. As a result, the Company took several preemptive actions to manage liquidity, preserve the health and safety of its employees and customers as well as maintain the continuity of its operations. The preparation of financial statements requires management to use judgments in making estimates and assumptions based on the relevant information available at the end of each period, which can have a significant effect on reported amounts. However, due to significant uncertainty surrounding the pandemic, including a resurgence in cases and the spread of COVID-19 variants, management's judgments could change. While the Company's results of operations, cash flows and financial condition could be negatively impacted, the extent of any continuing impact cannot be estimated with certainty at this time.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001783180-22-000034:notes:5]
BASIS OF PRESENTATION
The Unaudited Condensed Consolidated Financial Statements include all accounts of the Company and its wholly-owned and majority-owned subsidiaries in which it has control. All intra-company accounts and transactions have been eliminated. Related party transactions between the Company and its equity method investees have not been eliminated. Non-controlling interest represents a non-controlling investor's interests in the results of subsidiaries that the Company controls and consolidates.

[0001783180-22-000034:notes:6]
Sale of Chubb Fire & Security Business

[0001783180-22-000034:notes:7]
On July 26, 2021, the Company entered into a stock purchase agreement to sell its Chubb Fire and Security business ("Chubb") to APi Group Corporation ("APi"). As a result, the assets and liabilities of Chubb are presented as held for sale on the accompanying Unaudited Condensed Consolidated Balance Sheet as of December 31, 2021 and recorded at the lower of their carrying value or fair value less estimated cost to sell. The sale of Chubb was completed on January 3, 2022 (the "Chubb Sale"). See Note 16 - Divestitures for additional information.

[0001783180-22-000034:notes:8]
Separation from United Technologies

[0001783180-22-000034:notes:9]
On April 3, 2020, United Technologies Corporation, since renamed Raytheon Technologies Corporation ("UTC"), completed the spin-off of the Company into an independent, publicly traded company (the "Separation") through a pro-rata distribution (the "Distribution") on a one-for-one basis of all of the outstanding shares of common stock of the Company to UTC shareowners who held shares of UTC common stock as of the close of business on March 19, 2020, the record date of the Distribution. The Company incurred separation-related costs including employee-related costs, costs to establish certain stand-alone functions, information technology systems, professional service fees and other costs associated with becoming an independent, publicly traded company. These costs are primarily recorded in Selling, general and administrative in the Unaudited Condensed Consolidated Statement of Operations and totaled $16 million for the three months ended March 31, 2021.

[0001783180-22-000034:notes:10]
Recently Issued and Adopted Accounting Pronouncements

[0001783180-22-000034:notes:11]
The Financial Accounting Standards Board ("FASB") Accounting Standards Codification ("ASC") is the sole source of authoritative U.S. GAAP other than SEC issued rules and regulations that apply only to SEC registrants. The FASB issues Accounting Standards Updates ("ASU") to communicate changes to the codification. The Company considers the applicability and impact of all ASUs. ASUs pending adoption were assessed and determined to be either not applicable or not expected to have a material impact on the Unaudited Condensed Consolidated Financial Statements.


## us-gaap:InventoryDisclosureTextBlock

[0001783180-22-000034:notes:12]
INVENTORIES, NET 
Inventories are stated at the lower of cost or estimated net realizable value. Cost is primarily determined based on the first-in, first-out inventory method ("FIFO") or average cost methods, which approximates current replacement cost. However, certain subsidiaries use the last-in, first-out inventory method ("LIFO").

[0001783180-22-000034:notes:13]
Inventories, net consisted of the following:

[0001783180-22-000034:notes:14]
| (In millions) |  | March 31, 2022 |  | December 31, 2021 |
| Raw materials |  | $ | 670 |  |  | $ | 559 |  |
| Work-in-process |  | 260 |  |  | 197 |  |
| Finished goods |  | 1,428 |  |  | 1,214 |  |
| Inventories, net |  | $ | 2,358 |  |  | $ | 1,970 |  |

[0001783180-22-000034:notes:15]
The Company performs periodic assessments utilizing customer demand, production requirements and historical usage rates to determine the existence of excess and obsolete inventory and records necessary provisions to reduce such inventories to the lower of cost or estimated net realizable value. Raw materials, work-in-process and finished goods are net of valuation reserves of $160 million and $154 million as of March 31, 2022 and December 31, 2021, respectively.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001783180-22-000034:notes:16]
[same as prior period, unchanged from 0001783180-21-000065:notes:18]

[0001783180-22-000034:notes:17]
The changes in the carrying amount of goodwill were as follows:

[0001783180-22-000034:notes:18]
| (In millions) |  |  | HVAC |  | Refrigeration |  | Fire & Security |  | Total |
| Balance as of December 31, 2021 |  |  | $ | 5,658 |  |  | $ | 1,228 |  |  | $ | 2,463 |  |  | $ | 9,349 |  |
| Goodwill resulting from business combinations (1) |  |  | 3 |  |  | — |  |  | 1 |  |  | 4 |  |
| Foreign currency translation |  |  | (36) |  |  | (8) |  |  | (21) |  |  | (65) |  |
| Balance as of March 31, 2022 |  |  | $ | 5,625 |  |  | $ | 1,220 |  |  | $ | 2,443 |  |  | $ | 9,288 |  |

[0001783180-22-000034:notes:19]
(1) See Note 15 - Acquisitions for additional information.

[0001783180-22-000034:notes:20]
Indefinite-lived intangible assets are tested and reviewed annually for impairment on July 1 or whenever there is a material change in events or circumstances that indicates that the fair value of the asset may be less than the carrying amount of the asset. All other intangible assets with finite useful lives are amortized over their estimated useful lives.

[0001783180-22-000034:notes:21]
Identifiable intangible assets consisted of the following:

[0001783180-22-000034:notes:22]
|  |  | March 31, 2022 |  | December 31, 2021 |
| (In millions) |  | Gross Amount |  | Accumulated Amortization |  | Net Amount |  | Gross Amount |  | Accumulated Amortization |  | Net Amount |
| Amortized: |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 940 |  |  | $ | (705) |  |  | $ | 235 |  |  | $ | 945 |  |  | $ | (699) |  |  | $ | 246 |  |
| Patents and trademarks |  | 231 |  |  | (183) |  |  | 48 |  |  | 232 |  |  | (182) |  |  | 50 |  |
| Service portfolios and other |  | 683 |  |  | (542) |  |  | 141 |  |  | 688 |  |  | (539) |  |  | 149 |  |
|  |  | 1,854 |  |  | (1,430) |  |  | 424 |  |  | 1,865 |  |  | (1,420) |  |  | 445 |  |
| Unamortized: |  |  |  |  |  |  |  |  |  |  |  |  |
| Trademarks and other |  | 64 |  |  | — |  |  | 64 |  |  | 64 |  |  | — |  |  | 64 |  |
| Intangible assets, net |  | $ | 1,918 |  |  | $ | (1,430) |  |  | $ | 488 |  |  | $ | 1,929 |  |  | $ | (1,420) |  |  | $ | 509 |  |

[0001783180-22-000034:notes:23]
Amortization of intangible assets was $21 million and $24 million for the three months ended March 31, 2022 and 2021, respectively.


## us-gaap:DebtDisclosureTextBlock

[0001783180-22-000034:notes:24]
BORROWINGS AND LINES OF CREDIT 
Long-term debt consisted of the following:

[0001783180-22-000034:notes:25]
| (In millions) |  |  |  | March 31,2022 |  | December 31,2021 |
| 2.242% Notes due February 15, 2025 |  |  |  | $ | 1,200 |  |  | $ | 2,000 |  |
| 2.493% Notes due February 15, 2027 |  |  |  | 900 |  |  | 1,250 |  |
| 2.722% Notes due February 15, 2030 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.700% Notes due February 15, 2031 |  |  |  | 750 |  |  | 750 |  |
| 3.377% Notes due April 5, 2040 |  |  |  | 1,500 |  |  | 1,500 |  |
| 3.577% Notes due April 5, 2050 |  |  |  | 2,000 |  |  | 2,000 |  |
| Total Long-term notes |  |  |  | 8,350 |  |  | 9,500 |  |
| Other debt (including project financing obligations and finance leases) |  |  |  | 275 |  |  | 267 |  |
| Discounts and debt issuance costs |  |  |  | (64) |  |  | (71) |  |
| Total debt |  |  |  | 8,561 |  |  | 9,696 |  |
| Less: current portion of long-term debt |  |  |  | 256 |  |  | 183 |  |
| Long-term debt, net of current portion |  |  |  | $ | 8,305 |  |  | $ | 9,513 |  |

[0001783180-22-000034:notes:26]
Revolving Credit Facility

[0001783180-22-000034:notes:27]
On February 10, 2020, the Company entered into a revolving credit agreement with various banks permitting aggregate borrowings of up to $2.0 billion pursuant to an unsecured, unsubordinated revolving credit facility that matures on April 3, 2025 (the "Revolving Credit Facility"). The Revolving Credit Facility supports the Company's commercial paper program and cash requirements of the Company. A commitment fee of 0.125% is charged on unused commitments. Borrowings under the Revolving Credit Facility are available in U.S. Dollars, Euros and Pounds Sterling and bear interest at a variable interest rate plus a ratings-based margin, which was 125 basis points as of March 31, 2022. As of March 31, 2022, there were no borrowings outstanding under the Revolving Credit Facility.

[0001783180-22-000034:notes:28]
Commercial Paper Program

[0001783180-22-000034:notes:29]
The Company has a $2.0 billion unsecured, unsubordinated commercial paper program, which can be used for general corporate purposes, including the funding of working capital and potential acquisitions. As of March 31, 2022, there were no borrowings outstanding under the commercial paper program.

[0001783180-22-000034:notes:30]
Project Financing Arrangements

[0001783180-22-000034:notes:31]
The Company is involved in several long-term construction contracts in which it arranges project financing with certain customers. As a result, the Company issued $14 million and $46 million of debt during the three months ended March 31, 2022 and 2021, respectively. Long-term debt repayments associated with these financing arrangements during the three months ended March 31, 2022 and 2021 were $8 million and $53 million, respectively.

[0001783180-22-000034:notes:32]
Debt Covenants

[0001783180-22-000034:notes:33]
The Revolving Credit Facility and the indenture for the Long-term notes contain affirmative and negative covenants customary for financings of these types, which, among other things, limit the Company's ability to incur additional liens, to make certain fundamental changes and to enter into sale and leaseback transactions. As of March 31, 2022, the Company was in compliance with the covenants under the agreements governing its outstanding indebtedness.

[0001783180-22-000034:notes:34]
Tender Offers

[0001783180-22-000034:notes:35]
On March 15, 2022, the Company commenced tender offers to purchase up to $1.15 billion ("Aggregate Tender Cap") aggregate principal of the Company's 2.242% Notes due 2025 and 2.493% Notes due 2027 (together, the "Senior Notes"). The tender offers included payment of applicable accrued and unpaid interest up to the settlement date, along with a fixed spread for early repayment. Based on participation, the Company elected to settle the tender offers on March 30, 2022. The aggregate principal amount of Senior Notes validly tendered and accepted was approximately $1.15 billion, which included $800 million of Notes due 2025 and $350 million of Notes due 2027. Upon settlement, the Company recognized a net gain of $33 million and wrote off $5 million of unamortized deferred financing costs within Interest (expense) income, net on the accompanying Unaudited Condensed Consolidated Statement of Operations.


## us-gaap:FairValueDisclosuresTextBlock

[0001783180-22-000034:notes:36]
[same as prior period, unchanged from 0001783180-21-000065:notes:41]

[0001783180-22-000034:notes:37]
[same as prior period, unchanged from 0001783180-21-000065:notes:42]

[0001783180-22-000034:notes:38]
[same as prior period, unchanged from 0001783180-21-000065:notes:43]

[0001783180-22-000034:notes:39]
[same as prior period, unchanged from 0001783180-21-000065:notes:44]

[0001783180-22-000034:notes:40]
[same as prior period, unchanged from 0001783180-21-000065:notes:45]

[0001783180-22-000034:notes:41]
In the normal course of business, the Company is exposed to certain risks arising from business operations and economic factors, including foreign currency and commodity price risk. These exposures are managed through operational strategies and the use of undesignated hedging contracts. The Company's derivative assets and liabilities are measured at fair value on a recurring basis using internal models based on observable market inputs, such as forward, interest, contract and discount rates with changes in fair value reported directly in earnings.

[0001783180-22-000034:notes:42]
The following tables provide the valuation hierarchy classification of assets and liabilities that are recorded at fair value and

[0001783180-22-000034:notes:43]
measured on a recurring basis in the Company's Unaudited Condensed Consolidated Balance Sheet:

[0001783180-22-000034:notes:44]
| (In millions) |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |
| March 31, 2022 |  |  |  |  |  |  |  |  |
| Derivative assets (1) |  | $ | 19 |  |  | $ | — |  |  | $ | 19 |  |  | $ | — |  |
| Derivative liabilities (2) |  | $ | (9) |  |  | $ | — |  |  | $ | (9) |  |  | $ | — |  |
| December 31, 2021 |  |  |  |  |  |  |  |  |
| Derivative assets (1) |  | $ | 8 |  |  | $ | — |  |  | $ | 8 |  |  | $ | — |  |
| Derivative liabilities (2) |  | $ | (35) |  |  | $ | — |  |  | $ | (35) |  |  | $ | — |  |

[0001783180-22-000034:notes:45]
(1) Included in Other assets, current on the accompanying Unaudited Condensed Consolidated Balance Sheet.

[0001783180-22-000034:notes:46]
(2) Included in Accrued liabilities on the accompanying Unaudited Condensed Consolidated Balance Sheet.

[0001783180-22-000034:notes:47]
The following table provides the carrying amounts and fair values of the Company's Long-term notes that are not recorded at fair value in the Unaudited Condensed Consolidated Balance Sheet:

[0001783180-22-000034:notes:48]
|  |  | March 31, 2022 |  | December 31, 2021 |  |
| (In millions) |  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  |
| Total Long-term Notes (1) |  | $ | 8,350 |  |  | $ | 7,812 |  |  | $ | 9,500 |  |  | $ | 9,842 |  |  |

[0001783180-22-000034:notes:49]
(1) Excludes debt discount and issuance costs.

[0001783180-22-000034:notes:50]
The fair value of the Company's Long-term debt is measured based on observable market inputs which are considered Level 1 within the fair value hierarchy. The carrying value of cash and cash equivalents, accounts receivable, accounts payable and short-term borrowings approximate fair value due to the short-term nature of these accounts and would be classified as Level 1 in the fair value hierarchy. The Company's financing leases and project financing obligations, included in Long-term debt and Current portion of long-term debt on the accompanying Unaudited Condensed Consolidated Balance Sheet, approximate fair value and are classified as Level 3 in the fair value hierarchy.


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0001783180-22-000034:notes:51]
In the normal course of business, the Company is exposed to certain risks arising from business operations and economic factors, including foreign currency and commodity price risk. These exposures are managed through operational strategies and the use of undesignated hedging contracts. The Company's derivative assets and liabilities are measured at fair value on a recurring basis using internal models based on observable market inputs, such as forward, interest, contract and discount rates with changes in fair value reported directly in earnings. The fair value of the Company's Long-term debt is measured based on observable market inputs which are considered Level 1 within the fair value hierarchy. The carrying value of cash and cash equivalents, accounts receivable, accounts payable and short-term borrowings approximate fair value due to the short-term nature of these accounts and would be classified as Level 1 in the fair value hierarchy. The Company's financing leases and project financing obligations, included in Long-term debt and Current portion of long-term debt on the accompanying Unaudited Condensed Consolidated Balance Sheet, approximate fair value and are classified as Level 3 in the fair value hierarchy.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001783180-22-000034:notes:52]
EMPLOYEE BENEFIT PLANS 
The Company sponsors both funded and unfunded domestic and international defined benefit pension and defined contribution plans. In addition, the Company contributes to various domestic and international multi-employer pension plans.

[0001783180-22-000034:notes:53]
[same as prior period, unchanged from 0001783180-21-000065:notes:55]

[0001783180-22-000034:notes:54]
|  |  |  |  | For the Three Months Ended March 31, |
| (In millions) |  |  |  |  |  | 2022 (1) |  | 2021 |
| Defined benefit plans |  |  |  |  |  | $ | 4 |  |  | $ | 24 |  |
| Defined contribution plans |  |  |  |  |  | $ | 38 |  |  | $ | 37 |  |
| Multi-employer pension plans |  |  |  |  |  | $ | 3 |  |  | $ | 5 |  |

[0001783180-22-000034:notes:55]
(1) See Note 16 - Divestitures for additional information.

[0001783180-22-000034:notes:56]
The components of net periodic pension expense (benefit) for the defined benefit pension plans are as follows:

[0001783180-22-000034:notes:57]
|  |  |  |  | For the Three Months Ended March 31, |
| (In millions) |  |  |  |  |  | 2022 (1) |  | 2021 |
| Service cost |  |  |  |  |  | $ | 5 |  |  | $ | 7 |  |
| Interest cost |  |  |  |  |  | 4 |  |  | 9 |  |
| Expected return on plan assets |  |  |  |  |  | (7) |  |  | (36) |  |
| Amortization of prior service credit |  |  |  |  |  | 1 |  |  | 1 |  |
| Recognized actuarial net (gain) loss |  |  |  |  |  | 2 |  |  | 8 |  |
| Net periodic pension expense (benefit) |  |  |  |  |  | $ | 5 |  |  | $ | (11) |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001783180-22-000034:notes:58]
STOCK-BASED COMPENSATION
The Company accounts for stock-based compensation plans in accordance with ASC 718, Compensation - Stock Compensation, which requires a fair-value based method for measuring the value of stock-based compensation. Fair value is measured at the date of grant and is generally not adjusted for subsequent changes. The Company's stock-based compensation plans include programs for stock appreciation rights, restricted stock units and performance share units.

[0001783180-22-000034:notes:59]
Stock-based compensation expense, net of estimated forfeitures, is included in Cost of products sold, Selling, general and administrative and Research and development in the accompanying Unaudited Condensed Consolidated Statements of Operations.

[0001783180-22-000034:notes:60]
Stock-based compensation cost by award type was as follows:

[0001783180-22-000034:notes:61]
|  |  |  |  | For the Three Months Ended March 31, |
| (In millions) |  |  |  |  |  | 2022 |  | 2021 |
| Equity compensation costs - equity settled |  |  |  |  |  | $ | 21 |  |  | $ | 19 |  |
| Equity compensation costs - cash settled (1) |  |  |  |  |  | (6) |  |  | 4 |  |
| Total stock-based compensation expense |  |  |  |  |  | $ | 15 |  |  | $ | 23 |  |

[0001783180-22-000034:notes:62]
(1) The cash settled awards are classified as liability awards and are measured at fair value at each balance sheet date.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001783180-22-000034:notes:63]
PRODUCT WARRANTIES
In the ordinary course of business, the Company provides standard warranty coverage on its products. Provisions for these amounts are established at the time of sale and estimated primarily based on product warranty terms and historical claims experience. In addition, the Company incurs discretionary costs to service its products in connection with specific product performance issues. Provisions for these amounts are established when they are known and estimable. The Company assesses the adequacy of its initial provisions and will make adjustments as necessary based on known or anticipated claims or as new information becomes available that suggests it is probable that future costs will be different than estimated amounts. Amounts associated with these provisions are classified on the accompanying Unaudited Condensed Consolidated Balance Sheet as Accrued liabilities or Other long-term liabilities based on their anticipated settlement date.

[0001783180-22-000034:notes:64]
The changes in the carrying amount of warranty related provisions are as follows:

[0001783180-22-000034:notes:65]
|  |  | For the Three Months Ended March 31, |
| (In millions) |  | 2022 |  | 2021 |
| Balance as of January 1, |  | $ | 524 |  |  | $ | 514 |  |
| Warranties, performance guarantees issued and changes in estimated liability |  | 45 |  |  | 39 |  |
| Settlements made |  | (43) |  |  | (38) |  |
| Other |  | — |  |  | (1) |  |
| Balance as of March 31, |  | $ | 526 |  |  | $ | 514 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001783180-22-000034:notes:66]
EQUITY 
The authorized number of shares of common stock of Carrier is 4,000,000,000 shares of $0.01 par value. As of March 31, 2022 and December 31, 2021, 874,460,201 and 873,064,219 shares of common stock were issued, respectively, which includes 26,043,023 and 10,375,654 shares of treasury stock, respectively.

[0001783180-22-000034:notes:67]
[same as prior period, unchanged from 0001783180-21-000065:notes:67]

[0001783180-22-000034:notes:68]
On July 27, 2021, the Company's Board of Directors approved a share repurchase program authorizing the repurchase of up to $2.1 billion of the Company's outstanding common stock. The Company may repurchase its outstanding common stock from time to time subject to market conditions and at the Company's discretion in the open market or through one or more other public or private transactions and subject to compliance with the Company's obligations under certain tax agreements. The Company records repurchases under the cost method whereby the entire cost of the acquired stock is recorded as Treasury stock as a reduction to equity.

[0001783180-22-000034:notes:69]
On December 14, 2021, the Company entered into an accelerated share repurchase agreement ("ASR Agreement") to repurchase $500 million of its common stock pursuant to the Company's existing share repurchase program. In accordance with the ASR Agreement, the Company received initial delivery of 7.6 million shares on January 4, 2022, representing approximately 80% of the expected share repurchases. The final number of shares under the ASR Agreement was based on the daily average of the volume-weighted average share price of the Company's common stock over the term of the ASR Agreement. Upon final settlement, the Company received an additional 2.7 million shares on February 8, 2022 and recognized $500 million in Treasury stock as a reduction in equity.

[0001783180-22-000034:notes:70]
During the three months ended March 31, 2022, the Company repurchased 15,667,369 shares of common stock, which included shares repurchased under the ASR Agreement. The total aggregate purchase price was $741 million. During the three months ended March 31, 2021, the Company repurchased 976,374 shares of common stock for an aggregate purchase price of $38 million.

[0001783180-22-000034:notes:71]
[same as prior period, unchanged from 0001783180-21-000065:notes:70]

[0001783180-22-000034:notes:72]
A summary of changes in the components of Accumulated other comprehensive income (loss) for the three months ended March 31, 2022 and 2021 is as follows:

[0001783180-22-000034:notes:73]
| (In millions) |  | Foreign Currency Translation |  | Defined Benefit Pension and Post-retirement Plans |  |  |  |  |  | Accumulated Other Comprehensive Income (Loss) |
| Balance as of December 31, 2021 |  | $ | (505) |  |  | $ | (484) |  |  |  |  |  |  | $ | (989) |  |
| Other comprehensive income (loss) before reclassifications, net |  | (61) |  |  | (4) |  |  |  |  |  |  | (65) |  |
| Amounts reclassified, pre-tax |  | — |  |  | 3 |  |  |  |  |  |  | 3 |  |
| Tax expense (benefit) reclassified |  | — |  |  | (1) |  |  |  |  |  |  | (1) |  |
| Divestitures, net |  | (574) |  |  | 329 |  |  |  |  |  |  | (245) |  |
| Balance as of March 31, 2022 |  | $ | (1,140) |  |  | $ | (157) |  |  |  |  |  |  | $ | (1,297) |  |

[0001783180-22-000034:notes:74]
| (In millions) |  | Foreign Currency Translation |  | Defined Benefit Pension and Post-retirement Plans |  |  |  |  |  | Accumulated Other Comprehensive Income (Loss) |
| Balance as of December 31, 2020 |  | $ | (191) |  |  | $ | (554) |  |  |  |  |  |  | $ | (745) |  |
| Other comprehensive income (loss) before reclassifications, net |  | (121) |  |  | — |  |  |  |  |  |  | (121) |  |
| Amounts reclassified, pre-tax |  | — |  |  | 9 |  |  |  |  |  |  | 9 |  |
| Tax expense (benefit) reclassified |  | — |  |  | (2) |  |  |  |  |  |  | (2) |  |
| Balance as of March 31, 2021 |  | $ | (312) |  |  | $ | (547) |  |  |  |  |  |  | $ | (859) |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001783180-22-000034:notes:75]
REVENUE RECOGNITION 
The Company accounts for revenue in accordance with ASC 606: Revenue from Contracts with Customers. Revenue is recognized when control of a good or service promised in a contract (i.e., performance obligation) is transferred to a customer. Control is obtained when a customer has the ability to direct the use of and obtain substantially all of the remaining benefits from that good or service. A significant portion of the Company's performance obligations are recognized at a point-in-time when control of the product transfers to the customer, which is generally at the time of shipment. The remaining portion of the Company’s performance obligations are recognized over time as the customer simultaneously obtains control as the Company performs work under a contract, or if the product being produced for the customer has no alternative use and the Company has a contractual right to payment.

[0001783180-22-000034:notes:76]
Sales disaggregated by product and service are as follows:

[0001783180-22-000034:notes:77]
|  |  |  |  | For the Three Months Ended March 31, |
| (In millions) |  |  |  |  |  | 2022 |  | 2021 |
| Sales Type |  |  |  |  |  |  |  |  |
| Product |  |  |  |  |  | $ | 2,639 |  |  | $ | 2,147 |  |
| Service |  |  |  |  |  | 331 |  |  | 339 |  |
| HVAC sales |  |  |  |  |  | 2,970 |  |  | 2,486 |  |
| Product |  |  |  |  |  | 867 |  |  | 892 |  |
| Service |  |  |  |  |  | 109 |  |  | 113 |  |
| Refrigeration sales |  |  |  |  |  | 976 |  |  | 1,005 |  |
| Product |  |  |  |  |  | 771 |  |  | 919 |  |
| Service |  |  |  |  |  | 47 |  |  | 385 |  |
| Fire & Security sales |  |  |  |  |  | 818 |  |  | 1,304 |  |
| Total segment sales |  |  |  |  |  | 4,764 |  |  | 4,795 |  |
| Eliminations and other |  |  |  |  |  | (110) |  |  | (96) |  |
| Net sales |  |  |  |  |  | $ | 4,654 |  |  | $ | 4,699 |  |

[0001783180-22-000034:notes:78]
[same as prior period, unchanged from 0001783180-21-000065:notes:79]

[0001783180-22-000034:notes:79]
Total contract assets and contract liabilities consisted of the following:

[0001783180-22-000034:notes:80]
| (In millions) |  | March 31, 2022 |  | December 31, 2021 |
| Contract assets, current |  | $ | 655 |  |  | $ | 503 |  |
| Contract assets, non-current (included within Other assets) |  | 15 |  |  | 70 |  |
| Total contract assets |  | 670 |  |  | 573 |  |
| Contract liabilities, current |  | (426) |  |  | (415) |  |
| Contract liabilities, non-current (included within Other long-term liabilities) |  | (169) |  |  | (165) |  |
| Total contract liabilities |  | (595) |  |  | (580) |  |
| Net contract assets |  | $ | 75 |  |  | $ | (7) |  |

[0001783180-22-000034:notes:81]
The timing of revenue recognition, billings and cash collections results in contract assets and contract liabilities. Contract assets relate to the conditional right to consideration for any completed performance under a contract when costs are incurred in excess of billings under the percentage-of-completion methodology. Contract liabilities relate to payments received in advance of performance under a contract or when the Company has a right to consideration that is conditioned upon transfer of a good or service to a customer. Contract liabilities are recognized as revenue as (or when) the Company performs under the contract. 
The Company recognized revenue of $157 million during the three months ended March 31, 2022 that related to contract liabilities as of January 1, 2022. The Company expects a majority of its current contract liabilities at the end of the period to be recognized as revenue in the next 12 months.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0001783180-22-000034:notes:82]
The Company accounts for revenue in accordance with ASC 606: Revenue from Contracts with Customers. Revenue is recognized when control of a good or service promised in a contract (i.e., performance obligation) is transferred to a customer. Control is obtained when a customer has the ability to direct the use of and obtain substantially all of the remaining benefits from that good or service. A significant portion of the Company's performance obligations are recognized at a point-in-time when control of the product transfers to the customer, which is generally at the time of shipment. The remaining portion of the Company’s performance obligations are recognized over time as the customer simultaneously obtains control as the Company performs work under a contract, or if the product being produced for the customer has no alternative use and the Company has a contractual right to payment.The timing of revenue recognition, billings and cash collections results in contract assets and contract liabilities. Contract assets relate to the conditional right to consideration for any completed performance under a contract when costs are incurred in excess of billings under the percentage-of-completion methodology. Contract liabilities relate to payments received in advance of performance under a contract or when the Company has a right to consideration that is conditioned upon transfer of a good or service to a customer. Contract liabilities are recognized as revenue as (or when) the Company performs under the contract.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001783180-22-000034:notes:83]
RESTRUCTURING COSTS
The Company incurs costs associated with restructuring initiatives intended to improve operating performance, profitability and working capital levels. Actions associated with these initiatives may include improving productivity, workforce reductions and the consolidation of facilities.

[0001783180-22-000034:notes:84]
The Company recorded net pre-tax restructuring costs for new and ongoing restructuring initiatives as follows:

[0001783180-22-000034:notes:85]
|  |  |  | For the Three Months Ended March 31, |
| (In millions) |  |  |  |  | 2022 |  | 2021 |
| HVAC |  |  |  |  | $ | 4 |  |  | $ | 4 |  |
| Refrigeration |  |  |  |  | — |  |  | 2 |  |
| Fire & Security |  |  |  |  | 6 |  |  | 11 |  |
| Total Segment |  |  |  |  | 10 |  |  | 17 |  |
| General corporate expenses |  |  |  |  | — |  |  | 1 |  |
| Total restructuring costs |  |  |  |  | $ | 10 |  |  | $ | 18 |  |
| Cost of sales |  |  |  |  | $ | 2 |  |  | $ | 5 |  |
| Selling, general and administrative |  |  |  |  | 8 |  |  | 13 |  |
| Total restructuring costs |  |  |  |  | $ | 10 |  |  | $ | 18 |  |

[0001783180-22-000034:notes:86]
The following table summarizes the reserve and charges relating to the restructuring reserve, included in Accrued liabilities on the accompanying Unaudited Condensed Consolidated Balance Sheet:

[0001783180-22-000034:notes:87]
|  |  | For the Three Months Ended March 31, |
| (In millions) |  | 2022 |  | 2021 |
| Balance as of January 1, |  | $ | 54 |  |  | $ | 49 |  |
| Net pre-tax restructuring costs |  | 10 |  |  | 18 |  |
| Utilization, foreign exchange and other |  | (21) |  |  | (18) |  |
| Balance as of March 31, |  | $ | 43 |  |  | $ | 49 |  |

[0001783180-22-000034:notes:88]
During the three months ended March 31, 2022 and 2021, charges associated with restructuring initiatives related to cost reduction efforts. Amounts recognized primarily related to severance due to workforce reductions and exit costs due to the consolidation of field operations. As of March 31, 2022, the Company had $43 million accrued for costs associated with its announced restructuring initiatives, all of which is expected to be paid within one year.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001783180-22-000034:notes:89]
INCOME TAXESThe Company accounts for income tax expense in accordance with ASC 740, Income Taxes ("ASC 740"), which requires an estimate of the annual effective income tax rate for the full year to be applied to the respective interim period, taking into account year-to-date amounts and projected results for the full year. The effective tax rate was 17.8% for the three months ended March 31, 2022 compared with 21.0% for the three months ended March 31, 2021. The year-over-year decrease was primarily driven by a lower effective tax rate on the Chubb gain compared with the Company's U.S. statutory rate and a favorable tax adjustment of $32 million associated with foreign tax credits generated and expected to be utilized in the current 
year. The three months ended March 31, 2021 included a favorable tax adjustment of $21 million resulting from the re-organization of a German subsidiary.

[0001783180-22-000034:notes:90]
[same as prior period, unchanged from 0001783180-21-000065:notes:92]

[0001783180-22-000034:notes:91]
The Company conducts business globally and files income tax returns in U.S. federal, state and foreign jurisdictions. In certain jurisdictions, the Company's operations were included in UTC's combined tax returns for the periods through the Distribution. The U.S. Internal Revenue Service ("IRS") is currently auditing UTC's tax years 2017 and 2018. In the normal course of business, the Company is subject to examination by taxing authorities throughout the world, including Australia, Belgium, Canada, China, Czech Republic, France, Germany, Hong Kong, India, Italy, Mexico, the Netherlands, Singapore, the United Kingdom and the United States. The Company is no longer subject to U.S. federal income tax examination for years prior to 2017 and, with few exceptions, is no longer subject to state, local and foreign income tax examinations for tax years prior to 2013.

[0001783180-22-000034:notes:92]
In the ordinary course of business, there is inherent uncertainty in quantifying the Company's income tax positions. The Company assesses its income tax positions and records tax benefits for all years subject to examination based upon management’s evaluation of the facts, circumstances and information available at the reporting date. The Company believes that it is reasonably possible that a net decrease in unrecognized tax benefits of between $10 million and $65 million may occur within 12 months as a result of additional uncertain tax positions, the Separation, the revaluation of uncertain tax positions arising from examinations, appeals, court decisions and/or the expiration of tax statutes.


## us-gaap:EarningsPerShareTextBlock

[0001783180-22-000034:notes:93]
[same as prior period, unchanged from 0001783180-21-000065:notes:95]

[0001783180-22-000034:notes:94]
The following table summarizes the weighted-average number of shares of common stock outstanding for basic and diluted earnings per share calculations:

[0001783180-22-000034:notes:95]
|  |  |  |  | For the Three Months Ended March 31, |
| (In millions, except per share amounts) |  |  |  |  |  | 2022 |  | 2021 |
| Net income attributable to common shareowners |  |  |  |  |  | $ | 1,379 |  |  | $ | 384 |  |
| Basic weighted-average number of shares outstanding |  |  |  |  |  | 853.3 |  |  | 869.3 |  |
| Stock awards and equity units (share equivalent) |  |  |  |  |  | 20.8 |  |  | 20.5 |  |
| Diluted weighted-average number of shares outstanding |  |  |  |  |  | 874.1 |  |  | 889.8 |  |
| Antidilutive shares excluded from computation of diluted earnings per share |  |  |  |  |  | 3.2 |  |  | 3.3 |  |
| Earnings Per Share |  |  |  |  |  |  |  |  |
| Basic |  |  |  |  |  | $ | 1.62 |  |  | $ | 0.44 |  |
| Diluted |  |  |  |  |  | $ | 1.58 |  |  | $ | 0.43 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001783180-22-000034:notes:96]
ACQUISITIONSDuring the three months ended March 31, 2022 and 2021, the Company acquired consolidated businesses and minority-owned businesses. The aggregate cash paid, net of cash acquired, totaled $9 million and $6 million, respectively, and was funded through cash on hand. Acquisitions are recorded using the acquisition method of accounting in accordance with ASC 805, 
Business Combinations. As a result, the aggregate purchase price has been allocated to assets acquired and liabilities assumed based on the estimate of fair market value of such assets and liabilities at the date of acquisition. The excess purchase price over the estimated fair value of net assets acquired during the three months ended March 31, 2022 and 2021 was recognized as goodwill and totaled $4 million and $5 million, respectively.

[0001783180-22-000034:notes:97]
Toshiba Carrier Corporation Acquisition Agreement

[0001783180-22-000034:notes:98]
On February 6, 2022, the Company entered into a binding agreement to acquire a majority ownership stake in Toshiba Carrier Corporation (“TCC”) for approximately $900 million. TCC, a variable refrigerant flow ("VRF") and light commercial HVAC joint venture between Carrier and Toshiba Corporation, designs and manufactures flexible, energy-efficient and high-performance VRF and light commercial HVAC systems as well as commercial products, compressors and heat pumps. The acquisition will include all of TCC’s advanced research and development centers and global manufacturing operations, product pipeline and the long-term use of Toshiba’s iconic brand. The transaction is expected to close by the end of the third quarter of 2022, subject to customary closing conditions, including regulatory approvals. Upon closing, Toshiba Corporation will retain a 5% ownership interest in TCC.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001783180-22-000034:notes:99]
[same as prior period, unchanged from 0001783180-21-000065:notes:105]

[0001783180-22-000034:notes:100]
On January 3, 2022, the Company completed the Chubb Sale for net proceeds of $2.9 billion. Chubb, reported within the Company’s Fire & Security segment, delivers essential fire safety and security solutions from design and installation to monitoring, service and maintenance across more than 17 countries around the globe. The Company recognized a net gain on the sale of $1.1 billion, which is included in Other income (expense), net on the accompanying Unaudited Condensed Consolidated Statement of Operations. The net proceeds received are subject to working capital and other adjustments as provided in the sale agreement.

[0001783180-22-000034:notes:101]
The following table summarizes Chubb's assets and liabilities classified as held for sale:

[0001783180-22-000034:notes:102]
| (In millions) |  | December 31,2021 |  |  |
| Cash and cash equivalents |  | $ | 60 |  |  |  |
| Accounts receivable, net |  | 445 |  |  |  |
| Inventories, net |  | 73 |  |  |  |
| Contract assets, current |  | 184 |  |  |  |
| Other assets, current |  | 27 |  |  |  |
| Fixed assets, net |  | 67 |  |  |  |
| Intangible assets, net |  | 545 |  |  |  |
| Goodwill |  | 940 |  |  |  |
| Operating lease right-of-use assets |  | 193 |  |  |  |
| Pension and post-retirement assets |  | 614 |  |  |  |
| Other assets |  | 20 |  |  |  |
| Total assets disposed |  | $ | 3,168 |  |  |  |
| Accounts payable |  | $ | (190) |  |  |  |
| Accrued liabilities |  | (248) |  |  |  |
| Contract liabilities, current |  | (162) |  |  |  |
| Future pension and post-retirement obligations |  | (69) |  |  |  |
| Future income tax obligations |  | (273) |  |  |  |
| Operating lease liabilities |  | (175) |  |  |  |
| Other long-term liabilities |  | (17) |  |  |  |
| Total liabilities disposed |  | $ | (1,134) |  |  |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001783180-22-000034:notes:103]
SEGMENT FINANCIAL DATA 
The Company conducts its operations through three reportable operating segments: HVAC, Refrigeration and Fire & Security. In accordance with ASC 280 - Segment Reporting, the Company's segments maintain separate financial information for which results of operations are evaluated on a regular basis by the Company's Chief Operating Decision Maker in deciding how to allocate resources and in assessing performance.

[0001783180-22-000034:notes:104]
[same as prior period, unchanged from 0001783180-21-000065:notes:111]

[0001783180-22-000034:notes:105]
[same as prior period, unchanged from 0001783180-21-000065:notes:112]

[0001783180-22-000034:notes:106]
•The Fire & Security segment provides a wide range of residential, commercial and industrial technologies designed to help protect people and property.

[0001783180-22-000034:notes:107]
The customers of Carrier are in both the public and private sectors and the Company's businesses reflect extensive geographic diversification. Inter-company sales between segments are immaterial.

[0001783180-22-000034:notes:108]
[same as prior period, unchanged from 0001783180-21-000065:notes:115]

[0001783180-22-000034:notes:109]
|  |  | Net Sales |  | Operating Profit |
|  |  | For the Three Months Ended March 31, |  | For the Three Months Ended March 31, |
| (In millions) |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| HVAC |  | $ | 2,970 |  |  | $ | 2,486 |  |  | $ | 470 |  |  | $ | 365 |  |
| Refrigeration |  | 976 |  |  | 1,005 |  |  | 107 |  |  | 127 |  |
| Fire & Security |  | 818 |  |  | 1,304 |  |  | 1,218 |  |  | 150 |  |
| Total segment |  | 4,764 |  |  | 4,795 |  |  | 1,795 |  |  | 642 |  |
| Eliminations and other |  | (110) |  |  | (96) |  |  | (24) |  |  | (40) |  |
| General corporate expenses |  | — |  |  | — |  |  | (34) |  |  | (31) |  |
| Total Consolidated |  | $ | 4,654 |  |  | $ | 4,699 |  |  | $ | 1,737 |  |  | $ | 571 |  |

[0001783180-22-000034:notes:110]
Geographic external sales are attributed to the geographic regions based on their location of origin. With the exception of the U.S. presented in the table below, there were no individually significant countries with sales exceeding 10% of total sales during the three months ended March 31, 2022 and 2021.

[0001783180-22-000034:notes:111]
|  |  |  |  | For the Three Months Ended March 31, |
| (In millions) |  |  |  |  |  | 2022 |  | 2021 |
| United States |  |  |  |  |  | $ | 2,784 |  |  | $ | 2,353 |  |
| International: |  |  |  |  |  |  |  |  |
| Europe |  |  |  |  |  | 1,045 |  |  | 1,398 |  |
| Asia Pacific |  |  |  |  |  | 652 |  |  | 742 |  |
| Other |  |  |  |  |  | 173 |  |  | 206 |  |
| Net sales |  |  |  |  |  | $ | 4,654 |  |  | $ | 4,699 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001783180-22-000034:notes:112]
RELATED PARTIES 
Equity Method Investments

[0001783180-22-000034:notes:113]
The Company sells products to and purchases products from unconsolidated entities accounted for under the equity method and, therefore, these entities are considered to be related parties. Amounts attributable to equity method investees are as follows:

[0001783180-22-000034:notes:114]
|  |  |  |  | For the Three Months Ended March 31, |
| (In millions) |  |  |  |  |  | 2022 |  | 2021 |
| Sales to equity method investees included in Product sales |  |  |  |  |  | $ | 624 |  |  | $ | 468 |  |
| Purchases from equity method investees included in Cost of products sold |  |  |  |  |  | $ | 110 |  |  | $ | 75 |  |

[0001783180-22-000034:notes:115]
The Company had receivables from and payables to equity method investees as follows:

[0001783180-22-000034:notes:116]
| (In millions) |  | March 31,2022 |  | December 31, 2021 |
| Receivables from equity method investees included in Accounts receivable, net |  | $ | 228 |  |  | $ | 150 |  |
| Payables to equity method investees included in Accounts payable |  | $ | 49 |  |  | $ | 51 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001783180-22-000034:notes:117]
COMMITMENTS AND CONTINGENT LIABILITIES
The Company is involved in various litigation, claims and administrative proceedings, including those related to environmental and legal matters (including asbestos). In accordance with ASC 450, Contingencies, the Company records accruals for loss contingencies when it is probable that a liability will be incurred and the amount of the loss can be reasonably estimated. These accruals are generally based upon a range of possible outcomes. If no amount within the range is a better estimate than any other, the Company accrues the minimum amount. In addition, these estimates are reviewed periodically and adjusted to reflect additional information when it becomes available. The Company is unable to predict the final outcome of the following matters based on the information currently available, except as otherwise noted. However, the Company does not believe that the resolution of any of these matters will have a material adverse effect upon the Company's competitive position, results of operations, cash flows or financial condition.

[0001783180-22-000034:notes:118]
Environmental Matters

[0001783180-22-000034:notes:119]
The Company’s operations are subject to environmental regulation by various authorities. The Company has accrued for the costs of environmental remediation activities, including but not limited to investigatory, remediation, operating and maintenance costs and performance guarantees. The most likely cost to be incurred is accrued based on an evaluation of currently available facts with respect to individual sites, including technology required to remediate, current laws and regulations and prior remediation experience.

[0001783180-22-000034:notes:120]
The outstanding liabilities for environmental obligations are as follows:

[0001783180-22-000034:notes:121]
| (In millions) |  | March 31,2022 |  | December 31, 2021 |
| Environmental reserves included in Accrued liabilities |  | $ | 29 |  |  | $ | 29 |  |
| Environmental reserves included in Other long-term liabilities |  | 189 |  |  | 191 |  |
| Total Environmental reserves |  | $ | 218 |  |  | $ | 220 |  |

[0001783180-22-000034:notes:122]
For sites with multiple responsible parties, the Company considers its likely proportionate share of the anticipated remediation costs and the ability of other parties to fulfill their obligations in establishing a provision for these costs. Accrued environmental liabilities are not reduced by potential insurance reimbursements and are undiscounted.

[0001783180-22-000034:notes:123]
Asbestos Matters

[0001783180-22-000034:notes:124]
The Company has been named as a defendant in lawsuits alleging personal injury as a result of exposure to asbestos allegedly integrated into certain Carrier products or business premises. While the Company has never manufactured asbestos and no longer incorporates it into any currently-manufactured products, certain products that the Company no longer manufactures

[0001783180-22-000034:notes:125]
contained components incorporating asbestos. A substantial majority of these asbestos-related claims have been dismissed without payment or have been covered in full or in part by insurance or other forms of indemnity. Additional cases were litigated and settled without any insurance reimbursement. The amounts involved in asbestos-related claims were not material individually or in the aggregate in any period.

[0001783180-22-000034:notes:126]
The Company had asbestos liabilities and related insurance recoveries as follows:

[0001783180-22-000034:notes:127]
| (In millions) |  | March 31,2022 |  | December 31,2021 |
| Asbestos liabilities included in Accrued liabilities |  | $ | 17 |  |  | $ | 17 |  |
| Asbestos liabilities included in Other long-term liabilities |  | 219 |  |  | 220 |  |
| Total Asbestos liabilities |  | $ | 236 |  |  | $ | 237 |  |
| Asbestos-related recoveries included in Other assets, current |  | $ | 5 |  |  | $ | 5 |  |
| Asbestos-related recoveries included in Other assets |  | 92 |  |  | 93 |  |
| Total Asbestos-related recoveries |  | $ | 97 |  |  | $ | 98 |  |

[0001783180-22-000034:notes:128]
The amounts recorded for asbestos-related liabilities are based on currently available information and assumptions that the Company believes are reasonable and are made with input from outside actuarial experts. These amounts are undiscounted and exclude the Company’s legal fees to defend the asbestos claims, which are expensed as incurred. In addition, the Company has recorded insurance recovery receivables for probable asbestos-related recoveries.

[0001783180-22-000034:notes:129]
UTC Equity Awards Conversion Litigation

[0001783180-22-000034:notes:130]
On August 12, 2020, several former employees of UTC or its subsidiaries filed a putative class action complaint (the "Complaint") in the United States District Court for the District of Connecticut against Raytheon Technologies Corporation, Carrier, Otis, the former members of the UTC Board of Directors and the members of the Carrier and Otis Boards of Directors (Geraud Darnis, et al. v. Raytheon Technologies Corporation, et al.). The Complaint challenges the method by which UTC equity awards were converted to UTC, Carrier and Otis equity awards following the Separation and the Distribution. Defendants moved to dismiss the Complaint. Plaintiffs amended their Complaint on September 13, 2021 ("the Amended Complaint"). The Amended Complaint, now with Raytheon, Carrier and Otis as the only defendants, asserts that the defendants are liable for breach of certain equity compensation plans and for breach of the implied covenant of good faith and fair dealing. The Amended Complaint also seeks specific performance. Carrier believes that the claims against the Company are without merit. Defendants moved to dismiss the Amended Complaint on October 13, 2021. The motion was fully briefed as of December 3, 2021. The court has not scheduled arguments or decided the motion.

[0001783180-22-000034:notes:131]
Aqueous Film Forming Foam Litigation

[0001783180-22-000034:notes:132]
As of March 31, 2022, the Company has been named as a defendant in more than 2,200 lawsuits filed by individuals in or removed to the federal courts of the United States alleging that the historic use of Aqueous Film Forming Foam ("AFFF") caused personal injuries and/or property damage. The Company has also been named as a defendant in more than 160 lawsuits filed by several U.S. states, municipalities and water utilities in or removed to U.S. federal courts alleging that the historic use of AFFF caused contamination of property and water supplies. In December 2018, the U.S. Judicial Panel on Multidistrict Litigation transferred and consolidated all AFFF cases pending in the U.S. federal courts against the Company and others to the U.S. District Court for the District of South Carolina ("MDL Court") for pre-trial proceedings ("MDL Proceedings"). The individual plaintiffs in the MDL Proceedings generally seek damages for alleged personal injuries, medical monitoring and diminution in property value and injunctive relief to remediate alleged contamination of water supplies. The U.S. state, municipal and water utility plaintiffs in the MDL Proceedings generally seek damages and costs related to the remediation of public property and water supplies.

[0001783180-22-000034:notes:133]
AFFF is a firefighting foam, developed beginning in the late 1960s pursuant to U.S. military specification, used to extinguish certain types of hydrocarbon-fueled fires primarily at military bases and airports. AFFF was manufactured by several companies, including National Foam and Angus Fire. UTC first entered the AFFF business with the acquisition of National Foam and Angus Fire in 2005 as part of the acquisition of Kidde. In 2013, Kidde divested the National Foam and Angus Fire businesses to a third party. The Company acquired Kidde as part of its separation from UTC in April 2020. During the eight-year period of its operation by Kidde, National Foam manufactured AFFF for sale to government (including the U.S. federal government) and non-government customers in the U.S. at a single facility located in West Chester, Pennsylvania

[0001783180-22-000034:notes:134]
("Pennsylvania Site"). During the same period, Angus Fire manufactured AFFF for sale outside the United States at a single facility located in Bentham, England.

[0001783180-22-000034:notes:135]
The key components of AFFF that contribute to its fire-extinguishing capabilities are known as fluorosurfactants. National Foam and Angus Fire did not manufacture fluorosurfactants but instead purchased these substances from unrelated third parties. Plaintiffs in the MDL Proceedings allege that the fluorosurfactants used by various manufacturers in producing AFFF contained, or over time degraded into, compounds known as perflourooctane sulfonate ("PFOS") and/or perflourooctane acid ("PFOA"). Plaintiffs further allege that, as a result of the use of AFFF, PFOS and PFOA were released into the environment and, in some instances, ultimately reached drinking water supplies.

[0001783180-22-000034:notes:136]
Plaintiffs in the MDL Proceedings allege that PFOS and PFOA contamination has resulted from the use of AFFF containing fluorosurfactants manufactured using a process known as ECF. They also allege that PFOA contamination has resulted from the use of AFFF containing fluorosurfactants manufactured using a different process, known as telomerization. Plaintiffs further allege that 3M was the only AFFF manufacturer that used fluorosurfactants relying on the ECF process and that all other foam manufacturers (including National Foam and Angus Fire) relied solely on fluorosurfactants produced via telomerization. Compounds containing PFOS and PFOA (as well as many other per- and polyfluoroalkyl substances known collectively as "PFAS") have also been used for decades by many third parties in a number of different industries to manufacture carpets, clothing, fabrics, cookware, food packaging, personal care products, cleaning products, paints, varnishes and other consumer and industrial products.

[0001783180-22-000034:notes:137]
Plaintiffs in the MDL Proceedings have named multiple defendants, including four suppliers of chemicals and raw materials used to manufacture fluorosurfactants, four fluorosurfactant manufacturers, two toll manufacturers of fluorosurfactants and seven current (including National Foam and Angus Fire) and former (including the Company) AFFF manufacturers.

[0001783180-22-000034:notes:138]
General liability discovery in the MDL Proceedings continues. Preliminary stage discovery in ten "bellwether" water provider cases was concluded and three of these cases were selected for tier two site-specific discovery. That discovery is ongoing. The MDL Court previously established a briefing schedule with respect to certain aspects of the government contractor defense, potentially applicable to AFFF sold to or used by the U.S. government or other customers requiring product manufactured to meet military specification, with briefing to conclude at the end of January 2022 with a hearing to follow in late March. In late March the MDL Court postponed the planned hearing and called for briefing on additional elements of the government contractor defense. Briefing will continue through July 1, 2022.

[0001783180-22-000034:notes:139]
Outside of the MDL Proceedings, the Company and other defendants are also party to six lawsuits in U.S. state courts brought by oil refining companies alleging product liability claims related to legacy sales of AFFF and seeking damages for the costs to replace the product and for property damage. In addition, the Company and other defendants are party to two actions related to the Pennsylvania Site in which the plaintiff water utility company seeks remediation costs related to the alleged contamination of the local water supply.

[0001783180-22-000034:notes:140]
The Company believes that it has meritorious defenses to the claims in the MDL Proceedings and the other AFFF lawsuits. Based on the 2013 agreement for the sale of National Foam and Angus Fire, the Company is pursuing indemnification against these claims from the purchaser and current owner of National Foam and Angus Fire. The Company also is pursuing insurance coverage for these claims. At this time, however, given the numerous factual, scientific and legal issues to be resolved relating to these claims, the Company is unable to assess the probability of liability or to reasonably estimate the damages, if any, to be allocated to the Company, if one or more plaintiffs were to prevail in these cases. There can be no assurance that any such future exposure will not be material in any period.

[0001783180-22-000034:notes:141]
Income Taxes

[0001783180-22-000034:notes:142]
Under the Tax Matters Agreement relating to the Separation, the Company is responsible to UTC for its share of the Tax Cuts and Jobs Act ("TCJA") transition tax associated with foreign undistributed earnings as of December 31, 2017. As a result, a liability of $417 million is included within the accompanying Unaudited Condensed Consolidated Balance Sheet within Other Long-Term Liabilities as of March 31, 2022. This obligation is expected to be settled in annual installments ending in April 2026 with the next installment of $34 million due in 2023. The Company believes that the likelihood of incurring losses materially in excess of this amount is remote.

[0001783180-22-000034:notes:143]
Other

[0001783180-22-000034:notes:144]
The Company has other commitments and contingent liabilities related to legal proceedings, self-insurance programs and matters arising in the ordinary course of business. The Company accrues for contingencies generally based upon a range of

[0001783180-22-000034:notes:145]
possible outcomes. If no amount within the range is a better estimate than any other, the Company accrues the minimum amount.

[0001783180-22-000034:notes:146]
In the ordinary course of business, the Company is also routinely a defendant in, party to or otherwise subject to many pending and threatened legal actions, claims, disputes and proceedings. These matters are often based on alleged violations of contract, product liability, warranty, regulatory, environmental, health and safety, employment, intellectual property, tax and other laws. In some of these proceedings, claims for substantial monetary damages are asserted against the Company and could result in fines, penalties, compensatory or treble damages or non-monetary relief. The Company does not believe that these matters will have a material adverse effect upon its competitive position, results of operations, cash flows or financial condition.
