# CARR note change history — 0001783180-20-000052 → 0001783180-20-000067


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-10-29):
[0001783180-20-000067:note_history:1]
Environmental.  The Company’s operations are subject to environmental regulation by various authorities.  We have accrued for the costs of environmental remediation activities, including but not limited to investigatory, remediation, operating and maintenance costs and performance guarantees, and we periodically reassess these amounts.  Management believes that the likelihood of incurring losses materially in excess of the amounts accrued is remote.  As of September 30, 2020 and December 31, 2019, the outstanding liability for environmental obligations was $233 million and $217 million, respectively, of which $13 million and $14 million, respectively, is included in Accrued liabilities and $220 million and $203 million, respectively, is included in Other long-term liabilities on the accompanying Unaudited Condensed Consolidated Balance Sheet.
  (was, 2020-07-31, similarity 0.7441):
[0001783180-20-000052:note_history:1]
Environmental.  The Company’s operations are subject to environmental regulation by various authorities.  We have accrued for the costs of environmental remediation activities, including but not limited to investigatory, remediation, operating and maintenance costs and performance guarantees, and we periodically reassess these amounts.  Management believes that the likelihood of incurring losses materially in excess of the amounts accrued is remote.  As of June 30, 2020 and December 31, 2019, the outstanding liability for environmental obligations was $230 million and $217 million, respectively, of which $13 million and $14 million, respectively, is included in Accrued liabilities and $217 million and $203 million, respectively, is included in Other long-term liabilities on the accompanying Unaudited Condensed Consolidated Balance Sheet.

- changed (2020-10-29):
[0001783180-20-000067:note_history:2]
The amounts recorded for asbestos-related liabilities are based on currently available information and assumptions that we believe are reasonable and are made with input from outside actuarial experts. As of September 30, 2020, the estimated range of liability to resolve all pending and unasserted potential future asbestos claims through 2059 is approximately $250 million to $290 million. Where no amount within a range of estimates is more likely, the minimum is accrued. We have recorded the minimum amount of $250 million and $255 million, which is principally recorded in Other long-term liabilities on the Unaudited Condensed Consolidated Balance Sheet, as of September 30, 2020 and December 31, 2019, respectively.  These amounts are undiscounted and exclude the Company’s legal fees to defend the asbestos claims, which are expensed as incurred.  In addition, the Company has recorded an insurance recovery receivable for probable asbestos-related recoveries of approximately $104 million and $104 million, which is included primarily in Other assets on the Unaudited Condensed Consolidated Balance Sheet, as of September 30, 2020 and December 31, 2019, respectively.
  (was, 2020-07-31, similarity 0.9325):
[0001783180-20-000052:note_history:2]
The amounts recorded for asbestos-related liabilities are based on currently available information and assumptions that we believe are reasonable and are made with input from outside actuarial experts. As of June 30, 2020, the estimated range of liability to resolve all pending and unasserted potential future asbestos claims through 2059 is approximately $251 million to $290 million. Where no amount within a range of estimates is more likely, the minimum is accrued. We have recorded the minimum amount of $251 million and $255 million, which is principally recorded in Other long-term liabilities on the Unaudited Condensed Consolidated Balance Sheet as of June 30, 2020 and December 31, 2019, respectively.  These amounts are undiscounted and exclude the Company’s legal fees to defend the asbestos claims, which are expensed as incurred.  In addition, the Company has an insurance recovery receivable for probable asbestos-related recoveries of approximately $104 million, which is included primarily in Other assets on the Unaudited Condensed Consolidated Balance Sheet as of June 30, 2020 and December 31, 2019.

- added (2020-10-29):
[0001783180-20-000067:note_history:3]
UTC Equity Awards Conversion Litigation. On August 12, 2020, several former employees of UTC or its subsidiaries filed a putative class action complaint in the United States District Court for the District of Connecticut against UTC, Carrier, and Otis, the former members of the UTC Board of Directors, and the members of the Carrier and Otis Boards of Directors (Geraud Darnis, et al. v. Raytheon Technologies Corporation, et al.). The complaint challenges the method by which UTC equity awards were converted to UTC, Carrier, and Otis equity awards following the separation of UTC into three independent, publicly traded companies on April 3, 2020. The complaint claims that the defendants are liable for breach of certain equity compensation plans and for breach of fiduciary duty, and also asserts claims under certain provisions of Employee Retirement Income Security Act of 1974 ("ERISA"). Carrier believes that the claims against the Company are without merit.

- changed (2020-10-29):
[0001783180-20-000067:note_history:4]
Income Taxes.  As described in Note 1 – Description of the Business, under the TMA the Company is responsible to UTC for its share of the TCJA transition tax associated with foreign undistributed earnings as of December 31, 2017.  As of September 30, 2020, a liability of $72 million, primarily related to our share of TCJA transition tax associated with foreign undistributed earnings is included within Other long-term liabilities on the accompanying Unaudited Condensed Consolidated Balance Sheet.  We believe that the likelihood of incurring losses materially in excess of this amount is remote.
  (was, 2020-07-31, similarity 0.807):
[0001783180-20-000052:note_history:4]
Income Taxes.  As described in Note 1 – Description of the Business, the TMA provides special rules that allocate responsibility for tax liabilities arising from a failure of the Separation transactions to qualify for tax-free treatment based on the reasons for such failure.  Further, the Company is responsible to UTC for its share of the TCJA transition tax associated with foreign undistributed earnings as of December 31, 2017.  As of June 30, 2020, a liability of $72 million, primarily related to our share of TCJA transition tax associated with foreign undistributed earnings is included within Other long-term liabilities on the accompanying Unaudited Condensed Consolidated Balance Sheet.  We believe that the likelihood of incurring losses materially in excess of this amount is remote.

- changed (2020-10-29):
[0001783180-20-000067:note_history:5]
In the ordinary course of business, Carrier is routinely a defendant in, party to or otherwise subject to pending and threatened legal actions, claims, disputes and proceedings.  These matters are often based on alleged violations of contract, product liability, warranty, regulatory, environmental, health and safety, employment, intellectual property, tax and other laws.  In some of these proceedings or instances, claims for substantial monetary damages are asserted against the Company and its subsidiaries and could result in fines, penalties, compensatory or treble damages or non-monetary relief. We do not believe that these matters will have a material adverse effect upon our competitive position, results of operations, cash flows or financial condition.
  (was, 2020-07-31, similarity 0.9914):
[0001783180-20-000052:note_history:5]
In the ordinary course of business, Carrier is routinely a defendant in, party to or otherwise subject to pending and threatened legal actions, claims, disputes and proceedings.  These matters are often based on alleged violations of contract, product liability, warranty, regulatory, environmental, health and safety, employment, intellectual property, tax and other laws.  In some of these proceedings, claims for substantial monetary damages are asserted against the Company and its subsidiaries and could result in fines, penalties, compensatory or treble damages or non-monetary relief. We do not believe that these matters will have a material adverse effect upon our competitive position, results of operations, cash flows or financial condition.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2020-10-29):
[0001783180-20-000067:note_history:6]
The Company's financial statements for periods prior to the Separation and the Distribution are prepared on a "carve-out" basis, as described below.  The Company's financial statements for the period from April 3, 2020 through September 30, 2020 are consolidated financial statements based on the reported results of Carrier as a stand-alone company.
  (was, 2020-07-31, similarity 0.9807):
[0001783180-20-000052:note_history:6]
The Company's financial statements for periods prior to the Separation and the Distribution are prepared on a "carve-out" basis, as described below.  The Company's financial statements for the period from April 3, 2020 through June 30, 2020 are consolidated financial statements based on the reported results of Carrier as a stand-alone company.

- added (2020-10-29):
[0001783180-20-000067:note_history:7]
For the period prior to the Separation and the Distribution, the Unaudited Condensed Consolidated Financial Statements reflect the Company's financial position, results of operations and cash flows for the periods presented, which were historically managed by UTC. For the periods presented prior to the Separation and the Distribution, the Unaudited Condensed Consolidated Financial Statements are derived from UTC's consolidated financial statements and accounting records.

- changed (2020-10-29):
[0001783180-20-000067:note_history:8]
The Unaudited Condensed Consolidated Statement of Operations includes all revenues and costs directly attributable to Carrier, including costs for facilities, functions and services used by Carrier.  Prior to the Separation, costs for certain functions and services performed by UTC were directly charged to Carrier based on specific identification when possible or based on a reasonable allocation driver such as net sales, headcount, proportionate usage or other allocation methods.  The results of operations include allocations of costs for administrative functions and services performed on behalf of Carrier by centralized groups within UTC and of certain pension and other post-retirement benefit costs (see Note 5 – Related Parties for a description of the allocation methodologies).  All charges and allocations for facilities, functions and services performed by UTC have been deemed settled in cash by Carrier to UTC in the period in which the cost was recorded in the Unaudited Condensed Consolidated Statement of Operations.
  (was, 2020-07-31, similarity 0.9985):
[0001783180-20-000052:note_history:8]
The Unaudited Condensed Consolidated Statement of Operations includes all revenues and costs directly attributable to Carrier, including costs for facilities, functions and services used by Carrier.  Prior to the Separation, costs for certain functions and services performed by UTC were directly charged to Carrier based on specific identification when possible or based on a reasonable allocation driver such as net sales, headcount, proportionate usage or other allocation methods.  The results of operations include allocations of costs for administrative functions and services performed on behalf of Carrier by centralized groups within UTC and certain pension and other post-retirement benefit costs (see Note 5 – Related Parties for a description of the allocation methodologies).  All charges and allocations for facilities, functions and services performed by UTC have been deemed settled in cash by Carrier to UTC in the period in which the cost was recorded in the Unaudited Condensed Consolidated Statement of Operations.

- changed (2020-10-29):
[0001783180-20-000067:note_history:9]
Prior to the Separation, UTC used a centralized approach to cash management and the financing of its operations.  Accordingly, none of UTC's cash, third party debt or related interest expense has been allocated to Carrier in the Unaudited Condensed Consolidated Financial Statements for the period prior to the Separation.  However, cash balances primarily associated with certain foreign entities that did not participate in UTC’s cash management program have been included in the Unaudited Condensed Consolidated Financial Statements for periods prior to the Separation.  Transactions between UTC and Carrier are deemed settled immediately through UTC’s Net investment, other than those transactions which have been historically cash-settled and which are reflected in the Unaudited Condensed Consolidated Balance Sheet within Accounts receivable, net and Accounts payable.  The net effect of the deemed settled transactions is reflected in the Unaudited Condensed Consolidated Statement of Cash Flows as Net transfers to UTC within financing activities and in the Unaudited Condensed Consolidated Balance Sheet as UTC’s Net investment (see Note 5 – Related Parties for additional information).
  (was, 2020-07-31, similarity 0.9798):
[0001783180-20-000052:note_history:9]
Prior to the Separation, UTC used a centralized approach to cash management and financing its operations.  Accordingly, none of the cash, third party debt or related interest expense of UTC has been allocated to Carrier in the Unaudited Condensed Consolidated Financial Statements for the period prior to the Separation.  However, cash balances primarily associated with certain foreign entities that did not participate in UTC’s cash management program have been included in the Unaudited Condensed Consolidated Financial Statements for periods prior to the Separation.  Transactions between UTC and Carrier are deemed settled immediately through UTC’s Net investment, other than those transactions which have historically been cash-settled and which are reflected in the Unaudited Condensed Consolidated Balance Sheet within Accounts receivable, net and Accounts payable.  The net effect of the deemed settled transactions is reflected in the Unaudited Condensed Consolidated Statement of Cash Flows as Net transfers to UTC within financing activities and in the Unaudited Condensed Consolidated Balance Sheet as UTC’s Net investment (see Note 5 – Related Parties for additional information).

- changed (2020-10-29):
[0001783180-20-000067:note_history:10]
All of the allocations and estimates in the Unaudited Condensed Consolidated Financial Statements are based on assumptions that management believes are reasonable.  However, for the periods prior to the Separation, the Unaudited Condensed Consolidated Financial Statements may not be indicative of the Company's future financial position, results of operations and cash flows or if the Company had been a separate, stand-alone entity during the periods presented.
  (was, 2020-07-31, similarity 0.8332):
[0001783180-20-000052:note_history:10]
All of the allocations and estimates in the Unaudited Condensed Consolidated Financial Statements are based on assumptions that management believes are reasonable.  However, for the periods prior to the Separation, the Unaudited Condensed Consolidated Financial Statements included herein may not be indicative of the financial position, results of operations and cash flows of the Company in the future, or if the Company had been a separate, stand-alone entity during the periods presented.

- changed (2020-10-29):
[0001783180-20-000067:note_history:11]
In June 2016, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") 2016-13, Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments. This ASU and its related amendments (collectively, the "Credit Loss Standard") modified the credit loss model to utilize an expected loss methodology in place of an incurred loss methodology for financial instruments, including trade receivables, contract assets, long-term receivables and off-balance sheet credit exposures. The Credit Loss Standard requires consideration of a broader range of information to estimate expected credit losses, including historical information, current conditions and a reasonable forecast period. This ASU requires that the statement of operations reflect the measurement of credit losses for newly recognized financial assets as well as an expected increase or decrease of expected credit losses that have taken place during the period, which may result in earlier recognition.  The Company adopted the Credit Loss Standard effective January 1, 2020, utilizing a modified retrospective approach and its adoption did not have a significant impact on the Company's Unaudited Condensed Consolidated Financial Statements.
  (was, 2020-07-31, similarity 0.9992):
[0001783180-20-000052:note_history:11]
In June 2016, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") 2016-13, Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments. This ASU and its related amendments (collectively, the "Credit Loss Standard") modified the credit loss model to utilize an expected loss methodology in place of an incurred loss methodology for financial instruments, including trade receivables, contract assets, long term receivables and off-balance sheet credit exposures. The Credit Loss Standard requires consideration of a broader range of information to estimate expected credit losses, including historical information, current conditions and a reasonable forecast period. This ASU requires that the statement of operations reflect the measurement of credit losses for newly recognized financial assets as well as an expected increase or decrease of expected credit losses that have taken place during the period, which may result in earlier recognition.  The Company adopted the Credit Loss Standard effective January 1, 2020, utilizing a modified retrospective approach and its adoption did not have a significant impact on the Company's Unaudited Condensed Consolidated Financial Statements.

- added (2020-10-29):
[0001783180-20-000067:note_history:12]
Recently Issued SEC Rules

- changed (2020-10-29):
[0001783180-20-000067:note_history:13]
In May 2020, the SEC issued Final Rule Release No. 33-10786, which amends the financial statement requirements for acquisitions and dispositions of businesses and related pro forma financial information required under SEC Regulation S-X, Rule 3-05. The final rule modifies the significance test required in SEC Regulation S-X, Rule 1-02(w) by raising the significance threshold for reporting dispositions of a business from 10% to 20% and by modifying the calculation of the investment and income tests.  In accordance with Rules 3-09 or 4-08(g), the revised income test will apply to the evaluation of equity method investments for significance.  The Company is currently evaluating the impact of these modifications, which are effective for fiscal years beginning after December 31, 2020.
  (was, 2020-07-31, similarity 0.966):
[0001783180-20-000052:note_history:13]
In May 2020, the SEC issued Final Rule Release No. 33-10786, which amends the financial statement requirements for acquisitions and dispositions of businesses and related pro forma financial information required under SEC Regulation S-X, Rule 3-05. The final rule modifies the significance test required in SEC Regulation S-X, Rule 1-02(w) by raising the significance threshold for reporting dispositions of a business from 10% to 20% and by modifying the calculation of the investment and income tests.  In accordance with Rules 3-09 or 4-08(g), the revised income test will apply to the evaluation of equity method investments for significance.  The Company is currently evaluating the impact of these modifications which are effective for fiscal years starting after December 31, 2020.

- added (2020-10-29):
[0001783180-20-000067:note_history:14]
In August 2020, the SEC issued Final Rule Release No. 33-10825, which amends certain disclosure requirements required by Regulation S-K relating to the description of business (Item 101), legal proceedings (Item 103) and risk factors (Item 105). The amendments to Item 101 will, among other things, allow the Company to provide updates regarding the business based on materiality, if it incorporates by reference disclosure from a previous SEC filing.  The amendment also requires disclosures regarding the registrant’s human capital resources to the extent such disclosures would be material to an understanding of the registrant’s business. The amendments to Item 103 will, among other things, increase the quantitative threshold for disclosing certain environmental proceedings, and the amendments to Item 105 will, among other things, require a risk factor summary if the risk factors section is longer than 15 pages. The Company is currently evaluating the impact of these modifications, which are effective on November 9, 2020.

- removed (2020-10-29):
[0001783180-20-000052:note_history:15]
Prior to the Separation and the Distribution, the Unaudited Condensed Consolidated Financial Statements reflect the financial position, results of operations and cash flows of the Company for the periods presented as historically managed within UTC. For those periods prior to the Separation and the Distribution, the Unaudited Condensed Consolidated Financial Statements are derived from the consolidated financial statements and accounting records of UTC.

- removed (2020-10-29):
[0001783180-20-000052:note_history:16]
Recently Issued Accounting Pronouncements


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2020-10-29):
[0001783180-20-000067:note_history:17]
The Condensed Consolidated Financial Statements as of September 30, 2020 and for the three and nine months ended September 30, 2020 and 2019 are unaudited, and include all adjustments, consisting only of normal recurring adjustments considered necessary by management to fairly state our results of operations, financial position and cash flows for the interim periods. The results reported in the Unaudited Condensed Consolidated Financial Statements are not necessarily indicative of results that may be expected for any other interim period or the entire year. The financial information included herein should be read in conjunction with the financial statements and notes in the Company's information statement, dated March 16, 2020, which was included as Exhibit 99.1 in our Current Report on Form 8-K filed with the Securities and Exchange Commission ("SEC") on March 16, 2020 (the "Information Statement").
  (was, 2020-07-31, similarity 0.9319):
[0001783180-20-000052:note_history:17]
The Condensed Consolidated Financial Statements as of June 30, 2020 and for the three and six months ended June 30, 2020 and 2019 are unaudited, and include all adjustments (consisting only of normal recurring adjustments) considered necessary by management to fairly state our results of operations, financial position and cash flows for the interim periods. The results reported in the Unaudited Condensed Consolidated Financial Statements are not necessarily indicative of results that may be expected for any other interim period or the entire year. The financial information included herein should be read in conjunction with the financial statements and notes in the Company's information statement, dated March 16, 2020, which was included as Exhibit 99.1 in our Current Report on Form 8-K filed with the Securities and Exchange Commission ("SEC") on March 16, 2020 (the "Information Statement").

- changed (2020-10-29):
[0001783180-20-000067:note_history:18]
A novel strain of coronavirus ("COVID-19") surfaced in Wuhan, China in late 2019 and has since spread throughout the rest of the world. In March 2020, COVID-19 was declared a pandemic by the World Health Organization and a national emergency by the U.S. Government.  The pandemic has negatively affected the U.S. and global economies, disrupted global supply chains and financial markets, resulted in significant travel restrictions, mandated facility closures and shelter-in-place orders.
  (was, 2020-07-31, similarity 0.999):
[0001783180-20-000052:note_history:18]
A novel strain of coronavirus ("COVID-19") surfaced in Wuhan, China in late 2019 and has since spread throughout the rest of the world. In March 2020, COVID-19 was declared a pandemic by the World Health Organization and a national emergency by the U.S. Government.  The pandemic has negatively affected the U.S. and global economies, disrupted global supply chains and financial markets, resulted in significant travel restrictions, mandated facility closures, and shelter-in-place orders.

- added (2020-10-29):
[0001783180-20-000067:note_history:19]
Carrier is taking all prudent measures to protect the health and safety of our employees. In particular, we have implemented work from home requirements (where possible), social distancing and deep cleaning protocols at all of our facilities as well as travel restrictions, among other measures. We have also taken appropriate measures to work with our customers to minimize potential disruptions and to support the communities that we serve to address the challenges posed by the pandemic.

- changed (2020-10-29):
[0001783180-20-000067:note_history:20]
The full extent of the impact of COVID-19 on our operational and financial performance will depend on future developments, including the duration and spread of the pandemic as well as any worsening or additional outbreaks of the pandemic, and related containment and mitigation actions taken by the U.S., state and local and international governments to prevent disease spread. The extent of the pandemic's impact on Carrier will also depend upon our employees' ability to work safely in our facilities, our customers’ ability to continue to operate or to receive our products, and the level of activity and demand for the ultimate products and services of our customers or their customers.
  (was, 2020-07-31, similarity 0.9101):
[0001783180-20-000052:note_history:20]
The full extent of the impact of the COVID-19 pandemic on the Company's operational and financial performance will depend on future developments, including the duration and spread of the pandemic, as well as any worsening of the pandemic and whether there will be additional outbreaks of the pandemic, and related containment and mitigation actions taken by the U.S., state and local and international governments to prevent disease spread. The extent of the pandemic's impact on Carrier will also depend upon our employees' ability to work safely in our facilities, our customers’ ability to continue to operate or receive our products, the ability of our suppliers to continue to operate, and the level of activity and demand for the ultimate product and services of our customers or their customers.

- added (2020-10-29):
[0001783180-20-000067:note_history:21]
During the three months ended March 31, 2020, we temporarily closed or reduced production at manufacturing facilities in North America, Asia and Europe for safety reasons and in response to lower demand for our products.  Subsequently, our manufacturing operations have resumed, measures have been enacted to scale capacity to demand, and we continue to actively take steps to mitigate supply chain risk. We continue to apply appropriate safety measures and have not experienced any significant disruptions to our manufacturing operations.  We also initiated return-to-work protocols at our non-manufacturing facilities where employees were previously working remotely.

- changed (2020-10-29):
[0001783180-20-000067:note_history:22]
We continue to focus on navigating the challenges COVID-19 presents by preserving our liquidity and managing our cash flows through preemptive actions to enhance our ability to meet our liquidity needs over the next twelve months. Such actions during the nine months ended September 30, 2020 include, but are not limited to, modifying the financial covenants in our revolving and term loan credit facilities and issuing $750 million of unsecured, unsubordinated long-term debt (see Note 10 – Borrowings and Lines of Credit for additional information), reducing our discretionary spending, capital investments and general and administrative costs by implementing temporary pay freezes and pay cuts, employee furloughs and suspending non-critical hiring, and participating in global COVID-19 relief measures, including the Coronavirus Aid, Relief, and Economic Security ("CARES") Act, which provides for payroll tax deferrals and credits, income tax payment deferrals and an increase in the income tax interest deduction limitation. 
DESCRIPTION OF THE BUSINESS 
Carrier Global Corporation is a leading global provider of heating, ventilating, air conditioning ("HVAC"), refrigeration, and fire and security solutions. Carrier also provides a broad array of related building services, including audit, design, installation, system integration, repair, maintenance and monitoring. Carrier’s operations are classified into three segments: HVAC, Refrigeration and Fire & Security. The HVAC and Refrigeration segments sell their products and solutions directly, including to building contractors and owners, transportation companies and retail stores, or indirectly through joint venture and other minority-owned investments, independent sales representatives, distributors, wholesalers, dealers and retail outlets. These products and services are sold under the Carrier name and other brand names including Automated Logic, Bryant, CIAT, Day & Night, Heil, NORESCO, Riello, Carrier Commercial Refrigeration, Carrier Transicold, Sensitech and others. The Fire & Security segment sells its products directly to customers, or indirectly through manufacturers’ representatives, distributors, dealers, value-added resellers and retailers. Fire & Security’s products and services are used by governments, financial institutions, architects, building owners and developers, security and fire consultants, homeowners and other end-users requiring a high level of security and fire protection for their businesses and residences. These products and services are sold under brand names including Autronica, Chubb, Det-Tronics, Edwards, Fireye, GST, Kidde, LenelS2, Marioff, Onity, Supra and others.
  (was, 2020-07-31, similarity 0.9288):
[0001783180-20-000052:note_history:22]
We continue to focus on navigating the challenges COVID-19 presents by preserving our liquidity and managing our cash flows through preemptive actions to enhance our ability to meet our liquidity needs over the next twelve months. Such actions include, but are not limited to modifying the financial covenants in our revolving and term loan credit agreements and issuing  $750 million of unsecured, unsubordinated long-term debt (see Note 10 – Borrowings and Lines of Credit for additional information), reducing our discretionary spending, our capital investments and general and administrative costs by implementing pay freezes and cuts, employee furloughs and the suspension of non-critical hiring, and participation in global COVID-19 relief measures, including the Coronavirus Aid, Relief, and Economic Security ("CARES") Act, which provides for payroll tax deferrals and credits, income tax payment deferrals, and an increase in the income tax interest deduction limitation. 
DESCRIPTION OF THE BUSINESS 
Carrier Global Corporation is a leading global provider of heating, ventilating, air conditioning ("HVAC"), refrigeration, and fire and security solutions. Carrier also provides a broad array of related building services, including audit, design, installation, system integration, repair, maintenance and monitoring. Carrier’s operations are classified into three segments: HVAC, Refrigeration, and Fire & Security. The HVAC and Refrigeration segments sell their products and solutions directly, including to building contractors and owners, transportation companies and retail stores, or indirectly through joint venture and other minority-owned investments, independent sales representatives, distributors, wholesalers, dealers and retail outlets. These products and services are sold under the Carrier name and other brand names including Automated Logic, Bryant, CIAT, Day & Night, Heil, NORESCO, Riello, Carrier Commercial Refrigeration, Carrier Transicold, Sensitech and others. The Fire & Security segment sells its products directly to customers, or indirectly through manufacturers’ representatives, distributors, dealers, value-added resellers and retailers. Fire & Security’s products and services are used by governments, financial institutions, architects, building owners and developers, security and fire consultants, homeowners and other end-users requiring a high level of security and fire protection for their businesses and residences. These products and services are sold under brand names including Autronica, Chubb, Det-Tronics, Edwards, Fireye, GST, Kidde, LenelS2, Marioff, Onity, Supra and others.

- changed (2020-10-29):
[0001783180-20-000067:note_history:23]
On November 26, 2018, United Technologies Corporation, since renamed Raytheon Technologies Corporation ("UTC"), announced its intention to spin off Carrier, one of UTC's reportable segments, into a separate publicly traded company (the "Separation").  On April 3, 2020 (the "Distribution Date"), UTC completed the Separation through a pro-rata distribution (the "Distribution") of all of the outstanding common stock of the Company to UTC shareowners who held shares of UTC common stock as of the close of business on March 19, 2020, the record date for the Distribution. UTC distributed 866,158,910 shares of Carrier common stock in the Distribution, which was effective at 12:01 a.m., Eastern Time, on April 3, 2020 (the "Effective Time"). As a result of the Distribution, UTC shareowners of record received one share of the Company's common stock for every one share of UTC common stock and Carrier became an independent public company and our common stock is listed under the symbol "CARR" on the New York Stock Exchange.  In connection with the Separation, Carrier issued an aggregate principal balance of $11.0 billion of debt and transferred approximately $10.9 billion of cash to UTC on February 27, 2020 and March 27, 2020. On April 1, 2020 and April 2, 2020, Carrier received cash contributions totaling $590 million from UTC related to the Separation. See Note 10 – Borrowings and Lines of Credit and Note 3 – Earnings Per Share for additional information.
  (was, 2020-07-31, similarity 0.9452):
[0001783180-20-000052:note_history:23]
On November 26, 2018, United Technologies Corporation, since renamed Raytheon Technologies Corporation ("UTC"), announced its intention to spin off Carrier, one of UTC's reportable segments, into a separate publicly traded company (the "Separation").  On April 3, 2020, UTC completed the Separation through a pro-rata distribution (the "Distribution") of all of the outstanding common stock of the Company to UTC shareowners who held shares of UTC common stock as of the close of business on March 19, 2020, the record date for the Distribution. UTC distributed 866,158,910 shares of Carrier common stock in the Distribution, which was effective at 12:01 a.m., Eastern Time, on April 3, 2020 (the "Effective Time"). As a result of the Distribution, Carrier became an independent public company and our common stock is listed under the symbol "CARR" on the New York Stock Exchange.  In connection with the Separation, Carrier issued an aggregate principal balance of $11.0 billion of debt and transferred approximately $10.9 billion of cash to UTC on February 27, 2020 and March 27, 2020. On April 1, 2020 and April 2, 2020, Carrier received cash contributions totaling $590 million from UTC related to the Separation. See Note 10 – Borrowings and Lines of Credit and Note 3 – Earnings Per Share for additional information.

- changed (2020-10-29):
[0001783180-20-000067:note_history:24]
Transition Services Agreement.  We entered into a Transition Services Agreement (the "TSA") with UTC and Otis in connection with the Separation pursuant to which UTC provides us with certain services and we provide certain services to UTC for a limited time to help ensure an orderly transition following the Separation. The services we receive include, but are not limited to, information technology services, technical and engineering support, application support for operations, legal, payroll, finance, tax and accounting, general administrative services and other support services. The costs for these services historically were included in our operating results based on allocations from UTC and in the nine months ended September 30, 2020, were not materially different under the TSA from such costs historically nor do we expect such costs to be materially different when these services are ultimately transitioned from UTC to Carrier.
  (was, 2020-07-31, similarity 0.84):
[0001783180-20-000052:note_history:24]
Transition Services Agreement.  We entered into a Transition Services Agreement (the "TSA") with UTC and Otis in connection with the Separation pursuant to which UTC provides us with certain services and we provide certain services to UTC for a limited time to help ensure an orderly transition following the Separation. The services we receive include, but are not limited to, information technology services, technical and engineering support, application support for operations, legal, payroll, finance, tax and accounting, general administrative services and other support services. Because costs for these services historically were included in our operating results based on allocations from UTC, we do not expect the costs associated with the TSA to be materially different and, therefore, we do not expect such costs to materially affect our results of operations or cash flows after we became an independent publicly traded company nor do we expect such costs to be materially different when these services are transitioned from UTC to Carrier.

- changed (2020-10-29):
[0001783180-20-000067:note_history:25]
Tax Matters Agreement.  We entered into a Tax Matters Agreement (the "TMA") with UTC and Otis that governs the parties’ respective rights, responsibilities and obligations with respect to tax matters (including responsibility for taxes, entitlement to refunds, allocation of tax attributes, preparation of tax returns, control of tax contests and other tax matters).  Subject to certain exceptions set forth in the TMA, Carrier generally is responsible for federal, state and foreign taxes imposed on a separate return basis upon Carrier (or any of its subsidiaries) with respect to taxable periods (or portions thereof) that ended on or prior to the date of the Distribution.  The TMA provides special rules that allocate responsibility for tax liabilities arising from a failure of the Separation transactions to qualify for tax-free treatment based on the reasons for such failure.  The
  (was, 2020-07-31, similarity 0.8846):
[0001783180-20-000052:note_history:25]
Tax Matters Agreement.  We entered into a Tax Matters Agreement (the "TMA") with UTC and Otis that governs the parties’ respective rights, responsibilities and obligations with respect to tax matters (including responsibility for taxes, entitlement to refunds, allocation of tax attributes, preparation of tax returns, control of tax contests and other tax matters).  Subject to certain exceptions set forth in the TMA, Carrier generally is responsible for federal, state and foreign taxes imposed on a separate return basis upon Carrier (or any of its subsidiaries) with respect to taxable periods (or portions thereof) that ended on or prior to the date of the Distribution.  The TMA provides special rules that allocate responsibility for tax liabilities arising from a failure of the Separation transactions to qualify for tax-free treatment based on the reasons for such failure.  The TMA also imposes restrictions on each of Carrier and Otis during the two-year period following the Distribution that are intended to prevent certain transactions from failing to qualify as transactions that are generally tax-free.

- added (2020-10-29):
[0001783180-20-000067:note_history:26]
TMA also imposes restrictions on each of Carrier and Otis during the two-year period following the Distribution that are intended to prevent certain transactions from failing to qualify as transactions that are generally tax-free.

- removed (2020-10-29):
[0001783180-20-000052:note_history:27]
Carrier is taking all prudent measures to protect the health and safety of our employees and has implemented work from home requirements, where possible, social distancing where working from home is not feasible, including in our manufacturing facilities, deep cleaning protocols at all of our facilities and travel restrictions, among other measures. We have also taken appropriate measures to work with our customers to minimize potential disruption and to support the communities that we serve to address the challenges posed by the pandemic.

- removed (2020-10-29):
[0001783180-20-000052:note_history:28]
During the three months ended March 31, 2020, we temporarily closed or reduced production at manufacturing facilities in North America, Asia and Europe for safety reasons and in response to lower demand for our products, however, as of June 30, 2020, our manufacturing facilities (and nearly all of our suppliers) had resumed operations and 95% of our production capacity was available and, where appropriate, we initiated return-to-work protocols at our non-manufacturing facilities where employees were previously working remotely. During the three months ended March 31, 2020, we considered the outbreak and subsequent impacts to be a trigger to reassess our goodwill and intangible asset valuations.  In order to evaluate these impacts, we made forecast assumptions regarding future business activity that are subject to a wide range of uncertainties, including those noted in the prior paragraph.  Based upon qualitative and, in certain cases, quantitative analyses, we determined that our goodwill and intangible assets were not impaired. For the period ended June 30, 2020, we reviewed the assumptions used in our March 31, 2020 assessment and determined that they remain appropriate.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-10-29):
[0001783180-20-000067:note_history:29]
BORROWINGS AND LINES OF CREDIT 
On February 10, 2020, we entered into a revolving credit agreement with various banks permitting aggregate borrowings of up to $2.0 billion pursuant to an unsecured, unsubordinated revolving credit facility that matures on April 3, 2025 (the "revolving credit facility").  The revolving credit facility supports our commercial paper program and cash requirements.  A commitment fee of 0.125% is charged on the unused commitments.  Borrowings under the revolving credit facility are available in U.S. Dollars, Euros and Pounds Sterling and bear interest at a variable interest rate based on LIBOR plus a ratings-based margin, which was 125 basis points as of September 30, 2020.  As of September 30, 2020, there were no borrowings under the revolving credit facility.
  (was, 2020-07-31, similarity 0.924):
[0001783180-20-000052:note_history:29]
BORROWINGS AND LINES OF CREDIT 
On February 10, 2020, we entered into a revolving credit agreement with various banks permitting aggregate borrowings of up to $2.0 billion pursuant to an unsecured, unsubordinated revolving credit facility that matures on April 3, 2025 (the "revolving credit facility").  The revolving credit facility supports our commercial paper program and cash requirements.  A commitment fee of 0.125% is charged on the unused commitments.  Borrowings under the revolving credit facility are available in U.S. Dollars, Euros and Pounds Sterling and bear interest at a variable interest rate based on LIBOR plus a ratings-based margin, which was 125 basis points as of June 30, 2020.  As of June 30, 2020, there were no borrowings on the revolving credit facility.

- changed (2020-10-29):
[0001783180-20-000067:note_history:30]
On February 10, 2020, we entered into a $1.75 billion term loan credit agreement that provides an unsecured, unsubordinated term loan credit facility which matures on February 10, 2023 (the "term loan credit facility").
  (was, 2020-07-31, similarity 0.7057):
[0001783180-20-000052:note_history:30]
On February 10, 2020, we entered into a $1.75 billion term loan credit agreement that provides an unsecured, unsubordinated term loan credit facility which matures on February 10, 2023 (the "term loan credit facility").  Borrowings under the term loan credit facility are subject to a variable interest rate based on LIBOR plus a ratings-based margin, which was 112.5 basis points as of June 30, 2020.

- changed (2020-10-29):
[0001783180-20-000067:note_history:31]
The revolving credit facility, term loan credit facility and indenture contain affirmative and negative covenants customary for financings of this type, that among other things, limit Carrier and its subsidiaries' ability to incur additional liens, to make certain fundamental changes and to enter into sale and leaseback transactions. On June 2, 2020, the Company entered into amendments to both the revolving credit facility and the term loan credit facility.  Pursuant to the amendments, certain terms of the revolving credit facility and the term loan credit facility were amended for a period beginning on June 2, 2020 and ending on December 30, 2021 (the "Covenant Modification Period").  The Company may terminate the Covenant Modification Period prior to December 30, 2021, subject to the satisfaction of certain conditions.  The amendments defer testing of our consolidated total net leverage ratio financial covenant until June 30, 2021 and increase the consolidated total net leverage ratio limit until December 31, 2021.  The amendments also require us to maintain liquidity at a certain level until the earlier of (1) June 29, 2021 and (2) the last day of the Covenant Modification Period.  Additionally, during the Covenant Modification Period, the Company is subject to (a) limitations on the incurrence of subsidiary indebtedness, (b) limitations on the making of restricted payments, including purchases by the Company of its ordinary shares and the amount of dividends the Company may pay, and
  (was, 2020-07-31, similarity 0.8844):
[0001783180-20-000052:note_history:31]
The revolving credit agreement, term loan credit agreement and indenture contain affirmative and negative covenants customary for financings of this type, that among other things, limit Carrier and its subsidiaries' ability to incur additional liens, to make certain fundamental changes and to enter into sale and leaseback transactions. On June 2, 2020, the Company entered into amendments to both the revolving credit agreement and the term loan credit agreement.  Pursuant to the amendments, certain terms of the revolving credit facility and the term loan credit facility were amended for a period beginning on June 2, 2020 and ending on December 30, 2021 (the "Covenant Modification Period").  The Company may terminate the Covenant Modification Period prior to December 30, 2021 subject to the satisfaction of certain conditions.  The amendments defer testing of our consolidated total net leverage ratio financial covenant until June 30, 2021 and increases the consolidated total net leverage ratio limit until December 31, 2021.  The amendments also require us to maintain liquidity at a certain level until the earlier of (1) June 29, 2021 and (2) the last day of the Covenant Modification Period.  Additionally, during the Covenant Modification Period, the Company is subject to (a) limitations on the incurrence of subsidiary indebtedness, (b) limitations on the making of restricted payments, including purchases by the Company of its ordinary shares and the amount of dividends the Company may pay, and (c) a "most favored nations" provision related to certain terms of any committed credit facility in an amount greater than $100 million.  As of June 30, 2020, we were compliant with our covenants under the agreements governing our outstanding indebtedness.

- added (2020-10-29):
[0001783180-20-000067:note_history:32]
(c) a "most favored nations" provision related to certain terms of any committed credit facility in an amount greater than $100 million.  As of September 30, 2020, we were compliant with our covenants under the agreements governing our outstanding indebtedness.

- changed (2020-10-29):
[0001783180-20-000067:note_history:33]
On June 19, 2020, we issued $750 million of unsecured, unsubordinated 2.700% Notes due 2031.  These notes rank equally with our existing unsecured, unsubordinated obligations.  The net proceeds from the sale of the notes, which further enhance our liquidity and financial flexibility during the ongoing COVID-19 pandemic, are being used for general corporate purposes.
  (was, 2020-07-31, similarity 0.9543):
[0001783180-20-000052:note_history:33]
On June 19, 2020, we issued $750 million of unsecured, unsubordinated 2.700% Notes due 2031.  These notes rank equally with our existing unsecured, unsubordinated obligations.  We expect to use the net proceeds from the sale of the notes, which further enhance our liquidity and financial flexibility during the ongoing COVID-19 pandemic, for general corporate purposes.

- added (2020-10-29):
[0001783180-20-000067:note_history:34]
As of September 30, 2020, we have a $2.0 billion unsecured, unsubordinated commercial paper program which we plan to use for general corporate purposes, including the funding of working capital and potential acquisitions. As of September 30, 2020, there were no borrowings outstanding under the commercial paper program.

- changed (2020-10-29):
[0001783180-20-000067:note_history:35]
Long-term debt, all of which was issued during the nine months ended September 30, 2020 except for Other long-term debt, consisted of the following:
  (was, 2020-07-31, similarity 0.9429):
[0001783180-20-000052:note_history:35]
Long-term debt, all of which was issued during the six months ended June 30, 2020 except for Other long-term debt, consisted of the following:

- changed (2020-10-29):
[0001783180-20-000067:note_history:36]
| (dollars in millions) |  |  |  |  |  |  |  |  |
| Debt Description | Interest Rate |  |  | September 30, 2020 |  |  | December 31, 2019 |  |
| 3-Year Term Loan Credit Facility due February 10, 2023 | 1.275 | % | 1 |  | $ | 1,750 |  | 2 |  | $ | — |  |  |
| 1.923% Notes due February 15, 2023 | 1.923 | % |  |  | 500 |  | 2 |  | — |  |  |
| 2.242% Notes due February 15, 2025 | 2.242 | % |  |  | 2,000 |  | 2 |  | — |  |  |
| 2.493% Notes due February 15, 2027 | 2.493 | % |  |  | 1,250 |  | 2 |  | — |  |  |
| 2.722% Notes due February 15, 2030 | 2.722 | % |  |  | 2,000 |  | 2 |  | — |  |  |
| 2.700% Notes due February 15, 2031 | 2.700 | % |  |  | 750 |  |  |  | — |  |  |
| 3.377% Notes due April 5, 2040 | 3.377 | % |  |  | 1,500 |  | 2 |  | — |  |  |
| 3.577% Notes due April 5, 2050 | 3.577 | % |  |  | 2,000 |  | 2 |  | — |  |  |
| Other (including project financing obligations and finance leases) |  |  |  | 309 |  |  |  | 319 |  |  |
| Total principal long-term debt |  |  |  | 12,059 |  |  |  | 319 |  |  |
| Other (discounts and debt issuance costs) |  |  |  | (85) |  |  |  | — |  |  |
| Total debt |  |  |  | 11,974 |  |  |  | 319 |  |  |
| Less: current portion of long-term debt |  |  |  | 223 |  |  |  | 237 |  |  |
| Long-term debt, net of current portion |  |  |  | $ | 11,751 |  |  |  | $ | 82 |  |  |
  (was, 2020-07-31, similarity 0.9938):
[0001783180-20-000052:note_history:36]
| (dollars in millions) |  |  |  |  |  |  |  |  |
| Debt Description | Interest Rate |  |  | June 30, 2020 |  |  | December 31, 2019 |  |
| 3-Year Term Loan Credit Facility due February 10, 2023 | 2.195 | % | 1 |  | $ | 1,750 |  | 2 |  | $ | — |  |  |
| 1.923% Notes due February 15, 2023 | 1.923 | % |  |  | 500 |  | 2 |  | — |  |  |
| 2.242% Notes due February 15, 2025 | 2.242 | % |  |  | 2,000 |  | 2 |  | — |  |  |
| 2.493% Notes due February 15, 2027 | 2.493 | % |  |  | 1,250 |  | 2 |  | — |  |  |
| 2.722% Notes due February 15, 2030 | 2.722 | % |  |  | 2,000 |  | 2 |  | — |  |  |
| 2.700% Notes due February 15, 2031 | 2.700 | % |  |  | 750 |  |  |  | — |  |  |
| 3.377% Notes due April 05, 2040 | 3.377 | % |  |  | 1,500 |  | 2 |  | — |  |  |
| 3.577% Notes due April 05, 2050 | 3.577 | % |  |  | 2,000 |  | 2 |  | — |  |  |
| Other (including project financing obligations and finance leases) |  |  |  | 367 |  |  |  | 319 |  |  |
| Total principal long-term debt |  |  |  | 12,117 |  |  |  | 319 |  |  |
| Other (discounts and debt issuance costs) |  |  |  | (88) |  |  |  | — |  |  |
| Total debt |  |  |  | 12,029 |  |  |  | 319 |  |  |
| Less: current portion of long-term debt |  |  |  | 301 |  |  |  | 237 |  |  |
| Long-term debt, net of current portion |  |  |  | $ | 11,728 |  |  |  | $ | 82 |  |  |

- changed (2020-10-29):
[0001783180-20-000067:note_history:37]
1 The interest rate on the term loan as of September 30, 2020 was 1.275% which is a variable rate based on one-month LIBOR plus 112.5 basis points.
  (was, 2020-07-31, similarity 0.7692):
[0001783180-20-000052:note_history:37]
1 The interest rate on the term loan is variable based on six month LIBOR of 1.07% plus 112.5 basis points.

- changed (2020-10-29):
[0001783180-20-000067:note_history:38]
We issued $102 million and $106 million of debt during the nine months ended September 30, 2020 and 2019, respectively, relating to project financing arrangements.  Long-term debt repayments during the nine months ended September 30, 2020 and 2019 were $124 million and $98 million, respectively, relating to project financing arrangements.
  (was, 2020-07-31, similarity 0.7561):
[0001783180-20-000052:note_history:38]
We issued $75 million and $77 million of debt during the six months ended June 30, 2020 and 2019, respectively, relating to project financing arrangements.  Long-term debt repayments during the six months ended June 30, 2020 and 2019 were $36 million and $37 million, respectively.

- added (2020-10-29):
[0001783180-20-000067:note_history:39]
The average maturity of our long-term debt as of September 30, 2020 is approximately 12 years and the weighted-average interest rate on our total borrowings for the three months ended September 30, 2020 is approximately 2.7%. Interest expense associated with long-term debt for the three and nine months ended September 30, 2020 was $90 million and $213 million, respectively.  Included in Interest expense, net on the accompanying Unaudited Condensed Consolidated Statement of Operations is amortization of debt issuance costs of $2 million and $5 million, respectively, for the three and nine months ended September 30, 2020.  Also included in Interest expense, net for the nine months ended September 30, 2020 are debt issuance costs of $5 million that were expensed in the three months ended March 31, 2020.  Included in Accrued liabilities on the accompanying Unaudited Condensed Consolidated Balance Sheet was accrued interest of $127 million as of September 30, 2020.

- removed (2020-10-29):
[0001783180-20-000052:note_history:40]
As of June 30, 2020, we have a $2.0 billion unsecured, unsubordinated commercial paper program which we plan to use for general corporate purposes, including the funding of working capital and potential acquisitions. As of June 30, 2020, there were no borrowings outstanding under the commercial paper program.

- removed (2020-10-29):
[0001783180-20-000052:note_history:41]
The average maturity of our long-term debt at June 30, 2020 is approximately 12 years and the weighted-average interest rate on our total borrowings for the three months ended June 30, 2020 is approximately 2.7%. Interest expense associated with long-term debt for the three and six months ended June 30, 2020 was $85 million and $126 million, respectively.  Included in interest expense on the accompanying Unaudited Condensed Consolidated Statement of Operations is accrued interest of $83 million and amortization of debt issuance costs of $2 million for the three months ended June 30, 2020, and accrued interest of $118 million, debt issuance costs of $5 million and amortization of debt issuance costs of $3 million for the six months ended June 30, 2020.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-10-29):
[0001783180-20-000067:note_history:42]
Long-term debt, all of which was issued during the nine months ended September 30, 2020 except for Other long-term debt, consisted of the following:
  (was, 2020-07-31, similarity 0.9429):
[0001783180-20-000052:note_history:42]
Long-term debt, all of which was issued during the six months ended June 30, 2020 except for Other long-term debt, consisted of the following:

- changed (2020-10-29):
[0001783180-20-000067:note_history:43]
| (dollars in millions) |  |  |  |  |  |  |  |  |
| Debt Description | Interest Rate |  |  | September 30, 2020 |  |  | December 31, 2019 |  |
| 3-Year Term Loan Credit Facility due February 10, 2023 | 1.275 | % | 1 |  | $ | 1,750 |  | 2 |  | $ | — |  |  |
| 1.923% Notes due February 15, 2023 | 1.923 | % |  |  | 500 |  | 2 |  | — |  |  |
| 2.242% Notes due February 15, 2025 | 2.242 | % |  |  | 2,000 |  | 2 |  | — |  |  |
| 2.493% Notes due February 15, 2027 | 2.493 | % |  |  | 1,250 |  | 2 |  | — |  |  |
| 2.722% Notes due February 15, 2030 | 2.722 | % |  |  | 2,000 |  | 2 |  | — |  |  |
| 2.700% Notes due February 15, 2031 | 2.700 | % |  |  | 750 |  |  |  | — |  |  |
| 3.377% Notes due April 5, 2040 | 3.377 | % |  |  | 1,500 |  | 2 |  | — |  |  |
| 3.577% Notes due April 5, 2050 | 3.577 | % |  |  | 2,000 |  | 2 |  | — |  |  |
| Other (including project financing obligations and finance leases) |  |  |  | 309 |  |  |  | 319 |  |  |
| Total principal long-term debt |  |  |  | 12,059 |  |  |  | 319 |  |  |
| Other (discounts and debt issuance costs) |  |  |  | (85) |  |  |  | — |  |  |
| Total debt |  |  |  | 11,974 |  |  |  | 319 |  |  |
| Less: current portion of long-term debt |  |  |  | 223 |  |  |  | 237 |  |  |
| Long-term debt, net of current portion |  |  |  | $ | 11,751 |  |  |  | $ | 82 |  |  |
  (was, 2020-07-31, similarity 0.9938):
[0001783180-20-000052:note_history:43]
| (dollars in millions) |  |  |  |  |  |  |  |  |
| Debt Description | Interest Rate |  |  | June 30, 2020 |  |  | December 31, 2019 |  |
| 3-Year Term Loan Credit Facility due February 10, 2023 | 2.195 | % | 1 |  | $ | 1,750 |  | 2 |  | $ | — |  |  |
| 1.923% Notes due February 15, 2023 | 1.923 | % |  |  | 500 |  | 2 |  | — |  |  |
| 2.242% Notes due February 15, 2025 | 2.242 | % |  |  | 2,000 |  | 2 |  | — |  |  |
| 2.493% Notes due February 15, 2027 | 2.493 | % |  |  | 1,250 |  | 2 |  | — |  |  |
| 2.722% Notes due February 15, 2030 | 2.722 | % |  |  | 2,000 |  | 2 |  | — |  |  |
| 2.700% Notes due February 15, 2031 | 2.700 | % |  |  | 750 |  |  |  | — |  |  |
| 3.377% Notes due April 05, 2040 | 3.377 | % |  |  | 1,500 |  | 2 |  | — |  |  |
| 3.577% Notes due April 05, 2050 | 3.577 | % |  |  | 2,000 |  | 2 |  | — |  |  |
| Other (including project financing obligations and finance leases) |  |  |  | 367 |  |  |  | 319 |  |  |
| Total principal long-term debt |  |  |  | 12,117 |  |  |  | 319 |  |  |
| Other (discounts and debt issuance costs) |  |  |  | (88) |  |  |  | — |  |  |
| Total debt |  |  |  | 12,029 |  |  |  | 319 |  |  |
| Less: current portion of long-term debt |  |  |  | 301 |  |  |  | 237 |  |  |
| Long-term debt, net of current portion |  |  |  | $ | 11,728 |  |  |  | $ | 82 |  |  |

- changed (2020-10-29):
[0001783180-20-000067:note_history:44]
1 The interest rate on the term loan as of September 30, 2020 was 1.275% which is a variable rate based on one-month LIBOR plus 112.5 basis points.
  (was, 2020-07-31, similarity 0.7692):
[0001783180-20-000052:note_history:44]
1 The interest rate on the term loan is variable based on six month LIBOR of 1.07% plus 112.5 basis points.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2020-10-29):
[0001783180-20-000067:note_history:45]
Carrier sells products to and purchases products from unconsolidated entities accounted for under the equity method and, therefore, these entities are considered related parties.  During the three months ended September 30, 2020 and 2019, Product sales in the Unaudited Condensed Consolidated Statement of Operations included sales to equity method investees of $576 million and $498 million, respectively. During the three months ended September 30, 2020 and 2019, Cost of products sold in the Unaudited Condensed Consolidated Statement of Operations included purchases from equity method investees of $70 million and $96 million, respectively.
  (was, 2020-07-31, similarity 0.9569):
[0001783180-20-000052:note_history:45]
Carrier sells products to and purchases products from unconsolidated entities accounted for under the equity method, and, therefore, these entities are considered related parties.  During the three months ended June 30, 2020 and 2019, Product sales in the Unaudited Condensed Consolidated Statement of Operations included sales to equity method investees of $434 million and $546 million, respectively. During the three months ended June 30, 2020 and 2019, Cost of products sold in the Unaudited Condensed Consolidated Statement of Operations included purchases from equity method investees of $66 million and $101 million, respectively.

- added (2020-10-29):
[0001783180-20-000067:note_history:46]
During the nine months ended September 30, 2020 and 2019, Product sales in the Unaudited Condensed Consolidated Statement of Operations included sales to equity method investees of $1.4 billion and $1.4 billion, respectively. During the nine months ended September 30, 2020 and 2019, Cost of products sold in the Unaudited Condensed Consolidated Statement of Operations included purchases from equity method investees of $213 million and $274 million, respectively.

- added (2020-10-29):
[0001783180-20-000067:note_history:47]
Carrier had receivables from equity method investees of $213 million and $137 million at September 30, 2020 and December 31, 2019, respectively. Carrier also had payables to equity method investees of $40 million and $55 million at September 30, 2020 and December 31, 2019, respectively. The receivables and payables are included in Accounts receivable, net and Accounts payable on the Unaudited Condensed Consolidated Balance Sheet.

- changed (2020-10-29):
[0001783180-20-000067:note_history:48]
The Company periodically reviews the carrying value of its equity method investments to determine if there has been an other-than-temporary decline in fair value. A variety of factors are considered when determining if a decline in carrying value is other-than-temporary, including, among other factors, the financial condition and business prospects of the investee, as well as the Company's intent with regard to the investment.  During the three months ended March 31, 2020, we determined that indicators of impairment existed for a minority owned joint venture investment in the portfolio.  We performed a valuation of this investment, which was based on the income approach using the discounted cash flow method. We determined that the loss in value was other-than-temporary due to a reduction in sales and earnings that were driven by a deterioration in the oil and gas industry (the joint venture's primary market) and by the impact of the COVID-19 pandemic, among other factors. As a result, we recorded a non-cash, other-than-temporary impairment charge of $71 million on this investment during the three months ended March 31, 2020 which is included in Other income (expense), net on the accompanying Unaudited Condensed Consolidated Statement of Operations.
  (was, 2020-07-31, similarity 0.806):
[0001783180-20-000052:note_history:48]
The Company periodically reviews the carrying value of its equity method investments to determine if there has been an other-than-temporary decline in fair value. A variety of factors are considered when determining if a decline in carrying value is other-than-temporary, including, among other factors, the financial condition and business prospects of the investee, as well as the Company's intent with regard to the investment.  During the three months ended March 31, 2020, we determined that indicators of impairment existed for a minority owned joint venture investment in the portfolio.  We performed a valuation of this investment, based on the income approach using the discounted cash flow method. We determined that the loss in value was other-than-temporary due to a reduction in sales and earnings that were driven by a deterioration in the oil and gas industry (the joint venture's primary market) and the impact of the COVID-19 pandemic, among other factors. As a result, we recorded a non-cash, other-than-temporary impairment charge of $71 million on this investment during the three months ended March 31, 2020 which is included in Other (expense) income, net on the accompanying Unaudited Condensed Consolidated Statement of Operations. During the three months ended June 30, 2020, there were no significant equity method investment impairment charges.

- added (2020-10-29):
[0001783180-20-000067:note_history:49]
In September 2020, the Company sold 9.25 million B shares of Beijer Ref AB ("Beijer") for SEK290 ($32.38) per share equal to approximately 7.9% of the outstanding B shares in Beijer, through an accelerated equity offering. We received proceeds of approximately $300 million and recognized a pre-tax gain on the sale of $252 million included in Other income (expense), net on the accompanying Unaudited Condensed Consolidated Statement of Operations.  Following the sale, Beijer, which is listed on the Nasdaq Stockholm, continues to be reported as an equity method investment with Carrier continuing to hold approximately 30% of Beijer's B shares, approximately 22% of Beijer's A shares and approximately 26% of the Beijer total votes.

- changed (2020-10-29):
[0001783180-20-000067:note_history:50]
Prior to the Separation, Carrier had been managed and operated in the normal course of business with other affiliates of UTC.  Accordingly, certain shared costs were allocated to the Company and are reflected as expenses in the Unaudited Condensed Consolidated Financial Statements.
  (was, 2020-07-31, similarity 0.9788):
[0001783180-20-000052:note_history:50]
Prior to the Separation, Carrier had been managed and operated in the normal course of business with other affiliates of UTC.  Accordingly, certain shared costs had been allocated to the Company and are reflected as expenses in the Unaudited Condensed Consolidated Financial Statements.

- changed (2020-10-29):
[0001783180-20-000067:note_history:51]
Related Party Sales.  During the periods prior to the Separation, the Company sold products and services to UTC and its other affiliates.  Product sales in the Unaudited Condensed Consolidated Statement of Operations include sales to UTC and affiliates of UTC other than Carrier of $0 million and $6 million for the three months ended September 30, 2020 and 2019, respectively, and $3 million and $18 million for the nine months ended September 30, 2020 and 2019, respectively.
  (was, 2020-07-31, similarity 0.9323):
[0001783180-20-000052:note_history:51]
Related Party Sales.  During the periods prior to the Separation, the Company sold products and services to UTC and its other affiliates.  Product sales in the Unaudited Condensed Consolidated Statement of Operations include sales to UTC and affiliates of UTC other than Carrier of $0 million and $6 million for the three months ended June 30, 2020 and 2019, respectively, and $3 million and $12 million for the six months ended June 30, 2020 and 2019, respectively.

- changed (2020-10-29):
[0001783180-20-000067:note_history:52]
Allocated Centralized Costs.  Prior to the Separation, UTC incurred corporate costs for services provided to Carrier and to other UTC businesses.  These services included treasury, tax, accounting, human resources, internal audit, legal, purchasing and information technology.  The costs associated with these services generally included all payroll and benefit costs as well as related overhead costs.  UTC also allocated costs associated with corporate insurance coverage and medical, pension, post-retirement and other health plan costs for employees participating in UTC sponsored plans. UTC corporate costs were either specifically attributed and charged to Carrier, when possible, or allocated to the Company. Allocations were based on direct usage where identifiable and on a number of other utilization measures including headcount, proportionate usage and net sales.  All such amounts were deemed incurred and settled by the Company in the period in which the costs were recorded and are included in UTC Net investment.
  (was, 2020-07-31, similarity 0.9907):
[0001783180-20-000052:note_history:52]
Allocated Centralized Costs.  Prior to the Separation, UTC incurred corporate costs for services provided to the Company and to other UTC businesses.  These services included treasury, tax, accounting, human resources, internal audit, legal, purchasing, and information technology.  The costs associated with these services generally included all payroll and benefit costs as well as related overhead costs.  UTC also allocated costs associated with corporate insurance coverage and medical, pension, post-retirement and other health plan costs for employees participating in UTC sponsored plans. UTC corporate costs were either specifically attributed and charged to Carrier, when possible, or allocated to the Company. Allocations were based on direct usage where identifiable and on a number of other utilization measures including headcount, proportionate usage and net sales.  All such amounts were deemed incurred and settled by the Company in the period in which the costs were recorded and are included in UTC Net investment.

- added (2020-10-29):
[0001783180-20-000067:note_history:53]
The allocated centralized costs for the three months ended September 30, 2020 and 2019 were $0 million and $62 million, respectively, and for the nine months ended September 30, 2020 and 2019 were $43 million and $178 million, respectively, and are primarily included in Selling, general and administrative in the Unaudited Condensed Consolidated Statement of Operations.

- changed (2020-10-29):
[0001783180-20-000067:note_history:54]
The expense and cost allocations have been determined on a basis considered to be a reasonable reflection of the utilization of services provided to or for the benefit of the Company prior to the Separation.  The amounts that would have been, or will be incurred on a stand-alone basis could differ from the amounts allocated due to economies of scale, differences in management approach, a need for more or fewer employees, or other factors. In addition, the Company's future results of operations, financial position and cash flows could differ materially from the historical results presented herein.
  (was, 2020-07-31, similarity 0.9703):
[0001783180-20-000052:note_history:54]
The expense and cost allocations have been determined on a basis considered to be a reasonable reflection of the utilization of services provided to or for the benefit received by the Company prior to the Separation.  The amounts that would have been, or will be incurred, on a stand-alone basis could differ from the amounts allocated due to economies of scale, differences in management approach, a need for more or fewer employees, or other factors. In addition, the Company's future results of operations, financial position and cash flows could differ materially from the historical results presented herein.

- added (2020-10-29):
[0001783180-20-000067:note_history:55]
Separation Costs. In connection with the Separation, we have incurred separation-related costs of approximately $24 million and $92 million for the three and nine months ended September 30, 2020, respectively, and $13 million and $13 million for the three and nine months ended September 30, 2019, respectively, primarily recorded in Selling, general and administrative in the Unaudited Condensed Consolidated Statement of Operations, which primarily consist of employee-related costs, costs to establish certain stand-alone functions and information technology systems, professional service fees and other transaction-related costs resulting from Carrier becoming an independent, publicly traded company.

- added (2020-10-29):
[0001783180-20-000067:note_history:56]
During the nine months ended September 30, 2020, net assets of $780 million were contributed to the Company by UTC which primarily consisted of cash of $590 million, deferred tax assets and liabilities and fixed assets. These contributions of net assets are recorded as Net transfers from UTC on the Unaudited Condensed Consolidated Statement of Changes in Equity through UTC Net investment.

- changed (2020-10-29):
[0001783180-20-000067:note_history:57]
Accounts Receivable and Payable. Certain related party transactions between the Company and UTC were included within UTC Net investment in the Unaudited Condensed Consolidated Balance Sheet as of December 31, 2019 when the related party transactions were not settled in cash.  As of December 31, 2019, the UTC Net investment includes related party receivables due from UTC and its affiliates of $16.0 billion and related party payables due to UTC and its affiliates of $3.3 billion.  At the Distribution Date, UTC Net investment was reclassified to Common stock and Additional paid-in capital.
  (was, 2020-07-31, similarity 0.958):
[0001783180-20-000052:note_history:57]
Accounts Receivable and Payable. Certain related party transactions between the Company and UTC were included within UTC Net investment in the Unaudited Condensed Consolidated Balance Sheet as of December 31, 2019 when the related party transactions were not settled in cash.  As of December 31, 2019, the UTC Net investment includes related party receivables due from UTC and its affiliates of $16.0 billion and related party payables due to UTC and its affiliates of $3.3 billion.  As of June 30, 2020, UTC Net investment has been reclassified to Common stock and Additional paid-in capital.

- changed (2020-10-29):
[0001783180-20-000067:note_history:58]
Prior to the Separation, interest income and expense related to activity with UTC that was historically included in Carrier’s results is presented on a net basis in the Unaudited Condensed Consolidated Statement of Operations.  For the three and nine months ended September 30, 2019, there was $21 million and $70 million, respectively, of interest income from activity with UTC.  For the three and nine months ended September 30, 2019, there was $12 million and $44 million, respectively, of interest expense from activity with UTC.  The effect of the settlement of these related party transactions is included in financing activity
  (was, 2020-07-31, similarity 0.8069):
[0001783180-20-000052:note_history:58]
Prior to the Separation, interest income and expense related to activity with UTC that was historically included in Carrier’s results is presented on a net basis in the Unaudited Condensed Consolidated Statement of Operations.  For the three and six months ended June 30, 2019, there was $21 million and $49 million, respectively, of interest income from activity with UTC.  For the three and six months ended June 30, 2019, there was $16 million and $32 million, respectively, of interest expense from activity with UTC.  The effect of the settlement of these related party transactions is included in financing activity in the Unaudited Condensed Consolidated Statement of Cash Flows.  There was no interest income or expense from activity with UTC for the three and six months ended June 30, 2020.

- added (2020-10-29):
[0001783180-20-000067:note_history:59]
in the Unaudited Condensed Consolidated Statement of Cash Flows.  There was no interest income or expense from activity with UTC for the three and nine months ended September 30, 2020.

- changed (2020-10-29):
[0001783180-20-000067:note_history:60]
Additionally, certain transactions between Carrier and its subsidiaries, and UTC and its affiliates, were cash-settled prior to the Separation and are reflected in Accounts receivable, net and Accounts payable in the Unaudited Condensed Consolidated Balance Sheet as of December 31, 2019 in the amounts of $6 million and $4 million, respectively. As of September 30, 2020, there were no outstanding Accounts receivable, net or Accounts payable with UTC.
  (was, 2020-07-31, similarity 0.7783):
[0001783180-20-000052:note_history:60]
Additionally, certain transactions between Carrier and its subsidiaries, and UTC and its affiliates, were cash-settled and were reflected in Accounts receivable, net and Accounts payable in the Unaudited Condensed Consolidated Balance Sheet as of December 31, 2019 in the amounts of $6 million and $4 million, respectively. As of June 30, 2020, there were no accounts receivable or accounts payable balances with UTC.

- removed (2020-10-29):
[0001783180-20-000052:note_history:61]
During the six months ended June 30, 2020 and 2019, Product sales in the Unaudited Condensed Consolidated Statement of Operations included sales to equity method investees of $778 million and $940 million, respectively. During the six months ended June 30, 2020 and 2019, Cost of products sold in the Unaudited Condensed Consolidated Statement of Operations included purchases from equity method investees of $143 million and $178 million, respectively. Carrier had receivables from equity method investees of $219 million and $137 million at June 30, 2020 and December 31, 2019, respectively. Carrier also had payables to equity method investees of $38 million and $55 million at June 30, 2020 and December 31, 2019, respectively. The receivables and payables are included in Accounts receivable, net and Accounts payable on the Unaudited Condensed Consolidated Balance Sheet.

- removed (2020-10-29):
[0001783180-20-000052:note_history:62]
The allocated centralized costs for the three months ended June 30, 2020 and 2019 were $0 million and $62 million, respectively, and for the six months ended June 30, 2020 and 2019 were $43 million and $116 million, respectively, and are primarily included in Selling, general and administrative in the Unaudited Condensed Consolidated Statement of Operations.

- removed (2020-10-29):
[0001783180-20-000052:note_history:63]
Separation Costs. In connection with the Separation, we have incurred Separation-related costs of approximately $23 million and $68 million for the three and six months ended June 30, 2020, respectively, primarily recorded in Selling, general and administrative in the Unaudited Condensed Consolidated Statement of Operations, which primarily consist of employee-related costs, costs to establish certain stand-alone functions and information technology systems, professional

- removed (2020-10-29):
[0001783180-20-000052:note_history:64]
service fees and other transaction-related costs resulting from Carrier’s transition to becoming an independent publicly traded company. Carrier did not incur costs in connection with the Separation for the three and six months ended June 30, 2019.

- removed (2020-10-29):
[0001783180-20-000052:note_history:65]
During the three and six months ended June 30, 2020, net assets of $859 million and $780 million, respectively, were contributed to the Company by UTC which primarily consisted of cash, deferred tax assets and liabilities, and fixed assets. Included in the net assets received were cash contributions from UTC of $590 million.  These contributions of net assets are recorded as Net transfers from UTC on the Unaudited Condensed Consolidated Statement of Changes in Equity through UTC Net investment.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: no_current_note, score: 0.0

- removed (2020-10-29):
[0001783180-20-000052:note_history:66]
|  | For the Three Months Ended June 30, |  |  |  | For the Six Months Ended June 30, |  |  |  |  |  |
| (dollars in millions) | 2020 |  | 2019 |  | 2020 |  | 2019 |  |  |  |
| United States Operations | $ | 2,192 |  |  | $ | 2,713 |  |  | $ | 4,203 |  |  | $ | 4,932 |  |  |  |  |
| International Operations |  |  |  |  |  |  |  |  |  |  |
| Europe | 969 |  |  | 1,301 |  |  | 2,148 |  |  | 2,593 |  |  |  |  |
| Asia Pacific | 645 |  |  | 738 |  |  | 1,164 |  |  | 1,350 |  |  |  |  |
| Other | 166 |  |  | 210 |  |  | 345 |  |  | 410 |  |  |  |  |
| Consolidated | $ | 3,972 |  |  | $ | 4,962 |  |  | $ | 7,860 |  |  | $ | 9,285 |  |  |  |  |

- removed (2020-10-29):
[0001783180-20-000052:note_history:67]
Segment sales disaggregated by product and service are as follows:

- removed (2020-10-29):
[0001783180-20-000052:note_history:68]
|  | For the Three Months Ended June 30, |  |  |  | For the Six Months Ended June 30, |  |  |
| (dollars in millions) | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Sales Type |  |  |  |  |  |  |  |
| Product | $ | 1,976 |  |  | $ | 2,370 |  |  | $ | 3,633 |  |  | $ | 4,231 |  |
| Service | 315 |  |  | 365 |  |  | 617 |  |  | 672 |  |
| HVAC sales | 2,291 |  |  | 2,735 |  |  | 4,250 |  |  | 4,903 |  |
| Product | 609 |  |  | 861 |  |  | 1,322 |  |  | 1,728 |  |
| Service | 91 |  |  | 94 |  |  | 186 |  |  | 189 |  |
| Refrigeration sales | 700 |  |  | 955 |  |  | 1,508 |  |  | 1,917 |  |
| Product | 762 |  |  | 1,021 |  |  | 1,622 |  |  | 1,956 |  |
| Service | 295 |  |  | 365 |  |  | 641 |  |  | 720 |  |
| Fire & Security sales | 1,057 |  |  | 1,386 |  |  | 2,263 |  |  | 2,676 |  |
| Total segment sales | 4,048 |  |  | 5,076 |  |  | 8,021 |  |  | 9,496 |  |
| Eliminations and other | (76) |  |  | (114) |  |  | (161) |  |  | (211) |  |
| Consolidated | $ | 3,972 |  |  | $ | 4,962 |  |  | $ | 7,860 |  |  | $ | 9,285 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-10-29):
[0001783180-20-000067:note_history:69]
REVENUE RECOGNITION 
Contract Assets and Liabilities. Total contract assets and liabilities are as follows:
  (was, 2020-07-31, similarity 0.8689):
[0001783180-20-000052:note_history:69]
REVENUE RECOGNITION 
Contract Assets and Liabilities. Total contract assets and liabilities as of June 30, 2020 and December 31, 2019 are as follows:

- changed (2020-10-29):
[0001783180-20-000067:note_history:70]
| (dollars in millions) | September 30, 2020 |  | December 31, 2019 |
| Contract assets, current | $ | 753 |  |  | $ | 622 |  |
| Contract assets, non-current (included within Other assets) | 75 |  |  | 57 |  |
| Total contract assets | 828 |  |  | 679 |  |
| Contract liabilities, current | (495) |  |  | (443) |  |
| Contract liabilities, non-current (included within Other long-term liabilities) | (166) |  |  | (168) |  |
| Total contract liabilities | (661) |  |  | (611) |  |
| Net contract assets | $ | 167 |  |  | $ | 68 |  |
  (was, 2020-07-31, similarity 0.9609):
[0001783180-20-000052:note_history:70]
| (dollars in millions) | June 30, 2020 |  | December 31, 2019 |
| Contract assets, current | $ | 761 |  |  | $ | 622 |  |
| Contract assets, non-current (included within Other assets) | 48 |  |  | 57 |  |
| Total contract assets | 809 |  |  | 679 |  |
| Contract liabilities, current | (477) |  |  | (443) |  |
| Contract liabilities, non-current (included within Other long-term liabilities) | (166) |  |  | (168) |  |
| Total contract liabilities | (643) |  |  | (611) |  |
| Net contract assets | $ | 166 |  |  | $ | 68 |  |

- added (2020-10-29):
[0001783180-20-000067:note_history:71]
Contract assets increased $149 million for the nine months ended September 30, 2020, primarily due to the timing of billings on customer contracts and contract completions. Contract liabilities increased $50 million for the nine months ended September 30, 2020, primarily due to customer billings in excess of revenue earned.

- added (2020-10-29):
[0001783180-20-000067:note_history:72]
For the three months ended September 30, 2020 and 2019, we recognized revenue of $55 million and $53 million, respectively, and for the nine months ended September 30, 2020 and 2019, we recognized revenue of $288 million and $301 million, respectively, that was related to contract liabilities as of January 1, 2020 and 2019, respectively.

- changed (2020-10-29):
[0001783180-20-000067:note_history:73]
Remaining Performance Obligations ("RPO").  As of September 30, 2020, our total RPO was approximately $5.6 billion compared with $4.7 billion as of December 31, 2019. Of the total RPO as of September 30, 2020, we expect that approximately 73% will be recognized as sales over the next 12 months.
  (was, 2020-07-31, similarity 0.6874):
[0001783180-20-000052:note_history:73]
Remaining Performance Obligations ("RPO").  As of June 30, 2020, our total RPO was approximately $5.4 billion compared with $4.7 billion as of December 31, 2019. Of the total RPO as of June 30, 2020, we expect approximately 72% will be recognized as sales over the following 12 months.
(See Note 19 – Segment Financial Data which provides incremental disclosures required by Accounting Standard Codification ("ASC") Topic 606 – Revenue from Contracts with Customers

- added (2020-10-29):
[0001783180-20-000067:note_history:74]
See Note 19 – Segment Financial Data which provides incremental disclosures required by Accounting Standard Codification ("ASC") Topic 606 – Revenue from Contracts with Customers.

- removed (2020-10-29):
[0001783180-20-000052:note_history:75]
Contract assets increased $130 million for the six months ended June 30, 2020, primarily due to the timing of billings on customer contracts and contract completions. Contract liabilities increased $32 million for the six months ended June 30, 2020, primarily due to customer billings in excess of revenue earned.

- removed (2020-10-29):
[0001783180-20-000052:note_history:76]
For the three months ended June 30, 2020 and 2019, we recognized revenue of $89 million and $71 million, respectively, and for the six months ended June 30, 2020 and 2019, we recognized revenue of $233 million and $249 million, respectively, that was related to contract liabilities as of January 1, 2020 and 2019, respectively.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2020-10-29):
[0001783180-20-000067:note_history:77]
SUBSEQUENT EVENTS On October 15, 2020, the Board of Directors declared a dividend of $0.08 per share of common stock payable November 23, 2020 to shareowners of record at the close of business on October 30, 2020.

- removed (2020-10-29):
[0001783180-20-000052:note_history:78]
SUBSEQUENT EVENTS .
