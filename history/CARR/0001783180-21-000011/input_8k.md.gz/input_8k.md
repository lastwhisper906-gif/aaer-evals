# CARR 8-K — 0001783180-21-000009 filed 2021-02-09

## item codes, every 8-K on or before 2021-02-09

- 2021-02-09 0001783180-21-000009 — 2.02, 9.01
- 2021-02-05 0001140361-21-003513 — 8.01, 9.01
- 2020-12-23 0001140361-20-029419 — 7.01, 9.01
- 2020-12-22 0001140361-20-029097 — 8.01
- 2020-12-14 0001140361-20-028246 — 5.03, 9.01
- 2020-12-07 0001140361-20-027515 — 1.01, 7.01, 9.01
- 2020-10-29 0001783180-20-000063 — 2.02, 9.01
- 2020-10-19 0001140361-20-023241 — 5.02, 7.01, 9.01
- 2020-09-23 0001140361-20-021220 — 8.01, 9.01
- 2020-09-22 0001140361-20-021124 — 8.01, 9.01
- 2020-07-30 0001783180-20-000045 — 2.02, 9.01
- 2020-06-19 0001140361-20-014325 — 1.01, 2.03, 9.01
- 2020-06-16 0001140361-20-013880 — 8.01, 9.01
- 2020-06-03 0001140361-20-012939 — 1.01, 9.01
- 2020-05-08 0001783180-20-000013 — 2.02, 9.01
- 2020-04-03 0001140361-20-007888 — 1.01, 5.02, 5.03, 5.05, 7.01, 9.01
- 2020-03-16 0001140361-20-005868 — 8.01, 9.01

## late-filing notifications on or before 2021-02-09

- none on or before 2021-02-09

## item 2.02 — earnings release, exhibit 99.1

[0001783180-21-000009:8k_2_02:1]
EX-99
2
a8-kerexhibit99xq42020.htm
EX-99

[0001783180-21-000009:8k_2_02:2]
Document

[0001783180-21-000009:8k_2_02:3]
Exhibit 99

[0001783180-21-000009:8k_2_02:4]
Carrier Reports 2020 Results and Announces 2021 Outlook

[0001783180-21-000009:8k_2_02:5]
Anticipates growth in sales, adjusted EPS, adjusted operating margin and free cash flow in 2021

[0001783180-21-000009:8k_2_02:6]
Board authorizes $350 million share repurchase program

[0001783180-21-000009:8k_2_02:7]
Full Year 2020 Highlights

[0001783180-21-000009:8k_2_02:8]
•Sales and adjusted operating profit exceeded outlook

[0001783180-21-000009:8k_2_02:9]
•GAAP EPS of $2.25 and adjusted EPS of $1.66

[0001783180-21-000009:8k_2_02:10]
•Reduced long-term debt by $1.0 billion and net debt by more than $2.8 billion since spin-off

[0001783180-21-000009:8k_2_02:11]
Fourth Quarter 2020 Highlights

[0001783180-21-000009:8k_2_02:12]
•Sales of $4.6 billion driven by strong demand in North America residential HVAC

[0001783180-21-000009:8k_2_02:13]
•GAAP EPS of $1.00 and adjusted EPS of $0.31

[0001783180-21-000009:8k_2_02:14]
•Results included $50 million in vendor contract termination, legal and related costs

[0001783180-21-000009:8k_2_02:15]
•Prepaid $1.75 billion term loan credit facility

[0001783180-21-000009:8k_2_02:16]
Outlook for 2021

[0001783180-21-000009:8k_2_02:17]
•Sales growth of 6% to 8%, organic sales up 4% to 6%, currency translation to add approximately 2%

[0001783180-21-000009:8k_2_02:18]
•Adjusted operating margin of approximately 13.5%, up 70bps

[0001783180-21-000009:8k_2_02:19]
•Adjusted EPS of $1.85 to $1.95, up 14% at midpoint

[0001783180-21-000009:8k_2_02:20]
•Free cash flow of approximately $1.6 billion

[0001783180-21-000009:8k_2_02:21]
PALM BEACH GARDENS, Fla., February 9, 2021 – Carrier Global Corporation (NYSE:CARR) today reported financial results for the fourth quarter and full year 2020, and announced its 2021 outlook.  Carrier is the leading global provider of healthy, safe and sustainable building and cold chain solutions.

[0001783180-21-000009:8k_2_02:22]
“I’m proud of the Carrier team’s performance in 2020.  We overachieved on our key operational and financial goals, supported our customers and exited the year with strong momentum. I want to thank our 56,000 employees for their tireless efforts in a challenging year.  Our strategy was reinforced by fourth quarter results, which surpassed our expectations because of continued strength in North American residential HVAC and continued traction on our growth and cost containment initiatives,” said Carrier President & CEO Dave Gitlin. “Looking to 2021, we will continue to execute on our strategy to drive growth and profitability and expect mid-single digit organic sales growth, margin expansion, double-digit adjusted EPS growth, and strong cash conversion.  Carrier is well-positioned as the world leader in healthy, safe and sustainable building and cold chain solutions.”

[0001783180-21-000009:8k_2_02:23]
1

[0001783180-21-000009:8k_2_02:24]
Share Repurchase Authorization

[0001783180-21-000009:8k_2_02:25]
On February 4, 2021 Carrier’s Board of Directors authorized the repurchase of up to $350 million of the company's outstanding common stock.  Share repurchases may take place from time to time, subject to market conditions and at the company’s discretion in the open market or through one or more other public or private transactions.

[0001783180-21-000009:8k_2_02:26]
Full-Year 2020 Results

[0001783180-21-000009:8k_2_02:27]
Carrier’s 2020 sales of $17.5 billion were down 6% compared to the prior year.  The sales decline was largely driven by the impact of the COVID-19 pandemic, but partly offset by strong demand in North America residential HVAC in the second half of 2020.  GAAP operating profit of $3.1 billion was up 24% and adjusted operating profit of $2.23 billion was down 19%.  GAAP operating profit benefited from the gain on the sale of the company’s shares in Beijer Ref AB (“Beijer”) in the second half of the year. Adjusted operating profit was impacted by investments in growth initiatives, lower sales and unfavorable productivity due to factory disruptions related to the COVID-19 pandemic.  These negative effects were partly offset by cost-containment measures and accelerated savings under Carrier 700.

[0001783180-21-000009:8k_2_02:28]
GAAP EPS of $2.25 benefited from the gain on the sale of the shares in Beijer in the second half of the year and adjusted EPS was $1.66.  Net income was $2.0 billion, and adjusted net income was $1.5 billion.  Net cash flows provided by operating activities were $1.69 billion and capital expenditures were $312 million, resulting in free cash flow of $1.38 billion.  Free cash flow included $272 million in tax payments related to the gain on the sale of the shares in Beijer.

[0001783180-21-000009:8k_2_02:29]
Fourth Quarter 2020 Results

[0001783180-21-000009:8k_2_02:30]
Carrier’s fourth quarter sales of $4.6 billion were up 2% compared to the prior year due to currency translation and organic sales were flat to the prior year.  The sales performance was largely driven by continued strong demand in North America residential HVAC, which was up 25% compared to the prior year, an improved economic climate, and other businesses continue to improve sequentially, but were still down compared to last year.  GAAP operating profit in the quarter of $1.25 billion was up 124% and adjusted operating profit of $453 million was down 24%.  These results were impacted by planned investment spending on growth initiatives in the quarter, incremental public company, vendor contract termination, legal and related costs.

[0001783180-21-000009:8k_2_02:31]
GAAP EPS of $1.00 included the sale of Carrier’s stake in Beijer and adjusted EPS was $0.31. Net income was $884 million, and adjusted net income was $280 million. Net cash flows provided by operating activities were $199 million and capital expenditures were $161 million, resulting in free cash flow of $38 million.  Free cash flow included $272 million in tax payments related to the gain on the sale of the shares in Beijer.

[0001783180-21-000009:8k_2_02:32]
Full-Year 2021 Outlook*

[0001783180-21-000009:8k_2_02:33]
Carrier is announcing the following outlook for 2021:

[0001783180-21-000009:8k_2_02:34]
•Sales growth of 6% to 8%

[0001783180-21-000009:8k_2_02:35]
◦organic sales up 4% to 6%

[0001783180-21-000009:8k_2_02:36]
◦currency translation to add approximately 2%

[0001783180-21-000009:8k_2_02:37]
•Adjusted operating margin of approximately 13.5%, up 70 bps

[0001783180-21-000009:8k_2_02:38]
•Adjusted EPS of $1.85 to $1.95, up 14% at midpoint

[0001783180-21-000009:8k_2_02:39]
•Free cash flow of approximately $1.6 billion

[0001783180-21-000009:8k_2_02:40]
*Note: When the company provides expectations for organic sales, adjusted operating profit, adjusted operating margin, adjusted EPS and free cash flow on a forward-looking basis, a reconciliation of the differences between the non-GAAP expectations and the corresponding GAAP measures generally is not available without unreasonable effort. See “Use and Definitions of Non-GAAP Financial Measures” below for additional information.

[0001783180-21-000009:8k_2_02:41]
Conference Call

[0001783180-21-000009:8k_2_02:42]
Carrier will host a webcast of its earnings conference call today, Tuesday, February 9, 2021, at 9:00 a.m. ET. To access the webcast, visit the Events & Presentations section of the Carrier Investor Relations site at ir.carrier.com/news-and-events/events-and-presentations or to listen to the earnings call by phone, dial (877) 742-9091.

[0001783180-21-000009:8k_2_02:43]
About Carrier

[0001783180-21-000009:8k_2_02:44]
As the leading global provider of healthy, safe and sustainable building and cold chain solutions, Carrier Global Corporation is committed to making the world safer, more sustainable and comfortable for generations to come. From the beginning, we've led in inventing new technologies and entirely new industries. Today, we continue to lead because we have a world-class, diverse workforce that puts the customer at the center of everything we do.  For more information, visit www.corporate.carrier.com or follow Carrier on social media at @Carrier.

[0001783180-21-000009:8k_2_02:45]
Use and Definitions of Non-GAAP Financial Measures

[0001783180-21-000009:8k_2_02:46]
Carrier Global Corporation (“Carrier”) reports its financial results in accordance with accounting principles generally accepted in the United States ("GAAP").

[0001783180-21-000009:8k_2_02:47]
We supplement the reporting of our financial information determined under GAAP with certain non-GAAP financial information.  The non-GAAP information presented provides investors with additional useful information, but should not be considered in isolation or as substitutes for the related GAAP measures.  Moreover, other companies may define non-GAAP measures differently, which limits the usefulness of these measures for comparisons with such other companies. We encourage investors to review our financial statements and publicly filed reports in their entirety and not to rely on any single financial measure. A reconciliation of the non-GAAP measures to the corresponding amounts prepared in accordance with GAAP appears in the tables in this Appendix. The tables provide additional information as to the items and amounts that have been excluded from the adjusted measures.

[0001783180-21-000009:8k_2_02:48]
Organic sales, adjusted operating profit, adjusted operating margin, earnings before interest, taxes and depreciation and amortization (“EBITDA”), adjusted EBITDA, adjusted net income, adjusted earnings per share (“EPS”), the adjusted effective tax rate, and net debt are non-GAAP financial measures.  Organic sales represents consolidated net sales (a GAAP measure), excluding the impact of foreign currency translation, acquisitions and divestitures completed in the preceding twelve months and other significant items of a non-recurring and/or nonoperational nature (hereinafter referred to as “other significant items”). Adjusted operating profit represents operating profit (a GAAP measure), excluding restructuring costs and other significant items.  Adjusted operating margin represents adjusted operating profit as a percentage of net sales (a GAAP measure).  EBITDA represents net income attributable to common shareholders (a GAAP measure), adjusted for interest expense, income tax expense, and depreciation and amortization. Adjusted EBITDA represents EBITDA, as calculated above, excluding non-service pension benefit, non-controlling interest in subsidiaries’ earnings from operations, restructuring costs and other significant items.  Adjusted net income represents net income attributable to common shareowners (a GAAP measure), excluding restructuring costs and other significant items.  Adjusted EPS represents diluted earnings per share (a GAAP measure), excluding restructuring costs and other significant items. The adjusted effective tax rate represents the effective tax rate (a GAAP measure), excluding restructuring costs and other significant items.  Net debt represents long-term debt (a GAAP measure) less cash and cash equivalents.  For the business segments, when applicable, adjustments of operating profit and operating margins represent operating profit, excluding restructuring and other significant items.

[0001783180-21-000009:8k_2_02:49]
Free cash flow is a non-GAAP financial measure that represents net cash flows provided by operating activities (a GAAP measure) less capital expenditures.  Management believes free cash flow is a useful measure of liquidity and an additional

[0001783180-21-000009:8k_2_02:50]
3

[0001783180-21-000009:8k_2_02:51]
basis for assessing Carrier’s ability to fund its activities, including the financing of acquisitions, debt service, repurchases of Carrier's common stock and distribution of earnings to shareowners.

[0001783180-21-000009:8k_2_02:52]
When we provide our expectations for organic sales, adjusted operating profit, adjusted operating margin, adjusted EPS, and free cash flow  on a forward-looking basis, a reconciliation of the differences between the non-GAAP expectations and the corresponding GAAP measures (expected net sales, operating profit, operating margin, diluted EPS and net cash flows provided by operating activities) generally is not available without unreasonable effort due to potentially high variability, complexity and low visibility as to the items that would be excluded from the GAAP measure in the relevant future period, such as unusual gains and losses, the ultimate outcome of pending litigation, fluctuations in foreign currency exchange rates, the impact and timing of potential acquisitions and divestitures, future restructuring costs, and other structural changes or their probable significance.  The variability of the excluded items may have a significant, and potentially unpredictable, impact on our future GAAP results.

[0001783180-21-000009:8k_2_02:53]
Cautionary Statement

[0001783180-21-000009:8k_2_02:54]
4

[0001783180-21-000009:8k_2_02:55]
as a result of financing transactions undertaken in connection with the separation, as well as our ability to reduce indebtedness and the timing thereof; (20) the risk that dis-synergy costs, costs of restructuring transactions and other costs incurred in connection with the separation will exceed Carrier’s estimates; and (21) the impact of the Separation on Carrier’s business and Carrier’s resources, systems, procedures and controls, diversion of management’s attention and the impact on relationships with customers, suppliers, employees and other business counterparties.

[0001783180-21-000009:8k_2_02:56]
The above list of factors is not exhaustive or necessarily in order of importance. For additional information on identifying factors that may cause actual results to vary materially from those stated in forward-looking statements, see Carrier’s reports on Forms 10-K, 10-Q and 8-K filed with or furnished to the SEC from time to time. Any forward-looking statement speaks only as of the date on which it is made, and Carrier assumes no obligation to update or revise such statement, whether as a result of new information, future events or otherwise, except as required by applicable law.

[0001783180-21-000009:8k_2_02:57]
Contact:                                                           Media Inquiries

[0001783180-21-000009:8k_2_02:58]
Danielle Canzanella

[0001783180-21-000009:8k_2_02:59]
561-365-1101

[0001783180-21-000009:8k_2_02:60]
Danielle.Canzanella@Carrier.com

[0001783180-21-000009:8k_2_02:61]
Investor Relations

[0001783180-21-000009:8k_2_02:62]
Sam Pearlstein

[0001783180-21-000009:8k_2_02:63]
561-365-2251

[0001783180-21-000009:8k_2_02:64]
Sam.Pearlstein@Carrier.com

[0001783180-21-000009:8k_2_02:65]
5

[0001783180-21-000009:8k_2_02:66]
Carrier Global Corporation

[0001783180-21-000009:8k_2_02:67]
Condensed Consolidated Statement of Operations

[0001783180-21-000009:8k_2_02:68]
|  | (Unaudited) |
|  | For the Three Months Ended December 31, |  | For the Year Ended December 31, |
| (dollars in millions, except per share amounts; shares in millions) | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Net sales |  |  |  |  |  |  |  |
| Product sales | $ | 3,732 |  |  | $ | 3,657 |  |  | $ | 14,347 |  |  | $ | 15,360 |  |
| Service sales | 862 |  |  | 844 |  |  | 3,109 |  |  | 3,248 |  |
|  | 4,594 |  |  | 4,501 |  |  | 17,456 |  |  | 18,608 |  |
| Costs and expenses |  |  |  |  |  |  |  |
| Cost of products sold | 2,721 |  |  | 2,635 |  |  | 10,185 |  |  | 10,890 |  |
| Cost of services sold | 588 |  |  | 593 |  |  | 2,162 |  |  | 2,299 |  |
| Research and development | 127 |  |  | 99 |  |  | 419 |  |  | 401 |  |
| Selling, general and administrative | 810 |  |  | 695 |  |  | 2,820 |  |  | 2,761 |  |
|  | 4,246 |  |  | 4,022 |  |  | 15,586 |  |  | 16,351 |  |
| Equity method investment net earnings | 59 |  |  | 38 |  |  | 207 |  |  | 236 |  |
| Other income (expense), net | 838 |  |  | 40 |  |  | 1,006 |  |  | (2) |  |
| Operating profit | 1,245 |  |  | 557 |  |  | 3,083 |  |  | 2,491 |  |
| Non-service pension benefit | 13 |  |  | 30 |  |  | 60 |  |  | 154 |  |
| Interest (expense) income, net | (82) |  |  | 4 |  |  | (288) |  |  | 27 |  |
| Income from operations before income taxes | 1,176 |  |  | 591 |  |  | 2,855 |  |  | 2,672 |  |
| Income tax expense | 289 |  |  | 137 |  |  | 849 |  |  | 517 |  |
| Net income from operations | 887 |  |  | 454 |  |  | 2,006 |  |  | 2,155 |  |
| Less: Non-controlling interest in subsidiaries' earnings from operations | 3 |  |  | 14 |  |  | 24 |  |  | 39 |  |
| Income from operations attributable to common shareowners | $ | 884 |  |  | $ | 440 |  |  | $ | 1,982 |  |  | $ | 2,116 |  |
| Earnings per share (1), (2) |  |  |  |  |  |  |  |
| Basic | $ | 1.02 |  |  | $ | 0.50 |  |  | $ | 2.29 |  |  | $ | 2.44 |  |
| Diluted | $ | 1.00 |  |  | $ | 0.50 |  |  | $ | 2.25 |  |  | $ | 2.44 |  |
| Weighted-average number of shares outstanding (2) |  |  |  |  |  |  |  |
| Basic | 867.4 |  | 866.2 |  | 866.5 |  | 866.2 |
| Diluted | 888.4 |  | 866.2 |  | 880.2 |  | 866.2 |

[0001783180-21-000009:8k_2_02:69]
(1) On April 3, 2020, United Technologies Corporation, since renamed Raytheon Technologies Corporation ("UTC") completed the spin-off of Carrier, one of UTC's reportable segments, into a separate publicly traded company (the "Separation"). The Separation was completed through a pro-rata distribution (the "Distribution") of all of the outstanding common stock of Carrier to UTC shareowners who held shares of UTC common stock as of the close of business on March 19, 2020, the record date for the Distribution. Earnings per share for periods presented prior to the Separation were calculated using the number of shares that were distributed to UTC shareowners immediately following the Separation. For periods prior to the Separation it was assumed that there were no dilutive equity instruments as there were no equity awards in Carrier common stock outstanding prior to the Separation.

[0001783180-21-000009:8k_2_02:70]
(2) Basic and diluted earnings per share for the three and twelve months ended December 31, 2020 are calculated using the weighted-average number of common shares outstanding for the period beginning after the Distribution date. Diluted earnings per share is computed by giving effect to all potentially dilutive stock awards that are outstanding.

[0001783180-21-000009:8k_2_02:71]
6

[0001783180-21-000009:8k_2_02:72]
Carrier Global Corporation

[0001783180-21-000009:8k_2_02:73]
Segment Net Sales and Operating Profit

[0001783180-21-000009:8k_2_02:74]
|  | For the Three Months Ended December 31, |  | For the Year Ended December 31, |
| (Unaudited) | 2020 |  | 2019 |  | 2020 |  | 2019 |
| (dollars in millions) | Reported |  | Adjusted |  | Reported |  | Adjusted |  | Reported |  | Adjusted |  | Reported |  | Adjusted |
| Net sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| HVAC | $ | 2,336 |  | $ | 2,336 |  | $ | 2,207 |  | $ | 2,207 |  | $ | 9,478 |  | $ | 9,478 |  | $ | 9,712 |  | $ | 9,712 |
| Refrigeration | 949 |  | 949 |  | 953 |  | 953 |  | 3,333 |  | 3,333 |  | 3,792 |  | 3,792 |
| Fire & Security | 1,398 |  | 1,398 |  | 1,422 |  | 1,422 |  | 4,985 |  | 4,985 |  | 5,500 |  | 5,500 |
| Segment sales | 4,683 |  | 4,683 |  | 4,582 |  | 4,582 |  | 17,796 |  | 17,796 |  | 19,004 |  | 19,004 |
| Eliminations and other | (89) |  | (89) |  | (81) |  | (81) |  | (340) |  | (340) |  | (396) |  | (396) |
| Net sales | $ | 4,594 |  | $ | 4,594 |  | $ | 4,501 |  | $ | 4,501 |  | $ | 17,456 |  | $ | 17,456 |  | $ | 18,608 |  | $ | 18,608 |
| Operating profit |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| HVAC | $ | 1,098 |  | $ | 231 |  | $ | 321 |  | $ | 307 |  | $ | 2,462 |  | $ | 1,430 |  | $ | 1,563 |  | $ | 1,670 |
| Refrigeration | 94 |  | 110 |  | 159 |  | 137 |  | 357 |  | 375 |  | 532 |  | 524 |
| Fire & Security | 158 |  | 186 |  | 187 |  | 212 |  | 584 |  | 628 |  | 708 |  | 768 |
| Segment operating profit | 1,350 |  | 527 |  | 667 |  | 656 |  | 3,403 |  | 2,433 |  | 2,803 |  | 2,962 |
| Eliminations and other | (62) |  | (33) |  | (61) |  | (13) |  | (184) |  | (73) |  | (156) |  | (60) |
| General corporate expenses | (43) |  | (41) |  | (49) |  | (49) |  | (136) |  | (128) |  | (156) |  | (156) |
| Operating profit | $ | 1,245 |  | $ | 453 |  | $ | 557 |  | $ | 594 |  | $ | 3,083 |  | $ | 2,232 |  | $ | 2,491 |  | $ | 2,746 |
| Segment operating margin |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| HVAC | 47.0 | % |  | 9.9 | % |  | 14.5 | % |  | 13.9 | % |  | 26.0 | % |  | 15.1 | % |  | 16.1 | % |  | 17.2 | % |
| Refrigeration | 9.9 | % |  | 11.6 | % |  | 16.7 | % |  | 14.4 | % |  | 10.7 | % |  | 11.3 | % |  | 14.0 | % |  | 13.8 | % |
| Fire & Security | 11.3 | % |  | 13.3 | % |  | 13.2 | % |  | 14.9 | % |  | 11.7 | % |  | 12.6 | % |  | 12.9 | % |  | 14.0 | % |

[0001783180-21-000009:8k_2_02:75]
Carrier Global Corporation

[0001783180-21-000009:8k_2_02:76]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP)

[0001783180-21-000009:8k_2_02:77]
Operating Profit & Operating Profit Margin

[0001783180-21-000009:8k_2_02:78]
|  |  | For the Three Months Ended |  | For the Year Ended |
| (Unaudited) | December 31, |  | December 31, |
| (dollars in millions - Income (Expense)) | 2020 |  | 2019 |  | 2020 |  | 2019 |
| HVAC |  |  |  |  |
|  | Net sales | $ | 2,336 |  |  | $ | 2,207 |  |  | $ | 9,478 |  |  | $ | 9,712 |  |
|  | Operating profit | $ | 1,098 |  |  | $ | 321 |  |  | $ | 2,462 |  |  | $ | 1,563 |  |
|  | Restructuring | (4) |  |  | (9) |  |  | (7) |  |  | (56) |  |
|  | Impairment charge on equity method investment | — |  |  | — |  |  | (71) |  |  | (108) |  |
|  | Gain on sale of investment | 871 |  |  | 23 |  |  | 1,123 |  |  | 57 |  |
|  | Charge resulting from litigation matter | — |  |  | — |  |  | (11) |  |  | — |  |
|  | Separation costs | — |  |  | — |  |  | (2) |  |  | — |  |
|  | Adjusted operating profit | $ | 231 |  |  | $ | 307 |  |  | $ | 1,430 |  |  | $ | 1,670 |  |
|  | Adjusted operating margin | 9.9 | % |  | 13.9 | % |  | 15.1 | % |  | 17.2 | % |
| Refrigeration |  |  |  |  |  |  |  |
|  | Net sales | $ | 949 |  |  | $ | 953 |  |  | $ | 3,333 |  |  | $ | 3,792 |  |
|  | Operating profit | $ | 94 |  |  | $ | 159 |  |  | $ | 357 |  |  | $ | 532 |  |
|  | Restructuring | (10) |  |  | — |  |  | (12) |  |  | (14) |  |
|  | Net gain on expropriated plant | — |  |  | 22 |  |  | — |  |  | 22 |  |
|  | Separation costs | (6) |  |  | — |  |  | (6) |  |  | — |  |
|  | Adjusted operating profit | $ | 110 |  |  | $ | 137 |  |  | $ | 375 |  |  | $ | 524 |  |
|  | Adjusted operating margin | 11.6 | % |  | 14.4 | % |  | 11.3 | % |  | 13.8 | % |
| Fire & Security |  |  |  |  |  |  |  |
|  | Net sales | $ | 1,398 |  |  | $ | 1,422 |  |  | $ | 4,985 |  |  | $ | 5,500 |  |
|  | Operating profit | $ | 158 |  |  | $ | 187 |  |  | $ | 584 |  |  | $ | 708 |  |
|  | Restructuring | (15) |  |  | (18) |  |  | (28) |  |  | (53) |  |
|  | Separation costs | (13) |  |  | — |  |  | (16) |  |  | — |  |
|  | Pension plan amendment | — |  |  | (7) |  |  | — |  |  | (7) |  |
|  | Adjusted operating profit | $ | 186 |  |  | $ | 212 |  |  | $ | 628 |  |  | $ | 768 |  |
|  | Adjusted operating margin | 13.3 | % |  | 14.9 | % |  | 12.6 | % |  | 14.0 | % |
| General Corporate Expenses and Eliminations and Other |  |  |  |  |  |  |  |
|  | Net sales | $ | (89) |  |  | $ | (81) |  |  | $ | (340) |  |  | $ | (396) |  |
|  | Operating profit | $ | (105) |  |  | $ | (110) |  |  | $ | (320) |  |  | $ | (312) |  |
|  | Restructuring | (1) |  |  | (2) |  |  | (2) |  |  | (3) |  |
|  | Consultant contract termination | — |  |  | — |  |  | — |  |  | (34) |  |
|  | Separation costs | (30) |  |  | (46) |  |  | (117) |  |  | (59) |  |
|  | Adjusted operating profit | $ | (74) |  |  | $ | (62) |  |  | $ | (201) |  |  | $ | (216) |  |
| Carrier |  |  |  |  |  |  |  |
|  | Net sales | $ | 4,594 |  |  | $ | 4,501 |  |  | $ | 17,456 |  |  | $ | 18,608 |  |
|  | Operating profit | $ | 1,245 |  |  | $ | 557 |  | $ | 3,083 |  |  | $ | 2,491 |
|  | Total restructuring costs | (30) |  |  | (29) |  |  | (49) |  |  | (126) |  |
|  | Total non-recurring and non-operational items | 822 |  |  | (8) |  |  | 900 |  |  | (129) |  |
|  | Adjusted operating profit | $ | 453 |  |  | $ | 594 |  |  | $ | 2,232 |  |  | $ | 2,746 |  |
|  | Adjusted operating margin | 9.9 | % |  | 13.2 | % |  | 12.8 | % |  | 14.8 | % |

[0001783180-21-000009:8k_2_02:79]
8

[0001783180-21-000009:8k_2_02:80]
Carrier Global Corporation

[0001783180-21-000009:8k_2_02:81]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP) Results

[0001783180-21-000009:8k_2_02:82]
Net Income, Earnings Per Share, and Effective Tax Rate

[0001783180-21-000009:8k_2_02:83]
| (Unaudited) | For the Three Months Ended December 31, |  | For the Year Ended December 31, |
| (dollars in millions - Income (Expense)) | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Net income attributable to common shareowners | $ | 884 |  |  | $ | 440 |  |  | $ | 1,982 |  |  | $ | 2,116 |  |
| Total restructuring costs | (30) |  |  | (29) |  |  | (49) |  |  | (126) |  |
| Total non-recurring and non-operational items included in operating profit | 822 |  |  | (8) |  |  | 900 |  |  | (129) |  |
| Non-recurring and non-operational items included in Interest expense, net: |  |  |  |  |  |  |  |
| Interest income associated with participation in amnesty settlement | — |  |  | — |  |  | — |  |  | 8 |  |
| Interest income associated with IRS settlement | — |  |  | — |  |  | — |  |  | 8 |  |
| Debt issuance costs relating to Carrier's separation from UTC | — |  |  | — |  |  | (5) |  |  | — |  |
| Non-recurring and non-operational items included in Interest expense, net | — |  |  | — |  |  | (5) |  |  | 16 |  |
| Tax effect of restructuring and non-recurring and non-operational items | (188) |  |  | 8 |  |  | (217) |  |  | 39 |  |
| Significant non-recurring and non-operational items included in Income tax expense: |  |  |  |  |  |  |  |
| Favorable income tax adjustments related to tax amnesty | — |  |  | — |  |  | — |  |  | 95 |  |
| Adjustments related to tax settlements | — |  |  | — |  |  | — |  |  | 54 |  |
| Adjustment related to a valuation allowance recorded against a United Kingdom tax loss and credit carryforward as a result of separation related activities | — |  |  | — |  |  | (51) |  |  | — |  |
| Adjustment resulting from Carrier's decision to no longer permanently reinvest certain pre-2018 unremitted non-U.S. earnings | — |  |  | — |  |  | (46) |  |  | — |  |
| Deferred tax adjustment resulting from the UTC Separation | — |  |  | — |  |  | — |  |  | 19 |  |
| Deferred tax adjustment resulting from United Kingdom legislative change | — |  |  | — |  |  | (12) |  |  | — |  |
| Significant non-recurring and non-operational items included in Income tax expense | — |  |  | — |  |  | (109) |  |  | 168 |  |
| Total significant non-recurring and non-operational items | 604 |  |  | (29) |  |  | 520 |  |  | (32) |  |
| Adjusted net income attributable to common shareowners | $ | 280 |  |  | $ | 469 |  |  | $ | 1,462 |  |  | $ | 2,148 |  |
| Diluted earnings per share | $ | 1.00 |  |  | $ | 0.50 |  |  | $ | 2.25 |  |  | $ | 2.44 |  |
| Impact on diluted earnings per share | 0.69 |  |  | (0.03) |  |  | 0.59 |  |  | (0.04) |  |
| Adjusted diluted earnings per share | $ | 0.31 |  |  | $ | 0.53 |  |  | $ | 1.66 |  |  | $ | 2.48 |  |
| Effective tax rate | 24.5 | % |  | 23.2 | % |  | 29.7 | % |  | 19.4 | % |
| Impact on effective tax rate | 1.8 | % |  | (0.1) | % |  | (3.7) | % |  | 5.5 | % |
| Adjusted effective tax rate | 26.3 | % |  | 23.1 | % |  | 26.0 | % |  | 24.9 | % |

[0001783180-21-000009:8k_2_02:84]
9

[0001783180-21-000009:8k_2_02:85]
Carrier Global Corporation

[0001783180-21-000009:8k_2_02:86]
Components of Changes in Net Sales

[0001783180-21-000009:8k_2_02:87]
Three Months Ended December 31, 2020 Compared with Three Months Ended December 31, 2019

[0001783180-21-000009:8k_2_02:88]
|  | Factors Contributing to Total % change in Net Sales |
| (Unaudited) | Organic |  | FX Translation |  | Acquisitions / Divestitures, net |  | Other |  | Total |
| HVAC | 4% |  | 2% |  | —% |  | —% |  | 6% |
| Refrigeration | (3)% |  | 3% |  | —% |  | —% |  | —% |
| Fire & Security | (5)% |  | 3% |  | —% |  | —% |  | (2)% |
| Consolidated | —% |  | 2% |  | —% |  | —% |  | 2% |

[0001783180-21-000009:8k_2_02:89]
Year Ended December 31, 2020 Compared with Year Ended December 31, 2019

[0001783180-21-000009:8k_2_02:90]
|  | Factors Contributing to Total % change in Net Sales |
| (Unaudited) | Organic |  | FX Translation |  | Acquisitions / Divestitures, net |  | Other |  | Total |
| HVAC | (2)% |  | —% |  | —% |  | —% |  | (2)% |
| Refrigeration | (12)% |  | —% |  | —% |  | —% |  | (12)% |
| Fire & Security | (9)% |  | —% |  | —% |  | —% |  | (9)% |
| Consolidated | (6)% |  | —% |  | —% |  | —% |  | (6)% |

[0001783180-21-000009:8k_2_02:91]
Net Debt

[0001783180-21-000009:8k_2_02:92]
|  |  | As of |
|  |  | December 31, 2020 |  | March 31, 2020 (1) |
| Long-term debt |  | $ | 10,036 |  |  | $ | 11,029 |  |
| Current portion of long-term debt |  | 191 |  |  | 218 |  |
| Less: Cash and cash equivalents |  | 3,115 |  |  | 768 |  |
| Net debt |  | $ | 7,112 |  |  | $ | 10,479 |  |

[0001783180-21-000009:8k_2_02:93]
_________________

[0001783180-21-000009:8k_2_02:94]
(1) On April 1 and April 2, 2020, Carrier received cash contributions totaling $590 million from UTC related to the Separation, resulting in net debt of approximately $9.9 billion as of April 3, 2020.

[0001783180-21-000009:8k_2_02:95]
Carrier Global Corporation

[0001783180-21-000009:8k_2_02:96]
Condensed Consolidated Balance Sheet

[0001783180-21-000009:8k_2_02:97]
|  | (Unaudited) |
| (dollars in millions) | December 31, 2020 |  | December 31, 2019 |
| Assets |  |  |  |
| Cash and cash equivalents | $ | 3,115 |  |  | $ | 952 |  |
| Accounts receivable, net | 2,781 |  |  | 2,726 |  |
| Contract assets, current | 656 |  |  | 622 |  |
| Inventories, net | 1,629 |  |  | 1,332 |  |
| Other assets, current | 343 |  |  | 327 |  |
| Total current assets | 8,524 |  |  | 5,959 |  |
| Future income tax benefits | 449 |  |  | 500 |  |
| Fixed assets, net | 1,810 |  |  | 1,663 |  |
| Operating lease right-of-use assets | 788 |  |  | 832 |  |
| Intangible assets, net | 1,037 |  |  | 1,083 |  |
| Goodwill | 10,139 |  |  | 9,884 |  |
| Pension and post-retirement assets | 554 |  |  | 490 |  |
| Equity method investments | 1,513 |  |  | 1,739 |  |
| Other assets | 279 |  |  | 256 |  |
| Total Assets | $ | 25,093 |  |  | $ | 22,406 |  |
| Liabilities and Equity |  |  |  |
| Accounts payable | $ | 1,936 |  |  | $ | 1,701 |  |
| Accrued liabilities | 2,471 |  |  | 2,088 |  |
| Contract liabilities, current | 512 |  |  | 443 |  |
| Current portion of long-term debt | 191 |  |  | 237 |  |
| Total current liabilities | 5,110 |  |  | 4,469 |  |
| Long-term debt | 10,036 |  |  | 82 |  |
| Future pension and post-retirement obligations | 524 |  |  | 456 |  |
| Future income tax obligations | 479 |  |  | 1,099 |  |
| Operating lease liabilities | 642 |  |  | 682 |  |
| Other long-term liabilities | 1,724 |  |  | 1,183 |  |
| Total Liabilities | 18,515 |  |  | 7,971 |  |
| Equity |  |  |  |
| UTC Net investment | — |  |  | 15,355 |  |
| Common stock, par value $0.01; 4,000,000,000 shares authorized; 867,829,119 shares issued and outstanding as of December 31, 2020 | 9 |  |  | — |  |
| Additional paid-in capital | 5,345 |  |  | — |  |
| Retained earnings | 1,643 |  |  | — |  |
| Accumulated other comprehensive loss | (745) |  |  | (1,253) |  |
| Non-controlling interest | 326 |  |  | 333 |  |
| Total Equity | 6,578 |  |  | 14,435 |  |
| Total Liabilities and Equity | $ | 25,093 |  |  | $ | 22,406 |  |

[0001783180-21-000009:8k_2_02:98]
11

[0001783180-21-000009:8k_2_02:99]
Carrier Global Corporation

[0001783180-21-000009:8k_2_02:100]
Condensed Consolidated Statement of Cash Flows

[0001783180-21-000009:8k_2_02:101]
|  |  |  |  | (Unaudited) |
|  |  |  | For the Year Ended December 31, |
| (dollars in millions) |  |  |  |  | 2020 |  | 2019 |
| Operating Activities |  |  |  |  |  |  |  |
| Net income from operations |  |  |  |  | $ | 2,006 |  |  | $ | 2,155 |  |
| Adjustments to reconcile net income from operations to net cash flows provided by operating activities, net of acquisitions and dispositions |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  |  |  | 336 |  |  | 335 |  |
| Deferred income tax provision |  |  |  |  | 97 |  |  | (122) |  |
| Equity compensation cost |  |  |  |  | 77 |  |  | 52 |  |
| Equity method investment net earnings |  |  |  |  | (207) |  |  | (236) |  |
| Distributions from equity method investments |  |  |  |  | 169 |  |  | 158 |  |
| Impairment charge on minority-owned joint venture investments |  |  |  |  | 72 |  |  | 108 |  |
| Gains on sale of investments and businesses |  |  |  |  | (1,123) |  |  | — |  |
| Changes in operating assets and liabilities |  |  |  |  |  |  |  |
| Accounts receivable, net |  |  |  |  | 49 |  |  | (129) |  |
| Contract assets, current |  |  |  |  | (9) |  |  | 23 |  |
| Inventories, net |  |  |  |  | (240) |  |  | (2) |  |
| Other assets, current |  |  |  |  | 3 |  |  | 62 |  |
| Accounts payable and accrued liabilities |  |  |  |  | 237 |  |  | (296) |  |
| Contract liabilities, current |  |  |  |  | 46 |  |  | (18) |  |
| Defined benefit plan contributions |  |  |  |  | (41) |  |  | (36) |  |
| Other operating activities, net |  |  |  |  | 220 |  |  | 9 |  |
| Net cash flows provided by operating activities |  |  |  |  | 1,692 |  |  | 2,063 |  |
| Investing Activities |  |  |  |  |  |  |  |
| Capital expenditures |  |  |  |  | (312) |  |  | (243) |  |
| Proceeds on sale of investments and businesses |  |  |  |  | 1,377 |  |  | 6 |  |
| Receipt from settlement of derivative contracts |  |  |  |  | 40 |  |  | — |  |
| Other investing activities, net |  |  |  |  | 1 |  |  | (22) |  |
| Net cash flows provided by (used in) investing activities |  |  |  |  | 1,106 |  |  | (259) |  |
| Financing Activities |  |  |  |  |  |  |  |
| (Decrease) increase in short-term borrowings, net |  |  |  |  | (23) |  |  | 25 |  |
| Issuance of long-term debt |  |  |  |  | 11,784 |  |  | 107 |  |
| Repayment of long-term debt |  |  |  |  | (1,911) |  |  | (138) |  |
| Dividends paid on common stock |  |  |  |  | (138) |  |  | — |  |
| Dividends paid to non-controlling interest |  |  |  |  | (48) |  |  | (28) |  |
| Net transfers to UTC |  |  |  |  | (10,359) |  |  | (1,954) |  |
| Other financing activities, net |  |  |  |  | 14 |  |  | 6 |  |
| Net cash flows used in financing activities |  |  |  |  | (681) |  |  | (1,982) |  |
| Effect of foreign exchange rate changes on cash and cash equivalents |  |  |  |  | 45 |  |  | 1 |  |
| Net increase (decrease) in cash and cash equivalents and restricted cash |  |  |  |  | 2,162 |  |  | (177) |  |
| Cash, cash equivalents and restricted cash, beginning of period |  |  |  |  | 957 |  |  | 1,134 |  |
| Cash, cash equivalents and restricted cash, end of period |  |  |  |  | 3,119 |  |  | 957 |  |
| Less: restricted cash |  |  |  |  | 4 |  |  | 5 |  |
| Cash and cash equivalents, end of period |  |  |  |  | $ | 3,115 |  |  | $ | 952 |  |

[0001783180-21-000009:8k_2_02:102]
12

[0001783180-21-000009:8k_2_02:103]
Carrier Global Corporation

[0001783180-21-000009:8k_2_02:104]
Free Cash Flow Reconciliation

[0001783180-21-000009:8k_2_02:105]
|  | (Unaudited) |
|  | For the Three Months Ended March 31, |
| (dollars in millions) | 2020 |  | 2019 |
| Net income attributable to common shareowners | $ | 96 |  |  |  |  | $ | 400 |  |  |  |
| Net cash flows provided by operating activities | $ | 47 |  |  |  |  | $ | (183) |  |  |  |
| Less: Capital expenditures | 48 |  |  |  |  | 41 |  |  |  |
| Free cash flow | $ | (1) |  |  |  |  | $ | (224) |  |  |  |
| Free cash flow as a percentage of net income attributable to common shareowners |  |  | (1)% |  |  |  | (56)% |
|  | (Unaudited) |
|  | For the Three Months Ended June 30, |
| (dollars in millions) | 2020 |  | 2019 |
| Net income attributable to common shareowners | $ | 261 |  |  |  |  | $ | 784 |  |  |  |
| Net cash flows provided by operating activities | $ | 509 |  |  |  |  | $ | 554 |  |  |  |
| Less: Capital expenditures | 46 |  |  |  |  | 48 |  |  |  |
| Free cash flow | $ | 463 |  |  |  |  | $ | 506 |  |  |  |
| Free cash flow as a percentage of net income attributable to common shareowners |  |  | 177% |  |  |  | 65% |
|  | (Unaudited) |
|  | For the Three Months Ended September 30, |
| (dollars in millions) | 2020 |  | 2019 |
| Net income attributable to common shareowners | $ | 741 |  |  |  |  | $ | 492 |  |  |  |
| Net cash flows provided by operating activities | $ | 937 |  |  |  |  | $ | 618 |  |  |  |
| Less: Capital expenditures | 57 |  |  |  |  | 50 |  |  |  |
| Free cash flow | $ | 880 |  |  |  |  | $ | 568 |  |  |  |
| Free cash flow as a percentage of net income attributable to common shareowners |  |  | 119% |  |  |  | 115% |
|  | (Unaudited) |
|  | For the Three Months Ended December 31, |
| (dollars in millions) | 2020 |  | 2019 |
| Net income attributable to common shareowners | $ | 884 |  |  |  |  | $ | 440 |  |  |  |
| Net cash flows provided by operating activities | $ | 199 |  |  |  |  | $ | 1,074 |  |  |  |
| Less: Capital expenditures | 161 |  |  |  |  | 104 |  |  |  |
| Free cash flow | $ | 38 |  |  |  |  | $ | 970 |  |  |  |
| Free cash flow as a percentage of net income attributable to common shareowners |  |  | 4% |  |  |  | 220% |
|  | (Unaudited) |
|  | For the Year Ended December 31, |
| (dollars in millions) | 2020 |  | 2019 |
| Net income attributable to common shareowners | $ | 1,982 |  |  |  |  | $ | 2,116 |  |  |  |
| Net cash flows provided by operating activities | $ | 1,692 |  |  |  |  | $ | 2,063 |  |  |  |
| Less: Capital expenditures | 312 |  |  |  |  | 243 |  |  |  |
| Free cash flow | $ | 1,380 |  |  |  |  | $ | 1,820 |  |  |  |
| Free cash flow as a percentage of net income attributable to common shareowners |  |  | 70% |  |  |  | 86% |

[0001783180-21-000009:8k_2_02:106]
13
