# CARR MD&A — 0001783180-21-000011


## mdna

[0001783180-21-000011:mdna:1]
ITEM 7. MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0001783180-21-000011:mdna:2]
BUSINESS OVERVIEW

[0001783180-21-000011:mdna:3]
Separation from United Technologies Corporation

[0001783180-21-000011:mdna:4]
On April 3, 2020, UTC completed the Separation through the Distribution of all of the outstanding common stock of the Company to UTC shareowners who held shares of UTC common stock as of the close of business on March 19, 2020, the record date for the Distribution. UTC distributed 866,158,910 shares of Carrier common stock in the Distribution at the Effective Time. As a result of the Distribution, UTC shareowners of record received one share of the Company's common stock for every one share of UTC common stock and Carrier became an independent public company. Our common stock is listed under the symbol "CARR" on the NYSE. In connection with the Separation, Carrier issued an aggregate principal balance of $11.0 billion of debt and transferred approximately $10.9 billion of cash to UTC on February 27, 2020 and March 27, 2020. On April 1, 2020 and April 2, 2020, Carrier received cash contributions totaling $590 million from UTC related to the Separation. See Note 12 – Borrowings and Lines of Credit and Note 4 – Earnings Per Share in the accompanying Notes to the Consolidated Financial Statements for additional information.

[0001783180-21-000011:mdna:5]
Prior to the Separation and the Distribution, the Consolidated Financial Statements reflect the financial position, results of operations and cash flows of the Company for the periods presented as historically managed within UTC. For the periods prior to the Separation and the Distribution, the Consolidated Financial Statements were derived from the consolidated financial statements and accounting records of UTC and thus were prepared on a "carve-out" basis, as described subsequently. The Company's financial statements for the period from April 3, 2020 through December 31, 2020 are consolidated financial statements based on the reported results of Carrier as a stand-alone company.

[0001783180-21-000011:mdna:6]
The Consolidated Financial Statements include all revenues and costs directly attributable to Carrier, including costs for facilities, functions and services used by Carrier. Prior to the Separation and the Distribution, costs for certain functions and services performed by UTC were directly charged to Carrier based on specific identification when possible or based on a reasonable allocation driver such as net sales, headcount, proportionate usage or other allocation methods. The results of operations include allocations of costs for administrative functions and services performed on behalf of Carrier by centralized groups within UTC.

[0001783180-21-000011:mdna:7]
We entered into the TSA with UTC and Otis in connection with the Separation pursuant to which UTC provides us with certain services and we provide certain services to UTC for a limited time to help ensure an orderly transition following the Separation and the Distribution. The services we receive include, but are not limited to, information technology services, technical and engineering support, application support for operations, legal, payroll, finance, tax and accounting, general administrative services and other support services. The costs for these services historically were included in our operating results based on allocations from UTC and have not been materially different under the TSA, nor do we expect such costs to be materially different when these services are transitioned from UTC to Carrier.

[0001783180-21-000011:mdna:8]
Subsequent to the Separation and the Distribution, we have incurred and will continue to incur expenditures consisting primarily of employee-related costs, costs to establish certain stand-alone functions and information technology systems and other transaction-related costs. Additionally, we will have incurred and will continue to incur increased costs as a result of becoming an independent, publicly traded company, primarily from establishing or expanding corporate support for our businesses, including information technology, human resources, treasury, tax, internal audit, risk management, accounting and financial reporting, investor relations, governance, legal, procurement and other services. Our estimates of these additional recurring costs expected to be incurred annually are approximately $75 million in the aggregate greater than the expenses historically allocated to us from UTC, and primarily relate to Selling, general and administrative expenses. We believe our cash flows from operations will be sufficient to fund these additional corporate expenses.

[0001783180-21-000011:mdna:9]
In connection with the Separation, we entered into the TMA with UTC and Otis that governs the parties’ respective rights, responsibilities and obligations with respect to tax matters (including responsibility for taxes, entitlement to refunds, allocation of tax attributes, preparation of tax returns, control of tax contests and other tax matters). Subject to certain exceptions set forth in the TMA, Carrier generally is responsible for federal, state and foreign taxes imposed on a separate return basis upon Carrier (or any of our subsidiaries) with respect to taxable periods (or portions thereof) that ended on or prior to the date of the Distribution. The TMA provides special rules that allocate responsibility for tax liabilities arising from a failure of the

[0001783180-21-000011:mdna:10]
Separation transactions to qualify for tax-free treatment based on the reasons for such failure. The TMA also imposes restrictions on each of Carrier and Otis during the two-year period following the Distribution that are intended to prevent certain transactions from failing to qualify as transactions that are generally tax-free. See Note 1 – Description of the Business in the accompanying Notes to the Consolidated Financial Statements for additional information.

[0001783180-21-000011:mdna:11]
In connection with the Separation, we also entered into an employee matters agreement and intellectual property agreement with UTC and Otis. These agreements are not expected to have a material impact on the financial results of Carrier.

[0001783180-21-000011:mdna:12]
Business Summary

[0001783180-21-000011:mdna:13]
Carrier Global Corporation is a leading global provider of healthy, safe and sustainable building and cold chain solutions. Today, our portfolio includes industry-leading brands such as Carrier, Kidde, Edwards, LenelS2, Carrier Transicold and Automated Logic that offer innovative HVAC, refrigeration, fire, security and building automation technologies to help make the world safer and more comfortable.

[0001783180-21-000011:mdna:14]
Our worldwide operations are affected by global and regional industrial, economic and political factors and trends. These factors and trends include the mega-trends of urbanization, climate change and increasing requirements for food safety driven by the food needs of our growing global population and the rising standards of living in emerging markets. We believe that the Company's HVAC, Refrigeration and Fire & Security business segments are well positioned to benefit from favorable secular trends, including these mega-trends and from the strength of our industry-leading brands and track record of innovation.

[0001783180-21-000011:mdna:15]
The effects of climate change, such as extreme weather conditions, create financial risks to our business. For example, the demand for our products and services, such as residential air conditioning equipment, may be affected by unseasonable weather conditions. Demand for our HVAC products and services, representing our largest segment by sales, is seasonal and affected by the weather. Cooler than normal summers depress our sales of replacement air conditioning products and services. Similarly, warmer than normal winters have the same effect on our heating products.

[0001783180-21-000011:mdna:16]
Our business is also affected by changes in the general level of economic activity, such as changes in business and consumer spending, construction activity and shipping activity. A change in building and remodeling activity also can affect our financial performance. In addition, our financial performance may be influenced by the production and utilization of transport equipment, including truck production cycles in North America and Europe.

[0001783180-21-000011:mdna:17]
Business Segments

[0001783180-21-000011:mdna:18]
Our operations are organized into three segments: HVAC, Refrigeration and Fire & Security. Our HVAC segment provides products, controls, services and solutions to meet the heating and cooling and ventilation needs of residential and commercial customers. Our Refrigeration segment provides refrigeration and monitoring systems for trucks, trailers, shipping containers, intermodal and rail, as well as commercial refrigeration products. Our Fire & Security segment provides a wide range of residential and commercial building systems and security and service solutions. Our customers are in both the public and private sectors, and our businesses reflect extensive geographic diversification. See Note 1 – Description of the Business and Note 26 – Segment Financial Data in the accompanying Notes to the Consolidated Financial Statements for further information.

[0001783180-21-000011:mdna:19]
As part of our growth strategy, we invest in businesses in certain countries that carry higher levels of currency, political and/or economic risk, such as Mexico, China, Brazil, India and countries in the Middle East. As of December 31, 2020, our net assets in any one of these countries did not exceed 11% of our consolidated equity. See Note 26 – Segment Financial Data in the accompanying Notes to the Consolidated Financial Statements for further discussion of sales attributed to geographic regions.

[0001783180-21-000011:mdna:20]
Our earnings growth strategy contemplates earnings from organic sales growth, including growth from new product development and product improvements, structural cost reductions, operational improvements and incremental earnings from acquisitions.

[0001783180-21-000011:mdna:21]
Acquisition and restructuring costs associated with business combinations are expensed as incurred. Depending on the nature and level of acquisition activity, our earnings could be adversely impacted due to acquisition and restructuring actions initiated in connection with the integration of businesses acquired. For further discussion of acquisitions and restructuring, see Note 6 – Equity Method Investments and Related Parties, Note 10 – Business Acquisitions, Dispositions, Goodwill and Intangible Assets and Note 17 – Restructuring Costs in the accompanying Notes to the Consolidated Financial Statements.

[0001783180-21-000011:mdna:22]
Impact of the COVID-19 pandemic

[0001783180-21-000011:mdna:23]
COVID-19 surfaced in late 2019 and has spread throughout the world. In March 2020, COVID-19 was declared a pandemic by the World Health Organization and a national emergency by the U.S. government. The pandemic has negatively affected the U.S. and global economies, disrupted global supply chains and financial markets, resulted in significant travel restrictions, mandated facility closures, and resulted in shelter-in-place orders.

[0001783180-21-000011:mdna:24]
Carrier has taken and continues to take all prudent measures to protect the health and safety of our employees. In particular, we have implemented work-from-home requirements (where practical), social distancing and deep cleaning protocols at all of our facilities as well as travel restrictions, among other measures. We have also taken appropriate measures, which comply with applicable government regulations and guidance to work with our customers to minimize potential disruptions and to support the communities that we serve to address the challenges posed by the pandemic.

[0001783180-21-000011:mdna:25]
The full extent of the impact of COVID-19 on our operational and financial performance will depend on future developments, including the duration and spread of the pandemic as well as any worsening or additional outbreaks of the pandemic, related containment and mitigation actions taken by the U.S. federal, state and local and international governments to prevent disease spread and the rollout of vaccines in the U.S. and internationally, including the effectiveness of such vaccines in preventing COVID-19 and the time it takes to vaccinate a sufficient percentage of the U.S. and global populations. The extent of the pandemic's impact on Carrier will also depend upon our employees' ability to work safely in our facilities and to be granted access to vaccines (including the time it takes for our employees to be vaccinated), our customers’ ability to continue to operate or to receive our products, our suppliers' ability to continue to supply us with products and the level of activity and demand for the ultimate products and services of our customers or their customers.

[0001783180-21-000011:mdna:26]
In early 2020, we temporarily closed or reduced production at manufacturing facilities in North America, Asia and Europe for safety reasons and in response to lower demand for our products. Our manufacturing operations have since resumed, measures have been enacted to scale capacity to demand, and we continue to actively take steps to mitigate supply chain risk. We continue to apply appropriate safety measures and have not experienced any significant disruptions to our manufacturing operations. We also initiated return-to-work protocols at our non-manufacturing facilities where employees were previously working remotely.

[0001783180-21-000011:mdna:27]
We took preemptive actions in 2020 to preserve our liquidity and manage our cash flows to ensure we met our liquidity needs. Such actions included, but were not limited to, modifying the financial covenants in our revolving and term loan credit agreements and issuing $750 million of 2.700% Notes due 2031 (see Note 12 – Borrowings and Lines of Credit in the accompanying Notes to the Consolidated Financial Statements for further information), reducing our discretionary spending, our capital investments and general and administrative costs by implementing pay freezes and cuts, employee furloughs and the suspension of non-critical hiring, and participating in global COVID-19 relief measures.

[0001783180-21-000011:mdna:28]
CRITICAL ACCOUNTING ESTIMATES

[0001783180-21-000011:mdna:29]
Preparation of our financial statements requires management to make estimates and assumptions that affect the reported amounts of assets, liabilities, sales and expenses. Note 3 – Summary of Significant Accounting Policies in the accompanying Notes to the Consolidated Financial Statements describes the significant accounting policies used in preparation of the consolidated financial statements. We believe that the most complex and sensitive judgments, because of their potential significance to the Consolidated Financial Statements, result primarily from the need to make estimates about the effects of matters that are inherently uncertain and are described subsequently. Actual results could differ from management's estimates.

[0001783180-21-000011:mdna:30]
Goodwill and Intangible Assets

[0001783180-21-000011:mdna:31]
Our goodwill had an aggregate carrying amount of $10.1 billion as of December 31, 2020. Our indefinite-lived intangible assets primarily consist of individual trademarks, which had an aggregate carrying amount of $571 million as of December 31, 2020.

[0001783180-21-000011:mdna:32]
We test our reporting units and trademarks for impairment annually as of the first day of our third quarter, or more frequently if events or circumstances indicate it is more likely than not that the fair value of a reporting unit or trademark is less than its carrying amount. Such events and circumstances could include, among other things, increased competition or unexpected loss of market share, increased input costs beyond projections (for example, due to regulatory or industry changes), disposals of significant businesses or components of our business, unexpected business disruptions (for example, due to the loss of a customer, supplier or other significant business relationship), unexpected significant declines in operating results or significant adverse changes in the markets in which we operate. We test reporting units for impairment by comparing the estimated fair value of each reporting unit with its carrying amount. We test trademarks for impairment by comparing the estimated fair value of each brand with its carrying amount. If the carrying amount of a reporting unit or trademark exceeds its estimated fair value, we record an impairment loss based on the difference between fair value and carrying amount. In the case of reporting units, any impairment loss would not exceed the associated carrying amount of goodwill.

[0001783180-21-000011:mdna:33]
We performed our annual impairment assessment of goodwill and indefinite-lived trademarks as of July 1, 2020. As part of our annual impairment testing, we considered the impact of the adverse effects of COVID-19 on the global economy and our business and performed a quantitative impairment assessment that compared the fair value of each reporting unit to its associated carrying value to determine whether it was necessary to recognize a goodwill impairment. Estimating the fair value of individual reporting units and trademarks requires us to make assumptions and estimates regarding our future plans, as well as industry, economic and regulatory conditions, which were updated in performing the impairment assessment. If current expectations of future growth rates and margins are not met, if market factors outside of our control, such as discount rates, change, or if management’s expectations or plans otherwise change, including as a result of the execution of our global five-year strategic plan, then one or more of our reporting units or trademarks might become impaired in the future.

[0001783180-21-000011:mdna:34]
We utilize the discounted cash flow method under the income approach to estimate the fair value of our reporting units. The discounted cash flow method relies on estimates of future cash flows and explicitly addresses factors such as timing, growth and margins, with due consideration given to forecasting risk. We developed these assumptions based on the market and geographic risks unique to each reporting unit. The significant assumptions inherent in estimating the fair values include the estimated future annual net cash flows for each reporting unit (based on projected net sales, operating margins, working capital and capital expenditures), income tax rates, long-term growth rates and a discount rate that appropriately reflects the risks inherent in estimating future cash flows. We selected the assumptions used in the financial forecasts based on historical data, supplemented by current and anticipated market conditions, estimated growth rates and management’s plans. For all reporting units, the fair value of goodwill exceeded the carrying value, resulting in no goodwill impairment. However, for one reporting unit with goodwill of $917 million, the excess of fair value over the carrying value was approximately 13%. For this reporting unit, a 100 basis point increase in the discount rate used in the financial forecast would result in an impairment of approximately $84 million. The estimated fair value of the reporting unit would be negatively impacted if future economic conditions are worse than our financial forecast and assumptions or there are substantial reductions in our end markets and volume assumptions relative to our financial forecast.

[0001783180-21-000011:mdna:35]
For our indefinite-lived assets, a fair value is determined on a relief from royalty methodology, which is based on the implied royalty paid, at an appropriate discount rate, to license the use of an asset rather than owning the asset. The significant assumptions inherent in estimating fair value include the estimated future annual net sales for each trademark, royalty rates (as a percentage of net sales that would hypothetically be charged by a licensor of the brand to an unrelated licensee), income tax

[0001783180-21-000011:mdna:36]
considerations, long-term growth rates, a discount rate that reflects the level of risk associated with the future cost savings attributable to the brand, and management’s intent to invest in the brand indefinitely. We selected the assumptions used in the financial forecasts based on historical data, supplemented by current and anticipated market conditions, and estimated product category growth rates, management’s plans and guideline companies. The present value of the after-tax cost savings (i.e., royalty relief) indicates the estimated fair value of the asset. Any excess of the carrying value over the estimated fair value would be recognized as an impairment loss equal to that excess. For all trade names, the excess of the estimated fair value over carrying value (expressed as a percentage of carrying value) in the 2020 test was a minimum of 80%. Based upon the quantitative assessment performed, the fair value of indefinite-lived trademarks was determined to exceed the carrying value, resulting in no impairment.

[0001783180-21-000011:mdna:37]
The estimates of fair value are based on the best information available as of the date of the assessment, which primarily incorporates management assumptions about expected future cash flows. Although these assets are not currently impaired, there can be no assurance that future impairments will not occur. See Note 10 – Business Acquisitions, Dispositions, Goodwill and Intangible Assets in the accompanying Notes to the Consolidated Financial Statements for further information.

[0001783180-21-000011:mdna:38]
Revenue Recognition from Contracts with Customers

[0001783180-21-000011:mdna:39]
Effective January 1, 2018, we adopted ASU 2014-09 – Revenue from Contracts with Customers and its related amendments ("New Revenue Standard") and elected the modified retrospective approach. The adoption of the New Revenue Standard did not have a material impact on revenue, net income or net assets. Note 5 – Revenue Recognition in the accompanying Notes to the Consolidated Financial Statements contains further detail regarding the adoption of the New Revenue Standard and its impact on the consolidated financial statements as of, and for, the year ended December 31, 2018.

[0001783180-21-000011:mdna:40]
We recognize revenue on an over-time basis on installation and service contracts related to our HVAC, Refrigeration and Fire & Security service businesses. For contracts recorded on an over-time basis, we measure progress toward completion using costs incurred to date relative to total estimated costs at completion. This over-time basis using an input method requires estimates of future revenues and costs over the full term of product and/or service delivery. Incurred costs represent work performed, which correspond with and best depict transfer of control to the customer. Contract costs are incurred over a period of time, which can generally range from several months to years, and the estimation of these costs requires management’s judgment. We review our cost estimates on significant contracts on a quarterly basis and, for others, at least annually or when circumstances change and warrant a modification to a previous estimate. We record changes in contract estimates using the cumulative catch-up method.

[0001783180-21-000011:mdna:41]
We consider the contractual consideration payable by the customer and assess variable consideration that may affect the total transaction price, including contractual discounts, contract incentive payments, estimates of award fees and other sources of variable consideration, when determining the transaction price of each contract. Variable consideration is included in the estimated transaction price when there is a basis to reasonably estimate the amount. These estimates are based on historical experience, anticipated performance and management's judgment. We also consider whether the contracts provide customers with significant financing, although in general our contracts do not contain significant financing.

[0001783180-21-000011:mdna:42]
Income Taxes

[0001783180-21-000011:mdna:43]
The future tax benefit arising from deductible temporary differences and tax carryforwards was $838 million and $923 million as of December 31, 2020 and 2019, respectively. Management believes that our earnings during the periods when the temporary differences become deductible will be sufficient to realize the related future income tax benefits, which may be realized over an extended period of time. For those jurisdictions where the expiration date of tax carryforwards or the projected operating results indicate that realization is not likely, a valuation allowance is provided.

[0001783180-21-000011:mdna:44]
In assessing the need for a valuation allowance, we estimate future taxable income, considering the feasibility of ongoing tax planning strategies and the realizability of tax loss carryforwards. Valuation allowances related to deferred tax assets can be affected by changes in tax laws, changes to statutory tax rates and future taxable income levels. In the event we were to determine that we would not be able to realize all or a portion of our deferred tax assets in the future, we would reduce such amounts through an increase to tax expense in the period in which that determination is made or when tax law changes are enacted. Conversely, if we were to determine that we would be able to realize our deferred tax assets in the future in excess of the net carrying amounts, we would decrease a recorded valuation allowance through a decrease to tax expense in the period in which that determination is made.

[0001783180-21-000011:mdna:45]
35

[0001783180-21-000011:mdna:46]
In the ordinary course of business there is inherent uncertainty in quantifying our income tax positions. We assess our income tax positions and record tax benefits for all years subject to examination based upon management’s evaluation of the facts, circumstances and information available at the reporting date. For those tax positions where it is more likely than not that a tax benefit will be sustained, we have recorded the largest amount of tax benefit with a greater than 50% likelihood of being realized upon ultimate settlement with a taxing authority that has full knowledge of all relevant information. For those income tax positions where it is not more likely than not that a tax benefit will be sustained, no tax benefit has been recognized in the Consolidated Financial Statements. See Note 3 – Summary of Significant Accounting Policies and Note 19 – Income Taxes in the accompanying Notes to the Consolidated Financial Statements for further discussion.

[0001783180-21-000011:mdna:47]
Employee Benefit Plans

[0001783180-21-000011:mdna:48]
We sponsor domestic and foreign defined benefit pension and other post-retirement plans. The major assumptions used in the accounting for these employee benefit plans include the discount rate, expected return on plan assets, rate of increase in employee compensation levels and mortality rates. Assumptions are determined based on company data and appropriate market indicators and are evaluated each year as of December 31. A change in any of these assumptions would have an effect on net periodic pension and post-retirement benefit costs reported in the Consolidated Financial Statements.

[0001783180-21-000011:mdna:49]
The following table summarizes the sensitivity of our pension plan liabilities and net periodic cost to a 25 basis point change in the discount rates for benefit obligations, interest cost and service cost as of December 31, 2020:

[0001783180-21-000011:mdna:50]
| (dollars in millions) |  | Increase in Discount Rate of 25 bps |  | Decrease in Discount Rate of 25 bps |
| Pension plans |  |  |  |  |
| Projected benefit obligation |  | $ | (112) |  |  | $ | 119 |  |
| Net periodic pension (benefit) cost |  | $ | (2) |  |  | $ | 2 |  |

[0001783180-21-000011:mdna:51]
A 25 basis point change in the discount rate would not have a material impact on our post-retirement benefit plan obligations as of December 31, 2020.

[0001783180-21-000011:mdna:52]
These estimates assume no change in the shape or steepness of the company-specific yield curve used to plot the individual spot rates that will be applied to the future cash outflows for future benefit payments in order to calculate interest and service cost. A flattening of the yield curve, from a narrowing of the spread between interest and obligation discount rates, would increase our net periodic pension cost. Conversely, a steepening of the yield curve, from an increase in the spread between interest and obligation discount rates, would decrease our net periodic pension cost.

[0001783180-21-000011:mdna:53]
Pension expense is also sensitive to changes in the expected return on plan assets. An increase or decrease of 25 basis points in the expected return on plan assets would have decreased or increased 2020 pension expense by approximately $7 million.

[0001783180-21-000011:mdna:54]
The weighted-average discount rates used to measure pension liabilities and costs utilize each plan’s specific cash flows and are then compared with high-quality bond indices for reasonableness. For our significant plans, we utilize a full yield curve approach in the estimation of the service cost and interest cost components by applying the specific spot rates along the yield curve used in the determination of the benefit obligation to the relevant projected cash flows. Global market interest rates decreased during 2020 compared with 2019, and as a result, the weighted-average discount rate used to measure pension liabilities decreased from 2.0% in 2019 to 1.4% during 2020. The weighted-average discount rates used to measure service cost and interest cost were 1.8% and 1.8%, respectively, during 2020 and 3.2% and 2.7%, respectively in 2019.

[0001783180-21-000011:mdna:55]
See Note 13 – Employee Benefit Plans in the accompanying Notes to the Consolidated Financial Statements for further discussion.

[0001783180-21-000011:mdna:56]
Contingent Liabilities

[0001783180-21-000011:mdna:57]
As described in Note 25 – Commitments and Contingent Liabilities in the accompanying Notes to the Consolidated Financial Statements, contractual, regulatory and other matters, including asbestos claims, may arise in the ordinary course of business that subject us to claims or litigation. We have recorded reserves in the consolidated financial statements related to these matters, which are developed using input derived from actuarial estimates and historical and anticipated experience depending on the nature of the reserve, and in certain instances in consultation with legal counsel, internal and external

[0001783180-21-000011:mdna:58]
36

[0001783180-21-000011:mdna:59]
consultants and engineers. Subject to the uncertainties inherent in estimating future costs for these types of liabilities, we believe our estimated reserves are reasonable and do not believe the final determination of the liabilities with respect to these matters would have a material adverse effect upon our competitive position, results of operations, cash flows or financial condition. See the "Risk Factors" section in this Annual Report on Form 10-K for additional information.

[0001783180-21-000011:mdna:60]
Environmental Matters

[0001783180-21-000011:mdna:61]
Our operations are subject to environmental regulation by federal, state and local authorities in the U.S. and various regulatory authorities with jurisdiction over our foreign operations. As a result, we have established, and periodically update, policies relating to environmental standards of performance for our operations worldwide. We believe that expenditures necessary to comply with the current regulations governing environmental protection will not have a material adverse effect upon our competitive position, results of operations, cash flows or financial condition.

[0001783180-21-000011:mdna:62]
At the commencement of 2020, we identified 85 locations with reserves for which we may have some liability for remediating contamination. However, a few of these locations tracked several claims as a group which we are now tracking as 95 separate locations. Additionally, we added two new locations to our remediation program for the year ended December 31, 2020, resulting in 97 locations with reserves as of December 31, 2020. We do not believe that any individual location's exposure will have a material adverse effect on our results of operations. Sites in the investigation, remediation or operation and maintenance stage represent approximately 85% of our accrued environmental remediation reserve, while the remaining 15% reflects administrative costs such as legal fees, permits, settlements and municipal fees.

[0001783180-21-000011:mdna:63]
We have been identified as a potentially responsible party under the Comprehensive Environmental Response Compensation and Liability ACT ("Superfund") at 18 sites. The number of Superfund sites, in and of itself, does not represent a relevant measure of liability because the nature and extent of environmental concerns vary from site to site and our share of responsibility varies from sole responsibility to very little responsibility. In estimating our liability for remediation, we consider our likely proportionate share of the anticipated remediation expense and the ability of other potentially responsible parties to fulfill their obligations.

[0001783180-21-000011:mdna:64]
As of December 31, 2020 and 2019, the outstanding liability for environmental obligations was $239 million and $217 million, respectively. See Note 25 – Commitments and Contingent Liabilities in the accompanying Notes to the Consolidated Financial Statements for additional discussion.

[0001783180-21-000011:mdna:65]
Asbestos Matters

[0001783180-21-000011:mdna:66]
The amounts recorded for asbestos-related liabilities are based on currently available information and assumptions that we believe are reasonable and are made with input from outside actuarial experts. The estimated range of total liabilities to resolve all pending and unasserted potential future asbestos claims through 2059 is approximately $245 million to $276 million. Where no amount within a range of estimates is more likely, the minimum is accrued. We have recorded the minimum amount of $245 million, which is principally recorded in Other long-term liabilities on the Consolidated Balance Sheet as of December 31, 2020. This amount is not discounted and excludes the Company’s legal fees to defend the asbestos claims, which will continue to be expensed by the Company as incurred. In addition, the Company has an insurance recovery receivable for probable asbestos related recoveries of approximately $103 million, which is included primarily in Other assets on the Consolidated Balance Sheet as of December 31, 2020. See "Legal Proceedings" for further discussion of the estimated liabilities and insurance recoveries. See Note 25 – Commitments and Contingent Liabilities in the accompanying Notes to the Consolidated Financial Statements for further discussion.

[0001783180-21-000011:mdna:67]
Recent Accounting Pronouncements

[0001783180-21-000011:mdna:68]
See Note 3 – Summary of Significant Accounting Policies in the accompanying Notes to the Consolidated Financial Statements for a discussion of recent accounting pronouncements and their effect on us.

[0001783180-21-000011:mdna:69]
37

[0001783180-21-000011:mdna:70]
RESULTS OF OPERATIONS

[0001783180-21-000011:mdna:71]
The Company's financial statements for the periods prior to the Separation and the Distribution are prepared on a "carve-out" basis as described in Note 2 – Basis of Presentation. The Company's financial statements for the period from April 3, 2020 through December 31, 2020 are consolidated financial statements based on the reported results of Carrier as a stand-alone company.

[0001783180-21-000011:mdna:72]
The following represents our consolidated net sales and operating results (dollars in millions):

[0001783180-21-000011:mdna:73]
|  | For the Year Ended December 31, |
| (dollars in millions) | 2020 |  | 2019 |  | 2018 |
| Segment net sales: |  |  |  |  |  |
| HVAC | $ | 9,478 |  |  | $ | 9,712 |  |  | $ | 9,713 |  |
| Refrigeration | 3,333 |  |  | 3,792 |  |  | 4,095 |  |
| Fire & Security | 4,985 |  |  | 5,500 |  |  | 5,531 |  |
| Eliminations and other | (340) |  |  | (396) |  |  | (425) |  |
|  | 17,456 |  |  | 18,608 |  |  | 18,914 |  |
| Cost of products and services sold | 12,347 |  |  | 13,189 |  |  | 13,345 |  |
| Gross margin | 5,109 |  |  | 5,419 |  |  | 5,569 |  |
| Research and development | 419 |  |  | 401 |  |  | 400 |  |
| Selling, general and administrative | 2,820 |  |  | 2,761 |  |  | 2,689 |  |
| Equity method investment net earnings | 207 |  |  | 236 |  |  | 220 |  |
| Other income (expense), net | 1,006 |  |  | (2) |  |  | 937 |  |
| Operating profit | 3,083 |  |  | 2,491 |  |  | 3,637 |  |
| Non-service pension benefit | 60 |  |  | 154 |  |  | 168 |  |
| Interest (expense) income, net | (288) |  |  | 27 |  |  | 37 |  |
| Income from operations before income taxes | 2,855 |  |  | 2,672 |  |  | 3,842 |  |
| Income tax expense | 849 |  |  | 517 |  |  | 1,073 |  |
| Net income from operations | 2,006 |  |  | 2,155 |  |  | 2,769 |  |
| Less: Non-controlling interest in subsidiaries' earnings from operations | 24 |  |  | 39 |  |  | 35 |  |
| Net income attributable to common shareholders | $ | 1,982 |  |  | $ | 2,116 |  |  | $ | 2,734 |  |

[0001783180-21-000011:mdna:74]
Net Sales

[0001783180-21-000011:mdna:75]
| (dollars in millions) |  | 2020 |  | 2019 |  | 2018 |  |  |  |  |  |  |
| Net sales |  | $ | 17,456 |  | $ | 18,608 |  | $ | 18,914 |  |  |  |  |  |  |
| Percentage change |  | (6) | % |  | (2) | % |  |  |  |  |  |  |  |  |

[0001783180-21-000011:mdna:76]
The factors contributing to the total percentage change year-over-year in total net sales are as follows:

[0001783180-21-000011:mdna:77]
|  | 2020 |  | 2019 |  |  |
| Organic / Operational | (6) | % |  | 1 | % |  |  |
| Foreign currency translation | — | % |  | (2) | % |  |  |
| Acquisitions and divestitures, net | — | % |  | (1) | % |  |  |
| Total % change | (6) | % |  | (2) | % |  |  |

[0001783180-21-000011:mdna:78]
38

[0001783180-21-000011:mdna:79]
The 6% organic sales decrease for the year ended December 31, 2020 reflects lower sales volumes across all of the segments driven by the economic slowdown attributed to COVID-19 throughout 2020. The organic sales decrease in HVAC of 2% reflects declines in commercial HVAC and light commercial HVAC that were largely driven by the economic slowdown related to COVID-19, partially offset by increases in North America residential HVAC. The increase in North America residential HVAC sales was driven by new housing starts in addition to higher demand for replacement units due to increased usage attributed to a warmer than normal summer and remote work and school activities associated with COVID-19. The organic sales decrease of 12% in Refrigeration was driven by declines in commercial refrigeration that were primarily due to lower demand and the closure of new equipment installation sites because of COVID-19, in transport refrigeration in Europe and North America due to economic slowdowns related to COVID-19 and lower truck trailer sales volume in North America when compared with the cyclical peak experienced in 2019. Fire & Security sales decreased 9% organically reflecting lower product and field service sales. The decline in product sales was primarily driven by lower volume in North America and EMEA due to COVID-19. Field service sales were down primarily in Europe and Asia reflecting the impact of business shutdowns and project delays as a result of COVID-19. For additional discussion on the segment results for 2020, see the section entitled "Segment Review."

[0001783180-21-000011:mdna:80]
The organic sales increase of 1% for the year ended December 31, 2019 was primarily driven by growth in HVAC (1%) and in Fire & Security (1%), partially offset by declines in Refrigeration (1%). HVAC organic sales growth was driven by stronger sales in North America residential HVAC and by growth in commercial HVAC in Asia and the Americas. Organic sales growth in Fire & Security was driven by stronger product sales globally, as well as field service growth primarily within Asia. The decline in Refrigeration was driven by transport refrigeration, primarily the container business, partially offset by growth in North America Truck Trailer as well as a decline in commercial refrigeration, primarily in Europe. The divestiture related sales decrease in 2019 was due to the sale of Taylor in 2018, which was part of Refrigeration.

[0001783180-21-000011:mdna:81]
Cost of Products and Services Sold

[0001783180-21-000011:mdna:82]
| (dollars in millions) |  | 2020 |  | 2019 |  | 2018 |  |  |  |  |
| Total cost of products and services sold |  | $ | 12,347 |  | $ | 13,189 |  | $ | 13,345 |  |  |  |  |  |
| Percentage change year-over-year |  | (6) | % |  | (1) | % |  |  |  |  |  |  |

[0001783180-21-000011:mdna:83]
The factors contributing to the percentage change year-over-year in total cost of products and services sold are as follows:

[0001783180-21-000011:mdna:84]
|  | 2020 |  | 2019 |  |  |
| Organic / Operational | (6) | % |  | 2 | % |  |  |
| Foreign currency translation | — | % |  | (2) | % |  |  |
| Acquisitions and divestitures, net | — | % |  | (1) | % |  |  |
| Total % change | (6) | % |  | (1) | % |  |  |

[0001783180-21-000011:mdna:85]
The 6% organic decrease in the cost of products and services sold for the year ended December 31, 2020 is consistent with the 6% organic sales decrease largely attributed to the economic slowdown related to COVID-19.

[0001783180-21-000011:mdna:86]
The decrease in total cost of products and services sold for the year ended December 31, 2019 was primarily driven by favorable foreign currency translation and net acquisition and divestiture activity, which more than offset increases from organic sales growth, higher tariffs and unfavorable commodity prices.

[0001783180-21-000011:mdna:87]
Gross Margin

[0001783180-21-000011:mdna:88]
| (dollars in millions) |  | 2020 |  | 2019 |  | 2018 |  |  |  |  |
| Gross margin |  | $ | 5,109 |  | $ | 5,419 |  | $ | 5,569 |  |  |  |  |
| Percentage of net sales |  | 29.3 | % |  | 29.1 | % |  | 29.4 | % |  |  |  |  |

[0001783180-21-000011:mdna:89]
The 20 basis point increase in gross margin as a percentage of sales for 2020 reflects the benefit from favorable material productivity, partially offset by the effects of lower sales volumes largely as a result of the economic slowdown resulting from COVID-19.

[0001783180-21-000011:mdna:90]
39

[0001783180-21-000011:mdna:91]
Gross margin as a percentage of net sales decreased 30 basis points for the year ended December 31, 2019 as the favorable impact of pricing and productivity net of unfavorable commodity prices and tariffs was more than offset by unfavorable mix, the absence of a favorable prior year contract adjustment related to a large commercial project and the unfavorable year-over-year impact resulting from the revaluation of certain long-term liabilities.

[0001783180-21-000011:mdna:92]
Selling, General and Administrative

[0001783180-21-000011:mdna:93]
| (dollars in millions) |  | 2020 |  | 2019 |  | 2018 |
| Selling, general and administrative expenses |  | $ | 2,820 |  |  | $ | 2,761 |  |  | $ | 2,689 |  |
| Percentage of net sales |  | 16.2 | % |  | 14.8 | % |  | 14.2 | % |

[0001783180-21-000011:mdna:94]
The $59 million increase in Selling, general and administrative expenses for the year ended December 31, 2020 was primarily attributed to a year-over-year increase of $75 million in one-time Separation related costs, $75 million in costs associated with Carrier's transition to an independent publicly traded company and other costs. Increased Separation and public company costs were partially offset by cost containment initiatives implemented to mitigate the impact of COVID-19, which included furloughs, temporary pay freezes and pay cuts and reductions in discretionary spending, lower restructuring costs of $61 million, the absence of a $34 million charge incurred in 2019 related to the impact of a consultant contract termination and lower costs associated with the wind-down of a residential intrusion business of $21 million. As a percentage of sales, the 140 basis point increase was primarily driven by lower sales as a result of COVID-19.

[0001783180-21-000011:mdna:95]
Selling, general and administrative expenses increased $72 million for the year ended December 31, 2019 primarily driven by $53 million of costs related to the Separation, and a consultant contract termination fee of $34 million, neither of which were incurred in 2018, partially offset by lower year-over-year corporate allocations from UTC.

[0001783180-21-000011:mdna:96]
We are continuously evaluating our cost structure and have implemented restructuring actions to keep our cost structure competitive. The amounts reflected previously include the impact of restructuring actions on Selling, general and administrative expenses. For further discussion, see Note 17 – Restructuring Costs in the accompanying Notes to the Consolidated Financial Statements.

[0001783180-21-000011:mdna:97]
Equity Method Investment Net Earnings

[0001783180-21-000011:mdna:98]
| (dollars in millions) |  | 2020 |  | 2019 |  | 2018 |
| Equity method investment net earnings |  | $ | 207 |  |  | $ | 236 |  |  | $ | 220 |  |

[0001783180-21-000011:mdna:99]
Investments over which we do not exercise control, but have significant influence, are accounted for using the equity method of accounting. Equity method investment net earnings decreased $29 million for the year ended December 31, 2020 primarily due to lower earnings from our investments in HVAC joint ventures in Asia and the Middle East, primarily due to the impact of COVID-19 and the adverse impact of a product performance matter at one of our HVAC joint ventures.

[0001783180-21-000011:mdna:100]
In 2020, we sold our equity ownership in Beijer for $1.4 billion and recognized a pre-tax gain of approximately $1.1 billion. Following the sale, Carrier no longer has equity ownership in Beijer. For the year ended December 31, 2020, Carrier recognized $27 million of equity method investment net earnings related to our equity ownership in Beijer.

[0001783180-21-000011:mdna:101]
Equity in earnings of unconsolidated equity method investments increased by $16 million for the year ended December 31, 2019, primarily due to stronger earnings from our HVAC equity method investments in Europe and Asia.

[0001783180-21-000011:mdna:102]
See Note 6 – Equity Method Investments and Related Parties in the accompanying Notes to the Consolidated Financial Statements for additional information.

[0001783180-21-000011:mdna:103]
Other Income (Expense), Net

[0001783180-21-000011:mdna:104]
| (dollars in millions) |  | 2020 |  | 2019 |  | 2018 |
| Other income (expense), net |  | $ | 1,006 |  |  | $ | (2) |  |  | $ | 937 |  |

[0001783180-21-000011:mdna:105]
Other income (expense), net primarily includes the impact of gains and losses related to sale of ownership in our equity method investments or infrequently occurring items. The year-over-year change of $1.0 billion for 2020, is primarily attributed to a $1.1 billion gain on the sale of our equity ownership in Beijer. The favorable $37 million year-over-year impact related to other-than-temporary impairment charges of $71 million in 2020 and $108 million in 2019 was offset by the absence of gains on the sale of equity method investments and real property of $79 million and $19 million in charges related to litigation matters in 2020.

[0001783180-21-000011:mdna:106]
The year-over-year decrease of $939 million in Other income (expense), net for the year ended December 31, 2019 was primarily driven by the absence of a prior year gain of $799 million from the divestiture of Taylor, as well as the 2019 impairment of an equity method investment of $108 million.

[0001783180-21-000011:mdna:107]
Interest (Expense) Income, Net

[0001783180-21-000011:mdna:108]
| (dollars in millions) |  | 2020 |  | 2019 |  | 2018 |
| Interest expense |  | $ | (298) |  |  | $ | (75) |  |  | $ | (84) |  |
| Interest income |  | 10 |  |  | 102 |  |  | 121 |  |
| Interest (expense) income, net |  | $ | (288) |  |  | $ | 27 |  |  | $ | 37 |  |

[0001783180-21-000011:mdna:109]
Prior to the Separation and the Distribution, interest income and interest expense related primarily to interest on related party activity between Carrier and UTC. See "Liquidity and Financial Condition" and Note 6 – Equity Method Investments and Related Parties in the accompanying Notes to the Consolidated Financial Statements for additional information.

[0001783180-21-000011:mdna:110]
Interest (expense) income, net reflects $315 million higher year-over-year interest expense, net for the year ended December 31, 2020 compared with 2019 due to the issuance of $9.25 billion of long-term fixed rate notes in February 2020, a $1.75 billion draw on our Term Loan Credit Facility (defined subsequently) in March 2020, the issuance of $750 million of long-term fixed rate notes in June 2020, and a decrease in interest income earned on related party receivables due from UTC. In the three months ended December 31, 2020, Carrier prepaid the $1.75 billion Term Loan Credit Facility for which $26 million of interest expense was recognized in the year ended December 31, 2020. See Note 12 – Borrowings and Lines of Credit in the accompanying Notes to the Consolidated Financial Statements for additional information.

[0001783180-21-000011:mdna:111]
Interest (expense) income, net decreased for the year ended December 31, 2019 as compared with 2018, which primarily reflects changes in interest earned on related party receivables due from UTC.

[0001783180-21-000011:mdna:112]
Income Taxes

[0001783180-21-000011:mdna:113]
|  |  | 2020 |  | 2019 |  | 2018 |
| Effective tax rate |  | 29.7 | % |  | 19.4 | % |  | 27.9 | % |

[0001783180-21-000011:mdna:114]
The increase in the effective tax rate for the year ended December 31, 2020 compared with the prior year is primarily due to the absence of a prior year combined tax benefit of $149 million resulting from the filing by a Carrier subsidiary to participate in an amnesty program offered by the Italian Tax Authority and the conclusion of an audit by the IRS for UTC tax years 2014, 2015 and 2016. In addition, the following tax costs were recorded for the year ended December 31, 2020: a $51 million adjustment related to a valuation allowance recorded against a United Kingdom tax loss and credit carry forward resulting from separation-related activities and an adjustment of $46 million resulting from Carrier's decision to no longer permanently reinvest certain pre-2018 unremitted non-U.S. earnings.

[0001783180-21-000011:mdna:115]
The 2019 effective tax rate reflects a net tax benefit of $149 million as a result of the filing by a subsidiary of Carrier to participate in an amnesty program offered by the Italian Tax Authority and the conclusion of the audit by the Examination Division of the IRS for the UTC 2014, 2015 and 2016 tax years.

[0001783180-21-000011:mdna:116]
The 2018 effective tax rate reflects a net tax charge of $102 million as a result of UTC ceasing to assert that it intended to reinvest certain undistributed earnings of its international subsidiaries. The effective income tax rate for 2018 also reflects the incremental tax cost associated with the divestiture of Taylor.

[0001783180-21-000011:mdna:117]
For further discussion of income taxes and the effective income tax rate, see "Critical Accounting Estimates — Income Taxes" and Note 19 – Income Taxes in the accompanying Notes to the Consolidated Financial Statements.

[0001783180-21-000011:mdna:118]
Segment Review

[0001783180-21-000011:mdna:119]
We determine our segments based on how our Chief Executive Officer, who is our Chief Operating Decision Maker ("CODM"), allocates resources, assesses performance and makes operational decisions. The CODM allocates resources and evaluates the financial performance of each of our segments, HVAC, Refrigeration and Fire & Security, based on net sales and operating profit. Adjustments to reconcile segment reporting to the consolidated results for 2020 and 2019 are included in the section entitled "Eliminations and other and General corporate expenses."

[0001783180-21-000011:mdna:120]
Summary performance for each of our segments is as follows:

[0001783180-21-000011:mdna:121]
|  | Net Sales |  | Operating Profit |  | Operating Margin |
| (dollars in millions) | 2020 |  | 2019 |  | 2018 |  | 2020 |  | 2019 |  | 2018 |  | 2020 |  | 2019 |  | 2018 |
| HVAC | $ | 9,478 |  |  | $ | 9,712 |  |  | $ | 9,713 |  |  | $ | 2,462 |  |  | $ | 1,563 |  |  | $ | 1,720 |  |  | 26.0 | % |  | 16.1 | % |  | 17.7 | % |
| Refrigeration | 3,333 |  |  | 3,792 |  |  | 4,095 |  |  | 357 |  |  | 532 |  |  | 1,353 |  |  | 10.7 | % |  | 14.0 | % |  | 33.0 | % |
| Fire & Security | 4,985 |  |  | 5,500 |  |  | 5,531 |  |  | 584 |  |  | 708 |  |  | 726 |  |  | 11.7 | % |  | 12.9 | % |  | 13.1 | % |
| Total segment | 17,796 |  |  | 19,004 |  |  | 19,339 |  |  | 3,403 |  |  | 2,803 |  |  | 3,799 |  |  | 19.1 | % |  | 14.7 | % |  | 19.6 | % |
| Eliminations and other | (340) |  |  | (396) |  |  | (425) |  |  | (184) |  |  | (156) |  |  | (24) |  |  | 54.1 | % |  | 40.0 | % |  | 5.6 | % |
| General corporate expenses | — |  |  | — |  |  | — |  |  | (136) |  |  | (156) |  |  | (138) |  |  | — | % |  | — | % |  | — | % |
| Consolidated | $ | 17,456 |  |  | $ | 18,608 |  |  | $ | 18,914 |  |  | $ | 3,083 |  |  | $ | 2,491 |  |  | $ | 3,637 |  |  | 17.7 | % |  | 13.4 | % |  | 19.2 | % |

[0001783180-21-000011:mdna:122]
HVAC

[0001783180-21-000011:mdna:123]
Our HVAC segment provides products, controls, services and solutions to meet the heating and cooling needs of residential and commercial customers, while enhancing building performance, energy efficiency and sustainability. Our established brands include Automated Logic, BluEdge, Bryant, Carrier, CIAT, Day & Night, Heil, NORESCO, Riello and Tempstar. Products include air conditioners, heating systems, controls and aftermarket components, as well as aftermarket repair and maintenance services and building automation solutions. Some of these products are part of Carrier's Healthy Buildings Program, which offers a suite of targeted solutions focused on improving indoor air quality in buildings and homes. HVAC products and solutions are sold directly, including to building contractors and owners, and indirectly through joint ventures, independent sales representatives, distributors, wholesalers, dealers and retail outlets, and through direct sales offices which sell, in part, to mechanical contractors.

[0001783180-21-000011:mdna:124]
2020 Compared with 2019

[0001783180-21-000011:mdna:125]
| (dollars in millions) | 2020 |  | 2019 |  | Increase (Decrease) |  | % Increase (Decrease) |
| Net sales | $ | 9,478 |  |  | $ | 9,712 |  |  | $ | (234) |  |  | (2) | % |
| Operating profit | $ | 2,462 |  |  | $ | 1,563 |  |  | $ | 899 |  |  | 58 | % |

[0001783180-21-000011:mdna:126]
|  | Net sales |  | Operating profit |
| Organic / Operational | (2) | % |  | (15) | % |
| Foreign currency translation | — | % |  | (1) | % |
| Restructuring | — | % |  | 3 | % |
| Other | — | % |  | 71 | % |
| Total % change | (2) | % |  | 58 | % |

[0001783180-21-000011:mdna:127]
The organic sales decrease of 2% reflects declines in North America light commercial HVAC (15%) and commercial HVAC (9%) largely driven by the economic slowdown resulting from COVID-19, partially offset by increases in North America residential HVAC (10%). Commercial HVAC sales declined globally except in China, which saw an increase. The residential HVAC sales increase was driven by new housing starts in addition to higher demand for replacement units attributed to increased usage as a result of a warmer than normal summer, and remote work and school activity resulting from COVID-19.

[0001783180-21-000011:mdna:128]
The operational profit decrease of 15% was primarily attributed to lower sales volumes and unfavorable mix and increased selling, general and administrative costs, including higher costs associated with Carrier’s transition to an independent publicly traded company partially offset by favorable net material productivity.

[0001783180-21-000011:mdna:129]
The increase in Other of 71% primarily reflects a $1.1 billion gain on the sale of the Company's equity ownership in Beijer, partially offset by a $108 million impairment charge related to a minority-owned joint venture investment in 2019.

[0001783180-21-000011:mdna:130]
2019 Compared with 2018

[0001783180-21-000011:mdna:131]
| (dollars in millions) | 2019 |  | 2018 |  | Increase (Decrease) |  | % Increase (Decrease) |
| Net sales | $ | 9,712 |  |  | $ | 9,713 |  |  | $ | (1) |  |  | — | % |
| Operating profit | $ | 1,563 |  |  | $ | 1,720 |  |  | $ | (157) |  |  | (9) | % |

[0001783180-21-000011:mdna:132]
|  | Net sales |  | Operating profit |
| Organic / Operational | 1 | % |  | — | % |
| Foreign currency translation | (1) | % |  | (1) | % |
| Restructuring | — | % |  | (2) | % |
| Other | — | % |  | (6) | % |
| Total % change | — | % |  | (9) | % |

[0001783180-21-000011:mdna:133]
The organic sales increase of 1% primarily reflects stronger North America residential HVAC sales (2%), in addition to growth for commercial HVAC offerings in Asia (3%) and the Americas (2%), partially offset by declines in EMEA (9%).

[0001783180-21-000011:mdna:134]
Organic operational profit was flat due to favorable pricing offset by unfavorable mix.

[0001783180-21-000011:mdna:135]
The 6% decrease in Other primarily reflects a $108 million impairment charge related to a minority-owned joint venture investment in 2019.

[0001783180-21-000011:mdna:136]
Refrigeration

[0001783180-21-000011:mdna:137]
Our Refrigeration segment includes transport refrigeration and monitoring systems for trucks, trailers, shipping containers, intermodal and rail, as well as commercial refrigeration products. Transport refrigeration products and cold chain monitoring solutions, which are part of Carrier's Healthy, Safe, Sustainable Cold Chain Program, are used to enable the safe and reliable transport of food and beverages, medical supplies, including vaccines and other perishable cargo. Commercial refrigeration solutions include refrigerated cabinets, freezers, systems and controls. Our commercial refrigeration equipment solutions incorporate next-generation technologies to preserve freshness, ensure safety and enhance the appearance of food and beverage retail. Our Refrigeration products and services are sold under established brand names, including Carrier Commercial Refrigeration, Carrier Transicold and Sensitech. Refrigeration products and services are sold directly, including to transportation companies and retail stores, and indirectly through equity method investees, independent sales representatives, distributors, wholesalers and dealers.

[0001783180-21-000011:mdna:138]
2020 Compared with 2019

[0001783180-21-000011:mdna:139]
| (dollars in millions) | 2020 |  | 2019 |  | Increase (Decrease) |  | % Increase (Decrease) |
| Net sales | $ | 3,333 |  |  | $ | 3,792 |  |  | $ | (459) |  |  | (12) | % |
| Operating profit | $ | 357 |  |  | $ | 532 |  |  | $ | (175) |  |  | (33) | % |

[0001783180-21-000011:mdna:140]
|  | Net sales |  | Operating profit |
| Organic / Operational | (12) | % |  | (29) | % |
| Foreign currency translation | — | % |  | 1 | % |
| Other | — | % |  | (5) | % |
| Total % change | (12) | % |  | (33) | % |

[0001783180-21-000011:mdna:141]
The organic sales decrease of 12% was driven by declines in transport refrigeration (14%) and commercial refrigeration (9%). The decline in transport refrigeration sales reflects lower sales volume in North America when compared with the cyclical peak experienced in 2019 and the economic slowdown resulting from COVID-19, and Europe truck trailer sales volume decreased due to COVID-19. Commercial refrigeration sales declined primarily due to lower demand and the closure of new equipment installation sites resulting from COVID-19.

[0001783180-21-000011:mdna:142]
The operational profit decrease of 29% was primarily attributed to lower sales volumes and unfavorable mix, increased selling, general and administrative costs, including higher costs associated with Carrier's transition to an independent publicly traded company, partially offset by favorable net material productivity.

[0001783180-21-000011:mdna:143]
The 5% decrease in Other primarily reflects the year-over-year impact of the absence of a $22 million gain on an expropriated plant in 2019.

[0001783180-21-000011:mdna:144]
2019 Compared with 2018

[0001783180-21-000011:mdna:145]
| (dollars in millions) | 2019 |  | 2018 |  | Increase (Decrease) |  | % Increase (Decrease) |
| Net sales | $ | 3,792 |  |  | $ | 4,095 |  |  | $ | (303) |  |  | (7) | % |
| Operating profit | $ | 532 |  |  | $ | 1,353 |  |  | $ | (821) |  |  | (61) | % |

[0001783180-21-000011:mdna:146]
|  | Net sales |  | Operating profit |
| Organic / Operational | (1) | % |  | — | % |
| Foreign currency translation | (3) | % |  | (1) | % |
| Acquisitions and divestitures, net | (3) |  |  | (2) | % |
| Other | — | % |  | (58) | % |
| Total % change | (7) | % |  | (61) | % |

[0001783180-21-000011:mdna:147]
The organic sales decrease of 1% was driven by declines in transport refrigeration sales (1%), primarily in the container business (9%) and declines in commercial refrigeration (1%), primarily in Europe, partially offset by growth in North America truck trailer (5%).

[0001783180-21-000011:mdna:148]
Organic operational profit was flat on lower sales due to favorable pricing.

[0001783180-21-000011:mdna:149]
The 58% decrease in Other primarily reflects the year-over-year impact of the absence of the prior year gain from the divestiture of Taylor.

[0001783180-21-000011:mdna:150]
Fire & Security

[0001783180-21-000011:mdna:151]
Our Fire & Security segment provides a wide range of residential, commercial and industrial technologies, and systems and service solutions to protect people and property, including fire, flame, gas, smoke and carbon monoxide detection; portable fire extinguishers; fire suppression systems; intruder alarms; access control systems and video management systems and electronic controls. Other Fire & Security service offerings include audit, design, installation and system integration, as well as aftermarket, maintenance and repair and monitoring services. Our established brands include Autronica, Chubb, Det-Tronics, Edwards, Fireye, GST, Kidde, LenelS2, Marioff, Onity and Supra. Our Fire & Security products and solutions, also part of Carrier's Healthy Homes and Healthy Buildings Program, are sold directly to end customers as well as through manufacturers’ representatives, distributors, dealers, value-added resellers and retail distribution. In addition, certain of our products are supported by installation, maintenance and monitoring through a network of channel partners and our field service business, along with web-based mobile applications and cloud-based services.

[0001783180-21-000011:mdna:152]
2020 Compared with 2019

[0001783180-21-000011:mdna:153]
| (dollars in millions) | 2020 |  | 2019 |  | Increase (Decrease) |  | % Increase (Decrease) |
| Net sales | $ | 4,985 |  |  | $ | 5,500 |  |  | $ | (515) |  |  | (9) | % |
| Operating profit | $ | 584 |  |  | $ | 708 |  |  | $ | (124) |  |  | (18) | % |

[0001783180-21-000011:mdna:154]
|  | Net Sales |  | Operating Profit |
| Organic / Operational | (9) | % |  | (22) | % |
| Foreign currency translation | — | % |  | 1 | % |
| Restructuring | — | % |  | 3 | % |
| Total % change | (9) | % |  | (18) | % |

[0001783180-21-000011:mdna:155]
The organic sales decrease of 9% reflects lower product (10%) and field service (9%) sales. The decline in product sales was primarily driven by lower volume in North America and EMEA resulting from COVID-19. Field service sales were down primarily in Europe and Asia reflecting the impact of business shutdowns and project delays resulting from COVID-19.

[0001783180-21-000011:mdna:156]
The operational profit decrease of 22% was primarily attributed to lower sales volumes and higher provisions for customer credit losses partially offset by favorable material productivity.

[0001783180-21-000011:mdna:157]
2019 Compared with 2018

[0001783180-21-000011:mdna:158]
| (dollars in millions) | 2019 |  | 2018 |  | Increase (Decrease) |  | % Increase (Decrease) |
| Net sales | $ | 5,500 |  |  | $ | 5,531 |  |  | $ | (31) |  |  | (1) | % |
| Operating profit | $ | 708 |  |  | $ | 726 |  |  | $ | (18) |  |  | (2) | % |

[0001783180-21-000011:mdna:159]
|  | Net Sales |  | Operating Profit |
| Organic / Operational | 1 | % |  | (2) | % |
| Foreign currency translation | (3) | % |  | (2) | % |
| Acquisitions and divestitures, net | 1 | % |  | 2 | % |
| Restructuring | — | % |  | (2) | % |
| Other | — | % |  | 2 | % |
| Total % change | (1) | % |  | (2) | % |

[0001783180-21-000011:mdna:160]
The organic sales increase of 1% was driven primarily by global growth in product sales (1%) and growth in field service (1%), primarily in Asia (5%).

[0001783180-21-000011:mdna:161]
The organic operational profit decrease of 2% was driven by unfavorable mix and investments in research and development.

[0001783180-21-000011:mdna:162]
45

[0001783180-21-000011:mdna:163]
The 2% increase in Other primarily reflects the absence of the prior year impact associated with a product recall matter.

[0001783180-21-000011:mdna:164]
Eliminations and other and General corporate expenses

[0001783180-21-000011:mdna:165]
|  | Net Sales |  | Operating Profit |
| (dollars in millions) | 2020 |  | 2019 |  | 2018 |  | 2020 |  | 2019 |  | 2018 |
| Eliminations and other | $ | (340) |  |  | $ | (396) |  |  | $ | (425) |  |  | $ | (184) |  |  | $ | (156) |  |  | $ | (24) |  |
| General corporate expenses | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | (136) |  |  | $ | (156) |  |  | $ | (138) |  |

[0001783180-21-000011:mdna:166]
2020 Compared with 2019

[0001783180-21-000011:mdna:167]
Eliminations and other reflects the elimination of sales, other income and operating profit resulting from activity between segments, net hedging and foreign exchange-related gains and losses, as well as other infrequently occurring items, such as divestiture transaction costs. In addition, Eliminations and other includes costs associated with the settlement and defense of potential future asbestos-related claims, insurance settlements on asbestos-related matters and revisions in the estimated liability for potential future asbestos-related claims. Inter-segment sales eliminations decreased for the year ended December 31, 2020 compared with 2019.

[0001783180-21-000011:mdna:168]
For the year ended December 31, 2020, the $28 million year-over-year decrease in operating profit in Eliminations and other, compared with 2019, was primarily attributed to $54 million in incremental separation-related costs and higher deferred compensation charges of $16 million partially offset by the absence of a $34 million charge incurred in 2019 related to the impact of a consultant contract termination.

[0001783180-21-000011:mdna:169]
General corporate expenses include allocations of corporate expenses from UTC prior to the Separation and the Distribution, which are not necessarily indicative of our future expenses and do not necessarily reflect the results that Carrier may experience as an independent company for the periods presented.

[0001783180-21-000011:mdna:170]
2019 Compared with 2018

[0001783180-21-000011:mdna:171]
The year-over-year decrease in sales eliminations for the year ended December 31, 2019 as compared with 2018 reflects a decrease in the amount of inter-segment eliminations.

[0001783180-21-000011:mdna:172]
The year-over-year change in operating profit within Eliminations and other for the year ended December 31, 2019 is primarily due to separation-related costs of $58 million, a $34 million charge related to the impact of a consultant contract termination and lower asbestos-related settlement gains of $31 million, partially offset by the absence of $15 million of divestiture transaction costs in 2018.

[0001783180-21-000011:mdna:173]
The year-over-year change in General corporate expenses for the year ended December 31, 2019 was primarily driven by higher general and administrative expenses.

[0001783180-21-000011:mdna:174]
LIQUIDITY AND FINANCIAL CONDITION

[0001783180-21-000011:mdna:175]
|  |  | As of December 31, |
| (dollars in millions) |  | 2020 |  | 2019 |
| Cash and cash equivalents |  | $ | 3,115 |  |  | $ | 952 |  |
| Total debt |  | $ | 10,227 |  |  | $ | 319 |  |
| Net debt (total debt less cash and cash equivalents) |  | $ | 7,112 |  |  | $ | (633) |  |
| Total Equity |  | $ | 6,578 |  |  | $ | 14,435 |  |
| Total capitalization (total debt plus total equity) |  | $ | 16,805 |  |  | $ | 14,754 |  |
| Net capitalization (total debt plus total equity less cash and cash equivalents) |  | $ | 13,690 |  |  | $ | 13,802 |  |
| Total debt to total capitalization |  | 61 | % |  | NM |
| Net debt to net capitalization |  | 52 | % |  | NM |

[0001783180-21-000011:mdna:176]
______________________

[0001783180-21-000011:mdna:177]
Not measurable ("NM") - Prior to the Separation and the Distribution, Carrier participated in UTC's centralized cash management and financing programs; as such, these metrics are neither meaningful nor comparable to those of Carrier as a stand-alone company. See Note 6 – Equity Method Investments and Related Parties in the accompanying Notes to the Consolidated Financial Statements for additional information on the UTC cash management programs.

[0001783180-21-000011:mdna:178]
Prior to the Separation and the Distribution, Carrier participated in UTC’s centralized cash pooling and financing programs. Historically, we independently generated operating cash flows sufficient to fund our working capital, capital expenditures and financing needs. Following the Separation and the Distribution, the capital structure and sources of liquidity for Carrier changed as Carrier no longer participates in cash management and financing programs with UTC. Instead, Carrier’s ability to fund our capital requirements depends on our ability to generate cash flows from operations. Following the Separation and the Distribution, Carrier has access to a $2.0 billion Revolving Credit Facility (defined subsequently) that supports a commercial paper borrowing program and anticipates continuing to have access to the debt capital markets. We believe that our future operating cash flows and anticipated access to capital will provide sufficient sources of liquidity over the next twelve months to meet our commitments, including the negative impact of COVID-19 on our business.

[0001783180-21-000011:mdna:179]
From time to time we may need to access the capital markets to obtain financing. Although we believe that the arrangements currently in place permit us to finance our operations on acceptable terms and conditions, our access to, and the availability of, financing on acceptable terms and conditions in the future will be impacted by many factors, including (1) our credit ratings or absence of credit ratings, (2) the liquidity of the overall capital markets and (3) the state of the economy, including the impact of COVID-19. There can be no assurance that we will be able to obtain additional financing on terms favorable to us, if at all.

[0001783180-21-000011:mdna:180]
Financing for operational and strategic requirements, not satisfied by operating cash flows, is subject to the availability of external funds through short-term and long-term credit markets. The access to and cost of financing is dependent upon, among other factors, the Company's credit ratings. The following table presents our credit ratings and outlook as of December 31, 2020.

[0001783180-21-000011:mdna:181]
| Rating Agency | Long-term Rating (1) | Short-term Rating |  | Outlook (2) |
| S&P | BBB | A2 |  | Negative |
| Moody's | Baa3 | P3 |  | Stable |
| Fitch Ratings | BBB- | F3 |  | Stable |

[0001783180-21-000011:mdna:182]
(1 )The long-term rating for S&P was affirmed on June 15, 2020, and for Moody's on June 16, 2020. Fitch Ratings' long-term rating was issued on June 11, 2020.

[0001783180-21-000011:mdna:183]
(2) S&P revised its outlook to negative from stable on June 15, 2020.

[0001783180-21-000011:mdna:184]
As of December 31, 2020, we had cash and cash equivalents of $3.1 billion, of which approximately 33% was held by Carrier’s foreign subsidiaries. We manage our worldwide cash requirements by reviewing available funds and the cost effectiveness with which those funds can be accessed if held by foreign subsidiaries. On occasion, we are required to maintain cash deposits in connection with contractual obligations related to acquisitions or divestitures or other legal obligations. As of December 31, 2020 and 2019, the amount of such restricted cash was approximately $4 million and $5 million, respectively.

[0001783180-21-000011:mdna:185]
Borrowings and Lines of Credit

[0001783180-21-000011:mdna:186]
Long-term debt consisted of the following:

[0001783180-21-000011:mdna:187]
| (dollars in million) |  |  |  | As of December 31, |  |
| Debt Description | Interest Rate |  |  | 2020 |  |  | 2019 |  |
| 1.923% Notes due February 15, 2023 | 1.923 | % |  |  | $ | 500 |  |  |  | $ | — |  |  |
| 2.242% Notes due February 15, 2025 | 2.242 | % |  |  | 2,000 |  |  |  | — |  |  |
| 2.493% Notes due February 15, 2027 | 2.493 | % |  |  | 1,250 |  |  |  | — |  |  |
| 2.722% Notes due February 15, 2030 | 2.722 | % |  |  | 2,000 |  |  |  | — |  |  |
| 2.700% Notes due February 15, 2031 | 2.700 | % |  |  | 750 |  |  |  | — |  |  |
| 3.377% Notes due April 5, 2040 | 3.377 | % |  |  | 1,500 |  |  |  | — |  |  |
| 3.577% Notes due April 5, 2050 | 3.577 | % |  |  | 2,000 |  |  |  | — |  |  |
| Other (including project financing obligations and finance leases) |  |  |  | 308 |  |  |  | 319 |  |  |
| Total principal long-term debt |  |  |  | 10,308 |  |  |  | 319 |  |  |
| Other (discounts and debt issuance costs) |  |  |  | (81) |  |  |  | — |  |  |
| Total debt |  |  |  | 10,227 |  |  |  | 319 |  |  |
| Less: current portion of long-term debt |  |  |  | 191 |  |  |  | 237 |  |  |
| Long-term debt, net of current portion |  |  |  | $ | 10,036 |  |  |  | $ | 82 |  |  |

[0001783180-21-000011:mdna:188]
On February 10, 2020, Carrier entered into a revolving credit agreement with various banks permitting aggregate borrowings of up to $2.0 billion pursuant to an unsecured, unsubordinated Revolving Credit Facility that matures on April 3, 2025 as amended, (the "Revolving Credit Facility"). A commitment fee of 0.125% is charged on the unused commitments. Borrowings under the Revolving Credit Facility are available in U.S. Dollars, Euros and Pounds Sterling and bear interest at a variable interest rate based on LIBOR plus a ratings-based margin, which was 125 basis points as of December 31, 2020. The Revolving Credit Facility supports our commercial paper program and cash requirements. As of December 31, 2020, there were no borrowings on the Revolving Credit Facility.

[0001783180-21-000011:mdna:189]
On February 10, 2020, Carrier entered into a term loan credit agreement providing for a $1.75 billion unsecured, unsubordinated term loan credit facility which matures on February 10, 2023 (as amended, the "Term Loan Credit Facility"). On March 27, 2020, Carrier drew the full $1.75 billion available, and in the three months ended December 31, 2020, we fully prepaid the $1.75 billion outstanding under the Term Loan Credit Facility. The Term Loan Credit Facility was subject to a variable interest rate based on LIBOR plus a ratings-based margin, which immediately prior to the repayment date in the three months ended December 31, 2020 was 112.5 basis points. In connection with the full prepayment of the Term Loan Credit Facility, the term loan credit agreement was terminated.

[0001783180-21-000011:mdna:190]
On February 27, 2020, Carrier issued $9.25 billion of unsecured, unsubordinated long-term fixed rate notes in six series with maturities ranging from 2023 through 2050. Carrier used the proceeds from such long-term fixed rate notes and the Term Loan Credit Facility to fund approximately $10.9 billion in distributions to UTC in connection with the Separation.

[0001783180-21-000011:mdna:191]
The revolving credit agreement and indenture contain affirmative and negative covenants customary for financings of this type, that among other things, limit Carrier and our subsidiaries' ability to incur additional liens, to make certain fundamental changes and to enter into sale and leaseback transactions. On June 2, 2020, the Company entered into an amendment of the Revolving Credit Facility. Pursuant to the amendment, certain terms of the Revolving Credit Facility were amended for a period beginning on June 2, 2020 and ending on December 30, 2021 (the "Covenant Modification Period"). The Company may terminate the Covenant Modification Period prior to December 30, 2021, subject to the satisfaction of certain conditions. The amendment defers testing of our consolidated total net leverage ratio financial covenant until June 30, 2021 and increases the consolidated total net leverage ratio limit until December 31, 2021. The amendment also requires us to maintain liquidity at a certain level until the earlier of (1) June 29, 2021 and (2) the last day of the Covenant Modification Period. Additionally, during the Covenant Modification Period, the Company is subject to (a) limitations on the incurrence of subsidiary indebtedness, (b) limitations on the making of restricted payments, including purchases by the Company of our ordinary shares and the amount of dividends the Company may pay, and (c) a "most favored nations" provision related to certain terms of any committed credit facility in an amount greater than $100 million. As of December 31, 2020, we were compliant with all covenants under the agreements governing our outstanding indebtedness.

[0001783180-21-000011:mdna:192]
On June 19, 2020, Carrier issued $750 million of unsecured, unsubordinated 2.700% Notes due in 2031. These notes rank equally with our other unsecured, unsubordinated obligations. We used the net proceeds from the sale of such notes, which further enhanced our liquidity and financial flexibility during the ongoing COVID-19 pandemic, for general corporate purposes.

[0001783180-21-000011:mdna:193]
As of December 31, 2020, we have a $2.0 billion unsecured, unsubordinated commercial paper program which we plan to use for general corporate purposes, including the funding of working capital and potential acquisitions. As of December 31, 2020, there were no borrowings outstanding under the commercial paper program.

[0001783180-21-000011:mdna:194]
Interest payments related to indebtedness are expected to approximate $291 million per year, reflecting an approximate weighted-average interest rate of 2.8%.

[0001783180-21-000011:mdna:195]
Share Repurchase Program

[0001783180-21-000011:mdna:196]
On February 4, 2021 the Company’s Board of Directors approved a stock repurchase program authorizing the repurchase of up to $350 million of the Company’s outstanding common stock. Share repurchases may take place from time to time, subject to market conditions and at the Company’s discretion in the open market or through one or more other public or private transactions.

[0001783180-21-000011:mdna:197]
Other

[0001783180-21-000011:mdna:198]
The funded status of our defined benefit pension plans is dependent upon many factors, including returns on invested assets, the level of market interest rates and actuarial mortality and other assumptions. We can contribute cash subject to applicable regulations. As of December 31, 2020, our qualified domestic defined benefit pension plans are approximately 109% funded on a projected benefit obligation basis, and we are not required to make additional contributions through the end of 2022. We expect to make total contributions of approximately $28 million to our global defined benefit pension plans in 2021. Contributions to our global defined benefit pension plans in 2021 are expected to meet or exceed the current funding requirements.

[0001783180-21-000011:mdna:199]
Cash Flows

[0001783180-21-000011:mdna:200]
|  |  | For the Year Ended December 31, |
| (dollars in millions) |  | 2020 |  | 2019 |  | 2018 |
| Cash provided by (used in): |  |  |  |  |  |  |
| Operating activities |  | $ | 1,692 |  |  | $ | 2,063 |  |  | $ | 2,055 |  |
| Investing activities |  | 1,106 |  |  | (259) |  |  | 415 |  |
| Financing activities |  | (681) |  |  | (1,982) |  |  | (2,627) |  |
| Effect of foreign exchange rate changes on cash and cash equivalents |  | 45 |  |  | 1 |  |  | (39) |  |
| Net increase (decrease) in cash and cash equivalents and restricted cash |  | $ | 2,162 |  |  | $ | (177) |  |  | $ | (196) |  |

[0001783180-21-000011:mdna:201]
Cash Flows - 2020 Compared with 2019

[0001783180-21-000011:mdna:202]
Cash provided by operating activities was $1.7 billion for the year ended December 31, 2020 compared with $2.1 billion for the year ended December 31, 2019. The $371 million year-over-year decrease in cash provided by operating activities was attributed to lower net income from operations, net of non-cash adjustments, partially offset by $446 million in cash provided from working capital due to the timing of vendor payments and income taxes.

[0001783180-21-000011:mdna:203]
Net cash provided by investing activities increased $1.4 billion in the year ended December 31, 2020 compared with the year ended December 31, 2019 due to the receipt of $1.4 billion from the sale of our equity ownership in Beijer.

[0001783180-21-000011:mdna:204]
Net cash used in financing activities decreased $1.3 billion in the year ended December 31, 2020 compared with the year ended December 31, 2019. Net transfers to UTC increased $8.4 billion due to the Separation and were funded by the issuance of $11.0 billion in long-term debt of which the $1.75 billion Term Loan Credit Facility was prepaid in the three months ended December 31, 2020. On June 19, 2020 Carrier issued $750 million in Notes due 2031 to enhance financial flexibility during COVID-19.

[0001783180-21-000011:mdna:205]
Cash Flows - 2019 Compared with 2018

[0001783180-21-000011:mdna:206]
Cash provided by operating activities was $2.1 billion for the year ended December 31, 2019 which was consistent with the $2.1 billion provided by operating activities in the year ended December 31, 2018.

[0001783180-21-000011:mdna:207]
Net cash used in investing activities decreased $674 million in the year ended December 31, 2019 compared with the year ended December 31, 2018 due to the absence of $1.0 billion in proceeds received from the 2018 sale of Taylor, partially offset by a $310 million decrease in cash outflows for acquisitions.

[0001783180-21-000011:mdna:208]
Prior to the Separation our financing activities primarily related to net transfers to UTC. Net cash used in financing activities decreased $645 million in the year ended December 31, 2019 compared with the year ended December 31, 2018 primarily due to a decrease in net transfers to UTC.

[0001783180-21-000011:mdna:209]
Off-Balance Sheet Arrangements and Contractual Obligations

[0001783180-21-000011:mdna:210]
We extend a variety of financial guarantees to third parties in support of our business. We also have obligations arising from environmental, health and safety, tax and employment matters. Circumstances that could cause the contingent obligations and liabilities arising from these arrangements to come to fruition include changes in an underlying transaction, non-performance under a contract or deterioration in the financial condition of the guaranteed party.

[0001783180-21-000011:mdna:211]
A summary of our contractual obligations and commitments as of December 31, 2020 is as follows:

[0001783180-21-000011:mdna:212]
| (dollars in millions) | Total |  | 2021 |  | 2022-2023 |  | 2024-2025 |  | Thereafter |
| Operating leases | $ | 939 |  |  | $ | 180 |  |  | $ | 279 |  |  | $ | 182 |  |  | $ | 298 |  |
| Purchase Obligations | 1,437 |  |  | 1,186 |  |  | 213 |  |  | 36 |  |  | 2 |  |
| Long-term debt - principal | 10,308 |  |  | 190 |  |  | 618 |  |  | 2,000 |  |  | 7,500 |  |
| Interest on long-term debt | 4,174 |  |  | 292 |  |  | 566 |  |  | 507 |  |  | 2,809 |  |
| Obligations to UTC under TMA | 453 |  |  | — |  |  | 70 |  |  | 208 |  |  | 175 |  |
| Other long-term liabilities | 1,223 |  |  | 255 |  |  | 254 |  |  | 158 |  |  | 556 |  |
| Total contractual obligations | $ | 18,534 |  |  | $ | 2,103 |  |  | $ | 2,000 |  |  | $ | 3,091 |  |  | $ | 11,340 |  |

[0001783180-21-000011:mdna:213]
Operating leases include amounts related to future contractual payments on our leases for land and buildings, vehicles and machinery and equipment.

[0001783180-21-000011:mdna:214]
Purchase obligations include amounts committed for the purchase of goods and services under legally enforceable contracts or purchase orders. Where it is not practically feasible to determine the legally enforceable portion of our obligation under certain of our long-term purchase agreements, we include additional expected purchase obligations beyond what may be legally enforceable.

[0001783180-21-000011:mdna:215]
Long-term debt includes current maturities, financing leases and obligations under project financing arrangements. See Note 12 – Borrowings and Lines of Credit in the accompanying Notes to the Consolidated Financial Statements.

[0001783180-21-000011:mdna:216]
Other long-term liabilities include liabilities representing obligations under product service and warranty policies, estimated environmental remediation costs and expected contributions and liabilities under employee benefit programs. The timing of expected cash flows associated with these obligations is based upon management’s estimates over the terms of these agreements and is largely based upon historical experience.

[0001783180-21-000011:mdna:217]
Obligations to UTC under the TMA include Carrier’s obligations to pay $453 million to UTC resulting from the TCJA's mandatory transition tax attributable to Carrier. This amount will be settled with UTC in five future payments, the next of which is scheduled in April 2022. See Note 19 - Income Taxes in the accompanying Notes to the Consolidated Financial Statements for additional information.

[0001783180-21-000011:mdna:218]
The previous table excludes the following:

[0001783180-21-000011:mdna:219]
•Unrecognized tax benefits of $162 million that have not been recognized in the Company's Consolidated Financial Statements. It is uncertain if or when these previously claimed tax benefits could become payable if challenged by a taxing authority. See Note 19 – Income Taxes in the accompanying Notes to the Consolidated Financial Statements for additional discussion on unrecognized tax benefits.

[0001783180-21-000011:mdna:220]
•The Company is self-insured for workers' compensation, general liability and group healthcare benefits. The Company's self-insurance reserve totaled $249 million and $239 million as of December 31, 2020 and 2019, respectively. Self-insurance liabilities are based on estimates and actuarial assumptions. The amount and timing of payments can fluctuate and for this reason, they are not included in the previous table.

[0001783180-21-000011:mdna:221]
•The Company's obligations under defined pension plans are based on estimates and actuarial assumptions that can fluctuate in amount and timing and for this reason, only contributions expected in 2021 are included in the previous table.
