# CARR 10-K controls and the auditor's report


## auditors_report

[0001783180-21-000011:auditors_report:1]
Report of Independent Registered Public Accounting Firm

[0001783180-21-000011:auditors_report:2]
To the Board of Directors and Shareowners of Carrier Global Corporation

[0001783180-21-000011:auditors_report:3]
Opinion on the Financial Statements

[0001783180-21-000011:auditors_report:4]
We have audited the accompanying consolidated balance sheet of Carrier Global Corporation and its subsidiaries (the “Company”) as of December 31, 2020 and 2019, and the related consolidated statements of operations, of comprehensive income, of changes in equity and of cash flows for each of the three years in the period ended December 31, 2020, including the related notes and schedule of valuation and qualifying accounts for each of the three years in the period ended December 31, 2020 appearing after Item 16 and signatures page (collectively referred to as the “consolidated financial statements”). In our opinion, the consolidated financial statements present fairly, in all material respects, the financial position of the Company as of December 31, 2020 and 2019, and the results of its operations and its cash flows for each of the three years in the period ended December 31, 2020 in conformity with accounting principles generally accepted in the United States of America.

[0001783180-21-000011:auditors_report:5]
Change in Accounting Principle

[0001783180-21-000011:auditors_report:6]
As discussed in Note 3 to the consolidated financial statements, the Company changed the manner in which it accounts for leases in 2019.

[0001783180-21-000011:auditors_report:7]
Basis for Opinion

[0001783180-21-000011:auditors_report:8]
These consolidated financial statements are the responsibility of the Company’s management. Our responsibility is to express an opinion on the Company’s consolidated financial statements based on our audits. We are a public accounting firm registered with the Public Company Accounting Oversight Board (United States) (PCAOB) and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0001783180-21-000011:auditors_report:9]
We conducted our audits of these consolidated financial statements in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audit to obtain reasonable assurance about whether the consolidated financial statements are free of material misstatement, whether due to error or fraud.

[0001783180-21-000011:auditors_report:10]
Our audits included performing procedures to assess the risks of material misstatement of the consolidated financial statements, whether due to error or fraud, and performing procedures that respond to those risks. Such procedures included examining, on a test basis, evidence regarding the amounts and disclosures in the consolidated financial statements. Our audits also included evaluating the accounting principles used and significant estimates made by management, as well as evaluating the overall presentation of the consolidated financial statements. We believe that our audits provide a reasonable basis for our opinion.

[0001783180-21-000011:auditors_report:11]
Critical Audit Matters

[0001783180-21-000011:auditors_report:12]
The critical audit matter communicated below is a matter arising from the current period audit of the consolidated financial statements that was communicated or required to be communicated to the audit committee and that (i) relates to accounts or disclosures that are material to the consolidated financial statements and (ii) involved our especially challenging, subjective, or complex judgments. The communication of critical audit matters does not alter in any way our opinion on the consolidated financial statements, taken as a whole, and we are not, by communicating the critical audit matter below, providing a separate opinion on the critical audit matter or on the accounts or disclosures to which it relates.

[0001783180-21-000011:auditors_report:13]
Goodwill Impairment Assessment – One Reporting Unit where the Excess of Fair Value over Carrying Value Was Approximately 13% at the Assessment Date

[0001783180-21-000011:auditors_report:14]
As described in Notes 3 and 10 to the consolidated financial statements, the Company’s total goodwill balance was $10.1 billion as of December 31, 2020 and the goodwill associated with one reporting unit where the excess of fair value over carrying value was approximately 13% at the assessment date was $917 million. Goodwill is tested annually for impairment as of July 1, or when a triggering event occurs that indicates the fair value of the reporting unit may have decreased below the

[0001783180-21-000011:auditors_report:15]
52

[0001783180-21-000011:auditors_report:16]
carrying value. If the carrying value of the reporting unit exceeds its estimated fair value, management records an impairment based on the difference between fair value and carrying value, not to exceed the total amount of goodwill allocated to the reporting unit. Management utilizes the discounted cash flow method under the income approach to estimate the fair value of the reporting units. The significant assumptions related to projected net sales, projected operating margins, working capital, capital expenditures, income tax rate, long-term growth rate and the discount rate.

[0001783180-21-000011:auditors_report:17]
The principal considerations for our determination that performing procedures relating to the goodwill impairment assessment of the one reporting unit is a critical audit matter are (i) the significant judgment by management when developing the fair value measurement of the reporting unit, (ii) a high degree of auditor judgment, subjectivity, and effort in performing procedures and evaluating management’s significant assumptions related to projected net sales, projected operating margins, long-term growth rate and the discount rate, and (iii) the audit effort involved the use of professionals with specialized skill and knowledge.

[0001783180-21-000011:auditors_report:18]
Addressing the matter involved performing procedures and evaluating audit evidence in connection with forming our overall opinion on the consolidated financial statements. These procedures included, among others (i) testing management’s process for developing the fair value measurement of the reporting unit; (ii) evaluating the appropriateness of the discounted cash flow method, (iii) testing the completeness and accuracy of underlying data used in the method, and (iv) evaluating the reasonableness of the significant assumptions used by management related to projected net sales, projected operating margins, long-term growth rate and the discount rate. Evaluating management’s assumptions related to projected net sales and projected operating margins involved evaluating whether the assumptions used by management were reasonable considering (i) the current and past performance of the reporting unit, (ii) the consistency with external market and industry data, and (iii) whether these assumptions were consistent with evidence obtained in other areas of the audit. Professionals with specialized skill and knowledge were used to assist in the evaluation of management’s discounted cash flow method and management’s significant assumptions related to the long-term growth rate and the discount rate.

[0001783180-21-000011:auditors_report:19]
/s/ PricewaterhouseCoopers LLP

[0001783180-21-000011:auditors_report:20]
Hallandale Beach, Florida

[0001783180-21-000011:auditors_report:21]
February 9, 2021

[0001783180-21-000011:auditors_report:22]
We have served as the Company's auditor since 2019.

[0001783180-21-000011:auditors_report:23]
53

[0001783180-21-000011:auditors_report:24]
CARRIER GLOBAL CORPORATION AND SUBSIDIARIES


## item_9a

[0001783180-21-000011:item_9a:1]
ITEM 9A. CONTROLS AND PROCEDURES

[0001783180-21-000011:item_9a:2]
Evaluation of Disclosure Controls and Procedures — We maintain a set of disclosure controls and procedures designed to ensure that information required to be disclosed by us in reports that we file or submit under the Exchange Act is recorded, processed, summarized and reported within the time periods specified in SEC rules and forms. These controls and procedures also give reasonable assurance that information required to be disclosed in such reports is accumulated and communicated to management to allow timely decisions regarding required disclosures.

[0001783180-21-000011:item_9a:3]
In accordance with Rule 13a-15(b) of the Exchange Act, management has conducted an evaluation, under the supervision and with the participation of the Chief Executive Officer ("CEO") and Chief Financial Officer ("CFO"), of the effectiveness of the design and operation of our disclosure controls and procedures as of December 31, 2020.

[0001783180-21-000011:item_9a:4]
Based on this evaluation, the CEO and CFO concluded that our disclosure controls and procedures were effective as of December 31, 2020.

[0001783180-21-000011:item_9a:5]
Management’s Report on Internal Control Over Financial Reporting — This Annual Report on Form 10-K does not include a report of management's assessment regarding internal control over financial reporting or an attestation of the Company's independent registered public accounting firm due to the transition period established by the rules of the SEC for newly created public companies.

[0001783180-21-000011:item_9a:6]
Changes in Internal Control Over Financial Reporting — There were no changes in our internal control over financial reporting for the three months ended December 31, 2020 that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.
