# CARR notes — 0001783180-21-000011


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001783180-21-000011:notes:1]
Part III hereof incorporates by reference portions of the Registrant's definitive proxy statement related to its 2021 annual meeting of shareowners.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001783180-21-000011:notes:2]
DESCRIPTION OF THE BUSINESS 
Carrier Global Corporation is a leading global provider of HVAC, refrigeration, and fire and security solutions. Carrier also provides a broad array of related building services, including audit, design, installation, system integration, repair, maintenance and monitoring.

[0001783180-21-000011:notes:3]
Carrier’s operations are classified into three segments: HVAC, Refrigeration and Fire & Security. The HVAC and Refrigeration segments sell their products and solutions directly, including to building contractors and owners, transportation companies and retail stores, or indirectly through joint venture and other minority-owned investments, independent sales representatives, distributors, wholesalers, dealers and retail outlets. These products and services are sold under the Carrier name and other brand names including Automated Logic, BluEdge, Bryant, CIAT, Day & Night, Heil, NORESCO, Riello, Carrier Commercial Refrigeration, Carrier Transicold, Sensitech and others. The Fire & Security segment sells their products directly to customers, or indirectly through manufacturers’ representatives, distributors, dealers, value-added resellers and retailers. Fire & Security’s products and services are used by governments, financial institutions, architects, building owners and developers, security and fire consultants, homeowners and other end-users requiring a high level of security and fire protection for their businesses and residences. These products and services are sold under brand names including Autronica, Chubb, Det-Tronics, Edwards, Fireye, GST, Kidde, LenelS2, Marioff, Onity, Supra and others.

[0001783180-21-000011:notes:4]
The Separation

[0001783180-21-000011:notes:5]
On November 26, 2018, UTC announced its intention to spin off Carrier, into a separate, publicly traded company. Carrier was incorporated in Delaware on March 19, 2019, as a wholly-owned subsidiary of UTC. On April 3, 2020, UTC completed the Separation through a pro rata distribution on a one-for-one basis of all of the outstanding common stock of the Company to UTC shareowners who held shares of UTC common stock as of the close of business on March 19, 2020, the record date for the Distribution. UTC distributed 866,158,910 shares of Carrier common stock in the Distribution, which was effective at 12:01 a.m., Eastern Time, on April 3, 2020. As a result of the Distribution, Carrier became an independent public company and our common stock is listed under the symbol "CARR" on the NYSE. In connection with the Separation, Carrier issued an aggregate principal balance of $11.0 billion of debt and transferred approximately $10.9 billion of cash to UTC on February 27, 2020 and March 27, 2020. On April 1, 2020 and April 2, 2020, Carrier received cash contributions totaling $590 million from UTC related to the Separation. See Note 12 – Borrowings and Lines of Credit and Note 4 – Earnings Per Share for additional information.

[0001783180-21-000011:notes:6]
In connection with the Separation and the Distribution, Carrier entered into several agreements with UTC and Otis, including a separation and distribution agreement that sets forth certain agreements with UTC and Otis regarding the principal actions to be taken in connection with the Separation and the Distribution, including identifying the assets transferred, the liabilities assumed and the contracts transferred to each of UTC, Otis and Carrier as part of the Separation and the Distribution, and when and how these transfers and assumptions occurred. Other agreements we entered into that govern aspects of our relationship with UTC and Otis following the Separation and the Distribution include:

[0001783180-21-000011:notes:7]
Transition Services Agreement. We entered into the TSA with UTC and Otis in connection with the Separation pursuant to which UTC provides us with certain services and we provide certain services to UTC for a limited time to help ensure an orderly transition following the Separation and the Distribution. The services we receive include, but are not limited to, information technology services, technical and engineering support, application support for operations, legal, payroll, finance, tax and accounting, general administrative services and other support services. The costs for these services historically were included in our operating results based on allocations from UTC and for the year ended December 31, 2020 were not materially different under the TSA from such costs historically. We do not expect any such costs to be materially different when these services are completely transitioned from UTC to Carrier.

[0001783180-21-000011:notes:8]
Tax Matters Agreement. We entered into the TMA with UTC and Otis that governs the parties’ respective rights, responsibilities and obligations with respect to tax matters (including responsibility for taxes, entitlement to refunds, allocation of tax attributes, preparation of tax returns, control of tax contests and other tax matters). Subject to certain exceptions set forth in the TMA, Carrier generally is responsible for federal, state and foreign taxes imposed on a separate return basis upon Carrier (or any of our subsidiaries) with respect to taxable periods (or portions thereof) that ended on or prior to the date of the Distribution. The TMA provides special rules that allocate responsibility for tax liabilities arising from a failure of the Separation transactions to qualify for tax-free treatment based on the reasons for such failure. The TMA also imposes restrictions on each of Carrier and Otis during the two-year period following the Distribution that are intended to prevent certain transactions from failing to qualify as transactions that are generally tax-free.

[0001783180-21-000011:notes:9]
Employee Matters Agreement and Intellectual Property Agreement. We entered into an employee matters agreement and intellectual property agreement with UTC and Otis in connection with the Separation.

[0001783180-21-000011:notes:10]
Impact of the COVID-19 Pandemic

[0001783180-21-000011:notes:11]
COVID-19 surfaced in late 2019 and has spread throughout the world. In March 2020, COVID-19 was declared a pandemic by the World Health Organization and a national emergency by the U.S. Government. The pandemic has negatively affected the U.S. and global economies, disrupted global supply chains and financial markets, resulted in significant travel restrictions, mandated facility closures and resulted in shelter-in-place orders.

[0001783180-21-000011:notes:12]
Carrier has taken and continues to take all prudent measures to protect the health and safety of our employees. In particular, we have implemented work-from-home requirements (where practical), social distancing and deep cleaning protocols at all of our facilities as well as travel restrictions, among other measures, which comply with applicable government regulations and guidance. We have also taken appropriate measures to work with our customers to minimize potential disruptions and to support the communities that we serve to address the challenges posed by the pandemic.

[0001783180-21-000011:notes:13]
The full extent of the impact of COVID-19 on our operational and financial performance will depend on future developments, including the duration and spread of the pandemic as well as any worsening or additional outbreaks of the pandemic, related containment and mitigation actions taken by the U.S. federal, state and local and international governments to prevent disease spread and the rollout of vaccines in the U.S. and internationally, including the effectiveness of such vaccines in preventing COVID-19 and the time it takes to vaccinate a sufficient percentage of the U.S. and global populations. The extent of the pandemic's impact on Carrier will also depend upon our employees' ability to work safely in our facilities and to be granted access to vaccines (including the time it takes for our employees to be vaccinated), our customers’ ability to continue to operate or to receive our products, our suppliers' ability to continue to supply us with products, and the level of activity and demand for the ultimate products and services of our customers or their customers.

[0001783180-21-000011:notes:14]
In early 2020, we temporarily closed or reduced production at manufacturing facilities in North America, Asia and Europe for safety reasons and in response to lower demand for our products. Our manufacturing operations have since resumed, measures have been enacted to scale capacity to demand and we continue to actively take steps to mitigate supply chain risk. We continue to apply appropriate safety measures and have not experienced any significant disruptions to our manufacturing operations. We also initiated return-to-work protocols at our non-manufacturing facilities where employees were previously working remotely.
We took preemptive actions in 2020 to preserve our liquidity and manage our cash flows to ensure we met our liquidity needs. Such actions included, but were not limited to, modifying the financial covenants in our revolving and term loan credit agreements and issuing $750 million of 2.700% Notes due 2031 (see Note 12 – Borrowings and Lines of Credit for additional information), reducing our discretionary spending, our capital investments and general and administrative costs by implementing pay freezes and cuts, employee furloughs and the suspension of non-critical hiring and participating in global COVID-19 relief measures.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001783180-21-000011:notes:15]
BASIS OF PRESENTATION 
The Consolidated Financial Statements have been prepared in accordance with GAAP and the accounting rules under Regulation S-X, as promulgated by the SEC.

[0001783180-21-000011:notes:16]
The Consolidated Financial Statements include the accounts of the Company and our wholly-owned and controlled majority-owned subsidiaries. All intra-company accounts and transactions have been eliminated. Related party transactions between the Company and our equity method investees have not been eliminated. Non-controlling interest represents the non-controlling investors’ interests in the results of subsidiaries that we control and consolidate.

[0001783180-21-000011:notes:17]
The Company's financial statements for periods prior to the Separation and the Distribution are prepared on a "carve-out" basis, as described subsequently. The Company's financial statements for the period commencing April 3, 2020 are consolidated based on the reported results of Carrier as a stand-alone company.

[0001783180-21-000011:notes:18]
Certain immaterial amounts presented have been reclassified to conform to the current period presentation, including the reclassification of the Current portion of long-term debt from Accrued liabilities and the reclassification of long-term debt from Other long-term liabilities for 2019 on the Consolidated Balance Sheet.

[0001783180-21-000011:notes:19]
Basis of Presentation Prior to the Separation and the Distribution

[0001783180-21-000011:notes:20]
Prior to the Separation and the Distribution, the Consolidated Financial Statements reflect the financial position, results of operations and cash flows of the Company for the periods presented as historically managed within UTC. For those periods prior to the Separation and the Distribution, the Consolidated Financial Statements are derived from the consolidated financial statements and accounting records of UTC.

[0001783180-21-000011:notes:21]
The Consolidated Statement of Operations includes all revenues and costs directly attributable to Carrier, including costs for facilities, functions and services used by Carrier. Costs for certain functions and services performed by UTC were directly charged to Carrier based on specific identification when possible or based on a reasonable allocation driver such as net sales, headcount, proportionate usage or other allocation methods. The results of operations include allocations of costs for administrative functions and services performed on behalf of Carrier by centralized groups within UTC and certain pension and other post-retirement benefit costs. See Note 6 – Equity Method Investments and Related Parties for a description of the allocation methodologies. All charges and allocations for facilities, functions and services performed by UTC have been deemed settled in cash by Carrier to UTC in the period in which the cost was recorded in the Consolidated Statement of Operations.

[0001783180-21-000011:notes:22]
UTC used a centralized approach to cash management and financing its operations. Accordingly, none of the cash, third-party debt or related interest expense of UTC has been allocated to Carrier in the Consolidated Financial Statements for the periods prior to the Separation and the Distribution. However, cash balances primarily associated with certain foreign entities that did not participate in UTC’s cash management program have been included in the Consolidated Financial Statements for periods prior to the Separation and the Distribution. Transactions between UTC and Carrier were deemed settled immediately through UTC’s Net investment, other than those transactions which have historically been cash-settled and which are reflected in the Consolidated Balance Sheet within Accounts receivable, net and Accounts payable. The net effect of the deemed settled transactions is reflected in the Consolidated Statement of Cash Flows as Net transfers to UTC within financing activities and in the Consolidated Balance Sheet as UTC’s Net investment. See Note 6 – Equity Method Investments and Related Parties for additional information.

[0001783180-21-000011:notes:23]
All of the allocations and estimates in the Consolidated Financial Statements are based on assumptions that management believes are reasonable. However, for the periods prior to the Separation and the Distribution, the Consolidated Financial Statements included herein may not be indicative of the financial position, results of operations and cash flows of the Company in the future, or if the Company had been a separate, stand-alone entity during the periods presented.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001783180-21-000011:notes:24]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES
Principles of Consolidation. The Consolidated Financial Statements have been prepared on a stand-alone basis and include the accounts of Carrier and our wholly-owned subsidiaries, as well as entities in which Carrier has a controlling financial interest.

[0001783180-21-000011:notes:25]
Use of Estimates. The preparation of the Consolidated Financial Statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities. In addition, estimates and assumptions may impact the disclosure of contingent assets and liabilities at the date of the financial statements, as well as the reported amounts of revenues and expenses during the reporting period. Actual results could differ from those estimates.

[0001783180-21-000011:notes:26]
Cash and Cash Equivalents. Cash and cash equivalents include cash on hand, demand deposits and short-term cash investments that are highly liquid in nature and have original maturities of three months or less. Prior to the Separation and the Distribution, the Company participated in UTC’s centralized cash management and financing programs. See Note 6 – Equity Method Investments and Related Parties for additional information.

[0001783180-21-000011:notes:27]
On occasion, the Company is required to maintain restricted cash deposits with certain banks due to contractual or other legal obligations. Restricted cash of $4 million and $4 million is included in Other assets, current as of December 31, 2020 and 2019, respectively, and $1 million is included in Other assets as of December 31, 2019, on the Consolidated Balance Sheet.

[0001783180-21-000011:notes:28]
Accounts Receivable. Accounts receivable consist of billed amounts to customers that have not been paid.

[0001783180-21-000011:notes:29]
Receivables are recognized net of an allowance for credit losses. The Company is exposed to credit losses primarily through the sales of products and services to commercial customers, which are recorded as trade receivables. We evaluate a customer’s ability to pay by assessing creditworthiness, historical experience and current and projected economic and market conditions. We determine credit ratings for each customer in our portfolio based upon public information and information obtained directly from our customers. We evaluate the reasonableness of the allowance for credit losses on a quarterly basis or when events and circumstances warrant. In addition to credit quality indicators, factors considered in our evaluation of collectability include the underlying value of any collateral or security interests, past due balances, historical losses and existing economic conditions including country and political risk. In certain circumstances, we may require collateral or prepayment to mitigate credit risk. We determine receivables are impaired when, based on historical experience, current information and events and a reasonable forecast period, we may be unable to collect amounts due according to the contractual terms of an agreement. Estimated credit losses are written off in the period in which an accounts receivable is determined to be no longer collectible.

[0001783180-21-000011:notes:30]
Contract Assets and Liabilities. Contract assets and liabilities represent the difference in the timing of revenue recognition from receipt of cash from our customers. Contract assets (unbilled receivables) reflect revenue recognized and performance obligations satisfied in advance of customer billing. Performance obligations partially satisfied in advance of customer billings are included in Contract assets.

[0001783180-21-000011:notes:31]
Contract liabilities relate to payments received in advance of the satisfaction of performance obligations under a contract. The Company receives payments from customers based on contractual terms. See Note 5 – Revenue Recognition for additional information.

[0001783180-21-000011:notes:32]
Inventories. Inventories are stated at the lower of cost or estimated realizable value. Cost is primarily determined based on the first-in, first-out inventory method ("FIFO") or average cost methods, which approximates current replacement cost; however, certain Carrier entities use the last-in, first-out inventory method ("LIFO"). If inventories that were valued using the LIFO method had been valued under the FIFO method, the net book value of the inventories would have been higher by $118 million and $120 million as of December 31, 2020 and 2019, respectively. As of December 31, 2020 and 2019, approximately 33% and 32%, respectively, of all inventory utilized the LIFO method.

[0001783180-21-000011:notes:33]
We forecast future customer demand and production requirements and analyze historical usage rates for our products to estimate excess and obsolete inventory reserves.

[0001783180-21-000011:notes:34]
Financial Instruments. We use derivative financial instruments in the form of foreign currency forward contracts to manage certain foreign currency risk. Derivative financial instruments are recognized as either assets or liabilities at fair value and changes in fair value are reported directly in earnings. Derivative instruments are not used for trading or speculative

[0001783180-21-000011:notes:35]
purposes. A portion of our Cash and cash equivalents is invested in money market mutual funds with original maturities of three months or less.

[0001783180-21-000011:notes:36]
Fair Value of Financial Instruments. The fair value hierarchy is based on inputs to valuation techniques that are used to measure fair value that are either observable or unobservable. Observable inputs reflect assumptions market participants would use in pricing an asset or liability based on market data obtained from independent sources, while unobservable inputs reflect a reporting entity’s pricing based upon their own market assumptions. The fair value hierarchy consists of the following three levels:

[0001783180-21-000011:notes:37]
•Level I – Quoted prices for identical instruments in active markets.

[0001783180-21-000011:notes:38]
•Level II – Quoted prices for similar instruments in active markets; quoted prices for identical or similar instruments in markets that are not active; and model-derived valuations whose inputs are observable or whose significant value drivers are observable.

[0001783180-21-000011:notes:39]
•Level III – Instruments whose significant value drivers are unobservable.

[0001783180-21-000011:notes:40]
The carrying amount of accounts receivable, accounts payable and accrued liabilities approximates fair value due to the short maturity (less than one year) of the instruments.

[0001783180-21-000011:notes:41]
Equity Method Investments. Investments in which Carrier has the ability to exercise significant influence, but does not control, are accounted for under the equity method of accounting and are presented on the Consolidated Balance Sheet. Under this method of accounting, the Company’s share of the net earnings or losses of the investee is presented within Operating profit on the Consolidated Statement of Operations since the activities of the investee are closely aligned with the operations of the Company. The Company evaluates our equity method investments whenever events or changes in circumstance indicate that the carrying amounts of such investments may be impaired. If a decline in the value of an equity method investment is determined to be other than temporary, a loss is recorded in earnings in the current period. Distributions received from equity method investees are presented in the Consolidated Statement of Cash Flows based on the cumulative earnings approach.

[0001783180-21-000011:notes:42]
Goodwill and Intangible Assets. Goodwill represents costs in excess of fair values assigned to the underlying net assets of acquired businesses. Goodwill and intangible assets deemed to have indefinite lives are not amortized.

[0001783180-21-000011:notes:43]
Intangible assets consist of trademarks, patents, service contracts, monitoring lines and customer relationships and are recognized at fair value in acquisition accounting and then amortized to cost of sales and selling, general and administrative expenses.

[0001783180-21-000011:notes:44]
Goodwill and indefinite-lived intangible assets are tested annually for impairment, or when a triggering event occurs that indicates the fair value of a reporting unit or asset may have decreased below the carrying value in accordance with Financial Accounting Standards Board ("FASB") Accounting Standards Codification ("ASC") Topic 350: Intangibles – Goodwill and Other. The impairment assessment compares the estimated fair value of each reporting unit or indefinite-lived trademark to its associated carrying value. If the carrying value of the reporting unit or trademark exceeds its estimated fair value, then we record an impairment based on the difference between fair value and carrying value. In the case of reporting units, any impairment loss would not exceed the associated carrying value of goodwill.

[0001783180-21-000011:notes:45]
We performed our annual impairment assessment of goodwill and indefinite-lived trademarks as of July 1, 2020. For our goodwill impairment analysis, we utilize a discounted cash flow method under the income approach to estimate the fair value of our reporting units. The discounted cash flow method relies on estimates of future cash flows and expressly addressed factors such as timing, growth and margins, with consideration given to forecasting risk. We developed these assumptions based on market and geographic risks unique to each reporting unit. The significant assumptions inherent in estimating the fair values include estimated future annual net cash flows for each reporting unit (based on projected net sales, projected operating margins, working capital and capital expenditures), income tax rates, long-term growth rates and discount rates. For our indefinite-lived assets, fair value is determined on a relief from royalty methodology, which is based on the implied royalty paid, at an appropriate discount rate, to license the use of an asset rather than owning an asset. Additionally, as part of our annual impairment testing in 2020, we considered the impact of the adverse effects of COVID-19 on the global economy and on our business.

[0001783180-21-000011:notes:46]
Useful lives of finite-lived intangible assets are estimated based upon the nature of the intangible asset. These intangible assets are amortized based on the pattern in which the economic benefits of the intangible assets are consumed. If a pattern of

[0001783180-21-000011:notes:47]
economic benefit cannot be reliably determined or if straight-line amortization approximates the pattern of economic benefit, a straight-line amortization method may be used.

[0001783180-21-000011:notes:48]
See Note 10 – Business Acquisitions, Dispositions, Goodwill and Intangible Assets for additional information.

[0001783180-21-000011:notes:49]
Leases. We account for leases in accordance with ASC Topic 842: Leases, which requires a lessee to utilize the right-of-use model and to record a right-of-use asset and a lease liability on the Consolidated Balance Sheet for all leases with terms longer than 12 months. Leases are classified as either financing or operating, with classification affecting the pattern of expense recognition in the Consolidated Statement of Operations. In addition, a lessor is required to classify leases as either sales-type, financing or operating. A lease will be treated as a sale if it transfers all of the risks and rewards, as well as control of the underlying asset, to the lessee. If risks and rewards are conveyed without the transfer of control, the lease is treated as financing. If the lessor does not convey risk and rewards or control, the lease is treated as operating.

[0001783180-21-000011:notes:50]
We enter into operating and finance leases for the use of real estate space, vehicles, information technology equipment and certain other equipment. We determine if an arrangement contains a lease at the inception of an agreement. Operating leases are included in Operating lease right-of-use assets, Accrued liabilities and Operating lease liabilities in our Consolidated Balance Sheet. Finance leases are included in the Current portion of long-term debt and Long-term debt in our Consolidated Balance Sheet as of December 31, 2020 and 2019, respectively.

[0001783180-21-000011:notes:51]
Right-of-use assets represent our right to use an underlying asset for the lease term and lease liabilities represent our obligation to make lease payments over the lease term. Lease right-of-use assets and liabilities at commencement are initially measured at the present value of lease payments over the lease term. We generally use our incremental borrowing rate based on the information available at commencement to determine the present value of lease payments except when an implicit interest rate is readily determinable. We determine our incremental borrowing rate based on market sources including relevant industry data. Our lease right-of-use assets include any lease prepayment and exclude lease incentives. Our leases generally have remaining lease terms of 1 to 20 years, some of which include options to extend. For the majority of our leases with options to extend, those options are up to 5 years with the ability to terminate the lease within 1 to 5 years of inception. The exercise of lease renewal options is at our sole discretion and our lease right-of-use assets and liabilities reflect only the options we are reasonably certain that we will exercise. Operating lease expense is recognized on a straight-line basis over the lease term.

[0001783180-21-000011:notes:52]
Other Long-Lived Assets. The Company evaluates the potential impairment of other long-lived assets whenever events or changes in circumstances indicate that the related carrying amounts of a long-lived asset or asset group may not be recoverable. The carrying value of a long-lived asset or asset group is considered impaired when the projected future undiscounted cash flows to be generated from the asset or asset group over its remaining depreciable life are less than its current carrying value. The Company measures impairment based on the amount by which the carrying value exceeds the estimated fair value of the long-lived asset or asset group. There were no significant impairments of long-lived assets for the years ended December 31, 2020, 2019 or 2018.

[0001783180-21-000011:notes:53]
Income Taxes. Prior to the Separation and the Distribution, income taxes as presented in the Consolidated Financial Statements of the Company attribute current and deferred income taxes of UTC to the Company’s financial statements in a manner that is systematic, rational and consistent with the asset and liability method prescribed by FASB ASC Topic 740: Income Taxes. Accordingly, Carrier’s income tax provision was prepared following the separate return method prior to the Separation and the Distribution. The separate return method applies ASC 740 to the financial statements of each member of the consolidated group as if the group members were separate taxpayers. The calculation of our income taxes on a separate return basis requires a considerable amount of judgment and use of both estimates and allocations. As a result, actual transactions included in the consolidated financial statements of UTC may not be included in Carrier's Consolidated Financial Statements. Similarly, the tax treatment of certain items reflected in Carrier's Consolidated Financial Statements may not be reflected in the consolidated financial statements and tax returns of UTC. Therefore, such items as net operating losses, tax credit carry-forwards and valuation allowances may exist in Carrier's financial statements that may or may not exist in UTC’s consolidated financial statements. As such, the income taxes of the Company as presented in the Consolidated Financial Statements before the Separation and the Distribution may not be indicative of the income taxes that the Company will generate in the future.

[0001783180-21-000011:notes:54]
Prior to the Separation and the Distribution, certain operations of the Company have historically been included in a consolidated return with other UTC entities. Current obligations for taxes in certain jurisdictions, where the Company files a consolidated tax return with UTC, were deemed settled with UTC for purposes of the Consolidated Financial Statements. Current tax obligations in jurisdictions where the Company does not file a consolidated return with UTC, including certain foreign jurisdictions and certain U.S. states, are recorded as accrued liabilities.

[0001783180-21-000011:notes:55]
After the Separation and the Distribution, the Company’s income taxes were accounted for on a stand-alone basis. As a result, our deferred tax balances and effective tax rate as a stand-alone entity are significantly different from those recognized historically for periods prior to the Separation and the Distribution. Carrier will file our own consolidated U.S. federal and state income tax returns for the period subsequent to the Separation and the Distribution, April 3, 2020 through December 31, 2020, and any required filings for non-U.S. jurisdictions based on the applicable tax year in each jurisdiction. We account for income taxes under the asset and liability method, which requires the recognition of deferred tax assets and liabilities for the expected future tax consequences of events that have been included in the Consolidated Financial Statements. Under this method, deferred tax assets and liabilities are determined based on the differences between the financial statements and the tax basis of assets and liabilities using enacted tax rates in effect for the year in which the differences are expected to reverse. The effect of a change in tax rates on deferred tax assets and liabilities is recognized in income in the period that includes the enactment date. Changes in existing tax laws and rates, their related interpretations, and the uncertainty generated by the current economic environment may affect the amounts of deferred tax liabilities or the valuations of deferred tax assets over time. We record net deferred tax assets to the extent we believe these assets will more likely than not be realized. In making such a determination, we consider all available positive and negative evidence, including future reversals of existing taxable temporary differences, projected future taxable income, tax-planning strategies, and results of recent operations. In the event that we determine that we would be able to realize our deferred income tax assets in the future in excess of the net recorded amount, we would make an adjustment to the deferred tax asset valuation allowance, which impacts the provision for income taxes.

[0001783180-21-000011:notes:56]
In the ordinary course of business, there is inherent uncertainty in quantifying income tax positions. The Company assesses our income tax positions and records tax benefits for all years subject to examination based upon management’s evaluation of the facts, circumstances and information available. For those tax positions where it is more-likely-than-not that a tax benefit will be sustained, Carrier has recorded the amount of tax benefit with a greater than 50% likelihood of being realized upon ultimate settlement with a taxing authority that has full knowledge of all relevant information. For those income tax positions where it is not more-likely-than-not that a tax benefit will be sustained, no tax benefit has been recognized. Where applicable, associated interest expense has also been recognized. The Company recognizes accrued interest related to unrecognized tax benefits in interest expense. Penalties, if incurred, would be recognized as a component of income tax expense. See Note 19 – Income Taxes for further information.

[0001783180-21-000011:notes:57]
The TCJA subjects Carrier to a tax on global intangible low-taxed income ("GILTI"). GILTI is a tax on foreign income in excess of a deemed return on tangible assets of foreign corporations which the Company has elected to account for as a period cost.

[0001783180-21-000011:notes:58]
Revenue Recognition. The Company accounts for revenue in accordance with FASB ASC Topic 606: Revenue from Contracts with Customers. Under Topic 606, a performance obligation is a promise in a contract to transfer a distinct good or service to a customer. Some of our contracts with customers contain a single performance obligation, while others contain multiple performance obligations most commonly when a contract spans multiple phases of a product life-cycle such as production, installation, maintenance and support. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. When there are multiple performance obligations within a contract, the Company allocates the transaction price to each performance obligation based on our relative stand-alone selling price.

[0001783180-21-000011:notes:59]
Carrier considers the contractual consideration payable by the customer and assesses variable consideration that may affect the total transaction price, including contractual discounts, price concessions, contract incentive payments, estimates of award fees and other sources of variable consideration, when determining the transaction price of each contract. The Company includes variable consideration in the estimated transaction price when there is a basis to reasonably estimate the amount. These estimates are based on historical experience, anticipated performance and management's judgment. The Company also considers whether the contracts provide customers with significant financing. Generally, contracts do not contain significant financing.

[0001783180-21-000011:notes:60]
Point in time revenue recognition. Performance obligations are satisfied as of a point in time for certain businesses in HVAC, certain refrigeration systems and certain alarm and fire detection and suppression systems. Revenue is recognized when control of the product transfers to the customer, generally upon product shipment.

[0001783180-21-000011:notes:61]
Over-time revenue recognition. Performance obligations are satisfied over-time if the customer receives the benefits as the Company performs work, if the customer controls the asset as it is being produced or if the product being produced for the customer has no alternative use and the Company has a contractual right to payment. Carrier recognizes revenue on an over-

[0001783180-21-000011:notes:62]
time basis on installation and service contracts related to our Refrigeration and Fire & Security businesses as well as certain businesses within HVAC. For over-time performance obligations requiring the installation of equipment, revenue is recognized using costs incurred to date relative to total estimated costs at completion to measure progress. Incurred costs represent work performed, which correspond with and best depict transfer of control to the customer. Contract costs include labor, materials and subcontractors’ costs, or other direct costs, and where applicable, indirect costs.

[0001783180-21-000011:notes:63]
Contract modifications that are for goods or services that are not distinct are accounted for as part of an existing contract. If the goods or services are considered distinct, then a contract modification would be accounted for prospectively or as part of a new contract. The Company reviews cost estimates on significant contracts on at least a quarterly basis, and for other contracts, no less frequently than annually or when circumstances change and warrant a modification to a previous estimate. The Company records changes in contract estimates using the cumulative catch-up method. There were no material changes in contract estimates during the periods presented in the Consolidated Financial Statements.

[0001783180-21-000011:notes:64]
Loss provisions on contracts are recognized to the extent that estimated contract costs exceed the estimated consideration under the contractual arrangement. For new commitments, the Company generally records loss provisions at the earlier of contract announcement or contract signing except for certain requirements contracts under which losses are recorded upon receipt of the purchase order which obligates us to perform. For existing commitments, anticipated losses on contracts are recognized in the period in which losses become evident. Products contemplated under contractual arrangements include firm quantities of products sold under contract.

[0001783180-21-000011:notes:65]
Cash Payments to Customers. Carrier customarily offers our customers incentives to purchase products to ensure an adequate supply of our products in distribution channels. The principal incentive programs provide reimbursements to distributors for offering promotional pricing for products. The Company accounts for estimated incentive payments as a reduction in sales at the time a sale is recognized.

[0001783180-21-000011:notes:66]
Self-Insurance. The Company maintains self-insurance retentions for a number of risks, including but not limited to, workers’ compensation, general liability, automobile liability, property and employee-related healthcare benefits. It has obtained insurance coverage for amounts exceeding individual and aggregate loss limits. The Company accrues for known future claims and incurred but not reported losses. See Note 25 – Commitments and Contingent Liabilities for additional information.

[0001783180-21-000011:notes:67]
Environmental. Environmental investigatory, remediation, operating and maintenance costs are accrued when it is probable that a liability has been incurred and the amount can be reasonably estimated. The most likely cost to be incurred is accrued based on an evaluation of currently available facts with respect to individual sites, including the technology required to remediate, current laws and regulations and prior remediation experience. Where no amount within a range of estimates is more likely, the minimum is accrued. For sites with multiple responsible parties, the Company considers our likely proportionate share of the anticipated remediation costs and the ability of other parties to fulfill their obligations in establishing a provision for those costs. Environmental liabilities are undiscounted. Accrued environmental liabilities are not reduced by potential insurance reimbursements. See Note 25 – Commitments and Contingent Liabilities for additional information.

[0001783180-21-000011:notes:68]
Asbestos Related Liabilities and Insurance Recoveries. The Company records an undiscounted liability for any asbestos related contingency that is probable of occurrence and reasonably estimable. In connection with the recognition of liabilities for asbestos related matters, the Company records asbestos related insurance recoveries that are deemed probable. The amounts recorded by Carrier for asbestos-related liabilities and insurance recoveries are based on currently available information and assumptions that management believes are reasonable. Carrier’s actual liabilities or insurance recoveries could be higher or lower than those recorded if actual results vary significantly from our assumptions. The key assumptions include the number and type of new claims expected to be filed each year, the outcomes or resolution of such claims, the average cost of resolution of each new claim, the amount of insurance available, allocation methodologies, the contractual terms with each insurer with whom the Company has reached settlements, the resolution of coverage issues with other excess insurance carriers with whom the Company has not yet achieved settlements and the solvency risk with respect to Carrier’s insurance carriers. Other factors that may affect future liability include uncertainties surrounding the litigation process from jurisdiction to jurisdiction and from case to case, legal rulings that may be made by state and federal courts and the passage of state or federal legislation. Legal fees incurred to defend asbestos-related legal claims are expensed when incurred. See Note 25 – Commitments and Contingent Liabilities for additional information.

[0001783180-21-000011:notes:69]
Asset Retirement Obligations. The Company records the fair value of legal obligations associated with the retirement of tangible long-lived assets in the period in which a liability is determined to exist, if a reasonable estimate of fair value can be

[0001783180-21-000011:notes:70]
made. Upon initial recognition of a liability, the Company capitalizes the cost of the asset retirement obligation by increasing the carrying amount of the related long-lived asset. Over time, the liability is increased for changes in its present value and the capitalized cost is depreciated over the useful life of the related asset. As of December 31, 2020 and 2019, the outstanding liability for asset retirement obligations was $76 million and $74 million, respectively, which is included in Other long-term liabilities in the Consolidated Balance Sheet.

[0001783180-21-000011:notes:71]
Foreign Exchange. The Company operates in many countries and transacts in various foreign currencies and, accordingly, is subject to the inherent risks associated with foreign exchange rate movements. The financial position and results of operations of substantially all of the Company are measured using the local currency as the functional currency. Foreign currency denominated assets and liabilities are translated into U.S. dollars at the exchange rates existing at the respective balance sheet dates, and income and expense items are translated at the average exchange rates during the respective periods.

[0001783180-21-000011:notes:72]
Pension and Post-retirement Obligations. Guidance under FASB ASC Topic 715: Compensation – Retirement Benefits

[0001783180-21-000011:notes:73]
requires balance sheet recognition of the overfunded or underfunded status of pension and post-retirement benefit plans. Actuarial gains and losses, prior service costs or credits and any remaining transition assets or obligations that have not previously been recognized must be recognized in other comprehensive income, net of tax effects, until they are amortized as a component of net periodic benefit cost. Pension and post-retirement obligation balances and related costs reflected within the Consolidated Financial Statements include both costs directly attributable to plans dedicated to Carrier, as well as an allocation of costs for Carrier employees’ participation in UTC’s plans for periods prior to the Separation and the Distribution. See Note 13 – Employee Benefit Plans for further information.

[0001783180-21-000011:notes:74]
Product Performance Obligations. The Company extends performance and operating cost guarantees beyond normal service and warranty policies for extended periods on some of the Company’s products. The liabilities under such guarantees are based upon future product performance and durability and the Company records such costs that are probable and can be reasonably estimated within Cost of products sold. Separately priced extended warranties are recorded within contract liabilities. In addition, the Company incurs costs to service our products in connection with product performance issues. The costs associated with these product performance and operating cost guarantees require estimates over the term of an agreement and require management to consider factors such as the extent of future maintenance requirements and the future cost of material and labor to perform the services. These cost estimates are largely based upon historical experience. See Note 23 – Guarantees for additional information.

[0001783180-21-000011:notes:75]
Carrier accrues for costs associated with guarantees when it is probable that a liability has been incurred and the amount can be reasonably estimated. The most likely cost to be incurred is accrued based on an evaluation of currently available facts, and where no amount within a range of estimates is more likely, the minimum is accrued. In accordance with FASB ASC Topic 460-10: Guarantees, the Company records these liabilities at fair value.

[0001783180-21-000011:notes:76]
Research and Development. Research and development costs are charged to expense as incurred. Research and development costs were $419 million, $401 million and $400 million, which represented 2.4%, 2.2% and 2.1% of net sales, for the years ended December 31, 2020, 2019 and 2018, respectively.

[0001783180-21-000011:notes:77]
UTC Net Investment. UTC’s net investment in the Company is presented as "UTC Net investment" on the Consolidated Balance Sheet for periods prior to the Separation and the Distribution. The Consolidated Statement of Changes in Equity includes net cash transfers and other property transfers between UTC and the Company as well as related party receivables and payables between the Company and other UTC affiliates that were settled on a current basis. Prior to the Separation and the Distribution, UTC performed cash management and other treasury-related functions on a centralized basis for nearly all of its legal entities including the Company and, consequently, the net cash generated by the Company was transferred to UTC through inter-company accounts.

[0001783180-21-000011:notes:78]
Recent Pronouncements

[0001783180-21-000011:notes:79]
Recently Adopted Accounting Pronouncements and SEC Rules

[0001783180-21-000011:notes:80]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842) requiring recognition of operating leases as right-of-use assets and lease liabilities on the balance sheet and disclosure of key information about leasing arrangements. We adopted ASU 2016-02 and its related amendments (collectively, the "New Lease Accounting Standard") effective January 1, 2019, and elected the modified retrospective approach in which results for periods before 2019 were not adjusted for the new standard and the cumulative effect of the change in accounting was recognized through retained earnings at the date of adoption. We have elected certain of the practical expedients available under the New Lease Accounting Standard including the practical expedient which allows prospective transition to the New Lease Accounting Standard on January 1, 2019. Under the transition practical expedient, we did not reassess lease classification, embedded leases or initial direct costs. We have applied the practical expedient for short-term leases, whereby a lease right-of-use asset and liability is not recognized and the expense is recognized on a straight-line basis over the lease term. In addition, we have lease agreements with lease and non-lease components, for which we have elected the practical expedients to combine these components for certain equipment leases. Additionally, for certain equipment leases, we apply a portfolio approach to effectively account for the operating lease right-of-use assets and liabilities. The adoption of the New Lease Accounting Standard did not have a material effect on our Consolidated Statement of Operations or Consolidated Statement of Cash Flows. Upon adoption, we recorded an $894 million right-of-use asset and a $901 million lease liability. The adoption of the New Lease Accounting Standard did not have a material impact on UTC Net Investment. See Note 22 – Leases for further information.

[0001783180-21-000011:notes:81]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments. This ASU and its related amendments (collectively, the "Credit Loss Standard") modified the credit loss model to utilize an expected loss methodology in place of an incurred loss methodology for financial instruments, including trade receivables, contract assets, long term receivables and off-balance sheet credit exposures. The Credit Loss Standard requires consideration of a broader range of information to estimate expected credit losses, including historical information, current conditions and a reasonable forecast period. This ASU requires that the statement of operations reflect the measurement of credit losses for newly recognized financial assets as well as an expected increase or decrease of expected credit losses that have taken place during the period, which may result in earlier recognition. The Company adopted the Credit Loss Standard effective January 1, 2020, utilizing a modified retrospective approach and its adoption did not have a material impact on the Consolidated Financial Statements.

[0001783180-21-000011:notes:82]
In October 2016, the FASB issued ASU 2016-16, Income Taxes (Topic 740): Intra-Entity Transfers of Assets Other Than Inventory. This ASU requires the income tax consequences of an intra-entity transfer of an asset, other than inventory, to be recognized when the transfer occurs. Two common examples of assets included in the scope of this update are intellectual property and property, plant and equipment. Carrier adopted the new standard effective January 1, 2018. The adoption of this standard did not have a material impact on the Consolidated Financial Statements.

[0001783180-21-000011:notes:83]
In January 2017, the FASB issued ASU 2017-04, Intangibles – Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment. This ASU simplifies how an entity is required to test goodwill for impairment by eliminating Step 2 from the goodwill impairment test. Under this ASU, a goodwill impairment is calculated as the difference between the carrying amount of a reporting unit and its fair value, not to exceed the carrying amount of the goodwill allocated to a reporting unit. Additionally, this ASU requires the same impairment testing methodology for all reporting units, even those with a zero or negative carrying amount, and requires an entity to disclose the amount of goodwill allocated to each reporting unit with a zero or negative carrying amount. The Company adopted this ASU effective January 1, 2020 and its adoption did not have a material impact on the Consolidated Financial Statements.

[0001783180-21-000011:notes:84]
In February 2018, the FASB issued ASU 2018-02, Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income (Topic 220). The ASU allows companies to reclassify to retained earnings the stranded tax effects in accumulated other comprehensive income ("AOCI") from the then newly-enacted TCJA. The Company adopted this ASU effective January 1, 2019 and elected to reclassify the income tax effects of TCJA from AOCI to UTC Net investment, which did not have a material impact on the Consolidated Financial Statements.

[0001783180-21-000011:notes:85]
In August 2018, the FASB issued ASU 2018-13, Fair Value Measurement (Topic 820): Disclosure Framework—Changes to the Disclosure Requirements for Fair Value Measurement. This ASU removes the disclosure requirements for the amount of and reasons for transfers between Level 1 and Level 2 of the fair value hierarchy. The Company adopted this ASU on January 1, 2020. The adoption of this standard did not have a material impact on the Consolidated Financial Statements.

[0001783180-21-000011:notes:86]
In August 2018, the FASB issued ASU 2018-14, Compensation—Retirement Benefits—Defined Benefit Plans—General (Subtopic 715-20): Disclosure Framework—Changes to the Disclosure Requirements for Defined Benefit Plans. The new standard includes updates to the disclosure requirements for defined benefit plans including several additions, deletions and modifications to the disclosure requirements. The Company adopted this ASU on December 31, 2020. The adoption of this standard did not have a material impact on the Consolidated Financial Statements.

[0001783180-21-000011:notes:87]
In August 2018, the FASB issued ASU 2018-15, Intangibles—Goodwill and Other—Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That is a Service Contract. The new standard provides updated guidance surrounding implementation costs associated with cloud computing arrangements that are service contracts. The Company adopted this ASU on January 1, 2020. The adoption of this standard did not have a material impact on the Consolidated Financial Statements.

[0001783180-21-000011:notes:88]
In August 2020, the SEC issued Final Rule Release No. 33-10825, which amends certain disclosure requirements required by Regulation S-K relating to the description of business (Item 101), legal proceedings (Item 103) and risk factors (Item 105). The amendments to Item 101 will, among other things, allow the Company to provide updates regarding the business based on materiality, if it incorporates by reference disclosure from a previous SEC filing. The amendment also requires disclosures regarding the registrant’s human capital resources to the extent such disclosures would be material to an understanding of the registrant’s business. The amendments to Item 103, among other things, increase the quantitative threshold for disclosing certain environmental proceedings, and the amendments to Item 105, among other things, require a risk factors summary if the risk factors section is longer than 15 pages. The Company adopted these modifications, which were effective on November 9, 2020, and included disclosures regarding human capital management and a risk factors summary in this Annual Report on Form 10-K. The adoption of the other amendments did not have a material impact on the Consolidated Financial Statements.

[0001783180-21-000011:notes:89]
Recently Issued Accounting Pronouncements and SEC Rules

[0001783180-21-000011:notes:90]
In December 2019, the FASB issued ASU 2019-12, Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes. The amendments in this update remove certain exceptions allowed by Topic 740 including exceptions to the incremental approach for intra-period tax allocation when there is a loss from continuing operations and income or gain from other items, the requirement to recognize a deferred tax liability for equity method investments when a foreign subsidiary becomes an equity method investment, the ability not to recognize a deferred tax liability for a foreign subsidiary when a foreign equity method investment becomes a subsidiary and the general methodology for calculating income taxes in an interim period when a year-to-date loss exceeds the anticipated loss for the year. There are also additional areas of guidance in regards to franchise and other taxes partially based on income and the interim recognition of enactment of tax laws and rate changes. The provisions of this ASU are effective for years beginning after December 15, 2020, with early adoption permitted. The Company intends to apply ASU 2019-12 in the first quarter of 2021 and does not anticipate that the adoption will have a material impact on the Company's Consolidated Financial Statements upon adoption.

[0001783180-21-000011:notes:91]
In May 2020, the SEC issued Final Rule Release No. 33-10786, which amends the financial statement requirements for acquisitions and dispositions of businesses and related pro forma financial information required under SEC Regulation S-X, Rule 3-05. The final rule modifies the significance test required in SEC Regulation S-X, Rule 1-02(w) by raising the significance threshold for reporting dispositions of a business from 10% to 20% and by modifying the calculation of the investment and income tests. In accordance with Rules 3-09 or 4-08(g), the revised income test will apply to the evaluation of equity method investments for significance. The Company is currently evaluating the impact of these modifications, which are effective for fiscal years beginning after December 31, 2020.
In November 2020, the SEC issued Final Rule Release No. 33-10980, which amends the requirements for providing selected quarterly financial data, contractual obligations and management discussion and analysis. The Company will monitor future updates as a result of the new administration in Washington, D.C. and we are currently evaluating the impact of these modifications, which are required after August 9, 2021.


## us-gaap:EarningsPerShareTextBlock

[0001783180-21-000011:notes:92]
EARNINGS PER SHARE 
On the Distribution Date, 866,158,910 shares of the Company’s common stock, par value $0.01 per share, were distributed to UTC shareowners of record as of March 19, 2020. This share amount is utilized for the calculation of basic and diluted earnings per share for all periods presented prior to the Separation and the Distribution and such shares are treated as issued and outstanding for purposes of calculating historical earnings per share. For periods prior to the Separation and the Distribution, it is assumed that there are no dilutive equity instruments as there were no Carrier stock-based awards outstanding prior to the Separation and the Distribution.

[0001783180-21-000011:notes:93]
For periods subsequent to the Separation and the Distribution, diluted earnings per share is computed by giving effect to all potentially dilutive stock awards that are outstanding. The computation of diluted earnings per share excludes the effect of the potential exercise of stock-based awards, including stock appreciation rights and stock options, when the effect of the potential exercise would be anti-dilutive. The weighted-average number of common shares outstanding for basic and diluted earnings per share for the year ended December 31, 2020 was based on the weighted-average number of common shares outstanding for the period beginning after the Distribution Date. For the year ended December 31, 2020, the number of stock awards excluded from the computation of diluted earnings per share due to their anti-dilutive effect was approximately 0.2 million.

[0001783180-21-000011:notes:94]
| (dollars in millions, except per share amounts; shares in millions) |  | 2020 |  | 2019 |  | 2018 |
| Net income attributable to common shareowners |  | $ | 1,982 |  |  | $ | 2,116 |  |  | $ | 2,734 |  |
| Basic weighted-average number of shares outstanding |  | 866.5 |  |  | 866.2 |  |  | 866.2 |  |
| Stock awards and equity units (share equivalent) |  | 13.7 |  |  | — |  |  | — |  |
| Diluted weighted-average number of shares outstanding |  | 880.2 |  |  | 866.2 |  |  | 866.2 |  |
| Earnings Per Share |  |  |  |  |  |  |
| Basic |  | $ | 2.29 |  |  | $ | 2.44 |  |  | $ | 3.16 |  |
| Diluted |  | $ | 2.25 |  |  | $ | 2.44 |  |  | $ | 3.16 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001783180-21-000011:notes:95]
REVENUE RECOGNITION 
Contract Assets and Liabilities. Total contract assets and liabilities are as follows:

[0001783180-21-000011:notes:96]
| (dollars in millions) | 2020 |  | 2019 |
| Contract assets, current | $ | 656 |  |  | $ | 622 |  |
| Contract assets, non-current (included within Other assets) | 98 |  |  | 57 |  |
| Total contract assets | 754 |  |  | 679 |  |
| Contract liabilities, current | (512) |  |  | (443) |  |
| Contract liabilities, non-current (included within Other long-term liabilities) | (165) |  |  | (168) |  |
| Total contract liabilities | (677) |  |  | (611) |  |
| Net contract assets | $ | 77 |  |  | $ | 68 |  |

[0001783180-21-000011:notes:97]
Contract assets increased $75 million for the year ended December 31, 2020, primarily due to the timing of billings on customer contracts and contract completions. Contract liabilities increased $66 million for the year ended December 31, 2020, primarily due to customer billings in excess of revenue earned.

[0001783180-21-000011:notes:98]
For the years ended December 31, 2020 and 2019, we recognized revenue of $320 million and $362 million, respectively, that was related to contract liabilities as of January 1, 2020 and 2019, respectively.

[0001783180-21-000011:notes:99]
There were no individually significant customers with sales exceeding 10% of total sales for the years ended December 31, 2020, 2019 and 2018.

[0001783180-21-000011:notes:100]
Remaining Performance Obligations. As of December 31, 2020, our total RPO was approximately $5.4 billion compared with $4.7 billion as of December 31, 2019. Of the total RPO as of December 31, 2020, we expect approximately 71% will be recognized as sales over the following 12 months.
See Note 26 – Segment Financial Data which provides incremental disclosures required by ASC Topic 606: Revenue from Contracts with Customers


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001783180-21-000011:notes:101]
EQUITY METHOD INVESTMENTS AND RELATED PARTIES 
Equity Method Investments

[0001783180-21-000011:notes:102]
Carrier had 30 directly owned unconsolidated domestic and foreign affiliates as of December 31, 2020 and 2019. Carrier’s ownership interests in equity method investments vary among individual investments and range from 20% to 50%. While all three of our segments participate in joint ventures and strategic relationships, 98% of such investments are in our HVAC business.

[0001783180-21-000011:notes:103]
Summarized financial information for equity method investments is reflected in the following tables:

[0001783180-21-000011:notes:104]
| (dollars in millions) | 2020 |  | 2019 |
| Current assets | $ | 3,671 |  |  | $ | 4,324 |  |
| Non-current assets | 2,035 |  |  | 2,058 |  |
| Total assets | 5,706 |  |  | 6,382 |  |
| Current liabilities | 2,223 |  |  | 2,310 |  |
| Non-current liabilities | 298 |  |  | 592 |  |
| Total liabilities | 2,521 |  |  | 2,902 |  |
| Total net equity of investees | $ | 3,185 |  |  | $ | 3,480 |  |

[0001783180-21-000011:notes:105]
| (dollars in millions) | 2020 |  | 2019 |  | 2018 |
| Net sales | $ | 9,299 |  |  | $ | 9,622 |  |  | $ | 9,142 |  |
| Gross profit | $ | 1,722 |  |  | $ | 1,741 |  |  | $ | 1,673 |  |
| Income from continuing operations | $ | 544 |  |  | $ | 578 |  |  | $ | 645 |  |
| Net income | $ | 544 |  |  | $ | 578 |  |  | $ | 645 |  |

[0001783180-21-000011:notes:106]
Carrier sells products to and purchases products from unconsolidated entities accounted for under the equity method, therefore these entities are considered related parties. For the years ended December 31, 2020, 2019 and 2018, Product sales in the Consolidated Statement of Operations included sales to equity method investees of $1.8 billion, $1.8 billion and $1.9 billion, respectively. For the years ended December 31, 2020, 2019 and 2018, Cost of products sold in the Consolidated Statement of Operations included purchases from equity method investees of $292 million, $368 million and $355 million, respectively.

[0001783180-21-000011:notes:107]
Carrier had receivables from equity method investees of $161 million and $137 million as of December 31, 2020 and 2019, respectively. Carrier also had payables to equity method investees of $38 million and $55 million as of December 31, 2020 and 2019, respectively. The receivables and payables are included in Accounts receivable, net and Accounts payable on the Consolidated Balance Sheet.

[0001783180-21-000011:notes:108]
The Company periodically reviews the carrying value of our equity method investments to determine if there has been an other-than-temporary decline in fair value. A variety of factors are considered when determining if a decline in carrying value is other-than-temporary, including, among other factors, the financial condition and business prospects of the investee, as well as the Company's intent with regard to the investment. In 2020, we assessed potential impairment indicators related to our equity method investments and determined that indicators of impairment existed for a specific minority owned joint venture investment in the portfolio of our HVAC segment. We performed a valuation of this investment based on the income approach using the discounted cash flow method. We determined that the loss in value was other-than-temporary due to a reduction in sales and earnings that were driven by a deterioration in the oil and gas industry (the joint venture's primary market) and the impact of COVID-19, among other factors. As a result, we recorded an other-than-temporary impairment charge of $71 million on this investment in 2020, which is included in Other income (expense), net on the accompanying Consolidated Statement of Operations.

[0001783180-21-000011:notes:109]
In 2019, we assessed potential impairment indicators related to our equity method investments and determined that indicators of impairment existed for a specific minority owned joint venture investment in the portfolio. We performed a valuation of this investment and determined that the fair value was less than its carrying value and that the loss was other-than-temporary. As a result, we recorded an other-than-temporary impairment charge of $108 million on this investment in 2019.

[0001783180-21-000011:notes:110]
In September 2020, the Company sold 9.25 million B shares of Beijer for SEK290 ($32.38) per share equal to approximately 7.9% of the outstanding B shares in Beijer, through an accelerated equity offering. We received proceeds of approximately $300 million and recognized a pre-tax gain on the sale of $252 million, which is included in Other income (expense), net on the Consolidated Statement of Operations.

[0001783180-21-000011:notes:111]
Subsequently, in December 2020, the Company sold all of our remaining A and B shares of Beijer for SEK245 ($29.03) per share. We received proceeds of approximately $1.1 billion and recognized a pre-tax gain on the sale of $871 million, which is included in Other income (expense), net on the Consolidated Statement of Operations. Prior to the sale of the Company's remaining shares, Beijer was reported as an equity method investment.

[0001783180-21-000011:notes:112]
Related Party with UTC

[0001783180-21-000011:notes:113]
Prior to the Separation and the Distribution, Carrier had been managed and operated in the normal course of business with other affiliates of UTC. Accordingly, certain shared costs had been allocated to the Company and are reflected as expenses in the Consolidated Financial Statements.

[0001783180-21-000011:notes:114]
Related Party Sales. During the periods prior to the Separation and the Distribution, the Company sold products and services to UTC and its other affiliates. Product sales in the Consolidated Statement of Operations include sales to UTC and affiliates of UTC other than Carrier of $3 million, $23 million and $25 million for the years ended December 31, 2020, 2019 and 2018, respectively.

[0001783180-21-000011:notes:115]
Allocated Centralized Costs. Prior to the Separation and the Distribution, UTC incurred corporate costs for services provided to the Company and to other UTC businesses. These services included treasury, tax, accounting, human resources, internal audit, legal, purchasing and information technology. The costs associated with these services generally included all payroll and benefit costs as well as related overhead costs. UTC also allocated costs associated with corporate insurance coverage and medical, pension, post-retirement and other health plan costs for employees participating in UTC sponsored plans. UTC corporate costs were either specifically attributed and charged to Carrier, when possible, or allocated to the Company. Allocations were based on direct usage where identifiable and on a number of other utilization measures including headcount, proportionate usage and net sales. All such amounts were deemed incurred and settled by the Company in the period in which the costs were recorded and are included in UTC Net investment.

[0001783180-21-000011:notes:116]
The allocated centralized costs for the years ended December 31, 2020, 2019 and 2018, were $43 million, $245 million and $277 million, respectively, and are primarily included in Selling, general and administrative in the Consolidated Statement of Operations.

[0001783180-21-000011:notes:117]
The expense and cost allocations were determined on a basis considered to be a reasonable reflection of the utilization of services provided to or for the benefit received by the Company prior to the Separation and the Distribution. The amounts that would have been incurred on a stand-alone basis could differ from the amounts allocated due to economies of scale, differences in management approach, a need for more or fewer employees or other factors. In addition, the Company's future results of operations, financial position and cash flows could differ materially from the historical results presented herein.

[0001783180-21-000011:notes:118]
Separation Costs. In connection with the Separation and the Distribution, we have incurred separation-related costs of approximately $141 million and $58 million for the years ended December 31, 2020 and 2019, respectively, primarily recorded in Selling, general and administrative in the Consolidated Statement of Operations, which primarily consist of employee-related costs, costs to establish certain stand-alone functions and information technology systems, professional service fees and other transaction-related costs resulting from Carrier’s transition to becoming an independent, publicly traded company. Carrier did not incur costs in connection with the Separation for the year ended December 31, 2018.

[0001783180-21-000011:notes:119]
Cash Management and Financing. Prior to the Separation and the Distribution, the Company participated in UTC’s centralized cash management and financing programs. The cash reflected on the Consolidated Balance Sheet, prior to the Separation and the Distribution, represents cash on hand at certain foreign entities that did not participate in the centralized UTC cash management program and were specifically identifiable to the Company. Cash receipts and disbursements were

[0001783180-21-000011:notes:120]
executed through centralized systems, which were operated by UTC. As cash was received and disbursed by UTC, it was accounted for by the Company through UTC Net investment. The majority of external debt was financed by UTC, and financing decisions for wholly and majority owned subsidiaries were determined by UTC. The Company’s cash that was excluded from UTC's centralized cash management and financing programs is classified as Cash and cash equivalents in the Consolidated Balance Sheet as of December 31, 2019.

[0001783180-21-000011:notes:121]
For the year ended December 31, 2020, net assets of $859 million were contributed to the Company by UTC which primarily consisted of cash of $590 million, deferred tax assets and liabilities and fixed assets. These contributions of net assets are recorded as Net transfers from UTC on the Consolidated Statement of Changes in Equity through UTC Net investment.

[0001783180-21-000011:notes:122]
Accounts Receivable and Payable. Certain related party transactions between the Company and UTC were included within UTC Net investment in the Consolidated Balance Sheet as of December 31, 2019 when the related party transactions were not settled in cash. As of December 31, 2019, the UTC Net investment includes related party receivables due from UTC and its affiliates of $16.0 billion and related party payables due to UTC and its affiliates of $3.3 billion. As of April 3, 2020, UTC Net investment was reclassified to Common stock and Additional paid-in capital.

[0001783180-21-000011:notes:123]
Prior to the Separation and the Distribution, interest income and expense related to activity with UTC that were historically included in Carrier’s results are presented on a net basis in the Consolidated Statement of Operations. For the years ended December 31, 2019 and 2018 there was $91 million and $110 million, respectively, of interest income from activity with UTC. For the years ended 2019 and 2018, there was $55 million and $59 million, respectively, of interest expense from activity with UTC. The effect of the settlement of these related party transactions is included in financing activity in the Consolidated Statement of Cash Flows. There was no interest income or expense from activity with UTC for the year ended December 31, 2020.

[0001783180-21-000011:notes:124]
Additionally, certain transactions between Carrier and our subsidiaries, and UTC and its affiliates, were cash-settled and were reflected in Accounts receivable, net and Accounts payable in the Consolidated Balance Sheet as of December 31, 2019 in the amounts of $6 million and $4 million, respectively. As of December 31, 2020, there were no pre-Separation accounts receivable or accounts payable outstanding with UTC.


## us-gaap:AccountsAndNontradeReceivableTextBlock

[0001783180-21-000011:notes:125]
ACCOUNTS RECEIVABLE, NET
Accounts receivable, net consisted of the following:

[0001783180-21-000011:notes:126]
| (dollars in millions) | 2020 |  | 2019 |
| Trade receivables | $ | 2,567 |  |  | $ | 2,444 |  |
| Receivables from affiliates | 161 |  |  | 143 |  |
| Other receivables | 142 |  |  | 184 |  |
| Accounts receivable | 2,870 |  |  | 2,771 |  |
| Less: Allowance for expected credit losses | (89) |  |  | (45) |  |
| Accounts receivable, net | $ | 2,781 |  |  | $ | 2,726 |  |

[0001783180-21-000011:notes:127]
The changes in the allowance for expected credit losses related to Accounts receivable, net are as follows:

[0001783180-21-000011:notes:128]
| (dollars in millions) |  |
| Balance as of January 1, 2018 | $ | 152 |  |
| Provision charged to income | 20 |  |
| Accounts charged off, net of recoveries | (22) |  |
| Other | (9) |  |
| Balance as of December 31, 2018 | 141 |  |
| Provision charged to income | 18 |  |
| Accounts charged off, net of recoveries | (45) |  |
| Other (1) | (69) |  |
| Balance as of December 31, 2019 | 45 |  |
| Current period provision for expected credit losses | 40 |  |
| Accounts charged off, net of recoveries | (7) |  |
| Other (2) | 11 |  |
| Balance as of December 31, 2020 | $ | 89 |  |

[0001783180-21-000011:notes:129]
________________________

[0001783180-21-000011:notes:130]
(1) Includes $61 million of the prior year allowance for doubtful accounts reflected as a direct reduction in trade receivables.

[0001783180-21-000011:notes:131]
(2) Includes impact of adoption of ASU 2016-13.


## us-gaap:InventoryDisclosureTextBlock

[0001783180-21-000011:notes:132]
INVENTORIES, NET

[0001783180-21-000011:notes:133]
| (dollars in millions) | 2020 |  | 2019 |
| Raw materials | $ | 363 |  |  | $ | 290 |  |
| Work-in-process | 143 |  |  | 120 |  |
| Finished goods | 1,123 |  |  | 922 |  |
| Inventories, net | $ | 1,629 |  |  | $ | 1,332 |  |

[0001783180-21-000011:notes:134]
Raw materials, work-in-process and finished goods are net of valuation reserves of $183 million and $152 million as of December 31, 2020 and 2019, respectively.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001783180-21-000011:notes:135]
FIXED ASSETS, NET 
Fixed assets are recorded at cost and are depreciated on a straight-line basis over their estimated useful lives.

[0001783180-21-000011:notes:136]
| (dollars in millions) | Estimated Useful Lives (Years) |  | 2020 |  | 2019 |
| Land |  |  | $ | 109 |  |  | $ | 113 |  |
| Buildings and improvements | 40 |  | 1,160 |  |  | 1,138 |  |
| Machinery, tools and equipment | 3 to 25 |  | 2,138 |  |  | 1,924 |  |
| Rental assets | 3 to 12 |  | 416 |  |  | 395 |  |
| Other, including assets under construction |  |  | 261 |  |  | 188 |  |
| Fixed assets, gross |  |  | 4,084 |  |  | 3,758 |  |
| Accumulated depreciation |  |  | (2,274) |  |  | (2,095) |  |
| Fixed assets, net |  |  | $ | 1,810 |  |  | $ | 1,663 |  |

[0001783180-21-000011:notes:137]
Depreciation expense was $234 million, $219 million and $221 million for the years ended December 31, 2020, 2019 and 2018, respectively.


## carr:MergersAcquisitionsAndDispositionsDisclosuresAndGoodwillAndIntangibleAssetsDisclosureTextBlock

[0001783180-21-000011:notes:138]
BUSINESS ACQUISITIONS, DISPOSITIONS, GOODWILL AND INTANGIBLE ASSETS 
Business Acquisitions and Dispositions. There were no significant acquisitions or divestitures of consolidated businesses for the years ended December 31, 2020 and 2019. During the year ended December 31, 2018, Carrier's investment through acquisition, net of cash acquired was $310 million. This acquisition was not considered material for presentation of pro forma results under ASC 805: Business Combinations. Acquisition-related costs have been expensed as incurred and were not material in any of the periods presented.

[0001783180-21-000011:notes:139]
We completed the sale of Taylor during the year ended December 31, 2018 for $1.0 billion in cash, resulting in a pre-tax gain of $799 million on the sale included in Other income (expense), net on the Consolidated Statement of Operations.

[0001783180-21-000011:notes:140]
Goodwill. The changes in the carrying amount of goodwill were as follows:

[0001783180-21-000011:notes:141]
| (dollars in millions) | HVAC |  | Refrigeration |  | Fire & Security |  | Total |
| Balance as of January 1, 2019 | $ | 5,330 |  |  | $ | 1,231 |  |  | $ | 3,288 |  |  | $ | 9,849 |  |
| Foreign currency translation | 21 |  |  | (3) |  |  | 17 |  |  | 35 |  |
| Balance as of December 31, 2019 | $ | 5,351 |  |  | $ | 1,228 |  |  | $ | 3,305 |  |  | $ | 9,884 |  |
| Foreign currency translation | 138 |  |  | 23 |  |  | 94 |  |  | 255 |  |
| Balance as of December 31, 2020 | $ | 5,489 |  |  | $ | 1,251 |  |  | $ | 3,399 |  |  | $ | 10,139 |  |

[0001783180-21-000011:notes:142]
Intangible Assets, net. Identifiable intangible assets include the following:

[0001783180-21-000011:notes:143]
|  |  |  | 2020 |  | 2019 |
| (dollars in millions) | Useful Lives |  | Gross Amount |  | Accumulated Amortization |  | Gross Amount |  | Accumulated Amortization |
| Amortized: |  |  |  |  |  |  |  |  |  |
| Customer relationships | 1 to 30 |  | $ | 1,558 |  |  | $ | (1,285) |  |  | $ | 1,479 |  |  | $ | (1,154) |  |
| Patents and trademarks | 5 to 30 |  | 301 |  |  | (222) |  |  | 287 |  |  | (201) |  |
| Monitoring lines | 7 to 10 |  | 71 |  |  | (59) |  |  | 67 |  |  | (52) |  |
| Service portfolios and other | 1 to 23 |  | 644 |  |  | (542) |  |  | 629 |  |  | (506) |  |
|  |  |  | 2,574 |  |  | (2,108) |  |  | 2,462 |  |  | (1,913) |  |
| Unamortized: |  |  |  |  |  |  |  |  |  |
| Trademarks and other |  |  | 571 |  |  | — |  |  | 534 |  |  | — |  |
| Intangible assets, net |  |  | $ | 3,145 |  |  | $ | (2,108) |  |  | $ | 2,996 |  |  | $ | (1,913) |  |

[0001783180-21-000011:notes:144]
Amortization of intangible assets was $102 million, $116 million and $136 million for the years ended December 31, 2020, 2019 and 2018, respectively.

[0001783180-21-000011:notes:145]
The estimated future amortization of intangible assets is as follows:

[0001783180-21-000011:notes:146]
| (dollars in millions) | 2021 |  | 2022 |  | 2023 |  | 2024 |  | 2025 |
| Future amortization | $ | 94 |  |  | $ | 75 |  |  | $ | 65 |  |  | $ | 57 |  |  | $ | 50 |  |

[0001783180-21-000011:notes:147]
Annual Impairment Assessment. As part of our annual impairment testing, we concluded that the fair value of goodwill exceeded the carrying value for all reporting units, resulting in no goodwill impairment. However, for one reporting unit, with goodwill of $917 million, the excess of fair value over the carrying value was approximately 13%. For this reporting unit, a 100 basis point increase in the discount rate used in the financial forecast would result in an impairment of approximately $84 million. The estimated fair value of the reporting unit may be negatively impacted if future economic conditions are worse than our financial forecast and assumptions or there are substantial reductions in our end markets and volume assumptions relative to our financial forecast.

[0001783180-21-000011:notes:148]
Based upon the quantitative assessment performed, the fair value of indefinite lived trademarks was determined to exceed the carrying value, resulting in no impairment.


## us-gaap:AccountsPayableAndAccruedLiabilitiesDisclosureTextBlock

[0001783180-21-000011:notes:149]
ACCRUED LIABILITIES

[0001783180-21-000011:notes:150]
| (dollars in millions) |  | 2020 |  | 2019 |
| Accrued salaries, wages and employee benefits |  | $ | 634 |  |  | $ | 516 |  |
| Accrued taxes |  | 234 |  |  | 318 |  |
| Warranty-related (Note 23) |  | 191 |  |  | 200 |  |
| Accrued interest |  | 127 |  |  | 26 |  |
| Operating leases (Note 22) |  | 161 |  |  | 163 |  |
| Accrued insurance (Note 25) |  | 164 |  |  | 173 |  |
| Accrued restructuring (Note 17) |  | 47 |  |  | 66 |  |
| Accrued common stock dividend |  | 105 |  |  | — |  |
| Other |  | 808 |  |  | 626 |  |
| Accrued liabilities |  | $ | 2,471 |  |  | $ | 2,088 |  |


## us-gaap:DebtDisclosureTextBlock

[0001783180-21-000011:notes:151]
BORROWINGS AND LINES OF CREDIT 
On February 10, 2020, we entered into a revolving credit agreement with various banks permitting aggregate borrowings of up to $2.0 billion pursuant to an unsecured, unsubordinated revolving credit facility that matures on April 3, 2025. The Revolving Credit Facility supports our commercial paper program and cash requirements. A commitment fee of 0.125% is charged on the unused commitments. Borrowings under the Revolving Credit Facility are available in U.S. Dollars, Euros and Pounds Sterling and bear interest at a variable interest rate based on LIBOR plus a ratings-based margin, which was 125 basis points as of December 31, 2020. As of December 31, 2020, there were no borrowings on the Revolving Credit Facility.

[0001783180-21-000011:notes:152]
On February 10, 2020, we entered into a $1.75 billion term loan credit agreement that provided an unsecured, unsubordinated term loan credit facility which was scheduled to mature on February 10, 2023. In the three months ended December 31, 2020, Carrier prepaid the full $1.75 billion principal amount outstanding under the Term Loan Credit Facility. Borrowings under the Term Loan Credit Facility were subject to a variable interest rate based on LIBOR plus a ratings-based margin, which immediately prior to the repayment date in the three months ended December 31, 2020, was 112.5 basis points. In connection with the full prepayment of the Term Loan Credit Facility, the term loan credit agreement was terminated.

[0001783180-21-000011:notes:153]
On February 27, 2020, Carrier issued $9.25 billion of unsecured, unsubordinated long-term notes in six series with maturity dates ranging from 2023 through 2050. The long-term fixed rate notes were issued pursuant to an indenture between the Company and The Bank of New York Mellon Trust Company, N.A., as trustee.

[0001783180-21-000011:notes:154]
On March 27, 2020, Carrier drew $1.75 billion on the Term Loan Credit Facility. The proceeds of the long-term fixed rate notes issued in February 2020 of $9.25 billion and the Term Loan Credit Facility of $1.75 billion were used to distribute $10.9 billion to UTC in connection with the Separation.

[0001783180-21-000011:notes:155]
The revolving credit agreement and indenture contain affirmative and negative covenants customary for financings of this type, that among other things, limit Carrier and our subsidiaries' ability to incur additional liens, to make certain fundamental changes and to enter into sale and leaseback transactions. On June 2, 2020, the Company entered into an amendment to the revolving credit agreement. Pursuant to the amendment, certain terms of the Revolving Credit Facility were amended for the Covenant Modification Period. The Company may terminate the Covenant Modification Period prior to December 30, 2021 subject to the satisfaction of certain conditions. The amendment defers testing of our consolidated total net leverage ratio financial covenant until June 30, 2021 and increases the consolidated total net leverage ratio limit until December 31, 2021. The amendment also requires us to maintain liquidity at a certain level until the earlier of (1) June 29, 2021 and (2) the last day of the Covenant Modification Period. Additionally, during the Covenant Modification Period, the Company is subject to (a) limitations on the incurrence of subsidiary indebtedness, (b) limitations on the making of restricted payments, including purchases by the Company of our ordinary shares and the amount of dividends the Company may pay, and (c) a "most favored nations" provision related to certain terms of any committed credit facility in an amount greater than $100 million. As of December 31, 2020, we were compliant with our covenants under the agreements governing our outstanding indebtedness.

[0001783180-21-000011:notes:156]
On June 19, 2020, we issued $750 million of unsecured, unsubordinated 2.700% Notes due 2031. These notes rank equally with our other unsecured, unsubordinated obligations. We used the net proceeds from the sale of such notes, which further enhance our liquidity and financial flexibility during the ongoing COVID-19 pandemic, for general corporate purposes.

[0001783180-21-000011:notes:157]
As of December 31, 2020, we have a $2.0 billion unsecured, unsubordinated commercial paper program which we plan to use for general corporate purposes, including the funding of working capital and potential acquisitions. As of December 31, 2020, there were no borrowings outstanding under the commercial paper program.

[0001783180-21-000011:notes:158]
Long-term debt consisted of the following:

[0001783180-21-000011:notes:159]
| (dollars in millions) |  |  |  |  |  |  |  |  |
| Debt Description | Interest Rate |  |  | 2020 |  |  | 2019 |  |
| 1.923% Notes due February 15, 2023 | 1.923 | % |  |  | $ | 500 |  |  |  | $ | — |  |  |
| 2.242% Notes due February 15, 2025 | 2.242 | % |  |  | 2,000 |  |  |  | — |  |  |
| 2.493% Notes due February 15, 2027 | 2.493 | % |  |  | 1,250 |  |  |  | — |  |  |
| 2.722% Notes due February 15, 2030 | 2.722 | % |  |  | 2,000 |  |  |  | — |  |  |
| 2.700% Notes due February 15, 2031 | 2.700 | % |  |  | 750 |  |  |  | — |  |  |
| 3.377% Notes due April 5, 2040 | 3.377 | % |  |  | 1,500 |  |  |  | — |  |  |
| 3.577% Notes due April 5, 2050 | 3.577 | % |  |  | 2,000 |  |  |  | — |  |  |
| Other (including project financing obligations and finance leases) |  |  |  | 308 |  |  |  | 319 |  |  |
| Total principal long-term debt |  |  |  | 10,308 |  |  |  | 319 |  |  |
| Other (discounts and debt issuance costs) |  |  |  | (81) |  |  |  | — |  |  |
| Total debt |  |  |  | 10,227 |  |  |  | 319 |  |  |
| Less: current portion of long-term debt |  |  |  | 191 |  |  |  | 237 |  |  |
| Long-term debt, net of current portion |  |  |  | $ | 10,036 |  |  |  | $ | 82 |  |  |

[0001783180-21-000011:notes:160]
We issued $135 million and $107 million of debt for the years ended December 31, 2020 and 2019, respectively, relating to project financing arrangements. Long-term debt repayments for the years ended December 31, 2020 and 2019 relating to project financing arrangements were $161 million and $138 million, respectively.

[0001783180-21-000011:notes:161]
Scheduled maturities of long-term debt, excluding amortization of discount, are as follows:

[0001783180-21-000011:notes:162]
| (dollars in millions) |  |  |  |
| 2021 |  | $ | 190 |  |  |
| 2022 |  | $ | 117 |  |  |
| 2023 |  | $ | 501 |  |  |
| 2024 |  | $ | — |  |  |
| 2025 |  | $ | 2,000 |  |  |
| Thereafter |  | $ | 7,500 |  |  |

[0001783180-21-000011:notes:163]
The average maturity of our long-term debt as of December 31, 2020 is approximately 13 years and the weighted-average interest rate on our total borrowings for the year ended December 31, 2020 is approximately 2.7%.

[0001783180-21-000011:notes:164]
Interest expense associated with long-term debt for the year ended December 31, 2020 was $298 million. Included in Interest expense, net on the accompanying Consolidated Statement of Operations is amortization of debt issuance costs of $9 million and debt issuance costs of $5 million that were expensed for the year ended December 31, 2020. Included in Accrued liabilities on the accompanying Consolidated Balance Sheet was accrued interest associated with long-term debt of $96 million and $1 million as of December 31, 2020 and 2019, respectively.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001783180-21-000011:notes:165]
EMPLOYEE BENEFIT PLANS 
Employee Savings Plans. The Company sponsors various employee savings plans. Prior to the Separation and the Distribution, UTC also sponsored and contributed to defined contribution employee savings plans. Certain employees of Carrier participate in these plans. Carrier’s contributions to employer sponsored defined contribution plans were $103 million, $88 million and $94 million for the years ended December 31, 2020, 2019 and 2018, respectively.

[0001783180-21-000011:notes:166]
Pension Plans. The Company sponsors both funded and unfunded domestic and international defined benefit pension and other post-retirement benefit plans and defined contribution plans. Additionally, the Company contributes to various domestic and international multi-employer defined benefit pension and other post-retirement benefit plans.

[0001783180-21-000011:notes:167]
| (dollars in millions) | 2020 |  | 2019 |
| Change in Benefit Obligation |  |  |  |
| Beginning balance | $ | 2,885 |  |  | $ | 2,581 |  |
| Service cost | 29 |  |  | 31 |  |
| Interest cost | 52 |  |  | 67 |  |
| Actuarial loss | 239 |  |  | 351 |  |
| Benefits paid | (116) |  |  | (132) |  |
| Net settlement, curtailment and special termination benefits | (16) |  |  | (38) |  |
| Other (1) | 151 |  |  | 25 |  |
| Ending balance | $ | 3,224 |  |  | $ | 2,885 |  |
| (dollars in millions) | 2020 |  | 2019 |
| Change in Plan Assets |  |  |  |
| Beginning balance | $ | 2,953 |  |  | $ | 2,635 |  |
| Actual return on plan assets | 285 |  |  | 381 |  |
| Employer contributions | 41 |  |  | 36 |  |
| Benefits paid | (116) |  |  | (132) |  |
| Settlements | (15) |  |  | (14) |  |
| Other (1) | 146 |  |  | 47 |  |
| Ending balance | $ | 3,294 |  |  | $ | 2,953 |  |
| Funded Status |  |  |  |
| Fair value of plan assets | $ | 3,294 |  |  | $ | 2,953 |  |
| Benefit obligations | (3,224) |  |  | (2,885) |  |
| Funded status of plans | $ | 70 |  |  | $ | 68 |  |

[0001783180-21-000011:notes:168]
_____________________

[0001783180-21-000011:notes:169]
(1) Reflects the impact of foreign exchange translation, primarily for plans in the United Kingdom, Canada and Germany.

[0001783180-21-000011:notes:170]
The largest contributor to the improvement in the funded position was better than expected asset performance globally, offset by exchange rate losses and the decrease in the discount rate used to measure the benefit obligations of our plans. Discount rates in all applicable territories and countries declined over the measurement period as a result of reductions in corporate bond yields, which resulted in an increase in benefit obligations.

[0001783180-21-000011:notes:171]
| (dollars in millions) | 2020 |  | 2019 |
| Amounts Recognized in the Consolidated Balance Sheet Consist of: |  |  |  |
| Non-current assets | $ | 542 |  |  | $ | 488 |  |
| Current liability | (10) |  |  | (9) |  |
| Non-current liability | (462) |  |  | (411) |  |
| Net amount recognized | $ | 70 |  |  | $ | 68 |  |
| Amounts Recognized in Accumulated Other Comprehensive Loss Consist of: |  |  |  |
| Net actuarial loss | $ | 689 |  |  | $ | 577 |  |
| Prior service cost | 13 |  |  | 15 |  |
| Net amount recognized | $ | 702 |  |  | $ | 592 |  |

[0001783180-21-000011:notes:172]
Qualified domestic pension plan benefits comprise approximately 9% of the projected benefit obligation. These plans are closed to new entrants. Foreign plans comprise approximately 91% of the projected benefit obligation; certain of these plans provide participants with one-time payments upon separation of employment rather than a retirement annuity. Non-qualified domestic pension plans provide supplementary retirement benefits to certain employees and are not a material component of the projected benefit obligation.

[0001783180-21-000011:notes:173]
For the years ended December 31, 2020, 2019 and 2018, we made $41 million, $36 million and $45 million, respectively, of cash contributions to our foreign defined benefit pension plans.

[0001783180-21-000011:notes:174]
Information for pension plans with accumulated benefit obligations in excess of plan assets:

[0001783180-21-000011:notes:175]
| (dollars in millions) | 2020 |  | 2019 |
| Projected benefit obligation | $ | 622 |  |  | $ | 549 |  |
| Accumulated benefit obligation | $ | 579 |  |  | $ | 506 |  |
| Fair value of plan assets | $ | 156 |  |  | $ | 137 |  |

[0001783180-21-000011:notes:176]
Information for pension plan with projected benefit obligations in excess of plan assets:

[0001783180-21-000011:notes:177]
| (dollars in millions) | 2020 |  | 2019 |
| Projected benefit obligation | $ | 666 |  |  | $ | 690 |  |
| Accumulated benefit obligation | $ | 615 |  |  | $ | 630 |  |
| Fair value of plan assets | $ | 194 |  |  | $ | 270 |  |

[0001783180-21-000011:notes:178]
The accumulated benefit obligation for all defined benefit plans was $3.2 billion and $2.8 billion as of December 31, 2020 and 2019, respectively.

[0001783180-21-000011:notes:179]
The components of net periodic pension benefits for our defined benefit pension plan are as follows:

[0001783180-21-000011:notes:180]
| (dollars in millions) | 2020 |  | 2019 |  | 2018 |  |  |  |  |
| Service cost | $ | 29 |  |  | $ | 31 |  |  | $ | 33 |  |  |  |  |  |
| Interest cost | 52 |  |  | 67 |  |  | 64 |  |  |  |  |  |
| Expected return on plan assets | (140) |  |  | (154) |  |  | (170) |  |  |  |  |  |
| Amortization of prior service credit | 2 |  |  | 2 |  |  | 1 |  |  |  |  |  |
| Recognized actuarial net loss | 22 |  |  | 9 |  |  | 16 |  |  |  |  |  |
| Net settlement, curtailment and special termination benefit loss | 4 |  |  | 4 |  |  | 1 |  |  |  |  |  |
| Net periodic pension benefit | $ | (31) |  |  | $ | (41) |  |  | $ | (55) |  |  |  |  |  |

[0001783180-21-000011:notes:181]
Other changes in plan assets and benefit obligations recognized in other comprehensive income (loss) are as follows:

[0001783180-21-000011:notes:182]
| (dollars in millions) |  | 2020 |  | 2019 |
| Current year actuarial loss |  | $ | 94 |  |  | $ | 112 |  |
| Amortization of actuarial loss |  | (22) |  |  | (9) |  |
| Amortization of prior service cost |  | (2) |  |  | (2) |  |
| Net settlement and curtailment gain |  | (4) |  |  | (4) |  |
| Other (1) |  | 39 |  |  | 2 |  |
| Total recognized in other comprehensive loss |  | $ | 105 |  |  | $ | 99 |  |
| Net recognized in net periodic benefit and other comprehensive loss |  | $ | 74 |  |  | $ | 58 |  |

[0001783180-21-000011:notes:183]
Major assumptions used in determining the benefit obligation and net cost for pension plans are presented in the following table as weighted-averages:

[0001783180-21-000011:notes:184]
|  |  | Benefit Obligation |  |  | Net Costs |
| (dollars in millions) | 2020 |  | 2019 | (2) |  | 2020 |  | 2019 | (2) |  | 2018 | (2) |
| Discount rate |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Projected benefit obligation | 1.4% |  | 2.0 | % |  |  | 2.0% |  | 2.8 | % |  |  | 2.5 | % |  |
| Interest cost (1) |  | —% |  | — | % |  |  | 1.8% |  | 2.7 | % |  |  | 2.4 | % |  |
| Service cost (1) |  | —% |  | — | % |  |  | 1.8% |  | 3.2 | % |  |  | 2.8 | % |  |
| Salary scale |  | 2.8% |  | 3.4 | % |  |  | 3.3% |  | 3.0 | % |  |  | 3.0 | % |  |
| Expected return on plan assets | —% |  | — | % |  |  | 4.9% |  | 5.6 | % |  |  | 6.0 | % |  |

[0001783180-21-000011:notes:185]
(1) The 2020 and 2019 discount rates used to measure the service cost and interest cost applies to our significant plans. The projected benefit obligation discount rate is used for the service cost and interest cost measurements for non-significant plans.

[0001783180-21-000011:notes:186]
(2) Assumptions prior to 2020 include assumptions used for the UTC plan which included Carrier employees.

[0001783180-21-000011:notes:187]
The weighted-average discount rates used to measure pension benefit obligations and net costs are set by reference to specific analyses using each plan’s specific cash flows and high-quality bond indices to assess reasonableness. For those significant plans, Carrier utilizes a full yield curve approach in the estimation of the service cost and interest cost components by applying the specific spot rates along the yield curve used in determination of the benefit obligation to the relevant projected cash flows.

[0001783180-21-000011:notes:188]
In determining the expected return on plan assets, we consider the relative weighting of plan assets, the historical performance of total plan assets and individual asset classes and economic and other indicators of future performance. Return projections are assessed for reasonableness using a simulation model that incorporates yield curves, credit spreads and risk premiums to project long-term prospective returns.

[0001783180-21-000011:notes:189]
The plans’ investment management objectives include providing the liquidity and asset levels needed to meet current and future benefit payments, while maintaining a prudent degree of portfolio diversification considering interest rate risk and market volatility. Globally, investment strategies target a mix of approximately 40% of growth seeking assets and 60% of income generating and hedging assets using a wide diversification of asset types, fund strategies and investment managers. The growth seeking allocation consists of global public equities in developed and emerging countries and alternative-asset class strategies. Within the income generating assets, the fixed income portfolio consists of mainly government and broadly diversified high quality corporate bonds.

[0001783180-21-000011:notes:190]
The plans seek to reduce the plans’ interest rate risk and have incorporated liability hedging programs that include the adoption of a risk reduction objective as part of the long-term investment strategy. Under this objective the income generating and hedging assets typically increase as funded status improves. The hedging programs incorporate a range of assets and investment tools, each with various interest rate sensitivities. As a result of the improved funded status of the plans due to favorable asset returns and funding of the plans, the income generating and hedging assets increased in recent years.

[0001783180-21-000011:notes:191]
The fair values of pension plan assets by asset category are as follows:

[0001783180-21-000011:notes:192]
|  |  | Quoted Prices in Active Markets for Identical Assets |  | Significant Observable Inputs |  | Significant Unobservable Inputs |  | Not Subject |  |  |
| (dollars in millions) |  | (Level 1) |  | (Level 2) |  | (Level 3) |  | to Leveling |  | Total |
| Asset Category |  |  |  |  |  |  |  |  |  |  |
| Public Equities: |  |  |  |  |  |  |  |  |  |  |
| Global Equities |  | $ | — |  |  | $ | 52 |  |  | $ | — |  |  | $ | 65 |  |  | $ | 117 |  |
| Global Equity Funds at net asset value (8) |  | — |  |  | — |  |  | — |  |  | 733 |  |  | 733 |  |
| Fixed Income Securities: |  |  |  |  |  |  |  |  |  |  |
| Governments |  | — |  |  | 1,270 |  |  | — |  |  | — |  |  | 1,270 |  |
| Corporate Bonds |  | — |  |  | 121 |  |  | — |  |  | 41 |  |  | 162 |  |
| Fixed Income Securities (8) |  | — |  |  | — |  |  | — |  |  | 923 |  |  | 923 |  |
| Real Estate (4)(8) |  | — |  |  | 2 |  |  | — |  |  | 11 |  |  | 13 |  |
| Other (5)(8)(9) |  | — |  |  | (422) |  |  | — |  |  | 407 |  |  | (15) |  |
| Cash & Cash Equivalents (6)(8) |  | — |  |  | 32 |  |  | — |  |  | 22 |  |  | 54 |  |
| Subtotal |  | $ | — |  |  | $ | 1,055 |  |  | $ | — |  |  | $ | 2,202 |  |  | $ | 3,257 |  |
| Other Assets & Liabilities (7) |  |  |  |  |  |  |  |  |  | 37 |  |
| Total as of December 31, 2020 |  |  |  |  |  |  |  |  |  | $ | 3,294 |  |
| Public Equities: |  |  |  |  |  |  |  |  |  |  |
| Global Equities |  | $ | 29 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 29 |  |
| Global Equity Commingled Funds (1) |  | — |  |  | 141 |  |  | — |  |  | — |  |  | 141 |  |
| Enhanced Global Equities (2) |  | 3 |  |  | 3 |  |  | — |  |  | — |  |  | 6 |  |
| Global Equity Funds at net asset value (8) |  | — |  |  | — |  |  | — |  |  | 927 |  |  | 927 |  |
| Private Equities (3)(8) |  | — |  |  | — |  |  | 2 |  |  | 10 |  |  | 12 |  |
| Fixed Income Securities: |  |  |  |  |  |  |  |  |  |  |
| Governments |  | 8 |  |  | 35 |  |  | — |  |  | — |  |  | 43 |  |
| Corporate Bonds |  | — |  |  | 169 |  |  | — |  |  | — |  |  | 169 |  |
| Fixed Income Securities (8) |  | — |  |  | — |  |  | — |  |  | 1,449 |  |  | 1,449 |  |
| Real Estate (4)(8) |  | — |  |  | 3 |  |  | 12 |  |  | 6 |  |  | 21 |  |
| Other (5)(8) |  | — |  |  | 68 |  |  | — |  |  | 23 |  |  | 91 |  |
| Cash & Cash Equivalents (6)(8) |  | — |  |  | 3 |  |  | — |  |  | 44 |  |  | 47 |  |
| Subtotal |  | $ | 40 |  |  | $ | 422 |  |  | $ | 14 |  |  | $ | 2,459 |  |  | $ | 2,935 |  |
| Other Assets & Liabilities (7) |  |  |  |  |  |  |  |  |  | 18 |  |
| Total as of December 31, 2019 |  |  |  |  |  |  |  |  |  | $ | 2,953 |  |

[0001783180-21-000011:notes:193]
(1) Represents commingled funds that invest primarily in common stocks.

[0001783180-21-000011:notes:194]
(2) Represents enhanced equity separate account and commingled fund portfolios. A portion of the portfolio may include long-short market neutral and relative value strategies that invest in publicly traded, equity and fixed income securities, as well as derivatives of equity and fixed income securities and foreign currency.

[0001783180-21-000011:notes:195]
(3) Represents limited partner investments with general partners that primarily invest in debt and equity.

[0001783180-21-000011:notes:196]
(4) Represents investments in real estate, including commingled funds and directly held properties.

[0001783180-21-000011:notes:197]
(5) Represents insurance contracts and global balanced risk commingled funds consisting mainly of equity, bonds and some commodities.

[0001783180-21-000011:notes:198]
(6) Represents short-term commercial paper, bonds and other cash or cash-like instruments.

[0001783180-21-000011:notes:199]
(7) Represents trust receivables and payables that are not leveled.

[0001783180-21-000011:notes:200]
(8) In accordance with ASU 2015-07, Fair Value Measurement (Topic 820), certain investments that are measured at fair value using the net asset value per share (or its equivalent) practical expedient have not been classified in the fair value hierarchy. The fair value amounts presented in this table are intended to permit reconciliation of the fair value hierarchy to the amounts presented for the total pension plan assets.

[0001783180-21-000011:notes:201]
(9) Includes fixed income repurchase agreements entered into for purposes of pension asset and liability matching.

[0001783180-21-000011:notes:202]
Derivatives in the plan are primarily used to manage risk and gain asset class exposure while still maintaining liquidity. Derivative instruments mainly consist of fixed income repurchase agreements, interest rate swaps, total return swaps and currency forward contracts.

[0001783180-21-000011:notes:203]
The fair value measurement of plan assets using significant unobservable inputs (Level 3) was not significantly impacted in 2020 or 2019 by unrealized losses (gains), purchases, sales or settlements.

[0001783180-21-000011:notes:204]
Quoted market prices are used to value investments when available. Investments in securities traded on exchanges, including listed futures and options, are valued at the last reported sale prices on the last business day of the year or, if not available, the last reported bid prices. Fixed income securities are primarily measured using a market approach pricing methodology, whereby observable prices are obtained by market transactions involving identical or comparable securities of issuers with similar credit ratings. Over-the-counter securities and government obligations are valued at the bid prices or the average of the bid and ask prices on the last business day of the year from published sources or, if not available, from other sources considered reliable, including broker quotes. Temporary cash investments are stated at cost, which approximates fair value.

[0001783180-21-000011:notes:205]
We expect to make total contributions of approximately $28 million to our global defined benefit pension plans in 2021. Contributions do not reflect benefits to be paid directly from corporate assets.

[0001783180-21-000011:notes:206]
Benefit payments, including amounts to be paid from corporate assets, and reflecting expected future service, as appropriate, are expected to be paid as follows: $109 million in 2021, $113 million in 2022, $117 million in 2023, $119 million in 2024, $123 million in 2025 and $638 million from 2026 through 2030.

[0001783180-21-000011:notes:207]
Post-retirement Benefit Plans. The Company sponsors post-retirement benefit plans that provide both health and life insurance benefits to eligible retirees. The post-retirement plans are unfunded. The benefit obligation was $5 million and $6 million as of December 31, 2020 and 2019, respectively.

[0001783180-21-000011:notes:208]
Multiemployer Benefit Plans. The Company contributes to various domestic and foreign multiemployer defined benefit pension plans. The risks of participating in these multiemployer plans are different from those of single-employer plans in that assets contributed are pooled and may be used to provide benefits to employees of other participating employers. If a participating employer stops contributing to the plan, the unfunded obligations of the plan may be borne by the remaining participating employers.

[0001783180-21-000011:notes:209]
Our participation in these plans for the years ended December 31, 2020 and 2019 is outlined in the following table. Unless otherwise noted, the most recent Pension Protection Act zone status available in 2020 and 2019 is for the plan’s year-end as of December 31, 2019 and December 31, 2018, respectively. The zone status is based on information that we received from the plan and is certified by the plan’s actuary. Our significant plan is in the green zone which represents a plan that is at least 80% funded and does not require a financial improvement plan ("FIP") or a rehabilitation plan ("RP").

[0001783180-21-000011:notes:210]
| (dollars in millions) |  | EIN/Pension Plan Number |  | Zone Status |  | FIP/RP Status Pending Implemented |  | Contributions |  | Surcharge Imposed |  | Expiration Date of Collective-Bargaining Agreements |
| Pension Fund |  |  |  | 2020 |  | 2019 |  |  |  | 2020 |  | 2019 |  |  |  |  |
| Metal and technology industry pension plan |  | N/A |  | Green |  | Green |  | No |  | $ | 5 |  |  | $ | 6 |  |  | No |  | September 30, 2021 |
| Other funds |  |  |  |  |  |  |  |  |  | 15 |  |  | 14 |  |  |  |  |  |
|  |  |  |  |  |  |  |  |  |  | $ | 20 |  |  | $ | 20 |  |  |  |  |  |

[0001783180-21-000011:notes:211]
UTC Sponsored Defined Benefit Plans. Prior to the Separation and the Distribution, Carrier participated in defined benefit pension and post-retirement benefit plans sponsored by UTC, which were accounted for as multi-employer plans in the Consolidated Financial Statements in accordance with ASC Topic 715-30: Defined Benefit Plans – Pension and ASC Topic 715-60: Defined Benefit Plans – Other Post-retirement. ASC Topic 715: Compensation – Retirement Benefits provides that an employer that participates in a multi-employer defined benefit plan is not required to report a liability beyond the contributions currently due and unpaid to the plan. The Company's participation in these defined benefit pension and post-retirement benefits plans sponsored by UTC concluded in conjunction with the Separation and the Distribution.

[0001783180-21-000011:notes:212]
The expenses associated with these UTC plans were allocated to the Company and reported in Cost of products sold, Cost of services sold, Selling, general and administrative and Non-service pension benefit on the accompanying Consolidated Statement of Operations. The pension and post-retirement expenses were as follows:

[0001783180-21-000011:notes:213]
| (dollars in millions) | 2020 |  | 2019 |  | 2018 |
| Service cost | $ | — |  |  | $ | 18 |  |  | $ | 22 |  |
| Non-service pension benefit | (2) |  |  | (81) |  |  | (80) |  |
| Total net periodic benefit | $ | (2) |  |  | $ | (63) |  |  | $ | (58) |  |


## us-gaap:ScheduleOfMultiemployerPlansTableTextBlock

[0001783180-21-000011:notes:214]
The pension and post-retirement expenses were as follows:


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001783180-21-000011:notes:215]
STOCK-BASED COMPENSATION
Stock-Based Compensation. Prior to the Separation and the Distribution, Carrier participated in UTC’s long-term incentive plans ("LTIP"), which authorized various types of market and performance-based incentive awards, including stock options, stock appreciation rights, performance share units and restricted stock units, which were granted to eligible Carrier officers and employees. All awards granted under the UTC LTIP related to UTC common shares. For all periods prior to the Separation and the Distribution, stock-based compensation expense was allocated to Carrier from UTC based upon direct employee headcount.

[0001783180-21-000011:notes:216]
As a result of the Separation and the Distribution, outstanding and vested awards granted to employees under UTC's LTIP were converted into Carrier, Otis and UTC stock-based awards. Unvested awards held by Carrier employees and former employees were converted to Carrier stock-based awards. The ratio used to convert the UTC LTIP awards was intended to preserve the aggregate intrinsic value of each award immediately after the Separation and the Distribution when compared with the aggregate intrinsic value immediately prior to the Separation and the Distribution. All performance share units outstanding on the Distribution Date were converted to restricted stock units using payout metrics based on a combination of actual performance through the Distribution Date and the target for the remainder of the performance period. Due to the conversion, we expect to incur $14 million of incremental stock-based compensation expense to be recognized over the awards' remaining 1.4 year vesting period.

[0001783180-21-000011:notes:217]
Under Carrier's LTIP, the exercise price of awards is set on the grant date and, on a per share basis, may not be less than the fair market value of Carrier's common stock on that date. Stock appreciation rights and stock options have a term of ten years and a three-year vesting period, subject to limited exceptions. In the event of retirement, stock appreciation rights, stock options and restricted stock units held for more than one year may vest and become exercisable (if applicable), subject to certain terms and conditions. Performance share units vest based on performance relative to pre-established metrics and generally have a minimum three-year vesting period. In the event of retirement, performance share units held for more than one year remain eligible to vest based on actual performance relative to pre-established metrics.

[0001783180-21-000011:notes:218]
We measure the cost of stock-based compensation, including stock options, at fair value on the grant date net of expected forfeitures and amortize the cost over the award's vesting period.

[0001783180-21-000011:notes:219]
Stock-based compensation cost by award type are as follows:

[0001783180-21-000011:notes:220]
| (dollars in millions) | 2020 |  | 2019 |  | 2018 |
| Equity compensation costs - equity settled | $ | 77 |  |  | $ | 52 |  |  | $ | 44 |  |
| Equity compensation costs - cash settled | 11 |  |  | 6 |  |  | — |  |
| Total stock-based compensation cost | $ | 88 |  |  | $ | 58 |  |  | $ | 44 |  |
| Income tax benefit | $ | 9 |  |  | $ | 11 |  |  | $ | 10 |  |

[0001783180-21-000011:notes:221]
The stock-based compensation cost for the years ended December 31, 2019 and 2018 represent the amounts allocated to Carrier by UTC related to our direct employees. Our cash settled awards are classified as liability awards and are measured at fair value at each balance sheet date.

[0001783180-21-000011:notes:222]
For the years ended December 31, 2020, 2019 and 2018, we realized tax benefits resulting from the exercise of stock options of $12 million, $16 million and $7 million, respectively. In addition, for the years ended December 31, 2020, 2019 and

[0001783180-21-000011:notes:223]
2018, the associated tax benefit realized from the vesting of performance share units and restricted stock units was $9 million, $9 million and $2 million, respectively.

[0001783180-21-000011:notes:224]
As of December 31, 2020, there were $91 million of unrecognized stock-based compensation costs related to non-vested awards granted under the Carrier LTIP, which will be recognized ratably over the awards weighted-average vesting period of 2.3 years.

[0001783180-21-000011:notes:225]
Carrier LTIP activity for the year ended December 31, 2020 was as follows:

[0001783180-21-000011:notes:226]
|  |  | Stock Options and Stock Appreciation Rights |  | Performance Share Units |  | Restricted Stock Units |
|  |  |  |  | Average Price |  |  |  | Average Price |  |  |  | Average Price |
| (shares and units in thousands) |  | Shares |  | Per Share (1) |  | Units |  | Per Share (2) |  | Units |  | Per Share (2) |
| Outstanding as of April 3, 2020 (3) |  | 36,015 |  |  | $ | 19.90 |  |  | 68 |  |  | $ | 21.23 |  |  | 5,622 |  |  | $ | 21.37 |  |
| Granted |  | 3,921 |  |  | 17.57 |  |  | 728 |  |  | 18.23 |  |  | 523 |  |  | 21.43 |  |
| Vested/Exercised |  | (2,620) |  |  | 15.81 |  |  | — |  |  | — |  |  | (483) |  |  | 19.74 |  |
| Forfeited/Cancelled |  | (584) |  |  | 22.31 |  |  | (24) |  |  | 19.25 |  |  | (88) |  |  | 23.29 |  |
| Outstanding as of December 31, 2020 |  | 36,732 |  |  | $ | 19.91 |  |  | 772 |  |  | $ | 18.46 |  |  | 5,574 |  |  | $ | 21.57 |  |
| (1) Weighted-average exercise price |  |  |  |  |  |  |  |  |  |  |  |  |
| (2) Weighted-average grant date fair value |  |  |  |  |  |  |  |  |  |  |  |  |
| (3) Effective date of conversion upon the Separation and the Distribution |

[0001783180-21-000011:notes:227]
The weighted-average grant date fair value of stock options and stock appreciation rights granted for the years ended December 31, 2020, 2019 and 2018 was $4.67, $21.02 and $20.25, respectively. The weighted-average grant date fair value of performance share units, which vest upon achieving certain performance metrics, granted for the years ended December 31, 2020, 2019 and 2018 was $18.23, $112.76 and $131.42, respectively. The weighted-average grant date fair value of restricted stock units, granted for the years ended December 31, 2020, 2019 and 2018 was $21.43, $123.37 and $124.34, respectively. The total intrinsic value (which is the amount by which the stock price exceeded the exercise price on the date of exercise) of stock options and stock appreciation rights exercised for the years ended December 31, 2020, 2019 and 2018 was $47 million, $80 million and $43 million, respectively. The aggregate fair value (which is based on the stock price at vesting) of performance share units and restricted stock units vested was $15 million, $45 million and $14 million for the years ended December 31, 2020, 2019 and 2018, respectively.

[0001783180-21-000011:notes:228]
The following table summarizes outstanding Carrier LTIP awards that are vested and expected to vest (adjusted for expected forfeitures) and that are exercisable as of December 31, 2020:

[0001783180-21-000011:notes:229]
|  |  | Equity Awards Vested and Expected to Vest |  | Equity Awards That Are Exercisable |
| (shares and units in thousands; aggregate intrinsic value in dollars in millions) |  | Awards |  | Average Price Per Share (1) |  | Aggregate Intrinsic Value |  | Remaining Life (2) |  | Awards |  | Average Price Per Share (1) |  | Aggregate Intrinsic Value |  | Remaining Life (2) |
| Stock Options/ Stock Appreciation Rights |  | 35,553 |  |  | $ | 19.87 |  |  | $ | 635 |  |  | 6.7 |  | 14,678 |  |  | $ | 17.15 |  |  | $ | 302 |  |  | 4.1 |
| Performance Share Units/ Restricted Stock Units |  | 6,072 |  |  |  |  | $ | 229 |  |  | 1.7 |  |  |  |  |  |  |  |  |

[0001783180-21-000011:notes:230]
(1) Weighted-average exercise price per share

[0001783180-21-000011:notes:231]
(2) Weighted-average remaining contractual term in years for stock options and stock appreciation rights; weighted-average remaining vesting period in years for performance share units and restricted stock units

[0001783180-21-000011:notes:232]
Stock Options and Stock Appreciation Rights

[0001783180-21-000011:notes:233]
The Company utilizes a binomial lattice model to determine the fair value of our stock options and stock appreciation rights. The binomial lattice model relies on certain assumptions to estimate fair value. The following table indicates the assumptions used in estimating fair value for the years ended December 31, 2020, 2019 and 2018:

[0001783180-21-000011:notes:234]
|  |  | 2020 |  | 2019 |  | 2018 |
| Volatility |  | 32.1% to 35.6% |  | 18.8% to 19.7% |  | 17.5% to 21.1% |
| Expected term (in years) |  | 7.0 |  | 6.5 to 6.6 |  | 6.5 to 6.6 |
| Expected dividend yield |  | 1.4% to 2.0% |  | 2.4% |  | 2.2% |
| Range of risk-free rates |  | 0.1% to 1.0% |  | 2.3% to 2.7% |  | 1.3% to 2.7% |

[0001783180-21-000011:notes:235]
The assumptions for 2019 and 2018 were determined by UTC based on UTC's stock price performance. Carrier has limited historical trading data and used peer group data to estimate expected volatility for the 2020 awards. Carrier used historical Carrier employee data, including data prior to the Separation and the Distribution, to estimate expected term. The expected dividend yield is consistent with management's expectations. The risk-free rate is based on the term structure of interest rates at the time the awards were granted.

[0001783180-21-000011:notes:236]
Performance Share Units

[0001783180-21-000011:notes:237]
Performance share units are considered contingently issuable shares and are included in diluted earnings per share based upon the number of shares that would be awarded assuming the performance conditions existing at the end of the reporting period continued until the end of the performance period.

[0001783180-21-000011:notes:238]
Carrier utilizes a Monte Carlo simulation approach based on a three-year measurement period to determine the fair value of performance share units. This approach includes the use of assumptions regarding the future performance of the Company’s stock and those of a peer group. Those assumptions include expected volatility, risk-free interest rates, correlations and dividend yield. Dividends do not accrue on the performance share units during the performance period.

[0001783180-21-000011:notes:239]
Restricted Stock Units

[0001783180-21-000011:notes:240]
Restricted stock units' fair value is based on the closing market price of Carrier's common stock on the respective dates of the grants. Dividends accrue on the restricted stock units during the vesting period and are paid in shares of Carrier's common stock.


## us-gaap:OtherLiabilitiesDisclosureTextBlock

[0001783180-21-000011:notes:241]
OTHER LONG-TERM LIABILITIES
Other long-term liabilities are as follows:

[0001783180-21-000011:notes:242]
| (dollars in millions) |  | 2020 |  | 2019 |
| Warranty related (Note 23) |  | $ | 323 |  |  | $ | 288 |  |
| Asbestos reserves (Note 25) |  | 228 |  |  | 249 |  |
| Environmental reserves (Note 25) |  | 213 |  |  | 203 |  |
| Asset retirement obligations (Note 25) |  | 76 |  |  | 74 |  |
| Self-insurance reserves (Note 25) |  | 85 |  |  | 66 |  |
| Tax obligations (Note 19) |  | 459 |  |  | — |  |
| Other |  | 340 |  |  | 303 |  |
| Other long-term liabilities |  | $ | 1,724 |  |  | $ | 1,183 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001783180-21-000011:notes:243]
ACCUMULATED OTHER COMPREHENSIVE LOSS 
A summary of the changes in each component of Accumulated other comprehensive loss, net of tax is as follows:

[0001783180-21-000011:notes:244]
| (dollars in millions) | Foreign Currency Translation |  | Defined Benefit Pension and Post-retirement Plans |  |  |  |  |  | Unrealized Hedging Gains (Losses) |  | Accumulated Other Comprehensive Loss |
| Balance as of January 1, 2018 | $ | (393) |  |  | $ | (222) |  |  |  |  |  |  | $ | (2) |  |  | $ | (617) |  |
| Other comprehensive loss before reclassifications, net | (441) |  |  | (209) |  |  |  |  |  |  | — |  |  | (650) |  |
| Amounts reclassified, pre-tax | — |  |  | 17 |  |  |  |  |  |  | 2 |  |  | 19 |  |
| Tax benefit reclassified | — |  |  | 33 |  |  |  |  |  |  | — |  |  | 33 |  |
| Balance as of December 31, 2018 | $ | (834) |  |  | $ | (381) |  |  |  |  |  |  | $ | — |  |  | $ | (1,215) |  |
| Other comprehensive income (loss) before reclassifications, net | 52 |  |  | (109) |  |  |  |  |  |  | — |  |  | (57) |  |
| Amounts reclassified, pre-tax | 2 |  |  | 11 |  |  |  |  |  |  | — |  |  | 13 |  |
| Tax benefit reclassified | — |  |  | 15 |  |  |  |  |  |  | — |  |  | 15 |  |
| ASU 2018-02 adoption impact | — |  |  | (9) |  |  |  |  |  |  | — |  |  | (9) |  |
| Balance as of December 31, 2019 | $ | (780) |  |  | $ | (473) |  |  |  |  |  |  | $ | — |  |  | $ | (1,253) |  |
| Other comprehensive income before reclassifications, net | 589 |  |  | 2 |  |  |  |  |  |  | — |  |  | 591 |  |
| Amounts reclassified, pre-tax | — |  |  | (105) |  |  |  |  |  |  | — |  |  | (105) |  |
| Tax benefit reclassified | — |  |  | 22 |  |  |  |  |  |  | — |  |  | 22 |  |
| Balance as of December 31, 2020 | $ | (191) |  |  | $ | (554) |  |  |  |  |  |  | $ | — |  |  | $ | (745) |  |

[0001783180-21-000011:notes:245]
Amounts reclassified related to defined benefit pension and post-retirement plans include amortization of prior service costs and recognized actuarial net losses. These costs are recorded as components of net periodic pension cost for each period presented. See Note 13 – Employee Benefit Plans for additional information.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001783180-21-000011:notes:246]
RESTRUCTURING COSTS 
We recorded net pre-tax restructuring costs for new and ongoing restructuring actions as follows:

[0001783180-21-000011:notes:247]
| (dollars in millions) | 2020 |  | 2019 |  | 2018 |
| HVAC | $ | 7 |  |  | $ | 56 |  |  | $ | 20 |  |
| Refrigeration | 12 |  |  | 14 |  |  | 23 |  |
| Fire & Security | 28 |  |  | 53 |  |  | 34 |  |
| Eliminations and other | 2 |  |  | 3 |  |  | 3 |  |
| Total restructuring costs | $ | 49 |  |  | $ | 126 |  |  | $ | 80 |  |

[0001783180-21-000011:notes:248]
Restructuring charges incurred primarily relate to actions initiated for the years ended December 31, 2020, 2019 and 2018 and were recorded as follows:

[0001783180-21-000011:notes:249]
| (dollars in millions) | 2020 |  | 2019 |  | 2018 |
| Cost of sales | $ | 20 |  |  | $ | 36 |  |  | $ | 36 |  |
| Selling, general and administrative | 29 |  |  | 90 |  |  | 44 |  |
| Total restructuring costs | $ | 49 |  |  | $ | 126 |  |  | $ | 80 |  |

[0001783180-21-000011:notes:250]
For the year ended December 31, 2020, we had cash outflows totaling $55 million related to restructuring activities.

[0001783180-21-000011:notes:251]
2020 Actions. For the year ended December 31, 2020, we recorded net pre-tax restructuring costs of $47 million for restructuring actions initiated in 2020, consisting of $21 million in Cost of products sold and Cost of services sold and $26 million in Selling, general and administrative. The 2020 actions relate to ongoing cost reduction efforts, including workforce reductions and the consolidation of field operations. We are targeting to complete the majority of the remaining actions in 2021.

[0001783180-21-000011:notes:252]
The following table summarizes the accrual balance and utilization for the 2020 restructuring actions:

[0001783180-21-000011:notes:253]
| (dollars in millions) | Severance |  | Facility Exit, Lease Termination and Other Costs |  | Total |
| Restructuring accrual as of January 1, 2020 | $ | — |  |  | $ | — |  |  | $ | — |  |
| Net pre-tax restructuring costs | 39 |  |  | 8 |  |  | 47 |  |
| Utilization, foreign exchange and other costs | (14) |  |  | (6) |  |  | (20) |  |
| Balance as of December 31, 2020 | $ | 25 |  |  | $ | 2 |  |  | $ | 27 |  |

[0001783180-21-000011:notes:254]
The following table summarizes expected, incurred and remaining costs for the 2020 restructuring actions by segment:

[0001783180-21-000011:notes:255]
| (dollars in millions) | Expected Costs |  | Costs Incurred During 2020 |  |  |  | Remaining Costs as of December 31, 2020 |
| HVAC | $ | 22 |  |  | $ | (7) |  |  |  |  | $ | 15 |  |
| Refrigeration | 16 |  |  | (14) |  |  |  |  | 2 |  |
| Fire & Security | 32 |  |  | (24) |  |  |  |  | 8 |  |
| Eliminations and other | 5 |  |  | (2) |  |  |  |  | 3 |  |
| Total | $ | 75 |  |  | $ | (47) |  |  |  |  | $ | 28 |  |

[0001783180-21-000011:notes:256]
2019 Actions. For the year ended December 31, 2020, we recorded net pre-tax restructuring costs totaling $2 million for restructuring actions initiated in 2019, consisting of $0 million in Cost of products sold and Cost of services sold and $2 million in Selling, general and administrative, respectively. The 2019 actions relate to ongoing cost reduction efforts, including workforce reductions and consolidation of field operations. The following table summarizes the accrual balances and utilization for the 2019 restructuring actions:

[0001783180-21-000011:notes:257]
| (dollars in millions) | Severance |  | Facility Exit, Lease Termination and Other Costs |  | Total |
| Restructuring accrual as of January 1, 2019 | $ | — |  |  | $ | — |  |  | $ | — |  |
| Net pre-tax restructuring costs | 102 |  |  | 8 |  |  | 110 |  |
| Utilization, foreign exchange and other costs | (60) |  |  | (7) |  |  | (67) |  |
| Balance as of December 31, 2019 | $ | 42 |  |  | $ | 1 |  |  | $ | 43 |  |
| Net pre-tax restructuring costs | 1 |  |  | 1 |  |  | 2 |  |
| Utilization, foreign exchange and other costs | (28) |  |  | (1) |  |  | (29) |  |
| Balance as of December 31, 2020 | $ | 15 |  |  | $ | 1 |  |  | $ | 16 |  |

[0001783180-21-000011:notes:258]
The following table summarizes expected, incurred and remaining costs for the 2019 restructuring actions by segment:

[0001783180-21-000011:notes:259]
| (dollars in millions) | ExpectedCosts |  | Costs Incurred During 2019 |  | Costs Incurred During 2020 |  |  |  | Remaining Costs as of December 31, 2020 |
| HVAC | $ | 52 |  |  | $ | (51) |  |  | $ | — |  |  |  |  | $ | 1 |  |
| Refrigeration | 13 |  |  | (14) |  |  | 1 |  |  |  |  | — |  |
| Fire & Security | 47 |  |  | (43) |  |  | (3) |  |  |  |  | 1 |  |
| Eliminations and other | 2 |  |  | (2) |  |  | — |  |  |  |  | — |  |
| Total | $ | 114 |  |  | $ | (110) |  |  | $ | (2) |  |  |  |  | $ | 2 |  |

[0001783180-21-000011:notes:260]
2018 and Prior Actions. For the year ended December 31, 2020, we recorded net pre-tax restructuring costs totaling $0 million for restructuring actions initiated in 2018 and prior. As of December 31, 2020 and 2019, we had approximately $6 million and $23 million, respectively, of accrual balances remaining related to 2018 and prior actions.


## us-gaap:ScheduleOfRestructuringReserveByTypeOfCostTextBlock

[0001783180-21-000011:notes:261]
We recorded net pre-tax restructuring costs for new and ongoing restructuring actions as follows:


## us-gaap:OtherIncomeAndOtherExpenseDisclosureTextBlock

[0001783180-21-000011:notes:262]
OTHER INCOME (EXPENSE), NET

[0001783180-21-000011:notes:263]
| (dollars in millions) | 2020 |  | 2019 |  | 2018 |
| Transaction gains | $ | 1,123 |  |  | $ | — |  |  | $ | 799 |  |
| Impairment charge on minority-owned joint venture investments | (72) |  |  | (108) |  |  | — |  |
| Other | (45) |  |  | 106 |  |  | 138 |  |
| Other income (expense), net | $ | 1,006 |  |  | $ | (2) |  |  | $ | 937 |  |

[0001783180-21-000011:notes:264]
The transaction gain recorded for the year ended December 31, 2020 relates to the sale of shares in Beijer (see Note 6 – Equity Method Investments and Related Parties for additional information) and the transaction gain for the year ended December 31, 2018 relates to the sale of Taylor. See Note 10 – Business Acquisitions, Dispositions, Goodwill and Intangible Assets for additional information.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001783180-21-000011:notes:265]
INCOME TAXES 
Income Before Income Taxes. The sources of income from operations before income taxes are as follows:

[0001783180-21-000011:notes:266]
| (dollars in millions) | 2020 |  | 2019 |  | 2018 |
| United States | $ | 915 |  |  | $ | 1,460 |  |  | $ | 2,360 |  |
| Foreign | 1,940 |  |  | 1,212 |  |  | 1,482 |  |
| Total | $ | 2,855 |  |  | $ | 2,672 |  |  | $ | 3,842 |  |

[0001783180-21-000011:notes:267]
Provision for Income Taxes. The income tax expense (benefit) consisted of the following components:

[0001783180-21-000011:notes:268]
| (dollars in millions) | 2020 |  | 2019 |  | 2018 |
| Current: |  |  |  |  |  |
| United States: |  |  |  |  |  |
| Federal | $ | 434 |  |  | $ | 262 |  |  | $ | 479 |  |
| State | 74 |  |  | 72 |  |  | 119 |  |
| Foreign | 244 |  |  | 305 |  |  | 342 |  |
|  | 752 |  |  | 639 |  |  | 940 |  |
| Future: |  |  |  |  |  |
| United States: |  |  |  |  |  |
| Federal | 13 |  |  | (14) |  |  | (37) |  |
| State | 6 |  |  | (2) |  |  | 24 |  |
| Foreign | 78 |  |  | (106) |  |  | 146 |  |
|  | 97 |  |  | (122) |  |  | 133 |  |
| Income tax expense | $ | 849 |  |  | $ | 517 |  |  | $ | 1,073 |  |

[0001783180-21-000011:notes:269]
Reconciliation of Effective Income Tax Rate. The differences between the effective income tax rate and the statutory U.S. federal income tax rate are as follows:

[0001783180-21-000011:notes:270]
|  | 2020 |  | 2019 |  | 2018 |
| Statutory U.S. federal income tax rate | 21.0 | % |  | 21.0 | % |  | 21.0 | % |
| State income tax | 1.7 |  |  | 2.5 |  |  | 2.6 |  |
| Tax on international activities | 4.2 |  |  | 3.3 |  |  | 4.4 |  |
| Separation impact | 3.4 |  |  | (0.7) |  |  | — |  |
| Tax audit settlements | — |  |  | (5.6) |  |  | — |  |
| Other | (0.6) |  |  | (1.1) |  |  | (0.1) |  |
| Effective income tax rate | 29.7 | % |  | 19.4 | % |  | 27.9 | % |

[0001783180-21-000011:notes:271]
The effective tax rate for the year ended December 31, 2020 reflects a $51 million charge related to a valuation allowance recorded against a United Kingdom tax loss and a credit carry forward and a charge of $46 million resulting from Carrier's decision to no longer permanently reinvest certain pre-2018 unremitted non-U.S. earnings. These items were impacted by the Separation and are included in "Separation impact" in the previous table.

[0001783180-21-000011:notes:272]
The effective tax rate for the year ended December 31, 2019 reflects a net tax benefit of $149 million as a result of the filing by a Carrier subsidiary to participate in an amnesty program offered by the Italian Tax Authority and the conclusion of an audit by the IRS for UTC's 2014, 2015 and 2016 tax years.

[0001783180-21-000011:notes:273]
The effective tax rate for the year ended December 31, 2018 reflects a net tax charge of $102 million as a result of UTC ceasing to assert that it intended to reinvest certain undistributed earnings of its international subsidiaries.

[0001783180-21-000011:notes:274]
Deferred Tax Assets and Liabilities. Future income taxes represent the tax effects of transactions, which are reported in different periods for tax and U.S. GAAP purposes. These amounts consist of the tax effects of differences between tax and U.S. GAAP that are expected to be reversed in the future and tax carryforwards. Future income tax benefits and payables within the same tax paying component of a particular jurisdiction are offset for presentation in the Consolidated Balance Sheet.

[0001783180-21-000011:notes:275]
The tax effects of temporary differences and tax carryforwards which give rise to future income tax benefits and payables as of December 31, 2020 and 2019 are as follows:

[0001783180-21-000011:notes:276]
| (dollars in millions) | 2020 |  | 2019 |
| Future income tax benefits: |  |  |  |
| Insurance and employee benefits | $ | 109 |  |  | $ | 76 |  |
| Other assets basis differences | 152 |  |  | 128 |  |
| Other liabilities basis differences | 487 |  |  | 556 |  |
| Tax loss carryforward | 258 |  |  | 236 |  |
| Tax credit carryforward | 63 |  |  | 55 |  |
| Valuation allowances | (231) |  |  | (128) |  |
|  | $ | 838 |  |  | $ | 923 |  |
| Future income tax payables: |  |  |  |
| Goodwill and intangible assets | 411 |  |  | 392 |  |
| Other asset basis differences | 336 |  |  | 297 |  |
|  | $ | 747 |  |  | $ | 689 |  |

[0001783180-21-000011:notes:277]
Valuation allowances have been established primarily for tax credit carryforwards, tax loss carryforwards and certain foreign temporary differences to reduce future income tax benefits to expected realizable amounts.

[0001783180-21-000011:notes:278]
Tax Credit and Loss Carryforwards. As of December 31, 2020, tax credit carryforwards and tax loss carryforwards were as follows:

[0001783180-21-000011:notes:279]
| (dollars in millions) | Tax Loss Carryforwards |  | Tax Credit Carryforwards |
| Expiration period: |  |  |  |
| 2021-2025 | $ | 126 |  |  | $ | 7 |  |
| 2026-2030 | 53 |  |  | 5 |  |
| 2031-2040 | 17 |  |  | 4 |  |
| Indefinite | 949 |  |  | 47 |  |
| Total | $ | 1,145 |  |  | $ | 63 |  |

[0001783180-21-000011:notes:280]
The Company assesses the realizability of our deferred tax assets on a quarterly basis through an analysis of potential sources of future taxable income, including prior year taxable income available to absorb a carryback of tax losses, reversals of existing taxable temporary differences, tax planning strategies and forecasts of taxable income. The Company considers all negative and positive evidence, including the weight of the evidence, to determine if valuation allowances against deferred tax assets are required. The Company maintains valuation allowances against certain deferred tax assets, primarily in Non-U.S. jurisdictions.

[0001783180-21-000011:notes:281]
Unrecognized Tax Benefits. As of December 31, 2020, Carrier had unrecognized tax benefits of $162 million, all of which, if recognized, would impact Carrier's effective tax rate. A reconciliation of the beginning and ending amounts of unrecognized tax benefits and related interest expense is as follows:

[0001783180-21-000011:notes:282]
| (dollars in millions) | 2020 |  | 2019 |  | 2018 |
| Balance at beginning of period | $ | 166 |  |  | $ | 316 |  |  | $ | 290 |  |
| Additions for tax positions related to the current year | 22 |  |  | 30 |  |  | 27 |  |
| Additions for tax positions of prior years | 14 |  |  | 14 |  |  | 3 |  |
| Reductions for tax positions of prior years (1) | (40) |  |  | (19) |  |  | (4) |  |
| Settlements | — |  |  | (175) |  |  | — |  |
| Balance at end of period | $ | 162 |  |  | $ | 166 |  |  | $ | 316 |  |
| Gross interest expense related to unrecognized tax benefits | $ | 6 |  |  | $ | 8 |  |  | $ | 8 |  |
| Total accrued interest balance at end of period | $ | 25 |  |  | $ | 25 |  |  | $ | 33 |  |

[0001783180-21-000011:notes:283]
________________

[0001783180-21-000011:notes:284]
(1) Includes an adjustment of $37 million recorded in UTC Net investment for the year ended December 31, 2020 for tax positions of prior years.

[0001783180-21-000011:notes:285]
Carrier conducts business globally and, as a result, Carrier and our subsidiaries file income tax returns in the U.S. federal, various state and foreign jurisdictions. In certain jurisdictions, Carrier’s operations were included in UTC's combined tax returns for the periods through the Separation and the Distribution. The IRS commenced an audit of UTC's tax years 2017 and 2018 in the second quarter of 2020. In the normal course of business, the Company is subject to examination by taxing authorities throughout the world, including U.S., Australia, Belgium, Canada, China, Czech Republic, France, Germany, Hong Kong, India, Italy, Mexico, the Netherlands, Singapore and the United Kingdom. Carrier is no longer subject to U.S. federal income tax examination for years prior to 2017 and, with few exceptions, is no longer subject to U.S. state and local and foreign income tax examinations for tax years before 2010.

[0001783180-21-000011:notes:286]
During the second quarter of 2019, a subsidiary of Carrier that was engaged in litigation before the Italian Supreme Court filed to participate in the Italian amnesty program. In addition, during the second quarter of 2019, the IRS completed its review of UTC’s 2014, 2015 and 2016 tax years and certain U.S. state income tax exams concluded. As a result of the amnesty filing in Italy and the conclusion of the IRS and U.S. state audits, Carrier recognized a non-cash gain of approximately $166 million, including pre-tax interest of approximately $16 million.

[0001783180-21-000011:notes:287]
The U.S. Treasury finalized the GILTI High Tax Exclusion ("HTE") regulations in the third quarter of 2020. The HTE regulations permit an election to apply the regulations retroactively to the years 2018 and 2019. In accordance with the TMA, if the HTE election were made on an amended return by the Company for 2018 and 2019, UTC would be entitled to any federal

[0001783180-21-000011:notes:288]
tax benefit. On a stand-alone basis, the Company did not record a benefit from the HTE regulation associated with the years 2018 and 2019 and the amount would not have been material to the Consolidated Statement of Operations.

[0001783180-21-000011:notes:289]
As a result of the TCJA, Carrier no longer intends to reinvest certain undistributed earnings of our international subsidiaries that have been previously taxed in the U.S. As such, Carrier has recorded the taxes associated with the future remittance of these earnings. For the remainder of Carrier's undistributed international earnings, unless tax effective to repatriate, Carrier intends to continue to permanently reinvest these earnings. As of December 31, 2020 such undistributed earnings were approximately $7 billion, excluding other comprehensive income amounts. It is not practicable to estimate the amount of tax that might be payable on the remaining amounts.

[0001783180-21-000011:notes:290]
We relied upon certain historical tax return information and allocations that were provided by UTC in the computation of certain U.S. deferred tax assets and liabilities. These deferred tax items could change as a result of the finalization of our 2020 pre-separation period U.S. income tax returns and these changes could be material.

[0001783180-21-000011:notes:291]
Pursuant to the TMA, Carrier is required to make payments to UTC representing Carrier's portion of UTC's remaining net tax liability attributable to U.S. income tax on previously undistributed earnings of Carrier's international subsidiaries resulting from the passage of the TCJA. The amounts computed on a separate company basis of approximately $68 million recorded within Accrued liabilities and $701 million recorded within Future income tax obligations were adjusted through UTC Net investment upon the Separation and the Distribution. For the year ended December 31, 2020, $6 million of this obligation was paid, resulting in an obligation to UTC of $453 million recorded within Other Long-Term Liabilities as of December 31, 2020. The remaining obligation is expected to be settled in five annual payments, beginning in April of 2022.

[0001783180-21-000011:notes:292]
After the Separation and the Distribution, Carrier has been entitled to unrecognized tax benefits to the extent the item relates exclusively to Carrier in accordance with the TMA. The change from a separate company to stand-alone basis resulted in a $37 million decrease to Future income tax obligations which were recorded through UTC Net investment.

[0001783180-21-000011:notes:293]
In the ordinary course of business, there is inherent uncertainty in quantifying our income tax positions. We assess our income tax positions and record tax benefits for all years subject to examination based upon management’s evaluation of the facts, circumstances and information available at the reporting date. It is reasonably possible that a net decrease in unrecognized tax benefits from $10 million to $35 million may occur within 12 months as a result of additional worldwide uncertain tax positions, the revaluation of uncertain tax positions arising from examinations, appeals, court decisions or the closure of tax statutes.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001783180-21-000011:notes:294]
FINANCIAL INSTRUMENTS
We enter into derivative instruments primarily for risk management purposes. We operate internationally, and in the normal course of business, we are exposed to fluctuations in foreign exchange rates. These fluctuations can increase the costs of operating our business. We have used derivative instruments, such as forward contracts, to manage certain foreign currency risk.

[0001783180-21-000011:notes:295]
The following table summarizes the fair value and presentation in the Consolidated Balance Sheet for derivative instruments:

[0001783180-21-000011:notes:296]
| (dollars in millions) | Balance Sheet Location |  | 2020 |  | 2019 |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |
| Foreign exchange contracts | Asset Derivatives: |  |  |  |  |
|  | Other assets, current |  | $ | 17 |  |  | $ | — |  |
|  | Liability Derivatives: |  |  |  |  |
|  | Accrued liabilities |  | $ | (5) |  |  | $ | — |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001783180-21-000011:notes:297]
FAIR VALUE MEASUREMENTS
In accordance with the provisions of ASC Topic 820: Fair Value Measurement, the following tables provide the valuation hierarchy classification of assets and liabilities that are recorded at fair value and measured on a recurring basis in our Consolidated Balance Sheet:

[0001783180-21-000011:notes:298]
| (dollars in millions) |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |
| December 31, 2020 |  |  |  |  |  |  |  |  |
| Recurring fair value measurement: |  |  |  |  |  |  |  |  |
| Money market mutual funds |  | $ | 38 |  | (1) | $ | — |  |  | $ | 38 |  |  | $ | — |  |
| Derivative assets |  | $ | 17 |  |  | $ | — |  |  | $ | 17 |  |  | $ | — |  |
| Derivative liabilities |  | $ | (5) |  |  | $ | — |  |  | $ | (5) |  |  | $ | — |  |

[0001783180-21-000011:notes:299]
(1) Included in Cash and cash equivalents on the accompanying Consolidated Balance Sheet.

[0001783180-21-000011:notes:300]
Valuation Techniques. Our derivative assets and liabilities are measured at fair value using internal models based on observable market inputs, including forward rate, interest rate, contract rate and discount rate.

[0001783180-21-000011:notes:301]
The following table provides the carrying amounts and fair values of financial instruments that are not recorded at fair value in our Consolidated Balance Sheet:

[0001783180-21-000011:notes:302]
|  |  | 2020 |  | 2019 |  |
| (dollars in millions) |  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  |
| Current and long-term debt (excluding finance leases) |  | $ | 10,221 |  |  | $ | 11,115 |  |  | $ | 313 |  |  | $ | 313 |  |  |

[0001783180-21-000011:notes:303]
The following tables provide the valuation hierarchy classification of assets and liabilities that are not carried at fair value in our Consolidated Balance Sheet:

[0001783180-21-000011:notes:304]
| 2020 |  |  |  |  |  |  |  |  |
| (dollars in millions) |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |
| Current and long-term debt (excluding finance leases) |  | $ | 11,115 |  |  | $ | 10,811 |  |  | $ | — |  |  | $ | 304 |  |

[0001783180-21-000011:notes:305]
| 2019 |  |  |  |  |  |  |  |  |
| (dollars in millions) |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |
| Current and long-term debt (excluding finance leases) |  | $ | 313 |  |  | $ | — |  |  | $ | — |  |  | $ | 313 |  |

[0001783180-21-000011:notes:306]
Valuation Techniques. As of December 31, 2020, the project financing obligations included in Long-term debt approximate their fair value. For the years ended December 31, 2020 and 2019 there were no transfers in or out of levels 1, 2 or 3.

[0001783180-21-000011:notes:307]
The following table presents changes in Level 3 liabilities not measured at fair value on a recurring basis:

[0001783180-21-000011:notes:308]
| (dollars in millions) |  | 2020 |  | 2019 |  |  |  |
| Fair value as of January 1 |  | $ | 313 |  |  | $ | 291 |  |  |  |  |
| Issuances, including interest on project financing obligations |  | 152 |  |  | 160 |  |  |  |  |
| Settlements |  | (161) |  |  | (138) |  |  |  |  |
| Fair value as of December 31 |  | $ | 304 |  |  | $ | 313 |  |  |  |  |


## us-gaap:FairValueAssetsAndLiabilitiesMeasuredOnRecurringAndNonrecurringBasisTableTextBlock

[0001783180-21-000011:notes:309]
In accordance with the provisions of ASC Topic 820: Fair Value Measurement, the following tables provide the valuation hierarchy classification of assets and liabilities that are recorded at fair value and measured on a recurring basis in our Consolidated Balance Sheet:


## us-gaap:LesseeOperatingLeasesTextBlock

[0001783180-21-000011:notes:310]
LEASES 
Operating lease expense for the years ended December 31, 2020 and 2019 was $197 million and $206 million, respectively.

[0001783180-21-000011:notes:311]
Supplemental cash flow information related to operating leases was as follows:

[0001783180-21-000011:notes:312]
| (dollars in millions) |  | 2020 |  | 2019 |
| Operating cash flows for measurement of operating lease liabilities |  | $ | (213) |  |  | $ | (201) |  |
| Operating lease right-of-use assets obtained in exchange for operating lease obligations |  | $ | 169 |  |  | $ | 136 |  |

[0001783180-21-000011:notes:313]
Operating lease right-of-use assets and liabilities are reflected on our Consolidated Balance Sheet as follows:

[0001783180-21-000011:notes:314]
| (dollars in millions except lease term and discount rate) |  | 2020 |  | 2019 |
| Operating lease right-of-use assets |  | $ | 788 |  |  | $ | 832 |  |
| Accrued liabilities |  | $ | (161) |  |  | $ | (163) |  |
| Operating lease liabilities |  | (642) |  |  | (682) |  |
| Total operating lease liabilities |  | $ | (803) |  |  | $ | (845) |  |

[0001783180-21-000011:notes:315]
Supplemental balance sheet information related to operating leases was as follows:

[0001783180-21-000011:notes:316]
|  |  | 2020 |  | 2019 |
| Weighted-Average Remaining Lease Term (in years) |  | 7.7 |  | 8.0 |
| Weighted-Average Discount Rate |  | 3.4 | % |  | 3.6 | % |

[0001783180-21-000011:notes:317]
Undiscounted maturities of operating lease liabilities, including options to extend lease terms that are reasonably certain of being exercised, as of December 31, 2020 are as follows:

[0001783180-21-000011:notes:318]
| (dollars in millions) |  |  |
| 2021 |  | $ | 180 |  |
| 2022 |  | 152 |  |
| 2023 |  | 127 |  |
| 2024 |  | 102 |  |
| 2025 |  | 80 |  |
| Thereafter |  | 298 |  |
| Total undiscounted lease payments |  | 939 |  |
| Less: imputed interest |  | (136) |  |
| Total discounted lease payments |  | $ | 803 |  |

[0001783180-21-000011:notes:319]
Prior to the adoption of the New Lease Accounting Standard, rent expense was $167 million for the year ended December 31, 2018 and rental commitments on an undiscounted basis as of December 31, 2018 under long-term non-cancellable operating leases were payable as follows:

[0001783180-21-000011:notes:320]
| (dollars in millions) | 2019 |  | 2020 |  | 2021 |  | 2022 |  | 2023 |  | Thereafter |
| Operating lease commitments | $ | 189 |  |  | $ | 146 |  |  | $ | 110 |  |  | $ | 77 |  |  | $ | 52 |  |  | $ | 111 |  |


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001783180-21-000011:notes:321]
GUARANTEES 
The Company has commitments and performance guarantees, including energy savings guarantees, under long-term service and maintenance contracts related to our air conditioning equipment and system controls. Liabilities recorded on the Consolidated Balance Sheet related to these guarantees were not significant during the historical periods presented.

[0001783180-21-000011:notes:322]
The Company also has obligations arising from sales of certain businesses and assets, including those from representations and warranties and related indemnities for, among other matters, environmental, health and safety (including asbestos-related), tax and employment matters. The maximum potential payment related to these obligations is not a specified amount, as a

[0001783180-21-000011:notes:323]
number of the obligations do not contain financial caps. The carrying amount of liabilities related to these obligations was $17 million and $10 million as of December 31, 2020 and 2019, respectively, recorded within Accrued liabilities on the accompanying Consolidated Balance Sheet. See Note 25 – Commitments and Contingent Liabilities for additional information.

[0001783180-21-000011:notes:324]
The changes in the carrying amount of service and product warranties and product performance guarantees, included in Accrued liabilities on the accompanying Consolidated Balance Sheet are as follows:

[0001783180-21-000011:notes:325]
| (dollars in millions) | 2020 |  | 2019 |
| Balance as of January 1 | $ | 488 |  |  | $ | 473 |  |
| Warranties, performance guarantees issued and changes in estimated liability | 167 |  |  | 182 |  |
| Settlements made | (146) |  |  | (164) |  |
| Other | 5 |  |  | (3) |  |
| Balance as of December 31 | $ | 514 |  |  | $ | 488 |  |


## us-gaap:CashFlowSupplementalDisclosuresTextBlock

[0001783180-21-000011:notes:326]
SUPPLEMENTAL CASH FLOW INFORMATION

[0001783180-21-000011:notes:327]
| (dollars in millions) | 2020 |  | 2019 |  | 2018 |
| Interest paid, net of amounts capitalized | $ | 196 |  |  | $ | 28 |  |  | $ | 16 |  |
| Interest paid - related party | $ | — |  |  | $ | 55 |  |  | $ | 59 |  |
| Income taxes paid for - related party | $ | — |  |  | $ | 475 |  |  | $ | 649 |  |
| Income taxes paid, net of refunds | $ | 819 |  |  | $ | 284 |  |  | $ | 276 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001783180-21-000011:notes:328]
COMMITMENTS AND CONTINGENT LIABILITIES
The Company is unable to predict the final outcome of the following matters based on the information currently available except as otherwise noted. However, the Company does not believe that the resolution of any of these matters will have a material adverse effect upon our competitive position, results of operations, cash flows or financial condition.

[0001783180-21-000011:notes:329]
Environmental. The Company’s operations are subject to environmental regulation by various authorities. We have accrued for the costs of environmental remediation activities, including but not limited to, investigatory, remediation, operating and maintenance costs and performance guarantees, and we periodically reassess these amounts. Management believes that the likelihood of incurring losses materially in excess of the amounts accrued is remote. As of December 31, 2020 and 2019, the outstanding liability for environmental obligations was $239 million and $217 million, respectively, of which $26 million and $14 million, respectively, is included in Accrued liabilities and $213 million and $203 million, respectively, is included in Other long-term liabilities on the accompanying Consolidated Balance Sheet.

[0001783180-21-000011:notes:330]
Legal Proceedings.

[0001783180-21-000011:notes:331]
Asbestos Matters. The Company and our consolidated subsidiaries have been named as defendants in lawsuits alleging personal injury as a result of exposure to asbestos allegedly integrated into certain Carrier products or business premises. While the Company has never manufactured asbestos and no longer incorporates it into any currently-manufactured products, certain products that Carrier no longer manufactures contained components incorporating asbestos. A substantial majority of these asbestos-related claims have been dismissed without payment or were covered in full or in part by insurance or other forms of indemnity. Additional cases were litigated and settled without any insurance reimbursement. The amounts involved in asbestos-related claims were not material individually or in the aggregate in any period.

[0001783180-21-000011:notes:332]
As of December 31, 2020, the estimated range of liability to resolve all pending and unasserted potential future asbestos claims through 2059 is approximately $245 million to $276 million. Where no amount within a range of estimates is more likely, the minimum is accrued. We have recorded the minimum amount of $245 million and $255 million, of which $228 million and $249 million is recorded in Other long-term liabilities, on the accompanying Consolidated Balance Sheet as of December 31, 2020 and 2019, respectively. In addition, the Company has an insurance recovery receivable for probable asbestos-related recoveries of approximately $103 million and $104 million, of which $97 million and $102 million is included in Other assets, on the accompanying Consolidated Balance Sheet as of December 31, 2020 and 2019, respectively.

[0001783180-21-000011:notes:333]
Aqueous Film Forming Foam Litigation. AFFF is a firefighting foam developed in the 1970s pursuant to U.S. military specification and used to extinguish certain types of fires primarily at airports and military bases. AFFF was manufactured by several companies, including National Foam and Angus Fire. UTC acquired the National Foam and Angus Fire businesses in 2005 as part of the acquisition of Kidde, which has been operated by Carrier. In 2013, UTC divested the National Foam and Angus Fire businesses to a third party.

[0001783180-21-000011:notes:334]
Carrier and many other parties, including the third-party buyer of the National Foam and Angus Fire businesses, have been named as defendants in over 700 cases, including putative class actions and other lawsuits, alleging that the historic use of AFFF caused personal injuries and property damage. Additionally, several state and municipal plaintiffs have commenced litigation against the same defendants to recover remediation costs related to historic use of AFFF. In December 2018, the U.S. Judicial Panel on MDL transferred and consolidated all of the AFFF cases pending in the federal courts to the U.S. District Court for the District of South Carolina for pre-trial proceedings.

[0001783180-21-000011:notes:335]
Plaintiffs in the MDL allege that a chemical ingredient in AFFF contains, or breaks down into, compounds known as PFOS and PFOA that were released into the environment and, in some instances, ultimately leached into drinking water supplies. National Foam and Angus Fire purchased these perflourinated chemical ingredients from third-party chemical manufacturers to manufacture AFFF. Chemicals containing PFOS and PFOA (or their precursors) have also been used for decades by many third parties to manufacture carpets, clothing, fabrics, cookware and other consumer products. The individual plaintiffs in the MDL generally seek compensatory damages for alleged personal injuries, medical monitoring and diminution in property value and injunctive relief to remediate alleged contamination of water supplies. The state, municipal and water utility plaintiffs in the MDL generally seek damages and costs related to the remediation of public property and water supplies.

[0001783180-21-000011:notes:336]
Carrier and other defendants are also party to fewer than 10 cases in state court brought by oil refining companies in the U.S. alleging product liability claims related to legacy sales of AFFF and seeking damages for the costs to replace the product and for property damage.

[0001783180-21-000011:notes:337]
Carrier and other defendants are also party to an action related to the AFFF manufacturing facility that was operated by National Foam in which the plaintiff water utility seeks remediation costs related to the alleged contamination of the local water supply.

[0001783180-21-000011:notes:338]
We believe that we have meritorious defenses to these claims. We are also seeking insurance coverage for these claims. At this time, however, given the numerous factual, scientific and legal issues to be resolved relating to these claims, Carrier is unable to assess the probability of liability or reasonably estimate the damages, if any, to be allocated to Carrier, if one or more plaintiffs were to prevail in these cases, and there can be no assurance that any such future exposure will not be material in any period.

[0001783180-21-000011:notes:339]
UTC Equity Awards Conversion Litigation. On August 12, 2020, several former employees of UTC and its subsidiaries filed a putative class action complaint in the U.S. District Court for the District of Connecticut against Raytheon Technologies Corporation, Carrier, Otis, the former members of the UTC Board of Directors and the members of the Carrier and Otis Boards of Directors (Geraud Darnis, et al. v. Raytheon Technologies Corporation, et al.). The complaint challenges the method by which UTC equity awards were converted to UTC, Carrier and Otis equity awards following the Separation and the Distribution. The complaint asserts that the defendants are liable for breach of certain equity compensation plans and for breach of fiduciary duty and also asserts claims under certain provisions of ERISA. Carrier believes that the claims against the Company are without merit.

[0001783180-21-000011:notes:340]
Income Taxes. As described in Note 1 – Description of the Business, under the TMA, the Company is responsible to UTC for its share of the TCJA transition tax associated with foreign undistributed earnings as of December 31, 2017. As of December 31, 2020, a liability of $72 million, primarily related to our share of TCJA transition tax associated with foreign undistributed earnings is included within Other long-term liabilities on the accompanying Consolidated Balance Sheet. We believe that the likelihood of incurring losses materially in excess of this amount is remote.

[0001783180-21-000011:notes:341]
Self-insurance. Liabilities related to self-insured risks were $249 million and $239 million as of December 31, 2020 and 2019, respectively, of which $85 million and $66 million were primarily classified as Other long-term liabilities as of December 31, 2020 and 2019, respectively. We incurred expenses related to self-insured risks of $145 million, $177 million and $170 million for the years ended December 31, 2020, 2019 and 2018, respectively.

[0001783180-21-000011:notes:342]
Other. The Company has other commitments and contingent liabilities related to legal proceedings, self-insurance programs and matters arising in the ordinary course of business. The Company accrues for contingencies generally based upon a range of possible outcomes. If no amount within the range is a better estimate than any other, the Company accrues the minimum amount.

[0001783180-21-000011:notes:343]
In the ordinary course of business, Carrier is routinely a defendant in, party to or otherwise subject to pending and threatened legal actions, claims, disputes and proceedings. These matters are often based on alleged violations of contract, product liability, warranty, regulatory, environmental, health and safety, employment, intellectual property, tax and other laws. In some of these proceedings, claims for substantial monetary damages are asserted against the Company and our subsidiaries and could result in fines, penalties, compensatory or treble damages or non-monetary relief. We do not believe that these matters will have a material adverse effect upon our competitive position, results of operations, cash flows or financial condition.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001783180-21-000011:notes:344]
SEGMENT FINANCIAL DATA 
The Company's Chief Executive Officer, our CODM, evaluates how we allocate resources, assess performance and make strategic and operational decisions. Based upon such evaluation, Carrier determined it is organized into three operating segments, which are also our reportable segments. The CODM allocates resources to and evaluates the financial performance of each operating segment primarily based on net sales and operating profit. For the years ended December 31, 2020, 2019 and 2018, segment results are presented in accordance with this structure. Carrier's operating segments are HVAC, Refrigeration and Fire & Security.

[0001783180-21-000011:notes:345]
HVAC provides products, controls, services and solutions to meet the heating and cooling needs of residential and commercial customers, while enhancing building performance, energy efficiency and sustainability. Carrier’s industry-leading family of brands includes Carrier, Automated Logic, BluEdge, Bryant, CIAT, Day & Night, Heil, NORESCO, Riello and Tempstar. Products include air conditioners, heating systems, controls and aftermarket components, as well as aftermarket repair and maintenance services and building automation solutions. Our HVAC products and solutions are sold directly, including to building contractors and owners, and indirectly through equity method investees, independent sales representatives, distributors, wholesalers, dealers and retail outlets.

[0001783180-21-000011:notes:346]
Refrigeration is comprised of transport refrigeration and commercial refrigeration products and solutions. Transport refrigeration products and services include refrigeration and monitoring systems for trucks, trailers, shipping containers, intermodal and rail. Transport refrigeration products and cold chain monitoring solutions are used to enable the safe, reliable transport of food and beverages, medical supplies and other perishable cargo. Commercial refrigeration solutions include refrigerated cabinets, freezers, systems and controls. Carrier’s commercial refrigeration equipment solutions incorporate next-generation technologies to preserve freshness, ensure safety and enhance the appearance of retail food and beverage. The Company’s Refrigeration products and services are sold under established brand names, including Carrier Commercial Refrigeration, Carrier Transicold and Sensitech. Refrigeration products and services are sold directly, including to transportation companies and retail stores, and indirectly through equity method investees, independent sales representatives, distributors, wholesalers and dealers.

[0001783180-21-000011:notes:347]
Fire & Security includes a wide range of residential and building systems, including fire, flame, gas, smoke and carbon monoxide detection; portable fire extinguishers; fire suppression systems; intruder alarms; access control systems and video management systems. Other fire and security service offerings include audit, design, installation and system integration, as well as aftermarket maintenance and repair and monitoring services.

[0001783180-21-000011:notes:348]
Segment Information. Segment information for the periods presented are as follows:

[0001783180-21-000011:notes:349]
|  | Net Sales |  | Operating Profit |
| (dollars in millions) | 2020 |  | 2019 |  | 2018 |  | 2020 |  | 2019 |  | 2018 |
| HVAC | $ | 9,478 |  |  | $ | 9,712 |  |  | $ | 9,713 |  |  | $ | 2,462 |  |  | $ | 1,563 |  |  | $ | 1,720 |  |
| Refrigeration | 3,333 |  |  | 3,792 |  |  | 4,095 |  |  | 357 |  |  | 532 |  |  | 1,353 |  |
| Fire & Security | 4,985 |  |  | 5,500 |  |  | 5,531 |  |  | 584 |  |  | 708 |  |  | 726 |  |
| Total segment | 17,796 |  |  | 19,004 |  |  | 19,339 |  |  | 3,403 |  |  | 2,803 |  |  | 3,799 |  |
| Eliminations and other | (340) |  |  | (396) |  |  | (425) |  |  | (184) |  |  | (156) |  |  | (24) |  |
| General corporate expenses | — |  |  | — |  |  | — |  |  | (136) |  |  | (156) |  |  | (138) |  |
| Consolidated | $ | 17,456 |  |  | $ | 18,608 |  |  | $ | 18,914 |  |  | $ | 3,083 |  |  | $ | 2,491 |  |  | $ | 3,637 |  |

[0001783180-21-000011:notes:350]
Total assets are not presented for each segment as they are not presented to or reviewed by the CODM.

[0001783180-21-000011:notes:351]
|  | Segment Assets |  | Capital Expenditures |  | Depreciation & Amortization |
| (dollars in millions) | 2020 |  | 2019 |  |  |  | 2020 |  | 2019 |  | 2018 |  | 2020 |  | 2019 |  | 2018 |
| HVAC | $ | 2,150 |  |  | $ | 1,953 |  |  |  |  | $ | 188 |  |  | $ | 150 |  |  | $ | 149 |  |  | $ | 163 |  |  | $ | 160 |  |  | $ | 164 |  |
| Refrigeration | 1,125 |  |  | 989 |  |  |  |  | 26 |  |  | 30 |  |  | 40 |  |  | 39 |  |  | 34 |  |  | 36 |  |
| Fire & Security | 1,788 |  |  | 1,728 |  |  |  |  | 51 |  |  | 50 |  |  | 45 |  |  | 108 |  |  | 123 |  |  | 141 |  |
| Total Segment | 5,063 |  |  | 4,670 |  |  |  |  | 265 |  |  | 230 |  |  | 234 |  |  | 310 |  |  | 317 |  |  | 341 |  |
| Eliminations and other | 3 |  |  | 10 |  |  |  |  | 47 |  |  | 13 |  |  | 29 |  |  | 26 |  |  | 18 |  |  | 16 |  |
| Consolidated | $ | 5,066 |  |  | $ | 4,680 |  |  |  |  | $ | 312 |  |  | $ | 243 |  |  | $ | 263 |  |  | $ | 336 |  |  | $ | 335 |  |  | $ | 357 |  |
| Cash and cash equivalents | 3,115 |  |  | 952 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other assets, current | 343 |  |  | 327 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total current assets | $ | 8,524 |  |  | $ | 5,959 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0001783180-21-000011:notes:352]
Segment assets in the previous table represent accounts receivable, current contract assets and inventories, net. These assets are regularly reviewed by management and are therefore reported in the previous table as segment assets. All other remaining assets and liabilities for all periods presented are managed on a company-wide basis.

[0001783180-21-000011:notes:353]
Geographic External Sales. Geographic external sales and operating profits are attributed to the geographic regions based on their location of origin. With the exception of the U.S. as presented in the following table, there were no individually significant countries with sales exceeding 10% of total sales for the years ended December 31, 2020, 2019 and 2018.

[0001783180-21-000011:notes:354]
|  |  | External Sales |  | Long-Lived Assets |  |  |  |
| (dollars in millions) |  | 2020 |  | 2019 |  | 2018 |  | 2020 |  | 2019 |  |  |  |
| United States Operations |  | $ | 9,105 |  |  | $ | 9,594 |  |  | $ | 9,415 |  |  | $ | 782 |  |  | $ | 701 |  |  |  |  |
| International Operations |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Europe |  | 4,935 |  |  | 5,327 |  |  | 5,711 |  |  | 490 |  |  | 439 |  |  |  |  |
| Asia Pacific |  | 2,655 |  |  | 2,813 |  |  | 2,853 |  |  | 249 |  |  | 241 |  |  |  |  |
| Other |  | 761 |  |  | 874 |  |  | 935 |  |  | 289 |  |  | 282 |  |  |  |  |
| Consolidated |  | $ | 17,456 |  |  | $ | 18,608 |  |  | $ | 18,914 |  |  | $ | 1,810 |  |  | $ | 1,663 |  |  |  |  |

[0001783180-21-000011:notes:355]
Product sales and Service sales. Segment sales disaggregated by product and service are as follows:

[0001783180-21-000011:notes:356]
| (dollars in millions) |  | 2020 |  | 2019 |  | 2018 |
| Sales Type |  |  |  |  |  |  |
| Product |  | $ | 8,165 |  |  | $ | 8,279 |  |  | $ | 8,395 |  |
| Service |  | 1,313 |  |  | 1,433 |  |  | 1,318 |  |
| HVAC sales |  | 9,478 |  |  | 9,712 |  |  | 9,713 |  |
| Product |  | 2,927 |  |  | 3,405 |  |  | 3,665 |  |
| Service |  | 406 |  |  | 387 |  |  | 430 |  |
| Refrigeration sales |  | 3,333 |  |  | 3,792 |  |  | 4,095 |  |
| Product |  | 3,585 |  |  | 4,072 |  |  | 4,039 |  |
| Service |  | 1,400 |  |  | 1,428 |  |  | 1,492 |  |
| Fire & Security sales |  | 4,985 |  |  | 5,500 |  |  | 5,531 |  |
| Total segment sales |  | 17,796 |  |  | 19,004 |  |  | 19,339 |  |
| Eliminations and other |  | (340) |  |  | (396) |  |  | (425) |  |
| Consolidated |  | $ | 17,456 |  |  | $ | 18,608 |  |  | $ | 18,914 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0001783180-21-000011:notes:357]
Segment sales disaggregated by product and service are as follows:


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001783180-21-000011:notes:358]
SELECTED QUARTERLY FINANCIAL INFORMATION (UNAUDITED)

[0001783180-21-000011:notes:359]
|  | 2020 Quarters |
| (dollars in millions) | Q1 |  | Q2 |  | Q3 |  | Q4 |
| Net sales | $ | 3,888 |  |  | $ | 3,972 |  |  | $ | 5,002 |  |  | $ | 4,594 |  |
| Operating profit (1) | $ | 315 |  |  | $ | 442 |  |  | $ | 1,081 |  |  | $ | 1,245 |  |
| Net income attributable to common shareowners (2) | $ | 96 |  |  | $ | 261 |  |  | $ | 741 |  |  | $ | 884 |  |
| Earnings per share - basic (3) | $ | 0.11 |  |  | $ | 0.30 |  |  | $ | 0.86 |  |  | $ | 1.02 |  |
| Earnings per share - diluted (3) | $ | 0.11 |  |  | $ | 0.30 |  |  | $ | 0.84 |  |  | $ | 1.00 |  |
|  | 2019 Quarters |
|  | Q1 |  | Q2 |  | Q3 |  | Q4 |
| Net sales | $ | 4,323 |  |  | $ | 4,962 |  |  | $ | 4,822 |  |  | $ | 4,501 |  |
| Operating profit (1) | $ | 500 |  |  | $ | 805 |  |  | $ | 629 |  |  | $ | 557 |  |
| Net income attributable to common shareowners (2) | $ | 400 |  |  | $ | 784 |  |  | $ | 492 |  |  | $ | 440 |  |
| Earnings per share - basic (3) | $ | 0.46 |  |  | $ | 0.91 |  |  | $ | 0.57 |  |  | $ | 0.50 |  |
| Earnings per share - diluted (3) | $ | 0.46 |  |  | $ | 0.91 |  |  | $ | 0.57 |  |  | $ | 0.50 |  |

[0001783180-21-000011:notes:360]
(1) Q3 2020 and Q4 2020 Operating profit includes a $252 million and $871 million gain on the sale of our equity ownership in Beijer, respectively. Q1 2020 Operating profit includes a $71 million impairment charge related to a minority owned joint venture investment. Q3 2019 Operating profit includes a $108 million impairment charge related to a minority owned joint venture investment.

[0001783180-21-000011:notes:361]
(2) Q1 2020 Net income includes a $51 million charge related to a valuation allowance recorded against a United Kingdom tax loss and a credit carryforward and a charge of $46 million resulting from Carrier's decision to no longer permanently reinvest certain pre-2018 unremitted non-U.S. earnings. Q2 2019 Net income includes a tax benefit of $149 million as a result of the filing by a subsidiary of Carrier to participate in an amnesty program offered by the Italian Tax Authority and conclusion of a U.S. income tax audit. 
(3) Earnings per share for periods presented prior to the Separation and the Distribution were calculated using the number of shares that were distributed to UTC shareowners in the Distribution. For periods prior to the Separation and the Distribution it was assumed that there were no dilutive equity instruments as there were no equity awards in Carrier common stock outstanding prior to the Separation and the Distribution.


## us-gaap:SubsequentEventsTextBlock

[0001783180-21-000011:notes:362]
SUBSEQUENT EVENTS On February 4, 2021 the Company’s Board of Directors approved a stock repurchase program authorizing the repurchase of up to $350 million of the Company’s outstanding common stock. Share repurchases may take place from time to time, subject to market conditions and at the Company’s discretion in the open market or through one or more other public or private transactions.


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001783180-21-000011:notes:363]
SCHEDULE II

[0001783180-21-000011:notes:364]
CARRIER GLOBAL CORPORATION

[0001783180-21-000011:notes:365]
Valuation and Qualifying Accounts

[0001783180-21-000011:notes:366]
Three years ended December 31, 2020

[0001783180-21-000011:notes:367]
| (dollars in millions) |  |  |
| Future Income Tax Benefits - Valuation Allowance |  |  |
| Balance as of January 1, 2018 |  | $ | 113 |  |
| Additions charged to income tax expense |  | 15 |  |
| Reduction credited to income tax expense |  | (14) |  |
| Other adjustments |  | (7) |  |
| Balance as of December 13, 2018 |  | 107 |  |
| Additions charged to income tax expense |  | 41 |  |
| Reduction credited to income tax expense |  | (16) |  |
| Other adjustments |  | (4) |  |
| Balance as of December 31, 2019 |  | 128 |  |
| Additions charged to income tax expense (1) |  | 112 |  |
| Reduction credited to income tax expense |  | (13) |  |
| Other adjustments |  | 4 |  |
| Balance as of December 31, 2020 |  | $ | 231 |  |

[0001783180-21-000011:notes:368]
__________________________

[0001783180-21-000011:notes:369]
(1) Includes $89 million relating to "Separation impact" discussed in "Reconciliation of Effective Income Tax Rate" in Note 19 – Income Taxes in the accompanying Notes to the Consolidated Financial Statements.
