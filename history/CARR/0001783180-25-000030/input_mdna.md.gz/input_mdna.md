# CARR MD&A — 0001783180-25-000030


## mdna

[0001783180-25-000030:mdna:1]
[same as prior period, unchanged from 0001783180-24-000088:mdna:1]

[0001783180-25-000030:mdna:2]
[same as prior period, unchanged from 0001783180-24-000088:mdna:2]

[0001783180-25-000030:mdna:3]
[same as prior period, unchanged from 0001783180-24-000088:mdna:3]

[0001783180-25-000030:mdna:4]
Carrier Global Corporation ("we" or "our") is a global leader in intelligent climate and energy solutions with a focus on providing differentiated, digitally-enabled lifecycle solutions to our customers. Our portfolio includes industry-leading brands such as Carrier, Viessmann, Toshiba, Automated Logic and Carrier Transicold that offer innovative heating, ventilating, air conditioning ("HVAC") and cold chain transportation solutions to enhance the lives we live and the world we share. We also provide a broad array of related building services, including audit, design, installation, system integration, repair, maintenance and monitoring. Our operations are classified into four segments: Climate Solutions Americas, Climate Solutions Europe, Climate Solutions Asia Pacific, Middle East & Africa and Climate Solutions Transportation.

[0001783180-25-000030:mdna:5]
Through our performance-driven culture, we anticipate creating long-term shareowner value by investing strategically to strengthen our product position in homes, buildings and across the cold chain in order to drive profitable growth. We believe our business segments are well positioned to benefit from favorable secular trends, including the mega-trends of urbanization, population growth and demographic shifts, food security and safety, digitalization, global connectivity and energy efficiency. Coupled with our industry-leading brands and track record of innovation, we continue to provide market-leading solutions for our customers.

[0001783180-25-000030:mdna:6]
Our worldwide operations are affected by global and regional industrial, economic and political factors, trade policies and trends. They are also affected by changes in the general level of economic activity, such as changes in business and consumer spending, construction and shipping activity as well as short-term economic factors such as currency fluctuations, commodity price volatility and supply disruptions. We continue to invest in our business, take pricing actions to mitigate supply chain and inflationary pressures, develop new products and services in order to remain competitive in our markets and use risk management strategies to mitigate various exposures.

[0001783180-25-000030:mdna:7]
We are actively monitoring evolving macroeconomic conditions and recent trade policy announcements. Based on our preliminary analysis, we expect to fully mitigate our expected 2025 impact from tariffs announced to date through supply chain and productivity actions as well as approximately $300 million of incremental product pricing actions. To date, tariffs have not had a material impact on our business and we are deploying additional strategies, including cost containment measures, to limit future exposure in this current market environment.

[0001783180-25-000030:mdna:8]
[same as prior period, unchanged from 0001783180-24-000088:mdna:7]

[0001783180-25-000030:mdna:9]
[same as prior period, unchanged from 0001783180-24-000088:mdna:10]

[0001783180-25-000030:mdna:10]
During 2024, we completed several activities designed to simplify our business portfolio, transforming it into a pure-play climate and energy solutions provider. On January 2, 2024, we acquired the climate solutions business (the "VCS Business") of Viessmann Group GmbH & Co. KG (“Viessmann”). The VCS Business, primarily reported in the Climate Solutions Europe segment, is a premier residential and light commercial HVAC provider in Europe that expanded our portfolio to offer a global, comprehensive suite of sustainable and innovative building and cold-chain solutions. In addition, we divested our Commercial and Residential Fire, Access Solutions and Industrial Fire businesses which were historically reported in our Fire & Security segment. The transactions represented a single disposal plan to separately divest multiple businesses over different reporting periods and met the criteria to be presented as discontinued operations. We also divested our Commercial Refrigeration business (“CCR”) during 2024. CCR, which was historically reported in the Climate Solutions Transportation segment (previously named Refrigeration), did not meet the criteria to be presented as discontinued operations.

[0001783180-25-000030:mdna:11]
Segment Reorganization

[0001783180-25-000030:mdna:12]
As a result of our portfolio transformation, we revised our reportable segments during the first quarter to better reflect our business strategy, align our management reporting and increase transparency for investors. Under the revised segment structure, we have three new regional HVAC operating segments. Combined with the existing Climate Solutions Transportation operating segment, the four operating segments also serve as our reportable segments. This model is designed to create a simplified, more focused and customer-centric organization across the globe. Each segment reports through separate management teams which regularly review their operating results with our Chief Operating Decision Maker (the "CODM") determined in accordance with applicable accounting guidance. In connection with the revised structure, the CODM changed the measure used to evaluate segment profitability from Operating profit to Segment operating profit. All prior period comparative information has been recast to reflect the revised segment structure.

[0001783180-25-000030:mdna:13]
[same as prior period, unchanged from 0001783180-24-000088:mdna:20]

[0001783180-25-000030:mdna:14]
Preparation of our financial statements requires management to make estimates and assumptions that affect the reported amounts of assets, liabilities, sales and expenses. We believe that the most complex and sensitive judgments, because of their potential significance to the accompanying Unaudited Condensed Consolidated Financial Statements, result primarily from the need to make estimates about the effects of matters that are inherently uncertain. In "Management’s Discussion and Analysis of Financial Condition and Results of Operations" of our 2024 Form 10-K, we describe the significant accounting estimates and policies used in the preparation of the accompanying Unaudited Condensed Consolidated Financial Statements. Except as noted below, there have been no significant changes in our critical accounting estimates.

[0001783180-25-000030:mdna:15]
[same as prior period, unchanged from 0001783180-24-000088:mdna:24]

[0001783180-25-000030:mdna:16]
Three Months Ended March 31, 2025 Compared with the Three Months Ended March 31, 2024

[0001783180-25-000030:mdna:17]
[same as prior period, unchanged from 0001783180-24-000088:mdna:26]

[0001783180-25-000030:mdna:18]
|  |  | Three Months Ended March 31, |
| (In millions) |  | 2025 |  | 2024 |  | Period Change |  | % Change |
| Net sales |  | $ | 5,218 |  |  | $ | 5,420 |  |  | $ | (202) |  |  | (4) | % |
| Cost of products and services sold |  | (3,773) |  |  | (4,035) |  |  | 262 |  |  | (6) | % |
| Gross margin |  | 1,445 |  |  | 1,385 |  |  | 60 |  |  | 4 | % |
| Operating expenses |  | (816) |  |  | (1,000) |  |  | 184 |  |  | (18) | % |
| Operating profit |  | 629 |  |  | 385 |  |  | 244 |  |  | 63 | % |
| Non-operating income (expense), net |  | (81) |  |  | (141) |  |  | 60 |  |  | (43) | % |
| Earnings (loss) before income taxes |  | 548 |  |  | 244 |  |  | 304 |  |  | 125 | % |
| Income tax expense |  | (111) |  |  | (47) |  |  | (64) |  |  | 136 | % |
| Earnings (loss) from continuing operations |  | 437 |  |  | 197 |  |  | 240 |  |  | 122 | % |
| Discontinued operations, net of income taxes |  | — |  |  | 92 |  |  | (92) |  |  | (100) | % |
| Net earnings (loss) |  | 437 |  |  | 289 |  |  | 148 |  |  | 51 | % |
| Less: Non-controlling interest in subsidiaries' earnings from operations |  | 25 |  |  | 20 |  |  | 5 |  |  | 25 | % |
| Net earnings (loss) attributable to common shareowners |  | $ | 412 |  |  | $ | 269 |  |  | $ | 143 |  |  | 53 | % |

[0001783180-25-000030:mdna:19]
[same as prior period, unchanged from 0001783180-24-000088:mdna:28]

[0001783180-25-000030:mdna:20]
For the three months ended March 31, 2025, Net sales were $5.2 billion, a 4% decrease compared with the same period of 2024. The components of the year-over-year change were as follows:

[0001783180-25-000030:mdna:21]
|  |  | Three Months Ended March 31, 2025 |
| Organic |  | 2 | % |
| Foreign currency translation |  | (1) | % |
| Acquisitions and divestitures, net |  | (5) | % |
| Total % change |  | (4) | % |

[0001783180-25-000030:mdna:22]
Organic sales for the three months ended March 31, 2025 increased by 2% compared with the same period of 2024. The organic increase was primarily due to our Climate Solutions Americas segment as strong end-market demand continued to drive higher volumes. In addition, higher volumes benefited our Climate Solutions Transportation segment. These results were partially offset by lower end-market demand in both Climate Solutions Europe and Climate Solutions Asia Pacific, Middle East & Africa. Refer to "Segment Review" below for a discussion of Net sales by segment.

[0001783180-25-000030:mdna:23]
[same as prior period, unchanged from 0001783180-24-000088:mdna:33]

[0001783180-25-000030:mdna:24]
For the three months ended March 31, 2025, gross margin was $1.4 billion, a 4% increase compared with the same period of 2024. The components were as follows:

[0001783180-25-000030:mdna:25]
|  |  | Three Months Ended March 31, |
| (In millions) |  | 2025 |  | 2024 |
| Net sales |  | $ | 5,218 |  |  | $ | 5,420 |  |
| Cost of products and services sold |  | (3,773) |  |  | (4,035) |  |
| Gross margin |  | $ | 1,445 |  |  | $ | 1,385 |  |
| Percentage of net sales |  | 27.7 | % |  | 25.6 | % |

[0001783180-25-000030:mdna:26]
Gross margin increased by $60 million compared with the three months ended March 31, 2024. As a result, gross margin as a percentage of Net sales increased by 210 basis points compared with the same period of 2024. The prior period included inventory step-up and backlog amortization resulting from the recognition of acquired assets of the VCS Business at fair value which are now fully amortized. These costs had a 200 basis point unfavorable impact on the prior period gross margin as a percentage of Net sales. In addition, ongoing customer demand, pricing improvements and our continued focus on productivity initiatives further benefited gross margin.

[0001783180-25-000030:mdna:27]
[same as prior period, unchanged from 0001783180-24-000088:mdna:37]

[0001783180-25-000030:mdna:28]
For the three months ended March 31, 2025, operating expenses, including Equity method investment net earnings, were $816 million, an 18% decrease compared with the same period of 2024. The components were as follows:

[0001783180-25-000030:mdna:29]
|  |  | Three Months Ended March 31, |
| (In millions) |  | 2025 |  | 2024 |
| Selling, general and administrative |  | $ | (729) |  |  | $ | (807) |  |
| Research and development |  | (153) |  |  | (192) |  |
| Equity method investment net earnings |  | 44 |  |  | 31 |  |
| Other income (expense), net |  | 22 |  |  | (32) |  |
| Total operating expenses |  | $ | (816) |  |  | $ | (1,000) |  |
| Percentage of net sales |  | 15.6 | % |  | 18.5 | % |

[0001783180-25-000030:mdna:30]
30

[0001783180-25-000030:mdna:31]
For the three months ended March 31, 2025, Selling, general and administrative expenses were $729 million, a 10% decrease compared with the same period of 2024. The decrease relates to productivity initiatives associated with our portfolio transformation and synergies associated with the integration of the VCS Business. These benefits were partially offset by higher compensation and other employee-related costs. In addition, the current period also included $6 million of acquisition and divestiture-related costs compared with $48 million during the three months ended March 31, 2024.

[0001783180-25-000030:mdna:32]
Research and development costs relate to new product development and new technology innovation. Due to the variable nature of program development schedules, year-over-year spending levels can fluctuate. In addition, we continue to invest to prepare for future product innovations and digital controls technologies.

[0001783180-25-000030:mdna:33]
Investments over which we do not exercise control, but have significant influence, are accounted for using the equity method of accounting. For the three months ended March 31, 2025, Equity method investment net earnings were $44 million, a 42% increase compared with the same period of 2024. The increase was primarily due to a $23 million non-recurring charge in the prior year associated with the devaluation of U.S. Dollar denominated balances at an equity investment in Egypt.

[0001783180-25-000030:mdna:34]
Other income (expense), net primarily includes the impact of gains and losses related to the sale of businesses or interests in our equity method investments, foreign currency gains and losses on transactions that are denominated in a currency other than an entity's functional currency and hedging-related activities. In connection with the acquisition of the VCS Business, we recognized an $86 million loss during the three months ended March 31, 2024, on the mark-to-market valuation of our window forward contracts associated with the expected cash outflows of the Euro-denominated purchase price of the VCS Business. In addition, we recognized a $46 million gain associated with the TMA and UTC's conclusion of certain income tax matters from their 2017 and 2018 tax audit with the Internal Revenue Service ("IRS").

[0001783180-25-000030:mdna:35]
[same as prior period, unchanged from 0001783180-24-000088:mdna:44]

[0001783180-25-000030:mdna:36]
For the three months ended March 31, 2025, Non-operating income (expense), net was $81 million, a 43% decrease compared with the same period of 2024. The components were as follows:

[0001783180-25-000030:mdna:37]
|  |  | Three Months Ended March 31, |
| (In millions) |  | 2025 |  | 2024 |
| Non-service pension (expense) benefit |  | $ | 1 |  |  | $ | — |  |
| Interest expense |  | $ | (112) |  |  | $ | (156) |  |
| Interest income |  | 30 |  |  | 15 |  |
| Interest (expense) income, net |  | $ | (82) |  |  | $ | (141) |  |
| Non-operating income (expense), net |  | $ | (81) |  |  | $ | (141) |  |

[0001783180-25-000030:mdna:38]
Non-operating income (expense), net includes the results from activities other than normal business operations such as interest expense, interest income and the non-service components of pension and post-retirement obligations. Interest expense is affected by the amount of debt outstanding and the interest rates on that debt. For the three months ended March 31, 2025, Interest expense was $112 million, a 28% decrease compared with the same period of 2024. Consistent with our capital allocation strategy, we reduced our outstanding debt by approximately $3 billion over the course of 2024 and repaid an additional $1.2 billion during the current period.

[0001783180-25-000030:mdna:39]
[same as prior period, unchanged from 0001783180-24-000088:mdna:48]

[0001783180-25-000030:mdna:40]
|  |  | Three Months Ended March 31, |
|  |  | 2025 |  | 2024 |
| Effective tax rate |  | 20.3 | % |  | 19.3 | % |

[0001783180-25-000030:mdna:41]
31

[0001783180-25-000030:mdna:42]
We account for income tax expense in accordance with ASC 740, which requires an estimate of the annual effective income tax rate for the full year to be applied to the respective interim period, taking into account year-to-date amounts and projected results for the full year. The effective tax rate was 20.3% for the three months ended March 31, 2025, compared with 19.3% for the three months ended March 31, 2024. The year-over-year increase was primarily driven by the absence of a $21 million tax benefit associated with the TMA and UTC's conclusion of certain income tax matters from their 2017 and 2018 tax audit with the IRS recognized during the three months ended March 31, 2024. In addition, the three months ended March 31, 2025 included an $8 million tax benefit generated by the purchase of investment tax credits from a third-party.

[0001783180-25-000030:mdna:43]
Adjusted Operating Profit

[0001783180-25-000030:mdna:44]
We report our financial results in accordance with accounting principles generally accepted in the United States ("GAAP"). In addition, we supplement the reporting of our financial information determined under GAAP with certain non-GAAP financial information. Adjusted operating profit is a non-GAAP measure and defined as consolidated operating profit (a GAAP measure), excluding restructuring costs, amortization of acquired intangibles and other significant items of a nonoperational nature. This measure is useful to investors because it is how management assesses the operating performance of the business. A reconciliation of the amounts prepared in accordance with GAAP to the corresponding non-GAAP measure appears below and provides additional information as to the items and amounts that have been excluded from the adjusted measure.

[0001783180-25-000030:mdna:45]
|  |  | Three Months Ended March 31, |  |  |
| (In millions) |  | 2025 |  | 2024 |  |  |  |  |
| Reconciliation to Adjusted operating profit |  |  |  |  |  |  |  |  |
| Operating profit |  | $ | 629 |  |  | $ | 385 |  |  |  |  |  |
| Restructuring costs |  | 8 |  |  | 8 |  |  |  |  |  |
| Amortization of acquired intangibles |  | 201 |  |  | 172 |  |  |  |  |  |
| Acquisition on step-up amortization |  | — |  |  | 111 |  |  |  |  |  |
| Acquisition/divestiture-related costs |  | 5 |  |  | 48 |  |  |  |  |  |
| Viessmann-related hedges |  | — |  |  | 86 |  |  |  |  |  |
| Gain on liability adjustment |  | — |  |  | (46) |  |  |  |  |  |
| Adjusted operating profit |  | $ | 843 |  |  | $ | 764 |  |  |  |  |  |

[0001783180-25-000030:mdna:46]
Adjusted operating profit may not be comparable to similarly-titled measures used by other companies and should not be considered a substitute for Operating profit in accordance with GAAP. The non-GAAP information presented provides investors with additional useful information, but should not be considered in isolation or as a substitute for the related GAAP measure. Moreover, other companies may define non-GAAP measures differently, which limits the usefulness of these measures for comparisons with such other companies. We encourage investors to review our financial statements and publicly filed reports in their entirety and not to rely on any single financial measure.

[0001783180-25-000030:mdna:47]
32

[0001783180-25-000030:mdna:48]
[same as prior period, unchanged from 0001783180-24-000088:mdna:79]

[0001783180-25-000030:mdna:49]
We have four operating segments:

[0001783180-25-000030:mdna:50]
•Climate Solutions Americas provides products, controls, services and solutions to meet the heating, cooling and ventilation needs of residential and commercial customers in North and South America while enhancing building performance, health, energy efficiency and sustainability.

[0001783180-25-000030:mdna:51]
•Climate Solutions Europe provides products, controls, services and solutions to meet the heating, cooling and ventilation needs of residential and commercial customers in Europe while enhancing building performance, health, energy efficiency and sustainability.

[0001783180-25-000030:mdna:52]
•Climate Solutions Asia Pacific, Middle East & Africa provides products, controls, services and solutions to meet the heating, cooling and ventilation needs of residential and commercial customers in Asia Pacific, the Middle East and Africa while enhancing building performance, health, energy efficiency and sustainability.

[0001783180-25-000030:mdna:53]
•Climate Solutions Transportation includes global transport refrigeration and monitoring products, services and digital solutions for trucks, trailers, shipping containers, intermodal and rail.

[0001783180-25-000030:mdna:54]
Segment operating profit is the measure of profit and loss that our CODM uses to evaluate the financial performance of the business and as the basis for resource allocation, performance reviews and compensation. It represents operating profit (a GAAP measure) adjusted to exclude restructuring costs, amortization of acquired intangible assets and other significant items of a nonoperational nature.

[0001783180-25-000030:mdna:55]
Three Months Ended March 31, 2025 Compared with Three Months Ended March 31, 2024

[0001783180-25-000030:mdna:56]
[same as prior period, unchanged from 0001783180-24-000088:mdna:85]

[0001783180-25-000030:mdna:57]
|  |  | Net sales |  | Segment operating profit |  | Segment operating profit margin |
|  |  | Three Months Ended March 31, |  | Three Months Ended March 31, |  | Three Months Ended March 31, |
| (In millions) |  | 2025 |  | 2024 |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Climate Solutions Americas |  | $ | 2,572 |  |  | $ | 2,360 |  |  | $ | 570 |  |  | $ | 425 |  |  | 22.2 | % |  | 18.0 | % |
| Climate Solutions Europe |  | 1,169 |  |  | 1,292 |  |  | 105 |  |  | 167 |  |  | 9.0 | % |  | 12.9 | % |
| Climate Solutions Asia Pacific, Middle East & Africa |  | 826 |  |  | 884 |  |  | 121 |  |  | 108 |  |  | 14.6 | % |  | 12.2 | % |
| Climate Solutions Transportation |  | 651 |  |  | 884 |  |  | 97 |  |  | 113 |  |  | 14.9 | % |  | 12.8 | % |
| Total segment |  | $ | 5,218 |  |  | $ | 5,420 |  |  | $ | 893 |  |  | $ | 813 |  |  | 17.1 | % |  | 15.0 | % |

[0001783180-25-000030:mdna:58]
A reconciliation of Segment operating profit to Adjusted operating profit is as follows:

[0001783180-25-000030:mdna:59]
|  |  | Three Months Ended March 31, |
| (In millions) |  | 2025 |  | 2024 |
| Segment operating profit |  | $ | 893 |  |  | $ | 813 |  |
| Corporate and other |  | (50) |  |  | (49) |  |
| Adjusted operating profit |  | $ | 843 |  |  | $ | 764 |  |

[0001783180-25-000030:mdna:60]
Climate Solutions Americas

[0001783180-25-000030:mdna:61]
For the three months ended March 31, 2025, Net sales were $2.6 billion, a 9% increase compared with the same period of 2024. The components of the year-over-year change were as follows:

[0001783180-25-000030:mdna:62]
|  |  | Net sales |
| Organic |  | 9 | % |
| Foreign currency translation |  | — | % |
| Total % change in Net sales |  | 9 | % |

[0001783180-25-000030:mdna:63]
The organic increase in Net sales of 9% was driven by continued strong results in the segment. Growth in our residential business (up 20%) was primarily driven by strong end-market demand and pricing improvements compared to the prior year. In addition, ongoing customer demand in our commercial business (up 15%) further benefited segment results. These amounts were partially offset by reduced end-market demand in our light commercial business (down 34%).

[0001783180-25-000030:mdna:64]
For the three months ended March 31, 2025, Segment operating profit was $570 million, a 34% increase compared with the same period of 2024. The components of the year-over-year change were as follows:

[0001783180-25-000030:mdna:65]
|  |  | Segment operating profit |
| Operational |  | 36 | % |
| Foreign currency translation |  | (2) | % |
| Total % change in Segment operating profit |  | 34 | % |

[0001783180-25-000030:mdna:66]
The segment operational profit increase of 36% was primarily attributable to ongoing customer demand in certain end-markets compared with the prior year. In addition, favorable productivity initiatives and higher earnings from equity method investments further benefited segment results. These benefits more than offset volume reductions in certain end-markets and higher selling, general and administrative expenses.

[0001783180-25-000030:mdna:67]
Climate Solutions Europe

[0001783180-25-000030:mdna:68]
For the three months ended March 31, 2025, Net sales were $1.2 billion, a 10% decrease compared with the same period of 2024. The components of the year-over-year change were as follows:

[0001783180-25-000030:mdna:69]
|  |  | Net sales |
| Organic |  | (7) | % |
| Foreign currency translation |  | (3) | % |
| Total % change in Net sales |  | (10) | % |

[0001783180-25-000030:mdna:70]
The organic decrease in Net sales of 7% was driven by ongoing challenges in certain end-markets compared with the prior year. Results in our residential and light commercial business decreased (down 11%) due to lower volumes across the region as economic conditions, inflationary cost pressures and regulatory uncertainty impacted end-market demand. The reduction was partially offset by continued growth in our commercial business (up 5%) as a result of strong end-market demand and pricing improvements.

[0001783180-25-000030:mdna:71]
34

[0001783180-25-000030:mdna:72]
For the three months ended March 31, 2025, Segment operating profit was $105 million, a 37% decrease compared with the same period of 2024. The components of the year-over-year change were as follows:

[0001783180-25-000030:mdna:73]
|  |  | Segment operating profit |
| Operational |  | (35) | % |
| Foreign currency translation |  | (2) | % |
| Total % change in Segment operating profit |  | (37) | % |

[0001783180-25-000030:mdna:74]
The segment operational profit decrease of 35% was primarily attributable to volume reductions in certain end-markets compared with the prior year. Volume reductions were partially offset by favorable material costs, business integration synergies associated with the acquisition of the VCS Business and lower selling, general and administrative expenses.

[0001783180-25-000030:mdna:75]
Climate Solutions Asia Pacific, Middle East & Africa

[0001783180-25-000030:mdna:76]
For the three months ended March 31, 2025, Net sales were $826 million, a 7% decrease compared with the same period of 2024. The components of the year-over-year change were as follows:

[0001783180-25-000030:mdna:77]
|  |  | Net sales |
| Organic |  | (6) | % |
| Foreign currency translation |  | (1) | % |
| Total % change in Net sales |  | (7) | % |

[0001783180-25-000030:mdna:78]
The organic decrease in Net sales of 6% was driven by volume reductions within certain end-markets compared with the prior year. Results in China decreased (down 11%) as both commercial and residential end-markets experienced economic challenges impacting demand. These results were partially offset by improved end-market demand in the remaining region.

[0001783180-25-000030:mdna:79]
For the three months ended March 31, 2025, Segment operating profit was $121 million, an 12% increase compared with the same period of 2024. The components of the year-over-year change were as follows:

[0001783180-25-000030:mdna:80]
|  |  | Segment operating profit |
| Operational |  | 10 | % |
| Foreign currency translation |  | 2 | % |
| Total % change in Segment operating profit |  | 12 | % |

[0001783180-25-000030:mdna:81]
The segment operational profit increase of 10% was primarily attributable to higher earnings from equity method investments compared with the prior year. The increase was driven by the absence of a $23 million non-recurring charge in the prior year associated with the devaluation of U.S. Dollar denominated balances at an equity investment in Egypt. In addition, the segment benefited from favorable productivity initiatives and lower selling, general and administrative expenses. These benefits more than offset volume reductions in certain end-markets.

[0001783180-25-000030:mdna:82]
Climate Solutions Transportation

[0001783180-25-000030:mdna:83]
For the three months ended March 31, 2025, Net sales were $651 million, a 26% decrease compared to the same period of 2024. The components of the year-over-year change were as follows:

[0001783180-25-000030:mdna:84]
|  |  | Net sales |
| Organic |  | 2 | % |
| Foreign currency translation |  | (1) | % |
| Acquisitions and divestitures, net |  | (27) | % |
| Total % change in Net sales |  | (26) | % |

[0001783180-25-000030:mdna:85]
The organic increase in Net sales of 2% was primarily driven by volume growth within certain end-markets compared with the prior year. Container results increased (up 20%) due to improved end-market demand and pricing improvements. These results were partially offset by our transport refrigeration business (down 3%) as lower end-market demand in Europe and North America more than offset improved end-market demand in Asia.

[0001783180-25-000030:mdna:86]
For the three months ended March 31, 2025, Segment operating profit was $97 million, a 14% decrease compared with the same period of 2024. The components of the year-over-year change were as follows:

[0001783180-25-000030:mdna:87]
|  |  | Segment operating profit |
| Operational |  | (9) | % |
| Foreign currency translation |  | (2) | % |
| Acquisitions and divestitures, net |  | (3) | % |
| Total % change in Segment operating profit |  | (14) | % |

[0001783180-25-000030:mdna:88]
The decrease in segment operational profit of 9% was primarily driven by higher costs associated with warranty-related issues. In addition, unfavorable mix further impacted the segment. These amounts were partially offset by higher volumes and pricing improvements compared with the prior year. In addition, the segment benefited from lower selling, general and administrative expenses.

[0001783180-25-000030:mdna:89]
[same as prior period, unchanged from 0001783180-24-000088:mdna:123]

[0001783180-25-000030:mdna:90]
[same as prior period, unchanged from 0001783180-24-000088:mdna:124]

[0001783180-25-000030:mdna:91]
As of March 31, 2025, we had cash and cash equivalents of $1.7 billion, of which approximately 85% was held by our foreign subsidiaries. We manage our worldwide cash requirements by reviewing available funds and the cost effectiveness with which we can access funds held by foreign subsidiaries. On occasion, we are required to maintain cash deposits in connection with contractual obligations related to acquisitions, divestitures or other legal obligations. As of March 31, 2025 and December 31, 2024, the amount of such restricted cash was approximately $4 million and $3 million, respectively.

[0001783180-25-000030:mdna:92]
[same as prior period, unchanged from 0001783180-24-000088:mdna:126]

[0001783180-25-000030:mdna:93]
[same as prior period, unchanged from 0001783180-24-000088:mdna:127]

[0001783180-25-000030:mdna:94]
36

[0001783180-25-000030:mdna:95]
[same as prior period, unchanged from 0001783180-24-000088:mdna:128]

[0001783180-25-000030:mdna:96]
| (In millions) |  | March 31,2025 |  | December 31,2024 |
| Cash and cash equivalents |  | $ | 1,698 |  |  | $ | 3,969 |  |
| Total debt |  | $ | 11,184 |  |  | $ | 12,278 |  |
| Total equity |  | $ | 14,198 |  |  | $ | 14,395 |  |
| Net debt (total debt less cash and cash equivalents) |  | $ | 9,486 |  |  | $ | 8,309 |  |
| Total capitalization (total debt plus total equity) |  | $ | 25,382 |  |  | $ | 26,673 |  |
| Net capitalization (total debt plus total equity less cash and cash equivalents) |  | $ | 23,684 |  |  | $ | 22,704 |  |
| Total debt to total capitalization |  | 44 | % |  | 46 | % |
| Net debt to net capitalization |  | 40 | % |  | 37 | % |

[0001783180-25-000030:mdna:97]
[same as prior period, unchanged from 0001783180-24-000088:mdna:135]

[0001783180-25-000030:mdna:98]
We maintain a $2.0 billion unsecured, unsubordinated commercial paper program which we can use for general corporate purposes, including the funding of working capital and potential acquisitions. In addition, we maintain a $2.5 billion revolving credit agreement with various banks (the "Revolving Credit Facility") that matures in December 2029 which supports our commercial paper borrowing program and can be used for general corporate purposes. A ratings-based commitment fee is charged on unused commitments. As of March 31, 2025, we had no borrowings outstanding under our commercial paper program or our Revolving Credit Facility.

[0001783180-25-000030:mdna:99]
Our short-term obligations primarily consist of current maturities of long-term debt. Our long-term obligations primarily consist of long-term notes with maturity dates ranging between 2027 and 2054. Interest payments related to long-term notes are expected to approximate $398 million per year, reflecting an approximate weighted-average interest rate of 3.63%. Any borrowings from the Revolving Credit Facility are subject to variable interest rates. See Note 5 – Borrowings and Lines of Credit in the Notes to the accompanying Unaudited Condensed Consolidated Financial Statements for additional information regarding the terms of our long-term debt obligations.

[0001783180-25-000030:mdna:100]
Our credit ratings are periodically reviewed by the major independent debt-rating agencies. As of March 31, 2025, Standards & Poor's Global Inc., Moody’s Investor Service Inc. and Fitch Ratings Inc. have ratings on our debt set forth in the table below:

[0001783180-25-000030:mdna:101]
| Rating Agency |  | Long-term Rating |  | Short-term Rating |  | Outlook |
| Standards & Poor's Global Inc. |  | BBB+ |  | A2 |  | Stable |
| Moody's Investors Service Inc. |  | Baa1 |  | P2 |  | Positive |
| Fitch Ratings Inc. |  | BBB+ |  | F1 |  | Stable |

[0001783180-25-000030:mdna:102]
[same as prior period, unchanged from 0001783180-24-000088:mdna:143]

[0001783180-25-000030:mdna:103]
On June 2, 2024, we completed the divestiture of our Access Solutions business for cash proceeds of $5.0 billion. On July 1, 2024, we completed the divestiture of our Industrial Fire business for cash proceeds of $1.4 billion. On October 1, 2024, we completed the divestiture of CCR for cash proceeds of $679 million, subject to customary working capital and other adjustments. On December 2, 2024, we completed the divestiture of the Commercial and Residential Fire business for cash proceeds of $2.9 billion, subject to customary working capital and other adjustments. Consistent with our capital allocation strategy, the net proceeds were used to fund repayment of debt, invest in organic and inorganic growth initiatives, capital returns to shareowners as well as for general corporate purposes.

[0001783180-25-000030:mdna:104]
[same as prior period, unchanged from 0001783180-24-000088:mdna:32]

[0001783180-25-000030:mdna:105]
[same as prior period, unchanged from 0001783180-24-000088:mdna:146]

[0001783180-25-000030:mdna:106]
We may repurchase our outstanding common stock from time to time subject to market conditions and at our discretion. Repurchases occur in the open market or through one or more other public or private transactions pursuant to plans complying with Rules 10b5-1 and 10b-18 under the Exchange Act. Since the initial authorization in February 2021, our Board of Directors authorized the repurchase of up to $7.1 billion of our outstanding common stock.

[0001783180-25-000030:mdna:107]
During the three months ended March 31, 2025, we repurchased 19.0 million shares of common stock for an aggregate purchase price of $1.3 billion. As a result we had approximately $1.9 billion remaining under the current authorization at March 31, 2025.

[0001783180-25-000030:mdna:108]
[same as prior period, unchanged from 0001783180-24-000088:mdna:149]

[0001783180-25-000030:mdna:109]
We paid dividends on common stock during the three months ended March 31, 2025, totaling $198 million. In April 2025, the Board of Directors declared a dividend of $0.23 per share of common stock payable on May 22, 2025, to shareowners of record at the close of business on May 2, 2025.

[0001783180-25-000030:mdna:110]
[same as prior period, unchanged from 0001783180-24-000088:mdna:151]

[0001783180-25-000030:mdna:111]
[same as prior period, unchanged from 0001783180-24-000088:mdna:152]

[0001783180-25-000030:mdna:112]
|  |  | Three Months Ended March 31, |
| (In millions) |  | 2025 |  | 2024 |
| Net cash flows provided by (used in): |  |  |  |  |
| Continuing operating activities |  | $ | 488 |  |  | $ | 45 |  |
| Continuing investing activities |  | (30) |  |  | (11,080) |  |
| Continuing financing activities |  | (2,747) |  |  | 2,383 |  |

[0001783180-25-000030:mdna:113]
Cash flows from continuing operating activities primarily represent inflows and outflows associated with our continuing operations. Primary activities include net earnings from continuing operations adjusted for non-cash transactions, working capital changes and changes in other assets and liabilities. The year-over-year increase in net cash provided by continuing operating activities was primarily driven by higher net earnings and a decrease in working capital balances compared with the prior period. Higher accounts payable balances more than offset higher accounts receivable and inventory balances.

[0001783180-25-000030:mdna:114]
Cash flows from continuing investing activities primarily represent inflows and outflows associated with long-term assets. Primary activities include capital expenditures, acquisitions, divestitures and proceeds from the sale of fixed assets. During the three months ended March 31, 2025, net cash used in continuing investing activities was $30 million. The primary driver of the outflow related to $63 million of capital expenditures which was partially offset by $36 million cash inflow related to settlement of derivatives. During the three months ended March 31, 2024, net cash used in continuing investing activities was $11.1 billion. The primary driver of the outflow related to the acquisition of the VCS Business, which totaled $10.8 billion, net of cash acquired. Additional investing outflows include $209 million related to settlement of derivatives and $102 million of capital expenditures.

[0001783180-25-000030:mdna:115]
Cash flows from continuing financing activities primarily represent inflows and outflows associated with equity or borrowings. During the three months ended March 31, 2025, net cash used in continuing financing activities was $2.7 billion. The primary driver of the outflow was related to repurchases of our common stock totaling $1.3 billion. In addition, we made long-term debt repayments of $1.2 billion and the payment of $198 million in dividends to our common shareowners. During the three months ended March 31, 2024, net cash provided by continuing financing activities was $2.4 billion. The primary driver of the inflow related to proceeds of long-term debt of $2.5 billion used to fund the cash portion of the acquisition of the VCS Business. This amount was partially offset by the outflow related to the payment of $159 million in dividends to our common shareowners.
