# CARR notes — 0001783180-25-000030


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001783180-25-000030:notes:1]
DESCRIPTION OF THE BUSINESS
Carrier Global Corporation (the "Company") is a global leader in intelligent climate and energy solutions with a focus on providing differentiated, digitally-enabled lifecycle solutions to its customers. The Company's portfolio includes industry-leading brands such as Carrier, Viessmann, Toshiba, Automated Logic and Carrier Transicold that offer innovative heating, ventilating, air conditioning ("HVAC") and cold chain transportation solutions to enhance the lives we live and the world we share. The Company also provides a broad array of related building services, including audit, design, installation, system integration, repair, maintenance and monitoring. The Company's operations are classified into four segments: Climate Solutions Americas, Climate Solutions Europe, Climate Solutions Asia Pacific, Middle East & Africa and Climate Solutions Transportation.

[0001783180-25-000030:notes:2]
In the opinion of management, the accompanying Unaudited Condensed Consolidated Financial Statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission (the "SEC"). The accompanying Unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for 2024 filed with the SEC on February 11, 2025 (the "2024 Form 10-K").


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001783180-25-000030:notes:3]
BASIS OF PRESENTATION
The Unaudited Condensed Consolidated Financial Statements include all accounts of the Company and its wholly-owned and majority-owned subsidiaries in which it has control. Inter-company accounts and transactions have been eliminated. Related party transactions between the Company and its equity method investees have not been eliminated. Non-controlling interest represents a non-controlling investor's interests in the results of subsidiaries that the Company controls and consolidates.

[0001783180-25-000030:notes:4]
[same as prior period, unchanged from 0001783180-24-000088:notes:6]

[0001783180-25-000030:notes:5]
During 2024, the Company completed several activities designed to simplify its business portfolio, transforming it into a pure-play climate and energy solutions provider. On January 2, 2024, the Company acquired the climate solutions business (the "VCS Business") of Viessmann Group GmbH & Co. KG (“Viessmann”). The VCS Business, primarily reported in the Climate Solutions Europe segment, is a premier residential and light commercial HVAC provider in Europe that expanded our portfolio to offer a global, comprehensive suite of sustainable and innovative building and cold-chain solutions. In addition, the Company divested its Commercial and Residential Fire, Access Solutions and Industrial Fire businesses which were historically reported in its Fire & Security segment. The transactions represented a single disposal plan to separately divest multiple businesses over different reporting periods and met the criteria to be presented as discontinued operations in the accompanying financial statements. The Company also divested its Commercial Refrigeration business (“CCR”) during 2024. CCR, which was historically reported in the Climate Solutions Transportation segment (previously named Refrigeration), did not meet the criteria to be presented as discontinued operations.

[0001783180-25-000030:notes:6]
Segment Reorganization

[0001783180-25-000030:notes:7]
As a result of the Company's portfolio transformation, the Company revised its reportable segments during the first quarter to better reflect its business strategy, align its management reporting and increase transparency for investors. Under the revised segment structure, the Company has three new regional HVAC operating segments. Combined with the Climate Solutions Transportation operating segment, the four operating segments also serve as the Company's reportable segments. This model is designed to create a simplified, more focused and customer-centric organization across the globe. Each segment reports through separate management teams which regularly review their operating results with the Company's Chief Operating Decision Maker (the "CODM") determined in accordance with applicable accounting guidance. In connection with the revised structure, the CODM changed the measure used to evaluate segment profitability from Operating profit to Segment operating profit. All prior period comparative information has been recast to reflect the revised segment structure. See Note 17 – Segment Financial Data for additional information.

[0001783180-25-000030:notes:8]
[same as prior period, unchanged from 0001783180-24-000088:notes:15]

[0001783180-25-000030:notes:9]
On April 3, 2020 (the "Distribution Date"), United Technologies Corporation ("UTC"), since renamed RTX Corporation ("Raytheon Technologies Corporation" or "RTX"), completed the spin-off of Carrier into an independent, publicly traded company (the "Separation") through a pro-rata distribution (the "Distribution") on a one-for-one basis of all of the outstanding shares of common stock of Carrier to UTC shareowners who held shares of UTC common stock as of the close of business on March 19, 2020, the record date of the Distribution. In addition, the Company entered into several agreements with UTC and Otis Worldwide Corporation ("Otis") that govern various aspects of the relationship among the Company, UTC and Otis. As of March 31, 2025, only certain portions of the Tax Matters Agreement ("TMA") remain in effect.

[0001783180-25-000030:notes:10]
[same as prior period, unchanged from 0001783180-24-000088:notes:17]

[0001783180-25-000030:notes:11]
[same as prior period, unchanged from 0001783180-24-000088:notes:18]

[0001783180-25-000030:notes:12]
Recently Issued Accounting Pronouncements

[0001783180-25-000030:notes:13]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures ("ASU 2023-09"), which requires public entities to disclose disaggregated information about their effective tax rate reconciliation as well as information on income taxes paid. ASU 2023-09 is effective for annual periods beginning after December 15, 2024, with early adoption permitted. The ASU requires additional disclosures and is not expected to have a material impact on the Company's financial statements.

[0001783180-25-000030:notes:14]
In November 2024, the FASB issued ASU 2024-03, Disaggregation of Income Statement Expenses (DISE) ("ASU 2024-03"), which requires public entities to disclose disaggregated information about expenses by nature on an interim and annual basis. ASU 2024-03 is effective for fiscal years beginning after December 15, 2026 and interim periods within fiscal years beginning after December 15, 2027, with early adoption permitted. The Company is currently assessing the impact of this ASU on its financial statements.


## us-gaap:InventoryDisclosureTextBlock

[0001783180-25-000030:notes:15]
[same as prior period, unchanged from 0001783180-24-000088:notes:23]

[0001783180-25-000030:notes:16]
[same as prior period, unchanged from 0001783180-24-000088:notes:24]

[0001783180-25-000030:notes:17]
| (In millions) |  | March 31,2025 |  | December 31,2024 |
| Raw materials |  | $ | 653 |  |  | $ | 625 |  |
| Work-in-process |  | 216 |  |  | 213 |  |
| Finished goods |  | 1,779 |  |  | 1,461 |  |
| Inventories, net |  | $ | 2,648 |  |  | $ | 2,299 |  |

[0001783180-25-000030:notes:18]
The Company performs periodic assessments utilizing customer demand, production requirements and historical usage rates to determine the existence of excess and obsolete inventory and records necessary provisions to reduce such inventories to the lower of cost or estimated net realizable value. Raw materials, work-in-process and finished goods are net of valuation reserves of $241 million and $215 million as of March 31, 2025 and December 31, 2024, respectively.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001783180-25-000030:notes:19]
[same as prior period, unchanged from 0001783180-24-000088:notes:27]

[0001783180-25-000030:notes:20]
In connection with its revised segment structure, the Company performed a quantitative goodwill impairment test on its reporting units prior to the reorganization to determine if any impairment existed. The tests did not indicate any goodwill impairment. The Company then reassigned goodwill among its new reporting units using a relative fair value approach.

[0001783180-25-000030:notes:21]
The changes in the carrying amount of reassigned goodwill were as follows:

[0001783180-25-000030:notes:22]
| (In millions) |  | Climate Solutions Americas |  | Climate Solutions Europe |  | Climate Solutions Asia Pacific, Middle East & Africa |  | Climate Solutions Transportation |  |  |  |  |  | Total |
| Balance as of December 31, 2024 |  | $ | 5,059 |  |  | $ | 7,035 |  |  | $ | 1,380 |  |  | $ | 1,127 |  |  |  |  |  |  | $ | 14,601 |  |
| Foreign currency translation |  | 1 |  |  | 319 |  |  | 28 |  |  | 10 |  |  |  |  |  |  | 358 |  |
| Balance as of March 31, 2025 |  | $ | 5,060 |  |  | $ | 7,354 |  |  | $ | 1,408 |  |  | $ | 1,137 |  |  |  |  |  |  | $ | 14,959 |  |

[0001783180-25-000030:notes:23]
Identifiable intangible assets are amortized over their estimated useful lives and consisted of the following:

[0001783180-25-000030:notes:24]
|  |  | March 31, 2025 |  | December 31, 2024 |
| (In millions) |  | Gross Amount |  | Accumulated Amortization |  | Net Amount |  | Gross Amount |  | Accumulated Amortization |  | Net Amount |
| Customer relationships |  | $ | 5,818 |  |  | $ | (1,115) |  |  | $ | 4,703 |  |  | $ | 5,607 |  |  | $ | (939) |  |  | $ | 4,668 |  |
| Patents and trademarks |  | 915 |  |  | (165) |  |  | 750 |  |  | 885 |  |  | (147) |  |  | 738 |  |
| Service portfolios and other |  | 1,585 |  |  | (558) |  |  | 1,027 |  |  | 1,530 |  |  | (504) |  |  | 1,026 |  |
| Total intangible assets |  | $ | 8,318 |  |  | $ | (1,838) |  |  | $ | 6,480 |  |  | $ | 8,022 |  |  | $ | (1,590) |  |  | $ | 6,432 |  |

[0001783180-25-000030:notes:25]
[same as prior period, unchanged from 0001783180-24-000088:notes:34]

[0001783180-25-000030:notes:26]
|  |  | Three Months Ended March 31, |  |  |
| (In millions) |  | 2025 |  | 2024 |  |  |  |  |
| Amortization expense of Intangible assets |  | $ | 208 |  |  | $ | 211 |  |  |  |  |  |


## us-gaap:DebtDisclosureTextBlock

[0001783180-25-000030:notes:27]
BORROWINGS AND LINES OF CREDIT
Long-term debt consisted of the following:

[0001783180-25-000030:notes:28]
| (In millions) |  |  |  | March 31,2025 |  | December 31,2024 |
| 2.242% Notes due 2025 (1) |  |  |  | $ | — |  |  | $ | 1,200 |  |
| 2.493% Notes due 2027 |  |  |  | 900 |  |  | 900 |  |
| 4.125% Notes due 2028 |  |  |  | 809 |  |  | 783 |  |
| 2.722% Notes due 2030 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.700% Notes due 2031 |  |  |  | 750 |  |  | 750 |  |
| 4.500% Notes due 2032 |  |  |  | 917 |  |  | 887 |  |
| 5.900% Notes due 2034 |  |  |  | 875 |  |  | 875 |  |
| 3.625% Notes due 2037 |  |  |  | 809 |  |  | 783 |  |
| 3.377% Notes due 2040 |  |  |  | 1,500 |  |  | 1,500 |  |
| 3.577% Notes due 2050 |  |  |  | 1,400 |  |  | 1,400 |  |
| 6.200% Notes due 2054 |  |  |  | 650 |  |  | 650 |  |
| Total long-term notes |  |  |  | 10,610 |  |  | 11,728 |  |
| Japanese Term Loan Facility |  |  |  | 358 |  |  | 342 |  |
| Other debt (including project financing obligations and finance leases) |  |  |  | 302 |  |  | 296 |  |
| Discounts and debt issuance costs |  |  |  | (86) |  |  | (88) |  |
| Total debt |  |  |  | 11,184 |  |  | 12,278 |  |
| Less: current portion of long-term debt |  |  |  | 104 |  |  | 1,252 |  |
| Long-term debt, net of current portion |  |  |  | $ | 11,080 |  |  | $ | 11,026 |  |

[0001783180-25-000030:notes:29]
(1) 2.242% Notes due February 15, 2025; repaid during February 2025.

[0001783180-25-000030:notes:30]
Revolving Credit Facility

[0001783180-25-000030:notes:31]
On December 20, 2024, the Company refinanced its revolving credit agreement with JPMorgan Chase Bank, N.A., as administrative agent, and certain other lenders, permitting aggregate borrowings of up to $2.5 billion pursuant to an unsecured, unsubordinated revolving credit facility that matures in December 2029 (the "Revolving Credit Facility"). The Revolving Credit Facility supports the Company's commercial paper program and can be used for other general corporate purposes. Borrowings are available in U.S. Dollars and Euros. U.S. Dollar borrowings bear interest at either a Term SOFR Rate plus 0.10% and a ratings-based margin or, alternatively, at an alternate base rate plus a ratings-based margin. Euro borrowings bear interest at an adjusted EURIBOR rate plus a ratings-based margin. A ratings-based commitment fee is charged on unused commitments. Upon entering into the agreement, the Company capitalized $11 million of deferred financing costs which are being amortized over its term. As of March 31, 2025, there were no borrowings outstanding under the Revolving Credit Facility.

[0001783180-25-000030:notes:32]
Commercial Paper Program

[0001783180-25-000030:notes:33]
The Company has a $2.0 billion unsecured, unsubordinated commercial paper program, which can be used for general corporate purposes, including the funding of working capital and potential acquisitions. As of March 31, 2025, there were no borrowings outstanding under the commercial paper program.

[0001783180-25-000030:notes:34]
Project Financing Arrangements

[0001783180-25-000030:notes:35]
The Company is involved in long-term construction contracts in which it arranges project financing with certain customers. As a result, the Company issued $6 million and $10 million of debt during the three months ended March 31, 2025 and 2024, respectively. Long-term debt repayments associated with these financing arrangements during the three months ended March 31, 2025 and 2024, were zero  and $5 million, respectively.

[0001783180-25-000030:notes:36]
Debt Covenants

[0001783180-25-000030:notes:37]
The Revolving Credit Facility, the indenture for the long-term notes and the five-year, JPY 54 billion (approximately $400 million) senior unsecured term loan facility ("Japanese Term Loan Facility") contain affirmative and negative covenants customary for financings of these types, which, among other things, limit the Company's ability to incur certain liens, to make certain fundamental changes and to enter into sale and leaseback transactions. As of March 31, 2025, the Company was in compliance with the covenants under the agreements governing its outstanding indebtedness.


## us-gaap:FairValueDisclosuresTextBlock

[0001783180-25-000030:notes:38]
[same as prior period, unchanged from 0001783180-24-000088:notes:63]

[0001783180-25-000030:notes:39]
[same as prior period, unchanged from 0001783180-24-000088:notes:64]

[0001783180-25-000030:notes:40]
[same as prior period, unchanged from 0001783180-24-000088:notes:65]

[0001783180-25-000030:notes:41]
[same as prior period, unchanged from 0001783180-24-000088:notes:66]

[0001783180-25-000030:notes:42]
[same as prior period, unchanged from 0001783180-24-000088:notes:67]

[0001783180-25-000030:notes:43]
[same as prior period, unchanged from 0001783180-24-000088:notes:68]

[0001783180-25-000030:notes:44]
During 2022, the Company entered into cross currency swaps with various financial institutions to fund a portion of the Yen-denominated purchase price of Toshiba Carrier Corporation ('TCC"). The cross currency swaps are measured at fair value on a recurring basis using observable market inputs, such as forward, discount and interest rates as well as credit default swap spreads. The Company designated the cross currency swaps as a partial hedge of its investment in certain subsidiaries whose functional currency is the Japanese Yen in order to manage foreign currency translation risk. As a result, changes in the fair value of the swaps are recorded in Equity in the accompanying Unaudited Condensed Consolidated Balance Sheet. From time to time, the Company settles and enters into new cross currency swaps with the same purpose and characteristics as initially established.

[0001783180-25-000030:notes:45]
The remaining portion of the Yen-denominated purchase price was funded by the Japanese Term Loan Facility. The carrying value of the facility is translated on a recurring basis using the exchange rate at the end of the applicable period and approximates its fair value. The Company designated the Japanese Term Loan Facility as a partial hedge of its investment in certain subsidiaries whose functional currency is the Japanese Yen in order to manage foreign currency translation risk. As a result, changes in the carrying value of the term loan facility associated with foreign exchange rate movements are recorded in Equity in the Unaudited Condensed Consolidated Balance Sheet.

[0001783180-25-000030:notes:46]
During 2023, the Company entered into several interest rate swap contracts to mitigate interest rate exposure on the forecasted issuance of long-term debt. The contracts had an aggregate notional amount of $1.5 billion and were designated as cash flow hedges with changes in fair value reported in Equity in the accompanying Unaudited Condensed Consolidated Balance Sheet. Fair value was measured on a recurring basis using observable market inputs, such as forward, discount and interest rates. In November 2023, the contracts were settled upon the issuance of the underlying debt. As a result, the Company deferred a net unrecognized gain of $58 million in Equity which will be subsequently recognized in Interest expense over the term of the related notes which range from 2034 to 2054. The amount expected to be amortized during 2025 is a net gain of $4 million.

[0001783180-25-000030:notes:47]
The Company enters into cross currency swaps in order to manage foreign currency translation risk on assets denominated in a functional currency other than the U.S. Dollar. The swaps have an aggregate notional amount of $2.0 billion and are measured at fair value on a recurring basis using observable market inputs, such as forward, discount and interest rates. The Company designates the cross currency swaps as a partial hedge of its investments in certain subsidiaries whose functional currency is not the U.S. Dollar. As a result, changes in the fair value of the swaps are recorded in Equity in the accompanying Unaudited Condensed Consolidated Balance Sheet.

[0001783180-25-000030:notes:48]
[same as prior period, unchanged from 0001783180-24-000088:notes:74]

[0001783180-25-000030:notes:49]
| (In millions) |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |
| March 31, 2025 |  |  |  |  |  |  |  |  |
| Derivative assets (1) |  | $ | 64 |  |  | $ | — |  |  | $ | 64 |  |  | $ | — |  |
| Derivative liabilities (2) |  | $ | (33) |  |  | $ | — |  |  | $ | (33) |  |  | $ | — |  |
| December 31, 2024 |  |  |  |  |  |  |  |  |
| Derivative assets (1) |  | $ | 82 |  |  | $ | — |  |  | $ | 82 |  |  | $ | — |  |
| Derivative liabilities (2) |  | $ | (41) |  |  | $ | — |  |  | $ | (41) |  |  | $ | — |  |

[0001783180-25-000030:notes:50]
[same as prior period, unchanged from 0001783180-24-000088:notes:76]

[0001783180-25-000030:notes:51]
[same as prior period, unchanged from 0001783180-24-000088:notes:77]

[0001783180-25-000030:notes:52]
[same as prior period, unchanged from 0001783180-24-000088:notes:79]

[0001783180-25-000030:notes:53]
|  |  | March 31, 2025 |  | December 31, 2024 |
| (In millions) |  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |
| Total long-term notes (1) |  | $ | 10,610 |  |  | $ | 9,774 |  |  | $ | 11,728 |  |  | $ | 10,798 |  |

[0001783180-25-000030:notes:54]
[same as prior period, unchanged from 0001783180-24-000088:notes:81]

[0001783180-25-000030:notes:55]
[same as prior period, unchanged from 0001783180-24-000088:notes:82]


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0001783180-25-000030:notes:56]
[same as prior period, unchanged from 0001783180-24-000088:notes:83]


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001783180-25-000030:notes:57]
[same as prior period, unchanged from 0001783180-24-000088:notes:84]

[0001783180-25-000030:notes:58]
[same as prior period, unchanged from 0001783180-24-000088:notes:85]

[0001783180-25-000030:notes:59]
|  |  | Three Months Ended March 31, |  |  |
| (In millions) |  | 2025 |  | 2024 |  |  |  |  |
| Defined benefit plans |  | $ | 5 |  |  | $ | 6 |  |  |  |  |  |
| Defined contribution plans |  | $ | 35 |  |  | $ | 39 |  |  |  |  |  |
| Multi-employer pension plans |  | $ | 3 |  |  | $ | 4 |  |  |  |  |  |

[0001783180-25-000030:notes:60]
[same as prior period, unchanged from 0001783180-24-000088:notes:87]

[0001783180-25-000030:notes:61]
|  |  | Three Months Ended March 31, |  |  |
| (In millions) |  | 2025 |  | 2024 |  |  |  |  |
| Service cost |  | $ | 3 |  |  | $ | 4 |  |  |  |  |  |
| Interest cost |  | 7 |  |  | 7 |  |  |  |  |  |
| Expected return on plan assets |  | (8) |  |  | (7) |  |  |  |  |  |
| Net periodic pension expense (benefit) |  | $ | 2 |  |  | $ | 4 |  |  |  |  |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001783180-25-000030:notes:62]
[same as prior period, unchanged from 0001783180-24-000088:notes:89]

[0001783180-25-000030:notes:63]
[same as prior period, unchanged from 0001783180-24-000088:notes:90]

[0001783180-25-000030:notes:64]
[same as prior period, unchanged from 0001783180-24-000088:notes:91]

[0001783180-25-000030:notes:65]
|  |  | Three Months Ended March 31, |  |  |
| (In millions) |  | 2025 |  | 2024 |  |  |  |  |
| Equity compensation costs - equity settled |  | $ | 23 |  |  | $ | 22 |  |  |  |  |  |
| Equity compensation costs - cash settled (1) |  | (1) |  |  | — |  |  |  |  |  |
| Total stock-based compensation expense |  | $ | 22 |  |  | $ | 22 |  |  |  |  |  |
| Amounts recorded in continuing operations |  | $ | 22 |  |  | $ | 19 |  |  |  |  |  |
| Amounts recorded in discontinued operations |  | — |  |  | 3 |  |  |  |  |  |
| Total stock-based compensation expense |  | $ | 22 |  |  | $ | 22 |  |  |  |  |  |

[0001783180-25-000030:notes:66]
[same as prior period, unchanged from 0001783180-24-000088:notes:93]


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001783180-25-000030:notes:67]
[same as prior period, unchanged from 0001783180-24-000088:notes:94]

[0001783180-25-000030:notes:68]
[same as prior period, unchanged from 0001783180-24-000088:notes:95]

[0001783180-25-000030:notes:69]
|  |  | Three Months Ended March 31, |
| (In millions) |  | 2025 |  | 2024 |
| Balance as of January 1, |  | $ | 786 |  |  | $ | 568 |  |
| Warranties, performance guarantees issued and changes in estimated liability |  | 89 |  |  | 91 |  |
| Settlements made |  | (69) |  |  | (57) |  |
| Other |  | 8 |  |  | (4) |  |
| Acquisitions |  | — |  |  | 202 |  |
| Balance as of March 31, |  | $ | 814 |  |  | $ | 800 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001783180-25-000030:notes:70]
EQUITY
The authorized number of shares of common stock of Carrier is 4,000,000,000 shares of $0.01 par value. As of March 31, 2025 and December 31, 2024, 949,244,473 and 948,068,772 shares of common stock were issued, respectively, which includes 89,054,545 and 70,093,639 shares of treasury stock, respectively.

[0001783180-25-000030:notes:71]
[same as prior period, unchanged from 0001783180-24-000088:notes:98]

[0001783180-25-000030:notes:72]
The Company may repurchase its outstanding common stock from time to time subject to market conditions and at the Company's discretion. Repurchases occur in the open market or through one or more other public or private transactions pursuant to plans complying with Rules 10b5-1 and 10b-18 under the Exchange Act. Shares acquired are recognized at cost and presented separately on the balance sheet as a reduction to Equity. Since the initial authorization in February 2021, the Company's Board of Directors authorized the repurchase of up to $7.1 billion of the Company's outstanding common stock.

[0001783180-25-000030:notes:73]
During the three months ended March 31, 2025, the Company repurchased 19.0 million shares of common stock for an aggregate purchase price of $1.3 billion. As a result, the Company had approximately $1.9 billion remaining under the current authorization at March 31, 2025.

[0001783180-25-000030:notes:74]
[same as prior period, unchanged from 0001783180-24-000088:notes:103]

[0001783180-25-000030:notes:75]
A summary of changes in the components of Accumulated other comprehensive income (loss) for the three months ended March 31, 2025 is as follows:

[0001783180-25-000030:notes:76]
| (In millions) |  | Foreign Currency Translation |  | Defined Benefit Pension and Post-retirement Plans |  |  |  | Unrealized Hedging Gains (Losses) |  | Accumulated Other Comprehensive Income (Loss) |
| Balance as of December 31, 2024 |  | $ | (2,053) |  |  | $ | (107) |  |  |  |  | $ | 54 |  |  | $ | (2,106) |  |
| Other comprehensive income (loss) before reclassifications, net |  | 634 |  |  | — |  |  |  |  | — |  |  | 634 |  |
| Amounts reclassified, pre-tax |  | — |  |  | — |  |  |  |  | (1) |  |  | (1) |  |
| Balance as of March 31, 2025 |  | $ | (1,419) |  |  | $ | (107) |  |  |  |  | $ | 53 |  |  | $ | (1,473) |  |

[0001783180-25-000030:notes:77]
A summary of changes in the components of Accumulated other comprehensive income (loss) for the three months ended March 31, 2024 is as follows:

[0001783180-25-000030:notes:78]
| (In millions) |  | Foreign Currency Translation |  | Defined Benefit Pension and Post-retirement Plans |  |  |  | Unrealized Hedging Gains (Losses) |  | Accumulated Other Comprehensive Income (Loss) |
| Balance as of December 31, 2023 |  | $ | (1,444) |  |  | $ | (100) |  |  |  |  | $ | 58 |  |  | $ | (1,486) |  |
| Other comprehensive income (loss) before reclassifications, net |  | (385) |  |  | — |  |  |  |  | — |  |  | (385) |  |
| Amounts reclassified, pre-tax |  | — |  |  | — |  |  |  |  | (1) |  |  | (1) |  |
| Balance as of March 31, 2024 |  | $ | (1,829) |  |  | $ | (100) |  |  |  |  | $ | 57 |  |  | $ | (1,872) |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001783180-25-000030:notes:79]
[same as prior period, unchanged from 0001783180-24-000088:notes:108]

[0001783180-25-000030:notes:80]
External segment sales disaggregated by product and service are as follows:

[0001783180-25-000030:notes:81]
|  |  | Three Months Ended March 31, |  |  |
| (In millions) |  | 2025 |  | 2024 |  |  |  |  |
| Sales Type |  |  |  |  |  |  |  |  |
| Product |  | $ | 2,319 |  |  | $ | 2,105 |  |  |  |  |  |
| Service |  | 253 |  |  | 255 |  |  |  |  |  |
| Climate Solutions Americas sales |  | 2,572 |  |  | 2,360 |  |  |  |  |  |
| Product |  | 1,071 |  |  | 1,238 |  |  |  |  |  |
| Service |  | 98 |  |  | 54 |  |  |  |  |  |
| Climate Solutions Europe sales |  | 1,169 |  |  | 1,292 |  |  |  |  |  |
| Product |  | 660 |  |  | 728 |  |  |  |  |  |
| Service |  | 166 |  |  | 156 |  |  |  |  |  |
| Climate Solutions Asia Pacific, Middle East & Africa sales |  | 826 |  |  | 884 |  |  |  |  |  |
| Product |  | 602 |  |  | 772 |  |  |  |  |  |
| Service |  | 49 |  |  | 112 |  |  |  |  |  |
| Climate Solutions Transportation sales |  | 651 |  |  | 884 |  |  |  |  |  |
| Net sales |  | $ | 5,218 |  |  | $ | 5,420 |  |  |  |  |  |

[0001783180-25-000030:notes:82]
[same as prior period, unchanged from 0001783180-24-000088:notes:112]

[0001783180-25-000030:notes:83]
[same as prior period, unchanged from 0001783180-24-000088:notes:113]

[0001783180-25-000030:notes:84]
| (In millions) |  | March 31,2025 |  | December 31,2024 |
| Contract assets (included within Other current assets) |  | $ | 452 |  |  | $ | 366 |  |
| Contract assets, non-current (included within Other assets) |  | 35 |  |  | 65 |  |
| Total contract assets |  | 487 |  |  | 431 |  |
| Contract liabilities (included within Accrued liabilities) |  | (542) |  |  | (553) |  |
| Contract liabilities, non-current (included within Other long-term liabilities) |  | (168) |  |  | (164) |  |
| Total contract liabilities |  | (710) |  |  | (717) |  |
| Net contract assets (liabilities) |  | $ | (223) |  |  | $ | (286) |  |

[0001783180-25-000030:notes:85]
The timing of revenue recognition, billings and cash collections results in contract assets and contract liabilities. Contract assets relate to the conditional right to consideration for any completed performance under a contract when costs are incurred in excess of billings under the percentage-of-completion methodology. Contract liabilities relate to payments received in advance of performance under a contract or when the Company has a right to consideration that is conditioned upon transfer of a good or service to a customer. Contract liabilities are recognized as revenue as (or when) the Company performs under the contract.
The Company recognized revenue of $180 million during the three months ended March 31, 2025, that related to contract liabilities as of January 1, 2025. The Company expects a majority of its current contract liabilities at the end of the period to be recognized as revenue in the next 12 months.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0001783180-25-000030:notes:86]
[same as prior period, unchanged from 0001783180-24-000088:notes:116]

[0001783180-25-000030:notes:87]
[same as prior period, unchanged from 0001783180-24-000088:notes:117]


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0001783180-25-000030:notes:88]
Geographic external sales are attributed to the geographic regions based on their location of origin. With the exception of the U.S. presented in the table below, there were no individually significant countries with sales exceeding 10% of total sales during the three months ended March 31, 2025 and 2024.

[0001783180-25-000030:notes:89]
|  |  | Three Months Ended March 31, |  |  |
| (In millions) |  | 2025 |  | 2024 |  |  |  |  |
| United States |  | $ | 2,738 |  |  | $ | 2,547 |  |  |  |  |  |
| International: |  |  |  |  |  |  |  |  |
| Europe |  | 1,401 |  |  | 1,751 |  |  |  |  |  |
| Asia Pacific |  | 941 |  |  | 960 |  |  |  |  |  |
| Other |  | 138 |  |  | 162 |  |  |  |  |  |
| Net sales |  | $ | 5,218 |  |  | $ | 5,420 |  |  |  |  |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001783180-25-000030:notes:90]
[same as prior period, unchanged from 0001783180-24-000088:notes:118]

[0001783180-25-000030:notes:91]
[same as prior period, unchanged from 0001783180-24-000088:notes:119]

[0001783180-25-000030:notes:92]
|  | Three Months Ended March 31, |  |  |
| (In millions) | 2025 |  | 2024 |  |  |  |  |
| Climate Solutions Americas | $ | 3 |  |  | $ | (1) |  |  |  |  |  |
| Climate Solutions Europe | — |  |  | 10 |  |  |  |  |  |
| Climate Solutions Asia Pacific, Middle East & Africa | 1 |  |  | (2) |  |  |  |  |  |
| Climate Solutions Transportation | 1 |  |  | — |  |  |  |  |  |
| Total Segment | 5 |  |  | 7 |  |  |  |  |  |
| Corporate and other | 3 |  |  | 1 |  |  |  |  |  |
| Total restructuring costs (1) | $ | 8 |  |  | $ | 8 |  |  |  |  |  |
| Cost of sales | $ | 2 |  |  | $ | 8 |  |  |  |  |  |
| Selling, general and administrative | 6 |  |  | — |  |  |  |  |  |
| Total restructuring costs (1) | $ | 8 |  |  | $ | 8 |  |  |  |  |  |

[0001783180-25-000030:notes:93]
(1) Restructuring costs include period-related charges.

[0001783180-25-000030:notes:94]
[same as prior period, unchanged from 0001783180-24-000088:notes:122]

[0001783180-25-000030:notes:95]
|  |  | Three Months Ended March 31, |
| (In millions) |  | 2025 |  | 2024 |
| Balance as of January 1, |  | $ | 69 |  |  | $ | 41 |  |
| Net pre-tax restructuring costs |  | 4 |  |  | 8 |  |
| Acquisitions |  | — |  |  | 8 |  |
| Utilization, foreign exchange and other |  | (17) |  |  | (19) |  |
| Balance as of March 31, |  | $ | 56 |  |  | $ | 38 |  |

[0001783180-25-000030:notes:96]
As of March 31, 2025, the Company had $56 million accrued for costs associated with its announced restructuring initiatives. The balance relates to cost reduction efforts, primarily severance related across each of the Company's segments. The Company expects a majority of the balance to be utilized within one year.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001783180-25-000030:notes:97]
INCOME TAXES
The Company accounts for income tax expense in accordance with ASC 740, Income Taxes ("ASC 740"), which requires an estimate of the annual effective income tax rate for the full year to be applied to the respective interim period, taking into account year-to-date amounts and projected results for the full year. The effective tax rate was 20.3% for the three months ended March 31, 2025 compared with 19.3% for the three months ended March 31, 2024. The year-over-year increase was primarily driven by the absence of a $21 million tax benefit associated with the TMA and UTC's conclusion of certain income tax matters from their 2017 and 2018 tax audit with the U.S. Internal Revenue Service ("IRS") recognized during the three months ended March 31, 2024. In addition, the three months ended March 31, 2025 included an $8 million tax benefit generated by the purchase of investment tax credits from a third-party.

[0001783180-25-000030:notes:98]
[same as prior period, unchanged from 0001783180-24-000088:notes:127]

[0001783180-25-000030:notes:99]
The Company conducts business globally and files income tax returns in U.S. federal, state and foreign jurisdictions. In certain jurisdictions, the Company's operations were included in UTC's combined tax returns for the periods through the Distribution. The IRS finalized the examination of UTC's tax years 2017 and 2018 resulting in the recognition of a tax benefit of $21 million in the first quarter of 2024. The IRS examination of UTC's tax year 2020, which Carrier was included in through the date of Distribution, is expected to conclude in 2025. Carrier's tax year 2022 is under examination by the IRS, but is in an early stage. In the three months ended March 31, 2025, the Australia tax office began an audit of the Company's 2021 tax return, including the review of the disentanglement of the Chubb Australia business. In the normal course of business, the Company is subject to examination by taxing authorities throughout the world, including Australia, Canada, China, France, Germany, Hong Kong, India, Italy, Mexico, the Netherlands, Poland, Singapore, the United Kingdom and the United States. The Company is no longer subject to U.S. federal income tax examination for years prior to 2020 and, with few exceptions, is no longer subject to state, local and foreign income tax examinations for tax years prior to 2013.

[0001783180-25-000030:notes:100]
In the ordinary course of business, there is inherent uncertainty in quantifying the Company's income tax positions. The Company assesses its income tax positions and records tax benefits for all years subject to examination based upon management’s evaluation of the facts, circumstances and information available at the reporting date. The Company believes that it is reasonably possible that a net decrease in unrecognized tax benefits of $15 million to $30 million may occur within 12 months as a result of additional uncertain tax positions, the revaluation of uncertain tax positions arising from examinations, appeals, court decisions and/or the expiration of tax statutes.


## us-gaap:EarningsPerShareTextBlock

[0001783180-25-000030:notes:101]
[same as prior period, unchanged from 0001783180-24-000088:notes:130]

[0001783180-25-000030:notes:102]
[same as prior period, unchanged from 0001783180-24-000088:notes:131]

[0001783180-25-000030:notes:103]
|  |  | Three Months Ended March 31, |  |  |
| (In millions, except per share amounts) |  | 2025 |  | 2024 |  |  |  |  |
| Net earnings (loss) attributable to common shareowners |  | $ | 412 |  |  | $ | 269 |  |  |  |  |  |
| Basic weighted-average number of shares outstanding |  | 866.9 |  |  | 899.2 |  |  |  |  |  |
| Stock awards and equity units (share equivalent) |  | 11.4 |  |  | 13.8 |  |  |  |  |  |
| Diluted weighted-average number of shares outstanding |  | 878.3 |  |  | 913.0 |  |  |  |  |  |
| Antidilutive shares excluded from computation of diluted earnings per share |  | 3.7 |  |  | 4.2 |  |  |  |  |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001783180-25-000030:notes:104]
[same as prior period, unchanged from 0001783180-24-000088:notes:133]

[0001783180-25-000030:notes:105]
[same as prior period, unchanged from 0001783180-24-000088:notes:134]

[0001783180-25-000030:notes:106]
On January 2, 2024, the Company completed the acquisition of the VCS Business from Viessmann for total consideration of $14.2 billion. The purchase price consisted of (i) $11.2 billion in cash and (ii) 58,608,959 shares of the Company's common stock, subject to certain lock-up provisions and anti-dilution protection. The Company funded the cash portion of the purchase price with a combination of cash on hand, long term debt issuances and borrowings under various term facilities.

[0001783180-25-000030:notes:107]
[same as prior period, unchanged from 0001783180-24-000088:notes:136]

[0001783180-25-000030:notes:108]
[same as prior period, unchanged from 0001783180-24-000088:notes:137]

[0001783180-25-000030:notes:109]
[same as prior period, unchanged from 0001783180-24-000088:notes:138]

[0001783180-25-000030:notes:110]
The allocation of the purchase price is as follows:

[0001783180-25-000030:notes:111]
| (In millions) |  |  |  |  |  | January 2,2024 |
| Cash and cash equivalents |  |  |  |  |  | $ | 393 |  |
| Accounts receivable |  |  |  |  |  | 413 |  |
| Inventories |  |  |  |  |  | 920 |  |
| Other current assets |  |  |  |  |  | 17 |  |
| Fixed assets |  |  |  |  |  | 919 |  |
| Intangible assets |  |  |  |  |  | 6,645 |  |
| Other assets |  |  |  |  |  | 299 |  |
| Accounts payable |  |  |  |  |  | (290) |  |
| Other liabilities, current |  |  |  |  |  | (663) |  |
| Future income tax obligations |  |  |  |  |  | (1,810) |  |
| Other liabilities |  |  |  |  |  | (301) |  |
| Total identifiable net assets |  |  |  |  |  | 6,542 |  |
| Goodwill |  |  |  |  |  | 7,607 |  |
| Total consideration |  |  |  |  |  | $ | 14,149 |  |

[0001783180-25-000030:notes:112]
[same as prior period, unchanged from 0001783180-24-000088:notes:141]

[0001783180-25-000030:notes:113]
[same as prior period, unchanged from 0001783180-24-000088:notes:142]

[0001783180-25-000030:notes:114]
[same as prior period, unchanged from 0001783180-24-000088:notes:143]

[0001783180-25-000030:notes:115]
The valuation of intangible assets was determined using an income approach methodology including the multi-period excess earnings method and the relief from royalty method. Key assumptions used in estimating future cash flows included projected short-term revenue growth rates, research and development expenses, EBITDA margins, income tax rates, discount rates, customer attrition rates, royalty rates, contributory asset charge and obsolescence rates among others. The projected future cash flows are discounted to present value using an appropriate discount rate. The Company finalized the process of allocating the purchase price and valuing the acquired assets and liabilities during 2024.

[0001783180-25-000030:notes:116]
During 2024, $40 million of acquisition-related costs were incurred, of which $30 million was recognized during the three months ended March 31, 2024. These acquisition costs are reflected within Selling, general and administrative in the Condensed Consolidated Statement of Operations.

[0001783180-25-000030:notes:117]
The assets, liabilities and results of operations of the VCS Business were consolidated in the accompanying Condensed Consolidated Financial Statements as of the date of acquisition and reported primarily within the Company's Climate Solutions Europe segment.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001783180-25-000030:notes:118]
[same as prior period, unchanged from 0001783180-24-000088:notes:154]

[0001783180-25-000030:notes:119]
During 2024, the Company exited its Fire & Security segment in multiple transactions that represented a single disposal plan to separately divest multiple businesses over different reporting periods. As a result, the components of the Fire & Security segment in aggregate met the criteria to be presented as discontinued operations in the accompanying Unaudited Condensed Consolidated Statement of Operations and Unaudited Condensed Consolidated Statement of Cash Flows. Amounts reported during 2024 include the operating results of each component through their respective date of sale and related gain on sale. Amounts reported during 2025 relate to retained obligations from these business divestitures.

[0001783180-25-000030:notes:120]
[same as prior period, unchanged from 0001783180-24-000088:notes:156]

[0001783180-25-000030:notes:121]
|  | Three Months Ended March 31, |  |  |
| (In millions) | 2025 |  | 2024 |  |  |  |  |
| Net sales | $ | — |  |  | $ | 762 |  |  |  |  |  |
| Costs of sales | — |  |  | (442) |  |  |  |  |  |
| Research and development | — |  |  | (32) |  |  |  |  |  |
| Selling, general and administrative | — |  |  | (178) |  |  |  |  |  |
| Other income (expense), net | — |  |  | 5 |  |  |  |  |  |
| Interest (expense) income, net | — |  |  | (24) |  |  |  |  |  |
| Earnings before income taxes | — |  |  | 91 |  |  |  |  |  |
| Income tax (expense) benefit | — |  |  | 1 |  |  |  |  |  |
| Discontinued operations, net of tax | $ | — |  |  | $ | 92 |  |  |  |  |  |

[0001783180-25-000030:notes:122]
On December 2, 2024, the Company completed the sale of the Commercial and Residential Fire business ("CRF Business") for cash proceeds of $2.9 billion. The CRF Business, historically reported in the Company's Fire & Security segment, is a leading manufacturer of fire detection and alarm solutions for both commercial and residential applications. Upon sale, the Company recognized a net gain on the sale of $1.4 billion, which is included in Discontinued operations, net of tax. The net proceeds received are subject to working capital and other adjustments provided in the stock purchase agreement governing the sale of the CRF Business.

[0001783180-25-000030:notes:123]
On July 1, 2024, the Company completed the sale of its Industrial Fire business ("Industrial Fire") for cash proceeds of $1.4 billion. Industrial Fire, historically reported in the Company's Fire & Security segment, is a leading manufacturer of a full spectrum of fire detection and suppression solutions and services in critical high-hazard environments, including oil and gas, power generation, marine and offshore facilities, automotive, data centers and aircraft hangars. Upon sale, the Company recognized a net gain on the sale of $319 million, which is included in Discontinued operations, net of tax.

[0001783180-25-000030:notes:124]
On June 2, 2024, the Company completed the sale of its Access Solutions business ("Access Solutions") for cash proceeds of $5.0 billion. Access Solutions, historically reported in the Company's Fire & Security segment, is a global supplier of physical security and digital access solutions supporting the hospitality, commercial, education and military markets. Upon sale, the Company recognized a net gain on the sale of $1.8 billion, which is included in Discontinued operations, net of tax.

[0001783180-25-000030:notes:125]
Continuing Operations

[0001783180-25-000030:notes:126]
On October 1, 2024, the Company completed the sale of CCR for cash proceeds of $679 million. CCR, historically reported in the Company's Climate Solutions Transportation segment, is a global supplier of turnkey solutions for commercial refrigeration systems and services, with a primary focus on serving food retail customers, cold storage facilities and warehouses. Upon sale, the Company recognized a gross gain on the sale of $318 million, which is included in Other income (expense), net. The net proceeds received are subject to working capital and other adjustments provided in the stock purchase agreement governing the sale of CCR.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001783180-25-000030:notes:127]
SEGMENT FINANCIAL DATA
The Company conducts its operations through four reportable operating segments. In accordance with ASC 280 - Segment Reporting, the Company's segments maintain separate financial information for which results of operations are evaluated on a regular basis by the Company's CODM in deciding how to allocate resources and in assessing performance.

[0001783180-25-000030:notes:128]
•Climate Solutions Americas (CSA) provides products, controls, services and solutions to meet the heating, cooling and ventilation needs of residential and commercial customers in North and South America while enhancing building performance, health, energy efficiency and sustainability.

[0001783180-25-000030:notes:129]
•Climate Solutions Europe (CSE) provides products, controls, services and solutions to meet the heating, cooling and ventilation needs of residential and commercial customers in Europe while enhancing building performance, health, energy efficiency and sustainability.

[0001783180-25-000030:notes:130]
•Climate Solutions Asia Pacific, Middle East & Africa (CSAME) provides products, controls, services and solutions to meet the heating, cooling and ventilation needs of residential and commercial customers in Asia Pacific, the Middle East and Africa while enhancing building performance, health, energy efficiency and sustainability.

[0001783180-25-000030:notes:131]
•Climate Solutions Transportation (CST) includes global transport refrigeration and monitoring products, services and digital solutions for trucks, trailers, shipping containers, intermodal and rail.

[0001783180-25-000030:notes:132]
The Corporate and Other category primarily includes corporate administrative functions such as tax, treasury, internal audit, legal and human resources. A portion of these costs and costs associated with shared service centers that provide transaction processing, accounting and other business support functions are allocated to the reportable segments.

[0001783180-25-000030:notes:133]
Segment operating profit is the measure of profit and loss that the Company’s CODM, the Chief Executive Officer (“CEO”), uses to evaluate the financial performance of the business and as the basis for resource allocation, performance reviews and compensation. It represents operating profit (a GAAP measure) adjusted to exclude restructuring costs, amortization of acquired intangible assets and other significant items of a nonoperational nature. Targets are established on an annual basis and used by the CODM throughout the year to compare with actual results. Quarterly forecasts supplement annual targets and provide incremental information utilized to assess the performance of a segment. Variance analysis further provides insight into segment end-markets and operational cost optimization. These results also support the CODM to manage the Company’s business portfolio.

[0001783180-25-000030:notes:134]
Consistent with the management approach for segment reporting, the tables below present reported external net sales and significant expense categories for each of the Company’s segments that are regularly provided to the CODM and included in its reported measure of segment profit or loss. The Company manages research and development costs on a global basis and allocates these costs to the reportable segments.

[0001783180-25-000030:notes:135]
A summary of results by reportable segment are as follows:

[0001783180-25-000030:notes:136]
|  |  | Three Months Ended March 31, 2025 |
| (In millions) |  | CSA |  | CSE |  | CSAME |  | CST |  | Segment Total |  |  |  |  |
| Net sales |  | $ | 2,572 |  |  | $ | 1,169 |  |  | $ | 826 |  |  | $ | 651 |  |  | $ | 5,218 |  |  |  |  |  |
| Cost of goods sold |  | (1,700) |  |  | (788) |  |  | (609) |  |  | (471) |  |  | (3,568) |  |  |  |  |  |
| Research and development |  | (86) |  |  | (18) |  |  | (15) |  |  | (16) |  |  | (135) |  |  |  |  |  |
| Selling, general and administrative |  | (250) |  |  | (257) |  |  | (112) |  |  | (69) |  |  | (688) |  |  |  |  |  |
| Equity method investment net earnings |  | 26 |  |  | (2) |  |  | 18 |  |  | 2 |  |  | 44 |  |  |  |  |  |
| Other income (expense), net |  | 8 |  |  | 1 |  |  | 13 |  |  | — |  |  | 22 |  |  |  |  |  |
| Segment operating profit |  | $ | 570 |  |  | $ | 105 |  |  | $ | 121 |  |  | $ | 97 |  |  | $ | 893 |  |  |  |  |  |

[0001783180-25-000030:notes:137]
|  |  | Three Months Ended March 31, 2024 |
| (In millions) |  | CSA |  | CSE |  | CSAME |  | CST |  | Segment Total |  |  |  |  |
| Net sales |  | $ | 2,360 |  |  | $ | 1,292 |  |  | $ | 884 |  |  | $ | 884 |  |  | $ | 5,420 |  |  |  |  |  |
| Cost of goods sold |  | (1,623) |  |  | (826) |  |  | (643) |  |  | (651) |  |  | (3,743) |  |  |  |  |  |
| Research and development |  | (109) |  |  | (23) |  |  | (19) |  |  | (22) |  |  | (173) |  |  |  |  |  |
| Selling, general and administrative |  | (231) |  |  | (275) |  |  | (128) |  |  | (96) |  |  | (730) |  |  |  |  |  |
| Equity method investment net earnings |  | 23 |  |  | (1) |  |  | 7 |  |  | 2 |  |  | 31 |  |  |  |  |  |
| Other income (expense), net |  | 5 |  |  | — |  |  | 7 |  |  | (4) |  |  | 8 |  |  |  |  |  |
| Segment operating profit |  | $ | 425 |  |  | $ | 167 |  |  | $ | 108 |  |  | $ | 113 |  |  | $ | 813 |  |  |  |  |  |

[0001783180-25-000030:notes:138]
|  |  | Three Months Ended March 31, |  |  |
| (In millions) |  | 2025 |  | 2024 |  |  |  |  |
| Reconciliation to Earnings before income taxes |  |  |  |  |  |  |  |  |
| Segment operating profit |  | $ | 893 |  |  | $ | 813 |  |  |  |  |  |
| Corporate and other |  | (50) |  |  | (49) |  |  |  |  |  |
| Restructuring costs |  | (8) |  |  | (8) |  |  |  |  |  |
| Amortization of acquired intangibles |  | (201) |  |  | (172) |  |  |  |  |  |
| Acquisition on step-up amortization |  | — |  |  | (111) |  |  |  |  |  |
| Acquisition/divestiture-related costs |  | (5) |  |  | (48) |  |  |  |  |  |
| Viessmann-related hedges |  | — |  |  | (86) |  |  |  |  |  |
| Gain on liability adjustment |  | — |  |  | 46 |  |  |  |  |  |
| Non-service pension (expense) benefit |  | 1 |  |  | — |  |  |  |  |  |
| Interest (expense) income, net |  | (82) |  |  | (141) |  |  |  |  |  |
| Earnings before income taxes |  | $ | 548 |  |  | $ | 244 |  |  |  |  |  |

[0001783180-25-000030:notes:139]
Segment operating profit is not defined under GAAP and may not be comparable to similarly titled measures used by other companies. Measures of capital expenditures, depreciation expense, amortization expense and total assets by reportable segment are not provided to the CODM and therefore not disclosed.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001783180-25-000030:notes:140]
RELATED PARTIES
Equity Method Investments

[0001783180-25-000030:notes:141]
The Company sells products to and purchases products from unconsolidated entities accounted for under the equity method and, therefore, these entities are considered to be related parties. Amounts attributable to equity method investees are as follows:

[0001783180-25-000030:notes:142]
|  |  | Three Months Ended March 31, |  |  |
| (In millions) |  | 2025 |  | 2024 |  |  |  |  |
| Sales to equity method investees included in Product sales |  | $ | 780 |  |  | $ | 723 |  |  |  |  |  |
| Purchases from equity method investees included in Cost of products sold |  | $ | 47 |  |  | $ | 55 |  |  |  |  |  |

[0001783180-25-000030:notes:143]
The Company had receivables from and payables to equity method investees as follows:

[0001783180-25-000030:notes:144]
| (In millions) |  | March 31,2025 |  | December 31,2024 |
| Receivables from equity method investees included in Accounts receivable, net |  | $ | 311 |  |  | $ | 363 |  |
| Payables to equity method investees included in Accounts payable |  | $ | 32 |  |  | $ | 32 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001783180-25-000030:notes:145]
COMMITMENTS AND CONTINGENT LIABILITIES
The Company is involved in various litigation, claims and administrative proceedings, including those related to environmental (including asbestos) and legal matters. In accordance with ASC 450, Contingencies, the Company records accruals for loss contingencies when it is probable that a liability has been incurred and the amount of the loss can be reasonably estimated. These accruals are generally based upon a range of possible outcomes. If no amount within the range is a better estimate than any other, the Company accrues the minimum amount. In addition, these estimates are reviewed periodically and adjusted to reflect additional information when it becomes available. The Company is unable to predict the final outcome of the following matters based on the information currently available, except as otherwise noted. However, the Company does not believe that the resolution of any of these matters will have a material adverse effect upon its results of operations or financial condition.

[0001783180-25-000030:notes:146]
Environmental Matters

[0001783180-25-000030:notes:147]
The Company’s operations are subject to environmental regulation by various authorities. The Company has accrued for the costs of environmental remediation activities, including but not limited to investigatory, remediation, operating and maintenance costs and performance guarantees. The most likely cost to be incurred is accrued based on an evaluation of currently available facts with respect to individual sites, including the technology required to remediate, current laws and regulations and prior remediation experience.

[0001783180-25-000030:notes:148]
The outstanding liabilities for environmental obligations are as follows:

[0001783180-25-000030:notes:149]
| (In millions) |  | March 31,2025 |  | December 31,2024 |
| Environmental reserves included in Accrued liabilities |  | $ | 18 |  |  | $ | 25 |  |
| Environmental reserves included in Other long-term liabilities |  | 188 |  |  | 185 |  |
| Total Environmental reserves |  | $ | 206 |  |  | $ | 210 |  |

[0001783180-25-000030:notes:150]
For sites with multiple responsible parties, the Company considers its likely proportionate share of the anticipated remediation costs and the ability of other parties to fulfill their obligations in establishing a provision for these costs. Accrued environmental liabilities are not reduced by potential insurance reimbursements and are undiscounted.

[0001783180-25-000030:notes:151]
Asbestos Matters

[0001783180-25-000030:notes:152]
The Company has been named as a defendant in lawsuits alleging personal injury as a result of exposure to asbestos allegedly integrated into certain Carrier products or business premises. While the Company has never manufactured asbestos and no longer incorporates it into any currently-manufactured products, certain products that the Company no longer manufactures contained components incorporating asbestos. A substantial majority of these asbestos-related claims have been dismissed without payment or have been covered in full or in part by insurance or other forms of indemnity. Additional cases were litigated and settled without any insurance reimbursement. The amounts involved in asbestos-related claims were not material individually or in the aggregate in any period.

[0001783180-25-000030:notes:153]
The Company's asbestos liabilities and related insurance recoveries are as follows:

[0001783180-25-000030:notes:154]
| (In millions) |  | March 31,2025 |  | December 31,2024 |
| Asbestos liabilities included in Accrued liabilities |  | $ | 17 |  |  | $ | 17 |  |
| Asbestos liabilities included in Other long-term liabilities |  | 203 |  |  | 208 |  |
| Total Asbestos liabilities |  | $ | 220 |  |  | $ | 225 |  |
| Asbestos-related recoveries included in Other current assets |  | $ | 7 |  |  | $ | 7 |  |
| Asbestos-related recoveries included in Other assets |  | 86 |  |  | 88 |  |
| Total Asbestos-related recoveries |  | $ | 93 |  |  | $ | 95 |  |

[0001783180-25-000030:notes:155]
The amounts recorded for asbestos-related liabilities are based on currently available information and assumptions that the Company believes are reasonable and are made with input from outside actuarial experts. These amounts are undiscounted and exclude the Company’s legal fees to defend the asbestos claims, which are expensed as incurred. In addition, the Company has recorded insurance recovery receivables for probable asbestos-related recoveries.

[0001783180-25-000030:notes:156]
Aqueous Film Forming Foam Litigation

[0001783180-25-000030:notes:157]
As of March 31, 2025, the Company, Kidde-Fenwal, Inc. ("KFI") and others have been named as defendants in more than 10,000 lawsuits filed in United States state or federal courts and a single case in Canada alleging that the historic use of Aqueous Film Forming Foam ("AFFF") caused personal injuries and damage to property and water supplies. In December 2018, the U.S. Judicial Panel on Multidistrict Litigation transferred and consolidated all AFFF cases pending in the U.S. federal courts against the Company, KFI and others to the U.S. District Court for the District of South Carolina (the "MDL Proceedings"). Individual plaintiffs in the MDL Proceedings generally seek damages for alleged personal injuries, medical monitoring, diminution in property value and injunctive relief to remediate alleged contamination of water supplies. U.S. state, municipal and water utility plaintiffs in the MDL Proceedings generally seek damages and costs related to the remediation of public property and water supplies.

[0001783180-25-000030:notes:158]
AFFF is a firefighting foam, developed beginning in the late 1960s pursuant to U.S. military specification, used to extinguish certain types of hydrocarbon-fueled fires. The lawsuits identified above relate to Kidde Fire Fighting, Inc., which owned the “National Foam” business that manufactured AFFF for sale to government (including the U.S. federal government) and non-government customers in the U.S. at a single facility located in West Chester, Pennsylvania (the "Pennsylvania Site"). Kidde Fire Fighting, Inc. was acquired by a UTC subsidiary in 2005 and merged into KFI in 2007. In 2013, KFI divested the AFFF businesses to an unrelated third party. The Company acquired KFI as part of the Separation in April 2020.

[0001783180-25-000030:notes:159]
The key components that contribute to AFFF's fire-extinguishing capabilities are known as fluorosurfactants. Neither the Company, nor KFI, nor any of the Company's subsidiaries involved in the AFFF litigation manufactured fluorosurfactants. Instead, the National Foam business purchased these substances from unrelated third parties for use in manufacturing AFFF. Plaintiffs in the MDL Proceedings allege that the fluorosurfactants used by various manufacturers in producing AFFF contained, or over time degraded into, compounds known as per- and polyfluoroalkyl substances (referred to collectively as "PFAS"), including perflourooctanesulfonic acid ("PFOS") and perflourooctanoic acid ("PFOA"). Plaintiffs further allege that, as a result of the use of AFFF, PFOS and PFOA were released into the environment and, in some instances, ultimately reached drinking water supplies.

[0001783180-25-000030:notes:160]
Plaintiffs in the MDL Proceedings have named multiple defendants, including suppliers of chemicals and raw materials used to manufacture fluorosurfactants, fluorosurfactant manufacturers and AFFF manufacturers. The defendants in the MDL Proceedings moved for summary judgment on the government contractor defense, which potentially applies to AFFF sold to or used by the U.S. government. After full briefing and oral argument, on September 16, 2022, the MDL court declined to enter summary judgment for the defendants. The defense, however, remains available at any trial in which it would apply.

[0001783180-25-000030:notes:161]
On May 14, 2023, KFI filed a voluntary petition with the United States Bankruptcy Court for the District of Delaware (the “Bankruptcy Court”) seeking relief under chapter 11 of the Bankruptcy Code, after the Company determined that it would not provide financial support to KFI going forward other than ensuring KFI has access to services necessary for the effective operation of its business. As a result, all litigation against KFI was automatically stayed. By agreement, all AFFF-related litigation against the Company, its other subsidiaries and RTX also was stayed. On November 21, 2023, the Bankruptcy Court ordered certain parties, including the Company, to participate in mediation sessions with respect to claims that might be asserted by and against it in the bankruptcy proceedings.

[0001783180-25-000030:notes:162]
Following the conclusion of these mediation sessions in October 2024, the Company entered into a Settlement and Plan Support Agreement which contemplates that the Company will subsequently enter into three distinct settlement agreements (collectively, the “Proposed Settlement Agreements”) with KFI, the Official Committee of Unsecured Creditors appointed in KFI’s bankruptcy case (the “Committee”) and the Plaintiffs’ Executive Committee (the “MDL PEC”) appointed in the MDL Proceedings.

[0001783180-25-000030:notes:163]
The first of the Proposed Settlement Agreements relates to claims that the Company is responsible for liabilities arising from KFI’s manufacture or sale of AFFF (“Estate Claims Settlement”). Upon Bankruptcy Court approval, the Estate Claims Settlement will permanently resolve all present and future claims that the Company is responsible for any liabilities of KFI, including all liabilities arising from KFI’s manufacture and sale of AFFF. The second and third of the Proposed Settlement Agreements release a very substantial amount of current and future direct claims against the Company (the “Direct Claims Settlements”). Direct claims allege that UTC, which indirectly owned KFI’s AFFF business for eight years, engaged in conduct independent of KFI that caused harm to AFFF claimants. The Company agreed to indemnify UTC for these direct claims when it was spun-off from UTC. Upon approval by the MDL Court, the Direct Claims Settlements resolve and enjoin all current and future AFFF-related direct claims against the Company by participating public water providers and airports. Non-settling parties may still assert direct AFFF-related claims, although we expect a vast majority of public water providers and airports will participate in the Direct Claims Settlements.

[0001783180-25-000030:notes:164]
As part of the Proposed Settlement Agreements, the Company will pay $615 million in cash over five years, 100% of the net sale proceeds from its sale of KFI’s assets to Pacific Avenue Capital Partners, which are estimated to be $115 million, and contribute the right to recover proceeds under certain of its insurance policies. The Company will be entitled to receive up to $2.4 billion of proceeds from those insurance policies and will contribute the first $125 million of such proceeds as additional consideration in the Direct Claims Settlements. The Company also will be entitled to any earnouts payable to KFI under the KFI sale agreement. The Company expects insurance payments it receives in the future, in the aggregate, to cover the amount paid under the Proposed Settlement Agreements. As a result of the Proposed Settlement Agreements, the Company recorded a liability in the amount of $565 million during the three months ended September 30, 2024. The amount recognized is in addition to liabilities of $50 million that the Company recorded upon the deconsolidation of KFI on May 14, 2023, as further discussed below. As of March 31, 2025, the Company has not recorded any amounts associated with expected insurance proceeds.

[0001783180-25-000030:notes:165]
The Company and KFI believe that they have meritorious defenses to the remaining AFFF claims. Given the numerous factual, scientific and legal issues to be resolved relating to these claims, the Company is unable to assess the probability of liability or to reasonably estimate a range of possible loss at this time. There can be no assurance that any such future exposure will not be material in any period.

[0001783180-25-000030:notes:166]
On November 14, 2024, KFI filed the chapter 11 plan of liquidation (as may be further amended, restated, supplemented, waived, or otherwise modified from time to time, the "Chapter 11 Plan"), which incorporates the Estate Claims Settlement, provides for the treatment of the various creditor classes, and establishes wind-down provisions, among other things, and the disclosure statement for the Chapter 11 Plan (as may be further amended, restated, supplemented, waived, or otherwise modified from time to time, the "Disclosure Statement"). A hearing to approve the Disclosure Statement, its ancillary documents and establish a Chapter 11 Plan confirmation timeline in the Bankruptcy Court is expected to be held in May 2025.

[0001783180-25-000030:notes:167]
Deconsolidation Due to Bankruptcy

[0001783180-25-000030:notes:168]
As of May 14, 2023, the Company no longer controlled KFI as its activities are subject to review and oversight by the Bankruptcy Court. Therefore, KFI was deconsolidated and its respective assets and liabilities were derecognized from the Company’s Unaudited Condensed Consolidated Financial Statements. Upon deconsolidation, the Company determined the fair value of its retained interest in KFI to be zero and we accounted for it prospectively using the cost method.

[0001783180-25-000030:notes:169]
In connection with the bankruptcy filing, KFI entered into several agreements with subsidiaries of the Company to ensure they have access to services necessary for the effective operation of their business. All post-deconsolidation activity between the Company and KFI are reported as third-party transactions recorded within the Company's Unaudited Condensed Consolidated Statement of Operations. Since the petition date, there were no material transactions between the Company and KFI other than a $15 million payment during 2024 by the Company to KFI under the terms of a tax sharing arrangement.

[0001783180-25-000030:notes:170]
Income Taxes

[0001783180-25-000030:notes:171]
Under the TMA relating to the Separation, the Company is responsible to UTC for its share of the Tax Cuts and Jobs Act transition tax associated with foreign undistributed earnings as of December 31, 2017. As a result, a liability of $101 million is included within the accompanying Unaudited Condensed Consolidated Balance Sheet within Other Long-Term Liabilities as of March 31, 2025. This obligation is expected to be settled in April 2026. The Company believes that the likelihood of incurring losses materially in excess of this amount is remote.

[0001783180-25-000030:notes:172]
Other

[0001783180-25-000030:notes:173]
The Company has other commitments and contingent liabilities related to legal proceedings, self-insurance programs and matters arising in the ordinary course of business. The Company accrues for contingencies generally based upon a range of possible outcomes. If no amount within the range is a better estimate than any other, the Company accrues the minimum amount.

[0001783180-25-000030:notes:174]
In the ordinary course of business, the Company is also routinely a defendant in, party to or otherwise subject to many pending and threatened legal actions, claims, disputes and proceedings. These matters are often based on alleged violations of contract, product liability, warranty, regulatory, environmental, health and safety, employment, intellectual property, tax and other laws. In some of these proceedings, claims for substantial monetary damages are asserted against the Company and could result in fines, penalties, compensatory or treble damages or non-monetary relief. The Company does not believe that these matters will have a material adverse effect upon its results of operations, cash flows or financial condition.
