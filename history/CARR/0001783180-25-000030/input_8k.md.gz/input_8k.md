# CARR 8-K — 0001783180-25-000028 filed 2025-05-01

## item codes, every 8-K on or before 2025-05-01

- 2025-05-01 0001783180-25-000028 — 2.02, 7.01, 9.01
- 2025-04-17 0000950142-25-001103 — 5.02
- 2025-04-11 0001783180-25-000021 — 5.02, 5.07, 9.01
- 2025-02-11 0001783180-25-000006 — 2.02, 9.01
- 2025-01-15 0000950142-25-000133 — 5.02, 9.01
- 2024-12-20 0001783180-24-000093 — 1.01, 1.02, 2.03, 9.01
- 2024-12-03 0000950142-24-002874 — 5.02
- 2024-12-02 0000950142-24-002865 — 7.01, 9.01
- 2024-11-08 0000950142-24-002699 — 1.01, 2.03, 9.01
- 2024-10-28 0000950142-24-002640 — 8.01
- 2024-10-28 0000950142-24-002638 — 8.01
- 2024-10-24 0001783180-24-000084 — 2.02, 7.01, 9.01
- 2024-10-18 0000950142-24-002601 — 1.01
- 2024-08-15 0001140361-24-037426 — 7.01, 9.01
- 2024-07-25 0001783180-24-000075 — 2.02, 9.01
- 2024-06-21 0001783180-24-000069 — 5.02
- 2024-06-21 0000950142-24-001676 — 5.02
- 2024-06-07 0001783180-24-000062 — 5.02, 5.03, 9.01
- 2024-06-03 0000950142-24-001538 — 1.02, 7.01, 9.01
- 2024-05-17 0001783180-24-000049 — 1.01, 1.02, 2.03, 9.01
- 2024-04-25 0001783180-24-000042 — 2.02, 9.01
- 2024-04-19 0001783180-24-000035 — 5.07, 9.01
- 2024-04-19 0000950142-24-001162 — 5.07 — amendment of 0001783180-24-000035
- 2024-02-06 0001783180-24-000007 — 2.02, 9.01
- 2024-02-01 0000950142-24-000264 — 5.02
- 2024-01-02 0001140361-24-000034 — 1.01, 2.01, 2.03, 5.02, 7.01, 9.01
- 2023-12-13 0001140361-23-057415 — 1.01, 9.01
- 2023-12-08 0001140361-23-056751 — 7.01, 9.01
- 2023-11-30 0000950142-23-002884 — 1.01, 2.03, 8.01, 9.01
- 2023-11-16 0000950142-23-002788 — 8.01, 9.01
- 2023-11-13 0001140361-23-052667 — 7.01, 8.01, 9.01
- 2023-10-26 0001783180-23-000063 — 2.02, 9.01
- 2023-07-27 0001783180-23-000053 — 2.02, 9.01
- 2023-06-12 0000950142-23-001664 — 5.02
- 2023-05-25 0000950142-23-001541 — 1.01, 1.02, 2.03, 9.01
- 2023-04-26 0000950142-23-001205 — 1.01, 9.01
- 2023-04-25 0001783180-23-000036 — 2.02, 7.01, 9.01
- 2023-04-25 0000950142-23-001199 — 7.01, 8.01, 9.01
- 2023-04-21 0001783180-23-000032 — 5.07, 9.01
- 2023-02-07 0001783180-23-000010 — 2.02, 9.01
- 2022-10-27 0001783180-22-000054 — 2.02, 7.01, 9.01
- 2022-09-29 0000950142-22-002805 — 5.02, 9.01
- 2022-07-28 0001783180-22-000045 — 2.02, 9.01
- 2022-04-28 0001783180-22-000032 — 2.02, 9.01
- 2022-04-15 0001783180-22-000024 — 5.07, 9.01
- 2022-02-08 0001783180-22-000008 — 2.02, 9.01
- 2022-02-07 0000950142-22-000510 — 8.01, 9.01
- 2022-01-03 0000950142-22-000023 — 8.01, 9.01
- 2021-12-17 0001783180-21-000071 — 5.02, 7.01, 9.01
- 2021-11-23 0001783180-21-000068 — 5.03, 9.01
- 2021-10-28 0001783180-21-000062 — 2.02, 9.01
- 2021-08-27 0001783180-21-000056 — 8.01
- 2021-07-30 0001783180-21-000053 — 1.01
- 2021-07-29 0001783180-21-000049 — 2.02, 8.01, 9.01
- 2021-07-27 0000950142-21-002448 — 8.01, 9.01
- 2021-07-15 0000950142-21-002362 — 5.02, 9.01
- 2021-06-09 0000950142-21-001885 — 5.02, 9.01
- 2021-04-29 0001783180-21-000029 — 2.02, 9.01
- 2021-04-22 0001140361-21-013889 — 5.02, 9.01
- 2021-04-20 0001783180-21-000021 — 5.07, 9.01
- 2021-04-19 0000950142-21-001308 — 8.01, 9.01
- 2021-02-09 0001783180-21-000009 — 2.02, 9.01
- 2021-02-05 0001140361-21-003513 — 8.01, 9.01
- 2020-12-23 0001140361-20-029419 — 7.01, 9.01
- 2020-12-22 0001140361-20-029097 — 8.01
- 2020-12-14 0001140361-20-028246 — 5.03, 9.01
- 2020-12-07 0001140361-20-027515 — 1.01, 7.01, 9.01
- 2020-10-29 0001783180-20-000063 — 2.02, 9.01
- 2020-10-19 0001140361-20-023241 — 5.02, 7.01, 9.01
- 2020-09-23 0001140361-20-021220 — 8.01, 9.01
- 2020-09-22 0001140361-20-021124 — 8.01, 9.01
- 2020-07-30 0001783180-20-000045 — 2.02, 9.01
- 2020-06-19 0001140361-20-014325 — 1.01, 2.03, 9.01
- 2020-06-16 0001140361-20-013880 — 8.01, 9.01
- 2020-06-03 0001140361-20-012939 — 1.01, 9.01
- 2020-05-08 0001783180-20-000013 — 2.02, 9.01
- 2020-04-03 0001140361-20-007888 — 1.01, 5.02, 5.03, 5.05, 7.01, 9.01
- 2020-03-16 0001140361-20-005868 — 8.01, 9.01

## late-filing notifications on or before 2025-05-01

- none on or before 2025-05-01

## item 2.02 — earnings release, exhibit 99.1

[0001783180-25-000028:8k_2_02:1]
EX-99.1
2
a991-q12025earningsexhibit.htm
EX-99.1

[0001783180-25-000028:8k_2_02:2]
Document

[0001783180-25-000028:8k_2_02:3]
Exhibit 99.1

[0001783180-25-000028:8k_2_02:4]
Carrier Reports Strong First Quarter 2025 Results

[0001783180-25-000028:8k_2_02:5]
•Net sales down 4% given prior year divestiture; organic sales up 2%

[0001783180-25-000028:8k_2_02:6]
•GAAP EPS of $0.47 up 147% and adjusted EPS of $0.65 up 27%

[0001783180-25-000028:8k_2_02:7]
•GAAP operating margin up 500 bps; adjusted operating margin up 210 bps

[0001783180-25-000028:8k_2_02:8]
•Net cash flows from operating activities were $483 million and free cash flow was $420 million

[0001783180-25-000028:8k_2_02:9]
•Returned $1.5 billion to shareholders through share repurchases and dividends and paid down $1.2 billion in debt

[0001783180-25-000028:8k_2_02:10]
•Fully mitigating impact of tariffs in effect today

[0001783180-25-000028:8k_2_02:11]
•Increasing full-year 2025 adjusted earnings per share guidance

[0001783180-25-000028:8k_2_02:12]
•Transitioned to new segment reporting

[0001783180-25-000028:8k_2_02:13]
PALM BEACH GARDENS, Fla., May 1, 2025 – Carrier Global Corporation (NYSE:CARR), global leader in intelligent climate and energy solutions, today reported strong financial results for the first quarter of 2025 and increased its full year guidance.

[0001783180-25-000028:8k_2_02:14]
“We delivered another quarter of strong financial performance," said Carrier Chairman & CEO David Gitlin. “Adjusted EPS grew 27% with adjusted operating margins expanding 210 basis points on 2% organic sales growth. Sales for the Commercial1 and Residential businesses within Climate Solutions Americas were each up about 20%.  Total company orders were up high-single-digits, backlogs increased over 15% sequentially and about 10% year-over-year, positioning us for accelerated growth further fueled by differentiated products, aftermarket offerings and system solutions. We are increasing our full-year commitments as we proactively manage this dynamic environment."

[0001783180-25-000028:8k_2_02:15]
1.Excludes NORESCO

[0001783180-25-000028:8k_2_02:16]
1

[0001783180-25-000028:8k_2_02:17]
First Quarter 2025 Results

[0001783180-25-000028:8k_2_02:18]
Total Company

[0001783180-25-000028:8k_2_02:19]
|  | (Unaudited) |
|  | Three Months Ended March 31 |  |
| (In millions) | 2025 | 2024 | Change |  |  |  |
| Net sales | $ | 5,218 |  | $ | 5,420 |  | (4) | % |  |  |  |
| Organic sales | 2 | % |  |  |  |  |  |
| Operating profit | $ | 629 |  | $ | 385 |  | 63 | % |  |  |  |
| Operating margin | 12.1 | % | 7.1 | % | 500 bps |  |  |  |
| Adjusted operating profit | $ | 843 |  | $ | 764 |  | 10 | % |  |  |  |
| Adjusted operating margin | 16.2 | % | 14.1 | % | 210 bps |  |  |  |
| Diluted earnings per share: |  |  |  |  |  |  |
| Continuing operations | $ | 0.47 |  | $ | 0.19 |  | 147 | % |  |  |  |
| Continuing operations - Adjusted | $ | 0.65 |  | $ | 0.51 |  | 27 | % |  |  |  |

[0001783180-25-000028:8k_2_02:20]
Carrier’s first quarter sales of $5.2 billion were down 4% compared to the prior year. Organic sales growth of 2% was offset by a 5% headwind from net acquisitions and divestitures, driven by the sale of Commercial Refrigeration in Q4 2024. Foreign currency translation was a 1% headwind to sales growth.

[0001783180-25-000028:8k_2_02:21]
GAAP operating profit in the quarter of $629 million was up 63% from last year driven by operational performance, the absence of VCS backlog and inventory step-up amortization and decrease in acquisition and divestiture-related costs. Adjusted operating profit of $843 million was up 10%, mostly driven by strong productivity and price. Net income from continuing operations was $412 million and adjusted net earnings from continuing operations was $569 million. GAAP EPS from continuing operations was $0.47 and adjusted EPS from continuing operations was $0.65 from higher operating profit, lower net interest expense and benefits of a lower share count.

[0001783180-25-000028:8k_2_02:22]
2

[0001783180-25-000028:8k_2_02:23]
Climate Solutions Americas (CSA)

[0001783180-25-000028:8k_2_02:24]
|  | (Unaudited) |
|  | Three Months Ended March 31 |  |
| (In millions) | 2025 | 2024 | Change |  |  |  |
| Net sales | $ | 2,572 |  | $ | 2,360 |  | 9 | % |  |  |  |
| Organic sales | 9 | % |  |  |  |  |  |
| Segment operating profit | $ | 570 |  | $ | 425 |  | 34 | % |  |  |  |
| Segment operating margin | 22.2 | % | 18.0 | % | 420 bps |  |  |  |

[0001783180-25-000028:8k_2_02:25]
CSA segment sales increased 9%. Organic sales were up 9%, driven by continued strength in Commercial1 and Residential, each up about 20% more than offsetting a decline in Light Commercial.

[0001783180-25-000028:8k_2_02:26]
Segment operating margin increased 420 basis points driven by strong organic sales growth and productivity.

[0001783180-25-000028:8k_2_02:27]
Climate Solutions Europe (CSE)

[0001783180-25-000028:8k_2_02:28]
|  | (Unaudited) |
|  | Three Months Ended March 31 |  |
| (In millions) | 2025 | 2024 | Change |  |  |  |
| Net sales | $ | 1,169 |  | $ | 1,292 |  | (10) | % |  |  |  |
| Organic sales | (7) | % |  |  |  |  |  |
| Segment operating profit | $ | 105 |  | $ | 167 |  | (37) | % |  |  |  |
| Segment operating margin | 9.0 | % | 12.9 | % | (390) bps |  |  |  |

[0001783180-25-000028:8k_2_02:29]
CSE segment sales declined 10%. Organic sales were down 7%, with Commercial  up mid-single digits offsetting a low-double-digit decline in Residential and Light Commercial.

[0001783180-25-000028:8k_2_02:30]
Segment operating margin decreased 390 basis points, driven by lower volume, mix and investments partially offset by cost synergies.

[0001783180-25-000028:8k_2_02:31]
1.Excludes NORESCO

[0001783180-25-000028:8k_2_02:32]
3

[0001783180-25-000028:8k_2_02:33]
Climate Solutions Asia Pacific, Middle East & Africa (CSAME)

[0001783180-25-000028:8k_2_02:34]
|  | (Unaudited) |
|  | Three Months Ended March 31 |  |
| (In millions) | 2025 | 2024 | Change |  |  |  |
| Net sales | $ | 826 |  | $ | 884 |  | (7) | % |  |  |  |
| Organic sales | (6) | % |  |  |  |  |  |
| Segment operating profit | $ | 121 |  | $ | 108 |  | 12 | % |  |  |  |
| Segment operating margin | 14.6 | % | 12.2 | % | 240 bps |  |  |  |

[0001783180-25-000028:8k_2_02:35]
CSAME segment sales declined 7%. Organic sales were down 6%, mainly driven by declines in Residential Light Commercial in China, partially offset by strength in other countries.

[0001783180-25-000028:8k_2_02:36]
Segment operating margin increased 240 basis points driven by productivity and the absence of a prior year unfavorable currency impact, partially offset by lower volume.

[0001783180-25-000028:8k_2_02:37]
Climate Solutions Transportation (CST)

[0001783180-25-000028:8k_2_02:38]
|  | (Unaudited) |
|  | Three Months Ended March 31 |  |
| (In millions) | 2025 | 2024 | Change |  |  |  |
| Net sales | $ | 651 |  | $ | 884 |  | (26) | % |  |  |  |
| Organic sales | 2 | % |  |  |  |  |  |
| Segment operating profit | $ | 97 |  | $ | 113 |  | (14) | % |  |  |  |
| Segment operating margin | 14.9 | % | 12.8 | % | 210 bps |  |  |  |

[0001783180-25-000028:8k_2_02:39]
CST sales declined 26% driven by the impact from the divestiture of Commercial Refrigeration. Organic sales growth increased 2% driven by 20% growth in Container, partially offset by declines in Europe and North America Truck and Trailer.

[0001783180-25-000028:8k_2_02:40]
Segment operating margin increased 210 basis points mainly due to the Commercial Refrigeration exit.

[0001783180-25-000028:8k_2_02:41]
4

[0001783180-25-000028:8k_2_02:42]
Cash Flow

[0001783180-25-000028:8k_2_02:43]
|  |  | (Unaudited) |
|  |  | Three Months Ended March 31, |
| (In millions) |  | 2025 |  | 2024 |
| Net cash flows provided by operating activities |  | $ | 483 |  |  | $ | 40 |  |
| Less: Capital expenditures - continuing operations |  | (63) |  |  | (102) |  |
| Less: Capital expenditures - discontinued operations |  | — |  |  | (2) |  |
| Free cash flow |  | $ | 420 |  |  | $ | (64) |  |

[0001783180-25-000028:8k_2_02:44]
Net cash flows generated from operating activities were $483 million and capital expenditures were $63 million, resulting in free cash flow of $420 million. The increase in free cash flow was driven by higher net income, working capital improvements and lower capital expenditures.

[0001783180-25-000028:8k_2_02:45]
Carrier repurchased $1.3 billion in shares, paid $200 million in dividends and paid down $1.2 billion in debt.

[0001783180-25-000028:8k_2_02:46]
Full-Year 2025 Guidance**

[0001783180-25-000028:8k_2_02:47]
|  | Current Guidance** | Prior Guidance |  |
| Sales | ~$23 billion~$750 million revenue headwind from CCR exitOrganic* up MSDFX 1%Acquisitions 0%Divestitures (3%) | $22.5 – $23.0 billion~$750 million revenue headwind from CCR exitOrganic* up MSDFX (1%)Acquisitions 0%Divestitures (3%) |  |
| Adjusted Operating Margin* | 16.5% – 17.0%+ ~100 bps Y/Y | 16.5% – 17.0%+ ~100 bps Y/Y |  |
| Adjusted EPS* | $3.00 – $3.10~17-21% Y/Y | $2.95 – $3.05+ ~15-20% Y/Y |  |
| Free Cash Flow* | $2.4 – $2.6 billionIncludes the expected results of continuing and discontinued operations | $2.4 – $2.6 billionIncludes the expected results of continuing and discontinued operations |  |

[0001783180-25-000028:8k_2_02:48]
*Note: When the company provides expectations for organic sales, adjusted operating profit, adjusted operating margin, adjusted EPS and free cash flow on a forward-looking basis, a reconciliation of the differences between the non-GAAP expectations and the corresponding GAAP measures generally is not available without unreasonable effort. See “Use and Definitions of Non-GAAP Financial Measures” below for additional information.

[0001783180-25-000028:8k_2_02:49]
**As of May 1, 2025

[0001783180-25-000028:8k_2_02:50]
5

[0001783180-25-000028:8k_2_02:51]
Conference Call

[0001783180-25-000028:8k_2_02:52]
Carrier will host a webcast of its earnings conference call today, Thursday, May 1, 2025, at 7:30 a.m. ET. To access the webcast, visit the Events & Presentations section of the Carrier Investor Relations site at ir.carrier.com/news-and-events/events-and-presentations or to listen to the earnings call by phone, participants must pre-register at Carrier Earnings Call Registration. All registrants will receive dial-in information and a PIN allowing access to the live call.

[0001783180-25-000028:8k_2_02:53]
Cautionary Statement

[0001783180-25-000028:8k_2_02:54]
6

[0001783180-25-000028:8k_2_02:55]
About Carrier

[0001783180-25-000028:8k_2_02:56]
Carrier Global Corporation, global leader in intelligent climate and energy solutions, is committed to creating solutions that matter for people and our planet for generations to come. From the beginning, we've led in inventing new technologies and entirely new industries. Today, we continue to lead because we have a world-class, diverse workforce that puts the customer at the center of everything we do. For more information, visit corporate.carrier.com or follow Carrier on social media at @Carrier.

[0001783180-25-000028:8k_2_02:57]
CARR-IR

[0001783180-25-000028:8k_2_02:58]
Contact:

[0001783180-25-000028:8k_2_02:59]
Investor Relations

[0001783180-25-000028:8k_2_02:60]
Michael Rednor

[0001783180-25-000028:8k_2_02:61]
561-365-2020

[0001783180-25-000028:8k_2_02:62]
InvestorRelations@Carrier.com

[0001783180-25-000028:8k_2_02:63]
Media Inquiries

[0001783180-25-000028:8k_2_02:64]
Jason Shockley

[0001783180-25-000028:8k_2_02:65]
561-542-0207

[0001783180-25-000028:8k_2_02:66]
Jason.Shockley@Carrier.com

[0001783180-25-000028:8k_2_02:67]
7

[0001783180-25-000028:8k_2_02:68]
SELECTED FINANCIAL DATA, NON-GAAP MEASURES AND DEFINITIONS

[0001783180-25-000028:8k_2_02:69]
Following are tables that present selected financial data of Carrier Global Corporation (“Carrier”). Also included are reconciliations of non-GAAP measures to their most comparable GAAP measures.

[0001783180-25-000028:8k_2_02:70]
As a result of Carrier's portfolio transformation, Carrier revised its reportable segments during the first quarter of 2025 to better reflect its business strategy, align its management reporting and increase transparency for investors. In connection with the revised structure, the Chief Operating Decision Maker changed the measure used to evaluate segment profitability from Operating profit to Segment operating profit. It represents operating profit (a GAAP measure) adjusted to exclude restructuring costs, amortization of acquired intangible assets and other significant items of a nonoperational nature. All prior period comparative information has been recast to reflect the revised segment structure.

[0001783180-25-000028:8k_2_02:71]
Use and Definitions of Non-GAAP Financial Measures

[0001783180-25-000028:8k_2_02:72]
Carrier reports its financial results in accordance with accounting principles generally accepted in the United States ("GAAP"). We supplement the reporting of our financial information determined under GAAP with certain non-GAAP financial information. The non-GAAP information presented provides investors with additional useful information, but should not be considered in isolation or as substitutes for the related GAAP measures. Moreover, other companies may define non-GAAP measures differently, which limits the usefulness of these measures for comparisons with such other companies. We encourage investors to review our financial statements and publicly filed reports in their entirety and not to rely on any single financial measure. A reconciliation of the non-GAAP measures to the corresponding amounts prepared in accordance with GAAP appears in the tables in this Appendix. The tables provide additional information as to the items and amounts that have been excluded from the adjusted measures.

[0001783180-25-000028:8k_2_02:73]
Organic sales, adjusted operating profit, adjusted operating margin, adjusted net income, adjusted earnings per share (“EPS”), adjusted effective tax rate and net debt are non-GAAP financial measures and are associated with Carrier's continuing operations unless specifically noted.

[0001783180-25-000028:8k_2_02:74]
Organic sales represents consolidated net sales (a GAAP measure), excluding the impact of foreign currency translation, acquisitions and divestitures completed in the preceding twelve months and other significant items of a nonoperational nature (hereinafter referred to as “other significant items”). Adjusted operating profit represents consolidated operating profit (a GAAP measure), excluding restructuring costs, amortization of acquired intangibles and other significant items. Adjusted operating margin represents adjusted operating profit as a percentage of consolidated net sales (a GAAP measure). Adjusted net income represents net income attributable to common shareowners (a GAAP measure), excluding restructuring costs, amortization of acquired intangibles and other significant items. Adjusted EPS represents diluted earnings per share (a GAAP measure), excluding restructuring costs, amortization of acquired intangibles and other significant items. The adjusted effective tax rate represents the effective tax rate (a GAAP measure), excluding restructuring costs, amortization of acquired intangibles and other significant items. Net debt represents long-term debt (a GAAP measure) less cash and cash equivalents (a GAAP measure).

[0001783180-25-000028:8k_2_02:75]
Free cash flow is a non-GAAP financial measure that represents net cash flows provided by continuing operating activities (a GAAP measure) less capital expenditures. Management believes free cash flow is a useful measure of liquidity and an additional basis for assessing Carrier’s ability to fund its activities, including the financing of acquisitions, debt service, repurchases of Carrier's common stock and distribution of earnings to shareowners. Orders are contractual commitments with customers to provide specified goods or services for an agreed upon price and may not be subject to penalty if cancelled.

[0001783180-25-000028:8k_2_02:76]
When Carrier provides our expectations for organic sales, adjusted operating profit, adjusted operating margin, adjusted effective tax rate, adjusted EPS and free cash flow on a forward-looking basis, a reconciliation of the differences between the non-GAAP expectations and the corresponding GAAP measures generally is not available without unreasonable effort due to potentially high variability, complexity and low visibility as to the items that would be excluded from the GAAP measure in the relevant future period, such as unusual gains and losses, the ultimate outcome of pending litigation, fluctuations in foreign currency exchange rates, the impact and timing of potential acquisitions and divestitures, future restructuring costs, and other structural changes or their probable significance. The variability of the excluded items may have a significant, and potentially unpredictable, impact on our future GAAP results.

[0001783180-25-000028:8k_2_02:77]
8

[0001783180-25-000028:8k_2_02:78]
Carrier Global Corporation

[0001783180-25-000028:8k_2_02:79]
Condensed Consolidated Statement of Operations

[0001783180-25-000028:8k_2_02:80]
|  |  | (Unaudited) |
|  |  | Three Months Ended March 31, |  |  |
| (In millions, except per share amounts) |  | 2025 |  | 2024 |  |  |  |  |
| Net sales |  |  |  |  |  |  |  |  |
| Product sales |  | $ | 4,652 |  |  | $ | 4,842 |  |  |  |  |  |
| Service sales |  | 566 |  |  | 578 |  |  |  |  |  |
| Total Net sales |  | 5,218 |  |  | 5,420 |  |  |  |  |  |
| Costs and expenses |  |  |  |  |  |  |  |  |
| Cost of products sold |  | (3,358) |  |  | (3,582) |  |  |  |  |  |
| Cost of services sold |  | (415) |  |  | (453) |  |  |  |  |  |
| Research and development |  | (153) |  |  | (192) |  |  |  |  |  |
| Selling, general and administrative |  | (729) |  |  | (807) |  |  |  |  |  |
| Total Costs and expenses |  | (4,655) |  |  | (5,034) |  |  |  |  |  |
| Equity method investment net earnings |  | 44 |  |  | 31 |  |  |  |  |  |
| Other income (expense), net |  | 22 |  |  | (32) |  |  |  |  |  |
| Operating profit |  | 629 |  |  | 385 |  |  |  |  |  |
| Non-service pension (expense) benefit |  | 1 |  |  | — |  |  |  |  |  |
| Interest (expense) income, net |  | (82) |  |  | (141) |  |  |  |  |  |
| Earnings before income taxes |  | 548 |  |  | 244 |  |  |  |  |  |
| Income tax (expense) benefit |  | (111) |  |  | (47) |  |  |  |  |  |
| Earnings from continuing operations |  | 437 |  |  | 197 |  |  |  |  |  |
| Discontinued operations, net of tax |  | — |  |  | 92 |  |  |  |  |  |
| Net earnings (loss) |  | 437 |  |  | 289 |  |  |  |  |  |
| Less: Non-controlling interest in subsidiaries' |  | 25 |  |  | 20 |  |  |  |  |  |
| Net earnings (loss) attributable to common shareowners |  | $ | 412 |  |  | $ | 269 |  |  |  |  |  |
| Amounts attributable to common shareowners: |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 412 |  |  | $ | 177 |  |  |  |  |  |
| Discontinued operations |  | — |  |  | 92 |  |  |  |  |  |
| Net earnings (loss) attributable to common shareowners |  | $ | 412 |  |  | $ | 269 |  |  |  |  |  |
| Earnings per share |  |  |  |  |  |  |  |  |
| Basic: |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 0.47 |  |  | $ | 0.20 |  |  |  |  |  |
| Discontinued operations |  | — |  |  | 0.10 |  |  |  |  |  |
| Net earnings (loss) |  | $ | 0.47 |  |  | $ | 0.30 |  |  |  |  |  |
| Diluted: |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 0.47 |  |  | $ | 0.19 |  |  |  |  |  |
| Discontinued operations |  | — |  |  | 0.10 |  |  |  |  |  |
| Net earnings (loss) |  | $ | 0.47 |  |  | $ | 0.29 |  |  |  |  |  |
| Weighted-average number of shares outstanding |  |  |  |  |  |  |  |  |
| Basic |  | 866.9 |  |  | 899.2 |  |  |  |  |  |
| Diluted |  | 878.3 |  |  | 913.0 |  |  |  |  |  |

[0001783180-25-000028:8k_2_02:81]
9

[0001783180-25-000028:8k_2_02:82]
Carrier Global Corporation

[0001783180-25-000028:8k_2_02:83]
Condensed Consolidated Balance Sheet

[0001783180-25-000028:8k_2_02:84]
|  |  | (Unaudited) |
| (In millions) |  | March 31, 2025 |  | December 31, 2024 |
| Assets |  |  |  |  |
| Cash and cash equivalents |  | $ | 1,698 |  |  | $ | 3,969 |  |
| Accounts receivable, net |  | 2,979 |  |  | 2,651 |  |
| Inventories, net |  | 2,648 |  |  | 2,299 |  |
| Other current assets |  | 1,119 |  |  | 972 |  |
| Total current assets |  | 8,444 |  |  | 9,891 |  |
| Future income tax benefits |  | 1,149 |  |  | 1,131 |  |
| Fixed assets, net |  | 3,040 |  |  | 2,999 |  |
| Operating lease right-of-use assets |  | 563 |  |  | 554 |  |
| Intangible assets, net |  | 6,480 |  |  | 6,432 |  |
| Goodwill |  | 14,959 |  |  | 14,601 |  |
| Pension and post-retirement assets |  | 48 |  |  | 43 |  |
| Equity method investments |  | 1,253 |  |  | 1,194 |  |
| Other assets |  | 511 |  |  | 558 |  |
| Total Assets |  | $ | 36,447 |  |  | $ | 37,403 |  |
| Liabilities and Equity |  |  |  |  |
| Accounts payable |  | $ | 3,015 |  |  | $ | 2,458 |  |
| Accrued liabilities |  | 3,892 |  |  | 4,182 |  |
| Current portion of long-term debt |  | 104 |  |  | 1,252 |  |
| Total current liabilities |  | 7,011 |  |  | 7,892 |  |
| Long-term debt |  | 11,080 |  |  | 11,026 |  |
| Future pension and post-retirement obligations |  | 218 |  |  | 214 |  |
| Future income tax obligations |  | 2,028 |  |  | 2,015 |  |
| Operating lease liabilities |  | 437 |  |  | 432 |  |
| Other long-term liabilities |  | 1,475 |  |  | 1,429 |  |
| Total Liabilities |  | 22,249 |  |  | 23,008 |  |
| Equity |  |  |  |  |
| Common stock |  | 9 |  |  | 9 |  |
| Treasury stock |  | (5,188) |  |  | (3,915) |  |
| Additional paid-in capital |  | 8,616 |  |  | 8,610 |  |
| Retained earnings |  | 11,895 |  |  | 11,483 |  |
| Accumulated other comprehensive loss |  | (1,473) |  |  | (2,106) |  |
| Non-controlling interest |  | 339 |  |  | 314 |  |
| Total Equity |  | 14,198 |  |  | 14,395 |  |
| Total Liabilities and Equity |  | $ | 36,447 |  |  | $ | 37,403 |  |

[0001783180-25-000028:8k_2_02:85]
10

[0001783180-25-000028:8k_2_02:86]
Carrier Global Corporation

[0001783180-25-000028:8k_2_02:87]
Condensed Consolidated Statement of Cash Flows

[0001783180-25-000028:8k_2_02:88]
(Unaudited)

[0001783180-25-000028:8k_2_02:89]
|  |  | Three Months Ended March 31, |
| (In millions) |  | 2025 |  | 2024 |
| Operating Activities |  |  |  |  |
| Net earnings (loss) |  | $ | 437 |  |  | $ | 289 |  |
| Discontinued operations, net of tax |  | — |  |  | (92) |  |
| Adjustments for non-cash items, net: |  |  |  |  |
| Depreciation and amortization |  | 303 |  |  | 308 |  |
| Deferred income tax provision |  | (69) |  |  | (104) |  |
| Stock-based compensation costs |  | 23 |  |  | 19 |  |
| Equity method investment net earnings |  | (44) |  |  | (31) |  |
| (Gain) loss on sale of investments / deconsolidation |  | (5) |  |  | — |  |
| Changes in operating assets and liabilities |  |  |  |  |
| Accounts receivable, net |  | (362) |  |  | (181) |  |
| Inventories, net |  | (301) |  |  | (83) |  |
| Accounts payable and accrued liabilities |  | 481 |  |  | (146) |  |
| Distributions from equity method investments |  | 77 |  |  | 7 |  |
| Other operating activities, net |  | (52) |  |  | 59 |  |
| Net cash flows provided by (used in) continuing operating activities |  | 488 |  |  | 45 |  |
| Net cash flows provided by (used in) discontinued operating activities |  | (5) |  |  | (5) |  |
| Net cash flows provided by (used in) operating activities |  | 483 |  |  | 40 |  |
| Investing Activities |  |  |  |  |
| Capital expenditures |  | (63) |  |  | (102) |  |
| Investment in businesses, net of cash acquired |  | (12) |  |  | (10,772) |  |
| Dispositions of businesses |  | 8 |  |  | — |  |
| Settlement of derivative contracts, net |  | 36 |  |  | (209) |  |
| Other investing activities, net |  | 1 |  |  | 3 |  |
| Net cash flows provided by (used in) continuing investing activities |  | (30) |  |  | (11,080) |  |
| Net cash flows provided by (used in) discontinued investing activities |  | 7 |  |  | (1) |  |
| Net cash flows provided by (used in) investing activities |  | (23) |  |  | (11,081) |  |
| Financing Activities |  |  |  |  |
| Increase (decrease) in short-term borrowings, net |  | (49) |  |  | 20 |  |
| Issuance of long-term debt |  | 9 |  |  | 2,548 |  |
| Repayment of long-term debt |  | (1,205) |  |  | (5) |  |
| Repurchases of common stock |  | (1,288) |  |  | — |  |
| Dividends paid on common stock |  | (198) |  |  | (159) |  |
| Dividends paid to non-controlling interest |  | — |  |  | (2) |  |
| Other financing activities, net |  | (16) |  |  | (19) |  |
| Net cash flows provided by (used in) continuing financing activities |  | (2,747) |  |  | 2,383 |  |
| Net cash flows provided by (used in) discontinued financing activities |  | — |  |  | (4) |  |
| Net cash flows provided by (used in) financing activities |  | (2,747) |  |  | 2,379 |  |
| Effect of foreign exchange rate changes on cash and cash equivalents |  | 17 |  |  | (68) |  |
| Net increase (decrease) in cash and cash equivalents and restricted cash, including cash classified in current assets held for sale |  | (2,270) |  |  | (8,730) |  |
| Less: Change in cash balances classified as assets held for sale |  | — |  |  | (59) |  |
| Net increase (decrease) in cash and cash equivalents and restricted cash |  | (2,270) |  |  | (8,671) |  |
| Cash, cash equivalents and restricted cash, beginning of period |  | 3,972 |  |  | 9,853 |  |
| Cash, cash equivalents and restricted cash, end of period |  | 1,702 |  |  | 1,182 |  |
| Less: restricted cash |  | 4 |  |  | 2 |  |
| Cash and cash equivalents, end of period |  | $ | 1,698 |  |  | $ | 1,180 |  |

[0001783180-25-000028:8k_2_02:90]
Carrier Global Corporation

[0001783180-25-000028:8k_2_02:91]
Segment Summary

[0001783180-25-000028:8k_2_02:92]
|  | (Unaudited) |
|  | Three Months Ended March 31, |  |  |
| (In millions) | 2025 |  | 2024 |  |  |  |  |
| Segment net sales |  |  |  |  |  |  |  |  |
| Climate Solutions Americas |  | $ | 2,572 |  | $ | 2,360 |  |  |  |  |
| Climate Solutions Europe |  | 1,169 |  | 1,292 |  |  |  |  |
| Climate Solutions Asia Pacific, Middle East & Africa |  | 826 |  | 884 |  |  |  |  |
| Climate Solutions Transportation |  | 651 |  | 884 |  |  |  |  |
| Segment net sales |  | $ | 5,218 |  | $ | 5,420 |  |  |  |  |
| Segment operating profit |  |  |  |  |  |  |  |  |
| Climate Solutions Americas |  | $ | 570 |  | $ | 425 |  |  |  |  |
| Climate Solutions Europe |  | 105 |  | 167 |  |  |  |  |
| Climate Solutions Asia Pacific, Middle East & Africa |  | 121 |  | 108 |  |  |  |  |
| Climate Solutions Transportation |  | 97 |  | 113 |  |  |  |  |
| Segment operating profit |  | $ | 893 |  | $ | 813 |  |  |  |  |
| Segment operating margin |  |  |  |  |  |  |  |  |
| Climate Solutions Americas |  | 22.2 | % |  | 18.0 | % |  |  |  |  |
| Climate Solutions Europe |  | 9.0 | % |  | 12.9 | % |  |  |  |  |
| Climate Solutions Asia Pacific, Middle East & Africa |  | 14.6 | % |  | 12.2 | % |  |  |  |  |
| Climate Solutions Transportation |  | 14.9 | % |  | 12.8 | % |  |  |  |  |

[0001783180-25-000028:8k_2_02:93]
Components of Changes in Net Sales

[0001783180-25-000028:8k_2_02:94]
| Three Months Ended March 31, 2025 Compared with Three Months Ended March 31, 2024 |
|  | (Unaudited) |
|  | Factors Contributing to Total % change in Net Sales |
|  | Organic |  | FX Translation |  | Acquisitions / Divestitures, net |  | Other |  | Total |
| Climate Solutions Americas | 9 | % |  | — | % |  | — | % |  | — | % |  | 9 | % |
| Climate Solutions Europe | (7) | % |  | (3) | % |  | — | % |  | — | % |  | (10) | % |
| Climate Solutions Asia Pacific, Middle East & Africa | (6) | % |  | (1) | % |  | — | % |  | — | % |  | (7) | % |
| Climate Solutions Transportation | 2 | % |  | (1) | % |  | (27) | % |  | — | % |  | (26) | % |
| Consolidated | 2 | % |  | (1) | % |  | (5) | % |  | — | % |  | (4) | % |

[0001783180-25-000028:8k_2_02:95]
12

[0001783180-25-000028:8k_2_02:96]
Carrier Global Corporation

[0001783180-25-000028:8k_2_02:97]
Reconciliations

[0001783180-25-000028:8k_2_02:98]
|  |  | (Unaudited) |  |  |
|  |  | Three Months Ended March 31, |  |  |
| (In millions) |  | 2025 |  | 2024 |  |  |  |  |
| Reconciliation to Earnings before income taxes |  |  |  |  |  |  |  |  |
| Segment operating profit |  | $ | 893 |  |  | $ | 813 |  |  |  |  |  |
| Corporate and other |  | (50) |  |  | (49) |  |  |  |  |  |
| Restructuring costs |  | (8) |  |  | (8) |  |  |  |  |  |
| Amortization of acquired intangibles |  | (201) |  |  | (172) |  |  |  |  |  |
| Acquisition on step-up amortization |  | — |  |  | (111) |  |  |  |  |  |
| Acquisition/divestiture-related costs |  | (5) |  |  | (48) |  |  |  |  |  |
| Viessmann-related hedges |  | — |  |  | (86) |  |  |  |  |  |
| Gain on liability adjustment |  | — |  |  | 46 |  |  |  |  |  |
| Non-service pension (expense) benefit |  | 1 |  |  | — |  |  |  |  |  |
| Interest (expense) income, net |  | (82) |  |  | (141) |  |  |  |  |  |
| Earnings before income taxes |  | $ | 548 |  |  | $ | 244 |  |  |  |  |  |

[0001783180-25-000028:8k_2_02:99]
|  |  | (Unaudited) |  |  |
|  |  | Three Months Ended March 31, |  |  |
| (In millions) |  | 2025 |  | 2024 |  |  |  |  |
| Reconciliation of Segment operating profit to Adjusted operating profit |  |  |  |  |  |  |  |  |
| Climate Solutions Americas |  | $ | 570 |  |  | $ | 425 |  |  |  |  |  |
| Climate Solutions Europe |  | 105 |  |  | 167 |  |  |  |  |  |
| Climate Solutions Asia Pacific, Middle East & Africa |  | 121 |  |  | 108 |  |  |  |  |  |
| Climate Solutions Transportation |  | 97 |  |  | 113 |  |  |  |  |  |
| Segment operating profit |  | $ | 893 |  |  | $ | 813 |  |  |  |  |  |
| Corporate and other |  | (50) |  |  | (49) |  |  |  |  |  |
| Adjusted operating profit |  | $ | 843 |  |  | $ | 764 |  |  |  |  |  |

[0001783180-25-000028:8k_2_02:100]
13

[0001783180-25-000028:8k_2_02:101]
Carrier Global Corporation

[0001783180-25-000028:8k_2_02:102]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP) Results

[0001783180-25-000028:8k_2_02:103]
Net Income, Earnings Per Share and Effective Tax Rate

[0001783180-25-000028:8k_2_02:104]
|  | (Unaudited) |
|  | Three Months Ended March 31, 2025 |  |  |
| (In millions, except per share amounts) | Reported |  | Adjustments |  | Adjusted |  |  |  |  |  |  |
| Net sales | $ | 5,218 |  |  | $ | — |  |  | $ | 5,218 |  |  |  |  |  |  |  |
| Operating profit | $ | 629 |  |  | 214 |  | a | $ | 843 |  |  |  |  |  |  |  |
| Operating margin | 12.1 | % |  |  |  | 16.2 | % |  |  |  |  |  |  |
| Earnings before income taxes | $ | 548 |  |  | 214 |  | a | $ | 762 |  |  |  |  |  |  |  |
| Income tax (expense) benefit | $ | (111) |  |  | (57) |  | c | $ | (168) |  |  |  |  |  |  |  |
| Effective tax rate | 20.3 | % |  |  |  | 22.0 | % |  |  |  |  |  |  |
| Earnings from continuing operations attributable to common shareowners | $ | 412 |  |  | $ | 157 |  |  | $ | 569 |  |  |  |  |  |  |  |
| Summary of Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of acquired intangibles |  |  | $ | 201 |  | a |  |  |  |  |  |  |  |
| Restructuring costs |  |  | 8 |  | a |  |  |  |  |  |  |  |
| Acquisition/divestiture-related costs |  |  | 5 |  | a |  |  |  |  |  |  |  |
| Total adjustments |  |  | $ | 214 |  |  |  |  |  |  |  |  |  |
| Tax effect on adjustments above |  |  | $ | (57) |  |  |  |  |  |  |  |  |  |
| Total tax adjustments |  |  | $ | (57) |  | c |  |  |  |  |  |  |  |
| Diluted shares outstanding | 878.3 |  |  |  |  | 878.3 |  |  |  |  |  |  |  |
| Diluted earnings per share: |  |  |  |  |  |  |  |  |  |  |  |
| Continuing operations | $ | 0.47 |  |  |  |  | $ | 0.65 |  |  |  |  |  |  |  |

[0001783180-25-000028:8k_2_02:105]
Carrier Global Corporation

[0001783180-25-000028:8k_2_02:106]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP) Results

[0001783180-25-000028:8k_2_02:107]
Net Income, Earnings Per Share and Effective Tax Rate

[0001783180-25-000028:8k_2_02:108]
|  | (Unaudited) |
|  | Three Months Ended March 31, 2024 |  |  |
| (In millions, except per share amounts) | Reported |  | Adjustments |  | Adjusted |  |  |  |  |  |  |
| Net sales | $ | 5,420 |  |  | $ | — |  |  | $ | 5,420 |  |  |  |  |  |  |  |
| Operating profit | $ | 385 |  |  | 379 |  | a | $ | 764 |  |  |  |  |  |  |  |
| Operating margin | 7.1 | % |  |  |  | 14.1 | % |  |  |  |  |  |  |
| Earnings before income taxes | $ | 244 |  |  | 379 |  | a | $ | 623 |  |  |  |  |  |  |  |
| Income tax (expense) benefit | $ | (47) |  |  | (86) |  | c | $ | (133) |  |  |  |  |  |  |  |
| Effective tax rate | 19.4 | % |  |  |  | 21.4 | % |  |  |  |  |  |  |
| Earnings from continuing operations attributable to common shareowners | $ | 177 |  |  | $ | 293 |  |  | $ | 470 |  |  |  |  |  |  |  |
| Summary of Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of acquired intangibles |  |  | $ | 172 |  | a |  |  |  |  |  |  |  |
| Restructuring costs |  |  | 8 |  | a |  |  |  |  |  |  |  |
| Acquisition/divestiture-related costs |  |  | 48 |  | a |  |  |  |  |  |  |  |
| Acquisition on step-up amortization (1) |  |  | 111 |  | a |  |  |  |  |  |  |  |
| Viessmann-related hedges |  |  | 86 |  | a |  |  |  |  |  |  |  |
| Gain on liability adjustment (2) |  |  | (46) |  | a |  |  |  |  |  |  |  |
| Total adjustments |  |  | $ | 379 |  |  |  |  |  |  |  |  |  |
| Tax effect on adjustments above |  |  | $ | (86) |  |  |  |  |  |  |  |  |  |
| Total tax adjustments |  |  | $ | (86) |  | c |  |  |  |  |  |  |  |
| Diluted shares outstanding | 913.0 |  |  |  |  | 913.0 |  |  |  |  |  |  |  |
| Diluted earnings per share: |  |  |  |  |  |  |  |  |  |  |  |
| Continuing operations | $ | 0.19 |  |  |  |  | $ | 0.51 |  |  |  |  |  |  |  |

[0001783180-25-000028:8k_2_02:109]
(1) Amortization of the step-up to fair value of acquired inventory and backlog.

[0001783180-25-000028:8k_2_02:110]
(2) Gain associated with an adjustment to our tax-related liability owed to UTC.

[0001783180-25-000028:8k_2_02:111]
Free Cash Flow Reconciliation

[0001783180-25-000028:8k_2_02:112]
|  |  | (Unaudited) |
|  |  | Three Months Ended March 31, |
| (In millions) |  | 2025 |  | 2024 |
| Net cash flows provided by operating activities |  | $ | 483 |  |  | $ | 40 |  |
| Less: Capital expenditures - continuing operations |  | (63) |  |  | (102) |  |
| Less: Capital expenditures - discontinued operations |  | — |  |  | (2) |  |
| Free cash flow |  | $ | 420 |  |  | $ | (64) |  |

[0001783180-25-000028:8k_2_02:113]
15

[0001783180-25-000028:8k_2_02:114]
Net Debt Reconciliation

[0001783180-25-000028:8k_2_02:115]
|  |  | (Unaudited) |
| (In millions) |  | March 31, 2025 |  | December 31, 2024 |
| Long-term debt |  | $ | 11,080 |  |  | $ | 11,026 |  |
| Current portion of long-term debt |  | 104 |  |  | 1,252 |  |
| Less: Cash and cash equivalents |  | 1,698 |  |  | 3,969 |  |
| Net debt |  | $ | 9,486 |  |  | $ | 8,309 |  |
