# CARR note change history — 0001783180-24-000088 → 0001783180-25-000030


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-05-01):
[0001783180-25-000030:note_history:1]
| (In millions) |  | March 31,2025 |  | December 31,2024 |
| Environmental reserves included in Accrued liabilities |  | $ | 18 |  |  | $ | 25 |  |
| Environmental reserves included in Other long-term liabilities |  | 188 |  |  | 185 |  |
| Total Environmental reserves |  | $ | 206 |  |  | $ | 210 |  |
  (was, 2024-10-25, similarity 0.974):
[0001783180-24-000088:note_history:1]
| (In millions) |  | September 30,2024 |  | December 31,2023 |
| Environmental reserves included in Accrued liabilities |  | $ | 11 |  |  | $ | 19 |  |
| Environmental reserves included in Other long-term liabilities |  | 202 |  |  | 199 |  |
| Total Environmental reserves |  | $ | 213 |  |  | $ | 218 |  |

- changed (2025-05-01):
[0001783180-25-000030:note_history:2]
| (In millions) |  | March 31,2025 |  | December 31,2024 |
| Asbestos liabilities included in Accrued liabilities |  | $ | 17 |  |  | $ | 17 |  |
| Asbestos liabilities included in Other long-term liabilities |  | 203 |  |  | 208 |  |
| Total Asbestos liabilities |  | $ | 220 |  |  | $ | 225 |  |
| Asbestos-related recoveries included in Other current assets |  | $ | 7 |  |  | $ | 7 |  |
| Asbestos-related recoveries included in Other assets |  | 86 |  |  | 88 |  |
| Total Asbestos-related recoveries |  | $ | 93 |  |  | $ | 95 |  |
  (was, 2024-10-25, similarity 0.9877):
[0001783180-24-000088:note_history:2]
| (In millions) |  | September 30,2024 |  | December 31,2023 |
| Asbestos liabilities included in Accrued liabilities |  | $ | 17 |  |  | $ | 15 |  |
| Asbestos liabilities included in Other long-term liabilities |  | 208 |  |  | 206 |  |
| Total Asbestos liabilities |  | $ | 225 |  |  | $ | 221 |  |
| Asbestos-related recoveries included in Other current assets |  | $ | 7 |  |  | $ | 5 |  |
| Asbestos-related recoveries included in Other assets |  | 88 |  |  | 88 |  |
| Total Asbestos-related recoveries |  | $ | 95 |  |  | $ | 93 |  |

- changed (2025-05-01):
[0001783180-25-000030:note_history:3]
As of March 31, 2025, the Company, Kidde-Fenwal, Inc. ("KFI") and others have been named as defendants in more than 10,000 lawsuits filed in United States state or federal courts and a single case in Canada alleging that the historic use of Aqueous Film Forming Foam ("AFFF") caused personal injuries and damage to property and water supplies. In December 2018, the U.S. Judicial Panel on Multidistrict Litigation transferred and consolidated all AFFF cases pending in the U.S. federal courts against the Company, KFI and others to the U.S. District Court for the District of South Carolina (the "MDL Proceedings"). Individual plaintiffs in the MDL Proceedings generally seek damages for alleged personal injuries, medical monitoring, diminution in property value and injunctive relief to remediate alleged contamination of water supplies. U.S. state, municipal and water utility plaintiffs in the MDL Proceedings generally seek damages and costs related to the remediation of public property and water supplies.
  (was, 2024-10-25, similarity 0.993):
[0001783180-24-000088:note_history:3]
As of September 30, 2024, the Company, Kidde-Fenwal, Inc. ("KFI") and others have been named as defendants in more than 8,000 lawsuits filed in United States state or federal courts and a single case in Canada alleging that the historic use of Aqueous Film Forming Foam ("AFFF") caused personal injuries and damage to property and water supplies. In December 2018, the U.S. Judicial Panel on Multidistrict Litigation transferred and consolidated all AFFF cases pending in the U.S. federal courts against the Company, KFI and others to the U.S. District Court for the District of South Carolina (the "MDL Proceedings"). Individual plaintiffs in the MDL Proceedings generally seek damages for alleged personal injuries, medical monitoring, diminution in property value and injunctive relief to remediate alleged contamination of water supplies. U.S. state, municipal and water utility plaintiffs in the MDL Proceedings generally seek damages and costs related to the remediation of public property and water supplies.

- changed (2025-05-01):
[0001783180-25-000030:note_history:4]
As part of the Proposed Settlement Agreements, the Company will pay $615 million in cash over five years, 100% of the net sale proceeds from its sale of KFI’s assets to Pacific Avenue Capital Partners, which are estimated to be $115 million, and contribute the right to recover proceeds under certain of its insurance policies. The Company will be entitled to receive up to $2.4 billion of proceeds from those insurance policies and will contribute the first $125 million of such proceeds as additional consideration in the Direct Claims Settlements. The Company also will be entitled to any earnouts payable to KFI under the KFI sale agreement. The Company expects insurance payments it receives in the future, in the aggregate, to cover the amount paid under the Proposed Settlement Agreements. As a result of the Proposed Settlement Agreements, the Company recorded a liability in the amount of $565 million during the three months ended September 30, 2024. The amount recognized is in addition to liabilities of $50 million that the Company recorded upon the deconsolidation of KFI on May 14, 2023, as further discussed below. As of March 31, 2025, the Company has not recorded any amounts associated with expected insurance proceeds.
  (was, 2024-10-25, similarity 0.986):
[0001783180-24-000088:note_history:4]
As part of the Proposed Settlement Agreements, the Company will pay $615 million in cash over five years, 100% of the net sale proceeds from the sale of KFI’s assets from its sale to Pacific Avenue Capital Partners, which are estimated to be $115 million, and contribute the right to recover proceeds under certain of its insurance policies. The Company will be entitled to receive up to $2.4 billion of proceeds from those insurance policies and will contribute the first $125 million of such proceeds as additional consideration in the Direct Claims Settlements. The Company also will be entitled to any earnouts payable to KFI under the KFI sale agreement. The Company expects insurance payments it receives in the future, in the aggregate, to cover the amount paid under the Proposed Settlement Agreements. As a result of the Proposed Settlement Agreements, the Company recorded a liability in the amount of $565 million during the three months ended September 30, 2024. The amount recognized is in addition to liabilities of $50 million that the Company recorded upon the deconsolidation of KFI on May 14, 2023, as further discussed below. As of September 30, 2024, the Company has not recorded any amounts associated with expected insurance proceeds.

- added (2025-05-01):
[0001783180-25-000030:note_history:5]
On November 14, 2024, KFI filed the chapter 11 plan of liquidation (as may be further amended, restated, supplemented, waived, or otherwise modified from time to time, the "Chapter 11 Plan"), which incorporates the Estate Claims Settlement, provides for the treatment of the various creditor classes, and establishes wind-down provisions, among other things, and the disclosure statement for the Chapter 11 Plan (as may be further amended, restated, supplemented, waived, or otherwise modified from time to time, the "Disclosure Statement"). A hearing to approve the Disclosure Statement, its ancillary documents and establish a Chapter 11 Plan confirmation timeline in the Bankruptcy Court is expected to be held in May 2025.

- changed (2025-05-01):
[0001783180-25-000030:note_history:6]
As of May 14, 2023, the Company no longer controlled KFI as its activities are subject to review and oversight by the Bankruptcy Court. Therefore, KFI was deconsolidated and its respective assets and liabilities were derecognized from the Company’s Unaudited Condensed Consolidated Financial Statements. Upon deconsolidation, the Company determined the fair value of its retained interest in KFI to be zero and we accounted for it prospectively using the cost method.
  (was, 2024-10-25, similarity 0.8698):
[0001783180-24-000088:note_history:6]
As of May 14, 2023, the Company no longer controlled KFI as its activities are subject to review and oversight by the Bankruptcy Court. Therefore, KFI was deconsolidated and its respective assets and liabilities were derecognized from the Company’s Unaudited Condensed Consolidated Financial Statements. Upon deconsolidation, the Company determined the fair value of its retained interest in KFI to be zero and we accounted for it prospectively using the cost method. As a result of these actions, the Company recognized a loss of $297 million in its Unaudited Condensed Consolidated Statement of Operations

- changed (2025-05-01):
[0001783180-25-000030:note_history:7]
In connection with the bankruptcy filing, KFI entered into several agreements with subsidiaries of the Company to ensure they have access to services necessary for the effective operation of their business. All post-deconsolidation activity between the Company and KFI are reported as third-party transactions recorded within the Company's Unaudited Condensed Consolidated Statement of Operations. Since the petition date, there were no material transactions between the Company and KFI other than a $15 million payment during 2024 by the Company to KFI under the terms of a tax sharing arrangement.
  (was, 2024-10-25, similarity 0.9009):
[0001783180-24-000088:note_history:7]
In connection with the bankruptcy filing, KFI entered into several agreements with subsidiaries of the Company to ensure they have access to services necessary for the effective operation of their business. All post-deconsolidation activity between the Company and KFI are reported as third-party transactions recorded within the Company's Unaudited Condensed Consolidated Statement of Operations. Since the petition date, there were no material transactions between the Company and KFI other than a $15 million payment by the Company to KFI under the terms of a tax sharing arrangement.

- changed (2025-05-01):
[0001783180-25-000030:note_history:8]
Under the TMA relating to the Separation, the Company is responsible to UTC for its share of the Tax Cuts and Jobs Act transition tax associated with foreign undistributed earnings as of December 31, 2017. As a result, a liability of $101 million is included within the accompanying Unaudited Condensed Consolidated Balance Sheet within Other Long-Term Liabilities as of March 31, 2025. This obligation is expected to be settled in April 2026. The Company believes that the likelihood of incurring losses materially in excess of this amount is remote.
  (was, 2024-10-25, similarity 0.6763):
[0001783180-24-000088:note_history:8]
Under the TMA relating to the Separation, the Company is responsible to UTC for its share of the Tax Cuts and Jobs Act transition tax associated with foreign undistributed earnings as of December 31, 2017. During the nine months ended September 30, 2024, the Company recognized a $46 million gain associated with the TMA and UTC's conclusion of certain income tax matters from their 2017 and 2018 tax audit with the IRS. Liabilities under the TMA of $118 million and $108 million are included within the accompanying Unaudited Condensed Consolidated Balance Sheet within Accrued Liabilities and Other Long-Term Liabilities as of September 30, 2024, respectively. This obligation is expected to be settled in annual installments with the next installment of $118 million due in April 2025 and the final installment of $108 million due in April 2026. The Company believes that the likelihood of incurring losses materially in excess of this amount is remote.

- removed (2025-05-01):
[0001783180-24-000088:note_history:9]
within within Other income/(expense), net. In addition, the deconsolidation resulted in an investing cash outflow of $134 million in the Company's Unaudited Condensed Consolidated Statement of Cash Flows.


## us-gaap:ScheduleOfEnvironmentalLossContingenciesBySiteTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-05-01):
[0001783180-25-000030:note_history:10]
| (In millions) |  | March 31,2025 |  | December 31,2024 |
| Environmental reserves included in Accrued liabilities |  | $ | 18 |  |  | $ | 25 |  |
| Environmental reserves included in Other long-term liabilities |  | 188 |  |  | 185 |  |
| Total Environmental reserves |  | $ | 206 |  |  | $ | 210 |  |
  (was, 2024-10-25, similarity 0.974):
[0001783180-24-000088:note_history:10]
| (In millions) |  | September 30,2024 |  | December 31,2023 |
| Environmental reserves included in Accrued liabilities |  | $ | 11 |  |  | $ | 19 |  |
| Environmental reserves included in Other long-term liabilities |  | 202 |  |  | 199 |  |
| Total Environmental reserves |  | $ | 213 |  |  | $ | 218 |  |


## us-gaap:ScheduleOfLossContingenciesByContingencyTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-05-01):
[0001783180-25-000030:note_history:11]
| (In millions) |  | March 31,2025 |  | December 31,2024 |
| Asbestos liabilities included in Accrued liabilities |  | $ | 17 |  |  | $ | 17 |  |
| Asbestos liabilities included in Other long-term liabilities |  | 203 |  |  | 208 |  |
| Total Asbestos liabilities |  | $ | 220 |  |  | $ | 225 |  |
| Asbestos-related recoveries included in Other current assets |  | $ | 7 |  |  | $ | 7 |  |
| Asbestos-related recoveries included in Other assets |  | 86 |  |  | 88 |  |
| Total Asbestos-related recoveries |  | $ | 93 |  |  | $ | 95 |  |
  (was, 2024-10-25, similarity 0.9877):
[0001783180-24-000088:note_history:11]
| (In millions) |  | September 30,2024 |  | December 31,2023 |
| Asbestos liabilities included in Accrued liabilities |  | $ | 17 |  |  | $ | 15 |  |
| Asbestos liabilities included in Other long-term liabilities |  | 208 |  |  | 206 |  |
| Total Asbestos liabilities |  | $ | 225 |  |  | $ | 221 |  |
| Asbestos-related recoveries included in Other current assets |  | $ | 7 |  |  | $ | 5 |  |
| Asbestos-related recoveries included in Other assets |  | 88 |  |  | 88 |  |
| Total Asbestos-related recoveries |  | $ | 95 |  |  | $ | 93 |  |


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2025-05-01):
[0001783180-25-000030:note_history:12]
During 2024, the Company completed several activities designed to simplify its business portfolio, transforming it into a pure-play climate and energy solutions provider. On January 2, 2024, the Company acquired the climate solutions business (the "VCS Business") of Viessmann Group GmbH & Co. KG (“Viessmann”). The VCS Business, primarily reported in the Climate Solutions Europe segment, is a premier residential and light commercial HVAC provider in Europe that expanded our portfolio to offer a global, comprehensive suite of sustainable and innovative building and cold-chain solutions. In addition, the Company divested its Commercial and Residential Fire, Access Solutions and Industrial Fire businesses which were historically reported in its Fire & Security segment. The transactions represented a single disposal plan to separately divest multiple businesses over different reporting periods and met the criteria to be presented as discontinued operations in the accompanying financial statements. The Company also divested its Commercial Refrigeration business (“CCR”) during 2024. CCR, which was historically reported in the Climate Solutions Transportation segment (previously named Refrigeration), did not meet the criteria to be presented as discontinued operations.

- added (2025-05-01):
[0001783180-25-000030:note_history:13]
Segment Reorganization

- added (2025-05-01):
[0001783180-25-000030:note_history:14]
As a result of the Company's portfolio transformation, the Company revised its reportable segments during the first quarter to better reflect its business strategy, align its management reporting and increase transparency for investors. Under the revised segment structure, the Company has three new regional HVAC operating segments. Combined with the Climate Solutions Transportation operating segment, the four operating segments also serve as the Company's reportable segments. This model is designed to create a simplified, more focused and customer-centric organization across the globe. Each segment reports through separate management teams which regularly review their operating results with the Company's Chief Operating Decision Maker (the "CODM") determined in accordance with applicable accounting guidance. In connection with the revised structure, the CODM changed the measure used to evaluate segment profitability from Operating profit to Segment operating profit. All prior period comparative information has been recast to reflect the revised segment structure. See Note 17 – Segment Financial Data for additional information.

- changed (2025-05-01):
[0001783180-25-000030:note_history:15]
On April 3, 2020 (the "Distribution Date"), United Technologies Corporation ("UTC"), since renamed RTX Corporation ("Raytheon Technologies Corporation" or "RTX"), completed the spin-off of Carrier into an independent, publicly traded company (the "Separation") through a pro-rata distribution (the "Distribution") on a one-for-one basis of all of the outstanding shares of common stock of Carrier to UTC shareowners who held shares of UTC common stock as of the close of business on March 19, 2020, the record date of the Distribution. In addition, the Company entered into several agreements with UTC and Otis Worldwide Corporation ("Otis") that govern various aspects of the relationship among the Company, UTC and Otis. As of March 31, 2025, only certain portions of the Tax Matters Agreement ("TMA") remain in effect.
  (was, 2024-10-25, similarity 0.9647):
[0001783180-24-000088:note_history:15]
On April 3, 2020 (the "Distribution Date"), United Technologies Corporation ("UTC"), since renamed RTX Corporation ("Raytheon Technologies Corporation" or "RTX"), completed the spin-off of Carrier into an independent, publicly traded company (the "Separation") through a pro-rata distribution (the "Distribution") on a one-for-one basis of all of the outstanding shares of common stock of Carrier to UTC shareowners who held shares of UTC common stock as of the close of business on March 19, 2020, the record date of the Distribution. Following the Separation and Distribution, the Company entered into several agreements with UTC and Otis Worldwide Corporation ("Otis") that govern various aspects of the relationship among the Company, UTC and Otis. As of September 30, 2024, only certain portions of the Tax Matters Agreement ("TMA") remain in effect.

- changed (2025-05-01):
[0001783180-25-000030:note_history:16]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures ("ASU 2023-09"), which requires public entities to disclose disaggregated information about their effective tax rate reconciliation as well as information on income taxes paid. ASU 2023-09 is effective for annual periods beginning after December 15, 2024, with early adoption permitted. The ASU requires additional disclosures and is not expected to have a material impact on the Company's financial statements.
  (was, 2024-10-25, similarity 0.8264):
[0001783180-24-000088:note_history:16]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures ("ASU 2023-09"), which requires public entities to disclose disaggregated information about their effective tax rate reconciliation as well as information on income taxes paid. ASU 2023-09 is effective for fiscal years beginning after December 15, 2024, with early adoption permitted. The Company is currently assessing the impact of this ASU on its financial statements.

- added (2025-05-01):
[0001783180-25-000030:note_history:17]
In November 2024, the FASB issued ASU 2024-03, Disaggregation of Income Statement Expenses (DISE) ("ASU 2024-03"), which requires public entities to disclose disaggregated information about expenses by nature on an interim and annual basis. ASU 2024-03 is effective for fiscal years beginning after December 15, 2026 and interim periods within fiscal years beginning after December 15, 2027, with early adoption permitted. The Company is currently assessing the impact of this ASU on its financial statements.

- removed (2025-05-01):
[0001783180-24-000088:note_history:18]
Acquisition of Viessmann Climate Solutions

- removed (2025-05-01):
[0001783180-24-000088:note_history:19]
On April 25, 2023, the Company announced that it entered into a Share Purchase Agreement (the “Agreement”) to acquire the climate solutions business (the "VCS Business") of Viessmann Group GmbH & Co. KG (“Viessmann”), a privately-held company. The acquisition was completed on January 2, 2024. As a result, the assets, liabilities and results of operations of the VCS Business are consolidated in the accompanying Unaudited Condensed Consolidated Financial Statements as of the date of acquisition and reported within the Company’s HVAC segment. See Note 15 – Acquisitions for additional information.

- removed (2025-05-01):
[0001783180-24-000088:note_history:20]
On December 7, 2023, the Company entered into a stock purchase agreement to sell its Access Solutions business ("Access Solutions") to Honeywell International Inc. As a result, the assets and liabilities of Access Solutions are presented as held for sale on the accompanying Unaudited Condensed Consolidated Balance Sheet as of December 31, 2023, and recorded at the lower of their carrying value or fair value less estimated cost to sell. The sale of Access Solutions was completed on June 2, 2024. See Note 16 - Divestitures for additional information.

- removed (2025-05-01):
[0001783180-24-000088:note_history:21]
During the fourth quarter of 2023, the net assets of the Company's Industrial Fire business ("Industrial Fire") met the criteria to be classified as held for sale. As a result, the assets and liabilities of Industrial Fire are presented as held for sale on the accompanying Unaudited Condensed Consolidated Balance Sheet as of December 31, 2023, and recorded at the lower of their carrying value or fair value less estimated cost to sell. On March 5, 2024, the Company entered into a stock purchase agreement to sell Industrial Fire to Sentinel Capital Partners. The sale of Industrial Fire was completed on July 1, 2024. See Note 16 - Divestitures for additional information.

- removed (2025-05-01):
[0001783180-24-000088:note_history:22]
On December 12, 2023, the Company entered into a stock purchase agreement to sell its Commercial Refrigeration business ("CCR") to Haier Group Corporation for an enterprise value of approximately $775 million. As a result, the assets and liabilities of CCR are presented as held for sale on the accompanying Unaudited Condensed Consolidated Balance Sheet as of September 30, 2024 and December 31, 2023, and recorded at the lower of their carrying value or fair value less estimated cost to sell. The sale of CCR was completed on October 1, 2024. See Note 16 - Divestitures for additional information.

- removed (2025-05-01):
[0001783180-24-000088:note_history:23]
On August 15, 2024, the Company entered into a stock purchase agreement to sell its Commercial and Residential Fire business (“CRF Business”) to an affiliate of Lone Star Funds for an enterprise value of approximately $3.0 billion. As a result, the assets and liabilities of the CRF Business are presented as held for sale on the accompanying Unaudited Condensed Consolidated Balance Sheet as of September 30, 2024 and December 31, 2023, and recorded at the lower of their carrying value or fair value less estimated cost to sell. See Note 16 - Divestitures for additional information.

- removed (2025-05-01):
[0001783180-24-000088:note_history:24]
Discontinued Operations

- removed (2025-05-01):
[0001783180-24-000088:note_history:25]
In 2023, the Company announced plans to exit its Fire & Security and Commercial Refrigeration businesses over the course of 2024. The announced plan to exit the Fire & Security segment represents a single disposal plan to separately divest multiple businesses over different reporting periods. Upon the CRF Business qualifying as held for sale during the three months ended September 30, 2024, the components of the Fire & Security segment in aggregate met the criteria to be presented as discontinued operations in the accompanying Unaudited Condensed Consolidated Statement of Operations and Unaudited Condensed Consolidated Statement of Cash Flows. In addition, the assets and liabilities of the CRF Business have been reclassified to held for sale at December 31, 2023. The results of the CCR business did not meet the criteria to be presented in discontinued operations. See Note 16 - Divestitures for additional information.

- removed (2025-05-01):
[0001783180-24-000088:note_history:26]
Deconsolidation of Kidde-Fenwal, Inc.

- removed (2025-05-01):
[0001783180-24-000088:note_history:27]
On May 14, 2023, Kidde-Fenwal, Inc. ("KFI"), an indirect wholly-owned subsidiary of the Company, filed a petition for voluntary reorganization under Chapter 11 of the United States Bankruptcy Code ("Chapter 11") in the United States Bankruptcy Court for the District of Delaware. KFI, an industrial fire detection and suppression business historically reported in the Company's Fire & Security segment, indicated that it intended to use the bankruptcy process to explore strategic alternatives, including the sale of KFI as a going concern. As of the petition date, KFI was deconsolidated and its respective assets and liabilities were derecognized from the Company's Unaudited Condensed Consolidated Financial Statements. The sale of KFI was completed on July 1, 2024. See Note 19 - Commitments and Contingent Liabilities for additional information.

- removed (2025-05-01):
[0001783180-24-000088:note_history:28]
In November 2023, the FASB issued ASU 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures (“ASU 2023-07”), which requires public entities to disclose information about their reportable segments’ significant expenses on an interim and annual basis. In addition, the amendments clarify circumstances in which an entity can disclose multiple segment measures of profit or loss, provide new segment disclosure requirements for entities with a single reportable segment and contain other disclosure requirements. ASU 2023-07 is effective for fiscal years beginning after December 15, 2023 and interim periods beginning after December 15, 2024, with early adoption permitted. The Company is currently assessing the impact of this ASU on its financial statements.

- removed (2025-05-01):
[0001783180-24-000088:note_history:29]
On March 6, 2024, the SEC adopted new rules designed to enhance public company disclosures related to the risks and impacts of climate-related matters. The rules amend the provisions of both Regulation S-K and Regulation S-X to require disclosure of climate-related risks, transition plans, targets and goals, risk management and governance as well as require disclosure of the financial effects of severe weather events and other natural conditions as well as the use of carbon offsets or renewable energy credits. Disclosure requirements will begin phasing in for fiscal years beginning on or after January 1, 2025, subject to legal challenges and the SEC's voluntary stay of the disclosure requirements. The Company will continue to assess the impact of these new rules on its financial statements while the stay is in place.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2025-05-01):
[0001783180-25-000030:note_history:30]
DESCRIPTION OF THE BUSINESS
Carrier Global Corporation (the "Company") is a global leader in intelligent climate and energy solutions with a focus on providing differentiated, digitally-enabled lifecycle solutions to its customers. The Company's portfolio includes industry-leading brands such as Carrier, Viessmann, Toshiba, Automated Logic and Carrier Transicold that offer innovative heating, ventilating, air conditioning ("HVAC") and cold chain transportation solutions to enhance the lives we live and the world we share. The Company also provides a broad array of related building services, including audit, design, installation, system integration, repair, maintenance and monitoring. The Company's operations are classified into four segments: Climate Solutions Americas, Climate Solutions Europe, Climate Solutions Asia Pacific, Middle East & Africa and Climate Solutions Transportation.

- removed (2025-05-01):
[0001783180-24-000088:note_history:31]
DESCRIPTION OF THE BUSINESS
Carrier Global Corporation (the "Company") is a global leader in intelligent climate and energy solutions with a focus on providing differentiated, digitally-enabled lifecycle solutions to its customers. The Company's portfolio includes industry-leading brands such as Carrier, Viessmann, Toshiba, Automated Logic and Carrier Transicold that offer innovative heating, ventilating, air conditioning ("HVAC"), refrigeration and cold chain transportation solutions to help make the world safer and more comfortable. The Company also provides a broad array of related building services, including audit, design, installation, system integration, repair, maintenance and monitoring. The Company's operations are classified into two segments: HVAC and Refrigeration.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-05-01):
[0001783180-25-000030:note_history:32]
| (In millions) |  |  |  | March 31,2025 |  | December 31,2024 |
| 2.242% Notes due 2025 (1) |  |  |  | $ | — |  |  | $ | 1,200 |  |
| 2.493% Notes due 2027 |  |  |  | 900 |  |  | 900 |  |
| 4.125% Notes due 2028 |  |  |  | 809 |  |  | 783 |  |
| 2.722% Notes due 2030 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.700% Notes due 2031 |  |  |  | 750 |  |  | 750 |  |
| 4.500% Notes due 2032 |  |  |  | 917 |  |  | 887 |  |
| 5.900% Notes due 2034 |  |  |  | 875 |  |  | 875 |  |
| 3.625% Notes due 2037 |  |  |  | 809 |  |  | 783 |  |
| 3.377% Notes due 2040 |  |  |  | 1,500 |  |  | 1,500 |  |
| 3.577% Notes due 2050 |  |  |  | 1,400 |  |  | 1,400 |  |
| 6.200% Notes due 2054 |  |  |  | 650 |  |  | 650 |  |
| Total long-term notes |  |  |  | 10,610 |  |  | 11,728 |  |
| Japanese Term Loan Facility |  |  |  | 358 |  |  | 342 |  |
| Other debt (including project financing obligations and finance leases) |  |  |  | 302 |  |  | 296 |  |
| Discounts and debt issuance costs |  |  |  | (86) |  |  | (88) |  |
| Total debt |  |  |  | 11,184 |  |  | 12,278 |  |
| Less: current portion of long-term debt |  |  |  | 104 |  |  | 1,252 |  |
| Long-term debt, net of current portion |  |  |  | $ | 11,080 |  |  | $ | 11,026 |  |
  (was, 2024-10-25, similarity 0.9132):
[0001783180-24-000088:note_history:32]
| (In millions) |  |  |  | September 30,2024 |  | December 31,2023 |
| 2.242% Notes due 2025 (1) |  |  |  | $ | 1,200 |  |  | $ | 1,200 |  |
| 4.375% Notes due 2025 (2) |  |  |  | 836 |  |  | 830 |  |
| 5.800% Notes due 2025 |  |  |  | — |  |  | 1,000 |  |
| 2.493% Notes due 2027 |  |  |  | 900 |  |  | 900 |  |
| 4.125% Notes due 2028 |  |  |  | 836 |  |  | 830 |  |
| 2.722% Notes due 2030 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.700% Notes due 2031 |  |  |  | 750 |  |  | 750 |  |
| 4.500% Notes due 2032 |  |  |  | 948 |  |  | 941 |  |
| 5.900% Notes due 2034 |  |  |  | 875 |  |  | 1,000 |  |
| 3.377% Notes due 2040 |  |  |  | 1,500 |  |  | 1,500 |  |
| 3.577% Notes due 2050 |  |  |  | 1,400 |  |  | 2,000 |  |
| 6.200% Notes due 2054 |  |  |  | 650 |  |  | 1,000 |  |
| Total long-term notes |  |  |  | 11,895 |  |  | 13,951 |  |
| Japanese Term Loan Facility |  |  |  | 374 |  |  | 379 |  |
| Other debt (including project financing obligations and finance leases) |  |  |  | 243 |  |  | 74 |  |
| Discounts and debt issuance costs |  |  |  | (80) |  |  | (111) |  |
| Total debt |  |  |  | 12,432 |  |  | 14,293 |  |
| Less: current portion of long-term debt |  |  |  | 2,095 |  |  | 51 |  |
| Long-term debt, net of current portion |  |  |  | $ | 10,337 |  |  | $ | 14,242 |  |

- changed (2025-05-01):
[0001783180-25-000030:note_history:33]
(1) 2.242% Notes due February 15, 2025; repaid during February 2025.
  (was, 2024-10-25, similarity 0.6618):
[0001783180-24-000088:note_history:33]
(1) 2.242% Notes due February 15, 2025; reclassified to Current portion of long-term debt.

- changed (2025-05-01):
[0001783180-25-000030:note_history:34]
On December 20, 2024, the Company refinanced its revolving credit agreement with JPMorgan Chase Bank, N.A., as administrative agent, and certain other lenders, permitting aggregate borrowings of up to $2.5 billion pursuant to an unsecured, unsubordinated revolving credit facility that matures in December 2029 (the "Revolving Credit Facility"). The Revolving Credit Facility supports the Company's commercial paper program and can be used for other general corporate purposes. Borrowings are available in U.S. Dollars and Euros. U.S. Dollar borrowings bear interest at either a Term SOFR Rate plus 0.10% and a ratings-based margin or, alternatively, at an alternate base rate plus a ratings-based margin. Euro borrowings bear interest at an adjusted EURIBOR rate plus a ratings-based margin. A ratings-based commitment fee is charged on unused commitments. Upon entering into the agreement, the Company capitalized $11 million of deferred financing costs which are being amortized over its term. As of March 31, 2025, there were no borrowings outstanding under the Revolving Credit Facility.
  (was, 2024-10-25, similarity 0.9494):
[0001783180-24-000088:note_history:34]
On May 19, 2023, the Company entered into a revolving credit agreement with JPMorgan Chase Bank, N.A., as administrative agent, and certain other lenders, permitting aggregate borrowings of up to $2.0 billion pursuant to an unsecured, unsubordinated revolving credit facility that matures in May 2028 (the "Revolving Credit Facility"). The Revolving Credit Facility supports the Company's commercial paper program and can be used for other general corporate purposes. Borrowings are available in U.S. Dollars and Euros. U.S. Dollar borrowings bear interest at either a Term SOFR Rate plus 0.10% and a ratings-based margin or, alternatively, at an alternate base rate plus a ratings-based margin. Euro borrowings bear interest at an adjusted EURIBOR rate plus a ratings-based margin. A ratings-based commitment fee is charged on unused commitments. In addition, the Company capitalized $2 million of deferred financing costs which are being amortized over its term. As of September 30, 2024, there were no borrowings outstanding under the Revolving Credit Facility.

- changed (2025-05-01):
[0001783180-25-000030:note_history:35]
The Company has a $2.0 billion unsecured, unsubordinated commercial paper program, which can be used for general corporate purposes, including the funding of working capital and potential acquisitions. As of March 31, 2025, there were no borrowings outstanding under the commercial paper program.
  (was, 2024-10-25, similarity 0.9759):
[0001783180-24-000088:note_history:35]
The Company has a $2.0 billion unsecured, unsubordinated commercial paper program, which can be used for general corporate purposes, including the funding of working capital and potential acquisitions. As of September 30, 2024, there were no borrowings outstanding under the commercial paper program.

- changed (2025-05-01):
[0001783180-25-000030:note_history:36]
The Company is involved in long-term construction contracts in which it arranges project financing with certain customers. As a result, the Company issued $6 million and $10 million of debt during the three months ended March 31, 2025 and 2024, respectively. Long-term debt repayments associated with these financing arrangements during the three months ended March 31, 2025 and 2024, were zero  and $5 million, respectively.
  (was, 2024-10-25, similarity 0.8589):
[0001783180-24-000088:note_history:36]
The Company is involved in long-term construction contracts in which it arranges project financing with certain customers. As a result, the Company issued $40 million and $14 million of debt during the nine months ended September 30, 2024 and 2023, respectively. Long-term debt repayments associated with these financing arrangements during the nine months ended September 30, 2024 and 2023, were $7 million and $15 million, respectively.

- added (2025-05-01):
[0001783180-25-000030:note_history:37]
The Revolving Credit Facility, the indenture for the long-term notes and the five-year, JPY 54 billion (approximately $400 million) senior unsecured term loan facility ("Japanese Term Loan Facility") contain affirmative and negative covenants customary for financings of these types, which, among other things, limit the Company's ability to incur certain liens, to make certain fundamental changes and to enter into sale and leaseback transactions. As of March 31, 2025, the Company was in compliance with the covenants under the agreements governing its outstanding indebtedness.

- removed (2025-05-01):
[0001783180-24-000088:note_history:38]
(2) 4.375% Notes due May 29, 2025; reclassified to Current portion of long-term debt.

- removed (2025-05-01):
[0001783180-24-000088:note_history:39]
Acquisition Funding

- removed (2025-05-01):
[0001783180-24-000088:note_history:40]
On January 2, 2024, the Company completed the acquisition of the VCS Business for total consideration of $14.2 billion. Under the terms of the Agreement, 20% of the purchase price was paid in Carrier common stock, issued directly to Viessmann and subject to certain lock up provisions and 80% was paid in cash, subject to working capital and other adjustments. In order to fund the Euro-denominated cash portion of the purchase price, the Company used cash on hand, debt financing and various term loan facilities.

- removed (2025-05-01):
[0001783180-24-000088:note_history:41]
Debt Issuance

- removed (2025-05-01):
[0001783180-24-000088:note_history:42]
In November 2023, the Company issued $3.0 billion principal amount of USD-denominated notes in three tranches. The tranches consisted of $1.0 billion aggregate principal amount of 5.80% notes due 2025, $1.0 billion aggregate principal amount of 5.90% notes due 2034 and $1.0 billion aggregate principal amount of 6.20% notes due 2054 (collectively, the “USD Notes”). In addition, the Company issued €2.35 billion principal amount of Euro-denominated notes in three tranches. The tranches consisted of €750 million aggregate principal amount of 4.375% notes due 2025, €750 million aggregate principal amount of 4.125% notes due 2028 and €850 million aggregate principal amount of 4.50% notes due 2032 (collectively, the “Euro Notes”). The Company capitalized $51 million of deferred financing costs which are being amortized over the term of their related notes. The notes are subject to certain customary covenants and the Company has the option to redeem the notes in whole or in part at any time prior to their stated maturity date at the redemption price set forth in the indenture agreements. In June 2024, the Company redeemed the $1.0 billion aggregate principal amount of 5.80% notes due in 2025 and incurred a $8 million make-whole premium upon prepayment and wrote off $4 million of related unamortized debt financing costs.

- removed (2025-05-01):
[0001783180-24-000088:note_history:43]
Bridge Loan

- removed (2025-05-01):
[0001783180-24-000088:note_history:44]
On April 25, 2023, the Company entered into commitment letters with JPMorgan Chase Bank, N.A., BofA Securities, Inc. and Bank of America, N.A. to provide a €8.2 billion aggregate principal, senior unsecured bridge term loan facility (the “Bridge Loan”). Euro-denominated borrowings bore interest at the EURIBOR Rate plus a ratings-based margin, USD-denominated borrowings bore interest at either a Term SOFR Rate plus 0.10% and a ratings-based margin or, alternatively, at a base rate plus a ratings-based margin. The Company capitalized $48 million of deferred financing costs associated with the Bridge Loan which were amortized over the commitment period. Upon entering into a senior unsecured delayed draw term loan facility and issuing the USD Notes and the Euro Notes, the Company reduced the Bridge Loan by €7.7 billion and accelerated the amortization on $25 million of deferred financing costs in Interest expense during 2023. On January 2, 2024, the Company entered into a 60-day senior unsecured term loan agreement consisting of a Euro-denominated tranche in an aggregate amount of €113 million and a USD-denominated tranche in an aggregate amount of $349 million (the “60-day Loan”). Upon entering into the 60-day Loan, the Company reduced the final portion of the Bridge Loan by €500 million and subsequently terminated the agreement. Borrowings under the 60-day Loan were repaid in March 2024.

- removed (2025-05-01):
[0001783180-24-000088:note_history:45]
Delayed Draw Facility

- removed (2025-05-01):
[0001783180-24-000088:note_history:46]
On May 19, 2023, the Company entered into a senior unsecured delayed draw term loan credit agreement with JPMorgan Chase Bank, N.A., as administrative agent and certain other lenders that permits aggregate borrowings of up to €2.3 billion (the "Delayed Draw Facility"). The facility consisted of an 18-month, Euro-denominated tranche in an aggregate amount of €1.15 billion and a 3-year, Euro-denominated tranche in an aggregate amount of €1.15 billion. Euro-denominated borrowings bear interest at the EURIBOR Rate plus a ratings-based margin, USD-denominated borrowings bear interest at either a Term SOFR Rate plus 0.10% and a ratings-based margin or, alternatively, at a base rate plus a ratings-based margin. The Company capitalized $4 million of deferred financing costs which will be amortized over the respective term of the tranches. On January 2, 2024, the Company borrowed the full amount available under the Delayed Draw Facility in U.S. Dollars. Borrowings under the Delayed Draw Facility were repaid in June 2024 and the facility was subsequently terminated.

- removed (2025-05-01):
[0001783180-24-000088:note_history:47]
364-Day Revolver

- removed (2025-05-01):
[0001783180-24-000088:note_history:48]
On May 17, 2024, the Company entered into a 364-day, $500 million, senior unsecured revolving credit agreement with JPMorgan Chase Bank, N.A., as administrative agent and certain other lenders (the “364-day Revolver”). Borrowings are available in U.S. Dollars and Euros. USD-denominated borrowings bear interest at either a Term SOFR Rate plus 0.10% and a ratings-based margin or, alternatively, at a base rate plus a ratings-based margin, Euro-denominated borrowings bear interest at the Adjusted EURIBOR Rate plus a ratings-based margin. Upon entering into the 364-day Revolver, the Company terminated its existing $500 million senior unsecured revolving credit agreement that was set to mature in May 2024. As of September 30, 2024, there were no borrowings outstanding under the 364-day Revolver.

- removed (2025-05-01):
[0001783180-24-000088:note_history:49]
Japanese Term Loan Facility

- removed (2025-05-01):
[0001783180-24-000088:note_history:50]
On July 15, 2022, the Company entered into a five-year, JPY 54 billion (approximately $400 million) senior unsecured term loan facility with MUFG Bank Ltd., as administrative agent and lender, and certain other lenders (the "Japanese Term Loan Facility"). Borrowings under the Japanese Term Loan Facility bear interest at a rate equal to the Tokyo Term Risk Free Rate plus 0.75%. The Company capitalized $2 million of deferred financing costs which are being amortized over its term. On July 25, 2022, the Company borrowed JPY 54 billion under the Japanese Term Loan Facility and used the proceeds to fund a portion of the Yen-denominated purchase price of Toshiba Carrier Corporation ("TCC") and to pay related fees and expenses.

- removed (2025-05-01):
[0001783180-24-000088:note_history:51]
The Revolving Credit Facility, 364-day Revolver, the indenture for the long-term notes and the Japanese Term Loan Facility contain affirmative and negative covenants customary for financings of these types, which, among other things, limit the Company's ability to incur certain liens, to make certain fundamental changes and to enter into sale and leaseback transactions. As of September 30, 2024, the Company was in compliance with the covenants under the agreements governing its outstanding indebtedness.

- removed (2025-05-01):
[0001783180-24-000088:note_history:52]
Tender Offers
In July 2024, the Company commenced tender offers to purchase up to $800 million ("Aggregate Tender Cap") aggregate principal of certain tranches of the Company's notes. The tender offers included payment of applicable accrued and unpaid interest up to the settlement date, along with a fixed spread for early repayment. Based on participation, the Company elected to increase the Aggregate Tender Cap and settle the tender offers early. The aggregate principal amount tendered and accepted was approximately $1.0 billion, which included $125 million of notes due 2034, $350 million of notes due 2054 and approximately $600 million of notes due 2050. Upon settlement, the Company recognized a net gain of $97 million and wrote off $11 million of unamortized deferred financing costs within Interest (expense) income, net on the accompanying Unaudited Condensed Consolidated Statement of Operations.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-05-01):
[0001783180-25-000030:note_history:53]
| (In millions) |  |  |  | March 31,2025 |  | December 31,2024 |
| 2.242% Notes due 2025 (1) |  |  |  | $ | — |  |  | $ | 1,200 |  |
| 2.493% Notes due 2027 |  |  |  | 900 |  |  | 900 |  |
| 4.125% Notes due 2028 |  |  |  | 809 |  |  | 783 |  |
| 2.722% Notes due 2030 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.700% Notes due 2031 |  |  |  | 750 |  |  | 750 |  |
| 4.500% Notes due 2032 |  |  |  | 917 |  |  | 887 |  |
| 5.900% Notes due 2034 |  |  |  | 875 |  |  | 875 |  |
| 3.625% Notes due 2037 |  |  |  | 809 |  |  | 783 |  |
| 3.377% Notes due 2040 |  |  |  | 1,500 |  |  | 1,500 |  |
| 3.577% Notes due 2050 |  |  |  | 1,400 |  |  | 1,400 |  |
| 6.200% Notes due 2054 |  |  |  | 650 |  |  | 650 |  |
| Total long-term notes |  |  |  | 10,610 |  |  | 11,728 |  |
| Japanese Term Loan Facility |  |  |  | 358 |  |  | 342 |  |
| Other debt (including project financing obligations and finance leases) |  |  |  | 302 |  |  | 296 |  |
| Discounts and debt issuance costs |  |  |  | (86) |  |  | (88) |  |
| Total debt |  |  |  | 11,184 |  |  | 12,278 |  |
| Less: current portion of long-term debt |  |  |  | 104 |  |  | 1,252 |  |
| Long-term debt, net of current portion |  |  |  | $ | 11,080 |  |  | $ | 11,026 |  |
  (was, 2024-10-25, similarity 0.9132):
[0001783180-24-000088:note_history:53]
| (In millions) |  |  |  | September 30,2024 |  | December 31,2023 |
| 2.242% Notes due 2025 (1) |  |  |  | $ | 1,200 |  |  | $ | 1,200 |  |
| 4.375% Notes due 2025 (2) |  |  |  | 836 |  |  | 830 |  |
| 5.800% Notes due 2025 |  |  |  | — |  |  | 1,000 |  |
| 2.493% Notes due 2027 |  |  |  | 900 |  |  | 900 |  |
| 4.125% Notes due 2028 |  |  |  | 836 |  |  | 830 |  |
| 2.722% Notes due 2030 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.700% Notes due 2031 |  |  |  | 750 |  |  | 750 |  |
| 4.500% Notes due 2032 |  |  |  | 948 |  |  | 941 |  |
| 5.900% Notes due 2034 |  |  |  | 875 |  |  | 1,000 |  |
| 3.377% Notes due 2040 |  |  |  | 1,500 |  |  | 1,500 |  |
| 3.577% Notes due 2050 |  |  |  | 1,400 |  |  | 2,000 |  |
| 6.200% Notes due 2054 |  |  |  | 650 |  |  | 1,000 |  |
| Total long-term notes |  |  |  | 11,895 |  |  | 13,951 |  |
| Japanese Term Loan Facility |  |  |  | 374 |  |  | 379 |  |
| Other debt (including project financing obligations and finance leases) |  |  |  | 243 |  |  | 74 |  |
| Discounts and debt issuance costs |  |  |  | (80) |  |  | (111) |  |
| Total debt |  |  |  | 12,432 |  |  | 14,293 |  |
| Less: current portion of long-term debt |  |  |  | 2,095 |  |  | 51 |  |
| Long-term debt, net of current portion |  |  |  | $ | 10,337 |  |  | $ | 14,242 |  |

- changed (2025-05-01):
[0001783180-25-000030:note_history:54]
(1) 2.242% Notes due February 15, 2025; repaid during February 2025.
  (was, 2024-10-25, similarity 0.6618):
[0001783180-24-000088:note_history:54]
(1) 2.242% Notes due February 15, 2025; reclassified to Current portion of long-term debt.

- removed (2025-05-01):
[0001783180-24-000088:note_history:55]
(2) 4.375% Notes due May 29, 2025; reclassified to Current portion of long-term debt.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- added (2025-05-01):
[0001783180-25-000030:note_history:56]
|  |  | Three Months Ended March 31, |  |  |
| (In millions) |  | 2025 |  | 2024 |  |  |  |  |
| Sales to equity method investees included in Product sales |  | $ | 780 |  |  | $ | 723 |  |  |  |  |  |
| Purchases from equity method investees included in Cost of products sold |  | $ | 47 |  |  | $ | 55 |  |  |  |  |  |

- added (2025-05-01):
[0001783180-25-000030:note_history:57]
| (In millions) |  | March 31,2025 |  | December 31,2024 |
| Receivables from equity method investees included in Accounts receivable, net |  | $ | 311 |  |  | $ | 363 |  |
| Payables to equity method investees included in Accounts payable |  | $ | 32 |  |  | $ | 32 |  |

- removed (2025-05-01):
[0001783180-24-000088:note_history:58]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
| (In millions) |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Sales to equity method investees included in Product sales |  | $ | 774 |  |  | $ | 730 |  |  | $ | 2,329 |  |  | $ | 2,371 |  |
| Purchases from equity method investees included in Cost of products sold |  | $ | 64 |  |  | $ | 57 |  |  | $ | 178 |  |  | $ | 159 |  |

- removed (2025-05-01):
[0001783180-24-000088:note_history:59]
| (In millions) |  | September 30,2024 |  | December 31,2023 |
| Receivables from equity method investees included in Accounts receivable, net |  | $ | 287 |  |  | $ | 231 |  |
| Payables to equity method investees included in Accounts payable |  | $ | 47 |  |  | $ | 44 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-05-01):
[0001783180-25-000030:note_history:60]
External segment sales disaggregated by product and service are as follows:
  (was, 2024-10-25, similarity 0.8722):
[0001783180-24-000088:note_history:60]
Sales disaggregated by product and service are as follows:

- added (2025-05-01):
[0001783180-25-000030:note_history:61]
|  |  | Three Months Ended March 31, |  |  |
| (In millions) |  | 2025 |  | 2024 |  |  |  |  |
| Sales Type |  |  |  |  |  |  |  |  |
| Product |  | $ | 2,319 |  |  | $ | 2,105 |  |  |  |  |  |
| Service |  | 253 |  |  | 255 |  |  |  |  |  |
| Climate Solutions Americas sales |  | 2,572 |  |  | 2,360 |  |  |  |  |  |
| Product |  | 1,071 |  |  | 1,238 |  |  |  |  |  |
| Service |  | 98 |  |  | 54 |  |  |  |  |  |
| Climate Solutions Europe sales |  | 1,169 |  |  | 1,292 |  |  |  |  |  |
| Product |  | 660 |  |  | 728 |  |  |  |  |  |
| Service |  | 166 |  |  | 156 |  |  |  |  |  |
| Climate Solutions Asia Pacific, Middle East & Africa sales |  | 826 |  |  | 884 |  |  |  |  |  |
| Product |  | 602 |  |  | 772 |  |  |  |  |  |
| Service |  | 49 |  |  | 112 |  |  |  |  |  |
| Climate Solutions Transportation sales |  | 651 |  |  | 884 |  |  |  |  |  |
| Net sales |  | $ | 5,218 |  |  | $ | 5,420 |  |  |  |  |  |

- added (2025-05-01):
[0001783180-25-000030:note_history:62]
Geographic external sales are attributed to the geographic regions based on their location of origin. With the exception of the U.S. presented in the table below, there were no individually significant countries with sales exceeding 10% of total sales during the three months ended March 31, 2025 and 2024.

- added (2025-05-01):
[0001783180-25-000030:note_history:63]
|  |  | Three Months Ended March 31, |  |  |
| (In millions) |  | 2025 |  | 2024 |  |  |  |  |
| United States |  | $ | 2,738 |  |  | $ | 2,547 |  |  |  |  |  |
| International: |  |  |  |  |  |  |  |  |
| Europe |  | 1,401 |  |  | 1,751 |  |  |  |  |  |
| Asia Pacific |  | 941 |  |  | 960 |  |  |  |  |  |
| Other |  | 138 |  |  | 162 |  |  |  |  |  |
| Net sales |  | $ | 5,218 |  |  | $ | 5,420 |  |  |  |  |  |

- removed (2025-05-01):
[0001783180-24-000088:note_history:64]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
| (In millions) |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Sales Type |  |  |  |  |  |  |  |  |
| Product |  | $ | 4,504 |  |  | $ | 3,533 |  |  | $ | 13,045 |  |  | $ | 10,488 |  |
| Service |  | 554 |  |  | 475 |  |  | 1,524 |  |  | 1,358 |  |
| HVAC sales |  | 5,058 |  |  | 4,008 |  |  | 14,569 |  |  | 11,846 |  |
| Product |  | 811 |  |  | 808 |  |  | 2,434 |  |  | 2,453 |  |
| Service |  | 127 |  |  | 116 |  |  | 361 |  |  | 341 |  |
| Refrigeration sales |  | 938 |  |  | 924 |  |  | 2,795 |  |  | 2,794 |  |
| Total segment sales |  | 5,996 |  |  | 4,932 |  |  | 17,364 |  |  | 14,640 |  |
| Eliminations and other (1) |  | (12) |  |  | 3 |  |  | (26) |  |  | (5) |  |
| Net sales |  | $ | 5,984 |  |  | $ | 4,935 |  |  | $ | 17,338 |  |  | $ | 14,635 |  |

- removed (2025-05-01):
[0001783180-24-000088:note_history:65]
(1) Includes certain business activities previously reported in the Fire & Security segment.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-05-01):
[0001783180-25-000030:note_history:66]
External segment sales disaggregated by product and service are as follows:
  (was, 2024-10-25, similarity 0.8722):
[0001783180-24-000088:note_history:66]
Sales disaggregated by product and service are as follows:

- added (2025-05-01):
[0001783180-25-000030:note_history:67]
|  |  | Three Months Ended March 31, |  |  |
| (In millions) |  | 2025 |  | 2024 |  |  |  |  |
| Sales Type |  |  |  |  |  |  |  |  |
| Product |  | $ | 2,319 |  |  | $ | 2,105 |  |  |  |  |  |
| Service |  | 253 |  |  | 255 |  |  |  |  |  |
| Climate Solutions Americas sales |  | 2,572 |  |  | 2,360 |  |  |  |  |  |
| Product |  | 1,071 |  |  | 1,238 |  |  |  |  |  |
| Service |  | 98 |  |  | 54 |  |  |  |  |  |
| Climate Solutions Europe sales |  | 1,169 |  |  | 1,292 |  |  |  |  |  |
| Product |  | 660 |  |  | 728 |  |  |  |  |  |
| Service |  | 166 |  |  | 156 |  |  |  |  |  |
| Climate Solutions Asia Pacific, Middle East & Africa sales |  | 826 |  |  | 884 |  |  |  |  |  |
| Product |  | 602 |  |  | 772 |  |  |  |  |  |
| Service |  | 49 |  |  | 112 |  |  |  |  |  |
| Climate Solutions Transportation sales |  | 651 |  |  | 884 |  |  |  |  |  |
| Net sales |  | $ | 5,218 |  |  | $ | 5,420 |  |  |  |  |  |

- changed (2025-05-01):
[0001783180-25-000030:note_history:68]
| (In millions) |  | March 31,2025 |  | December 31,2024 |
| Contract assets (included within Other current assets) |  | $ | 452 |  |  | $ | 366 |  |
| Contract assets, non-current (included within Other assets) |  | 35 |  |  | 65 |  |
| Total contract assets |  | 487 |  |  | 431 |  |
| Contract liabilities (included within Accrued liabilities) |  | (542) |  |  | (553) |  |
| Contract liabilities, non-current (included within Other long-term liabilities) |  | (168) |  |  | (164) |  |
| Total contract liabilities |  | (710) |  |  | (717) |  |
| Net contract assets (liabilities) |  | $ | (223) |  |  | $ | (286) |  |
  (was, 2024-10-25, similarity 0.9892):
[0001783180-24-000088:note_history:68]
| (In millions) |  | September 30,2024 |  | December 31,2023 |
| Contract assets (included within Other current assets) |  | $ | 367 |  |  | $ | 306 |  |
| Contract assets, non-current (included within Other assets) |  | 55 |  |  | 26 |  |
| Total contract assets |  | 422 |  |  | 332 |  |
| Contract liabilities (included within Accrued liabilities) |  | (563) |  |  | (419) |  |
| Contract liabilities, non-current (included within Other long-term liabilities) |  | (162) |  |  | (160) |  |
| Total contract liabilities |  | (725) |  |  | (579) |  |
| Net contract assets (liabilities) |  | $ | (303) |  |  | $ | (247) |  |

- changed (2025-05-01):
[0001783180-25-000030:note_history:69]
The timing of revenue recognition, billings and cash collections results in contract assets and contract liabilities. Contract assets relate to the conditional right to consideration for any completed performance under a contract when costs are incurred in excess of billings under the percentage-of-completion methodology. Contract liabilities relate to payments received in advance of performance under a contract or when the Company has a right to consideration that is conditioned upon transfer of a good or service to a customer. Contract liabilities are recognized as revenue as (or when) the Company performs under the contract.
The Company recognized revenue of $180 million during the three months ended March 31, 2025, that related to contract liabilities as of January 1, 2025. The Company expects a majority of its current contract liabilities at the end of the period to be recognized as revenue in the next 12 months.
  (was, 2024-10-25, similarity 0.9722):
[0001783180-24-000088:note_history:69]
The timing of revenue recognition, billings and cash collections results in contract assets and contract liabilities. Contract assets relate to the conditional right to consideration for any completed performance under a contract when costs are incurred in excess of billings under the percentage-of-completion methodology. Contract liabilities relate to payments received in advance of performance under a contract or when the Company has a right to consideration that is conditioned upon transfer of a good or service to a customer. Contract liabilities are recognized as revenue as (or when) the Company performs under the contract.
The Company recognized revenue of $401 million during the nine months ended September 30, 2024 that related to contract liabilities as of January 1, 2024. The Company expects a majority of its current contract liabilities at the end of the period to be recognized as revenue in the next 12 months.

- removed (2025-05-01):
[0001783180-24-000088:note_history:70]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
| (In millions) |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Sales Type |  |  |  |  |  |  |  |  |
| Product |  | $ | 4,504 |  |  | $ | 3,533 |  |  | $ | 13,045 |  |  | $ | 10,488 |  |
| Service |  | 554 |  |  | 475 |  |  | 1,524 |  |  | 1,358 |  |
| HVAC sales |  | 5,058 |  |  | 4,008 |  |  | 14,569 |  |  | 11,846 |  |
| Product |  | 811 |  |  | 808 |  |  | 2,434 |  |  | 2,453 |  |
| Service |  | 127 |  |  | 116 |  |  | 361 |  |  | 341 |  |
| Refrigeration sales |  | 938 |  |  | 924 |  |  | 2,795 |  |  | 2,794 |  |
| Total segment sales |  | 5,996 |  |  | 4,932 |  |  | 17,364 |  |  | 14,640 |  |
| Eliminations and other (1) |  | (12) |  |  | 3 |  |  | (26) |  |  | (5) |  |
| Net sales |  | $ | 5,984 |  |  | $ | 4,935 |  |  | $ | 17,338 |  |  | $ | 14,635 |  |

- removed (2025-05-01):
[0001783180-24-000088:note_history:71]
(1) Includes certain business activities previously reported in the Fire & Security segment.
