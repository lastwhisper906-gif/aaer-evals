# CARR notes — 0001783180-22-000056


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001783180-22-000056:notes:1]
[same as prior period, unchanged from 0001783180-22-000048:notes:1]

[0001783180-22-000056:notes:2]
In the opinion of management, the accompanying Unaudited Condensed Consolidated Financial Statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission (the "SEC"). The accompanying Unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for 2021 filed with the SEC on February 8, 2022 (the "2021 Form 10-K").

[0001783180-22-000056:notes:3]
[same as prior period, unchanged from 0001783180-22-000048:notes:3]

[0001783180-22-000056:notes:4]
[same as prior period, unchanged from 0001783180-22-000048:notes:4]


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001783180-22-000056:notes:5]
BASIS OF PRESENTATION
The Unaudited Condensed Consolidated Financial Statements include all accounts of the Company and its wholly-owned and majority-owned subsidiaries in which it has control. All intra-company accounts and transactions have been eliminated. Related party transactions between the Company and its equity method investees have not been eliminated. Non-controlling interest represents a non-controlling investor's interests in the results of subsidiaries that the Company controls and consolidates.

[0001783180-22-000056:notes:6]
Acquisition of Toshiba Carrier Corporation

[0001783180-22-000056:notes:7]
On February 6, 2022, the Company entered into a binding agreement to acquire a majority ownership interest in Toshiba Carrier Corporation (“TCC”), a variable refrigerant flow ("VRF") and light commercial HVAC joint venture between Carrier and Toshiba Corporation. The acquisition was completed on August 1, 2022, subject to customary closing conditions. As a result, the assets, liabilities and results of operations of TCC are consolidated in the accompanying Unaudited Condensed Consolidated Financial Statements as of the date of acquisition and reported within the Company’s HVAC segment. Upon closing, Toshiba Corporation retained a 5% ownership interest in TCC. See Note 15 – Acquisitions for additional information.

[0001783180-22-000056:notes:8]
[same as prior period, unchanged from 0001783180-22-000048:notes:6]

[0001783180-22-000056:notes:9]
[same as prior period, unchanged from 0001783180-22-000048:notes:7]

[0001783180-22-000056:notes:10]
[same as prior period, unchanged from 0001783180-22-000048:notes:8]

[0001783180-22-000056:notes:11]
On April 3, 2020, United Technologies Corporation, since renamed Raytheon Technologies Corporation ("UTC"), completed the spin-off of the Company into an independent, publicly traded company (the "Separation") through a pro-rata distribution (the "Distribution") on a one-for-one basis of all of the outstanding shares of common stock of the Company to UTC shareowners who held shares of UTC common stock as of the close of business on March 19, 2020, the record date of the Distribution. The Company incurred separation-related costs including employee-related costs, costs to establish certain stand-alone functions, information technology systems, professional service fees and other costs associated with becoming an independent, publicly traded company. These costs are primarily recorded in Selling, general and administrative in the accompanying Unaudited Condensed Consolidated Statement of Operations and totaled $19 million for the nine months ended September 30, 2021.

[0001783180-22-000056:notes:12]
[same as prior period, unchanged from 0001783180-22-000048:notes:10]

[0001783180-22-000056:notes:13]
The Financial Accounting Standards Board ("FASB") Accounting Standards Codification ("ASC") is the sole source of authoritative U.S. GAAP other than SEC issued rules and regulations that apply only to SEC registrants. The FASB issues Accounting Standards Updates ("ASU") to communicate changes to the codification. The Company considers the applicability and impact of all ASUs. ASUs pending adoption were assessed and determined to be either not applicable or not expected to have a material impact on the accompanying Unaudited Condensed Consolidated Financial Statements.


## us-gaap:InventoryDisclosureTextBlock

[0001783180-22-000056:notes:14]
[same as prior period, unchanged from 0001783180-22-000048:notes:12]

[0001783180-22-000056:notes:15]
[same as prior period, unchanged from 0001783180-22-000048:notes:13]

[0001783180-22-000056:notes:16]
| (In millions) |  | September 30, 2022 |  | December 31, 2021 |
| Raw materials |  | $ | 822 |  |  | $ | 559 |  |
| Work-in-process |  | 217 |  |  | 197 |  |
| Finished goods |  | 1,625 |  |  | 1,214 |  |
| Inventories, net |  | $ | 2,664 |  |  | $ | 1,970 |  |

[0001783180-22-000056:notes:17]
The Company performs periodic assessments utilizing customer demand, production requirements and historical usage rates to determine the existence of excess and obsolete inventory and records necessary provisions to reduce such inventories to the lower of cost or estimated net realizable value. Raw materials, work-in-process and finished goods are net of valuation reserves of $157 million and $154 million as of September 30, 2022 and December 31, 2021, respectively.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001783180-22-000056:notes:18]
[same as prior period, unchanged from 0001783180-22-000048:notes:16]

[0001783180-22-000056:notes:19]
[same as prior period, unchanged from 0001783180-22-000048:notes:17]

[0001783180-22-000056:notes:20]
| (In millions) |  |  | HVAC |  | Refrigeration |  | Fire & Security |  | Total |
| Balance as of December 31, 2021 |  |  | $ | 5,658 |  |  | $ | 1,228 |  |  | $ | 2,463 |  |  | $ | 9,349 |  |
| Goodwill resulting from business combinations (1) |  |  | 877 |  |  | — |  |  | 1 |  |  | 878 |  |
| Foreign currency translation |  |  | (368) |  |  | (80) |  |  | (158) |  |  | (606) |  |
| Balance as of September 30, 2022 |  |  | $ | 6,167 |  |  | $ | 1,148 |  |  | $ | 2,306 |  |  | $ | 9,621 |  |

[0001783180-22-000056:notes:21]
[same as prior period, unchanged from 0001783180-22-000048:notes:19]

[0001783180-22-000056:notes:22]
Indefinite-lived intangible assets are tested and reviewed annually for impairment on July 1 or whenever there is a material change in events or circumstances that indicates that the fair value of the asset may be less than the carrying amount of the

[0001783180-22-000056:notes:23]
asset. All other intangible assets with finite useful lives are amortized over their estimated useful lives.

[0001783180-22-000056:notes:24]
[same as prior period, unchanged from 0001783180-22-000048:notes:21]

[0001783180-22-000056:notes:25]
|  |  | September 30, 2022 |  | December 31, 2021 |
| (In millions) |  | Gross Amount |  | Accumulated Amortization |  | Net Amount |  | Gross Amount |  | Accumulated Amortization |  | Net Amount |
| Amortized: |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 1,367 |  |  | $ | (691) |  |  | $ | 676 |  |  | $ | 945 |  |  | $ | (699) |  |  | $ | 246 |  |
| Patents and trademarks |  | 380 |  |  | (178) |  |  | 202 |  |  | 232 |  |  | (182) |  |  | 50 |  |
| Service portfolios and other |  | 916 |  |  | (548) |  |  | 368 |  |  | 688 |  |  | (539) |  |  | 149 |  |
|  |  | 2,663 |  |  | (1,417) |  |  | 1,246 |  |  | 1,865 |  |  | (1,420) |  |  | 445 |  |
| Unamortized: |  |  |  |  |  |  |  |  |  |  |  |  |
| Trademarks and other |  | 63 |  |  | — |  |  | 63 |  |  | 64 |  |  | — |  |  | 64 |  |
| Intangible assets, net |  | $ | 2,726 |  |  | $ | (1,417) |  |  | $ | 1,309 |  |  | $ | 1,929 |  |  | $ | (1,420) |  |  | $ | 509 |  |

[0001783180-22-000056:notes:26]
[same as prior period, unchanged from 0001783180-22-000048:notes:23]

[0001783180-22-000056:notes:27]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
| (In millions) |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Amortization expense of Intangible assets |  | $ | 38 |  |  | $ | 25 |  |  | $ | 79 |  |  | $ | 74 |  |

[0001783180-22-000056:notes:28]
Annual Impairment Test

[0001783180-22-000056:notes:29]
The Company tested its goodwill and indefinite-lived intangible assets for impairment as part of its annual assessment. For each test except one, the Company qualitatively assessed all relevant events or circumstances that could impact the estimate of fair value and determined it was more likely than not that the fair value of each reporting unit and indefinite-lived intangible asset exceeded their carrying amount. The test for one reporting unit related to the TCC acquisition and the subsequent reorganization of the Company's Commercial HVAC reporting unit in order to create a separate Global Comfort Solutions reporting unit. As a result, the Company performed a quantitative goodwill impairment test on its Commercial HVAC reporting unit prior to the reorganization, the results of which did not indicate any goodwill impairment. The Company then reassigned goodwill among its Commercial HVAC and new Global Comfort Solutions reporting units using a relative fair value approach and performed a goodwill impairment assessment. The results did not indicate any goodwill impairment.


## us-gaap:DebtDisclosureTextBlock

[0001783180-22-000056:notes:30]
BORROWINGS AND LINES OF CREDIT 
Long-term debt consisted of the following:

[0001783180-22-000056:notes:31]
| (In millions) |  |  |  | September 30,2022 |  | December 31,2021 |
| 2.242% Notes due February 15, 2025 |  |  |  | $ | 1,200 |  |  | $ | 2,000 |  |
| 2.493% Notes due February 15, 2027 |  |  |  | 900 |  |  | 1,250 |  |
| 2.722% Notes due February 15, 2030 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.700% Notes due February 15, 2031 |  |  |  | 750 |  |  | 750 |  |
| 3.377% Notes due April 5, 2040 |  |  |  | 1,500 |  |  | 1,500 |  |
| 3.577% Notes due April 5, 2050 |  |  |  | 2,000 |  |  | 2,000 |  |
| Total long-term Notes |  |  |  | 8,350 |  |  | 9,500 |  |
| Japanese Term Loan Facility |  |  |  | 372 |  |  | — |  |
| Other debt (including project financing obligations and finance leases) |  |  |  | 228 |  |  | 267 |  |
| Discounts and debt issuance costs |  |  |  | (61) |  |  | (71) |  |
| Total debt |  |  |  | 8,889 |  |  | 9,696 |  |
| Less: current portion of long-term debt |  |  |  | 219 |  |  | 183 |  |
| Long-term debt, net of current portion |  |  |  | $ | 8,670 |  |  | $ | 9,513 |  |

[0001783180-22-000056:notes:32]
Japanese Term Loan Facility

[0001783180-22-000056:notes:33]
On July 15, 2022, the Company entered into a five-year, JPY 54 billion (approximately $400 million) senior unsecured term loan facility with MUFG Bank Ltd., as administrative agent and lender, and certain other lenders (the "Japanese Term Loan Facility"). Borrowings under the Japanese Term Loan Facility bear interest at a rate equal to the Tokyo Term Risk Free Rate plus 0.75%. In addition, the Japanese Term Loan Facility is subject to customary covenants including a covenant to maintain a maximum consolidated leverage ratio. On July 25, 2022, the Company borrowed JPY 54 billion under the Japanese Term Loan Facility and used the proceeds to fund a portion of the TCC acquisition and to pay related fees and expenses.

[0001783180-22-000056:notes:34]
Revolving Credit Facility

[0001783180-22-000056:notes:35]
On February 10, 2020, the Company entered into a revolving credit agreement with various banks permitting aggregate borrowings of up to $2.0 billion pursuant to an unsecured, unsubordinated revolving credit facility that matures on April 3, 2025 (the "Revolving Credit Facility"). The Revolving Credit Facility supports the Company's commercial paper program and cash requirements of the Company. A commitment fee of 0.125% is charged on unused commitments. Borrowings under the Revolving Credit Facility are available in U.S. Dollars, Euros and Pounds Sterling and bear interest at a variable interest rate plus a ratings-based margin, which was 125 basis points as of September 30, 2022. As of September 30, 2022, there were no borrowings outstanding under the Revolving Credit Facility.

[0001783180-22-000056:notes:36]
Commercial Paper Program

[0001783180-22-000056:notes:37]
The Company has a $2.0 billion unsecured, unsubordinated commercial paper program, which can be used for general corporate purposes, including the funding of working capital and potential acquisitions. As of September 30, 2022, there were no borrowings outstanding under the commercial paper program.

[0001783180-22-000056:notes:38]
Project Financing Arrangements

[0001783180-22-000056:notes:39]
The Company is involved in long-term construction contracts in which it arranges project financing with certain customers. As a result, the Company issued $27 million and $108 million of debt during the nine months ended September 30, 2022 and 2021, respectively. Long-term debt repayments associated with these financing arrangements during the nine months ended September 30, 2022 and 2021 were $70 million and $170 million, respectively.

[0001783180-22-000056:notes:40]
Debt Covenants

[0001783180-22-000056:notes:41]
The Revolving Credit Facility, the indenture for the long-term Notes and the Japanese Term Loan Facility contain affirmative and negative covenants customary for financings of these types, which, among other things, limit the Company's ability to incur additional liens, to make certain fundamental changes and to enter into sale and leaseback transactions. As of September 30, 2022, the Company was in compliance with the covenants under the agreements governing its outstanding indebtedness.

[0001783180-22-000056:notes:42]
Tender Offers

[0001783180-22-000056:notes:43]
On March 15, 2022, the Company commenced tender offers to purchase up to $1.15 billion ("Aggregate Tender Cap") aggregate principal of the Company's 2.242% Notes due 2025 and 2.493% Notes due 2027 (together, the "Senior Notes"). The tender offers included payment of applicable accrued and unpaid interest up to the settlement date, along with a fixed spread for early repayment. Based on participation, the Company elected to settle the tender offers on March 30, 2022. The aggregate principal amount of Senior Notes validly tendered and accepted was approximately $1.15 billion, which included $800 million of Notes due 2025 and $350 million of Notes due 2027. As a result, the Company recognized a net gain of $33 million and wrote off $5 million of unamortized deferred financing costs within Interest (expense) income, net on the accompanying Unaudited Condensed Consolidated Statement of Operations during the three months ended March 31, 2022.


## us-gaap:FairValueDisclosuresTextBlock

[0001783180-22-000056:notes:44]
[same as prior period, unchanged from 0001783180-22-000048:notes:38]

[0001783180-22-000056:notes:45]
[same as prior period, unchanged from 0001783180-22-000048:notes:39]

[0001783180-22-000056:notes:46]
[same as prior period, unchanged from 0001783180-22-000048:notes:40]

[0001783180-22-000056:notes:47]
[same as prior period, unchanged from 0001783180-22-000048:notes:41]

[0001783180-22-000056:notes:48]
[same as prior period, unchanged from 0001783180-22-000048:notes:42]

[0001783180-22-000056:notes:49]
In the normal course of business, the Company is exposed to certain risks arising from business operations and economic factors, including foreign currency and commodity price risk. These exposures are managed through operational strategies and the use of undesignated hedging contracts. The Company's derivative assets and liabilities are measured at fair value on a recurring basis using internal models based on observable market inputs, such as forward, interest, contract and discount rates with changes in fair value reported in earnings in the accompanying Unaudited Condensed Consolidated Statement of Operations.

[0001783180-22-000056:notes:50]
In connection with the TCC acquisition, the Company funded a portion of the Yen-denominated purchase price with cash on hand by entering into cross currency swaps with SMBC Capital Markets, Inc. as syndication swap arranger, and certain other financial institutions. The fair value of the cross currency swaps are measured at fair value on a recurring basis using observable market inputs, such as forward, discount and interest rates as well as credit default swap spreads. The Company designated the cross currency swaps as a partial hedge of its investment in certain subsidiaries whose functional currency is the Japanese Yen in order to manage foreign currency translation risk. As a result, changes in the fair value of the swaps are recorded in Equity in the accompanying Unaudited Condensed Consolidated Balance Sheet.

[0001783180-22-000056:notes:51]
The remaining portion of the Yen-denominated purchase price was funded by the Japanese Term Loan Facility. The carrying value of the facility is translated on a recurring basis using the exchange rate at the end of the applicable period and approximates its fair value. The Company designated the Japanese Term Loan Facility as a partial hedge of its investment in certain subsidiaries whose functional currency is the Japanese Yen in order to manage foreign currency translation risk. As a result, changes in the carrying value of the Japanese Term Loan Facility associated with foreign exchange rate movements are recorded in Equity in the Unaudited Condensed Consolidated Balance Sheet.

[0001783180-22-000056:notes:52]
The following tables provide the valuation hierarchy classification of assets and liabilities that are recorded at fair value and measured on a recurring basis in the accompanying Unaudited Condensed Consolidated Balance Sheet:

[0001783180-22-000056:notes:53]
| (In millions) |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |
| September 30, 2022 |  |  |  |  |  |  |  |  |
| Derivative assets (1)(3) |  | $ | 26 |  |  | $ | — |  |  | $ | 26 |  |  | $ | — |  |
| Derivative liabilities (2)(3) |  | $ | (89) |  |  | $ | — |  |  | $ | (89) |  |  | $ | — |  |
| December 31, 2021 |  |  |  |  |  |  |  |  |
| Derivative assets (1) |  | $ | 8 |  |  | $ | — |  |  | $ | 8 |  |  | $ | — |  |
| Derivative liabilities (2) |  | $ | (35) |  |  | $ | — |  |  | $ | (35) |  |  | $ | — |  |

[0001783180-22-000056:notes:54]
[same as prior period, unchanged from 0001783180-22-000048:notes:47]

[0001783180-22-000056:notes:55]
[same as prior period, unchanged from 0001783180-22-000048:notes:48]

[0001783180-22-000056:notes:56]
(3) Includes cross currency swaps.

[0001783180-22-000056:notes:57]
The following table provides the carrying amounts and fair values of the Company's long-term notes that are not recorded at fair value in the accompanying Unaudited Condensed Consolidated Balance Sheet:

[0001783180-22-000056:notes:58]
|  |  | September 30, 2022 |  | December 31, 2021 |  |
| (In millions) |  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  |
| Total long-term Notes (1) |  | $ | 8,350 |  |  | $ | 6,642 |  |  | $ | 9,500 |  |  | $ | 9,842 |  |  |

[0001783180-22-000056:notes:59]
[same as prior period, unchanged from 0001783180-22-000048:notes:51]

[0001783180-22-000056:notes:60]
[same as prior period, unchanged from 0001783180-22-000048:notes:52]


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0001783180-22-000056:notes:61]
The remaining portion of the Yen-denominated purchase price was funded by the Japanese Term Loan Facility. The carrying value of the facility is translated on a recurring basis using the exchange rate at the end of the applicable period and approximates its fair value. The Company designated the Japanese Term Loan Facility as a partial hedge of its investment in certain subsidiaries whose functional currency is the Japanese Yen in order to manage foreign currency translation risk. As a result, changes in the carrying value of the Japanese Term Loan Facility associated with foreign exchange rate movements are recorded in Equity in the Unaudited Condensed Consolidated Balance Sheet.
The fair value of the Company's long-term debt is measured based on observable market inputs which are considered Level 1 within the fair value hierarchy. The carrying value of cash and cash equivalents, accounts receivable, accounts payable and short-term borrowings approximate fair value due to the short-term nature of these accounts and would be classified as Level 1 in the fair value hierarchy. The Company's financing leases and project financing obligations, included in Long-term debt and Current portion of long-term debt on the accompanying Unaudited Condensed Consolidated Balance Sheet, approximate fair value and are classified as Level 3 in the fair value hierarchy.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001783180-22-000056:notes:62]
[same as prior period, unchanged from 0001783180-22-000048:notes:54]

[0001783180-22-000056:notes:63]
[same as prior period, unchanged from 0001783180-22-000048:notes:55]

[0001783180-22-000056:notes:64]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
| (In millions) |  | 2022 (1) |  | 2021 |  | 2022 (1) |  | 2021 |
| Defined benefit plans |  | $ | 4 |  |  | $ | 2 |  |  | $ | 10 |  |  | $ | 29 |  |
| Defined contribution plans |  | $ | 29 |  |  | $ | 30 |  |  | $ | 95 |  |  | $ | 97 |  |
| Multi-employer pension plans |  | $ | 5 |  |  | $ | 5 |  |  | $ | 11 |  |  | $ | 17 |  |

[0001783180-22-000056:notes:65]
[same as prior period, unchanged from 0001783180-22-000048:notes:57]

[0001783180-22-000056:notes:66]
[same as prior period, unchanged from 0001783180-22-000048:notes:58]

[0001783180-22-000056:notes:67]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |  |  |
| (In millions) |  | 2022 (1) |  | 2021 |  | 2022 (1) |  | 2021 |  |  |
| Service cost |  | $ | 5 |  |  | $ | 7 |  |  | $ | 14 |  |  | $ | 21 |  |  |  |
| Interest cost |  | 5 |  |  | 9 |  |  | 13 |  |  | 28 |  |  |  |
| Expected return on plan assets |  | (7) |  |  | (36) |  |  | (20) |  |  | (109) |  |  |  |
| Amortization of prior service credit |  | 1 |  |  | — |  |  | 2 |  |  | 1 |  |  |  |
| Recognized actuarial net (gain) loss |  | 2 |  |  | 8 |  |  | 7 |  |  | 24 |  |  |  |
| Net settlement, curtailment and special termination benefit (gain) loss |  | — |  |  | 4 |  |  | — |  |  | 4 |  |  |  |
| Net periodic pension expense (benefit) |  | $ | 6 |  |  | $ | (8) |  |  | $ | 16 |  |  | $ | (31) |  |  |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001783180-22-000056:notes:68]
[same as prior period, unchanged from 0001783180-22-000048:notes:60]

[0001783180-22-000056:notes:69]
[same as prior period, unchanged from 0001783180-22-000048:notes:61]

[0001783180-22-000056:notes:70]
[same as prior period, unchanged from 0001783180-22-000048:notes:62]

[0001783180-22-000056:notes:71]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
| (In millions) |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Equity compensation costs - equity settled |  | $ | 17 |  |  | $ | 21 |  |  | $ | 58 |  |  | $ | 60 |  |
| Equity compensation costs - cash settled (1) |  | 1 |  |  | 5 |  |  | (16) |  |  | 15 |  |
| Total stock-based compensation expense |  | $ | 18 |  |  | $ | 26 |  |  | $ | 42 |  |  | $ | 75 |  |

[0001783180-22-000056:notes:72]
[same as prior period, unchanged from 0001783180-22-000048:notes:64]


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001783180-22-000056:notes:73]
PRODUCT WARRANTIESIn the ordinary course of business, the Company provides standard warranty coverage on its products. Provisions for these amounts are established at the time of sale and estimated primarily based on product warranty terms and historical claims experience. In addition, the Company incurs discretionary costs to service its products in connection with specific product performance issues. Provisions for these amounts are established when they are known and estimable. The Company assesses the adequacy of its initial provisions and will make adjustments as necessary based on known or anticipated claims or as new information becomes available that suggests it is probable that future costs will be different than estimated amounts. Amounts associated with these provisions are classified on the accompanying Unaudited Condensed Consolidated Balance Sheet as Accrued liabilities or Other long-term liabilities based on their anticipated settlement date.
The changes in the carrying amount of warranty related provisions are as follows:

[0001783180-22-000056:notes:74]
|  |  | Nine Months Ended September 30, |
| (In millions) |  | 2022 |  | 2021 |
| Balance as of January 1, |  | $ | 524 |  |  | $ | 514 |  |
| Warranties, performance guarantees issued and changes in estimated liability |  | 120 |  |  | 136 |  |
| Settlements made |  | (116) |  |  | (127) |  |
| Other |  | 9 |  |  | 1 |  |
| Balance as of September 30, |  | $ | 537 |  |  | $ | 524 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001783180-22-000056:notes:75]
EQUITY 
The authorized number of shares of common stock of Carrier is 4,000,000,000 shares of $0.01 par value. As of September 30, 2022 and December 31, 2021, 875,413,836 and 873,064,219 shares of common stock were issued, respectively, which includes 39,237,430 and 10,375,654 shares of treasury stock, respectively.

[0001783180-22-000056:notes:76]
[same as prior period, unchanged from 0001783180-22-000048:notes:69]

[0001783180-22-000056:notes:77]
[same as prior period, unchanged from 0001783180-22-000048:notes:70]

[0001783180-22-000056:notes:78]
[same as prior period, unchanged from 0001783180-22-000048:notes:71]

[0001783180-22-000056:notes:79]
During the nine months ended September 30, 2022, the Company repurchased 28.9 million shares of common stock for an aggregate purchase price of $1.3 billion, which includes shares repurchased under the ASR Agreement. As of September 30, 2022, the Company has approximately $309 million remaining under the current authorization. In October 2022, the Company's Board of Directors approved a $2.0 billion increase to the Company's existing share repurchase program.

[0001783180-22-000056:notes:80]
[same as prior period, unchanged from 0001783180-22-000048:notes:73]

[0001783180-22-000056:notes:81]
A summary of changes in the components of Accumulated other comprehensive income (loss) for the three and nine months ended September 30, 2022 is as follows:

[0001783180-22-000056:notes:82]
| (In millions) |  | Foreign Currency Translation |  | Defined Benefit Pension and Post-retirement Plans |  |  |  |  |  | Accumulated Other Comprehensive Income (Loss) |
| Balance as of December 31, 2021 |  | $ | (505) |  |  | $ | (484) |  |  |  |  |  |  | $ | (989) |  |
| Other comprehensive income (loss) before reclassifications, net |  | (61) |  |  | (4) |  |  |  |  |  |  | (65) |  |
| Amounts reclassified, pre-tax |  | — |  |  | 3 |  |  |  |  |  |  | 3 |  |
| Tax expense (benefit) reclassified |  | — |  |  | (1) |  |  |  |  |  |  | (1) |  |
| Divestitures, net |  | (574) |  |  | 329 |  |  |  |  |  |  | (245) |  |
| Balance as of March 31, 2022 |  | $ | (1,140) |  |  | $ | (157) |  |  |  |  |  |  | $ | (1,297) |  |
| Other comprehensive income (loss) before reclassifications, net |  | (480) |  |  | — |  |  |  |  |  |  | (480) |  |
| Amounts reclassified, pre-tax |  | — |  |  | 3 |  |  |  |  |  |  | 3 |  |
| Tax expense (benefit) reclassified |  | — |  |  | (1) |  |  |  |  |  |  | (1) |  |
| Balance as of June 30, 2022 |  | $ | (1,620) |  |  | $ | (155) |  |  |  |  |  |  | $ | (1,775) |  |
| Other comprehensive income (loss) before reclassifications, net |  | (632) |  |  | — |  |  |  |  |  |  | (632) |  |
| Amounts reclassified, pre-tax |  | — |  |  | 3 |  |  |  |  |  |  | 3 |  |
| Tax expense (benefit) reclassified |  | — |  |  | (1) |  |  |  |  |  |  | (1) |  |
| Balance as of September 30, 2022 |  | $ | (2,252) |  |  | $ | (153) |  |  |  |  |  |  | $ | (2,405) |  |

[0001783180-22-000056:notes:83]
A summary of changes in the components of Accumulated other comprehensive income (loss) for the three and nine months ended September 30, 2021 is as follows:

[0001783180-22-000056:notes:84]
| (In millions) |  | Foreign Currency Translation |  | Defined Benefit Pension and Post-retirement Plans |  |  |  |  |  | Accumulated Other Comprehensive Income (Loss) |
| Balance as of December 31, 2020 |  | $ | (191) |  |  | $ | (554) |  |  |  |  |  |  | $ | (745) |  |
| Other comprehensive income (loss) before reclassifications, net |  | (121) |  |  | — |  |  |  |  |  |  | (121) |  |
| Amounts reclassified, pre-tax |  | — |  |  | 9 |  |  |  |  |  |  | 9 |  |
| Tax expense (benefit) reclassified |  | — |  |  | (2) |  |  |  |  |  |  | (2) |  |
| Balance as of March 31, 2021 |  | $ | (312) |  |  | $ | (547) |  |  |  |  |  |  | $ | (859) |  |
| Other comprehensive income (loss) before reclassifications, net |  | 59 |  |  | — |  |  |  |  |  |  | 59 |  |
| Amounts reclassified, pre-tax |  | — |  |  | 8 |  |  |  |  |  |  | 8 |  |
| Tax expense (benefit) reclassified |  | — |  |  | (2) |  |  |  |  |  |  | (2) |  |
| Balance as of June 30, 2021 |  | $ | (253) |  |  | $ | (541) |  |  |  |  |  |  | $ | (794) |  |
| Other comprehensive income (loss) before reclassifications, net |  | (203) |  |  | — |  |  |  |  |  |  | (203) |  |
| Amounts reclassified, pre-tax |  | — |  |  | 8 |  |  |  |  |  |  | 8 |  |
| Tax expense (benefit) reclassified |  | — |  |  | (2) |  |  |  |  |  |  | (2) |  |
| Balance as of September 30, 2021 |  | $ | (456) |  |  | $ | (535) |  |  |  |  |  |  | $ | (991) |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001783180-22-000056:notes:85]
REVENUE RECOGNITION The Company accounts for revenue in accordance with ASC 606: Revenue from Contracts with Customers. Revenue is recognized when control of a good or service promised in a contract (i.e., performance obligation) is transferred to a customer. Control is obtained when a customer has the ability to direct the use of and obtain substantially all of the remaining benefits from that good or service. A significant portion of the Company's performance obligations are recognized at a point-in-time when control of the product transfers to the customer, which is generally at the time of shipment. The remaining portion of the Company’s performance obligations are recognized over time as the customer simultaneously obtains control as the Company 
performs work under a contract, or if the product being produced for the customer has no alternative use and the Company has a contractual right to payment.

[0001783180-22-000056:notes:86]
[same as prior period, unchanged from 0001783180-22-000048:notes:78]

[0001783180-22-000056:notes:87]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
| (In millions) |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Sales Type |  |  |  |  |  |  |  |  |
| Product |  | $ | 3,330 |  |  | $ | 2,702 |  |  | $ | 8,974 |  |  | $ | 7,606 |  |
| Service |  | 404 |  |  | 352 |  |  | 1,118 |  |  | 1,054 |  |
| HVAC sales |  | 3,734 |  |  | 3,054 |  |  | 10,092 |  |  | 8,660 |  |
| Product |  | 811 |  |  | 894 |  |  | 2,603 |  |  | 2,701 |  |
| Service |  | 112 |  |  | 117 |  |  | 337 |  |  | 336 |  |
| Refrigeration sales |  | 923 |  |  | 1,011 |  |  | 2,940 |  |  | 3,037 |  |
| Product |  | 859 |  |  | 1,012 |  |  | 2,468 |  |  | 2,943 |  |
| Service |  | 46 |  |  | 365 |  |  | 142 |  |  | 1,141 |  |
| Fire & Security sales |  | 905 |  |  | 1,377 |  |  | 2,610 |  |  | 4,084 |  |
| Total segment sales |  | 5,562 |  |  | 5,442 |  |  | 15,642 |  |  | 15,781 |  |
| Eliminations and other |  | (111) |  |  | (101) |  |  | (326) |  |  | (301) |  |
| Net sales |  | $ | 5,451 |  |  | $ | 5,341 |  |  | $ | 15,316 |  |  | $ | 15,480 |  |

[0001783180-22-000056:notes:88]
[same as prior period, unchanged from 0001783180-22-000048:notes:80]

[0001783180-22-000056:notes:89]
[same as prior period, unchanged from 0001783180-22-000048:notes:81]

[0001783180-22-000056:notes:90]
| (In millions) |  | September 30, 2022 |  | December 31, 2021 |
| Contract assets, current |  | $ | 666 |  |  | $ | 503 |  |
| Contract assets, non-current (included within Other assets) |  | 7 |  |  | 70 |  |
| Total contract assets |  | 673 |  |  | 573 |  |
| Contract liabilities, current |  | (440) |  |  | (415) |  |
| Contract liabilities, non-current (included within Other long-term liabilities) |  | (167) |  |  | (165) |  |
| Total contract liabilities |  | (607) |  |  | (580) |  |
| Net contract assets |  | $ | 66 |  |  | $ | (7) |  |

[0001783180-22-000056:notes:91]
The timing of revenue recognition, billings and cash collections results in contract assets and contract liabilities. Contract assets relate to the conditional right to consideration for any completed performance under a contract when costs are incurred in excess of billings under the percentage-of-completion methodology. Contract liabilities relate to payments received in advance of performance under a contract or when the Company has a right to consideration that is conditioned upon transfer of a good or service to a customer. Contract liabilities are recognized as revenue as (or when) the Company performs under the contract. 
The Company recognized revenue of $289 million during the nine months ended September 30, 2022 that related to contract liabilities as of January 1, 2022. The Company expects a majority of its current contract liabilities at the end of the period to be recognized as revenue in the next 12 months.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0001783180-22-000056:notes:92]
The Company accounts for revenue in accordance with ASC 606: Revenue from Contracts with Customers. Revenue is recognized when control of a good or service promised in a contract (i.e., performance obligation) is transferred to a customer. Control is obtained when a customer has the ability to direct the use of and obtain substantially all of the remaining benefits from that good or service. A significant portion of the Company's performance obligations are recognized at a point-in-time when control of the product transfers to the customer, which is generally at the time of shipment. The remaining portion of the Company’s performance obligations are recognized over time as the customer simultaneously obtains control as the Company performs work under a contract, or if the product being produced for the customer has no alternative use and the Company has a contractual right to payment.The timing of revenue recognition, billings and cash collections results in contract assets and contract liabilities. Contract assets relate to the conditional right to consideration for any completed performance under a contract when costs are incurred in excess of billings under the percentage-of-completion methodology. Contract liabilities relate to payments received in advance of performance under a contract or when the Company has a right to consideration that is conditioned upon transfer of a good or service to a customer. Contract liabilities are recognized as revenue as (or when) the Company performs under the contract.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001783180-22-000056:notes:93]
[same as prior period, unchanged from 0001783180-22-000048:notes:85]

[0001783180-22-000056:notes:94]
[same as prior period, unchanged from 0001783180-22-000048:notes:86]

[0001783180-22-000056:notes:95]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
| (In millions) | 2022 |  | 2021 |  | 2022 |  | 2021 |
| HVAC | $ | 2 |  |  | $ | 7 |  |  | $ | 8 |  |  | $ | 18 |  |
| Refrigeration | 3 |  |  | 2 |  |  | 9 |  |  | 7 |  |
| Fire & Security | 1 |  |  | 3 |  |  | 10 |  |  | 23 |  |
| Total Segment | 6 |  |  | 12 |  |  | 27 |  |  | 48 |  |
| General corporate expenses | — |  |  | 1 |  |  | 2 |  |  | 4 |  |
| Total restructuring costs | $ | 6 |  |  | $ | 13 |  |  | $ | 29 |  |  | $ | 52 |  |
| Cost of sales | $ | 1 |  |  | $ | 7 |  |  | $ | 8 |  |  | $ | 18 |  |
| Selling, general and administrative | 5 |  |  | 6 |  |  | 21 |  |  | 34 |  |
| Total restructuring costs | $ | 6 |  |  | $ | 13 |  |  | $ | 29 |  |  | $ | 52 |  |

[0001783180-22-000056:notes:96]
[same as prior period, unchanged from 0001783180-22-000048:notes:88]

[0001783180-22-000056:notes:97]
|  |  | Nine Months Ended September 30, |
| (In millions) |  | 2022 |  | 2021 |
| Balance as of January 1, |  | $ | 54 |  |  | $ | 49 |  |
| Net pre-tax restructuring costs |  | 29 |  |  | 52 |  |
| Utilization, foreign exchange and other |  | (50) |  |  | (54) |  |
| Reclassified as Liabilities held for sale (1) |  | — |  |  | (14) |  |
| Balance as of September 30, |  | $ | 33 |  |  | $ | 33 |  |

[0001783180-22-000056:notes:98]
During the nine months ended September 30, 2022 and 2021, charges associated with restructuring initiatives related to cost reduction efforts. Amounts recognized primarily related to severance due to workforce reductions and exit costs due to the consolidation of field operations. As of September 30, 2022, the Company had $33 million accrued for costs associated with its announced restructuring initiatives, all of which is expected to be paid within one year.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001783180-22-000056:notes:99]
INCOME TAXES
The Company accounts for income tax expense in accordance with ASC 740, Income Taxes ("ASC 740"), which requires an estimate of the annual effective income tax rate for the full year to be applied to the respective interim period, taking into account year-to-date amounts and projected results for the full year. The effective tax rate was 9.4% for the three months ended September 30, 2022 compared with 37.5% for the three months ended September 30, 2021. The year-over-year decrease was primarily driven by a lower effective tax rate on a $732 million non-cash gain resulting from the recognition of the Company's previously held TCC equity investments at fair value upon acquisition of TCC compared with the Company's U.S. statutory tax rate. In addition, the prior year included a net tax charge of $136 million primarily relating to the re-organizations and disentanglement of certain Chubb subsidiaries executed in advance of the planned divestiture of the Chubb business.

[0001783180-22-000056:notes:100]
The effective tax rate was 15.6% for the nine months ended September 30, 2022 compared with 31.4% for the nine months ended September 30, 2021. The year-over-year decrease was primarily driven by a lower effective tax rate on a $732 million non-cash gain resulting from the recognition of the Company's previously held TCC equity investments at fair value upon acquisition of TCC and the $1.1 billion Chubb gain compared with the Company's U.S. statutory rate. The nine months ended September 30, 2021 included a net tax charge of $136 million primarily relating to the re-organizations and disentanglement of certain Chubb subsidiaries executed in advance of the planned divestiture of the Chubb business, and a $43 million deferred tax charge associated with a tax rate increase in the United Kingdom enacted on June 10, 2021 with an effective date of April 2023. These amounts were partially offset by the recognition of a favorable tax adjustment of $21 million resulting from the re-organization of a German subsidiary.

[0001783180-22-000056:notes:101]
[same as prior period, unchanged from 0001783180-22-000048:notes:93]

[0001783180-22-000056:notes:102]
[same as prior period, unchanged from 0001783180-22-000048:notes:94]

[0001783180-22-000056:notes:103]
[same as prior period, unchanged from 0001783180-22-000048:notes:95]


## us-gaap:EarningsPerShareTextBlock

[0001783180-22-000056:notes:104]
EARNINGS PER SHARE Earnings per share is computed by dividing Net income attributable to common shareowners by the weighted-average number of shares of common stock outstanding during the period (excluding treasury stock). Diluted earnings per share is computed by giving effect to all potentially dilutive stock awards that are outstanding. The computation of diluted earnings per share excludes the effect of the potential exercise of stock-based awards, including stock appreciation rights and stock options, when the effect of the potential exercise would be anti-dilutive.
The following table summarizes the weighted-average number of shares of common stock outstanding for basic and diluted earnings per share calculations:

[0001783180-22-000056:notes:105]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
| (In millions, except per share amounts) |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Net income attributable to common shareowners |  | $ | 1,312 |  |  | $ | 469 |  |  | $ | 3,264 |  |  | $ | 1,340 |  |
| Basic weighted-average number of shares outstanding |  | 839.6 |  |  | 867.6 |  |  | 846.1 |  |  | 868.6 |  |
| Stock awards and equity units (share equivalent) |  | 16.9 |  |  | 24.4 |  |  | 18.2 |  |  | 22.3 |  |
| Diluted weighted-average number of shares outstanding |  | 856.5 |  |  | 892.0 |  |  | 864.3 |  |  | 890.9 |  |
| Antidilutive shares excluded from computation of diluted earnings per share |  | 4.5 |  |  | 0.2 |  |  | 3.1 |  |  | 0.2 |  |
| Earnings Per Share |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.56 |  |  | $ | 0.54 |  |  | $ | 3.86 |  |  | $ | 1.54 |  |
| Diluted |  | $ | 1.53 |  |  | $ | 0.53 |  |  | $ | 3.78 |  |  | $ | 1.50 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001783180-22-000056:notes:106]
ACQUISITIONS
Acquisitions are recorded using the acquisition method of accounting in accordance with ASC 805, Business Combinations. As a result, the aggregate purchase price has been allocated to assets acquired and liabilities assumed based on the estimate of fair market value of such assets and liabilities at the date of acquisition.

[0001783180-22-000056:notes:107]
Toshiba Carrier Corporation

[0001783180-22-000056:notes:108]
On February 6, 2022, the Company entered into a binding agreement to acquire a majority ownership interest in TCC for $891 million. TCC, a VRF and light commercial HVAC joint venture between Carrier and Toshiba Corporation, designs and manufactures flexible, energy-efficient and high-performance VRF and light commercial HVAC systems as well as commercial products, compressors and heat pumps. The acquisition included all of TCC’s advanced research and development centers and global manufacturing operations, product pipeline and the long-term use of Toshiba’s iconic brand. The acquisition was completed on August 1, 2022, subject to customary closing conditions and funded through the Japanese Term Loan Facility as well as with cash on hand. Upon closing, Toshiba Corporation retained a 5% ownership interest in TCC.

[0001783180-22-000056:notes:109]
The preliminary allocation of the purchase price is as follows:

[0001783180-22-000056:notes:110]
| (In millions) |  | August 1, 2022 |
| Cash and cash equivalents |  | $ | 462 |  |
| Accounts receivable |  | 393 |  |
| Inventories |  | 373 |  |
| Other assets, current |  | 74 |  |
| Fixed assets |  | 294 |  |
| Intangible assets |  | 965 |  |
| Goodwill |  | 866 |  |
| Other assets |  | 287 |  |
| Accounts payable |  | (412) |  |
| Accrued liabilities |  | (445) |  |
| Contract liabilities, current |  | (21) |  |
| Other long-term liabilities |  | (496) |  |
| Net assets acquired |  | $ | 2,340 |  |
| Less: Fair value of non-controlling interests |  | (22) |  |
| Less: Fair value of previously held TCC equity investments |  | (1,427) |  |
| Total cash consideration |  | $ | 891 |  |

[0001783180-22-000056:notes:111]
The excess purchase price over the estimated fair value of the net assets acquired was recognized as goodwill and totaled $866 million, which is not deductible for tax purposes. Accounts receivable and current liabilities were stated at their historical carrying value, which approximates fair value given the short-term nature of these assets and liabilities. The estimate of fair value for inventory and fixed assets was based on an assessment of the acquired assets' condition as well as an evaluation of the current market value of such assets.

[0001783180-22-000056:notes:112]
The Company recorded intangible assets based on its preliminary estimate of fair value which consisted of the following:

[0001783180-22-000056:notes:113]
| (In millions) | Estimated Useful Life (in years) |  | Intangible Assets Acquired |
| Customer relationships | 23 |  | $ | 497 |  |
| Technology | 7 |  | 220 |  |
| Trademark | 26 |  | 180 |  |
| Backlog | 1 |  | 60 |  |
| Land use rights | 45 |  | 8 |  |
| Total intangible assets acquired |  |  | $ | 965 |  |

[0001783180-22-000056:notes:114]
The valuation of intangible assets was determined using an income approach methodology including the multi-period excess earnings method and the relief from royalty method. Key assumptions used in estimating future cash flows included projected revenue growth rates, profit margins, discount rates, customer attrition rates and royalty rates among others. The projected future cash flows are discounted to present value using an appropriate discount rate. As of September 30, 2022, the Company has not finalized the process of allocating TCC's purchase price and valuing the acquired assets and liabilities.

[0001783180-22-000056:notes:115]
The Company previously accounted for its minority ownership in TCC under the equity method of accounting. In connection with the transaction, the carrying value of the Company's previously held TCC equity investments were recognized at fair value at the date of acquisition using an income approach methodology. As a result, the Company recognized a $732 million non-cash gain within Other income (expense), net on the accompanying Unaudited Condensed Consolidated Statement of Operations. In addition, the assets, liabilities and results of operations of TCC are consolidated in the accompanying Unaudited Condensed Consolidated Financial Statements as of the date of acquisition and reported within the Company's HVAC segment. During the

[0001783180-22-000056:notes:116]
nine months ended September 30, 2022, the Company incurred $25 million of acquisition-related costs which are included within Selling, general and administrative on the accompanying Unaudited Condensed Consolidated Statement of Operations. The Company has not included pro forma financial information required under ASC 805 as the pro forma impact was not significant.

[0001783180-22-000056:notes:117]
Other Acquisitions

[0001783180-22-000056:notes:118]
During the nine months ended September 30, 2022, the Company acquired other consolidated businesses and minority-owned businesses. The aggregate cash paid, net of cash acquired, totaled $43 million and was funded through cash on hand. The excess purchase price over the estimated fair value of net assets acquired during the nine months ended September 30, 2022 was recognized as goodwill and totaled $12 million.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001783180-22-000056:notes:119]
[same as prior period, unchanged from 0001783180-22-000048:notes:102]

[0001783180-22-000056:notes:120]
[same as prior period, unchanged from 0001783180-22-000048:notes:103]

[0001783180-22-000056:notes:121]
[same as prior period, unchanged from 0001783180-22-000048:notes:104]

[0001783180-22-000056:notes:122]
[same as prior period, unchanged from 0001783180-22-000048:notes:105]

[0001783180-22-000056:notes:123]
The sale agreement included several customary provisions to settle working capital and other transaction-related items as of the date of sale. During the three months ended September 30, 2022, the parties finalized these amounts in accordance with the terms of the sale agreement. As a result, the Company recorded an accrual of $7 million and a corresponding reduction to the net gain on sale, which is included in Other income (expense), net on the accompanying Unaudited Condensed Consolidated Statement of Operations. Payment is expected to be made to APi in the fourth quarter of 2022.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001783180-22-000056:notes:124]
[same as prior period, unchanged from 0001783180-22-000048:notes:107]

[0001783180-22-000056:notes:125]
[same as prior period, unchanged from 0001783180-22-000048:notes:108]

[0001783180-22-000056:notes:126]
[same as prior period, unchanged from 0001783180-22-000048:notes:109]

[0001783180-22-000056:notes:127]
[same as prior period, unchanged from 0001783180-22-000048:notes:110]

[0001783180-22-000056:notes:128]
[same as prior period, unchanged from 0001783180-22-000048:notes:111]

[0001783180-22-000056:notes:129]
[same as prior period, unchanged from 0001783180-22-000048:notes:112]

[0001783180-22-000056:notes:130]
|  |  | Net Sales |  | Operating Profit |
|  |  | Three Months Ended September 30, |  | Three Months Ended September 30, |
| (In millions) |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| HVAC |  | $ | 3,734 |  |  | $ | 3,054 |  |  | $ | 1,314 |  |  | $ | 573 |  |
| Refrigeration |  | 923 |  |  | 1,011 |  |  | 116 |  |  | 119 |  |
| Fire & Security |  | 905 |  |  | 1,377 |  |  | 142 |  |  | 182 |  |
| Total segment |  | 5,562 |  |  | 5,442 |  |  | 1,572 |  |  | 874 |  |
| Eliminations and other |  | (111) |  |  | (101) |  |  | (10) |  |  | (10) |  |
| General corporate expenses |  | — |  |  | — |  |  | (36) |  |  | (36) |  |
| Total Consolidated |  | $ | 5,451 |  |  | $ | 5,341 |  |  | $ | 1,526 |  |  | $ | 828 |  |

[0001783180-22-000056:notes:131]
|  |  | Net Sales |  | Operating Profit |
|  |  | Nine Months Ended September 30, |  | Nine Months Ended September 30, |
| (In millions) |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| HVAC |  | $ | 10,092 |  |  | $ | 8,660 |  |  | $ | 2,369 |  |  | $ | 1,511 |  |
| Refrigeration |  | 2,940 |  |  | 3,037 |  |  | 370 |  |  | 369 |  |
| Fire & Security |  | 2,610 |  |  | 4,084 |  |  | 1,494 |  |  | 480 |  |
| Total segment |  | 15,642 |  |  | 15,781 |  |  | 4,233 |  |  | 2,360 |  |
| Eliminations and other |  | (326) |  |  | (301) |  |  | (50) |  |  | (73) |  |
| General corporate expenses |  | — |  |  | — |  |  | (101) |  |  | (105) |  |
| Total Consolidated |  | $ | 15,316 |  |  | $ | 15,480 |  |  | $ | 4,082 |  |  | $ | 2,182 |  |

[0001783180-22-000056:notes:132]
Geographic external sales are attributed to the geographic regions based on their location of origin. With the exception of the U.S. presented in the table below, there were no individually significant countries with sales exceeding 10% of total sales during the nine months ended September 30, 2022 and 2021.

[0001783180-22-000056:notes:133]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
| (In millions) |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| United States |  | $ | 3,154 |  |  | $ | 2,832 |  |  | $ | 9,109 |  |  | $ | 8,033 |  |
| International: |  |  |  |  |  |  |  |  |
| Europe |  | 1,024 |  |  | 1,416 |  |  | 3,188 |  |  | 4,273 |  |
| Asia Pacific |  | 1,071 |  |  | 869 |  |  | 2,436 |  |  | 2,518 |  |
| Other |  | 202 |  |  | 224 |  |  | 583 |  |  | 656 |  |
| Net sales |  | $ | 5,451 |  |  | $ | 5,341 |  |  | $ | 15,316 |  |  | $ | 15,480 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001783180-22-000056:notes:134]
RELATED PARTIES 
Equity Method Investments

[0001783180-22-000056:notes:135]
The Company sells products to and purchases products from unconsolidated entities accounted for under the equity method and, therefore, these entities are considered to be related parties. Amounts attributable to equity method investees are as follows:

[0001783180-22-000056:notes:136]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
| (In millions) |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Sales to equity method investees included in Product sales |  | $ | 718 |  |  | $ | 556 |  |  | $ | 2,129 |  |  | $ | 1,675 |  |
| Purchases from equity method investees included in Cost of products sold |  | $ | 60 |  |  | $ | 93 |  |  | $ | 261 |  |  | $ | 266 |  |

[0001783180-22-000056:notes:137]
The Company had receivables from and payables to equity method investees as follows:

[0001783180-22-000056:notes:138]
| (In millions) |  | September 30,2022 |  | December 31, 2021 |
| Receivables from equity method investees included in Accounts receivable, net |  | $ | 307 |  |  | $ | 150 |  |
| Payables to equity method investees included in Accounts payable |  | $ | 33 |  |  | $ | 51 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001783180-22-000056:notes:139]
COMMITMENTS AND CONTINGENT LIABILITIES
The Company is involved in various litigation, claims and administrative proceedings, including those related to environmental (including asbestos) and legal matters. In accordance with ASC 450, Contingencies, the Company records accruals for loss contingencies when it is probable that a liability will be incurred and the amount of the loss can be reasonably estimated. These accruals are generally based upon a range of possible outcomes. If no amount within the range is a better estimate than any other, the Company accrues the minimum amount. In addition, these estimates are reviewed periodically and adjusted to reflect additional information when it becomes available. The Company is unable to predict the final outcome of the following matters based on the information currently available, except as otherwise noted. However, the Company does not believe that the resolution of any of these matters will have a material adverse effect upon the Company's competitive position, results of operations, cash flows or financial condition.

[0001783180-22-000056:notes:140]
Environmental Matters

[0001783180-22-000056:notes:141]
The Company’s operations are subject to environmental regulation by various authorities. The Company has accrued for the costs of environmental remediation activities, including but not limited to investigatory, remediation, operating and maintenance costs and performance guarantees. The most likely cost to be incurred is accrued based on an evaluation of currently available facts with respect to individual sites, including technology required to remediate, current laws and regulations and prior remediation experience.

[0001783180-22-000056:notes:142]
The outstanding liabilities for environmental obligations are as follows:

[0001783180-22-000056:notes:143]
| (In millions) |  | September 30,2022 |  | December 31, 2021 |
| Environmental reserves included in Accrued liabilities |  | $ | 29 |  |  | $ | 29 |  |
| Environmental reserves included in Other long-term liabilities |  | 203 |  |  | 191 |  |
| Total Environmental reserves |  | $ | 232 |  |  | $ | 220 |  |

[0001783180-22-000056:notes:144]
For sites with multiple responsible parties, the Company considers its likely proportionate share of the anticipated remediation costs and the ability of other parties to fulfill their obligations in establishing a provision for these costs. Accrued environmental liabilities are not reduced by potential insurance reimbursements and are undiscounted.

[0001783180-22-000056:notes:145]
Asbestos Matters

[0001783180-22-000056:notes:146]
The Company has been named as a defendant in lawsuits alleging personal injury as a result of exposure to asbestos allegedly integrated into certain Carrier products or business premises. While the Company has never manufactured asbestos and no longer incorporates it into any currently-manufactured products, certain products that the Company no longer manufactures contained components incorporating asbestos. A substantial majority of these asbestos-related claims have been dismissed without payment or have been covered in full or in part by insurance or other forms of indemnity. Additional cases were litigated and settled without any insurance reimbursement. The amounts involved in asbestos-related claims were not material individually or in the aggregate in any period.

[0001783180-22-000056:notes:147]
The Company's asbestos liabilities and related insurance recoveries are as follows:

[0001783180-22-000056:notes:148]
| (In millions) |  | September 30,2022 |  | December 31,2021 |
| Asbestos liabilities included in Accrued liabilities |  | $ | 17 |  |  | $ | 17 |  |
| Asbestos liabilities included in Other long-term liabilities |  | 214 |  |  | 220 |  |
| Total Asbestos liabilities |  | $ | 231 |  |  | $ | 237 |  |
| Asbestos-related recoveries included in Other assets, current |  | $ | 5 |  |  | $ | 5 |  |
| Asbestos-related recoveries included in Other assets |  | 91 |  |  | 93 |  |
| Total Asbestos-related recoveries |  | $ | 96 |  |  | $ | 98 |  |

[0001783180-22-000056:notes:149]
The amounts recorded for asbestos-related liabilities are based on currently available information and assumptions that the Company believes are reasonable and are made with input from outside actuarial experts. These amounts are undiscounted and

[0001783180-22-000056:notes:150]
exclude the Company’s legal fees to defend the asbestos claims, which are expensed as incurred. In addition, the Company has recorded insurance recovery receivables for probable asbestos-related recoveries.

[0001783180-22-000056:notes:151]
UTC Equity Awards Conversion Litigation

[0001783180-22-000056:notes:152]
On August 12, 2020, several former employees of UTC or its subsidiaries filed a putative class action complaint (the "Complaint") in the United States District Court for the District of Connecticut against Raytheon Technologies Corporation, Carrier, Otis, the former members of the UTC Board of Directors and the members of the Carrier and Otis Boards of Directors (Geraud Darnis, et al. v. Raytheon Technologies Corporation, et al.). The Complaint challenges the method by which UTC equity awards were converted to UTC, Carrier and Otis equity awards following the Separation and the Distribution. Defendants moved to dismiss the Complaint. Plaintiffs amended their Complaint on September 13, 2021 (the "Amended Complaint"). The Amended Complaint, now with Raytheon, Carrier and Otis as the only defendants, asserts that the defendants are liable for breach of certain equity compensation plans and for breach of the implied covenant of good faith and fair dealing. The Amended Complaint also seeks specific performance. Carrier believes that the claims against the Company are without merit. Defendants moved to dismiss the Amended Complaint on October 13, 2021. The motion to dismiss was fully briefed as of December 3, 2021 and the court held oral argument on the motion on July 14, 2022. On September 30, 2022, the court dismissed the complaint against all defendants, with prejudice. The court entered judgment for the defendants on October 4, 2022. The deadline for seeking appellate review of the ruling is November 3, 2022.

[0001783180-22-000056:notes:153]
Aqueous Film Forming Foam Litigation

[0001783180-22-000056:notes:154]
As of September 30, 2022, the Company has been named as a defendant in more than 2,800 lawsuits filed by individuals in or removed to the federal courts of the United States alleging that the historic use of Aqueous Film Forming Foam ("AFFF") caused personal injuries and/or property damage. The Company has also been named as a defendant in more than 250 lawsuits filed by several U.S. states, municipalities and water utilities in or removed to U.S. federal courts alleging that the historic use of AFFF caused contamination of property and water supplies. In December 2018, the U.S. Judicial Panel on Multidistrict Litigation transferred and consolidated all AFFF cases pending in the U.S. federal courts against the Company and others to the U.S. District Court for the District of South Carolina ("MDL Court") for pre-trial proceedings ("MDL Proceedings"). The individual plaintiffs in the MDL Proceedings generally seek damages for alleged personal injuries, medical monitoring and diminution in property value and injunctive relief to remediate alleged contamination of water supplies. The U.S. state, municipal and water utility plaintiffs in the MDL Proceedings generally seek damages and costs related to the remediation of public property and water supplies.

[0001783180-22-000056:notes:155]
AFFF is a firefighting foam, developed beginning in the late 1960s pursuant to U.S. military specification, used to extinguish certain types of hydrocarbon-fueled fires primarily at military bases and airports. AFFF was manufactured by several companies, including National Foam and Angus Fire. UTC first entered the AFFF business with the acquisition of National Foam and Angus Fire in 2005 as part of the acquisition of Kidde. In 2013, Kidde divested the National Foam and Angus Fire businesses to a third party. The Company acquired Kidde as part of its separation from UTC in April 2020. During the eight-year period of its operation by Kidde, National Foam manufactured AFFF for sale to government (including the U.S. federal government) and non-government customers in the U.S. at a single facility located in West Chester, Pennsylvania ("Pennsylvania Site"). During the same period, Angus Fire manufactured AFFF for sale outside the United States at a single facility located in Bentham, England.

[0001783180-22-000056:notes:156]
The key components of AFFF that contribute to its fire-extinguishing capabilities are known as fluorosurfactants. National Foam and Angus Fire did not manufacture fluorosurfactants but instead purchased these substances from unrelated third parties. Plaintiffs in the MDL Proceedings allege that the fluorosurfactants used by various manufacturers in producing AFFF contained, or over time degraded into, compounds known as perflourooctane sulfonate ("PFOS") and/or perflourooctane acid ("PFOA"). Plaintiffs further allege that, as a result of the use of AFFF, PFOS and PFOA were released into the environment and, in some instances, ultimately reached drinking water supplies.

[0001783180-22-000056:notes:157]
Plaintiffs in the MDL Proceedings allege that PFOS and PFOA contamination has resulted from the use of AFFF manufactured using a process known as ECF, and that this process was used exclusively by 3M. They also allege that PFOA contamination has resulted from the use of AFFF manufactured using a different process, known as telomerization, and that this process was used exclusively by the other AFFF manufacturers (including National Foam and Angus Fire). Compounds containing PFOS and PFOA (as well as many other per- and polyfluoroalkyl substances known collectively as "PFAS") have also been used for decades by many third parties in a number of different industries to manufacture firefighters’ protective outerwear, carpets, clothing, fabrics, cookware, food packaging, personal care products, cleaning products, paints, varnishes and other consumer and industrial products.

[0001783180-22-000056:notes:158]
Plaintiffs in the MDL Proceedings have named multiple defendants, including four suppliers of chemicals and raw materials used to manufacture fluorosurfactants, four fluorosurfactant manufacturers, two toll manufacturers of fluorosurfactants and seven current (including National Foam and Angus Fire) and former (including the Company) AFFF manufacturers.

[0001783180-22-000056:notes:159]
The defendants moved for summary judgment on the government contractor defense, which potentially applies to AFFF sold to or used by the U.S. government. After full briefing and oral argument, on September 16, 2022, the MDL court declined to enter summary judgment for the defendants. The defense, however, remains available at any trial to which it applies.

[0001783180-22-000056:notes:160]
On September 23, 2022, after completion of discovery, the MDL court selected one water provider case, the City of Stuart, FL v. 3M, et al., for a bellwether trial. That trial is tentatively scheduled for June 2023. The court has set a briefing schedule for case-specific summary judgment motions and other pretrial motions. That briefing is expected to conclude in February 2023. The MDL court has ordered that the bellwether process for personal injury cases will begin in 2023. The court has not yet outlined details on that process or its timing.

[0001783180-22-000056:notes:161]
Outside of the MDL Proceedings, the Company and other defendants are also party to six lawsuits in U.S. state courts brought by oil refining companies alleging product liability claims related to legacy sales of AFFF and seeking damages for the costs to replace the product and for property damage. In addition, the Company and other defendants are party to two actions related to the Pennsylvania Site in which the plaintiff water utility company seeks remediation costs related to the alleged contamination of the local water supply.

[0001783180-22-000056:notes:162]
The Company and other defendants are also party to one action in Arizona state court brought by a firefighter claiming that occupational exposure to AFFF has caused him certain personal injuries. That case is not eligible for transfer to the MDL at this time. The Company believes that it has meritorious defenses to the claims in the MDL Proceedings and the other AFFF lawsuits. Based on the 2013 agreement for the sale of National Foam and Angus Fire, the Company is pursuing indemnification against these claims from the purchaser and current owner of National Foam and Angus Fire. The Company also is pursuing insurance coverage for these claims. At this time, however, given the numerous factual, scientific and legal issues to be resolved relating to these claims, the Company is unable to assess the probability of liability or to reasonably estimate the damages, if any, to be allocated to the Company, if one or more plaintiffs were to prevail in these cases. There can be no assurance that any such future exposure will not be material in any period.

[0001783180-22-000056:notes:163]
Income Taxes

[0001783180-22-000056:notes:164]
Under the Tax Matters Agreement relating to the Separation, the Company is responsible to UTC for its share of the Tax Cuts and Jobs Act ("TCJA") transition tax associated with foreign undistributed earnings as of December 31, 2017. As a result, liabilities of $34 million and $383 million are included within the accompanying Unaudited Condensed Consolidated Balance Sheet within Accrued Liabilities and Other Long-Term Liabilities as of September 30, 2022, respectively. This obligation is expected to be settled in annual installments ending in April 2026 with the next installment of $34 million due in 2023. The Company believes that the likelihood of incurring losses materially in excess of this amount is remote.

[0001783180-22-000056:notes:165]
Other

[0001783180-22-000056:notes:166]
The Company has other commitments and contingent liabilities related to legal proceedings, self-insurance programs and matters arising in the ordinary course of business. The Company accrues for contingencies generally based upon a range of possible outcomes. If no amount within the range is a better estimate than any other, the Company accrues the minimum amount.

[0001783180-22-000056:notes:167]
In the ordinary course of business, the Company is also routinely a defendant in, party to or otherwise subject to many pending and threatened legal actions, claims, disputes and proceedings. These matters are often based on alleged violations of contract, product liability, warranty, regulatory, environmental, health and safety, employment, intellectual property, tax and other laws. In some of these proceedings, claims for substantial monetary damages are asserted against the Company and could result in fines, penalties, compensatory or treble damages or non-monetary relief. The Company does not believe that these matters will have a material adverse effect upon its competitive position, results of operations, cash flows or financial condition.
