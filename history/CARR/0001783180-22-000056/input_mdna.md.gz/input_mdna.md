# CARR MD&A — 0001783180-22-000056


## mdna

[0001783180-22-000056:mdna:1]
[same as prior period, unchanged from 0001783180-22-000048:mdna:1]

[0001783180-22-000056:mdna:2]
[same as prior period, unchanged from 0001783180-22-000048:mdna:2]

[0001783180-22-000056:mdna:3]
[same as prior period, unchanged from 0001783180-22-000048:mdna:3]

[0001783180-22-000056:mdna:4]
[same as prior period, unchanged from 0001783180-22-000048:mdna:4]

[0001783180-22-000056:mdna:5]
Our worldwide operations are affected by global and regional industrial, economic and political factors and trends. These include the mega-trends of urbanization, climate change and increasing requirements for food safety driven by the food needs of our growing global population and the rising standards of living in emerging markets. We believe that our business segments are well positioned to benefit from favorable secular trends, including these mega-trends and from the strength of our industry-leading brands and track record of innovation. In addition, we regularly review our end markets to proactively identify trends and adapt our strategies accordingly.

[0001783180-22-000056:mdna:6]
Our business is also affected by changes in the general level of economic activity, such as changes in business and consumer spending, construction and shipping activity as well as short-term economic factors such as currency fluctuations, commodity price volatility and supply disruptions. We continue to invest in our business, take pricing actions to mitigate supply chain and inflationary pressures, develop new products and services in order to remain competitive in our markets and use risk management strategies to mitigate various exposures. We believe that we have industry-leading global brands, which form the foundation of our business strategy. Coupled with our focus on growth, innovation and operational efficiency, we expect to drive long-term future growth and increased value for our shareowners.

[0001783180-22-000056:mdna:7]
[same as prior period, unchanged from 0001783180-22-000048:mdna:7]

[0001783180-22-000056:mdna:8]
Acquisition of Toshiba Carrier Corporation

[0001783180-22-000056:mdna:9]
On February 6, 2022, we entered into a binding agreement to acquire a majority ownership interest in TCC, a VRF and light commercial HVAC joint venture between Carrier and Toshiba Corporation. TCC designs and manufactures flexible, energy-efficient and high-performance VRF and light commercial HVAC systems as well as commercial products, compressors and heat pumps. The acquisition included all of TCC's advanced research and development centers and global manufacturing operations, product pipeline and the long-term use of Toshiba's iconic brand. The acquisition was completed on August 1, 2022, subject to customary closing conditions. As a result, the assets, liabilities and results of operations of TCC are consolidated in the accompanying Unaudited Condensed Consolidated Financial Statements as of the date of acquisition and reported within our HVAC segment. Upon closing, Toshiba Corporation retained a 5% ownership interest in TCC.

[0001783180-22-000056:mdna:10]
[same as prior period, unchanged from 0001783180-22-000048:mdna:8]

[0001783180-22-000056:mdna:11]
In February 2022, Russian forces initiated a military action against Ukraine. As a result, the European Union, United States, the United Kingdom and other countries have imposed sanctions that have increased global economic and political uncertainty. We operated in Russia through a Russia-based subsidiary and a joint venture which represents less than 1% of our total assets and revenue. On March 10, 2022, we announced that we were suspending business operations in Russia, honoring existing contractual obligations in a manner that fully complies with all sanctions and trade controls imposed. As of September 30, 2022, we remain on track to cease all operations in Russia this year. While neither Russia nor Ukraine constitute a material portion of our business, the conflict could lead to disruption, instability and volatility in global markets and industries that could negatively impact our results of operations. We continue to monitor the evolving impacts of this conflict and its effect on the global economy and geopolitical landscape.

[0001783180-22-000056:mdna:12]
[same as prior period, unchanged from 0001783180-22-000048:mdna:10]

[0001783180-22-000056:mdna:13]
The ongoing global economic recovery from the COVID-19 pandemic has caused significant challenges for global supply chains resulting in inflationary cost pressures, component shortages and transportation delays. As a result, we have incurred incremental costs for commodities and components used in our products as well as component shortages that have negatively

[0001783180-22-000056:mdna:14]
impacted our sales and results of operations. We expect that these challenges will continue to have an impact on our businesses for the foreseeable future.

[0001783180-22-000056:mdna:15]
[same as prior period, unchanged from 0001783180-22-000048:mdna:12]

[0001783180-22-000056:mdna:16]
[same as prior period, unchanged from 0001783180-22-000048:mdna:13]

[0001783180-22-000056:mdna:17]
On January 3, 2022, we completed the Chubb Sale for net proceeds of $2.9 billion. Chubb, which was reported within our Fire & Security segment, delivered essential fire safety and security solutions from design and installation to monitoring, service and maintenance across more than 17 countries around the globe. During the three months ended March 31, 2022, we recognized a gain on the sale of $1.1 billion. The sale agreement included several customary provisions to settle working capital and other transaction-related items as of the date of sale. During the three months ended September 30, 2022, the parties finalized these amounts in accordance with the terms of the sale agreement.

[0001783180-22-000056:mdna:18]
[same as prior period, unchanged from 0001783180-22-000048:mdna:17]

[0001783180-22-000056:mdna:19]
[same as prior period, unchanged from 0001783180-22-000048:mdna:18]

[0001783180-22-000056:mdna:20]
[same as prior period, unchanged from 0001783180-22-000048:mdna:19]

[0001783180-22-000056:mdna:21]
Preparation of our financial statements requires management to make estimates and assumptions that affect the reported amounts of assets, liabilities, sales and expenses. We believe that the most complex and sensitive judgments, because of their potential significance to the accompanying Unaudited Condensed Consolidated Financial Statements, result primarily from the need to make estimates about the effects of matters that are inherently uncertain. In "Management’s Discussion and Analysis of Financial Condition and Results of Operations" of our 2021 Form 10-K, we describe the significant accounting estimates and policies used in the preparation of the accompanying Unaudited Condensed Consolidated Financial Statements. There have been no significant changes in our critical accounting estimates.

[0001783180-22-000056:mdna:22]
[same as prior period, unchanged from 0001783180-22-000048:mdna:21]

[0001783180-22-000056:mdna:23]
As a result of the Chubb Sale, we do not have any remaining ownership interest in Chubb and no longer consolidate Chubb in our financial statements as of January 3, 2022. Therefore, this Management’s Discussion and Analysis of Financial Condition and Results of Operations only includes the financial results of Chubb in periods prior to the date of sale. As a result, prior period results may not be comparable to the current period. See Note 16 - Divestitures in the Notes to the accompanying Unaudited Condensed Consolidated Financial Statements for additional information.

[0001783180-22-000056:mdna:24]
The results of operations of TCC are included in our consolidated results since the acquisition date of August 1, 2022. Prior to the acquisition, we previously accounted for our minority ownership in TCC under the equity method of accounting and recognized our portion of earnings within Equity method investment in net earnings as part of operating expenses. As a result, prior period results may not be comparable to the current period. See Note 15 - Acquisitions in the Notes to the accompanying Unaudited Condensed Consolidated Financial Statements for additional information.

[0001783180-22-000056:mdna:25]
Three Months Ended September 30, 2022 Compared with the Three Months Ended September 30, 2021

[0001783180-22-000056:mdna:26]
[same as prior period, unchanged from 0001783180-22-000048:mdna:24]

[0001783180-22-000056:mdna:27]
|  |  | Three Months Ended September 30, |  |  |  |  |  |  |
| (In millions) |  | 2022 |  | 2021 |  | Period Change |  | % Change |  |  |  |  |  |  |
| Net sales |  | $ | 5,451 |  |  | $ | 5,341 |  |  | $ | 110 |  |  | 2 | % |  |  |  |  |  |  |
| Cost of products and services sold |  | (3,974) |  |  | (3,740) |  |  | (234) |  |  | 6 | % |  |  |  |  |  |  |
| Gross margin |  | 1,477 |  |  | 1,601 |  |  | (124) |  |  | (8) | % |  |  |  |  |  |  |
| Operating expenses |  | 49 |  |  | (773) |  |  | 822 |  |  | (106) | % |  |  |  |  |  |  |
| Operating profit |  | 1,526 |  |  | 828 |  |  | 698 |  |  | 84 | % |  |  |  |  |  |  |
| Non-operating income (expenses), net |  | (56) |  |  | (60) |  |  | 4 |  |  | (7) | % |  |  |  |  |  |  |
| Income from operations before income taxes |  | 1,470 |  |  | 768 |  |  | 702 |  |  | 91 | % |  |  |  |  |  |  |
| Income tax expense |  | (138) |  |  | (288) |  |  | 150 |  |  | (52) | % |  |  |  |  |  |  |
| Net income from operations |  | 1,332 |  |  | 480 |  |  | 852 |  |  | 178 | % |  |  |  |  |  |  |
| Less: Non-controlling interest in subsidiaries' earnings from operations |  | 20 |  |  | 11 |  |  | 9 |  |  | 82 | % |  |  |  |  |  |  |
| Net income attributable to common shareowners |  | $ | 1,312 |  |  | $ | 469 |  |  | $ | 843 |  |  | 180 | % |  |  |  |  |  |  |

[0001783180-22-000056:mdna:28]
[same as prior period, unchanged from 0001783180-22-000048:mdna:26]

[0001783180-22-000056:mdna:29]
For the three months ended September 30, 2022, Net sales were $5.5 billion, a 2% increase compared with the same period of 2021. The components of the year-over-year change were as follows:

[0001783180-22-000056:mdna:30]
|  |  | Three Months Ended September 30, 2022 |  |  |  |  |  |  |
| Organic |  | 8 | % |  |  |  |  |  |  |
| Foreign currency translation |  | (4) | % |  |  |  |  |  |  |
| Acquisitions and divestitures, net |  | (2) | % |  |  |  |  |  |  |
| Total % change |  | 2 | % |  |  |  |  |  |  |

[0001783180-22-000056:mdna:31]
Organic sales for the three months ended September 30, 2022 increased by 8% compared with the same period of 2021. We continue to benefit from the demand for energy-efficient, digital products and healthy building solutions. In addition, pricing improvements more than offset inflationary impacts in each of our segments. The organic increase was primarily driven by our HVAC segment due to pricing improvements in our North America residential and light commercial business and improved global end-markets in our Commercial HVAC business. Our Refrigeration segment benefited from pricing improvements, but continued supply chain and logistic constraints as well as weakness in Europe impacted results. Pricing improvements in our Fire & Security segment were the primary driver of growth compared with the prior year while supply chain and logistic constraints continue to be challenging. Refer to "Segment Review" below for a discussion of Net sales by segment.

[0001783180-22-000056:mdna:32]
[same as prior period, unchanged from 0001783180-22-000048:mdna:30]

[0001783180-22-000056:mdna:33]
For the three months ended September 30, 2022, gross margin was $1.5 billion, an 8% decrease compared with the same period of 2021. The components were as follows:

[0001783180-22-000056:mdna:34]
|  |  | Three Months Ended September 30, |  |  |  |  |  |  |
| (In millions) |  | 2022 |  | 2021 |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 5,451 |  |  | $ | 5,341 |  |  |  |  |  |  |  |  |  |
| Cost of products and services sold |  | (3,974) |  |  | (3,740) |  |  |  |  |  |  |  |  |  |
| Gross margin |  | $ | 1,477 |  |  | $ | 1,601 |  |  |  |  |  |  |  |  |  |
| Percentage of net sales |  | 27.1 | % |  | 30.0 | % |  |  |  |  |  |  |  |  |

[0001783180-22-000056:mdna:35]
Gross margin decreased by $124 million compared with the three months ended September 30, 2021. A main driver of the decrease related to the incremental costs of products and services sold associated with TCC since the date of acquisition, which included inventory step-up, backlog amortization and intangible asset amortization resulting from the recognition of acquired assets at fair value. These costs had a 100 basis point impact on gross margin as a percentage of Net sales. In addition, each of our segments continue to be impacted by the higher cost of commodities and components used in our products, certain supply chain constraints and higher freight costs. However, these impacts were more than offset by ongoing customer demand, pricing improvements and our continued focus on productivity initiatives. Although pricing improvements more than offset inflationary impacts and supply chain challenges, gross margin as a percentage of Net sales decreased by 290 basis points compared with the same period of 2021 including the impact of the TCC acquisition.

[0001783180-22-000056:mdna:36]
[same as prior period, unchanged from 0001783180-22-000048:mdna:34]

[0001783180-22-000056:mdna:37]
For the three months ended September 30, 2022, operating expenses, including Equity method investment net earnings, were $49 million, a 106% decrease compared with the same period of 2021. The components were as follows:

[0001783180-22-000056:mdna:38]
|  |  | Three Months Ended September 30, |  |  |  |  |  |  |
| (In millions) |  | 2022 |  | 2021 |  |  |  |  |  |  |  |  |
| Selling, general and administrative |  | $ | (624) |  |  | $ | (748) |  |  |  |  |  |  |  |  |  |
| Research and development |  | (143) |  |  | (123) |  |  |  |  |  |  |  |  |  |
| Equity method investment net earnings |  | 63 |  |  | 76 |  |  |  |  |  |  |  |  |  |
| Other income (expense), net |  | 753 |  |  | 22 |  |  |  |  |  |  |  |  |  |
| Total operating expenses |  | $ | 49 |  |  | $ | (773) |  |  |  |  |  |  |  |  |  |
| Percentage of net sales |  | (0.9) | % |  | 14.5 | % |  |  |  |  |  |  |  |  |

[0001783180-22-000056:mdna:39]
For the three months ended September 30, 2022, Selling, general and administrative expenses were $624 million, a 17% decrease compared with the same period of 2021. The decrease is primarily due to the Chubb Sale on January 3, 2022. In addition, lower restructuring charges and the benefit provided by changes in the fair value of cash-settled equity awards further contributed to the decrease. These amounts were partially offset by incremental selling, general and administrative expenses associated with TCC since the date of acquisition and $15 million of acquisition-related costs. The three months ended September 30, 2021 included $14 million of costs related to the Chubb Sale.

[0001783180-22-000056:mdna:40]
Research and development costs relate to new product development and new technology innovation. Due to the variable nature of program development schedules, year-over-year spending levels can fluctuate. In addition, we continue to invest to prepare for future energy efficiency and refrigerant regulation changes and in digital controls technologies.

[0001783180-22-000056:mdna:41]
Investments over which we do not exercise control, but have significant influence, are accounted for using the equity method of accounting. For the three months ended September 30, 2022, Equity method investment net earnings were $63 million, a 17% decrease compared with the same period of 2021. The decrease was primarily associated with the increase in our ownership interest in TCC on August 1, 2022. As a result, TCC is no longer accounted for under the equity method of accounting since the date of acquisition.

[0001783180-22-000056:mdna:42]
Other income (expense), net primarily includes the impact of gains and losses related to the sale of businesses or interests in our equity method investments, foreign currency gains and losses on transactions that are denominated in a currency other than an entity's functional currency and hedging-related activities. In connection with the TCC acquisition, the carrying value of our previously held TCC equity investments were recognized at fair value at the date of acquisition. As a result, we recognized a $732 million non-cash gain associated with the increase in our ownership interest. In addition, we recognized a $7 million charge resulting from the settlement of working capital and other transaction-related items associated with the Chubb Sale during the three months ended September 30, 2022.

[0001783180-22-000056:mdna:43]
[same as prior period, unchanged from 0001783180-22-000048:mdna:42]

[0001783180-22-000056:mdna:44]
For the three months ended September 30, 2022, Non-operating income (expenses), net was $56 million, a 7% decrease compared with the same period of 2021. The components were as follows:

[0001783180-22-000056:mdna:45]
|  |  | Three Months Ended September 30, |  |  |
| (In millions) |  | 2022 |  | 2021 |  |  |  |  |
| Non-service pension (expense) benefit |  | $ | — |  |  | $ | 14 |  |  |  |  |  |
| Interest expense |  | $ | (71) |  |  | $ | (76) |  |  |  |  |  |
| Interest income |  | 15 |  |  | 2 |  |  |  |  |  |
| Interest (expense) income, net |  | $ | (56) |  |  | $ | (74) |  |  |  |  |  |
| Non-operating income (expenses), net |  | $ | (56) |  |  | $ | (60) |  |  |  |  |  |

[0001783180-22-000056:mdna:46]
Non-operating income (expenses), net includes the results from activities other than normal business operations such as interest expense, interest income and the non-service components of pension and post-retirement obligations. For the three months ended September 30, 2022, Interest expense was $71 million, a 7% decrease compared with the same period of 2021. The decrease was primarily driven by the repayment of $1.15 billion aggregate principal 2.242% Notes due 2025 and 2.493% Notes due 2027 during the three months ended March 31, 2022.

[0001783180-22-000056:mdna:47]
[same as prior period, unchanged from 0001783180-22-000048:mdna:47]

[0001783180-22-000056:mdna:48]
|  |  | Three Months Ended September 30, |  |  |  |
|  |  | 2022 |  | 2021 |  |  |  |  |  |  |  |
| Effective tax rate |  | 9.4 | % |  | 37.5 | % |  |  |  |  |  |  |  |

[0001783180-22-000056:mdna:49]
We account for income tax expense in accordance with ASC 740, which requires an estimate of the annual effective income tax rate for the full year to be applied to the respective interim period, taking into account year-to-date amounts and projected results for the full year. The effective tax rate was 9.4% for the three months ended September 30, 2022 compared with 37.5% for the three months ended September 30, 2021. The year-over-year decrease was primarily driven by a lower effective tax rate on a $732 million non-cash gain resulting from the recognition of our previously held TCC equity investments at fair value upon acquisition of TCC compared with our U.S. statutory tax rate. In addition, the prior year included a net tax charge $136 million primarily relating to the re-organizations and disentanglement of certain Chubb subsidiaries executed in advance of the planned divestiture of Chubb business.

[0001783180-22-000056:mdna:50]
34

[0001783180-22-000056:mdna:51]
Nine Months Ended September 30, 2022 Compared with the Nine Months Ended September 30, 2021

[0001783180-22-000056:mdna:52]
[same as prior period, unchanged from 0001783180-22-000048:mdna:51]

[0001783180-22-000056:mdna:53]
|  |  | Nine Months Ended September 30, |  |  |  |  |  |  |
| (In millions) |  | 2022 |  | 2021 |  | Period Change |  | % Change |  |  |  |  |  |  |
| Net sales |  | $ | 15,316 |  |  | $ | 15,480 |  |  | $ | (164) |  |  | (1) | % |  |  |  |  |  |  |
| Cost of products and services sold |  | (11,099) |  |  | (10,866) |  |  | (233) |  |  | 2 | % |  |  |  |  |  |  |
| Gross margin |  | 4,217 |  |  | 4,614 |  |  | (397) |  |  | (9) | % |  |  |  |  |  |  |
| Operating expenses |  | (135) |  |  | (2,432) |  |  | 2,297 |  |  | (94) | % |  |  |  |  |  |  |
| Operating profit |  | 4,082 |  |  | 2,182 |  |  | 1,900 |  |  | 87 | % |  |  |  |  |  |  |
| Non-operating income (expenses), net |  | (167) |  |  | (187) |  |  | 20 |  |  | (11) | % |  |  |  |  |  |  |
| Income from operations before income taxes |  | 3,915 |  |  | 1,995 |  |  | 1,920 |  |  | 96 | % |  |  |  |  |  |  |
| Income tax expense |  | (609) |  |  | (626) |  |  | 17 |  |  | (3) | % |  |  |  |  |  |  |
| Net income from operations |  | 3,306 |  |  | 1,369 |  |  | 1,937 |  |  | 141 | % |  |  |  |  |  |  |
| Less: Non-controlling interest in subsidiaries' earnings from operations |  | 42 |  |  | 29 |  |  | 13 |  |  | 45 | % |  |  |  |  |  |  |
| Net income attributable to common shareowners |  | $ | 3,264 |  |  | $ | 1,340 |  |  | $ | 1,924 |  |  | 144 | % |  |  |  |  |  |  |

[0001783180-22-000056:mdna:54]
[same as prior period, unchanged from 0001783180-22-000048:mdna:53]

[0001783180-22-000056:mdna:55]
For the nine months ended September 30, 2022, Net sales were $15.3 billion, a 1% decrease compared with the same period of 2021. The components of the year-over-year change were as follows:

[0001783180-22-000056:mdna:56]
|  |  |  |  | Nine Months Ended September 30, 2022 |  |  |  |  |
| Organic |  |  |  | 9 | % |  |  |  |  |
| Foreign currency translation |  |  |  | (3) | % |  |  |  |  |
| Acquisitions and divestitures, net |  |  |  | (7) | % |  |  |  |  |
| Total % change |  |  |  | (1) | % |  |  |  |  |

[0001783180-22-000056:mdna:57]
Organic sales for the nine months ended September 30, 2022 increased by 9% compared with the same period of 2021. We continue to benefit from the demand for energy-efficient, digital products and healthy building solutions. In addition, pricing improvements more than offset inflationary impacts in each of our segments. The organic increase was primarily driven by our HVAC segment due to pricing improvements in our North America residential and light commercial business and improved global end-markets in our Commercial HVAC business. Refrigeration results benefited from pricing improvements which more than offset ongoing supply chain and logistic constraints. Pricing improvements in our Fire & Security segment were the primary driver of growth compared with the prior year while supply chain and logistic constraints continue to be challenging. Refer to "Segment Review" below for a discussion of Net sales by segment.

[0001783180-22-000056:mdna:58]
[same as prior period, unchanged from 0001783180-22-000048:mdna:58]

[0001783180-22-000056:mdna:59]
For the nine months ended September 30, 2022, gross margin was $4.2 billion, a 9% decrease compared with the same period

[0001783180-22-000056:mdna:60]
of 2021. The components were as follows:

[0001783180-22-000056:mdna:61]
|  |  |  |  | Nine Months Ended September 30, |  |  |  |  |
| (In millions) |  |  |  |  |  | 2022 |  | 2021 |  |  |  |  |
| Net sales |  |  |  |  |  | $ | 15,316 |  |  | $ | 15,480 |  |  |  |  |  |
| Cost of products and services sold |  |  |  |  |  | (11,099) |  |  | (10,866) |  |  |  |  |  |
| Gross margin |  |  |  |  |  | $ | 4,217 |  |  | $ | 4,614 |  |  |  |  |  |
| Percentage of net sales |  |  |  |  |  | 27.5 | % |  | 29.8 | % |  |  |  |  |

[0001783180-22-000056:mdna:62]
Gross margin decreased by $397 million compared with the nine months ended September 30, 2021. A main driver of the decrease related to incremental costs of products and services sold associated with TCC since the date of acquisition, which included inventory step-up, backlog amortization and intangible asset amortization resulting from the recognition of acquired assets at fair value. These costs had a 40 basis point impact on gross margin as a percentage of Net sales. In addition, each of our segments continue to be impacted by the higher cost of commodities and components used in our products, certain supply chain constraints and higher freight costs. However, these impacts were more than offset by ongoing customer demand, pricing improvements and our continued focus on productivity initiatives. Although pricing improvements more than offset inflationary impacts and supply chain challenges, gross margin as a percentage of Net sales decreased by 230 basis points compared with the same period of 2021.

[0001783180-22-000056:mdna:63]
[same as prior period, unchanged from 0001783180-22-000048:mdna:62]

[0001783180-22-000056:mdna:64]
For the nine months ended September 30, 2022, operating expenses, including Equity method investment net earnings, were $135 million, a 94% decrease compared with the same period of 2021. The components were as follows:

[0001783180-22-000056:mdna:65]
|  |  |  |  | Nine Months Ended September 30, |  |  |  |  |
| (In millions) |  |  |  |  |  | 2022 |  | 2021 |  |  |  |  |
| Selling, general and administrative |  |  |  |  |  | $ | (1,839) |  |  | $ | (2,304) |  |  |  |  |  |
| Research and development |  |  |  |  |  | (390) |  |  | (369) |  |  |  |  |  |
| Equity method investment net earnings |  |  |  |  |  | 222 |  |  | 201 |  |  |  |  |  |
| Other income (expense), net |  |  |  |  |  | 1,872 |  |  | 40 |  |  |  |  |  |
| Total operating expenses |  |  |  |  |  | $ | (135) |  |  | $ | (2,432) |  |  |  |  |  |
| Percentage of net sales |  |  |  |  |  | 0.9 | % |  | 15.7 | % |  |  |  |  |

[0001783180-22-000056:mdna:66]
For the nine months ended September 30, 2022, Selling, general and administrative expenses were $1.8 billion, a 20% decrease compared with the same period of 2021. The decrease is primarily due to the Chubb Sale on January 3, 2022. In addition, lower restructuring charges and the benefit provided by changes in the fair value of cash-settled equity awards further contributed to the decrease. These amounts were partially offset by incremental selling, general and administrative expenses associated with TCC since the date of acquisition and $28 million of acquisition-related costs. The nine months ended September 30, 2021 included $29 million of costs related to the Chubb Sale and $19 million of costs related to the Separation.

[0001783180-22-000056:mdna:67]
Research and development costs relate to new product development and new technology innovation. Due to the variable nature of program development schedules, year-over-year spending levels can fluctuate. In addition, we continue to invest to prepare for future energy efficiency and refrigerant regulation changes and in digital controls technologies.

[0001783180-22-000056:mdna:68]
Investments over which we do not exercise control, but have significant influence, are accounted for using the equity method of accounting. For the nine months ended September 30, 2022, Equity method investment net earnings were $222 million, a 10% increase compared with the same period of 2021. The increase was primarily related to a $27 million gain on the sale of two minority owned subsidiaries by one of our joint ventures. In addition, higher earnings in HVAC joint ventures in Asia and North America further benefited earnings. These amounts were partially offset by the increase in our ownership interest in TCC on August 1, 2022. As a result, TCC is no longer accounted for under the equity method of accounting since the date of acquisition.

[0001783180-22-000056:mdna:69]
Other income (expense), net primarily includes the impact of gains and losses related to the sale of businesses or interests in our equity method investments, foreign currency gains and losses on transactions that are denominated in a currency other than an entity's functional currency and hedging-related activities. In connection with the TCC acquisition, the carrying value of our previously held TCC equity investments were recognized at fair value at the date of acquisition. As a result, we recognized a $732 million non-cash gain associated with the increase in our ownership interest. In addition, we completed the Chubb Sale and recognized a net gain on the sale of $1.1 billion during the nine months ended September 30, 2022.

[0001783180-22-000056:mdna:70]
[same as prior period, unchanged from 0001783180-22-000048:mdna:70]

[0001783180-22-000056:mdna:71]
For the nine months ended September 30, 2022, Non-operating income (expenses), net was $167 million, an 11% increase compared with the same period of 2021. The components were as follows:

[0001783180-22-000056:mdna:72]
|  |  |  |  | Nine Months Ended September 30, |
| (In millions) |  |  |  |  |  | 2022 |  | 2021 |
| Non-service pension (expense) benefit |  |  |  |  |  | $ | (2) |  |  | $ | 51 |  |
| Interest expense |  |  |  |  |  | $ | (226) |  |  | $ | (247) |  |
| Interest income |  |  |  |  |  | 61 |  |  | 9 |  |
| Interest (expense) income, net |  |  |  |  |  | $ | (165) |  |  | $ | (238) |  |
| Non-operating income (expenses), net |  |  |  |  |  | $ | (167) |  |  | $ | (187) |  |

[0001783180-22-000056:mdna:73]
Non-operating income (expenses), net includes the results from activities other than normal business operations such as interest expense, interest income and the non-service components of pension and post-retirement obligations. For the nine months ended September 30, 2022, Interest expense was $226 million, a 9% decrease compared with the same period of 2021. During the nine months ended September 30, 2022, we completed tender offers to repurchase approximately $1.15 billion aggregate principal of our 2.242% Notes due 2025 and 2.493% Notes due 2027. Upon settlement, we wrote off $5 million of unamortized deferred financing costs in Interest expense and recognized a net gain of $33 million in Interest income. During the nine months ended September 30, 2021, we incurred a make-whole premium of $17 million and wrote-off $2 million of unamortized deferred financing costs in Interest expense as a result of the redemption of our $500 million 1.923% Notes originally due in February 2023.

[0001783180-22-000056:mdna:74]
[same as prior period, unchanged from 0001783180-22-000048:mdna:74]

[0001783180-22-000056:mdna:75]
|  |  |  | Nine Months Ended September 30, |  |  |
|  |  |  |  |  | 2022 |  | 2021 |  |  |  |  |
| Effective tax rate |  |  |  |  | 15.6 | % |  | 31.4 | % |  |  |  |  |

[0001783180-22-000056:mdna:76]
We account for income tax expense in accordance with ASC 740, which requires an estimate of the annual effective income tax rate for the full year to be applied to the respective interim period, taking into account year-to-date amounts and projected results for the full year. The effective tax rate was 15.6% for the nine months ended September 30, 2022 compared with 31.4% for the nine months ended September 30, 2021. The year-over-year decrease was primarily driven by a lower effective tax rate on a $732 million non-cash gain resulting from the recognition of our previously held TCC equity investments at fair value upon acquisition of TCC and the $1.1 billion Chubb gain compared with the Company's U.S. statutory rate. The nine months ended September 30, 2021 included a net tax charge of $136 million primarily relating to the re-organizations and disentanglement of certain Chubb subsidiaries executed in advance of the planned divestiture of our Chubb business and a $43 million deferred tax charge associated with a tax rate increase in the United Kingdom enacted on June 10, 2021 with an effective date of April 2023. These amounts were partially offset by the recognition of a favorable tax adjustment of $21 million resulting from the re-organization of a German subsidiary.

[0001783180-22-000056:mdna:77]
[same as prior period, unchanged from 0001783180-22-000048:mdna:134]

[0001783180-22-000056:mdna:78]
[same as prior period, unchanged from 0001783180-22-000048:mdna:77]

[0001783180-22-000056:mdna:79]
[same as prior period, unchanged from 0001783180-22-000048:mdna:78]

[0001783180-22-000056:mdna:80]
[same as prior period, unchanged from 0001783180-22-000048:mdna:79]

[0001783180-22-000056:mdna:81]
[same as prior period, unchanged from 0001783180-22-000048:mdna:80]

[0001783180-22-000056:mdna:82]
[same as prior period, unchanged from 0001783180-22-000048:mdna:81]

[0001783180-22-000056:mdna:83]
[same as prior period, unchanged from 0001783180-22-000048:mdna:82]

[0001783180-22-000056:mdna:84]
Three Months Ended September 30, 2022 Compared with Three Months Ended September 30, 2021

[0001783180-22-000056:mdna:85]
[same as prior period, unchanged from 0001783180-22-000048:mdna:84]

[0001783180-22-000056:mdna:86]
|  |  | Net Sales |  | Operating Profit |  | Operating Profit Margin |
|  |  | Three Months Ended September 30, |  | Three Months Ended September 30, |  | Three Months Ended September 30, |
| (In millions) |  | 2022 |  | 2021 |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| HVAC |  | $ | 3,734 |  |  | $ | 3,054 |  |  | $ | 1,314 |  |  | $ | 573 |  |  | 35.2 | % |  | 18.8 | % |
| Refrigeration |  | 923 |  |  | 1,011 |  |  | 116 |  |  | 119 |  |  | 12.6 | % |  | 11.8 | % |
| Fire & Security |  | 905 |  |  | 1,377 |  |  | 142 |  |  | 182 |  |  | 15.7 | % |  | 13.2 | % |
| Total segment |  | $ | 5,562 |  |  | $ | 5,442 |  |  | $ | 1,572 |  |  | $ | 874 |  |  | 28.3 | % |  | 16.1 | % |

[0001783180-22-000056:mdna:87]
[same as prior period, unchanged from 0001783180-22-000048:mdna:86]

[0001783180-22-000056:mdna:88]
For the three months ended September 30, 2022, Net sales in our HVAC segment were $3.7 billion, a 22% increase compared with the same period of 2021. The components of the year-over-year change were as follows:

[0001783180-22-000056:mdna:89]
|  |  | Net Sales |
| Organic |  | 13 | % |
| Foreign currency translation |  | (3) | % |
| Acquisitions and divestitures, net |  | 12 | % |
| Total % change in Net sales |  | 22 | % |

[0001783180-22-000056:mdna:90]
The organic increase in Net sales of 13% was driven by continued strong results across each of the segment's businesses. Increased sales in our North America residential and light commercial business (up 12%) were primarily driven by pricing improvements during the period. Commercial HVAC (up 15%) benefited from pricing improvements and ongoing customer demand in our end-markets. The business saw continued growth in North America and strong results in Asia compared with the prior period. Increased sales in our Global Comfort Solutions business (up 11%) were primarily driven by pricing improvements. While current demand remains strong, supply chain and logistics constraints continue to be challenging, negatively impacting our sales and results of operations.

[0001783180-22-000056:mdna:91]
On August 1, 2022, the Commercial HVAC business acquired a majority ownership interest in TCC, a VRF and light commercial HVAC joint venture between Carrier and Toshiba Corporation. The results of TCC have been included in our Unaudited Condensed Consolidated Financial Statements since the date of acquisition. The transaction added 12% to Net sales during the three months ended September 30, 2022 and is included in Acquisitions and divestitures, net.

[0001783180-22-000056:mdna:92]
For the three months ended September 30, 2022, Operating profit in our HVAC segment was $1.3 billion, a 129% increase compared with the same period of 2021. The components of the year-over-year change were as follows:

[0001783180-22-000056:mdna:93]
|  |  | Operating Profit |
| Operational |  | — | % |
| Foreign currency translation |  | (1) | % |
| Acquisitions and divestitures, net |  | 5 | % |
| Restructuring |  | 1 | % |
| Other |  | 124 | % |
| Total % change in Operating profit |  | 129 | % |

[0001783180-22-000056:mdna:94]
Operational profit was flat compared with the prior year. Pricing improvements, higher volume and productivity initiatives benefited operational profit during the period. These amounts were partially offset by the higher costs of commodities and components used in our products as well as higher freight and logistic costs compared with the prior year. In addition, lower earnings from equity method investments further impacted operational profit as TCC is now included in the segments consolidated results since the date of acquisition.

[0001783180-22-000056:mdna:95]
Acquisitions and divestitures, net primarily related to the results of operations associated with the acquisition of TCC. The transaction added 5% to Operating profit during the three months ended September 30, 2022. In connection with the TCC acquisition, the carrying value of our previously held TCC equity investments were recognized at fair value at the date of acquisition. As a result, we recognized a $732 million non-cash gain associated with the increase in our ownership interest in Other.

[0001783180-22-000056:mdna:96]
[same as prior period, unchanged from 0001783180-22-000048:mdna:96]

[0001783180-22-000056:mdna:97]
For the three months ended September 30, 2022, Net sales in our Refrigeration segment were $0.9 billion, a 9% decrease compared with the same period of 2021. The components of the year-over-year change were as follows:

[0001783180-22-000056:mdna:98]
|  |  | Net Sales |
| Organic |  | (1) | % |
| Foreign currency translation |  | (8) | % |
| Total % change in Net sales |  | (9) | % |

[0001783180-22-000056:mdna:99]
The organic decrease in Net sales of 1% was driven by lower volumes compared with the prior year. Commercial refrigeration sales were flat compared with the prior year, primarily driven by lower volumes in Europe as economic conditions and inflationary cost pressures impacted end-market demand. These impacts were partially offset by pricing improvements and growth in Asia. Transport refrigeration sales (down 1%) decreased primarily due to continued supply chain constraints impacting component availability. These impacts were partially offset by pricing improvements, strong growth in North America, the continued demand for global transportation and COVID-19 vaccine-related cargo monitoring. While current demand remains strong, supply chain and logistics constraints continue to be challenging, negatively impacting our sales and results of operations.

[0001783180-22-000056:mdna:100]
For the three months ended September 30, 2022, Operating profit in our Refrigeration segment was $116 million, a 2% decrease compared with the same period of 2021. The components of the year-over-year change were as follows:

[0001783180-22-000056:mdna:101]
|  |  | Operating Profit |
| Operational |  | 5 | % |
| Foreign currency translation |  | (7) | % |
| Restructuring |  | (1) | % |
| Other |  | 1 | % |
| Total % change in Operating profit |  | (2) | % |

[0001783180-22-000056:mdna:102]
The increase in operational profit of 5% was primarily attributable to pricing improvements compared with the prior year. In addition, favorable productivity initiatives and lower selling, general and administrative costs further benefited operational profit. These amounts were partially offset by the higher costs of commodities and components used in our products as well as higher freight and logistic costs.

[0001783180-22-000056:mdna:103]
[same as prior period, unchanged from 0001783180-22-000048:mdna:103]

[0001783180-22-000056:mdna:104]
For the three months ended September 30, 2022, Net sales in our Fire & Security segment were $905 million, a 34% decrease compared with the same period of 2021. The components of the year-over-year change were as follows:

[0001783180-22-000056:mdna:105]
|  |  | Net Sales |
| Organic |  | 5 | % |
| Foreign currency translation |  | (3) | % |
| Acquisitions and divestitures, net |  | (36) | % |
| Total % change in Net sales |  | (34) | % |

[0001783180-22-000056:mdna:106]
The organic increase in Net sales of 5% was primarily driven by pricing improvements compared with the prior year. The segment primarily saw growth in both residential and commercial sales in the Americas and Europe as sales in China decreased as a result of current economic conditions and reduced end-market demand. Global industrial sales also benefited segment results with pricing improvements and strong demand. While current demand remains strong, supply chain constraints continue to be challenging, negatively impacting our sales and results of operations. In addition, results for 2021 reflected a significant rebound in demand after initial weakness associated with the COVID-19 pandemic.

[0001783180-22-000056:mdna:107]
Acquisitions and divestitures, net primarily relates to the prior year results of our Chubb business, the sale of which was completed on January 3, 2022. During the three months ended September 30, 2021, Net sales in our Fire & Security segment were $1.4 billion, which included $520 million from our Chubb business. Absent the results of Chubb, Net sales increased 6% from $857 million to $905 million.

[0001783180-22-000056:mdna:108]
For the three months ended September 30, 2022, Operating profit in our Fire & Security segment was $142 million, a 22% decrease compared with the same period of 2021. The components of the year-over-year change were as follows:

[0001783180-22-000056:mdna:109]
|  |  | Operating Profit |
| Operational |  | 1 | % |
| Foreign currency translation |  | (2) | % |
| Acquisitions and divestitures, net |  | (19) | % |
| Restructuring |  | 1 | % |
| Other |  | (3) | % |
| Total % change in Operating profit |  | (22) | % |

[0001783180-22-000056:mdna:110]
The increase in operational profit of 1% was primarily attributable to pricing improvements compared with the prior year. In addition, productivity initiatives also benefited operational profit. These amounts were partially offset by the higher costs of commodities and components used in our products as well as higher freight and logistics costs.

[0001783180-22-000056:mdna:111]
[same as prior period, unchanged from 0001783180-22-000048:mdna:170]

[0001783180-22-000056:mdna:112]
Acquisitions and divestitures, net primarily relates to the prior year results of our Chubb business, the sale of which was completed on January 3, 2022. Amounts reported during the three months ended September 30, 2021 include $13 million of transaction costs associated with the divestiture. In addition, amounts reported in Other include a $7 million charge resulting from the settlement of working capital and other transaction-related items associated with the Chubb Sale.

[0001783180-22-000056:mdna:113]
Nine Months Ended September 30, 2022 Compared with Nine Months Ended September 30, 2021

[0001783180-22-000056:mdna:114]
| Summary performance for each of our segments is as follows: |
|  | Net Sales |  | Operating Profit |  | Operating Profit Margin |
|  | Nine Months Ended September 30, |  | Nine Months Ended September 30, |  | Nine Months Ended September 30, |
| (In millions) | 2022 |  | 2021 |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| HVAC | $ | 10,092 |  |  | $ | 8,660 |  |  | $ | 2,369 |  |  | $ | 1,511 |  |  | 23.5 | % |  | 17.4 | % |
| Refrigeration | 2,940 |  |  | 3,037 |  |  | 370 |  |  | 369 |  |  | 12.6 | % |  | 12.2 | % |
| Fire & Security | 2,610 |  |  | 4,084 |  |  | 1,494 |  |  | 480 |  |  | 57.2 | % |  | 11.8 | % |
| Total segment | $ | 15,642 |  |  | $ | 15,781 |  |  | $ | 4,233 |  |  | $ | 2,360 |  |  | 27.1 | % |  | 15.0 | % |

[0001783180-22-000056:mdna:115]
[same as prior period, unchanged from 0001783180-22-000048:mdna:114]

[0001783180-22-000056:mdna:116]
For the nine months ended September 30, 2022, Net sales in our HVAC segment were $10.1 billion, a 17% increase compared with the same period of 2021. The components of the year-over-year change were as follows:

[0001783180-22-000056:mdna:117]
|  |  | Net Sales |
| Organic |  | 13 | % |
| Acquisitions and divestitures, net |  | 6 | % |
| Other |  | (2) | % |
| Total % change in Net sales |  | 17 | % |

[0001783180-22-000056:mdna:118]
The organic increase in Net sales of 13% was driven by continued strong results across each of the segment's businesses. Increased sales in our North America residential and light commercial business (up 16%) were driven by pricing improvements and end-market demand. Increased sales in our Commercial HVAC business (up 8%) benefited from pricing improvements and ongoing customer demand in our end-markets. The business saw growth in each region including Asia as demand increased after a resurgence of COVID-19 cases and additional restrictions imposed earlier in the year. While current demand remains strong, supply chain and logistics constraints continue to be challenging, negatively impacting our sales and results of operations. In addition, results for 2021 reflected a significant rebound in demand after initial weakness associated with the COVID-19 pandemic.

[0001783180-22-000056:mdna:119]
On August 1, 2022, the Commercial HVAC business acquired a majority ownership interest in TCC, a VRF and light commercial HVAC joint venture between Carrier and Toshiba Corporation. The results of TCC have been included in our Unaudited Condensed Consolidated Financial Statements since the date of acquisition. The transaction added 5% to Net sales during the nine months ended September 30, 2022 and is included in Acquisitions and divestitures, net.

[0001783180-22-000056:mdna:120]
On June 1, 2021, the Commercial HVAC business acquired a 70% controlling interest in Guangdong Giwee Group and its subsidiaries ("Giwee") and subsequently acquired the remaining 30% ownership interest on September 7, 2021. Giwee is a China-based manufacturer offering a portfolio of HVAC products including variable refrigerant flow, modular chillers and light commercial air conditioners. The results of Giwee have been included in our Unaudited Condensed Consolidated Financial Statements since the date of acquisition. The transaction added 1% to Net sales during the nine months ended September 30, 2022 and is included in Acquisitions and divestitures, net.

[0001783180-22-000056:mdna:121]
For the nine months ended September 30, 2022, Operating profit in our HVAC segment was $2.4 billion, a 57% increase compared with the same period of 2021. The components of the year-over-year change were as follows:

[0001783180-22-000056:mdna:122]
|  |  |  | Operating Profit |
| Operational |  |  | 8 | % |
| Acquisitions and divestitures, net |  |  | (1) | % |
| Restructuring |  |  | 1 | % |
| Other |  |  | 49 | % |
| Total % change in Operating profit |  |  | 57 | % |

[0001783180-22-000056:mdna:123]
The operational profit increase of 8% was primarily attributable to pricing improvements compared with the prior year. Higher earnings from equity method investments in Asia and North America also benefited operational profit and included a $27 million gain on the sale of two minority owned subsidiaries by one of our joint ventures. These amounts were partially offset by the increase in our ownership interest in TCC on August 1, 2022. As a result, TCC is no longer accounted for under the equity method of accounting since the date of acquisition. In addition, productivity initiatives provided further benefits to operational profit. These amounts were partially offset by the higher costs of commodities and components used in our products as well as higher freight and logistic costs.

[0001783180-22-000056:mdna:124]
In connection with the TCC acquisition, the carrying value of our previously held TCC equity investments were recognized at fair value at the date of acquisition. As a result, we recognized a $732 million non-cash gain associated with the increase in our ownership interest in Other. In addition, amounts reported in Other include a $22 million charge resulting from a litigation matter recognized during the nine months ended September 30, 2022.

[0001783180-22-000056:mdna:125]
[same as prior period, unchanged from 0001783180-22-000048:mdna:123]

[0001783180-22-000056:mdna:126]
For the nine months ended September 30, 2022, Net sales in our Refrigeration segment were $2.9 billion, a 3% decrease compared with the same period of 2021. The components of the year-over-year change were as follows:

[0001783180-22-000056:mdna:127]
|  |  | Net Sales |
| Organic |  | 3 | % |
| Foreign currency translation |  | (6) | % |
| Total % change in Net sales |  | (3) | % |

[0001783180-22-000056:mdna:128]
The organic increase in Net sales of 3% was driven by strong demand across each of the segment's businesses. Commercial refrigeration sales increased (up 4%) primarily due to pricing improvements compared with the prior year. These amounts were partially offset by continued supply chain constraints. Transport refrigeration sales increased (up 2%) primarily due to pricing improvements and higher volumes associated with component availability during the period. The nine months ended September 30, 2021 reflected a significant rebound in demand associated with the cyclical decline that began in late 2019 as well as the demand for global transportation and COVID-19 vaccine-related cargo monitoring. While current demand remains strong, supply chain and logistics constraints continue to be challenging, negatively impacting our sales and results of operations.

[0001783180-22-000056:mdna:129]
For the nine months ended September 30, 2022, Operating profit in our Refrigeration segment was $370 million, flat compared with the same period of 2021. The components of the year-over-year change were as follows:

[0001783180-22-000056:mdna:130]
|  |  |  | Operating Profit |
| Operational |  |  | 6 | % |
| Foreign currency translation |  |  | (7) | % |
| Other |  |  | 1 | % |
| Total % change in Operating profit |  |  | — | % |

[0001783180-22-000056:mdna:131]
The increase in operational profit of 6% was primarily attributable to pricing improvements compared with the prior year. In addition, favorable productivity initiatives and lower selling, general and administrative costs further benefited operational profit. These amounts were partially offset by the higher costs of commodities and components used in our products and higher freight and logistic costs. Amounts reported in Other primarily represent a $7 million gain on the sale of our interest in a cost method investment during the nine months ended September 30, 2022.

[0001783180-22-000056:mdna:132]
42

[0001783180-22-000056:mdna:133]
[same as prior period, unchanged from 0001783180-22-000048:mdna:130]

[0001783180-22-000056:mdna:134]
For the nine months ended September 30, 2022, Net sales in our Fire & Security segment were $2.6 billion, a 36% decrease compared with the same period of 2021. The components of the year-over-year change were as follows:

[0001783180-22-000056:mdna:135]
|  |  | Net Sales |
| Organic |  | 4 | % |
| Foreign currency translation |  | (2) | % |
| Acquisitions and divestitures, net |  | (38) | % |
| Total % change in Net sales |  | (36) | % |

[0001783180-22-000056:mdna:136]
The organic increase in Net sales of 4% was primarily driven by pricing improvements compared with the prior year. The segment primarily saw growth in both residential and commercial sales in the Americas and Europe as sales in China decreased as a result of current economic conditions and reduced end-market demand. Global industrial sales also benefited segment results with pricing improvements and strong demand. While current demand remains strong, supply chain constraints continue to be challenging, negatively impacting our sales and results of operations. In addition, results for 2021 reflected a significant rebound in demand after initial weakness associated with the COVID-19 pandemic.

[0001783180-22-000056:mdna:137]
Acquisitions and divestitures, net primarily relates to the prior year results of our Chubb business, the sale of which was completed on January 3, 2022. During the nine months ended September 30, 2021, Net sales in our Fire & Security segment were $4.1 billion, which included $1.6 billion from our Chubb business. Absent the results of Chubb, Net sales increased 6% from $2.5 billion to $2.6 billion.

[0001783180-22-000056:mdna:138]
For the nine months ended September 30, 2022, Operating profit in our Fire & Security segment was $1.5 billion, a 211% increase compared with the same period of 2021. The components of the year-over-year change were as follows:

[0001783180-22-000056:mdna:139]
|  |  |  | Operating Profit |
| Operational |  |  | (5) | % |
| Foreign currency translation |  |  | (2) | % |
| Acquisitions and divestitures, net |  |  | (16) | % |
| Restructuring |  |  | 3 | % |
| Other |  |  | 231 | % |
| Total % change in Operating profit |  |  | 211 | % |

[0001783180-22-000056:mdna:140]
The decrease in operational profit of 5% was primarily attributable to the higher costs of commodities and components used in our products and higher freight and logistics costs. In addition, unfavorable mix and lower volumes further impacted results compared with the prior year. These amounts were partially offset by pricing improvements.

[0001783180-22-000056:mdna:141]
Acquisitions and divestitures, net primarily relates to the prior year results of our Chubb business, the sale of which was completed on January 3, 2022. Amounts reported during the nine months ended September 30, 2021 include $28 million of transaction costs associated with the divestiture. Amounts reported in Other represent the net gain on the Chubb Sale of $1.1 billion.

[0001783180-22-000056:mdna:142]
[same as prior period, unchanged from 0001783180-22-000048:mdna:141]

[0001783180-22-000056:mdna:143]
[same as prior period, unchanged from 0001783180-22-000048:mdna:142]

[0001783180-22-000056:mdna:144]
As of September 30, 2022, we had cash and cash equivalents of $3.0 billion, of which approximately 38% was held by our foreign subsidiaries. We manage our worldwide cash requirements by reviewing available funds and the cost effectiveness with which we can access funds held by foreign subsidiaries. On occasion, we are required to maintain cash deposits in connection

[0001783180-22-000056:mdna:145]
with contractual obligations related to acquisitions, divestitures or other legal obligations. As of September 30, 2022 and December 31, 2021, the amount of such restricted cash was approximately $6 million and $39 million, respectively.

[0001783180-22-000056:mdna:146]
We maintain a $2.0 billion unsecured, unsubordinated commercial paper program which can be used for general corporate purposes, including working capital and potential acquisitions. In addition, we maintain our $2.0 billion Revolving Credit Facility that matures on April 3, 2025 which supports our commercial paper borrowing program and cash requirements. The Revolving Credit Facility has a commitment fee of 0.125% that is charged on unused commitments. Borrowings under the Revolving Credit Facility are available in U.S. Dollars, Euros and Pounds Sterling and bear interest at a variable interest rate plus a ratings-based margin, which was 125 basis points as of September 30, 2022. As of September 30, 2022, we had no borrowings outstanding under our commercial paper program and our Revolving Credit Facility.

[0001783180-22-000056:mdna:147]
[same as prior period, unchanged from 0001783180-22-000048:mdna:145]

[0001783180-22-000056:mdna:148]
[same as prior period, unchanged from 0001783180-22-000048:mdna:146]

[0001783180-22-000056:mdna:149]
The Revolving Credit Facility and the indentures for the long-term notes contain affirmative and negative covenants customary for financings of these types, which among other things, limit our ability to incur additional liens, to make certain fundamental changes and to enter into sale and leaseback transactions. As of September 30, 2022, we were in compliance with the covenants under the agreements governing our outstanding indebtedness.

[0001783180-22-000056:mdna:150]
The following table presents our credit ratings and outlook as of September 30, 2022:

[0001783180-22-000056:mdna:151]
[same as prior period, unchanged from 0001783180-22-000048:mdna:149]

[0001783180-22-000056:mdna:152]
[same as prior period, unchanged from 0001783180-22-000048:mdna:150]

[0001783180-22-000056:mdna:153]
[same as prior period, unchanged from 0001783180-22-000048:mdna:151]

[0001783180-22-000056:mdna:154]
[same as prior period, unchanged from 0001783180-22-000048:mdna:152]

[0001783180-22-000056:mdna:155]
| (In millions) |  | September 30,2022 |  | December 31,2021 |
| Cash and cash equivalents |  | $ | 2,985 |  |  | $ | 2,987 |  |
| Total debt |  | $ | 8,889 |  |  | $ | 9,696 |  |
| Total equity |  | $ | 7,463 |  |  | $ | 7,094 |  |
| Net debt (total debt less cash and cash equivalents) |  | $ | 5,904 |  |  | $ | 6,709 |  |
| Total capitalization (total debt plus total equity) |  | $ | 16,352 |  |  | $ | 16,790 |  |
| Net capitalization (total debt plus total equity less cash and cash equivalents) |  | $ | 13,367 |  |  | $ | 13,803 |  |
| Total debt to total capitalization |  | 54 | % |  | 58 | % |
| Net debt to net capitalization |  | 44 | % |  | 49 | % |

[0001783180-22-000056:mdna:156]
44

[0001783180-22-000056:mdna:157]
[same as prior period, unchanged from 0001783180-22-000048:mdna:154]

[0001783180-22-000056:mdna:158]
Our short-term obligations primarily consist of current maturities of long-term debt. Our long-term obligations primarily consist of long-term notes with maturity dates ranging between 2025 and 2050. Interest payments related to long-term Notes are expected to approximate $247 million per year, reflecting an approximate weighted-average interest rate of 2.95%. Any borrowings from the Revolving Credit Facility are subject to variable interest rates. See Note 5 – Borrowings and Lines of Credit in the Notes to the accompanying Unaudited Condensed Consolidated Financial Statements for additional information regarding the terms of our long-term debt obligations.

[0001783180-22-000056:mdna:159]
[same as prior period, unchanged from 0001783180-22-000048:mdna:156]

[0001783180-22-000056:mdna:160]
On July 15, 2022, we entered into a five-year, JPY 54 billion (approximately $400 million) Japanese Term Loan Facility. Borrowings bear interest at a rate equal to the Tokyo Term Risk Free Rate plus 0.75%. In addition, it is subject to customary covenants including a covenant to maintain a maximum consolidated leverage ratio. On July 25, 2022, we borrowed JPY 54 billion under the Japanese Term Loan Facility and used the proceeds to fund a portion of the TCC acquisition and to pay related fees and expenses.

[0001783180-22-000056:mdna:161]
[same as prior period, unchanged from 0001783180-22-000048:mdna:158]

[0001783180-22-000056:mdna:162]
On January 3, 2022, we completed the Chubb Sale for net proceeds of $2.9 billion. Consistent with our capital allocation strategy, the net proceeds will be used to fund investments in organic and inorganic growth initiatives and capital returns to shareowners as well as for general corporate purposes. The sale agreement included several customary provisions to settle working capital and other transaction-related items as of the date of sale. During the three months ended September 30, 2022, the parties finalized these amounts in accordance with the terms of the sale agreement. See Note 16 - Divestitures for additional information.

[0001783180-22-000056:mdna:163]
On February 6, 2022, we entered into a binding agreement to acquire a majority ownership interest in TCC for $891 million. The transaction was completed on August 1, 2022, subject to customary closing conditions and funded through the Japanese Term Loan Facility as well as with cash on hand. Upon closing, Toshiba Corporation retained a 5% ownership interest in TCC. In addition, during the nine months ended September 30, 2022, we acquired other consolidated businesses and minority-owned businesses. The aggregate cash paid for acquisitions, net of cash acquired, totaled $43 million and was funded through cash on hand. See Note 15 – Acquisitions for additional information.

[0001783180-22-000056:mdna:164]
[same as prior period, unchanged from 0001783180-22-000048:mdna:162]

[0001783180-22-000056:mdna:165]
We may purchase our outstanding common stock from time to time subject to market conditions and at our discretion in the open market or through one or more other public or private transactions and subject to compliance with our obligations under certain tax agreements. In July 2021, our Board of Directors approved a $1.75 billion increase to our existing $350 million share repurchase program authorizing the repurchase of up to $2.1 billion of our outstanding common stock. During the nine months ended September 30, 2022, we repurchased 28.9 million shares of our common stock for an aggregate purchase price of $1.3 billion, which includes shares repurchased under the ASR Agreement. As of September 30, 2022, we have approximately $309 million remaining under the current authorization. In October 2022, our Board of Directors approved a $2.0 billion increase to our existing share repurchase program.

[0001783180-22-000056:mdna:166]
[same as prior period, unchanged from 0001783180-22-000048:mdna:164]

[0001783180-22-000056:mdna:167]
We paid dividends on common stock during the nine months ended September 30, 2022, totaling $384 million. In October 2022, the Board of Directors declared a dividend of $0.15 per share of common stock payable on November 21, 2022 to shareowners of record at the close of business on October 28, 2022.

[0001783180-22-000056:mdna:168]
45

[0001783180-22-000056:mdna:169]
[same as prior period, unchanged from 0001783180-22-000048:mdna:166]

[0001783180-22-000056:mdna:170]
|  |  | Nine Months Ended September 30, |
| (In millions) |  | 2022 |  | 2021 |
| Net cash flows provided by (used in): |  |  |  |  |
| Operating activities |  | $ | 620 |  |  | $ | 1,324 |  |
| Investing activities |  | 2,045 |  |  | (426) |  |
| Financing activities |  | (2,584) |  |  | (1,225) |  |
| Effect of foreign exchange rate changes on cash and cash equivalents |  | (115) |  |  | (15) |  |
| Net increase (decrease) in cash and cash equivalents and restricted cash |  | $ | (34) |  |  | $ | (342) |  |

[0001783180-22-000056:mdna:171]
Cash flows from operating activities primarily represent inflows and outflows associated with our operations. Primary activities include net income from operations adjusted for non-cash transactions, working capital changes and changes in other assets and liabilities. The year-over-year decrease in net cash provided by operating activities was primarily driven by higher working capital balances during the current period. Ongoing customer demand and an increase of safety stock due to supply chain constraints led to higher inventory balances. In addition, higher accounts receivable balances more than offset higher accounts payable balances.

[0001783180-22-000056:mdna:172]
Cash flows from investing activities primarily represent inflows and outflows associated with long-term assets. Primary activities include capital expenditures, acquisitions, divestitures and proceeds from the sale of fixed assets. During the nine months ended September 30, 2022, net cash provided by investing activities was $2.0 billion. The primary driver of the inflow related to the net proceeds from the Chubb Sale. This amount was partially offset by the acquisition of TCC and several other businesses and minority-owned businesses, which totaled $472 million, net of cash acquired and $213 million of capital expenditures. During the nine months ended September 30, 2021, net cash used in investing activities was $426 million. The primary driver of the outflow related to the acquisition of several businesses and a minority-owned business, which totaled $214 million, net of cash acquired and $206 million of capital expenditures.

[0001783180-22-000056:mdna:173]
Cash flows from financing activities primarily represent inflows and outflows associated with equity or borrowings. During the nine months ended September 30, 2022, net cash used in financing activities was $2.6 billion. The primary driver of the outflow related to the payment of $1.3 billion to repurchase shares of our common stock. In addition, we settled our tender offers for $1.15 billion and paid $384 million in dividends to our common shareowners. During the nine months ended September 30, 2021, net cash used in financing activities was $1.2 billion. The primary driver of the outflow related to the redemption of long-term notes of $500 million. In addition, we paid $313 million in dividends to our common shareowners and paid $275 million to repurchase shares of our common stock.
