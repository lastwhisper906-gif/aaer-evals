# CARR 8-K — 0001783180-22-000054 filed 2022-10-27

## item codes, every 8-K on or before 2022-10-27

- 2022-10-27 0001783180-22-000054 — 2.02, 7.01, 9.01
- 2022-09-29 0000950142-22-002805 — 5.02, 9.01
- 2022-07-28 0001783180-22-000045 — 2.02, 9.01
- 2022-04-28 0001783180-22-000032 — 2.02, 9.01
- 2022-04-15 0001783180-22-000024 — 5.07, 9.01
- 2022-02-08 0001783180-22-000008 — 2.02, 9.01
- 2022-02-07 0000950142-22-000510 — 8.01, 9.01
- 2022-01-03 0000950142-22-000023 — 8.01, 9.01
- 2021-12-17 0001783180-21-000071 — 5.02, 7.01, 9.01
- 2021-11-23 0001783180-21-000068 — 5.03, 9.01
- 2021-10-28 0001783180-21-000062 — 2.02, 9.01
- 2021-08-27 0001783180-21-000056 — 8.01
- 2021-07-30 0001783180-21-000053 — 1.01
- 2021-07-29 0001783180-21-000049 — 2.02, 8.01, 9.01
- 2021-07-27 0000950142-21-002448 — 8.01, 9.01
- 2021-07-15 0000950142-21-002362 — 5.02, 9.01
- 2021-06-09 0000950142-21-001885 — 5.02, 9.01
- 2021-04-29 0001783180-21-000029 — 2.02, 9.01
- 2021-04-22 0001140361-21-013889 — 5.02, 9.01
- 2021-04-20 0001783180-21-000021 — 5.07, 9.01
- 2021-04-19 0000950142-21-001308 — 8.01, 9.01
- 2021-02-09 0001783180-21-000009 — 2.02, 9.01
- 2021-02-05 0001140361-21-003513 — 8.01, 9.01
- 2020-12-23 0001140361-20-029419 — 7.01, 9.01
- 2020-12-22 0001140361-20-029097 — 8.01
- 2020-12-14 0001140361-20-028246 — 5.03, 9.01
- 2020-12-07 0001140361-20-027515 — 1.01, 7.01, 9.01
- 2020-10-29 0001783180-20-000063 — 2.02, 9.01
- 2020-10-19 0001140361-20-023241 — 5.02, 7.01, 9.01
- 2020-09-23 0001140361-20-021220 — 8.01, 9.01
- 2020-09-22 0001140361-20-021124 — 8.01, 9.01
- 2020-07-30 0001783180-20-000045 — 2.02, 9.01
- 2020-06-19 0001140361-20-014325 — 1.01, 2.03, 9.01
- 2020-06-16 0001140361-20-013880 — 8.01, 9.01
- 2020-06-03 0001140361-20-012939 — 1.01, 9.01
- 2020-05-08 0001783180-20-000013 — 2.02, 9.01
- 2020-04-03 0001140361-20-007888 — 1.01, 5.02, 5.03, 5.05, 7.01, 9.01
- 2020-03-16 0001140361-20-005868 — 8.01, 9.01

## late-filing notifications on or before 2022-10-27

- none on or before 2022-10-27

## item 2.02 — earnings release, exhibit 99.1

[0001783180-22-000054:8k_2_02:1]
EX-99
2
a99-q32022earningsexhibit.htm
EX-99

[0001783180-22-000054:8k_2_02:2]
Document

[0001783180-22-000054:8k_2_02:3]
Exhibit 99

[0001783180-22-000054:8k_2_02:4]
Carrier Reports Third Quarter 2022 Results

[0001783180-22-000054:8k_2_02:5]
Board approves $2 billion share repurchase authorization

[0001783180-22-000054:8k_2_02:6]
•Net sales up 2% versus 2021; organic sales up 8%

[0001783180-22-000054:8k_2_02:7]
•GAAP EPS of $1.53 and adjusted EPS of $0.70

[0001783180-22-000054:8k_2_02:8]
•Net cash flows from operating activities of $790 million; free cash flow of $699 million

[0001783180-22-000054:8k_2_02:9]
•Updating 2022 adjusted EPS* guidance range to $2.30 to $2.35 from $2.25 to $2.35

[0001783180-22-000054:8k_2_02:10]
•Updating 2022 free cash flow* guidance to ~$1.4 billion from ~$1.65 billion

[0001783180-22-000054:8k_2_02:11]
•Carrier’s Board authorizes $2 billion share repurchase program

[0001783180-22-000054:8k_2_02:12]
PALM BEACH GARDENS, Fla., October 27, 2022 – Carrier Global Corporation (NYSE:CARR), the leading global provider of healthy, safe, sustainable and intelligent building and cold chain solutions, reported another quarter of strong financial results and updated its full-year adjusted EPS outlook to the high-end of its prior guidance.

[0001783180-22-000054:8k_2_02:13]
“Carrier delivered another strong quarter,” said Carrier Chairman & CEO David Gitlin. “Our continued focus on innovation and digitally enabled lifecycle solutions provides differentiated outcomes to customers and positions us to benefit from compelling secular trends. Our strong aftermarket growth through the first nine months of the year further strengthens the resiliency of our business model. Our new share repurchase authorization demonstrates our confidence in Carrier’s long-term strategy and commitment to delivering shareholder value through disciplined capital allocation.”

[0001783180-22-000054:8k_2_02:14]
Third Quarter 2022 Results

[0001783180-22-000054:8k_2_02:15]
Carrier’s third quarter sales of $5.5 billion were up 2% compared to the prior year, despite the impact from the Chubb divestiture and foreign exchange. Organic sales grew 8% while the Chubb divestiture reduced sales by about 10%, acquisitions contributed 8% and currency translation reduced sales by 4%. The Toshiba Carrier Corporation acquisition

[0001783180-22-000054:8k_2_02:16]
1

[0001783180-22-000054:8k_2_02:17]
closed August 1st and represented substantially all the sales growth from acquisitions in the quarter.

[0001783180-22-000054:8k_2_02:18]
HVAC had another strong organic growth quarter with residential and light commercial sales up 12% and commercial HVAC growing 15%. Commercial HVAC continued to see strong order trends, up double digits for the seventh consecutive quarter. Refrigeration sales were down 1% organically due to supply shortages and a decline in Container sales. Organic sales for the Fire & Security segment were up 5%.

[0001783180-22-000054:8k_2_02:19]
GAAP operating profit in the quarter of $1.5 billion was up substantially due to a $732 million gain related to the acquisition of Toshiba Carrier Corporation. Adjusted operating profit of $861 million was flat compared to last year. Strong price realization helped mitigate continued supply chain challenges. Price/cost remained positive in the third quarter across all three segments.

[0001783180-22-000054:8k_2_02:20]
Net income was $1.3 billion and adjusted net income was $600 million. GAAP EPS was $1.53 and adjusted EPS was $0.70. Net cash flows from operating activities were $790 million and capital expenditures were $91 million, resulting in free cash flow of $699 million. Despite an improved free cash flow quarter, Carrier reduced full-year guidance from $1.65 billion to $1.4 billion as supply chain improvements are taking place later in the year than previously anticipated. During the third quarter, Carrier repurchased $247 million of its common stock.

[0001783180-22-000054:8k_2_02:21]
On October 25, 2022, Carrier Global Corporation's Board of Directors approved a $2 billion share repurchase authorization. Share repurchases will take place at the company’s discretion in the open market or through one or more other public or private transactions, subject to, among other things, market conditions, share price, compliance with securities laws and regulatory requirements and other factors. The stock repurchase authorization has no time limit and may be modified, suspended or discontinued at any time. With the remaining portion of the prior authorization, Carrier currently has about $2.3 billion of repurchase authorization. This authorization is a key component of the company's capital allocation plans, which also includes acquisitions and dividends to help position the company for strategic growth and to generate attractive shareowner returns.

[0001783180-22-000054:8k_2_02:22]
2

[0001783180-22-000054:8k_2_02:23]
Updated Full-Year 2022 Outlook**

[0001783180-22-000054:8k_2_02:24]
Carrier is announcing the following updated outlook for 2022.

[0001783180-22-000054:8k_2_02:25]
|  |  | Prior 2022 Outlook | Updated 2022 Outlook |  |  |
|  |  | ~$20.8B | ~$20.4B |  |  |
| Sales |  | Organic* up HSD | Organic* up HSD |  |  |
|  |  | FX ~(3%) | FX ~(4%) |  |  |
|  |  | Acq / Div, net ~(5%) | Acq / Div, net ~(5%) |  |  |
| Adjusted Operating Margin * |  | Up ~40 bps Y/Y | Up ~60 bps Y/Y |  |  |
| Adjusted EPS * |  | $2.25 - $2.35 | $2.30 - $2.35 |  |  |
| Free Cash Flow *1 |  | ~$1.65B | ~$1.4B |  |  |

[0001783180-22-000054:8k_2_02:26]
*Note: When the company provides expectations for organic sales, adjusted operating profit, adjusted operating margin, adjusted EPS and free cash flow on a forward-looking basis, a reconciliation of the differences between the non-GAAP expectations and the corresponding GAAP measures generally is not available without unreasonable effort. See “Use and Definitions of Non-GAAP Financial Measures” below for additional information.

[0001783180-22-000054:8k_2_02:27]
**As of October 27, 2022

[0001783180-22-000054:8k_2_02:28]
1Includes ~$200M in tax payments on Chubb gain

[0001783180-22-000054:8k_2_02:29]
Carrier excludes the impact of amortization of acquired intangibles from its non-GAAP financial measures including adjusted operating profit, adjusted net income and adjusted EPS. Amortization of acquired intangibles, a non-cash expense, is unrelated to our core operating performance and amounts can vary significantly depending on the number, timing and size of acquisitions, among other factors. We believe this adjustment provides investors meaningful information to better evaluate our operating performance between periods.

[0001783180-22-000054:8k_2_02:30]
Conference Call

[0001783180-22-000054:8k_2_02:31]
Carrier will host a webcast of its earnings conference call today, Thursday, October 27, 2022, at 7:30 a.m. ET. To access the webcast, visit the Events & Presentations section of the Carrier Investor Relations site at ir.carrier.com/news-and-events/events-and-presentations or to listen to the earnings call by phone, participants must pre-register at

[0001783180-22-000054:8k_2_02:32]
3

[0001783180-22-000054:8k_2_02:33]
Carrier Earnings Call Registration. All registrants will receive dial-in information and a PIN allowing access to the live call.

[0001783180-22-000054:8k_2_02:34]
Cautionary Statement

[0001783180-22-000054:8k_2_02:35]
This communication contains statements which, to the extent they are not statements of historical or present fact, constitute "forward-looking statements" under the securities laws. These forward-looking statements are intended to provide management's current expectations or plans for Carrier's future operating and financial performance, based on assumptions currently believed to be valid. Forward-looking statements can be identified by the use of words such as "believe," "expect," "expectations," "plans," "strategy," "prospects," "estimate," "project," "target," "anticipate," "will," "should," "see," "guidance," "outlook," "confident," "scenario" and other words of similar meaning in connection with a discussion of future operating or financial performance or the separation from United Technologies Corporation (the "Separation"), since renamed Raytheon Technologies Corporation. Forward-looking statements may include, among other things, statements relating to future sales, earnings, cash flow, results of operations, uses of cash, share repurchases, tax rates and other measures of financial performance or potential future plans, strategies or transactions of Carrier, the estimated costs associated with the Separation, Carrier's plans with respect to its indebtedness and other statements that are not historical facts. All forward-looking statements involve risks, uncertainties and other factors that may cause actual results to differ materially from those expressed or implied in the forward-looking statements. For additional information on identifying factors that may cause actual results to vary materially from those stated in forward-looking statements, see Carrier's reports on Forms 10-K, 10-Q and 8-K filed with or furnished to the U.S. Securities and Exchange Commission from time to time. Any forward-looking statement speaks only as of the date on which it is made, and Carrier assumes no obligation to update or revise such statement, whether as a result of new information, future events or otherwise, except as required by applicable law.

[0001783180-22-000054:8k_2_02:36]
Contact:

[0001783180-22-000054:8k_2_02:37]
Media Inquiries

[0001783180-22-000054:8k_2_02:38]
Ashley Barrie

[0001783180-22-000054:8k_2_02:39]
561-365-1260

[0001783180-22-000054:8k_2_02:40]
Ashley.Barrie@Carrier.com

[0001783180-22-000054:8k_2_02:41]
Investor Relations

[0001783180-22-000054:8k_2_02:42]
Sam Pearlstein

[0001783180-22-000054:8k_2_02:43]
561-365-2251

[0001783180-22-000054:8k_2_02:44]
Sam.Pearlstein@Carrier.com

[0001783180-22-000054:8k_2_02:45]
4

[0001783180-22-000054:8k_2_02:46]
SELECTED FINANCIAL DATA, NON-GAAP MEASURES AND DEFINITIONS

[0001783180-22-000054:8k_2_02:47]
Following are tables that present selected financial data of Carrier Global Corporation (“Carrier”). Also included are reconciliations of non-GAAP measures to their most comparable GAAP measures.

[0001783180-22-000054:8k_2_02:48]
Use and Definitions of Non-GAAP Financial Measures

[0001783180-22-000054:8k_2_02:49]
Carrier Global Corporation (“Carrier”) reports its financial results in accordance with accounting principles generally accepted in the United States ("GAAP"). We supplement the reporting of our financial information determined under GAAP with certain non-GAAP financial information. The non-GAAP information presented provides investors with additional useful information, but should not be considered in isolation or as substitutes for the related GAAP measures. Moreover, other companies may define non-GAAP measures differently, which limits the usefulness of these measures for comparisons with such other companies. We encourage investors to review our financial statements and publicly filed reports in their entirety and not to rely on any single financial measure. A reconciliation of the non-GAAP measures to the corresponding amounts prepared in accordance with GAAP appears in the tables in this Appendix. The tables provide additional information as to the items and amounts that have been excluded from the adjusted measures.

[0001783180-22-000054:8k_2_02:50]
Organic sales, adjusted operating profit, adjusted operating margin, incremental margins / earnings conversion, earnings before interest, taxes and depreciation and amortization (“EBITDA”), adjusted EBITDA, adjusted net income, adjusted earnings per share (“EPS”), adjusted interest expense, net, adjusted effective tax rate and net debt are non-GAAP financial measures.

[0001783180-22-000054:8k_2_02:51]
Organic sales represents consolidated net sales (a GAAP measure), excluding the impact of foreign currency translation, acquisitions and divestitures completed in the preceding twelve months and other significant items of a nonoperational nature (hereinafter referred to as “other significant items”). Adjusted operating profit represents operating profit (a GAAP measure), excluding restructuring costs, amortization of acquired intangibles and other significant items. Adjusted operating margin represents adjusted operating profit as a percentage of net sales (a GAAP measure). Incremental margins / earnings conversion represents the year-over-year change in adjusted operating profit divided by the year-over-year change in net sales. EBITDA represents net income attributable to common shareholders (a GAAP measure), adjusted for interest income and expense, income tax expense, and depreciation and amortization. Adjusted EBITDA represents EBITDA, as calculated above, excluding non-service pension benefit, non-controlling interest in subsidiaries’ earnings from operations, restructuring costs and other significant items. Adjusted net income represents net income attributable to common shareowners (a GAAP measure), excluding restructuring costs, amortization of acquired intangibles and other significant items. Adjusted EPS represents diluted earnings per share (a GAAP measure), excluding restructuring costs, amortization of acquired intangibles and other significant items. Adjusted interest expense, net represents interest expense (a GAAP measure) and interest income (a GAAP measure), net excluding other significant items. The adjusted effective tax rate represents the effective tax rate (a GAAP measure), excluding restructuring costs, amortization of acquired intangibles and other significant items. Net debt represents long-term debt (a GAAP measure) less cash and cash equivalents (a GAAP measure). For the business segments, when applicable, adjustments of operating profit and operating margins represent operating profit, excluding restructuring, amortization of acquired intangibles and other significant items.

[0001783180-22-000054:8k_2_02:52]
Free cash flow is a non-GAAP financial measure that represents net cash flows provided by operating activities (a GAAP measure) less capital expenditures. Management believes free cash flow is a useful measure of liquidity and an additional basis for assessing Carrier’s ability to fund its activities, including the financing of acquisitions, debt service, repurchases of Carrier's common stock and distribution of earnings to shareowners.

[0001783180-22-000054:8k_2_02:53]
Orders are contractual commitments with customers to provide specified goods or services for an agreed upon price and may not be subject to penalty if cancelled.

[0001783180-22-000054:8k_2_02:54]
When we provide our expectations for organic sales, adjusted operating profit, adjusted operating margin, adjusted interest expense, net, adjusted effective tax rate, incremental margins/earnings conversion, adjusted EPS and free cash flow on a forward-looking basis, a reconciliation of the differences between the non-GAAP expectations and the corresponding GAAP measures (expected net sales, operating profit, operating margin, interest expense, effective tax rate, incremental operating margin, diluted EPS and net cash flows provided by operating activities) generally is not available without unreasonable effort due to potentially high variability, complexity and low visibility as to the items that would be excluded from the GAAP measure in the relevant future period, such as unusual gains and losses, the ultimate outcome of pending litigation, fluctuations in foreign currency exchange rates, the impact and timing of potential acquisitions and divestitures, future restructuring costs, and other structural changes or their probable significance. The variability of the excluded items may have a significant, and potentially unpredictable, impact on our future GAAP results.

[0001783180-22-000054:8k_2_02:55]
5

[0001783180-22-000054:8k_2_02:56]
Carrier Global Corporation

[0001783180-22-000054:8k_2_02:57]
Condensed Consolidated Statement of Operations

[0001783180-22-000054:8k_2_02:58]
|  | (Unaudited) |
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
| (In millions, except per share amounts) | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Net sales |  |  |  |  |  |  |  |
| Product sales | $ | 4,891 |  |  | $ | 4,510 |  |  | $ | 13,723 |  |  | $ | 12,958 |  |
| Service sales | 560 |  |  | 831 |  |  | 1,593 |  |  | 2,522 |  |
| Total Net sales | 5,451 |  |  | 5,341 |  |  | 15,316 |  |  | 15,480 |  |
| Costs and expenses |  |  |  |  |  |  |  |
| Cost of products sold | (3,569) |  |  | (3,172) |  |  | (9,930) |  |  | (9,131) |  |
| Cost of services sold | (405) |  |  | (568) |  |  | (1,169) |  |  | (1,735) |  |
| Research and development | (143) |  |  | (123) |  |  | (390) |  |  | (369) |  |
| Selling, general and administrative | (624) |  |  | (748) |  |  | (1,839) |  |  | (2,304) |  |
| Total Costs and expenses | (4,741) |  |  | (4,611) |  |  | (13,328) |  |  | (13,539) |  |
| Equity method investment net earnings | 63 |  |  | 76 |  |  | 222 |  |  | 201 |  |
| Other income (expense), net | 753 |  |  | 22 |  |  | 1,872 |  |  | 40 |  |
| Operating profit | 1,526 |  |  | 828 |  |  | 4,082 |  |  | 2,182 |  |
| Non-service pension (expense) benefit | — |  |  | 14 |  |  | (2) |  |  | 51 |  |
| Interest (expense) income, net | (56) |  |  | (74) |  |  | (165) |  |  | (238) |  |
| Income from operations before income taxes | 1,470 |  |  | 768 |  |  | 3,915 |  |  | 1,995 |  |
| Income tax (expense) benefit | (138) |  |  | (288) |  |  | (609) |  |  | (626) |  |
| Net income from operations | 1,332 |  |  | 480 |  |  | 3,306 |  |  | 1,369 |  |
| Less: Non-controlling interest in subsidiaries' earnings from operations | 20 |  |  | 11 |  |  | 42 |  |  | 29 |  |
| Net income attributable to common shareowners | $ | 1,312 |  |  | $ | 469 |  |  | $ | 3,264 |  |  | $ | 1,340 |  |
| Earnings per share |  |  |  |  |  |  |  |
| Basic | $ | 1.56 |  |  | $ | 0.54 |  |  | $ | 3.86 |  |  | $ | 1.54 |  |
| Diluted | $ | 1.53 |  |  | $ | 0.53 |  |  | $ | 3.78 |  |  | $ | 1.50 |  |
| Weighted-average number of shares outstanding |  |  |  |  |  |  |  |
| Basic | 839.6 |  |  | 867.6 |  |  | 846.1 |  |  | 868.6 |  |
| Diluted | 856.5 |  |  | 892.0 |  |  | 864.3 |  |  | 890.9 |  |

[0001783180-22-000054:8k_2_02:59]
6

[0001783180-22-000054:8k_2_02:60]
Carrier Global Corporation

[0001783180-22-000054:8k_2_02:61]
Condensed Consolidated Balance Sheet

[0001783180-22-000054:8k_2_02:62]
|  |  | (Unaudited) |
| (In millions) |  | September 30, 2022 |  | December 31, 2021 |
| Assets |  |  |  |  |
| Cash and cash equivalents |  | $ | 2,985 |  |  | $ | 2,987 |  |
| Accounts receivable, net |  | 3,003 |  |  | 2,403 |  |
| Contract assets, current |  | 666 |  |  | 503 |  |
| Inventories, net |  | 2,664 |  |  | 1,970 |  |
| Assets held for sale |  | — |  |  | 3,168 |  |
| Other assets, current |  | 422 |  |  | 376 |  |
| Total current assets |  | 9,740 |  |  | 11,407 |  |
| Future income tax benefits |  | 619 |  |  | 563 |  |
| Fixed assets, net |  | 2,055 |  |  | 1,826 |  |
| Operating lease right-of-use assets |  | 625 |  |  | 640 |  |
| Intangible assets, net |  | 1,309 |  |  | 509 |  |
| Goodwill |  | 9,621 |  |  | 9,349 |  |
| Pension and post-retirement assets |  | 23 |  |  | 43 |  |
| Equity method investments |  | 1,151 |  |  | 1,593 |  |
| Other assets |  | 207 |  |  | 242 |  |
| Total Assets |  | $ | 25,350 |  |  | $ | 26,172 |  |
| Liabilities and Equity |  |  |  |  |
| Accounts payable |  | $ | 2,817 |  |  | $ | 2,334 |  |
| Accrued liabilities |  | 2,537 |  |  | 2,561 |  |
| Contract liabilities, current |  | 440 |  |  | 415 |  |
| Liabilities held for sale |  | — |  |  | 1,134 |  |
| Current portion of long-term debt |  | 219 |  |  | 183 |  |
| Total current liabilities |  | 6,013 |  |  | 6,627 |  |
| Long-term debt |  | 8,670 |  |  | 9,513 |  |
| Future pension and post-retirement obligations |  | 431 |  |  | 380 |  |
| Future income tax obligations |  | 522 |  |  | 354 |  |
| Operating lease liabilities |  | 514 |  |  | 527 |  |
| Other long-term liabilities |  | 1,737 |  |  | 1,677 |  |
| Total Liabilities |  | 17,887 |  |  | 19,078 |  |
| Equity |  |  |  |  |
| Common stock |  | 9 |  |  | 9 |  |
| Treasury stock |  | (1,791) |  |  | (529) |  |
| Additional paid-in capital |  | 5,463 |  |  | 5,411 |  |
| Retained earnings |  | 5,876 |  |  | 2,865 |  |
| Accumulated other comprehensive loss |  | (2,405) |  |  | (989) |  |
| Non-controlling interest |  | 311 |  |  | 327 |  |
| Total Equity |  | 7,463 |  |  | 7,094 |  |
| Total Liabilities and Equity |  | $ | 25,350 |  |  | $ | 26,172 |  |

[0001783180-22-000054:8k_2_02:63]
7

[0001783180-22-000054:8k_2_02:64]
Carrier Global Corporation

[0001783180-22-000054:8k_2_02:65]
Condensed Consolidated Statement of Cash Flows

[0001783180-22-000054:8k_2_02:66]
|  |  |  |  | (Unaudited) |
|  |  |  | Nine Months Ended September 30, |
| (In millions) |  |  |  |  | 2022 |  | 2021 |
| Operating Activities |  |  |  |  |  |  |  |
| Net income from operations |  |  |  |  | $ | 3,306 |  |  | $ | 1,369 |  |
| Adjustments to reconcile net income to net cash flows from operating activities: |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  |  |  | 257 |  |  | 251 |  |
| Deferred income tax provision |  |  |  |  | (107) |  |  | 69 |  |
| Stock-based compensation costs |  |  |  |  | 58 |  |  | 60 |  |
| Equity method investment net earnings |  |  |  |  | (222) |  |  | (201) |  |
| Impairment charge on minority-owned joint venture investments |  |  |  |  | — |  |  | 2 |  |
| (Gain) loss on extinguishment of debt |  |  |  |  | (36) |  |  | — |  |
| (Gain) loss on sale of investments |  |  |  |  | (1,844) |  |  | (4) |  |
| Changes in operating assets and liabilities |  |  |  |  |  |  |  |
| Accounts receivable, net |  |  |  |  | (433) |  |  | (290) |  |
| Contract assets, current |  |  |  |  | (201) |  |  | (66) |  |
| Inventories, net |  |  |  |  | (492) |  |  | (344) |  |
| Other assets, current |  |  |  |  | (3) |  |  | (20) |  |
| Accounts payable and accrued liabilities |  |  |  |  | 180 |  |  | 496 |  |
| Contract liabilities, current |  |  |  |  | 34 |  |  | 43 |  |
| Defined benefit plan contributions |  |  |  |  | (10) |  |  | (29) |  |
| Distributions from equity method investments |  |  |  |  | 55 |  |  | 65 |  |
| Other operating activities, net |  |  |  |  | 78 |  |  | (77) |  |
| Net cash flows provided by (used in) operating activities |  |  |  |  | 620 |  |  | 1,324 |  |
| Investing Activities |  |  |  |  |  |  |  |
| Capital expenditures |  |  |  |  | (213) |  |  | (206) |  |
| Investments in businesses, net of cash acquired |  |  |  |  | (472) |  |  | (214) |  |
| Disposition of businesses |  |  |  |  | 2,944 |  |  | 3 |  |
| Settlement of derivative contracts, net |  |  |  |  | (202) |  |  | (18) |  |
| Other investing activities, net |  |  |  |  | (12) |  |  | 9 |  |
| Net cash flows provided by (used in) investing activities |  |  |  |  | 2,045 |  |  | (426) |  |
| Financing Activities |  |  |  |  |  |  |  |
| Increase (decrease) in short-term borrowings, net |  |  |  |  | (125) |  |  | (17) |  |
| Issuance of long-term debt |  |  |  |  | 421 |  |  | 122 |  |
| Repayment of long-term debt |  |  |  |  | (1,185) |  |  | (692) |  |
| Repurchases of common stock |  |  |  |  | (1,261) |  |  | (275) |  |
| Dividends paid on common stock |  |  |  |  | (384) |  |  | (313) |  |
| Dividends paid to non-controlling interest |  |  |  |  | (22) |  |  | (32) |  |
| Other financing activities, net |  |  |  |  | (28) |  |  | (18) |  |
| Net cash flows provided by (used in) financing activities |  |  |  |  | (2,584) |  |  | (1,225) |  |
| Effect of foreign exchange rate changes on cash and cash equivalents |  |  |  |  | (115) |  |  | (15) |  |
| Net increase (decrease) in cash and cash equivalents and restricted cash |  |  |  |  | (34) |  |  | (342) |  |
| Less: Change in cash balances classified as assets held for sale |  |  |  |  | — |  |  | 74 |  |
| Cash, cash equivalents and restricted cash, beginning of period |  |  |  |  | 3,025 |  |  | 3,120 |  |
| Cash, cash equivalents and restricted cash, end of period |  |  |  |  | 2,991 |  |  | 2,704 |  |
| Less: restricted cash |  |  |  |  | 6 |  |  | 33 |  |
| Cash and cash equivalents, end of period |  |  |  |  | $ | 2,985 |  |  | $ | 2,671 |  |

[0001783180-22-000054:8k_2_02:67]
8

[0001783180-22-000054:8k_2_02:68]
Carrier Global Corporation

[0001783180-22-000054:8k_2_02:69]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP)

[0001783180-22-000054:8k_2_02:70]
Operating Profit

[0001783180-22-000054:8k_2_02:71]
|  | (Unaudited) |
|  | Three Months Ended September 30, 2022 |
| (In millions) | HVAC |  | Refrigeration |  | Fire & Security |  | Eliminations and Other |  | General Corporate Expenses |  | Carrier |
| Net sales | $ | 3,734 |  |  | $ | 923 |  |  | $ | 905 |  |  | $ | (111) |  |  | $ | — |  |  | $ | 5,451 |  |
| Segment operating profit | $ | 1,314 |  |  | $ | 116 |  |  | $ | 142 |  |  | $ | (10) |  |  | $ | (36) |  |  | $ | 1,526 |  |
| Reported operating margin | 35.2 | % |  | 12.6 | % |  | 15.7 | % |  |  |  |  |  | 28.0 | % |
| Adjustments to segment operating profit: |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring costs | $ | 2 |  |  | $ | 3 |  |  | $ | 1 |  |  | $ | — |  |  | $ | — |  |  | $ | 6 |  |
| Amortization of acquired intangibles (1) | 16 |  |  | — |  |  | 1 |  |  | — |  |  | — |  |  | 17 |  |
| Acquisition step-up amortization (2) | 24 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 24 |  |
| Acquisition-related costs | — |  |  | — |  |  | — |  |  | — |  |  | 15 |  |  | 15 |  |
| Chubb gain | — |  |  | — |  |  | 7 |  |  | — |  |  | — |  |  | 7 |  |
| TCC acquisition-related gain (3) | (732) |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (732) |  |
| Russia/Ukraine asset impairment | — |  |  | (1) |  |  | (1) |  |  | — |  |  | — |  |  | (2) |  |
| Total adjustments to operating profit | $ | (690) |  |  | $ | 2 |  |  | $ | 8 |  |  | $ | — |  |  | $ | 15 |  |  | $ | (665) |  |
| Adjusted operating profit | $ | 624 |  |  | $ | 118 |  |  | $ | 150 |  |  | $ | (10) |  |  | $ | (21) |  |  | $ | 861 |  |
| Adjusted operating margin | 16.7 | % |  | 12.8 | % |  | 16.6 | % |  |  |  |  |  | 15.8 | % |

[0001783180-22-000054:8k_2_02:72]
|  | (Unaudited) |
|  | Three Months Ended September 30, 2021 |
| (In millions) | HVAC |  | Refrigeration |  | Fire & Security |  | Eliminations and Other |  | General Corporate Expenses |  | Carrier |
| Net sales | $ | 3,054 |  |  | $ | 1,011 |  |  | $ | 1,377 |  |  | $ | (101) |  |  | $ | — |  |  | $ | 5,341 |  |
| Segment operating profit | $ | 573 |  |  | $ | 119 |  |  | $ | 182 |  |  | $ | (10) |  |  | $ | (36) |  |  | $ | 828 |  |
| Reported operating margin | 18.8 | % |  | 11.8 | % |  | 13.2 | % |  |  |  |  |  | 15.5 | % |
| Adjustments to segment operating profit: |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring costs | $ | 7 |  |  | $ | 2 |  |  | $ | 3 |  |  | $ | — |  |  | $ | 1 |  |  | $ | 13 |  |
| Amortization of acquired intangibles (1) | 7 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 7 |  |
| Acquisition step-up amortization (2) | 3 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 3 |  |
| Chubb transaction costs | — |  |  | — |  |  | 13 |  |  | — |  |  | 1 |  |  | 14 |  |
| Total adjustments to operating profit | $ | 17 |  |  | $ | 2 |  |  | $ | 16 |  |  | $ | — |  |  | $ | 2 |  |  | $ | 37 |  |
| Adjusted operating profit | $ | 590 |  |  | $ | 121 |  |  | $ | 198 |  |  | $ | (10) |  |  | $ | (34) |  |  | $ | 865 |  |
| Adjusted operating margin | 19.3 | % |  | 12.0 | % |  | 14.4 | % |  |  |  |  |  | 16.2 | % |

[0001783180-22-000054:8k_2_02:73]
(1) Beginning in Q3 2022, we exclude the impact of amortization of acquired intangibles from our non-GAAP financial measures including adjusted operating profit. Amortization of acquired intangibles, a non-cash expense, is unrelated to our core operating performance and amounts can vary significantly depending on the number, timing and size of acquisitions, among other factors. We believe this adjustment provides investors meaningful information to better evaluate our operating performance between periods. Historical periods have been updated to conform with the current period presentation.

[0001783180-22-000054:8k_2_02:74]
(2) Amortization of the step-up to fair value of acquired inventory and backlog.

[0001783180-22-000054:8k_2_02:75]
(3) The carrying value of our previously held TCC equity investments were recognized at fair value at the TCC acquisition date.

[0001783180-22-000054:8k_2_02:76]
9

[0001783180-22-000054:8k_2_02:77]
Carrier Global Corporation

[0001783180-22-000054:8k_2_02:78]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP)

[0001783180-22-000054:8k_2_02:79]
Operating Profit

[0001783180-22-000054:8k_2_02:80]
|  | (Unaudited) |
|  | Nine Months Ended September 30, 2022 |
| (In millions) | HVAC |  | Refrigeration |  | Fire & Security |  | Eliminations and Other |  | General Corporate Expenses |  | Carrier |
| Net sales | $ | 10,092 |  |  | $ | 2,940 |  |  | $ | 2,610 |  |  | $ | (326) |  |  | $ | — |  |  | $ | 15,316 |  |
| Segment operating profit | $ | 2,369 |  |  | $ | 370 |  |  | $ | 1,494 |  |  | $ | (50) |  |  | $ | (101) |  |  | $ | 4,082 |  |
| Reported operating margin | 23.5 | % |  | 12.6 | % |  | 57.2 | % |  |  |  |  |  | 26.7 | % |
| Adjustments to segment operating profit: |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring costs | $ | 8 |  |  | $ | 9 |  |  | $ | 10 |  |  | $ | — |  |  | $ | 2 |  |  | $ | 29 |  |
| Amortization of acquired intangibles (1) | 24 |  |  | — |  |  | 3 |  |  | — |  |  | — |  |  | 27 |  |
| Acquisition step-up amortization (2) | 24 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 24 |  |
| Acquisition-related costs | — |  |  | — |  |  | — |  |  | — |  |  | 28 |  |  | 28 |  |
| Chubb gain | — |  |  | — |  |  | (1,105) |  |  | — |  |  | — |  |  | (1,105) |  |
| TCC acquisition-related gain (3) | (732) |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (732) |  |
| Russia/Ukraine asset impairment | — |  |  | 3 |  |  | — |  |  | — |  |  | — |  |  | 3 |  |
| Charge resulting from legal matter | 22 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 22 |  |
| Total adjustments to operating profit | $ | (654) |  |  | $ | 12 |  |  | $ | (1,092) |  |  | $ | — |  |  | $ | 30 |  |  | $ | (1,704) |  |
| Adjusted operating profit | $ | 1,715 |  |  | $ | 382 |  |  | $ | 402 |  |  | $ | (50) |  |  | $ | (71) |  |  | $ | 2,378 |  |
| Adjusted operating margin | 17.0 | % |  | 13.0 | % |  | 15.4 | % |  |  |  |  |  | 15.5 | % |

[0001783180-22-000054:8k_2_02:81]
|  | (Unaudited) |
|  | Nine Months Ended September 30, 2021 |
| (In millions) | HVAC |  | Refrigeration |  | Fire & Security |  | Eliminations and Other |  | General Corporate Expenses |  | Carrier |
| Net sales | $ | 8,660 |  |  | $ | 3,037 |  |  | $ | 4,084 |  |  | $ | (301) |  |  | $ | — |  |  | $ | 15,480 |  |
| Segment operating profit | $ | 1,511 |  |  | $ | 369 |  |  | $ | 480 |  |  | $ | (73) |  |  | $ | (105) |  |  | $ | 2,182 |  |
| Reported operating margin | 17.4 | % |  | 12.2 | % |  | 11.8 | % |  |  |  |  |  | 14.1 | % |
| Adjustments to segment operating profit: |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring costs | $ | 18 |  |  | $ | 7 |  |  | $ | 23 |  |  | $ | — |  |  | $ | 4 |  |  | $ | 52 |  |
| Amortization of acquired intangibles (1) | 11 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 11 |  |
| Acquisition step-up amortization (2) | 5 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 5 |  |
| Chubb transaction costs | — |  |  | — |  |  | 28 |  |  | — |  |  | 1 |  |  | 29 |  |
| Separation costs | — |  |  | — |  |  | — |  |  | 19 |  |  | — |  |  | 19 |  |
| Total adjustments to operating profit | $ | 34 |  |  | $ | 7 |  |  | $ | 51 |  |  | $ | 19 |  |  | $ | 5 |  |  | $ | 116 |  |
| Adjusted operating profit | $ | 1,545 |  |  | $ | 376 |  |  | $ | 531 |  |  | $ | (54) |  |  | $ | (100) |  |  | $ | 2,298 |  |
| Adjusted operating margin | 17.8 | % |  | 12.4 | % |  | 13.0 | % |  |  |  |  |  | 14.8 | % |

[0001783180-22-000054:8k_2_02:82]
(1) Beginning in Q3 2022, we exclude the impact of amortization of acquired intangibles from our non-GAAP financial measures including adjusted operating profit. Amortization of acquired intangibles, a non-cash expense, is unrelated to our core operating performance and amounts can vary significantly depending on the number, timing and size of acquisitions, among other factors. We believe this adjustment provides investors meaningful information to better evaluate our operating performance between periods. Historical periods have been updated to conform with the current period presentation.

[0001783180-22-000054:8k_2_02:83]
(2) Amortization of the step-up to fair value of acquired inventory and backlog.

[0001783180-22-000054:8k_2_02:84]
(3) The carrying value of our previously held TCC equity investments were recognized at fair value at the TCC acquisition date.

[0001783180-22-000054:8k_2_02:85]
10

[0001783180-22-000054:8k_2_02:86]
Carrier Global Corporation

[0001783180-22-000054:8k_2_02:87]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP) Results

[0001783180-22-000054:8k_2_02:88]
Net Income, Earnings Per Share, and Effective Tax Rate

[0001783180-22-000054:8k_2_02:89]
|  | (Unaudited) |
|  | Three Months Ended September 30, 2022 |  | Nine Months Ended September 30, 2022 |
| (In millions, except per share amounts) | Reported |  | Adjustments |  | Adjusted |  | Reported |  | Adjustments |  | Adjusted |
| Net sales | $ | 5,451 |  |  | $ | — |  |  | $ | 5,451 |  |  | $ | 15,316 |  |  | $ | — |  |  | $ | 15,316 |  |
| Operating profit | $ | 1,526 |  |  | (665) |  | a | $ | 861 |  |  | $ | 4,082 |  |  | (1,704) |  | a | $ | 2,378 |  |
| Operating margin | 28.0 | % |  |  |  | 15.8 | % |  | 26.7 | % |  |  |  | 15.5 | % |
| Income from operations before income taxes | $ | 1,470 |  |  | (665) |  | a | $ | 805 |  |  | $ | 3,915 |  |  | (1,732) |  | a,b | $ | 2,183 |  |
| Income tax expense | $ | (138) |  |  | (47) |  | c | $ | (185) |  |  | $ | (609) |  |  | 148 |  | c | $ | (461) |  |
| Income tax rate | 9.4 | % |  |  |  | 23.0 | % |  | 15.6 | % |  |  |  | 21.1 | % |
| Net income attributable to common shareowners | $ | 1,312 |  |  | $ | (712) |  |  | $ | 600 |  |  | $ | 3,264 |  |  | $ | (1,584) |  |  | $ | 1,680 |  |
| Summary of Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring costs |  |  | $ | 6 |  | a |  |  |  |  | $ | 29 |  | a |  |
| Amortization of acquired intangibles (1) |  |  | 17 |  | a |  |  |  |  | 27 |  | a |  |
| Acquisition step-up amortization (2) |  |  | 24 |  | a |  |  |  |  | 24 |  | a |  |
| Acquisition-related costs |  |  | 15 |  | a |  |  |  |  | 28 |  | a |  |
| Chubb gain |  |  | 7 |  | a |  |  |  |  | (1,105) |  | a |  |
| TCC acquisition-related gain (3) |  |  | (732) |  | a |  |  |  |  | (732) |  | a |  |
| Russia/Ukraine asset impairment |  |  | (2) |  | a |  |  |  |  | 3 |  | a |  |
| Charge resulting from legal matter |  |  | — |  |  |  |  |  |  | 22 |  | a |  |
| Debt extinguishment (gain), net (4) |  |  | — |  |  |  |  |  |  | (28) |  | b |  |
| Total adjustments |  |  | $ | (665) |  |  |  |  |  |  | $ | (1,732) |  |  |  |
| Tax effect on adjustments above |  |  | $ | (15) |  |  |  |  |  |  | $ | 185 |  |  |  |
| Tax specific adjustments |  |  | (32) |  |  |  |  |  |  | (37) |  |  |  |
| Total tax adjustments |  |  | $ | (47) |  | c |  |  |  |  | $ | 148 |  | c |  |
| Shares outstanding - Diluted | 856.5 |  |  |  |  | 856.5 |  |  | 864.3 |  |  |  |  | 864.3 |  |
| Earnings per share - Diluted | $ | 1.53 |  |  |  |  | $ | 0.70 |  |  | $ | 3.78 |  |  |  |  | $ | 1.94 |  |

[0001783180-22-000054:8k_2_02:90]
(1) Beginning in Q3 2022, we exclude the impact of amortization of acquired intangibles from our non-GAAP financial measures including adjusted operating profit, adjusted net income and adjusted EPS. Amortization of acquired intangibles, a non-cash expense, is unrelated to our core operating performance and amounts can vary significantly depending on the number, timing and size of acquisitions, among other factors. We believe this adjustment provides investors meaningful information to better evaluate our operating performance between periods. Historical periods have been updated to conform with the current period presentation.

[0001783180-22-000054:8k_2_02:91]
(2) Amortization of the step-up to fair value of acquired inventory and backlog.

[0001783180-22-000054:8k_2_02:92]
(3) The carrying value of our previously held TCC equity investments were recognized at fair value at the TCC acquisition date.

[0001783180-22-000054:8k_2_02:93]
(4) The Company repurchased approximately $1.15 billion of aggregate principal senior notes on March 30, 2022 and recognized a net gain of $33 million and wrote-off $5 million of unamortized deferred financing costs in Interest (expense) income, net.

[0001783180-22-000054:8k_2_02:94]
11

[0001783180-22-000054:8k_2_02:95]
Carrier Global Corporation

[0001783180-22-000054:8k_2_02:96]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP) Results

[0001783180-22-000054:8k_2_02:97]
Net Income, Earnings Per Share, and Effective Tax Rate

[0001783180-22-000054:8k_2_02:98]
|  | (Unaudited) |
|  | Three Months Ended September 30, 2021 |  | Nine Months Ended September 30, 2021 |
| (In millions, except per share amounts) | Reported |  | Adjustments |  | Adjusted |  | Reported |  | Adjustments |  | Adjusted |
| Net sales | $ | 5,341 |  |  | $ | — |  |  | $ | 5,341 |  |  | $ | 15,480 |  |  | $ | — |  |  | $ | 15,480 |  |
| Operating profit | $ | 828 |  |  | 37 |  | a | $ | 865 |  |  | $ | 2,182 |  |  | 116 |  | a | $ | 2,298 |  |
| Operating margin | 15.5 | % |  |  |  | 16.2 | % |  | 14.1 | % |  |  |  | 14.8 | % |
| Income from operations before income taxes | $ | 768 |  |  | 37 |  | a,b | $ | 805 |  |  | $ | 1,995 |  |  | 135 |  | a,b | $ | 2,130 |  |
| Income tax expense | $ | (288) |  |  | 129 |  | c | $ | (159) |  |  | $ | (626) |  |  | 157 |  | c | $ | (469) |  |
| Income tax rate | 37.5 | % |  |  |  | 19.8 | % |  | 31.4 | % |  |  |  | 22.0 | % |
| Net income attributable to common shareowners | $ | 469 |  |  | $ | 166 |  |  | $ | 635 |  |  | $ | 1,340 |  |  | $ | 292 |  |  | $ | 1,632 |  |
| Summary of Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring costs |  |  | $ | 13 |  | a |  |  |  |  | $ | 52 |  | a |  |
| Amortization of acquired intangibles (1) |  |  | 7 |  | a |  |  |  |  | 11 |  | a |  |
| Acquisition step-up amortization (2) |  |  | 3 |  | a |  |  |  |  | 5 |  | a |  |
| Chubb transaction costs |  |  | 14 |  | a |  |  |  |  | 29 |  | a |  |
| Separation costs |  |  | — |  |  |  |  |  |  | 19 |  | a |  |
| Debt prepayment costs |  |  | — |  |  |  |  |  |  | 19 |  | b |  |
| Total adjustments |  |  | $ | 37 |  |  |  |  |  |  | $ | 135 |  |  |  |
| Tax effect on adjustments above |  |  | $ | (7) |  |  |  |  |  |  | $ | (22) |  |  |  |
| Tax specific adjustments |  |  | 136 |  |  |  |  |  |  | 179 |  |  |  |
| Total tax adjustments |  |  | $ | 129 |  | c |  |  |  |  | $ | 157 |  | c |  |
| Shares outstanding - Diluted | 892.0 |  |  |  |  | 892.0 |  |  | 890.9 |  |  |  |  | 890.9 |  |
| Earnings per share - Diluted | $ | 0.53 |  |  |  |  | $ | 0.71 |  |  | $ | 1.50 |  |  |  |  | $ | 1.84 |  |

[0001783180-22-000054:8k_2_02:99]
(1) Beginning in Q3 2022, we exclude the impact of amortization of acquired intangibles from our non-GAAP financial measures including adjusted operating profit, adjusted net income and adjusted EPS. Amortization of acquired intangibles, a non-cash expense, is unrelated to our core operating performance and amounts can vary significantly depending on the number, timing and size of acquisitions, among other factors. We believe this adjustment provides investors meaningful information to better evaluate our operating performance between periods. Historical periods have been updated to conform with the current period presentation.

[0001783180-22-000054:8k_2_02:100]
(2) Amortization of the step-up to fair value of acquired inventory and backlog.

[0001783180-22-000054:8k_2_02:101]
12

[0001783180-22-000054:8k_2_02:102]
Carrier Global Corporation

[0001783180-22-000054:8k_2_02:103]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP) Results

[0001783180-22-000054:8k_2_02:104]
Components of Changes in Net Sales

[0001783180-22-000054:8k_2_02:105]
| Three Months Ended September 30, 2022 Compared with Three Months Ended September 30, 2021 |
|  | (Unaudited) |
|  | Factors Contributing to Total % change in Net Sales |
|  | Organic |  | FX Translation |  | Acquisitions / Divestitures, net |  | Other |  | Total |
| HVAC | 13 | % |  | (3) | % |  | 12 | % |  | — | % |  | 22 | % |
| Refrigeration | (1) | % |  | (8) | % |  | — | % |  | — | % |  | (9) | % |
| Fire & Security | 5 | % |  | (3) | % |  | (36) | % |  | — | % |  | (34) | % |
| Consolidated | 8 | % |  | (4) | % |  | (2) | % |  | — | % |  | 2 | % |

[0001783180-22-000054:8k_2_02:106]
| Nine Months Ended September 30, 2022 Compared with Nine Months Ended September 30, 2021 |
|  | (Unaudited) |
|  | Factors Contributing to Total % change in Net Sales |
|  | Organic |  | FX Translation |  | Acquisitions / Divestitures, net |  | Other |  | Total |
| HVAC | 13 | % |  | — | % |  | 6 | % |  | (2) | % |  | 17 | % |
| Refrigeration | 3 | % |  | (6) | % |  | — | % |  | — | % |  | (3) | % |
| Fire & Security | 4 | % |  | (2) | % |  | (38) | % |  | — | % |  | (36) | % |
| Consolidated | 9 | % |  | (3) | % |  | (7) | % |  | — | % |  | (1) | % |

[0001783180-22-000054:8k_2_02:107]
Net Sales Excluding Impact of Chubb

[0001783180-22-000054:8k_2_02:108]
|  | (Unaudited) |
|  | Three Months Ended September 30, 2021 |  | Nine Months Ended September 30, 2021 |
|  | Carrier |  | Fire and Security |  | Carrier |  | Fire and Security |
| Net Sales: |  |  |  |  |  |  |  |
| Reported | $ | 5,341 |  |  | $ | 1,377 |  |  | $ | 15,480 |  |  | $ | 4,084 |  |
| Chubb | (520) |  |  | (520) |  |  | (1,622) |  |  | (1,622) |  |
| Net sales excluding impact of Chubb | $ | 4,821 |  |  | $ | 857 |  |  | $ | 13,858 |  |  | $ | 2,462 |  |
| Percentage increase in Net sales excluding impact of Chubb | 13 | % |  | 6 | % |  | 11 | % |  | 6 | % |

[0001783180-22-000054:8k_2_02:109]
13

[0001783180-22-000054:8k_2_02:110]
Carrier Global Corporation

[0001783180-22-000054:8k_2_02:111]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP) Results

[0001783180-22-000054:8k_2_02:112]
Historical Amounts of Amortization of Acquired Intangibles

[0001783180-22-000054:8k_2_02:113]
|  |  | (Unaudited) |
|  |  | Q1 |  | Q2 |  | Q3 |  | Q4 |  | FY |  | Q1 |  | Q2 |  | Q3 |
| (In millions) |  | 2021 |  | 2021 |  | 2021 |  | 2021 |  | 2021 |  | 2022 |  | 2022 |  | 2022 |
| HVAC |  | $ | — |  |  | $ | 4 |  |  | $ | 7 |  |  | $ | 4 |  |  | $ | 15 |  |  | $ | 4 |  |  | $ | 4 |  |  | $ | 16 |  |
| Fire & Security |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 1 |  |  | 1 |  |  | 1 |  |
| Total Carrier |  | — |  |  | 4 |  |  | 7 |  |  | 4 |  | 15 |  |  | 5 |  |  | 5 |  |  | 17 |  |
| Associated tax effect |  | — |  |  | (1) |  |  | (2) |  |  | (1) |  |  | (4) |  |  | (1) |  |  | (1) |  |  | (7) |  |
| Net impact to adjusted results |  | $ | — |  |  | $ | 3 |  |  | $ | 5 |  |  | $ | 3 |  |  | $ | 11 |  |  | $ | 4 |  |  | $ | 4 |  |  | $ | 10 |  |

[0001783180-22-000054:8k_2_02:114]
Free Cash Flow Reconciliation

[0001783180-22-000054:8k_2_02:115]
|  |  | (Unaudited) |
|  |  | Q1 |  | Q2 |  | Q3 |  | Q4 |  | FY |  | Q1 |  | Q2 |  | Q3 |  |  |
| (In millions) |  | 2021 |  | 2021 |  | 2021 |  | 2021 |  | 2021 |  | 2022 |  | 2022 |  | 2022 |  |  |
| Net cash flows provided by (used in) operating activities |  | $ | 184 |  |  | $ | 561 |  |  | $ | 579 |  |  | $ | 913 |  |  | $ | 2,237 |  |  | $ | (202) |  |  | $ | 32 |  |  | $ | 790 |  |  |  |
| Less: Capital expenditures |  | 53 |  |  | 79 |  |  | 74 |  |  | 138 |  | 344 |  |  | 56 |  |  | 66 |  |  | 91 |  |  |  |
| Free cash flow |  | $ | 131 |  |  | $ | 482 |  |  | $ | 505 |  |  | $ | 775 |  |  | $ | 1,893 |  |  | $ | (258) |  |  | $ | (34) |  |  | $ | 699 |  |  |  |

[0001783180-22-000054:8k_2_02:116]
Net Debt Reconciliation

[0001783180-22-000054:8k_2_02:117]
|  |  | (Unaudited) |
| (In millions) |  | September 30, 2022 |  | December 31, 2021 |
| Long-term debt |  | $ | 8,670 |  |  | $ | 9,513 |  |
| Current portion of long-term debt |  | 219 |  |  | 183 |  |
| Less: Cash and cash equivalents |  | 2,985 |  |  | 2,987 |  |
| Net debt |  | $ | 5,904 |  |  | $ | 6,709 |  |

[0001783180-22-000054:8k_2_02:118]
14
