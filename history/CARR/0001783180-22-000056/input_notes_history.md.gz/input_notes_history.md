# CARR note change history — 0001783180-22-000048 → 0001783180-22-000056


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-10-27):
[0001783180-22-000056:note_history:1]
| (In millions) |  | September 30,2022 |  | December 31, 2021 |
| Environmental reserves included in Accrued liabilities |  | $ | 29 |  |  | $ | 29 |  |
| Environmental reserves included in Other long-term liabilities |  | 203 |  |  | 191 |  |
| Total Environmental reserves |  | $ | 232 |  |  | $ | 220 |  |
  (was, 2022-07-28, similarity 0.976):
[0001783180-22-000048:note_history:1]
| (In millions) |  | June 30,2022 |  | December 31, 2021 |
| Environmental reserves included in Accrued liabilities |  | $ | 29 |  |  | $ | 29 |  |
| Environmental reserves included in Other long-term liabilities |  | 187 |  |  | 191 |  |
| Total Environmental reserves |  | $ | 216 |  |  | $ | 220 |  |

- changed (2022-10-27):
[0001783180-22-000056:note_history:2]
The Company has been named as a defendant in lawsuits alleging personal injury as a result of exposure to asbestos allegedly integrated into certain Carrier products or business premises. While the Company has never manufactured asbestos and no longer incorporates it into any currently-manufactured products, certain products that the Company no longer manufactures contained components incorporating asbestos. A substantial majority of these asbestos-related claims have been dismissed without payment or have been covered in full or in part by insurance or other forms of indemnity. Additional cases were litigated and settled without any insurance reimbursement. The amounts involved in asbestos-related claims were not material individually or in the aggregate in any period.
  (was, 2022-07-28, similarity 0.6924):
[0001783180-22-000048:note_history:2]
contained components incorporating asbestos. A substantial majority of these asbestos-related claims have been dismissed without payment or have been covered in full or in part by insurance or other forms of indemnity. Additional cases were litigated and settled without any insurance reimbursement. The amounts involved in asbestos-related claims were not material individually or in the aggregate in any period.

- changed (2022-10-27):
[0001783180-22-000056:note_history:3]
The Company's asbestos liabilities and related insurance recoveries are as follows:
  (was, 2022-07-28, similarity 0.939):
[0001783180-22-000048:note_history:3]
The Company had asbestos liabilities and related insurance recoveries as follows:

- changed (2022-10-27):
[0001783180-22-000056:note_history:4]
| (In millions) |  | September 30,2022 |  | December 31,2021 |
| Asbestos liabilities included in Accrued liabilities |  | $ | 17 |  |  | $ | 17 |  |
| Asbestos liabilities included in Other long-term liabilities |  | 214 |  |  | 220 |  |
| Total Asbestos liabilities |  | $ | 231 |  |  | $ | 237 |  |
| Asbestos-related recoveries included in Other assets, current |  | $ | 5 |  |  | $ | 5 |  |
| Asbestos-related recoveries included in Other assets |  | 91 |  |  | 93 |  |
| Total Asbestos-related recoveries |  | $ | 96 |  |  | $ | 98 |  |
  (was, 2022-07-28, similarity 0.9867):
[0001783180-22-000048:note_history:4]
| (In millions) |  | June 30,2022 |  | December 31,2021 |
| Asbestos liabilities included in Accrued liabilities |  | $ | 17 |  |  | $ | 17 |  |
| Asbestos liabilities included in Other long-term liabilities |  | 215 |  |  | 220 |  |
| Total Asbestos liabilities |  | $ | 232 |  |  | $ | 237 |  |
| Asbestos-related recoveries included in Other assets, current |  | $ | 5 |  |  | $ | 5 |  |
| Asbestos-related recoveries included in Other assets |  | 92 |  |  | 93 |  |
| Total Asbestos-related recoveries |  | $ | 97 |  |  | $ | 98 |  |

- changed (2022-10-27):
[0001783180-22-000056:note_history:5]
The amounts recorded for asbestos-related liabilities are based on currently available information and assumptions that the Company believes are reasonable and are made with input from outside actuarial experts. These amounts are undiscounted and
  (was, 2022-07-28, similarity 0.7039):
[0001783180-22-000048:note_history:5]
The amounts recorded for asbestos-related liabilities are based on currently available information and assumptions that the Company believes are reasonable and are made with input from outside actuarial experts. These amounts are undiscounted and exclude the Company’s legal fees to defend the asbestos claims, which are expensed as incurred. In addition, the Company has recorded insurance recovery receivables for probable asbestos-related recoveries.

- added (2022-10-27):
[0001783180-22-000056:note_history:6]
exclude the Company’s legal fees to defend the asbestos claims, which are expensed as incurred. In addition, the Company has recorded insurance recovery receivables for probable asbestos-related recoveries.

- changed (2022-10-27):
[0001783180-22-000056:note_history:7]
On August 12, 2020, several former employees of UTC or its subsidiaries filed a putative class action complaint (the "Complaint") in the United States District Court for the District of Connecticut against Raytheon Technologies Corporation, Carrier, Otis, the former members of the UTC Board of Directors and the members of the Carrier and Otis Boards of Directors (Geraud Darnis, et al. v. Raytheon Technologies Corporation, et al.). The Complaint challenges the method by which UTC equity awards were converted to UTC, Carrier and Otis equity awards following the Separation and the Distribution. Defendants moved to dismiss the Complaint. Plaintiffs amended their Complaint on September 13, 2021 (the "Amended Complaint"). The Amended Complaint, now with Raytheon, Carrier and Otis as the only defendants, asserts that the defendants are liable for breach of certain equity compensation plans and for breach of the implied covenant of good faith and fair dealing. The Amended Complaint also seeks specific performance. Carrier believes that the claims against the Company are without merit. Defendants moved to dismiss the Amended Complaint on October 13, 2021. The motion to dismiss was fully briefed as of December 3, 2021 and the court held oral argument on the motion on July 14, 2022. On September 30, 2022, the court dismissed the complaint against all defendants, with prejudice. The court entered judgment for the defendants on October 4, 2022. The deadline for seeking appellate review of the ruling is November 3, 2022.
  (was, 2022-07-28, similarity 0.9187):
[0001783180-22-000048:note_history:7]
On August 12, 2020, several former employees of UTC or its subsidiaries filed a putative class action complaint (the "Complaint") in the United States District Court for the District of Connecticut against Raytheon Technologies Corporation, Carrier, Otis, the former members of the UTC Board of Directors and the members of the Carrier and Otis Boards of Directors (Geraud Darnis, et al. v. Raytheon Technologies Corporation, et al.). The Complaint challenges the method by which UTC equity awards were converted to UTC, Carrier and Otis equity awards following the Separation and the Distribution. Defendants moved to dismiss the Complaint. Plaintiffs amended their Complaint on September 13, 2021 (the "Amended Complaint"). The Amended Complaint, now with Raytheon, Carrier and Otis as the only defendants, asserts that the defendants are liable for breach of certain equity compensation plans and for breach of the implied covenant of good faith and fair dealing. The Amended Complaint also seeks specific performance. Carrier believes that the claims against the Company are without merit. Defendants moved to dismiss the Amended Complaint on October 13, 2021. The motion to dismiss was fully briefed as of December 3, 2021 and the court held oral argument on the motion on July 14, 2022.

- changed (2022-10-27):
[0001783180-22-000056:note_history:8]
As of September 30, 2022, the Company has been named as a defendant in more than 2,800 lawsuits filed by individuals in or removed to the federal courts of the United States alleging that the historic use of Aqueous Film Forming Foam ("AFFF") caused personal injuries and/or property damage. The Company has also been named as a defendant in more than 250 lawsuits filed by several U.S. states, municipalities and water utilities in or removed to U.S. federal courts alleging that the historic use of AFFF caused contamination of property and water supplies. In December 2018, the U.S. Judicial Panel on Multidistrict Litigation transferred and consolidated all AFFF cases pending in the U.S. federal courts against the Company and others to the U.S. District Court for the District of South Carolina ("MDL Court") for pre-trial proceedings ("MDL Proceedings"). The individual plaintiffs in the MDL Proceedings generally seek damages for alleged personal injuries, medical monitoring and diminution in property value and injunctive relief to remediate alleged contamination of water supplies. The U.S. state, municipal and water utility plaintiffs in the MDL Proceedings generally seek damages and costs related to the remediation of public property and water supplies.
  (was, 2022-07-28, similarity 0.9948):
[0001783180-22-000048:note_history:8]
As of June 30, 2022, the Company has been named as a defendant in more than 2,400 lawsuits filed by individuals in or removed to the federal courts of the United States alleging that the historic use of Aqueous Film Forming Foam ("AFFF") caused personal injuries and/or property damage. The Company has also been named as a defendant in more than 200 lawsuits filed by several U.S. states, municipalities and water utilities in or removed to U.S. federal courts alleging that the historic use of AFFF caused contamination of property and water supplies. In December 2018, the U.S. Judicial Panel on Multidistrict Litigation transferred and consolidated all AFFF cases pending in the U.S. federal courts against the Company and others to the U.S. District Court for the District of South Carolina ("MDL Court") for pre-trial proceedings ("MDL Proceedings"). The individual plaintiffs in the MDL Proceedings generally seek damages for alleged personal injuries, medical monitoring and diminution in property value and injunctive relief to remediate alleged contamination of water supplies. The U.S. state, municipal and water utility plaintiffs in the MDL Proceedings generally seek damages and costs related to the remediation of public property and water supplies.

- changed (2022-10-27):
[0001783180-22-000056:note_history:9]
AFFF is a firefighting foam, developed beginning in the late 1960s pursuant to U.S. military specification, used to extinguish certain types of hydrocarbon-fueled fires primarily at military bases and airports. AFFF was manufactured by several companies, including National Foam and Angus Fire. UTC first entered the AFFF business with the acquisition of National Foam and Angus Fire in 2005 as part of the acquisition of Kidde. In 2013, Kidde divested the National Foam and Angus Fire businesses to a third party. The Company acquired Kidde as part of its separation from UTC in April 2020. During the eight-year period of its operation by Kidde, National Foam manufactured AFFF for sale to government (including the U.S. federal government) and non-government customers in the U.S. at a single facility located in West Chester, Pennsylvania ("Pennsylvania Site"). During the same period, Angus Fire manufactured AFFF for sale outside the United States at a single facility located in Bentham, England.
  (was, 2022-07-28, similarity 0.9114):
[0001783180-22-000048:note_history:9]
AFFF is a firefighting foam, developed beginning in the late 1960s pursuant to U.S. military specification, used to extinguish certain types of hydrocarbon-fueled fires primarily at military bases and airports. AFFF was manufactured by several companies, including National Foam and Angus Fire. UTC first entered the AFFF business with the acquisition of National Foam and Angus Fire in 2005 as part of the acquisition of Kidde. In 2013, Kidde divested the National Foam and Angus Fire businesses to a third party. The Company acquired Kidde as part of its separation from UTC in April 2020. During the eight-year period of its operation by Kidde, National Foam manufactured AFFF for sale to government (including the U.S. federal government) and non-government customers in the U.S. at a single facility located in West Chester, Pennsylvania

- added (2022-10-27):
[0001783180-22-000056:note_history:10]
Plaintiffs in the MDL Proceedings allege that PFOS and PFOA contamination has resulted from the use of AFFF manufactured using a process known as ECF, and that this process was used exclusively by 3M. They also allege that PFOA contamination has resulted from the use of AFFF manufactured using a different process, known as telomerization, and that this process was used exclusively by the other AFFF manufacturers (including National Foam and Angus Fire). Compounds containing PFOS and PFOA (as well as many other per- and polyfluoroalkyl substances known collectively as "PFAS") have also been used for decades by many third parties in a number of different industries to manufacture firefighters’ protective outerwear, carpets, clothing, fabrics, cookware, food packaging, personal care products, cleaning products, paints, varnishes and other consumer and industrial products.

- added (2022-10-27):
[0001783180-22-000056:note_history:11]
The defendants moved for summary judgment on the government contractor defense, which potentially applies to AFFF sold to or used by the U.S. government. After full briefing and oral argument, on September 16, 2022, the MDL court declined to enter summary judgment for the defendants. The defense, however, remains available at any trial to which it applies.

- added (2022-10-27):
[0001783180-22-000056:note_history:12]
On September 23, 2022, after completion of discovery, the MDL court selected one water provider case, the City of Stuart, FL v. 3M, et al., for a bellwether trial. That trial is tentatively scheduled for June 2023. The court has set a briefing schedule for case-specific summary judgment motions and other pretrial motions. That briefing is expected to conclude in February 2023. The MDL court has ordered that the bellwether process for personal injury cases will begin in 2023. The court has not yet outlined details on that process or its timing.

- added (2022-10-27):
[0001783180-22-000056:note_history:13]
The Company and other defendants are also party to one action in Arizona state court brought by a firefighter claiming that occupational exposure to AFFF has caused him certain personal injuries. That case is not eligible for transfer to the MDL at this time. The Company believes that it has meritorious defenses to the claims in the MDL Proceedings and the other AFFF lawsuits. Based on the 2013 agreement for the sale of National Foam and Angus Fire, the Company is pursuing indemnification against these claims from the purchaser and current owner of National Foam and Angus Fire. The Company also is pursuing insurance coverage for these claims. At this time, however, given the numerous factual, scientific and legal issues to be resolved relating to these claims, the Company is unable to assess the probability of liability or to reasonably estimate the damages, if any, to be allocated to the Company, if one or more plaintiffs were to prevail in these cases. There can be no assurance that any such future exposure will not be material in any period.

- changed (2022-10-27):
[0001783180-22-000056:note_history:14]
Under the Tax Matters Agreement relating to the Separation, the Company is responsible to UTC for its share of the Tax Cuts and Jobs Act ("TCJA") transition tax associated with foreign undistributed earnings as of December 31, 2017. As a result, liabilities of $34 million and $383 million are included within the accompanying Unaudited Condensed Consolidated Balance Sheet within Accrued Liabilities and Other Long-Term Liabilities as of September 30, 2022, respectively. This obligation is expected to be settled in annual installments ending in April 2026 with the next installment of $34 million due in 2023. The Company believes that the likelihood of incurring losses materially in excess of this amount is remote.
  (was, 2022-07-28, similarity 0.9906):
[0001783180-22-000048:note_history:14]
Under the Tax Matters Agreement relating to the Separation, the Company is responsible to UTC for its share of the Tax Cuts and Jobs Act ("TCJA") transition tax associated with foreign undistributed earnings as of December 31, 2017. As a result, liabilities of $34 million and $383 million are included within the accompanying Unaudited Condensed Consolidated Balance Sheet within Accrued Liabilities and Other Long-Term Liabilities as of June 30, 2022, respectively. This obligation is expected to be settled in annual installments ending in April 2026 with the next installment of $34 million due in 2023. The Company believes that the likelihood of incurring losses materially in excess of this amount is remote.

- changed (2022-10-27):
[0001783180-22-000056:note_history:15]
The Company has other commitments and contingent liabilities related to legal proceedings, self-insurance programs and matters arising in the ordinary course of business. The Company accrues for contingencies generally based upon a range of possible outcomes. If no amount within the range is a better estimate than any other, the Company accrues the minimum amount.
  (was, 2022-07-28, similarity 0.7921):
[0001783180-22-000048:note_history:15]
The Company has other commitments and contingent liabilities related to legal proceedings, self-insurance programs and matters arising in the ordinary course of business. The Company accrues for contingencies generally based upon a range of

- removed (2022-10-27):
[0001783180-22-000048:note_history:16]
The Company has been named as a defendant in lawsuits alleging personal injury as a result of exposure to asbestos allegedly integrated into certain Carrier products or business premises. While the Company has never manufactured asbestos and no longer incorporates it into any currently-manufactured products, certain products that the Company no longer manufactures

- removed (2022-10-27):
[0001783180-22-000048:note_history:17]
("Pennsylvania Site"). During the same period, Angus Fire manufactured AFFF for sale outside the United States at a single facility located in Bentham, England.

- removed (2022-10-27):
[0001783180-22-000048:note_history:18]
Plaintiffs in the MDL Proceedings allege that PFOS and PFOA contamination has resulted from the use of AFFF containing fluorosurfactants manufactured using a process known as ECF. They also allege that PFOA contamination has resulted from the use of AFFF containing fluorosurfactants manufactured using a different process, known as telomerization. Plaintiffs further allege that 3M was the only AFFF manufacturer that used fluorosurfactants relying on the ECF process and that all other foam manufacturers (including National Foam and Angus Fire) relied solely on fluorosurfactants produced via telomerization. Compounds containing PFOS and PFOA (as well as many other per- and polyfluoroalkyl substances known collectively as "PFAS") have also been used for decades by many third parties in a number of different industries to manufacture carpets, clothing, fabrics, cookware, food packaging, personal care products, cleaning products, paints, varnishes and other consumer and industrial products.

- removed (2022-10-27):
[0001783180-22-000048:note_history:19]
General liability discovery in the MDL Proceedings continues. Preliminary stage discovery in ten "bellwether" water provider cases was concluded and three of these cases were selected for tier two site-specific discovery. That discovery is ongoing. The MDL Court previously established a briefing schedule with respect to certain aspects of the government contractor defense, potentially applicable to AFFF sold to or used by the U.S. government or other customers requiring product manufactured to meet military specification, with briefing to conclude at the end of January 2022 with a hearing to follow in late March. In late March, the MDL Court postponed the planned hearing and called for briefing on additional elements of the government contractor defense. Briefing was completed as of July 1, 2022. An oral argument is now scheduled on August 19, 2022.

- removed (2022-10-27):
[0001783180-22-000048:note_history:20]
The Company believes that it has meritorious defenses to the claims in the MDL Proceedings and the other AFFF lawsuits. Based on the 2013 agreement for the sale of National Foam and Angus Fire, the Company is pursuing indemnification against these claims from the purchaser and current owner of National Foam and Angus Fire. The Company also is pursuing insurance coverage for these claims. At this time, however, given the numerous factual, scientific and legal issues to be resolved relating to these claims, the Company is unable to assess the probability of liability or to reasonably estimate the damages, if any, to be allocated to the Company, if one or more plaintiffs were to prevail in these cases. There can be no assurance that any such future exposure will not be material in any period.

- removed (2022-10-27):
[0001783180-22-000048:note_history:21]
possible outcomes. If no amount within the range is a better estimate than any other, the Company accrues the minimum amount.


## us-gaap:ScheduleOfEnvironmentalLossContingenciesBySiteTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-10-27):
[0001783180-22-000056:note_history:22]
| (In millions) |  | September 30,2022 |  | December 31, 2021 |
| Environmental reserves included in Accrued liabilities |  | $ | 29 |  |  | $ | 29 |  |
| Environmental reserves included in Other long-term liabilities |  | 203 |  |  | 191 |  |
| Total Environmental reserves |  | $ | 232 |  |  | $ | 220 |  |
  (was, 2022-07-28, similarity 0.976):
[0001783180-22-000048:note_history:22]
| (In millions) |  | June 30,2022 |  | December 31, 2021 |
| Environmental reserves included in Accrued liabilities |  | $ | 29 |  |  | $ | 29 |  |
| Environmental reserves included in Other long-term liabilities |  | 187 |  |  | 191 |  |
| Total Environmental reserves |  | $ | 216 |  |  | $ | 220 |  |


## us-gaap:ScheduleOfLossContingenciesByContingencyTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-10-27):
[0001783180-22-000056:note_history:23]
The Company's asbestos liabilities and related insurance recoveries are as follows:
  (was, 2022-07-28, similarity 0.939):
[0001783180-22-000048:note_history:23]
The Company had asbestos liabilities and related insurance recoveries as follows:

- changed (2022-10-27):
[0001783180-22-000056:note_history:24]
| (In millions) |  | September 30,2022 |  | December 31,2021 |
| Asbestos liabilities included in Accrued liabilities |  | $ | 17 |  |  | $ | 17 |  |
| Asbestos liabilities included in Other long-term liabilities |  | 214 |  |  | 220 |  |
| Total Asbestos liabilities |  | $ | 231 |  |  | $ | 237 |  |
| Asbestos-related recoveries included in Other assets, current |  | $ | 5 |  |  | $ | 5 |  |
| Asbestos-related recoveries included in Other assets |  | 91 |  |  | 93 |  |
| Total Asbestos-related recoveries |  | $ | 96 |  |  | $ | 98 |  |
  (was, 2022-07-28, similarity 0.9867):
[0001783180-22-000048:note_history:24]
| (In millions) |  | June 30,2022 |  | December 31,2021 |
| Asbestos liabilities included in Accrued liabilities |  | $ | 17 |  |  | $ | 17 |  |
| Asbestos liabilities included in Other long-term liabilities |  | 215 |  |  | 220 |  |
| Total Asbestos liabilities |  | $ | 232 |  |  | $ | 237 |  |
| Asbestos-related recoveries included in Other assets, current |  | $ | 5 |  |  | $ | 5 |  |
| Asbestos-related recoveries included in Other assets |  | 92 |  |  | 93 |  |
| Total Asbestos-related recoveries |  | $ | 97 |  |  | $ | 98 |  |


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2022-10-27):
[0001783180-22-000056:note_history:25]
Acquisition of Toshiba Carrier Corporation

- added (2022-10-27):
[0001783180-22-000056:note_history:26]
On February 6, 2022, the Company entered into a binding agreement to acquire a majority ownership interest in Toshiba Carrier Corporation (“TCC”), a variable refrigerant flow ("VRF") and light commercial HVAC joint venture between Carrier and Toshiba Corporation. The acquisition was completed on August 1, 2022, subject to customary closing conditions. As a result, the assets, liabilities and results of operations of TCC are consolidated in the accompanying Unaudited Condensed Consolidated Financial Statements as of the date of acquisition and reported within the Company’s HVAC segment. Upon closing, Toshiba Corporation retained a 5% ownership interest in TCC. See Note 15 – Acquisitions for additional information.

- changed (2022-10-27):
[0001783180-22-000056:note_history:27]
On April 3, 2020, United Technologies Corporation, since renamed Raytheon Technologies Corporation ("UTC"), completed the spin-off of the Company into an independent, publicly traded company (the "Separation") through a pro-rata distribution (the "Distribution") on a one-for-one basis of all of the outstanding shares of common stock of the Company to UTC shareowners who held shares of UTC common stock as of the close of business on March 19, 2020, the record date of the Distribution. The Company incurred separation-related costs including employee-related costs, costs to establish certain stand-alone functions, information technology systems, professional service fees and other costs associated with becoming an independent, publicly traded company. These costs are primarily recorded in Selling, general and administrative in the accompanying Unaudited Condensed Consolidated Statement of Operations and totaled $19 million for the nine months ended September 30, 2021.
  (was, 2022-07-28, similarity 0.9392):
[0001783180-22-000048:note_history:27]
On April 3, 2020, United Technologies Corporation, since renamed Raytheon Technologies Corporation ("UTC"), completed the spin-off of the Company into an independent, publicly traded company (the "Separation") through a pro-rata distribution (the "Distribution") on a one-for-one basis of all of the outstanding shares of common stock of the Company to UTC shareowners who held shares of UTC common stock as of the close of business on March 19, 2020, the record date of the Distribution. The Company incurred separation-related costs including employee-related costs, costs to establish certain stand-alone functions, information technology systems, professional service fees and other costs associated with becoming an independent, publicly traded company. These costs are primarily recorded in Selling, general and administrative in the Unaudited Condensed Consolidated Statement of Operations and totaled $3 million and $19 million for the three and six months ended June 30, 2021, respectively.

- changed (2022-10-27):
[0001783180-22-000056:note_history:28]
The Financial Accounting Standards Board ("FASB") Accounting Standards Codification ("ASC") is the sole source of authoritative U.S. GAAP other than SEC issued rules and regulations that apply only to SEC registrants. The FASB issues Accounting Standards Updates ("ASU") to communicate changes to the codification. The Company considers the applicability and impact of all ASUs. ASUs pending adoption were assessed and determined to be either not applicable or not expected to have a material impact on the accompanying Unaudited Condensed Consolidated Financial Statements.
  (was, 2022-07-28, similarity 0.9885):
[0001783180-22-000048:note_history:28]
The Financial Accounting Standards Board ("FASB") Accounting Standards Codification ("ASC") is the sole source of authoritative U.S. GAAP other than SEC issued rules and regulations that apply only to SEC registrants. The FASB issues Accounting Standards Updates ("ASU") to communicate changes to the codification. The Company considers the applicability and impact of all ASUs. ASUs pending adoption were assessed and determined to be either not applicable or not expected to have a material impact on the Unaudited Condensed Consolidated Financial Statements.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2022-10-27):
[0001783180-22-000056:note_history:29]
In the opinion of management, the accompanying Unaudited Condensed Consolidated Financial Statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission (the "SEC"). The accompanying Unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for 2021 filed with the SEC on February 8, 2022 (the "2021 Form 10-K").
  (was, 2022-07-28, similarity 0.9913):
[0001783180-22-000048:note_history:29]
In the opinion of management, the accompanying Unaudited Condensed Consolidated Financial Statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission (the "SEC"). These Unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for 2021 filed with the SEC on February 8, 2022 (the "2021 Form 10-K").


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-10-27):
[0001783180-22-000056:note_history:30]
| (In millions) |  |  |  | September 30,2022 |  | December 31,2021 |
| 2.242% Notes due February 15, 2025 |  |  |  | $ | 1,200 |  |  | $ | 2,000 |  |
| 2.493% Notes due February 15, 2027 |  |  |  | 900 |  |  | 1,250 |  |
| 2.722% Notes due February 15, 2030 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.700% Notes due February 15, 2031 |  |  |  | 750 |  |  | 750 |  |
| 3.377% Notes due April 5, 2040 |  |  |  | 1,500 |  |  | 1,500 |  |
| 3.577% Notes due April 5, 2050 |  |  |  | 2,000 |  |  | 2,000 |  |
| Total long-term Notes |  |  |  | 8,350 |  |  | 9,500 |  |
| Japanese Term Loan Facility |  |  |  | 372 |  |  | — |  |
| Other debt (including project financing obligations and finance leases) |  |  |  | 228 |  |  | 267 |  |
| Discounts and debt issuance costs |  |  |  | (61) |  |  | (71) |  |
| Total debt |  |  |  | 8,889 |  |  | 9,696 |  |
| Less: current portion of long-term debt |  |  |  | 219 |  |  | 183 |  |
| Long-term debt, net of current portion |  |  |  | $ | 8,670 |  |  | $ | 9,513 |  |
  (was, 2022-07-28, similarity 0.9568):
[0001783180-22-000048:note_history:30]
| (In millions) |  |  |  | June 30,2022 |  | December 31,2021 |
| 2.242% Notes due February 15, 2025 |  |  |  | $ | 1,200 |  |  | $ | 2,000 |  |
| 2.493% Notes due February 15, 2027 |  |  |  | 900 |  |  | 1,250 |  |
| 2.722% Notes due February 15, 2030 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.700% Notes due February 15, 2031 |  |  |  | 750 |  |  | 750 |  |
| 3.377% Notes due April 5, 2040 |  |  |  | 1,500 |  |  | 1,500 |  |
| 3.577% Notes due April 5, 2050 |  |  |  | 2,000 |  |  | 2,000 |  |
| Total long-term Notes |  |  |  | 8,350 |  |  | 9,500 |  |
| Other debt (including project financing obligations and finance leases) |  |  |  | 279 |  |  | 267 |  |
| Discounts and debt issuance costs |  |  |  | (62) |  |  | (71) |  |
| Total debt |  |  |  | 8,567 |  |  | 9,696 |  |
| Less: current portion of long-term debt |  |  |  | 269 |  |  | 183 |  |
| Long-term debt, net of current portion |  |  |  | $ | 8,298 |  |  | $ | 9,513 |  |

- added (2022-10-27):
[0001783180-22-000056:note_history:31]
Japanese Term Loan Facility

- added (2022-10-27):
[0001783180-22-000056:note_history:32]
On July 15, 2022, the Company entered into a five-year, JPY 54 billion (approximately $400 million) senior unsecured term loan facility with MUFG Bank Ltd., as administrative agent and lender, and certain other lenders (the "Japanese Term Loan Facility"). Borrowings under the Japanese Term Loan Facility bear interest at a rate equal to the Tokyo Term Risk Free Rate plus 0.75%. In addition, the Japanese Term Loan Facility is subject to customary covenants including a covenant to maintain a maximum consolidated leverage ratio. On July 25, 2022, the Company borrowed JPY 54 billion under the Japanese Term Loan Facility and used the proceeds to fund a portion of the TCC acquisition and to pay related fees and expenses.

- changed (2022-10-27):
[0001783180-22-000056:note_history:33]
On February 10, 2020, the Company entered into a revolving credit agreement with various banks permitting aggregate borrowings of up to $2.0 billion pursuant to an unsecured, unsubordinated revolving credit facility that matures on April 3, 2025 (the "Revolving Credit Facility"). The Revolving Credit Facility supports the Company's commercial paper program and cash requirements of the Company. A commitment fee of 0.125% is charged on unused commitments. Borrowings under the Revolving Credit Facility are available in U.S. Dollars, Euros and Pounds Sterling and bear interest at a variable interest rate plus a ratings-based margin, which was 125 basis points as of September 30, 2022. As of September 30, 2022, there were no borrowings outstanding under the Revolving Credit Facility.
  (was, 2022-07-28, similarity 0.9682):
[0001783180-22-000048:note_history:33]
On February 10, 2020, the Company entered into a revolving credit agreement with various banks permitting aggregate borrowings of up to $2.0 billion pursuant to an unsecured, unsubordinated revolving credit facility that matures on April 3, 2025 (the "Revolving Credit Facility"). The Revolving Credit Facility supports the Company's commercial paper program and cash requirements of the Company. A commitment fee of 0.125% is charged on unused commitments. Borrowings under the Revolving Credit Facility are available in U.S. Dollars, Euros and Pounds Sterling and bear interest at a variable interest rate plus a ratings-based margin, which was 125 basis points as of June 30, 2022. As of June 30, 2022, there were no borrowings outstanding under the Revolving Credit Facility.

- changed (2022-10-27):
[0001783180-22-000056:note_history:34]
The Company has a $2.0 billion unsecured, unsubordinated commercial paper program, which can be used for general corporate purposes, including the funding of working capital and potential acquisitions. As of September 30, 2022, there were no borrowings outstanding under the commercial paper program.
  (was, 2022-07-28, similarity 0.7393):
[0001783180-22-000048:note_history:34]
corporate purposes, including the funding of working capital and potential acquisitions. As of June 30, 2022, there were no borrowings outstanding under the commercial paper program.

- changed (2022-10-27):
[0001783180-22-000056:note_history:35]
The Company is involved in long-term construction contracts in which it arranges project financing with certain customers. As a result, the Company issued $27 million and $108 million of debt during the nine months ended September 30, 2022 and 2021, respectively. Long-term debt repayments associated with these financing arrangements during the nine months ended September 30, 2022 and 2021 were $70 million and $170 million, respectively.
  (was, 2022-07-28, similarity 0.8747):
[0001783180-22-000048:note_history:35]
The Company is involved in several long-term construction contracts in which it arranges project financing with certain customers. As a result, the Company issued $21 million and $71 million of debt during the six months ended June 30, 2022 and 2021, respectively. Long-term debt repayments associated with these financing arrangements during the six months ended June 30, 2022 and 2021 were $12 million and $83 million, respectively.

- added (2022-10-27):
[0001783180-22-000056:note_history:36]
The Revolving Credit Facility, the indenture for the long-term Notes and the Japanese Term Loan Facility contain affirmative and negative covenants customary for financings of these types, which, among other things, limit the Company's ability to incur additional liens, to make certain fundamental changes and to enter into sale and leaseback transactions. As of September 30, 2022, the Company was in compliance with the covenants under the agreements governing its outstanding indebtedness.

- removed (2022-10-27):
[0001783180-22-000048:note_history:37]
The Company has a $2.0 billion unsecured, unsubordinated commercial paper program, which can be used for general

- removed (2022-10-27):
[0001783180-22-000048:note_history:38]
The Revolving Credit Facility and the indenture for the long-term Notes contain affirmative and negative covenants customary for financings of these types, which, among other things, limit the Company's ability to incur additional liens, to make certain fundamental changes and to enter into sale and leaseback transactions. As of June 30, 2022, the Company was in compliance with the covenants under the agreements governing its outstanding indebtedness.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-10-27):
[0001783180-22-000056:note_history:39]
| (In millions) |  |  |  | September 30,2022 |  | December 31,2021 |
| 2.242% Notes due February 15, 2025 |  |  |  | $ | 1,200 |  |  | $ | 2,000 |  |
| 2.493% Notes due February 15, 2027 |  |  |  | 900 |  |  | 1,250 |  |
| 2.722% Notes due February 15, 2030 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.700% Notes due February 15, 2031 |  |  |  | 750 |  |  | 750 |  |
| 3.377% Notes due April 5, 2040 |  |  |  | 1,500 |  |  | 1,500 |  |
| 3.577% Notes due April 5, 2050 |  |  |  | 2,000 |  |  | 2,000 |  |
| Total long-term Notes |  |  |  | 8,350 |  |  | 9,500 |  |
| Japanese Term Loan Facility |  |  |  | 372 |  |  | — |  |
| Other debt (including project financing obligations and finance leases) |  |  |  | 228 |  |  | 267 |  |
| Discounts and debt issuance costs |  |  |  | (61) |  |  | (71) |  |
| Total debt |  |  |  | 8,889 |  |  | 9,696 |  |
| Less: current portion of long-term debt |  |  |  | 219 |  |  | 183 |  |
| Long-term debt, net of current portion |  |  |  | $ | 8,670 |  |  | $ | 9,513 |  |
  (was, 2022-07-28, similarity 0.9568):
[0001783180-22-000048:note_history:39]
| (In millions) |  |  |  | June 30,2022 |  | December 31,2021 |
| 2.242% Notes due February 15, 2025 |  |  |  | $ | 1,200 |  |  | $ | 2,000 |  |
| 2.493% Notes due February 15, 2027 |  |  |  | 900 |  |  | 1,250 |  |
| 2.722% Notes due February 15, 2030 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.700% Notes due February 15, 2031 |  |  |  | 750 |  |  | 750 |  |
| 3.377% Notes due April 5, 2040 |  |  |  | 1,500 |  |  | 1,500 |  |
| 3.577% Notes due April 5, 2050 |  |  |  | 2,000 |  |  | 2,000 |  |
| Total long-term Notes |  |  |  | 8,350 |  |  | 9,500 |  |
| Other debt (including project financing obligations and finance leases) |  |  |  | 279 |  |  | 267 |  |
| Discounts and debt issuance costs |  |  |  | (62) |  |  | (71) |  |
| Total debt |  |  |  | 8,567 |  |  | 9,696 |  |
| Less: current portion of long-term debt |  |  |  | 269 |  |  | 183 |  |
| Long-term debt, net of current portion |  |  |  | $ | 8,298 |  |  | $ | 9,513 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- added (2022-10-27):
[0001783180-22-000056:note_history:40]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
| (In millions) |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Sales to equity method investees included in Product sales |  | $ | 718 |  |  | $ | 556 |  |  | $ | 2,129 |  |  | $ | 1,675 |  |
| Purchases from equity method investees included in Cost of products sold |  | $ | 60 |  |  | $ | 93 |  |  | $ | 261 |  |  | $ | 266 |  |

- added (2022-10-27):
[0001783180-22-000056:note_history:41]
| (In millions) |  | September 30,2022 |  | December 31, 2021 |
| Receivables from equity method investees included in Accounts receivable, net |  | $ | 307 |  |  | $ | 150 |  |
| Payables to equity method investees included in Accounts payable |  | $ | 33 |  |  | $ | 51 |  |

- removed (2022-10-27):
[0001783180-22-000048:note_history:42]
|  |  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
| (In millions) |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Sales to equity method investees included in Product sales |  | $ | 787 |  |  | $ | 652 |  |  | $ | 1,411 |  |  | $ | 1,120 |  |
| Purchases from equity method investees included in Cost of products sold |  | $ | 91 |  |  | $ | 98 |  |  | $ | 201 |  |  | $ | 174 |  |

- removed (2022-10-27):
[0001783180-22-000048:note_history:43]
| (In millions) |  | June 30,2022 |  | December 31, 2021 |
| Receivables from equity method investees included in Accounts receivable, net |  | $ | 315 |  |  | $ | 150 |  |
| Payables to equity method investees included in Accounts payable |  | $ | 57 |  |  | $ | 51 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-10-27):
[0001783180-22-000056:note_history:44]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
| (In millions) |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Sales Type |  |  |  |  |  |  |  |  |
| Product |  | $ | 3,330 |  |  | $ | 2,702 |  |  | $ | 8,974 |  |  | $ | 7,606 |  |
| Service |  | 404 |  |  | 352 |  |  | 1,118 |  |  | 1,054 |  |
| HVAC sales |  | 3,734 |  |  | 3,054 |  |  | 10,092 |  |  | 8,660 |  |
| Product |  | 811 |  |  | 894 |  |  | 2,603 |  |  | 2,701 |  |
| Service |  | 112 |  |  | 117 |  |  | 337 |  |  | 336 |  |
| Refrigeration sales |  | 923 |  |  | 1,011 |  |  | 2,940 |  |  | 3,037 |  |
| Product |  | 859 |  |  | 1,012 |  |  | 2,468 |  |  | 2,943 |  |
| Service |  | 46 |  |  | 365 |  |  | 142 |  |  | 1,141 |  |
| Fire & Security sales |  | 905 |  |  | 1,377 |  |  | 2,610 |  |  | 4,084 |  |
| Total segment sales |  | 5,562 |  |  | 5,442 |  |  | 15,642 |  |  | 15,781 |  |
| Eliminations and other |  | (111) |  |  | (101) |  |  | (326) |  |  | (301) |  |
| Net sales |  | $ | 5,451 |  |  | $ | 5,341 |  |  | $ | 15,316 |  |  | $ | 15,480 |  |
  (was, 2022-07-28, similarity 0.958):
[0001783180-22-000048:note_history:44]
|  |  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
| (In millions) |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Sales Type |  |  |  |  |  |  |  |  |
| Product |  | $ | 3,005 |  |  | $ | 2,757 |  |  | $ | 5,644 |  |  | $ | 4,904 |  |
| Service |  | 383 |  |  | 363 |  |  | 714 |  |  | 702 |  |
| HVAC sales |  | 3,388 |  |  | 3,120 |  |  | 6,358 |  |  | 5,606 |  |
| Product |  | 925 |  |  | 915 |  |  | 1,792 |  |  | 1,807 |  |
| Service |  | 116 |  |  | 106 |  |  | 225 |  |  | 219 |  |
| Refrigeration sales |  | 1,041 |  |  | 1,021 |  |  | 2,017 |  |  | 2,026 |  |
| Product |  | 838 |  |  | 1,012 |  |  | 1,609 |  |  | 1,931 |  |
| Service |  | 49 |  |  | 391 |  |  | 96 |  |  | 776 |  |
| Fire & Security sales |  | 887 |  |  | 1,403 |  |  | 1,705 |  |  | 2,707 |  |
| Total segment sales |  | 5,316 |  |  | 5,544 |  |  | 10,080 |  |  | 10,339 |  |
| Eliminations and other |  | (105) |  |  | (104) |  |  | (215) |  |  | (200) |  |
| Net sales |  | $ | 5,211 |  |  | $ | 5,440 |  |  | $ | 9,865 |  |  | $ | 10,139 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-10-27):
[0001783180-22-000056:note_history:45]
The Company accounts for revenue in accordance with ASC 606: Revenue from Contracts with Customers. Revenue is recognized when control of a good or service promised in a contract (i.e., performance obligation) is transferred to a customer. Control is obtained when a customer has the ability to direct the use of and obtain substantially all of the remaining benefits from that good or service. A significant portion of the Company's performance obligations are recognized at a point-in-time when control of the product transfers to the customer, which is generally at the time of shipment. The remaining portion of the Company’s performance obligations are recognized over time as the customer simultaneously obtains control as the Company performs work under a contract, or if the product being produced for the customer has no alternative use and the Company has a contractual right to payment.The timing of revenue recognition, billings and cash collections results in contract assets and contract liabilities. Contract assets relate to the conditional right to consideration for any completed performance under a contract when costs are incurred in excess of billings under the percentage-of-completion methodology. Contract liabilities relate to payments received in advance of performance under a contract or when the Company has a right to consideration that is conditioned upon transfer of a good or service to a customer. Contract liabilities are recognized as revenue as (or when) the Company performs under the contract.
  (was, 2022-07-28, similarity 0.9997):
[0001783180-22-000048:note_history:45]
The Company accounts for revenue in accordance with ASC 606: Revenue from Contracts with Customers. Revenue is recognized when control of a good or service promised in a contract (i.e. performance obligation) is transferred to a customer. Control is obtained when a customer has the ability to direct the use of and obtain substantially all of the remaining benefits from that good or service. A significant portion of the Company's performance obligations are recognized at a point-in-time when control of the product transfers to the customer, which is generally at the time of shipment. The remaining portion of the Company’s performance obligations are recognized over time as the customer simultaneously obtains control as the Company performs work under a contract, or if the product being produced for the customer has no alternative use and the Company has a contractual right to payment.The timing of revenue recognition, billings and cash collections results in contract assets and contract liabilities. Contract assets relate to the conditional right to consideration for any completed performance under a contract when costs are incurred in excess of billings under the percentage-of-completion methodology. Contract liabilities relate to payments received in advance of performance under a contract or when the Company has a right to consideration that is conditioned upon transfer of a good or service to a customer. Contract liabilities are recognized as revenue as (or when) the Company performs under the contract.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-10-27):
[0001783180-22-000056:note_history:46]
REVENUE RECOGNITION The Company accounts for revenue in accordance with ASC 606: Revenue from Contracts with Customers. Revenue is recognized when control of a good or service promised in a contract (i.e., performance obligation) is transferred to a customer. Control is obtained when a customer has the ability to direct the use of and obtain substantially all of the remaining benefits from that good or service. A significant portion of the Company's performance obligations are recognized at a point-in-time when control of the product transfers to the customer, which is generally at the time of shipment. The remaining portion of the Company’s performance obligations are recognized over time as the customer simultaneously obtains control as the Company 
performs work under a contract, or if the product being produced for the customer has no alternative use and the Company has a contractual right to payment.
  (was, 2022-07-28, similarity 0.9995):
[0001783180-22-000048:note_history:46]
REVENUE RECOGNITION 
The Company accounts for revenue in accordance with ASC 606: Revenue from Contracts with Customers. Revenue is recognized when control of a good or service promised in a contract (i.e. performance obligation) is transferred to a customer. Control is obtained when a customer has the ability to direct the use of and obtain substantially all of the remaining benefits from that good or service. A significant portion of the Company's performance obligations are recognized at a point-in-time when control of the product transfers to the customer, which is generally at the time of shipment. The remaining portion of the Company’s performance obligations are recognized over time as the customer simultaneously obtains control as the Company performs work under a contract, or if the product being produced for the customer has no alternative use and the Company has a contractual right to payment.

- changed (2022-10-27):
[0001783180-22-000056:note_history:47]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
| (In millions) |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Sales Type |  |  |  |  |  |  |  |  |
| Product |  | $ | 3,330 |  |  | $ | 2,702 |  |  | $ | 8,974 |  |  | $ | 7,606 |  |
| Service |  | 404 |  |  | 352 |  |  | 1,118 |  |  | 1,054 |  |
| HVAC sales |  | 3,734 |  |  | 3,054 |  |  | 10,092 |  |  | 8,660 |  |
| Product |  | 811 |  |  | 894 |  |  | 2,603 |  |  | 2,701 |  |
| Service |  | 112 |  |  | 117 |  |  | 337 |  |  | 336 |  |
| Refrigeration sales |  | 923 |  |  | 1,011 |  |  | 2,940 |  |  | 3,037 |  |
| Product |  | 859 |  |  | 1,012 |  |  | 2,468 |  |  | 2,943 |  |
| Service |  | 46 |  |  | 365 |  |  | 142 |  |  | 1,141 |  |
| Fire & Security sales |  | 905 |  |  | 1,377 |  |  | 2,610 |  |  | 4,084 |  |
| Total segment sales |  | 5,562 |  |  | 5,442 |  |  | 15,642 |  |  | 15,781 |  |
| Eliminations and other |  | (111) |  |  | (101) |  |  | (326) |  |  | (301) |  |
| Net sales |  | $ | 5,451 |  |  | $ | 5,341 |  |  | $ | 15,316 |  |  | $ | 15,480 |  |
  (was, 2022-07-28, similarity 0.958):
[0001783180-22-000048:note_history:47]
|  |  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
| (In millions) |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Sales Type |  |  |  |  |  |  |  |  |
| Product |  | $ | 3,005 |  |  | $ | 2,757 |  |  | $ | 5,644 |  |  | $ | 4,904 |  |
| Service |  | 383 |  |  | 363 |  |  | 714 |  |  | 702 |  |
| HVAC sales |  | 3,388 |  |  | 3,120 |  |  | 6,358 |  |  | 5,606 |  |
| Product |  | 925 |  |  | 915 |  |  | 1,792 |  |  | 1,807 |  |
| Service |  | 116 |  |  | 106 |  |  | 225 |  |  | 219 |  |
| Refrigeration sales |  | 1,041 |  |  | 1,021 |  |  | 2,017 |  |  | 2,026 |  |
| Product |  | 838 |  |  | 1,012 |  |  | 1,609 |  |  | 1,931 |  |
| Service |  | 49 |  |  | 391 |  |  | 96 |  |  | 776 |  |
| Fire & Security sales |  | 887 |  |  | 1,403 |  |  | 1,705 |  |  | 2,707 |  |
| Total segment sales |  | 5,316 |  |  | 5,544 |  |  | 10,080 |  |  | 10,339 |  |
| Eliminations and other |  | (105) |  |  | (104) |  |  | (215) |  |  | (200) |  |
| Net sales |  | $ | 5,211 |  |  | $ | 5,440 |  |  | $ | 9,865 |  |  | $ | 10,139 |  |

- changed (2022-10-27):
[0001783180-22-000056:note_history:48]
| (In millions) |  | September 30, 2022 |  | December 31, 2021 |
| Contract assets, current |  | $ | 666 |  |  | $ | 503 |  |
| Contract assets, non-current (included within Other assets) |  | 7 |  |  | 70 |  |
| Total contract assets |  | 673 |  |  | 573 |  |
| Contract liabilities, current |  | (440) |  |  | (415) |  |
| Contract liabilities, non-current (included within Other long-term liabilities) |  | (167) |  |  | (165) |  |
| Total contract liabilities |  | (607) |  |  | (580) |  |
| Net contract assets |  | $ | 66 |  |  | $ | (7) |  |
  (was, 2022-07-28, similarity 0.9617):
[0001783180-22-000048:note_history:48]
| (In millions) |  | June 30, 2022 |  | December 31, 2021 |
| Contract assets, current |  | $ | 712 |  |  | $ | 503 |  |
| Contract assets, non-current (included within Other assets) |  | 6 |  |  | 70 |  |
| Total contract assets |  | 718 |  |  | 573 |  |
| Contract liabilities, current |  | (444) |  |  | (415) |  |
| Contract liabilities, non-current (included within Other long-term liabilities) |  | (169) |  |  | (165) |  |
| Total contract liabilities |  | (613) |  |  | (580) |  |
| Net contract assets |  | $ | 105 |  |  | $ | (7) |  |

- changed (2022-10-27):
[0001783180-22-000056:note_history:49]
The timing of revenue recognition, billings and cash collections results in contract assets and contract liabilities. Contract assets relate to the conditional right to consideration for any completed performance under a contract when costs are incurred in excess of billings under the percentage-of-completion methodology. Contract liabilities relate to payments received in advance of performance under a contract or when the Company has a right to consideration that is conditioned upon transfer of a good or service to a customer. Contract liabilities are recognized as revenue as (or when) the Company performs under the contract. 
The Company recognized revenue of $289 million during the nine months ended September 30, 2022 that related to contract liabilities as of January 1, 2022. The Company expects a majority of its current contract liabilities at the end of the period to be recognized as revenue in the next 12 months.
  (was, 2022-07-28, similarity 0.7993):
[0001783180-22-000048:note_history:49]
The timing of revenue recognition, billings and cash collections results in contract assets and contract liabilities. Contract assets relate to the conditional right to consideration for any completed performance under a contract when costs are incurred in excess of billings under the percentage-of-completion methodology. Contract liabilities relate to payments received in advance of performance under a contract or when the Company has a right to consideration that is conditioned upon transfer of a good or service to a customer. Contract liabilities are recognized as revenue as (or when) the Company performs under the contract. 
The Company recognized revenue of $221 million during the six months ended June 30, 2022 that related to contract liabilities as of January 1, 2022. The Company expects a majority of its current contract liabilities at the end of the period to be recognized as revenue in the next 12 months.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2022-10-27):
[0001783180-22-000048:note_history:50]
SUBSEQUENT EVENTS 
On July 15, 2022, the Company entered into a five-year, JPY 54 billion (approximately $400 million) senior unsecured term loan facility with MUFG Bank Ltd., as administrative agent and lender, and certain other lenders (the "Japanese Term Loan Facility"). Borrowings under the Japanese Term Loan Facility bear interest at a rate equal to the Tokyo Term Risk Free Rate plus 0.75%. In addition, the Japanese Term Loan Facility is subject to customary covenants including a covenant to maintain a maximum consolidated leverage ratio during its term. The Company expects to designate the Japanese Term Loan Facility as a partial hedge of its investment in certain Yen-functional currency subsidiaries in order to manage foreign currency translation risk. As a result, changes in the fair value of the Japanese Term Loan Facility associated with foreign exchange rate movements will be recorded in Equity in the Unaudited Condensed Consolidated Balance Sheet.

- removed (2022-10-27):
[0001783180-22-000048:note_history:51]
On July 25, 2022, the Company borrowed JPY 54 billion under the Japanese Term Loan Facility and intends to use the proceeds to fund a portion of the planned acquisition of TCC and to pay related fees and expenses. The Company expects to fund the remaining portion of the Yen denominated purchase price for the planned acquisition of TCC with cash on hand by entering into cross currency swaps with SMBC Capital Markets, Inc. as syndication swap arranger, and certain other financial institutions. The Company expects to designate the cross currency swaps as a partial hedge of its investment in certain Yen-functional currency subsidiaries in order to manage foreign currency translation risk. As a result, changes in the fair value of the swaps will be recorded in Equity in the Unaudited Condensed Consolidated Balance Sheet.
