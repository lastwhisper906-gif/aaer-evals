# CARR MD&A — 0001783180-26-000026


## mdna

[0001783180-26-000026:mdna:1]
[same as prior period, unchanged from 0001783180-25-000066:mdna:1]

[0001783180-26-000026:mdna:2]
[same as prior period, unchanged from 0001783180-25-000066:mdna:2]

[0001783180-26-000026:mdna:3]
[same as prior period, unchanged from 0001783180-25-000066:mdna:3]

[0001783180-26-000026:mdna:4]
Carrier Global Corporation ("we" or "our") is a global leader in intelligent climate and energy solutions with a focus on providing differentiated, digitally-enabled lifecycle solutions to our customers. Our portfolio includes industry-leading brands such as Carrier, Viessmann, Toshiba, Automated Logic and Carrier Transicold that offer innovative heating, cooling and cold chain solutions to enhance the lives we live and the world we share. We also provide a broad array of related building services, including audit, design, installation, system integration, repair, maintenance and monitoring. Our operations are classified into four segments: Climate Solutions Americas, Climate Solutions Europe, Climate Solutions Asia Pacific, Middle East & Africa and Climate Solutions Transportation.

[0001783180-26-000026:mdna:5]
Through our performance-driven culture, we anticipate creating long-term shareowner value by investing strategically to strengthen our product position in homes, buildings and across the cold chain in order to drive profitable growth. We believe our business segments are well positioned to benefit from favorable secular trends, including the mega-trends of urbanization, population growth and demographic shifts, food security and safety, electrification, increasing demand for climate control and accelerated digitalization. Coupled with our industry-leading brands and track record of innovation, we continue to provide market-leading solutions for our customers.

[0001783180-26-000026:mdna:6]
[same as prior period, unchanged from 0001783180-25-000066:mdna:6]

[0001783180-26-000026:mdna:7]
Through a combination of supply‑chain adjustments, productivity initiatives and pricing actions, we fully mitigated the 2025 impact of tariffs implemented in 2025. While these tariffs did not have a material impact on our prior year results, in 2026 we continue to evaluate and assess any potential exposure to the impacts of these tariffs, including impacts to supply chains and cost structures.

[0001783180-26-000026:mdna:8]
In February 2026, the U.S. Supreme Court ruled that tariffs imposed under the International Emergency Economic Powers Act ("IEEPA") were unauthorized. We were the importer of record for certain products previously subject to IEEPA tariffs. In March 2026, the U.S. Court of International Trade ordered U.S. Customs and Border Protection to refund IEEPA tariffs collected; however, the refund process and timing remain uncertain, and the order may be subject to further government action or challenge. Accordingly, as of March 31, 2026, we have not recorded any benefit related to potential refunds of IEEPA tariffs paid.

[0001783180-26-000026:mdna:9]
On April 2, 2026, updated Section 232 tariffs applicable to steel, aluminum and copper were announced. We expect to mitigate the 2026 impact by leveraging similar strategies deployed during 2025 including supply chain changes, operational cost reduction and pricing actions.

[0001783180-26-000026:mdna:10]
To date, neither the IEEPA tariffs implemented during 2025 nor the Section 232 tariffs have had a material impact on our business, and we will continue to monitor developments in U.S. tariff policy and assess the impact of any changes on our business.

[0001783180-26-000026:mdna:11]
27

[0001783180-26-000026:mdna:12]
[same as prior period, unchanged from 0001783180-25-000066:mdna:8]

[0001783180-26-000026:mdna:13]
Sale of Riello Business

[0001783180-26-000026:mdna:14]
On December 16, 2025, we entered into a purchase agreement to sell our Riello business ("Riello") to Ariston Group with expected gross proceeds of approximately $430 million. Riello, predominantly reported in our Climate Solutions Europe segment, is a leading international manufacturer that designs, produces and integrates a comprehensive portfolio of thermal solutions including burners, boilers, heat pumps, cooling systems and aftermarket services for residential, commercial and industrial applications, with a strong focus on energy efficiency, innovation and a global distribution network. This transaction is expected to close in the first half of 2026 and is subject to customary closing conditions and regulatory approvals.

[0001783180-26-000026:mdna:15]
[same as prior period, unchanged from 0001783180-25-000066:mdna:14]

[0001783180-26-000026:mdna:16]
Preparation of our financial statements requires management to make estimates and assumptions that affect the reported amounts of assets, liabilities, sales and expenses. We believe that the most complex and sensitive judgments, because of their potential significance to the accompanying Unaudited Condensed Consolidated Financial Statements, result primarily from the need to make estimates about the effects of matters that are inherently uncertain. In "Management’s Discussion and Analysis of Financial Condition and Results of Operations" of our 2025 Form 10-K, we describe the significant accounting estimates and policies used in the preparation of the accompanying Unaudited Condensed Consolidated Financial Statements. There have been no significant changes in our critical accounting estimates.

[0001783180-26-000026:mdna:17]
[same as prior period, unchanged from 0001783180-25-000066:mdna:16]

[0001783180-26-000026:mdna:18]
Three Months Ended March 31, 2026 Compared with the Three Months Ended March 31, 2025

[0001783180-26-000026:mdna:19]
[same as prior period, unchanged from 0001783180-25-000066:mdna:18]

[0001783180-26-000026:mdna:20]
|  |  | Three Months Ended March 31, |
| (In millions) |  | 2026 |  | 2025 |  | Period Change |  | % Change |
| Net sales |  | $ | 5,341 |  |  | $ | 5,218 |  |  | $ | 123 |  |  | 2 | % |
| Cost of products and services sold |  | (4,097) |  |  | (3,773) |  |  | (324) |  |  | 9 | % |
| Gross margin |  | 1,244 |  |  | 1,445 |  |  | (201) |  |  | (14) | % |
| Operating expenses |  | (985) |  |  | (816) |  |  | (169) |  |  | 21 | % |
| Operating profit |  | 259 |  |  | 629 |  |  | (370) |  |  | (59) | % |
| Non-operating income (expense), net |  | (89) |  |  | (81) |  |  | (8) |  |  | 10 | % |
| Earnings (loss) before income taxes |  | 170 |  |  | 548 |  |  | (378) |  |  | (69) | % |
| Income tax expense |  | 96 |  |  | (111) |  |  | 207 |  |  | (186) | % |
| Earnings (loss) from continuing operations |  | 266 |  |  | 437 |  |  | (171) |  |  | (39) | % |
| Discontinued operations, net of income taxes |  | (1) |  |  | — |  |  | (1) |  |  | — | % |
| Net earnings (loss) |  | 265 |  |  | 437 |  |  | (172) |  |  | (39) | % |
| Less: Non-controlling interest in subsidiaries' earnings from operations |  | 27 |  |  | 25 |  |  | 2 |  |  | 8 | % |
| Net earnings (loss) attributable to common shareowners |  | $ | 238 |  |  | $ | 412 |  |  | $ | (174) |  |  | (42) | % |

[0001783180-26-000026:mdna:21]
[same as prior period, unchanged from 0001783180-25-000066:mdna:20]

[0001783180-26-000026:mdna:22]
For the three months ended March 31, 2026, Net sales were $5.3 billion, a 2% increase compared with the same period of 2025. The components of the year-over-year change were as follows:

[0001783180-26-000026:mdna:23]
|  |  | Three Months Ended March 31, |
| Organic |  | (1) | % |
| Foreign currency translation |  | 3 | % |
| Total % change |  | 2 | % |

[0001783180-26-000026:mdna:24]
Organic sales for the three months ended March 31, 2026, decreased by 1% compared with the same period of 2025. The organic decrease was primarily due to our Climate Solutions Americas segment as reduced end-market demand in our residential business impacted the segment. In addition, lower end-market demand in both our Climate Solutions Europe and Climate Solutions Asia Pacific, Middle East & Africa segments further impacted overall results. These results were partially offset by improved end-market demand in Climate Solutions Transportation. Refer to "Segment Review" below for a discussion of Net sales by segment.

[0001783180-26-000026:mdna:25]
[same as prior period, unchanged from 0001783180-25-000066:mdna:24]

[0001783180-26-000026:mdna:26]
For the three months ended March 31, 2026, gross margin was $1.2 billion, a 14% decrease compared with the same period of 2025. The components were as follows:

[0001783180-26-000026:mdna:27]
|  |  | Three Months Ended March 31, |
| (In millions) |  | 2026 |  | 2025 |
| Net sales |  | $ | 5,341 |  |  | $ | 5,218 |  |
| Cost of products and services sold |  | (4,097) |  |  | (3,773) |  |
| Gross margin |  | $ | 1,244 |  |  | $ | 1,445 |  |
| Percentage of net sales |  | 23.3 | % |  | 27.7 | % |

[0001783180-26-000026:mdna:28]
Gross margin decreased by $201 million compared with the three months ended March 31, 2025, primarily due to lower volumes in certain end-markets within each of our segments. The associated under-absorption, in addition to an increase in costs associated with announced restructuring initiatives, further impacted our results. These amounts were partially offset by higher volumes in certain end-markets, pricing improvements and our continued focus on productivity initiatives. As a result, gross margin as a percentage of Net sales decreased by 440 basis points compared with the same period of 2025.

[0001783180-26-000026:mdna:29]
[same as prior period, unchanged from 0001783180-25-000066:mdna:29]

[0001783180-26-000026:mdna:30]
For the three months ended March 31, 2026, operating expenses, including Equity method investment net earnings, were $985 million, a 20.7% increase compared with the same period of 2025. The components were as follows:

[0001783180-26-000026:mdna:31]
|  |  | Three Months Ended March 31, |
| (In millions) |  | 2026 |  | 2025 |
| Selling, general and administrative |  | $ | (861) |  |  | $ | (729) |  |
| Research and development |  | (143) |  |  | (153) |  |
| Equity method investment net earnings |  | 31 |  |  | 44 |  |
| Other income (expense), net |  | (12) |  |  | 22 |  |
| Total operating expenses |  | $ | (985) |  |  | $ | (816) |  |
| Percentage of net sales |  | 18.4 | % |  | 15.6 | % |

[0001783180-26-000026:mdna:32]
For the three months ended March 31, 2026, Selling, general and administrative expenses were $861 million, an 18% increase compared with the same period of 2025. The increase primarily relates to an increase in costs associated with announced restructuring initiatives. In addition, higher compensation, commission and employee-related costs further impacted our results. These costs were partially offset by lower consulting and other managed expenses. The current period also included $14 million of acquisition and divestiture-related costs compared with $6 million during the three months ended March 31, 2025.

[0001783180-26-000026:mdna:33]
[same as prior period, unchanged from 0001783180-25-000066:mdna:33]

[0001783180-26-000026:mdna:34]
Investments over which we do not exercise control, but have significant influence, are accounted for using the equity method of accounting. For the three months ended March 31, 2026, Equity method investment net earnings were $31 million, a 30% decrease compared with the same period of 2025. The decrease was primarily driven by lower earnings in joint ventures within Climate Solutions Americas.

[0001783180-26-000026:mdna:35]
[same as prior period, unchanged from 0001783180-25-000066:mdna:35]

[0001783180-26-000026:mdna:36]
[same as prior period, unchanged from 0001783180-25-000066:mdna:36]

[0001783180-26-000026:mdna:37]
For the three months ended March 31, 2026, Non-operating income (expense), net was $89 million, a 10% increase compared with the same period of 2025. The components were as follows:

[0001783180-26-000026:mdna:38]
|  |  | Three Months Ended March 31, |
| (In millions) |  | 2026 |  | 2025 |
| Non-service pension benefit (expense) |  | $ | 1 |  |  | $ | 1 |  |
| Interest expense |  | $ | (111) |  |  | $ | (112) |  |
| Interest income |  | 21 |  |  | 30 |  |
| Interest (expense) income, net |  | $ | (90) |  |  | $ | (82) |  |
| Non-operating income (expense), net |  | $ | (89) |  |  | $ | (81) |  |

[0001783180-26-000026:mdna:39]
Non-operating income (expense), net includes the results from activities other than normal business operations such as interest expense, interest income and the non-service components of pension and post-retirement obligations. Interest expense is affected by the amount of debt outstanding and the interest rates on that debt. For the three months ended March 31, 2026, Interest expense was $111 million, a 1% decrease compared with the same period of 2025. During the three months ended March 31, 2025, we repaid $1.2 billion, consistent with our capital allocation strategy.

[0001783180-26-000026:mdna:40]
[same as prior period, unchanged from 0001783180-25-000066:mdna:40]

[0001783180-26-000026:mdna:41]
|  |  | Three Months Ended March 31, |
|  |  | 2026 |  | 2025 |
| Effective tax rate |  | (56.5) | % |  | 20.3 | % |

[0001783180-26-000026:mdna:42]
30

[0001783180-26-000026:mdna:43]
The Company accounts for income tax expense in accordance with ASC 740, Income Taxes ("ASC 740"), which requires an estimate of the annual effective income tax rate for the full year to be applied to the respective interim period, taking into account year-to-date amounts and projected results for the full year. The effective tax rate was (56.5)% for the three months ended March 31, 2026, compared with 20.3% for the three months ended March 31, 2025. The year-over-year decrease was primarily driven by a net $99 million tax benefit from the partial release of a valuation allowance associated with our operations in a Swiss subsidiary and a favorable settlement of $18 million related to a state income tax audit, both in the current period. In addition, the three months ended March 31, 2025, included an $8 million tax benefit generated by the purchase of investment tax credits from a third-party.

[0001783180-26-000026:mdna:44]
[same as prior period, unchanged from 0001783180-25-000066:mdna:43]

[0001783180-26-000026:mdna:45]
We report our financial results in accordance with accounting principles generally accepted in the United States ("GAAP"). In addition, we supplement the reporting of our financial information determined under GAAP with certain non-GAAP financial information. Adjusted operating profit is a non-GAAP measure and defined as consolidated operating profit (a GAAP measure), excluding restructuring costs, amortization of acquired intangible assets and other significant items of a nonoperational nature. This measure is useful to investors because it is how management assesses the operating performance of the business. A reconciliation of the amounts prepared in accordance with GAAP to the corresponding non-GAAP measure appears below and provides additional information as to the items and amounts that have been excluded from the adjusted measure.

[0001783180-26-000026:mdna:46]
|  |  | Three Months Ended March 31, |  |  |
| (In millions) |  | 2026 |  | 2025 |  |  |  |  |
| Reconciliation to Adjusted operating profit |  |  |  |  |  |  |  |  |
| Operating profit |  | $ | 259 |  |  | $ | 629 |  |  |  |  |  |
| Restructuring costs |  | 108 |  |  | 8 |  |  |  |  |  |
| Amortization of acquired intangible assets |  | 213 |  |  | 201 |  |  |  |  |  |
| Acquisition/divestiture-related costs |  | 14 |  |  | 10 |  |  |  |  |  |
| Adjusted operating profit |  | $ | 594 |  |  | $ | 848 |  |  |  |  |  |

[0001783180-26-000026:mdna:47]
[same as prior period, unchanged from 0001783180-25-000066:mdna:46]

[0001783180-26-000026:mdna:48]
31

[0001783180-26-000026:mdna:49]
[same as prior period, unchanged from 0001783180-25-000066:mdna:79]

[0001783180-26-000026:mdna:50]
[same as prior period, unchanged from 0001783180-25-000066:mdna:80]

[0001783180-26-000026:mdna:51]
[same as prior period, unchanged from 0001783180-25-000066:mdna:81]

[0001783180-26-000026:mdna:52]
[same as prior period, unchanged from 0001783180-25-000066:mdna:82]

[0001783180-26-000026:mdna:53]
[same as prior period, unchanged from 0001783180-25-000066:mdna:83]

[0001783180-26-000026:mdna:54]
[same as prior period, unchanged from 0001783180-25-000066:mdna:84]

[0001783180-26-000026:mdna:55]
[same as prior period, unchanged from 0001783180-25-000066:mdna:85]

[0001783180-26-000026:mdna:56]
Three Months Ended March 31, 2026 Compared with Three Months Ended March 31, 2025

[0001783180-26-000026:mdna:57]
[same as prior period, unchanged from 0001783180-25-000066:mdna:87]

[0001783180-26-000026:mdna:58]
|  |  | Net sales |  | Segment operating profit |  | Segment operating profit margin |
|  |  | Three Months Ended March 31, |  | Three Months Ended March 31, |  | Three Months Ended March 31, |
| (In millions) |  | 2026 |  | 2025 |  | 2026 |  | 2025 |  | 2026 |  | 2025 |
| Climate Solutions Americas |  | $ | 2,501 |  |  | $ | 2,572 |  |  | $ | 373 |  |  | $ | 570 |  |  | 14.9 | % |  | 22.2 | % |
| Climate Solutions Europe |  | 1,293 |  |  | 1,169 |  |  | 89 |  |  | 105 |  |  | 6.9 | % |  | 9.0 | % |
| Climate Solutions Asia Pacific, Middle East & Africa |  | 834 |  |  | 826 |  |  | 81 |  |  | 121 |  |  | 9.7 | % |  | 14.6 | % |
| Climate Solutions Transportation |  | 713 |  |  | 651 |  |  | 101 |  |  | 97 |  |  | 14.2 | % |  | 14.9 | % |
| Total segment |  | $ | 5,341 |  |  | $ | 5,218 |  |  | $ | 644 |  |  | $ | 893 |  |  | 12.1 | % |  | 17.1 | % |

[0001783180-26-000026:mdna:59]
[same as prior period, unchanged from 0001783180-25-000066:mdna:89]

[0001783180-26-000026:mdna:60]
|  |  | Three Months Ended March 31, |
| (In millions) |  | 2026 |  | 2025 |
| Segment operating profit |  | $ | 644 |  |  | $ | 893 |  |
| Corporate and other |  | (50) |  |  | (45) |  |
| Adjusted operating profit |  | $ | 594 |  |  | $ | 848 |  |

[0001783180-26-000026:mdna:61]
[same as prior period, unchanged from 0001783180-25-000066:mdna:92]

[0001783180-26-000026:mdna:62]
For the three months ended March 31, 2026, Net sales were $2.5 billion, a 3% decrease compared with the same period of 2025. The components of the year-over-year change were as follows:

[0001783180-26-000026:mdna:63]
|  |  | Net sales |
| Organic |  | (3) | % |
| Foreign currency translation |  | — | % |
| Total % change in Net sales |  | (3) | % |

[0001783180-26-000026:mdna:64]
The organic decrease in Net sales of 3% was driven by volume reductions within certain end-markets compared with the prior year. Lower volume in our residential business (down 12%) was primarily driven by reduced end-market demand. These results were partially offset by growth in our commercial business (up 4%) primarily driven by ongoing customer demand and improved price. In addition, higher volume in our light commercial business (up 9%) further benefited segment results.

[0001783180-26-000026:mdna:65]
For the three months ended March 31, 2026, Segment operating profit was $373 million, a 35% decrease compared with the same period of 2025. The components of the year-over-year change were as follows:

[0001783180-26-000026:mdna:66]
|  |  | Segment operating profit |
| Operational |  | (35) | % |
| Foreign currency translation |  | — | % |
| Total % change in Segment operating profit |  | (35) | % |

[0001783180-26-000026:mdna:67]
The segment operational profit decrease of 35% was primarily attributable to volume reductions in certain end-markets compared with the prior year. The associated under-absorption, in addition to higher selling, general and administrative expenses and lower earnings from equity method investments, further impacted the segment. These amounts were partially offset by favorable productivity initiatives.

[0001783180-26-000026:mdna:68]
[same as prior period, unchanged from 0001783180-25-000066:mdna:99]

[0001783180-26-000026:mdna:69]
For the three months ended March 31, 2026, Net sales were $1.3 billion, an 11% increase compared with the same period of 2025. The components of the year-over-year change were as follows:

[0001783180-26-000026:mdna:70]
|  |  | Net sales |
| Organic |  | — | % |
| Foreign currency translation |  | 11 | % |
| Total % change in Net sales |  | 11 | % |

[0001783180-26-000026:mdna:71]
Organic Net sales were flat as a result of ongoing challenges in certain end-markets compared with the prior year. Results in our residential and light commercial business increased (up 2%) as a result of higher volumes across the region partially offset by targeted pricing promotions. Results in our commercial business decreased (down 5%) due to lower volumes across the region.

[0001783180-26-000026:mdna:72]
For the three months ended March 31, 2026, Segment operating profit was $89 million, a 15% decrease compared with the same period of 2025. The components of the year-over-year change were as follows:

[0001783180-26-000026:mdna:73]
|  |  | Segment operating profit |
| Operational |  | (29) | % |
| Foreign currency translation |  | 11 | % |
| Other |  | 3 | % |
| Total % change in Segment operating profit |  | (15) | % |

[0001783180-26-000026:mdna:74]
The segment operational profit decrease of 29% was primarily attributable to volume reductions and associated under-absorption in certain end-markets compared with the prior year. In addition, price promotions, higher selling, general and administrative expenses as well as warranty-related charges further impacted the segment. These amounts were partially offset by continued productivity initiatives and higher volume in certain end-markets. Amounts reported in other represent the benefit of a legal reserve no longer required.

[0001783180-26-000026:mdna:75]
[same as prior period, unchanged from 0001783180-25-000066:mdna:106]

[0001783180-26-000026:mdna:76]
For the three months ended March 31, 2026, Net sales were $834 million, a 1% increase compared with the same period of 2025. The components of the year-over-year change were as follows:

[0001783180-26-000026:mdna:77]
|  |  | Net sales |
| Organic |  | (1) | % |
| Foreign currency translation |  | 2 | % |
| Total % change in Net sales |  | 1 | % |

[0001783180-26-000026:mdna:78]
The organic decrease in Net sales of 1% was driven by volume reductions within certain end-markets compared with the prior year. Results in China decreased (down 13%) as end-markets experienced economic challenges impacting both demand and price. These results were predominantly offset by end-market demand and improved price in the region's remaining geographies.

[0001783180-26-000026:mdna:79]
For the three months ended March 31, 2026, Segment operating profit was $81 million, a 33% decrease compared with the same period of 2025. The components of the year-over-year change were as follows:

[0001783180-26-000026:mdna:80]
|  |  | Segment operating profit |
| Operational |  | (36) | % |
| Foreign currency translation |  | 3 | % |
| Total % change in Segment operating profit |  | (33) | % |

[0001783180-26-000026:mdna:81]
The segment operational profit decrease of 36% was primarily attributable to volume reductions in certain end-markets compared with the prior year. The associated under-absorption, in addition to unfavorable product mix and higher selling, general and administrative expenses, further impacted segment results. These reductions were partially offset by favorable productivity initiatives.

[0001783180-26-000026:mdna:82]
[same as prior period, unchanged from 0001783180-25-000066:mdna:113]

[0001783180-26-000026:mdna:83]
For the three months ended March 31, 2026, Net sales were $713 million, a 10% increase compared to the same period of 2025. The components of the year-over-year change were as follows:

[0001783180-26-000026:mdna:84]
|  |  | Net sales |
| Organic |  | 5 | % |
| Foreign currency translation |  | 5 | % |
| Total % change in Net sales |  | 10 | % |

[0001783180-26-000026:mdna:85]
The organic increase in Net sales of 5% was primarily driven by volume growth within certain end-markets compared with the prior year. Container results increased (up 38%) due to ongoing end-market demand. These results were partially offset by lower volume in our global truck and trailer business (down 7%) primarily due to reduced end-market demand in all regions.

[0001783180-26-000026:mdna:86]
For the three months ended March 31, 2026, Segment operating profit was $101 million, a 4% increase compared with the same period of 2025. The components of the year-over-year change were as follows:

[0001783180-26-000026:mdna:87]
|  |  | Segment operating profit |
| Operational |  | (1) | % |
| Foreign currency translation |  | 6 | % |
| Acquisitions and divestitures, net |  | (1) | % |
| Total % change in Segment operating profit |  | 4 | % |

[0001783180-26-000026:mdna:88]
The segment operational profit decrease of 1% was primarily driven by lower volumes in certain end-markets compared with the prior year. In addition, costs associated with warranty-related issues and higher selling, general and administrative costs further impacted the segment. These amounts were partially offset by favorable productivity initiatives. In addition, higher volumes in certain end-markets provided additional benefit in the segment but led to unfavorable mix.

[0001783180-26-000026:mdna:89]
[same as prior period, unchanged from 0001783180-25-000066:mdna:156]

[0001783180-26-000026:mdna:90]
[same as prior period, unchanged from 0001783180-25-000066:mdna:157]

[0001783180-26-000026:mdna:91]
As of March 31, 2026, we had cash and cash equivalents of $1.4 billion, of which approximately 94% was held by our foreign subsidiaries. We manage our worldwide cash requirements by reviewing available funds and the cost effectiveness with which we can access funds held by foreign subsidiaries. On occasion, we are required to maintain cash deposits in connection with contractual obligations related to acquisitions, divestitures or other legal obligations. As of March 31, 2026, and December 31, 2025, the amount of such restricted cash was approximately $3 million and $2 million, respectively.

[0001783180-26-000026:mdna:92]
[same as prior period, unchanged from 0001783180-25-000066:mdna:159]

[0001783180-26-000026:mdna:93]
[same as prior period, unchanged from 0001783180-25-000066:mdna:160]

[0001783180-26-000026:mdna:94]
[same as prior period, unchanged from 0001783180-25-000066:mdna:161]

[0001783180-26-000026:mdna:95]
| (In millions) |  | March 31,2026 |  | December 31,2025 |
| Cash and cash equivalents |  | $ | 1,371 |  |  | $ | 1,555 |  |
| Total debt |  | 12,158 |  |  | 11,833 |  |
| Total equity |  | 13,801 |  |  | 14,128 |  |
| Net debt (total debt less cash and cash equivalents) |  | 10,787 |  |  | 10,278 |  |
| Total capitalization (total debt plus total equity) |  | 25,959 |  |  | 25,961 |  |
| Net capitalization (total debt plus total equity less cash and cash equivalents) |  | 24,588 |  |  | 24,406 |  |
| Total debt to total capitalization |  | 47 | % |  | 46 | % |
| Net debt to net capitalization |  | 44 | % |  | 42 | % |

[0001783180-26-000026:mdna:96]
[same as prior period, unchanged from 0001783180-25-000066:mdna:163]

[0001783180-26-000026:mdna:97]
We maintain a $2.0 billion USD-denominated facility and a $500 million Euro-denominated facility as part of an unsecured, unsubordinated commercial paper program which we can use for general corporate purposes, including the funding of working capital and potential acquisitions. In addition, we maintain a $2.5 billion revolving credit facility with various banks (the "Revolving Credit Facility") that matures in December 2029 which supports our commercial paper borrowing program and can be used for general corporate purposes. A ratings-based commitment fee is charged on unused commitments. As of March 31, 2026, we had $708 million and zero borrowings outstanding under our commercial paper program and our Revolving Credit Facility, respectively.

[0001783180-26-000026:mdna:98]
Our short-term obligations primarily consist of current maturities of long-term debt. Our long-term obligations primarily consist of long-term notes with maturity dates ranging between 2027 and 2054. Interest payments related to long-term notes are expected to approximate $406 million per year, reflecting an approximate weighted-average interest rate of 3.65%. Any borrowings from the Revolving Credit Facility are subject to variable interest rates. See Note 5 – Borrowings and Lines of Credit in the Notes to the accompanying Unaudited Condensed Consolidated Financial Statements for additional information regarding the terms of our long-term debt obligations.

[0001783180-26-000026:mdna:99]
Our credit ratings are periodically reviewed by the major independent debt-rating agencies. As of March 31, 2026, Standards & Poor's Global Inc. and Moody’s Investor Service Inc. have ratings on our debt set forth in the table below:

[0001783180-26-000026:mdna:100]
[same as prior period, unchanged from 0001783180-25-000066:mdna:167]

[0001783180-26-000026:mdna:101]
Planned Divestitures

[0001783180-26-000026:mdna:102]
On December 16, 2025, we entered into a purchase agreement to sell our Riello business with expected gross proceeds of approximately $430 million. The transaction is expected to close in the first half of 2026 and is subject to customary closing conditions and regulatory approvals.

[0001783180-26-000026:mdna:103]
[same as prior period, unchanged from 0001783180-25-000066:mdna:170]

[0001783180-26-000026:mdna:104]
We may repurchase our outstanding common stock from time to time subject to market conditions and at our discretion. Repurchases occur in the open market or through one or more other public or private transactions pursuant to plans complying with Rules 10b5-1 and 10b-18 under the Exchange Act. Since the initial authorization in February 2021, our Board of Directors authorized the repurchase of up to $12.1 billion of our outstanding common stock.

[0001783180-26-000026:mdna:105]
During the three months ended March 31, 2026, we repurchased 5.0 million shares of common stock for an aggregate purchase price of $306 million. As a result, we had approximately $5.0 billion remaining under the current authorization at March 31, 2026.

[0001783180-26-000026:mdna:106]
[same as prior period, unchanged from 0001783180-25-000066:mdna:173]

[0001783180-26-000026:mdna:107]
We paid dividends on common stock during the three months ended March 31, 2026, totaling $201 million. In April 2026, the Board of Directors declared a dividend of $0.24 per share of common stock payable on May 22, 2026, to shareowners of record at the close of business on May 4, 2026.

[0001783180-26-000026:mdna:108]
[same as prior period, unchanged from 0001783180-25-000066:mdna:175]

[0001783180-26-000026:mdna:109]
[same as prior period, unchanged from 0001783180-25-000066:mdna:176]

[0001783180-26-000026:mdna:110]
|  |  | Three Months EndedMarch 31, |
| (In millions) |  | 2026 |  | 2025 |
| Net cash flows provided by (used in): |  |  |  |  |
| Continuing operating activities |  | $ | 66 |  |  | $ | 488 |  |
| Continuing investing activities |  | (65) |  |  | (30) |  |
| Continuing financing activities |  | (141) |  |  | (2,747) |  |

[0001783180-26-000026:mdna:111]
Cash flows from continuing operating activities primarily represent inflows and outflows associated with our continuing operations. Primary activities include net earnings from continuing operations adjusted for non-cash transactions, working capital changes and changes in other assets and liabilities. The year-over-year decrease in net cash provided by continuing operating activities was primarily driven by lower net earnings and higher working capital balances compared with the prior period.

[0001783180-26-000026:mdna:112]
Cash flows from continuing investing activities primarily represent inflows and outflows associated with long-term assets. Primary activities include capital expenditures, acquisitions, divestitures and proceeds from the sale of fixed assets. During the three months ended March 31, 2026, net cash used in continuing investing activities was $65 million. The primary driver of the outflow related to $94 million of capital expenditures which was partially offset by $35 million of cash inflow related to settlement of derivatives. During the three months ended March 31, 2025, net cash used in continuing investing activities was $30 million. The primary driver of the outflow related to $63 million of capital expenditures which was partially offset by $36 million of cash inflow related to settlement of derivatives.

[0001783180-26-000026:mdna:113]
Cash flows from continuing financing activities primarily represent inflows and outflows associated with equity or borrowings. During the three months ended March 31, 2026, net cash used in continuing financing activities was $141 million. The primary driver of the outflow was related to repurchases of our common stock totaling $306 million. In addition, we paid $201 million in dividends to our common shareowners. These outflows were partially offset by short-term borrowings of $371 million. During the three months ended March 31, 2025, net cash used in continuing financing activities was $2.7 billion. The primary driver of the outflow was related to repurchases of our common stock totaling $1.3 billion. In addition, we made long-term debt repayments of $1.2 billion and the payment of $198 million in dividends to our common shareowners.
