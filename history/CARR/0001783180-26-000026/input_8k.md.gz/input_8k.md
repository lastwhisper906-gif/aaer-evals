# CARR 8-K — 0001783180-26-000023 filed 2026-04-30

## item codes, every 8-K on or before 2026-04-30

- 2026-04-30 0001783180-26-000023 — 2.02, 9.01
- 2026-04-16 0000950142-26-001146 — 5.07
- 2026-02-05 0001783180-26-000005 — 2.02
- 2025-10-28 0001783180-25-000063 — 2.02, 7.01, 9.01
- 2025-09-04 0000950142-25-002375 — 5.02
- 2025-07-29 0001783180-25-000058 — 8.01, 9.01
- 2025-07-29 0001783180-25-000047 — 2.02, 9.01
- 2025-06-05 0000950142-25-001575 — 7.01
- 2025-05-01 0001783180-25-000028 — 2.02, 7.01, 9.01
- 2025-04-17 0000950142-25-001103 — 5.02
- 2025-04-11 0001783180-25-000021 — 5.02, 5.07, 9.01
- 2025-02-11 0001783180-25-000006 — 2.02, 9.01
- 2025-01-15 0000950142-25-000133 — 5.02, 9.01
- 2024-12-20 0001783180-24-000093 — 1.01, 1.02, 2.03, 9.01
- 2024-12-03 0000950142-24-002874 — 5.02
- 2024-12-02 0000950142-24-002865 — 7.01, 9.01
- 2024-11-08 0000950142-24-002699 — 1.01, 2.03, 9.01
- 2024-10-28 0000950142-24-002640 — 8.01
- 2024-10-28 0000950142-24-002638 — 8.01
- 2024-10-24 0001783180-24-000084 — 2.02, 7.01, 9.01
- 2024-10-18 0000950142-24-002601 — 1.01
- 2024-08-15 0001140361-24-037426 — 7.01, 9.01
- 2024-07-25 0001783180-24-000075 — 2.02, 9.01
- 2024-06-21 0001783180-24-000069 — 5.02
- 2024-06-21 0000950142-24-001676 — 5.02
- 2024-06-07 0001783180-24-000062 — 5.02, 5.03, 9.01
- 2024-06-03 0000950142-24-001538 — 1.02, 7.01, 9.01
- 2024-05-17 0001783180-24-000049 — 1.01, 1.02, 2.03, 9.01
- 2024-04-25 0001783180-24-000042 — 2.02, 9.01
- 2024-04-19 0001783180-24-000035 — 5.07, 9.01
- 2024-04-19 0000950142-24-001162 — 5.07 — amendment of 0001783180-24-000035
- 2024-02-06 0001783180-24-000007 — 2.02, 9.01
- 2024-02-01 0000950142-24-000264 — 5.02
- 2024-01-02 0001140361-24-000034 — 1.01, 2.01, 2.03, 5.02, 7.01, 9.01
- 2023-12-13 0001140361-23-057415 — 1.01, 9.01
- 2023-12-08 0001140361-23-056751 — 7.01, 9.01
- 2023-11-30 0000950142-23-002884 — 1.01, 2.03, 8.01, 9.01
- 2023-11-16 0000950142-23-002788 — 8.01, 9.01
- 2023-11-13 0001140361-23-052667 — 7.01, 8.01, 9.01
- 2023-10-26 0001783180-23-000063 — 2.02, 9.01
- 2023-07-27 0001783180-23-000053 — 2.02, 9.01
- 2023-06-12 0000950142-23-001664 — 5.02
- 2023-05-25 0000950142-23-001541 — 1.01, 1.02, 2.03, 9.01
- 2023-04-26 0000950142-23-001205 — 1.01, 9.01
- 2023-04-25 0001783180-23-000036 — 2.02, 7.01, 9.01
- 2023-04-25 0000950142-23-001199 — 7.01, 8.01, 9.01
- 2023-04-21 0001783180-23-000032 — 5.07, 9.01
- 2023-02-07 0001783180-23-000010 — 2.02, 9.01
- 2022-10-27 0001783180-22-000054 — 2.02, 7.01, 9.01
- 2022-09-29 0000950142-22-002805 — 5.02, 9.01
- 2022-07-28 0001783180-22-000045 — 2.02, 9.01
- 2022-04-28 0001783180-22-000032 — 2.02, 9.01
- 2022-04-15 0001783180-22-000024 — 5.07, 9.01
- 2022-02-08 0001783180-22-000008 — 2.02, 9.01
- 2022-02-07 0000950142-22-000510 — 8.01, 9.01
- 2022-01-03 0000950142-22-000023 — 8.01, 9.01
- 2021-12-17 0001783180-21-000071 — 5.02, 7.01, 9.01
- 2021-11-23 0001783180-21-000068 — 5.03, 9.01
- 2021-10-28 0001783180-21-000062 — 2.02, 9.01
- 2021-08-27 0001783180-21-000056 — 8.01
- 2021-07-30 0001783180-21-000053 — 1.01
- 2021-07-29 0001783180-21-000049 — 2.02, 8.01, 9.01
- 2021-07-27 0000950142-21-002448 — 8.01, 9.01
- 2021-07-15 0000950142-21-002362 — 5.02, 9.01
- 2021-06-09 0000950142-21-001885 — 5.02, 9.01
- 2021-04-29 0001783180-21-000029 — 2.02, 9.01
- 2021-04-22 0001140361-21-013889 — 5.02, 9.01
- 2021-04-20 0001783180-21-000021 — 5.07, 9.01
- 2021-04-19 0000950142-21-001308 — 8.01, 9.01
- 2021-02-09 0001783180-21-000009 — 2.02, 9.01
- 2021-02-05 0001140361-21-003513 — 8.01, 9.01
- 2020-12-23 0001140361-20-029419 — 7.01, 9.01
- 2020-12-22 0001140361-20-029097 — 8.01
- 2020-12-14 0001140361-20-028246 — 5.03, 9.01
- 2020-12-07 0001140361-20-027515 — 1.01, 7.01, 9.01
- 2020-10-29 0001783180-20-000063 — 2.02, 9.01
- 2020-10-19 0001140361-20-023241 — 5.02, 7.01, 9.01
- 2020-09-23 0001140361-20-021220 — 8.01, 9.01
- 2020-09-22 0001140361-20-021124 — 8.01, 9.01
- 2020-07-30 0001783180-20-000045 — 2.02, 9.01
- 2020-06-19 0001140361-20-014325 — 1.01, 2.03, 9.01
- 2020-06-16 0001140361-20-013880 — 8.01, 9.01
- 2020-06-03 0001140361-20-012939 — 1.01, 9.01
- 2020-05-08 0001783180-20-000013 — 2.02, 9.01
- 2020-04-03 0001140361-20-007888 — 1.01, 5.02, 5.03, 5.05, 7.01, 9.01
- 2020-03-16 0001140361-20-005868 — 8.01, 9.01

## late-filing notifications on or before 2026-04-30

- none on or before 2026-04-30

## item 2.02 — earnings release, exhibit 99.1

[0001783180-26-000023:8k_2_02:1]
EX-99
2
a99-q12026earningsexhibit.htm
EX-99

[0001783180-26-000023:8k_2_02:2]
Document

[0001783180-26-000023:8k_2_02:3]
Exhibit 99

[0001783180-26-000023:8k_2_02:4]
Carrier Reports First Quarter 2026 Results

[0001783180-26-000023:8k_2_02:5]
•Data center orders up over 500%; backlog fully covers expected 2026 data center sales

[0001783180-26-000023:8k_2_02:6]
•Total company orders1 up 11%; Commercial HVAC1 up 35%

[0001783180-26-000023:8k_2_02:7]
•Net sales up 2%; organic sales down 1%

[0001783180-26-000023:8k_2_02:8]
•GAAP EPS of $0.28 and adjusted EPS of $0.57

[0001783180-26-000023:8k_2_02:9]
•Net cash flows from operating activities of $79 million and free cash flow of ($15) million

[0001783180-26-000023:8k_2_02:10]
•Returned ~$500 million to shareholders through dividends and repurchases

[0001783180-26-000023:8k_2_02:11]
•Reaffirms full year outlook

[0001783180-26-000023:8k_2_02:12]
PALM BEACH GARDENS, Fla., April 30, 2026 – Carrier Global Corporation (NYSE:CARR), global leader in intelligent climate and energy solutions, today reported financial results for the first quarter of 2026.

[0001783180-26-000023:8k_2_02:13]
“We started the year with better than expected sales performance across the portfolio,” said Chairman & CEO David Gitlin. “Orders in our global Commercial HVAC1 business increased 35%, helped by data centers which were up over 500% in the quarter. The strong double-digit sequential increase in Commercial HVAC backlog gives us the confidence to drive our sixth consecutive year of double-digit growth in this business. CSA Light commercial and CSE Residential both delivered growth, while CSA Residential came in better than expected. I am pleased with the team's performance in the first quarter, and we are reaffirming our full-year outlook.”

[0001783180-26-000023:8k_2_02:14]
1 Excludes NORESCO

[0001783180-26-000023:8k_2_02:15]
1

[0001783180-26-000023:8k_2_02:16]
First Quarter 2026 Results

[0001783180-26-000023:8k_2_02:17]
Total Company

[0001783180-26-000023:8k_2_02:18]
|  | (Unaudited) |
|  | Three Months Ended March 31 |  |
| (In millions) | 2026 | 2025 | Change |  |  |  |
| Net sales | $ | 5,341 |  | $ | 5,218 |  | 2 | % |  |  |  |
| Organic sales | (1) | % |  |  |  |  |  |
| Operating profit | $ | 259 |  | $ | 629 |  | (59) | % |  |  |  |
| Operating margin | 4.8 | % | 12.1 | % | (730) bps |  |  |  |
| Adjusted operating profit | $ | 594 |  | $ | 848 |  | (30) | % |  |  |  |
| Adjusted operating margin | 11.1 | % | 16.3 | % | (520) bps |  |  |  |
| Diluted earnings per share: |  |  |  |  |  |  |
| Continuing operations | $ | 0.28 |  | $ | 0.47 |  | (40) | % |  |  |  |
| Continuing operations - Adjusted | $ | 0.57 |  | $ | 0.65 |  | (12) | % |  |  |  |

[0001783180-26-000023:8k_2_02:19]
Carrier’s first-quarter sales of $5.3 billion increased 2% compared to the prior year. Organic sales declined 1%, more than offset by a 3% tailwind from foreign currency translation.

[0001783180-26-000023:8k_2_02:20]
GAAP operating profit of $259 million in the quarter declined 59% from last year, driven by the CSA, CSE and CSAME segments.  
    Adjusted operating profit of $594 million was down 30% from last year, predominantly due to lower sales in our CSA Residential business and continued headwinds in China Residential and Light Commercial (RLC).

[0001783180-26-000023:8k_2_02:21]
Net earnings from continuing operations were $239 million and adjusted net earnings from continuing operations were $482 million. GAAP EPS from continuing operations was $0.28 and adjusted EPS was $0.57, down 40% and 12% year-over-year, respectively. The declines were primarily driven by lower operating profit, partially offset by a lower tax rate and benefits of a lower share count.

[0001783180-26-000023:8k_2_02:22]
2

[0001783180-26-000023:8k_2_02:23]
Climate Solutions Americas (CSA)

[0001783180-26-000023:8k_2_02:24]
|  | (Unaudited) |
|  | Three Months Ended March 31 |  |
| (In millions) | 2026 | 2025 | Change |  |  |  |
| Net sales | $ | 2,501 |  | $ | 2,572 |  | (3) | % |  |  |  |
| Organic sales | (3) | % |  |  |  |  |  |
| Segment operating profit | $ | 373 |  | $ | 570 |  | (35) | % |  |  |  |
| Segment operating margin | 14.9 | % | 22.2 | % | (730) bps |  |  |  |

[0001783180-26-000023:8k_2_02:25]
CSA segment sales declined 3%. Organic sales were down 3% driven by Residential, down about 12%, partially offset by strength in Light commercial and Commercial1, up 9% and 1% respectively.

[0001783180-26-000023:8k_2_02:26]
Segment operating margin decreased 730 basis points largely reflecting lower Residential sales and associated factory under-absorption.

[0001783180-26-000023:8k_2_02:27]
Climate Solutions Europe (CSE)

[0001783180-26-000023:8k_2_02:28]
|  | (Unaudited) |
|  | Three Months Ended March 31 |  |
| (In millions) | 2026 | 2025 | Change |  |  |  |
| Net sales | $ | 1,293 |  | $ | 1,169 |  | 11 | % |  |  |  |
| Organic sales | — | % |  |  |  |  |  |
| Segment operating profit | $ | 89 |  | $ | 105 |  | (15) | % |  |  |  |
| Segment operating margin | 6.9 | % | 9.0 | % | (210) bps |  |  |  |

[0001783180-26-000023:8k_2_02:29]
CSE segment sales increased 11%. Organic sales were flat with RLC up low-single digits and Commercial down mid-single digits.

[0001783180-26-000023:8k_2_02:30]
Segment operating margin decreased 210 basis points driven by lower Commercial volume and higher promotions partially offset by RLC volume growth and strong productivity.

[0001783180-26-000023:8k_2_02:31]
1 Excludes NORESCO

[0001783180-26-000023:8k_2_02:32]
3

[0001783180-26-000023:8k_2_02:33]
Climate Solutions Asia Pacific, Middle East & Africa (CSAME)

[0001783180-26-000023:8k_2_02:34]
|  | (Unaudited) |
|  | Three Months Ended March 31 |  |
| (In millions) | 2026 | 2025 | Change |  |  |  |
| Net sales | $ | 834 |  | $ | 826 |  | 1 | % |  |  |  |
| Organic sales | (1) | % |  |  |  |  |  |
| Segment operating profit | $ | 81 |  | $ | 121 |  | (33) | % |  |  |  |
| Segment operating margin | 9.7 | % | 14.6 | % | (490) bps |  |  |  |

[0001783180-26-000023:8k_2_02:35]
CSAME segment sales increased 1%. Organic sales were down 1% mainly driven by RLC in China, partially offset by strong Commercial growth outside of China, particularly in India and Australia.

[0001783180-26-000023:8k_2_02:36]
Segment operating margin decreased 490 basis points as expected, driven mainly by China RLC.

[0001783180-26-000023:8k_2_02:37]
Climate Solutions Transportation (CST)

[0001783180-26-000023:8k_2_02:38]
|  | (Unaudited) |
|  | Three Months Ended March 31 |  |
| (In millions) | 2026 | 2025 | Change |  |  |  |
| Net sales | $ | 713 |  | $ | 651 |  | 10 | % |  |  |  |
| Organic sales | 5 | % |  |  |  |  |  |
| Segment operating profit | $ | 101 |  | $ | 97 |  | 4 | % |  |  |  |
| Segment operating margin | 14.2 | % | 14.9 | % | (70) bps |  |  |  |

[0001783180-26-000023:8k_2_02:39]
CST sales increased 10% driven by strong growth in Container. Organic sales increased 5% with 38% growth in Container, partially offset by a decline in Global Truck and Trailer, down high-single digits.

[0001783180-26-000023:8k_2_02:40]
Segment operating margin declined 70 basis points, due to unfavorable mix.

[0001783180-26-000023:8k_2_02:41]
4

[0001783180-26-000023:8k_2_02:42]
Cash Flow

[0001783180-26-000023:8k_2_02:43]
|  |  | (Unaudited) |  |  |
|  |  | Three Months Ended March 31, |  |  |
| (In millions) |  | 2026 |  | 2025 |  |  |  |  |
| Net cash flows provided by operating activities |  | $ | 79 |  |  | $ | 483 |  |  |  |  |  |
| Less: Capital expenditures |  | (94) |  |  | (63) |  |  |  |  |  |
| Free cash flow |  | $ | (15) |  |  | $ | 420 |  |  |  |  |  |

[0001783180-26-000023:8k_2_02:44]
Net cash flows generated from operating activities were $79 million and capital expenditures were $94 million, resulting in free cash flow of ($15) million.

[0001783180-26-000023:8k_2_02:45]
5

[0001783180-26-000023:8k_2_02:46]
Full-Year 2026 Guidance**

[0001783180-26-000023:8k_2_02:47]
|  | Current Guidance** | Prior Guidance |  |
| Sales | ~$22 billion~$250 million revenue headwind from Riello exitOrganic* flat to up LSDFX 1%Net, Acquisitions / Divestitures (1%) | ~$22 billion~$350 million revenue headwind from Riello exitOrganic* flat to up LSDFX 1%Net, Acquisitions / Divestitures (1%) |  |
| Adjusted Operating Profit* | ~$3.4 billion | ~$3.4 billion |  |
| Adjusted EPS* | ~$2.80 | ~$2.80 |  |
| Free Cash Flow* | ~$2 billion | ~$2 billion |  |

[0001783180-26-000023:8k_2_02:48]
Riello divestiture expected to close by the end of Q2 2026; prior guidance assumed the divestiture closed by the
 end of Q1 2026.

[0001783180-26-000023:8k_2_02:49]
*Note: When the company provides expectations for organic sales, adjusted operating profit, adjusted operating profit, adjusted EPS and free cash flow on a forward-looking basis, a reconciliation of the differences between the non-GAAP expectations and the corresponding GAAP measures generally is not available without unreasonable effort. See “Use and Definitions of Non-GAAP Financial Measures” below for additional information.

[0001783180-26-000023:8k_2_02:50]
**As of April 30, 2026

[0001783180-26-000023:8k_2_02:51]
Conference Call

[0001783180-26-000023:8k_2_02:52]
Carrier will host a webcast of its earnings conference call today, Thursday, April 30, 2026, at 7:30 a.m. ET. To access the webcast, visit the Events & Presentations section of the Carrier Investor Relations site at ir.carrier.com/news-and-events/events-and-presentations. For alternative dial-in information, please contact Carrier investor relations at InvestorRelations@Carrier.com.

[0001783180-26-000023:8k_2_02:53]
6

[0001783180-26-000023:8k_2_02:54]
Cautionary Statement

[0001783180-26-000023:8k_2_02:55]
7

[0001783180-26-000023:8k_2_02:56]
About Carrier

[0001783180-26-000023:8k_2_02:57]
Carrier Global Corporation, global leader in intelligent climate and energy solutions, is committed to creating innovations that bring comfort, safety and sustainability to life. Through cutting-edge advancements in climate solutions such as temperature control, air quality and transportation, we improve lives, empower critical industries and ensure the safe transport of food, life-saving medicines and more. Since inventing modern air conditioning in 1902, we lead with purpose: enhancing the lives we live and the world we share. We continue to lead because of our world-class, inclusive workforce that puts the customer at the center of everything we do. For more information, visit www.carrier.com or follow Carrier on social media at @Carrier.

[0001783180-26-000023:8k_2_02:58]
Contact:

[0001783180-26-000023:8k_2_02:59]
Investor Relations

[0001783180-26-000023:8k_2_02:60]
Michael Rednor

[0001783180-26-000023:8k_2_02:61]
561-365-2020

[0001783180-26-000023:8k_2_02:62]
InvestorRelations@Carrier.com

[0001783180-26-000023:8k_2_02:63]
Media Inquiries

[0001783180-26-000023:8k_2_02:64]
Rob Six

[0001783180-26-000023:8k_2_02:65]
561-365-2020

[0001783180-26-000023:8k_2_02:66]
Robert.Six@Carrier.com

[0001783180-26-000023:8k_2_02:67]
8

[0001783180-26-000023:8k_2_02:68]
SELECTED FINANCIAL DATA, NON-GAAP MEASURES AND DEFINITIONS

[0001783180-26-000023:8k_2_02:69]
Following are tables that present selected financial data of Carrier Global Corporation (“Carrier”). Also included are reconciliations of non-GAAP measures to their most comparable GAAP measures.

[0001783180-26-000023:8k_2_02:70]
Use and Definitions of Non-GAAP Financial Measures

[0001783180-26-000023:8k_2_02:71]
Carrier reports its financial results in accordance with accounting principles generally accepted in the United States ("GAAP"). We supplement the reporting of our financial information determined under GAAP with certain non-GAAP financial information. The non-GAAP information presented provides investors with additional useful information, but should not be considered in isolation or as substitutes for the related GAAP measures. Moreover, other companies may define non-GAAP measures differently, which limits the usefulness of these measures for comparisons with such other companies. We encourage investors to review our financial statements and publicly filed reports in their entirety and not to rely on any single financial measure. A reconciliation of the non-GAAP measures to the corresponding amounts prepared in accordance with GAAP appears in the tables in this Appendix. The tables provide additional information as to the items and amounts that have been excluded from the adjusted measures.

[0001783180-26-000023:8k_2_02:72]
Organic sales, adjusted operating profit, adjusted operating margin, adjusted earnings per share (“EPS”), adjusted effective tax rate and net debt are non-GAAP financial measures and are associated with Carrier's continuing operations unless specifically noted.

[0001783180-26-000023:8k_2_02:73]
Organic sales represents consolidated net sales (a GAAP measure), excluding the impact of foreign currency translation, acquisitions and divestitures completed in the preceding twelve months and other significant items of a nonoperational nature (hereinafter referred to as “other significant items”). Adjusted operating profit represents consolidated operating profit (a GAAP measure), excluding restructuring costs, amortization of acquired intangible assets and other significant items. Adjusted operating margin represents adjusted operating profit as a percentage of consolidated net sales (a GAAP measure). Adjusted EPS represents diluted earnings per share (a GAAP measure), excluding restructuring costs, amortization of acquired intangible assets and other significant items. The adjusted effective tax rate represents the effective tax rate (a GAAP measure), excluding restructuring costs, amortization of acquired intangible assets and other significant items. Net debt represents long-term debt (a GAAP measure) less cash and cash equivalents (a GAAP measure).

[0001783180-26-000023:8k_2_02:74]
Segment operating profit is the measure of profit and loss that the Chief Operating Decision Maker uses to evaluate segment profitability. Segment operating profit represents operating profit (a GAAP measure) adjusted to exclude restructuring costs, amortization of acquired intangible assets and other significant items of a nonoperational nature.

[0001783180-26-000023:8k_2_02:75]
Free cash flow is a non-GAAP financial measure that represents net cash flows provided by continuing operating activities (a GAAP measure) less capital expenditures. Management believes free cash flow is a useful measure of liquidity and an additional basis for assessing Carrier’s ability to fund its activities, including the financing of acquisitions, debt service, repurchases of Carrier's common stock and distribution of earnings to shareowners. Orders are contractual commitments with customers to provide specified goods or services for an agreed upon price and may not be subject to penalty if cancelled.

[0001783180-26-000023:8k_2_02:76]
When Carrier provides our expectations for organic sales, adjusted operating profit (including on a segment basis), adjusted operating margin (including on a segment basis), adjusted effective tax rate, adjusted EPS, free cash flow, and interest expense, net on a forward-looking basis, a reconciliation of the differences between the non-GAAP expectations and the corresponding GAAP measures generally is not available without unreasonable effort due to potentially high variability, complexity and low visibility as to the items that would be excluded from the GAAP measure in the relevant future period, such as unusual gains and losses, the ultimate outcome of pending litigation, fluctuations in foreign currency exchange rates, the impact and timing of potential acquisitions and divestitures, future restructuring costs, and other structural changes or their probable significance. The variability of the excluded items may have a significant, and potentially unpredictable, impact on our future GAAP results.

[0001783180-26-000023:8k_2_02:77]
9

[0001783180-26-000023:8k_2_02:78]
Carrier Global Corporation

[0001783180-26-000023:8k_2_02:79]
Condensed Consolidated Statement of Operations

[0001783180-26-000023:8k_2_02:80]
|  |  | (Unaudited) |
|  |  | Three Months Ended March 31, |  |  |
| (In millions, except per share amounts) |  | 2026 |  | 2025 |  |  |  |  |
| Net sales |  |  |  |  |  |  |  |  |
| Product sales |  | $ | 4,667 |  |  | $ | 4,652 |  |  |  |  |  |
| Service sales |  | 674 |  |  | 566 |  |  |  |  |  |
| Total Net sales |  | 5,341 |  |  | 5,218 |  |  |  |  |  |
| Costs and expenses |  |  |  |  |  |  |  |  |
| Cost of products sold |  | (3,591) |  |  | (3,358) |  |  |  |  |  |
| Cost of services sold |  | (506) |  |  | (415) |  |  |  |  |  |
| Research and development |  | (143) |  |  | (153) |  |  |  |  |  |
| Selling, general and administrative |  | (861) |  |  | (729) |  |  |  |  |  |
| Total Costs and expenses |  | (5,101) |  |  | (4,655) |  |  |  |  |  |
| Equity method investment net earnings |  | 31 |  |  | 44 |  |  |  |  |  |
| Other income (expense), net |  | (12) |  |  | 22 |  |  |  |  |  |
| Operating profit |  | 259 |  |  | 629 |  |  |  |  |  |
| Non-service pension benefit (expense) |  | 1 |  |  | 1 |  |  |  |  |  |
| Interest (expense) income, net |  | (90) |  |  | (82) |  |  |  |  |  |
| Earnings before income taxes |  | 170 |  |  | 548 |  |  |  |  |  |
| Income tax (expense) benefit |  | 96 |  |  | (111) |  |  |  |  |  |
| Earnings from continuing operations |  | 266 |  |  | 437 |  |  |  |  |  |
| Discontinued operations, net of tax |  | (1) |  |  | — |  |  |  |  |  |
| Net earnings (loss) |  | 265 |  |  | 437 |  |  |  |  |  |
| Less: Non-controlling interest in subsidiaries' |  | 27 |  |  | 25 |  |  |  |  |  |
| Net earnings (loss) attributable to common shareowners |  | $ | 238 |  |  | $ | 412 |  |  |  |  |  |
| Amounts attributable to common shareowners: |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 239 |  |  | $ | 412 |  |  |  |  |  |
| Discontinued operations |  | (1) |  |  | — |  |  |  |  |  |
| Net earnings (loss) attributable to common shareowners |  | $ | 238 |  |  | $ | 412 |  |  |  |  |  |
| Earnings per share |  |  |  |  |  |  |  |  |
| Basic: |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 0.29 |  |  | $ | 0.47 |  |  |  |  |  |
| Discontinued operations |  | — |  |  | — |  |  |  |  |  |
| Net earnings (loss) |  | $ | 0.29 |  |  | $ | 0.47 |  |  |  |  |  |
| Diluted: |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 0.28 |  |  | $ | 0.47 |  |  |  |  |  |
| Discontinued operations |  | — |  |  | — |  |  |  |  |  |
| Net earnings (loss) |  | $ | 0.28 |  |  | $ | 0.47 |  |  |  |  |  |
| Weighted-average number of shares outstanding |  |  |  |  |  |  |  |  |
| Basic |  | 835.0 |  |  | 866.9 |  |  |  |  |  |
| Diluted |  | 842.8 |  |  | 878.3 |  |  |  |  |  |

[0001783180-26-000023:8k_2_02:81]
10

[0001783180-26-000023:8k_2_02:82]
Carrier Global Corporation

[0001783180-26-000023:8k_2_02:83]
Condensed Consolidated Balance Sheet

[0001783180-26-000023:8k_2_02:84]
|  |  | (Unaudited) |
| (In millions) |  | March 31, 2026 |  | December 31, 2025 |
| Assets |  |  |  |  |
| Cash and cash equivalents |  | $ | 1,371 |  |  | $ | 1,555 |  |
| Accounts receivable, net |  | 3,130 |  |  | 2,639 |  |
| Inventories, net |  | 2,581 |  |  | 2,483 |  |
| Assets held for sale |  | 621 |  |  | 592 |  |
| Other current assets |  | 1,315 |  |  | 1,264 |  |
| Total current assets |  | 9,018 |  |  | 8,533 |  |
| Future income tax benefits |  | 1,137 |  |  | 1,074 |  |
| Fixed assets, net |  | 3,122 |  |  | 3,165 |  |
| Operating lease right-of-use assets |  | 551 |  |  | 546 |  |
| Intangible assets, net |  | 5,987 |  |  | 6,326 |  |
| Goodwill |  | 15,313 |  |  | 15,501 |  |
| Pension and post-retirement assets |  | 58 |  |  | 56 |  |
| Equity method investments |  | 1,331 |  |  | 1,321 |  |
| Other assets |  | 669 |  |  | 668 |  |
| Total Assets |  | $ | 37,186 |  |  | $ | 37,190 |  |
| Liabilities and Equity |  |  |  |  |
| Accounts payable |  | $ | 2,979 |  |  | $ | 2,702 |  |
| Accrued liabilities |  | 3,700 |  |  | 3,774 |  |
| Liabilities held for sale |  | 170 |  |  | 170 |  |
| Short-term borrowings and current portion of long-term debt |  | 1,736 |  |  | 468 |  |
| Total current liabilities |  | 8,585 |  |  | 7,114 |  |
| Long-term debt |  | 10,422 |  |  | 11,365 |  |
| Future pension and post-retirement obligations |  | 188 |  |  | 192 |  |
| Future income tax obligations |  | 1,688 |  |  | 1,833 |  |
| Operating lease liabilities |  | 415 |  |  | 418 |  |
| Other long-term liabilities |  | 2,087 |  |  | 2,140 |  |
| Total Liabilities |  | 23,385 |  |  | 23,062 |  |
| Equity |  |  |  |  |
| Common stock |  | 10 |  |  | 10 |  |
| Treasury stock |  | (7,104) |  |  | (6,795) |  |
| Additional paid-in capital |  | 8,675 |  |  | 8,665 |  |
| Retained earnings |  | 12,431 |  |  | 12,193 |  |
| Accumulated other comprehensive income (loss) |  | (560) |  |  | (269) |  |
| Non-controlling interest |  | 349 |  |  | 324 |  |
| Total Equity |  | 13,801 |  |  | 14,128 |  |
| Total Liabilities and Equity |  | $ | 37,186 |  |  | $ | 37,190 |  |

[0001783180-26-000023:8k_2_02:85]
11

[0001783180-26-000023:8k_2_02:86]
Carrier Global Corporation

[0001783180-26-000023:8k_2_02:87]
Condensed Consolidated Statement of Cash Flows

[0001783180-26-000023:8k_2_02:88]
(Unaudited)

[0001783180-26-000023:8k_2_02:89]
|  |  |  |  | Three Months EndedMarch 31, |
| (In millions) |  |  |  |  |  | 2026 |  | 2025 |
| Operating Activities |  |  |  |  |  |  |  |  |
| Net earnings (loss) |  |  |  |  |  | $ | 265 |  |  | $ | 437 |  |
| Discontinued operations, net of tax |  |  |  |  |  | 1 |  |  | — |  |
| Adjustments for non-cash items, net: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  |  |  |  | 315 |  |  | 303 |  |
| Deferred income tax provision |  |  |  |  |  | (179) |  |  | (69) |  |
| Stock-based compensation costs |  |  |  |  |  | 21 |  |  | 23 |  |
| Equity method investment net earnings |  |  |  |  |  | (31) |  |  | (44) |  |
| (Gain) loss on sale of investments |  |  |  |  |  | (3) |  |  | (5) |  |
| Changes in operating assets and liabilities |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  |  |  |  |  | (509) |  |  | (362) |  |
| Inventories, net |  |  |  |  |  | (138) |  |  | (301) |  |
| Accounts payable and accrued liabilities |  |  |  |  |  | 351 |  |  | 481 |  |
| Distributions from equity method investments |  |  |  |  |  | 12 |  |  | 77 |  |
| Other operating activities, net |  |  |  |  |  | (39) |  |  | (52) |  |
| Net cash flows provided by (used in) continuing operating activities |  |  |  |  |  | 66 |  |  | 488 |  |
| Net cash flows provided by (used in) discontinued operating activities |  |  |  |  |  | 13 |  |  | (5) |  |
| Net cash flows provided by (used in) operating activities |  |  |  |  |  | 79 |  |  | 483 |  |
| Investing Activities |  |  |  |  |  |  |  |  |
| Capital expenditures |  |  |  |  |  | (94) |  |  | (63) |  |
| Investment in businesses, net of cash acquired |  |  |  |  |  | (23) |  |  | (12) |  |
| Dispositions of businesses |  |  |  |  |  | 8 |  |  | 8 |  |
| Settlement of derivative contracts, net |  |  |  |  |  | 35 |  |  | 36 |  |
| Other investing activities, net |  |  |  |  |  | 9 |  |  | 1 |  |
| Net cash flows provided by (used in) continuing investing activities |  |  |  |  |  | (65) |  |  | (30) |  |
| Net cash flows provided by (used in) discontinued investing activities |  |  |  |  |  | — |  |  | 7 |  |
| Net cash flows provided by (used in) investing activities |  |  |  |  |  | (65) |  |  | (23) |  |
| Financing Activities |  |  |  |  |  |  |  |  |
| Increase (decrease) in short-term borrowings, net |  |  |  |  |  | 371 |  |  | (49) |  |
| Issuance of long-term debt |  |  |  |  |  | 22 |  |  | 9 |  |
| Repayment of long-term debt |  |  |  |  |  | (16) |  |  | (1,205) |  |
| Repurchases of common stock |  |  |  |  |  | (306) |  |  | (1,288) |  |
| Dividends paid on common stock |  |  |  |  |  | (201) |  |  | (198) |  |
| Dividends paid to non-controlling interest |  |  |  |  |  | (1) |  |  | — |  |
| Other financing activities, net |  |  |  |  |  | (10) |  |  | (16) |  |
| Net cash flows provided by (used in) continuing financing activities |  |  |  |  |  | (141) |  |  | (2,747) |  |
| Net cash flows provided by (used in) discontinued financing activities |  |  |  |  |  | — |  |  | — |  |
| Net cash flows provided by (used in) financing activities |  |  |  |  |  | (141) |  |  | (2,747) |  |
| Effect of foreign exchange rate changes on cash and cash equivalents |  |  |  |  |  | (13) |  |  | 17 |  |
| Net increase (decrease) in cash and cash equivalents and restricted cash, including cash classified in current assets held for sale |  |  |  |  |  | (140) |  |  | (2,270) |  |
| Less: Change in cash balances classified as assets held for sale |  |  |  |  |  | 43 |  |  | — |  |
| Net increase (decrease) in cash and cash equivalents and restricted cash |  |  |  |  |  | (183) |  |  | (2,270) |  |
| Cash, cash equivalents and restricted cash, beginning of period |  |  |  |  |  | 1,557 |  |  | 3,972 |  |
| Cash, cash equivalents and restricted cash, end of period |  |  |  |  |  | 1,374 |  |  | 1,702 |  |
| Less: restricted cash |  |  |  |  |  | 3 |  |  | 4 |  |
| Cash and cash equivalents, end of period |  |  |  |  |  | $ | 1,371 |  |  | $ | 1,698 |  |

[0001783180-26-000023:8k_2_02:90]
12

[0001783180-26-000023:8k_2_02:91]
Carrier Global Corporation

[0001783180-26-000023:8k_2_02:92]
Segment Summary

[0001783180-26-000023:8k_2_02:93]
|  | (Unaudited) |  |
|  | Three Months Ended March 31, |  |  |  |
| (In millions) | 2026 |  | 2025 |  |  |  |  |  |
| Segment net sales |  |  |  |  |  |  |  |  |  |
| Climate Solutions Americas |  | $ | 2,501 |  | $ | 2,572 |  |  |  |  |  |
| Climate Solutions Europe |  | 1,293 |  | 1,169 |  |  |  |  |  |
| Climate Solutions Asia Pacific, Middle East & Africa |  | 834 |  | 826 |  |  |  |  |  |
| Climate Solutions Transportation |  | 713 |  | 651 |  |  |  |  |  |
| Segment net sales |  | $ | 5,341 |  | $ | 5,218 |  |  |  |  |  |
| Segment operating profit |  |  |  |  |  |  |  |  |  |
| Climate Solutions Americas |  | $ | 373 |  | $ | 570 |  |  |  |  |  |
| Climate Solutions Europe |  | 89 |  | 105 |  |  |  |  |  |
| Climate Solutions Asia Pacific, Middle East & Africa |  | 81 |  | 121 |  |  |  |  |  |
| Climate Solutions Transportation |  | 101 |  | 97 |  |  |  |  |  |
| Segment operating profit |  | $ | 644 |  | $ | 893 |  |  |  |  |  |
| Segment operating margin |  |  |  |  |  |  |  |  |  |
| Climate Solutions Americas |  | 14.9 | % |  | 22.2 | % |  |  |  |  |  |
| Climate Solutions Europe |  | 6.9 | % |  | 9.0 | % |  |  |  |  |  |
| Climate Solutions Asia Pacific, Middle East & Africa |  | 9.7 | % |  | 14.6 | % |  |  |  |  |  |
| Climate Solutions Transportation |  | 14.2 | % |  | 14.9 | % |  |  |  |  |  |

[0001783180-26-000023:8k_2_02:94]
13

[0001783180-26-000023:8k_2_02:95]
Components of Changes in Net Sales

[0001783180-26-000023:8k_2_02:96]
| Three Months Ended March 31, 2026 Compared with Three Months Ended March 31, 2025 |
|  | (Unaudited) |
|  | Factors Contributing to Total % change in Net Sales |
|  | Organic |  | FX Translation |  | Acquisitions / Divestitures, net |  | Other |  | Total |
| Climate Solutions Americas | (3) | % |  | — | % |  | — | % |  | — | % |  | (3) | % |
| Climate Solutions Europe | — | % |  | 11 | % |  | — | % |  | — | % |  | 11 | % |
| Climate Solutions Asia Pacific, Middle East & Africa | (1) | % |  | 2 | % |  | — | % |  | — | % |  | 1 | % |
| Climate Solutions Transportation | 5 | % |  | 5 | % |  | — | % |  | — | % |  | 10 | % |
| Consolidated | (1) | % |  | 3 | % |  | — | % |  | — | % |  | 2 | % |

[0001783180-26-000023:8k_2_02:97]
14

[0001783180-26-000023:8k_2_02:98]
Carrier Global Corporation

[0001783180-26-000023:8k_2_02:99]
Reconciliations

[0001783180-26-000023:8k_2_02:100]
|  |  | (Unaudited) |
|  |  | Three Months Ended March 31, |  |  |
| (In millions) |  | 2026 |  | 2025 |  |  |  |  |
| Reconciliation to Earnings before income taxes |  |  |  |  |  |  |  |  |
| Segment operating profit |  | $ | 644 |  |  | $ | 893 |  |  |  |  |  |
| Corporate and other |  | (50) |  |  | (45) |  |  |  |  |  |
| Restructuring costs |  | (108) |  |  | (8) |  |  |  |  |  |
| Amortization of acquired intangible assets |  | (213) |  |  | (201) |  |  |  |  |  |
| Acquisition/divestiture-related costs |  | (14) |  |  | (10) |  |  |  |  |  |
| Non-service pension (expense) benefit |  | 1 |  |  | 1 |  |  |  |  |  |
| Interest (expense) income, net |  | (90) |  |  | (82) |  |  |  |  |  |
| Earnings before income taxes |  | $ | 170 |  |  | $ | 548 |  |  |  |  |  |

[0001783180-26-000023:8k_2_02:101]
|  |  | (Unaudited) |
|  |  | Three Months Ended March 31, |  |  |
| (In millions) |  | 2026 |  | 2025 |  |  |  |  |
| Reconciliation of Segment operating profit to Adjusted operating profit |  |  |  |  |  |  |  |  |
| Climate Solutions Americas |  | $ | 373 |  |  | $ | 570 |  |  |  |  |  |
| Climate Solutions Europe |  | 89 |  |  | 105 |  |  |  |  |  |
| Climate Solutions Asia Pacific, Middle East & Africa |  | 81 |  |  | 121 |  |  |  |  |  |
| Climate Solutions Transportation |  | 101 |  |  | 97 |  |  |  |  |  |
| Segment operating profit |  | $ | 644 |  |  | $ | 893 |  |  |  |  |  |
| Corporate and other |  | (50) |  |  | (45) |  |  |  |  |  |
| Adjusted operating profit |  | $ | 594 |  |  | $ | 848 |  |  |  |  |  |

[0001783180-26-000023:8k_2_02:102]
Carrier Global Corporation

[0001783180-26-000023:8k_2_02:103]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP) Results

[0001783180-26-000023:8k_2_02:104]
Net Income, Earnings Per Share and Effective Tax Rate

[0001783180-26-000023:8k_2_02:105]
|  | (Unaudited) |
|  | Three Months Ended March 31, 2026 |  |  |
| (In millions, except per share amounts) | Reported |  | Adjustments |  | Adjusted |  |  |  |  |  |  |
| Net sales | $ | 5,341 |  |  | $ | — |  |  | $ | 5,341 |  |  |  |  |  |  |  |
| Operating profit | $ | 259 |  |  | 335 |  | a | $ | 594 |  |  |  |  |  |  |  |
| Operating margin | 4.8 | % |  |  |  | 11.1 | % |  |  |  |  |  |  |
| Earnings before income taxes | $ | 170 |  |  | 335 |  | a | $ | 505 |  |  |  |  |  |  |  |
| Income tax (expense) benefit | $ | 96 |  |  | (92) |  | b | $ | 4 |  |  |  |  |  |  |  |
| Effective tax rate | (56.5) | % |  |  |  | (0.8) | % |  |  |  |  |  |  |
| Earnings from continuing operations attributable to common shareowners | $ | 239 |  |  | $ | 243 |  |  | $ | 482 |  |  |  |  |  |  |  |
| Summary of Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring costs |  |  | $ | 108 |  | a |  |  |  |  |  |  |  |
| Amortization of acquired intangible assets |  |  | 213 |  | a |  |  |  |  |  |  |  |
| Acquisition/divestiture-related costs |  |  | 14 |  | a |  |  |  |  |  |  |  |
| Total adjustments |  |  | $ | 335 |  |  |  |  |  |  |  |  |  |
| Tax effect on adjustments above |  |  | $ | (92) |  |  |  |  |  |  |  |  |  |
| Total tax adjustments |  |  | $ | (92) |  | b |  |  |  |  |  |  |  |
| Diluted shares outstanding | 842.8 |  |  |  |  | 842.8 |  |  |  |  |  |  |  |
| Diluted earnings per share: |  |  |  |  |  |  |  |  |  |  |  |
| Continuing operations | $ | 0.28 |  |  |  |  | $ | 0.57 |  |  |  |  |  |  |  |

[0001783180-26-000023:8k_2_02:106]
16

[0001783180-26-000023:8k_2_02:107]
Carrier Global Corporation

[0001783180-26-000023:8k_2_02:108]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP) Results

[0001783180-26-000023:8k_2_02:109]
Net Income, Earnings Per Share and Effective Tax Rate

[0001783180-26-000023:8k_2_02:110]
|  | (Unaudited) |
|  | Three Months Ended March 31, 2025 |  |  |
| (In millions, except per share amounts) | Reported |  | Adjustments |  | Adjusted |  |  |  |  |  |  |
| Net sales | $ | 5,218 |  |  | $ | — |  |  | $ | 5,218 |  |  |  |  |  |  |  |
| Operating profit | $ | 629 |  |  | 219 |  | a | $ | 848 |  |  |  |  |  |  |  |
| Operating margin | 12.1 | % |  |  |  | 16.3 | % |  |  |  |  |  |  |
| Earnings before income taxes | $ | 548 |  |  | 219 |  | a | $ | 767 |  |  |  |  |  |  |  |
| Income tax (expense) benefit | $ | (111) |  |  | (58) |  | b | $ | (169) |  |  |  |  |  |  |  |
| Effective tax rate | 20.3 | % |  |  |  | 22.0 | % |  |  |  |  |  |  |
| Earnings from continuing operations attributable to common shareowners | $ | 412 |  |  | $ | 161 |  |  | $ | 573 |  |  |  |  |  |  |  |
| Summary of Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring costs |  |  | $ | 8 |  | a |  |  |  |  |  |  |  |
| Amortization of acquired intangible assets |  |  | 201 |  | a |  |  |  |  |  |  |  |
| Acquisition/divestiture-related costs |  |  | 10 |  | a |  |  |  |  |  |  |  |
| Total adjustments |  |  | $ | 219 |  |  |  |  |  |  |  |  |  |
| Tax effect on adjustments above |  |  | $ | (58) |  |  |  |  |  |  |  |  |  |
| Total tax adjustments |  |  | $ | (58) |  | b |  |  |  |  |  |  |  |
| Diluted shares outstanding | 878.3 |  |  |  |  | 878.3 |  |  |  |  |  |  |  |
| Diluted earnings per share: |  |  |  |  |  |  |  |  |  |  |  |
| Continuing operations | $ | 0.47 |  |  |  |  | $ | 0.65 |  |  |  |  |  |  |  |

[0001783180-26-000023:8k_2_02:111]
17

[0001783180-26-000023:8k_2_02:112]
Free Cash Flow Reconciliation

[0001783180-26-000023:8k_2_02:113]
|  |  | (Unaudited) |
|  |  | Three Months Ended March 31, |  |  |
| (In millions) |  | 2026 |  | 2025 |  |  |  |  |
| Net cash flows provided by operating activities |  | $ | 79 |  |  | $ | 483 |  |  |  |  |  |
| Less: Capital expenditures |  | (94) |  |  | (63) |  |  |  |  |  |
| Free cash flow |  | $ | (15) |  |  | $ | 420 |  |  |  |  |  |

[0001783180-26-000023:8k_2_02:114]
Net Debt Reconciliation

[0001783180-26-000023:8k_2_02:115]
|  |  | (Unaudited) |
| (In millions) |  | March 31, 2026 |  | December 31, 2025 |
| Long-term debt |  | $ | 10,422 |  |  | $ | 11,365 |  |
| Short-term borrowings and current portion of long-term debt |  | 1,736 |  |  | 468 |  |
| Less: Cash and cash equivalents |  | 1,371 |  |  | 1,555 |  |
| Net debt |  | $ | 10,787 |  |  | $ | 10,278 |  |

[0001783180-26-000023:8k_2_02:116]
18
