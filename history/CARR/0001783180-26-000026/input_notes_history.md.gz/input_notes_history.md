# CARR note change history — 0001783180-25-000066 → 0001783180-26-000026


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2026-04-30):
[0001783180-26-000026:note_history:1]
| (In millions) |  | March 31,2026 |  | December 31,2025 |
| Environmental reserves included in Accrued liabilities |  | $ | 17 |  |  | $ | 18 |  |
| Environmental reserves included in Other long-term liabilities |  | 181 |  |  | 182 |  |
| Total Environmental reserves |  | $ | 198 |  |  | $ | 200 |  |
  (was, 2025-10-28, similarity 0.974):
[0001783180-25-000066:note_history:1]
| (In millions) |  | September 30,2025 |  | December 31,2024 |
| Environmental reserves included in Accrued liabilities |  | $ | 13 |  |  | $ | 25 |  |
| Environmental reserves included in Other long-term liabilities |  | 187 |  |  | 185 |  |
| Total Environmental reserves |  | $ | 200 |  |  | $ | 210 |  |

- changed (2026-04-30):
[0001783180-26-000026:note_history:2]
| (In millions) |  | March 31,2026 |  | December 31,2025 |
| Asbestos liabilities included in Accrued liabilities |  | $ | 17 |  |  | $ | 17 |  |
| Asbestos liabilities included in Other long-term liabilities |  | 195 |  |  | 201 |  |
| Total Asbestos liabilities |  | $ | 212 |  |  | $ | 218 |  |
| Asbestos-related recoveries included in Other current assets |  | $ | 6 |  |  | $ | 6 |  |
| Asbestos-related recoveries included in Other assets |  | 85 |  |  | 86 |  |
| Total Asbestos-related recoveries |  | $ | 91 |  |  | $ | 92 |  |
  (was, 2025-10-28, similarity 0.9877):
[0001783180-25-000066:note_history:2]
| (In millions) |  | September 30,2025 |  | December 31,2024 |
| Asbestos liabilities included in Accrued liabilities |  | $ | 17 |  |  | $ | 17 |  |
| Asbestos liabilities included in Other long-term liabilities |  | 201 |  |  | 208 |  |
| Total Asbestos liabilities |  | $ | 218 |  |  | $ | 225 |  |
| Asbestos-related recoveries included in Other current assets |  | $ | 6 |  |  | $ | 7 |  |
| Asbestos-related recoveries included in Other assets |  | 86 |  |  | 88 |  |
| Total Asbestos-related recoveries |  | $ | 92 |  |  | $ | 95 |  |

- changed (2026-04-30):
[0001783180-26-000026:note_history:3]
As of March 31, 2026, the Company, Kidde-Fenwal, Inc. ("KFI") and others have been named as defendants in more than 17,000 lawsuits filed in United States state or federal courts and a single case in Canada alleging that the historic use of Aqueous Film Forming Foam ("AFFF") caused personal injuries and damage to property and water supplies. In December 2018, the U.S. Judicial Panel on Multidistrict Litigation transferred and consolidated all AFFF cases pending in the U.S. federal courts against the Company, KFI and others to the U.S. District Court for the District of South Carolina (the "MDL Proceedings"). In 2013, KFI divested the AFFF businesses to an unrelated third party. The Company acquired KFI as part of the Separation in April 2020.
  (was, 2025-10-28, similarity 0.6983):
[0001783180-25-000066:note_history:3]
As of September 30, 2025, the Company, Kidde-Fenwal, Inc. ("KFI") and others have been named as defendants in more than 13,000 lawsuits filed in United States state or federal courts and a single case in Canada alleging that the historic use of Aqueous Film Forming Foam ("AFFF") caused personal injuries and damage to property and water supplies. In December 2018, the U.S. Judicial Panel on Multidistrict Litigation transferred and consolidated all AFFF cases pending in the U.S. federal courts against the Company, KFI and others to the U.S. District Court for the District of South Carolina (the "MDL Proceedings"). Individual plaintiffs in the MDL Proceedings generally seek damages for alleged personal injuries, medical monitoring, diminution in property value and injunctive relief to remediate alleged contamination of water supplies. U.S. state, municipal and water utility plaintiffs in the MDL Proceedings generally seek damages and costs related to the remediation of public property and water supplies.

- changed (2026-04-30):
[0001783180-26-000026:note_history:4]
As part of the Proposed Settlement Agreements, the Company will pay $615 million in cash over five years, 100% of the net sale proceeds from its sale of KFI’s assets to Pacific Avenue Capital Partners, which are estimated to be $115 million, and contribute the right to recover proceeds under certain of its insurance policies. The Company will be entitled to receive up to $2.4 billion of proceeds from those insurance policies and will contribute the first $125 million of such proceeds as additional consideration in the Direct Claims Settlements. The Company also will be entitled to any earnouts payable to KFI under the KFI sale agreement. The Company expects insurance payments it receives in the future, in the aggregate, to cover the amount paid under the Proposed Settlement Agreements. As a result of the Proposed Settlement Agreements, the Company recorded a liability in the amount of $565 million during 2024. The amount recognized is in addition to liabilities of $50 million that the Company recorded upon the deconsolidation of KFI on May 14, 2023, as further discussed below. As of March 31, 2026, the Company has not recorded any amounts associated with expected insurance proceeds.
  (was, 2025-10-28, similarity 0.9794):
[0001783180-25-000066:note_history:4]
As part of the Proposed Settlement Agreements, the Company will pay $615 million in cash over five years, 100% of the net sale proceeds from its sale of KFI’s assets to Pacific Avenue Capital Partners, which are estimated to be $115 million, and contribute the right to recover proceeds under certain of its insurance policies. The Company will be entitled to receive up to $2.4 billion of proceeds from those insurance policies and will contribute the first $125 million of such proceeds as additional consideration in the Direct Claims Settlements. The Company also will be entitled to any earnouts payable to KFI under the KFI sale agreement. The Company expects insurance payments it receives in the future, in the aggregate, to cover the amount paid under the Proposed Settlement Agreements. As a result of the Proposed Settlement Agreements, the Company recorded a liability in the amount of $565 million during the three months ended September 30, 2024. The amount recognized is in addition to liabilities of $50 million that the Company recorded upon the deconsolidation of KFI on May 14, 2023, as further discussed below. As of September 30, 2025, the Company has not recorded any amounts associated with expected insurance proceeds.

- added (2026-04-30):
[0001783180-26-000026:note_history:5]
Antitrust Litigation

- added (2026-04-30):
[0001783180-26-000026:note_history:6]
Beginning in March 2026, the Company, along with several other HVAC manufacturers, has been named as a defendant in putative class-action lawsuits alleging violations of federal and state antitrust laws on behalf of direct and indirect purchasers of HVAC equipment. These lawsuits are currently pending in the United States District Court for the Eastern District of Michigan and generally allege that the Company and other industry participants have engaged in an unlawful agreement to fix or raise the prices of certain HVAC products in the United States since January 1, 2020. The lawsuits seek damages, including treble damages under federal and state antitrust statutes, as well as injunctive relief and attorneys’ fees. The Company believes the allegations in these lawsuits lack merit and that it has meritorious defenses to the alleged claims. At this time, the Company is unable to assess the probability of liability or to reasonably estimate a range of possible loss. There can be no assurance that any future exposure will not be material in any period.

- changed (2026-04-30):
[0001783180-26-000026:note_history:7]
Under the TMA relating to the Separation, the Company is responsible to UTC for its share of the Tax Cuts and Jobs Act transition tax associated with foreign undistributed earnings as of December 31, 2017. As a result, a liability of $101 million is included within the accompanying Unaudited Condensed Consolidated Balance Sheet within Accrued liabilities as of March 31, 2026. This obligation was settled in April 2026.
  (was, 2025-10-28, similarity 0.8476):
[0001783180-25-000066:note_history:7]
Under the TMA relating to the Separation, the Company is responsible to UTC for its share of the Tax Cuts and Jobs Act transition tax associated with foreign undistributed earnings as of December 31, 2017. As a result, a liability of $101 million is included within the accompanying Unaudited Condensed Consolidated Balance Sheet within Accrued liabilities as of September 30, 2025. This obligation is expected to be settled in April 2026. The Company believes that the likelihood of incurring losses materially in excess of this amount is remote.

- removed (2026-04-30):
[0001783180-25-000066:note_history:8]
AFFF is a firefighting foam, developed beginning in the late 1960s pursuant to U.S. military specification, used to extinguish certain types of hydrocarbon-fueled fires. The lawsuits identified above relate to Kidde Fire Fighting, Inc., which owned the “National Foam” business that manufactured AFFF for sale to government (including the U.S. federal government) and non-government customers in the U.S. at a single facility located in West Chester, Pennsylvania (the "Pennsylvania Site"). Kidde Fire Fighting, Inc. was acquired by a UTC subsidiary in 2005 and merged into KFI in 2007. In 2013, KFI divested the AFFF businesses to an unrelated third party. The Company acquired KFI as part of the Separation in April 2020.

- removed (2026-04-30):
[0001783180-25-000066:note_history:9]
The key components that contribute to AFFF's fire-extinguishing capabilities are known as fluorosurfactants. Neither the Company, nor KFI, nor any of the Company's subsidiaries involved in the AFFF litigation manufactured fluorosurfactants. Instead, the National Foam business purchased these substances from unrelated third parties for use in manufacturing AFFF. Plaintiffs in the MDL Proceedings allege that the fluorosurfactants used by various manufacturers in producing AFFF contained, or over time degraded into, compounds known as per- and polyfluoroalkyl substances (referred to collectively as "PFAS"), including perflourooctanesulfonic acid ("PFOS") and perflourooctanoic acid ("PFOA"). Plaintiffs further allege that, as a result of the use of AFFF, PFOS and PFOA were released into the environment and, in some instances, ultimately reached drinking water supplies.

- removed (2026-04-30):
[0001783180-25-000066:note_history:10]
Plaintiffs in the MDL Proceedings have named multiple defendants, including suppliers of chemicals and raw materials used to manufacture fluorosurfactants, fluorosurfactant manufacturers and AFFF manufacturers. The defendants in the MDL Proceedings moved for summary judgment on the government contractor defense, which potentially applies to AFFF sold to or used by the U.S. government. After full briefing and oral argument, on September 16, 2022, the MDL court declined to enter summary judgment for the defendants. The defense, however, remains available at any trial in which it would apply.

- removed (2026-04-30):
[0001783180-25-000066:note_history:11]
Deconsolidation Due to Bankruptcy

- removed (2026-04-30):
[0001783180-25-000066:note_history:12]
As of May 14, 2023, the Company no longer controlled KFI as its activities are subject to review and oversight by the Bankruptcy Court. Therefore, KFI was deconsolidated and its respective assets and liabilities were derecognized from the Company’s Unaudited Condensed Consolidated Financial Statements. Upon deconsolidation, the Company determined the fair value of its retained interest in KFI to be zero and we accounted for it prospectively using the cost method.

- removed (2026-04-30):
[0001783180-25-000066:note_history:13]
In connection with the bankruptcy filing, KFI entered into several agreements with subsidiaries of the Company to ensure they have access to services necessary for the effective operation of their business. All post-deconsolidation activity between the Company and KFI are reported as third-party transactions recorded within the Company's Unaudited Condensed Consolidated Statement of Operations. Since the petition date, there were no material transactions between the Company and KFI other than a $15 million payment during 2024 by the Company to KFI under the terms of a tax sharing arrangement.


## us-gaap:ScheduleOfEnvironmentalLossContingenciesBySiteTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2026-04-30):
[0001783180-26-000026:note_history:14]
| (In millions) |  | March 31,2026 |  | December 31,2025 |
| Environmental reserves included in Accrued liabilities |  | $ | 17 |  |  | $ | 18 |  |
| Environmental reserves included in Other long-term liabilities |  | 181 |  |  | 182 |  |
| Total Environmental reserves |  | $ | 198 |  |  | $ | 200 |  |
  (was, 2025-10-28, similarity 0.974):
[0001783180-25-000066:note_history:14]
| (In millions) |  | September 30,2025 |  | December 31,2024 |
| Environmental reserves included in Accrued liabilities |  | $ | 13 |  |  | $ | 25 |  |
| Environmental reserves included in Other long-term liabilities |  | 187 |  |  | 185 |  |
| Total Environmental reserves |  | $ | 200 |  |  | $ | 210 |  |


## us-gaap:ScheduleOfLossContingenciesByContingencyTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2026-04-30):
[0001783180-26-000026:note_history:15]
| (In millions) |  | March 31,2026 |  | December 31,2025 |
| Asbestos liabilities included in Accrued liabilities |  | $ | 17 |  |  | $ | 17 |  |
| Asbestos liabilities included in Other long-term liabilities |  | 195 |  |  | 201 |  |
| Total Asbestos liabilities |  | $ | 212 |  |  | $ | 218 |  |
| Asbestos-related recoveries included in Other current assets |  | $ | 6 |  |  | $ | 6 |  |
| Asbestos-related recoveries included in Other assets |  | 85 |  |  | 86 |  |
| Total Asbestos-related recoveries |  | $ | 91 |  |  | $ | 92 |  |
  (was, 2025-10-28, similarity 0.9877):
[0001783180-25-000066:note_history:15]
| (In millions) |  | September 30,2025 |  | December 31,2024 |
| Asbestos liabilities included in Accrued liabilities |  | $ | 17 |  |  | $ | 17 |  |
| Asbestos liabilities included in Other long-term liabilities |  | 201 |  |  | 208 |  |
| Total Asbestos liabilities |  | $ | 218 |  |  | $ | 225 |  |
| Asbestos-related recoveries included in Other current assets |  | $ | 6 |  |  | $ | 7 |  |
| Asbestos-related recoveries included in Other assets |  | 86 |  |  | 88 |  |
| Total Asbestos-related recoveries |  | $ | 92 |  |  | $ | 95 |  |


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2026-04-30):
[0001783180-26-000026:note_history:16]
Sale of Riello Business

- added (2026-04-30):
[0001783180-26-000026:note_history:17]
On December 16, 2025, the Company entered into a stock purchase agreement to sell its Riello business ("Riello") to Ariston Group with expected gross proceeds of approximately $430 million. Riello, predominantly reported in the Company's Climate Solutions Europe segment, is a leading international manufacturer that designs, produces and integrates a comprehensive portfolio of thermal solutions including burners, boilers, heat pumps, cooling systems and aftermarket services for residential, commercial and industrial applications, with a strong focus on energy efficiency, innovation and a global distribution network. As a result, the assets and liabilities of Riello are presented as held for sale in the accompanying Unaudited Condensed Consolidated Balance Sheet as of March 31, 2026 and December 31, 2025, and recorded at the lower of their carrying value or fair value less estimated cost to sell. See Note 15 - Divestitures for additional information.

- changed (2026-04-30):
[0001783180-26-000026:note_history:18]
On April 3, 2020 (the "Distribution Date"), United Technologies Corporation ("UTC"), since renamed RTX Corporation ("Raytheon Technologies Corporation" or "RTX"), completed the spin-off of Carrier into an independent, publicly traded company (the "Separation") through a pro-rata distribution (the "Distribution") on a one-for-one basis of all of the outstanding shares of common stock of Carrier to UTC shareowners who held shares of UTC common stock as of the close of business on March 19, 2020, the record date of the Distribution. In addition, the Company entered into several agreements with UTC and Otis Worldwide Corporation ("Otis") that govern various aspects of the relationship among the Company, UTC and Otis. As of March 31, 2026, only certain portions of the Tax Matters Agreement ("TMA") remain in effect.
  (was, 2025-10-28, similarity 0.9913):
[0001783180-25-000066:note_history:18]
On April 3, 2020 (the "Distribution Date"), United Technologies Corporation ("UTC"), since renamed RTX Corporation ("Raytheon Technologies Corporation" or "RTX"), completed the spin-off of Carrier into an independent, publicly traded company (the "Separation") through a pro-rata distribution (the "Distribution") on a one-for-one basis of all of the outstanding shares of common stock of Carrier to UTC shareowners who held shares of UTC common stock as of the close of business on March 19, 2020, the record date of the Distribution. In addition, the Company entered into several agreements with UTC and Otis Worldwide Corporation ("Otis") that govern various aspects of the relationship among the Company, UTC and Otis. As of September 30, 2025, only certain portions of the Tax Matters Agreement ("TMA") remain in effect.

- removed (2026-04-30):
[0001783180-25-000066:note_history:19]
Portfolio Transformation

- removed (2026-04-30):
[0001783180-25-000066:note_history:20]
During 2024, the Company completed several activities designed to simplify its business portfolio, transforming it into a pure-play climate and energy solutions provider. On January 2, 2024, the Company acquired the climate solutions business (the "VCS Business") of Viessmann Group GmbH & Co. KG (together with its affiliates, “Viessmann”). The VCS Business, primarily reported in the Climate Solutions Europe segment, is a premier residential and light commercial HVAC provider in Europe that expanded the Company's portfolio to offer a global, comprehensive suite of sustainable and innovative building and cold-chain solutions. In addition, the Company divested its Commercial and Residential Fire, Access Solutions and Industrial Fire businesses which were historically reported in its Fire & Security segment. The transactions represented a single disposal plan to separately divest multiple businesses over different reporting periods and met the criteria to be presented as discontinued operations in the accompanying financial statements. The Company also divested its Commercial Refrigeration business (“CCR”) during 2024. CCR, which was historically reported in the Climate Solutions Transportation segment (previously named Refrigeration), did not meet the criteria to be presented as discontinued operations.

- removed (2026-04-30):
[0001783180-25-000066:note_history:21]
Segment Reorganization

- removed (2026-04-30):
[0001783180-25-000066:note_history:22]
As a result of the Company's portfolio transformation, the Company revised its reportable segments during the first quarter of 2025 to better reflect its business strategy, align its management reporting and increase transparency for investors. Under the revised segment structure, the Company has three new regional HVAC operating segments. Combined with the Climate Solutions Transportation operating segment, the four operating segments also serve as the Company's reportable segments. This model is designed to create a simplified, more focused and customer-centric organization across the globe. Each segment reports through separate management teams which regularly review their operating results with the Company's Chief Operating Decision Maker (the "CODM") determined in accordance with applicable accounting guidance. In connection with the revised structure, the CODM changed the measure used to evaluate segment profitability from Operating profit to Segment operating profit. All prior period comparative information has been recast to reflect the revised segment structure. See Note 17 – Segment Financial Data for additional information.

- removed (2026-04-30):
[0001783180-25-000066:note_history:23]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures ("ASU 2023-09"), which requires public entities to disclose disaggregated information about their effective tax rate reconciliation as well as information on income taxes paid. ASU 2023-09 is effective for annual periods beginning after December 15, 2024, with early adoption permitted. The ASU requires additional disclosures and is not expected to have a material impact on the Company's financial statements.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2026-04-30):
[0001783180-26-000026:note_history:24]
DESCRIPTION OF THE BUSINESS
Carrier Global Corporation (the "Company") is a global leader in intelligent climate and energy solutions with a focus on providing differentiated, digitally-enabled lifecycle solutions to its customers. The Company's portfolio includes industry-leading brands such as Carrier, Viessmann, Toshiba, Automated Logic and Carrier Transicold that offer innovative heating, cooling and cold chain solutions to enhance the lives we live and the world we share. The Company also provides a broad array of related building services, including audit, design, installation, system integration, repair, maintenance and monitoring. The Company's operations are classified into four segments: Climate Solutions Americas, Climate Solutions Europe, Climate Solutions Asia Pacific, Middle East & Africa and Climate Solutions Transportation.
In the opinion of management, the accompanying Unaudited Condensed Consolidated Financial Statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission (the "SEC"). The accompanying Unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for 2025 filed with the SEC on February 5, 2026 (the "2025 Form 10-K").
  (was, 2025-10-28, similarity 0.6416):
[0001783180-25-000066:note_history:24]
In the opinion of management, the accompanying Unaudited Condensed Consolidated Financial Statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission (the "SEC"). The accompanying Unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for 2024 filed with the SEC on February 11, 2025 (the "2024 Form 10-K"). Certain prior period amounts have been reclassified to conform to the current period financial statement presentation.

- removed (2026-04-30):
[0001783180-25-000066:note_history:25]
DESCRIPTION OF THE BUSINESS
Carrier Global Corporation (the "Company") is a global leader in intelligent climate and energy solutions with a focus on providing differentiated, digitally-enabled lifecycle solutions to its customers. The Company's portfolio includes industry-leading brands such as Carrier, Viessmann, Toshiba, Automated Logic and Carrier Transicold that offer innovative heating, ventilating, air conditioning ("HVAC") and cold chain transportation solutions to enhance the lives we live and the world we share. The Company also provides a broad array of related building services, including audit, design, installation, system integration, repair, maintenance and monitoring. The Company's operations are classified into four segments: Climate Solutions Americas, Climate Solutions Europe, Climate Solutions Asia Pacific, Middle East & Africa and Climate Solutions Transportation.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2026-04-30):
[0001783180-26-000026:note_history:26]
| (In millions) |  |  |  | March 31,2026 |  | December 31,2025 |
| Commercial paper |  |  |  | $ | 708 |  |  | $ | 325 |  |
| Short-term borrowings |  |  |  | 23 |  |  | 35 |  |
| Current portion of long-term debt |  |  |  | 1,005 |  |  | 108 |  |
| Short-term borrowings and current portion of long-term debt |  |  |  | $ | 1,736 |  |  | $ | 468 |  |

- changed (2026-04-30):
[0001783180-26-000026:note_history:27]
The Company has a $2.0 billion USD-denominated facility and a $500 million Euro-denominated facility as part of an unsecured, unsubordinated commercial paper program, which can be used for general corporate purposes including the funding of working capital and potential acquisitions. At March 31, 2026, the Company had $708 million outstanding under its  commercial paper facilities with a weighted average interest rate of 4.06%.
  (was, 2025-10-28, similarity 0.8905):
[0001783180-25-000066:note_history:27]
The Company has a $2.0 billion USD-denominated facility and a $500 million Euro-denominated facility as part of an unsecured, unsubordinated commercial paper program, which can be used for general corporate purposes including the funding of working capital and potential acquisitions. At September 30, 2025, the Company had $415 million outstanding under its USD-denominated commercial paper facility, with a weighted average rate of 4.28%.

- changed (2026-04-30):
[0001783180-26-000026:note_history:28]
| (In millions) |  |  |  | March 31,2026 |  | December 31,2025 |
| 2.493% Notes due 2027 (1) |  |  |  | 900 |  |  | 900 |  |
| 4.125% Notes due 2028 |  |  |  | 865 |  |  | 883 |  |
| 2.722% Notes due 2030 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.700% Notes due 2031 |  |  |  | 750 |  |  | 750 |  |
| 4.500% Notes due 2032 |  |  |  | 980 |  |  | 1,001 |  |
| 5.900% Notes due 2034 |  |  |  | 875 |  |  | 875 |  |
| 3.625% Notes due 2037 |  |  |  | 865 |  |  | 883 |  |
| 3.377% Notes due 2040 |  |  |  | 1,500 |  |  | 1,500 |  |
| 3.577% Notes due 2050 |  |  |  | 1,400 |  |  | 1,400 |  |
| 6.200% Notes due 2054 |  |  |  | 650 |  |  | 650 |  |
| Total long-term notes |  |  |  | 10,785 |  |  | 10,842 |  |
| Japanese Term Loan Facility |  |  |  | 338 |  |  | 345 |  |
| Other debt (including project financing obligations and finance leases) |  |  |  | 380 |  |  | 364 |  |
| Discounts and debt issuance costs |  |  |  | (76) |  |  | (78) |  |
| Total long-term debt |  |  |  | 11,427 |  |  | 11,473 |  |
| Less: current portion of long-term debt |  |  |  | 1,005 |  |  | 108 |  |
| Long-term debt, net of current portion |  |  |  | $ | 10,422 |  |  | $ | 11,365 |  |
  (was, 2025-10-28, similarity 0.9552):
[0001783180-25-000066:note_history:28]
| (In millions) |  |  |  | September 30,2025 |  | December 31,2024 |
| 2.242% Notes due 2025 (1) |  |  |  | $ | — |  |  | $ | 1,200 |  |
| 2.493% Notes due 2027 |  |  |  | 900 |  |  | 900 |  |
| 4.125% Notes due 2028 |  |  |  | 875 |  |  | 783 |  |
| 2.722% Notes due 2030 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.700% Notes due 2031 |  |  |  | 750 |  |  | 750 |  |
| 4.500% Notes due 2032 |  |  |  | 992 |  |  | 887 |  |
| 5.900% Notes due 2034 |  |  |  | 875 |  |  | 875 |  |
| 3.625% Notes due 2037 |  |  |  | 875 |  |  | 783 |  |
| 3.377% Notes due 2040 |  |  |  | 1,500 |  |  | 1,500 |  |
| 3.577% Notes due 2050 |  |  |  | 1,400 |  |  | 1,400 |  |
| 6.200% Notes due 2054 |  |  |  | 650 |  |  | 650 |  |
| Total long-term notes |  |  |  | 10,817 |  |  | 11,728 |  |
| Japanese Term Loan Facility |  |  |  | 360 |  |  | 342 |  |
| Other debt (including project financing obligations and finance leases) |  |  |  | 347 |  |  | 296 |  |
| Discounts and debt issuance costs |  |  |  | (81) |  |  | (88) |  |
| Total long-term debt |  |  |  | 11,443 |  |  | 12,278 |  |
| Less: current portion of long-term debt |  |  |  | 107 |  |  | 1,252 |  |
| Long-term debt, net of current portion |  |  |  | $ | 11,336 |  |  | $ | 11,026 |  |

- changed (2026-04-30):
[0001783180-26-000026:note_history:29]
(1) 2.493% Notes due February 27, 2027; reclassified to Current portion of long-term debt.
  (was, 2025-10-28, similarity 0.6618):
[0001783180-25-000066:note_history:29]
(1) 2.242% Notes due February 15, 2025; repaid during February 2025.

- changed (2026-04-30):
[0001783180-26-000026:note_history:30]
The Company maintains a $2.5 billion unsecured, unsubordinated revolving credit facility that matures in December 2029 (the "Revolving Credit Facility"). The Revolving Credit Facility supports the Company's commercial paper program and can be used for other general corporate purposes. Borrowings are available in U.S. Dollars and Euros. U.S. Dollar borrowings bear interest at either a Term SOFR Rate plus 0.10% and a ratings-based margin or, alternatively, at an alternate base rate plus a ratings-based margin. Euro borrowings bear interest at an adjusted EURIBOR rate plus a ratings-based margin. A ratings-based commitment fee is charged on unused commitments. As of March 31, 2026, there were no borrowings outstanding under the Revolving Credit Facility.
  (was, 2025-10-28, similarity 0.7947):
[0001783180-25-000066:note_history:30]
On December 20, 2024, the Company refinanced its revolving credit agreement with JPMorgan Chase Bank, N.A., as administrative agent, and certain other lenders, permitting aggregate borrowings of up to $2.5 billion pursuant to an unsecured, unsubordinated revolving credit facility that matures in December 2029 (the "Revolving Credit Facility"). The Revolving Credit Facility supports the Company's commercial paper program and can be used for other general corporate purposes. Borrowings are available in U.S. Dollars and Euros. U.S. Dollar borrowings bear interest at either a Term SOFR Rate plus 0.10% and a ratings-based margin or, alternatively, at an alternate base rate plus a ratings-based margin. Euro borrowings bear interest at an adjusted EURIBOR rate plus a ratings-based margin. A ratings-based commitment fee is charged on unused commitments. Upon entering into the agreement, the Company capitalized $11 million of deferred financing costs which are being amortized over its term. As of September 30, 2025, there were no borrowings outstanding under the Revolving Credit Facility.

- changed (2026-04-30):
[0001783180-26-000026:note_history:31]
The Company is involved in long-term construction contracts in which it arranges project financing with certain customers. As a result, the Company issued $14 million and $6 million of debt during the three months ended March 31, 2026 and 2025, respectively. Long-term debt repayments associated with these financing arrangements during the three months ended March 31, 2026 and 2025, were $14 million and zero, respectively.
  (was, 2025-10-28, similarity 0.8529):
[0001783180-25-000066:note_history:31]
The Company is involved in long-term construction contracts in which it arranges project financing with certain customers. As a result, the Company issued $22 million and $40 million of debt during the nine months ended September 30, 2025 and 2024, respectively. Long-term debt repayments associated with these financing arrangements during the nine months ended September 30, 2025 and 2024, were zero and $7 million, respectively.

- changed (2026-04-30):
[0001783180-26-000026:note_history:32]
The Revolving Credit Facility, the indenture for the long-term notes and the five-year, JPY 54 billion senior unsecured term loan facility ("Japanese Term Loan Facility") contain affirmative and negative covenants customary for financings of these types, which, among other things, limit the Company's ability to incur certain liens, to make certain fundamental changes and to enter into sale and leaseback transactions. As of March 31, 2026, the Company was in compliance with the covenants under the agreements governing its outstanding indebtedness.
  (was, 2025-10-28, similarity 0.9634):
[0001783180-25-000066:note_history:32]
The Revolving Credit Facility, the indenture for the long-term notes and the five-year, JPY 54 billion (approximately $400 million) senior unsecured term loan facility ("Japanese Term Loan Facility") contain affirmative and negative covenants customary for financings of these types, which, among other things, limit the Company's ability to incur certain liens, to make certain fundamental changes and to enter into sale and leaseback transactions. As of September 30, 2025, the Company was in compliance with the covenants under the agreements governing its outstanding indebtedness.

- removed (2026-04-30):
[0001783180-25-000066:note_history:33]
| (In millions) |  |  |  | September 30,2025 |  | December 31,2024 |
| Commercial paper |  |  |  | $ | 415 |  |  | $ | — |  |
| Short-term borrowings |  |  |  | 58 |  |  | 84 |  |
| Current portion of long-term debt |  |  |  | 107 |  |  | 1,252 |  |
| Short-term borrowings and current portion of long-term debt |  |  |  | $ | 580 |  |  | $ | 1,336 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2026-04-30):
[0001783180-26-000026:note_history:34]
| (In millions) |  |  |  | March 31,2026 |  | December 31,2025 |
| 2.493% Notes due 2027 (1) |  |  |  | 900 |  |  | 900 |  |
| 4.125% Notes due 2028 |  |  |  | 865 |  |  | 883 |  |
| 2.722% Notes due 2030 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.700% Notes due 2031 |  |  |  | 750 |  |  | 750 |  |
| 4.500% Notes due 2032 |  |  |  | 980 |  |  | 1,001 |  |
| 5.900% Notes due 2034 |  |  |  | 875 |  |  | 875 |  |
| 3.625% Notes due 2037 |  |  |  | 865 |  |  | 883 |  |
| 3.377% Notes due 2040 |  |  |  | 1,500 |  |  | 1,500 |  |
| 3.577% Notes due 2050 |  |  |  | 1,400 |  |  | 1,400 |  |
| 6.200% Notes due 2054 |  |  |  | 650 |  |  | 650 |  |
| Total long-term notes |  |  |  | 10,785 |  |  | 10,842 |  |
| Japanese Term Loan Facility |  |  |  | 338 |  |  | 345 |  |
| Other debt (including project financing obligations and finance leases) |  |  |  | 380 |  |  | 364 |  |
| Discounts and debt issuance costs |  |  |  | (76) |  |  | (78) |  |
| Total long-term debt |  |  |  | 11,427 |  |  | 11,473 |  |
| Less: current portion of long-term debt |  |  |  | 1,005 |  |  | 108 |  |
| Long-term debt, net of current portion |  |  |  | $ | 10,422 |  |  | $ | 11,365 |  |
  (was, 2025-10-28, similarity 0.9552):
[0001783180-25-000066:note_history:34]
| (In millions) |  |  |  | September 30,2025 |  | December 31,2024 |
| 2.242% Notes due 2025 (1) |  |  |  | $ | — |  |  | $ | 1,200 |  |
| 2.493% Notes due 2027 |  |  |  | 900 |  |  | 900 |  |
| 4.125% Notes due 2028 |  |  |  | 875 |  |  | 783 |  |
| 2.722% Notes due 2030 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.700% Notes due 2031 |  |  |  | 750 |  |  | 750 |  |
| 4.500% Notes due 2032 |  |  |  | 992 |  |  | 887 |  |
| 5.900% Notes due 2034 |  |  |  | 875 |  |  | 875 |  |
| 3.625% Notes due 2037 |  |  |  | 875 |  |  | 783 |  |
| 3.377% Notes due 2040 |  |  |  | 1,500 |  |  | 1,500 |  |
| 3.577% Notes due 2050 |  |  |  | 1,400 |  |  | 1,400 |  |
| 6.200% Notes due 2054 |  |  |  | 650 |  |  | 650 |  |
| Total long-term notes |  |  |  | 10,817 |  |  | 11,728 |  |
| Japanese Term Loan Facility |  |  |  | 360 |  |  | 342 |  |
| Other debt (including project financing obligations and finance leases) |  |  |  | 347 |  |  | 296 |  |
| Discounts and debt issuance costs |  |  |  | (81) |  |  | (88) |  |
| Total long-term debt |  |  |  | 11,443 |  |  | 12,278 |  |
| Less: current portion of long-term debt |  |  |  | 107 |  |  | 1,252 |  |
| Long-term debt, net of current portion |  |  |  | $ | 11,336 |  |  | $ | 11,026 |  |

- changed (2026-04-30):
[0001783180-26-000026:note_history:35]
(1) 2.493% Notes due February 27, 2027; reclassified to Current portion of long-term debt.
  (was, 2025-10-28, similarity 0.6618):
[0001783180-25-000066:note_history:35]
(1) 2.242% Notes due February 15, 2025; repaid during February 2025.


## us-gaap:ScheduleOfShortTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2026-04-30):
[0001783180-26-000026:note_history:36]
| (In millions) |  |  |  | March 31,2026 |  | December 31,2025 |
| Commercial paper |  |  |  | $ | 708 |  |  | $ | 325 |  |
| Short-term borrowings |  |  |  | 23 |  |  | 35 |  |
| Current portion of long-term debt |  |  |  | 1,005 |  |  | 108 |  |
| Short-term borrowings and current portion of long-term debt |  |  |  | $ | 1,736 |  |  | $ | 468 |  |

- removed (2026-04-30):
[0001783180-25-000066:note_history:37]
| (In millions) |  |  |  | September 30,2025 |  | December 31,2024 |
| Commercial paper |  |  |  | $ | 415 |  |  | $ | — |  |
| Short-term borrowings |  |  |  | 58 |  |  | 84 |  |
| Current portion of long-term debt |  |  |  | 107 |  |  | 1,252 |  |
| Short-term borrowings and current portion of long-term debt |  |  |  | $ | 580 |  |  | $ | 1,336 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- added (2026-04-30):
[0001783180-26-000026:note_history:38]
|  |  | Three Months Ended March 31, |  |  |
| (In millions) |  | 2026 |  | 2025 |  |  |  |  |
| Sales to equity method investees included in Product sales |  | $ | 686 |  |  | $ | 780 |  |  |  |  |  |
| Purchases from equity method investees included in Cost of products sold |  | $ | 51 |  |  | $ | 47 |  |  |  |  |  |

- added (2026-04-30):
[0001783180-26-000026:note_history:39]
| (In millions) |  | March 31,2026 |  | December 31,2025 |
| Receivables from equity method investees included in Accounts receivable, net |  | $ | 290 |  |  | $ | 220 |  |
| Payables to equity method investees included in Accounts payable |  | $ | 33 |  |  | $ | 40 |  |

- removed (2026-04-30):
[0001783180-25-000066:note_history:40]
|  |  | Three Months Ended September 30, |  | Nine Months EndedSeptember 30, |
| (In millions) |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Sales to equity method investees included in Product sales |  | $ | 668 |  |  | $ | 774 |  |  | $ | 2,293 |  |  | $ | 2,329 |  |
| Purchases from equity method investees included in Cost of products sold |  | $ | 68 |  |  | $ | 64 |  |  | $ | 172 |  |  | $ | 178 |  |

- removed (2026-04-30):
[0001783180-25-000066:note_history:41]
| (In millions) |  | September 30,2025 |  | December 31,2024 |
| Receivables from equity method investees included in Accounts receivable, net |  | $ | 255 |  |  | $ | 363 |  |
| Payables to equity method investees included in Accounts payable |  | $ | 40 |  |  | $ | 32 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2026-04-30):
[0001783180-26-000026:note_history:42]
|  |  | Three Months Ended March 31, |  |  |
| (In millions) |  | 2026 |  | 2025 |  |  |  |  |
| Sales Type |  |  |  |  |  |  |  |  |
| Product |  | $ | 2,214 |  |  | $ | 2,319 |  |  |  |  |  |
| Service |  | 287 |  |  | 253 |  |  |  |  |  |
| Climate Solutions Americas sales |  | 2,501 |  |  | 2,572 |  |  |  |  |  |
| Product |  | 1,154 |  |  | 1,071 |  |  |  |  |  |
| Service |  | 139 |  |  | 98 |  |  |  |  |  |
| Climate Solutions Europe sales |  | 1,293 |  |  | 1,169 |  |  |  |  |  |
| Product |  | 642 |  |  | 660 |  |  |  |  |  |
| Service |  | 192 |  |  | 166 |  |  |  |  |  |
| Climate Solutions Asia Pacific, Middle East & Africa sales |  | 834 |  |  | 826 |  |  |  |  |  |
| Product |  | 657 |  |  | 602 |  |  |  |  |  |
| Service |  | 56 |  |  | 49 |  |  |  |  |  |
| Climate Solutions Transportation sales |  | 713 |  |  | 651 |  |  |  |  |  |
| Net sales |  | $ | 5,341 |  |  | $ | 5,218 |  |  |  |  |  |
  (was, 2025-10-28, similarity 0.8646):
[0001783180-25-000066:note_history:42]
|  |  | Three Months Ended September 30, |  | Nine Months EndedSeptember 30, |
| (In millions) |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Sales Type |  |  |  |  |  |  |  |  |
| Product |  | $ | 2,393 |  |  | $ | 2,669 |  |  | $ | 7,682 |  |  | $ | 7,359 |  |
| Service |  | 318 |  |  | 292 |  |  | 853 |  |  | 827 |  |
| Climate Solutions Americas sales |  | 2,711 |  |  | 2,961 |  |  | 8,535 |  |  | 8,186 |  |
| Product |  | 1,168 |  |  | 1,150 |  |  | 3,376 |  |  | 3,515 |  |
| Service |  | 122 |  |  | 96 |  |  | 336 |  |  | 217 |  |
| Climate Solutions Europe sales |  | 1,290 |  |  | 1,246 |  |  | 3,712 |  |  | 3,732 |  |
| Product |  | 659 |  |  | 678 |  |  | 2,016 |  |  | 2,153 |  |
| Service |  | 174 |  |  | 162 |  |  | 525 |  |  | 473 |  |
| Climate Solutions Asia Pacific, Middle East & Africa sales |  | 833 |  |  | 840 |  |  | 2,541 |  |  | 2,626 |  |
| Product |  | 686 |  |  | 810 |  |  | 1,961 |  |  | 2,433 |  |
| Service |  | 59 |  |  | 127 |  |  | 161 |  |  | 361 |  |
| Climate Solutions Transportation sales |  | 745 |  |  | 937 |  |  | 2,122 |  |  | 2,794 |  |
| Net sales |  | $ | 5,579 |  |  | $ | 5,984 |  |  | $ | 16,910 |  |  | $ | 17,338 |  |

- changed (2026-04-30):
[0001783180-26-000026:note_history:43]
Geographic external sales are attributed to the geographic regions based on their location of origin. With the exception of the United States as presented in the table below, there were no individually significant countries with sales exceeding 10% of total sales during the three months ended March 31, 2026 and 2025.
  (was, 2025-10-28, similarity 0.9666):
[0001783180-25-000066:note_history:43]
Geographic external sales are attributed to the geographic regions based on their location of origin. With the exception of the United States as presented in the table below, there were no individually significant countries with sales exceeding 10% of total sales during the three and nine months ended September 30, 2025 and 2024.

- changed (2026-04-30):
[0001783180-26-000026:note_history:44]
|  |  | Three Months Ended March 31, |  |  |
| (In millions) |  | 2026 |  | 2025 |  |  |  |  |
| United States |  | $ | 2,657 |  |  | $ | 2,738 |  |  |  |  |  |
| International: |  |  |  |  |  |  |  |  |
| Europe |  | 1,549 |  |  | 1,401 |  |  |  |  |  |
| Asia Pacific |  | 986 |  |  | 941 |  |  |  |  |  |
| Other |  | 149 |  |  | 138 |  |  |  |  |  |
| Net sales |  | $ | 5,341 |  |  | $ | 5,218 |  |  |  |  |  |
  (was, 2025-10-28, similarity 0.8143):
[0001783180-25-000066:note_history:44]
|  |  | Three Months Ended September 30, |  | Nine Months EndedSeptember 30, |
| (In millions) |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| United States |  | $ | 2,860 |  |  | $ | 3,154 |  |  | $ | 9,027 |  |  | $ | 8,778 |  |
| International: |  |  |  |  |  |  |  |  |
| Europe |  | 1,560 |  |  | 1,723 |  |  | 4,481 |  |  | 5,152 |  |
| Asia Pacific |  | 961 |  |  | 923 |  |  | 2,883 |  |  | 2,886 |  |
| Other |  | 198 |  |  | 184 |  |  | 519 |  |  | 522 |  |
| Net sales |  | $ | 5,579 |  |  | $ | 5,984 |  |  | $ | 16,910 |  |  | $ | 17,338 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2026-04-30):
[0001783180-26-000026:note_history:45]
|  |  | Three Months Ended March 31, |  |  |
| (In millions) |  | 2026 |  | 2025 |  |  |  |  |
| Sales Type |  |  |  |  |  |  |  |  |
| Product |  | $ | 2,214 |  |  | $ | 2,319 |  |  |  |  |  |
| Service |  | 287 |  |  | 253 |  |  |  |  |  |
| Climate Solutions Americas sales |  | 2,501 |  |  | 2,572 |  |  |  |  |  |
| Product |  | 1,154 |  |  | 1,071 |  |  |  |  |  |
| Service |  | 139 |  |  | 98 |  |  |  |  |  |
| Climate Solutions Europe sales |  | 1,293 |  |  | 1,169 |  |  |  |  |  |
| Product |  | 642 |  |  | 660 |  |  |  |  |  |
| Service |  | 192 |  |  | 166 |  |  |  |  |  |
| Climate Solutions Asia Pacific, Middle East & Africa sales |  | 834 |  |  | 826 |  |  |  |  |  |
| Product |  | 657 |  |  | 602 |  |  |  |  |  |
| Service |  | 56 |  |  | 49 |  |  |  |  |  |
| Climate Solutions Transportation sales |  | 713 |  |  | 651 |  |  |  |  |  |
| Net sales |  | $ | 5,341 |  |  | $ | 5,218 |  |  |  |  |  |
  (was, 2025-10-28, similarity 0.8646):
[0001783180-25-000066:note_history:45]
|  |  | Three Months Ended September 30, |  | Nine Months EndedSeptember 30, |
| (In millions) |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Sales Type |  |  |  |  |  |  |  |  |
| Product |  | $ | 2,393 |  |  | $ | 2,669 |  |  | $ | 7,682 |  |  | $ | 7,359 |  |
| Service |  | 318 |  |  | 292 |  |  | 853 |  |  | 827 |  |
| Climate Solutions Americas sales |  | 2,711 |  |  | 2,961 |  |  | 8,535 |  |  | 8,186 |  |
| Product |  | 1,168 |  |  | 1,150 |  |  | 3,376 |  |  | 3,515 |  |
| Service |  | 122 |  |  | 96 |  |  | 336 |  |  | 217 |  |
| Climate Solutions Europe sales |  | 1,290 |  |  | 1,246 |  |  | 3,712 |  |  | 3,732 |  |
| Product |  | 659 |  |  | 678 |  |  | 2,016 |  |  | 2,153 |  |
| Service |  | 174 |  |  | 162 |  |  | 525 |  |  | 473 |  |
| Climate Solutions Asia Pacific, Middle East & Africa sales |  | 833 |  |  | 840 |  |  | 2,541 |  |  | 2,626 |  |
| Product |  | 686 |  |  | 810 |  |  | 1,961 |  |  | 2,433 |  |
| Service |  | 59 |  |  | 127 |  |  | 161 |  |  | 361 |  |
| Climate Solutions Transportation sales |  | 745 |  |  | 937 |  |  | 2,122 |  |  | 2,794 |  |
| Net sales |  | $ | 5,579 |  |  | $ | 5,984 |  |  | $ | 16,910 |  |  | $ | 17,338 |  |

- changed (2026-04-30):
[0001783180-26-000026:note_history:46]
| (In millions) |  | March 31,2026 |  | December 31,2025 |
| Contract assets (included within Other current assets) |  | $ | 527 |  |  | $ | 499 |  |
| Contract assets, non-current (included within Other assets) |  | 79 |  |  | 83 |  |
| Total contract assets |  | 606 |  |  | 582 |  |
| Contract liabilities (included within Accrued liabilities) |  | (722) |  |  | (691) |  |
| Contract liabilities, non-current (included within Other long-term liabilities) |  | (208) |  |  | (203) |  |
| Total contract liabilities |  | (930) |  |  | (894) |  |
| Net contract assets (liabilities) |  | $ | (324) |  |  | $ | (312) |  |
  (was, 2025-10-28, similarity 0.9892):
[0001783180-25-000066:note_history:46]
| (In millions) |  | September 30,2025 |  | December 31,2024 |
| Contract assets (included within Other current assets) |  | $ | 520 |  |  | $ | 366 |  |
| Contract assets, non-current (included within Other assets) |  | 55 |  |  | 65 |  |
| Total contract assets |  | 575 |  |  | 431 |  |
| Contract liabilities (included within Accrued liabilities) |  | (546) |  |  | (553) |  |
| Contract liabilities, non-current (included within Other long-term liabilities) |  | (186) |  |  | (164) |  |
| Total contract liabilities |  | (732) |  |  | (717) |  |
| Net contract assets (liabilities) |  | $ | (157) |  |  | $ | (286) |  |

- changed (2026-04-30):
[0001783180-26-000026:note_history:47]
The timing of revenue recognition, billings and cash collections results in contract assets and contract liabilities. Contract assets relate to the conditional right to consideration for any completed performance under a contract when costs are incurred in excess of billings under the percentage-of-completion methodology. Contract liabilities relate to payments received in advance of performance under a contract or when the Company has a right to consideration that is conditioned upon transfer of a good or service to a customer. Contract liabilities are recognized as revenue as (or when) the Company performs under the contract.
The Company recognized revenue of $250 million during the three months ended March 31, 2026, that related to contract liabilities as of January 1, 2026. The Company expects a majority of its current contract liabilities at the end of the period to be recognized as revenue in the next 12 months.
  (was, 2025-10-28, similarity 0.9722):
[0001783180-25-000066:note_history:47]
The timing of revenue recognition, billings and cash collections results in contract assets and contract liabilities. Contract assets relate to the conditional right to consideration for any completed performance under a contract when costs are incurred in excess of billings under the percentage-of-completion methodology. Contract liabilities relate to payments received in advance of performance under a contract or when the Company has a right to consideration that is conditioned upon transfer of a good or service to a customer. Contract liabilities are recognized as revenue as (or when) the Company performs under the contract.
The Company recognized revenue of $491 million during the nine months ended September 30, 2025, that related to contract liabilities as of January 1, 2025. The Company expects a majority of its current contract liabilities at the end of the period to be recognized as revenue in the next 12 months.
