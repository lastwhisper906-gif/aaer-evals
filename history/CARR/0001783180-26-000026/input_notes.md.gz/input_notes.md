# CARR notes — 0001783180-26-000026


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001783180-26-000026:notes:1]
DESCRIPTION OF THE BUSINESS
Carrier Global Corporation (the "Company") is a global leader in intelligent climate and energy solutions with a focus on providing differentiated, digitally-enabled lifecycle solutions to its customers. The Company's portfolio includes industry-leading brands such as Carrier, Viessmann, Toshiba, Automated Logic and Carrier Transicold that offer innovative heating, cooling and cold chain solutions to enhance the lives we live and the world we share. The Company also provides a broad array of related building services, including audit, design, installation, system integration, repair, maintenance and monitoring. The Company's operations are classified into four segments: Climate Solutions Americas, Climate Solutions Europe, Climate Solutions Asia Pacific, Middle East & Africa and Climate Solutions Transportation.
In the opinion of management, the accompanying Unaudited Condensed Consolidated Financial Statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission (the "SEC"). The accompanying Unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for 2025 filed with the SEC on February 5, 2026 (the "2025 Form 10-K").


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001783180-26-000026:notes:2]
BASIS OF PRESENTATION
The Unaudited Condensed Consolidated Financial Statements include all accounts of the Company and its wholly-owned and majority-owned subsidiaries in which it has control. Inter-company accounts and transactions have been eliminated. Related party transactions between the Company and its equity method investees have not been eliminated. Non-controlling interest represents a non-controlling investor's interests in the results of subsidiaries that the Company controls and consolidates.

[0001783180-26-000026:notes:3]
Sale of Riello Business

[0001783180-26-000026:notes:4]
On December 16, 2025, the Company entered into a stock purchase agreement to sell its Riello business ("Riello") to Ariston Group with expected gross proceeds of approximately $430 million. Riello, predominantly reported in the Company's Climate Solutions Europe segment, is a leading international manufacturer that designs, produces and integrates a comprehensive portfolio of thermal solutions including burners, boilers, heat pumps, cooling systems and aftermarket services for residential, commercial and industrial applications, with a strong focus on energy efficiency, innovation and a global distribution network. As a result, the assets and liabilities of Riello are presented as held for sale in the accompanying Unaudited Condensed Consolidated Balance Sheet as of March 31, 2026 and December 31, 2025, and recorded at the lower of their carrying value or fair value less estimated cost to sell. See Note 15 - Divestitures for additional information.

[0001783180-26-000026:notes:5]
[same as prior period, unchanged from 0001783180-25-000066:notes:8]

[0001783180-26-000026:notes:6]
On April 3, 2020 (the "Distribution Date"), United Technologies Corporation ("UTC"), since renamed RTX Corporation ("Raytheon Technologies Corporation" or "RTX"), completed the spin-off of Carrier into an independent, publicly traded company (the "Separation") through a pro-rata distribution (the "Distribution") on a one-for-one basis of all of the outstanding shares of common stock of Carrier to UTC shareowners who held shares of UTC common stock as of the close of business on March 19, 2020, the record date of the Distribution. In addition, the Company entered into several agreements with UTC and Otis Worldwide Corporation ("Otis") that govern various aspects of the relationship among the Company, UTC and Otis. As of March 31, 2026, only certain portions of the Tax Matters Agreement ("TMA") remain in effect.

[0001783180-26-000026:notes:7]
[same as prior period, unchanged from 0001783180-25-000066:notes:10]

[0001783180-26-000026:notes:8]
[same as prior period, unchanged from 0001783180-25-000066:notes:11]

[0001783180-26-000026:notes:9]
Recently Issued Accounting Pronouncements

[0001783180-26-000026:notes:10]
In November 2024, the FASB issued ASU 2024-03, Disaggregation of Income Statement Expenses (DISE) ("ASU 2024-03"), which requires public entities to disclose disaggregated information about expenses by nature on an interim and annual basis. ASU 2024-03 is effective for fiscal years beginning after December 15, 2026 and interim periods within fiscal years beginning after December 15, 2027, with early adoption permitted. The Company is currently assessing the impact of this ASU on its financial statements.


## us-gaap:InventoryDisclosureTextBlock

[0001783180-26-000026:notes:11]
[same as prior period, unchanged from 0001783180-25-000066:notes:15]

[0001783180-26-000026:notes:12]
[same as prior period, unchanged from 0001783180-25-000066:notes:16]

[0001783180-26-000026:notes:13]
| (In millions) |  | March 31,2026 |  | December 31,2025 |
| Raw materials |  | $ | 645 |  |  | $ | 666 |  |
| Work-in-process |  | 269 |  |  | 245 |  |
| Finished goods |  | 1,667 |  |  | 1,572 |  |
| Inventories, net |  | $ | 2,581 |  |  | $ | 2,483 |  |

[0001783180-26-000026:notes:14]
The Company performs periodic assessments utilizing customer demand, production requirements and historical usage rates to determine the existence of excess and obsolete inventory and records necessary provisions to reduce such inventories to the lower of cost or estimated net realizable value. Raw materials, work-in-process and finished goods are net of valuation reserves of $345 million and $337 million as of March 31, 2026 and December 31, 2025, respectively.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001783180-26-000026:notes:15]
[same as prior period, unchanged from 0001783180-25-000066:notes:19]

[0001783180-26-000026:notes:16]
The changes in the carrying value of goodwill were as follows:

[0001783180-26-000026:notes:17]
| (In millions) |  | Climate Solutions Americas |  | Climate Solutions Europe |  | Climate Solutions Asia Pacific, Middle East & Africa |  | Climate Solutions Transportation |  |  |  |  |  | Total |
| Balance as of December 31, 2025 |  | $ | 5,075 |  |  | $ | 7,808 |  |  | $ | 1,410 |  |  | $ | 1,208 |  |  |  |  |  |  | $ | 15,501 |  |
| Acquisitions |  | 10 |  |  | — |  |  | — |  |  | — |  |  |  |  |  |  | 10 |  |
| Reclassified to held for sale (1) |  | — |  |  | 4 |  |  | — |  |  | — |  |  |  |  |  |  | 4 |  |
| Foreign currency translation |  | (2) |  |  | (191) |  |  | (1) |  |  | (8) |  |  |  |  |  |  | (202) |  |
| Balance as of March 31, 2026 |  | $ | 5,083 |  |  | $ | 7,621 |  |  | $ | 1,409 |  |  | $ | 1,200 |  |  |  |  |  |  | $ | 15,313 |  |

[0001783180-26-000026:notes:18]
(1) See Note 15 - Divestitures for additional information.

[0001783180-26-000026:notes:19]
[same as prior period, unchanged from 0001783180-25-000066:notes:22]

[0001783180-26-000026:notes:20]
|  |  | March 31, 2026 |  | December 31, 2025 |
| (In millions) |  | Gross Amount |  | Accumulated Amortization |  | Net Amount |  | Gross Amount |  | Accumulated Amortization |  | Net Amount |
| Customer relationships |  | $ | 6,009 |  |  | $ | (1,697) |  |  | $ | 4,312 |  |  | $ | 6,143 |  |  | $ | (1,573) |  |  | $ | 4,570 |  |
| Patents and trademarks |  | 942 |  |  | (204) |  |  | 738 |  |  | 945 |  |  | (191) |  |  | 754 |  |
| Technology and other |  | 1,657 |  |  | (720) |  |  | 937 |  |  | 1,692 |  |  | (690) |  |  | 1,002 |  |
| Total intangible assets |  | $ | 8,608 |  |  | $ | (2,621) |  |  | $ | 5,987 |  |  | $ | 8,780 |  |  | $ | (2,454) |  |  | $ | 6,326 |  |

[0001783180-26-000026:notes:21]
[same as prior period, unchanged from 0001783180-25-000066:notes:24]

[0001783180-26-000026:notes:22]
|  |  | Three Months Ended March 31, |  |  |
| (In millions) |  | 2026 |  | 2025 |  |  |  |  |
| Amortization expense of Intangible assets |  | $ | 217 |  |  | $ | 208 |  |  |  |  |  |


## us-gaap:DebtDisclosureTextBlock

[0001783180-26-000026:notes:23]
BORROWINGS AND LINES OF CREDIT
Short-term borrowings and current portion of long-term debt consisted of the following:

[0001783180-26-000026:notes:24]
| (In millions) |  |  |  | March 31,2026 |  | December 31,2025 |
| Commercial paper |  |  |  | $ | 708 |  |  | $ | 325 |  |
| Short-term borrowings |  |  |  | 23 |  |  | 35 |  |
| Current portion of long-term debt |  |  |  | 1,005 |  |  | 108 |  |
| Short-term borrowings and current portion of long-term debt |  |  |  | $ | 1,736 |  |  | $ | 468 |  |

[0001783180-26-000026:notes:25]
Commercial Paper Program

[0001783180-26-000026:notes:26]
The Company has a $2.0 billion USD-denominated facility and a $500 million Euro-denominated facility as part of an unsecured, unsubordinated commercial paper program, which can be used for general corporate purposes including the funding of working capital and potential acquisitions. At March 31, 2026, the Company had $708 million outstanding under its  commercial paper facilities with a weighted average interest rate of 4.06%.

[0001783180-26-000026:notes:27]
Long-term debt consisted of the following:

[0001783180-26-000026:notes:28]
| (In millions) |  |  |  | March 31,2026 |  | December 31,2025 |
| 2.493% Notes due 2027 (1) |  |  |  | 900 |  |  | 900 |  |
| 4.125% Notes due 2028 |  |  |  | 865 |  |  | 883 |  |
| 2.722% Notes due 2030 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.700% Notes due 2031 |  |  |  | 750 |  |  | 750 |  |
| 4.500% Notes due 2032 |  |  |  | 980 |  |  | 1,001 |  |
| 5.900% Notes due 2034 |  |  |  | 875 |  |  | 875 |  |
| 3.625% Notes due 2037 |  |  |  | 865 |  |  | 883 |  |
| 3.377% Notes due 2040 |  |  |  | 1,500 |  |  | 1,500 |  |
| 3.577% Notes due 2050 |  |  |  | 1,400 |  |  | 1,400 |  |
| 6.200% Notes due 2054 |  |  |  | 650 |  |  | 650 |  |
| Total long-term notes |  |  |  | 10,785 |  |  | 10,842 |  |
| Japanese Term Loan Facility |  |  |  | 338 |  |  | 345 |  |
| Other debt (including project financing obligations and finance leases) |  |  |  | 380 |  |  | 364 |  |
| Discounts and debt issuance costs |  |  |  | (76) |  |  | (78) |  |
| Total long-term debt |  |  |  | 11,427 |  |  | 11,473 |  |
| Less: current portion of long-term debt |  |  |  | 1,005 |  |  | 108 |  |
| Long-term debt, net of current portion |  |  |  | $ | 10,422 |  |  | $ | 11,365 |  |

[0001783180-26-000026:notes:29]
(1) 2.493% Notes due February 27, 2027; reclassified to Current portion of long-term debt.

[0001783180-26-000026:notes:30]
Revolving Credit Facility

[0001783180-26-000026:notes:31]
The Company maintains a $2.5 billion unsecured, unsubordinated revolving credit facility that matures in December 2029 (the "Revolving Credit Facility"). The Revolving Credit Facility supports the Company's commercial paper program and can be used for other general corporate purposes. Borrowings are available in U.S. Dollars and Euros. U.S. Dollar borrowings bear interest at either a Term SOFR Rate plus 0.10% and a ratings-based margin or, alternatively, at an alternate base rate plus a ratings-based margin. Euro borrowings bear interest at an adjusted EURIBOR rate plus a ratings-based margin. A ratings-based commitment fee is charged on unused commitments. As of March 31, 2026, there were no borrowings outstanding under the Revolving Credit Facility.

[0001783180-26-000026:notes:32]
Project Financing Arrangements

[0001783180-26-000026:notes:33]
The Company is involved in long-term construction contracts in which it arranges project financing with certain customers. As a result, the Company issued $14 million and $6 million of debt during the three months ended March 31, 2026 and 2025, respectively. Long-term debt repayments associated with these financing arrangements during the three months ended March 31, 2026 and 2025, were $14 million and zero, respectively.

[0001783180-26-000026:notes:34]
Debt Covenants

[0001783180-26-000026:notes:35]
The Revolving Credit Facility, the indenture for the long-term notes and the five-year, JPY 54 billion senior unsecured term loan facility ("Japanese Term Loan Facility") contain affirmative and negative covenants customary for financings of these types, which, among other things, limit the Company's ability to incur certain liens, to make certain fundamental changes and to enter into sale and leaseback transactions. As of March 31, 2026, the Company was in compliance with the covenants under the agreements governing its outstanding indebtedness.


## us-gaap:FairValueDisclosuresTextBlock

[0001783180-26-000026:notes:36]
[same as prior period, unchanged from 0001783180-25-000066:notes:42]

[0001783180-26-000026:notes:37]
[same as prior period, unchanged from 0001783180-25-000066:notes:43]

[0001783180-26-000026:notes:38]
[same as prior period, unchanged from 0001783180-25-000066:notes:44]

[0001783180-26-000026:notes:39]
[same as prior period, unchanged from 0001783180-25-000066:notes:45]

[0001783180-26-000026:notes:40]
[same as prior period, unchanged from 0001783180-25-000066:notes:46]

[0001783180-26-000026:notes:41]
[same as prior period, unchanged from 0001783180-25-000066:notes:47]

[0001783180-26-000026:notes:42]
The Company enters into external cross currency swaps in order to manage foreign currency translation risk on assets denominated in a functional currency other than the U.S. Dollar. The swaps have an aggregate notional amount of $3.2 billion and are measured at fair value on a recurring basis using observable market inputs, such as forward, discount and interest rates. The Company designates the cross currency swaps as a partial hedge of its investment in certain subsidiaries whose functional currency is not the U.S. Dollar. As a result, changes in the fair value of the swaps are recorded in Equity in the Unaudited Condensed Consolidated Balance Sheet.

[0001783180-26-000026:notes:43]
[same as prior period, unchanged from 0001783180-25-000066:notes:50]

[0001783180-26-000026:notes:44]
[same as prior period, unchanged from 0001783180-25-000066:notes:52]

[0001783180-26-000026:notes:45]
| (In millions) |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |
| March 31, 2026 |  |  |  |  |  |  |  |  |
| Derivative assets (1) |  | $ | 133 |  |  | $ | — |  |  | $ | 133 |  |  | $ | — |  |
| Derivative liabilities (2) |  | $ | (153) |  |  | $ | — |  |  | $ | (153) |  |  | $ | — |  |
| December 31, 2025 |  |  |  |  |  |  |  |  |
| Derivative assets (1) |  | $ | 129 |  |  | $ | — |  |  | $ | 129 |  |  | $ | — |  |
| Derivative liabilities (2) |  | $ | (166) |  |  | $ | — |  |  | $ | (166) |  |  | $ | — |  |

[0001783180-26-000026:notes:46]
[same as prior period, unchanged from 0001783180-25-000066:notes:54]

[0001783180-26-000026:notes:47]
[same as prior period, unchanged from 0001783180-25-000066:notes:55]

[0001783180-26-000026:notes:48]
The following table provides the carrying values and fair values of the Company's long-term notes that are not recorded at fair value in the accompanying Unaudited Condensed Consolidated Balance Sheet:

[0001783180-26-000026:notes:49]
|  |  | March 31, 2026 |  | December 31, 2025 |
| (In millions) |  | CarryingValue |  | FairValue |  | CarryingValue |  | FairValue |
| Total long-term notes (1) |  | $ | 10,785 |  |  | $ | 9,939 |  |  | $ | 10,842 |  |  | $ | 10,167 |  |

[0001783180-26-000026:notes:50]
[same as prior period, unchanged from 0001783180-25-000066:notes:58]

[0001783180-26-000026:notes:51]
[same as prior period, unchanged from 0001783180-25-000066:notes:59]


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0001783180-26-000026:notes:52]
[same as prior period, unchanged from 0001783180-25-000066:notes:60]


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001783180-26-000026:notes:53]
[same as prior period, unchanged from 0001783180-25-000066:notes:61]

[0001783180-26-000026:notes:54]
[same as prior period, unchanged from 0001783180-25-000066:notes:62]

[0001783180-26-000026:notes:55]
|  |  | Three Months Ended March 31, |  |  |
| (In millions) |  | 2026 |  | 2025 |  |  |  |  |
| Defined benefit plans |  | $ | 5 |  |  | $ | 5 |  |  |  |  |  |
| Defined contribution plans |  | $ | 32 |  |  | $ | 35 |  |  |  |  |  |
| Multi-employer pension plans |  | $ | 4 |  |  | $ | 3 |  |  |  |  |  |

[0001783180-26-000026:notes:56]
[same as prior period, unchanged from 0001783180-25-000066:notes:64]

[0001783180-26-000026:notes:57]
|  |  | Three Months Ended March 31, |  |  |
| (In millions) |  | 2026 |  | 2025 |  |  |  |  |
| Service cost |  | $ | 3 |  |  | $ | 3 |  |  |  |  |  |
| Interest cost |  | 6 |  |  | 7 |  |  |  |  |  |
| Expected return on plan assets |  | (8) |  |  | (8) |  |  |  |  |  |
| Recognized actuarial net (gain) loss |  | 1 |  |  | — |  |  |  |  |  |
| Net periodic pension expense (benefit) |  | $ | 2 |  |  | $ | 2 |  |  |  |  |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001783180-26-000026:notes:58]
[same as prior period, unchanged from 0001783180-25-000066:notes:66]

[0001783180-26-000026:notes:59]
Stock-based compensation expense, net of estimated forfeitures, is included in Cost of products sold, Selling, general and administrative and Research and development in the accompanying Unaudited Condensed Consolidated Statement of Operations.

[0001783180-26-000026:notes:60]
[same as prior period, unchanged from 0001783180-25-000066:notes:68]

[0001783180-26-000026:notes:61]
|  |  | Three Months Ended March 31, |  |  |
| (In millions) |  | 2026 |  | 2025 |  |  |  |  |
| Equity compensation costs - equity settled |  | $ | 21 |  |  | $ | 23 |  |  |  |  |  |
| Equity compensation costs - cash settled (1) |  | 1 |  |  | (1) |  |  |  |  |  |
| Total stock-based compensation expense |  | $ | 22 |  |  | $ | 22 |  |  |  |  |  |

[0001783180-26-000026:notes:62]
[same as prior period, unchanged from 0001783180-25-000066:notes:70]


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001783180-26-000026:notes:63]
[same as prior period, unchanged from 0001783180-25-000066:notes:71]

[0001783180-26-000026:notes:64]
The changes in the carrying value of warranty related provisions are as follows:

[0001783180-26-000026:notes:65]
|  |  | Three Months EndedMarch 31, |
| (In millions) |  | 2026 |  | 2025 |
| Balance as of January 1, |  | $ | 893 |  |  | $ | 786 |  |
| Warranties, performance guarantees issued and changes in estimated liability |  | 92 |  |  | 89 |  |
| Settlements made |  | (69) |  |  | (69) |  |
| Other (1) |  | (6) |  |  | 8 |  |
| Balance as of March 31, |  | $ | 910 |  |  | $ | 814 |  |

[0001783180-26-000026:notes:66]
[same as prior period, unchanged from 0001783180-25-000066:notes:74]


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001783180-26-000026:notes:67]
EQUITY
The authorized number of shares of common stock of Carrier is 4,000,000,000 shares of $0.01 par value. As of March 31, 2026 and December 31, 2025, 951,330,903 and 950,633,287 shares of common stock were issued, respectively, which includes 119,939,168 and 114,891,176 shares of treasury stock, respectively.

[0001783180-26-000026:notes:68]
[same as prior period, unchanged from 0001783180-25-000066:notes:76]

[0001783180-26-000026:notes:69]
The Company may repurchase its outstanding common stock from time to time subject to market conditions and at the Company's discretion. Repurchases occur in the open market or through one or more other public or private transactions pursuant to plans complying with Rules 10b5-1 and 10b-18 under the Exchange Act. Shares acquired are recognized at cost and presented separately on the balance sheet as a reduction to Equity. Since the initial authorization in February 2021, the Company's Board of Directors authorized the repurchase of up to $12.1 billion of the Company's outstanding common stock.

[0001783180-26-000026:notes:70]
During the three months ended March 31, 2026, the Company repurchased 5.0 million shares of common stock for an aggregate purchase price of $306 million. As a result, the Company had approximately $5.0 billion remaining under the current authorization at March 31, 2026.

[0001783180-26-000026:notes:71]
[same as prior period, unchanged from 0001783180-25-000066:notes:79]

[0001783180-26-000026:notes:72]
A summary of changes in the components of Accumulated other comprehensive income (loss) for the three months ended March 31, 2026 is as follows:

[0001783180-26-000026:notes:73]
| (In millions) |  | Foreign Currency Translation |  | Defined Benefit Pension and Post-retirement Plans |  |  |  | Unrealized Hedging Gains (Losses) |  | Accumulated Other Comprehensive Income (Loss) |
| Balance as of December 31, 2025 |  | $ | (225) |  |  | $ | (93) |  |  |  |  | $ | 49 |  |  | $ | (269) |  |
| Other comprehensive income (loss) before reclassifications, net |  | (291) |  |  | — |  |  |  |  | — |  |  | (291) |  |
| Amounts reclassified, pre-tax |  | — |  |  | 1 |  |  |  |  | (1) |  |  | — |  |
| Balance as of March 31, 2026 |  | $ | (516) |  |  | $ | (92) |  |  |  |  | $ | 48 |  |  | $ | (560) |  |

[0001783180-26-000026:notes:74]
A summary of changes in the components of Accumulated other comprehensive income (loss) for the three months ended March 31, 2025 is as follows:

[0001783180-26-000026:notes:75]
| (In millions) |  | Foreign Currency Translation |  | Defined Benefit Pension and Post-retirement Plans |  |  |  | Unrealized Hedging Gains (Losses) |  | Accumulated Other Comprehensive Income (Loss) |
| Balance as of December 31, 2024 |  | $ | (2,053) |  |  | $ | (107) |  |  |  |  | $ | 54 |  |  | $ | (2,106) |  |
| Other comprehensive income (loss) before reclassifications, net |  | 634 |  |  | — |  |  |  |  | — |  |  | 634 |  |
| Amounts reclassified, pre-tax |  | — |  |  | — |  |  |  |  | (1) |  |  | (1) |  |
| Balance as of March 31, 2025 |  | $ | (1,419) |  |  | $ | (107) |  |  |  |  | $ | 53 |  |  | $ | (1,473) |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001783180-26-000026:notes:76]
[same as prior period, unchanged from 0001783180-25-000066:notes:84]

[0001783180-26-000026:notes:77]
[same as prior period, unchanged from 0001783180-25-000066:notes:85]

[0001783180-26-000026:notes:78]
|  |  | Three Months Ended March 31, |  |  |
| (In millions) |  | 2026 |  | 2025 |  |  |  |  |
| Sales Type |  |  |  |  |  |  |  |  |
| Product |  | $ | 2,214 |  |  | $ | 2,319 |  |  |  |  |  |
| Service |  | 287 |  |  | 253 |  |  |  |  |  |
| Climate Solutions Americas sales |  | 2,501 |  |  | 2,572 |  |  |  |  |  |
| Product |  | 1,154 |  |  | 1,071 |  |  |  |  |  |
| Service |  | 139 |  |  | 98 |  |  |  |  |  |
| Climate Solutions Europe sales |  | 1,293 |  |  | 1,169 |  |  |  |  |  |
| Product |  | 642 |  |  | 660 |  |  |  |  |  |
| Service |  | 192 |  |  | 166 |  |  |  |  |  |
| Climate Solutions Asia Pacific, Middle East & Africa sales |  | 834 |  |  | 826 |  |  |  |  |  |
| Product |  | 657 |  |  | 602 |  |  |  |  |  |
| Service |  | 56 |  |  | 49 |  |  |  |  |  |
| Climate Solutions Transportation sales |  | 713 |  |  | 651 |  |  |  |  |  |
| Net sales |  | $ | 5,341 |  |  | $ | 5,218 |  |  |  |  |  |

[0001783180-26-000026:notes:79]
[same as prior period, unchanged from 0001783180-25-000066:notes:87]

[0001783180-26-000026:notes:80]
[same as prior period, unchanged from 0001783180-25-000066:notes:88]

[0001783180-26-000026:notes:81]
| (In millions) |  | March 31,2026 |  | December 31,2025 |
| Contract assets (included within Other current assets) |  | $ | 527 |  |  | $ | 499 |  |
| Contract assets, non-current (included within Other assets) |  | 79 |  |  | 83 |  |
| Total contract assets |  | 606 |  |  | 582 |  |
| Contract liabilities (included within Accrued liabilities) |  | (722) |  |  | (691) |  |
| Contract liabilities, non-current (included within Other long-term liabilities) |  | (208) |  |  | (203) |  |
| Total contract liabilities |  | (930) |  |  | (894) |  |
| Net contract assets (liabilities) |  | $ | (324) |  |  | $ | (312) |  |

[0001783180-26-000026:notes:82]
The timing of revenue recognition, billings and cash collections results in contract assets and contract liabilities. Contract assets relate to the conditional right to consideration for any completed performance under a contract when costs are incurred in excess of billings under the percentage-of-completion methodology. Contract liabilities relate to payments received in advance of performance under a contract or when the Company has a right to consideration that is conditioned upon transfer of a good or service to a customer. Contract liabilities are recognized as revenue as (or when) the Company performs under the contract.
The Company recognized revenue of $250 million during the three months ended March 31, 2026, that related to contract liabilities as of January 1, 2026. The Company expects a majority of its current contract liabilities at the end of the period to be recognized as revenue in the next 12 months.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0001783180-26-000026:notes:83]
[same as prior period, unchanged from 0001783180-25-000066:notes:91]

[0001783180-26-000026:notes:84]
[same as prior period, unchanged from 0001783180-25-000066:notes:92]


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0001783180-26-000026:notes:85]
Geographic external sales are attributed to the geographic regions based on their location of origin. With the exception of the United States as presented in the table below, there were no individually significant countries with sales exceeding 10% of total sales during the three months ended March 31, 2026 and 2025.

[0001783180-26-000026:notes:86]
|  |  | Three Months Ended March 31, |  |  |
| (In millions) |  | 2026 |  | 2025 |  |  |  |  |
| United States |  | $ | 2,657 |  |  | $ | 2,738 |  |  |  |  |  |
| International: |  |  |  |  |  |  |  |  |
| Europe |  | 1,549 |  |  | 1,401 |  |  |  |  |  |
| Asia Pacific |  | 986 |  |  | 941 |  |  |  |  |  |
| Other |  | 149 |  |  | 138 |  |  |  |  |  |
| Net sales |  | $ | 5,341 |  |  | $ | 5,218 |  |  |  |  |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001783180-26-000026:notes:87]
[same as prior period, unchanged from 0001783180-25-000066:notes:95]

[0001783180-26-000026:notes:88]
[same as prior period, unchanged from 0001783180-25-000066:notes:96]

[0001783180-26-000026:notes:89]
|  | Three Months Ended March 31, |  |  |
| (In millions) | 2026 |  | 2025 |  |  |  |  |
| Climate Solutions Americas | $ | 3 |  |  | $ | 3 |  |  |  |  |  |
| Climate Solutions Europe | 86 |  |  | — |  |  |  |  |  |
| Climate Solutions Asia Pacific, Middle East & Africa | 3 |  |  | 1 |  |  |  |  |  |
| Climate Solutions Transportation | 2 |  |  | 1 |  |  |  |  |  |
| Total Segment | 94 |  |  | 5 |  |  |  |  |  |
| Corporate and other | 14 |  |  | 3 |  |  |  |  |  |
| Total restructuring costs (1) | $ | 108 |  |  | $ | 8 |  |  |  |  |  |
| Cost of sales | $ | 44 |  |  | $ | 2 |  |  |  |  |  |
| Selling, general and administrative | 64 |  |  | 6 |  |  |  |  |  |
| Total restructuring costs (1) | $ | 108 |  |  | $ | 8 |  |  |  |  |  |

[0001783180-26-000026:notes:90]
[same as prior period, unchanged from 0001783180-25-000066:notes:98]

[0001783180-26-000026:notes:91]
[same as prior period, unchanged from 0001783180-25-000066:notes:99]

[0001783180-26-000026:notes:92]
|  |  | Three Months EndedMarch 31, |
| (In millions) |  | 2026 |  | 2025 |
| Balance as of January 1, |  | $ | 102 |  |  | $ | 69 |  |
| Net pre-tax restructuring costs |  | 103 |  |  | 4 |  |
| Utilization, foreign exchange and other |  | (46) |  |  | (17) |  |
| Balance as of March 31, |  | $ | 159 |  |  | $ | 56 |  |

[0001783180-26-000026:notes:93]
As of March 31, 2026, the Company had $159 million accrued for costs associated with its announced restructuring initiatives. The balance relates to cost reduction efforts, primarily severance related across each of the Company's segments. The Company expects a majority of the balance to be utilized within 12 months.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001783180-26-000026:notes:94]
INCOME TAXES
The Company accounts for income tax expense in accordance with ASC 740, Income Taxes ("ASC 740"), which requires an estimate of the annual effective income tax rate for the full year to be applied to the respective interim period, taking into account year-to-date amounts, projected results for the full year, and tax items recorded discretely in the period. The effective tax rate was (56.5)% for the three months ended March 31, 2026, compared with 20.3% for the three months ended March 31, 2025. The year-over-year decrease was primarily driven by a net $99 million tax benefit from the partial release of a valuation allowance associated with our operations in a Swiss subsidiary and a favorable settlement of $18 million related to a state income tax audit, both in the current period. The three months ended March 31, 2025 included an $8 million tax benefit generated by the purchase of investment tax credits from a third-party.

[0001783180-26-000026:notes:95]
[same as prior period, unchanged from 0001783180-25-000066:notes:104]

[0001783180-26-000026:notes:96]
The Company conducts business globally and files income tax returns in U.S. federal, state and foreign jurisdictions. In certain jurisdictions, the Company's operations were included in UTC's combined tax returns for the periods through the Distribution. Carrier's tax year 2022 is under examination by the IRS with closure of the examination expected in 2027. The Australia Tax Office is auditing the Company's 2021 tax return, including the review of the disentanglement of the Chubb Australia business, with the audit expected to close in late 2026. In the normal course of business, the Company is subject to examination by taxing authorities throughout the world, including Australia, Canada, China, France, Germany, Hong Kong, India, Italy, Mexico, the Netherlands, Poland, Singapore, the United Kingdom and the United States. The Company is no longer subject to U.S. federal income tax examination for years prior to 2022 and, with few exceptions, is no longer subject to state, local and foreign income tax examinations for tax years prior to 2014.

[0001783180-26-000026:notes:97]
In the ordinary course of business, there is inherent uncertainty in quantifying the Company's income tax positions. The Company assesses its income tax positions and records tax benefits for all years subject to examination based upon management’s evaluation of the facts, circumstances and information available at the reporting date. The Company believes that it is reasonably possible that a net decrease in unrecognized tax benefits of $5 million to $95 million may occur within 12 months as a result of additional uncertain tax positions, the revaluation of uncertain tax positions arising from examinations, appeals, court decisions and/or the expiration of tax statutes.
On July 4, 2025, the One Big Beautiful Bill Act was enacted in the U.S., making permanent key provisions from the Tax Cuts and Jobs Act including full expensing of capital investments and U.S. incurred research and development costs, while also modifying the international tax framework and reinstating favorable treatment for certain business tax items. The legislation has staggered effective dates from 2025 through 2027. The U.S. law change did not have a material impact on the Company's Statement of Operations.


## us-gaap:EarningsPerShareTextBlock

[0001783180-26-000026:notes:98]
[same as prior period, unchanged from 0001783180-25-000066:notes:107]

[0001783180-26-000026:notes:99]
[same as prior period, unchanged from 0001783180-25-000066:notes:108]

[0001783180-26-000026:notes:100]
|  |  | Three Months Ended March 31, |  |  |
| (In millions, except per share amounts) |  | 2026 |  | 2025 |  |  |  |  |
| Net earnings (loss) attributable to common shareowners |  | $ | 238 |  |  | $ | 412 |  |  |  |  |  |
| Basic weighted-average number of shares outstanding |  | 835.0 |  |  | 866.9 |  |  |  |  |  |
| Stock awards and equity units (share equivalent) |  | 7.8 |  |  | 11.4 |  |  |  |  |  |
| Diluted weighted-average number of shares outstanding |  | 842.8 |  |  | 878.3 |  |  |  |  |  |
| Antidilutive shares excluded from computation of diluted earnings per share |  | 6.8 |  |  | 3.7 |  |  |  |  |  |


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001783180-26-000026:notes:101]
DIVESTITURES
On December 16, 2025, the Company entered into a stock purchase agreement to sell its Riello business to Ariston Group with expected gross proceeds of approximately $430 million. Riello, predominantly reported in the Company's Climate Solutions Europe segment, is a leading international manufacturer that designs, produces, and integrates a comprehensive portfolio of thermal solutions—including burners, boilers, heat pumps, cooling systems, and aftermarket services—for residential, commercial, and industrial applications, with a strong focus on energy efficiency, innovation, and a global distribution network. As a result, the assets and liabilities of Riello are presented as held for sale in the accompanying Unaudited Condensed Consolidated Balance Sheet as of March 31, 2026, and December 31, 2025, and recorded at the lower of their carrying value or fair value less estimated cost to sell. This transaction is expected to close in the first half of 2026 and is subject to customary closing conditions and regulatory approvals.

[0001783180-26-000026:notes:102]
The following table summarizes assets and liabilities classified as held for sale:

[0001783180-26-000026:notes:103]
|  | March 31, 2026 |  | December 31, 2025 |  |  |
| (In millions) | Riello |  |  |
| Cash and cash equivalents | $ | 67 |  |  | $ | 25 |  |  |  |
| Accounts receivable, net | 86 |  |  | 103 |  |  |  |
| Inventories, net | 106 |  |  | 98 |  |  |  |
| Other current assets | 2 |  |  | 2 |  |  |  |
| Fixed assets, net | 78 |  |  | 77 |  |  |  |
| Intangible assets, net | 20 |  |  | 18 |  |  |  |
| Goodwill | 171 |  |  | 175 |  |  |  |
| Operating lease right-of-use assets | 7 |  |  | 7 |  |  |  |
| Other assets | 84 |  |  | 87 |  |  |  |
| Total assets held for sale | $ | 621 |  |  | $ | 592 |  |  |  |
| Accounts payable | $ | 100 |  |  | $ | 91 |  |  |  |
| Accrued liabilities | 36 |  |  | 45 |  |  |  |
| Contract liabilities | 2 |  |  | 3 |  |  |  |
| Future pension and post-retirement obligations | 7 |  |  | 7 |  |  |  |
| Future income tax obligations | 10 |  |  | 9 |  |  |  |
| Operating lease liabilities | 4 |  |  | 4 |  |  |  |
| Other long-term liabilities | 11 |  |  | 11 |  |  |  |
| Total liabilities held for sale | $ | 170 |  |  | $ | 170 |  |  |  |

[0001783180-26-000026:notes:104]
Discontinued Operations

[0001783180-26-000026:notes:105]
During 2024, the Company exited its Fire & Security segment in multiple transactions that represented a single disposal plan to separately divest multiple businesses over different reporting periods. As a result, the components of the Fire & Security segment in aggregate met the criteria to be presented as discontinued operations in the accompanying Unaudited Condensed Consolidated Statement of Operations and Unaudited Condensed Consolidated Statement of Cash Flows. Amounts reported during 2025 and 2026 relate to retained obligations from these business divestitures.

[0001783180-26-000026:notes:106]
[same as prior period, unchanged from 0001783180-25-000066:notes:126]

[0001783180-26-000026:notes:107]
|  | Three Months Ended March 31, |  |  |
| (In millions) | 2026 |  | 2025 |  |  |  |  |
| Net sales | $ | — |  |  | $ | — |  |  |  |  |  |
| Costs of sales | — |  |  | — |  |  |  |  |  |
| Research and development | — |  |  | — |  |  |  |  |  |
| Selling, general and administrative | (1) |  |  | — |  |  |  |  |  |
| Other income (expense), net | — |  |  | — |  |  |  |  |  |
| Gain (loss) on divestitures and deconsolidation | — |  |  | — |  |  |  |  |  |
| Interest (expense) income, net | — |  |  | — |  |  |  |  |  |
| Earnings (loss) before income taxes | (1) |  |  | — |  |  |  |  |  |
| Income tax (expense) benefit | — |  |  | — |  |  |  |  |  |
| Tax on divestitures and deconsolidation | — |  |  | — |  |  |  |  |  |
| Discontinued operations, net of tax | $ | (1) |  |  | $ | — |  |  |  |  |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001783180-26-000026:notes:108]
[same as prior period, unchanged from 0001783180-25-000066:notes:133]

[0001783180-26-000026:notes:109]
[same as prior period, unchanged from 0001783180-25-000066:notes:134]

[0001783180-26-000026:notes:110]
[same as prior period, unchanged from 0001783180-25-000066:notes:135]

[0001783180-26-000026:notes:111]
[same as prior period, unchanged from 0001783180-25-000066:notes:136]

[0001783180-26-000026:notes:112]
[same as prior period, unchanged from 0001783180-25-000066:notes:137]

[0001783180-26-000026:notes:113]
[same as prior period, unchanged from 0001783180-25-000066:notes:138]

[0001783180-26-000026:notes:114]
[same as prior period, unchanged from 0001783180-25-000066:notes:139]

[0001783180-26-000026:notes:115]
[same as prior period, unchanged from 0001783180-25-000066:notes:140]

[0001783180-26-000026:notes:116]
[same as prior period, unchanged from 0001783180-25-000066:notes:141]

[0001783180-26-000026:notes:117]
|  |  | Three Months Ended March 31, 2026 |
| (In millions) |  | CSA |  | CSE |  | CSAME |  | CST |  | Segment Total |  |  |  |  |
| Net sales |  | $ | 2,501 |  |  | $ | 1,293 |  |  | $ | 834 |  |  | $ | 713 |  |  | $ | 5,341 |  |  |  |  |  |
| Cost of goods sold |  | (1,770) |  |  | (904) |  |  | (640) |  |  | (525) |  |  | (3,839) |  |  |  |  |  |
| Research and development |  | (77) |  |  | (21) |  |  | (15) |  |  | (15) |  |  | (128) |  |  |  |  |  |
| Selling, general and administrative |  | (280) |  |  | (280) |  |  | (117) |  |  | (74) |  |  | (751) |  |  |  |  |  |
| Equity method investment net earnings |  | 13 |  |  | (1) |  |  | 17 |  |  | 3 |  |  | 32 |  |  |  |  |  |
| Other income (expense), net |  | (14) |  |  | 2 |  |  | 2 |  |  | (1) |  |  | (11) |  |  |  |  |  |
| Segment operating profit |  | $ | 373 |  |  | $ | 89 |  |  | $ | 81 |  |  | $ | 101 |  |  | $ | 644 |  |  |  |  |  |

[0001783180-26-000026:notes:118]
|  |  | Three Months Ended March 31, 2025 |
| (In millions) |  | CSA |  | CSE |  | CSAME |  | CST |  | Segment Total |  |  |  |  |
| Net sales |  | $ | 2,572 |  |  | $ | 1,169 |  |  | $ | 826 |  |  | $ | 651 |  |  | $ | 5,218 |  |  |  |  |  |
| Cost of goods sold |  | (1,700) |  |  | (788) |  |  | (609) |  |  | (471) |  |  | (3,568) |  |  |  |  |  |
| Research and development |  | (86) |  |  | (18) |  |  | (15) |  |  | (16) |  |  | (135) |  |  |  |  |  |
| Selling, general and administrative |  | (250) |  |  | (257) |  |  | (112) |  |  | (69) |  |  | (688) |  |  |  |  |  |
| Equity method investment net earnings |  | 26 |  |  | (2) |  |  | 18 |  |  | 2 |  |  | 44 |  |  |  |  |  |
| Other income (expense), net |  | 8 |  |  | 1 |  |  | 13 |  |  | — |  |  | 22 |  |  |  |  |  |
| Segment operating profit |  | $ | 570 |  |  | $ | 105 |  |  | $ | 121 |  |  | $ | 97 |  |  | $ | 893 |  |  |  |  |  |

[0001783180-26-000026:notes:119]
|  |  | Three Months Ended March 31, |  |  |
| (In millions) |  | 2026 |  | 2025 |  |  |  |  |
| Reconciliation to Earnings before income taxes |  |  |  |  |  |  |  |  |
| Segment operating profit |  | $ | 644 |  |  | $ | 893 |  |  |  |  |  |
| Corporate and other |  | (50) |  |  | (45) |  |  |  |  |  |
| Restructuring costs |  | (108) |  |  | (8) |  |  |  |  |  |
| Amortization of acquired intangible assets |  | (213) |  |  | (201) |  |  |  |  |  |
| Acquisition/divestiture-related costs |  | (14) |  |  | (10) |  |  |  |  |  |
| Non-service pension (expense) benefit |  | 1 |  |  | 1 |  |  |  |  |  |
| Interest (expense) income, net |  | (90) |  |  | (82) |  |  |  |  |  |
| Earnings before income taxes |  | $ | 170 |  |  | $ | 548 |  |  |  |  |  |

[0001783180-26-000026:notes:120]
[same as prior period, unchanged from 0001783180-25-000066:notes:145]


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001783180-26-000026:notes:121]
RELATED PARTIES
Equity Method Investments

[0001783180-26-000026:notes:122]
The Company sells products to and purchases products from unconsolidated entities accounted for under the equity method and, therefore, these entities are considered to be related parties. Amounts attributable to equity method investees are as follows:

[0001783180-26-000026:notes:123]
|  |  | Three Months Ended March 31, |  |  |
| (In millions) |  | 2026 |  | 2025 |  |  |  |  |
| Sales to equity method investees included in Product sales |  | $ | 686 |  |  | $ | 780 |  |  |  |  |  |
| Purchases from equity method investees included in Cost of products sold |  | $ | 51 |  |  | $ | 47 |  |  |  |  |  |

[0001783180-26-000026:notes:124]
The Company had receivables from and payables to equity method investees as follows:

[0001783180-26-000026:notes:125]
| (In millions) |  | March 31,2026 |  | December 31,2025 |
| Receivables from equity method investees included in Accounts receivable, net |  | $ | 290 |  |  | $ | 220 |  |
| Payables to equity method investees included in Accounts payable |  | $ | 33 |  |  | $ | 40 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001783180-26-000026:notes:126]
COMMITMENTS AND CONTINGENT LIABILITIES
The Company is involved in various litigation, claims and administrative proceedings, including those related to environmental (including asbestos) and legal matters. In accordance with ASC 450, Contingencies, the Company records accruals for loss contingencies when it is probable that a liability has been incurred and the amount of the loss can be reasonably estimated. These accruals are generally based upon a range of possible outcomes. If no amount within the range is a better estimate than any other, the Company accrues the minimum amount. In addition, these estimates are reviewed periodically and adjusted to reflect additional information when it becomes available. The Company is unable to predict the final outcome of the following matters based on the information currently available, except as otherwise noted. However, the Company does not believe that the resolution of any of these matters will have a material adverse effect upon its results of operations or financial condition.

[0001783180-26-000026:notes:127]
Environmental Matters

[0001783180-26-000026:notes:128]
The Company’s operations are subject to environmental regulation by various authorities. The Company has accrued for the costs of environmental remediation activities, including but not limited to investigatory, remediation, operating and maintenance costs and performance guarantees. The most likely cost to be incurred is accrued based on an evaluation of currently available facts with respect to individual sites, including the technology required to remediate, current laws and regulations and prior remediation experience.

[0001783180-26-000026:notes:129]
The outstanding liabilities for environmental obligations are as follows:

[0001783180-26-000026:notes:130]
| (In millions) |  | March 31,2026 |  | December 31,2025 |
| Environmental reserves included in Accrued liabilities |  | $ | 17 |  |  | $ | 18 |  |
| Environmental reserves included in Other long-term liabilities |  | 181 |  |  | 182 |  |
| Total Environmental reserves |  | $ | 198 |  |  | $ | 200 |  |

[0001783180-26-000026:notes:131]
For sites with multiple responsible parties, the Company considers its likely proportionate share of the anticipated remediation costs and the ability of other parties to fulfill their obligations in establishing a provision for these costs. Accrued environmental liabilities are not reduced by potential insurance reimbursements and are undiscounted.

[0001783180-26-000026:notes:132]
Asbestos Matters

[0001783180-26-000026:notes:133]
The Company has been named as a defendant in lawsuits alleging personal injury as a result of exposure to asbestos allegedly integrated into certain Carrier products or business premises. While the Company has never manufactured asbestos and no longer incorporates it into any currently-manufactured products, certain products that the Company no longer manufactures contained components incorporating asbestos. A substantial majority of these asbestos-related claims have been dismissed without payment or have been covered in full or in part by insurance or other forms of indemnity. Additional cases were litigated and settled without any insurance reimbursement. The amounts involved in asbestos-related claims were not material individually or in the aggregate in any period.

[0001783180-26-000026:notes:134]
The Company's asbestos liabilities and related insurance recoveries are as follows:

[0001783180-26-000026:notes:135]
| (In millions) |  | March 31,2026 |  | December 31,2025 |
| Asbestos liabilities included in Accrued liabilities |  | $ | 17 |  |  | $ | 17 |  |
| Asbestos liabilities included in Other long-term liabilities |  | 195 |  |  | 201 |  |
| Total Asbestos liabilities |  | $ | 212 |  |  | $ | 218 |  |
| Asbestos-related recoveries included in Other current assets |  | $ | 6 |  |  | $ | 6 |  |
| Asbestos-related recoveries included in Other assets |  | 85 |  |  | 86 |  |
| Total Asbestos-related recoveries |  | $ | 91 |  |  | $ | 92 |  |

[0001783180-26-000026:notes:136]
The amounts recorded for asbestos-related liabilities are based on currently available information and assumptions that the Company believes are reasonable and are made with input from outside actuarial experts. These amounts are undiscounted and exclude the Company’s legal fees to defend the asbestos claims, which are expensed as incurred. In addition, the Company has recorded insurance recovery receivables for probable asbestos-related recoveries.

[0001783180-26-000026:notes:137]
Aqueous Film Forming Foam Litigation

[0001783180-26-000026:notes:138]
As of March 31, 2026, the Company, Kidde-Fenwal, Inc. ("KFI") and others have been named as defendants in more than 17,000 lawsuits filed in United States state or federal courts and a single case in Canada alleging that the historic use of Aqueous Film Forming Foam ("AFFF") caused personal injuries and damage to property and water supplies. In December 2018, the U.S. Judicial Panel on Multidistrict Litigation transferred and consolidated all AFFF cases pending in the U.S. federal courts against the Company, KFI and others to the U.S. District Court for the District of South Carolina (the "MDL Proceedings"). In 2013, KFI divested the AFFF businesses to an unrelated third party. The Company acquired KFI as part of the Separation in April 2020.

[0001783180-26-000026:notes:139]
On May 14, 2023, KFI filed a voluntary petition with the United States Bankruptcy Court for the District of Delaware (the “Bankruptcy Court”) seeking relief under chapter 11 of the Bankruptcy Code, after the Company determined that it would not provide financial support to KFI going forward other than ensuring KFI has access to services necessary for the effective operation of its business. As a result, all litigation against KFI was automatically stayed. By agreement, all AFFF-related litigation against the Company, its other subsidiaries and RTX also was stayed. On November 21, 2023, the Bankruptcy Court ordered certain parties, including the Company, to participate in mediation sessions with respect to claims that might be asserted by and against it in the bankruptcy proceedings.

[0001783180-26-000026:notes:140]
Following the conclusion of these mediation sessions in October 2024, the Company entered into a Settlement and Plan Support Agreement which contemplates that the Company will subsequently enter into three distinct settlement agreements (collectively, the “Proposed Settlement Agreements”) with KFI, the Official Committee of Unsecured Creditors appointed in KFI’s bankruptcy case (the “Committee”) and the Plaintiffs’ Executive Committee (the “MDL PEC”) appointed in the MDL Proceedings.

[0001783180-26-000026:notes:141]
The first of the Proposed Settlement Agreements relates to claims that the Company is responsible for liabilities arising from KFI’s manufacture or sale of AFFF (“Estate Claims Settlement”). Upon Bankruptcy Court approval, the Estate Claims Settlement will permanently resolve all present and future claims that the Company is responsible for any liabilities of KFI, including all liabilities arising from KFI’s manufacture and sale of AFFF. The second and third of the Proposed Settlement Agreements release a very substantial amount of current and future direct claims against the Company (the “Direct Claims Settlements”). Direct claims allege that UTC, which indirectly owned KFI’s AFFF business for eight years, engaged in conduct independent of KFI that caused harm to AFFF claimants. The Company agreed to indemnify UTC for these direct claims when it was spun-off from UTC. Upon approval by the MDL Court, the Direct Claims Settlements resolve and enjoin all current and future AFFF-related direct claims against the Company by participating public water providers and airports. Non-settling parties may still assert direct AFFF-related claims, although we expect a vast majority of public water providers and airports will participate in the Direct Claims Settlements.

[0001783180-26-000026:notes:142]
As part of the Proposed Settlement Agreements, the Company will pay $615 million in cash over five years, 100% of the net sale proceeds from its sale of KFI’s assets to Pacific Avenue Capital Partners, which are estimated to be $115 million, and contribute the right to recover proceeds under certain of its insurance policies. The Company will be entitled to receive up to $2.4 billion of proceeds from those insurance policies and will contribute the first $125 million of such proceeds as additional consideration in the Direct Claims Settlements. The Company also will be entitled to any earnouts payable to KFI under the KFI sale agreement. The Company expects insurance payments it receives in the future, in the aggregate, to cover the amount paid under the Proposed Settlement Agreements. As a result of the Proposed Settlement Agreements, the Company recorded a liability in the amount of $565 million during 2024. The amount recognized is in addition to liabilities of $50 million that the Company recorded upon the deconsolidation of KFI on May 14, 2023, as further discussed below. As of March 31, 2026, the Company has not recorded any amounts associated with expected insurance proceeds.

[0001783180-26-000026:notes:143]
The Company and KFI believe that they have meritorious defenses to the remaining AFFF claims. Given the numerous factual, scientific and legal issues to be resolved relating to these claims, the Company is unable to assess the probability of liability or to reasonably estimate a range of possible loss at this time. There can be no assurance that any such future exposure will not be material in any period.

[0001783180-26-000026:notes:144]
On November 14, 2024, KFI filed the chapter 11 plan of liquidation (as may be further amended, restated, supplemented, waived, or otherwise modified from time to time, the "Chapter 11 Plan"), which incorporates the Estate Claims Settlement, provides for the treatment of the various creditor classes, and establishes wind-down provisions, among other things, and the disclosure statement for the Chapter 11 Plan (as may be further amended, restated, supplemented, waived, or otherwise modified from time to time, the "Disclosure Statement"). A hearing to approve the Disclosure Statement was held in June 2025. A revised and supplemented Disclosure Statement was filed on August 15, 2025. The Bankruptcy Court held a hearing on that statement on October 6, 2025. Following that hearing, the Bankruptcy Court ordered that the revised and supplemented Disclosure Statement be modified further in two areas, which the parties are addressing.

[0001783180-26-000026:notes:145]
Antitrust Litigation

[0001783180-26-000026:notes:146]
Beginning in March 2026, the Company, along with several other HVAC manufacturers, has been named as a defendant in putative class-action lawsuits alleging violations of federal and state antitrust laws on behalf of direct and indirect purchasers of HVAC equipment. These lawsuits are currently pending in the United States District Court for the Eastern District of Michigan and generally allege that the Company and other industry participants have engaged in an unlawful agreement to fix or raise the prices of certain HVAC products in the United States since January 1, 2020. The lawsuits seek damages, including treble damages under federal and state antitrust statutes, as well as injunctive relief and attorneys’ fees. The Company believes the allegations in these lawsuits lack merit and that it has meritorious defenses to the alleged claims. At this time, the Company is unable to assess the probability of liability or to reasonably estimate a range of possible loss. There can be no assurance that any future exposure will not be material in any period.

[0001783180-26-000026:notes:147]
Income Taxes

[0001783180-26-000026:notes:148]
Under the TMA relating to the Separation, the Company is responsible to UTC for its share of the Tax Cuts and Jobs Act transition tax associated with foreign undistributed earnings as of December 31, 2017. As a result, a liability of $101 million is included within the accompanying Unaudited Condensed Consolidated Balance Sheet within Accrued liabilities as of March 31, 2026. This obligation was settled in April 2026.

[0001783180-26-000026:notes:149]
Other

[0001783180-26-000026:notes:150]
The Company has other commitments and contingent liabilities related to legal proceedings, self-insurance programs and matters arising in the ordinary course of business. The Company accrues for contingencies generally based upon a range of possible outcomes. If no amount within the range is a better estimate than any other, the Company accrues the minimum amount.

[0001783180-26-000026:notes:151]
In the ordinary course of business, the Company is also routinely a defendant in, party to or otherwise subject to many pending and threatened legal actions, claims, disputes and proceedings. These matters are often based on alleged violations of contract, product liability, warranty, regulatory, environmental, health and safety, employment, intellectual property, tax and other laws. In some of these proceedings, claims for substantial monetary damages are asserted against the Company and could result in fines, penalties, compensatory or treble damages or non-monetary relief. The Company does not believe that these matters will have a material adverse effect upon its results of operations, cash flows or financial condition.
