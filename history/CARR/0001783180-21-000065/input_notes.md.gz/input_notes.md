# CARR notes — 0001783180-21-000065


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001783180-21-000065:notes:1]
[same as prior period, unchanged from 0001783180-21-000050:notes:1]

[0001783180-21-000065:notes:2]
[same as prior period, unchanged from 0001783180-21-000050:notes:2]

[0001783180-21-000065:notes:3]
In connection with the Separation, the Company entered into several agreements with UTC and Otis Worldwide Corporation ("Otis") that govern various aspects of the relationship among the Company, UTC and Otis following the Separation and the Distribution, including a transition services agreement ("TSA"), a tax matters agreement ("TMA"), an employee matters agreement and an intellectual property agreement that cover services such as information technology, tax, finance and human resources. In addition, the Company incurred separation-related costs including employee-related costs, costs to establish certain stand-alone functions, information technology systems, professional service fees and other costs associated with becoming an independent, publicly traded company. These costs are primarily recorded in Selling, general and administrative in the Unaudited Condensed Consolidated Statement of Operations and totaled $24 million for the three months ended September 30, 2020. Costs for the nine months ended September 30, 2021 and 2020 were $19 million and $92 million, respectively. The TSA expired on March 31, 2021.

[0001783180-21-000065:notes:4]
[same as prior period, unchanged from 0001783180-21-000050:notes:4]

[0001783180-21-000065:notes:5]
In early 2020, the World Health Organization declared the outbreak of a respiratory disease known as COVID-19 as a global pandemic. In response, many countries implemented containment and mitigation measures to combat the outbreak, which severely restricted the level of economic activity and caused a significant contraction in the global economy. As a result, the Company temporarily closed or reduced production at manufacturing facilities across the globe to ensure employee safety and instructed non-essential employees to work from home. In addition, the Company took several preemptive actions during 2020 to manage liquidity as demand for its products decreased. Despite the adverse impacts of the pandemic on the Company’s results beginning in the first quarter of 2020, manufacturing operations resumed and several restorative actions were completed during 2020, including the reinstatement of annual merit-based salary increases and continued investment to support the Company's strategic priorities.

[0001783180-21-000065:notes:6]
The Company continues to focus its efforts on preserving the health and safety of its employees and customers as well as maintaining the continuity of its operations. In addition, the Company continues to actively monitor its liquidity position and working capital needs and believes that its overall capital resources and liquidity position are adequate. The preparation of financial statements requires management to use judgments in making estimates and assumptions based on the relevant information available at the end of each period, which can have a significant effect on reported amounts. However, due to significant uncertainty surrounding the pandemic, including a resurgence in cases and the spread of COVID-19 variants, management's judgments could change. While the Company's results of operations, cash flows and financial condition could be negatively impacted, the extent of any continuing impact cannot be estimated with certainty at this time.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001783180-21-000065:notes:7]
BASIS OF PRESENTATION
The Unaudited Condensed Consolidated Financial Statements include all accounts of the Company and its wholly-owned and majority-owned subsidiaries in which it has control. All intra-company accounts and transactions have been eliminated. Related party transactions between the Company and its equity method investees have not been eliminated. Non-controlling interest represents a non-controlling investor's interests in the results of subsidiaries that the Company controls and consolidates.

[0001783180-21-000065:notes:8]
The Company's financial statements for the periods prior to the Separation and the Distribution are prepared on a "carve-out" basis and include all amounts directly attributable to the Company. Net cash transfers and other property transferred between UTC and the Company, including related party receivables and payables between the Company and other UTC affiliates, are presented as Net transfers to UTC. In addition, the financial statements include allocations of costs for administrative functions and services performed on behalf of the Company by centralized groups within UTC. All allocations and estimates in the Unaudited Condensed Consolidated Financial Statements are based on assumptions that management believes are reasonable. The Company's financial statements for the periods subsequent to April 3, 2020 are consolidated financial statements based on the reported results of Carrier as a stand-alone company.

[0001783180-21-000065:notes:9]
Held for Sale

[0001783180-21-000065:notes:10]
On July 26, 2021, the Company entered into a stock purchase agreement to sell its Chubb Fire and Security business ("Chubb") to APi Group Corporation ("APi"). The transaction is expected to close late in the fourth quarter of 2021 or early in the first quarter of 2022, subject to regulatory approvals, required works council approval in France and customary closing conditions. In accordance with U.S. GAAP, the assets and liabilities of Chubb have been classified as held for sale on the accompanying Unaudited Condensed Consolidated Balance Sheet as of September 30, 2021 and recorded at the lower of their carrying value or fair value less estimated cost to sell. See Note 16 - Divestitures for additional information.

[0001783180-21-000065:notes:11]
Recently Adopted Accounting Pronouncements

[0001783180-21-000065:notes:12]
[same as prior period, unchanged from 0001783180-21-000050:notes:10]

[0001783180-21-000065:notes:13]
In December 2019, the FASB issued ASU 2019-12, Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes ("ASU 2019-12"), which simplifies certain aspects of income tax accounting guidance in ASC 740, Income Taxes ("ASC 740") reducing the complexity of its application while maintaining or improving the usefulness of the information required to be reported. The ASU eliminates certain exceptions from ASC 740 including: intra-period tax allocation, deferred tax liabilities related to outside basis differences and year-to-date loss in interim periods, among others. ASU 2019-12 was effective for periods beginning after December 15, 2020, including interim periods therein with early adoption permitted. The Company adopted this ASU on January 1, 2021 with no material impact on the Unaudited Condensed Consolidated Financial Statements.


## us-gaap:InventoryDisclosureTextBlock

[0001783180-21-000065:notes:14]
[same as prior period, unchanged from 0001783180-21-000050:notes:12]

[0001783180-21-000065:notes:15]
[same as prior period, unchanged from 0001783180-21-000050:notes:13]

[0001783180-21-000065:notes:16]
| (In millions) |  | September 30,2021 |  | December 31,2020 |
| Raw materials |  | $ | 521 |  |  | $ | 363 |  |
| Work-in-process |  | 203 |  |  | 143 |  |
| Finished goods |  | 1,202 |  |  | 1,123 |  |
| Inventories, net |  | $ | 1,926 |  |  | $ | 1,629 |  |

[0001783180-21-000065:notes:17]
The Company performs periodic assessments to determine the existence of excess and obsolete inventory and records necessary provisions to reduce such inventories to estimated realizable value. Raw materials, work-in-process and finished goods are net of valuation reserves of $165 million and $183 million as of September 30, 2021 and December 31, 2020, respectively.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001783180-21-000065:notes:18]
GOODWILL AND INTANGIBLE ASSETS 
The Company records goodwill as the excess of the purchase price over the fair value of the net assets acquired in a business combination. Goodwill is tested and reviewed annually for impairment on July 1 or whenever there is a material change in events or circumstances that indicates that the fair value of the reporting unit may be less than its carrying value.

[0001783180-21-000065:notes:19]
The changes in the carrying amount of goodwill are as follows:

[0001783180-21-000065:notes:20]
| (In millions) |  |  | HVAC |  | Refrigeration |  | Fire & Security |  | Total |
| Balance as of December 31, 2020 |  |  | $ | 5,489 |  |  | $ | 1,251 |  |  | $ | 3,399 |  |  | $ | 10,139 |  |
| Goodwill resulting from business combinations (1) |  |  | 180 |  |  | (1) |  |  | — |  |  | 179 |  |
| Reclassified as Assets held for sale (2) |  |  | — |  |  | — |  |  | (936) |  |  | (936) |  |
| Foreign currency translation |  |  | (78) |  |  | (19) |  |  | (48) |  |  | (145) |  |
| Balance as of September 30, 2021 |  |  | $ | 5,591 |  |  | $ | 1,231 |  |  | $ | 2,415 |  |  | $ | 9,237 |  |

[0001783180-21-000065:notes:21]
(1) See Note 15 - Acquisitions for additional information

[0001783180-21-000065:notes:22]
(2) See Note 16 - Divestitures for additional information

[0001783180-21-000065:notes:23]
[same as prior period, unchanged from 0001783180-21-000050:notes:19]

[0001783180-21-000065:notes:24]
[same as prior period, unchanged from 0001783180-21-000050:notes:20]

[0001783180-21-000065:notes:25]
|  |  | September 30, 2021 |  | December 31, 2020 |
| (In millions) |  | Gross Amount |  | Accumulated Amortization |  | Net Amount (1) |  | Gross Amount |  | Accumulated Amortization |  | Net Amount |
| Amortized: |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 924 |  |  | $ | (684) |  |  | $ | 240 |  |  | $ | 1,558 |  |  | $ | (1,285) |  |  | $ | 273 |  |
| Patents and trademarks |  | 230 |  |  | (179) |  |  | 51 |  |  | 301 |  |  | (222) |  |  | 79 |  |
| Monitoring lines |  | — |  |  | — |  |  | — |  |  | 71 |  |  | (59) |  |  | 12 |  |
| Service portfolios and other |  | 662 |  |  | (536) |  |  | 126 |  |  | 644 |  |  | (542) |  |  | 102 |  |
|  |  | 1,816 |  |  | (1,399) |  |  | 417 |  |  | 2,574 |  |  | (2,108) |  |  | 466 |  |
| Unamortized: |  |  |  |  |  |  |  |  |  |  |  |  |
| Trademarks and other |  | 64 |  |  | — |  |  | 64 |  |  | 571 |  |  | — |  |  | 571 |  |
| Intangible assets, net |  | $ | 1,880 |  |  | $ | (1,399) |  |  | $ | 481 |  |  | $ | 3,145 |  |  | $ | (2,108) |  |  | $ | 1,037 |  |

[0001783180-21-000065:notes:26]
(1) See Note 16 - Divestitures for additional information

[0001783180-21-000065:notes:27]
Amortization of intangible assets was $25 million and $26 million for the three months ended September 30, 2021 and 2020, respectively, and $74 million and $76 million for the nine months ended September 30, 2021 and 2020, respectively.

[0001783180-21-000065:notes:28]
Annual Impairment Assessment

[0001783180-21-000065:notes:29]
The Company tested its goodwill and indefinite-lived intangible assets for impairment as part of its annual assessment. For each test, the Company qualitatively assessed all relevant events or circumstances that could impact the estimate of fair value and determined that it was more likely than not that the fair value of any asset exceeded its carrying amount.


## us-gaap:DebtDisclosureTextBlock

[0001783180-21-000065:notes:30]
BORROWINGS AND LINES OF CREDIT 
Long-term debt consisted of the following:

[0001783180-21-000065:notes:31]
| (In millions) |  |  |  | September 30,2021 |  | December 31,2020 |
| 1.923% Notes due February 15, 2023 |  |  |  | $ | — |  | (1) | $ | 500 |  |
| 2.242% Notes due February 15, 2025 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.493% Notes due February 15, 2027 |  |  |  | 1,250 |  |  | 1,250 |  |
| 2.722% Notes due February 15, 2030 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.700% Notes due February 15, 2031 |  |  |  | 750 |  |  | 750 |  |
| 3.377% Notes due April 5, 2040 |  |  |  | 1,500 |  |  | 1,500 |  |
| 3.577% Notes due April 5, 2050 |  |  |  | 2,000 |  |  | 2,000 |  |
| Total long-term Notes |  |  |  | 9,500 |  |  | 10,000 |  |
| Other debt (including project financing obligations and finance leases) |  |  |  | 261 |  |  | 308 |  |
| Discounts and debt issuance costs |  |  |  | (73) |  |  | (81) |  |
| Total debt |  |  |  | 9,688 |  |  | 10,227 |  |
| Less: current portion of long-term debt |  |  |  | 130 |  |  | 191 |  |
| Long-term debt, net of current portion |  |  |  | $ | 9,558 |  |  | $ | 10,036 |  |

[0001783180-21-000065:notes:32]
(1) In February 2021, the Company prepaid the 1.923% Notes due in February 2023 and incurred a $17 million make-whole premium upon prepayment and wrote-off $2 million of the remaining unamortized deferred financing costs

[0001783180-21-000065:notes:33]
Revolving Credit Facility

[0001783180-21-000065:notes:34]
On February 10, 2020, the Company entered into a revolving credit agreement with various banks permitting aggregate borrowings of up to $2.0 billion pursuant to an unsecured, unsubordinated revolving credit facility that matures on April 3, 2025 (the "Revolving Credit Facility"). The Revolving Credit Facility supports the Company's commercial paper program and cash requirements of the Company. A commitment fee of 0.125% is charged on unused commitments. Borrowings under the Revolving Credit Facility are available in U.S. Dollars, Euros and Pounds Sterling and bear interest at a variable interest rate based on LIBOR plus a ratings-based margin, which was 125 basis points as of September 30, 2021. As of September 30, 2021, there were no borrowings outstanding under the Revolving Credit Facility.

[0001783180-21-000065:notes:35]
Commercial Paper Program

[0001783180-21-000065:notes:36]
As of September 30, 2021, the Company had a $2.0 billion unsecured, unsubordinated commercial paper program, which can be used for general corporate purposes, including the funding of working capital and potential acquisitions. As of September 30, 2021, there were no borrowings outstanding under the commercial paper program.

[0001783180-21-000065:notes:37]
Project Financing Arrangements

[0001783180-21-000065:notes:38]
The Company is involved in several long-term construction contracts in which it arranges project financing with certain customers. As a result, the Company issued $108 million and $102 million of debt during the nine months ended September 30, 2021 and 2020, respectively. Long-term debt repayments associated with these financing arrangements during the nine months ended September 30, 2021 and 2020 were $170 million and $124 million, respectively.

[0001783180-21-000065:notes:39]
Debt Covenants

[0001783180-21-000065:notes:40]
The Revolving Credit Facility and the indenture for the long-term notes contain affirmative and negative covenants customary for financings of these types which, among other things, limit the Company's ability to incur additional liens, to make certain fundamental changes and to enter into sale and leaseback transactions. On June 2, 2020, the Company entered into an amendment of the Revolving Credit Facility, under which certain terms of the facility were amended for a period beginning on June 2, 2020 and ending on December 30, 2021 (the "Covenant Modification"). The Company terminated the Covenant Modification effective as of August 27, 2021 in accordance with the procedure for termination set forth in the revolving credit agreement, which returned the consolidated leverage ratio covenant to the limit in effect prior to the Covenant Modification. As 
of September 30, 2021, the Company was in compliance with the covenants under the agreements governing its outstanding indebtedness.


## us-gaap:FairValueDisclosuresTextBlock

[0001783180-21-000065:notes:41]
[same as prior period, unchanged from 0001783180-21-000050:notes:34]

[0001783180-21-000065:notes:42]
[same as prior period, unchanged from 0001783180-21-000050:notes:35]

[0001783180-21-000065:notes:43]
[same as prior period, unchanged from 0001783180-21-000050:notes:36]

[0001783180-21-000065:notes:44]
[same as prior period, unchanged from 0001783180-21-000050:notes:37]

[0001783180-21-000065:notes:45]
[same as prior period, unchanged from 0001783180-21-000050:notes:38]

[0001783180-21-000065:notes:46]
[same as prior period, unchanged from 0001783180-21-000050:notes:39]

[0001783180-21-000065:notes:47]
| (In millions) |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |
| September 30, 2021 |  |  |  |  |  |  |  |  |  |
| Derivative assets |  | $ | 10 |  | (1) |  | $ | — |  |  | $ | 10 |  |  | $ | — |  |
| Derivative liabilities |  | $ | (4) |  | (2) |  | $ | — |  |  | $ | (4) |  |  | $ | — |  |
| December 31, 2020 |  |  |  |  |  |  |  |  |  |
| Derivative assets |  | $ | 17 |  | (1) |  | $ | — |  |  | $ | 17 |  |  | $ | — |  |
| Derivative liabilities |  | $ | (5) |  | (2) |  | $ | — |  |  | $ | (5) |  |  | $ | — |  |

[0001783180-21-000065:notes:48]
(1) Included in Other assets, current on the accompanying Unaudited Condensed Consolidated Balance Sheet

[0001783180-21-000065:notes:49]
(2) Included in Accrued liabilities on the accompanying Unaudited Condensed Consolidated Balance Sheet

[0001783180-21-000065:notes:50]
[same as prior period, unchanged from 0001783180-21-000050:notes:43]

[0001783180-21-000065:notes:51]
|  |  | September 30, 2021 |  | December 31, 2020 |  |
| (In millions) |  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  |
| Total Long-term Notes (1) |  | $ | 9,500 |  |  | $ | 9,960 |  |  | $ | 10,000 |  |  | $ | 10,811 |  |  |

[0001783180-21-000065:notes:52]
[same as prior period, unchanged from 0001783180-21-000050:notes:45]

[0001783180-21-000065:notes:53]
The carrying value of cash and cash equivalents, accounts receivable, accounts payable and short-term borrowings approximate fair value due to the short-term nature of these accounts and would be classified as Level 1 in the fair value hierarchy. The Company's financing leases and project financing obligations, included in Long-term debt, approximate fair value and are classified as Level 3 in the fair value hierarchy.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001783180-21-000065:notes:54]
[same as prior period, unchanged from 0001783180-21-000050:notes:47]

[0001783180-21-000065:notes:55]
[same as prior period, unchanged from 0001783180-21-000050:notes:48]

[0001783180-21-000065:notes:56]
|  |  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
| (In millions) |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Defined benefit plans |  | $ | 2 |  |  | $ | 1 |  |  | $ | 29 |  |  | $ | 29 |  |
| Defined contribution plans |  | $ | 30 |  |  | $ | 23 |  |  | $ | 97 |  |  | $ | 78 |  |
| Multi-employer pension plans |  | $ | 5 |  |  | $ | 5 |  |  | $ | 17 |  |  | $ | 15 |  |

[0001783180-21-000065:notes:57]
[same as prior period, unchanged from 0001783180-21-000050:notes:50]

[0001783180-21-000065:notes:58]
|  |  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
| (In millions) |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Service cost |  | $ | 7 |  |  | $ | 7 |  |  | $ | 21 |  |  | $ | 22 |  |
| Interest cost |  | 9 |  |  | 13 |  |  | 28 |  |  | 39 |  |
| Expected return on plan assets |  | (36) |  |  | (35) |  |  | (109) |  |  | (104) |  |
| Amortization of prior service credit |  | — |  |  | 1 |  |  | 1 |  |  | 2 |  |
| Recognized actuarial net (gain) loss |  | 8 |  |  | 5 |  |  | 24 |  |  | 15 |  |
| Net settlement, curtailment and special termination benefit (gain) loss |  | 4 |  |  | — |  |  | 4 |  |  | 1 |  |
| Net periodic pension expense (benefit) |  | $ | (8) |  |  | $ | (9) |  |  | $ | (31) |  |  | $ | (25) |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001783180-21-000065:notes:59]
[same as prior period, unchanged from 0001783180-21-000050:notes:52]

[0001783180-21-000065:notes:60]
The Company accounts for stock-based compensation plans in accordance with ASC 718, Compensation - Stock Compensation, which requires a fair-value based method for measuring the value of stock-based compensation. Fair value is measured at the date of grant and is generally not adjusted for subsequent changes. The Company's stock-based compensation plans include programs for stock appreciation rights, restricted stock units and performance share units.

[0001783180-21-000065:notes:61]
Stock-based compensation expense is included in Cost of products sold, Selling, general and administrative and Research and development in the accompanying Unaudited Condensed Consolidated Statements of Operations. The expense recognized was as follows:

[0001783180-21-000065:notes:62]
|  |  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
| (in millions) |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Equity settled |  | $ | 21 |  |  | $ | 21 |  |  | $ | 60 |  |  | $ | 56 |  |
| Cash settled |  | 5 |  |  | 5 |  |  | 15 |  |  | 2 |  |
| Total stock-based compensation expense |  | $ | 26 |  |  | $ | 26 |  |  | $ | 75 |  |  | $ | 58 |  |

[0001783180-21-000065:notes:63]
Prior to the Separation and the Distribution, the Company participated in UTC's long-term incentive plans, which authorized various types of market and performance-based incentive awards. For these periods, stock-based compensation expense was allocated to the Company from UTC based upon direct employee headcount. In connection with the Separation and the Distribution, all awards were converted into Carrier stock-based awards with unvested awards converted to preserve their intrinsic value immediately before and after the Separation.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001783180-21-000065:notes:64]
[same as prior period, unchanged from 0001783180-21-000050:notes:57]

[0001783180-21-000065:notes:65]
|  |  | For the Nine Months Ended September 30, |
| (In millions) |  | 2021 |  | 2020 |
| Balance as of January 1, |  | $ | 514 |  |  | $ | 488 |  |
| Warranties, performance guarantees issued and changes in estimated liability |  | 136 |  |  | 131 |  |
| Settlements made |  | (127) |  |  | (111) |  |
| Other |  | 1 |  |  | 1 |  |
| Balance as of September 30, |  | $ | 524 |  |  | $ | 509 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001783180-21-000065:notes:66]
EQUITY 
The authorized number of shares of common stock of Carrier is 4,000,000,000 shares of $0.01 par value. As of September 30, 2021, 872,324,594 shares of common stock were issued, which includes 5,705,590 shares of treasury stock.

[0001783180-21-000065:notes:67]
[same as prior period, unchanged from 0001783180-21-000050:notes:60]

[0001783180-21-000065:notes:68]
In July 2021, the Company's Board of Directors authorized a $1.75 billion increase to the Company's existing $350 million stock repurchase program. This program allows the Company to repurchase its outstanding common stock from time to time subject to market conditions and at the Company's discretion in the open market or through one or more other public or private transactions and subject to compliance with the Company's obligations under the TMA. The Company records repurchases under the cost method whereby the entire cost of the acquired stock is recorded as Treasury stock as a reduction to equity. The reissuance of treasury stock uses the first-in, first-out method of accounting.

[0001783180-21-000065:notes:69]
The Company repurchased 2.7 million shares and 5.7 million shares of common stock for an aggregate purchase price of $146 million and $276 million for the three and nine months ended September 30, 2021, respectively, which are held in Treasury stock as of September 30, 2021 as reflected on its Unaudited Condensed Consolidated Balance Sheet.

[0001783180-21-000065:notes:70]
[same as prior period, unchanged from 0001783180-21-000050:notes:63]

[0001783180-21-000065:notes:71]
A summary of changes in the components of Accumulated other comprehensive income (loss) for the three months ended September 30, 2021 and 2020 is as follows:

[0001783180-21-000065:notes:72]
| (In millions) |  | Foreign Currency Translation |  | Defined Benefit Pension and Post-retirement Plans |  |  |  |  |  | Accumulated Other Comprehensive Income (Loss) |
| Balance as of June 30, 2021 |  | $ | (253) |  |  | $ | (541) |  |  |  |  |  |  | $ | (794) |  |
| Other comprehensive income (loss) before reclassifications, net |  | (203) |  |  | — |  |  |  |  |  |  | (203) |  |
| Amounts reclassified, pre-tax |  | — |  |  | 8 |  |  |  |  |  |  | 8 |  |
| Tax expense (benefit) reclassified |  | — |  |  | (2) |  |  |  |  |  |  | (2) |  |
| Balance as of September 30, 2021 |  | $ | (456) |  |  | $ | (535) |  |  |  |  |  |  | $ | (991) |  |

[0001783180-21-000065:notes:73]
| (In millions) |  | Foreign Currency Translation |  | Defined Benefit Pension and Post-retirement Plans |  |  |  |  |  | Accumulated Other Comprehensive Income (Loss) |
| Balance as of June 30, 2020 |  | $ | (1,018) |  |  | $ | (461) |  |  |  |  |  |  | $ | (1,479) |  |
| Other comprehensive income (loss) before reclassifications, net |  | 302 |  |  | — |  |  |  |  |  |  | 302 |  |
| Amounts reclassified, pre-tax |  | — |  |  | 6 |  |  |  |  |  |  | 6 |  |
| Tax expense (benefit) reclassified |  | — |  |  | (1) |  |  |  |  |  |  | (1) |  |
| Balance as of September 30, 2020 |  | $ | (716) |  |  | $ | (456) |  |  |  |  |  |  | $ | (1,172) |  |

[0001783180-21-000065:notes:74]
A summary of changes in the components of Accumulated other comprehensive income (loss) for the nine months ended September 30, 2021 and 2020 is as follows:

[0001783180-21-000065:notes:75]
| (In millions) | Foreign Currency Translation |  | Defined Benefit Pension and Post-retirement Plans |  |  |  |  |  | Accumulated Other Comprehensive Income (Loss) |
| Balance as of December 31, 2020 | $ | (191) |  |  | $ | (554) |  |  |  |  |  |  | $ | (745) |  |
| Other comprehensive income (loss) before reclassifications, net | (265) |  |  | — |  |  |  |  |  |  | (265) |  |
| Amounts reclassified, pre-tax | — |  |  | 25 |  |  |  |  |  |  | 25 |  |
| Tax expense reclassified | — |  |  | (6) |  |  |  |  |  |  | (6) |  |
| Balance as of September 30, 2021 | $ | (456) |  |  | $ | (535) |  |  |  |  |  |  | $ | (991) |  |

[0001783180-21-000065:notes:76]
| (In millions) | Foreign Currency Translation |  | Defined Benefit Pension and Post-retirement Plans |  |  |  |  |  | Accumulated Other Comprehensive Income (Loss) |
| Balance as of December 31, 2019 | $ | (780) |  |  | $ | (473) |  |  |  |  |  |  | $ | (1,253) |  |
| Other comprehensive income (loss) before reclassifications, net | 64 |  |  | 2 |  |  |  |  |  |  | 66 |  |
| Amounts reclassified, pre-tax | — |  |  | 18 |  |  |  |  |  |  | 18 |  |
| Tax expense reclassified | — |  |  | (3) |  |  |  |  |  |  | (3) |  |
| Balance as of September 30, 2020 | $ | (716) |  |  | $ | (456) |  |  |  |  |  |  | $ | (1,172) |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001783180-21-000065:notes:77]
REVENUE RECOGNITION The Company recognizes revenue when control of a good or service promised in a contract (i.e., performance obligation) is transferred to a customer. Control is obtained when a customer has the ability to direct the use of and obtain substantially all of the remaining benefit from that good or service. A significant portion of the Company's performance obligations are recognized at a point-in-time when control of the product transfers to the customer, which is generally at the time of shipment. The remaining portion of the Company's performance obligations are recognized over time as the customer simultaneously obtains control as the Company performs work under a contract, or if the product being produced for the customer has no alternative use and the Company has a contractual right to payment. 
Sales disaggregated by product and service are as follows:

[0001783180-21-000065:notes:78]
|  |  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
| (In millions) |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Sales Type |  |  |  |  |  |  |  |  |
| Product |  | $ | 2,702 |  |  | $ | 2,547 |  |  | $ | 7,606 |  |  | $ | 6,180 |  |
| Service |  | 352 |  |  | 345 |  |  | 1,054 |  |  | 962 |  |
| HVAC sales |  | 3,054 |  |  | 2,892 |  |  | 8,660 |  |  | 7,142 |  |
| Product |  | 894 |  |  | 771 |  |  | 2,701 |  |  | 2,093 |  |
| Service |  | 117 |  |  | 105 |  |  | 336 |  |  | 291 |  |
| Refrigeration sales |  | 1,011 |  |  | 876 |  |  | 3,037 |  |  | 2,384 |  |
| Product |  | 1,012 |  |  | 965 |  |  | 2,943 |  |  | 2,587 |  |
| Service |  | 365 |  |  | 359 |  |  | 1,141 |  |  | 1,000 |  |
| Fire & Security sales |  | 1,377 |  |  | 1,324 |  |  | 4,084 |  |  | 3,587 |  |
| Total segment sales |  | 5,442 |  |  | 5,092 |  |  | 15,781 |  |  | 13,113 |  |
| Eliminations and other |  | (101) |  |  | (90) |  |  | (301) |  |  | (251) |  |
| Net sales |  | $ | 5,341 |  |  | $ | 5,002 |  |  | $ | 15,480 |  |  | $ | 12,862 |  |

[0001783180-21-000065:notes:79]
[same as prior period, unchanged from 0001783180-21-000050:notes:72]

[0001783180-21-000065:notes:80]
[same as prior period, unchanged from 0001783180-21-000050:notes:73]

[0001783180-21-000065:notes:81]
| (In millions) |  | September 30,2021 |  | December 31,2020 |
| Contract assets, current |  | $ | 502 |  |  | $ | 656 |  |
| Contract assets, non-current (included within Other assets) |  | 119 |  |  | 98 |  |
| Total contract assets |  | 621 |  |  | 754 |  |
| Contract liabilities, current |  | 418 |  |  | 512 |  |
| Contract liabilities, non-current (included within Other long-term liabilities) |  | 169 |  |  | 165 |  |
| Total contract liabilities |  | 587 |  |  | 677 |  |
| Net contract assets |  | $ | 34 |  |  | $ | 77 |  |

[0001783180-21-000065:notes:82]
The timing of revenue recognition, billings and cash collections results in contract assets and contract liabilities. Contract assets relate to the conditional right to consideration for any completed performance under a contract when costs are incurred in excess of billings under the percentage-of-completion methodology. Contract liabilities relate to payments received in advance of performance under the contract or when the Company has a right to consideration that is conditioned upon transfer of a good or service to the customer. Contract liabilities are recognized as revenue as (or when) the Company performs under the contract. The Company recognized revenue of $337 million during the nine months ended September 30, 2021 that related to contract liabilities as of January 1, 2021. The Company expects a majority of its contract liabilities at the end of the period to be recognized as revenue in the next 12 months.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001783180-21-000065:notes:83]
[same as prior period, unchanged from 0001783180-21-000050:notes:76]

[0001783180-21-000065:notes:84]
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
| (In millions) | 2021 |  | 2020 |  | 2021 |  | 2020 |
| HVAC | $ | 7 |  |  | $ | — |  |  | $ | 18 |  |  | $ | 3 |  |
| Refrigeration | 2 |  |  | (1) |  |  | 7 |  |  | 2 |  |
| Fire & Security | 3 |  |  | 4 |  |  | 23 |  |  | 13 |  |
| Total Segment | 12 |  |  | 3 |  |  | 48 |  |  | 18 |  |
| General corporate expenses | 1 |  |  | — |  |  | 4 |  |  | 1 |  |
| Total restructuring costs | $ | 13 |  |  | $ | 3 |  |  | $ | 52 |  |  | $ | 19 |  |
| Cost of sales | $ | 7 |  |  | $ | (1) |  |  | $ | 18 |  |  | $ | 5 |  |
| Selling, general and administrative | 6 |  |  | 4 |  |  | 34 |  |  | 14 |  |
| Total restructuring costs | $ | 13 |  |  | $ | 3 |  |  | $ | 52 |  |  | $ | 19 |  |

[0001783180-21-000065:notes:85]
The changes in the restructuring accrual, included in Accrued liabilities on the accompanying Unaudited Condensed Consolidated Balance Sheet, are as follows:

[0001783180-21-000065:notes:86]
|  |  | For the Nine Months Ended September 30, |
| (In millions) |  | 2021 |  | 2020 |
| Balance as of January 1, |  | $ | 49 |  |  | $ | 66 |  |
| Net pre-tax restructuring costs |  | 52 |  |  | 19 |  |
| Utilization, foreign exchange and other |  | (54) |  |  | (46) |  |
| Reclassified as Liabilities held for sale (1) |  | (14) |  |  | — |  |
| Balance as of September 30, |  | $ | 33 |  |  | $ | 39 |  |

[0001783180-21-000065:notes:87]
During the nine months ended September 30, 2021, charges associated with restructuring initiatives related to cost reduction efforts. Amounts recognized primarily related to severance due to workforce reductions and exit costs due to the consolidation of field operations. As of September 30, 2021, the Company had $33 million accrued for costs associated with its announced restructuring initiatives, all of which is expected to be paid within one year.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001783180-21-000065:notes:88]
INCOME TAXES 
The Company accounts for income tax expense in accordance with ASC 740, which requires an estimate of the annual effective income tax rate for the full year to be applied to the respective interim period, taking into account year-to-date amounts and projected results for the full year. The effective tax rate for the three months ended September 30, 2021 was 37.5% compared with 25.9% for the three months ended September 30, 2020. The period-over-period increase was driven by a net tax charge of $136 million primarily relating to the re-organizations and disentanglements of certain Chubb subsidiaries executed in advance of the planned divestiture of the Company's Chubb business. This increase was partially offset by a favorable tax adjustment of $23 million due to foreign tax credits generated and expected to be utilized in the current year.

[0001783180-21-000065:notes:89]
The effective tax rate for the nine months ended September 30, 2021 was 31.4% compared with 33.4% for the nine months ended September 30, 2020. The year-over-year decrease is primarily due to the significant items recognized during the period as a percentage of Income from operations before income taxes. The nine months ended September 30, 2021 include a net tax charge of $136 million primarily relating to the re-organizations and disentanglements of certain Chubb subsidiaries executed in advance of the planned divestiture of the Company's Chubb business, a $43 million deferred tax charge as a result of the tax rate increase from 19% to 25% in the United Kingdom, partially offset by a favorable tax adjustment of $23 million due to

[0001783180-21-000065:notes:90]
foreign tax credits generated and expected to be utilized in the current year and $21 million resulting from re-organization of a German subsidiary. The nine months ended September 30, 2020 include a tax charge of $51 million related to a valuation allowance recorded against a United Kingdom tax loss and credit carryforward and a $46 million charge resulting from the Company's decision to no longer permanently reinvest certain pre-2018 unremitted non-U.S. earnings.

[0001783180-21-000065:notes:91]
Income taxes through March 31, 2020 were recorded based on a "carve-out" and separate company basis. Prior to the Separation and the Distribution, the Company’s portion of income taxes for domestic and certain foreign jurisdictions were deemed settled in the period the related tax expense was recorded. After the Separation and the Distribution, the Company’s income taxes are prepared on a stand-alone basis.

[0001783180-21-000065:notes:92]
[same as prior period, unchanged from 0001783180-21-000050:notes:85]

[0001783180-21-000065:notes:93]
[same as prior period, unchanged from 0001783180-21-000050:notes:86]

[0001783180-21-000065:notes:94]
In the ordinary course of business, there is inherent uncertainty in quantifying the Company's income tax positions. The Company assesses its income tax positions and records tax benefits for all years subject to examination based upon management’s evaluation of the facts, circumstances and information available at the reporting date. The Company believes that it is reasonably possible that a net decrease in unrecognized tax benefits of between $25 million and $75 million may occur within 12 months as a result of additional uncertain tax positions, the Separation, the revaluation of uncertain tax positions arising from examinations, appeals, court decisions and/or the expiration of tax statutes.


## us-gaap:EarningsPerShareTextBlock

[0001783180-21-000065:notes:95]
[same as prior period, unchanged from 0001783180-21-000050:notes:88]

[0001783180-21-000065:notes:96]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
| (In millions, except per share amounts) |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Net income attributable to common shareowners |  | $ | 469 |  |  | $ | 741 |  |  | $ | 1,340 |  |  | $ | 1,098 |  |
| Basic weighted-average number of shares outstanding |  | 867.6 |  |  | 866.4 |  |  | 868.6 |  |  | 866.3 |  |
| Stock awards and equity units (share equivalent) |  | 24.4 |  |  | 15.1 |  |  | 22.3 |  |  | 9.9 |  |
| Diluted weighted-average number of shares outstanding |  | 892.0 |  |  | 881.5 |  |  | 890.9 |  |  | 876.2 |  |
| Antidilutive shares excluded from computation of diluted earnings per share |  | 0.2 |  |  | 3.2 |  |  | 0.2 |  |  | 3.2 |  |
| Earnings Per Share |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.54 |  |  | $ | 0.86 |  |  | $ | 1.54 |  |  | $ | 1.27 |  |
| Diluted |  | $ | 0.53 |  |  | $ | 0.84 |  |  | $ | 1.50 |  |  | $ | 1.25 |  |

[0001783180-21-000065:notes:97]
On the Distribution Date, 866,158,910 shares of the Company’s common stock, par value $0.01 per share, were distributed to 
UTC shareowners of record as of March 19, 2020. This share amount is utilized for the calculation of basic and diluted earnings per share for all periods presented prior to the Separation and the Distribution and such shares are treated as issued and outstanding for purposes of calculating historical earnings per share. It is assumed that there are no dilutive equity instruments for the periods prior to the Separation and Distribution because there were no Carrier stock-based awards outstanding prior to the Separation and the Distribution.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001783180-21-000065:notes:98]
ACQUISITIONS
During the nine months ended September 30, 2021, the Company acquired consolidated businesses and a minority-owned business. The aggregate cash paid, net of cash acquired, totaled $214 million and was funded through cash on hand. Acquisitions are recorded using the acquisition method of accounting in accordance with ASC 805, Business Combinations ("ASC 805"). As a result, the aggregate purchase price has been allocated to assets acquired and liabilities assumed based on the estimate of fair market value of such assets and liabilities at the date of acquisition. Intangible assets associated with these transactions totaled $94 million and primarily related to customer relationships, technology assets and a non-compete agreement. The excess purchase price over the estimated fair value of net assets acquired was recognized as goodwill and totaled $180 million.

[0001783180-21-000065:notes:99]
[same as prior period, unchanged from 0001783180-21-000050:notes:92]

[0001783180-21-000065:notes:100]
On June 1, 2021, the Company acquired a 70% controlling stake in Guangdong Giwee Group and its subsidiaries ("Giwee") and acquired the remaining 30% ownership interest on September 7, 2021. Giwee is a China-based manufacturer of HVAC products, offering a portfolio of products including variable refrigerant flow, modular chillers and light commercial air conditioners. The results of Giwee are reported within the HVAC segment as of the date of acquisition. The Company has not included pro forma financial information required under ASC 805 as the pro forma impact was not deemed significant.

[0001783180-21-000065:notes:101]
The excess of the purchase price over the estimated fair value of the net assets acquired was recognized as goodwill and totaled $174 million, which is not deductible for tax purposes. Accounts receivable and current liabilities were stated at their historical carrying value, which approximates fair value given the short-term nature of these assets and liabilities. The estimate of fair value for inventory and property, plant and equipment was based on an assessment of the acquired assets' condition as well as an evaluation of the current market value of such assets.

[0001783180-21-000065:notes:102]
[same as prior period, unchanged from 0001783180-21-000050:notes:95]

[0001783180-21-000065:notes:103]
[same as prior period, unchanged from 0001783180-21-000050:notes:96]

[0001783180-21-000065:notes:104]
The valuation of intangible assets was determined using an income approach methodology including the multi-period excess earnings method and the relief from royalty method. Key assumptions used in estimating future cash flows included projected revenue growth rates, customer attrition rates and royalty rates. The projected future cash flows are discounted to present value using an appropriate discount rate. As of September 30, 2021, the Company has not finalized the process of allocating the purchase price and valuing the acquired assets and liabilities for the Giwee acquisition.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001783180-21-000065:notes:105]
DIVESTITURES
Sale of Chubb Fire & Security Business

[0001783180-21-000065:notes:106]
On July 26, 2021, the Company entered into a stock purchase agreement to sell its Chubb business to APi for an enterprise value of $3.1 billion (the "Chubb Sale Agreement"). Chubb, reported within the Company’s Fire & Security segment, delivers essential fire safety and security solutions from design and installation to monitoring, service and maintenance across more than 17 countries around the globe. The transaction is expected to close late in the fourth quarter of 2021 or early in the first quarter of 2022, subject to regulatory approvals, required works council approval in France and customary closing conditions. The

[0001783180-21-000065:notes:107]
purchase price is subject to working capital and other adjustments as provided in the Chubb Sale Agreement. In accordance with U.S. GAAP, the assets and liabilities of Chubb have been reclassified as held for sale in the accompanying Unaudited Condensed Consolidated Balance Sheet as of September 30, 2021 and recorded at the lower of their carrying value or fair value less estimated cost to sell, and are no longer depreciated or amortized. Based on the carrying amount of Chubb’s net assets, foreign currency translation rates and other assumptions at September 30, 2021, the Company expects to recover the carrying value of the disposal group upon completion of the transaction.

[0001783180-21-000065:notes:108]
The components of Chubb's assets and liabilities recorded as held for sale on the Unaudited Condensed Consolidated Balance Sheet at September 30, 2021 were as follows:

[0001783180-21-000065:notes:109]
| (in millions) |  | September 30,2021 |  |  |
| Cash and cash equivalents |  | $ | 74 |  |  |  |
| Accounts receivable, net |  | 414 |  |  |  |
| Inventories, net |  | 70 |  |  |  |
| Contract assets, current |  | 210 |  |  |  |
| Other assets, current |  | 28 |  |  |  |
| Fixed assets, net |  | 66 |  |  |  |
| Intangible assets, net |  | 551 |  |  |  |
| Goodwill |  | 936 |  |  |  |
| Operating lease right-of-use assets |  | 173 |  |  |  |
| Pension and post-retirement assets |  | 600 |  |  |  |
| Other assets |  | 26 |  |  |  |
| Total assets held for sale |  | $ | 3,148 |  |  |  |
| Accounts payable |  | $ | 178 |  |  |  |
| Accrued liabilities |  | 288 |  |  |  |
| Contract liabilities, current |  | 154 |  |  |  |
| Future pension and post-retirement obligations |  | 85 |  |  |  |
| Future income tax obligations |  | 255 |  |  |  |
| Operating lease liabilities |  | 122 |  |  |  |
| Other long-term liabilities |  | 20 |  |  |  |
| Total liabilities held for sale |  | $ | 1,102 |  |  |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001783180-21-000065:notes:110]
[same as prior period, unchanged from 0001783180-21-000050:notes:98]

[0001783180-21-000065:notes:111]
[same as prior period, unchanged from 0001783180-21-000050:notes:99]

[0001783180-21-000065:notes:112]
[same as prior period, unchanged from 0001783180-21-000050:notes:100]

[0001783180-21-000065:notes:113]
[same as prior period, unchanged from 0001783180-21-000050:notes:101]

[0001783180-21-000065:notes:114]
[same as prior period, unchanged from 0001783180-21-000050:notes:102]

[0001783180-21-000065:notes:115]
[same as prior period, unchanged from 0001783180-21-000050:notes:103]

[0001783180-21-000065:notes:116]
|  |  | Net Sales |  | Operating Profit |
|  |  | For the Three Months Ended September 30, |  | For the Three Months Ended September 30, |
| (In millions) |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| HVAC |  | $ | 3,054 |  |  | $ | 2,892 |  |  | $ | 573 |  |  | $ | 839 |  |
| Refrigeration |  | 1,011 |  |  | 876 |  |  | 119 |  |  | 103 |  |
| Fire & Security |  | 1,377 |  |  | 1,324 |  |  | 182 |  |  | 200 |  |
| Total segment |  | 5,442 |  |  | 5,092 |  |  | 874 |  |  | 1,142 |  |
| Eliminations and other |  | (101) |  |  | (90) |  |  | (10) |  |  | (31) |  |
| General corporate expenses |  | — |  |  | — |  |  | (36) |  |  | (30) |  |
| Total Consolidated |  | $ | 5,341 |  |  | $ | 5,002 |  |  | $ | 828 |  |  | $ | 1,081 |  |

[0001783180-21-000065:notes:117]
|  |  | Net Sales |  | Operating Profit |
|  |  | For the Nine Months Ended September 30, |  | For the Nine Months Ended September 30, |
| (In millions) |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| HVAC |  | $ | 8,660 |  |  | $ | 7,142 |  |  | $ | 1,511 |  |  | $ | 1,364 |  |
| Refrigeration |  | 3,037 |  |  | 2,384 |  |  | 369 |  |  | 263 |  |
| Fire & Security |  | 4,084 |  |  | 3,587 |  |  | 480 |  |  | 426 |  |
| Total segment |  | 15,781 |  |  | 13,113 |  |  | 2,360 |  |  | 2,053 |  |
| Eliminations and other |  | (301) |  |  | (251) |  |  | (73) |  |  | (122) |  |
| General corporate expenses |  | — |  |  | — |  |  | (105) |  |  | (93) |  |
| Total Consolidated |  | $ | 15,480 |  |  | $ | 12,862 |  |  | $ | 2,182 |  |  | $ | 1,838 |  |

[0001783180-21-000065:notes:118]
Geographic external sales are attributed to the geographic regions based on their location of origin. With the exception of the U.S. presented in the table below, there were no individually significant countries with sales exceeding 10% of total sales during the nine months ended September 30, 2021 and 2020.

[0001783180-21-000065:notes:119]
|  |  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
| (In millions) |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| United States |  | $ | 2,832 |  |  | $ | 2,780 |  |  | $ | 8,033 |  |  | $ | 6,983 |  |
| International: |  |  |  |  |  |  |  |  |
| Europe |  | 1,416 |  |  | 1,307 |  |  | 4,273 |  |  | 3,455 |  |
| Asia Pacific |  | 869 |  |  | 715 |  |  | 2,518 |  |  | 1,879 |  |
| Other |  | 224 |  |  | 200 |  |  | 656 |  |  | 545 |  |
| Net sales |  | $ | 5,341 |  |  | $ | 5,002 |  |  | $ | 15,480 |  |  | $ | 12,862 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001783180-21-000065:notes:120]
RELATED PARTIES 
Equity Method Investments

[0001783180-21-000065:notes:121]
The Company sells products to and purchases products from unconsolidated entities accounted for under the equity method and, therefore, these entities are considered to be related parties. Amounts attributable to equity method investees are as follows:

[0001783180-21-000065:notes:122]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
| (In millions) |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Sales to equity method investees included in Product sales |  | $ | 556 |  |  | $ | 576 |  |  | $ | 1,675 |  |  | $ | 1,400 |  |
| Purchases from equity method investees included in Cost of products sold |  | $ | 93 |  |  | $ | 70 |  |  | $ | 266 |  |  | $ | 213 |  |

[0001783180-21-000065:notes:123]
The Company had receivables from and payables to equity method investees as follows:

[0001783180-21-000065:notes:124]
| (In millions) |  | September 30,2021 |  | December 31, 2020 |
| Receivables from equity method investees included in Accounts receivable, net |  | $ | 253 |  |  | $ | 161 |  |
| Payables to equity method investees included in Accounts payable |  | $ | 55 |  |  | $ | 38 |  |

[0001783180-21-000065:notes:125]
The Company periodically reviews the carrying value of its equity method investments to determine if there has been an other-than-temporary decline in fair value. During the three months ended March 31, 2020, the Company determined that indicators of impairment existed for a minority owned joint venture investment and performed a valuation of this investment using a discounted cash flow method. The Company determined that the loss in value was other-than-temporary due to a reduction in sales and earnings that were primarily driven by a deterioration in the oil and gas industry (the joint venture's primary market) and by the impact of the COVID-19 pandemic. As a result, the Company recorded a non-cash, other-than-temporary impairment charge of $71 million on this investment during the three months ended March 31, 2020, which is included in Other income (expense), net on the accompanying Unaudited Condensed Consolidated Statement of Operations.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001783180-21-000065:notes:126]
COMMITMENTS AND CONTINGENT LIABILITIES
The Company is involved in various litigation, claims and administrative proceedings, including those related to environmental and legal matters (including asbestos). In accordance with ASC 450, Contingencies ("ASC 450"), the Company records accruals for loss contingencies when it is probable that a liability will be incurred and the amount of the loss can be reasonably estimated. These accruals are generally based upon a range of possible outcomes. If no amount within the range is a better estimate than any other, the Company accrues the minimum amount. In addition, these estimates are reviewed periodically and adjusted to reflect additional information when it becomes available. The Company is unable to predict the final outcome of the following matters based on the information currently available, except as otherwise noted. However, the Company does not believe that the resolution of any of these matters will have a material adverse effect upon the Company's competitive position, results of operations, cash flows or financial condition.

[0001783180-21-000065:notes:127]
Environmental Matters

[0001783180-21-000065:notes:128]
The Company’s operations are subject to environmental regulation by various authorities. The Company has accrued for the costs of environmental remediation activities, including but not limited to investigatory, remediation, operating and maintenance costs and performance guarantees, and the Company periodically reassesses these amounts. Management believes

[0001783180-21-000065:notes:129]
that the likelihood of incurring losses materially in excess of the amounts accrued is remote. The outstanding liabilities for environmental obligations are as follows:

[0001783180-21-000065:notes:130]
| (In millions) |  | September 30,2021 |  | December 31, 2020 |
| Environmental reserves included in Accrued liabilities |  | $ | 19 |  |  | $ | 26 |  |
| Environmental reserves included in Other long-term liabilities |  | 202 |  |  | 213 |  |
| Total Environmental reserves |  | $ | 221 |  |  | $ | 239 |  |

[0001783180-21-000065:notes:131]
Asbestos Matters

[0001783180-21-000065:notes:132]
The Company and its consolidated subsidiaries have been named as defendants in lawsuits alleging personal injury as a result of exposure to asbestos allegedly integrated into certain Carrier products or business premises. While the Company has never manufactured asbestos and no longer incorporates it into any currently-manufactured products, certain products that the Company no longer manufactures contained components incorporating asbestos. A substantial majority of these asbestos-related claims have been dismissed without payment or have been covered in full or in part by insurance or other forms of indemnity. Additional cases were litigated and settled without any insurance reimbursement. The amounts involved in asbestos-related claims were not material individually or in the aggregate in any period.

[0001783180-21-000065:notes:133]
The Company had asbestos liabilities and related recoveries as follows:

[0001783180-21-000065:notes:134]
| (In millions) |  | September 30,2021 |  | December 31,2020 |
| Asbestos liabilities included in Accrued liabilities |  | $ | 17 |  |  | $ | 17 |  |
| Asbestos liabilities included in Other long-term liabilities |  | 221 |  |  | 228 |  |
| Total Asbestos liabilities |  | $ | 238 |  |  | $ | 245 |  |
| Asbestos-related recoveries included in Other assets, current |  | $ | 5 |  |  | $ | 6 |  |
| Asbestos-related recoveries included in Other assets |  | 93 |  |  | 97 |  |
| Total Asbestos-related recoveries |  | $ | 98 |  |  | $ | 103 |  |

[0001783180-21-000065:notes:135]
The amounts recorded for asbestos-related liabilities are based on currently available information and assumptions that the Company believes are reasonable and are made with input from outside actuarial experts. Where no amount within a range of estimates is more likely, the minimum is accrued. These amounts are undiscounted and exclude the Company’s legal fees to defend the asbestos claims, which are expensed as incurred. In addition, the Company has recorded an insurance recovery receivable for probable asbestos-related recoveries.

[0001783180-21-000065:notes:136]
UTC Equity Awards Conversion Litigation

[0001783180-21-000065:notes:137]
On August 12, 2020, several former employees of UTC or its subsidiaries filed a putative class action complaint (the "Complaint") in the United States District Court for the District of Connecticut against Raytheon Technologies Corporation, Carrier, Otis, the former members of the UTC Board of Directors and the members of the Carrier and Otis Boards of Directors (Geraud Darnis, et al. v. Raytheon Technologies Corporation, et al.). The Complaint challenges the method by which UTC equity awards were converted to UTC, Carrier and Otis equity awards following the Separation and the Distribution. Defendants moved to dismiss the Complaint. Plaintiffs amended their Complaint on September 13, 2021. The amended Complaint, now with Raytheon, Carrier and Otis as the only defendants, asserts that the defendants are liable for breach of certain equity compensation plans and for breach of the implied covenant of good faith and fair dealing. The Amended Complaint also seeks specific performance. Carrier believes that the claims against the Company are without merit.

[0001783180-21-000065:notes:138]
Aqueous Film Forming Foam Litigation

[0001783180-21-000065:notes:139]
As of September 30, 2021, the Company has been named as a defendant in 1,629 lawsuits filed by individuals in or removed to the federal courts of the United States alleging that the historic use of Aqueous Film Forming Foam ("AFFF") caused personal injuries and/or property damage. The Company has also been named as a defendant in 149 lawsuits filed by several U.S. states, municipalities and water utilities in or removed to U.S. federal courts alleging that the historic use of AFFF caused

[0001783180-21-000065:notes:140]
contamination of property and water supplies. In December 2018, the U.S. Judicial Panel on Multidistrict Litigation transferred and consolidated all AFFF cases pending in the U.S. federal courts against the Company and others to the U.S. District Court for the District of South Carolina ("MDL Court") for pre-trial proceedings ("MDL Proceedings"). The individual plaintiffs in the MDL Proceedings generally seek damages for alleged personal injuries, medical monitoring and diminution in property value and injunctive relief to remediate alleged contamination of water supplies. The U.S. state, municipal and water utility plaintiffs in the MDL Proceedings generally seek damages and costs related to the remediation of public property and water supplies.

[0001783180-21-000065:notes:141]
AFFF is a firefighting foam, developed beginning in the late 1960s pursuant to U.S. military specification, used to extinguish certain types of hydrocarbon-fueled fires primarily at military bases and airports. AFFF was manufactured by several companies, including National Foam and Angus Fire. UTC first entered the AFFF business with the acquisition of National Foam and Angus Fire in 2005 as part of the acquisition of Kidde. In 2013, Kidde divested the National Foam and Angus Fire businesses to a third party. The Company acquired Kidde as part of its separation from UTC in April 2020. During the eight year period of its operation by Kidde, National Foam manufactured AFFF for sale to government (including the U.S. federal government) and non-government customers in the U.S. at a single facility located in West Chester, Pennsylvania ("Pennsylvania Site"). During the same period, Angus Fire manufactured AFFF for sale outside the United States at a single facility located in Bentham, England.

[0001783180-21-000065:notes:142]
The key components of AFFF that contribute to its fire-extinguishing capabilities are known as fluorosurfactants. National Foam and Angus Fire did not manufacture fluorosurfactants but instead purchased these substances from unrelated third parties. Plaintiffs in the MDL Proceedings allege that the fluorosurfactants used by various manufacturers in producing AFFF contained, or over time degraded into, compounds known as perflourooctane sulfonate ("PFOS") and/or perflourooctane acid ("PFOA"). Plaintiffs further allege that, as a result of the use of AFFF, PFOS and PFOA were released into the environment and, in some instances, ultimately reached drinking water supplies.

[0001783180-21-000065:notes:143]
Plaintiffs in the MDL Proceedings allege that PFOS and PFOA contamination has resulted from the use of AFFF containing fluorosurfactants manufactured using a process known as ECF. They also allege that PFOA contamination has resulted from the use of AFFF containing fluorosurfactants manufactured using a different process, known as telomerization. Plaintiffs further allege that 3M was the only AFFF manufacturer that used fluorosurfactants relying on the ECF process and that all other foam manufacturers (including National Foam and Angus Fire) relied solely on fluorosurfactants produced via telomerization. Compounds containing PFOS and PFOA (as well as many other per- and polyfluoroalkyl substances known collectively as "PFAS") have also been used for decades by many third parties in a number of different industries to manufacture carpets, clothing, fabrics, cookware, food packaging, personal care products, cleaning products, paints, varnishes and other consumer and industrial products.

[0001783180-21-000065:notes:144]
Plaintiffs in the MDL Proceedings have named multiple defendants, including four suppliers of chemicals and raw materials used to manufacture fluorosurfactants, four fluorosurfactant manufacturers, two toll manufacturers of fluorosurfactants and seven current (including National Foam and Angus Fire) and former (including the Company) AFFF manufacturers.

[0001783180-21-000065:notes:145]
General liability discovery in the MDL Proceedings continues. The parties are also currently conducting preliminary stage discovery with respect to ten "bellwether" water provider cases, which are scheduled to conclude by October 2021. At that point, the MDL Court intends to reduce that pool to three cases, after which the parties will conduct expanded fact and expert discovery and pursue dispositive motions, followed by trials to commence in 2023. The MDL Court has established a briefing schedule with respect to certain aspects of the government contractor defense, potentially applicable to AFFF sold to or used by the U.S. federal government or other customers requiring product manufactured to meet military specification, such that all briefs will be filed by late January 2022 with a hearing to follow thereafter.

[0001783180-21-000065:notes:146]
Outside of the MDL Proceedings, the Company and other defendants are also party to six lawsuits in U.S. state courts brought by oil refining companies alleging product liability claims related to legacy sales of AFFF and seeking damages for the costs to replace the product and for property damage. In addition, the Company and other defendants are party to two actions related to the Pennsylvania Site in which the plaintiff water utility seeks remediation costs related to the alleged contamination of the local water supply.

[0001783180-21-000065:notes:147]
The Company believes that it has meritorious defenses to the claims in the MDL Proceedings and the other AFFF lawsuits. Based on the 2013 agreement for the sale of National Foam and Angus Fire, the Company is pursuing indemnification against these claims from the purchaser and current owner of National Foam and Angus Fire. The Company is also pursuing insurance coverage for these claims. At this time, however, given the numerous factual, scientific and legal issues to be resolved relating

[0001783180-21-000065:notes:148]
to these claims, the Company is unable to assess the probability of liability or to reasonably estimate the damages, if any, to be allocated to the Company, if one or more plaintiffs were to prevail in these cases, and there can be no assurance that any such future exposure will not be material in any period.

[0001783180-21-000065:notes:149]
Income Taxes

[0001783180-21-000065:notes:150]
Under the TMA, the Company is responsible to UTC for its share of the Tax Cuts and Jobs Act ("TCJA") transition tax associated with foreign undistributed earnings as of December 31, 2017. As a result, a liability of $453 million is included within the accompanying Unaudited Condensed Consolidated Balance Sheet as of September 30, 2021. This obligation is expected to be settled in annual installments ending in April 2026 with the next installment of $36 million included within Accrued Liabilities. The Company believes that the likelihood of incurring losses materially in excess of this amount is remote.

[0001783180-21-000065:notes:151]
Other

[0001783180-21-000065:notes:152]
The Company has other commitments and contingent liabilities related to legal proceedings, self-insurance programs and matters arising in the ordinary course of business. The Company accrues for contingencies generally based upon a range of possible outcomes. If no amount within the range is a better estimate than any other, the Company accrues the minimum amount.

[0001783180-21-000065:notes:153]
In the ordinary course of business, the Company is also routinely a defendant in, party to or otherwise subject to many pending and threatened legal actions, claims, disputes and proceedings. These matters are often based on alleged violations of contract, product liability, warranty, regulatory, environmental, health and safety, employment, intellectual property, tax and other laws. In some of these proceedings, claims for substantial monetary damages are asserted against the Company and could result in fines, penalties, compensatory or treble damages or non-monetary relief. The Company does not believe that these matters will have a material adverse effect upon its competitive position, results of operations, cash flows or financial condition.
