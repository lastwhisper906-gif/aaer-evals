# CARR note change history — 0001783180-21-000050 → 0001783180-21-000065


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2021-10-28):
[0001783180-21-000065:note_history:1]
COMMITMENTS AND CONTINGENT LIABILITIES
The Company is involved in various litigation, claims and administrative proceedings, including those related to environmental and legal matters (including asbestos). In accordance with ASC 450, Contingencies ("ASC 450"), the Company records accruals for loss contingencies when it is probable that a liability will be incurred and the amount of the loss can be reasonably estimated. These accruals are generally based upon a range of possible outcomes. If no amount within the range is a better estimate than any other, the Company accrues the minimum amount. In addition, these estimates are reviewed periodically and adjusted to reflect additional information when it becomes available. The Company is unable to predict the final outcome of the following matters based on the information currently available, except as otherwise noted. However, the Company does not believe that the resolution of any of these matters will have a material adverse effect upon the Company's competitive position, results of operations, cash flows or financial condition.
  (was, 2021-07-29, similarity 0.9835):
[0001783180-21-000050:note_history:1]
COMMITMENTS AND CONTINGENT LIABILITIES
The Company is involved in various litigation, claims and administrative proceedings, including those related to environmental (including asbestos) and legal matters. In accordance with ASC 450, Contingencies ("ASC 450"), the Company records accruals for loss contingencies when it is probable that a liability will be incurred and the amount of the loss can be reasonably estimated. These accruals are generally based upon a range of possible outcomes. If no amount within the range is a better estimate than any other, the Company accrues the minimum amount. In addition, these estimates are reviewed periodically and adjusted to reflect additional information when it becomes available. The Company is unable to predict the final outcome of the following matters based on the information currently available, except as otherwise noted. However, the Company does not believe that the resolution of any of these matters will have a material adverse effect upon the Company's competitive position, results of operations, cash flows or financial condition.

- changed (2021-10-28):
[0001783180-21-000065:note_history:2]
The Company’s operations are subject to environmental regulation by various authorities. The Company has accrued for the costs of environmental remediation activities, including but not limited to investigatory, remediation, operating and maintenance costs and performance guarantees, and the Company periodically reassesses these amounts. Management believes
  (was, 2021-07-29, similarity 0.8095):
[0001783180-21-000050:note_history:2]
The Company’s operations are subject to environmental regulation by various authorities. The Company has accrued for the costs of environmental remediation activities, including but not limited to investigatory, remediation, operating and maintenance costs and performance guarantees, and the Company periodically reassesses these amounts. Management believes that the likelihood of incurring losses materially in excess of the amounts accrued is remote. The outstanding liabilities for environmental obligations are as follows:

- added (2021-10-28):
[0001783180-21-000065:note_history:3]
that the likelihood of incurring losses materially in excess of the amounts accrued is remote. The outstanding liabilities for environmental obligations are as follows:

- changed (2021-10-28):
[0001783180-21-000065:note_history:4]
| (In millions) |  | September 30,2021 |  | December 31, 2020 |
| Environmental reserves included in Accrued liabilities |  | $ | 19 |  |  | $ | 26 |  |
| Environmental reserves included in Other long-term liabilities |  | 202 |  |  | 213 |  |
| Total Environmental reserves |  | $ | 221 |  |  | $ | 239 |  |
  (was, 2021-07-29, similarity 0.976):
[0001783180-21-000050:note_history:4]
| (In millions) |  | June 30,2021 |  | December 31, 2020 |
| Environmental reserves included in Accrued liabilities |  | $ | 25 |  |  | $ | 26 |  |
| Environmental reserves included in Other long-term liabilities |  | 209 |  |  | 213 |  |
| Total Environmental reserves |  | $ | 234 |  |  | $ | 239 |  |

- changed (2021-10-28):
[0001783180-21-000065:note_history:5]
| (In millions) |  | September 30,2021 |  | December 31,2020 |
| Asbestos liabilities included in Accrued liabilities |  | $ | 17 |  |  | $ | 17 |  |
| Asbestos liabilities included in Other long-term liabilities |  | 221 |  |  | 228 |  |
| Total Asbestos liabilities |  | $ | 238 |  |  | $ | 245 |  |
| Asbestos-related recoveries included in Other assets, current |  | $ | 5 |  |  | $ | 6 |  |
| Asbestos-related recoveries included in Other assets |  | 93 |  |  | 97 |  |
| Total Asbestos-related recoveries |  | $ | 98 |  |  | $ | 103 |  |
  (was, 2021-07-29, similarity 0.9867):
[0001783180-21-000050:note_history:5]
| (In millions) |  | June 30,2021 |  | December 31,2020 |
| Asbestos liabilities included in Accrued liabilities |  | $ | 18 |  |  | $ | 17 |  |
| Asbestos liabilities included in Other long-term liabilities |  | 222 |  |  | 228 |  |
| Total Asbestos liabilities |  | $ | 240 |  |  | $ | 245 |  |
| Asbestos-related recoveries included in Other assets, current |  | $ | 6 |  |  | $ | 6 |  |
| Asbestos-related recoveries included in Other assets |  | 95 |  |  | 97 |  |
| Total Asbestos-related recoveries |  | $ | 101 |  |  | $ | 103 |  |

- added (2021-10-28):
[0001783180-21-000065:note_history:6]
On August 12, 2020, several former employees of UTC or its subsidiaries filed a putative class action complaint (the "Complaint") in the United States District Court for the District of Connecticut against Raytheon Technologies Corporation, Carrier, Otis, the former members of the UTC Board of Directors and the members of the Carrier and Otis Boards of Directors (Geraud Darnis, et al. v. Raytheon Technologies Corporation, et al.). The Complaint challenges the method by which UTC equity awards were converted to UTC, Carrier and Otis equity awards following the Separation and the Distribution. Defendants moved to dismiss the Complaint. Plaintiffs amended their Complaint on September 13, 2021. The amended Complaint, now with Raytheon, Carrier and Otis as the only defendants, asserts that the defendants are liable for breach of certain equity compensation plans and for breach of the implied covenant of good faith and fair dealing. The Amended Complaint also seeks specific performance. Carrier believes that the claims against the Company are without merit.

- added (2021-10-28):
[0001783180-21-000065:note_history:7]
As of September 30, 2021, the Company has been named as a defendant in 1,629 lawsuits filed by individuals in or removed to the federal courts of the United States alleging that the historic use of Aqueous Film Forming Foam ("AFFF") caused personal injuries and/or property damage. The Company has also been named as a defendant in 149 lawsuits filed by several U.S. states, municipalities and water utilities in or removed to U.S. federal courts alleging that the historic use of AFFF caused

- added (2021-10-28):
[0001783180-21-000065:note_history:8]
contamination of property and water supplies. In December 2018, the U.S. Judicial Panel on Multidistrict Litigation transferred and consolidated all AFFF cases pending in the U.S. federal courts against the Company and others to the U.S. District Court for the District of South Carolina ("MDL Court") for pre-trial proceedings ("MDL Proceedings"). The individual plaintiffs in the MDL Proceedings generally seek damages for alleged personal injuries, medical monitoring and diminution in property value and injunctive relief to remediate alleged contamination of water supplies. The U.S. state, municipal and water utility plaintiffs in the MDL Proceedings generally seek damages and costs related to the remediation of public property and water supplies.

- added (2021-10-28):
[0001783180-21-000065:note_history:9]
AFFF is a firefighting foam, developed beginning in the late 1960s pursuant to U.S. military specification, used to extinguish certain types of hydrocarbon-fueled fires primarily at military bases and airports. AFFF was manufactured by several companies, including National Foam and Angus Fire. UTC first entered the AFFF business with the acquisition of National Foam and Angus Fire in 2005 as part of the acquisition of Kidde. In 2013, Kidde divested the National Foam and Angus Fire businesses to a third party. The Company acquired Kidde as part of its separation from UTC in April 2020. During the eight year period of its operation by Kidde, National Foam manufactured AFFF for sale to government (including the U.S. federal government) and non-government customers in the U.S. at a single facility located in West Chester, Pennsylvania ("Pennsylvania Site"). During the same period, Angus Fire manufactured AFFF for sale outside the United States at a single facility located in Bentham, England.

- added (2021-10-28):
[0001783180-21-000065:note_history:10]
The key components of AFFF that contribute to its fire-extinguishing capabilities are known as fluorosurfactants. National Foam and Angus Fire did not manufacture fluorosurfactants but instead purchased these substances from unrelated third parties. Plaintiffs in the MDL Proceedings allege that the fluorosurfactants used by various manufacturers in producing AFFF contained, or over time degraded into, compounds known as perflourooctane sulfonate ("PFOS") and/or perflourooctane acid ("PFOA"). Plaintiffs further allege that, as a result of the use of AFFF, PFOS and PFOA were released into the environment and, in some instances, ultimately reached drinking water supplies.

- added (2021-10-28):
[0001783180-21-000065:note_history:11]
Plaintiffs in the MDL Proceedings allege that PFOS and PFOA contamination has resulted from the use of AFFF containing fluorosurfactants manufactured using a process known as ECF. They also allege that PFOA contamination has resulted from the use of AFFF containing fluorosurfactants manufactured using a different process, known as telomerization. Plaintiffs further allege that 3M was the only AFFF manufacturer that used fluorosurfactants relying on the ECF process and that all other foam manufacturers (including National Foam and Angus Fire) relied solely on fluorosurfactants produced via telomerization. Compounds containing PFOS and PFOA (as well as many other per- and polyfluoroalkyl substances known collectively as "PFAS") have also been used for decades by many third parties in a number of different industries to manufacture carpets, clothing, fabrics, cookware, food packaging, personal care products, cleaning products, paints, varnishes and other consumer and industrial products.

- added (2021-10-28):
[0001783180-21-000065:note_history:12]
Plaintiffs in the MDL Proceedings have named multiple defendants, including four suppliers of chemicals and raw materials used to manufacture fluorosurfactants, four fluorosurfactant manufacturers, two toll manufacturers of fluorosurfactants and seven current (including National Foam and Angus Fire) and former (including the Company) AFFF manufacturers.

- added (2021-10-28):
[0001783180-21-000065:note_history:13]
General liability discovery in the MDL Proceedings continues. The parties are also currently conducting preliminary stage discovery with respect to ten "bellwether" water provider cases, which are scheduled to conclude by October 2021. At that point, the MDL Court intends to reduce that pool to three cases, after which the parties will conduct expanded fact and expert discovery and pursue dispositive motions, followed by trials to commence in 2023. The MDL Court has established a briefing schedule with respect to certain aspects of the government contractor defense, potentially applicable to AFFF sold to or used by the U.S. federal government or other customers requiring product manufactured to meet military specification, such that all briefs will be filed by late January 2022 with a hearing to follow thereafter.

- added (2021-10-28):
[0001783180-21-000065:note_history:14]
Outside of the MDL Proceedings, the Company and other defendants are also party to six lawsuits in U.S. state courts brought by oil refining companies alleging product liability claims related to legacy sales of AFFF and seeking damages for the costs to replace the product and for property damage. In addition, the Company and other defendants are party to two actions related to the Pennsylvania Site in which the plaintiff water utility seeks remediation costs related to the alleged contamination of the local water supply.

- added (2021-10-28):
[0001783180-21-000065:note_history:15]
The Company believes that it has meritorious defenses to the claims in the MDL Proceedings and the other AFFF lawsuits. Based on the 2013 agreement for the sale of National Foam and Angus Fire, the Company is pursuing indemnification against these claims from the purchaser and current owner of National Foam and Angus Fire. The Company is also pursuing insurance coverage for these claims. At this time, however, given the numerous factual, scientific and legal issues to be resolved relating

- added (2021-10-28):
[0001783180-21-000065:note_history:16]
to these claims, the Company is unable to assess the probability of liability or to reasonably estimate the damages, if any, to be allocated to the Company, if one or more plaintiffs were to prevail in these cases, and there can be no assurance that any such future exposure will not be material in any period.

- changed (2021-10-28):
[0001783180-21-000065:note_history:17]
Under the TMA, the Company is responsible to UTC for its share of the Tax Cuts and Jobs Act ("TCJA") transition tax associated with foreign undistributed earnings as of December 31, 2017. As a result, a liability of $453 million is included within the accompanying Unaudited Condensed Consolidated Balance Sheet as of September 30, 2021. This obligation is expected to be settled in annual installments ending in April 2026 with the next installment of $36 million included within Accrued Liabilities. The Company believes that the likelihood of incurring losses materially in excess of this amount is remote.
  (was, 2021-07-29, similarity 0.983):
[0001783180-21-000050:note_history:17]
Under the TMA, the Company is responsible to UTC for its share of the Tax Cuts and Jobs Act ("TCJA") transition tax associated with foreign undistributed earnings as of December 31, 2017. As a result, a liability of $453 million is included within the accompanying Unaudited Condensed Consolidated Balance Sheet at June 30, 2021. This obligation is expected to be settled in annual installments ending in April 2026 with the next installment of $36 million included within Accrued Liabilities. The Company believes that the likelihood of incurring losses materially in excess of this amount is remote.

- removed (2021-10-28):
[0001783180-21-000050:note_history:18]
On August 12, 2020, several former employees of UTC or its subsidiaries filed a putative class action complaint (the "Complaint") in the United States District Court for the District of Connecticut against Raytheon Technologies Corporation, Carrier, Otis, the former members of the UTC Board of Directors and the members of the Carrier and Otis Boards of Directors (Geraud Darnis, et al. v. Raytheon Technologies Corporation, et al.). The Complaint challenges the method by which UTC equity awards were converted to UTC, Carrier and Otis equity awards following the Separation and the Distribution. The Complaint asserted that the defendants are liable for breach of certain equity compensation plans and for breach of fiduciary duty and also asserted claims under certain provisions of the Employee Retirement Income Security Act of 1974, as amended. Plaintiffs have withdrawn, with prejudice, their claims against Otis's and Carrier's current Boards of Directors. Carrier believes that the remaining claims against the Company are without merit.

- removed (2021-10-28):
[0001783180-21-000050:note_history:19]
Aqueous Film Forming Foam ("AFFF") is a firefighting foam developed in the 1970s pursuant to U.S. military specification and used to extinguish certain types of fires primarily at airports and military bases. AFFF was manufactured by several companies, including National Foam and Angus Fire. UTC acquired the National Foam and Angus Fire businesses in 2005 as part of the acquisition of Kidde, which had been operated by Carrier. In 2013, UTC divested the National Foam and Angus Fire businesses to a third party.

- removed (2021-10-28):
[0001783180-21-000050:note_history:20]
The Company and many other parties, including the third-party buyer of the National Foam and Angus Fire businesses, have been named as defendants in over 1,300 cases, including putative class actions and other lawsuits, alleging that the historic use of AFFF caused personal injuries and property damage. Additionally, several state, municipal and water utility plaintiffs have commenced litigation against the same defendants to recover remediation costs related to historic use of AFFF. In December 2018, the U.S. Judicial Panel on Multidistrict Litigation ("MDL") transferred and consolidated all of the AFFF cases pending in the federal courts to the U.S. District Court for the District of South Carolina for pre-trial proceedings.

- removed (2021-10-28):
[0001783180-21-000050:note_history:21]
Plaintiffs in the MDL allege that a chemical ingredient in AFFF contains, or breaks down into, compounds known as perflourooctane sulfonate ("PFOS") and perflourooctane acid ("PFOA") that were released into the environment and, in some instances, ultimately leached into drinking water supplies. National Foam and Angus Fire purchased these perflourinated chemical ingredients from third-party chemical manufacturers to manufacture AFFF. Chemicals containing PFOS and PFOA (or their precursors) have also been used for decades by many third parties to manufacture carpets, clothing, fabrics, cookware and other consumer products. The individual plaintiffs in the MDL generally seek compensatory damages for alleged personal injuries, medical monitoring and diminution in property value and injunctive relief to remediate alleged contamination of water supplies. The U.S., state, municipal and water utility plaintiffs in the MDL generally seek damages and costs related to the remediation of public property and water supplies.

- removed (2021-10-28):
[0001783180-21-000050:note_history:22]
The Company and other defendants are also party to fewer than 10 cases in state court brought by oil refining companies in the U.S. alleging product liability claims related to legacy sales of AFFF and seeking damages for the costs to replace the product and for property damage.

- removed (2021-10-28):
[0001783180-21-000050:note_history:23]
The Company and other defendants are also party to an action related to the AFFF manufacturing facility that was operated by National Foam and Angus Fire in which the plaintiff water utility seeks remediation costs related to the alleged contamination of the local water supply.

- removed (2021-10-28):
[0001783180-21-000050:note_history:24]
The Company believes that it has meritorious defenses to these claims and the Company is also seeking insurance coverage for these claims. At this time, however, given the numerous factual, scientific and legal issues to be resolved relating to these claims, the Company is unable to assess the probability of liability or reasonably estimate the damages, if any, to be allocated to the Company, if one or more plaintiffs were to prevail in these cases, and there can be no assurance that any such future exposure will not be material in any period.


## us-gaap:ScheduleOfEnvironmentalLossContingenciesBySiteTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2021-10-28):
[0001783180-21-000065:note_history:25]
| (In millions) |  | September 30,2021 |  | December 31, 2020 |
| Environmental reserves included in Accrued liabilities |  | $ | 19 |  |  | $ | 26 |  |
| Environmental reserves included in Other long-term liabilities |  | 202 |  |  | 213 |  |
| Total Environmental reserves |  | $ | 221 |  |  | $ | 239 |  |
  (was, 2021-07-29, similarity 0.976):
[0001783180-21-000050:note_history:25]
| (In millions) |  | June 30,2021 |  | December 31, 2020 |
| Environmental reserves included in Accrued liabilities |  | $ | 25 |  |  | $ | 26 |  |
| Environmental reserves included in Other long-term liabilities |  | 209 |  |  | 213 |  |
| Total Environmental reserves |  | $ | 234 |  |  | $ | 239 |  |


## us-gaap:ScheduleOfLossContingenciesByContingencyTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2021-10-28):
[0001783180-21-000065:note_history:26]
| (In millions) |  | September 30,2021 |  | December 31,2020 |
| Asbestos liabilities included in Accrued liabilities |  | $ | 17 |  |  | $ | 17 |  |
| Asbestos liabilities included in Other long-term liabilities |  | 221 |  |  | 228 |  |
| Total Asbestos liabilities |  | $ | 238 |  |  | $ | 245 |  |
| Asbestos-related recoveries included in Other assets, current |  | $ | 5 |  |  | $ | 6 |  |
| Asbestos-related recoveries included in Other assets |  | 93 |  |  | 97 |  |
| Total Asbestos-related recoveries |  | $ | 98 |  |  | $ | 103 |  |
  (was, 2021-07-29, similarity 0.9867):
[0001783180-21-000050:note_history:26]
| (In millions) |  | June 30,2021 |  | December 31,2020 |
| Asbestos liabilities included in Accrued liabilities |  | $ | 18 |  |  | $ | 17 |  |
| Asbestos liabilities included in Other long-term liabilities |  | 222 |  |  | 228 |  |
| Total Asbestos liabilities |  | $ | 240 |  |  | $ | 245 |  |
| Asbestos-related recoveries included in Other assets, current |  | $ | 6 |  |  | $ | 6 |  |
| Asbestos-related recoveries included in Other assets |  | 95 |  |  | 97 |  |
| Total Asbestos-related recoveries |  | $ | 101 |  |  | $ | 103 |  |


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2021-10-28):
[0001783180-21-000065:note_history:27]
Held for Sale

- added (2021-10-28):
[0001783180-21-000065:note_history:28]
On July 26, 2021, the Company entered into a stock purchase agreement to sell its Chubb Fire and Security business ("Chubb") to APi Group Corporation ("APi"). The transaction is expected to close late in the fourth quarter of 2021 or early in the first quarter of 2022, subject to regulatory approvals, required works council approval in France and customary closing conditions. In accordance with U.S. GAAP, the assets and liabilities of Chubb have been classified as held for sale on the accompanying Unaudited Condensed Consolidated Balance Sheet as of September 30, 2021 and recorded at the lower of their carrying value or fair value less estimated cost to sell. See Note 16 - Divestitures for additional information.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2021-10-28):
[0001783180-21-000065:note_history:29]
In connection with the Separation, the Company entered into several agreements with UTC and Otis Worldwide Corporation ("Otis") that govern various aspects of the relationship among the Company, UTC and Otis following the Separation and the Distribution, including a transition services agreement ("TSA"), a tax matters agreement ("TMA"), an employee matters agreement and an intellectual property agreement that cover services such as information technology, tax, finance and human resources. In addition, the Company incurred separation-related costs including employee-related costs, costs to establish certain stand-alone functions, information technology systems, professional service fees and other costs associated with becoming an independent, publicly traded company. These costs are primarily recorded in Selling, general and administrative in the Unaudited Condensed Consolidated Statement of Operations and totaled $24 million for the three months ended September 30, 2020. Costs for the nine months ended September 30, 2021 and 2020 were $19 million and $92 million, respectively. The TSA expired on March 31, 2021.
  (was, 2021-07-29, similarity 0.8997):
[0001783180-21-000050:note_history:29]
In connection with the Separation, the Company entered into several agreements with UTC and Otis Worldwide Corporation ("Otis") that govern various aspects of the relationship among the Company, UTC and Otis following the Separation and the Distribution, including a transition services agreement ("TSA"), a tax matters agreement ("TMA"), an employee matters agreement and an intellectual property agreement that cover services such as information technology, tax, finance and human resources. In addition, the Company incurred separation-related costs including employee-related costs, costs to establish certain stand-alone functions, information technology systems, professional service fees and other costs associated with becoming an independent, publicly traded company. These costs are primarily recorded in Selling, general and administrative in the Unaudited Condensed Consolidated Statement of Operations and totaled $3 million and $23 million for the three months ended June 30, 2021 and 2020, respectively. Costs for the six months ended June 30, 2021 and 2020 were $19 million and $68 million, respectively. The TSA expired on March 31, 2021.

- changed (2021-10-28):
[0001783180-21-000065:note_history:30]
In early 2020, the World Health Organization declared the outbreak of a respiratory disease known as COVID-19 as a global pandemic. In response, many countries implemented containment and mitigation measures to combat the outbreak, which severely restricted the level of economic activity and caused a significant contraction in the global economy. As a result, the Company temporarily closed or reduced production at manufacturing facilities across the globe to ensure employee safety and instructed non-essential employees to work from home. In addition, the Company took several preemptive actions during 2020 to manage liquidity as demand for its products decreased. Despite the adverse impacts of the pandemic on the Company’s results beginning in the first quarter of 2020, manufacturing operations resumed and several restorative actions were completed during 2020, including the reinstatement of annual merit-based salary increases and continued investment to support the Company's strategic priorities.
  (was, 2021-07-29, similarity 0.9834):
[0001783180-21-000050:note_history:30]
In early 2020, the World Health Organization declared the outbreak of a respiratory disease known as COVID-19 as a global pandemic. In response, many countries implemented containment and mitigation measures to combat the outbreak, which severely restricted the level of economic activity and caused a significant contraction in the global economy. As a result, the Company temporarily closed or reduced production at manufacturing facilities across the globe to ensure employee safety and instructed non-essential employees to work from home. In addition, the Company took several preemptive actions during 2020 to manage liquidity as demand for its products decreased. Despite the adverse impacts of the pandemic on the Company’s results beginning in the first quarter of 2020, manufacturing operations resumed and several restorative actions were completed during 2020, including the reinstatement of annual merit-based salary increases and continued investment to support the Company's core strategy.

- changed (2021-10-28):
[0001783180-21-000065:note_history:31]
The Company continues to focus its efforts on preserving the health and safety of its employees and customers as well as maintaining the continuity of its operations. In addition, the Company continues to actively monitor its liquidity position and working capital needs and believes that its overall capital resources and liquidity position are adequate. The preparation of financial statements requires management to use judgments in making estimates and assumptions based on the relevant information available at the end of each period, which can have a significant effect on reported amounts. However, due to significant uncertainty surrounding the pandemic, including a resurgence in cases and the spread of COVID-19 variants, management's judgments could change. While the Company's results of operations, cash flows and financial condition could be negatively impacted, the extent of any continuing impact cannot be estimated with certainty at this time.
  (was, 2021-07-29, similarity 0.7214):
[0001783180-21-000050:note_history:31]
The Company continues to focus its efforts on preserving the health and safety of its employees and customers as well as maintaining the continuity of its operations. In addition, the Company continues to actively monitor its liquidity position and working capital needs and believes that its overall capital resources and liquidity position are adequate. The preparation of financial statements requires management to use judgments in making estimates and assumptions based on the relevant information available at the end of each period, which can have a significant effect on reported amounts. However, due to significant uncertainty surrounding the pandemic, management's judgments could change. While the Company's results of operations, cash flows and financial condition could be negatively impacted, the extent of any continuing impact cannot be estimated with certainty at this time.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-10-28):
[0001783180-21-000065:note_history:32]
| (In millions) |  |  |  | September 30,2021 |  | December 31,2020 |
| 1.923% Notes due February 15, 2023 |  |  |  | $ | — |  | (1) | $ | 500 |  |
| 2.242% Notes due February 15, 2025 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.493% Notes due February 15, 2027 |  |  |  | 1,250 |  |  | 1,250 |  |
| 2.722% Notes due February 15, 2030 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.700% Notes due February 15, 2031 |  |  |  | 750 |  |  | 750 |  |
| 3.377% Notes due April 5, 2040 |  |  |  | 1,500 |  |  | 1,500 |  |
| 3.577% Notes due April 5, 2050 |  |  |  | 2,000 |  |  | 2,000 |  |
| Total long-term Notes |  |  |  | 9,500 |  |  | 10,000 |  |
| Other debt (including project financing obligations and finance leases) |  |  |  | 261 |  |  | 308 |  |
| Discounts and debt issuance costs |  |  |  | (73) |  |  | (81) |  |
| Total debt |  |  |  | 9,688 |  |  | 10,227 |  |
| Less: current portion of long-term debt |  |  |  | 130 |  |  | 191 |  |
| Long-term debt, net of current portion |  |  |  | $ | 9,558 |  |  | $ | 10,036 |  |
  (was, 2021-07-29, similarity 0.9791):
[0001783180-21-000050:note_history:32]
| (In millions, except percentages) |  |  |  | June 30,2021 |  | December 31,2020 |
| 1.923% Notes due February 15, 2023 |  |  |  | $ | — |  | (1) | $ | 500 |  |
| 2.242% Notes due February 15, 2025 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.493% Notes due February 15, 2027 |  |  |  | 1,250 |  |  | 1,250 |  |
| 2.722% Notes due February 15, 2030 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.700% Notes due February 15, 2031 |  |  |  | 750 |  |  | 750 |  |
| 3.377% Notes due April 5, 2040 |  |  |  | 1,500 |  |  | 1,500 |  |
| 3.577% Notes due April 5, 2050 |  |  |  | 2,000 |  |  | 2,000 |  |
| Total long-term Notes |  |  |  | 9,500 |  |  | 10,000 |  |
| Other debt (including project financing obligations and finance leases) |  |  |  | 300 |  |  | 308 |  |
| Discounts and debt issuance costs |  |  |  | (75) |  |  | (81) |  |
| Total debt |  |  |  | 9,725 |  |  | 10,227 |  |
| Less: current portion of long-term debt |  |  |  | 125 |  |  | 191 |  |
| Long-term debt, net of current portion |  |  |  | $ | 9,600 |  |  | $ | 10,036 |  |

- changed (2021-10-28):
[0001783180-21-000065:note_history:33]
(1) In February 2021, the Company prepaid the 1.923% Notes due in February 2023 and incurred a $17 million make-whole premium upon prepayment and wrote-off $2 million of the remaining unamortized deferred financing costs
  (was, 2021-07-29, similarity 0.9976):
[0001783180-21-000050:note_history:33]
(1) In February 2021, the Company prepaid the 1.923% Notes due in February 2023 and incurred a $17 million make-whole premium upon prepayment and wrote-off $2 million of the remaining unamortized deferred financing costs.

- changed (2021-10-28):
[0001783180-21-000065:note_history:34]
On February 10, 2020, the Company entered into a revolving credit agreement with various banks permitting aggregate borrowings of up to $2.0 billion pursuant to an unsecured, unsubordinated revolving credit facility that matures on April 3, 2025 (the "Revolving Credit Facility"). The Revolving Credit Facility supports the Company's commercial paper program and cash requirements of the Company. A commitment fee of 0.125% is charged on unused commitments. Borrowings under the Revolving Credit Facility are available in U.S. Dollars, Euros and Pounds Sterling and bear interest at a variable interest rate based on LIBOR plus a ratings-based margin, which was 125 basis points as of September 30, 2021. As of September 30, 2021, there were no borrowings outstanding under the Revolving Credit Facility.
  (was, 2021-07-29, similarity 0.9688):
[0001783180-21-000050:note_history:34]
On February 10, 2020, the Company entered into a revolving credit agreement with various banks permitting aggregate borrowings of up to $2.0 billion pursuant to an unsecured, unsubordinated revolving credit facility that matures on April 3, 2025 (the "Revolving Credit Facility"). The Revolving Credit Facility supports the Company's commercial paper program and cash requirements of the Company. A commitment fee of 0.125% is charged on unused commitments. Borrowings under the Revolving Credit Facility are available in U.S. Dollars, Euros and Pounds Sterling and bear interest at a variable interest rate based on LIBOR plus a ratings-based margin, which was 125 basis points as of June 30, 2021. As of June 30, 2021, there were no borrowings outstanding under the Revolving Credit Facility.

- added (2021-10-28):
[0001783180-21-000065:note_history:35]
As of September 30, 2021, the Company had a $2.0 billion unsecured, unsubordinated commercial paper program, which can be used for general corporate purposes, including the funding of working capital and potential acquisitions. As of September 30, 2021, there were no borrowings outstanding under the commercial paper program.

- changed (2021-10-28):
[0001783180-21-000065:note_history:36]
The Company is involved in several long-term construction contracts in which it arranges project financing with certain customers. As a result, the Company issued $108 million and $102 million of debt during the nine months ended September 30, 2021 and 2020, respectively. Long-term debt repayments associated with these financing arrangements during the nine months ended September 30, 2021 and 2020 were $170 million and $124 million, respectively.
  (was, 2021-07-29, similarity 0.8854):
[0001783180-21-000050:note_history:36]
The Company is involved in several long-term construction contracts in which it arranges project financing with certain customers. As a result, the Company issued $71 million and $75 million of debt during the six months ended June 30, 2021 and 2020, respectively. Long-term debt repayments associated with these financing arrangements during the six months ended June 30, 2021 and 2020 were $83 million and $36 million, respectively.

- added (2021-10-28):
[0001783180-21-000065:note_history:37]
The Revolving Credit Facility and the indenture for the long-term notes contain affirmative and negative covenants customary for financings of these types which, among other things, limit the Company's ability to incur additional liens, to make certain fundamental changes and to enter into sale and leaseback transactions. On June 2, 2020, the Company entered into an amendment of the Revolving Credit Facility, under which certain terms of the facility were amended for a period beginning on June 2, 2020 and ending on December 30, 2021 (the "Covenant Modification"). The Company terminated the Covenant Modification effective as of August 27, 2021 in accordance with the procedure for termination set forth in the revolving credit agreement, which returned the consolidated leverage ratio covenant to the limit in effect prior to the Covenant Modification. As 
of September 30, 2021, the Company was in compliance with the covenants under the agreements governing its outstanding indebtedness.

- removed (2021-10-28):
[0001783180-21-000050:note_history:38]
As of June 30, 2021, the Company had a $2.0 billion unsecured, unsubordinated commercial paper program, which can be used for general corporate purposes, including the funding of working capital and potential acquisitions. As of June 30, 2021, there were no borrowings outstanding under the commercial paper program.

- removed (2021-10-28):
[0001783180-21-000050:note_history:39]
The Revolving Credit Facility and the indenture for the long-term notes contain affirmative and negative covenants customary for financings of these types which, among other things, limit the Company's ability to incur additional liens, to make certain fundamental changes and to enter into sale and leaseback transactions. On June 2, 2020, the Company entered into an amendment of the Revolving Credit Facility, under which certain terms of the facility were amended for a period beginning on June 2, 2020 and ending on December 30, 2021 (the "Covenant Modification Period"). The Company may terminate the Covenant Modification Period prior to December 30, 2021, subject to the satisfaction of certain conditions. The amendment deferred testing of the Company's consolidated total net leverage ratio financial covenant until June 30, 2021 and increases the consolidated total net leverage ratio limit until December 31, 2021. The amendment also required the Company to maintain 
liquidity at a certain level until the earlier of (1) June 29, 2021 and (2) the last day of the Covenant Modification Period. As of June 30, 2021 the requirement to test the Company's consolidated total net leverage ratio was reinstated, and there is no remaining requirement to maintain liquidity at a certain level. Additionally, during the Covenant Modification Period, the Company is subject to: (a) limitations on the incurrence of subsidiary indebtedness, (b) limitations on the making of restricted payments, including purchases by the Company of shares of its common stock and the amount of dividends the Company may pay and (c) a "most favored nations" provision related to certain terms of any committed credit facility in an amount greater than $100 million. As of June 30, 2021, the Company was in compliance with the covenants under the agreements governing its outstanding indebtedness.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-10-28):
[0001783180-21-000065:note_history:40]
| (In millions) |  |  |  | September 30,2021 |  | December 31,2020 |
| 1.923% Notes due February 15, 2023 |  |  |  | $ | — |  | (1) | $ | 500 |  |
| 2.242% Notes due February 15, 2025 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.493% Notes due February 15, 2027 |  |  |  | 1,250 |  |  | 1,250 |  |
| 2.722% Notes due February 15, 2030 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.700% Notes due February 15, 2031 |  |  |  | 750 |  |  | 750 |  |
| 3.377% Notes due April 5, 2040 |  |  |  | 1,500 |  |  | 1,500 |  |
| 3.577% Notes due April 5, 2050 |  |  |  | 2,000 |  |  | 2,000 |  |
| Total long-term Notes |  |  |  | 9,500 |  |  | 10,000 |  |
| Other debt (including project financing obligations and finance leases) |  |  |  | 261 |  |  | 308 |  |
| Discounts and debt issuance costs |  |  |  | (73) |  |  | (81) |  |
| Total debt |  |  |  | 9,688 |  |  | 10,227 |  |
| Less: current portion of long-term debt |  |  |  | 130 |  |  | 191 |  |
| Long-term debt, net of current portion |  |  |  | $ | 9,558 |  |  | $ | 10,036 |  |
  (was, 2021-07-29, similarity 0.9791):
[0001783180-21-000050:note_history:40]
| (In millions, except percentages) |  |  |  | June 30,2021 |  | December 31,2020 |
| 1.923% Notes due February 15, 2023 |  |  |  | $ | — |  | (1) | $ | 500 |  |
| 2.242% Notes due February 15, 2025 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.493% Notes due February 15, 2027 |  |  |  | 1,250 |  |  | 1,250 |  |
| 2.722% Notes due February 15, 2030 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.700% Notes due February 15, 2031 |  |  |  | 750 |  |  | 750 |  |
| 3.377% Notes due April 5, 2040 |  |  |  | 1,500 |  |  | 1,500 |  |
| 3.577% Notes due April 5, 2050 |  |  |  | 2,000 |  |  | 2,000 |  |
| Total long-term Notes |  |  |  | 9,500 |  |  | 10,000 |  |
| Other debt (including project financing obligations and finance leases) |  |  |  | 300 |  |  | 308 |  |
| Discounts and debt issuance costs |  |  |  | (75) |  |  | (81) |  |
| Total debt |  |  |  | 9,725 |  |  | 10,227 |  |
| Less: current portion of long-term debt |  |  |  | 125 |  |  | 191 |  |
| Long-term debt, net of current portion |  |  |  | $ | 9,600 |  |  | $ | 10,036 |  |

- changed (2021-10-28):
[0001783180-21-000065:note_history:41]
(1) In February 2021, the Company prepaid the 1.923% Notes due in February 2023 and incurred a $17 million make-whole premium upon prepayment and wrote-off $2 million of the remaining unamortized deferred financing costs
  (was, 2021-07-29, similarity 0.9976):
[0001783180-21-000050:note_history:41]
(1) In February 2021, the Company prepaid the 1.923% Notes due in February 2023 and incurred a $17 million make-whole premium upon prepayment and wrote-off $2 million of the remaining unamortized deferred financing costs.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- added (2021-10-28):
[0001783180-21-000065:note_history:42]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
| (In millions) |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Sales to equity method investees included in Product sales |  | $ | 556 |  |  | $ | 576 |  |  | $ | 1,675 |  |  | $ | 1,400 |  |
| Purchases from equity method investees included in Cost of products sold |  | $ | 93 |  |  | $ | 70 |  |  | $ | 266 |  |  | $ | 213 |  |

- added (2021-10-28):
[0001783180-21-000065:note_history:43]
| (In millions) |  | September 30,2021 |  | December 31, 2020 |
| Receivables from equity method investees included in Accounts receivable, net |  | $ | 253 |  |  | $ | 161 |  |
| Payables to equity method investees included in Accounts payable |  | $ | 55 |  |  | $ | 38 |  |

- removed (2021-10-28):
[0001783180-21-000050:note_history:44]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
| (In millions) |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Sales to equity method investees included in Product sales |  | $ | 652 |  |  | $ | 434 |  |  | $ | 1,120 |  |  | $ | 778 |  |
| Purchases from equity method investees included in Cost of products sold |  | $ | 98 |  |  | $ | 66 |  |  | $ | 174 |  |  | $ | 143 |  |

- removed (2021-10-28):
[0001783180-21-000050:note_history:45]
| (In millions) |  | June 30,2021 |  | December 31, 2020 |
| Receivables from equity method investees included in Accounts receivable, net |  | $ | 243 |  |  | $ | 161 |  |
| Payables to equity method investees included in Accounts payable |  | $ | 59 |  |  | $ | 38 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-10-28):
[0001783180-21-000065:note_history:46]
|  |  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
| (In millions) |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Sales Type |  |  |  |  |  |  |  |  |
| Product |  | $ | 2,702 |  |  | $ | 2,547 |  |  | $ | 7,606 |  |  | $ | 6,180 |  |
| Service |  | 352 |  |  | 345 |  |  | 1,054 |  |  | 962 |  |
| HVAC sales |  | 3,054 |  |  | 2,892 |  |  | 8,660 |  |  | 7,142 |  |
| Product |  | 894 |  |  | 771 |  |  | 2,701 |  |  | 2,093 |  |
| Service |  | 117 |  |  | 105 |  |  | 336 |  |  | 291 |  |
| Refrigeration sales |  | 1,011 |  |  | 876 |  |  | 3,037 |  |  | 2,384 |  |
| Product |  | 1,012 |  |  | 965 |  |  | 2,943 |  |  | 2,587 |  |
| Service |  | 365 |  |  | 359 |  |  | 1,141 |  |  | 1,000 |  |
| Fire & Security sales |  | 1,377 |  |  | 1,324 |  |  | 4,084 |  |  | 3,587 |  |
| Total segment sales |  | 5,442 |  |  | 5,092 |  |  | 15,781 |  |  | 13,113 |  |
| Eliminations and other |  | (101) |  |  | (90) |  |  | (301) |  |  | (251) |  |
| Net sales |  | $ | 5,341 |  |  | $ | 5,002 |  |  | $ | 15,480 |  |  | $ | 12,862 |  |
  (was, 2021-07-29, similarity 0.9559):
[0001783180-21-000050:note_history:46]
|  |  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
| (In millions) |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Sales Type |  |  |  |  |  |  |  |  |
| Product |  | $ | 2,757 |  |  | $ | 1,976 |  |  | $ | 4,904 |  |  | $ | 3,633 |  |
| Service |  | 363 |  |  | 315 |  |  | 702 |  |  | 617 |  |
| HVAC sales |  | 3,120 |  |  | 2,291 |  |  | 5,606 |  |  | 4,250 |  |
| Product |  | 915 |  |  | 609 |  |  | 1,807 |  |  | 1,322 |  |
| Service |  | 106 |  |  | 91 |  |  | 219 |  |  | 186 |  |
| Refrigeration sales |  | 1,021 |  |  | 700 |  |  | 2,026 |  |  | 1,508 |  |
| Product |  | 1,012 |  |  | 762 |  |  | 1,931 |  |  | 1,622 |  |
| Service |  | 391 |  |  | 295 |  |  | 776 |  |  | 641 |  |
| Fire & Security sales |  | 1,403 |  |  | 1,057 |  |  | 2,707 |  |  | 2,263 |  |
| Total segment sales |  | 5,544 |  |  | 4,048 |  |  | 10,339 |  |  | 8,021 |  |
| Eliminations and other |  | (104) |  |  | (76) |  |  | (200) |  |  | (161) |  |
| Net sales |  | $ | 5,440 |  |  | $ | 3,972 |  |  | $ | 10,139 |  |  | $ | 7,860 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-10-28):
[0001783180-21-000065:note_history:47]
|  |  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
| (In millions) |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Sales Type |  |  |  |  |  |  |  |  |
| Product |  | $ | 2,702 |  |  | $ | 2,547 |  |  | $ | 7,606 |  |  | $ | 6,180 |  |
| Service |  | 352 |  |  | 345 |  |  | 1,054 |  |  | 962 |  |
| HVAC sales |  | 3,054 |  |  | 2,892 |  |  | 8,660 |  |  | 7,142 |  |
| Product |  | 894 |  |  | 771 |  |  | 2,701 |  |  | 2,093 |  |
| Service |  | 117 |  |  | 105 |  |  | 336 |  |  | 291 |  |
| Refrigeration sales |  | 1,011 |  |  | 876 |  |  | 3,037 |  |  | 2,384 |  |
| Product |  | 1,012 |  |  | 965 |  |  | 2,943 |  |  | 2,587 |  |
| Service |  | 365 |  |  | 359 |  |  | 1,141 |  |  | 1,000 |  |
| Fire & Security sales |  | 1,377 |  |  | 1,324 |  |  | 4,084 |  |  | 3,587 |  |
| Total segment sales |  | 5,442 |  |  | 5,092 |  |  | 15,781 |  |  | 13,113 |  |
| Eliminations and other |  | (101) |  |  | (90) |  |  | (301) |  |  | (251) |  |
| Net sales |  | $ | 5,341 |  |  | $ | 5,002 |  |  | $ | 15,480 |  |  | $ | 12,862 |  |
  (was, 2021-07-29, similarity 0.9559):
[0001783180-21-000050:note_history:47]
|  |  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
| (In millions) |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Sales Type |  |  |  |  |  |  |  |  |
| Product |  | $ | 2,757 |  |  | $ | 1,976 |  |  | $ | 4,904 |  |  | $ | 3,633 |  |
| Service |  | 363 |  |  | 315 |  |  | 702 |  |  | 617 |  |
| HVAC sales |  | 3,120 |  |  | 2,291 |  |  | 5,606 |  |  | 4,250 |  |
| Product |  | 915 |  |  | 609 |  |  | 1,807 |  |  | 1,322 |  |
| Service |  | 106 |  |  | 91 |  |  | 219 |  |  | 186 |  |
| Refrigeration sales |  | 1,021 |  |  | 700 |  |  | 2,026 |  |  | 1,508 |  |
| Product |  | 1,012 |  |  | 762 |  |  | 1,931 |  |  | 1,622 |  |
| Service |  | 391 |  |  | 295 |  |  | 776 |  |  | 641 |  |
| Fire & Security sales |  | 1,403 |  |  | 1,057 |  |  | 2,707 |  |  | 2,263 |  |
| Total segment sales |  | 5,544 |  |  | 4,048 |  |  | 10,339 |  |  | 8,021 |  |
| Eliminations and other |  | (104) |  |  | (76) |  |  | (200) |  |  | (161) |  |
| Net sales |  | $ | 5,440 |  |  | $ | 3,972 |  |  | $ | 10,139 |  |  | $ | 7,860 |  |

- added (2021-10-28):
[0001783180-21-000065:note_history:48]
| (In millions) |  | September 30,2021 |  | December 31,2020 |
| Contract assets, current |  | $ | 502 |  |  | $ | 656 |  |
| Contract assets, non-current (included within Other assets) |  | 119 |  |  | 98 |  |
| Total contract assets |  | 621 |  |  | 754 |  |
| Contract liabilities, current |  | 418 |  |  | 512 |  |
| Contract liabilities, non-current (included within Other long-term liabilities) |  | 169 |  |  | 165 |  |
| Total contract liabilities |  | 587 |  |  | 677 |  |
| Net contract assets |  | $ | 34 |  |  | $ | 77 |  |

- changed (2021-10-28):
[0001783180-21-000065:note_history:49]
The timing of revenue recognition, billings and cash collections results in contract assets and contract liabilities. Contract assets relate to the conditional right to consideration for any completed performance under a contract when costs are incurred in excess of billings under the percentage-of-completion methodology. Contract liabilities relate to payments received in advance of performance under the contract or when the Company has a right to consideration that is conditioned upon transfer of a good or service to the customer. Contract liabilities are recognized as revenue as (or when) the Company performs under the contract. The Company recognized revenue of $337 million during the nine months ended September 30, 2021 that related to contract liabilities as of January 1, 2021. The Company expects a majority of its contract liabilities at the end of the period to be recognized as revenue in the next 12 months.
  (was, 2021-07-29, similarity 0.8072):
[0001783180-21-000050:note_history:49]
The timing of revenue recognition, billings and cash collections results in contract assets and contract liabilities. Contract assets relate to the conditional right to consideration for any completed performance under a contract when costs are incurred in excess of billings under the percentage-of-completion methodology. Contract liabilities relate to payments received in advance of performance under the contract or when the Company has a right to consideration that is conditioned upon transfer of a good or service to the customer. Contract liabilities are recognized as revenue as (or when) the Company performs under the contract. The Company recognized revenue of $100 million during the six months ended June 30, 2021 that related to contract liabilities  as of January 1, 2021. The Company expects a majority of its contract liabilities at the end of the period to be recognized as revenue in the next 12 months.

- removed (2021-10-28):
[0001783180-21-000050:note_history:50]
| (In millions) |  | June 30,2021 |  | December 31,2020 |
| Contract assets, current |  | $ | 695 |  |  | $ | 656 |  |
| Contract assets, non-current (included within Other assets) |  | 166 |  |  | 98 |  |
| Total contract assets |  | $ | 861 |  |  | $ | 754 |  |
| Contract liabilities, current |  | (576) |  |  | (512) |  |
| Contract liabilities, non-current (included within Other long-term liabilities) |  | (171) |  |  | (165) |  |
| Total contract liabilities |  | (747) |  |  | (677) |  |
| Net contract assets |  | $ | 114 |  |  | $ | 77 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2021-10-28):
[0001783180-21-000050:note_history:51]
SUBSEQUENT EVENTS 
Sale of Chubb Fire & Security Business

- removed (2021-10-28):
[0001783180-21-000050:note_history:52]
On July 26, 2021, the Company entered into an agreement to sell its Chubb Fire and Security business (Chubb) to APi Group Corporation (APi) for an enterprise value of $3.1 billion (the “Agreement”). The purchase price is subject to working capital and other adjustments as provided in the Agreement. Chubb, reported within the Company’s Fire & Security segment, delivers essential fire safety and security solutions from design and installation to monitoring, service and maintenance across more than 17 countries around the globe. At June 30, 2021, Chubb did not meet the criteria for assets held for sale in the Unaudited Condensed Consolidated Balance Sheet. On a prospective basis, the net assets of Chubb will be classified as held for sale until the divestiture is completed. This transaction is expected to close late in the fourth quarter of 2021 or early in the first quarter of 2022, subject to regulatory approvals, required works council consultation in France and customary closing conditions. Based on the carrying amount of Chubb’s net assets, foreign currency translation rates and other assumptions at June 30, 2021, the Company expects to recover the carrying value of the disposal group upon completion of the transaction. In conjunction with the Agreement, the Company has agreed to provide APi, and APi has agreed to provide the Company, certain transitional services for varying periods after the closing.

- removed (2021-10-28):
[0001783180-21-000050:note_history:53]
Share Repurchase Program
On July 27, 2021, the Company's Board of Directors approved a $1.75 billion increase to the Company's existing $350 million stock repurchase program authorized in February 2021. Share repurchases may take place from time to time subject to market conditions and at the Company's discretion in the open market or through one or more other public or private transactions.
