# CARR 8-K — 0001783180-21-000062 filed 2021-10-28

## item codes, every 8-K on or before 2021-10-28

- 2021-10-28 0001783180-21-000062 — 2.02, 9.01
- 2021-08-27 0001783180-21-000056 — 8.01
- 2021-07-30 0001783180-21-000053 — 1.01
- 2021-07-29 0001783180-21-000049 — 2.02, 8.01, 9.01
- 2021-07-27 0000950142-21-002448 — 8.01, 9.01
- 2021-07-15 0000950142-21-002362 — 5.02, 9.01
- 2021-06-09 0000950142-21-001885 — 5.02, 9.01
- 2021-04-29 0001783180-21-000029 — 2.02, 9.01
- 2021-04-22 0001140361-21-013889 — 5.02, 9.01
- 2021-04-20 0001783180-21-000021 — 5.07, 9.01
- 2021-04-19 0000950142-21-001308 — 8.01, 9.01
- 2021-02-09 0001783180-21-000009 — 2.02, 9.01
- 2021-02-05 0001140361-21-003513 — 8.01, 9.01
- 2020-12-23 0001140361-20-029419 — 7.01, 9.01
- 2020-12-22 0001140361-20-029097 — 8.01
- 2020-12-14 0001140361-20-028246 — 5.03, 9.01
- 2020-12-07 0001140361-20-027515 — 1.01, 7.01, 9.01
- 2020-10-29 0001783180-20-000063 — 2.02, 9.01
- 2020-10-19 0001140361-20-023241 — 5.02, 7.01, 9.01
- 2020-09-23 0001140361-20-021220 — 8.01, 9.01
- 2020-09-22 0001140361-20-021124 — 8.01, 9.01
- 2020-07-30 0001783180-20-000045 — 2.02, 9.01
- 2020-06-19 0001140361-20-014325 — 1.01, 2.03, 9.01
- 2020-06-16 0001140361-20-013880 — 8.01, 9.01
- 2020-06-03 0001140361-20-012939 — 1.01, 9.01
- 2020-05-08 0001783180-20-000013 — 2.02, 9.01
- 2020-04-03 0001140361-20-007888 — 1.01, 5.02, 5.03, 5.05, 7.01, 9.01
- 2020-03-16 0001140361-20-005868 — 8.01, 9.01

## late-filing notifications on or before 2021-10-28

- none on or before 2021-10-28

## item 2.02 — earnings release, exhibit 99.1

[0001783180-21-000062:8k_2_02:1]
EX-99.1
2
a991-q32021earningsexhibit.htm
EX-99.1

[0001783180-21-000062:8k_2_02:2]
Document

[0001783180-21-000062:8k_2_02:3]
Exhibit 99

[0001783180-21-000062:8k_2_02:4]
Carrier Reports Third Quarter 2021 Results

[0001783180-21-000062:8k_2_02:5]
Raising outlook to the high-end of prior adjusted earnings per share guidance

[0001783180-21-000062:8k_2_02:6]
•Sales of $5.3 billion, up 7% compared to 2020 including 4% organic growth

[0001783180-21-000062:8k_2_02:7]
•GAAP EPS of $0.53 and adjusted EPS of $0.71

[0001783180-21-000062:8k_2_02:8]
•Net cash flow from operating activities of $579 million and free cash flow of $505 million

[0001783180-21-000062:8k_2_02:9]
•Raising full-year 2021 projected organic sales growth to ~16%, ~13% organic*

[0001783180-21-000062:8k_2_02:10]
•Raising full-year 2021 projected adjusted EPS to ~$2.20 from a range of $2.10 to $2.20*

[0001783180-21-000062:8k_2_02:11]
•Reaffirming full-year 2021 projected free cash flow of ~$1.9 billion*

[0001783180-21-000062:8k_2_02:12]
PALM BEACH GARDENS, Fla., October 28, 2021 – Carrier Global Corporation (NYSE:CARR) today reported financial results for the third quarter of 2021 and updated its full year outlook. Carrier is the leading global provider of healthy, safe, sustainable and intelligent building and cold chain solutions.

[0001783180-21-000062:8k_2_02:13]
“We delivered a strong quarter driven by continued growth across our portfolio,” said Carrier Chairman & CEO David Gitlin. “Our results demonstrate continued robust demand and reinforce our positive long-term outlook. Despite supply chain challenges impacting our input costs and factory output, our team has gone to great lengths to deliver superior products and solutions to our customers. We are helping to address critical societal needs, including climate change, indoor air quality, and the safe distribution of food and vaccines. Our future growth will be driven by our differentiated products and solutions, which are supported by secular tailwinds propelling our healthy, safe, sustainable and intelligent building and cold chain solutions.”

[0001783180-21-000062:8k_2_02:14]
1

[0001783180-21-000062:8k_2_02:15]
Third Quarter 2021 Results

[0001783180-21-000062:8k_2_02:16]
Carrier’s third quarter sales of $5.3 billion were up 7% compared to the prior year and organic sales were up 4% over the same period. Sales strength continued in the HVAC segment, with strong light commercial and aftermarket sales performance offsetting the expected modest North American residential HVAC decline in the quarter. Organic sales growth of 14% for the Refrigeration segment was driven by strong Transport refrigeration growth. Fire and Security sales were up 2% organically driven by Fire and Security products growth. All segments were impacted by cost and availability headwinds related to supply chain challenges. GAAP operating profit in the quarter of $828 million was down 23% from last year and adjusted operating profit of $858 million was down 1%. These results reflect higher volume and price realization offset by increased supply chain costs and the absence of prior year cost containment activities related to the COVID-19 pandemic. GAAP operating profit comparisons were also impacted by the absence of a 2020 gain on the sale of Beijer shares held as an investment.

[0001783180-21-000062:8k_2_02:17]
Net income was $469 million, and adjusted net income was $630 million. GAAP EPS of $0.53 and adjusted EPS of $0.71 included about a $0.05 benefit from a lower adjusted effective tax rate. Net cash flows provided by operating activities were $579 million and capital expenditures were $74 million, resulting in free cash flow of $505 million.

[0001783180-21-000062:8k_2_02:18]
Updated Full-Year 2021 Outlook*

[0001783180-21-000062:8k_2_02:19]
Carrier’s updated outlook for 2021 is as follows including Chubb results:

[0001783180-21-000062:8k_2_02:20]
|  |  | Updated Outlook |  | Prior Outlook |
|  |  | Up ~16% Y/Y |  | Up 14% - 16% Y/Y |
| Sales |  | Organic * +~13% Y/Y |  | Organic * +10% - 12% Y/Y |
|  |  | Acquisitions +1% Y/Y |  | Acquisitions +1% Y/Y |
|  |  | FX +2% Y/Y |  | FX +3% Y/Y |
| Adjusted Operating Margin * |  | >13.5% |  | >13.5% |
| Adjusted EPS * |  | ~$2.20 |  | $2.10 - $2.20 |
|  |  | Adjusted Effective Tax Rate* ~22% |  | Adjusted Effective Tax Rate* ~24% |
| Free Cash Flow * |  | ~$1.9B |  | ~$1.9B |

[0001783180-21-000062:8k_2_02:21]
2

[0001783180-21-000062:8k_2_02:22]
*Note: When the company provides expectations for organic sales, adjusted operating profit, adjusted operating margin, adjusted effective tax rate, incremental margins / earnings conversion, adjusted EPS and free cash flow on a forward-looking basis, a reconciliation of the differences between the non-GAAP expectations and the corresponding GAAP measures generally is not available without unreasonable effort. See “Use and Definitions of Non-GAAP Financial Measures” below for additional information.

[0001783180-21-000062:8k_2_02:23]
Conference Call

[0001783180-21-000062:8k_2_02:24]
Carrier will host a webcast of its earnings conference call today, Thursday, October 28, 2021, at 8:30 a.m. ET. To access the webcast, visit the Events & Presentations section of the Carrier Investor Relations site at ir.carrier.com/news-and-events/events-and-presentations or to listen to the earnings call by phone, dial (877) 742-9091.

[0001783180-21-000062:8k_2_02:25]
About Carrier

[0001783180-21-000062:8k_2_02:26]
As the leading global provider of healthy, safe, sustainable and intelligent building and cold chain solutions, Carrier Global Corporation is committed to making the world safer, sustainable and more comfortable for generations to come. From the beginning, we've led in inventing new technologies and entirely new industries. Today, we continue to lead because we have a world-class, diverse workforce that puts the customer at the center of everything we do. For more information, www.corporate.carrier.com or follow Carrier on social media at @Carrier.

[0001783180-21-000062:8k_2_02:27]
Cautionary Statement

[0001783180-21-000062:8k_2_02:28]
This communication contains statements which, to the extent they are not statements of historical or present fact, constitute "forward-looking statements" under the securities laws. These forward-looking statements are intended to provide management's current expectations or plans for Carrier's future operating and financial performance, based on assumptions currently believed to be valid. Forward-looking statements can be identified by the use of words such as "believe," "expect," "expectations," "plans," "strategy," "prospects," "estimate," "project," "target," "anticipate," "will," "should," "see," "guidance," "outlook," "confident," "scenario" and other words of similar meaning in connection with a discussion of future operating or financial performance or the separation from United Technologies Corporation (the "Separation"), since renamed Raytheon Technologies Corporation. Forward-looking statements may include, among other things, statements relating to future sales, earnings, cash flow, results of operations, uses of cash, share repurchases, tax rates and other measures of financial performance or potential future plans, strategies or transactions of Carrier, the estimated costs associated with the Separation, Carrier's plans with respect to its indebtedness and other statements that are not historical facts. All forward-looking statements involve risks, uncertainties and other factors that may cause actual results to differ materially from those expressed or implied in the forward-looking statements. For additional information on identifying factors that may cause actual results to vary materially from those stated in forward-looking statements, see Carrier's reports on Forms 10-K, 10-Q

[0001783180-21-000062:8k_2_02:29]
3

[0001783180-21-000062:8k_2_02:30]
and 8-K filed with or furnished to the U.S. Securities and Exchange Commission from time to time. Any forward-looking statement speaks only as of the date on which it is made, and Carrier assumes no obligation to update or revise such statement, whether as a result of new information, future events or otherwise, except as required by applicable law.

[0001783180-21-000062:8k_2_02:31]
Contact:                        Media Inquiries

[0001783180-21-000062:8k_2_02:32]
Danielle Canzanella

[0001783180-21-000062:8k_2_02:33]
561-365-1101

[0001783180-21-000062:8k_2_02:34]
Danielle.Canzanella@Carrier.com

[0001783180-21-000062:8k_2_02:35]
Investor Relations

[0001783180-21-000062:8k_2_02:36]
Sam Pearlstein

[0001783180-21-000062:8k_2_02:37]
561-365-2251

[0001783180-21-000062:8k_2_02:38]
Sam.Pearlstein@Carrier.com

[0001783180-21-000062:8k_2_02:39]
4

[0001783180-21-000062:8k_2_02:40]
SELECTED FINANCIAL DATA, NON-GAAP MEASURES AND DEFINITIONS

[0001783180-21-000062:8k_2_02:41]
Following are tables that present selected financial data of Carrier Global Corporation (“Carrier”). Also included are reconciliations of non-GAAP measures to their most comparable GAAP measures.

[0001783180-21-000062:8k_2_02:42]
Use and Definitions of Non-GAAP Financial Measures

[0001783180-21-000062:8k_2_02:43]
Carrier reports its financial results in accordance with accounting principles generally accepted in the United States ("GAAP").

[0001783180-21-000062:8k_2_02:44]
We supplement the reporting of our financial information determined under GAAP with certain non-GAAP financial information. The non-GAAP information presented provides investors with additional useful information, but should not be considered in isolation or as substitutes for the related GAAP measures. Moreover, other companies may define non-GAAP measures differently, which limits the usefulness of these measures for comparisons with such other companies. We encourage investors to review our financial statements and publicly filed reports in their entirety and not to rely on any single financial measure. A reconciliation of the non-GAAP measures to the corresponding amounts prepared in accordance with GAAP appears in the tables attached to this release. The tables provide additional information as to the items and amounts that have been excluded from the adjusted measures.

[0001783180-21-000062:8k_2_02:45]
Organic sales, adjusted operating profit, adjusted operating margin, incremental margins / earnings conversion, earnings before interest, taxes and depreciation and amortization (“EBITDA”), adjusted EBITDA, adjusted net income, adjusted earnings per share (“EPS”), the adjusted effective tax rate, and net debt are non-GAAP financial measures.

[0001783180-21-000062:8k_2_02:46]
Organic sales represents consolidated net sales (a GAAP measure), excluding the impact of foreign currency translation, acquisitions and divestitures completed in the preceding twelve months and other significant items of a nonoperational nature (hereinafter referred to as “other significant items”). Adjusted operating profit represents operating profit (a GAAP measure), excluding restructuring costs and other significant items. Adjusted operating margin represents adjusted operating profit as a percentage of net sales (a GAAP measure). Incremental margins / earnings conversion represents the year-over-year change in adjusted operating profit divided by the year-over-year change in net sales. EBITDA represents net income attributable to common shareholders (a GAAP measure), adjusted for interest income and expense, income tax expense, and depreciation and amortization. Adjusted EBITDA represents EBITDA, as calculated above, excluding non-service pension benefit, non-controlling interest in subsidiaries’ earnings from operations, restructuring costs and other significant items. Adjusted net income represents net income attributable to common shareowners (a GAAP measure), excluding restructuring costs and other significant items. Adjusted EPS represents diluted earnings per share (a GAAP measure), excluding restructuring costs and other significant items. The adjusted effective tax rate represents the effective tax rate (a GAAP measure), excluding restructuring costs and other significant items. Net debt represents long-term debt (a GAAP measure) less cash and cash equivalents. For the business segments, when applicable, adjustments of operating profit and operating margins represent operating profit, excluding restructuring and other significant items.

[0001783180-21-000062:8k_2_02:47]
Free cash flow is a non-GAAP financial measure that represents net cash flows provided by operating activities (a GAAP measure) less capital expenditures. Management believes free cash flow is a useful measure of liquidity and an additional basis for assessing Carrier’s ability to fund its activities, including the financing of acquisitions, debt service, repurchases of Carrier's common stock and distribution of earnings to shareowners.

[0001783180-21-000062:8k_2_02:48]
When we provide our expectations for organic sales, adjusted operating profit, adjusted operating margin, adjusted effective tax rate, incremental margins/earnings conversion, adjusted EPS and free cash flow on a forward-looking basis, a reconciliation of the differences between the non-GAAP expectations and the corresponding GAAP measures (expected net sales, operating profit, operating margin, effective tax rate, incremental operating margin, diluted EPS and net cash flows provided by operating activities) generally is not available without unreasonable effort due to potentially high variability, complexity and low visibility as to the items that would be excluded from the GAAP measure in the relevant future period, such as unusual gains and losses, the ultimate outcome of pending litigation, fluctuations in foreign currency exchange rates, the impact and timing of potential acquisitions and divestitures, future restructuring costs, and other structural changes or their probable significance. The variability of the excluded items may have a significant, and potentially unpredictable, impact on our future GAAP results.

[0001783180-21-000062:8k_2_02:49]
5

[0001783180-21-000062:8k_2_02:50]
Carrier Global Corporation

[0001783180-21-000062:8k_2_02:51]
Condensed Consolidated Statement of Operations

[0001783180-21-000062:8k_2_02:52]
|  | (Unaudited) |
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
| (dollars in millions, except per share amounts; shares in millions) | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Net sales: |  |  |  |  |  |  |  |
| Product sales | $ | 4,510 |  |  | $ | 4,193 |  |  | $ | 12,958 |  |  | $ | 10,615 |  |
| Service sales | 831 |  |  | 809 |  |  | 2,522 |  |  | 2,247 |  |
| Total Net sales | 5,341 |  |  | 5,002 |  |  | 15,480 |  |  | 12,862 |  |
| Costs and expenses |  |  |  |  |  |  |  |
| Cost of products sold | (3,172) |  |  | (2,884) |  |  | (9,131) |  |  | (7,464) |  |
| Cost of services sold | (568) |  |  | (557) |  |  | (1,735) |  |  | (1,574) |  |
| Research and development | (123) |  |  | (100) |  |  | (369) |  |  | (292) |  |
| Selling, general and administrative | (748) |  |  | (681) |  |  | (2,304) |  |  | (2,010) |  |
| Total Costs and expenses | (4,611) |  |  | (4,222) |  |  | (13,539) |  |  | (11,340) |  |
| Equity method investment net earnings | 76 |  |  | 62 |  |  | 201 |  |  | 148 |  |
| Other income (expense), net | 22 |  |  | 239 |  |  | 40 |  |  | 168 |  |
| Operating profit | 828 |  |  | 1,081 |  |  | 2,182 |  |  | 1,838 |  |
| Non-service pension (expense) benefit | 14 |  |  | 16 |  |  | 51 |  |  | 47 |  |
| Interest (expense) income, net | (74) |  |  | (88) |  |  | (238) |  |  | (206) |  |
| Income from operations before income taxes | 768 |  |  | 1,009 |  |  | 1,995 |  |  | 1,679 |  |
| Income tax (expense) benefit | (288) |  |  | (261) |  |  | (626) |  |  | (560) |  |
| Net income from operations | 480 |  |  | 748 |  |  | 1,369 |  |  | 1,119 |  |
| Less: Non-controlling interest in subsidiaries' earnings from operations | 11 |  |  | 7 |  |  | 29 |  |  | 21 |  |
| Net income attributable to common shareowners | $ | 469 |  |  | $ | 741 |  |  | $ | 1,340 |  |  | $ | 1,098 |  |
| Earnings per share (1), (2) |  |  |  |  |  |  |  |
| Basic | $ | 0.54 |  |  | $ | 0.86 |  |  | $ | 1.54 |  |  | $ | 1.27 |  |
| Diluted | $ | 0.53 |  |  | $ | 0.84 |  |  | $ | 1.50 |  |  | $ | 1.25 |  |
| Weighted average number of shares outstanding (2) |  |  |  |  |  |  |  |
| Basic | 867.6 |  | 866.4 |  | 868.6 |  | 866.3 |
| Diluted | 892.0 |  | 881.5 |  | 890.9 |  | 876.2 |

[0001783180-21-000062:8k_2_02:53]
(1) On April 3, 2020, United Technologies Corporation, since renamed Raytheon Technologies Corporation ("UTC"), completed the spin-off of Carrier into a separate publicly traded company (the "Separation"). The Separation was completed through a pro-rata distribution (the "Distribution") of all of the outstanding common stock of the Company to UTC shareowners who held shares of UTC common stock as of the close of business on March 19, 2020.

[0001783180-21-000062:8k_2_02:54]
(2) Basic and diluted earnings per share for the nine months ended September 30, 2020 are calculated using the weighted-average number of common shares outstanding for the period beginning after the Distribution date. Diluted earnings per share is computed by giving effect to all potentially dilutive stock awards that are outstanding. For periods prior to the Separation it was assumed that there were no dilutive equity instruments as there were no equity awards in Carrier common stock outstanding prior to the Separation.

[0001783180-21-000062:8k_2_02:55]
6

[0001783180-21-000062:8k_2_02:56]
Carrier Global Corporation

[0001783180-21-000062:8k_2_02:57]
Condensed Consolidated Balance Sheet

[0001783180-21-000062:8k_2_02:58]
|  |  | (Unaudited) |
|  |  | As of |
| (dollars in millions) |  | September 30, 2021 |  | December 31, 2020 |
| Assets |  |  |  |  |
| Cash and cash equivalents |  | $ | 2,671 |  |  | $ | 3,115 |  |
| Accounts receivable, net |  | 2,669 |  |  | 2,781 |  |
| Contract assets, current |  | 502 |  |  | 656 |  |
| Inventories, net |  | 1,926 |  |  | 1,629 |  |
| Assets held for sale |  | 3,148 |  |  | — |  |
| Other assets, current |  | 384 |  |  | 343 |  |
| Total current assets |  | 11,300 |  |  | 8,524 |  |
| Future income tax benefits |  | 456 |  |  | 449 |  |
| Fixed assets, net |  | 1,764 |  |  | 1,810 |  |
| Operating lease right-of-use assets |  | 626 |  |  | 788 |  |
| Intangible assets, net |  | 481 |  |  | 1,037 |  |
| Goodwill |  | 9,237 |  |  | 10,139 |  |
| Pension and post-retirement assets |  | 25 |  |  | 554 |  |
| Equity method investments |  | 1,619 |  |  | 1,513 |  |
| Other assets |  | 280 |  |  | 279 |  |
| Total Assets |  | $ | 25,788 |  |  | $ | 25,093 |  |
| Liabilities and Equity |  |  |  |  |
| Accounts payable |  | $ | 2,158 |  |  | $ | 1,936 |  |
| Accrued liabilities |  | 2,260 |  |  | 2,471 |  |
| Contract liabilities, current |  | 418 |  |  | 512 |  |
| Liabilities held for sale |  | 1,102 |  |  | — |  |
| Current portion of long-term debt |  | 130 |  |  | 191 |  |
| Total current liabilities |  | 6,068 |  |  | 5,110 |  |
| Long-term debt |  | 9,558 |  |  | 10,036 |  |
| Future pension and post-retirement obligations |  | 416 |  |  | 524 |  |
| Future income tax obligations |  | 331 |  |  | 479 |  |
| Operating lease liabilities |  | 515 |  |  | 642 |  |
| Other long-term liabilities |  | 1,678 |  |  | 1,724 |  |
| Total Liabilities |  | 18,566 |  |  | 18,515 |  |
| Equity |  |  |  |  |
| Common stock |  | 9 |  |  | 9 |  |
| Treasury stock |  | (276) |  |  | — |  |
| Additional paid-in capital |  | 5,384 |  |  | 5,345 |  |
| Retained earnings |  | 2,774 |  |  | 1,643 |  |
| Accumulated other comprehensive loss |  | (991) |  |  | (745) |  |
| Non-controlling interest |  | 322 |  |  | 326 |  |
| Total Equity |  | 7,222 |  |  | 6,578 |  |
| Total Liabilities and Equity |  | $ | 25,788 |  |  | $ | 25,093 |  |

[0001783180-21-000062:8k_2_02:59]
7

[0001783180-21-000062:8k_2_02:60]
Carrier Global Corporation

[0001783180-21-000062:8k_2_02:61]
Condensed Consolidated Statement of Cash Flows

[0001783180-21-000062:8k_2_02:62]
|  |  |  |  | (Unaudited) |
|  |  |  | For the Nine Months Ended September 30, |
| (dollars in millions) |  |  |  |  | 2021 |  | 2020 |
| Operating Activities |  |  |  |  |  |  |  |
| Net income from operations |  |  |  |  | $ | 1,369 |  |  | $ | 1,119 |  |
| Adjustments to reconcile net income to net cash flows from operating activities: |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  |  |  | 251 |  |  | 241 |  |
| Deferred income tax provision |  |  |  |  | 69 |  |  | 121 |  |
| Stock-based compensation costs |  |  |  |  | 60 |  |  | 56 |  |
| Equity method investment net earnings |  |  |  |  | (201) |  |  | (148) |  |
| Distributions from equity method investments |  |  |  |  | 65 |  |  | 88 |  |
| Impairment charge on minority-owned joint venture investments |  |  |  |  | 2 |  |  | 72 |  |
| (Gain) loss on sale of investments |  |  |  |  | (4) |  |  | (252) |  |
| Changes in operating assets and liabilities |  |  |  |  |  |  |  |
| Accounts receivable, net |  |  |  |  | (290) |  |  | (117) |  |
| Contract assets, current |  |  |  |  | (66) |  |  | (120) |  |
| Inventories, net |  |  |  |  | (344) |  |  | (237) |  |
| Other assets, current |  |  |  |  | (20) |  |  | 52 |  |
| Accounts payable and accrued liabilities |  |  |  |  | 496 |  |  | 529 |  |
| Contract liabilities, current |  |  |  |  | 43 |  |  | 44 |  |
| Defined benefit plan contributions |  |  |  |  | (29) |  |  | (29) |  |
| Other operating activities, net |  |  |  |  | (77) |  |  | 74 |  |
| Net cash flows provided by (used in) operating activities |  |  |  |  | 1,324 |  |  | 1,493 |  |
| Investing Activities |  |  |  |  |  |  |  |
| Capital expenditures |  |  |  |  | (206) |  |  | (151) |  |
| Investments in businesses, net of cash acquired |  |  |  |  | (214) |  |  | — |  |
| Disposition of businesses |  |  |  |  | 3 |  |  | — |  |
| Proceeds on sale of investments |  |  |  |  | — |  |  | 300 |  |
| Settlement of derivative contracts, net |  |  |  |  | (18) |  |  | 67 |  |
| Other investing activities, net |  |  |  |  | 9 |  |  | 14 |  |
| Net cash flows provided by (used in) investing activities |  |  |  |  | (426) |  |  | 230 |  |
| Financing Activities |  |  |  |  |  |  |  |
| Increase (decrease) in short-term borrowings, net |  |  |  |  | (17) |  |  | (22) |  |
| Issuance of long-term debt |  |  |  |  | 122 |  |  | 11,762 |  |
| Repayment of long-term debt |  |  |  |  | (692) |  |  | (124) |  |
| Repurchases of common stock |  |  |  |  | (275) |  |  | — |  |
| Dividends paid on common stock |  |  |  |  | (313) |  |  | (70) |  |
| Dividends paid to non-controlling interest |  |  |  |  | (32) |  |  | (17) |  |
| Net transfers to UTC |  |  |  |  | — |  |  | (10,359) |  |
| Other financing activities, net |  |  |  |  | (18) |  |  | 3 |  |
| Net cash flows provided by (used in) financing activities |  |  |  |  | (1,225) |  |  | 1,173 |  |
| Effect of foreign exchange rate changes on cash and cash equivalents |  |  |  |  | (15) |  |  | — |  |
| Net increase (decrease) in cash and cash equivalents and restricted cash |  |  |  |  | (342) |  |  | 2,896 |  |
| Less: Change in cash balances classified as assets held for sale |  |  |  |  | 74 |  |  | — |  |
| Cash, cash equivalents and restricted cash, beginning of period |  |  |  |  | 3,120 |  |  | 957 |  |
| Cash, cash equivalents and restricted cash, end of period |  |  |  |  | 2,704 |  |  | 3,853 |  |
| Less: restricted cash |  |  |  |  | 33 |  |  | 5 |  |
| Cash and cash equivalents, end of period |  |  |  |  | $ | 2,671 |  |  | $ | 3,848 |  |

[0001783180-21-000062:8k_2_02:63]
8

[0001783180-21-000062:8k_2_02:64]
Carrier Global Corporation

[0001783180-21-000062:8k_2_02:65]
Segment Net Sales and Operating Profit Reported (GAAP) to Adjusted (Non-GAAP)

[0001783180-21-000062:8k_2_02:66]
|  | (Unaudited) |
|  | For the Three Months Ended September 30, |  | For the Nine Months Ended September 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| (In millions) | Reported |  | Adjusted |  | Reported |  | Adjusted |  | Reported |  | Adjusted |  | Reported |  | Adjusted |
| Net sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| HVAC | $ | 3,054 |  |  | $ | 3,054 |  |  | $ | 2,892 |  |  | $ | 2,892 |  |  | $ | 8,660 |  |  | $ | 8,660 |  |  | $ | 7,142 |  |  | $ | 7,142 |  |
| Refrigeration | 1,011 |  |  | 1,011 |  |  | 876 |  |  | 876 |  |  | 3,037 |  |  | 3,037 |  |  | 2,384 |  |  | 2,384 |  |
| Fire & Security | 1,377 |  |  | 1,377 |  |  | 1,324 |  |  | 1,324 |  |  | 4,084 |  |  | 4,084 |  |  | 3,587 |  |  | 3,587 |  |
| Segment sales | 5,442 |  |  | 5,442 |  |  | 5,092 |  |  | 5,092 |  |  | 15,781 |  |  | 15,781 |  |  | 13,113 |  |  | 13,113 |  |
| Eliminations and other | (101) |  |  | (101) |  |  | (90) |  |  | (90) |  |  | (301) |  |  | (301) |  |  | (251) |  |  | (251) |  |
| Net sales | $ | 5,341 |  |  | $ | 5,341 |  |  | $ | 5,002 |  |  | $ | 5,002 |  |  | $ | 15,480 |  |  | $ | 15,480 |  |  | $ | 12,862 |  |  | $ | 12,862 |  |
| Operating profit |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| HVAC | $ | 573 |  |  | $ | 583 |  | $ | 839 |  |  | $ | 598 |  |  | $ | 1,511 |  |  | $ | 1,534 |  |  | $ | 1,364 |  |  | $ | 1,199 |  |
| Refrigeration | 119 |  |  | 121 |  | 103 |  |  | 102 |  |  | 369 |  |  | 376 |  |  | 263 |  |  | 265 |  |
| Fire & Security | 182 |  |  | 198 |  | 200 |  |  | 204 |  |  | 480 |  |  | 531 |  |  | 426 |  |  | 442 |  |
| Segment operating profit | 874 |  |  | 902 |  | 1,142 |  |  | 904 |  |  | 2,360 |  |  | 2,441 |  |  | 2,053 |  |  | 1,906 |  |
| Eliminations and other | (10) |  |  | (10) |  | (31) |  |  | (9) |  |  | (73) |  |  | (56) |  |  | (122) |  |  | (40) |  |
| General corporate expenses | (36) |  |  | (34) |  | (30) |  |  | (28) |  |  | (105) |  |  | (98) |  |  | (93) |  |  | (87) |  |
| Operating profit | $ | 828 |  |  | $ | 858 |  | $ | 1,081 |  |  | $ | 867 |  |  | $ | 2,182 |  |  | $ | 2,287 |  |  | $ | 1,838 |  |  | $ | 1,779 |  |
| Operating margin |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| HVAC | 18.8 | % |  | 19.1 | % |  | 29.0 | % |  | 20.7 | % |  | 17.4 | % |  | 17.7 | % |  | 19.1 | % |  | 16.8 | % |
| Refrigeration | 11.8 | % |  | 12.0 | % |  | 11.8 | % |  | 11.6 | % |  | 12.2 | % |  | 12.4 | % |  | 11.0 | % |  | 11.1 | % |
| Fire & Security | 13.2 | % |  | 14.4 | % |  | 15.1 | % |  | 15.4 | % |  | 11.8 | % |  | 13.0 | % |  | 11.9 | % |  | 12.3 | % |
| Total Carrier | 15.5 | % |  | 16.1 | % |  | 21.6 | % |  | 17.3 | % |  | 14.1 | % |  | 14.8 | % |  | 14.3 | % |  | 13.8 | % |

[0001783180-21-000062:8k_2_02:67]
9

[0001783180-21-000062:8k_2_02:68]
Carrier Global Corporation

[0001783180-21-000062:8k_2_02:69]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP)

[0001783180-21-000062:8k_2_02:70]
Operating Profit

[0001783180-21-000062:8k_2_02:71]
|  |  | (Unaudited) |  |
|  |  | For the Three Months Ended |  | For the Nine Months Ended |  |
|  | September 30, |  | September 30, |  |
| (dollars in millions - Income (Expense)) | 2021 |  | 2020 |  | 2021 |  | 2020 |  |
| HVAC |  |  |  |  |  |
|  | Net sales | $ | 3,054 |  |  | $ | 2,892 |  |  | $ | 8,660 |  |  | $ | 7,142 |  |  |
|  | Operating profit | $ | 573 |  |  | $ | 839 |  |  | $ | 1,511 |  |  | $ | 1,364 |  |  |
|  | Restructuring | (7) |  |  | — |  |  | (18) |  |  | (3) |  |  |
|  | Gain on sales of joint venture | — |  |  | 252 |  |  | — |  |  | 252 |  |  |
|  | Impairment of joint venture investment | — |  |  | — |  |  | — |  |  | (71) |  |  |
|  | Separation costs | — |  |  | — |  |  | — |  |  | (2) |  |  |
|  | Charge resulting from litigation matter | — |  |  | (11) |  |  | — |  |  | (11) |  |  |
|  | Acquisition-related costs | (3) |  |  | — |  |  | (5) |  |  | — |  |  |
|  | Adjusted operating profit | $ | 583 |  |  | $ | 598 |  |  | $ | 1,534 |  |  | $ | 1,199 |  |  |
| Refrigeration |  |  |  |  |  |  |  |  |
|  | Net sales | $ | 1,011 |  |  | $ | 876 |  |  | $ | 3,037 |  |  | $ | 2,384 |  |  |
|  | Operating profit | $ | 119 |  |  | $ | 103 |  |  | $ | 369 |  |  | $ | 263 |  |  |
|  | Restructuring | (2) |  |  | 1 |  |  | (7) |  |  | (2) |  |  |
|  | Adjusted operating profit | $ | 121 |  |  | $ | 102 |  |  | $ | 376 |  |  | $ | 265 |  |  |
| Fire & Security |  |  |  |  |  |  |  |  |
|  | Net sales | $ | 1,377 |  |  | $ | 1,324 |  |  | $ | 4,084 |  |  | $ | 3,587 |  |  |
|  | Operating profit | $ | 182 |  |  | $ | 200 |  |  | $ | 480 |  |  | $ | 426 |  |  |
|  | Restructuring | (3) |  |  | (4) |  |  | (23) |  |  | (13) |  |  |
|  | Separation costs | — |  |  | — |  |  | — |  |  | (3) |  |  |
|  | Chubb transaction costs | (13) |  |  | — |  |  | (28) |  |  | — |  |  |
|  | Adjusted operating profit | $ | 198 |  |  | $ | 204 |  |  | $ | 531 |  |  | $ | 442 |  |  |
| General Corporate Expenses and Eliminations and Other |  |  |  |  |  |  |  |  |
|  | Net sales | $ | (101) |  |  | $ | (90) |  |  | $ | (301) |  |  | $ | (251) |  |  |
|  | Operating profit | $ | (46) |  |  | $ | (61) |  |  | $ | (178) |  |  | $ | (215) |  |  |
|  | Restructuring | (1) |  |  | — |  |  | (4) |  |  | (1) |  |  |
|  | Separation costs | — |  |  | (24) |  |  | (19) |  |  | (87) |  |  |
|  | Chubb transaction costs | (1) |  |  | — |  |  | (1) |  |  | — |  |  |
|  | Adjusted operating profit | $ | (44) |  |  | $ | (37) |  |  | $ | (154) |  |  | $ | (127) |  |  |
| Carrier |  |  |  |  |  |  |  |  |
|  | Net sales | $ | 5,341 |  |  | $ | 5,002 |  |  | $ | 15,480 |  |  | $ | 12,862 |  |  |
|  | Operating profit | $ | 828 |  |  | $ | 1,081 |  | $ | 2,182 |  |  | $ | 1,838 |  |
|  | Total restructuring costs | (13) |  |  | (3) |  |  | (52) |  |  | (19) |  |  |
|  | Total non-recurring and non-operational items | (17) |  |  | 217 |  |  | (53) |  |  | 78 |  |  |
|  | Adjusted operating profit | $ | 858 |  |  | $ | 867 |  |  | $ | 2,287 |  |  | $ | 1,779 |  |  |

[0001783180-21-000062:8k_2_02:72]
Carrier Global Corporation

[0001783180-21-000062:8k_2_02:73]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP) Results

[0001783180-21-000062:8k_2_02:74]
Net Income, Earnings Per Share, and Effective Tax Rate

[0001783180-21-000062:8k_2_02:75]
|  | (Unaudited) |
|  | For the Three Months Ended September 30, 2021 |  | For the Nine Months Ended September 30, 2021 |
| (In millions, except per share amounts) | Reported |  | Adjustments |  | Adjusted |  | Reported |  | Adjustments |  | Adjusted |
| Net sales | $ | 5,341 |  |  | $ | — |  |  | $ | 5,341 |  |  | $ | 15,480 |  |  | $ | — |  |  | $ | 15,480 |  |
| Operating profit | 828 |  |  | 30 |  | a | 858 |  |  | 2,182 |  |  | 105 |  | a | 2,287 |  |
| Operating margin | 15.5 | % |  |  |  | 16.1 | % |  | 14.1 | % |  |  |  | 14.8 | % |
| Income from operations before income taxes | 768 |  |  | 30 |  | a, b | 798 |  |  | 1,995 |  |  | 124 |  | a,b | 2,119 |  |
| Income tax expense | (288) |  |  | 131 |  | c | (157) |  |  | (626) |  |  | 160 |  | c | (466) |  |
| Income tax rate | 37.5 | % |  |  |  | 19.7 | % |  | 31.4 | % |  |  |  | 22.0 | % |
| Net income attributable to common shareowners | $ | 469 |  |  | $ | 161 |  |  | $ | 630 |  |  | $ | 1,340 |  |  | $ | 284 |  |  | $ | 1,624 |  |
| Summary of Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring costs |  |  | $ | 13 |  | a |  |  |  |  | $ | 52 |  | a |  |
| Separation costs |  |  | — |  | a |  |  |  |  | 19 |  | a |  |
| Acquisition-related costs |  |  | 3 |  | a |  |  |  |  | 5 |  | a |  |
| Chubb transaction costs |  |  | 14 |  | a |  |  |  |  | 29 |  | a |  |
| Debt prepayment costs |  |  | — |  | b |  |  |  |  | 19 |  | b |  |
| Total adjustments |  |  | $ | 30 |  |  |  |  |  |  | $ | 143 |  |  |  |
| Tax effect on adjustments above |  |  | $ | (5) |  |  |  |  |  |  | $ | (19) |  |  |  |
| Tax specific adjustments |  |  | 136 |  |  |  |  |  |  | 179 |  |  |  |
| Total tax adjustments |  |  | $ | 131 |  | c |  |  |  |  | $ | 160 |  | c |  |
| Shares outstanding - Diluted | 892.0 |  |  |  |  | 892.0 |  |  | 890.9 |  |  |  |  | 890.9 |  |
| Earnings per share - Diluted | $ | 0.53 |  |  |  |  | $ | 0.71 |  |  | $ | 1.50 |  |  |  |  | $ | 1.84 |  |

[0001783180-21-000062:8k_2_02:76]
11

[0001783180-21-000062:8k_2_02:77]
Carrier Global Corporation

[0001783180-21-000062:8k_2_02:78]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP) Results

[0001783180-21-000062:8k_2_02:79]
Net Income, Earnings Per Share, and Effective Tax Rate

[0001783180-21-000062:8k_2_02:80]
|  | (Unaudited) |
|  | For the Three Months Ended September 30, 2020 |  | For the Nine Months Ended September 30, 2020 |
| (In millions, except per share amounts) | Reported |  | Adjustments |  | Adjusted |  | Reported |  | Adjustments |  | Adjusted |
| Net sales | $ | 5,002 |  |  | $ | — |  |  | $ | 5,002 |  |  | $ | 12,862 |  |  | $ | — |  |  | $ | 12,862 |  |
| Operating profit | 1,081 |  |  | (214) |  | a | 867 |  |  | 1,838 |  |  | (59) |  | a | 1,779 |  |
| Operating margin | 21.6 | % |  |  |  | 17.3 | % |  | 14.3 | % |  |  |  | 13.8 | % |
| Income from operations before income taxes | 1,009 |  |  | (214) |  | a,b | 795 |  |  | 1,679 |  |  | (54) |  | a,b | 1,625 |  |
| Income tax expense | (261) |  |  | 63 |  | c | (198) |  |  | (560) |  |  | 138 |  | c | (422) |  |
| Income tax rate | 25.9 | % |  |  |  | 24.9 | % |  | 33.4 | % |  |  |  | 26.0 | % |
| Net income attributable to common shareowners | $ | 741 |  |  | $ | (151) |  |  | $ | 590 |  |  | $ | 1,098 |  |  | $ | 84 |  |  | $ | 1,182 |  |
| Summary of Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring costs |  |  | $ | 3 |  | a |  |  |  |  | $ | 19 |  | a |  |
| Gain on sale of joint venture |  |  | (252) |  | a |  |  |  |  | (252) |  | a |  |
| Impairment of equity method investment |  |  | — |  | a |  |  |  |  | 71 |  | a |  |
| Charge resulting from litigation matter |  |  | 11 |  | a |  |  |  |  | 11 |  | a |  |
| Separation costs |  |  | 24 |  | a |  |  |  |  | 92 |  | a |  |
| Debt issuance costs |  |  | — |  | b |  |  |  |  | 5 |  | b |  |
| Total adjustments |  |  | $ | (214) |  |  |  |  |  |  | $ | (54) |  |  |  |
| Tax effect on adjustments above |  |  | $ | 51 |  |  |  |  |  |  | $ | 29 |  |  |  |
| Tax specific adjustments |  |  | 12 |  |  |  |  |  |  | 109 |  |  |  |
| Total tax adjustments |  |  | $ | 63 |  | c |  |  |  |  | $ | 138 |  | c |  |
| Shares outstanding - Diluted | 881.5 |  |  |  |  | 881.5 |  |  | 876.2 |  |  |  |  | 876.2 |  |
| Earnings per share - Diluted | $ | 0.84 |  |  |  |  | $ | 0.67 |  |  | $ | 1.25 |  |  |  |  | $ | 1.35 |  |

[0001783180-21-000062:8k_2_02:81]
12

[0001783180-21-000062:8k_2_02:82]
Carrier Global Corporation

[0001783180-21-000062:8k_2_02:83]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP) Results

[0001783180-21-000062:8k_2_02:84]
Components of Changes in Net Sales

[0001783180-21-000062:8k_2_02:85]
| Three Months Ended September 30, 2021 Compared with Three Months Ended September 30, 2020 |
|  | (Unaudited) |
|  | Factors Contributing to Total % change in Net Sales |
|  | Organic |  | FX Translation |  | Acquisitions / Divestitures, net |  | Other |  | Total |
| HVAC | 2 | % |  | 1 | % |  | 3 | % |  | — | % |  | 6 | % |
| Refrigeration | 14 | % |  | 1 | % |  | — | % |  | — | % |  | 15 | % |
| Fire & Security | 2 | % |  | 2 | % |  | — | % |  | — | % |  | 4 | % |
| Consolidated | 4 | % |  | 1 | % |  | 2 | % |  | — | % |  | 7 | % |

[0001783180-21-000062:8k_2_02:86]
| Nine Months Ended September 30, 2021 Compared with Nine Months Ended September 30, 2020 |
|  | (Unaudited) |
|  | Factors Contributing to Total % change in Net Sales |
|  | Organic |  | FX Translation |  | Acquisitions / Divestitures, net |  | Other |  | Total |
| HVAC | 18 | % |  | 1 | % |  | 2 | % |  | — | % |  | 21 | % |
| Refrigeration | 23 | % |  | 4 | % |  | — | % |  | — | % |  | 27 | % |
| Fire & Security | 9 | % |  | 5 | % |  | — | % |  | — | % |  | 14 | % |
| Consolidated | 16 | % |  | 3 | % |  | 1 | % |  | — | % |  | 20 | % |

[0001783180-21-000062:8k_2_02:87]
Free Cash Flow Reconciliation

[0001783180-21-000062:8k_2_02:88]
|  |  | (Unaudited) |
|  |  | Q1 |  | Q2 |  | Q3 |  | Q4 |  | FY |  | Q1 |  | Q2 |  | Q3 |
| (dollars in millions) |  | 2020 |  | 2020 |  | 2020 |  | 2020 |  | 2020 |  | 2021 |  | 2021 |  | 2021 |
| Net cash flows provided by operating activities |  | $ | 47 |  |  | $ | 509 |  |  | $ | 937 |  |  | $ | 199 |  |  | $ | 1,692 |  |  | $ | 184 |  |  | $ | 561 |  |  | $ | 579 |  |
| Less: Capital expenditures |  | 48 |  |  | 46 |  |  | 57 |  |  | 161 |  | 312 |  |  | 53 |  |  | 79 |  |  | 74 |  |
| Free cash flow |  | $ | (1) |  |  | $ | 463 |  |  | $ | 880 |  |  | $ | 38 |  |  | $ | 1,380 |  |  | $ | 131 |  |  | $ | 482 |  |  | $ | 505 |  |

[0001783180-21-000062:8k_2_02:89]
Net Debt Reconciliation

[0001783180-21-000062:8k_2_02:90]
|  |  | (Unaudited) |
|  |  | As of |
| (dollars in millions) |  | September 30, 2021 |  | December 31, 2020 |
| Long-term debt |  | $ | 9,558 |  |  | $ | 10,036 |  |
| Current portion of long-term debt |  | 130 |  |  | 191 |  |
| Less: Cash and cash equivalents |  | 2,671 |  |  | 3,115 |  |
| Net debt |  | $ | 7,017 |  |  | $ | 7,112 |  |

[0001783180-21-000062:8k_2_02:91]
13
