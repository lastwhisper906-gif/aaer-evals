# CARR MD&A — 0001783180-21-000065


## mdna

[0001783180-21-000065:mdna:1]
[same as prior period, unchanged from 0001783180-21-000050:mdna:1]

[0001783180-21-000065:mdna:2]
[same as prior period, unchanged from 0001783180-21-000050:mdna:2]

[0001783180-21-000065:mdna:3]
[same as prior period, unchanged from 0001783180-21-000050:mdna:3]

[0001783180-21-000065:mdna:4]
[same as prior period, unchanged from 0001783180-21-000050:mdna:4]

[0001783180-21-000065:mdna:5]
Our worldwide operations are affected by global and regional industrial, economic and political factors and trends. These include the mega-trends of urbanization, climate change and increasing requirements for food safety driven by the food needs of our growing global population and the rising standards of living in emerging markets. We believe that our business segments are well positioned to benefit from favorable secular trends, including these mega-trends and from the strength of our industry-leading brands and track record of innovation. In addition, we regularly review our markets to proactively identify trends and adapt our strategies accordingly.

[0001783180-21-000065:mdna:6]
Our business is also affected by changes in the general level of economic activity, such as changes in business and consumer spending, construction and shipping activity as well as short-term economic factors such as currency fluctuations, commodity price volatility and supply disruptions. However, we continue to invest in our business, take pricing actions to mitigate supply chain and inflationary pressures, develop new products and services in order to remain competitive in our markets and use risk management strategies to mitigate various exposures. We believe that we have industry-leading global brands, which form the foundation of our business strategy. Coupled with our focus on growth, innovation and operational efficiency, we expect to drive long-term future growth and increased value for our shareowners.

[0001783180-21-000065:mdna:7]
[same as prior period, unchanged from 0001783180-21-000050:mdna:7]

[0001783180-21-000065:mdna:8]
Supply Chain Challenges

[0001783180-21-000065:mdna:9]
The ongoing global economic recovery from the COVID-19 pandemic has caused significant challenges for global supply chains resulting in inflationary cost pressures, component shortages and transportation delays. As a result, we have incurred incremental costs for commodities and components used in our products as well as component shortages that have negatively impacted our sales and results of operations. We expect that these challenges will continue to have an impact on our businesses for the foreseeable future.

[0001783180-21-000065:mdna:10]
We continue to take proactive steps to limit the impact of these challenges and are working closely with our suppliers to ensure availability of products and implement other cost savings initiatives. In addition, we continue to invest in our supply chain to improve its resilience with a focus on automation, dual sourcing of critical components and localized manufacturing when feasible. To date, there has been limited disruption to the availability of our products, though it is possible that more significant disruptions could occur if these supply chain challenges continue.

[0001783180-21-000065:mdna:11]
[same as prior period, unchanged from 0001783180-21-000050:mdna:8]

[0001783180-21-000065:mdna:12]
On July 26, 2021, we entered into a stock purchase agreement to sell our Chubb business to APi for an enterprise value of $3.1 billion. The purchase price is subject to working capital and other adjustments as provided in the Chubb Sale Agreement. Chubb, reported within our Fire & Security segment, delivers essential fire safety and security solutions from design and installation to monitoring, service and maintenance across more than 17 countries around the globe. This transaction is expected to close late in the fourth quarter of 2021 or early in the first quarter of 2022, subject to regulatory approvals, required works council approvals in France and customary closing conditions. In conjunction with the Chubb Sale Agreement, we have agreed to provide APi, and APi has agreed to provide us certain transitional services for varying periods after the closing. The services we will receive include tax and accounting support and information technology services for certain entities.

[0001783180-21-000065:mdna:13]
[same as prior period, unchanged from 0001783180-21-000050:mdna:12]

[0001783180-21-000065:mdna:14]
On April 3, 2020, UTC completed the Separation of Carrier into an independent, publicly traded company. In connection with the Separation, we issued an aggregate principal balance of $11.0 billion of debt and transferred approximately $10.9 billion of

[0001783180-21-000065:mdna:15]
cash to UTC on February 27, 2020 and March 27, 2020. In addition, we entered into several agreements with UTC and Otis that govern various aspects of the relationship among us, UTC and Otis following the Separation and the Distribution including the TSA (which expired on March 31, 2021), the TMA, an employee matters agreement and an intellectual property agreement. Income and expense under these agreements are not material. On April 1, 2020 and April 2, 2020, we received cash contributions totaling $590 million from UTC related to the Separation.

[0001783180-21-000065:mdna:16]
Our financial statements for periods prior to the Separation and the Distribution are prepared on a "carve-out" basis and include all amounts directly attributable to Carrier. Net cash transfers and other property transferred between UTC and us, including related party receivables and payables between us and other UTC affiliates, are presented as Net transfers to UTC. In addition, the financial statements include allocations of costs for administrative functions and services performed on our behalf by centralized groups within UTC. All allocations and estimates in the Unaudited Condensed Consolidated Financial Statements are based on assumptions that management believes are reasonable. Our financial statements for the periods subsequent to April 3, 2020 are consolidated financial statements based on the reported results of Carrier as a stand-alone company.

[0001783180-21-000065:mdna:17]
[same as prior period, unchanged from 0001783180-21-000050:mdna:15]

[0001783180-21-000065:mdna:18]
In early 2020, the World Health Organization declared the outbreak of a respiratory disease known as COVID-19 as a global pandemic. In response, many countries implemented containment and mitigation measures to combat the outbreak, which severely restricted the level of economic activity and caused a significant contraction in the global economy. As a result, we temporarily closed or reduced production at manufacturing facilities across the globe to ensure employee safety and instructed non-essential employees to work from home. In addition, we took several preemptive actions during 2020 to manage liquidity as demand for our products decreased. Despite the adverse impacts of the pandemic on our results beginning in the first quarter of 2020, manufacturing operations resumed and several restorative actions were completed during 2020 including the reinstatement of annual merit-based salary increases and continued investment to support our strategic priorities.

[0001783180-21-000065:mdna:19]
We continue to focus our efforts on preserving the health and safety of our employees and customers as well as maintaining the continuity of our operations. In addition, we continue to actively monitor our liquidity position and working capital needs and believe that our overall capital resources and liquidity position are adequate. The preparation of financial statements requires management to use judgments in making estimates and assumptions based on the relevant information available at the end of each period, which can have a significant effect on reported amounts. However, due to significant uncertainty surrounding the pandemic, including a resurgence in cases and the spread of COVID-19 variants, management's judgments could change. While our results of operations, cash flows and financial condition could be negatively impacted, the extent of any continuing impact cannot be estimated with certainty at this time.

[0001783180-21-000065:mdna:20]
[same as prior period, unchanged from 0001783180-21-000050:mdna:18]

[0001783180-21-000065:mdna:21]
[same as prior period, unchanged from 0001783180-21-000050:mdna:19]

[0001783180-21-000065:mdna:22]
[same as prior period, unchanged from 0001783180-21-000050:mdna:40]

[0001783180-21-000065:mdna:23]
[same as prior period, unchanged from 0001783180-21-000050:mdna:21]

[0001783180-21-000065:mdna:24]
Three Months Ended September 30, 2021 Compared with the Three Months Ended September 30, 2020

[0001783180-21-000065:mdna:25]
|  |  | For the Three Months Ended September 30, |  |  |  |  |  |  |
| (In millions) |  | 2021 |  | 2020 |  | Period Change |  | % Change |  |  |  |  |  |  |
| Net sales |  | $ | 5,341 |  |  | $ | 5,002 |  |  | $ | 339 |  |  | 7 | % |  |  |  |  |  |  |
| Cost of products and services sold |  | (3,740) |  |  | (3,441) |  |  | (299) |  |  | 9 | % |  |  |  |  |  |  |
| Gross margin |  | 1,601 |  |  | 1,561 |  |  | 40 |  |  | 3 | % |  |  |  |  |  |  |
| Operating expenses |  | (773) |  |  | (480) |  |  | (293) |  |  | 61 | % |  |  |  |  |  |  |
| Operating profit |  | 828 |  |  | 1,081 |  |  | (253) |  |  | (23) | % |  |  |  |  |  |  |
| Non-operating income (expenses), net |  | (60) |  |  | (72) |  |  | 12 |  |  | (17) | % |  |  |  |  |  |  |
| Income from operations before income taxes |  | 768 |  |  | 1,009 |  |  | (241) |  |  | (24) | % |  |  |  |  |  |  |
| Income tax expense |  | (288) |  |  | (261) |  |  | (27) |  |  | 10 | % |  |  |  |  |  |  |
| Net income from operations |  | 480 |  |  | 748 |  |  | (268) |  |  | (36) | % |  |  |  |  |  |  |
| Less: Non-controlling interest in subsidiaries' earnings from operations |  | 11 |  |  | 7 |  |  | 4 |  |  | 57 | % |  |  |  |  |  |  |
| Net income attributable to common shareowners |  | $ | 469 |  |  | $ | 741 |  |  | $ | (272) |  |  | (37) | % |  |  |  |  |  |  |

[0001783180-21-000065:mdna:26]
[same as prior period, unchanged from 0001783180-21-000050:mdna:24]

[0001783180-21-000065:mdna:27]
For the three months ended September 30, 2021, Net sales were $5.3 billion, a 7% increase compared with the same period of 2020. The components of the year-over-year change were as follows:

[0001783180-21-000065:mdna:28]
|  |  | For the Three Months Ended September 30, 2021 |  |  |  |  |  |  |
| Organic |  | 4 | % |  |  |  |  |  |  |
| Foreign currency translation |  | 1 | % |  |  |  |  |  |  |
| Acquisitions and divestitures, net |  | 2 | % |  |  |  |  |  |  |
| Total % change |  | 7 | % |  |  |  |  |  |  |

[0001783180-21-000065:mdna:29]
During the three months ended September 30, 2021, continued end-market recovery in each of our segments increased organic sales by 4% compared with the same period of 2020. The organic increase was primarily driven by our Refrigeration segment as strong demand for global transportation continued. Higher volume in our Commercial HVAC business and improved pricing in our North America residential and light commercial business benefited the HVAC segment. In addition, higher volume and pricing were the primary drivers of growth in the Fire & Security segment. However, the current global economic environment has led to supply chain constraints that impacted volume in each of our segments during the period. Refer to "Segment Review" below for a discussion of Net sales by segment.

[0001783180-21-000065:mdna:30]
[same as prior period, unchanged from 0001783180-21-000050:mdna:28]

[0001783180-21-000065:mdna:31]
For the three months ended September 30, 2021, gross margin was $1.6 billion, a 3% increase compared with the same period of 2020. The components were as follows:

[0001783180-21-000065:mdna:32]
|  |  | For the Three Months Ended September 30, |  |  |  |  |  |  |
| (In millions) |  | 2021 |  | 2020 |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 5,341 |  |  | $ | 5,002 |  |  |  |  |  |  |  |  |  |
| Cost of products and services sold |  | (3,740) |  |  | (3,441) |  |  |  |  |  |  |  |  |  |
| Gross margin |  | $ | 1,601 |  |  | $ | 1,561 |  |  |  |  |  |  |  |  |  |
| Percentage of net sales |  | 30.0 | % |  | 31.2 | % |  |  |  |  |  |  |  |  |

[0001783180-21-000065:mdna:33]
The increase in gross margin for the three months ended September 30, 2021 was primarily driven by continued improvement in the global economic environment during the current period and pricing improvements. Higher sales in each of our segments outpaced operational costs as we continued to focus on Carrier 700 cost containment actions. However, each of our segments has been impacted by the rising cost for commodities and components used in our products, supply chain constraints and higher freight costs. As a result, gross margin as a percentage of Net sales decreased by 120 basis points compared with the same period of 2020.

[0001783180-21-000065:mdna:34]
[same as prior period, unchanged from 0001783180-21-000050:mdna:33]

[0001783180-21-000065:mdna:35]
For the three months ended September 30, 2021, operating expenses, including Equity method investment net earnings, were $773 million, a 61% increase compared with the same period of 2020. The components were as follows:

[0001783180-21-000065:mdna:36]
|  |  | For the Three Months Ended September 30, |  |  |  |  |  |  |
| (In millions) |  | 2021 |  | 2020 |  |  |  |  |  |  |  |  |
| Selling, general and administrative |  | $ | (748) |  |  | $ | (681) |  |  |  |  |  |  |  |  |  |
| Research and development |  | (123) |  |  | (100) |  |  |  |  |  |  |  |  |  |
| Equity method investment net earnings |  | 76 |  |  | 62 |  |  |  |  |  |  |  |  |  |
| Other income (expense), net |  | 22 |  |  | 239 |  |  |  |  |  |  |  |  |  |
| Total operating expenses |  | $ | (773) |  |  | $ | (480) |  |  |  |  |  |  |  |  |  |
| Percentage of net sales |  | 14.5 | % |  | 9.6 | % |  |  |  |  |  |  |  |  |

[0001783180-21-000065:mdna:37]
For the three months ended September 30, 2021, Selling, general and administrative expenses were $748 million, a 10% increase compared with the same period of 2020. At the onset of the COVID-19 pandemic, we initiated various cost containment initiatives in order to help mitigate the impacts on our business, which included reducing discretionary spending, employee furloughs and temporarily closing or limiting the presence of our workforce in our facilities. As a result, the increase in Selling, general and administrative expense in the current period reflects the gradual return to our operational spending levels prior to the COVID-19 pandemic. In addition, higher compensation costs and restructuring charges along with transaction costs of $14 million associated with the planned divestiture of our Chubb business further contributed to the year-over-year increase. Costs associated with the Separation for the three months ended September 30, 2020 were $24 million.

[0001783180-21-000065:mdna:38]
[same as prior period, unchanged from 0001783180-21-000050:mdna:37]

[0001783180-21-000065:mdna:39]
Investments over which we do not exercise control, but have significant influence, are accounted for using the equity method of accounting. For the three months ended September 30, 2021, Equity method investment net earnings were $76 million, a 23% increase compared with the same period of 2020. The increase was primarily related to higher earnings in HVAC joint ventures in North America and Asia as end-markets improved compared with the prior period and the absence of a 2020 product performance matter at one of our HVAC joint ventures. These increases were partially offset by the reduction in earnings resulting from the sale of our investment in Beijer REF AB in 2020.

[0001783180-21-000065:mdna:40]
Other income (expense), net primarily includes the impact of gains and losses related to the sale of interests in our equity method investments, foreign currency gains and losses on transactions that are denominated in a currency other than an entity's functional currency and hedging-related activities. During the three months ended September 30, 2020, we realized a $252 million gain on sale of our investment in Beijer REF AB and recorded an $11 million charge resulting from a litigation matter. In addition, higher gains on hedging activities were recognized in the three months ended September 30, 2021 as compared with the same period of 2020.

[0001783180-21-000065:mdna:41]
[same as prior period, unchanged from 0001783180-21-000050:mdna:41]

[0001783180-21-000065:mdna:42]
For the three months ended September 30, 2021, Non-operating income (expenses), net was $60 million, a 17% decrease compared with the same period of 2020. The components were as follows:

[0001783180-21-000065:mdna:43]
|  |  | For the Three Months Ended September 30, |  |  |
| (In millions) |  | 2021 |  | 2020 |  |  |  |  |
| Non-service pension (expense) benefit |  | $ | 14 |  |  | $ | 16 |  |  |  |  |  |
| Interest expense |  | $ | (76) |  |  | $ | (90) |  |  |  |  |  |
| Interest income |  | 2 |  |  | 2 |  |  |  |  |  |
| Interest (expense) income, net |  | $ | (74) |  |  | $ | (88) |  |  |  |  |  |
| Non-operating income (expenses), net |  | $ | (60) |  |  | $ | (72) |  |  |  |  |  |

[0001783180-21-000065:mdna:44]
Non-operating income (expenses), net includes the results from activities other than normal business operations such as interest expense, interest income and the non-service components of pension and post-retirement obligations. Interest expense is affected by the amount of debt outstanding and the interest rates on that debt. For the three months ended September 30, 2021, Interest expense was $76 million, a 16% decrease compared with the same period in 2020. The decrease was primarily driven by the repayment of our $1.75 billion Term Loan Credit Facility in 2020 and the prepayment of the $500 million 1.923% Notes in February 2021. These amounts were partially offset by the issuance of $750 million of long-term notes in June 2020.

[0001783180-21-000065:mdna:45]
[same as prior period, unchanged from 0001783180-21-000050:mdna:45]

[0001783180-21-000065:mdna:46]
|  |  | For the Three Months Ended September 30, |  |  |  |
|  |  | 2021 |  | 2020 |  |  |  |  |  |  |  |
| Effective tax rate |  | 37.5 | % |  | 25.9 | % |  |  |  |  |  |  |  |

[0001783180-21-000065:mdna:47]
The increase in the effective tax rate for the three months ended September 30, 2021 compared with the same period of 2020 was driven by a net tax charge of $136 million primarily relating to the re-organizations and disentanglements of certain Chubb subsidiaries executed in advance of the planned divestiture of our Chubb business. The increase was partially offset by a favorable tax adjustment of $23 million due to foreign tax credits generated and expected to be utilized in the current year.

[0001783180-21-000065:mdna:48]
Nine Months Ended September 30, 2021 Compared with the Nine Months Ended September 30, 2020

[0001783180-21-000065:mdna:49]
|  |  | For the Nine Months Ended September 30, |  |  |  |  |  |  |
| (In millions) |  | 2021 |  | 2020 |  | Period Change |  | % Change |  |  |  |  |  |  |
| Net sales |  | $ | 15,480 |  |  | $ | 12,862 |  |  | $ | 2,618 |  |  | 20 | % |  |  |  |  |  |  |
| Cost of products and services sold |  | (10,866) |  |  | (9,038) |  |  | (1,828) |  |  | 20 | % |  |  |  |  |  |  |
| Gross margin |  | 4,614 |  |  | 3,824 |  |  | 790 |  |  | 21 | % |  |  |  |  |  |  |
| Operating expenses |  | (2,432) |  |  | (1,986) |  |  | (446) |  |  | 22 | % |  |  |  |  |  |  |
| Operating profit |  | 2,182 |  |  | 1,838 |  |  | 344 |  |  | 19 | % |  |  |  |  |  |  |
| Non-operating income (expenses), net |  | (187) |  |  | (159) |  |  | (28) |  |  | 18 | % |  |  |  |  |  |  |
| Income from operations before income taxes |  | 1,995 |  |  | 1,679 |  |  | 316 |  |  | 19 | % |  |  |  |  |  |  |
| Income tax expense |  | (626) |  |  | (560) |  |  | (66) |  |  | 12 | % |  |  |  |  |  |  |
| Net income from operations |  | 1,369 |  |  | 1,119 |  |  | 250 |  |  | 22 | % |  |  |  |  |  |  |
| Less: Non-controlling interest in subsidiaries' earnings from operations |  | 29 |  |  | 21 |  |  | 8 |  |  | 38 | % |  |  |  |  |  |  |
| Net income attributable to common shareowners |  | $ | 1,340 |  |  | $ | 1,098 |  |  | $ | 242 |  |  | 22 | % |  |  |  |  |  |  |

[0001783180-21-000065:mdna:50]
[same as prior period, unchanged from 0001783180-21-000050:mdna:71]

[0001783180-21-000065:mdna:51]
[same as prior period, unchanged from 0001783180-21-000050:mdna:50]

[0001783180-21-000065:mdna:52]
For the nine months ended September 30, 2021, Net sales were $15.5 billion, a 20% increase compared with the same period of 2020. The components of the year-over-year change were as follows:

[0001783180-21-000065:mdna:53]
|  |  |  |  | For the Nine Months Ended September 30, 2021 |  |  |  |  |
| Organic |  |  |  | 16 | % |  |  |  |  |
| Foreign currency translation |  |  |  | 3 | % |  |  |  |  |
| Acquisitions and divestitures, net |  |  |  | 1 | % |  |  |  |  |
| Total % change |  |  |  | 20 | % |  |  |  |  |

[0001783180-21-000065:mdna:54]
As the global economy continues to recover from the impact of the COVID-19 pandemic, we continue to see improvement across our global business. During the nine months ended September 30, 2021, higher volume and pricing improvements in each of our segments increased organic sales by 16% compared with the same period of 2020. The organic increase was primarily driven by our HVAC segment with strong demand in our North America residential and light commercial business and improved global end-markets in our Commercial HVAC business. Higher sales in our Refrigeration and Fire & Security segments were driven by improved global end-markets and pricing improvements compared with the prior period. Refer to "Segment Review" below for a discussion of Net sales by segment.

[0001783180-21-000065:mdna:55]
[same as prior period, unchanged from 0001783180-21-000050:mdna:54]

[0001783180-21-000065:mdna:56]
For the nine months ended September 30, 2021, gross margin was $4.6 billion, a 21% increase compared with the same period of 2020. The components were as follows:

[0001783180-21-000065:mdna:57]
|  |  |  |  | For the Nine Months Ended September 30, |  |  |  |  |
| (In millions) |  |  |  |  |  | 2021 |  | 2020 |  |  |  |  |
| Net sales |  |  |  |  |  | $ | 15,480 |  |  | $ | 12,862 |  |  |  |  |  |
| Cost of products and services sold |  |  |  |  |  | (10,866) |  |  | (9,038) |  |  |  |  |  |
| Gross margin |  |  |  |  |  | $ | 4,614 |  |  | $ | 3,824 |  |  |  |  |  |
| Percentage of net sales |  |  |  |  |  | 29.8 | % |  | 29.7 | % |  |  |  |  |

[0001783180-21-000065:mdna:58]
The increase in gross margin for the nine months ended September 30, 2021 was primarily driven by continued improvement in the global economic climate during the current period. Higher volumes in each of our segments outpaced operational costs as we continued to focus on Carrier 700 cost containment actions. However, each of our segments have been impacted by the rising cost for commodities and components used in our products, certain supply chain constraints and higher freight costs. As a result, gross margin as a percentage of Net sales was flat compared with the same period of 2020.

[0001783180-21-000065:mdna:59]
[same as prior period, unchanged from 0001783180-21-000050:mdna:58]

[0001783180-21-000065:mdna:60]
For the nine months ended September 30, 2021, operating expenses, including Equity method investment net earnings, were $2.4 billion, a 22% increase compared with the same period of 2020. The components were as follows:

[0001783180-21-000065:mdna:61]
|  |  |  |  | For the Nine Months Ended September 30, |  |  |  |  |
| (In millions) |  |  |  |  |  | 2021 |  | 2020 |  |  |  |  |
| Selling, general and administrative |  |  |  |  |  | $ | (2,304) |  |  | $ | (2,010) |  |  |  |  |  |
| Research and development |  |  |  |  |  | (369) |  |  | (292) |  |  |  |  |  |
| Equity method investment net earnings |  |  |  |  |  | 201 |  |  | 148 |  |  |  |  |  |
| Other income (expense), net |  |  |  |  |  | 40 |  |  | 168 |  |  |  |  |  |
| Total operating expenses |  |  |  |  |  | $ | (2,432) |  |  | $ | (1,986) |  |  |  |  |  |
| Percentage of net sales |  |  |  |  |  | 15.7 | % |  | 15.4 | % |  |  |  |  |

[0001783180-21-000065:mdna:62]
For the nine months ended September 30, 2021, Selling, general and administrative expenses were $2.3 billion, a 15% increase compared with the same period of 2020. At the onset of the COVID-19 pandemic, we initiated various cost containment initiatives in order to help mitigate the impacts on our business, which included reducing discretionary spending, employee furloughs and temporarily closing or limiting the presence of our workforce in our facilities. As a result, the increase in Selling, general and administrative expense in the current period reflects the gradual return to our operational spending levels prior to the COVID-19 pandemic. In addition, higher compensation costs and restructuring charges in the current period along with transaction costs of $29 million associated with the planned divestiture of our Chubb business further contributed to the year-over-year increase. Costs associated with the Separation were $19 million during the nine months ended September 30, 2021 compared with $92 million for the same period of 2020.

[0001783180-21-000065:mdna:63]
[same as prior period, unchanged from 0001783180-21-000050:mdna:63]

[0001783180-21-000065:mdna:64]
Investments over which we do not exercise control, but have significant influence, are accounted for using the equity method of accounting. For the nine months ended September 30, 2021, Equity method investment net earnings were $201 million, a 36% increase compared with the same period of 2020. The increase was primarily related to higher earnings in HVAC joint ventures in Asia, the Middle East and North America as end-markets improved compared with the prior period and the absence of a 2020 product performance matter at one of our HVAC joint ventures. These increases were partially offset by the reduction in earnings resulting from the sale of our investment in Beijer REF AB in 2020.

[0001783180-21-000065:mdna:65]
Other income (expense), net primarily includes the impact of gains and losses related to the sale of interests in our equity method investments, foreign currency gains and losses on transactions that are denominated in a currency other than an entity's functional currency and hedging-related activities. The nine months ended September 30, 2020 included a $252 million gain on sale of our investment in Beijer REF AB. The gain was partially offset by a $71 million other-than-temporary impairment charge on a minority-owned joint venture, an $11 million charge resulting from a litigation matter and a $12 million unfavorable impact for a change in the estimate of certain long-term liabilities. In addition, higher gains on hedging activities were partially offset by deferred compensation costs in the current period.

[0001783180-21-000065:mdna:66]
[same as prior period, unchanged from 0001783180-21-000050:mdna:97]

[0001783180-21-000065:mdna:67]
[same as prior period, unchanged from 0001783180-21-000050:mdna:66]

[0001783180-21-000065:mdna:68]
For the nine months ended September 30, 2021, Non-operating income (expenses), net was $187 million, an 18% increase compared with the same period of 2020. The components were as follows:

[0001783180-21-000065:mdna:69]
|  |  |  |  | For the Nine Months Ended September 30, |
| (In millions) |  |  |  |  |  | 2021 |  | 2020 |
| Non-service pension (expense) benefit |  |  |  |  |  | $ | 51 |  |  | $ | 47 |  |
| Interest expense |  |  |  |  |  | $ | (247) |  |  | $ | (213) |  |
| Interest income |  |  |  |  |  | 9 |  |  | 7 |  |
| Interest (expense) income, net |  |  |  |  |  | $ | (238) |  |  | $ | (206) |  |
| Non-operating income (expenses), net |  |  |  |  |  | $ | (187) |  |  | $ | (159) |  |

[0001783180-21-000065:mdna:70]
Non-operating income (expenses), net includes the results from activities other than normal business operations such as interest expense, interest income and the non-service components of pension and post-retirement obligations. For the nine months ended September 30, 2021 Interest expense was $247 million, a 16% increase compared with the same period in 2020. In connection with the Separation and the Distribution, we issued $11.0 billion of long-term debt in February 2020. As a result, interest expense during the nine months ended September 30, 2020 only included interest expense incurred on such debt after the issuance date. In addition, we issued $750 million of 2.70% long-term notes in June 2020. During the nine months ended September 30, 2021, we incurred a make-whole premium of $17 million and wrote-off $2 million of unamortized deferred financing costs as a result of the redemption of our $500 million 1.923% Notes originally due in February 2023.

[0001783180-21-000065:mdna:71]
[same as prior period, unchanged from 0001783180-21-000050:mdna:70]

[0001783180-21-000065:mdna:72]
|  |  |  | For the Nine Months Ended September 30, |  |  |
|  |  |  |  |  | 2021 |  | 2020 |  |  |  |  |
| Effective tax rate |  |  |  |  | 31.4 | % |  | 33.4 | % |  |  |  |  |

[0001783180-21-000065:mdna:73]
The decrease in the effective tax rate for the nine months ended September 30, 2021 compared with the same period of 2020 is primarily due to the significant items recognized during each period as a percentage of Income from operations before income taxes. The nine months ended September 30, 2021 include a net tax charge of $136 million primarily relating to the re-organizations and disentanglements of certain Chubb subsidiaries executed in advance of the planned divestiture of our Chubb business, a $43 million deferred tax charge as a result of the tax rate increase from 19% to 25% in the United Kingdom, partially offset by favorable tax adjustments of $23 million due to foreign tax credits generated and expected to be utilized in the current year and $21 million resulting from a re-organization of a German subsidiary. The nine months ended September 30, 2020 include a tax charge of $51 million related to a valuation allowance recorded against a United Kingdom tax loss and credit carryforward and a $46 million tax charge resulting from the Company's decision to no longer permanently reinvest certain pre-2018 unremitted non-U.S. earnings.

[0001783180-21-000065:mdna:74]
[same as prior period, unchanged from 0001783180-21-000050:mdna:74]

[0001783180-21-000065:mdna:75]
[same as prior period, unchanged from 0001783180-21-000050:mdna:75]

[0001783180-21-000065:mdna:76]
[same as prior period, unchanged from 0001783180-21-000050:mdna:76]

[0001783180-21-000065:mdna:77]
[same as prior period, unchanged from 0001783180-21-000050:mdna:77]

[0001783180-21-000065:mdna:78]
•The Fire & Security segment provides a wide range of residential, commercial and industrial technologies and systems

[0001783180-21-000065:mdna:79]
and services solutions to protect people and property.

[0001783180-21-000065:mdna:80]
We determine our segments based on how our Chief Executive Officer, who is the Chief Operating Decision Maker (the "CODM"), allocates resources, assesses performance and makes operational decisions. The CODM allocates resources and evaluates the financial performance of each of our segments based on Net sales and Operating profit. Adjustments to reconcile segment reporting to the consolidated results are included in Note 17 - Segment Financial Data.

[0001783180-21-000065:mdna:81]
Three Months Ended September 30, 2021 Compared with Three Months Ended September 30, 2020

[0001783180-21-000065:mdna:82]
Summary performance for each of our segments for the three months ended September 30, 2021 and 2020 is as follows:

[0001783180-21-000065:mdna:83]
|  |  | Net Sales |  | Operating Profit |  | Operating Profit Margin |
|  |  | For the Three Months Ended September 30, |  | For the Three Months Ended September 30, |  | For the Three Months Ended September 30, |
| (In millions) |  | 2021 |  | 2020 |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| HVAC |  | $ | 3,054 |  |  | $ | 2,892 |  |  | $ | 573 |  |  | $ | 839 |  |  | 18.8 | % |  | 29.0 | % |
| Refrigeration |  | 1,011 |  |  | 876 |  |  | 119 |  |  | 103 |  |  | 11.8 | % |  | 11.8 | % |
| Fire & Security |  | 1,377 |  |  | 1,324 |  |  | 182 |  |  | 200 |  |  | 13.2 | % |  | 15.1 | % |
| Total segment |  | $ | 5,442 |  |  | $ | 5,092 |  |  | $ | 874 |  |  | $ | 1,142 |  |  | 16.1 | % |  | 22.4 | % |

[0001783180-21-000065:mdna:84]
[same as prior period, unchanged from 0001783180-21-000050:mdna:83]

[0001783180-21-000065:mdna:85]
For the three months ended September 30, 2021, Net sales in our HVAC segment were $3.1 billion, a 6% increase compared with the same period of 2020. The components of the year-over-year change were as follows:

[0001783180-21-000065:mdna:86]
|  |  | Net Sales |
| Organic |  | 2 | % |
| Foreign currency translation |  | 1 | % |
| Acquisitions and divestitures, net |  | 3 | % |
| Total % change in Net sales |  | 6 | % |

[0001783180-21-000065:mdna:87]
The organic increase in Net sales of 2% was primarily driven by our Commercial HVAC business (4%) reflecting the gradual improvement in the global economic environment as our end-markets improved from the prior year impacts of the COVID-19 pandemic. Volume growth in Europe was the primary driver of improved results during the period with modest growth in Asia due to a resurgence of COVID-19 cases and additional restrictions put in place. Net sales in our North America residential and light commercial business were flat compared with the same period of 2020. Results during the three months ended September 30, 2020 reflected a significant rebound in demand after initial weakness during the first half of 2020 due to the COVID-19 pandemic. Current period results reflect normalizing demand. In addition, the current global economic environment has led to supply chain constraints and shipping delays that negatively impacted Net sales which were offset by pricing improvements during the period.

[0001783180-21-000065:mdna:88]
On June 1, 2021, the Commercial HVAC business completed the acquisition of Giwee. Giwee is a China-based manufacturer of HVAC products, offering a portfolio of products including variable refrigerant flow, modular chillers and light commercial air conditioners. The results of Giwee have been included in our Unaudited Condensed Consolidated Financial Statements since the date of acquisition. The transaction added 2% to Net sales during the three months ended September 30, 2021. Refer to Note 15 - Acquisitions for additional information.

[0001783180-21-000065:mdna:89]
[same as prior period, unchanged from 0001783180-21-000050:mdna:118]

[0001783180-21-000065:mdna:90]
For the three months ended September 30, 2021, Operating profit in our HVAC segment was $573 million, a 32% decrease compared with the same period of 2020. The components of the year-over-year change were as follows:

[0001783180-21-000065:mdna:91]
|  |  | Operating Profit |
| Operational |  | (1) | % |
| Foreign currency translation |  | — | % |
| Acquisitions and divestitures, net |  | (1) | % |
| Restructuring |  | (1) | % |
| Other |  | (29) | % |
| Total % change in Operating profit |  | (32) | % |

[0001783180-21-000065:mdna:92]
The decrease in organic operational profit of 1% was primarily attributable to higher costs for commodities and components used in our products and higher freight costs, partially offset by pricing improvements and higher earnings from equity method investments compared with the prior period. In addition, higher selling, general and administrative costs and research and development further impacted operational profit as our businesses return to normal spending levels as compared with the prior period.

[0001783180-21-000065:mdna:93]
Operating profit was also impacted by the acquisition of Giwee, the results of which included transaction costs, inventory step-up and backlog amortization during the period. In addition, the decrease in Other reflects the absence of a $252 million gain on sale of our investment in Beijer REF AB in the prior period.

[0001783180-21-000065:mdna:94]
[same as prior period, unchanged from 0001783180-21-000050:mdna:92]

[0001783180-21-000065:mdna:95]
For the three months ended September 30, 2021, Net sales in our Refrigeration segment were $1.0 billion, a 15% increase compared with the same period of 2020. The components of the year-over-year change were as follows:

[0001783180-21-000065:mdna:96]
|  |  | Net Sales |
| Organic |  | 14 | % |
| Foreign currency translation |  | 1 | % |
| Total % change in Net sales |  | 15 | % |

[0001783180-21-000065:mdna:97]
The organic increase in Net sales of 14% was primarily driven by our Transport refrigeration business reflecting the gradual improvement in the global economic environment as our end-markets improved from the prior year impacts of the COVID-19 pandemic. Transport refrigeration sales (24%) benefited from the continued recovery associated with the cyclical decline that began in late 2019 as well as a rebound in the demand for global transportation. Commercial refrigeration sales decreased (1%) as sales volume growth was limited by supply chain constraints and end market weakness in Asia.

[0001783180-21-000065:mdna:98]
For the three months ended September 30, 2021, Operating profit in our Refrigeration segment was $119 million, a 15% increase compared with the same period of 2020. The components of the year-over-year change were as follows:

[0001783180-21-000065:mdna:99]
|  |  | Operating Profit |
| Operational |  | 16 | % |
| Foreign currency translation |  | 2 | % |
| Restructuring |  | (3) | % |
| Total % change in Operating profit |  | 15 | % |

[0001783180-21-000065:mdna:100]
The increase in operational profit of 16% was primarily attributable to higher sales volumes compared with the prior period, which was impacted by the COVID-19 pandemic. In addition, pricing improvements also contributed to the increase. These increases were partially offset by higher costs for commodities and components used in our products and higher freight costs. Higher selling, general and administrative costs and research and development activities further impacted operational profit as

[0001783180-21-000065:mdna:101]
our businesses return to normal spending levels compared with the prior period in addition to incremental investments in product development and expanding our sales force.

[0001783180-21-000065:mdna:102]
[same as prior period, unchanged from 0001783180-21-000050:mdna:100]

[0001783180-21-000065:mdna:103]
For the three months ended September 30, 2021, Net sales in our Fire & Security segment were $1.4 billion, a 4% increase compared with the same period of 2020. The components of the year-over-year change were as follows:

[0001783180-21-000065:mdna:104]
|  |  | Net Sales |
| Organic |  | 2 | % |
| Foreign currency translation |  | 2 | % |
| Total % change in Net sales |  | 4 | % |

[0001783180-21-000065:mdna:105]
The organic increase in Net sales of 2% was driven by the gradual improvement in the global economic environment as our end-markets improved from the prior year impacts of the COVID-19 pandemic. An increase in product sales (3%) was primarily driven by volume improvements in the commercial and industrial businesses, which were impacted by shutdowns related to COVID-19 in the prior period. Favorable pricing also contributed to the increase. In addition, volume increases in Europe benefited from improved end-markets impacted by COVID-19 in the prior period. These amounts were partially offset by reduced demand in Asia due to a resurgence of COVID-19 cases and supply chain constraints. Field service sales were flat compared with the prior period. Improved end-markets impacted by COVID-19 in the prior period were offset by continued restrictions in certain countries in Asia and supply chain constraints during the current period.

[0001783180-21-000065:mdna:106]
For the three months ended September 30, 2021, Operating profit in our Fire & Security segment was $182 million, a 9% decrease compared with the same period of 2020. The components of the year-over-year change were as follows:

[0001783180-21-000065:mdna:107]
|  |  | Operating Profit |
| Operational |  | (9) | % |
| Foreign currency translation |  | 1 | % |
| Restructuring |  | 1 | % |
| Other |  | (2) | % |
| Total % change in Operating profit |  | (9) | % |

[0001783180-21-000065:mdna:108]
The decrease in operational profit of 9% was primarily attributable to higher costs for commodities and components used in our products and freight costs. These amounts were partially offset by higher sales volumes and pricing improvements compared with the prior period, which was impacted by the COVID-19 pandemic. In addition, higher selling, general and administrative costs and research and development further impacted operational profit as our businesses return to normal spending levels as compared with the prior period in addition to incremental investments in product development and expanding our sales force.

[0001783180-21-000065:mdna:109]
Amounts reported in Other represent transaction costs associated with the planned divestiture of our Chubb business. These amounts were partially offset by lower depreciation and amortization, which was ceased on Chubb's assets held for sale in accordance with ASC 360, Property, Plant and Equipment.

[0001783180-21-000065:mdna:110]
[same as prior period, unchanged from 0001783180-21-000050:mdna:140]

[0001783180-21-000065:mdna:111]
Nine Months Ended September 30, 2021 Compared with Nine Months Ended September 30, 2020

[0001783180-21-000065:mdna:112]
| Summary performance for each of our segments for the nine months ended September 30, 2021 and 2020 is as follows: |
|  | Net Sales |  | Operating Profit |  | Operating Profit Margin |
| (in millions) | 2021 |  | 2020 |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| HVAC | $ | 8,660 |  |  | $ | 7,142 |  |  | $ | 1,511 |  |  | $ | 1,364 |  |  | 17.4 | % |  | 19.1 | % |
| Refrigeration | 3,037 |  |  | 2,384 |  |  | 369 |  |  | 263 |  |  | 12.2 | % |  | 11.0 | % |
| Fire & Security | 4,084 |  |  | 3,587 |  |  | 480 |  |  | 426 |  |  | 11.8 | % |  | 11.9 | % |
| Total segment | $ | 15,781 |  |  | $ | 13,113 |  |  | $ | 2,360 |  |  | $ | 2,053 |  |  | 15.0 | % |  | 15.7 | % |

[0001783180-21-000065:mdna:113]
[same as prior period, unchanged from 0001783180-21-000050:mdna:110]

[0001783180-21-000065:mdna:114]
For the nine months ended September 30, 2021, Net sales in our HVAC segment were $8.7 billion, a 21% increase compared with the same period of 2020. The components of the year-over-year change were as follows:

[0001783180-21-000065:mdna:115]
|  |  | Net Sales |
| Organic |  | 18 | % |
| Foreign currency translation |  | 1 | % |
| Acquisitions and divestitures, net |  | 2 | % |
| Total % change in Net sales |  | 21 | % |

[0001783180-21-000065:mdna:116]
The organic increase in Net sales of 18% was driven by improved results across each of the segment's businesses. Increased sales in our North America residential and light commercial business (21%) were driven by new construction, the ongoing stay-at-home workforce, higher distributor stocking levels and pricing improvements. Increased sales in our Commercial HVAC business (14%) benefited from the gradual improvement in the global economic environment as our end-markets continue to improve from the prior year impacts of the COVID-19 pandemic. Volume growth in Europe and Asia were the primary drivers of improved results during the period, although sales in certain countries in Asia were tempered by additional restrictions as a result of a resurgence of COVID-19 cases.

[0001783180-21-000065:mdna:117]
On June 1, 2021, the Commercial HVAC business completed the acquisition of Giwee. The results of Giwee has been included in our Unaudited Condensed Consolidated Financial Statements since the date of acquisition. The transaction added 1% to Net sales during the nine months ended September 30, 2021. Refer to Note 15 - Acquisitions for additional information.

[0001783180-21-000065:mdna:118]
For the nine months ended September 30, 2021, Operating profit in our HVAC segment was $1.5 billion, an 11% increase compared with the same period of 2020. The components of the year-over-year change were as follows:

[0001783180-21-000065:mdna:119]
|  |  |  | Operating Profit |
| Operational |  |  | 26 | % |
| Foreign currency translation |  |  | 1 | % |
| Acquisitions and divestitures, net |  |  | (2) | % |
| Restructuring |  |  | (1) | % |
| Other |  |  | (13) | % |
| Total % change in Operating profit |  |  | 11 | % |

[0001783180-21-000065:mdna:120]
39

[0001783180-21-000065:mdna:121]
The operational profit increase of 26% was primarily attributable to higher sales volumes in each of the segment's businesses compared with the prior period. Favorable product mix, pricing improvements and higher earnings from equity method investments also benefited operational profit. These amounts were partially offset by higher selling, general and administrative costs and research and development as our businesses return to normal spending levels as compared with the prior period.

[0001783180-21-000065:mdna:122]
The decrease in Other of 13% primarily reflects the absence of a $252 million gain on sale of our investment in Beijer REF AB in the prior period. In addition, the amounts reported in Other reflects the absence of a prior period non-cash, other-than-temporary impairment charge of $71 million on a minority-owned joint venture investment due to a reduction in sales and earnings that were driven by a deterioration in the oil and gas industry (the joint venture's primary market) and the impact of the COVID-19 pandemic.

[0001783180-21-000065:mdna:123]
[same as prior period, unchanged from 0001783180-21-000050:mdna:119]

[0001783180-21-000065:mdna:124]
For the nine months ended September 30, 2021, Net sales in our Refrigeration segment were $3.0 billion, a 27% increase compared with the same period of 2020. The components of the year-over-year change were as follows:

[0001783180-21-000065:mdna:125]
|  |  | Net Sales |
| Organic |  | 23 | % |
| Foreign currency translation |  | 4 | % |
| Total % change in Net sales |  | 27 | % |

[0001783180-21-000065:mdna:126]
The organic increase in Net sales of 23% was driven by improved results across each of the segment's businesses. Transport refrigeration sales (29%) benefited from the continued recovery associated with the cyclical decline that began in late 2019 as well as a rebound in the demand for global transportation and COVID-19 vaccine-related cargo monitoring. Commercial refrigeration sales (12%) also increased due to a rebound in demand.

[0001783180-21-000065:mdna:127]
For the nine months ended September 30, 2021, Operating profit in our Refrigeration segment was $369 million, a 40% increase compared with the same period of 2020. The components of the year-over-year change were as follows:

[0001783180-21-000065:mdna:128]
|  |  |  | Operating Profit |
| Operational |  |  | 36 | % |
| Foreign currency translation |  |  | 7 | % |
| Restructuring |  |  | (2) | % |
| Other |  |  | (1) | % |
| Total % change in Operating profit |  |  | 40 | % |

[0001783180-21-000065:mdna:129]
The increase in operational profit of 36% was primarily attributable to higher sales volumes and pricing improvements compared with the prior period, which was heavily impacted by the COVID-19 pandemic. In addition, favorable productivity initiatives benefited factory costs. These amounts were partially offset by increased logistics costs. Higher selling, general and administrative costs and research and development further impacted operational profit as our businesses return to normal spending levels as compared with the prior period in addition to incremental investments in product development and expanding our sales force.

[0001783180-21-000065:mdna:130]
[same as prior period, unchanged from 0001783180-21-000050:mdna:126]

[0001783180-21-000065:mdna:131]
For the nine months ended September 30, 2021, Net sales in our Fire & Security segment were $4.1 billion, a 14% increase compared with the same period of 2020. The components of the year-over-year change were as follows:

[0001783180-21-000065:mdna:132]
|  |  | Net Sales |
| Organic |  | 9 | % |
| Foreign currency translation |  | 5 | % |
| Total % change in Net sales |  | 14 | % |

[0001783180-21-000065:mdna:133]
40

[0001783180-21-000065:mdna:134]
The organic increase in Net sales of 9% was driven by improved results across each of the segment's businesses. Field service sales (9%) benefited from improved end-markets in regions that were previously impacted by COVID-19, including Europe and Asia. An increase in product sales (9%) was primarily driven by improvements in the Americas, Asia and Europe, which were impacted by shutdowns related to COVID-19 in the prior period.

[0001783180-21-000065:mdna:135]
For the nine months ended September 30, 2021, Operating profit in our Fire & Security segment was $480 million, a 13% increase compared with the same period of 2020. The components of the year-over-year change were as follows:

[0001783180-21-000065:mdna:136]
|  |  |  | Operating Profit |
| Operational |  |  | 17 | % |
| Foreign currency translation |  |  | 3 | % |
| Restructuring |  |  | (2) | % |
| Other |  |  | (5) | % |
| Total % change in Operating profit |  |  | 13 | % |

[0001783180-21-000065:mdna:137]
The increase in operational profit of 17% was primarily attributable to higher sales volumes, pricing improvements and favorable mix compared with the prior period, which was heavily impacted by the COVID-19 pandemic. These operational increases were partially offset by higher costs for commodities and components used in our products and higher freight. In addition, higher selling, general and administrative costs and research and development further impacted operational profit as our businesses return to normal spending levels as compared with the prior period.

[0001783180-21-000065:mdna:138]
Amounts reported in Other represent transaction costs associated with the planned divestiture of our Chubb business as well as the absence of a favorable adjustment related to a product recall matter in the prior period. These amounts were partially offset by lower depreciation and amortization, which was ceased on Chubb's assets held for sale in accordance with ASC 360, Property, Plant and Equipment.

[0001783180-21-000065:mdna:139]
[same as prior period, unchanged from 0001783180-21-000050:mdna:134]

[0001783180-21-000065:mdna:140]
[same as prior period, unchanged from 0001783180-21-000050:mdna:135]

[0001783180-21-000065:mdna:141]
As of September 30, 2021, we had cash and cash equivalents of $2.7 billion, of which approximately 36% was held by our foreign subsidiaries. We manage our worldwide cash requirements by reviewing available funds and the cost effectiveness with which we can access funds held by foreign subsidiaries. On occasion, we are required to maintain cash deposits in connection with contractual obligations related to acquisitions, divestitures or other legal obligations. As of September 30, 2021 and December 31, 2020, the amount of such restricted cash was approximately $33 million and $4 million, respectively.

[0001783180-21-000065:mdna:142]
We maintain a $2.0 billion unsecured, unsubordinated commercial paper program which can be used for general corporate purposes, including working capital and potential acquisitions. In addition, we maintain our $2.0 billion Revolving Credit Facility that matures on April 3, 2025 which supports our commercial paper borrowing program and cash requirements. This Revolving Credit Facility has a commitment fee of 0.125% that is charged on unused commitments. Borrowings are available in U.S. Dollars, Euros and Pounds Sterling and bear interest at a variable rate based on LIBOR plus a ratings-based margin (or customary LIBOR replacement provisions), which was 125 basis points as of September 30, 2021. As of September 30, 2021, we had no borrowings outstanding under our commercial paper program and our Revolving Credit Facility.

[0001783180-21-000065:mdna:143]
[same as prior period, unchanged from 0001783180-21-000050:mdna:138]

[0001783180-21-000065:mdna:144]
[same as prior period, unchanged from 0001783180-21-000050:mdna:139]

[0001783180-21-000065:mdna:145]
The Revolving Credit Facility and the indentures for the long-term notes contain affirmative and negative covenants customary for financings of these types, which among other things, limit our ability to incur additional liens, to make certain fundamental changes and to enter into sale and leaseback transactions. As of September 30, 2021, we were in compliance with the covenants under the agreements governing our outstanding indebtedness.

[0001783180-21-000065:mdna:146]
The following table presents our credit ratings and outlook as of September 30, 2021:

[0001783180-21-000065:mdna:147]
[same as prior period, unchanged from 0001783180-21-000050:mdna:143]

[0001783180-21-000065:mdna:148]
(1) The long-term rating for S&P was affirmed on May 14, 2021, and for Moody's on June 16, 2020. Fitch's long-term rating was affirmed on June 3, 2021

[0001783180-21-000065:mdna:149]
(2) S&P revised its outlook to stable from negative on May 14, 2021

[0001783180-21-000065:mdna:150]
[same as prior period, unchanged from 0001783180-21-000050:mdna:146]

[0001783180-21-000065:mdna:151]
| (In millions) |  | September 30,2021 |  | December 31,2020 |
| Cash and cash equivalents |  | $ | 2,671 |  |  | $ | 3,115 |  |
| Total debt |  | $ | 9,688 |  |  | $ | 10,227 |  |
| Total equity |  | $ | 7,222 |  |  | $ | 6,578 |  |
| Net debt (total debt less cash and cash equivalents) |  | $ | 7,017 |  |  | $ | 7,112 |  |
| Total capitalization (total debt plus total equity) |  | $ | 16,910 |  |  | $ | 16,805 |  |
| Net capitalization (total debt plus total equity less cash and cash equivalents) |  | $ | 14,239 |  |  | $ | 13,690 |  |
| Total debt to total capitalization |  | 57 | % |  | 61 | % |
| Net debt to net capitalization |  | 49 | % |  | 52 | % |

[0001783180-21-000065:mdna:152]
Our short-term obligations primarily consist of current maturities of long-term debt. Our long-term obligations primarily consist of long-term notes with maturity dates ranging between 2025 and 2050. Interest payments related to Long-term Notes are expected to approximate $273 million per year, reflecting an approximate weighted-average interest rate of 2.87%. Any borrowings from the Revolving Credit Facility are subject to variable interest rates. See Note 5 – Borrowings and Lines of Credit in the Notes to the Unaudited Condensed Consolidated Financial Statements for additional information regarding the terms of our long-term debt obligations.

[0001783180-21-000065:mdna:153]
During the nine months ended September 30, 2021, we acquired consolidated businesses and a minority-owned business. The aggregate cash paid for acquisitions, net of cash acquired, totaled $214 million and was funded through cash on hand. See Note 15 – Acquisitions for additional information.

[0001783180-21-000065:mdna:154]
On February 4, 2021, our Board of Directors approved a stock repurchase program authorizing the repurchase of up to $350 million of our outstanding common stock. The share repurchase program, which was increased by $1.75 billion on July 27, 2021, allows us to repurchase shares from time to time subject to market conditions and at our discretion in the open market or through one or more other public or private transactions and subject to compliance with our obligations under the TMA. During the nine months ended September 30, 2021, we repurchased 5.7 million shares of our common stock for an aggregate purchase

[0001783180-21-000065:mdna:155]
price of $276 million, which are held in Treasury stock as of September 30, 2021 in the Unaudited Condensed Consolidated Balance Sheet.

[0001783180-21-000065:mdna:156]
We paid dividends on common stock during the nine months ended September 30, 2021, totaling $313 million. On October 14, 2021, the Board of Directors declared a dividend of $0.12 per share of common stock payable on November 22, 2021 to shareowners of record at the close of business on October 29, 2021.

[0001783180-21-000065:mdna:157]
[same as prior period, unchanged from 0001783180-21-000050:mdna:152]

[0001783180-21-000065:mdna:158]
The following table reflects the major categories of cash flows. For additional details, see the Unaudited Condensed Consolidated Statement of Cash Flows in the accompanying Unaudited Condensed Consolidated Financial Statements.

[0001783180-21-000065:mdna:159]
|  |  | Nine Months Ended September 30, |
| (In millions) |  | 2021 |  | 2020 |
| Net cash flows provided by (used in): |  |  |  |  |
| Operating activities |  | $ | 1,324 |  |  | $ | 1,493 |  |
| Investing activities |  | (426) |  |  | 230 |  |
| Financing activities |  | (1,225) |  |  | 1,173 |  |
| Effect of foreign exchange rate changes on cash and cash equivalents |  | (15) |  |  | — |  |
| Net increase (decrease) in cash and cash equivalents and restricted cash |  | $ | (342) |  |  | $ | 2,896 |  |

[0001783180-21-000065:mdna:160]
Cash flows from operating activities primarily represent inflows and outflows associated with our operations. Primary activities include net income from operations adjusted for non-cash transactions, working capital changes and changes in other assets and liabilities. The year-over-year decrease in net cash provided by operating activities was primarily driven by higher working capital balances during the current period. Continued strong demand and an increase of safety stock due to supply chain constraints led to higher inventory balances. In addition, higher accounts receivable balances due to increased sales more than offset outstanding accounts payable balances.

[0001783180-21-000065:mdna:161]
Cash flows from investing activities primarily represent inflows and outflows associated with long-term assets. Primary activities include capital expenditures, acquisitions, divestitures and proceeds from the sale of fixed assets. During the nine months ended September 30, 2021, net cash used in investing activities was $426 million. The primary driver of the outflow related to the acquisition of several businesses and a minority-owned business, which totaled $214 million, net of cash acquired and $206 million of capital expenditures. During the nine months ended September 30, 2020, net cash provided by investing activities was $230 million with the primary drivers of the inflow relating to the proceeds received from the sale of our investment in Beijer REF AB and the settlement of derivative contracts of $67 million. These inflows were partially offset by capital expenditures of $151 million.

[0001783180-21-000065:mdna:162]
Cash flows from financing activities primarily represent inflows and outflows associated with equity or borrowings. Primary activities include debt transactions, paying dividends to shareowners and the repurchase of our common stock. During the nine months ended September 30, 2021, net cash used in financing activities was $1.2 billion. The primary driver of the outflow related to the redemption of long-term Notes of $500 million. In addition, we paid $313 million in dividends to our common shareowners and paid $275 million to repurchase shares of our common stock. During the nine months ended September 30, 2020, net cash provided by financing activities was $1.2 billion with the primary drivers of the increase relating to the issuance of $750 million of long-term debt and a $590 million cash contribution from UTC in connection with the Separation.

[0001783180-21-000065:mdna:163]
[same as prior period, unchanged from 0001783180-21-000050:mdna:158]

[0001783180-21-000065:mdna:164]
The section entitled "Management's Discussion and Analysis of Financial Condition and Results of Operations – Off-Balance Sheet Arrangements and Contractual Obligations" in our 2020 Form 10-K provided disclosures about our contractual obligations and commercial commitments at the end of 2020. There have been no material changes for the three and nine months ended September 30, 2021 to our off-balance sheet arrangements and contractual obligations disclosed in our 2020 Form 10-K.
