# CARR notes — 0001783180-22-000010


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001783180-22-000010:notes:1]
Part III hereof incorporates by reference portions of the Registrant's definitive proxy statement related to its 2022 annual meeting of shareowners.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001783180-22-000010:notes:2]
DESCRIPTION OF THE BUSINESS 
Carrier Global Corporation is a leading global provider of healthy, safe, sustainable and intelligent building and cold chain solutions. The Company's portfolio includes industry-leading brands such as Carrier, Kidde, Edwards, LenelS2, Carrier Transicold and Automated Logic that offer innovative HVAC, refrigeration, fire, security and building automation technologies to help make the world safer and more comfortable. The Company also provides a broad array of related building services, including audit, design, installation, system integration, repair, maintenance and monitoring. The Company's operations are classified into three segments: HVAC, Refrigeration and Fire & Security.

[0001783180-22-000010:notes:3]
The Separation

[0001783180-22-000010:notes:4]
On April 3, 2020, United Technologies Corporation, since renamed Raytheon Technologies Corporation, completed the spin-off of the Company into an independent, publicly traded company through a pro rata distribution on a one-for-one basis of all of the outstanding shares of common stock of the Company to UTC shareowners who held shares of UTC common stock as of the close of business on March 19, 2020, the record date for the Distribution. In connection with the Separation, the Company issued an aggregate principal balance of $11.0 billion of debt and transferred approximately $10.9 billion of cash to UTC on February 27, 2020 and March 27, 2020. On April 1, 2020 and April 2, 2020, the Company received cash contributions totaling $590 million from UTC related to the Separation.

[0001783180-22-000010:notes:5]
In connection with the Separation, the Company entered into several agreements with UTC and Otis that govern various aspects of the relationship among the Company, UTC and Otis following the Separation and the Distribution, including a TSA that expired on March 31, 2021, a TMA, an employee matters agreement and an intellectual property agreement that cover services such as information technology, tax, finance and human resources. In addition, the Company incurred separation-related costs including employee-related costs, costs to establish certain stand-alone functions, information technology systems, professional service fees and other costs associated with becoming an independent, publicly traded company.

[0001783180-22-000010:notes:6]
Impact of the COVID-19 Pandemic

[0001783180-22-000010:notes:7]
In early 2020, the World Health Organization declared the outbreak of a respiratory disease known as COVID-19 as a global pandemic. In response, many countries implemented containment and mitigation measures to combat the outbreak, which severely restricted the level of economic activity and caused a significant contraction in the global economy. As a result, the Company temporarily closed or reduced production at manufacturing facilities across the globe to ensure employee safety and instructed non-essential employees to work from home. In addition, the Company took several preemptive actions during 2020 to manage liquidity as demand for its products decreased. Despite the adverse impacts of the pandemic on the Company’s results beginning in the first quarter of 2020, manufacturing operations resumed and several restorative actions were completed during 2020, including the reinstatement of annual merit-based salary increases and continued investment to support the Company's strategic priorities.

[0001783180-22-000010:notes:8]
The Company continues to focus its efforts on preserving the health and safety of its employees and customers as well as maintaining the continuity of its operations. In addition, the Company continues to actively monitor its liquidity position and working capital needs and believes that its overall capital resources and liquidity position are adequate. The preparation of financial statements requires management to use judgments in making estimates and assumptions based on the relevant information available at the end of each period, which can have a significant effect on reported amounts. However, due to significant uncertainty surrounding the pandemic, including a resurgence in cases and the spread of COVID-19 variants, management's judgments could change. While the Company's results of operations, cash flows and financial condition could be negatively impacted, the extent of any continuing impact cannot be estimated with certainty at this time.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001783180-22-000010:notes:9]
BASIS OF PRESENTATION The accompanying Consolidated Financial Statements reflect the consolidated operations of the Company and have been prepared in accordance with U.S. Generally Accepted Accounting Principles ("GAAP") as defined by the FASB within the FASB Accounting Standards Codification. Inter-company accounts and transactions have been eliminated. Related party transactions between the Company and its equity method investees have not been eliminated. Certain immaterial amounts presented in prior periods have been reclassified to conform to the current period presentation.
The Consolidated Financial Statements include all majority-owned subsidiaries of the Company. A non-controlling interest in a subsidiary is considered an ownership interest in a majority-owned subsidiary that is not attributable to the parent. The Company includes Non-controlling interest as a component of Total equity in the Consolidated Balance Sheet and the Non-controlling interest in subsidiaries' earnings from operations are presented as an adjustment to Net income from operations used to arrive at Net income attributable to common shareowners in the Consolidated Statement of Operations. Partially-owned equity affiliates represent 20-50% ownership interests in investments where the Company demonstrates significant influence, but does not have a controlling financial interest. Partially-owned equity affiliates are accounted for under the equity method.

[0001783180-22-000010:notes:10]
The Company's financial statements for the periods prior to the Separation and the Distribution are prepared on a "carve-out" basis and include all amounts directly attributable to the Company. Net cash transfers and other property transferred between UTC and the Company, including related party receivables and payables between the Company and other UTC affiliates, are presented as Net transfers to UTC within UTC Net Investment on the Consolidated Financial Statements. In addition, the financial statements include allocations of costs for administrative functions and services performed on behalf of the Company by centralized groups within UTC. All allocations and estimates in the Consolidated Financial Statements are based on assumptions that management believes are reasonable. The allocated centralized costs for the years ended December 31, 2020 and 2019, were $43 million and $245 million, respectively, and are primarily included in Selling, general and administrative in the Consolidated Statement of Operations.

[0001783180-22-000010:notes:11]
The Company's financial statements for the periods subsequent to April 3, 2020 are consolidated financial statements based on the reported results of Carrier as a stand-alone company. In connection with the Separation, the Company incurred separation-related costs of approximately $20 million, $141 million and $58 million for the years ended December 31, 2021, 2020 and 2019, respectively. These costs are primarily recorded in Selling, general and administrative in the Consolidated Statement of Operations and consist of employee-related costs, costs to establish certain stand-alone functions and information technology systems, professional service fees and other transaction-related costs resulting from Carrier’s transition to becoming an independent, publicly traded company.

[0001783180-22-000010:notes:12]
Held for Sale

[0001783180-22-000010:notes:13]
On July 26, 2021, the Company entered into a stock purchase agreement to sell its Chubb business to APi. As a result, the assets and liabilities of Chubb have been presented as held for sale on the accompanying Consolidated Balance Sheet as of December 31, 2021 and recorded at the lower of their carrying value or fair value less estimated cost to sell. See Note 20 - Divestitures for additional information.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001783180-22-000010:notes:14]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES
A summary of significant accounting policies used in the preparation of the accompanying Consolidated Financial Statements is as follows:

[0001783180-22-000010:notes:15]
Use of Estimates. The preparation of the Consolidated Financial Statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and the disclosure of contingent assets and liabilities at the date of the financial statements as well as the reported amounts of revenues and expenses during the reporting period. Estimates are based on several factors including the facts and circumstances available at the time the estimates are made, historical experience and various other assumptions that are believed to be reasonable under the circumstances. Actual results could differ from those estimates.

[0001783180-22-000010:notes:16]
Currency Translation. Assets and liabilities of non-U.S. subsidiaries, where the functional currency is not the U.S. dollar, have been translated at year-end exchange rates, and income and expense accounts have been translated using average exchange rates throughout the year. Adjustments resulting from the process of translating an entity’s financial statements into the U.S. dollar have been recorded in the equity section of the Consolidated Balance Sheet within Accumulated other comprehensive income (loss). Transactions that are denominated in a currency other than an entity’s functional currency are subject to changes in exchange rates with the resulting gains and losses recorded in Net income from operations.

[0001783180-22-000010:notes:17]
Cash and Cash Equivalents. Cash and cash equivalents include cash on hand, demand deposits and short-term cash investments that are highly liquid in nature and have original maturities of three months or less. On occasion, the Company is

[0001783180-22-000010:notes:18]
required to maintain restricted cash deposits with certain banks due to contractual or other legal obligations. Restricted cash of $39 million and $4 million is included in Other assets, current as of December 31, 2021 and 2020, respectively.

[0001783180-22-000010:notes:19]
Accounts Receivable. Accounts receivable consist of billed amounts owed for products shipped to or services performed for customers. Amounts are recorded net of an allowance for expected credit losses which represents the best estimate of probable loss inherent in the Company's accounts receivable portfolio. The allowance is determined using a combination of factors including a reserve based on the aging of the outstanding accounts receivable portfolio and the Company's historical credit loss experience with its end markets, customer base and products. In addition, the Company considers knowledge of specific customers, current market conditions as well as reasonable and supportable forecasts of future events and economic conditions. As of December 31, 2021 and 2020, the allowance for expected credit losses was $88 million and $89 million, respectively. These estimates and assumptions are reviewed periodically with the effects of changes, if any, reflected in the Consolidated Statement of Operations in the period that they are determined.

[0001783180-22-000010:notes:20]
Fixed Assets. Property, plant and equipment are stated at cost less accumulated depreciation. Assets placed in service are recorded at cost and depreciated using the straight-line method over the estimated useful life of the asset. Assets acquired in a business combination are recorded at fair value at the date of acquisition. Major expenditures for replacements and significant improvements that increase asset values and extend useful lives are capitalized. Repairs and maintenance expenditures that do not extend the useful life of an asset are charged to expense as incurred.

[0001783180-22-000010:notes:21]
Per ASC 360, the Company assesses the recoverability of the carrying value of its property, plant and equipment whenever events or changes in circumstances indicate that the carrying amount of an asset group may not be recoverable. Recoverability is measured by a comparison of the carrying amount of an asset group to the future net undiscounted cash flows expected to be generated by the asset group. If the undiscounted cash flows are less than the carrying amount of the asset group, an impairment loss is recognized for the amount by which the carrying amount of the asset group exceeds the fair value of the asset group.

[0001783180-22-000010:notes:22]
Equity Method Investments. Investments in which the Company has the ability to exercise significant influence, but does not control, are accounted for under the equity method of accounting and are presented on the Consolidated Balance Sheet. Under this method of accounting, the Company’s share of the net earnings or losses of the investee is presented within Operating profit on the Consolidated Statement of Operations since the activities of the investee are closely aligned with the operations of the Company. The Company evaluates its equity method investments whenever events or changes in circumstance indicate that the carrying amounts of such investments may be impaired. If a decline in the value of an equity method investment is determined to be other than temporary, a loss is recorded in earnings in the current period. Distributions received from equity method investees are presented in the Consolidated Statement of Cash Flows based on the cumulative earnings approach.

[0001783180-22-000010:notes:23]
Goodwill and Intangible Assets. The Company records goodwill as the excess of the purchase price over the fair value of the net assets acquired in a business combination. In accordance with ASC 350, goodwill and other indefinite-lived intangibles are tested and reviewed annually for impairment on July 1 or whenever there is a material change in events or circumstances that indicate that the fair value of the asset is more likely than not less than the carrying amount of the asset.

[0001783180-22-000010:notes:24]
Impairment of goodwill is assessed at the reporting unit level and begins with a qualitative assessment to determine if it is more likely than not that the fair value of each reporting unit is less than its carrying amount as a basis for determining whether it is necessary to perform the goodwill impairment test under ASC 350. For those reporting units that bypass or fail the qualitative assessment, the test compares the carrying amount of the reporting unit to its estimated fair value. If the estimated fair value of a reporting unit exceeds its carrying amount, goodwill of the reporting unit is not impaired. To the extent that the carrying amount of the reporting unit exceeds its estimated fair value, an impairment loss will be recognized for the amount by which the reporting unit's carrying amount exceeds its fair value, not to exceed the carrying amount of goodwill in that reporting unit.

[0001783180-22-000010:notes:25]
Intangible assets such as patents, service contracts, monitoring lines and customer relationships with finite useful lives are amortized based on the pattern in which the economic benefits of the intangible assets are consumed. If a pattern of economic benefit cannot be reliably determined or if straight-line amortization approximates the pattern of economic benefit, a straight-line amortization may be used.

[0001783180-22-000010:notes:26]
The weighted-average useful lives approximate the following (in years):

[0001783180-22-000010:notes:27]
| Customer relationships | 1 to 30 |
| Patents and trademarks | 5 to 30 |
| Monitoring lines | 7 to 10 |
| Service portfolio and other | 1 to 23 |

[0001783180-22-000010:notes:28]
The Company assesses the recoverability of the carrying amount of its intangible assets with finite useful lives whenever events or changes in circumstances indicate that the carrying amount of the asset group may not be recoverable. Recoverability is measured by a comparison of the carrying amount of an asset group to the future net undiscounted cash flows expected to be generated by the asset group. If the undiscounted cash flows are less than the carrying amount of the asset group, an impairment loss is recognized for the amount by which the carrying value of the asset group exceeds the fair value of the asset group.

[0001783180-22-000010:notes:29]
Leases. The Company accounts for leases in accordance with ASC 842: Leases, which requires a lessee to record a right-of-use ("ROU") asset and a lease liability on the Consolidated Balance Sheet for all leases with terms longer than 12 months. ROU assets and liabilities are recognized at the commencement date based on the present value of lease payments over the lease term. The Company generally uses its incremental borrowing rate, which is based on information available at the lease commencement date, to determine the present value of lease payments except when an implicit interest rate is readily determinable. The lease term may include options to extend or terminate the lease when it is reasonably certain that the Company will exercise that option. The Company has elected not to recognize ROU assets and lease obligations for its short-term leases, which are defined as leases with an initial term of 12 months or less.

[0001783180-22-000010:notes:30]
Income Taxes. The Company accounts for income taxes in accordance with ASC 740. Deferred tax assets and liabilities are determined based on temporary differences between financial reporting and tax bases of assets and liabilities, applying enacted tax rates expected to be in effect for the year in which the differences are expected to reverse. The Company recognizes future tax benefits to the extent that realizing these benefits is considered in its judgment to be more likely than not. For those jurisdictions where the expiration date of tax carryforwards or the projected operating results indicate that realization is not likely, a valuation allowance is provided. The Company reviews the realizability of its deferred tax asset valuation allowances on a quarterly basis, or whenever events or changes in circumstances indicate that a review is required and will adjust its estimate if significant events so dictate. To the extent that the ultimate results differ from the Company's original or adjusted estimates, the effect will be recorded in the provision for income taxes in the period that the matter is finally resolved.

[0001783180-22-000010:notes:31]
In the ordinary course of business, there is inherent uncertainty in quantifying the Company's income tax positions. The Company assesses its income tax positions and records tax benefits for all years subject to examination based upon management’s evaluation of the facts, circumstances and information available at the reporting date. For those tax positions where it is more likely than not that a tax benefit will be sustained, the Company has recorded the largest amount of tax benefit with a greater than 50% likelihood of being realized upon ultimate settlement with a taxing authority that has full knowledge of all relevant information. For those income tax positions where it is not more likely than not that a tax benefit will be sustained, no tax benefit has been recognized in the Consolidated Financial Statements.

[0001783180-22-000010:notes:32]
Prior to the Separation, the Company’s income tax provision was prepared following the separate return methodology. The separate return method applies ASC 740 to the financial statements of each member of a consolidated group as if the group members were separate taxpayers. As a result, certain operations of the Company were included in a consolidated return with other UTC entities. The calculation of the Company's income taxes on a separate return basis requires a considerable amount of judgment and use of both estimates and allocations. See Note 17 – Income Taxes for additional information.

[0001783180-22-000010:notes:33]
Pension and Post-retirement Obligations. The Company provides a range of benefit plans to eligible current and former employees. The Company accounts for its benefit plans in accordance with ASC 715 which requires balance sheet recognition of the overfunded or underfunded status of pension and post-retirement benefit plans. Determining the amounts associated with these benefits are performed by actuaries and dependent on various actuarial assumptions including discount rates, expected return on plan assets, compensation increases, mortality and health care cost trends. Actual results may differ from the actuarial assumptions and are generally accumulated into Accumulated other comprehensive income (loss) and amortized into Net income from operations over future periods. The Company reviews its actuarial assumptions at each measurement date and makes modifications to the assumptions based on current rates and trends, if appropriate. See Note 10 – Employee Benefit Plans for additional information.

[0001783180-22-000010:notes:34]
Asset Retirement Obligations. The Company records the fair value of legal obligations associated with the retirement of tangible long-lived assets in the period in which a liability is determined to exist, if a reasonable estimate of fair value can be made. Upon initial recognition of a liability, the Company capitalizes the cost of the asset retirement obligation by increasing the carrying amount of the related long-lived asset. Over time, the liability is increased for changes in its present value and the capitalized cost is depreciated over the useful life of the related asset.

[0001783180-22-000010:notes:35]
Research and Development. The Company conducts research and development activities with a focus on new product development and technology innovation. These costs are charged to expense as incurred. For the years ended December 31, 2021, 2020 and 2019, these costs amounted to $503 million, $419 million and $401 million, respectively.

[0001783180-22-000010:notes:36]
Recent Pronouncements

[0001783180-22-000010:notes:37]
The FASB ASC is the sole source of authoritative GAAP other than SEC issued rules and regulations that apply only to SEC registrants. The FASB issues Accounting Standards Updates ("ASU") to communicate changes to the codification. The Company considers the applicability and impact of all ASUs. ASUs not referenced below were assessed and determined to be either not applicable or are not expected to have a material impact on the Consolidated Financial Statements.

[0001783180-22-000010:notes:38]
Recently Adopted Accounting Pronouncements and SEC Rules

[0001783180-22-000010:notes:39]
In October 2021, the FASB issued ASU 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers, which updates the current guidance to require that an entity recognize and measure contract asset and contract liabilities acquired in a business combination consistent with those recorded by the acquiree immediately before the acquisition. The guidance eliminates the complexity of determining the fair value of contract liabilities and will likely increase the balance of contract liabilities acquired in a business combination with a corresponding increase in post-combination revenue recognized by the acquirer. The update is effective for fiscal years beginning after December 15, 2022 and interim periods therein, with early adoption permitted. In October 2021, the Company early adopted ASU 2021-08 and the adoption did not have a material impact on the Company's Consolidated Financial Statements.

[0001783180-22-000010:notes:40]
In December 2019, the FASB issued ASU 2019-12, Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes. The amendments in this update remove certain exceptions allowed by Topic 740 including exceptions to the incremental approach for intra-period tax allocation when there is a loss from continuing operations and income or gain from other items, the requirement to recognize a deferred tax liability for equity method investments when a foreign subsidiary becomes an equity method investment, the ability not to recognize a deferred tax liability for a foreign subsidiary when a foreign equity method investment becomes a subsidiary and the general methodology for calculating income taxes in an interim period when a year-to-date loss exceeds the anticipated loss for the year. There are also additional areas of guidance in regards to franchise and other taxes partially based on income and the interim recognition of enactment of tax laws and rate changes. The provisions of this ASU were effective for years beginning after December 15, 2020, with early adoption permitted. The Company adopted ASU 2019-12 in the first quarter of 2021 and the adoption did not have a material impact on the Company's Consolidated Financial Statements.

[0001783180-22-000010:notes:41]
In May 2020, the SEC issued Final Rule Release No. 33-10786, which amends the financial statement requirements for acquisitions and dispositions of businesses and related pro forma financial information required under SEC Regulation S-X, Rule 3-05. The final rule modifies the significance test required in SEC Regulation S-X, Rule 1-02(w) by raising the significance threshold for reporting dispositions of a business from 10% to 20% and by modifying the calculation of the investment and income tests. In accordance with Rules 3-09 or 4-08(g), the revised income test will apply to the evaluation of equity method investments for significance. The Company adopted these modifications, which were effective for fiscal years beginning after December 31, 2020. The adoption of these amendments did not have a material impact on the Consolidated Financial Statements.

[0001783180-22-000010:notes:42]
In November 2020, the SEC issued Final Rule Release No. 33-10980, which amends the requirements for providing selected quarterly financial data, contractual obligations and management discussion and analysis. These modifications were required after August 9, 2021. The Company applied the requirements of this release for this Annual Report on Form 10-K.


## us-gaap:ScheduleOfFiniteLivedIntangibleAssetsTableTextBlock

[0001783180-22-000010:notes:43]
Identifiable intangible assets consisted of the following:

[0001783180-22-000010:notes:44]
|  |  |  | 2021 |  | 2020 |
| (In millions) |  |  | Gross Amount |  | Accumulated Amortization |  | Net Amount |  | Gross Amount |  | Accumulated Amortization |  | Net Amount |
| Amortized: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  |  | $ | 945 |  |  | $ | (699) |  |  | $ | 246 |  |  | $ | 1,558 |  |  | $ | (1,285) |  |  | $ | 273 |  |
| Patents and trademarks |  |  | 232 |  |  | (182) |  |  | 50 |  |  | 301 |  |  | (222) |  |  | 79 |  |
| Monitoring lines |  |  | — |  |  | — |  |  | — |  |  | 71 |  |  | (59) |  |  | 12 |  |
| Service portfolios and other |  |  | 688 |  |  | (539) |  |  | 149 |  |  | 644 |  |  | (542) |  |  | 102 |  |
|  |  |  | 1,865 |  |  | (1,420) |  |  | 445 |  |  | 2,574 |  |  | (2,108) |  |  | 466 |  |
| Unamortized: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Trademarks and other |  |  | 64 |  |  | — |  |  | 64 |  |  | 571 |  |  | — |  |  | 571 |  |
| Intangible assets, net |  |  | $ | 1,929 |  |  | $ | (1,420) |  |  | $ | 509 |  |  | $ | 3,145 |  |  | $ | (2,108) |  |  | $ | 1,037 |  |


## us-gaap:InventoryDisclosureTextBlock

[0001783180-22-000010:notes:45]
INVENTORIES, NET 
Inventories are stated at the lower of cost or estimated realizable value. Cost is primarily determined based on the first-in, first-out inventory method ("FIFO") or average cost methods, which approximates current replacement cost. However, certain Carrier entities use the last-in, first-out inventory method ("LIFO").

[0001783180-22-000010:notes:46]
Inventories, net consisted of the following:

[0001783180-22-000010:notes:47]
| (In millions) | 2021 |  | 2020 |
| Raw materials | $ | 559 |  |  | $ | 363 |  |
| Work-in-process | 197 |  |  | 143 |  |
| Finished goods | 1,214 |  |  | 1,123 |  |
| Inventories, net | $ | 1,970 |  |  | $ | 1,629 |  |

[0001783180-22-000010:notes:48]
The Company performs periodic assessments utilizing customer demand, production requirements and historical usage rates to determine the existence of excess and obsolete inventory and records necessary provisions to reduce such inventories to estimated realizable value. Raw materials, work-in-process and finished goods are net of valuation reserves of $154 million and $183 million as of December 31, 2021 and 2020, respectively.

[0001783180-22-000010:notes:49]
Certain entities use LIFO to determine the cost of inventory. If inventories that were valued using the LIFO method had been valued under the FIFO method, the net book value of the inventories would have been higher by $141 million and $118 million as of December 31, 2021 and 2020, respectively. As of December 31, 2021 and 2020, approximately 31% and 33%, respectively, of all inventory utilized the LIFO method.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001783180-22-000010:notes:50]
FIXED ASSETS, NET 
Fixed assets, net consisted of the following:

[0001783180-22-000010:notes:51]
| (In millions) | Estimated Useful Lives (Years) |  | 2021 |  | 2020 |
| Land |  |  | $ | 114 |  |  | $ | 109 |  |
| Buildings and improvements | 20 to 40 |  | 1,084 |  |  | 1,160 |  |
| Machinery, tools and equipment | 3 to 25 |  | 2,093 |  |  | 2,138 |  |
| Rental assets | 3 to 12 |  | 381 |  |  | 416 |  |
| Other, including assets under construction |  |  | 304 |  |  | 261 |  |
| Fixed assets, gross |  |  | 3,976 |  |  | 4,084 |  |
| Accumulated depreciation |  |  | (2,150) |  |  | (2,274) |  |
| Fixed assets, net |  |  | $ | 1,826 |  |  | $ | 1,810 |  |

[0001783180-22-000010:notes:52]
Depreciation expense was $238 million, $234 million and $219 million for the years ended December 31, 2021, 2020 and 2019, respectively.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001783180-22-000010:notes:53]
GOODWILL AND INTANGIBLE ASSETS The Company records goodwill as the excess of the purchase price over the fair value of the net assets acquired in a business combination. Goodwill is tested and reviewed annually for impairment on July 1 or whenever there is a material change in events or circumstances that indicates that the fair value of the reporting unit may be less than its carrying amount.
The changes in the carrying amount of goodwill were as follows:

[0001783180-22-000010:notes:54]
| (In millions) | HVAC |  | Refrigeration |  | Fire & Security |  | Total |
| Balance as of December 31, 2019 | $ | 5,351 |  |  | $ | 1,228 |  |  | $ | 3,305 |  |  | $ | 9,884 |  |
| Foreign currency translation | 138 |  |  | 23 |  |  | 94 |  |  | 255 |  |
| Balance as of December 31, 2020 | $ | 5,489 |  |  | $ | 1,251 |  |  | $ | 3,399 |  |  | $ | 10,139 |  |
| Goodwill resulting from business combinations (1) | 261 |  |  | (1) |  |  | 60 |  |  | 320 |  |
| Reclassified to held for sale (2) | — |  |  | — |  |  | (940) |  |  | (940) |  |
| Foreign currency translation | (92) |  |  | (22) |  |  | (56) |  |  | (170) |  |
| Balance as of December 31, 2021 | $ | 5,658 |  |  | $ | 1,228 |  |  | $ | 2,463 |  |  | $ | 9,349 |  |

[0001783180-22-000010:notes:55]
(1) See Note 19 - Acquisitions for additional information.

[0001783180-22-000010:notes:56]
(2) See Note 20 - Divestitures for additional information.

[0001783180-22-000010:notes:57]
Indefinite-lived intangible assets are tested and reviewed annually for impairment on July 1 or whenever there is a material change in events or circumstances that indicates that the fair value of the asset may be less than its carrying amount. All other intangible assets with finite useful lives are amortized over their estimated useful lives.

[0001783180-22-000010:notes:58]
Amortization of intangible assets was $98 million, $102 million and $116 million for the years ended December 31, 2021, 2020 and 2019, respectively.

[0001783180-22-000010:notes:59]
The estimated future amortization of intangible assets is as follows:

[0001783180-22-000010:notes:60]
| (In millions) | 2022 |  | 2023 |  | 2024 |  | 2025 |  | 2026 |
| Future amortization | $ | 80 |  |  | $ | 75 |  |  | $ | 69 |  |  | $ | 59 |  |  | $ | 47 |  |

[0001783180-22-000010:notes:61]
Annual Impairment Assessment

[0001783180-22-000010:notes:62]
The Company tested its goodwill and indefinite-lived intangible assets for impairment as part of its annual assessment. For each test, the Company qualitatively assessed all relevant events or circumstances that could impact the estimate of fair value. Based upon this assessment, the Company determined that it was more likely than not that goodwill and indefinite-lived intangible assets were not impaired.


## us-gaap:DebtDisclosureTextBlock

[0001783180-22-000010:notes:63]
BORROWINGS AND LINES OF CREDIT 
Long-term debt consisted of the following:

[0001783180-22-000010:notes:64]
| (In millions) |  |  |  | 2021 |  |  | 2020 |  |
| 1.923% Notes due February 15, 2023 |  |  |  | $ | — |  | (1) |  | $ | 500 |  |  |
| 2.242% Notes due February 15, 2025 |  |  |  | 2,000 |  |  |  | 2,000 |  |  |
| 2.493% Notes due February 15, 2027 |  |  |  | 1,250 |  |  |  | 1,250 |  |  |
| 2.722% Notes due February 15, 2030 |  |  |  | 2,000 |  |  |  | 2,000 |  |  |
| 2.700% Notes due February 15, 2031 |  |  |  | 750 |  |  |  | 750 |  |  |
| 3.377% Notes due April 5, 2040 |  |  |  | 1,500 |  |  |  | 1,500 |  |  |
| 3.577% Notes due April 5, 2050 |  |  |  | 2,000 |  |  |  | 2,000 |  |  |
| Total long-term notes |  |  |  | 9,500 |  |  |  | 10,000 |  |  |
| Other (including project financing obligations and finance leases) |  |  |  | 267 |  |  |  | 308 |  |  |
| Discounts and debt issuance costs |  |  |  | (71) |  |  |  | (81) |  |  |
| Total debt |  |  |  | 9,696 |  |  |  | 10,227 |  |  |
| Less: current portion of long-term debt |  |  |  | 183 |  |  |  | 191 |  |  |
| Long-term debt, net of current portion |  |  |  | $ | 9,513 |  |  |  | $ | 10,036 |  |  |

[0001783180-22-000010:notes:65]
(1) In February 2021, the Company prepaid the 1.923% Notes due in February 2023 and incurred a $17 million make-whole premium upon prepayment and wrote-off $2 million of the remaining unamortized deferred financing costs.

[0001783180-22-000010:notes:66]
Revolving Credit Facility

[0001783180-22-000010:notes:67]
On February 10, 2020, the Company entered into a revolving credit agreement with various banks permitting aggregate borrowings of up to $2.0 billion pursuant to an unsecured, unsubordinated revolving credit facility that matures on April 3, 2025 (the "Revolving Credit Facility"). The Revolving Credit Facility supports the Company's commercial paper program and cash requirements of the Company. A commitment fee of 0.125% is charged on unused commitments. Borrowings under the Revolving Credit Facility are available in U.S. Dollars, Euros and Pounds Sterling. Pounds Sterling bears interest at a variable interest rate based on daily simple SONIA plus 0.0326%, Euros bears an interest rate using EURIBOR and U.S. Dollar bears an interest rate at LIBOR plus a ratings-based margin, which was 125 basis points as of December 31, 2021. As of December 31, 2021, there were no borrowings on the Revolving Credit Facility.

[0001783180-22-000010:notes:68]
Commercial Paper Program

[0001783180-22-000010:notes:69]
As of December 31, 2021, the Company had a $2.0 billion unsecured, unsubordinated commercial paper program, which can be used for general corporate purposes, including the funding of working capital and potential acquisitions. As of December 31, 2021, there were no borrowings outstanding under the commercial paper program.

[0001783180-22-000010:notes:70]
Project Financing Arrangements

[0001783180-22-000010:notes:71]
The Company is involved in several long-term construction contracts in which it arranges project financing with certain customers. As a result, the Company issued $124 million and $135 million of debt during the year ended December 31, 2021 and 2020, respectively. Long-term debt repayments associated with these financing arrangements for the years ended December 31, 2021 and 2020 were $181 million and $161 million, respectively.

[0001783180-22-000010:notes:72]
Debt Covenants

[0001783180-22-000010:notes:73]
The Revolving Credit Facility and the indenture for the long-term notes contain affirmative and negative covenants customary for financings of this type which, among other things, limit the Company's ability to incur additional liens, to make certain fundamental changes and to enter into sale and leaseback transactions. On June 2, 2020, the Company entered into an amendment to the Revolving Credit Facility, under which certain terms of the facility were amended for a period beginning on June 2, 2020 and ending on December 30, 2021 (the "Covenant Modification"). The Company terminated the Covenant Modification effective as of August 27, 2021 in accordance with procedures for termination set forth in the revolving credit agreement, which returned the consolidated leverage ratio covenant to the limit in effect prior to the Covenant Modification. As

[0001783180-22-000010:notes:74]
of December 31, 2021, the Company was in compliance with the covenants under the agreements governing its outstanding indebtedness.

[0001783180-22-000010:notes:75]
Schedule of Long-term Debt Maturities

[0001783180-22-000010:notes:76]
Scheduled maturities of long-term debt, excluding amortization of discount, are as follows:

[0001783180-22-000010:notes:77]
| (In millions) |  |  |  |
| 2022 |  | $ | 183 |  |  |
| 2023 |  | $ | 74 |  |  |
| 2024 |  | $ | 2 |  |  |
| 2025 |  | $ | 2,002 |  |  |
| 2026 |  | $ | 2 |  |  |
| Thereafter |  | $ | 7,504 |  |  |

[0001783180-22-000010:notes:78]
As of December 31, 2021, the average maturity of the Company's long-term notes is approximately 12 years and the weighted-average interest rate on its total borrowings is approximately 2.8%. 
Interest expense associated with long-term debt for the years ended December 31, 2021 and 2020 was $319 million and $298 million, respectively. Interest expense for the year ended December 31, 2021 includes amortization of debt issuance costs of $10 million, a make whole-premium related to the prepayment of the 1.923% Notes of $17 million and a write-off of debt issuance costs of $2 million. Interest expense for the year ended December 31, 2020 includes amortization of debt issuance costs of $9 million and a write-off of debt issuance costs of $5 million.


## us-gaap:FairValueDisclosuresTextBlock

[0001783180-22-000010:notes:79]
FAIR VALUE MEASUREMENTS
ASC 820, Fair Value Measurement ("ASC 820"), defines fair value as the price that would be received if an asset is sold or the price paid to transfer a liability in an orderly transaction between market participants at the measurement date. ASC 820 also establishes a three-level fair value hierarchy that prioritizes information used in developing assumptions when pricing an asset or liability as follows:

[0001783180-22-000010:notes:80]
•Level 1: Observable inputs such as quoted prices in active markets;

[0001783180-22-000010:notes:81]
•Level 2: Inputs, other than quoted prices in active markets, that are observable either directly or indirectly; and

[0001783180-22-000010:notes:82]
•Level 3: Unobservable inputs where there is little or no market data, which requires the reporting entity to develop its own assumptions.

[0001783180-22-000010:notes:83]
ASC 820 requires the use of observable market data, when available, in making fair value measurements. When inputs used to measure fair value fall within different levels of the hierarchy, the level within which the fair value measurement is categorized is based on the lowest level input that is significant to the fair value measurement.

[0001783180-22-000010:notes:84]
In the normal course of business, the Company is exposed to certain risks arising from business operations and economic factors, including foreign currency and commodity price risk. These exposures are managed through operational strategies and the use of undesignated hedging contracts. The Company's derivative assets and liabilities are measured at fair value on a recurring basis using internal models based on observable market inputs, such as forward, interest, contract and discount rates with changes in fair value reported directly in earnings.

[0001783180-22-000010:notes:85]
The following tables provide the valuation hierarchy classification of assets and liabilities that are recorded at fair value and measured on a recurring basis in the Company's Consolidated Balance Sheet:

[0001783180-22-000010:notes:86]
| (In millions) |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |
| December 31, 2021 |  |  |  |  |  |  |  |  |
| Fair value measurement: |  |  |  |  |  |  |  |  |
| Derivative assets (1) |  | $ | 8 |  |  | $ | — |  |  | $ | 8 |  |  | $ | — |  |
| Derivative liabilities (2) |  | $ | (35) |  |  | $ | — |  |  | $ | (35) |  |  | $ | — |  |
| December 31, 2020 |  |  |  |  |  |  |  |  |
| Fair value measurement: |  |  |  |  |  |  |  |  |
| Derivative assets (1) |  | $ | 17 |  |  | $ | — |  |  | $ | 17 |  |  | $ | — |  |
| Derivative liabilities (2) |  | $ | (5) |  |  | $ | — |  |  | $ | (5) |  |  | $ | — |  |

[0001783180-22-000010:notes:87]
(1) Included in Other assets, current on the accompanying Consolidated Balance Sheet.

[0001783180-22-000010:notes:88]
(2) Included in Accrued liabilities on the accompanying Consolidated Balance Sheet.

[0001783180-22-000010:notes:89]
The following table provides the carrying amounts and fair values of the Company's long-term notes that are not recorded at fair value in the Consolidated Balance Sheet:

[0001783180-22-000010:notes:90]
|  |  | 2021 |  | 2020 |
| (In millions) |  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |
| Total long-term notes (1) |  | $ | 9,500 |  |  | $ | 9,842 |  |  | $ | 10,000 |  |  | $ | 10,811 |  |

[0001783180-22-000010:notes:91]
(1) Excludes debt discount and issuance costs.

[0001783180-22-000010:notes:92]
The fair value of the Company's long-term debt is measured based on observable market inputs which are considered Level 1 within the fair value hierarchy. The carrying value of cash and cash equivalents, accounts receivable, accounts payable and short-term borrowings approximate fair value due to the short-term nature of these accounts and would be classified as Level 1 in the fair value hierarchy. The Company's financing leases and project financing obligations, included in Long-term debt approximate fair value and are classified as Level 3 in the fair value hierarchy. For the years ended December 31, 2021 and 2020 there were no transfers in or out of levels 1, 2 or 3.


## us-gaap:LesseeFinanceLeasesTextBlock

[0001783180-22-000010:notes:93]
LEASES The Company enters into operating and finance leases for the use of real estate space, vehicles, information technology equipment and certain other equipment. At contract inception, the Company determines a lease exists if the arrangement conveys the right to control an identified asset for a period of time in exchange for consideration. Control is considered to exist when the lessee has the right to obtain substantially all of the economic benefits from the use of an identified asset as well as the right to direct the use of that asset. If a contract is considered to be a lease, the Company recognizes a lease liability based on the present value of the future lease payments with an offsetting entry to recognize a ROU asset. 
Operating lease ROU assets and liabilities are reflected on the Consolidated Balance Sheet as follows:

[0001783180-22-000010:notes:94]
| (In millions) |  | 2021 |  | 2020 |
| Operating lease right-of-use assets |  | $ | 640 |  |  | $ | 788 |  |
| Accrued liabilities |  | $ | (130) |  |  | $ | (161) |  |
| Operating lease liabilities |  | (527) |  |  | (642) |  |
| Total operating lease liabilities |  | $ | (657) |  |  | $ | (803) |  |
| Weighted-Average Remaining Lease Term (in years) |  | 7.8 |  | 7.7 |
| Weighted-Average Discount Rate |  | 3.0 | % |  | 3.4 | % |

[0001783180-22-000010:notes:95]
The operating lease ROU assets include any lease payments related to initial direct costs and prepayments and excludes lease incentives. The Company's leases generally have remaining lease terms of 1 to 23 years, some of which include options to extend. For the majority of its leases with options to extend, those options are up to 5 years with the ability to terminate the lease within 1 to 5 years of inception. The exercise of lease renewal options is at the Company's sole discretion and its lease ROU assets and liabilities reflect only the options the Company is reasonably certain that it will exercise.

[0001783180-22-000010:notes:96]
Supplemental cash flow and lease expense information related to operating leases were as follows:

[0001783180-22-000010:notes:97]
| (In millions) |  | 2021 |  | 2020 |  | 2019 |
| Operating cash flows for measurement of operating lease liabilities |  | $ | 197 |  |  | $ | 213 |  |  | $ | 201 |  |
| Operating lease ROU assets obtained in exchange for operating lease obligations |  | $ | 180 |  |  | $ | 169 |  |  | $ | 136 |  |
| Operating lease expense |  | $ | 200 |  |  | $ | 197 |  |  | $ | 206 |  |

[0001783180-22-000010:notes:98]
Operating lease expense is recognized on a straight-line basis over the lease term. Where applicable, the Company accounts for each separate lease component of a contract and its associated non-lease component as a single lease component.

[0001783180-22-000010:notes:99]
Undiscounted maturities of operating lease liabilities, including options to extend lease terms that are reasonably certain of being exercised, as of December 31, 2021 are as follows:

[0001783180-22-000010:notes:100]
| (In millions) |  |  |
| 2022 |  | $ | 141 |  |
| 2023 |  | 123 |  |
| 2024 |  | 106 |  |
| 2025 |  | 87 |  |
| 2026 |  | 67 |  |
| Thereafter |  | 218 |  |
| Total undiscounted lease payments |  | 742 |  |
| Less: imputed interest |  | (85) |  |
| Total discounted lease payments |  | $ | 657 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001783180-22-000010:notes:101]
EMPLOYEE BENEFIT PLANS 
The Company sponsors both funded and unfunded domestic and international defined benefit pension and defined contribution plans. In addition, the Company contributes to various domestic and international multi-employer defined benefit pension plans.

[0001783180-22-000010:notes:102]
Pension Plans

[0001783180-22-000010:notes:103]
Qualified domestic pension plan benefits covering collectively bargained U.S. employees comprise approximately 34% of the projected benefit obligation. This noncontributory defined benefit plan provides benefits on a flat dollar formula based on

[0001783180-22-000010:notes:104]
location and is closed to new entrants. The non-U.S. plans comprise approximately 66% of the projected benefit obligation; certain of these plans provide participants with one-time payments upon separation of employment rather than a retirement annuity. These plans provide benefits based on a plan specific benefit formula. Non-qualified domestic pension plans provide supplementary retirement benefits to certain employees and are not a material component of the projected benefit obligation.

[0001783180-22-000010:notes:105]
The following table details information regarding the Company's pension plans:

[0001783180-22-000010:notes:106]
| (In millions) | 2021 |  | 2020 |
| Change in Benefit Obligation |  |  |  |
| Benefit obligation at beginning of year | $ | 3,224 |  |  | $ | 2,885 |  |
| Service cost | 27 |  |  | 29 |  |
| Interest cost | 37 |  |  | 52 |  |
| Actuarial (gain) loss (1) | (112) |  |  | 239 |  |
| Benefits paid | (106) |  |  | (116) |  |
| Curtailment, settlements and special termination benefits | (54) |  |  | (16) |  |
| Other, including expenses paid | (48) |  |  | 151 |  |
| Liabilities held for sale (2) | (2,062) |  |  | — |  |
| Benefit obligation at end of year | $ | 906 |  |  | $ | 3,224 |  |
| Change in Plan Assets |  |  |  |
| Fair value at beginning of year | $ | 3,294 |  |  | $ | 2,953 |  |
| Actual return on plan assets | 67 |  |  | 285 |  |
| Company contributions | 47 |  |  | 41 |  |
| Benefits paid | (106) |  |  | (116) |  |
| Settlements | (54) |  |  | (15) |  |
| Other, including expenses paid | (34) |  |  | 146 |  |
| Assets held for sale (2) | (2,623) |  |  | — |  |
| Fair value of assets end of year | $ | 591 |  |  | $ | 3,294 |  |
| Funded status of plans | $ | (315) |  |  | $ | 70 |  |
| Amounts included in the balance sheet: |  |  |  |
| Other non-current assets | $ | 43 |  |  | $ | 542 |  |
| Accrued compensation and benefits | (10) |  |  | (10) |  |
| Post-employment and other benefit liabilities | (348) |  |  | (462) |  |
| Net amount recognized | $ | (315) |  |  | $ | 70 |  |

[0001783180-22-000010:notes:107]
(1) Reflects the impact of foreign exchange translation, primarily for plans in the United Kingdom, Canada and Germany.

[0001783180-22-000010:notes:108]
The key contributor to the movement in the funded position was the reclassification of plans included in the sale of Chubb to held for sale. The plans to be retained by the Company experienced an improvement in the net deficit position due to better than expected asset performance globally, favorable exchange rate movements and an increase in the discount rate used to measure the benefit obligations of the plans. Discount rates in all applicable territories and countries increased over the measurement period as a result of increases in corporate bond yields.

[0001783180-22-000010:notes:109]
The pretax amounts recognized in Accumulated other comprehensive (income) loss are:

[0001783180-22-000010:notes:110]
| (In millions) |  | Prior Service Cost (Benefit) |  | Net Actuarial (Gain) Loss |  | Total |
| As of December 31, 2020 |  | $ | 13 |  |  | $ | 689 |  |  | $ | 702 |  |
| Current year changes recorded in AOCI |  | 4 |  |  | (34) |  |  | (30) |  |
| Amortization reclassified to earnings |  | (2) |  |  | (32) |  |  | (34) |  |
| Settlement/curtailment reclassified to earnings |  | — |  |  | (12) |  |  | (12) |  |
| Currency translation and other |  | — |  |  | (16) |  |  | (16) |  |
| As of December 31, 2021 |  | $ | 15 |  |  | $ | 595 |  |  | $ | 610 |  |

[0001783180-22-000010:notes:111]
Information for pension plans with accumulated benefit obligations in excess of plan assets:

[0001783180-22-000010:notes:112]
| (In millions) | 2021 |  | 2020 |
| Projected benefit obligation | $ | 405 |  |  | $ | 622 |  |
| Accumulated benefit obligation | $ | 374 |  |  | $ | 579 |  |
| Fair value of plan assets | $ | 47 |  |  | $ | 156 |  |

[0001783180-22-000010:notes:113]
Information for pension plans with projected benefit obligations in excess of plan assets:

[0001783180-22-000010:notes:114]
| (In millions) | 2021 |  | 2020 |
| Projected benefit obligation | $ | 405 |  |  | $ | 666 |  |
| Accumulated benefit obligation | $ | 374 |  |  | $ | 615 |  |
| Fair value of plan assets | $ | 47 |  |  | $ | 194 |  |

[0001783180-22-000010:notes:115]
The components of net periodic pension benefits for the defined benefit pension plans are as follows:

[0001783180-22-000010:notes:116]
| (In millions) | 2021 |  | 2020 |  | 2019 |  |  |  |  |
| Service cost | $ | 27 |  |  | $ | 29 |  |  | $ | 31 |  |  |  |  |  |
| Interest cost | 37 |  |  | 52 |  |  | 67 |  |  |  |  |  |
| Expected return on plan assets | (145) |  |  | (140) |  |  | (154) |  |  |  |  |  |
| Amortization of prior service cost | 2 |  |  | 2 |  |  | 2 |  |  |  |  |  |
| Recognized actuarial net loss | 32 |  |  | 22 |  |  | 9 |  |  |  |  |  |
| Net settlement, curtailment and special termination benefit loss | 13 |  |  | 4 |  |  | 4 |  |  |  |  |  |
| Net periodic pension benefit | $ | (34) |  |  | $ | (31) |  |  | $ | (41) |  |  |  |  |  |

[0001783180-22-000010:notes:117]
The accumulated benefit obligation for all defined benefit plans was $0.9 billion and $3.2 billion as of December 31, 2021 and 2020, respectively.

[0001783180-22-000010:notes:118]
Major assumptions used in determining the benefit obligation and net cost for pension plans are presented in the following table as weighted-averages:

[0001783180-22-000010:notes:119]
|  |  | Benefit Obligation |  | Net Costs |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |  | 2019 | (2) |
| Discount rate |  |  |  |  |  |  |  |  |  |  |  |
| Projected benefit obligation | 2.1% |  | 1.4 | % |  | 1.4% |  | 2.0 | % |  | 2.8 | % |  |
| Interest cost (1) |  | —% |  | — | % |  | 1.2% |  | 1.8 | % |  | 2.7 | % |  |
| Service cost (1) |  | —% |  | — | % |  | 2.1% |  | 1.8 | % |  | 3.2 | % |  |
| Salary scale |  | 3.1% |  | 2.8 | % |  | 2.8% |  | 3.3 | % |  | 3.0 | % |  |
| Expected return on plan assets | —% |  | — | % |  | 4.6% |  | 4.9 | % |  | 5.6 | % |  |

[0001783180-22-000010:notes:120]
(1) The 2021 and 2020 discount rates used to measure the service cost and interest cost applies to the significant plans of the Company. The projected benefit obligation discount rate is used for the service cost and interest cost measurements for non-significant plans.

[0001783180-22-000010:notes:121]
(2) Assumptions prior to 2020 include assumptions used for the UTC plan which included Carrier employees.

[0001783180-22-000010:notes:122]
The weighted-average discount rates used to measure pension benefit obligations and net costs are set by reference to specific analyses using each plan’s specific cash flows and high-quality bond indices to assess reasonableness. For those significant plans, the Company utilizes a full yield curve approach in the estimation of the service cost and interest cost components by applying the specific spot rates along the yield curve used in determination of the benefit obligation to the relevant projected cash flows.

[0001783180-22-000010:notes:123]
In determining the expected return on plan assets, the Company considered the relative weighting of plan assets, the historical performance of total plan assets and individual asset classes and economic and other indicators of future performance. Return projections are assessed for reasonableness using a simulation model that incorporates yield curves, credit spreads and risk premiums to project long-term prospective returns.

[0001783180-22-000010:notes:124]
The plans’ investment management objectives include providing the liquidity and asset levels needed to meet current and future benefit payments, while maintaining a prudent degree of portfolio diversification considering interest rate risk and market volatility. Globally, investment strategies target a mix of approximately 50% of growth seeking assets and 50% of income generating and hedging assets using a wide diversification of asset types, fund strategies and investment managers. The growth seeking allocation consists of global public equities in developed and emerging countries and alternative-asset class strategies. Within the income generating assets, the fixed income portfolio primarily consists of government and broadly diversified high quality corporate bonds.

[0001783180-22-000010:notes:125]
The plans seek to reduce interest rate risk and have incorporated liability hedging programs that include the adoption of a risk reduction objective as part of the long-term investment strategy. Under this objective, the income generating and hedging assets typically increase as funded status improves. The hedging programs incorporate a range of assets and investment tools, each with various interest rate sensitivities. As a result of the improved funded status of the plans, due to favorable asset returns and funding of the plans, the income generating and hedging assets increased in recent years.

[0001783180-22-000010:notes:126]
The fair values of pension plan assets by asset category are as follows:

[0001783180-22-000010:notes:127]
|  |  | Quoted Prices in Active Markets for Identical Assets |  | Significant Observable Inputs |  | Significant Unobservable Inputs |  | Not Subject |  |  |
| (In millions) |  | (Level 1) |  | (Level 2) |  | (Level 3) |  | to Leveling |  | Total |
| Asset Category |  |  |  |  |  |  |  |  |  |  |
| Public Equities: |  |  |  |  |  |  |  |  |  |  |
| Global Equities |  | $ | — |  |  | $ | 29 |  |  | $ | — |  |  | $ | — |  |  | $ | 29 |  |
| Global Equity Funds at net asset value (1) (2) |  | — |  |  | — |  |  | — |  |  | 208 |  |  | 208 |  |
| Fixed Income Securities: |  |  |  |  |  |  |  |  |  |  |
| Governments |  | — |  |  | 26 |  |  | — |  |  | — |  |  | 26 |  |
| Corporate Bonds |  | — |  |  | 103 |  |  | — |  |  | — |  |  | 103 |  |
| Fixed Income Securities (2) |  | — |  |  | — |  |  | — |  |  | 189 |  |  | 189 |  |
| Real Estate (3) |  | — |  |  | 9 |  |  | — |  |  | — |  |  | 9 |  |
| Other (4) (5) |  | — |  |  | 5 |  |  | — |  |  | — |  |  | 5 |  |
| Cash & Cash Equivalents (2)(6) |  | — |  |  | 7 |  |  | — |  |  | 3 |  |  | 10 |  |
| Subtotal |  | $ | — |  |  | $ | 179 |  |  | $ | — |  |  | $ | 400 |  |  | $ | 579 |  |
| Other assets and liabilities (7) |  |  |  |  |  |  |  |  |  | 12 |  |
| Total as of December 31, 2021 (8) |  |  |  |  |  |  |  |  |  | $ | 591 |  |
|  |  | Quoted Prices in Active Markets for Identical Assets |  | Significant Observable Inputs |  | Significant Unobservable Inputs |  | Not Subject |  |  |
| (In millions) |  | (Level 1) |  | (Level 2) |  | (Level 3) |  | to Leveling |  | Total |
| Asset Category |  |  |  |  |  |  |  |  |  |  |
| Public Equities: |  |  |  |  |  |  |  |  |  |  |
| Global Equities (1) (2) |  | $ | — |  |  | $ | 52 |  |  | $ | — |  |  | $ | 65 |  |  | $ | 117 |  |
| Global Equity Funds at net asset value (1) |  | — |  |  | — |  |  | — |  |  | 733 |  |  | 733 |  |
| Fixed Income Securities: |  |  |  |  |  |  |  |  |  |  |
| Governments |  | — |  |  | 1,270 |  |  | — |  |  | — |  |  | 1,270 |  |
| Corporate Bonds |  | — |  |  | 121 |  |  | — |  |  | 41 |  |  | 162 |  |
| Fixed Income Securities (2) |  | — |  |  | — |  |  | — |  |  | 923 |  |  | 923 |  |
| Real Estate (3)(2) |  | — |  |  | 2 |  |  | — |  |  | 11 |  |  | 13 |  |
| Other (4)(2)(5) |  | — |  |  | (422) |  |  | — |  |  | 407 |  |  | (15) |  |
| Cash & Cash Equivalents (2)(6) |  | — |  |  | 32 |  |  | — |  |  | 22 |  |  | 54 |  |
| Subtotal |  | $ | — |  |  | $ | 1,055 |  |  | $ | — |  |  | $ | 2,202 |  |  | $ | 3,257 |  |
| Other assets and liabilities (7) |  |  |  |  |  |  |  |  |  | 37 |  |
| Total as of December 31, 2020 |  |  |  |  |  |  |  |  |  | $ | 3,294 |  |

[0001783180-22-000010:notes:128]
(1) Represents commingled funds that invest primarily in common stocks.

[0001783180-22-000010:notes:129]
(2) In accordance with ASU 2015-07, Fair Value Measurement (Topic 820), certain investments that are measured at fair value using the net asset value per share (or its equivalent) practical expedient have not been classified in the fair value hierarchy. The fair value amounts presented in this table are intended to permit reconciliation of the fair value hierarchy to the amounts presented for the total pension plan assets.

[0001783180-22-000010:notes:130]
(3) Represents investments in real estate, including commingled funds and directly held properties.

[0001783180-22-000010:notes:131]
(4) Represents insurance contracts and global balanced risk commingled funds consisting mainly of equity, bonds and some commodities.

[0001783180-22-000010:notes:132]
(5) Includes fixed income repurchase agreements entered into for purposes of pension asset and liability matching.

[0001783180-22-000010:notes:133]
(6) Represents short-term commercial paper, bonds and other cash or cash-like instruments.

[0001783180-22-000010:notes:134]
(7) Represents trust receivables and payables that are not leveled.

[0001783180-22-000010:notes:135]
(8) Chubb plan assets for 2021, totaling $2.6 billion are not included within this table, as the business has been reclassified as held for sale.

[0001783180-22-000010:notes:136]
Derivatives in the plan are primarily used to manage risk and gain asset class exposure while still maintaining liquidity. Derivative instruments mainly consist of fixed income repurchase agreements, interest rate swaps, total return swaps and currency forward contracts.

[0001783180-22-000010:notes:137]
Quoted market prices are used to value investments when available. Investments in securities traded on exchanges, including listed futures and options, are valued at the last reported sale prices on the last business day of the year or, if not available, the

[0001783180-22-000010:notes:138]
last reported bid prices. Fixed income securities are primarily measured using a market approach pricing methodology, whereby observable prices are obtained by market transactions involving identical or comparable securities of issuers with similar credit ratings. Over-the-counter securities and government obligations are valued at the bid prices or the average of the bid and ask prices on the last business day of the year from published sources or, if not available, from other sources considered reliable, including broker quotes. Temporary cash investments are stated at cost, which approximates fair value.

[0001783180-22-000010:notes:139]
For the years ended December 31, 2021, 2020 and 2019, the Company made $47 million, $41 million and $36 million, respectively, of cash contributions to its defined benefit pension plans. The Company expects to make total contributions of approximately $3 million to its defined benefit pension plans in 2022. Contributions do not reflect benefits to be paid directly from corporate assets. Benefit payments, including amounts to be paid from corporate assets, and reflecting expected future service, as appropriate, are expected to be paid as follows: $25 million in 2022, $28 million in 2023, $29 million in 2024, $32 million in 2025, $34 million in 2026 and $197 million from 2027 through 2030.

[0001783180-22-000010:notes:140]
Multiemployer Benefit Plans

[0001783180-22-000010:notes:141]
The Company contributes to various domestic and foreign multiemployer defined benefit pension plans. The risks of participating in these multiemployer plans are different from those of single-employer plans in that assets contributed are pooled and may be used to provide benefits to employees of other participating employers. If a participating employer stops contributing to the plan, the unfunded obligations of the plan may be borne by the remaining participating employers. The Company's contributions to these plans for the years ended December 31, 2021 and 2020 was $14 million and $15 million, respectively.

[0001783180-22-000010:notes:142]
Employee Savings Plans

[0001783180-22-000010:notes:143]
The Company sponsors various employee savings plans. Certain employees of Carrier participate in these plans. Carrier’s contributions to employer sponsored defined contribution plans were $115 million, $103 million and $88 million for the years ended December 31, 2021, 2020 and 2019, respectively.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001783180-22-000010:notes:144]
PRODUCT WARRANTIES 
In the ordinary course of business, the Company provides standard warranty coverage on its products. Provisions for these amounts are established at the time of sale and estimated primarily based on product warranty terms and historical claims experience. In addition, the Company incurs discretionary costs to service its products in connection with specific product performance issues. Provisions for these amounts are established when they are known and estimable. The Company assesses the adequacy of its initial provisions and will make adjustments as necessary based on known or anticipated claims or as new information becomes available that suggests it is probable that future costs will be different than estimated amounts. Amounts associated with these provisions are classified as Accrued liabilities or Other long-term liabilities based on their anticipated settlement date.

[0001783180-22-000010:notes:145]
The changes is the carrying amount of warranty related provisions are as follows:

[0001783180-22-000010:notes:146]
| (In millions) | 2021 |  | 2020 |
| Balance as of January 1, | $ | 514 |  |  | $ | 488 |  |
| Warranties, performance guarantees issued and changes in estimated liability | 172 |  |  | 167 |  |
| Settlements made | (165) |  |  | (146) |  |
| Other | 3 |  |  | 5 |  |
| Balance as of December 31, | $ | 524 |  |  | $ | 514 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001783180-22-000010:notes:147]
EQUITY 
Share Repurchase Program

[0001783180-22-000010:notes:148]
In July 2021, the Company's Board of Directors authorized a $1.75 billion increase to the Company's existing $350 million stock repurchase program. The program allows the Company to repurchase its outstanding common stock from time to time subject to market conditions and at the Company's discretion in the open market or through one or more other public or private transactions and subject to compliance with the Company's obligations under the TMA. The Company records repurchases under the cost method whereby the entire cost of the acquired stock is recorded as Treasury stock as a reduction to equity. The reissuance of treasury stock uses the first-in, first-out method of accounting.

[0001783180-22-000010:notes:149]
The Company repurchased 10.4 million shares of common stock for an aggregate purchase price of $529 million for the year ended December 31, 2021, which are held in Treasury stock as of December 31, 2021 as reflected on its Consolidated Balance Sheet.

[0001783180-22-000010:notes:150]
Accumulated Other Comprehensive Income (Loss)

[0001783180-22-000010:notes:151]
A summary of the changes in each component of Accumulated other comprehensive income (loss) is as follows:

[0001783180-22-000010:notes:152]
| (In millions) | Foreign Currency Translation |  | Defined Benefit Pension and Post-retirement Plans |  |  |  |  |  |  |  | Accumulated Other Comprehensive Income (Loss) |
| Balance as of January 1, 2019 | $ | (834) |  |  | $ | (381) |  |  |  |  |  |  |  |  | $ | (1,215) |  |
| Other comprehensive income (loss) before reclassifications, net | 52 |  |  | (109) |  |  |  |  |  |  |  |  | (57) |  |
| Amounts reclassified, pre-tax | 2 |  |  | 11 |  |  |  |  |  |  |  |  | 13 |  |
| Tax benefit reclassified | — |  |  | 15 |  |  |  |  |  |  |  |  | 15 |  |
| ASU 2018-02 adoption impact | — |  |  | (9) |  |  |  |  |  |  |  |  | (9) |  |
| Balance as of December 31, 2019 | $ | (780) |  |  | $ | (473) |  |  |  |  |  |  |  |  | $ | (1,253) |  |
| Other comprehensive income (loss) before reclassifications, net | 589 |  |  | 2 |  |  |  |  |  |  |  |  | 591 |  |
| Amounts reclassified, pre-tax | — |  |  | (105) |  |  |  |  |  |  |  |  | (105) |  |
| Tax benefit reclassified | — |  |  | 22 |  |  |  |  |  |  |  |  | 22 |  |
| Balance as of December 31, 2020 | $ | (191) |  |  | $ | (554) |  |  |  |  |  |  |  |  | $ | (745) |  |
| Other comprehensive income (loss) before reclassifications, net | (322) |  |  | 53 |  |  |  |  |  |  |  |  | (269) |  |
| Amounts reclassified, pre-tax | 8 |  |  | 34 |  |  |  |  |  |  |  |  | 42 |  |
| Tax benefit reclassified | — |  |  | (17) |  |  |  |  |  |  |  |  | (17) |  |
| Balance as of December 31, 2021 | $ | (505) |  |  | $ | (484) |  |  |  |  |  |  |  |  | $ | (989) |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001783180-22-000010:notes:153]
REVENUE RECOGNITION The Company accounts for revenue in accordance with ASC 606: Revenue from Contracts with Customers. Revenue is recognized when control of a good or service promised in a contract (i.e., performance obligation) is transferred to a customer. Control is obtained when a customer has the ability to direct the use of and obtain substantially all of the remaining benefits from that good or service. A significant portion of the Company's performance obligations are recognized at a point-in-time when control of the product transfers to the customer, which is generally the time of shipment. The remaining portion of the Company’s performance obligations are recognized over time as the customer simultaneously obtains control as the Company performs work under a contract, or if the product being produced for the customer has no alternative use and the Company has a contractual right to payment. 
Performance Obligations

[0001783180-22-000010:notes:154]
A performance obligation is a distinct good, service or a bundle of goods and services promised in a contract. Some of the Company's contracts with customers contain a single performance obligation, while others contain multiple performance obligations most commonly when a contract spans multiple phases of a product life-cycle such as production, installation, maintenance and support. The Company identifies performance obligations at the inception of a contract and allocates the transaction price to each distinct performance obligation. Revenue is recognized when or as the performance obligation is satisfied. When there are multiple performance obligations within a contract, the Company allocates the transaction price to each performance obligation based on its relative stand-alone selling price.

[0001783180-22-000010:notes:155]
The Company primarily generates revenue from the sale of products to customers and recognizes revenue at a point in time when control transfers to the customer. Transfer of control is generally based on the shipping terms of the contract. In addition, the Company recognizes revenue on an over-time basis on installation and service contracts. For over-time performance obligations requiring the installation of equipment, revenue is recognized using costs incurred to date relative to total estimated costs at completion to measure progress. Incurred costs represent work performed, which correspond with and best depict transfer of control to the customer. Contract costs include direct costs such as labor, materials and subcontractors’ costs and where applicable, indirect costs.

[0001783180-22-000010:notes:156]
Segment sales disaggregated by product and service are as follows:

[0001783180-22-000010:notes:157]
| (In millions) |  | 2021 |  | 2020 |  | 2019 |
| Sales Type |  |  |  |  |  |  |
| Product |  | $ | 9,985 |  |  | $ | 8,165 |  |  | $ | 8,279 |  |
| Service |  | 1,405 |  |  | 1,313 |  |  | 1,433 |  |
| HVAC sales |  | 11,390 |  |  | 9,478 |  |  | 9,712 |  |
| Product |  | 3,653 |  |  | 2,927 |  |  | 3,405 |  |
| Service |  | 474 |  |  | 406 |  |  | 387 |  |
| Refrigeration sales |  | 4,127 |  |  | 3,333 |  |  | 3,792 |  |
| Product |  | 3,985 |  |  | 3,585 |  |  | 4,072 |  |
| Service |  | 1,530 |  |  | 1,400 |  |  | 1,428 |  |
| Fire & Security sales |  | 5,515 |  |  | 4,985 |  |  | 5,500 |  |
| Total segment sales |  | 21,032 |  |  | 17,796 |  |  | 19,004 |  |
| Eliminations and other |  | (419) |  |  | (340) |  |  | (396) |  |
| Consolidated |  | $ | 20,613 |  |  | $ | 17,456 |  |  | $ | 18,608 |  |

[0001783180-22-000010:notes:158]
The transaction price allocated to performance obligations reflects the Company’s expectations about the consideration it will be entitled to receive from a customer. The Company includes variable consideration in the estimated transaction price when there is a basis to reasonably estimate the amount and when it is probable that a significant reversal of revenue recognized would not occur when the uncertainty associated with variable consideration is subsequently resolved. In addition, the Company customarily offers its customers incentives to purchase products to ensure an adequate supply of its products in distribution channels. The principal incentive programs provide reimbursements to distributors for offering promotional pricing for products. The Company accounts for estimated incentive payments as a reduction in sales at the time a sale is recognized.

[0001783180-22-000010:notes:159]
Contract Balances

[0001783180-22-000010:notes:160]
Total contract assets and liabilities consisted of the following:

[0001783180-22-000010:notes:161]
| (In millions) | 2021 |  | 2020 |
| Contract assets, current | $ | 503 |  |  | $ | 656 |  |
| Contract assets, non-current (included within Other assets) | 70 |  |  | 98 |  |
| Total contract assets | 573 |  |  | 754 |  |
| Contract liabilities, current | (415) |  |  | (512) |  |
| Contract liabilities, non-current (included within Other long-term liabilities) | (165) |  |  | (165) |  |
| Total contract liabilities | (580) |  |  | (677) |  |
| Net contract assets (liabilities) | $ | (7) |  |  | $ | 77 |  |

[0001783180-22-000010:notes:162]
The timing of revenue recognition, billings and cash collections results in contract assets and contract liabilities. Contract assets relate to the conditional right to consideration for any completed performance under a contract when costs are incurred in excess of billings under the percentage-of-completion methodology. Contract liabilities relate to payments received in advance of performance under the contract or when the Company has a right to consideration that is conditioned upon transfer of a good or service to the customer. Contract liabilities are recognized as revenue as (or when) the Company performs under the contract.

[0001783180-22-000010:notes:163]
The Company recognized revenue of $408 million for the year ended December 31, 2021 that was related to contract liabilities as of January 1, 2021. The Company expects a majority of its contract liabilities at the end of the period to be recognized as revenue over the next 12 months. There were no individually significant customers with sales exceeding 10% of total sales for the years ended December 31, 2021, 2020 and 2019.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0001783180-22-000010:notes:164]
The Company accounts for revenue in accordance with ASC 606: Revenue from Contracts with Customers. Revenue is recognized when control of a good or service promised in a contract (i.e., performance obligation) is transferred to a customer. Control is obtained when a customer has the ability to direct the use of and obtain substantially all of the remaining benefits from that good or service. A significant portion of the Company's performance obligations are recognized at a point-in-time when control of the product transfers to the customer, which is generally the time of shipment. The remaining portion of the Company’s performance obligations are recognized over time as the customer simultaneously obtains control as the Company performs work under a contract, or if the product being produced for the customer has no alternative use and the Company has a contractual right to payment. 
Performance Obligations

[0001783180-22-000010:notes:165]
The Company primarily generates revenue from the sale of products to customers and recognizes revenue at a point in time when control transfers to the customer. Transfer of control is generally based on the shipping terms of the contract. In addition, the Company recognizes revenue on an over-time basis on installation and service contracts. For over-time performance obligations requiring the installation of equipment, revenue is recognized using costs incurred to date relative to total estimated costs at completion to measure progress. Incurred costs represent work performed, which correspond with and best depict transfer of control to the customer. Contract costs include direct costs such as labor, materials and subcontractors’ costs and where applicable, indirect costs.
The transaction price allocated to performance obligations reflects the Company’s expectations about the consideration it will be entitled to receive from a customer. The Company includes variable consideration in the estimated transaction price when there is a basis to reasonably estimate the amount and when it is probable that a significant reversal of revenue recognized would not occur when the uncertainty associated with variable consideration is subsequently resolved. In addition, the Company customarily offers its customers incentives to purchase products to ensure an adequate supply of its products in distribution channels. The principal incentive programs provide reimbursements to distributors for offering promotional pricing for products. The Company accounts for estimated incentive payments as a reduction in sales at the time a sale is recognized.The timing of revenue recognition, billings and cash collections results in contract assets and contract liabilities. Contract assets relate to the conditional right to consideration for any completed performance under a contract when costs are incurred in excess of billings under the percentage-of-completion methodology. Contract liabilities relate to payments received in advance of performance under the contract or when the Company has a right to consideration that is conditioned upon transfer of a good or service to the customer. Contract liabilities are recognized as revenue as (or when) the Company performs under the contract.


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0001783180-22-000010:notes:166]
|  |  | External Sales |  | Long-Lived Assets |  |  |  |
| (In millions) |  | 2021 |  | 2020 |  | 2019 |  | 2021 |  | 2020 |  |  |  |
| United States Operations |  | $ | 10,492 |  |  | $ | 9,105 |  |  | $ | 9,594 |  |  | $ | 772 |  |  | $ | 782 |  |  |  |  |
| International Operations |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Europe |  | 5,776 |  |  | 4,935 |  |  | 5,327 |  |  | 476 |  |  | 490 |  |  |  |  |
| Asia Pacific |  | 3,464 |  |  | 2,655 |  |  | 2,813 |  |  | 279 |  |  | 249 |  |  |  |  |
| Other |  | 881 |  |  | 761 |  |  | 874 |  |  | 299 |  |  | 289 |  |  |  |  |
| Consolidated |  | $ | 20,613 |  |  | $ | 17,456 |  |  | $ | 18,608 |  |  | $ | 1,826 |  |  | $ | 1,810 |  |  |  |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001783180-22-000010:notes:167]
STOCK-BASED COMPENSATION
The Company accounts for stock-based compensation plans in accordance with ASC 718, Compensation - Stock Compensation, which requires a fair-value based method for measuring the value of stock-based compensation. Fair value is measured at the date of grant and is generally not adjusted for subsequent changes. The Company's stock-based compensation plans include programs for stock appreciation rights, restricted stock and performance share units.

[0001783180-22-000010:notes:168]
Stock Options and Appreciation Rights

[0001783180-22-000010:notes:169]
Eligible participants may receive stock options or stock appreciation rights as part of the Company's long-term incentive program. The fair value of each instrument is determined as of the date of grant using a binomial lattice model and expensed on a straight-line basis over the required service period, which is generally a three-year vesting period. However, in the event of retirement, awards held for at least one year may vest and become exercisable (if applicable), subject to certain terms and conditions.

[0001783180-22-000010:notes:170]
The following table summarizes fair value information for stock options and stock appreciation rights:

[0001783180-22-000010:notes:171]
|  |  | 2021 (1) |  | 2020 (1) |  | 2019 (2) |
| Stock options and stock appreciation rights weighted-average fair value per award |  | $ | 10.13 |  |  | $ | 4.67 |  |  | $ | 21.02 |  |
| Assumptions: |  |  |  |  |  |  |
| Volatility |  | 31.6% to 34.1% |  | 32.1% to 35.6% |  | 18.8% to 19.7% |
| Expected term (in years) |  | 6.6 |  | 7.0 |  | 6.5 to 6.6 |
| Expected dividend yield |  | 1.5% |  | 1.4% to 2.0% |  | 2.4% |
| Range of risk-free rates |  | 0.7% to 1.4% |  | 0.1% to 1.0% |  | 2.3% to 2.7% |

[0001783180-22-000010:notes:172]
(1) Carrier has limited historical trading data and used peer group data to estimate expected volatility for the 2021 and 2020 awards.

[0001783180-22-000010:notes:173]
(2) The assumptions for 2019 were determined by UTC based on UTC's stock price performance.

[0001783180-22-000010:notes:174]
The Company used historical employee data, including data prior to the Separation and the Distribution, to estimate expected term. The expected dividend yield is consistent with management's expectations. The risk-free rate is based on the term structure of interest rates at the time the awards were granted.

[0001783180-22-000010:notes:175]
Changes in stock options and stock appreciation rights outstanding subsequent to the Separation and Distribution were as follows:

[0001783180-22-000010:notes:176]
|  | Shares Subject to Option(in thousands) |  | Weighted-Average Exercise Price |  | Aggregate Intrinsic Value (in millions) |  | Weighted- Average Remaining Life (in years) |
| As of April 3, 2020 | 36,015 |  |  | $ | 19.90 |  |  |  |  |  |
| Granted | 3,921 |  |  | $ | 17.57 |  |  |  |  |  |
| Exercised | (2,620) |  |  | $ | 15.81 |  |  |  |  |  |
| Cancelled | (584) |  |  | $ | 22.31 |  |  |  |  |  |
| As of December 31, 2020 | 36,732 |  |  | $ | 19.91 |  |  |  |  |  |
| Granted | 3,194 |  |  | $ | 38.92 |  |  |  |  |  |
| Exercised | (5,934) |  |  | $ | 17.59 |  |  |  |  |  |
| Cancelled | (1,551) |  |  | $ | 23.98 |  |  |  |  |  |
| Outstanding as of December 31, 2021 | 32,441 |  |  | $ | 22.02 |  |  | $ | 1,046 |  |  | 6.3 |
| Exercisable as of December 31, 2021 | 14,613 |  |  | $ | 18.96 |  |  | $ | 516 |  |  | 4.3 |

[0001783180-22-000010:notes:177]
Restricted Stock Units

[0001783180-22-000010:notes:178]
Eligible participants may receive restricted stock units ("RSU") as part of the Company's long-term incentive program. The fair value of restricted stock units are based on the closing market price of the Company's common stock on the date of grant and expensed on a straight-line basis over the required service period (which is generally the three-year vesting period). However, in the event of retirement, awards held for at least one year may vest and become exercisable (if applicable), subject to certain terms and conditions. Dividends accrue during the vesting period and are paid in shares of the Company's common stock.

[0001783180-22-000010:notes:179]
Changes in restricted stock units subsequent to the Separation and Distribution were as follows:

[0001783180-22-000010:notes:180]
|  | RSUs (in thousands) |  | Weighted-Average Grant Date Fair Value |
| Outstanding and unvested as of April 3, 2020 | 5,622 |  |  | $ | 21.37 |  |
| Granted | 523 |  |  | $ | 21.43 |  |
| Vested | (483) |  |  | $ | 19.74 |  |
| Cancelled | (88) |  |  | $ | 23.29 |  |
| Outstanding and unvested as of December 31, 2020 | 5,574 |  |  | $ | 21.57 |  |
| Granted | 286 |  |  | $ | 46.49 |  |
| Vested | (2,168) |  |  | $ | 21.45 |  |
| Cancelled | (122) |  |  | $ | 25.39 |  |
| Outstanding and unvested as of December 31, 2021 | 3,570 |  |  | $ | 23.33 |  |

[0001783180-22-000010:notes:181]
Performance Share Units

[0001783180-22-000010:notes:182]
The Company has a performance share program for key employees whereby awards are provided in the form of performance share units ("PSU") based on performance against pre-established objectives. The annual target level is expressed as shares of the Company's common stock based on the fair value of its stock on the date of grant. Awards are earned over a three-year performance period based equally on a performance condition, measured by the compound annual growth rate of the Company's earnings per share and on a market condition, measured by the Company's relative total shareowner return compared to the total shareowner return of a subset of industrial companies in the S&P 500 Index. The fair value of the market condition is estimated using a Monte Carlo simulation approach. The fair value of the PSU awards are expensed over the

[0001783180-22-000010:notes:183]
required service period, which is generally a three-year vesting period. In the event of retirement, performance share units held for at least one year remain eligible to vest based on actual performance relative to pre-established metrics. Dividends do not accrue on the performance share units during the performance period.

[0001783180-22-000010:notes:184]
Changes in PSUs subsequent to the Separation and Distribution were as follows:

[0001783180-22-000010:notes:185]
|  | PSUs (in thousands) |  | Weighted-Average Grant Date Fair Value |
| Outstanding and unvested as of April 3, 2020 | 68 |  |  | $ | 21.23 |  |
| Granted | 728 |  |  | $ | 18.23 |  |
| Forfeited | (24) |  |  | $ | 19.25 |  |
| Outstanding and unvested as of December 31, 2020 | 772 |  |  | $ | 18.46 |  |
| Granted | 821 |  |  | $ | 41.48 |  |
| Vested | (20) |  |  | $ | 23.72 |  |
| Forfeited | (152) |  |  | $ | 27.28 |  |
| Outstanding and unvested as of December 31, 2021 | 1,421 |  |  | $ | 30.75 |  |

[0001783180-22-000010:notes:186]
Compensation Expense

[0001783180-22-000010:notes:187]
Stock-based compensation expense, net of estimated forfeitures, is included in Cost of products sold , Selling, general and administrative and Research and development, in the accompanying Consolidated Statement of Operations.

[0001783180-22-000010:notes:188]
Stock-based compensation cost by award type are as follows:

[0001783180-22-000010:notes:189]
| (In millions) | 2021 |  | 2020 (1) |  | 2019 (1) |
| Equity compensation costs - equity settled | $ | 92 |  |  | $ | 77 |  |  | $ | 52 |  |
| Equity compensation costs - cash settled (2) | 19 |  |  | 11 |  |  | 6 |  |
| Total stock-based compensation cost | $ | 111 |  |  | $ | 88 |  |  | $ | 58 |  |
| Income tax benefit | $ | 13 |  |  | $ | 9 |  |  | $ | 11 |  |

[0001783180-22-000010:notes:190]
(1) The stock-based compensation cost for 2020 and 2019 include amounts allocated to Carrier by UTC related to its direct employees.

[0001783180-22-000010:notes:191]
(2) The cash settled awards are classified as liability awards and are measured at fair value at each balance sheet date.

[0001783180-22-000010:notes:192]
Prior to the Separation and the Distribution, the Company participated in UTC’s long-term incentive plans, which authorized various types of market and performance-based incentive awards. Stock-based compensation expense was allocated to the Company from UTC based upon direct employee headcount. In connection with the Separation and the Distribution, all awards were converted to Carrier stock-based awards with unvested awards converted to preserve the aggregate intrinsic value immediately before and after the Separation.

[0001783180-22-000010:notes:193]
As of December 31, 2021 and 2020, there were $77 million and $91 million of unrecognized stock-based compensation costs related to non-vested awards granted under the plan, respectively, which will be recognized ratably over the awards weighted-average vesting period of 2 years.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001783180-22-000010:notes:194]
RESTRUCTURING COSTS 
The Company incurs costs associated with restructuring initiatives intended to improve operating performance, profitability and working capital levels. Actions associated with these initiatives may include improving productivity, workforce reductions and the consolidation of facilities.

[0001783180-22-000010:notes:195]
The Company recorded net pre-tax restructuring costs for new and ongoing restructuring actions as follows:

[0001783180-22-000010:notes:196]
| (In millions) | 2021 |  | 2020 |  | 2019 |
| HVAC | $ | 33 |  |  | $ | 7 |  |  | $ | 56 |  |
| Refrigeration | 25 |  |  | 12 |  |  | 14 |  |
| Fire & Security | 26 |  |  | 28 |  |  | 53 |  |
| Total Segment | 84 |  |  | 47 |  |  | 123 |  |
| General corporate expenses | 5 |  |  | 2 |  |  | 3 |  |
| Total restructuring costs | $ | 89 |  |  | $ | 49 |  |  | $ | 126 |  |
| Cost of sales | $ | 28 |  |  | $ | 20 |  |  | $ | 36 |  |
| Selling, general and administrative | 60 |  |  | 29 |  |  | 90 |  |
| Other income (expense), net | 1 |  |  | — |  |  | — |  |
| Total restructuring costs | $ | 89 |  |  | $ | 49 |  |  | $ | 126 |  |

[0001783180-22-000010:notes:197]
The following table summarizes the reserves and charges related to the restructuring reserve:

[0001783180-22-000010:notes:198]
| (In millions) |  | 2021 |  | 2020 |
| Balance as of January 1, |  | $ | 49 |  |  | $ | 66 |  |
| Net pre-tax restructuring costs |  | 89 |  |  | 49 |  |
| Utilization, foreign exchange and other |  | (76) |  |  | (66) |  |
| Reclassified to held for sale |  | (8) |  |  | — |  |
| Balance as of December 31, |  | $ | 54 |  |  | $ | 49 |  |

[0001783180-22-000010:notes:199]
During the year ended December 31, 2021, charges associated with restructuring initiatives related to cost reduction efforts. Amounts recognized primarily related to severance due to workforce reductions and exit costs due to the consolidation of field operations. As of December 31, 2021, the Company had $54 million accrued for costs associated with its announced restructuring initiatives, all of which is expected to be paid within one year.


## us-gaap:OtherIncomeAndOtherExpenseDisclosureTextBlock

[0001783180-22-000010:notes:200]
OTHER INCOME (EXPENSE), NET
Other income (expense), net consisted of the following:

[0001783180-22-000010:notes:201]
| (In millions) | 2021 |  | 2020 |  | 2019 |
| Transaction gains (1) | $ | — |  |  | $ | 1,123 |  |  | $ | — |  |
| Impairment charge on minority-owned joint venture investments (1) | (2) |  |  | (72) |  |  | (108) |  |
| Other | 41 |  |  | (45) |  |  | 106 |  |
| Other income (expense), net | $ | 39 |  |  | $ | 1,006 |  |  | $ | (2) |  |

[0001783180-22-000010:notes:202]
(1) See Note 22 - Related Parties for additional information.

[0001783180-22-000010:notes:203]
Other income (expense), net primarily includes the impact of gains and losses related to the sale of interests in equity method investments, foreign currency gains and losses on transactions that are denominated in a currency other than the entity's functional currency and hedging-related activities.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001783180-22-000010:notes:204]
INCOME TAXES 
Income Before Income Taxes

[0001783180-22-000010:notes:205]
The sources of Income from operations before income taxes are as follows:

[0001783180-22-000010:notes:206]
| (In millions) | 2021 |  | 2020 |  | 2019 |
| United States | $ | 1,528 |  |  | $ | 915 |  |  | $ | 1,460 |  |
| Foreign | 872 |  |  | 1,940 |  |  | 1,212 |  |
| Total | $ | 2,400 |  |  | $ | 2,855 |  |  | $ | 2,672 |  |

[0001783180-22-000010:notes:207]
Provision for Income Taxes

[0001783180-22-000010:notes:208]
The income tax expense (benefit) consisted of the following components:

[0001783180-22-000010:notes:209]
| (In millions) | 2021 |  | 2020 |  | 2019 |
| Current: |  |  |  |  |  |
| United States: |  |  |  |  |  |
| Federal | $ | 336 |  |  | $ | 434 |  |  | $ | 262 |  |
| State | 83 |  |  | 74 |  |  | 72 |  |
| Foreign | 354 |  |  | 244 |  |  | 305 |  |
|  | 773 |  |  | 752 |  |  | 639 |  |
| Future: |  |  |  |  |  |
| United States: |  |  |  |  |  |
| Federal | (125) |  |  | 13 |  |  | (14) |  |
| State | (14) |  |  | 6 |  |  | (2) |  |
| Foreign | 65 |  |  | 78 |  |  | (106) |  |
|  | (74) |  |  | 97 |  |  | (122) |  |
| Income tax expense | $ | 699 |  |  | $ | 849 |  |  | $ | 517 |  |

[0001783180-22-000010:notes:210]
Reconciliation of Effective Income Tax Rate

[0001783180-22-000010:notes:211]
The differences between the effective income tax rate and the statutory U.S. federal income tax rate are as follows:

[0001783180-22-000010:notes:212]
|  | 2021 |  | 2020 |  | 2019 |
| Statutory U.S. federal income tax rate | 21.0 | % |  | 21.0 | % |  | 21.0 | % |
| State income tax | 1.9 |  |  | 1.7 |  |  | 2.5 |  |
| Tax on international activities | 7.2 |  |  | 4.2 |  |  | 3.3 |  |
| Separation impact | — |  |  | 3.4 |  |  | (0.7) |  |
| Tax audit settlements | — |  |  | — |  |  | (5.6) |  |
| Other | (1.0) |  |  | (0.6) |  |  | (1.1) |  |
| Effective income tax rate | 29.1 | % |  | 29.7 | % |  | 19.4 | % |

[0001783180-22-000010:notes:213]
The effective tax rate for the year ended December 31, 2021 includes a net tax charge of $157 million primarily relating to the re-organization and disentanglement of certain Chubb subsidiaries executed in advance of the planned divestiture of Chubb, a $43 million deferred tax charge as a result of the tax rate increase from 19% to 25% in the United Kingdom, partially offset by a favorable tax adjustment of $70 million due to foreign tax credits generated and expected to be utilized in the current year and $21 million resulting from the re-organization of a German subsidiary.

[0001783180-22-000010:notes:214]
The effective tax rate for the year ended December 31, 2020 reflects a $51 million charge related to a valuation allowance recorded against a United Kingdom tax loss and credit carryforward and a charge of $46 million resulting from the Company's decision to no longer permanently reinvest certain pre-2018 unremitted non-U.S. earnings. These items were impacted by the Separation and are included in "Separation impact" in the previous table.

[0001783180-22-000010:notes:215]
The effective tax rate for the year ended December 31, 2019 reflects a net tax benefit of $149 million as a result of the filing by a subsidiary of the Company to participate in an amnesty program offered by the Italian Tax Authority and the conclusion of an audit by the IRS for UTC's 2014, 2015 and 2016 tax years.

[0001783180-22-000010:notes:216]
Deferred Tax Assets and Liabilities

[0001783180-22-000010:notes:217]
Future income taxes represent the tax effects of transactions, which are reported in different periods for tax and GAAP purposes. These amounts consist of the tax effects of differences between tax and GAAP that are expected to be reversed in the future and tax carryforwards. Future income tax benefits and payables within the same tax paying component of a particular jurisdiction are offset for presentation in the Consolidated Balance Sheet.

[0001783180-22-000010:notes:218]
The tax effects of temporary differences and tax carryforwards which give rise to future income tax benefits and payables as of December 31, 2021 and 2020 are as follows:

[0001783180-22-000010:notes:219]
| (In millions) | 2021 |  | 2020 |
| Future income tax benefits: |  |  |  |
| Insurance and employee benefits | $ | 198 |  |  | $ | 109 |  |
| Other assets basis differences | 166 |  |  | 152 |  |
| Other liabilities basis differences | 512 |  |  | 487 |  |
| Tax loss carryforward | 175 |  |  | 258 |  |
| Tax credit carryforward | 24 |  |  | 63 |  |
| Valuation allowances | (90) |  |  | (231) |  |
| Future income tax benefit | $ | 985 |  |  | $ | 838 |  |
| Future income tax payables: |  |  |  |
| Goodwill and intangible assets | $ | (270) |  |  | $ | (411) |  |
| Other asset basis differences | (307) |  |  | (336) |  |
| Future income tax payables | $ | (577) |  |  | $ | (747) |  |

[0001783180-22-000010:notes:220]
Valuation allowances have been established primarily for tax credit carryforwards, tax loss carryforwards and certain foreign temporary differences to reduce future income tax benefits to expected realizable amounts. As of December 31, 2021, future income tax benefits and future income tax payables exclude a net liability of $266 million classified as held for sale. See Note 20 - Divestitures for additional information.

[0001783180-22-000010:notes:221]
Changes to valuation allowances consisted of the following:

[0001783180-22-000010:notes:222]
| (In millions) |  |  |
| Balance as of January 1, 2019 |  | $ | 107 |  |
| Additions charged to income tax expense |  | 41 |  |
| Reduction credited to income tax expense |  | (16) |  |
| Other adjustments |  | (4) |  |
| Balance as of December 31, 2019 |  | $ | 128 |  |
| Additions charged to income tax expense (1) |  | 112 |  |
| Reduction credited to income tax expense |  | (13) |  |
| Other adjustments |  | 4 |  |
| Balance as of December 31, 2020 |  | $ | 231 |  |
| Additions charged to income tax expense |  | 32 |  |
| Reduction credited to income tax expense |  | (22) |  |
| Other adjustments |  | (41) |  |
| Reclassified to held for sale |  | (110) |  |
| Balance as of December 31, 2021 |  | $ | 90 |  |

[0001783180-22-000010:notes:223]
(1) Includes $89 million relating to "Separation impact" discussed in section "Reconciliation of Effective Income Tax Rate."

[0001783180-22-000010:notes:224]
Tax Credit and Loss Carryforwards

[0001783180-22-000010:notes:225]
As of December 31, 2021, tax credit carryforwards and tax loss carryforwards, excluding amounts associated with Chubb entities, were as follows:

[0001783180-22-000010:notes:226]
| (In millions) | Tax Loss Carryforwards |  | Tax Credit Carryforwards |
| Expiration period: |  |  |  |
| 2022-2026 | $ | 100 |  |  | $ | 7 |  |
| 2027-2031 | 58 |  |  | 5 |  |
| 2032-2041 | 32 |  |  | 4 |  |
| Indefinite | 599 |  |  | 8 |  |
| Total | $ | 789 |  |  | $ | 24 |  |

[0001783180-22-000010:notes:227]
The Company assesses the realizability of its deferred tax assets on a quarterly basis through an analysis of potential sources of future taxable income, including prior year taxable income available to absorb a carryback of tax losses, reversals of existing taxable temporary differences, tax planning strategies and forecasts of taxable income. The Company considers all negative and positive evidence, including the weight of the evidence, to determine if valuation allowances against deferred tax assets are required. The Company maintains valuation allowances against certain deferred tax assets, primarily in non-U.S. jurisdictions.

[0001783180-22-000010:notes:228]
Unrecognized Tax Benefits

[0001783180-22-000010:notes:229]
As of December 31, 2021, the Company had unrecognized tax benefits of $251 million, all of which, if recognized, would impact its effective tax rate. A reconciliation of the beginning and ending amounts of unrecognized tax benefits and related interest expense is as follows:

[0001783180-22-000010:notes:230]
| (In millions) | 2021 |  | 2020 |  | 2019 |
| Balance at beginning of period | $ | 162 |  |  | $ | 166 |  |  | $ | 316 |  |
| Additions for tax positions related to the current year | 86 |  |  | 22 |  |  | 30 |  |
| Additions for tax positions of prior years (1) | 24 |  |  | 14 |  |  | 14 |  |
| Reductions for tax positions of prior years (2) | (1) |  |  | (40) |  |  | (19) |  |
| Settlements | (18) |  |  | — |  |  | (175) |  |
| Reclassified as held for sale | (2) |  |  | — |  |  | — |  |
| Balance at end of period | $ | 251 |  |  | $ | 162 |  |  | $ | 166 |  |
| Gross interest expense related to unrecognized tax benefits | $ | 8 |  |  | $ | 6 |  |  | $ | 8 |  |
| Total accrued interest balance at end of period | $ | 35 |  |  | $ | 25 |  |  | $ | 25 |  |

[0001783180-22-000010:notes:231]
(1) Includes $14 million related to acquisitions during the year ended December 31, 2021.

[0001783180-22-000010:notes:232]
(2) Includes an adjustment of $37 million recorded in UTC Net investment for the year ended December 31, 2020 for tax positions of prior years.

[0001783180-22-000010:notes:233]
The Company conducts business globally and, as a result, the Company and its subsidiaries file income tax returns in the U.S. federal, various state and foreign jurisdictions. In certain jurisdictions, the Company's operations were included in UTC's combined tax returns for the periods through the Separation and the Distribution. The IRS commenced an audit of UTC's tax years 2017 and 2018 in the second quarter of 2020. In the normal course of business, the Company is subject to examination by taxing authorities throughout the world, including the U.S., Australia, Belgium, Canada, China, Czech Republic, France, Germany, Hong Kong, India, Italy, Mexico, the Netherlands, Singapore and the United Kingdom. The Company is no longer subject to U.S. federal income tax examination for years prior to 2017 and, with few exceptions, is no longer subject to U.S. state and local and foreign income tax examinations for tax years before 2012.

[0001783180-22-000010:notes:234]
During the second quarter of 2019, a subsidiary of the Company that was engaged in litigation before the Italian Supreme Court filed to participate in the Italian amnesty program. In addition, during the second quarter of 2019, the IRS completed its review of UTC’s 2014, 2015 and 2016 tax years and certain U.S. state income tax exams concluded. As a result of the amnesty filing in Italy and the conclusion of the IRS and U.S. state audits, the Company recognized a non-cash gain of approximately $166 million, including pre-tax interest of approximately $16 million.

[0001783180-22-000010:notes:235]
In the ordinary course of business, there is inherent uncertainty in quantifying the Company's income tax positions. The Company assesses its income tax positions and records tax benefits for all years subject to examination based upon management’s evaluation of the facts, circumstances and information available at the reporting date. It is reasonably possible that a net decrease in unrecognized tax benefits from $10 million to $65 million may occur within 12 months as a result of additional worldwide uncertain tax positions, the revaluation of uncertain tax positions arising from examinations, appeals, court decisions or the closure of tax statutes.

[0001783180-22-000010:notes:236]
As a result of the Tax Cuts and Jobs Act ("TCJA"), the Company no longer intends to reinvest certain undistributed earnings of its international subsidiaries that have been previously taxed in the U.S. As such, the Company has recorded the taxes associated with the future remittance of these earnings. In addition, the Company no longer intends to permanently reinvest the book and tax basis difference including the undistributed earnings of the Company's Chubb business due to its divestiture. For the remainder of the Company's undistributed international earnings, unless tax effective to repatriate, the Company intends to continue to permanently reinvest these earnings. As of December 31, 2021 such undistributed earnings were approximately $6.0 billion, excluding other comprehensive income amounts. It is not practicable to estimate the amount of tax that might be payable on the remaining amounts. In addition, the TCJA subjects the Company to a tax on global intangible low-taxed income ("GILTI"). GILTI is a tax on foreign income in excess of a deemed return on tangible assets of foreign corporations which the Company has elected to account for as a period cost.


## us-gaap:EarningsPerShareTextBlock

[0001783180-22-000010:notes:237]
EARNINGS PER SHARE 
Earnings per share is computed by dividing Net income attributable to common shareowners by the weighted-average number of shares of common stock outstanding during the period (excluding treasury stock). Diluted earnings per share is computed by giving effect to all potentially dilutive stock awards that are outstanding. The computation of diluted earnings per share excludes the effect of the potential exercise of stock-based awards, including stock appreciation rights and stock options, when the effect of the potential exercise would be anti-dilutive.

[0001783180-22-000010:notes:238]
| (In millions, except per share amounts) |  | 2021 |  | 2020 |  | 2019 |  |
| Net income attributable to common shareowners |  | $ | 1,664 |  |  | $ | 1,982 |  |  | $ | 2,116 |  |  |
| Basic weighted-average number of shares outstanding |  | 867.7 |  |  | 866.5 |  |  | 866.2 |  |  |
| Stock awards and equity units (share equivalent) |  | 22.6 |  |  | 13.7 |  |  | — |  |  |
| Diluted weighted-average number of shares outstanding |  | 890.3 |  |  | 880.2 |  |  | 866.2 |  |  |
| Antidilutive shares excluded from computation of diluted earnings per share |  | 0.1 |  |  | 0.2 |  | (1) | — |  |  |
| Earnings Per Share |  |  |  |  |  |  |  |
| Basic |  | $ | 1.92 |  |  | $ | 2.29 |  |  | $ | 2.44 |  |  |
| Diluted |  | $ | 1.87 |  |  | $ | 2.25 |  |  | $ | 2.44 |  |  |

[0001783180-22-000010:notes:239]
(1) The weighted-average number of common shares outstanding for basic and diluted earnings per share for the year ended December 31, 2020 was based on the weighted-average number of common shares outstanding for the period beginning after the Distribution Date.
On the Distribution Date, 866,158,910 shares of the Company’s common stock, par value $0.01 per share, were distributed to UTC shareowners of record as of March 19, 2020. This share amount is utilized for the calculation of basic and diluted earnings per share for all periods presented prior to the Separation and the Distribution and such shares are treated as issued and outstanding for purposes of calculating historical earnings per share. It is assumed that there are no dilutive equity instruments for periods prior to the Separation and Distribution because there were no Carrier stock-based awards outstanding prior to the Separation and the Distribution.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001783180-22-000010:notes:240]
ACQUISITIONS
During the year ended December 31, 2021, the Company acquired consolidated and minority-owned businesses. The aggregate cash paid, net of cash acquired, totaled $366 million and was funded through cash on hand. Acquisitions are recorded using the acquisition method of accounting in accordance with ASC 805, Business Combinations ("ASC 805"). As a result, the aggregate purchase price has been allocated to assets acquired and liabilities assumed based on the estimate of fair market value of such assets and liabilities at the date of acquisition. Intangible assets associated with these transactions totaled $146 million and primarily related to customer relationships, technology assets and a non-compete agreement. The excess purchase price over the estimated fair value of net assets acquired was recognized as goodwill and totaled $320 million.

[0001783180-22-000010:notes:241]
Acquisition of Guangdong Giwee Group Co.

[0001783180-22-000010:notes:242]
On June 1, 2021, the Company acquired a 70% controlling stake in Guangdong Giwee Group Co. and its subsidiaries ("Giwee") and subsequently acquired the remaining 30% ownership in Giwee on September 7, 2021. Giwee is a China-based manufacturer offering a portfolio of HVAC products including variable refrigerant flow, modular chillers and light commercial air conditioners. The results of Giwee are reported within the HVAC segment as of the date of acquisition. The Company has not included pro forma financial information required under ASC 805 as the pro forma impact was not deemed significant.

[0001783180-22-000010:notes:243]
The excess of the purchase price over the estimated fair value of the net assets acquired was recognized as goodwill and totaled $182 million, which is not deductible for tax purposes. Accounts receivable and current liabilities were stated at their historical carrying value, which approximates fair value given the short-term nature of these assets and liabilities. The estimate of fair value for inventory and property, plant and equipment was based on an assessment of the acquired assets' condition as well as an evaluation of the current market value of such assets.

[0001783180-22-000010:notes:244]
The Company recorded intangible assets which consisted of the following:

[0001783180-22-000010:notes:245]
| (In millions) | Estimated Useful Life (in years) |  | Intangible Assets Acquired |
| Customer relationships | 14 |  | $ | 52 |  |
| Technology | 10 |  | 34 |  |
| Non-compete agreement | 5 |  | 8 |  |
| Total intangible assets acquired |  |  | $ | 94 |  |

[0001783180-22-000010:notes:246]
The valuation of intangible assets was determined using an income approach methodology including the multi-period excess earnings method and the relief from royalty method. Key assumptions used in estimating future cash flows included projected revenue growth rates, customer attrition rates and royalty rates. The projected future cash flows are discounted to present value using an appropriate discount rate. As of December 31, 2021, the Company has finalized the process of allocating the purchase price and valuing the acquired assets and liabilities for the Giwee acquisition.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001783180-22-000010:notes:247]
DIVESTITURES
On July 26, 2021, the Company entered into a stock purchase agreement to sell its Chubb business to APi. Chubb, reported within the Company’s Fire & Security segment, delivers essential fire safety and security solutions from design and installation to monitoring, service and maintenance across more than 17 countries around the globe.

[0001783180-22-000010:notes:248]
The assets and liabilities of Chubb have been reclassified as held for sale in the accompanying Consolidated Balance Sheet as of December 31, 2021 and recorded at the lower of their carrying value or fair value less estimated cost to sell. In addition, depreciation and amortization was ceased in accordance with ASC 360. Based on the carrying amount of Chubb’s net assets, foreign currency translation rates and other assumptions as of December 31, 2021, the Company expects to recover the carrying value of the disposal group upon completion of the transaction.

[0001783180-22-000010:notes:249]
The components of Chubb's assets and liabilities recorded as held for sale were as follows:

[0001783180-22-000010:notes:250]
| (In millions) |  | 2021 |
| Cash and cash equivalents |  | $ | 60 |  |
| Accounts receivable, net |  | 445 |  |
| Inventories, net |  | 73 |  |
| Contract assets, current |  | 184 |  |
| Other assets, current |  | 27 |  |
| Fixed assets, net |  | 67 |  |
| Intangible assets, net |  | 545 |  |
| Goodwill |  | 940 |  |
| Operating lease right-of-use assets |  | 193 |  |
| Pension and post-retirement assets |  | 614 |  |
| Other assets |  | 20 |  |
| Total assets held for sale |  | $ | 3,168 |  |
| Accounts payable |  | $ | (190) |  |
| Accrued liabilities |  | (248) |  |
| Contract liabilities, current |  | (162) |  |
| Future pension and post-retirement obligations |  | (69) |  |
| Future income tax obligations |  | (273) |  |
| Operating lease liabilities |  | (175) |  |
| Other long-term liabilities |  | (17) |  |
| Total liabilities held for sale |  | $ | (1,134) |  |

[0001783180-22-000010:notes:251]
On January 3, 2022, the Company completed the sale of Chubb for an enterprise value of $3.1 billion, subject to working capital and other adjustments as provided in the Chubb Sale Agreement. Consistent with the Company's capital allocation strategy, the net proceeds of approximately $2.6 billion will be used to fund investments in organic and inorganic growth initiatives and capital returns to its shareowners as well as for general corporate purposes.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001783180-22-000010:notes:252]
SEGMENT FINANCIAL DATA 
The Company conducts its operations through three reportable operating segments: HVAC, Refrigeration and Fire & Security. In accordance with ASC 280 - Segment Reporting, the Company’s segments maintain separate financial information for which results of operations are evaluated on a regular basis by the Company’s CODM in deciding how to allocate resources and in assessing performance. Inter-company sales between segments are immaterial.

[0001783180-22-000010:notes:253]
•The HVAC segment provides products, controls, services and solutions to meet the heating, cooling and ventilation needs of residential and commercial customers while enhancing building performance, health, energy efficiency and sustainability. Products include air conditioners, heating systems, controls and aftermarket components as well as aftermarket repair and maintenance services and building automation solutions. Products and solutions are sold directly to building contractors and owners and indirectly through joint ventures, independent sales representatives, distributors, wholesalers, dealers and retail outlets.

[0001783180-22-000010:notes:254]
•The Refrigeration segment provides a healthier, safer, more sustainable and more intelligent cold chain through the reliable transport and preservation of food, medicine and other perishable cargo. Refrigeration and monitoring products services and digital solutions strengthen the connected cold chain and are designed for trucks, trailers, shipping containers, intermodal applications, food retail and warehouse monitoring. Commercial refrigeration solutions include refrigerated cabinets, freezers, systems and controls incorporating next-generation technologies to preserve freshness, ensure safety and enhance the appearance of retail food and beverage. Products and services are sold directly to transportation companies and retail stores and indirectly through joint ventures, independent sales representatives, distributors, wholesalers and dealers.

[0001783180-22-000010:notes:255]
•The Fire & Security segment provides a wide range of residential, commercial and industrial technologies designed to help protect people and property. Products include fire, flame, gas, smoke and carbon monoxide detection, portable fire extinguishers, fire suppression systems, intruder alarms, access control systems and video management systems and electronic controls. Other fire and security offerings include audit, design, installation and system integration as well as aftermarket maintenance and repair and monitoring services. Products and solutions are sold directly to end customers as well as through manufacturers' representatives, distributors, dealers, value-added resellers and retail distribution.

[0001783180-22-000010:notes:256]
Segment information are as follows:

[0001783180-22-000010:notes:257]
|  | Net Sales |  | Operating Profit |
| (In millions) | 2021 |  | 2020 |  | 2019 |  | 2021 |  | 2020 |  | 2019 |
| HVAC | $ | 11,390 |  |  | $ | 9,478 |  |  | $ | 9,712 |  |  | $ | 1,738 |  |  | $ | 2,462 |  |  | $ | 1,563 |  |
| Refrigeration | 4,127 |  |  | 3,333 |  |  | 3,792 |  |  | 476 |  |  | 357 |  |  | 532 |  |
| Fire & Security | 5,515 |  |  | 4,985 |  |  | 5,500 |  |  | 662 |  |  | 584 |  |  | 708 |  |
| Total segment | 21,032 |  |  | 17,796 |  |  | 19,004 |  |  | 2,876 |  |  | 3,403 |  |  | 2,803 |  |
| Eliminations and other | (419) |  |  | (340) |  |  | (396) |  |  | (96) |  |  | (184) |  |  | (156) |  |
| General corporate expenses | — |  |  | — |  |  | — |  |  | (135) |  |  | (136) |  |  | (156) |  |
| Consolidated | $ | 20,613 |  |  | $ | 17,456 |  |  | $ | 18,608 |  |  | $ | 2,645 |  |  | $ | 3,083 |  |  | $ | 2,491 |  |

[0001783180-22-000010:notes:258]
Total assets are not presented for each segment as they are not presented to or reviewed by the CODM. Segment assets in the following table represent Accounts receivable, net , Contract assets, current and Inventories, net. These assets are regularly reviewed by management and are therefore reported in the following table as segment assets. All other remaining assets and liabilities for all periods presented are managed on a company-wide basis.

[0001783180-22-000010:notes:259]
|  | Segment Assets |  | Capital Expenditures |  | Depreciation & Amortization |
| (In millions) | 2021 |  | 2020 |  |  |  | 2021 |  | 2020 |  | 2019 |  | 2021 |  | 2020 |  | 2019 |
| HVAC | $ | 2,375 |  |  | $ | 2,150 |  |  |  |  | $ | 225 |  |  | $ | 188 |  |  | $ | 150 |  |  | $ | 186 |  |  | $ | 163 |  |  | $ | 160 |  |
| Refrigeration | 1,285 |  |  | 1,125 |  |  |  |  | 39 |  |  | 26 |  |  | 30 |  |  | 36 |  |  | 39 |  |  | 34 |  |
| Fire & Security | 1,203 |  |  | 1,788 |  |  |  |  | 49 |  |  | 51 |  |  | 50 |  |  | 83 |  |  | 108 |  |  | 123 |  |
| Total Segment | 4,863 |  |  | 5,063 |  |  |  |  | 313 |  |  | 265 |  |  | 230 |  |  | 305 |  |  | 310 |  |  | 317 |  |
| Eliminations and other | 13 |  |  | 3 |  |  |  |  | 31 |  |  | 47 |  |  | 13 |  |  | 33 |  |  | 26 |  |  | 18 |  |
| Consolidated | $ | 4,876 |  |  | $ | 5,066 |  |  |  |  | $ | 344 |  |  | $ | 312 |  |  | $ | 243 |  |  | $ | 338 |  |  | $ | 336 |  |  | $ | 335 |  |
| Cash and cash equivalents | 2,987 |  |  | 3,115 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other assets, current | 376 |  |  | 343 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets held for sale | 3,168 |  |  | — |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total current assets | $ | 11,407 |  |  | $ | 8,524 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0001783180-22-000010:notes:260]
Geographic External Sales

[0001783180-22-000010:notes:261]
Geographic external sales and operating profits are attributed to the geographic regions based on their location of origin. With the exception of the U.S. as presented in the following table, there were no individually significant countries with sales exceeding 10% of total sales for the years ended December 31, 2021, 2020 and 2019.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001783180-22-000010:notes:262]
RELATED PARTIES 
Equity Method Investments

[0001783180-22-000010:notes:263]
The Company sells products to and purchases products from unconsolidated entities accounted for under the equity method, and therefore, these entities are considered to be related parties. The Company has 30 directly owned unconsolidated domestic and foreign affiliates as of December 31, 2021 and 2020, respectively, of which 99% of such investments are in its HVAC segment. Amounts attributable to equity method investees are as follows:

[0001783180-22-000010:notes:264]
| (In millions) | 2021 |  | 2020 |  | 2019 |
| Sales to equity method investees included in Product sales | $ | 2,258 |  |  | $ | 1,758 |  |  | $ | 1,807 |  |
| Purchases from equity method investees included in Cost of products sold | $ | 357 |  |  | $ | 292 |  |  | $ | 368 |  |

[0001783180-22-000010:notes:265]
The Company had receivables from and payables to equity method investees as follows:

[0001783180-22-000010:notes:266]
| (In millions) | 2021 |  | 2020 |
| Receivables from equity method investees included in Accounts receivable, net | $ | 150 |  |  | $ | 161 |  |
| Payables to equity method investees included in Accounts payable | $ | 51 |  |  | $ | 38 |  |

[0001783180-22-000010:notes:267]
The Company periodically reviews the carrying value of its equity method investments to determine if there has been an other-than-temporary decline in fair value. In 2020, the Company determined that indicators of impairment existed for a minority owned joint venture investment and performed a valuation of this investment using a discounted cash flow method. The Company determined that the loss in value was other-than-temporary due to a reduction in sales and earnings that were primarily driven by a deterioration in the oil and gas industry (the joint venture's primary market) and by the impact of the COVID-19 pandemic. As a result, the Company recorded a non-cash, other-than-temporary impairment charge of $71 million on this investment in 2020, which is included in Other income (expense), net on the accompanying Consolidated Statement of Operations. In 2019, the Company determined that indicators of impairment existed for a minority owned joint venture investment and performed a valuation of this investment using a discounted cash flow method. The Company determined that the loss in value was other-than-temporary. As a result, the Company recorded a non-cash, other-than-temporary impairment charge of $108 million on this investment in 2019, which is included in Other income (expense), net on the accompanying Consolidated Statement of Operations.

[0001783180-22-000010:notes:268]
In September 2020, the Company sold 9.25 million B shares of Beijer for SEK290 ($32.38) per share equal to approximately 7.9% of the outstanding B shares in Beijer, through an accelerated equity offering. The Company received proceeds of approximately $300 million and recognized a pre-tax gain on the sale of $252 million, which is included in Other income (expense), net on the Consolidated Statement of Operations. Subsequently, in December 2020, the Company sold all of its remaining A and B shares of Beijer for SEK245 ($29.03) per share. The Company received proceeds of approximately $1.1 billion and recognized a pre-tax gain on the sale of $871 million, which is included in Other income (expense), net on the Consolidated Statement of Operations. Prior to the sale of the Company's remaining shares, Beijer was reported as an equity method investment.

[0001783180-22-000010:notes:269]
Summarized Financial Information. Pursuant to Rule 3-10 and Rule 4-08(g) of Regulation S-X under the Securities Act, the Company is required to present summarized financial information of the combined accounts of its non-consolidated joint

[0001783180-22-000010:notes:270]
ventures accounted for by the equity method. Summarized unaudited financial information for equity method investments is as follows:

[0001783180-22-000010:notes:271]
| (In millions) | 2021 |  | 2020 |
| Current assets | $ | 4,275 |  |  | $ | 3,671 |  |
| Non-current assets | 2,140 |  |  | 2,035 |  |
| Total assets | 6,415 |  |  | 5,706 |  |
| Current liabilities | (2,596) |  |  | (2,223) |  |
| Non-current liabilities | (329) |  |  | (298) |  |
| Total liabilities | (2,925) |  |  | (2,521) |  |
| Total net equity of investees | $ | 3,490 |  |  | $ | 3,185 |  |

[0001783180-22-000010:notes:272]
| (In millions) | 2021 |  | 2020 |  | 2019 |
| Net sales | $ | 9,471 |  |  | $ | 9,299 |  |  | $ | 9,622 |  |
| Gross profit | $ | 1,907 |  |  | $ | 1,722 |  |  | $ | 1,741 |  |
| Income from continuing operations | $ | 650 |  |  | $ | 544 |  |  | $ | 578 |  |
| Net income | $ | 650 |  |  | $ | 544 |  |  | $ | 578 |  |


## us-gaap:EquityMethodInvestmentsTextBlock

[0001783180-22-000010:notes:273]
Amounts attributable to equity method investees are as follows:

[0001783180-22-000010:notes:274]
Summarized unaudited financial information for equity method investments is as follows:


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001783180-22-000010:notes:275]
COMMITMENTS AND CONTINGENT LIABILITIES
The Company is involved in various litigation, claims and administrative proceedings, including those related to environmental and legal matters (including asbestos). In accordance with ASC 450, the Company records accruals for loss contingencies when it is probable that a liability will be incurred and the amount of the loss can be reasonably estimated. These accruals are generally based upon a range of possible outcomes. If no amount within the range is a better estimate than any other, the Company accrues the minimum amount. In addition, these estimates are reviewed periodically and adjusted to reflect additional information when it becomes available. The Company is unable to predict the final outcome of the following matters based on the information currently available, except as otherwise noted. However, the Company does not believe that the resolution of any of these matters will have a material adverse effect upon the Company's competitive position, results of operations, cash flows or financial condition.

[0001783180-22-000010:notes:276]
Environmental Matters

[0001783180-22-000010:notes:277]
The Company’s operations are subject to environmental regulation by various authorities. The Company has accrued for the costs of environmental remediation activities, including but not limited to, investigatory, remediation, operating and maintenance costs and performance guarantees. The most likely cost to be incurred is accrued based on an evaluation of currently available facts with respect to individual sites, including the technology required to remediate, current laws and regulations and prior remediation experience.

[0001783180-22-000010:notes:278]
As of December 31, 2021 and 2020, the outstanding liability for environmental obligations are as follows:

[0001783180-22-000010:notes:279]
| (In millions) |  | 2021 |  | 2020 |
| Environmental reserves included in Accrued liabilities |  | $ | 29 |  |  | $ | 26 |  |
| Environmental reserves included in Other long-term liabilities |  | 191 |  |  | 213 |
| Total environmental reserves |  | $ | 220 |  |  | $ | 239 |  |

[0001783180-22-000010:notes:280]
For sites with multiple responsible parties, the Company considers its likely proportionate share of the anticipated remediation costs and the ability of other parties to fulfill their obligations in establishing a provision for those costs. Accrued environmental liabilities are not reduced by potential insurance reimbursements and are undiscounted.

[0001783180-22-000010:notes:281]
Asbestos Matters

[0001783180-22-000010:notes:282]
The Company has been named as a defendant in lawsuits alleging personal injury as a result of exposure to asbestos allegedly integrated into certain Carrier products or business premises. While the Company has never manufactured asbestos and no longer incorporates it into any currently-manufactured products, certain products that the Company no longer manufactures contained components incorporating asbestos. A substantial majority of these asbestos-related claims have been dismissed without payment or have been covered in full or in part by insurance or other forms of indemnity. Additional cases were litigated and settled without any insurance reimbursement. The amounts involved in asbestos-related claims were not material individually or in the aggregate in any period.

[0001783180-22-000010:notes:283]
The Company had asbestos liabilities and related insurance recoveries as follows:

[0001783180-22-000010:notes:284]
| (In millions) |  | 2021 |  | 2020 |
| Asbestos liabilities included in Accrued liabilities |  | $ | 17 |  |  | $ | 17 |  |
| Asbestos liabilities included in Other long-term liabilities |  | 220 |  |  | 228 |  |
| Total asbestos liabilities |  | $ | 237 |  |  | $ | 245 |  |
| Asbestos-related recoveries included in Other assets, current |  | $ | 5 |  |  | $ | 6 |  |
| Asbestos-related recoveries included in Other assets |  | 93 |  |  | 97 |  |
| Total asbestos-related recoveries |  | $ | 98 |  |  | $ | 103 |  |

[0001783180-22-000010:notes:285]
The amounts recorded for asbestos-related liabilities are based on currently available information and assumptions that the Company believes are reasonable and are made with input from outside actuarial experts. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are deemed probable. These amounts are undiscounted and exclude the Company’s legal fees to defend the asbestos claims, which are expensed as incurred. As of December 31, 2021, the estimated range of liability to resolve all pending and unasserted potential future asbestos claims through 2059 is approximately $237 million to $258 million.

[0001783180-22-000010:notes:286]
UTC Equity Awards Conversion Litigation

[0001783180-22-000010:notes:287]
On August 12, 2020, several former employees of UTC or its subsidiaries filed a putative class action complaint (the "Complaint") in the United States District Court for the District of Connecticut against RTX, Carrier, Otis, the former members of the UTC Board of Directors and the members of the Carrier and Otis Boards of Directors (Geraud Darnis, et al. v. Raytheon Technologies Corporation, et al.). The Complaint challenges the method by which UTC equity awards were converted to RTX, Carrier and Otis equity awards following the Separation and the Distribution. Defendants moved to dismiss the Complaint. Plaintiffs amended their Complaint on September 13, 2021 (the "Amended Complaint"). The Amended Complaint, now with RTX, Carrier and Otis as the only defendants, asserts that the defendants are liable for breach of certain equity compensation plans and for breach of the implied covenant of good faith and fair dealing. The Amended Complaint also seeks specific performance. Carrier believes that the claims against the Company are without merit. Defendants moved to dismiss the Amended Complaint on October 13, 2021.

[0001783180-22-000010:notes:288]
Aqueous Film Forming Foam Litigation

[0001783180-22-000010:notes:289]
As of December 31, 2021, the Company has been named as a defendant in over 1,800 lawsuits filed by individuals in or removed to the federal courts of the United States alleging that the historic use of AFFF caused personal injuries and/or property damage. The Company has also been named as a defendant in over 160 lawsuits filed by several U.S. states, municipalities and water utilities in or removed to U.S. federal courts alleging that the historic use of AFFF caused contamination of property and water supplies. In December 2018, the U.S. Judicial Panel on Multidistrict Litigation transferred and consolidated all AFFF cases pending in the U.S. federal courts against the Company and others to the MDL Court for MDL Proceedings. The individual plaintiffs in the MDL Proceedings generally seek damages for alleged personal injuries, medical

[0001783180-22-000010:notes:290]
monitoring and diminution in property value and injunctive relief to remediate alleged contamination of water supplies. The U.S. state, municipal and water utility plaintiffs in the MDL Proceedings generally seek damages and costs related to the remediation of public property and water supplies.

[0001783180-22-000010:notes:291]
AFFF is a firefighting foam, developed beginning in the late 1960s pursuant to U.S. military specification, used to extinguish certain types of hydrocarbon-fueled fires primarily at military bases and airports. AFFF was manufactured by several companies, including National Foam and Angus Fire. UTC first entered the AFFF business with the acquisition of National Foam and Angus Fire in 2005 as part of the acquisition of Kidde. In 2013, Kidde divested the National Foam and Angus Fire businesses to a third party. The Company acquired Kidde as part of its separation from UTC in April 2020. During the eight year period of its operation by Kidde, National Foam manufactured AFFF for sale to government (including the U.S. federal government) and non-government customers in the U.S. at a single facility located in West Chester, Pennsylvania ("Pennsylvania Site"). During the same period, Angus Fire manufactured AFFF for sale outside the United States at a single facility located in Bentham, England.

[0001783180-22-000010:notes:292]
The key components of AFFF that contribute to its fire-extinguishing capabilities are known as fluorosurfactants. National Foam and Angus Fire did not manufacture fluorosurfactants but instead purchased these substances from unrelated third parties. Plaintiffs in the MDL Proceedings allege that the fluorosurfactants used by various manufacturers in producing AFFF contained, or over time degraded into, compounds known as PFOS and/or PFOA. Plaintiffs further allege that, as a result of the use of AFFF, PFOS and PFOA were released into the environment and, in some instances, ultimately reached drinking water supplies.

[0001783180-22-000010:notes:293]
Plaintiffs in the MDL Proceedings allege that PFOS and PFOA contamination has resulted from the use of AFFF containing fluorosurfactants manufactured using a process known as ECF. They also allege that PFOA contamination has resulted from the use of AFFF containing fluorosurfactants manufactured using a different process, known as telomerization. Plaintiffs further allege that 3M was the only AFFF manufacturer that used fluorosurfactants relying on the ECF process and that all other foam manufacturers (including National Foam and Angus Fire) relied solely on fluorosurfactants produced via telomerization. Compounds containing PFOS and PFOA (as well as many other per- and polyfluoroalkyl substances known collectively as "PFAS") have also been used for decades by many third parties in a number of different industries to manufacture carpets, clothing, fabrics, cookware, food packaging, personal care products, cleaning products, paints, varnishes and other consumer and industrial products.

[0001783180-22-000010:notes:294]
Plaintiffs in the MDL Proceedings have named multiple defendants, including four suppliers of chemicals and raw materials used to manufacture fluorosurfactants, four fluorosurfactant manufacturers, two toll manufacturers of fluorosurfactants and seven current (including National Foam and Angus Fire) and former (including the Company) AFFF manufacturers.

[0001783180-22-000010:notes:295]
General liability discovery in the MDL Proceedings continues. Preliminary stage discovery in ten "bellwether" water provider cases was concluded and three of these cases were selected for tier two site-specific discovery. That discovery is ongoing. The MDL Court has established a briefing schedule with respect to certain aspects of the government contractor defense, potentially applicable to AFFF sold to or used by the U.S. government or other customers requiring product manufactured to meet military specification, such that all briefs were filed at the end of January 2022 with a hearing to follow.

[0001783180-22-000010:notes:296]
Outside of the MDL Proceedings, the Company and other defendants are also party to six lawsuits in U.S. state courts brought by oil refining companies alleging product liability claims related to legacy sales of AFFF and seeking damages for the costs to replace the product and for property damage. In addition, the Company and other defendants are party to two actions related to the Pennsylvania Site in which the plaintiff water utility company seeks remediation costs related to the alleged contamination of the local water supply.

[0001783180-22-000010:notes:297]
The Company believes that it has meritorious defenses to the claims in the MDL Proceedings and the other AFFF lawsuits. Based on the 2013 agreement for the sale of National Foam and Angus Fire, the Company is pursuing indemnification against these claims from the purchaser and current owner of National Foam and Angus Fire. The Company is also pursuing insurance coverage for these claims. At this time, however, given the numerous factual, scientific and legal issues to be resolved relating to these claims, the Company is unable to assess the probability of liability or to reasonably estimate the damages, if any, to be allocated to the Company, if one or more plaintiffs were to prevail in these cases, and there can be no assurance that any such future exposure will not be material in any period.

[0001783180-22-000010:notes:298]
Income Taxes

[0001783180-22-000010:notes:299]
Under the TMA, the Company is responsible to UTC for its share of the TCJA transition tax associated with foreign undistributed earnings as of December 31, 2017. As a result, a liability of $417 million is included within the accompanying Consolidated Balance Sheet within Other Long-Term Liabilities as of December 31, 2021. This obligation is expected to be settled in annual installments ending in April 2026 with the next installment of $34 million due in 2023. The Company believes that the likelihood of incurring losses materially in excess of this amount is remote.

[0001783180-22-000010:notes:300]
Self-Insurance

[0001783180-22-000010:notes:301]
The Company maintains self-insurance for a number of risks, including but not limited to, workers’ compensation, general liability, automobile liability, property and employee-related healthcare benefits. It has obtained insurance coverage for amounts exceeding individual and aggregate loss limits. The Company accrues for known future claims and incurred but not reported losses.

[0001783180-22-000010:notes:302]
The Company's self-insurance liabilities were as follows:

[0001783180-22-000010:notes:303]
| (In millions) | 2021 |  | 2020 |
| Self-insurance liabilities included in Accrued liabilities | $ | 154 |  |  | $ | 164 |  |
| Self-insurance liabilities included in Other long-term liabilities | 72 |  |  | 85 |
| Total self-insurance liabilities | $ | 226 |  |  | $ | 249 |  |

[0001783180-22-000010:notes:304]
The Company incurred expenses related to self-insured risks of $155 million, $145 million and $177 million for the years ended December 31, 2021, 2020 and 2019, respectively.

[0001783180-22-000010:notes:305]
Other Matters

[0001783180-22-000010:notes:306]
The Company has other commitments and contingent liabilities related to legal proceedings, self-insurance programs and matters arising in the ordinary course of business. The Company accrues for contingencies generally based upon a range of possible outcomes. If no amount within the range is a better estimate than any other, the Company accrues the minimum amount.

[0001783180-22-000010:notes:307]
In the ordinary course of business, the Company is also routinely a defendant in, party to or otherwise subject to many pending and threatened legal actions, claims, disputes and proceedings. These matters are often based on alleged violations of contract, product liability, warranty, regulatory, environmental, health and safety, employment, intellectual property, tax and other laws. In some of these proceedings, claims for substantial monetary damages are asserted against the Company and could result in fines, penalties, compensatory or treble damages or non-monetary relief. The Company does not believe that these matters will have a material adverse effect upon its competitive position, results of operations, cash flows or financial condition.


## us-gaap:CashFlowSupplementalDisclosuresTextBlock

[0001783180-22-000010:notes:308]
SUPPLEMENTAL CASH FLOW INFORMATION 
Supplemental cash flow information was as follows:

[0001783180-22-000010:notes:309]
| (In millions) | 2021 |  | 2020 |  | 2019 |
| Interest paid, net of amounts capitalized | $ | 317 |  |  | $ | 196 |  |  | $ | 28 |  |
| Interest paid - related party | $ | — |  |  | $ | — |  |  | $ | 55 |  |
| Income taxes paid for - related party | $ | — |  |  | $ | — |  |  | $ | 475 |  |
| Income taxes paid, net of refunds | $ | 675 |  |  | $ | 819 |  |  | $ | 284 |  |
| Non-cash financing activity: |  |  |  |  |  |
| Common stock dividends payable | $ | 130 |  |  | $ | 108 |  |  | $ | — |  |


## us-gaap:SubsequentEventsTextBlock

[0001783180-22-000010:notes:310]
SUBSEQUENT EVENTS 
Share Repurchase Program

[0001783180-22-000010:notes:311]
On January 4, 2022, the Company announced that it has entered into an accelerated share repurchase agreement to repurchase $500 million of the Company's common stock pursuant to the Company's existing share repurchase program. The final settlement of the accelerated share repurchase is expected to be completed in the first quarter of 2022.

[0001783180-22-000010:notes:312]
Toshiba Carrier Corporation Acquisition Agreement

[0001783180-22-000010:notes:313]
On February 6, 2022, the Company entered into a binding agreement to acquire a majority ownership stake in Toshiba Carrier Corporation (“TCC”) for approximately $900 million. TCC, a variable refrigerant flow ("VRF") and light commercial HVAC joint venture between Carrier and Toshiba Corporation, designs and manufactures flexible, energy-efficient and high-performance VRF and light commercial HVAC systems as well as commercial products, compressors and heat pumps. The acquisition will include all of TCC’s advanced research and development centers and global manufacturing operations, product pipeline and the long-term use of Toshiba’s iconic brand. The transaction is expected to close before the end of the third quarter of 2022, subject to customary closing conditions, including regulatory approvals. Upon closing, Toshiba Corporation will retain a 5% ownership in TCC.
