# CARR 8-K — 0001783180-22-000008 filed 2022-02-08

## item codes, every 8-K on or before 2022-02-08

- 2022-02-08 0001783180-22-000008 — 2.02, 9.01
- 2022-02-07 0000950142-22-000510 — 8.01, 9.01
- 2022-01-03 0000950142-22-000023 — 8.01, 9.01
- 2021-12-17 0001783180-21-000071 — 5.02, 7.01, 9.01
- 2021-11-23 0001783180-21-000068 — 5.03, 9.01
- 2021-10-28 0001783180-21-000062 — 2.02, 9.01
- 2021-08-27 0001783180-21-000056 — 8.01
- 2021-07-30 0001783180-21-000053 — 1.01
- 2021-07-29 0001783180-21-000049 — 2.02, 8.01, 9.01
- 2021-07-27 0000950142-21-002448 — 8.01, 9.01
- 2021-07-15 0000950142-21-002362 — 5.02, 9.01
- 2021-06-09 0000950142-21-001885 — 5.02, 9.01
- 2021-04-29 0001783180-21-000029 — 2.02, 9.01
- 2021-04-22 0001140361-21-013889 — 5.02, 9.01
- 2021-04-20 0001783180-21-000021 — 5.07, 9.01
- 2021-04-19 0000950142-21-001308 — 8.01, 9.01
- 2021-02-09 0001783180-21-000009 — 2.02, 9.01
- 2021-02-05 0001140361-21-003513 — 8.01, 9.01
- 2020-12-23 0001140361-20-029419 — 7.01, 9.01
- 2020-12-22 0001140361-20-029097 — 8.01
- 2020-12-14 0001140361-20-028246 — 5.03, 9.01
- 2020-12-07 0001140361-20-027515 — 1.01, 7.01, 9.01
- 2020-10-29 0001783180-20-000063 — 2.02, 9.01
- 2020-10-19 0001140361-20-023241 — 5.02, 7.01, 9.01
- 2020-09-23 0001140361-20-021220 — 8.01, 9.01
- 2020-09-22 0001140361-20-021124 — 8.01, 9.01
- 2020-07-30 0001783180-20-000045 — 2.02, 9.01
- 2020-06-19 0001140361-20-014325 — 1.01, 2.03, 9.01
- 2020-06-16 0001140361-20-013880 — 8.01, 9.01
- 2020-06-03 0001140361-20-012939 — 1.01, 9.01
- 2020-05-08 0001783180-20-000013 — 2.02, 9.01
- 2020-04-03 0001140361-20-007888 — 1.01, 5.02, 5.03, 5.05, 7.01, 9.01
- 2020-03-16 0001140361-20-005868 — 8.01, 9.01

## late-filing notifications on or before 2022-02-08

- none on or before 2022-02-08

## item 2.02 — earnings release, exhibit 99.1

[0001783180-22-000008:8k_2_02:1]
EX-99
2
a8-kerexhibit99xq42021.htm
EX-99

[0001783180-22-000008:8k_2_02:2]
Document

[0001783180-22-000008:8k_2_02:3]
Exhibit 99

[0001783180-22-000008:8k_2_02:4]
Carrier Reports 2021 Results and Announces 2022 Outlook

[0001783180-22-000008:8k_2_02:5]
Fourth Quarter 2021 Highlights

[0001783180-22-000008:8k_2_02:6]
•Sales of $5.1 billion, up 12% compared to 2020 including 11% organic growth

[0001783180-22-000008:8k_2_02:7]
•GAAP EPS of $0.36 and adjusted EPS of $0.44

[0001783180-22-000008:8k_2_02:8]
•Net cash flow from operating activities of $913 million and free cash flow of $775 million

[0001783180-22-000008:8k_2_02:9]
Full Year 2021 Highlights

[0001783180-22-000008:8k_2_02:10]
•Sales growth of 18% and organic sales growth of 15%

[0001783180-22-000008:8k_2_02:11]
•GAAP EPS of $1.87 and adjusted EPS of $2.26; adjusted EPS growth of 36%

[0001783180-22-000008:8k_2_02:12]
•Net cash flow from operating activities of $2.2 billion and free cash flow of $1.9 billion or 114% of net income

[0001783180-22-000008:8k_2_02:13]
Outlook for 2022

[0001783180-22-000008:8k_2_02:14]
•Sales of about $20 billion with high single-digit organic sales* growth

[0001783180-22-000008:8k_2_02:15]
•Adjusted operating margin* up ~75 bps

[0001783180-22-000008:8k_2_02:16]
•Adjusted EPS* of $2.20 - $2.30, up double-digits adjusting for the Chubb divestiture

[0001783180-22-000008:8k_2_02:17]
•Free cash flow* of ~$1.65 billion, which includes a ~$200 million tax payment related to the gain on the Chubb sale

[0001783180-22-000008:8k_2_02:18]
•Outlook excludes recently announced Toshiba acquisition, expected to close before the end of Q3 2022

[0001783180-22-000008:8k_2_02:19]
PALM BEACH GARDENS, Fla., February 8, 2022 – Carrier Global Corporation (NYSE:CARR), the leading global provider of healthy, safe, sustainable and intelligent building and cold chain solutions, today reported strong financial results for the fourth quarter capping a full year 2021 that exceeded expectations.  The Company projects solid organic growth and adjusted operating margin expansion in 2022 and is well-positioned with a strong balance sheet with significant capital to deploy towards continued value creation.

[0001783180-22-000008:8k_2_02:20]
“Our fourth quarter results, including double-digit sales and adjusted net income growth, as well as adjusted operating margin expansion, served as a great conclusion to a year marked by strong execution and innovation. I am very pleased with the strategic progress we

[0001783180-22-000008:8k_2_02:21]
1

[0001783180-22-000008:8k_2_02:22]
made in 2021, including the launches of our global digital platforms for buildings and cold chain solutions, Abound and Lynx,” said Carrier Chairman & CEO Dave Gitlin. “We will work to build on our strong momentum as we enter 2022 with record backlog levels. We are pleased with the divestiture of Chubb and the pending acquisition of Toshiba Carrier Corporation and we will work to proactively improve our portfolio. We anticipate another year of strong financial results, execution and innovation as we continue to address some of the world’s most important challenges.”

[0001783180-22-000008:8k_2_02:23]
Fourth Quarter 2021 Results

[0001783180-22-000008:8k_2_02:24]
Carrier’s fourth quarter sales of $5.1 billion were up 12% compared to the prior year and organic sales were up 11% over the same period, reflecting continued order momentum. Sales remained strong in the HVAC segment with residential and light commercial performance driving the 14% organic growth.  Organic sales growth of 17% for the Refrigeration segment was due to strong Transport refrigeration growth.  Fire and Security sales were up 3% organically resulting from continued growth in commercial and industrial fire but were negatively impacted by supply chain constraints.

[0001783180-22-000008:8k_2_02:25]
GAAP operating profit in the quarter of $463 million decreased 63% from the fourth quarter of 2020 which included an $871 million gain on the sale of Beijer shares held as an investment. Adjusted operating profit of $517 million increased 14% on higher volume and price realization offset by increased supply chain costs.

[0001783180-22-000008:8k_2_02:26]
Net income and adjusted net income were $324 million and $389 million, respectively. GAAP EPS of $0.36 and adjusted EPS of $0.44 benefitted from a lower adjusted effective tax rate, resulting in a ~$0.06 benefit relative to October guidance and ~$0.07 on a year-over-year basis. Net cash flows provided by operating activities were $913 million and capital expenditures were $138 million, resulting in free cash flow of $775 million.

[0001783180-22-000008:8k_2_02:27]
Full-Year 2021 Results

[0001783180-22-000008:8k_2_02:28]
Carrier’s 2021 sales of $20.6 billion increased 18% compared to the prior year and 15% organically, reflecting strong demand across the businesses – primarily HVAC and Transport Refrigeration – and the results of execution on strategic initiatives. GAAP operating profit of

[0001783180-22-000008:8k_2_02:29]
2

[0001783180-22-000008:8k_2_02:30]
$2.6 billion decreased 14% and adjusted operating profit increased 26% to $2.8 billion.  Adjusted operating profit growth was strong despite the unprecedented supply chain environment. Productivity savings and strategic price increases partly offset the supply chain environment and incremental investments. GAAP operating profit comparisons were also negatively impacted by the 2020 gain on the sale of the Beijer shares.

[0001783180-22-000008:8k_2_02:31]
GAAP EPS was $1.87 and adjusted EPS was $2.26.  Net income was $1.7 billion, and adjusted net income was $2.0 billion.  Net cash flows provided by operating activities were $2.2 billion and capital expenditures were $344 million, resulting in free cash flow of $1.9 billion. 2021 capital deployment included over $360 million in acquisitions, $417 million in dividend payments, the repurchase of $527 million worth of common stock and the repayment of $500 million of long-term debt.

[0001783180-22-000008:8k_2_02:32]
Full-Year 2022 Guidance

[0001783180-22-000008:8k_2_02:33]
Carrier is announcing the following outlook for 2022 excluding the pending Toshiba acquisition:

[0001783180-22-000008:8k_2_02:34]
|  |  |  |  | 2022 Guidance**(excluding impact of TCC acquisition) |
|  |  |  |  | ~$20B |
| Sales |  |  |  | Organic* up HSD |
|  |  |  |  | FX ~(1%) |
|  |  |  |  | Acquisitions ~1% |
|  |  |  |  | Divestitures ~(10%) |
| Adjusted Operating Margin * |  |  |  | Up ~75 bps Y/Y |
| Adjusted EPS * |  |  |  | $2.20 - $2.30 |
| Free Cash Flow * |  |  |  | ~$1.65B |
|  |  |  |  | Includes ~$200M in tax payments on Chubb gain |

[0001783180-22-000008:8k_2_02:35]
*Note: When the company provides expectations for organic sales, adjusted operating profit, adjusted operating margin, adjusted EPS and free cash flow on a forward-looking basis, a reconciliation of the differences between the non-GAAP expectations and the corresponding GAAP measures generally is not available without unreasonable effort. See “Use and Definitions of Non-GAAP Financial Measures” below for additional information.

[0001783180-22-000008:8k_2_02:36]
**As of February 8, 2022

[0001783180-22-000008:8k_2_02:37]
3

[0001783180-22-000008:8k_2_02:38]
Conference Call

[0001783180-22-000008:8k_2_02:39]
Carrier will host a webcast of its earnings conference call today, Tuesday, February 8, 2022, at 8:30 a.m. ET. To access the webcast, visit the Events & Presentations section of the Carrier Investor Relations site at ir.carrier.com/news-and-events/events-and-presentations or to listen to the earnings call by phone, dial (877) 742-9091.

[0001783180-22-000008:8k_2_02:40]
About Carrier

[0001783180-22-000008:8k_2_02:41]
As the leading global provider of healthy, safe, sustainable and intelligent building and cold chain solutions, Carrier Global Corporation is committed to making the world safer, sustainable and more comfortable for generations to come. From the beginning, we've led in inventing new technologies and entirely new industries. Today, we continue to lead because we have a world-class, diverse workforce that puts the customer at the center of everything we do.  For more information, visit www.corporate.carrier.com or follow Carrier on social media at @Carrier.

[0001783180-22-000008:8k_2_02:42]
Cautionary Statement

[0001783180-22-000008:8k_2_02:43]
This communication contains statements which, to the extent they are not statements of historical or present fact, constitute "forward-looking statements" under the securities laws. These forward-looking statements are intended to provide management's current expectations or plans for Carrier's future operating and financial performance, based on assumptions currently believed to be valid. Forward-looking statements can be identified by the use of words such as "believe," "expect," "expectations," "plans," "strategy," "prospects," "estimate," "project," "target," "anticipate," "will," "should," "see," "guidance," "outlook," "confident," "scenario" and other words of similar meaning in connection with a discussion of future operating or financial performance or the separation from United Technologies Corporation (the "Separation"), since renamed Raytheon Technologies Corporation. Forward-looking statements may include, among other things, statements relating to future sales, earnings, cash flow, results of operations, uses of cash, share repurchases, tax rates and other measures of financial performance or potential future plans, strategies or transactions of Carrier, the estimated costs associated with the Separation, Carrier's plans with respect to its indebtedness and other statements that are not historical facts. All forward-looking statements involve risks, uncertainties and other factors that may cause actual results to differ materially from those expressed or implied in the forward-looking statements. For additional information on identifying factors that may cause actual results to vary materially from those stated in forward-looking statements, see Carrier's reports on Forms 10-K, 10-Q and 8-K filed with or furnished to the U.S. Securities and Exchange Commission from time to time. Any forward-looking statement speaks only as of the date on which it is made, and Carrier assumes no obligation to update or revise such statement, whether as a result of new information, future events or otherwise, except as required by applicable law.

[0001783180-22-000008:8k_2_02:44]
4

[0001783180-22-000008:8k_2_02:45]
Contact:    Media Inquiries

[0001783180-22-000008:8k_2_02:46]
Danielle Canzanella

[0001783180-22-000008:8k_2_02:47]
561-365-1101

[0001783180-22-000008:8k_2_02:48]
Danielle.Canzanella@Carrier.com

[0001783180-22-000008:8k_2_02:49]
Investor Relations

[0001783180-22-000008:8k_2_02:50]
Sam Pearlstein

[0001783180-22-000008:8k_2_02:51]
561-365-2251

[0001783180-22-000008:8k_2_02:52]
Sam.Pearlstein@Carrier.com

[0001783180-22-000008:8k_2_02:53]
SELECTED FINANCIAL DATA, NON-GAAP MEASURES AND DEFINITIONS

[0001783180-22-000008:8k_2_02:54]
Following are tables that present selected financial data of Carrier Global Corporation (“Carrier”). Also included are reconciliations of non-GAAP measures to their most comparable GAAP measures.

[0001783180-22-000008:8k_2_02:55]
Use and Definitions of Non-GAAP Financial Measures

[0001783180-22-000008:8k_2_02:56]
Carrier reports its financial results in accordance with accounting principles generally accepted in the United States ("GAAP").

[0001783180-22-000008:8k_2_02:57]
We supplement the reporting of our financial information determined under GAAP with certain non-GAAP financial information. The non-GAAP information presented provides investors with additional useful information, but should not be considered in isolation or as substitutes for the related GAAP measures. Moreover, other companies may define non-GAAP measures differently, which limits the usefulness of these measures for comparisons with such other companies. We encourage investors to review our financial statements and publicly filed reports in their entirety and not to rely on any single financial measure. A reconciliation of the non-GAAP measures to the corresponding amounts prepared in accordance with GAAP appears in the tables attached to this release. The tables provide additional information as to the items and amounts that have been excluded from the adjusted measures.

[0001783180-22-000008:8k_2_02:58]
Organic sales, adjusted operating profit, adjusted operating margin, incremental margins / earnings conversion, earnings before interest, taxes and depreciation and amortization (“EBITDA”), adjusted EBITDA, adjusted net income, adjusted earnings per share (“EPS”), the adjusted effective tax rate, and net debt are non-GAAP financial measures.

[0001783180-22-000008:8k_2_02:59]
Organic sales represents consolidated net sales (a GAAP measure), excluding the impact of foreign currency translation, acquisitions and divestitures completed in the preceding twelve months and other significant items of a nonoperational nature (hereinafter referred to as “other significant items”). Adjusted operating profit represents operating profit (a GAAP measure), excluding restructuring costs and other significant items. Adjusted operating margin represents adjusted operating profit as a percentage of net sales (a GAAP measure). Incremental margins / earnings conversion represents the year-over-year change in adjusted operating profit divided by the year-over-year change in net sales. EBITDA represents net income attributable to common shareholders (a GAAP measure), adjusted for interest income and expense, income tax expense, and depreciation and amortization. Adjusted EBITDA represents EBITDA, as calculated above, excluding non-service pension benefit, non-controlling interest in subsidiaries’ earnings from operations, restructuring costs and other significant items. Adjusted net income represents net income attributable to common shareowners (a GAAP measure), excluding restructuring costs and other significant items. Adjusted EPS represents diluted earnings per share (a GAAP measure), excluding restructuring costs and other significant items. The adjusted effective tax rate represents the effective tax rate (a GAAP measure), excluding restructuring costs and other significant items. Net debt represents long-term debt (a GAAP measure) less cash and cash equivalents. For the business segments, when applicable, adjustments of operating profit and operating margins represent operating profit, excluding restructuring and other significant items.

[0001783180-22-000008:8k_2_02:60]
5

[0001783180-22-000008:8k_2_02:61]
Free cash flow is a non-GAAP financial measure that represents net cash flows provided by operating activities (a GAAP measure) less capital expenditures. Management believes free cash flow is a useful measure of liquidity and an additional basis for assessing Carrier’s ability to fund its activities, including the financing of acquisitions, debt service, repurchases of Carrier's common stock and distribution of earnings to shareowners.

[0001783180-22-000008:8k_2_02:62]
When we provide our expectations for organic sales, adjusted operating profit, adjusted operating margin, adjusted effective tax rate, incremental margins/earnings conversion, adjusted EPS and free cash flow on a forward-looking basis, a reconciliation of the differences between the non-GAAP expectations and the corresponding GAAP measures (expected net sales, operating profit, operating margin, effective tax rate, incremental operating margin, diluted EPS and net cash flows provided by operating activities) generally is not available without unreasonable effort due to potentially high variability, complexity and low visibility as to the items that would be excluded from the GAAP measure in the relevant future period, such as unusual gains and losses, the ultimate outcome of pending litigation, fluctuations in foreign currency exchange rates, the impact and timing of potential acquisitions and divestitures, future restructuring costs, and other structural changes or their probable significance. The variability of the excluded items may have a significant, and potentially unpredictable, impact on our future GAAP results.

[0001783180-22-000008:8k_2_02:63]
6

[0001783180-22-000008:8k_2_02:64]
Carrier Global Corporation

[0001783180-22-000008:8k_2_02:65]
Consolidated Statement of Operations

[0001783180-22-000008:8k_2_02:66]
|  | (Unaudited) |
|  | For the Three Months Ended December 31, |  | For the Year Ended December 31, |
| (In millions, except per share amounts) | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Net sales |  |  |  |  |  |  |  |
| Product sales | $ | 4,256 |  |  | $ | 3,732 |  |  | $ | 17,214 |  |  | $ | 14,347 |  |
| Service sales | 877 |  |  | 862 |  |  | 3,399 |  |  | 3,109 |  |
| Total Net sales | 5,133 |  |  | 4,594 |  |  | 20,613 |  |  | 17,456 |  |
| Costs and expenses |  |  |  |  |  |  |  |
| Cost of products sold | (3,169) |  |  | (2,721) |  |  | (12,300) |  |  | (10,185) |  |
| Cost of services sold | (598) |  |  | (588) |  |  | (2,333) |  |  | (2,162) |  |
| Research and development | (134) |  |  | (127) |  |  | (503) |  |  | (419) |  |
| Selling, general and administrative | (816) |  |  | (810) |  |  | (3,120) |  |  | (2,820) |  |
| Total Costs and expenses | (4,717) |  |  | (4,246) |  |  | (18,256) |  |  | (15,586) |  |
| Equity method investment net earnings | 48 |  |  | 59 |  |  | 249 |  |  | 207 |  |
| Other income (expense), net | (1) |  |  | 838 |  |  | 39 |  |  | 1,006 |  |
| Operating profit | 463 |  |  | 1,245 |  |  | 2,645 |  |  | 3,083 |  |
| Non-service pension benefit | 10 |  |  | 13 |  |  | 61 |  |  | 60 |  |
| Interest (expense) income, net | (68) |  |  | (82) |  |  | (306) |  |  | (288) |  |
| Income from operations before income taxes | 405 |  |  | 1,176 |  |  | 2,400 |  |  | 2,855 |  |
| Income tax expense | (73) |  |  | (289) |  |  | (699) |  |  | (849) |  |
| Net income from operations | 332 |  |  | 887 |  |  | 1,701 |  |  | 2,006 |  |
| Less: Non-controlling interest in subsidiaries' earnings from operations | 8 |  |  | 3 |  |  | 37 |  |  | 24 |  |
| Net income attributable to common shareowners | $ | 324 |  |  | $ | 884 |  |  | $ | 1,664 |  |  | $ | 1,982 |  |
| Earnings per share (1), (2) |  |  |  |  |  |  |  |
| Basic | $ | 0.38 |  |  | $ | 1.02 |  |  | $ | 1.92 |  |  | $ | 2.29 |  |
| Diluted | $ | 0.36 |  |  | $ | 1.00 |  |  | $ | 1.87 |  |  | $ | 2.25 |  |
| Weighted-average number of shares outstanding (2) |  |  |  |  |  |  |  |
| Basic | 865.2 |  | 867.4 |  | 867.7 |  | 866.5 |
| Diluted | 888.5 |  | 888.4 |  | 890.3 |  | 880.2 |

[0001783180-22-000008:8k_2_02:67]
(1) On April 3, 2020, United Technologies Corporation, since renamed Raytheon Technologies Corporation ("UTC"), completed the spin-off of Carrier into a separate publicly traded company (the "Separation"). The Separation was completed through a pro-rata distribution (the "Distribution") of all of the outstanding common stock of the Company to UTC shareowners who held shares of UTC common stock as of the close of business on March 19, 2020.

[0001783180-22-000008:8k_2_02:68]
(2) Basic and diluted earnings per share for the twelve months ended December 31, 2020 are calculated using the weighted-average number of common shares outstanding for the period beginning after the Distribution date. Diluted earnings per share is computed by giving effect to all potentially dilutive stock awards that are outstanding. For periods prior to the Separation it was assumed that there were no dilutive equity instruments as there were no equity awards in Carrier common stock outstanding prior to the Separation.

[0001783180-22-000008:8k_2_02:69]
7

[0001783180-22-000008:8k_2_02:70]
Carrier Global Corporation

[0001783180-22-000008:8k_2_02:71]
Consolidated Balance Sheet

[0001783180-22-000008:8k_2_02:72]
|  | (Unaudited) |
|  | As of December 31, |
| (In millions) | 2021 |  | 2020 |
| Assets |  |  |  |
| Cash and cash equivalents | $ | 2,987 |  |  | $ | 3,115 |  |
| Accounts receivable, net | 2,403 |  |  | 2,781 |  |
| Contract assets, current | 503 |  |  | 656 |  |
| Inventories, net | 1,970 |  |  | 1,629 |  |
| Assets held for sale | 3,168 |  |  | — |  |
| Other assets, current | 376 |  |  | 343 |  |
| Total current assets | 11,407 |  |  | 8,524 |  |
| Future income tax benefits | 563 |  |  | 449 |  |
| Fixed assets, net | 1,826 |  |  | 1,810 |  |
| Operating lease right-of-use assets | 640 |  |  | 788 |  |
| Intangible assets, net | 509 |  |  | 1,037 |  |
| Goodwill | 9,349 |  |  | 10,139 |  |
| Pension and post-retirement assets | 43 |  |  | 554 |  |
| Equity method investments | 1,593 |  |  | 1,513 |  |
| Other assets | 242 |  |  | 279 |  |
| Total Assets | $ | 26,172 |  |  | $ | 25,093 |  |
| Liabilities and Equity |  |  |  |
| Accounts payable | $ | 2,334 |  |  | $ | 1,936 |  |
| Accrued liabilities | 2,561 |  |  | 2,471 |  |
| Contract liabilities, current | 415 |  |  | 512 |  |
| Liabilities held for sale | 1,134 |  |  | — |  |
| Current portion of long-term debt | 183 |  |  | 191 |  |
| Total current liabilities | 6,627 |  |  | 5,110 |  |
| Long-term debt | 9,513 |  |  | 10,036 |  |
| Future pension and post-retirement obligations | 380 |  |  | 524 |  |
| Future income tax obligations | 354 |  |  | 479 |  |
| Operating lease liabilities | 527 |  |  | 642 |  |
| Other long-term liabilities | 1,677 |  |  | 1,724 |  |
| Total Liabilities | 19,078 |  |  | 18,515 |  |
| Equity |  |  |  |
| Common stock, par value $0.01; 4,000,000,000 shares authorized; 873,064,219 and 867,829,119 shares issued; 863,039,097 and 867,829,119 outstanding as of December 31, 2021 and 2020, respectively | 9 |  |  | 9 |  |
| Treasury stock | (529) |  |  | — |  |
| Additional paid-in capital | 5,411 |  |  | 5,345 |  |
| Retained earnings | 2,865 |  |  | 1,643 |  |
| Accumulated other comprehensive loss | (989) |  |  | (745) |  |
| Non-controlling interest | 327 |  |  | 326 |  |
| Total Equity | 7,094 |  |  | 6,578 |  |
| Total Liabilities and Equity | $ | 26,172 |  |  | $ | 25,093 |  |

[0001783180-22-000008:8k_2_02:73]
8

[0001783180-22-000008:8k_2_02:74]
Carrier Global Corporation

[0001783180-22-000008:8k_2_02:75]
Consolidated Statement of Cash Flows (Unaudited)

[0001783180-22-000008:8k_2_02:76]
|  |  | For the Year Ended December 31, |
| (In millions) |  |  |  | 2021 |  | 2020 |
| Operating Activities |  |  |  |  |  |  |
| Net income from operations |  |  |  | $ | 1,701 |  |  | $ | 2,006 |  |
| Adjustments to reconcile net income from operations to net cash flows from operating activities |  |  |  |  |  |  |
| Depreciation and amortization |  |  |  | 338 |  |  | 336 |  |
| Deferred income tax provision |  |  |  | (74) |  |  | 97 |  |
| Stock-based compensation cost |  |  |  | 92 |  |  | 77 |  |
| Equity method investment net earnings |  |  |  | (249) |  |  | (207) |  |
| Impairment charge on minority-owned joint venture investments |  |  |  | 2 |  |  | 72 |  |
| (Gain) loss on sale of investments and businesses |  |  |  | 2 |  |  | (1,123) |  |
| Changes in operating assets and liabilities |  |  |  |  |  |  |
| Accounts receivable, net |  |  |  | (97) |  |  | 49 |  |
| Contract assets, current |  |  |  | (47) |  |  | (9) |  |
| Inventories, net |  |  |  | (408) |  |  | (240) |  |
| Other assets, current |  |  |  | (11) |  |  | 3 |  |
| Accounts payable and accrued liabilities |  |  |  | 829 |  |  | 237 |  |
| Contract liabilities, current |  |  |  | 51 |  |  | 46 |  |
| Defined benefit plan contributions |  |  |  | (47) |  |  | (41) |  |
| Distributions from equity method investments |  |  |  | 159 |  |  | 169 |  |
| Other operating activities, net |  |  |  | (4) |  |  | 220 |  |
| Net cash flows provided by (used in) operating activities |  |  |  | 2,237 |  |  | 1,692 |  |
| Investing Activities |  |  |  |  |  |  |
| Capital expenditures |  |  |  | (344) |  |  | (312) |  |
| Investment in businesses, net of cash acquired |  |  |  | (366) |  |  | — |  |
| Proceeds on sale of investments |  |  |  | 7 |  |  | 1,377 |  |
| Settlement of derivative contracts, net |  |  |  | 4 |  |  | 40 |  |
| Other investing activities, net |  |  |  | 7 |  |  | 1 |  |
| Net cash flows provided by (used in) investing activities |  |  |  | (692) |  |  | 1,106 |  |
| Financing Activities |  |  |  |  |  |  |
| (Decrease) increase in short-term borrowings, net |  |  |  | 13 |  |  | (23) |  |
| Issuance of long-term debt |  |  |  | 140 |  |  | 11,784 |  |
| Repayment of long-term debt |  |  |  | (704) |  |  | (1,911) |  |
| Repurchases of common stock |  |  |  | (527) |  |  | — |  |
| Dividends paid on common stock |  |  |  | (417) |  |  | (138) |  |
| Dividends paid to non-controlling interest |  |  |  | (42) |  |  | (48) |  |
| Net transfers to UTC |  |  |  | — |  |  | (10,359) |  |
| Other financing activities, net |  |  |  | (25) |  |  | 14 |  |
| Net cash flows provided by (used in) financing activities |  |  |  | (1,562) |  |  | (681) |  |
| Effect of foreign exchange rate changes on cash and cash equivalents |  |  |  | (16) |  |  | 45 |  |
| Net increase (decrease) in cash and cash equivalents and restricted cash, including cash classified in current assets held for sale |  |  |  | (33) |  |  | 2,162 |  |
| Less: Change in cash balances classified as assets held for sale |  |  |  | 60 |  |  | — |  |
| Net increase (decrease) in cash and cash equivalents and restricted cash |  |  |  | (93) |  |  | 2,162 |  |
| Cash, cash equivalents and restricted cash, beginning of period |  |  |  | 3,119 |  |  | 957 |  |
| Cash, cash equivalents and restricted cash, end of period |  |  |  | 3,026 |  |  | 3,119 |  |
| Less: restricted cash |  |  |  | 39 |  |  | 4 |  |
| Cash and cash equivalents, end of period |  |  |  | $ | 2,987 |  |  | $ | 3,115 |  |

[0001783180-22-000008:8k_2_02:77]
9

[0001783180-22-000008:8k_2_02:78]
Carrier Global Corporation

[0001783180-22-000008:8k_2_02:79]
Segment Net Sales and Operating Profit

[0001783180-22-000008:8k_2_02:80]
|  | (Unaudited) |
|  | For the Three Months Ended December 31, |  | For the Year Ended December 31, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| (In millions) | Reported |  | Adjusted |  | Reported |  | Adjusted |  | Reported |  | Adjusted |  | Reported |  | Adjusted |
| Net sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| HVAC | $ | 2,730 |  | $ | 2,730 |  | $ | 2,336 |  | $ | 2,336 |  | $ | 11,390 |  | $ | 11,390 |  | $ | 9,478 |  | $ | 9,478 |
| Refrigeration | 1,090 |  | 1,090 |  | 949 |  | 949 |  | 4,127 |  | 4,127 |  | 3,333 |  | 3,333 |
| Fire & Security | 1,431 |  | 1,431 |  | 1,398 |  | 1,398 |  | 5,515 |  | 5,515 |  | 4,985 |  | 4,985 |
| Segment sales | 5,251 |  | 5,251 |  | 4,683 |  | 4,683 |  | 21,032 |  | 21,032 |  | 17,796 |  | 17,796 |
| Eliminations and other | (118) |  | (118) |  | (89) |  | (89) |  | (419) |  | (419) |  | (340) |  | (340) |
| Net sales | $ | 5,133 |  | $ | 5,133 |  | $ | 4,594 |  | $ | 4,594 |  | $ | 20,613 |  | $ | 20,613 |  | $ | 17,456 |  | $ | 17,456 |
| Operating profit |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| HVAC | $ | 227 |  | $ | 242 |  | $ | 1,098 |  | $ | 231 |  | $ | 1,738 |  | $ | 1,776 |  | $ | 2,462 |  | $ | 1,430 |
| Refrigeration | 107 |  | 125 |  | 94 |  | 110 |  | 476 |  | 501 |  | 357 |  | 375 |
| Fire & Security | 182 |  | 199 |  | 158 |  | 186 |  | 662 |  | 730 |  | 584 |  | 628 |
| Segment operating profit | 516 |  | 566 |  | 1,350 |  | 527 |  | 2,876 |  | 3,007 |  | 3,403 |  | 2,433 |
| Eliminations and other | (23) |  | (23) |  | (62) |  | (33) |  | (96) |  | (79) |  | (184) |  | (73) |
| General corporate expenses | (30) |  | (26) |  | (43) |  | (41) |  | (135) |  | (124) |  | (136) |  | (128) |
| Operating profit | $ | 463 |  | $ | 517 |  | $ | 1,245 |  | $ | 453 |  | $ | 2,645 |  | $ | 2,804 |  | $ | 3,083 |  | $ | 2,232 |
| Operating margin |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| HVAC | 8.3 | % |  | 8.9 | % |  | 47.0 | % |  | 9.9 | % |  | 15.3 | % |  | 15.6 | % |  | 26.0 | % |  | 15.1 | % |
| Refrigeration | 9.8 | % |  | 11.5 | % |  | 9.9 | % |  | 11.6 | % |  | 11.5 | % |  | 12.1 | % |  | 10.7 | % |  | 11.3 | % |
| Fire & Security | 12.7 | % |  | 13.9 | % |  | 11.3 | % |  | 13.3 | % |  | 12.0 | % |  | 13.2 | % |  | 11.7 | % |  | 12.6 | % |
| Total Carrier | 9.0 | % |  | 10.1 | % |  | 27.1 | % |  | 9.9 | % |  | 12.8 | % |  | 13.6 | % |  | 17.7 | % |  | 12.8 | % |

[0001783180-22-000008:8k_2_02:81]
10

[0001783180-22-000008:8k_2_02:82]
Carrier Global Corporation

[0001783180-22-000008:8k_2_02:83]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP)

[0001783180-22-000008:8k_2_02:84]
Operating Profit

[0001783180-22-000008:8k_2_02:85]
|  |  | (Unaudited) |
|  |  | For the Three Months Ended |  | For the Year Ended |
|  | December 31, |  | December 31, |
| (In millions - Income (Expense)) | 2021 |  | 2020 |  | 2021 |  | 2020 |
| HVAC |  |  |  |  |
|  | Net sales | $ | 2,730 |  |  | $ | 2,336 |  |  | $ | 11,390 |  |  | $ | 9,478 |  |
|  | Operating profit | $ | 227 |  |  | $ | 1,098 |  |  | $ | 1,738 |  |  | $ | 2,462 |  |
|  | Restructuring | (15) |  |  | (4) |  |  | (33) |  |  | (7) |  |
|  | Impairment of joint venture investment | — |  |  | — |  |  | — |  |  | (71) |  |
|  | Gain on sale of joint venture | — |  |  | 871 |  |  | — |  |  | 1,123 |  |
|  | Charge resulting from litigation matter | — |  |  | — |  |  | — |  |  | (11) |  |
|  | Separation costs | — |  |  | — |  |  | — |  |  | (2) |  |
|  | Acquisition and other related costs | — |  |  | — |  |  | (5) |  |  | — |  |
|  | Adjusted operating profit | $ | 242 |  |  | $ | 231 |  |  | $ | 1,776 |  |  | $ | 1,430 |  |
| Refrigeration |  |  |  |  |  |  |  |
|  | Net sales | $ | 1,090 |  |  | $ | 949 |  |  | $ | 4,127 |  |  | $ | 3,333 |  |
|  | Operating profit | $ | 107 |  |  | $ | 94 |  |  | $ | 476 |  |  | $ | 357 |  |
|  | Restructuring | (18) |  |  | (10) |  |  | (25) |  |  | (12) |  |
|  | Separation costs | — |  |  | (6) |  |  | — |  |  | (6) |  |
|  | Adjusted operating profit | $ | 125 |  |  | $ | 110 |  |  | $ | 501 |  |  | $ | 375 |  |
| Fire & Security |  |  |  |  |  |  |  |
|  | Net sales | $ | 1,431 |  |  | $ | 1,398 |  |  | $ | 5,515 |  |  | $ | 4,985 |  |
|  | Operating profit | $ | 182 |  |  | $ | 158 |  |  | $ | 662 |  |  | $ | 584 |  |
|  | Restructuring | (3) |  |  | (15) |  |  | (26) |  |  | (28) |  |
|  | Separation costs | — |  |  | (13) |  |  | — |  |  | (16) |  |
|  | Chubb transaction costs | (14) |  |  | — |  |  | (42) |  |  | — |  |
|  | Adjusted operating profit | $ | 199 |  |  | $ | 186 |  |  | $ | 730 |  |  | $ | 628 |  |
| General Corporate Expenses and Eliminations and Other |  |  |  |  |  |  |  |
|  | Net sales | $ | (118) |  |  | $ | (89) |  |  | $ | (419) |  |  | $ | (340) |  |
|  | Operating profit | $ | (53) |  |  | $ | (105) |  |  | $ | (231) |  |  | $ | (320) |  |
|  | Restructuring | (1) |  |  | (1) |  |  | (5) |  |  | (2) |  |
|  | Separation costs | (1) |  |  | (30) |  |  | (20) |  |  | (117) |  |
|  | Chubb transaction costs | — |  |  | — |  |  | (1) |  |  | — |  |
|  | Other | (2) |  |  | — |  |  | (2) |  |  | — |  |
|  | Adjusted operating profit | $ | (49) |  |  | $ | (74) |  |  | $ | (203) |  |  | $ | (201) |  |
| Carrier |  |  |  |  |  |  |  |
|  | Net sales | $ | 5,133 |  |  | $ | 4,594 |  |  | $ | 20,613 |  |  | $ | 17,456 |  |
|  | Operating profit | $ | 463 |  |  | $ | 1,245 |  | $ | 2,645 |  |  | $ | 3,083 |
|  | Total restructuring costs | (37) |  |  | (30) |  |  | (89) |  |  | (49) |  |
|  | Total non-recurring and non-operational items | (17) |  |  | 822 |  |  | (70) |  |  | 900 |  |
|  | Adjusted operating profit | $ | 517 |  |  | $ | 453 |  |  | $ | 2,804 |  |  | $ | 2,232 |  |

[0001783180-22-000008:8k_2_02:86]
11

[0001783180-22-000008:8k_2_02:87]
Carrier Global Corporation

[0001783180-22-000008:8k_2_02:88]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP) Results

[0001783180-22-000008:8k_2_02:89]
Net Income, Earnings Per Share, and Effective Tax Rate

[0001783180-22-000008:8k_2_02:90]
|  | (Unaudited) |
|  | For the Three Months Ended December 31, 2021 |  | For the Year Ended December 31, 2021 |
| (In millions, except per share amounts) | Reported |  | Adjustments |  | Adjusted |  | Reported |  | Adjustments |  | Adjusted |
| Net sales | $ | 5,133 |  |  | $ | — |  |  | $ | 5,133 |  |  | $ | 20,613 |  |  | $ | — |  |  | $ | 20,613 |  |
| Operating profit | $ | 463 |  |  | 54 |  | a | $ | 517 |  |  | $ | 2,645 |  |  | 159 |  | a | $ | 2,804 |  |
| Operating margin | 9.0 | % |  |  |  | 10.1 | % |  | 12.8 | % |  |  |  | 13.6 | % |
| Income from operations before income taxes | $ | 405 |  |  | 54 |  | a,b | $ | 459 |  |  | $ | 2,400 |  |  | 178 |  | a,b | $ | 2,578 |  |
| Income tax expense | $ | (73) |  |  | 11 |  | c | $ | (62) |  |  | $ | (699) |  |  | 171 |  | c | $ | (528) |  |
| Income tax rate | 18.0 | % |  |  |  | 13.5 | % |  | 29.1 | % |  |  |  | 20.5 | % |
| Net income attributable to common shareowners | $ | 324 |  |  | $ | 65 |  |  | $ | 389 |  |  | $ | 1,664 |  |  | $ | 349 |  |  | $ | 2,013 |  |
| Summary of Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring costs |  |  | $ | 37 |  | a |  |  |  |  | $ | 89 |  | a |  |
| Separation costs |  |  | 1 |  | a |  |  |  |  | 20 |  | a |  |
| Acquisition and other related costs |  |  | 2 |  | a |  |  |  |  | 7 |  | a |  |
| Chubb transaction costs |  |  | 14 |  | a |  |  |  |  | 43 |  | a |  |
| Debt prepayment costs |  |  | — |  | b |  |  |  |  | 19 |  | b |  |
| Total adjustments |  |  | $ | 54 |  |  |  |  |  |  | $ | 178 |  |  |  |
| Tax effect on adjustments above |  |  | $ | (10) |  |  |  |  |  |  | $ | (29) |  |  |  |
| Tax specific adjustments |  |  | 21 |  |  |  |  |  |  | 200 |  |  |  |
| Total tax adjustments |  |  | $ | 11 |  | c |  |  |  |  | $ | 171 |  | c |  |
| Shares outstanding - Diluted | 888.5 |  |  |  |  | 888.5 |  |  | 890.3 |  |  |  |  | 890.3 |  |
| Earnings per share - Diluted | $ | 0.36 |  |  |  |  | $ | 0.44 |  |  | $ | 1.87 |  |  |  |  | $ | 2.26 |  |

[0001783180-22-000008:8k_2_02:91]
Carrier Global Corporation

[0001783180-22-000008:8k_2_02:92]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP) Results

[0001783180-22-000008:8k_2_02:93]
Net Income, Earnings Per Share, and Effective Tax Rate

[0001783180-22-000008:8k_2_02:94]
|  | (Unaudited) |
|  | For the Three Months Ended December 31, 2020 |  | For the Year Ended December 31, 2020 |
| (In millions, except per share amounts) | Reported |  | Adjustments |  | Adjusted |  | Reported |  | Adjustments |  | Adjusted |
| Net sales | $ | 4,594 |  |  | $ | — |  |  | $ | 4,594 |  |  | $ | 17,456 |  |  | $ | — |  |  | $ | 17,456 |  |
| Operating profit | $ | 1,245 |  |  | (792) |  | a | $ | 453 |  |  | $ | 3,083 |  |  | (851) |  | a | $ | 2,232 |  |
| Operating margin | 27.1 | % |  |  |  | 9.9 | % |  | 17.7 | % |  |  |  | 12.8 | % |
| Income from operations before income taxes | $ | 1,176 |  |  | (792) |  | a,b | $ | 384 |  |  | $ | 2,855 |  |  | (846) |  | a,b | $ | 2,009 |  |
| Income tax expense | $ | (289) |  |  | 188 |  | c | $ | (101) |  |  | $ | (849) |  |  | 326 |  | c | $ | (523) |  |
| Income tax rate | 24.5 | % |  |  |  | 26.3 | % |  | 29.7 | % |  |  |  | 26.0 | % |
| Net income attributable to common shareowners | $ | 884 |  |  | $ | (604) |  |  | $ | 280 |  |  | $ | 1,982 |  |  | $ | (520) |  |  | $ | 1,462 |  |
| Summary of Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring costs |  |  | $ | 30 |  | a |  |  |  |  | $ | 49 |  | a |  |
| Gain on sale of joint venture |  |  | (871) |  | a |  |  |  |  | (1,123) |  | a |  |
| Impairment of equity method investment |  |  | — |  | a |  |  |  |  | 71 |  | a |  |
| Charge resulting from litigation matter |  |  | — |  | a |  |  |  |  | 11 |  | a |  |
| Separation costs |  |  | 49 |  | a |  |  |  |  | 141 |  | a |  |
| Debt issuance costs |  |  | — |  | b |  |  |  |  | 5 |  | b |  |
| Total adjustments |  |  | $ | (792) |  |  |  |  |  |  | $ | (846) |  |  |  |
| Tax effect on adjustments above |  |  | $ | 188 |  |  |  |  |  |  | $ | 217 |  |  |  |
| Tax specific adjustments |  |  | — |  |  |  |  |  |  | 109 |  |  |  |
| Total tax adjustments |  |  | $ | 188 |  | c |  |  |  |  | $ | 326 |  | c |  |
| Shares outstanding - Diluted | 888.4 |  |  |  |  | 888.4 |  |  | 880.2 |  |  |  |  | 880.2 |  |
| Earnings per share - Diluted | $ | 1.00 |  |  |  |  | $ | 0.31 |  |  | $ | 2.25 |  |  |  |  | $ | 1.66 |  |

[0001783180-22-000008:8k_2_02:95]
13

[0001783180-22-000008:8k_2_02:96]
Carrier Global Corporation

[0001783180-22-000008:8k_2_02:97]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP) Results

[0001783180-22-000008:8k_2_02:98]
Components of Changes in Net Sales

[0001783180-22-000008:8k_2_02:99]
Three Months Ended December 31, 2021 Compared with Three Months Ended December 31, 2020

[0001783180-22-000008:8k_2_02:100]
|  | (Unaudited) |
|  | Factors Contributing to Total % change in Net Sales |
|  | Organic |  | FX Translation |  | Acquisitions / Divestitures, net |  | Other |  | Total |
| HVAC | 14% |  | —% |  | 3% |  | —% |  | 17% |
| Refrigeration | 17% |  | (2)% |  | —% |  | —% |  | 15% |
| Fire & Security | 3% |  | (1)% |  | —% |  | —% |  | 2% |
| Consolidated | 11% |  | (1)% |  | 2% |  | —% |  | 12% |

[0001783180-22-000008:8k_2_02:101]
Year Ended December 31, 2021 Compared with Year Ended December 31, 2020

[0001783180-22-000008:8k_2_02:102]
|  | (Unaudited) |
|  | Factors Contributing to Total % change in Net Sales |
|  | Organic |  | FX Translation |  | Acquisitions / Divestitures, net |  | Other |  | Total |
| HVAC | 17% |  | 1% |  | 2% |  | —% |  | 20% |
| Refrigeration | 21% |  | 3% |  | —% |  | —% |  | 24% |
| Fire & Security | 7% |  | 4% |  | —% |  | —% |  | 11% |
| Consolidated | 15% |  | 2% |  | 1% |  | —% |  | 18% |

[0001783180-22-000008:8k_2_02:103]
Free Cash Flow Reconciliation

[0001783180-22-000008:8k_2_02:104]
|  |  | (Unaudited) |  |
|  |  | Q1 |  | Q2 |  | Q3 |  | Q4 |  | FY |  | Q1 |  | Q2 |  | Q3 |  | Q4 |  | FY |
| (In millions) |  | 2020 |  | 2020 |  | 2020 |  | 2020 |  | 2020 |  | 2021 |  | 2021 |  | 2021 |  | 2021 |  | 2021 |
| Net cash flows provided by operating activities |  | $ | 47 |  |  | $ | 509 |  |  | $ | 937 |  |  | $ | 199 |  |  | $ | 1,692 |  |  | $ | 184 |  |  | $ | 561 |  |  | $ | 579 |  |  | $ | 913 |  |  | $ | 2,237 |  |
| Less: Capital expenditures |  | 48 |  |  | 46 |  |  | 57 |  |  | 161 |  |  | 312 |  |  | 53 |  |  | 79 |  |  | 74 |  |  | 138 |  |  | 344 |  |
| Free cash flow |  | $ | (1) |  |  | $ | 463 |  |  | $ | 880 |  |  | $ | 38 |  |  | $ | 1,380 |  |  | $ | 131 |  |  | $ | 482 |  |  | $ | 505 |  |  | $ | 775 |  |  | $ | 1,893 |  |

[0001783180-22-000008:8k_2_02:105]
Net Debt Reconciliation

[0001783180-22-000008:8k_2_02:106]
|  |  | (Unaudited) |
|  |  | As of December 31, |
| (In millions) |  | 2021 |  | 2020 (1) |
| Long-term debt |  | $ | 9,513 |  |  | $ | 10,036 |  |
| Current portion of long-term debt |  | 183 |  |  | 191 |  |
| Less: Cash and cash equivalents |  | 2,987 |  |  | 3,115 |  |
| Net debt |  | $ | 6,709 |  |  | $ | 7,112 |  |

[0001783180-22-000008:8k_2_02:107]
(1) On April 1 and April 2, 2020, Carrier received cash contributions totaling $590 million from UTC related to the Separation, resulting in net debt of approximately $9.9 billion as of April 3, 2020.

[0001783180-22-000008:8k_2_02:108]
14
