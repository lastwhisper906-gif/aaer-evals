# CARR MD&A — 0001783180-22-000010


## mdna

[0001783180-22-000010:mdna:1]
ITEM 7. MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0001783180-22-000010:mdna:2]
BUSINESS OVERVIEW

[0001783180-22-000010:mdna:3]
Business Summary

[0001783180-22-000010:mdna:4]
Carrier Global Corporation is a leading global provider of healthy, safe, sustainable and intelligent building and cold chain solutions. Our portfolio includes industry-leading brands such as Carrier, Kidde, Edwards, LenelS2, Carrier Transicold and Automated Logic that offer innovative HVAC, refrigeration, fire, security and building automation technologies to help make the world safer and more comfortable. We also provide a broad array of related building services, including audit, design, installation, system integration, repair, maintenance and monitoring. Our operations are classified into three segments: HVAC, Refrigeration and Fire & Security.

[0001783180-22-000010:mdna:5]
Our worldwide operations are affected by global and regional industrial, economic and political factors and trends. These include the mega-trends of urbanization, climate change and increasing requirements for food safety driven by the food needs of our growing global population and the rising standards of living in emerging markets. We believe that our business segments are well positioned to benefit from favorable secular trends, including these mega-trends and from the strength of our industry-leading brands and track record of innovation. In addition, we regularly review our markets to proactively identify trends and adapt our strategies accordingly.

[0001783180-22-000010:mdna:6]
Our business is also affected by changes in the general level of economic activity, such as changes in business and consumer spending, construction and shipping activity as well as short-term economic factors such as currency fluctuations, commodity price volatility and supply disruptions. However, we continue to invest in our business, take pricing actions to mitigate supply chain and inflationary pressures, develop new products and services in order to remain competitive in our markets and use risk management strategies to mitigate various exposures. We believe that we have industry-leading global brands, which form the foundation of our business strategy. Coupled with our focus on growth, innovation and operational efficiency, we expect to drive long-term future growth and increased value for our shareowners.

[0001783180-22-000010:mdna:7]
Recent Developments

[0001783180-22-000010:mdna:8]
Supply Chain Challenges

[0001783180-22-000010:mdna:9]
The ongoing global economic recovery from the COVID-19 pandemic has caused significant challenges for global supply chains resulting in inflationary cost pressures, component shortages and transportation delays. As a result, we have incurred incremental costs for commodities and components used in our products as well as component shortages and higher freight costs that have negatively impacted our sales and results of operations. We expect that these challenges will continue to have an impact on our business for the foreseeable future.

[0001783180-22-000010:mdna:10]
We continue to take proactive steps to limit the impact of these challenges and are working closely with our suppliers to ensure availability of products and implement other cost savings initiatives. In addition, we continue to invest in our operations and supply chain to improve its resilience with a focus on automation, dual sourcing of critical components and localized manufacturing when feasible. To date, there has been moderate disruption to the availability of our products, though it is possible that more significant disruptions could occur if these supply chain challenges continue.

[0001783180-22-000010:mdna:11]
Sale of Chubb Fire & Security Business

[0001783180-22-000010:mdna:12]
On January 3, 2022, we completed the sale of Chubb to APi pursuant to a stock purchase agreement for an enterprise value of $3.1 billion. Chubb, reported within our Fire & Security segment, delivers essential fire safety and security solutions from design and installation to monitoring, service and maintenance across more than 17 countries around the globe. As a result, the

[0001783180-22-000010:mdna:13]
32

[0001783180-22-000010:mdna:14]
operations of Chubb are included in our 2021 consolidated results of operations. However, the assets and liabilities of Chubb are presented as held for sale in the accompanying Consolidated Balance Sheet as of December 31, 2021. The purchase price is subject to working capital and other adjustments as provided in the Chubb Sale Agreement. Consistent with our capital allocation strategy, the net proceeds of approximately $2.6 billion will be used to fund investments in organic and inorganic growth initiatives and capital returns to our shareowners as well as for general corporate purposes.

[0001783180-22-000010:mdna:15]
Separation from United Technologies Corporation

[0001783180-22-000010:mdna:16]
On April 3, 2020, UTC completed the Separation of Carrier into an independent publicly traded company. In connection with the Separation, we issued an aggregate principal balance of $11.0 billion of debt and transferred approximately $10.9 billion of cash to UTC on February 27, 2020 and March 27, 2020. In addition, we entered into several agreements with UTC and Otis that govern various aspects of the relationship among us, UTC and Otis following the Separation and the Distribution including the TSA (which expired on March 31, 2021), the TMA, an employee matters agreement and an intellectual property agreement. Income and expense under these agreements are not material. On April 1, 2020 and April 2, 2020, we received cash contributions totaling $590 million from UTC related to the Separation.

[0001783180-22-000010:mdna:17]
Our financial statements for periods prior to the Separation and the Distribution are prepared on a "carve-out" basis and include all amounts directly attributable to Carrier. Net cash transfers and other property transferred between UTC and us, including related party receivables and payables between us and other UTC affiliates, are presented as Net transfers to UTC. In addition, the financial statements include allocations of costs for administrative functions and services performed on our behalf by centralized groups within UTC. All allocations and estimates in the Consolidated Financial Statements are based on assumptions that management believes are reasonable. Our financial statements for the periods subsequent to April 3, 2020 are consolidated financial statements based on the reported results of Carrier as a stand-alone company. See Note 2 – Basis of Presentation in the accompanying Notes to the Consolidated Financial Statements in this Annual Report on Form 10-K for additional information.

[0001783180-22-000010:mdna:18]
Impact of the COVID-19 Pandemic

[0001783180-22-000010:mdna:19]
In early 2020, the World Health Organization declared the outbreak of a respiratory disease known as COVID-19 as a global pandemic. In response, many countries implemented containment and mitigation measures to combat the outbreak, which severely restricted the level of economic activity and caused a significant contraction in the global economy. As a result, we temporarily closed or reduced production at manufacturing facilities across the globe to ensure employee safety and instructed non-essential employees to work from home. In addition, we took several preemptive actions during 2020 to manage liquidity as demand for our products decreased. Despite the adverse impacts of the pandemic on our results beginning in the first quarter of 2020, manufacturing operations resumed and several restorative actions were completed during 2020 including the reinstatement of annual merit-based salary increases and continued investment to support our strategic priorities.

[0001783180-22-000010:mdna:20]
We continue to focus our efforts on preserving the health and safety of our employees and customers as well as maintaining the continuity of our operations. In addition, we continue to actively monitor our liquidity position and working capital needs and believe that our overall capital resources and liquidity position are adequate. The preparation of financial statements requires management to use judgments in making estimates and assumptions based on the relevant information available at the end of each period, which can have a significant effect on reported amounts. However, due to significant uncertainty surrounding the pandemic, including a resurgence in cases and the spread of COVID-19 variants, management's judgments could change. While our results of operations, cash flows and financial condition could be negatively impacted, the extent of any continuing impact cannot be estimated with certainty at this time.

[0001783180-22-000010:mdna:21]
RESULTS OF OPERATIONS

[0001783180-22-000010:mdna:22]
This discussion summarizes the significant factors affecting our consolidated results of operations, financial condition and liquidity for the year ended December 31, 2021 compared with December 31, 2020. This discussion should be read in conjunction with Item 8, the Consolidated Financial Statements and the accompanying Notes to the Consolidated Financial Statements in this Annual Report on Form 10-K. A detailed discussion of the year ended December 31, 2020 compared with December 31, 2019 is not included herein and can be found in the Management's Discussion and Analysis section in the Company's 2020 Annual Report on Form 10-K, filed with the SEC on February 9, 2021, under the heading "Results of Operations," which is incorporated herein by reference.

[0001783180-22-000010:mdna:23]
33

[0001783180-22-000010:mdna:24]
Year Ended December 31, 2021 Compared with Year Ended December 31, 2020

[0001783180-22-000010:mdna:25]
The following represents our consolidated net sales and operating results:

[0001783180-22-000010:mdna:26]
| (In millions) | 2021 |  | 2020 |  | Period Change |  | % Change |  |  |
| Net sales | $ | 20,613 |  |  | $ | 17,456 |  |  | $ | 3,157 |  |  | 18 | % |  |  |
| Cost of products and services sold | (14,633) |  |  | (12,347) |  |  | (2,286) |  |  | 19 | % |  |  |
| Gross margin | 5,980 |  |  | 5,109 |  |  | 871 |  |  | 17 | % |  |  |
| Operating expenses | (3,335) |  |  | (2,026) |  |  | (1,309) |  |  | 65 | % |  |  |
| Operating profit | 2,645 |  |  | 3,083 |  |  | (438) |  |  | (14) | % |  |  |
| Non-operating income (expense), net | (245) |  |  | (228) |  |  | (17) |  |  | 7 | % |  |  |
| Income from operations before income taxes | 2,400 |  |  | 2,855 |  |  | (455) |  |  | (16) | % |  |  |
| Income tax expense | (699) |  |  | (849) |  |  | 150 |  |  | (18) | % |  |  |
| Net income from operations | 1,701 |  |  | 2,006 |  |  | (305) |  |  | (15) | % |  |  |
| Less: Non-controlling interest in subsidiaries' earnings from operations | 37 |  |  | 24 |  |  | 13 |  |  | 54 | % |  |  |
| Net income attributable to common shareowners | $ | 1,664 |  |  | $ | 1,982 |  |  | $ | (318) |  |  | (16) | % |  |  |

[0001783180-22-000010:mdna:27]
Net Sales

[0001783180-22-000010:mdna:28]
For the year ended December 31, 2021, Net sales was $20.6 billion, an 18% increase compared with 2020. The components of the year-over-year change were as follows:

[0001783180-22-000010:mdna:29]
|  | 2021 |  |  |  |  |
| Organic / Operational | 15 | % |  |  |  |  |
| Foreign currency translation | 2 | % |  |  |  |  |
| Acquisitions and divestitures, net | 1 | % |  |  |  |  |
| Total % change | 18 | % |  |  |  |  |

[0001783180-22-000010:mdna:30]
For the year ended December 31, 2021, higher volumes and pricing improvements in each of our segments increased organic sales by 15% compared with 2020. The organic increase was primarily driven by our HVAC segment with strong demand in our North America residential and light commercial business and improved global end-markets in our Commercial HVAC business. Higher sales in our Refrigeration and Fire & Security segments were driven by improved global end-markets. Results for 2021 reflected a significant rebound in demand after initial weakness during the first half of 2020 due to the COVID-19 pandemic and current demand remains strong. However, supply chain and logistic constraints continue to be challenging, negatively impacting our sales and results of operations. For additional discussion on the segment results for 2021, see the section entitled "Segment Review."

[0001783180-22-000010:mdna:31]
Gross Margin

[0001783180-22-000010:mdna:32]
For the year ended December 31, 2021, gross margin was $6.0 billion, a 17% increase compared with the same period of 2020. The components were as follows:

[0001783180-22-000010:mdna:33]
| (In millions) | 2021 |  | 2020 |  |  |  |  |  |  |
| Net sales | $ | 20,613 |  |  | $ | 17,456 |  |  |  |  |  |  |  |
| Cost of products and services sold | (14,633) |  |  | (12,347) |  |  |  |  |  |  |  |
| Gross margin | $ | 5,980 |  |  | $ | 5,109 |  |  |  |  |  |  |  |
| Percentage of net sales | 29.0 | % |  | 29.3 | % |  |  |  |  |  |  |

[0001783180-22-000010:mdna:34]
The increase in gross margin for the year ended December 31, 2021 was primarily driven by continued improvement in the global economic climate during the current period. Higher volumes and pricing improvements in each of our segments outpaced operational costs as we continued to focus on Carrier 700 cost containment actions. However, each of our segments was

[0001783180-22-000010:mdna:35]
impacted by the rising cost for commodities and components used in our products, certain supply chain constraints and higher freight costs particularly in the second half of the year. As a result, gross margin as a percentage of Net sales decreased by 30 basis points compared with the same period of 2020.

[0001783180-22-000010:mdna:36]
Operating Expenses

[0001783180-22-000010:mdna:37]
For the year ended December 31, 2021, operating expenses, including Equity method investment net earnings, was $3.3 billion, a 65% increase compared with the same period of 2020. The components were as follows:

[0001783180-22-000010:mdna:38]
|  | For the Year Ended December 31, |  |  |
| (In millions) | 2021 |  | 2020 |  |  |
| Selling, general and administrative | $ | (3,120) |  |  | $ | (2,820) |  |  |  |
| Research and development | (503) |  |  | (419) |  |  |  |
| Equity method investment net earnings | 249 |  |  | 207 |  |  |  |
| Other income (expense), net | 39 |  |  | 1,006 |  |  |  |
| Operating expenses | $ | (3,335) |  |  | $ | (2,026) |  |  |  |
| Percentage of net sales | 16.2 | % |  | 11.6 | % |  |  |

[0001783180-22-000010:mdna:39]
For the year ended December 31, 2021, Selling, general and administrative expenses were $3.1 billion, an 11% increase compared with the same period of 2020. At the onset of the COVID-19 pandemic, we initiated various cost containment initiatives in order to help mitigate the impacts on our business, which included reducing discretionary spending, employee furloughs and temporarily closing or limiting the presence of our workforce in our facilities. As a result, the increase in Selling, general and administrative expense in the current period reflects the gradual return to our operational spending levels prior to the COVID-19 pandemic. In addition, higher compensation and restructuring costs as well as transaction costs of $43 million associated with the divestiture of our Chubb business further contributed to the year-over-year increase. Costs associated with the Separation were $20 million for the year ended December 31, 2021 compared with $141 million for the same period of 2020.

[0001783180-22-000010:mdna:40]
Research and development costs relate to new product development and new technology innovation. Due to the variable nature of program development schedules, year-over-year spending levels can fluctuate. In addition, we continue to invest to prepare for future energy efficiency and refrigerant regulation changes and in digital controls technologies.

[0001783180-22-000010:mdna:41]
Investments over which we do not exercise control, but have significant influence, are accounted for using the equity method of accounting. For the year ended December 31, 2021, Equity method investment net earnings were $249 million, a 20% increase compared with the same period of 2020. The increase was primarily related to higher earnings in HVAC joint ventures in Asia, the Middle East and North America as end-markets improved compared with the same period of 2020 and the absence of a 2020 product performance matter at one of our HVAC joint ventures. These increases were partially offset by the reduction in earnings resulting from the sale of our investment in Beijer REF AB ("Beijer") in 2020.

[0001783180-22-000010:mdna:42]
Other income (expense), net primarily includes the impact of gains and losses related to the sale of interests in our equity method investments, foreign currency gains and losses on transactions that are denominated in a currency other than an entity's functional currency and hedging-related activities. The twelve months ended December 31, 2020 included a $1.1 billion gain on sale of our investment in Beijer. The gain was partially offset by a $71 million other-than-temporary impairment charge on a minority-owned joint venture, an $11 million charge resulting from a litigation matter and a $12 million unfavorable impact for a change in the estimate of certain long-term liabilities. In addition, higher gains on hedging activities were partially offset by deferred compensation costs in the current period.

[0001783180-22-000010:mdna:43]
35

[0001783180-22-000010:mdna:44]
Non-Operating Income (Expense), net

[0001783180-22-000010:mdna:45]
For the year ended December 31, 2021, Non-operating income (expense), net was $245 million, a 7% increase compared with the same period of 2020. The components were as follows:

[0001783180-22-000010:mdna:46]
|  | For the Year Ended December 31, |  |
| (In millions) | 2021 |  | 2020 |  |
| Non-service pension benefit | $ | 61 |  |  | $ | 60 |  |  |
| Interest expense | (319) |  |  | (298) |  |  |
| Interest income | 13 |  |  | 10 |  |  |
| Interest (expense) income, net | (306) |  |  | (288) |  |  |
| Non-operating income (expense), net | $ | (245) |  |  | $ | (228) |  |  |

[0001783180-22-000010:mdna:47]
Non-operating income (expense), net includes the results from activities other than normal business operations such as interest expense, interest income and the non-service components of pension and post-retirement obligations. Interest expense is affected by the amount of debt outstanding and the interest rates on that debt. For the year ended December 31, 2021, interest expense was $319 million, a 7% increase compared with the same period of 2020. In connection with the Separation and the Distribution, we issued $11.0 billion of long-term debt in February 2020. As a result, interest expense for the year ended December 31, 2020 only included interest expense incurred on such debt after the issuance date. In addition, we issued $750 million of 2.70% long-term notes in June 2020. During the year ended December 31, 2021, we incurred a make-whole premium of $17 million and write-off of $2 million of unamortized deferred financing costs as a result of the redemption of our $500 million 1.923% Notes originally due in February 2023.

[0001783180-22-000010:mdna:48]
Income Taxes

[0001783180-22-000010:mdna:49]
|  |  | 2021 |  | 2020 |  |  |
| Effective tax rate |  | 29.1 | % |  | 29.7 | % |  |  |

[0001783180-22-000010:mdna:50]
The effective tax rate for the year ended December 31, 2021 includes a net tax charge of $157 million primarily relating to the re-organization and disentanglement of certain Chubb subsidiaries executed in advance of the planned divestiture of Chubb, a $43 million deferred tax charge as a result of the tax rate increase from 19% to 25% in the United Kingdom, partially offset by a favorable tax adjustment of $70 million due to foreign tax credits generated and expected to be utilized in the current year and $21 million resulting from the re-organization of a German subsidiary.

[0001783180-22-000010:mdna:51]
The effective tax rate for the year ended December 31, 2020 reflects a $51 million charge related to a valuation allowance recorded against a United Kingdom tax loss and credit carry forward and a charge of $46 million resulting from our decision to no longer permanently reinvest certain pre-2018 unremitted non-U.S. earnings.

[0001783180-22-000010:mdna:52]
Segment Review

[0001783180-22-000010:mdna:53]
We have three operating segments:

[0001783180-22-000010:mdna:54]
•The HVAC segment provides products, controls, services and solutions to meet the heating, cooling and ventilation needs of residential and commercial customers while enhancing building performance, health, energy efficiency and sustainability.

[0001783180-22-000010:mdna:55]
•The Refrigeration segment includes transport refrigeration and monitoring products, services and digital solutions for trucks, trailers, shipping containers, intermodal applications, food retail and warehouse cooling, as well as commercial refrigeration products.

[0001783180-22-000010:mdna:56]
•The Fire & Security segment provides a wide range of residential, commercial and industrial technologies designed to help protect people and property.

[0001783180-22-000010:mdna:57]
We determine our segments based on how our Chief Executive Officer, who is the Chief Operating Decision Maker ("CODM"), allocates resources, assesses performance and makes operational decisions. The CODM allocates resources and evaluates the financial performance of each of our segments based on Net sales and Operating profit. Adjustments to reconcile segment reporting to the consolidated results are included in Note 21 - Segment Financial Data.

[0001783180-22-000010:mdna:58]
Summary performance for each of our segments is as follows:

[0001783180-22-000010:mdna:59]
|  | Net Sales |  | Operating Profit |  | Operating Margin |
| (In millions) | 2021 |  | 2020 |  |  |  | 2021 |  | 2020 |  |  |  | 2021 |  | 2020 |  |  |
| HVAC | $ | 11,390 |  |  | $ | 9,478 |  |  |  |  | $ | 1,738 |  |  | $ | 2,462 |  |  |  |  | 15.3 | % |  | 26.0 | % |  |  |
| Refrigeration | 4,127 |  |  | 3,333 |  |  |  |  | 476 |  |  | 357 |  |  |  |  | 11.5 | % |  | 10.7 | % |  |  |
| Fire & Security | 5,515 |  |  | 4,985 |  |  |  |  | 662 |  |  | 584 |  |  |  |  | 12.0 | % |  | 11.7 | % |  |  |
| Total segment | $ | 21,032 |  |  | $ | 17,796 |  |  |  |  | $ | 2,876 |  |  | $ | 3,403 |  |  |  |  | 13.7 | % |  | 19.1 | % |  |  |

[0001783180-22-000010:mdna:60]
HVAC Segment

[0001783180-22-000010:mdna:61]
For the year ended December 31, 2021, Net sales in our HVAC segment was $11.4 billion, a 20% increase compared with the same period of 2020. The components of the year-over-year change were as follows:

[0001783180-22-000010:mdna:62]
|  | Net sales |
| Organic / Operational | 17 | % |
| Foreign currency translation | 1 | % |
| Acquisitions and divestitures, net | 2 | % |
| Total % change | 20 | % |

[0001783180-22-000010:mdna:63]
The organic increase in Net sales of 17% was driven by improved results across each of our HVAC segment's businesses. Increased sales in our North America residential and light commercial business (22%) were driven by new construction, the demand for our products by the ongoing stay-at-home workforce, higher distributor stocking levels and pricing improvements. Increased sales in our Commercial HVAC business (11%) benefited from the gradual improvement in the global economic environment as our end-markets continue to improve from the prior year impacts of the COVID-19 pandemic. Volume growth in Europe and Asia were the primary drivers of improved results during the period. Results for 2021 reflected a significant rebound in demand after initial weakness during the first half of 2020 due to the COVID-19 pandemic and current demand remains strong. However, supply chain and logistic constraints continue to be challenging, negatively impacting our sales and results of operations.

[0001783180-22-000010:mdna:64]
On June 1, 2021, the Commercial HVAC business completed the acquisition of Giwee. Giwee is a China-based manufacturer offering a portfolio of HVAC products including variable refrigerant flow, modular chillers and light commercial air conditioners. The results of Giwee have been included in our Consolidated Financial Statements since the date of acquisition. The transaction added 2% to Net sales for the year ended December 31, 2021. See Note 19 - Acquisitions in the accompanying Notes to the Consolidated Financial Statements in this Annual Report on Form 10-K for additional information.

[0001783180-22-000010:mdna:65]
For the year ended December 31, 2021, Operating profit in our HVAC segment was $1.7 billion, a 29% decrease compared with the same period of 2020. The components of the year-over-year change were as follows:

[0001783180-22-000010:mdna:66]
|  | Operating profit |
| Organic / Operational | 15 | % |
| Foreign currency translation | 1 | % |
| Acquisitions and divestitures, net | (2) | % |
| Restructuring | (1) | % |
| Other | (42) | % |
| Total % change | (29) | % |

[0001783180-22-000010:mdna:67]
37

[0001783180-22-000010:mdna:68]
The operational profit increase of 15% was primarily attributable to higher sales volumes and higher earnings from equity method investments compared with the same period of 2020. In addition, productivity initiatives and favorable product mix further contributed to the segment's results. Pricing improvements offset higher costs for commodities and components used in our products as well as higher freight costs experienced during the year. Higher selling, general and administrative costs and research and development impacted operational profit as our businesses return to normal spending levels as compared with the same period of 2020.

[0001783180-22-000010:mdna:69]
The decrease in Other of 42% primarily reflects the absence of a $1.1 billion gain on the sale of our investment in Beijer in the prior year. In addition, the amounts reported in Other reflect the absence of a prior period non-cash, other-than-temporary impairment charge of $71 million on a minority-owned joint venture investment due to a reduction in sales and earnings that were driven by a deterioration in the oil and gas industry (the joint venture's primary market) and the impact of the COVID-19 pandemic.

[0001783180-22-000010:mdna:70]
Refrigeration Segment

[0001783180-22-000010:mdna:71]
For the year ended December 31, 2021, Net sales in our Refrigeration segment was $4.1 billion, a 24% increase compared with the same period of 2020. The components of the year-over-year change were as follows:

[0001783180-22-000010:mdna:72]
|  | Net sales |
| Organic / Operational | 21 | % |
| Foreign currency translation | 3 | % |
| Total % change | 24 | % |

[0001783180-22-000010:mdna:73]
The organic increase in Net sales of 21% was driven by improved results across each of our Refrigeration segment's businesses. Transport refrigeration sales (28%) benefited from the continued recovery associated with the cyclical decline that began in late 2019 as well as a rebound in the demand for global transportation and COVID-19 vaccine-related cargo monitoring products. Commercial refrigeration sales (9%) also increased due to a rebound in demand. Results for 2021 reflected a significant rebound in demand after initial weakness during the first half of 2020 due to the COVID-19 pandemic and current demand remains strong. However, supply chain and logistic constraints continue to be challenging, negatively impacting our sales and results of operations.

[0001783180-22-000010:mdna:74]
For the year ended December 31, 2021, Operating profit in our Refrigeration segment was $476 million, a 33% increase compared with the same period of 2020. The components of the year-over-year change were as follows:

[0001783180-22-000010:mdna:75]
|  | Operating profit |
| Organic / Operational | 32 | % |
| Foreign currency translation | 7 | % |
| Restructuring | (4) | % |
| Other | (2) | % |
| Total % change | 33 | % |

[0001783180-22-000010:mdna:76]
The increase in operational profit of 32% was primarily attributed to higher sales volumes compared with the same period of 2020, which was heavily impacted by the COVID-19 pandemic. In addition, pricing improvements also contributed to the increase. These increases were partially offset by higher costs for commodities and components used in our products and higher freight costs. Higher selling, general and administrative costs and research and development activities further impacted operational profit as our businesses return to normal spending levels compared with the same period of 2020 in addition to incremental investments in product development and expanding our sales force.

[0001783180-22-000010:mdna:77]
Fire & Security Segment

[0001783180-22-000010:mdna:78]
For the year ended December 31, 2021, Net sales in our Fire & Security segment was $5.5 billion, an 11% increase compared with the same period of 2020. The components of the year-over-year change were as follows:

[0001783180-22-000010:mdna:79]
|  | Net sales |  |  |
| Organic / Operational | 7 | % |  |  |
| Foreign currency translation | 4 | % |  |  |
| Total % change | 11 | % |  |  |

[0001783180-22-000010:mdna:80]
The organic increase in Net sales of 7% was driven by improved results across each of our Fire & Security segment's businesses. Field service sales (6%) benefited from improved end-markets in regions that were previously impacted by COVID-19, including Europe and Asia. An increase in product sales (8%) was primarily driven by improvements in the Americas, Asia and Europe, which were impacted by shutdowns related to COVID-19 in the prior year. Results for 2021 reflected a significant rebound in demand after initial weakness during the first half of 2020 due to the COVID-19 pandemic and current demand remains strong. However, supply chain and logistic constraints continue to be challenging, negatively impacting our sales and results of operations.

[0001783180-22-000010:mdna:81]
For the year ended December 31, 2021, Operating profit in our Fire & Security segment was $662 million, a 13% increase compared with the same period of 2020. The components of the year-over-year change were as follows:

[0001783180-22-000010:mdna:82]
|  |  |  | Operating profit |
| Organic / Operational |  |  | 10 | % |
| Foreign currency translation |  |  | 3 | % |
| Other |  |  | — | % |
| Total % change |  |  | 13 | % |

[0001783180-22-000010:mdna:83]
The operational profit increase of 10% was primarily attributable to higher sales volumes, pricing improvements and favorable mix compared with the same period of 2020, which was heavily impacted by the COVID-19 pandemic. These operational increases were partially offset by higher costs for commodities and components used in our products and higher freight. In addition, higher selling, general and administrative costs and research and development further impacted operational profit as our businesses return to normal spending levels as compared with the same period of 2020 as well as continued investment in selling and engineering.

[0001783180-22-000010:mdna:84]
Other activity recorded in Operating profit includes transaction costs associated with the planned divestiture of our Chubb business and the absence of a favorable adjustment related to a product recall matter in the prior year, offset by lower depreciation and amortization, which was ceased on Chubb's assets that were held for sale in accordance with ASC 360, Property, Plant and Equipment ("ASC 360").

[0001783180-22-000010:mdna:85]
LIQUIDITY AND FINANCIAL CONDITION

[0001783180-22-000010:mdna:86]
We assess liquidity in terms of our ability to generate adequate amounts of cash necessary to fund our current and future cash requirements to support our business and strategic initiatives. In doing so, we review and analyze our cash on hand, working capital, debt service requirements and capital expenditures. We rely on operating cash flows as our primary source of liquidity. In addition, we have access to other sources of capital to finance our strategic initiatives and fund growth.

[0001783180-22-000010:mdna:87]
We manage our worldwide cash requirements by reviewing available funds and the cost effectiveness with which those funds can be accessed if held by foreign subsidiaries. As of December 31, 2021, we had cash and cash equivalents of approximately $3.0 billion, of which approximately 38% was held by Carrier’s foreign subsidiaries. On occasion, we are required to maintain cash deposits in connection with contractual obligations related to acquisitions or divestitures or other legal obligations. As of December 31, 2021 and 2020, the amount of such restricted cash included in Other current assets on the accompanying Consolidated Balance Sheet was approximately $39 million and $4 million, respectively.

[0001783180-22-000010:mdna:88]
39

[0001783180-22-000010:mdna:89]
We maintain a $2.0 billion unsecured, unsubordinated commercial paper program which we can use for general corporate purposes, including the funding of working capital and potential acquisitions. As of December 31, 2021, there were no borrowings outstanding under the commercial paper program.

[0001783180-22-000010:mdna:90]
We maintain a $2.0 billion revolving credit agreement with various banks that matures on April 3, 2025, as amended (the "Revolving Credit Facility"), which supports our commercial paper borrowing program and cash requirements. This Revolving Credit Facility has a commitment fee of 0.125% that is charged on the unused commitments. Borrowings under the Revolving Credit Facility are available in U.S. Dollars, Euros and Pounds Sterling. Pounds Sterling bears interest at a variable interest rate based on the daily simple Sterling Overnight Index Average ("SONIA") plus 0.0326%, Euros bear interest at the Euro Interbank Offered Rate (“EURIBOR”) and U.S. Dollar bears interest at LIBOR, in each case, plus a ratings-based margin, which was 125 basis points as of December 31, 2021. As of December 31, 2021, there were no borrowings on the Revolving Credit Facility.

[0001783180-22-000010:mdna:91]
We believe that our available cash and operating cash flows will be sufficient to meet our future operating cash needs. Our committed credit facilities and access to the debt and equity markets provide additional sources of short-term and long-term capital to fund current operations, dividends, share repurchases, debt maturities and future investment opportunities. Although we believe that the arrangements currently in place permit us to finance our operations on acceptable terms and conditions, our access to and the availability of financing on acceptable terms and conditions in the future will be impacted by many factors, including: (1) our credit ratings or absence of credit ratings; (2) the liquidity of the overall capital markets; and (3) the state of the economy, including the impact of the COVID-19 pandemic and inflation. There can be no assurance that we will be able to obtain additional financing on terms favorable to us, if at all.

[0001783180-22-000010:mdna:92]
The Revolving Credit Facility and the indentures for our long-term notes contain affirmative and negative covenants customary for financings of this type, that among other things, limit Carrier and our subsidiaries' ability to incur additional liens, to make certain fundamental changes and to enter into sale and leaseback transactions. On June 2, 2020, we entered into an amendment of the Revolving Credit Facility, under which certain terms of the facility were amended for a period beginning on June 2, 2020 and ending on December 30, 2021 (the "Covenant Modification"). We terminated the Covenant Modification effective as of August 27, 2021 in accordance with procedures for termination set forth in the Revolving Credit Facility, which returned the consolidated leverage ratio to the limit in effect prior to the Covenant Modification. As of December 31, 2021, we were compliant with all covenants under the agreements governing our outstanding indebtedness.

[0001783180-22-000010:mdna:93]
Financing for operational and strategic requirements, not satisfied by operating cash flows, is subject to the availability of external funds through short-term and long-term credit markets. The access to and cost of financing is dependent upon, among other factors, our credit ratings. The following table presents our credit ratings and outlook as of December 31, 2021:

[0001783180-22-000010:mdna:94]
| Rating Agency | Long-term Rating (1) | Short-term Rating |  | Outlook (2) |
| S&P | BBB | A2 |  | Stable |
| Moody's | Baa3 | P3 |  | Stable |
| Fitch Ratings | BBB- | F3 |  | Stable |

[0001783180-22-000010:mdna:95]
(1) The long-term rating for S&P was affirmed on May 14, 2021, and for Moody's on June 16, 2020. Fitch Ratings' long-term rating was issued on June 3, 2021.

[0001783180-22-000010:mdna:96]
(2) S&P revised its outlook to stable from negative on May 14, 2021.

[0001783180-22-000010:mdna:97]
The following table contains several key measures of our financial condition and liquidity:

[0001783180-22-000010:mdna:98]
|  |  | As of December 31, |
| (In millions) |  | 2021 |  | 2020 |
| Cash and cash equivalents |  | $ | 2,987 |  |  | $ | 3,115 |  |
| Total debt |  | $ | 9,696 |  |  | $ | 10,227 |  |
| Net debt (total debt less cash and cash equivalents) |  | $ | 6,709 |  |  | $ | 7,112 |  |
| Total equity |  | $ | 7,094 |  |  | $ | 6,578 |  |
| Total capitalization (total debt plus total equity) |  | $ | 16,790 |  |  | $ | 16,805 |  |
| Net capitalization (total debt plus total equity less cash and cash equivalents) |  | $ | 13,803 |  |  | $ | 13,690 |  |
| Total debt to total capitalization |  | 58 | % |  | 61 | % |
| Net debt to net capitalization |  | 49 | % |  | 52 | % |

[0001783180-22-000010:mdna:99]
Borrowings and Lines of Credit

[0001783180-22-000010:mdna:100]
Our short-term obligations primarily consist of current maturities of long-term debt. Our long-term obligations primarily consist of long-term notes with maturity dates ranging between 2025 and 2050. Interest payments related to long-term notes are expected to approximate $273 million per year, reflecting an approximate weighted-average interest rate of 2.80%. Any borrowings from the Revolving Credit Facility are subject to variable interest rates. See Note 7 - Borrowings and Lines of Credit in the accompanying Notes to the Consolidated Financial Statements in this Annual Report on Form 10-K for additional information.

[0001783180-22-000010:mdna:101]
Scheduled maturities of long-term debt, excluding amortization of discount, are as follows:

[0001783180-22-000010:mdna:102]
| (In millions) |  |  |  |
| 2022 |  | $ | 183 |  |  |
| 2023 |  | $ | 74 |  |  |
| 2024 |  | $ | 2 |  |  |
| 2025 |  | $ | 2,002 |  |  |
| 2026 |  | $ | 2 |  |  |
| Thereafter |  | $ | 7,504 |  |  |

[0001783180-22-000010:mdna:103]
Share Repurchase Program

[0001783180-22-000010:mdna:104]
During 2021, our Board of Directors approved a stock repurchase program authorizing the repurchase of up to $2.1 billion of Carrier’s outstanding common stock. The repurchase program allows us to repurchase shares from time to time, subject to market conditions and at our discretion in the open market or through one or more other public or private transactions and subject to compliance with our obligations under the TMA and our Revolving Credit Facility. During the year ended December 31, 2021, we repurchased 10.4 million shares of our common stock for an aggregate purchase price of $529 million, which are held in Treasury stock as of December 31, 2021 in the accompanying Consolidated Balance Sheet. On January 4, 2022, we entered into an accelerated share repurchase agreement to repurchase $500 million of the Company's common stock to be completed in the first quarter of 2022.

[0001783180-22-000010:mdna:105]
Dividends

[0001783180-22-000010:mdna:106]
We paid dividends on our common stock of $0.48 per share during the year ended December 31, 2021, totaling $417 million. On December 8, 2021, the Board of Directors declared a dividend of $0.15 per share of common stock payable on February 10, 2022 to shareowners of record at the close of business on December 23, 2021.

[0001783180-22-000010:mdna:107]
Acquisitions

[0001783180-22-000010:mdna:108]
During the year ended December 31, 2021, we acquired consolidated and minority-owned businesses, including Giwee. The aggregate cash paid for acquisitions, net of cash acquired, totaled $366 million and was funded through cash on hand. See Note 19 - Acquisitions in the accompanying Notes to the Consolidated Financial Statements in this Annual Report on Form 10-K for additional information.

[0001783180-22-000010:mdna:109]
Discussion of Cash Flows

[0001783180-22-000010:mdna:110]
|  |  | For the Years Ended December 31, |
| (In millions) |  | 2021 |  | 2020 |  |  |
| Cash provided by (used in): |  |  |  |  |  |  |
| Operating activities |  | $ | 2,237 |  |  | $ | 1,692 |  |  |  |
| Investing activities |  | (692) |  |  | 1,106 |  |  |  |
| Financing activities |  | (1,562) |  |  | (681) |  |  |  |
| Effect of foreign exchange rate changes on cash and cash equivalents |  | (16) |  |  | 45 |  |  |  |
| Net increase (decrease) in cash and cash equivalents and restricted cash |  | $ | (33) |  |  | $ | 2,162 |  |  |  |

[0001783180-22-000010:mdna:111]
Cash flows from operating activities primarily represent inflows and outflows associated with our operations. Primary activities include net income from operations adjusted for non-cash transactions, working capital changes and changes in other assets and liabilities. We define working capital as the assets and liabilities, other than cash, generated through our primary operating activities. The year-over-year increase in net cash provided by operating activities was primarily driven by income generated by our operations after adjusting for non-cash transactions. In addition, lower working capital balances during the current period further added to the increase. Higher inventory levels, driven by continued strong demand and an increase of safety stock due to supply chain constraints were more than offset by higher outstanding accounts payable balances.

[0001783180-22-000010:mdna:112]
Cash flows from investing activities primarily represent inflows and outflows associated with long-term assets. Primary activities include capital expenditures, acquisitions and divestitures. During the year ended December 31, 2021, net cash used in investing activities was $692 million. The primary driver of the outflow related to the acquisition of several businesses and a minority-owned business, which totaled $366 million, net of cash acquired and $344 million of capital expenditures. During the year ended December 31, 2020, net cash provided by investing activities was $1.1 billion with the primary drivers of the inflow relating to the proceeds received from the sale of our investment in Beijer and the settlement of derivative contracts of $40 million. These inflows were partially offset by capital expenditures of $312 million.

[0001783180-22-000010:mdna:113]
Cash flows from financing activities primarily represent inflows and outflows associated with equity or borrowings. Primary activities include debt transactions, paying dividends to shareowners and the repurchase of our common stock. During the year ended December 31, 2021 net cash used in financing activities was $1.6 billion. The primary drivers of the outflow resulted from the repurchase of $527 million of our common stock, the redemption of our 1.923% Notes of $500 million and the payment of $417 million in dividends to our common shareowners. During the year ended December 31, 2020, net cash used by financing activities was $681 million with the primary drivers of the decrease relating to the prepayment of the Term Loan Credit Facility of $1.75 billion. This outflow was partially offset by the issuance of $750 million of long-term debt and a $590 million cash contribution from UTC in connection with the Separation.

[0001783180-22-000010:mdna:114]
Summary of Other Sources and Uses of Cash

[0001783180-22-000010:mdna:115]
We continue to actively manage and strengthen our business and product portfolio to meet the current and future needs of our customers. This is accomplished through research and development activities with a focus on new product development and new technology innovation as well as sustaining activities with a focus on improving existing products and reducing production costs. We also pursue potential acquisitions to complement existing products and services to enhance our product portfolio. In addition, we routinely conduct discussions, evaluate targets and enter into agreements regarding possible acquisitions, divestitures, joint ventures and equity investments to manage our business portfolio. As a result, we acquired consolidated and minority-owned businesses during the year ended December 31, 2021. The aggregate cash paid for acquisitions, net of cash acquired, totaled $366 million and was funded through cash on hand. In addition, on January 3, 2022, we completed the sale of Chubb to APi pursuant to a stock purchase agreement and received net proceeds of approximately $2.6 billion, subject to customary working capital and other adjustments as provided in the Chubb Sale Agreement.

[0001783180-22-000010:mdna:116]
Rapid changes in legislation, regulations and government policies, including with respect to regulations intended to combat climate change, affect our operations and business in the countries, regions and localities in which we operate and sell our products. We are committed to comply with these regulations and to environmental stewardship. As a result, we have set goals to invest over $2 billion by 2030 to develop healthy, safe, sustainable and intelligent buildings and cold chain solutions that incorporate sustainable design principles and reduce lifecycle impacts. In addition, to reach our goal to achieve carbon neutrality in our operations by 2030, we expect to incur capital expenditures for climate-related projects including upgrading our facilities, equipment and controls to optimize energy efficiency, transition our energy consumption from a dependency on fossil fuels to renewable energy and expanding the electrification of our fleet vehicles. See section entitled Environmental Goals under the headings "Other Matters Relating to Our Business as a Whole" for additional information.

[0001783180-22-000010:mdna:117]
We also have obligations related to environmental and asbestos matters, pension and post-retirement benefits and taxes. See Note 10 - Employee Benefit Plans, Note 17 - Income Taxes, and Note 23 - Commitments and Contingent Liabilities in the accompanying Notes to the Consolidated Financial Statements in this Annual Report on Form 10-K for additional information.

[0001783180-22-000010:mdna:118]
CRITICAL ACCOUNTING ESTIMATES

[0001783180-22-000010:mdna:119]
Our financial statements are prepared in accordance with accounting principles generally accepted in the United States. The preparation of financial statements in conformity with those accounting principles requires management to use judgement in making estimates and assumptions based on the relevant information available at the end of each period. These estimates and assumptions have a significant effect on reported amounts of assets, liabilities, sales and expenses as well as the disclosure of

[0001783180-22-000010:mdna:120]
contingent assets and liabilities because they result primarily from the need to make estimates and assumptions on matters that are inherently uncertain. Actual results could differ from management's estimates.

[0001783180-22-000010:mdna:121]
Goodwill and Indefinite-Lived Intangible Assets

[0001783180-22-000010:mdna:122]
In accordance with the Financial Accounting Standards Board ("FASB") Accounting Standards Codification ("ASC") 350, Intangibles - Goodwill and Other ("ASC 350"), goodwill and other indefinite-lived intangible assets are tested and reviewed annually for impairment or whenever there is a material change in events or circumstances that indicate that the fair value of the asset is more likely than not less than the carrying amount of the asset. We test our reporting units and indefinite-lived intangible assets for impairment annually as of the first day of our third quarter, or more frequently if events or circumstances occur.

[0001783180-22-000010:mdna:123]
ASC 350 provides entities with an option to perform a qualitative assessment (commonly referred to as “step zero”) to determine whether a quantitative analysis for impairment is necessary. In performing step zero for our impairment test, we are required to make assumptions and judgments, including but not limited to the following: the evaluation of macroeconomic conditions as related to our business, industry and market trends, and the overall future financial performance of our reporting units and future opportunities in the markets in which they operate. If impairment indicators are present after performing step zero, we would perform a quantitative impairment analysis to estimate fair value.

[0001783180-22-000010:mdna:124]
For our 2021 impairment test, we elected to perform a qualitative step zero assessment for goodwill and indefinite-lived intangible assets. This qualitative assessment included the review of certain macroeconomic factors and entity-specific qualitative factors to determine if it was more likely than not that the fair values of our reporting units and indefinite-lived intangible assets were below carrying value. We considered macroeconomic factors including global economic growth, general macroeconomic trends for the markets in which our reporting units operate and where the intangible assets are utilized and the forecasted growth of the global industrial products industry. In addition to these macroeconomic factors, among other things, we considered the reporting units’ current results and forecasts, changes in the nature of each business, any significant legal, regulatory, contractual, political or other business climate factors, changes in the industry and competitive environment, changes in the composition or carrying amount of net assets and any intention to sell or dispose of a reporting unit or cease the use of an indefinite-lived intangible assets. Based upon our qualitative analysis, we determined that our goodwill and indefinite-lived intangible assets were not impaired.

[0001783180-22-000010:mdna:125]
Revenue Recognition from Contracts with Customers

[0001783180-22-000010:mdna:126]
Revenue is recognized when control of a good or service promised in a contract (i.e., performance obligation) is transferred to a customer. Control is obtained when a customer has the ability to direct the use of and obtain substantially all of the remaining benefits from that good or service. A significant portion of our performance obligations are recognized at a point-in-time when control of the product transfers to the customer, which is generally the time of shipment. The remaining portion of our performance obligations are recognized over time as the customer simultaneously obtains control as we perform work under a contract, or if the product being produced for the customer has no alternative use and we have a contractual right to payment.

[0001783180-22-000010:mdna:127]
A performance obligation is a distinct good, service or a bundle of goods and services promised in a contract. Some of our contracts with customers contain a single performance obligation, while others contain multiple performance obligations most commonly when a contract spans multiple phases of a product life-cycle such as production, installation, maintenance and support. We identify performance obligations at the inception of a contract and allocate the transaction price to each distinct performance obligation. Revenue is recognized when or as the performance obligation is satisfied. When there are multiple performance obligations within a contract, we allocate the transaction price to each performance obligation based on its relative stand-alone selling price.

[0001783180-22-000010:mdna:128]
We primarily generate revenue from the sale of products to customers and recognize revenue at a point in time when control transfers to the customer. Transfer of control is generally based on the shipping terms of the contract. In addition, we recognize revenue on an over-time basis on installation and service contracts. For over-time performance obligations requiring the installation of equipment, revenue is recognized using costs incurred to date relative to total estimated costs at completion to measure progress. Incurred costs represent work performed, which correspond with and best depict transfer of control to the customer. Contract costs include direct costs such as labor, materials and subcontractors’ costs and, where applicable, indirect costs.

[0001783180-22-000010:mdna:129]
The transaction price allocated to performance obligations reflects our expectations about the consideration we will be entitled to receive from a customer. We include variable consideration in the estimated transaction price when there is a basis to reasonably estimate the amount and when it is probable that a significant reversal of revenue recognized would not occur when the uncertainty associated with variable consideration is subsequently resolved. In addition, we customarily offer our customers incentives to purchase products to ensure an adequate supply of our products in distribution channels. The principal incentive programs provide reimbursements to distributors for offering promotional pricing for products. We account for estimated incentive payments as a reduction in sales at the time a sale is recognized.

[0001783180-22-000010:mdna:130]
Income Taxes

[0001783180-22-000010:mdna:131]
We account for income taxes in accordance with ASC 740: Income Taxes ("ASC 740"). Deferred tax assets and liabilities are determined based on temporary differences between financial reporting and tax bases of assets and liabilities, applying enacted tax rates expected to be in effect for the year in which the differences are expected to reverse. We recognize future tax benefits to the extent that realizing these benefits is considered in our judgment to be more likely than not. For those jurisdictions where the expiration date of tax carryforwards or the projected operating results indicate that realization is not likely, a valuation allowance is provided. We review the realizability of our deferred tax asset valuation allowances on a quarterly basis, or whenever events or changes in circumstances indicate that a review is required and will adjust our estimate if significant events so dictate. To the extent that the ultimate results differ from our original or adjusted estimates, the effect will be recorded in the provision for income taxes in the period that the matter is finally resolved.

[0001783180-22-000010:mdna:132]
In the ordinary course of business, there is inherent uncertainty in quantifying our income tax positions. We assess our income tax positions and record tax benefits for all years subject to examination based upon management’s evaluation of the facts, circumstances and information available at the reporting date. For those tax positions where it is more likely than not that a tax benefit will be sustained, we have recorded the largest amount of tax benefit with a greater than 50% likelihood of being realized upon ultimate settlement with a taxing authority that has full knowledge of all relevant information. For those income tax positions where it is not more likely than not that a tax benefit will be sustained, no tax benefit has been recognized in the Consolidated Financial Statements.

[0001783180-22-000010:mdna:133]
Employee Benefit Plans

[0001783180-22-000010:mdna:134]
We provide a range of benefit plans to eligible current and former employees. We account for our benefits plans in accordance with ASC 715: Compensation – Retirement Benefits ("ASC 715"), which requires balance sheet recognition of the overfunded or underfunded status of pension plans. The determination of the amounts associated with these benefits is performed by actuaries and dependent on various actuarial assumptions including discount rates, expected return on plan assets, compensation increases, mortality and health care cost trends. Actual results may differ from the actuarial assumptions and are generally accumulated into Accumulated other comprehensive income (loss) and amortized into Net income from operations over future periods. We review our actuarial assumptions at each measurement date and make modifications to the assumptions based on current rates and trends, if appropriate.

[0001783180-22-000010:mdna:135]
A change in any of these assumptions would have an effect on net periodic pension and post-retirement benefit costs reported in the Consolidated Financial Statements. The following table summarizes the sensitivity of our pension plan liabilities and net periodic cost to a 25 basis point change in the discount rates for benefit obligations, interest cost and service cost as of December 31, 2021:

[0001783180-22-000010:mdna:136]
| (In millions) |  | Increase in Discount Rate of 25 bps |  | Decrease in Discount Rate of 25 bps |
| Projected benefit obligation |  | $ | (32) |  |  | $ | 35 |  |
| Net periodic pension (benefit) cost |  | $ | (2) |  |  | $ | 2 |  |

[0001783180-22-000010:mdna:137]
Net periodic pension (benefit) cost is also sensitive to changes in the expected return on plan assets. An increase or decrease of 25 basis points in the expected return on plan assets would have decreased or increased 2021 pension expense by approximately $1 million. See Note 10 – Employee Benefit Plans in the accompanying Notes to the Consolidated Financial Statements in this Annual Report on Form 10-K for additional information.

[0001783180-22-000010:mdna:138]
Contingent Liabilities

[0001783180-22-000010:mdna:139]
We are involved in various litigation, claims and administrative proceedings, including those related to environmental and legal matters (including asbestos). In accordance with ASC 450, Contingencies ("ASC 450"), we record accruals for loss contingencies when it is probable that a liability will be incurred and the amount of the loss can be reasonably estimated. These accruals are generally based upon a range of possible outcomes. If no amount within the range is a better estimate than any other, we accrue the minimum amount. In addition, these estimates are reviewed periodically and adjusted to reflect additional information when it becomes available. We are unable to predict the final outcome of these matters based on the information currently available. However, we do not believe that the resolution of any of these matters will have a material adverse effect upon our competitive position, results of operations, cash flows or financial condition.

[0001783180-22-000010:mdna:140]
As described in Note 23 – Commitments and Contingent Liabilities in the accompanying Notes to the Consolidated Financial Statements in this Annual Report on Form 10-K, contractual, regulatory and other matters, including asbestos claims, may arise in the ordinary course of business that subject us to claims or litigation. We have recorded reserves in the consolidated financial statements related to these matters, which are developed using input derived from actuarial estimates and historical and anticipated experience depending on the nature of the reserve, and in certain instances in consultation with legal counsel, internal and external consultants and engineers. Subject to the uncertainties inherent in estimating future costs for these types of liabilities, we believe our estimated reserves are reasonable and do not believe the final determination of the liabilities with respect to these matters would have a material adverse effect upon our competitive position, results of operations, cash flows or financial condition. See the "Risk Factors" section in this Annual Report on Form 10-K for additional information.

[0001783180-22-000010:mdna:141]
Recent Accounting Pronouncements

[0001783180-22-000010:mdna:142]
See Note 3 – Summary of Significant Accounting Policies in the accompanying Notes to the Consolidated Financial Statements in this Annual Report on Form 10-K for a discussion of recent accounting pronouncements and their effect on our financial statements.
