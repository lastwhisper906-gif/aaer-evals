# CARR notes — 0001783180-23-000038


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001783180-23-000038:notes:1]
DESCRIPTION OF THE BUSINESS 
Carrier Global Corporation (the "Company") is the leading global provider of healthy, safe, sustainable and intelligent building and cold chain solutions with a focus on providing differentiated, digitally-enabled lifecycle solutions to its customers. The Company's portfolio includes industry-leading brands such as Carrier, Toshiba, Automated Logic, Carrier Transicold, Kidde, Edwards and LenelS2 that offer innovative heating, ventilating, air conditioning ("HVAC"), refrigeration, fire, security and building automation technologies to help make the world safer and more comfortable. The Company also provides a broad array of related building services, including audit, design, installation, system integration, repair, maintenance and monitoring. The Company's operations are classified into three segments: HVAC, Refrigeration and Fire & Security.

[0001783180-23-000038:notes:2]
In the opinion of management, the accompanying Unaudited Condensed Consolidated Financial Statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission (the "SEC"). The accompanying Unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for 2022 filed with the SEC on February 7, 2023 (the "2022 Form 10-K").


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001783180-23-000038:notes:3]
BASIS OF PRESENTATION
The Unaudited Condensed Consolidated Financial Statements include all accounts of the Company and its wholly-owned and majority-owned subsidiaries in which it has control. Inter-company accounts and transactions have been eliminated. Related party transactions between the Company and its equity method investees have not been eliminated. Non-controlling interest represents a non-controlling investor's interests in the results of subsidiaries that the Company controls and consolidates.

[0001783180-23-000038:notes:4]
[same as prior period, unchanged from 0001783180-22-000056:notes:6]

[0001783180-23-000038:notes:5]
On February 6, 2022, the Company entered into a binding agreement to acquire a majority ownership interest in Toshiba Carrier Corporation (“TCC”), a variable refrigerant flow ("VRF") and light commercial HVAC joint venture between Carrier and Toshiba Corporation. The acquisition was completed on August 1, 2022. As a result, the assets, liabilities and results of operations of TCC are consolidated in the accompanying Unaudited Condensed Consolidated Financial Statements as of the date of acquisition and reported within the Company’s HVAC segment. Upon closing, Toshiba Corporation retained a 5% ownership interest in TCC. See Note 15 – Acquisitions for additional information.

[0001783180-23-000038:notes:6]
[same as prior period, unchanged from 0001783180-22-000056:notes:8]

[0001783180-23-000038:notes:7]
On July 26, 2021, the Company entered into a stock purchase agreement to sell its Chubb Fire and Security business ("Chubb") to APi Group Corporation ("APi"). Chubb, which was reported within the Company’s Fire & Security segment, delivered essential fire safety and security solutions from design and installation to monitoring, service and maintenance across more than 17 countries around the globe. The sale of Chubb was completed on January 3, 2022 (the "Chubb Sale"). See Note 16 - Divestitures for additional information.

[0001783180-23-000038:notes:8]
[same as prior period, unchanged from 0001783180-22-000056:notes:10]

[0001783180-23-000038:notes:9]
On April 3, 2020 (the Distribution Date"), United Technologies Corporation, since renamed Raytheon Technologies Corporation ("UTC"), completed the spin-off of Carrier into an independent, publicly traded company (the "Separation") through a pro-rata distribution (the "Distribution") on a one-for-one basis of all of the outstanding shares of common stock of Carrier to UTC shareowners who held shares of UTC common stock as of the close of business on March 19, 2020, the record date of the Distribution. In connection with the Separation, the Company issued an aggregate principal balance of $11.0 billion of debt and transferred approximately $10.9 billion of cash to UTC on February 27, 2020 and March 27, 2020. On April 1, 2020 and April 2, 2020, the Company received cash contributions totaling $590 million from UTC related to the Separation.

[0001783180-23-000038:notes:10]
[same as prior period, unchanged from 0001783180-22-000056:notes:12]

[0001783180-23-000038:notes:11]
[same as prior period, unchanged from 0001783180-22-000056:notes:13]


## us-gaap:InventoryDisclosureTextBlock

[0001783180-23-000038:notes:12]
[same as prior period, unchanged from 0001783180-22-000056:notes:14]

[0001783180-23-000038:notes:13]
[same as prior period, unchanged from 0001783180-22-000056:notes:15]

[0001783180-23-000038:notes:14]
| (In millions) |  | March 31, 2023 |  | December 31, 2022 |
| Raw materials |  | $ | 881 |  |  | $ | 884 |  |
| Work-in-process |  | 292 |  |  | 230 |  |
| Finished goods |  | 1,630 |  |  | 1,526 |  |
| Inventories, net |  | $ | 2,803 |  |  | $ | 2,640 |  |

[0001783180-23-000038:notes:15]
The Company performs periodic assessments utilizing customer demand, production requirements and historical usage rates to determine the existence of excess and obsolete inventory and records necessary provisions to reduce such inventories to the lower of cost or estimated net realizable value. Raw materials, work-in-process and finished goods are net of valuation reserves of $221 million and $190 million as of March 31, 2023 and December 31, 2022, respectively.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001783180-23-000038:notes:16]
[same as prior period, unchanged from 0001783180-22-000056:notes:18]

[0001783180-23-000038:notes:17]
[same as prior period, unchanged from 0001783180-22-000056:notes:19]

[0001783180-23-000038:notes:18]
| (In millions) |  |  | HVAC |  | Refrigeration |  | Fire & Security |  | Total |
| Balance as of December 31, 2022 |  |  | $ | 6,392 |  |  | $ | 1,197 |  |  | $ | 2,388 |  |  | $ | 9,977 |  |
| Acquisitions / divestitures |  |  | (13) |  |  | (4) |  |  | — |  |  | (17) |  |
| Foreign currency translation |  |  | 16 |  |  | 3 |  |  | 8 |  |  | 27 |  |
| Balance as of March 31, 2023 |  |  | $ | 6,395 |  |  | $ | 1,196 |  |  | $ | 2,396 |  |  | $ | 9,987 |  |

[0001783180-23-000038:notes:19]
Indefinite-lived intangible assets are tested and reviewed annually for impairment on July 1 or whenever there is a material change in events or circumstances that indicates that the fair value of the asset may be less than the carrying amount of the asset. All other intangible assets with finite useful lives are amortized over their estimated useful lives.

[0001783180-23-000038:notes:20]
[same as prior period, unchanged from 0001783180-22-000056:notes:24]

[0001783180-23-000038:notes:21]
|  |  | March 31, 2023 |  | December 31, 2022 |
| (In millions) |  | Gross Amount |  | Accumulated Amortization |  | Net Amount |  | Gross Amount |  | Accumulated Amortization |  | Net Amount |
| Amortized: |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 1,426 |  |  | $ | (734) |  |  | $ | 692 |  |  | $ | 1,431 |  |  | $ | (720) |  |  | $ | 711 |  |
| Patents and trademarks |  | 404 |  |  | (199) |  |  | 205 |  |  | 401 |  |  | (191) |  |  | 210 |  |
| Service portfolios and other |  | 956 |  |  | (630) |  |  | 326 |  |  | 953 |  |  | (595) |  |  | 358 |  |
|  |  | 2,786 |  |  | (1,563) |  |  | 1,223 |  |  | 2,785 |  |  | (1,506) |  |  | 1,279 |  |
| Unamortized: |  |  |  |  |  |  |  |  |  |  |  |  |
| Trademarks and other |  | 64 |  |  | — |  |  | 64 |  |  | 63 |  |  | — |  |  | 63 |  |
| Intangible assets, net |  | $ | 2,850 |  |  | $ | (1,563) |  |  | $ | 1,287 |  |  | $ | 2,848 |  |  | $ | (1,506) |  |  | $ | 1,342 |  |

[0001783180-23-000038:notes:22]
[same as prior period, unchanged from 0001783180-22-000056:notes:26]

[0001783180-23-000038:notes:23]
|  |  | Three Months Ended March 31, |  |  |
| (In millions) |  | 2023 |  | 2022 |  |  |  |  |
| Amortization expense of Intangible assets |  | $ | 64 |  |  | $ | 21 |  |  |  |  |  |


## us-gaap:DebtDisclosureTextBlock

[0001783180-23-000038:notes:24]
BORROWINGS AND LINES OF CREDIT 
Long-term debt consisted of the following:

[0001783180-23-000038:notes:25]
| (In millions) |  |  |  | March 31,2023 |  | December 31,2022 |
| 2.242% Notes due February 15, 2025 |  |  |  | $ | 1,200 |  |  | $ | 1,200 |  |
| 2.493% Notes due February 15, 2027 |  |  |  | 900 |  |  | 900 |  |
| 2.722% Notes due February 15, 2030 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.700% Notes due February 15, 2031 |  |  |  | 750 |  |  | 750 |  |
| 3.377% Notes due April 5, 2040 |  |  |  | 1,500 |  |  | 1,500 |  |
| 3.577% Notes due April 5, 2050 |  |  |  | 2,000 |  |  | 2,000 |  |
| Total long-term notes |  |  |  | 8,350 |  |  | 8,350 |  |
| Japanese Term Loan Facility |  |  |  | 408 |  |  | 404 |  |
| Other debt (including project financing obligations and finance leases) |  |  |  | 152 |  |  | 149 |  |
| Discounts and debt issuance costs |  |  |  | (60) |  |  | (61) |  |
| Total debt |  |  |  | 8,850 |  |  | 8,842 |  |
| Less: current portion of long-term debt |  |  |  | 142 |  |  | 140 |  |
| Long-term debt, net of current portion |  |  |  | $ | 8,708 |  |  | $ | 8,702 |  |

[0001783180-23-000038:notes:26]
Japanese Term Loan Facility

[0001783180-23-000038:notes:27]
On July 15, 2022, the Company entered into a five-year, JPY 54 billion (approximately $400 million) senior unsecured term loan facility with MUFG Bank Ltd., as administrative agent and lender, and certain other lenders (the "Japanese Term Loan Facility"). Borrowings under the Japanese Term Loan Facility bear interest at a rate equal to the Tokyo Term Risk Free Rate plus 0.75%. In addition, the Japanese Term Loan Facility is subject to customary covenants including a covenant to maintain a maximum consolidated leverage ratio. On July 25, 2022, the Company borrowed JPY 54 billion under the Japanese Term Loan Facility and used the proceeds to fund a portion of the TCC acquisition and to pay related fees and expenses.

[0001783180-23-000038:notes:28]
Revolving Credit Facility

[0001783180-23-000038:notes:29]
On February 10, 2020, the Company entered into a revolving credit agreement with various banks permitting aggregate borrowings of up to $2.0 billion pursuant to an unsecured, unsubordinated revolving credit facility that matures on April 3, 2025 (the "Revolving Credit Facility"). The Revolving Credit Facility supports the Company's commercial paper program and cash requirements. A commitment fee of 0.125% is charged on unused commitments. Borrowings under the Revolving Credit Facility are available in U.S. Dollars, Euros and Pounds Sterling. Pounds Sterling borrowings bear interest at a variable rate based on daily simple SONIA plus 0.0326%, Euro borrowings bear interest at EURIBOR rates and U.S. Dollar borrowings bear interest at LIBOR plus a ratings-based margin, which was 125 basis points as of March 31, 2023. As of March 31, 2023, there were no borrowings outstanding under the Revolving Credit Facility.

[0001783180-23-000038:notes:30]
Commercial Paper Program

[0001783180-23-000038:notes:31]
The Company has a $2.0 billion unsecured, unsubordinated commercial paper program, which can be used for general corporate purposes, including the funding of working capital and potential acquisitions. As of March 31, 2023, there were no borrowings outstanding under the commercial paper program.

[0001783180-23-000038:notes:32]
Project Financing Arrangements

[0001783180-23-000038:notes:33]
The Company is involved in long-term construction contracts in which it arranges project financing with certain customers. As a result, the Company issued $5 million and $14 million of debt during the three months ended March 31, 2023 and 2022, respectively. Long-term debt repayments associated with these financing arrangements during the three months ended March 31, 2023 and 2022 were $2 million and $8 million, respectively.

[0001783180-23-000038:notes:34]
Debt Covenants

[0001783180-23-000038:notes:35]
The Revolving Credit Facility, the indenture for the long-term notes and the Japanese Term Loan Facility contain affirmative and negative covenants customary for financings of these types, which, among other things, limit the Company's ability to incur additional liens, to make certain fundamental changes and to enter into sale and leaseback transactions. As of March 31, 2023, the Company was in compliance with the covenants under the agreements governing its outstanding indebtedness.

[0001783180-23-000038:notes:36]
Tender Offers

[0001783180-23-000038:notes:37]
On March 15, 2022, the Company commenced tender offers to purchase up to $1.15 billion ("Aggregate Tender Cap") aggregate principal of the Company's 2.242% Notes due 2025 and 2.493% Notes due 2027 (together, the "Senior Notes"). The tender offers included payment of applicable accrued and unpaid interest up to the settlement date, along with a fixed spread for early repayment. Based on participation, the Company elected to settle the tender offers on March 30, 2022. The aggregate principal amount of Senior Notes validly tendered and accepted was approximately $1.15 billion, which included $800 million of Notes due 2025 and $350 million of Notes due 2027. As a result, the Company recognized a net gain of $33 million and wrote off $5 million of unamortized deferred financing costs within Interest (expense) income, net on the accompanying Unaudited Condensed Consolidated Statement of Operations during the three months ended March 31, 2022.


## us-gaap:FairValueDisclosuresTextBlock

[0001783180-23-000038:notes:38]
[same as prior period, unchanged from 0001783180-22-000056:notes:44]

[0001783180-23-000038:notes:39]
[same as prior period, unchanged from 0001783180-22-000056:notes:45]

[0001783180-23-000038:notes:40]
[same as prior period, unchanged from 0001783180-22-000056:notes:46]

[0001783180-23-000038:notes:41]
[same as prior period, unchanged from 0001783180-22-000056:notes:47]

[0001783180-23-000038:notes:42]
[same as prior period, unchanged from 0001783180-22-000056:notes:48]

[0001783180-23-000038:notes:43]
[same as prior period, unchanged from 0001783180-22-000056:notes:49]

[0001783180-23-000038:notes:44]
[same as prior period, unchanged from 0001783180-22-000056:notes:50]

[0001783180-23-000038:notes:45]
[same as prior period, unchanged from 0001783180-22-000056:notes:51]

[0001783180-23-000038:notes:46]
[same as prior period, unchanged from 0001783180-22-000056:notes:52]

[0001783180-23-000038:notes:47]
| (In millions) |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |
| March 31, 2023 |  |  |  |  |  |  |  |  |
| Derivative assets (1)(3) |  | $ | 20 |  |  | $ | — |  |  | $ | 20 |  |  | $ | — |  |
| Derivative liabilities (2)(3) |  | $ | (71) |  |  | $ | — |  |  | $ | (71) |  |  | $ | — |  |
| December 31, 2022 |  |  |  |  |  |  |  |  |
| Derivative assets (1) (3) |  | $ | 28 |  |  | $ | — |  |  | $ | 28 |  |  | $ | — |  |
| Derivative liabilities (2) (3) |  | $ | (48) |  |  | $ | — |  |  | $ | (48) |  |  | $ | — |  |

[0001783180-23-000038:notes:48]
[same as prior period, unchanged from 0001783180-22-000056:notes:54]

[0001783180-23-000038:notes:49]
[same as prior period, unchanged from 0001783180-22-000056:notes:55]

[0001783180-23-000038:notes:50]
[same as prior period, unchanged from 0001783180-22-000056:notes:56]

[0001783180-23-000038:notes:51]
[same as prior period, unchanged from 0001783180-22-000056:notes:57]

[0001783180-23-000038:notes:52]
|  |  | March 31, 2023 |  | December 31, 2022 |  |
| (In millions) |  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  |
| Total long-term Notes (1) |  | $ | 8,350 |  |  | $ | 7,105 |  |  | $ | 8,350 |  |  | $ | 6,832 |  |  |

[0001783180-23-000038:notes:53]
[same as prior period, unchanged from 0001783180-22-000056:notes:59]

[0001783180-23-000038:notes:54]
The fair value of the Company's long-term debt is measured based on observable market inputs which are considered Level 1 within the fair value hierarchy. The carrying value of cash and cash equivalents, accounts receivable, accounts payable and short-term borrowings approximate fair value due to the short-term nature of these accounts and would be classified as Level 1 in the fair value hierarchy. The Company's financing leases and project financing obligations, included in Long-term debt and 
Current portion of long-term debt on the accompanying Unaudited Condensed Consolidated Balance Sheet, approximate fair value and are classified as Level 3 in the fair value hierarchy.


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0001783180-23-000038:notes:55]
[same as prior period, unchanged from 0001783180-22-000056:notes:61]


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001783180-23-000038:notes:56]
[same as prior period, unchanged from 0001783180-22-000056:notes:62]

[0001783180-23-000038:notes:57]
[same as prior period, unchanged from 0001783180-22-000056:notes:63]

[0001783180-23-000038:notes:58]
|  |  | Three Months Ended March 31, |  |  |
| (In millions) |  | 2023 |  | 2022 |  |  |  |  |
| Defined benefit plans |  | $ | 6 |  |  | $ | 4 |  |  |  |  |  |
| Defined contribution plans |  | $ | 37 |  |  | $ | 38 |  |  |  |  |  |
| Multi-employer pension plans |  | $ | 4 |  |  | $ | 3 |  |  |  |  |  |

[0001783180-23-000038:notes:59]
[same as prior period, unchanged from 0001783180-22-000056:notes:66]

[0001783180-23-000038:notes:60]
|  |  | Three Months Ended March 31, |  |  |  |  |
| (In millions) |  | 2023 |  | 2022 |  |  |  |  |  |  |
| Service cost |  | $ | 4 |  |  | $ | 5 |  |  |  |  |  |  |  |
| Interest cost |  | 8 |  |  | 4 |  |  |  |  |  |  |  |
| Expected return on plan assets |  | (8) |  |  | (7) |  |  |  |  |  |  |  |
| Amortization of prior service credit |  | — |  |  | 1 |  |  |  |  |  |  |  |
| Recognized actuarial net (gain) loss |  | — |  |  | 2 |  |  |  |  |  |  |  |
| Net periodic pension expense (benefit) |  | $ | 4 |  |  | $ | 5 |  |  |  |  |  |  |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001783180-23-000038:notes:61]
[same as prior period, unchanged from 0001783180-22-000056:notes:68]

[0001783180-23-000038:notes:62]
[same as prior period, unchanged from 0001783180-22-000056:notes:69]

[0001783180-23-000038:notes:63]
[same as prior period, unchanged from 0001783180-22-000056:notes:70]

[0001783180-23-000038:notes:64]
|  |  | Three Months Ended March 31, |  |  |
| (In millions) |  | 2023 |  | 2022 |  |  |  |  |
| Equity compensation costs - equity settled |  | $ | 22 |  |  | $ | 21 |  |  |  |  |  |
| Equity compensation costs - cash settled (1) |  | 1 |  |  | (6) |  |  |  |  |  |
| Total stock-based compensation expense |  | $ | 23 |  |  | $ | 15 |  |  |  |  |  |

[0001783180-23-000038:notes:65]
[same as prior period, unchanged from 0001783180-22-000056:notes:72]


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001783180-23-000038:notes:66]
PRODUCT WARRANTIESIn the ordinary course of business, the Company provides standard warranty coverage on its products. Provisions for these amounts are established at the time of sale and estimated primarily based on product warranty terms and historical claims 
experience. In addition, the Company incurs discretionary costs to service its products in connection with specific product performance issues. Provisions for these amounts are established when they are known and estimable. The Company assesses the adequacy of its initial provisions and will make adjustments as necessary based on known or anticipated claims or as new information becomes available that suggests it is probable that future costs will be different than estimated amounts. Amounts associated with these provisions are classified on the accompanying Unaudited Condensed Consolidated Balance Sheet as Accrued liabilities or Other long-term liabilities based on their anticipated settlement date.

[0001783180-23-000038:notes:67]
The changes in the carrying amount of warranty related provisions are as follows:

[0001783180-23-000038:notes:68]
|  |  | Three Months Ended March 31, |
| (In millions) |  | 2023 |  | 2022 |
| Balance as of January 1, |  | $ | 552 |  |  | $ | 524 |  |
| Warranties, performance guarantees issued and changes in estimated liability |  | 54 |  |  | 45 |  |
| Settlements made |  | (45) |  |  | (43) |  |
| Other |  | 2 |  |  | — |  |
| Balance as of March 31, |  | $ | 563 |  |  | $ | 526 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001783180-23-000038:notes:69]
EQUITY 
The authorized number of shares of common stock of Carrier is 4,000,000,000 shares of $0.01 par value. As of March 31, 2023 and December 31, 2022, 878,272,100 and 876,487,480 shares of common stock were issued, respectively, which includes 43,490,981 and 42,103,995 shares of treasury stock, respectively.

[0001783180-23-000038:notes:70]
[same as prior period, unchanged from 0001783180-22-000056:notes:76]

[0001783180-23-000038:notes:71]
The Company may repurchase its outstanding common stock from time to time subject to market conditions and at the Company's discretion. Repurchases occur in the open market or through one or more other public or private transactions pursuant to plans complying with Rules 10b5-1 and 10b-18 under the Exchange Act. Shares acquired are recognized at cost and presented separately on the balance sheet as a reduction to Equity. Since the initial authorization in February 2021, the Company's Board of Directors authorized the repurchase of up to $4.1 billion of the Company's outstanding common stock. As of December 31, 2022, the Company repurchased 42.1 million shares of common stock for an aggregate purchase price of $1.9 billion, including shares repurchased under an accelerated share repurchase agreement. As a result, the Company had approximately $2.2 billion remaining under the current authorization at December 31, 2022.

[0001783180-23-000038:notes:72]
During the three months ended March 31, 2023, the Company repurchased 1.4 million shares of common stock for an aggregate purchase price of $62 million. As a result, the Company has approximately $2.1 billion remaining under the current authorization at March 31, 2023.

[0001783180-23-000038:notes:73]
[same as prior period, unchanged from 0001783180-22-000056:notes:80]

[0001783180-23-000038:notes:74]
A summary of changes in the components of Accumulated other comprehensive income (loss) for the three months ended March 31, 2023 is as follows:

[0001783180-23-000038:notes:75]
| (In millions) |  | Foreign Currency Translation |  | Defined Benefit Pension and Post-retirement Plans |  |  |  |  |  | Accumulated Other Comprehensive Income (Loss) |
| Balance as of December 31, 2022 |  | $ | (1,604) |  |  | $ | (84) |  |  |  |  |  |  | $ | (1,688) |  |
| Other comprehensive income (loss) before reclassifications, net |  | 52 |  |  | — |  |  |  |  |  |  | 52 |  |
| Amounts reclassified, pre-tax |  | — |  |  | — |  |  |  |  |  |  | — |  |
| Tax expense (benefit) reclassified |  | — |  |  | — |  |  |  |  |  |  | — |  |
| Balance as of March 31, 2023 |  | $ | (1,552) |  |  | $ | (84) |  |  |  |  |  |  | $ | (1,636) |  |

[0001783180-23-000038:notes:76]
A summary of changes in the components of Accumulated other comprehensive income (loss) for the three months ended March 31, 2022 is as follows:

[0001783180-23-000038:notes:77]
| (In millions) |  | Foreign Currency Translation |  | Defined Benefit Pension and Post-retirement Plans |  |  |  |  |  | Accumulated Other Comprehensive Income (Loss) |
| Balance as of December 31, 2021 |  | $ | (505) |  |  | $ | (484) |  |  |  |  |  |  | $ | (989) |  |
| Other comprehensive income (loss) before reclassifications, net |  | (61) |  |  | (4) |  |  |  |  |  |  | (65) |  |
| Amounts reclassified, pre-tax |  | — |  |  | 3 |  |  |  |  |  |  | 3 |  |
| Tax expense (benefit) reclassified |  | — |  |  | (1) |  |  |  |  |  |  | (1) |  |
| Chubb divestiture |  | (574) |  |  | 329 |  |  |  |  |  |  | (245) |  |
| Balance as of March 31, 2022 |  | $ | (1,140) |  |  | $ | (157) |  |  |  |  |  |  | $ | (1,297) |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001783180-23-000038:notes:78]
REVENUE RECOGNITION 
The Company accounts for revenue in accordance with ASC 606: Revenue from Contracts with Customers. Revenue is recognized when control of a good or service promised in a contract (i.e., performance obligation) is transferred to a customer. Control is obtained when a customer has the ability to direct the use of and obtain substantially all of the remaining benefits from that good or service. A significant portion of the Company's performance obligations are recognized at a point-in-time when control of the product transfers to the customer, which is generally at the time of shipment. The remaining portion of the Company’s performance obligations are recognized over time as the customer simultaneously obtains control as the Company performs work under a contract, or if the product being produced for the customer has no alternative use and the Company has a contractual right to payment.

[0001783180-23-000038:notes:79]
[same as prior period, unchanged from 0001783180-22-000056:notes:86]

[0001783180-23-000038:notes:80]
|  |  | Three Months Ended March 31, |  |  |
| (In millions) |  | 2023 |  | 2022 |  |  |  |  |
| Sales Type |  |  |  |  |  |  |  |  |
| Product |  | $ | 3,201 |  |  | $ | 2,639 |  |  |  |  |  |
| Service |  | 421 |  |  | 331 |  |  |  |  |  |
| HVAC sales |  | 3,622 |  |  | 2,970 |  |  |  |  |  |
| Product |  | 787 |  |  | 867 |  |  |  |  |  |
| Service |  | 111 |  |  | 109 |  |  |  |  |  |
| Refrigeration sales |  | 898 |  |  | 976 |  |  |  |  |  |
| Product |  | 813 |  |  | 771 |  |  |  |  |  |
| Service |  | 56 |  |  | 47 |  |  |  |  |  |
| Fire & Security sales |  | 869 |  |  | 818 |  |  |  |  |  |
| Total segment sales |  | 5,389 |  |  | 4,764 |  |  |  |  |  |
| Eliminations and other |  | (116) |  |  | (110) |  |  |  |  |  |
| Net sales |  | $ | 5,273 |  |  | $ | 4,654 |  |  |  |  |  |

[0001783180-23-000038:notes:81]
[same as prior period, unchanged from 0001783180-22-000056:notes:88]

[0001783180-23-000038:notes:82]
[same as prior period, unchanged from 0001783180-22-000056:notes:89]

[0001783180-23-000038:notes:83]
| (In millions) |  | March 31, 2023 |  | December 31, 2022 |
| Contract assets, current |  | $ | 568 |  |  | $ | 537 |  |
| Contract assets, non-current (included within Other assets) |  | 6 |  |  | 6 |  |
| Total contract assets |  | 574 |  |  | 543 |  |
| Contract liabilities, current |  | (516) |  |  | (449) |  |
| Contract liabilities, non-current (included within Other long-term liabilities) |  | (174) |  |  | (174) |  |
| Total contract liabilities |  | (690) |  |  | (623) |  |
| Net contract assets (liabilities) |  | $ | (116) |  |  | $ | (80) |  |

[0001783180-23-000038:notes:84]
The timing of revenue recognition, billings and cash collections results in contract assets and contract liabilities. Contract assets relate to the conditional right to consideration for any completed performance under a contract when costs are incurred in excess of billings under the percentage-of-completion methodology. Contract liabilities relate to payments received in advance of performance under a contract or when the Company has a right to consideration that is conditioned upon transfer of a good or service to a customer. Contract liabilities are recognized as revenue as (or when) the Company performs under the contract. 
The Company recognized revenue of $178 million during the three months ended March 31, 2023 that related to contract liabilities as of January 1, 2023. The Company expects a majority of its current contract liabilities at the end of the period to be recognized as revenue in the next 12 months.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0001783180-23-000038:notes:85]
[same as prior period, unchanged from 0001783180-22-000056:notes:92]


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001783180-23-000038:notes:86]
RESTRUCTURING COSTS
The Company incurs costs associated with restructuring initiatives intended to improve operating performance, profitability and working capital levels. Actions associated with these initiatives may include improving productivity, workforce reductions and the consolidation of facilities. Due to the size, nature and frequency of these discrete plans, they are fundamentally different from the Company's ongoing productivity actions.

[0001783180-23-000038:notes:87]
[same as prior period, unchanged from 0001783180-22-000056:notes:94]

[0001783180-23-000038:notes:88]
|  | Three Months Ended March 31, |  |  |
| (In millions) | 2023 |  | 2022 |  |  |  |  |
| HVAC | $ | (1) |  |  | $ | 4 |  |  |  |  |  |
| Refrigeration | 3 |  |  | — |  |  |  |  |  |
| Fire & Security | 13 |  |  | 6 |  |  |  |  |  |
| Total Segment | 15 |  |  | 10 |  |  |  |  |  |
| General corporate expenses | 2 |  |  | — |  |  |  |  |  |
| Total restructuring costs | $ | 17 |  |  | $ | 10 |  |  |  |  |  |
| Cost of sales | $ | 6 |  |  | $ | 2 |  |  |  |  |  |
| Selling, general and administrative | 11 |  |  | 8 |  |  |  |  |  |
| Total restructuring costs | $ | 17 |  |  | $ | 10 |  |  |  |  |  |

[0001783180-23-000038:notes:89]
[same as prior period, unchanged from 0001783180-22-000056:notes:96]

[0001783180-23-000038:notes:90]
|  |  | Three Months Ended March 31, |
| (In millions) |  | 2023 |  | 2022 |
| Balance as of January 1, |  | $ | 24 |  |  | $ | 54 |  |
| Net pre-tax restructuring costs |  | 17 |  |  | 10 |  |
| Utilization, foreign exchange and other |  | (6) |  |  | (21) |  |
| Balance as of March 31, |  | $ | 35 |  |  | $ | 43 |  |

[0001783180-23-000038:notes:91]
During the three months ended March 31, 2023 and 2022, charges associated with restructuring initiatives related to cost reduction efforts. Amounts recognized primarily related to severance due to workforce reductions and exit costs due to the consolidation of field operations. As of March 31, 2023, the Company had $35 million accrued for costs associated with its announced restructuring initiatives, all of which is expected to be paid within one year.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001783180-23-000038:notes:92]
INCOME TAXES
The Company accounts for income tax expense in accordance with ASC 740, Income Taxes ("ASC 740"), which requires an estimate of the annual effective income tax rate for the full year to be applied to the respective interim period, taking into account year-to-date amounts and projected results for the full year. The effective tax rate was 24.0% for the three months ended March 31, 2023 compared with 17.8% for the three months ended March 31, 2022. The year-over-year increase was primarily driven by a lower effective tax rate on the $1.1 billion Chubb gain compared with the Company's U.S. statutory rate and a favorable tax adjustment of $32 million associated with foreign tax credits generated and utilized in the prior year.

[0001783180-23-000038:notes:93]
[same as prior period, unchanged from 0001783180-22-000056:notes:101]

[0001783180-23-000038:notes:94]
The Company conducts business globally and files income tax returns in U.S. federal, state and foreign jurisdictions. In certain jurisdictions, the Company's operations were included in UTC's combined tax returns for the periods through the Distribution. The U.S. Internal Revenue Service ("IRS") is currently auditing UTC's tax years 2017 and 2018 and this audit could conclude within the next twelve months. In the normal course of business, the Company is subject to examination by taxing authorities throughout the world, including Australia, Belgium, Canada, China, Czech Republic, France, Germany, Hong Kong, India, Italy, Mexico, the Netherlands, Singapore, the United Kingdom and the United States. The Company is no longer subject to U.S. federal income tax examination for years prior to 2017 and, with few exceptions, is no longer subject to state, local and foreign income tax examinations for tax years prior to 2013.

[0001783180-23-000038:notes:95]
In the ordinary course of business, there is inherent uncertainty in quantifying the Company's income tax positions. The Company assesses its income tax positions and records tax benefits for all years subject to examination based upon management’s evaluation of the facts, circumstances and information available at the reporting date. The Company believes that it is reasonably possible that a net decrease in unrecognized tax benefits of $50 million to $65 million may occur within 12 months as a result of additional uncertain tax positions, the Separation, the revaluation of uncertain tax positions arising from examinations, appeals, court decisions and/or the expiration of tax statutes.


## us-gaap:EarningsPerShareTextBlock

[0001783180-23-000038:notes:96]
EARNINGS PER SHARE 
Earnings per share is computed by dividing Net income attributable to common shareowners by the weighted-average number of shares of common stock outstanding during the period (excluding treasury stock). Diluted earnings per share is computed by giving effect to all potentially dilutive stock awards that are outstanding. The computation of diluted earnings per share excludes the effect of the potential exercise of stock-based awards, including stock appreciation rights and stock options, when the effect of the potential exercise would be anti-dilutive.

[0001783180-23-000038:notes:97]
The following table summarizes the weighted-average number of shares of common stock outstanding for basic and diluted earnings per share calculations:

[0001783180-23-000038:notes:98]
|  |  | Three Months Ended March 31, |  |  |
| (In millions, except per share amounts) |  | 2023 |  | 2022 |  |  |  |  |
| Net income attributable to common shareowners |  | $ | 373 |  |  | $ | 1,379 |  |  |  |  |  |
| Basic weighted-average number of shares outstanding |  | 835.0 |  |  | 853.3 |  |  |  |  |  |
| Stock awards and equity units (share equivalent) |  | 17.2 |  |  | 20.8 |  |  |  |  |  |
| Diluted weighted-average number of shares outstanding |  | 852.2 |  |  | 874.1 |  |  |  |  |  |
| Antidilutive shares excluded from computation of diluted earnings per share |  | 6.5 |  |  | 3.2 |  |  |  |  |  |
| Earnings Per Share |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.45 |  |  | $ | 1.62 |  |  |  |  |  |
| Diluted |  | $ | 0.44 |  |  | $ | 1.58 |  |  |  |  |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001783180-23-000038:notes:99]
[same as prior period, unchanged from 0001783180-22-000056:notes:106]

[0001783180-23-000038:notes:100]
[same as prior period, unchanged from 0001783180-22-000056:notes:107]

[0001783180-23-000038:notes:101]
On February 6, 2022, the Company entered into a binding agreement to acquire a majority ownership interest in TCC for $920 million. TCC, a VRF and light commercial HVAC joint venture between Carrier and Toshiba Corporation, designs and manufactures flexible, energy-efficient and high-performance VRF and light commercial HVAC systems as well as commercial products, compressors and heat pumps. The acquisition included all of TCC’s advanced research and development centers and global manufacturing operations, product pipeline and the long-term use of Toshiba’s iconic brand. The acquisition was completed on August 1, 2022 and funded through the Japanese Term Loan Facility and cash on hand. Upon closing, Toshiba Corporation retained a 5% ownership interest in TCC.

[0001783180-23-000038:notes:102]
[same as prior period, unchanged from 0001783180-22-000056:notes:109]

[0001783180-23-000038:notes:103]
| (In millions) |  | August 1, 2022 |
| Cash and cash equivalents |  | $ | 462 |  |
| Accounts receivable |  | 426 |  |
| Inventories |  | 373 |  |
| Other assets, current |  | 54 |  |
| Fixed assets |  | 343 |  |
| Intangible assets |  | 965 |  |
| Goodwill |  | 876 |  |
| Other assets |  | 293 |  |
| Accounts payable |  | (412) |  |
| Accrued liabilities |  | (445) |  |
| Contract liabilities, current |  | (21) |  |
| Other long-term liabilities |  | (574) |  |
| Net assets acquired |  | $ | 2,340 |  |
| Less: Fair value of non-controlling interests |  | (22) |  |
| Less: Fair value of previously held TCC equity investments |  | (1,398) |  |
| Total cash consideration |  | $ | 920 |  |

[0001783180-23-000038:notes:104]
The excess purchase price over the estimated fair value of the net assets acquired was recognized as goodwill and totaled $876 million, which is not deductible for tax purposes. Accounts receivable and current liabilities were stated at their historical carrying value, which approximates fair value given the short-term nature of these assets and liabilities. The estimate of fair value for inventory and fixed assets was based on an assessment of the acquired assets' condition as well as an evaluation of the current market value of such assets. The sale agreement included several customary provisions to settle working capital and other transaction-related items as of the date of sale. During the year ended December 31, 2022, the parties finalized these amounts in accordance with the terms of the sale agreement and the Company paid an additional $41 million to Toshiba Corporation during the first quarter of 2023. In addition, the parties finalized amounts related to pension funding levels during the period. As a result, the Company recorded a receivable of $12 million which is expected to be paid by Toshiba Corporation during the second quarter of 2023.

[0001783180-23-000038:notes:105]
[same as prior period, unchanged from 0001783180-22-000056:notes:112]

[0001783180-23-000038:notes:106]
[same as prior period, unchanged from 0001783180-22-000056:notes:113]

[0001783180-23-000038:notes:107]
The valuation of intangible assets was determined using an income approach methodology including the multi-period excess earnings method and the relief from royalty method. Key assumptions used in estimating future cash flows included projected revenue growth rates, EBIT margins, discount rates, customer attrition rates and royalty rates among others. The projected future cash flows are discounted to present value using an appropriate discount rate. As of March 31, 2023, the Company

[0001783180-23-000038:notes:108]
finalized the process of allocating the purchase price and valuing the acquired assets and liabilities except for certain amounts associated with income taxes.

[0001783180-23-000038:notes:109]
The Company previously accounted for its minority ownership in TCC under the equity method of accounting. In connection with the transaction, the carrying value of the Company's previously held TCC equity investments were recognized at fair value at the date of acquisition using an income approach methodology. As a result, the Company recognized a $696 million non-cash gain within Other income (expense), net on the accompanying Unaudited Condensed Consolidated Statement of Operations. In addition, the assets, liabilities and results of operations of TCC are consolidated in the accompanying Unaudited Condensed Consolidated Financial Statements as of the date of acquisition and reported within the Company's HVAC segment. The Company incurred $29 million of acquisition-related costs during 2022, of which $6 million was recognized during the three months ended March 31, 2022 and included within Selling, general and administrative on the accompanying Unaudited Condensed Consolidated Statement of Operations. The Company has not included pro forma financial information required under ASC 805 as the pro forma impact was not significant.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001783180-23-000038:notes:110]
DIVESTITURESSale of Chubb Fire & Security Business On January 3, 2022, the Company completed the Chubb Sale for net proceeds of $2.9 billion. Chubb, which was reported within the Company’s Fire & Security segment, delivered essential fire safety and security solutions from design and installation to monitoring, service and maintenance across more than 17 countries around the globe. The sale agreement included several customary provisions to settle working capital and other transaction-related items as of the date of sale. The parties finalized these amounts in accordance with the terms of the sale agreement during 2022. During the three months ended March 31, 2022, the Company recognized a net gain on the sale of $1.1 billion, which is included in Other income (expense), net on the accompanying Unaudited Condensed Consolidated Statement of Operations.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001783180-23-000038:notes:111]
[same as prior period, unchanged from 0001783180-22-000056:notes:124]

[0001783180-23-000038:notes:112]
[same as prior period, unchanged from 0001783180-22-000056:notes:125]

[0001783180-23-000038:notes:113]
[same as prior period, unchanged from 0001783180-22-000056:notes:126]

[0001783180-23-000038:notes:114]
[same as prior period, unchanged from 0001783180-22-000056:notes:127]

[0001783180-23-000038:notes:115]
[same as prior period, unchanged from 0001783180-22-000056:notes:128]

[0001783180-23-000038:notes:116]
[same as prior period, unchanged from 0001783180-22-000056:notes:129]

[0001783180-23-000038:notes:117]
|  |  | Net Sales |  | Operating Profit |
|  |  | Three Months Ended March 31, |  | Three Months Ended March 31, |
| (In millions) |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| HVAC |  | $ | 3,622 |  |  | $ | 2,970 |  |  | $ | 435 |  |  | $ | 470 |  |
| Refrigeration |  | 898 |  |  | 976 |  |  | 108 |  |  | 107 |  |
| Fire & Security |  | 869 |  |  | 818 |  |  | 93 |  |  | 1,218 |  |
| Total segment |  | 5,389 |  |  | 4,764 |  |  | 636 |  |  | 1,795 |  |
| Eliminations and other |  | (116) |  |  | (110) |  |  | (38) |  |  | (24) |  |
| General corporate expenses |  | — |  |  | — |  |  | (43) |  |  | (34) |  |
| Total Consolidated |  | $ | 5,273 |  |  | $ | 4,654 |  |  | $ | 555 |  |  | $ | 1,737 |  |

[0001783180-23-000038:notes:118]
Geographic external sales are attributed to the geographic regions based on their location of origin. With the exception of the U.S. presented in the table below, there were no individually significant countries with sales exceeding 10% of total sales during the three months ended March 31, 2023 and 2022.

[0001783180-23-000038:notes:119]
|  |  | Three Months Ended March 31, |  |  |
| (In millions) |  | 2023 |  | 2022 |  |  |  |  |
| United States |  | $ | 2,860 |  |  | $ | 2,784 |  |  |  |  |  |
| International: |  |  |  |  |  |  |  |  |
| Europe |  | 1,196 |  |  | 1,045 |  |  |  |  |  |
| Asia Pacific |  | 1,033 |  |  | 652 |  |  |  |  |  |
| Other |  | 184 |  |  | 173 |  |  |  |  |  |
| Net sales |  | $ | 5,273 |  |  | $ | 4,654 |  |  |  |  |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001783180-23-000038:notes:120]
RELATED PARTIES
Equity Method Investments

[0001783180-23-000038:notes:121]
The Company sells products to and purchases products from unconsolidated entities accounted for under the equity method and, therefore, these entities are considered to be related parties. Amounts attributable to equity method investees are as follows:

[0001783180-23-000038:notes:122]
|  |  | Three Months Ended March 31, |  |  |
| (In millions) |  | 2023 |  | 2022 |  |  |  |  |
| Sales to equity method investees included in Product sales |  | $ | 754 |  |  | $ | 624 |  |  |  |  |  |
| Purchases from equity method investees included in Cost of products sold |  | $ | 43 |  |  | $ | 110 |  |  |  |  |  |

[0001783180-23-000038:notes:123]
The Company had receivables from and payables to equity method investees as follows:

[0001783180-23-000038:notes:124]
| (In millions) |  | March 31,2023 |  | December 31, 2022 |
| Receivables from equity method investees included in Accounts receivable, net |  | $ | 260 |  |  | $ | 154 |  |
| Payables to equity method investees included in Accounts payable |  | $ | 24 |  |  | $ | 44 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001783180-23-000038:notes:125]
COMMITMENTS AND CONTINGENT LIABILITIES
The Company is involved in various litigation, claims and administrative proceedings, including those related to environmental (including asbestos) and legal matters. In accordance with ASC 450, Contingencies, the Company records accruals for loss contingencies when it is probable that a liability will be incurred and the amount of the loss can be reasonably estimated. These accruals are generally based upon a range of possible outcomes. If no amount within the range is a better estimate than any other, the Company accrues the minimum amount. In addition, these estimates are reviewed periodically and adjusted to reflect additional information when it becomes available. The Company is unable to predict the final outcome of the following matters based on the information currently available, except as otherwise noted. However, the Company does not believe that the resolution of any of these matters will have a material adverse effect upon its results of operations, cash flows or financial condition.

[0001783180-23-000038:notes:126]
Environmental Matters

[0001783180-23-000038:notes:127]
The Company’s operations are subject to environmental regulation by various authorities. The Company has accrued for the costs of environmental remediation activities, including but not limited to investigatory, remediation, operating and maintenance costs and performance guarantees. The most likely cost to be incurred is accrued based on an evaluation of currently available facts with respect to individual sites, including the technology required to remediate, current laws and regulations and prior remediation experience.

[0001783180-23-000038:notes:128]
The outstanding liabilities for environmental obligations are as follows:

[0001783180-23-000038:notes:129]
| (In millions) |  | March 31,2023 |  | December 31, 2022 |
| Environmental reserves included in Accrued liabilities |  | $ | 19 |  |  | $ | 24 |  |
| Environmental reserves included in Other long-term liabilities |  | 214 |  |  | 211 |  |
| Total Environmental reserves |  | $ | 233 |  |  | $ | 235 |  |

[0001783180-23-000038:notes:130]
For sites with multiple responsible parties, the Company considers its likely proportionate share of the anticipated remediation costs and the ability of other parties to fulfill their obligations in establishing a provision for these costs. Accrued environmental liabilities are not reduced by potential insurance reimbursements and are undiscounted.

[0001783180-23-000038:notes:131]
Asbestos Matters

[0001783180-23-000038:notes:132]
The Company has been named as a defendant in lawsuits alleging personal injury as a result of exposure to asbestos allegedly integrated into certain Carrier products or business premises. While the Company has never manufactured asbestos and no longer incorporates it into any currently-manufactured products, certain products that the Company no longer manufactures contained components incorporating asbestos. A substantial majority of these asbestos-related claims have been dismissed without payment or have been covered in full or in part by insurance or other forms of indemnity. Additional cases were litigated and settled without any insurance reimbursement. The amounts involved in asbestos-related claims were not material individually or in the aggregate in any period.

[0001783180-23-000038:notes:133]
The Company's asbestos liabilities and related insurance recoveries are as follows:

[0001783180-23-000038:notes:134]
| (In millions) |  | March 31,2023 |  | December 31,2022 |
| Asbestos liabilities included in Accrued liabilities |  | $ | 16 |  |  | $ | 16 |  |
| Asbestos liabilities included in Other long-term liabilities |  | 211 |  |  | 212 |  |
| Total Asbestos liabilities |  | $ | 227 |  |  | $ | 228 |  |
| Asbestos-related recoveries included in Other assets, current |  | $ | 5 |  |  | $ | 5 |  |
| Asbestos-related recoveries included in Other assets |  | 89 |  |  | 90 |  |
| Total Asbestos-related recoveries |  | $ | 94 |  |  | $ | 95 |  |

[0001783180-23-000038:notes:135]
The amounts recorded for asbestos-related liabilities are based on currently available information and assumptions that the Company believes are reasonable and are made with input from outside actuarial experts. These amounts are undiscounted and exclude the Company’s legal fees to defend the asbestos claims, which are expensed as incurred. In addition, the Company has recorded insurance recovery receivables for probable asbestos-related recoveries.

[0001783180-23-000038:notes:136]
UTC Equity Awards Conversion Litigation

[0001783180-23-000038:notes:137]
On August 12, 2020, several former employees of UTC or its subsidiaries filed a putative class action complaint (the "Complaint") in the United States District Court for the District of Connecticut against Raytheon Technologies Corporation ("Raytheon"), Carrier, Otis Worldwide Corporation ("Otis"), the former members of the UTC Board of Directors and the members of the Carrier and Otis Boards of Directors (Geraud Darnis, et al. v. Raytheon Technologies Corporation, et al.). The Complaint challenged the method by which UTC equity awards were converted to UTC, Carrier and Otis equity awards following the Separation and the Distribution. Defendants moved to dismiss the Complaint. Plaintiffs amended their Complaint on September 13, 2021 (the "Amended Complaint"). The Amended Complaint, with Raytheon, Carrier and Otis as the only defendants, asserted that the defendants are liable for breach of certain equity compensation plans and for breach of the implied covenant of good faith and fair dealing. The Amended Complaint also sought specific performance. The Company believes all plaintiffs' claims against it are without merit. Defendants moved to dismiss the Amended Complaint. On September 30, 2022, the court dismissed the case against all defendants, with prejudice. Plaintiffs appealed the dismissal to the United States Court of Appeals for the Second Circuit. Oral arguments on the appeal is scheduled to occur before the Second Circuit on June 29, 2023.

[0001783180-23-000038:notes:138]
Aqueous Film Forming Foam Litigation

[0001783180-23-000038:notes:139]
As of March 31, 2023,  the Company and certain  of its subsidiaries, including Kidde-Fenwal, Inc. ("KFI"), have been named as defendants in more than 3,800 lawsuits filed by individuals in or removed to the federal courts of the United States alleging that the historic use of Aqueous Film Forming Foam ("AFFF") caused personal injuries and/or property damage. The Company and certain of its subsidiaries, including KFI, have also been named as a defendant in more than 370 lawsuits filed by several U.S. states, municipalities and water utilities in or removed to U.S. federal courts alleging that the historic use of AFFF caused contamination of property and water supplies. In December 2018, the U.S. Judicial Panel on Multidistrict Litigation transferred and consolidated all AFFF cases pending in the U.S. federal courts against the Company and others to the U.S. District Court for the District of South Carolina ("MDL Court") for pre-trial proceedings ("MDL Proceedings"). The individual plaintiffs in the MDL Proceedings generally seek damages for alleged personal injuries, medical monitoring, diminution in property value and injunctive relief to remediate alleged contamination of water supplies. The U.S. state, municipal and water utility plaintiffs in the MDL Proceedings generally seek damages and costs related to the remediation of public property and water supplies.

[0001783180-23-000038:notes:140]
AFFF is a firefighting foam, developed beginning in the late 1960s pursuant to U.S. military specification, used to extinguish certain types of hydrocarbon-fueled fires primarily at military bases and airports. AFFF was manufactured by several companies, including National Foam and Angus Fire. UTC subsidiaries first entered the AFFF business with their acquisition of National Foam and Angus Fire in 2005 as part of the acquisition of KFI and Kidde Products Limited ("KPL"). In 2013, KFI and KPL divested the National Foam and Angus Fire businesses to a third party. The Company acquired KFI and KPL as part of the Separation in April 2020. During the eight-year period of its operation by KFI, National Foam manufactured AFFF for sale to government (including the U.S. federal government) and non-government customers in the U.S. at a single facility located in

[0001783180-23-000038:notes:141]
West Chester, Pennsylvania ("Pennsylvania Site"). During the same period, Angus Fire manufactured AFFF for sale outside the United States at a single facility located in Bentham, England.

[0001783180-23-000038:notes:142]
The key components of AFFF that contribute to its fire-extinguishing capabilities are known as fluorosurfactants. Neither the Company nor any of its former or current subsidiaries, including National Foam/Angus Fire and KFI/KPL, respectively, manufactured fluorosurfactants; they instead purchased these substances from unrelated third parties to, in turn, manufacture AFFF. Plaintiffs in the MDL Proceedings allege that the fluorosurfactants used by various manufacturers in producing AFFF contained, or over time degraded into, compounds known as perflourooctane sulfonate ("PFOS") and/or perflourooctane acid ("PFOA"). Plaintiffs further allege that, as a result of the use of AFFF, PFOS and PFOA were released into the environment and, in some instances, ultimately reached drinking water supplies.

[0001783180-23-000038:notes:143]
Plaintiffs in the MDL Proceedings allege that PFOS and PFOA contamination has resulted from the use of AFFF manufactured using a process known as ECF, and that this process was used exclusively by 3M. They also allege that PFOA contamination has resulted from the use of AFFF manufactured using a different process, known as telomerization, and that this process was used exclusively by the other AFFF manufacturers (including National Foam and Angus Fire). Compounds containing PFOS and PFOA (as well as many other per- and polyfluoroalkyl substances known collectively as "PFAS") have also been used for decades by many third parties in a number of different industries to manufacture firefighters’ protective outerwear, carpets, clothing, fabrics, cookware, food packaging, personal care products, cleaning products, paints, varnishes and other consumer and industrial products.

[0001783180-23-000038:notes:144]
Plaintiffs in the MDL Proceedings have named multiple defendants, including four suppliers of chemicals and raw materials used to manufacture fluorosurfactants, four fluorosurfactant manufacturers, two toll manufacturers of fluorosurfactants and seven current (including National Foam and Angus Fire) and former (including the Company and KFI) AFFF manufacturers.

[0001783180-23-000038:notes:145]
The defendants moved for summary judgment on the government contractor defense, which potentially applies to AFFF sold to or used by the U.S. government. After full briefing and oral argument, on September 16, 2022, the MDL court declined to enter summary judgment for the defendants. The defense, however, remains available at any trial to which it applies.

[0001783180-23-000038:notes:146]
On September 23, 2022, after completion of discovery, the MDL court selected one water provider case, the City of Stuart, FL v. 3M, et al., for a bellwether trial. That trial is scheduled for June 2023. The MDL court has ordered that the bellwether process for personal injury cases will begin in 2023. The court has not yet outlined details on that process or its timing.

[0001783180-23-000038:notes:147]
Outside of the MDL Proceedings, the Company and other defendants are also party to six lawsuits in U.S. state courts brought by oil refining companies alleging product liability claims related to legacy sales of AFFF and seeking damages for the costs to replace the product and for property damage. In addition, the Company and other defendants are party to two actions related to the Pennsylvania Site in which the plaintiff water utility company seeks remediation costs related to the alleged contamination of the local water supply.

[0001783180-23-000038:notes:148]
The Company and its subsidiaries, including KFI, and other defendants are also party to one action in Arizona state court brought by a firefighter claiming that occupational exposure to AFFF has caused him certain personal injuries. The Company and its subsidiaries, including KFI, believe that they have meritorious defenses to the claims in the MDL Proceedings and the other AFFF lawsuits. Based on its 2013 agreement for the sale of National Foam and Angus Fire, the Company and its subsidiaries, including KFI, are pursuing indemnification against these claims from the purchaser and current owner of National Foam and Angus Fire. The Company and its subsidiaries, including KFI, are also pursuing insurance coverage for these claims. At this time, however, given the numerous factual, scientific and legal issues to be resolved relating to these claims, the Company is unable to assess the probability of liability or to reasonably estimate the damages, if any, to be allocated to the Company and its subsidiaries, including KFI, if one or more plaintiffs were to prevail in these cases. There can be no assurance that any such future exposure will not be material in any period.

[0001783180-23-000038:notes:149]
Income Taxes

[0001783180-23-000038:notes:150]
Under the Tax Matters Agreement relating to the Separation, the Company is responsible to UTC for its share of the Tax Cuts and Jobs Act transition tax associated with foreign undistributed earnings as of December 31, 2017. As a result, liabilities of $49 million and $368 million are included within the accompanying Unaudited Condensed Consolidated Balance Sheet within Accrued Liabilities and Other Long-Term Liabilities as of March 31, 2023, respectively. This obligation is expected to be settled in annual installments ending in April 2026 with the next installment of $49 million due in 2023. The Company believes that the likelihood of incurring losses materially in excess of this amount is remote.

[0001783180-23-000038:notes:151]
Other

[0001783180-23-000038:notes:152]
The Company has other commitments and contingent liabilities related to legal proceedings, self-insurance programs and matters arising in the ordinary course of business. The Company accrues for contingencies generally based upon a range of possible outcomes. If no amount within the range is a better estimate than any other, the Company accrues the minimum amount.

[0001783180-23-000038:notes:153]
In the ordinary course of business, the Company is also routinely a defendant in, party to or otherwise subject to many pending and threatened legal actions, claims, disputes and proceedings. These matters are often based on alleged violations of contract, product liability, warranty, regulatory, environmental, health and safety, employment, intellectual property, tax and other laws. In some of these proceedings, claims for substantial monetary damages are asserted against the Company and could result in fines, penalties, compensatory or treble damages or non-monetary relief. The Company does not believe that these matters will have a material adverse effect upon its results of operations, cash flows or financial condition.


## us-gaap:SubsequentEventsTextBlock

[0001783180-23-000038:notes:154]
SUBSEQUENT EVENTS 
On April 25, 2023, the Company announced that it entered into a Share Purchase Agreement (the “Agreement”) to acquire the climate solutions business (the "Business") of Viessmann Group GmbH & Co. KG (“Viessmann”), a privately-held company, for approximately €12 billion. The Business develops intelligent, integrated and sustainable technologies, including heat pumps, boilers, photovoltaic systems, home battery storage and digital solutions, primarily for residential customers in Europe. Under the terms of the Agreement, 20% of the purchase price will be paid in Carrier common stock, issued directly to Viessmann and subject to long-term lock-up provisions, and 80% will be paid in cash, subject to working capital and other adjustments. The Company intends to finance the acquisition with a combination of cash on hand and debt financing and expects the transaction to close around the end of 2023, subject to customary closing conditions and regulatory approvals. On April 26, 2023, the Company entered into a forward contract with a total notional amount of €7 billion to mitigate the foreign currency risk of the Euro cash outflows associated with the acquisition.

[0001783180-23-000038:notes:155]
On April 25, 2023, the Company announced plans to exit its Fire & Security and Commercial Refrigeration businesses over the course of 2024. Carrier expects to use the proceeds from these transactions to reduce leverage, advance the Company’s capital allocation priorities and for general corporate purposes. The planned exit is not expected to impact UTEC, Fire & Security’s controls business for residential HVAC customers or the Company’s Transicold transport refrigeration, Profroid mechanical systems or the Sensitech monitoring businesses.
