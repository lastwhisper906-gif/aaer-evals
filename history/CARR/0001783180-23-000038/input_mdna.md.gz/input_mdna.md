# CARR MD&A — 0001783180-23-000038


## mdna

[0001783180-23-000038:mdna:1]
[same as prior period, unchanged from 0001783180-22-000056:mdna:1]

[0001783180-23-000038:mdna:2]
[same as prior period, unchanged from 0001783180-22-000056:mdna:2]

[0001783180-23-000038:mdna:3]
[same as prior period, unchanged from 0001783180-22-000056:mdna:3]

[0001783180-23-000038:mdna:4]
Carrier Global Corporation ("we" or "our") is the leading global provider of healthy, safe, sustainable and intelligent building and cold chain solutions with a focus on providing differentiated, digitally-enabled lifecycle solutions to our customers. Our portfolio includes industry-leading brands such as Carrier, Toshiba, Automated Logic, Carrier Transicold, Kidde, Edwards and LenelS2 that offer innovative heating, ventilating and air conditioning ("HVAC"), refrigeration, fire, security and building automation technologies to help make the world safer and more comfortable. We also provide a broad array of related building services, including audit, design, installation, system integration, repair, maintenance and monitoring. Our operations are classified into three segments: HVAC, Refrigeration and Fire & Security.

[0001783180-23-000038:mdna:5]
Our worldwide operations are affected by global and regional industrial, economic and political factors and trends. These include the mega-trends of urbanization, climate change and increasing requirements for food safety driven by the food needs of the growing global population and the rising standards of living in emerging markets. We believe that our business segments are well positioned to benefit from favorable secular trends, including these mega-trends and from the strength of our industry-leading brands and track record of innovation. In addition, we regularly review our end markets to proactively identify trends and adapt our strategies accordingly.

[0001783180-23-000038:mdna:6]
[same as prior period, unchanged from 0001783180-22-000056:mdna:6]

[0001783180-23-000038:mdna:7]
[same as prior period, unchanged from 0001783180-22-000056:mdna:7]

[0001783180-23-000038:mdna:8]
The ongoing global economic recovery from the COVID-19 pandemic has caused significant challenges for global supply chains resulting in inflationary cost pressures, component shortages and transportation delays. As a result, we have incurred incremental costs for commodities and components used in our products as well as component shortages that have negatively impacted our sales and results of operations. Inflationary cost pressures have begun to moderate, but remain elevated and continue to affect our results. We expect that these challenges will continue to impact our businesses for the foreseeable future.

[0001783180-23-000038:mdna:9]
[same as prior period, unchanged from 0001783180-22-000056:mdna:15]

[0001783180-23-000038:mdna:10]
[same as prior period, unchanged from 0001783180-22-000056:mdna:8]

[0001783180-23-000038:mdna:11]
On February 6, 2022, we entered into a binding agreement to acquire a majority ownership interest in Toshiba Carrier Corporation ("TCC"), a variable refrigerant flow ("VRF") and light commercial HVAC joint venture between Carrier and Toshiba Corporation. TCC designs and manufactures flexible, energy-efficient and high-performance VRF and light commercial HVAC systems as well as commercial products, compressors and heat pumps. The acquisition included all of TCC's advanced research and development centers and global manufacturing operations, product pipeline and the long-term use of Toshiba's iconic brand. The acquisition was completed on August 1, 2022. As a result, the assets, liabilities and results of operations of TCC are consolidated in the accompanying Unaudited Condensed Consolidated Financial Statements as of the date of acquisition and reported within our HVAC segment. Upon closing, Toshiba Corporation retained a 5% ownership interest in TCC.

[0001783180-23-000038:mdna:12]
[same as prior period, unchanged from 0001783180-22-000056:mdna:16]

[0001783180-23-000038:mdna:13]
On July 26, 2021, we entered into a stock purchase agreement to sell our Chubb Fire and Security business ("Chubb") to APi Group Corporation ("APi"). Chubb, which was reported within our Fire & Security segment, delivered essential fire safety and security solutions from design and installation to monitoring, service and maintenance across more than 17 countries around the globe. On January 3, 2022, we completed the sale of Chubb (the "Chubb Sale") for net proceeds of $2.9 billion and recognized a gain on the sale of $1.1 billion during the year ended December 31, 2022.

[0001783180-23-000038:mdna:14]
[same as prior period, unchanged from 0001783180-22-000056:mdna:20]

[0001783180-23-000038:mdna:15]
Preparation of our financial statements requires management to make estimates and assumptions that affect the reported amounts of assets, liabilities, sales and expenses. We believe that the most complex and sensitive judgments, because of their potential significance to the accompanying Unaudited Condensed Consolidated Financial Statements, result primarily from the need to make estimates about the effects of matters that are inherently uncertain. In "Management’s Discussion and Analysis of Financial Condition and Results of Operations" of our 2022 Form 10-K, we describe the significant accounting estimates and policies used in the preparation of the accompanying Unaudited Condensed Consolidated Financial Statements. There have been no significant changes in our critical accounting estimates.

[0001783180-23-000038:mdna:16]
28

[0001783180-23-000038:mdna:17]
[same as prior period, unchanged from 0001783180-22-000056:mdna:22]

[0001783180-23-000038:mdna:18]
Three Months Ended March 31, 2023 Compared with the Three Months Ended March 31, 2022

[0001783180-23-000038:mdna:19]
The results of TCC's operations are included in our consolidated results since the acquisition date of August 1, 2022. Prior to the acquisition, we accounted for our minority ownership in TCC under the equity method of accounting and recognized our portion of earnings within Equity method investment in net earnings as part of operating expenses. As a result, prior period results may not be comparable to the current period.

[0001783180-23-000038:mdna:20]
[same as prior period, unchanged from 0001783180-22-000056:mdna:26]

[0001783180-23-000038:mdna:21]
|  |  | Three Months Ended March 31, |  |  |  |  |  |  |
| (In millions) |  | 2023 |  | 2022 |  | Period Change |  | % Change |  |  |  |  |  |  |
| Net sales |  | $ | 5,273 |  |  | $ | 4,654 |  |  | $ | 619 |  |  | 13 | % |  |  |  |  |  |  |
| Cost of products and services sold |  | (3,895) |  |  | (3,361) |  |  | (534) |  |  | 16 | % |  |  |  |  |  |  |
| Gross margin |  | 1,378 |  |  | 1,293 |  |  | 85 |  |  | 7 | % |  |  |  |  |  |  |
| Operating expenses |  | (823) |  |  | 444 |  |  | (1,267) |  |  | (285) | % |  |  |  |  |  |  |
| Operating profit |  | 555 |  |  | 1,737 |  |  | (1,182) |  |  | (68) | % |  |  |  |  |  |  |
| Non-operating income (expenses), net |  | (46) |  |  | (49) |  |  | 3 |  |  | (6) | % |  |  |  |  |  |  |
| Income from operations before income taxes |  | 509 |  |  | 1,688 |  |  | (1,179) |  |  | (70) | % |  |  |  |  |  |  |
| Income tax expense |  | (122) |  |  | (301) |  |  | 179 |  |  | (59) | % |  |  |  |  |  |  |
| Net income from operations |  | 387 |  |  | 1,387 |  |  | (1,000) |  |  | (72) | % |  |  |  |  |  |  |
| Less: Non-controlling interest in subsidiaries' earnings from operations |  | 14 |  |  | 8 |  |  | 6 |  |  | 75 | % |  |  |  |  |  |  |
| Net income attributable to common shareowners |  | $ | 373 |  |  | $ | 1,379 |  |  | $ | (1,006) |  |  | (73) | % |  |  |  |  |  |  |

[0001783180-23-000038:mdna:22]
[same as prior period, unchanged from 0001783180-22-000056:mdna:28]

[0001783180-23-000038:mdna:23]
For the three months ended March 31, 2023, Net sales were $5.3 billion, a 13% increase compared with the same period of 2022. The components of the year-over-year change were as follows:

[0001783180-23-000038:mdna:24]
|  |  | Three Months Ended March 31, 2023 |  |  |  |  |  |  |
| Organic |  | 4 | % |  |  |  |  |  |  |
| Foreign currency translation |  | (2) | % |  |  |  |  |  |  |
| Acquisitions and divestitures, net |  | 11 | % |  |  |  |  |  |  |
| Total % change |  | 13 | % |  |  |  |  |  |  |

[0001783180-23-000038:mdna:25]
Organic sales for the three months ended March 31, 2023 increased by 4% compared with the same period of 2022. The organic increase was primarily driven by our Fire & Security segment due to price improvements and volume growth in each region. In addition, improved global end-markets in our Commercial HVAC business further benefited our results. Refrigeration results decreased as each of the segment's businesses experienced challenges in certain end-markets during the quarter. Refer to "Segment Review" below for a discussion of Net sales by segment.

[0001783180-23-000038:mdna:26]
[same as prior period, unchanged from 0001783180-22-000056:mdna:32]

[0001783180-23-000038:mdna:27]
For the three months ended March 31, 2023, gross margin was $1.4 billion, a 7% increase compared with the same period of

[0001783180-23-000038:mdna:28]
2022. The components were as follows:

[0001783180-23-000038:mdna:29]
|  |  |  |  | Three Months Ended March 31, |  |  |  |  |
| (In millions) |  |  |  |  |  | 2023 |  | 2022 |  |  |  |  |
| Net sales |  |  |  |  |  | $ | 5,273 |  |  | $ | 4,654 |  |  |  |  |  |
| Cost of products and services sold |  |  |  |  |  | (3,895) |  |  | (3,361) |  |  |  |  |  |
| Gross margin |  |  |  |  |  | $ | 1,378 |  |  | $ | 1,293 |  |  |  |  |  |
| Percentage of net sales |  |  |  |  |  | 26.1 | % |  | 27.8 | % |  |  |  |  |

[0001783180-23-000038:mdna:30]
Gross margin increased by $85 million compared with the three months ended March 31, 2022. The main driver of the increase related to ongoing customer demand, pricing improvements and our continued focus on productivity initiatives. In addition, incremental results associated with TCC since the date of acquisition further benefited gross margin during the period. However, the results of TCC included inventory step-up, backlog amortization and intangible asset amortization resulting from the recognition of acquired assets at fair value. These costs had a 240 basis point unfavorable impact on gross margin as a percentage of Net sales. In addition, each of our segments continue to be impacted by the higher cost of commodities and components used in our products, certain supply chain constraints and higher freight costs. Although pricing improvements more than offset inflationary impacts and supply chain challenges, gross margin as a percentage of Net sales decreased by 170 basis points compared with the same period of 2022.

[0001783180-23-000038:mdna:31]
[same as prior period, unchanged from 0001783180-22-000056:mdna:36]

[0001783180-23-000038:mdna:32]
For the three months ended March 31, 2023, operating expenses, including Equity method investment net earnings, were $823 million, a 285% increase compared with the same period of 2022. The components were as follows:

[0001783180-23-000038:mdna:33]
|  |  | Three Months Ended March 31, |
| (In millions) |  | 2023 |  | 2022 |
| Selling, general and administrative |  | $ | (721) |  |  | $ | (601) |  |
| Research and development |  | (139) |  |  | (125) |  |
| Equity method investment net earnings |  | 44 |  |  | 58 |  |
| Other income (expense), net |  | (7) |  |  | 1,112 |  |
| Total operating expenses |  | $ | (823) |  |  | $ | 444 |  |
| Percentage of net sales |  | 15.6 | % |  | (9.5) | % |

[0001783180-23-000038:mdna:34]
For the three months ended March 31, 2023, Selling, general and administrative expenses were $721 million, a 20% increase compared with the same period of 2022. The increase is primarily due to the incremental selling, general and administrative expenses associated with TCC since the date of acquisition. In addition, higher compensation and other employee-related costs further contributed to the increase. The current period also included $12 million of acquisition-related costs compared with $6 million during the three months ended March 31, 2022.

[0001783180-23-000038:mdna:35]
[same as prior period, unchanged from 0001783180-22-000056:mdna:40]

[0001783180-23-000038:mdna:36]
Investments over which we do not exercise control, but have significant influence, are accounted for using the equity method of accounting. For the three months ended March 31, 2023, Equity method investment net earnings were $44 million, a 24% decrease compared with the same period of 2022. The decrease was primarily driven by the increase in our ownership interest in TCC on August 1, 2022. As a result, TCC is no longer accounted for under the equity method of accounting since the date of acquisition. During the three months ended March 31, 2022, pre-acquisition equity earnings of TCC totaled $20 million.

[0001783180-23-000038:mdna:37]
Other income (expense), net primarily includes the impact of gains and losses related to the sale of businesses or interests in our equity method investments, foreign currency gains and losses on transactions that are denominated in a currency other than an

[0001783180-23-000038:mdna:38]
entity's functional currency and hedging-related activities. During the three months ended March 31, 2022, we completed the Chubb Sale and recognized a net gain on the sale of $1.1 billion.

[0001783180-23-000038:mdna:39]
[same as prior period, unchanged from 0001783180-22-000056:mdna:43]

[0001783180-23-000038:mdna:40]
For the three months ended March 31, 2023, Non-operating income (expenses), net was $46 million, an 6% increase compared with the same period of 2022. The components were as follows:

[0001783180-23-000038:mdna:41]
|  |  | Three Months Ended March 31, |
| (In millions) |  | 2023 |  | 2022 |
| Non-service pension (expense) benefit |  | $ | — |  |  | $ | (1) |  |
| Interest expense |  | $ | (71) |  |  | $ | (87) |  |
| Interest income |  | 25 |  |  | 39 |  |
| Interest (expense) income, net |  | $ | (46) |  |  | $ | (48) |  |
| Non-operating income (expenses), net |  | $ | (46) |  |  | $ | (49) |  |

[0001783180-23-000038:mdna:42]
Non-operating income (expenses), net includes the results from activities other than normal business operations such as interest expense, interest income and the non-service components of pension and post-retirement obligations. Interest expense is affected by the amount of debt outstanding and the interest rates on that debt. For the three months ended March 31, 2023, Interest expense was $71 million, a 18% decrease compared with the same period of 2022. During the three months ended March 31, 2022, we completed tender offers to repurchase approximately $1.15 billion aggregate principal of our 2.242% Notes due 2025 and 2.493% Notes due 2027. Upon settlement, we wrote off $5 million of unamortized deferred financing costs in Interest expense and recognized a net gain of $33 million in Interest income.

[0001783180-23-000038:mdna:43]
[same as prior period, unchanged from 0001783180-22-000056:mdna:47]

[0001783180-23-000038:mdna:44]
|  |  |  | Three Months Ended March 31, |  |  |
|  |  |  |  |  | 2023 |  | 2022 |  |  |  |  |
| Effective tax rate |  |  |  |  | 24.0 | % |  | 17.8 | % |  |  |  |  |

[0001783180-23-000038:mdna:45]
We account for income tax expense in accordance with ASC 740, which requires an estimate of the annual effective income tax rate for the full year to be applied to the respective interim period, taking into account year-to-date amounts and projected results for the full year. The effective tax rate was 24.0% for the three months ended March 31, 2023 compared with 17.8% for the three months ended March 31, 2022. The year-over-year increase was primarily driven by a lower effective tax rate on the $1.1 billion Chubb gain compared with our U.S. statutory rate and a favorable tax adjustment of $32 million associated with foreign tax credits generated and utilized in the prior year.

[0001783180-23-000038:mdna:46]
31

[0001783180-23-000038:mdna:47]
[same as prior period, unchanged from 0001783180-22-000056:mdna:78]

[0001783180-23-000038:mdna:48]
[same as prior period, unchanged from 0001783180-22-000056:mdna:79]

[0001783180-23-000038:mdna:49]
[same as prior period, unchanged from 0001783180-22-000056:mdna:80]

[0001783180-23-000038:mdna:50]
[same as prior period, unchanged from 0001783180-22-000056:mdna:81]

[0001783180-23-000038:mdna:51]
[same as prior period, unchanged from 0001783180-22-000056:mdna:82]

[0001783180-23-000038:mdna:52]
[same as prior period, unchanged from 0001783180-22-000056:mdna:83]

[0001783180-23-000038:mdna:53]
Three Months Ended March 31, 2023 Compared with Three Months Ended March 31, 2022

[0001783180-23-000038:mdna:54]
| Summary performance for each of our segments is as follows: |
|  | Net Sales |  | Operating Profit |  | Operating Profit Margin |
|  | Three Months Ended March 31, |  | Three Months Ended March 31, |  | Three Months Ended March 31, |
| (In millions) | 2023 |  | 2022 |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| HVAC | $ | 3,622 |  |  | $ | 2,970 |  |  | $ | 435 |  |  | $ | 470 |  |  | 12.0 | % |  | 15.8 | % |
| Refrigeration | 898 |  |  | 976 |  |  | 108 |  |  | 107 |  |  | 12.0 | % |  | 11.0 | % |
| Fire & Security | 869 |  |  | 818 |  |  | 93 |  |  | 1,218 |  |  | 10.7 | % |  | 148.9 | % |
| Total segment | $ | 5,389 |  |  | $ | 4,764 |  |  | $ | 636 |  |  | $ | 1,795 |  |  | 11.8 | % |  | 37.7 | % |

[0001783180-23-000038:mdna:55]
[same as prior period, unchanged from 0001783180-22-000056:mdna:87]

[0001783180-23-000038:mdna:56]
For the three months ended March 31, 2023, Net sales in our HVAC segment were $3.6 billion, a 22% increase compared with the same period of 2022. The components of the year-over-year change were as follows:

[0001783180-23-000038:mdna:57]
|  |  | Net Sales |
| Organic |  | 6 | % |
| Foreign currency translation |  | (2) | % |
| Acquisitions and divestitures, net |  | 18 | % |
| Total % change in Net sales |  | 22 | % |

[0001783180-23-000038:mdna:58]
The organic increase in Net sales of 6% was driven by continued strong results in the segment. Increased sales in our Commercial HVAC business (up 14%) benefited from pricing improvements and ongoing customer demand in our end-markets. The business saw strong growth in all regions including Europe and Asia as current economic conditions and inflationary cost pressures moderated from the prior year. In addition, increased sales in our Global Comfort Solutions business (up 18%) were primarily driven by pricing improvements. Lower sales in our North America residential and light commercial business (down 2%) were primarily driven by volume reductions in North America residential end-markets. These amounts were partially offset by pricing improvements and improved mix associated with regulatory changes effective as of the beginning of 2023.

[0001783180-23-000038:mdna:59]
On August 1, 2022, the Commercial HVAC business acquired a majority ownership interest in TCC, a VRF and light commercial HVAC joint venture between Carrier and Toshiba Corporation. The results of TCC have been included in our

[0001783180-23-000038:mdna:60]
Unaudited Condensed Consolidated Financial Statements since the date of acquisition. The transaction added 18% to Net sales during the three months ended March 31, 2023 and is included in Acquisitions and divestitures, net.

[0001783180-23-000038:mdna:61]
For the three months ended March 31, 2023, Operating profit in our HVAC segment was $435 million, a 7% decrease compared with the same period of 2022. The components of the year-over-year change were as follows:

[0001783180-23-000038:mdna:62]
|  |  |  | Operating Profit |
| Operational |  |  | (7) | % |
| Foreign currency translation |  |  | (1) | % |
| Acquisitions and divestitures, net |  |  | 8 | % |
| Restructuring |  |  | 1 | % |
| Amortization of acquired intangibles |  |  | (7) | % |
| Other |  |  | (1) | % |
| Total % change in Operating profit |  |  | (7) | % |

[0001783180-23-000038:mdna:63]
The operational profit decrease of 7% was primarily attributable to volume reductions in certain end-markets compared with the prior year. In addition, lower earnings from equity method investments also impacted operational profit due to the increase in our ownership interest in TCC on August 1, 2022. As a result, TCC is no longer accounted for under the equity method of accounting since the date of acquisition. Pricing and productivity improvements more than offset higher costs for commodities and components used in our products as well as higher freight and logistics costs. Inflationary cost pressures have begun to moderate, but remain elevated and continue to impact our operating profit.

[0001783180-23-000038:mdna:64]
[same as prior period, unchanged from 0001783180-22-000056:mdna:96]

[0001783180-23-000038:mdna:65]
For the three months ended March 31, 2023, Net sales in our Refrigeration segment were $898 million, a 8% decrease compared with the same period of 2022. The components of the year-over-year change were as follows:

[0001783180-23-000038:mdna:66]
|  |  | Net Sales |
| Organic |  | (5) | % |
| Foreign currency translation |  | (3) | % |
| Acquisitions and divestitures, net |  | — | % |
| Total % change in Net sales |  | (8) | % |

[0001783180-23-000038:mdna:67]
Organic Net sales decreased 5% compared to the prior year as each of the segment's businesses experienced challenges in certain end-markets during the period. Results for Commercial refrigeration decreased (down 15%) compared with the prior year, primarily driven by lower volumes in Europe as economic conditions and inflationary cost pressures impacted end-market demand. In addition, results in Asia continued to be affected by ongoing COVID-19 impacts. However, these impacts were partially offset by pricing improvements. Transport refrigeration sales increased (up 1%) compared to the prior year as pricing improvements and strong end-market demand in the U.S. and Europe were more than offset by continued weakness in container end-markets.

[0001783180-23-000038:mdna:68]
For the three months ended March 31, 2023, Operating profit in our Refrigeration segment was $108 million, a 1% increase  compared with the same period of 2022. The components of the year-over-year change were as follows:

[0001783180-23-000038:mdna:69]
|  |  |  | Operating Profit |
| Operational |  |  | (15) | % |
| Foreign currency translation |  |  | (3) | % |
| Restructuring |  |  | (3) | % |
| Other |  |  | 22 | % |
| Total % change in Operating profit |  |  | 1 | % |

[0001783180-23-000038:mdna:70]
The decrease in operational profit of 15% was primarily driven by volume reductions in certain end-markets compared with the prior year. In addition, the higher costs of commodities and components used in our products further impacted segment results. These amounts were partially offset by pricing improvements, favorable productivity initiatives and lower selling, general and administrative costs during the period. Inflationary cost pressures have begun to moderate, but remain elevated and continue to impact our operating profit. Amounts reported in Other represent a $24 million gain on sale of a business within Transport refrigeration.

[0001783180-23-000038:mdna:71]
[same as prior period, unchanged from 0001783180-22-000056:mdna:103]

[0001783180-23-000038:mdna:72]
For the three months ended March 31, 2023, Net sales in our Fire & Security segment were $869 million, a 6% increase compared with the same period of 2022. The components of the year-over-year change were as follows:

[0001783180-23-000038:mdna:73]
|  |  | Net Sales |
| Organic |  | 9 | % |
| Foreign currency translation |  | (3) | % |
| Total % change in Net sales |  | 6 | % |

[0001783180-23-000038:mdna:74]
The organic increase in Net sales of 9% was primarily driven by pricing improvements and volume growth compared with the prior year. Sales grew in all three regions with strong commercial results in Europe and Asia as current economic conditions and end-market demand improved. Growth in the Americas was impacted by reduced residential end-market demand. Global industrial sales benefited segment results due to pricing improvements and strong demand. The segment continues to be impacted by ongoing supply chain constraints for certain components used in our products.

[0001783180-23-000038:mdna:75]
For the three months ended March 31, 2023, Operating profit in our Fire & Security segment was $93 million, a 92% decrease compared with the same period of 2022. The components of the year-over-year change were as follows:

[0001783180-23-000038:mdna:76]
|  |  | Operating Profit |
| Operational |  | — | % |
| Restructuring |  | (1) | % |
| Chubb gain |  | (91) | % |
| Total % change in Operating profit |  | (92) | % |

[0001783180-23-000038:mdna:77]
Operational profit was flat compared to the prior year as each of the segment's businesses was impacted by the higher costs of commodities and components used in our products as well as higher freight and logistics costs. These amounts were offset by pricing improvements, volume growth and ongoing productivity initiatives. Inflationary cost pressures have moderated, but remain elevated and continue to impact our operating profit. Amounts reported in Other represent the net gain on the Chubb Sale of $1.1 billion.

[0001783180-23-000038:mdna:78]
[same as prior period, unchanged from 0001783180-22-000056:mdna:142]

[0001783180-23-000038:mdna:79]
[same as prior period, unchanged from 0001783180-22-000056:mdna:143]

[0001783180-23-000038:mdna:80]
As of March 31, 2023, we had cash and cash equivalents of $3.3 billion, of which approximately 37% was held by our foreign subsidiaries. We manage our worldwide cash requirements by reviewing available funds and the cost effectiveness with which we can access funds held by foreign subsidiaries. On occasion, we are required to maintain cash deposits in connection with contractual obligations related to acquisitions, divestitures or other legal obligations. As of March 31, 2023 and December 31, 2022, the amount of such restricted cash was approximately $7 million and $39 million, respectively.

[0001783180-23-000038:mdna:81]
We maintain a $2.0 billion unsecured, unsubordinated commercial paper program which can be used for general corporate purposes, including the funding of working capital and potential acquisitions. In addition, we maintain our $2.0 billion revolving credit agreement with various banks (the "Revolving Credit Facility") that matures on April 3, 2025 which supports

[0001783180-23-000038:mdna:82]
our commercial paper borrowing program and cash requirements. A commitment fee of 0.125% is charged on unused commitments. Borrowings under the Revolving Credit Facility are available in U.S. Dollars, Euros and Pounds Sterling. As of March 31, 2023, we had no borrowings outstanding under our commercial paper program and our Revolving Credit Facility.

[0001783180-23-000038:mdna:83]
[same as prior period, unchanged from 0001783180-22-000056:mdna:147]

[0001783180-23-000038:mdna:84]
We believe that our available cash and operating cash flows will be sufficient to meet our future operating cash needs. Our committed credit facilities and access to the debt and equity markets provide additional sources of short-term and long-term capital to fund current operations, debt maturities and future investment opportunities. Although we believe that the arrangements currently in place permit us to finance our operations on acceptable terms and conditions, our access to and the availability of financing on acceptable terms and conditions in the future will be impacted by many factors, including: (1) our credit ratings or absence of credit ratings, (2) the liquidity of the overall capital markets and (3) the state of the economy. There can be no assurance that we will be able to obtain additional financing on terms favorable to us, if at all.

[0001783180-23-000038:mdna:85]
[same as prior period, unchanged from 0001783180-22-000056:mdna:154]

[0001783180-23-000038:mdna:86]
| (In millions) |  | March 31,2023 |  | December 31,2022 |
| Cash and cash equivalents |  | $ | 3,347 |  |  | $ | 3,520 |  |
| Total debt |  | $ | 8,850 |  |  | $ | 8,842 |  |
| Total equity |  | $ | 8,468 |  |  | $ | 8,076 |  |
| Net debt (total debt less cash and cash equivalents) |  | $ | 5,503 |  |  | $ | 5,322 |  |
| Total capitalization (total debt plus total equity) |  | $ | 17,318 |  |  | $ | 16,918 |  |
| Net capitalization (total debt plus total equity less cash and cash equivalents) |  | $ | 13,971 |  |  | $ | 13,398 |  |
| Total debt to total capitalization |  | 51 | % |  | 52 | % |
| Net debt to net capitalization |  | 39 | % |  | 40 | % |

[0001783180-23-000038:mdna:87]
[same as prior period, unchanged from 0001783180-22-000056:mdna:157]

[0001783180-23-000038:mdna:88]
Our short-term obligations primarily consist of current maturities of long-term debt. Our long-term obligations primarily consist of long-term notes with maturity dates ranging between 2025 and 2050. Interest payments related to long-term Notes are expected to approximate $249 million per year, reflecting an approximate weighted-average interest rate of 2.85%. Any borrowings from the Revolving Credit Facility are subject to variable interest rates. See Note 5 – Borrowings and Lines of Credit in the Notes to the accompanying Unaudited Condensed Consolidated Financial Statements for additional information regarding the terms of our long-term debt obligations.

[0001783180-23-000038:mdna:89]
[same as prior period, unchanged from 0001783180-22-000056:mdna:159]

[0001783180-23-000038:mdna:90]
On July 15, 2022, we entered into a five-year, JPY 54 billion (approximately $400 million) senior unsecured term loan facility with MUFG Bank Ltd., as administrative agent and lender, and certain other lenders (the "Japanese Term Loan Facility"). Borrowings bear interest at a rate equal to the Tokyo Term Risk Free Rate plus 0.75%. In addition, it is subject to customary covenants including a covenant to maintain a maximum consolidated leverage ratio. On July 25, 2022, we borrowed JPY 54 billion under the Japanese Term Loan Facility and used the proceeds to fund a portion of the TCC acquisition and to pay

[0001783180-23-000038:mdna:91]
related fees and expenses.

[0001783180-23-000038:mdna:92]
The Revolving Credit Facility, the Japanese Term Loan Facility and the indentures for the long-term notes contain affirmative and negative covenants customary for financings of these types, which among other things, limit our ability to incur additional liens, to make certain fundamental changes and to enter into sale and leaseback transactions. As of March 31, 2023, we were compliant with the covenants under the agreements governing our outstanding indebtedness.

[0001783180-23-000038:mdna:93]
The following table presents our credit ratings and outlook as of March 31, 2023:

[0001783180-23-000038:mdna:94]
| Rating Agency |  | Long-term Rating (1) |  | Short-term Rating |  | Outlook (2) (3) |
| Standards & Poor's ("S&P") |  | BBB |  | A2 |  | Positive |
| Moody's Investors Service Inc. ("Moody's") |  | Baa3 |  | P3 |  | Positive |
| Fitch Ratings ("Fitch") |  | BBB- |  | F3 |  | Stable |

[0001783180-23-000038:mdna:95]
[same as prior period, unchanged from 0001783180-22-000056:mdna:152]

[0001783180-23-000038:mdna:96]
[same as prior period, unchanged from 0001783180-22-000056:mdna:153]

[0001783180-23-000038:mdna:97]
(3) Moody's Investors Service revised its outlook to positive from stable on February 28, 2023.

[0001783180-23-000038:mdna:98]
[same as prior period, unchanged from 0001783180-22-000056:mdna:164]

[0001783180-23-000038:mdna:99]
We may repurchase our outstanding common stock from time to time subject to market conditions and at our discretion. Repurchases occur in the open market or through one or more other public or private transactions pursuant to plans complying with Rules 10b5-1 and 10b-18 under the Exchange Act. Since the initial authorization in February 2021, our Board of Directors authorized the repurchase of up to $4.1 billion of our outstanding common stock. As of December 31, 2022, we repurchased 42.1 million  shares of common stock for an aggregate purchase price of $1.9 billion, including shares repurchased under an accelerated share repurchase agreement. As a result, we had approximately $2.2 billion remaining under the current authorization at December 31, 2022.

[0001783180-23-000038:mdna:100]
During the three months ended March 31, 2023, we repurchased 1.4 million shares of common stock for an aggregate purchase price of $62 million. As a result, we have approximately $2.1 billion remaining under the current authorization at March 31, 2023.

[0001783180-23-000038:mdna:101]
[same as prior period, unchanged from 0001783180-22-000056:mdna:166]

[0001783180-23-000038:mdna:102]
We paid dividends on common stock during the three months ended March 31, 2023, totaling $154 million. In April 2023, the Board of Directors declared a dividend of $0.185 per share of common stock payable on May 24, 2023 to shareowners of record at the close of business on May 5, 2023.

[0001783180-23-000038:mdna:103]
[same as prior period, unchanged from 0001783180-22-000056:mdna:169]

[0001783180-23-000038:mdna:104]
|  |  | Three Months Ended March 31, |
| (In millions) |  | 2023 |  | 2022 |
| Net cash flows provided by (used in): |  |  |  |  |
| Operating activities |  | $ | 120 |  |  | $ | (202) |  |
| Investing activities |  | (100) |  |  | 2,820 |  |
| Financing activities |  | (213) |  |  | (2,020) |  |
| Effect of foreign exchange rate changes on cash and cash equivalents |  | 20 |  |  | (1) |  |
| Net increase (decrease) in cash and cash equivalents and restricted cash |  | $ | (173) |  |  | $ | 597 |  |

[0001783180-23-000038:mdna:105]
Cash flows from operating activities primarily represent inflows and outflows associated with our operations. Primary activities include net income from operations adjusted for non-cash transactions, working capital changes and changes in other assets and liabilities. The year-over-year increase in net cash provided by operating activities was primarily driven by a more moderate increase in working capital balances compared with the prior period. Prior year working capital balances increased due to higher safety stock and supply chain constraints. In addition, higher accounts payable balances more than offset higher accounts receivable balances in the current period.

[0001783180-23-000038:mdna:106]
Cash flows from investing activities primarily represent inflows and outflows associated with long-term assets. Primary activities include capital expenditures, acquisitions, divestitures and proceeds from the sale of fixed assets. During the three months ended March 31, 2023, net cash used in investing activities was $100 million. The primary driver of the outflow related to $70 million of capital expenditures. In addition, we settled working capital and other transaction-related items associated with the acquisition of TCC and invested in several businesses. These amounts totaled $52 million, net of cash acquired and were partially offset by the proceeds from the sale of a business during the period. During the three months ended March 31, 2022, net cash provided by investing activities was $2.8 billion. The primary driver of the inflow related to the net proceeds from the Chubb Sale. This amount was partially offset by the acquisition of several businesses and minority-owned businesses, which totaled $9 million net of cash acquired and $56 million of capital expenditures.

[0001783180-23-000038:mdna:107]
Cash flows from financing activities primarily represent inflows and outflows associated with equity or borrowings. During the three months ended March 31, 2023, net cash used in financing activities was $213 million. The primary driver of the outflow related to the payment of $154 million in dividends to our common shareowners. In addition, we paid $62 million to repurchase shares of our common stock. During the three months ended March 31, 2022, net cash used in financing activities was $2.0 billion. The primary driver of the outflow related to the settlement of our tender offers for $1.15 billion. In addition, we paid $129 million in dividends to our common shareowners and paid $734 million to repurchase shares of our common stock.
