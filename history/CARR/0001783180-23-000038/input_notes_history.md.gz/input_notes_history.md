# CARR note change history — 0001783180-22-000056 → 0001783180-23-000038


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-04-26):
[0001783180-23-000038:note_history:1]
COMMITMENTS AND CONTINGENT LIABILITIES
The Company is involved in various litigation, claims and administrative proceedings, including those related to environmental (including asbestos) and legal matters. In accordance with ASC 450, Contingencies, the Company records accruals for loss contingencies when it is probable that a liability will be incurred and the amount of the loss can be reasonably estimated. These accruals are generally based upon a range of possible outcomes. If no amount within the range is a better estimate than any other, the Company accrues the minimum amount. In addition, these estimates are reviewed periodically and adjusted to reflect additional information when it becomes available. The Company is unable to predict the final outcome of the following matters based on the information currently available, except as otherwise noted. However, the Company does not believe that the resolution of any of these matters will have a material adverse effect upon its results of operations, cash flows or financial condition.
  (was, 2022-10-27, similarity 0.9614):
[0001783180-22-000056:note_history:1]
COMMITMENTS AND CONTINGENT LIABILITIES
The Company is involved in various litigation, claims and administrative proceedings, including those related to environmental (including asbestos) and legal matters. In accordance with ASC 450, Contingencies, the Company records accruals for loss contingencies when it is probable that a liability will be incurred and the amount of the loss can be reasonably estimated. These accruals are generally based upon a range of possible outcomes. If no amount within the range is a better estimate than any other, the Company accrues the minimum amount. In addition, these estimates are reviewed periodically and adjusted to reflect additional information when it becomes available. The Company is unable to predict the final outcome of the following matters based on the information currently available, except as otherwise noted. However, the Company does not believe that the resolution of any of these matters will have a material adverse effect upon the Company's competitive position, results of operations, cash flows or financial condition.

- changed (2023-04-26):
[0001783180-23-000038:note_history:2]
The Company’s operations are subject to environmental regulation by various authorities. The Company has accrued for the costs of environmental remediation activities, including but not limited to investigatory, remediation, operating and maintenance costs and performance guarantees. The most likely cost to be incurred is accrued based on an evaluation of currently available facts with respect to individual sites, including the technology required to remediate, current laws and regulations and prior remediation experience.
  (was, 2022-10-27, similarity 0.9962):
[0001783180-22-000056:note_history:2]
The Company’s operations are subject to environmental regulation by various authorities. The Company has accrued for the costs of environmental remediation activities, including but not limited to investigatory, remediation, operating and maintenance costs and performance guarantees. The most likely cost to be incurred is accrued based on an evaluation of currently available facts with respect to individual sites, including technology required to remediate, current laws and regulations and prior remediation experience.

- changed (2023-04-26):
[0001783180-23-000038:note_history:3]
| (In millions) |  | March 31,2023 |  | December 31, 2022 |
| Environmental reserves included in Accrued liabilities |  | $ | 19 |  |  | $ | 24 |  |
| Environmental reserves included in Other long-term liabilities |  | 214 |  |  | 211 |  |
| Total Environmental reserves |  | $ | 233 |  |  | $ | 235 |  |
  (was, 2022-10-27, similarity 0.9742):
[0001783180-22-000056:note_history:3]
| (In millions) |  | September 30,2022 |  | December 31, 2021 |
| Environmental reserves included in Accrued liabilities |  | $ | 29 |  |  | $ | 29 |  |
| Environmental reserves included in Other long-term liabilities |  | 203 |  |  | 191 |  |
| Total Environmental reserves |  | $ | 232 |  |  | $ | 220 |  |

- changed (2023-04-26):
[0001783180-23-000038:note_history:4]
| (In millions) |  | March 31,2023 |  | December 31,2022 |
| Asbestos liabilities included in Accrued liabilities |  | $ | 16 |  |  | $ | 16 |  |
| Asbestos liabilities included in Other long-term liabilities |  | 211 |  |  | 212 |  |
| Total Asbestos liabilities |  | $ | 227 |  |  | $ | 228 |  |
| Asbestos-related recoveries included in Other assets, current |  | $ | 5 |  |  | $ | 5 |  |
| Asbestos-related recoveries included in Other assets |  | 89 |  |  | 90 |  |
| Total Asbestos-related recoveries |  | $ | 94 |  |  | $ | 95 |  |
  (was, 2022-10-27, similarity 0.9877):
[0001783180-22-000056:note_history:4]
| (In millions) |  | September 30,2022 |  | December 31,2021 |
| Asbestos liabilities included in Accrued liabilities |  | $ | 17 |  |  | $ | 17 |  |
| Asbestos liabilities included in Other long-term liabilities |  | 214 |  |  | 220 |  |
| Total Asbestos liabilities |  | $ | 231 |  |  | $ | 237 |  |
| Asbestos-related recoveries included in Other assets, current |  | $ | 5 |  |  | $ | 5 |  |
| Asbestos-related recoveries included in Other assets |  | 91 |  |  | 93 |  |
| Total Asbestos-related recoveries |  | $ | 96 |  |  | $ | 98 |  |

- changed (2023-04-26):
[0001783180-23-000038:note_history:5]
The amounts recorded for asbestos-related liabilities are based on currently available information and assumptions that the Company believes are reasonable and are made with input from outside actuarial experts. These amounts are undiscounted and exclude the Company’s legal fees to defend the asbestos claims, which are expensed as incurred. In addition, the Company has recorded insurance recovery receivables for probable asbestos-related recoveries.
  (was, 2022-10-27, similarity 0.7039):
[0001783180-22-000056:note_history:5]
The amounts recorded for asbestos-related liabilities are based on currently available information and assumptions that the Company believes are reasonable and are made with input from outside actuarial experts. These amounts are undiscounted and

- changed (2023-04-26):
[0001783180-23-000038:note_history:6]
On August 12, 2020, several former employees of UTC or its subsidiaries filed a putative class action complaint (the "Complaint") in the United States District Court for the District of Connecticut against Raytheon Technologies Corporation ("Raytheon"), Carrier, Otis Worldwide Corporation ("Otis"), the former members of the UTC Board of Directors and the members of the Carrier and Otis Boards of Directors (Geraud Darnis, et al. v. Raytheon Technologies Corporation, et al.). The Complaint challenged the method by which UTC equity awards were converted to UTC, Carrier and Otis equity awards following the Separation and the Distribution. Defendants moved to dismiss the Complaint. Plaintiffs amended their Complaint on September 13, 2021 (the "Amended Complaint"). The Amended Complaint, with Raytheon, Carrier and Otis as the only defendants, asserted that the defendants are liable for breach of certain equity compensation plans and for breach of the implied covenant of good faith and fair dealing. The Amended Complaint also sought specific performance. The Company believes all plaintiffs' claims against it are without merit. Defendants moved to dismiss the Amended Complaint. On September 30, 2022, the court dismissed the case against all defendants, with prejudice. Plaintiffs appealed the dismissal to the United States Court of Appeals for the Second Circuit. Oral arguments on the appeal is scheduled to occur before the Second Circuit on June 29, 2023.
  (was, 2022-10-27, similarity 0.6742):
[0001783180-22-000056:note_history:6]
On August 12, 2020, several former employees of UTC or its subsidiaries filed a putative class action complaint (the "Complaint") in the United States District Court for the District of Connecticut against Raytheon Technologies Corporation, Carrier, Otis, the former members of the UTC Board of Directors and the members of the Carrier and Otis Boards of Directors (Geraud Darnis, et al. v. Raytheon Technologies Corporation, et al.). The Complaint challenges the method by which UTC equity awards were converted to UTC, Carrier and Otis equity awards following the Separation and the Distribution. Defendants moved to dismiss the Complaint. Plaintiffs amended their Complaint on September 13, 2021 (the "Amended Complaint"). The Amended Complaint, now with Raytheon, Carrier and Otis as the only defendants, asserts that the defendants are liable for breach of certain equity compensation plans and for breach of the implied covenant of good faith and fair dealing. The Amended Complaint also seeks specific performance. Carrier believes that the claims against the Company are without merit. Defendants moved to dismiss the Amended Complaint on October 13, 2021. The motion to dismiss was fully briefed as of December 3, 2021 and the court held oral argument on the motion on July 14, 2022. On September 30, 2022, the court dismissed the complaint against all defendants, with prejudice. The court entered judgment for the defendants on October 4, 2022. The deadline for seeking appellate review of the ruling is November 3, 2022.

- added (2023-04-26):
[0001783180-23-000038:note_history:7]
As of March 31, 2023,  the Company and certain  of its subsidiaries, including Kidde-Fenwal, Inc. ("KFI"), have been named as defendants in more than 3,800 lawsuits filed by individuals in or removed to the federal courts of the United States alleging that the historic use of Aqueous Film Forming Foam ("AFFF") caused personal injuries and/or property damage. The Company and certain of its subsidiaries, including KFI, have also been named as a defendant in more than 370 lawsuits filed by several U.S. states, municipalities and water utilities in or removed to U.S. federal courts alleging that the historic use of AFFF caused contamination of property and water supplies. In December 2018, the U.S. Judicial Panel on Multidistrict Litigation transferred and consolidated all AFFF cases pending in the U.S. federal courts against the Company and others to the U.S. District Court for the District of South Carolina ("MDL Court") for pre-trial proceedings ("MDL Proceedings"). The individual plaintiffs in the MDL Proceedings generally seek damages for alleged personal injuries, medical monitoring, diminution in property value and injunctive relief to remediate alleged contamination of water supplies. The U.S. state, municipal and water utility plaintiffs in the MDL Proceedings generally seek damages and costs related to the remediation of public property and water supplies.

- added (2023-04-26):
[0001783180-23-000038:note_history:8]
AFFF is a firefighting foam, developed beginning in the late 1960s pursuant to U.S. military specification, used to extinguish certain types of hydrocarbon-fueled fires primarily at military bases and airports. AFFF was manufactured by several companies, including National Foam and Angus Fire. UTC subsidiaries first entered the AFFF business with their acquisition of National Foam and Angus Fire in 2005 as part of the acquisition of KFI and Kidde Products Limited ("KPL"). In 2013, KFI and KPL divested the National Foam and Angus Fire businesses to a third party. The Company acquired KFI and KPL as part of the Separation in April 2020. During the eight-year period of its operation by KFI, National Foam manufactured AFFF for sale to government (including the U.S. federal government) and non-government customers in the U.S. at a single facility located in

- added (2023-04-26):
[0001783180-23-000038:note_history:9]
West Chester, Pennsylvania ("Pennsylvania Site"). During the same period, Angus Fire manufactured AFFF for sale outside the United States at a single facility located in Bentham, England.

- changed (2023-04-26):
[0001783180-23-000038:note_history:10]
The key components of AFFF that contribute to its fire-extinguishing capabilities are known as fluorosurfactants. Neither the Company nor any of its former or current subsidiaries, including National Foam/Angus Fire and KFI/KPL, respectively, manufactured fluorosurfactants; they instead purchased these substances from unrelated third parties to, in turn, manufacture AFFF. Plaintiffs in the MDL Proceedings allege that the fluorosurfactants used by various manufacturers in producing AFFF contained, or over time degraded into, compounds known as perflourooctane sulfonate ("PFOS") and/or perflourooctane acid ("PFOA"). Plaintiffs further allege that, as a result of the use of AFFF, PFOS and PFOA were released into the environment and, in some instances, ultimately reached drinking water supplies.
  (was, 2022-10-27, similarity 0.8235):
[0001783180-22-000056:note_history:10]
The key components of AFFF that contribute to its fire-extinguishing capabilities are known as fluorosurfactants. National Foam and Angus Fire did not manufacture fluorosurfactants but instead purchased these substances from unrelated third parties. Plaintiffs in the MDL Proceedings allege that the fluorosurfactants used by various manufacturers in producing AFFF contained, or over time degraded into, compounds known as perflourooctane sulfonate ("PFOS") and/or perflourooctane acid ("PFOA"). Plaintiffs further allege that, as a result of the use of AFFF, PFOS and PFOA were released into the environment and, in some instances, ultimately reached drinking water supplies.

- changed (2023-04-26):
[0001783180-23-000038:note_history:11]
Plaintiffs in the MDL Proceedings have named multiple defendants, including four suppliers of chemicals and raw materials used to manufacture fluorosurfactants, four fluorosurfactant manufacturers, two toll manufacturers of fluorosurfactants and seven current (including National Foam and Angus Fire) and former (including the Company and KFI) AFFF manufacturers.
  (was, 2022-10-27, similarity 0.9889):
[0001783180-22-000056:note_history:11]
Plaintiffs in the MDL Proceedings have named multiple defendants, including four suppliers of chemicals and raw materials used to manufacture fluorosurfactants, four fluorosurfactant manufacturers, two toll manufacturers of fluorosurfactants and seven current (including National Foam and Angus Fire) and former (including the Company) AFFF manufacturers.

- changed (2023-04-26):
[0001783180-23-000038:note_history:12]
On September 23, 2022, after completion of discovery, the MDL court selected one water provider case, the City of Stuart, FL v. 3M, et al., for a bellwether trial. That trial is scheduled for June 2023. The MDL court has ordered that the bellwether process for personal injury cases will begin in 2023. The court has not yet outlined details on that process or its timing.
  (was, 2022-10-27, similarity 0.8054):
[0001783180-22-000056:note_history:12]
On September 23, 2022, after completion of discovery, the MDL court selected one water provider case, the City of Stuart, FL v. 3M, et al., for a bellwether trial. That trial is tentatively scheduled for June 2023. The court has set a briefing schedule for case-specific summary judgment motions and other pretrial motions. That briefing is expected to conclude in February 2023. The MDL court has ordered that the bellwether process for personal injury cases will begin in 2023. The court has not yet outlined details on that process or its timing.

- added (2023-04-26):
[0001783180-23-000038:note_history:13]
The Company and its subsidiaries, including KFI, and other defendants are also party to one action in Arizona state court brought by a firefighter claiming that occupational exposure to AFFF has caused him certain personal injuries. The Company and its subsidiaries, including KFI, believe that they have meritorious defenses to the claims in the MDL Proceedings and the other AFFF lawsuits. Based on its 2013 agreement for the sale of National Foam and Angus Fire, the Company and its subsidiaries, including KFI, are pursuing indemnification against these claims from the purchaser and current owner of National Foam and Angus Fire. The Company and its subsidiaries, including KFI, are also pursuing insurance coverage for these claims. At this time, however, given the numerous factual, scientific and legal issues to be resolved relating to these claims, the Company is unable to assess the probability of liability or to reasonably estimate the damages, if any, to be allocated to the Company and its subsidiaries, including KFI, if one or more plaintiffs were to prevail in these cases. There can be no assurance that any such future exposure will not be material in any period.

- changed (2023-04-26):
[0001783180-23-000038:note_history:14]
Under the Tax Matters Agreement relating to the Separation, the Company is responsible to UTC for its share of the Tax Cuts and Jobs Act transition tax associated with foreign undistributed earnings as of December 31, 2017. As a result, liabilities of $49 million and $368 million are included within the accompanying Unaudited Condensed Consolidated Balance Sheet within Accrued Liabilities and Other Long-Term Liabilities as of March 31, 2023, respectively. This obligation is expected to be settled in annual installments ending in April 2026 with the next installment of $49 million due in 2023. The Company believes that the likelihood of incurring losses materially in excess of this amount is remote.
  (was, 2022-10-27, similarity 0.9833):
[0001783180-22-000056:note_history:14]
Under the Tax Matters Agreement relating to the Separation, the Company is responsible to UTC for its share of the Tax Cuts and Jobs Act ("TCJA") transition tax associated with foreign undistributed earnings as of December 31, 2017. As a result, liabilities of $34 million and $383 million are included within the accompanying Unaudited Condensed Consolidated Balance Sheet within Accrued Liabilities and Other Long-Term Liabilities as of September 30, 2022, respectively. This obligation is expected to be settled in annual installments ending in April 2026 with the next installment of $34 million due in 2023. The Company believes that the likelihood of incurring losses materially in excess of this amount is remote.

- changed (2023-04-26):
[0001783180-23-000038:note_history:15]
In the ordinary course of business, the Company is also routinely a defendant in, party to or otherwise subject to many pending and threatened legal actions, claims, disputes and proceedings. These matters are often based on alleged violations of contract, product liability, warranty, regulatory, environmental, health and safety, employment, intellectual property, tax and other laws. In some of these proceedings, claims for substantial monetary damages are asserted against the Company and could result in fines, penalties, compensatory or treble damages or non-monetary relief. The Company does not believe that these matters will have a material adverse effect upon its results of operations, cash flows or financial condition.
  (was, 2022-10-27, similarity 0.9852):
[0001783180-22-000056:note_history:15]
In the ordinary course of business, the Company is also routinely a defendant in, party to or otherwise subject to many pending and threatened legal actions, claims, disputes and proceedings. These matters are often based on alleged violations of contract, product liability, warranty, regulatory, environmental, health and safety, employment, intellectual property, tax and other laws. In some of these proceedings, claims for substantial monetary damages are asserted against the Company and could result in fines, penalties, compensatory or treble damages or non-monetary relief. The Company does not believe that these matters will have a material adverse effect upon its competitive position, results of operations, cash flows or financial condition.

- removed (2023-04-26):
[0001783180-22-000056:note_history:16]
exclude the Company’s legal fees to defend the asbestos claims, which are expensed as incurred. In addition, the Company has recorded insurance recovery receivables for probable asbestos-related recoveries.

- removed (2023-04-26):
[0001783180-22-000056:note_history:17]
As of September 30, 2022, the Company has been named as a defendant in more than 2,800 lawsuits filed by individuals in or removed to the federal courts of the United States alleging that the historic use of Aqueous Film Forming Foam ("AFFF") caused personal injuries and/or property damage. The Company has also been named as a defendant in more than 250 lawsuits filed by several U.S. states, municipalities and water utilities in or removed to U.S. federal courts alleging that the historic use of AFFF caused contamination of property and water supplies. In December 2018, the U.S. Judicial Panel on Multidistrict Litigation transferred and consolidated all AFFF cases pending in the U.S. federal courts against the Company and others to the U.S. District Court for the District of South Carolina ("MDL Court") for pre-trial proceedings ("MDL Proceedings"). The individual plaintiffs in the MDL Proceedings generally seek damages for alleged personal injuries, medical monitoring and diminution in property value and injunctive relief to remediate alleged contamination of water supplies. The U.S. state, municipal and water utility plaintiffs in the MDL Proceedings generally seek damages and costs related to the remediation of public property and water supplies.

- removed (2023-04-26):
[0001783180-22-000056:note_history:18]
AFFF is a firefighting foam, developed beginning in the late 1960s pursuant to U.S. military specification, used to extinguish certain types of hydrocarbon-fueled fires primarily at military bases and airports. AFFF was manufactured by several companies, including National Foam and Angus Fire. UTC first entered the AFFF business with the acquisition of National Foam and Angus Fire in 2005 as part of the acquisition of Kidde. In 2013, Kidde divested the National Foam and Angus Fire businesses to a third party. The Company acquired Kidde as part of its separation from UTC in April 2020. During the eight-year period of its operation by Kidde, National Foam manufactured AFFF for sale to government (including the U.S. federal government) and non-government customers in the U.S. at a single facility located in West Chester, Pennsylvania ("Pennsylvania Site"). During the same period, Angus Fire manufactured AFFF for sale outside the United States at a single facility located in Bentham, England.

- removed (2023-04-26):
[0001783180-22-000056:note_history:19]
The Company and other defendants are also party to one action in Arizona state court brought by a firefighter claiming that occupational exposure to AFFF has caused him certain personal injuries. That case is not eligible for transfer to the MDL at this time. The Company believes that it has meritorious defenses to the claims in the MDL Proceedings and the other AFFF lawsuits. Based on the 2013 agreement for the sale of National Foam and Angus Fire, the Company is pursuing indemnification against these claims from the purchaser and current owner of National Foam and Angus Fire. The Company also is pursuing insurance coverage for these claims. At this time, however, given the numerous factual, scientific and legal issues to be resolved relating to these claims, the Company is unable to assess the probability of liability or to reasonably estimate the damages, if any, to be allocated to the Company, if one or more plaintiffs were to prevail in these cases. There can be no assurance that any such future exposure will not be material in any period.


## us-gaap:ScheduleOfEnvironmentalLossContingenciesBySiteTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-04-26):
[0001783180-23-000038:note_history:20]
| (In millions) |  | March 31,2023 |  | December 31, 2022 |
| Environmental reserves included in Accrued liabilities |  | $ | 19 |  |  | $ | 24 |  |
| Environmental reserves included in Other long-term liabilities |  | 214 |  |  | 211 |  |
| Total Environmental reserves |  | $ | 233 |  |  | $ | 235 |  |
  (was, 2022-10-27, similarity 0.9742):
[0001783180-22-000056:note_history:20]
| (In millions) |  | September 30,2022 |  | December 31, 2021 |
| Environmental reserves included in Accrued liabilities |  | $ | 29 |  |  | $ | 29 |  |
| Environmental reserves included in Other long-term liabilities |  | 203 |  |  | 191 |  |
| Total Environmental reserves |  | $ | 232 |  |  | $ | 220 |  |


## us-gaap:ScheduleOfLossContingenciesByContingencyTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-04-26):
[0001783180-23-000038:note_history:21]
| (In millions) |  | March 31,2023 |  | December 31,2022 |
| Asbestos liabilities included in Accrued liabilities |  | $ | 16 |  |  | $ | 16 |  |
| Asbestos liabilities included in Other long-term liabilities |  | 211 |  |  | 212 |  |
| Total Asbestos liabilities |  | $ | 227 |  |  | $ | 228 |  |
| Asbestos-related recoveries included in Other assets, current |  | $ | 5 |  |  | $ | 5 |  |
| Asbestos-related recoveries included in Other assets |  | 89 |  |  | 90 |  |
| Total Asbestos-related recoveries |  | $ | 94 |  |  | $ | 95 |  |
  (was, 2022-10-27, similarity 0.9877):
[0001783180-22-000056:note_history:21]
| (In millions) |  | September 30,2022 |  | December 31,2021 |
| Asbestos liabilities included in Accrued liabilities |  | $ | 17 |  |  | $ | 17 |  |
| Asbestos liabilities included in Other long-term liabilities |  | 214 |  |  | 220 |  |
| Total Asbestos liabilities |  | $ | 231 |  |  | $ | 237 |  |
| Asbestos-related recoveries included in Other assets, current |  | $ | 5 |  |  | $ | 5 |  |
| Asbestos-related recoveries included in Other assets |  | 91 |  |  | 93 |  |
| Total Asbestos-related recoveries |  | $ | 96 |  |  | $ | 98 |  |


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2023-04-26):
[0001783180-23-000038:note_history:22]
BASIS OF PRESENTATION
The Unaudited Condensed Consolidated Financial Statements include all accounts of the Company and its wholly-owned and majority-owned subsidiaries in which it has control. Inter-company accounts and transactions have been eliminated. Related party transactions between the Company and its equity method investees have not been eliminated. Non-controlling interest represents a non-controlling investor's interests in the results of subsidiaries that the Company controls and consolidates.
  (was, 2022-10-27, similarity 0.9863):
[0001783180-22-000056:note_history:22]
BASIS OF PRESENTATION
The Unaudited Condensed Consolidated Financial Statements include all accounts of the Company and its wholly-owned and majority-owned subsidiaries in which it has control. All intra-company accounts and transactions have been eliminated. Related party transactions between the Company and its equity method investees have not been eliminated. Non-controlling interest represents a non-controlling investor's interests in the results of subsidiaries that the Company controls and consolidates.

- changed (2023-04-26):
[0001783180-23-000038:note_history:23]
On February 6, 2022, the Company entered into a binding agreement to acquire a majority ownership interest in Toshiba Carrier Corporation (“TCC”), a variable refrigerant flow ("VRF") and light commercial HVAC joint venture between Carrier and Toshiba Corporation. The acquisition was completed on August 1, 2022. As a result, the assets, liabilities and results of operations of TCC are consolidated in the accompanying Unaudited Condensed Consolidated Financial Statements as of the date of acquisition and reported within the Company’s HVAC segment. Upon closing, Toshiba Corporation retained a 5% ownership interest in TCC. See Note 15 – Acquisitions for additional information.
  (was, 2022-10-27, similarity 0.9703):
[0001783180-22-000056:note_history:23]
On February 6, 2022, the Company entered into a binding agreement to acquire a majority ownership interest in Toshiba Carrier Corporation (“TCC”), a variable refrigerant flow ("VRF") and light commercial HVAC joint venture between Carrier and Toshiba Corporation. The acquisition was completed on August 1, 2022, subject to customary closing conditions. As a result, the assets, liabilities and results of operations of TCC are consolidated in the accompanying Unaudited Condensed Consolidated Financial Statements as of the date of acquisition and reported within the Company’s HVAC segment. Upon closing, Toshiba Corporation retained a 5% ownership interest in TCC. See Note 15 – Acquisitions for additional information.

- added (2023-04-26):
[0001783180-23-000038:note_history:24]
On July 26, 2021, the Company entered into a stock purchase agreement to sell its Chubb Fire and Security business ("Chubb") to APi Group Corporation ("APi"). Chubb, which was reported within the Company’s Fire & Security segment, delivered essential fire safety and security solutions from design and installation to monitoring, service and maintenance across more than 17 countries around the globe. The sale of Chubb was completed on January 3, 2022 (the "Chubb Sale"). See Note 16 - Divestitures for additional information.

- added (2023-04-26):
[0001783180-23-000038:note_history:25]
On April 3, 2020 (the Distribution Date"), United Technologies Corporation, since renamed Raytheon Technologies Corporation ("UTC"), completed the spin-off of Carrier into an independent, publicly traded company (the "Separation") through a pro-rata distribution (the "Distribution") on a one-for-one basis of all of the outstanding shares of common stock of Carrier to UTC shareowners who held shares of UTC common stock as of the close of business on March 19, 2020, the record date of the Distribution. In connection with the Separation, the Company issued an aggregate principal balance of $11.0 billion of debt and transferred approximately $10.9 billion of cash to UTC on February 27, 2020 and March 27, 2020. On April 1, 2020 and April 2, 2020, the Company received cash contributions totaling $590 million from UTC related to the Separation.

- removed (2023-04-26):
[0001783180-22-000056:note_history:26]
On July 26, 2021, the Company entered into a stock purchase agreement to sell its Chubb Fire and Security business ("Chubb") to APi Group Corporation ("APi"). As a result, the assets and liabilities of Chubb are presented as held for sale on the accompanying Unaudited Condensed Consolidated Balance Sheet as of December 31, 2021 and recorded at the lower of their carrying value or fair value less estimated cost to sell. The sale of Chubb was completed on January 3, 2022 (the "Chubb Sale"). See Note 16 - Divestitures for additional information.

- removed (2023-04-26):
[0001783180-22-000056:note_history:27]
On April 3, 2020, United Technologies Corporation, since renamed Raytheon Technologies Corporation ("UTC"), completed the spin-off of the Company into an independent, publicly traded company (the "Separation") through a pro-rata distribution (the "Distribution") on a one-for-one basis of all of the outstanding shares of common stock of the Company to UTC shareowners who held shares of UTC common stock as of the close of business on March 19, 2020, the record date of the Distribution. The Company incurred separation-related costs including employee-related costs, costs to establish certain stand-alone functions, information technology systems, professional service fees and other costs associated with becoming an independent, publicly traded company. These costs are primarily recorded in Selling, general and administrative in the accompanying Unaudited Condensed Consolidated Statement of Operations and totaled $19 million for the nine months ended September 30, 2021.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2023-04-26):
[0001783180-23-000038:note_history:28]
DESCRIPTION OF THE BUSINESS 
Carrier Global Corporation (the "Company") is the leading global provider of healthy, safe, sustainable and intelligent building and cold chain solutions with a focus on providing differentiated, digitally-enabled lifecycle solutions to its customers. The Company's portfolio includes industry-leading brands such as Carrier, Toshiba, Automated Logic, Carrier Transicold, Kidde, Edwards and LenelS2 that offer innovative heating, ventilating, air conditioning ("HVAC"), refrigeration, fire, security and building automation technologies to help make the world safer and more comfortable. The Company also provides a broad array of related building services, including audit, design, installation, system integration, repair, maintenance and monitoring. The Company's operations are classified into three segments: HVAC, Refrigeration and Fire & Security.

- removed (2023-04-26):
[0001783180-22-000056:note_history:29]
DESCRIPTION OF THE BUSINESS 
Carrier Global Corporation is the leading global provider of healthy, safe, sustainable and intelligent building and cold chain solutions. The Company's portfolio includes industry-leading brands such as Carrier, Automated Logic, Carrier Transicold, Kidde, Edwards and LenelS2 that offer innovative heating, ventilating, air conditioning ("HVAC"), refrigeration, fire, security and building automation technologies to help make the world safer and more comfortable. The Company also provides a broad array of related building services, including audit, design, installation, system integration, repair, maintenance and monitoring.

- removed (2023-04-26):
[0001783180-22-000056:note_history:30]
Impact of the COVID-19 Pandemic

- removed (2023-04-26):
[0001783180-22-000056:note_history:31]
In early 2020, the World Health Organization declared the outbreak of a respiratory disease known as COVID-19 as a global pandemic. In response, many countries implemented containment and mitigation measures to combat the outbreak, which severely restricted the level of economic activity and caused a significant contraction in the global economy. As a result, the Company took several preemptive actions to manage liquidity, preserve the health and safety of its employees and customers as well as maintain the continuity of its operations. The preparation of financial statements requires management to use judgments in making estimates and assumptions based on the relevant information available at the end of each period, which can have a significant effect on reported amounts. However, due to significant uncertainty surrounding the pandemic, including a resurgence in cases and the spread of COVID-19 variants, management's judgments could change. While the Company's results of operations, cash flows and financial condition could be negatively impacted, the extent of any continuing impact cannot be estimated with certainty at this time.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-04-26):
[0001783180-23-000038:note_history:32]
| (In millions) |  |  |  | March 31,2023 |  | December 31,2022 |
| 2.242% Notes due February 15, 2025 |  |  |  | $ | 1,200 |  |  | $ | 1,200 |  |
| 2.493% Notes due February 15, 2027 |  |  |  | 900 |  |  | 900 |  |
| 2.722% Notes due February 15, 2030 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.700% Notes due February 15, 2031 |  |  |  | 750 |  |  | 750 |  |
| 3.377% Notes due April 5, 2040 |  |  |  | 1,500 |  |  | 1,500 |  |
| 3.577% Notes due April 5, 2050 |  |  |  | 2,000 |  |  | 2,000 |  |
| Total long-term notes |  |  |  | 8,350 |  |  | 8,350 |  |
| Japanese Term Loan Facility |  |  |  | 408 |  |  | 404 |  |
| Other debt (including project financing obligations and finance leases) |  |  |  | 152 |  |  | 149 |  |
| Discounts and debt issuance costs |  |  |  | (60) |  |  | (61) |  |
| Total debt |  |  |  | 8,850 |  |  | 8,842 |  |
| Less: current portion of long-term debt |  |  |  | 142 |  |  | 140 |  |
| Long-term debt, net of current portion |  |  |  | $ | 8,708 |  |  | $ | 8,702 |  |
  (was, 2022-10-27, similarity 0.991):
[0001783180-22-000056:note_history:32]
| (In millions) |  |  |  | September 30,2022 |  | December 31,2021 |
| 2.242% Notes due February 15, 2025 |  |  |  | $ | 1,200 |  |  | $ | 2,000 |  |
| 2.493% Notes due February 15, 2027 |  |  |  | 900 |  |  | 1,250 |  |
| 2.722% Notes due February 15, 2030 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.700% Notes due February 15, 2031 |  |  |  | 750 |  |  | 750 |  |
| 3.377% Notes due April 5, 2040 |  |  |  | 1,500 |  |  | 1,500 |  |
| 3.577% Notes due April 5, 2050 |  |  |  | 2,000 |  |  | 2,000 |  |
| Total long-term Notes |  |  |  | 8,350 |  |  | 9,500 |  |
| Japanese Term Loan Facility |  |  |  | 372 |  |  | — |  |
| Other debt (including project financing obligations and finance leases) |  |  |  | 228 |  |  | 267 |  |
| Discounts and debt issuance costs |  |  |  | (61) |  |  | (71) |  |
| Total debt |  |  |  | 8,889 |  |  | 9,696 |  |
| Less: current portion of long-term debt |  |  |  | 219 |  |  | 183 |  |
| Long-term debt, net of current portion |  |  |  | $ | 8,670 |  |  | $ | 9,513 |  |

- changed (2023-04-26):
[0001783180-23-000038:note_history:33]
On February 10, 2020, the Company entered into a revolving credit agreement with various banks permitting aggregate borrowings of up to $2.0 billion pursuant to an unsecured, unsubordinated revolving credit facility that matures on April 3, 2025 (the "Revolving Credit Facility"). The Revolving Credit Facility supports the Company's commercial paper program and cash requirements. A commitment fee of 0.125% is charged on unused commitments. Borrowings under the Revolving Credit Facility are available in U.S. Dollars, Euros and Pounds Sterling. Pounds Sterling borrowings bear interest at a variable rate based on daily simple SONIA plus 0.0326%, Euro borrowings bear interest at EURIBOR rates and U.S. Dollar borrowings bear interest at LIBOR plus a ratings-based margin, which was 125 basis points as of March 31, 2023. As of March 31, 2023, there were no borrowings outstanding under the Revolving Credit Facility.
  (was, 2022-10-27, similarity 0.646):
[0001783180-22-000056:note_history:33]
On February 10, 2020, the Company entered into a revolving credit agreement with various banks permitting aggregate borrowings of up to $2.0 billion pursuant to an unsecured, unsubordinated revolving credit facility that matures on April 3, 2025 (the "Revolving Credit Facility"). The Revolving Credit Facility supports the Company's commercial paper program and cash requirements of the Company. A commitment fee of 0.125% is charged on unused commitments. Borrowings under the Revolving Credit Facility are available in U.S. Dollars, Euros and Pounds Sterling and bear interest at a variable interest rate plus a ratings-based margin, which was 125 basis points as of September 30, 2022. As of September 30, 2022, there were no borrowings outstanding under the Revolving Credit Facility.

- changed (2023-04-26):
[0001783180-23-000038:note_history:34]
The Company has a $2.0 billion unsecured, unsubordinated commercial paper program, which can be used for general corporate purposes, including the funding of working capital and potential acquisitions. As of March 31, 2023, there were no borrowings outstanding under the commercial paper program.
  (was, 2022-10-27, similarity 0.9759):
[0001783180-22-000056:note_history:34]
The Company has a $2.0 billion unsecured, unsubordinated commercial paper program, which can be used for general corporate purposes, including the funding of working capital and potential acquisitions. As of September 30, 2022, there were no borrowings outstanding under the commercial paper program.

- changed (2023-04-26):
[0001783180-23-000038:note_history:35]
The Company is involved in long-term construction contracts in which it arranges project financing with certain customers. As a result, the Company issued $5 million and $14 million of debt during the three months ended March 31, 2023 and 2022, respectively. Long-term debt repayments associated with these financing arrangements during the three months ended March 31, 2023 and 2022 were $2 million and $8 million, respectively.
  (was, 2022-10-27, similarity 0.8768):
[0001783180-22-000056:note_history:35]
The Company is involved in long-term construction contracts in which it arranges project financing with certain customers. As a result, the Company issued $27 million and $108 million of debt during the nine months ended September 30, 2022 and 2021, respectively. Long-term debt repayments associated with these financing arrangements during the nine months ended September 30, 2022 and 2021 were $70 million and $170 million, respectively.

- changed (2023-04-26):
[0001783180-23-000038:note_history:36]
The Revolving Credit Facility, the indenture for the long-term notes and the Japanese Term Loan Facility contain affirmative and negative covenants customary for financings of these types, which, among other things, limit the Company's ability to incur additional liens, to make certain fundamental changes and to enter into sale and leaseback transactions. As of March 31, 2023, the Company was in compliance with the covenants under the agreements governing its outstanding indebtedness.
  (was, 2022-10-27, similarity 0.9856):
[0001783180-22-000056:note_history:36]
The Revolving Credit Facility, the indenture for the long-term Notes and the Japanese Term Loan Facility contain affirmative and negative covenants customary for financings of these types, which, among other things, limit the Company's ability to incur additional liens, to make certain fundamental changes and to enter into sale and leaseback transactions. As of September 30, 2022, the Company was in compliance with the covenants under the agreements governing its outstanding indebtedness.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-04-26):
[0001783180-23-000038:note_history:37]
| (In millions) |  |  |  | March 31,2023 |  | December 31,2022 |
| 2.242% Notes due February 15, 2025 |  |  |  | $ | 1,200 |  |  | $ | 1,200 |  |
| 2.493% Notes due February 15, 2027 |  |  |  | 900 |  |  | 900 |  |
| 2.722% Notes due February 15, 2030 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.700% Notes due February 15, 2031 |  |  |  | 750 |  |  | 750 |  |
| 3.377% Notes due April 5, 2040 |  |  |  | 1,500 |  |  | 1,500 |  |
| 3.577% Notes due April 5, 2050 |  |  |  | 2,000 |  |  | 2,000 |  |
| Total long-term notes |  |  |  | 8,350 |  |  | 8,350 |  |
| Japanese Term Loan Facility |  |  |  | 408 |  |  | 404 |  |
| Other debt (including project financing obligations and finance leases) |  |  |  | 152 |  |  | 149 |  |
| Discounts and debt issuance costs |  |  |  | (60) |  |  | (61) |  |
| Total debt |  |  |  | 8,850 |  |  | 8,842 |  |
| Less: current portion of long-term debt |  |  |  | 142 |  |  | 140 |  |
| Long-term debt, net of current portion |  |  |  | $ | 8,708 |  |  | $ | 8,702 |  |
  (was, 2022-10-27, similarity 0.991):
[0001783180-22-000056:note_history:37]
| (In millions) |  |  |  | September 30,2022 |  | December 31,2021 |
| 2.242% Notes due February 15, 2025 |  |  |  | $ | 1,200 |  |  | $ | 2,000 |  |
| 2.493% Notes due February 15, 2027 |  |  |  | 900 |  |  | 1,250 |  |
| 2.722% Notes due February 15, 2030 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.700% Notes due February 15, 2031 |  |  |  | 750 |  |  | 750 |  |
| 3.377% Notes due April 5, 2040 |  |  |  | 1,500 |  |  | 1,500 |  |
| 3.577% Notes due April 5, 2050 |  |  |  | 2,000 |  |  | 2,000 |  |
| Total long-term Notes |  |  |  | 8,350 |  |  | 9,500 |  |
| Japanese Term Loan Facility |  |  |  | 372 |  |  | — |  |
| Other debt (including project financing obligations and finance leases) |  |  |  | 228 |  |  | 267 |  |
| Discounts and debt issuance costs |  |  |  | (61) |  |  | (71) |  |
| Total debt |  |  |  | 8,889 |  |  | 9,696 |  |
| Less: current portion of long-term debt |  |  |  | 219 |  |  | 183 |  |
| Long-term debt, net of current portion |  |  |  | $ | 8,670 |  |  | $ | 9,513 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- added (2023-04-26):
[0001783180-23-000038:note_history:38]
|  |  | Three Months Ended March 31, |  |  |
| (In millions) |  | 2023 |  | 2022 |  |  |  |  |
| Sales to equity method investees included in Product sales |  | $ | 754 |  |  | $ | 624 |  |  |  |  |  |
| Purchases from equity method investees included in Cost of products sold |  | $ | 43 |  |  | $ | 110 |  |  |  |  |  |

- added (2023-04-26):
[0001783180-23-000038:note_history:39]
| (In millions) |  | March 31,2023 |  | December 31, 2022 |
| Receivables from equity method investees included in Accounts receivable, net |  | $ | 260 |  |  | $ | 154 |  |
| Payables to equity method investees included in Accounts payable |  | $ | 24 |  |  | $ | 44 |  |

- removed (2023-04-26):
[0001783180-22-000056:note_history:40]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
| (In millions) |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Sales to equity method investees included in Product sales |  | $ | 718 |  |  | $ | 556 |  |  | $ | 2,129 |  |  | $ | 1,675 |  |
| Purchases from equity method investees included in Cost of products sold |  | $ | 60 |  |  | $ | 93 |  |  | $ | 261 |  |  | $ | 266 |  |

- removed (2023-04-26):
[0001783180-22-000056:note_history:41]
| (In millions) |  | September 30,2022 |  | December 31, 2021 |
| Receivables from equity method investees included in Accounts receivable, net |  | $ | 307 |  |  | $ | 150 |  |
| Payables to equity method investees included in Accounts payable |  | $ | 33 |  |  | $ | 51 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-04-26):
[0001783180-23-000038:note_history:42]
|  |  | Three Months Ended March 31, |  |  |
| (In millions) |  | 2023 |  | 2022 |  |  |  |  |
| Sales Type |  |  |  |  |  |  |  |  |
| Product |  | $ | 3,201 |  |  | $ | 2,639 |  |  |  |  |  |
| Service |  | 421 |  |  | 331 |  |  |  |  |  |
| HVAC sales |  | 3,622 |  |  | 2,970 |  |  |  |  |  |
| Product |  | 787 |  |  | 867 |  |  |  |  |  |
| Service |  | 111 |  |  | 109 |  |  |  |  |  |
| Refrigeration sales |  | 898 |  |  | 976 |  |  |  |  |  |
| Product |  | 813 |  |  | 771 |  |  |  |  |  |
| Service |  | 56 |  |  | 47 |  |  |  |  |  |
| Fire & Security sales |  | 869 |  |  | 818 |  |  |  |  |  |
| Total segment sales |  | 5,389 |  |  | 4,764 |  |  |  |  |  |
| Eliminations and other |  | (116) |  |  | (110) |  |  |  |  |  |
| Net sales |  | $ | 5,273 |  |  | $ | 4,654 |  |  |  |  |  |
  (was, 2022-10-27, similarity 0.8487):
[0001783180-22-000056:note_history:42]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
| (In millions) |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Sales Type |  |  |  |  |  |  |  |  |
| Product |  | $ | 3,330 |  |  | $ | 2,702 |  |  | $ | 8,974 |  |  | $ | 7,606 |  |
| Service |  | 404 |  |  | 352 |  |  | 1,118 |  |  | 1,054 |  |
| HVAC sales |  | 3,734 |  |  | 3,054 |  |  | 10,092 |  |  | 8,660 |  |
| Product |  | 811 |  |  | 894 |  |  | 2,603 |  |  | 2,701 |  |
| Service |  | 112 |  |  | 117 |  |  | 337 |  |  | 336 |  |
| Refrigeration sales |  | 923 |  |  | 1,011 |  |  | 2,940 |  |  | 3,037 |  |
| Product |  | 859 |  |  | 1,012 |  |  | 2,468 |  |  | 2,943 |  |
| Service |  | 46 |  |  | 365 |  |  | 142 |  |  | 1,141 |  |
| Fire & Security sales |  | 905 |  |  | 1,377 |  |  | 2,610 |  |  | 4,084 |  |
| Total segment sales |  | 5,562 |  |  | 5,442 |  |  | 15,642 |  |  | 15,781 |  |
| Eliminations and other |  | (111) |  |  | (101) |  |  | (326) |  |  | (301) |  |
| Net sales |  | $ | 5,451 |  |  | $ | 5,341 |  |  | $ | 15,316 |  |  | $ | 15,480 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-04-26):
[0001783180-23-000038:note_history:43]
|  |  | Three Months Ended March 31, |  |  |
| (In millions) |  | 2023 |  | 2022 |  |  |  |  |
| Sales Type |  |  |  |  |  |  |  |  |
| Product |  | $ | 3,201 |  |  | $ | 2,639 |  |  |  |  |  |
| Service |  | 421 |  |  | 331 |  |  |  |  |  |
| HVAC sales |  | 3,622 |  |  | 2,970 |  |  |  |  |  |
| Product |  | 787 |  |  | 867 |  |  |  |  |  |
| Service |  | 111 |  |  | 109 |  |  |  |  |  |
| Refrigeration sales |  | 898 |  |  | 976 |  |  |  |  |  |
| Product |  | 813 |  |  | 771 |  |  |  |  |  |
| Service |  | 56 |  |  | 47 |  |  |  |  |  |
| Fire & Security sales |  | 869 |  |  | 818 |  |  |  |  |  |
| Total segment sales |  | 5,389 |  |  | 4,764 |  |  |  |  |  |
| Eliminations and other |  | (116) |  |  | (110) |  |  |  |  |  |
| Net sales |  | $ | 5,273 |  |  | $ | 4,654 |  |  |  |  |  |
  (was, 2022-10-27, similarity 0.8487):
[0001783180-22-000056:note_history:43]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
| (In millions) |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Sales Type |  |  |  |  |  |  |  |  |
| Product |  | $ | 3,330 |  |  | $ | 2,702 |  |  | $ | 8,974 |  |  | $ | 7,606 |  |
| Service |  | 404 |  |  | 352 |  |  | 1,118 |  |  | 1,054 |  |
| HVAC sales |  | 3,734 |  |  | 3,054 |  |  | 10,092 |  |  | 8,660 |  |
| Product |  | 811 |  |  | 894 |  |  | 2,603 |  |  | 2,701 |  |
| Service |  | 112 |  |  | 117 |  |  | 337 |  |  | 336 |  |
| Refrigeration sales |  | 923 |  |  | 1,011 |  |  | 2,940 |  |  | 3,037 |  |
| Product |  | 859 |  |  | 1,012 |  |  | 2,468 |  |  | 2,943 |  |
| Service |  | 46 |  |  | 365 |  |  | 142 |  |  | 1,141 |  |
| Fire & Security sales |  | 905 |  |  | 1,377 |  |  | 2,610 |  |  | 4,084 |  |
| Total segment sales |  | 5,562 |  |  | 5,442 |  |  | 15,642 |  |  | 15,781 |  |
| Eliminations and other |  | (111) |  |  | (101) |  |  | (326) |  |  | (301) |  |
| Net sales |  | $ | 5,451 |  |  | $ | 5,341 |  |  | $ | 15,316 |  |  | $ | 15,480 |  |

- changed (2023-04-26):
[0001783180-23-000038:note_history:44]
| (In millions) |  | March 31, 2023 |  | December 31, 2022 |
| Contract assets, current |  | $ | 568 |  |  | $ | 537 |  |
| Contract assets, non-current (included within Other assets) |  | 6 |  |  | 6 |  |
| Total contract assets |  | 574 |  |  | 543 |  |
| Contract liabilities, current |  | (516) |  |  | (449) |  |
| Contract liabilities, non-current (included within Other long-term liabilities) |  | (174) |  |  | (174) |  |
| Total contract liabilities |  | (690) |  |  | (623) |  |
| Net contract assets (liabilities) |  | $ | (116) |  |  | $ | (80) |  |
  (was, 2022-10-27, similarity 0.9695):
[0001783180-22-000056:note_history:44]
| (In millions) |  | September 30, 2022 |  | December 31, 2021 |
| Contract assets, current |  | $ | 666 |  |  | $ | 503 |  |
| Contract assets, non-current (included within Other assets) |  | 7 |  |  | 70 |  |
| Total contract assets |  | 673 |  |  | 573 |  |
| Contract liabilities, current |  | (440) |  |  | (415) |  |
| Contract liabilities, non-current (included within Other long-term liabilities) |  | (167) |  |  | (165) |  |
| Total contract liabilities |  | (607) |  |  | (580) |  |
| Net contract assets |  | $ | 66 |  |  | $ | (7) |  |

- changed (2023-04-26):
[0001783180-23-000038:note_history:45]
The timing of revenue recognition, billings and cash collections results in contract assets and contract liabilities. Contract assets relate to the conditional right to consideration for any completed performance under a contract when costs are incurred in excess of billings under the percentage-of-completion methodology. Contract liabilities relate to payments received in advance of performance under a contract or when the Company has a right to consideration that is conditioned upon transfer of a good or service to a customer. Contract liabilities are recognized as revenue as (or when) the Company performs under the contract. 
The Company recognized revenue of $178 million during the three months ended March 31, 2023 that related to contract liabilities as of January 1, 2023. The Company expects a majority of its current contract liabilities at the end of the period to be recognized as revenue in the next 12 months.
  (was, 2022-10-27, similarity 0.9722):
[0001783180-22-000056:note_history:45]
The timing of revenue recognition, billings and cash collections results in contract assets and contract liabilities. Contract assets relate to the conditional right to consideration for any completed performance under a contract when costs are incurred in excess of billings under the percentage-of-completion methodology. Contract liabilities relate to payments received in advance of performance under a contract or when the Company has a right to consideration that is conditioned upon transfer of a good or service to a customer. Contract liabilities are recognized as revenue as (or when) the Company performs under the contract. 
The Company recognized revenue of $289 million during the nine months ended September 30, 2022 that related to contract liabilities as of January 1, 2022. The Company expects a majority of its current contract liabilities at the end of the period to be recognized as revenue in the next 12 months.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2023-04-26):
[0001783180-23-000038:note_history:46]
SUBSEQUENT EVENTS 
On April 25, 2023, the Company announced that it entered into a Share Purchase Agreement (the “Agreement”) to acquire the climate solutions business (the "Business") of Viessmann Group GmbH & Co. KG (“Viessmann”), a privately-held company, for approximately €12 billion. The Business develops intelligent, integrated and sustainable technologies, including heat pumps, boilers, photovoltaic systems, home battery storage and digital solutions, primarily for residential customers in Europe. Under the terms of the Agreement, 20% of the purchase price will be paid in Carrier common stock, issued directly to Viessmann and subject to long-term lock-up provisions, and 80% will be paid in cash, subject to working capital and other adjustments. The Company intends to finance the acquisition with a combination of cash on hand and debt financing and expects the transaction to close around the end of 2023, subject to customary closing conditions and regulatory approvals. On April 26, 2023, the Company entered into a forward contract with a total notional amount of €7 billion to mitigate the foreign currency risk of the Euro cash outflows associated with the acquisition.

- added (2023-04-26):
[0001783180-23-000038:note_history:47]
On April 25, 2023, the Company announced plans to exit its Fire & Security and Commercial Refrigeration businesses over the course of 2024. Carrier expects to use the proceeds from these transactions to reduce leverage, advance the Company’s capital allocation priorities and for general corporate purposes. The planned exit is not expected to impact UTEC, Fire & Security’s controls business for residential HVAC customers or the Company’s Transicold transport refrigeration, Profroid mechanical systems or the Sensitech monitoring businesses.
