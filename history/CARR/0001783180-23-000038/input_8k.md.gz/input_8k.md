# CARR 8-K — 0001783180-23-000036 filed 2023-04-25

## item codes, every 8-K on or before 2023-04-26

- 2023-04-26 0000950142-23-001205 — 1.01, 9.01
- 2023-04-25 0001783180-23-000036 — 2.02, 7.01, 9.01
- 2023-04-25 0000950142-23-001199 — 7.01, 8.01, 9.01
- 2023-04-21 0001783180-23-000032 — 5.07, 9.01
- 2023-02-07 0001783180-23-000010 — 2.02, 9.01
- 2022-10-27 0001783180-22-000054 — 2.02, 7.01, 9.01
- 2022-09-29 0000950142-22-002805 — 5.02, 9.01
- 2022-07-28 0001783180-22-000045 — 2.02, 9.01
- 2022-04-28 0001783180-22-000032 — 2.02, 9.01
- 2022-04-15 0001783180-22-000024 — 5.07, 9.01
- 2022-02-08 0001783180-22-000008 — 2.02, 9.01
- 2022-02-07 0000950142-22-000510 — 8.01, 9.01
- 2022-01-03 0000950142-22-000023 — 8.01, 9.01
- 2021-12-17 0001783180-21-000071 — 5.02, 7.01, 9.01
- 2021-11-23 0001783180-21-000068 — 5.03, 9.01
- 2021-10-28 0001783180-21-000062 — 2.02, 9.01
- 2021-08-27 0001783180-21-000056 — 8.01
- 2021-07-30 0001783180-21-000053 — 1.01
- 2021-07-29 0001783180-21-000049 — 2.02, 8.01, 9.01
- 2021-07-27 0000950142-21-002448 — 8.01, 9.01
- 2021-07-15 0000950142-21-002362 — 5.02, 9.01
- 2021-06-09 0000950142-21-001885 — 5.02, 9.01
- 2021-04-29 0001783180-21-000029 — 2.02, 9.01
- 2021-04-22 0001140361-21-013889 — 5.02, 9.01
- 2021-04-20 0001783180-21-000021 — 5.07, 9.01
- 2021-04-19 0000950142-21-001308 — 8.01, 9.01
- 2021-02-09 0001783180-21-000009 — 2.02, 9.01
- 2021-02-05 0001140361-21-003513 — 8.01, 9.01
- 2020-12-23 0001140361-20-029419 — 7.01, 9.01
- 2020-12-22 0001140361-20-029097 — 8.01
- 2020-12-14 0001140361-20-028246 — 5.03, 9.01
- 2020-12-07 0001140361-20-027515 — 1.01, 7.01, 9.01
- 2020-10-29 0001783180-20-000063 — 2.02, 9.01
- 2020-10-19 0001140361-20-023241 — 5.02, 7.01, 9.01
- 2020-09-23 0001140361-20-021220 — 8.01, 9.01
- 2020-09-22 0001140361-20-021124 — 8.01, 9.01
- 2020-07-30 0001783180-20-000045 — 2.02, 9.01
- 2020-06-19 0001140361-20-014325 — 1.01, 2.03, 9.01
- 2020-06-16 0001140361-20-013880 — 8.01, 9.01
- 2020-06-03 0001140361-20-012939 — 1.01, 9.01
- 2020-05-08 0001783180-20-000013 — 2.02, 9.01
- 2020-04-03 0001140361-20-007888 — 1.01, 5.02, 5.03, 5.05, 7.01, 9.01
- 2020-03-16 0001140361-20-005868 — 8.01, 9.01

## late-filing notifications on or before 2023-04-26

- none on or before 2023-04-26

## item 2.02 — earnings release, exhibit 99.1

[0001783180-23-000036:8k_2_02:1]
EX-99
2
a99-q12023earningsexhibit.htm
EX-99

[0001783180-23-000036:8k_2_02:2]
Document

[0001783180-23-000036:8k_2_02:3]
Exhibit 99

[0001783180-23-000036:8k_2_02:4]
Carrier Reports First Quarter 2023 Results

[0001783180-23-000036:8k_2_02:5]
•Net sales up 13% versus first quarter 2022; organic sales up 4%

[0001783180-23-000036:8k_2_02:6]
•GAAP EPS of $0.44 and adjusted EPS of $0.52

[0001783180-23-000036:8k_2_02:7]
•Net cash inflows from operating activities were $120 million and free cash flow generation was $50 million

[0001783180-23-000036:8k_2_02:8]
•Reaffirming full-year 2023 guidance for sales, adjusted operating margin, adjusted EPS and free cash flow*

[0001783180-23-000036:8k_2_02:9]
PALM BEACH GARDENS, Fla., April 25, 2023 – Carrier Global Corporation (NYSE:CARR), a global leader in intelligent climate and energy solutions, today reported strong financial results for the first quarter of 2023 and reiterated its full year guidance.

[0001783180-23-000036:8k_2_02:10]
“The Carrier team continues to execute well with all financial performance metrics coming in better than we expected. We delivered another quarter of double-digit growth in commercial and light commercial HVAC, global truck and trailer, aftermarket and controls which shows the strength of our execution and strategic focus,” said Carrier Chairman & CEO David Gitlin. “We are excited to build on our growth and success with the strategic actions announced separately today, which will transform Carrier into a more focused, pure-play, higher growth intelligent climate and energy solutions company with leadership positions in the most attractive markets globally.”

[0001783180-23-000036:8k_2_02:11]
First Quarter 2023 Results

[0001783180-23-000036:8k_2_02:12]
Carrier’s first quarter sales of $5.3 billion were up 13% compared to the prior year and organic sales grew 4% over the same period. Organic sales strength continued in the HVAC segment with commercial and controls up double digits while Fire and Security was up 9% organically in the quarter. Refrigeration sales were down 5% organically driven by container and commercial refrigeration only partially offset by strength in global truck and

[0001783180-23-000036:8k_2_02:13]
1

[0001783180-23-000036:8k_2_02:14]
trailer. North America residential and light commercial HVAC was down 2% driven by a tough comparison in residential.

[0001783180-23-000036:8k_2_02:15]
GAAP operating profit in the quarter of $555 million was down 68% from last year that included the gain related to the divestiture of Chubb.  Adjusted operating profit of $642 million was down 2%. Favorable price/cost was more than offset by flattish volumes, unfavorable mix, and spending on investments.

[0001783180-23-000036:8k_2_02:16]
Net income was $373 million and adjusted net income was $442 million. GAAP EPS was $0.44 and adjusted EPS was $0.52. Net cash flows generated in operating activities were $120 million and capital expenditures were $70 million, resulting in a free cash inflow of $50 million. The inflow was driven by lower seasonal inventory build and other working capital improvements compared to last year.  During the first quarter, Carrier repurchased $62 million of its common stock.

[0001783180-23-000036:8k_2_02:17]
Full-Year 2023 Guidance**

[0001783180-23-000036:8k_2_02:18]
Carrier reaffirmed the following guidance for 2023:

[0001783180-23-000036:8k_2_02:19]
|  |  | 2/7/2023 Guidance | 4/25/2023 Guidance** |  |  |
|  |  | ~$22B | ~$22B |  |  |
| Sales |  | Organic* up LSD-MSD | Organic* up LSD-MSD |  |  |
|  |  | FX (~1%) | FX ~0% |  |  |
|  |  | Acquisitions + ~6% | Acquisitions + ~6% |  |  |
| Adjusted Operating Margin * |  | ~14% | ~14% |  |  |
|  | Includes ~50bps negative impact from Toshiba Carrier Corp. (TCC) | Includes ~50bps negative impact from TCC |  |  |
| Adjusted EPS * |  | $2.50 - $2.60 | $2.50 - $2.60 |  |  |
| Free Cash Flow * |  | ~$1.9B | ~$1.9B |  |  |

[0001783180-23-000036:8k_2_02:20]
*Note: When the company provides expectations for organic sales, adjusted operating profit, adjusted operating margin, adjusted EPS and free cash flow on a forward-looking basis, a reconciliation of the differences between the non-GAAP expectations and the corresponding GAAP measures generally is not available without unreasonable effort. See “Use and Definitions of Non-GAAP Financial Measures” below for additional information.

[0001783180-23-000036:8k_2_02:21]
**As of April 25, 2023

[0001783180-23-000036:8k_2_02:22]
2

[0001783180-23-000036:8k_2_02:23]
Conference Call

[0001783180-23-000036:8k_2_02:24]
Carrier will host a webcast of its earnings conference call tomorrow, Wednesday, April 26, 2023, at 7:30 a.m. ET. To access the webcast, visit the Events & Presentations section of the Carrier Investor Relations site at ir.carrier.com/news-and-events/events-and-presentations or to listen to the earnings call by phone, participants must pre-register at Carrier Earnings Call Registration. All registrants will receive dial-in information and a PIN allowing access to the live call. In light of this call, Carrier is cancelling its previously scheduled earnings conference call on Thursday, April 27, 2023.

[0001783180-23-000036:8k_2_02:25]
About Carrier

[0001783180-23-000036:8k_2_02:26]
As a global leader in intelligent climate and energy solutions, Carrier Global Corporation is committed to making the world safer, sustainable and more comfortable for generations to come. From the beginning, we've led in inventing new technologies and entirely new industries. Today, we continue to lead because we have a world-class, diverse workforce that puts the customer at the center of everything we do.  For more information, visit www.corporate.carrier.com or follow Carrier on social media at @Carrier.

[0001783180-23-000036:8k_2_02:27]
Cautionary Statement

[0001783180-23-000036:8k_2_02:28]
This communication contains statements which, to the extent they are not statements of historical or present fact, constitute "forward-looking statements" under the securities laws. These forward-looking statements are intended to provide management's current expectations or plans for Carrier's future operating and financial performance, based on assumptions currently believed to be valid. Forward-looking statements can be identified by the use of words such as "believe," "expect," "expectations," "plans," "strategy," "prospects," "estimate," "project," "target," "anticipate," "will," "should," "see," "guidance," "outlook," "confident," "scenario" and other words of similar meaning in connection with a discussion of future operating or financial performance. Forward-looking statements may include, among other things, statements relating to future sales, earnings, cash flow, results of operations, uses of cash, share repurchases, tax rates and other measures of financial performance or potential future plans, strategies or transactions of Carrier, Carrier's plans with respect to its indebtedness and other statements that are not historical facts. All forward-looking statements involve risks, uncertainties and other factors that may cause actual results to differ materially from those expressed or implied in the forward-looking statements. For additional information on identifying factors that may cause actual results to vary materially from those stated in forward-looking statements, see Carrier's reports on Forms 10-K, 10-Q and 8-K filed with or furnished to the U.S. Securities and Exchange Commission from time to time. Any forward-looking statement speaks only as of the date on which it is made, and Carrier assumes no obligation to update or revise such statement, whether as a result of new information, future events or otherwise, except as required by applicable law.

[0001783180-23-000036:8k_2_02:29]
3

[0001783180-23-000036:8k_2_02:30]
Contact:

[0001783180-23-000036:8k_2_02:31]
Media Inquiries

[0001783180-23-000036:8k_2_02:32]
Ashley Barrie

[0001783180-23-000036:8k_2_02:33]
561-365-1260

[0001783180-23-000036:8k_2_02:34]
Ashley.Barrie@Carrier.com

[0001783180-23-000036:8k_2_02:35]
Investor Relations

[0001783180-23-000036:8k_2_02:36]
Sam Pearlstein

[0001783180-23-000036:8k_2_02:37]
561-365-2251

[0001783180-23-000036:8k_2_02:38]
Sam.Pearlstein@Carrier.com

[0001783180-23-000036:8k_2_02:39]
4

[0001783180-23-000036:8k_2_02:40]
SELECTED FINANCIAL DATA, NON-GAAP MEASURES AND DEFINITIONS

[0001783180-23-000036:8k_2_02:41]
Following are tables that present selected financial data of Carrier Global Corporation (“Carrier”). Also included are reconciliations of non-GAAP measures to their most comparable GAAP measures.

[0001783180-23-000036:8k_2_02:42]
Use and Definitions of Non-GAAP Financial Measures

[0001783180-23-000036:8k_2_02:43]
Carrier Global Corporation (“Carrier”) reports its financial results in accordance with accounting principles generally accepted in the United States ("GAAP"). We supplement the reporting of our financial information determined under GAAP with certain non-GAAP financial information. The non-GAAP information presented provides investors with additional useful information, but should not be considered in isolation or as substitutes for the related GAAP measures. Moreover, other companies may define non-GAAP measures differently, which limits the usefulness of these measures for comparisons with such other companies. We encourage investors to review our financial statements and publicly filed reports in their entirety and not to rely on any single financial measure. A reconciliation of the non-GAAP measures to the corresponding amounts prepared in accordance with GAAP appears in the tables in this Appendix. The tables provide additional information as to the items and amounts that have been excluded from the adjusted measures.

[0001783180-23-000036:8k_2_02:44]
Organic sales, adjusted operating profit, adjusted operating margin, incremental margins / earnings conversion, earnings before interest, taxes and depreciation and amortization (“EBITDA”), adjusted EBITDA, adjusted net income, adjusted earnings per share (“EPS”), adjusted interest expense, net, adjusted effective tax rate and net debt are non-GAAP financial measures.

[0001783180-23-000036:8k_2_02:45]
Organic sales represents consolidated net sales (a GAAP measure), excluding the impact of foreign currency translation, acquisitions and divestitures completed in the preceding twelve months and other significant items of a nonoperational nature (hereinafter referred to as “other significant items”). Adjusted operating profit represents operating profit (a GAAP measure), excluding restructuring costs, amortization of acquired intangibles and other significant items. Adjusted operating margin represents adjusted operating profit as a percentage of net sales (a GAAP measure). Incremental margins / earnings conversion represents the year-over-year change in adjusted operating profit divided by the year-over-year change in net sales. EBITDA represents net income attributable to common shareholders (a GAAP measure), adjusted for interest income and expense, income tax expense, and depreciation and amortization. Adjusted EBITDA represents EBITDA, as calculated above, excluding non-service pension benefit, non-controlling interest in subsidiaries’ earnings from operations, restructuring costs and other significant items. Adjusted net income represents net income attributable to common shareowners (a GAAP measure), excluding restructuring costs, amortization of acquired intangibles and other significant items. Adjusted EPS represents diluted earnings per share (a GAAP measure), excluding restructuring costs, amortization of acquired intangibles and other significant items. Adjusted interest expense, net represents interest expense (a GAAP measure) and interest income (a GAAP measure), net excluding other significant items. The adjusted effective tax rate represents the effective tax rate (a GAAP measure), excluding restructuring costs, amortization of acquired intangibles and other significant items. Net debt represents long-term debt (a GAAP measure) less cash and cash equivalents (a GAAP measure). For the business segments, when applicable, adjustments of operating profit and operating margins represent operating profit, excluding restructuring, amortization of acquired intangibles and other significant items.

[0001783180-23-000036:8k_2_02:46]
Free cash flow is a non-GAAP financial measure that represents net cash flows provided by operating activities (a GAAP measure) less capital expenditures. Management believes free cash flow is a useful measure of liquidity and an additional basis for assessing Carrier’s ability to fund its activities, including the financing of acquisitions, debt service, repurchases of Carrier's common stock and distribution of earnings to shareowners.

[0001783180-23-000036:8k_2_02:47]
Orders are contractual commitments with customers to provide specified goods or services for an agreed upon price and may not be subject to penalty if cancelled.

[0001783180-23-000036:8k_2_02:48]
When we provide our expectations for organic sales, adjusted operating profit, adjusted operating margin, adjusted interest expense, net, adjusted effective tax rate, incremental margins/earnings conversion, adjusted EPS and free cash flow on a forward-looking basis, a reconciliation of the differences between the non-GAAP expectations and the corresponding GAAP measures (expected net sales, operating profit, operating margin, interest expense, effective tax rate, incremental operating margin, diluted EPS and net cash flows provided by operating activities) generally is not available without unreasonable effort due to potentially high variability, complexity and low visibility as to the items that would be excluded from the GAAP measure in the relevant future period, such as unusual gains and losses, the ultimate outcome of pending litigation, fluctuations in foreign currency exchange rates, the impact and timing of potential acquisitions and divestitures, future restructuring costs, and other structural changes or their probable significance. The variability of the excluded items may have a significant, and potentially unpredictable, impact on our future GAAP results.

[0001783180-23-000036:8k_2_02:49]
5

[0001783180-23-000036:8k_2_02:50]
Carrier Global Corporation

[0001783180-23-000036:8k_2_02:51]
Condensed Consolidated Statement of Operations

[0001783180-23-000036:8k_2_02:52]
|  | (Unaudited) |
|  | Three Months Ended March 31, |  |  |
| (In millions, except per share amounts) | 2023 |  | 2022 |  |  |  |  |
| Net sales |  |  |  |  |  |  |  |
| Product sales | $ | 4,686 |  |  | $ | 4,170 |  |  |  |  |  |
| Service sales | 587 |  |  | 484 |  |  |  |  |  |
| Total Net sales | 5,273 |  |  | 4,654 |  |  |  |  |  |
| Costs and expenses |  |  |  |  |  |  |  |
| Cost of products sold | (3,458) |  |  | (2,998) |  |  |  |  |  |
| Cost of services sold | (437) |  |  | (363) |  |  |  |  |  |
| Research and development | (139) |  |  | (125) |  |  |  |  |  |
| Selling, general and administrative | (721) |  |  | (601) |  |  |  |  |  |
| Total Costs and expenses | (4,755) |  |  | (4,087) |  |  |  |  |  |
| Equity method investment net earnings | 44 |  |  | 58 |  |  |  |  |  |
| Other income (expense), net | (7) |  |  | 1,112 |  |  |  |  |  |
| Operating profit | 555 |  |  | 1,737 |  |  |  |  |  |
| Non-service pension (expense) benefit | — |  |  | (1) |  |  |  |  |  |
| Interest (expense) income, net | (46) |  |  | (48) |  |  |  |  |  |
| Income from operations before income taxes | 509 |  |  | 1,688 |  |  |  |  |  |
| Income tax (expense) benefit | (122) |  |  | (301) |  |  |  |  |  |
| Net income from operations | 387 |  |  | 1,387 |  |  |  |  |  |
| Less: Non-controlling interest in subsidiaries' earnings from operations | 14 |  |  | 8 |  |  |  |  |  |
| Net income attributable to common shareowners | $ | 373 |  |  | $ | 1,379 |  |  |  |  |  |
| Earnings per share |  |  |  |  |  |  |  |
| Basic | $ | 0.45 |  |  | $ | 1.62 |  |  |  |  |  |
| Diluted | $ | 0.44 |  |  | $ | 1.58 |  |  |  |  |  |
| Weighted-average number of shares outstanding |  |  |  |  |  |  |  |
| Basic | 835.0 |  |  | 853.3 |  |  |  |  |  |
| Diluted | 852.2 |  |  | 874.1 |  |  |  |  |  |

[0001783180-23-000036:8k_2_02:53]
6

[0001783180-23-000036:8k_2_02:54]
Carrier Global Corporation

[0001783180-23-000036:8k_2_02:55]
Condensed Consolidated Balance Sheet

[0001783180-23-000036:8k_2_02:56]
|  |  | (Unaudited) |
| (In millions) |  | March 31, 2023 |  | December 31, 2022 |
| Assets |  |  |  |  |
| Cash and cash equivalents |  | $ | 3,347 |  |  | $ | 3,520 |  |
| Accounts receivable, net |  | 3,032 |  |  | 2,833 |  |
| Contract assets, current |  | 568 |  |  | 537 |  |
| Inventories, net |  | 2,803 |  |  | 2,640 |  |
| Other assets, current |  | 408 |  |  | 349 |  |
| Total current assets |  | 10,158 |  |  | 9,879 |  |
| Future income tax benefits |  | 639 |  |  | 612 |  |
| Fixed assets, net |  | 2,277 |  |  | 2,241 |  |
| Operating lease right-of-use assets |  | 625 |  |  | 642 |  |
| Intangible assets, net |  | 1,287 |  |  | 1,342 |  |
| Goodwill |  | 9,987 |  |  | 9,977 |  |
| Pension and post-retirement assets |  | 29 |  |  | 26 |  |
| Equity method investments |  | 1,103 |  |  | 1,148 |  |
| Other assets |  | 306 |  |  | 219 |  |
| Total Assets |  | $ | 26,411 |  |  | $ | 26,086 |  |
| Liabilities and Equity |  |  |  |  |
| Accounts payable |  | $ | 2,926 |  |  | $ | 2,833 |  |
| Accrued liabilities |  | 2,374 |  |  | 2,610 |  |
| Contract liabilities, current |  | 516 |  |  | 449 |  |
| Current portion of long-term debt |  | 142 |  |  | 140 |  |
| Total current liabilities |  | 5,958 |  |  | 6,032 |  |
| Long-term debt |  | 8,708 |  |  | 8,702 |  |
| Future pension and post-retirement obligations |  | 354 |  |  | 349 |  |
| Future income tax obligations |  | 581 |  |  | 568 |  |
| Operating lease liabilities |  | 506 |  |  | 529 |  |
| Other long-term liabilities |  | 1,836 |  |  | 1,830 |  |
| Total Liabilities |  | 17,943 |  |  | 18,010 |  |
| Equity |  |  |  |  |
| Common stock |  | 9 |  |  | 9 |  |
| Treasury stock |  | (1,972) |  |  | (1,910) |  |
| Additional paid-in capital |  | 5,494 |  |  | 5,481 |  |
| Retained earnings |  | 6,239 |  |  | 5,866 |  |
| Accumulated other comprehensive loss |  | (1,636) |  |  | (1,688) |  |
| Non-controlling interest |  | 334 |  |  | 318 |  |
| Total Equity |  | 8,468 |  |  | 8,076 |  |
| Total Liabilities and Equity |  | $ | 26,411 |  |  | $ | 26,086 |  |

[0001783180-23-000036:8k_2_02:57]
7

[0001783180-23-000036:8k_2_02:58]
Carrier Global Corporation

[0001783180-23-000036:8k_2_02:59]
Condensed Consolidated Statement of Cash Flows

[0001783180-23-000036:8k_2_02:60]
|  |  |  |  | (Unaudited) |
|  |  |  | Three Months Ended March 31, |
| (In millions) |  |  |  |  | 2023 |  | 2022 |
| Operating Activities |  |  |  |  |  |  |  |
| Net income from operations |  |  |  |  | $ | 387 |  |  | $ | 1,387 |  |
| Adjustments to reconcile net income to net cash flows from operating activities: |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  |  |  | 136 |  |  | 79 |  |
| Deferred income tax provision |  |  |  |  | (24) |  |  | 48 |  |
| Stock-based compensation costs |  |  |  |  | 22 |  |  | 21 |  |
| Equity method investment net earnings |  |  |  |  | (44) |  |  | (58) |  |
| (Gain) loss on extinguishment of debt |  |  |  |  | — |  |  | (36) |  |
| (Gain) loss on sale of investments |  |  |  |  | (16) |  |  | (1,112) |  |
| Changes in operating assets and liabilities |  |  |  |  |  |  |  |
| Accounts receivable, net |  |  |  |  | (157) |  |  | (207) |  |
| Contract assets, current |  |  |  |  | (28) |  |  | (154) |  |
| Inventories, net |  |  |  |  | (126) |  |  | (390) |  |
| Other assets, current |  |  |  |  | (60) |  |  | (15) |  |
| Accounts payable and accrued liabilities |  |  |  |  | (25) |  |  | 132 |  |
| Contract liabilities, current |  |  |  |  | 64 |  |  | 13 |  |
| Defined benefit plan contributions |  |  |  |  | (6) |  |  | (4) |  |
| Distributions from equity method investments |  |  |  |  | 3 |  |  | 11 |  |
| Other operating activities, net |  |  |  |  | (6) |  |  | 83 |  |
| Net cash flows provided by (used in) operating activities |  |  |  |  | 120 |  |  | (202) |  |
| Investing Activities |  |  |  |  |  |  |  |
| Capital expenditures |  |  |  |  | (70) |  |  | (56) |  |
| Investments in businesses, net of cash acquired |  |  |  |  | (52) |  |  | (9) |  |
| Disposition of businesses |  |  |  |  | 35 |  |  | 2,935 |  |
| Settlement of derivative contracts, net |  |  |  |  | (18) |  |  | (32) |  |
| Other investing activities, net |  |  |  |  | 5 |  |  | (18) |  |
| Net cash flows provided by (used in) investing activities |  |  |  |  | (100) |  |  | 2,820 |  |
| Financing Activities |  |  |  |  |  |  |  |
| Increase (decrease) in short-term borrowings, net |  |  |  |  | 10 |  |  | (33) |  |
| Issuance of long-term debt |  |  |  |  | 5 |  |  | 14 |  |
| Repayment of long-term debt |  |  |  |  | (2) |  |  | (1,123) |  |
| Repurchases of common stock |  |  |  |  | (62) |  |  | (734) |  |
| Dividends paid on common stock |  |  |  |  | (154) |  |  | (129) |  |
| Other financing activities, net |  |  |  |  | (10) |  |  | (15) |  |
| Net cash flows provided by (used in) financing activities |  |  |  |  | (213) |  |  | (2,020) |  |
| Effect of foreign exchange rate changes on cash and cash equivalents |  |  |  |  | 20 |  |  | (1) |  |
| Net increase (decrease) in cash and cash equivalents and restricted cash |  |  |  |  | (173) |  |  | 597 |  |
| Cash, cash equivalents and restricted cash, beginning of period |  |  |  |  | 3,527 |  |  | 3,025 |  |
| Cash, cash equivalents and restricted cash, end of period |  |  |  |  | 3,354 |  |  | 3,622 |  |
| Less: restricted cash |  |  |  |  | 7 |  |  | 18 |  |
| Cash and cash equivalents, end of period |  |  |  |  | $ | 3,347 |  |  | $ | 3,604 |  |

[0001783180-23-000036:8k_2_02:61]
8

[0001783180-23-000036:8k_2_02:62]
Carrier Global Corporation

[0001783180-23-000036:8k_2_02:63]
Segment Net Sales and Operating Profit

[0001783180-23-000036:8k_2_02:64]
|  | (Unaudited) |
|  | Three Months Ended March 31, |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
| (In millions) | Reported |  | Adjusted |  | Reported |  | Adjusted |  |  |  |  |  |  |  |  |
| Net sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| HVAC | $ | 3,622 |  | $ | 3,622 |  | $ | 2,970 |  | $ | 2,970 |  |  |  |  |  |  |  |  |
| Refrigeration | 898 |  | 898 |  | 976 |  | 976 |  |  |  |  |  |  |  |  |
| Fire & Security | 869 |  | 869 |  | 818 |  | 818 |  |  |  |  |  |  |  |  |
| Segment sales | 5,389 |  | 5,389 |  | 4,764 |  | 4,764 |  |  |  |  |  |  |  |  |
| Eliminations and other | (116) |  | (116) |  | (110) |  | (110) |  |  |  |  |  |  |  |  |
| Net sales | $ | 5,273 |  | $ | 5,273 |  | $ | 4,654 |  | $ | 4,654 |  |  |  |  |  |  |  |  |
| Operating profit |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| HVAC | $ | 435 |  | $ | 490 |  | $ | 470 |  | $ | 478 |  |  |  |  |  |  |  |  |
| Refrigeration | 108 |  | 111 |  | 107 |  | 112 |  |  |  |  |  |  |  |  |
| Fire & Security | 93 |  | 108 |  | 1,218 |  | 117 |  |  |  |  |  |  |  |  |
| Segment operating profit | 636 |  | 709 |  | 1,795 |  | 707 |  |  |  |  |  |  |  |  |
| Eliminations and other | (38) |  | (36) |  | (24) |  | (24) |  |  |  |  |  |  |  |  |
| General corporate expenses | (43) |  | (31) |  | (34) |  | (28) |  |  |  |  |  |  |  |  |
| Operating profit | $ | 555 |  | $ | 642 |  | $ | 1,737 |  | $ | 655 |  |  |  |  |  |  |  |  |
| Operating margin |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| HVAC | 12.0 | % |  | 13.5 | % |  | 15.8 | % |  | 16.1 | % |  |  |  |  |  |  |  |  |
| Refrigeration | 12.0 | % |  | 12.4 | % |  | 11.0 | % |  | 11.5 | % |  |  |  |  |  |  |  |  |
| Fire & Security | 10.7 | % |  | 12.4 | % |  | 148.9 | % |  | 14.3 | % |  |  |  |  |  |  |  |  |
| Total Carrier | 10.5 | % |  | 12.2 | % |  | 37.3 | % |  | 14.1 | % |  |  |  |  |  |  |  |  |

[0001783180-23-000036:8k_2_02:65]
9

[0001783180-23-000036:8k_2_02:66]
Carrier Global Corporation

[0001783180-23-000036:8k_2_02:67]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP)

[0001783180-23-000036:8k_2_02:68]
Operating Profit

[0001783180-23-000036:8k_2_02:69]
|  | (Unaudited) |
|  | Three Months Ended March 31, 2023 |
| (In millions) | HVAC |  | Refrigeration |  | Fire & Security |  | Eliminations and Other |  | General Corporate Expenses |  | Carrier |
| Net sales | $ | 3,622 |  |  | $ | 898 |  |  | $ | 869 |  |  | $ | (116) |  |  | $ | — |  |  | $ | 5,273 |  |
| Segment operating profit | $ | 435 |  |  | $ | 108 |  |  | $ | 93 |  |  | $ | (38) |  |  | $ | (43) |  |  | $ | 555 |  |
| Reported operating margin | 12.0 | % |  | 12.0 | % |  | 10.7 | % |  |  |  |  |  | 10.5 | % |
| Adjustments to segment operating profit: |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring costs | $ | (1) |  |  | $ | 3 |  |  | $ | 13 |  |  | $ | 2 |  |  | $ | — |  |  | $ | 17 |  |
| Amortization of acquired intangibles | 37 |  |  | — |  |  | 2 |  |  | — |  |  | — |  |  | 39 |  |
| Acquisition step-up amortization (1) | 11 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 11 |  |
| Acquisition-related costs | — |  |  | — |  |  | — |  |  | — |  |  | 12 |  |  | 12 |  |
| TCC acquisition-related gain (2) | 8 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 8 |  |
| Total adjustments to operating profit | $ | 55 |  |  | $ | 3 |  |  | $ | 15 |  |  | $ | 2 |  |  | $ | 12 |  |  | $ | 87 |  |
| Adjusted operating profit | $ | 490 |  |  | $ | 111 |  |  | $ | 108 |  |  | $ | (36) |  |  | $ | (31) |  |  | $ | 642 |  |
| Adjusted operating margin | 13.5 | % |  | 12.4 | % |  | 12.4 | % |  |  |  |  |  | 12.2 | % |

[0001783180-23-000036:8k_2_02:70]
|  | (Unaudited) |
|  | Three Months Ended March 31, 2022 |
| (In millions) | HVAC |  | Refrigeration |  | Fire & Security |  | Eliminations and Other |  | General Corporate Expenses |  | Carrier |
| Net sales | $ | 2,970 |  |  | $ | 976 |  |  | $ | 818 |  |  | $ | (110) |  |  | $ | — |  |  | $ | 4,654 |  |
| Segment operating profit | $ | 470 |  |  | $ | 107 |  |  | $ | 1,218 |  |  | $ | (24) |  |  | $ | (34) |  |  | $ | 1,737 |  |
| Reported operating margin | 15.8 | % |  | 11.0 | % |  | 148.9 | % |  |  |  |  |  | 37.3 | % |
| Adjustments to segment operating profit: |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring costs | $ | 4 |  |  | $ | — |  |  | $ | 6 |  |  | $ | — |  |  | $ | — |  |  | $ | 10 |  |
| Amortization of acquired intangibles | 4 |  |  | — |  |  | 1 |  |  | — |  |  | — |  |  | 5 |  |
| Acquisition-related costs | — |  |  | — |  |  | — |  |  | — |  |  | 6 |  |  | 6 |  |
| Chubb gain | — |  |  | — |  |  | (1,112) |  |  | — |  |  | — |  |  | (1,112) |  |
| Russia/Ukraine asset impairment | — |  |  | 5 |  |  | 4 |  |  | — |  |  | — |  |  | 9 |  |
| Total adjustments to operating profit | $ | 8 |  |  | $ | 5 |  |  | $ | (1,101) |  |  | $ | — |  |  | $ | 6 |  |  | $ | (1,082) |  |
| Adjusted operating profit | $ | 478 |  |  | $ | 112 |  |  | $ | 117 |  |  | $ | (24) |  |  | $ | (28) |  |  | $ | 655 |  |
| Adjusted operating margin | 16.1 | % |  | 11.5 | % |  | 14.3 | % |  |  |  |  |  | 14.1 | % |

[0001783180-23-000036:8k_2_02:71]
(1)  Amortization of the step-up to fair value of acquired inventory and backlog.

[0001783180-23-000036:8k_2_02:72]
(2)  The carrying value of our previously held TCC equity investments were recognized at fair value and subsequently adjusted.

[0001783180-23-000036:8k_2_02:73]
10

[0001783180-23-000036:8k_2_02:74]
Carrier Global Corporation

[0001783180-23-000036:8k_2_02:75]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP) Results

[0001783180-23-000036:8k_2_02:76]
Net Income, Earnings Per Share, and Effective Tax Rate

[0001783180-23-000036:8k_2_02:77]
|  | (Unaudited) |
|  | Three Months Ended March 31, 2023 |  |  |
| (In millions, except per share amounts) | Reported |  | Adjustments |  | Adjusted |  |  |  |  |  |  |
| Net sales | $ | 5,273 |  |  | $ | — |  |  | $ | 5,273 |  |  |  |  |  |  |  |
| Operating profit | $ | 555 |  |  | 87 |  | a | $ | 642 |  |  |  |  |  |  |  |
| Operating margin | 10.5 | % |  |  |  | 12.2 | % |  |  |  |  |  |  |
| Income from operations before income taxes | $ | 509 |  |  | 87 |  | a | $ | 596 |  |  |  |  |  |  |  |
| Income tax expense | $ | (122) |  |  | (18) |  | c | $ | (140) |  |  |  |  |  |  |  |
| Income tax rate | 24.0 | % |  |  |  | 23.5 | % |  |  |  |  |  |  |
| Net income attributable to common shareowners | $ | 373 |  |  | $ | 69 |  |  | $ | 442 |  |  |  |  |  |  |  |
| Summary of Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring costs |  |  | $ | 17 |  | a |  |  |  |  |  |  |  |
| Amortization of acquired intangibles |  |  | 39 |  | a |  |  |  |  |  |  |  |
| Acquisition step-up amortization (1) |  |  | 11 |  | a |  |  |  |  |  |  |  |
| Acquisition-related costs |  |  | 12 |  | a |  |  |  |  |  |  |  |
| TCC acquisition-related gain (2) |  |  | 8 |  | a |  |  |  |  |  |  |  |
| Total adjustments |  |  | $ | 87 |  |  |  |  |  |  |  |  |  |
| Tax effect on adjustments above |  |  | $ | (18) |  |  |  |  |  |  |  |  |  |
| Total tax adjustments |  |  | $ | (18) |  | c |  |  |  |  |  |  |  |
| Shares outstanding - Diluted | 852.2 |  |  |  |  | 852.2 |  |  |  |  |  |  |  |
| Earnings per share - Diluted | $ | 0.44 |  |  |  |  | $ | 0.52 |  |  |  |  |  |  |  |

[0001783180-23-000036:8k_2_02:78]
(1)  Amortization of the step-up to fair value of acquired inventory and backlog.

[0001783180-23-000036:8k_2_02:79]
(2)  The carrying value of our previously held TCC equity investments were recognized at fair value and subsequently adjusted.

[0001783180-23-000036:8k_2_02:80]
11

[0001783180-23-000036:8k_2_02:81]
Carrier Global Corporation

[0001783180-23-000036:8k_2_02:82]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP) Results

[0001783180-23-000036:8k_2_02:83]
Net Income, Earnings Per Share, and Effective Tax Rate

[0001783180-23-000036:8k_2_02:84]
|  | (Unaudited) |
|  | Three Months Ended March 31, 2022 |  |  |
| (In millions, except per share amounts) | Reported |  | Adjustments |  | Adjusted |  |  |  |  |  |  |
| Net sales | $ | 4,654 |  |  | $ | — |  |  | $ | 4,654 |  |  |  |  |  |  |  |
| Operating profit | $ | 1,737 |  |  | (1,082) |  | a | $ | 655 |  |  |  |  |  |  |  |
| Operating margin | 37.3 | % |  |  |  | 14.1 | % |  |  |  |  |  |  |
| Income from operations before income taxes | $ | 1,688 |  |  | (1,110) |  | a,b | $ | 578 |  |  |  |  |  |  |  |
| Income tax expense | $ | (301) |  |  | 208 |  | c | $ | (93) |  |  |  |  |  |  |  |
| Income tax rate | 17.8 | % |  |  |  | 16.1 | % |  |  |  |  |  |  |
| Net income attributable to common shareowners | $ | 1,379 |  |  | $ | (902) |  |  | $ | 477 |  |  |  |  |  |  |  |
| Summary of Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring costs |  |  | $ | 10 |  | a |  |  |  |  |  |  |  |
| Amortization of acquired intangibles |  |  | 5 |  | a |  |  |  |  |  |  |  |
| Acquisition-related costs |  |  | 6 |  | a |  |  |  |  |  |  |  |
| Chubb gain |  |  | (1,112) |  | a |  |  |  |  |  |  |  |
| Russia/Ukraine asset impairment |  |  | 9 |  | a |  |  |  |  |  |  |  |
| Debt extinguishment (gain), net (1) |  |  | (28) |  | b |  |  |  |  |  |  |  |
| Total adjustments |  |  | $ | (1,110) |  |  |  |  |  |  |  |  |  |
| Tax effect on adjustments above |  |  | $ | 208 |  |  |  |  |  |  |  |  |  |
| Tax specific adjustments |  |  | — |  |  |  |  |  |  |  |  |  |
| Total tax adjustments |  |  | $ | 208 |  | c |  |  |  |  |  |  |  |
| Shares outstanding - Diluted | 874.1 |  |  |  |  | 874.1 |  |  |  |  |  |  |  |
| Earnings per share - Diluted | $ | 1.58 |  |  |  |  | $ | 0.55 |  |  |  |  |  |  |  |

[0001783180-23-000036:8k_2_02:85]
(1)  The Company repurchased approximately $1.15 billion of aggregate principal senior notes on March 30, 2022 and recognized a net gain of $33 million and wrote-off $5 million of unamortized deferred financing costs in Interest (expense) income, net.

[0001783180-23-000036:8k_2_02:86]
12

[0001783180-23-000036:8k_2_02:87]
Carrier Global Corporation

[0001783180-23-000036:8k_2_02:88]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP) Results

[0001783180-23-000036:8k_2_02:89]
Components of Changes in Net Sales

[0001783180-23-000036:8k_2_02:90]
| Three Months Ended March 31, 2023 Compared with Three Months Ended March 31, 2022 |
|  | (Unaudited) |
|  | Factors Contributing to Total % change in Net Sales |
|  | Organic |  | FX Translation |  | Acquisitions / Divestitures, net |  | Other |  | Total |
| HVAC | 6 | % |  | (2) | % |  | 18 | % |  | — | % |  | 22 | % |
| Refrigeration | (5) | % |  | (3) | % |  | — | % |  | — | % |  | (8) | % |
| Fire & Security | 9 | % |  | (3) | % |  | — | % |  | — | % |  | 6 | % |
| Consolidated | 4 | % |  | (2) | % |  | 11 | % |  | — | % |  | 13 | % |

[0001783180-23-000036:8k_2_02:91]
Historical Amounts of Amortization of Acquired Intangibles

[0001783180-23-000036:8k_2_02:92]
|  |  | (Unaudited) |
|  |  | Q1 |  | Q2 |  | Q3 |  | Q4 |  | FY |  |  |  |  |
| (In millions) |  | 2022 |  | 2022 |  | 2022 |  | 2022 |  | 2022 |  |  |  |  |
| HVAC |  | $ | 4 |  |  | $ | 4 |  |  | $ | 16 |  |  | $ | 22 |  |  | $ | 46 |  |  |  |  |  |
| Fire & Security |  | 1 |  |  | 1 |  |  | 1 |  |  | 1 |  |  | 4 |  |  |  |  |  |
| Total Carrier |  | 5 |  |  | 5 |  |  | 17 |  |  | 23 |  | 50 |  |  |  |  |  |
| Associated tax effect |  | (1) |  |  | (1) |  |  | (7) |  |  | (4) |  |  | (13) |  |  |  |  |  |
| Net impact to adjusted results |  | $ | 4 |  |  | $ | 4 |  |  | $ | 10 |  |  | $ | 19 |  |  | $ | 37 |  |  |  |  |  |

[0001783180-23-000036:8k_2_02:93]
Free Cash Flow Reconciliation

[0001783180-23-000036:8k_2_02:94]
|  |  | (Unaudited) |
|  |  | Q1 |  | Q2 |  | Q3 |  | Q4 |  | FY |  | Q1 |  |  |  |  |  |  |
| (In millions) |  | 2022 |  | 2022 |  | 2022 |  | 2022 |  | 2022 |  | 2023 |  |  |  |  |  |  |
| Net cash flows provided by (used in) operating activities |  | $ | (202) |  |  | $ | 32 |  |  | $ | 790 |  |  | $ | 1,123 |  |  | $ | 1,743 |  |  | $ | 120 |  |  |  |  |  |  |  |
| Less: Capital expenditures |  | 56 |  |  | 66 |  |  | 91 |  |  | 140 |  | 353 |  |  | 70 |  |  |  |  |  |  |  |
| Free cash flow |  | $ | (258) |  |  | $ | (34) |  |  | $ | 699 |  |  | $ | 983 |  |  | $ | 1,390 |  |  | $ | 50 |  |  |  |  |  |  |  |

[0001783180-23-000036:8k_2_02:95]
Net Debt Reconciliation

[0001783180-23-000036:8k_2_02:96]
|  |  | (Unaudited) |
| (In millions) |  | March 31, 2023 |  | December 31, 2022 |
| Long-term debt |  | $ | 8,708 |  |  | $ | 8,702 |  |
| Current portion of long-term debt |  | 142 |  |  | 140 |  |
| Less: Cash and cash equivalents |  | 3,347 |  |  | 3,520 |  |
| Net debt |  | $ | 5,503 |  |  | $ | 5,322 |  |

[0001783180-23-000036:8k_2_02:97]
13
