# CARR 8-K — 0001783180-25-000047 filed 2025-07-29

## item codes, every 8-K on or before 2025-07-29

- 2025-07-29 0001783180-25-000058 — 8.01, 9.01
- 2025-07-29 0001783180-25-000047 — 2.02, 9.01
- 2025-06-05 0000950142-25-001575 — 7.01
- 2025-05-01 0001783180-25-000028 — 2.02, 7.01, 9.01
- 2025-04-17 0000950142-25-001103 — 5.02
- 2025-04-11 0001783180-25-000021 — 5.02, 5.07, 9.01
- 2025-02-11 0001783180-25-000006 — 2.02, 9.01
- 2025-01-15 0000950142-25-000133 — 5.02, 9.01
- 2024-12-20 0001783180-24-000093 — 1.01, 1.02, 2.03, 9.01
- 2024-12-03 0000950142-24-002874 — 5.02
- 2024-12-02 0000950142-24-002865 — 7.01, 9.01
- 2024-11-08 0000950142-24-002699 — 1.01, 2.03, 9.01
- 2024-10-28 0000950142-24-002640 — 8.01
- 2024-10-28 0000950142-24-002638 — 8.01
- 2024-10-24 0001783180-24-000084 — 2.02, 7.01, 9.01
- 2024-10-18 0000950142-24-002601 — 1.01
- 2024-08-15 0001140361-24-037426 — 7.01, 9.01
- 2024-07-25 0001783180-24-000075 — 2.02, 9.01
- 2024-06-21 0001783180-24-000069 — 5.02
- 2024-06-21 0000950142-24-001676 — 5.02
- 2024-06-07 0001783180-24-000062 — 5.02, 5.03, 9.01
- 2024-06-03 0000950142-24-001538 — 1.02, 7.01, 9.01
- 2024-05-17 0001783180-24-000049 — 1.01, 1.02, 2.03, 9.01
- 2024-04-25 0001783180-24-000042 — 2.02, 9.01
- 2024-04-19 0001783180-24-000035 — 5.07, 9.01
- 2024-04-19 0000950142-24-001162 — 5.07 — amendment of 0001783180-24-000035
- 2024-02-06 0001783180-24-000007 — 2.02, 9.01
- 2024-02-01 0000950142-24-000264 — 5.02
- 2024-01-02 0001140361-24-000034 — 1.01, 2.01, 2.03, 5.02, 7.01, 9.01
- 2023-12-13 0001140361-23-057415 — 1.01, 9.01
- 2023-12-08 0001140361-23-056751 — 7.01, 9.01
- 2023-11-30 0000950142-23-002884 — 1.01, 2.03, 8.01, 9.01
- 2023-11-16 0000950142-23-002788 — 8.01, 9.01
- 2023-11-13 0001140361-23-052667 — 7.01, 8.01, 9.01
- 2023-10-26 0001783180-23-000063 — 2.02, 9.01
- 2023-07-27 0001783180-23-000053 — 2.02, 9.01
- 2023-06-12 0000950142-23-001664 — 5.02
- 2023-05-25 0000950142-23-001541 — 1.01, 1.02, 2.03, 9.01
- 2023-04-26 0000950142-23-001205 — 1.01, 9.01
- 2023-04-25 0001783180-23-000036 — 2.02, 7.01, 9.01
- 2023-04-25 0000950142-23-001199 — 7.01, 8.01, 9.01
- 2023-04-21 0001783180-23-000032 — 5.07, 9.01
- 2023-02-07 0001783180-23-000010 — 2.02, 9.01
- 2022-10-27 0001783180-22-000054 — 2.02, 7.01, 9.01
- 2022-09-29 0000950142-22-002805 — 5.02, 9.01
- 2022-07-28 0001783180-22-000045 — 2.02, 9.01
- 2022-04-28 0001783180-22-000032 — 2.02, 9.01
- 2022-04-15 0001783180-22-000024 — 5.07, 9.01
- 2022-02-08 0001783180-22-000008 — 2.02, 9.01
- 2022-02-07 0000950142-22-000510 — 8.01, 9.01
- 2022-01-03 0000950142-22-000023 — 8.01, 9.01
- 2021-12-17 0001783180-21-000071 — 5.02, 7.01, 9.01
- 2021-11-23 0001783180-21-000068 — 5.03, 9.01
- 2021-10-28 0001783180-21-000062 — 2.02, 9.01
- 2021-08-27 0001783180-21-000056 — 8.01
- 2021-07-30 0001783180-21-000053 — 1.01
- 2021-07-29 0001783180-21-000049 — 2.02, 8.01, 9.01
- 2021-07-27 0000950142-21-002448 — 8.01, 9.01
- 2021-07-15 0000950142-21-002362 — 5.02, 9.01
- 2021-06-09 0000950142-21-001885 — 5.02, 9.01
- 2021-04-29 0001783180-21-000029 — 2.02, 9.01
- 2021-04-22 0001140361-21-013889 — 5.02, 9.01
- 2021-04-20 0001783180-21-000021 — 5.07, 9.01
- 2021-04-19 0000950142-21-001308 — 8.01, 9.01
- 2021-02-09 0001783180-21-000009 — 2.02, 9.01
- 2021-02-05 0001140361-21-003513 — 8.01, 9.01
- 2020-12-23 0001140361-20-029419 — 7.01, 9.01
- 2020-12-22 0001140361-20-029097 — 8.01
- 2020-12-14 0001140361-20-028246 — 5.03, 9.01
- 2020-12-07 0001140361-20-027515 — 1.01, 7.01, 9.01
- 2020-10-29 0001783180-20-000063 — 2.02, 9.01
- 2020-10-19 0001140361-20-023241 — 5.02, 7.01, 9.01
- 2020-09-23 0001140361-20-021220 — 8.01, 9.01
- 2020-09-22 0001140361-20-021124 — 8.01, 9.01
- 2020-07-30 0001783180-20-000045 — 2.02, 9.01
- 2020-06-19 0001140361-20-014325 — 1.01, 2.03, 9.01
- 2020-06-16 0001140361-20-013880 — 8.01, 9.01
- 2020-06-03 0001140361-20-012939 — 1.01, 9.01
- 2020-05-08 0001783180-20-000013 — 2.02, 9.01
- 2020-04-03 0001140361-20-007888 — 1.01, 5.02, 5.03, 5.05, 7.01, 9.01
- 2020-03-16 0001140361-20-005868 — 8.01, 9.01

## late-filing notifications on or before 2025-07-29

- none on or before 2025-07-29

## item 2.02 — earnings release, exhibit 99.1

[0001783180-25-000047:8k_2_02:1]
EX-99
2
a99-q22025earningsexhibit.htm
EX-99

[0001783180-25-000047:8k_2_02:2]
Document

[0001783180-25-000047:8k_2_02:3]
Exhibit 99

[0001783180-25-000047:8k_2_02:4]
Carrier Reports Strong Second Quarter 2025 Results

[0001783180-25-000047:8k_2_02:5]
•Net sales up 3%; organic sales up 6%

[0001783180-25-000047:8k_2_02:6]
•GAAP EPS of $0.70 up 56% and adjusted EPS of $0.92 up 26%

[0001783180-25-000047:8k_2_02:7]
•GAAP operating margin up 260 bps; adjusted operating margin up 130 bps

[0001783180-25-000047:8k_2_02:8]
•Net cash flows from operating activities were $649 million and free cash flow was $568 million

[0001783180-25-000047:8k_2_02:9]
•Reaffirming full-year 2025 guidance for sales, adjusted operating margin, adjusted EPS and free cash flow*

[0001783180-25-000047:8k_2_02:10]
PALM BEACH GARDENS, Fla., July 29, 2025 – Carrier Global Corporation (NYSE:CARR), global leader in intelligent climate and energy solutions, today reported strong financial results for the second quarter of 2025 and reaffirmed its full year guidance.

[0001783180-25-000047:8k_2_02:11]
“We delivered another quarter of strong financial performance," said Carrier Chairman & CEO David Gitlin. “Organic sales growth of 6% was driven by strong results in our Climate Solutions Americas segment, with Commercial1 sales up 45% and total company aftermarket sales up 13%. Adjusted operating margins expanded 130 basis points driven by strong organic growth and productivity, leading to over 25% adjusted EPS growth. With a strong first half, we remain committed to accelerating growth driven by differentiated products, aftermarket offerings and system solutions. We are maintaining our full-year outlook for sales, adjusted operating margin expansion and adjusted EPS, representing about 20% adjusted EPS growth at the midpoint."

[0001783180-25-000047:8k_2_02:12]
1.Excludes NORESCO

[0001783180-25-000047:8k_2_02:13]
1

[0001783180-25-000047:8k_2_02:14]
Second Quarter 2025 Results

[0001783180-25-000047:8k_2_02:15]
Total Company

[0001783180-25-000047:8k_2_02:16]
|  | (Unaudited) |
|  | Three Months Ended June 30 |  |
| (In millions) | 2025 | 2024 | Change |  |  |  |
| Net sales | $ | 6,113 |  | $ | 5,934 |  | 3 | % |  |  |  |
| Organic sales | 6 | % |  |  |  |  |  |
| Operating profit | $ | 903 |  | $ | 724 |  | 25 | % |  |  |  |
| Operating margin | 14.8 | % | 12.2 | % | 260 bps |  |  |  |
| Adjusted operating profit | $ | 1,166 |  | $ | 1,056 |  | 10 | % |  |  |  |
| Adjusted operating margin | 19.1 | % | 17.8 | % | 130 bps |  |  |  |
| Diluted earnings per share: |  |  |  |  |  |  |
| Continuing operations | $ | 0.70 |  | $ | 0.45 |  | 56 | % |  |  |  |
| Continuing operations - Adjusted | $ | 0.92 |  | $ | 0.73 |  | 26 | % |  |  |  |

[0001783180-25-000047:8k_2_02:17]
Carrier’s second quarter sales of $6.1 billion increased 3% compared to the prior year. Organic sales growth of 6% was offset by a 4% headwind from net acquisitions and divestitures, driven by the sale of Commercial Refrigeration in Q4 2024. Foreign currency translation was a 1% tailwind to sales growth.

[0001783180-25-000047:8k_2_02:18]
GAAP operating profit in the quarter of $903 million was up 25% from last year driven by strong operational performance, the absence of backlog and inventory step-up amortization and a decrease in acquisition and divestiture-related costs. Adjusted operating profit of $1,166 million was up 10%, largely driven by strong organic growth and productivity. Net earnings from continuing operations were $608 million and adjusted net earnings from continuing operations was $796 million. GAAP EPS from continuing operations was $0.70 and adjusted EPS from continuing operations was $0.92 driven by higher operating profit, lower net interest expense and benefits of a lower share count.

[0001783180-25-000047:8k_2_02:19]
2

[0001783180-25-000047:8k_2_02:20]
Climate Solutions Americas (CSA)

[0001783180-25-000047:8k_2_02:21]
|  | (Unaudited) |
|  | Three Months Ended June 30 |  |
| (In millions) | 2025 | 2024 | Change |  |  |  |
| Net sales | $ | 3,252 |  | $ | 2,865 |  | 14 | % |  |  |  |
| Organic sales | 14 | % |  |  |  |  |  |
| Segment operating profit | $ | 879 |  | $ | 713 |  | 23 | % |  |  |  |
| Segment operating margin | 27.0 | % | 24.9 | % | 210 bps |  |  |  |

[0001783180-25-000047:8k_2_02:22]
CSA segment sales increased 14%. Organic sales were up 14%, driven by continued strength in Commercial1 up 45% and Residential up over 10%, partially offset by  a decline in Light Commercial.

[0001783180-25-000047:8k_2_02:23]
Segment operating margin increased 210 basis points driven by strong organic sales growth and productivity.

[0001783180-25-000047:8k_2_02:24]
Climate Solutions Europe (CSE)

[0001783180-25-000047:8k_2_02:25]
|  | (Unaudited) |
|  | Three Months Ended June 30 |  |
| (In millions) | 2025 | 2024 | Change |  |  |  |
| Net sales | $ | 1,253 |  | $ | 1,194 |  | 5 | % |  |  |  |
| Organic sales | — | % |  |  |  |  |  |
| Segment operating profit | $ | 99 |  | $ | 93 |  | 6 | % |  |  |  |
| Segment operating margin | 7.9 | % | 7.8 | % | 10 bps |  |  |  |

[0001783180-25-000047:8k_2_02:26]
CSE segment sales increased 5%. Organic sales were flat, with Commercial up low-single digits while Residential and Light Commercial was about flat.

[0001783180-25-000047:8k_2_02:27]
Segment operating margin increased 10 basis points, driven by productivity including cost synergies, partially offset by geographic and product mix.

[0001783180-25-000047:8k_2_02:28]
1.Excludes NORESCO

[0001783180-25-000047:8k_2_02:29]
3

[0001783180-25-000047:8k_2_02:30]
Climate Solutions Asia Pacific, Middle East & Africa (CSAME)

[0001783180-25-000047:8k_2_02:31]
|  | (Unaudited) |
|  | Three Months Ended June 30 |  |
| (In millions) | 2025 | 2024 | Change |  |  |  |
| Net sales | $ | 882 |  | $ | 902 |  | (2) | % |  |  |  |
| Organic sales | (4) | % |  |  |  |  |  |
| Segment operating profit | $ | 135 |  | $ | 157 |  | (14) | % |  |  |  |
| Segment operating margin | 15.3 | % | 17.4 | % | (210) bps |  |  |  |

[0001783180-25-000047:8k_2_02:32]
CSAME segment sales declined 2%. Organic sales were down 4%, mainly driven by Residential Light Commercial in China, partially offset by strength in India, Japan and the Middle East.

[0001783180-25-000047:8k_2_02:33]
Segment operating margin decreased 210 basis points with strong productivity more than offset by a prior year favorable currency impact and lower volume.

[0001783180-25-000047:8k_2_02:34]
Climate Solutions Transportation (CST)

[0001783180-25-000047:8k_2_02:35]
|  | (Unaudited) |
|  | Three Months Ended June 30 |  |
| (In millions) | 2025 | 2024 | Change |  |  |  |
| Net sales | $ | 726 |  | $ | 973 |  | (25) | % |  |  |  |
| Organic sales | (1) | % |  |  |  |  |  |
| Segment operating profit | $ | 128 |  | $ | 138 |  | (7) | % |  |  |  |
| Segment operating margin | 17.6 | % | 14.2 | % | 340 bps |  |  |  |

[0001783180-25-000047:8k_2_02:36]
CST sales declined 25% driven by the impact from the divestiture of Commercial Refrigeration. Organic sales growth declined 1% with mid-single digit growth in Container and low-single digit growth in North America Truck and Trailer more than offset by declines in Europe and Asia Truck and Trailer.

[0001783180-25-000047:8k_2_02:37]
Segment operating margin increased 340 basis points largely due to the Commercial Refrigeration exit during Q4 2024.

[0001783180-25-000047:8k_2_02:38]
4

[0001783180-25-000047:8k_2_02:39]
Cash Flow

[0001783180-25-000047:8k_2_02:40]
|  |  | (Unaudited) |  | (Unaudited) |
|  |  | Three Months Ended June 30, |  | Six Months EndedJune 30, |
| (In millions) |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Net cash flows provided by operating activities |  | $ | 649 |  |  | $ | 660 |  |  | $ | 1,132 |  |  | $ | 700 |  |
| Less: Capital expenditures - continuing operations |  | (81) |  |  | (108) |  |  | (144) |  |  | (210) |  |
| Less: Capital expenditures - discontinued operations |  | — |  |  | (3) |  |  | — |  |  | (5) |  |
| Free cash flow |  | $ | 568 |  |  | $ | 549 |  |  | $ | 988 |  |  | $ | 485 |  |

[0001783180-25-000047:8k_2_02:41]
Net cash flows generated from operating activities were $649 million and capital expenditures were $81 million, resulting in free cash flow of $568 million.

[0001783180-25-000047:8k_2_02:42]
Full-Year 2025 Guidance**

[0001783180-25-000047:8k_2_02:43]
|  | Current Guidance**No change vs. prior guidance | Prior Guidance |  |
| Sales | ~$23 billion~$750 million revenue headwind from CCR exitOrganic* up MSDFX 1%Acquisitions 0%Divestitures (3%) | ~$23 billion~$750 million revenue headwind from CCR exitOrganic* up MSDFX 1%Acquisitions 0%Divestitures (3%) |  |
| Adjusted Operating Margin* | 16.5% – 17.0%+ ~100 bps Y/Y | 16.5% – 17.0%+ ~100 bps Y/Y |  |
| Adjusted EPS* | $3.00 – $3.10~17-21% Y/Y | $3.00 – $3.10~17-21% Y/Y |  |
| Free Cash Flow* | $2.4 – $2.6 billionIncludes the expected results of continuing and discontinued operations | $2.4 – $2.6 billionIncludes the expected results of continuing and discontinued operations |  |

[0001783180-25-000047:8k_2_02:44]
*Note: When the company provides expectations for organic sales, adjusted operating profit, adjusted operating margin, adjusted EPS and free cash flow on a forward-looking basis, a reconciliation of the differences between the non-GAAP expectations and the corresponding GAAP measures generally is not available without unreasonable effort. See “Use and Definitions of Non-GAAP Financial Measures” below for additional information.

[0001783180-25-000047:8k_2_02:45]
**As of July 29, 2025

[0001783180-25-000047:8k_2_02:46]
5

[0001783180-25-000047:8k_2_02:47]
Conference Call

[0001783180-25-000047:8k_2_02:48]
Carrier will host a webcast of its earnings conference call today, Tuesday, July 29, 2025, at 7:30 a.m. ET. To access the webcast, visit the Events & Presentations section of the Carrier Investor Relations site at ir.carrier.com/news-and-events/events-and-presentations or to listen to the earnings call by phone, participants must pre-register at Carrier Earnings Call Registration. All registrants will receive dial-in information and a PIN allowing access to the live call.

[0001783180-25-000047:8k_2_02:49]
Cautionary Statement

[0001783180-25-000047:8k_2_02:50]
6

[0001783180-25-000047:8k_2_02:51]
About Carrier

[0001783180-25-000047:8k_2_02:52]
Carrier Global Corporation, global leader in intelligent climate and energy solutions, is committed to creating innovations that bring comfort, safety and sustainability to life. Through cutting-edge advancements in climate solutions such as temperature control, air quality and transportation, we improve lives, empower critical industries and ensure the safe transport of food, life-saving medicines and more. Since inventing modern air conditioning in 1902, we lead with purpose: enhancing the lives we live and the world we share. We continue to lead because of our world-class, inclusive workforce that puts the customer at the center of everything we do. For more information, visit corporate.carrier.com or follow Carrier on social media at @Carrier.

[0001783180-25-000047:8k_2_02:53]
Carrier. For the World We Share.

[0001783180-25-000047:8k_2_02:54]
CARR-IR

[0001783180-25-000047:8k_2_02:55]
Contact:

[0001783180-25-000047:8k_2_02:56]
Investor Relations

[0001783180-25-000047:8k_2_02:57]
Michael Rednor

[0001783180-25-000047:8k_2_02:58]
561-365-2020

[0001783180-25-000047:8k_2_02:59]
InvestorRelations@Carrier.com

[0001783180-25-000047:8k_2_02:60]
7

[0001783180-25-000047:8k_2_02:61]
Media Inquiries

[0001783180-25-000047:8k_2_02:62]
Jason Shockley

[0001783180-25-000047:8k_2_02:63]
561-542-0207

[0001783180-25-000047:8k_2_02:64]
Jason.Shockley@Carrier.com

[0001783180-25-000047:8k_2_02:65]
8

[0001783180-25-000047:8k_2_02:66]
SELECTED FINANCIAL DATA, NON-GAAP MEASURES AND DEFINITIONS

[0001783180-25-000047:8k_2_02:67]
Following are tables that present selected financial data of Carrier Global Corporation (“Carrier”). Also included are reconciliations of non-GAAP measures to their most comparable GAAP measures.

[0001783180-25-000047:8k_2_02:68]
As a result of Carrier's portfolio transformation, Carrier revised its reportable segments during the first quarter of 2025 to better reflect its business strategy, align its management reporting and increase transparency for investors. In connection with the revised structure, the Chief Operating Decision Maker changed the measure used to evaluate segment profitability from Operating profit to Segment operating profit. It represents operating profit (a GAAP measure) adjusted to exclude restructuring costs, amortization of acquired intangible assets and other significant items of a nonoperational nature. All prior period comparative information has been recast to reflect the revised segment structure.

[0001783180-25-000047:8k_2_02:69]
Use and Definitions of Non-GAAP Financial Measures

[0001783180-25-000047:8k_2_02:70]
Carrier reports its financial results in accordance with accounting principles generally accepted in the United States ("GAAP"). We supplement the reporting of our financial information determined under GAAP with certain non-GAAP financial information. The non-GAAP information presented provides investors with additional useful information, but should not be considered in isolation or as substitutes for the related GAAP measures. Moreover, other companies may define non-GAAP measures differently, which limits the usefulness of these measures for comparisons with such other companies. We encourage investors to review our financial statements and publicly filed reports in their entirety and not to rely on any single financial measure. A reconciliation of the non-GAAP measures to the corresponding amounts prepared in accordance with GAAP appears in the tables in this Appendix. The tables provide additional information as to the items and amounts that have been excluded from the adjusted measures.

[0001783180-25-000047:8k_2_02:71]
Organic sales, adjusted operating profit, adjusted operating margin, adjusted net income, adjusted earnings per share (“EPS”), adjusted effective tax rate and net debt are non-GAAP financial measures and are associated with Carrier's continuing operations unless specifically noted.

[0001783180-25-000047:8k_2_02:72]
Organic sales represents consolidated net sales (a GAAP measure), excluding the impact of foreign currency translation, acquisitions and divestitures completed in the preceding twelve months and other significant items of a nonoperational nature (hereinafter referred to as “other significant items”). Adjusted operating profit represents consolidated operating profit (a GAAP measure), excluding restructuring costs, amortization of acquired intangibles and other significant items. Adjusted operating margin represents adjusted operating profit as a percentage of consolidated net sales (a GAAP measure). Adjusted net income represents net income attributable to common shareowners (a GAAP measure), excluding restructuring costs, amortization of acquired intangibles and other significant items. Adjusted EPS represents diluted earnings per share (a GAAP measure), excluding restructuring costs, amortization of acquired intangibles and other significant items. The adjusted effective tax rate represents the effective tax rate (a GAAP measure), excluding restructuring costs, amortization of acquired intangibles and other significant items. Net debt represents long-term debt (a GAAP measure) less cash and cash equivalents (a GAAP measure).

[0001783180-25-000047:8k_2_02:73]
Free cash flow is a non-GAAP financial measure that represents net cash flows provided by continuing operating activities (a GAAP measure) less capital expenditures. Management believes free cash flow is a useful measure of liquidity and an additional basis for assessing Carrier’s ability to fund its activities, including the financing of acquisitions, debt service, repurchases of Carrier's common stock and distribution of earnings to shareowners. Orders are contractual commitments with customers to provide specified goods or services for an agreed upon price and may not be subject to penalty if cancelled.

[0001783180-25-000047:8k_2_02:74]
When Carrier provides our expectations for organic sales, adjusted operating profit, adjusted operating margin, adjusted effective tax rate, adjusted EPS and free cash flow on a forward-looking basis, a reconciliation of the differences between the non-GAAP expectations and the corresponding GAAP measures generally is not available without unreasonable effort due to potentially high variability, complexity and low visibility as to the items that would be excluded from the GAAP measure in the relevant future period, such as unusual gains and losses, the ultimate outcome of pending litigation, fluctuations in foreign currency exchange rates, the impact and timing of potential acquisitions and divestitures, future restructuring costs, and other structural changes or their probable significance. The variability of the excluded items may have a significant, and potentially unpredictable, impact on our future GAAP results.

[0001783180-25-000047:8k_2_02:75]
9

[0001783180-25-000047:8k_2_02:76]
Carrier Global Corporation

[0001783180-25-000047:8k_2_02:77]
Condensed Consolidated Statement of Operations

[0001783180-25-000047:8k_2_02:78]
|  |  | (Unaudited) |
|  |  | Three Months Ended June 30, |  | Six Months EndedJune 30, |
| (In millions, except per share amounts) |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Net sales |  |  |  |  |  |  |  |  |
| Product sales |  | $ | 5,477 |  |  | $ | 5,311 |  |  | $ | 10,129 |  |  | $ | 10,153 |  |
| Service sales |  | 636 |  |  | 623 |  |  | 1,202 |  |  | 1,201 |  |
| Total Net sales |  | 6,113 |  |  | 5,934 |  |  | 11,331 |  |  | 11,354 |  |
| Costs and expenses |  |  |  |  |  |  |  |  |
| Cost of products sold |  | (3,867) |  |  | (3,867) |  |  | (7,225) |  |  | (7,449) |  |
| Cost of services sold |  | (477) |  |  | (492) |  |  | (892) |  |  | (945) |  |
| Research and development |  | (161) |  |  | (160) |  |  | (314) |  |  | (352) |  |
| Selling, general and administrative |  | (813) |  |  | (789) |  |  | (1,542) |  |  | (1,596) |  |
| Total Costs and expenses |  | (5,318) |  |  | (5,308) |  |  | (9,973) |  |  | (10,342) |  |
| Equity method investment net earnings |  | 78 |  |  | 90 |  |  | 122 |  |  | 121 |  |
| Other income (expense), net |  | 30 |  |  | 8 |  |  | 52 |  |  | (24) |  |
| Operating profit |  | 903 |  |  | 724 |  |  | 1,532 |  |  | 1,109 |  |
| Non-service pension (expense) benefit |  | — |  |  | — |  |  | 1 |  |  | — |  |
| Interest (expense) income, net |  | (91) |  |  | (157) |  |  | (173) |  |  | (298) |  |
| Earnings before income taxes |  | 812 |  |  | 567 |  |  | 1,360 |  |  | 811 |  |
| Income tax (expense) benefit |  | (162) |  |  | (120) |  |  | (273) |  |  | (167) |  |
| Earnings from continuing operations |  | 650 |  |  | 447 |  |  | 1,087 |  |  | 644 |  |
| Discontinued operations, net of tax |  | (17) |  |  | 1,922 |  |  | (17) |  |  | 2,014 |  |
| Net earnings (loss) |  | 633 |  |  | 2,369 |  |  | 1,070 |  |  | 2,658 |  |
| Less: Non-controlling interest in subsidiaries' |  | 42 |  |  | 32 |  |  | 67 |  |  | 52 |  |
| Net earnings (loss) attributable to common shareowners |  | $ | 591 |  |  | $ | 2,337 |  |  | $ | 1,003 |  |  | $ | 2,606 |  |
| Amounts attributable to common shareowners: |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 608 |  |  | $ | 415 |  |  | $ | 1,020 |  |  | $ | 592 |  |
| Discontinued operations |  | (17) |  |  | 1,922 |  |  | (17) |  |  | 2,014 |  |
| Net earnings (loss) attributable to common shareowners |  | $ | 591 |  |  | $ | 2,337 |  |  | $ | 1,003 |  |  | $ | 2,606 |  |
| Earnings per share |  |  |  |  |  |  |  |  |
| Basic: |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 0.71 |  |  | $ | 0.46 |  |  | $ | 1.18 |  |  | $ | 0.66 |  |
| Discontinued operations |  | (0.02) |  |  | 2.13 |  |  | (0.01) |  |  | 2.24 |  |
| Net earnings (loss) |  | $ | 0.69 |  |  | $ | 2.59 |  |  | $ | 1.17 |  |  | $ | 2.90 |  |
| Diluted: |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 0.70 |  |  | $ | 0.45 |  |  | $ | 1.17 |  |  | $ | 0.65 |  |
| Discontinued operations |  | (0.02) |  |  | 2.10 |  |  | (0.02) |  |  | 2.20 |  |
| Net earnings (loss) |  | $ | 0.68 |  |  | $ | 2.55 |  |  | $ | 1.15 |  |  | $ | 2.85 |  |
| Weighted-average number of shares outstanding |  |  |  |  |  |  |  |  |
| Basic |  | 854.9 |  |  | 902.4 |  |  | 860.8 |  |  | 900.2 |  |
| Diluted |  | 866.3 |  |  | 915.3 |  |  | 872.3 |  |  | 913.6 |  |

[0001783180-25-000047:8k_2_02:79]
10

[0001783180-25-000047:8k_2_02:80]
Carrier Global Corporation

[0001783180-25-000047:8k_2_02:81]
Condensed Consolidated Balance Sheet

[0001783180-25-000047:8k_2_02:82]
|  |  | (Unaudited) |
| (In millions) |  | June 30, 2025 |  | December 31, 2024 |
| Assets |  |  |  |  |
| Cash and cash equivalents |  | $ | 1,797 |  |  | $ | 3,969 |  |
| Accounts receivable, net |  | 3,373 |  |  | 2,651 |  |
| Inventories, net |  | 2,888 |  |  | 2,299 |  |
| Other current assets |  | 1,073 |  |  | 972 |  |
| Total current assets |  | 9,131 |  |  | 9,891 |  |
| Future income tax benefits |  | 1,220 |  |  | 1,131 |  |
| Fixed assets, net |  | 3,182 |  |  | 2,999 |  |
| Operating lease right-of-use assets |  | 575 |  |  | 554 |  |
| Intangible assets, net |  | 6,770 |  |  | 6,432 |  |
| Goodwill |  | 15,672 |  |  | 14,601 |  |
| Pension and post-retirement assets |  | 50 |  |  | 43 |  |
| Equity method investments |  | 1,353 |  |  | 1,194 |  |
| Other assets |  | 540 |  |  | 558 |  |
| Total Assets |  | $ | 38,493 |  |  | $ | 37,403 |  |
| Liabilities and Equity |  |  |  |  |
| Accounts payable |  | $ | 3,214 |  |  | $ | 2,458 |  |
| Accrued liabilities |  | 4,508 |  |  | 4,182 |  |
| Current portion of long-term debt |  | 107 |  |  | 1,252 |  |
| Total current liabilities |  | 7,829 |  |  | 7,892 |  |
| Long-term debt |  | 11,336 |  |  | 11,026 |  |
| Future pension and post-retirement obligations |  | 221 |  |  | 214 |  |
| Future income tax obligations |  | 2,087 |  |  | 2,015 |  |
| Operating lease liabilities |  | 444 |  |  | 432 |  |
| Other long-term liabilities |  | 1,562 |  |  | 1,429 |  |
| Total Liabilities |  | 23,479 |  |  | 23,008 |  |
| Equity |  |  |  |  |
| Common stock |  | 9 |  |  | 9 |  |
| Treasury stock |  | (5,522) |  |  | (3,915) |  |
| Additional paid-in capital |  | 8,338 |  |  | 8,610 |  |
| Retained earnings |  | 12,294 |  |  | 11,483 |  |
| Accumulated other comprehensive loss |  | (413) |  |  | (2,106) |  |
| Non-controlling interest |  | 308 |  |  | 314 |  |
| Total Equity |  | 15,014 |  |  | 14,395 |  |
| Total Liabilities and Equity |  | $ | 38,493 |  |  | $ | 37,403 |  |

[0001783180-25-000047:8k_2_02:83]
11

[0001783180-25-000047:8k_2_02:84]
Carrier Global Corporation

[0001783180-25-000047:8k_2_02:85]
Condensed Consolidated Statement of Cash Flows

[0001783180-25-000047:8k_2_02:86]
(Unaudited)

[0001783180-25-000047:8k_2_02:87]
|  |  | Six Months EndedJune 30, |
| (In millions) |  | 2025 |  | 2024 |
| Operating Activities |  |  |  |  |
| Net earnings (loss) |  | $ | 1,070 |  |  | $ | 2,658 |  |
| Discontinued operations, net of tax |  | 17 |  |  | (2,014) |  |
| Adjustments for non-cash items, net: |  |  |  |  |
| Depreciation and amortization |  | 620 |  |  | 602 |  |
| Deferred income tax provision |  | (158) |  |  | (231) |  |
| Stock-based compensation costs |  | 44 |  |  | 40 |  |
| Equity method investment net earnings |  | (122) |  |  | (121) |  |
| (Gain) loss on sale of investments |  | (17) |  |  | — |  |
| Changes in operating assets and liabilities |  |  |  |  |
| Accounts receivable, net |  | (702) |  |  | (232) |  |
| Inventories, net |  | (412) |  |  | 7 |  |
| Accounts payable and accrued liabilities |  | 378 |  |  | 2 |  |
| Distributions from equity method investments |  | 81 |  |  | 12 |  |
| Other operating activities, net |  | (47) |  |  | (114) |  |
| Net cash flows provided by (used in) continuing operating activities |  | 752 |  |  | 609 |  |
| Net cash flows provided by (used in) discontinued operating activities |  | 380 |  |  | 91 |  |
| Net cash flows provided by (used in) operating activities |  | 1,132 |  |  | 700 |  |
| Investing Activities |  |  |  |  |
| Capital expenditures |  | (144) |  |  | (210) |  |
| Investment in businesses, net of cash acquired |  | (61) |  |  | (10,779) |  |
| Dispositions of businesses |  | 8 |  |  | — |  |
| Settlement of derivative contracts, net |  | 87 |  |  | (185) |  |
| Other investing activities, net |  | (3) |  |  | 27 |  |
| Net cash flows provided by (used in) continuing investing activities |  | (113) |  |  | (11,147) |  |
| Net cash flows provided by (used in) discontinued investing activities |  | 35 |  |  | 4,874 |  |
| Net cash flows provided by (used in) investing activities |  | (78) |  |  | (6,273) |  |
| Financing Activities |  |  |  |  |
| Increase (decrease) in short-term borrowings, net |  | (57) |  |  | 7 |  |
| Issuance of long-term debt |  | 15 |  |  | 2,555 |  |
| Repayment of long-term debt |  | (1,208) |  |  | (3,542) |  |
| Repurchases of common stock |  | (1,628) |  |  | — |  |
| Dividends paid on common stock |  | (390) |  |  | (330) |  |
| Dividends paid to non-controlling interest |  | (9) |  |  | (67) |  |
| Other financing activities, net |  | (17) |  |  | (14) |  |
| Net cash flows provided by (used in) continuing financing activities |  | (3,294) |  |  | (1,391) |  |
| Net cash flows provided by (used in) discontinued financing activities |  | — |  |  | (15) |  |
| Net cash flows provided by (used in) financing activities |  | (3,294) |  |  | (1,406) |  |
| Effect of foreign exchange rate changes on cash and cash equivalents |  | 68 |  |  | (82) |  |
| Net increase (decrease) in cash and cash equivalents and restricted cash, including cash classified in current assets held for sale |  | (2,172) |  |  | (7,061) |  |
| Less: Change in cash balances classified as assets held for sale |  | — |  |  | 34 |  |
| Net increase (decrease) in cash and cash equivalents and restricted cash |  | (2,172) |  |  | (7,095) |  |
| Cash, cash equivalents and restricted cash, beginning of period |  | 3,972 |  |  | 9,853 |  |
| Cash, cash equivalents and restricted cash, end of period |  | 1,800 |  |  | 2,758 |  |
| Less: restricted cash |  | 3 |  |  | 2 |  |
| Cash and cash equivalents, end of period |  | $ | 1,797 |  |  | $ | 2,756 |  |

[0001783180-25-000047:8k_2_02:88]
12

[0001783180-25-000047:8k_2_02:89]
Carrier Global Corporation

[0001783180-25-000047:8k_2_02:90]
Segment Summary

[0001783180-25-000047:8k_2_02:91]
|  | (Unaudited) |  |
|  | Three Months Ended June 30, |  | Six Months EndedJune 30, |  |
| (In millions) | 2025 |  | 2024 |  | 2025 |  | 2024 |  |
| Segment net sales |  |  |  |  |  |  |  |  |  |
| Climate Solutions Americas |  | $ | 3,252 |  | $ | 2,865 |  | $ | 5,824 |  | $ | 5,225 |  |
| Climate Solutions Europe |  | 1,253 |  | 1,194 |  | 2,422 |  | 2,486 |  |
| Climate Solutions Asia Pacific, Middle East & Africa |  | 882 |  | 902 |  | 1,708 |  | 1,786 |  |
| Climate Solutions Transportation |  | 726 |  | 973 |  | 1,377 |  | 1,857 |  |
| Segment net sales |  | $ | 6,113 |  | $ | 5,934 |  | $ | 11,331 |  | $ | 11,354 |  |
| Segment operating profit |  |  |  |  |  |  |  |  |  |
| Climate Solutions Americas |  | $ | 879 |  | $ | 713 |  | $ | 1,449 |  | $ | 1,138 |  |
| Climate Solutions Europe |  | 99 |  | 93 |  | 204 |  | 260 |  |
| Climate Solutions Asia Pacific, Middle East & Africa |  | 135 |  | 157 |  | 256 |  | 265 |  |
| Climate Solutions Transportation |  | 128 |  | 138 |  | 225 |  | 251 |  |
| Segment operating profit |  | $ | 1,241 |  | $ | 1,101 |  | $ | 2,134 |  | $ | 1,914 |  |
| Segment operating margin |  |  |  |  |  |  |  |  |  |
| Climate Solutions Americas |  | 27.0 | % |  | 24.9 | % |  | 24.9 | % |  | 21.8 | % |  |
| Climate Solutions Europe |  | 7.9 | % |  | 7.8 | % |  | 8.4 | % |  | 10.5 | % |  |
| Climate Solutions Asia Pacific, Middle East & Africa |  | 15.3 | % |  | 17.4 | % |  | 15.0 | % |  | 14.8 | % |  |
| Climate Solutions Transportation |  | 17.6 | % |  | 14.2 | % |  | 16.3 | % |  | 13.5 | % |  |

[0001783180-25-000047:8k_2_02:92]
13

[0001783180-25-000047:8k_2_02:93]
Components of Changes in Net Sales

[0001783180-25-000047:8k_2_02:94]
| Three Months Ended June 30, 2025 Compared with Three Months Ended June 30, 2024 |
|  | (Unaudited) |
|  | Factors Contributing to Total % change in Net Sales |
|  | Organic |  | FX Translation |  | Acquisitions / Divestitures, net |  | Other |  | Total |
| Climate Solutions Americas | 14 | % |  | — | % |  | — | % |  | — | % |  | 14 | % |
| Climate Solutions Europe | — | % |  | 5 | % |  | — | % |  | — | % |  | 5 | % |
| Climate Solutions Asia Pacific, Middle East & Africa | (4) | % |  | 2 | % |  | — | % |  | — | % |  | (2) | % |
| Climate Solutions Transportation | (1) | % |  | 1 | % |  | (25) | % |  | — | % |  | (25) | % |
| Consolidated | 6 | % |  | 1 | % |  | (4) | % |  | — | % |  | 3 | % |

[0001783180-25-000047:8k_2_02:95]
| Six Months Ended June 30, 2025 Compared with Six Months Ended June 30, 2024 |
|  | (Unaudited) |
|  | Factors Contributing to Total % change in Net Sales |
|  | Organic |  | FX Translation |  | Acquisitions / Divestitures, net |  | Other |  | Total |
| Climate Solutions Americas | 11 | % |  | — | % |  | — | % |  | — | % |  | 11 | % |
| Climate Solutions Europe | (4) | % |  | 1 | % |  | — | % |  | — | % |  | (3) | % |
| Climate Solutions Asia Pacific, Middle East & Africa | (5) | % |  | 1 | % |  | — | % |  | — | % |  | (4) | % |
| Climate Solutions Transportation | — | % |  | — | % |  | (26) | % |  | — | % |  | (26) | % |
| Consolidated | 4 | % |  | — | % |  | (4) | % |  | — | % |  | — | % |

[0001783180-25-000047:8k_2_02:96]
14

[0001783180-25-000047:8k_2_02:97]
Carrier Global Corporation

[0001783180-25-000047:8k_2_02:98]
Reconciliations

[0001783180-25-000047:8k_2_02:99]
|  |  | (Unaudited) |
|  |  | Three Months Ended June 30, |  | Six Months EndedJune 30, |
| (In millions) |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Reconciliation to Earnings before income taxes |  |  |  |  |  |  |  |  |
| Segment operating profit |  | $ | 1,241 |  |  | $ | 1,101 |  |  | $ | 2,134 |  |  | $ | 1,914 |  |
| Corporate and other |  | (75) |  |  | (45) |  |  | (120) |  |  | (94) |  |
| Restructuring costs |  | (47) |  |  | (29) |  |  | (55) |  |  | (37) |  |
| Amortization of acquired intangibles |  | (214) |  |  | (170) |  |  | (415) |  |  | (342) |  |
| Acquisition step-up amortization |  | — |  |  | (109) |  |  | — |  |  | (220) |  |
| Acquisition/divestiture-related costs |  | (9) |  |  | (24) |  |  | (19) |  |  | (72) |  |
| CCR gain |  | 7 |  |  | — |  |  | 7 |  |  | — |  |
| Viessmann-related hedges |  | — |  |  | — |  |  | — |  |  | (86) |  |
| Gain on liability adjustment |  | — |  |  | — |  |  | — |  |  | 46 |  |
| Non-service pension (expense) benefit |  | — |  |  | — |  |  | 1 |  |  | — |  |
| Interest (expense) income, net |  | (91) |  |  | (157) |  |  | (173) |  |  | (298) |  |
| Earnings before income taxes |  | $ | 812 |  |  | $ | 567 |  |  | $ | 1,360 |  |  | $ | 811 |  |

[0001783180-25-000047:8k_2_02:100]
|  |  | (Unaudited) |
|  |  | Three Months Ended June 30, |  | Six Months EndedJune 30, |
| (In millions) |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Reconciliation of Segment operating profit to Adjusted operating profit |  |  |  |  |  |  |  |  |
| Climate Solutions Americas |  | $ | 879 |  |  | $ | 713 |  |  | $ | 1,449 |  |  | $ | 1,138 |  |
| Climate Solutions Europe |  | 99 |  |  | 93 |  |  | 204 |  |  | 260 |  |
| Climate Solutions Asia Pacific, Middle East & Africa |  | 135 |  |  | 157 |  |  | 256 |  |  | 265 |  |
| Climate Solutions Transportation |  | 128 |  |  | 138 |  |  | 225 |  |  | 251 |  |
| Segment operating profit |  | $ | 1,241 |  |  | $ | 1,101 |  |  | $ | 2,134 |  |  | $ | 1,914 |  |
| Corporate and other |  | (75) |  |  | (45) |  |  | (120) |  |  | (94) |  |
| Adjusted operating profit |  | $ | 1,166 |  |  | $ | 1,056 |  |  | $ | 2,014 |  |  | $ | 1,820 |  |

[0001783180-25-000047:8k_2_02:101]
15

[0001783180-25-000047:8k_2_02:102]
Carrier Global Corporation

[0001783180-25-000047:8k_2_02:103]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP) Results

[0001783180-25-000047:8k_2_02:104]
Net Income, Earnings Per Share and Effective Tax Rate

[0001783180-25-000047:8k_2_02:105]
|  | (Unaudited) |
|  | Three Months Ended June 30, 2025 |  | Six Months Ended June 30, 2025 |
| (In millions, except per share amounts) | Reported |  | Adjustments |  | Adjusted |  | Reported |  | Adjustments |  | Adjusted |
| Net sales | $ | 6,113 |  |  | $ | — |  |  | $ | 6,113 |  |  | $ | 11,331 |  |  | $ | — |  |  | $ | 11,331 |  |
| Operating profit | $ | 903 |  |  | 263 |  | a | $ | 1,166 |  |  | $ | 1,532 |  |  | 482 |  | a | $ | 2,014 |  |
| Operating margin | 14.8 | % |  |  |  | 19.1 | % |  | 13.5 | % |  |  |  | 17.8 | % |
| Earnings before income taxes | $ | 812 |  |  | 263 |  | a | $ | 1,075 |  |  | $ | 1,360 |  |  | 482 |  | a,b | $ | 1,842 |  |
| Income tax (expense) benefit | $ | (162) |  |  | (75) |  | c | $ | (237) |  |  | $ | (273) |  |  | (133) |  | c | $ | (406) |  |
| Effective tax rate | 20.0 | % |  |  |  | 22.1 | % |  | 20.1 | % |  |  |  | 22.1 | % |
| Earnings from continuing operations attributable to common shareowners | $ | 608 |  |  | $ | 188 |  |  | $ | 796 |  |  | $ | 1,020 |  |  | $ | 349 |  |  | $ | 1,369 |  |
| Summary of Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of acquired intangibles |  |  | $ | 214 |  | a |  |  |  |  | $ | 415 |  | a |  |
| Restructuring costs |  |  | 47 |  | a |  |  |  |  | 55 |  | a |  |
| Acquisition/divestiture-related costs |  |  | 9 |  | a |  |  |  |  | 19 |  | a |  |
| CCR gain |  |  | (7) |  | a |  |  |  |  | (7) |  | a |  |
| Total adjustments |  |  | $ | 263 |  |  |  |  |  |  | $ | 482 |  |  |  |
| Tax effect on adjustments above |  |  | $ | (69) |  |  |  |  |  |  | $ | (127) |  |  |  |
| Tax specific adjustments |  |  | (6) |  |  |  |  |  |  | (6) |  |  |  |
| Total tax adjustments |  |  | $ | (75) |  | c |  |  |  |  | $ | (133) |  | c |  |
| Diluted shares outstanding | 866.3 |  |  |  |  | 866.3 |  |  | 872.3 |  |  |  |  | 872.3 |  |
| Diluted earnings per share: |  |  |  |  |  |  |  |  |  |  |  |
| Continuing operations | $ | 0.70 |  |  |  |  | $ | 0.92 |  |  | $ | 1.17 |  |  |  |  | $ | 1.57 |  |

[0001783180-25-000047:8k_2_02:106]
16

[0001783180-25-000047:8k_2_02:107]
Carrier Global Corporation

[0001783180-25-000047:8k_2_02:108]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP) Results

[0001783180-25-000047:8k_2_02:109]
Net Income, Earnings Per Share and Effective Tax Rate

[0001783180-25-000047:8k_2_02:110]
|  | (Unaudited) |
|  | Three Months Ended June 30, 2024 |  | Six Months Ended June 30, 2024 |
| (In millions, except per share amounts) | Reported |  | Adjustments |  | Adjusted |  | Reported |  | Adjustments |  | Adjusted |
| Net sales | $ | 5,934 |  |  | $ | — |  |  | $ | 5,934 |  |  | $ | 11,354 |  |  | $ | — |  |  | $ | 11,354 |  |
| Operating profit | $ | 724 |  |  | 332 |  | a | $ | 1,056 |  |  | $ | 1,109 |  |  | 711 |  | a | $ | 1,820 |  |
| Operating margin | 12.2 | % |  |  |  | 17.8 | % |  | 9.8 | % |  |  |  | 16.0 | % |
| Earnings before income taxes | $ | 567 |  |  | 344 |  | a,b | $ | 911 |  |  | $ | 811 |  |  | 723 |  | a,b | $ | 1,534 |  |
| Income tax (expense) benefit | $ | (120) |  |  | (87) |  | c | $ | (207) |  |  | $ | (167) |  |  | (173) |  | c | $ | (340) |  |
| Effective tax rate | 21.2 | % |  |  |  | 22.7 | % |  | 20.6 | % |  |  |  | 22.2 | % |
| Earnings from continuing operations attributable to common shareowners | $ | 415 |  |  | $ | 257 |  |  | $ | 672 |  |  | $ | 592 |  |  | $ | 550 |  |  | $ | 1,142 |  |
| Summary of Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of acquired intangibles |  |  | $ | 170 |  | a |  |  |  |  | $ | 342 |  | a |  |
| Restructuring costs |  |  | 29 |  | a |  |  |  |  | 37 |  | a |  |
| Acquisition/divestiture-related costs |  |  | 24 |  | a |  |  |  |  | 72 |  | a |  |
| Acquisition step-up amortization (1) |  |  | 109 |  | a |  |  |  |  | 220 |  | a |  |
| Viessmann-related hedges |  |  | — |  | a |  |  |  |  | 86 |  | a |  |
| Gain on liability adjustment (2) |  |  | — |  | a |  |  |  |  | (46) |  | a |  |
| Debt prepayment costs |  |  | $ | 12 |  | b |  |  |  |  | $ | 12 |  | b |  |
| Total adjustments |  |  | $ | 344 |  |  |  |  |  |  | $ | 723 |  |  |  |
| Tax effect on adjustments above |  |  | $ | (87) |  |  |  |  |  |  | $ | (173) |  |  |  |
| Total tax adjustments |  |  | $ | (87) |  | c |  |  |  |  | $ | (173) |  | c |  |
| Diluted shares outstanding | 915.3 |  |  |  |  | 915.3 |  |  | 913.6 |  |  |  |  | 913.6 |  |
| Diluted earnings per share: |  |  |  |  |  |  |  |  |  |  |  |
| Continuing operations | $ | 0.45 |  |  |  |  | $ | 0.73 |  |  | $ | 0.65 |  |  |  |  | $ | 1.25 |  |

[0001783180-25-000047:8k_2_02:111]
(1) Amortization of the step-up to fair value of acquired inventory and backlog.

[0001783180-25-000047:8k_2_02:112]
(2) Gain associated with an adjustment to our tax-related liability owed to UTC.

[0001783180-25-000047:8k_2_02:113]
17

[0001783180-25-000047:8k_2_02:114]
Free Cash Flow Reconciliation

[0001783180-25-000047:8k_2_02:115]
|  |  | (Unaudited) |
|  |  | Three Months Ended June 30, |  | Six Months EndedJune 30, |
| (In millions) |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Net cash flows provided by operating activities |  | $ | 649 |  |  | $ | 660 |  |  | $ | 1,132 |  |  | $ | 700 |  |
| Less: Capital expenditures - continuing operations |  | (81) |  |  | (108) |  |  | (144) |  |  | (210) |  |
| Less: Capital expenditures - discontinued operations |  | — |  |  | (3) |  |  | — |  |  | (5) |  |
| Free cash flow |  | $ | 568 |  |  | $ | 549 |  |  | $ | 988 |  |  | $ | 485 |  |

[0001783180-25-000047:8k_2_02:116]
Net Debt Reconciliation

[0001783180-25-000047:8k_2_02:117]
|  |  | (Unaudited) |
| (In millions) |  | June 30, 2025 |  | December 31, 2024 |
| Long-term debt |  | $ | 11,336 |  |  | $ | 11,026 |  |
| Current portion of long-term debt |  | 107 |  |  | 1,252 |  |
| Less: Cash and cash equivalents |  | 1,797 |  |  | 3,969 |  |
| Net debt |  | $ | 9,646 |  |  | $ | 8,309 |  |

[0001783180-25-000047:8k_2_02:118]
18
