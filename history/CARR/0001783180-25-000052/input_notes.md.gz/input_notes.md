# CARR notes — 0001783180-25-000052


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001783180-25-000052:notes:1]
[same as prior period, unchanged from 0001783180-25-000030:notes:1]

[0001783180-25-000052:notes:2]
[same as prior period, unchanged from 0001783180-25-000030:notes:2]


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001783180-25-000052:notes:3]
BASIS OF PRESENTATION
The Unaudited Condensed Consolidated Financial Statements include all accounts of the Company and its wholly-owned and majority-owned subsidiaries in which it has control. Inter-company accounts and transactions have been eliminated. Related party transactions between the Company and its equity method investees have not been eliminated. Non-controlling interest represents a non-controlling investor's interests in the results of subsidiaries that the Company controls and consolidates.

[0001783180-25-000052:notes:4]
[same as prior period, unchanged from 0001783180-25-000030:notes:4]

[0001783180-25-000052:notes:5]
During 2024, the Company completed several activities designed to simplify its business portfolio, transforming it into a pure-play climate and energy solutions provider. On January 2, 2024, the Company acquired the climate solutions business (the "VCS Business") of Viessmann Group GmbH & Co. KG (together with its affiliates, “Viessmann”). The VCS Business, primarily reported in the Climate Solutions Europe segment, is a premier residential and light commercial HVAC provider in Europe that expanded our portfolio to offer a global, comprehensive suite of sustainable and innovative building and cold-chain solutions. In addition, the Company divested its Commercial and Residential Fire, Access Solutions and Industrial Fire businesses which were historically reported in its Fire & Security segment. The transactions represented a single disposal plan to separately divest multiple businesses over different reporting periods and met the criteria to be presented as discontinued operations in the accompanying financial statements. The Company also divested its Commercial Refrigeration business (“CCR”) during 2024. CCR, which was historically reported in the Climate Solutions Transportation segment (previously named Refrigeration), did not meet the criteria to be presented as discontinued operations.

[0001783180-25-000052:notes:6]
[same as prior period, unchanged from 0001783180-25-000030:notes:6]

[0001783180-25-000052:notes:7]
As a result of the Company's portfolio transformation, the Company revised its reportable segments during the first quarter of 2025 to better reflect its business strategy, align its management reporting and increase transparency for investors. Under the revised segment structure, the Company has three new regional HVAC operating segments. Combined with the Climate Solutions Transportation operating segment, the four operating segments also serve as the Company's reportable segments. This model is designed to create a simplified, more focused and customer-centric organization across the globe. Each segment reports through separate management teams which regularly review their operating results with the Company's Chief Operating Decision Maker (the "CODM") determined in accordance with applicable accounting guidance. In connection with the revised structure, the CODM changed the measure used to evaluate segment profitability from Operating profit to Segment operating profit. All prior period comparative information has been recast to reflect the revised segment structure. See Note 17 – Segment Financial Data for additional information.

[0001783180-25-000052:notes:8]
[same as prior period, unchanged from 0001783180-25-000030:notes:8]

[0001783180-25-000052:notes:9]
On April 3, 2020 (the "Distribution Date"), United Technologies Corporation ("UTC"), since renamed RTX Corporation ("Raytheon Technologies Corporation" or "RTX"), completed the spin-off of Carrier into an independent, publicly traded company (the "Separation") through a pro-rata distribution (the "Distribution") on a one-for-one basis of all of the outstanding shares of common stock of Carrier to UTC shareowners who held shares of UTC common stock as of the close of business on March 19, 2020, the record date of the Distribution. In addition, the Company entered into several agreements with UTC and Otis Worldwide Corporation ("Otis") that govern various aspects of the relationship among the Company, UTC and Otis. As of June 30, 2025, only certain portions of the Tax Matters Agreement ("TMA") remain in effect.

[0001783180-25-000052:notes:10]
[same as prior period, unchanged from 0001783180-25-000030:notes:10]

[0001783180-25-000052:notes:11]
[same as prior period, unchanged from 0001783180-25-000030:notes:11]

[0001783180-25-000052:notes:12]
Recently Issued Accounting Pronouncements

[0001783180-25-000052:notes:13]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures ("ASU 2023-09"), which requires public entities to disclose disaggregated information about their effective tax rate reconciliation as well as information on income taxes paid. ASU 2023-09 is effective for annual periods beginning after December 15, 2024, with early adoption permitted. The ASU requires additional disclosures and is not expected to have a material impact on the Company's financial statements.

[0001783180-25-000052:notes:14]
In November 2024, the FASB issued ASU 2024-03, Disaggregation of Income Statement Expenses (DISE) ("ASU 2024-03"), which requires public entities to disclose disaggregated information about expenses by nature on an interim and annual basis. ASU 2024-03 is effective for fiscal years beginning after December 15, 2026 and interim periods within fiscal years beginning after December 15, 2027, with early adoption permitted. The Company is currently assessing the impact of this ASU on its financial statements.


## us-gaap:InventoryDisclosureTextBlock

[0001783180-25-000052:notes:15]
[same as prior period, unchanged from 0001783180-25-000030:notes:15]

[0001783180-25-000052:notes:16]
[same as prior period, unchanged from 0001783180-25-000030:notes:16]

[0001783180-25-000052:notes:17]
| (In millions) |  | June 30,2025 |  | December 31,2024 |
| Raw materials |  | $ | 700 |  |  | $ | 625 |  |
| Work-in-process |  | 231 |  |  | 213 |  |
| Finished goods |  | 1,957 |  |  | 1,461 |  |
| Inventories, net |  | $ | 2,888 |  |  | $ | 2,299 |  |

[0001783180-25-000052:notes:18]
The Company performs periodic assessments utilizing customer demand, production requirements and historical usage rates to determine the existence of excess and obsolete inventory and records necessary provisions to reduce such inventories to the lower of cost or estimated net realizable value. Raw materials, work-in-process and finished goods are net of valuation reserves of $340 million and $215 million as of June 30, 2025 and December 31, 2024, respectively.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001783180-25-000052:notes:19]
[same as prior period, unchanged from 0001783180-25-000030:notes:19]

[0001783180-25-000052:notes:20]
In connection with its revised segment structure, the Company performed a quantitative goodwill impairment test on its reporting units prior to the reorganization to determine if any impairment existed. The tests did not indicate any goodwill impairment. The Company then reassigned goodwill among its new reporting units using a relative fair value approach. Based on these analyses, the Climate Solutions Europe segment had a fair value of 10% above its carrying value. All other reporting units had fair values substantially in excess of their carrying values. However, there can be no assurances that changes in the macroeconomic environment or business conditions affecting our industry will not occur which could result in goodwill impairment charges in future periods.

[0001783180-25-000052:notes:21]
[same as prior period, unchanged from 0001783180-25-000030:notes:21]

[0001783180-25-000052:notes:22]
| (In millions) |  | Climate Solutions Americas |  | Climate Solutions Europe |  | Climate Solutions Asia Pacific, Middle East & Africa |  | Climate Solutions Transportation |  |  |  |  |  | Total |
| Balance as of December 31, 2024 |  | $ | 5,059 |  |  | $ | 7,035 |  |  | $ | 1,380 |  |  | $ | 1,127 |  |  |  |  |  |  | $ | 14,601 |  |
| Acquisitions |  | — |  |  | — |  |  | 7 |  |  | 44 |  |  |  |  |  |  | 51 |  |
| Foreign currency translation |  | 4 |  |  | 927 |  |  | 54 |  |  | 35 |  |  |  |  |  |  | 1,020 |  |
| Balance as of June 30, 2025 |  | $ | 5,063 |  |  | $ | 7,962 |  |  | $ | 1,441 |  |  | $ | 1,206 |  |  |  |  |  |  | $ | 15,672 |  |

[0001783180-25-000052:notes:23]
[same as prior period, unchanged from 0001783180-25-000030:notes:23]

[0001783180-25-000052:notes:24]
|  |  | June 30, 2025 |  | December 31, 2024 |
| (In millions) |  | Gross Amount |  | Accumulated Amortization |  | Net Amount |  | Gross Amount |  | Accumulated Amortization |  | Net Amount |
| Customer relationships |  | $ | 6,239 |  |  | $ | (1,351) |  |  | $ | 4,888 |  |  | $ | 5,607 |  |  | $ | (939) |  |  | $ | 4,668 |  |
| Patents and trademarks |  | 982 |  |  | (188) |  |  | 794 |  |  | 885 |  |  | (147) |  |  | 738 |  |
| Service portfolios and other |  | 1,715 |  |  | (627) |  |  | 1,088 |  |  | 1,530 |  |  | (504) |  |  | 1,026 |  |
| Total intangible assets |  | $ | 8,936 |  |  | $ | (2,166) |  |  | $ | 6,770 |  |  | $ | 8,022 |  |  | $ | (1,590) |  |  | $ | 6,432 |  |

[0001783180-25-000052:notes:25]
[same as prior period, unchanged from 0001783180-25-000030:notes:25]

[0001783180-25-000052:notes:26]
|  |  | Three Months Ended June 30, |  | Six Months EndedJune 30, |
| (In millions) |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Amortization expense of Intangible assets |  | $ | 221 |  |  | $ | 208 |  |  | $ | 429 |  |  | $ | 419 |  |


## us-gaap:DebtDisclosureTextBlock

[0001783180-25-000052:notes:27]
BORROWINGS AND LINES OF CREDIT
Long-term debt consisted of the following:

[0001783180-25-000052:notes:28]
| (In millions) |  |  |  | June 30,2025 |  | December 31,2024 |
| 2.242% Notes due 2025 (1) |  |  |  | $ | — |  |  | $ | 1,200 |  |
| 2.493% Notes due 2027 |  |  |  | 900 |  |  | 900 |  |
| 4.125% Notes due 2028 |  |  |  | 878 |  |  | 783 |  |
| 2.722% Notes due 2030 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.700% Notes due 2031 |  |  |  | 750 |  |  | 750 |  |
| 4.500% Notes due 2032 |  |  |  | 995 |  |  | 887 |  |
| 5.900% Notes due 2034 |  |  |  | 875 |  |  | 875 |  |
| 3.625% Notes due 2037 |  |  |  | 878 |  |  | 783 |  |
| 3.377% Notes due 2040 |  |  |  | 1,500 |  |  | 1,500 |  |
| 3.577% Notes due 2050 |  |  |  | 1,400 |  |  | 1,400 |  |
| 6.200% Notes due 2054 |  |  |  | 650 |  |  | 650 |  |
| Total long-term notes |  |  |  | 10,826 |  |  | 11,728 |  |
| Japanese Term Loan Facility |  |  |  | 374 |  |  | 342 |  |
| Other debt (including project financing obligations and finance leases) |  |  |  | 326 |  |  | 296 |  |
| Discounts and debt issuance costs |  |  |  | (83) |  |  | (88) |  |
| Total debt |  |  |  | 11,443 |  |  | 12,278 |  |
| Less: current portion of long-term debt |  |  |  | 107 |  |  | 1,252 |  |
| Long-term debt, net of current portion |  |  |  | $ | 11,336 |  |  | $ | 11,026 |  |

[0001783180-25-000052:notes:29]
(1) 2.242% Notes due February 15, 2025; repaid during February 2025.

[0001783180-25-000052:notes:30]
Revolving Credit Facility

[0001783180-25-000052:notes:31]
On December 20, 2024, the Company refinanced its revolving credit agreement with JPMorgan Chase Bank, N.A., as administrative agent, and certain other lenders, permitting aggregate borrowings of up to $2.5 billion pursuant to an unsecured, unsubordinated revolving credit facility that matures in December 2029 (the "Revolving Credit Facility"). The Revolving Credit Facility supports the Company's commercial paper program and can be used for other general corporate purposes. Borrowings are available in U.S. Dollars and Euros. U.S. Dollar borrowings bear interest at either a Term SOFR Rate plus 0.10% and a ratings-based margin or, alternatively, at an alternate base rate plus a ratings-based margin. Euro borrowings bear interest at an adjusted EURIBOR rate plus a ratings-based margin. A ratings-based commitment fee is charged on unused commitments. Upon entering into the agreement, the Company capitalized $11 million of deferred financing costs which are being amortized over its term. As of June 30, 2025, there were no borrowings outstanding under the Revolving Credit Facility.

[0001783180-25-000052:notes:32]
Commercial Paper Program

[0001783180-25-000052:notes:33]
The Company has a $2.0 billion USD-denominated unsecured, unsubordinated commercial paper program, which can be used for general corporate purposes, including the funding of working capital and potential acquisitions. As of June 30, 2025, there were no borrowings outstanding under the commercial paper program.

[0001783180-25-000052:notes:34]
Project Financing Arrangements

[0001783180-25-000052:notes:35]
The Company is involved in long-term construction contracts in which it arranges project financing with certain customers. As a result, the Company issued $10 million and $20 million of debt during the six months ended June 30, 2025 and 2024, respectively. Long-term debt repayments associated with these financing arrangements during the six months ended June 30, 2025 and 2024, were zero and $6 million, respectively.

[0001783180-25-000052:notes:36]
Debt Covenants

[0001783180-25-000052:notes:37]
The Revolving Credit Facility, the indenture for the long-term notes and the five-year, JPY 54 billion (approximately $400 million) senior unsecured term loan facility ("Japanese Term Loan Facility") contain affirmative and negative covenants customary for financings of these types, which, among other things, limit the Company's ability to incur certain liens, to make certain fundamental changes and to enter into sale and leaseback transactions. As of June 30, 2025, the Company was in compliance with the covenants under the agreements governing its outstanding indebtedness.


## us-gaap:FairValueDisclosuresTextBlock

[0001783180-25-000052:notes:38]
[same as prior period, unchanged from 0001783180-25-000030:notes:38]

[0001783180-25-000052:notes:39]
[same as prior period, unchanged from 0001783180-25-000030:notes:39]

[0001783180-25-000052:notes:40]
[same as prior period, unchanged from 0001783180-25-000030:notes:40]

[0001783180-25-000052:notes:41]
[same as prior period, unchanged from 0001783180-25-000030:notes:41]

[0001783180-25-000052:notes:42]
[same as prior period, unchanged from 0001783180-25-000030:notes:42]

[0001783180-25-000052:notes:43]
[same as prior period, unchanged from 0001783180-25-000030:notes:43]

[0001783180-25-000052:notes:44]
[same as prior period, unchanged from 0001783180-25-000030:notes:44]

[0001783180-25-000052:notes:45]
[same as prior period, unchanged from 0001783180-25-000030:notes:45]

[0001783180-25-000052:notes:46]
[same as prior period, unchanged from 0001783180-25-000030:notes:46]

[0001783180-25-000052:notes:47]
[same as prior period, unchanged from 0001783180-25-000030:notes:47]

[0001783180-25-000052:notes:48]
[same as prior period, unchanged from 0001783180-25-000030:notes:48]

[0001783180-25-000052:notes:49]
| (In millions) |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |
| June 30, 2025 |  |  |  |  |  |  |  |  |
| Derivative assets (1) |  | $ | 59 |  |  | $ | — |  |  | $ | 59 |  |  | $ | — |  |
| Derivative liabilities (2) |  | $ | (170) |  |  | $ | — |  |  | $ | (170) |  |  | $ | — |  |
| December 31, 2024 |  |  |  |  |  |  |  |  |
| Derivative assets (1) |  | $ | 82 |  |  | $ | — |  |  | $ | 82 |  |  | $ | — |  |
| Derivative liabilities (2) |  | $ | (41) |  |  | $ | — |  |  | $ | (41) |  |  | $ | — |  |

[0001783180-25-000052:notes:50]
[same as prior period, unchanged from 0001783180-25-000030:notes:50]

[0001783180-25-000052:notes:51]
[same as prior period, unchanged from 0001783180-25-000030:notes:51]

[0001783180-25-000052:notes:52]
[same as prior period, unchanged from 0001783180-25-000030:notes:52]

[0001783180-25-000052:notes:53]
|  |  | June 30, 2025 |  | December 31, 2024 |
| (In millions) |  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |
| Total long-term notes (1) |  | $ | 10,826 |  |  | $ | 10,095 |  |  | $ | 11,728 |  |  | $ | 10,798 |  |

[0001783180-25-000052:notes:54]
[same as prior period, unchanged from 0001783180-25-000030:notes:54]

[0001783180-25-000052:notes:55]
[same as prior period, unchanged from 0001783180-25-000030:notes:55]


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0001783180-25-000052:notes:56]
[same as prior period, unchanged from 0001783180-25-000030:notes:56]


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001783180-25-000052:notes:57]
[same as prior period, unchanged from 0001783180-25-000030:notes:57]

[0001783180-25-000052:notes:58]
[same as prior period, unchanged from 0001783180-25-000030:notes:58]

[0001783180-25-000052:notes:59]
|  |  | Three Months Ended June 30, |  | Six Months EndedJune 30, |
| (In millions) |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Defined benefit plans |  | $ | 15 |  |  | $ | 12 |  |  | $ | 20 |  |  | $ | 18 |  |
| Defined contribution plans |  | $ | 28 |  |  | $ | 35 |  |  | $ | 63 |  |  | $ | 74 |  |
| Multi-employer pension plans |  | $ | 4 |  |  | $ | 4 |  |  | $ | 7 |  |  | $ | 8 |  |

[0001783180-25-000052:notes:60]
[same as prior period, unchanged from 0001783180-25-000030:notes:60]

[0001783180-25-000052:notes:61]
|  |  | Three Months Ended June 30, |  | Six Months EndedJune 30, |
| (In millions) |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Service cost |  | $ | 4 |  |  | $ | 3 |  |  | $ | 7 |  |  | $ | 7 |  |
| Interest cost |  | 7 |  |  | 7 |  |  | 14 |  |  | 14 |  |
| Expected return on plan assets |  | (8) |  |  | (7) |  |  | (16) |  |  | (14) |  |
| Recognized actuarial net (gain) loss |  | 1 |  |  | — |  |  | 1 |  |  | — |  |
| Net settlement, curtailment and special termination benefit (gain) loss |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Net periodic pension expense (benefit) |  | $ | 4 |  |  | $ | 4 |  |  | $ | 6 |  |  | $ | 8 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001783180-25-000052:notes:62]
[same as prior period, unchanged from 0001783180-25-000030:notes:62]

[0001783180-25-000052:notes:63]
[same as prior period, unchanged from 0001783180-25-000030:notes:63]

[0001783180-25-000052:notes:64]
[same as prior period, unchanged from 0001783180-25-000030:notes:64]

[0001783180-25-000052:notes:65]
|  |  | Three Months Ended June 30, |  | Six Months EndedJune 30, |
| (In millions) |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Equity compensation costs - equity settled |  | $ | 21 |  |  | $ | 26 |  |  | $ | 44 |  |  | $ | 48 |  |
| Equity compensation costs - cash settled (1) |  | 2 |  |  | 1 |  |  | 1 |  |  | 1 |  |
| Total stock-based compensation expense |  | $ | 23 |  |  | $ | 27 |  |  | $ | 45 |  |  | $ | 49 |  |
| Amounts recorded in continuing operations |  | $ | 23 |  |  | $ | 21 |  |  | $ | 45 |  |  | $ | 40 |  |
| Amounts recorded in discontinued operations |  | — |  |  | 6 |  |  | — |  |  | 9 |  |
| Total stock-based compensation expense |  | $ | 23 |  |  | $ | 27 |  |  | $ | 45 |  |  | $ | 49 |  |

[0001783180-25-000052:notes:66]
[same as prior period, unchanged from 0001783180-25-000030:notes:66]


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001783180-25-000052:notes:67]
[same as prior period, unchanged from 0001783180-25-000030:notes:67]

[0001783180-25-000052:notes:68]
[same as prior period, unchanged from 0001783180-25-000030:notes:68]

[0001783180-25-000052:notes:69]
|  |  | Six Months EndedJune 30, |
| (In millions) |  | 2025 |  | 2024 |
| Balance as of January 1, |  | $ | 786 |  |  | $ | 568 |  |
| Warranties, performance guarantees issued and changes in estimated liability |  | 174 |  |  | 162 |  |
| Settlements made |  | (129) |  |  | (143) |  |
| Acquisitions |  | 1 |  |  | 202 |  |
| Other (1) |  | 30 |  |  | (8) |  |
| Balance as of June 30, |  | $ | 862 |  |  | $ | 781 |  |

[0001783180-25-000052:notes:70]
(1) The changes within Other include foreign currency translation activity.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001783180-25-000052:notes:71]
EQUITY
The authorized number of shares of common stock of Carrier is 4,000,000,000 shares of $0.01 par value. As of June 30, 2025 and December 31, 2024, 949,712,403 and 948,068,772 shares of common stock were issued, respectively, which includes 98,888,958 and 70,093,639 shares of treasury stock, respectively.

[0001783180-25-000052:notes:72]
[same as prior period, unchanged from 0001783180-25-000030:notes:71]

[0001783180-25-000052:notes:73]
[same as prior period, unchanged from 0001783180-25-000030:notes:72]

[0001783180-25-000052:notes:74]
On June 5, 2025, the Company entered into a repurchase agreement with Viessmann, an entity controlled by one of the Company's directors, to acquire an aggregate 4,267,425 shares of the Company's common stock at a price per share of $70.30 for an aggregate purchase price of $300 million. The Company recorded a liability of $300 million with an offsetting amount in a contra-equity account in Additional paid-in capital related to the future purchase. During the six months ended June 30, 2025, the Company repurchased 28.8 million shares of common stock for an aggregate purchase price of $1.9 billion, which included shares repurchased from Viessmann under the repurchase agreement. As a result, the Company had approximately $1.3 billion remaining under the current authorization at June 30, 2025. On July 1, 2025, the Company acquired the shares from Viessmann and reclassified the shares into Treasury stock.

[0001783180-25-000052:notes:75]
[same as prior period, unchanged from 0001783180-25-000030:notes:74]

[0001783180-25-000052:notes:76]
A summary of changes in the components of Accumulated other comprehensive income (loss) for the three and six months ended June 30, 2025 is as follows:

[0001783180-25-000052:notes:77]
| (In millions) |  | Foreign Currency Translation |  | Defined Benefit Pension and Post-retirement Plans |  |  |  | Unrealized Hedging Gains (Losses) |  | Accumulated Other Comprehensive Income (Loss) |
| Balance as of December 31, 2024 |  | $ | (2,053) |  |  | $ | (107) |  |  |  |  | $ | 54 |  |  | $ | (2,106) |  |
| Other comprehensive income (loss) before reclassifications, net |  | 634 |  |  | — |  |  |  |  | — |  |  | 634 |  |
| Amounts reclassified, pre-tax |  | — |  |  | — |  |  |  |  | (1) |  |  | (1) |  |
| Balance as of March 31, 2025 |  | $ | (1,419) |  |  | $ | (107) |  |  |  |  | $ | 53 |  |  | $ | (1,473) |  |
| Other comprehensive income (loss) before reclassifications, net |  | 1,067 |  |  | (6) |  |  |  |  | — |  |  | 1,061 |  |
| Amounts reclassified, pre-tax |  | — |  |  | 1 |  |  |  |  | (2) |  |  | (1) |  |
| Balance as of June 30, 2025 |  | $ | (352) |  |  | $ | (112) |  |  |  |  | $ | 51 |  |  | $ | (413) |  |

[0001783180-25-000052:notes:78]
A summary of changes in the components of Accumulated other comprehensive income (loss) for the three and six months ended June 30, 2024 is as follows:

[0001783180-25-000052:notes:79]
| (In millions) |  | Foreign Currency Translation |  | Defined Benefit Pension and Post-retirement Plans |  |  |  | Unrealized Hedging Gains (Losses) |  | Accumulated Other Comprehensive Income (Loss) |
| Balance as of December 31, 2023 |  | $ | (1,444) |  |  | $ | (100) |  |  |  |  | $ | 58 |  |  | $ | (1,486) |  |
| Other comprehensive income (loss) before reclassifications, net |  | (385) |  |  | — |  |  |  |  | — |  |  | (385) |  |
| Amounts reclassified, pre-tax |  | — |  |  | — |  |  |  |  | (1) |  |  | (1) |  |
| Balance as of March 31, 2024 |  | $ | (1,829) |  |  | $ | (100) |  |  |  |  | $ | 57 |  |  | $ | (1,872) |  |
| Other comprehensive income (loss) before reclassifications, net |  | (187) |  |  | — |  |  |  |  | — |  |  | (187) |  |
| Amounts reclassified, pre-tax |  | — |  |  | 1 |  |  |  |  | (1) |  |  | — |  |
| Divestitures, net |  | 373 |  |  | — |  |  |  |  | — |  |  | 373 |  |
| Balance as of June 30, 2024 |  | $ | (1,643) |  |  | $ | (99) |  |  |  |  | $ | 56 |  |  | $ | (1,686) |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001783180-25-000052:notes:80]
[same as prior period, unchanged from 0001783180-25-000030:notes:79]

[0001783180-25-000052:notes:81]
[same as prior period, unchanged from 0001783180-25-000030:notes:80]

[0001783180-25-000052:notes:82]
|  |  | Three Months Ended June 30, |  | Six Months EndedJune 30, |
| (In millions) |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Sales Type |  |  |  |  |  |  |  |  |
| Product |  | $ | 2,970 |  |  | $ | 2,586 |  |  | $ | 5,289 |  |  | $ | 4,690 |  |
| Service |  | 282 |  |  | 279 |  |  | 535 |  |  | 535 |  |
| Climate Solutions Americas sales |  | 3,252 |  |  | 2,865 |  |  | 5,824 |  |  | 5,225 |  |
| Product |  | 1,137 |  |  | 1,127 |  |  | 2,208 |  |  | 2,365 |  |
| Service |  | 116 |  |  | 67 |  |  | 214 |  |  | 121 |  |
| Climate Solutions Europe sales |  | 1,253 |  |  | 1,194 |  |  | 2,422 |  |  | 2,486 |  |
| Product |  | 697 |  |  | 747 |  |  | 1,357 |  |  | 1,475 |  |
| Service |  | 185 |  |  | 155 |  |  | 351 |  |  | 311 |  |
| Climate Solutions Asia Pacific, Middle East & Africa sales |  | 882 |  |  | 902 |  |  | 1,708 |  |  | 1,786 |  |
| Product |  | 673 |  |  | 851 |  |  | 1,275 |  |  | 1,623 |  |
| Service |  | 53 |  |  | 122 |  |  | 102 |  |  | 234 |  |
| Climate Solutions Transportation sales |  | 726 |  |  | 973 |  |  | 1,377 |  |  | 1,857 |  |
| Net sales |  | $ | 6,113 |  |  | $ | 5,934 |  |  | $ | 11,331 |  |  | $ | 11,354 |  |

[0001783180-25-000052:notes:83]
[same as prior period, unchanged from 0001783180-25-000030:notes:82]

[0001783180-25-000052:notes:84]
[same as prior period, unchanged from 0001783180-25-000030:notes:83]

[0001783180-25-000052:notes:85]
| (In millions) |  | June 30,2025 |  | December 31,2024 |
| Contract assets (included within Other current assets) |  | $ | 474 |  |  | $ | 366 |  |
| Contract assets, non-current (included within Other assets) |  | 47 |  |  | 65 |  |
| Total contract assets |  | 521 |  |  | 431 |  |
| Contract liabilities (included within Accrued liabilities) |  | (549) |  |  | (553) |  |
| Contract liabilities, non-current (included within Other long-term liabilities) |  | (178) |  |  | (164) |  |
| Total contract liabilities |  | (727) |  |  | (717) |  |
| Net contract assets (liabilities) |  | $ | (206) |  |  | $ | (286) |  |

[0001783180-25-000052:notes:86]
The timing of revenue recognition, billings and cash collections results in contract assets and contract liabilities. Contract assets relate to the conditional right to consideration for any completed performance under a contract when costs are incurred in excess of billings under the percentage-of-completion methodology. Contract liabilities relate to payments received in advance of performance under a contract or when the Company has a right to consideration that is conditioned upon transfer of a good or service to a customer. Contract liabilities are recognized as revenue as (or when) the Company performs under the contract.
The Company recognized revenue of $340 million during the six months ended June 30, 2025, that related to contract liabilities as of January 1, 2025. The Company expects a majority of its current contract liabilities at the end of the period to be recognized as revenue in the next 12 months.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0001783180-25-000052:notes:87]
[same as prior period, unchanged from 0001783180-25-000030:notes:86]

[0001783180-25-000052:notes:88]
[same as prior period, unchanged from 0001783180-25-000030:notes:87]


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0001783180-25-000052:notes:89]
Geographic external sales are attributed to the geographic regions based on their location of origin. With the exception of the U.S. presented in the table below, there were no individually significant countries with sales exceeding 10% of total sales during the three and six months ended June 30, 2025 and 2024.

[0001783180-25-000052:notes:90]
|  |  | Three Months Ended June 30, |  | Six Months EndedJune 30, |
| (In millions) |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| United States |  | $ | 3,429 |  |  | $ | 3,077 |  |  | $ | 6,168 |  |  | $ | 5,624 |  |
| International: |  |  |  |  |  |  |  |  |
| Europe |  | 1,520 |  |  | 1,678 |  |  | 2,920 |  |  | 3,429 |  |
| Asia Pacific |  | 981 |  |  | 1,003 |  |  | 1,922 |  |  | 1,963 |  |
| Other |  | 183 |  |  | 176 |  |  | 321 |  |  | 338 |  |
| Net sales |  | $ | 6,113 |  |  | $ | 5,934 |  |  | $ | 11,331 |  |  | $ | 11,354 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001783180-25-000052:notes:91]
[same as prior period, unchanged from 0001783180-25-000030:notes:90]

[0001783180-25-000052:notes:92]
[same as prior period, unchanged from 0001783180-25-000030:notes:91]

[0001783180-25-000052:notes:93]
|  | Three Months Ended June 30, |  | Six Months EndedJune 30, |
| (In millions) | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Climate Solutions Americas | $ | 1 |  |  | $ | 2 |  |  | $ | 4 |  |  | $ | 1 |  |
| Climate Solutions Europe | 26 |  |  | 17 |  |  | 26 |  |  | 27 |  |
| Climate Solutions Asia Pacific, Middle East & Africa | 7 |  |  | 6 |  |  | 8 |  |  | 4 |  |
| Climate Solutions Transportation | 1 |  |  | 1 |  |  | 2 |  |  | 1 |  |
| Total Segment | 35 |  |  | 26 |  |  | 40 |  |  | 33 |  |
| Corporate and other | 12 |  |  | 3 |  |  | 15 |  |  | 4 |  |
| Total restructuring costs (1) | $ | 47 |  |  | $ | 29 |  |  | $ | 55 |  |  | $ | 37 |  |
| Cost of sales | $ | 8 |  |  | $ | 13 |  |  | $ | 10 |  |  | $ | 21 |  |
| Selling, general and administrative | 39 |  |  | 16 |  |  | 45 |  |  | 16 |  |
| Total restructuring costs (1) | $ | 47 |  |  | $ | 29 |  |  | $ | 55 |  |  | $ | 37 |  |

[0001783180-25-000052:notes:94]
[same as prior period, unchanged from 0001783180-25-000030:notes:93]

[0001783180-25-000052:notes:95]
[same as prior period, unchanged from 0001783180-25-000030:notes:94]

[0001783180-25-000052:notes:96]
|  |  | Six Months EndedJune 30, |
| (In millions) |  | 2025 |  | 2024 |
| Balance as of January 1, |  | $ | 69 |  |  | $ | 41 |  |
| Net pre-tax restructuring costs |  | 44 |  |  | 34 |  |
| Acquisitions |  | — |  |  | 8 |  |
| Utilization, foreign exchange and other |  | (37) |  |  | (32) |  |
| Balance as of June 30, |  | $ | 76 |  |  | $ | 51 |  |

[0001783180-25-000052:notes:97]
As of June 30, 2025, the Company had $76 million accrued for costs associated with its announced restructuring initiatives. The balance relates to cost reduction efforts, primarily severance related across each of the Company's segments. The Company expects a majority of the balance to be utilized within one year.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001783180-25-000052:notes:98]
INCOME TAXES
The Company accounts for income tax expense in accordance with ASC 740, Income Taxes ("ASC 740"), which requires an estimate of the annual effective income tax rate for the full year to be applied to the respective interim period, taking into account year-to-date amounts and projected results for the full year. The effective tax rate for the three months ended June 30, 2025 was 20.0% compared with 21.2% for the three months ended June 30, 2024. The effective tax rate for the three months ended June 30, 2025 was lower than the effective tax rate for the three months ended June 30, 2024 primarily due to a state tax benefit of $6 million related to the utilization of a capital loss, a tax benefit of $6 million from the conclusion of the UTC 2020 U.S. Internal Revenue Service ("IRS") tax audit, a reduction in non-deductible interest expense and lower income tax costs associated with U.S. tax on international operations.

[0001783180-25-000052:notes:99]
The effective tax rate for the six months ended June 30, 2025 was 20.1% compared with 20.6% for the six months ended June 30, 2024. The year-over-year decrease was primarily driven by a $12 million tax benefit generated by the purchase of investment tax credits from a third-party, a state tax benefit of $6 million related to the utilization of a capital loss, a tax benefit of $6 million from the conclusion of the UTC 2020 IRS tax audit, a reduction in non-deductible interest expense and lower income tax costs associated with U.S. tax on international operations. These amounts were partially offset by the absence of a $21 million tax benefit associated with the TMA and UTC's conclusion of certain income tax matters from their 2017 and 2018 tax audit with the IRS recognized during the six months ended June 30, 2024.

[0001783180-25-000052:notes:100]
[same as prior period, unchanged from 0001783180-25-000030:notes:98]

[0001783180-25-000052:notes:101]
The Company conducts business globally and files income tax returns in U.S. federal, state and foreign jurisdictions. In certain jurisdictions, the Company's operations were included in UTC's combined tax returns for the periods through the Distribution. In the three months ended June 30, 2025, the IRS finalized the examination of UTC's tax year 2020, resulting in the recognition of a tax benefit of $6 million. Carrier's tax year 2022 is under examination by the IRS, but is in an early stage. The Australia tax office is auditing the Company's 2021 tax return, including the review of the disentanglement of the Chubb Australia business, with the audit expected to close in 2026. In the normal course of business, the Company is subject to examination by taxing authorities throughout the world, including Australia, Canada, China, France, Germany, Hong Kong, India, Italy, Mexico, the Netherlands, Poland, Singapore, the United Kingdom and the United States. The Company is no longer subject to U.S. federal income tax examination for years prior to 2022 and, with few exceptions, is no longer subject to state, local and foreign income tax examinations for tax years prior to 2014.

[0001783180-25-000052:notes:102]
In the ordinary course of business, there is inherent uncertainty in quantifying the Company's income tax positions. The Company assesses its income tax positions and records tax benefits for all years subject to examination based upon management’s evaluation of the facts, circumstances and information available at the reporting date. The Company believes that it is reasonably possible that a net decrease in unrecognized tax benefits of $15 million to $45 million may occur within 12 months as a result of additional uncertain tax positions, the revaluation of uncertain tax positions arising from examinations, appeals, court decisions and/or the expiration of tax statutes.


## us-gaap:EarningsPerShareTextBlock

[0001783180-25-000052:notes:103]
[same as prior period, unchanged from 0001783180-25-000030:notes:101]

[0001783180-25-000052:notes:104]
[same as prior period, unchanged from 0001783180-25-000030:notes:102]

[0001783180-25-000052:notes:105]
|  |  | Three Months Ended June 30, |  | Six Months EndedJune 30, |
| (In millions, except per share amounts) |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Net earnings (loss) attributable to common shareowners |  | $ | 591 |  |  | $ | 2,337 |  |  | $ | 1,003 |  |  | $ | 2,606 |  |
| Basic weighted-average number of shares outstanding |  | 854.9 |  |  | 902.4 |  |  | 860.8 |  |  | 900.2 |  |
| Stock awards and equity units (share equivalent) |  | 11.4 |  |  | 12.9 |  |  | 11.5 |  |  | 13.4 |  |
| Diluted weighted-average number of shares outstanding |  | 866.3 |  |  | 915.3 |  |  | 872.3 |  |  | 913.6 |  |
| Antidilutive shares excluded from computation of diluted earnings per share |  | 1.9 |  |  | 4.1 |  |  | 1.9 |  |  | 4.1 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001783180-25-000052:notes:106]
[same as prior period, unchanged from 0001783180-25-000030:notes:104]

[0001783180-25-000052:notes:107]
[same as prior period, unchanged from 0001783180-25-000030:notes:105]

[0001783180-25-000052:notes:108]
[same as prior period, unchanged from 0001783180-25-000030:notes:106]

[0001783180-25-000052:notes:109]
[same as prior period, unchanged from 0001783180-25-000030:notes:107]

[0001783180-25-000052:notes:110]
[same as prior period, unchanged from 0001783180-25-000030:notes:108]

[0001783180-25-000052:notes:111]
| (In millions) |  | January 2,2024 |
| Cash |  | $ | 11,156 |  |
| Common shares (58,608,959 shares at $51.20 per share) |  | 3,001 |  |
| Total consideration |  | $ | 14,157 |  |

[0001783180-25-000052:notes:112]
[same as prior period, unchanged from 0001783180-25-000030:notes:110]

[0001783180-25-000052:notes:113]
[same as prior period, unchanged from 0001783180-25-000030:notes:111]

[0001783180-25-000052:notes:114]
[same as prior period, unchanged from 0001783180-25-000030:notes:112]

[0001783180-25-000052:notes:115]
[same as prior period, unchanged from 0001783180-25-000030:notes:113]

[0001783180-25-000052:notes:116]
[same as prior period, unchanged from 0001783180-25-000030:notes:114]

[0001783180-25-000052:notes:117]
[same as prior period, unchanged from 0001783180-25-000030:notes:115]

[0001783180-25-000052:notes:118]
During 2024, $40 million of acquisition-related costs were incurred, of which $7 million and $37 million was recognized during the three and six months ended June 30, 2024, respectively. These acquisition costs are reflected within Selling, general and administrative in the Condensed Consolidated Statement of Operations.

[0001783180-25-000052:notes:119]
[same as prior period, unchanged from 0001783180-25-000030:notes:117]


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001783180-25-000052:notes:120]
[same as prior period, unchanged from 0001783180-25-000030:notes:118]

[0001783180-25-000052:notes:121]
[same as prior period, unchanged from 0001783180-25-000030:notes:119]

[0001783180-25-000052:notes:122]
[same as prior period, unchanged from 0001783180-25-000030:notes:120]

[0001783180-25-000052:notes:123]
|  | Three Months Ended June 30, |  | Six Months EndedJune 30, |
| (In millions) | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Net sales | $ | — |  |  | $ | 755 |  |  | $ | — |  |  | $ | 1,517 |  |
| Costs of sales | — |  |  | (452) |  |  | — |  |  | (894) |  |
| Research and development | — |  |  | (27) |  |  | — |  |  | (59) |  |
| Selling, general and administrative | — |  |  | (186) |  |  | — |  |  | (364) |  |
| Other income (expense), net | — |  |  | (4) |  |  | — |  |  | 1 |  |
| Gain (loss) on divestitures and deconsolidation | (22) |  |  | 2,881 |  |  | (22) |  |  | 2,881 |  |
| Interest (expense) income, net | — |  |  | (10) |  |  | — |  |  | (34) |  |
| Earnings (loss) before income taxes | (22) |  |  | 2,957 |  |  | (22) |  |  | 3,048 |  |
| Income tax (expense) benefit | — |  |  | 41 |  |  | — |  |  | 42 |  |
| Tax on divestitures and deconsolidation | 5 |  |  | (1,076) |  |  | 5 |  |  | (1,076) |  |
| Discontinued operations, net of tax | $ | (17) |  |  | $ | 1,922 |  |  | $ | (17) |  |  | $ | 2,014 |  |

[0001783180-25-000052:notes:124]
On December 2, 2024, the Company completed the sale of the Commercial and Residential Fire business ("CRF Business") for cash proceeds of $2.9 billion. The CRF Business, historically reported in the Company's Fire & Security segment, is a leading manufacturer of fire detection and alarm solutions for both commercial and residential applications. Upon sale, the Company recognized a net gain on the sale of $1.4 billion, which is included in Discontinued operations, net of tax.

[0001783180-25-000052:notes:125]
[same as prior period, unchanged from 0001783180-25-000030:notes:123]

[0001783180-25-000052:notes:126]
[same as prior period, unchanged from 0001783180-25-000030:notes:124]

[0001783180-25-000052:notes:127]
[same as prior period, unchanged from 0001783180-25-000030:notes:125]

[0001783180-25-000052:notes:128]
On October 1, 2024, the Company completed the sale of CCR for cash proceeds of $679 million. CCR, historically reported in the Company's Climate Solutions Transportation segment, is a global supplier of turnkey solutions for commercial refrigeration systems and services, with a primary focus on serving food retail customers, cold storage facilities and warehouses. Upon sale, the Company recognized a gross gain on the sale of $318 million, which is included in Other income (expense), net. During the three months ended June 30, 2025, the Company finalized the working capital and other adjustments provided in the stock purchase agreement governing the sale of CCR.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001783180-25-000052:notes:129]
[same as prior period, unchanged from 0001783180-25-000030:notes:127]

[0001783180-25-000052:notes:130]
•Climate Solutions Americas ("CSA") provides products, controls, services and solutions to meet the heating, cooling and ventilation needs of residential and commercial customers in North and South America while enhancing building performance, health, energy efficiency and sustainability.

[0001783180-25-000052:notes:131]
•Climate Solutions Europe ("CSE") provides products, controls, services and solutions to meet the heating, cooling and ventilation needs of residential and commercial customers in Europe while enhancing building performance, health, energy efficiency and sustainability.

[0001783180-25-000052:notes:132]
•Climate Solutions Asia Pacific, Middle East & Africa ("CSAME") provides products, controls, services and solutions to meet the heating, cooling and ventilation needs of residential and commercial customers in Asia Pacific, the Middle East and Africa while enhancing building performance, health, energy efficiency and sustainability.

[0001783180-25-000052:notes:133]
•Climate Solutions Transportation ("CST") includes global transport refrigeration and monitoring products, services and digital solutions for trucks, trailers, shipping containers, intermodal and rail.

[0001783180-25-000052:notes:134]
The Corporate and other category primarily includes corporate administrative functions such as tax, treasury, internal audit, legal and human resources. A portion of these costs and costs associated with shared service centers that provide transaction processing, accounting and other business support functions are allocated to the reportable segments.

[0001783180-25-000052:notes:135]
[same as prior period, unchanged from 0001783180-25-000030:notes:133]

[0001783180-25-000052:notes:136]
[same as prior period, unchanged from 0001783180-25-000030:notes:134]

[0001783180-25-000052:notes:137]
[same as prior period, unchanged from 0001783180-25-000030:notes:135]

[0001783180-25-000052:notes:138]
|  |  | Three Months Ended June 30, 2025 |
| (In millions) |  | CSA |  | CSE |  | CSAME |  | CST |  | Segment Total |  |  |  |  |
| Net sales |  | $ | 3,252 |  |  | $ | 1,253 |  |  | $ | 882 |  |  | $ | 726 |  |  | $ | 6,113 |  |  |  |  |  |
| Cost of goods sold |  | (2,061) |  |  | (883) |  |  | (654) |  |  | (518) |  |  | (4,116) |  |  |  |  |  |
| Research and development |  | (89) |  |  | (19) |  |  | (16) |  |  | (17) |  |  | (141) |  |  |  |  |  |
| Selling, general and administrative |  | (277) |  |  | (260) |  |  | (126) |  |  | (72) |  |  | (735) |  |  |  |  |  |
| Equity method investment net earnings |  | 43 |  |  | 1 |  |  | 30 |  |  | 4 |  |  | 78 |  |  |  |  |  |
| Other income (expense), net |  | 11 |  |  | 7 |  |  | 19 |  |  | 5 |  |  | 42 |  |  |  |  |  |
| Segment operating profit |  | $ | 879 |  |  | $ | 99 |  |  | $ | 135 |  |  | $ | 128 |  |  | $ | 1,241 |  |  |  |  |  |
|  |  | Three Months Ended June 30, 2024 |
| (In millions) |  | CSA |  | CSE |  | CSAME |  | CST |  | Segment Total |  |  |  |  |
| Net sales |  | $ | 2,865 |  |  | $ | 1,194 |  |  | $ | 902 |  |  | $ | 973 |  |  | $ | 5,934 |  |  |  |  |  |
| Cost of goods sold |  | (1,868) |  |  | (834) |  |  | (648) |  |  | (716) |  |  | (4,066) |  |  |  |  |  |
| Research and development |  | (91) |  |  | (19) |  |  | (16) |  |  | (18) |  |  | (144) |  |  |  |  |  |
| Selling, general and administrative |  | (237) |  |  | (248) |  |  | (131) |  |  | (104) |  |  | (720) |  |  |  |  |  |
| Equity method investment net earnings |  | 44 |  |  | (1) |  |  | 43 |  |  | 3 |  |  | 89 |  |  |  |  |  |
| Other income (expense), net |  | — |  |  | 1 |  |  | 7 |  |  | — |  |  | 8 |  |  |  |  |  |
| Segment operating profit |  | $ | 713 |  |  | $ | 93 |  |  | $ | 157 |  |  | $ | 138 |  |  | $ | 1,101 |  |  |  |  |  |
|  |  | Six Months Ended June 30, 2025 |
| (In millions) |  | CSA |  | CSE |  | CSAME |  | CST |  | Segment Total |  |  |  |  |
| Net sales |  | $ | 5,824 |  |  | $ | 2,422 |  |  | $ | 1,708 |  |  | $ | 1,377 |  |  | $ | 11,331 |  |  |  |  |  |
| Cost of goods sold |  | (3,761) |  |  | (1,671) |  |  | (1,263) |  |  | (990) |  |  | (7,685) |  |  |  |  |  |
| Research and development |  | (175) |  |  | (37) |  |  | (31) |  |  | (33) |  |  | (276) |  |  |  |  |  |
| Selling, general and administrative |  | (527) |  |  | (517) |  |  | (238) |  |  | (141) |  |  | (1,423) |  |  |  |  |  |
| Equity method investment net earnings |  | 69 |  |  | (1) |  |  | 48 |  |  | 6 |  |  | 122 |  |  |  |  |  |
| Other income (expense), net |  | 19 |  |  | 8 |  |  | 32 |  |  | 6 |  |  | 65 |  |  |  |  |  |
| Segment operating profit |  | $ | 1,449 |  |  | $ | 204 |  |  | $ | 256 |  |  | $ | 225 |  |  | $ | 2,134 |  |  |  |  |  |
|  |  | Six Months Ended June 30, 2024 |
| (In millions) |  | CSA |  | CSE |  | CSAME |  | CST |  | Segment Total |  |  |  |  |
| Net sales |  | $ | 5,225 |  |  | $ | 2,486 |  |  | $ | 1,786 |  |  | $ | 1,857 |  |  | $ | 11,354 |  |  |  |  |  |
| Cost of goods sold |  | (3,491) |  |  | (1,659) |  |  | (1,291) |  |  | (1,368) |  |  | (7,809) |  |  |  |  |  |
| Research and development |  | (200) |  |  | (42) |  |  | (36) |  |  | (40) |  |  | (318) |  |  |  |  |  |
| Selling, general and administrative |  | (467) |  |  | (523) |  |  | (258) |  |  | (200) |  |  | (1,448) |  |  |  |  |  |
| Equity method investment net earnings |  | 66 |  |  | (2) |  |  | 50 |  |  | 6 |  |  | 120 |  |  |  |  |  |
| Other income (expense), net |  | 5 |  |  | — |  |  | 14 |  |  | (4) |  |  | 15 |  |  |  |  |  |
| Segment operating profit |  | $ | 1,138 |  |  | $ | 260 |  |  | $ | 265 |  |  | $ | 251 |  |  | $ | 1,914 |  |  |  |  |  |

[0001783180-25-000052:notes:139]
|  |  | Three Months Ended June 30, |  | Six Months EndedJune 30, |
| (In millions) |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Reconciliation to Earnings before income taxes |  |  |  |  |  |  |  |  |
| Segment operating profit |  | $ | 1,241 |  |  | $ | 1,101 |  |  | $ | 2,134 |  |  | $ | 1,914 |  |
| Corporate and other |  | (75) |  |  | (45) |  |  | (120) |  |  | (94) |  |
| Restructuring costs |  | (47) |  |  | (29) |  |  | (55) |  |  | (37) |  |
| Amortization of acquired intangibles |  | (214) |  |  | (170) |  |  | (415) |  |  | (342) |  |
| Acquisition step-up amortization |  | — |  |  | (109) |  |  | — |  |  | (220) |  |
| Acquisition/divestiture-related costs |  | (9) |  |  | (24) |  |  | (19) |  |  | (72) |  |
| CCR gain |  | 7 |  |  | — |  |  | 7 |  |  | — |  |
| Viessmann-related hedges |  | — |  |  | — |  |  | — |  |  | (86) |  |
| Gain on liability adjustment |  | — |  |  | — |  |  | — |  |  | 46 |  |
| Non-service pension (expense) benefit |  | — |  |  | — |  |  | 1 |  |  | — |  |
| Interest (expense) income, net |  | (91) |  |  | (157) |  |  | (173) |  |  | (298) |  |
| Earnings before income taxes |  | $ | 812 |  |  | $ | 567 |  |  | $ | 1,360 |  |  | $ | 811 |  |

[0001783180-25-000052:notes:140]
[same as prior period, unchanged from 0001783180-25-000030:notes:139]


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001783180-25-000052:notes:141]
RELATED PARTIES
Equity Method Investments

[0001783180-25-000052:notes:142]
The Company sells products to and purchases products from unconsolidated entities accounted for under the equity method and, therefore, these entities are considered to be related parties. Amounts attributable to equity method investees are as follows:

[0001783180-25-000052:notes:143]
|  |  | Three Months Ended June 30, |  | Six Months EndedJune 30, |
| (In millions) |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Sales to equity method investees included in Product sales |  | $ | 845 |  |  | $ | 832 |  |  | $ | 1,625 |  |  | $ | 1,555 |  |
| Purchases from equity method investees included in Cost of products sold |  | $ | 57 |  |  | $ | 59 |  |  | $ | 104 |  |  | $ | 114 |  |

[0001783180-25-000052:notes:144]
The Company had receivables from and payables to equity method investees as follows:

[0001783180-25-000052:notes:145]
| (In millions) |  | June 30,2025 |  | December 31,2024 |
| Receivables from equity method investees included in Accounts receivable, net |  | $ | 485 |  |  | $ | 363 |  |
| Payables to equity method investees included in Accounts payable |  | $ | 32 |  |  | $ | 32 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001783180-25-000052:notes:146]
COMMITMENTS AND CONTINGENT LIABILITIES
The Company is involved in various litigation, claims and administrative proceedings, including those related to environmental (including asbestos) and legal matters. In accordance with ASC 450, Contingencies, the Company records accruals for loss contingencies when it is probable that a liability has been incurred and the amount of the loss can be reasonably estimated. These accruals are generally based upon a range of possible outcomes. If no amount within the range is a better estimate than any other, the Company accrues the minimum amount. In addition, these estimates are reviewed periodically and adjusted to reflect additional information when it becomes available. The Company is unable to predict the final outcome of the following matters based on the information currently available, except as otherwise noted. However, the Company does not believe that the resolution of any of these matters will have a material adverse effect upon its results of operations or financial condition.

[0001783180-25-000052:notes:147]
Environmental Matters

[0001783180-25-000052:notes:148]
The Company’s operations are subject to environmental regulation by various authorities. The Company has accrued for the costs of environmental remediation activities, including but not limited to investigatory, remediation, operating and maintenance costs and performance guarantees. The most likely cost to be incurred is accrued based on an evaluation of currently available facts with respect to individual sites, including the technology required to remediate, current laws and regulations and prior remediation experience.

[0001783180-25-000052:notes:149]
The outstanding liabilities for environmental obligations are as follows:

[0001783180-25-000052:notes:150]
| (In millions) |  | June 30,2025 |  | December 31,2024 |
| Environmental reserves included in Accrued liabilities |  | $ | 16 |  |  | $ | 25 |  |
| Environmental reserves included in Other long-term liabilities |  | 188 |  |  | 185 |  |
| Total Environmental reserves |  | $ | 204 |  |  | $ | 210 |  |

[0001783180-25-000052:notes:151]
For sites with multiple responsible parties, the Company considers its likely proportionate share of the anticipated remediation costs and the ability of other parties to fulfill their obligations in establishing a provision for these costs. Accrued environmental liabilities are not reduced by potential insurance reimbursements and are undiscounted.

[0001783180-25-000052:notes:152]
Asbestos Matters

[0001783180-25-000052:notes:153]
The Company has been named as a defendant in lawsuits alleging personal injury as a result of exposure to asbestos allegedly integrated into certain Carrier products or business premises. While the Company has never manufactured asbestos and no longer incorporates it into any currently-manufactured products, certain products that the Company no longer manufactures contained components incorporating asbestos. A substantial majority of these asbestos-related claims have been dismissed without payment or have been covered in full or in part by insurance or other forms of indemnity. Additional cases were litigated and settled without any insurance reimbursement. The amounts involved in asbestos-related claims were not material individually or in the aggregate in any period.

[0001783180-25-000052:notes:154]
The Company's asbestos liabilities and related insurance recoveries are as follows:

[0001783180-25-000052:notes:155]
| (In millions) |  | June 30,2025 |  | December 31,2024 |
| Asbestos liabilities included in Accrued liabilities |  | $ | 17 |  |  | $ | 17 |  |
| Asbestos liabilities included in Other long-term liabilities |  | 200 |  |  | 208 |  |
| Total Asbestos liabilities |  | $ | 217 |  |  | $ | 225 |  |
| Asbestos-related recoveries included in Other current assets |  | $ | 7 |  |  | $ | 7 |  |
| Asbestos-related recoveries included in Other assets |  | 84 |  |  | 88 |  |
| Total Asbestos-related recoveries |  | $ | 91 |  |  | $ | 95 |  |

[0001783180-25-000052:notes:156]
The amounts recorded for asbestos-related liabilities are based on currently available information and assumptions that the Company believes are reasonable and are made with input from outside actuarial experts. These amounts are undiscounted and exclude the Company’s legal fees to defend the asbestos claims, which are expensed as incurred. In addition, the Company has recorded insurance recovery receivables for probable asbestos-related recoveries.

[0001783180-25-000052:notes:157]
Aqueous Film Forming Foam Litigation

[0001783180-25-000052:notes:158]
As of June 30, 2025, the Company, Kidde-Fenwal, Inc. ("KFI") and others have been named as defendants in more than 12,000 lawsuits filed in United States state or federal courts and a single case in Canada alleging that the historic use of Aqueous Film Forming Foam ("AFFF") caused personal injuries and damage to property and water supplies. In December 2018, the U.S. Judicial Panel on Multidistrict Litigation transferred and consolidated all AFFF cases pending in the U.S. federal courts against the Company, KFI and others to the U.S. District Court for the District of South Carolina (the "MDL Proceedings"). Individual plaintiffs in the MDL Proceedings generally seek damages for alleged personal injuries, medical monitoring, diminution in property value and injunctive relief to remediate alleged contamination of water supplies. U.S. state, municipal and water utility plaintiffs in the MDL Proceedings generally seek damages and costs related to the remediation of public property and water supplies.

[0001783180-25-000052:notes:159]
AFFF is a firefighting foam, developed beginning in the late 1960s pursuant to U.S. military specification, used to extinguish certain types of hydrocarbon-fueled fires. The lawsuits identified above relate to Kidde Fire Fighting, Inc., which owned the “National Foam” business that manufactured AFFF for sale to government (including the U.S. federal government) and non-government customers in the U.S. at a single facility located in West Chester, Pennsylvania (the "Pennsylvania Site"). Kidde Fire Fighting, Inc. was acquired by a UTC subsidiary in 2005 and merged into KFI in 2007. In 2013, KFI divested the AFFF businesses to an unrelated third party. The Company acquired KFI as part of the Separation in April 2020.

[0001783180-25-000052:notes:160]
The key components that contribute to AFFF's fire-extinguishing capabilities are known as fluorosurfactants. Neither the Company, nor KFI, nor any of the Company's subsidiaries involved in the AFFF litigation manufactured fluorosurfactants. Instead, the National Foam business purchased these substances from unrelated third parties for use in manufacturing AFFF. Plaintiffs in the MDL Proceedings allege that the fluorosurfactants used by various manufacturers in producing AFFF contained, or over time degraded into, compounds known as per- and polyfluoroalkyl substances (referred to collectively as "PFAS"), including perflourooctanesulfonic acid ("PFOS") and perflourooctanoic acid ("PFOA"). Plaintiffs further allege that, as a result of the use of AFFF, PFOS and PFOA were released into the environment and, in some instances, ultimately reached drinking water supplies.

[0001783180-25-000052:notes:161]
Plaintiffs in the MDL Proceedings have named multiple defendants, including suppliers of chemicals and raw materials used to manufacture fluorosurfactants, fluorosurfactant manufacturers and AFFF manufacturers. The defendants in the MDL Proceedings moved for summary judgment on the government contractor defense, which potentially applies to AFFF sold to or used by the U.S. government. After full briefing and oral argument, on September 16, 2022, the MDL court declined to enter summary judgment for the defendants. The defense, however, remains available at any trial in which it would apply.

[0001783180-25-000052:notes:162]
On May 14, 2023, KFI filed a voluntary petition with the United States Bankruptcy Court for the District of Delaware (the “Bankruptcy Court”) seeking relief under chapter 11 of the Bankruptcy Code, after the Company determined that it would not provide financial support to KFI going forward other than ensuring KFI has access to services necessary for the effective operation of its business. As a result, all litigation against KFI was automatically stayed. By agreement, all AFFF-related litigation against the Company, its other subsidiaries and RTX also was stayed. On November 21, 2023, the Bankruptcy Court ordered certain parties, including the Company, to participate in mediation sessions with respect to claims that might be asserted by and against it in the bankruptcy proceedings.

[0001783180-25-000052:notes:163]
Following the conclusion of these mediation sessions in October 2024, the Company entered into a Settlement and Plan Support Agreement which contemplates that the Company will subsequently enter into three distinct settlement agreements (collectively, the “Proposed Settlement Agreements”) with KFI, the Official Committee of Unsecured Creditors appointed in KFI’s bankruptcy case (the “Committee”) and the Plaintiffs’ Executive Committee (the “MDL PEC”) appointed in the MDL Proceedings.

[0001783180-25-000052:notes:164]
The first of the Proposed Settlement Agreements relates to claims that the Company is responsible for liabilities arising from KFI’s manufacture or sale of AFFF (“Estate Claims Settlement”). Upon Bankruptcy Court approval, the Estate Claims Settlement will permanently resolve all present and future claims that the Company is responsible for any liabilities of KFI, including all liabilities arising from KFI’s manufacture and sale of AFFF. The second and third of the Proposed Settlement Agreements release a very substantial amount of current and future direct claims against the Company (the “Direct Claims Settlements”). Direct claims allege that UTC, which indirectly owned KFI’s AFFF business for eight years, engaged in conduct independent of KFI that caused harm to AFFF claimants. The Company agreed to indemnify UTC for these direct claims when it was spun-off from UTC. Upon approval by the MDL Court, the Direct Claims Settlements resolve and enjoin all current and future AFFF-related direct claims against the Company by participating public water providers and airports. Non-settling parties may still assert direct AFFF-related claims, although we expect a vast majority of public water providers and airports will participate in the Direct Claims Settlements.

[0001783180-25-000052:notes:165]
As part of the Proposed Settlement Agreements, the Company will pay $615 million in cash over five years, 100% of the net sale proceeds from its sale of KFI’s assets to Pacific Avenue Capital Partners, which are estimated to be $115 million, and contribute the right to recover proceeds under certain of its insurance policies. The Company will be entitled to receive up to $2.4 billion of proceeds from those insurance policies and will contribute the first $125 million of such proceeds as additional consideration in the Direct Claims Settlements. The Company also will be entitled to any earnouts payable to KFI under the KFI sale agreement. The Company expects insurance payments it receives in the future, in the aggregate, to cover the amount paid under the Proposed Settlement Agreements. As a result of the Proposed Settlement Agreements, the Company recorded a liability in the amount of $565 million during the three months ended September 30, 2024. The amount recognized is in addition to liabilities of $50 million that the Company recorded upon the deconsolidation of KFI on May 14, 2023, as further discussed below. As of June 30, 2025, the Company has not recorded any amounts associated with expected insurance proceeds.

[0001783180-25-000052:notes:166]
The Company and KFI believe that they have meritorious defenses to the remaining AFFF claims. Given the numerous factual, scientific and legal issues to be resolved relating to these claims, the Company is unable to assess the probability of liability or to reasonably estimate a range of possible loss at this time. There can be no assurance that any such future exposure will not be material in any period.

[0001783180-25-000052:notes:167]
On November 14, 2024, KFI filed the chapter 11 plan of liquidation (as may be further amended, restated, supplemented, waived, or otherwise modified from time to time, the "Chapter 11 Plan"), which incorporates the Estate Claims Settlement, provides for the treatment of the various creditor classes, and establishes wind-down provisions, among other things, and the disclosure statement for the Chapter 11 Plan (as may be further amended, restated, supplemented, waived, or otherwise modified from time to time, the "Disclosure Statement"). A hearing to approve the Disclosure Statement was held in June 2025. The Bankruptcy Court ordered that the Disclosure Statement be revised and supplemented, which the Company expects to be filed in the third quarter of 2025.

[0001783180-25-000052:notes:168]
Deconsolidation Due to Bankruptcy

[0001783180-25-000052:notes:169]
As of May 14, 2023, the Company no longer controlled KFI as its activities are subject to review and oversight by the Bankruptcy Court. Therefore, KFI was deconsolidated and its respective assets and liabilities were derecognized from the Company’s Unaudited Condensed Consolidated Financial Statements. Upon deconsolidation, the Company determined the fair value of its retained interest in KFI to be zero and we accounted for it prospectively using the cost method.

[0001783180-25-000052:notes:170]
In connection with the bankruptcy filing, KFI entered into several agreements with subsidiaries of the Company to ensure they have access to services necessary for the effective operation of their business. All post-deconsolidation activity between the Company and KFI are reported as third-party transactions recorded within the Company's Unaudited Condensed Consolidated Statement of Operations. Since the petition date, there were no material transactions between the Company and KFI other than a $15 million payment during 2024 by the Company to KFI under the terms of a tax sharing arrangement.

[0001783180-25-000052:notes:171]
Income Taxes

[0001783180-25-000052:notes:172]
Under the TMA relating to the Separation, the Company is responsible to UTC for its share of the Tax Cuts and Jobs Act transition tax associated with foreign undistributed earnings as of December 31, 2017. As a result, a liability of $101 million is included within the accompanying Unaudited Condensed Consolidated Balance Sheet within Accrued liabilities as of June 30, 2025. This obligation is expected to be settled in April 2026. The Company believes that the likelihood of incurring losses materially in excess of this amount is remote.

[0001783180-25-000052:notes:173]
Other

[0001783180-25-000052:notes:174]
The Company has other commitments and contingent liabilities related to legal proceedings, self-insurance programs and matters arising in the ordinary course of business. The Company accrues for contingencies generally based upon a range of possible outcomes. If no amount within the range is a better estimate than any other, the Company accrues the minimum amount.

[0001783180-25-000052:notes:175]
In the ordinary course of business, the Company is also routinely a defendant in, party to or otherwise subject to many pending and threatened legal actions, claims, disputes and proceedings. These matters are often based on alleged violations of contract, product liability, warranty, regulatory, environmental, health and safety, employment, intellectual property, tax and other laws. In some of these proceedings, claims for substantial monetary damages are asserted against the Company and could result in fines, penalties, compensatory or treble damages or non-monetary relief. The Company does not believe that these matters will have a material adverse effect upon its results of operations, cash flows or financial condition.
