# CARR MD&A — 0001783180-25-000052


## mdna

[0001783180-25-000052:mdna:1]
[same as prior period, unchanged from 0001783180-25-000030:mdna:1]

[0001783180-25-000052:mdna:2]
[same as prior period, unchanged from 0001783180-25-000030:mdna:2]

[0001783180-25-000052:mdna:3]
[same as prior period, unchanged from 0001783180-25-000030:mdna:3]

[0001783180-25-000052:mdna:4]
[same as prior period, unchanged from 0001783180-25-000030:mdna:4]

[0001783180-25-000052:mdna:5]
[same as prior period, unchanged from 0001783180-25-000030:mdna:5]

[0001783180-25-000052:mdna:6]
[same as prior period, unchanged from 0001783180-25-000030:mdna:6]

[0001783180-25-000052:mdna:7]
We continue to actively monitor evolving macroeconomic conditions and recent trade policy announcements. Based on our updated analysis, we expect to fully mitigate our expected 2025 impact from tariffs announced to date through supply chain and productivity actions as well as approximately $200 million of incremental product pricing actions. To date, tariffs have not had a material impact on our business and we are deploying additional strategies, including cost containment measures, to limit future exposure in this current market environment.

[0001783180-25-000052:mdna:8]
[same as prior period, unchanged from 0001783180-25-000030:mdna:8]

[0001783180-25-000052:mdna:9]
[same as prior period, unchanged from 0001783180-25-000030:mdna:9]

[0001783180-25-000052:mdna:10]
During 2024, we completed several activities designed to simplify our business portfolio, transforming it into a pure-play climate and energy solutions provider. On January 2, 2024, we acquired the climate solutions business (the "VCS Business") of Viessmann Group GmbH & Co. KG (together with its affiliates, “Viessmann”). The VCS Business, primarily reported in the Climate Solutions Europe segment, is a premier residential and light commercial HVAC provider in Europe that expanded our portfolio to offer a global, comprehensive suite of sustainable and innovative building and cold-chain solutions. In addition, we divested our Commercial and Residential Fire, Access Solutions and Industrial Fire businesses which were historically reported in our Fire & Security segment. The transactions represented a single disposal plan to separately divest multiple businesses over different reporting periods and met the criteria to be presented as discontinued operations. We also divested our Commercial Refrigeration business (“CCR”) during 2024. CCR, which was historically reported in the Climate Solutions Transportation segment (previously named Refrigeration), did not meet the criteria to be presented as discontinued operations.

[0001783180-25-000052:mdna:11]
[same as prior period, unchanged from 0001783180-25-000030:mdna:30]

[0001783180-25-000052:mdna:12]
[same as prior period, unchanged from 0001783180-25-000030:mdna:11]

[0001783180-25-000052:mdna:13]
As a result of our portfolio transformation, we revised our reportable segments during the first quarter of 2025 to better reflect our business strategy, align our management reporting and increase transparency for investors. Under the revised segment structure, we have three new regional HVAC operating segments. Combined with the existing Climate Solutions Transportation operating segment, the four operating segments also serve as our reportable segments. This model is designed to create a simplified, more focused and customer-centric organization across the globe. Each segment reports through separate management teams which regularly review their operating results with our Chief Operating Decision Maker (the "CODM") determined in accordance with applicable accounting guidance. In connection with the revised structure, the CODM changed the measure used to evaluate segment profitability from Operating profit to Segment operating profit. All prior period comparative information has been recast to reflect the revised segment structure.

[0001783180-25-000052:mdna:14]
[same as prior period, unchanged from 0001783180-25-000030:mdna:39]

[0001783180-25-000052:mdna:15]
On July 4, 2025, the One Big Beautiful Bill Act was enacted in the U.S., making permanent key provisions from the Tax Cuts and Jobs Act including full expensing of capital investments, while also modifying the international tax framework and reinstating favorable treatment for certain business tax items. The legislation has staggered effective dates from 2025 through 2027. We are currently evaluating its impact on our consolidated financial statements, including considerations for the quarter ending September 30, 2025 as a result of its enactment.

[0001783180-25-000052:mdna:16]
[same as prior period, unchanged from 0001783180-25-000030:mdna:13]

[0001783180-25-000052:mdna:17]
[same as prior period, unchanged from 0001783180-25-000030:mdna:14]

[0001783180-25-000052:mdna:18]
[same as prior period, unchanged from 0001783180-25-000030:mdna:15]

[0001783180-25-000052:mdna:19]
Three Months Ended June 30, 2025 Compared with the Three Months Ended June 30, 2024

[0001783180-25-000052:mdna:20]
[same as prior period, unchanged from 0001783180-25-000030:mdna:17]

[0001783180-25-000052:mdna:21]
|  |  | Three Months Ended June 30, |
| (In millions) |  | 2025 |  | 2024 |  | Period Change |  | % Change |
| Net sales |  | $ | 6,113 |  |  | $ | 5,934 |  |  | $ | 179 |  |  | 3 | % |
| Cost of products and services sold |  | (4,344) |  |  | (4,359) |  |  | 15 |  |  | — | % |
| Gross margin |  | 1,769 |  |  | 1,575 |  |  | 194 |  |  | 12 | % |
| Operating expenses |  | (866) |  |  | (851) |  |  | (15) |  |  | 2 | % |
| Operating profit |  | 903 |  |  | 724 |  |  | 179 |  |  | 25 | % |
| Non-operating income (expense), net |  | (91) |  |  | (157) |  |  | 66 |  |  | (42) | % |
| Earnings (loss) before income taxes |  | 812 |  |  | 567 |  |  | 245 |  |  | 43 | % |
| Income tax expense |  | (162) |  |  | (120) |  |  | (42) |  |  | 35 | % |
| Earnings (loss) from continuing operations |  | 650 |  |  | 447 |  |  | 203 |  |  | 45 | % |
| Discontinued operations, net of income taxes |  | (17) |  |  | 1,922 |  |  | (1,939) |  |  | (101) | % |
| Net earnings (loss) |  | 633 |  |  | 2,369 |  |  | (1,736) |  |  | (73) | % |
| Less: Non-controlling interest in subsidiaries' earnings from operations |  | 42 |  |  | 32 |  |  | 10 |  |  | 31 | % |
| Net earnings (loss) attributable to common shareowners |  | $ | 591 |  |  | $ | 2,337 |  |  | $ | (1,746) |  |  | (75) | % |

[0001783180-25-000052:mdna:22]
[same as prior period, unchanged from 0001783180-25-000030:mdna:41]

[0001783180-25-000052:mdna:23]
[same as prior period, unchanged from 0001783180-25-000030:mdna:19]

[0001783180-25-000052:mdna:24]
For the three months ended June 30, 2025, Net sales were $6.1 billion, a 3% increase compared with the same period of 2024. The components of the year-over-year change were as follows:

[0001783180-25-000052:mdna:25]
|  |  | Three Months Ended June 30, |
| Organic |  | 6 | % |
| Foreign currency translation |  | 1 | % |
| Acquisitions and divestitures, net |  | (4) | % |
| Total % change |  | 3 | % |

[0001783180-25-000052:mdna:26]
Organic sales for the three months ended June 30, 2025 increased by 6% compared with the same period of 2024. The organic increase was primarily due to our Climate Solutions Americas segment as strong end-market demand continued to drive higher volumes. Results in Climate Solutions Europe were flat as economic uncertainly continued to impact the region. These results were partially offset by lower end-market demand in both Climate Solutions Asia Pacific, Middle East & Africa and Climate Solutions Transportation. Refer to "Segment Review" below for a discussion of Net sales by segment.

[0001783180-25-000052:mdna:27]
[same as prior period, unchanged from 0001783180-25-000030:mdna:23]

[0001783180-25-000052:mdna:28]
For the three months ended June 30, 2025, gross margin was $1.8 billion, a 12% increase compared with the same period of 2024. The components were as follows:

[0001783180-25-000052:mdna:29]
|  |  | Three Months Ended June 30, |
| (In millions) |  | 2025 |  | 2024 |
| Net sales |  | $ | 6,113 |  |  | $ | 5,934 |  |
| Cost of products and services sold |  | (4,344) |  |  | (4,359) |  |
| Gross margin |  | $ | 1,769 |  |  | $ | 1,575 |  |
| Percentage of net sales |  | 28.9 | % |  | 26.5 | % |

[0001783180-25-000052:mdna:30]
Gross margin increased by $194 million compared with the three months ended June 30, 2024. As a result, gross margin as a percentage of Net sales increased by 240 basis points compared with the same period of 2024. The prior period included inventory step-up and backlog amortization resulting from the recognition of acquired assets of the VCS Business at fair value which are now fully amortized. These costs had a 190 basis point unfavorable impact on the prior period gross margin as a percentage of Net sales. In addition, ongoing customer demand and our continued focus on productivity initiatives further benefited gross margin.

[0001783180-25-000052:mdna:31]
[same as prior period, unchanged from 0001783180-25-000030:mdna:27]

[0001783180-25-000052:mdna:32]
For the three months ended June 30, 2025, operating expenses, including Equity method investment net earnings, were $866 million, a 2% increase compared with the same period of 2024. The components were as follows:

[0001783180-25-000052:mdna:33]
|  |  | Three Months Ended June 30, |
| (In millions) |  | 2025 |  | 2024 |
| Selling, general and administrative |  | $ | (813) |  |  | $ | (789) |  |
| Research and development |  | (161) |  |  | (160) |  |
| Equity method investment net earnings |  | 78 |  |  | 90 |  |
| Other income (expense), net |  | 30 |  |  | 8 |  |
| Total operating expenses |  | $ | (866) |  |  | $ | (851) |  |
| Percentage of net sales |  | 14.2 | % |  | 14.3 | % |

[0001783180-25-000052:mdna:34]
[same as prior period, unchanged from 0001783180-25-000030:mdna:47]

[0001783180-25-000052:mdna:35]
For the three months ended June 30, 2025, Selling, general and administrative expenses were $813 million, a 3% increase compared with the same period of 2024. The increase primarily relates to foreign currency translation. In addition, employee-related costs associated with our portfolio transformation further impacted results. These costs were partially offset by lower compensation costs and synergies associated with the integration of the VCS Business. The current period also included $9 million of acquisition and divestiture-related costs compared with $24 million during the three months ended June 30, 2024.

[0001783180-25-000052:mdna:36]
[same as prior period, unchanged from 0001783180-25-000030:mdna:32]

[0001783180-25-000052:mdna:37]
Investments over which we do not exercise control, but have significant influence, are accounted for using the equity method of accounting. For the three months ended June 30, 2025, Equity method investment net earnings were $78 million, a 13% decrease compared with the same period of 2024. The decrease was primarily driven by lower earnings in joint ventures in the Asia Pacific region.

[0001783180-25-000052:mdna:38]
Other income (expense), net primarily includes the impact of gains and losses related to the sale of businesses or interests in our equity method investments, foreign currency gains and losses on transactions that are denominated in a currency other than an entity's functional currency and hedging-related activities. During the three months ended June 30, 2025, we finalized the working capital and other adjustments provided in the stock purchase agreement governing the sale of CCR.

[0001783180-25-000052:mdna:39]
[same as prior period, unchanged from 0001783180-25-000030:mdna:35]

[0001783180-25-000052:mdna:40]
For the three months ended June 30, 2025, Non-operating income (expense), net was $91 million, a 42% decrease compared with the same period of 2024. The components were as follows:

[0001783180-25-000052:mdna:41]
|  |  | Three Months Ended June 30, |
| (In millions) |  | 2025 |  | 2024 |
| Non-service pension (expense) benefit |  | $ | — |  |  | $ | — |  |
| Interest expense |  | $ | (115) |  |  | $ | (175) |  |
| Interest income |  | 24 |  |  | 18 |  |
| Interest (expense) income, net |  | $ | (91) |  |  | $ | (157) |  |
| Non-operating income (expense), net |  | $ | (91) |  |  | $ | (157) |  |

[0001783180-25-000052:mdna:42]
Non-operating income (expense), net includes the results from activities other than normal business operations such as interest expense, interest income and the non-service components of pension and post-retirement obligations. Interest expense is affected by the amount of debt outstanding and the interest rates on that debt. For the three months ended June 30, 2025, Interest expense was $115 million, a 34% decrease compared with the same period of 2024. Consistent with our capital allocation strategy, we reduced our outstanding debt by approximately $3 billion over the course of 2024 and repaid an additional $1.2 billion in 2025.

[0001783180-25-000052:mdna:43]
Income Taxes

[0001783180-25-000052:mdna:44]
|  |  | Three Months Ended June 30, |
|  |  | 2025 |  | 2024 |
| Effective tax rate |  | 20.0 | % |  | 21.2 | % |

[0001783180-25-000052:mdna:45]
33

[0001783180-25-000052:mdna:46]
We account for income tax expense in accordance with ASC 740, which requires an estimate of the annual effective income tax rate for the full year to be applied to the respective interim period, taking into account year-to-date amounts and projected results for the full year. The effective tax rate for the three months ended June 30, 2025 was 20.0% compared with 21.2% for the three months ended June 30, 2024. The effective tax rate for the three months ended June 30, 2025 was lower than the effective tax rate for three months ended June 30, 2024 primarily due to a state tax benefit of $6 million related to the utilization of a capital loss, a tax benefit of $6 million from the conclusion of the UTC 2020 Internal Revenue Service ("IRS") tax audit, a reduction in non-deductible interest expense and lower income tax costs associated with U.S. tax on international operations.

[0001783180-25-000052:mdna:47]
[same as prior period, unchanged from 0001783180-25-000030:mdna:43]

[0001783180-25-000052:mdna:48]
[same as prior period, unchanged from 0001783180-25-000030:mdna:44]

[0001783180-25-000052:mdna:49]
|  |  | Three Months Ended June 30, |  |  |
| (In millions) |  | 2025 |  | 2024 |  |  |  |  |
| Reconciliation to Adjusted operating profit |  |  |  |  |  |  |  |  |
| Operating profit |  | $ | 903 |  |  | $ | 724 |  |  |  |  |  |
| Restructuring costs |  | 47 |  |  | 29 |  |  |  |  |  |
| Amortization of acquired intangibles |  | 214 |  |  | 170 |  |  |  |  |  |
| Acquisition step-up amortization |  | — |  |  | 109 |  |  |  |  |  |
| Acquisition/divestiture-related costs |  | 9 |  |  | 24 |  |  |  |  |  |
| CCR gain |  | (7) |  |  | — |  |  |  |  |  |
| Adjusted operating profit |  | $ | 1,166 |  |  | $ | 1,056 |  |  |  |  |  |

[0001783180-25-000052:mdna:50]
[same as prior period, unchanged from 0001783180-25-000030:mdna:46]

[0001783180-25-000052:mdna:51]
[same as prior period, unchanged from 0001783180-25-000030:mdna:71]

[0001783180-25-000052:mdna:52]
Six Months Ended June 30, 2025 Compared with the Six Months Ended June 30, 2024

[0001783180-25-000052:mdna:53]
The following represents our consolidated net sales and operating results:

[0001783180-25-000052:mdna:54]
|  |  | Six Months Ended June 30, |
| (In millions) |  | 2025 |  | 2024 |  | Period Change |  | % Change |
| Net sales |  | $ | 11,331 |  |  | $ | 11,354 |  |  | $ | (23) |  |  | — | % |
| Cost of products and services sold |  | (8,117) |  |  | (8,394) |  |  | 277 |  |  | (3) | % |
| Gross margin |  | 3,214 |  |  | 2,960 |  |  | 254 |  |  | 9 | % |
| Operating expenses |  | (1,682) |  |  | (1,851) |  |  | 169 |  |  | (9) | % |
| Operating profit |  | 1,532 |  |  | 1,109 |  |  | 423 |  |  | 38 | % |
| Non-operating income (expense), net |  | (172) |  |  | (298) |  |  | 126 |  |  | (42) | % |
| Earnings (loss) before income taxes |  | 1,360 |  |  | 811 |  |  | 549 |  |  | 68 | % |
| Income tax expense |  | (273) |  |  | (167) |  |  | (106) |  |  | 63 | % |
| Earnings (loss) from continuing operations |  | 1,087 |  |  | 644 |  |  | 443 |  |  | 69 | % |
| Discontinued operations, net of income taxes |  | (17) |  |  | 2,014 |  |  | (2,031) |  |  | (101) | % |
| Net earnings (loss) |  | 1,070 |  |  | 2,658 |  |  | (1,588) |  |  | (60) | % |
| Less: Non-controlling interest in subsidiaries' earnings from operations |  | 67 |  |  | 52 |  |  | 15 |  |  | 29 | % |
| Net earnings (loss) attributable to common shareowners |  | $ | 1,003 |  |  | $ | 2,606 |  |  | $ | (1,603) |  |  | (62) | % |

[0001783180-25-000052:mdna:55]
Net Sales

[0001783180-25-000052:mdna:56]
For the six months ended June 30, 2025, Net sales were $11.3 billion, flat compared with the same period of 2024. The components of the year-over-year change were as follows:

[0001783180-25-000052:mdna:57]
|  |  | Six Months EndedJune 30, |
| Organic |  | 4 | % |
| Acquisitions and divestitures, net |  | (4) | % |
| Total % change |  | — | % |

[0001783180-25-000052:mdna:58]
Organic sales for the six months ended June 30, 2025 increased by 4% compared with the same period of 2024. The organic increase was primarily due to our Climate Solutions Americas segment as strong end-market demand continued to drive higher volumes. In addition, results were flat in our Climate Solutions Transportation segment due to mixed end-market demand. These results were partially offset by lower end-market demand in both Climate Solutions Europe and Climate Solutions Asia Pacific, Middle East & Africa. Refer to "Segment Review" below for a discussion of Net sales by segment.

[0001783180-25-000052:mdna:59]
35

[0001783180-25-000052:mdna:60]
Gross Margin

[0001783180-25-000052:mdna:61]
For the six months ended June 30, 2025, gross margin was $3.2 billion, a 9% increase compared with the same period of 2024. The components were as follows:

[0001783180-25-000052:mdna:62]
|  |  | Six Months EndedJune 30, |  |  |  |  |
| (In millions) |  | 2025 |  | 2024 |  |  |  |  |
| Net sales |  | $ | 11,331 |  |  | $ | 11,354 |  |  |  |  |  |
| Cost of products and services sold |  | (8,117) |  |  | (8,394) |  |  |  |  |  |
| Gross margin |  | $ | 3,214 |  |  | $ | 2,960 |  |  |  |  |  |
| Percentage of net sales |  | 28.4 | % |  | 26.1 | % |  |  |  |  |

[0001783180-25-000052:mdna:63]
Gross margin increased by $254 million compared with the six months ended June 30, 2024. As a result, gross margin as a percentage of Net sales increased by 230 basis points compared with the same period of 2024. The prior period included inventory step-up and backlog amortization resulting from the recognition of acquired assets of the VCS Business at fair value which are now fully amortized. These costs had a 190 basis point unfavorable impact on the prior period gross margin as a percentage of Net sales. In addition, ongoing customer demand, pricing improvements and our continued focus on productivity initiatives further benefited gross margin.

[0001783180-25-000052:mdna:64]
Operating Expenses

[0001783180-25-000052:mdna:65]
For the six months ended June 30, 2025, operating expenses, including Equity method investment net earnings, were $1.7 billion, a 9% decrease compared with the same period of 2024. The components were as follows:

[0001783180-25-000052:mdna:66]
|  |  | Six Months EndedJune 30, |
| (In millions) |  | 2025 |  | 2024 |
| Selling, general and administrative |  | $ | (1,542) |  |  | $ | (1,596) |  |
| Research and development |  | (314) |  |  | (352) |  |
| Equity method investment net earnings |  | 122 |  |  | 121 |  |
| Other income (expense), net |  | 52 |  |  | (24) |  |
| Total operating expenses |  | $ | (1,682) |  |  | $ | (1,851) |  |
| Percentage of net sales |  | 14.8 | % |  | 16.3 | % |

[0001783180-25-000052:mdna:67]
For the six months ended June 30, 2025, Selling, general and administrative expenses were $1.5 billion, a 3% decrease compared with the same period of 2024. The decrease relates to productivity initiatives associated with our portfolio transformation and synergies associated with the integration of the VCS Business. These benefits were partially offset by higher foreign currency translation, compensation and other employee-related costs. In addition, the current period also included $20 million of acquisition and divestiture-related costs compared with $72 million during the six months ended June 30, 2024.

[0001783180-25-000052:mdna:68]
Research and development costs relate to new product development and new technology innovation. Due to the variable nature of program development schedules, year-over-year spending levels can fluctuate. In addition, we continue to invest to prepare for future product innovations and digital controls technologies.

[0001783180-25-000052:mdna:69]
Investments over which we do not exercise control, but have significant influence, are accounted for using the equity method of accounting. For the six months ended June 30, 2025, Equity method investment net earnings were $122 million, a 1% increase compared with the same period of 2024. Equity method earnings increased within Climate Solutions America and Climate Solutions Europe and was partially offset by lower equity earnings in Climate Solutions Asia Pacific, Middle East & Africa.

[0001783180-25-000052:mdna:70]
Other income (expense), net primarily includes the impact of gains and losses related to the sale of businesses or interests in our equity method investments, foreign currency gains and losses on transactions that are denominated in a currency other than an entity's functional currency and hedging-related activities. During the six months ended June 30, 2025, we finalized the working capital and other adjustments provided in the stock purchase agreement governing the sale of CCR. In connection with the acquisition of the VCS Business, we recognized an $86 million loss during the six months ended June 30, 2024 on the mark-to-market valuation of our window forward contracts associated with the expected cash outflows of the Euro-denominated purchase price of the VCS Business. In addition, we recognized a $46 million gain associated with the TMA and UTC's conclusion of certain income tax matters from their 2017 and 2018 tax audit with the Internal Revenue Service ("IRS").

[0001783180-25-000052:mdna:71]
Non-Operating Income (Expense), net

[0001783180-25-000052:mdna:72]
For the six months ended June 30, 2025, Non-operating income (expense), net was $172 million, a 42% decrease compared with the same period of 2024. The components were as follows:

[0001783180-25-000052:mdna:73]
|  |  | Six Months EndedJune 30, |
| (In millions) |  | 2025 |  | 2024 |
| Non-service pension (expense) benefit |  | $ | 1 |  |  | $ | — |  |
| Interest expense |  | $ | (227) |  |  | $ | (331) |  |
| Interest income |  | 54 |  |  | 33 |  |
| Interest (expense) income, net |  | $ | (173) |  |  | $ | (298) |  |
| Non-operating income (expense), net |  | $ | (172) |  |  | $ | (298) |  |

[0001783180-25-000052:mdna:74]
Non-operating income (expense), net includes the results from activities other than normal business operations such as interest expense, interest income and the non-service components of pension and post-retirement obligations. Interest expense is affected by the amount of debt outstanding and the interest rates on that debt. For the six months ended June 30, 2025, Interest expense was $227 million, a 31% decrease compared with the same period of 2024. Consistent with our capital allocation strategy, we reduced our outstanding debt by approximately $3 billion over the course of 2024 and repaid an additional $1.2 billion during 2025.

[0001783180-25-000052:mdna:75]
Income Taxes

[0001783180-25-000052:mdna:76]
|  |  | Six Months EndedJune 30, |  |  |
|  |  | 2025 |  | 2024 |  |  |  |  |
| Effective tax rate |  | 20.1 | % |  | 20.6 | % |  |  |  |  |

[0001783180-25-000052:mdna:77]
We account for income tax expense in accordance with ASC 740, which requires an estimate of the annual effective income tax rate for the full year to be applied to the respective interim period, taking into account year-to-date amounts and projected results for the full year. The effective tax rate was 20.1% for the six months ended June 30, 2025, compared with 20.6% for the six months ended June 30, 2024. The year-over-year decrease was primarily driven by a $12 million tax benefit generated by the purchase of investment tax credits from a third-party, a state tax benefit of $6 million related to the utilization of a capital loss, a tax benefit of $6 million from the conclusion of the UTC 2020 IRS tax audit, a reduction in non-deductible interest expense and lower income tax costs associated with U.S. tax on international operations. These amounts were partially offset by the absence of a $21 million tax benefit associated with the TMA and UTC's conclusion of certain income tax matters from their 2017 and 2018 tax audit with the IRS recognized during the six months ended June 30, 2024.

[0001783180-25-000052:mdna:78]
[same as prior period, unchanged from 0001783180-25-000030:mdna:104]

[0001783180-25-000052:mdna:79]
Adjusted Operating Profit

[0001783180-25-000052:mdna:80]
We report our financial results in accordance with accounting principles generally accepted in the United States ("GAAP"). In addition, we supplement the reporting of our financial information determined under GAAP with certain non-GAAP financial information. Adjusted operating profit is a non-GAAP measure and defined as consolidated operating profit (a GAAP measure), excluding restructuring costs, amortization of acquired intangibles and other significant items of a nonoperational nature. This measure is useful to investors because it is how management assesses the operating performance of the business. A reconciliation of the amounts prepared in accordance with GAAP to the corresponding non-GAAP measure appears below and provides additional information as to the items and amounts that have been excluded from the adjusted measure.

[0001783180-25-000052:mdna:81]
|  |  |  |  | Six Months EndedJune 30, |
| (In millions) |  |  |  |  |  | 2025 |  | 2024 |
| Reconciliation to Adjusted operating profit |  |  |  |  |  |  |  |  |
| Operating profit |  |  |  |  |  | $ | 1,532 |  |  | $ | 1,109 |  |
| Restructuring costs |  |  |  |  |  | 55 |  |  | 37 |  |
| Amortization of acquired intangibles |  |  |  |  |  | 415 |  |  | 342 |  |
| Acquisition step-up amortization |  |  |  |  |  | — |  |  | 220 |  |
| Acquisition/divestiture-related costs |  |  |  |  |  | 19 |  |  | 72 |  |
| CCR gain |  |  |  |  |  | (7) |  |  | — |  |
| Viessmann-related hedges |  |  |  |  |  | — |  |  | 86 |  |
| Gain on liability adjustment |  |  |  |  |  | — |  |  | (46) |  |
| Adjusted operating profit |  |  |  |  |  | $ | 2,014 |  |  | $ | 1,820 |  |

[0001783180-25-000052:mdna:82]
Adjusted operating profit may not be comparable to similarly-titled measures used by other companies and should not be considered a substitute for Operating profit in accordance with GAAP. The non-GAAP information presented provides investors with additional useful information, but should not be considered in isolation or as a substitute for the related GAAP measure. Moreover, other companies may define non-GAAP measures differently, which limits the usefulness of these measures for comparisons with such other companies. We encourage investors to review our financial statements and publicly filed reports in their entirety and not to rely on any single financial measure.

[0001783180-25-000052:mdna:83]
38

[0001783180-25-000052:mdna:84]
[same as prior period, unchanged from 0001783180-25-000030:mdna:48]

[0001783180-25-000052:mdna:85]
[same as prior period, unchanged from 0001783180-25-000030:mdna:49]

[0001783180-25-000052:mdna:86]
[same as prior period, unchanged from 0001783180-25-000030:mdna:50]

[0001783180-25-000052:mdna:87]
[same as prior period, unchanged from 0001783180-25-000030:mdna:51]

[0001783180-25-000052:mdna:88]
[same as prior period, unchanged from 0001783180-25-000030:mdna:52]

[0001783180-25-000052:mdna:89]
[same as prior period, unchanged from 0001783180-25-000030:mdna:53]

[0001783180-25-000052:mdna:90]
[same as prior period, unchanged from 0001783180-25-000030:mdna:54]

[0001783180-25-000052:mdna:91]
Three Months Ended June 30, 2025 Compared with Three Months Ended June 30, 2024

[0001783180-25-000052:mdna:92]
[same as prior period, unchanged from 0001783180-25-000030:mdna:56]

[0001783180-25-000052:mdna:93]
|  |  | Net sales |  | Segment operating profit |  | Segment operating profit margin |
|  |  | Three Months Ended June 30, |  | Three Months Ended June 30, |  | Three Months Ended June 30, |
| (In millions) |  | 2025 |  | 2024 |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Climate Solutions Americas |  | $ | 3,252 |  |  | $ | 2,865 |  |  | $ | 879 |  |  | $ | 713 |  |  | 27.0 | % |  | 24.9 | % |
| Climate Solutions Europe |  | 1,253 |  |  | 1,194 |  |  | 99 |  |  | 93 |  |  | 7.9 | % |  | 7.8 | % |
| Climate Solutions Asia Pacific, Middle East & Africa |  | 882 |  |  | 902 |  |  | 135 |  |  | 157 |  |  | 15.3 | % |  | 17.4 | % |
| Climate Solutions Transportation |  | 726 |  |  | 973 |  |  | 128 |  |  | 138 |  |  | 17.6 | % |  | 14.2 | % |
| Total segment |  | $ | 6,113 |  |  | $ | 5,934 |  |  | $ | 1,241 |  |  | $ | 1,101 |  |  | 20.3 | % |  | 18.6 | % |

[0001783180-25-000052:mdna:94]
[same as prior period, unchanged from 0001783180-25-000030:mdna:58]

[0001783180-25-000052:mdna:95]
|  |  | Three Months Ended June 30, |
| (In millions) |  | 2025 |  | 2024 |
| Segment operating profit |  | $ | 1,241 |  |  | $ | 1,101 |  |
| Corporate and other |  | (75) |  |  | (45) |  |
| Adjusted operating profit |  | $ | 1,166 |  |  | $ | 1,056 |  |

[0001783180-25-000052:mdna:96]
39

[0001783180-25-000052:mdna:97]
[same as prior period, unchanged from 0001783180-25-000030:mdna:60]

[0001783180-25-000052:mdna:98]
For the three months ended June 30, 2025, Net sales were $3.3 billion, a 14% increase compared with the same period of 2024. The components of the year-over-year change were as follows:

[0001783180-25-000052:mdna:99]
|  |  | Net sales |
| Organic |  | 14 | % |
| Foreign currency translation |  | — | % |
| Total % change in Net sales |  | 14 | % |

[0001783180-25-000052:mdna:100]
The organic increase in Net sales of 14% was driven by continued strong results in the segment. Growth in our commercial business (up 39%) was primarily driven by ongoing customer demand. In addition, pricing improvements and favorable mix in our residential business (up 11%) further benefited segment results. These amounts were partially offset by reduced end-market demand in our light commercial business (down 23%).

[0001783180-25-000052:mdna:101]
For the three months ended June 30, 2025, Segment operating profit was $879 million, a 23% increase compared with the same period of 2024. The components of the year-over-year change were as follows:

[0001783180-25-000052:mdna:102]
|  |  | Segment operating profit |
| Operational |  | 24 | % |
| Foreign currency translation |  | (1) | % |
| Total % change in Segment operating profit |  | 23 | % |

[0001783180-25-000052:mdna:103]
The segment operational profit increase of 24% was primarily attributable to ongoing customer demand in certain end-markets compared with the prior year. In addition, favorable productivity initiatives and pricing improvements further benefited segment results. These benefits more than offset volume reductions in certain end-markets and higher selling, general and administrative expenses.

[0001783180-25-000052:mdna:104]
[same as prior period, unchanged from 0001783180-25-000030:mdna:67]

[0001783180-25-000052:mdna:105]
For the three months ended June 30, 2025, Net sales were $1.3 billion, a 5% increase compared with the same period of 2024. The components of the year-over-year change were as follows:

[0001783180-25-000052:mdna:106]
|  |  | Net sales |
| Organic |  | — | % |
| Foreign currency translation |  | 5 | % |
| Total % change in Net sales |  | 5 | % |

[0001783180-25-000052:mdna:107]
Organic Net sales were flat as a result of mixed results across geographies compared with the prior year. Results in our residential and light commercial business were down (down 1%) due to lower volumes across the region as economic conditions, inflationary cost pressures and regulatory uncertainty impacted end-market demand. These results were offset by continued growth in our commercial business (up 2%) as a result of ongoing end-market demand and pricing improvements.

[0001783180-25-000052:mdna:108]
For the three months ended June 30, 2025, Segment operating profit was $99 million, a 6% increase compared with the same period of 2024. The components of the year-over-year change were as follows:

[0001783180-25-000052:mdna:109]
|  |  | Segment operating profit |
| Operational |  | 2 | % |
| Foreign currency translation |  | 4 | % |
| Total % change in Segment operating profit |  | 6 | % |

[0001783180-25-000052:mdna:110]
The segment operational profit increase of 2% was primarily attributable to ongoing customer demand in certain end-markets and favorable productivity initiatives. In addition, business integration synergies associated with the acquisition of the VCS Business further benefited the segment. These amounts were partially offset by volume reductions in certain end-markets, unfavorable product and geographical mix as well as higher selling, general and administrative costs.

[0001783180-25-000052:mdna:111]
[same as prior period, unchanged from 0001783180-25-000030:mdna:75]

[0001783180-25-000052:mdna:112]
For the three months ended June 30, 2025, Net sales were $882 million, a 2% decrease compared with the same period of 2024. The components of the year-over-year change were as follows:

[0001783180-25-000052:mdna:113]
|  |  | Net sales |
| Organic |  | (4) | % |
| Foreign currency translation |  | 2 | % |
| Total % change in Net sales |  | (2) | % |

[0001783180-25-000052:mdna:114]
The organic decrease in Net sales of 4% was driven by volume reductions within certain end-markets compared with the prior year. Results in China decreased (down 11%) as residential end-markets experienced economic challenges impacting demand. These results were partially offset by growth within commercial end-markets in China and improved end-market demand in the remaining geographies in the region.

[0001783180-25-000052:mdna:115]
For the three months ended June 30, 2025, Segment operating profit was $135 million, an 14% decrease compared with the same period of 2024. The components of the year-over-year change were as follows:

[0001783180-25-000052:mdna:116]
|  |  | Segment operating profit |
| Operational |  | (18) | % |
| Foreign currency translation |  | 4 | % |
| Total % change in Segment operating profit |  | (14) | % |

[0001783180-25-000052:mdna:117]
The segment operational profit decrease of 18% was primarily attributable to volume reductions in certain end-markets compared with the prior year. In addition, the segment was impacted by lower earnings from equity method investments. These reductions were partially offset by favorable productivity initiatives and lower selling, general and administrative expenses.

[0001783180-25-000052:mdna:118]
[same as prior period, unchanged from 0001783180-25-000030:mdna:82]

[0001783180-25-000052:mdna:119]
For the three months ended June 30, 2025, Net sales were $726 million, a 25% decrease compared to the same period of 2024. The components of the year-over-year change were as follows:

[0001783180-25-000052:mdna:120]
|  |  | Net sales |
| Organic |  | (1) | % |
| Foreign currency translation |  | 1 | % |
| Acquisitions and divestitures, net |  | (25) | % |
| Total % change in Net sales |  | (25) | % |

[0001783180-25-000052:mdna:121]
The organic decrease in Net sales of 1% was primarily driven by volume reductions within certain end-markets compared with the prior year. Container results increased (up 6%) due to improved end-market demand and pricing improvements. These results were more than offset by our global truck and trailer business (down 4%) as lower end-market demand in Europe and Asia more than offset improved end-market demand in North America.

[0001783180-25-000052:mdna:122]
For the three months ended June 30, 2025, Segment operating profit was $128 million, a 7% decrease compared with the same period of 2024. The components of the year-over-year change were as follows:

[0001783180-25-000052:mdna:123]
|  |  | Segment operating profit |
| Operational |  | (9) | % |
| Foreign currency translation |  | 2 | % |
| Total % change in Segment operating profit |  | (7) | % |

[0001783180-25-000052:mdna:124]
The decrease in segment operational profit of 9% was primarily driven by volume reductions with certain end-markets compared with the prior year. In addition, unfavorable mix further impacted the segment. These amounts were partially offset by higher volumes in certain end-markets, favorable productivity initiatives and lower selling, general and administrative expenses.

[0001783180-25-000052:mdna:125]
42

[0001783180-25-000052:mdna:126]
Six Months Ended June 30, 2025 Compared with Six Months Ended June 30, 2024

[0001783180-25-000052:mdna:127]
Summary performance for each of our segments is as follows:

[0001783180-25-000052:mdna:128]
|  | Net sales |  | Segment operating profit |  | Segment operating profit margin |
|  | Six Months EndedJune 30, |  | Six Months EndedJune 30, |  | Six Months EndedJune 30, |
| (In millions) | 2025 |  | 2024 |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Climate Solutions Americas | $ | 5,824 |  |  | $ | 5,225 |  |  | $ | 1,449 |  |  | $ | 1,138 |  |  | 24.9 | % |  | 21.8 | % |
| Climate Solutions Europe | 2,422 |  |  | 2,486 |  |  | 204 |  |  | 260 |  |  | 8.4 | % |  | 10.5 | % |
| Climate Solutions Asia Pacific, Middle East & Africa | 1,708 |  |  | 1,786 |  |  | 256 |  |  | 265 |  |  | 15.0 | % |  | 14.8 | % |
| Climate Solutions Transportation | 1,377 |  |  | 1,857 |  |  | 225 |  |  | 251 |  |  | 16.3 | % |  | 13.5 | % |
| Total segment | $ | 11,331 |  |  | $ | 11,354 |  |  | $ | 2,134 |  |  | $ | 1,914 |  |  | 18.8 | % |  | 16.9 | % |

[0001783180-25-000052:mdna:129]
A reconciliation of Segment operating profit to Adjusted operating profit is as follows:

[0001783180-25-000052:mdna:130]
|  |  | Six Months EndedJune 30, |
| (In millions) |  | 2025 |  | 2024 |
| Segment operating profit |  | $ | 2,134 |  |  | $ | 1,914 |  |
| Corporate and other |  | (120) |  |  | (94) |  |
| Adjusted operating profit |  | $ | 2,014 |  |  | $ | 1,820 |  |

[0001783180-25-000052:mdna:131]
Climate Solutions Americas

[0001783180-25-000052:mdna:132]
For the six months ended June 30, 2025, Net sales were $5.8 billion, a 11% increase compared with the same period of 2024. The components of the year-over-year change were as follows:

[0001783180-25-000052:mdna:133]
|  |  | Net sales |
| Organic |  | 11 | % |
| Foreign currency translation |  | — | % |
| Total % change in Net sales |  | 11 | % |

[0001783180-25-000052:mdna:134]
The organic increase in Net sales of 11% was driven by continued strong results in the segment. Growth in our residential business (up 15%) was primarily driven by pricing improvements and favorable mix compared to the prior year. In addition, ongoing customer demand in our commercial business (up 27%) further benefited segment results. These amounts were partially offset by reduced end-market demand in our light commercial business (down 28%).

[0001783180-25-000052:mdna:135]
For the six months ended June 30, 2025, Segment operating profit was $1,449 million, a 27% increase compared with the same period of 2024. The components of the year-over-year change were as follows:

[0001783180-25-000052:mdna:136]
|  |  | Segment operating profit |
| Operational |  | 28 | % |
| Foreign currency translation |  | (1) | % |
| Total % change in Operating profit |  | 27 | % |

[0001783180-25-000052:mdna:137]
43

[0001783180-25-000052:mdna:138]
The segment operational profit increase of 28% was primarily attributable to ongoing customer demand in certain end-markets compared with the prior year. In addition, favorable productivity initiatives, pricing improvements and higher earnings from equity method investments further benefited segment results. These benefits more than offset volume reductions in certain end-markets and higher selling, general and administrative expenses.

[0001783180-25-000052:mdna:139]
Climate Solutions Europe

[0001783180-25-000052:mdna:140]
For the six months ended June 30, 2025, Net sales were $2.4 billion, a 3% decrease compared with the same period of 2024. The components of the year-over-year change were as follows:

[0001783180-25-000052:mdna:141]
|  |  | Net sales |
| Organic |  | (4) | % |
| Foreign currency translation |  | 1 | % |
| Total % change in Net sales |  | (3) | % |

[0001783180-25-000052:mdna:142]
The organic decrease in Net sales of 4% was driven by ongoing challenges in certain end-markets compared with the prior year. Results in our residential and light commercial business decreased (down 6%) due to lower volumes across the region as economic conditions, inflationary cost pressures and regulatory uncertainty impacted end-market demand. These results were partially offset by continued growth in our commercial business (up 3%) as a result of strong end-market demand and pricing improvements.

[0001783180-25-000052:mdna:143]
For the six months ended June 30, 2025, Segment operating profit was $204 million, a 22% decrease compared with the same period of 2024. The components of the year-over-year change were as follows:

[0001783180-25-000052:mdna:144]
|  |  | Segment operating profit |
| Operational |  | (22) | % |
| Foreign currency translation |  | — | % |
| Total % change in Operating profit |  | (22) | % |

[0001783180-25-000052:mdna:145]
The segment operational profit decrease of 22% was primarily attributable to volume reductions in certain end-markets compared with the prior year. These amounts were partially offset by favorable material costs, business integration synergies associated with the acquisition of the VCS Business and lower selling, general and administrative expenses. In addition, ongoing end-market demand in certain markets further benefited the segment.

[0001783180-25-000052:mdna:146]
Climate Solutions Asia Pacific, Middle East & Africa

[0001783180-25-000052:mdna:147]
For the six months ended June 30, 2025, Net sales were $1.7 billion, a 4% decrease compared with the same period of 2024. The components of the year-over-year change were as follows:

[0001783180-25-000052:mdna:148]
|  |  | Net sales |
| Organic |  | (5) | % |
| Foreign currency translation |  | 1 | % |
| Total % change in Net sales |  | (4) | % |

[0001783180-25-000052:mdna:149]
The organic decrease in Net sales of 5% was driven by volume reductions within certain end-markets compared with the prior year. Results in China decreased (down 11%) as residential end-markets experienced economic challenges impacting demand. These results were partially offset by growth within commercial end-markets in China and improved end-market demand in the remaining geographies in the region.

[0001783180-25-000052:mdna:150]
For the six months ended June 30, 2025, Segment operating profit was $256 million, a 3% decrease compared with the same period of 2024. The components of the year-over-year change were as follows:

[0001783180-25-000052:mdna:151]
|  |  | Segment operating profit |
| Operational |  | (6) | % |
| Foreign currency translation |  | 3 | % |
| Total % change in Operating profit |  | (3) | % |

[0001783180-25-000052:mdna:152]
The segment operational profit decrease of 6% was primarily attributable to volume reductions within certain end-markets compared with the prior year. The segment was further impacted by lower earnings from equity method investments. These amounts were partially offset by favorable productivity initiatives and lower selling, general and administrative expenses.

[0001783180-25-000052:mdna:153]
Climate Solutions Transportation

[0001783180-25-000052:mdna:154]
For the six months ended June 30, 2025, Net sales were $1,377 million, a 26% decrease compared to the same period of 2024. The components of the year-over-year change were as follows:

[0001783180-25-000052:mdna:155]
|  |  | Net sales |
| Organic |  | — | % |
| Acquisitions and divestitures, net |  | (26) | % |
| Total % change in Net sales |  | (26) | % |

[0001783180-25-000052:mdna:156]
Organic Net sales were flat as a result of mixed results within the segment compared with the prior year. Container results increased (up 12%) due to improved end-market demand and pricing improvements. These results were offset by our global truck and trailer business (down 4%) as lower end-market demand in Europe more than offset improved end-market demand in Asia and North America.

[0001783180-25-000052:mdna:157]
For the six months ended June 30, 2025, Segment operating profit was $225 million, a 10% decrease compared with the same period of 2024. The components of the year-over-year change were as follows:

[0001783180-25-000052:mdna:158]
|  |  | Segment operating profit |
| Operational |  | (9) | % |
| Acquisitions and divestitures, net |  | (1) | % |
| Total % change in Operating profit |  | (10) | % |

[0001783180-25-000052:mdna:159]
The decrease in segment operational profit of 9% was primarily driven by volume reductions in certain end-markets. In addition, unfavorable mix and higher costs associated with warranty-related issues further impacted the segment. These amounts were partially offset by by higher volumes in certain end-markets, favorable productivity initiatives and lower selling, general and administrative expenses.

[0001783180-25-000052:mdna:160]
45

[0001783180-25-000052:mdna:161]
[same as prior period, unchanged from 0001783180-25-000030:mdna:89]

[0001783180-25-000052:mdna:162]
[same as prior period, unchanged from 0001783180-25-000030:mdna:90]

[0001783180-25-000052:mdna:163]
As of June 30, 2025, we had cash and cash equivalents of $1.8 billion, of which approximately 82% was held by our foreign subsidiaries. We manage our worldwide cash requirements by reviewing available funds and the cost effectiveness with which we can access funds held by foreign subsidiaries. On occasion, we are required to maintain cash deposits in connection with contractual obligations related to acquisitions, divestitures or other legal obligations. As of June 30, 2025 and December 31, 2024, the amount of such restricted cash was approximately $3 million and $3 million, respectively.

[0001783180-25-000052:mdna:164]
[same as prior period, unchanged from 0001783180-25-000030:mdna:92]

[0001783180-25-000052:mdna:165]
[same as prior period, unchanged from 0001783180-25-000030:mdna:93]

[0001783180-25-000052:mdna:166]
[same as prior period, unchanged from 0001783180-25-000030:mdna:95]

[0001783180-25-000052:mdna:167]
| (In millions) |  | June 30,2025 |  | December 31,2024 |
| Cash and cash equivalents |  | $ | 1,797 |  |  | $ | 3,969 |  |
| Total debt |  | $ | 11,443 |  |  | $ | 12,278 |  |
| Total equity |  | $ | 15,014 |  |  | $ | 14,395 |  |
| Net debt (total debt less cash and cash equivalents) |  | $ | 9,646 |  |  | $ | 8,309 |  |
| Total capitalization (total debt plus total equity) |  | $ | 26,457 |  |  | $ | 26,673 |  |
| Net capitalization (total debt plus total equity less cash and cash equivalents) |  | $ | 24,660 |  |  | $ | 22,704 |  |
| Total debt to total capitalization |  | 43 | % |  | 46 | % |
| Net debt to net capitalization |  | 39 | % |  | 37 | % |

[0001783180-25-000052:mdna:168]
[same as prior period, unchanged from 0001783180-25-000030:mdna:97]

[0001783180-25-000052:mdna:169]
We maintain a $2.0 billion USD-denominated unsecured, unsubordinated commercial paper program which we can use for general corporate purposes, including the funding of working capital and potential acquisitions. In addition, we maintain a $2.5 billion revolving credit agreement with various banks (the "Revolving Credit Facility") that matures in December 2029 which supports our commercial paper borrowing program and can be used for general corporate purposes. A ratings-based commitment fee is charged on unused commitments. As of June 30, 2025, we had no borrowings outstanding under our commercial paper program or our Revolving Credit Facility.

[0001783180-25-000052:mdna:170]
On July 1, 2025, we entered into a $500 million Euro-denominated unsecured, unsubordinated commercial paper program which can be used for general corporate purposes and is supported by the Revolving Credit Facility.

[0001783180-25-000052:mdna:171]
46

[0001783180-25-000052:mdna:172]
Our short-term obligations primarily consist of current maturities of long-term debt. Our long-term obligations primarily consist of long-term notes with maturity dates ranging between 2027 and 2054. Interest payments related to long-term notes are expected to approximate $407 million per year, reflecting an approximate weighted-average interest rate of 3.64%. Any borrowings from the Revolving Credit Facility are subject to variable interest rates. See Note 5 – Borrowings and Lines of Credit in the Notes to the accompanying Unaudited Condensed Consolidated Financial Statements for additional information regarding the terms of our long-term debt obligations.

[0001783180-25-000052:mdna:173]
Our credit ratings are periodically reviewed by the major independent debt-rating agencies. As of June 30, 2025, Standards & Poor's Global Inc. and Moody’s Investor Service Inc. have ratings on our debt set forth in the table below:

[0001783180-25-000052:mdna:174]
| Rating Agency |  | Long-term Rating |  | Short-term Rating |  | Outlook |
| Standards & Poor's Global Inc. |  | BBB+ |  | A2 |  | Stable |
| Moody's Investors Service Inc. |  | Baa1 |  | P-2 |  | Positive |

[0001783180-25-000052:mdna:175]
[same as prior period, unchanged from 0001783180-25-000030:mdna:102]

[0001783180-25-000052:mdna:176]
On June 2, 2024, we completed the divestiture of our Access Solutions business for cash proceeds of $5.0 billion. On July 1, 2024, we completed the divestiture of our Industrial Fire business for cash proceeds of $1.4 billion. On October 1, 2024, we completed the divestiture of CCR for cash proceeds of $679 million. On December 2, 2024, we completed the divestiture of the Commercial and Residential Fire business for cash proceeds of $2.9 billion. Consistent with our capital allocation strategy, the net proceeds were used to fund repayment of debt, invest in organic and inorganic growth initiatives, capital returns to shareowners as well as for general corporate purposes.

[0001783180-25-000052:mdna:177]
[same as prior period, unchanged from 0001783180-25-000030:mdna:105]

[0001783180-25-000052:mdna:178]
[same as prior period, unchanged from 0001783180-25-000030:mdna:106]

[0001783180-25-000052:mdna:179]
During the six months ended June 30, 2025, we repurchased 28.8 million shares of common stock for an aggregate purchase price of $1.9 billion, which included shares repurchased from Viessmann. As a result, we had approximately $1.3 billion remaining under the current authorization at June 30, 2025.

[0001783180-25-000052:mdna:180]
[same as prior period, unchanged from 0001783180-25-000030:mdna:108]

[0001783180-25-000052:mdna:181]
We paid dividends on common stock during the six months ended June 30, 2025, totaling $390 million. In June 2025, the Board of Directors declared a dividend of $0.23 per share of common stock payable on August 8, 2025, to shareowners of record at the close of business on July 21, 2025.

[0001783180-25-000052:mdna:182]
[same as prior period, unchanged from 0001783180-25-000030:mdna:110]

[0001783180-25-000052:mdna:183]
[same as prior period, unchanged from 0001783180-25-000030:mdna:111]

[0001783180-25-000052:mdna:184]
|  |  | Six Months EndedJune 30, |
| (In millions) |  | 2025 |  | 2024 |
| Net cash flows provided by (used in): |  |  |  |  |
| Continuing operating activities |  | $ | 752 |  |  | $ | 609 |  |
| Continuing investing activities |  | (113) |  |  | (11,147) |  |
| Continuing financing activities |  | (3,294) |  |  | (1,391) |  |

[0001783180-25-000052:mdna:185]
47

[0001783180-25-000052:mdna:186]
Cash flows from continuing operating activities primarily represent inflows and outflows associated with our continuing operations. Primary activities include net earnings from continuing operations adjusted for non-cash transactions, working capital changes and changes in other assets and liabilities. The year-over-year increase in net cash provided by continuing operating activities was primarily driven by higher net earnings partially offset by working capital balances compared with the prior period.

[0001783180-25-000052:mdna:187]
Cash flows from continuing investing activities primarily represent inflows and outflows associated with long-term assets. Primary activities include capital expenditures, acquisitions, divestitures and proceeds from the sale of fixed assets. During the six months ended June 30, 2025, net cash used in continuing investing activities was $113 million. The primary driver of the outflow related to $144 million of capital expenditures which was partially offset by $87 million cash inflow related to settlement of derivatives. During the six months ended June 30, 2024, net cash used in continuing investing activities was $11.1 billion. The primary driver of the outflow related to the acquisition of the VCS Business, which totaled $10.8 billion, net of cash acquired. Additional investing outflows include $185 million related to settlement of derivatives and $210 million of capital expenditures.

[0001783180-25-000052:mdna:188]
Cash flows from continuing financing activities primarily represent inflows and outflows associated with equity or borrowings. During the six months ended June 30, 2025, net cash used in continuing financing activities was $3.3 billion. The primary driver of the outflow was related to repurchases of our common stock totaling $1.6 billion. In addition, we made long-term debt repayments of $1.2 billion and the payment of $390 million in dividends to our common shareowners. During the six months ended June 30, 2024, net cash used in continuing financing activities was $1.4 billion. The primary driver of the outflow is due to repayment of long-term debt totaling $3.5 billion. In addition, we made dividend payments of $330 million. These outflows were partially offset by the proceeds of long-term debt used to fund the cash portion of the acquisition of the VCS Business.
