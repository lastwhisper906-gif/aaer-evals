# CARR 10-Q controls and the auditor's report


## item_4_controls

[0001783180-25-000052:item_4_controls:1]
Item 4.    Controls and Procedures

[0001783180-25-000052:item_4_controls:2]
As required by Rule 13a-15 under the Securities Exchange Act of 1934, as amended (the "Exchange Act"), we carried out an evaluation under the supervision and with the participation of our management, including the Chairman and Chief Executive Officer ("CEO"), the Senior Vice President and Chief Financial Officer ("CFO") of the effectiveness of the design and operation of our disclosure controls and procedures as of June 30, 2025. There are inherent limitations to the effectiveness of any system of disclosure controls and procedures, including the possibility of human error and the circumvention or overriding of the controls and procedures. Accordingly, even effective disclosure controls and procedures can only provide reasonable assurance of achieving their control objectives. Based upon our evaluation, our CEO and CFO have concluded that, as of June 30, 2025, our disclosure controls and procedures were effective and provide reasonable assurance that information required to be disclosed in the reports that we file or submit under the Exchange Act is recorded, processed, summarized and reported within the time periods specified in the applicable rules and forms, and that it is accumulated and communicated to our management, including our CEO and CFO, as appropriate, to allow timely decisions regarding required disclosure.

[0001783180-25-000052:item_4_controls:3]
There has been no change in our internal control over financial reporting during the three months ended June 30, 2025, that has materially affected, or is reasonably likely to materially affect, our internal control over financial reporting.

[0001783180-25-000052:item_4_controls:4]
48
