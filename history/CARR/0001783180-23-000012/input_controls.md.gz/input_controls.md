# CARR 10-K controls and the auditor's report


## auditors_report

[0001783180-23-000012:auditors_report:1]
Report of Independent Registered Public Accounting Firm

[0001783180-23-000012:auditors_report:2]
To the Board of Directors and Shareowners of Carrier Global Corporation

[0001783180-23-000012:auditors_report:3]
Opinions on the Financial Statements and Internal Control over Financial Reporting

[0001783180-23-000012:auditors_report:4]
We have audited the accompanying consolidated balance sheet of Carrier Global Corporation and its subsidiaries (the “Company”) as of December 31, 2022 and 2021, and the related consolidated statements of operations, of comprehensive income (loss), of changes in equity and of cash flows for each of the three years in the period ended December 31, 2022, including the related notes (collectively referred to as the “consolidated financial statements”). We also have audited the Company's internal control over financial reporting as of December 31, 2022, based on criteria established in Internal Control - Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (COSO).

[0001783180-23-000012:auditors_report:5]
In our opinion, the consolidated financial statements referred to above present fairly, in all material respects, the financial position of the Company as of December 31, 2022 and 2021, and the results of its operations and its cash flows for each of the three years in the period ended December 31, 2022 in conformity with accounting principles generally accepted in the United States of America. Also in our opinion, the Company maintained, in all material respects, effective internal control over financial reporting as of December 31, 2022, based on criteria established in Internal Control - Integrated Framework (2013) issued by the COSO.

[0001783180-23-000012:auditors_report:6]
Basis for Opinions

[0001783180-23-000012:auditors_report:7]
The Company's management is responsible for these consolidated financial statements, for maintaining effective internal control over financial reporting, and for its assessment of the effectiveness of internal control over financial reporting, included in Management’s Report on Internal Control Over Financial Reporting appearing under Item 9A. Our responsibility is to express opinions on the Company’s consolidated financial statements and on the Company's internal control over financial reporting based on our audits. We are a public accounting firm registered with the Public Company Accounting Oversight Board (United States) (PCAOB) and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0001783180-23-000012:auditors_report:8]
We conducted our audits in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audits to obtain reasonable assurance about whether the consolidated financial statements are free of material misstatement, whether due to error or fraud, and whether effective internal control over financial reporting was maintained in all material respects.

[0001783180-23-000012:auditors_report:9]
Our audits of the consolidated financial statements included performing procedures to assess the risks of material misstatement of the consolidated financial statements, whether due to error or fraud, and performing procedures that respond to those risks. Such procedures included examining, on a test basis, evidence regarding the amounts and disclosures in the consolidated financial statements. Our audits also included evaluating the accounting principles used and significant estimates made by management, as well as evaluating the overall presentation of the consolidated financial statements. Our audit of internal control over financial reporting included obtaining an understanding of internal control over financial reporting, assessing the risk that a material weakness exists, and testing and evaluating the design and operating effectiveness of internal control based on the assessed risk. Our audits also included performing such other procedures as we considered necessary in the circumstances. We believe that our audits provide a reasonable basis for our opinions.

[0001783180-23-000012:auditors_report:10]
As described in Management’s Report on Internal Control Over Financial Reporting, management has excluded Toshiba Carrier Corporation (TCC) from its assessment of internal control over financial reporting as of December 31, 2022, because it was acquired by the Company in a purchase business combination during 2022. We have also excluded TCC from our audit of internal control over financial reporting. TCC is a majority-owned subsidiary whose total assets and total net sales excluded from management’s assessment and our audit of internal control over financial reporting represent approximately 7% and 4%, respectively, of the related consolidated financial statement amounts as of and for the year ended December 31, 2022.

[0001783180-23-000012:auditors_report:11]
Definition and Limitations of Internal Control over Financial Reporting

[0001783180-23-000012:auditors_report:12]
A company’s internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally

[0001783180-23-000012:auditors_report:13]
accepted accounting principles. A company’s internal control over financial reporting includes those policies and procedures that (i) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the company; (ii) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the company are being made only in accordance with authorizations of management and directors of the company; and (iii) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the company’s assets that could have a material effect on the financial statements.

[0001783180-23-000012:auditors_report:14]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0001783180-23-000012:auditors_report:15]
Critical Audit Matters

[0001783180-23-000012:auditors_report:16]
The critical audit matters communicated below are matters arising from the current period audit of the consolidated financial statements that were communicated or required to be communicated to the audit committee and that (i) relate to accounts or disclosures that are material to the consolidated financial statements and (ii) involved our especially challenging, subjective, or complex judgments. The communication of critical audit matters does not alter in any way our opinion on the consolidated financial statements, taken as a whole, and we are not, by communicating the critical audit matters below, providing separate opinions on the critical audit matters or on the accounts or disclosures to which they relate.

[0001783180-23-000012:auditors_report:17]
Revenue Recognition from Contracts with Customers

[0001783180-23-000012:auditors_report:18]
As described in Note 13 to the consolidated financial statements, the Company recognized $20,421 million of consolidated revenue for the year ended December 31, 2022. Some of the Company’s contracts with customers contain a single performance obligation, while others contain multiple performance obligations most commonly when a contract spans multiple phases of a product life-cycle such as production, installation, maintenance and support. The Company recognizes revenue when control of a good or service promised in a contract (i.e., performance obligation) is transferred to a customer. Control is obtained when a customer has the ability to direct the use of and obtain substantially all of the remaining benefits from that good or service. A significant portion of the Company's performance obligations are recognized at a point-in-time when control of the product transfers to the customer, which is generally the time of shipment. The remaining portion of the Company's performance obligations are recognized over time as the customer simultaneously obtains control as the Company performs work under a contract, or if the product being produced for the customer has no alternative use and the Company has a contractual right to payment. For over-time performance obligations requiring the installation of equipment, revenue is recognized using costs incurred to date relative to total estimated costs at completion to measure progress. The Company includes variable consideration in the estimated transaction price when there is a basis to reasonably estimate the amount and when it is probable that a significant reversal of revenue recognized would not occur when the uncertainty associated with variable consideration is subsequently resolved. In addition, the Company customarily offers its customers incentives to purchase products to ensure an adequate supply of its products in distribution channels. The principal incentive programs provide reimbursements to distributors for offering promotional pricing for products. The Company accounts for estimated incentive payments as a reduction in sales at the time a sale is recognized.

[0001783180-23-000012:auditors_report:19]
The principal considerations for our determination that performing procedures relating to revenue recognition from contracts with customers is a critical audit matter are the high degree of audit effort in performing procedures related to revenue recognized on the Company’s point-in-time and over-time contracts with customers and in evaluating evidence related to management’s determination of total estimated costs at completion for revenue recognized on an over-time basis.

[0001783180-23-000012:auditors_report:20]
Addressing the matter involved performing procedures and evaluating audit evidence in connection with forming our overall opinion on the consolidated financial statements. These procedures included testing the effectiveness of controls relating to the revenue recognition process on the Company’s point-in-time and over-time contracts with customers, including controls over the determination of total estimated costs at completion for revenue recognized on an over-time basis. These procedures also included, among others (i) evaluating management’s significant accounting policies related to revenue recognition; (ii) testing the appropriateness of the timing and amount of revenue recognized for a sample of point-in-time revenue transactions by obtaining and inspecting source documents, such as contracts with customers, purchase order information, shipping documents, cash receipts, and other documentation; and (iii) evaluating and testing management’s process for determining the total estimated costs at completion for a sample of over-time revenue contracts, which included evaluating the total estimated costs at completion used by management by considering factors that can affect the accuracy of those estimates. Evaluating the total

[0001783180-23-000012:auditors_report:21]
estimated costs at completion for revenue recognized on an over-time basis involved comparing the originally estimated costs and actual costs incurred, including identifying circumstances that may warrant a modification to the total estimated costs to complete.

[0001783180-23-000012:auditors_report:22]
Acquisition of TCC – Valuation of Technology, Trademark, and Certain Customer Relationships Intangible Assets

[0001783180-23-000012:auditors_report:23]
As described in Note 19 to the consolidated financial statements, on August 1, 2022, the Company acquired a majority ownership interest in TCC for $930 million, which resulted in the recognition of intangible assets including $220 million of technology, $180 million of trademark, and $497 million of customer relationships. The valuation of intangible assets was determined using an income approach methodology including the multi-period excess earnings method and the relief from royalty method. Key assumptions used in estimating future cash flows included projected revenue growth rates, earnings before interest and taxes (“EBIT”) margins, discount rates, customer attrition rates, and royalty rates, among others.

[0001783180-23-000012:auditors_report:24]
The principal considerations for our determination that performing procedures relating to the valuation of technology, trademark, and certain customer relationships intangible assets acquired in the acquisition of TCC is a critical audit matter are (i) the significant judgment by management when developing the fair value estimate of the technology, trademark, and certain customer relationships intangible assets; (ii) a high degree of auditor judgment, subjectivity, and effort in performing procedures and evaluating management’s significant assumptions related to certain royalty rates used in the valuation of the technology, the discount rate and royalty rate used in the valuation of the trademark, and certain projected revenue growth rates, EBIT margins, discount rates, and customer attrition rates used in the valuation of certain customer relationships; and (iii) the audit effort involved the use of professionals with specialized skill and knowledge.

[0001783180-23-000012:auditors_report:25]
Addressing the matter involved performing procedures and evaluating audit evidence in connection with forming our overall opinion on the consolidated financial statements. These procedures included testing the effectiveness of controls relating to business combination accounting, including controls over management’s valuation of the technology, trademark, and certain customer relationships intangible assets and controls over the development of significant assumptions related to projected revenue growth rates, EBIT margins, discount rates, customer attrition rates, and royalty rates, as applicable to the respective intangible assets. These procedures also included, among others (i) reading the purchase agreement and (ii) testing management’s process for developing the fair value estimate of the technology, trademark, and certain customer relationships intangible assets. Testing management’s process included evaluating the appropriateness of the valuation methods, testing the completeness and accuracy of the underlying data used by management, and evaluating the reasonableness of the aforementioned significant assumptions. Evaluating management’s assumptions related to certain projected revenue growth rates and EBIT margins involved considering TCC’s historical performance, consistency with economic and industry data, and whether these assumptions were consistent with evidence obtained in other areas of the audit. Professionals with specialized skill and knowledge were used to assist in the evaluation of the appropriateness of the Company’s valuation methods and the evaluation of the reasonableness of the significant assumptions related to discount rates, customer attrition rates, and certain royalty rates.

[0001783180-23-000012:auditors_report:26]
/s/ PricewaterhouseCoopers LLP

[0001783180-23-000012:auditors_report:27]
Hallandale Beach, Florida

[0001783180-23-000012:auditors_report:28]
February 7, 2023

[0001783180-23-000012:auditors_report:29]
We have served as the Company's auditor since 2019.

[0001783180-23-000012:auditors_report:30]
CARRIER GLOBAL CORPORATION AND SUBSIDIARIES


## item_9a

[0001783180-23-000012:item_9a:1]
ITEM 9A. CONTROLS AND PROCEDURES

[0001783180-23-000012:item_9a:2]
Evaluation of Disclosure Controls and Procedures — Our management, with the participation of our CEO and Senior Vice President and Chief Financial Officer ("CFO"), has evaluated the effectiveness of the Company's disclosure controls and procedures (as such term is defined in Rules 13a-15(e) and 15d-15(e) under the Exchange Act) as of December 31, 2022. Based on that evaluation, the Company's CEO and CFO have concluded that, as of December 31, 2022, the Company's disclosure controls and procedures were effective in recording, processing, summarizing and reporting, within the time periods specified in the SEC's rules and forms, information required to be disclosed by the Company in the reports that it files or submits under the Exchange Act, and that information is accumulated and communicated to the Company's management, including our CEO and CFO, as appropriate, to allow timely decisions regarding required disclosures.

[0001783180-23-000012:item_9a:3]
Management’s Report on Internal Control Over Financial Reporting — The Company’s management is responsible for establishing and maintaining adequate internal control over financial reporting, as such term is defined in Exchange Act Rules 13a-15(f) and 15d-15(f). The Company’s management, with the participation of the Company’s CEO and CFO, has evaluated the effectiveness of the Company’s internal control over financial reporting based on the criteria described in Internal Control-Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission. Based on this evaluation, the Company’s management has concluded that, as of December 31, 2022, the Company’s internal control over financial reporting was effective.

[0001783180-23-000012:item_9a:4]
In accordance with guidance issued by the staff of the SEC, companies are permitted to exclude acquisitions from their assessment of internal control over financial reporting for the first fiscal year in which the acquisition occurred. As discussed in Note 19 "Acquisitions" of the Company's Notes to the Consolidated Financial Statements, the Company acquired a majority ownership interest in TCC on August 1, 2022 in a purchase business combination. TCC has total assets excluding intangible assets and goodwill arising from the acquisition and total net sales, of approximately 7% and 4%, respectively, of the related consolidated financial statement amounts as of and for the year ended December 31, 2022. Management's assessment of the effectiveness of our internal control over financial reporting as of December 31, 2022 excluded the TCC acquisition, as the Company is in the process of aligning and integrating various processes, systems and internal controls related to the business and operations of this subsidiary, excluding intangible assets and goodwill, which are included within the scope of management’s assessment.

[0001783180-23-000012:item_9a:5]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0001783180-23-000012:item_9a:6]
PricewaterhouseCoopers LLP, an independent registered public accounting firm, has audited the effectiveness of the Company's internal control over financial reporting as of December 31, 2022 as stated in their report which appears herein.

[0001783180-23-000012:item_9a:7]
Changes in Internal Control Over Financial Reporting — There were no changes in our internal control over financial reporting during the three months ended December 31, 2022 that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.

[0001783180-23-000012:item_9a:8]
89
