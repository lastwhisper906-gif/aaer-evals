# CARR MD&A — 0001783180-23-000012


## mdna

[0001783180-23-000012:mdna:1]
ITEM 7. MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0001783180-23-000012:mdna:2]
BUSINESS OVERVIEW

[0001783180-23-000012:mdna:3]
Business Summary

[0001783180-23-000012:mdna:4]
Carrier Global Corporation is the leading global provider of healthy, safe, sustainable and intelligent building and cold chain solutions with a focus on providing differentiated, digitally-enabled lifecycle solutions to our customers. Our portfolio includes industry-leading brands such as Carrier, Toshiba, Automated Logic, Carrier Transicold, Kidde, Edwards and LenelS2 that offer innovative HVAC, refrigeration, fire, security and building automation technologies to help make the world safer and more comfortable. We also provide a broad array of related building services, including audit, design, installation, system integration, repair, maintenance and monitoring. Our operations are classified into three segments: HVAC, Refrigeration and Fire & Security.

[0001783180-23-000012:mdna:5]
Our worldwide operations are affected by global and regional industrial, economic and political factors and trends. These include the mega-trends of urbanization, climate change and increasing requirements for food safety driven by the food needs of our growing global population and the rising standards of living in emerging markets. We believe that our business segments are well positioned to benefit from favorable secular trends, including these mega-trends and from the strength of our industry-leading brands and track record of innovation. In addition, we regularly review our end markets to proactively identify trends and adapt our strategies accordingly.

[0001783180-23-000012:mdna:6]
Our business is also affected by changes in the general level of economic activity, such as changes in business and consumer spending, construction and shipping activity as well as short-term economic factors such as currency fluctuations, commodity price volatility and supply disruptions. We continue to invest in our business, take pricing actions to mitigate supply chain and inflationary pressures, develop new products and services in order to remain competitive in our markets and use risk management strategies to mitigate various exposures. We believe that we have industry-leading global brands, which form the foundation of our business strategy. Coupled with our focus on growth, innovation and operational efficiency, we expect to drive long-term future growth and increased value for our shareowners.

[0001783180-23-000012:mdna:7]
Significant Events

[0001783180-23-000012:mdna:8]
Acquisition of Toshiba Carrier Corporation

[0001783180-23-000012:mdna:9]
On February 6, 2022, we entered into a binding agreement to acquire a majority ownership interest in TCC, a VRF and light commercial HVAC joint venture between Carrier and Toshiba Corporation. TCC designs and manufactures flexible, energy-efficient and high-performance VRF and light commercial HVAC systems as well as commercial products, compressors and heat pumps. The acquisition included all of TCC's advanced research and development centers and global manufacturing operations, product pipeline and the long-term use of Toshiba's iconic brand. The acquisition was completed on August 1, 2022. As a result, the assets, liabilities and results of operations of TCC are consolidated in the accompanying Consolidated Financial Statements as of the date of acquisition and reported within our HVAC segment. Upon closing, Toshiba Corporation retained a 5% ownership interest in TCC.

[0001783180-23-000012:mdna:10]
Supply Chain Challenges

[0001783180-23-000012:mdna:11]
The ongoing global economic recovery from the COVID-19 pandemic has caused significant challenges for global supply chains resulting in inflationary cost pressures, component shortages and transportation delays. As a result, we have incurred incremental costs for commodities and components used in our products as well as component shortages that have negatively

[0001783180-23-000012:mdna:12]
impacted our sales and results of operations. We expect that these challenges will continue to have an impact on our businesses for the foreseeable future.

[0001783180-23-000012:mdna:13]
We continue to take proactive steps to limit the impact of these challenges and are working closely with our suppliers to ensure availability of products and implement other cost savings initiatives. In addition, we continue to invest in our supply chain to improve its resilience with a focus on automation, dual sourcing of critical components and localized manufacturing when feasible. To date, there has been limited disruption to the availability of our products, though it is possible that more significant disruptions could occur if these supply chain challenges continue.

[0001783180-23-000012:mdna:14]
Russia's Invasion of Ukraine

[0001783180-23-000012:mdna:15]
In February 2022, Russian forces initiated a military action against Ukraine. As a result, the European Union, the United States, the United Kingdom and other countries have imposed sanctions that have increased global economic and political uncertainty. We operated in Russia through a Russia-based subsidiary and a joint venture which represented less than 1% of our total assets and revenue. On March 10, 2022, we announced that we were suspending business operations in Russia, honoring existing contractual obligations in a manner that fully complies with all sanctions and trade controls imposed. As of December 31, 2022, we have ceased all operations in Russia. While neither Russia nor Ukraine constitute a material portion of our business, the conflict could lead to disruption, instability and volatility in global markets and industries that could negatively impact our results of operations. We continue to monitor the evolving impacts of this conflict and its effect on the global economy and geopolitical landscape.

[0001783180-23-000012:mdna:16]
Sale of Chubb Fire & Security Business

[0001783180-23-000012:mdna:17]
On July 26, 2021, we entered into a stock purchase agreement to sell our Chubb business to APi. Chubb, which was reported within our Fire & Security segment, delivered essential fire safety and security solutions from design and installation to monitoring, service and maintenance across more than 17 countries around the globe. On January 3, 2022, we completed the Chubb Sale for net proceeds of $2.9 billion and recognized a gain on the sale of $1.1 billion during the year ended December 31, 2022.

[0001783180-23-000012:mdna:18]
Impact of the COVID-19 Pandemic

[0001783180-23-000012:mdna:19]
In early 2020, the World Health Organization declared the outbreak of a respiratory disease known as COVID-19 as a global pandemic. In response, many countries implemented containment and mitigation measures to combat the outbreak, which severely restricted the level of economic activity and caused a significant contraction in the global economy. As a result, we took several preemptive actions to manage liquidity, preserve the health and safety of our employees and customers as well as maintaining the continuity of our operations. The preparation of financial statements requires management to use judgments in making estimates and assumptions based on the relevant information available at the end of each period, which can have a significant effect on reported amounts. However, due to significant uncertainty surrounding the pandemic, including a resurgence in cases and the spread of COVID-19 variants, management's judgments could change. While our results of operations, cash flows and financial condition could be negatively impacted, the extent of any continuing impact cannot be estimated with certainty at this time.

[0001783180-23-000012:mdna:20]
RESULTS OF OPERATIONS

[0001783180-23-000012:mdna:21]
This discussion summarizes the significant factors affecting our consolidated results of operations, financial condition and liquidity for the year ended December 31, 2022 compared with December 31, 2021. This discussion should be read in conjunction with Item 8, the Consolidated Financial Statements and the accompanying Notes to the Consolidated Financial Statements in this Annual Report on Form 10-K. A detailed discussion of the year ended December 31, 2021 compared with December 31, 2020 is not included herein and can be found in the Management's Discussion and Analysis of Financial Condition and Results of Operations section in the Company's 2021 Annual Report on Form 10-K, filed with the SEC on February 8, 2022, under the heading "Results of Operations," which is incorporated herein by reference.

[0001783180-23-000012:mdna:22]
Year Ended December 31, 2022 Compared with Year Ended December 31, 2021

[0001783180-23-000012:mdna:23]
As a result of the Chubb Sale, we do not have any remaining ownership interest in Chubb and no longer consolidate Chubb in our financial statements as of January 3, 2022. Therefore, this Management’s Discussion and Analysis of Financial Condition and Results of Operations only includes the financial results of Chubb in periods prior to the date of sale. As a result, prior period results may not be comparable to the current period.

[0001783180-23-000012:mdna:24]
The results of TCC's operations are included in our consolidated results since the acquisition date of August 1, 2022. Prior to the acquisition, we accounted for our minority ownership in TCC under the equity method of accounting and recognized our portion of earnings within Equity method investment in net earnings as part of operating expenses. As a result, prior period results may not be comparable to the current period.

[0001783180-23-000012:mdna:25]
The following represents our consolidated net sales and operating results:

[0001783180-23-000012:mdna:26]
| (In millions) | 2022 |  | 2021 |  | Period Change |  | % Change |  |  |
| Net sales | $ | 20,421 |  |  | $ | 20,613 |  |  | $ | (192) |  |  | (1) | % |  |  |
| Cost of products and services sold | (14,957) |  |  | (14,633) |  |  | (324) |  |  | 2 | % |  |  |
| Gross margin | 5,464 |  |  | 5,980 |  |  | (516) |  |  | (9) | % |  |  |
| Operating expenses | (949) |  |  | (3,335) |  |  | 2,386 |  |  | (72) | % |  |  |
| Operating profit | 4,515 |  |  | 2,645 |  |  | 1,870 |  |  | 71 | % |  |  |
| Non-operating income (expense), net | (223) |  |  | (245) |  |  | 22 |  |  | (9) | % |  |  |
| Income from operations before income taxes | 4,292 |  |  | 2,400 |  |  | 1,892 |  |  | 79 | % |  |  |
| Income tax expense | (708) |  |  | (699) |  |  | (9) |  |  | 1 | % |  |  |
| Net income from operations | 3,584 |  |  | 1,701 |  |  | 1,883 |  |  | 111 | % |  |  |
| Less: Non-controlling interest in subsidiaries' earnings from operations | 50 |  |  | 37 |  |  | 13 |  |  | 35 | % |  |  |
| Net income attributable to common shareowners | $ | 3,534 |  |  | $ | 1,664 |  |  | $ | 1,870 |  |  | 112 | % |  |  |

[0001783180-23-000012:mdna:27]
Net Sales

[0001783180-23-000012:mdna:28]
For the year ended December 31, 2022, Net sales was $20.4 billion, a 1% decrease compared with the same period of 2021. The components of the year-over-year change were as follows:

[0001783180-23-000012:mdna:29]
|  | 2022 |  |
| Organic / Operational | 8 | % |  |
| Foreign currency translation | (3) | % |  |
| Acquisitions and divestitures, net | (6) | % |  |
| Total % change | (1) | % |  |

[0001783180-23-000012:mdna:30]
Organic sales for the year ended December 31, 2022 increased by 8% compared with the same period of 2021. We continue to benefit from the demand for energy-efficient, digital products and healthy building solutions. In addition, pricing improvements more than offset inflationary impacts in each of our segments. The organic increase was primarily driven by our HVAC segment due to pricing improvements in our North America residential and light commercial business and improved global end-markets in our Commercial HVAC business. Refrigeration results were flat as each of the segment's businesses experienced challenges in certain end markets during the second half of the year. Pricing improvements in our Fire & Security segment were the primary driver of growth compared with the prior year while supply chain and logistics constraints continue to be challenging. Refer to "Segment Review" below for a discussion of Net sales by segment.

[0001783180-23-000012:mdna:31]
Gross Margin

[0001783180-23-000012:mdna:32]
For the year ended December 31, 2022, gross margin was $5.5 billion, a 9% decrease compared with the same period of 2021. The components were as follows:

[0001783180-23-000012:mdna:33]
| (In millions) | 2022 |  | 2021 |  |  |  |  |  |  |
| Net sales | $ | 20,421 |  |  | $ | 20,613 |  |  |  |  |  |  |  |
| Cost of products and services sold | (14,957) |  |  | (14,633) |  |  |  |  |  |  |  |
| Gross margin | $ | 5,464 |  |  | $ | 5,980 |  |  |  |  |  |  |  |
| Percentage of net sales | 26.8 | % |  | 29.0 | % |  |  |  |  |  |  |

[0001783180-23-000012:mdna:34]
Gross margin decreased by $516 million compared with the year ended December 31, 2021. A main driver of the decrease related to incremental costs of products and services sold associated with TCC since the date of acquisition, which included inventory step-up, backlog amortization and intangible asset amortization resulting from the recognition of acquired assets at fair value. These costs had a 50 basis point impact on gross margin as a percentage of Net sales. In addition, each of our segments continue to be impacted by the higher cost of commodities and components used in our products, certain supply chain constraints and higher freight costs. However, these impacts were partially offset by ongoing customer demand, pricing improvements and our continued focus on productivity initiatives. Although pricing improvements more than offset inflationary impacts and supply chain challenges, gross margin as a percentage of Net sales decreased by 220 basis points compared with the same period of 2021.

[0001783180-23-000012:mdna:35]
Operating Expenses

[0001783180-23-000012:mdna:36]
For the year ended December 31, 2022, operating expenses, including Equity method investment net earnings, was $0.9 billion, a 72% decrease compared with the same period of 2021. The components were as follows:

[0001783180-23-000012:mdna:37]
|  | For the Year Ended December 31, |  |  |
| (In millions) | 2022 |  | 2021 |  |  |
| Selling, general and administrative | $ | (2,512) |  |  | $ | (3,120) |  |  |  |
| Research and development | (539) |  |  | (503) |  |  |  |
| Equity method investment net earnings | 262 |  |  | 249 |  |  |  |
| Other income (expense), net | 1,840 |  |  | 39 |  |  |  |
| Operating expenses | $ | (949) |  |  | $ | (3,335) |  |  |  |
| Percentage of net sales | 4.6 | % |  | 16.2 | % |  |  |

[0001783180-23-000012:mdna:38]
For the year ended December 31, 2022, Selling, general and administrative expenses were $2.5 billion, a 19% decrease compared with the same period of 2021. The decrease is primarily due to the Chubb Sale on January 3, 2022. In addition, lower restructuring charges and the benefit provided by changes in the fair value of cash-settled equity awards further contributed to the decrease. These amounts were partially offset by incremental selling, general and administrative expenses associated with TCC since the date of acquisition and $31 million of acquisition-related costs. The year ended December 31, 2021 included $43 million of costs related to the Chubb Sale and $20 million of costs related to the Separation.

[0001783180-23-000012:mdna:39]
Research and development costs relate to new product development and new technology innovation. Due to the variable nature of program development schedules, year-over-year spending levels can fluctuate. In addition, we continue to invest to prepare for future energy efficiency and refrigerant regulation changes and in digital controls technologies.

[0001783180-23-000012:mdna:40]
Investments over which we do not exercise control, but have significant influence, are accounted for using the equity method of accounting. For the year ended December 31, 2022, Equity method investment net earnings were $262 million, a 5% increase compared with the same period of 2021. The increase was primarily related to a $27 million gain on the sale of two minority owned subsidiaries by one of our joint ventures. In addition, higher earnings in HVAC joint ventures in Asia and North America further benefited earnings. These amounts were partially offset by the increase in our ownership interest in TCC on August 1, 2022. As a result, TCC is no longer accounted for under the equity method of accounting since the date of acquisition.

[0001783180-23-000012:mdna:41]
Other income (expense), net primarily includes the impact of gains and losses related to the sale of interests in our equity method investments, foreign currency gains and losses on transactions that are denominated in a currency other than an entity's functional currency and hedging-related activities.  In connection with the TCC acquisition, the carrying value of our previously held TCC equity investments were recognized at fair value at the date of acquisition. As a result, we recognized a $705 million non-cash gain associated with the increase in our ownership interest. In addition, we completed the Chubb Sale and recognized a net gain on the sale of $1.1 billion during the twelve months ended December 31, 2022.

[0001783180-23-000012:mdna:42]
Non-Operating Income (Expense), net

[0001783180-23-000012:mdna:43]
For the year ended December 31, 2022, Non-operating income (expense), net was $223 million, a 9% decrease compared with the same period of 2021. The components were as follows:

[0001783180-23-000012:mdna:44]
|  | For the Year Ended December 31, |  |
| (In millions) | 2022 |  | 2021 |  |
| Non-service pension benefit (expense) | $ | (4) |  |  | $ | 61 |  |  |
| Interest expense | (302) |  |  | (319) |  |  |
| Interest income | 83 |  |  | 13 |  |  |
| Interest (expense) income, net | (219) |  |  | (306) |  |  |
| Non-operating income (expense), net | $ | (223) |  |  | $ | (245) |  |  |

[0001783180-23-000012:mdna:45]
Non-operating income (expense), net includes the results from activities other than normal business operations such as interest expense, interest income and the non-service components of pension and post-retirement obligations. Interest expense is affected by the amount of debt outstanding and the interest rates on that debt. For the year ended December 31, 2022, interest expense was $302 million, a 5% decrease compared with the same period of 2021. During the year ended December 31, 2022, we completed tender offers to repurchase approximately $1.15 billion aggregate principal of our 2.242% Notes due 2025 and 2.493% Notes due 2027. Upon settlement, we wrote off $5 million of unamortized deferred financing costs in Interest expense and recognized a net gain of $33 million in Interest income. During the year ended December 31, 2021, we incurred a make-whole premium of $17 million and write-off of $2 million of unamortized deferred financing costs as a result of the redemption of our $500 million 1.923% Notes originally due in February 2023.

[0001783180-23-000012:mdna:46]
Income Taxes

[0001783180-23-000012:mdna:47]
|  |  | 2022 |  | 2021 |  |  |
| Effective tax rate |  | 16.5 | % |  | 29.1 | % |  |  |

[0001783180-23-000012:mdna:48]
The effective tax rate for the year ended December 31, 2022 was lower than our statutory U.S. federal income tax rate. The decrease was driven by a lower effective tax rate on the $705 million non-cash gain resulting from the recognition of our previously held TCC equity investments at fair value upon acquisition of TCC, a lower effective tax rate on the $1.1 billion Chubb gain and $45 million of foreign tax credits generated and utilized in the current year. The effective tax rate for the year ended December 31, 2021 was higher than our statutory U.S. federal income tax rate. The increase was driven by a net tax charge of $157 million primarily relating to the re-organization and disentanglement of certain Chubb subsidiaries executed in advance of the planned divestiture of Chubb and a $43 million deferred tax charge as a result of the tax rate increase from 19% to 25% in the United Kingdom. These amounts were partially offset by a favorable tax adjustment of $70 million due to foreign tax credits generated and expected to be utilized in the current year and $21 million resulting from the re-organization of a German subsidiary.

[0001783180-23-000012:mdna:49]
Segment Review

[0001783180-23-000012:mdna:50]
We conduct our operations through three reportable segments:

[0001783180-23-000012:mdna:51]
•The HVAC segment provides products, controls, services and solutions to meet the heating, cooling and ventilation needs of residential and commercial customers while enhancing building performance, health, energy efficiency and sustainability.

[0001783180-23-000012:mdna:52]
•The Refrigeration segment includes transport refrigeration and monitoring products, services and digital solutions for trucks, trailers, shipping containers, intermodal and rail, as well as commercial refrigeration products.

[0001783180-23-000012:mdna:53]
•The Fire & Security segment provides a wide range of residential, commercial and industrial technologies designed to help protect people and property.

[0001783180-23-000012:mdna:54]
We determine our segments based on how our Chief Executive Officer, who is the Chief Operating Decision Maker (the "CODM"), allocates resources, assesses performance and makes operational decisions. The CODM allocates resources and evaluates the financial performance of each of our segments based on Net sales and Operating profit. Adjustments to reconcile segment reporting to the consolidated results are included in Note 21 - Segment Financial Data.

[0001783180-23-000012:mdna:55]
Summary performance for each of our segments is as follows:

[0001783180-23-000012:mdna:56]
|  | Net Sales |  | Operating Profit |  | Operating Margin |
| (In millions) | 2022 |  | 2021 |  |  |  | 2022 |  | 2021 |  |  |  | 2022 |  | 2021 |  |  |
| HVAC | $ | 13,408 |  |  | $ | 11,390 |  |  |  |  | $ | 2,610 |  |  | $ | 1,738 |  |  |  |  | 19.5 | % |  | 15.3 | % |  |  |
| Refrigeration | 3,883 |  |  | 4,127 |  |  |  |  | 483 |  |  | 476 |  |  |  |  | 12.4 | % |  | 11.5 | % |  |  |
| Fire & Security | 3,570 |  |  | 5,515 |  |  |  |  | 1,630 |  |  | 662 |  |  |  |  | 45.7 | % |  | 12.0 | % |  |  |
| Total segment | $ | 20,861 |  |  | $ | 21,032 |  |  |  |  | $ | 4,723 |  |  | $ | 2,876 |  |  |  |  | 22.6 | % |  | 13.7 | % |  |  |

[0001783180-23-000012:mdna:57]
HVAC Segment

[0001783180-23-000012:mdna:58]
For the year ended December 31, 2022, Net sales in our HVAC segment was $13.4 billion, an 18% increase compared with the same period of 2021. The components of the year-over-year change were as follows:

[0001783180-23-000012:mdna:59]
|  | Net sales |
| Organic / Operational | 12 | % |
| Foreign currency translation | (2) | % |
| Acquisitions and divestitures, net | 8 | % |
| Total % change | 18 | % |

[0001783180-23-000012:mdna:60]
The organic increase in Net sales of 12% was driven by continued strong results across each of the segment's businesses. Increased sales in our North America residential and light commercial business (up 14%) were primarily driven by pricing improvements and end market demand. These amounts were partially offset by volume reductions in certain end markets. Increased sales in our Commercial HVAC business (up 9%) benefited from pricing improvements and ongoing customer demand in our end-markets. The business saw growth in North America and Asia while growth in Europe was tempered by current economic conditions and inflationary cost pressures which impacted end-market demand. Increased sales in our Global Comfort Solutions business (up 8%) were primarily driven by pricing improvements. While current demand remains strong, supply chain and logistics constraints continue to be challenging, negatively impacting our sales and results of operations. In addition, results for 2021 reflected a significant rebound in demand after initial weakness associated with the COVID-19 pandemic.

[0001783180-23-000012:mdna:61]
On August 1, 2022, the Commercial HVAC business acquired a majority ownership interest in TCC, a VRF and light commercial HVAC joint venture between Carrier and Toshiba Corporation. The results of TCC have been included in our Consolidated Financial Statements since the date of acquisition. The transaction added 7% to Net sales for the year ended December 31, 2022 and is included in Acquisitions and divestitures, net.

[0001783180-23-000012:mdna:62]
35

[0001783180-23-000012:mdna:63]
On June 1, 2021, the Commercial HVAC business acquired a 70% controlling interest in Guangdong Giwee Group and its subsidiaries ("Giwee") and subsequently acquired the remaining 30% ownership interest on September 7, 2021. Giwee is a China-based manufacturer offering a portfolio of HVAC products including variable refrigerant flow, modular chillers and light commercial air conditioners. The results of Giwee have been included in our Consolidated Financial Statements since the date of acquisition. The transaction added 1% to Net sales during the year ended December 31, 2022 and is included in Acquisitions and divestitures, net.

[0001783180-23-000012:mdna:64]
For the year ended December 31, 2022, Operating profit in our HVAC segment was $2.6 billion, a 50% increase compared with the same period of 2021. The components of the year-over-year change were as follows:

[0001783180-23-000012:mdna:65]
|  | Operating profit |
| Organic / Operational | 10 | % |
| Foreign currency translation | (1) | % |
| Acquisitions and divestitures, net | (1) | % |
| Restructuring | 1 | % |
| Other | 41 | % |
| Total % change | 50 | % |

[0001783180-23-000012:mdna:66]
The operational profit increase of 10% was primarily attributable to pricing improvements compared with the prior year. Higher earnings from equity method investments in Asia and North America also benefited operational profit and included a $27 million gain on the sale of two minority owned subsidiaries by one of our joint ventures. These amounts were partially offset by the increase in our ownership interest in TCC on August 1, 2022. As a result, TCC is no longer accounted for under the equity method of accounting since the date of acquisition. In addition, productivity initiatives provided further benefits to operational profit. These amounts were partially offset by the higher costs of commodities and components used in our products as well as higher freight and logistics costs.

[0001783180-23-000012:mdna:67]
In connection with the TCC acquisition, the carrying value of our previously held TCC equity investments were recognized at fair value at the date of acquisition. As a result, we recognized a $705 million non-cash gain associated with the increase in our ownership interest in Other. In addition, amounts reported in Other include a $22 million charge resulting from a litigation matter recognized during the year ended December 31, 2022.

[0001783180-23-000012:mdna:68]
Refrigeration Segment

[0001783180-23-000012:mdna:69]
For the year ended December 31, 2022, Net sales in our Refrigeration segment was $3.9 billion, a 6% decrease compared with the same period of 2021. The components of the year-over-year change were as follows:

[0001783180-23-000012:mdna:70]
|  | Net sales |
| Organic / Operational | — | % |
| Foreign currency translation | (6) | % |
| Total % change | (6) | % |

[0001783180-23-000012:mdna:71]
Organic Net sales were flat compared to the prior year as each of the segment's businesses experienced challenges in certain end markets during the second half of the year. Results for Commercial refrigeration were flat compared with the prior year, primarily driven by continued supply chain constraints and lower volumes in Europe as economic conditions and inflationary cost pressures impacted end-market demand. In addition, ongoing growth in Asia was more than offset by fourth quarter COVID-19 impacts. These impacts were offset by pricing improvements. Transport refrigeration sales were flat compared to the prior year as pricing improvements and strong end market demand in the U.S. and Europe were offset by continued weakness in the marine sector. The year ended December 31, 2021 reflected a significant rebound in demand associated with the cyclical decline that began in late 2019 as well as the demand for global transportation and COVID-19 vaccine-related cargo monitoring. In addition, supply chain and logistics constraints continue to be challenging, negatively impacting our sales and results of operations.

[0001783180-23-000012:mdna:72]
For the year ended December 31, 2022, Operating profit in our Refrigeration segment was $483 million, a 2% increase compared with the same period of 2021. The components of the year-over-year change were as follows:

[0001783180-23-000012:mdna:73]
|  | Operating profit |
| Organic / Operational | 5 | % |
| Foreign currency translation | (7) | % |
| Restructuring | 3 | % |
| Other | 1 | % |
| Total % change | 2 | % |

[0001783180-23-000012:mdna:74]
The increase in operational profit of 5% was primarily attributable to pricing improvements compared with the prior year. In addition, favorable productivity initiatives and lower selling, general and administrative costs further benefited operational profit. These amounts were partially offset by the higher costs of commodities and components used in our products and higher freight and logistic costs.

[0001783180-23-000012:mdna:75]
Fire & Security Segment

[0001783180-23-000012:mdna:76]
For the year ended December 31, 2022, Net sales in our Fire & Security segment was $3.6 billion, a 35% decrease compared with the same period of 2021. The components of the year-over-year change were as follows:

[0001783180-23-000012:mdna:77]
|  | Net sales |  |  |
| Organic / Operational | 5 | % |  |  |
| Foreign currency translation | (2) | % |  |  |
| Acquisitions and divestitures, net | (38) | % |  |  |
| Total % change | (35) | % |  |  |

[0001783180-23-000012:mdna:78]
The organic increase in Net sales of 5% was primarily driven by pricing improvements compared with the prior year. The segment primarily saw growth in both residential and commercial sales in the Americas and Europe as sales in China decreased as a result of current economic conditions and reduced end-market demand. Global industrial sales also benefited segment results with pricing improvements and strong demand. Results for 2021 reflected a significant rebound in demand after initial weakness associated with the COVID-19 pandemic. In addition, supply chain constraints continue to be challenging, negatively impacting our sales and results of operations.

[0001783180-23-000012:mdna:79]
Acquisitions and divestitures, net primarily relates to the prior year results of our Chubb business, the sale of which was completed on January 3, 2022. During the year ended December 31, 2021, Net sales in our Fire & Security segment were $5.5 billion, which included $2.2 billion from our Chubb business. Absent the results of Chubb, Net sales increased 6% from $3.3 billion to $3.6 billion.

[0001783180-23-000012:mdna:80]
For the year ended December 31, 2022, Operating profit in our Fire & Security segment was $1.6 billion, a 146% increase compared with the same period of 2021. The components of the year-over-year change were as follows:

[0001783180-23-000012:mdna:81]
|  |  |  | Operating profit |
| Organic / Operational |  |  | (5) | % |
| Foreign currency translation |  |  | (2) | % |
| Acquisitions and divestitures, net |  |  | (15) | % |
| Restructuring |  |  | 2 | % |
| Other |  |  | 166 | % |
| Total % change |  |  | 146 | % |

[0001783180-23-000012:mdna:82]
The operational profit decrease of 5% was primarily attributable to the higher costs of commodities and components used in our products and higher freight and logistics costs. In addition, unfavorable mix and lower volumes further impacted results

[0001783180-23-000012:mdna:83]
37

[0001783180-23-000012:mdna:84]
compared with the prior year. These amounts were partially offset by pricing improvements and favorable productivity initiatives.

[0001783180-23-000012:mdna:85]
Acquisitions and divestitures, net primarily relates to the prior year results of our Chubb business, the sale of which was completed on January 3, 2022. Amounts reported during the year ended December 31, 2021 include $42 million of transaction costs associated with the divestiture. Amounts reported in Other represent the net gain on the Chubb Sale of $1.1 billion.

[0001783180-23-000012:mdna:86]
LIQUIDITY AND FINANCIAL CONDITION

[0001783180-23-000012:mdna:87]
We assess liquidity in terms of our ability to generate adequate amounts of cash necessary to fund our current and future cash requirements to support our business and strategic initiatives. In doing so, we review and analyze our cash on hand, working capital, debt service requirements and capital expenditures. We rely on operating cash flows as our primary source of liquidity. In addition, we have access to other sources of capital to finance our strategic initiatives and fund growth.

[0001783180-23-000012:mdna:88]
As of December 31, 2022, we had cash and cash equivalents of $3.5 billion, of which approximately 42% was held by our foreign subsidiaries. We manage our worldwide cash requirements by reviewing available funds and the cost effectiveness with which we can access funds held by foreign subsidiaries. On occasion, we are required to maintain cash deposits in connection with contractual obligations related to acquisitions or divestitures or other legal obligations. As of December 31, 2022 and 2021, the amount of such restricted cash was $7 million and $39 million, respectively.

[0001783180-23-000012:mdna:89]
We maintain a $2.0 billion unsecured, unsubordinated commercial paper program which we can use for general corporate purposes, including working capital and potential acquisitions. In addition, we maintain our $2.0 billion revolving credit agreement with various banks (the "Revolving Credit Facility") that matures on April 3, 2025 which supports our commercial paper borrowing program and cash requirements. The Revolving Credit Facility has a commitment fee of 0.125% that is charged on the unused commitments. Borrowings under the Revolving Credit Facility are available in U.S. Dollars, Euros and Pounds Sterling and bear interest at a variable interest rate plus a ratings-based margin, which was 125 basis points as of December 31, 2022. As of December 31, 2022, we had no borrowings outstanding under our commercial paper program and our Revolving Credit Facility.

[0001783180-23-000012:mdna:90]
We believe that our available cash and operating cash flows will be sufficient to meet our future operating cash needs. Our committed credit facilities and access to the debt and equity markets provide additional sources of short-term and long-term capital to fund current operations, debt maturities and future investment opportunities. Although we believe that the arrangements currently in place permit us to finance our operations on acceptable terms and conditions, our access to and the availability of financing on acceptable terms and conditions in the future will be impacted by many factors, including: (1) our credit ratings or absence of credit ratings; (2) the liquidity of the overall capital markets; and (3) the state of the economy, including the impact of the COVID-19 pandemic. There can be no assurance that we will be able to obtain additional financing on terms favorable to us, if at all.

[0001783180-23-000012:mdna:91]
The following table contains several key measures of our financial condition and liquidity:

[0001783180-23-000012:mdna:92]
|  |  | As of December 31, |
| (In millions) |  | 2022 |  | 2021 |
| Cash and cash equivalents |  | $ | 3,520 |  |  | $ | 2,987 |  |
| Total debt |  | $ | 8,842 |  |  | $ | 9,696 |  |
| Net debt (total debt less cash and cash equivalents) |  | $ | 5,322 |  |  | $ | 6,709 |  |
| Total equity |  | $ | 8,076 |  |  | $ | 7,094 |  |
| Total capitalization (total debt plus total equity) |  | $ | 16,918 |  |  | $ | 16,790 |  |
| Net capitalization (total debt plus total equity less cash and cash equivalents) |  | $ | 13,398 |  |  | $ | 13,803 |  |
| Total debt to total capitalization |  | 52 | % |  | 58 | % |
| Net debt to net capitalization |  | 40 | % |  | 49 | % |

[0001783180-23-000012:mdna:93]
Borrowings and Lines of Credit

[0001783180-23-000012:mdna:94]
Our short-term obligations primarily consist of current maturities of long-term debt. Our long-term obligations primarily consist of long-term notes with maturity dates ranging between 2025 and 2050. Interest payments related to long-term notes are

[0001783180-23-000012:mdna:95]
expected to approximate $249 million per year, reflecting an approximate weighted-average interest rate of 2.85%. Any borrowings from the Revolving Credit Facility are subject to variable interest rates. See Note 7 - Borrowings and Lines of Credit in the accompanying Notes to the Consolidated Financial Statements in this Annual Report on Form 10-K for additional information regarding the terms of our long-term debt obligations.

[0001783180-23-000012:mdna:96]
Scheduled maturities of long-term debt, excluding amortization of discount, are as follows:

[0001783180-23-000012:mdna:97]
| (In millions) |  |  |  |
| 2023 |  | $ | 140 |  |  |
| 2024 |  | $ | 2 |  |  |
| 2025 |  | $ | 1,202 |  |  |
| 2026 |  | $ | 2 |  |  |
| 2027 |  | $ | 1,306 |  |  |
| Thereafter |  | $ | 6,251 |  |  |

[0001783180-23-000012:mdna:98]
On March 15, 2022, we commenced tender offers to repurchase up to $1.15 billion aggregate principal of our 2.242% Notes due 2025 and 2.493% Notes due 2027. The tender offers included payment of applicable accrued and unpaid interest up to the settlement date, along with a fixed spread for early repayment. Based on participation, we elected to settle the tender offers on March 30, 2022. The aggregate principal amount of Senior Notes validly tendered and accepted was approximately $1.15 billion and included $800 million of Notes due 2025 and $350 million of Notes due 2027. Upon settlement, we recognized a net gain of $33 million and wrote off $5 million of unamortized deferred financing costs during the three months ended March 31, 2022.

[0001783180-23-000012:mdna:99]
On July 15, 2022, we entered into a five-year, JPY 54 billion (approximately $400 million) senior unsecured term loan facility with MUFG Bank Ltd., as administrative agent and lender, and certain other lenders (the "Japanese Term Loan Facility"). Borrowings bear interest at a rate equal to the Tokyo Term Risk Free Rate plus 0.75%. In addition, it is subject to customary covenants including a covenant to maintain a maximum consolidated leverage ratio. On July 25, 2022, we borrowed JPY 54 billion under the Japanese Term Loan Facility and used the proceeds to fund a portion of the TCC acquisition and to pay related fees and expenses.

[0001783180-23-000012:mdna:100]
The Revolving Credit Facility, the Japanese Term Loan Facility and the indentures for our long-term notes contain affirmative and negative covenants customary for financings of this type, which among other things, limit our ability to incur additional liens, to make certain fundamental changes and to enter into sale and leaseback transactions. As of December 31, 2022, we were compliant with the covenants under the agreements governing our outstanding indebtedness.

[0001783180-23-000012:mdna:101]
The following table presents our credit ratings and outlook as of December 31, 2022:

[0001783180-23-000012:mdna:102]
| Rating Agency | Long-term Rating (1) | Short-term Rating |  | Outlook (2) |
| S&P | BBB | A2 |  | Positive |
| Moody's | Baa3 | P3 |  | Stable |
| Fitch Ratings | BBB- | F3 |  | Stable |

[0001783180-23-000012:mdna:103]
(1) The long-term rating for S&P was affirmed on May 14, 2021, and for Moody's on March 30, 2022. Fitch Ratings' long-term rating was issued on June 3, 2021.

[0001783180-23-000012:mdna:104]
(2) S&P revised its outlook to positive from stable on May 20, 2022.

[0001783180-23-000012:mdna:105]
Acquisitions and Divestitures

[0001783180-23-000012:mdna:106]
On January 3, 2022, we completed the Chubb Sale for net proceeds of $2.9 billion. Consistent with our capital allocation strategy, the net proceeds will be used to fund investments in organic and inorganic growth initiatives and capital returns to shareowners as well as for general corporate purposes.

[0001783180-23-000012:mdna:107]
On February 6, 2022, we entered into a binding agreement to acquire a majority ownership interest in TCC for $930 million, less cash acquired. The transaction was completed on August 1, 2022 and funded through the Japanese Term Loan Facility and cash on hand. Upon closing, Toshiba Corporation retained a 5% ownership interest in TCC. In addition, during the year ended December 31, 2022, we acquired other consolidated businesses and minority-owned businesses. The aggregate cash paid for these acquisitions, net of cash acquired, totaled $77 million and was funded through cash on hand.

[0001783180-23-000012:mdna:108]
39

[0001783180-23-000012:mdna:109]
Share Repurchase Program

[0001783180-23-000012:mdna:110]
We may purchase our outstanding common stock from time to time subject to market conditions and at our discretion. Repurchases occur in the open market or through one or more other public or private transactions pursuant to plans complying with Rules 10b5-1 and 10b-18 under the Exchange Act. In July 2021, our Board of Directors approved a $1.75 billion increase to our existing $350 million share repurchase program authorizing the repurchase of up to $2.1 billion of our outstanding common stock. In October 2022, our Board of Directors approved an additional $2.0 billion increase to our existing $2.1 billion share repurchase program. Since inception, we repurchased 42.1 million shares of our common stock for an aggregate purchase price of $1.9 billion. As of December 31, 2022, we have approximately $2.2 billion remaining under the current authorization.

[0001783180-23-000012:mdna:111]
Dividends

[0001783180-23-000012:mdna:112]
We paid dividends on our common stock of $0.60 per share during the year ended December 31, 2022, totaling $509 million. On December 7, 2022, the Board of Directors declared a dividend of $0.185 per share of common stock which represents a 23% increase over the prior quarterly dividend. It is payable on February 10, 2023 to shareowners of record at the close of business on December 22, 2022.

[0001783180-23-000012:mdna:113]
Discussion of Cash Flows

[0001783180-23-000012:mdna:114]
|  |  | For the Years Ended December 31, |
| (In millions) |  | 2022 |  | 2021 |  |  |
| Cash provided by (used in): |  |  |  |  |  |  |
| Operating activities |  | $ | 1,743 |  |  | $ | 2,237 |  |  |  |
| Investing activities |  | 1,745 |  |  | (692) |  |  |  |
| Financing activities |  | (2,931) |  |  | (1,562) |  |  |  |
| Effect of foreign exchange rate changes on cash and cash equivalents |  | (56) |  |  | (16) |  |  |  |
| Net increase (decrease) in cash and cash equivalents and restricted cash |  | $ | 501 |  |  | $ | (33) |  |  |  |

[0001783180-23-000012:mdna:115]
Cash flows from operating activities primarily represent inflows and outflows associated with our operations. Primary activities include net income from operations adjusted for non-cash transactions, working capital changes and changes in other assets and liabilities. We define working capital as the assets and liabilities, other than cash, generated through our primary operating activities. The year-over-year decrease in net cash provided by operating activities was driven by higher working capital balances. Ongoing customer demand and an increase in safety stock led to higher inventory balances. In addition, higher account receivable balances more than offset higher accounts payable balances.

[0001783180-23-000012:mdna:116]
Cash flows from investing activities primarily represent inflows and outflows associated with long-term assets. Primary activities include capital expenditures, acquisitions, divestitures and proceeds from the sale of fixed assets. During the year ended December 31, 2022, net cash provided by investing activities was $1.7 billion. The primary driver of the inflow related to the net proceeds from the Chubb Sale. This amount was partially offset by the acquisition of TCC and several other businesses and minority-owned businesses, which totaled $506 million, net of cash acquired and $353 million of capital expenditures. During the year ended December 31, 2021, net cash used in investing activities was $692 million. The primary driver of the outflow related to the acquisition of several businesses and a minority-owned business, which totaled $366 million, net of cash acquired and $344 million of capital expenditures.

[0001783180-23-000012:mdna:117]
Cash flows from financing activities primarily represent inflows and outflows associated with equity or borrowings. Primary activities include debt transactions, paying dividends to shareowners and the repurchase of our common stock. During the year ended December 31, 2022 net cash used in financing activities was $2.9 billion. The primary driver of the outflow related to the payment of $1.4 billion to repurchase shares of our common stock. In addition, we settled our tender offers for $1.15 billion and paid $509 million in dividends to our common shareowners. During the year ended December 31, 2021 net cash used in financing activities was $1.6 billion. The primary drivers of the outflow resulted from the repurchase of $527 million of our common stock, the redemption of our 1.923% Notes of $500 million and the payment of $417 million in dividends to our common shareowners.

[0001783180-23-000012:mdna:118]
40

[0001783180-23-000012:mdna:119]
Summary of Other Sources and Uses of Cash

[0001783180-23-000012:mdna:120]
We continue to actively manage and strengthen our business and product portfolio to meet the current and future needs of our customers. This is accomplished through research and development activities with a focus on new product development and new technology innovation as well as sustaining activities with a focus on improving existing products and reducing production costs. We also pursue potential acquisitions to complement existing products and services to enhance our product portfolio. In addition, we routinely conduct discussions, evaluate targets and enter into agreements regarding possible acquisitions, divestitures, joint ventures and equity investments to manage our business portfolio.

[0001783180-23-000012:mdna:121]
Rapid changes in legislation, regulations and government policies, including with respect to regulations intended to combat climate change, affect our operations and business in the countries, regions and localities in which we operate and sell our products. We are committed to comply with these regulations and to environmental stewardship. As a result, we have set goals to invest over $2 billion by 2030 to develop healthy, safe, sustainable and intelligent buildings and cold chain solutions that incorporate sustainable design principles and reduce lifecycle impacts. In addition, to reach our goal to achieve carbon neutrality in our operations by 2030, we expect to incur capital expenditures for climate-related projects including upgrading our facilities, equipment and controls to optimize energy efficiency, transition our energy consumption from a dependency on fossil fuels to renewable energy and expanding the electrification of our fleet vehicles. See section entitled Environmental Goals under the headings "Other Matters Relating to Our Business as a Whole" for additional information.

[0001783180-23-000012:mdna:122]
We also have obligations related to environmental and asbestos matters, pension and post-retirement benefits and taxes. See Note 10 - Employee Benefit Plans, Note 17 - Income Taxes, and Note 23 - Commitments and Contingent Liabilities in the accompanying Notes to the Consolidated Financial Statements in this Annual Report on Form 10-K for additional information.

[0001783180-23-000012:mdna:123]
CRITICAL ACCOUNTING ESTIMATES

[0001783180-23-000012:mdna:124]
Our financial statements are prepared in accordance with accounting principles generally accepted in the United States. The preparation of financial statements in conformity with those accounting principles requires management to use judgement in making estimates and assumptions based on the relevant information available at the end of each period. These estimates and assumptions have a significant effect on reported amounts of assets, liabilities, sales and expenses as well as the disclosure of contingent assets and liabilities because they result primarily from the need to make estimates and assumptions on matters that are inherently uncertain. Actual results could differ from management's estimates.

[0001783180-23-000012:mdna:125]
Goodwill and Indefinite-Lived Intangible Assets

[0001783180-23-000012:mdna:126]
In accordance with the Financial Accounting Standards Board ("FASB") Accounting Standards Codification ("ASC") 350, Intangibles - Goodwill and Other ("ASC 350"), goodwill and other indefinite-lived intangible assets are tested and reviewed annually for impairment or whenever there is a material change in events or circumstances that indicate that the fair value of the asset is more likely than not less than the carrying amount of the asset. We test our reporting units and indefinite-lived intangible assets for impairment annually as of the first day of our third quarter, or more frequently if events or circumstances occur.

[0001783180-23-000012:mdna:127]
ASC 350 provides entities with an option to perform a qualitative assessment (commonly referred to as “step zero”) to determine whether a quantitative analysis for impairment is necessary. In performing step zero for our impairment test, we are required to make assumptions and judgments, including but not limited to the following: the evaluation of macroeconomic conditions as related to our business, industry and market trends, and the overall future financial performance of our reporting units and future opportunities in the markets in which they operate. If impairment indicators are present after performing step zero, we would perform a quantitative impairment analysis to estimate fair value.

[0001783180-23-000012:mdna:128]
For our 2022 impairment test, we elected to perform a quantitative test on our Commercial HVAC reporting unit prior to the  TCC acquisition and the subsequent creation of a separate Global Comfort Solutions reporting unit. We utilized a discounted cash flow method under the income approach to estimate the fair value of the Commercial HVAC reporting unit prior to the reorganization, the results of which did not indicate any goodwill impairment. We then reassigned goodwill among our Commercial HVAC and Global Comfort Solutions reporting units using a relative fair value approach and performed a goodwill impairment assessment using a discounted cash flow method under the income approach to estimate the fair value of the reporting units. The results did not indicate any goodwill impairment. For each test, we relied on our estimates of future cash flows, long-term growth rates, discount rates and income tax rates and explicitly addressed factors such as timing, growth and margins with due consideration given to forecasting, market and geographic risk.

[0001783180-23-000012:mdna:129]
41

[0001783180-23-000012:mdna:130]
For the remaining goodwill and indefinite-lived intangible assets tests, we elected to perform qualitative step zero assessments to determine if it was more likely than not that the fair values of our reporting units and indefinite-lived intangible assets were below carrying value. We considered macroeconomic factors including global economic growth, general macroeconomic trends for the markets in which our reporting units operate and where the intangible assets are utilized and the forecasted growth of the global industrial products industry. In addition to these macroeconomic factors, among other things, we considered the reporting units’ current results and forecasts, changes in the nature of each business, any significant legal, regulatory, contractual, political or other business climate factors, changes in the industry and competitive environment, changes in the composition or carrying amount of net assets and any intention to sell or dispose of a reporting unit or cease the use of any indefinite-lived intangible assets. Based upon our qualitative analysis, we determined that our goodwill and indefinite-lived intangible assets were not impaired.

[0001783180-23-000012:mdna:131]
Revenue Recognition from Contracts with Customers

[0001783180-23-000012:mdna:132]
Revenue is recognized when control of a good or service promised in a contract (i.e., performance obligation) is transferred to a customer. Control is obtained when a customer has the ability to direct the use of and obtain substantially all of the remaining benefits from that good or service. A significant portion of our performance obligations are recognized at a point-in-time when control of the product transfers to the customer, which is generally the time of shipment. The remaining portion of our performance obligations are recognized over time as the customer simultaneously obtains control as we perform work under a contract, or if the product being produced for the customer has no alternative use and we have a contractual right to payment.

[0001783180-23-000012:mdna:133]
A performance obligation is a distinct good, service or a bundle of goods and services promised in a contract. Some of our contracts with customers contain a single performance obligation, while others contain multiple performance obligations most commonly when a contract spans multiple phases of a product life-cycle such as production, installation, maintenance and support. We identify performance obligations at the inception of a contract and allocate the transaction price to each distinct performance obligation. Revenue is recognized when or as the performance obligation is satisfied. When there are multiple performance obligations within a contract, we allocate the transaction price to each performance obligation based on its relative stand-alone selling price.

[0001783180-23-000012:mdna:134]
We primarily generate revenue from the sale of products to customers and recognize revenue at a point in time when control transfers to the customer. Transfer of control is generally based on the shipping terms of the contract. In addition, we recognize revenue on an over-time basis on installation and service contracts. For over-time performance obligations requiring the installation of equipment, revenue is recognized using costs incurred to date relative to total estimated costs at completion to measure progress. Incurred costs represent work performed, which correspond with and best depict transfer of control to the customer. Contract costs include direct costs such as labor, materials and subcontractors’ costs and, where applicable, indirect costs.

[0001783180-23-000012:mdna:135]
The transaction price allocated to performance obligations reflects our expectations about the consideration we will be entitled to receive from a customer. We include variable consideration in the estimated transaction price when there is a basis to reasonably estimate the amount and when it is probable that a significant reversal of revenue recognized would not occur when the uncertainty associated with variable consideration is subsequently resolved. In addition, we customarily offer our customers incentives to purchase products to ensure an adequate supply of our products in distribution channels. The principal incentive programs provide reimbursements to distributors for offering promotional pricing for products. We account for estimated incentive payments as a reduction in sales at the time a sale is recognized.

[0001783180-23-000012:mdna:136]
Income Taxes

[0001783180-23-000012:mdna:137]
We account for income taxes in accordance with ASC 740, Income Taxes ("ASC 740"). Deferred tax assets and liabilities are determined based on temporary differences between financial reporting and tax bases of assets and liabilities, applying enacted tax rates expected to be in effect for the year in which the differences are expected to reverse. We recognize future tax benefits to the extent that realizing these benefits is considered in our judgment to be more likely than not. For those jurisdictions where the expiration date of tax carryforwards or the projected operating results indicate that realization is not likely, a valuation allowance is provided. We review the realizability of our deferred tax asset valuation allowances on a quarterly basis, or whenever events or changes in circumstances indicate that a review is required and will adjust our estimate if significant events so dictate. To the extent that the ultimate results differ from our original or adjusted estimates, the effect will be recorded in the provision for income taxes in the period that the matter is finally resolved.

[0001783180-23-000012:mdna:138]
In the ordinary course of business, there is inherent uncertainty in quantifying our income tax positions. We assess our income tax positions and record tax benefits for all years subject to examination based upon management’s evaluation of the facts, circumstances and information available at the reporting date. For those tax positions where it is more likely than not that a tax benefit will be sustained, we have recorded the largest amount of tax benefit with a greater than 50% likelihood of being realized upon ultimate settlement with a taxing authority that has full knowledge of all relevant information. For those income tax positions where it is not more likely than not that a tax benefit will be sustained, no tax benefit has been recognized in the Consolidated Financial Statements.

[0001783180-23-000012:mdna:139]
Employee Benefit Plans

[0001783180-23-000012:mdna:140]
We provide a range of benefit plans to eligible current and former employees. We account for our benefits plans in accordance with ASC 715, Compensation – Retirement Benefits ("ASC 715"), which requires balance sheet recognition of the overfunded or underfunded status of pension plans. The determination of the amounts associated with these benefits is performed by actuaries and dependent on various actuarial assumptions including discount rates, expected return on plan assets, compensation increases, mortality and health care cost trends. Actual results may differ from the actuarial assumptions and are generally recorded in Accumulated other comprehensive income (loss) and amortized into Net income from operations over future periods. We review our actuarial assumptions at each measurement date and make modifications to the assumptions based on current rates and trends, if appropriate.

[0001783180-23-000012:mdna:141]
A change in any of these assumptions would have an effect on net periodic pension and post-retirement benefit costs reported in the Consolidated Financial Statements. The following table summarizes the estimated sensitivity of our 2022 projected benefit obligation and net periodic pension (benefit) cost to a 25 basis point change in the discount rate:

[0001783180-23-000012:mdna:142]
| (In millions) |  | Increase in Discount Rate of 25 bps |  | Decrease in Discount Rate of 25 bps |
| Projected benefit obligation |  | $ | (20) |  |  | $ | 21 |  |
| Net periodic pension (benefit) cost |  | $ | (1) |  |  | $ | 1 |  |

[0001783180-23-000012:mdna:143]
Net periodic pension (benefit) cost is also sensitive to changes in the expected return on plan assets. An increase or decrease of 25 basis points in the expected return on plan assets would have decreased or increased 2022 pension expense by approximately $1 million.

[0001783180-23-000012:mdna:144]
Contingent Liabilities

[0001783180-23-000012:mdna:145]
We are involved in various litigation, claims and administrative proceedings, including those related to environmental (including asbestos) and legal matters. In accordance with ASC 450, Contingencies ("ASC 450"), we record accruals for loss contingencies when it is probable that a liability will be incurred and the amount of the loss can be reasonably estimated. These accruals are generally based upon a range of possible outcomes. If no amount within the range is a better estimate than any other, we accrue the minimum amount. In addition, these estimates are reviewed periodically and adjusted to reflect additional information when it becomes available. We are unable to predict the final outcome of these matters based on the information currently available. However, we do not believe that the resolution of any of these matters will have a material adverse effect upon our competitive position, results of operations, cash flows or financial condition.

[0001783180-23-000012:mdna:146]
As described in Note 23 – Commitments and Contingent Liabilities in the accompanying Notes to the Consolidated Financial Statements in this Annual Report on Form 10-K, contractual, regulatory and other matters, including asbestos claims, may arise in the ordinary course of business that subject us to claims or litigation. We have recorded reserves in the consolidated financial statements related to these matters, which are developed using input derived from actuarial estimates and historical and anticipated experience depending on the nature of the reserve, and in certain instances in consultation with legal counsel, internal and external consultants and engineers. Subject to the uncertainties inherent in estimating future costs for these types of liabilities, we believe our estimated reserves are reasonable and do not believe the final determination of the liabilities with respect to these matters would have a material adverse effect upon our competitive position, results of operations, cash flows or financial condition. See the "Risk Factors" section in this Annual Report on Form 10-K for additional information.

[0001783180-23-000012:mdna:147]
Recent Accounting Pronouncements

[0001783180-23-000012:mdna:148]
See Note 3 – Summary of Significant Accounting Policies in the accompanying Notes to the Consolidated Financial Statements in this Annual Report on Form 10-K for a discussion of recent accounting pronouncements and their effect on our financial statements.
