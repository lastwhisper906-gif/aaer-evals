# CARR 8-K — 0001783180-23-000010 filed 2023-02-07

## item codes, every 8-K on or before 2023-02-07

- 2023-02-07 0001783180-23-000010 — 2.02, 9.01
- 2022-10-27 0001783180-22-000054 — 2.02, 7.01, 9.01
- 2022-09-29 0000950142-22-002805 — 5.02, 9.01
- 2022-07-28 0001783180-22-000045 — 2.02, 9.01
- 2022-04-28 0001783180-22-000032 — 2.02, 9.01
- 2022-04-15 0001783180-22-000024 — 5.07, 9.01
- 2022-02-08 0001783180-22-000008 — 2.02, 9.01
- 2022-02-07 0000950142-22-000510 — 8.01, 9.01
- 2022-01-03 0000950142-22-000023 — 8.01, 9.01
- 2021-12-17 0001783180-21-000071 — 5.02, 7.01, 9.01
- 2021-11-23 0001783180-21-000068 — 5.03, 9.01
- 2021-10-28 0001783180-21-000062 — 2.02, 9.01
- 2021-08-27 0001783180-21-000056 — 8.01
- 2021-07-30 0001783180-21-000053 — 1.01
- 2021-07-29 0001783180-21-000049 — 2.02, 8.01, 9.01
- 2021-07-27 0000950142-21-002448 — 8.01, 9.01
- 2021-07-15 0000950142-21-002362 — 5.02, 9.01
- 2021-06-09 0000950142-21-001885 — 5.02, 9.01
- 2021-04-29 0001783180-21-000029 — 2.02, 9.01
- 2021-04-22 0001140361-21-013889 — 5.02, 9.01
- 2021-04-20 0001783180-21-000021 — 5.07, 9.01
- 2021-04-19 0000950142-21-001308 — 8.01, 9.01
- 2021-02-09 0001783180-21-000009 — 2.02, 9.01
- 2021-02-05 0001140361-21-003513 — 8.01, 9.01
- 2020-12-23 0001140361-20-029419 — 7.01, 9.01
- 2020-12-22 0001140361-20-029097 — 8.01
- 2020-12-14 0001140361-20-028246 — 5.03, 9.01
- 2020-12-07 0001140361-20-027515 — 1.01, 7.01, 9.01
- 2020-10-29 0001783180-20-000063 — 2.02, 9.01
- 2020-10-19 0001140361-20-023241 — 5.02, 7.01, 9.01
- 2020-09-23 0001140361-20-021220 — 8.01, 9.01
- 2020-09-22 0001140361-20-021124 — 8.01, 9.01
- 2020-07-30 0001783180-20-000045 — 2.02, 9.01
- 2020-06-19 0001140361-20-014325 — 1.01, 2.03, 9.01
- 2020-06-16 0001140361-20-013880 — 8.01, 9.01
- 2020-06-03 0001140361-20-012939 — 1.01, 9.01
- 2020-05-08 0001783180-20-000013 — 2.02, 9.01
- 2020-04-03 0001140361-20-007888 — 1.01, 5.02, 5.03, 5.05, 7.01, 9.01
- 2020-03-16 0001140361-20-005868 — 8.01, 9.01

## late-filing notifications on or before 2023-02-07

- none on or before 2023-02-07

## item 2.02 — earnings release, exhibit 99.1

[0001783180-23-000010:8k_2_02:1]
EX-99
2
a8-kerexhibit99xq42022.htm
EX-99

[0001783180-23-000010:8k_2_02:2]
Document

[0001783180-23-000010:8k_2_02:3]
Exhibit 99

[0001783180-23-000010:8k_2_02:4]
Carrier Reports 2022 Results and Announces 2023 Outlook

[0001783180-23-000010:8k_2_02:5]
Fourth Quarter 2022 Highlights

[0001783180-23-000010:8k_2_02:6]
•Sales of $5.1 billion, down 1% compared to 2021 including 5% organic growth

[0001783180-23-000010:8k_2_02:7]
•GAAP EPS of $0.32 and adjusted EPS of $0.40

[0001783180-23-000010:8k_2_02:8]
•Net cash flow from operating activities of $1.1 billion and free cash flow of $983 million

[0001783180-23-000010:8k_2_02:9]
Full Year 2022 Highlights

[0001783180-23-000010:8k_2_02:10]
•Sales of $20.4 billion, down 1% compared to 2021 including 8% organic growth

[0001783180-23-000010:8k_2_02:11]
•GAAP EPS of $4.10 and adjusted EPS of $2.34

[0001783180-23-000010:8k_2_02:12]
•Net cash flow from operating activities of $1.7 billion and free cash flow of $1.4 billion

[0001783180-23-000010:8k_2_02:13]
Outlook for 2023

[0001783180-23-000010:8k_2_02:14]
•Sales of ~$22 billion with low to mid-single digit organic* growth

[0001783180-23-000010:8k_2_02:15]
•Adjusted operating margin* of ~14%, includes ~50 bps negative impact from TCC

[0001783180-23-000010:8k_2_02:16]
•Adjusted EPS* of $2.50 - $2.60, up high-single to low-double digits

[0001783180-23-000010:8k_2_02:17]
•Free cash flow* of ~$1.9 billion

[0001783180-23-000010:8k_2_02:18]
PALM BEACH GARDENS, Fla., Feb 7, 2023 – Carrier Global Corporation (NYSE:CARR), the leading global provider of healthy, safe, sustainable and intelligent building and cold chain solutions, today reported strong financial results for the fourth quarter and full year of 2022. The company projects continued organic growth in 2023 and is well-positioned with a strong balance sheet with significant capital to deploy towards continued value creation.

[0001783180-23-000010:8k_2_02:19]
“Our fourth quarter results represent the culmination of a year marked by strong execution and innovation. In 2022, we delivered on our organic sales growth, adjusted operating margin expansion and adjusted EPS growth commitments, in line with our value creation framework amidst an uncertain macro environment,” said Carrier Chairman & CEO Dave Gitlin. “I am proud of the strategic progress we made in 2022, including the expansion of our global digital platforms for buildings and cold chain solutions, Abound and Lynx, and the

[0001783180-23-000010:8k_2_02:20]
1

[0001783180-23-000010:8k_2_02:21]
significant portfolio actions we took including the divestiture of Chubb and acquisition of Toshiba Carrier Corporation. We will continue to build on our momentum as we enter 2023 with solid backlog levels and a healthy balance sheet. As the leading climate solutions provider, we are well-positioned to fully realize the benefits from the secular trends transforming our industry and planet.”

[0001783180-23-000010:8k_2_02:22]
Fourth Quarter 2022 Results

[0001783180-23-000010:8k_2_02:23]
Carrier’s fourth quarter sales of $5.1 billion were down 1% compared to the prior year including organic sales growth of 5%, a 4% headwind from currency translation and a 2% net negative impact from acquisitions and divestitures. Sales remained strong in the HVAC segment with 9% organic growth driven by double digit growth in Commercial HVAC, and strong growth in the North America Residential and Light Commercial business. Organic sales were down 7% for the Refrigeration segment due to significant weakness in container and commercial refrigeration which more than offset double-digit growth in global truck and trailer.  Fire & Security sales were up 6% organically driven by growth in commercial and industrial fire and access solutions.

[0001783180-23-000010:8k_2_02:24]
GAAP operating profit in the quarter of $433 million was down 6% from the fourth quarter of 2021. Adjusted operating profit of $516 million was down 1%.

[0001783180-23-000010:8k_2_02:25]
Net income and adjusted net income were $270 million and $340 million, respectively. GAAP EPS of $0.32 and adjusted EPS of $0.40 benefitted from a lower share count due to share repurchases offset by a higher year-over-year adjusted effective tax rate. Net cash flows provided by operating activities for the quarter were $1.1 billion and capital expenditures were $140 million, resulting in free cash flow of $983 million.

[0001783180-23-000010:8k_2_02:26]
Full-Year 2022 Results

[0001783180-23-000010:8k_2_02:27]
Carrier’s 2022 sales of $20.4 billion decreased 1% compared to the prior year including organic sales growth of 8%, a 3% headwind from currency translation and a 6% net negative impact from acquisitions and divestitures. GAAP operating profit of $4.5 billion increased 71% and adjusted operating profit increased 3% to $2.9 billion. Adjusted operating profit increased despite lower reported sales due to the Chubb divestiture and persistent supply chain

[0001783180-23-000010:8k_2_02:28]
2

[0001783180-23-000010:8k_2_02:29]
challenges. Strong price realization more than offset unprecedented inflation and productivity savings more than offset strategic incremental investments.

[0001783180-23-000010:8k_2_02:30]
GAAP EPS was $4.10 and adjusted EPS was $2.34. Net income was $3.5 billion, and adjusted net income was $2.0 billion. Net cash flows provided by operating activities were $1.7 billion and capital expenditures were $353 million, resulting in free cash flow of $1.4 billion. 2022 capital deployment included a net decrease of about $750 million in our long-term debt, over $500 million in acquisitions, $509 million in dividend payments and the repurchase of almost $1.4 billion of common stock.

[0001783180-23-000010:8k_2_02:31]
Full-Year 2023 Guidance

[0001783180-23-000010:8k_2_02:32]
Carrier is announcing the following outlook for 2023:

[0001783180-23-000010:8k_2_02:33]
|  | 2023 Guidance** |
| Sales | ~$22B Organic* up LSD - MSDFX down ~1%M&A up ~6% |
| Adjusted Operating Margin* | ~14% Includes ~50 bps negative impact from TCC |
| Adjusted EPS* | $2.50 - $2.60 |
| Free Cash Flow* | ~$1.9B |

[0001783180-23-000010:8k_2_02:34]
*Note: When the company provides expectations for organic sales, adjusted operating profit, adjusted operating margin, adjusted EPS and free cash flow on a forward-looking basis, a reconciliation of the differences between the non-GAAP expectations and the corresponding GAAP measures generally is not available without unreasonable effort. See “Use and Definitions of Non-GAAP Financial Measures” below for additional information.

[0001783180-23-000010:8k_2_02:35]
**As of February 7, 2023

[0001783180-23-000010:8k_2_02:36]
Conference Call

[0001783180-23-000010:8k_2_02:37]
Carrier will host a webcast of its earnings conference call today, Tuesday, Feb. 7, 2023, at 8 a.m. ET. To access the webcast, visit the Events & Presentations section of the Carrier Investor Relations site at ir.carrier.com/news-and-events/events-and-presentations or to listen to the earnings call by phone, participants must pre-register at Carrier Earnings Call Registration. All registrants will receive dial-in information and a PIN allowing access to the live call.

[0001783180-23-000010:8k_2_02:38]
3

[0001783180-23-000010:8k_2_02:39]
Cautionary Statement

[0001783180-23-000010:8k_2_02:40]
This communication contains statements which, to the extent they are not statements of historical or present fact, constitute "forward-looking statements" under the securities laws. These forward-looking statements are intended to provide management's current expectations or plans for Carrier's future operating and financial performance, based on assumptions currently believed to be valid. Forward-looking statements can be identified by the use of words such as "believe," "expect," "expectations," "plans," "strategy," "prospects," "estimate," "project," "target," "anticipate," "will," "should," "see," "guidance," "outlook," "confident," "scenario" and other words of similar meaning in connection with a discussion of future operating or financial performance. Forward-looking statements may include, among other things, statements relating to future sales, earnings, cash flow, results of operations, uses of cash, share repurchases, tax rates and other measures of financial performance or potential future plans, strategies or transactions of Carrier, Carrier's plans with respect to its indebtedness and other statements that are not historical facts. All forward-looking statements involve risks, uncertainties and other factors that may cause actual results to differ materially from those expressed or implied in the forward-looking statements. For additional information on identifying factors that may cause actual results to vary materially from those stated in forward-looking statements, see Carrier's reports on Forms 10-K, 10-Q and 8-K filed with or furnished to the U.S. Securities and Exchange Commission from time to time. Any forward-looking statement speaks only as of the date on which it is made, and Carrier assumes no obligation to update or revise such statement, whether as a result of new information, future events or otherwise, except as required by applicable law.

[0001783180-23-000010:8k_2_02:41]
Contact:    Media Inquiries

[0001783180-23-000010:8k_2_02:42]
Ashley Barrie

[0001783180-23-000010:8k_2_02:43]
561-365-1260

[0001783180-23-000010:8k_2_02:44]
Ashley.Barrie@Carrier.com

[0001783180-23-000010:8k_2_02:45]
Investor Relations

[0001783180-23-000010:8k_2_02:46]
Sam Pearlstein

[0001783180-23-000010:8k_2_02:47]
561-365-2251

[0001783180-23-000010:8k_2_02:48]
Sam.Pearlstein@Carrier.com

[0001783180-23-000010:8k_2_02:49]
SELECTED FINANCIAL DATA, NON-GAAP MEASURES AND DEFINITIONS

[0001783180-23-000010:8k_2_02:50]
Following Following are tables that present selected financial data of Carrier Global Corporation (“Carrier”). Also included are reconciliations of non-GAAP measures to their most comparable GAAP measures.

[0001783180-23-000010:8k_2_02:51]
Use and Definitions of Non-GAAP Financial Measures

[0001783180-23-000010:8k_2_02:52]
4

[0001783180-23-000010:8k_2_02:53]
Carrier Global Corporation (“Carrier”) reports its financial results in accordance with accounting principles generally accepted in the United States ("GAAP"). We supplement the reporting of our financial information determined under GAAP with certain non-GAAP financial information. The non-GAAP information presented provides investors with additional useful information, but should not be considered in isolation or as substitutes for the related GAAP measures. Moreover, other companies may define non-GAAP measures differently, which limits the usefulness of these measures for comparisons with such other companies. We encourage investors to review our financial statements and publicly filed reports in their entirety and not to rely on any single financial measure. A reconciliation of the non-GAAP measures to the corresponding amounts prepared in accordance with GAAP appears in the tables in this Appendix. The tables provide additional information as to the items and amounts that have been excluded from the adjusted measures.

[0001783180-23-000010:8k_2_02:54]
Organic sales, adjusted operating profit, adjusted operating margin, incremental margins / earnings conversion, earnings before interest, taxes and depreciation and amortization (“EBITDA”), adjusted EBITDA, adjusted net income, adjusted earnings per share (“EPS”), adjusted interest expense, net, adjusted effective tax rate and net debt are non-GAAP financial measures.

[0001783180-23-000010:8k_2_02:55]
Organic sales represents consolidated net sales (a GAAP measure), excluding the impact of foreign currency translation, acquisitions and divestitures completed in the preceding twelve months and other significant items of a nonoperational nature (hereinafter referred to as “other significant items”). Adjusted operating profit represents operating profit (a GAAP measure), excluding restructuring costs, amortization of acquired intangibles and other significant items. Adjusted operating margin represents adjusted operating profit as a percentage of net sales (a GAAP measure). Incremental margins / earnings conversion represents the year-over-year change in adjusted operating profit divided by the year-over-year change in net sales. EBITDA represents net income attributable to common shareholders (a GAAP measure), adjusted for interest income and expense, income tax expense, and depreciation and amortization. Adjusted EBITDA represents EBITDA, as calculated above, excluding non-service pension benefit, non-controlling interest in subsidiaries’ earnings from operations, restructuring costs and other significant items. Adjusted net income represents net income attributable to common shareowners (a GAAP measure), excluding restructuring costs, amortization of acquired intangibles and other significant items. Adjusted EPS represents diluted earnings per share (a GAAP measure), excluding restructuring costs, amortization of acquired intangibles and other significant items. Adjusted interest expense, net represents interest expense (a GAAP measure) and interest income (a GAAP measure), net excluding other significant items. The adjusted effective tax rate represents the effective tax rate (a GAAP measure), excluding restructuring costs, amortization of acquired intangibles and other significant items. Net debt represents long-term debt (a GAAP measure) less cash and cash equivalents (a GAAP measure). For the business segments, when applicable, adjustments of operating profit and operating margins represent operating profit, excluding restructuring, amortization of acquired intangibles and other significant items.

[0001783180-23-000010:8k_2_02:56]
Free cash flow is a non-GAAP financial measure that represents net cash flows provided by operating activities (a GAAP measure) less capital expenditures. Management believes free cash flow is a useful measure of liquidity and an additional basis for assessing Carrier’s ability to fund its activities, including the financing of acquisitions, debt service, repurchases of Carrier's common stock and distribution of earnings to shareowners.

[0001783180-23-000010:8k_2_02:57]
Orders are contractual commitments with customers to provide specified goods or services for an agreed upon price and may not be subject to penalty if cancelled.

[0001783180-23-000010:8k_2_02:58]
When we provide our expectations for organic sales, adjusted operating profit, adjusted operating margin, adjusted interest expense, net, adjusted effective tax rate, incremental margins/earnings conversion, adjusted EPS and free cash flow on a forward-looking basis, a reconciliation of the differences between the non-GAAP expectations and the corresponding GAAP measures (expected net sales, operating profit, operating margin, interest expense, effective tax rate, incremental operating margin, diluted EPS and net cash flows provided by operating activities) generally is not available without unreasonable effort due to potentially high variability, complexity and low visibility as to the items that would be excluded from the GAAP measure in the relevant future period, such as unusual gains and losses, the ultimate outcome of pending litigation, fluctuations in foreign currency exchange rates, the impact and timing of potential acquisitions and divestitures, future restructuring costs, and other structural changes or their probable significance. The variability of the excluded items may have a significant, and potentially unpredictable, impact on our future GAAP results.

[0001783180-23-000010:8k_2_02:59]
5

[0001783180-23-000010:8k_2_02:60]
Carrier Global Corporation

[0001783180-23-000010:8k_2_02:61]
Consolidated Statement of Operations

[0001783180-23-000010:8k_2_02:62]
|  | (Unaudited) |
|  | Three Months Ended December 31, |  | Year Ended December 31, |
| (In millions, except per share amounts) | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Net sales |  |  |  |  |  |  |  |
| Product sales | $ | 4,527 |  |  | $ | 4,256 |  |  | $ | 18,250 |  |  | $ | 17,214 |  |
| Service sales | 578 |  |  | 877 |  |  | 2,171 |  |  | 3,399 |  |
| Total Net sales | 5,105 |  |  | 5,133 |  |  | 20,421 |  |  | 20,613 |  |
| Costs and expenses |  |  |  |  |  |  |  |
| Cost of products sold | (3,407) |  |  | (3,169) |  |  | (13,337) |  |  | (12,300) |  |
| Cost of services sold | (451) |  |  | (598) |  |  | (1,620) |  |  | (2,333) |  |
| Research and development | (149) |  |  | (134) |  |  | (539) |  |  | (503) |  |
| Selling, general and administrative | (673) |  |  | (816) |  |  | (2,512) |  |  | (3,120) |  |
| Total Costs and expenses | (4,680) |  |  | (4,717) |  |  | (18,008) |  |  | (18,256) |  |
| Equity method investment net earnings | 40 |  |  | 48 |  |  | 262 |  |  | 249 |  |
| Other income (expense), net | (32) |  |  | (1) |  |  | 1,840 |  |  | 39 |  |
| Operating profit | 433 |  |  | 463 |  |  | 4,515 |  |  | 2,645 |  |
| Non-service pension benefit (expense) | (2) |  |  | 10 |  |  | (4) |  |  | 61 |  |
| Interest (expense) income, net | (54) |  |  | (68) |  |  | (219) |  |  | (306) |  |
| Income from operations before income taxes | 377 |  |  | 405 |  |  | 4,292 |  |  | 2,400 |  |
| Income tax expense | (99) |  |  | (73) |  |  | (708) |  |  | (699) |  |
| Net income from operations | 278 |  |  | 332 |  |  | 3,584 |  |  | 1,701 |  |
| Less: Non-controlling interest in subsidiaries' earnings from operations | 8 |  |  | 8 |  |  | 50 |  |  | 37 |  |
| Net income attributable to common shareowners | $ | 270 |  |  | $ | 324 |  |  | $ | 3,534 |  |  | $ | 1,664 |  |
| Earnings per share |  |  |  |  |  |  |  |
| Basic | $ | 0.32 |  |  | $ | 0.38 |  |  | $ | 4.19 |  |  | $ | 1.92 |  |
| Diluted | $ | 0.32 |  |  | $ | 0.36 |  |  | $ | 4.10 |  |  | $ | 1.87 |  |
| Weighted-average number of shares outstanding |  |  |  |  |  |  |  |
| Basic | 835.6 |  | 865.2 |  | 843.4 |  | 867.7 |
| Diluted | 852.2 |  | 888.5 |  | 861.2 |  | 890.3 |

[0001783180-23-000010:8k_2_02:63]
6

[0001783180-23-000010:8k_2_02:64]
Carrier Global Corporation

[0001783180-23-000010:8k_2_02:65]
Consolidated Balance Sheet

[0001783180-23-000010:8k_2_02:66]
|  | (Unaudited) |
|  | As of December 31, |
| (In millions) | 2022 |  | 2021 |
| Assets |  |  |  |
| Cash and cash equivalents | $ | 3,520 |  |  | $ | 2,987 |  |
| Accounts receivable, net | 2,833 |  |  | 2,403 |  |
| Contract assets, current | 537 |  |  | 503 |  |
| Inventories, net | 2,640 |  |  | 1,970 |  |
| Assets held for sale | — |  |  | 3,168 |  |
| Other assets, current | 349 |  |  | 376 |  |
| Total current assets | 9,879 |  |  | 11,407 |  |
| Future income tax benefits | 612 |  |  | 563 |  |
| Fixed assets, net | 2,241 |  |  | 1,826 |  |
| Operating lease right-of-use assets | 642 |  |  | 640 |  |
| Intangible assets, net | 1,342 |  |  | 509 |  |
| Goodwill | 9,977 |  |  | 9,349 |  |
| Pension and post-retirement assets | 26 |  |  | 43 |  |
| Equity method investments | 1,148 |  |  | 1,593 |  |
| Other assets | 219 |  |  | 242 |  |
| Total Assets | $ | 26,086 |  |  | $ | 26,172 |  |
| Liabilities and Equity |  |  |  |
| Accounts payable | $ | 2,833 |  |  | $ | 2,334 |  |
| Accrued liabilities | 2,610 |  |  | 2,561 |  |
| Contract liabilities, current | 449 |  |  | 415 |  |
| Liabilities held for sale | — |  |  | 1,134 |  |
| Current portion of long-term debt | 140 |  |  | 183 |  |
| Total current liabilities | 6,032 |  |  | 6,627 |  |
| Long-term debt | 8,702 |  |  | 9,513 |  |
| Future pension and post-retirement obligations | 349 |  |  | 380 |  |
| Future income tax obligations | 568 |  |  | 354 |  |
| Operating lease liabilities | 529 |  |  | 527 |  |
| Other long-term liabilities | 1,830 |  |  | 1,677 |  |
| Total Liabilities | 18,010 |  |  | 19,078 |  |
| Equity |  |  |  |
| Common stock, par value $0.01; 4,000,000,000 shares authorized; 876,487,480 and 873,064,219 shares issued; 834,664,966 and 863,039,097 outstanding as of December 31, 2022 and 2021, respectively | 9 |  |  | 9 |  |
| Treasury stock | (1,910) |  |  | (529) |  |
| Additional paid-in capital | 5,481 |  |  | 5,411 |  |
| Retained earnings | 5,866 |  |  | 2,865 |  |
| Accumulated other comprehensive loss | (1,688) |  |  | (989) |  |
| Non-controlling interest | 318 |  |  | 327 |  |
| Total Equity | 8,076 |  |  | 7,094 |  |
| Total Liabilities and Equity | $ | 26,086 |  |  | $ | 26,172 |  |

[0001783180-23-000010:8k_2_02:67]
7

[0001783180-23-000010:8k_2_02:68]
Carrier Global Corporation

[0001783180-23-000010:8k_2_02:69]
Consolidated Statement of Cash Flows (Unaudited)

[0001783180-23-000010:8k_2_02:70]
|  |  | Year Ended December 31, |
| (In millions) |  |  |  | 2022 |  | 2021 |
| Operating Activities |  |  |  |  |  |  |
| Net income from operations |  |  |  | $ | 3,584 |  |  | $ | 1,701 |  |
| Adjustments to reconcile net income from operations to net cash flows from operating activities |  |  |  |  |  |  |
| Depreciation and amortization |  |  |  | 380 |  |  | 338 |  |
| Deferred income tax provision |  |  |  | (124) |  |  | (74) |  |
| Stock-based compensation cost |  |  |  | 77 |  |  | 92 |  |
| Equity method investment net earnings |  |  |  | (262) |  |  | (249) |  |
| Impairment charge on minority-owned joint venture investments |  |  |  | — |  |  | 2 |  |
| (Gain) loss on extinguishment of debt |  |  |  | (36) |  |  | — |  |
| (Gain) loss on sale of investments |  |  |  | (1,815) |  |  | 2 |  |
| Changes in operating assets and liabilities |  |  |  |  |  |  |
| Accounts receivable, net |  |  |  | (145) |  |  | (97) |  |
| Contract assets, current |  |  |  | (51) |  |  | (47) |  |
| Inventories, net |  |  |  | (334) |  |  | (408) |  |
| Other assets, current |  |  |  | 104 |  |  | (11) |  |
| Accounts payable and accrued liabilities |  |  |  | 61 |  |  | 829 |  |
| Contract liabilities, current |  |  |  | 29 |  |  | 51 |  |
| Defined benefit plan contributions |  |  |  | (16) |  |  | (47) |  |
| Distributions from equity method investments |  |  |  | 148 |  |  | 159 |  |
| Other operating activities, net |  |  |  | 143 |  |  | (4) |  |
| Net cash flows provided by (used in) operating activities |  |  |  | 1,743 |  |  | 2,237 |  |
| Investing Activities |  |  |  |  |  |  |
| Capital expenditures |  |  |  | (353) |  |  | (344) |  |
| Investment in businesses, net of cash acquired |  |  |  | (506) |  |  | (366) |  |
| Dispositions of businesses |  |  |  | 2,902 |  |  | — |  |
| Proceeds on sale of investments |  |  |  | — |  |  | 7 |  |
| Settlement of derivative contracts, net |  |  |  | (194) |  |  | 4 |  |
| Payment to former shareholders of TCC |  |  |  | (104) |  |  | — |  |
| Other investing activities, net |  |  |  | — |  |  | 7 |  |
| Net cash flows provided by (used in) investing activities |  |  |  | 1,745 |  |  | (692) |  |
| Financing Activities |  |  |  |  |  |  |
| (Decrease) increase in short-term borrowings, net |  |  |  | (140) |  |  | 13 |  |
| Issuance of long-term debt |  |  |  | 432 |  |  | 140 |  |
| Repayment of long-term debt |  |  |  | (1,275) |  |  | (704) |  |
| Repurchases of common stock |  |  |  | (1,380) |  |  | (527) |  |
| Dividends paid on common stock |  |  |  | (509) |  |  | (417) |  |
| Dividends paid to non-controlling interest |  |  |  | (46) |  |  | (42) |  |
| Other financing activities, net |  |  |  | (13) |  |  | (25) |  |
| Net cash flows provided by (used in) financing activities |  |  |  | (2,931) |  |  | (1,562) |  |
| Effect of foreign exchange rate changes on cash and cash equivalents |  |  |  | (56) |  |  | (16) |  |
| Net increase (decrease) in cash and cash equivalents and restricted cash, including cash classified in current assets held for sale |  |  |  | 501 |  |  | (33) |  |
| Less: Change in cash balances classified as assets held for sale |  |  |  | — |  |  | 60 |  |
| Net increase (decrease) in cash and cash equivalents and restricted cash |  |  |  | 501 |  |  | (93) |  |
| Cash, cash equivalents and restricted cash, beginning of period |  |  |  | 3,026 |  |  | 3,119 |  |
| Cash, cash equivalents and restricted cash, end of period |  |  |  | 3,527 |  |  | 3,026 |  |
| Less: restricted cash |  |  |  | 7 |  |  | 39 |  |
| Cash and cash equivalents, end of period |  |  |  | $ | 3,520 |  |  | $ | 2,987 |  |

[0001783180-23-000010:8k_2_02:71]
8

[0001783180-23-000010:8k_2_02:72]
Carrier Global Corporation

[0001783180-23-000010:8k_2_02:73]
Segment Net Sales and Operating Profit

[0001783180-23-000010:8k_2_02:74]
|  | (Unaudited) |
|  | Three Months Ended December 31, |  | Year Ended December 31, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| (In millions) | Reported |  | Adjusted |  | Reported |  | Adjusted |  | Reported |  | Adjusted |  | Reported |  | Adjusted |
| Net sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| HVAC | $ | 3,316 |  | $ | 3,316 |  | $ | 2,730 |  | $ | 2,730 |  | $ | 13,408 |  | $ | 13,408 |  | $ | 11,390 |  | $ | 11,390 |
| Refrigeration | 943 |  | 943 |  | 1,090 |  | 1,090 |  | 3,883 |  | 3,883 |  | 4,127 |  | 4,127 |
| Fire & Security | 960 |  | 960 |  | 1,431 |  | 1,431 |  | 3,570 |  | 3,570 |  | 5,515 |  | 5,515 |
| Segment sales | 5,219 |  | 5,219 |  | 5,251 |  | 5,251 |  | 20,861 |  | 20,861 |  | 21,032 |  | 21,032 |
| Eliminations and other | (114) |  | (114) |  | (118) |  | (118) |  | (440) |  | (440) |  | (419) |  | (419) |
| Net sales | $ | 5,105 |  | $ | 5,105 |  | $ | 5,133 |  | $ | 5,133 |  | $ | 20,421 |  | $ | 20,421 |  | $ | 20,613 |  | $ | 20,613 |
| Operating profit |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| HVAC | $ | 241 |  | $ | 317 |  | $ | 227 |  | $ | 246 |  | $ | 2,610 |  | $ | 2,032 |  | $ | 1,738 |  | $ | 1,791 |
| Refrigeration | 113 |  | 114 |  | 107 |  | 125 |  | 483 |  | 496 |  | 476 |  | 501 |
| Fire & Security | 136 |  | 139 |  | 182 |  | 199 |  | 1,630 |  | 541 |  | 662 |  | 730 |
| Segment operating profit | 490 |  | 570 |  | 516 |  | 570 |  | 4,723 |  | 3,069 |  | 2,876 |  | 3,022 |
| Eliminations and other | (30) |  | (30) |  | (23) |  | (23) |  | (80) |  | (80) |  | (96) |  | (79) |
| General corporate expenses | (27) |  | (24) |  | (30) |  | (26) |  | (128) |  | (95) |  | (135) |  | (124) |
| Operating profit | $ | 433 |  | $ | 516 |  | $ | 463 |  | $ | 521 |  | $ | 4,515 |  | $ | 2,894 |  | $ | 2,645 |  | $ | 2,819 |
| Operating margin |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| HVAC | 7.3 | % |  | 9.6 | % |  | 8.3 | % |  | 9.0 | % |  | 19.5 | % |  | 15.2 | % |  | 15.3 | % |  | 15.7 | % |
| Refrigeration | 12.0 | % |  | 12.1 | % |  | 9.8 | % |  | 11.5 | % |  | 12.4 | % |  | 12.8 | % |  | 11.5 | % |  | 12.1 | % |
| Fire & Security | 14.2 | % |  | 14.5 | % |  | 12.7 | % |  | 13.9 | % |  | 45.7 | % |  | 15.2 | % |  | 12.0 | % |  | 13.2 | % |
| Total Carrier | 8.5 | % |  | 10.1 | % |  | 9.0 | % |  | 10.2 | % |  | 22.1 | % |  | 14.2 | % |  | 12.8 | % |  | 13.7 | % |

[0001783180-23-000010:8k_2_02:75]
9

[0001783180-23-000010:8k_2_02:76]
Carrier Global Corporation

[0001783180-23-000010:8k_2_02:77]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP)

[0001783180-23-000010:8k_2_02:78]
Operating Profit

[0001783180-23-000010:8k_2_02:79]
|  | (Unaudited) |
|  | Three Months Ended December 31, 2022 |
| (In millions) | HVAC |  | Refrigeration |  | Fire & Security |  | Eliminations and Other |  | General Corporate Expenses |  | Carrier |
| Net sales | $ | 3,316 |  |  | $ | 943 |  |  | $ | 960 |  |  | $ | (114) |  |  | $ | — |  |  | $ | 5,105 |  |
| Segment operating profit | $ | 241 |  |  | $ | 113 |  |  | $ | 136 |  |  | $ | (30) |  |  | $ | (27) |  |  | $ | 433 |  |
| Reported operating margin | 7.3 | % |  | 12.0 | % |  | 14.2 | % |  |  |  |  |  | 8.5 | % |
| Adjustments to segment operating profit: |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring costs | $ | — |  |  | $ | 1 |  |  | $ | 1 |  |  | $ | — |  |  | $ | — |  |  | $ | 2 |  |
| Amortization of acquired intangibles (1) | 22 |  |  | — |  |  | 1 |  |  | — |  |  | — |  |  | 23 |  |
| Acquisition step-up amortization (2) | 27 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 27 |  |
| Acquisition-related costs | — |  |  | — |  |  | — |  |  | — |  |  | 3 |  |  | 3 |  |
| Chubb gain | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| TCC acquisition-related gain (3) | 27 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 27 |  |
| Russia/Ukraine asset impairment | — |  |  | — |  |  | 1 |  |  | — |  |  | — |  |  | 1 |  |
| Charge resulting from legal matter | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total adjustments to operating profit | $ | 76 |  |  | $ | 1 |  |  | $ | 3 |  |  | $ | — |  |  | $ | 3 |  |  | $ | 83 |  |
| Adjusted operating profit | $ | 317 |  |  | $ | 114 |  |  | $ | 139 |  |  | $ | (30) |  |  | $ | (24) |  |  | $ | 516 |  |
| Adjusted operating margin | 9.6 | % |  | 12.1 | % |  | 14.5 | % |  |  |  |  |  | 10.1 | % |

[0001783180-23-000010:8k_2_02:80]
|  | (Unaudited) |
|  | Three Months Ended December 31, 2021 |
| (In millions) | HVAC |  | Refrigeration |  | Fire & Security |  | Eliminations and Other |  | General Corporate Expenses |  | Carrier |
| Net sales | $ | 2,730 |  |  | $ | 1,090 |  |  | $ | 1,431 |  |  | $ | (118) |  |  | $ | — |  |  | $ | 5,133 |  |
| Segment operating profit | $ | 227 |  |  | $ | 107 |  |  | $ | 182 |  |  | $ | (23) |  |  | $ | (30) |  |  | $ | 463 |  |
| Reported operating margin | 8.3 | % |  | 9.8 | % |  | 12.7 | % |  |  |  |  |  | 9.0 | % |
| Adjustments to segment operating profit: |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring costs | $ | 15 |  |  | $ | 18 |  |  | $ | 3 |  |  | $ | — |  |  | $ | 1 |  |  | $ | 37 |  |
| Amortization of acquired intangibles (1) | 4 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 4 |  |
| Acquisition step-up amortization (2) | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Acquisition-related costs | — |  |  | — |  |  | — |  |  | — |  |  | 2 |  |  | 2 |  |
| Chubb transaction costs | — |  |  | — |  |  | 14 |  |  | — |  |  | — |  |  | 14 |  |
| Separation Costs | — |  |  | — |  |  | — |  |  | — |  |  | 1 |  |  | 1 |  |
| Total adjustments to operating profit | $ | 19 |  |  | $ | 18 |  |  | $ | 17 |  |  | $ | — |  |  | $ | 4 |  |  | $ | 58 |  |
| Adjusted operating profit | $ | 246 |  |  | $ | 125 |  |  | $ | 199 |  |  | $ | (23) |  |  | $ | (26) |  |  | $ | 521 |  |
| Adjusted operating margin | 9.0 | % |  | 11.5 | % |  | 13.9 | % |  |  |  |  |  | 10.2 | % |

[0001783180-23-000010:8k_2_02:81]
(1) Beginning in Q3 2022, we exclude the impact of amortization of acquired intangibles from our non-GAAP financial measures including adjusted operating profit. Amortization of acquired intangibles, a non-cash expense, is unrelated to our core operating performance and amounts can vary significantly depending on the number, timing and size of acquisitions, among other factors. We believe this adjustment provides investors meaningful information to better evaluate our operating performance between periods. Historical periods have been updated to conform with the current period presentation.

[0001783180-23-000010:8k_2_02:82]
(2) Amortization of the step-up to fair value of acquired inventory and backlog.

[0001783180-23-000010:8k_2_02:83]
(3) The carrying value of our previously held TCC equity investments were recognized at fair value and subsequently adjusted.

[0001783180-23-000010:8k_2_02:84]
10

[0001783180-23-000010:8k_2_02:85]
Carrier Global Corporation

[0001783180-23-000010:8k_2_02:86]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP)

[0001783180-23-000010:8k_2_02:87]
Operating Profit

[0001783180-23-000010:8k_2_02:88]
|  | (Unaudited) |
|  | Year Ended December 31, 2022 |
| (In millions) | HVAC |  | Refrigeration |  | Fire & Security |  | Eliminations and Other |  | General Corporate Expenses |  | Carrier |
| Net sales | $ | 13,408 |  |  | $ | 3,883 |  |  | $ | 3,570 |  |  | $ | (440) |  |  | $ | — |  |  | $ | 20,421 |  |
| Segment operating profit | $ | 2,610 |  |  | $ | 483 |  |  | $ | 1,630 |  |  | $ | (80) |  |  | $ | (128) |  |  | $ | 4,515 |  |
| Reported operating margin | 19.5 | % |  | 12.4 | % |  | 45.7 | % |  |  |  |  |  | 22.1 | % |
| Adjustments to segment operating profit: |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring costs | $ | 8 |  |  | $ | 10 |  |  | $ | 11 |  |  | $ | — |  |  | $ | 2 |  |  | $ | 31 |  |
| Amortization of acquired intangibles (1) | 46 |  |  | — |  |  | 4 |  |  | — |  |  | — |  |  | 50 |  |
| Acquisition step-up amortization (2) | 51 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 51 |  |
| Acquisition-related costs | — |  |  | — |  |  | — |  |  | — |  |  | 31 |  |  | 31 |  |
| Chubb gain | — |  |  | — |  |  | (1,105) |  |  | — |  |  | — |  |  | (1,105) |  |
| TCC acquisition-related gain (3) | (705) |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (705) |  |
| Russia/Ukraine asset impairment | — |  |  | 3 |  |  | 1 |  |  | — |  |  | — |  |  | 4 |  |
| Charge resulting from legal matter | 22 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 22 |  |
| Total adjustments to operating profit | $ | (578) |  |  | $ | 13 |  |  | $ | (1,089) |  |  | $ | — |  |  | $ | 33 |  |  | $ | (1,621) |  |
| Adjusted operating profit | $ | 2,032 |  |  | $ | 496 |  |  | $ | 541 |  |  | $ | (80) |  |  | $ | (95) |  |  | $ | 2,894 |  |
| Adjusted operating margin | 15.2 | % |  | 12.8 | % |  | 15.2 | % |  |  |  |  |  | 14.2 | % |

[0001783180-23-000010:8k_2_02:89]
|  | (Unaudited) |
|  | Year Ended December 31, 2021 |
| (In millions) | HVAC |  | Refrigeration |  | Fire & Security |  | Eliminations and Other |  | General Corporate Expenses |  | Carrier |
| Net sales | $ | 11,390 |  |  | $ | 4,127 |  |  | $ | 5,515 |  |  | $ | (419) |  |  | $ | — |  |  | $ | 20,613 |  |
| Segment operating profit | $ | 1,738 |  |  | $ | 476 |  |  | $ | 662 |  |  | $ | (96) |  |  | $ | (135) |  |  | $ | 2,645 |  |
| Reported operating margin | 15.3 | % |  | 11.5 | % |  | 12.0 | % |  |  |  |  |  | 12.8 | % |
| Adjustments to segment operating profit: |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring Cost | $ | 33 |  |  | $ | 25 |  |  | $ | 26 |  |  | $ | — |  |  | $ | 5 |  |  | $ | 89 |  |
| Amortization of acquired intangibles (1) | 15 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 15 |  |
| Acquisition step-up amortization (2) | 5 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 5 |  |
| Acquisition-related costs | — |  |  | — |  |  | — |  |  | — |  |  | 2 |  |  | 2 |  |
| Chubb transaction costs | — |  |  | — |  |  | 42 |  |  | — |  |  | 1 |  |  | 43 |  |
| Separation costs | — |  |  | — |  |  | — |  |  | 17 |  |  | 3 |  |  | 20 |  |
| Total adjustments to operating profit | $ | 53 |  |  | $ | 25 |  |  | $ | 68 |  |  | $ | 17 |  |  | $ | 11 |  |  | $ | 174 |  |
| Adjusted operating profit | $ | 1,791 |  |  | $ | 501 |  |  | $ | 730 |  |  | $ | (79) |  |  | $ | (124) |  |  | $ | 2,819 |  |
| Adjusted operating margin | 15.7 | % |  | 12.1 | % |  | 13.2 | % |  |  |  |  |  | 13.7 | % |

[0001783180-23-000010:8k_2_02:90]
(1) Beginning in Q3 2022, we exclude the impact of amortization of acquired intangibles from our non-GAAP financial measures including adjusted operating profit. Amortization of acquired intangibles, a non-cash expense, is unrelated to our core operating performance and amounts can vary significantly depending on the number, timing and size of acquisitions, among other factors. We believe this adjustment provides investors meaningful information to better evaluate our operating performance between periods. Historical periods have been updated to conform with the current period presentation.

[0001783180-23-000010:8k_2_02:91]
(2) Amortization of the step-up to fair value of acquired inventory and backlog.

[0001783180-23-000010:8k_2_02:92]
(3) The carrying value of our previously held TCC equity investments were recognized at fair value and subsequently adjusted.

[0001783180-23-000010:8k_2_02:93]
11

[0001783180-23-000010:8k_2_02:94]
Carrier Global Corporation

[0001783180-23-000010:8k_2_02:95]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP) Results

[0001783180-23-000010:8k_2_02:96]
Net Income, Earnings Per Share, and Effective Tax Rate

[0001783180-23-000010:8k_2_02:97]
|  | (Unaudited) |
|  | Three Months Ended December 31, 2022 |  | Year Ended December 31, 2022 |
| (In millions, except per share amounts) | Reported |  | Adjustments |  | Adjusted |  | Reported |  | Adjustments |  | Adjusted |
| Net sales | $ | 5,105 |  |  | $ | — |  |  | $ | 5,105 |  |  | $ | 20,421 |  |  | $ | — |  |  | $ | 20,421 |  |
| Operating profit | $ | 433 |  |  | 83 |  | a | $ | 516 |  |  | $ | 4,515 |  |  | (1,621) |  | a | $ | 2,894 |  |
| Operating margin | 8.5 | % |  |  |  | 10.1 | % |  | 22.1 | % |  |  |  | 14.2 | % |
| Income from operations before income taxes | $ | 377 |  |  | 83 |  | a | $ | 460 |  |  | $ | 4,292 |  |  | (1,649) |  | a,b | $ | 2,643 |  |
| Income tax expense | $ | (99) |  |  | (13) |  | c | $ | (112) |  |  | $ | (708) |  |  | 135 |  | c | $ | (573) |  |
| Income tax rate | 26.3 | % |  |  |  | 24.3 | % |  | 16.5 | % |  |  |  | 21.7 | % |
| Net income attributable to common shareowners | $ | 270 |  |  | $ | 70 |  |  | $ | 340 |  |  | $ | 3,534 |  |  | $ | (1,514) |  |  | $ | 2,020 |  |
| Summary of Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring costs |  |  | $ | 2 |  | a |  |  |  |  | $ | 31 |  | a |  |
| Amortization of acquired intangibles (1) |  |  | 23 |  | a |  |  |  |  | 50 |  | a |  |
| Acquisition step-up amortization (2) |  |  | 27 |  | a |  |  |  |  | 51 |  | a |  |
| Acquisition-related costs |  |  | 3 |  | a |  |  |  |  | 31 |  | a |  |
| Chubb gain |  |  | — |  | a |  |  |  |  | (1,105) |  | a |  |
| TCC acquisition-related gain (3) |  |  | 27 |  | a |  |  |  |  | (705) |  | a |  |
| Russia/Ukraine asset impairment |  |  | 1 |  | a |  |  |  |  | 4 |  | a |  |
| Charge resulting from legal matter |  |  | — |  |  |  |  |  |  | 22 |  | a |  |
| Debt extinguishment (gain), net (4) |  |  | — |  |  |  |  |  |  | (28) |  | b |  |
| Total adjustments |  |  | $ | 83 |  |  |  |  |  |  | $ | (1,649) |  |  |  |
| Tax effect on adjustments above |  |  | $ | (13) |  |  |  |  |  |  | $ | 172 |  |  |  |
| Tax specific adjustments |  |  | — |  |  |  |  |  |  | (37) |  |  |  |
| Total tax adjustments |  |  | $ | (13) |  | c |  |  |  |  | $ | 135 |  | c |  |
| Shares outstanding - Diluted | 852.2 |  |  |  |  | 852.2 |  |  | 861.2 |  |  |  |  | 861.2 |  |
| Earnings per share - Diluted | $ | 0.32 |  |  |  |  | $ | 0.40 |  |  | $ | 4.10 |  |  |  |  | $ | 2.34 |  |

[0001783180-23-000010:8k_2_02:98]
(1) Beginning in Q3 2022, we exclude the impact of amortization of acquired intangibles from our non-GAAP financial measures including adjusted operating profit, adjusted net income and adjusted EPS. Amortization of acquired intangibles, a non-cash expense, is unrelated to our core operating performance and amounts can vary significantly depending on the number, timing and size of acquisitions, among other factors. We believe this adjustment provides investors meaningful information to better evaluate our operating performance between periods. Historical periods have been updated to conform with the current period presentation.

[0001783180-23-000010:8k_2_02:99]
(2) Amortization of the step-up to fair value of acquired inventory and backlog.

[0001783180-23-000010:8k_2_02:100]
(3) The carrying value of our previously held TCC equity investments were recognized at fair value and subsequently adjusted.

[0001783180-23-000010:8k_2_02:101]
(4) The Company repurchased approximately $1.15 billion of aggregate principal senior notes on March 30, 2022 and recognized a net gain of $33 million and wrote-off $5 million of unamortized deferred financing costs in Interest (expense) income, net.

[0001783180-23-000010:8k_2_02:102]
Carrier Global Corporation

[0001783180-23-000010:8k_2_02:103]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP) Results

[0001783180-23-000010:8k_2_02:104]
Net Income, Earnings Per Share, and Effective Tax Rate

[0001783180-23-000010:8k_2_02:105]
|  | (Unaudited) |
|  | Three Months Ended December 31, 2021 |  | Year Ended December 31, 2021 |
| (In millions, except per share amounts) | Reported |  | Adjustments |  | Adjusted |  | Reported |  | Adjustments |  | Adjusted |
| Net sales | $ | 5,133 |  |  | $ | — |  |  | $ | 5,133 |  |  | $ | 20,613 |  |  | $ | — |  |  | $ | 20,613 |  |
| Operating profit | $ | 463 |  |  | 58 |  | a | $ | 521 |  |  | $ | 2,645 |  |  | 174 |  | a | $ | 2,819 |  |
| Operating margin | 9.0 | % |  |  |  | 10.2 | % |  | 12.8 | % |  |  |  | 13.7 | % |
| Income from operations before income taxes | $ | 405 |  |  | 58 |  | a,b | $ | 463 |  |  | $ | 2,400 |  |  | 193 |  | a,b | $ | 2,593 |  |
| Income tax expense | $ | (73) |  |  | 10 |  | c | $ | (63) |  |  | $ | (699) |  |  | 167 |  | c | $ | (532) |  |
| Income tax rate | 18.0 | % |  |  |  | 13.6 | % |  | 29.1 | % |  |  |  | 20.5 | % |
| Net income attributable to common shareowners | $ | 324 |  |  | $ | 68 |  |  | $ | 392 |  |  | $ | 1,664 |  |  | $ | 360 |  |  | $ | 2,024 |  |
| Summary of Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring costs |  |  | $ | 37 |  | a |  |  |  |  | $ | 89 |  | a |  |
| Amortization of acquired intangibles (1) |  |  | 4 |  | a |  |  |  |  | 15 |  | a |  |
| Acquisition step-up amortization (2) |  |  | — |  | a |  |  |  |  | 5 |  | a |  |
| Acquisition-related costs |  |  | 2 |  | a |  |  |  |  | 2 |  | a |  |
| Chubb transaction costs |  |  | 14 |  | a |  |  |  |  | 43 |  | a |  |
| Separation costs |  |  | 1 |  | a |  |  |  |  | 20 |  | a |  |
| Debt prepayment costs |  |  | — |  |  |  |  |  |  | 19 |  | b |  |
| Total adjustments |  |  | $ | 58 |  |  |  |  |  |  | $ | 193 |  |  |  |
| Tax effect on adjustments above |  |  | $ | (11) |  |  |  |  |  |  | $ | (33) |  |  |  |
| Tax specific adjustments |  |  | 21 |  |  |  |  |  |  | 200 |  |  |  |
| Total tax adjustments |  |  | $ | 10 |  | c |  |  |  |  | $ | 167 |  | c |  |
| Shares outstanding - Diluted | 888.5 |  |  |  |  | 888.5 |  |  | 890.3 |  |  |  |  | 890.3 |  |
| Earnings per share - Diluted | $ | 0.36 |  |  |  |  | $ | 0.44 |  |  | $ | 1.87 |  |  |  |  | $ | 2.27 |  |

[0001783180-23-000010:8k_2_02:106]
(1) Beginning in Q3 2022, we exclude the impact of amortization of acquired intangibles from our non-GAAP financial measures including adjusted operating profit, adjusted net income and adjusted EPS. Amortization of acquired intangibles, a non-cash expense, is unrelated to our core operating performance and amounts can vary significantly depending on the number, timing and size of acquisitions, among other factors. We believe this adjustment provides investors meaningful information to better evaluate our operating performance between periods. Historical periods have been updated to conform with the current period presentation.

[0001783180-23-000010:8k_2_02:107]
(2) Amortization of the step-up to fair value of acquired inventory and backlog.

[0001783180-23-000010:8k_2_02:108]
13

[0001783180-23-000010:8k_2_02:109]
Carrier Global Corporation

[0001783180-23-000010:8k_2_02:110]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP) Results

[0001783180-23-000010:8k_2_02:111]
Components of Changes in Net Sales

[0001783180-23-000010:8k_2_02:112]
Three Months Ended December 31, 2022 Compared with Three Months Ended December 31, 2021

[0001783180-23-000010:8k_2_02:113]
|  | (Unaudited) |
|  | Factors Contributing to Total % change in Net Sales |
|  | Organic |  | FX Translation |  | Acquisitions / Divestitures, net |  | Other |  | Total |
| HVAC | 9% |  | (4)% |  | 16% |  | —% |  | 21% |
| Refrigeration | (7)% |  | (7)% |  | —% |  | —% |  | (14)% |
| Fire & Security | 6% |  | (3)% |  | (36)% |  | —% |  | (33)% |
| Consolidated | 5% |  | (4)% |  | (2)% |  | —% |  | (1)% |

[0001783180-23-000010:8k_2_02:114]
Year Ended December 31, 2022 Compared with Year Ended December 31, 2021

[0001783180-23-000010:8k_2_02:115]
|  | (Unaudited) |
|  | Factors Contributing to Total % change in Net Sales |
|  | Organic |  | FX Translation |  | Acquisitions / Divestitures, net |  | Other |  | Total |
| HVAC | 12% |  | (2)% |  | 8% |  | —% |  | 18% |
| Refrigeration | —% |  | (6)% |  | —% |  | —% |  | (6)% |
| Fire & Security | 5% |  | (2)% |  | (38)% |  | —% |  | (35)% |
| Consolidated | 8% |  | (3)% |  | (6)% |  | —% |  | (1)% |

[0001783180-23-000010:8k_2_02:116]
Net Sales Excluding Impact of Chubb

[0001783180-23-000010:8k_2_02:117]
|  | (Unaudited) |
|  | Three Months Ended December 31, 2021 |  | Year Ended December 31, 2021 |
|  | Carrier |  | Fire and Security |  | Carrier |  | Fire and Security |
| Net Sales: |  |  |  |  |  |  |  |
| Reported | $ | 5,133 |  |  | $ | 1,431 |  |  | $ | 20,613 |  |  | $ | 5,515 |  |
| Chubb | (536) |  |  | (536) |  |  | (2,158) |  |  | (2,158) |  |
| Net sales excluding impact of Chubb | $ | 4,597 |  |  | $ | 895 |  |  | $ | 18,455 |  |  | $ | 3,357 |  |
| Percentage increase in Net sales excluding impact of Chubb | 11 | % |  | 7 | % |  | 11 | % |  | 6 | % |

[0001783180-23-000010:8k_2_02:118]
14

[0001783180-23-000010:8k_2_02:119]
Carrier Global Corporation

[0001783180-23-000010:8k_2_02:120]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP) Results

[0001783180-23-000010:8k_2_02:121]
Historical Amounts of Amortization of Acquired Intangibles

[0001783180-23-000010:8k_2_02:122]
|  |  | (Unaudited) |  |  |  |  |
|  |  | Q1 |  | Q2 |  | Q3 |  | Q4 |  | FY |  | Q1 |  | Q2 |  | Q3 |  | Q4 |  | FY |
| (In millions) |  | 2021 |  | 2021 |  | 2021 |  | 2021 |  | 2021 |  | 2022 |  | 2022 |  | 2022 |  | 2022 |  | 2022 |
| HVAC |  | $ | — |  |  | $ | 4 |  |  | $ | 7 |  |  | $ | 4 |  |  | $ | 15 |  |  | $ | 4 |  |  | $ | 4 |  |  | $ | 16 |  |  | $ | 22 |  |  | $ | 46 |  |
| Fire & Security |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 1 |  |  | 1 |  |  | 1 |  |  | 1 |  |  | 4 |  |
| Total Carrier |  | — |  |  | 4 |  |  | 7 |  |  | 4 |  | 15 |  |  | 5 |  |  | 5 |  |  | 17 |  |  | 23 |  |  | 50 |  |
| Associated tax effect |  | — |  |  | (1) |  |  | (2) |  |  | (1) |  |  | (4) |  |  | (1) |  |  | (1) |  |  | (7) |  |  | (4) |  |  | (13) |  |
| Net impact to adjusted results |  | $ | — |  |  | $ | 3 |  |  | $ | 5 |  |  | $ | 3 |  |  | $ | 11 |  |  | $ | 4 |  |  | $ | 4 |  |  | $ | 10 |  |  | $ | 19 |  |  | $ | 37 |  |

[0001783180-23-000010:8k_2_02:123]
Free Cash Flow Reconciliation

[0001783180-23-000010:8k_2_02:124]
|  |  | (Unaudited) |  |
|  |  | Q1 |  | Q2 |  | Q3 |  | Q4 |  | FY |  | Q1 |  | Q2 |  | Q3 |  | Q4 |  | FY |
| (In millions) |  | 2021 |  | 2021 |  | 2021 |  | 2021 |  | 2021 |  | 2022 |  | 2022 |  | 2022 |  | 2022 |  | 2022 |
| Net cash flows provided by operating activities |  | $ | 184 |  |  | $ | 561 |  |  | $ | 579 |  |  | $ | 913 |  |  | $ | 2,237 |  |  | $ | (202) |  |  | $ | 32 |  |  | $ | 790 |  |  | $ | 1,123 |  |  | $ | 1,743 |  |
| Less: Capital expenditures |  | 53 |  |  | 79 |  |  | 74 |  |  | 138 |  |  | 344 |  |  | 56 |  |  | 66 |  |  | 91 |  |  | 140 |  |  | 353 |  |
| Free cash flow |  | $ | 131 |  |  | $ | 482 |  |  | $ | 505 |  |  | $ | 775 |  |  | $ | 1,893 |  |  | $ | (258) |  |  | $ | (34) |  |  | $ | 699 |  |  | $ | 983 |  |  | $ | 1,390 |  |

[0001783180-23-000010:8k_2_02:125]
Net Debt Reconciliation

[0001783180-23-000010:8k_2_02:126]
|  |  | (Unaudited) |
|  |  | As of December 31, |
| (In millions) |  | 2022 |  | 2021 |
| Long-term debt |  | $ | 8,702 |  |  | $ | 9,513 |  |
| Current portion of long-term debt |  | 140 |  |  | 183 |  |
| Less: Cash and cash equivalents |  | 3,520 |  |  | 2,987 |  |
| Net debt |  | $ | 5,322 |  |  | $ | 6,709 |  |

[0001783180-23-000010:8k_2_02:127]
15
