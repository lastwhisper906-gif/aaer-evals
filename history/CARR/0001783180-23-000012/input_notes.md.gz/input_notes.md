# CARR notes — 0001783180-23-000012


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001783180-23-000012:notes:1]
Part III hereof incorporates by reference portions of the Registrant's definitive proxy statement related to its 2023 annual meeting of shareowners.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001783180-23-000012:notes:2]
DESCRIPTION OF THE BUSINESS 
Carrier Global Corporation (the "Company") is the leading global provider of healthy, safe, sustainable and intelligent building and cold chain solutions with a focus on providing differentiated, digitally-enabled lifecycle solutions to its customers. The Company's portfolio includes industry-leading brands such as Carrier, Toshiba, Automated Logic, Carrier Transicold, Kidde, Edwards and LenelS2 that offer innovative heating, ventilating and air conditioning ("HVAC"), refrigeration, fire, security and building automation technologies to help make the world safer and more comfortable. The Company also provides a broad array of related building services, including audit, design, installation, system integration, repair, maintenance and monitoring. The Company's operations are classified into three segments: HVAC, Refrigeration and Fire & Security.

[0001783180-23-000012:notes:3]
Impact of the COVID-19 Pandemic

[0001783180-23-000012:notes:4]
In early 2020, the World Health Organization declared the outbreak of a respiratory disease known as COVID-19 as a global pandemic. In response, many countries implemented containment and mitigation measures to combat the outbreak, which severely restricted the level of economic activity and caused a significant contraction in the global economy. As a result, the Company took several preemptive actions to manage liquidity, preserve the health and safety of its employees and customers as well as maintain the continuity of its operations. The preparation of financial statements requires management to use judgments in making estimates and assumptions based on the relevant information available at the end of each period, which can have a significant effect on reported amounts. However, due to significant uncertainty surrounding the pandemic, including a resurgence in cases and the spread of COVID-19 variants, management's judgments could change. While the Company's results of operations, cash flows and financial condition could be negatively impacted, the extent of any continuing impact cannot be estimated with certainty at this time.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001783180-23-000012:notes:5]
BASIS OF PRESENTATION 
The accompanying Consolidated Financial Statements reflect the consolidated operations of the Company and have been prepared in accordance with U.S. Generally Accepted Accounting Principles ("GAAP") as defined by the Financial Accounting Standards Board ("FASB") within the FASB Accounting Standards Codification ("ASC"). Inter-company accounts and transactions have been eliminated. Related party transactions between the Company and its equity method investees have not been eliminated. Certain immaterial amounts presented in prior periods have been reclassified to conform to the current period presentation.

[0001783180-23-000012:notes:6]
The accompanying Consolidated Financial Statements include all majority-owned subsidiaries of the Company. A non-controlling interest in a subsidiary is considered an ownership interest in a majority-owned subsidiary that is not attributable to the parent. The Company includes Non-controlling interest as a component of Total equity in the accompanying Consolidated Balance Sheet and the Non-controlling interest in subsidiaries' earnings from operations are presented as an adjustment to Net income from operations used to arrive at Net income attributable to common shareowners in the accompanying Consolidated Statement of Operations. Partially-owned equity affiliates represent 20 to 50% ownership interests in investments where the Company demonstrates significant influence, but does not have a controlling financial interest. Partially-owned equity affiliates are accounted for under the equity method.

[0001783180-23-000012:notes:7]
Acquisition of Toshiba Carrier Corporation

[0001783180-23-000012:notes:8]
On February 6, 2022, the Company entered into a binding agreement to acquire a majority ownership interest in Toshiba Carrier Corporation (“TCC”), a variable refrigerant flow ("VRF") and light commercial HVAC joint venture between Carrier and Toshiba Corporation. The acquisition was completed on August 1, 2022. As a result, the assets, liabilities and results of operations of TCC are consolidated in the accompanying Consolidated Financial Statements as of the date of acquisition and reported within the Company’s HVAC segment. Upon closing, Toshiba Corporation retained a 5% ownership interest in TCC. See Note 19 - Acquisitions for additional information.

[0001783180-23-000012:notes:9]
Sale of Chubb Fire & Security Business

[0001783180-23-000012:notes:10]
On July 26, 2021, the Company entered into a stock purchase agreement to sell its Chubb Fire and Security business ("Chubb") to APi Group Corporation ("APi"). As a result, the assets and liabilities of Chubb are presented as held for sale in the accompanying Consolidated Balance Sheet as of December 31, 2021 and recorded at the lower of their carrying value or fair value less estimated cost to sell. The sale of Chubb was completed on January 3, 2022 (the "Chubb Sale"). See Note 20 - Divestitures for additional information.

[0001783180-23-000012:notes:11]
Separation from United Technologies

[0001783180-23-000012:notes:12]
On April 3, 2020 (the "Distribution Date"), United Technologies Corporation, since renamed Raytheon Technologies Corporation ("UTC"), completed the spin-off of the Company into an independent, publicly traded company (the "Separation") through a pro rata distribution (the "Distribution") on a one-for-one basis of all of the outstanding shares of common stock of the Company to UTC shareowners who held shares of UTC common stock as of the close of business on March 19, 2020, the record date for the Distribution. In connection with the Separation, the Company issued an aggregate principal balance of $11.0 billion of debt and transferred approximately $10.9 billion of cash to UTC on February 27, 2020 and March 27, 2020. On April 1, 2020 and April 2, 2020, the Company received cash contributions totaling $590 million from UTC related to the Separation.

[0001783180-23-000012:notes:13]
The Company's financial statements for the periods prior to the Separation and the Distribution are prepared on a "carve-out" basis and include all amounts directly attributable to the Company. Net cash transfers and other property transferred between UTC and the Company, including related party receivables and payables between the Company and other UTC affiliates, are presented as Net transfers to UTC within UTC Net Investment in the accompanying Consolidated Financial Statements. In addition, the financial statements include allocations of costs for administrative functions and services performed on behalf of the Company by centralized groups within UTC. All allocations and estimates in the accompanying Consolidated Financial Statements are based on assumptions that management believes are reasonable. The allocated centralized costs for the year ended December 31, 2020 were $43 million and are primarily included in Selling, general and administrative in the accompanying Consolidated Statement of Operations.

[0001783180-23-000012:notes:14]
The Company's financial statements for the periods subsequent to April 3, 2020 are consolidated financial statements based on the reported results of Carrier as a stand-alone company. Following the Separation and Distribution, the Company entered into several agreements with UTC and Otis Worldwide Corporation ("Otis") that govern various aspects of the relationship among the Company, UTC and Otis. As of December 31, 2022, only the Tax Matters Agreement ("TMA") remains in effect. In addition, the Company incurred separation-related costs of $20 million and $141 million for the years ended December 31, 2021 and 2020, respectively. These costs are primarily included in Selling, general and administrative in the accompanying Consolidated Statement of Operations and consist of employee-related costs, costs to establish certain stand-alone functions and information technology systems, professional service fees and other transaction-related costs resulting from Carrier’s transition to becoming an independent, publicly traded company.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001783180-23-000012:notes:15]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES
A summary of significant accounting policies used in the preparation of the accompanying Consolidated Financial Statements is as follows:

[0001783180-23-000012:notes:16]
Use of Estimates. The preparation of the Consolidated Financial Statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and the disclosure of contingent assets and liabilities at the date of the financial statements as well as the reported amounts of revenues and expenses during the reporting period. Estimates are based on several factors including the facts and circumstances available at the time the estimates are made, historical experience and various other assumptions that are believed to be reasonable under the circumstances. Actual results could differ from those estimates.

[0001783180-23-000012:notes:17]
Currency Translation. Assets and liabilities of non-U.S. subsidiaries, where the functional currency is not the U.S. dollar, have been translated at year-end exchange rates, and income and expense accounts have been translated using average exchange rates throughout the year. Adjustments resulting from the process of translating an entity’s financial statements into the U.S. dollar have been recorded in the equity section of the Consolidated Balance Sheet within Accumulated other comprehensive income (loss). Transactions that are denominated in a currency other than an entity’s functional currency are subject to changes in exchange rates with the resulting gains and losses recorded in Net income from operations.

[0001783180-23-000012:notes:18]
Cash and Cash Equivalents. Cash and cash equivalents include cash on hand, demand deposits and short-term cash investments that are highly liquid in nature and have original maturities of three months or less. On occasion, the Company is required to maintain restricted cash deposits with certain banks due to contractual or other legal obligations. Restricted cash of $7 million and $39 million is included in Other assets, current as of December 31, 2022 and 2021, respectively.

[0001783180-23-000012:notes:19]
Accounts Receivable. Accounts receivable consist of billed amounts owed for products shipped to or services performed for customers. Amounts are recorded net of an allowance for expected credit losses which represents the best estimate of probable loss inherent in the Company's accounts receivable portfolio. The allowance is determined using a combination of factors including a reserve based on the aging of the outstanding accounts receivable portfolio and the Company's historical credit loss experience with its end markets, customer base and products. In addition, the Company considers knowledge of specific customers, current market conditions as well as reasonable and supportable forecasts of future events and economic conditions. As of December 31, 2022 and 2021, the allowance for expected credit losses was $117 million and $88 million, respectively. These estimates and assumptions are reviewed periodically with the effects of changes, if any, reflected in the Consolidated Statement of Operations in the period that they are determined.

[0001783180-23-000012:notes:20]
Fixed Assets. Property, plant and equipment are stated at cost less accumulated depreciation. Assets placed in service are recorded at cost and depreciated using the straight-line method over the estimated useful life of the asset. Assets acquired in a business combination are recorded at fair value at the date of acquisition. Major expenditures for replacements and significant improvements that increase asset values and extend useful lives are capitalized. Repairs and maintenance expenditures that do not extend the useful life of an asset are charged to expense as incurred.

[0001783180-23-000012:notes:21]
Per ASC 360, Property, Plant and Equipment ("ASC 360"), the Company assesses the recoverability of the carrying value of its property, plant and equipment whenever events or changes in circumstances indicate that the carrying amount of an asset group may not be recoverable. Recoverability is measured by a comparison of the carrying amount of an asset group to the future net undiscounted cash flows expected to be generated by the asset group. If the undiscounted cash flows are less than the carrying amount of the asset group, an impairment loss is recognized for the amount by which the carrying amount of the asset group exceeds the fair value of the asset group.

[0001783180-23-000012:notes:22]
Equity Method Investments. Investments in which the Company has the ability to exercise significant influence, but does not control, are accounted for under the equity method of accounting and are presented on the Consolidated Balance Sheet. Under this method of accounting, the Company’s share of the net earnings or losses of the investee is presented within Operating profit on the Consolidated Statement of Operations since the activities of the investee are closely aligned with the operations of the Company. The Company evaluates its equity method investments whenever events or changes in circumstance indicate that the carrying amounts of such investments may be impaired. If a decline in the value of an equity method investment is determined to be other than temporary, a loss is recorded in earnings in the current period. Distributions received from equity method investees are presented in the Consolidated Statement of Cash Flows based on the cumulative earnings approach.

[0001783180-23-000012:notes:23]
Goodwill and Intangible Assets. The Company records goodwill as the excess of the purchase price over the fair value of the net assets acquired in a business combination. In accordance with ASC 350, Intangibles - Goodwill and Other ("ASC 350"), goodwill and other indefinite-lived intangibles are tested and reviewed annually for impairment on July 1 or whenever there is a material change in events or circumstances that indicate that the fair value of the asset is more likely than not less than the carrying amount of the asset.

[0001783180-23-000012:notes:24]
Impairment of goodwill is assessed at the reporting unit level and begins with a qualitative assessment to determine if it is more likely than not that the fair value of each reporting unit is less than its carrying amount as a basis for determining whether it is necessary to perform the goodwill impairment test under ASC 350. For those reporting units that bypass or fail the qualitative assessment, the test compares the carrying amount of the reporting unit to its estimated fair value. If the estimated fair value of a reporting unit exceeds its carrying amount, goodwill of the reporting unit is not impaired. To the extent that the carrying amount of the reporting unit exceeds its estimated fair value, an impairment loss will be recognized for the amount by which the reporting unit's carrying amount exceeds its fair value, not to exceed the carrying amount of goodwill in that reporting unit.

[0001783180-23-000012:notes:25]
Intangible assets such as patents, service contracts, monitoring lines and customer relationships with finite useful lives are amortized based on the pattern in which the economic benefits of the intangible assets are consumed. If a pattern of economic benefit cannot be reliably determined or if straight-line amortization approximates the pattern of economic benefit, a straight-line amortization may be used.

[0001783180-23-000012:notes:26]
The range of useful lives approximate the following (in years):

[0001783180-23-000012:notes:27]
| Customer relationships | 1 to 30 |
| Patents and trademarks | 5 to 30 |
| Monitoring lines | 7 to 10 |
| Service portfolio and other | 1 to 23 |

[0001783180-23-000012:notes:28]
The Company assesses the recoverability of the carrying amount of its intangible assets with finite useful lives whenever events or changes in circumstances indicate that the carrying amount of the asset group may not be recoverable. Recoverability is measured by a comparison of the carrying amount of an asset group to the future net undiscounted cash flows expected to be generated by the asset group. If the undiscounted cash flows are less than the carrying amount of the asset group, an impairment loss is recognized for the amount by which the carrying value of the asset group exceeds the fair value of the asset group.

[0001783180-23-000012:notes:29]
Leases. The Company accounts for leases in accordance with ASC 842, Leases ("ASC 842"), which requires a lessee to record a right-of-use ("ROU") asset and a lease liability on the Consolidated Balance Sheet for all leases with terms longer than 12 months. ROU assets and liabilities are recognized at the commencement date based on the present value of lease payments over the lease term. The Company generally uses its incremental borrowing rate, which is based on information available at the lease commencement date, to determine the present value of lease payments except when an implicit interest rate is readily determinable. The lease term may include options to extend or terminate the lease when it is reasonably certain that the Company will exercise that option. The Company has elected not to recognize ROU assets and lease obligations for its short-term leases, which are defined as leases with an initial term of 12 months or less.

[0001783180-23-000012:notes:30]
Income Taxes. The Company accounts for income taxes in accordance with ASC 740, Income Taxes ("ASC 740"). Deferred tax assets and liabilities are determined based on temporary differences between financial reporting and tax bases of assets and liabilities, applying enacted tax rates expected to be in effect for the year in which the differences are expected to reverse. The Company recognizes future tax benefits to the extent that realizing these benefits is considered in its judgment to be more likely than not. For those jurisdictions where the expiration date of tax carryforwards or the projected operating results indicate that realization is not likely, a valuation allowance is provided. The Company reviews the realizability of its deferred tax asset valuation allowances on a quarterly basis, or whenever events or changes in circumstances indicate that a review is required and will adjust its estimate if significant events so dictate. To the extent that the ultimate results differ from the Company's original or adjusted estimates, the effect will be recorded in the provision for income taxes in the period that the matter is finally resolved.

[0001783180-23-000012:notes:31]
In the ordinary course of business, there is inherent uncertainty in quantifying the Company's income tax positions. The Company assesses its income tax positions and records tax benefits for all years subject to examination based upon management’s evaluation of the facts, circumstances and information available at the reporting date. For those tax positions where it is more likely than not that a tax benefit will be sustained, the Company has recorded the largest amount of tax benefit with a greater than 50% likelihood of being realized upon ultimate settlement with a taxing authority that has full knowledge of all relevant information. For those income tax positions where it is not more likely than not that a tax benefit will be sustained, no tax benefit has been recognized in the Consolidated Financial Statements.

[0001783180-23-000012:notes:32]
Prior to the Separation, the Company’s income tax provision was prepared following the separate return methodology. The separate return method applies ASC 740 to the financial statements of each member of a consolidated group as if the group members were separate taxpayers. As a result, certain operations of the Company were included in a consolidated return with other UTC entities. The calculation of the Company's income taxes on a separate return basis requires a considerable amount of judgment and use of both estimates and allocations. See Note 17 – Income Taxes for additional information.

[0001783180-23-000012:notes:33]
Pension and Post-retirement Obligations. The Company provides a range of benefit plans to eligible current and former employees. The Company accounts for its benefit plans in accordance with ASC 715, Compensation - Retirement Benefits ("ASC 715")  which requires balance sheet recognition of the overfunded or underfunded status of pension and post-retirement benefit plans. Determining the amounts associated with these benefits are performed by actuaries and dependent on various actuarial assumptions including discount rates, expected return on plan assets, compensation increases, mortality and health care cost trends. Actual results may differ from the actuarial assumptions and are generally recorded in Accumulated other comprehensive income (loss) and amortized into Net income from operations over future periods. The Company reviews its actuarial assumptions at each measurement date and makes modifications to the assumptions based on current rates and trends, if appropriate. See Note 10 – Employee Benefit Plans for additional information.

[0001783180-23-000012:notes:34]
Business Combinations. In accordance with ASC 805, Business Combinations ("ASC 805"), acquisitions that meet the definition of a business are recorded using the acquisition method of accounting. We recognize and measure the identifiable assets acquired, liabilities assumed and any non-controlling interest as of the acquisition date at fair value. The valuation of intangible assets is determined by an income approach methodology, using assumptions such as projected future revenues, customer attrition rates, royalty rates, tax rates and discount rates. The excess, if any, of total consideration transferred in a business combination over the fair value of identifiable assets acquired, liabilities assumed and any non-controlling interest is recognized as goodwill. Costs incurred as a result of a business combination other than costs related to the issuance of debt or equity securities are recorded in the period the costs are incurred.

[0001783180-23-000012:notes:35]
Asset Retirement Obligations. The Company records the fair value of legal obligations associated with the retirement of tangible long-lived assets in the period in which a liability is determined to exist, if a reasonable estimate of fair value can be made. Upon initial recognition of a liability, the Company capitalizes the cost of the asset retirement obligation by increasing the carrying amount of the related long-lived asset. Over time, the liability is increased for changes in its present value and the capitalized cost is depreciated over the useful life of the related asset.

[0001783180-23-000012:notes:36]
Research and Development. The Company conducts research and development activities with a focus on new product development and technology innovation. These costs are charged to expense as incurred. For the years ended December 31, 2022, 2021 and 2020, these costs amounted to $539 million, $503 million and $419 million, respectively.

[0001783180-23-000012:notes:37]
Recent Pronouncements

[0001783180-23-000012:notes:38]
The FASB ASC is the sole source of authoritative GAAP other than United States Securities and Exchange Commission ("SEC') issued rules and regulations that apply only to SEC registrants. The FASB issues Accounting Standards Updates ("ASU") to communicate changes to the codification. The Company considers the applicability and impact of all ASUs. ASUs not referenced below were assessed and determined to be either not applicable or are not expected to have a material impact on the Consolidated Financial Statements.

[0001783180-23-000012:notes:39]
Recently Adopted Accounting Pronouncements and SEC Rules

[0001783180-23-000012:notes:40]
In October 2021, the FASB issued ASU 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers, which updates the current guidance to require that an entity recognize and measure contract asset and contract liabilities acquired in a business combination consistent with those recorded by the acquiree immediately before the acquisition. The guidance eliminates the complexity of determining the fair value of contract liabilities and will likely increase the balance of contract liabilities acquired in a business combination with a corresponding increase in post-combination revenue recognized by the acquirer. The update is effective for fiscal years beginning after December 15, 2022 and interim periods therein, with early adoption permitted. In October 2021, the Company early adopted ASU 2021-08 and the adoption did not have a material impact on the Company's Consolidated Financial Statements.

[0001783180-23-000012:notes:41]
In December 2019, the FASB issued ASU 2019-12, Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes. The amendments in this update remove certain exceptions allowed by Topic 740 including exceptions to the incremental approach for intra-period tax allocation when there is a loss from continuing operations and income or gain from other items, the requirement to recognize a deferred tax liability for equity method investments when a foreign subsidiary becomes an equity method investment, the ability not to recognize a deferred tax liability for a foreign subsidiary when a foreign equity method investment becomes a subsidiary and the general methodology for calculating income taxes in an interim period when a year-to-date loss exceeds the anticipated loss for the year. There are also additional areas of guidance in regards to franchise and other taxes partially based on income and the interim recognition of enactment of tax laws and rate changes. The provisions of this ASU were effective for years beginning after December 15, 2020, with early adoption permitted. The Company adopted ASU 2019-12 in the first quarter of 2021 and the adoption did not have a material impact on the Company's Consolidated Financial Statements.

[0001783180-23-000012:notes:42]
In May 2020, the SEC issued Final Rule Release No. 33-10786, which amends the financial statement requirements for acquisitions and dispositions of businesses and related pro forma financial information required under SEC Regulation S-X, Rule 3-05. The final rule modifies the significance test required in SEC Regulation S-X, Rule 1-02(w) by raising the significance threshold for reporting dispositions of a business from 10% to 20% and by modifying the calculation of the investment and income tests. In accordance with Rules 3-09 or 4-08(g), the revised income test will apply to the evaluation of equity method investments for significance. The Company adopted these modifications, which were effective for fiscal years

[0001783180-23-000012:notes:43]
beginning after December 31, 2020. The adoption of these amendments did not have a material impact on the Consolidated Financial Statements.

[0001783180-23-000012:notes:44]
In November 2020, the SEC issued Final Rule Release No. 33-10980, which amends the requirements for providing selected quarterly financial data, contractual obligations and management discussion and analysis. These modifications were required after August 9, 2021. The Company applied the requirements of this release in its 2021 Annual Report on Form 10-K.


## us-gaap:ScheduleOfFiniteLivedIntangibleAssetsTableTextBlock

[0001783180-23-000012:notes:45]
Identifiable intangible assets consisted of the following:

[0001783180-23-000012:notes:46]
|  |  |  | 2022 |  | 2021 |
| (In millions) |  |  | Gross Amount |  | Accumulated Amortization |  | Net Amount |  | Gross Amount |  | Accumulated Amortization |  | Net Amount |
| Amortized: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  |  | $ | 1,431 |  |  | $ | (720) |  |  | $ | 711 |  |  | $ | 945 |  |  | $ | (699) |  |  | $ | 246 |  |
| Patents and trademarks |  |  | 401 |  |  | (191) |  |  | 210 |  |  | 232 |  |  | (182) |  |  | 50 |  |
| Service portfolios and other |  |  | 953 |  |  | (595) |  |  | 358 |  |  | 688 |  |  | (539) |  |  | 149 |  |
|  |  |  | 2,785 |  |  | (1,506) |  |  | 1,279 |  |  | 1,865 |  |  | (1,420) |  |  | 445 |  |
| Unamortized: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Trademarks and other |  |  | 63 |  |  | — |  |  | 63 |  |  | 64 |  |  | — |  |  | 64 |  |
| Intangible assets, net |  |  | $ | 2,848 |  |  | $ | (1,506) |  |  | $ | 1,342 |  |  | $ | 1,929 |  |  | $ | (1,420) |  |  | $ | 509 |  |


## us-gaap:InventoryDisclosureTextBlock

[0001783180-23-000012:notes:47]
INVENTORIES, NET 
Inventories are stated at the lower of cost or estimated net realizable value. Cost is primarily determined based on the first-in, first-out inventory method ("FIFO") or average cost methods, which approximates current replacement cost. However, certain Carrier entities use the last-in, first-out inventory method ("LIFO").

[0001783180-23-000012:notes:48]
Inventories, net consisted of the following:

[0001783180-23-000012:notes:49]
| (In millions) | 2022 |  | 2021 |
| Raw materials | $ | 884 |  |  | $ | 559 |  |
| Work-in-process | 230 |  |  | 197 |  |
| Finished goods | 1,526 |  |  | 1,214 |  |
| Inventories, net | $ | 2,640 |  |  | $ | 1,970 |  |

[0001783180-23-000012:notes:50]
The Company performs periodic assessments utilizing customer demand, production requirements and historical usage rates to determine the existence of excess and obsolete inventory and records necessary provisions to reduce such inventories to the lower of cost or estimated net realizable value. Raw materials, work-in-process and finished goods are net of valuation reserves of $190 million and $154 million as of December 31, 2022 and 2021, respectively.

[0001783180-23-000012:notes:51]
Certain entities use LIFO to determine the cost of inventory. If inventories that were valued using the LIFO method had been valued under the FIFO method, the net book value of the inventories would have been higher by $199 million and $141 million as of December 31, 2022 and 2021, respectively. As of December 31, 2022 and 2021, approximately 26% and 31%, respectively, of all inventory utilized the LIFO method.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001783180-23-000012:notes:52]
FIXED ASSETS, NET 
Fixed assets, net consisted of the following:

[0001783180-23-000012:notes:53]
| (In millions) | Estimated Useful Lives (Years) |  | 2022 |  | 2021 |
| Land |  |  | $ | 126 |  |  | $ | 114 |  |
| Buildings and improvements | 20 to 40 |  | 1,251 |  |  | 1,084 |  |
| Machinery, tools and equipment | 3 to 25 |  | 2,409 |  |  | 2,093 |  |
| Rental assets | 3 to 12 |  | 390 |  |  | 381 |  |
| Other, including assets under construction |  |  | 347 |  |  | 304 |  |
| Fixed assets, gross |  |  | 4,523 |  |  | 3,976 |  |
| Accumulated depreciation |  |  | (2,282) |  |  | (2,150) |  |
| Fixed assets, net |  |  | $ | 2,241 |  |  | $ | 1,826 |  |

[0001783180-23-000012:notes:54]
Depreciation expense was $256 million, $238 million and $234 million for the years ended December 31, 2022, 2021 and 2020, respectively.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001783180-23-000012:notes:55]
GOODWILL AND INTANGIBLE ASSETS The Company records goodwill as the excess of the purchase price over the fair value of the net assets acquired in a business combination. Goodwill is tested and reviewed annually for impairment on July 1 or whenever there is a material change in events or circumstances that indicates that the fair value of the reporting unit may be less than its carrying value.
The changes in the carrying amount of goodwill were as follows:

[0001783180-23-000012:notes:56]
| (In millions) | HVAC |  | Refrigeration |  | Fire & Security |  | Total |
| Balance as of December 31, 2020 | $ | 5,489 |  |  | $ | 1,251 |  |  | $ | 3,399 |  |  | $ | 10,139 |  |
| Goodwill resulting from business combinations (1) | 261 |  |  | (1) |  |  | 60 |  |  | 320 |  |
| Reclassified to held for sale (2) | — |  |  | — |  |  | (940) |  |  | (940) |  |
| Foreign currency translation | (92) |  |  | (22) |  |  | (56) |  |  | (170) |  |
| Balance as of December 31, 2021 | $ | 5,658 |  |  | $ | 1,228 |  |  | $ | 2,463 |  |  | $ | 9,349 |  |
| Goodwill resulting from business combinations (1) | 904 |  |  | — |  |  | 1 |  |  | 905 |  |
| Foreign currency translation | (170) |  |  | (31) |  |  | (76) |  |  | (277) |  |
| Balance as of December 31, 2022 | $ | 6,392 |  |  | $ | 1,197 |  |  | $ | 2,388 |  |  | $ | 9,977 |  |

[0001783180-23-000012:notes:57]
(1) See Note 19 - Acquisitions for additional information.

[0001783180-23-000012:notes:58]
(2) See Note 20 - Divestitures for additional information.

[0001783180-23-000012:notes:59]
Indefinite-lived intangible assets are tested and reviewed annually for impairment on July 1 or whenever there is a material change in events or circumstances that indicates that the fair value of the asset may be less than the carrying amount of the asset. All other intangible assets with finite useful lives are amortized over their estimated useful lives.

[0001783180-23-000012:notes:60]
Amortization of intangible assets was $124 million, $98 million and $102 million for the years ended December 31, 2022, 2021 and 2020, respectively.

[0001783180-23-000012:notes:61]
The estimated future amortization of intangible assets is as follows:

[0001783180-23-000012:notes:62]
| (In millions) | 2023 |  | 2024 |  | 2025 |  | 2026 |  | 2027 |
| Future amortization | $ | 246 |  |  | $ | 194 |  |  | $ | 170 |  |  | $ | 136 |  |  | $ | 99 |  |

[0001783180-23-000012:notes:63]
Annual Impairment Assessment

[0001783180-23-000012:notes:64]
The Company tested its goodwill and indefinite-lived intangible assets for impairment as part of its annual assessment. For each test except one, the Company qualitatively assessed all relevant events or circumstances that could impact the estimate of fair value and determined it was more likely than not that the fair value of each reporting unit and indefinite-lived intangible asset exceeded their carrying amount. The remaining test related to the TCC acquisition and the subsequent reorganization of the Company's Commercial HVAC reporting unit in order to create a separate Global Comfort Solutions reporting unit. As a result, the Company performed a quantitative goodwill impairment test on its Commercial HVAC reporting unit prior to the reorganization, the results of which did not indicate any goodwill impairment. The Company then reassigned goodwill among its Commercial HVAC and Global Comfort Solutions reporting units using a relative fair value approach and performed a goodwill impairment assessment. The results did not indicate any goodwill impairment.


## us-gaap:DebtDisclosureTextBlock

[0001783180-23-000012:notes:65]
BORROWINGS AND LINES OF CREDIT 
Long-term debt consisted of the following:

[0001783180-23-000012:notes:66]
| (In millions) |  |  |  | 2022 |  | 2021 |
| 2.242% Notes due February 15, 2025 |  |  |  | 1,200 |  |  | 2,000 |  |
| 2.493% Notes due February 15, 2027 |  |  |  | 900 |  |  | 1,250 |  |
| 2.722% Notes due February 15, 2030 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.700% Notes due February 15, 2031 |  |  |  | 750 |  |  | 750 |  |
| 3.377% Notes due April 5, 2040 |  |  |  | 1,500 |  |  | 1,500 |  |
| 3.577% Notes due April 5, 2050 |  |  |  | 2,000 |  |  | 2,000 |  |
| Total long-term notes |  |  |  | 8,350 |  |  | 9,500 |  |
| Japanese Term Loan Facility |  |  |  | 404 |  |  | — |  |
| Other debt (including project financing obligations and finance leases) |  |  |  | 149 |  |  | 267 |  |
| Discounts and debt issuance costs |  |  |  | (61) |  |  | (71) |  |
| Total debt |  |  |  | 8,842 |  |  | 9,696 |  |
| Less: current portion of long-term debt |  |  |  | 140 |  |  | 183 |  |
| Long-term debt, net of current portion |  |  |  | $ | 8,702 |  |  | $ | 9,513 |  |

[0001783180-23-000012:notes:67]
Japanese Term Loan Facility

[0001783180-23-000012:notes:68]
On July 15, 2022, the Company entered into a five-year, JPY 54 billion (approximately $400 million) senior unsecured term loan facility with MUFG Bank Ltd., as administrative agent and lender, and certain other lenders (the "Japanese Term Loan Facility"). Borrowings under the Japanese Term Loan Facility bear interest at a rate equal to the Tokyo Term Risk Free Rate plus 0.75%. In addition, the Japanese Term Loan Facility is subject to customary covenants including a covenant to maintain a maximum consolidated leverage ratio. On July 25, 2022, the Company borrowed JPY 54 billion under the Japanese Term Loan Facility and used the proceeds to fund a portion of the TCC acquisition and to pay related fees and expenses.

[0001783180-23-000012:notes:69]
Revolving Credit Facility

[0001783180-23-000012:notes:70]
On February 10, 2020, the Company entered into a revolving credit agreement with various banks permitting aggregate borrowings of up to $2.0 billion pursuant to an unsecured, unsubordinated revolving credit facility that matures on April 3, 2025 (the "Revolving Credit Facility"). The Revolving Credit Facility supports the Company's commercial paper program and cash requirements of the Company. A commitment fee of 0.125% is charged on unused commitments. Borrowings under the Revolving Credit Facility are available in U.S. Dollars, Euros and Pounds Sterling. Pounds Sterling borrowings bear interest at a variable interest rate based on daily simple SONIA plus 0.0326%, Euro borrowings bear interest at EURIBOR rates and U.S. Dollar borrowings bear interest at LIBOR plus a ratings-based margin, which was 125 basis points as of December 31, 2022. As of December 31, 2022, there were no borrowings outstanding under the Revolving Credit Facility.

[0001783180-23-000012:notes:71]
Commercial Paper Program

[0001783180-23-000012:notes:72]
The Company has a $2.0 billion unsecured, unsubordinated commercial paper program, which can be used for general corporate purposes, including the funding of working capital and potential acquisitions. As of December 31, 2022, there were no borrowings outstanding under the commercial paper program.

[0001783180-23-000012:notes:73]
Project Financing Arrangements

[0001783180-23-000012:notes:74]
The Company is involved in long-term construction contracts in which it arranges project financing with certain customers. As a result, the Company issued $38 million and $124 million of debt during the year ended December 31, 2022 and 2021, respectively. Long-term debt repayments associated with these financing arrangements for the years ended December 31, 2022 and 2021 were $160 million and $181 million, respectively.

[0001783180-23-000012:notes:75]
Debt Covenants

[0001783180-23-000012:notes:76]
The Revolving Credit Facility, the indenture for the long-term Notes and the Japanese Term Loan Facility contain affirmative and negative covenants customary for financings of these types, which, among other things, limit the Company's ability to incur additional liens, to make certain fundamental changes and to enter into sale and leaseback transactions. As of December 31, 2022, the Company was in compliance with the covenants under the agreements governing its outstanding indebtedness.

[0001783180-23-000012:notes:77]
Tender Offers

[0001783180-23-000012:notes:78]
On March 15, 2022, the Company commenced tender offers to purchase up to $1.15 billion ("Aggregate Tender Cap") aggregate principal of the Company's 2.242% Notes due 2025 and 2.493% Notes due 2027 (together, the "Senior Notes"). The tender offers included payment of applicable accrued and unpaid interest up to the settlement date, along with a fixed spread for early repayment. Based on participation, the Company elected to settle the tender offers on March 30, 2022. The aggregate principal amount of Senior Notes validly tendered and accepted was approximately $1.15 billion, which included $800 million of Notes due 2025 and $350 million of Notes due 2027. As a result, the Company recognized a net gain of $33 million and wrote off $5 million of unamortized deferred financing costs within Interest (expense) income, net on the accompanying Consolidated Statement of Operations during the year ended December 31, 2022.

[0001783180-23-000012:notes:79]
Schedule of Long-term Debt Maturities

[0001783180-23-000012:notes:80]
Scheduled maturities of long-term debt, excluding amortization of discount, are as follows:

[0001783180-23-000012:notes:81]
| (In millions) |  |  |
| 2023 |  | $ | 140 |  |
| 2024 |  | $ | 2 |  |
| 2025 |  | $ | 1,202 |  |
| 2026 |  | $ | 2 |  |
| 2027 |  | $ | 1,306 |  |
| Thereafter |  | $ | 6,251 |  |

[0001783180-23-000012:notes:82]
As of December 31, 2022, the average maturity of the Company's long-term notes is approximately 12 years and the weighted-average interest rate on its total borrowings is approximately 2.9%. Interest expense associated with long-term debt for the years ended December 31, 2022, 2021 and 2020 was $302 million, $319 million and $298 million, respectively.


## us-gaap:FairValueDisclosuresTextBlock

[0001783180-23-000012:notes:83]
FAIR VALUE MEASUREMENTS
ASC 820, Fair Value Measurement ("ASC 820"), defines fair value as the price that would be received if an asset is sold or the price paid to transfer a liability in an orderly transaction between market participants at the measurement date. ASC 820 also establishes a three-level fair value hierarchy that prioritizes information used in developing assumptions when pricing an asset or liability as follows:

[0001783180-23-000012:notes:84]
•Level 1: Observable inputs such as quoted prices in active markets;

[0001783180-23-000012:notes:85]
•Level 2: Inputs, other than quoted prices in active markets, that are observable either directly or indirectly; and

[0001783180-23-000012:notes:86]
•Level 3: Unobservable inputs where there is little or no market data, which requires the reporting entity to develop its own assumptions.

[0001783180-23-000012:notes:87]
ASC 820 requires the use of observable market data, when available, in making fair value measurements. When inputs used to measure fair value fall within different levels of the hierarchy, the level within which the fair value measurement is categorized is based on the lowest level input that is significant to the fair value measurement.

[0001783180-23-000012:notes:88]
In the normal course of business, the Company is exposed to certain risks arising from business operations and economic factors, including foreign currency and commodity price risk. These exposures are managed through operational strategies and the use of undesignated hedging contracts. The Company's derivative assets and liabilities are measured at fair value on a recurring basis using internal models based on observable market inputs, such as forward, interest, contract and discount rates with changes in fair value reported in earnings in the accompanying Consolidated Statement of Operations.

[0001783180-23-000012:notes:89]
In connection with the TCC acquisition, the Company funded a portion of the Yen-denominated purchase price with cash on hand by entering into cross currency swaps with SMBC Capital Markets, Inc., as syndication swap arranger, and certain other financial institutions. The fair value of the cross currency swaps are measured at fair value on a recurring basis using observable market inputs, such as forward, discount and interest rates as well as credit default swap spreads. The Company designated the cross currency swaps as a partial hedge of its investment in certain subsidiaries whose functional currency is the Japanese Yen in order to manage foreign currency translation risk. As a result, changes in the fair value of the swaps are recorded in Equity in the accompanying Consolidated Balance Sheet.

[0001783180-23-000012:notes:90]
The remaining portion of the Yen-denominated purchase price was funded by the Japanese Term Loan Facility. The carrying value of the facility is translated on a recurring basis using the exchange rate at the end of the applicable period and approximates its fair value. The Company designated the Japanese Term Loan Facility as a partial hedge of its investment in certain subsidiaries whose functional currency is the Japanese Yen in order to manage foreign currency translation risk. As a result, changes in the carrying value of the Japanese Term Loan Facility associated with foreign exchange rate movements are recorded in Equity in the Consolidated Balance Sheet.

[0001783180-23-000012:notes:91]
The following tables provide the valuation hierarchy classification of assets and liabilities that are recorded at fair value and measured on a recurring basis in the accompanying Consolidated Balance Sheet:

[0001783180-23-000012:notes:92]
| (In millions) |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |
| December 31, 2022 |  |  |  |  |  |  |  |  |
| Fair value measurement: |  |  |  |  |  |  |  |  |
| Derivative assets (1)(3) |  | $ | 28 |  |  | $ | — |  |  | $ | 28 |  |  | $ | — |  |
| Derivative liabilities (2)(3) |  | $ | (48) |  |  | $ | — |  |  | $ | (48) |  |  | $ | — |  |
| December 31, 2021 |  |  |  |  |  |  |  |  |
| Fair value measurement: |  |  |  |  |  |  |  |  |
| Derivative assets (1) |  | $ | 8 |  |  | $ | — |  |  | $ | 8 |  |  | $ | — |  |
| Derivative liabilities (2) |  | $ | (35) |  |  | $ | — |  |  | $ | (35) |  |  | $ | — |  |

[0001783180-23-000012:notes:93]
(1) Included in Other assets, current on the accompanying Consolidated Balance Sheet.

[0001783180-23-000012:notes:94]
(2) Included in Accrued liabilities on the accompanying Consolidated Balance Sheet.

[0001783180-23-000012:notes:95]
(3) Includes cross currency swaps.

[0001783180-23-000012:notes:96]
The following table provides the carrying amounts and fair values of the Company's long-term notes that are not recorded at fair value in the accompanying Consolidated Balance Sheet:

[0001783180-23-000012:notes:97]
|  |  | 2022 |  | 2021 |
| (In millions) |  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |
| Total long-term notes (1) |  | $ | 8,350 |  |  | $ | 6,832 |  |  | $ | 9,500 |  |  | $ | 9,842 |  |

[0001783180-23-000012:notes:98]
(1) Excludes debt discount and issuance costs.

[0001783180-23-000012:notes:99]
The fair value of the Company's long-term debt is measured based on observable market inputs which are considered Level 1 within the fair value hierarchy. The carrying value of cash and cash equivalents, accounts receivable, accounts payable and short-term borrowings approximate fair value due to the short-term nature of these accounts and would be classified as Level 1 in the fair value hierarchy. The Company's financing leases and project financing obligations, included in Long-term debt and Current portion of long-term debt on the accompanying Consolidated Balance Sheet, approximate fair value and are classified as Level 3 in the fair value hierarchy.


## us-gaap:LesseeFinanceLeasesTextBlock

[0001783180-23-000012:notes:100]
LEASES The Company enters into operating and finance leases for the use of real estate space, vehicles, information technology equipment and certain other equipment. At contract inception, the Company determines a lease exists if the arrangement conveys the right to control an identified asset for a period of time in exchange for consideration. Control is considered to exist when the lessee has the right to obtain substantially all of the economic benefits from the use of an identified asset as well as the right to direct the use of that asset. If a contract is considered to be a lease, the Company recognizes a lease liability based on 
the present value of the future lease payments with an offsetting entry to recognize a ROU asset.

[0001783180-23-000012:notes:101]
Operating lease ROU assets and liabilities are reflected on the Consolidated Balance Sheet as follows:

[0001783180-23-000012:notes:102]
| (In millions) |  | 2022 |  | 2021 |
| Operating lease right-of-use assets |  | $ | 642 |  |  | $ | 640 |  |
| Accrued liabilities |  | $ | (132) |  |  | $ | (130) |  |
| Operating lease liabilities |  | (529) |  |  | (527) |  |
| Total operating lease liabilities |  | $ | (661) |  |  | $ | (657) |  |
| Weighted-Average Remaining Lease Term (in years) |  | 7.7 |  | 7.8 |
| Weighted-Average Discount Rate |  | 3.4 | % |  | 3.0 | % |

[0001783180-23-000012:notes:103]
The operating lease ROU assets include any lease payments related to initial direct costs and prepayments and excludes lease incentives. The Company's leases generally have remaining lease terms of 1 to 26 years, some of which include options to extend. For the majority of its leases with options to extend, those options are up to 5 years with the ability to terminate the lease within 1 to 5 years of inception. The exercise of lease renewal options is at the Company's sole discretion and its lease ROU assets and liabilities reflect only the options the Company is reasonably certain that it will exercise.

[0001783180-23-000012:notes:104]
Supplemental cash flow and lease expense information related to operating leases were as follows:

[0001783180-23-000012:notes:105]
| (In millions) |  | 2022 |  | 2021 |  | 2020 |
| Operating cash flows for measurement of operating lease liabilities |  | $ | 145 |  |  | $ | 197 |  |  | $ | 213 |  |
| Operating lease ROU assets obtained in exchange for operating lease obligations |  | $ | 109 |  |  | $ | 180 |  |  | $ | 169 |  |
| Operating lease expense |  | $ | 148 |  |  | $ | 200 |  |  | $ | 197 |  |

[0001783180-23-000012:notes:106]
Operating lease expense is recognized on a straight-line basis over the lease term. Where applicable, the Company accounts for each separate lease component of a contract and its associated non-lease component as a single lease component.

[0001783180-23-000012:notes:107]
Undiscounted maturities of operating lease liabilities, including options to extend lease terms that are reasonably certain of being exercised, as of December 31, 2022 are as follows:

[0001783180-23-000012:notes:108]
| (In millions) |  |  |
| 2023 |  | $ | 153 |  |
| 2024 |  | 132 |  |
| 2025 |  | 106 |  |
| 2026 |  | 83 |  |
| 2027 |  | 59 |  |
| Thereafter |  | 231 |  |
| Total undiscounted lease payments |  | 764 |  |
| Less: imputed interest |  | (103) |  |
| Total discounted lease payments |  | $ | 661 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001783180-23-000012:notes:109]
EMPLOYEE BENEFIT PLANS The Company sponsors both funded and unfunded domestic and international defined benefit pension and defined contribution plans. In addition, the Company contributes to various domestic and international multi-employer defined benefit pension plans.
Pension Plans

[0001783180-23-000012:notes:110]
Qualified domestic pension plan benefits covering collectively bargained U.S. employees comprise approximately 29% of the projected benefit obligation. This noncontributory defined benefit plan provides benefits on a flat dollar formula based on an employee's location and is closed to new entrants. The non-U.S. plans comprise approximately 71% of the projected benefit obligation; certain of these plans provide participants with one-time payments upon separation of employment rather than a retirement annuity. These plans provide benefits based on a plan specific benefit formula. Non-qualified domestic pension plans provide supplementary retirement benefits to certain employees and are not a material component of the projected benefit obligation.

[0001783180-23-000012:notes:111]
The following table details information regarding the Company's pension plans:

[0001783180-23-000012:notes:112]
| (In millions) | 2022 |  | 2021 |
| Change in Benefit Obligation |  |  |  |
| Benefit obligation at beginning of year | $ | 906 |  |  | $ | 3,224 |  |
| Service cost | 20 |  |  | 27 |  |
| Interest cost | 18 |  |  | 37 |  |
| Actuarial (gain) loss (1) | (271) |  |  | (112) |  |
| Benefits paid | (21) |  |  | (106) |  |
| Curtailment, settlements and special termination benefits | (7) |  |  | (54) |  |
| Other, including expenses paid | (38) |  |  | (48) |  |
| Liabilities held for sale (2) | — |  |  | (2,062) |  |
| Acquisitions (3) | 153 |  |  | — |  |
| Benefit obligation at end of year | $ | 760 |  |  | $ | 906 |  |
| Change in Plan Assets |  |  |  |
| Fair value at beginning of year | $ | 591 |  |  | $ | 3,294 |  |
| Actual return on plan assets | (170) |  |  | 67 |  |
| Company contributions | 16 |  |  | 47 |  |
| Benefits paid | (21) |  |  | (106) |  |
| Settlements | (7) |  |  | (54) |  |
| Other, including expenses paid | (18) |  |  | (34) |  |
| Assets held for sale (2) | — |  |  | (2,623) |  |
| Acquisitions (3) | 60 |  |  | — |  |
| Fair value of assets end of year | $ | 451 |  |  | $ | 591 |  |
| Funded status of plans | $ | (309) |  |  | $ | (315) |  |
| Amounts included in the balance sheet: |  |  |  |
| Other non-current assets | $ | 25 |  |  | $ | 43 |  |
| Accrued compensation and benefits | (18) |  |  | (10) |  |
| Post-employment and other benefit liabilities | (316) |  |  | (348) |  |
| Net amount recognized | $ | (309) |  |  | $ | (315) |  |

[0001783180-23-000012:notes:113]
(1) Reflects the impact of foreign exchange translation, primarily for plans in the United Kingdom, Canada and Germany.

[0001783180-23-000012:notes:114]
(3) See Note 19 - Acquisitions for additional information.

[0001783180-23-000012:notes:115]
All plans experienced an improvement in the net deficit position due to a significant increase in the discount rates used to measure the benefit obligations of the plans. Discount rates increased over the measurement period as a result of increases in corporate bond yields. The reduction in the benefit obligation was partially offset by lower plan asset performance. In addition, the acquisition of TCC on August 1, 2022 contributed to the change in the funded position.

[0001783180-23-000012:notes:116]
The pretax amounts recognized in Accumulated other comprehensive (income) loss are:

[0001783180-23-000012:notes:117]
| (In millions) |  | Prior Service Cost (Benefit) |  | Net Actuarial (Gain) Loss |  | Total |
| As of December 31, 2021 |  | $ | 15 |  |  | $ | 595 |  |  | $ | 610 |  |
| Current year changes recorded in AOCI |  | (2) |  |  | (476) |  |  | (478) |  |
| Amortization reclassified to earnings |  | (2) |  |  | (9) |  |  | (11) |  |
| Settlement/curtailment reclassified to earnings |  | — |  |  | (2) |  |  | (2) |  |
| Currency translation and other |  | — |  |  | (15) |  |  | (15) |  |
| As of December 31, 2022 |  | $ | 11 |  |  | $ | 93 |  |  | $ | 104 |  |

[0001783180-23-000012:notes:118]
Information for pension plans with accumulated benefit obligations in excess of plan assets:

[0001783180-23-000012:notes:119]
| (In millions) | 2022 |  | 2021 |
| Projected benefit obligation | $ | 564 |  |  | $ | 405 |  |
| Accumulated benefit obligation | $ | 538 |  |  | $ | 374 |  |
| Fair value of plan assets | $ | 230 |  |  | $ | 47 |  |

[0001783180-23-000012:notes:120]
Information for pension plans with projected benefit obligations in excess of plan assets:

[0001783180-23-000012:notes:121]
The components of net periodic pension expense (benefit) for the defined benefit pension plans are as follows:

[0001783180-23-000012:notes:122]
| (In millions) | 2022 (1) |  | 2021 |  | 2020 |  |  |  |  |
| Service cost | $ | 20 |  |  | $ | 27 |  |  | $ | 29 |  |  |  |  |  |
| Interest cost | 18 |  |  | 37 |  |  | 52 |  |  |  |  |  |
| Expected return on plan assets | (27) |  |  | (145) |  |  | (140) |  |  |  |  |  |
| Amortization of prior service cost | 2 |  |  | 2 |  |  | 2 |  |  |  |  |  |
| Recognized actuarial net loss | 9 |  |  | 32 |  |  | 22 |  |  |  |  |  |
| Net settlement, curtailment and special termination benefit loss | 2 |  |  | 13 |  |  | 4 |  |  |  |  |  |
| Net periodic pension expense (benefit) | $ | 24 |  |  | $ | (34) |  |  | $ | (31) |  |  |  |  |  |

[0001783180-23-000012:notes:123]
(1) See Note 20 - Divestitures for additional information.

[0001783180-23-000012:notes:124]
The accumulated benefit obligation for all defined benefit plans was $0.7 billion and $0.9 billion as of December 31, 2022 and 2021, respectively.

[0001783180-23-000012:notes:125]
Major assumptions used in determining the benefit obligation and net cost for pension plans are presented in the following table as weighted-averages:

[0001783180-23-000012:notes:126]
|  |  | Benefit Obligation |  | Net Costs |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |  | 2020 |  |
| Discount rate |  |  |  |  |  |  |  |  |  |  |  |
| Projected benefit obligation | 4.2% |  | 2.1 | % |  | 2.1% |  | 1.4 | % |  | 2.0 | % |  |
| Interest cost (1) |  | —% |  | — | % |  | 1.9% |  | 1.2 | % |  | 1.8 | % |  |
| Service cost (1) |  | —% |  | — | % |  | 2.8% |  | 2.1 | % |  | 1.8 | % |  |
| Salary scale |  | 2.4% |  | 3.1 | % |  | 3.1% |  | 2.8 | % |  | 3.3 | % |  |
| Expected return on plan assets | —% |  | — | % |  | 5.0% |  | 4.6 | % |  | 4.9 | % |  |

[0001783180-23-000012:notes:127]
(1) The 2022 and 2021 discount rates used to measure the service cost and interest cost applies to the significant plans of the Company. The projected benefit obligation discount rate is used for the service cost and interest cost measurements for non-significant plans.

[0001783180-23-000012:notes:128]
The weighted-average discount rates used to measure pension benefit obligations and net costs are set by reference to specific analyses using each plan’s specific cash flows and high-quality bond indices to assess reasonableness. For those significant plans, the Company utilizes a full yield curve approach in the estimation of the service cost and interest cost components by applying the specific spot rates along the yield curve used in determination of the benefit obligation to the relevant projected cash flows.

[0001783180-23-000012:notes:129]
In determining the expected return on plan assets, the Company considered the relative weighting of plan assets, the historical performance of total plan assets and individual asset classes and economic and other indicators of future performance. Return projections are assessed for reasonableness using a simulation model that incorporates yield curves, credit spreads and risk premiums to project long-term prospective returns.

[0001783180-23-000012:notes:130]
The plans’ investment management objectives include providing the liquidity and asset levels needed to meet current and future benefit payments, while maintaining a prudent degree of portfolio diversification considering interest rate risk and market volatility. Globally, investment strategies target a mix of approximately 50% of growth seeking assets and 50% of income generating and hedging assets using a wide diversification of asset types, fund strategies and investment managers. The growth seeking allocation consists of global public equities in developed and emerging countries and alternative-asset class strategies. Within the income generating assets, the fixed income portfolio primarily consists of government and broadly diversified high quality corporate bonds.

[0001783180-23-000012:notes:131]
The plans seek to reduce interest rate risk and have incorporated liability hedging programs that include the adoption of a risk reduction objective as part of the long-term investment strategy. Under this objective, the income generating and hedging assets typically increase as funded status improves. The hedging programs incorporate a range of assets and investment tools, each with various interest rate sensitivities. As a result of the improved funded status of the plans, due to favorable asset returns and funding of the plans, the income generating and hedging assets increased in recent years.

[0001783180-23-000012:notes:132]
The fair values of pension plan assets by asset category are as follows:

[0001783180-23-000012:notes:133]
|  |  | Quoted Prices in Active Markets for Identical Assets |  | Significant Observable Inputs |  | Significant Unobservable Inputs |  | Not Subject |  |  |
| (In millions) |  | (Level 1) |  | (Level 2) |  | (Level 3) |  | to Leveling |  | Total |
| Asset Category |  |  |  |  |  |  |  |  |  |  |
| Public Equities: |  |  |  |  |  |  |  |  |  |  |
| Global Equities |  | $ | — |  |  | $ | 27 |  |  | $ | — |  |  | $ | — |  |  | $ | 27 |  |
| Global Equity Funds at net asset value (1) (2) |  | — |  |  | — |  |  | — |  |  | 119 |  |  | 119 |  |
| Fixed Income Securities: |  |  |  |  |  |  |  |  |  |  |
| Governments |  | — |  |  | 35 |  |  | — |  |  | 24 |  |  | 59 |  |
| Corporate Bonds |  | — |  |  | 45 |  |  | — |  |  | — |  |  | 45 |  |
| Fixed Income Securities (2) |  | — |  |  | 11 |  |  | — |  |  | 156 |  |  | 167 |  |
| Real Estate (3) |  | — |  |  | 1 |  |  | — |  |  | — |  |  | 1 |  |
| Other (4) (5) |  | — |  |  | 8 |  |  | — |  |  | — |  |  | 8 |  |
| Cash & Cash Equivalents (2)(6) |  | — |  |  | 25 |  |  | — |  |  | 1 |  |  | 26 |  |
| Subtotal |  | $ | — |  |  | $ | 152 |  |  | $ | — |  |  | $ | 300 |  |  | $ | 452 |  |
| Other assets and liabilities (7) |  |  |  |  |  |  |  |  |  | (1) |  |
| Total as of December 31, 2022 |  |  |  |  |  |  |  |  |  | $ | 451 |  |
|  |  | Quoted Prices in Active Markets for Identical Assets |  | Significant Observable Inputs |  | Significant Unobservable Inputs |  | Not Subject |  |  |
| (In millions) |  | (Level 1) |  | (Level 2) |  | (Level 3) |  | to Leveling |  | Total |
| Asset Category |  |  |  |  |  |  |  |  |  |  |
| Public Equities: |  |  |  |  |  |  |  |  |  |  |
| Global Equities |  | $ | — |  |  | $ | 29 |  |  | $ | — |  |  | $ | — |  |  | $ | 29 |  |
| Global Equity Funds at net asset value (1) (2) |  | — |  |  | — |  |  | — |  |  | 208 |  |  | 208 |  |
| Fixed Income Securities: |  |  |  |  |  |  |  |  |  |  |
| Governments |  | — |  |  | 26 |  |  | — |  |  | — |  |  | 26 |  |
| Corporate Bonds |  | — |  |  | 103 |  |  | — |  |  | — |  |  | 103 |  |
| Fixed Income Securities (2) |  | — |  |  | — |  |  | — |  |  | 189 |  |  | 189 |  |
| Real Estate (3) |  | — |  |  | 9 |  |  | — |  |  | — |  |  | 9 |  |
| Other (4)(5) |  | — |  |  | 5 |  |  | — |  |  | — |  |  | 5 |  |
| Cash & Cash Equivalents (2)(6) |  | — |  |  | 7 |  |  | — |  |  | 3 |  |  | 10 |  |
| Subtotal |  | $ | — |  |  | $ | 179 |  |  | $ | — |  |  | $ | 400 |  |  | $ | 579 |  |
| Other assets and liabilities (7) |  |  |  |  |  |  |  |  |  | 12 |  |
| Total as of December 31, 2021 (8) |  |  |  |  |  |  |  |  |  | $ | 591 |  |

[0001783180-23-000012:notes:134]
(1) Represents commingled funds that invest primarily in common stocks.

[0001783180-23-000012:notes:135]
(2) In accordance with ASU 2015-07, Fair Value Measurement (Topic 820), certain investments that are measured at fair value using the net asset value per share (or its equivalent) practical expedient have not been classified in the fair value hierarchy. The fair value amounts presented in this table are intended to permit reconciliation of the fair value hierarchy to the amounts presented for the total pension plan assets.

[0001783180-23-000012:notes:136]
(3) Represents investments in real estate, including commingled funds and directly held properties.

[0001783180-23-000012:notes:137]
(4) Represents insurance contracts and global balanced risk commingled funds consisting mainly of equity, bonds and some commodities.

[0001783180-23-000012:notes:138]
(5) Includes fixed income repurchase agreements entered into for purposes of pension asset and liability matching.

[0001783180-23-000012:notes:139]
(6) Represents short-term commercial paper, bonds and other cash or cash-like instruments.

[0001783180-23-000012:notes:140]
(7) Represents trust receivables and payables that are not leveled.

[0001783180-23-000012:notes:141]
(8) Chubb plan assets for 2021, totaling $2.6 billion are not included within this table, as the business was reclassified as held for sale.

[0001783180-23-000012:notes:142]
Derivatives in the plan are primarily used to manage risk and gain asset class exposure while still maintaining liquidity. Derivative instruments mainly consist of fixed income repurchase agreements, interest rate swaps, total return swaps and currency forward contracts.

[0001783180-23-000012:notes:143]
Quoted market prices are used to value investments when available. Investments in securities traded on exchanges, including listed futures and options, are valued at the last reported sale prices on the last business day of the year or, if not available, the

[0001783180-23-000012:notes:144]
last reported bid prices. Fixed income securities are primarily measured using a market approach pricing methodology, whereby observable prices are obtained by market transactions involving identical or comparable securities of issuers with similar credit ratings. Over-the-counter securities and government obligations are valued at the bid prices or the average of the bid and ask prices on the last business day of the year from published sources or, if not available, from other sources considered reliable, including broker quotes. Temporary cash investments are stated at cost, which approximates fair value.

[0001783180-23-000012:notes:145]
For the years ended December 31, 2022, 2021 and 2020, the Company made $16 million, $47 million and $41 million, respectively, of cash contributions to its defined benefit pension plans. The Company expects to make total contributions of approximately $5 million to its defined benefit pension plans in 2023. Contributions do not reflect benefits to be paid directly from corporate assets. Benefit payments, including amounts to be paid from corporate assets, and reflecting expected future service, as appropriate, are expected to be paid as follows: $38 million in 2023, $38 million in 2024, $40 million in 2025, $45 million in 2026, $50 million in 2027 and $243 million from 2028 through 2031.

[0001783180-23-000012:notes:146]
Multiemployer Benefit Plans

[0001783180-23-000012:notes:147]
The Company contributes to various domestic and foreign multiemployer defined benefit pension plans. The risks of participating in these multiemployer plans are different from those of single-employer plans in that assets contributed are pooled and may be used to provide benefits to employees of other participating employers. If a participating employer stops contributing to the plan, the unfunded obligations of the plan may be borne by the remaining participating employers. The Company's contributions to these plans for the years ended December 31, 2022 and 2021 was $15 million and $14 million, respectively.

[0001783180-23-000012:notes:148]
Employee Savings Plans

[0001783180-23-000012:notes:149]
The Company sponsors various employee savings plans. Certain employees of Carrier participate in these plans. Carrier’s contributions to employer sponsored defined contribution plans were $123 million, $115 million and $103 million for the years ended December 31, 2022, 2021 and 2020, respectively.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001783180-23-000012:notes:150]
PRODUCT WARRANTIES 
In the ordinary course of business, the Company provides standard warranty coverage on its products. Provisions for these amounts are established at the time of sale and estimated primarily based on product warranty terms and historical claims experience. In addition, the Company incurs discretionary costs to service its products in connection with specific product performance issues. Provisions for these amounts are established when they are known and estimable. The Company assesses the adequacy of its initial provisions and will make adjustments as necessary based on known or anticipated claims or as new information becomes available that suggests it is probable that future costs will be different than estimated amounts. Amounts associated with these provisions are classified on the accompanying Consolidated Balance Sheet as Accrued liabilities or Other long-term liabilities based on their anticipated settlement date.

[0001783180-23-000012:notes:151]
The changes is the carrying amount of warranty related provisions are as follows:

[0001783180-23-000012:notes:152]
| (In millions) | 2022 |  | 2021 |
| Balance as of January 1, | $ | 524 |  |  | $ | 514 |  |
| Warranties, performance guarantees issued and changes in estimated liability | 184 |  |  | 172 |  |
| Settlements made | (171) |  |  | (165) |  |
| Other | 14 |  |  | 3 |  |
| Balance as of December 31, | $ | 551 |  |  | $ | 524 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001783180-23-000012:notes:153]
EQUITY 
The authorized number of shares of common stock of Carrier is 4,000,000,000 shares of $0.01 par value. As of December 31, 2022 and December 31, 2021, 876,487,480 and 873,064,219 shares of common stock were issued, respectively, which includes 42,103,995 and 10,375,654 shares of treasury stock, respectively.

[0001783180-23-000012:notes:154]
Share Repurchase Program

[0001783180-23-000012:notes:155]
The Company may purchase its outstanding common stock from time to time subject to market conditions and at our discretion. Repurchases occur in the open market or through one or more other public or private transactions pursuant to plans complying with Rules 10b5-1 and 10b-18 under the Exchange Act. Shares acquired are recognized at cost and presented separately on the balance sheet as a reduction to Equity. In July 2021, the Company's Board of Directors approved a $1.75 billion increase to the Company's existing $350 million share repurchase program authorizing the repurchase of up to $2.1 billion of the Company's outstanding common stock. During 2021, the Company repurchased 10.4 million shares of common stock for an aggregate purchase price of $529 million.

[0001783180-23-000012:notes:156]
On December 14, 2021, the Company entered into an accelerated share repurchase agreement ("ASR Agreement") to repurchase $500 million of its common stock pursuant to the Company's existing share repurchase program. In accordance with the ASR Agreement, the Company received initial delivery of 7.6 million shares on January 4, 2022, representing approximately 80% of the expected share repurchases. The final number of shares under the ASR Agreement was based on the daily average of the volume-weighted average share price of the Company's common stock over the term of the ASR Agreement. Upon final settlement, the Company received an additional 2.7 million shares on February 8, 2022 and recognized $500 million in Treasury stock as a reduction in equity. In addition, the Company's Board of Directors approved a $2 billion increase to the Company's existing share repurchase program in October 2022.

[0001783180-23-000012:notes:157]
During 2022, the Company repurchased 31.7 million shares of common stock for an aggregate purchase price of $1.4 billion, which includes shares repurchased under the ASR Agreement. As of December 31, 2022, the Company has approximately $2.2 billion remaining under the current authorization.

[0001783180-23-000012:notes:158]
Accumulated Other Comprehensive Income (Loss)

[0001783180-23-000012:notes:159]
A summary of changes in the components of Accumulated other comprehensive income (loss) is as follows:

[0001783180-23-000012:notes:160]
| (In millions) | Foreign Currency Translation |  | Defined Benefit Pension and Post-retirement Plans |  |  |  |  |  |  |  | Accumulated Other Comprehensive Income (Loss) |
| Balance as of January 1, 2020 | $ | (780) |  |  | $ | (473) |  |  |  |  |  |  |  |  | $ | (1,253) |  |
| Other comprehensive income (loss) before reclassifications, net | 589 |  |  | 2 |  |  |  |  |  |  |  |  | 591 |  |
| Amounts reclassified, pre-tax | — |  |  | (105) |  |  |  |  |  |  |  |  | (105) |  |
| Tax benefit reclassified | — |  |  | 22 |  |  |  |  |  |  |  |  | 22 |  |
| Balance as of December 31, 2020 | $ | (191) |  |  | $ | (554) |  |  |  |  |  |  |  |  | $ | (745) |  |
| Other comprehensive income (loss) before reclassifications, net | (322) |  |  | 53 |  |  |  |  |  |  |  |  | (269) |  |
| Amounts reclassified, pre-tax | 8 |  |  | 34 |  |  |  |  |  |  |  |  | 42 |  |
| Tax benefit reclassified | — |  |  | (17) |  |  |  |  |  |  |  |  | (17) |  |
| Balance as of December 31, 2021 | $ | (505) |  |  | $ | (484) |  |  |  |  |  |  |  |  | $ | (989) |  |
| Other comprehensive income (loss) before reclassifications, net | (525) |  |  | 63 |  |  |  |  |  |  |  |  | (462) |  |
| Amounts reclassified, pre-tax | — |  |  | 11 |  |  |  |  |  |  |  |  | 11 |  |
| Tax benefit reclassified | — |  |  | (3) |  |  |  |  |  |  |  |  | (3) |  |
| Chubb divestiture | (574) |  |  | 329 |  |  |  |  |  |  |  |  | (245) |  |
| Balance as of December 31, 2022 | $ | (1,604) |  |  | $ | (84) |  |  |  |  |  |  |  |  | $ | (1,688) |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001783180-23-000012:notes:161]
REVENUE RECOGNITION 
The Company accounts for revenue in accordance with ASC 606: Revenue from Contracts with Customers. Revenue is recognized when control of a good or service promised in a contract (i.e., performance obligation) is transferred to a customer. Control is obtained when a customer has the ability to direct the use of and obtain substantially all of the remaining benefits from that good or service. A significant portion of the Company's performance obligations are recognized at a point-in-time when control of the product transfers to the customer, which is generally the time of shipment. The remaining portion of the Company’s performance obligations are recognized over time as the customer simultaneously obtains control as the Company performs work under a contract, or if the product being produced for the customer has no alternative use and the Company has a contractual right to payment.

[0001783180-23-000012:notes:162]
Performance Obligations

[0001783180-23-000012:notes:163]
A performance obligation is a distinct good, service or a bundle of goods and services promised in a contract. Some of the Company's contracts with customers contain a single performance obligation, while others contain multiple performance obligations most commonly when a contract spans multiple phases of a product life-cycle such as production, installation, maintenance and support. The Company identifies performance obligations at the inception of a contract and allocates the transaction price to each distinct performance obligation. Revenue is recognized when or as the performance obligation is satisfied. When there are multiple performance obligations within a contract, the Company allocates the transaction price to each performance obligation based on its relative stand-alone selling price.

[0001783180-23-000012:notes:164]
The Company primarily generates revenue from the sale of products to customers and recognizes revenue at a point in time when control transfers to the customer. Transfer of control is generally based on the shipping terms of the contract. In addition, the Company recognizes revenue on an over-time basis on installation and service contracts. For over-time performance obligations requiring the installation of equipment, revenue is recognized using costs incurred to date relative to total estimated costs at completion to measure progress. Incurred costs represent work performed, which correspond with and best depict transfer of control to the customer. Contract costs include direct costs such as labor, materials and subcontractors’ costs and where applicable, indirect costs.

[0001783180-23-000012:notes:165]
Segment sales disaggregated by product and service are as follows:

[0001783180-23-000012:notes:166]
| (In millions) |  | 2022 |  | 2021 |  | 2020 |
| Sales Type |  |  |  |  |  |  |
| Product |  | $ | 11,882 |  |  | $ | 9,985 |  |  | $ | 8,165 |  |
| Service |  | 1,526 |  |  | 1,405 |  |  | 1,313 |  |
| HVAC sales |  | 13,408 |  |  | 11,390 |  |  | 9,478 |  |
| Product |  | 3,432 |  |  | 3,653 |  |  | 2,927 |  |
| Service |  | 451 |  |  | 474 |  |  | 406 |  |
| Refrigeration sales |  | 3,883 |  |  | 4,127 |  |  | 3,333 |  |
| Product |  | 3,372 |  |  | 3,985 |  |  | 3,585 |  |
| Service |  | 198 |  |  | 1,530 |  |  | 1,400 |  |
| Fire & Security sales |  | 3,570 |  |  | 5,515 |  |  | 4,985 |  |
| Total segment sales |  | 20,861 |  |  | 21,032 |  |  | 17,796 |  |
| Eliminations and other |  | (440) |  |  | (419) |  |  | (340) |  |
| Consolidated |  | $ | 20,421 |  |  | $ | 20,613 |  |  | $ | 17,456 |  |

[0001783180-23-000012:notes:167]
The transaction price allocated to performance obligations reflects the Company’s expectations about the consideration it will be entitled to receive from a customer. The Company includes variable consideration in the estimated transaction price when there is a basis to reasonably estimate the amount and when it is probable that a significant reversal of revenue recognized would not occur when the uncertainty associated with variable consideration is subsequently resolved. In addition, the Company customarily offers its customers incentives to purchase products to ensure an adequate supply of its products in

[0001783180-23-000012:notes:168]
distribution channels. The principal incentive programs provide reimbursements to distributors for offering promotional pricing for products. The Company accounts for estimated incentive payments as a reduction in sales at the time a sale is recognized.

[0001783180-23-000012:notes:169]
Contract Balances

[0001783180-23-000012:notes:170]
Total contract assets and liabilities consisted of the following:

[0001783180-23-000012:notes:171]
| (In millions) | 2022 |  | 2021 |
| Contract assets, current | $ | 537 |  |  | $ | 503 |  |
| Contract assets, non-current (included within Other assets) | 6 |  |  | 70 |  |
| Total contract assets | 543 |  |  | 573 |  |
| Contract liabilities, current | (449) |  |  | (415) |  |
| Contract liabilities, non-current (included within Other long-term liabilities) | (174) |  |  | (165) |  |
| Total contract liabilities | (623) |  |  | (580) |  |
| Net contract assets (liabilities) | $ | (80) |  |  | $ | (7) |  |

[0001783180-23-000012:notes:172]
The timing of revenue recognition, billings and cash collections results in contract assets and contract liabilities. Contract assets relate to the conditional right to consideration for any completed performance under a contract when costs are incurred in excess of billings under the percentage-of-completion methodology. Contract liabilities relate to payments received in advance of performance under a contract or when the Company has a right to consideration that is conditioned upon transfer of a good or service to the customer. Contract liabilities are recognized as revenue as (or when) the Company performs under the contract.

[0001783180-23-000012:notes:173]
The Company recognized revenue of $321 million for the year ended December 31, 2022 that was related to contract liabilities as of January 1, 2022. The Company expects a majority of its contract liabilities at the end of the period to be recognized as revenue over the next 12 months. There were no individually significant customers with sales exceeding 10% of total sales for the years ended December 31, 2022, 2021 and 2020.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0001783180-23-000012:notes:174]
The Company accounts for revenue in accordance with ASC 606: Revenue from Contracts with Customers. Revenue is recognized when control of a good or service promised in a contract (i.e., performance obligation) is transferred to a customer. Control is obtained when a customer has the ability to direct the use of and obtain substantially all of the remaining benefits from that good or service. A significant portion of the Company's performance obligations are recognized at a point-in-time when control of the product transfers to the customer, which is generally the time of shipment. The remaining portion of the Company’s performance obligations are recognized over time as the customer simultaneously obtains control as the Company performs work under a contract, or if the product being produced for the customer has no alternative use and the Company has a contractual right to payment.

[0001783180-23-000012:notes:175]
The Company primarily generates revenue from the sale of products to customers and recognizes revenue at a point in time when control transfers to the customer. Transfer of control is generally based on the shipping terms of the contract. In addition, the Company recognizes revenue on an over-time basis on installation and service contracts. For over-time performance obligations requiring the installation of equipment, revenue is recognized using costs incurred to date relative to total estimated costs at completion to measure progress. Incurred costs represent work performed, which correspond with and best depict transfer of control to the customer. Contract costs include direct costs such as labor, materials and subcontractors’ costs and where applicable, indirect costs.
The transaction price allocated to performance obligations reflects the Company’s expectations about the consideration it will be entitled to receive from a customer. The Company includes variable consideration in the estimated transaction price when there is a basis to reasonably estimate the amount and when it is probable that a significant reversal of revenue recognized would not occur when the uncertainty associated with variable consideration is subsequently resolved. In addition, the Company customarily offers its customers incentives to purchase products to ensure an adequate supply of its products in distribution channels. The principal incentive programs provide reimbursements to distributors for offering promotional pricing for products. The Company accounts for estimated incentive payments as a reduction in sales at the time a sale is recognized.The timing of revenue recognition, billings and cash collections results in contract assets and contract liabilities. Contract assets relate to the conditional right to consideration for any completed performance under a contract when costs are incurred in excess of billings under the percentage-of-completion methodology. Contract liabilities relate to payments received in advance of performance under a contract or when the Company has a right to consideration that is conditioned upon transfer of a good or service to the customer. Contract liabilities are recognized as revenue as (or when) the Company performs under the contract.


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0001783180-23-000012:notes:176]
|  |  | External Sales |  | Long-Lived Assets |  |  |  |
| (In millions) |  | 2022 |  | 2021 |  | 2020 |  | 2022 |  | 2021 |  |  |  |
| United States Operations |  | $ | 11,797 |  |  | $ | 10,492 |  |  | $ | 9,105 |  |  | $ | 803 |  |  | $ | 772 |  |  |  |  |
| International Operations |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Europe |  | 4,359 |  |  | 5,776 |  |  | 4,935 |  |  | 453 |  |  | 476 |  |  |  |  |
| Asia Pacific |  | 3,489 |  |  | 3,464 |  |  | 2,655 |  |  | 573 |  |  | 279 |  |  |  |  |
| Other |  | 776 |  |  | 881 |  |  | 761 |  |  | 412 |  |  | 299 |  |  |  |  |
| Consolidated |  | $ | 20,421 |  |  | $ | 20,613 |  |  | $ | 17,456 |  |  | $ | 2,241 |  |  | $ | 1,826 |  |  |  |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001783180-23-000012:notes:177]
STOCK-BASED COMPENSATION
The Company accounts for stock-based compensation plans in accordance with ASC 718, Compensation - Stock Compensation, which requires a fair-value based method for measuring the value of stock-based compensation. Fair value is measured at the date of grant and is generally not adjusted for subsequent changes. The Company's stock-based compensation plans include programs for stock appreciation rights, restricted stock and performance share units.

[0001783180-23-000012:notes:178]
Stock Options and Appreciation Rights

[0001783180-23-000012:notes:179]
Eligible participants may receive stock options or stock appreciation rights as part of the Company's long-term incentive program. The fair value of each instrument is determined as of the date of grant using a binomial lattice model and expensed on a straight-line basis over the required service period, which is generally a three-year vesting period. However, in the event of retirement, awards held for at least one year may vest and become exercisable (if applicable), subject to certain terms and conditions.

[0001783180-23-000012:notes:180]
The following table summarizes fair value information for stock options and stock appreciation rights:

[0001783180-23-000012:notes:181]
|  |  | 2022 (1) |  | 2021 (1) |  | 2020 (1) |
| Stock options and stock appreciation rights weighted-average fair value per award |  | $ | 10.68 |  |  | $ | 10.13 |  |  | $ | 4.67 |  |
| Assumptions: |  |  |  |  |  |  |
| Volatility |  | 30.8% to 31.3% |  | 31.6% to 34.1% |  | 32.1% to 35.6% |
| Expected term (in years) |  | 6.1 |  | 6.6 |  | 7.0 |
| Expected dividend yield |  | 1.5% |  | 1.5% |  | 1.4% to 2.0% |
| Range of risk-free rates |  | 1.7% to 3.0% |  | 0.7% to 1.4% |  | 0.1% to 1.0% |

[0001783180-23-000012:notes:182]
(1) Carrier has limited historical trading data and used peer group data to estimate expected volatility for the 2022, 2021 and 2020 awards.

[0001783180-23-000012:notes:183]
The Company used historical employee data, including data prior to the Separation and the Distribution, to estimate expected term. The expected dividend yield is consistent with management's expectations. The risk-free rate is based on the term structure of interest rates at the time the awards were granted.

[0001783180-23-000012:notes:184]
Changes in stock options and stock appreciation rights outstanding subsequent to the Separation and Distribution were as follows:

[0001783180-23-000012:notes:185]
|  | Shares Subject to Option(in thousands) |  | Weighted-Average Exercise Price |  | Aggregate Intrinsic Value (in millions) |  | Weighted- Average Remaining Life (in years) |
| As of April 3, 2020 | 36,015 |  |  | $ | 19.90 |  |  |  |  |  |
| Granted | 3,921 |  |  | $ | 17.57 |  |  |  |  |  |
| Exercised | (2,620) |  |  | $ | 15.81 |  |  |  |  |  |
| Cancelled | (584) |  |  | $ | 22.31 |  |  |  |  |  |
| As of December 31, 2020 | 36,732 |  |  | $ | 19.91 |  |  |  |  |  |
| Granted | 3,194 |  |  | $ | 38.92 |  |  |  |  |  |
| Exercised | (5,934) |  |  | $ | 17.59 |  |  |  |  |  |
| Cancelled | (1,551) |  |  | $ | 23.98 |  |  |  |  |  |
| As of December 31, 2021 | 32,441 |  |  | $ | 22.02 |  |  |  |  |  |
| Granted | 2,715 |  |  | $ | 47.72 |  |  |  |  |  |
| Exercised | (3,495) |  |  | $ | 17.76 |  |  |  |  |  |
| Cancelled | (883) |  |  | $ | 30.33 |  |  |  |  |  |
| Outstanding as of December 31, 2022 | 30,778 |  |  | $ | 24.53 |  |  | $ | 532 |  |  | 5.9 |
| Exercisable as of December 31, 2022 | 17,642 |  |  | $ | 20.03 |  |  | $ | 375 |  |  | 4.5 |

[0001783180-23-000012:notes:186]
Restricted Stock Units

[0001783180-23-000012:notes:187]
Eligible participants may receive restricted stock units ("RSU") as part of the Company's long-term incentive program. The fair value of restricted stock units are based on the closing market price of the Company's common stock on the date of grant and expensed on a straight-line basis over the required service period (which is generally a three-year vesting period). However, in the event of retirement, awards held for at least one year may vest and become exercisable (if applicable), subject to certain terms and conditions. Dividends accrue during the vesting period and are paid in shares of the Company's common stock.

[0001783180-23-000012:notes:188]
Changes in restricted stock units subsequent to the Separation and Distribution were as follows:

[0001783180-23-000012:notes:189]
|  | RSUs (in thousands) |  | Weighted-Average Grant Date Fair Value |
| Outstanding and unvested as of April 3, 2020 | 5,622 |  |  | $ | 21.37 |  |
| Granted | 523 |  |  | $ | 21.43 |  |
| Vested | (483) |  |  | $ | 19.74 |  |
| Cancelled | (88) |  |  | $ | 23.29 |  |
| Outstanding and unvested as of December 31, 2020 | 5,574 |  |  | $ | 21.57 |  |
| Granted | 286 |  |  | $ | 46.49 |  |
| Vested | (2,168) |  |  | $ | 21.45 |  |
| Cancelled | (122) |  |  | $ | 25.39 |  |
| Outstanding and unvested as of December 31, 2021 | 3,570 |  |  | $ | 23.33 |  |
| Granted | 555 |  |  | $ | 41.88 |  |
| Vested | (1,915) |  |  | $ | 20.85 |  |
| Cancelled | (143) |  |  | $ | 32.92 |  |
| Outstanding and unvested as of December 31, 2022 | 2,067 |  |  | $ | 29.87 |  |

[0001783180-23-000012:notes:190]
Performance Share Units

[0001783180-23-000012:notes:191]
The Company has a performance share program for key employees whereby awards are provided in the form of performance share units ("PSU") based on performance against pre-established objectives. The annual target level is expressed as shares of the Company's common stock based on the fair value of its stock on the date of grant. Awards are earned over a three-year performance period based equally on a performance condition, measured by the compound annual growth rate of the Company's earnings per share and on a market condition, measured by the Company's relative total shareowner return compared to the total shareowner return of a subset of industrial companies in the S&P 500 Index. The fair value of the market condition is estimated using a Monte Carlo simulation approach. The fair value of the PSU awards are expensed over the required service period, which is generally a three-year vesting period. In the event of retirement, performance share units held for at least one year remain eligible to vest based on actual performance relative to pre-established metrics. Dividends do not accrue on the performance share units during the performance period.

[0001783180-23-000012:notes:192]
Changes in PSUs subsequent to the Separation and Distribution were as follows:

[0001783180-23-000012:notes:193]
|  | PSUs (in thousands) |  | Weighted-Average Grant Date Fair Value |
| Outstanding and unvested as of April 3, 2020 | 68 |  |  | $ | 21.23 |  |
| Granted | 728 |  |  | $ | 18.23 |  |
| Forfeited | (24) |  |  | $ | 19.25 |  |
| Outstanding and unvested as of December 31, 2020 | 772 |  |  | $ | 18.46 |  |
| Granted | 821 |  |  | $ | 41.48 |  |
| Vested | (20) |  |  | $ | 23.72 |  |
| Forfeited | (152) |  |  | $ | 27.28 |  |
| Outstanding and unvested as of December 31, 2021 | 1,421 |  |  | $ | 30.75 |  |
| Granted | 653 |  |  | $ | 46.93 |  |
| Vested | (5) |  |  | $ | 41.81 |  |
| Forfeited | (139) |  |  | $ | 35.45 |  |
| Outstanding and unvested as of December 31, 2022 | 1,930 |  |  | $ | 35.86 |  |

[0001783180-23-000012:notes:194]
Compensation Expense

[0001783180-23-000012:notes:195]
Stock-based compensation expense, net of estimated forfeitures, is included in Cost of products sold, Selling, general and administrative and Research and development, in the accompanying Consolidated Statement of Operations.

[0001783180-23-000012:notes:196]
Stock-based compensation cost by award type are as follows:

[0001783180-23-000012:notes:197]
| (In millions) | 2022 |  | 2021 |  | 2020 (1) |
| Equity compensation costs - equity settled | $ | 77 |  |  | $ | 92 |  |  | $ | 77 |  |
| Equity compensation costs - cash settled (2) | (15) |  |  | 19 |  |  | 11 |  |
| Total stock-based compensation cost | $ | 62 |  |  | $ | 111 |  |  | $ | 88 |  |
| Income tax benefit | $ | 9 |  |  | $ | 13 |  |  | $ | 9 |  |

[0001783180-23-000012:notes:198]
(1) The stock-based compensation cost for 2020 include amounts allocated to Carrier by UTC related to its direct employees.

[0001783180-23-000012:notes:199]
(2) The cash settled awards are classified as liability awards and are measured at fair value at each balance sheet date.

[0001783180-23-000012:notes:200]
Prior to the Separation and the Distribution, the Company participated in UTC’s long-term incentive plans, which authorized various types of market and performance-based incentive awards. Stock-based compensation expense was allocated to the Company from UTC based upon direct employee headcount. In connection with the Separation and the Distribution, all awards were converted to Carrier stock-based awards with unvested awards converted to preserve the aggregate intrinsic value immediately before and after the Separation.

[0001783180-23-000012:notes:201]
As of December 31, 2022 and 2021, there were $64 million and $77 million of unrecognized stock-based compensation costs related to non-vested awards granted under the plan, respectively, which will be recognized ratably over the awards weighted-average remaining vesting period of 2 years.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001783180-23-000012:notes:202]
RESTRUCTURING COSTS 
The Company incurs costs associated with restructuring initiatives intended to improve operating performance, profitability and working capital levels. Actions associated with these initiatives may include improving productivity, workforce reductions and the consolidation of facilities. Due to the size, nature and frequency of these discrete plans, they are fundamentally different from the Company’s ongoing productivity initiatives.

[0001783180-23-000012:notes:203]
The Company recorded net pre-tax restructuring costs for new and ongoing restructuring actions as follows:

[0001783180-23-000012:notes:204]
| (In millions) | 2022 |  | 2021 |  | 2020 |
| HVAC | $ | 8 |  |  | $ | 33 |  |  | $ | 7 |  |
| Refrigeration | 10 |  |  | 25 |  |  | 12 |  |
| Fire & Security | 11 |  |  | 26 |  |  | 28 |  |
| Total Segment | 29 |  |  | 84 |  |  | 47 |  |
| General corporate expenses | 2 |  |  | 5 |  |  | 2 |  |
| Total restructuring costs | $ | 31 |  |  | $ | 89 |  |  | $ | 49 |  |
| Cost of sales | $ | 9 |  |  | $ | 28 |  |  | $ | 20 |  |
| Selling, general and administrative | 22 |  |  | 60 |  |  | 29 |  |
| Other income (expense), net | — |  |  | 1 |  |  | — |  |
| Total restructuring costs | $ | 31 |  |  | $ | 89 |  |  | $ | 49 |  |

[0001783180-23-000012:notes:205]
The following table summarizes the reserves and charges related to the restructuring reserve, included in Accrued liabilities on the accompanying Consolidated Balance Sheet:

[0001783180-23-000012:notes:206]
| (In millions) |  | 2022 |  | 2021 |
| Balance as of January 1, |  | $ | 54 |  |  | $ | 49 |  |
| Net pre-tax restructuring costs |  | 31 |  |  | 89 |  |
| Utilization, foreign exchange and other |  | (61) |  |  | (76) |  |
| Reclassified as Liabilities held for sale (1) |  | — |  |  | (8) |  |
| Balance as of December 31, |  | $ | 24 |  |  | $ | 54 |  |

[0001783180-23-000012:notes:207]
During the year ended December 31, 2022, charges associated with restructuring initiatives related to cost reduction efforts. Amounts recognized primarily related to severance due to workforce reductions and exit costs due to the consolidation of field operations. As of December 31, 2022, the Company had $24 million accrued for costs associated with its announced restructuring initiatives, all of which is expected to be paid within one year.


## us-gaap:OtherIncomeAndOtherExpenseDisclosureTextBlock

[0001783180-23-000012:notes:208]
OTHER INCOME (EXPENSE), NET
Other income (expense), net consisted of the following:

[0001783180-23-000012:notes:209]
| (In millions) | 2022 |  | 2021 |  | 2020 |
| Transaction gains (1) | $ | — |  |  | $ | — |  |  | $ | 1,123 |  |
| Impairment charge on minority-owned joint venture investments (1) | — |  |  | (2) |  |  | (72) |  |
| Other | 1,840 |  |  | 41 |  |  | (45) |  |
| Other income (expense), net | $ | 1,840 |  |  | $ | 39 |  |  | $ | 1,006 |  |

[0001783180-23-000012:notes:210]
(1) See Note 22 - Related Parties for additional information.

[0001783180-23-000012:notes:211]
Other income (expense), net primarily includes the impact of gains and losses related to the sale of interests in equity method investments, foreign currency gains and losses on transactions that are denominated in a currency other than the entity's functional currency and hedging-related activities. In connection with the TCC acquisition, the carrying value of the Company's previously held TCC equity investments were recognized at fair value at the date of acquisition. As a result, the Company recognized a $705 million non-cash gain associated with the increase in our ownership interest. In addition, the Company completed the Chubb Sale and recognized a net gain on the sale of $1.1 billion during the twelve months ended December 31, 2022.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001783180-23-000012:notes:212]
INCOME TAXES 
Income Before Income Taxes

[0001783180-23-000012:notes:213]
The sources of Income from operations before income taxes are as follows:

[0001783180-23-000012:notes:214]
| (In millions) | 2022 |  | 2021 |  | 2020 |
| United States | $ | 1,876 |  |  | $ | 1,528 |  |  | $ | 915 |  |
| Foreign | 2,416 |  |  | 872 |  |  | 1,940 |  |
| Total | $ | 4,292 |  |  | $ | 2,400 |  |  | $ | 2,855 |  |

[0001783180-23-000012:notes:215]
Provision for Income Taxes

[0001783180-23-000012:notes:216]
The income tax expense (benefit) consisted of the following components:

[0001783180-23-000012:notes:217]
| (In millions) | 2022 |  | 2021 |  | 2020 |
| Current: |  |  |  |  |  |
| United States: |  |  |  |  |  |
| Federal | $ | 453 |  |  | $ | 336 |  |  | $ | 434 |  |
| State | 120 |  |  | 83 |  |  | 74 |  |
| Foreign | 259 |  |  | 354 |  |  | 244 |  |
|  | 832 |  |  | 773 |  |  | 752 |  |
| Future: |  |  |  |  |  |
| United States: |  |  |  |  |  |
| Federal | (23) |  |  | (125) |  |  | 13 |  |
| State | (29) |  |  | (14) |  |  | 6 |  |
| Foreign | (72) |  |  | 65 |  |  | 78 |  |
|  | (124) |  |  | (74) |  |  | 97 |  |
| Income tax expense | $ | 708 |  |  | $ | 699 |  |  | $ | 849 |  |

[0001783180-23-000012:notes:218]
Reconciliation of Effective Income Tax Rate

[0001783180-23-000012:notes:219]
The differences between the effective income tax rate and the statutory U.S. federal income tax rate are as follows:

[0001783180-23-000012:notes:220]
|  | 2022 |  | 2021 |  | 2020 |
| Statutory U.S. federal income tax rate | 21.0 | % |  | 21.0 | % |  | 21.0 | % |
| State income tax | 1.5 |  |  | 1.9 |  |  | 1.7 |  |
| Tax on international activities | (1.0) |  |  | 7.2 |  |  | 4.2 |  |
| Separation impact | — |  |  | — |  |  | 3.4 |  |
| TCC acquisition impact | (4.2) |  |  | — |  |  | — |  |
| Other | (0.8) |  |  | (1.0) |  |  | (0.6) |  |
| Effective income tax rate | 16.5 | % |  | 29.1 | % |  | 29.7 | % |

[0001783180-23-000012:notes:221]
The effective tax rate for the year ended December 31, 2022 was lower than the Company's statutory U.S. federal income tax rate. The decrease was driven by a lower effective tax rate on the $705 million non-cash gain resulting from the recognition of the Company's previously held TCC equity investments at fair value upon acquisition of TCC, a lower effective tax rate on the $1.1 billion Chubb gain and $45 million of foreign tax credits generated and utilized in the current year. The effective tax rate for the year ended December 31, 2021 was higher than the Company's statutory U.S. federal income tax rate. The increase was driven by a net tax charge of $157 million primarily relating to the re-organization and disentanglement of certain Chubb subsidiaries executed in advance of the planned divestiture of the Chubb business and a $43 million deferred tax charge associated with a tax rate increase in the United Kingdom enacted on June 10, 2021 with an effective date of April 2023. These amounts were partially offset by the recognition of a favorable tax adjustment of $70 million due to foreign tax credits generated and expected to be utilized in the current year and $21 million resulting from the re-organization of a German subsidiary. The effective tax rate for the year ended December 31, 2020 was higher than the Company's statutory U.S. federal income tax rate. The increase was driven by a $51 million charge related to a valuation allowance recorded against a United Kingdom tax loss and credit carryforward and a charge of $46 million resulting from the Company's decision to no longer permanently reinvest certain pre-2018 unremitted non-U.S. earnings. These items were impacted by the Separation and included in "Separation impact" in the previous table.

[0001783180-23-000012:notes:222]
Deferred Tax Assets and Liabilities

[0001783180-23-000012:notes:223]
Future income taxes represent the tax effects of transactions, which are reported in different periods for tax and GAAP purposes. These amounts consist of the tax effects of differences between tax and GAAP that are expected to be reversed in the

[0001783180-23-000012:notes:224]
future and tax carryforwards. Future income tax benefits and payables within the same tax paying component of a particular jurisdiction are offset for presentation in the Consolidated Balance Sheet.

[0001783180-23-000012:notes:225]
The tax effects of temporary differences and tax carryforwards which give rise to future income tax benefits and payables as of December 31, 2022 and 2021 are as follows:

[0001783180-23-000012:notes:226]
| (In millions) | 2022 |  | 2021 |
| Future income tax benefits: |  |  |  |
| Insurance and employee benefits | $ | 161 |  |  | $ | 198 |  |
| Other assets basis differences | 284 |  |  | 166 |  |
| Other liabilities basis differences | 571 |  |  | 512 |  |
| Tax loss carryforward | 177 |  |  | 175 |  |
| Tax credit carryforward | 29 |  |  | 24 |  |
| Valuation allowances | (100) |  |  | (90) |  |
| Future income tax benefit | $ | 1,122 |  |  | $ | 985 |  |
| Future income tax payables: |  |  |  |
| Goodwill and intangible assets | $ | (449) |  |  | $ | (270) |  |
| Other asset basis differences | (395) |  |  | (307) |  |
| Future income tax payables | $ | (844) |  |  | $ | (577) |  |

[0001783180-23-000012:notes:227]
Valuation allowances have been established primarily for tax credit carryforwards, tax loss carryforwards and certain foreign temporary differences to reduce future income tax benefits to expected realizable amounts. As of December 31, 2021, future income tax benefits and future income tax payables exclude a net liability of $266 million classified as held for sale. See Note 20 - Divestitures for additional information.

[0001783180-23-000012:notes:228]
Changes to valuation allowances consisted of the following:

[0001783180-23-000012:notes:229]
| (In millions) |  |  |
| Balance as of January 1, 2020 |  | $ | 128 |  |
| Additions charged to income tax expense (1) |  | 112 |  |
| Reduction credited to income tax expense |  | (13) |  |
| Other adjustments |  | 4 |  |
| Balance as of December 31, 2020 |  | $ | 231 |  |
| Additions charged to income tax expense |  | 32 |  |
| Reduction credited to income tax expense |  | (22) |  |
| Other adjustments |  | (41) |  |
| Reclassified to held for sale |  | (110) |  |
| Balance as of December 31, 2021 |  | $ | 90 |  |
| Additions charged to income tax expense |  | 18 |  |
| Reduction credited to income tax expense |  | (22) |  |
| Other adjustments |  | 14 |  |
| Balance as of December 31, 2022 |  | $ | 100 |  |

[0001783180-23-000012:notes:230]
(1) Includes $89 million relating to "Separation impact" discussed in section "Reconciliation of Effective Income Tax Rate."

[0001783180-23-000012:notes:231]
Tax Credit and Loss Carryforwards

[0001783180-23-000012:notes:232]
As of December 31, 2022, tax credit carryforwards and tax loss carryforwards were as follows:

[0001783180-23-000012:notes:233]
| (In millions) | Tax Loss Carryforwards |  | Tax Credit Carryforwards |
| Expiration period: |  |  |  |
| 2023-2027 | $ | 107 |  |  | $ | 7 |  |
| 2028-2032 | 61 |  |  | 5 |  |
| 2033-2042 | 33 |  |  | 4 |  |
| Indefinite | 607 |  |  | 13 |  |
| Total | $ | 808 |  |  | $ | 29 |  |

[0001783180-23-000012:notes:234]
The Company assesses the realizability of its deferred tax assets on a quarterly basis through an analysis of potential sources of future taxable income, including prior year taxable income available to absorb a carryback of tax losses, reversals of existing taxable temporary differences, tax planning strategies and forecasts of taxable income. The Company considers all negative and positive evidence, including the weight of the evidence, to determine if valuation allowances against deferred tax assets are required. The Company maintains valuation allowances against certain deferred tax assets.

[0001783180-23-000012:notes:235]
Unrecognized Tax Benefits

[0001783180-23-000012:notes:236]
As of December 31, 2022, the Company had unrecognized tax benefits of $291 million, all of which, if recognized, would impact its effective tax rate. A reconciliation of the beginning and ending amounts of unrecognized tax benefits and related interest expense is as follows:

[0001783180-23-000012:notes:237]
| (In millions) | 2022 |  | 2021 |  | 2020 |
| Balance at beginning of period | $ | 251 |  |  | $ | 162 |  |  | $ | 166 |  |
| Additions for tax positions related to the current year | 34 |  |  | 86 |  |  | 22 |  |
| Additions for tax positions of prior years (1) | 32 |  |  | 24 |  |  | 14 |  |
| Reductions for tax positions of prior years (2) | (13) |  |  | (1) |  |  | (40) |  |
| Settlements | (13) |  |  | (18) |  |  | — |  |
| Reclassified as held for sale | — |  |  | (2) |  |  | — |  |
| Balance at end of period | $ | 291 |  |  | $ | 251 |  |  | $ | 162 |  |
| Gross interest expense related to unrecognized tax benefits | $ | 16 |  |  | $ | 8 |  |  | $ | 6 |  |
| Total accrued interest balance at end of period | $ | 48 |  |  | $ | 35 |  |  | $ | 25 |  |

[0001783180-23-000012:notes:238]
(1) Includes $14 million related to acquisitions during the year ended December 31, 2021.

[0001783180-23-000012:notes:239]
(2) Includes an adjustment of $37 million recorded in UTC Net investment for the year ended December 31, 2020 for tax positions of prior years.

[0001783180-23-000012:notes:240]
The Company conducts business globally and, as a result, the Company and its subsidiaries file income tax returns in the U.S. federal, various state and foreign jurisdictions. In certain jurisdictions, the Company's operations were included in UTC's combined tax returns for the periods through the Separation and the Distribution. The IRS commenced an audit of UTC's tax years 2017 and 2018 in the second quarter of 2020 and this audit will continue into 2023. In the normal course of business, the Company is subject to examination by taxing authorities throughout the world, including the U.S., Australia, Belgium, Canada, China, Czech Republic, France, Germany, Hong Kong, India, Italy, Japan, Mexico, the Netherlands, Singapore, Thailand, and the United Kingdom. The Company is no longer subject to U.S. federal income tax examination for years prior to 2017 and, with few exceptions, is no longer subject to U.S. state and local and foreign income tax examinations for tax years before 2013.

[0001783180-23-000012:notes:241]
In the ordinary course of business, there is inherent uncertainty in quantifying the Company's income tax positions. The Company assesses its income tax positions and records tax benefits for all years subject to examination based upon management’s evaluation of the facts, circumstances and information available at the reporting date. The Company believes that it is reasonably possible that a net decrease in unrecognized tax benefits of $45 million to $55 million may occur within 12 months as a result of additional uncertain tax positions, the revaluation of uncertain tax positions arising from examinations, appeals, court decisions or the closure of tax statutes.
As a result of the Tax Cuts and Jobs Act ("TCJA"), the Company no longer intends to reinvest certain undistributed earnings of its international subsidiaries that have been previously taxed in the U.S. As such, the Company has recorded the taxes associated with the future remittance of these earnings. For the remainder of the Company's undistributed international earnings, unless tax effective to repatriate, the Company intends to continue to permanently reinvest these earnings. As of December 31, 2022, such undistributed earnings were approximately $10 billion, excluding other comprehensive income amounts. It is not practicable to estimate the amount of tax that might be payable on the remaining amounts. In addition, the TCJA subjects the Company to a tax on global intangible low-taxed income ("GILTI"). GILTI is a tax on foreign income in excess of a deemed return on tangible assets of foreign corporations which the Company has elected to account for as a period cost.


## us-gaap:EarningsPerShareTextBlock

[0001783180-23-000012:notes:242]
EARNINGS PER SHARE 
Earnings per share is computed by dividing Net income attributable to common shareowners by the weighted-average number of shares of common stock outstanding during the period (excluding treasury stock). Diluted earnings per share is computed by giving effect to all potentially dilutive stock awards that are outstanding. The computation of diluted earnings per share excludes the effect of the potential exercise of stock-based awards, including stock appreciation rights and stock options, when the effect of the potential exercise would be anti-dilutive.

[0001783180-23-000012:notes:243]
The following table summarizes the weighted-average number of shares of common stock outstanding for basic and diluted earnings per share calculations:

[0001783180-23-000012:notes:244]
| (In millions, except per share amounts) |  | 2022 |  | 2021 |  | 2020 |  |  |
| Net income attributable to common shareowners |  | $ | 3,534 |  |  | $ | 1,664 |  |  | $ | 1,982 |  |  |  |
| Basic weighted-average number of shares outstanding |  | 843.4 |  |  | 867.7 |  |  | 866.5 |  |  |  |
| Stock awards and equity units (share equivalent) |  | 17.8 |  |  | 22.6 |  |  | 13.7 |  |  |  |
| Diluted weighted-average number of shares outstanding |  | 861.2 |  |  | 890.3 |  |  | 880.2 |  |  |  |
| Antidilutive shares excluded from computation of diluted earnings per share |  | 2.9 |  |  | 0.1 |  | (1) | 0.2 |  |  |  |
| Earnings Per Share |  |  |  |  |  |  |  |  |
| Basic |  | $ | 4.19 |  |  | $ | 1.92 |  |  | $ | 2.29 |  |  |  |
| Diluted |  | $ | 4.10 |  |  | $ | 1.87 |  |  | $ | 2.25 |  |  |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001783180-23-000012:notes:245]
ACQUISITIONS
During the year ended December 31, 2022, the Company acquired consolidated and minority-owned businesses. The aggregate cash paid, net of cash acquired, totaled $506 million. Acquisitions are recorded using the acquisition method of accounting in accordance with ASC 805. As a result, the aggregate purchase price has been allocated to assets acquired and liabilities assumed based on the estimate of fair market value of such assets and liabilities at the date of acquisition. The excess purchase price over the estimated fair value of net assets acquired was recognized as goodwill and totaled $905 million.

[0001783180-23-000012:notes:246]
Toshiba Carrier Corporation

[0001783180-23-000012:notes:247]
On February 6, 2022, the Company entered into a binding agreement to acquire a majority ownership interest in TCC for $930 million. TCC, a VRF and light commercial HVAC joint venture between Carrier and Toshiba Corporation, designs and manufactures flexible, energy-efficient and high-performance VRF and light commercial HVAC systems as well as commercial products, compressors and heat pumps. The acquisition included all of TCC’s advanced research and development centers and global manufacturing operations, product pipeline and the long-term use of Toshiba’s iconic brand. The acquisition was completed on August 1, 2022 and funded through the Japanese Term Loan Facility and cash on hand. Upon closing, Toshiba Corporation retained a 5% ownership interest in TCC.

[0001783180-23-000012:notes:248]
The preliminary allocation of the purchase price is as follows:

[0001783180-23-000012:notes:249]
| (In millions) |  | August 1, 2022 |
| Cash and cash equivalents |  | $ | 462 |  |
| Accounts receivable |  | 414 |  |
| Inventories |  | 373 |  |
| Other assets, current |  | 54 |  |
| Fixed assets |  | 343 |  |
| Intangible assets |  | 965 |  |
| Goodwill |  | 889 |  |
| Other assets |  | 293 |  |
| Accounts payable |  | (412) |  |
| Accrued liabilities |  | (445) |  |
| Contract liabilities, current |  | (21) |  |
| Other long-term liabilities |  | (565) |  |
| Net assets acquired |  | $ | 2,350 |  |
| Less: Fair value of non-controlling interests |  | (22) |  |
| Less: Fair value of previously held TCC equity investments |  | (1,398) |  |
| Total cash consideration |  | $ | 930 |  |

[0001783180-23-000012:notes:250]
The excess purchase price over the estimated fair value of the net assets acquired was recognized as goodwill and totaled $889 million, which is not deductible for tax purposes. Accounts receivable and current liabilities were stated at their historical carrying value, which approximates fair value given the short-term nature of these assets and liabilities. The estimate of fair value for inventory and fixed assets was based on an assessment of the acquired assets' condition as well as an evaluation of the current market value of such assets. The sale agreement included several customary provisions to settle working capital and other transaction-related items as of the date of sale. During the year ended December 31, 2022, the parties finalized these amounts in accordance with the terms of the sale agreement. As a result, the Company recorded an accrual of $39 million which is expected to be paid to Toshiba Corporation in the first quarter of 2023.

[0001783180-23-000012:notes:251]
The Company recorded intangible assets based on its estimate of fair value which consisted of the following:

[0001783180-23-000012:notes:252]
| (In millions) | Estimated Useful Life (in years) |  | Intangible Assets Acquired |
| Customer relationships | 23 |  | $ | 497 |  |
| Technology | 7 |  | 220 |  |
| Trademark | 26 |  | 180 |  |
| Backlog | 1 |  | 60 |  |
| Land use rights | 45 |  | 8 |  |
| Total intangible assets acquired |  |  | $ | 965 |  |

[0001783180-23-000012:notes:253]
The valuation of intangible assets was determined using an income approach methodology including the multi-period excess earnings method and the relief from royalty method. Key assumptions used in estimating future cash flows included projected revenue growth rates, EBIT margins, discount rates, customer attrition rates and royalty rates among others. The projected future cash flows are discounted to present value using an appropriate discount rate. As of December 31, 2022, the Company  finalized the process of allocating the purchase price and valuing the acquired assets and liabilities except for certain amounts associated with pension funding levels and income taxes.

[0001783180-23-000012:notes:254]
The Company previously accounted for its minority ownership in TCC under the equity method of accounting. In connection with the transaction, the carrying value of the Company's previously held TCC equity investments were recognized at fair value at the date of acquisition using an income approach methodology. As a result, the Company recognized a $705 million non-cash

[0001783180-23-000012:notes:255]
gain within Other income (expense), net on the accompanying Consolidated Statement of Operations. In addition, the assets, liabilities and results of operations of TCC are consolidated in the accompanying Consolidated Financial Statements as of the date of acquisition and reported within the Company's HVAC segment. During the year ended December 31, 2022, the Company incurred $29 million of acquisition-related costs which are included within Selling, general and administrative on the accompanying Consolidated Statement of Operations. The Company has not included pro forma financial information required under ASC 805 as the pro forma impact was not deemed significant.

[0001783180-23-000012:notes:256]
Acquisition of Guangdong Giwee Group Co.

[0001783180-23-000012:notes:257]
On June 1, 2021, the Company acquired a 70% controlling stake in Guangdong Giwee Group Co. and its subsidiaries ("Giwee") and subsequently acquired the remaining 30% ownership in Giwee on September 7, 2021. Giwee is a China-based manufacturer offering a portfolio of HVAC products including variable refrigerant flow, modular chillers and light commercial air conditioners. The acquisition was funded through cash on hand.

[0001783180-23-000012:notes:258]
The excess of the purchase price over the estimated fair value of the net assets acquired was recognized as goodwill and totaled $182 million, which is not deductible for tax purposes. Accounts receivable and current liabilities were stated at their historical carrying value, which approximates fair value given the short-term nature of these assets and liabilities. The estimate of fair value for inventory and property, plant and equipment was based on an assessment of the acquired assets' condition as well as an evaluation of the current market value of such assets.

[0001783180-23-000012:notes:259]
The Company recorded intangible assets which consisted of the following:

[0001783180-23-000012:notes:260]
| (In millions) | Estimated Useful Life (in years) |  | Intangible Assets Acquired |
| Customer relationships | 14 |  | $ | 52 |  |
| Technology | 10 |  | 34 |  |
| Non-compete agreement | 5 |  | 8 |  |
| Total intangible assets acquired |  |  | $ | 94 |  |

[0001783180-23-000012:notes:261]
The valuation of intangible assets was determined using an income approach methodology including the multi-period excess earnings method and the relief from royalty method. Key assumptions used in estimating future cash flows included projected revenue growth rates, customer attrition rates and royalty rates. The projected future cash flows are discounted to present value using an appropriate discount rate.

[0001783180-23-000012:notes:262]
The results of Giwee are reported within the HVAC segment as of the date of acquisition. The Company finalized the process of allocating the purchase price and valuing the acquired assets and liabilities during the year ended December 31, 2021. The Company has not included pro forma financial information required under ASC 805 as the pro forma impact was not deemed significant.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001783180-23-000012:notes:263]
DIVESTITURESOn January 3, 2022, the Company completed the Chubb Sale for net proceeds of $2.9 billion. Chubb, which was reported within the Company’s Fire & Security segment, delivered essential fire safety and security solutions from design and installation to monitoring, service and maintenance across more than 17 countries around the globe. During the year ended December 31, 2022, the Company recognized a net gain on the sale of $1.1 billion, which is included in Other income (expense), net on the accompanying Consolidated Statement of Operations. 
The following table summarizes Chubb's assets and liabilities classified as held for sale:

[0001783180-23-000012:notes:264]
| (In millions) |  | December 31, 2021 |
| Cash and cash equivalents |  | $ | 60 |  |
| Accounts receivable, net |  | 445 |  |
| Inventories, net |  | 73 |  |
| Contract assets, current |  | 184 |  |
| Other assets, current |  | 27 |  |
| Fixed assets, net |  | 67 |  |
| Intangible assets, net |  | 545 |  |
| Goodwill |  | 940 |  |
| Operating lease right-of-use assets |  | 193 |  |
| Pension and post-retirement assets |  | 614 |  |
| Other assets |  | 20 |  |
| Total assets held for sale |  | $ | 3,168 |  |
| Accounts payable |  | $ | (190) |  |
| Accrued liabilities |  | (248) |  |
| Contract liabilities, current |  | (162) |  |
| Future pension and post-retirement obligations |  | (69) |  |
| Future income tax obligations |  | (273) |  |
| Operating lease liabilities |  | (175) |  |
| Other long-term liabilities |  | (17) |  |
| Total liabilities held for sale |  | $ | (1,134) |  |

[0001783180-23-000012:notes:265]
The sale agreement included several customary provisions to settle working capital and other transaction-related items as of the date of sale. The parties finalized these amounts in accordance with the terms of the sale agreement.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001783180-23-000012:notes:266]
SEGMENT FINANCIAL DATA 
The Company conducts its operations through three reportable operating segments: HVAC, Refrigeration and Fire & Security. In accordance with ASC 280 - Segment Reporting, the Company’s segments maintain separate financial information for which results of operations are evaluated on a regular basis by the Company’s Chief Operating Decision Maker in deciding how to allocate resources and in assessing performance. Inter-company sales between segments are immaterial.

[0001783180-23-000012:notes:267]
•The HVAC segment provides products, controls, services and solutions to meet the heating, cooling and ventilation needs of residential and commercial customers while enhancing building performance, health, energy efficiency and sustainability.

[0001783180-23-000012:notes:268]
•The Refrigeration segment includes transport refrigeration and monitoring products, services and digital solutions for trucks, trailers, shipping containers, intermodal and rail, as well as commercial refrigeration products.

[0001783180-23-000012:notes:269]
•The Fire & Security segment provides a wide range of residential, commercial and industrial technologies designed to help protect people and property.

[0001783180-23-000012:notes:270]
The Company's customers are in both the public and private sectors and its businesses reflect extensive geographic diversification. Inter-company sales between segments are immaterial.

[0001783180-23-000012:notes:271]
Net sales and Operating profit by segment are as follows:

[0001783180-23-000012:notes:272]
|  | Net Sales |  | Operating Profit |
| (In millions) | 2022 |  | 2021 |  | 2020 |  | 2022 |  | 2021 |  | 2020 |
| HVAC | $ | 13,408 |  |  | $ | 11,390 |  |  | $ | 9,478 |  |  | $ | 2,610 |  |  | $ | 1,738 |  |  | $ | 2,462 |  |
| Refrigeration | 3,883 |  |  | 4,127 |  |  | 3,333 |  |  | 483 |  |  | 476 |  |  | 357 |  |
| Fire & Security | 3,570 |  |  | 5,515 |  |  | 4,985 |  |  | 1,630 |  |  | 662 |  |  | 584 |  |
| Total segment | 20,861 |  |  | 21,032 |  |  | 17,796 |  |  | 4,723 |  |  | 2,876 |  |  | 3,403 |  |
| Eliminations and other | (440) |  |  | (419) |  |  | (340) |  |  | (80) |  |  | (96) |  |  | (184) |  |
| General corporate expenses | — |  |  | — |  |  | — |  |  | (128) |  |  | (135) |  |  | (136) |  |
| Consolidated | $ | 20,421 |  |  | $ | 20,613 |  |  | $ | 17,456 |  |  | $ | 4,515 |  |  | $ | 2,645 |  |  | $ | 3,083 |  |

[0001783180-23-000012:notes:273]
Total assets are not presented for each segment as they are not presented to or reviewed by the CODM. Segment assets in the following table represent Accounts receivable, net, Contract assets, current and Inventories, net. These assets are regularly reviewed by management and are therefore reported in the following table as segment assets. All other remaining assets and liabilities for all periods presented are managed on a company-wide basis.

[0001783180-23-000012:notes:274]
|  | Segment Assets |  | Capital Expenditures |  | Depreciation & Amortization |
| (In millions) | 2022 |  | 2021 |  |  |  | 2022 |  | 2021 |  | 2020 |  | 2022 |  | 2021 |  | 2020 |
| HVAC | $ | 3,191 |  |  | $ | 2,375 |  |  |  |  | $ | 232 |  |  | $ | 225 |  |  | $ | 188 |  |  | $ | 256 |  |  | $ | 186 |  |  | $ | 163 |  |
| Refrigeration | 1,279 |  |  | 1,285 |  |  |  |  | 32 |  |  | 39 |  |  | 26 |  |  | 31 |  |  | 36 |  |  | 39 |  |
| Fire & Security | 1,492 |  |  | 1,203 |  |  |  |  | 40 |  |  | 49 |  |  | 51 |  |  | 58 |  |  | 83 |  |  | 108 |  |
| Total Segment | 5,962 |  |  | 4,863 |  |  |  |  | 304 |  |  | 313 |  |  | 265 |  |  | 345 |  |  | 305 |  |  | 310 |  |
| Eliminations and other | 48 |  |  | 13 |  |  |  |  | 49 |  |  | 31 |  |  | 47 |  |  | 35 |  |  | 33 |  |  | 26 |  |
| Consolidated | $ | 6,010 |  |  | $ | 4,876 |  |  |  |  | $ | 353 |  |  | $ | 344 |  |  | $ | 312 |  |  | $ | 380 |  |  | $ | 338 |  |  | $ | 336 |  |
| Cash and cash equivalents | 3,520 |  |  | 2,987 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other assets, current | 349 |  |  | 376 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets held for sale | — |  |  | 3,168 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total current assets | $ | 9,879 |  |  | $ | 11,407 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0001783180-23-000012:notes:275]
Geographic External Sales

[0001783180-23-000012:notes:276]
Geographic external sales and operating profits are attributed to the geographic regions based on their location of origin. With the exception of the U.S. as presented in the following table, there were no individually significant countries with sales exceeding 10% of total sales for the years ended December 31, 2022, 2021 and 2020.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001783180-23-000012:notes:277]
RELATED PARTIES 
Equity Method Investments

[0001783180-23-000012:notes:278]
The Company sells products to and purchases products from unconsolidated entities accounted for under the equity method and, therefore, these entities are considered to be related parties. The Company has 27 directly owned unconsolidated domestic and foreign affiliates as of December 31, 2022 and 2021, respectively, of which 99% of such investments are in its HVAC segment. Amounts attributable to equity method investees are as follows:

[0001783180-23-000012:notes:279]
| (In millions) | 2022 |  | 2021 |  | 2020 |
| Sales to equity method investees included in Product sales | $ | 2,845 |  |  | $ | 2,258 |  |  | $ | 1,758 |  |
| Purchases from equity method investees included in Cost of products sold | $ | 331 |  |  | $ | 357 |  |  | $ | 292 |  |

[0001783180-23-000012:notes:280]
The Company had receivables from and payables to equity method investees as follows:

[0001783180-23-000012:notes:281]
| (In millions) | 2022 |  | 2021 |
| Receivables from equity method investees included in Accounts receivable, net | $ | 154 |  |  | $ | 150 |  |
| Payables to equity method investees included in Accounts payable | $ | 44 |  |  | $ | 51 |  |

[0001783180-23-000012:notes:282]
The financial results of TCC are included in the Company's consolidated results since the acquisition date of August 1, 2022. Prior to the acquisition, the Company previously accounted for its minority ownership in TCC under the equity method of accounting. As a result, prior period results may not be comparable to the current period.

[0001783180-23-000012:notes:283]
The Company periodically reviews the carrying value of its equity method investments to determine if there has been an other-than-temporary decline in fair value. In 2020, the Company determined that indicators of impairment existed for a minority owned joint venture investment and performed a valuation of this investment using a discounted cash flow method. The Company determined that the loss in value was other-than-temporary due to a reduction in sales and earnings that were primarily driven by a deterioration in the oil and gas industry (the joint venture's primary market) and by the impact of the COVID-19 pandemic. As a result, the Company recorded a non-cash, other-than-temporary impairment charge of $71 million on this investment in 2020, which is included in Other income (expense), net on the accompanying Consolidated Statement of Operations.

[0001783180-23-000012:notes:284]
In September 2020, the Company sold 9.25 million B shares of Beijer for SEK290 ($32.38) per share equal to approximately 7.9% of the outstanding B shares in Beijer, through an accelerated equity offering. The Company received proceeds of approximately $300 million and recognized a pre-tax gain on the sale of $252 million, which is included in Other income (expense), net on the Consolidated Statement of Operations. Subsequently, in December 2020, the Company sold all of its remaining A and B shares of Beijer for SEK245 ($29.03) per share. The Company received proceeds of approximately $1.1 billion and recognized a pre-tax gain on the sale of $871 million, which is included in Other income (expense), net on the Consolidated Statement of Operations. Prior to the sale of the Company's remaining shares, Beijer was reported as an equity method investment.

[0001783180-23-000012:notes:285]
Summarized Financial Information. Pursuant to Rule 3-10 and Rule 4-08(g) of Regulation S-X under the Securities Act, the Company presents summarized financial information of the combined accounts of its non-consolidated joint ventures accounted for by the equity method.

[0001783180-23-000012:notes:286]
Summarized unaudited financial information for equity method investments is as follows:

[0001783180-23-000012:notes:287]
| (In millions) | 2022 |  | 2021 |
| Current assets | $ | 10,621 |  |  | $ | 4,275 |  |
| Non-current assets | 1,931 |  |  | 2,140 |  |
| Total assets | 12,552 |  |  | 6,415 |  |
| Current liabilities | (8,631) |  |  | (2,596) |  |
| Non-current liabilities | (195) |  |  | (329) |  |
| Total liabilities | (8,826) |  |  | (2,925) |  |
| Total net equity of investees | $ | 3,726 |  |  | $ | 3,490 |  |

[0001783180-23-000012:notes:288]
| (In millions) | 2022 |  | 2021 |  | 2020 |
| Net sales | $ | 11,524 |  |  | $ | 9,471 |  |  | $ | 9,299 |  |
| Gross profit | $ | 2,274 |  |  | $ | 1,907 |  |  | $ | 1,722 |  |
| Income from continuing operations | $ | 757 |  |  | $ | 650 |  |  | $ | 544 |  |
| Net income | $ | 757 |  |  | $ | 650 |  |  | $ | 544 |  |


## us-gaap:EquityMethodInvestmentsTextBlock

[0001783180-23-000012:notes:289]
Amounts attributable to equity method investees are as follows:


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001783180-23-000012:notes:290]
COMMITMENTS AND CONTINGENT LIABILITIES
The Company is involved in various litigation, claims and administrative proceedings, including those related to environmental (including asbestos) and legal matters. In accordance with ASC 450, Contingencies, the Company records accruals for loss contingencies when it is probable that a liability will be incurred and the amount of the loss can be reasonably estimated. These accruals are generally based upon a range of possible outcomes. If no amount within the range is a better estimate than any other, the Company accrues the minimum amount. In addition, these estimates are reviewed periodically and adjusted to reflect additional information when it becomes available. The Company is unable to predict the final outcome of the following matters based on the information currently available, except as otherwise noted. However, the Company does not believe that the resolution of any of these matters will have a material adverse effect upon the Company's competitive position, results of operations, cash flows or financial condition.

[0001783180-23-000012:notes:291]
Environmental Matters

[0001783180-23-000012:notes:292]
The Company’s operations are subject to environmental regulation by various authorities. The Company has accrued for the costs of environmental remediation activities, including but not limited to, investigatory, remediation, operating and maintenance costs and performance guarantees. The most likely cost to be incurred is accrued based on an evaluation of currently available facts with respect to individual sites, including the technology required to remediate, current laws and regulations and prior remediation experience.

[0001783180-23-000012:notes:293]
As of December 31, 2022 and 2021, the outstanding liability for environmental obligations are as follows:

[0001783180-23-000012:notes:294]
| (In millions) |  | 2022 |  | 2021 |
| Environmental reserves included in Accrued liabilities |  | $ | 24 |  |  | $ | 29 |  |
| Environmental reserves included in Other long-term liabilities |  | 211 |  |  | 191 |
| Total environmental reserves |  | $ | 235 |  |  | $ | 220 |  |

[0001783180-23-000012:notes:295]
For sites with multiple responsible parties, the Company considers its likely proportionate share of the anticipated remediation costs and the ability of other parties to fulfill their obligations in establishing a provision for these costs. Accrued environmental liabilities are not reduced by potential insurance reimbursements and are undiscounted.

[0001783180-23-000012:notes:296]
Asbestos Matters

[0001783180-23-000012:notes:297]
The Company has been named as a defendant in lawsuits alleging personal injury as a result of exposure to asbestos allegedly integrated into certain Carrier products or business premises. While the Company has never manufactured asbestos and no longer incorporates it into any currently-manufactured products, certain products that the Company no longer manufactures contained components incorporating asbestos. A substantial majority of these asbestos-related claims have been dismissed without payment or have been covered in full or in part by insurance or other forms of indemnity. Additional cases were litigated and settled without any insurance reimbursement. The amounts involved in asbestos-related claims were not material individually or in the aggregate in any period.

[0001783180-23-000012:notes:298]
The Company's asbestos liabilities and related insurance recoveries are as follows:

[0001783180-23-000012:notes:299]
| (In millions) |  | 2022 |  | 2021 |
| Asbestos liabilities included in Accrued liabilities |  | $ | 16 |  |  | $ | 17 |  |
| Asbestos liabilities included in Other long-term liabilities |  | 212 |  |  | 220 |  |
| Total asbestos liabilities |  | $ | 228 |  |  | $ | 237 |  |
| Asbestos-related recoveries included in Other assets, current |  | $ | 5 |  |  | $ | 5 |  |
| Asbestos-related recoveries included in Other assets |  | 90 |  |  | 93 |  |
| Total asbestos-related recoveries |  | $ | 95 |  |  | $ | 98 |  |

[0001783180-23-000012:notes:300]
The amounts recorded for asbestos-related liabilities are based on currently available information and assumptions that the Company believes are reasonable and are made with input from outside actuarial experts. These amounts are undiscounted and exclude the Company's legal fees to defend the asbestos claims, which are expensed as incurred. In addition, the Company has recorded insurance recovery receivables for probable asbestos-related recoveries.

[0001783180-23-000012:notes:301]
UTC Equity Awards Conversion Litigation

[0001783180-23-000012:notes:302]
On August 12, 2020, several former employees of UTC or its subsidiaries filed a putative class action complaint (the "Complaint") in the United States District Court for the District of Connecticut against Raytheon Technologies Corporation, Carrier, Otis, the former members of the UTC Board of Directors and the members of the Carrier and Otis Boards of Directors (Geraud Darnis, et al. v. Raytheon Technologies Corporation, et al.). The Complaint challenged the method by which UTC equity awards were converted to UTC, Carrier and Otis equity awards following the Separation and the Distribution. Defendants moved to dismiss the Complaint. Plaintiffs amended their Complaint on September 13, 2021 (the "Amended Complaint"). The Amended Complaint, with Raytheon, Carrier and Otis as the only defendants, asserted that the defendants are liable for breach of certain equity compensation plans and for breach of the implied covenant of good faith and fair dealing. The Amended Complaint also sought specific performance. Carrier believes all plaintiffs' claims against the Company are without merit. Defendants moved to dismiss the Amended Complaint. On September 30, 2022, the court dismissed the case against all defendants, with prejudice. Plaintiffs appealed the dismissal to the United States Court of Appeals for the Second Circuit. The briefing process is ongoing.

[0001783180-23-000012:notes:303]
Aqueous Film Forming Foam Litigation

[0001783180-23-000012:notes:304]
As of December 31, 2022, the Company and certain  of its subsidiaries, including Kidde-Fenwal, Inc. ("KFI"), have been named as defendants in more than 3,150 lawsuits filed by individuals in or removed to the federal courts of the United States alleging that the historic use of Aqueous Film Forming Foam ("AFFF") caused personal injuries and/or property damage. The Company and certain of its subsidiaries, including KFI, have also been named as a defendant in more than 300 lawsuits filed by several U.S. states, municipalities and water utilities in or removed to U.S. federal courts alleging that the historic use of AFFF caused contamination of property and water supplies. In December 2018, the U.S. Judicial Panel on Multidistrict Litigation transferred and consolidated all AFFF cases pending in the U.S. federal courts against the Company and others to the U.S. District Court for the District of South Carolina ("MDL Court") for pre-trial proceedings ("MDL Proceedings"). The individual

[0001783180-23-000012:notes:305]
plaintiffs in the MDL Proceedings generally seek damages for alleged personal injuries, medical monitoring, diminution in property value and injunctive relief to remediate alleged contamination of water supplies. The U.S. state, municipal and water utility plaintiffs in the MDL Proceedings generally seek damages and costs related to the remediation of public property and water supplies.

[0001783180-23-000012:notes:306]
AFFF is a firefighting foam, developed beginning in the late 1960s pursuant to U.S. military specification, used to extinguish certain types of hydrocarbon-fueled fires primarily at military bases and airports. AFFF was manufactured by several companies, including National Foam and Angus Fire. UTC subsidiaries first entered the AFFF business with their acquisition of National Foam and Angus Fire in 2005 as part of the acquisition of KFI and Kidde Products Limited ("KPL"). In 2013, KFI and KPL divested the National Foam and Angus Fire businesses to a third party. The Company acquired KFI and KPL as part of its separation from UTC in April 2020. During the eight-year period of its operation by KFI, National Foam manufactured AFFF for sale to government (including the U.S. federal government) and non-government customers in the U.S. at a single facility located in West Chester, Pennsylvania ("Pennsylvania Site"). During the same period, Angus Fire manufactured AFFF for sale outside the United States at a single facility located in Bentham, England.

[0001783180-23-000012:notes:307]
The key components of AFFF that contribute to its fire-extinguishing capabilities are known as fluorosurfactants. Niether the Company nor any of its former or current subsidiaries, including National Foam/Angus Fire and KFI/KPL, respectively, manufactured fluorosurfactants; they instead purchased these substances from unrelated third parties to in turn manufacture AFFF. Plaintiffs in the MDL Proceedings allege that the fluorosurfactants used by various manufacturers in producing AFFF contained, or over time degraded into, compounds known as perflourooctane sulfonate ("PFOS") and/or perflourooctane acid ("PFOA"). Plaintiffs further allege that, as a result of the use of AFFF, PFOS and PFOA were released into the environment and, in some instances, ultimately reached drinking water supplies.

[0001783180-23-000012:notes:308]
Plaintiffs in the MDL Proceedings allege that PFOS and PFOA contamination has resulted from the use of AFFF manufactured using a process known as ECF, and that this process was used exclusively by 3M. They also allege that PFOA contamination has resulted from the use of AFFF manufactured using a different process, known as telomerization, and that this process was used exclusively by the other AFFF manufacturers (including National Foam and Angus Fire). Compounds containing PFOS and PFOA (as well as many other per- and polyfluoroalkyl substances known collectively as "PFAS") have also been used for decades by many third parties in a number of different industries to manufacture firefighters’ protective outerwear, carpets, clothing, fabrics, cookware, food packaging, personal care products, cleaning products, paints, varnishes and other consumer and industrial products.

[0001783180-23-000012:notes:309]
Plaintiffs in the MDL Proceedings have named multiple defendants, including four suppliers of chemicals and raw materials used to manufacture fluorosurfactants, four fluorosurfactant manufacturers, two toll manufacturers of fluorosurfactants and seven current (including National Foam and Angus Fire) and former (including the Company and KFI) AFFF manufacturers.

[0001783180-23-000012:notes:310]
The defendants moved for summary judgment on the government contractor defense, which potentially applies to AFFF sold to or used by the U.S. government. After full briefing and oral argument, on September 16, 2022, the MDL court declined to enter summary judgment for the defendants. The defense, however, remains available at any trial to which it applies.

[0001783180-23-000012:notes:311]
On September 23, 2022, after completion of discovery, the MDL court selected one water provider case, the City of Stuart, FL v. 3M, et al., for a bellwether trial. That trial is tentatively scheduled for June 2023. The MDL court has ordered that the bellwether process for personal injury cases will begin in 2023. The court has not yet outlined details on that process or its timing.

[0001783180-23-000012:notes:312]
Outside of the MDL Proceedings, the Company and other defendants are also party to six lawsuits in U.S. state courts brought by oil refining companies alleging product liability claims related to legacy sales of AFFF and seeking damages for the costs to replace the product and for property damage. In addition, the Company and other defendants are party to two actions related to the Pennsylvania Site in which the plaintiff water utility company seeks remediation costs related to the alleged contamination of the local water supply.

[0001783180-23-000012:notes:313]
The Company and its subsidiaries, including KFI, and other defendants are also party to one action in Arizona state court brought by a firefighter claiming that occupational exposure to AFFF has caused him certain personal injuries. The Company and its subsidiaries, including KFI, believe that they have meritorious defenses to the claims in the MDL Proceedings and the other AFFF lawsuits. Based on its 2013 agreement for the sale of National Foam and Angus Fire, the Company and its subsidiaries, including KFI, are pursuing indemnification against these claims from the purchaser and current owner of National Foam and Angus Fire. The Company and its subsidiaries, including KFI, are also pursuing insurance coverage for these claims.

[0001783180-23-000012:notes:314]
At this time, however, given the numerous factual, scientific and legal issues to be resolved relating to these claims, the Company is unable to assess the probability of liability or to reasonably estimate the damages, if any, to be allocated to the Company and its subsidiaries, including KFI, if one or more plaintiffs were to prevail in these cases. There can be no assurance that any such future exposure will not be material in any period.

[0001783180-23-000012:notes:315]
Income Taxes

[0001783180-23-000012:notes:316]
Under the Tax Matters Agreement relating to the Separation, the Company is responsible to UTC for its share of the TCJA transition tax associated with foreign undistributed earnings as of December 31, 2017. As a result, liabilities of $34 million and $383 million are included within the accompanying Consolidated Balance Sheet within Accrued Liabilities and Other Long-Term Liabilities as of December 31, 2022, respectively. This obligation is expected to be settled in annual installments ending in April 2026 with the next installment of $34 million due in 2023. The Company believes that the likelihood of incurring losses materially in excess of this amount is remote.

[0001783180-23-000012:notes:317]
Self-Insurance

[0001783180-23-000012:notes:318]
The Company maintains self-insurance for a number of risks, including but not limited to, workers’ compensation, general liability, automobile liability, property and employee-related healthcare benefits. It has obtained insurance coverage for amounts exceeding individual and aggregate loss limits. The Company accrues for known future claims and incurred but not reported losses.

[0001783180-23-000012:notes:319]
The Company's self-insurance liabilities were as follows:

[0001783180-23-000012:notes:320]
| (In millions) | 2022 |  | 2021 |
| Self-insurance liabilities included in Accrued liabilities | $ | 139 |  |  | $ | 154 |  |
| Self-insurance liabilities included in Other long-term liabilities | 53 |  |  | 72 |
| Total self-insurance liabilities | $ | 192 |  |  | $ | 226 |  |

[0001783180-23-000012:notes:321]
The Company incurred expenses related to self-insured risks of $155 million, $155 million and $145 million for the years ended December 31, 2022, 2021 and 2020, respectively.

[0001783180-23-000012:notes:322]
Other Matters

[0001783180-23-000012:notes:323]
The Company has other commitments and contingent liabilities related to legal proceedings, self-insurance programs and matters arising in the ordinary course of business. The Company accrues for contingencies generally based upon a range of possible outcomes. If no amount within the range is a better estimate than any other, the Company accrues the minimum amount.

[0001783180-23-000012:notes:324]
In the ordinary course of business, the Company is also routinely a defendant in, party to or otherwise subject to many pending and threatened legal actions, claims, disputes and proceedings. These matters are often based on alleged violations of contract, product liability, warranty, regulatory, environmental, health and safety, employment, intellectual property, tax and other laws. In some of these proceedings, claims for substantial monetary damages are asserted against the Company and could result in fines, penalties, compensatory or treble damages or non-monetary relief. The Company does not believe that these matters will have a material adverse effect upon its competitive position, results of operations, cash flows or financial condition.


## us-gaap:CashFlowSupplementalDisclosuresTextBlock

[0001783180-23-000012:notes:325]
SUPPLEMENTAL CASH FLOW INFORMATION 
Supplemental cash flow information was as follows:

[0001783180-23-000012:notes:326]
| (In millions) | 2022 |  | 2021 |  | 2020 |
| Interest paid, net of amounts capitalized | $ | 297 |  |  | $ | 317 |  |  | $ | 196 |  |
| Income taxes paid, net of refunds | $ | 833 |  |  | $ | 675 |  |  | $ | 819 |  |
| Non-cash financing activity: |  |  |  |  |  |
| Common stock dividends payable | $ | 158 |  |  | $ | 130 |  |  | $ | 108 |  |
