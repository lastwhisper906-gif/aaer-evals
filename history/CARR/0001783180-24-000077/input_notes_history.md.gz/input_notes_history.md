# CARR note change history — 0001783180-24-000044 → 0001783180-24-000077


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-07-25):
[0001783180-24-000077:note_history:1]
| (In millions) |  | June 30,2024 |  | December 31,2023 |
| Environmental reserves included in Accrued liabilities |  | $ | 16 |  |  | $ | 21 |  |
| Environmental reserves included in Other long-term liabilities |  | 200 |  |  | 203 |  |
| Total Environmental reserves |  | $ | 216 |  |  | $ | 224 |  |
  (was, 2024-04-25, similarity 0.9831):
[0001783180-24-000044:note_history:1]
| (In millions) |  | March 31,2024 |  | December 31,2023 |
| Environmental reserves included in Accrued liabilities |  | $ | 19 |  |  | $ | 21 |  |
| Environmental reserves included in Other long-term liabilities |  | 201 |  |  | 203 |  |
| Total Environmental reserves |  | $ | 220 |  |  | $ | 224 |  |

- changed (2024-07-25):
[0001783180-24-000077:note_history:2]
| (In millions) |  | June 30,2024 |  | December 31,2023 |
| Asbestos liabilities included in Accrued liabilities |  | $ | 16 |  |  | $ | 15 |  |
| Asbestos liabilities included in Other long-term liabilities |  | 201 |  |  | 206 |  |
| Total Asbestos liabilities |  | $ | 217 |  |  | $ | 221 |  |
| Asbestos-related recoveries included in Other current assets |  | $ | 5 |  |  | $ | 5 |  |
| Asbestos-related recoveries included in Other assets |  | 86 |  |  | 88 |  |
| Total Asbestos-related recoveries |  | $ | 91 |  |  | $ | 93 |  |
  (was, 2024-04-25, similarity 0.9608):
[0001783180-24-000044:note_history:2]
| (In millions) |  | March 31,2024 |  | December 31,2023 |
| Asbestos liabilities included in Accrued liabilities |  | $ | 15 |  |  | $ | 15 |  |
| Asbestos liabilities included in Other long-term liabilities |  | 203 |  |  | 206 |  |
| Total Asbestos liabilities |  | $ | 218 |  |  | $ | 221 |  |
| Asbestos-related recoveries included in Other assets, current |  | $ | 5 |  |  | $ | 5 |  |
| Asbestos-related recoveries included in Other assets |  | 87 |  |  | 88 |  |
| Total Asbestos-related recoveries |  | $ | 92 |  |  | $ | 93 |  |

- changed (2024-07-25):
[0001783180-24-000077:note_history:3]
As of June 30, 2024, the Company, KFI and others have been named as defendants in more than 8,500 lawsuits filed by individuals in or removed to the federal courts of the United States alleging that the historic use of Aqueous Film Forming Foam ("AFFF") caused personal injuries and/or property damage. The Company, KFI and others have also been named as defendants in more than 800 lawsuits filed by several U.S. states, municipalities and water utilities in or removed to U.S. federal courts alleging that the historic use of AFFF caused contamination of property and water supplies. In December 2018, the U.S. Judicial Panel on Multidistrict Litigation transferred and consolidated all AFFF cases pending in the U.S. federal courts against the Company, KFI and others to the U.S. District Court for the District of South Carolina (the "MDL Proceedings"). The individual plaintiffs in the MDL Proceedings generally seek damages for alleged personal injuries, medical monitoring, diminution in property value and injunctive relief to remediate alleged contamination of water supplies. The U.S. state, municipal and water utility plaintiffs in the MDL Proceedings generally seek damages and costs related to the remediation of public property and water supplies.
  (was, 2024-04-25, similarity 0.9964):
[0001783180-24-000044:note_history:3]
As of March 31, 2024, the Company, KFI and others have been named as defendants in more than 7,000 lawsuits filed by individuals in or removed to the federal courts of the United States alleging that the historic use of Aqueous Film Forming Foam ("AFFF") caused personal injuries and/or property damage. The Company, KFI and others have also been named as defendants in more than 800 lawsuits filed by several U.S. states, municipalities and water utilities in or removed to U.S. federal courts alleging that the historic use of AFFF caused contamination of property and water supplies. In December 2018, the U.S. Judicial Panel on Multidistrict Litigation transferred and consolidated all AFFF cases pending in the U.S. federal courts against the Company, KFI and others to the U.S. District Court for the District of South Carolina (the "MDL Proceedings"). The individual plaintiffs in the MDL Proceedings generally seek damages for alleged personal injuries, medical monitoring, diminution in property value and injunctive relief to remediate alleged contamination of water supplies. The U.S. state, municipal and water utility plaintiffs in the MDL Proceedings generally seek damages and costs related to the remediation of public property and water supplies.

- changed (2024-07-25):
[0001783180-24-000077:note_history:4]
On May 14, 2023, KFI filed a voluntary petition with the United States Bankruptcy Court for the District of Delaware seeking relief under Chapter 11 of the Bankruptcy Code after the Company determined that it would not provide financial support to KFI going forward, other than ensuring KFI has access to services necessary for the effective operation of its business. As a result, all litigation against KFI is automatically stayed. KFI filed an adversary complaint and motion in the Chapter 11 case seeking an order staying or enjoining all AFFF-related litigation against the Company, its other subsidiaries and RTX. That motion was resolved through an agreement that effectively stays the AFFF litigation against these parties. KFI has also indicated to the bankruptcy court that it intends to pursue insurance coverage for AFFF-related liabilities and contractual indemnification for AFFF-related liabilities from the third party to which KFI sold National Foam. On November 21, 2023, the bankruptcy court ordered certain parties, including the Company, to participate in a mediation with respect to claims that might be asserted by and against it in the bankruptcy proceedings. The parties have engaged in several mediation sessions and anticipate further sessions in the future. The terms and scope of any potential settlement may be affected by, among other factors, the United States Supreme Court's decision in Harrington v. Purdue Pharma, L.P., which held that nonconsensual releases of litigation claims against non-debtors are unavailable.
  (was, 2024-04-25, similarity 0.9039):
[0001783180-24-000044:note_history:4]
On May 14, 2023, KFI filed a voluntary petition with the United States Bankruptcy Court for the District of Delaware seeking relief under Chapter 11 of the Bankruptcy Code after the Company determined that it would not provide financial support to KFI going forward, other than ensuring KFI has access to services necessary for the effective operation of its business. As a result, all litigation against KFI is automatically stayed. KFI filed an adversary complaint and motion in the Chapter 11 case seeking an order staying or enjoining all AFFF-related litigation against the Company, its other subsidiaries and RTX. That motion was resolved through an agreement that effectively stays the AFFF litigation against these parties. KFI has also indicated to the bankruptcy court that it intends to pursue insurance coverage for AFFF-related liabilities and contractual indemnification for AFFF-related liabilities from the third party to which KFI sold National Foam. On November 21, 2023, the bankruptcy court ordered certain parties, including the Company, to participate in a mediation with respect to claims that might be asserted by and against it in the bankruptcy proceedings. The parties have engaged in several mediation sessions and anticipate further sessions in the future. The terms and scope of any potential settlement may be affected by, among other factors, the bankruptcy court’s ability to approve nonconsensual releases of litigation claims against non-debtors, which the United States Supreme Court is expected to decide in Harrington v. Purdue Pharma, L.P.

- changed (2024-07-25):
[0001783180-24-000077:note_history:5]
In connection with the bankruptcy filing, KFI entered into several agreements with subsidiaries of the Company to ensure they have access to services necessary for the effective operation of their business. All post-deconsolidation activity between the Company and KFI are reported as third-party transactions recorded within the Company's Unaudited Condensed Consolidated Statement of Operations. Since the petition date, there were no material transactions between the Company and KFI other than a $15 million payment by the Company to KFI under the terms of a tax sharing arrangement.
  (was, 2024-04-25, similarity 0.9077):
[0001783180-24-000044:note_history:5]
In connection with the bankruptcy filing, KFI entered into several agreements with subsidiaries of the Company to ensure they have access to services necessary for the effective operation of their business. All post-deconsolidation activity between the Company and KFI are reported as third-party transactions recorded within the Company's Unaudited Condensed Consolidated Statement of Operations. Since the petition date, there were no material transactions between the Company and KFI.

- changed (2024-07-25):
[0001783180-24-000077:note_history:6]
On March 15, 2024, the Company and Pacific Avenue Capital Partners entered into certain agreements including a stock and asset purchase agreement whereby Pacific Avenue Capital Partners shall acquire certain assets and operating liabilities of KFI, subject to approval by the bankruptcy court. On April 1, 2024, the bankruptcy court subsequently approved the sale, which was completed on July 1, 2024 for $140 million, subject to working capital and other adjustments as provided in the sale agreement. However, there has been no determination with respect to the allocation of sale proceeds.
  (was, 2024-04-25, similarity 0.7014):
[0001783180-24-000044:note_history:6]
On March 15, 2024, the Company and Pacific Avenue Capital Partners entered into certain agreements including a stock and asset purchase agreement whereby Pacific Avenue Capital Partners shall acquire certain assets and operating liabilities of KFI, subject to approval by the bankruptcy court. On April 1, 2024, the bankruptcy court subsequently approved the sale. However, there has been no determination with respect to the allocation of sale proceeds.

- added (2024-07-25):
[0001783180-24-000077:note_history:7]
Under the TMA relating to the Separation, the Company is responsible to UTC for its share of the Tax Cuts and Jobs Act transition tax associated with foreign undistributed earnings as of December 31, 2017. During the six months ended June 30, 2024, the Company recognized a $46 million gain associated with the TMA and UTC's conclusion of certain income tax matters from their 2017 and 2018 tax audit with the IRS. Liabilities under the TMA of $118 million and $108 million are included within the accompanying Unaudited Condensed Consolidated Balance Sheet within Accrued Liabilities and Other Long-Term Liabilities as of June 30, 2024, respectively. This obligation is expected to be settled in annual installments with the next installment of $118 million due in April 2025 and the final installment due in April 2026. The Company believes that the likelihood of incurring losses materially in excess of this amount is remote.

- removed (2024-07-25):
[0001783180-24-000044:note_history:8]
Under the TMA relating to the Separation, the Company is responsible to UTC for its share of the Tax Cuts and Jobs Act transition tax associated with foreign undistributed earnings as of December 31, 2017. During the three months ended March 31, 2024, the Company recognized a $46 million gain associated with the TMA and UTC's conclusion of certain income tax matters from their 2017 and 2018 tax audit with the IRS. Liabilities under the TMA of $96 million and $233 million are included within the accompanying Unaudited Condensed Consolidated Balance Sheet within Accrued Liabilities and Other Long-Term Liabilities as of March 31, 2024, respectively. This obligation is expected to be settled in annual installments ending in April 2026 with the next installment of $96 million due in 2024. The Company believes that the likelihood of incurring losses materially in excess of this amount is remote.


## us-gaap:ScheduleOfEnvironmentalLossContingenciesBySiteTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-07-25):
[0001783180-24-000077:note_history:9]
| (In millions) |  | June 30,2024 |  | December 31,2023 |
| Environmental reserves included in Accrued liabilities |  | $ | 16 |  |  | $ | 21 |  |
| Environmental reserves included in Other long-term liabilities |  | 200 |  |  | 203 |  |
| Total Environmental reserves |  | $ | 216 |  |  | $ | 224 |  |
  (was, 2024-04-25, similarity 0.9831):
[0001783180-24-000044:note_history:9]
| (In millions) |  | March 31,2024 |  | December 31,2023 |
| Environmental reserves included in Accrued liabilities |  | $ | 19 |  |  | $ | 21 |  |
| Environmental reserves included in Other long-term liabilities |  | 201 |  |  | 203 |  |
| Total Environmental reserves |  | $ | 220 |  |  | $ | 224 |  |


## us-gaap:ScheduleOfLossContingenciesByContingencyTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-07-25):
[0001783180-24-000077:note_history:10]
| (In millions) |  | June 30,2024 |  | December 31,2023 |
| Asbestos liabilities included in Accrued liabilities |  | $ | 16 |  |  | $ | 15 |  |
| Asbestos liabilities included in Other long-term liabilities |  | 201 |  |  | 206 |  |
| Total Asbestos liabilities |  | $ | 217 |  |  | $ | 221 |  |
| Asbestos-related recoveries included in Other current assets |  | $ | 5 |  |  | $ | 5 |  |
| Asbestos-related recoveries included in Other assets |  | 86 |  |  | 88 |  |
| Total Asbestos-related recoveries |  | $ | 91 |  |  | $ | 93 |  |
  (was, 2024-04-25, similarity 0.9608):
[0001783180-24-000044:note_history:10]
| (In millions) |  | March 31,2024 |  | December 31,2023 |
| Asbestos liabilities included in Accrued liabilities |  | $ | 15 |  |  | $ | 15 |  |
| Asbestos liabilities included in Other long-term liabilities |  | 203 |  |  | 206 |  |
| Total Asbestos liabilities |  | $ | 218 |  |  | $ | 221 |  |
| Asbestos-related recoveries included in Other assets, current |  | $ | 5 |  |  | $ | 5 |  |
| Asbestos-related recoveries included in Other assets |  | 87 |  |  | 88 |  |
| Total Asbestos-related recoveries |  | $ | 92 |  |  | $ | 93 |  |


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2024-07-25):
[0001783180-24-000077:note_history:11]
On April 25, 2023, the Company announced that it entered into a Share Purchase Agreement (the “Agreement”) to acquire the climate solutions business (the "VCS Business") of Viessmann Group GmbH & Co. KG (“Viessmann”), a privately-held company. The acquisition was completed on January 2, 2024. As a result, the assets, liabilities and results of operations of the VCS Business are consolidated in the accompanying Unaudited Condensed Consolidated Financial Statements as of the date of acquisition and reported within the Company’s HVAC segment. See Note 15 – Acquisitions for additional information.
  (was, 2024-04-25, similarity 0.84):
[0001783180-24-000044:note_history:11]
On April 25, 2023, the Company announced that it entered into a Share Purchase Agreement (the “Agreement”) to acquire the climate solutions business (the "VCS Business") of Viessmann Group GmbH & Co. KG (“Viessmann”), a privately-held company. The VCS Business develops intelligent, integrated and sustainable technologies, including heat pumps, boilers, photovoltaic systems, home battery storage and digital solutions, primarily for residential customers in Europe. The acquisition was completed on January 2, 2024. As a result, the assets, liabilities and results of operations of the VCS Business are consolidated in the accompanying Unaudited Condensed Consolidated Financial Statements as of the date of acquisition and reported within the Company’s HVAC segment. See Note 15 – Acquisitions for additional information.

- added (2024-07-25):
[0001783180-24-000077:note_history:12]
On December 7, 2023, the Company entered into a stock purchase agreement to sell its Access Solutions business ("Access Solutions") to Honeywell International Inc. As a result, the assets and liabilities of Access Solutions are presented as held for sale on the accompanying Unaudited Condensed Consolidated Balance Sheet as of December 31, 2023, and recorded at the lower of their carrying value or fair value less estimated cost to sell. The sale of Access Solutions was completed on June 2, 2024. See Note 16 - Divestitures for additional information.

- added (2024-07-25):
[0001783180-24-000077:note_history:13]
On December 12, 2023, the Company entered into a stock purchase agreement to sell its Commercial Refrigeration business ("CCR") to Haier Group Corporation for an enterprise value of approximately $775 million. In addition, the net assets of the Company’s Industrial Fire business ("Industrial Fire") met the criteria to be classified as held for sale during the fourth quarter of 2023. As a result, the assets and liabilities of each business are presented as held for sale in the accompanying Unaudited Condensed Consolidated Balance Sheet as of June 30, 2024 and December 31, 2023, and recorded at the lower of their carrying value or fair value less estimated cost to sell. On March 5, 2024, the Company entered into a stock purchase agreement to sell Industrial Fire to Sentinel Capital Partners for an enterprise value of approximately $1.425 billion. The sale of Industrial Fire was completed on July 1, 2024. See Note 16 - Divestitures for additional information.

- changed (2024-07-25):
[0001783180-24-000077:note_history:14]
On May 14, 2023, Kidde-Fenwal, Inc. ("KFI"), an indirect wholly-owned subsidiary of the Company, filed a petition for voluntary reorganization under Chapter 11 of the United States Bankruptcy Code ("Chapter 11") in the United States Bankruptcy Court for the District of Delaware. KFI, an industrial fire detection and suppression business historically reported in the Company's Fire & Security segment, indicated that it intended to use the bankruptcy process to explore strategic alternatives, including the sale of KFI as a going concern. As of the petition date, KFI was deconsolidated and its respective assets and liabilities were derecognized from the Company's Unaudited Condensed Consolidated Financial Statements. See Note 19 - Commitments and Contingent Liabilities for additional information.
  (was, 2024-04-25, similarity 0.8573):
[0001783180-24-000044:note_history:14]
On May 14, 2023, Kidde-Fenwal, Inc. ("KFI"), an indirect wholly-owned subsidiary of the Company, filed a petition for voluntary reorganization under Chapter 11 of the United States Bankruptcy Code ("Chapter 11") in the United States Bankruptcy Court for the District of Delaware. KFI, an industrial fire detection and suppression business historically reported in the Company's Fire & Security segment, has indicated that it intends to use the bankruptcy process to explore strategic alternatives, including the sale of KFI as a going concern. KFI has further stated that, during the Chapter 11 process, KFI expects that there will be no significant interruptions to its business operations. As of the petition date, KFI was deconsolidated and its respective assets and liabilities were derecognized from the Company's Unaudited Condensed Consolidated Financial Statements. See Note 19 - Commitments and Contingent Liabilities for additional information.

- changed (2024-07-25):
[0001783180-24-000077:note_history:15]
On April 3, 2020 (the "Distribution Date"), United Technologies Corporation ("UTC"), since renamed RTX Corporation ("Raytheon Technologies Corporation" or "RTX"), completed the spin-off of Carrier into an independent, publicly traded company (the "Separation") through a pro-rata distribution (the "Distribution") on a one-for-one basis of all of the outstanding shares of common stock of Carrier to UTC shareowners who held shares of UTC common stock as of the close of business on March 19, 2020, the record date of the Distribution. Following the Separation and Distribution, the Company entered into several agreements with UTC and Otis Worldwide Corporation ("Otis") that govern various aspects of the relationship among the Company, UTC and Otis. As of June 30, 2024, only certain portions of the Tax Matters Agreement ("TMA") remain in effect.
  (was, 2024-04-25, similarity 0.994):
[0001783180-24-000044:note_history:15]
On April 3, 2020 (the Distribution Date"), United Technologies Corporation ("UTC"), since renamed RTX Corporation ("Raytheon Technologies Corporation" or "RTX"), completed the spin-off of Carrier into an independent, publicly traded company (the "Separation") through a pro-rata distribution (the "Distribution") on a one-for-one basis of all of the outstanding shares of common stock of Carrier to UTC shareowners who held shares of UTC common stock as of the close of business on March 19, 2020, the record date of the Distribution. Following the Separation and Distribution, the Company entered into several agreements with UTC and Otis Worldwide Corporation ("Otis") that govern various aspects of the relationship among the Company, UTC and Otis. As of March 31, 2024, only certain portions of the Tax Matters Agreement ("TMA") remain in effect.

- changed (2024-07-25):
[0001783180-24-000077:note_history:16]
In November 2023, the FASB issued ASU 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures (“ASU 2023-07”), which requires public entities to disclose information about their reportable segments’ significant expenses on an interim and annual basis. In addition, the amendments clarify circumstances in which an entity can disclose multiple segment measures of profit or loss, provide new segment disclosure requirements for entities with a single reportable segment and contain other disclosure requirements. ASU 2023-07 is effective for fiscal years beginning after December 15, 2023 and interim periods beginning after December 15, 2024, with early adoption permitted. The Company is currently assessing the impact of this ASU on its financial statements.
  (was, 2024-04-25, similarity 0.9429):
[0001783180-24-000044:note_history:16]
In November 2023, the FASB issued ASU 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures (“ASU 2023-07”), which requires public entities to disclose information about their reportable segments’ significant expenses on an interim and annual basis. In addition, the amendments clarify circumstances in which an entity can disclose multiple segment measures of profit or loss, provide new segment disclosure requirements for entities with a single reportable segment and contain other disclosure requirements. ASU 2023-07 is effective for fiscal years beginning after December 15, 2023 and interim periods within fiscal years beginning after December 15, 2024, with early adoption permitted. The Company is currently assessing the impact of this ASU on its financial statements.

- changed (2024-07-25):
[0001783180-24-000077:note_history:17]
On March 6, 2024, the SEC adopted new rules designed to enhance public company disclosures related to the risks and impacts of climate-related matters. The rules amend the provisions of both Regulation S-K and Regulation S-X to require disclosure of climate-related risks, transition plans, targets and goals, risk management and governance as well as require disclosure of the financial effects of severe weather events and other natural conditions as well as the use of carbon offsets or renewable energy credits. Disclosure requirements will begin phasing in for fiscal years beginning on or after January 1, 2025, subject to legal challenges and the SEC's voluntary stay of the disclosure requirements. The Company will continue to assess the impact of these new rules on its financial statements while the stay is in place.
  (was, 2024-04-25, similarity 0.8828):
[0001783180-24-000044:note_history:17]
On March 6, 2024, the SEC adopted new rules designed to enhance public company disclosures related to the risks and impacts of climate-related matters. The rules amend the provisions of both Regulation S-K and Regulation S-X and will be required in annual reports and registration statements. Amendments to Regulation S-K require disclosure of climate-related risks, transition plans, targets and goals, risk management and governance. Amendments to Regulation S-X require disclosure of the financial effects of severe weather events and other natural conditions as well as the use of carbon offsets or renewable energy credits. Disclosure requirements will begin phasing in for fiscal years beginning on or after January 1, 2025, subject to legal challenges and the SEC's voluntary stay of the disclosure requirements. The Company will continue to assess the impact of these new rules on its financial statements while the stay is in place.

- removed (2024-07-25):
[0001783180-24-000044:note_history:18]
On April 25, 2023, the Company announced plans to exit its Fire & Security and Commercial Refrigeration businesses over the course of 2024. On December 7, 2023, the Company entered into a stock purchase agreement to sell its Access Solutions business ("Access Solutions") to Honeywell International Inc. for an enterprise value of approximately $4.95 billion. Access Solutions, historically reported in the Company's Fire & Security segment, is a global supplier of physical security and digital access solutions supporting the hospitality, commercial, education and military markets. On December 12, 2023, the Company entered into a stock purchase agreement to sell its Commercial Refrigeration business ("CCR") to Haier Group Corporation for an enterprise value of approximately $775 million. CCR, historically reported in the Company's Refrigeration segment, is a global supplier of turnkey solutions for commercial refrigeration systems and services, with a primary focus on serving food retail customers, cold storage facilities and warehouses. As a result, the assets and liabilities of each business are presented as held for sale in the accompanying Unaudited Condensed Consolidated Balance Sheet as of March 31, 2024 and December 31, 2023, and recorded at the lower of their carrying value or fair value less estimated cost to sell. See Note 16 - Divestitures for additional information.

- removed (2024-07-25):
[0001783180-24-000044:note_history:19]
In addition, the net assets of the Company’s Industrial Fire business ("Industrial Fire") met the criteria to be classified as held for sale during the fourth quarter of 2023. Industrial Fire, historically reported in the Company's Fire & Security segment, is a leading manufacturer of a full spectrum of fire detection and suppression solutions and services in critical high-hazard environments, including oil and gas, power generation, marine and offshore facilities, automotive, data centers and aircraft hangars. As a result, the assets and liabilities of the business are presented as held for sale in the accompanying Unaudited Condensed Consolidated Balance Sheet as of March 31, 2024 and December 31, 2023, and recorded at the lower of their carrying value or fair value less estimated cost to sell. On March 5, 2024, the Company entered into a stock purchase agreement to sell Industrial Fire to Sentinel Capital Partners for an enterprise value of approximately $1.425 billion. See Note 16 - Divestitures for additional information.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2024-07-25):
[0001783180-24-000077:note_history:20]
DESCRIPTION OF THE BUSINESS
Carrier Global Corporation (the "Company") is a global leader in intelligent climate and energy solutions with a focus on providing differentiated, digitally-enabled lifecycle solutions to its customers. The Company's portfolio includes industry-leading brands such as Carrier, Viessmann, Toshiba, Automated Logic, Carrier Transicold, Kidde and Edwards that offer innovative heating, ventilating, air conditioning ("HVAC"), refrigeration, fire and building automation technologies to help make the world safer and more comfortable. The Company also provides a broad array of related building services, including audit, design, installation, system integration, repair, maintenance and monitoring. The Company's operations are classified into three segments: HVAC, Refrigeration and Fire & Security.
  (was, 2024-04-25, similarity 0.9838):
[0001783180-24-000044:note_history:20]
DESCRIPTION OF THE BUSINESS
Carrier Global Corporation (the "Company") is a global leader in intelligent climate and energy solutions with a focus on providing differentiated, digitally-enabled lifecycle solutions to its customers. The Company's portfolio includes industry-leading brands such as Carrier, Viessmann, Toshiba, Automated Logic, Carrier Transicold, Kidde, Edwards and LenelS2 that offer innovative heating, ventilating, air conditioning ("HVAC"), refrigeration, fire, security and building automation technologies to help make the world safer and more comfortable. The Company also provides a broad array of related building services, including audit, design, installation, system integration, repair, maintenance and monitoring. The Company's operations are classified into three segments: HVAC, Refrigeration and Fire & Security.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-07-25):
[0001783180-24-000077:note_history:21]
| (In millions) |  |  |  | June 30,2024 |  | December 31,2023 |
| 2.242% Notes due 2025 (1) |  |  |  | $ | 1,200 |  |  | $ | 1,200 |  |
| 4.375% Notes due 2025 (2) |  |  |  | 801 |  |  | 830 |  |
| 5.800% Notes due 2025 |  |  |  | — |  |  | 1,000 |  |
| 2.493% Notes due 2027 |  |  |  | 900 |  |  | 900 |  |
| 4.125% Notes due 2028 |  |  |  | 801 |  |  | 830 |  |
| 2.722% Notes due 2030 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.700% Notes due 2031 |  |  |  | 750 |  |  | 750 |  |
| 4.500% Notes due 2032 |  |  |  | 908 |  |  | 941 |  |
| 5.900% Notes due 2034 |  |  |  | 1,000 |  |  | 1,000 |  |
| 3.377% Notes due 2040 |  |  |  | 1,500 |  |  | 1,500 |  |
| 3.577% Notes due 2050 |  |  |  | 2,000 |  |  | 2,000 |  |
| 6.200% Notes due 2054 |  |  |  | 1,000 |  |  | 1,000 |  |
| Total long-term notes |  |  |  | 12,860 |  |  | 13,951 |  |
| Japanese Term Loan Facility |  |  |  | 337 |  |  | 379 |  |
| Other debt (including project financing obligations and finance leases) |  |  |  | 220 |  |  | 74 |  |
| Discounts and debt issuance costs |  |  |  | (95) |  |  | (111) |  |
| Total debt |  |  |  | 13,322 |  |  | 14,293 |  |
| Less: current portion of long-term debt |  |  |  | 2,052 |  |  | 51 |  |
| Long-term debt, net of current portion |  |  |  | $ | 11,270 |  |  | $ | 14,242 |  |
  (was, 2024-04-25, similarity 0.9208):
[0001783180-24-000044:note_history:21]
| (In millions) |  |  |  | March 31,2024 |  | December 31,2023 |
| 2.242% Notes due 2025 (1) |  |  |  | $ | 1,200 |  |  | $ | 1,200 |  |
| 4.375% Notes due 2025 |  |  |  | 812 |  |  | 830 |  |
| 5.800% Notes due 2025 |  |  |  | 1,000 |  |  | 1,000 |  |
| 2.493% Notes due 2027 |  |  |  | 900 |  |  | 900 |  |
| 4.125% Notes due 2028 |  |  |  | 812 |  |  | 830 |  |
| 2.722% Notes due 2030 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.700% Notes due 2031 |  |  |  | 750 |  |  | 750 |  |
| 4.500% Notes due 2032 |  |  |  | 921 |  |  | 941 |  |
| 5.900% Notes due 2034 |  |  |  | 1,000 |  |  | 1,000 |  |
| 3.377% Notes due 2040 |  |  |  | 1,500 |  |  | 1,500 |  |
| 3.577% Notes due 2050 |  |  |  | 2,000 |  |  | 2,000 |  |
| 6.200% Notes due 2054 |  |  |  | 1,000 |  |  | 1,000 |  |
| Total long-term notes |  |  |  | 13,895 |  |  | 13,951 |  |
| Delayed Draw Facility |  |  |  | 2,536 |  |  | — |  |
| Japanese Term Loan Facility |  |  |  | 357 |  |  | 379 |  |
| Other debt (including project financing obligations and finance leases) |  |  |  | 213 |  |  | 74 |  |
| Discounts and debt issuance costs |  |  |  | (106) |  |  | (111) |  |
| Total debt |  |  |  | 16,895 |  |  | 14,293 |  |
| Less: current portion of long-term debt |  |  |  | 1,248 |  |  | 51 |  |
| Long-term debt, net of current portion |  |  |  | $ | 15,647 |  |  | $ | 14,242 |  |

- added (2024-07-25):
[0001783180-24-000077:note_history:22]
(2) 4.375% Notes due May 29, 2025; reclassified to Current portion of long-term debt.

- changed (2024-07-25):
[0001783180-24-000077:note_history:23]
In November 2023, the Company issued $3.0 billion principal amount of USD-denominated notes in three tranches. The tranches consisted of $1.0 billion aggregate principal amount of 5.80% notes due 2025, $1.0 billion aggregate principal amount of 5.90% notes due 2034 and $1.0 billion aggregate principal amount of 6.20% notes due 2054 (collectively, the “USD Notes”). In addition, the Company issued €2.35 billion principal amount of Euro-denominated notes in three tranches. The tranches consisted of €750 million aggregate principal amount of 4.375% notes due 2025, €750 million aggregate principal amount of 4.125% notes due 2028 and €850 million aggregate principal amount of 4.50% notes due 2032 (collectively, the “Euro Notes”). The Company capitalized $51 million of deferred financing costs which are being amortized over the term of their related notes. The notes are subject to certain customary covenants and the Company has the option to redeem the notes in whole or in part at any time prior to their stated maturity date at the redemption price set forth in the indenture agreements. In June 2024, the Company redeemed the $1.0 billion aggregate principal amount of 5.80% notes due in 2025 and incurred a $8 million make-whole premium upon prepayment and wrote off $4 million of related unamortized debt financing costs.
  (was, 2024-04-25, similarity 0.9015):
[0001783180-24-000044:note_history:23]
In November 2023, the Company issued $3.0 billion principal amount of USD-denominated notes in three tranches. The tranches consisted of $1.0 billion aggregate principal amount of 5.8% notes due 2025, $1.0 billion aggregate principal amount of 5.90% notes due 2034 and $1.0 billion aggregate principal amount of 6.2% notes due 2054 (collectively, the “USD Notes”). In addition, the Company issued €2.35 billion principal amount of Euro-denominated notes in three tranches. The tranches consisted of €750 million aggregate principal amount of 4.375% notes due 2025, €750 million aggregate principal amount of 4.125% notes due 2028 and €850 million aggregate principal amount of 4.5% notes due 2032 (collectively, the “Euro Notes”). The Company capitalized $51 million of deferred financing costs which are being amortized over the term of their related notes. The notes are subject to certain customary covenants and the Company has the option to redeem the notes in whole or in part at any time, prior to their stated maturity date at the redemption price set forth in the indenture agreements.

- changed (2024-07-25):
[0001783180-24-000077:note_history:24]
On April 25, 2023, the Company entered into commitment letters with JPMorgan Chase Bank, N.A., BofA Securities, Inc. and Bank of America, N.A. to provide a €8.2 billion aggregate principal, senior unsecured bridge term loan facility (the “Bridge Loan”). Euro-denominated borrowings bore interest at the EURIBOR Rate plus a ratings-based margin, USD-denominated borrowings bore interest at either a Term SOFR Rate plus 0.10% and a ratings-based margin or, alternatively, at a base rate plus a ratings-based margin. The Company capitalized $48 million of deferred financing costs associated with the Bridge Loan which were amortized over the commitment period. Upon entering into a senior unsecured delayed draw term loan facility and issuing the USD Notes and the Euro Notes, the Company reduced the Bridge Loan by €7.7 billion and accelerated the amortization on $25 million of deferred financing costs in Interest expense during 2023. On January 2, 2024, the Company entered into a 60-day senior unsecured term loan agreement consisting of a Euro-denominated tranche in an aggregate amount of €113 million and a USD-denominated tranche in an aggregate amount of $349 million (the “60-day Loan”). Upon entering into the 60-day Loan, the Company reduced the final portion of the Bridge Loan by €500 million and subsequently terminated the agreement. Borrowings under the 60-day Loan were repaid in March 2024.
  (was, 2024-04-25, similarity 0.9779):
[0001783180-24-000044:note_history:24]
On April 25, 2023, the Company entered into commitment letters with JPMorgan Chase Bank, N.A., BofA Securities, Inc. and Bank of America, N.A. to provide a €8.2 billion aggregate principal, senior unsecured bridge term loan facility (the “Bridge Loan”). Euro-denominated borrowings bore interest at the EURIBOR Rate plus a ratings-based margin, USD-denominated borrowings bore interest at either a Term SOFR Rate plus 0.10% and a ratings-based margin or, alternatively, at a base rate plus a ratings-based margin. The Company capitalized $48 million of deferred financing costs associated with the Bridge Loan which were amortized over the commitment period. Upon entering into a senior unsecured delayed draw term loan facility and issuing the USD Notes and the Euro Notes, the Company reduced the Bridge Loan by €7.7 billion and accelerated the amortization on $25 million of deferred financing costs in Interest expense during 2023. On January 2, 2024, the Company entered into a 60-day senior unsecured term loan agreement consisting of a Euro-denominated tranche in an aggregate amount of €113 million and a USD-denominated tranche in an aggregate amount of $349 million (the “60-day Loan”). Upon entering into the 60-day Loan, the Company reduced the final portion of the Bridge Loan by €500 million and subsequently terminated the agreement. As of March 31, 2024, borrowings under the 60-day Loan have been fully repaid.

- changed (2024-07-25):
[0001783180-24-000077:note_history:25]
On May 19, 2023, the Company entered into a senior unsecured delayed draw term loan credit agreement with JPMorgan Chase Bank, N.A., as administrative agent and certain other lenders that permits aggregate borrowings of up to €2.3 billion (the "Delayed Draw Facility"). The facility consists of an 18-month, Euro-denominated tranche in an aggregate amount of €1.15 billion and a 3-year, Euro-denominated tranche in an aggregate amount of €1.15 billion. Euro-denominated borrowings bear interest at the EURIBOR Rate plus a ratings-based margin, USD-denominated borrowings bear interest at either a Term SOFR Rate plus 0.10% and a ratings-based margin or, alternatively, at a base rate plus a ratings-based margin. The Company capitalized $4 million of deferred financing costs which will be amortized over the respective term of the tranches. On January 2, 2024, the Company borrowed the full amount available under the Delayed Draw Facility in U.S. Dollars. Borrowings under the Delayed Draw Facility were repaid in June 2024 and the facility was subsequently terminated.
  (was, 2024-04-25, similarity 0.9439):
[0001783180-24-000044:note_history:25]
On May 19, 2023, the Company entered into a senior unsecured delayed draw term loan credit agreement with JPMorgan Chase Bank, N.A., as administrative agent and certain other lenders that permits aggregate borrowings of up to €2.3 billion (the "Delayed Draw Facility"). The facility consists of an 18-month, Euro-denominated tranche in an aggregate amount of €1.15 billion and a 3-year, Euro-denominated tranche in an aggregate amount of €1.15 billion. Euro-denominated borrowings bear interest at the EURIBOR Rate plus a ratings-based margin, USD-denominated borrowings bear interest at either a Term SOFR Rate plus 0.10% and a ratings-based margin or, alternatively, at a base rate plus a ratings-based margin. The Company capitalized $4 million of deferred financing costs which will be amortized over the respective term of the tranches. On January 2, 2024, the Company borrowed the full amount available under the Delayed Draw Facility in U.S. Dollars.

- changed (2024-07-25):
[0001783180-24-000077:note_history:26]
364-Day Revolver
  (was, 2024-04-25, similarity 0.9286):
[0001783180-24-000044:note_history:26]
364 Day Revolver

- added (2024-07-25):
[0001783180-24-000077:note_history:27]
On May 17, 2024, the Company entered into a 364-day, $500 million, senior unsecured revolving credit agreement with JPMorgan Chase Bank, N.A., as administrative agent and certain other lenders (the “364-day Revolver”). Borrowings are available in U.S. Dollars and Euros. USD-denominated borrowings bear interest at either a Term SOFR Rate plus 0.10% and a ratings-based margin or, alternatively, at a base rate plus a ratings-based margin, Euro-denominated borrowings bear interest at the Adjusted EURIBOR Rate plus a ratings-based margin. Upon entering into the 364-day Revolver, the Company terminated its existing $500 million senior unsecured revolving credit agreement that was set to mature in May 2024. As of June 30, 2024, there were no borrowings outstanding under the 364-day Revolver.

- changed (2024-07-25):
[0001783180-24-000077:note_history:28]
On May 19, 2023, the Company entered into a revolving credit agreement with JPMorgan Chase Bank, N.A., as administrative agent, and certain other lenders, permitting aggregate borrowings of up to $2.0 billion pursuant to an unsecured, unsubordinated revolving credit facility that matures in May 2028 (the "Revolving Credit Facility"). The Revolving Credit Facility supports the Company's commercial paper program and can be used for other general corporate purposes. Borrowings are available in U.S. Dollars and Euros. U.S. Dollar borrowings bear interest at either a Term SOFR Rate plus 0.10% and a ratings-based margin or, alternatively, at an alternate base rate plus a ratings-based margin. Euro borrowings bear interest at an adjusted EURIBOR rate plus a ratings-based margin. A ratings-based commitment fee is charged on unused commitments. In addition, the Company capitalized $2 million of deferred financing costs which are being amortized over its term. As of June 30, 2024, there were no borrowings outstanding under the Revolving Credit Facility.
  (was, 2024-04-25, similarity 0.9354):
[0001783180-24-000044:note_history:28]
On May 19, 2023, the Company entered into a revolving credit agreement with JPMorgan Chase Bank, N.A., as administrative agent, and certain other lenders, permitting aggregate borrowings of up to $2.0 billion pursuant to an unsecured, unsubordinated revolving credit facility that matures in May 2028 (the "Revolving Credit Facility"). The Revolving Credit Facility supports the Company's commercial paper program and can be used for other general corporate purposes. Borrowings are available in U.S. Dollars and Euros. U.S. Dollar borrowings can bear interest at either a Term SOFR Rate plus 0.10% and a ratings-based margin or, alternatively, at an alternate base rate plus a ratings-based margin. Euro borrowings bear interest at an adjusted EURIBOR rate plus a ratings-based margin. A ratings-based commitment fee is charged on unused commitments. Upon entering into the agreement, the Company terminated its existing revolving credit facility that was set to mature in April 2025. In addition, the Company capitalized $2 million of deferred financing costs which are being amortized over its term. As of March 31, 2024, there were no borrowings outstanding under the Revolving Credit Facility.

- changed (2024-07-25):
[0001783180-24-000077:note_history:29]
The Company has a $2.0 billion unsecured, unsubordinated commercial paper program, which can be used for general corporate purposes, including the funding of working capital and potential acquisitions. As of June 30, 2024, there were no borrowings outstanding under the commercial paper program.
  (was, 2024-04-25, similarity 0.9843):
[0001783180-24-000044:note_history:29]
The Company has a $2.0 billion unsecured, unsubordinated commercial paper program, which can be used for general corporate purposes, including the funding of working capital and potential acquisitions. As of March 31, 2024, there were no borrowings outstanding under the commercial paper program.

- changed (2024-07-25):
[0001783180-24-000077:note_history:30]
The Company is involved in long-term construction contracts in which it arranges project financing with certain customers. As a result, the Company issued $20 million and $6 million of debt during the six months ended June 30, 2024 and 2023, respectively. Long-term debt repayments associated with these financing arrangements during the six months ended June 30, 2024 and 2023 were $6 million and $12 million, respectively.
  (was, 2024-04-25, similarity 0.8897):
[0001783180-24-000044:note_history:30]
The Company is involved in long-term construction contracts in which it arranges project financing with certain customers. As a result, the Company issued $10 million and $5 million of debt during the three months ended March 31, 2024 and 2023, respectively. Long-term debt repayments associated with these financing arrangements during the three months ended March 31, 2024 and 2023 were $5 million and $2 million, respectively.

- added (2024-07-25):
[0001783180-24-000077:note_history:31]
The Revolving Credit Facility, 364-day Revolver, the indenture for the long-term notes and the Japanese Term Loan Facility contain affirmative and negative covenants customary for financings of these types, which, among other things, limit the Company's ability to incur certain liens, to make certain fundamental changes and to enter into sale and leaseback transactions. As of June 30, 2024, the Company was in compliance with the covenants under the agreements governing its outstanding indebtedness.

- removed (2024-07-25):
[0001783180-24-000044:note_history:32]
On May 19, 2023, the Company entered into a 364-day, $500 million, senior unsecured revolving credit agreement with JPMorgan Chase Bank, N.A., as administrative agent and certain other lenders (the “Revolver”), the proceeds of which became available upon closing of the acquisition of the VCS Business. Borrowings bear interest at either a Term SOFR Rate plus 0.10% and a ratings-based margin or, alternatively, at a base rate plus a ratings-based margin. As of March 31, 2024, there were no borrowings outstanding under the Revolver.

- removed (2024-07-25):
[0001783180-24-000044:note_history:33]
The Revolving Credit Facility, Revolver, the indenture for the long-term notes and the Japanese Term Loan Facility contain affirmative and negative covenants customary for financings of these types, which, among other things, limit the Company's ability to incur certain liens, to make certain fundamental changes and to enter into sale and leaseback transactions. As of March 31, 2024, the Company was in compliance with the covenants under the agreements governing its outstanding indebtedness.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-07-25):
[0001783180-24-000077:note_history:34]
| (In millions) |  |  |  | June 30,2024 |  | December 31,2023 |
| 2.242% Notes due 2025 (1) |  |  |  | $ | 1,200 |  |  | $ | 1,200 |  |
| 4.375% Notes due 2025 (2) |  |  |  | 801 |  |  | 830 |  |
| 5.800% Notes due 2025 |  |  |  | — |  |  | 1,000 |  |
| 2.493% Notes due 2027 |  |  |  | 900 |  |  | 900 |  |
| 4.125% Notes due 2028 |  |  |  | 801 |  |  | 830 |  |
| 2.722% Notes due 2030 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.700% Notes due 2031 |  |  |  | 750 |  |  | 750 |  |
| 4.500% Notes due 2032 |  |  |  | 908 |  |  | 941 |  |
| 5.900% Notes due 2034 |  |  |  | 1,000 |  |  | 1,000 |  |
| 3.377% Notes due 2040 |  |  |  | 1,500 |  |  | 1,500 |  |
| 3.577% Notes due 2050 |  |  |  | 2,000 |  |  | 2,000 |  |
| 6.200% Notes due 2054 |  |  |  | 1,000 |  |  | 1,000 |  |
| Total long-term notes |  |  |  | 12,860 |  |  | 13,951 |  |
| Japanese Term Loan Facility |  |  |  | 337 |  |  | 379 |  |
| Other debt (including project financing obligations and finance leases) |  |  |  | 220 |  |  | 74 |  |
| Discounts and debt issuance costs |  |  |  | (95) |  |  | (111) |  |
| Total debt |  |  |  | 13,322 |  |  | 14,293 |  |
| Less: current portion of long-term debt |  |  |  | 2,052 |  |  | 51 |  |
| Long-term debt, net of current portion |  |  |  | $ | 11,270 |  |  | $ | 14,242 |  |
  (was, 2024-04-25, similarity 0.9208):
[0001783180-24-000044:note_history:34]
| (In millions) |  |  |  | March 31,2024 |  | December 31,2023 |
| 2.242% Notes due 2025 (1) |  |  |  | $ | 1,200 |  |  | $ | 1,200 |  |
| 4.375% Notes due 2025 |  |  |  | 812 |  |  | 830 |  |
| 5.800% Notes due 2025 |  |  |  | 1,000 |  |  | 1,000 |  |
| 2.493% Notes due 2027 |  |  |  | 900 |  |  | 900 |  |
| 4.125% Notes due 2028 |  |  |  | 812 |  |  | 830 |  |
| 2.722% Notes due 2030 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.700% Notes due 2031 |  |  |  | 750 |  |  | 750 |  |
| 4.500% Notes due 2032 |  |  |  | 921 |  |  | 941 |  |
| 5.900% Notes due 2034 |  |  |  | 1,000 |  |  | 1,000 |  |
| 3.377% Notes due 2040 |  |  |  | 1,500 |  |  | 1,500 |  |
| 3.577% Notes due 2050 |  |  |  | 2,000 |  |  | 2,000 |  |
| 6.200% Notes due 2054 |  |  |  | 1,000 |  |  | 1,000 |  |
| Total long-term notes |  |  |  | 13,895 |  |  | 13,951 |  |
| Delayed Draw Facility |  |  |  | 2,536 |  |  | — |  |
| Japanese Term Loan Facility |  |  |  | 357 |  |  | 379 |  |
| Other debt (including project financing obligations and finance leases) |  |  |  | 213 |  |  | 74 |  |
| Discounts and debt issuance costs |  |  |  | (106) |  |  | (111) |  |
| Total debt |  |  |  | 16,895 |  |  | 14,293 |  |
| Less: current portion of long-term debt |  |  |  | 1,248 |  |  | 51 |  |
| Long-term debt, net of current portion |  |  |  | $ | 15,647 |  |  | $ | 14,242 |  |

- added (2024-07-25):
[0001783180-24-000077:note_history:35]
(2) 4.375% Notes due May 29, 2025; reclassified to Current portion of long-term debt.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2024-07-25):
[0001783180-24-000077:note_history:36]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
| (In millions) |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Sales to equity method investees included in Product sales |  | $ | 832 |  |  | $ | 887 |  |  | $ | 1,555 |  |  | $ | 1,641 |  |
| Purchases from equity method investees included in Cost of products sold |  | $ | 59 |  |  | $ | 59 |  |  | $ | 114 |  |  | $ | 102 |  |
  (was, 2024-04-25, similarity 0.7076):
[0001783180-24-000044:note_history:36]
|  |  |  |  | Three Months Ended March 31, |
| (In millions) |  |  |  |  |  | 2024 |  | 2023 |
| Sales to equity method investees included in Product sales |  |  |  |  |  | $ | 723 |  |  | $ | 754 |  |
| Purchases from equity method investees included in Cost of products sold |  |  |  |  |  | $ | 55 |  |  | $ | 43 |  |

- changed (2024-07-25):
[0001783180-24-000077:note_history:37]
| (In millions) |  | June 30,2024 |  | December 31,2023 |
| Receivables from equity method investees included in Accounts receivable, net |  | $ | 276 |  |  | $ | 231 |  |
| Payables to equity method investees included in Accounts payable |  | $ | 51 |  |  | $ | 44 |  |
  (was, 2024-04-25, similarity 0.9814):
[0001783180-24-000044:note_history:37]
| (In millions) |  | March 31,2024 |  | December 31,2023 |
| Receivables from equity method investees included in Accounts receivable, net |  | $ | 261 |  |  | $ | 231 |  |
| Payables to equity method investees included in Accounts payable |  | $ | 44 |  |  | $ | 44 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-07-25):
[0001783180-24-000077:note_history:38]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
| (In millions) |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Sales Type |  |  |  |  |  |  |  |  |
| Product |  | $ | 4,468 |  |  | $ | 3,754 |  |  | $ | 8,541 |  |  | $ | 6,955 |  |
| Service |  | 502 |  |  | 462 |  |  | 970 |  |  | 883 |  |
| HVAC sales |  | 4,970 |  |  | 4,216 |  |  | 9,511 |  |  | 7,838 |  |
| Product |  | 851 |  |  | 858 |  |  | 1,623 |  |  | 1,645 |  |
| Service |  | 122 |  |  | 114 |  |  | 234 |  |  | 225 |  |
| Refrigeration sales |  | 973 |  |  | 972 |  |  | 1,857 |  |  | 1,870 |  |
| Product |  | 809 |  |  | 869 |  |  | 1,634 |  |  | 1,682 |  |
| Service |  | 62 |  |  | 63 |  |  | 124 |  |  | 119 |  |
| Fire & Security sales |  | 871 |  |  | 932 |  |  | 1,758 |  |  | 1,801 |  |
| Total segment sales |  | 6,814 |  |  | 6,120 |  |  | 13,126 |  |  | 11,509 |  |
| Eliminations and other |  | (125) |  |  | (128) |  |  | (255) |  |  | (244) |  |
| Net sales |  | $ | 6,689 |  |  | $ | 5,992 |  |  | $ | 12,871 |  |  | $ | 11,265 |  |
  (was, 2024-04-25, similarity 0.8555):
[0001783180-24-000044:note_history:38]
|  |  | Three Months Ended March 31, |  |  |
| (In millions) |  | 2024 |  | 2023 |  |  |  |  |
| Sales Type |  |  |  |  |  |  |  |  |
| Product |  | $ | 4,073 |  |  | $ | 3,201 |  |  |  |  |  |
| Service |  | 468 |  |  | 421 |  |  |  |  |  |
| HVAC sales |  | 4,541 |  |  | 3,622 |  |  |  |  |  |
| Product |  | 772 |  |  | 787 |  |  |  |  |  |
| Service |  | 112 |  |  | 111 |  |  |  |  |  |
| Refrigeration sales |  | 884 |  |  | 898 |  |  |  |  |  |
| Product |  | 825 |  |  | 813 |  |  |  |  |  |
| Service |  | 62 |  |  | 56 |  |  |  |  |  |
| Fire & Security sales |  | 887 |  |  | 869 |  |  |  |  |  |
| Total segment sales |  | 6,312 |  |  | 5,389 |  |  |  |  |  |
| Eliminations and other |  | (130) |  |  | (116) |  |  |  |  |  |
| Net sales |  | $ | 6,182 |  |  | $ | 5,273 |  |  |  |  |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-07-25):
[0001783180-24-000077:note_history:39]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
| (In millions) |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Sales Type |  |  |  |  |  |  |  |  |
| Product |  | $ | 4,468 |  |  | $ | 3,754 |  |  | $ | 8,541 |  |  | $ | 6,955 |  |
| Service |  | 502 |  |  | 462 |  |  | 970 |  |  | 883 |  |
| HVAC sales |  | 4,970 |  |  | 4,216 |  |  | 9,511 |  |  | 7,838 |  |
| Product |  | 851 |  |  | 858 |  |  | 1,623 |  |  | 1,645 |  |
| Service |  | 122 |  |  | 114 |  |  | 234 |  |  | 225 |  |
| Refrigeration sales |  | 973 |  |  | 972 |  |  | 1,857 |  |  | 1,870 |  |
| Product |  | 809 |  |  | 869 |  |  | 1,634 |  |  | 1,682 |  |
| Service |  | 62 |  |  | 63 |  |  | 124 |  |  | 119 |  |
| Fire & Security sales |  | 871 |  |  | 932 |  |  | 1,758 |  |  | 1,801 |  |
| Total segment sales |  | 6,814 |  |  | 6,120 |  |  | 13,126 |  |  | 11,509 |  |
| Eliminations and other |  | (125) |  |  | (128) |  |  | (255) |  |  | (244) |  |
| Net sales |  | $ | 6,689 |  |  | $ | 5,992 |  |  | $ | 12,871 |  |  | $ | 11,265 |  |
  (was, 2024-04-25, similarity 0.8555):
[0001783180-24-000044:note_history:39]
|  |  | Three Months Ended March 31, |  |  |
| (In millions) |  | 2024 |  | 2023 |  |  |  |  |
| Sales Type |  |  |  |  |  |  |  |  |
| Product |  | $ | 4,073 |  |  | $ | 3,201 |  |  |  |  |  |
| Service |  | 468 |  |  | 421 |  |  |  |  |  |
| HVAC sales |  | 4,541 |  |  | 3,622 |  |  |  |  |  |
| Product |  | 772 |  |  | 787 |  |  |  |  |  |
| Service |  | 112 |  |  | 111 |  |  |  |  |  |
| Refrigeration sales |  | 884 |  |  | 898 |  |  |  |  |  |
| Product |  | 825 |  |  | 813 |  |  |  |  |  |
| Service |  | 62 |  |  | 56 |  |  |  |  |  |
| Fire & Security sales |  | 887 |  |  | 869 |  |  |  |  |  |
| Total segment sales |  | 6,312 |  |  | 5,389 |  |  |  |  |  |
| Eliminations and other |  | (130) |  |  | (116) |  |  |  |  |  |
| Net sales |  | $ | 6,182 |  |  | $ | 5,273 |  |  |  |  |  |

- changed (2024-07-25):
[0001783180-24-000077:note_history:40]
| (In millions) |  | June 30,2024 |  | December 31,2023 |
| Contract assets |  | $ | 333 |  |  | $ | 306 |  |
| Contract assets, non-current (included within Other assets) |  | 40 |  |  | 26 |  |
| Total contract assets |  | 373 |  |  | 332 |  |
| Contract liabilities |  | (493) |  |  | (425) |  |
| Contract liabilities, non-current (included within Other long-term liabilities) |  | (161) |  |  | (160) |  |
| Total contract liabilities |  | (654) |  |  | (585) |  |
| Net contract assets (liabilities) |  | $ | (281) |  |  | $ | (253) |  |
  (was, 2024-04-25, similarity 0.9721):
[0001783180-24-000044:note_history:40]
| (In millions) |  | March 31,2024 |  | December 31,2023 |
| Contract assets, current |  | $ | 320 |  |  | $ | 306 |  |
| Contract assets, non-current (included within Other assets) |  | 30 |  |  | 26 |  |
| Total contract assets |  | 350 |  |  | 332 |  |
| Contract liabilities, current |  | (501) |  |  | (425) |  |
| Contract liabilities, non-current (included within Other long-term liabilities) |  | (157) |  |  | (160) |  |
| Total contract liabilities |  | (658) |  |  | (585) |  |
| Net contract assets (liabilities) |  | $ | (308) |  |  | $ | (253) |  |

- changed (2024-07-25):
[0001783180-24-000077:note_history:41]
The timing of revenue recognition, billings and cash collections results in contract assets and contract liabilities. Contract assets relate to the conditional right to consideration for any completed performance under a contract when costs are incurred in excess of billings under the percentage-of-completion methodology. Contract liabilities relate to payments received in advance of performance under a contract or when the Company has a right to consideration that is conditioned upon transfer of a good or service to a customer. Contract liabilities are recognized as revenue as (or when) the Company performs under the contract.
The Company recognized revenue of $348 million during the six months ended June 30, 2024 that related to contract liabilities as of January 1, 2024. The Company expects a majority of its current contract liabilities at the end of the period to be recognized as revenue in the next 12 months.
  (was, 2024-04-25, similarity 0.8199):
[0001783180-24-000044:note_history:41]
The timing of revenue recognition, billings and cash collections results in contract assets and contract liabilities. Contract assets relate to the conditional right to consideration for any completed performance under a contract when costs are incurred in excess of billings under the percentage-of-completion methodology. Contract liabilities relate to payments received in advance of performance under a contract or when the Company has a right to consideration that is conditioned upon transfer of a good or service to a customer. Contract liabilities are recognized as revenue as (or when) the Company performs under the contract.

- removed (2024-07-25):
[0001783180-24-000044:note_history:42]
The Company recognized revenue of $345 million during the three months ended March 31, 2024 that related to contract liabilities as of January 1, 2024. The Company expects a majority of its current contract liabilities at the end of the period to be recognized as revenue in the next 12 months.
