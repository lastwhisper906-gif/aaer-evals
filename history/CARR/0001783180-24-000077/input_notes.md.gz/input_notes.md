# CARR notes — 0001783180-24-000077


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001783180-24-000077:notes:1]
DESCRIPTION OF THE BUSINESS
Carrier Global Corporation (the "Company") is a global leader in intelligent climate and energy solutions with a focus on providing differentiated, digitally-enabled lifecycle solutions to its customers. The Company's portfolio includes industry-leading brands such as Carrier, Viessmann, Toshiba, Automated Logic, Carrier Transicold, Kidde and Edwards that offer innovative heating, ventilating, air conditioning ("HVAC"), refrigeration, fire and building automation technologies to help make the world safer and more comfortable. The Company also provides a broad array of related building services, including audit, design, installation, system integration, repair, maintenance and monitoring. The Company's operations are classified into three segments: HVAC, Refrigeration and Fire & Security.

[0001783180-24-000077:notes:2]
[same as prior period, unchanged from 0001783180-24-000044:notes:2]


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001783180-24-000077:notes:3]
BASIS OF PRESENTATION
The Unaudited Condensed Consolidated Financial Statements include all accounts of the Company and its wholly-owned and majority-owned subsidiaries in which it has control. Inter-company accounts and transactions have been eliminated. Related party transactions between the Company and its equity method investees have not been eliminated. Non-controlling interest represents a non-controlling investor's interests in the results of subsidiaries that the Company controls and consolidates.

[0001783180-24-000077:notes:4]
[same as prior period, unchanged from 0001783180-24-000044:notes:4]

[0001783180-24-000077:notes:5]
On April 25, 2023, the Company announced that it entered into a Share Purchase Agreement (the “Agreement”) to acquire the climate solutions business (the "VCS Business") of Viessmann Group GmbH & Co. KG (“Viessmann”), a privately-held company. The acquisition was completed on January 2, 2024. As a result, the assets, liabilities and results of operations of the VCS Business are consolidated in the accompanying Unaudited Condensed Consolidated Financial Statements as of the date of acquisition and reported within the Company’s HVAC segment. See Note 15 – Acquisitions for additional information.

[0001783180-24-000077:notes:6]
[same as prior period, unchanged from 0001783180-24-000044:notes:6]

[0001783180-24-000077:notes:7]
On December 7, 2023, the Company entered into a stock purchase agreement to sell its Access Solutions business ("Access Solutions") to Honeywell International Inc. As a result, the assets and liabilities of Access Solutions are presented as held for sale on the accompanying Unaudited Condensed Consolidated Balance Sheet as of December 31, 2023, and recorded at the lower of their carrying value or fair value less estimated cost to sell. The sale of Access Solutions was completed on June 2, 2024. See Note 16 - Divestitures for additional information.

[0001783180-24-000077:notes:8]
On December 12, 2023, the Company entered into a stock purchase agreement to sell its Commercial Refrigeration business ("CCR") to Haier Group Corporation for an enterprise value of approximately $775 million. In addition, the net assets of the Company’s Industrial Fire business ("Industrial Fire") met the criteria to be classified as held for sale during the fourth quarter of 2023. As a result, the assets and liabilities of each business are presented as held for sale in the accompanying Unaudited Condensed Consolidated Balance Sheet as of June 30, 2024 and December 31, 2023, and recorded at the lower of their carrying value or fair value less estimated cost to sell. On March 5, 2024, the Company entered into a stock purchase agreement to sell Industrial Fire to Sentinel Capital Partners for an enterprise value of approximately $1.425 billion. The sale of Industrial Fire was completed on July 1, 2024. See Note 16 - Divestitures for additional information.

[0001783180-24-000077:notes:9]
[same as prior period, unchanged from 0001783180-24-000044:notes:9]

[0001783180-24-000077:notes:10]
On May 14, 2023, Kidde-Fenwal, Inc. ("KFI"), an indirect wholly-owned subsidiary of the Company, filed a petition for voluntary reorganization under Chapter 11 of the United States Bankruptcy Code ("Chapter 11") in the United States Bankruptcy Court for the District of Delaware. KFI, an industrial fire detection and suppression business historically reported in the Company's Fire & Security segment, indicated that it intended to use the bankruptcy process to explore strategic alternatives, including the sale of KFI as a going concern. As of the petition date, KFI was deconsolidated and its respective assets and liabilities were derecognized from the Company's Unaudited Condensed Consolidated Financial Statements. See Note 19 - Commitments and Contingent Liabilities for additional information.

[0001783180-24-000077:notes:11]
[same as prior period, unchanged from 0001783180-24-000044:notes:11]

[0001783180-24-000077:notes:12]
On April 3, 2020 (the "Distribution Date"), United Technologies Corporation ("UTC"), since renamed RTX Corporation ("Raytheon Technologies Corporation" or "RTX"), completed the spin-off of Carrier into an independent, publicly traded company (the "Separation") through a pro-rata distribution (the "Distribution") on a one-for-one basis of all of the outstanding shares of common stock of Carrier to UTC shareowners who held shares of UTC common stock as of the close of business on March 19, 2020, the record date of the Distribution. Following the Separation and Distribution, the Company entered into several agreements with UTC and Otis Worldwide Corporation ("Otis") that govern various aspects of the relationship among the Company, UTC and Otis. As of June 30, 2024, only certain portions of the Tax Matters Agreement ("TMA") remain in effect.

[0001783180-24-000077:notes:13]
[same as prior period, unchanged from 0001783180-24-000044:notes:13]

[0001783180-24-000077:notes:14]
[same as prior period, unchanged from 0001783180-24-000044:notes:14]

[0001783180-24-000077:notes:15]
Recently Issued Accounting Pronouncements

[0001783180-24-000077:notes:16]
In November 2023, the FASB issued ASU 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures (“ASU 2023-07”), which requires public entities to disclose information about their reportable segments’ significant expenses on an interim and annual basis. In addition, the amendments clarify circumstances in which an entity can disclose multiple segment measures of profit or loss, provide new segment disclosure requirements for entities with a single reportable segment and contain other disclosure requirements. ASU 2023-07 is effective for fiscal years beginning after December 15, 2023 and interim periods beginning after December 15, 2024, with early adoption permitted. The Company is currently assessing the impact of this ASU on its financial statements.

[0001783180-24-000077:notes:17]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures ("ASU 2023-09"), which requires public entities to disclose disaggregated information about their effective tax rate reconciliation as well as information on income taxes paid. ASU 2023-09 is effective for fiscal years beginning after December 15, 2023 and interim periods within fiscal years beginning after December 15, 2024, with early adoption permitted. The Company is currently assessing the impact of this ASU on its financial statements.

[0001783180-24-000077:notes:18]
On March 6, 2024, the SEC adopted new rules designed to enhance public company disclosures related to the risks and impacts of climate-related matters. The rules amend the provisions of both Regulation S-K and Regulation S-X to require disclosure of climate-related risks, transition plans, targets and goals, risk management and governance as well as require disclosure of the financial effects of severe weather events and other natural conditions as well as the use of carbon offsets or renewable energy credits. Disclosure requirements will begin phasing in for fiscal years beginning on or after January 1, 2025, subject to legal challenges and the SEC's voluntary stay of the disclosure requirements. The Company will continue to assess the impact of these new rules on its financial statements while the stay is in place.


## us-gaap:InventoryDisclosureTextBlock

[0001783180-24-000077:notes:19]
[same as prior period, unchanged from 0001783180-24-000044:notes:19]

[0001783180-24-000077:notes:20]
[same as prior period, unchanged from 0001783180-24-000044:notes:20]

[0001783180-24-000077:notes:21]
| (In millions) |  | June 30,2024 |  | December 31,2023 |
| Raw materials |  | $ | 981 |  |  | $ | 695 |  |
| Work-in-process |  | 285 |  |  | 259 |  |
| Finished goods |  | 1,779 |  |  | 1,263 |  |
| Inventories, net |  | $ | 3,045 |  |  | $ | 2,217 |  |

[0001783180-24-000077:notes:22]
The Company performs periodic assessments utilizing customer demand, production requirements and historical usage rates to determine the existence of excess and obsolete inventory and records necessary provisions to reduce such inventories to the lower of cost or estimated net realizable value. Raw materials, work-in-process and finished goods are net of valuation reserves of $245 million and $223 million as of June 30, 2024 and December 31, 2023, respectively.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001783180-24-000077:notes:23]
[same as prior period, unchanged from 0001783180-24-000044:notes:23]

[0001783180-24-000077:notes:24]
[same as prior period, unchanged from 0001783180-24-000044:notes:24]

[0001783180-24-000077:notes:25]
| (In millions) |  | HVAC |  | Refrigeration |  | Fire & Security |  | Total |
| Balance as of December 31, 2023 |  | $ | 6,407 |  |  | $ | 1,124 |  |  | $ | 458 |  |  | $ | 7,989 |  |
| Acquisitions (1) |  | 7,572 |  |  | — |  |  | — |  |  | 7,572 |  |
| Divestitures (2) |  | — |  |  | — |  |  | 31 |  |  | 31 |  |
| Reclassified to held for sale (2) |  | — |  |  | 3 |  |  | (13) |  |  | (10) |  |
| Foreign currency translation |  | (364) |  |  | (26) |  |  | 53 |  |  | (337) |  |
| Balance as of June 30, 2024 |  | $ | 13,615 |  |  | $ | 1,101 |  |  | $ | 529 |  |  | $ | 15,245 |  |

[0001783180-24-000077:notes:26]
[same as prior period, unchanged from 0001783180-24-000044:notes:26]

[0001783180-24-000077:notes:27]
[same as prior period, unchanged from 0001783180-24-000044:notes:27]

[0001783180-24-000077:notes:28]
[same as prior period, unchanged from 0001783180-24-000044:notes:28]

[0001783180-24-000077:notes:29]
[same as prior period, unchanged from 0001783180-24-000044:notes:29]

[0001783180-24-000077:notes:30]
|  |  | June 30, 2024 |  | December 31, 2023 |
| (In millions) |  | Gross Amount |  | Accumulated Amortization |  | Net Amount |  | Gross Amount |  | Accumulated Amortization |  | Net Amount |
| Amortized: |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 5,868 |  |  | $ | (852) |  |  | $ | 5,016 |  |  | $ | 1,222 |  |  | $ | (610) |  |  | $ | 612 |  |
| Patents and trademarks |  | 973 |  |  | (186) |  |  | 787 |  |  | 332 |  |  | (163) |  |  | 169 |  |
| Service portfolios and other |  | 1,802 |  |  | (621) |  |  | 1,181 |  |  | 686 |  |  | (503) |  |  | 183 |  |
|  |  | 8,643 |  |  | (1,659) |  |  | 6,984 |  |  | 2,240 |  |  | (1,276) |  |  | 964 |  |
| Unamortized: |  |  |  |  |  |  |  |  |  |  |  |  |
| Trademarks and other |  | 64 |  |  | — |  |  | 64 |  |  | 64 |  |  | — |  |  | 64 |  |
| Intangible assets, net |  | $ | 8,707 |  |  | $ | (1,659) |  |  | $ | 7,048 |  |  | $ | 2,304 |  |  | $ | (1,276) |  |  | $ | 1,028 |  |

[0001783180-24-000077:notes:31]
[same as prior period, unchanged from 0001783180-24-000044:notes:31]

[0001783180-24-000077:notes:32]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
| (In millions) |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Amortization expense of Intangible assets |  | $ | 218 |  |  | $ | 61 |  |  | $ | 430 |  |  | $ | 125 |  |


## us-gaap:DebtDisclosureTextBlock

[0001783180-24-000077:notes:33]
BORROWINGS AND LINES OF CREDIT
Long-term debt consisted of the following:

[0001783180-24-000077:notes:34]
| (In millions) |  |  |  | June 30,2024 |  | December 31,2023 |
| 2.242% Notes due 2025 (1) |  |  |  | $ | 1,200 |  |  | $ | 1,200 |  |
| 4.375% Notes due 2025 (2) |  |  |  | 801 |  |  | 830 |  |
| 5.800% Notes due 2025 |  |  |  | — |  |  | 1,000 |  |
| 2.493% Notes due 2027 |  |  |  | 900 |  |  | 900 |  |
| 4.125% Notes due 2028 |  |  |  | 801 |  |  | 830 |  |
| 2.722% Notes due 2030 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.700% Notes due 2031 |  |  |  | 750 |  |  | 750 |  |
| 4.500% Notes due 2032 |  |  |  | 908 |  |  | 941 |  |
| 5.900% Notes due 2034 |  |  |  | 1,000 |  |  | 1,000 |  |
| 3.377% Notes due 2040 |  |  |  | 1,500 |  |  | 1,500 |  |
| 3.577% Notes due 2050 |  |  |  | 2,000 |  |  | 2,000 |  |
| 6.200% Notes due 2054 |  |  |  | 1,000 |  |  | 1,000 |  |
| Total long-term notes |  |  |  | 12,860 |  |  | 13,951 |  |
| Japanese Term Loan Facility |  |  |  | 337 |  |  | 379 |  |
| Other debt (including project financing obligations and finance leases) |  |  |  | 220 |  |  | 74 |  |
| Discounts and debt issuance costs |  |  |  | (95) |  |  | (111) |  |
| Total debt |  |  |  | 13,322 |  |  | 14,293 |  |
| Less: current portion of long-term debt |  |  |  | 2,052 |  |  | 51 |  |
| Long-term debt, net of current portion |  |  |  | $ | 11,270 |  |  | $ | 14,242 |  |

[0001783180-24-000077:notes:35]
(1) 2.242% Notes due February 15, 2025; reclassified to Current portion of long-term debt.

[0001783180-24-000077:notes:36]
(2) 4.375% Notes due May 29, 2025; reclassified to Current portion of long-term debt.

[0001783180-24-000077:notes:37]
Acquisition Funding

[0001783180-24-000077:notes:38]
On January 2, 2024, the Company completed the acquisition of the VCS Business for total consideration of $14.2 billion. Under the terms of the Agreement, 20% of the purchase price was paid in Carrier common stock, issued directly to Viessmann and subject to certain lock up provisions and 80% was paid in cash, subject to working capital and other adjustments. In order to fund the Euro-denominated cash portion of the purchase price, the Company used cash on hand, debt financing and various term loan facilities.

[0001783180-24-000077:notes:39]
Debt Issuance

[0001783180-24-000077:notes:40]
In November 2023, the Company issued $3.0 billion principal amount of USD-denominated notes in three tranches. The tranches consisted of $1.0 billion aggregate principal amount of 5.80% notes due 2025, $1.0 billion aggregate principal amount of 5.90% notes due 2034 and $1.0 billion aggregate principal amount of 6.20% notes due 2054 (collectively, the “USD Notes”). In addition, the Company issued €2.35 billion principal amount of Euro-denominated notes in three tranches. The tranches consisted of €750 million aggregate principal amount of 4.375% notes due 2025, €750 million aggregate principal amount of 4.125% notes due 2028 and €850 million aggregate principal amount of 4.50% notes due 2032 (collectively, the “Euro Notes”). The Company capitalized $51 million of deferred financing costs which are being amortized over the term of their related notes. The notes are subject to certain customary covenants and the Company has the option to redeem the notes in whole or in part at any time prior to their stated maturity date at the redemption price set forth in the indenture agreements. In June 2024, the Company redeemed the $1.0 billion aggregate principal amount of 5.80% notes due in 2025 and incurred a $8 million make-whole premium upon prepayment and wrote off $4 million of related unamortized debt financing costs.

[0001783180-24-000077:notes:41]
Bridge Loan

[0001783180-24-000077:notes:42]
On April 25, 2023, the Company entered into commitment letters with JPMorgan Chase Bank, N.A., BofA Securities, Inc. and Bank of America, N.A. to provide a €8.2 billion aggregate principal, senior unsecured bridge term loan facility (the “Bridge Loan”). Euro-denominated borrowings bore interest at the EURIBOR Rate plus a ratings-based margin, USD-denominated borrowings bore interest at either a Term SOFR Rate plus 0.10% and a ratings-based margin or, alternatively, at a base rate plus a ratings-based margin. The Company capitalized $48 million of deferred financing costs associated with the Bridge Loan which were amortized over the commitment period. Upon entering into a senior unsecured delayed draw term loan facility and issuing the USD Notes and the Euro Notes, the Company reduced the Bridge Loan by €7.7 billion and accelerated the amortization on $25 million of deferred financing costs in Interest expense during 2023. On January 2, 2024, the Company entered into a 60-day senior unsecured term loan agreement consisting of a Euro-denominated tranche in an aggregate amount of €113 million and a USD-denominated tranche in an aggregate amount of $349 million (the “60-day Loan”). Upon entering into the 60-day Loan, the Company reduced the final portion of the Bridge Loan by €500 million and subsequently terminated the agreement. Borrowings under the 60-day Loan were repaid in March 2024.

[0001783180-24-000077:notes:43]
Delayed Draw Facility

[0001783180-24-000077:notes:44]
On May 19, 2023, the Company entered into a senior unsecured delayed draw term loan credit agreement with JPMorgan Chase Bank, N.A., as administrative agent and certain other lenders that permits aggregate borrowings of up to €2.3 billion (the "Delayed Draw Facility"). The facility consists of an 18-month, Euro-denominated tranche in an aggregate amount of €1.15 billion and a 3-year, Euro-denominated tranche in an aggregate amount of €1.15 billion. Euro-denominated borrowings bear interest at the EURIBOR Rate plus a ratings-based margin, USD-denominated borrowings bear interest at either a Term SOFR Rate plus 0.10% and a ratings-based margin or, alternatively, at a base rate plus a ratings-based margin. The Company capitalized $4 million of deferred financing costs which will be amortized over the respective term of the tranches. On January 2, 2024, the Company borrowed the full amount available under the Delayed Draw Facility in U.S. Dollars. Borrowings under the Delayed Draw Facility were repaid in June 2024 and the facility was subsequently terminated.

[0001783180-24-000077:notes:45]
364-Day Revolver

[0001783180-24-000077:notes:46]
On May 17, 2024, the Company entered into a 364-day, $500 million, senior unsecured revolving credit agreement with JPMorgan Chase Bank, N.A., as administrative agent and certain other lenders (the “364-day Revolver”). Borrowings are available in U.S. Dollars and Euros. USD-denominated borrowings bear interest at either a Term SOFR Rate plus 0.10% and a ratings-based margin or, alternatively, at a base rate plus a ratings-based margin, Euro-denominated borrowings bear interest at the Adjusted EURIBOR Rate plus a ratings-based margin. Upon entering into the 364-day Revolver, the Company terminated its existing $500 million senior unsecured revolving credit agreement that was set to mature in May 2024. As of June 30, 2024, there were no borrowings outstanding under the 364-day Revolver.

[0001783180-24-000077:notes:47]
Japanese Term Loan Facility

[0001783180-24-000077:notes:48]
On July 15, 2022, the Company entered into a five-year, JPY 54 billion (approximately $400 million) senior unsecured term loan facility with MUFG Bank Ltd., as administrative agent and lender, and certain other lenders (the "Japanese Term Loan Facility"). Borrowings under the Japanese Term Loan Facility bear interest at a rate equal to the Tokyo Term Risk Free Rate plus 0.75%. The Company capitalized $2 million of deferred financing costs which are being amortized over its term. On July 25, 2022, the Company borrowed JPY 54 billion under the Japanese Term Loan Facility and used the proceeds to fund a portion of the Yen-denominated purchase price of Toshiba Carrier Corporation ("TCC") and to pay related fees and expenses.

[0001783180-24-000077:notes:49]
Revolving Credit Facility

[0001783180-24-000077:notes:50]
On May 19, 2023, the Company entered into a revolving credit agreement with JPMorgan Chase Bank, N.A., as administrative agent, and certain other lenders, permitting aggregate borrowings of up to $2.0 billion pursuant to an unsecured, unsubordinated revolving credit facility that matures in May 2028 (the "Revolving Credit Facility"). The Revolving Credit Facility supports the Company's commercial paper program and can be used for other general corporate purposes. Borrowings are available in U.S. Dollars and Euros. U.S. Dollar borrowings bear interest at either a Term SOFR Rate plus 0.10% and a ratings-based margin or, alternatively, at an alternate base rate plus a ratings-based margin. Euro borrowings bear interest at an adjusted EURIBOR rate plus a ratings-based margin. A ratings-based commitment fee is charged on unused commitments. In addition, the Company capitalized $2 million of deferred financing costs which are being amortized over its term. As of June 30, 2024, there were no borrowings outstanding under the Revolving Credit Facility.

[0001783180-24-000077:notes:51]
Commercial Paper Program

[0001783180-24-000077:notes:52]
The Company has a $2.0 billion unsecured, unsubordinated commercial paper program, which can be used for general corporate purposes, including the funding of working capital and potential acquisitions. As of June 30, 2024, there were no borrowings outstanding under the commercial paper program.

[0001783180-24-000077:notes:53]
Project Financing Arrangements

[0001783180-24-000077:notes:54]
The Company is involved in long-term construction contracts in which it arranges project financing with certain customers. As a result, the Company issued $20 million and $6 million of debt during the six months ended June 30, 2024 and 2023, respectively. Long-term debt repayments associated with these financing arrangements during the six months ended June 30, 2024 and 2023 were $6 million and $12 million, respectively.

[0001783180-24-000077:notes:55]
Debt Covenants

[0001783180-24-000077:notes:56]
The Revolving Credit Facility, 364-day Revolver, the indenture for the long-term notes and the Japanese Term Loan Facility contain affirmative and negative covenants customary for financings of these types, which, among other things, limit the Company's ability to incur certain liens, to make certain fundamental changes and to enter into sale and leaseback transactions. As of June 30, 2024, the Company was in compliance with the covenants under the agreements governing its outstanding indebtedness.


## us-gaap:FairValueDisclosuresTextBlock

[0001783180-24-000077:notes:57]
[same as prior period, unchanged from 0001783180-24-000044:notes:58]

[0001783180-24-000077:notes:58]
[same as prior period, unchanged from 0001783180-24-000044:notes:59]

[0001783180-24-000077:notes:59]
[same as prior period, unchanged from 0001783180-24-000044:notes:60]

[0001783180-24-000077:notes:60]
[same as prior period, unchanged from 0001783180-24-000044:notes:61]

[0001783180-24-000077:notes:61]
[same as prior period, unchanged from 0001783180-24-000044:notes:62]

[0001783180-24-000077:notes:62]
[same as prior period, unchanged from 0001783180-24-000044:notes:63]

[0001783180-24-000077:notes:63]
[same as prior period, unchanged from 0001783180-24-000044:notes:64]

[0001783180-24-000077:notes:64]
[same as prior period, unchanged from 0001783180-24-000044:notes:65]

[0001783180-24-000077:notes:65]
During 2023, the Company entered into window forward contracts with Bank of America N.A. and JPMorgan Chase Bank N.A. to mitigate the foreign currency risk of the expected cash outflows associated with the Euro-denominated purchase price of the VCS Business. The instruments had an aggregate notional amount of €7 billion and were measured at fair value on a recurring basis using observable market inputs, such as forward, discount and interest rates with changes in fair value reported in Other income (expense), net in the accompanying Unaudited Condensed Consolidated Statement of Operations. During 2023, the Company recognized a $96 million loss on the mark-to-market valuation of its window forward contracts. The Company settled the window forward contracts on January 2, 2024, upon the acquisition of the VCS Business and recognized an additional $86 million loss.

[0001783180-24-000077:notes:66]
[same as prior period, unchanged from 0001783180-24-000044:notes:67]

[0001783180-24-000077:notes:67]
[same as prior period, unchanged from 0001783180-24-000044:notes:68]

[0001783180-24-000077:notes:68]
| (In millions) |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |
| June 30, 2024 |  |  |  |  |  |  |  |  |
| Derivative assets (1)(3) |  | $ | 62 |  |  | $ | — |  |  | $ | 62 |  |  | $ | — |  |
| Derivative liabilities (2)(3) |  | $ | (12) |  |  | $ | — |  |  | $ | (12) |  |  | $ | — |  |
| December 31, 2023 |  |  |  |  |  |  |  |  |
| Derivative assets (1) (3) |  | $ | 32 |  |  | $ | — |  |  | $ | 32 |  |  | $ | — |  |
| Derivative liabilities (2) (3) |  | $ | (126) |  |  | $ | — |  |  | $ | (126) |  |  | $ | — |  |

[0001783180-24-000077:notes:69]
(1) Included in Other current assets and Other assets on the accompanying Unaudited Condensed Consolidated Balance Sheet.

[0001783180-24-000077:notes:70]
[same as prior period, unchanged from 0001783180-24-000044:notes:71]

[0001783180-24-000077:notes:71]
[same as prior period, unchanged from 0001783180-24-000044:notes:72]

[0001783180-24-000077:notes:72]
[same as prior period, unchanged from 0001783180-24-000044:notes:73]

[0001783180-24-000077:notes:73]
|  |  | June 30, 2024 |  | December 31, 2023 |  |
| (In millions) |  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  |
| Total long-term notes (1) |  | $ | 12,860 |  |  | $ | 11,725 |  |  | $ | 13,951 |  |  | $ | 13,194 |  |  |

[0001783180-24-000077:notes:74]
[same as prior period, unchanged from 0001783180-24-000044:notes:75]

[0001783180-24-000077:notes:75]
[same as prior period, unchanged from 0001783180-24-000044:notes:76]


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0001783180-24-000077:notes:76]
[same as prior period, unchanged from 0001783180-24-000044:notes:77]


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001783180-24-000077:notes:77]
[same as prior period, unchanged from 0001783180-24-000044:notes:78]

[0001783180-24-000077:notes:78]
[same as prior period, unchanged from 0001783180-24-000044:notes:79]

[0001783180-24-000077:notes:79]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
| (In millions) |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Defined benefit plans |  | $ | 12 |  |  | $ | 5 |  |  | $ | 18 |  |  | $ | 11 |  |
| Defined contribution plans |  | $ | 35 |  |  | $ | 29 |  |  | $ | 74 |  |  | $ | 66 |  |
| Multi-employer pension plans |  | $ | 4 |  |  | $ | 4 |  |  | $ | 8 |  |  | $ | 8 |  |

[0001783180-24-000077:notes:80]
[same as prior period, unchanged from 0001783180-24-000044:notes:81]

[0001783180-24-000077:notes:81]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
| (In millions) |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Service cost |  | $ | 3 |  |  | $ | 4 |  |  | $ | 7 |  |  | $ | 8 |  |
| Interest cost |  | 7 |  |  | 8 |  |  | 14 |  |  | 16 |  |
| Expected return on plan assets |  | (7) |  |  | (8) |  |  | (14) |  |  | (16) |  |
| Amortization of prior service credit |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Recognized actuarial net (gain) loss |  | — |  |  | (1) |  |  | — |  |  | (1) |  |
| Net settlement, curtailment and special termination benefit (gain) loss |  | 1 |  |  | — |  |  | 1 |  |  | — |  |
| Net periodic pension expense (benefit) |  | $ | 4 |  |  | $ | 4 |  |  | $ | 8 |  |  | $ | 8 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001783180-24-000077:notes:82]
[same as prior period, unchanged from 0001783180-24-000044:notes:83]

[0001783180-24-000077:notes:83]
[same as prior period, unchanged from 0001783180-24-000044:notes:84]

[0001783180-24-000077:notes:84]
[same as prior period, unchanged from 0001783180-24-000044:notes:85]

[0001783180-24-000077:notes:85]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
| (In millions) |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Equity compensation costs - equity settled |  | $ | 26 |  |  | $ | 18 |  |  | $ | 48 |  |  | $ | 40 |  |
| Equity compensation costs - cash settled (1) |  | 1 |  |  | 1 |  |  | 1 |  |  | 2 |  |
| Total stock-based compensation expense |  | $ | 27 |  |  | $ | 19 |  |  | $ | 49 |  |  | $ | 42 |  |

[0001783180-24-000077:notes:86]
[same as prior period, unchanged from 0001783180-24-000044:notes:87]


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001783180-24-000077:notes:87]
[same as prior period, unchanged from 0001783180-24-000044:notes:88]

[0001783180-24-000077:notes:88]
[same as prior period, unchanged from 0001783180-24-000044:notes:89]

[0001783180-24-000077:notes:89]
|  |  | Six Months Ended June 30, |
| (In millions) |  | 2024 |  | 2023 |
| Balance as of January 1, |  | $ | 570 |  |  | $ | 552 |  |
| Warranties, performance guarantees issued and changes in estimated liability |  | 165 |  |  | 117 |  |
| Settlements made |  | (143) |  |  | (92) |  |
| Other |  | (8) |  |  | (2) |  |
| Acquisitions (1) |  | 202 |  |  | — |  |
| Balance as of June 30, |  | $ | 786 |  |  | $ | 575 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001783180-24-000077:notes:90]
EQUITY
The authorized number of shares of common stock of Carrier is 4,000,000,000 shares of $0.01 par value. As of June 30, 2024 and December 31, 2023, 946,155,120 and 883,068,393 shares of common stock were issued, respectively, which includes 43,490,981 shares of treasury stock, for both periods respectively.

[0001783180-24-000077:notes:91]
[same as prior period, unchanged from 0001783180-24-000044:notes:92]

[0001783180-24-000077:notes:92]
[same as prior period, unchanged from 0001783180-24-000044:notes:93]

[0001783180-24-000077:notes:93]
As of December 31, 2023, the Company repurchased 43.5 million shares of common stock for an aggregate purchase price of $2.0 billion, including shares repurchased under an accelerated share repurchase agreement. As a result, the Company had approximately $2.1 billion remaining under the current authorization at December 31, 2023. Upon announcement of the proposed acquisition of the VCS Business, the Company temporarily paused its share repurchase program in order to advance its capital allocation strategy. As a result, there was no share repurchase activity during the six months ended June 30, 2024.

[0001783180-24-000077:notes:94]
[same as prior period, unchanged from 0001783180-24-000044:notes:95]

[0001783180-24-000077:notes:95]
A summary of changes in the components of Accumulated other comprehensive income (loss) for the three and six months ended June 30, 2024 is as follows:

[0001783180-24-000077:notes:96]
| (In millions) |  | Foreign Currency Translation |  | Defined Benefit Pension and Post-retirement Plans |  |  |  | Unrealized Hedging Gains (Losses) |  | Accumulated Other Comprehensive Income (Loss) |
| Balance as of December 31, 2023 |  | $ | (1,444) |  |  | $ | (100) |  |  |  |  | $ | 58 |  |  | $ | (1,486) |  |
| Other comprehensive income (loss) before reclassifications, net |  | (385) |  |  | — |  |  |  |  | — |  |  | (385) |  |
| Amounts reclassified, pre-tax |  | — |  |  | — |  |  |  |  | (1) |  |  | (1) |  |
| Balance as of March 31, 2024 |  | $ | (1,829) |  |  | $ | (100) |  |  |  |  | $ | 57 |  |  | $ | (1,872) |  |
| Other comprehensive income (loss) before reclassifications, net |  | (187) |  |  | — |  |  |  |  | — |  |  | (187) |  |
| Amounts reclassified, pre-tax |  | — |  |  | 1 |  |  |  |  | (1) |  |  | — |  |
| Divestitures, net |  | 373 |  |  | — |  |  |  |  | — |  |  | 373 |  |
| Balance as of June 30, 2024 |  | $ | (1,643) |  |  | $ | (99) |  |  |  |  | $ | 56 |  |  | $ | (1,686) |  |

[0001783180-24-000077:notes:97]
A summary of changes in the components of Accumulated other comprehensive income (loss) for the three and six months ended June 30, 2023 is as follows:

[0001783180-24-000077:notes:98]
| (In millions) |  | Foreign Currency Translation |  | Defined Benefit Pension and Post-retirement Plans |  |  |  | Unrealized Hedging Gains (Losses) |  | Accumulated Other Comprehensive Income (Loss) |
| Balance as of December 31, 2022 |  | $ | (1,604) |  |  | $ | (84) |  |  |  |  | $ | — |  |  | $ | (1,688) |  |
| Other comprehensive income (loss) before reclassifications, net |  | 52 |  |  | — |  |  |  |  | — |  |  | 52 |  |
| Balance as of March 31, 2023 |  | $ | (1,552) |  |  | $ | (84) |  |  |  |  | $ | — |  |  | $ | (1,636) |  |
| Other comprehensive income (loss) before reclassifications, net |  | (55) |  |  | — |  |  |  |  | — |  |  | (55) |  |
| Balance as of June 30, 2023 |  | $ | (1,607) |  |  | $ | (84) |  |  |  |  | $ | — |  |  | $ | (1,691) |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001783180-24-000077:notes:99]
[same as prior period, unchanged from 0001783180-24-000044:notes:100]

[0001783180-24-000077:notes:100]
[same as prior period, unchanged from 0001783180-24-000044:notes:101]

[0001783180-24-000077:notes:101]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
| (In millions) |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Sales Type |  |  |  |  |  |  |  |  |
| Product |  | $ | 4,468 |  |  | $ | 3,754 |  |  | $ | 8,541 |  |  | $ | 6,955 |  |
| Service |  | 502 |  |  | 462 |  |  | 970 |  |  | 883 |  |
| HVAC sales |  | 4,970 |  |  | 4,216 |  |  | 9,511 |  |  | 7,838 |  |
| Product |  | 851 |  |  | 858 |  |  | 1,623 |  |  | 1,645 |  |
| Service |  | 122 |  |  | 114 |  |  | 234 |  |  | 225 |  |
| Refrigeration sales |  | 973 |  |  | 972 |  |  | 1,857 |  |  | 1,870 |  |
| Product |  | 809 |  |  | 869 |  |  | 1,634 |  |  | 1,682 |  |
| Service |  | 62 |  |  | 63 |  |  | 124 |  |  | 119 |  |
| Fire & Security sales |  | 871 |  |  | 932 |  |  | 1,758 |  |  | 1,801 |  |
| Total segment sales |  | 6,814 |  |  | 6,120 |  |  | 13,126 |  |  | 11,509 |  |
| Eliminations and other |  | (125) |  |  | (128) |  |  | (255) |  |  | (244) |  |
| Net sales |  | $ | 6,689 |  |  | $ | 5,992 |  |  | $ | 12,871 |  |  | $ | 11,265 |  |

[0001783180-24-000077:notes:102]
[same as prior period, unchanged from 0001783180-24-000044:notes:103]

[0001783180-24-000077:notes:103]
[same as prior period, unchanged from 0001783180-24-000044:notes:104]

[0001783180-24-000077:notes:104]
| (In millions) |  | June 30,2024 |  | December 31,2023 |
| Contract assets |  | $ | 333 |  |  | $ | 306 |  |
| Contract assets, non-current (included within Other assets) |  | 40 |  |  | 26 |  |
| Total contract assets |  | 373 |  |  | 332 |  |
| Contract liabilities |  | (493) |  |  | (425) |  |
| Contract liabilities, non-current (included within Other long-term liabilities) |  | (161) |  |  | (160) |  |
| Total contract liabilities |  | (654) |  |  | (585) |  |
| Net contract assets (liabilities) |  | $ | (281) |  |  | $ | (253) |  |

[0001783180-24-000077:notes:105]
The timing of revenue recognition, billings and cash collections results in contract assets and contract liabilities. Contract assets relate to the conditional right to consideration for any completed performance under a contract when costs are incurred in excess of billings under the percentage-of-completion methodology. Contract liabilities relate to payments received in advance of performance under a contract or when the Company has a right to consideration that is conditioned upon transfer of a good or service to a customer. Contract liabilities are recognized as revenue as (or when) the Company performs under the contract.
The Company recognized revenue of $348 million during the six months ended June 30, 2024 that related to contract liabilities as of January 1, 2024. The Company expects a majority of its current contract liabilities at the end of the period to be recognized as revenue in the next 12 months.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0001783180-24-000077:notes:106]
[same as prior period, unchanged from 0001783180-24-000044:notes:108]

[0001783180-24-000077:notes:107]
The timing of revenue recognition, billings and cash collections results in contract assets and contract liabilities. Contract assets relate to the conditional right to consideration for any completed performance under a contract when costs are incurred in excess of billings under the percentage-of-completion methodology. Contract liabilities relate to payments received in advance of performance under a contract or when the Company has a right to consideration that is conditioned upon transfer of a good or service to a customer. Contract liabilities are recognized as revenue as (or when) the Company performs under the contract.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001783180-24-000077:notes:108]
[same as prior period, unchanged from 0001783180-24-000044:notes:109]

[0001783180-24-000077:notes:109]
[same as prior period, unchanged from 0001783180-24-000044:notes:110]

[0001783180-24-000077:notes:110]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
| (In millions) | 2024 |  | 2023 |  | 2024 |  | 2023 |
| HVAC | $ | 25 |  |  | $ | 3 |  |  | $ | 32 |  |  | $ | 2 |  |
| Refrigeration | 1 |  |  | 7 |  |  | 1 |  |  | 10 |  |
| Fire & Security | 3 |  |  | (1) |  |  | 10 |  |  | 12 |  |
| Total Segment | 29 |  |  | 9 |  |  | 43 |  |  | 24 |  |
| General corporate expenses | 3 |  |  | — |  |  | 4 |  |  | 2 |  |
| Total restructuring costs (1) | $ | 32 |  |  | $ | 9 |  |  | $ | 47 |  |  | $ | 26 |  |
| Cost of sales | $ | 13 |  |  | $ | 3 |  |  | $ | 25 |  |  | $ | 9 |  |
| Selling, general and administrative | 19 |  |  | 6 |  |  | 22 |  |  | 17 |  |
| Total restructuring costs (1) | $ | 32 |  |  | $ | 9 |  |  | $ | 47 |  |  | $ | 26 |  |

[0001783180-24-000077:notes:111]
[same as prior period, unchanged from 0001783180-24-000044:notes:112]

[0001783180-24-000077:notes:112]
[same as prior period, unchanged from 0001783180-24-000044:notes:113]

[0001783180-24-000077:notes:113]
|  |  | Six Months Ended June 30, |
| (In millions) |  | 2024 |  | 2023 |
| Balance as of January 1, |  | $ | 55 |  |  | $ | 24 |  |
| Net pre-tax restructuring costs |  | 41 |  |  | 26 |  |
| Acquisitions (1) |  | 8 |  |  | — |  |
| Utilization, foreign exchange and other |  | (47) |  |  | (19) |  |
| Balance as of June 30, |  | $ | 57 |  |  | $ | 31 |  |

[0001783180-24-000077:notes:114]
As of June 30, 2024, the Company had $57 million accrued for costs associated with its announced restructuring initiatives. The balance relates to cost reduction efforts, primarily severance related across each of the Company's segments, along with  reserves associated with the Company's planned portfolio transformation. The Company expects a majority of the balance to be utilized within one year.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001783180-24-000077:notes:115]
INCOME TAXES
The Company accounts for income tax expense in accordance with ASC 740, Income Taxes ("ASC 740"), which requires an estimate of the annual effective income tax rate for the full year to be applied to the respective interim period, taking into account year-to-date amounts and projected results for the full year. The effective tax rate was 32.8% for the three months ended June 30, 2024 compared with 44.8% for the three months ended June 30, 2023. The year-over-year decrease was primarily driven by the absence of the non-deductible loss of $293 million on the deconsolidation of KFI due to its Chapter 11 filing and the $111 million loss on the mark-to-market valuation of our window forward contracts associated with the expected cash outflows of the Euro-denominated purchase price of the VCS Business recognized during the three months ended June 30, 2023. These amounts were partially offset by the $1.1 billion tax on the $2.9 billion gain on the sale of Access Solutions and a held-for-sale tax benefit of $43 million related to adjustments to basis differences in certain companies recognized during the three months ended June 30, 2024.

[0001783180-24-000077:notes:116]
The effective tax rate was 31.1% for the six months ended June 30, 2024, compared with 33.4% for the six months ended June 30, 2023. The year-over-year decrease was primarily driven by the absence of the non-deductible loss of $293 million on the deconsolidation of KFI due to its Chapter 11 filing recognized during the six months ended June 30, 2023. This amount was partially offset by the $1.1 billion tax on the $2.9 billion gain on the sale of Access Solutions and a held-for-sale tax benefit of $62 million related to adjustments to basis differences in certain companies recognized during the six months ended June 30, 2024. In addition, the Company recognized a tax benefit of $21 million associated with the TMA and UTC's conclusion of certain income tax matters from their 2017 and 2018 tax audit with the U.S. Internal Revenue Service ("IRS"), a net tax benefit of $16 million related to the re-organization and disentanglement of certain Fire & Security industrial businesses in advance of the planned divestitures, and a tax charge of $15 million related to a reduction of utilizable foreign tax credits during the six months ended June 30, 2024.

[0001783180-24-000077:notes:117]
[same as prior period, unchanged from 0001783180-24-000044:notes:117]

[0001783180-24-000077:notes:118]
[same as prior period, unchanged from 0001783180-24-000044:notes:118]

[0001783180-24-000077:notes:119]
In the ordinary course of business, there is inherent uncertainty in quantifying the Company's income tax positions. The Company assesses its income tax positions and records tax benefits for all years subject to examination based upon management’s evaluation of the facts, circumstances and information available at the reporting date. The Company believes that it is reasonably possible that a net decrease in unrecognized tax benefits of $20 million to $40 million may occur within 12 months as a result of additional uncertain tax positions, the Separation, the revaluation of uncertain tax positions arising from examinations, appeals, court decisions and/or the expiration of tax statutes.


## us-gaap:EarningsPerShareTextBlock

[0001783180-24-000077:notes:120]
[same as prior period, unchanged from 0001783180-24-000044:notes:120]

[0001783180-24-000077:notes:121]
[same as prior period, unchanged from 0001783180-24-000044:notes:121]

[0001783180-24-000077:notes:122]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
| (In millions, except per share amounts) |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Net income attributable to common shareowners |  | $ | 2,337 |  |  | $ | 199 |  |  | $ | 2,606 |  |  | $ | 572 |  |
| Basic weighted-average number of shares outstanding |  | 902.4 |  |  | 836.0 |  |  | 900.2 |  |  | 835.5 |  |
| Stock awards and equity units (share equivalent) |  | 12.9 |  |  | 14.9 |  |  | 13.4 |  |  | 16.0 |  |
| Diluted weighted-average number of shares outstanding |  | 915.3 |  |  | 850.9 |  |  | 913.6 |  |  | 851.5 |  |
| Antidilutive shares excluded from computation of diluted earnings per share |  | 4.1 |  |  | 5.9 |  |  | 4.1 |  |  | 5.6 |  |
| Earnings Per Share |  |  |  |  |  |  |  |  |
| Basic |  | $ | 2.59 |  |  | $ | 0.24 |  |  | $ | 2.90 |  |  | $ | 0.68 |  |
| Diluted |  | $ | 2.55 |  |  | $ | 0.23 |  |  | $ | 2.85 |  |  | $ | 0.67 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001783180-24-000077:notes:123]
[same as prior period, unchanged from 0001783180-24-000044:notes:123]

[0001783180-24-000077:notes:124]
[same as prior period, unchanged from 0001783180-24-000044:notes:124]

[0001783180-24-000077:notes:125]
[same as prior period, unchanged from 0001783180-24-000044:notes:125]

[0001783180-24-000077:notes:126]
[same as prior period, unchanged from 0001783180-24-000044:notes:126]

[0001783180-24-000077:notes:127]
The components of the purchase price are as follows:

[0001783180-24-000077:notes:128]
[same as prior period, unchanged from 0001783180-24-000044:notes:128]

[0001783180-24-000077:notes:129]
[same as prior period, unchanged from 0001783180-24-000044:notes:129]

[0001783180-24-000077:notes:130]
| (In millions) |  | Preliminary January 2, 2024 |  | Measurement Period Adjustments |  | As Adjusted January 2, 2024 |
| Cash and cash equivalents |  | $ | 394 |  |  | (1) |  |  | $ | 393 |  |
| Accounts receivable |  | 408 |  |  | 5 |  |  | 413 |  |
| Inventories |  | 948 |  |  | — |  |  | 948 |  |
| Other current assets |  | 17 |  |  | — |  |  | 17 |  |
| Fixed assets |  | 913 |  |  | 11 |  |  | 924 |  |
| Intangible assets |  | 6,640 |  |  | — |  |  | 6,640 |  |
| Other assets |  | 284 |  |  | 2 |  |  | 286 |  |
| Accounts payable |  | (288) |  |  | (2) |  |  | (290) |  |
| Other liabilities, current |  | (626) |  |  | (4) |  |  | (630) |  |
| Future income tax obligations |  | (1,825) |  |  | 5 |  |  | (1,820) |  |
| Other liabilities |  | (284) |  |  | (12) |  |  | (296) |  |
| Total identifiable net assets |  | 6,581 |  |  | 4 |  |  | 6,585 |  |
| Goodwill |  | 7,576 |  |  | (4) |  |  | 7,572 |  |
| Total consideration |  | $ | 14,157 |  |  | $ | — |  |  | $ | 14,157 |  |

[0001783180-24-000077:notes:131]
[same as prior period, unchanged from 0001783180-24-000044:notes:131]

[0001783180-24-000077:notes:132]
[same as prior period, unchanged from 0001783180-24-000044:notes:132]

[0001783180-24-000077:notes:133]
[same as prior period, unchanged from 0001783180-24-000044:notes:133]

[0001783180-24-000077:notes:134]
The valuation of intangible assets was determined using an income approach methodology including the multi-period excess earnings method and the relief from royalty method. Key assumptions used in estimating future cash flows included projected revenue growth rates, EBITDA margins, discount rates, customer attrition rates and royalty rates among others. The projected future cash flows are discounted to present value using an appropriate discount rate. As of June 30, 2024, the Company is substantially complete with the process of allocating the purchase price and valuing the acquired assets and liabilities assumed except for certain amounts associated with tax-related assets.

[0001783180-24-000077:notes:135]
During the three and six months ended June 30, 2024, the Company incurred $7 million and $37 million of acquisition-related costs, respectively. During 2023, $80 million of acquisition-related costs were incurred, of which $8 million and $20 million was recognized during the three and six months ended June 30, 2023, respectively. These acquisition costs are reflected within Selling, general and administrative in the Unaudited Condensed Consolidated Statement of Operations.

[0001783180-24-000077:notes:136]
The assets, liabilities and results of operations of the VCS Business are consolidated in the accompanying Unaudited Condensed Consolidated Financial Statements as of the date of acquisition and reported within the Company's HVAC segment.

[0001783180-24-000077:notes:137]
The following table summarizes the results of the VCS Business since the date of acquisition:

[0001783180-24-000077:notes:138]
| (In millions) | Three Months Ended June 30, 2024 |  | Six Months Ended June 30, 2024 |
| Net sales | $ | 743 |  |  | $ | 1,618 |  |
| Net income (loss) | (109) |  |  | (233) |  |

[0001783180-24-000077:notes:139]
The financial results of the VCS Business includes amortization of the step-up to fair value of inventory and backlog as well as intangible amortization totaling $247 million and $497 million for the three and six months ended June 30, 2024, respectively.

[0001783180-24-000077:notes:140]
[same as prior period, unchanged from 0001783180-24-000044:notes:137]

[0001783180-24-000077:notes:141]
[same as prior period, unchanged from 0001783180-24-000044:notes:138]

[0001783180-24-000077:notes:142]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
| (In millions) | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Net sales | $ | 6,689 |  |  | $ | 7,227 |  |  | $ | 12,871 |  |  | $ | 13,505 |  |
| Net income (loss) | 2,421 |  |  | 250 |  |  | 2,764 |  |  | 329 |  |

[0001783180-24-000077:notes:143]
[same as prior period, unchanged from 0001783180-24-000044:notes:140]


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001783180-24-000077:notes:144]
DIVESTITURES
Access Solutions

[0001783180-24-000077:notes:145]
On June 2, 2024, the Company completed the sale of Access Solutions for cash proceeds of $5.0 billion. Access Solutions, historically reported in the Company's Fire & Security segment, is a global supplier of physical security and digital access solutions supporting the hospitality, commercial, education and military markets. The Company recognized a gain on the sale of $2.9 billion, which is included in Other income (expense), net on the accompanying Unaudited Condensed Consolidated Statement of Operations. The net proceeds received are subject to working capital and other adjustments provided in the stock purchase agreement governing the sale of Access Solutions.

[0001783180-24-000077:notes:146]
The following table summarizes the assets and liabilities of Access Solutions divested as of the date of sale:

[0001783180-24-000077:notes:147]
| (In millions) | June 2, 2024 |
| Cash and cash equivalents | $ | 82 |  |
| Accounts receivable, net | 90 |  |
| Inventories, net | 43 |  |
| Contract assets | 3 |  |
| Other current assets | 3 |  |
| Fixed assets, net | 18 |  |
| Intangible assets, net | 53 |  |
| Goodwill | 1,467 |  |
| Operating lease right-of-use assets | 16 |  |
| Other assets | 8 |  |
| Total assets held for sale | $ | 1,783 |  |
| Accounts payable | $ | 54 |  |
| Accrued liabilities | 20 |  |
| Contract liabilities | 60 |  |
| Operating lease liabilities | 17 |  |
| Other long-term liabilities | 10 |  |
| Total liabilities held for sale | $ | 161 |  |

[0001783180-24-000077:notes:148]
Commercial Refrigeration and Industrial Fire

[0001783180-24-000077:notes:149]
On December 12, 2023, the Company entered into a stock purchase agreement to sell the CCR business to Haier Group Corporation for an enterprise value of approximately $775 million. CCR, historically reported in the Company's Refrigeration segment, is a global supplier of turnkey solutions for commercial refrigeration systems and services, with a primary focus on serving food retail customers, cold storage facilities and warehouses. As a result, the assets and liabilities of CCR are presented as held for sale in the accompanying Unaudited Condensed Consolidated Balance Sheet as of June 30, 2024 and December 31, 2023, and recorded at the lower of their carrying value or fair value less estimated cost to sell. The transaction is expected to close in 2024 and is subject to customary closing conditions.

[0001783180-24-000077:notes:150]
The net assets of Industrial Fire met the criteria to be classified as held for sale during the fourth quarter of 2023. Industrial Fire, historically reported in the Company's Fire & Security segment, is a leading manufacturer of a full spectrum of fire detection and suppression solutions and services in critical high-hazard environments, including oil and gas, power generation, marine and offshore facilities, automotive, data centers and aircraft hangars. As a result, the assets and liabilities of Industrial Fire are presented as held for sale in the accompanying Unaudited Condensed Consolidated Balance Sheet as of June 30, 2024 and December 31, 2023, and recorded at the lower of their carrying value or fair value less estimated cost to sell. On March 5, 2024, the Company entered into a stock purchase agreement to sell its Industrial Fire business to Sentinel Capital Partners for an enterprise value of approximately $1.425 billion. The sale of Industrial Fire was completed on July 1, 2024.

[0001783180-24-000077:notes:151]
[same as prior period, unchanged from 0001783180-24-000044:notes:144]

[0001783180-24-000077:notes:152]
|  | June 30, 2024 |
| (In millions) | Commercial Refrigeration |  | IndustrialFire |  | Total |
| Cash and cash equivalents | $ | 151 |  |  | $ | 40 |  |  | $ | 191 |  |
| Accounts receivable, net | 207 |  |  | 93 |  |  | 300 |  |
| Inventories, net | 98 |  |  | 72 |  |  | 170 |  |
| Contract assets | 117 |  |  | 51 |  |  | 168 |  |
| Other current assets | 17 |  |  | 5 |  |  | 22 |  |
| Fixed assets, net | 79 |  |  | 24 |  |  | 103 |  |
| Intangible assets, net | — |  |  | 2 |  |  | 2 |  |
| Goodwill | 69 |  |  | 452 |  |  | 521 |  |
| Operating lease right-of-use assets | 48 |  |  | 26 |  |  | 74 |  |
| Other assets | 48 |  |  | 2 |  |  | 50 |  |
| Total assets held for sale | $ | 834 |  |  | $ | 767 |  |  | $ | 1,601 |  |
| Accounts payable | $ | 122 |  |  | $ | 43 |  |  | $ | 165 |  |
| Accrued liabilities | 149 |  |  | 55 |  |  | 204 |  |
| Contract liabilities | 24 |  |  | 19 |  |  | 43 |  |
| Long-term debt, including current portion | 7 |  |  | — |  |  | 7 |  |
| Future pension and post-retirement obligations | 196 |  |  | — |  |  | 196 |  |
| Future income tax obligations | 7 |  |  | 3 |  |  | 10 |  |
| Operating lease liabilities | 36 |  |  | 20 |  |  | 56 |  |
| Other long-term liabilities | 3 |  |  | 3 |  |  | 6 |  |
| Total liabilities held for sale | $ | 544 |  |  | $ | 143 |  |  | $ | 687 |  |

[0001783180-24-000077:notes:153]
|  | December 31, 2023 |
| (In millions) | Commercial Refrigeration |  | AccessSolutions |  | IndustrialFire |  | Total |
| Cash and cash equivalents | $ | 131 |  |  | $ | 6 |  |  | $ | 20 |  |  | $ | 157 |  |
| Accounts receivable, net | 274 |  |  | 104 |  |  | 101 |  |  | 479 |  |
| Inventories, net | 84 |  |  | 31 |  |  | 65 |  |  | 180 |  |
| Contract assets | 98 |  |  | 2 |  |  | 42 |  |  | 142 |  |
| Other current assets | 15 |  |  | 3 |  |  | 4 |  |  | 22 |  |
| Fixed assets, net | 78 |  |  | 13 |  |  | 22 |  |  | 113 |  |
| Intangible assets, net | — |  |  | 53 |  |  | 2 |  |  | 55 |  |
| Goodwill | 72 |  |  | 1,498 |  |  | 439 |  |  | 2,009 |  |
| Operating lease right-of-use assets | 49 |  |  | 13 |  |  | 28 |  |  | 90 |  |
| Other assets | 44 |  |  | 10 |  |  | 13 |  |  | 67 |  |
| Total assets held for sale | $ | 845 |  |  | $ | 1,733 |  |  | $ | 736 |  |  | $ | 3,314 |  |
| Accounts payable | $ | 129 |  |  | $ | 20 |  |  | $ | 39 |  |  | $ | 188 |  |
| Accrued liabilities | 181 |  |  | 21 |  |  | 55 |  |  | 257 |  |
| Contract liabilities | 23 |  |  | 53 |  |  | 22 |  |  | 98 |  |
| Long-term debt, including current portion | 8 |  |  | — |  |  | — |  |  | 8 |  |
| Future pension and post-retirement obligations | 203 |  |  | — |  |  | 1 |  |  | 204 |  |
| Future income tax obligations | 4 |  |  | 2 |  |  | 3 |  |  | 9 |  |
| Operating lease liabilities | 40 |  |  | 11 |  |  | 23 |  |  | 74 |  |
| Other long-term liabilities | 3 |  |  | 12 |  |  | 9 |  |  | 24 |  |
| Total liabilities held for sale | $ | 591 |  |  | $ | 119 |  |  | $ | 152 |  |  | $ | 862 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001783180-24-000077:notes:154]
[same as prior period, unchanged from 0001783180-24-000044:notes:147]

[0001783180-24-000077:notes:155]
[same as prior period, unchanged from 0001783180-24-000044:notes:148]

[0001783180-24-000077:notes:156]
[same as prior period, unchanged from 0001783180-24-000044:notes:149]

[0001783180-24-000077:notes:157]
[same as prior period, unchanged from 0001783180-24-000044:notes:150]

[0001783180-24-000077:notes:158]
[same as prior period, unchanged from 0001783180-24-000044:notes:151]

[0001783180-24-000077:notes:159]
[same as prior period, unchanged from 0001783180-24-000044:notes:152]

[0001783180-24-000077:notes:160]
|  |  | Net Sales |  | Operating Profit |
|  |  | Three Months Ended June 30, |  | Three Months Ended June 30, |
| (In millions) |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| HVAC |  | $ | 4,970 |  |  | $ | 4,216 |  |  | $ | 687 |  |  | $ | 742 |  |
| Refrigeration |  | 973 |  |  | 972 |  |  | 113 |  |  | 112 |  |
| Fire & Security |  | 871 |  |  | 932 |  |  | 3,001 |  |  | (157) |  |
| Total segment |  | 6,814 |  |  | 6,120 |  |  | 3,801 |  |  | 697 |  |
| Eliminations and other |  | (125) |  |  | (128) |  |  | (23) |  |  | (146) |  |
| General corporate expenses |  | — |  |  | — |  |  | (87) |  |  | (62) |  |
| Total Consolidated |  | $ | 6,689 |  |  | $ | 5,992 |  |  | $ | 3,691 |  |  | $ | 489 |  |

[0001783180-24-000077:notes:161]
|  |  | Net Sales |  | Operating Profit |
|  |  | Six Months Ended June 30, |  | Six Months Ended June 30, |
| (In millions) |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| HVAC |  | $ | 9,511 |  |  | $ | 7,838 |  |  | $ | 1,116 |  |  | $ | 1,177 |  |
| Refrigeration |  | 1,857 |  |  | 1,870 |  |  | 210 |  |  | 220 |  |
| Fire & Security |  | 1,758 |  |  | 1,801 |  |  | 3,154 |  |  | (64) |  |
| Total segment |  | 13,126 |  |  | 11,509 |  |  | 4,480 |  |  | 1,333 |  |
| Eliminations and other |  | (255) |  |  | (244) |  |  | (98) |  |  | (184) |  |
| General corporate expenses |  | — |  |  | — |  |  | (191) |  |  | (105) |  |
| Total Consolidated |  | $ | 12,871 |  |  | $ | 11,265 |  |  | $ | 4,191 |  |  | $ | 1,044 |  |

[0001783180-24-000077:notes:162]
Geographic external sales are attributed to the geographic regions based on their location of origin. With the exception of the U.S. presented in the table below, there were no individually significant countries with sales exceeding 10% of total sales during the three and six months ended June 30, 2024 and 2023.

[0001783180-24-000077:notes:163]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
| (In millions) |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| United States |  | $ | 3,477 |  |  | $ | 3,389 |  |  | $ | 6,444 |  |  | $ | 6,249 |  |
| International: |  |  |  |  |  |  |  |  |
| Europe |  | 1,889 |  |  | 1,205 |  |  | 3,860 |  |  | 2,401 |  |
| Asia Pacific |  | 1,104 |  |  | 1,194 |  |  | 2,144 |  |  | 2,227 |  |
| Other |  | 219 |  |  | 204 |  |  | 423 |  |  | 388 |  |
| Net sales |  | $ | 6,689 |  |  | $ | 5,992 |  |  | $ | 12,871 |  |  | $ | 11,265 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001783180-24-000077:notes:164]
RELATED PARTIES
Equity Method Investments

[0001783180-24-000077:notes:165]
The Company sells products to and purchases products from unconsolidated entities accounted for under the equity method and, therefore, these entities are considered to be related parties. Amounts attributable to equity method investees are as follows:

[0001783180-24-000077:notes:166]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
| (In millions) |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Sales to equity method investees included in Product sales |  | $ | 832 |  |  | $ | 887 |  |  | $ | 1,555 |  |  | $ | 1,641 |  |
| Purchases from equity method investees included in Cost of products sold |  | $ | 59 |  |  | $ | 59 |  |  | $ | 114 |  |  | $ | 102 |  |

[0001783180-24-000077:notes:167]
The Company had receivables from and payables to equity method investees as follows:

[0001783180-24-000077:notes:168]
| (In millions) |  | June 30,2024 |  | December 31,2023 |
| Receivables from equity method investees included in Accounts receivable, net |  | $ | 276 |  |  | $ | 231 |  |
| Payables to equity method investees included in Accounts payable |  | $ | 51 |  |  | $ | 44 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001783180-24-000077:notes:169]
COMMITMENTS AND CONTINGENT LIABILITIES
The Company is involved in various litigation, claims and administrative proceedings, including those related to environmental (including asbestos) and legal matters. In accordance with ASC 450, Contingencies, the Company records accruals for loss contingencies when it is probable that a liability has been incurred and the amount of the loss can be reasonably estimated. These accruals are generally based upon a range of possible outcomes. If no amount within the range is a better estimate than any other, the Company accrues the minimum amount. In addition, these estimates are reviewed periodically and adjusted to reflect additional information when it becomes available. The Company is unable to predict the final outcome of the following matters based on the information currently available, except as otherwise noted. However, the Company does not believe that the resolution of any of these matters will have a material adverse effect upon its results of operations or financial condition.

[0001783180-24-000077:notes:170]
Environmental Matters

[0001783180-24-000077:notes:171]
The Company’s operations are subject to environmental regulation by various authorities. The Company has accrued for the costs of environmental remediation activities, including but not limited to investigatory, remediation, operating and maintenance costs and performance guarantees. The most likely cost to be incurred is accrued based on an evaluation of currently available facts with respect to individual sites, including the technology required to remediate, current laws and regulations and prior remediation experience.

[0001783180-24-000077:notes:172]
The outstanding liabilities for environmental obligations are as follows:

[0001783180-24-000077:notes:173]
| (In millions) |  | June 30,2024 |  | December 31,2023 |
| Environmental reserves included in Accrued liabilities |  | $ | 16 |  |  | $ | 21 |  |
| Environmental reserves included in Other long-term liabilities |  | 200 |  |  | 203 |  |
| Total Environmental reserves |  | $ | 216 |  |  | $ | 224 |  |

[0001783180-24-000077:notes:174]
For sites with multiple responsible parties, the Company considers its likely proportionate share of the anticipated remediation costs and the ability of other parties to fulfill their obligations in establishing a provision for these costs. Accrued environmental liabilities are not reduced by potential insurance reimbursements and are undiscounted.

[0001783180-24-000077:notes:175]
Asbestos Matters

[0001783180-24-000077:notes:176]
The Company has been named as a defendant in lawsuits alleging personal injury as a result of exposure to asbestos allegedly integrated into certain Carrier products or business premises. While the Company has never manufactured asbestos and no longer incorporates it into any currently-manufactured products, certain products that the Company no longer manufactures contained components incorporating asbestos. A substantial majority of these asbestos-related claims have been dismissed without payment or have been covered in full or in part by insurance or other forms of indemnity. Additional cases were litigated and settled without any insurance reimbursement. The amounts involved in asbestos-related claims were not material individually or in the aggregate in any period.

[0001783180-24-000077:notes:177]
The Company's asbestos liabilities and related insurance recoveries are as follows:

[0001783180-24-000077:notes:178]
| (In millions) |  | June 30,2024 |  | December 31,2023 |
| Asbestos liabilities included in Accrued liabilities |  | $ | 16 |  |  | $ | 15 |  |
| Asbestos liabilities included in Other long-term liabilities |  | 201 |  |  | 206 |  |
| Total Asbestos liabilities |  | $ | 217 |  |  | $ | 221 |  |
| Asbestos-related recoveries included in Other current assets |  | $ | 5 |  |  | $ | 5 |  |
| Asbestos-related recoveries included in Other assets |  | 86 |  |  | 88 |  |
| Total Asbestos-related recoveries |  | $ | 91 |  |  | $ | 93 |  |

[0001783180-24-000077:notes:179]
The amounts recorded for asbestos-related liabilities are based on currently available information and assumptions that the Company believes are reasonable and are made with input from outside actuarial experts. These amounts are undiscounted and exclude the Company’s legal fees to defend the asbestos claims, which are expensed as incurred. In addition, the Company has recorded insurance recovery receivables for probable asbestos-related recoveries.

[0001783180-24-000077:notes:180]
Aqueous Film Forming Foam Litigation

[0001783180-24-000077:notes:181]
As of June 30, 2024, the Company, KFI and others have been named as defendants in more than 8,500 lawsuits filed by individuals in or removed to the federal courts of the United States alleging that the historic use of Aqueous Film Forming Foam ("AFFF") caused personal injuries and/or property damage. The Company, KFI and others have also been named as defendants in more than 800 lawsuits filed by several U.S. states, municipalities and water utilities in or removed to U.S. federal courts alleging that the historic use of AFFF caused contamination of property and water supplies. In December 2018, the U.S. Judicial Panel on Multidistrict Litigation transferred and consolidated all AFFF cases pending in the U.S. federal courts against the Company, KFI and others to the U.S. District Court for the District of South Carolina (the "MDL Proceedings"). The individual plaintiffs in the MDL Proceedings generally seek damages for alleged personal injuries, medical monitoring, diminution in property value and injunctive relief to remediate alleged contamination of water supplies. The U.S. state, municipal and water utility plaintiffs in the MDL Proceedings generally seek damages and costs related to the remediation of public property and water supplies.

[0001783180-24-000077:notes:182]
AFFF is a firefighting foam, developed beginning in the late 1960s pursuant to U.S. military specification, used to extinguish certain types of hydrocarbon-fueled fires. The lawsuits identified above relate to Kidde Fire Fighting, Inc., which owned the National Foam business. Kidde Fire Fighting, Inc. was acquired by a UTC subsidiary in 2005 and merged into KFI in 2007. The National Foam business manufactured AFFF for sale to government (including the U.S. federal government) and non-government customers in the U.S. at a single facility located in West Chester, Pennsylvania (the "Pennsylvania Site"). In 2013, KFI divested the AFFF businesses to an unrelated third party. The Company acquired KFI as part of the Separation in April 2020.

[0001783180-24-000077:notes:183]
The key components that contribute to AFFF's fire-extinguishing capabilities are known as fluorosurfactants. Neither the Company, nor KFI, nor any of the Company's subsidiaries involved in the AFFF litigation manufactured fluorosurfactants. Instead, the National Foam business purchased these substances from unrelated third parties for use in manufacturing AFFF. Plaintiffs in the MDL Proceedings allege that the fluorosurfactants used by various manufacturers in producing AFFF contained, or over time degraded into, compounds known as per- and polyfluoroalkyl substances (referred to collectively as "PFAS"), including perflourooctanesulfonic acid ("PFOS") and perflourooctanoic acid ("PFOA"). Plaintiffs further allege that, as a result of the use of AFFF, PFOS and PFOA were released into the environment and, in some instances, ultimately reached drinking water supplies.

[0001783180-24-000077:notes:184]
Plaintiffs in the MDL Proceedings allege that PFOS and PFOA contamination has resulted from the use of AFFF manufactured using a process known as ECF, and that this process was used exclusively by 3M. They also allege that PFOA contamination has resulted from the use of AFFF manufactured using a different process, known as telomerization, and that this process was used exclusively by the other AFFF manufacturers (including the National Foam business). Compounds containing PFOS and PFOA (as well as many other PFAS) have also been used for decades by many third parties in a number of different industries to manufacture firefighters’ protective outerwear, carpets, clothing, fabrics, cookware, food packaging, personal care products, cleaning products, paints, varnishes and other consumer and industrial products.

[0001783180-24-000077:notes:185]
Plaintiffs in the MDL Proceedings have named multiple defendants, including suppliers of chemicals and raw materials used to manufacture fluorosurfactants, fluorosurfactant manufacturers and AFFF manufacturers. The defendants in the MDL Proceedings moved for summary judgment on the government contractor defense, which potentially applies to AFFF sold to or used by the U.S. government. After full briefing and oral argument, on September 16, 2022, the MDL court declined to enter summary judgment for the defendants. The defense, however, remains available at any trial to which it applies.

[0001783180-24-000077:notes:186]
On September 23, 2022, after completion of discovery, the MDL court selected one water provider case, the City of Stuart, FL v. 3M, et al., for a bellwether trial. That trial was scheduled to begin in early June 2023 but was postponed indefinitely. The MDL court ordered that the bellwether process for personal injury cases to begin in 2023. However, the court has not yet outlined details on that process or its timing.

[0001783180-24-000077:notes:187]
Outside of the MDL Proceedings, the Company and other defendants also are party to six lawsuits in U.S. state courts brought by oil refining companies alleging product liability claims related to legacy sales of AFFF and seeking damages for the costs to replace the product and for property damage. In addition, the Company and other defendants are party to two actions related to the Pennsylvania Site in which the plaintiff water utility company seeks remediation costs related to the alleged contamination of the local water supply. The Company, KFI and other defendants are also party to one action in Arizona state court brought by a firefighter claiming that occupational exposure to AFFF has caused certain personal injuries.

[0001783180-24-000077:notes:188]
The Company and KFI believe that they have meritorious defenses to the claims in the MDL Proceedings and the other AFFF lawsuits. Given the numerous factual, scientific and legal issues to be resolved relating to these claims, the Company is unable to assess the probability of liability or to reasonably estimate a range of possible loss at this time. There can be no assurance that any such future exposure will not be material in any period.

[0001783180-24-000077:notes:189]
On May 14, 2023, KFI filed a voluntary petition with the United States Bankruptcy Court for the District of Delaware seeking relief under Chapter 11 of the Bankruptcy Code after the Company determined that it would not provide financial support to KFI going forward, other than ensuring KFI has access to services necessary for the effective operation of its business. As a result, all litigation against KFI is automatically stayed. KFI filed an adversary complaint and motion in the Chapter 11 case seeking an order staying or enjoining all AFFF-related litigation against the Company, its other subsidiaries and RTX. That motion was resolved through an agreement that effectively stays the AFFF litigation against these parties. KFI has also indicated to the bankruptcy court that it intends to pursue insurance coverage for AFFF-related liabilities and contractual indemnification for AFFF-related liabilities from the third party to which KFI sold National Foam. On November 21, 2023, the bankruptcy court ordered certain parties, including the Company, to participate in a mediation with respect to claims that might be asserted by and against it in the bankruptcy proceedings. The parties have engaged in several mediation sessions and anticipate further sessions in the future. The terms and scope of any potential settlement may be affected by, among other factors, the United States Supreme Court's decision in Harrington v. Purdue Pharma, L.P., which held that nonconsensual releases of litigation claims against non-debtors are unavailable.

[0001783180-24-000077:notes:190]
Deconsolidation Due to Bankruptcy

[0001783180-24-000077:notes:191]
As of May 14, 2023, the Company no longer controlled KFI as their activities are subject to review and oversight by the bankruptcy court. Therefore, KFI was deconsolidated and their respective assets and liabilities were derecognized from the Company’s Unaudited Condensed Consolidated Financial Statements. Upon deconsolidation, the Company determined the fair value of its retained interest in KFI to be zero and will account for it prospectively using the cost method. As a result of these actions, the Company recognized a loss of $297 million in its Unaudited Condensed Consolidated Statement of Operations within Other income/(expense), net. In addition, the deconsolidation resulted in an investing cash outflow of $134 million in the Company's Unaudited Condensed Consolidated Statement of Cash Flows.

[0001783180-24-000077:notes:192]
In connection with the bankruptcy filing, KFI entered into several agreements with subsidiaries of the Company to ensure they have access to services necessary for the effective operation of their business. All post-deconsolidation activity between the Company and KFI are reported as third-party transactions recorded within the Company's Unaudited Condensed Consolidated Statement of Operations. Since the petition date, there were no material transactions between the Company and KFI other than a $15 million payment by the Company to KFI under the terms of a tax sharing arrangement.

[0001783180-24-000077:notes:193]
On March 15, 2024, the Company and Pacific Avenue Capital Partners entered into certain agreements including a stock and asset purchase agreement whereby Pacific Avenue Capital Partners shall acquire certain assets and operating liabilities of KFI, subject to approval by the bankruptcy court. On April 1, 2024, the bankruptcy court subsequently approved the sale, which was completed on July 1, 2024 for $140 million, subject to working capital and other adjustments as provided in the sale agreement. However, there has been no determination with respect to the allocation of sale proceeds.

[0001783180-24-000077:notes:194]
Income Taxes

[0001783180-24-000077:notes:195]
Under the TMA relating to the Separation, the Company is responsible to UTC for its share of the Tax Cuts and Jobs Act transition tax associated with foreign undistributed earnings as of December 31, 2017. During the six months ended June 30, 2024, the Company recognized a $46 million gain associated with the TMA and UTC's conclusion of certain income tax matters from their 2017 and 2018 tax audit with the IRS. Liabilities under the TMA of $118 million and $108 million are included within the accompanying Unaudited Condensed Consolidated Balance Sheet within Accrued Liabilities and Other Long-Term Liabilities as of June 30, 2024, respectively. This obligation is expected to be settled in annual installments with the next installment of $118 million due in April 2025 and the final installment due in April 2026. The Company believes that the likelihood of incurring losses materially in excess of this amount is remote.

[0001783180-24-000077:notes:196]
Other

[0001783180-24-000077:notes:197]
The Company has other commitments and contingent liabilities related to legal proceedings, self-insurance programs and matters arising in the ordinary course of business. The Company accrues for contingencies generally based upon a range of possible outcomes. If no amount within the range is a better estimate than any other, the Company accrues the minimum amount.

[0001783180-24-000077:notes:198]
In the ordinary course of business, the Company is also routinely a defendant in, party to or otherwise subject to many pending and threatened legal actions, claims, disputes and proceedings. These matters are often based on alleged violations of contract, product liability, warranty, regulatory, environmental, health and safety, employment, intellectual property, tax and other laws. In some of these proceedings, claims for substantial monetary damages are asserted against the Company and could result in fines, penalties, compensatory or treble damages or non-monetary relief. The Company does not believe that these matters will have a material adverse effect upon its results of operations, cash flows or financial condition.
