# CARR 8-K — 0001783180-24-000075 filed 2024-07-25

## item codes, every 8-K on or before 2024-07-25

- 2024-07-25 0001783180-24-000075 — 2.02, 9.01
- 2024-06-21 0001783180-24-000069 — 5.02
- 2024-06-21 0000950142-24-001676 — 5.02
- 2024-06-07 0001783180-24-000062 — 5.02, 5.03, 9.01
- 2024-06-03 0000950142-24-001538 — 1.02, 7.01, 9.01
- 2024-05-17 0001783180-24-000049 — 1.01, 1.02, 2.03, 9.01
- 2024-04-25 0001783180-24-000042 — 2.02, 9.01
- 2024-04-19 0001783180-24-000035 — 5.07, 9.01
- 2024-04-19 0000950142-24-001162 — 5.07 — amendment of 0001783180-24-000035
- 2024-02-06 0001783180-24-000007 — 2.02, 9.01
- 2024-02-01 0000950142-24-000264 — 5.02
- 2024-01-02 0001140361-24-000034 — 1.01, 2.01, 2.03, 5.02, 7.01, 9.01
- 2023-12-13 0001140361-23-057415 — 1.01, 9.01
- 2023-12-08 0001140361-23-056751 — 7.01, 9.01
- 2023-11-30 0000950142-23-002884 — 1.01, 2.03, 8.01, 9.01
- 2023-11-16 0000950142-23-002788 — 8.01, 9.01
- 2023-11-13 0001140361-23-052667 — 7.01, 8.01, 9.01
- 2023-10-26 0001783180-23-000063 — 2.02, 9.01
- 2023-07-27 0001783180-23-000053 — 2.02, 9.01
- 2023-06-12 0000950142-23-001664 — 5.02
- 2023-05-25 0000950142-23-001541 — 1.01, 1.02, 2.03, 9.01
- 2023-04-26 0000950142-23-001205 — 1.01, 9.01
- 2023-04-25 0001783180-23-000036 — 2.02, 7.01, 9.01
- 2023-04-25 0000950142-23-001199 — 7.01, 8.01, 9.01
- 2023-04-21 0001783180-23-000032 — 5.07, 9.01
- 2023-02-07 0001783180-23-000010 — 2.02, 9.01
- 2022-10-27 0001783180-22-000054 — 2.02, 7.01, 9.01
- 2022-09-29 0000950142-22-002805 — 5.02, 9.01
- 2022-07-28 0001783180-22-000045 — 2.02, 9.01
- 2022-04-28 0001783180-22-000032 — 2.02, 9.01
- 2022-04-15 0001783180-22-000024 — 5.07, 9.01
- 2022-02-08 0001783180-22-000008 — 2.02, 9.01
- 2022-02-07 0000950142-22-000510 — 8.01, 9.01
- 2022-01-03 0000950142-22-000023 — 8.01, 9.01
- 2021-12-17 0001783180-21-000071 — 5.02, 7.01, 9.01
- 2021-11-23 0001783180-21-000068 — 5.03, 9.01
- 2021-10-28 0001783180-21-000062 — 2.02, 9.01
- 2021-08-27 0001783180-21-000056 — 8.01
- 2021-07-30 0001783180-21-000053 — 1.01
- 2021-07-29 0001783180-21-000049 — 2.02, 8.01, 9.01
- 2021-07-27 0000950142-21-002448 — 8.01, 9.01
- 2021-07-15 0000950142-21-002362 — 5.02, 9.01
- 2021-06-09 0000950142-21-001885 — 5.02, 9.01
- 2021-04-29 0001783180-21-000029 — 2.02, 9.01
- 2021-04-22 0001140361-21-013889 — 5.02, 9.01
- 2021-04-20 0001783180-21-000021 — 5.07, 9.01
- 2021-04-19 0000950142-21-001308 — 8.01, 9.01
- 2021-02-09 0001783180-21-000009 — 2.02, 9.01
- 2021-02-05 0001140361-21-003513 — 8.01, 9.01
- 2020-12-23 0001140361-20-029419 — 7.01, 9.01
- 2020-12-22 0001140361-20-029097 — 8.01
- 2020-12-14 0001140361-20-028246 — 5.03, 9.01
- 2020-12-07 0001140361-20-027515 — 1.01, 7.01, 9.01
- 2020-10-29 0001783180-20-000063 — 2.02, 9.01
- 2020-10-19 0001140361-20-023241 — 5.02, 7.01, 9.01
- 2020-09-23 0001140361-20-021220 — 8.01, 9.01
- 2020-09-22 0001140361-20-021124 — 8.01, 9.01
- 2020-07-30 0001783180-20-000045 — 2.02, 9.01
- 2020-06-19 0001140361-20-014325 — 1.01, 2.03, 9.01
- 2020-06-16 0001140361-20-013880 — 8.01, 9.01
- 2020-06-03 0001140361-20-012939 — 1.01, 9.01
- 2020-05-08 0001783180-20-000013 — 2.02, 9.01
- 2020-04-03 0001140361-20-007888 — 1.01, 5.02, 5.03, 5.05, 7.01, 9.01
- 2020-03-16 0001140361-20-005868 — 8.01, 9.01

## late-filing notifications on or before 2024-07-25

- none on or before 2024-07-25

## item 2.02 — earnings release, exhibit 99.1

[0001783180-24-000075:8k_2_02:1]
EX-99
2
a99-q22024earningsexhibit.htm
EX-99

[0001783180-24-000075:8k_2_02:2]
Document

[0001783180-24-000075:8k_2_02:3]
Exhibit 99

[0001783180-24-000075:8k_2_02:4]
Carrier Reports Strong Second Quarter 2024 Results

[0001783180-24-000075:8k_2_02:5]
•Net sales of $6.7 billion up 12% versus second quarter 2023; organic sales up 2%

[0001783180-24-000075:8k_2_02:6]
•GAAP EPS of $2.55 up significantly and adjusted EPS of $0.87 up double-digits

[0001783180-24-000075:8k_2_02:7]
•GAAP operating margin expanded significantly year over year; adjusted operating margin expanded 200 bps

[0001783180-24-000075:8k_2_02:8]
•Reaffirming full year 2024 adjusted EPS guidance range

[0001783180-24-000075:8k_2_02:9]
•Closed two of four business exit transactions; remaining two on-track

[0001783180-24-000075:8k_2_02:10]
•Expect to repurchase about $1 billion worth of shares in the second half of 2024

[0001783180-24-000075:8k_2_02:11]
PALM BEACH GARDENS, Fla., July 25, 2024 – Carrier Global Corporation (NYSE:CARR), global leader in intelligent climate and energy solutions, today reported strong financial results for the second quarter of 2024 and reaffirmed its full year earnings guidance.

[0001783180-24-000075:8k_2_02:12]
“Carrier delivered another quarter of strong financial performance, while making great progress with our portfolio transformation,” said Carrier Chairman & CEO David Gitlin. “We delivered solid sales and roughly 30% orders growth as we continue to outperform in our markets. Our strong operational execution drove 200 basis points of adjusted operating margin expansion and double-digit adjusted earnings growth. Year-to-date, we also closed on two of our four business exits, and the remaining two continue to track well. The proceeds from the exits, combined with our strong free cash flow performance, have enabled us to reduce net debt by about $5 billion in the quarter and we now plan to repurchase about $1 billion of shares in the second half of 2024.”

[0001783180-24-000075:8k_2_02:13]
1

[0001783180-24-000075:8k_2_02:14]
Second Quarter 2024 Results

[0001783180-24-000075:8k_2_02:15]
Carrier’s second quarter sales of $6.7 billion were up 12% compared to the prior year including 2% organic growth and approximately 12% contribution from the acquisition of Viessmann Climate Solutions offset by about 2% from divestitures. Foreign currency translation had a 1% negative impact on sales. Organic sales in the HVAC segment were up 2%. HVAC sales in the Americas were up mid-single digits driven by continued strength in Commercial and Light Commercial businesses both of which were up double-digits. North America Residential HVAC sales were up about mid-single digits. HVAC organic sales in EMEA were up low-single-digits with Commercial HVAC up mid-teens, offsetting a decline in EMEA Residential and Light Commercial HVAC. These organic figures exclude the contribution of Viessmann Climate Solutions which was down almost 30% year-over-year in the quarter, roughly one third of which was driven by lower solar PV sales. HVAC sales in Asia Pacific were down high-single-digits with declines driven by residential light commercial in China, partially offset by Southeast Asia which was up double-digits. Refrigeration sales were up 1% organically driven by over 30% growth in container, mostly offset by North America truck and trailer and commercial refrigeration. Fire and Security showed broad-based growth and sales were up 3% organically in the quarter. The residential and commercial fire organic sales, the last of our four business exits, were up mid-single digits.

[0001783180-24-000075:8k_2_02:16]
GAAP operating profit in the quarter of $3.7 billion was up over 650% from last year primarily due to the gain on the sale of Access Solutions and the addition of Viessmann Climate Solutions. Adjusted operating profit of $1.2 billion was up 26%, mostly driven by the addition of Viessmann Climate Solutions.

[0001783180-24-000075:8k_2_02:17]
Net income was $2.3 billion and adjusted net income was $793 million. GAAP EPS was $2.55 and adjusted EPS was $0.87. Net cash flows generated from operating activities were $660 million and capital expenditures were $111 million, resulting in free cash flow of $549 million. During the second-quarter, Carrier received $5.0 billion in cash proceeds from the sale of Access Solutions, redeemed $1.0 billion of its long-term notes, and repaid €2.3 billion of its term-loans.

[0001783180-24-000075:8k_2_02:18]
2

[0001783180-24-000075:8k_2_02:19]
Full-Year 2024 Guidance**

[0001783180-24-000075:8k_2_02:20]
Carrier updated the following guidance for 2024, which now includes Commercial Refrigeration for nine-months.

[0001783180-24-000075:8k_2_02:21]
|  | Current Guidance | Prior Guidance |
| Sales | ~$25.5B Organic* up MSDFX (1%)Acquisitions +16%Divestitures (5%) | ~$26B Organic* up MSDFX (0%)Acquisitions +18%Divestitures (6%) |
| Adjusted Operating Margin* | ~15.5% | ~15.5% |
| Adjusted EPS* | $2.80 - $2.90 | $2.80 - $2.90 |
| Free Cash Flow* | ~$0.4BIncludes ~$2B of expected tax payments on the gains from the announced business exits, restructuring, and transaction-related costs | ~$0.4BIncludes ~$2B of expected tax payments on the gains from the announced business exits, restructuring, and transaction-related costs |

[0001783180-24-000075:8k_2_02:22]
*Note: When the company provides expectations for organic sales, adjusted operating profit, adjusted operating margin, adjusted EPS and free cash flow on a forward-looking basis, a reconciliation of the differences between the non-GAAP expectations and the corresponding GAAP measures generally is not available without unreasonable effort. See “Use and Definitions of Non-GAAP Financial Measures” below for additional information.

[0001783180-24-000075:8k_2_02:23]
**As of July 25, 2024

[0001783180-24-000075:8k_2_02:24]
Conference Call

[0001783180-24-000075:8k_2_02:25]
Carrier will host a webcast of its earnings conference call today, Thursday, July 25, 2024, at 7:30 a.m. ET. To access the webcast, visit the Events & Presentations section of the Carrier Investor Relations site at ir.carrier.com/news-and-events/events-and-presentations or to listen to the earnings call by phone, participants must pre-register at Carrier Earnings Call Registration. All registrants will receive dial-in information and a PIN allowing access to the live call.

[0001783180-24-000075:8k_2_02:26]
3

[0001783180-24-000075:8k_2_02:27]
Cautionary Statement

[0001783180-24-000075:8k_2_02:28]
This communication contains statements which, to the extent they are not statements of historical or present fact, constitute "forward-looking statements" under the securities laws. These forward-looking statements are intended to provide management's current expectations or plans for Carrier's future operating and financial performance, based on assumptions currently believed to be valid. Forward-looking statements can be identified by the use of words such as "believe," "expect," "expectations," "plans," "strategy," "prospects," "estimate," "project," "target," "anticipate," "will," "should," "see," "guidance," "outlook," "confident," "scenario" and other words of similar meaning in connection with a discussion of future operating or financial performance. Forward-looking statements may include, among other things, statements relating to future sales, earnings, cash flow, results of operations, uses of cash, share repurchases, tax rates and other measures of financial performance or potential future plans, strategies or transactions of Carrier, our portfolio transformation and the use of the anticipated proceeds thereof, potential future investments, Carrier's plans with respect to its indebtedness and other statements that are not historical facts. All forward-looking statements involve risks, uncertainties and other factors that may cause actual results to differ materially from those expressed or implied in the forward-looking statements. For additional information on identifying factors that may cause actual results to vary materially from those stated in forward-looking statements, see Carrier's reports on Forms 10-K, 10-Q and 8-K filed with or furnished to the U.S. Securities and Exchange Commission from time to time. Any forward-looking statement speaks only as of the date on which it is made, and Carrier assumes no obligation to update or revise such statement, whether as a result of new information, future events or otherwise, except as required by applicable law.

[0001783180-24-000075:8k_2_02:29]
About Carrier

[0001783180-24-000075:8k_2_02:30]
Carrier Global Corporation, global leader in intelligent climate and energy solutions, is committed to creating solutions that matter for people and our planet for generations to come. From the beginning, we've led in inventing new technologies and entirely new industries. Today, we continue to lead because we have a world-class, diverse workforce that puts the customer at the center of everything we do. For more information, visit corporate.carrier.com or follow Carrier on social media at @Carrier.

[0001783180-24-000075:8k_2_02:31]
CARR-IR

[0001783180-24-000075:8k_2_02:32]
Contact:

[0001783180-24-000075:8k_2_02:33]
Investor Relations

[0001783180-24-000075:8k_2_02:34]
Sam Pearlstein

[0001783180-24-000075:8k_2_02:35]
561-365-2251

[0001783180-24-000075:8k_2_02:36]
Sam.Pearlstein@Carrier.com

[0001783180-24-000075:8k_2_02:37]
Media Inquiries

[0001783180-24-000075:8k_2_02:38]
Rob Six

[0001783180-24-000075:8k_2_02:39]
561-281-2362

[0001783180-24-000075:8k_2_02:40]
Rob.Six@Carrier.com

[0001783180-24-000075:8k_2_02:41]
4

[0001783180-24-000075:8k_2_02:42]
SELECTED FINANCIAL DATA, NON-GAAP MEASURES AND DEFINITIONS

[0001783180-24-000075:8k_2_02:43]
Following are tables that present selected financial data of Carrier Global Corporation (“Carrier”). Also included are reconciliations of non-GAAP measures to their most comparable GAAP measures.

[0001783180-24-000075:8k_2_02:44]
Use and Definitions of Non-GAAP Financial Measures

[0001783180-24-000075:8k_2_02:45]
Carrier Global Corporation (“Carrier”) reports its financial results in accordance with accounting principles generally accepted in the United States ("GAAP"). We supplement the reporting of our financial information determined under GAAP with certain non-GAAP financial information. The non-GAAP information presented provides investors with additional useful information, but should not be considered in isolation or as substitutes for the related GAAP measures. Moreover, other companies may define non-GAAP measures differently, which limits the usefulness of these measures for comparisons with such other companies. We encourage investors to review our financial statements and publicly filed reports in their entirety and not to rely on any single financial measure. A reconciliation of the non-GAAP measures to the corresponding amounts prepared in accordance with GAAP appears in the tables in this Appendix. The tables provide additional information as to the items and amounts that have been excluded from the adjusted measures.

[0001783180-24-000075:8k_2_02:46]
Organic sales, adjusted operating profit, adjusted operating margin, incremental margins / earnings conversion, earnings before interest, taxes and depreciation and amortization (“EBITDA”), adjusted EBITDA, adjusted net income, adjusted earnings per share (“EPS”), adjusted interest expense, net, adjusted effective tax rate and net debt are non-GAAP financial measures.

[0001783180-24-000075:8k_2_02:47]
Organic sales represents consolidated net sales (a GAAP measure), excluding the impact of foreign currency translation, acquisitions and divestitures completed in the preceding twelve months and other significant items of a nonoperational nature (hereinafter referred to as “other significant items”). Adjusted operating profit represents operating profit (a GAAP measure), excluding restructuring costs, amortization of acquired intangibles and other significant items. Adjusted operating margin represents adjusted operating profit as a percentage of net sales (a GAAP measure). Incremental margins / earnings conversion represents the year-over-year change in adjusted operating profit divided by the year-over-year change in net sales. EBITDA represents net income attributable to common shareholders (a GAAP measure), adjusted for interest income and expense, income tax expense, and depreciation and amortization. Adjusted EBITDA represents EBITDA, as calculated above, excluding non-service pension benefit, non-controlling interest in subsidiaries’ earnings from operations, restructuring costs and other significant items. Adjusted net income represents net income attributable to common shareowners (a GAAP measure), excluding restructuring costs, amortization of acquired intangibles and other significant items. Adjusted EPS represents diluted earnings per share (a GAAP measure), excluding restructuring costs, amortization of acquired intangibles and other significant items. Adjusted interest expense, net represents interest expense (a GAAP measure) and interest income (a GAAP measure), net excluding other significant items. The adjusted effective tax rate represents the effective tax rate (a GAAP measure), excluding restructuring costs, amortization of acquired intangibles and other significant items. Net debt represents long-term debt (a GAAP measure) less cash and cash equivalents (a GAAP measure). For the business segments, when applicable, adjustments of operating profit and operating margins represent operating profit, excluding restructuring, amortization of acquired intangibles and other significant items.

[0001783180-24-000075:8k_2_02:48]
Free cash flow is a non-GAAP financial measure that represents net cash flows provided by operating activities (a GAAP measure) less capital expenditures. Management believes free cash flow is a useful measure of liquidity and an additional basis for assessing Carrier’s ability to fund its activities, including the financing of acquisitions, debt service, repurchases of Carrier's common stock and distribution of earnings to shareowners.

[0001783180-24-000075:8k_2_02:49]
Orders are contractual commitments with customers to provide specified goods or services for an agreed upon price and may not be subject to penalty if cancelled.

[0001783180-24-000075:8k_2_02:50]
When we provide our expectations for organic sales, adjusted operating profit, adjusted operating margin, adjusted interest expense, net, adjusted effective tax rate, incremental margins/earnings conversion, EBITDA, adjusted EBITDA, adjusted EPS and free cash flow on a forward-looking basis, a reconciliation of the differences between the non-GAAP expectations and the corresponding GAAP measures (expected net sales, operating profit, operating margin, interest expense, effective tax rate, incremental operating margin, net income attributable to common shareowners, diluted EPS and net cash flows provided by operating activities) generally is not available without unreasonable effort due to potentially high variability, complexity and low visibility as to the items that would be excluded from the GAAP measure in the relevant future period, such as unusual gains and losses, the ultimate outcome of pending litigation, fluctuations in foreign currency exchange rates, the impact and timing of potential acquisitions and divestitures, future restructuring costs, and other structural changes or their probable significance. The variability of the excluded items may have a significant, and potentially unpredictable, impact on our future GAAP results.

[0001783180-24-000075:8k_2_02:51]
5

[0001783180-24-000075:8k_2_02:52]
Carrier Global Corporation

[0001783180-24-000075:8k_2_02:53]
Condensed Consolidated Statement of Operations

[0001783180-24-000075:8k_2_02:54]
|  |  | (Unaudited) |
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
| (In millions, except per share amounts) |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Net sales |  |  |  |  |  |  |  |  |
| Product sales |  | $ | 6,004 |  |  | $ | 5,355 |  |  | $ | 11,546 |  |  | $ | 10,041 |  |
| Service sales |  | 685 |  |  | 637 |  |  | 1,325 |  |  | 1,224 |  |
| Total Net sales |  | 6,689 |  |  | 5,992 |  |  | 12,871 |  |  | 11,265 |  |
| Costs and expenses |  |  |  |  |  |  |  |  |
| Cost of products sold |  | (4,296) |  |  | (3,769) |  |  | (8,294) |  |  | (7,227) |  |
| Cost of services sold |  | (515) |  |  | (468) |  |  | (994) |  |  | (905) |  |
| Research and development |  | (187) |  |  | (151) |  |  | (411) |  |  | (290) |  |
| Selling, general and administrative |  | (975) |  |  | (784) |  |  | (1,960) |  |  | (1,505) |  |
| Total Costs and expenses |  | (5,973) |  |  | (5,172) |  |  | (11,659) |  |  | (9,927) |  |
| Equity method investment net earnings |  | 90 |  |  | 52 |  |  | 121 |  |  | 96 |  |
| Other income (expense), net |  | 2,885 |  |  | (383) |  |  | 2,858 |  |  | (390) |  |
| Operating profit |  | 3,691 |  |  | 489 |  |  | 4,191 |  |  | 1,044 |  |
| Non-service pension (expense) benefit |  | (1) |  |  | — |  |  | (1) |  |  | — |  |
| Interest (expense) income, net |  | (166) |  |  | (67) |  |  | (331) |  |  | (113) |  |
| Income from operations before income taxes |  | 3,524 |  |  | 422 |  |  | 3,859 |  |  | 931 |  |
| Income tax (expense) benefit |  | (1,155) |  |  | (189) |  |  | (1,201) |  |  | (311) |  |
| Net income from operations |  | 2,369 |  |  | 233 |  |  | 2,658 |  |  | 620 |  |
| Less: Non-controlling interest in subsidiaries' earnings from operations |  | 32 |  |  | 34 |  |  | 52 |  |  | 48 |  |
| Net income attributable to common shareowners |  | $ | 2,337 |  |  | $ | 199 |  |  | $ | 2,606 |  |  | $ | 572 |  |
| Earnings per share |  |  |  |  |  |  |  |  |
| Basic |  | $ | 2.59 |  |  | $ | 0.24 |  |  | $ | 2.90 |  |  | $ | 0.68 |  |
| Diluted |  | $ | 2.55 |  |  | $ | 0.23 |  |  | $ | 2.85 |  |  | $ | 0.67 |  |
| Weighted-average number of shares outstanding |  |  |  |  |  |  |  |  |
| Basic |  | 902.4 |  |  | 836.0 |  |  | 900.2 |  |  | 835.5 |  |
| Diluted |  | 915.3 |  |  | 850.9 |  |  | 913.6 |  |  | 851.5 |  |

[0001783180-24-000075:8k_2_02:55]
6

[0001783180-24-000075:8k_2_02:56]
Carrier Global Corporation

[0001783180-24-000075:8k_2_02:57]
Condensed Consolidated Balance Sheet

[0001783180-24-000075:8k_2_02:58]
|  |  | (Unaudited) |
| (In millions) |  | June 30, 2024 |  | December 31, 2023 |
| Assets |  |  |  |  |
| Cash and cash equivalents |  | $ | 2,919 |  |  | $ | 10,015 |  |
| Accounts receivable, net |  | 3,187 |  |  | 2,481 |  |
| Contract assets |  | 333 |  |  | 306 |  |
| Inventories, net |  | 3,045 |  |  | 2,217 |  |
| Assets held for sale |  | 1,601 |  |  | 3,314 |  |
| Other current assets |  | 488 |  |  | 447 |  |
| Total current assets |  | 11,573 |  |  | 18,780 |  |
| Future income tax benefits |  | 939 |  |  | 739 |  |
| Fixed assets, net |  | 3,117 |  |  | 2,293 |  |
| Operating lease right-of-use assets |  | 635 |  |  | 491 |  |
| Intangible assets, net |  | 7,048 |  |  | 1,028 |  |
| Goodwill |  | 15,245 |  |  | 7,989 |  |
| Pension and post-retirement assets |  | 81 |  |  | 32 |  |
| Equity method investments |  | 1,221 |  |  | 1,140 |  |
| Other assets |  | 565 |  |  | 330 |  |
| Total Assets |  | $ | 40,424 |  |  | $ | 32,822 |  |
| Liabilities and Equity |  |  |  |  |
| Accounts payable |  | $ | 3,181 |  |  | $ | 2,742 |  |
| Accrued liabilities |  | 4,262 |  |  | 2,811 |  |
| Contract liabilities |  | 493 |  |  | 425 |  |
| Liabilities held for sale |  | 687 |  |  | 862 |  |
| Current portion of long-term debt |  | 2,052 |  |  | 51 |  |
| Total current liabilities |  | 10,675 |  |  | 6,891 |  |
| Long-term debt |  | 11,270 |  |  | 14,242 |  |
| Future pension and post-retirement obligations |  | 247 |  |  | 155 |  |
| Future income tax obligations |  | 2,184 |  |  | 535 |  |
| Operating lease liabilities |  | 501 |  |  | 391 |  |
| Other long-term liabilities |  | 1,468 |  |  | 1,603 |  |
| Total Liabilities |  | 26,345 |  |  | 23,817 |  |
| Equity |  |  |  |  |
| Common stock |  | 9 |  |  | 9 |  |
| Treasury stock |  | (1,972) |  |  | (1,972) |  |
| Additional paid-in capital |  | 8,563 |  |  | 5,535 |  |
| Retained earnings |  | 8,854 |  |  | 6,591 |  |
| Accumulated other comprehensive loss |  | (1,686) |  |  | (1,486) |  |
| Non-controlling interest |  | 311 |  |  | 328 |  |
| Total Equity |  | 14,079 |  |  | 9,005 |  |
| Total Liabilities and Equity |  | $ | 40,424 |  |  | $ | 32,822 |  |

[0001783180-24-000075:8k_2_02:59]
7

[0001783180-24-000075:8k_2_02:60]
Carrier Global Corporation

[0001783180-24-000075:8k_2_02:61]
Condensed Consolidated Statement of Cash Flows

[0001783180-24-000075:8k_2_02:62]
|  |  |  |  | (Unaudited) |
|  |  |  | Six Months Ended June 30, |
| (In millions) |  |  |  |  | 2024 |  | 2023 |
| Operating Activities |  |  |  |  |  |  |  |
| Net income from operations |  |  |  |  | $ | 2,658 |  |  | $ | 620 |  |
| Adjustments to reconcile net income to net cash flows from operating activities: |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  |  |  | 625 |  |  | 273 |  |
| Deferred income tax provision |  |  |  |  | (338) |  |  | (110) |  |
| Stock-based compensation costs |  |  |  |  | 48 |  |  | 40 |  |
| Equity method investment net earnings |  |  |  |  | (121) |  |  | (96) |  |
| (Gain) loss on sale of investments / deconsolidation |  |  |  |  | (2,881) |  |  | 276 |  |
| Changes in operating assets and liabilities |  |  |  |  |  |  |  |
| Accounts receivable, net |  |  |  |  | (286) |  |  | (406) |  |
| Contract assets |  |  |  |  | (62) |  |  | (40) |  |
| Inventories, net |  |  |  |  | (2) |  |  | (59) |  |
| Other current assets |  |  |  |  | (52) |  |  | (105) |  |
| Accounts payable and accrued liabilities |  |  |  |  | 1,118 |  |  | 120 |  |
| Contract liabilities |  |  |  |  | (19) |  |  | 37 |  |
| Distributions from equity method investments |  |  |  |  | 12 |  |  | 10 |  |
| Other operating activities, net |  |  |  |  | — |  |  | (56) |  |
| Net cash flows provided by (used in) operating activities |  |  |  |  | 700 |  |  | 504 |  |
| Investing Activities |  |  |  |  |  |  |  |
| Capital expenditures |  |  |  |  | (215) |  |  | (144) |  |
| Investment in businesses, net of cash acquired |  |  |  |  | (10,779) |  |  | (56) |  |
| Dispositions of businesses |  |  |  |  | 4,877 |  |  | 36 |  |
| Settlement of derivative contracts, net |  |  |  |  | (185) |  |  | (14) |  |
| Kidde-Fenwal, Inc. deconsolidation |  |  |  |  | — |  |  | (134) |  |
| Other investing activities, net |  |  |  |  | 29 |  |  | 16 |  |
| Net cash flows provided by (used in) investing activities |  |  |  |  | (6,273) |  |  | (296) |  |
| Financing Activities |  |  |  |  |  |  |  |
| Increase (decrease) in short-term borrowings, net |  |  |  |  | — |  |  | (19) |  |
| Issuance of long-term debt |  |  |  |  | 2,555 |  |  | 6 |  |
| Repayment of long-term debt |  |  |  |  | (3,542) |  |  | (12) |  |
| Repurchases of common stock |  |  |  |  | — |  |  | (62) |  |
| Dividends paid on common stock |  |  |  |  | (330) |  |  | (309) |  |
| Dividends paid to non-controlling interest |  |  |  |  | (67) |  |  | (41) |  |
| Other financing activities, net |  |  |  |  | (22) |  |  | (69) |  |
| Net cash flows provided by (used in) financing activities |  |  |  |  | (1,406) |  |  | (506) |  |
| Effect of foreign exchange rate changes on cash and cash equivalents |  |  |  |  | (82) |  |  | (13) |  |
| Net increase (decrease) in cash and cash equivalents and restricted cash, including cash classified in current assets held for sale |  |  |  |  | (7,061) |  |  | (311) |  |
| Less: Change in cash balances classified as assets held for sale |  |  |  |  | 34 |  |  | — |  |
| Net increase (decrease) in cash and cash equivalents and restricted cash |  |  |  |  | (7,095) |  |  | (311) |  |
| Cash, cash equivalents and restricted cash, beginning of period |  |  |  |  | 10,017 |  |  | 3,527 |  |
| Cash, cash equivalents and restricted cash, end of period |  |  |  |  | 2,922 |  |  | 3,216 |  |
| Less: restricted cash |  |  |  |  | 3 |  |  | 7 |  |
| Cash and cash equivalents, end of period |  |  |  |  | $ | 2,919 |  |  | $ | 3,209 |  |

[0001783180-24-000075:8k_2_02:63]
8

[0001783180-24-000075:8k_2_02:64]
Carrier Global Corporation

[0001783180-24-000075:8k_2_02:65]
Segment Net Sales and Operating Profit

[0001783180-24-000075:8k_2_02:66]
|  | (Unaudited) |
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| (In millions) | Reported |  | Adjusted |  | Reported |  | Adjusted |  | Reported |  | Adjusted |  | Reported |  | Adjusted |
| Net sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| HVAC | $ | 4,970 |  | $ | 4,970 |  | $ | 4,216 |  | $ | 4,216 |  | $ | 9,511 |  | $ | 9,511 |  | $ | 7,838 |  | $ | 7,838 |
| Refrigeration | 973 |  | 973 |  | 972 |  | 972 |  | 1,857 |  | 1,857 |  | 1,870 |  | 1,870 |
| Fire & Security | 871 |  | 871 |  | 932 |  | 932 |  | 1,758 |  | 1,758 |  | 1,801 |  | 1,801 |
| Segment sales | 6,814 |  | 6,814 |  | 6,120 |  | 6,120 |  | 13,126 |  | 13,126 |  | 11,509 |  | 11,509 |
| Eliminations and other | (125) |  | (125) |  | (128) |  | (128) |  | (255) |  | (255) |  | (244) |  | (244) |
| Net sales | $ | 6,689 |  | $ | 6,689 |  | $ | 5,992 |  | $ | 5,992 |  | $ | 12,871 |  | $ | 12,871 |  | $ | 11,265 |  | $ | 11,265 |
| Operating profit |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| HVAC | $ | 687 |  | $ | 991 |  | $ | 742 |  | $ | 791 |  | $ | 1,116 |  | $ | 1,711 |  | $ | 1,177 |  | $ | 1,281 |
| Refrigeration | 113 |  | 118 |  | 112 |  | 119 |  | 210 |  | 217 |  | 220 |  | 230 |
| Fire & Security | 3,001 |  | 155 |  | (157) |  | 137 |  | 3,154 |  | 319 |  | (64) |  | 245 |
| Segment operating profit | 3,801 |  | 1,264 |  | 697 |  | 1,047 |  | 4,480 |  | 2,247 |  | 1,333 |  | 1,756 |
| Eliminations and other | (23) |  | (20) |  | (146) |  | (35) |  | (98) |  | (54) |  | (184) |  | (71) |
| General corporate expenses | (87) |  | (31) |  | (62) |  | (48) |  | (191) |  | (53) |  | (105) |  | (79) |
| Operating profit | $ | 3,691 |  | $ | 1,213 |  | $ | 489 |  | $ | 964 |  | $ | 4,191 |  | $ | 2,140 |  | $ | 1,044 |  | $ | 1,606 |
| Operating margin |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| HVAC | 13.8 | % |  | 19.9 | % |  | 17.6 | % |  | 18.8 | % |  | 11.7 | % |  | 18.0 | % |  | 15.0 | % |  | 16.3 | % |
| Refrigeration | 11.6 | % |  | 12.1 | % |  | 11.5 | % |  | 12.2 | % |  | 11.3 | % |  | 11.7 | % |  | 11.8 | % |  | 12.3 | % |
| Fire & Security | 344.5 | % |  | 17.8 | % |  | (16.8) | % |  | 14.7 | % |  | 179.4 | % |  | 18.1 | % |  | (3.6) | % |  | 13.6 | % |
| Total Carrier | 55.2 | % |  | 18.1 | % |  | 8.2 | % |  | 16.1 | % |  | 32.6 | % |  | 16.6 | % |  | 9.3 | % |  | 14.3 | % |

[0001783180-24-000075:8k_2_02:67]
9

[0001783180-24-000075:8k_2_02:68]
Carrier Global Corporation

[0001783180-24-000075:8k_2_02:69]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP)

[0001783180-24-000075:8k_2_02:70]
Operating Profit

[0001783180-24-000075:8k_2_02:71]
|  | (Unaudited) |
|  | Three Months Ended June 30, 2024 |
| (In millions) | HVAC |  | Refrigeration |  | Fire & Security |  | Eliminations and Other |  | General Corporate Expenses |  | Carrier |
| Net sales | $ | 4,970 |  |  | $ | 973 |  |  | $ | 871 |  |  | $ | (125) |  |  | $ | — |  |  | $ | 6,689 |  |
| Segment operating profit | $ | 687 |  |  | $ | 113 |  |  | $ | 3,001 |  |  | $ | (23) |  |  | $ | (87) |  |  | $ | 3,691 |  |
| Reported operating margin | 13.8 | % |  | 11.6 | % |  | 344.5 | % |  |  |  |  |  | 55.2 | % |
| Adjustments to segment operating profit: |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring costs | $ | 25 |  |  | $ | 1 |  |  | $ | 3 |  |  | $ | 3 |  |  | $ | — |  |  | $ | 32 |  |
| Amortization of acquired intangibles | 170 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 170 |  |
| Acquisition step-up amortization (1) | 109 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 109 |  |
| Acquisition/divestiture-related costs | — |  |  | 4 |  |  | 32 |  |  | — |  |  | 56 |  |  | 92 |  |
| Access Solutions gain | — |  |  | — |  |  | (2,881) |  |  | — |  |  | — |  |  | (2,881) |  |
| Total adjustments to operating profit | $ | 304 |  |  | $ | 5 |  |  | $ | (2,846) |  |  | $ | 3 |  |  | $ | 56 |  |  | $ | (2,478) |  |
| Adjusted operating profit | $ | 991 |  |  | $ | 118 |  |  | $ | 155 |  |  | $ | (20) |  |  | $ | (31) |  |  | $ | 1,213 |  |
| Adjusted operating margin | 19.9 | % |  | 12.1 | % |  | 17.8 | % |  |  |  |  |  | 18.1 | % |

[0001783180-24-000075:8k_2_02:72]
|  | (Unaudited) |
|  | Three Months Ended June 30, 2023 |
| (In millions) | HVAC |  | Refrigeration |  | Fire & Security |  | Eliminations and Other |  | General Corporate Expenses |  | Carrier |
| Net sales | $ | 4,216 |  |  | $ | 972 |  |  | $ | 932 |  |  | $ | (128) |  |  | $ | — |  |  | $ | 5,992 |  |
| Segment operating profit | $ | 742 |  |  | $ | 112 |  |  | $ | (157) |  |  | $ | (146) |  |  | $ | (62) |  |  | $ | 489 |  |
| Reported operating margin | 17.6 | % |  | 11.5 | % |  | (16.8) | % |  |  |  |  |  | 8.2 | % |
| Adjustments to segment operating profit: |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring costs | $ | 3 |  |  | $ | 7 |  |  | $ | (1) |  |  | $ | — |  |  | $ | — |  |  | $ | 9 |  |
| Amortization of acquired intangibles | 36 |  |  | — |  |  | 2 |  |  | — |  |  | — |  |  | 38 |  |
| Acquisition step-up amortization (1) | 10 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 10 |  |
| Acquisition/divestiture-related costs | — |  |  | — |  |  | — |  |  | — |  |  | 14 |  |  | 14 |  |
| Viessmann-related hedges | — |  |  | — |  |  | — |  |  | 111 |  |  | — |  |  | 111 |  |
| KFI deconsolidation | — |  |  | — |  |  | 293 |  |  | — |  |  | — |  |  | 293 |  |
| Total adjustments to operating profit | $ | 49 |  |  | $ | 7 |  |  | $ | 294 |  |  | $ | 111 |  |  | $ | 14 |  |  | $ | 475 |  |
| Adjusted operating profit | $ | 791 |  |  | $ | 119 |  |  | $ | 137 |  |  | $ | (35) |  |  | $ | (48) |  |  | $ | 964 |  |
| Adjusted operating margin | 18.8 | % |  | 12.2 | % |  | 14.7 | % |  |  |  |  |  | 16.1 | % |

[0001783180-24-000075:8k_2_02:73]
(1)  Amortization of the step-up to fair value of acquired inventory and backlog.

[0001783180-24-000075:8k_2_02:74]
10

[0001783180-24-000075:8k_2_02:75]
Carrier Global Corporation

[0001783180-24-000075:8k_2_02:76]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP)

[0001783180-24-000075:8k_2_02:77]
Operating Profit

[0001783180-24-000075:8k_2_02:78]
|  | (Unaudited) |
|  | Six Months Ended June 30, 2024 |
| (In millions) | HVAC |  | Refrigeration |  | Fire & Security |  | Eliminations and Other |  | General Corporate Expenses |  | Carrier |
| Net sales | $ | 9,511 |  |  | $ | 1,857 |  |  | $ | 1,758 |  |  | $ | (255) |  |  | $ | — |  |  | $ | 12,871 |  |
| Segment operating profit | $ | 1,116 |  |  | $ | 210 |  |  | $ | 3,154 |  |  | $ | (98) |  |  | $ | (191) |  |  | $ | 4,191 |  |
| Reported operating margin | 11.7 | % |  | 11.3 | % |  | 179.4 | % |  |  |  |  |  | 32.6 | % |
| Adjustments to segment operating profit: |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring costs | $ | 32 |  |  | $ | 1 |  |  | $ | 10 |  |  | $ | 4 |  |  | $ | — |  |  | $ | 47 |  |
| Amortization of acquired intangibles | 342 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 342 |  |
| Acquisition step-up amortization (1) | 220 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 220 |  |
| Acquisition/divestiture-related costs | 1 |  |  | 6 |  |  | 36 |  |  | — |  |  | 138 |  |  | 181 |  |
| Viessmann-related hedges | — |  |  | — |  |  | — |  |  | 86 |  |  | — |  |  | 86 |  |
| Gain on liability adjustment (2) | — |  |  | — |  |  | — |  |  | (46) |  |  | — |  |  | (46) |  |
| Access Solutions gain | — |  |  | — |  |  | (2,881) |  |  | — |  |  | — |  |  | (2,881) |  |
| Total adjustments to operating profit | $ | 595 |  |  | $ | 7 |  |  | $ | (2,835) |  |  | $ | 44 |  |  | $ | 138 |  |  | $ | (2,051) |  |
| Adjusted operating profit | $ | 1,711 |  |  | $ | 217 |  |  | $ | 319 |  |  | $ | (54) |  |  | $ | (53) |  |  | $ | 2,140 |  |
| Adjusted operating margin | 18.0 | % |  | 11.7 | % |  | 18.1 | % |  |  |  |  |  | 16.6 | % |

[0001783180-24-000075:8k_2_02:79]
|  | (Unaudited) |
|  | Six Months Ended June 30, 2023 |
| (In millions) | HVAC |  | Refrigeration |  | Fire & Security |  | Eliminations and Other |  | General Corporate Expenses |  | Carrier |
| Net sales | $ | 7,838 |  |  | $ | 1,870 |  |  | $ | 1,801 |  |  | $ | (244) |  |  | $ | — |  |  | $ | 11,265 |  |
| Segment operating profit | $ | 1,177 |  |  | $ | 220 |  |  | $ | (64) |  |  | $ | (184) |  |  | $ | (105) |  |  | $ | 1,044 |  |
| Reported operating margin | 15.0 | % |  | 11.8 | % |  | (3.6) | % |  |  |  |  |  | 9.3 | % |
| Adjustments to segment operating profit: |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring costs | $ | 2 |  |  | $ | 10 |  |  | $ | 12 |  |  | $ | 2 |  |  | $ | — |  |  | $ | 26 |  |
| Amortization of acquired intangibles | 73 |  |  | — |  |  | 4 |  |  | — |  |  | — |  |  | 77 |  |
| Acquisition step-up amortization (1) | 21 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 21 |  |
| Acquisition/divestiture-related costs | — |  |  | — |  |  | — |  |  | — |  |  | 26 |  |  | 26 |  |
| Viessmann-related hedges | — |  |  | — |  |  | — |  |  | 111 |  |  | — |  |  | 111 |  |
| TCC acquisition-related gain (3) | 8 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 8 |  |
| KFI deconsolidation | — |  |  | — |  |  | 293 |  |  | — |  |  | — |  |  | 293 |  |
| Total adjustments to operating profit | $ | 104 |  |  | $ | 10 |  |  | $ | 309 |  |  | $ | 113 |  |  | $ | 26 |  |  | $ | 562 |  |
| Adjusted operating profit | $ | 1,281 |  |  | $ | 230 |  |  | $ | 245 |  |  | $ | (71) |  |  | $ | (79) |  |  | $ | 1,606 |  |
| Adjusted operating margin | 16.3 | % |  | 12.3 | % |  | 13.6 | % |  |  |  |  |  | 14.3 | % |

[0001783180-24-000075:8k_2_02:80]
(1)  Amortization of the step-up to fair value of acquired inventory and backlog.

[0001783180-24-000075:8k_2_02:81]
(2) Gain associated with an adjustment to our tax-related liability owed to UTC.

[0001783180-24-000075:8k_2_02:82]
(3)  The carrying value of our previously held TCC equity investments were recognized at fair value and subsequently adjusted.

[0001783180-24-000075:8k_2_02:83]
11

[0001783180-24-000075:8k_2_02:84]
Carrier Global Corporation

[0001783180-24-000075:8k_2_02:85]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP) Results

[0001783180-24-000075:8k_2_02:86]
Net Income, Earnings Per Share and Effective Tax Rate

[0001783180-24-000075:8k_2_02:87]
|  | (Unaudited) |
|  | Three Months Ended June 30, 2024 |  | Six Months Ended June 30, 2024 |
| (In millions, except per share amounts) | Reported |  | Adjustments |  | Adjusted |  | Reported |  | Adjustments |  | Adjusted |
| Net sales | $ | 6,689 |  |  | $ | — |  |  | $ | 6,689 |  |  | $ | 12,871 |  |  | $ | — |  |  | $ | 12,871 |  |
| Operating profit | $ | 3,691 |  |  | (2,478) |  | a | $ | 1,213 |  |  | $ | 4,191 |  |  | (2,051) |  | a | $ | 2,140 |  |
| Operating margin | 55.2 | % |  |  |  | 18.1 | % |  | 32.6 | % |  |  |  | 16.6 | % |
| Income from operations before income taxes | $ | 3,524 |  |  | (2,466) |  | a,b | $ | 1,058 |  |  | $ | 3,859 |  |  | (2,039) |  | a,b | $ | 1,820 |  |
| Income tax expense | $ | (1,155) |  |  | 922 |  | c | $ | (233) |  |  | $ | (1,201) |  |  | 791 |  | c | $ | (410) |  |
| Effective tax rate | 32.8 | % |  |  |  | 22.0 | % |  | 31.1 | % |  |  |  | 22.5 | % |
| Net income attributable to common shareowners | $ | 2,337 |  |  | $ | (1,544) |  |  | $ | 793 |  |  | $ | 2,606 |  |  | $ | (1,248) |  |  | $ | 1,358 |  |
| Summary of Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring costs |  |  | $ | 32 |  | a |  |  |  |  | $ | 47 |  | a |  |
| Amortization of acquired intangibles |  |  | 170 |  | a |  |  |  |  | 342 |  | a |  |
| Acquisition step-up amortization (1) |  |  | 109 |  | a |  |  |  |  | 220 |  | a |  |
| Acquisition/divestiture-related costs |  |  | 92 |  | a |  |  |  |  | 181 |  | a |  |
| Access Solutions gain |  |  | (2,881) |  | a |  |  |  |  | (2,881) |  | a |  |
| Viessmann-related hedges |  |  | — |  | a |  |  |  |  | 86 |  | a |  |
| Gain on liability adjustment (2) |  |  | — |  | a |  |  |  |  | (46) |  | a |  |
| Debt prepayment costs |  |  | 12 |  | b |  |  |  |  | 12 |  | b |  |
| Total adjustments |  |  | $ | (2,466) |  |  |  |  |  |  | $ | (2,039) |  |  |  |
| Tax effect on adjustments above |  |  | $ | 976 |  |  |  |  |  |  | $ | 880 |  |  |  |
| Tax specific adjustments |  |  | (54) |  |  |  |  |  |  | (89) |  |  |  |
| Total tax adjustments |  |  | $ | 922 |  | c |  |  |  |  | $ | 791 |  | c |  |
| Shares outstanding - Diluted | 915.3 |  |  |  |  | 915.3 |  |  | 913.6 |  |  |  |  | 913.6 |  |
| Earnings per share - Diluted | $ | 2.55 |  |  |  |  | $ | 0.87 |  |  | $ | 2.85 |  |  |  |  | $ | 1.49 |  |

[0001783180-24-000075:8k_2_02:88]
(1)  Amortization of the step-up to fair value of acquired inventory and backlog.

[0001783180-24-000075:8k_2_02:89]
(2) Gain associated with an adjustment to our tax-related liability owed to UTC.

[0001783180-24-000075:8k_2_02:90]
12

[0001783180-24-000075:8k_2_02:91]
Carrier Global Corporation

[0001783180-24-000075:8k_2_02:92]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP) Results

[0001783180-24-000075:8k_2_02:93]
Net Income, Earnings Per Share and Effective Tax Rate

[0001783180-24-000075:8k_2_02:94]
|  | (Unaudited) |
|  | Three Months Ended June 30, 2023 |  | Six Months Ended June 30, 2023 |
| (In millions, except per share amounts) | Reported |  | Adjustments |  | Adjusted |  | Reported |  | Adjustments |  | Adjusted |
| Net sales | $ | 5,992 |  |  | $ | — |  |  | $ | 5,992 |  |  | $ | 11,265 |  |  | $ | — |  |  | $ | 11,265 |  |
| Operating profit | $ | 489 |  |  | 475 |  | a | $ | 964 |  |  | $ | 1,044 |  |  | 562 |  | a | $ | 1,606 |  |
| Operating margin | 8.2 | % |  |  |  | 16.1 | % |  | 9.3 | % |  |  |  | 14.3 | % |
| Income from operations before income taxes | $ | 422 |  |  | 496 |  | a,b | $ | 918 |  |  | $ | 931 |  |  | 583 |  | a,b | $ | 1,514 |  |
| Income tax expense | $ | (189) |  |  | (25) |  | c | $ | (214) |  |  | $ | (311) |  |  | (43) |  | c | $ | (354) |  |
| Effective tax rate | 44.8 | % |  |  |  | 23.3 | % |  | 33.4 | % |  |  |  | 23.4 | % |
| Net income attributable to common shareowners | $ | 199 |  |  | $ | 471 |  |  | $ | 670 |  |  | $ | 572 |  |  | $ | 540 |  |  | $ | 1,112 |  |
| Summary of Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring costs |  |  | $ | 9 |  | a |  |  |  |  | $ | 26 |  | a |  |
| Amortization of acquired intangibles |  |  | 38 |  | a |  |  |  |  | 77 |  | a |  |
| Acquisition step-up amortization (1) |  |  | 10 |  | a |  |  |  |  | 21 |  | a |  |
| Acquisition/divestiture-related costs |  |  | 14 |  | a |  |  |  |  | 26 |  | a |  |
| Viessmann-related hedges |  |  | 111 |  | a |  |  |  |  | 111 |  | a |  |
| TCC acquisition-related gain (2) |  |  | — |  | a |  |  |  |  | 8 |  | a |  |
| KFI deconsolidation |  |  | 293 |  | a |  |  |  |  | 293 |  | a |  |
| Bridge loan financing costs |  |  | 21 |  | b |  |  |  |  | 21 |  | b |  |
| Total adjustments |  |  | $ | 496 |  |  |  |  |  |  | $ | 583 |  |  |  |
| Tax effect on adjustments above |  |  | $ | (25) |  |  |  |  |  |  | $ | (43) |  |  |  |
| Total tax adjustments |  |  | $ | (25) |  | c |  |  |  |  | $ | (43) |  | c |  |
| Shares outstanding - Diluted | 850.9 |  |  |  |  | 850.9 |  |  | 851.5 |  |  |  |  | 851.5 |  |
| Earnings per share - Diluted | $ | 0.23 |  |  |  |  | $ | 0.79 |  |  | $ | 0.67 |  |  |  |  | $ | 1.31 |  |

[0001783180-24-000075:8k_2_02:95]
(1) Amortization of the step-up to fair value of acquired inventory and backlog.

[0001783180-24-000075:8k_2_02:96]
(2) The carrying value of our previously held TCC equity investments were recognized at fair value at the TCC acquisition date.

[0001783180-24-000075:8k_2_02:97]
13

[0001783180-24-000075:8k_2_02:98]
Carrier Global Corporation

[0001783180-24-000075:8k_2_02:99]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP) Results

[0001783180-24-000075:8k_2_02:100]
Components of Changes in Net Sales

[0001783180-24-000075:8k_2_02:101]
| Three Months Ended June 30, 2024 Compared with Three Months Ended June 30, 2023 |
|  | (Unaudited) |
|  | Factors Contributing to Total % change in Net Sales |
|  | Organic |  | FX Translation |  | Acquisitions / Divestitures, net |  | Other |  | Total |
| HVAC | 2 | % |  | (1) | % |  | 17 | % |  | — | % |  | 18 | % |
| Refrigeration | 1 | % |  | (1) | % |  | — | % |  | — | % |  | — | % |
| Fire & Security | 3 | % |  | — | % |  | (10) | % |  | — | % |  | (7) | % |
| Consolidated | 2 | % |  | (1) | % |  | 11 | % |  | — | % |  | 12 | % |

[0001783180-24-000075:8k_2_02:102]
| Six Months Ended June 30, 2024 Compared with Six Months Ended June 30, 2023 |
|  | (Unaudited) |
|  | Factors Contributing to Total % change in Net Sales |
|  | Organic |  | FX Translation |  | Acquisitions / Divestitures, net |  | Other |  | Total |
| HVAC | 2 | % |  | (1) | % |  | 20 | % |  | — | % |  | 21 | % |
| Refrigeration | (1) | % |  | — | % |  | — | % |  | — | % |  | (1) | % |
| Fire & Security | 5 | % |  | — | % |  | (7) | % |  | — | % |  | (2) | % |
| Consolidated | 2 | % |  | (1) | % |  | 13 | % |  | — | % |  | 14 | % |

[0001783180-24-000075:8k_2_02:103]
Historical Amounts of Amortization of Acquired Intangibles

[0001783180-24-000075:8k_2_02:104]
|  |  | (Unaudited) |  |  |
|  |  | Q1 |  | Q2 |  | Q3 |  | Q4 |  | FY |  | Q1 |  | Q2 |  |  |
| (In millions) |  | 2023 |  | 2023 |  | 2023 |  | 2023 |  | 2023 |  | 2024 |  | 2024 |  |  |
| HVAC |  | $ | 37 |  |  | $ | 36 |  |  | $ | 35 |  |  | $ | 35 |  |  | $ | 143 |  |  | $ | 172 |  |  | $ | 170 |  |  |  |
| Fire & Security |  | 2 |  |  | 2 |  |  | 2 |  |  | — |  |  | 6 |  |  | — |  |  | — |  |  |  |
| Total Carrier |  | 39 |  |  | 38 |  |  | 37 |  |  | 35 |  | 149 |  |  | 172 |  |  | 170 |  |  |  |
| Associated tax effect |  | (12) |  |  | (11) |  |  | (11) |  |  | (11) |  |  | (45) |  |  | (46) |  |  | (42) |  |  |  |
| Net impact to adjusted results |  | $ | 27 |  |  | $ | 27 |  |  | $ | 26 |  |  | $ | 24 |  |  | $ | 104 |  |  | $ | 126 |  |  | $ | 128 |  |  |  |

[0001783180-24-000075:8k_2_02:105]
Free Cash Flow Reconciliation

[0001783180-24-000075:8k_2_02:106]
|  |  | (Unaudited) |
|  |  | Q1 |  | Q2 |  | Q3 |  | Q4 |  | FY |  | Q1 |  | Q2 |  |  |
| (In millions) |  | 2023 |  | 2023 |  | 2023 |  | 2023 |  | 2023 |  | 2024 |  | 2024 |  |  |
| Net cash flows provided by (used in) operating activities |  | $ | 120 |  |  | $ | 384 |  |  | $ | 1,041 |  |  | $ | 1,062 |  |  | $ | 2,607 |  |  | $ | 40 |  |  | $ | 660 |  |  |  |
| Less: Capital expenditures |  | 70 |  |  | 74 |  |  | 92 |  |  | 233 |  | 469 |  |  | 104 |  |  | 111 |  |  |  |
| Free cash flow |  | $ | 50 |  |  | $ | 310 |  |  | $ | 949 |  |  | $ | 829 |  |  | $ | 2,138 |  |  | $ | (64) |  |  | $ | 549 |  |  |  |

[0001783180-24-000075:8k_2_02:107]
14

[0001783180-24-000075:8k_2_02:108]
Net Debt Reconciliation

[0001783180-24-000075:8k_2_02:109]
|  |  | (Unaudited) |
| (In millions) |  | June 30, 2024 |  | December 31, 2023 |
| Long-term debt |  | $ | 11,270 |  |  | $ | 14,242 |  |
| Current portion of long-term debt |  | 2,052 |  |  | 51 |  |
| Less: Cash and cash equivalents |  | 2,919 |  |  | 10,015 |  |
| Net debt |  | $ | 10,403 |  |  | $ | 4,278 |  |

[0001783180-24-000075:8k_2_02:110]
15
