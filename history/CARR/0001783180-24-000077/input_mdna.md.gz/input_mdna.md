# CARR MD&A — 0001783180-24-000077


## mdna

[0001783180-24-000077:mdna:1]
[same as prior period, unchanged from 0001783180-24-000044:mdna:1]

[0001783180-24-000077:mdna:2]
[same as prior period, unchanged from 0001783180-24-000044:mdna:2]

[0001783180-24-000077:mdna:3]
[same as prior period, unchanged from 0001783180-24-000044:mdna:3]

[0001783180-24-000077:mdna:4]
Carrier Global Corporation ("we" or "our") is a global leader in intelligent climate and energy solutions with a focus on providing differentiated, digitally-enabled lifecycle solutions to our customers. Our portfolio includes industry-leading brands such as Carrier, Viessmann, Toshiba, Automated Logic, Carrier Transicold, Kidde and Edwards that offer innovative heating, ventilating and air conditioning ("HVAC"), refrigeration, fire and building automation technologies to help make the world safer and more comfortable. We also provide a broad array of related building services, including audit, design, installation, system integration, repair, maintenance and monitoring. Our operations are classified into three segments: HVAC, Refrigeration and Fire & Security.

[0001783180-24-000077:mdna:5]
[same as prior period, unchanged from 0001783180-24-000044:mdna:5]

[0001783180-24-000077:mdna:6]
[same as prior period, unchanged from 0001783180-24-000044:mdna:6]

[0001783180-24-000077:mdna:7]
[same as prior period, unchanged from 0001783180-24-000044:mdna:7]

[0001783180-24-000077:mdna:8]
[same as prior period, unchanged from 0001783180-24-000044:mdna:8]

[0001783180-24-000077:mdna:9]
[same as prior period, unchanged from 0001783180-24-000044:mdna:9]

[0001783180-24-000077:mdna:10]
[same as prior period, unchanged from 0001783180-24-000044:mdna:10]

[0001783180-24-000077:mdna:11]
On June 2, 2024, we completed the sale of our Access Solutions business ("Access Solutions") to Honeywell International Inc. ("Honeywell") for cash proceeds of $5.0 billion. Access Solutions, historically reported in our Fire & Security segment, is a global supplier of physical security and digital access solutions supporting the hospitality, commercial, education and military markets. We recognized a gain on the sale of $2.9 billion, which is included in Other income (expense), net on the accompanying Unaudited Condensed Consolidated Statement of Operations. The net proceeds received are subject to working capital and other adjustments provided in the stock purchase agreement.

[0001783180-24-000077:mdna:12]
On December 12, 2023, we entered into a stock purchase agreement to sell our Commercial Refrigeration business ("CCR") to Haier Group Corporation for an enterprise value of approximately $775 million. CCR, historically reported in our Refrigeration segment, is a global supplier of turnkey solutions for commercial refrigeration systems and services, with a primary focus on serving food retail customers, cold storage facilities and warehouses. The transaction is expected to close in 2024.

[0001783180-24-000077:mdna:13]
On March 5, 2024, we entered into a stock purchase agreement to sell our Industrial Fire business ("Industrial Fire") to Sentinel Capital Partners for an enterprise value of approximately $1.425 billion. Industrial Fire, historically reported in our Fire & Security segment, is a leading manufacturer of a full spectrum of fire detection and suppression solutions and services in critical high-hazard environments, including oil and gas, power generation, marine and offshore facilities, automotive, data centers and aircraft hangars. The sale of Industrial Fire was completed on July 1, 2024.

[0001783180-24-000077:mdna:14]
The following table summarizes Net sales for each of our businesses included in our portfolio transformation:

[0001783180-24-000077:mdna:15]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |  | Year Ended December 31, |
| (In millions) |  | 2024 |  | 2023 |  | 2024 |  | 2023 |  | 2023 |
| Access Solutions |  | $ | 112 |  |  | $ | 181 |  |  | $ | 282 |  |  | $ | 356 |  |  | $ | 716 |  |
| Industrial Fire |  | 143 |  |  | 134 |  |  | 287 |  |  | 251 |  |  | 520 |  |
| Commercial and Residential Fire |  | 495 |  |  | 471 |  |  | 937 |  |  | 886 |  |  | 1,827 |  |
| Commercial Refrigeration |  | 254 |  |  | 269 |  |  | 495 |  |  | 513 |  |  | 1,074 |  |

[0001783180-24-000077:mdna:16]
The announced plan to exit our Fire & Security segment represents a single disposal plan to separately divest multiple businesses. As such, at the time that the remaining significant business in the segment, Commercial and Residential Fire, qualifies as held for sale, the Fire & Security segment in aggregate will likely be presented in discontinued operations. We expect this to occur in 2024.

[0001783180-24-000077:mdna:17]
[same as prior period, unchanged from 0001783180-24-000044:mdna:13]

[0001783180-24-000077:mdna:18]
On May 14, 2023, Kidde-Fenwal, Inc. ("KFI"), an indirect wholly-owned subsidiary of ours, filed a petition for voluntary reorganization under Chapter 11 of the United States Bankruptcy Code ("Chapter 11") in the United States Bankruptcy Court for the District of Delaware. KFI, an industrial fire detection and suppression business historically reported in our Fire & Security segment, indicated that it intended to use the bankruptcy process to explore strategic alternatives, including the sale of KFI as a going concern. As of the petition date, KFI was deconsolidated and its respective assets and liabilities were derecognized from our Unaudited Condensed Consolidated Financial Statements.

[0001783180-24-000077:mdna:19]
[same as prior period, unchanged from 0001783180-24-000044:mdna:15]

[0001783180-24-000077:mdna:20]
[same as prior period, unchanged from 0001783180-24-000044:mdna:16]

[0001783180-24-000077:mdna:21]
[same as prior period, unchanged from 0001783180-24-000044:mdna:17]

[0001783180-24-000077:mdna:22]
[same as prior period, unchanged from 0001783180-24-000044:mdna:18]

[0001783180-24-000077:mdna:23]
[same as prior period, unchanged from 0001783180-24-000044:mdna:19]

[0001783180-24-000077:mdna:24]
Due to the sale of Access Solutions, we no longer consolidate the results of Access Solutions in our financial statements as of June 2, 2024. Therefore, this Management's Discussion and Analysis of Financial Condition and Results of Operations only

[0001783180-24-000077:mdna:25]
34

[0001783180-24-000077:mdna:26]
includes the financial results of Access Solutions in periods prior to the date of the sale. As a result, prior periods may not be comparable to the current period.

[0001783180-24-000077:mdna:27]
Three Months Ended June 30, 2024 Compared with the Three Months Ended June 30, 2023

[0001783180-24-000077:mdna:28]
[same as prior period, unchanged from 0001783180-24-000044:mdna:21]

[0001783180-24-000077:mdna:29]
|  |  | Three Months Ended June 30, |
| (In millions) |  | 2024 |  | 2023 |  | Period Change |  | % Change |
| Net sales |  | $ | 6,689 |  |  | $ | 5,992 |  |  | $ | 697 |  |  | 12 | % |
| Cost of products and services sold |  | (4,811) |  |  | (4,237) |  |  | (574) |  |  | 14 | % |
| Gross margin |  | 1,878 |  |  | 1,755 |  |  | 123 |  |  | 7 | % |
| Operating expenses |  | 1,813 |  |  | (1,266) |  |  | 3,079 |  |  | (243) | % |
| Operating profit |  | 3,691 |  |  | 489 |  |  | 3,202 |  |  | 655 | % |
| Non-operating income (expense), net |  | (167) |  |  | (67) |  |  | (100) |  |  | 149 | % |
| Income from operations before income taxes |  | 3,524 |  |  | 422 |  |  | 3,102 |  |  | 735 | % |
| Income tax expense |  | (1,155) |  |  | (189) |  |  | (966) |  |  | 511 | % |
| Net income from operations |  | 2,369 |  |  | 233 |  |  | 2,136 |  |  | 917 | % |
| Less: Non-controlling interest in subsidiaries' earnings from operations |  | 32 |  |  | 34 |  |  | (2) |  |  | (6) | % |
| Net income attributable to common shareowners |  | $ | 2,337 |  |  | $ | 199 |  |  | $ | 2,138 |  |  | 1,074 | % |

[0001783180-24-000077:mdna:30]
[same as prior period, unchanged from 0001783180-24-000044:mdna:23]

[0001783180-24-000077:mdna:31]
For the three months ended June 30, 2024, Net sales were $6.7 billion, a 12% increase compared with the same period of 2023. The components of the year-over-year change were as follows:

[0001783180-24-000077:mdna:32]
|  |  | Three Months Ended June 30, 2024 |
| Organic |  | 2 | % |
| Foreign currency translation |  | (1) | % |
| Acquisitions and divestitures, net |  | 11 | % |
| Total % change |  | 12 | % |

[0001783180-24-000077:mdna:33]
Organic sales for the three months ended June 30, 2024, increased by 2% compared with the same period of 2023. The organic increase was primarily driven by our HVAC segment due to improved end-markets in the Americas and EMEA, which more than offset reduced end-market demand in Asia. In addition, our Fire & Security segment benefited from volume growth and price improvements in both the Commercial and Residential fire and Industrial fire businesses. Results in our Refrigeration segment were mixed as growth in Transport refrigeration was partially offset by challenges in Commercial refrigeration end-markets. Refer to "Segment Review" below for a discussion of Net sales by segment.

[0001783180-24-000077:mdna:34]
35

[0001783180-24-000077:mdna:35]
[same as prior period, unchanged from 0001783180-24-000044:mdna:29]

[0001783180-24-000077:mdna:36]
For the three months ended June 30, 2024, gross margin was $1.9 billion, a 7% increase compared with the same period of 2023. The components were as follows:

[0001783180-24-000077:mdna:37]
|  |  | Three Months Ended June 30, |
| (In millions) |  | 2024 |  | 2023 |
| Net sales |  | $ | 6,689 |  |  | $ | 5,992 |  |
| Cost of products and services sold |  | (4,811) |  |  | (4,237) |  |
| Gross margin |  | $ | 1,878 |  |  | $ | 1,755 |  |
| Percentage of net sales |  | 28.1 | % |  | 29.3 | % |

[0001783180-24-000077:mdna:38]
Gross margin increased by $123 million compared with the three months ended June 30, 2023. The main driver of the increase related to ongoing customer demand, pricing improvements and our continued focus on productivity initiatives. Operating results associated with the VCS Business since the date of acquisition further benefited gross margin during the period. However, the results of the VCS Business included inventory step-up, backlog amortization and intangible asset amortization resulting from the recognition of acquired assets at fair value. These costs had a 300 basis point unfavorable impact on gross margin as a percentage of Net sales. As a result, gross margin as a percentage of Net sales decreased by 120 basis points compared with the same period of 2023.

[0001783180-24-000077:mdna:39]
[same as prior period, unchanged from 0001783180-24-000044:mdna:33]

[0001783180-24-000077:mdna:40]
For the three months ended June 30, 2024, operating expenses, including Equity method investment net earnings, were a benefit of $1.8 billion, a 243% decrease compared with the same period of 2023. The components were as follows:

[0001783180-24-000077:mdna:41]
|  |  | Three Months Ended June 30, |
| (In millions) |  | 2024 |  | 2023 |
| Selling, general and administrative |  | $ | (975) |  |  | $ | (784) |  |
| Research and development |  | (187) |  |  | (151) |  |
| Equity method investment net earnings |  | 90 |  |  | 52 |  |
| Other income (expense), net |  | 2,885 |  |  | (383) |  |
| Total operating expenses |  | $ | 1,813 |  |  | $ | (1,266) |  |
| Percentage of net sales |  | (27.1) | % |  | 21.1 | % |

[0001783180-24-000077:mdna:42]
For the three months ended June 30, 2024, Selling, general and administrative expenses were $975 million, a 24% increase compared with the same period of 2023. The increase is primarily due to incremental expenses associated with the VCS Business since the date of acquisition. In addition, the current period also included $92 million of acquisition and divestiture-related costs compared with $14 million during the three months ended June 30, 2023.

[0001783180-24-000077:mdna:43]
[same as prior period, unchanged from 0001783180-24-000044:mdna:37]

[0001783180-24-000077:mdna:44]
Investments over which we do not exercise control, but have significant influence, are accounted for using the equity method of accounting. For the three months ended June 30, 2024, Equity method investment net earnings were $90 million, a 73% increase compared with the same period of 2023. The increase was primarily driven by higher earnings in HVAC joint ventures across all regions.

[0001783180-24-000077:mdna:45]
Other income (expense), net primarily includes the impact of gains and losses related to the sale of businesses or interests in our equity method investments, foreign currency gains and losses on transactions that are denominated in a currency other than an entity's functional currency and hedging-related activities. During the three months ended June 30, 2024, we completed the sale of Access Solutions and recognized a gain on the sale of $2.9 billion.

[0001783180-24-000077:mdna:46]
During the three months ended June 30, 2023, we recognized a loss of $293 million on the deconsolidation of KFI due to its Chapter 11 filing. In addition, we recognized a $111 million loss on the mark-to-market valuation of our window forward contracts associated with the expected cash outflows of the Euro-denominated purchase price of the VCS Business.

[0001783180-24-000077:mdna:47]
[same as prior period, unchanged from 0001783180-24-000044:mdna:40]

[0001783180-24-000077:mdna:48]
For the three months ended June 30, 2024, Non-operating income (expense), net was $167 million, a 149% increase compared with the same period of 2023. The components were as follows:

[0001783180-24-000077:mdna:49]
|  |  | Three Months Ended June 30, |
| (In millions) |  | 2024 |  | 2023 |
| Non-service pension (expense) benefit |  | $ | (1) |  |  | $ | — |  |
| Interest expense |  | $ | (185) |  |  | $ | (94) |  |
| Interest income |  | 19 |  |  | 27 |  |
| Interest (expense) income, net |  | $ | (166) |  |  | $ | (67) |  |
| Non-operating income (expense), net |  | $ | (167) |  |  | $ | (67) |  |

[0001783180-24-000077:mdna:50]
Non-operating income (expense), net includes the results from activities other than normal business operations such as interest expense, interest income and the non-service components of pension and post-retirement obligations. Interest expense is affected by the amount of debt outstanding and the interest rates on that debt. For the three months ended June 30, 2024, Interest expense was $185 million, a 97% increase compared with the same period of 2023. In connection with the acquisition of the VCS Business, we entered into several financing arrangements to fund the cash portion of the Euro-denominated purchase price. In addition, we incurred a make-whole premium of $8 million and wrote off $4 million of unamortized deferred financing costs associated with the redemption of our $1.0 billion aggregate principal amount of 5.80% notes due in 2025. During the three months ended June 30, 2023, we amortized $21 million of deferred financing cost in Interest expense, of which $19 million related to our senior unsecured bridge term loan facility (the "Bridge Loan").

[0001783180-24-000077:mdna:51]
[same as prior period, unchanged from 0001783180-24-000044:mdna:44]

[0001783180-24-000077:mdna:52]
|  |  | Three Months Ended June 30, |
|  |  | 2024 |  | 2023 |
| Effective tax rate |  | 32.8 | % |  | 44.8 | % |

[0001783180-24-000077:mdna:53]
We account for income tax expense in accordance with ASC 740, which requires an estimate of the annual effective income tax rate for the full year to be applied to the respective interim period, taking into account year-to-date amounts and projected results for the full year. The effective tax rate was 32.8% for the three months ended June 30, 2024, compared with 44.8% for the three months ended June 30, 2023. The year-over-year decrease was primarily driven by the absence of the non-deductible loss of $293 million on the deconsolidation of KFI due to its Chapter 11 filing and the $111 million loss on the mark-to-market valuation of our window forward contracts associated with the expected cash outflows of the Euro-denominated purchase price of the VCS Business recognized during the three months ended June 30, 2023. These amounts were partially offset by the $1.1 billion tax on the $2.9 billion gain on the sale of Access Solutions and a held-for-sale tax benefit of $43 million related to adjustments to basis differences in certain companies recognized during the three months ended June 30, 2024.

[0001783180-24-000077:mdna:54]
37

[0001783180-24-000077:mdna:55]
Six Months Ended June 30, 2024 Compared with the Six Months Ended June 30, 2023

[0001783180-24-000077:mdna:56]
The following represents our consolidated net sales and operating results:

[0001783180-24-000077:mdna:57]
|  |  | Six Months Ended June 30, |
| (In millions) |  | 2024 |  | 2023 |  | Period Change |  | % Change |
| Net sales |  | $ | 12,871 |  |  | $ | 11,265 |  |  | $ | 1,606 |  |  | 14 | % |
| Cost of products and services sold |  | (9,288) |  |  | (8,132) |  |  | (1,156) |  |  | 14 | % |
| Gross margin |  | 3,583 |  |  | 3,133 |  |  | 450 |  |  | 14 | % |
| Operating expenses |  | 608 |  |  | (2,089) |  |  | 2,697 |  |  | (129) | % |
| Operating profit |  | 4,191 |  |  | 1,044 |  |  | 3,147 |  |  | 301 | % |
| Non-operating income (expense), net |  | (332) |  |  | (113) |  |  | (219) |  |  | 194 | % |
| Income from operations before income taxes |  | 3,859 |  |  | 931 |  |  | 2,928 |  |  | 315 | % |
| Income tax expense |  | (1,201) |  |  | (311) |  |  | (890) |  |  | 286 | % |
| Net income from operations |  | 2,658 |  |  | 620 |  |  | 2,038 |  |  | 329 | % |
| Less: Non-controlling interest in subsidiaries' earnings from operations |  | 52 |  |  | 48 |  |  | 4 |  |  | 8 | % |
| Net income attributable to common shareowners |  | $ | 2,606 |  |  | $ | 572 |  |  | $ | 2,034 |  |  | 356 | % |

[0001783180-24-000077:mdna:58]
Net Sales

[0001783180-24-000077:mdna:59]
For the six months ended June 30, 2024, Net sales were $12.9 billion, a 14% increase compared with the same period of 2023. The components of the year-over-year change were as follows:

[0001783180-24-000077:mdna:60]
|  |  | Six Months Ended June 30, 2024 |
| Organic |  | 2 | % |
| Foreign currency translation |  | (1) | % |
| Acquisitions and divestitures, net |  | 13 | % |
| Total % change |  | 14 | % |

[0001783180-24-000077:mdna:61]
Organic sales for the six months ended June 30, 2024 increased by 2% compared with the same period of 2023. The organic increase was primarily driven by our HVAC segment due to improved end-markets in the Americas, which more than offset reduced end-markets in EMEA and Asia. In addition, our Fire & Security segment benefited from volume growth and price improvements in both the Commercial and Residential fire and Industrial fire businesses. Refrigeration results decreased as each of the segment's businesses experienced challenges in certain end-markets. Refer to "Segment Review" below for a discussion of Net sales by segment.

[0001783180-24-000077:mdna:62]
Gross Margin

[0001783180-24-000077:mdna:63]
For the six months ended June 30, 2024, gross margin was $3.6 billion, a 14% increase compared with the same period of 2023. The components were as follows:

[0001783180-24-000077:mdna:64]
|  |  | Six Months Ended June 30, |  |  |  |  |
| (In millions) |  | 2024 |  | 2023 |  |  |  |  |
| Net sales |  | $ | 12,871 |  |  | $ | 11,265 |  |  |  |  |  |
| Cost of products and services sold |  | (9,288) |  |  | (8,132) |  |  |  |  |  |
| Gross margin |  | $ | 3,583 |  |  | $ | 3,133 |  |  |  |  |  |
| Percentage of net sales |  | 27.8 | % |  | 27.8 | % |  |  |  |  |

[0001783180-24-000077:mdna:65]
Gross margin increased by $450 million compared with the six months ended June 30, 2023. The main driver of the increase related to ongoing customer demand, pricing improvements and our continued focus on productivity initiatives. Operating results associated with the VCS Business since the date of acquisition further benefited gross margin during the period. However, the results of the VCS Business included inventory step-up, backlog amortization and intangible asset amortization resulting from the recognition of acquired assets at fair value. These costs had a 260 basis point unfavorable impact on gross margin as a percentage of Net sales. As a result, gross margin as a percentage of Net sales was flat compared with the same period of 2023.

[0001783180-24-000077:mdna:66]
Operating Expenses

[0001783180-24-000077:mdna:67]
For the six months ended June 30, 2024, operating expenses, including Equity method investment net earnings, were a benefit of $0.6 billion, a 129% decrease compared with the same period of 2023. The components were as follows:

[0001783180-24-000077:mdna:68]
|  |  | Six Months Ended June 30, |
| (In millions) |  | 2024 |  | 2023 |
| Selling, general and administrative |  | $ | (1,960) |  |  | $ | (1,505) |  |
| Research and development |  | (411) |  |  | (290) |  |
| Equity method investment net earnings |  | 121 |  |  | 96 |  |
| Other income (expense), net |  | 2,858 |  |  | (390) |  |
| Total operating expenses |  | $ | 608 |  |  | $ | (2,089) |  |
| Percentage of net sales |  | (4.7) | % |  | 18.5 | % |

[0001783180-24-000077:mdna:69]
For the six months ended June 30, 2024, Selling, general and administrative expenses were $2.0 billion, a 30% increase compared with the same period of 2023. The increase is primarily due to incremental expenses associated with the VCS Business since the date of acquisition. In addition, higher compensation and other employee-related costs further contributed to the increase. The current period also included $181 million of acquisition and divestiture-related costs compared with $26 million during the six months ended June 30, 2023.

[0001783180-24-000077:mdna:70]
Research and development costs relate to new product development and new technology innovation. Due to the variable nature of program development schedules, year-over-year spending levels can fluctuate. In addition, we continue to invest to prepare for future energy efficiency and refrigerant regulation changes and in digital controls technologies.

[0001783180-24-000077:mdna:71]
Investments over which we do not exercise control, but have significant influence, are accounted for using the equity method of accounting. For the six months ended June 30, 2024, Equity method investment net earnings were $121 million, a 26% increase compared with the same period of 2023. The increase was primarily driven by higher earnings in HVAC joint ventures across all regions. The increase was partially offset by a $23 million charge associated with the devaluation of U.S. Dollar denominated balances at an HVAC equity investment in Egypt.

[0001783180-24-000077:mdna:72]
Other income (expense), net primarily includes the impact of gains and losses related to the sale of businesses or interests in our equity method investments, foreign currency gains and losses on transactions that are denominated in a currency other than an entity's functional currency and hedging-related activities. During the six months ended June 30, 2024, we completed the sale of Access Solutions and recognized a gain on the sale of $2.9 billion. In addition, we recognized a $46 million gain associated with our share of United Technologies Corporation's conclusion of certain income tax matters from their 2017 and 2018 tax audit with the Internal Revenue Service ("IRS"). In connection with the acquisition of the VCS Business, we recognized an $86 million loss on the mark-to-market valuation of our window forward contracts associated with the cash outflows of the Euro-denominated purchase price.

[0001783180-24-000077:mdna:73]
During the six months ended June 30, 2023, we recognized a loss of $293 million on the deconsolidation of KFI due to its Chapter 11 filing. In addition, we recognized a $111 million loss on the mark-to-market valuation of our window forward contracts associated with the expected cash outflows of the Euro-denominated purchase price of the VCS Business.

[0001783180-24-000077:mdna:74]
Non-Operating Income (Expense), net

[0001783180-24-000077:mdna:75]
For the six months ended June 30, 2024, Non-operating income (expense), net was $332 million, a 194% increase compared with the same period of 2023. The components were as follows:

[0001783180-24-000077:mdna:76]
|  |  | Six Months Ended June 30, |
| (In millions) |  | 2024 |  | 2023 |
| Non-service pension (expense) benefit |  | $ | (1) |  |  | $ | — |  |
| Interest expense |  | $ | (365) |  |  | $ | (165) |  |
| Interest income |  | 34 |  |  | 52 |  |
| Interest (expense) income, net |  | $ | (331) |  |  | $ | (113) |  |
| Non-operating income (expense), net |  | $ | (332) |  |  | $ | (113) |  |

[0001783180-24-000077:mdna:77]
Non-operating income (expense), net includes the results from activities other than normal business operations such as interest expense, interest income and the non-service components of pension and post-retirement obligations. Interest expense is affected by the amount of debt outstanding and the interest rates on that debt. For the six months ended June 30, 2024, Interest expense was $365 million, a 121% increase compared with the same period of 2023. In connection with the acquisition of the VCS Business, we entered into several financing arrangements to fund the Euro-denominated purchase price. In addition, we incurred a make-whole premium of $8 million and wrote off $4 million of unamortized deferred financing costs associated with the redemption of our $1.0 billion aggregate principal amount of 5.80% notes due in 2025. During the six months ended June 30, 2023, we amortized $22 million of deferred financing cost in Interest expense, of which $19 million related to our Bridge Loan.

[0001783180-24-000077:mdna:78]
[same as prior period, unchanged from 0001783180-24-000044:mdna:97]

[0001783180-24-000077:mdna:79]
Income Taxes

[0001783180-24-000077:mdna:80]
|  |  | Six Months Ended June 30, |  |  |
|  |  | 2024 |  | 2023 |  |  |  |  |
| Effective tax rate |  | 31.1 | % |  | 33.4 | % |  |  |  |  |

[0001783180-24-000077:mdna:81]
We account for income tax expense in accordance with ASC 740, which requires an estimate of the annual effective income tax rate for the full year to be applied to the respective interim period, taking into account year-to-date amounts and projected results for the full year. The effective tax rate was 31.1% for the six months ended June 30, 2024 compared with 33.4% for the six months ended June 30, 2023. The year-over-year decrease was primarily driven by the absence of the non-deductible loss of $293 million on the deconsolidation of KFI due to its Chapter 11 filing recognized during the six months ended June 30, 2023. This amount was partially offset by the $1.1 billion tax on the $2.9 billion gain on the sale of Access Solutions and a held-for-sale tax benefit of $62 million related to adjustments to basis differences in certain companies recognized during the six months ended June 30, 2024. In addition, we recognized a tax benefit of $21 million associated with the TMA and UTC's conclusion of certain income tax matters from their 2017 and 2018 tax audit with the U.S. Internal Revenue Service ("IRS"), a net tax benefit of $16 million related to the re-organization and disentanglement of certain Fire & Security industrial businesses in advance of their planned divestitures and a tax charge of $15 million related to a reduction of utilizable foreign tax credits during the six months ended June 30, 2024.

[0001783180-24-000077:mdna:82]
[same as prior period, unchanged from 0001783180-24-000044:mdna:47]

[0001783180-24-000077:mdna:83]
[same as prior period, unchanged from 0001783180-24-000044:mdna:48]

[0001783180-24-000077:mdna:84]
[same as prior period, unchanged from 0001783180-24-000044:mdna:49]

[0001783180-24-000077:mdna:85]
[same as prior period, unchanged from 0001783180-24-000044:mdna:50]

[0001783180-24-000077:mdna:86]
[same as prior period, unchanged from 0001783180-24-000044:mdna:51]

[0001783180-24-000077:mdna:87]
[same as prior period, unchanged from 0001783180-24-000044:mdna:52]

[0001783180-24-000077:mdna:88]
Three Months Ended June 30, 2024 Compared with Three Months Ended June 30, 2023

[0001783180-24-000077:mdna:89]
[same as prior period, unchanged from 0001783180-24-000044:mdna:54]

[0001783180-24-000077:mdna:90]
|  |  | Net Sales |  | Operating Profit |  | Operating Profit Margin |
|  |  | Three Months Ended June 30, |  | Three Months Ended June 30, |  | Three Months Ended June 30, |
| (In millions) |  | 2024 |  | 2023 |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| HVAC |  | $ | 4,970 |  |  | $ | 4,216 |  |  | $ | 687 |  |  | $ | 742 |  |  | 13.8 | % |  | 17.6 | % |
| Refrigeration |  | 973 |  |  | 972 |  |  | 113 |  |  | 112 |  |  | 11.6 | % |  | 11.5 | % |
| Fire & Security |  | 871 |  |  | 932 |  |  | 3,001 |  |  | (157) |  |  | 344.5 | % |  | (16.8) | % |
| Total segment |  | $ | 6,814 |  |  | $ | 6,120 |  |  | $ | 3,801 |  |  | $ | 697 |  |  | 55.8 | % |  | 11.4 | % |

[0001783180-24-000077:mdna:91]
[same as prior period, unchanged from 0001783180-24-000044:mdna:56]

[0001783180-24-000077:mdna:92]
For the three months ended June 30, 2024, Net sales in our HVAC segment were $5.0 billion, a 18% increase compared with the same period of 2023. The components of the year-over-year change were as follows:

[0001783180-24-000077:mdna:93]
|  |  | Net Sales |
| Organic |  | 2 | % |
| Foreign currency translation |  | (1) | % |
| Acquisitions and divestitures, net |  | 17 | % |
| Total % change in Net sales |  | 18 | % |

[0001783180-24-000077:mdna:94]
The organic increase in Net sales of 2% was driven by continued strong results in the segment. Growth in the Americas (up 5%) was primarily driven by our Commercial and Light Commercial businesses which benefited from ongoing customer demand and pricing improvements. In addition, volume increases in residential markets further benefited results. Growth in EMEA (up 2%) was primarily driven by ongoing customer demand and pricing improvements in our Commercial business. Residential markets continue to be impacted by reduced volume compared with the prior year. Results in Asia (down 7%) were impacted by lower demand in the region, primarily in China.

[0001783180-24-000077:mdna:95]
On January 2, 2024, we acquired the VCS Business, a leading manufacturer of high efficiency heating and renewable energy systems in Europe. The results of the VCS Business have been included in our Unaudited Condensed Consolidated Financial Statements since the date of acquisition. The transaction added 17% to Net sales during the three months ended June 30, 2024 and is included in Acquisitions and divestitures, net.

[0001783180-24-000077:mdna:96]
For the three months ended June 30, 2024, Operating profit in our HVAC segment was $687 million, a 7% decrease compared with the same period of 2023. The components of the year-over-year change were as follows:

[0001783180-24-000077:mdna:97]
|  |  | Operating Profit |
| Operational |  | 16 | % |
| Acquisitions and divestitures, net |  | (2) | % |
| Restructuring |  | (3) | % |
| Amortization of acquired intangibles |  | (18) | % |
| Total % change in Operating profit |  | (7) | % |

[0001783180-24-000077:mdna:98]
The operational profit increase of 16% was primarily attributable to ongoing customer demand and pricing improvements in certain end-markets compared with the prior year. In addition, favorable material and logistics costs drove productivity benefits in the segment. These benefits more than offset volume reductions in certain end-markets. Higher earnings from equity method investments further benefited operational profit in the segment.

[0001783180-24-000077:mdna:99]
[same as prior period, unchanged from 0001783180-24-000044:mdna:64]

[0001783180-24-000077:mdna:100]
For the three months ended June 30, 2024, Net sales in our Refrigeration segment were $973 million, flat compared to the same period of 2023. The components of the year-over-year change were as follows:

[0001783180-24-000077:mdna:101]
|  |  | Net Sales |
| Organic |  | 1 | % |
| Foreign currency translation |  | (1) | % |
| Total % change in Net sales |  | — | % |

[0001783180-24-000077:mdna:102]
42

[0001783180-24-000077:mdna:103]
The organic increase in Net Sales of 1% was primarily driven by volume growth and price improvements within certain end-markets compared with the prior year. Transport refrigeration results increased (up 3%) compared to the prior year primarily due to strong container end-markets. In addition, higher volumes in Europe and Asia further benefited results but were more than offset by lower end-market demand in North America. Results for Commercial refrigeration decreased (down 5%) compared with the prior year, primarily driven by lower volumes in Europe as economic conditions and inflationary cost pressures impacted end-market demand. In addition, Asia was impacted by reduced end-market demand in China.

[0001783180-24-000077:mdna:104]
For the three months ended June 30, 2024, Operating profit in our Refrigeration segment was $113 million, a 1% increase compared with the same period of 2023. The components of the year-over-year change were as follows:

[0001783180-24-000077:mdna:105]
|  |  | Operating Profit |
| Operational |  | 1 | % |
| Foreign currency translation |  | (1) | % |
| Restructuring |  | 5 | % |
| Other |  | (4) | % |
| Total % change in Operating profit |  | 1 | % |

[0001783180-24-000077:mdna:106]
The increase in operational profit of 1% was primarily driven by favorable productivity initiatives and price improvements compared with the prior year. In addition, volume growth in certain end-markets further benefited the segment. These amounts were partially offset by volume reductions in certain other end-markets. Inflationary cost pressures are moderating but continue to impact our operating profit. Amounts reported in Other represent $4 million of divestiture-related costs associated with the announced sale of CCR.

[0001783180-24-000077:mdna:107]
[same as prior period, unchanged from 0001783180-24-000044:mdna:71]

[0001783180-24-000077:mdna:108]
For the three months ended June 30, 2024, Net sales in our Fire & Security segment were $871 million, a 7% decrease compared with the same period of 2023. The components of the year-over-year change were as follows:

[0001783180-24-000077:mdna:109]
|  |  | Net Sales |
| Organic |  | 3 | % |
| Acquisitions and divestitures, net |  | (8) | % |
| KFI deconsolidation |  | (2) | % |
| Total % change in Net sales |  | (7) | % |

[0001783180-24-000077:mdna:110]
The organic increase in Net sales of 3% was primarily driven by volume growth and price improvements compared with the prior year. Increased sales in our Commercial and Residential fire business benefited from ongoing customer demand and price improvements in the Americas and Europe. Growth in our Global Industrial business was driven by strong end-market demand and pricing improvements. Acquisitions and divestitures, net primarily relates to the current year results of Access Solutions, the sale of which was completed on June 2, 2024.

[0001783180-24-000077:mdna:111]
43

[0001783180-24-000077:mdna:112]
For the three months ended June 30, 2024, Operating profit in our Fire & Security segment was $3.0 billion, a 2,011% increase compared with the same period of 2023. The components of the year-over-year change were as follows:

[0001783180-24-000077:mdna:113]
|  |  | Operating Profit |
| Operational |  | 31 | % |
| Foreign currency translation |  | (1) | % |
| Acquisitions and divestitures, net |  | (17) | % |
| Restructuring |  | (3) | % |
| KFI deconsolidation |  | 184 | % |
| Access Solutions gain |  | 1,834 | % |
| Amortization of acquired intangibles |  | 1 | % |
| Other |  | (18) | % |
| Total % change in Operating profit |  | 2,011 | % |

[0001783180-24-000077:mdna:114]
The increase in operational profit of 31% was primarily driven by volume growth, price improvements and favorable product mix compared with the prior year. In addition, favorable material and logistics costs drove productivity benefits during the period. The segment also benefited from lower inventory-related reserves compared with the prior year as supply chain challenges improved. Lower depreciation and amortization, which was ceased on held-for-sale assets in accordance with ASC 360, Property, Plant and Equipment, further benefited operational profit. These amounts were partially offset by lower volumes in certain end-markets.

[0001783180-24-000077:mdna:115]
Acquisitions and divestitures, net primarily relates to the current year results of Access Solutions, the sale of which was completed on June 2, 2024. Amounts reported in Other represent $11 million of divestiture-related costs associated with our announced portfolio transformation and Access Solutions sale.

[0001783180-24-000077:mdna:116]
Six Months Ended June 30, 2024 Compared with Six Months Ended June 30, 2023

[0001783180-24-000077:mdna:117]
Summary performance for each of our segments is as follows:

[0001783180-24-000077:mdna:118]
|  | Net Sales |  | Operating Profit |  | Operating Profit Margin |
|  | Six Months Ended June 30, |  | Six Months Ended June 30, |  | Six Months Ended June 30, |
| (In millions) | 2024 |  | 2023 |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| HVAC | $ | 9,511 |  |  | $ | 7,838 |  |  | $ | 1,116 |  |  | $ | 1,177 |  |  | 11.7 | % |  | 15.0 | % |
| Refrigeration | 1,857 |  |  | 1,870 |  |  | 210 |  |  | 220 |  |  | 11.3 | % |  | 11.8 | % |
| Fire & Security | 1,758 |  |  | 1,801 |  |  | 3,154 |  |  | (64) |  |  | 179.4 | % |  | (3.6) | % |
| Total segment | $ | 13,126 |  |  | $ | 11,509 |  |  | $ | 4,480 |  |  | $ | 1,333 |  |  | 34.1 | % |  | 11.6 | % |

[0001783180-24-000077:mdna:119]
HVAC Segment

[0001783180-24-000077:mdna:120]
For the six months ended June 30, 2024, Net sales in our HVAC segment were $9.5 billion, a 21% increase compared with the same period of 2023. The components of the year-over-year change were as follows:

[0001783180-24-000077:mdna:121]
|  |  | Net Sales |
| Organic |  | 2 | % |
| Foreign currency translation |  | (1) | % |
| Acquisitions and divestitures, net |  | 20 | % |
| Total % change in Net sales |  | 21 | % |

[0001783180-24-000077:mdna:122]
The organic increase in Net sales of 2% was driven by continued strong results in the segment. Growth in the Americas (up 5%) was primarily driven by our Commercial and Light Commercial businesses which benefited from ongoing customer demand and pricing improvements. Moderate growth in our residential business due to price improvements was impacted by lower volumes compared with the prior year. EMEA (down 4%) continues to be impacted by reduced volumes in residential markets. The reduction was partially offset by ongoing customer demand and pricing improvements in our Commercial business. Results in Asia (down 4%) were impacted by lower demand in the region, primarily in China.

[0001783180-24-000077:mdna:123]
On January 2, 2024, we acquired the VCS Business, a leading manufacturer of high efficiency heating and renewable energy systems in Europe. The results of the VCS Business have been included in our Unaudited Condensed Consolidated Financial Statements since the date of acquisition. The transaction added 20% to Net sales during the six months ended June 30, 2024 and is included in Acquisitions and divestitures, net.

[0001783180-24-000077:mdna:124]
For the six months ended June 30, 2024, Operating profit in our HVAC segment was $1.1 billion, a 5% decrease compared with the same period of 2023. The components of the year-over-year change were as follows:

[0001783180-24-000077:mdna:125]
|  |  | Operating Profit |
| Operational |  | 21 | % |
| Acquisitions and divestitures, net |  | — | % |
| Restructuring |  | (3) | % |
| Amortization of acquired intangibles |  | (23) | % |
| Total % change in Operating profit |  | (5) | % |

[0001783180-24-000077:mdna:126]
The operational profit increase of 21% was primarily attributable to ongoing customer demand and pricing improvements in certain end-markets compared with the prior year. In addition, favorable material and logistics costs drove productivity benefits in the segment. These benefits more than offset volume reductions in certain end-markets. Higher earnings from equity method investments further benefited operational profit in the segment. The increase was partially offset by a $23 million charge associated with the devaluation of U.S. Dollar denominated balances at an HVAC equity investment in Egypt.

[0001783180-24-000077:mdna:127]
Refrigeration Segment

[0001783180-24-000077:mdna:128]
For the six months ended June 30, 2024, Net sales in our Refrigeration segment were $1.9 billion, a 1% decrease compared with the same period of 2023. The components of the year-over-year change were as follows:

[0001783180-24-000077:mdna:129]
|  |  | Net Sales |
| Organic |  | (1) | % |
| Foreign currency translation |  | — | % |
| Total % change in Net sales |  | (1) | % |

[0001783180-24-000077:mdna:130]
Organic Net sales decreased 1% compared to the prior year as the segment experienced challenges in certain end-markets during the period. Results for Commercial refrigeration decreased (down 4%) compared with the prior year, primarily driven by lower volumes in Europe as economic conditions and inflationary cost pressures impacted end-market demand. In addition, Asia results were impacted by reduced end-market demand in China. Transport refrigeration sales were flat compared to the prior year as lower end-market demand in North America offset improved results in Europe and Asia. However, the decrease was offset by strong container end-markets.

[0001783180-24-000077:mdna:131]
For the six months ended June 30, 2024, Operating profit in our Refrigeration segment was $210 million, a 5% decrease compared with the same period of 2023. The components of the year-over-year change were as follows:

[0001783180-24-000077:mdna:132]
|  |  | Operating Profit |
| Operational |  | 6 | % |
| Restructuring |  | 4 | % |
| Other |  | (15) | % |
| Total % change in Operating profit |  | (5) | % |

[0001783180-24-000077:mdna:133]
The increase in operational profit of 6% was primarily driven by favorable productivity initiatives and price improvements compared with the prior year. In addition, volume growth in certain end-markets further benefited the segment. These amounts were partially offset by volume reductions in certain other end-markets. Inflationary cost pressures are moderating but continue to impact our operating profit. Amounts reported in Other represent $6 million of divestiture-related costs associated with the announced sale of CCR. In addition, the prior year includes a $24 million gain on the sale of a business within Transport refrigeration.

[0001783180-24-000077:mdna:134]
Fire & Security Segment

[0001783180-24-000077:mdna:135]
For the six months ended June 30, 2024, Net sales in our Fire & Security segment were $1.8 billion, a 2% decrease compared with the same period of 2023. The components of the year-over-year change were as follows:

[0001783180-24-000077:mdna:136]
|  |  | Net Sales |
| Organic |  | 5 | % |
| Acquisitions and divestitures, net |  | (4) | % |
| KFI deconsolidation |  | (3) | % |
| Total % change in Net sales |  | (2) | % |

[0001783180-24-000077:mdna:137]
The organic increase in Net sales of 5% was primarily driven by volume growth and price improvements compared with the prior year. Increased sales in our Commercial and Residential fire business benefited from ongoing customer demand and price improvements in the Americas and Europe. Growth in our Global Industrial business was driven by strong end-market demand and pricing improvements. Acquisitions and divestitures, net primarily relates to the Access Solutions divestiture completed on June 2, 2024.

[0001783180-24-000077:mdna:138]
For the six months ended June 30, 2024, Operating profit in our Fire & Security segment was $3.2 billion, a 5,028% increase compared with the same period of 2023. The components of the year-over-year change were as follows:

[0001783180-24-000077:mdna:139]
|  |  | Operating Profit |
| Operational |  | 183 | % |
| Foreign currency translation |  | (2) | % |
| Acquisitions and divestitures, net |  | (41) | % |
| Restructuring |  | 3 | % |
| Amortization of acquired intangibles |  | 6 | % |
| KFI deconsolidation |  | 430 | % |
| Access Solutions gain |  | 4,483 | % |
| Other |  | (34) | % |
| Total % change in Operating profit |  | 5,028 | % |

[0001783180-24-000077:mdna:140]
The increase in operational profit of 183% was primarily driven by volume growth and price improvements compared with the prior year. In addition, favorable material and logistics costs drove productivity benefits during the period. The segment also benefited from lower inventory-related reserves compared with the prior year as supply chain challenges improved. In addition, lower depreciation and amortization, which was ceased on held-for-sale assets in accordance with ASC 360, Property, Plant and Equipment, further benefited operational profit. These amounts were partially offset by lower volumes in certain end-markets. Inflationary cost pressures are moderating but continue to impact our operating profit.

[0001783180-24-000077:mdna:141]
Acquisitions and divestitures, net primarily relates to the current year results of Access Solutions, the sale of which was completed on June 2, 2024. Amounts reported in Other represent $16 million of separation-related costs associated with our announced portfolio transformation and Access Solutions sale.

[0001783180-24-000077:mdna:142]
47

[0001783180-24-000077:mdna:143]
[same as prior period, unchanged from 0001783180-24-000044:mdna:78]

[0001783180-24-000077:mdna:144]
[same as prior period, unchanged from 0001783180-24-000044:mdna:79]

[0001783180-24-000077:mdna:145]
As of June 30, 2024, we had cash and cash equivalents of $2.9 billion, of which approximately 52% was held by our foreign subsidiaries. We manage our worldwide cash requirements by reviewing available funds and the cost effectiveness with which we can access funds held by foreign subsidiaries. On occasion, we are required to maintain cash deposits in connection with contractual obligations related to acquisitions, divestitures or other legal obligations. As of June 30, 2024 and December 31, 2023, the amount of such restricted cash was approximately $3 million and $2 million, respectively.

[0001783180-24-000077:mdna:146]
[same as prior period, unchanged from 0001783180-24-000044:mdna:81]

[0001783180-24-000077:mdna:147]
[same as prior period, unchanged from 0001783180-24-000044:mdna:82]

[0001783180-24-000077:mdna:148]
[same as prior period, unchanged from 0001783180-24-000044:mdna:83]

[0001783180-24-000077:mdna:149]
| (In millions) |  | June 30,2024 |  | December 31,2023 |
| Cash and cash equivalents |  | $ | 2,919 |  |  | $ | 10,015 |  |
| Total debt |  | $ | 13,322 |  |  | $ | 14,293 |  |
| Total equity |  | $ | 14,079 |  |  | $ | 9,005 |  |
| Net debt (total debt less cash and cash equivalents) |  | $ | 10,403 |  |  | $ | 4,278 |  |
| Total capitalization (total debt plus total equity) |  | $ | 27,401 |  |  | $ | 23,298 |  |
| Net capitalization (total debt plus total equity less cash and cash equivalents) |  | $ | 24,482 |  |  | $ | 13,283 |  |
| Total debt to total capitalization |  | 49 | % |  | 61 | % |
| Net debt to net capitalization |  | 42 | % |  | 32 | % |

[0001783180-24-000077:mdna:150]
[same as prior period, unchanged from 0001783180-24-000044:mdna:85]

[0001783180-24-000077:mdna:151]
[same as prior period, unchanged from 0001783180-24-000044:mdna:86]

[0001783180-24-000077:mdna:152]
48

[0001783180-24-000077:mdna:153]
[same as prior period, unchanged from 0001783180-24-000044:mdna:87]

[0001783180-24-000077:mdna:154]
On January 2, 2024, we completed the acquisition of the VCS Business for $14.2 billion. The cash portion of the purchase price was funded through cash on hand, proceeds from the USD Notes and the Euro Notes and borrowings under the Delayed Draw Facility and the 60-day Loan. Proceeds from the Revolver became available upon closing.

[0001783180-24-000077:mdna:155]
In March 2024, borrowings under the 60-day loan were repaid. In May 2024, the Revolver was terminated and refinanced in order to extend its maturity to May 2025. In addition, we redeemed our $1.0 billion aggregate principle amount of 5.80% notes due in 2025 and repaid borrowings under the Delayed Draw Facility in June 2024, which was subsequently terminated.

[0001783180-24-000077:mdna:156]
[same as prior period, unchanged from 0001783180-24-000044:mdna:89]

[0001783180-24-000077:mdna:157]
We maintain a $2.0 billion unsecured, unsubordinated commercial paper program which we can use for general corporate purposes, including the funding of working capital and potential acquisitions. In addition, we maintain a $2.0 billion revolving credit agreement with various banks (the "Revolving Credit Facility") that matures in May 2028 which supports our commercial paper borrowing program and can be used for general corporate purposes. A ratings-based commitment fee is charged on unused commitments. As of June 30, 2024, we had no borrowings outstanding under our commercial paper program or our Revolving Credit Facility.

[0001783180-24-000077:mdna:158]
Our short-term obligations primarily consist of current maturities of long-term debt. Our long-term obligations primarily consist of long-term notes with maturity dates ranging between 2025 and 2054. Interest payments related to long-term Notes are expected to approximate $479 million per year, reflecting an approximate weighted-average interest rate of 3.63%. Any borrowings from the Revolving Credit Facility are subject to variable interest rates. See Note 5 – Borrowings and Lines of Credit in the Notes to the accompanying Unaudited Condensed Consolidated Financial Statements for additional information regarding the terms of our long-term debt obligations.

[0001783180-24-000077:mdna:159]
The following table presents our credit ratings and outlook as of June 30, 2024:

[0001783180-24-000077:mdna:160]
| Rating Agency |  | Long-term Rating (1) |  | Short-term Rating (2) |  | Outlook (2) (3) (4) |
| Standards & Poor's ("S&P") |  | BBB |  | A2 |  | Positive |
| Moody's Investors Service Inc. ("Moody's") |  | Baa2 |  | P2 |  | Positive |
| Fitch Ratings ("Fitch") |  | BBB |  | F3 |  | Stable |

[0001783180-24-000077:mdna:161]
(1) The long-term rating for S&P was affirmed on May 14, 2021, upgraded by Moody's to Baa2 on May 13, 2024. Fitch's was updated in December 2023.

[0001783180-24-000077:mdna:162]
(2) Fitch upgraded its short-term rating to F2 from F3 and revised its outlook to positive from stable on July 11, 2024.

[0001783180-24-000077:mdna:163]
(3) S&P revised its outlook to positive from stable in December 2023.

[0001783180-24-000077:mdna:164]
(4) Moody's revised its outlook to positive from stable on February 28, 2023.

[0001783180-24-000077:mdna:165]
49

[0001783180-24-000077:mdna:166]
[same as prior period, unchanged from 0001783180-24-000044:mdna:98]

[0001783180-24-000077:mdna:167]
On June 2, 2024, we completed the divestiture of Access Solutions for cash proceeds of $5.0 billion, subject to customary working capital and other adjustments. Consistent with our capital allocation strategy, the net proceeds will be used to fund repayment of debt, investments in organic and inorganic growth initiatives and capital returns to shareowners as well as for general corporate purposes.

[0001783180-24-000077:mdna:168]
On December 12, 2023, we entered into a stock purchase agreement to sell CCR to Haier Group Corporation for an enterprise value of approximately $775 million. The transaction is expected to close in 2024. On March 5, 2024, we entered into a stock purchase agreement to sell Industrial Fire to Sentinel Capital Partners for an enterprise value of approximately $1.425 billion. The sale was completed on July 1, 2024.

[0001783180-24-000077:mdna:169]
[same as prior period, unchanged from 0001783180-24-000044:mdna:100]

[0001783180-24-000077:mdna:170]
[same as prior period, unchanged from 0001783180-24-000044:mdna:101]

[0001783180-24-000077:mdna:171]
[same as prior period, unchanged from 0001783180-24-000044:mdna:102]

[0001783180-24-000077:mdna:172]
We paid dividends on common stock during the six months ended June 30, 2024, totaling $330 million. In June 2024, the Board of Directors declared a dividend of $0.19 per share of common stock payable on August 8, 2024, to shareowners of record at the close of business on June 21, 2024.

[0001783180-24-000077:mdna:173]
[same as prior period, unchanged from 0001783180-24-000044:mdna:104]

[0001783180-24-000077:mdna:174]
|  |  | Six Months Ended June 30, |
| (In millions) |  | 2024 |  | 2023 |
| Net cash flows provided by (used in): |  |  |  |  |
| Operating activities |  | $ | 700 |  |  | $ | 504 |  |
| Investing activities |  | (6,273) |  |  | (296) |  |
| Financing activities |  | (1,406) |  |  | (506) |  |
| Effect of foreign exchange rate changes on cash and cash equivalents |  | (82) |  |  | (13) |  |
| Net increase (decrease) in cash and cash equivalents and restricted cash |  | $ | (7,061) |  |  | $ | (311) |  |

[0001783180-24-000077:mdna:175]
Cash flows from operating activities primarily represent inflows and outflows associated with our operations. Primary activities include net income from operations adjusted for non-cash transactions, working capital changes and changes in other assets and liabilities. The year-over-year increase in net cash provided by operating activities was primarily driven by an decrease in working capital balances compared with the prior period. Higher accounts payable balances, improved cash conversion and lower inventory benefited working capital during the year.

[0001783180-24-000077:mdna:176]
Cash flows from investing activities primarily represent inflows and outflows associated with long-term assets. Primary activities include capital expenditures, acquisitions, divestitures and proceeds from the sale of fixed assets. During the six months ended June 30, 2024, net cash used in investing activities was $6.3 billion. The primary driver of the outflow related to the acquisition of the VCS Business, which totaled $10.8 billion, net of cash acquired. Additional investing outflows include $185 million related to settlement of derivatives and $215 million of capital expenditures. These outflows were partially offset by the divestiture of Access Solutions for cash proceeds of $5.0 billion. During the six months ended June 30, 2023, net cash used in investing activities was $296 million. The primary drivers of the outflow related to $144 million of capital expenditures and $134 million related to the deconsolidation of KFI. In addition, we settled working capital and other transaction-related items associated with the acquisition of Toshiba Carrier Corporation and invested in several businesses. These amounts totaled $56 million, net of cash acquired and were partially offset by the proceeds from the sale of a business during the period.

[0001783180-24-000077:mdna:177]
Cash flows from financing activities primarily represent inflows and outflows associated with equity or borrowings. During the six months ended June 30, 2024, net cash used in financing activities was $1.4 billion. The primary driver of the outflow is due to repayments of long-term debt of $3.5 billion which includes prepayments of the Delayed Draw Facility and the redemption of our 5.80% notes due in 2025. In addition, we made dividend payments of $330 million to our common shareowners. These outflows were partially offset by the proceeds of borrowings used to fund the cash portion of the acquisition of the VCS Business. During the six months ended June 30, 2023, net cash used in financing activities was $506 million. The primary driver of the outflow related to the payment of $309 million in dividends to our common shareowners. In addition, we paid $62 million to repurchase shares of our common stock.
