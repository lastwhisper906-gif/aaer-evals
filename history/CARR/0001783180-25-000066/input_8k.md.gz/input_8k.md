# CARR 8-K — 0001783180-25-000063 filed 2025-10-28

## item codes, every 8-K on or before 2025-10-28

- 2025-10-28 0001783180-25-000063 — 2.02, 7.01, 9.01
- 2025-09-04 0000950142-25-002375 — 5.02
- 2025-07-29 0001783180-25-000058 — 8.01, 9.01
- 2025-07-29 0001783180-25-000047 — 2.02, 9.01
- 2025-06-05 0000950142-25-001575 — 7.01
- 2025-05-01 0001783180-25-000028 — 2.02, 7.01, 9.01
- 2025-04-17 0000950142-25-001103 — 5.02
- 2025-04-11 0001783180-25-000021 — 5.02, 5.07, 9.01
- 2025-02-11 0001783180-25-000006 — 2.02, 9.01
- 2025-01-15 0000950142-25-000133 — 5.02, 9.01
- 2024-12-20 0001783180-24-000093 — 1.01, 1.02, 2.03, 9.01
- 2024-12-03 0000950142-24-002874 — 5.02
- 2024-12-02 0000950142-24-002865 — 7.01, 9.01
- 2024-11-08 0000950142-24-002699 — 1.01, 2.03, 9.01
- 2024-10-28 0000950142-24-002640 — 8.01
- 2024-10-28 0000950142-24-002638 — 8.01
- 2024-10-24 0001783180-24-000084 — 2.02, 7.01, 9.01
- 2024-10-18 0000950142-24-002601 — 1.01
- 2024-08-15 0001140361-24-037426 — 7.01, 9.01
- 2024-07-25 0001783180-24-000075 — 2.02, 9.01
- 2024-06-21 0001783180-24-000069 — 5.02
- 2024-06-21 0000950142-24-001676 — 5.02
- 2024-06-07 0001783180-24-000062 — 5.02, 5.03, 9.01
- 2024-06-03 0000950142-24-001538 — 1.02, 7.01, 9.01
- 2024-05-17 0001783180-24-000049 — 1.01, 1.02, 2.03, 9.01
- 2024-04-25 0001783180-24-000042 — 2.02, 9.01
- 2024-04-19 0001783180-24-000035 — 5.07, 9.01
- 2024-04-19 0000950142-24-001162 — 5.07 — amendment of 0001783180-24-000035
- 2024-02-06 0001783180-24-000007 — 2.02, 9.01
- 2024-02-01 0000950142-24-000264 — 5.02
- 2024-01-02 0001140361-24-000034 — 1.01, 2.01, 2.03, 5.02, 7.01, 9.01
- 2023-12-13 0001140361-23-057415 — 1.01, 9.01
- 2023-12-08 0001140361-23-056751 — 7.01, 9.01
- 2023-11-30 0000950142-23-002884 — 1.01, 2.03, 8.01, 9.01
- 2023-11-16 0000950142-23-002788 — 8.01, 9.01
- 2023-11-13 0001140361-23-052667 — 7.01, 8.01, 9.01
- 2023-10-26 0001783180-23-000063 — 2.02, 9.01
- 2023-07-27 0001783180-23-000053 — 2.02, 9.01
- 2023-06-12 0000950142-23-001664 — 5.02
- 2023-05-25 0000950142-23-001541 — 1.01, 1.02, 2.03, 9.01
- 2023-04-26 0000950142-23-001205 — 1.01, 9.01
- 2023-04-25 0001783180-23-000036 — 2.02, 7.01, 9.01
- 2023-04-25 0000950142-23-001199 — 7.01, 8.01, 9.01
- 2023-04-21 0001783180-23-000032 — 5.07, 9.01
- 2023-02-07 0001783180-23-000010 — 2.02, 9.01
- 2022-10-27 0001783180-22-000054 — 2.02, 7.01, 9.01
- 2022-09-29 0000950142-22-002805 — 5.02, 9.01
- 2022-07-28 0001783180-22-000045 — 2.02, 9.01
- 2022-04-28 0001783180-22-000032 — 2.02, 9.01
- 2022-04-15 0001783180-22-000024 — 5.07, 9.01
- 2022-02-08 0001783180-22-000008 — 2.02, 9.01
- 2022-02-07 0000950142-22-000510 — 8.01, 9.01
- 2022-01-03 0000950142-22-000023 — 8.01, 9.01
- 2021-12-17 0001783180-21-000071 — 5.02, 7.01, 9.01
- 2021-11-23 0001783180-21-000068 — 5.03, 9.01
- 2021-10-28 0001783180-21-000062 — 2.02, 9.01
- 2021-08-27 0001783180-21-000056 — 8.01
- 2021-07-30 0001783180-21-000053 — 1.01
- 2021-07-29 0001783180-21-000049 — 2.02, 8.01, 9.01
- 2021-07-27 0000950142-21-002448 — 8.01, 9.01
- 2021-07-15 0000950142-21-002362 — 5.02, 9.01
- 2021-06-09 0000950142-21-001885 — 5.02, 9.01
- 2021-04-29 0001783180-21-000029 — 2.02, 9.01
- 2021-04-22 0001140361-21-013889 — 5.02, 9.01
- 2021-04-20 0001783180-21-000021 — 5.07, 9.01
- 2021-04-19 0000950142-21-001308 — 8.01, 9.01
- 2021-02-09 0001783180-21-000009 — 2.02, 9.01
- 2021-02-05 0001140361-21-003513 — 8.01, 9.01
- 2020-12-23 0001140361-20-029419 — 7.01, 9.01
- 2020-12-22 0001140361-20-029097 — 8.01
- 2020-12-14 0001140361-20-028246 — 5.03, 9.01
- 2020-12-07 0001140361-20-027515 — 1.01, 7.01, 9.01
- 2020-10-29 0001783180-20-000063 — 2.02, 9.01
- 2020-10-19 0001140361-20-023241 — 5.02, 7.01, 9.01
- 2020-09-23 0001140361-20-021220 — 8.01, 9.01
- 2020-09-22 0001140361-20-021124 — 8.01, 9.01
- 2020-07-30 0001783180-20-000045 — 2.02, 9.01
- 2020-06-19 0001140361-20-014325 — 1.01, 2.03, 9.01
- 2020-06-16 0001140361-20-013880 — 8.01, 9.01
- 2020-06-03 0001140361-20-012939 — 1.01, 9.01
- 2020-05-08 0001783180-20-000013 — 2.02, 9.01
- 2020-04-03 0001140361-20-007888 — 1.01, 5.02, 5.03, 5.05, 7.01, 9.01
- 2020-03-16 0001140361-20-005868 — 8.01, 9.01

## late-filing notifications on or before 2025-10-28

- none on or before 2025-10-28

## item 2.02 — earnings release, exhibit 99.1

[0001783180-25-000063:8k_2_02:1]
EX-99.1
2
a99-q32025earningsexhibit.htm
EX-99.1

[0001783180-25-000063:8k_2_02:2]
Document

[0001783180-25-000063:8k_2_02:3]
Exhibit 99.1

[0001783180-25-000063:8k_2_02:4]
Carrier Reports Third Quarter 2025 Results

[0001783180-25-000063:8k_2_02:5]
•Net sales down 7%; organic sales down 4%

[0001783180-25-000063:8k_2_02:6]
•Total GAAP EPS of $0.47 and adjusted EPS of $0.67

[0001783180-25-000063:8k_2_02:7]
•Net cash flows from operating activities were $341 million and free cash flow was $224 million

[0001783180-25-000063:8k_2_02:8]
•Returned $3 billion to shareholders YTD, including $2.4 billion of share repurchases

[0001783180-25-000063:8k_2_02:9]
•Expecting full-year 2025 sales of ~$22 billion and adjusted EPS of ~$2.65

[0001783180-25-000063:8k_2_02:10]
•Board approves $5 billion share repurchase authorization

[0001783180-25-000063:8k_2_02:11]
PALM BEACH GARDENS, Fla., October 28, 2025 – Carrier Global Corporation (NYSE:CARR), global leader in intelligent climate and energy solutions, today reported financial results for the third quarter of 2025.

[0001783180-25-000063:8k_2_02:12]
"Our team drove continued double-digit aftermarket growth and strong performance in Commercial HVAC1, which grew 30% in the Americas, both of which were more than offset by expected weakness in Residential in the Americas," said Chairman & CEO David Gitlin. “Our previously announced cost reduction actions and continued strength in our data center pipeline and backlog position us well for strong earnings growth in 2026. The $5 billion share repurchase authorization reflects confidence in our strategy and commitment to delivering superior value for our shareholders."

[0001783180-25-000063:8k_2_02:13]
1.Excludes NORESCO

[0001783180-25-000063:8k_2_02:14]
1

[0001783180-25-000063:8k_2_02:15]
Third Quarter 2025 Results

[0001783180-25-000063:8k_2_02:16]
Total Company

[0001783180-25-000063:8k_2_02:17]
|  | (Unaudited) |
|  | Three Months Ended September 30 |  |
| (In millions) | 2025 | 2024 | Change |  |  |  |
| Net sales | $ | 5,579 |  | $ | 5,984 |  | (7) | % |  |  |  |
| Organic sales | (4) | % |  |  |  |  |  |
| Operating profit | $ | 539 |  | $ | 763 |  | (29) | % |  |  |  |
| Operating margin | 9.7 | % | 12.8 | % | (310) bps |  |  |  |
| Adjusted operating profit | $ | 823 |  | $ | 1,044 |  | (21) | % |  |  |  |
| Adjusted operating margin | 14.8 | % | 17.4 | % | (260) bps |  |  |  |
| Diluted earnings per share: |  |  |  |  |  |  |
| Continuing operations | $ | 0.47 |  | $ | 0.62 |  | (24) | % |  |  |  |
| Continuing operations - Adjusted | $ | 0.67 |  | $ | 0.77 |  | (13) | % |  |  |  |

[0001783180-25-000063:8k_2_02:18]
Carrier’s third-quarter sales of $5.6 billion decreased 7% compared to the prior year. An organic sales decline of 4% and a 4% headwind from net divestitures from the sale of Commercial Refrigeration in Q4 2024 were partially offset by a 1% tailwind from foreign currency translation.

[0001783180-25-000063:8k_2_02:19]
GAAP operating profit of $539 million in the quarter declined 29% from last year reflecting weaker residential end-markets and distributor destocking in the Americas, partially offset by the absence of prior year backlog and inventory step-up amortization.  
    Adjusted operating profit of $823 million was down 21% primarily due to lower volume in our CSA Residential business. Net earnings from continuing operations were $407 million and adjusted net earnings from continuing operations were $576 million. GAAP EPS from continuing operations was $0.47 and adjusted EPS was $0.67, down 24% and 13% year-over-year, respectively. The declines were primarily driven by lower operating profit, partially offset by a lower tax rate and benefits of a lower share count.

[0001783180-25-000063:8k_2_02:20]
2

[0001783180-25-000063:8k_2_02:21]
Climate Solutions Americas (CSA)

[0001783180-25-000063:8k_2_02:22]
|  | (Unaudited) |
|  | Three Months Ended September 30 |  |
| (In millions) | 2025 | 2024 | Change |  |  |  |
| Net sales | $ | 2,711 |  | $ | 2,961 |  | (8) | % |  |  |  |
| Organic sales | (8) | % |  |  |  |  |  |
| Segment operating profit | $ | 533 |  | $ | 750 |  | (29) | % |  |  |  |
| Segment operating margin | 19.7 | % | 25.3 | % | (560) bps |  |  |  |

[0001783180-25-000063:8k_2_02:23]
CSA segment sales declined 8%. Organic sales were down 8% with continued strength in Commercial1 up 30%, more than offset by lower volumes in Residential, down about 30%, and Light Commercial down 4%.

[0001783180-25-000063:8k_2_02:24]
Segment operating margin decreased 560 basis points, reflecting the significant volume decline in the Residential business.

[0001783180-25-000063:8k_2_02:25]
Climate Solutions Europe (CSE)

[0001783180-25-000063:8k_2_02:26]
|  | (Unaudited) |
|  | Three Months Ended September 30 |  |
| (In millions) | 2025 | 2024 | Change |  |  |  |
| Net sales | $ | 1,290 |  | $ | 1,246 |  | 4 | % |  |  |  |
| Organic sales | (3) | % |  |  |  |  |  |
| Segment operating profit | $ | 120 |  | $ | 129 |  | (7) | % |  |  |  |
| Segment operating margin | 9.3 | % | 10.4 | % | (110) bps |  |  |  |

[0001783180-25-000063:8k_2_02:27]
CSE segment sales increased 4%. Organic sales were down 3% with Residential and Light Commercial down low-single digits and Commercial down mid-single digits.

[0001783180-25-000063:8k_2_02:28]
Segment operating margin decreased 110 basis points driven by strong productivity, including cost synergies, more than offset by lower organic sales and mix.

[0001783180-25-000063:8k_2_02:29]
1.Excludes NORESCO

[0001783180-25-000063:8k_2_02:30]
3

[0001783180-25-000063:8k_2_02:31]
Climate Solutions Asia Pacific, Middle East & Africa (CSAME)

[0001783180-25-000063:8k_2_02:32]
|  | (Unaudited) |
|  | Three Months Ended September 30 |  |
| (In millions) | 2025 | 2024 | Change |  |  |  |
| Net sales | $ | 833 |  | $ | 840 |  | (1) | % |  |  |  |
| Organic sales | (2) | % |  |  |  |  |  |
| Segment operating profit | $ | 97 |  | $ | 106 |  | (8) | % |  |  |  |
| Segment operating margin | 11.6 | % | 12.6 | % | (100) bps |  |  |  |

[0001783180-25-000063:8k_2_02:33]
CSAME segment sales declined 1%. Organic sales were down 2% mainly driven by Residential and Light Commercial (RLC) in China, partially offset by continued strong growth in India and the Middle East.

[0001783180-25-000063:8k_2_02:34]
Segment operating margin decreased 100 basis points with strong productivity more than offset by lower sales.

[0001783180-25-000063:8k_2_02:35]
Climate Solutions Transportation (CST)

[0001783180-25-000063:8k_2_02:36]
|  | (Unaudited) |
|  | Three Months Ended September 30 |  |
| (In millions) | 2025 | 2024 | Change |  |  |  |
| Net sales | $ | 745 |  | $ | 937 |  | (20) | % |  |  |  |
| Organic sales | 6 | % |  |  |  |  |  |
| Segment operating profit | $ | 115 |  | $ | 137 |  | (16) | % |  |  |  |
| Segment operating margin | 15.4 | % | 14.6 | % | 80 bps |  |  |  |

[0001783180-25-000063:8k_2_02:37]
CST sales declined 20% driven by the impact from the divestiture of Commercial Refrigeration. Organic sales increased 6% with 50% growth in Container, partially offset by a decline in Global Truck and Trailer, down mid-single digits.

[0001783180-25-000063:8k_2_02:38]
Segment operating margin increased 80 basis points largely due to the Commercial Refrigeration exit during Q4 2024, partially offset by mix.

[0001783180-25-000063:8k_2_02:39]
4

[0001783180-25-000063:8k_2_02:40]
Cash Flow

[0001783180-25-000063:8k_2_02:41]
|  |  | (Unaudited) |  | (Unaudited) |
|  |  | Three Months Ended September 30, |  | Nine Months EndedSeptember 30, |
| (In millions) |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Net cash flows provided by operating activities |  | $ | 341 |  |  | $ | (269) |  |  | $ | 1,473 |  |  | $ | 431 |  |
| Less: Capital expenditures - continuing operations |  | (117) |  |  | (92) |  |  | (261) |  |  | (302) |  |
| Less: Capital expenditures - discontinued operations |  | — |  |  | (5) |  |  | — |  |  | (10) |  |
| Free cash flow |  | $ | 224 |  |  | $ | (366) |  |  | $ | 1,212 |  |  | $ | 119 |  |

[0001783180-25-000063:8k_2_02:42]
Net cash flows generated from operating activities were $341 million and capital expenditures were $117 million, resulting in free cash flow of $224 million.

[0001783180-25-000063:8k_2_02:43]
Full-Year 2025 Guidance**

[0001783180-25-000063:8k_2_02:44]
|  | Current Guidance** | Prior Guidance |  |
| Sales | ~$22 billion~$750 million revenue headwind from CCR exitOrganic* ~flatFX 1%Acquisitions 0%Divestitures (3%) | ~$23 billion~$750 million revenue headwind from CCR exitOrganic* up MSDFX 1%Acquisitions 0%Divestitures (3%) |  |
| Adjusted Operating Margin* | 15.0% – 15.5%~(50) bps Y/Y | 16.5% – 17.0%+ ~100 bps Y/Y |  |
| Adjusted EPS* | ~$2.65+~4% Y/Y | $3.00 – $3.10~17-21% Y/Y |  |
| Free Cash Flow* | ~$2 billionIncludes the expected results of continuing and discontinued operations | $2.4 – $2.6 billionIncludes the expected results of continuing and discontinued operations |  |

[0001783180-25-000063:8k_2_02:45]
*Note: When the company provides expectations for organic sales, adjusted operating profit, adjusted operating margin, adjusted EPS and free cash flow on a forward-looking basis, a reconciliation of the differences between the non-GAAP expectations and the corresponding GAAP measures generally is not available without unreasonable effort. See “Use and Definitions of Non-GAAP Financial Measures” below for additional information.

[0001783180-25-000063:8k_2_02:46]
**As of October 28, 2025

[0001783180-25-000063:8k_2_02:47]
Conference Call

[0001783180-25-000063:8k_2_02:48]
Carrier will host a webcast of its earnings conference call today, Tuesday, October 28, at 7:30 a.m. ET. To access the webcast, visit the Events & Presentations section of the Carrier Investor Relations site at ir.carrier.com/news-and-events/events-and-presentations or to listen to the earnings call by phone, participants must pre-register at Carrier Earnings Call Registration. All registrants will receive dial-in information and a PIN allowing access to the live call.

[0001783180-25-000063:8k_2_02:49]
Cautionary Statement

[0001783180-25-000063:8k_2_02:50]
6

[0001783180-25-000063:8k_2_02:51]
About Carrier

[0001783180-25-000063:8k_2_02:52]
Carrier Global Corporation, global leader in intelligent climate and energy solutions, is committed to creating innovations that bring comfort, safety and sustainability to life. Through cutting-edge advancements in climate solutions such as temperature control, air quality and transportation, we improve lives, empower critical industries and ensure the safe transport of food, life-saving medicines and more. Since inventing modern air conditioning in 1902, we lead with purpose: enhancing the lives we live and the world we share. We continue to lead because of our world-class, inclusive workforce that puts the customer at the center of everything we do. For more information, visit corporate.carrier.com or follow Carrier on social media at @Carrier.

[0001783180-25-000063:8k_2_02:53]
Carrier. For the World We Share.

[0001783180-25-000063:8k_2_02:54]
CARR-IR

[0001783180-25-000063:8k_2_02:55]
7

[0001783180-25-000063:8k_2_02:56]
Contact:

[0001783180-25-000063:8k_2_02:57]
Investor Relations

[0001783180-25-000063:8k_2_02:58]
Michael Rednor

[0001783180-25-000063:8k_2_02:59]
561-365-2020

[0001783180-25-000063:8k_2_02:60]
InvestorRelations@Carrier.com

[0001783180-25-000063:8k_2_02:61]
Media Inquiries

[0001783180-25-000063:8k_2_02:62]
Jason Shockley

[0001783180-25-000063:8k_2_02:63]
561-542-0207

[0001783180-25-000063:8k_2_02:64]
Jason.Shockley@Carrier.com

[0001783180-25-000063:8k_2_02:65]
8

[0001783180-25-000063:8k_2_02:66]
SELECTED FINANCIAL DATA, NON-GAAP MEASURES AND DEFINITIONS

[0001783180-25-000063:8k_2_02:67]
Following are tables that present selected financial data of Carrier Global Corporation (“Carrier”).

[0001783180-25-000063:8k_2_02:68]
As a result of Carrier's portfolio transformation, Carrier revised its reportable segments during the first quarter of 2025 to better reflect its business strategy, align its management reporting and increase transparency for investors. In connection with the revised structure, the Chief Operating Decision Maker changed the measure used to evaluate segment profitability from Operating profit to Segment operating profit. It represents operating profit (a measure prepared in accordance with accounting principles generally accepted in the United States (“GAAP”)) adjusted to exclude restructuring costs, amortization of acquired intangible assets and other significant items of a nonoperational nature. All prior period comparative information has been recast to reflect the revised segment structure.

[0001783180-25-000063:8k_2_02:69]
Use and Definitions of Non-GAAP Financial Measures

[0001783180-25-000063:8k_2_02:70]
Carrier reports its financial results in accordance with GAAP. We supplement the reporting of our financial information determined under GAAP with certain non-GAAP financial information. The non-GAAP information presented provides investors with additional useful information, but should not be considered in isolation or as substitutes for the related GAAP measures. Moreover, other companies may define non-GAAP measures differently, which limits the usefulness of these measures for comparisons with such other companies. We encourage investors to review our financial statements and publicly filed reports in their entirety and not to rely on any single financial measure. A reconciliation of the non-GAAP measures to the corresponding amounts prepared in accordance with GAAP appears in the tables in this Appendix. The tables provide additional information as to the items and amounts that have been excluded from the adjusted measures.

[0001783180-25-000063:8k_2_02:71]
Organic sales, adjusted operating profit, adjusted operating margin, adjusted net income, adjusted earnings per share (“EPS”), adjusted effective tax rate and net debt are non-GAAP financial measures and are associated with Carrier's continuing operations unless specifically noted.

[0001783180-25-000063:8k_2_02:72]
Organic sales represents consolidated net sales (a GAAP measure), excluding the impact of foreign currency translation, acquisitions and divestitures completed in the preceding twelve months and other significant items of a nonoperational nature (hereinafter referred to as “other significant items”). Adjusted operating profit represents consolidated operating profit (a GAAP measure), excluding restructuring costs, amortization of acquired intangibles and other significant items. Adjusted operating margin represents adjusted operating profit as a percentage of consolidated net sales (a GAAP measure). Adjusted net income represents net income attributable to common shareowners (a GAAP measure), excluding restructuring costs, amortization of acquired intangibles and other significant items. Adjusted EPS represents diluted earnings per share (a GAAP measure), excluding restructuring costs, amortization of acquired intangibles and other significant items. The adjusted effective tax rate represents the effective tax rate (a GAAP measure), excluding restructuring costs, amortization of acquired intangibles and other significant items. Net debt represents long-term debt (a GAAP measure) less cash and cash equivalents (a GAAP measure).

[0001783180-25-000063:8k_2_02:73]
Free cash flow is a non-GAAP financial measure that represents net cash flows provided by continuing operating activities (a GAAP measure) less capital expenditures. Management believes free cash flow is a useful measure of liquidity and an additional basis for assessing Carrier’s ability to fund its activities, including the financing of acquisitions, debt service, repurchases of Carrier's common stock and distribution of earnings to shareowners. Orders are contractual commitments with customers to provide specified goods or services for an agreed upon price and may not be subject to penalty if cancelled.

[0001783180-25-000063:8k_2_02:74]
When Carrier provides our expectations for organic sales, adjusted operating profit, adjusted operating margin, adjusted effective tax rate, adjusted EPS and free cash flow on a forward-looking basis, a reconciliation of the differences between the non-GAAP expectations and the corresponding GAAP measures generally is not available without unreasonable effort due to potentially high variability, complexity and low visibility as to the items that would be excluded from the GAAP measure in the relevant future period, such as unusual gains and losses, the ultimate outcome of pending litigation, fluctuations in foreign currency exchange rates, the impact and timing of potential acquisitions and divestitures, future restructuring costs, and other structural changes or their probable significance. The variability of the excluded items may have a significant, and potentially unpredictable, impact on our future GAAP results.

[0001783180-25-000063:8k_2_02:75]
9

[0001783180-25-000063:8k_2_02:76]
Carrier Global Corporation

[0001783180-25-000063:8k_2_02:77]
Condensed Consolidated Statement of Operations

[0001783180-25-000063:8k_2_02:78]
|  |  | (Unaudited) |
|  |  | Three Months Ended September 30, |  | Nine Months EndedSeptember 30, |
| (In millions, except per share amounts) |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Net sales |  |  |  |  |  |  |  |  |
| Product sales |  | $ | 4,906 |  |  | $ | 5,307 |  |  | $ | 15,035 |  |  | $ | 15,460 |  |
| Service sales |  | 673 |  |  | 677 |  |  | 1,875 |  |  | 1,878 |  |
| Total Net sales |  | 5,579 |  |  | 5,984 |  |  | 16,910 |  |  | 17,338 |  |
| Costs and expenses |  |  |  |  |  |  |  |  |
| Cost of products sold |  | (3,656) |  |  | (3,796) |  |  | (10,881) |  |  | (11,245) |  |
| Cost of services sold |  | (474) |  |  | (511) |  |  | (1,366) |  |  | (1,456) |  |
| Research and development |  | (151) |  |  | (172) |  |  | (465) |  |  | (524) |  |
| Selling, general and administrative |  | (803) |  |  | (799) |  |  | (2,345) |  |  | (2,394) |  |
| Total Costs and expenses |  | (5,084) |  |  | (5,278) |  |  | (15,057) |  |  | (15,619) |  |
| Equity method investment net earnings |  | 60 |  |  | 66 |  |  | 182 |  |  | 187 |  |
| Other income (expense), net |  | (16) |  |  | (9) |  |  | 36 |  |  | (34) |  |
| Operating profit |  | 539 |  |  | 763 |  |  | 2,071 |  |  | 1,872 |  |
| Non-service pension (expense) benefit |  | (9) |  |  | (1) |  |  | (8) |  |  | (1) |  |
| Interest (expense) income, net |  | (97) |  |  | 8 |  |  | (270) |  |  | (290) |  |
| Earnings before income taxes |  | 433 |  |  | 770 |  |  | 1,793 |  |  | 1,581 |  |
| Income tax (expense) benefit |  | 1 |  |  | (172) |  |  | (272) |  |  | (339) |  |
| Earnings from continuing operations |  | 434 |  |  | 598 |  |  | 1,521 |  |  | 1,242 |  |
| Discontinued operations, net of tax |  | 21 |  |  | (117) |  |  | 4 |  |  | 1,897 |  |
| Net earnings (loss) |  | 455 |  |  | 481 |  |  | 1,525 |  |  | 3,139 |  |
| Less: Non-controlling interest in subsidiaries' |  | 27 |  |  | 34 |  |  | 94 |  |  | 86 |  |
| Net earnings (loss) attributable to common shareowners |  | $ | 428 |  |  | $ | 447 |  |  | $ | 1,431 |  |  | $ | 3,053 |  |
| Amounts attributable to common shareowners: |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 407 |  |  | $ | 564 |  |  | $ | 1,427 |  |  | $ | 1,156 |  |
| Discontinued operations |  | 21 |  |  | (117) |  |  | 4 |  |  | 1,897 |  |
| Net earnings (loss) attributable to common shareowners |  | $ | 428 |  |  | $ | 447 |  |  | $ | 1,431 |  |  | $ | 3,053 |  |
| Earnings per share |  |  |  |  |  |  |  |  |
| Basic: |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 0.48 |  |  | $ | 0.63 |  |  | $ | 1.67 |  |  | $ | 1.28 |  |
| Discontinued operations |  | 0.02 |  |  | (0.13) |  |  | — |  |  | 2.11 |  |
| Net earnings (loss) |  | $ | 0.50 |  |  | $ | 0.50 |  |  | $ | 1.67 |  |  | $ | 3.39 |  |
| Diluted: |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 0.47 |  |  | $ | 0.62 |  |  | $ | 1.64 |  |  | $ | 1.26 |  |
| Discontinued operations |  | 0.03 |  |  | (0.13) |  |  | 0.01 |  |  | 2.08 |  |
| Net earnings (loss) |  | $ | 0.50 |  |  | $ | 0.49 |  |  | $ | 1.65 |  |  | $ | 3.34 |  |
| Weighted-average number of shares outstanding |  |  |  |  |  |  |  |  |
| Basic |  | 848.8 |  |  | 901.2 |  |  | 856.8 |  |  | 900.9 |  |
| Diluted |  | 858.6 |  |  | 915.0 |  |  | 867.7 |  |  | 914.4 |  |

[0001783180-25-000063:8k_2_02:79]
10

[0001783180-25-000063:8k_2_02:80]
Carrier Global Corporation

[0001783180-25-000063:8k_2_02:81]
Condensed Consolidated Balance Sheet

[0001783180-25-000063:8k_2_02:82]
|  |  | (Unaudited) |
| (In millions) |  | September 30, 2025 |  | December 31, 2024 |
| Assets |  |  |  |  |
| Cash and cash equivalents |  | $ | 1,423 |  |  | $ | 3,969 |  |
| Accounts receivable, net |  | 3,129 |  |  | 2,651 |  |
| Inventories, net |  | 3,004 |  |  | 2,299 |  |
| Other current assets |  | 1,283 |  |  | 972 |  |
| Total current assets |  | 8,839 |  |  | 9,891 |  |
| Future income tax benefits |  | 1,199 |  |  | 1,131 |  |
| Fixed assets, net |  | 3,214 |  |  | 2,999 |  |
| Operating lease right-of-use assets |  | 558 |  |  | 554 |  |
| Intangible assets, net |  | 6,560 |  |  | 6,432 |  |
| Goodwill |  | 15,680 |  |  | 14,601 |  |
| Pension and post-retirement assets |  | 50 |  |  | 43 |  |
| Equity method investments |  | 1,381 |  |  | 1,194 |  |
| Other assets |  | 596 |  |  | 558 |  |
| Total Assets |  | $ | 38,077 |  |  | $ | 37,403 |  |
| Liabilities and Equity |  |  |  |  |
| Accounts payable |  | $ | 2,959 |  |  | $ | 2,458 |  |
| Accrued liabilities |  | 4,208 |  |  | 4,098 |  |
| Short-term borrowings and current portion of long-term debt |  | 580 |  |  | 1,336 |  |
| Total current liabilities |  | 7,747 |  |  | 7,892 |  |
| Long-term debt |  | 11,336 |  |  | 11,026 |  |
| Future pension and post-retirement obligations |  | 220 |  |  | 214 |  |
| Future income tax obligations |  | 1,943 |  |  | 2,015 |  |
| Operating lease liabilities |  | 424 |  |  | 432 |  |
| Other long-term liabilities |  | 1,568 |  |  | 1,429 |  |
| Total Liabilities |  | 23,238 |  |  | 23,008 |  |
| Equity |  |  |  |  |
| Common stock |  | 9 |  |  | 9 |  |
| Treasury stock |  | (6,311) |  |  | (3,915) |  |
| Additional paid-in capital |  | 8,646 |  |  | 8,610 |  |
| Retained earnings |  | 12,530 |  |  | 11,483 |  |
| Accumulated other comprehensive loss |  | (365) |  |  | (2,106) |  |
| Non-controlling interest |  | 330 |  |  | 314 |  |
| Total Equity |  | 14,839 |  |  | 14,395 |  |
| Total Liabilities and Equity |  | $ | 38,077 |  |  | $ | 37,403 |  |

[0001783180-25-000063:8k_2_02:83]
11

[0001783180-25-000063:8k_2_02:84]
Carrier Global Corporation

[0001783180-25-000063:8k_2_02:85]
Condensed Consolidated Statement of Cash Flows

[0001783180-25-000063:8k_2_02:86]
(Unaudited)

[0001783180-25-000063:8k_2_02:87]
|  |  | Three Months Ended September 30, |  | Nine Months EndedSeptember 30, |
| (In millions) |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Operating Activities |  |  |  |  |  |  |  |  |
| Net earnings (loss) |  | $ | 455 |  |  | $ | 481 |  |  | $ | 1,525 |  |  | $ | 3,139 |  |
| Discontinued operations, net of tax |  | (21) |  |  | 117 |  |  | (4) |  |  | (1,897) |  |
| Adjustments for non-cash items, net: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  | 325 |  |  | 312 |  |  | 945 |  |  | 914 |  |
| Deferred income tax provision |  | (158) |  |  | (65) |  |  | (316) |  |  | (296) |  |
| Stock-based compensation costs |  | 11 |  |  | 25 |  |  | 55 |  |  | 65 |  |
| Equity method investment net earnings |  | (60) |  |  | (66) |  |  | (182) |  |  | (187) |  |
| (Gain) loss on extinguishment of debt |  | — |  |  | (88) |  |  | — |  |  | (88) |  |
| (Gain) loss on sale of investments |  | — |  |  | (2) |  |  | (17) |  |  | (2) |  |
| Changes in operating assets and liabilities |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  | 212 |  |  | 97 |  |  | (490) |  |  | (135) |  |
| Inventories, net |  | (116) |  |  | 69 |  |  | (528) |  |  | 76 |  |
| Accounts payable and accrued liabilities |  | (208) |  |  | (260) |  |  | 170 |  |  | (258) |  |
| Distributions from equity method investments |  | 24 |  |  | 24 |  |  | 105 |  |  | 36 |  |
| Other operating activities, net |  | (140) |  |  | (45) |  |  | (187) |  |  | (159) |  |
| Net cash flows provided by (used in) continuing operating activities |  | 324 |  |  | 599 |  |  | 1,076 |  |  | 1,208 |  |
| Net cash flows provided by (used in) discontinued operating activities |  | 17 |  |  | (868) |  |  | 397 |  |  | (777) |  |
| Net cash flows provided by (used in) operating activities |  | 341 |  |  | (269) |  |  | 1,473 |  |  | 431 |  |
| Investing Activities |  |  |  |  |  |  |  |  |
| Capital expenditures |  | (117) |  |  | (92) |  |  | (261) |  |  | (302) |  |
| Investment in businesses, net of cash acquired |  | (31) |  |  | (94) |  |  | (92) |  |  | (10,873) |  |
| Dispositions of businesses |  | — |  |  | — |  |  | 8 |  |  | — |  |
| Settlement of derivative contracts, net |  | 33 |  |  | (2) |  |  | 120 |  |  | (187) |  |
| Other investing activities, net |  | (4) |  |  | 4 |  |  | (7) |  |  | 31 |  |
| Net cash flows provided by (used in) continuing investing activities |  | (119) |  |  | (184) |  |  | (232) |  |  | (11,331) |  |
| Net cash flows provided by (used in) discontinued investing activities |  | — |  |  | 1,343 |  |  | 35 |  |  | 6,217 |  |
| Net cash flows provided by (used in) investing activities |  | (119) |  |  | 1,159 |  |  | (197) |  |  | (5,114) |  |
| Financing Activities |  |  |  |  |  |  |  |  |
| Increase (decrease) in short-term borrowings, net |  | 444 |  |  | 30 |  |  | 387 |  |  | 37 |  |
| Issuance of long-term debt |  | 17 |  |  | 31 |  |  | 32 |  |  | 2,586 |  |
| Repayment of long-term debt |  | (1) |  |  | (988) |  |  | (1,209) |  |  | (4,530) |  |
| Repurchases of common stock |  | (785) |  |  | (431) |  |  | (2,413) |  |  | (431) |  |
| Dividends paid on common stock |  | (193) |  |  | (184) |  |  | (583) |  |  | (514) |  |
| Dividends paid to non-controlling interest |  | (72) |  |  | (5) |  |  | (81) |  |  | (72) |  |
| Other financing activities, net |  | (1) |  |  | (1) |  |  | (18) |  |  | (15) |  |
| Net cash flows provided by (used in) continuing financing activities |  | (591) |  |  | (1,548) |  |  | (3,885) |  |  | (2,939) |  |
| Net cash flows provided by (used in) discontinued financing activities |  | — |  |  | 4 |  |  | — |  |  | (11) |  |
| Net cash flows provided by (used in) financing activities |  | (591) |  |  | (1,544) |  |  | (3,885) |  |  | (2,950) |  |
| Effect of foreign exchange rate changes on cash and cash equivalents |  | (5) |  |  | 64 |  |  | 63 |  |  | (18) |  |
| Net increase (decrease) in cash and cash equivalents and restricted cash, including cash classified in current assets held for sale |  | (374) |  |  | (590) |  |  | (2,546) |  |  | (7,651) |  |
| Less: Change in cash balances classified as assets held for sale |  | — |  |  | (70) |  |  | — |  |  | (36) |  |
| Net increase (decrease) in cash and cash equivalents and restricted cash |  | (374) |  |  | (520) |  |  | (2,546) |  |  | (7,615) |  |
| Cash, cash equivalents and restricted cash, beginning of period |  | 1,800 |  |  | 2,758 |  |  | 3,972 |  |  | 9,853 |  |
| Cash, cash equivalents and restricted cash, end of period |  | 1,426 |  |  | 2,238 |  |  | 1,426 |  |  | 2,238 |  |
| Less: restricted cash |  | 3 |  |  | 14 |  |  | 3 |  |  | 14 |  |
| Cash and cash equivalents, end of period |  | $ | 1,423 |  |  | $ | 2,224 |  |  | $ | 1,423 |  |  | $ | 2,224 |  |

[0001783180-25-000063:8k_2_02:88]
Carrier Global Corporation

[0001783180-25-000063:8k_2_02:89]
Segment Summary

[0001783180-25-000063:8k_2_02:90]
|  | (Unaudited) |  |
|  | Three Months Ended September 30, |  | Nine Months EndedSeptember 30, |  |
| (In millions) | 2025 |  | 2024 |  | 2025 |  | 2024 |  |
| Segment net sales |  |  |  |  |  |  |  |  |  |
| Climate Solutions Americas |  | $ | 2,711 |  | $ | 2,961 |  | $ | 8,535 |  | $ | 8,186 |  |
| Climate Solutions Europe |  | 1,290 |  | 1,246 |  | 3,712 |  | 3,732 |  |
| Climate Solutions Asia Pacific, Middle East & Africa |  | 833 |  | 840 |  | 2,541 |  | 2,626 |  |
| Climate Solutions Transportation |  | 745 |  | 937 |  | 2,122 |  | 2,794 |  |
| Segment net sales |  | $ | 5,579 |  | $ | 5,984 |  | $ | 16,910 |  | $ | 17,338 |  |
| Segment operating profit |  |  |  |  |  |  |  |  |  |
| Climate Solutions Americas |  | $ | 533 |  | $ | 750 |  | $ | 1,982 |  | $ | 1,888 |  |
| Climate Solutions Europe |  | 120 |  | 129 |  | 324 |  | 389 |  |
| Climate Solutions Asia Pacific, Middle East & Africa |  | 97 |  | 106 |  | 353 |  | 371 |  |
| Climate Solutions Transportation |  | 115 |  | 137 |  | 340 |  | 388 |  |
| Segment operating profit |  | $ | 865 |  | $ | 1,122 |  | $ | 2,999 |  | $ | 3,036 |  |
| Segment operating margin |  |  |  |  |  |  |  |  |  |
| Climate Solutions Americas |  | 19.7 | % |  | 25.3 | % |  | 23.2 | % |  | 23.1 | % |  |
| Climate Solutions Europe |  | 9.3 | % |  | 10.4 | % |  | 8.7 | % |  | 10.4 | % |  |
| Climate Solutions Asia Pacific, Middle East & Africa |  | 11.6 | % |  | 12.6 | % |  | 13.9 | % |  | 14.1 | % |  |
| Climate Solutions Transportation |  | 15.4 | % |  | 14.6 | % |  | 16.0 | % |  | 13.9 | % |  |

[0001783180-25-000063:8k_2_02:91]
13

[0001783180-25-000063:8k_2_02:92]
Components of Changes in Net Sales

[0001783180-25-000063:8k_2_02:93]
| Three Months Ended September 30, 2025 Compared with Three Months Ended September 30, 2024 |
|  | (Unaudited) |
|  | Factors Contributing to Total % change in Net Sales |
|  | Organic |  | FX Translation |  | Acquisitions / Divestitures, net |  | Other |  | Total |
| Climate Solutions Americas | (8) | % |  | — | % |  | — | % |  | — | % |  | (8) | % |
| Climate Solutions Europe | (3) | % |  | 7 | % |  | — | % |  | — | % |  | 4 | % |
| Climate Solutions Asia Pacific, Middle East & Africa | (2) | % |  | 1 | % |  | — | % |  | — | % |  | (1) | % |
| Climate Solutions Transportation | 6 | % |  | 2 | % |  | (28) | % |  | — | % |  | (20) | % |
| Consolidated | (4) | % |  | 1 | % |  | (4) | % |  | — | % |  | (7) | % |

[0001783180-25-000063:8k_2_02:94]
| Nine Months Ended September 30, 2025 Compared with Nine Months Ended September 30, 2024 |
|  | (Unaudited) |
|  | Factors Contributing to Total % change in Net Sales |
|  | Organic |  | FX Translation |  | Acquisitions / Divestitures, net |  | Other |  | Total |
| Climate Solutions Americas | 4 | % |  | — | % |  | — | % |  | — | % |  | 4 | % |
| Climate Solutions Europe | (3) | % |  | 2 | % |  | — | % |  | — | % |  | (1) | % |
| Climate Solutions Asia Pacific, Middle East & Africa | (4) | % |  | 1 | % |  | — | % |  | — | % |  | (3) | % |
| Climate Solutions Transportation | 2 | % |  | 1 | % |  | (27) | % |  | — | % |  | (24) | % |
| Consolidated | 1 | % |  | 1 | % |  | (4) | % |  | — | % |  | (2) | % |

[0001783180-25-000063:8k_2_02:95]
14

[0001783180-25-000063:8k_2_02:96]
Carrier Global Corporation

[0001783180-25-000063:8k_2_02:97]
Reconciliations

[0001783180-25-000063:8k_2_02:98]
|  |  | (Unaudited) |
|  |  | Three Months Ended September 30, |  | Nine Months EndedSeptember 30, |
| (In millions) |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Reconciliation to Earnings before income taxes |  |  |  |  |  |  |  |  |
| Segment operating profit |  | $ | 865 |  |  | $ | 1,122 |  |  | $ | 2,999 |  |  | $ | 3,036 |  |
| Corporate and other |  | (42) |  |  | (78) |  |  | (162) |  |  | (172) |  |
| Restructuring costs |  | (50) |  |  | (60) |  |  | (105) |  |  | (97) |  |
| Amortization of acquired intangibles |  | (221) |  |  | (175) |  |  | (636) |  |  | (517) |  |
| Acquisition step-up amortization |  | — |  |  | (31) |  |  | — |  |  | (251) |  |
| Acquisition/divestiture-related costs |  | (13) |  |  | (15) |  |  | (32) |  |  | (87) |  |
| CCR gain |  | — |  |  | — |  |  | 7 |  |  | — |  |
| Viessmann-related hedges |  | — |  |  | — |  |  | — |  |  | (86) |  |
| Gain on liability adjustment |  | — |  |  | — |  |  | — |  |  | 46 |  |
| Non-service pension (expense) benefit |  | (9) |  |  | (1) |  |  | (8) |  |  | (1) |  |
| Interest (expense) income, net |  | (97) |  |  | 8 |  |  | (270) |  |  | (290) |  |
| Earnings before income taxes |  | $ | 433 |  |  | $ | 770 |  |  | $ | 1,793 |  |  | $ | 1,581 |  |

[0001783180-25-000063:8k_2_02:99]
|  |  | (Unaudited) |
|  |  | Three Months Ended September 30, |  | Nine Months EndedSeptember 30, |
| (In millions) |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Reconciliation of Segment operating profit to Adjusted operating profit |  |  |  |  |  |  |  |  |
| Climate Solutions Americas |  | $ | 533 |  |  | $ | 750 |  |  | $ | 1,982 |  |  | $ | 1,888 |  |
| Climate Solutions Europe |  | 120 |  |  | 129 |  |  | 324 |  |  | 389 |  |
| Climate Solutions Asia Pacific, Middle East & Africa |  | 97 |  |  | 106 |  |  | 353 |  |  | 371 |  |
| Climate Solutions Transportation |  | 115 |  |  | 137 |  |  | 340 |  |  | 388 |  |
| Segment operating profit |  | $ | 865 |  |  | $ | 1,122 |  |  | $ | 2,999 |  |  | $ | 3,036 |  |
| Corporate and other |  | (42) |  |  | (78) |  |  | (162) |  |  | (172) |  |
| Adjusted operating profit |  | $ | 823 |  |  | $ | 1,044 |  |  | $ | 2,837 |  |  | $ | 2,864 |  |

[0001783180-25-000063:8k_2_02:100]
15

[0001783180-25-000063:8k_2_02:101]
Carrier Global Corporation

[0001783180-25-000063:8k_2_02:102]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP) Results

[0001783180-25-000063:8k_2_02:103]
Net Income, Earnings Per Share and Effective Tax Rate

[0001783180-25-000063:8k_2_02:104]
|  | (Unaudited) |
|  | Three Months Ended September 30, 2025 |  | Nine Months Ended September 30, 2025 |
| (In millions, except per share amounts) | Reported |  | Adjustments |  | Adjusted |  | Reported |  | Adjustments |  | Adjusted |
| Net sales | $ | 5,579 |  |  | $ | — |  |  | $ | 5,579 |  |  | $ | 16,910 |  |  | $ | — |  |  | $ | 16,910 |  |
| Operating profit | $ | 539 |  |  | 284 |  | a | $ | 823 |  |  | $ | 2,071 |  |  | 766 |  | a | $ | 2,837 |  |
| Operating margin | 9.7 | % |  |  |  | 14.8 | % |  | 12.2 | % |  |  |  | 16.8 | % |
| Earnings before income taxes | $ | 433 |  |  | 295 |  | a, b | $ | 728 |  |  | $ | 1,793 |  |  | 777 |  | a, b | $ | 2,570 |  |
| Income tax (expense) benefit | $ | 1 |  |  | (126) |  | c | $ | (125) |  |  | $ | (272) |  |  | (259) |  | c | $ | (531) |  |
| Effective tax rate | (0.2) | % |  |  |  | 17.2 | % |  | 15.2 | % |  |  |  | 20.7 | % |
| Earnings from continuing operations attributable to common shareowners | $ | 407 |  |  | $ | 169 |  |  | $ | 576 |  |  | $ | 1,427 |  |  | $ | 518 |  |  | $ | 1,945 |  |
| Summary of Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring costs |  |  | $ | 50 |  | a |  |  |  |  | $ | 105 |  | a |  |
| Amortization of acquired intangibles |  |  | 221 |  | a |  |  |  |  | 636 |  | a |  |
| Acquisition/divestiture-related costs |  |  | 13 |  | a |  |  |  |  | 32 |  | a |  |
| CCR gain |  |  | — |  | a |  |  |  |  | (7) |  | a |  |
| Defined benefit pension settlement |  |  | 11 |  | b |  |  |  |  | 11 |  | b |  |
| Total adjustments |  |  | $ | 295 |  |  |  |  |  |  | $ | 777 |  |  |  |
| Tax effect on adjustments above |  |  | $ | (77) |  |  |  |  |  |  | $ | (204) |  |  |  |
| Tax specific adjustments |  |  | (49) |  |  |  |  |  |  | (55) |  |  |  |
| Total tax adjustments |  |  | $ | (126) |  | c |  |  |  |  | $ | (259) |  | c |  |
| Diluted shares outstanding | 858.6 |  |  |  |  | 858.6 |  |  | 867.7 |  |  |  |  | 867.7 |  |
| Diluted earnings per share: |  |  |  |  |  |  |  |  |  |  |  |
| Continuing operations | $ | 0.47 |  |  |  |  | $ | 0.67 |  |  | $ | 1.64 |  |  |  |  | $ | 2.24 |  |

[0001783180-25-000063:8k_2_02:105]
16

[0001783180-25-000063:8k_2_02:106]
Carrier Global Corporation

[0001783180-25-000063:8k_2_02:107]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP) Results

[0001783180-25-000063:8k_2_02:108]
Net Income, Earnings Per Share and Effective Tax Rate

[0001783180-25-000063:8k_2_02:109]
|  | (Unaudited) |
|  | Three Months Ended September 30, 2024 |  | Nine Months Ended September 30, 2024 |
| (In millions, except per share amounts) | Reported |  | Adjustments |  | Adjusted |  | Reported |  | Adjustments |  | Adjusted |
| Net sales | $ | 5,984 |  |  | $ | — |  |  | $ | 5,984 |  |  | $ | 17,338 |  |  | $ | — |  |  | $ | 17,338 |  |
| Operating profit | $ | 763 |  |  | 281 |  | a | $ | 1,044 |  |  | $ | 1,872 |  |  | 992 |  | a | $ | 2,864 |  |
| Operating margin | 12.8 | % |  |  |  | 17.4 | % |  | 10.8 | % |  |  |  | 16.5 | % |
| Earnings before income taxes | $ | 770 |  |  | 195 |  | a, b | $ | 965 |  |  | $ | 1,581 |  |  | 918 |  | a, b | $ | 2,499 |  |
| Income tax (expense) benefit | $ | (172) |  |  | (54) |  | c | $ | (226) |  |  | $ | (339) |  |  | (227) |  | c | $ | (566) |  |
| Effective tax rate | 22.2 | % |  |  |  | 23.3 | % |  | 21.4 | % |  |  |  | 22.6 | % |
| Earnings from continuing operations attributable to common shareowners | $ | 564 |  |  | $ | 141 |  |  | $ | 705 |  |  | $ | 1,156 |  |  | $ | 691 |  |  | $ | 1,847 |  |
| Summary of Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring costs |  |  | 60 |  | a |  |  |  |  | 97 |  | a |  |
| Amortization of acquired intangibles |  |  | $ | 175 |  | a |  |  |  |  | $ | 517 |  | a |  |
| Acquisition/divestiture-related costs |  |  | 15 |  | a |  |  |  |  | 87 |  | a |  |
| Acquisition step-up amortization (1) |  |  | 31 |  | a |  |  |  |  | 251 |  | a |  |
| Viessmann-related hedges |  |  | — |  | a |  |  |  |  | 86 |  | a |  |
| Gain on liability adjustment (2) |  |  | — |  | a |  |  |  |  | (46) |  | a |  |
| Debt extinguishment (gain) |  |  | (97) |  | b |  |  |  |  | (97) |  | b |  |
| Debt prepayment costs |  |  | $ | 11 |  | b |  |  |  |  | $ | 23 |  | b |  |
| Total adjustments |  |  | $ | 195 |  |  |  |  |  |  | $ | 918 |  |  |  |
| Tax effect on adjustments above |  |  | $ | (54) |  |  |  |  |  |  | $ | (227) |  |  |  |
| Total tax adjustments |  |  | $ | (54) |  | c |  |  |  |  | $ | (227) |  | c |  |
| Diluted shares outstanding | 915.0 |  |  |  |  | 915.0 |  |  | 914.4 |  |  |  |  | 914.4 |  |
| Diluted earnings per share: |  |  |  |  |  |  |  |  |  |  |  |
| Continuing operations | $ | 0.62 |  |  |  |  | $ | 0.77 |  |  | $ | 1.26 |  |  |  |  | $ | 2.02 |  |

[0001783180-25-000063:8k_2_02:110]
(1) Amortization of the step-up to fair value of acquired inventory and backlog.

[0001783180-25-000063:8k_2_02:111]
(2) Gain associated with an adjustment to our tax-related liability owed to UTC.

[0001783180-25-000063:8k_2_02:112]
17

[0001783180-25-000063:8k_2_02:113]
Free Cash Flow Reconciliation

[0001783180-25-000063:8k_2_02:114]
|  |  | (Unaudited) |
|  |  | Three Months Ended September 30, |  | Nine Months EndedSeptember 30, |
| (In millions) |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Net cash flows provided by operating activities |  | $ | 341 |  |  | $ | (269) |  |  | $ | 1,473 |  |  | $ | 431 |  |
| Less: Capital expenditures - continuing operations |  | (117) |  |  | (92) |  |  | (261) |  |  | (302) |  |
| Less: Capital expenditures - discontinued operations |  | — |  |  | (5) |  |  | — |  |  | (10) |  |
| Free cash flow |  | $ | 224 |  |  | $ | (366) |  |  | $ | 1,212 |  |  | $ | 119 |  |

[0001783180-25-000063:8k_2_02:115]
Net Debt Reconciliation

[0001783180-25-000063:8k_2_02:116]
|  |  | (Unaudited) |
| (In millions) |  | September 30, 2025 |  | December 31, 2024 |
| Long-term debt |  | $ | 11,336 |  |  | $ | 11,026 |  |
| Short-term borrowings and current portion of long-term debt |  | 580 |  |  | 1,336 |  |
| Less: Cash and cash equivalents |  | 1,423 |  |  | 3,969 |  |
| Net debt |  | $ | 10,493 |  |  | $ | 8,393 |  |

[0001783180-25-000063:8k_2_02:117]
18
