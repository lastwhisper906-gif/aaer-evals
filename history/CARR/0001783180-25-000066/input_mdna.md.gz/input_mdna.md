# CARR MD&A — 0001783180-25-000066


## mdna

[0001783180-25-000066:mdna:1]
[same as prior period, unchanged from 0001783180-25-000052:mdna:1]

[0001783180-25-000066:mdna:2]
[same as prior period, unchanged from 0001783180-25-000052:mdna:2]

[0001783180-25-000066:mdna:3]
[same as prior period, unchanged from 0001783180-25-000052:mdna:3]

[0001783180-25-000066:mdna:4]
[same as prior period, unchanged from 0001783180-25-000052:mdna:4]

[0001783180-25-000066:mdna:5]
[same as prior period, unchanged from 0001783180-25-000052:mdna:5]

[0001783180-25-000066:mdna:6]
[same as prior period, unchanged from 0001783180-25-000052:mdna:6]

[0001783180-25-000066:mdna:7]
[same as prior period, unchanged from 0001783180-25-000052:mdna:7]

[0001783180-25-000066:mdna:8]
[same as prior period, unchanged from 0001783180-25-000052:mdna:8]

[0001783180-25-000066:mdna:9]
[same as prior period, unchanged from 0001783180-25-000052:mdna:9]

[0001783180-25-000066:mdna:10]
[same as prior period, unchanged from 0001783180-25-000052:mdna:10]

[0001783180-25-000066:mdna:11]
[same as prior period, unchanged from 0001783180-25-000052:mdna:34]

[0001783180-25-000066:mdna:12]
[same as prior period, unchanged from 0001783180-25-000052:mdna:12]

[0001783180-25-000066:mdna:13]
[same as prior period, unchanged from 0001783180-25-000052:mdna:13]

[0001783180-25-000066:mdna:14]
[same as prior period, unchanged from 0001783180-25-000052:mdna:16]

[0001783180-25-000066:mdna:15]
Preparation of our financial statements requires management to make estimates and assumptions that affect the reported amounts of assets, liabilities, sales and expenses. We believe that the most complex and sensitive judgments, because of their potential significance to the accompanying Unaudited Condensed Consolidated Financial Statements, result primarily from the need to make estimates about the effects of matters that are inherently uncertain. In "Management’s Discussion and Analysis of Financial Condition and Results of Operations" of our 2024 Form 10-K, we describe the significant accounting estimates and policies used in the preparation of the accompanying Unaudited Condensed Consolidated Financial Statements. There have been no significant changes in our critical accounting estimates.

[0001783180-25-000066:mdna:16]
[same as prior period, unchanged from 0001783180-25-000052:mdna:18]

[0001783180-25-000066:mdna:17]
Three Months Ended September 30, 2025 Compared with the Three Months Ended September 30, 2024

[0001783180-25-000066:mdna:18]
[same as prior period, unchanged from 0001783180-25-000052:mdna:20]

[0001783180-25-000066:mdna:19]
|  |  | Three Months Ended September 30, |
| (In millions) |  | 2025 |  | 2024 |  | Period Change |  | % Change |
| Net sales |  | $ | 5,579 |  |  | $ | 5,984 |  |  | $ | (405) |  |  | (7) | % |
| Cost of products and services sold |  | (4,130) |  |  | (4,307) |  |  | 177 |  |  | (4) | % |
| Gross margin |  | 1,449 |  |  | 1,677 |  |  | (228) |  |  | (14) | % |
| Operating expenses |  | (910) |  |  | (914) |  |  | 4 |  |  | — | % |
| Operating profit |  | 539 |  |  | 763 |  |  | (224) |  |  | (29) | % |
| Non-operating income (expense), net |  | (106) |  |  | 7 |  |  | (113) |  |  | (1614) | % |
| Earnings (loss) before income taxes |  | 433 |  |  | 770 |  |  | (337) |  |  | (44) | % |
| Income tax expense |  | 1 |  |  | (172) |  |  | 173 |  |  | (101) | % |
| Earnings (loss) from continuing operations |  | 434 |  |  | 598 |  |  | (164) |  |  | (27) | % |
| Discontinued operations, net of income taxes |  | 21 |  |  | (117) |  |  | 138 |  |  | (118) | % |
| Net earnings (loss) |  | 455 |  |  | 481 |  |  | (26) |  |  | (5) | % |
| Less: Non-controlling interest in subsidiaries' earnings from operations |  | 27 |  |  | 34 |  |  | (7) |  |  | (21) | % |
| Net earnings (loss) attributable to common shareowners |  | $ | 428 |  |  | $ | 447 |  |  | $ | (19) |  |  | (4) | % |

[0001783180-25-000066:mdna:20]
[same as prior period, unchanged from 0001783180-25-000052:mdna:23]

[0001783180-25-000066:mdna:21]
For the three months ended September 30, 2025, Net sales were $5.6 billion, a 7% decrease compared with the same period of 2024. The components of the year-over-year change were as follows:

[0001783180-25-000066:mdna:22]
|  |  | Three Months Ended September 30, |
| Organic |  | (4) | % |
| Foreign currency translation |  | 1 | % |
| Acquisitions and divestitures, net |  | (4) | % |
| Total % change |  | (7) | % |

[0001783180-25-000066:mdna:23]
Organic sales for the three months ended September 30, 2025, decreased by 4% compared with the same period of 2024. The organic decrease was primarily due to our Climate Solutions Americas segment as reduced end-market demand and distributor destocking in our residential business impacted the segment. In addition, lower end-market demand in both our Climate Solutions Europe and Climate Solutions Asia Pacific, Middle East & Africa segments further impacted overall results. These results were partially offset by improved end-market demand in Climate Solutions Transportation. Refer to "Segment Review" below for a discussion of Net sales by segment.

[0001783180-25-000066:mdna:24]
[same as prior period, unchanged from 0001783180-25-000052:mdna:27]

[0001783180-25-000066:mdna:25]
For the three months ended September 30, 2025, gross margin was $1.4 billion, a 14% decrease compared with the same period of 2024. The components were as follows:

[0001783180-25-000066:mdna:26]
|  |  | Three Months Ended September 30, |
| (In millions) |  | 2025 |  | 2024 |
| Net sales |  | $ | 5,579 |  |  | $ | 5,984 |  |
| Cost of products and services sold |  | (4,130) |  |  | (4,307) |  |
| Gross margin |  | $ | 1,449 |  |  | $ | 1,677 |  |
| Percentage of net sales |  | 26.0 | % |  | 28.0 | % |

[0001783180-25-000066:mdna:27]
Gross margin decreased by $228 million compared with the three months ended September 30, 2024 primarily due to lower volumes in certain end-markets. As a result, gross margin as a percentage of Net sales decreased by 200 basis points compared with the same period of 2024. The prior period included inventory step-up and backlog amortization resulting from the recognition of acquired assets of the VCS Business at fair value which are now fully amortized. These costs had a 50 basis point unfavorable impact on the prior period gross margin as a percentage of Net sales. The decrease was partially offset by ongoing customer demand in certain end-markets and our continued focus on productivity initiatives.

[0001783180-25-000066:mdna:28]
[same as prior period, unchanged from 0001783180-25-000052:mdna:51]

[0001783180-25-000066:mdna:29]
[same as prior period, unchanged from 0001783180-25-000052:mdna:31]

[0001783180-25-000066:mdna:30]
For the three months ended September 30, 2025, operating expenses, including Equity method investment net earnings, were $910 million, flat compared with the same period of 2024. The components were as follows:

[0001783180-25-000066:mdna:31]
|  |  | Three Months Ended September 30, |
| (In millions) |  | 2025 |  | 2024 |
| Selling, general and administrative |  | $ | (803) |  |  | $ | (799) |  |
| Research and development |  | (151) |  |  | (172) |  |
| Equity method investment net earnings |  | 60 |  |  | 66 |  |
| Other income (expense), net |  | (16) |  |  | (9) |  |
| Total operating expenses |  | $ | (910) |  |  | $ | (914) |  |
| Percentage of net sales |  | 16.3 | % |  | 15.3 | % |

[0001783180-25-000066:mdna:32]
For the three months ended September 30, 2025, Selling, general and administrative expenses were $803 million, a 1% increase compared with the same period of 2024. The increase primarily relates to foreign currency translation. In addition, employee-related costs associated with our portfolio transformation further impacted results. These costs were partially offset by lower compensation costs and synergies associated with the integration of the VCS Business. The current period also included $13 million of acquisition and divestiture-related costs compared with $15 million during the three months ended September 30, 2024.

[0001783180-25-000066:mdna:33]
[same as prior period, unchanged from 0001783180-25-000052:mdna:36]

[0001783180-25-000066:mdna:34]
Investments over which we do not exercise control, but have significant influence, are accounted for using the equity method of accounting. For the three months ended September 30, 2025, Equity method investment net earnings were $60 million, a 9% decrease compared with the same period of 2024. The decrease was primarily driven by lower earnings in joint ventures within Climate Solutions Americas.

[0001783180-25-000066:mdna:35]
Other income (expense), net primarily includes the impact of gains and losses related to the sale of businesses or interests in our equity method investments, foreign currency gains and losses on transactions that are denominated in a currency other than an entity's functional currency and hedging-related activities.

[0001783180-25-000066:mdna:36]
[same as prior period, unchanged from 0001783180-25-000052:mdna:39]

[0001783180-25-000066:mdna:37]
For the three months ended September 30, 2025, Non-operating income (expense), net was $106 million, a 1,614% decrease compared with the same period of 2024. The components were as follows:

[0001783180-25-000066:mdna:38]
|  |  | Three Months Ended September 30, |
| (In millions) |  | 2025 |  | 2024 |
| Non-service pension (expense) benefit |  | $ | (9) |  |  | $ | (1) |  |
| Interest expense |  | $ | (116) |  |  | $ | (131) |  |
| Interest income |  | 19 |  |  | 139 |  |
| Interest (expense) income, net |  | $ | (97) |  |  | $ | 8 |  |
| Non-operating income (expense), net |  | $ | (106) |  |  | $ | 7 |  |

[0001783180-25-000066:mdna:39]
Non-operating income (expense), net includes the results from activities other than normal business operations such as interest expense, interest income and the non-service components of pension and post-retirement obligations. Interest expense is affected by the amount of debt outstanding and the interest rates on that debt. For the three months ended September 30, 2025, Interest expense was $116 million, an 11% decrease compared with the same period of 2024. Consistent with our capital allocation strategy, we reduced our outstanding debt by approximately $3 billion over the course of 2024 and repaid an additional $1.2 billion in 2025. During the three months ended September 30, 2024, our debt repayments resulted in an $11 million write off of unamortized deferred financing costs in Interest expense and recognition of a net gain of $97 million in Interest income.

[0001783180-25-000066:mdna:40]
[same as prior period, unchanged from 0001783180-25-000052:mdna:14]

[0001783180-25-000066:mdna:41]
|  |  | Three Months Ended September 30, |
|  |  | 2025 |  | 2024 |
| Effective tax rate |  | (0.2) | % |  | 22.3 | % |

[0001783180-25-000066:mdna:42]
We account for income tax expense in accordance with ASC 740, which requires an estimate of the annual effective income tax rate for the full year to be applied to the respective interim period, taking into account year-to-date amounts and projected results for the full year. The effective tax rate for the three months ended September 30, 2025, was a 0.2% benefit compared with 22.3% for the three months ended September 30, 2024. The effective tax rate for the three months ended September 30, 2025, was lower than the effective tax rate for the three months ended September 30, 2024, primarily due to a net tax benefit of $64 million from changes to the German effective rate and a statutory reduction to the German corporate tax rate enacted during the current period and a tax benefit of $49 million from the re-organization of a Japanese subsidiary.

[0001783180-25-000066:mdna:43]
[same as prior period, unchanged from 0001783180-25-000052:mdna:47]

[0001783180-25-000066:mdna:44]
[same as prior period, unchanged from 0001783180-25-000052:mdna:48]

[0001783180-25-000066:mdna:45]
|  |  | Three Months Ended September 30, |  |  |
| (In millions) |  | 2025 |  | 2024 |  |  |  |  |
| Reconciliation to Adjusted operating profit |  |  |  |  |  |  |  |  |
| Operating profit |  | $ | 539 |  |  | $ | 763 |  |  |  |  |  |
| Restructuring costs |  | 50 |  |  | 60 |  |  |  |  |  |
| Amortization of acquired intangibles |  | 221 |  |  | 175 |  |  |  |  |  |
| Acquisition step-up amortization |  | — |  |  | 31 |  |  |  |  |  |
| Acquisition/divestiture-related costs |  | 13 |  |  | 15 |  |  |  |  |  |
| Adjusted operating profit |  | $ | 823 |  |  | $ | 1,044 |  |  |  |  |  |

[0001783180-25-000066:mdna:46]
[same as prior period, unchanged from 0001783180-25-000052:mdna:50]

[0001783180-25-000066:mdna:47]
36

[0001783180-25-000066:mdna:48]
Nine Months Ended September 30, 2025 Compared with the Nine Months Ended September 30, 2024

[0001783180-25-000066:mdna:49]
[same as prior period, unchanged from 0001783180-25-000052:mdna:53]

[0001783180-25-000066:mdna:50]
|  |  | Nine Months Ended September 30, |
| (In millions) |  | 2025 |  | 2024 |  | Period Change |  | % Change |
| Net sales |  | $ | 16,910 |  |  | $ | 17,338 |  |  | $ | (428) |  |  | (2) | % |
| Cost of products and services sold |  | (12,247) |  |  | (12,701) |  |  | 454 |  |  | (4) | % |
| Gross margin |  | 4,663 |  |  | 4,637 |  |  | 26 |  |  | 1 | % |
| Operating expenses |  | (2,592) |  |  | (2,765) |  |  | 173 |  |  | (6) | % |
| Operating profit |  | 2,071 |  |  | 1,872 |  |  | 199 |  |  | 11 | % |
| Non-operating income (expense), net |  | (278) |  |  | (291) |  |  | 13 |  |  | (4) | % |
| Earnings (loss) before income taxes |  | 1,793 |  |  | 1,581 |  |  | 212 |  |  | 13 | % |
| Income tax expense |  | (272) |  |  | (339) |  |  | 67 |  |  | (20) | % |
| Earnings (loss) from continuing operations |  | 1,521 |  |  | 1,242 |  |  | 279 |  |  | 22 | % |
| Discontinued operations, net of income taxes |  | 4 |  |  | 1,897 |  |  | (1,893) |  |  | (100) | % |
| Net earnings (loss) |  | 1,525 |  |  | 3,139 |  |  | (1,614) |  |  | (51) | % |
| Less: Non-controlling interest in subsidiaries' earnings from operations |  | 94 |  |  | 86 |  |  | 8 |  |  | 9 | % |
| Net earnings (loss) attributable to common shareowners |  | $ | 1,431 |  |  | $ | 3,053 |  |  | $ | (1,622) |  |  | (53) | % |

[0001783180-25-000066:mdna:51]
[same as prior period, unchanged from 0001783180-25-000052:mdna:55]

[0001783180-25-000066:mdna:52]
For the nine months ended September 30, 2025, Net sales were $16.9 billion, a 2% decrease compared with the same period of 2024. The components of the year-over-year change were as follows:

[0001783180-25-000066:mdna:53]
|  |  | Nine Months EndedSeptember 30, |
| Organic |  | 1 | % |
| Foreign currency translation |  | 1 | % |
| Acquisitions and divestitures, net |  | (4) | % |
| Total % change |  | (2) | % |

[0001783180-25-000066:mdna:54]
Organic sales for the nine months ended September 30, 2025 increased by 1% compared with the same period of 2024. The organic increase was primarily due to our Climate Solutions Americas segment as ongoing demand in certain end-markets continued to drive higher volumes. In addition, improved end-market demand in our Climate Solutions Transportation segment further benefited results. These amounts were partially offset by lower end-market demand in both Climate Solutions Europe and Climate Solutions Asia Pacific, Middle East & Africa. Refer to "Segment Review" below for a discussion of Net sales by segment.

[0001783180-25-000066:mdna:55]
[same as prior period, unchanged from 0001783180-25-000052:mdna:78]

[0001783180-25-000066:mdna:56]
[same as prior period, unchanged from 0001783180-25-000052:mdna:60]

[0001783180-25-000066:mdna:57]
For the nine months ended September 30, 2025, gross margin was $4.7 billion, a 1% increase compared with the same period of 2024. The components were as follows:

[0001783180-25-000066:mdna:58]
|  |  | Nine Months EndedSeptember 30, |  |  |  |  |
| (In millions) |  | 2025 |  | 2024 |  |  |  |  |
| Net sales |  | $ | 16,910 |  |  | $ | 17,338 |  |  |  |  |  |
| Cost of products and services sold |  | (12,247) |  |  | (12,701) |  |  |  |  |  |
| Gross margin |  | $ | 4,663 |  |  | $ | 4,637 |  |  |  |  |  |
| Percentage of net sales |  | 27.6 | % |  | 26.7 | % |  |  |  |  |

[0001783180-25-000066:mdna:59]
Gross margin increased by $26 million compared with the nine months ended September 30, 2024 primarily due to higher volumes in certain end-markets and our continued focus on productivity initiatives. As a result, gross margin as a percentage of Net sales increased by 90 basis points compared with the same period of 2024. The prior period included inventory step-up and backlog amortization resulting from the recognition of acquired assets of the VCS Business at fair value which are now fully amortized. These costs had a 150 basis point unfavorable impact on the prior period gross margin as a percentage of Net sales.

[0001783180-25-000066:mdna:60]
[same as prior period, unchanged from 0001783180-25-000052:mdna:64]

[0001783180-25-000066:mdna:61]
For the nine months ended September 30, 2025, operating expenses, including Equity method investment net earnings, were $2.6 billion, a 6% decrease compared with the same period of 2024. The components were as follows:

[0001783180-25-000066:mdna:62]
|  |  | Nine Months EndedSeptember 30, |
| (In millions) |  | 2025 |  | 2024 |
| Selling, general and administrative |  | $ | (2,345) |  |  | $ | (2,394) |  |
| Research and development |  | (465) |  |  | (524) |  |
| Equity method investment net earnings |  | 182 |  |  | 187 |  |
| Other income (expense), net |  | 36 |  |  | (34) |  |
| Total operating expenses |  | $ | (2,592) |  |  | $ | (2,765) |  |
| Percentage of net sales |  | 15.3 | % |  | 15.9 | % |

[0001783180-25-000066:mdna:63]
For the nine months ended September 30, 2025, Selling, general and administrative expenses were $2.3 billion, a 2% decrease compared with the same period of 2024. The decrease relates to productivity initiatives associated with our portfolio transformation and synergies associated with the integration of the VCS Business. These benefits were partially offset by higher foreign currency translation, compensation and other employee-related costs. In addition, the current period also included $33 million of acquisition and divestiture-related costs compared with $87 million during the nine months ended September 30, 2024.

[0001783180-25-000066:mdna:64]
[same as prior period, unchanged from 0001783180-25-000052:mdna:68]

[0001783180-25-000066:mdna:65]
Investments over which we do not exercise control, but have significant influence, are accounted for using the equity method of accounting. For the nine months ended September 30, 2025, Equity method investment net earnings were $182 million, a 3% decrease compared with the same period of 2024. The decrease was primarily driven by lower earnings in joint ventures within Climate Solutions Americas.

[0001783180-25-000066:mdna:66]
Other income (expense), net primarily includes the impact of gains and losses related to the sale of businesses or interests in our equity method investments, foreign currency gains and losses on transactions that are denominated in a currency other than an entity's functional currency and hedging-related activities. During the nine months ended September 30, 2025, we finalized the working capital and other adjustments provided in the stock purchase agreement governing the sale of CCR. In connection with the acquisition of the VCS Business, we recognized an $86 million loss during the nine months ended September 30, 2024, on the mark-to-market valuation of our window forward contracts associated with the expected cash outflows of the Euro-denominated purchase price of the VCS Business. In addition, we recognized a $46 million gain associated with the TMA and UTC's conclusion of certain income tax matters from their 2017 and 2018 tax audit with the Internal Revenue Service ("IRS").

[0001783180-25-000066:mdna:67]
[same as prior period, unchanged from 0001783180-25-000052:mdna:71]

[0001783180-25-000066:mdna:68]
For the nine months ended September 30, 2025, Non-operating income (expense), net was $278 million, a 5% decrease compared with the same period of 2024. The components were as follows:

[0001783180-25-000066:mdna:69]
|  |  | Nine Months EndedSeptember 30, |
| (In millions) |  | 2025 |  | 2024 |
| Non-service pension (expense) benefit |  | $ | (8) |  |  | $ | (1) |  |
| Interest expense |  | $ | (343) |  |  | $ | (462) |  |
| Interest income |  | 73 |  |  | 172 |  |
| Interest (expense) income, net |  | $ | (270) |  |  | $ | (290) |  |
| Non-operating income (expense), net |  | $ | (278) |  |  | $ | (291) |  |

[0001783180-25-000066:mdna:70]
Non-operating income (expense), net includes the results from activities other than normal business operations such as interest expense, interest income and the non-service components of pension and post-retirement obligations. Interest expense is affected by the amount of debt outstanding and the interest rates on that debt. For the nine months ended September 30, 2025, Interest expense was $343 million, a 26% decrease compared with the same period of 2024. Consistent with our capital allocation strategy, we reduced our outstanding debt by approximately $3 billion over the course of 2024 and repaid an additional $1.2 billion during 2025. During the nine months ended September 30, 2024, our debt repayments resulted in a make-whole premium of $8 million in Interest expense, an $11 million write off of unamortized deferred financing costs in Interest expense and recognition of a net gain of $97 million in Interest income.

[0001783180-25-000066:mdna:71]
[same as prior period, unchanged from 0001783180-25-000052:mdna:43]

[0001783180-25-000066:mdna:72]
|  |  | Nine Months EndedSeptember 30, |  |  |
|  |  | 2025 |  | 2024 |  |  |  |  |
| Effective tax rate |  | 15.2 | % |  | 21.4 | % |  |  |  |  |

[0001783180-25-000066:mdna:73]
We account for income tax expense in accordance with ASC 740, which requires an estimate of the annual effective income tax rate for the full year to be applied to the respective interim period, taking into account year-to-date amounts and projected results for the full year. The effective tax rate was 15.2% for the nine months ended September 30, 2025, compared with 21.4% for the nine months ended September 30, 2024. The year-over-year decrease was primarily driven by a net tax benefit of $64 million from changes to the German effective rate and a statutory reduction to the German corporate tax rate enacted during the current period, a tax benefit of $49 million from the re-organization of a Japanese subsidiary and a $16 million tax benefit generated by the purchase of investment tax credits from a third-party. These amounts were partially offset by the absence of a $21 million tax benefit associated with the TMA and UTC's conclusion of certain income tax matters from their 2017 and 2018 tax audit with the IRS recognized during the nine months ended September 30, 2024.

[0001783180-25-000066:mdna:74]
[same as prior period, unchanged from 0001783180-25-000052:mdna:96]

[0001783180-25-000066:mdna:75]
[same as prior period, unchanged from 0001783180-25-000052:mdna:79]

[0001783180-25-000066:mdna:76]
[same as prior period, unchanged from 0001783180-25-000052:mdna:80]

[0001783180-25-000066:mdna:77]
|  |  |  |  | Nine Months EndedSeptember 30, |
| (In millions) |  |  |  |  |  | 2025 |  | 2024 |
| Reconciliation to Adjusted operating profit |  |  |  |  |  |  |  |  |
| Operating profit |  |  |  |  |  | $ | 2,071 |  |  | $ | 1,872 |  |
| Restructuring costs |  |  |  |  |  | 105 |  |  | 97 |  |
| Amortization of acquired intangibles |  |  |  |  |  | 636 |  |  | 517 |  |
| Acquisition step-up amortization |  |  |  |  |  | — |  |  | 251 |  |
| Acquisition/divestiture-related costs |  |  |  |  |  | 32 |  |  | 87 |  |
| CCR gain |  |  |  |  |  | (7) |  |  | — |  |
| Viessmann-related hedges |  |  |  |  |  | — |  |  | 86 |  |
| Gain on liability adjustment |  |  |  |  |  | — |  |  | (46) |  |
| Adjusted operating profit |  |  |  |  |  | $ | 2,837 |  |  | $ | 2,864 |  |

[0001783180-25-000066:mdna:78]
[same as prior period, unchanged from 0001783180-25-000052:mdna:82]

[0001783180-25-000066:mdna:79]
[same as prior period, unchanged from 0001783180-25-000052:mdna:84]

[0001783180-25-000066:mdna:80]
[same as prior period, unchanged from 0001783180-25-000052:mdna:85]

[0001783180-25-000066:mdna:81]
[same as prior period, unchanged from 0001783180-25-000052:mdna:86]

[0001783180-25-000066:mdna:82]
[same as prior period, unchanged from 0001783180-25-000052:mdna:87]

[0001783180-25-000066:mdna:83]
[same as prior period, unchanged from 0001783180-25-000052:mdna:88]

[0001783180-25-000066:mdna:84]
[same as prior period, unchanged from 0001783180-25-000052:mdna:89]

[0001783180-25-000066:mdna:85]
[same as prior period, unchanged from 0001783180-25-000052:mdna:90]

[0001783180-25-000066:mdna:86]
Three Months Ended September 30, 2025 Compared with Three Months Ended September 30, 2024

[0001783180-25-000066:mdna:87]
[same as prior period, unchanged from 0001783180-25-000052:mdna:92]

[0001783180-25-000066:mdna:88]
|  |  | Net sales |  | Segment operating profit |  | Segment operating profit margin |
|  |  | Three Months Ended September 30, |  | Three Months Ended September 30, |  | Three Months Ended September 30, |
| (In millions) |  | 2025 |  | 2024 |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Climate Solutions Americas |  | $ | 2,711 |  |  | $ | 2,961 |  |  | $ | 533 |  |  | $ | 750 |  |  | 19.7 | % |  | 25.3 | % |
| Climate Solutions Europe |  | 1,290 |  |  | 1,246 |  |  | 120 |  |  | 129 |  |  | 9.3 | % |  | 10.4 | % |
| Climate Solutions Asia Pacific, Middle East & Africa |  | 833 |  |  | 840 |  |  | 97 |  |  | 106 |  |  | 11.6 | % |  | 12.6 | % |
| Climate Solutions Transportation |  | 745 |  |  | 937 |  |  | 115 |  |  | 137 |  |  | 15.4 | % |  | 14.6 | % |
| Total segment |  | $ | 5,579 |  |  | $ | 5,984 |  |  | $ | 865 |  |  | $ | 1,122 |  |  | 15.5 | % |  | 18.8 | % |

[0001783180-25-000066:mdna:89]
[same as prior period, unchanged from 0001783180-25-000052:mdna:94]

[0001783180-25-000066:mdna:90]
|  |  | Three Months Ended September 30, |
| (In millions) |  | 2025 |  | 2024 |
| Segment operating profit |  | $ | 865 |  |  | $ | 1,122 |  |
| Corporate and other |  | (42) |  |  | (78) |  |
| Adjusted operating profit |  | $ | 823 |  |  | $ | 1,044 |  |

[0001783180-25-000066:mdna:91]
41

[0001783180-25-000066:mdna:92]
[same as prior period, unchanged from 0001783180-25-000052:mdna:97]

[0001783180-25-000066:mdna:93]
For the three months ended September 30, 2025, Net sales were $2.7 billion, an 8% decrease compared with the same period of 2024. The components of the year-over-year change were as follows:

[0001783180-25-000066:mdna:94]
|  |  | Net sales |
| Organic |  | (8) | % |
| Foreign currency translation |  | — | % |
| Total % change in Net sales |  | (8) | % |

[0001783180-25-000066:mdna:95]
The organic decrease in Net sales of 8% was driven by volume reductions within certain end-markets compared with the prior year. Growth in our commercial business (up 28%) was primarily driven by ongoing customer demand and improved price. These results were more than offset by lower volume in our residential business (down 30%) primarily due to reduced end-market demand and distributor destocking. These amounts were partially offset by favorable mix and improved price. In addition, lower volume in our light commercial business (down 4%) further impacted segment results.

[0001783180-25-000066:mdna:96]
For the three months ended September 30, 2025, Segment operating profit was $533 million, a 29% decrease compared with the same period of 2024. The components of the year-over-year change were as follows:

[0001783180-25-000066:mdna:97]
|  |  | Segment operating profit |
| Operational |  | (29) | % |
| Foreign currency translation |  | — | % |
| Total % change in Segment operating profit |  | (29) | % |

[0001783180-25-000066:mdna:98]
The segment operational profit decrease of 29% was primarily attributable to volume reductions in certain end-markets compared with the prior year. In addition, unfavorable productivity, higher selling, general and administrative expenses and lower earnings from equity method investments further impacted the segment. These amounts were partially offset by favorable mix and improved price.

[0001783180-25-000066:mdna:99]
[same as prior period, unchanged from 0001783180-25-000052:mdna:104]

[0001783180-25-000066:mdna:100]
For the three months ended September 30, 2025, Net sales were $1.3 billion, a 4% increase compared with the same period of 2024. The components of the year-over-year change were as follows:

[0001783180-25-000066:mdna:101]
|  |  | Net sales |
| Organic |  | (3) | % |
| Foreign currency translation |  | 7 | % |
| Total % change in Net sales |  | 4 | % |

[0001783180-25-000066:mdna:102]
The organic decrease in Net sales of 3% was driven by volume reductions in each of the segment's businesses compared with the prior year. Results in our commercial business were down (down 4%) due to lower volumes across the region, partially offset by improved price. In addition, results in our residential and light commercial business were down (down 2%) due to lower volumes across the region as economic conditions, inflationary cost pressures and regulatory uncertainty impacted end-market demand.

[0001783180-25-000066:mdna:103]
For the three months ended September 30, 2025, Segment operating profit was $120 million, a 7% decrease compared with the same period of 2024. The components of the year-over-year change were as follows:

[0001783180-25-000066:mdna:104]
|  |  | Segment operating profit |
| Operational |  | (11) | % |
| Foreign currency translation |  | 4 | % |
| Total % change in Segment operating profit |  | (7) | % |

[0001783180-25-000066:mdna:105]
The segment operational profit decrease of 11% was primarily attributable to volume reductions in each of the segment's businesses compared with the prior year. In addition, unfavorable product and geographical mix further impacted the segment. These amounts were partially offset by integration synergies associated with the acquisition of the VCS Business and lower selling, general and administrative costs.

[0001783180-25-000066:mdna:106]
[same as prior period, unchanged from 0001783180-25-000052:mdna:111]

[0001783180-25-000066:mdna:107]
For the three months ended September 30, 2025, Net sales were $833 million, a 1% decrease compared with the same period of 2024. The components of the year-over-year change were as follows:

[0001783180-25-000066:mdna:108]
|  |  | Net sales |
| Organic |  | (2) | % |
| Foreign currency translation |  | 1 | % |
| Total % change in Net sales |  | (1) | % |

[0001783180-25-000066:mdna:109]
The organic decrease in Net sales of 2% was driven by volume reductions within certain end-markets compared with the prior year. Results in China decreased (down 8%) as residential end-markets experienced economic challenges impacting both demand and price. These results were partially offset by growth within commercial end-markets in China. In addition, ongoing end-market demand and improved price in the region's remaining geographies further benefitted the segment.

[0001783180-25-000066:mdna:110]
For the three months ended September 30, 2025, Segment operating profit was $97 million, an 8% decrease compared with the same period of 2024. The components of the year-over-year change were as follows:

[0001783180-25-000066:mdna:111]
|  |  | Segment operating profit |
| Operational |  | (13) | % |
| Foreign currency translation |  | 4 | % |
| Acquisitions and divestitures, net |  | 1 | % |
| Total % change in Segment operating profit |  | (8) | % |

[0001783180-25-000066:mdna:112]
The segment operational profit decrease of 13% was primarily attributable to volume reductions in certain end-markets compared with the prior year. In addition, unfavorable price and product mix further impacted segment results. These reductions were partially offset by favorable productivity initiatives, lower selling, general and administrative expenses and higher earnings from equity method investments.

[0001783180-25-000066:mdna:113]
[same as prior period, unchanged from 0001783180-25-000052:mdna:118]

[0001783180-25-000066:mdna:114]
For the three months ended September 30, 2025, Net sales were $745 million, a 20% decrease compared to the same period of 2024. The components of the year-over-year change were as follows:

[0001783180-25-000066:mdna:115]
|  |  | Net sales |
| Organic |  | 6 | % |
| Foreign currency translation |  | 2 | % |
| Acquisitions and divestitures, net |  | (28) | % |
| Total % change in Net sales |  | (20) | % |

[0001783180-25-000066:mdna:116]
The organic increase in Net sales of 6% was primarily driven by volume growth within certain end-markets compared with the prior year. Container results increased (up 50%) due to ongoing end-market demand and improved price. These results were partially offset by lower volume in our global truck and trailer business (down 4%) primarily due to reduced end-market demand.

[0001783180-25-000066:mdna:117]
For the three months ended September 30, 2025, Segment operating profit was $115 million, a 16% decrease compared with the same period of 2024. The components of the year-over-year change were as follows:

[0001783180-25-000066:mdna:118]
|  |  | Segment operating profit |
| Operational |  | (12) | % |
| Foreign currency translation |  | 2 | % |
| Acquisitions and divestitures, net |  | (6) | % |
| Total % change in Segment operating profit |  | (16) | % |

[0001783180-25-000066:mdna:119]
The segment operational profit decrease of 12% was primarily driven by lower volumes in certain end-markets compared with the prior year. In addition, costs associated with warranty-related issues further impacted the segment. These amounts were partially offset by favorable productivity initiatives, lower selling, general and administrative costs and higher volumes in certain end-markets. However, the higher volumes led to an unfavorable mix in the segment.

[0001783180-25-000066:mdna:120]
44

[0001783180-25-000066:mdna:121]
Nine Months Ended September 30, 2025 Compared with Nine Months Ended September 30, 2024

[0001783180-25-000066:mdna:122]
[same as prior period, unchanged from 0001783180-25-000052:mdna:127]

[0001783180-25-000066:mdna:123]
|  | Net sales |  | Segment operating profit |  | Segment operating profit margin |
|  | Nine Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |  | Nine Months EndedSeptember 30, |
| (In millions) | 2025 |  | 2024 |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Climate Solutions Americas | $ | 8,535 |  |  | $ | 8,186 |  |  | $ | 1,982 |  |  | $ | 1,888 |  |  | 23.2 | % |  | 23.1 | % |
| Climate Solutions Europe | 3,712 |  |  | 3,732 |  |  | 324 |  |  | 389 |  |  | 8.7 | % |  | 10.4 | % |
| Climate Solutions Asia Pacific, Middle East & Africa | 2,541 |  |  | 2,626 |  |  | 353 |  |  | 371 |  |  | 13.9 | % |  | 14.1 | % |
| Climate Solutions Transportation | 2,122 |  |  | 2,794 |  |  | 340 |  |  | 388 |  |  | 16.0 | % |  | 13.9 | % |
| Total segment | $ | 16,910 |  |  | $ | 17,338 |  |  | $ | 2,999 |  |  | $ | 3,036 |  |  | 17.7 | % |  | 17.5 | % |

[0001783180-25-000066:mdna:124]
[same as prior period, unchanged from 0001783180-25-000052:mdna:129]

[0001783180-25-000066:mdna:125]
|  |  | Nine Months EndedSeptember 30, |
| (In millions) |  | 2025 |  | 2024 |
| Segment operating profit |  | $ | 2,999 |  |  | $ | 3,036 |  |
| Corporate and other |  | (162) |  |  | (172) |  |
| Adjusted operating profit |  | $ | 2,837 |  |  | $ | 2,864 |  |

[0001783180-25-000066:mdna:126]
[same as prior period, unchanged from 0001783180-25-000052:mdna:131]

[0001783180-25-000066:mdna:127]
For the nine months ended September 30, 2025, Net sales were $8.5 billion, a 4% increase compared with the same period of 2024. The components of the year-over-year change were as follows:

[0001783180-25-000066:mdna:128]
|  |  | Net sales |
| Organic |  | 4 | % |
| Foreign currency translation |  | — | % |
| Total % change in Net sales |  | 4 | % |

[0001783180-25-000066:mdna:129]
The organic increase in Net sales of 4% was driven by volume growth within certain end-markets compared with the prior year. Growth in our commercial business (up 27%) was primarily driven by ongoing customer demand and improved price. These results were partially offset by lower volume in our residential business (down 2%) primarily due to reduced end-market demand and distributor destocking during the current quarter. These amounts were partially offset by favorable mix and improved price. In addition, lower volume in our light commercial business (down 21%) further impacted segment results.

[0001783180-25-000066:mdna:130]
For the nine months ended September 30, 2025, Segment operating profit was $1,982 million, a 5% increase compared with the same period of 2024. The components of the year-over-year change were as follows:

[0001783180-25-000066:mdna:131]
|  |  | Segment operating profit |
| Operational |  | 6 | % |
| Foreign currency translation |  | (1) | % |
| Total % change in Operating profit |  | 5 | % |

[0001783180-25-000066:mdna:132]
[same as prior period, unchanged from 0001783180-25-000052:mdna:160]

[0001783180-25-000066:mdna:133]
The segment operational profit increase of 6% was primarily attributable to ongoing customer demand in certain end-markets compared with the prior year. In addition, favorable productivity initiatives, pricing improvements and product mix further benefited segment results. These benefits were partially offset by volume reductions in certain end-markets, lower earnings from equity method investments and higher selling, general and administrative expenses.

[0001783180-25-000066:mdna:134]
[same as prior period, unchanged from 0001783180-25-000052:mdna:139]

[0001783180-25-000066:mdna:135]
For the nine months ended September 30, 2025, Net sales were $3.7 billion, a 1% decrease compared with the same period of 2024. The components of the year-over-year change were as follows:

[0001783180-25-000066:mdna:136]
|  |  | Net sales |
| Organic |  | (3) | % |
| Foreign currency translation |  | 2 | % |
| Total % change in Net sales |  | (1) | % |

[0001783180-25-000066:mdna:137]
The organic decrease in Net sales of 3% was driven by ongoing challenges in certain end-markets compared with the prior year. Results in our residential and light commercial business decreased (down 5%) due to lower volumes across the region as economic conditions, inflationary cost pressures and regulatory uncertainty impacted end-market demand. These results were partially offset by growth in our commercial business (up 1%) as a result of end-market demand and improved price.

[0001783180-25-000066:mdna:138]
For the nine months ended September 30, 2025, Segment operating profit was $324 million, a 17% decrease compared with the same period of 2024. The components of the year-over-year change were as follows:

[0001783180-25-000066:mdna:139]
|  |  | Segment operating profit |
| Operational |  | (18) | % |
| Foreign currency translation |  | 1 | % |
| Total % change in Operating profit |  | (17) | % |

[0001783180-25-000066:mdna:140]
The segment operational profit decrease of 18% was primarily attributable to volume reductions in certain end-markets compared with the prior year. In addition, unfavorable product mix and geographical mix further impacted the segment. These amounts were partially offset by favorable productivity initiatives and business integration synergies associated with the acquisition of the VCS Business.

[0001783180-25-000066:mdna:141]
[same as prior period, unchanged from 0001783180-25-000052:mdna:146]

[0001783180-25-000066:mdna:142]
For the nine months ended September 30, 2025, Net sales were $2.5 billion, a 3% decrease compared with the same period of 2024. The components of the year-over-year change were as follows:

[0001783180-25-000066:mdna:143]
[same as prior period, unchanged from 0001783180-25-000052:mdna:141]

[0001783180-25-000066:mdna:144]
The organic decrease in Net sales of 4% was driven by volume reductions within certain end-markets compared with the prior year. Results in China decreased (down 10%) as residential end-markets experienced economic challenges impacting both demand and price. These results were partially offset by growth within commercial end-markets in China. In addition, ongoing end-market demand and improved price in the region's remaining geographies further benefited the segment.

[0001783180-25-000066:mdna:145]
[same as prior period, unchanged from 0001783180-25-000052:mdna:171]

[0001783180-25-000066:mdna:146]
For the nine months ended September 30, 2025, Segment operating profit was $353 million, a 5% decrease compared with the same period of 2024. The components of the year-over-year change were as follows:

[0001783180-25-000066:mdna:147]
|  |  | Segment operating profit |
| Operational |  | (8) | % |
| Foreign currency translation |  | 3 | % |
| Total % change in Operating profit |  | (5) | % |

[0001783180-25-000066:mdna:148]
The segment operational profit decrease of 8% was primarily attributable to volume reductions within certain end-markets compared with the prior year. In addition, unfavorable price and product mix further impacted segment results. These reductions were partially offset by favorable productivity initiatives and lower selling, general and administrative expenses.

[0001783180-25-000066:mdna:149]
[same as prior period, unchanged from 0001783180-25-000052:mdna:153]

[0001783180-25-000066:mdna:150]
For the nine months ended September 30, 2025, Net sales were $2,122 million, a 24% decrease compared to the same period of 2024. The components of the year-over-year change were as follows:

[0001783180-25-000066:mdna:151]
|  |  | Net sales |
| Organic |  | 2 | % |
| Foreign currency translation |  | 1 | % |
| Acquisitions and divestitures, net |  | (27) | % |
| Total % change in Net sales |  | (24) | % |

[0001783180-25-000066:mdna:152]
The organic increase in Net sales of 2% was primarily driven by volume growth within certain end-markets compared with the prior year. Container results increased (up 25%) due to ongoing end-market demand and improved price. These results were partially offset by our global truck and trailer business (down 4%) as lower end-market demand in Asia and Europe more than offset flat results in North America.

[0001783180-25-000066:mdna:153]
For the nine months ended September 30, 2025, Segment operating profit was $340 million, a 12% decrease compared with the same period of 2024. The components of the year-over-year change were as follows:

[0001783180-25-000066:mdna:154]
|  |  | Segment operating profit |
| Operational |  | (10) | % |
| Foreign currency translation |  | 1 | % |
| Acquisitions and divestitures, net |  | (3) | % |
| Total % change in Operating profit |  | (12) | % |

[0001783180-25-000066:mdna:155]
The decrease in segment operational profit of 10% was primarily driven by volume reductions in certain end-markets. In addition, costs associated with warranty-related issues further impacted the segment. These amounts were partially offset by favorable productivity initiatives, lower selling, general and administrative costs and higher volumes in certain end-markets. However, the higher volumes led to an unfavorable mix in the segment.

[0001783180-25-000066:mdna:156]
[same as prior period, unchanged from 0001783180-25-000052:mdna:161]

[0001783180-25-000066:mdna:157]
[same as prior period, unchanged from 0001783180-25-000052:mdna:162]

[0001783180-25-000066:mdna:158]
As of September 30, 2025, we had cash and cash equivalents of $1.4 billion, of which approximately 94% was held by our foreign subsidiaries. We manage our worldwide cash requirements by reviewing available funds and the cost effectiveness with which we can access funds held by foreign subsidiaries. On occasion, we are required to maintain cash deposits in connection with contractual obligations related to acquisitions, divestitures or other legal obligations. As of September 30, 2025 and December 31, 2024, the amount of such restricted cash was approximately $3 million and $3 million, respectively.

[0001783180-25-000066:mdna:159]
[same as prior period, unchanged from 0001783180-25-000052:mdna:164]

[0001783180-25-000066:mdna:160]
[same as prior period, unchanged from 0001783180-25-000052:mdna:165]

[0001783180-25-000066:mdna:161]
[same as prior period, unchanged from 0001783180-25-000052:mdna:166]

[0001783180-25-000066:mdna:162]
| (In millions) |  | September 30,2025 |  | December 31,2024 |
| Cash and cash equivalents |  | $ | 1,423 |  |  | $ | 3,969 |  |
| Total debt |  | 11,916 |  |  | 12,362 |  |
| Total equity |  | 14,839 |  |  | 14,395 |  |
| Net debt (total debt less cash and cash equivalents) |  | 10,493 |  |  | 8,393 |  |
| Total capitalization (total debt plus total equity) |  | 26,755 |  |  | 26,757 |  |
| Net capitalization (total debt plus total equity less cash and cash equivalents) |  | 25,332 |  |  | 22,788 |  |
| Total debt to total capitalization |  | 45 | % |  | 46 | % |
| Net debt to net capitalization |  | 41 | % |  | 37 | % |

[0001783180-25-000066:mdna:163]
[same as prior period, unchanged from 0001783180-25-000052:mdna:168]

[0001783180-25-000066:mdna:164]
We maintain a $2.0 billion USD-denominated facility and a $500 million Euro-denominated facility as part of an unsecured, unsubordinated commercial paper program which we can use for general corporate purposes, including the funding of working capital and potential acquisitions. In addition, we maintain a $2.5 billion revolving credit agreement with various banks (the "Revolving Credit Facility") that matures in December 2029 which supports our commercial paper borrowing program and can be used for general corporate purposes. A ratings-based commitment fee is charged on unused commitments. As of September 30, 2025, we had $415 million and zero borrowings outstanding under our commercial paper program and our Revolving Credit Facility, respectively.

[0001783180-25-000066:mdna:165]
Our short-term obligations primarily consist of current maturities of long-term debt. Our long-term obligations primarily consist of long-term notes with maturity dates ranging between 2027 and 2054. Interest payments related to long-term notes are expected to approximate $407 million per year, reflecting an approximate weighted-average interest rate of 3.64%. Any borrowings from the Revolving Credit Facility are subject to variable interest rates. See Note 5 – Borrowings and Lines of Credit in the Notes to the accompanying Unaudited Condensed Consolidated Financial Statements for additional information regarding the terms of our long-term debt obligations.

[0001783180-25-000066:mdna:166]
Our credit ratings are periodically reviewed by the major independent debt-rating agencies. As of September 30, 2025, Standards & Poor's Global Inc. and Moody’s Investor Service Inc. have ratings on our debt set forth in the table below:

[0001783180-25-000066:mdna:167]
[same as prior period, unchanged from 0001783180-25-000052:mdna:174]

[0001783180-25-000066:mdna:168]
[same as prior period, unchanged from 0001783180-25-000052:mdna:175]

[0001783180-25-000066:mdna:169]
[same as prior period, unchanged from 0001783180-25-000052:mdna:176]

[0001783180-25-000066:mdna:170]
[same as prior period, unchanged from 0001783180-25-000052:mdna:177]

[0001783180-25-000066:mdna:171]
[same as prior period, unchanged from 0001783180-25-000052:mdna:178]

[0001783180-25-000066:mdna:172]
During the nine months ended September 30, 2025, we repurchased 36.3 million shares of common stock for an aggregate purchase price of $2.4 billion, which included shares repurchased from Viessmann. As a result, we had approximately $811 million remaining under the current authorization at September 30, 2025. In October 2025, our Board of Directors approved a $5 billion increase to our existing share repurchase program.

[0001783180-25-000066:mdna:173]
[same as prior period, unchanged from 0001783180-25-000052:mdna:180]

[0001783180-25-000066:mdna:174]
We paid dividends on common stock during the nine months ended September 30, 2025, totaling $583 million. In October 2025, the Board of Directors declared a dividend of $0.225 per share of common stock payable on November 18, 2025, to shareowners of record at the close of business on October 29, 2025.

[0001783180-25-000066:mdna:175]
[same as prior period, unchanged from 0001783180-25-000052:mdna:182]

[0001783180-25-000066:mdna:176]
[same as prior period, unchanged from 0001783180-25-000052:mdna:183]

[0001783180-25-000066:mdna:177]
|  |  | Nine Months EndedSeptember 30, |
| (In millions) |  | 2025 |  | 2024 |
| Net cash flows provided by (used in): |  |  |  |  |
| Continuing operating activities |  | $ | 1,076 |  |  | $ | 1,208 |  |
| Continuing investing activities |  | (232) |  |  | (11,331) |  |
| Continuing financing activities |  | (3,885) |  |  | (2,939) |  |

[0001783180-25-000066:mdna:178]
Cash flows from continuing operating activities primarily represent inflows and outflows associated with our continuing operations. Primary activities include net earnings from continuing operations adjusted for non-cash transactions, working capital changes and changes in other assets and liabilities. The year-over-year decrease in net cash provided by continuing operating activities was primarily driven by an increase in working capital balances compared with the prior period. Higher accounts receivable and inventory balances were partially offset by higher accounts payable balances.

[0001783180-25-000066:mdna:179]
Cash flows from continuing investing activities primarily represent inflows and outflows associated with long-term assets. Primary activities include capital expenditures, acquisitions, divestitures and proceeds from the sale of fixed assets. During the nine months ended September 30, 2025, net cash used in continuing investing activities was $232 million. The primary driver of the outflow related to $261 million of capital expenditures which was partially offset by $120 million of cash inflow related to settlement of derivatives. During the nine months ended September 30, 2024, net cash used in continuing investing activities was $11.3 billion. The primary driver of the outflow related to the acquisition of the VCS Business, which totaled $10.8 billion, net of cash acquired. Additional investing outflows include $187 million related to settlement of derivatives and $302 million of capital expenditures.

[0001783180-25-000066:mdna:180]
Cash flows from continuing financing activities primarily represent inflows and outflows associated with equity or borrowings. During the nine months ended September 30, 2025, net cash used in continuing financing activities was $3.9 billion. The primary driver of the outflow was related to repurchases of our common stock totaling $2.4 billion. In addition, we made long-term debt repayments of $1.2 billion and payments of $583 million in dividends to our common shareowners. During the nine months ended September 30, 2024, net cash used in continuing financing activities was $2.9 billion. The primary driver of the outflow is due to repayment of long-term debt totaling $4.5 billion. In addition, we made dividend payments of $514 million and share repurchases of $431 million. These outflows were partially offset by the proceeds of long-term debt used to fund the cash portion of the acquisition of the VCS Business.
