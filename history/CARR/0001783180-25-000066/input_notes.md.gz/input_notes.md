# CARR notes — 0001783180-25-000066


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001783180-25-000066:notes:1]
[same as prior period, unchanged from 0001783180-25-000052:notes:1]

[0001783180-25-000066:notes:2]
In the opinion of management, the accompanying Unaudited Condensed Consolidated Financial Statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission (the "SEC"). The accompanying Unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for 2024 filed with the SEC on February 11, 2025 (the "2024 Form 10-K"). Certain prior period amounts have been reclassified to conform to the current period financial statement presentation.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001783180-25-000066:notes:3]
BASIS OF PRESENTATION
The Unaudited Condensed Consolidated Financial Statements include all accounts of the Company and its wholly-owned and majority-owned subsidiaries in which it has control. Inter-company accounts and transactions have been eliminated. Related party transactions between the Company and its equity method investees have not been eliminated. Non-controlling interest represents a non-controlling investor's interests in the results of subsidiaries that the Company controls and consolidates.

[0001783180-25-000066:notes:4]
[same as prior period, unchanged from 0001783180-25-000052:notes:4]

[0001783180-25-000066:notes:5]
During 2024, the Company completed several activities designed to simplify its business portfolio, transforming it into a pure-play climate and energy solutions provider. On January 2, 2024, the Company acquired the climate solutions business (the "VCS Business") of Viessmann Group GmbH & Co. KG (together with its affiliates, “Viessmann”). The VCS Business, primarily reported in the Climate Solutions Europe segment, is a premier residential and light commercial HVAC provider in Europe that expanded the Company's portfolio to offer a global, comprehensive suite of sustainable and innovative building and cold-chain solutions. In addition, the Company divested its Commercial and Residential Fire, Access Solutions and Industrial Fire businesses which were historically reported in its Fire & Security segment. The transactions represented a single disposal plan to separately divest multiple businesses over different reporting periods and met the criteria to be presented as discontinued operations in the accompanying financial statements. The Company also divested its Commercial Refrigeration business (“CCR”) during 2024. CCR, which was historically reported in the Climate Solutions Transportation segment (previously named Refrigeration), did not meet the criteria to be presented as discontinued operations.

[0001783180-25-000066:notes:6]
[same as prior period, unchanged from 0001783180-25-000052:notes:6]

[0001783180-25-000066:notes:7]
[same as prior period, unchanged from 0001783180-25-000052:notes:7]

[0001783180-25-000066:notes:8]
[same as prior period, unchanged from 0001783180-25-000052:notes:8]

[0001783180-25-000066:notes:9]
On April 3, 2020 (the "Distribution Date"), United Technologies Corporation ("UTC"), since renamed RTX Corporation ("Raytheon Technologies Corporation" or "RTX"), completed the spin-off of Carrier into an independent, publicly traded company (the "Separation") through a pro-rata distribution (the "Distribution") on a one-for-one basis of all of the outstanding shares of common stock of Carrier to UTC shareowners who held shares of UTC common stock as of the close of business on March 19, 2020, the record date of the Distribution. In addition, the Company entered into several agreements with UTC and Otis Worldwide Corporation ("Otis") that govern various aspects of the relationship among the Company, UTC and Otis. As of September 30, 2025, only certain portions of the Tax Matters Agreement ("TMA") remain in effect.

[0001783180-25-000066:notes:10]
[same as prior period, unchanged from 0001783180-25-000052:notes:10]

[0001783180-25-000066:notes:11]
[same as prior period, unchanged from 0001783180-25-000052:notes:11]

[0001783180-25-000066:notes:12]
Recently Issued Accounting Pronouncements

[0001783180-25-000066:notes:13]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures ("ASU 2023-09"), which requires public entities to disclose disaggregated information about their effective tax rate reconciliation as well as information on income taxes paid. ASU 2023-09 is effective for annual periods beginning after December 15, 2024, with early adoption permitted. The ASU requires additional disclosures and is not expected to have a material impact on the Company's financial statements.

[0001783180-25-000066:notes:14]
In November 2024, the FASB issued ASU 2024-03, Disaggregation of Income Statement Expenses (DISE) ("ASU 2024-03"), which requires public entities to disclose disaggregated information about expenses by nature on an interim and annual basis. ASU 2024-03 is effective for fiscal years beginning after December 15, 2026 and interim periods within fiscal years beginning after December 15, 2027, with early adoption permitted. The Company is currently assessing the impact of this ASU on its financial statements.


## us-gaap:InventoryDisclosureTextBlock

[0001783180-25-000066:notes:15]
[same as prior period, unchanged from 0001783180-25-000052:notes:15]

[0001783180-25-000066:notes:16]
[same as prior period, unchanged from 0001783180-25-000052:notes:16]

[0001783180-25-000066:notes:17]
| (In millions) |  | September 30,2025 |  | December 31,2024 |
| Raw materials |  | $ | 756 |  |  | $ | 625 |  |
| Work-in-process |  | 250 |  |  | 213 |  |
| Finished goods |  | 1,998 |  |  | 1,461 |  |
| Inventories, net |  | $ | 3,004 |  |  | $ | 2,299 |  |

[0001783180-25-000066:notes:18]
The Company performs periodic assessments utilizing customer demand, production requirements and historical usage rates to determine the existence of excess and obsolete inventory and records necessary provisions to reduce such inventories to the lower of cost or estimated net realizable value. Raw materials, work-in-process and finished goods are net of valuation reserves of $391 million and $215 million as of September 30, 2025 and December 31, 2024, respectively.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001783180-25-000066:notes:19]
[same as prior period, unchanged from 0001783180-25-000052:notes:19]

[0001783180-25-000066:notes:20]
The changes in the carrying amount of goodwill were as follows:

[0001783180-25-000066:notes:21]
| (In millions) |  | Climate Solutions Americas |  | Climate Solutions Europe |  | Climate Solutions Asia Pacific, Middle East & Africa |  | Climate Solutions Transportation |  |  |  |  |  | Total |
| Balance as of December 31, 2024 |  | $ | 5,059 |  |  | $ | 7,035 |  |  | $ | 1,380 |  |  | $ | 1,127 |  |  |  |  |  |  | $ | 14,601 |  |
| Acquisitions |  | 11 |  |  | 6 |  |  | 7 |  |  | 44 |  |  |  |  |  |  | 68 |  |
| Foreign currency translation |  | 2 |  |  | 931 |  |  | 43 |  |  | 35 |  |  |  |  |  |  | 1,011 |  |
| Balance as of September 30, 2025 |  | $ | 5,072 |  |  | $ | 7,972 |  |  | $ | 1,430 |  |  | $ | 1,206 |  |  |  |  |  |  | $ | 15,680 |  |

[0001783180-25-000066:notes:22]
[same as prior period, unchanged from 0001783180-25-000052:notes:23]

[0001783180-25-000066:notes:23]
|  |  | September 30, 2025 |  | December 31, 2024 |
| (In millions) |  | Gross Amount |  | Accumulated Amortization |  | Net Amount |  | Gross Amount |  | Accumulated Amortization |  | Net Amount |
| Customer relationships |  | $ | 6,258 |  |  | $ | (1,522) |  |  | $ | 4,736 |  |  | $ | 5,607 |  |  | $ | (939) |  |  | $ | 4,668 |  |
| Patents and trademarks |  | 978 |  |  | (201) |  |  | 777 |  |  | 885 |  |  | (147) |  |  | 738 |  |
| Service portfolios and other |  | 1,713 |  |  | (666) |  |  | 1,047 |  |  | 1,530 |  |  | (504) |  |  | 1,026 |  |
| Total intangible assets |  | $ | 8,949 |  |  | $ | (2,389) |  |  | $ | 6,560 |  |  | $ | 8,022 |  |  | $ | (1,590) |  |  | $ | 6,432 |  |

[0001783180-25-000066:notes:24]
[same as prior period, unchanged from 0001783180-25-000052:notes:25]

[0001783180-25-000066:notes:25]
|  |  | Three Months Ended September 30, |  | Nine Months EndedSeptember 30, |
| (In millions) |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Amortization expense of Intangible assets |  | $ | 228 |  |  | $ | 213 |  |  | $ | 657 |  |  | $ | 632 |  |

[0001783180-25-000066:notes:26]
Impairment Test

[0001783180-25-000066:notes:27]
In connection with its revised segment structure, the Company performed a quantitative goodwill impairment test on its reporting units prior to the reorganization to determine if any impairment existed. The tests did not indicate any goodwill impairment. The Company then reassigned goodwill among its new reporting units using a relative fair value approach. Based on these analyses, the Climate Solutions Europe reporting unit had a fair value of 10% above its carrying value. All other reporting units had fair values substantially in excess of their carrying values.

[0001783180-25-000066:notes:28]
The Company tested its goodwill for impairment on July 1 as part of its annual assessment. For each test except the Climate Solutions Europe reporting unit, the Company qualitatively assessed all relevant events or circumstances that could impact the estimate of fair value and determined it was more likely than not that the fair value of each reporting unit substantially exceeded their carrying amount. For the remaining test, the Company's Climate Solutions Europe reporting unit, the Company performed a quantitative goodwill impairment test to determine if any impairment existed. Upon completion of the test, the reporting unit had a fair value of approximately 14% above its carrying value. As a result, the test did not indicate any goodwill impairment.


## us-gaap:DebtDisclosureTextBlock

[0001783180-25-000066:notes:29]
BORROWINGS AND LINES OF CREDIT
Short-term borrowings and current portion of long-term debt consisted of the following:

[0001783180-25-000066:notes:30]
| (In millions) |  |  |  | September 30,2025 |  | December 31,2024 |
| Commercial paper |  |  |  | $ | 415 |  |  | $ | — |  |
| Short-term borrowings |  |  |  | 58 |  |  | 84 |  |
| Current portion of long-term debt |  |  |  | 107 |  |  | 1,252 |  |
| Short-term borrowings and current portion of long-term debt |  |  |  | $ | 580 |  |  | $ | 1,336 |  |

[0001783180-25-000066:notes:31]
Commercial Paper Program

[0001783180-25-000066:notes:32]
The Company has a $2.0 billion USD-denominated facility and a $500 million Euro-denominated facility as part of an unsecured, unsubordinated commercial paper program, which can be used for general corporate purposes including the funding of working capital and potential acquisitions. At September 30, 2025, the Company had $415 million outstanding under its USD-denominated commercial paper facility, with a weighted average rate of 4.28%.

[0001783180-25-000066:notes:33]
Long-term debt consisted of the following:

[0001783180-25-000066:notes:34]
| (In millions) |  |  |  | September 30,2025 |  | December 31,2024 |
| 2.242% Notes due 2025 (1) |  |  |  | $ | — |  |  | $ | 1,200 |  |
| 2.493% Notes due 2027 |  |  |  | 900 |  |  | 900 |  |
| 4.125% Notes due 2028 |  |  |  | 875 |  |  | 783 |  |
| 2.722% Notes due 2030 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.700% Notes due 2031 |  |  |  | 750 |  |  | 750 |  |
| 4.500% Notes due 2032 |  |  |  | 992 |  |  | 887 |  |
| 5.900% Notes due 2034 |  |  |  | 875 |  |  | 875 |  |
| 3.625% Notes due 2037 |  |  |  | 875 |  |  | 783 |  |
| 3.377% Notes due 2040 |  |  |  | 1,500 |  |  | 1,500 |  |
| 3.577% Notes due 2050 |  |  |  | 1,400 |  |  | 1,400 |  |
| 6.200% Notes due 2054 |  |  |  | 650 |  |  | 650 |  |
| Total long-term notes |  |  |  | 10,817 |  |  | 11,728 |  |
| Japanese Term Loan Facility |  |  |  | 360 |  |  | 342 |  |
| Other debt (including project financing obligations and finance leases) |  |  |  | 347 |  |  | 296 |  |
| Discounts and debt issuance costs |  |  |  | (81) |  |  | (88) |  |
| Total long-term debt |  |  |  | 11,443 |  |  | 12,278 |  |
| Less: current portion of long-term debt |  |  |  | 107 |  |  | 1,252 |  |
| Long-term debt, net of current portion |  |  |  | $ | 11,336 |  |  | $ | 11,026 |  |

[0001783180-25-000066:notes:35]
(1) 2.242% Notes due February 15, 2025; repaid during February 2025.

[0001783180-25-000066:notes:36]
Revolving Credit Facility

[0001783180-25-000066:notes:37]
On December 20, 2024, the Company refinanced its revolving credit agreement with JPMorgan Chase Bank, N.A., as administrative agent, and certain other lenders, permitting aggregate borrowings of up to $2.5 billion pursuant to an unsecured, unsubordinated revolving credit facility that matures in December 2029 (the "Revolving Credit Facility"). The Revolving Credit Facility supports the Company's commercial paper program and can be used for other general corporate purposes. Borrowings are available in U.S. Dollars and Euros. U.S. Dollar borrowings bear interest at either a Term SOFR Rate plus 0.10% and a ratings-based margin or, alternatively, at an alternate base rate plus a ratings-based margin. Euro borrowings bear interest at an adjusted EURIBOR rate plus a ratings-based margin. A ratings-based commitment fee is charged on unused commitments. Upon entering into the agreement, the Company capitalized $11 million of deferred financing costs which are being amortized over its term. As of September 30, 2025, there were no borrowings outstanding under the Revolving Credit Facility.

[0001783180-25-000066:notes:38]
Project Financing Arrangements

[0001783180-25-000066:notes:39]
The Company is involved in long-term construction contracts in which it arranges project financing with certain customers. As a result, the Company issued $22 million and $40 million of debt during the nine months ended September 30, 2025 and 2024, respectively. Long-term debt repayments associated with these financing arrangements during the nine months ended September 30, 2025 and 2024, were zero and $7 million, respectively.

[0001783180-25-000066:notes:40]
Debt Covenants

[0001783180-25-000066:notes:41]
The Revolving Credit Facility, the indenture for the long-term notes and the five-year, JPY 54 billion (approximately $400 million) senior unsecured term loan facility ("Japanese Term Loan Facility") contain affirmative and negative covenants customary for financings of these types, which, among other things, limit the Company's ability to incur certain liens, to make certain fundamental changes and to enter into sale and leaseback transactions. As of September 30, 2025, the Company was in compliance with the covenants under the agreements governing its outstanding indebtedness.


## us-gaap:FairValueDisclosuresTextBlock

[0001783180-25-000066:notes:42]
[same as prior period, unchanged from 0001783180-25-000052:notes:38]

[0001783180-25-000066:notes:43]
[same as prior period, unchanged from 0001783180-25-000052:notes:39]

[0001783180-25-000066:notes:44]
[same as prior period, unchanged from 0001783180-25-000052:notes:40]

[0001783180-25-000066:notes:45]
[same as prior period, unchanged from 0001783180-25-000052:notes:41]

[0001783180-25-000066:notes:46]
[same as prior period, unchanged from 0001783180-25-000052:notes:42]

[0001783180-25-000066:notes:47]
[same as prior period, unchanged from 0001783180-25-000052:notes:43]

[0001783180-25-000066:notes:48]
[same as prior period, unchanged from 0001783180-25-000052:notes:44]

[0001783180-25-000066:notes:49]
[same as prior period, unchanged from 0001783180-25-000052:notes:45]

[0001783180-25-000066:notes:50]
During 2023, the Company entered into several interest rate swap contracts to mitigate interest rate exposure on the forecasted issuance of long-term debt. The contracts had an aggregate notional amount of $1.5 billion and were designated as cash flow hedges with changes in fair value reported in Equity in the accompanying Unaudited Condensed Consolidated Balance Sheet. Fair value was measured on a recurring basis using observable market inputs, such as forward, discount and interest rates. In November 2023, the contracts were settled upon the issuance of the underlying debt. As a result, the Company deferred a net unrecognized gain of $58 million in Equity which will be subsequently recognized in Interest expense over the term of the related notes which range from 2034 to 2054. The amount expected to be amortized during the next twelve months is a net gain of $4 million.

[0001783180-25-000066:notes:51]
The Company enters into cross currency swaps in order to manage foreign currency translation risk on assets denominated in a functional currency other than the U.S. Dollar. The swaps have an aggregate notional amount of $2.6 billion and are measured at fair value on a recurring basis using observable market inputs, such as forward, discount and interest rates. The Company designates the cross currency swaps as a partial hedge of its investments in certain subsidiaries whose functional currency is not the U.S. Dollar. As a result, changes in the fair value of the swaps are recorded in Equity in the accompanying Unaudited Condensed Consolidated Balance Sheet.

[0001783180-25-000066:notes:52]
[same as prior period, unchanged from 0001783180-25-000052:notes:48]

[0001783180-25-000066:notes:53]
| (In millions) |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |
| September 30, 2025 |  |  |  |  |  |  |  |  |
| Derivative assets (1) |  | $ | 92 |  |  | $ | — |  |  | $ | 92 |  |  | $ | — |  |
| Derivative liabilities (2) |  | $ | (178) |  |  | $ | — |  |  | $ | (178) |  |  | $ | — |  |
| December 31, 2024 |  |  |  |  |  |  |  |  |
| Derivative assets (1) |  | $ | 82 |  |  | $ | — |  |  | $ | 82 |  |  | $ | — |  |
| Derivative liabilities (2) |  | $ | (41) |  |  | $ | — |  |  | $ | (41) |  |  | $ | — |  |

[0001783180-25-000066:notes:54]
[same as prior period, unchanged from 0001783180-25-000052:notes:50]

[0001783180-25-000066:notes:55]
[same as prior period, unchanged from 0001783180-25-000052:notes:51]

[0001783180-25-000066:notes:56]
[same as prior period, unchanged from 0001783180-25-000052:notes:52]

[0001783180-25-000066:notes:57]
|  |  | September 30, 2025 |  | December 31, 2024 |
| (In millions) |  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |
| Total long-term notes (1) |  | $ | 10,817 |  |  | $ | 10,177 |  |  | $ | 11,728 |  |  | $ | 10,798 |  |

[0001783180-25-000066:notes:58]
[same as prior period, unchanged from 0001783180-25-000052:notes:54]

[0001783180-25-000066:notes:59]
[same as prior period, unchanged from 0001783180-25-000052:notes:55]


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0001783180-25-000066:notes:60]
[same as prior period, unchanged from 0001783180-25-000052:notes:56]


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001783180-25-000066:notes:61]
[same as prior period, unchanged from 0001783180-25-000052:notes:57]

[0001783180-25-000066:notes:62]
[same as prior period, unchanged from 0001783180-25-000052:notes:58]

[0001783180-25-000066:notes:63]
|  |  | Three Months Ended September 30, |  | Nine Months EndedSeptember 30, |
| (In millions) |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Defined benefit plans |  | $ | 13 |  |  | $ | 16 |  |  | $ | 33 |  |  | $ | 34 |  |
| Defined contribution plans |  | $ | 28 |  |  | $ | 30 |  |  | $ | 91 |  |  | $ | 104 |  |
| Multi-employer pension plans |  | $ | 4 |  |  | $ | 4 |  |  | $ | 11 |  |  | $ | 12 |  |

[0001783180-25-000066:notes:64]
[same as prior period, unchanged from 0001783180-25-000052:notes:60]

[0001783180-25-000066:notes:65]
|  |  | Three Months Ended September 30, |  | Nine Months EndedSeptember 30, |
| (In millions) |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Service cost |  | $ | 3 |  |  | $ | 4 |  |  | $ | 10 |  |  | $ | 11 |  |
| Interest cost |  | 7 |  |  | 13 |  |  | 21 |  |  | 26 |  |
| Expected return on plan assets |  | (9) |  |  | (13) |  |  | (25) |  |  | (27) |  |
| Amortization of prior service cost |  | 1 |  |  | — |  |  | 1 |  |  | — |  |
| Recognized actuarial net (gain) loss |  | — |  |  | — |  |  | 1 |  |  | 1 |  |
| Net settlement, curtailment and special termination benefit (gain) loss |  | 10 |  |  | 1 |  |  | 10 |  |  | 1 |  |
| Net periodic pension expense (benefit) |  | $ | 12 |  |  | $ | 5 |  |  | $ | 18 |  |  | $ | 12 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001783180-25-000066:notes:66]
[same as prior period, unchanged from 0001783180-25-000052:notes:62]

[0001783180-25-000066:notes:67]
[same as prior period, unchanged from 0001783180-25-000052:notes:63]

[0001783180-25-000066:notes:68]
[same as prior period, unchanged from 0001783180-25-000052:notes:64]

[0001783180-25-000066:notes:69]
|  |  | Three Months Ended September 30, |  | Nine Months EndedSeptember 30, |
| (In millions) |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Equity compensation costs - equity settled |  | $ | 11 |  |  | $ | 28 |  |  | $ | 55 |  |  | $ | 76 |  |
| Equity compensation costs - cash settled (1) |  | (2) |  |  | 2 |  |  | (1) |  |  | 3 |  |
| Total stock-based compensation expense |  | $ | 9 |  |  | $ | 30 |  |  | $ | 54 |  |  | $ | 79 |  |
| Amounts recorded in continuing operations |  | $ | 9 |  |  | $ | 27 |  |  | $ | 54 |  |  | $ | 68 |  |
| Amounts recorded in discontinued operations |  | — |  |  | 3 |  |  | — |  |  | 11 |  |
| Total stock-based compensation expense |  | $ | 9 |  |  | $ | 30 |  |  | $ | 54 |  |  | $ | 79 |  |

[0001783180-25-000066:notes:70]
[same as prior period, unchanged from 0001783180-25-000052:notes:66]


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001783180-25-000066:notes:71]
[same as prior period, unchanged from 0001783180-25-000052:notes:67]

[0001783180-25-000066:notes:72]
[same as prior period, unchanged from 0001783180-25-000052:notes:68]

[0001783180-25-000066:notes:73]
|  |  | Nine Months EndedSeptember 30, |
| (In millions) |  | 2025 |  | 2024 |
| Balance as of January 1, |  | $ | 786 |  |  | $ | 568 |  |
| Warranties, performance guarantees issued and changes in estimated liability |  | 272 |  |  | 229 |  |
| Settlements made |  | (218) |  |  | (211) |  |
| Acquisitions |  | 1 |  |  | 202 |  |
| Other (1) |  | 29 |  |  | 5 |  |
| Balance as of September 30, |  | $ | 870 |  |  | $ | 793 |  |

[0001783180-25-000066:notes:74]
[same as prior period, unchanged from 0001783180-25-000052:notes:70]


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001783180-25-000066:notes:75]
EQUITY
The authorized number of shares of common stock of Carrier is 4,000,000,000 shares of $0.01 par value. As of September 30, 2025 and December 31, 2024, 950,311,832 and 948,068,772 shares of common stock were issued, respectively, which includes 106,390,297 and 70,093,639 shares of treasury stock, respectively.

[0001783180-25-000066:notes:76]
[same as prior period, unchanged from 0001783180-25-000052:notes:72]

[0001783180-25-000066:notes:77]
[same as prior period, unchanged from 0001783180-25-000052:notes:73]

[0001783180-25-000066:notes:78]
In June 2025, the Company entered into a repurchase agreement with Viessmann, an entity controlled by one of the Company's directors, to acquire an aggregate 4,267,425 shares of the Company's common stock at a price per share of $70.30 for an aggregate purchase price of $300 million. In July 2025, the Company acquired the shares from Viessmann. During the nine months ended September 30, 2025, the Company repurchased 36.3 million shares of common stock for an aggregate purchase price of $2.4 billion, which included shares repurchased from Viessmann under the repurchase agreement. As a result, the Company had approximately $811 million remaining under the current authorization at September 30, 2025. In October 2025, the Company's Board of Directors approved a $5 billion increase to the Company's existing share repurchase program.

[0001783180-25-000066:notes:79]
[same as prior period, unchanged from 0001783180-25-000052:notes:75]

[0001783180-25-000066:notes:80]
A summary of changes in the components of Accumulated other comprehensive income (loss) for the three and nine months ended September 30, 2025 is as follows:

[0001783180-25-000066:notes:81]
| (In millions) |  | Foreign Currency Translation |  | Defined Benefit Pension and Post-retirement Plans |  |  |  | Unrealized Hedging Gains (Losses) |  | Accumulated Other Comprehensive Income (Loss) |
| Balance as of December 31, 2024 |  | $ | (2,053) |  |  | $ | (107) |  |  |  |  | $ | 54 |  |  | $ | (2,106) |  |
| Other comprehensive income (loss) before reclassifications, net |  | 634 |  |  | — |  |  |  |  | — |  |  | 634 |  |
| Amounts reclassified, pre-tax |  | — |  |  | — |  |  |  |  | (1) |  |  | (1) |  |
| Balance as of March 31, 2025 |  | $ | (1,419) |  |  | $ | (107) |  |  |  |  | $ | 53 |  |  | $ | (1,473) |  |
| Other comprehensive income (loss) before reclassifications, net |  | 1,067 |  |  | (6) |  |  |  |  | — |  |  | 1,061 |  |
| Amounts reclassified, pre-tax |  | — |  |  | 1 |  |  |  |  | (2) |  |  | (1) |  |
| Balance as of June 30, 2025 |  | $ | (352) |  |  | $ | (112) |  |  |  |  | $ | 51 |  |  | $ | (413) |  |
| Other comprehensive income (loss) before reclassifications, net |  | 46 |  |  | 2 |  |  |  |  | — |  |  | 48 |  |
| Amounts reclassified, pre-tax |  | — |  |  | 1 |  |  |  |  | (1) |  |  | — |  |
| Balance as of September 30, 2025 |  | $ | (306) |  |  | $ | (109) |  |  |  |  | $ | 50 |  |  | $ | (365) |  |

[0001783180-25-000066:notes:82]
A summary of changes in the components of Accumulated other comprehensive income (loss) for the three and nine months ended September 30, 2024 is as follows:

[0001783180-25-000066:notes:83]
| (In millions) |  | Foreign Currency Translation |  | Defined Benefit Pension and Post-retirement Plans |  |  |  | Unrealized Hedging Gains (Losses) |  | Accumulated Other Comprehensive Income (Loss) |
| Balance as of December 31, 2023 |  | $ | (1,444) |  |  | $ | (100) |  |  |  |  | $ | 58 |  |  | $ | (1,486) |  |
| Other comprehensive income (loss) before reclassifications, net |  | (385) |  |  | — |  |  |  |  | — |  |  | (385) |  |
| Amounts reclassified, pre-tax |  | — |  |  | — |  |  |  |  | (1) |  |  | (1) |  |
| Balance as of March 31, 2024 |  | $ | (1,829) |  |  | $ | (100) |  |  |  |  | $ | 57 |  |  | $ | (1,872) |  |
| Other comprehensive income (loss) before reclassifications, net |  | (187) |  |  | — |  |  |  |  | — |  |  | (187) |  |
| Amounts reclassified, pre-tax |  | — |  |  | 1 |  |  |  |  | (1) |  |  | — |  |
| Divestitures, net |  | 373 |  |  | — |  |  |  |  | — |  |  | 373 |  |
| Balance as of June 30, 2024 |  | $ | (1,643) |  |  | $ | (99) |  |  |  |  | $ | 56 |  |  | $ | (1,686) |  |
| Other comprehensive income (loss) before reclassifications, net |  | 669 |  |  | — |  |  |  |  | — |  |  | 669 |  |
| Amounts reclassified, pre-tax |  | — |  |  | 2 |  |  |  |  | (1) |  |  | 1 |  |
| Tax expense (benefit) reclassified |  | — |  |  | (1) |  |  |  |  | — |  |  | (1) |  |
| Divestitures, net |  | 215 |  |  | — |  |  |  |  | — |  |  | 215 |  |
| Balance as of September 30, 2024 |  | $ | (759) |  |  | $ | (98) |  |  |  |  | $ | 55 |  |  | $ | (802) |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001783180-25-000066:notes:84]
[same as prior period, unchanged from 0001783180-25-000052:notes:80]

[0001783180-25-000066:notes:85]
[same as prior period, unchanged from 0001783180-25-000052:notes:81]

[0001783180-25-000066:notes:86]
|  |  | Three Months Ended September 30, |  | Nine Months EndedSeptember 30, |
| (In millions) |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Sales Type |  |  |  |  |  |  |  |  |
| Product |  | $ | 2,393 |  |  | $ | 2,669 |  |  | $ | 7,682 |  |  | $ | 7,359 |  |
| Service |  | 318 |  |  | 292 |  |  | 853 |  |  | 827 |  |
| Climate Solutions Americas sales |  | 2,711 |  |  | 2,961 |  |  | 8,535 |  |  | 8,186 |  |
| Product |  | 1,168 |  |  | 1,150 |  |  | 3,376 |  |  | 3,515 |  |
| Service |  | 122 |  |  | 96 |  |  | 336 |  |  | 217 |  |
| Climate Solutions Europe sales |  | 1,290 |  |  | 1,246 |  |  | 3,712 |  |  | 3,732 |  |
| Product |  | 659 |  |  | 678 |  |  | 2,016 |  |  | 2,153 |  |
| Service |  | 174 |  |  | 162 |  |  | 525 |  |  | 473 |  |
| Climate Solutions Asia Pacific, Middle East & Africa sales |  | 833 |  |  | 840 |  |  | 2,541 |  |  | 2,626 |  |
| Product |  | 686 |  |  | 810 |  |  | 1,961 |  |  | 2,433 |  |
| Service |  | 59 |  |  | 127 |  |  | 161 |  |  | 361 |  |
| Climate Solutions Transportation sales |  | 745 |  |  | 937 |  |  | 2,122 |  |  | 2,794 |  |
| Net sales |  | $ | 5,579 |  |  | $ | 5,984 |  |  | $ | 16,910 |  |  | $ | 17,338 |  |

[0001783180-25-000066:notes:87]
[same as prior period, unchanged from 0001783180-25-000052:notes:83]

[0001783180-25-000066:notes:88]
[same as prior period, unchanged from 0001783180-25-000052:notes:84]

[0001783180-25-000066:notes:89]
| (In millions) |  | September 30,2025 |  | December 31,2024 |
| Contract assets (included within Other current assets) |  | $ | 520 |  |  | $ | 366 |  |
| Contract assets, non-current (included within Other assets) |  | 55 |  |  | 65 |  |
| Total contract assets |  | 575 |  |  | 431 |  |
| Contract liabilities (included within Accrued liabilities) |  | (546) |  |  | (553) |  |
| Contract liabilities, non-current (included within Other long-term liabilities) |  | (186) |  |  | (164) |  |
| Total contract liabilities |  | (732) |  |  | (717) |  |
| Net contract assets (liabilities) |  | $ | (157) |  |  | $ | (286) |  |

[0001783180-25-000066:notes:90]
The timing of revenue recognition, billings and cash collections results in contract assets and contract liabilities. Contract assets relate to the conditional right to consideration for any completed performance under a contract when costs are incurred in excess of billings under the percentage-of-completion methodology. Contract liabilities relate to payments received in advance of performance under a contract or when the Company has a right to consideration that is conditioned upon transfer of a good or service to a customer. Contract liabilities are recognized as revenue as (or when) the Company performs under the contract.
The Company recognized revenue of $491 million during the nine months ended September 30, 2025, that related to contract liabilities as of January 1, 2025. The Company expects a majority of its current contract liabilities at the end of the period to be recognized as revenue in the next 12 months.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0001783180-25-000066:notes:91]
[same as prior period, unchanged from 0001783180-25-000052:notes:87]

[0001783180-25-000066:notes:92]
[same as prior period, unchanged from 0001783180-25-000052:notes:88]


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0001783180-25-000066:notes:93]
Geographic external sales are attributed to the geographic regions based on their location of origin. With the exception of the United States as presented in the table below, there were no individually significant countries with sales exceeding 10% of total sales during the three and nine months ended September 30, 2025 and 2024.

[0001783180-25-000066:notes:94]
|  |  | Three Months Ended September 30, |  | Nine Months EndedSeptember 30, |
| (In millions) |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| United States |  | $ | 2,860 |  |  | $ | 3,154 |  |  | $ | 9,027 |  |  | $ | 8,778 |  |
| International: |  |  |  |  |  |  |  |  |
| Europe |  | 1,560 |  |  | 1,723 |  |  | 4,481 |  |  | 5,152 |  |
| Asia Pacific |  | 961 |  |  | 923 |  |  | 2,883 |  |  | 2,886 |  |
| Other |  | 198 |  |  | 184 |  |  | 519 |  |  | 522 |  |
| Net sales |  | $ | 5,579 |  |  | $ | 5,984 |  |  | $ | 16,910 |  |  | $ | 17,338 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001783180-25-000066:notes:95]
[same as prior period, unchanged from 0001783180-25-000052:notes:91]

[0001783180-25-000066:notes:96]
[same as prior period, unchanged from 0001783180-25-000052:notes:92]

[0001783180-25-000066:notes:97]
|  | Three Months Ended September 30, |  | Nine Months EndedSeptember 30, |
| (In millions) | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Climate Solutions Americas | $ | 8 |  |  | $ | 5 |  |  | $ | 12 |  |  | $ | 6 |  |
| Climate Solutions Europe | 22 |  |  | 45 |  |  | 48 |  |  | 72 |  |
| Climate Solutions Asia Pacific, Middle East & Africa | 6 |  |  | 5 |  |  | 14 |  |  | 9 |  |
| Climate Solutions Transportation | 3 |  |  | 4 |  |  | 5 |  |  | 5 |  |
| Total Segment | 39 |  |  | 59 |  |  | 79 |  |  | 92 |  |
| Corporate and other | 11 |  |  | 1 |  |  | 26 |  |  | 5 |  |
| Total restructuring costs (1) | $ | 50 |  |  | $ | 60 |  |  | $ | 105 |  |  | $ | 97 |  |
| Cost of sales | $ | 11 |  |  | $ | 15 |  |  | $ | 22 |  |  | $ | 36 |  |
| Selling, general and administrative | 39 |  |  | 45 |  |  | 83 |  |  | 61 |  |
| Total restructuring costs (1) | $ | 50 |  |  | $ | 60 |  |  | $ | 105 |  |  | $ | 97 |  |

[0001783180-25-000066:notes:98]
[same as prior period, unchanged from 0001783180-25-000052:notes:94]

[0001783180-25-000066:notes:99]
[same as prior period, unchanged from 0001783180-25-000052:notes:95]

[0001783180-25-000066:notes:100]
|  |  | Nine Months EndedSeptember 30, |
| (In millions) |  | 2025 |  | 2024 |
| Balance as of January 1, |  | $ | 69 |  |  | $ | 41 |  |
| Net pre-tax restructuring costs |  | 86 |  |  | 90 |  |
| Acquisitions |  | — |  |  | 8 |  |
| Utilization, foreign exchange and other |  | (73) |  |  | (55) |  |
| Balance as of September 30, |  | $ | 82 |  |  | $ | 84 |  |

[0001783180-25-000066:notes:101]
As of September 30, 2025, the Company had $82 million accrued for costs associated with its announced restructuring initiatives. The balance relates to cost reduction efforts, primarily severance related across each of the Company's segments. The Company expects a majority of the balance to be utilized within one year.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001783180-25-000066:notes:102]
INCOME TAXES
The Company accounts for income tax expense in accordance with ASC 740, Income Taxes ("ASC 740"), which requires an estimate of the annual effective income tax rate for the full year to be applied to the respective interim period, taking into account year-to-date amounts and projected results for the full year. The effective tax rate for the three months ended September 30, 2025, was a 0.2% benefit compared with 22.3% for the three months ended September 30, 2024. The effective tax rate for the three months ended September 30, 2025 was lower than the effective tax rate for the three months ended September 30, 2024, primarily due to a net tax benefit of $64 million from changes to the German effective rate and a statutory reduction to the German corporate tax rate enacted during the current period and a tax benefit of $49 million from the re-organization of a Japanese subsidiary.

[0001783180-25-000066:notes:103]
The effective tax rate for the nine months ended September 30, 2025, was 15.2% compared with 21.4% for the nine months ended September 30, 2024. The year-over-year decrease was primarily driven by a net tax benefit of $64 million from changes to the German effective rate and a statutory reduction to the German corporate tax rate enacted during the current period, a tax benefit of $49 million from the re-organization of a Japanese subsidiary and a $16 million tax benefit generated by the purchase of investment tax credits from a third-party. These amounts were partially offset by the absence of a $21 million tax benefit associated with the TMA and UTC's conclusion of certain income tax matters from their 2017 and 2018 tax audit with the IRS recognized during the nine months ended September 30, 2024.

[0001783180-25-000066:notes:104]
[same as prior period, unchanged from 0001783180-25-000052:notes:100]

[0001783180-25-000066:notes:105]
The Company conducts business globally and files income tax returns in U.S. federal, state and foreign jurisdictions. In certain jurisdictions, the Company's operations were included in UTC's combined tax returns for the periods through the Distribution. During the nine months ended September 30, 2025, the IRS finalized the examination of UTC's tax year 2020, resulting in the recognition of a tax benefit of $6 million. Carrier's tax year 2022 is under examination by the IRS, but is in an early stage. The Australia tax office is auditing the Company's 2021 tax return, including the review of the disentanglement of the Chubb Australia business, with the audit expected to close in late 2026. In the normal course of business, the Company is subject to examination by taxing authorities throughout the world, including Australia, Canada, China, France, Germany, Hong Kong, India, Italy, Mexico, the Netherlands, Poland, Singapore, the United Kingdom and the United States. The Company is no longer subject to U.S. federal income tax examination for years prior to 2022 and, with few exceptions, is no longer subject to state, local and foreign income tax examinations for tax years prior to 2014.

[0001783180-25-000066:notes:106]
In the ordinary course of business, there is inherent uncertainty in quantifying the Company's income tax positions. The Company assesses its income tax positions and records tax benefits for all years subject to examination based upon management’s evaluation of the facts, circumstances and information available at the reporting date. The Company believes that it is reasonably possible that a net decrease in unrecognized tax benefits of $10 million to $50 million may occur within 12 months as a result of additional uncertain tax positions, the revaluation of uncertain tax positions arising from examinations, appeals, court decisions and/or the expiration of tax statutes.
On July 4, 2025, the One Big Beautiful Bill Act was enacted in the U.S., making permanent key provisions from the Tax Cuts and Jobs Act including full expensing of capital investments and U.S. incurred research and development costs, while also modifying the international tax framework and reinstating favorable treatment for certain business tax items. The legislation has staggered effective dates from 2025 through 2027. The U.S. law change did not have a material impact on the Company's Statement of Operations. However, the Company anticipates a reduction in 2025 U.S. cash taxes given the allowable full expensing of U.S. capital investments and U.S. incurred research and development costs.


## us-gaap:EarningsPerShareTextBlock

[0001783180-25-000066:notes:107]
[same as prior period, unchanged from 0001783180-25-000052:notes:103]

[0001783180-25-000066:notes:108]
[same as prior period, unchanged from 0001783180-25-000052:notes:104]

[0001783180-25-000066:notes:109]
|  |  | Three Months Ended September 30, |  | Nine Months EndedSeptember 30, |
| (In millions, except per share amounts) |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Net earnings (loss) attributable to common shareowners |  | $ | 428 |  |  | $ | 447 |  |  | $ | 1,431 |  |  | $ | 3,053 |  |
| Basic weighted-average number of shares outstanding |  | 848.8 |  |  | 901.2 |  |  | 856.8 |  |  | 900.9 |  |
| Stock awards and equity units (share equivalent) |  | 9.8 |  |  | 13.8 |  |  | 10.9 |  |  | 13.5 |  |
| Diluted weighted-average number of shares outstanding |  | 858.6 |  |  | 915.0 |  |  | 867.7 |  |  | 914.4 |  |
| Antidilutive shares excluded from computation of diluted earnings per share |  | 2.0 |  |  | 2.0 |  |  | 2.0 |  |  | 2.0 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001783180-25-000066:notes:110]
[same as prior period, unchanged from 0001783180-25-000052:notes:106]

[0001783180-25-000066:notes:111]
[same as prior period, unchanged from 0001783180-25-000052:notes:107]

[0001783180-25-000066:notes:112]
[same as prior period, unchanged from 0001783180-25-000052:notes:108]

[0001783180-25-000066:notes:113]
[same as prior period, unchanged from 0001783180-25-000052:notes:109]

[0001783180-25-000066:notes:114]
[same as prior period, unchanged from 0001783180-25-000052:notes:110]

[0001783180-25-000066:notes:115]
[same as prior period, unchanged from 0001783180-25-000052:notes:111]

[0001783180-25-000066:notes:116]
[same as prior period, unchanged from 0001783180-25-000052:notes:112]

[0001783180-25-000066:notes:117]
[same as prior period, unchanged from 0001783180-25-000052:notes:113]

[0001783180-25-000066:notes:118]
[same as prior period, unchanged from 0001783180-25-000052:notes:114]

[0001783180-25-000066:notes:119]
[same as prior period, unchanged from 0001783180-25-000052:notes:115]

[0001783180-25-000066:notes:120]
[same as prior period, unchanged from 0001783180-25-000052:notes:116]

[0001783180-25-000066:notes:121]
[same as prior period, unchanged from 0001783180-25-000052:notes:117]

[0001783180-25-000066:notes:122]
During 2024, $40 million of acquisition-related costs were incurred, of which $3 million and $40 million was recognized during the three and nine months ended September 30, 2024, respectively. These acquisition costs are reflected within Selling, general and administrative in the Unaudited Condensed Consolidated Statement of Operations.

[0001783180-25-000066:notes:123]
The assets, liabilities and results of operations of the VCS Business were consolidated in the accompanying Unaudited Condensed Consolidated Financial Statements as of the date of acquisition and reported primarily within the Company's Climate Solutions Europe segment.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001783180-25-000066:notes:124]
[same as prior period, unchanged from 0001783180-25-000052:notes:120]

[0001783180-25-000066:notes:125]
[same as prior period, unchanged from 0001783180-25-000052:notes:121]

[0001783180-25-000066:notes:126]
[same as prior period, unchanged from 0001783180-25-000052:notes:122]

[0001783180-25-000066:notes:127]
|  | Three Months Ended September 30, |  | Nine Months EndedSeptember 30, |
| (In millions) | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Net sales | $ | — |  |  | $ | 475 |  |  | $ | — |  |  | $ | 1,992 |  |
| Costs of sales | — |  |  | (285) |  |  | — |  |  | (1,179) |  |
| Research and development | — |  |  | (16) |  |  | — |  |  | (75) |  |
| Selling, general and administrative | (5) |  |  | (115) |  |  | (5) |  |  | (479) |  |
| Other income (expense), net | — |  |  | (593) |  |  | — |  |  | (592) |  |
| Gain (loss) on divestitures and deconsolidation | — |  |  | 509 |  |  | (22) |  |  | 3,390 |  |
| Interest (expense) income, net | — |  |  | (5) |  |  | — |  |  | (39) |  |
| Earnings (loss) before income taxes | (5) |  |  | (30) |  |  | (27) |  |  | 3,018 |  |
| Income tax (expense) benefit | — |  |  | 112 |  |  | — |  |  | 154 |  |
| Tax on divestitures and deconsolidation | 26 |  |  | (199) |  |  | 31 |  |  | (1,275) |  |
| Discontinued operations, net of tax | $ | 21 |  |  | $ | (117) |  |  | $ | 4 |  |  | $ | 1,897 |  |

[0001783180-25-000066:notes:128]
[same as prior period, unchanged from 0001783180-25-000052:notes:124]

[0001783180-25-000066:notes:129]
[same as prior period, unchanged from 0001783180-25-000052:notes:125]

[0001783180-25-000066:notes:130]
[same as prior period, unchanged from 0001783180-25-000052:notes:126]

[0001783180-25-000066:notes:131]
[same as prior period, unchanged from 0001783180-25-000052:notes:127]

[0001783180-25-000066:notes:132]
On October 1, 2024, the Company completed the sale of CCR for cash proceeds of $679 million. CCR, historically reported in the Company's Climate Solutions Transportation segment, is a global supplier of turnkey solutions for commercial refrigeration systems and services, with a primary focus on serving food retail customers, cold storage facilities and warehouses. Upon sale, the Company recognized a gross gain on the sale of $318 million, which is included in Other income (expense), net. During 2025, the Company finalized the working capital and other adjustments provided in the stock purchase agreement governing the sale of CCR.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001783180-25-000066:notes:133]
[same as prior period, unchanged from 0001783180-25-000052:notes:129]

[0001783180-25-000066:notes:134]
[same as prior period, unchanged from 0001783180-25-000052:notes:130]

[0001783180-25-000066:notes:135]
[same as prior period, unchanged from 0001783180-25-000052:notes:131]

[0001783180-25-000066:notes:136]
[same as prior period, unchanged from 0001783180-25-000052:notes:132]

[0001783180-25-000066:notes:137]
[same as prior period, unchanged from 0001783180-25-000052:notes:133]

[0001783180-25-000066:notes:138]
[same as prior period, unchanged from 0001783180-25-000052:notes:134]

[0001783180-25-000066:notes:139]
[same as prior period, unchanged from 0001783180-25-000052:notes:135]

[0001783180-25-000066:notes:140]
[same as prior period, unchanged from 0001783180-25-000052:notes:136]

[0001783180-25-000066:notes:141]
[same as prior period, unchanged from 0001783180-25-000052:notes:137]

[0001783180-25-000066:notes:142]
|  |  | Three Months Ended September 30, 2025 |
| (In millions) |  | CSA |  | CSE |  | CSAME |  | CST |  | Segment Total |  |  |  |  |
| Net sales |  | $ | 2,711 |  |  | $ | 1,290 |  |  | $ | 833 |  |  | $ | 745 |  |  | $ | 5,579 |  |  |  |  |  |
| Cost of goods sold |  | (1,837) |  |  | (888) |  |  | (630) |  |  | (541) |  |  | (3,896) |  |  |  |  |  |
| Research and development |  | (83) |  |  | (19) |  |  | (15) |  |  | (16) |  |  | (133) |  |  |  |  |  |
| Selling, general and administrative |  | (273) |  |  | (264) |  |  | (122) |  |  | (74) |  |  | (733) |  |  |  |  |  |
| Equity method investment net earnings |  | 33 |  |  | — |  |  | 28 |  |  | — |  |  | 61 |  |  |  |  |  |
| Other income (expense), net |  | (18) |  |  | 1 |  |  | 3 |  |  | 1 |  |  | (13) |  |  |  |  |  |
| Segment operating profit |  | $ | 533 |  |  | $ | 120 |  |  | $ | 97 |  |  | $ | 115 |  |  | $ | 865 |  |  |  |  |  |

[0001783180-25-000066:notes:143]
|  |  | Three Months Ended September 30, 2024 |
| (In millions) |  | CSA |  | CSE |  | CSAME |  | CST |  | Segment Total |  |  |  |  |
| Net sales |  | $ | 2,961 |  |  | $ | 1,246 |  |  | $ | 840 |  |  | $ | 937 |  |  | $ | 5,984 |  |  |  |  |  |
| Cost of goods sold |  | (1,920) |  |  | (851) |  |  | (625) |  |  | (686) |  |  | (4,082) |  |  |  |  |  |
| Research and development |  | (98) |  |  | (20) |  |  | (17) |  |  | (20) |  |  | (155) |  |  |  |  |  |
| Selling, general and administrative |  | (230) |  |  | (259) |  |  | (125) |  |  | (90) |  |  | (704) |  |  |  |  |  |
| Equity method investment net earnings |  | 40 |  |  | — |  |  | 27 |  |  | — |  |  | 67 |  |  |  |  |  |
| Other income (expense), net |  | (3) |  |  | 13 |  |  | 6 |  |  | (4) |  |  | 12 |  |  |  |  |  |
| Segment operating profit |  | $ | 750 |  |  | $ | 129 |  |  | $ | 106 |  |  | $ | 137 |  |  | $ | 1,122 |  |  |  |  |  |
|  |  | Nine Months Ended September 30, 2025 |
| (In millions) |  | CSA |  | CSE |  | CSAME |  | CST |  | Segment Total |  |  |  |  |
| Net sales |  | $ | 8,535 |  |  | $ | 3,712 |  |  | $ | 2,541 |  |  | $ | 2,122 |  |  | $ | 16,910 |  |  |  |  |  |
| Cost of goods sold |  | (5,598) |  |  | (2,559) |  |  | (1,893) |  |  | (1,531) |  |  | (11,581) |  |  |  |  |  |
| Research and development |  | (258) |  |  | (56) |  |  | (46) |  |  | (49) |  |  | (409) |  |  |  |  |  |
| Selling, general and administrative |  | (800) |  |  | (781) |  |  | (360) |  |  | (215) |  |  | (2,156) |  |  |  |  |  |
| Equity method investment net earnings |  | 102 |  |  | (1) |  |  | 76 |  |  | 6 |  |  | 183 |  |  |  |  |  |
| Other income (expense), net |  | 1 |  |  | 9 |  |  | 35 |  |  | 7 |  |  | 52 |  |  |  |  |  |
| Segment operating profit |  | $ | 1,982 |  |  | $ | 324 |  |  | $ | 353 |  |  | $ | 340 |  |  | $ | 2,999 |  |  |  |  |  |
|  |  | Nine Months Ended September 30, 2024 |
| (In millions) |  | CSA |  | CSE |  | CSAME |  | CST |  | Segment Total |  |  |  |  |
| Net sales |  | $ | 8,186 |  |  | $ | 3,732 |  |  | $ | 2,626 |  |  | $ | 2,794 |  |  | $ | 17,338 |  |  |  |  |  |
| Cost of goods sold |  | (5,411) |  |  | (2,510) |  |  | (1,916) |  |  | (2,054) |  |  | (11,891) |  |  |  |  |  |
| Research and development |  | (298) |  |  | (62) |  |  | (53) |  |  | (60) |  |  | (473) |  |  |  |  |  |
| Selling, general and administrative |  | (697) |  |  | (782) |  |  | (383) |  |  | (290) |  |  | (2,152) |  |  |  |  |  |
| Equity method investment net earnings |  | 106 |  |  | (2) |  |  | 77 |  |  | 6 |  |  | 187 |  |  |  |  |  |
| Other income (expense), net |  | 2 |  |  | 13 |  |  | 20 |  |  | (8) |  |  | 27 |  |  |  |  |  |
| Segment operating profit |  | $ | 1,888 |  |  | $ | 389 |  |  | $ | 371 |  |  | $ | 388 |  |  | $ | 3,036 |  |  |  |  |  |

[0001783180-25-000066:notes:144]
|  |  | Three Months Ended September 30, |  | Nine Months EndedSeptember 30, |
| (In millions) |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Reconciliation to Earnings before income taxes |  |  |  |  |  |  |  |  |
| Segment operating profit |  | $ | 865 |  |  | $ | 1,122 |  |  | $ | 2,999 |  |  | $ | 3,036 |  |
| Corporate and other |  | (42) |  |  | (78) |  |  | (162) |  |  | (172) |  |
| Restructuring costs |  | (50) |  |  | (60) |  |  | (105) |  |  | (97) |  |
| Amortization of acquired intangibles |  | (221) |  |  | (175) |  |  | (636) |  |  | (517) |  |
| Acquisition step-up amortization |  | — |  |  | (31) |  |  | — |  |  | (251) |  |
| Acquisition/divestiture-related costs |  | (13) |  |  | (15) |  |  | (32) |  |  | (87) |  |
| CCR gain |  | — |  |  | — |  |  | 7 |  |  | — |  |
| Viessmann-related hedges |  | — |  |  | — |  |  | — |  |  | (86) |  |
| Gain on liability adjustment |  | — |  |  | — |  |  | — |  |  | 46 |  |
| Non-service pension (expense) benefit |  | (9) |  |  | (1) |  |  | (8) |  |  | (1) |  |
| Interest (expense) income, net |  | (97) |  |  | 8 |  |  | (270) |  |  | (290) |  |
| Earnings before income taxes |  | $ | 433 |  |  | $ | 770 |  |  | $ | 1,793 |  |  | $ | 1,581 |  |

[0001783180-25-000066:notes:145]
[same as prior period, unchanged from 0001783180-25-000052:notes:140]


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001783180-25-000066:notes:146]
RELATED PARTIES
Equity Method Investments

[0001783180-25-000066:notes:147]
The Company sells products to and purchases products from unconsolidated entities accounted for under the equity method and, therefore, these entities are considered to be related parties. Amounts attributable to equity method investees are as follows:

[0001783180-25-000066:notes:148]
|  |  | Three Months Ended September 30, |  | Nine Months EndedSeptember 30, |
| (In millions) |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Sales to equity method investees included in Product sales |  | $ | 668 |  |  | $ | 774 |  |  | $ | 2,293 |  |  | $ | 2,329 |  |
| Purchases from equity method investees included in Cost of products sold |  | $ | 68 |  |  | $ | 64 |  |  | $ | 172 |  |  | $ | 178 |  |

[0001783180-25-000066:notes:149]
The Company had receivables from and payables to equity method investees as follows:

[0001783180-25-000066:notes:150]
| (In millions) |  | September 30,2025 |  | December 31,2024 |
| Receivables from equity method investees included in Accounts receivable, net |  | $ | 255 |  |  | $ | 363 |  |
| Payables to equity method investees included in Accounts payable |  | $ | 40 |  |  | $ | 32 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001783180-25-000066:notes:151]
COMMITMENTS AND CONTINGENT LIABILITIES
The Company is involved in various litigation, claims and administrative proceedings, including those related to environmental (including asbestos) and legal matters. In accordance with ASC 450, Contingencies, the Company records accruals for loss contingencies when it is probable that a liability has been incurred and the amount of the loss can be reasonably estimated. These accruals are generally based upon a range of possible outcomes. If no amount within the range is a better estimate than any other, the Company accrues the minimum amount. In addition, these estimates are reviewed periodically and adjusted to reflect additional information when it becomes available. The Company is unable to predict the final outcome of the following matters based on the information currently available, except as otherwise noted. However, the Company does not believe that the resolution of any of these matters will have a material adverse effect upon its results of operations or financial condition.

[0001783180-25-000066:notes:152]
Environmental Matters

[0001783180-25-000066:notes:153]
The Company’s operations are subject to environmental regulation by various authorities. The Company has accrued for the costs of environmental remediation activities, including but not limited to investigatory, remediation, operating and maintenance costs and performance guarantees. The most likely cost to be incurred is accrued based on an evaluation of currently available facts with respect to individual sites, including the technology required to remediate, current laws and regulations and prior remediation experience.

[0001783180-25-000066:notes:154]
The outstanding liabilities for environmental obligations are as follows:

[0001783180-25-000066:notes:155]
| (In millions) |  | September 30,2025 |  | December 31,2024 |
| Environmental reserves included in Accrued liabilities |  | $ | 13 |  |  | $ | 25 |  |
| Environmental reserves included in Other long-term liabilities |  | 187 |  |  | 185 |  |
| Total Environmental reserves |  | $ | 200 |  |  | $ | 210 |  |

[0001783180-25-000066:notes:156]
For sites with multiple responsible parties, the Company considers its likely proportionate share of the anticipated remediation costs and the ability of other parties to fulfill their obligations in establishing a provision for these costs. Accrued environmental liabilities are not reduced by potential insurance reimbursements and are undiscounted.

[0001783180-25-000066:notes:157]
Asbestos Matters

[0001783180-25-000066:notes:158]
The Company has been named as a defendant in lawsuits alleging personal injury as a result of exposure to asbestos allegedly integrated into certain Carrier products or business premises. While the Company has never manufactured asbestos and no longer incorporates it into any currently-manufactured products, certain products that the Company no longer manufactures contained components incorporating asbestos. A substantial majority of these asbestos-related claims have been dismissed without payment or have been covered in full or in part by insurance or other forms of indemnity. Additional cases were litigated and settled without any insurance reimbursement. The amounts involved in asbestos-related claims were not material individually or in the aggregate in any period.

[0001783180-25-000066:notes:159]
The Company's asbestos liabilities and related insurance recoveries are as follows:

[0001783180-25-000066:notes:160]
| (In millions) |  | September 30,2025 |  | December 31,2024 |
| Asbestos liabilities included in Accrued liabilities |  | $ | 17 |  |  | $ | 17 |  |
| Asbestos liabilities included in Other long-term liabilities |  | 201 |  |  | 208 |  |
| Total Asbestos liabilities |  | $ | 218 |  |  | $ | 225 |  |
| Asbestos-related recoveries included in Other current assets |  | $ | 6 |  |  | $ | 7 |  |
| Asbestos-related recoveries included in Other assets |  | 86 |  |  | 88 |  |
| Total Asbestos-related recoveries |  | $ | 92 |  |  | $ | 95 |  |

[0001783180-25-000066:notes:161]
The amounts recorded for asbestos-related liabilities are based on currently available information and assumptions that the Company believes are reasonable and are made with input from outside actuarial experts. These amounts are undiscounted and exclude the Company’s legal fees to defend the asbestos claims, which are expensed as incurred. In addition, the Company has recorded insurance recovery receivables for probable asbestos-related recoveries.

[0001783180-25-000066:notes:162]
Aqueous Film Forming Foam Litigation

[0001783180-25-000066:notes:163]
As of September 30, 2025, the Company, Kidde-Fenwal, Inc. ("KFI") and others have been named as defendants in more than 13,000 lawsuits filed in United States state or federal courts and a single case in Canada alleging that the historic use of Aqueous Film Forming Foam ("AFFF") caused personal injuries and damage to property and water supplies. In December 2018, the U.S. Judicial Panel on Multidistrict Litigation transferred and consolidated all AFFF cases pending in the U.S. federal courts against the Company, KFI and others to the U.S. District Court for the District of South Carolina (the "MDL Proceedings"). Individual plaintiffs in the MDL Proceedings generally seek damages for alleged personal injuries, medical monitoring, diminution in property value and injunctive relief to remediate alleged contamination of water supplies. U.S. state, municipal and water utility plaintiffs in the MDL Proceedings generally seek damages and costs related to the remediation of public property and water supplies.

[0001783180-25-000066:notes:164]
AFFF is a firefighting foam, developed beginning in the late 1960s pursuant to U.S. military specification, used to extinguish certain types of hydrocarbon-fueled fires. The lawsuits identified above relate to Kidde Fire Fighting, Inc., which owned the “National Foam” business that manufactured AFFF for sale to government (including the U.S. federal government) and non-government customers in the U.S. at a single facility located in West Chester, Pennsylvania (the "Pennsylvania Site"). Kidde Fire Fighting, Inc. was acquired by a UTC subsidiary in 2005 and merged into KFI in 2007. In 2013, KFI divested the AFFF businesses to an unrelated third party. The Company acquired KFI as part of the Separation in April 2020.

[0001783180-25-000066:notes:165]
The key components that contribute to AFFF's fire-extinguishing capabilities are known as fluorosurfactants. Neither the Company, nor KFI, nor any of the Company's subsidiaries involved in the AFFF litigation manufactured fluorosurfactants. Instead, the National Foam business purchased these substances from unrelated third parties for use in manufacturing AFFF. Plaintiffs in the MDL Proceedings allege that the fluorosurfactants used by various manufacturers in producing AFFF contained, or over time degraded into, compounds known as per- and polyfluoroalkyl substances (referred to collectively as "PFAS"), including perflourooctanesulfonic acid ("PFOS") and perflourooctanoic acid ("PFOA"). Plaintiffs further allege that, as a result of the use of AFFF, PFOS and PFOA were released into the environment and, in some instances, ultimately reached drinking water supplies.

[0001783180-25-000066:notes:166]
Plaintiffs in the MDL Proceedings have named multiple defendants, including suppliers of chemicals and raw materials used to manufacture fluorosurfactants, fluorosurfactant manufacturers and AFFF manufacturers. The defendants in the MDL Proceedings moved for summary judgment on the government contractor defense, which potentially applies to AFFF sold to or used by the U.S. government. After full briefing and oral argument, on September 16, 2022, the MDL court declined to enter summary judgment for the defendants. The defense, however, remains available at any trial in which it would apply.

[0001783180-25-000066:notes:167]
On May 14, 2023, KFI filed a voluntary petition with the United States Bankruptcy Court for the District of Delaware (the “Bankruptcy Court”) seeking relief under chapter 11 of the Bankruptcy Code, after the Company determined that it would not provide financial support to KFI going forward other than ensuring KFI has access to services necessary for the effective operation of its business. As a result, all litigation against KFI was automatically stayed. By agreement, all AFFF-related litigation against the Company, its other subsidiaries and RTX also was stayed. On November 21, 2023, the Bankruptcy Court ordered certain parties, including the Company, to participate in mediation sessions with respect to claims that might be asserted by and against it in the bankruptcy proceedings.

[0001783180-25-000066:notes:168]
Following the conclusion of these mediation sessions in October 2024, the Company entered into a Settlement and Plan Support Agreement which contemplates that the Company will subsequently enter into three distinct settlement agreements (collectively, the “Proposed Settlement Agreements”) with KFI, the Official Committee of Unsecured Creditors appointed in KFI’s bankruptcy case (the “Committee”) and the Plaintiffs’ Executive Committee (the “MDL PEC”) appointed in the MDL Proceedings.

[0001783180-25-000066:notes:169]
The first of the Proposed Settlement Agreements relates to claims that the Company is responsible for liabilities arising from KFI’s manufacture or sale of AFFF (“Estate Claims Settlement”). Upon Bankruptcy Court approval, the Estate Claims Settlement will permanently resolve all present and future claims that the Company is responsible for any liabilities of KFI, including all liabilities arising from KFI’s manufacture and sale of AFFF. The second and third of the Proposed Settlement Agreements release a very substantial amount of current and future direct claims against the Company (the “Direct Claims Settlements”). Direct claims allege that UTC, which indirectly owned KFI’s AFFF business for eight years, engaged in conduct independent of KFI that caused harm to AFFF claimants. The Company agreed to indemnify UTC for these direct claims when it was spun-off from UTC. Upon approval by the MDL Court, the Direct Claims Settlements resolve and enjoin all current and future AFFF-related direct claims against the Company by participating public water providers and airports. Non-settling parties may still assert direct AFFF-related claims, although we expect a vast majority of public water providers and airports will participate in the Direct Claims Settlements.

[0001783180-25-000066:notes:170]
As part of the Proposed Settlement Agreements, the Company will pay $615 million in cash over five years, 100% of the net sale proceeds from its sale of KFI’s assets to Pacific Avenue Capital Partners, which are estimated to be $115 million, and contribute the right to recover proceeds under certain of its insurance policies. The Company will be entitled to receive up to $2.4 billion of proceeds from those insurance policies and will contribute the first $125 million of such proceeds as additional consideration in the Direct Claims Settlements. The Company also will be entitled to any earnouts payable to KFI under the KFI sale agreement. The Company expects insurance payments it receives in the future, in the aggregate, to cover the amount paid under the Proposed Settlement Agreements. As a result of the Proposed Settlement Agreements, the Company recorded a liability in the amount of $565 million during the three months ended September 30, 2024. The amount recognized is in addition to liabilities of $50 million that the Company recorded upon the deconsolidation of KFI on May 14, 2023, as further discussed below. As of September 30, 2025, the Company has not recorded any amounts associated with expected insurance proceeds.

[0001783180-25-000066:notes:171]
The Company and KFI believe that they have meritorious defenses to the remaining AFFF claims. Given the numerous factual, scientific and legal issues to be resolved relating to these claims, the Company is unable to assess the probability of liability or to reasonably estimate a range of possible loss at this time. There can be no assurance that any such future exposure will not be material in any period.

[0001783180-25-000066:notes:172]
On November 14, 2024, KFI filed the chapter 11 plan of liquidation (as may be further amended, restated, supplemented, waived, or otherwise modified from time to time, the "Chapter 11 Plan"), which incorporates the Estate Claims Settlement, provides for the treatment of the various creditor classes, and establishes wind-down provisions, among other things, and the disclosure statement for the Chapter 11 Plan (as may be further amended, restated, supplemented, waived, or otherwise modified from time to time, the "Disclosure Statement"). A hearing to approve the Disclosure Statement was held in June 2025. A revised and supplemented Disclosure Statement was filed on August 15, 2025. The Bankruptcy Court held a hearing on that statement on October 6, 2025. Following that hearing, the Bankruptcy Court ordered that the revised and supplemented Disclosure Statement be modified further in two areas, which the parties are addressing.

[0001783180-25-000066:notes:173]
Deconsolidation Due to Bankruptcy

[0001783180-25-000066:notes:174]
As of May 14, 2023, the Company no longer controlled KFI as its activities are subject to review and oversight by the Bankruptcy Court. Therefore, KFI was deconsolidated and its respective assets and liabilities were derecognized from the Company’s Unaudited Condensed Consolidated Financial Statements. Upon deconsolidation, the Company determined the fair value of its retained interest in KFI to be zero and we accounted for it prospectively using the cost method.

[0001783180-25-000066:notes:175]
In connection with the bankruptcy filing, KFI entered into several agreements with subsidiaries of the Company to ensure they have access to services necessary for the effective operation of their business. All post-deconsolidation activity between the Company and KFI are reported as third-party transactions recorded within the Company's Unaudited Condensed Consolidated Statement of Operations. Since the petition date, there were no material transactions between the Company and KFI other than a $15 million payment during 2024 by the Company to KFI under the terms of a tax sharing arrangement.

[0001783180-25-000066:notes:176]
Income Taxes

[0001783180-25-000066:notes:177]
Under the TMA relating to the Separation, the Company is responsible to UTC for its share of the Tax Cuts and Jobs Act transition tax associated with foreign undistributed earnings as of December 31, 2017. As a result, a liability of $101 million is included within the accompanying Unaudited Condensed Consolidated Balance Sheet within Accrued liabilities as of September 30, 2025. This obligation is expected to be settled in April 2026. The Company believes that the likelihood of incurring losses materially in excess of this amount is remote.

[0001783180-25-000066:notes:178]
Other

[0001783180-25-000066:notes:179]
The Company has other commitments and contingent liabilities related to legal proceedings, self-insurance programs and matters arising in the ordinary course of business. The Company accrues for contingencies generally based upon a range of possible outcomes. If no amount within the range is a better estimate than any other, the Company accrues the minimum amount.

[0001783180-25-000066:notes:180]
In the ordinary course of business, the Company is also routinely a defendant in, party to or otherwise subject to many pending and threatened legal actions, claims, disputes and proceedings. These matters are often based on alleged violations of contract, product liability, warranty, regulatory, environmental, health and safety, employment, intellectual property, tax and other laws. In some of these proceedings, claims for substantial monetary damages are asserted against the Company and could result in fines, penalties, compensatory or treble damages or non-monetary relief. The Company does not believe that these matters will have a material adverse effect upon its results of operations, cash flows or financial condition.
