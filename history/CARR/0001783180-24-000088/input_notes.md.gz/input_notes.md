# CARR notes — 0001783180-24-000088


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001783180-24-000088:notes:1]
DESCRIPTION OF THE BUSINESS
Carrier Global Corporation (the "Company") is a global leader in intelligent climate and energy solutions with a focus on providing differentiated, digitally-enabled lifecycle solutions to its customers. The Company's portfolio includes industry-leading brands such as Carrier, Viessmann, Toshiba, Automated Logic and Carrier Transicold that offer innovative heating, ventilating, air conditioning ("HVAC"), refrigeration and cold chain transportation solutions to help make the world safer and more comfortable. The Company also provides a broad array of related building services, including audit, design, installation, system integration, repair, maintenance and monitoring. The Company's operations are classified into two segments: HVAC and Refrigeration.

[0001783180-24-000088:notes:2]
[same as prior period, unchanged from 0001783180-24-000077:notes:2]


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001783180-24-000088:notes:3]
BASIS OF PRESENTATION
The Unaudited Condensed Consolidated Financial Statements include all accounts of the Company and its wholly-owned and majority-owned subsidiaries in which it has control. Inter-company accounts and transactions have been eliminated. Related party transactions between the Company and its equity method investees have not been eliminated. Non-controlling interest represents a non-controlling investor's interests in the results of subsidiaries that the Company controls and consolidates.

[0001783180-24-000088:notes:4]
[same as prior period, unchanged from 0001783180-24-000077:notes:4]

[0001783180-24-000088:notes:5]
[same as prior period, unchanged from 0001783180-24-000077:notes:5]

[0001783180-24-000088:notes:6]
[same as prior period, unchanged from 0001783180-24-000077:notes:6]

[0001783180-24-000088:notes:7]
[same as prior period, unchanged from 0001783180-24-000077:notes:7]

[0001783180-24-000088:notes:8]
During the fourth quarter of 2023, the net assets of the Company's Industrial Fire business ("Industrial Fire") met the criteria to be classified as held for sale. As a result, the assets and liabilities of Industrial Fire are presented as held for sale on the accompanying Unaudited Condensed Consolidated Balance Sheet as of December 31, 2023, and recorded at the lower of their carrying value or fair value less estimated cost to sell. On March 5, 2024, the Company entered into a stock purchase agreement to sell Industrial Fire to Sentinel Capital Partners. The sale of Industrial Fire was completed on July 1, 2024. See Note 16 - Divestitures for additional information.

[0001783180-24-000088:notes:9]
On December 12, 2023, the Company entered into a stock purchase agreement to sell its Commercial Refrigeration business ("CCR") to Haier Group Corporation for an enterprise value of approximately $775 million. As a result, the assets and liabilities of CCR are presented as held for sale on the accompanying Unaudited Condensed Consolidated Balance Sheet as of September 30, 2024 and December 31, 2023, and recorded at the lower of their carrying value or fair value less estimated cost to sell. The sale of CCR was completed on October 1, 2024. See Note 16 - Divestitures for additional information.

[0001783180-24-000088:notes:10]
On August 15, 2024, the Company entered into a stock purchase agreement to sell its Commercial and Residential Fire business (“CRF Business”) to an affiliate of Lone Star Funds for an enterprise value of approximately $3.0 billion. As a result, the assets and liabilities of the CRF Business are presented as held for sale on the accompanying Unaudited Condensed Consolidated Balance Sheet as of September 30, 2024 and December 31, 2023, and recorded at the lower of their carrying value or fair value less estimated cost to sell. See Note 16 - Divestitures for additional information.

[0001783180-24-000088:notes:11]
Discontinued Operations

[0001783180-24-000088:notes:12]
In 2023, the Company announced plans to exit its Fire & Security and Commercial Refrigeration businesses over the course of 2024. The announced plan to exit the Fire & Security segment represents a single disposal plan to separately divest multiple businesses over different reporting periods. Upon the CRF Business qualifying as held for sale during the three months ended September 30, 2024, the components of the Fire & Security segment in aggregate met the criteria to be presented as discontinued operations in the accompanying Unaudited Condensed Consolidated Statement of Operations and Unaudited Condensed Consolidated Statement of Cash Flows. In addition, the assets and liabilities of the CRF Business have been reclassified to held for sale at December 31, 2023. The results of the CCR business did not meet the criteria to be presented in discontinued operations. See Note 16 - Divestitures for additional information.

[0001783180-24-000088:notes:13]
[same as prior period, unchanged from 0001783180-24-000077:notes:9]

[0001783180-24-000088:notes:14]
On May 14, 2023, Kidde-Fenwal, Inc. ("KFI"), an indirect wholly-owned subsidiary of the Company, filed a petition for voluntary reorganization under Chapter 11 of the United States Bankruptcy Code ("Chapter 11") in the United States Bankruptcy Court for the District of Delaware. KFI, an industrial fire detection and suppression business historically reported in the Company's Fire & Security segment, indicated that it intended to use the bankruptcy process to explore strategic alternatives, including the sale of KFI as a going concern. As of the petition date, KFI was deconsolidated and its respective assets and liabilities were derecognized from the Company's Unaudited Condensed Consolidated Financial Statements. The sale of KFI was completed on July 1, 2024. See Note 19 - Commitments and Contingent Liabilities for additional information.

[0001783180-24-000088:notes:15]
[same as prior period, unchanged from 0001783180-24-000077:notes:11]

[0001783180-24-000088:notes:16]
On April 3, 2020 (the "Distribution Date"), United Technologies Corporation ("UTC"), since renamed RTX Corporation ("Raytheon Technologies Corporation" or "RTX"), completed the spin-off of Carrier into an independent, publicly traded company (the "Separation") through a pro-rata distribution (the "Distribution") on a one-for-one basis of all of the outstanding shares of common stock of Carrier to UTC shareowners who held shares of UTC common stock as of the close of business on March 19, 2020, the record date of the Distribution. Following the Separation and Distribution, the Company entered into several agreements with UTC and Otis Worldwide Corporation ("Otis") that govern various aspects of the relationship among the Company, UTC and Otis. As of September 30, 2024, only certain portions of the Tax Matters Agreement ("TMA") remain in effect.

[0001783180-24-000088:notes:17]
[same as prior period, unchanged from 0001783180-24-000077:notes:13]

[0001783180-24-000088:notes:18]
[same as prior period, unchanged from 0001783180-24-000077:notes:14]

[0001783180-24-000088:notes:19]
Recently Issued Accounting Pronouncements

[0001783180-24-000088:notes:20]
In November 2023, the FASB issued ASU 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures (“ASU 2023-07”), which requires public entities to disclose information about their reportable segments’ significant expenses on an interim and annual basis. In addition, the amendments clarify circumstances in which an entity can disclose multiple segment measures of profit or loss, provide new segment disclosure requirements for entities with a single reportable segment and contain other disclosure requirements. ASU 2023-07 is effective for fiscal years beginning after December 15, 2023 and interim periods beginning after December 15, 2024, with early adoption permitted. The Company is currently assessing the impact of this ASU on its financial statements.

[0001783180-24-000088:notes:21]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures ("ASU 2023-09"), which requires public entities to disclose disaggregated information about their effective tax rate reconciliation as well as information on income taxes paid. ASU 2023-09 is effective for fiscal years beginning after December 15, 2024, with early adoption permitted. The Company is currently assessing the impact of this ASU on its financial statements.

[0001783180-24-000088:notes:22]
[same as prior period, unchanged from 0001783180-24-000077:notes:18]


## us-gaap:InventoryDisclosureTextBlock

[0001783180-24-000088:notes:23]
[same as prior period, unchanged from 0001783180-24-000077:notes:19]

[0001783180-24-000088:notes:24]
[same as prior period, unchanged from 0001783180-24-000077:notes:20]

[0001783180-24-000088:notes:25]
| (In millions) |  | September 30,2024 |  | December 31,2023 |
| Raw materials |  | $ | 872 |  |  | $ | 534 |  |
| Work-in-process |  | 246 |  |  | 245 |  |
| Finished goods |  | 1,528 |  |  | 1,044 |  |
| Inventories, net |  | $ | 2,646 |  |  | $ | 1,823 |  |

[0001783180-24-000088:notes:26]
The Company performs periodic assessments utilizing customer demand, production requirements and historical usage rates to determine the existence of excess and obsolete inventory and records necessary provisions to reduce such inventories to the lower of cost or estimated net realizable value. Raw materials, work-in-process and finished goods are net of valuation reserves of $224 million and $173 million as of September 30, 2024 and December 31, 2023, respectively.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001783180-24-000088:notes:27]
[same as prior period, unchanged from 0001783180-24-000077:notes:23]

[0001783180-24-000088:notes:28]
[same as prior period, unchanged from 0001783180-24-000077:notes:24]

[0001783180-24-000088:notes:29]
| (In millions) |  | HVAC |  | Refrigeration |  |  |  | Corporate and other |  | Total |
| Balance as of December 31, 2023 |  | $ | 6,407 |  |  | $ | 1,037 |  |  |  |  | $ | 76 |  |  | $ | 7,520 |  |
| Acquisitions (1) |  | 7,608 |  |  | 29 |  |  |  |  | — |  |  | 7,637 |  |
| Foreign currency translation |  | 61 |  |  | 76 |  |  |  |  | — |  |  | 137 |  |
| Balance as of September 30, 2024 |  | $ | 14,076 |  |  | $ | 1,142 |  |  |  |  | $ | 76 |  |  | $ | 15,294 |  |

[0001783180-24-000088:notes:30]
[same as prior period, unchanged from 0001783180-24-000077:notes:26]

[0001783180-24-000088:notes:31]
[same as prior period, unchanged from 0001783180-24-000077:notes:28]

[0001783180-24-000088:notes:32]
[same as prior period, unchanged from 0001783180-24-000077:notes:29]

[0001783180-24-000088:notes:33]
|  |  | September 30, 2024 |  | December 31, 2023 |
| (In millions) |  | Gross Amount |  | Accumulated Amortization |  | Net Amount |  | Gross Amount |  | Accumulated Amortization |  | Net Amount |
| Customer relationships |  | $ | 5,990 |  |  | $ | (852) |  |  | $ | 5,138 |  |  | $ | 1,056 |  |  | $ | (445) |  |  | $ | 611 |  |
| Patents and trademarks |  | 946 |  |  | (140) |  |  | 806 |  |  | 255 |  |  | (96) |  |  | 159 |  |
| Service portfolios and other |  | 1,637 |  |  | (463) |  |  | 1,174 |  |  | 431 |  |  | (256) |  |  | 175 |  |
| Total intangible assets |  | $ | 8,573 |  |  | $ | (1,455) |  |  | $ | 7,118 |  |  | $ | 1,742 |  |  | $ | (797) |  |  | $ | 945 |  |

[0001783180-24-000088:notes:34]
[same as prior period, unchanged from 0001783180-24-000077:notes:31]

[0001783180-24-000088:notes:35]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
| (In millions) |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Amortization expense of Intangible assets |  | $ | 213 |  |  | $ | 54 |  |  | $ | 632 |  |  | $ | 167 |  |

[0001783180-24-000088:notes:36]
Annual Impairment Test

[0001783180-24-000088:notes:37]
The Company tested its goodwill and indefinite-lived intangible assets for impairment on July 1 as part of its annual assessment. For each test except one, the Company qualitatively assessed all relevant events or circumstances that could impact the estimate of fair value and determined it was more likely than not that the fair value of each reporting unit and indefinite-lived intangible assets exceeded their carrying amount. For the remaining test, the Company performed a quantitative goodwill impairment test to determine if any impairment existed. The test did not indicate any goodwill impairment.
In connection with the presentation of the CRF Business as held for sale at September 30, 2024, the Company reassigned goodwill to the remaining business activities previously reported within the Fire & Security segment. For the test, the Company qualitatively assessed all relevant events or circumstances that could impact the estimate of fair value and determined it was more likely than not that the fair value of the remaining business activities exceeded their carrying amount. Due to these business activities no longer meeting the criteria of a reportable segment, they have been included in Corporate and other.


## us-gaap:DebtDisclosureTextBlock

[0001783180-24-000088:notes:38]
BORROWINGS AND LINES OF CREDIT
Long-term debt consisted of the following:

[0001783180-24-000088:notes:39]
| (In millions) |  |  |  | September 30,2024 |  | December 31,2023 |
| 2.242% Notes due 2025 (1) |  |  |  | $ | 1,200 |  |  | $ | 1,200 |  |
| 4.375% Notes due 2025 (2) |  |  |  | 836 |  |  | 830 |  |
| 5.800% Notes due 2025 |  |  |  | — |  |  | 1,000 |  |
| 2.493% Notes due 2027 |  |  |  | 900 |  |  | 900 |  |
| 4.125% Notes due 2028 |  |  |  | 836 |  |  | 830 |  |
| 2.722% Notes due 2030 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.700% Notes due 2031 |  |  |  | 750 |  |  | 750 |  |
| 4.500% Notes due 2032 |  |  |  | 948 |  |  | 941 |  |
| 5.900% Notes due 2034 |  |  |  | 875 |  |  | 1,000 |  |
| 3.377% Notes due 2040 |  |  |  | 1,500 |  |  | 1,500 |  |
| 3.577% Notes due 2050 |  |  |  | 1,400 |  |  | 2,000 |  |
| 6.200% Notes due 2054 |  |  |  | 650 |  |  | 1,000 |  |
| Total long-term notes |  |  |  | 11,895 |  |  | 13,951 |  |
| Japanese Term Loan Facility |  |  |  | 374 |  |  | 379 |  |
| Other debt (including project financing obligations and finance leases) |  |  |  | 243 |  |  | 74 |  |
| Discounts and debt issuance costs |  |  |  | (80) |  |  | (111) |  |
| Total debt |  |  |  | 12,432 |  |  | 14,293 |  |
| Less: current portion of long-term debt |  |  |  | 2,095 |  |  | 51 |  |
| Long-term debt, net of current portion |  |  |  | $ | 10,337 |  |  | $ | 14,242 |  |

[0001783180-24-000088:notes:40]
(1) 2.242% Notes due February 15, 2025; reclassified to Current portion of long-term debt.

[0001783180-24-000088:notes:41]
(2) 4.375% Notes due May 29, 2025; reclassified to Current portion of long-term debt.

[0001783180-24-000088:notes:42]
Acquisition Funding

[0001783180-24-000088:notes:43]
On January 2, 2024, the Company completed the acquisition of the VCS Business for total consideration of $14.2 billion. Under the terms of the Agreement, 20% of the purchase price was paid in Carrier common stock, issued directly to Viessmann and subject to certain lock up provisions and 80% was paid in cash, subject to working capital and other adjustments. In order to fund the Euro-denominated cash portion of the purchase price, the Company used cash on hand, debt financing and various term loan facilities.

[0001783180-24-000088:notes:44]
Debt Issuance

[0001783180-24-000088:notes:45]
In November 2023, the Company issued $3.0 billion principal amount of USD-denominated notes in three tranches. The tranches consisted of $1.0 billion aggregate principal amount of 5.80% notes due 2025, $1.0 billion aggregate principal amount of 5.90% notes due 2034 and $1.0 billion aggregate principal amount of 6.20% notes due 2054 (collectively, the “USD Notes”). In addition, the Company issued €2.35 billion principal amount of Euro-denominated notes in three tranches. The tranches consisted of €750 million aggregate principal amount of 4.375% notes due 2025, €750 million aggregate principal amount of 4.125% notes due 2028 and €850 million aggregate principal amount of 4.50% notes due 2032 (collectively, the “Euro Notes”). The Company capitalized $51 million of deferred financing costs which are being amortized over the term of their related notes. The notes are subject to certain customary covenants and the Company has the option to redeem the notes in whole or in part at any time prior to their stated maturity date at the redemption price set forth in the indenture agreements. In June 2024, the Company redeemed the $1.0 billion aggregate principal amount of 5.80% notes due in 2025 and incurred a $8 million make-whole premium upon prepayment and wrote off $4 million of related unamortized debt financing costs.

[0001783180-24-000088:notes:46]
Bridge Loan

[0001783180-24-000088:notes:47]
On April 25, 2023, the Company entered into commitment letters with JPMorgan Chase Bank, N.A., BofA Securities, Inc. and Bank of America, N.A. to provide a €8.2 billion aggregate principal, senior unsecured bridge term loan facility (the “Bridge Loan”). Euro-denominated borrowings bore interest at the EURIBOR Rate plus a ratings-based margin, USD-denominated borrowings bore interest at either a Term SOFR Rate plus 0.10% and a ratings-based margin or, alternatively, at a base rate plus a ratings-based margin. The Company capitalized $48 million of deferred financing costs associated with the Bridge Loan which were amortized over the commitment period. Upon entering into a senior unsecured delayed draw term loan facility and issuing the USD Notes and the Euro Notes, the Company reduced the Bridge Loan by €7.7 billion and accelerated the amortization on $25 million of deferred financing costs in Interest expense during 2023. On January 2, 2024, the Company entered into a 60-day senior unsecured term loan agreement consisting of a Euro-denominated tranche in an aggregate amount of €113 million and a USD-denominated tranche in an aggregate amount of $349 million (the “60-day Loan”). Upon entering into the 60-day Loan, the Company reduced the final portion of the Bridge Loan by €500 million and subsequently terminated the agreement. Borrowings under the 60-day Loan were repaid in March 2024.

[0001783180-24-000088:notes:48]
Delayed Draw Facility

[0001783180-24-000088:notes:49]
On May 19, 2023, the Company entered into a senior unsecured delayed draw term loan credit agreement with JPMorgan Chase Bank, N.A., as administrative agent and certain other lenders that permits aggregate borrowings of up to €2.3 billion (the "Delayed Draw Facility"). The facility consisted of an 18-month, Euro-denominated tranche in an aggregate amount of €1.15 billion and a 3-year, Euro-denominated tranche in an aggregate amount of €1.15 billion. Euro-denominated borrowings bear interest at the EURIBOR Rate plus a ratings-based margin, USD-denominated borrowings bear interest at either a Term SOFR Rate plus 0.10% and a ratings-based margin or, alternatively, at a base rate plus a ratings-based margin. The Company capitalized $4 million of deferred financing costs which will be amortized over the respective term of the tranches. On January 2, 2024, the Company borrowed the full amount available under the Delayed Draw Facility in U.S. Dollars. Borrowings under the Delayed Draw Facility were repaid in June 2024 and the facility was subsequently terminated.

[0001783180-24-000088:notes:50]
364-Day Revolver

[0001783180-24-000088:notes:51]
On May 17, 2024, the Company entered into a 364-day, $500 million, senior unsecured revolving credit agreement with JPMorgan Chase Bank, N.A., as administrative agent and certain other lenders (the “364-day Revolver”). Borrowings are available in U.S. Dollars and Euros. USD-denominated borrowings bear interest at either a Term SOFR Rate plus 0.10% and a ratings-based margin or, alternatively, at a base rate plus a ratings-based margin, Euro-denominated borrowings bear interest at the Adjusted EURIBOR Rate plus a ratings-based margin. Upon entering into the 364-day Revolver, the Company terminated its existing $500 million senior unsecured revolving credit agreement that was set to mature in May 2024. As of September 30, 2024, there were no borrowings outstanding under the 364-day Revolver.

[0001783180-24-000088:notes:52]
Japanese Term Loan Facility

[0001783180-24-000088:notes:53]
On July 15, 2022, the Company entered into a five-year, JPY 54 billion (approximately $400 million) senior unsecured term loan facility with MUFG Bank Ltd., as administrative agent and lender, and certain other lenders (the "Japanese Term Loan Facility"). Borrowings under the Japanese Term Loan Facility bear interest at a rate equal to the Tokyo Term Risk Free Rate plus 0.75%. The Company capitalized $2 million of deferred financing costs which are being amortized over its term. On July 25, 2022, the Company borrowed JPY 54 billion under the Japanese Term Loan Facility and used the proceeds to fund a portion of the Yen-denominated purchase price of Toshiba Carrier Corporation ("TCC") and to pay related fees and expenses.

[0001783180-24-000088:notes:54]
Revolving Credit Facility

[0001783180-24-000088:notes:55]
On May 19, 2023, the Company entered into a revolving credit agreement with JPMorgan Chase Bank, N.A., as administrative agent, and certain other lenders, permitting aggregate borrowings of up to $2.0 billion pursuant to an unsecured, unsubordinated revolving credit facility that matures in May 2028 (the "Revolving Credit Facility"). The Revolving Credit Facility supports the Company's commercial paper program and can be used for other general corporate purposes. Borrowings are available in U.S. Dollars and Euros. U.S. Dollar borrowings bear interest at either a Term SOFR Rate plus 0.10% and a ratings-based margin or, alternatively, at an alternate base rate plus a ratings-based margin. Euro borrowings bear interest at an adjusted EURIBOR rate plus a ratings-based margin. A ratings-based commitment fee is charged on unused commitments. In addition, the Company capitalized $2 million of deferred financing costs which are being amortized over its term. As of September 30, 2024, there were no borrowings outstanding under the Revolving Credit Facility.

[0001783180-24-000088:notes:56]
Commercial Paper Program

[0001783180-24-000088:notes:57]
The Company has a $2.0 billion unsecured, unsubordinated commercial paper program, which can be used for general corporate purposes, including the funding of working capital and potential acquisitions. As of September 30, 2024, there were no borrowings outstanding under the commercial paper program.

[0001783180-24-000088:notes:58]
Project Financing Arrangements

[0001783180-24-000088:notes:59]
The Company is involved in long-term construction contracts in which it arranges project financing with certain customers. As a result, the Company issued $40 million and $14 million of debt during the nine months ended September 30, 2024 and 2023, respectively. Long-term debt repayments associated with these financing arrangements during the nine months ended September 30, 2024 and 2023, were $7 million and $15 million, respectively.

[0001783180-24-000088:notes:60]
Debt Covenants

[0001783180-24-000088:notes:61]
The Revolving Credit Facility, 364-day Revolver, the indenture for the long-term notes and the Japanese Term Loan Facility contain affirmative and negative covenants customary for financings of these types, which, among other things, limit the Company's ability to incur certain liens, to make certain fundamental changes and to enter into sale and leaseback transactions. As of September 30, 2024, the Company was in compliance with the covenants under the agreements governing its outstanding indebtedness.

[0001783180-24-000088:notes:62]
Tender Offers
In July 2024, the Company commenced tender offers to purchase up to $800 million ("Aggregate Tender Cap") aggregate principal of certain tranches of the Company's notes. The tender offers included payment of applicable accrued and unpaid interest up to the settlement date, along with a fixed spread for early repayment. Based on participation, the Company elected to increase the Aggregate Tender Cap and settle the tender offers early. The aggregate principal amount tendered and accepted was approximately $1.0 billion, which included $125 million of notes due 2034, $350 million of notes due 2054 and approximately $600 million of notes due 2050. Upon settlement, the Company recognized a net gain of $97 million and wrote off $11 million of unamortized deferred financing costs within Interest (expense) income, net on the accompanying Unaudited Condensed Consolidated Statement of Operations.


## us-gaap:FairValueDisclosuresTextBlock

[0001783180-24-000088:notes:63]
[same as prior period, unchanged from 0001783180-24-000077:notes:57]

[0001783180-24-000088:notes:64]
[same as prior period, unchanged from 0001783180-24-000077:notes:58]

[0001783180-24-000088:notes:65]
[same as prior period, unchanged from 0001783180-24-000077:notes:59]

[0001783180-24-000088:notes:66]
[same as prior period, unchanged from 0001783180-24-000077:notes:60]

[0001783180-24-000088:notes:67]
[same as prior period, unchanged from 0001783180-24-000077:notes:61]

[0001783180-24-000088:notes:68]
[same as prior period, unchanged from 0001783180-24-000077:notes:62]

[0001783180-24-000088:notes:69]
[same as prior period, unchanged from 0001783180-24-000077:notes:63]

[0001783180-24-000088:notes:70]
[same as prior period, unchanged from 0001783180-24-000077:notes:64]

[0001783180-24-000088:notes:71]
[same as prior period, unchanged from 0001783180-24-000077:notes:65]

[0001783180-24-000088:notes:72]
[same as prior period, unchanged from 0001783180-24-000077:notes:66]

[0001783180-24-000088:notes:73]
In July 2024, the Company entered into cross currency swaps with Barclays Bank PLC as syndication swap arranger in order to manage foreign currency translation risk on Euro-denominated assets. The swaps have an aggregate notional amount of $2.0 billion and are measured at fair value on a recurring basis using observable market inputs, such as forward, discount and interest rates. The Company designated the cross currency swaps as a partial hedge of its investment in certain subsidiaries whose functional currency is the Euro. As a result, changes in the fair value of the swaps are recorded in Equity in the accompanying Unaudited Condensed Consolidated Balance Sheet.

[0001783180-24-000088:notes:74]
[same as prior period, unchanged from 0001783180-24-000077:notes:67]

[0001783180-24-000088:notes:75]
| (In millions) |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |
| September 30, 2024 |  |  |  |  |  |  |  |  |
| Derivative assets (1)(3) |  | $ | 70 |  |  | $ | — |  |  | $ | 70 |  |  | $ | — |  |
| Derivative liabilities (2)(3) |  | $ | (69) |  |  | $ | — |  |  | $ | (69) |  |  | $ | — |  |
| December 31, 2023 |  |  |  |  |  |  |  |  |
| Derivative assets (1) (3) |  | $ | 32 |  |  | $ | — |  |  | $ | 32 |  |  | $ | — |  |
| Derivative liabilities (2) (3) |  | $ | (126) |  |  | $ | — |  |  | $ | (126) |  |  | $ | — |  |

[0001783180-24-000088:notes:76]
[same as prior period, unchanged from 0001783180-24-000077:notes:69]

[0001783180-24-000088:notes:77]
[same as prior period, unchanged from 0001783180-24-000077:notes:70]

[0001783180-24-000088:notes:78]
[same as prior period, unchanged from 0001783180-24-000077:notes:71]

[0001783180-24-000088:notes:79]
[same as prior period, unchanged from 0001783180-24-000077:notes:72]

[0001783180-24-000088:notes:80]
|  |  | September 30, 2024 |  | December 31, 2023 |  |
| (In millions) |  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  |
| Total long-term notes (1) |  | $ | 11,895 |  |  | $ | 11,372 |  |  | $ | 13,951 |  |  | $ | 13,194 |  |  |

[0001783180-24-000088:notes:81]
[same as prior period, unchanged from 0001783180-24-000077:notes:74]

[0001783180-24-000088:notes:82]
[same as prior period, unchanged from 0001783180-24-000077:notes:75]


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0001783180-24-000088:notes:83]
[same as prior period, unchanged from 0001783180-24-000077:notes:76]


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001783180-24-000088:notes:84]
[same as prior period, unchanged from 0001783180-24-000077:notes:77]

[0001783180-24-000088:notes:85]
[same as prior period, unchanged from 0001783180-24-000077:notes:78]

[0001783180-24-000088:notes:86]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
| (In millions) |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Defined benefit plans |  | $ | 16 |  |  | $ | 6 |  |  | $ | 34 |  |  | $ | 17 |  |
| Defined contribution plans |  | $ | 30 |  |  | $ | 30 |  |  | $ | 104 |  |  | $ | 96 |  |
| Multi-employer pension plans |  | $ | 4 |  |  | $ | 3 |  |  | $ | 12 |  |  | $ | 11 |  |

[0001783180-24-000088:notes:87]
[same as prior period, unchanged from 0001783180-24-000077:notes:80]

[0001783180-24-000088:notes:88]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
| (In millions) |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Service cost |  | $ | 4 |  |  | $ | 4 |  |  | $ | 11 |  |  | $ | 12 |  |
| Interest cost |  | 13 |  |  | 8 |  |  | 26 |  |  | 24 |  |
| Expected return on plan assets |  | (13) |  |  | (8) |  |  | (27) |  |  | (24) |  |
| Amortization of prior service cost |  | — |  |  | 1 |  |  | — |  |  | 2 |  |
| Recognized actuarial net (gain) loss |  | — |  |  | (1) |  |  | 1 |  |  | (2) |  |
| Net settlement, curtailment and special termination benefit (gain) loss |  | 1 |  |  | — |  |  | 1 |  |  | — |  |
| Net periodic pension expense (benefit) |  | $ | 5 |  |  | $ | 4 |  |  | $ | 12 |  |  | $ | 12 |  |
| Amounts recorded in continuing operations |  | $ | 5 |  |  | $ | 4 |  |  | $ | 12 |  |  | $ | 12 |  |
| Amounts recorded in discontinued operations |  | — |  |  | — |  |  | — |  |  | — |  |
| Net periodic pension expense (benefit) |  | $ | 5 |  |  | $ | 4 |  |  | $ | 12 |  |  | $ | 12 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001783180-24-000088:notes:89]
[same as prior period, unchanged from 0001783180-24-000077:notes:82]

[0001783180-24-000088:notes:90]
[same as prior period, unchanged from 0001783180-24-000077:notes:83]

[0001783180-24-000088:notes:91]
[same as prior period, unchanged from 0001783180-24-000077:notes:84]

[0001783180-24-000088:notes:92]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
| (In millions) |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Equity compensation costs - equity settled |  | $ | 28 |  |  | $ | 23 |  |  | $ | 76 |  |  | $ | 63 |  |
| Equity compensation costs - cash settled (1) |  | 2 |  |  | 1 |  |  | 3 |  |  | 3 |  |
| Total stock-based compensation expense |  | $ | 30 |  |  | $ | 24 |  |  | $ | 79 |  |  | $ | 66 |  |
| Amounts recorded in continuing operations |  | $ | 27 |  |  | $ | 22 |  |  | $ | 68 |  |  | $ | 58 |  |
| Amounts recorded in discontinued operations |  | 3 |  |  | 2 |  |  | 11 |  |  | 8 |  |
| Total stock-based compensation expense |  | $ | 30 |  |  | $ | 24 |  |  | $ | 79 |  |  | $ | 66 |  |

[0001783180-24-000088:notes:93]
[same as prior period, unchanged from 0001783180-24-000077:notes:86]


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001783180-24-000088:notes:94]
[same as prior period, unchanged from 0001783180-24-000077:notes:87]

[0001783180-24-000088:notes:95]
[same as prior period, unchanged from 0001783180-24-000077:notes:88]

[0001783180-24-000088:notes:96]
|  |  | Nine Months Ended September 30, |
| (In millions) |  | 2024 |  | 2023 |
| Balance as of January 1, |  | $ | 568 |  |  | $ | 544 |  |
| Warranties, performance guarantees issued and changes in estimated liability |  | 229 |  |  | 188 |  |
| Settlements made |  | (211) |  |  | (146) |  |
| Other |  | 5 |  |  | (14) |  |
| Acquisitions (1) |  | 202 |  |  | — |  |
| Balance as of September 30, |  | $ | 793 |  |  | $ | 572 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001783180-24-000088:notes:97]
EQUITY
The authorized number of shares of common stock of Carrier is 4,000,000,000 shares of $0.01 par value. As of September 30, 2024 and December 31, 2023, 947,450,955 and 883,068,393 shares of common stock were issued, respectively, which includes 49,659,143 and 43,490,981 shares of treasury stock, respectively.

[0001783180-24-000088:notes:98]
[same as prior period, unchanged from 0001783180-24-000077:notes:91]

[0001783180-24-000088:notes:99]
The Company may repurchase its outstanding common stock from time to time subject to market conditions and at the Company's discretion. Repurchases occur in the open market or through one or more other public or private transactions

[0001783180-24-000088:notes:100]
pursuant to plans complying with Rules 10b5-1 and 10b-18 under the Exchange Act. Shares acquired are recognized at cost and presented separately on the balance sheet as a reduction to Equity. Since the initial authorization in February 2021, the Company's Board of Directors authorized the repurchase of up to $4.1 billion of the Company's outstanding common stock.

[0001783180-24-000088:notes:101]
As of December 31, 2023, the Company repurchased 43.5 million shares of common stock for an aggregate purchase price of $2.0 billion, including shares repurchased under an accelerated share repurchase agreement. As a result, the Company had approximately $2.1 billion remaining under the current authorization at December 31, 2023.

[0001783180-24-000088:notes:102]
During the nine months ended September 30, 2024, the Company repurchased 6.2 million shares of common stock for an aggregate purchase price of $0.4 billion. As a result, the Company had approximately $1.7 billion remaining under the current authorization at September 30, 2024. In addition, the Company's Board of Directors approved a $3 billion increase to the Company's existing share repurchase program in October 2024.

[0001783180-24-000088:notes:103]
[same as prior period, unchanged from 0001783180-24-000077:notes:94]

[0001783180-24-000088:notes:104]
A summary of changes in the components of Accumulated other comprehensive income (loss) for the three and nine months ended September 30, 2024 is as follows:

[0001783180-24-000088:notes:105]
| (In millions) |  | Foreign Currency Translation |  | Defined Benefit Pension and Post-retirement Plans |  |  |  | Unrealized Hedging Gains (Losses) |  | Accumulated Other Comprehensive Income (Loss) |
| Balance as of December 31, 2023 |  | $ | (1,444) |  |  | $ | (100) |  |  |  |  | $ | 58 |  |  | $ | (1,486) |  |
| Other comprehensive income (loss) before reclassifications, net |  | (385) |  |  | — |  |  |  |  | — |  |  | (385) |  |
| Amounts reclassified, pre-tax |  | — |  |  | — |  |  |  |  | (1) |  |  | (1) |  |
| Balance as of March 31, 2024 |  | $ | (1,829) |  |  | $ | (100) |  |  |  |  | $ | 57 |  |  | $ | (1,872) |  |
| Other comprehensive income (loss) before reclassifications, net |  | (187) |  |  | — |  |  |  |  | — |  |  | (187) |  |
| Amounts reclassified, pre-tax |  | — |  |  | 1 |  |  |  |  | (1) |  |  | — |  |
| Divestitures, net |  | 373 |  |  | — |  |  |  |  | — |  |  | 373 |  |
| Balance as of June 30, 2024 |  | $ | (1,643) |  |  | $ | (99) |  |  |  |  | $ | 56 |  |  | $ | (1,686) |  |
| Other comprehensive income (loss) before reclassifications, net |  | 669 |  |  | — |  |  |  |  | — |  |  | 669 |  |
| Amounts reclassified, pre-tax |  | — |  |  | 2 |  |  |  |  | (1) |  |  | 1 |  |
| Tax expense (benefit) reclassified |  | — |  |  | (1) |  |  |  |  | — |  |  | (1) |  |
| Divestitures, net |  | 215 |  |  | — |  |  |  |  | — |  |  | 215 |  |
| Balance as of September 30, 2024 |  | $ | (759) |  |  | $ | (98) |  |  |  |  | $ | 55 |  |  | $ | (802) |  |

[0001783180-24-000088:notes:106]
A summary of changes in the components of Accumulated other comprehensive income (loss) for the three and nine months ended September 30, 2023 is as follows:

[0001783180-24-000088:notes:107]
| (In millions) |  | Foreign Currency Translation |  | Defined Benefit Pension and Post-retirement Plans |  |  |  | Unrealized Hedging Gains (Losses) |  | Accumulated Other Comprehensive Income (Loss) |
| Balance as of December 31, 2022 |  | $ | (1,604) |  |  | $ | (84) |  |  |  |  | $ | — |  |  | $ | (1,688) |  |
| Other comprehensive income (loss) before reclassifications, net |  | 52 |  |  | — |  |  |  |  | — |  |  | 52 |  |
| Balance as of March 31, 2023 |  | $ | (1,552) |  |  | $ | (84) |  |  |  |  | $ | — |  |  | $ | (1,636) |  |
| Other comprehensive income (loss) before reclassifications, net |  | (55) |  |  | — |  |  |  |  | — |  |  | (55) |  |
| Balance as of June 30, 2023 |  | $ | (1,607) |  |  | $ | (84) |  |  |  |  | $ | — |  |  | $ | (1,691) |  |
| Other comprehensive income (loss) before reclassifications, net |  | (245) |  |  | — |  |  |  |  | 80 |  |  | (165) |  |
| Balance as of September 30, 2023 |  | $ | (1,852) |  |  | $ | (84) |  |  |  |  | $ | 80 |  |  | $ | (1,856) |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001783180-24-000088:notes:108]
[same as prior period, unchanged from 0001783180-24-000077:notes:99]

[0001783180-24-000088:notes:109]
[same as prior period, unchanged from 0001783180-24-000077:notes:100]

[0001783180-24-000088:notes:110]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
| (In millions) |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Sales Type |  |  |  |  |  |  |  |  |
| Product |  | $ | 4,504 |  |  | $ | 3,533 |  |  | $ | 13,045 |  |  | $ | 10,488 |  |
| Service |  | 554 |  |  | 475 |  |  | 1,524 |  |  | 1,358 |  |
| HVAC sales |  | 5,058 |  |  | 4,008 |  |  | 14,569 |  |  | 11,846 |  |
| Product |  | 811 |  |  | 808 |  |  | 2,434 |  |  | 2,453 |  |
| Service |  | 127 |  |  | 116 |  |  | 361 |  |  | 341 |  |
| Refrigeration sales |  | 938 |  |  | 924 |  |  | 2,795 |  |  | 2,794 |  |
| Total segment sales |  | 5,996 |  |  | 4,932 |  |  | 17,364 |  |  | 14,640 |  |
| Eliminations and other (1) |  | (12) |  |  | 3 |  |  | (26) |  |  | (5) |  |
| Net sales |  | $ | 5,984 |  |  | $ | 4,935 |  |  | $ | 17,338 |  |  | $ | 14,635 |  |

[0001783180-24-000088:notes:111]
(1) Includes certain business activities previously reported in the Fire & Security segment.

[0001783180-24-000088:notes:112]
[same as prior period, unchanged from 0001783180-24-000077:notes:102]

[0001783180-24-000088:notes:113]
[same as prior period, unchanged from 0001783180-24-000077:notes:103]

[0001783180-24-000088:notes:114]
| (In millions) |  | September 30,2024 |  | December 31,2023 |
| Contract assets (included within Other current assets) |  | $ | 367 |  |  | $ | 306 |  |
| Contract assets, non-current (included within Other assets) |  | 55 |  |  | 26 |  |
| Total contract assets |  | 422 |  |  | 332 |  |
| Contract liabilities (included within Accrued liabilities) |  | (563) |  |  | (419) |  |
| Contract liabilities, non-current (included within Other long-term liabilities) |  | (162) |  |  | (160) |  |
| Total contract liabilities |  | (725) |  |  | (579) |  |
| Net contract assets (liabilities) |  | $ | (303) |  |  | $ | (247) |  |

[0001783180-24-000088:notes:115]
The timing of revenue recognition, billings and cash collections results in contract assets and contract liabilities. Contract assets relate to the conditional right to consideration for any completed performance under a contract when costs are incurred in excess of billings under the percentage-of-completion methodology. Contract liabilities relate to payments received in advance of performance under a contract or when the Company has a right to consideration that is conditioned upon transfer of a good or service to a customer. Contract liabilities are recognized as revenue as (or when) the Company performs under the contract.
The Company recognized revenue of $401 million during the nine months ended September 30, 2024 that related to contract liabilities as of January 1, 2024. The Company expects a majority of its current contract liabilities at the end of the period to be recognized as revenue in the next 12 months.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0001783180-24-000088:notes:116]
[same as prior period, unchanged from 0001783180-24-000077:notes:106]

[0001783180-24-000088:notes:117]
[same as prior period, unchanged from 0001783180-24-000077:notes:107]


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001783180-24-000088:notes:118]
[same as prior period, unchanged from 0001783180-24-000077:notes:108]

[0001783180-24-000088:notes:119]
[same as prior period, unchanged from 0001783180-24-000077:notes:109]

[0001783180-24-000088:notes:120]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
| (In millions) | 2024 |  | 2023 |  | 2024 |  | 2023 |
| HVAC | $ | 54 |  |  | $ | 25 |  |  | $ | 86 |  |  | $ | 27 |  |
| Refrigeration | 4 |  |  | 4 |  |  | 5 |  |  | 14 |  |
| Total Segment | 58 |  |  | 29 |  |  | 91 |  |  | 41 |  |
| General corporate expenses | 2 |  |  | — |  |  | 6 |  |  | 2 |  |
| Total restructuring costs (1) | $ | 60 |  |  | $ | 29 |  |  | $ | 97 |  |  | $ | 43 |  |
| Cost of sales | $ | 15 |  |  | $ | 4 |  |  | $ | 36 |  |  | $ | 10 |  |
| Selling, general and administrative | 45 |  |  | 25 |  |  | 61 |  |  | 33 |  |
| Total restructuring costs (1) | $ | 60 |  |  | $ | 29 |  |  | $ | 97 |  |  | $ | 43 |  |

[0001783180-24-000088:notes:121]
(1) 2024 restructuring costs include period-related charges.

[0001783180-24-000088:notes:122]
[same as prior period, unchanged from 0001783180-24-000077:notes:112]

[0001783180-24-000088:notes:123]
|  |  | Nine Months Ended September 30, |
| (In millions) |  | 2024 |  | 2023 |
| Balance as of January 1, |  | $ | 41 |  |  | $ | 21 |  |
| Net pre-tax restructuring costs |  | 90 |  |  | 43 |  |
| Acquisitions (1) |  | 8 |  |  | — |  |
| Utilization, foreign exchange and other |  | (55) |  |  | (24) |  |
| Balance as of September 30, |  | $ | 84 |  |  | $ | 40 |  |

[0001783180-24-000088:notes:124]
As of September 30, 2024, the Company had $84 million accrued for costs associated with its announced restructuring initiatives. The balance relates to cost reduction efforts, primarily severance related across each of the Company's segments, along with reserves associated with the Company's planned portfolio transformation. The Company expects a majority of the balance to be utilized within one year.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001783180-24-000088:notes:125]
INCOME TAXES
The Company accounts for income tax expense in accordance with ASC 740, Income Taxes ("ASC 740"), which requires an estimate of the annual effective income tax rate for the full year to be applied to the respective interim period, taking into account year-to-date amounts and projected results for the full year. The effective tax rate was 22.3% for the three months ended September 30, 2024 compared with 37.6% for the three months ended September 30, 2023. The year-over-year decrease was primarily driven by the absence of the non-deductible loss of $257 million on the mark-to-market valuation of the Company's window forward contracts associated with the expected cash outflows of the Euro-denominated purchase price of the VCS Business and a tax charge of $19 million related to the Company's intention to no longer permanently reinvest historical earnings from certain jurisdictions.

[0001783180-24-000088:notes:126]
The effective tax rate was 21.4% for the nine months ended September 30, 2024, compared with 30.3% for the nine months ended September 30, 2023. The year-over-year decrease was primarily driven by the $368 million loss on the mark-to-market valuation of the Company's window forward contracts associated with the expected cash outflows of the Euro-denominated purchase price of the VCS Business during the nine months ended September 30, 2023. In addition, the Company recognized a tax benefit of $21 million associated with the TMA and UTC's conclusion of certain income tax matters from their 2017 and 2018 tax audit with the U.S. Internal Revenue Service ("IRS") during the nine months ended September 30, 2024.

[0001783180-24-000088:notes:127]
[same as prior period, unchanged from 0001783180-24-000077:notes:117]

[0001783180-24-000088:notes:128]
[same as prior period, unchanged from 0001783180-24-000077:notes:118]

[0001783180-24-000088:notes:129]
In the ordinary course of business, there is inherent uncertainty in quantifying the Company's income tax positions. The Company assesses its income tax positions and records tax benefits for all years subject to examination based upon management’s evaluation of the facts, circumstances and information available at the reporting date. The Company believes that it is reasonably possible that a net decrease in unrecognized tax benefits of $15 million to $35 million may occur within 12 months as a result of additional uncertain tax positions, the Separation, the revaluation of uncertain tax positions arising from examinations, appeals, court decisions and/or the expiration of tax statutes.


## us-gaap:EarningsPerShareTextBlock

[0001783180-24-000088:notes:130]
EARNINGS PER SHARE
Earnings per share is computed by dividing Net earnings (loss) attributable to common shareowners by the weighted-average number of shares of common stock outstanding during the period (excluding treasury stock). Diluted earnings per share is computed by giving effect to all potentially dilutive stock awards that are outstanding. The computation of diluted earnings per share excludes the effect of the potential exercise of stock-based awards, including stock appreciation rights and stock options, when the effect of the potential exercise would be anti-dilutive.

[0001783180-24-000088:notes:131]
[same as prior period, unchanged from 0001783180-24-000077:notes:121]

[0001783180-24-000088:notes:132]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
| (In millions, except per share amounts) |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Net earnings (loss) attributable to common shareowners |  | $ | 447 |  |  | $ | 357 |  |  | $ | 3,053 |  |  | $ | 929 |  |
| Basic weighted-average number of shares outstanding |  | 901.2 |  |  | 838.7 |  |  | 900.9 |  |  | 836.6 |  |
| Stock awards and equity units (share equivalent) |  | 13.8 |  |  | 16.0 |  |  | 13.5 |  |  | 16.1 |  |
| Diluted weighted-average number of shares outstanding |  | 915.0 |  |  | 854.7 |  |  | 914.4 |  |  | 852.7 |  |
| Antidilutive shares excluded from computation of diluted earnings per share |  | 2.0 |  |  | 2.0 |  |  | 2.0 |  |  | 1.9 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001783180-24-000088:notes:133]
[same as prior period, unchanged from 0001783180-24-000077:notes:123]

[0001783180-24-000088:notes:134]
[same as prior period, unchanged from 0001783180-24-000077:notes:124]

[0001783180-24-000088:notes:135]
[same as prior period, unchanged from 0001783180-24-000077:notes:125]

[0001783180-24-000088:notes:136]
[same as prior period, unchanged from 0001783180-24-000077:notes:126]

[0001783180-24-000088:notes:137]
[same as prior period, unchanged from 0001783180-24-000077:notes:127]

[0001783180-24-000088:notes:138]
[same as prior period, unchanged from 0001783180-24-000077:notes:128]

[0001783180-24-000088:notes:139]
[same as prior period, unchanged from 0001783180-24-000077:notes:129]

[0001783180-24-000088:notes:140]
| (In millions) |  | Preliminary January 2, 2024 |  | Measurement Period Adjustments |  | As Adjusted January 2, 2024 |
| Cash and cash equivalents |  | $ | 394 |  |  | $ | (1) |  |  | $ | 393 |  |
| Accounts receivable |  | 408 |  |  | 5 |  |  | 413 |  |
| Inventories |  | 948 |  |  | (28) |  |  | 920 |  |
| Other current assets |  | 17 |  |  | — |  |  | 17 |  |
| Fixed assets |  | 913 |  |  | 6 |  |  | 919 |  |
| Intangible assets |  | 6,640 |  |  | 5 |  |  | 6,645 |  |
| Other assets |  | 284 |  |  | 15 |  |  | 299 |  |
| Accounts payable |  | (288) |  |  | (2) |  |  | (290) |  |
| Other liabilities, current |  | (626) |  |  | (8) |  |  | (634) |  |
| Future income tax obligations |  | (1,825) |  |  | 6 |  |  | (1,819) |  |
| Other liabilities |  | (284) |  |  | (15) |  |  | (299) |  |
| Total identifiable net assets |  | 6,581 |  |  | (17) |  |  | 6,564 |  |
| Goodwill |  | 7,576 |  |  | 17 |  |  | 7,593 |  |
| Total consideration |  | $ | 14,157 |  |  | $ | — |  |  | $ | 14,157 |  |

[0001783180-24-000088:notes:141]
[same as prior period, unchanged from 0001783180-24-000077:notes:131]

[0001783180-24-000088:notes:142]
[same as prior period, unchanged from 0001783180-24-000077:notes:132]

[0001783180-24-000088:notes:143]
| (In millions) |  | Estimated Useful Life (in years) |  | Intangible Assets Acquired |
| Customer relationships |  | 17 |  | $ | 4,787 |  |
| Technology |  | 10 - 20 |  | 1,051 |  |
| Trademark |  | 40 |  | 679 |  |
| Backlog |  | 1 |  | 123 |  |
| Other |  | 50 |  | 5 |  |
| Total intangible assets acquired |  |  |  | $ | 6,645 |  |

[0001783180-24-000088:notes:144]
The valuation of intangible assets was determined using an income approach methodology including the multi-period excess earnings method and the relief from royalty method. Key assumptions used in estimating future cash flows included projected revenue growth rates, EBITDA margins, discount rates, customer attrition rates and royalty rates among others. The projected future cash flows are discounted to present value using an appropriate discount rate. As of September 30, 2024, the Company is substantially complete with the process of allocating the purchase price and valuing the acquired assets and liabilities assumed except for certain amounts associated with tax-related assets.

[0001783180-24-000088:notes:145]
During the three and nine months ended September 30, 2024, the Company incurred $3 million and $40 million of acquisition-related costs, respectively. During 2023, $80 million of acquisition-related costs were incurred, of which $19 million and $39 million were recognized during the three and nine months ended September 30, 2023, respectively. These acquisition costs are reflected within Selling, general and administrative in the Unaudited Condensed Consolidated Statement of Operations.

[0001783180-24-000088:notes:146]
[same as prior period, unchanged from 0001783180-24-000077:notes:136]

[0001783180-24-000088:notes:147]
[same as prior period, unchanged from 0001783180-24-000077:notes:137]

[0001783180-24-000088:notes:148]
| (In millions) | Three Months Ended September 30, 2024 |  | Nine Months Ended September 30, 2024 |
| Net sales | $ | 806 |  |  | $ | 2,425 |  |
| Net earnings (loss) | (72) |  |  | (305) |  |

[0001783180-24-000088:notes:149]
The financial results of the VCS Business includes amortization of the step-up to fair value of inventory and backlog as well as intangible amortization totaling $170 million and $667 million for the three and nine months ended September 30, 2024, respectively.

[0001783180-24-000088:notes:150]
[same as prior period, unchanged from 0001783180-24-000077:notes:140]

[0001783180-24-000088:notes:151]
[same as prior period, unchanged from 0001783180-24-000077:notes:141]

[0001783180-24-000088:notes:152]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
| (In millions) | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Net sales | $ | 5,984 |  |  | $ | 5,898 |  |  | $ | 17,338 |  |  | $ | 17,838 |  |
| Net earnings (loss) | 578 |  |  | (44) |  |  | 1,382 |  |  | 207 |  |

[0001783180-24-000088:notes:153]
[same as prior period, unchanged from 0001783180-24-000077:notes:143]


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001783180-24-000088:notes:154]
DIVESTITURES
Discontinued Operations

[0001783180-24-000088:notes:155]
In 2023, the Company announced plans to exit its Fire & Security and Commercial Refrigeration businesses over the course of 2024. The announced plan to exit the Fire & Security segment represents a single disposal plan to separately divest multiple businesses over different reporting periods. Upon the CRF Business qualifying as held for sale during the three months ended September 30, 2024, the components of the Fire & Security segment in aggregate met the criteria to be presented as discontinued operations in the accompanying Unaudited Condensed Consolidated Statement of Operations and Unaudited Condensed Consolidated Statement of Cash Flows. In addition, the assets and liabilities of the CRF Business have been reclassified to held for sale at December 31, 2023. The results of the CCR business did not meet the criteria to be presented in discontinued operations.

[0001783180-24-000088:notes:156]
The components of Discontinued operations, net of tax are as follows:

[0001783180-24-000088:notes:157]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
| (In millions) | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Net sales | $ | 475 |  |  | $ | 796 |  |  | $ | 1,992 |  |  | $ | 2,361 |  |
| Costs of sales | (285) |  |  | (466) |  |  | (1,179) |  |  | (1,457) |  |
| Research and development | (16) |  |  | (31) |  |  | (75) |  |  | (92) |  |
| Selling, general and administrative | (115) |  |  | (167) |  |  | (479) |  |  | (466) |  |
| Other income (expense), net | (593) |  |  | 7 |  |  | (592) |  |  | 19 |  |
| Gain (loss) on divestitures and deconsolidation | 509 |  |  | (4) |  |  | 3,390 |  |  | (297) |  |
| Interest (expense) income, net | (5) |  |  | (12) |  |  | (39) |  |  | (38) |  |
| Earnings before income taxes | (30) |  |  | 123 |  |  | 3,018 |  |  | 30 |  |
| Income tax (expense) benefit | 112 |  |  | (37) |  |  | 154 |  |  | (76) |  |
| Tax on divestitures and deconsolidation | (199) |  |  | 1 |  |  | (1,275) |  |  | 5 |  |
| Discontinued operations, net of tax | $ | (117) |  |  | $ | 87 |  |  | $ | 1,897 |  |  | $ | (41) |  |

[0001783180-24-000088:notes:158]
Portfolio transformation

[0001783180-24-000088:notes:159]
On December 12, 2023, the Company entered into a stock purchase agreement to sell the CCR business to Haier Group Corporation for an enterprise value of approximately $775 million. CCR, historically reported in the Company's Refrigeration segment, is a global supplier of turnkey solutions for commercial refrigeration systems and services, with a primary focus on serving food retail customers, cold storage facilities and warehouses. As a result, the assets and liabilities of CCR are presented as held for sale in the accompanying Unaudited Condensed Consolidated Balance Sheet as of September 30, 2024 and December 31, 2023, and recorded at the lower of their carrying value or fair value less estimated cost to sell. The sale of CCR was completed on October 1, 2024.

[0001783180-24-000088:notes:160]
On August 15, 2024, the Company entered into a stock purchase agreement to sell the CRF Business to an affiliate of Lone Star Funds for an enterprise value of approximately $3.0 billion. The CRF Business, historically reported in the Company's Fire & Security segment, is a leading manufacturer of fire detection and alarm solutions for both commercial and residential applications. As a result, the assets and liabilities of the CRF Business are presented as held for sale in the accompanying Unaudited Condensed Consolidated Balance Sheet as of September 30, 2024 and December 31, 2023, and recorded at the lower of their carrying value or fair value less estimated cost to sell. The transaction is expected to close by the end of 2024 and is subject to regulatory approvals and customary closing conditions.

[0001783180-24-000088:notes:161]
The following tables summarize assets and liabilities classified as held for sale:

[0001783180-24-000088:notes:162]
|  | September 30, 2024 |
| (In millions) | Commercial Refrigeration |  | Commercial & Residential Fire |  | Total |
| Cash and cash equivalents | $ | 141 |  |  | $ | 143 |  |  | $ | 284 |  |
| Accounts receivable, net | 222 |  |  | 414 |  |  | 636 |  |
| Inventories, net | 96 |  |  | 426 |  |  | 522 |  |
| Other current assets | 157 |  |  | 27 |  |  | 184 |  |
| Fixed assets, net | 100 |  |  | 127 |  |  | 227 |  |
| Intangible assets, net | — |  |  | 80 |  |  | 80 |  |
| Goodwill | 72 |  |  | 472 |  |  | 544 |  |
| Operating lease right-of-use assets | 58 |  |  | 76 |  |  | 134 |  |
| Other assets | 46 |  |  | 23 |  |  | 69 |  |
| Total assets held for sale | $ | 892 |  |  | $ | 1,788 |  |  | $ | 2,680 |  |
| Accounts payable | $ | 133 |  |  | $ | 279 |  |  | $ | 412 |  |
| Accrued liabilities | 181 |  |  | 280 |  |  | 461 |  |
| Long-term debt, including current portion | 7 |  |  | — |  |  | 7 |  |
| Future pension and post-retirement obligations | 204 |  |  | 5 |  |  | 209 |  |
| Future income tax obligations | 6 |  |  | 15 |  |  | 21 |  |
| Operating lease liabilities | 40 |  |  | 55 |  |  | 95 |  |
| Other long-term liabilities | 2 |  |  | 14 |  |  | 16 |  |
| Total liabilities held for sale | $ | 573 |  |  | $ | 648 |  |  | $ | 1,221 |  |

[0001783180-24-000088:notes:163]
|  | December 31, 2023 |
| (In millions) | Commercial Refrigeration |  | AccessSolutions |  | IndustrialFire |  | Commercial & Residential Fire |  | Total |
| Cash and cash equivalents | $ | 131 |  |  | $ | 6 |  |  | $ | 20 |  |  | $ | 163 |  |  | $ | 320 |  |
| Accounts receivable, net | 274 |  |  | 104 |  |  | 101 |  |  | 401 |  |  | 880 |  |
| Inventories, net | 84 |  |  | 31 |  |  | 65 |  |  | 394 |  |  | 574 |  |
| Other current assets | 113 |  |  | 5 |  |  | 46 |  |  | 25 |  |  | 189 |  |
| Fixed assets, net | 78 |  |  | 13 |  |  | 22 |  |  | 133 |  |  | 246 |  |
| Intangible assets, net | — |  |  | 53 |  |  | 2 |  |  | 83 |  |  | 138 |  |
| Goodwill | 72 |  |  | 1,498 |  |  | 439 |  |  | 469 |  |  | 2,478 |  |
| Operating lease right-of-use assets | 49 |  |  | 13 |  |  | 28 |  |  | 70 |  |  | 160 |  |
| Other assets | 44 |  |  | 10 |  |  | 13 |  |  | 41 |  |  | 108 |  |
| Total assets held for sale | $ | 845 |  |  | $ | 1,733 |  |  | $ | 736 |  |  | $ | 1,779 |  |  | $ | 5,093 |  |
| Accounts payable | $ | 129 |  |  | $ | 20 |  |  | $ | 39 |  |  | $ | 259 |  |  | $ | 447 |  |
| Accrued liabilities | 204 |  |  | 74 |  |  | 77 |  |  | 239 |  |  | 594 |  |
| Long-term debt, including current portion | 8 |  |  | — |  |  | — |  |  | — |  |  | 8 |  |
| Future pension and post-retirement obligations | 203 |  |  | — |  |  | 1 |  |  | 6 |  |  | 210 |  |
| Future income tax obligations | 4 |  |  | 2 |  |  | 3 |  |  | 12 |  |  | 21 |  |
| Operating lease liabilities | 40 |  |  | 11 |  |  | 23 |  |  | 58 |  |  | 132 |  |
| Other long-term liabilities | 3 |  |  | 12 |  |  | 9 |  |  | 14 |  |  | 38 |  |
| Total liabilities held for sale | $ | 591 |  |  | $ | 119 |  |  | $ | 152 |  |  | $ | 588 |  |  | $ | 1,450 |  |

[0001783180-24-000088:notes:164]
On June 2, 2024, the Company completed the sale of Access Solutions for cash proceeds of $5.0 billion. Access Solutions, historically reported in the Company's Fire & Security segment, is a global supplier of physical security and digital access solutions supporting the hospitality, commercial, education and military markets. The Company recognized a net gain on the sale of $1.8 billion, which is included in Discontinued operations, net of tax on the accompanying Unaudited Condensed Consolidated Statement of Operations. The net proceeds received are subject to working capital and other adjustments provided in the stock purchase agreement governing the sale of Access Solutions.

[0001783180-24-000088:notes:165]
On July 1, 2024, the Company completed the sale of Industrial Fire for cash proceeds of $1.4 billion. Industrial Fire, historically reported in the Company's Fire & Security segment, is a leading manufacturer of a full spectrum of fire detection and suppression solutions and services in critical high-hazard environments, including oil and gas, power generation, marine and offshore facilities, automotive, data centers and aircraft hangars. The Company recognized a net gain on the sale of $310 million, which is included in Discontinued operations, net of tax on the accompanying Unaudited Condensed Consolidated Statement of Operations. The net proceeds received are subject to working capital and other adjustments provided in the stock purchase agreement governing the sale of Industrial Fire.

[0001783180-24-000088:notes:166]
The following table summarizes the assets and liabilities divested as of their respective dates of sale:

[0001783180-24-000088:notes:167]
| (In millions) | AccessSolutions |  | IndustrialFire |  |  |
| Cash and cash equivalents | $ | 82 |  |  | $ | 40 |  |  |  |
| Accounts receivable, net | 90 |  |  | 93 |  |  |  |
| Inventories, net | 43 |  |  | 73 |  |  |  |
| Other current assets | 6 |  |  | 55 |  |  |  |
| Fixed assets, net | 18 |  |  | 24 |  |  |  |
| Intangible assets, net | 53 |  |  | 2 |  |  |  |
| Goodwill | 1,467 |  |  | 452 |  |  |  |
| Operating lease right-of-use assets | 16 |  |  | 24 |  |  |  |
| Other assets | 8 |  |  | 2 |  |  |  |
| Total assets held for sale | $ | 1,783 |  |  | $ | 765 |  |  |  |
| Accounts payable | $ | 54 |  |  | $ | 43 |  |  |  |
| Accrued liabilities | 80 |  |  | 65 |  |  |  |
| Operating lease liabilities | 17 |  |  | 24 |  |  |  |
| Other long-term liabilities | 10 |  |  | 6 |  |  |  |
| Total liabilities held for sale | $ | 161 |  |  | $ | 138 |  |  |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001783180-24-000088:notes:168]
SEGMENT FINANCIAL DATA
The Company conducts its operations through two reportable operating segments: HVAC and Refrigeration. In accordance with ASC 280 - Segment Reporting, the Company's segments maintain separate financial information for which results of operations are evaluated on a regular basis by the Company's Chief Operating Decision Maker in deciding how to allocate resources and in assessing performance.

[0001783180-24-000088:notes:169]
[same as prior period, unchanged from 0001783180-24-000077:notes:155]

[0001783180-24-000088:notes:170]
[same as prior period, unchanged from 0001783180-24-000077:notes:156]

[0001783180-24-000088:notes:171]
[same as prior period, unchanged from 0001783180-24-000077:notes:158]

[0001783180-24-000088:notes:172]
Due to the Company's ongoing portfolio transformation, certain business activities previously reported within the Fire & Security segment no longer meet the criteria of a reportable segment. As a result, these business activities have been included in Eliminations and other in the following tables.

[0001783180-24-000088:notes:173]
[same as prior period, unchanged from 0001783180-24-000077:notes:159]

[0001783180-24-000088:notes:174]
|  |  | Net Sales |  | Operating Profit |
|  |  | Three Months Ended September 30, |  | Three Months Ended September 30, |
| (In millions) |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| HVAC |  | $ | 5,058 |  |  | $ | 4,008 |  |  | $ | 741 |  |  | $ | 763 |  |
| Refrigeration |  | 938 |  |  | 924 |  |  | 109 |  |  | 107 |  |
| Total segment |  | 5,996 |  |  | 4,932 |  |  | 850 |  |  | 870 |  |
| Eliminations and other |  | (12) |  |  | 3 |  |  | (25) |  |  | (252) |  |
| General corporate expenses |  | — |  |  | — |  |  | (62) |  |  | (108) |  |
| Total Consolidated |  | $ | 5,984 |  |  | $ | 4,935 |  |  | $ | 763 |  |  | $ | 510 |  |

[0001783180-24-000088:notes:175]
|  |  | Net Sales |  | Operating Profit |
|  |  | Nine Months Ended September 30, |  | Nine Months Ended September 30, |
| (In millions) |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| HVAC |  | $ | 14,569 |  |  | $ | 11,846 |  |  | $ | 1,857 |  |  | $ | 1,940 |  |
| Refrigeration |  | 2,795 |  |  | 2,794 |  |  | 319 |  |  | 327 |  |
| Total segment |  | 17,364 |  |  | 14,640 |  |  | 2,176 |  |  | 2,267 |  |
| Eliminations and other |  | (26) |  |  | (5) |  |  | (84) |  |  | (399) |  |
| General corporate expenses |  | — |  |  | — |  |  | (220) |  |  | (247) |  |
| Total Consolidated |  | $ | 17,338 |  |  | $ | 14,635 |  |  | $ | 1,872 |  |  | $ | 1,621 |  |

[0001783180-24-000088:notes:176]
Geographic external sales are attributed to the geographic regions based on their location of origin. With the exception of the U.S. presented in the table below, there were no individually significant countries with sales exceeding 10% of total sales during the three and nine months ended September 30, 2024 and 2023.

[0001783180-24-000088:notes:177]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
| (In millions) |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| United States |  | $ | 3,154 |  |  | $ | 2,882 |  |  | $ | 8,778 |  |  | $ | 8,256 |  |
| International: |  |  |  |  |  |  |  |  |
| Europe |  | 1,723 |  |  | 934 |  |  | 5,152 |  |  | 2,923 |  |
| Asia Pacific |  | 923 |  |  | 954 |  |  | 2,886 |  |  | 2,986 |  |
| Other |  | 184 |  |  | 165 |  |  | 522 |  |  | 470 |  |
| Net sales |  | $ | 5,984 |  |  | $ | 4,935 |  |  | $ | 17,338 |  |  | $ | 14,635 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001783180-24-000088:notes:178]
RELATED PARTIES
Equity Method Investments

[0001783180-24-000088:notes:179]
The Company sells products to and purchases products from unconsolidated entities accounted for under the equity method and, therefore, these entities are considered to be related parties. Amounts attributable to equity method investees are as follows:

[0001783180-24-000088:notes:180]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
| (In millions) |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Sales to equity method investees included in Product sales |  | $ | 774 |  |  | $ | 730 |  |  | $ | 2,329 |  |  | $ | 2,371 |  |
| Purchases from equity method investees included in Cost of products sold |  | $ | 64 |  |  | $ | 57 |  |  | $ | 178 |  |  | $ | 159 |  |

[0001783180-24-000088:notes:181]
The Company had receivables from and payables to equity method investees as follows:

[0001783180-24-000088:notes:182]
| (In millions) |  | September 30,2024 |  | December 31,2023 |
| Receivables from equity method investees included in Accounts receivable, net |  | $ | 287 |  |  | $ | 231 |  |
| Payables to equity method investees included in Accounts payable |  | $ | 47 |  |  | $ | 44 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001783180-24-000088:notes:183]
COMMITMENTS AND CONTINGENT LIABILITIES
The Company is involved in various litigation, claims and administrative proceedings, including those related to environmental (including asbestos) and legal matters. In accordance with ASC 450, Contingencies, the Company records accruals for loss contingencies when it is probable that a liability has been incurred and the amount of the loss can be reasonably estimated. These accruals are generally based upon a range of possible outcomes. If no amount within the range is a better estimate than any other, the Company accrues the minimum amount. In addition, these estimates are reviewed periodically and adjusted to reflect additional information when it becomes available. The Company is unable to predict the final outcome of the following matters based on the information currently available, except as otherwise noted. However, the Company does not believe that the resolution of any of these matters will have a material adverse effect upon its results of operations or financial condition.

[0001783180-24-000088:notes:184]
Environmental Matters

[0001783180-24-000088:notes:185]
The Company’s operations are subject to environmental regulation by various authorities. The Company has accrued for the costs of environmental remediation activities, including but not limited to investigatory, remediation, operating and maintenance costs and performance guarantees. The most likely cost to be incurred is accrued based on an evaluation of currently available facts with respect to individual sites, including the technology required to remediate, current laws and regulations and prior remediation experience.

[0001783180-24-000088:notes:186]
The outstanding liabilities for environmental obligations are as follows:

[0001783180-24-000088:notes:187]
| (In millions) |  | September 30,2024 |  | December 31,2023 |
| Environmental reserves included in Accrued liabilities |  | $ | 11 |  |  | $ | 19 |  |
| Environmental reserves included in Other long-term liabilities |  | 202 |  |  | 199 |  |
| Total Environmental reserves |  | $ | 213 |  |  | $ | 218 |  |

[0001783180-24-000088:notes:188]
For sites with multiple responsible parties, the Company considers its likely proportionate share of the anticipated remediation costs and the ability of other parties to fulfill their obligations in establishing a provision for these costs. Accrued environmental liabilities are not reduced by potential insurance reimbursements and are undiscounted.

[0001783180-24-000088:notes:189]
Asbestos Matters

[0001783180-24-000088:notes:190]
The Company has been named as a defendant in lawsuits alleging personal injury as a result of exposure to asbestos allegedly integrated into certain Carrier products or business premises. While the Company has never manufactured asbestos and no longer incorporates it into any currently-manufactured products, certain products that the Company no longer manufactures contained components incorporating asbestos. A substantial majority of these asbestos-related claims have been dismissed without payment or have been covered in full or in part by insurance or other forms of indemnity. Additional cases were litigated and settled without any insurance reimbursement. The amounts involved in asbestos-related claims were not material individually or in the aggregate in any period.

[0001783180-24-000088:notes:191]
The Company's asbestos liabilities and related insurance recoveries are as follows:

[0001783180-24-000088:notes:192]
| (In millions) |  | September 30,2024 |  | December 31,2023 |
| Asbestos liabilities included in Accrued liabilities |  | $ | 17 |  |  | $ | 15 |  |
| Asbestos liabilities included in Other long-term liabilities |  | 208 |  |  | 206 |  |
| Total Asbestos liabilities |  | $ | 225 |  |  | $ | 221 |  |
| Asbestos-related recoveries included in Other current assets |  | $ | 7 |  |  | $ | 5 |  |
| Asbestos-related recoveries included in Other assets |  | 88 |  |  | 88 |  |
| Total Asbestos-related recoveries |  | $ | 95 |  |  | $ | 93 |  |

[0001783180-24-000088:notes:193]
The amounts recorded for asbestos-related liabilities are based on currently available information and assumptions that the Company believes are reasonable and are made with input from outside actuarial experts. These amounts are undiscounted and exclude the Company’s legal fees to defend the asbestos claims, which are expensed as incurred. In addition, the Company has recorded insurance recovery receivables for probable asbestos-related recoveries.

[0001783180-24-000088:notes:194]
Aqueous Film Forming Foam Litigation

[0001783180-24-000088:notes:195]
As of September 30, 2024, the Company, Kidde-Fenwal, Inc. ("KFI") and others have been named as defendants in more than 8,000 lawsuits filed in United States state or federal courts and a single case in Canada alleging that the historic use of Aqueous Film Forming Foam ("AFFF") caused personal injuries and damage to property and water supplies. In December 2018, the U.S. Judicial Panel on Multidistrict Litigation transferred and consolidated all AFFF cases pending in the U.S. federal courts against the Company, KFI and others to the U.S. District Court for the District of South Carolina (the "MDL Proceedings"). Individual plaintiffs in the MDL Proceedings generally seek damages for alleged personal injuries, medical monitoring, diminution in property value and injunctive relief to remediate alleged contamination of water supplies. U.S. state, municipal and water utility plaintiffs in the MDL Proceedings generally seek damages and costs related to the remediation of public property and water supplies.

[0001783180-24-000088:notes:196]
AFFF is a firefighting foam, developed beginning in the late 1960s pursuant to U.S. military specification, used to extinguish certain types of hydrocarbon-fueled fires. The lawsuits identified above relate to Kidde Fire Fighting, Inc., which owned the “National Foam” business that manufactured AFFF for sale to government (including the U.S. federal government) and non-government customers in the U.S. at a single facility located in West Chester, Pennsylvania (the "Pennsylvania Site"). Kidde Fire Fighting, Inc. was acquired by a UTC subsidiary in 2005 and merged into KFI in 2007. In 2013, KFI divested the AFFF businesses to an unrelated third party. The Company acquired KFI as part of the Separation in April 2020.

[0001783180-24-000088:notes:197]
The key components that contribute to AFFF's fire-extinguishing capabilities are known as fluorosurfactants. Neither the Company, nor KFI, nor any of the Company's subsidiaries involved in the AFFF litigation manufactured fluorosurfactants. Instead, the National Foam business purchased these substances from unrelated third parties for use in manufacturing AFFF. Plaintiffs in the MDL Proceedings allege that the fluorosurfactants used by various manufacturers in producing AFFF contained, or over time degraded into, compounds known as per- and polyfluoroalkyl substances (referred to collectively as "PFAS"), including perflourooctanesulfonic acid ("PFOS") and perflourooctanoic acid ("PFOA"). Plaintiffs further allege that, as a result of the use of AFFF, PFOS and PFOA were released into the environment and, in some instances, ultimately reached drinking water supplies.

[0001783180-24-000088:notes:198]
Plaintiffs in the MDL Proceedings have named multiple defendants, including suppliers of chemicals and raw materials used to manufacture fluorosurfactants, fluorosurfactant manufacturers and AFFF manufacturers. The defendants in the MDL Proceedings moved for summary judgment on the government contractor defense, which potentially applies to AFFF sold to or used by the U.S. government. After full briefing and oral argument, on September 16, 2022, the MDL court declined to enter summary judgment for the defendants. The defense, however, remains available at any trial in which it would apply.

[0001783180-24-000088:notes:199]
On May 14, 2023, KFI filed a voluntary petition with the United States Bankruptcy Court for the District of Delaware (the “Bankruptcy Court”) seeking relief under chapter 11 of the Bankruptcy Code, after the Company determined that it would not provide financial support to KFI going forward other than ensuring KFI has access to services necessary for the effective operation of its business. As a result, all litigation against KFI was automatically stayed. By agreement, all AFFF-related litigation against the Company, its other subsidiaries and RTX also was stayed. On November 21, 2023, the Bankruptcy Court ordered certain parties, including the Company, to participate in mediation sessions with respect to claims that might be asserted by and against it in the bankruptcy proceedings.

[0001783180-24-000088:notes:200]
Following the conclusion of these mediation sessions in October 2024, the Company entered into a Settlement and Plan Support Agreement which contemplates that the Company will subsequently enter into three distinct settlement agreements (collectively, the “Proposed Settlement Agreements”) with KFI, the Official Committee of Unsecured Creditors appointed in KFI’s bankruptcy case (the “Committee”) and the Plaintiffs’ Executive Committee (the “MDL PEC”) appointed in the MDL Proceedings.

[0001783180-24-000088:notes:201]
The first of the Proposed Settlement Agreements relates to claims that the Company is responsible for liabilities arising from KFI’s manufacture or sale of AFFF (“Estate Claims Settlement”). Upon Bankruptcy Court approval, the Estate Claims Settlement will permanently resolve all present and future claims that the Company is responsible for any liabilities of KFI, including all liabilities arising from KFI’s manufacture and sale of AFFF. The second and third of the Proposed Settlement Agreements release a very substantial amount of current and future direct claims against the Company (the “Direct Claims Settlements”). Direct claims allege that UTC, which indirectly owned KFI’s AFFF business for eight years, engaged in conduct independent of KFI that caused harm to AFFF claimants. The Company agreed to indemnify UTC for these direct claims when it was spun-off from UTC. Upon approval by the MDL Court, the Direct Claims Settlements resolve and enjoin all current and future AFFF-related direct claims against the Company by participating public water providers and airports. Non-settling parties may still assert direct AFFF-related claims, although we expect a vast majority of public water providers and airports will participate in the Direct Claims Settlements.

[0001783180-24-000088:notes:202]
As part of the Proposed Settlement Agreements, the Company will pay $615 million in cash over five years, 100% of the net sale proceeds from the sale of KFI’s assets from its sale to Pacific Avenue Capital Partners, which are estimated to be $115 million, and contribute the right to recover proceeds under certain of its insurance policies. The Company will be entitled to receive up to $2.4 billion of proceeds from those insurance policies and will contribute the first $125 million of such proceeds as additional consideration in the Direct Claims Settlements. The Company also will be entitled to any earnouts payable to KFI under the KFI sale agreement. The Company expects insurance payments it receives in the future, in the aggregate, to cover the amount paid under the Proposed Settlement Agreements. As a result of the Proposed Settlement Agreements, the Company recorded a liability in the amount of $565 million during the three months ended September 30, 2024. The amount recognized is in addition to liabilities of $50 million that the Company recorded upon the deconsolidation of KFI on May 14, 2023, as further discussed below. As of September 30, 2024, the Company has not recorded any amounts associated with expected insurance proceeds.

[0001783180-24-000088:notes:203]
The Company and KFI believe that they have meritorious defenses to the remaining AFFF claims. Given the numerous factual, scientific and legal issues to be resolved relating to these claims, the Company is unable to assess the probability of liability or to reasonably estimate a range of possible loss at this time. There can be no assurance that any such future exposure will not be material in any period.

[0001783180-24-000088:notes:204]
Deconsolidation Due to Bankruptcy

[0001783180-24-000088:notes:205]
As of May 14, 2023, the Company no longer controlled KFI as its activities are subject to review and oversight by the Bankruptcy Court. Therefore, KFI was deconsolidated and its respective assets and liabilities were derecognized from the Company’s Unaudited Condensed Consolidated Financial Statements. Upon deconsolidation, the Company determined the fair value of its retained interest in KFI to be zero and we accounted for it prospectively using the cost method. As a result of these actions, the Company recognized a loss of $297 million in its Unaudited Condensed Consolidated Statement of Operations

[0001783180-24-000088:notes:206]
within within Other income/(expense), net. In addition, the deconsolidation resulted in an investing cash outflow of $134 million in the Company's Unaudited Condensed Consolidated Statement of Cash Flows.

[0001783180-24-000088:notes:207]
In connection with the bankruptcy filing, KFI entered into several agreements with subsidiaries of the Company to ensure they have access to services necessary for the effective operation of their business. All post-deconsolidation activity between the Company and KFI are reported as third-party transactions recorded within the Company's Unaudited Condensed Consolidated Statement of Operations. Since the petition date, there were no material transactions between the Company and KFI other than a $15 million payment by the Company to KFI under the terms of a tax sharing arrangement.

[0001783180-24-000088:notes:208]
Income Taxes

[0001783180-24-000088:notes:209]
Under the TMA relating to the Separation, the Company is responsible to UTC for its share of the Tax Cuts and Jobs Act transition tax associated with foreign undistributed earnings as of December 31, 2017. During the nine months ended September 30, 2024, the Company recognized a $46 million gain associated with the TMA and UTC's conclusion of certain income tax matters from their 2017 and 2018 tax audit with the IRS. Liabilities under the TMA of $118 million and $108 million are included within the accompanying Unaudited Condensed Consolidated Balance Sheet within Accrued Liabilities and Other Long-Term Liabilities as of September 30, 2024, respectively. This obligation is expected to be settled in annual installments with the next installment of $118 million due in April 2025 and the final installment of $108 million due in April 2026. The Company believes that the likelihood of incurring losses materially in excess of this amount is remote.

[0001783180-24-000088:notes:210]
Other

[0001783180-24-000088:notes:211]
The Company has other commitments and contingent liabilities related to legal proceedings, self-insurance programs and matters arising in the ordinary course of business. The Company accrues for contingencies generally based upon a range of possible outcomes. If no amount within the range is a better estimate than any other, the Company accrues the minimum amount.

[0001783180-24-000088:notes:212]
In the ordinary course of business, the Company is also routinely a defendant in, party to or otherwise subject to many pending and threatened legal actions, claims, disputes and proceedings. These matters are often based on alleged violations of contract, product liability, warranty, regulatory, environmental, health and safety, employment, intellectual property, tax and other laws. In some of these proceedings, claims for substantial monetary damages are asserted against the Company and could result in fines, penalties, compensatory or treble damages or non-monetary relief. The Company does not believe that these matters will have a material adverse effect upon its results of operations, cash flows or financial condition.
