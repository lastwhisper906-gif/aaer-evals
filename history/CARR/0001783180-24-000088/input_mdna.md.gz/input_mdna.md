# CARR MD&A — 0001783180-24-000088


## mdna

[0001783180-24-000088:mdna:1]
[same as prior period, unchanged from 0001783180-24-000077:mdna:1]

[0001783180-24-000088:mdna:2]
[same as prior period, unchanged from 0001783180-24-000077:mdna:2]

[0001783180-24-000088:mdna:3]
[same as prior period, unchanged from 0001783180-24-000077:mdna:3]

[0001783180-24-000088:mdna:4]
Carrier Global Corporation ("we" or "our") is a global leader in intelligent climate and energy solutions with a focus on providing differentiated, digitally-enabled lifecycle solutions to our customers. Our portfolio includes industry-leading brands such as Carrier, Viessmann, Toshiba, Automated Logic and Carrier Transicold that offer innovative heating, ventilating and air conditioning ("HVAC"), refrigeration, and cold chain transportation solutions to help make the world safer and more comfortable. We also provide a broad array of related building services, including audit, design, installation, system integration, repair, maintenance and monitoring. Our operations are classified into two segments: HVAC and Refrigeration.

[0001783180-24-000088:mdna:5]
[same as prior period, unchanged from 0001783180-24-000077:mdna:5]

[0001783180-24-000088:mdna:6]
[same as prior period, unchanged from 0001783180-24-000077:mdna:6]

[0001783180-24-000088:mdna:7]
[same as prior period, unchanged from 0001783180-24-000077:mdna:7]

[0001783180-24-000088:mdna:8]
[same as prior period, unchanged from 0001783180-24-000077:mdna:8]

[0001783180-24-000088:mdna:9]
[same as prior period, unchanged from 0001783180-24-000077:mdna:9]

[0001783180-24-000088:mdna:10]
[same as prior period, unchanged from 0001783180-24-000077:mdna:10]

[0001783180-24-000088:mdna:11]
On June 2, 2024, we completed the sale of our Access Solutions business ("Access Solutions") to Honeywell International Inc. ("Honeywell") for cash proceeds of $5.0 billion. Access Solutions, historically reported in our Fire & Security segment, is a global supplier of physical security and digital access solutions supporting the hospitality, commercial, education and military markets. We recognized a net gain on the sale of $1.8 billion, which is included in Discontinued operations, net of tax on the accompanying Unaudited Condensed Consolidated Statement of Operations. The net proceeds received are subject to working capital and other adjustments provided in the stock purchase agreement.

[0001783180-24-000088:mdna:12]
On July 1, 2024, we completed the sale of our Industrial Fire business ("Industrial Fire") for cash proceeds of $1.4 billion. Industrial Fire, historically reported in our Fire & Security segment, is a leading manufacturer of a full spectrum of fire detection and suppression solutions and services in critical high-hazard environments, including oil and gas, power generation, marine and offshore facilities, automotive, data centers and aircraft hangars. We recognized a net gain on the sale of $310 million, which is included in Discontinued operations, net of tax on the accompanying Unaudited Condensed Consolidated

[0001783180-24-000088:mdna:13]
Statement of Operations. The net proceeds received are subject to working capital and other adjustments provided in the stock purchase agreement governing the sale of Industrial Fire.

[0001783180-24-000088:mdna:14]
On December 12, 2023, we entered into a stock purchase agreement to sell our Commercial Refrigeration business ("CCR") to Haier Group Corporation for an enterprise value of approximately $775 million. CCR, historically reported in our Refrigeration segment, is a global supplier of turnkey solutions for commercial refrigeration systems and services, with a primary focus on serving food retail customers, cold storage facilities and warehouses. The sale of CCR was completed on October 1, 2024.

[0001783180-24-000088:mdna:15]
On August 15, 2024, we entered into a stock purchase agreement to sell our Commercial and Residential Fire business (“CRF Business") to an affiliate of Lone Star Funds for an enterprise value of approximately $3.0 billion. The CRF Business, historically reported in our Fire & Security segment, is a leading manufacturer of fire detection and alarm solutions for both commercial and residential applications. The transaction is expected to close in 2024, subject to regulatory approvals and customary closing conditions.

[0001783180-24-000088:mdna:16]
Discontinued Operations

[0001783180-24-000088:mdna:17]
In 2023, we announced plans to exit our Fire & Security and Commercial Refrigeration businesses over the course of 2024. The announced plan to exit the Fire & Security segment represents a single disposal plan to separately divest multiple businesses over different reporting periods. Upon the CRF Business qualifying as held for sale during the three months ended September 30, 2024, the components of the Fire & Security segment in aggregate met the criteria to be presented as discontinued operations. In addition, the assets and liabilities of the CRF Business have been reclassified to held for sale at December 31, 2023. The results of CCR did not meet the criteria to be presented in discontinued operations.

[0001783180-24-000088:mdna:18]
[same as prior period, unchanged from 0001783180-24-000077:mdna:17]

[0001783180-24-000088:mdna:19]
[same as prior period, unchanged from 0001783180-24-000077:mdna:18]

[0001783180-24-000088:mdna:20]
[same as prior period, unchanged from 0001783180-24-000077:mdna:19]

[0001783180-24-000088:mdna:21]
[same as prior period, unchanged from 0001783180-24-000077:mdna:20]

[0001783180-24-000088:mdna:22]
[same as prior period, unchanged from 0001783180-24-000077:mdna:21]

[0001783180-24-000088:mdna:23]
[same as prior period, unchanged from 0001783180-24-000077:mdna:22]

[0001783180-24-000088:mdna:24]
[same as prior period, unchanged from 0001783180-24-000077:mdna:23]

[0001783180-24-000088:mdna:25]
Three Months Ended September 30, 2024 Compared with the Three Months Ended September 30, 2023

[0001783180-24-000088:mdna:26]
[same as prior period, unchanged from 0001783180-24-000077:mdna:28]

[0001783180-24-000088:mdna:27]
|  |  | Three Months Ended September 30, |
| (In millions) |  | 2024 |  | 2023 |  | Period Change |  | % Change |
| Net sales |  | $ | 5,984 |  |  | $ | 4,935 |  |  | $ | 1,049 |  |  | 21 | % |
| Cost of products and services sold |  | (4,307) |  |  | (3,449) |  |  | (858) |  |  | 25 | % |
| Gross margin |  | 1,677 |  |  | 1,486 |  |  | 191 |  |  | 13 | % |
| Operating expenses |  | (914) |  |  | (976) |  |  | 62 |  |  | (6) | % |
| Operating profit |  | 763 |  |  | 510 |  |  | 253 |  |  | 50 | % |
| Non-operating income (expense), net |  | 7 |  |  | (39) |  |  | 46 |  |  | (118) | % |
| Earnings (loss) before income taxes |  | 770 |  |  | 471 |  |  | 299 |  |  | 63 | % |
| Income tax expense |  | (172) |  |  | (177) |  |  | 5 |  |  | (3) | % |
| Earnings (loss) from continuing operations |  | 598 |  |  | 294 |  |  | 304 |  |  | 103 | % |
| Discontinued operations, net of income taxes |  | (117) |  |  | 87 |  |  | (204) |  |  | (234) | % |
| Net earnings (loss) |  | 481 |  |  | 381 |  |  | 100 |  |  | 26 | % |
| Less: Non-controlling interest in subsidiaries' earnings from operations |  | 34 |  |  | 24 |  |  | 10 |  |  | 42 | % |
| Net earnings (loss) attributable to common shareowners |  | $ | 447 |  |  | $ | 357 |  |  | $ | 90 |  |  | 25 | % |

[0001783180-24-000088:mdna:28]
[same as prior period, unchanged from 0001783180-24-000077:mdna:30]

[0001783180-24-000088:mdna:29]
For the three months ended September 30, 2024, Net sales were $6.0 billion, a 21% increase compared with the same period of 2023. The components of the year-over-year change were as follows:

[0001783180-24-000088:mdna:30]
|  |  | Three Months Ended September 30, 2024 |
| Organic |  | 4 | % |
| Acquisitions and divestitures, net |  | 17 | % |
| Total % change |  | 21 | % |

[0001783180-24-000088:mdna:31]
Organic sales for the three months ended September 30, 2024, increased by 4% compared with the same period of 2023. The organic increase was primarily driven by our HVAC segment due to improved end-markets in the Americas and EMEA, which more than offset reduced end-market demand in Asia. Results in our Refrigeration segment were mixed as growth in Transport refrigeration was partially offset by challenges in Commercial refrigeration end-markets. Refer to "Segment Review" below for a discussion of Net sales by segment.

[0001783180-24-000088:mdna:32]
[same as prior period, unchanged from 0001783180-24-000077:mdna:54]

[0001783180-24-000088:mdna:33]
[same as prior period, unchanged from 0001783180-24-000077:mdna:35]

[0001783180-24-000088:mdna:34]
For the three months ended September 30, 2024, gross margin was $1.7 billion, a 13% increase compared with the same period of 2023. The components were as follows:

[0001783180-24-000088:mdna:35]
|  |  | Three Months Ended September 30, |
| (In millions) |  | 2024 |  | 2023 |
| Net sales |  | $ | 5,984 |  |  | $ | 4,935 |  |
| Cost of products and services sold |  | (4,307) |  |  | (3,449) |  |
| Gross margin |  | $ | 1,677 |  |  | $ | 1,486 |  |
| Percentage of net sales |  | 28.0 | % |  | 30.1 | % |

[0001783180-24-000088:mdna:36]
Gross margin increased by $191 million compared with the three months ended September 30, 2023. The main driver of the increase related to ongoing customer demand, pricing improvements and our continued focus on productivity initiatives. Operating results associated with the VCS Business since the date of acquisition further benefited gross margin during the period. However, the results of the VCS Business included inventory step-up, backlog amortization and intangible asset amortization resulting from the recognition of acquired assets at fair value. These costs had a 220 basis point unfavorable impact on gross margin as a percentage of Net sales. As a result, gross margin as a percentage of Net sales decreased by 210 basis points compared with the same period of 2023.

[0001783180-24-000088:mdna:37]
[same as prior period, unchanged from 0001783180-24-000077:mdna:39]

[0001783180-24-000088:mdna:38]
For the three months ended September 30, 2024, operating expenses, including Equity method investment net earnings, were a benefit of $0.9 billion, a 6% decrease compared with the same period of 2023. The components were as follows:

[0001783180-24-000088:mdna:39]
|  |  | Three Months Ended September 30, |
| (In millions) |  | 2024 |  | 2023 |
| Selling, general and administrative |  | $ | (799) |  |  | $ | (664) |  |
| Research and development |  | (172) |  |  | (126) |  |
| Equity method investment net earnings |  | 66 |  |  | 75 |  |
| Other income (expense), net |  | (9) |  |  | (261) |  |
| Total operating expenses |  | $ | (914) |  |  | $ | (976) |  |
| Percentage of net sales |  | 15.3 | % |  | 19.8 | % |

[0001783180-24-000088:mdna:40]
For the three months ended September 30, 2024, Selling, general and administrative expenses were $799 million, a 20% increase compared with the same period of 2023. The increase is primarily due to incremental expenses associated with the VCS Business since the date of acquisition. In addition, the current period also included $15 million of acquisition and divestiture-related costs compared with $35 million during the three months ended September 30, 2023.

[0001783180-24-000088:mdna:41]
[same as prior period, unchanged from 0001783180-24-000077:mdna:43]

[0001783180-24-000088:mdna:42]
Investments over which we do not exercise control, but have significant influence, are accounted for using the equity method of accounting. For the three months ended September 30, 2024, Equity method investment net earnings were $66 million, a 12% decrease compared with the same period of 2023. The decrease was primarily driven by the absence of a $16 million benefit recognized in connection with a favorable tax ruling at a minority owned joint venture in the prior year. As a result, we reported higher earnings in HVAC joint ventures across all regions.

[0001783180-24-000088:mdna:43]
Other income (expense), net primarily includes the impact of gains and losses related to the sale of businesses or interests in our equity method investments, foreign currency gains and losses on transactions that are denominated in a currency other than an entity's functional currency and hedging-related activities. During the three months ended September 30, 2023, we recognized a $257 million loss on the mark-to-market valuation of our window forward contracts associated with the expected cash outflows of the Euro-denominated purchase price of the VCS Business.

[0001783180-24-000088:mdna:44]
[same as prior period, unchanged from 0001783180-24-000077:mdna:47]

[0001783180-24-000088:mdna:45]
For the three months ended September 30, 2024, Non-operating income (expense), net was $7 million, a 118% decrease compared with the same period of 2023. The components were as follows:

[0001783180-24-000088:mdna:46]
|  |  | Three Months Ended September 30, |
| (In millions) |  | 2024 |  | 2023 |
| Non-service pension (expense) benefit |  | $ | (1) |  |  | $ | — |  |
| Interest expense |  | $ | (131) |  |  | $ | (73) |  |
| Interest income |  | 139 |  |  | 34 |  |
| Interest (expense) income, net |  | $ | 8 |  |  | $ | (39) |  |
| Non-operating income (expense), net |  | $ | 7 |  |  | $ | (39) |  |

[0001783180-24-000088:mdna:47]
Non-operating income (expense), net includes the results from activities other than normal business operations such as interest expense, interest income and the non-service components of pension and post-retirement obligations. Interest expense is affected by the amount of debt outstanding and the interest rates on that debt. For the three months ended September 30, 2024, Interest expense was $131 million, a 79% increase compared with the same period of 2023. In connection with the acquisition of the VCS Business, we entered into several financing arrangements to fund the cash portion of the Euro-denominated purchase price. In July 2024, we completed tender offers to repurchase approximately $1.0 billion aggregate principal which included $125 million of notes due 2034, $350 million of notes due 2054 and approximately $600 million of notes due 2050. Upon settlement, we wrote off $11 million of unamortized deferred financing costs in Interest expense and recognized a net gain of $97 million in Interest income. During the three months ended September 30, 2023, we amortized $12 million of deferred financing cost in Interest expense, of which $11 million related to our senior unsecured bridge term loan facility (the "Bridge Loan").

[0001783180-24-000088:mdna:48]
[same as prior period, unchanged from 0001783180-24-000077:mdna:51]

[0001783180-24-000088:mdna:49]
|  |  | Three Months Ended September 30, |
|  |  | 2024 |  | 2023 |
| Effective tax rate |  | 22.3 | % |  | 37.6 | % |

[0001783180-24-000088:mdna:50]
We account for income tax expense in accordance with ASC 740, which requires an estimate of the annual effective income tax rate for the full year to be applied to the respective interim period, taking into account year-to-date amounts and projected results for the full year. The effective tax rate was 22.3% for the three months ended September 30, 2024 compared with 37.6% for the three months ended September 30, 2023. The year-over-year decrease was primarily driven by the absence of the non-deductible loss of $257 million on the mark-to-market valuation of the Company's window forward contracts associated with the expected cash outflows of the Euro-denominated purchase price of the VCS Business and a tax charge of $19 million related to the Company's intention to no longer permanently reinvest historical earnings from certain jurisdictions.

[0001783180-24-000088:mdna:51]
39

[0001783180-24-000088:mdna:52]
Nine Months Ended September 30, 2024 Compared with the Nine Months Ended September 30, 2023

[0001783180-24-000088:mdna:53]
[same as prior period, unchanged from 0001783180-24-000077:mdna:56]

[0001783180-24-000088:mdna:54]
|  |  | Nine Months Ended September 30, |
| (In millions) |  | 2024 |  | 2023 |  | Period Change |  | % Change |
| Net sales |  | $ | 17,338 |  |  | $ | 14,635 |  |  | $ | 2,703 |  |  | 18 | % |
| Cost of products and services sold |  | (12,701) |  |  | (10,590) |  |  | (2,111) |  |  | 20 | % |
| Gross margin |  | 4,637 |  |  | 4,045 |  |  | 592 |  |  | 15 | % |
| Operating expenses |  | (2,765) |  |  | (2,424) |  |  | (341) |  |  | 14 | % |
| Operating profit |  | 1,872 |  |  | 1,621 |  |  | 251 |  |  | 15 | % |
| Non-operating income (expense), net |  | (291) |  |  | (126) |  |  | (165) |  |  | 131 | % |
| Income from operations before income taxes |  | 1,581 |  |  | 1,495 |  |  | 86 |  |  | 6 | % |
| Income tax expense |  | (339) |  |  | (453) |  |  | 114 |  |  | (25) | % |
| Earnings (loss) from continuing operations |  | 1,242 |  |  | 1,042 |  |  | 200 |  |  | 19 | % |
| Discontinued operations, net of tax |  | 1,897 |  |  | (41) |  |  | 1,938 |  |  | (4727) | % |
| Net earnings (loss) |  | 3,139 |  |  | 1,001 |  |  | 2,138 |  |  | 214 | % |
| Less: Non-controlling interest in subsidiaries' earnings from operations |  | 86 |  |  | 72 |  |  | 14 |  |  | 19 | % |
| Net earnings (loss) attributable to common shareowners |  | $ | 3,053 |  |  | $ | 929 |  |  | $ | 2,124 |  |  | 229 | % |

[0001783180-24-000088:mdna:55]
[same as prior period, unchanged from 0001783180-24-000077:mdna:58]

[0001783180-24-000088:mdna:56]
For the nine months ended September 30, 2024, Net sales were $17.3 billion, a 18% increase compared with the same period of 2023. The components of the year-over-year change were as follows:

[0001783180-24-000088:mdna:57]
|  |  | Nine Months Ended September 30, 2024 |
| Organic |  | 2 | % |
| Foreign currency translation |  | (1) | % |
| Acquisitions and divestitures, net |  | 17 | % |
| Total % change |  | 18 | % |

[0001783180-24-000088:mdna:58]
Organic sales for the nine months ended September 30, 2024 increased by 2% compared with the same period of 2023. The organic increase was primarily driven by our HVAC segment due to improved end-markets in the Americas, which more than offset reduced end-markets in EMEA and Asia. Results in Refrigeration were flat compared to the prior year as each of the segment's businesses experienced challenges in certain end-markets. Refer to "Segment Review" below for a discussion of Net sales by segment.

[0001783180-24-000088:mdna:59]
[same as prior period, unchanged from 0001783180-24-000077:mdna:78]

[0001783180-24-000088:mdna:60]
[same as prior period, unchanged from 0001783180-24-000077:mdna:62]

[0001783180-24-000088:mdna:61]
For the nine months ended September 30, 2024, gross margin was $4.6 billion, a 15% increase compared with the same period of 2023. The components were as follows:

[0001783180-24-000088:mdna:62]
|  |  | Nine Months Ended September 30, |  |  |  |  |
| (In millions) |  | 2024 |  | 2023 |  |  |  |  |
| Net sales |  | $ | 17,338 |  |  | $ | 14,635 |  |  |  |  |  |
| Cost of products and services sold |  | (12,701) |  |  | (10,590) |  |  |  |  |  |
| Gross margin |  | $ | 4,637 |  |  | $ | 4,045 |  |  |  |  |  |
| Percentage of net sales |  | 26.7 | % |  | 27.6 | % |  |  |  |  |

[0001783180-24-000088:mdna:63]
Gross margin increased by $592 million compared with the nine months ended September 30, 2023. The main driver of the increase related to ongoing customer demand, pricing improvements and our continued focus on productivity initiatives. Operating results associated with the VCS Business since the date of acquisition further benefited gross margin during the period. However, the results of the VCS Business included inventory step-up, backlog amortization and intangible asset amortization resulting from the recognition of acquired assets at fair value. These costs had a 270 basis point unfavorable impact on gross margin as a percentage of Net sales. As a result, gross margin as a percentage of Net sales decreased by 90 basis points compared with the same period of 2023.

[0001783180-24-000088:mdna:64]
[same as prior period, unchanged from 0001783180-24-000077:mdna:66]

[0001783180-24-000088:mdna:65]
For the nine months ended September 30, 2024, operating expenses, including Equity method investment net earnings, were a benefit of $2.8 billion, a 14% increase compared with the same period of 2023. The components were as follows:

[0001783180-24-000088:mdna:66]
|  |  | Nine Months Ended September 30, |
| (In millions) |  | 2024 |  | 2023 |
| Selling, general and administrative |  | $ | (2,394) |  |  | $ | (1,870) |  |
| Research and development |  | (524) |  |  | (355) |  |
| Equity method investment net earnings |  | 187 |  |  | 171 |  |
| Other income (expense), net |  | (34) |  |  | (370) |  |
| Total operating expenses |  | $ | (2,765) |  |  | $ | (2,424) |  |
| Percentage of net sales |  | 15.9 | % |  | 16.6 | % |

[0001783180-24-000088:mdna:67]
For the nine months ended September 30, 2024, Selling, general and administrative expenses were $2.4 billion, a 28% increase compared with the same period of 2023. The increase is primarily due to incremental expenses associated with the VCS Business since the date of acquisition. In addition, higher compensation and other employee-related costs further contributed to the increase. The current period also included $87 million of acquisition and divestiture-related costs compared with $58 million during the nine months ended September 30, 2023.

[0001783180-24-000088:mdna:68]
[same as prior period, unchanged from 0001783180-24-000077:mdna:70]

[0001783180-24-000088:mdna:69]
Investments over which we do not exercise control, but have significant influence, are accounted for using the equity method of accounting. For the nine months ended September 30, 2024, Equity method investment net earnings were $187 million, a 9% increase compared with the same period of 2023. The increase was primarily driven by higher earnings in HVAC joint ventures across all regions. The increase was partially offset by a $23 million charge associated with the devaluation of U.S. Dollar denominated balances at an HVAC equity investment in Egypt. In addition, prior year results include a $16 million benefit recognized in connection with a favorable tax ruling at a minority owned joint venture.

[0001783180-24-000088:mdna:70]
Other income (expense), net primarily includes the impact of gains and losses related to the sale of businesses or interests in our equity method investments, foreign currency gains and losses on transactions that are denominated in a currency other than an entity's functional currency and hedging-related activities. During the nine months ended September 30, 2024, we recognized a $46 million gain associated with our share of United Technologies Corporation's conclusion of certain income tax matters from their 2017 and 2018 tax audit with the Internal Revenue Service ("IRS"). In connection with the acquisition of the VCS Business, we recognized an $86 million loss on the mark-to-market valuation of our window forward contracts associated with the cash outflows of the Euro-denominated purchase price. During the nine months ended September 30, 2023, we recognized a $368 million loss on the mark-to-market valuation of our window forward contracts associated with the expected cash outflows of the Euro-denominated purchase price of the VCS Business.

[0001783180-24-000088:mdna:71]
[same as prior period, unchanged from 0001783180-24-000077:mdna:74]

[0001783180-24-000088:mdna:72]
For the nine months ended September 30, 2024, Non-operating income (expense), net was $291 million, a 131% increase compared with the same period of 2023. The components were as follows:

[0001783180-24-000088:mdna:73]
|  |  | Nine Months Ended September 30, |
| (In millions) |  | 2024 |  | 2023 |
| Non-service pension (expense) benefit |  | $ | (1) |  |  | $ | — |  |
| Interest expense |  | $ | (462) |  |  | $ | (209) |  |
| Interest income |  | 172 |  |  | 83 |  |
| Interest (expense) income, net |  | $ | (290) |  |  | $ | (126) |  |
| Non-operating income (expense), net |  | $ | (291) |  |  | $ | (126) |  |

[0001783180-24-000088:mdna:74]
Non-operating income (expense), net includes the results from activities other than normal business operations such as interest expense, interest income and the non-service components of pension and post-retirement obligations. Interest expense is affected by the amount of debt outstanding and the interest rates on that debt. For the nine months ended September 30, 2024, Interest expense was $462 million, a 121% increase compared with the same period of 2023. In connection with the acquisition of the VCS Business, we entered into several financing arrangements to fund the Euro-denominated purchase price. We also redeemed $1.0 billion aggregate principal amount of 5.80% notes due in 2025 and completed tender offers to repurchase approximately $1.0 billion aggregate principal which included $125 million of notes due 2034, $350 million of notes due 2054 and approximately $600 million of notes due 2050. Upon settlement, we incurred a make-whole premium of $8 million in Interest expense, wrote off $11 million of unamortized deferred financing costs in Interest expense and recognized a net gain of $97 million in Interest income. During the nine months ended September 30, 2023, we amortized $34 million of deferred financing cost in Interest expense, of which $30 million related to our Bridge Loan.

[0001783180-24-000088:mdna:75]
[same as prior period, unchanged from 0001783180-24-000077:mdna:102]

[0001783180-24-000088:mdna:76]
[same as prior period, unchanged from 0001783180-24-000077:mdna:79]

[0001783180-24-000088:mdna:77]
|  |  | Nine Months Ended September 30, |  |  |
|  |  | 2024 |  | 2023 |  |  |  |  |
| Effective tax rate |  | 21.4 | % |  | 30.3 | % |  |  |  |  |

[0001783180-24-000088:mdna:78]
We account for income tax expense in accordance with ASC 740, which requires an estimate of the annual effective income tax rate for the full year to be applied to the respective interim period, taking into account year-to-date amounts and projected results for the full year. The effective tax rate was 21.4% for the nine months ended September 30, 2024, compared with 30.3% for the nine months ended September 30, 2023. The year-over-year decrease was primarily driven by the $368 million loss on the mark-to-market valuation of the Company's window forward contracts associated with the expected cash outflows of the Euro-denominated purchase price of the VCS Business during the nine months ended September 30, 2023. In addition, the Company recognized a tax benefit of $21 million associated with the TMA and UTC's conclusion of certain income tax matters from their 2017 and 2018 tax audit with the U.S. Internal Revenue Service ("IRS") during the nine months ended September 30, 2024.

[0001783180-24-000088:mdna:79]
[same as prior period, unchanged from 0001783180-24-000077:mdna:82]

[0001783180-24-000088:mdna:80]
We have two operating segments:

[0001783180-24-000088:mdna:81]
[same as prior period, unchanged from 0001783180-24-000077:mdna:84]

[0001783180-24-000088:mdna:82]
[same as prior period, unchanged from 0001783180-24-000077:mdna:85]

[0001783180-24-000088:mdna:83]
[same as prior period, unchanged from 0001783180-24-000077:mdna:87]

[0001783180-24-000088:mdna:84]
Three Months Ended September 30, 2024 Compared with Three Months Ended September 30, 2023

[0001783180-24-000088:mdna:85]
[same as prior period, unchanged from 0001783180-24-000077:mdna:89]

[0001783180-24-000088:mdna:86]
|  |  | Net Sales |  | Operating Profit |  | Operating Profit Margin |
|  |  | Three Months Ended September 30, |  | Three Months Ended September 30, |  | Three Months Ended September 30, |
| (In millions) |  | 2024 |  | 2023 |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| HVAC |  | $ | 5,058 |  |  | $ | 4,008 |  |  | $ | 741 |  |  | $ | 763 |  |  | 14.7 | % |  | 19.0 | % |
| Refrigeration |  | 938 |  |  | 924 |  |  | 109 |  |  | 107 |  |  | 11.6 | % |  | 11.6 | % |
| Total segment |  | $ | 5,996 |  |  | $ | 4,932 |  |  | $ | 850 |  |  | $ | 870 |  |  | 14.2 | % |  | 17.6 | % |

[0001783180-24-000088:mdna:87]
[same as prior period, unchanged from 0001783180-24-000077:mdna:91]

[0001783180-24-000088:mdna:88]
For the three months ended September 30, 2024, Net sales in our HVAC segment were $5.1 billion, a 26% increase compared with the same period of 2023. The components of the year-over-year change were as follows:

[0001783180-24-000088:mdna:89]
|  |  | Net Sales |
| Organic |  | 6 | % |
| Acquisitions and divestitures, net |  | 20 | % |
| Total % change in Net sales |  | 26 | % |

[0001783180-24-000088:mdna:90]
The organic increase in Net sales of 6% was driven by continued strong results in the segment. Growth in the Americas (up 9%) was primarily driven by our Commercial and Residential businesses which benefited from strong customer demand and pricing improvements. This was partially offset by lower volumes in our Light Commercial business. Growth in EMEA (up 3%) was primarily driven by ongoing customer demand and pricing improvements in our Commercial business. Residential markets continue to be impacted by reduced volume compared with the prior year. Results in Asia (down 3%) were impacted by lower demand in the region, primarily in China.

[0001783180-24-000088:mdna:91]
On January 2, 2024, we acquired the VCS Business, a leading manufacturer of high efficiency heating and renewable energy systems in Europe. The results of the VCS Business have been included in our Unaudited Condensed Consolidated Financial Statements since the date of acquisition. The transaction added 20% to Net sales during the three months ended September 30, 2024, and is included in Acquisitions and divestitures, net.

[0001783180-24-000088:mdna:92]
For the three months ended September 30, 2024, Operating profit in our HVAC segment was $741 million, a 3% decrease compared with the same period of 2023. The components of the year-over-year change were as follows:

[0001783180-24-000088:mdna:93]
|  |  | Operating Profit |
| Operational |  | 11 | % |
| Acquisitions and divestitures, net |  | 7 | % |
| Restructuring |  | (4) | % |
| Amortization of acquired intangibles |  | (18) | % |
| Other |  | 1 | % |
| Total % change in Operating profit |  | (3) | % |

[0001783180-24-000088:mdna:94]
The operational profit increase of 11% was primarily attributable to ongoing customer demand and pricing improvements in certain end-markets compared with the prior year. In addition, favorable material costs drove productivity benefits in the segment. These benefits more than offset volume reductions in certain end-markets and lower earnings from equity method investments. However, the prior year included a $16 million benefit recognized in connection with a favorable tax ruling at a minority owned joint venture.

[0001783180-24-000088:mdna:95]
[same as prior period, unchanged from 0001783180-24-000077:mdna:99]

[0001783180-24-000088:mdna:96]
For the three months ended September 30, 2024, Net sales in our Refrigeration segment were $938 million, a 1% increase compared to the same period of 2023. The components of the year-over-year change were as follows:

[0001783180-24-000088:mdna:97]
|  |  | Net Sales |
| Organic |  | 1 | % |
| Foreign currency translation |  | — | % |
| Total % change in Net sales |  | 1 | % |

[0001783180-24-000088:mdna:98]
The organic increase in Net Sales of 1% was primarily driven by volume growth and price improvements within certain end-markets compared with the prior year. Transport refrigeration results increased (up 4%) compared to the prior year primarily due to strong container end-markets. In addition, higher volumes in Asia further benefited results but were more than offset by lower end-market demand in North America and Europe. Results for Commercial refrigeration decreased (down 3%) compared with the prior year, primarily driven by reduced end-market demand in China. In addition, economic conditions and inflationary cost pressures impacted end-market demand in Europe.

[0001783180-24-000088:mdna:99]
For the three months ended September 30, 2024, Operating profit in our Refrigeration segment was $109 million, a 2% increase compared with the same period of 2023. The components of the year-over-year change were as follows:

[0001783180-24-000088:mdna:100]
|  |  | Operating Profit |
| Operational |  | 7 | % |
| Foreign currency translation |  | (1) | % |
| Other |  | (4) | % |
| Total % change in Operating profit |  | 2 | % |

[0001783180-24-000088:mdna:101]
The increase in operational profit of 7% was primarily driven by favorable productivity initiatives and price improvements compared with the prior year. In addition, volume growth in certain end-markets further benefited the segment. These amounts were partially offset by volume reductions in certain other end-markets. Inflationary cost pressures are moderating but continue to impact our operating profit. Amounts reported in Other represent $3 million of divestiture-related costs associated with the sale of CCR.

[0001783180-24-000088:mdna:102]
45

[0001783180-24-000088:mdna:103]
Nine Months Ended September 30, 2024 Compared with Nine Months Ended September 30, 2023

[0001783180-24-000088:mdna:104]
[same as prior period, unchanged from 0001783180-24-000077:mdna:117]

[0001783180-24-000088:mdna:105]
|  | Net Sales |  | Operating Profit |  | Operating Profit Margin |
|  | Nine Months Ended September 30, |  | Nine Months Ended September 30, |  | Nine Months Ended September 30, |
| (In millions) | 2024 |  | 2023 |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| HVAC | $ | 14,569 |  |  | $ | 11,846 |  |  | $ | 1,857 |  |  | $ | 1,940 |  |  | 12.7 | % |  | 16.4 | % |
| Refrigeration | 2,795 |  |  | 2,794 |  |  | 319 |  |  | 327 |  |  | 11.4 | % |  | 11.7 | % |
| Total segment | $ | 17,364 |  |  | $ | 14,640 |  |  | $ | 2,176 |  |  | $ | 2,267 |  |  | 12.5 | % |  | 15.5 | % |

[0001783180-24-000088:mdna:106]
[same as prior period, unchanged from 0001783180-24-000077:mdna:119]

[0001783180-24-000088:mdna:107]
For the nine months ended September 30, 2024, Net sales in our HVAC segment were $14.6 billion, a 23% increase compared with the same period of 2023. The components of the year-over-year change were as follows:

[0001783180-24-000088:mdna:108]
|  |  | Net Sales |
| Organic |  | 3 | % |
| Acquisitions and divestitures, net |  | 20 | % |
| Total % change in Net sales |  | 23 | % |

[0001783180-24-000088:mdna:109]
The organic increase in Net sales of 3% was driven by continued strong results in the segment. Growth in the Americas (up 7%) was primarily driven by our Commercial and Light Commercial businesses which benefited from ongoing customer demand and pricing improvements. Moderate growth in our Residential business was due to higher volumes compared with the prior year. EMEA (down 2%) continues to be impacted by reduced volumes in residential markets. The reduction was partially offset by ongoing customer demand and pricing improvements in our Commercial business. Results in Asia (down 3%) were impacted by lower demand in the region, primarily in China.

[0001783180-24-000088:mdna:110]
On January 2, 2024, we acquired the VCS Business, a leading manufacturer of high efficiency heating and renewable energy systems in Europe. The results of the VCS Business have been included in our Unaudited Condensed Consolidated Financial Statements since the date of acquisition. The transaction added 20% to Net sales during the nine months ended September 30, 2024 and is included in Acquisitions and divestitures, net.

[0001783180-24-000088:mdna:111]
For the nine months ended September 30, 2024, Operating profit in our HVAC segment was $1.9 billion, a 4% decrease compared with the same period of 2023. The components of the year-over-year change were as follows:

[0001783180-24-000088:mdna:112]
|  |  | Operating Profit |
| Operational |  | 17 | % |
| Acquisitions and divestitures, net |  | 1 | % |
| Restructuring |  | (3) | % |
| Amortization of acquired intangibles |  | (21) | % |
| Other |  | 2 | % |
| Total % change in Operating profit |  | (4) | % |

[0001783180-24-000088:mdna:113]
The operational profit increase of 17% was primarily attributable to ongoing customer demand and pricing improvements in certain end-markets compared with the prior year. In addition, favorable material and logistics costs drove productivity benefits in the segment. These benefits more than offset volume reductions in certain end-markets. Higher earnings from equity method investments further benefited operational profit in the segment. The increase was partially offset by a $23 million charge associated with the devaluation of U.S. Dollar denominated balances at an HVAC equity investment in Egypt.

[0001783180-24-000088:mdna:114]
46

[0001783180-24-000088:mdna:115]
[same as prior period, unchanged from 0001783180-24-000077:mdna:127]

[0001783180-24-000088:mdna:116]
For the nine months ended September 30, 2024, Net sales in our Refrigeration segment were $2.8 billion, flat compared to the same period of 2023. The components of the year-over-year change were as follows:

[0001783180-24-000088:mdna:117]
|  |  | Net Sales |
| Organic |  | — | % |
| Foreign currency translation |  | — | % |
| Total % change in Net sales |  | — | % |

[0001783180-24-000088:mdna:118]
Organic Net sales was flat compared to the prior year as the segment experienced challenges in certain end-markets during the period. Transport refrigeration results increased (up 1%) compared to the prior year primarily due to strong container markets. In addition, higher volumes in Asia and Europe further benefited results but were more than offset by lower end-market demand in North America. Results for Commercial refrigeration decreased (down 4%) compared with the prior year, primarily driven by lower volumes in Europe as economic conditions and inflationary cost pressures impacted end-market demand. In addition, Asia results were impacted by reduced end-market demand in China.

[0001783180-24-000088:mdna:119]
For the nine months ended September 30, 2024, Operating profit in our Refrigeration segment was $319 million, a 2% decrease compared with the same period of 2023. The components of the year-over-year change were as follows:

[0001783180-24-000088:mdna:120]
|  |  | Operating Profit |
| Operational |  | 6 | % |
| Foreign currency translation |  | (1) | % |
| Restructuring |  | 3 | % |
| Other |  | (10) | % |
| Total % change in Operating profit |  | (2) | % |

[0001783180-24-000088:mdna:121]
The increase in operational profit of 6% was primarily driven by favorable productivity initiatives and price improvements compared with the prior year. In addition, volume growth in certain end-markets further benefited the segment. These amounts were partially offset by volume reductions in certain other end-markets. Inflationary cost pressures are moderating but continue to impact our operating profit. Amounts reported in Other represent $11 million of divestiture-related costs associated with the sale of CCR. In addition, the prior year includes a $24 million gain on the sale of a business within Transport refrigeration.

[0001783180-24-000088:mdna:122]
[same as prior period, unchanged from 0001783180-24-000077:mdna:142]

[0001783180-24-000088:mdna:123]
[same as prior period, unchanged from 0001783180-24-000077:mdna:143]

[0001783180-24-000088:mdna:124]
[same as prior period, unchanged from 0001783180-24-000077:mdna:144]

[0001783180-24-000088:mdna:125]
As of September 30, 2024, we had cash and cash equivalents of $2.2 billion, of which approximately 68% was held by our foreign subsidiaries. We manage our worldwide cash requirements by reviewing available funds and the cost effectiveness with which we can access funds held by foreign subsidiaries. On occasion, we are required to maintain cash deposits in connection with contractual obligations related to acquisitions, divestitures or other legal obligations. As of September 30, 2024 and December 31, 2023, the amount of such restricted cash was approximately $14 million and $2 million, respectively.

[0001783180-24-000088:mdna:126]
[same as prior period, unchanged from 0001783180-24-000077:mdna:146]

[0001783180-24-000088:mdna:127]
[same as prior period, unchanged from 0001783180-24-000077:mdna:147]

[0001783180-24-000088:mdna:128]
[same as prior period, unchanged from 0001783180-24-000077:mdna:148]

[0001783180-24-000088:mdna:129]
| (In millions) |  | September 30,2024 |  | December 31,2023 |
| Cash and cash equivalents |  | $ | 2,225 |  |  | $ | 9,852 |  |
| Total debt |  | $ | 12,432 |  |  | $ | 14,293 |  |
| Total equity |  | $ | 15,042 |  |  | $ | 9,005 |  |
| Net debt (total debt less cash and cash equivalents) |  | $ | 10,207 |  |  | $ | 4,441 |  |
| Total capitalization (total debt plus total equity) |  | $ | 27,474 |  |  | $ | 23,298 |  |
| Net capitalization (total debt plus total equity less cash and cash equivalents) |  | $ | 25,249 |  |  | $ | 13,446 |  |
| Total debt to total capitalization |  | 45 | % |  | 61 | % |
| Net debt to net capitalization |  | 40 | % |  | 33 | % |

[0001783180-24-000088:mdna:130]
[same as prior period, unchanged from 0001783180-24-000077:mdna:150]

[0001783180-24-000088:mdna:131]
[same as prior period, unchanged from 0001783180-24-000077:mdna:151]

[0001783180-24-000088:mdna:132]
[same as prior period, unchanged from 0001783180-24-000077:mdna:153]

[0001783180-24-000088:mdna:133]
[same as prior period, unchanged from 0001783180-24-000077:mdna:154]

[0001783180-24-000088:mdna:134]
In March 2024, borrowings under the 60-day loan were repaid. In May 2024, the Revolver was terminated and refinanced in order to extend its maturity to May 2025. In addition, we redeemed our $1.0 billion aggregate principal amount of 5.80% notes due in 2025 and repaid borrowings under the Delayed Draw Facility in June 2024, which was subsequently terminated. In August 2024, we completed tender offers on certain tranches of our notes which included $125 million of notes due 2034, $350 million of notes due 2054 and approximately $600 million of notes due 2050.

[0001783180-24-000088:mdna:135]
[same as prior period, unchanged from 0001783180-24-000077:mdna:156]

[0001783180-24-000088:mdna:136]
We maintain a $2.0 billion unsecured, unsubordinated commercial paper program which we can use for general corporate purposes, including the funding of working capital and potential acquisitions. In addition, we maintain a $2.0 billion revolving credit agreement with various banks (the "Revolving Credit Facility") that matures in May 2028 which supports our commercial paper borrowing program and can be used for general corporate purposes. A ratings-based commitment fee is charged on unused commitments. As of September 30, 2024, we had no borrowings outstanding under our commercial paper program or our Revolving Credit Facility.

[0001783180-24-000088:mdna:137]
Our short-term obligations primarily consist of current maturities of long-term debt. Our long-term obligations primarily consist of long-term notes with maturity dates ranging between 2025 and 2054. Interest payments related to long-term notes are expected to approximate $433 million per year, reflecting an approximate weighted-average interest rate of 3.53%. Any borrowings from the Revolving Credit Facility are subject to variable interest rates. See Note 5 – Borrowings and Lines of Credit in the Notes to the accompanying Unaudited Condensed Consolidated Financial Statements for additional information regarding the terms of our long-term debt obligations.

[0001783180-24-000088:mdna:138]
The following table presents our credit ratings and outlook as of September 30, 2024:

[0001783180-24-000088:mdna:139]
| Rating Agency |  | Long-term Rating (1) |  | Short-term Rating (2) |  | Outlook (2) (3) |
| Standards & Poor's ("S&P") |  | BBB |  | A2 |  | Positive |
| Moody's Investors Service Inc. ("Moody's") |  | Baa2 |  | P2 |  | Positive |
| Fitch Ratings ("Fitch") |  | BBB |  | F2 |  | Positive |

[0001783180-24-000088:mdna:140]
(1) The long-term rating was upgraded by Moody's to Baa2 on May 13, 2024. Fitch's was updated in December 2023.

[0001783180-24-000088:mdna:141]
[same as prior period, unchanged from 0001783180-24-000077:mdna:162]

[0001783180-24-000088:mdna:142]
[same as prior period, unchanged from 0001783180-24-000077:mdna:163]

[0001783180-24-000088:mdna:143]
[same as prior period, unchanged from 0001783180-24-000077:mdna:166]

[0001783180-24-000088:mdna:144]
On June 2, 2024, we completed the divestiture of Access Solutions for cash proceeds of $5.0 billion, subject to customary working capital and other adjustments. On July 1, 2024, we completed the divestiture of Industrial Fire to Sentinel Capital Partners for cash proceeds of $1.4 billion, subject to customary working capital and other adjustments. Consistent with our capital allocation strategy, the net proceeds will be used to fund repayment of debt, investments in organic and inorganic growth initiatives and capital returns to shareowners as well as for general corporate purposes.

[0001783180-24-000088:mdna:145]
On December 12, 2023, we entered into a stock purchase agreement to sell CCR to Haier Group Corporation for an enterprise value of approximately $775 million. The sale of CCR was completed on October 1, 2024. On August 15, 2024, we entered into a stock purchase agreement to sell the CRF Business to an affiliate of Lone Star Funds for an enterprise value of approximately $3.0 billion. The transaction is expected to close in 2024.

[0001783180-24-000088:mdna:146]
[same as prior period, unchanged from 0001783180-24-000077:mdna:169]

[0001783180-24-000088:mdna:147]
We may repurchase our outstanding common stock from time to time subject to market conditions and at our discretion. Repurchases occur in the open market or through one or more other public or private transactions pursuant to plans complying with Rules 10b5-1 and 10b-18 under the Exchange Act. Since the initial authorization in February 2021, our Board of Directors authorized the repurchase of up to $4.1 billion of our outstanding common stock. As of December 31, 2023, we repurchased 43.5 million shares of common stock for an aggregate purchase price of $2.0 billion, including shares repurchased under an accelerated share repurchase agreement. As a result, we had approximately $2.1 billion remaining under the current authorization at December 31, 2023.

[0001783180-24-000088:mdna:148]
During the nine months ended September 30, 2024, we repurchased 6.2 million shares of common stock for an aggregate purchase price of $0.4 billion. As a result we had approximately $1.7 billion remaining under the current authorization at September 30, 2024. In addition, our Board of Directors approved a $3 billion increase to our existing share repurchase program in October 2024.

[0001783180-24-000088:mdna:149]
[same as prior period, unchanged from 0001783180-24-000077:mdna:171]

[0001783180-24-000088:mdna:150]
We paid dividends on common stock during the nine months ended September 30, 2024, totaling $514 million. In October 2024, the Board of Directors declared a dividend of $0.19 per share of common stock payable on November 18, 2024, to shareowners of record at the close of business on October 25, 2024.

[0001783180-24-000088:mdna:151]
[same as prior period, unchanged from 0001783180-24-000077:mdna:173]

[0001783180-24-000088:mdna:152]
The following table reflects the major categories of cash flows for the following periods:

[0001783180-24-000088:mdna:153]
|  |  | Nine Months Ended September 30, |
| (In millions) |  | 2024 |  | 2023 |
| Net cash flows provided by (used in): |  |  |  |  |
| Continuing operating activities |  | $ | 1,208 |  |  | $ | 1,345 |  |
| Continuing investing activities |  | (11,331) |  |  | (284) |  |
| Continuing financing activities |  | (2,939) |  |  | (673) |  |

[0001783180-24-000088:mdna:154]
Cash flows from continuing operating activities primarily represent inflows and outflows associated with our continuing operations. Primary activities include net earnings from continuing operations adjusted for non-cash transactions, working capital changes and changes in other assets and liabilities. The year-over-year decrease in net cash provided by continuing operating activities was primarily driven by an increase in working capital balances compared with the prior period. Improved cash conversion and lower inventory levels were more than offset by lower accounts payable balances.

[0001783180-24-000088:mdna:155]
50

[0001783180-24-000088:mdna:156]
Cash flows from continuing investing activities primarily represent inflows and outflows associated with long-term assets. Primary activities include capital expenditures, acquisitions, divestitures and proceeds from the sale of fixed assets. During the nine months ended September 30, 2024, net cash used in continuing investing activities was $11.3 billion. The primary driver of the outflow related to the acquisition of the VCS Business, which totaled $10.8 billion, net of cash acquired. Additional investing outflows include $187 million related to settlement of derivatives and $302 million of capital expenditures. During the nine months ended September 30, 2023, net cash used in continuing investing activities was $284 million. The primary driver of the outflow related to $217 million of capital expenditures. In addition, we settled working capital and other transaction-related items associated with the acquisition of Toshiba Carrier Corporation and invested in several businesses. These amounts totaled $69 million, net of cash acquired and were partially offset by the proceeds from the sale of a business during the period.

[0001783180-24-000088:mdna:157]
Cash flows from continuing financing activities primarily represent inflows and outflows associated with equity or borrowings. During the nine months ended September 30, 2024, net cash used in continuing financing activities was $2.9 billion. The primary driver of the outflow is due to repayments of long-term debt of $4.5 billion which includes prepayments of the Delayed Draw Facility, redemption of our 5.80% notes due in 2025 and tender offers of approximately $1.0 billion. In addition, we made payments totaling $431 million to repurchase shares of our common stock and dividend payments of $514 million to our common shareowners. These outflows were partially offset by the proceeds of borrowings used to fund the cash portion of the acquisition of the VCS Business. During the nine months ended September 30, 2023, net cash used in continuing financing activities was $673 million. The primary driver of the outflow related to the payment of $465 million in dividends to our common shareowners. In addition, we paid $62 million to repurchase shares of our common stock.
