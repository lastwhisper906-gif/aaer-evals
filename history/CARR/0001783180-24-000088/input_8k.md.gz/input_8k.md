# CARR 8-K — 0001783180-24-000084 filed 2024-10-24

## item codes, every 8-K on or before 2024-10-25

- 2024-10-24 0001783180-24-000084 — 2.02, 7.01, 9.01
- 2024-10-18 0000950142-24-002601 — 1.01
- 2024-08-15 0001140361-24-037426 — 7.01, 9.01
- 2024-07-25 0001783180-24-000075 — 2.02, 9.01
- 2024-06-21 0001783180-24-000069 — 5.02
- 2024-06-21 0000950142-24-001676 — 5.02
- 2024-06-07 0001783180-24-000062 — 5.02, 5.03, 9.01
- 2024-06-03 0000950142-24-001538 — 1.02, 7.01, 9.01
- 2024-05-17 0001783180-24-000049 — 1.01, 1.02, 2.03, 9.01
- 2024-04-25 0001783180-24-000042 — 2.02, 9.01
- 2024-04-19 0001783180-24-000035 — 5.07, 9.01
- 2024-04-19 0000950142-24-001162 — 5.07 — amendment of 0001783180-24-000035
- 2024-02-06 0001783180-24-000007 — 2.02, 9.01
- 2024-02-01 0000950142-24-000264 — 5.02
- 2024-01-02 0001140361-24-000034 — 1.01, 2.01, 2.03, 5.02, 7.01, 9.01
- 2023-12-13 0001140361-23-057415 — 1.01, 9.01
- 2023-12-08 0001140361-23-056751 — 7.01, 9.01
- 2023-11-30 0000950142-23-002884 — 1.01, 2.03, 8.01, 9.01
- 2023-11-16 0000950142-23-002788 — 8.01, 9.01
- 2023-11-13 0001140361-23-052667 — 7.01, 8.01, 9.01
- 2023-10-26 0001783180-23-000063 — 2.02, 9.01
- 2023-07-27 0001783180-23-000053 — 2.02, 9.01
- 2023-06-12 0000950142-23-001664 — 5.02
- 2023-05-25 0000950142-23-001541 — 1.01, 1.02, 2.03, 9.01
- 2023-04-26 0000950142-23-001205 — 1.01, 9.01
- 2023-04-25 0001783180-23-000036 — 2.02, 7.01, 9.01
- 2023-04-25 0000950142-23-001199 — 7.01, 8.01, 9.01
- 2023-04-21 0001783180-23-000032 — 5.07, 9.01
- 2023-02-07 0001783180-23-000010 — 2.02, 9.01
- 2022-10-27 0001783180-22-000054 — 2.02, 7.01, 9.01
- 2022-09-29 0000950142-22-002805 — 5.02, 9.01
- 2022-07-28 0001783180-22-000045 — 2.02, 9.01
- 2022-04-28 0001783180-22-000032 — 2.02, 9.01
- 2022-04-15 0001783180-22-000024 — 5.07, 9.01
- 2022-02-08 0001783180-22-000008 — 2.02, 9.01
- 2022-02-07 0000950142-22-000510 — 8.01, 9.01
- 2022-01-03 0000950142-22-000023 — 8.01, 9.01
- 2021-12-17 0001783180-21-000071 — 5.02, 7.01, 9.01
- 2021-11-23 0001783180-21-000068 — 5.03, 9.01
- 2021-10-28 0001783180-21-000062 — 2.02, 9.01
- 2021-08-27 0001783180-21-000056 — 8.01
- 2021-07-30 0001783180-21-000053 — 1.01
- 2021-07-29 0001783180-21-000049 — 2.02, 8.01, 9.01
- 2021-07-27 0000950142-21-002448 — 8.01, 9.01
- 2021-07-15 0000950142-21-002362 — 5.02, 9.01
- 2021-06-09 0000950142-21-001885 — 5.02, 9.01
- 2021-04-29 0001783180-21-000029 — 2.02, 9.01
- 2021-04-22 0001140361-21-013889 — 5.02, 9.01
- 2021-04-20 0001783180-21-000021 — 5.07, 9.01
- 2021-04-19 0000950142-21-001308 — 8.01, 9.01
- 2021-02-09 0001783180-21-000009 — 2.02, 9.01
- 2021-02-05 0001140361-21-003513 — 8.01, 9.01
- 2020-12-23 0001140361-20-029419 — 7.01, 9.01
- 2020-12-22 0001140361-20-029097 — 8.01
- 2020-12-14 0001140361-20-028246 — 5.03, 9.01
- 2020-12-07 0001140361-20-027515 — 1.01, 7.01, 9.01
- 2020-10-29 0001783180-20-000063 — 2.02, 9.01
- 2020-10-19 0001140361-20-023241 — 5.02, 7.01, 9.01
- 2020-09-23 0001140361-20-021220 — 8.01, 9.01
- 2020-09-22 0001140361-20-021124 — 8.01, 9.01
- 2020-07-30 0001783180-20-000045 — 2.02, 9.01
- 2020-06-19 0001140361-20-014325 — 1.01, 2.03, 9.01
- 2020-06-16 0001140361-20-013880 — 8.01, 9.01
- 2020-06-03 0001140361-20-012939 — 1.01, 9.01
- 2020-05-08 0001783180-20-000013 — 2.02, 9.01
- 2020-04-03 0001140361-20-007888 — 1.01, 5.02, 5.03, 5.05, 7.01, 9.01
- 2020-03-16 0001140361-20-005868 — 8.01, 9.01

## late-filing notifications on or before 2024-10-25

- none on or before 2024-10-25

## item 2.02 — earnings release, exhibit 99.1

[0001783180-24-000084:8k_2_02:1]
EX-99
2
a99-q32024earningsexhibit.htm
EX-99

[0001783180-24-000084:8k_2_02:2]
Document

[0001783180-24-000084:8k_2_02:3]
Exhibit 99

[0001783180-24-000084:8k_2_02:4]
Carrier Reports Strong Third Quarter 2024 Results

[0001783180-24-000084:8k_2_02:5]
•Fire & Security segment now reported as discontinued operations making prior guidance not comparable

[0001783180-24-000084:8k_2_02:6]
•Net sales of $6.0 billion up 21% versus third quarter 2023; organic sales up 4%

[0001783180-24-000084:8k_2_02:7]
•GAAP EPS from continuing operations of $0.62 and adjusted EPS from continuing operations of $0.77

[0001783180-24-000084:8k_2_02:8]
•Total GAAP EPS of $0.49 and adjusted EPS of $0.83

[0001783180-24-000084:8k_2_02:9]
•Final business exit on-track to close around year end

[0001783180-24-000084:8k_2_02:10]
•Board increases remaining share repurchase authorization to $4.7 billion

[0001783180-24-000084:8k_2_02:11]
•Updated full year guidance to reflect the impact of discontinued operations

[0001783180-24-000084:8k_2_02:12]
PALM BEACH GARDENS, Fla., October 24, 2024 – Carrier Global Corporation (NYSE:CARR), global leader in intelligent climate and energy solutions, today reported strong financial results for the third quarter of 2024 and adjusted its full year guidance to reflect the move of the Fire & Security segment to discontinued operations. The guidance now only reflects continuing operations.

[0001783180-24-000084:8k_2_02:13]
“We delivered another quarter of strong financial performance while making significant progress on our portfolio transformation," said Carrier Chair & CEO David Gitlin. “Organic sales growth was up mid-single digits – with aftermarket up 10% – and we grew orders roughly 20% as we continue to gain share across key segments. Strong operating performance driven by Carrier Excellence led to very strong core earnings conversion. Carrier continues to create tremendous value for our shareholders as we become a higher growth and more focused global leader in intelligent climate and energy solutions. Our new share repurchase authorization reflects our commitment to deliver shareholder value through disciplined capital allocation. We plan to have all our divestitures complete by the end of this year and we are very pleased with the recently announced settlements related to aqueous film-forming foam (AFFF). With all of our transformational actions now

[0001783180-24-000084:8k_2_02:14]
1

[0001783180-24-000084:8k_2_02:15]
substantially behind us we can even further increase our focus on customers and delivering continued superior financial performance.

[0001783180-24-000084:8k_2_02:16]
Third Quarter 2024 Results

[0001783180-24-000084:8k_2_02:17]
Carrier’s third quarter sales of $6.0 billion were up 21% compared to the prior year including 4% organic growth and approximately 17% contribution from acquisitions, driven by Viessmann Climate Solutions. Foreign currency translation had no impact on sales growth. Organic sales in the HVAC segment were up 6%. HVAC sales in the Americas were up high-single-digits driven by continued strength in Commercial HVAC, which was up almost 20%, and double-digit growth in North America Residential HVAC. HVAC organic sales in EMEA were up low-single-digits, with Commercial HVAC up double-digits offsetting a decline in Residential and Light Commercial HVAC sales. These organic figures exclude the sales contribution of Viessmann Climate Solutions which was up 8% sequentially and down around 25% year-over-year. HVAC sales in Asia Pacific were down low-single-digits driven by declines in residential light commercial in China, partially offset by strength in Commercial HVAC and other countries in Asia. Refrigeration sales were up 1% organically driven by over 30% growth in container, mostly offset by declines in North America truck and trailer.

[0001783180-24-000084:8k_2_02:18]
GAAP operating profit in the quarter of $0.8 billion was up 50% from last year primarily due to operational performance and the addition of Viessmann Climate Solutions. Adjusted operating profit of over $1.0 billion from continuing operations was up 19%, mostly driven by organic growth, price and productivity, and the addition of Viessmann Climate Solutions. Net income from continuing operations was $564 million and adjusted net earnings from continuing operations was $705 million. GAAP EPS from continuing operations was $0.62 and adjusted EPS from continuing operations was $0.77. GAAP EPS from discontinued operations was ($0.13) and adjusted EPS from discontinued operations was $0.06.

[0001783180-24-000084:8k_2_02:19]
Year to date, preliminary net cash flows generated from operating activities were $431 million and capital expenditures were $312 million, resulting in preliminary free cash flow of $119 million. This includes cash tax payments of approximately $1 billion on the

[0001783180-24-000084:8k_2_02:20]
2

[0001783180-24-000084:8k_2_02:21]
gains of the business exits and approximately $300 million of transaction and restructuring costs.

[0001783180-24-000084:8k_2_02:22]
Share Repurchase Authorization

[0001783180-24-000084:8k_2_02:23]
On October 21, 2024, Carrier Global Corporation's Board of Directors approved a $3 billion share repurchase authorization. With the remaining portion of the prior authorization, Carrier currently has about $4.7 billion of repurchase authorization. Share repurchases, if any, will take place at the company’s discretion in the open market or through one or more other public or private transactions, subject to, among other things, market conditions, share price, compliance with securities laws and regulatory requirements and other factors. The stock repurchase authorization has no time limit and may be modified, suspended or discontinued at any time. This authorization is a key component of the company's capital allocation plans, which also includes acquisitions and dividends to help position the company for strategic growth and to generate attractive shareowner returns.

[0001783180-24-000084:8k_2_02:24]
3

[0001783180-24-000084:8k_2_02:25]
Full-Year 2024 Guidance**

[0001783180-24-000084:8k_2_02:26]
Carrier's updated guidance for 2024 now only reflects continuing operations with the exception of free cash flow.

[0001783180-24-000084:8k_2_02:27]
|  | Current Guidance** |  |
| Sales | ~$22.5B Organic* up ~3%FX (0%)Acquisitions +18%Divestitures (2%) |  |
| Adjusted Operating Margin* | ~15.5% |  |
| Adjusted EPS* | ~$2.50 |  |
| Free Cash Flow* | ~($0.2B)Includes the expected results of continuing operations and discontinued operations. Includes ~$2.6B of expected tax payments on the gains from the announced business exits, restructuring, and transaction-related costs |  |

[0001783180-24-000084:8k_2_02:28]
*Note: When the company provides expectations for organic sales, adjusted operating profit, adjusted operating margin, adjusted EPS and free cash flow on a forward-looking basis, a reconciliation of the differences between the non-GAAP expectations and the corresponding GAAP measures generally is not available without unreasonable effort. See “Use and Definitions of Non-GAAP Financial Measures” below for additional information.

[0001783180-24-000084:8k_2_02:29]
**As of October 24, 2024

[0001783180-24-000084:8k_2_02:30]
Conference Call

[0001783180-24-000084:8k_2_02:31]
Carrier will host a webcast of its earnings conference call today, Thursday, October 24, 2024, at 7:30 a.m. ET. To access the webcast, visit the Events & Presentations section of the Carrier Investor Relations site at ir.carrier.com/news-and-events/events-and-presentations or to listen to the earnings call by phone, participants must pre-register at Carrier Earnings Call Registration. All registrants will receive dial-in information and a PIN allowing access to the live call.

[0001783180-24-000084:8k_2_02:32]
Discontinued Operations

[0001783180-24-000084:8k_2_02:33]
In 2023, the Company announced plans to exit its Fire & Security and Commercial Refrigeration businesses over the course of 2024. The announced plan to exit the Fire & Security segment represents a single disposal plan to separately divest multiple businesses over different reporting periods. Upon the Commercial and Residential Fire Business qualifying as held for sale during the three months ended September 30, 2024, the components of the Fire & Security segment in aggregate met the criteria to be presented as

[0001783180-24-000084:8k_2_02:34]
4

[0001783180-24-000084:8k_2_02:35]
discontinued operations in the Company’s unaudited condensed consolidated statement of operations and unaudited condensed consolidated statement of cash flows. In addition, the assets and liabilities of the Commercial and Residential Fire Business have been reclassified to held for sale at December 31, 2023. The results of the Commercial Refrigeration business did not meet the criteria to be presented in discontinued operations. Accordingly, all financial measures presented herein, including non-GAAP financial measures, are associated with Carrier's continuing operations unless specifically noted. See “Use and Definitions of Non-GAAP Financial Measures” below.

[0001783180-24-000084:8k_2_02:36]
Cautionary Statement

[0001783180-24-000084:8k_2_02:37]
This communication contains statements which, to the extent they are not statements of historical or present fact, constitute "forward-looking statements" under the securities laws. These forward-looking statements are intended to provide management's current expectations or plans for Carrier's future operating and financial performance, based on assumptions currently believed to be valid. Forward-looking statements can be identified by the use of words such as "believe," "expect," "expectations," "plans," "strategy," "prospects," "preliminary," "estimate," "project," "target," "anticipate," "will," "should," "see," "guidance," "outlook," "confident," "scenario" and other words of similar meaning in connection with a discussion of future operating or financial performance. Forward-looking statements may include, among other things, statements relating to future sales, earnings, cash flow, results of operations, uses of cash, share repurchases, tax rates and other measures of financial performance or potential future plans, strategies or transactions of Carrier, our portfolio transformation and the use of the anticipated proceeds thereof, potential future investments, Carrier's plans with respect to its indebtedness and other statements that are not historical facts.

[0001783180-24-000084:8k_2_02:38]
This communication also contains estimated net cash flow and free cash flow results for the quarter ended September 30, 2024. These estimated net cash flow and free cash results are preliminary and subject to completion and may change as a result of management’s continued review. Such preliminary results are subject to the finalization of quarter-end financial and accounting procedures. The preliminary net cash flow and free cash flow financial results represent management estimates that constitute forward-looking statements.

[0001783180-24-000084:8k_2_02:39]
All forward-looking statements involve risks, uncertainties and other factors that may cause actual results to differ materially from those expressed or implied in the forward-looking statements. For additional information on identifying factors that may cause actual results to vary materially from those stated in forward-looking statements, see Carrier's reports on Forms 10-K, 10-Q and 8-K filed with or furnished to the U.S. Securities and Exchange Commission from time to time. Any forward-looking statement speaks only as of the date on which it is made, and Carrier assumes no obligation to update or revise such statement, whether as a result of new information, future events or otherwise, except as required by applicable law.

[0001783180-24-000084:8k_2_02:40]
About Carrier

[0001783180-24-000084:8k_2_02:41]
Carrier Global Corporation, global leader in intelligent climate and energy solutions, is committed to creating solutions that matter for people and our planet for generations to come. From the beginning, we've led in inventing new technologies and entirely new industries. Today, we continue to lead because we have a world-class, diverse workforce

[0001783180-24-000084:8k_2_02:42]
5

[0001783180-24-000084:8k_2_02:43]
that puts the customer at the center of everything we do. For more information, visit corporate.carrier.com or follow Carrier on social media at @Carrier.

[0001783180-24-000084:8k_2_02:44]
CARR-IR

[0001783180-24-000084:8k_2_02:45]
Contact:

[0001783180-24-000084:8k_2_02:46]
Investor Relations

[0001783180-24-000084:8k_2_02:47]
561-365-2251

[0001783180-24-000084:8k_2_02:48]
Investor.Relations@Carrier.com

[0001783180-24-000084:8k_2_02:49]
Media Inquiries

[0001783180-24-000084:8k_2_02:50]
Rob Six

[0001783180-24-000084:8k_2_02:51]
561-281-2362

[0001783180-24-000084:8k_2_02:52]
Rob.Six@Carrier.com

[0001783180-24-000084:8k_2_02:53]
6

[0001783180-24-000084:8k_2_02:54]
SELECTED FINANCIAL DATA, NON-GAAP MEASURES AND DEFINITIONS

[0001783180-24-000084:8k_2_02:55]
Following are tables that present selected financial data of Carrier Global Corporation (“Carrier”). Also included are reconciliations of non-GAAP measures to their most comparable GAAP measures.

[0001783180-24-000084:8k_2_02:56]
Use and Definitions of Non-GAAP Financial Measures

[0001783180-24-000084:8k_2_02:57]
Carrier reports its financial results in accordance with accounting principles generally accepted in the United States ("GAAP"). We supplement the reporting of our financial information determined under GAAP with certain non-GAAP financial information. The non-GAAP information presented provides investors with additional useful information, but should not be considered in isolation or as substitutes for the related GAAP measures. Moreover, other companies may define non-GAAP measures differently, which limits the usefulness of these measures for comparisons with such other companies. We encourage investors to review our financial statements and publicly filed reports in their entirety and not to rely on any single financial measure. A reconciliation of the non-GAAP measures to the corresponding amounts prepared in accordance with GAAP appears in the tables in this Appendix. The tables provide additional information as to the items and amounts that have been excluded from the adjusted measures.

[0001783180-24-000084:8k_2_02:58]
Organic sales, adjusted operating profit, adjusted operating margin, incremental margins / earnings conversion, earnings before interest, taxes and depreciation and amortization (“EBITDA”), adjusted EBITDA, adjusted net income, adjusted earnings per share (“EPS”), adjusted interest expense, net, adjusted effective tax rate and net debt are non-GAAP financial measures and are associated with Carrier's continuing operations unless specifically noted.

[0001783180-24-000084:8k_2_02:59]
Organic sales represents consolidated net sales (a GAAP measure), excluding the impact of foreign currency translation, acquisitions and divestitures completed in the preceding twelve months and other significant items of a nonoperational nature (hereinafter referred to as “other significant items”). Adjusted operating profit represents operating profit (a GAAP measure), excluding restructuring costs, amortization of acquired intangibles and other significant items. Adjusted operating margin represents adjusted operating profit as a percentage of net sales (a GAAP measure). Incremental margins / earnings conversion represents the year-over-year change in adjusted operating profit divided by the year-over-year change in net sales. EBITDA represents net income attributable to common shareholders (a GAAP measure), adjusted for interest income and expense, income tax expense, and depreciation and amortization. Adjusted EBITDA represents EBITDA, as calculated above, excluding non-service pension benefit, non-controlling interest in subsidiaries’ earnings from operations, restructuring costs and other significant items. Adjusted net income represents net income attributable to common shareowners (a GAAP measure), excluding restructuring costs, amortization of acquired intangibles and other significant items. Adjusted EPS represents diluted earnings per share (a GAAP measure), excluding restructuring costs, amortization of acquired intangibles and other significant items. Adjusted interest expense, net represents interest expense (a GAAP measure) and interest income (a GAAP measure), net excluding other significant items. The adjusted effective tax rate represents the effective tax rate (a GAAP measure), excluding restructuring costs, amortization of acquired intangibles and other significant items. Net debt represents long-term debt (a GAAP measure) less cash and cash equivalents (a GAAP measure). For the business segments, when applicable, adjustments of operating profit and operating margins represent operating profit, excluding restructuring, amortization of acquired intangibles and other significant items.

[0001783180-24-000084:8k_2_02:60]
Free cash flow is a non-GAAP financial measure that represents net cash flows provided by continuing operating activities (a GAAP measure) less capital expenditures. Management believes free cash flow is a useful measure of liquidity and an additional basis for assessing Carrier’s ability to fund its activities, including the financing of acquisitions, debt service, repurchases of Carrier's common stock and distribution of earnings to shareowners.

[0001783180-24-000084:8k_2_02:61]
Orders are contractual commitments with customers to provide specified goods or services for an agreed upon price and may not be subject to penalty if cancelled.

[0001783180-24-000084:8k_2_02:62]
When Carrier provides our expectations for organic sales, adjusted operating profit, adjusted operating margin, adjusted interest expense, net, adjusted effective tax rate, incremental margins/earnings conversion, EBITDA, adjusted EBITDA, adjusted EPS and free cash flow on a forward-looking basis, a reconciliation of the differences between the non-GAAP expectations and the corresponding GAAP measures (expected net sales, operating profit, operating margin, interest expense, effective tax rate, incremental operating margin, net income attributable to common shareowners, diluted EPS and net cash flows provided by operating activities) generally is not available without unreasonable effort due to potentially high variability, complexity and low visibility as to the items that would be excluded from the GAAP measure in the relevant future period, such as unusual gains and losses, the ultimate outcome of pending litigation, fluctuations in foreign currency exchange rates, the impact and timing of potential acquisitions and divestitures, future restructuring costs, and other structural changes or their probable significance. The variability of the excluded items may have a significant, and potentially unpredictable, impact on our future GAAP results.

[0001783180-24-000084:8k_2_02:63]
Carrier Global Corporation

[0001783180-24-000084:8k_2_02:64]
Condensed Consolidated Statement of Operations

[0001783180-24-000084:8k_2_02:65]
|  |  | (Unaudited) |
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
| (In millions, except per share amounts) |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Net sales |  |  |  |  |  |  |  |  |
| Product sales |  | $ | 5,307 |  |  | $ | 4,344 |  |  | $ | 15,460 |  |  | $ | 12,939 |  |
| Service sales |  | 677 |  |  | 591 |  |  | 1,878 |  |  | 1,696 |  |
| Total Net sales |  | 5,984 |  |  | 4,935 |  |  | 17,338 |  |  | 14,635 |  |
| Costs and expenses |  |  |  |  |  |  |  |  |
| Cost of products sold |  | (3,796) |  |  | (2,986) |  |  | (11,245) |  |  | (9,269) |  |
| Cost of services sold |  | (511) |  |  | (463) |  |  | (1,456) |  |  | (1,321) |  |
| Research and development |  | (172) |  |  | (126) |  |  | (524) |  |  | (355) |  |
| Selling, general and administrative |  | (799) |  |  | (664) |  |  | (2,394) |  |  | (1,870) |  |
| Total Costs and expenses |  | (5,278) |  |  | (4,239) |  |  | (15,619) |  |  | (12,815) |  |
| Equity method investment net earnings |  | 66 |  |  | 75 |  |  | 187 |  |  | 171 |  |
| Other income (expense), net |  | (9) |  |  | (261) |  |  | (34) |  |  | (370) |  |
| Operating profit |  | 763 |  |  | 510 |  |  | 1,872 |  |  | 1,621 |  |
| Non-service pension (expense) benefit |  | (1) |  |  | — |  |  | (1) |  |  | — |  |
| Interest (expense) income, net |  | 8 |  |  | (39) |  |  | (290) |  |  | (126) |  |
| Earnings before income taxes |  | 770 |  |  | 471 |  |  | 1,581 |  |  | 1,495 |  |
| Income tax (expense) benefit |  | (172) |  |  | (177) |  |  | (339) |  |  | (453) |  |
| Earnings from continuing operations |  | 598 |  |  | 294 |  |  | 1,242 |  |  | 1,042 |  |
| Discontinued operations, net of tax |  | (117) |  |  | 87 |  |  | 1,897 |  |  | (41) |  |
| Net earnings (loss) |  | 481 |  |  | 381 |  |  | 3,139 |  |  | 1,001 |  |
| Less: Non-controlling interest in subsidiaries' |  | 34 |  |  | 24 |  |  | 86 |  |  | 72 |  |
| Net earnings (loss) attributable to common shareowners |  | $ | 447 |  |  | $ | 357 |  |  | $ | 3,053 |  |  | $ | 929 |  |
| Amounts attributable to common shareowners: |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 564 |  |  | $ | 270 |  |  | $ | 1,156 |  |  | $ | 970 |  |
| Discontinued operations |  | (117) |  |  | 87 |  |  | 1,897 |  |  | (41) |  |
| Net earnings (loss) attributable to common shareowners |  | $ | 447 |  |  | $ | 357 |  |  | $ | 3,053 |  |  | $ | 929 |  |
| Earnings per share |  |  |  |  |  |  |  |  |
| Basic: |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 0.63 |  |  | $ | 0.32 |  |  | $ | 1.28 |  |  | $ | 1.16 |  |
| Discontinued operations |  | (0.13) |  |  | 0.11 |  |  | 2.11 |  |  | (0.05) |  |
| Net earnings (loss) |  | $ | 0.50 |  |  | $ | 0.43 |  |  | $ | 3.39 |  |  | $ | 1.11 |  |
| Diluted: |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 0.62 |  |  | $ | 0.32 |  |  | $ | 1.26 |  |  | $ | 1.14 |  |
| Discontinued operations |  | (0.13) |  |  | 0.10 |  |  | 2.08 |  |  | (0.05) |  |
| Net earnings (loss) |  | $ | 0.49 |  |  | $ | 0.42 |  |  | $ | 3.34 |  |  | $ | 1.09 |  |
| Weighted-average number of shares outstanding |  |  |  |  |  |  |  |  |
| Basic |  | 901.2 |  |  | 838.7 |  |  | 900.9 |  |  | 836.6 |  |
| Diluted |  | 915.0 |  |  | 854.7 |  |  | 914.4 |  |  | 852.7 |  |

[0001783180-24-000084:8k_2_02:66]
8

[0001783180-24-000084:8k_2_02:67]
Carrier Global Corporation

[0001783180-24-000084:8k_2_02:68]
Condensed Consolidated Balance Sheet

[0001783180-24-000084:8k_2_02:69]
|  |  | (Unaudited) |
| (In millions) |  | September 30, 2024 |  | December 31, 2023 |
| Assets |  |  |  |  |
| Cash and cash equivalents |  | $ | 2,225 |  |  | $ | 9,852 |  |
| Accounts receivable, net |  | 2,726 |  |  | 2,080 |  |
| Inventories, net |  | 2,646 |  |  | 1,823 |  |
| Assets held for sale |  | 2,680 |  |  | 5,093 |  |
| Other current assets |  | 917 |  |  | 728 |  |
| Total current assets |  | 11,194 |  |  | 19,576 |  |
| Future income tax benefits |  | 1,142 |  |  | 718 |  |
| Fixed assets, net |  | 3,015 |  |  | 2,160 |  |
| Operating lease right-of-use assets |  | 568 |  |  | 421 |  |
| Intangible assets, net |  | 7,118 |  |  | 945 |  |
| Goodwill |  | 15,294 |  |  | 7,520 |  |
| Pension and post-retirement assets |  | 54 |  |  | 32 |  |
| Equity method investments |  | 1,287 |  |  | 1,140 |  |
| Other assets |  | 529 |  |  | 310 |  |
| Total Assets |  | $ | 40,201 |  |  | $ | 32,822 |  |
| Liabilities and Equity |  |  |  |  |
| Accounts payable |  | $ | 2,829 |  |  | $ | 2,483 |  |
| Accrued liabilities |  | 4,233 |  |  | 2,997 |  |
| Liabilities held for sale |  | 1,221 |  |  | 1,450 |  |
| Current portion of long-term debt |  | 2,095 |  |  | 51 |  |
| Total current liabilities |  | 10,378 |  |  | 6,981 |  |
| Long-term debt |  | 10,337 |  |  | 14,242 |  |
| Future pension and post-retirement obligations |  | 209 |  |  | 149 |  |
| Future income tax obligations |  | 2,241 |  |  | 523 |  |
| Operating lease liabilities |  | 445 |  |  | 333 |  |
| Other long-term liabilities |  | 1,549 |  |  | 1,589 |  |
| Total Liabilities |  | 25,159 |  |  | 23,817 |  |
| Equity |  |  |  |  |
| Common stock |  | 9 |  |  | 9 |  |
| Treasury stock |  | (2,403) |  |  | (1,972) |  |
| Additional paid-in capital |  | 8,588 |  |  | 5,535 |  |
| Retained earnings |  | 9,301 |  |  | 6,591 |  |
| Accumulated other comprehensive loss |  | (802) |  |  | (1,486) |  |
| Non-controlling interest |  | 349 |  |  | 328 |  |
| Total Equity |  | 15,042 |  |  | 9,005 |  |
| Total Liabilities and Equity |  | $ | 40,201 |  |  | $ | 32,822 |  |

[0001783180-24-000084:8k_2_02:70]
9

[0001783180-24-000084:8k_2_02:71]
Carrier Global Corporation

[0001783180-24-000084:8k_2_02:72]
Condensed Consolidated Statement of Cash Flows

[0001783180-24-000084:8k_2_02:73]
(Unaudited)

[0001783180-24-000084:8k_2_02:74]
|  |  | Nine Months Ended September 30, |
| (In millions) |  | 2024 |  | 2023 |
| Operating Activities |  |  |  |  |
| Net earnings (loss) |  | $ | 3,139 |  |  | $ | 1,001 |  |
| Discontinued operations, net of tax |  | (1,897) |  |  | 41 |  |
| Adjustments for non-cash items, net: |  |  |  |  |
| Depreciation and amortization |  | 914 |  |  | 368 |  |
| Deferred income tax provision |  | (296) |  |  | (150) |  |
| Stock-based compensation costs |  | 65 |  |  | 55 |  |
| Equity method investment net earnings |  | (187) |  |  | (171) |  |
| (Gain) loss on extinguishment of debt |  | (88) |  |  | — |  |
| (Gain) loss on sale of investments / deconsolidation |  | (2) |  |  | (19) |  |
| Changes in operating assets and liabilities |  |  |  |  |
| Accounts receivable, net |  | (135) |  |  | (279) |  |
| Inventories, net |  | 76 |  |  | (72) |  |
| Accounts payable and accrued liabilities |  | (247) |  |  | 622 |  |
| Distributions from equity method investments |  | 36 |  |  | 45 |  |
| Other operating activities, net |  | (260) |  |  | (96) |  |
| Preliminary net cash flows provided by (used in) continuing operating activities |  | 1,118 |  |  | 1,345 |  |
| Preliminary net cash flows provided by (used in) discontinued operating activities |  | (687) |  |  | 200 |  |
| Preliminary net cash flows provided by (used in) operating activities |  | 431 |  |  | 1,545 |  |
| Investing Activities |  |  |  |  |
| Capital expenditures |  | (302) |  |  | (217) |  |
| Investment in businesses, net of cash acquired |  | (10,873) |  |  | (69) |  |
| Dispositions of businesses |  | — |  |  | 54 |  |
| Settlement of derivative contracts, net |  | (187) |  |  | (66) |  |
| Other investing activities, net |  | 31 |  |  | 14 |  |
| Net cash flows provided by (used in) continuing investing activities |  | (11,331) |  |  | (284) |  |
| Net cash flows provided by (used in) discontinued investing activities |  | 6,217 |  |  | (147) |  |
| Net cash flows provided by (used in) investing activities |  | (5,114) |  |  | (431) |  |
| Financing Activities |  |  |  |  |
| Increase (decrease) in short-term borrowings, net |  | 37 |  |  | (27) |  |
| Issuance of long-term debt |  | 2,586 |  |  | 14 |  |
| Repayment of long-term debt |  | (4,530) |  |  | (15) |  |
| Repurchases of common stock |  | (431) |  |  | (62) |  |
| Dividends paid on common stock |  | (514) |  |  | (465) |  |
| Dividends paid to non-controlling interest |  | (72) |  |  | (46) |  |
| Other financing activities, net |  | (15) |  |  | (72) |  |
| Net cash flows provided by (used in) continuing financing activities |  | (2,939) |  |  | (673) |  |
| Net cash flows provided by (used in) discontinued financing activities |  | (11) |  |  | (15) |  |
| Net cash flows provided by (used in) financing activities |  | (2,950) |  |  | (688) |  |
| Effect of foreign exchange rate changes on cash and cash equivalents |  | (18) |  |  | (45) |  |
| Net increase (decrease) in cash and cash equivalents and restricted cash, including cash classified in current assets held for sale |  | (7,651) |  |  | 381 |  |
| Less: Change in cash balances classified as assets held for sale |  | (36) |  |  | (5) |  |
| Net increase (decrease) in cash and cash equivalents and restricted cash |  | (7,615) |  |  | 386 |  |
| Cash, cash equivalents and restricted cash, beginning of period |  | 9,854 |  |  | 3,303 |  |
| Cash, cash equivalents and restricted cash, end of period |  | 2,239 |  |  | 3,689 |  |
| Less: restricted cash |  | 14 |  |  | 4 |  |
| Cash and cash equivalents, end of period |  | $ | 2,225 |  |  | $ | 3,685 |  |

[0001783180-24-000084:8k_2_02:75]
10

[0001783180-24-000084:8k_2_02:76]
Carrier Global Corporation

[0001783180-24-000084:8k_2_02:77]
Segment Net Sales and Operating Profit

[0001783180-24-000084:8k_2_02:78]
|  | (Unaudited) |
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| (In millions) | Reported |  | Adjusted |  | Reported |  | Adjusted |  | Reported |  | Adjusted |  | Reported |  | Adjusted |
| Net sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| HVAC | $ | 5,058 |  | $ | 5,058 |  | $ | 4,008 |  | $ | 4,008 |  | $ | 14,569 |  | $ | 14,569 |  | $ | 11,846 |  | $ | 11,846 |
| Refrigeration | 938 |  | 938 |  | 924 |  | 924 |  | 2,795 |  | 2,795 |  | 2,794 |  | 2,794 |
| Segment sales | 5,996 |  | 5,996 |  | 4,932 |  | 4,932 |  | 17,364 |  | 17,364 |  | 14,640 |  | 14,640 |
| Eliminations and other | (12) |  | (12) |  | 3 |  | 3 |  | (26) |  | (26) |  | (5) |  | (5) |
| Net sales | $ | 5,984 |  | $ | 5,984 |  | $ | 4,935 |  | $ | 4,935 |  | $ | 17,338 |  | $ | 17,338 |  | $ | 14,635 |  | $ | 14,635 |
| Operating profit |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| HVAC | $ | 741 |  | $ | 1,001 |  | $ | 763 |  | $ | 833 |  | $ | 1,857 |  | $ | 2,712 |  | $ | 1,940 |  | $ | 2,114 |
| Refrigeration | 109 |  | 117 |  | 107 |  | 111 |  | 319 |  | 334 |  | 327 |  | 341 |
| Segment operating profit | 850 |  | 1,118 |  | 870 |  | 944 |  | 2,176 |  | 3,046 |  | 2,267 |  | 2,455 |
| Eliminations and other | (25) |  | (23) |  | (252) |  | 6 |  | (84) |  | (38) |  | (399) |  | (28) |
| General corporate expenses | (62) |  | (51) |  | (108) |  | (73) |  | (220) |  | (144) |  | (247) |  | (189) |
| Operating profit | $ | 763 |  | $ | 1,044 |  | $ | 510 |  | $ | 877 |  | $ | 1,872 |  | $ | 2,864 |  | $ | 1,621 |  | $ | 2,238 |
| Operating margin |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| HVAC | 14.7 | % |  | 19.8 | % |  | 19.0 | % |  | 20.8 | % |  | 12.7 | % |  | 18.6 | % |  | 16.4 | % |  | 17.8 | % |
| Refrigeration | 11.6 | % |  | 12.5 | % |  | 11.6 | % |  | 12.0 | % |  | 11.4 | % |  | 11.9 | % |  | 11.7 | % |  | 12.2 | % |
| Total Carrier | 12.8 | % |  | 17.4 | % |  | 10.3 | % |  | 17.8 | % |  | 10.8 | % |  | 16.5 | % |  | 11.1 | % |  | 15.3 | % |

[0001783180-24-000084:8k_2_02:79]
11

[0001783180-24-000084:8k_2_02:80]
Carrier Global Corporation

[0001783180-24-000084:8k_2_02:81]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP)

[0001783180-24-000084:8k_2_02:82]
Operating Profit

[0001783180-24-000084:8k_2_02:83]
|  | (Unaudited) |
|  | Three Months Ended September 30, 2024 |
| (In millions) | HVAC |  | Refrigeration |  | Eliminations and Other |  | General Corporate Expenses |  | Carrier |
| Net sales | $ | 5,058 |  |  | $ | 938 |  |  | $ | (12) |  |  | $ | — |  |  | $ | 5,984 |  |
| Segment operating profit | $ | 741 |  |  | $ | 109 |  |  | $ | (25) |  |  | $ | (62) |  |  | $ | 763 |  |
| Reported operating margin | 14.7 | % |  | 11.6 | % |  |  |  |  |  | 12.8 | % |
| Adjustments to segment operating profit: |  |  |  |  |  |  |  |  |  |
| Restructuring costs | $ | 54 |  |  | $ | 4 |  |  | $ | 2 |  |  | $ | — |  |  | $ | 60 |  |
| Amortization of acquired intangibles | 175 |  |  | — |  |  | — |  |  | — |  |  | 175 |  |
| Acquisition step-up amortization (1) | 31 |  |  | — |  |  | — |  |  | — |  |  | 31 |  |
| Acquisition/divestiture-related costs | — |  |  | 4 |  |  | — |  |  | 11 |  |  | 15 |  |
| Total adjustments to operating profit | $ | 260 |  |  | $ | 8 |  |  | $ | 2 |  |  | $ | 11 |  |  | $ | 281 |  |
| Adjusted operating profit | $ | 1,001 |  |  | $ | 117 |  |  | $ | (23) |  |  | $ | (51) |  |  | $ | 1,044 |  |
| Adjusted operating margin | 19.8 | % |  | 12.5 | % |  |  |  |  |  | 17.4 | % |

[0001783180-24-000084:8k_2_02:84]
|  | (Unaudited) |
|  | Three Months Ended September 30, 2023 |
| (In millions) | HVAC |  | Refrigeration |  | Eliminations and Other |  | General Corporate Expenses |  | Carrier |
| Net sales | $ | 4,008 |  |  | $ | 924 |  |  | $ | 3 |  |  | $ | — |  |  | $ | 4,935 |  |
| Segment operating profit | $ | 763 |  |  | $ | 107 |  |  | $ | (252) |  |  | $ | (108) |  |  | $ | 510 |  |
| Reported operating margin | 19.0 | % |  | 11.6 | % |  |  |  |  |  | 10.3 | % |
| Adjustments to segment operating profit: |  |  |  |  |  |  |  |  |  |
| Restructuring costs | $ | 25 |  |  | $ | 4 |  |  | $ | — |  |  | $ | — |  |  | $ | 29 |  |
| Amortization of acquired intangibles | 35 |  |  | — |  |  | — |  |  | — |  |  | 35 |  |
| Acquisition step-up amortization (1) | 10 |  |  | — |  |  | — |  |  | — |  |  | 10 |  |
| Acquisition/divestiture-related costs | — |  |  | — |  |  | — |  |  | 35 |  |  | 35 |  |
| Bridge loan financing costs | — |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Viessmann-related hedges | — |  |  | — |  |  | 257 |  |  | — |  |  | 257 |  |
| Total adjustments to operating profit | $ | 70 |  |  | $ | 4 |  |  | $ | 258 |  |  | $ | 35 |  |  | $ | 367 |  |
| Adjusted operating profit | $ | 833 |  |  | $ | 111 |  |  | $ | 6 |  |  | $ | (73) |  |  | $ | 877 |  |
| Adjusted operating margin | 20.8 | % |  | 12.0 | % |  |  |  |  |  | 17.8 | % |

[0001783180-24-000084:8k_2_02:85]
(1)  Amortization of the step-up to fair value of acquired inventory and backlog.

[0001783180-24-000084:8k_2_02:86]
12

[0001783180-24-000084:8k_2_02:87]
Carrier Global Corporation

[0001783180-24-000084:8k_2_02:88]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP)

[0001783180-24-000084:8k_2_02:89]
Operating Profit

[0001783180-24-000084:8k_2_02:90]
|  | (Unaudited) |
|  | Nine Months Ended September 30, 2024 |
| (In millions) | HVAC |  | Refrigeration |  | Eliminations and Other |  | General Corporate Expenses |  | Carrier |
| Net sales | $ | 14,569 |  |  | $ | 2,795 |  |  | $ | (26) |  |  | $ | — |  |  | $ | 17,338 |  |
| Segment operating profit | $ | 1,857 |  |  | $ | 319 |  |  | $ | (84) |  |  | $ | (220) |  |  | $ | 1,872 |  |
| Reported operating margin | 12.7 | % |  | 11.4 | % |  |  |  |  |  | 10.8 | % |
| Adjustments to segment operating profit: |  |  |  |  |  |  |  |  |  |
| Restructuring costs | $ | 86 |  |  | $ | 5 |  |  | $ | 6 |  |  | $ | — |  |  | $ | 97 |  |
| Amortization of acquired intangibles | 517 |  |  | — |  |  | — |  |  | — |  |  | 517 |  |
| Acquisition step-up amortization (1) | 251 |  |  | — |  |  | — |  |  | — |  |  | 251 |  |
| Acquisition/divestiture-related costs | 1 |  |  | 10 |  |  | — |  |  | 76 |  |  | 87 |  |
| Viessmann-related hedges | — |  |  | — |  |  | 86 |  |  | — |  |  | 86 |  |
| Gain on liability adjustment (2) | — |  |  | — |  |  | (46) |  |  | — |  |  | (46) |  |
| Total adjustments to operating profit | $ | 855 |  |  | $ | 15 |  |  | $ | 46 |  |  | $ | 76 |  |  | $ | 992 |  |
| Adjusted operating profit | $ | 2,712 |  |  | $ | 334 |  |  | $ | (38) |  |  | $ | (144) |  |  | $ | 2,864 |  |
| Adjusted operating margin | 18.6 | % |  | 11.9 | % |  |  |  |  |  | 16.5 | % |

[0001783180-24-000084:8k_2_02:91]
|  | (Unaudited) |
|  | Nine Months Ended September 30, 2023 |
| (In millions) | HVAC |  | Refrigeration |  | Eliminations and Other |  | General Corporate Expenses |  | Carrier |
| Net sales | $ | 11,846 |  |  | $ | 2,794 |  |  | $ | (5) |  |  | $ | — |  |  | $ | 14,635 |  |
| Segment operating profit | $ | 1,940 |  |  | $ | 327 |  |  | $ | (399) |  |  | $ | (247) |  |  | $ | 1,621 |  |
| Reported operating margin | 16.4 | % |  | 11.7 | % |  |  |  |  |  | 11.1 | % |
| Adjustments to segment operating profit: |  |  |  |  |  |  |  |  |  |
| Restructuring costs | $ | 27 |  |  | $ | 14 |  |  | $ | 2 |  |  | $ | — |  |  | $ | 43 |  |
| Amortization of acquired intangibles | 108 |  |  | — |  |  | — |  |  | — |  |  | 108 |  |
| Acquisition step-up amortization (1) | 31 |  |  | — |  |  | — |  |  | — |  |  | 31 |  |
| Acquisition/divestiture-related costs | — |  |  | — |  |  | — |  |  | 58 |  |  | 58 |  |
| Bridge loan financing costs | — |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Viessmann-related hedges | — |  |  | — |  |  | 368 |  |  | — |  |  | 368 |  |
| TCC acquisition-related gain (3) | 8 |  |  | — |  |  | — |  |  | — |  |  | 8 |  |
| Total adjustments to operating profit | $ | 174 |  |  | $ | 14 |  |  | $ | 371 |  |  | $ | 58 |  |  | $ | 617 |  |
| Adjusted operating profit | $ | 2,114 |  |  | $ | 341 |  |  | $ | (28) |  |  | $ | (189) |  |  | $ | 2,238 |  |
| Adjusted operating margin | 17.8 | % |  | 12.2 | % |  |  |  |  |  | 15.3 | % |

[0001783180-24-000084:8k_2_02:92]
(1)  Amortization of the step-up to fair value of acquired inventory and backlog.

[0001783180-24-000084:8k_2_02:93]
(2) Gain associated with an adjustment to our tax-related liability owed to UTC.

[0001783180-24-000084:8k_2_02:94]
(3)  The carrying value of our previously held TCC equity investments were recognized at fair value and subsequently adjusted.

[0001783180-24-000084:8k_2_02:95]
13

[0001783180-24-000084:8k_2_02:96]
Carrier Global Corporation

[0001783180-24-000084:8k_2_02:97]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP) Results

[0001783180-24-000084:8k_2_02:98]
Net Income, Earnings Per Share and Effective Tax Rate

[0001783180-24-000084:8k_2_02:99]
|  | (Unaudited) |
|  | Three Months Ended September 30, 2024 |  | Nine Months Ended September 30, 2024 |
| (In millions, except per share amounts) | Reported |  | Adjustments |  | Adjusted |  | Reported |  | Adjustments |  | Adjusted |
| Net sales | $ | 5,984 |  |  | $ | — |  |  | $ | 5,984 |  |  | $ | 17,338 |  |  | $ | — |  |  | $ | 17,338 |  |
| Operating profit | $ | 763 |  |  | 281 |  | a | $ | 1,044 |  |  | $ | 1,872 |  |  | 992 |  | a | $ | 2,864 |  |
| Operating margin | 12.8 | % |  |  |  | 17.4 | % |  | 10.8 | % |  |  |  | 16.5 | % |
| Earnings before income taxes | $ | 770 |  |  | 195 |  | a,b | $ | 965 |  |  | $ | 1,581 |  |  | 918 |  | a,b | $ | 2,499 |  |
| Income tax (expense) benefit | $ | (172) |  |  | (54) |  | c | $ | (226) |  |  | $ | (339) |  |  | (227) |  | c | $ | (566) |  |
| Effective tax rate | 22.3 | % |  |  |  | 23.4 | % |  | 21.4 | % |  |  |  | 22.6 | % |
| Earnings from continuing operations attributable to common shareowners | $ | 564 |  |  | $ | 141 |  |  | $ | 705 |  |  | $ | 1,156 |  |  | $ | 691 |  |  | $ | 1,847 |  |
| Summary of Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring costs |  |  | $ | 60 |  | a |  |  |  |  | $ | 97 |  | a |  |
| Amortization of acquired intangibles |  |  | 175 |  | a |  |  |  |  | 517 |  | a |  |
| Acquisition step-up amortization (1) |  |  | 31 |  | a |  |  |  |  | 251 |  | a |  |
| Acquisition/divestiture-related costs |  |  | 15 |  | a |  |  |  |  | 87 |  | a |  |
| Viessmann-related hedges |  |  | — |  | a |  |  |  |  | 86 |  | a |  |
| Gain on liability adjustment (2) |  |  | — |  | a |  |  |  |  | (46) |  | a |  |
| Debt extinguishment (gain) |  |  | (97) |  | b |  |  |  |  | (97) |  | b |  |
| Debt prepayment costs |  |  | 11 |  | b |  |  |  |  | 23 |  | b |  |
| Total adjustments |  |  | $ | 195 |  |  |  |  |  |  | $ | 918 |  |  |  |
| Tax effect on adjustments above |  |  | $ | (54) |  |  |  |  |  |  | $ | (227) |  |  |  |
| Tax specific adjustments |  |  | — |  |  |  |  |  |  | — |  |  |  |
| Total tax adjustments |  |  | $ | (54) |  | c |  |  |  |  | $ | (227) |  | c |  |
| Diluted shares outstanding | 915.0 |  |  |  |  | 915.0 |  |  | 914.4 |  |  |  |  | 914.4 |  |
| Diluted earnings per share: |  |  |  |  |  |  |  |  |  |  |  |
| Continuing operations | $ | 0.62 |  |  |  |  | $ | 0.77 |  |  | $ | 1.26 |  |  |  |  | $ | 2.02 |  |

[0001783180-24-000084:8k_2_02:100]
(1)  Amortization of the step-up to fair value of acquired inventory and backlog.

[0001783180-24-000084:8k_2_02:101]
(2) Gain associated with an adjustment to our tax-related liability owed to UTC.

[0001783180-24-000084:8k_2_02:102]
14

[0001783180-24-000084:8k_2_02:103]
Carrier Global Corporation

[0001783180-24-000084:8k_2_02:104]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP) Results

[0001783180-24-000084:8k_2_02:105]
Net Income, Earnings Per Share and Effective Tax Rate

[0001783180-24-000084:8k_2_02:106]
|  | (Unaudited) |
|  | Three Months Ended September 30, 2023 |  | Nine Months Ended September 30, 2023 |
| (In millions, except per share amounts) | Reported |  | Adjustments |  | Adjusted |  | Reported |  | Adjustments |  | Adjusted |
| Net sales | $ | 4,935 |  |  | $ | — |  |  | $ | 4,935 |  |  | $ | 14,635 |  |  | $ | — |  |  | $ | 14,635 |  |
| Operating profit | $ | 510 |  |  | 367 |  | a | $ | 877 |  |  | $ | 1,621 |  |  | 617 |  | a | $ | 2,238 |  |
| Operating margin | 10.3 | % |  |  |  | 17.8 | % |  | 11.1 | % |  |  |  | 15.3 | % |
| Earnings before income taxes | $ | 471 |  |  | 378 |  | a,b | $ | 849 |  |  | $ | 1,495 |  |  | 649 |  | a,b | $ | 2,144 |  |
| Income tax (expense) benefit | $ | (177) |  |  | (10) |  | c | $ | (187) |  |  | $ | (453) |  |  | (44) |  | c | $ | (497) |  |
| Effective tax rate | 37.6 | % |  |  |  | 22.0 | % |  | 30.3 | % |  |  |  | 23.2 | % |
| Earnings from continuing operations attributable to common shareowners | $ | 270 |  |  | $ | 368 |  |  | $ | 638 |  |  | $ | 970 |  |  | $ | 605 |  |  | $ | 1,575 |  |
| Summary of Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring costs |  |  | $ | 29 |  | a |  |  |  |  | $ | 43 |  | a |  |
| Amortization of acquired intangibles |  |  | 35 |  | a |  |  |  |  | 108 |  | a |  |
| Acquisition step-up amortization (1) |  |  | 10 |  | a |  |  |  |  | 31 |  | a |  |
| Acquisition/divestiture-related costs |  |  | 35 |  | a |  |  |  |  | 58 |  | a |  |
| Viessmann-related hedges |  |  | 257 |  | a |  |  |  |  | 368 |  | a |  |
| TCC acquisition-related gain (2) |  |  | — |  | a |  |  |  |  | 8 |  | a |  |
| Bridge loan financing costs (3) |  |  | 12 |  | a,b |  |  |  |  | 33 |  | a,b |  |
| Total adjustments |  |  | $ | 378 |  |  |  |  |  |  | $ | 649 |  |  |  |
| Tax effect on adjustments above |  |  | $ | (29) |  |  |  |  |  |  | $ | (63) |  |  |  |
| Tax specific adjustments |  |  | 19 |  |  |  |  |  |  | 19 |  |  |  |
| Total tax adjustments |  |  | $ | (10) |  | c |  |  |  |  | $ | (44) |  | c |  |
| Diluted shares outstanding | 854.7 |  |  |  |  | 854.7 |  |  | 852.7 |  |  |  |  | 852.7 |  |
| Diluted earnings per share: |  |  |  |  |  |  |  |  |  |  |  |
| Continuing operations | $ | 0.32 |  |  |  |  | $ | 0.75 |  |  | $ | 1.14 |  |  |  |  | $ | 1.85 |  |

[0001783180-24-000084:8k_2_02:107]
(1) Amortization of the step-up to fair value of acquired inventory and backlog.

[0001783180-24-000084:8k_2_02:108]
(2) The carrying value of our previously held TCC equity investments were recognized at fair value at the TCC acquisition date.

[0001783180-24-000084:8k_2_02:109]
(3)  Includes commitment fees recognized in Selling, general and administrative.

[0001783180-24-000084:8k_2_02:110]
15

[0001783180-24-000084:8k_2_02:111]
Carrier Global Corporation

[0001783180-24-000084:8k_2_02:112]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP) Results

[0001783180-24-000084:8k_2_02:113]
Components of Changes in Net Sales

[0001783180-24-000084:8k_2_02:114]
| Three Months Ended September 30, 2024 Compared with Three Months Ended September 30, 2023 |
|  | (Unaudited) |
|  | Factors Contributing to Total % change in Net Sales |
|  | Organic |  | FX Translation |  | Acquisitions / Divestitures, net |  | Other |  | Total |
| HVAC | 6 | % |  | — | % |  | 20 | % |  | — | % |  | 26 | % |
| Refrigeration | 1 | % |  | — | % |  | — | % |  | — | % |  | 1 | % |
| Consolidated | 4 | % |  | — | % |  | 17 | % |  | — | % |  | 21 | % |

[0001783180-24-000084:8k_2_02:115]
| Nine Months Ended September 30, 2024 Compared with Nine Months Ended September 30, 2023 |
|  | (Unaudited) |
|  | Factors Contributing to Total % change in Net Sales |
|  | Organic |  | FX Translation |  | Acquisitions / Divestitures, net |  | Other |  | Total |
| HVAC | 3 | % |  | — | % |  | 20 | % |  | — | % |  | 23 | % |
| Refrigeration | — | % |  | — | % |  | — | % |  | — | % |  | — | % |
| Consolidated | 2 | % |  | (1) | % |  | 17 | % |  | — | % |  | 18 | % |

[0001783180-24-000084:8k_2_02:116]
Preliminary Free Cash Flow Reconciliation

[0001783180-24-000084:8k_2_02:117]
|  |  | (Unaudited) |
|  |  | Nine Months Ended September 30, |
| (In millions) |  | 2024 |  | 2023 |
| Preliminary net cash flows provided by (used in) operating activities |  | $ | 431 |  |  | $ | 1,545 |  |
| Less: Capital expenditures (1) |  | 312 |  |  | 236 |  |
| Free cash flow |  | $ | 119 |  |  | $ | 1,309 |  |

[0001783180-24-000084:8k_2_02:118]
(1) Includes $10 million and $19 million of capital expenditures related to discontinued operations, respectively.

[0001783180-24-000084:8k_2_02:119]
Net Debt Reconciliation

[0001783180-24-000084:8k_2_02:120]
|  |  | (Unaudited) |
| (In millions) |  | September 30, 2024 |  | December 31, 2023 |
| Long-term debt |  | $ | 10,337 |  |  | $ | 14,242 |  |
| Current portion of long-term debt |  | 2,095 |  |  | 51 |  |
| Less: Cash and cash equivalents |  | 2,225 |  |  | 9,852 |  |
| Net debt |  | $ | 10,207 |  |  | $ | 4,441 |  |

[0001783180-24-000084:8k_2_02:121]
Carrier Global Corporation

[0001783180-24-000084:8k_2_02:122]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP) Results

[0001783180-24-000084:8k_2_02:123]
Discontinued operations, net of tax Reconciliation

[0001783180-24-000084:8k_2_02:124]
|  |  | (Unaudited) |
|  |  | Three Months Ended September 30, |
| (In millions, except per share amounts) |  | 2024 |
| Discontinued operations, net of tax |  | $ | (117) |  |
| Summary of adjustments, net of tax: |  |  |
| Divestiture-related costs |  | $ | 33 |  |
| Gain on sale of Industrial business |  | (310) |  |
| AFFF legal reserve |  | 420 |  |
| Tax specific adjustments |  | 26 |  |
| Total adjustments |  | $ | 169 |  |
| Adjusted Discontinued operations, net of tax |  | $ | 52 |  |
| Adjusted diluted earnings per share |  | $ | 0.06 |  |

[0001783180-24-000084:8k_2_02:125]
Diluted EPS Reconciliation - Adjusted

[0001783180-24-000084:8k_2_02:126]
|  |  | (Unaudited) |
|  |  | Three Months Ended September 30, |
|  |  | 2024 |
| Continuing operations |  | $ | 0.77 |  |
| Discontinued operations |  | 0.06 |  |
| Total |  | $ | 0.83 |  |

[0001783180-24-000084:8k_2_02:127]
17
