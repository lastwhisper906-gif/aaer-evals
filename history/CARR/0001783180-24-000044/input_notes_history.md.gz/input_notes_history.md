# CARR note change history — 0001783180-23-000065 → 0001783180-24-000044


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-04-25):
[0001783180-24-000044:note_history:1]
COMMITMENTS AND CONTINGENT LIABILITIES
The Company is involved in various litigation, claims and administrative proceedings, including those related to environmental (including asbestos) and legal matters. In accordance with ASC 450, Contingencies, the Company records accruals for loss contingencies when it is probable that a liability has been incurred and the amount of the loss can be reasonably estimated. These accruals are generally based upon a range of possible outcomes. If no amount within the range is a better estimate than any other, the Company accrues the minimum amount. In addition, these estimates are reviewed periodically and adjusted to reflect additional information when it becomes available. The Company is unable to predict the final outcome of the following matters based on the information currently available, except as otherwise noted. However, the Company does not believe that the resolution of any of these matters will have a material adverse effect upon its results of operations or financial condition.
  (was, 2023-10-26, similarity 0.9942):
[0001783180-23-000065:note_history:1]
COMMITMENTS AND CONTINGENT LIABILITIES
The Company is involved in various litigation, claims and administrative proceedings, including those related to environmental (including asbestos) and legal matters. In accordance with ASC 450, Contingencies, the Company records accruals for loss contingencies when it is probable that a liability has been incurred and the amount of the loss can be reasonably estimated. These accruals are generally based upon a range of possible outcomes. If no amount within the range is a better estimate than any other, the Company accrues the minimum amount. In addition, these estimates are reviewed periodically and adjusted to reflect additional information when it becomes available. The Company is unable to predict the final outcome of the following matters based on the information currently available, except as otherwise noted. However, the Company does not believe that the resolution of any of these matters will have a material adverse effect upon its results of operations, cash flows or financial condition.

- changed (2024-04-25):
[0001783180-24-000044:note_history:2]
| (In millions) |  | March 31,2024 |  | December 31,2023 |
| Environmental reserves included in Accrued liabilities |  | $ | 19 |  |  | $ | 21 |  |
| Environmental reserves included in Other long-term liabilities |  | 201 |  |  | 203 |  |
| Total Environmental reserves |  | $ | 220 |  |  | $ | 224 |  |
  (was, 2023-10-26, similarity 0.974):
[0001783180-23-000065:note_history:2]
| (In millions) |  | September 30,2023 |  | December 31,2022 |
| Environmental reserves included in Accrued liabilities |  | $ | 12 |  |  | $ | 24 |  |
| Environmental reserves included in Other long-term liabilities |  | 208 |  |  | 211 |  |
| Total Environmental reserves |  | $ | 220 |  |  | $ | 235 |  |

- changed (2024-04-25):
[0001783180-24-000044:note_history:3]
| (In millions) |  | March 31,2024 |  | December 31,2023 |
| Asbestos liabilities included in Accrued liabilities |  | $ | 15 |  |  | $ | 15 |  |
| Asbestos liabilities included in Other long-term liabilities |  | 203 |  |  | 206 |  |
| Total Asbestos liabilities |  | $ | 218 |  |  | $ | 221 |  |
| Asbestos-related recoveries included in Other assets, current |  | $ | 5 |  |  | $ | 5 |  |
| Asbestos-related recoveries included in Other assets |  | 87 |  |  | 88 |  |
| Total Asbestos-related recoveries |  | $ | 92 |  |  | $ | 93 |  |
  (was, 2023-10-26, similarity 0.9877):
[0001783180-23-000065:note_history:3]
| (In millions) |  | September 30,2023 |  | December 31,2022 |
| Asbestos liabilities included in Accrued liabilities |  | $ | 16 |  |  | $ | 16 |  |
| Asbestos liabilities included in Other long-term liabilities |  | 207 |  |  | 212 |  |
| Total Asbestos liabilities |  | $ | 223 |  |  | $ | 228 |  |
| Asbestos-related recoveries included in Other assets, current |  | $ | 5 |  |  | $ | 5 |  |
| Asbestos-related recoveries included in Other assets |  | 89 |  |  | 90 |  |
| Total Asbestos-related recoveries |  | $ | 94 |  |  | $ | 95 |  |

- changed (2024-04-25):
[0001783180-24-000044:note_history:4]
As of March 31, 2024, the Company, KFI and others have been named as defendants in more than 7,000 lawsuits filed by individuals in or removed to the federal courts of the United States alleging that the historic use of Aqueous Film Forming Foam ("AFFF") caused personal injuries and/or property damage. The Company, KFI and others have also been named as defendants in more than 800 lawsuits filed by several U.S. states, municipalities and water utilities in or removed to U.S. federal courts alleging that the historic use of AFFF caused contamination of property and water supplies. In December 2018, the U.S. Judicial Panel on Multidistrict Litigation transferred and consolidated all AFFF cases pending in the U.S. federal courts against the Company, KFI and others to the U.S. District Court for the District of South Carolina (the "MDL Proceedings"). The individual plaintiffs in the MDL Proceedings generally seek damages for alleged personal injuries, medical monitoring, diminution in property value and injunctive relief to remediate alleged contamination of water supplies. The U.S. state, municipal and water utility plaintiffs in the MDL Proceedings generally seek damages and costs related to the remediation of public property and water supplies.
  (was, 2023-10-26, similarity 0.9944):
[0001783180-23-000065:note_history:4]
As of September 30, 2023, the Company, KFI and others have been named as defendants in more than 5,000 lawsuits filed by individuals in or removed to the federal courts of the United States alleging that the historic use of Aqueous Film Forming Foam ("AFFF") caused personal injuries and/or property damage. The Company, KFI and others have also been named as defendants in more than 600 lawsuits filed by several U.S. states, municipalities and water utilities in or removed to U.S. federal courts alleging that the historic use of AFFF caused contamination of property and water supplies. In December 2018, the U.S. Judicial Panel on Multidistrict Litigation transferred and consolidated all AFFF cases pending in the U.S. federal courts against the Company, KFI and others to the U.S. District Court for the District of South Carolina (the "MDL Proceedings"). The individual plaintiffs in the MDL Proceedings generally seek damages for alleged personal injuries, medical monitoring, diminution in property value and injunctive relief to remediate alleged contamination of water supplies. The U.S. state, municipal and water utility plaintiffs in the MDL Proceedings generally seek damages and costs related to the remediation of public property and water supplies.

- changed (2024-04-25):
[0001783180-24-000044:note_history:5]
On September 23, 2022, after completion of discovery, the MDL court selected one water provider case, the City of Stuart, FL v. 3M, et al., for a bellwether trial. That trial was scheduled to begin in early June 2023 but was postponed indefinitely. The MDL court ordered that the bellwether process for personal injury cases to begin in 2023. However, the court has not yet outlined details on that process or its timing.
  (was, 2023-10-26, similarity 0.9815):
[0001783180-23-000065:note_history:5]
On September 23, 2022, after completion of discovery, the MDL court selected one water provider case, the City of Stuart, FL v. 3M, et al., for a bellwether trial. That trial was scheduled to begin in early June 2023 but was postponed indefinitely. The MDL court ordered that the bellwether process for personal injury cases will begin in 2023. The court has not yet outlined details on that process or its timing.

- changed (2024-04-25):
[0001783180-24-000044:note_history:6]
On May 14, 2023, KFI filed a voluntary petition with the United States Bankruptcy Court for the District of Delaware seeking relief under Chapter 11 of the Bankruptcy Code after the Company determined that it would not provide financial support to KFI going forward, other than ensuring KFI has access to services necessary for the effective operation of its business. As a result, all litigation against KFI is automatically stayed. KFI filed an adversary complaint and motion in the Chapter 11 case seeking an order staying or enjoining all AFFF-related litigation against the Company, its other subsidiaries and RTX. That motion was resolved through an agreement that effectively stays the AFFF litigation against these parties. KFI has also indicated to the bankruptcy court that it intends to pursue insurance coverage for AFFF-related liabilities and contractual indemnification for AFFF-related liabilities from the third party to which KFI sold National Foam. On November 21, 2023, the bankruptcy court ordered certain parties, including the Company, to participate in a mediation with respect to claims that might be asserted by and against it in the bankruptcy proceedings. The parties have engaged in several mediation sessions and anticipate further sessions in the future. The terms and scope of any potential settlement may be affected by, among other factors, the bankruptcy court’s ability to approve nonconsensual releases of litigation claims against non-debtors, which the United States Supreme Court is expected to decide in Harrington v. Purdue Pharma, L.P.
  (was, 2023-10-26, similarity 0.7602):
[0001783180-23-000065:note_history:6]
On May 14, 2023, KFI filed a voluntary petition with the United States Bankruptcy Court for the District of Delaware seeking relief under Chapter 11 of the Bankruptcy Code after the Company determined that it would not provide financial support to KFI going forward, other than ensuring KFI has access to services necessary for the effective operation of its business. As a result, all litigation against KFI is automatically stayed. KFI filed an adversary complaint and motion in the Chapter 11 case seeking an order staying or enjoining all AFFF-related litigation against the Company, its other subsidiaries and RTX. That motion was resolved through an agreement that effectively stays the AFFF litigation against these parties. KFI has also indicated to the bankruptcy court that it intends to pursue insurance coverage for AFFF-related liabilities and contractual indemnification for AFFF-related liabilities from the third party to which KFI sold National Foam.

- changed (2024-04-25):
[0001783180-24-000044:note_history:7]
As of May 14, 2023, the Company no longer controlled KFI as their activities are subject to review and oversight by the bankruptcy court. Therefore, KFI was deconsolidated and their respective assets and liabilities were derecognized from the Company’s Unaudited Condensed Consolidated Financial Statements. Upon deconsolidation, the Company determined the fair value of its retained interest in KFI to be zero and will account for it prospectively using the cost method. As a result of these actions, the Company recognized a loss of $297 million in its Unaudited Condensed Consolidated Statement of Operations within Other income/(expense), net. In addition, the deconsolidation resulted in an investing cash outflow of $134 million in the Company's Unaudited Condensed Consolidated Statement of Cash Flows.
  (was, 2023-10-26, similarity 0.8396):
[0001783180-23-000065:note_history:7]
As of May 14, 2023, the Company no longer controlled KFI as their activities are subject to review and oversight by the bankruptcy court. Therefore, KFI was deconsolidated and their respective assets and liabilities were derecognized from the Company’s Unaudited Condensed Consolidated Financial Statements. Upon deconsolidation, the Company determined the fair value of its retained interest in KFI to be zero and will account for it prospectively using the cost method. As a result of these actions, the Company recognized a loss of $297 million in its Unaudited Condensed Consolidated Statements of Operations

- changed (2024-04-25):
[0001783180-24-000044:note_history:8]
In connection with the bankruptcy filing, KFI entered into several agreements with subsidiaries of the Company to ensure they have access to services necessary for the effective operation of their business. All post-deconsolidation activity between the Company and KFI are reported as third-party transactions recorded within the Company's Unaudited Condensed Consolidated Statement of Operations. Since the petition date, there were no material transactions between the Company and KFI.
  (was, 2023-10-26, similarity 0.999):
[0001783180-23-000065:note_history:8]
In connection with the bankruptcy filing, KFI entered into several agreements with subsidiaries of the Company to ensure they have access to services necessary for the effective operation of their business. All post-deconsolidation activity between the Company and KFI are reported as third-party transactions recorded within the Company's Unaudited Condensed Consolidated Statements of Operations. Since the petition date, there were no material transactions between the Company and KFI.

- added (2024-04-25):
[0001783180-24-000044:note_history:9]
On March 15, 2024, the Company and Pacific Avenue Capital Partners entered into certain agreements including a stock and asset purchase agreement whereby Pacific Avenue Capital Partners shall acquire certain assets and operating liabilities of KFI, subject to approval by the bankruptcy court. On April 1, 2024, the bankruptcy court subsequently approved the sale. However, there has been no determination with respect to the allocation of sale proceeds.

- changed (2024-04-25):
[0001783180-24-000044:note_history:10]
Under the TMA relating to the Separation, the Company is responsible to UTC for its share of the Tax Cuts and Jobs Act transition tax associated with foreign undistributed earnings as of December 31, 2017. During the three months ended March 31, 2024, the Company recognized a $46 million gain associated with the TMA and UTC's conclusion of certain income tax matters from their 2017 and 2018 tax audit with the IRS. Liabilities under the TMA of $96 million and $233 million are included within the accompanying Unaudited Condensed Consolidated Balance Sheet within Accrued Liabilities and Other Long-Term Liabilities as of March 31, 2024, respectively. This obligation is expected to be settled in annual installments ending in April 2026 with the next installment of $96 million due in 2024. The Company believes that the likelihood of incurring losses materially in excess of this amount is remote.
  (was, 2023-10-26, similarity 0.6808):
[0001783180-23-000065:note_history:10]
Under the Tax Matters Agreement relating to the Separation, the Company is responsible to UTC for its share of the Tax Cuts and Jobs Act transition tax associated with foreign undistributed earnings as of December 31, 2017. As a result, liabilities of $75 million and $293 million are included within the accompanying Unaudited Condensed Consolidated Balance Sheet within Accrued Liabilities and Other Long-Term Liabilities as of September 30, 2023, respectively. This obligation is expected to be settled in annual installments ending in April 2026 with the next installment of $75 million due in 2024. The Company believes that the likelihood of incurring losses materially in excess of this amount is remote.

- removed (2024-04-25):
[0001783180-23-000065:note_history:11]
UTC Equity Awards Conversion Litigation

- removed (2024-04-25):
[0001783180-23-000065:note_history:12]
On August 12, 2020, several former employees of UTC or its subsidiaries filed a putative class action complaint (the "Complaint") in the United States District Court for the District of Connecticut against Raytheon Technologies Corporation, Carrier, Otis Worldwide Corporation ("Otis"), the former members of the UTC Board of Directors and the members of the Carrier and Otis Boards of Directors (Geraud Darnis, et al. v. Raytheon Technologies Corporation, et al.). The Complaint challenged the method by which UTC equity awards were converted to UTC, Carrier and Otis equity awards following the Separation and the Distribution. Defendants moved to dismiss the Complaint. Plaintiffs amended their Complaint on September 13, 2021 (the "Amended Complaint"). The Amended Complaint, with Raytheon Technologies Corporation, Carrier and Otis as the only defendants, asserted that the defendants are liable for breach of certain equity compensation plans and for breach of the implied covenant of good faith and fair dealing. The Amended Complaint also sought specific performance. The Company believes all plaintiffs' claims against it are without merit. Defendants moved to dismiss the Amended Complaint. On September 30, 2022, the court dismissed the case against all defendants, with prejudice. Plaintiffs appealed the dismissal to the United States Court of Appeals for the Second Circuit. On August 3, 2023, the Second Circuit Court of Appeals affirmed the district court’s ruling.

- removed (2024-04-25):
[0001783180-23-000065:note_history:13]
within Other income/(expense), net. In addition, the deconsolidation resulted in an investing cash outflow of $134 million in the Company's Unaudited Condensed Consolidated Statements of Cash Flows.


## us-gaap:ScheduleOfEnvironmentalLossContingenciesBySiteTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-04-25):
[0001783180-24-000044:note_history:14]
| (In millions) |  | March 31,2024 |  | December 31,2023 |
| Environmental reserves included in Accrued liabilities |  | $ | 19 |  |  | $ | 21 |  |
| Environmental reserves included in Other long-term liabilities |  | 201 |  |  | 203 |  |
| Total Environmental reserves |  | $ | 220 |  |  | $ | 224 |  |
  (was, 2023-10-26, similarity 0.974):
[0001783180-23-000065:note_history:14]
| (In millions) |  | September 30,2023 |  | December 31,2022 |
| Environmental reserves included in Accrued liabilities |  | $ | 12 |  |  | $ | 24 |  |
| Environmental reserves included in Other long-term liabilities |  | 208 |  |  | 211 |  |
| Total Environmental reserves |  | $ | 220 |  |  | $ | 235 |  |


## us-gaap:ScheduleOfLossContingenciesByContingencyTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-04-25):
[0001783180-24-000044:note_history:15]
| (In millions) |  | March 31,2024 |  | December 31,2023 |
| Asbestos liabilities included in Accrued liabilities |  | $ | 15 |  |  | $ | 15 |  |
| Asbestos liabilities included in Other long-term liabilities |  | 203 |  |  | 206 |  |
| Total Asbestos liabilities |  | $ | 218 |  |  | $ | 221 |  |
| Asbestos-related recoveries included in Other assets, current |  | $ | 5 |  |  | $ | 5 |  |
| Asbestos-related recoveries included in Other assets |  | 87 |  |  | 88 |  |
| Total Asbestos-related recoveries |  | $ | 92 |  |  | $ | 93 |  |
  (was, 2023-10-26, similarity 0.9877):
[0001783180-23-000065:note_history:15]
| (In millions) |  | September 30,2023 |  | December 31,2022 |
| Asbestos liabilities included in Accrued liabilities |  | $ | 16 |  |  | $ | 16 |  |
| Asbestos liabilities included in Other long-term liabilities |  | 207 |  |  | 212 |  |
| Total Asbestos liabilities |  | $ | 223 |  |  | $ | 228 |  |
| Asbestos-related recoveries included in Other assets, current |  | $ | 5 |  |  | $ | 5 |  |
| Asbestos-related recoveries included in Other assets |  | 89 |  |  | 90 |  |
| Total Asbestos-related recoveries |  | $ | 94 |  |  | $ | 95 |  |


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2024-04-25):
[0001783180-24-000044:note_history:16]
Acquisition of Viessmann Climate Solutions

- added (2024-04-25):
[0001783180-24-000044:note_history:17]
On April 25, 2023, the Company announced that it entered into a Share Purchase Agreement (the “Agreement”) to acquire the climate solutions business (the "VCS Business") of Viessmann Group GmbH & Co. KG (“Viessmann”), a privately-held company. The VCS Business develops intelligent, integrated and sustainable technologies, including heat pumps, boilers, photovoltaic systems, home battery storage and digital solutions, primarily for residential customers in Europe. The acquisition was completed on January 2, 2024. As a result, the assets, liabilities and results of operations of the VCS Business are consolidated in the accompanying Unaudited Condensed Consolidated Financial Statements as of the date of acquisition and reported within the Company’s HVAC segment. See Note 15 – Acquisitions for additional information.

- changed (2024-04-25):
[0001783180-24-000044:note_history:18]
Portfolio Transformation
  (was, 2023-10-26, similarity 0.8571):
[0001783180-23-000065:note_history:18]
Planned Portfolio Transformation

- added (2024-04-25):
[0001783180-24-000044:note_history:19]
On April 25, 2023, the Company announced plans to exit its Fire & Security and Commercial Refrigeration businesses over the course of 2024. On December 7, 2023, the Company entered into a stock purchase agreement to sell its Access Solutions business ("Access Solutions") to Honeywell International Inc. for an enterprise value of approximately $4.95 billion. Access Solutions, historically reported in the Company's Fire & Security segment, is a global supplier of physical security and digital access solutions supporting the hospitality, commercial, education and military markets. On December 12, 2023, the Company entered into a stock purchase agreement to sell its Commercial Refrigeration business ("CCR") to Haier Group Corporation for an enterprise value of approximately $775 million. CCR, historically reported in the Company's Refrigeration segment, is a global supplier of turnkey solutions for commercial refrigeration systems and services, with a primary focus on serving food retail customers, cold storage facilities and warehouses. As a result, the assets and liabilities of each business are presented as held for sale in the accompanying Unaudited Condensed Consolidated Balance Sheet as of March 31, 2024 and December 31, 2023, and recorded at the lower of their carrying value or fair value less estimated cost to sell. See Note 16 - Divestitures for additional information.

- added (2024-04-25):
[0001783180-24-000044:note_history:20]
In addition, the net assets of the Company’s Industrial Fire business ("Industrial Fire") met the criteria to be classified as held for sale during the fourth quarter of 2023. Industrial Fire, historically reported in the Company's Fire & Security segment, is a leading manufacturer of a full spectrum of fire detection and suppression solutions and services in critical high-hazard environments, including oil and gas, power generation, marine and offshore facilities, automotive, data centers and aircraft hangars. As a result, the assets and liabilities of the business are presented as held for sale in the accompanying Unaudited Condensed Consolidated Balance Sheet as of March 31, 2024 and December 31, 2023, and recorded at the lower of their carrying value or fair value less estimated cost to sell. On March 5, 2024, the Company entered into a stock purchase agreement to sell Industrial Fire to Sentinel Capital Partners for an enterprise value of approximately $1.425 billion. See Note 16 - Divestitures for additional information.

- changed (2024-04-25):
[0001783180-24-000044:note_history:21]
On April 3, 2020 (the Distribution Date"), United Technologies Corporation ("UTC"), since renamed RTX Corporation ("Raytheon Technologies Corporation" or "RTX"), completed the spin-off of Carrier into an independent, publicly traded company (the "Separation") through a pro-rata distribution (the "Distribution") on a one-for-one basis of all of the outstanding shares of common stock of Carrier to UTC shareowners who held shares of UTC common stock as of the close of business on March 19, 2020, the record date of the Distribution. Following the Separation and Distribution, the Company entered into several agreements with UTC and Otis Worldwide Corporation ("Otis") that govern various aspects of the relationship among the Company, UTC and Otis. As of March 31, 2024, only certain portions of the Tax Matters Agreement ("TMA") remain in effect.
  (was, 2023-10-26, similarity 0.638):
[0001783180-23-000065:note_history:21]
On April 3, 2020 (the Distribution Date"), United Technologies Corporation ("UTC"), since renamed RTX Corporation ("Raytheon Technologies Corporation" or "RTX"), completed the spin-off of Carrier into an independent, publicly traded company (the "Separation") through a pro-rata distribution (the "Distribution") on a one-for-one basis of all of the outstanding shares of common stock of Carrier to UTC shareowners who held shares of UTC common stock as of the close of business on March 19, 2020, the record date of the Distribution. In connection with the Separation, the Company issued an aggregate principal balance of $11.0 billion of debt and transferred approximately $10.9 billion of cash to UTC on February 27, 2020 and March 27, 2020. On April 1, 2020 and April 2, 2020, the Company received cash contributions totaling $590 million from UTC related to the Separation.

- added (2024-04-25):
[0001783180-24-000044:note_history:22]
Recently Issued Accounting Pronouncements

- added (2024-04-25):
[0001783180-24-000044:note_history:23]
In November 2023, the FASB issued ASU 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures (“ASU 2023-07”), which requires public entities to disclose information about their reportable segments’ significant expenses on an interim and annual basis. In addition, the amendments clarify circumstances in which an entity can disclose multiple segment measures of profit or loss, provide new segment disclosure requirements for entities with a single reportable segment and contain other disclosure requirements. ASU 2023-07 is effective for fiscal years beginning after December 15, 2023 and interim periods within fiscal years beginning after December 15, 2024, with early adoption permitted. The Company is currently assessing the impact of this ASU on its financial statements.

- added (2024-04-25):
[0001783180-24-000044:note_history:24]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures ("ASU 2023-09"), which requires public entities to disclose disaggregated information about their effective tax rate reconciliation as well as information on income taxes paid. ASU 2023-09 is effective for fiscal years beginning after December 15, 2023 and interim periods within fiscal years beginning after December 15, 2024, with early adoption permitted. The Company is currently assessing the impact of this ASU on its financial statements.

- added (2024-04-25):
[0001783180-24-000044:note_history:25]
On March 6, 2024, the SEC adopted new rules designed to enhance public company disclosures related to the risks and impacts of climate-related matters. The rules amend the provisions of both Regulation S-K and Regulation S-X and will be required in annual reports and registration statements. Amendments to Regulation S-K require disclosure of climate-related risks, transition plans, targets and goals, risk management and governance. Amendments to Regulation S-X require disclosure of the financial effects of severe weather events and other natural conditions as well as the use of carbon offsets or renewable energy credits. Disclosure requirements will begin phasing in for fiscal years beginning on or after January 1, 2025, subject to legal challenges and the SEC's voluntary stay of the disclosure requirements. The Company will continue to assess the impact of these new rules on its financial statements while the stay is in place.

- removed (2024-04-25):
[0001783180-23-000065:note_history:26]
On April 25, 2023, the Company announced that it entered into a Share Purchase Agreement (the “Agreement”) to acquire the climate solutions business (the "VCS Business") of Viessmann Group GmbH & Co. KG (“Viessmann”), a privately-held company, for approximately €12 billion. The VCS Business develops intelligent, integrated and sustainable technologies, including heat pumps, boilers, photovoltaic systems, home battery storage and digital solutions, primarily for residential customers in Europe. The transaction is expected to close around the end of 2023, subject to customary closing conditions and regulatory approvals. In addition, the Company also announced plans to exit its Fire & Security and Commercial Refrigeration businesses over the course of 2024. See Note 15 – Acquisitions and Note 16 - Divestitures for additional information.

- removed (2024-04-25):
[0001783180-23-000065:note_history:27]
Acquisition of Toshiba Carrier Corporation

- removed (2024-04-25):
[0001783180-23-000065:note_history:28]
On February 6, 2022, the Company entered into a binding agreement to acquire a majority ownership interest in Toshiba Carrier Corporation (“TCC”), a variable refrigerant flow ("VRF") and light commercial HVAC joint venture between Carrier and Toshiba Corporation. The acquisition was completed on August 1, 2022. As a result, the assets, liabilities and results of operations of TCC are consolidated in the accompanying Unaudited Condensed Consolidated Financial Statements as of the

- removed (2024-04-25):
[0001783180-23-000065:note_history:29]
date of acquisition and reported within the Company’s HVAC segment. Upon closing, Toshiba Corporation retained a 5% ownership interest in TCC. See Note 15 – Acquisitions for additional information.

- removed (2024-04-25):
[0001783180-23-000065:note_history:30]
Sale of Chubb Fire & Security Business

- removed (2024-04-25):
[0001783180-23-000065:note_history:31]
On July 26, 2021, the Company entered into a stock purchase agreement to sell its Chubb Fire and Security business ("Chubb") to APi Group Corporation ("APi"). Chubb, which was reported within the Company’s Fire & Security segment, delivered essential fire safety and security solutions from design and installation to monitoring, service and maintenance across more than 17 countries around the globe. The sale of Chubb was completed on January 3, 2022 (the "Chubb Sale"). See Note 16 - Divestitures for additional information.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2024-04-25):
[0001783180-24-000044:note_history:32]
DESCRIPTION OF THE BUSINESS
Carrier Global Corporation (the "Company") is a global leader in intelligent climate and energy solutions with a focus on providing differentiated, digitally-enabled lifecycle solutions to its customers. The Company's portfolio includes industry-leading brands such as Carrier, Viessmann, Toshiba, Automated Logic, Carrier Transicold, Kidde, Edwards and LenelS2 that offer innovative heating, ventilating, air conditioning ("HVAC"), refrigeration, fire, security and building automation technologies to help make the world safer and more comfortable. The Company also provides a broad array of related building services, including audit, design, installation, system integration, repair, maintenance and monitoring. The Company's operations are classified into three segments: HVAC, Refrigeration and Fire & Security.
  (was, 2023-10-26, similarity 0.9934):
[0001783180-23-000065:note_history:32]
DESCRIPTION OF THE BUSINESS
Carrier Global Corporation (the "Company") is a global leader in intelligent climate and energy solutions with a focus on providing differentiated, digitally-enabled lifecycle solutions to its customers. The Company's portfolio includes industry-leading brands such as Carrier, Toshiba, Automated Logic, Carrier Transicold, Kidde, Edwards and LenelS2 that offer innovative heating, ventilating, air conditioning ("HVAC"), refrigeration, fire, security and building automation technologies to help make the world safer and more comfortable. The Company also provides a broad array of related building services, including audit, design, installation, system integration, repair, maintenance and monitoring. The Company's operations are classified into three segments: HVAC, Refrigeration and Fire & Security.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-04-25):
[0001783180-24-000044:note_history:33]
| (In millions) |  |  |  | March 31,2024 |  | December 31,2023 |
| 2.242% Notes due 2025 (1) |  |  |  | $ | 1,200 |  |  | $ | 1,200 |  |
| 4.375% Notes due 2025 |  |  |  | 812 |  |  | 830 |  |
| 5.800% Notes due 2025 |  |  |  | 1,000 |  |  | 1,000 |  |
| 2.493% Notes due 2027 |  |  |  | 900 |  |  | 900 |  |
| 4.125% Notes due 2028 |  |  |  | 812 |  |  | 830 |  |
| 2.722% Notes due 2030 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.700% Notes due 2031 |  |  |  | 750 |  |  | 750 |  |
| 4.500% Notes due 2032 |  |  |  | 921 |  |  | 941 |  |
| 5.900% Notes due 2034 |  |  |  | 1,000 |  |  | 1,000 |  |
| 3.377% Notes due 2040 |  |  |  | 1,500 |  |  | 1,500 |  |
| 3.577% Notes due 2050 |  |  |  | 2,000 |  |  | 2,000 |  |
| 6.200% Notes due 2054 |  |  |  | 1,000 |  |  | 1,000 |  |
| Total long-term notes |  |  |  | 13,895 |  |  | 13,951 |  |
| Delayed Draw Facility |  |  |  | 2,536 |  |  | — |  |
| Japanese Term Loan Facility |  |  |  | 357 |  |  | 379 |  |
| Other debt (including project financing obligations and finance leases) |  |  |  | 213 |  |  | 74 |  |
| Discounts and debt issuance costs |  |  |  | (106) |  |  | (111) |  |
| Total debt |  |  |  | 16,895 |  |  | 14,293 |  |
| Less: current portion of long-term debt |  |  |  | 1,248 |  |  | 51 |  |
| Long-term debt, net of current portion |  |  |  | $ | 15,647 |  |  | $ | 14,242 |  |
  (was, 2023-10-26, similarity 0.8):
[0001783180-23-000065:note_history:33]
| (In millions) |  |  |  | September 30,2023 |  | December 31,2022 |
| 2.242% Notes due February 15, 2025 |  |  |  | $ | 1,200 |  |  | $ | 1,200 |  |
| 2.493% Notes due February 15, 2027 |  |  |  | 900 |  |  | 900 |  |
| 2.722% Notes due February 15, 2030 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.700% Notes due February 15, 2031 |  |  |  | 750 |  |  | 750 |  |
| 3.377% Notes due April 5, 2040 |  |  |  | 1,500 |  |  | 1,500 |  |
| 3.577% Notes due April 5, 2050 |  |  |  | 2,000 |  |  | 2,000 |  |
| Total long-term notes |  |  |  | 8,350 |  |  | 8,350 |  |
| Japanese Term Loan Facility |  |  |  | 362 |  |  | 404 |  |
| Other debt (including project financing obligations and finance leases) |  |  |  | 154 |  |  | 149 |  |
| Discounts and debt issuance costs |  |  |  | (81) |  |  | (61) |  |
| Total debt |  |  |  | 8,785 |  |  | 8,842 |  |
| Less: current portion of long-term debt |  |  |  | 134 |  |  | 140 |  |
| Long-term debt, net of current portion |  |  |  | $ | 8,651 |  |  | $ | 8,702 |  |

- added (2024-04-25):
[0001783180-24-000044:note_history:34]
(1) 2.242% Notes due February 15, 2025; reclassified to Current portion of long-term debt.

- added (2024-04-25):
[0001783180-24-000044:note_history:35]
Acquisition Funding

- added (2024-04-25):
[0001783180-24-000044:note_history:36]
On January 2, 2024, the Company completed the acquisition of the VCS Business for total consideration of $14.2 billion. Under the terms of the Agreement, 20% of the purchase price was paid in Carrier common stock, issued directly to Viessmann and subject to certain lock up provisions and 80% was paid in cash, subject to working capital and other adjustments. In order to fund the Euro-denominated cash portion of the purchase price, the Company used cash on hand, debt financing and various term loan facilities.

- added (2024-04-25):
[0001783180-24-000044:note_history:37]
Debt Issuance

- added (2024-04-25):
[0001783180-24-000044:note_history:38]
In November 2023, the Company issued $3.0 billion principal amount of USD-denominated notes in three tranches. The tranches consisted of $1.0 billion aggregate principal amount of 5.8% notes due 2025, $1.0 billion aggregate principal amount of 5.90% notes due 2034 and $1.0 billion aggregate principal amount of 6.2% notes due 2054 (collectively, the “USD Notes”). In addition, the Company issued €2.35 billion principal amount of Euro-denominated notes in three tranches. The tranches consisted of €750 million aggregate principal amount of 4.375% notes due 2025, €750 million aggregate principal amount of 4.125% notes due 2028 and €850 million aggregate principal amount of 4.5% notes due 2032 (collectively, the “Euro Notes”). The Company capitalized $51 million of deferred financing costs which are being amortized over the term of their related notes. The notes are subject to certain customary covenants and the Company has the option to redeem the notes in whole or in part at any time, prior to their stated maturity date at the redemption price set forth in the indenture agreements.

- added (2024-04-25):
[0001783180-24-000044:note_history:39]
Bridge Loan

- added (2024-04-25):
[0001783180-24-000044:note_history:40]
On April 25, 2023, the Company entered into commitment letters with JPMorgan Chase Bank, N.A., BofA Securities, Inc. and Bank of America, N.A. to provide a €8.2 billion aggregate principal, senior unsecured bridge term loan facility (the “Bridge Loan”). Euro-denominated borrowings bore interest at the EURIBOR Rate plus a ratings-based margin, USD-denominated borrowings bore interest at either a Term SOFR Rate plus 0.10% and a ratings-based margin or, alternatively, at a base rate plus a ratings-based margin. The Company capitalized $48 million of deferred financing costs associated with the Bridge Loan which were amortized over the commitment period. Upon entering into a senior unsecured delayed draw term loan facility and issuing the USD Notes and the Euro Notes, the Company reduced the Bridge Loan by €7.7 billion and accelerated the amortization on $25 million of deferred financing costs in Interest expense during 2023. On January 2, 2024, the Company entered into a 60-day senior unsecured term loan agreement consisting of a Euro-denominated tranche in an aggregate amount of €113 million and a USD-denominated tranche in an aggregate amount of $349 million (the “60-day Loan”). Upon entering into the 60-day Loan, the Company reduced the final portion of the Bridge Loan by €500 million and subsequently terminated the agreement. As of March 31, 2024, borrowings under the 60-day Loan have been fully repaid.

- added (2024-04-25):
[0001783180-24-000044:note_history:41]
Delayed Draw Facility

- added (2024-04-25):
[0001783180-24-000044:note_history:42]
On May 19, 2023, the Company entered into a senior unsecured delayed draw term loan credit agreement with JPMorgan Chase Bank, N.A., as administrative agent and certain other lenders that permits aggregate borrowings of up to €2.3 billion (the "Delayed Draw Facility"). The facility consists of an 18-month, Euro-denominated tranche in an aggregate amount of €1.15 billion and a 3-year, Euro-denominated tranche in an aggregate amount of €1.15 billion. Euro-denominated borrowings bear interest at the EURIBOR Rate plus a ratings-based margin, USD-denominated borrowings bear interest at either a Term SOFR Rate plus 0.10% and a ratings-based margin or, alternatively, at a base rate plus a ratings-based margin. The Company capitalized $4 million of deferred financing costs which will be amortized over the respective term of the tranches. On January 2, 2024, the Company borrowed the full amount available under the Delayed Draw Facility in U.S. Dollars.

- added (2024-04-25):
[0001783180-24-000044:note_history:43]
364 Day Revolver

- added (2024-04-25):
[0001783180-24-000044:note_history:44]
On May 19, 2023, the Company entered into a 364-day, $500 million, senior unsecured revolving credit agreement with JPMorgan Chase Bank, N.A., as administrative agent and certain other lenders (the “Revolver”), the proceeds of which became available upon closing of the acquisition of the VCS Business. Borrowings bear interest at either a Term SOFR Rate plus 0.10% and a ratings-based margin or, alternatively, at a base rate plus a ratings-based margin. As of March 31, 2024, there were no borrowings outstanding under the Revolver.

- changed (2024-04-25):
[0001783180-24-000044:note_history:45]
On July 15, 2022, the Company entered into a five-year, JPY 54 billion (approximately $400 million) senior unsecured term loan facility with MUFG Bank Ltd., as administrative agent and lender, and certain other lenders (the "Japanese Term Loan Facility"). Borrowings under the Japanese Term Loan Facility bear interest at a rate equal to the Tokyo Term Risk Free Rate plus 0.75%. The Company capitalized $2 million of deferred financing costs which are being amortized over its term. On July 25, 2022, the Company borrowed JPY 54 billion under the Japanese Term Loan Facility and used the proceeds to fund a portion of the Yen-denominated purchase price of Toshiba Carrier Corporation ("TCC") and to pay related fees and expenses.
  (was, 2023-10-26, similarity 0.8453):
[0001783180-23-000065:note_history:45]
On July 15, 2022, the Company entered into a five-year, JPY 54 billion (approximately $400 million) senior unsecured term loan facility with MUFG Bank Ltd., as administrative agent and lender, and certain other lenders (the "Japanese Term Loan Facility"). Borrowings under the Japanese Term Loan Facility bear interest at a rate equal to the Tokyo Term Risk Free Rate plus 0.75%. In addition, the Japanese Term Loan Facility is subject to customary covenants including a covenant to maintain a maximum consolidated leverage ratio. The Company capitalized $2 million of deferred financing costs which are being amortized over its term. On July 25, 2022, the Company borrowed JPY 54 billion under the Japanese Term Loan Facility and used the proceeds to fund a portion of the TCC acquisition and to pay related fees and expenses.

- changed (2024-04-25):
[0001783180-24-000044:note_history:46]
On May 19, 2023, the Company entered into a revolving credit agreement with JPMorgan Chase Bank, N.A., as administrative agent, and certain other lenders, permitting aggregate borrowings of up to $2.0 billion pursuant to an unsecured, unsubordinated revolving credit facility that matures in May 2028 (the "Revolving Credit Facility"). The Revolving Credit Facility supports the Company's commercial paper program and can be used for other general corporate purposes. Borrowings are available in U.S. Dollars and Euros. U.S. Dollar borrowings can bear interest at either a Term SOFR Rate plus 0.10% and a ratings-based margin or, alternatively, at an alternate base rate plus a ratings-based margin. Euro borrowings bear interest at an adjusted EURIBOR rate plus a ratings-based margin. A ratings-based commitment fee is charged on unused commitments. Upon entering into the agreement, the Company terminated its existing revolving credit facility that was set to mature in April 2025. In addition, the Company capitalized $2 million of deferred financing costs which are being amortized over its term. As of March 31, 2024, there were no borrowings outstanding under the Revolving Credit Facility.
  (was, 2023-10-26, similarity 0.994):
[0001783180-23-000065:note_history:46]
On May 19, 2023, the Company entered into a revolving credit agreement with JPMorgan Chase Bank, N.A., as administrative agent, and certain other lenders, permitting aggregate borrowings of up to $2.0 billion pursuant to an unsecured, unsubordinated revolving credit facility that matures in May 2028 (the "Revolving Credit Facility"). The Revolving Credit Facility supports the Company's commercial paper program and can be used for other general corporate purposes. Borrowings are available in U.S. Dollars and Euros. U.S. Dollar borrowings can bear interest at either a Term SOFR Rate plus 0.10% and a ratings-based margin or, alternatively, at an alternate base rate plus a ratings-based margin. Euro borrowings bear interest at an adjusted EURIBOR rate plus a ratings-based margin. A ratings-based commitment fee is charged on unused commitments. Upon entering into the agreement, the Company terminated its existing revolving credit facility that was set to mature in April 2025. In addition, the Company capitalized $2 million of deferred financing costs which are being amortized over its term. As of September 30, 2023, there were no borrowings outstanding under the Revolving Credit Facility.

- changed (2024-04-25):
[0001783180-24-000044:note_history:47]
The Company has a $2.0 billion unsecured, unsubordinated commercial paper program, which can be used for general corporate purposes, including the funding of working capital and potential acquisitions. As of March 31, 2024, there were no borrowings outstanding under the commercial paper program.
  (was, 2023-10-26, similarity 0.9759):
[0001783180-23-000065:note_history:47]
The Company has a $2.0 billion unsecured, unsubordinated commercial paper program, which can be used for general corporate purposes, including the funding of working capital and potential acquisitions. As of September 30, 2023, there were no borrowings outstanding under the commercial paper program.

- changed (2024-04-25):
[0001783180-24-000044:note_history:48]
The Company is involved in long-term construction contracts in which it arranges project financing with certain customers. As a result, the Company issued $10 million and $5 million of debt during the three months ended March 31, 2024 and 2023, respectively. Long-term debt repayments associated with these financing arrangements during the three months ended March 31, 2024 and 2023 were $5 million and $2 million, respectively.
  (was, 2023-10-26, similarity 0.8768):
[0001783180-23-000065:note_history:48]
The Company is involved in long-term construction contracts in which it arranges project financing with certain customers. As a result, the Company issued $14 million and $27 million of debt during the nine months ended September 30, 2023 and 2022, respectively. Long-term debt repayments associated with these financing arrangements during the nine months ended September 30, 2023 and 2022 were $15 million and $70 million, respectively.

- added (2024-04-25):
[0001783180-24-000044:note_history:49]
The Revolving Credit Facility, Revolver, the indenture for the long-term notes and the Japanese Term Loan Facility contain affirmative and negative covenants customary for financings of these types, which, among other things, limit the Company's ability to incur certain liens, to make certain fundamental changes and to enter into sale and leaseback transactions. As of March 31, 2024, the Company was in compliance with the covenants under the agreements governing its outstanding indebtedness.

- removed (2024-04-25):
[0001783180-23-000065:note_history:50]
The Revolving Credit Facility, the indenture for the long-term notes and the Japanese Term Loan Facility contain affirmative and negative covenants customary for financings of these types, which, among other things, limit the Company's ability to incur additional liens, to make certain fundamental changes and to enter into sale and leaseback transactions. As of September 30, 2023, the Company was in compliance with the covenants under the agreements governing its outstanding indebtedness.

- removed (2024-04-25):
[0001783180-23-000065:note_history:51]
Tender Offers

- removed (2024-04-25):
[0001783180-23-000065:note_history:52]
On March 15, 2022, the Company commenced tender offers to purchase up to $1.15 billion ("Aggregate Tender Cap") aggregate principal of the Company's 2.242% Notes due 2025 and 2.493% Notes due 2027 (together, the "Senior Notes"). The tender offers included payment of applicable accrued and unpaid interest up to the settlement date, along with a fixed spread for early repayment. Based on participation, the Company elected to settle the tender offers on March 30, 2022. The aggregate principal amount of Senior Notes validly tendered and accepted was approximately $1.15 billion, which included $800 million of Notes due 2025 and $350 million of Notes due 2027. As a result, the Company recognized a net gain of $33 million and wrote off $5 million of unamortized deferred financing costs within Interest (expense) income, net on the accompanying Unaudited Condensed Consolidated Statement of Operations during the three months ended March 31, 2022.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-04-25):
[0001783180-24-000044:note_history:53]
| (In millions) |  |  |  | March 31,2024 |  | December 31,2023 |
| 2.242% Notes due 2025 (1) |  |  |  | $ | 1,200 |  |  | $ | 1,200 |  |
| 4.375% Notes due 2025 |  |  |  | 812 |  |  | 830 |  |
| 5.800% Notes due 2025 |  |  |  | 1,000 |  |  | 1,000 |  |
| 2.493% Notes due 2027 |  |  |  | 900 |  |  | 900 |  |
| 4.125% Notes due 2028 |  |  |  | 812 |  |  | 830 |  |
| 2.722% Notes due 2030 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.700% Notes due 2031 |  |  |  | 750 |  |  | 750 |  |
| 4.500% Notes due 2032 |  |  |  | 921 |  |  | 941 |  |
| 5.900% Notes due 2034 |  |  |  | 1,000 |  |  | 1,000 |  |
| 3.377% Notes due 2040 |  |  |  | 1,500 |  |  | 1,500 |  |
| 3.577% Notes due 2050 |  |  |  | 2,000 |  |  | 2,000 |  |
| 6.200% Notes due 2054 |  |  |  | 1,000 |  |  | 1,000 |  |
| Total long-term notes |  |  |  | 13,895 |  |  | 13,951 |  |
| Delayed Draw Facility |  |  |  | 2,536 |  |  | — |  |
| Japanese Term Loan Facility |  |  |  | 357 |  |  | 379 |  |
| Other debt (including project financing obligations and finance leases) |  |  |  | 213 |  |  | 74 |  |
| Discounts and debt issuance costs |  |  |  | (106) |  |  | (111) |  |
| Total debt |  |  |  | 16,895 |  |  | 14,293 |  |
| Less: current portion of long-term debt |  |  |  | 1,248 |  |  | 51 |  |
| Long-term debt, net of current portion |  |  |  | $ | 15,647 |  |  | $ | 14,242 |  |
  (was, 2023-10-26, similarity 0.8):
[0001783180-23-000065:note_history:53]
| (In millions) |  |  |  | September 30,2023 |  | December 31,2022 |
| 2.242% Notes due February 15, 2025 |  |  |  | $ | 1,200 |  |  | $ | 1,200 |  |
| 2.493% Notes due February 15, 2027 |  |  |  | 900 |  |  | 900 |  |
| 2.722% Notes due February 15, 2030 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.700% Notes due February 15, 2031 |  |  |  | 750 |  |  | 750 |  |
| 3.377% Notes due April 5, 2040 |  |  |  | 1,500 |  |  | 1,500 |  |
| 3.577% Notes due April 5, 2050 |  |  |  | 2,000 |  |  | 2,000 |  |
| Total long-term notes |  |  |  | 8,350 |  |  | 8,350 |  |
| Japanese Term Loan Facility |  |  |  | 362 |  |  | 404 |  |
| Other debt (including project financing obligations and finance leases) |  |  |  | 154 |  |  | 149 |  |
| Discounts and debt issuance costs |  |  |  | (81) |  |  | (61) |  |
| Total debt |  |  |  | 8,785 |  |  | 8,842 |  |
| Less: current portion of long-term debt |  |  |  | 134 |  |  | 140 |  |
| Long-term debt, net of current portion |  |  |  | $ | 8,651 |  |  | $ | 8,702 |  |

- added (2024-04-25):
[0001783180-24-000044:note_history:54]
(1) 2.242% Notes due February 15, 2025; reclassified to Current portion of long-term debt.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- added (2024-04-25):
[0001783180-24-000044:note_history:55]
|  |  |  |  | Three Months Ended March 31, |
| (In millions) |  |  |  |  |  | 2024 |  | 2023 |
| Sales to equity method investees included in Product sales |  |  |  |  |  | $ | 723 |  |  | $ | 754 |  |
| Purchases from equity method investees included in Cost of products sold |  |  |  |  |  | $ | 55 |  |  | $ | 43 |  |

- added (2024-04-25):
[0001783180-24-000044:note_history:56]
| (In millions) |  | March 31,2024 |  | December 31,2023 |
| Receivables from equity method investees included in Accounts receivable, net |  | $ | 261 |  |  | $ | 231 |  |
| Payables to equity method investees included in Accounts payable |  | $ | 44 |  |  | $ | 44 |  |

- removed (2024-04-25):
[0001783180-23-000065:note_history:57]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
| (In millions) |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Sales to equity method investees included in Product sales |  | $ | 730 |  |  | $ | 718 |  |  | $ | 2,371 |  |  | $ | 2,129 |  |
| Purchases from equity method investees included in Cost of products sold |  | $ | 57 |  |  | $ | 60 |  |  | $ | 159 |  |  | $ | 261 |  |

- removed (2024-04-25):
[0001783180-23-000065:note_history:58]
| (In millions) |  | September 30,2023 |  | December 31,2022 |
| Receivables from equity method investees included in Accounts receivable, net |  | $ | 289 |  |  | $ | 154 |  |
| Payables to equity method investees included in Accounts payable |  | $ | 35 |  |  | $ | 44 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-04-25):
[0001783180-24-000044:note_history:59]
|  |  | Three Months Ended March 31, |  |  |
| (In millions) |  | 2024 |  | 2023 |  |  |  |  |
| Sales Type |  |  |  |  |  |  |  |  |
| Product |  | $ | 4,073 |  |  | $ | 3,201 |  |  |  |  |  |
| Service |  | 468 |  |  | 421 |  |  |  |  |  |
| HVAC sales |  | 4,541 |  |  | 3,622 |  |  |  |  |  |
| Product |  | 772 |  |  | 787 |  |  |  |  |  |
| Service |  | 112 |  |  | 111 |  |  |  |  |  |
| Refrigeration sales |  | 884 |  |  | 898 |  |  |  |  |  |
| Product |  | 825 |  |  | 813 |  |  |  |  |  |
| Service |  | 62 |  |  | 56 |  |  |  |  |  |
| Fire & Security sales |  | 887 |  |  | 869 |  |  |  |  |  |
| Total segment sales |  | 6,312 |  |  | 5,389 |  |  |  |  |  |
| Eliminations and other |  | (130) |  |  | (116) |  |  |  |  |  |
| Net sales |  | $ | 6,182 |  |  | $ | 5,273 |  |  |  |  |  |
  (was, 2023-10-26, similarity 0.8487):
[0001783180-23-000065:note_history:59]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
| (In millions) |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Sales Type |  |  |  |  |  |  |  |  |
| Product |  | $ | 3,533 |  |  | $ | 3,330 |  |  | $ | 10,488 |  |  | $ | 8,974 |  |
| Service |  | 475 |  |  | 404 |  |  | 1,358 |  |  | 1,118 |  |
| HVAC sales |  | 4,008 |  |  | 3,734 |  |  | 11,846 |  |  | 10,092 |  |
| Product |  | 808 |  |  | 811 |  |  | 2,453 |  |  | 2,603 |  |
| Service |  | 116 |  |  | 112 |  |  | 341 |  |  | 337 |  |
| Refrigeration sales |  | 924 |  |  | 923 |  |  | 2,794 |  |  | 2,940 |  |
| Product |  | 864 |  |  | 859 |  |  | 2,546 |  |  | 2,468 |  |
| Service |  | 59 |  |  | 46 |  |  | 178 |  |  | 142 |  |
| Fire & Security sales |  | 923 |  |  | 905 |  |  | 2,724 |  |  | 2,610 |  |
| Total segment sales |  | 5,855 |  |  | 5,562 |  |  | 17,364 |  |  | 15,642 |  |
| Eliminations and other |  | (124) |  |  | (111) |  |  | (368) |  |  | (326) |  |
| Net sales |  | $ | 5,731 |  |  | $ | 5,451 |  |  | $ | 16,996 |  |  | $ | 15,316 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-04-25):
[0001783180-24-000044:note_history:60]
The Company accounts for revenue in accordance with ASC 606: Revenue from Contracts with Customers. Revenue is recognized when control of a good or service promised in a contract (i.e., performance obligation) is transferred to a customer. Control is obtained when a customer has the ability to direct the use of and obtain substantially all of the remaining benefits from that good or service. A significant portion of the Company's performance obligations are recognized at a point-in-time when control of the product transfers to the customer, which is generally at the time of shipment. The remaining portion of the Company’s performance obligations are recognized over time as the customer simultaneously obtains control as the Company performs work under a contract, or if the product being produced for the customer has no alternative use and the Company has a contractual right to payment.
  (was, 2023-10-26, similarity 0.7381):
[0001783180-23-000065:note_history:60]
The Company accounts for revenue in accordance with ASC 606: Revenue from Contracts with Customers. Revenue is recognized when control of a good or service promised in a contract (i.e., performance obligation) is transferred to a customer. Control is obtained when a customer has the ability to direct the use of and obtain substantially all of the remaining benefits from that good or service. A significant portion of the Company's performance obligations are recognized at a point-in-time when control of the product transfers to the customer, which is generally at the time of shipment. The remaining portion of the Company’s performance obligations are recognized over time as the customer simultaneously obtains control as the Company performs work under a contract, or if the product being produced for the customer has no alternative use and the Company has a contractual right to payment.The timing of revenue recognition, billings and cash collections results in contract assets and contract liabilities. Contract assets relate to the conditional right to consideration for any completed performance under a contract when costs are incurred in excess of billings under the percentage-of-completion methodology. Contract liabilities relate to payments received in advance of performance under a contract or when the Company has a right to consideration that is conditioned upon transfer of a good or service to a customer. Contract liabilities are recognized as revenue as (or when) the Company performs under the contract.

- added (2024-04-25):
[0001783180-24-000044:note_history:61]
The timing of revenue recognition, billings and cash collections results in contract assets and contract liabilities. Contract assets relate to the conditional right to consideration for any completed performance under a contract when costs are incurred in excess of billings under the percentage-of-completion methodology. Contract liabilities relate to payments received in advance of performance under a contract or when the Company has a right to consideration that is conditioned upon transfer of a good or service to a customer. Contract liabilities are recognized as revenue as (or when) the Company performs under the contract.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-04-25):
[0001783180-24-000044:note_history:62]
REVENUE RECOGNITION
The Company accounts for revenue in accordance with ASC 606: Revenue from Contracts with Customers. Revenue is recognized when control of a good or service promised in a contract (i.e., performance obligation) is transferred to a customer. Control is obtained when a customer has the ability to direct the use of and obtain substantially all of the remaining benefits from that good or service. A significant portion of the Company's performance obligations are recognized at a point-in-time when control of the product transfers to the customer, which is generally at the time of shipment. The remaining portion of the Company’s performance obligations are recognized over time as the customer simultaneously obtains control as the Company performs work under a contract, or if the product being produced for the customer has no alternative use and the Company has a contractual right to payment.
  (was, 2023-10-26, similarity 0.9682):
[0001783180-23-000065:note_history:62]
REVENUE RECOGNITIONThe Company accounts for revenue in accordance with ASC 606: Revenue from Contracts with Customers. Revenue is recognized when control of a good or service promised in a contract (i.e., performance obligation) is transferred to a customer. Control is obtained when a customer has the ability to direct the use of and obtain substantially all of the remaining benefits from that good or service. A significant portion of the Company's performance obligations are recognized at a point-in-time when control of the product transfers to the customer, which is generally at the time of shipment. The remaining portion of the Company’s performance obligations are recognized over time as the customer simultaneously obtains control as the Company performs work under a contract, or if the product being produced for the customer has no alternative use and the Company has a contractual right to payment.
Sales disaggregated by product and service are as follows:

- added (2024-04-25):
[0001783180-24-000044:note_history:63]
Sales disaggregated by product and service are as follows:

- changed (2024-04-25):
[0001783180-24-000044:note_history:64]
|  |  | Three Months Ended March 31, |  |  |
| (In millions) |  | 2024 |  | 2023 |  |  |  |  |
| Sales Type |  |  |  |  |  |  |  |  |
| Product |  | $ | 4,073 |  |  | $ | 3,201 |  |  |  |  |  |
| Service |  | 468 |  |  | 421 |  |  |  |  |  |
| HVAC sales |  | 4,541 |  |  | 3,622 |  |  |  |  |  |
| Product |  | 772 |  |  | 787 |  |  |  |  |  |
| Service |  | 112 |  |  | 111 |  |  |  |  |  |
| Refrigeration sales |  | 884 |  |  | 898 |  |  |  |  |  |
| Product |  | 825 |  |  | 813 |  |  |  |  |  |
| Service |  | 62 |  |  | 56 |  |  |  |  |  |
| Fire & Security sales |  | 887 |  |  | 869 |  |  |  |  |  |
| Total segment sales |  | 6,312 |  |  | 5,389 |  |  |  |  |  |
| Eliminations and other |  | (130) |  |  | (116) |  |  |  |  |  |
| Net sales |  | $ | 6,182 |  |  | $ | 5,273 |  |  |  |  |  |
  (was, 2023-10-26, similarity 0.8487):
[0001783180-23-000065:note_history:64]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
| (In millions) |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Sales Type |  |  |  |  |  |  |  |  |
| Product |  | $ | 3,533 |  |  | $ | 3,330 |  |  | $ | 10,488 |  |  | $ | 8,974 |  |
| Service |  | 475 |  |  | 404 |  |  | 1,358 |  |  | 1,118 |  |
| HVAC sales |  | 4,008 |  |  | 3,734 |  |  | 11,846 |  |  | 10,092 |  |
| Product |  | 808 |  |  | 811 |  |  | 2,453 |  |  | 2,603 |  |
| Service |  | 116 |  |  | 112 |  |  | 341 |  |  | 337 |  |
| Refrigeration sales |  | 924 |  |  | 923 |  |  | 2,794 |  |  | 2,940 |  |
| Product |  | 864 |  |  | 859 |  |  | 2,546 |  |  | 2,468 |  |
| Service |  | 59 |  |  | 46 |  |  | 178 |  |  | 142 |  |
| Fire & Security sales |  | 923 |  |  | 905 |  |  | 2,724 |  |  | 2,610 |  |
| Total segment sales |  | 5,855 |  |  | 5,562 |  |  | 17,364 |  |  | 15,642 |  |
| Eliminations and other |  | (124) |  |  | (111) |  |  | (368) |  |  | (326) |  |
| Net sales |  | $ | 5,731 |  |  | $ | 5,451 |  |  | $ | 16,996 |  |  | $ | 15,316 |  |

- changed (2024-04-25):
[0001783180-24-000044:note_history:65]
| (In millions) |  | March 31,2024 |  | December 31,2023 |
| Contract assets, current |  | $ | 320 |  |  | $ | 306 |  |
| Contract assets, non-current (included within Other assets) |  | 30 |  |  | 26 |  |
| Total contract assets |  | 350 |  |  | 332 |  |
| Contract liabilities, current |  | (501) |  |  | (425) |  |
| Contract liabilities, non-current (included within Other long-term liabilities) |  | (157) |  |  | (160) |  |
| Total contract liabilities |  | (658) |  |  | (585) |  |
| Net contract assets (liabilities) |  | $ | (308) |  |  | $ | (253) |  |
  (was, 2023-10-26, similarity 0.9879):
[0001783180-23-000065:note_history:65]
| (In millions) |  | September 30,2023 |  | December 31,2022 |
| Contract assets, current |  | $ | 605 |  |  | $ | 537 |  |
| Contract assets, non-current (included within Other assets) |  | 18 |  |  | 6 |  |
| Total contract assets |  | 623 |  |  | 543 |  |
| Contract liabilities, current |  | (496) |  |  | (449) |  |
| Contract liabilities, non-current (included within Other long-term liabilities) |  | (166) |  |  | (174) |  |
| Total contract liabilities |  | (662) |  |  | (623) |  |
| Net contract assets (liabilities) |  | $ | (39) |  |  | $ | (80) |  |

- changed (2024-04-25):
[0001783180-24-000044:note_history:66]
The Company recognized revenue of $345 million during the three months ended March 31, 2024 that related to contract liabilities as of January 1, 2024. The Company expects a majority of its current contract liabilities at the end of the period to be recognized as revenue in the next 12 months.
  (was, 2023-10-26, similarity 0.9097):
[0001783180-23-000065:note_history:66]
The Company recognized revenue of $325 million during the nine months ended September 30, 2023 that related to contract liabilities as of January 1, 2023. The Company expects a majority of its current contract liabilities at the end of the period to be recognized as revenue in the next 12 months.
