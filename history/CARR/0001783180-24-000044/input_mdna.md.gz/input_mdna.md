# CARR MD&A — 0001783180-24-000044


## mdna

[0001783180-24-000044:mdna:1]
[same as prior period, unchanged from 0001783180-23-000065:mdna:1]

[0001783180-24-000044:mdna:2]
[same as prior period, unchanged from 0001783180-23-000065:mdna:2]

[0001783180-24-000044:mdna:3]
[same as prior period, unchanged from 0001783180-23-000065:mdna:3]

[0001783180-24-000044:mdna:4]
Carrier Global Corporation ("we" or "our") is a global leader in intelligent climate and energy solutions with a focus on providing differentiated, digitally-enabled lifecycle solutions to our customers. Our portfolio includes industry-leading brands such as Carrier, Viessmann, Toshiba, Automated Logic, Carrier Transicold, Kidde, Edwards and LenelS2 that offer innovative heating, ventilating and air conditioning ("HVAC"), refrigeration, fire, security and building automation technologies to help make the world safer and more comfortable. We also provide a broad array of related building services, including audit, design, installation, system integration, repair, maintenance and monitoring. Our operations are classified into three segments: HVAC, Refrigeration and Fire & Security.

[0001783180-24-000044:mdna:5]
[same as prior period, unchanged from 0001783180-23-000065:mdna:5]

[0001783180-24-000044:mdna:6]
[same as prior period, unchanged from 0001783180-23-000065:mdna:6]

[0001783180-24-000044:mdna:7]
[same as prior period, unchanged from 0001783180-23-000065:mdna:7]

[0001783180-24-000044:mdna:8]
Acquisition of Viessmann Climate Solutions

[0001783180-24-000044:mdna:9]
On April 25, 2023, we announced that we entered into a Share Purchase Agreement (the “Agreement”) to acquire the climate solutions business (the "VCS Business") of Viessmann Group GmbH & Co. KG (“Viessmann”), a privately-held company. The VCS Business develops intelligent, integrated and sustainable technologies, including heat pumps, boilers, photovoltaic systems, home battery storage and digital solutions, primarily for residential customers in Europe. The acquisition was completed on January 2, 2024. As a result, the assets, liabilities and results of operations of the VCS Business are consolidated in the accompanying Unaudited Condensed Consolidated Financial Statements as of the date of acquisition and reported within our HVAC segment.

[0001783180-24-000044:mdna:10]
Portfolio Transformation

[0001783180-24-000044:mdna:11]
On April 25, 2023, we announced plans to exit our Fire & Security and Commercial Refrigeration businesses over the course of 2024. On December 7, 2023, we entered into a stock purchase agreement to sell our Access Solutions business ("Access Solutions") to Honeywell International Inc. for an enterprise value of approximately $4.95 billion. Access Solutions, historically reported in our Fire & Security segment, is a global supplier of physical security and digital access solutions supporting the hospitality, commercial, education and military markets. On December 12, 2023, we entered into a stock purchase agreement to sell our Commercial Refrigeration business ("CCR") to Haier Group Corporation for an enterprise value of approximately $775 million. CCR, historically reported in our Refrigeration segment, is a global supplier of turnkey solutions for commercial refrigeration systems and services, with a primary focus on serving food retail customers, cold storage facilities and warehouses. On March 5, 2024, we entered into a stock purchase agreement to sell our Industrial Fire business ("Industrial Fire") to Sentinel Capital Partners for an enterprise value of approximately $1.425 billion. Industrial Fire, historically reported in our Fire & Security segment, is a leading manufacturer of a full spectrum of fire detection and suppression solutions and services in critical high-hazard environments, including oil and gas, power generation, marine and offshore facilities, automotive, data centers and aircraft hangars. These transactions are expected to close in 2024.

[0001783180-24-000044:mdna:12]
32

[0001783180-24-000044:mdna:13]
[same as prior period, unchanged from 0001783180-23-000065:mdna:13]

[0001783180-24-000044:mdna:14]
[same as prior period, unchanged from 0001783180-23-000065:mdna:14]

[0001783180-24-000044:mdna:15]
[same as prior period, unchanged from 0001783180-23-000065:mdna:19]

[0001783180-24-000044:mdna:16]
Preparation of our financial statements requires management to make estimates and assumptions that affect the reported amounts of assets, liabilities, sales and expenses. We believe that the most complex and sensitive judgments, because of their potential significance to the accompanying Unaudited Condensed Consolidated Financial Statements, result primarily from the need to make estimates about the effects of matters that are inherently uncertain. In "Management’s Discussion and Analysis of Financial Condition and Results of Operations" of our 2023 Form 10-K, we describe the significant accounting estimates and policies used in the preparation of the accompanying Unaudited Condensed Consolidated Financial Statements. Except as noted below, there have been no significant changes in our critical accounting estimates.

[0001783180-24-000044:mdna:17]
Business Combinations

[0001783180-24-000044:mdna:18]
In accordance with ASC 805, Business Combinations ("ASC 805"), acquisitions that meet the definition of a business are recorded using the acquisition method of accounting. We recognize and measure the identifiable assets acquired, liabilities assumed and any non-controlling interest as of the acquisition date at fair value. The valuation of intangible assets is determined by an income approach methodology, using assumptions such as projected future revenues, customer attrition rates, royalty rates, tax rates and discount rates. The excess, if any, of total consideration transferred in a business combination over the fair value of identifiable assets acquired, liabilities assumed and any non-controlling interest is recognized as goodwill. Costs incurred as a result of a business combination other than costs related to the issuance of debt or equity securities are recorded in the period the costs are incurred.

[0001783180-24-000044:mdna:19]
[same as prior period, unchanged from 0001783180-23-000065:mdna:21]

[0001783180-24-000044:mdna:20]
Three Months Ended March 31, 2024 Compared with the Three Months Ended March 31, 2023

[0001783180-24-000044:mdna:21]
[same as prior period, unchanged from 0001783180-23-000065:mdna:24]

[0001783180-24-000044:mdna:22]
|  |  | Three Months Ended March 31, |
| (In millions) |  | 2024 |  | 2023 |  | Period Change |  | % Change |
| Net sales |  | $ | 6,182 |  |  | $ | 5,273 |  |  | $ | 909 |  |  | 17 | % |
| Cost of products and services sold |  | (4,477) |  |  | (3,895) |  |  | (582) |  |  | 15 | % |
| Gross margin |  | 1,705 |  |  | 1,378 |  |  | 327 |  |  | 24 | % |
| Operating expenses |  | (1,205) |  |  | (823) |  |  | (382) |  |  | 46 | % |
| Operating profit |  | 500 |  |  | 555 |  |  | (55) |  |  | (10) | % |
| Non-operating income (expense), net |  | (165) |  |  | (46) |  |  | (119) |  |  | 259 | % |
| Income from operations before income taxes |  | 335 |  |  | 509 |  |  | (174) |  |  | (34) | % |
| Income tax expense |  | (46) |  |  | (122) |  |  | 76 |  |  | (62) | % |
| Net income from operations |  | 289 |  |  | 387 |  |  | (98) |  |  | (25) | % |
| Less: Non-controlling interest in subsidiaries' earnings from operations |  | 20 |  |  | 14 |  |  | 6 |  |  | 43 | % |
| Net income attributable to common shareowners |  | $ | 269 |  |  | $ | 373 |  |  | $ | (104) |  |  | (28) | % |

[0001783180-24-000044:mdna:23]
[same as prior period, unchanged from 0001783180-23-000065:mdna:26]

[0001783180-24-000044:mdna:24]
For the three months ended March 31, 2024, Net sales were $6.2 billion, a 17% increase compared with the same period of 2023. The components of the year-over-year change were as follows:

[0001783180-24-000044:mdna:25]
|  |  | Three Months Ended March 31, 2024 |
| Organic |  | 2 | % |
| Foreign currency translation |  | — | % |
| Acquisitions and divestitures, net |  | 15 | % |
| Total % change |  | 17 | % |

[0001783180-24-000044:mdna:26]
Organic sales for the three months ended March 31, 2024, increased by 2% compared with the same period of 2023. The organic increase was primarily driven by our HVAC segment due to improved end-markets in the Americas, which more than offset reduced end-market demand in EMEA and Asia. In addition, our Fire & Security segment benefited from volume growth and price improvements in both the Commercial and Residential fire and Industrial fire businesses. Refrigeration results decreased as each of the segment's businesses experienced challenges in certain end-markets during the quarter. Refer to "Segment Review" below for a discussion of Net sales by segment.

[0001783180-24-000044:mdna:27]
On January 2, 2024, we acquired the VCS Business, a leading manufacturer of high efficiency heating and renewable energy systems in Europe. The results of the VCS Business have been included in our Unaudited Condensed Consolidated Financial Statements since the date of acquisition. The transaction added 16% to Net sales during the three months ended March 31, 2024, and is included in Acquisitions and divestitures, net.

[0001783180-24-000044:mdna:28]
As of May 14, 2023, we no longer controlled KFI as their activities are subject to review and oversight by the bankruptcy court. Therefore, KFI was deconsolidated and their respective assets and liabilities were derecognized from our Unaudited Condensed Consolidated Financial Statements. The deconsolidation had a 1% impact on Net sales during the three months ended March 31, 2024, and is included in Acquisitions and divestitures, net.

[0001783180-24-000044:mdna:29]
[same as prior period, unchanged from 0001783180-23-000065:mdna:32]

[0001783180-24-000044:mdna:30]
For the three months ended March 31, 2024, gross margin was $1.7 billion, a 24% increase compared with the same period of 2023. The components were as follows:

[0001783180-24-000044:mdna:31]
|  |  | Three Months Ended March 31, |
| (In millions) |  | 2024 |  | 2023 |
| Net sales |  | $ | 6,182 |  |  | $ | 5,273 |  |
| Cost of products and services sold |  | (4,477) |  |  | (3,895) |  |
| Gross margin |  | $ | 1,705 |  |  | $ | 1,378 |  |
| Percentage of net sales |  | 27.6 | % |  | 26.1 | % |

[0001783180-24-000044:mdna:32]
Gross margin increased by $327 million compared with the three months ended March 31, 2023. The main driver of the increase related to ongoing customer demand, pricing improvements and our continued focus on productivity initiatives. Operating results associated with the VCS Business since the date of acquisition further benefited gross margin during the period. As a result, gross margin as a percentage of Net sales increased by 150 basis points compared with the same period of 2023. However, the results of the VCS Business included inventory step-up, backlog amortization and intangible asset amortization resulting from the recognition of acquired assets at fair value. These costs had a 250 basis point unfavorable impact on gross margin as a percentage of Net sales.

[0001783180-24-000044:mdna:33]
[same as prior period, unchanged from 0001783180-23-000065:mdna:36]

[0001783180-24-000044:mdna:34]
For the three months ended March 31, 2024, operating expenses, including Equity method investment net earnings, were $1.2 billion, a 46% increase compared with the same period of 2023. The components were as follows:

[0001783180-24-000044:mdna:35]
|  |  | Three Months Ended March 31, |
| (In millions) |  | 2024 |  | 2023 |
| Selling, general and administrative |  | $ | (985) |  |  | $ | (721) |  |
| Research and development |  | (224) |  |  | (139) |  |
| Equity method investment net earnings |  | 31 |  |  | 44 |  |
| Other income (expense), net |  | (27) |  |  | (7) |  |
| Total operating expenses |  | $ | (1,205) |  |  | $ | (823) |  |
| Percentage of net sales |  | 19.5 | % |  | 15.6 | % |

[0001783180-24-000044:mdna:36]
For the three months ended March 31, 2024, Selling, general and administrative expenses were $985 million, a 37% increase compared with the same period of 2023. The increase is primarily due to incremental expenses associated with the VCS Business since the date of acquisition. In addition, the current period also included $89 million of acquisition and divestiture-related costs compared with $12 million during the three months ended March 31, 2023.

[0001783180-24-000044:mdna:37]
[same as prior period, unchanged from 0001783180-23-000065:mdna:40]

[0001783180-24-000044:mdna:38]
Investments over which we do not exercise control, but have significant influence, are accounted for using the equity method of accounting. For the three months ended March 31, 2024, Equity method investment net earnings were $31 million, a 30% decrease compared with the same period of 2023. The decrease was primarily driven by a $23 million charge associated with the devaluation of U.S. Dollar denominated balances at an HVAC equity investment in Egypt.

[0001783180-24-000044:mdna:39]
Other income (expense), net primarily includes the impact of gains and losses related to the sale of businesses or interests in our equity method investments, foreign currency gains and losses on transactions that are denominated in a currency other than an entity's functional currency and hedging-related activities. In connection with the acquisition of the VCS Business, we recognized a $86 million loss during the three months ended March 31, 2024 on the mark-to-market valuation of our window forward contracts associated with the cash outflows of the Euro-denominated purchase price for the VCS Business. In addition, we recognized a $46 million gain associated with our share of United Technologies Corporation's conclusion of certain income tax matters from their 2017 and 2018 tax audit with the Internal Revenue Service ("IRS").

[0001783180-24-000044:mdna:40]
[same as prior period, unchanged from 0001783180-23-000065:mdna:44]

[0001783180-24-000044:mdna:41]
For the three months ended March 31, 2024, Non-operating income (expense), net was $165 million, a 259% increase compared with the same period of 2023. The components were as follows:

[0001783180-24-000044:mdna:42]
|  |  | Three Months Ended March 31, |
| (In millions) |  | 2024 |  | 2023 |
| Non-service pension (expense) benefit |  | $ | — |  |  | $ | — |  |
| Interest expense |  | $ | (180) |  |  | $ | (71) |  |
| Interest income |  | 15 |  |  | 25 |  |
| Interest (expense) income, net |  | $ | (165) |  |  | $ | (46) |  |
| Non-operating income (expense), net |  | $ | (165) |  |  | $ | (46) |  |

[0001783180-24-000044:mdna:43]
Non-operating income (expense), net includes the results from activities other than normal business operations such as interest expense, interest income and the non-service components of pension and post-retirement obligations. Interest expense is affected by the amount of debt outstanding and the interest rates on that debt. For the three months ended March 31, 2024, Interest expense was $180 million, a 154% increase compared with the same period of 2023. In connection with the acquisition of the VCS Business, we entered into several financing arrangements to fund the cash portion of the Euro-denominated purchase price.

[0001783180-24-000044:mdna:44]
[same as prior period, unchanged from 0001783180-23-000065:mdna:48]

[0001783180-24-000044:mdna:45]
|  |  | Three Months Ended March 31, |
|  |  | 2024 |  | 2023 |
| Effective tax rate |  | 13.7 | % |  | 24.0 | % |

[0001783180-24-000044:mdna:46]
We account for income tax expense in accordance with ASC 740, which requires an estimate of the annual effective income tax rate for the full year to be applied to the respective interim period, taking into account year-to-date amounts and projected results for the full year. The effective tax rate was 13.7% for the three months ended March 31, 2024, compared with 24.0% for the three months ended March 31, 2023. The year-over-year decrease was primarily driven by a tax benefit of $21 million associated with United Technologies Corporation's conclusion of certain income tax matters from their 2017 and 2018 tax audit with the IRS, a net tax benefit of $19 million related to adjustments to basis differences in certain companies presented as held-for-sale and a net tax benefit of $16 million related to the re-organization and disentanglement of certain Fire & Security industrial businesses in advance of the planned divestitures. These amounts were partially offset by a tax charge of $15 million related to a reduction of utilizable foreign tax credits.

[0001783180-24-000044:mdna:47]
[same as prior period, unchanged from 0001783180-23-000065:mdna:83]

[0001783180-24-000044:mdna:48]
[same as prior period, unchanged from 0001783180-23-000065:mdna:84]

[0001783180-24-000044:mdna:49]
[same as prior period, unchanged from 0001783180-23-000065:mdna:85]

[0001783180-24-000044:mdna:50]
[same as prior period, unchanged from 0001783180-23-000065:mdna:86]

[0001783180-24-000044:mdna:51]
[same as prior period, unchanged from 0001783180-23-000065:mdna:87]

[0001783180-24-000044:mdna:52]
[same as prior period, unchanged from 0001783180-23-000065:mdna:88]

[0001783180-24-000044:mdna:53]
Three Months Ended March 31, 2024 Compared with Three Months Ended March 31, 2023

[0001783180-24-000044:mdna:54]
[same as prior period, unchanged from 0001783180-23-000065:mdna:90]

[0001783180-24-000044:mdna:55]
|  |  | Net Sales |  | Operating Profit |  | Operating Profit Margin |
|  |  | Three Months Ended March 31, |  | Three Months Ended March 31, |  | Three Months Ended March 31, |
| (In millions) |  | 2024 |  | 2023 |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| HVAC |  | $ | 4,541 |  |  | $ | 3,622 |  |  | $ | 429 |  |  | $ | 435 |  |  | 9.4 | % |  | 12.0 | % |
| Refrigeration |  | 884 |  |  | 898 |  |  | 97 |  |  | 108 |  |  | 11.0 | % |  | 12.0 | % |
| Fire & Security |  | 887 |  |  | 869 |  |  | 153 |  |  | 93 |  |  | 17.2 | % |  | 10.7 | % |
| Total segment |  | $ | 6,312 |  |  | $ | 5,389 |  |  | $ | 679 |  |  | $ | 636 |  |  | 10.8 | % |  | 11.8 | % |

[0001783180-24-000044:mdna:56]
[same as prior period, unchanged from 0001783180-23-000065:mdna:92]

[0001783180-24-000044:mdna:57]
For the three months ended March 31, 2024, Net sales in our HVAC segment were $4.5 billion, a 25% increase compared with the same period of 2023. The components of the year-over-year change were as follows:

[0001783180-24-000044:mdna:58]
|  |  | Net Sales |
| Organic |  | 2 | % |
| Foreign currency translation |  | (1) | % |
| Acquisitions and divestitures, net |  | 24 | % |
| Total % change in Net sales |  | 25 | % |

[0001783180-24-000044:mdna:59]
The organic increase in Net sales of 2% was driven by continued strong results in the segment. Growth in the Americas (up 6%) were primarily driven by our Commercial and Light commercial businesses which benefited from ongoing customer demand and pricing improvements. Growth was partially offset by volume reductions in our Residential business. EMEA (down 10%) was impacted by lower customer demand in residential markets. The reduction was partially offset by strong ongoing customer demand and pricing improvements in commercial markets. Asia (flat) was impacted by lower demand in Japan, offset by improved results in China.

[0001783180-24-000044:mdna:60]
On January 2, 2024, we acquired the VCS Business, a leading manufacturer of high efficiency heating and renewable energy systems in Europe. The results of the VCS Business have been included in our Unaudited Condensed Consolidated Financial Statements since the date of acquisition. The transaction added 24% to Net sales during the three months ended March 31, 2024 and is included in Acquisitions and divestitures, net.

[0001783180-24-000044:mdna:61]
For the three months ended March 31, 2024, Operating profit in our HVAC segment was $429 million, a 1% decrease compared with the same period of 2023. The components of the year-over-year change were as follows:

[0001783180-24-000044:mdna:62]
|  |  | Operating Profit |
| Operational |  | 29 | % |
| Acquisitions and divestitures, net |  | 3 | % |
| Restructuring |  | (2) | % |
| Amortization of acquired intangibles |  | (31) | % |
| Total % change in Operating profit |  | (1) | % |

[0001783180-24-000044:mdna:63]
The operational profit increase of 29% was primarily attributable to ongoing customer demand and pricing improvements in certain end-markets compared with the prior year. In addition, favorable material and logistics costs drove productivity benefits in the segment. These benefits more than offset volume reductions in certain end-markets. Segment results were also impacted by lower earnings from equity method investments which included a $23 million charge associated with the devaluation of U.S. Dollar denominated balances at an HVAC equity investment in Egypt.

[0001783180-24-000044:mdna:64]
[same as prior period, unchanged from 0001783180-23-000065:mdna:102]

[0001783180-24-000044:mdna:65]
For the three months ended March 31, 2024, Net sales in our Refrigeration segment were $884 million, a 2% decrease compared with the same period of 2023. The components of the year-over-year change were as follows:

[0001783180-24-000044:mdna:66]
|  |  | Net Sales |
| Organic |  | (2) | % |
| Foreign currency translation |  | — | % |
| Total % change in Net sales |  | (2) | % |

[0001783180-24-000044:mdna:67]
Organic Net sales decreased 2% compared with the prior year as the segment experienced challenges in certain end-markets during the period. Results for Commercial refrigeration decreased (down 3%) compared with the prior year, primarily driven by lower volumes in Europe as economic conditions and inflationary cost pressures impacted end-market demand. In addition, Asia was impacted by reduced end-market demand in China. Transport refrigeration results decreased (down 3%) compared to the prior year as lower end-market demand in North America more than offset improved results in Europe and Asia. In addition, the year-over-year decrease was partially offset by strong container end-markets.

[0001783180-24-000044:mdna:68]
For the three months ended March 31, 2024, Operating profit in our Refrigeration segment was $97 million, a 10% decrease compared with the same period of 2023. The components of the year-over-year change were as follows:

[0001783180-24-000044:mdna:69]
|  |  | Operating Profit |
| Operational |  | 12 | % |
| Acquisitions and divestitures, net |  | (1) | % |
| Restructuring |  | 3 | % |
| Other |  | (24) | % |
| Total % change in Operating profit |  | (10) | % |

[0001783180-24-000044:mdna:70]
The increase in operational profit of 12% was primarily driven by favorable productivity initiatives and price improvements compared with the prior year. In addition, volume growth in certain end-markets further benefited the segment. These amounts were partially offset by volume reductions in certain end-markets. Inflationary cost pressures are moderating but continue to impact our operating profit. Amounts reported in Other represent a $24 million gain on the sale of a business within Transport refrigeration in the prior year.

[0001783180-24-000044:mdna:71]
[same as prior period, unchanged from 0001783180-23-000065:mdna:109]

[0001783180-24-000044:mdna:72]
For the three months ended March 31, 2024, Net sales in our Fire & Security segment were $887 million, a 2% increase compared with the same period of 2023. The components of the year-over-year change were as follows:

[0001783180-24-000044:mdna:73]
|  |  | Net Sales |
| Organic |  | 7 | % |
| KFI deconsolidation |  | (5) | % |
| Total % change in Net sales |  | 2 | % |

[0001783180-24-000044:mdna:74]
The organic increase in Net sales of 7% was primarily driven by volume growth and price improvements compared with the prior year. Increased sales in our Commercial and Residential fire business benefited from ongoing customer demand and price improvements in the Americas and Europe. Growth in our Global Industrial business was driven by strong end-market demand and pricing improvements.

[0001783180-24-000044:mdna:75]
For the three months ended March 31, 2024, Operating profit in our Fire & Security segment was $153 million, a 65% increase compared with the same period of 2023. The components of the year-over-year change were as follows:

[0001783180-24-000044:mdna:76]
|  |  | Operating Profit |
| Operational |  | 75 | % |
| Restructuring |  | 6 | % |
| KFI deconsolidation |  | (14) | % |
| Other |  | (2) | % |
| Total % change in Operating profit |  | 65 | % |

[0001783180-24-000044:mdna:77]
The increase in operational profit of 75% was primarily driven by volume growth and price improvements compared with the prior year. In addition, favorable material and logistics costs drove productivity benefits during the period. The segment also benefited from lower inventory-related reserves compared with the prior year as supply chain challenges improved. In addition, lower depreciation and amortization, which was ceased on held-for-sale assets in accordance with ASC 360, Property, Plant and Equipment, further benefited operational profit. These amounts were partially offset by lower volumes in certain end-markets. Inflationary cost pressures are moderating but continue to impact our operating profit.

[0001783180-24-000044:mdna:78]
[same as prior period, unchanged from 0001783180-23-000065:mdna:145]

[0001783180-24-000044:mdna:79]
[same as prior period, unchanged from 0001783180-23-000065:mdna:146]

[0001783180-24-000044:mdna:80]
As of March 31, 2024, we had cash and cash equivalents of $1.3 billion, of which approximately 96% was held by our foreign subsidiaries. We manage our worldwide cash requirements by reviewing available funds and the cost effectiveness with which we can access funds held by foreign subsidiaries. On occasion, we are required to maintain cash deposits in connection with contractual obligations related to acquisitions, divestitures or other legal obligations. As of March 31, 2024 and December 31, 2023, the amount of such restricted cash was approximately $4 million and $2 million, respectively.

[0001783180-24-000044:mdna:81]
[same as prior period, unchanged from 0001783180-23-000065:mdna:150]

[0001783180-24-000044:mdna:82]
We believe that our available cash and operating cash flows will be sufficient to meet our future operating cash needs. Our committed credit facilities and access to the debt and equity markets provide additional sources of short-term and long-term capital to fund current operations, debt maturities and future investment opportunities. Although we believe that the arrangements currently in place permit us to finance our operations on acceptable terms and conditions, our access to and the availability of financing on acceptable terms and conditions in the future will be impacted by many factors, including: (1) our credit ratings or absence of credit ratings, (2) the level of our existing indebtedness, (3) the restrictions under our debt agreements, (4) the liquidity of the overall capital markets and (5) the state of the economy. There can be no assurance that we will be able to obtain additional financing on terms favorable to us, if at all.

[0001783180-24-000044:mdna:83]
[same as prior period, unchanged from 0001783180-23-000065:mdna:152]

[0001783180-24-000044:mdna:84]
| (In millions) |  | March 31,2024 |  | December 31,2023 |
| Cash and cash equivalents |  | $ | 1,313 |  |  | $ | 10,015 |  |
| Total debt |  | $ | 16,895 |  |  | $ | 14,293 |  |
| Total equity |  | $ | 11,906 |  |  | $ | 9,005 |  |
| Net debt (total debt less cash and cash equivalents) |  | $ | 15,582 |  |  | $ | 4,278 |  |
| Total capitalization (total debt plus total equity) |  | $ | 28,801 |  |  | $ | 23,298 |  |
| Net capitalization (total debt plus total equity less cash and cash equivalents) |  | $ | 27,488 |  |  | $ | 13,283 |  |
| Total debt to total capitalization |  | 59 | % |  | 61 | % |
| Net debt to net capitalization |  | 57 | % |  | 32 | % |

[0001783180-24-000044:mdna:85]
Acquisition of the VCS Business

[0001783180-24-000044:mdna:86]
On April 25, 2023, we announced that we entered into an Agreement to acquire the VCS Business. Under the terms of the Agreement, 20% of the purchase price was to be paid in Carrier common stock, issued directly to Viessmann and subject to certain lock-up provisions and 80% was to be paid in cash. Simultaneously, we entered into commitment letters with JPMorgan Chase Bank, N.A., BofA Securities, Inc. and Bank of America, N.A. to provide a €8.2 billion senior unsecured bridge term loan facility (the "Bridge Loan") to fund a portion of the Euro-denominated purchase price.

[0001783180-24-000044:mdna:87]
On May 19, 2023, we entered into a 364-day, $500 million, senior unsecured revolving credit agreement with JPMorgan Chase Bank, N.A., as administrative agent and certain other lenders (the "Revolver"). In addition, we entered into a senior unsecured delayed draw term loan credit agreement with JPMorgan Chase Bank, N.A., as administrative agent and certain other lenders that permits aggregate borrowings of up to €2.3 billion (the "Delayed Draw Facility"). Upon entering into the Delayed Draw Facility, the aggregate principal amount of the Bridge Loan was reduced by €2.3 billion. In November 2023, we issued $3.0 billion principal amount of USD-denominated notes ("USD Notes") and €2.35 billion principal amount of Euro-denominated notes ("Euro Notes"). Upon issuance, the aggregate principal amount of the Bridge Loan was reduced by €5.4 billion. On January 2, 2024, we entered into a 60-day senior unsecured term loan agreement consisting of a Euro-denominated tranche in an aggregate amount of €113 million and a USD-denominated tranche in an aggregate amount of $349 million (the “60-day Loan”). Upon entering into the 60-day Loan, we reduced the final portion of the Bridge Loan by €500 million and subsequently terminated the agreement.

[0001783180-24-000044:mdna:88]
On January 2, 2024, we completed the acquisition of the VCS Business for $14.2 billion. The cash portion of the purchase price was funded through cash on hand, proceeds from the USD Notes and the Euro Notes and borrowings under the Delayed Draw Facility and the 60-day Loan. In addition, proceeds from the Revolver became available upon closing.

[0001783180-24-000044:mdna:89]
[same as prior period, unchanged from 0001783180-23-000065:mdna:154]

[0001783180-24-000044:mdna:90]
We maintain a $2.0 billion unsecured, unsubordinated commercial paper program which we can use for general corporate purposes, including the funding of working capital and potential acquisitions. In addition, we maintain a $2.0 billion revolving credit agreement with various banks (the "Revolving Credit Facility") that matures in May 2028 which supports our commercial paper borrowing program and can be used for general corporate purposes. A ratings-based commitment fee is charged on unused commitments. As of March 31, 2024, we had no borrowings outstanding under our commercial paper program or our Revolving Credit Facility.

[0001783180-24-000044:mdna:91]
Our short-term obligations primarily consist of current maturities of long-term debt. Our long-term obligations primarily consist of long-term notes with maturity dates ranging between 2025 and 2054. Interest payments related to long-term Notes are expected to approximate $708 million per year, reflecting an approximate weighted-average interest rate of 4.22%. Any borrowings from the Revolving Credit Facility are subject to variable interest rates. See Note 5 – Borrowings and Lines of Credit in the Notes to the accompanying Unaudited Condensed Consolidated Financial Statements for additional information regarding the terms of our long-term debt obligations.

[0001783180-24-000044:mdna:92]
The following table presents our credit ratings and outlook as of March 31, 2024:

[0001783180-24-000044:mdna:93]
| Rating Agency |  | Long-term Rating (1) |  | Short-term Rating |  | Outlook (2) (3) |
| Standards & Poor's ("S&P") |  | BBB |  | A2 |  | Positive |
| Moody's Investors Service Inc. ("Moody's") |  | Baa3 |  | P3 |  | Positive |
| Fitch Ratings ("Fitch") |  | BBB |  | F3 |  | Stable |

[0001783180-24-000044:mdna:94]
(1) The long-term rating for S&P was affirmed on May 14, 2021, and for Moody's on March 30, 2022. Fitch's long-term rating was updated in December 2023.

[0001783180-24-000044:mdna:95]
(2) S&P revised its outlook to positive from stable in December 2023.

[0001783180-24-000044:mdna:96]
[same as prior period, unchanged from 0001783180-23-000065:mdna:163]

[0001783180-24-000044:mdna:97]
[same as prior period, unchanged from 0001783180-23-000065:mdna:97]

[0001783180-24-000044:mdna:98]
Portfolio Transformation

[0001783180-24-000044:mdna:99]
On April 25, 2023, we announced plans to exit our Fire & Security and Commercial Refrigeration businesses over the course of 2024. On December 7, 2023, we entered into a stock purchase agreement to sell our Fire & Security Access Solutions business to Honeywell International Inc. for an enterprise value of approximately $4.95 billion. On December 12, 2023, we entered into a stock purchase agreement to sell CCR to Haier Group Corporation for an enterprise value of approximately $775 million. On March 5, 2024, we entered into a stock purchase agreement to sell Industrial Fire to Sentinel Capital Partners for an enterprise value of approximately $1.425 billion. These transactions are expected to close in 2024.

[0001783180-24-000044:mdna:100]
[same as prior period, unchanged from 0001783180-23-000065:mdna:168]

[0001783180-24-000044:mdna:101]
We may repurchase our outstanding common stock from time to time subject to market conditions and at our discretion. Repurchases occur in the open market or through one or more other public or private transactions pursuant to plans complying with Rules 10b5-1 and 10b-18 under the Exchange Act. Since the initial authorization in February 2021, our Board of Directors authorized the repurchase of up to $4.1 billion of our outstanding common stock. As of December 31, 2023, we repurchased 43.5 million shares of common stock for an aggregate purchase price of $2.0 billion, including shares repurchased under an accelerated share repurchase agreement. As a result, we had approximately $2.1 billion remaining under the current authorization at December 31, 2023. Upon announcement of the acquisition of the VCS Business, we temporarily paused our share repurchase program in order to advance our capital allocation strategy.

[0001783180-24-000044:mdna:102]
[same as prior period, unchanged from 0001783180-23-000065:mdna:171]

[0001783180-24-000044:mdna:103]
We paid dividends on common stock during the three months ended March 31, 2024, totaling $159 million. In April 2024, the Board of Directors declared a dividend of $0.19 per share of common stock payable on May 22, 2024 to shareowners of record at the close of business on May 3, 2024.

[0001783180-24-000044:mdna:104]
[same as prior period, unchanged from 0001783180-23-000065:mdna:173]

[0001783180-24-000044:mdna:105]
|  |  | Three Months Ended March 31, |
| (In millions) |  | 2024 |  | 2023 |
| Net cash flows provided by (used in): |  |  |  |  |
| Operating activities |  | $ | 40 |  |  | $ | 120 |  |
| Investing activities |  | (11,081) |  |  | (100) |  |
| Financing activities |  | 2,379 |  |  | (213) |  |
| Effect of foreign exchange rate changes on cash and cash equivalents |  | (68) |  |  | 20 |  |
| Net increase (decrease) in cash and cash equivalents and restricted cash |  | $ | (8,730) |  |  | $ | (173) |  |

[0001783180-24-000044:mdna:106]
Cash flows from operating activities primarily represent inflows and outflows associated with our operations. Primary activities include net income from operations adjusted for non-cash transactions, working capital changes and changes in other assets and liabilities. The year-over-year decrease in net cash provided by operating activities was primarily driven by an increase in working capital balances compared with the prior period. Higher accounts receivable balances due to increased sales and lower account payables impacted working capital. Prior year working capital balances increased due to higher safety stock and supply chain constraints.

[0001783180-24-000044:mdna:107]
Cash flows from investing activities primarily represent inflows and outflows associated with long-term assets. Primary activities include capital expenditures, acquisitions, divestitures and proceeds from the sale of fixed assets. During the three months ended March 31, 2024, net cash used in investing activities was $11.1 billion. The primary driver of the outflow related to the acquisition of the VCS Business, which totaled $10.8 billion, net of cash acquired. Additional investing outflows include $209 million related to settlement of derivatives and $104 million of capital expenditures. During the three months ended March 31, 2023, net cash used in investing activities was $100 million. The primary driver of the outflow related to $70 million of capital expenditures. In addition, we settled working capital and other transaction-related items associated with the acquisition of Toshiba Carrier Corporation and invested in several businesses. These amounts totaled $52 million, net of cash acquired and were partially offset by the proceeds from the sale of a business during the period.

[0001783180-24-000044:mdna:108]
Cash flows from financing activities primarily represent inflows and outflows associated with equity or borrowings. During the three months ended March 31, 2024, net cash provided by financing activities was $2.4 billion. The primary driver of the inflow related to the proceeds of borrowings on the Bridge Loan and Delayed Draw Facility which were used to fund the cash portion of the acquisition of the VCS Business. This amount was partially offset by the outflow related to the payment of $159 million in dividends to our common shareowners. During the three months ended March 31, 2023, net cash used in financing activities was $213 million. The primary driver of the outflow related to the payment of $154 million in dividends to our common shareowners. In addition, we paid $62 million to repurchase shares of our common stock.
