# CARR notes — 0001783180-24-000044


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001783180-24-000044:notes:1]
DESCRIPTION OF THE BUSINESS
Carrier Global Corporation (the "Company") is a global leader in intelligent climate and energy solutions with a focus on providing differentiated, digitally-enabled lifecycle solutions to its customers. The Company's portfolio includes industry-leading brands such as Carrier, Viessmann, Toshiba, Automated Logic, Carrier Transicold, Kidde, Edwards and LenelS2 that offer innovative heating, ventilating, air conditioning ("HVAC"), refrigeration, fire, security and building automation technologies to help make the world safer and more comfortable. The Company also provides a broad array of related building services, including audit, design, installation, system integration, repair, maintenance and monitoring. The Company's operations are classified into three segments: HVAC, Refrigeration and Fire & Security.

[0001783180-24-000044:notes:2]
In the opinion of management, the accompanying Unaudited Condensed Consolidated Financial Statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission (the "SEC"). The accompanying Unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for 2023 filed with the SEC on February 6, 2024 (the "2023 Form 10-K").


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001783180-24-000044:notes:3]
BASIS OF PRESENTATION
The Unaudited Condensed Consolidated Financial Statements include all accounts of the Company and its wholly-owned and majority-owned subsidiaries in which it has control. Inter-company accounts and transactions have been eliminated. Related party transactions between the Company and its equity method investees have not been eliminated. Non-controlling interest represents a non-controlling investor's interests in the results of subsidiaries that the Company controls and consolidates.

[0001783180-24-000044:notes:4]
Acquisition of Viessmann Climate Solutions

[0001783180-24-000044:notes:5]
On April 25, 2023, the Company announced that it entered into a Share Purchase Agreement (the “Agreement”) to acquire the climate solutions business (the "VCS Business") of Viessmann Group GmbH & Co. KG (“Viessmann”), a privately-held company. The VCS Business develops intelligent, integrated and sustainable technologies, including heat pumps, boilers, photovoltaic systems, home battery storage and digital solutions, primarily for residential customers in Europe. The acquisition was completed on January 2, 2024. As a result, the assets, liabilities and results of operations of the VCS Business are consolidated in the accompanying Unaudited Condensed Consolidated Financial Statements as of the date of acquisition and reported within the Company’s HVAC segment. See Note 15 – Acquisitions for additional information.

[0001783180-24-000044:notes:6]
Portfolio Transformation

[0001783180-24-000044:notes:7]
On April 25, 2023, the Company announced plans to exit its Fire & Security and Commercial Refrigeration businesses over the course of 2024. On December 7, 2023, the Company entered into a stock purchase agreement to sell its Access Solutions business ("Access Solutions") to Honeywell International Inc. for an enterprise value of approximately $4.95 billion. Access Solutions, historically reported in the Company's Fire & Security segment, is a global supplier of physical security and digital access solutions supporting the hospitality, commercial, education and military markets. On December 12, 2023, the Company entered into a stock purchase agreement to sell its Commercial Refrigeration business ("CCR") to Haier Group Corporation for an enterprise value of approximately $775 million. CCR, historically reported in the Company's Refrigeration segment, is a global supplier of turnkey solutions for commercial refrigeration systems and services, with a primary focus on serving food retail customers, cold storage facilities and warehouses. As a result, the assets and liabilities of each business are presented as held for sale in the accompanying Unaudited Condensed Consolidated Balance Sheet as of March 31, 2024 and December 31, 2023, and recorded at the lower of their carrying value or fair value less estimated cost to sell. See Note 16 - Divestitures for additional information.

[0001783180-24-000044:notes:8]
In addition, the net assets of the Company’s Industrial Fire business ("Industrial Fire") met the criteria to be classified as held for sale during the fourth quarter of 2023. Industrial Fire, historically reported in the Company's Fire & Security segment, is a leading manufacturer of a full spectrum of fire detection and suppression solutions and services in critical high-hazard environments, including oil and gas, power generation, marine and offshore facilities, automotive, data centers and aircraft hangars. As a result, the assets and liabilities of the business are presented as held for sale in the accompanying Unaudited Condensed Consolidated Balance Sheet as of March 31, 2024 and December 31, 2023, and recorded at the lower of their carrying value or fair value less estimated cost to sell. On March 5, 2024, the Company entered into a stock purchase agreement to sell Industrial Fire to Sentinel Capital Partners for an enterprise value of approximately $1.425 billion. See Note 16 - Divestitures for additional information.

[0001783180-24-000044:notes:9]
[same as prior period, unchanged from 0001783180-23-000065:notes:6]

[0001783180-24-000044:notes:10]
[same as prior period, unchanged from 0001783180-23-000065:notes:7]

[0001783180-24-000044:notes:11]
[same as prior period, unchanged from 0001783180-23-000065:notes:13]

[0001783180-24-000044:notes:12]
On April 3, 2020 (the Distribution Date"), United Technologies Corporation ("UTC"), since renamed RTX Corporation ("Raytheon Technologies Corporation" or "RTX"), completed the spin-off of Carrier into an independent, publicly traded company (the "Separation") through a pro-rata distribution (the "Distribution") on a one-for-one basis of all of the outstanding shares of common stock of Carrier to UTC shareowners who held shares of UTC common stock as of the close of business on March 19, 2020, the record date of the Distribution. Following the Separation and Distribution, the Company entered into several agreements with UTC and Otis Worldwide Corporation ("Otis") that govern various aspects of the relationship among the Company, UTC and Otis. As of March 31, 2024, only certain portions of the Tax Matters Agreement ("TMA") remain in effect.

[0001783180-24-000044:notes:13]
[same as prior period, unchanged from 0001783180-23-000065:notes:15]

[0001783180-24-000044:notes:14]
[same as prior period, unchanged from 0001783180-23-000065:notes:16]

[0001783180-24-000044:notes:15]
Recently Issued Accounting Pronouncements

[0001783180-24-000044:notes:16]
In November 2023, the FASB issued ASU 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures (“ASU 2023-07”), which requires public entities to disclose information about their reportable segments’ significant expenses on an interim and annual basis. In addition, the amendments clarify circumstances in which an entity can disclose multiple segment measures of profit or loss, provide new segment disclosure requirements for entities with a single reportable segment and contain other disclosure requirements. ASU 2023-07 is effective for fiscal years beginning after December 15, 2023 and interim periods within fiscal years beginning after December 15, 2024, with early adoption permitted. The Company is currently assessing the impact of this ASU on its financial statements.

[0001783180-24-000044:notes:17]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures ("ASU 2023-09"), which requires public entities to disclose disaggregated information about their effective tax rate reconciliation as well as information on income taxes paid. ASU 2023-09 is effective for fiscal years beginning after December 15, 2023 and interim periods within fiscal years beginning after December 15, 2024, with early adoption permitted. The Company is currently assessing the impact of this ASU on its financial statements.

[0001783180-24-000044:notes:18]
On March 6, 2024, the SEC adopted new rules designed to enhance public company disclosures related to the risks and impacts of climate-related matters. The rules amend the provisions of both Regulation S-K and Regulation S-X and will be required in annual reports and registration statements. Amendments to Regulation S-K require disclosure of climate-related risks, transition plans, targets and goals, risk management and governance. Amendments to Regulation S-X require disclosure of the financial effects of severe weather events and other natural conditions as well as the use of carbon offsets or renewable energy credits. Disclosure requirements will begin phasing in for fiscal years beginning on or after January 1, 2025, subject to legal challenges and the SEC's voluntary stay of the disclosure requirements. The Company will continue to assess the impact of these new rules on its financial statements while the stay is in place.


## us-gaap:InventoryDisclosureTextBlock

[0001783180-24-000044:notes:19]
[same as prior period, unchanged from 0001783180-23-000065:notes:17]

[0001783180-24-000044:notes:20]
[same as prior period, unchanged from 0001783180-23-000065:notes:18]

[0001783180-24-000044:notes:21]
| (In millions) |  | March 31,2024 |  | December 31,2023 |
| Raw materials |  | $ | 979 |  |  | $ | 695 |  |
| Work-in-process |  | 296 |  |  | 259 |  |
| Finished goods |  | 1,914 |  |  | 1,263 |  |
| Inventories, net |  | $ | 3,189 |  |  | $ | 2,217 |  |

[0001783180-24-000044:notes:22]
The Company performs periodic assessments utilizing customer demand, production requirements and historical usage rates to determine the existence of excess and obsolete inventory and records necessary provisions to reduce such inventories to the lower of cost or estimated net realizable value. Raw materials, work-in-process and finished goods are net of valuation reserves of $260 million and $223 million as of March 31, 2024 and December 31, 2023, respectively.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001783180-24-000044:notes:23]
GOODWILL AND INTANGIBLE ASSETS
The Company records goodwill as the excess of the purchase price over the fair value of the net assets acquired in a business combination. Goodwill is tested and reviewed annually for impairment on July 1 or whenever there is a material change in events or circumstances that indicates that the fair value of the reporting unit may be less than its carrying value.

[0001783180-24-000044:notes:24]
The changes in the carrying amount of goodwill were as follows:

[0001783180-24-000044:notes:25]
| (In millions) |  |  | HVAC |  | Refrigeration |  | Fire & Security |  | Total |
| Balance as of December 31, 2023 |  |  | $ | 6,407 |  |  | $ | 1,124 |  |  | $ | 458 |  |  | $ | 7,989 |  |
| Acquisitions (1) |  |  | 7,576 |  |  | — |  |  | — |  |  | 7,576 |  |
| Reclassified to held for sale (2) |  |  | — |  |  | — |  |  | 25 |  |  | 25 |  |
| Foreign currency translation |  |  | (253) |  |  | (22) |  |  | 51 |  |  | (224) |  |
| Balance as of March 31, 2024 |  |  | $ | 13,730 |  |  | $ | 1,102 |  |  | $ | 534 |  |  | $ | 15,366 |  |

[0001783180-24-000044:notes:26]
(1) See Note 15 - Acquisitions for additional information.

[0001783180-24-000044:notes:27]
(2) See Note 16 - Divestitures for additional information.

[0001783180-24-000044:notes:28]
[same as prior period, unchanged from 0001783180-23-000065:notes:23]

[0001783180-24-000044:notes:29]
[same as prior period, unchanged from 0001783180-23-000065:notes:24]

[0001783180-24-000044:notes:30]
|  |  | March 31, 2024 |  | December 31, 2023 |
| (In millions) |  | Gross Amount |  | Accumulated Amortization |  | Net Amount |  | Gross Amount |  | Accumulated Amortization |  | Net Amount |
| Amortized: |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 5,929 |  |  | $ | (730) |  |  | $ | 5,199 |  |  | $ | 1,222 |  |  | $ | (610) |  |  | $ | 612 |  |
| Patents and trademarks |  | 993 |  |  | (175) |  |  | 818 |  |  | 332 |  |  | (163) |  |  | 169 |  |
| Service portfolios and other |  | 1,831 |  |  | (561) |  |  | 1,270 |  |  | 686 |  |  | (503) |  |  | 183 |  |
|  |  | 8,753 |  |  | (1,466) |  |  | 7,287 |  |  | 2,240 |  |  | (1,276) |  |  | 964 |  |
| Unamortized: |  |  |  |  |  |  |  |  |  |  |  |  |
| Trademarks and other |  | 64 |  |  | — |  |  | 64 |  |  | 64 |  |  | — |  |  | 64 |  |
| Intangible assets, net |  | $ | 8,817 |  |  | $ | (1,466) |  |  | $ | 7,351 |  |  | $ | 2,304 |  |  | $ | (1,276) |  |  | $ | 1,028 |  |

[0001783180-24-000044:notes:31]
[same as prior period, unchanged from 0001783180-23-000065:notes:26]

[0001783180-24-000044:notes:32]
|  |  | Three Months Ended March 31, |  |  |
| (In millions) |  | 2024 |  | 2023 |  |  |  |  |
| Amortization expense of Intangible assets |  | $ | 212 |  |  | $ | 64 |  |  |  |  |  |

[0001783180-24-000044:notes:33]
Impairment Assessment

[0001783180-24-000044:notes:34]
On January 1, 2024, the Company reorganized its HVAC segment reporting units due to the VCS Business acquisition. As a result, the Company performed a quantitative goodwill impairment test on its legacy Commercial HVAC, North America residential and light commercial and Global Comfort solutions reporting units prior to the reorganization which did not result in a goodwill impairment. The Company then reassigned goodwill among its new regional reporting units using a relative fair value approach and performed a goodwill impairment assessment which did not result in a goodwill impairment.


## us-gaap:DebtDisclosureTextBlock

[0001783180-24-000044:notes:35]
BORROWINGS AND LINES OF CREDIT
Long-term debt consisted of the following:

[0001783180-24-000044:notes:36]
| (In millions) |  |  |  | March 31,2024 |  | December 31,2023 |
| 2.242% Notes due 2025 (1) |  |  |  | $ | 1,200 |  |  | $ | 1,200 |  |
| 4.375% Notes due 2025 |  |  |  | 812 |  |  | 830 |  |
| 5.800% Notes due 2025 |  |  |  | 1,000 |  |  | 1,000 |  |
| 2.493% Notes due 2027 |  |  |  | 900 |  |  | 900 |  |
| 4.125% Notes due 2028 |  |  |  | 812 |  |  | 830 |  |
| 2.722% Notes due 2030 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.700% Notes due 2031 |  |  |  | 750 |  |  | 750 |  |
| 4.500% Notes due 2032 |  |  |  | 921 |  |  | 941 |  |
| 5.900% Notes due 2034 |  |  |  | 1,000 |  |  | 1,000 |  |
| 3.377% Notes due 2040 |  |  |  | 1,500 |  |  | 1,500 |  |
| 3.577% Notes due 2050 |  |  |  | 2,000 |  |  | 2,000 |  |
| 6.200% Notes due 2054 |  |  |  | 1,000 |  |  | 1,000 |  |
| Total long-term notes |  |  |  | 13,895 |  |  | 13,951 |  |
| Delayed Draw Facility |  |  |  | 2,536 |  |  | — |  |
| Japanese Term Loan Facility |  |  |  | 357 |  |  | 379 |  |
| Other debt (including project financing obligations and finance leases) |  |  |  | 213 |  |  | 74 |  |
| Discounts and debt issuance costs |  |  |  | (106) |  |  | (111) |  |
| Total debt |  |  |  | 16,895 |  |  | 14,293 |  |
| Less: current portion of long-term debt |  |  |  | 1,248 |  |  | 51 |  |
| Long-term debt, net of current portion |  |  |  | $ | 15,647 |  |  | $ | 14,242 |  |

[0001783180-24-000044:notes:37]
(1) 2.242% Notes due February 15, 2025; reclassified to Current portion of long-term debt.

[0001783180-24-000044:notes:38]
Acquisition Funding

[0001783180-24-000044:notes:39]
On January 2, 2024, the Company completed the acquisition of the VCS Business for total consideration of $14.2 billion. Under the terms of the Agreement, 20% of the purchase price was paid in Carrier common stock, issued directly to Viessmann and subject to certain lock up provisions and 80% was paid in cash, subject to working capital and other adjustments. In order to fund the Euro-denominated cash portion of the purchase price, the Company used cash on hand, debt financing and various term loan facilities.

[0001783180-24-000044:notes:40]
Debt Issuance

[0001783180-24-000044:notes:41]
In November 2023, the Company issued $3.0 billion principal amount of USD-denominated notes in three tranches. The tranches consisted of $1.0 billion aggregate principal amount of 5.8% notes due 2025, $1.0 billion aggregate principal amount of 5.90% notes due 2034 and $1.0 billion aggregate principal amount of 6.2% notes due 2054 (collectively, the “USD Notes”). In addition, the Company issued €2.35 billion principal amount of Euro-denominated notes in three tranches. The tranches consisted of €750 million aggregate principal amount of 4.375% notes due 2025, €750 million aggregate principal amount of 4.125% notes due 2028 and €850 million aggregate principal amount of 4.5% notes due 2032 (collectively, the “Euro Notes”). The Company capitalized $51 million of deferred financing costs which are being amortized over the term of their related notes. The notes are subject to certain customary covenants and the Company has the option to redeem the notes in whole or in part at any time, prior to their stated maturity date at the redemption price set forth in the indenture agreements.

[0001783180-24-000044:notes:42]
Bridge Loan

[0001783180-24-000044:notes:43]
On April 25, 2023, the Company entered into commitment letters with JPMorgan Chase Bank, N.A., BofA Securities, Inc. and Bank of America, N.A. to provide a €8.2 billion aggregate principal, senior unsecured bridge term loan facility (the “Bridge Loan”). Euro-denominated borrowings bore interest at the EURIBOR Rate plus a ratings-based margin, USD-denominated borrowings bore interest at either a Term SOFR Rate plus 0.10% and a ratings-based margin or, alternatively, at a base rate plus a ratings-based margin. The Company capitalized $48 million of deferred financing costs associated with the Bridge Loan which were amortized over the commitment period. Upon entering into a senior unsecured delayed draw term loan facility and issuing the USD Notes and the Euro Notes, the Company reduced the Bridge Loan by €7.7 billion and accelerated the amortization on $25 million of deferred financing costs in Interest expense during 2023. On January 2, 2024, the Company entered into a 60-day senior unsecured term loan agreement consisting of a Euro-denominated tranche in an aggregate amount of €113 million and a USD-denominated tranche in an aggregate amount of $349 million (the “60-day Loan”). Upon entering into the 60-day Loan, the Company reduced the final portion of the Bridge Loan by €500 million and subsequently terminated the agreement. As of March 31, 2024, borrowings under the 60-day Loan have been fully repaid.

[0001783180-24-000044:notes:44]
Delayed Draw Facility

[0001783180-24-000044:notes:45]
On May 19, 2023, the Company entered into a senior unsecured delayed draw term loan credit agreement with JPMorgan Chase Bank, N.A., as administrative agent and certain other lenders that permits aggregate borrowings of up to €2.3 billion (the "Delayed Draw Facility"). The facility consists of an 18-month, Euro-denominated tranche in an aggregate amount of €1.15 billion and a 3-year, Euro-denominated tranche in an aggregate amount of €1.15 billion. Euro-denominated borrowings bear interest at the EURIBOR Rate plus a ratings-based margin, USD-denominated borrowings bear interest at either a Term SOFR Rate plus 0.10% and a ratings-based margin or, alternatively, at a base rate plus a ratings-based margin. The Company capitalized $4 million of deferred financing costs which will be amortized over the respective term of the tranches. On January 2, 2024, the Company borrowed the full amount available under the Delayed Draw Facility in U.S. Dollars.

[0001783180-24-000044:notes:46]
364 Day Revolver

[0001783180-24-000044:notes:47]
On May 19, 2023, the Company entered into a 364-day, $500 million, senior unsecured revolving credit agreement with JPMorgan Chase Bank, N.A., as administrative agent and certain other lenders (the “Revolver”), the proceeds of which became available upon closing of the acquisition of the VCS Business. Borrowings bear interest at either a Term SOFR Rate plus 0.10% and a ratings-based margin or, alternatively, at a base rate plus a ratings-based margin. As of March 31, 2024, there were no borrowings outstanding under the Revolver.

[0001783180-24-000044:notes:48]
Japanese Term Loan Facility

[0001783180-24-000044:notes:49]
On July 15, 2022, the Company entered into a five-year, JPY 54 billion (approximately $400 million) senior unsecured term loan facility with MUFG Bank Ltd., as administrative agent and lender, and certain other lenders (the "Japanese Term Loan Facility"). Borrowings under the Japanese Term Loan Facility bear interest at a rate equal to the Tokyo Term Risk Free Rate plus 0.75%. The Company capitalized $2 million of deferred financing costs which are being amortized over its term. On July 25, 2022, the Company borrowed JPY 54 billion under the Japanese Term Loan Facility and used the proceeds to fund a portion of the Yen-denominated purchase price of Toshiba Carrier Corporation ("TCC") and to pay related fees and expenses.

[0001783180-24-000044:notes:50]
Revolving Credit Facility

[0001783180-24-000044:notes:51]
On May 19, 2023, the Company entered into a revolving credit agreement with JPMorgan Chase Bank, N.A., as administrative agent, and certain other lenders, permitting aggregate borrowings of up to $2.0 billion pursuant to an unsecured, unsubordinated revolving credit facility that matures in May 2028 (the "Revolving Credit Facility"). The Revolving Credit Facility supports the Company's commercial paper program and can be used for other general corporate purposes. Borrowings are available in U.S. Dollars and Euros. U.S. Dollar borrowings can bear interest at either a Term SOFR Rate plus 0.10% and a ratings-based margin or, alternatively, at an alternate base rate plus a ratings-based margin. Euro borrowings bear interest at an adjusted EURIBOR rate plus a ratings-based margin. A ratings-based commitment fee is charged on unused commitments. Upon entering into the agreement, the Company terminated its existing revolving credit facility that was set to mature in April 2025. In addition, the Company capitalized $2 million of deferred financing costs which are being amortized over its term. As of March 31, 2024, there were no borrowings outstanding under the Revolving Credit Facility.

[0001783180-24-000044:notes:52]
Commercial Paper Program

[0001783180-24-000044:notes:53]
The Company has a $2.0 billion unsecured, unsubordinated commercial paper program, which can be used for general corporate purposes, including the funding of working capital and potential acquisitions. As of March 31, 2024, there were no borrowings outstanding under the commercial paper program.

[0001783180-24-000044:notes:54]
Project Financing Arrangements

[0001783180-24-000044:notes:55]
The Company is involved in long-term construction contracts in which it arranges project financing with certain customers. As a result, the Company issued $10 million and $5 million of debt during the three months ended March 31, 2024 and 2023, respectively. Long-term debt repayments associated with these financing arrangements during the three months ended March 31, 2024 and 2023 were $5 million and $2 million, respectively.

[0001783180-24-000044:notes:56]
Debt Covenants

[0001783180-24-000044:notes:57]
The Revolving Credit Facility, Revolver, the indenture for the long-term notes and the Japanese Term Loan Facility contain affirmative and negative covenants customary for financings of these types, which, among other things, limit the Company's ability to incur certain liens, to make certain fundamental changes and to enter into sale and leaseback transactions. As of March 31, 2024, the Company was in compliance with the covenants under the agreements governing its outstanding indebtedness.


## us-gaap:FairValueDisclosuresTextBlock

[0001783180-24-000044:notes:58]
[same as prior period, unchanged from 0001783180-23-000065:notes:44]

[0001783180-24-000044:notes:59]
[same as prior period, unchanged from 0001783180-23-000065:notes:45]

[0001783180-24-000044:notes:60]
[same as prior period, unchanged from 0001783180-23-000065:notes:46]

[0001783180-24-000044:notes:61]
[same as prior period, unchanged from 0001783180-23-000065:notes:47]

[0001783180-24-000044:notes:62]
[same as prior period, unchanged from 0001783180-23-000065:notes:48]

[0001783180-24-000044:notes:63]
[same as prior period, unchanged from 0001783180-23-000065:notes:49]

[0001783180-24-000044:notes:64]
During 2022, the Company entered into cross currency swaps with various financial institutions to fund a portion of the Yen-denominated purchase price of TCC. The cross currency swaps are measured at fair value on a recurring basis using observable market inputs, such as forward, discount and interest rates as well as credit default swap spreads. The Company designated the cross currency swaps as a partial hedge of its investment in certain subsidiaries whose functional currency is the Japanese Yen in order to manage foreign currency translation risk. As a result, changes in the fair value of the swaps are recorded in Equity in the accompanying Unaudited Condensed Consolidated Balance Sheet. From time to time, the Company settles and enters into new cross currency swaps with the same purpose and characteristics as initially established.

[0001783180-24-000044:notes:65]
[same as prior period, unchanged from 0001783180-23-000065:notes:51]

[0001783180-24-000044:notes:66]
During 2023, the Company entered into window forward contracts with Bank of America N.A. and JPMorgan Chase Bank N.A. to mitigate the foreign currency risk of the expected cash outflows associated with the Euro-denominated purchase price of the VCS Business. The instruments had an aggregate notional amount of €7 billion and a settlement window between November 28, 2023 and February 27, 2024. The window forward contracts were measured at fair value on a recurring basis using observable market inputs, such as forward, discount and interest rates with changes in fair value reported in Other income (expense), net in the accompanying Unaudited Condensed Consolidated Statement of Operations. During the three months ended March 31, 2024, the Company recognized a $86 million loss on the mark-to-market valuation of its window forward contracts. The Company settled the window forward contracts on January 2, 2024 upon the acquisition of the VCS Business.

[0001783180-24-000044:notes:67]
During 2023, the Company entered into several interest rate swap contracts to mitigate interest rate exposure on the forecasted issuance of long-term debt. The contracts had an aggregate notional amount of $1.525 billion and were designated as cash flow hedges with changes in fair value reported in Equity in the accompanying Unaudited Condensed Consolidated Balance Sheet. Fair value was measured on a recurring basis using observable market inputs, such as forward, discount and interest rates. In November 2023, the contracts were settled upon the issuance of the underlying debt. As a result, the Company deferred a net unrecognized gain of $58 million in Equity which will be subsequently recognized in Interest expense over the term of the related notes which range from 2034 to 2044. The amount expected to be amortized during 2024 is a net gain of $5 million.

[0001783180-24-000044:notes:68]
[same as prior period, unchanged from 0001783180-23-000065:notes:54]

[0001783180-24-000044:notes:69]
| (In millions) |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |
| March 31, 2024 |  |  |  |  |  |  |  |  |
| Derivative assets (1)(3) |  | $ | 32 |  |  | $ | — |  |  | $ | 32 |  |  | $ | — |  |
| Derivative liabilities (2)(3) |  | $ | (17) |  |  | $ | — |  |  | $ | (17) |  |  | $ | — |  |
| December 31, 2023 |  |  |  |  |  |  |  |  |
| Derivative assets (1) (3) |  | $ | 32 |  |  | $ | — |  |  | $ | 32 |  |  | $ | — |  |
| Derivative liabilities (2) (3) |  | $ | (126) |  |  | $ | — |  |  | $ | (126) |  |  | $ | — |  |

[0001783180-24-000044:notes:70]
[same as prior period, unchanged from 0001783180-23-000065:notes:56]

[0001783180-24-000044:notes:71]
[same as prior period, unchanged from 0001783180-23-000065:notes:57]

[0001783180-24-000044:notes:72]
(3) Includes cross currency swaps and window forward contracts (which were settled on January 2, 2024).

[0001783180-24-000044:notes:73]
[same as prior period, unchanged from 0001783180-23-000065:notes:59]

[0001783180-24-000044:notes:74]
|  |  | March 31, 2024 |  | December 31, 2023 |  |
| (In millions) |  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  |
| Total long-term Notes (1) |  | $ | 13,895 |  |  | $ | 12,873 |  |  | $ | 13,951 |  |  | $ | 13,194 |  |  |

[0001783180-24-000044:notes:75]
[same as prior period, unchanged from 0001783180-23-000065:notes:61]

[0001783180-24-000044:notes:76]
[same as prior period, unchanged from 0001783180-23-000065:notes:62]


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0001783180-24-000044:notes:77]
[same as prior period, unchanged from 0001783180-23-000065:notes:63]


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001783180-24-000044:notes:78]
EMPLOYEE BENEFIT PLANS
The Company sponsors U.S. and international defined benefit pension and defined contribution plans. In addition, the Company contributes to various U.S. and international multi-employer defined benefit pension plans.

[0001783180-24-000044:notes:79]
Contributions to the plans were as follows:

[0001783180-24-000044:notes:80]
|  |  | Three Months Ended March 31, |  |  |
| (In millions) |  | 2024 |  | 2023 |  |  |  |  |
| Defined benefit plans |  | $ | 6 |  |  | $ | 6 |  |  |  |  |  |
| Defined contribution plans |  | $ | 39 |  |  | $ | 37 |  |  |  |  |  |
| Multi-employer pension plans |  | $ | 4 |  |  | $ | 4 |  |  |  |  |  |

[0001783180-24-000044:notes:81]
[same as prior period, unchanged from 0001783180-23-000065:notes:67]

[0001783180-24-000044:notes:82]
|  |  | Three Months Ended March 31, |  |  |
| (In millions) |  | 2024 |  | 2023 |  |  |  |  |
| Service cost |  | $ | 4 |  |  | $ | 4 |  |  |  |  |  |
| Interest cost |  | 7 |  |  | 8 |  |  |  |  |  |
| Expected return on plan assets |  | (7) |  |  | (8) |  |  |  |  |  |
| Net periodic pension expense (benefit) |  | $ | 4 |  |  | $ | 4 |  |  |  |  |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001783180-24-000044:notes:83]
[same as prior period, unchanged from 0001783180-23-000065:notes:69]

[0001783180-24-000044:notes:84]
[same as prior period, unchanged from 0001783180-23-000065:notes:70]

[0001783180-24-000044:notes:85]
[same as prior period, unchanged from 0001783180-23-000065:notes:71]

[0001783180-24-000044:notes:86]
|  |  | Three Months Ended March 31, |  |  |
| (In millions) |  | 2024 |  | 2023 |  |  |  |  |
| Equity compensation costs - equity settled |  | $ | 22 |  |  | $ | 22 |  |  |  |  |  |
| Equity compensation costs - cash settled (1) |  | — |  |  | 1 |  |  |  |  |  |
| Total stock-based compensation expense |  | $ | 22 |  |  | $ | 23 |  |  |  |  |  |

[0001783180-24-000044:notes:87]
[same as prior period, unchanged from 0001783180-23-000065:notes:73]


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001783180-24-000044:notes:88]
PRODUCT WARRANTIES
In the ordinary course of business, the Company provides standard warranty coverage on its products. Provisions for these amounts are established at the time of sale and estimated primarily based on product warranty terms and historical claims experience. In addition, the Company incurs discretionary costs to service its products in connection with specific product performance issues. Provisions for these amounts are established when they are known and estimable. The Company assesses the adequacy of its initial provisions and will make adjustments as necessary based on known or anticipated claims or as new information becomes available that suggests it is probable that future costs will be different than estimated amounts. Amounts associated with these provisions are classified on the accompanying Unaudited Condensed Consolidated Balance Sheet as Accrued liabilities or Other long-term liabilities based on their anticipated settlement date.

[0001783180-24-000044:notes:89]
The changes in the carrying amount of warranty related provisions are as follows:

[0001783180-24-000044:notes:90]
|  |  | Three Months Ended March 31, |
| (In millions) |  | 2024 |  | 2023 |
| Balance as of January 1, |  | $ | 570 |  |  | $ | 552 |  |
| Warranties, performance guarantees issued and changes in estimated liability |  | 91 |  |  | 54 |  |
| Settlements made |  | (57) |  |  | (45) |  |
| Other |  | (4) |  |  | 2 |  |
| Acquisitions (1) |  | 202 |  |  | — |  |
| Balance as of March 31, |  | $ | 802 |  |  | $ | 563 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001783180-24-000044:notes:91]
EQUITY
The authorized number of shares of common stock of Carrier is 4,000,000,000 shares of $0.01 par value. As of March 31, 2024 and December 31, 2023, 944,433,341 and 883,068,393 shares of common stock were issued, respectively, which includes 43,490,981 shares of treasury stock, for both periods respectively.

[0001783180-24-000044:notes:92]
[same as prior period, unchanged from 0001783180-23-000065:notes:77]

[0001783180-24-000044:notes:93]
The Company may repurchase its outstanding common stock from time to time subject to market conditions and at the Company's discretion. Repurchases occur in the open market or through one or more other public or private transactions pursuant to plans complying with Rules 10b5-1 and 10b-18 under the Exchange Act. Shares acquired are recognized at cost and presented separately on the balance sheet as a reduction to Equity. Since the initial authorization in February 2021, the Company's Board of Directors authorized the repurchase of up to $4.1 billion of the Company's outstanding common stock.

[0001783180-24-000044:notes:94]
As of December 31, 2023, the Company repurchased 43.5 million shares of common stock for an aggregate purchase price of $2.0 billion, including shares repurchased under an accelerated share repurchase agreement. As a result, the Company had approximately $2.1 billion remaining under the current authorization at December 31, 2023. Upon announcement of the proposed acquisition of the VCS Business, the Company temporarily paused its share repurchase program in order to advance its capital allocation strategy. As a result, there is no share repurchase activity during the three months ended March 31, 2024.

[0001783180-24-000044:notes:95]
[same as prior period, unchanged from 0001783180-23-000065:notes:80]

[0001783180-24-000044:notes:96]
A summary of changes in the components of Accumulated other comprehensive income (loss) for the three months ended March 31, 2024 is as follows:

[0001783180-24-000044:notes:97]
| (In millions) |  | Foreign Currency Translation |  | Defined Benefit Pension and Post-retirement Plans |  |  |  | Unrealized Hedging Gains (Losses) |  | Accumulated Other Comprehensive Income (Loss) |
| Balance as of December 31, 2023 |  | $ | (1,444) |  |  | $ | (100) |  |  |  |  | $ | 58 |  |  | $ | (1,486) |  |
| Other comprehensive income (loss) before reclassifications, net |  | (385) |  |  | — |  |  |  |  | — |  |  | (385) |  |
| Amounts reclassified, pre-tax |  | — |  |  | — |  |  |  |  | (1) |  |  | (1) |  |
| Balance as of March 31, 2024 |  | $ | (1,829) |  |  | $ | (100) |  |  |  |  | $ | 57 |  |  | $ | (1,872) |  |

[0001783180-24-000044:notes:98]
A summary of changes in the components of Accumulated other comprehensive income (loss) for the three months ended March 31, 2023 is as follows:

[0001783180-24-000044:notes:99]
| (In millions) |  | Foreign Currency Translation |  | Defined Benefit Pension and Post-retirement Plans |  |  |  | Unrealized Hedging Gains (Losses) |  | Accumulated Other Comprehensive Income (Loss) |
| Balance as of December 31, 2022 |  | $ | (1,604) |  |  | $ | (84) |  |  |  |  | $ | — |  |  | $ | (1,688) |  |
| Other comprehensive income (loss) before reclassifications, net |  | 52 |  |  | — |  |  |  |  | — |  |  | 52 |  |
| Balance as of March 31, 2023 |  | $ | (1,552) |  |  | $ | (84) |  |  |  |  | $ | — |  |  | $ | (1,636) |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001783180-24-000044:notes:100]
REVENUE RECOGNITION
The Company accounts for revenue in accordance with ASC 606: Revenue from Contracts with Customers. Revenue is recognized when control of a good or service promised in a contract (i.e., performance obligation) is transferred to a customer. Control is obtained when a customer has the ability to direct the use of and obtain substantially all of the remaining benefits from that good or service. A significant portion of the Company's performance obligations are recognized at a point-in-time when control of the product transfers to the customer, which is generally at the time of shipment. The remaining portion of the Company’s performance obligations are recognized over time as the customer simultaneously obtains control as the Company performs work under a contract, or if the product being produced for the customer has no alternative use and the Company has a contractual right to payment.

[0001783180-24-000044:notes:101]
Sales disaggregated by product and service are as follows:

[0001783180-24-000044:notes:102]
|  |  | Three Months Ended March 31, |  |  |
| (In millions) |  | 2024 |  | 2023 |  |  |  |  |
| Sales Type |  |  |  |  |  |  |  |  |
| Product |  | $ | 4,073 |  |  | $ | 3,201 |  |  |  |  |  |
| Service |  | 468 |  |  | 421 |  |  |  |  |  |
| HVAC sales |  | 4,541 |  |  | 3,622 |  |  |  |  |  |
| Product |  | 772 |  |  | 787 |  |  |  |  |  |
| Service |  | 112 |  |  | 111 |  |  |  |  |  |
| Refrigeration sales |  | 884 |  |  | 898 |  |  |  |  |  |
| Product |  | 825 |  |  | 813 |  |  |  |  |  |
| Service |  | 62 |  |  | 56 |  |  |  |  |  |
| Fire & Security sales |  | 887 |  |  | 869 |  |  |  |  |  |
| Total segment sales |  | 6,312 |  |  | 5,389 |  |  |  |  |  |
| Eliminations and other |  | (130) |  |  | (116) |  |  |  |  |  |
| Net sales |  | $ | 6,182 |  |  | $ | 5,273 |  |  |  |  |  |

[0001783180-24-000044:notes:103]
[same as prior period, unchanged from 0001783180-23-000065:notes:87]

[0001783180-24-000044:notes:104]
[same as prior period, unchanged from 0001783180-23-000065:notes:88]

[0001783180-24-000044:notes:105]
| (In millions) |  | March 31,2024 |  | December 31,2023 |
| Contract assets, current |  | $ | 320 |  |  | $ | 306 |  |
| Contract assets, non-current (included within Other assets) |  | 30 |  |  | 26 |  |
| Total contract assets |  | 350 |  |  | 332 |  |
| Contract liabilities, current |  | (501) |  |  | (425) |  |
| Contract liabilities, non-current (included within Other long-term liabilities) |  | (157) |  |  | (160) |  |
| Total contract liabilities |  | (658) |  |  | (585) |  |
| Net contract assets (liabilities) |  | $ | (308) |  |  | $ | (253) |  |

[0001783180-24-000044:notes:106]
[same as prior period, unchanged from 0001783180-23-000065:notes:90]

[0001783180-24-000044:notes:107]
The Company recognized revenue of $345 million during the three months ended March 31, 2024 that related to contract liabilities as of January 1, 2024. The Company expects a majority of its current contract liabilities at the end of the period to be recognized as revenue in the next 12 months.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0001783180-24-000044:notes:108]
The Company accounts for revenue in accordance with ASC 606: Revenue from Contracts with Customers. Revenue is recognized when control of a good or service promised in a contract (i.e., performance obligation) is transferred to a customer. Control is obtained when a customer has the ability to direct the use of and obtain substantially all of the remaining benefits from that good or service. A significant portion of the Company's performance obligations are recognized at a point-in-time when control of the product transfers to the customer, which is generally at the time of shipment. The remaining portion of the Company’s performance obligations are recognized over time as the customer simultaneously obtains control as the Company performs work under a contract, or if the product being produced for the customer has no alternative use and the Company has a contractual right to payment.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001783180-24-000044:notes:109]
RESTRUCTURING COSTS
The Company incurs costs associated with restructuring initiatives intended to improve operating performance, profitability and working capital levels. Actions associated with these initiatives may include improving productivity, workforce reductions and the consolidation of facilities. Due to the size, nature and frequency of these discrete plans, they are fundamentally different from the Company's ongoing productivity actions.

[0001783180-24-000044:notes:110]
[same as prior period, unchanged from 0001783180-23-000065:notes:94]

[0001783180-24-000044:notes:111]
|  | Three Months Ended March 31, |  |  |
| (In millions) | 2024 |  | 2023 |  |  |  |  |
| HVAC | $ | 7 |  |  | $ | (1) |  |  |  |  |  |
| Refrigeration | — |  |  | 3 |  |  |  |  |  |
| Fire & Security | 7 |  |  | 13 |  |  |  |  |  |
| Total Segment | 14 |  |  | 15 |  |  |  |  |  |
| General corporate expenses | 1 |  |  | 2 |  |  |  |  |  |
| Total restructuring costs (1) | $ | 15 |  |  | $ | 17 |  |  |  |  |  |
| Cost of sales | $ | 12 |  |  | $ | 6 |  |  |  |  |  |
| Selling, general and administrative | 3 |  |  | 11 |  |  |  |  |  |
| Total restructuring costs (1) | $ | 15 |  |  | $ | 17 |  |  |  |  |  |

[0001783180-24-000044:notes:112]
(1) 2024 restructuring costs include period related charges.

[0001783180-24-000044:notes:113]
[same as prior period, unchanged from 0001783180-23-000065:notes:96]

[0001783180-24-000044:notes:114]
|  |  | Three Months Ended March 31, |
| (In millions) |  | 2024 |  | 2023 |
| Balance as of January 1, |  | $ | 55 |  |  | $ | 24 |  |
| Net pre-tax restructuring costs |  | 12 |  |  | 17 |  |
| Acquisitions (1) |  | 8 |  |  | — |  |
| Utilization, foreign exchange and other |  | (24) |  |  | (6) |  |
| Balance as of March 31, |  | $ | 51 |  |  | $ | 35 |  |

[0001783180-24-000044:notes:115]
As of March 31, 2024, the Company had $51 million accrued for costs associated with its announced restructuring initiatives. The balance relates to cost reduction efforts, primarily severance related across each of the Company's segments, along with  reserves associated with the Company's planned portfolio transformation. The Company expects a majority of the balance to be utilized within one year.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001783180-24-000044:notes:116]
INCOME TAXES
The Company accounts for income tax expense in accordance with ASC 740, Income Taxes ("ASC 740"), which requires an estimate of the annual effective income tax rate for the full year to be applied to the respective interim period, taking into account year-to-date amounts and projected results for the full year. The effective tax rate was 13.7% for the three months ended March 31, 2024 compared with 24.0% for the three months ended March 31, 2023. The year-over-year decrease was primarily driven by a tax benefit of $21 million associated with the TMA and UTC's conclusion of certain income tax matters from their 2017 and 2018 tax audit with the U.S. Internal Revenue Service ("IRS"), a net tax benefit of $19 million related to adjustments to basis differences in certain companies presented as held-for-sale and a net tax benefit of $16 million related to the re-organization and disentanglement of certain Fire & Security industrial businesses in advance of the planned divestitures. These amounts were partially offset by a tax charge of $15 million related to a reduction of utilizable foreign tax credits.

[0001783180-24-000044:notes:117]
[same as prior period, unchanged from 0001783180-23-000065:notes:102]

[0001783180-24-000044:notes:118]
The Company conducts business globally and files income tax returns in U.S. federal, state and foreign jurisdictions. In certain jurisdictions, the Company's operations were included in UTC's combined tax returns for the periods through the Distribution. The IRS has completed its audit of UTC's 2017 and 2018 tax years. In the normal course of business, the Company is subject to examination by taxing authorities throughout the world, including Australia, Belgium, Canada, China, Czech Republic, France, Germany, Hong Kong, India, Italy, Mexico, the Netherlands, Singapore, the United Kingdom and the United States. The Company is no longer subject to U.S. federal income tax examination for years prior to 2020 and, with few exceptions, is no longer subject to state, local and foreign income tax examinations for tax years prior to 2013.

[0001783180-24-000044:notes:119]
In the ordinary course of business, there is inherent uncertainty in quantifying the Company's income tax positions. The Company assesses its income tax positions and records tax benefits for all years subject to examination based upon management’s evaluation of the facts, circumstances and information available at the reporting date. The Company believes that it is reasonably possible that a net decrease in unrecognized tax benefits of $30 million to $45 million may occur within 12 months as a result of additional uncertain tax positions, the Separation, the revaluation of uncertain tax positions arising from examinations, appeals, court decisions and/or the expiration of tax statutes.


## us-gaap:EarningsPerShareTextBlock

[0001783180-24-000044:notes:120]
[same as prior period, unchanged from 0001783180-23-000065:notes:105]

[0001783180-24-000044:notes:121]
[same as prior period, unchanged from 0001783180-23-000065:notes:106]

[0001783180-24-000044:notes:122]
|  |  | Three Months Ended March 31, |  |  |
| (In millions, except per share amounts) |  | 2024 |  | 2023 |  |  |  |  |
| Net income attributable to common shareowners |  | $ | 269 |  |  | $ | 373 |  |  |  |  |  |
| Basic weighted-average number of shares outstanding |  | 899.2 |  |  | 835.0 |  |  |  |  |  |
| Stock awards and equity units (share equivalent) |  | 13.8 |  |  | 17.2 |  |  |  |  |  |
| Diluted weighted-average number of shares outstanding |  | 913.0 |  |  | 852.2 |  |  |  |  |  |
| Antidilutive shares excluded from computation of diluted earnings per share |  | 4.2 |  |  | 6.5 |  |  |  |  |  |
| Earnings Per Share |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.30 |  |  | $ | 0.45 |  |  |  |  |  |
| Diluted |  | $ | 0.29 |  |  | $ | 0.44 |  |  |  |  |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001783180-24-000044:notes:123]
[same as prior period, unchanged from 0001783180-23-000065:notes:108]

[0001783180-24-000044:notes:124]
Viessmann Climate Solutions

[0001783180-24-000044:notes:125]
On January 2, 2024, the Company completed the acquisition of the VCS Business from Viessmann for total consideration of $14.2 billion. The purchase price consisted of (i) $11.2 billion in cash and (ii) 58,608,959 shares of the Company's common stock, subject to certain lock-up provisions and anti-dilution protection. The Company funded the cash portion of the purchase price with a combination of cash on hand, net proceeds from the USD Notes and Euro Notes and borrowings under the Delayed Draw Facility and the 60-day Loan.

[0001783180-24-000044:notes:126]
The VCS Business develops intelligent, integrated and sustainable technologies, including heat pumps, boilers, photovoltaic systems, home battery storage and digital solutions, primarily for residential customers in Europe. The Company believes that secular trends in these areas will drive significant, sustained future growth. In addition, the Company anticipates realizing significant operational synergies including savings through supplier rationalization and leverage, reduced manufacturing costs and lower general and administrative costs. Longer term, the Company expects to benefit from synergies related to service revenue expansion, leverage of distribution channels and cross-selling opportunities.

[0001783180-24-000044:notes:127]
The components of the purchase price is as follows:

[0001783180-24-000044:notes:128]
| (In millions) |  | January 2, 2024 |
| Cash |  | $ | 11,156 |  |
| Common shares (58,608,959 shares at $51.20 per share) |  | 3,001 |  |
| Total consideration |  | $ | 14,157 |  |

[0001783180-24-000044:notes:129]
The preliminary allocation of the purchase price is as follows:

[0001783180-24-000044:notes:130]
| (In millions) |  | January 2, 2024 |
| Cash and cash equivalents |  | $ | 394 |  |
| Accounts receivable |  | 408 |  |
| Inventories |  | 948 |  |
| Other assets, current |  | 17 |  |
| Fixed assets |  | 913 |  |
| Intangible assets |  | 6,640 |  |
| Goodwill |  | 7,576 |  |
| Other assets |  | 284 |  |
| Accounts payable |  | (288) |  |
| Other liabilities, current |  | (626) |  |
| Future income tax obligations |  | (1,825) |  |
| Other liabilities |  | (284) |  |
| Net assets acquired |  | $ | 14,157 |  |

[0001783180-24-000044:notes:131]
The excess purchase price over the estimated fair value of the net identifiable assets acquired was recognized as goodwill and totaled $7.6 billion, which is not deductible for tax purposes. Accounts receivable and current liabilities were stated at their historical carrying value, which approximates fair value given the short-term nature of these assets and liabilities. The estimate of fair value for inventory and fixed assets was based on an assessment of the acquired assets' condition as well as an evaluation of the current market value of such assets.

[0001783180-24-000044:notes:132]
[same as prior period, unchanged from 0001783180-23-000065:notes:114]

[0001783180-24-000044:notes:133]
| (In millions) |  | Estimated Useful Life (in years) |  | Intangible Assets Acquired |
| Customer relationships |  | 17 |  | $ | 4,787 |  |
| Technology |  | 10 - 20 |  | 1,051 |  |
| Trademark |  | 40 |  | 679 |  |
| Backlog |  | 1 |  | 123 |  |
| Total intangible assets acquired |  |  |  | $ | 6,640 |  |

[0001783180-24-000044:notes:134]
The valuation of intangible assets was determined using an income approach methodology including the multi-period excess earnings method and the relief from royalty method. Key assumptions used in estimating future cash flows included projected revenue growth rates, EBITDA margins, discount rates, customer attrition rates and royalty rates among others. The projected future cash flows are discounted to present value using an appropriate discount rate. As of March 31, 2024, the Company is in the process of completing its valuation of tangible, intangible and tax-related assets relating to the VCS Business and the allocation of the purchase price to the assets acquired and liabilities assumed will be completed once the valuation process has been finalized.

[0001783180-24-000044:notes:135]
The assets, liabilities and results of operations of the VCS Business are consolidated in the accompanying Unaudited Condensed Consolidated Financial Statements as of the date of acquisition and reported within the Company's HVAC segment. For the period from January 2, 2024 to March 31, 2024, revenues for the VCS Business were $875 million and its net loss was $124 million which included amortization of the step-up to fair value of inventory and backlog of $111 million as well as $139 million of intangible asset amortization.

[0001783180-24-000044:notes:136]
During the three months ended March 31, 2024, the Company incurred $30 million of acquisition-related costs. During 2023, $80 million of acquisition-related costs were incurred, of which $12 million was recognized during the three months ended March 31, 2023. These acquisition costs are reflected within Selling, general and administrative in the Unaudited Condensed Consolidated Statement of Operations.

[0001783180-24-000044:notes:137]
Unaudited Pro Forma Financial Information

[0001783180-24-000044:notes:138]
The following unaudited pro forma financial information is presented to illustrate the estimated effects of the acquisition of the VCS Business as if the business combination had occurred on January 1, 2023:

[0001783180-24-000044:notes:139]
|  | Three Months Ended March 31, |  |  |
| (In millions) | 2024 |  | 2023 |  |  |  |  |
| Revenue | $ | 6,182 |  |  | $ | 6,278 |  |  |  |  |  |
| Earnings | 343 |  |  | 79 |  |  |  |  |  |

[0001783180-24-000044:notes:140]
The pro forma amounts include the historical operating results of the Company and the VCS Business prior to the acquisition, with adjustments directly attributable to the acquisition including amortization of the step-up to fair value of inventory and amortization expense of acquired intangible assets. The unaudited pro forma financial information is not necessarily indicative of the results of operations that actually would have been achieved had the acquisition of the VCS Business been consummated as of the dates indicated, nor is it indicative of any future results. In addition, the unaudited pro forma financial information does not reflect the expected realization of any synergies or cost savings associated with the acquisition.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001783180-24-000044:notes:141]
DIVESTITURES
Portfolio Transformation

[0001783180-24-000044:notes:142]
On April 25, 2023, the Company announced plans to exit its Fire & Security and Commercial Refrigeration businesses over the course of 2024. On December 7, 2023, the Company entered into a stock purchase agreement to sell its Access Solutions business to Honeywell International Inc. for an enterprise value of approximately $4.95 billion. Access Solutions, historically reported in the Company's Fire & Security segment, is a global supplier of physical security and digital access solutions supporting the hospitality, commercial, education and military markets. On December 12, 2023, the Company entered into a stock purchase agreement to sell the CCR business to Haier Group Corporation for an enterprise value of approximately $775 million. CCR, historically reported in the Company's Refrigeration segment, is a global supplier of turnkey solutions for commercial refrigeration systems and services, with a primary focus on serving food retail customers, cold storage facilities and warehouses. As a result, the assets and liabilities of both businesses are presented as held for sale in the accompanying Unaudited Condensed Consolidated Balance Sheet as of March 31, 2024 and December 31, 2023, and recorded at the lower of their carrying value or fair value less estimated cost to sell. Both transactions are expected to close in 2024 and are subject to customary closing conditions.

[0001783180-24-000044:notes:143]
In addition, the net assets of Industrial Fire met the criteria to be classified as held for sale during the fourth quarter of 2023. Industrial Fire, historically reported in the Company's Fire & Security segment, is a leading manufacturer of a full spectrum of fire detection and suppression solutions and services in critical high-hazard environments, including oil and gas, power generation, marine and offshore facilities, automotive, data centers and aircraft hangars. As a result, the assets and liabilities of the business are presented as held for sale in the accompanying Unaudited Condensed Consolidated Balance Sheet as of March 31, 2024 and December 31, 2023, and recorded at the lower of their carrying value or fair value less estimated cost to sell. On March 5, 2024, the Company entered into a stock purchase agreement to sell its Industrial Fire business to Sentinel Capital Partners for an enterprise value of approximately $1.425 billion. The transaction is expected to close in 2024 and is subject to customary closing conditions.

[0001783180-24-000044:notes:144]
The following table summarizes assets and liabilities classified as held for sale:

[0001783180-24-000044:notes:145]
|  | March 31, 2024 |
| (In millions) | Commercial Refrigeration |  | AccessSolutions |  | IndustrialFire |  | Total |
| Cash and cash equivalents | $ | 107 |  |  | $ | 10 |  |  | $ | 11 |  |  | $ | 128 |  |
| Accounts receivable, net | 189 |  |  | 85 |  |  | 96 |  |  | 370 |  |
| Inventories, net | 93 |  |  | 34 |  |  | 68 |  |  | 195 |  |
| Contract assets, current | 106 |  |  | 2 |  |  | 49 |  |  | 157 |  |
| Other assets, current | 16 |  |  | 4 |  |  | 5 |  |  | 25 |  |
| Fixed assets, net | 77 |  |  | 14 |  |  | 23 |  |  | 114 |  |
| Intangible assets, net | — |  |  | 52 |  |  | 2 |  |  | 54 |  |
| Goodwill | 72 |  |  | 1,479 |  |  | 433 |  |  | 1,984 |  |
| Operating lease right-of-use assets | 49 |  |  | 14 |  |  | 26 |  |  | 89 |  |
| Other assets | 44 |  |  | 7 |  |  | 2 |  |  | 53 |  |
| Total assets held for sale | $ | 753 |  |  | $ | 1,701 |  |  | $ | 715 |  |  | $ | 3,169 |  |
| Accounts payable | $ | 123 |  |  | $ | 29 |  |  | $ | 43 |  |  | $ | 195 |  |
| Accrued liabilities | 156 |  |  | 20 |  |  | 50 |  |  | 226 |  |
| Contract liabilities, current | 25 |  |  | 57 |  |  | 17 |  |  | 99 |  |
| Long-term debt, including current portion | 7 |  |  | — |  |  | — |  |  | 7 |  |
| Future pension and post-retirement obligations | 198 |  |  | — |  |  | — |  |  | 198 |  |
| Future income tax obligations | 4 |  |  | — |  |  | 3 |  |  | 7 |  |
| Operating lease liabilities | 38 |  |  | 11 |  |  | 21 |  |  | 70 |  |
| Other long-term liabilities | 3 |  |  | 12 |  |  | 3 |  |  | 18 |  |
| Total liabilities held for sale | $ | 554 |  |  | $ | 129 |  |  | $ | 137 |  |  | $ | 820 |  |

[0001783180-24-000044:notes:146]
|  | December 31, 2023 |
| (In millions) | Commercial Refrigeration |  | AccessSolutions |  | IndustrialFire |  | Total |
| Cash and cash equivalents | $ | 131 |  |  | $ | 6 |  |  | $ | 20 |  |  | $ | 157 |  |
| Accounts receivable, net | 274 |  |  | 104 |  |  | 101 |  |  | 479 |  |
| Inventories, net | 84 |  |  | 31 |  |  | 65 |  |  | 180 |  |
| Contract assets, current | 98 |  |  | 2 |  |  | 42 |  |  | 142 |  |
| Other assets, current | 15 |  |  | 3 |  |  | 4 |  |  | 22 |  |
| Fixed assets, net | 78 |  |  | 13 |  |  | 22 |  |  | 113 |  |
| Intangible assets, net | — |  |  | 53 |  |  | 2 |  |  | 55 |  |
| Goodwill | 72 |  |  | 1,498 |  |  | 439 |  |  | 2,009 |  |
| Operating lease right-of-use assets | 49 |  |  | 13 |  |  | 28 |  |  | 90 |  |
| Other assets | 44 |  |  | 10 |  |  | 13 |  |  | 67 |  |
| Total assets held for sale | $ | 845 |  |  | $ | 1,733 |  |  | $ | 736 |  |  | $ | 3,314 |  |
| Accounts payable | $ | 129 |  |  | $ | 20 |  |  | $ | 39 |  |  | $ | 188 |  |
| Accrued liabilities | 181 |  |  | 21 |  |  | 55 |  |  | 257 |  |
| Contract liabilities, current | 23 |  |  | 53 |  |  | 22 |  |  | 98 |  |
| Long-term debt, including current portion | 8 |  |  | — |  |  | — |  |  | 8 |  |
| Future pension and post-retirement obligations | 203 |  |  | — |  |  | 1 |  |  | 204 |  |
| Future income tax obligations | 4 |  |  | 2 |  |  | 3 |  |  | 9 |  |
| Operating lease liabilities | 40 |  |  | 11 |  |  | 23 |  |  | 74 |  |
| Other long-term liabilities | 3 |  |  | 12 |  |  | 9 |  |  | 24 |  |
| Total liabilities held for sale | $ | 591 |  |  | $ | 119 |  |  | $ | 152 |  |  | $ | 862 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001783180-24-000044:notes:147]
[same as prior period, unchanged from 0001783180-23-000065:notes:126]

[0001783180-24-000044:notes:148]
[same as prior period, unchanged from 0001783180-23-000065:notes:127]

[0001783180-24-000044:notes:149]
[same as prior period, unchanged from 0001783180-23-000065:notes:128]

[0001783180-24-000044:notes:150]
[same as prior period, unchanged from 0001783180-23-000065:notes:129]

[0001783180-24-000044:notes:151]
[same as prior period, unchanged from 0001783180-23-000065:notes:130]

[0001783180-24-000044:notes:152]
[same as prior period, unchanged from 0001783180-23-000065:notes:131]

[0001783180-24-000044:notes:153]
|  |  | Net Sales |  | Operating Profit |
|  |  | Three Months Ended March 31, |  | Three Months Ended March 31, |
| (In millions) |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| HVAC |  | $ | 4,541 |  |  | $ | 3,622 |  |  | $ | 429 |  |  | $ | 435 |  |
| Refrigeration |  | 884 |  |  | 898 |  |  | 97 |  |  | 108 |  |
| Fire & Security |  | 887 |  |  | 869 |  |  | 153 |  |  | 93 |  |
| Total segment |  | 6,312 |  |  | 5,389 |  |  | 679 |  |  | 636 |  |
| Eliminations and other |  | (130) |  |  | (116) |  |  | (75) |  |  | (38) |  |
| General corporate expenses |  | — |  |  | — |  |  | (104) |  |  | (43) |  |
| Total Consolidated |  | $ | 6,182 |  |  | $ | 5,273 |  |  | $ | 500 |  |  | $ | 555 |  |

[0001783180-24-000044:notes:154]
Geographic external sales are attributed to the geographic regions based on their location of origin. With the exception of the U.S. presented in the table below, there were no individually significant countries with sales exceeding 10% of total sales during the three months ended March 31, 2024 and 2023.

[0001783180-24-000044:notes:155]
|  |  | Three Months Ended March 31, |  |  |
| (In millions) |  | 2024 |  | 2023 |  |  |  |  |
| United States |  | $ | 2,967 |  |  | $ | 2,860 |  |  |  |  |  |
| International: |  |  |  |  |  |  |  |  |
| Europe |  | 1,971 |  |  | 1,196 |  |  |  |  |  |
| Asia Pacific |  | 1,040 |  |  | 1,033 |  |  |  |  |  |
| Other |  | 204 |  |  | 184 |  |  |  |  |  |
| Net sales |  | $ | 6,182 |  |  | $ | 5,273 |  |  |  |  |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001783180-24-000044:notes:156]
RELATED PARTIES
Equity Method Investments

[0001783180-24-000044:notes:157]
The Company sells products to and purchases products from unconsolidated entities accounted for under the equity method and, therefore, these entities are considered to be related parties. Amounts attributable to equity method investees are as follows:

[0001783180-24-000044:notes:158]
|  |  |  |  | Three Months Ended March 31, |
| (In millions) |  |  |  |  |  | 2024 |  | 2023 |
| Sales to equity method investees included in Product sales |  |  |  |  |  | $ | 723 |  |  | $ | 754 |  |
| Purchases from equity method investees included in Cost of products sold |  |  |  |  |  | $ | 55 |  |  | $ | 43 |  |

[0001783180-24-000044:notes:159]
The Company had receivables from and payables to equity method investees as follows:

[0001783180-24-000044:notes:160]
| (In millions) |  | March 31,2024 |  | December 31,2023 |
| Receivables from equity method investees included in Accounts receivable, net |  | $ | 261 |  |  | $ | 231 |  |
| Payables to equity method investees included in Accounts payable |  | $ | 44 |  |  | $ | 44 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001783180-24-000044:notes:161]
COMMITMENTS AND CONTINGENT LIABILITIES
The Company is involved in various litigation, claims and administrative proceedings, including those related to environmental (including asbestos) and legal matters. In accordance with ASC 450, Contingencies, the Company records accruals for loss contingencies when it is probable that a liability has been incurred and the amount of the loss can be reasonably estimated. These accruals are generally based upon a range of possible outcomes. If no amount within the range is a better estimate than any other, the Company accrues the minimum amount. In addition, these estimates are reviewed periodically and adjusted to reflect additional information when it becomes available. The Company is unable to predict the final outcome of the following matters based on the information currently available, except as otherwise noted. However, the Company does not believe that the resolution of any of these matters will have a material adverse effect upon its results of operations or financial condition.

[0001783180-24-000044:notes:162]
Environmental Matters

[0001783180-24-000044:notes:163]
The Company’s operations are subject to environmental regulation by various authorities. The Company has accrued for the costs of environmental remediation activities, including but not limited to investigatory, remediation, operating and maintenance costs and performance guarantees. The most likely cost to be incurred is accrued based on an evaluation of currently available facts with respect to individual sites, including the technology required to remediate, current laws and regulations and prior remediation experience.

[0001783180-24-000044:notes:164]
The outstanding liabilities for environmental obligations are as follows:

[0001783180-24-000044:notes:165]
| (In millions) |  | March 31,2024 |  | December 31,2023 |
| Environmental reserves included in Accrued liabilities |  | $ | 19 |  |  | $ | 21 |  |
| Environmental reserves included in Other long-term liabilities |  | 201 |  |  | 203 |  |
| Total Environmental reserves |  | $ | 220 |  |  | $ | 224 |  |

[0001783180-24-000044:notes:166]
For sites with multiple responsible parties, the Company considers its likely proportionate share of the anticipated remediation costs and the ability of other parties to fulfill their obligations in establishing a provision for these costs. Accrued environmental liabilities are not reduced by potential insurance reimbursements and are undiscounted.

[0001783180-24-000044:notes:167]
Asbestos Matters

[0001783180-24-000044:notes:168]
The Company has been named as a defendant in lawsuits alleging personal injury as a result of exposure to asbestos allegedly integrated into certain Carrier products or business premises. While the Company has never manufactured asbestos and no longer incorporates it into any currently-manufactured products, certain products that the Company no longer manufactures contained components incorporating asbestos. A substantial majority of these asbestos-related claims have been dismissed without payment or have been covered in full or in part by insurance or other forms of indemnity. Additional cases were litigated and settled without any insurance reimbursement. The amounts involved in asbestos-related claims were not material individually or in the aggregate in any period.

[0001783180-24-000044:notes:169]
The Company's asbestos liabilities and related insurance recoveries are as follows:

[0001783180-24-000044:notes:170]
| (In millions) |  | March 31,2024 |  | December 31,2023 |
| Asbestos liabilities included in Accrued liabilities |  | $ | 15 |  |  | $ | 15 |  |
| Asbestos liabilities included in Other long-term liabilities |  | 203 |  |  | 206 |  |
| Total Asbestos liabilities |  | $ | 218 |  |  | $ | 221 |  |
| Asbestos-related recoveries included in Other assets, current |  | $ | 5 |  |  | $ | 5 |  |
| Asbestos-related recoveries included in Other assets |  | 87 |  |  | 88 |  |
| Total Asbestos-related recoveries |  | $ | 92 |  |  | $ | 93 |  |

[0001783180-24-000044:notes:171]
The amounts recorded for asbestos-related liabilities are based on currently available information and assumptions that the Company believes are reasonable and are made with input from outside actuarial experts. These amounts are undiscounted and exclude the Company’s legal fees to defend the asbestos claims, which are expensed as incurred. In addition, the Company has recorded insurance recovery receivables for probable asbestos-related recoveries.

[0001783180-24-000044:notes:172]
Aqueous Film Forming Foam Litigation

[0001783180-24-000044:notes:173]
As of March 31, 2024, the Company, KFI and others have been named as defendants in more than 7,000 lawsuits filed by individuals in or removed to the federal courts of the United States alleging that the historic use of Aqueous Film Forming Foam ("AFFF") caused personal injuries and/or property damage. The Company, KFI and others have also been named as defendants in more than 800 lawsuits filed by several U.S. states, municipalities and water utilities in or removed to U.S. federal courts alleging that the historic use of AFFF caused contamination of property and water supplies. In December 2018, the U.S. Judicial Panel on Multidistrict Litigation transferred and consolidated all AFFF cases pending in the U.S. federal courts against the Company, KFI and others to the U.S. District Court for the District of South Carolina (the "MDL Proceedings"). The individual plaintiffs in the MDL Proceedings generally seek damages for alleged personal injuries, medical monitoring, diminution in property value and injunctive relief to remediate alleged contamination of water supplies. The U.S. state, municipal and water utility plaintiffs in the MDL Proceedings generally seek damages and costs related to the remediation of public property and water supplies.

[0001783180-24-000044:notes:174]
AFFF is a firefighting foam, developed beginning in the late 1960s pursuant to U.S. military specification, used to extinguish certain types of hydrocarbon-fueled fires. The lawsuits identified above relate to Kidde Fire Fighting, Inc., which owned the National Foam business. Kidde Fire Fighting, Inc. was acquired by a UTC subsidiary in 2005 and merged into KFI in 2007. The National Foam business manufactured AFFF for sale to government (including the U.S. federal government) and non-government customers in the U.S. at a single facility located in West Chester, Pennsylvania (the "Pennsylvania Site"). In 2013, KFI divested the AFFF businesses to an unrelated third party. The Company acquired KFI as part of the Separation in April 2020.

[0001783180-24-000044:notes:175]
The key components that contribute to AFFF's fire-extinguishing capabilities are known as fluorosurfactants. Neither the Company, nor KFI, nor any of the Company's subsidiaries involved in the AFFF litigation manufactured fluorosurfactants. Instead, the National Foam business purchased these substances from unrelated third parties for use in manufacturing AFFF. Plaintiffs in the MDL Proceedings allege that the fluorosurfactants used by various manufacturers in producing AFFF contained, or over time degraded into, compounds known as per- and polyfluoroalkyl substances (referred to collectively as "PFAS"), including perflourooctanesulfonic acid ("PFOS") and perflourooctanoic acid ("PFOA"). Plaintiffs further allege that, as a result of the use of AFFF, PFOS and PFOA were released into the environment and, in some instances, ultimately reached drinking water supplies.

[0001783180-24-000044:notes:176]
Plaintiffs in the MDL Proceedings allege that PFOS and PFOA contamination has resulted from the use of AFFF manufactured using a process known as ECF, and that this process was used exclusively by 3M. They also allege that PFOA contamination has resulted from the use of AFFF manufactured using a different process, known as telomerization, and that this process was used exclusively by the other AFFF manufacturers (including the National Foam business). Compounds containing PFOS and PFOA (as well as many other PFAS) have also been used for decades by many third parties in a number of different industries to manufacture firefighters’ protective outerwear, carpets, clothing, fabrics, cookware, food packaging, personal care products, cleaning products, paints, varnishes and other consumer and industrial products.

[0001783180-24-000044:notes:177]
Plaintiffs in the MDL Proceedings have named multiple defendants, including suppliers of chemicals and raw materials used to manufacture fluorosurfactants, fluorosurfactant manufacturers and AFFF manufacturers. The defendants in the MDL Proceedings moved for summary judgment on the government contractor defense, which potentially applies to AFFF sold to or used by the U.S. government. After full briefing and oral argument, on September 16, 2022, the MDL court declined to enter summary judgment for the defendants. The defense, however, remains available at any trial to which it applies.

[0001783180-24-000044:notes:178]
On September 23, 2022, after completion of discovery, the MDL court selected one water provider case, the City of Stuart, FL v. 3M, et al., for a bellwether trial. That trial was scheduled to begin in early June 2023 but was postponed indefinitely. The MDL court ordered that the bellwether process for personal injury cases to begin in 2023. However, the court has not yet outlined details on that process or its timing.

[0001783180-24-000044:notes:179]
Outside of the MDL Proceedings, the Company and other defendants also are party to six lawsuits in U.S. state courts brought by oil refining companies alleging product liability claims related to legacy sales of AFFF and seeking damages for the costs to replace the product and for property damage. In addition, the Company and other defendants are party to two actions related to the Pennsylvania Site in which the plaintiff water utility company seeks remediation costs related to the alleged contamination of the local water supply. The Company, KFI and other defendants are also party to one action in Arizona state court brought by a firefighter claiming that occupational exposure to AFFF has caused certain personal injuries.

[0001783180-24-000044:notes:180]
The Company and KFI believe that they have meritorious defenses to the claims in the MDL Proceedings and the other AFFF lawsuits. Given the numerous factual, scientific and legal issues to be resolved relating to these claims, the Company is unable to assess the probability of liability or to reasonably estimate a range of possible loss at this time. There can be no assurance that any such future exposure will not be material in any period.

[0001783180-24-000044:notes:181]
On May 14, 2023, KFI filed a voluntary petition with the United States Bankruptcy Court for the District of Delaware seeking relief under Chapter 11 of the Bankruptcy Code after the Company determined that it would not provide financial support to KFI going forward, other than ensuring KFI has access to services necessary for the effective operation of its business. As a result, all litigation against KFI is automatically stayed. KFI filed an adversary complaint and motion in the Chapter 11 case seeking an order staying or enjoining all AFFF-related litigation against the Company, its other subsidiaries and RTX. That motion was resolved through an agreement that effectively stays the AFFF litigation against these parties. KFI has also indicated to the bankruptcy court that it intends to pursue insurance coverage for AFFF-related liabilities and contractual indemnification for AFFF-related liabilities from the third party to which KFI sold National Foam. On November 21, 2023, the bankruptcy court ordered certain parties, including the Company, to participate in a mediation with respect to claims that might be asserted by and against it in the bankruptcy proceedings. The parties have engaged in several mediation sessions and anticipate further sessions in the future. The terms and scope of any potential settlement may be affected by, among other factors, the bankruptcy court’s ability to approve nonconsensual releases of litigation claims against non-debtors, which the United States Supreme Court is expected to decide in Harrington v. Purdue Pharma, L.P.

[0001783180-24-000044:notes:182]
Deconsolidation Due to Bankruptcy

[0001783180-24-000044:notes:183]
As of May 14, 2023, the Company no longer controlled KFI as their activities are subject to review and oversight by the bankruptcy court. Therefore, KFI was deconsolidated and their respective assets and liabilities were derecognized from the Company’s Unaudited Condensed Consolidated Financial Statements. Upon deconsolidation, the Company determined the fair value of its retained interest in KFI to be zero and will account for it prospectively using the cost method. As a result of these actions, the Company recognized a loss of $297 million in its Unaudited Condensed Consolidated Statement of Operations within Other income/(expense), net. In addition, the deconsolidation resulted in an investing cash outflow of $134 million in the Company's Unaudited Condensed Consolidated Statement of Cash Flows.

[0001783180-24-000044:notes:184]
In connection with the bankruptcy filing, KFI entered into several agreements with subsidiaries of the Company to ensure they have access to services necessary for the effective operation of their business. All post-deconsolidation activity between the Company and KFI are reported as third-party transactions recorded within the Company's Unaudited Condensed Consolidated Statement of Operations. Since the petition date, there were no material transactions between the Company and KFI.

[0001783180-24-000044:notes:185]
On March 15, 2024, the Company and Pacific Avenue Capital Partners entered into certain agreements including a stock and asset purchase agreement whereby Pacific Avenue Capital Partners shall acquire certain assets and operating liabilities of KFI, subject to approval by the bankruptcy court. On April 1, 2024, the bankruptcy court subsequently approved the sale. However, there has been no determination with respect to the allocation of sale proceeds.

[0001783180-24-000044:notes:186]
Income Taxes

[0001783180-24-000044:notes:187]
Under the TMA relating to the Separation, the Company is responsible to UTC for its share of the Tax Cuts and Jobs Act transition tax associated with foreign undistributed earnings as of December 31, 2017. During the three months ended March 31, 2024, the Company recognized a $46 million gain associated with the TMA and UTC's conclusion of certain income tax matters from their 2017 and 2018 tax audit with the IRS. Liabilities under the TMA of $96 million and $233 million are included within the accompanying Unaudited Condensed Consolidated Balance Sheet within Accrued Liabilities and Other Long-Term Liabilities as of March 31, 2024, respectively. This obligation is expected to be settled in annual installments ending in April 2026 with the next installment of $96 million due in 2024. The Company believes that the likelihood of incurring losses materially in excess of this amount is remote.

[0001783180-24-000044:notes:188]
Other

[0001783180-24-000044:notes:189]
The Company has other commitments and contingent liabilities related to legal proceedings, self-insurance programs and matters arising in the ordinary course of business. The Company accrues for contingencies generally based upon a range of possible outcomes. If no amount within the range is a better estimate than any other, the Company accrues the minimum amount.

[0001783180-24-000044:notes:190]
In the ordinary course of business, the Company is also routinely a defendant in, party to or otherwise subject to many pending and threatened legal actions, claims, disputes and proceedings. These matters are often based on alleged violations of contract, product liability, warranty, regulatory, environmental, health and safety, employment, intellectual property, tax and other laws. In some of these proceedings, claims for substantial monetary damages are asserted against the Company and could result in fines, penalties, compensatory or treble damages or non-monetary relief. The Company does not believe that these matters will have a material adverse effect upon its results of operations, cash flows or financial condition.
