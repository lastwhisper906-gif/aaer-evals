# CARR 8-K — 0001783180-24-000042 filed 2024-04-25

## item codes, every 8-K on or before 2024-04-25

- 2024-04-25 0001783180-24-000042 — 2.02, 9.01
- 2024-04-19 0001783180-24-000035 — 5.07, 9.01
- 2024-04-19 0000950142-24-001162 — 5.07 — amendment of 0001783180-24-000035
- 2024-02-06 0001783180-24-000007 — 2.02, 9.01
- 2024-02-01 0000950142-24-000264 — 5.02
- 2024-01-02 0001140361-24-000034 — 1.01, 2.01, 2.03, 5.02, 7.01, 9.01
- 2023-12-13 0001140361-23-057415 — 1.01, 9.01
- 2023-12-08 0001140361-23-056751 — 7.01, 9.01
- 2023-11-30 0000950142-23-002884 — 1.01, 2.03, 8.01, 9.01
- 2023-11-16 0000950142-23-002788 — 8.01, 9.01
- 2023-11-13 0001140361-23-052667 — 7.01, 8.01, 9.01
- 2023-10-26 0001783180-23-000063 — 2.02, 9.01
- 2023-07-27 0001783180-23-000053 — 2.02, 9.01
- 2023-06-12 0000950142-23-001664 — 5.02
- 2023-05-25 0000950142-23-001541 — 1.01, 1.02, 2.03, 9.01
- 2023-04-26 0000950142-23-001205 — 1.01, 9.01
- 2023-04-25 0001783180-23-000036 — 2.02, 7.01, 9.01
- 2023-04-25 0000950142-23-001199 — 7.01, 8.01, 9.01
- 2023-04-21 0001783180-23-000032 — 5.07, 9.01
- 2023-02-07 0001783180-23-000010 — 2.02, 9.01
- 2022-10-27 0001783180-22-000054 — 2.02, 7.01, 9.01
- 2022-09-29 0000950142-22-002805 — 5.02, 9.01
- 2022-07-28 0001783180-22-000045 — 2.02, 9.01
- 2022-04-28 0001783180-22-000032 — 2.02, 9.01
- 2022-04-15 0001783180-22-000024 — 5.07, 9.01
- 2022-02-08 0001783180-22-000008 — 2.02, 9.01
- 2022-02-07 0000950142-22-000510 — 8.01, 9.01
- 2022-01-03 0000950142-22-000023 — 8.01, 9.01
- 2021-12-17 0001783180-21-000071 — 5.02, 7.01, 9.01
- 2021-11-23 0001783180-21-000068 — 5.03, 9.01
- 2021-10-28 0001783180-21-000062 — 2.02, 9.01
- 2021-08-27 0001783180-21-000056 — 8.01
- 2021-07-30 0001783180-21-000053 — 1.01
- 2021-07-29 0001783180-21-000049 — 2.02, 8.01, 9.01
- 2021-07-27 0000950142-21-002448 — 8.01, 9.01
- 2021-07-15 0000950142-21-002362 — 5.02, 9.01
- 2021-06-09 0000950142-21-001885 — 5.02, 9.01
- 2021-04-29 0001783180-21-000029 — 2.02, 9.01
- 2021-04-22 0001140361-21-013889 — 5.02, 9.01
- 2021-04-20 0001783180-21-000021 — 5.07, 9.01
- 2021-04-19 0000950142-21-001308 — 8.01, 9.01
- 2021-02-09 0001783180-21-000009 — 2.02, 9.01
- 2021-02-05 0001140361-21-003513 — 8.01, 9.01
- 2020-12-23 0001140361-20-029419 — 7.01, 9.01
- 2020-12-22 0001140361-20-029097 — 8.01
- 2020-12-14 0001140361-20-028246 — 5.03, 9.01
- 2020-12-07 0001140361-20-027515 — 1.01, 7.01, 9.01
- 2020-10-29 0001783180-20-000063 — 2.02, 9.01
- 2020-10-19 0001140361-20-023241 — 5.02, 7.01, 9.01
- 2020-09-23 0001140361-20-021220 — 8.01, 9.01
- 2020-09-22 0001140361-20-021124 — 8.01, 9.01
- 2020-07-30 0001783180-20-000045 — 2.02, 9.01
- 2020-06-19 0001140361-20-014325 — 1.01, 2.03, 9.01
- 2020-06-16 0001140361-20-013880 — 8.01, 9.01
- 2020-06-03 0001140361-20-012939 — 1.01, 9.01
- 2020-05-08 0001783180-20-000013 — 2.02, 9.01
- 2020-04-03 0001140361-20-007888 — 1.01, 5.02, 5.03, 5.05, 7.01, 9.01
- 2020-03-16 0001140361-20-005868 — 8.01, 9.01

## late-filing notifications on or before 2024-04-25

- none on or before 2024-04-25

## item 2.02 — earnings release, exhibit 99.1

[0001783180-24-000042:8k_2_02:1]
EX-99
2
a99-q12024earningsexhibit.htm
EX-99

[0001783180-24-000042:8k_2_02:2]
Document

[0001783180-24-000042:8k_2_02:3]
Exhibit 99

[0001783180-24-000042:8k_2_02:4]
Carrier Reports Strong First Quarter 2024 Results

[0001783180-24-000042:8k_2_02:5]
•Net sales up 17% versus first quarter 2023; organic sales up 2%

[0001783180-24-000042:8k_2_02:6]
•GAAP EPS of $0.29 and adjusted EPS of $0.62

[0001783180-24-000042:8k_2_02:7]
•GAAP operating margin down 240 bps year over year; adjusted operating margin expanded 280 bps

[0001783180-24-000042:8k_2_02:8]
•Maintaining full year 2024 adjusted EPS guidance range despite additional $0.05 headwind from the earlier timing of business exits

[0001783180-24-000042:8k_2_02:9]
•Increasing full year 2024 adjusted operating margin guidance to ~15.5%

[0001783180-24-000042:8k_2_02:10]
•Expect to resume share repurchases in 2024

[0001783180-24-000042:8k_2_02:11]
PALM BEACH GARDENS, Fla., April 25, 2024 – Carrier Global Corporation (NYSE:CARR), global leader in intelligent climate and energy solutions, today reported strong financial results for the first quarter of 2024 and reaffirmed its full year earnings guidance despite the expected earlier timing of business exits compared to guidance provided in February.

[0001783180-24-000042:8k_2_02:12]
“We continue to perform while transforming. We expanded adjusted operating margins by 280 basis points driven by very strong productivity while continuing to invest in our future,” said Carrier Chairman & CEO David Gitlin. “We closed on Viessmann Climate Solutions at the beginning of the year, which will be transformational for Carrier and the industry. We are focused on capitalizing on the long-term secular sustainability trends, outperforming the market, and achieving and accelerating revenue and cost synergies. The business exits are also on track as we are within months of closing on three of our four transactions and are making significant progress on completing the fourth. We now expect to resume share repurchases in 2024 as the net proceeds from the announced transactions help us return to ~2x net leverage this year.”

[0001783180-24-000042:8k_2_02:13]
1

[0001783180-24-000042:8k_2_02:14]
First Quarter 2024 Results

[0001783180-24-000042:8k_2_02:15]
Carrier’s first quarter sales of $6.2 billion were up 17% compared to the prior year including 2% organic growth and approximately 16% contribution from the acquisition of Viessmann Climate Solutions offset by about 1% from divestitures. Organic sales in the HVAC segment were up 2%. HVAC sales in the Americas were up mid-single-digits driven by continued strength in commercial and light commercial HVAC both of which were up approximately 20%, partially offset by residential HVAC which was down low-single-digits. HVAC organic sales in EMEA were down 10% with commercial HVAC up around 10% which was more than offset by a significant decline in EMEA residential and light commercial. These organic figures exclude the contribution of Viessmann Climate Solutions which was down 12% year-over-year in the quarter, more than half of which was driven by lower solar PV sales.  HVAC sales in Asia Pacific were flat with strong growth in China offset by lower sales in Japan as we continue to improve our mix in that country. Refrigeration sales were down 2% organically driven by North America truck and trailer and commercial refrigeration, mostly offset by over 50% growth in container. Fire and Security showed broad-based growth and sales were up 7% organically in the quarter with commercial and residential fire up mid-single digits.

[0001783180-24-000042:8k_2_02:16]
GAAP operating profit in the quarter of $500 million was down 10% from last year primarily due to acquisition costs and the amortization expense of acquired intangible assets, which more than offset the addition of Viessmann Climate Solutions. Adjusted operating profit of $927 million was up 44%, mostly driven by strong productivity and the contribution from Viessmann Climate Solutions.

[0001783180-24-000042:8k_2_02:17]
Net income was $269 million and adjusted net income was $565 million. GAAP EPS was $0.29 and adjusted EPS was $0.62. Net cash flows generated in operating activities were $40 million and capital expenditures were $104 million, resulting in a free cash outflow of $64 million. The outflow was consistent with Carrier’s seasonal working capital pattern.

[0001783180-24-000042:8k_2_02:18]
2

[0001783180-24-000042:8k_2_02:19]
Full-Year 2024 Guidance**

[0001783180-24-000042:8k_2_02:20]
Carrier updated the following guidance for 2024, which includes Access Solutions, Commercial Refrigeration, and Industrial Fire for half a year:

[0001783180-24-000042:8k_2_02:21]
|  | Current Guidance | Prior Guidance |
| Sales | ~$26B Organic* up MSDFX 0%Acquisitions +18%Divestitures (6%) | ~$26.5B Organic* up MSDFX 0%Acquisitions +20%Divestitures (5%) |
| Adjusted Operating Margin* | ~15.5% | 15.0% - 15.5% |
| Adjusted EPS* | $2.80 - $2.90 | $2.80 - $2.90 |
| Free Cash Flow* | ~$0.4BIncludes ~$2B of expected tax payments on the gains from the announced business exits, restructuring, and transaction-related costs | ~$0.7BIncludes ~$1.7B of expected tax payments on the gains from the announced business exits, restructuring, and transaction-related costs |

[0001783180-24-000042:8k_2_02:22]
*Note: When the company provides expectations for organic sales, adjusted operating profit, adjusted operating margin, adjusted EPS and free cash flow on a forward-looking basis, a reconciliation of the differences between the non-GAAP expectations and the corresponding GAAP measures generally is not available without unreasonable effort. See “Use and Definitions of Non-GAAP Financial Measures” below for additional information.

[0001783180-24-000042:8k_2_02:23]
**As of April 25, 2024

[0001783180-24-000042:8k_2_02:24]
Conference Call

[0001783180-24-000042:8k_2_02:25]
Carrier will host a webcast of its earnings conference call today, Thursday, April 25, 2024, at 7:30 a.m. ET. To access the webcast, visit the Events & Presentations section of the Carrier Investor Relations site at ir.carrier.com/news-and-events/events-and-presentations or to listen to the earnings call by phone, participants must pre-register at Carrier Earnings Call Registration. All registrants will receive dial-in information and a PIN allowing access to the live call.

[0001783180-24-000042:8k_2_02:26]
3

[0001783180-24-000042:8k_2_02:27]
Cautionary Statement

[0001783180-24-000042:8k_2_02:28]
This communication contains statements which, to the extent they are not statements of historical or present fact, constitute "forward-looking statements" under the securities laws. These forward-looking statements are intended to provide management's current expectations or plans for Carrier's future operating and financial performance, based on assumptions currently believed to be valid. Forward-looking statements can be identified by the use of words such as "believe," "expect," "expectations," "plans," "strategy," "prospects," "estimate," "project," "target," "anticipate," "will," "should," "see," "guidance," "outlook," "confident," "scenario" and other words of similar meaning in connection with a discussion of future operating or financial performance. Forward-looking statements may include, among other things, statements relating to future sales, earnings, cash flow, results of operations, uses of cash, share repurchases, tax rates and other measures of financial performance or potential future plans, strategies or transactions of Carrier, our portfolio transformation and the use of the anticipated proceeds thereof, potential future investments, Carrier's plans with respect to its indebtedness and other statements that are not historical facts. All forward-looking statements involve risks, uncertainties and other factors that may cause actual results to differ materially from those expressed or implied in the forward-looking statements. For additional information on identifying factors that may cause actual results to vary materially from those stated in forward-looking statements, see Carrier's reports on Forms 10-K, 10-Q and 8-K filed with or furnished to the U.S. Securities and Exchange Commission from time to time. Any forward-looking statement speaks only as of the date on which it is made, and Carrier assumes no obligation to update or revise such statement, whether as a result of new information, future events or otherwise, except as required by applicable law.

[0001783180-24-000042:8k_2_02:29]
About Carrier

[0001783180-24-000042:8k_2_02:30]
Carrier Global Corporation, global leader in intelligent climate and energy solutions, is committed to creating solutions that matter for people and our planet for generations to come. From the beginning, we've led in inventing new technologies and entirely new industries. Today, we continue to lead because we have a world-class, diverse workforce that puts the customer at the center of everything we do. For more information, visit corporate.carrier.com or follow Carrier on social media at @Carrier.

[0001783180-24-000042:8k_2_02:31]
CARR-IR

[0001783180-24-000042:8k_2_02:32]
Contact:

[0001783180-24-000042:8k_2_02:33]
Investor Relations

[0001783180-24-000042:8k_2_02:34]
Sam Pearlstein

[0001783180-24-000042:8k_2_02:35]
561-365-2251

[0001783180-24-000042:8k_2_02:36]
Sam.Pearlstein@Carrier.com

[0001783180-24-000042:8k_2_02:37]
Media Inquiries

[0001783180-24-000042:8k_2_02:38]
Ashley Barrie

[0001783180-24-000042:8k_2_02:39]
561-365-1260

[0001783180-24-000042:8k_2_02:40]
Ashley.Barrie@Carrier.com

[0001783180-24-000042:8k_2_02:41]
4

[0001783180-24-000042:8k_2_02:42]
SELECTED FINANCIAL DATA, NON-GAAP MEASURES AND DEFINITIONS

[0001783180-24-000042:8k_2_02:43]
Following are tables that present selected financial data of Carrier Global Corporation (“Carrier”). Also included are reconciliations of non-GAAP measures to their most comparable GAAP measures.

[0001783180-24-000042:8k_2_02:44]
Use and Definitions of Non-GAAP Financial Measures

[0001783180-24-000042:8k_2_02:45]
Carrier Global Corporation (“Carrier”) reports its financial results in accordance with accounting principles generally accepted in the United States ("GAAP"). We supplement the reporting of our financial information determined under GAAP with certain non-GAAP financial information. The non-GAAP information presented provides investors with additional useful information, but should not be considered in isolation or as substitutes for the related GAAP measures. Moreover, other companies may define non-GAAP measures differently, which limits the usefulness of these measures for comparisons with such other companies. We encourage investors to review our financial statements and publicly filed reports in their entirety and not to rely on any single financial measure. A reconciliation of the non-GAAP measures to the corresponding amounts prepared in accordance with GAAP appears in the tables in this Appendix. The tables provide additional information as to the items and amounts that have been excluded from the adjusted measures.

[0001783180-24-000042:8k_2_02:46]
Organic sales, adjusted operating profit, adjusted operating margin, incremental margins / earnings conversion, earnings before interest, taxes and depreciation and amortization (“EBITDA”), adjusted EBITDA, adjusted net income, adjusted earnings per share (“EPS”), adjusted interest expense, net, adjusted effective tax rate and net debt are non-GAAP financial measures.

[0001783180-24-000042:8k_2_02:47]
Organic sales represents consolidated net sales (a GAAP measure), excluding the impact of foreign currency translation, acquisitions and divestitures completed in the preceding twelve months and other significant items of a nonoperational nature (hereinafter referred to as “other significant items”). Adjusted operating profit represents operating profit (a GAAP measure), excluding restructuring costs, amortization of acquired intangibles and other significant items. Adjusted operating margin represents adjusted operating profit as a percentage of net sales (a GAAP measure). Incremental margins / earnings conversion represents the year-over-year change in adjusted operating profit divided by the year-over-year change in net sales. EBITDA represents net income attributable to common shareholders (a GAAP measure), adjusted for interest income and expense, income tax expense, and depreciation and amortization. Adjusted EBITDA represents EBITDA, as calculated above, excluding non-service pension benefit, non-controlling interest in subsidiaries’ earnings from operations, restructuring costs and other significant items. Adjusted net income represents net income attributable to common shareowners (a GAAP measure), excluding restructuring costs, amortization of acquired intangibles and other significant items. Adjusted EPS represents diluted earnings per share (a GAAP measure), excluding restructuring costs, amortization of acquired intangibles and other significant items. Adjusted interest expense, net represents interest expense (a GAAP measure) and interest income (a GAAP measure), net excluding other significant items. The adjusted effective tax rate represents the effective tax rate (a GAAP measure), excluding restructuring costs, amortization of acquired intangibles and other significant items. Net debt represents long-term debt (a GAAP measure) less cash and cash equivalents (a GAAP measure). For the business segments, when applicable, adjustments of operating profit and operating margins represent operating profit, excluding restructuring, amortization of acquired intangibles and other significant items.

[0001783180-24-000042:8k_2_02:48]
Free cash flow is a non-GAAP financial measure that represents net cash flows provided by operating activities (a GAAP measure) less capital expenditures. Management believes free cash flow is a useful measure of liquidity and an additional basis for assessing Carrier’s ability to fund its activities, including the financing of acquisitions, debt service, repurchases of Carrier's common stock and distribution of earnings to shareowners.

[0001783180-24-000042:8k_2_02:49]
Orders are contractual commitments with customers to provide specified goods or services for an agreed upon price and may not be subject to penalty if cancelled.

[0001783180-24-000042:8k_2_02:50]
When we provide our expectations for organic sales, adjusted operating profit, adjusted operating margin, adjusted interest expense, net, adjusted effective tax rate, incremental margins/earnings conversion, EBITDA, adjusted EBITDA, adjusted EPS and free cash flow on a forward-looking basis, a reconciliation of the differences between the non-GAAP expectations and the corresponding GAAP measures (expected net sales, operating profit, operating margin, interest expense, effective tax rate, incremental operating margin, net income attributable to common shareowners, diluted EPS and net cash flows provided by operating activities) generally is not available without unreasonable effort due to potentially high variability, complexity and low visibility as to the items that would be excluded from the GAAP measure in the relevant future period, such as unusual gains and losses, the ultimate outcome of pending litigation, fluctuations in foreign currency exchange rates, the impact and timing of potential acquisitions and divestitures, future restructuring costs, and other structural changes or their probable significance. The variability of the excluded items may have a significant, and potentially unpredictable, impact on our future GAAP results.

[0001783180-24-000042:8k_2_02:51]
5

[0001783180-24-000042:8k_2_02:52]
Carrier Global Corporation

[0001783180-24-000042:8k_2_02:53]
Condensed Consolidated Statement of Operations

[0001783180-24-000042:8k_2_02:54]
|  |  | (Unaudited) |
|  |  | Three Months Ended March 31, |  |  |
| (In millions, except per share amounts) |  | 2024 |  | 2023 |  |  |  |  |
| Net sales |  |  |  |  |  |  |  |  |
| Product sales |  | $ | 5,542 |  |  | $ | 4,686 |  |  |  |  |  |
| Service sales |  | 640 |  |  | 587 |  |  |  |  |  |
| Total Net sales |  | 6,182 |  |  | 5,273 |  |  |  |  |  |
| Costs and expenses |  |  |  |  |  |  |  |  |
| Cost of products sold |  | (3,998) |  |  | (3,458) |  |  |  |  |  |
| Cost of services sold |  | (479) |  |  | (437) |  |  |  |  |  |
| Research and development |  | (224) |  |  | (139) |  |  |  |  |  |
| Selling, general and administrative |  | (985) |  |  | (721) |  |  |  |  |  |
| Total Costs and expenses |  | (5,686) |  |  | (4,755) |  |  |  |  |  |
| Equity method investment net earnings |  | 31 |  |  | 44 |  |  |  |  |  |
| Other income (expense), net |  | (27) |  |  | (7) |  |  |  |  |  |
| Operating profit |  | 500 |  |  | 555 |  |  |  |  |  |
| Interest (expense) income, net |  | (165) |  |  | (46) |  |  |  |  |  |
| Income from operations before income taxes |  | 335 |  |  | 509 |  |  |  |  |  |
| Income tax (expense) benefit |  | (46) |  |  | (122) |  |  |  |  |  |
| Net income from operations |  | 289 |  |  | 387 |  |  |  |  |  |
| Less: Non-controlling interest in subsidiaries' earnings from operations |  | 20 |  |  | 14 |  |  |  |  |  |
| Net income attributable to common shareowners |  | $ | 269 |  |  | $ | 373 |  |  |  |  |  |
| Earnings per share |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.30 |  |  | $ | 0.45 |  |  |  |  |  |
| Diluted |  | $ | 0.29 |  |  | $ | 0.44 |  |  |  |  |  |
| Weighted-average number of shares outstanding |  |  |  |  |  |  |  |  |
| Basic |  | 899.2 |  |  | 835.0 |  |  |  |  |  |
| Diluted |  | 913.0 |  |  | 852.2 |  |  |  |  |  |

[0001783180-24-000042:8k_2_02:55]
6

[0001783180-24-000042:8k_2_02:56]
Carrier Global Corporation

[0001783180-24-000042:8k_2_02:57]
Condensed Consolidated Balance Sheet

[0001783180-24-000042:8k_2_02:58]
|  |  | (Unaudited) |
| (In millions) |  | March 31, 2024 |  | December 31, 2023 |
| Assets |  |  |  |  |
| Cash and cash equivalents |  | $ | 1,313 |  |  | $ | 10,015 |  |
| Accounts receivable, net |  | 3,156 |  |  | 2,481 |  |
| Contract assets, current |  | 320 |  |  | 306 |  |
| Inventories, net |  | 3,189 |  |  | 2,217 |  |
| Assets held for sale, current |  | 3,169 |  |  | 3,314 |  |
| Other assets, current |  | 568 |  |  | 447 |  |
| Total current assets |  | 11,715 |  |  | 18,780 |  |
| Future income tax benefits |  | 823 |  |  | 739 |  |
| Fixed assets, net |  | 3,179 |  |  | 2,293 |  |
| Operating lease right-of-use assets |  | 633 |  |  | 491 |  |
| Intangible assets, net |  | 7,351 |  |  | 1,028 |  |
| Goodwill |  | 15,366 |  |  | 7,989 |  |
| Pension and post-retirement assets |  | 78 |  |  | 32 |  |
| Equity method investments |  | 1,155 |  |  | 1,140 |  |
| Other assets |  | 510 |  |  | 330 |  |
| Total Assets |  | $ | 40,810 |  |  | $ | 32,822 |  |
| Liabilities and Equity |  |  |  |  |
| Accounts payable |  | $ | 3,074 |  |  | $ | 2,742 |  |
| Accrued liabilities |  | 2,994 |  |  | 2,811 |  |
| Contract liabilities, current |  | 501 |  |  | 425 |  |
| Liabilities held for sale, current |  | 820 |  |  | 862 |  |
| Current portion of long-term debt |  | 1,248 |  |  | 51 |  |
| Total current liabilities |  | 8,637 |  |  | 6,891 |  |
| Long-term debt |  | 15,647 |  |  | 14,242 |  |
| Future pension and post-retirement obligations |  | 259 |  |  | 155 |  |
| Future income tax obligations |  | 2,272 |  |  | 535 |  |
| Operating lease liabilities |  | 505 |  |  | 391 |  |
| Other long-term liabilities |  | 1,584 |  |  | 1,603 |  |
| Total Liabilities |  | 28,904 |  |  | 23,817 |  |
| Equity |  |  |  |  |
| Common stock |  | 9 |  |  | 9 |  |
| Treasury stock |  | (1,972) |  |  | (1,972) |  |
| Additional paid-in capital |  | 8,536 |  |  | 5,535 |  |
| Retained earnings |  | 6,860 |  |  | 6,591 |  |
| Accumulated other comprehensive loss |  | (1,872) |  |  | (1,486) |  |
| Non-controlling interest |  | 345 |  |  | 328 |  |
| Total Equity |  | 11,906 |  |  | 9,005 |  |
| Total Liabilities and Equity |  | $ | 40,810 |  |  | $ | 32,822 |  |

[0001783180-24-000042:8k_2_02:59]
7

[0001783180-24-000042:8k_2_02:60]
Carrier Global Corporation

[0001783180-24-000042:8k_2_02:61]
Condensed Consolidated Statement of Cash Flows

[0001783180-24-000042:8k_2_02:62]
|  |  |  |  | (Unaudited) |
|  |  |  | Three Months Ended March 31, |
| (In millions) |  |  |  |  | 2024 |  | 2023 |
| Operating Activities |  |  |  |  |  |  |  |
| Net income from operations |  |  |  |  | $ | 289 |  |  | $ | 387 |  |
| Adjustments to reconcile net income to net cash flows from operating activities: |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  |  |  | 314 |  |  | 136 |  |
| Deferred income tax provision |  |  |  |  | (123) |  |  | (24) |  |
| Stock-based compensation costs |  |  |  |  | 22 |  |  | 22 |  |
| Equity method investment net earnings |  |  |  |  | (31) |  |  | (44) |  |
| (Gain) loss on sale of investments / deconsolidation |  |  |  |  | — |  |  | (16) |  |
| Changes in operating assets and liabilities |  |  |  |  |  |  |  |
| Accounts receivable, net |  |  |  |  | (205) |  |  | (157) |  |
| Contract assets, current |  |  |  |  | (33) |  |  | (28) |  |
| Inventories, net |  |  |  |  | (72) |  |  | (126) |  |
| Other assets, current |  |  |  |  | (52) |  |  | (60) |  |
| Accounts payable and accrued liabilities |  |  |  |  | (195) |  |  | (25) |  |
| Contract liabilities, current |  |  |  |  | (18) |  |  | 64 |  |
| Defined benefit plan contributions |  |  |  |  | (6) |  |  | (6) |  |
| Distributions from equity method investments |  |  |  |  | 7 |  |  | 3 |  |
| Other operating activities, net |  |  |  |  | 143 |  |  | (6) |  |
| Net cash flows provided by (used in) operating activities |  |  |  |  | 40 |  |  | 120 |  |
| Investing Activities |  |  |  |  |  |  |  |
| Capital expenditures |  |  |  |  | (104) |  |  | (70) |  |
| Investments in businesses, net of cash acquired |  |  |  |  | (10,772) |  |  | (52) |  |
| Disposition of businesses |  |  |  |  | — |  |  | 35 |  |
| Settlement of derivative contracts, net |  |  |  |  | (209) |  |  | (18) |  |
| Other investing activities, net |  |  |  |  | 4 |  |  | 5 |  |
| Net cash flows provided by (used in) investing activities |  |  |  |  | (11,081) |  |  | (100) |  |
| Financing Activities |  |  |  |  |  |  |  |
| Increase (decrease) in short-term borrowings, net |  |  |  |  | 19 |  |  | 10 |  |
| Issuance of long-term debt |  |  |  |  | 2,548 |  |  | 5 |  |
| Repayment of long-term debt |  |  |  |  | (5) |  |  | (2) |  |
| Repurchases of common stock |  |  |  |  | — |  |  | (62) |  |
| Dividends paid on common stock |  |  |  |  | (159) |  |  | (154) |  |
| Dividends paid to non-controlling interest |  |  |  |  | (2) |  |  | — |  |
| Other financing activities, net |  |  |  |  | (22) |  |  | (10) |  |
| Net cash flows provided by (used in) financing activities |  |  |  |  | 2,379 |  |  | (213) |  |
| Effect of foreign exchange rate changes on cash and cash equivalents |  |  |  |  | (68) |  |  | 20 |  |
| Net increase (decrease) in cash and cash equivalents and restricted cash, including cash classified in current assets held for sale |  |  |  |  | (8,730) |  |  | (173) |  |
| Less: Change in cash balances classified as assets held for sale |  |  |  |  | (30) |  |  | — |  |
| Net increase (decrease) in cash and cash equivalents and restricted cash |  |  |  |  | (8,700) |  |  | (173) |  |
| Cash, cash equivalents and restricted cash, beginning of period |  |  |  |  | 10,017 |  |  | 3,527 |  |
| Cash, cash equivalents and restricted cash, end of period |  |  |  |  | 1,317 |  |  | 3,354 |  |
| Less: restricted cash |  |  |  |  | 4 |  |  | 7 |  |
| Cash and cash equivalents, end of period |  |  |  |  | $ | 1,313 |  |  | $ | 3,347 |  |

[0001783180-24-000042:8k_2_02:63]
8

[0001783180-24-000042:8k_2_02:64]
Carrier Global Corporation

[0001783180-24-000042:8k_2_02:65]
Segment Net Sales and Operating Profit

[0001783180-24-000042:8k_2_02:66]
|  | (Unaudited) |
|  | Three Months Ended March 31, |  |  |
|  | 2024 |  | 2023 |  |  |  |  |
| (In millions) | Reported |  | Adjusted |  | Reported |  | Adjusted |  |  |  |  |  |  |  |  |
| Net sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| HVAC | $ | 4,541 |  | $ | 4,541 |  | $ | 3,622 |  | $ | 3,622 |  |  |  |  |  |  |  |  |
| Refrigeration | 884 |  | 884 |  | 898 |  | 898 |  |  |  |  |  |  |  |  |
| Fire & Security | 887 |  | 887 |  | 869 |  | 869 |  |  |  |  |  |  |  |  |
| Segment sales | 6,312 |  | 6,312 |  | 5,389 |  | 5,389 |  |  |  |  |  |  |  |  |
| Eliminations and other | (130) |  | (130) |  | (116) |  | (116) |  |  |  |  |  |  |  |  |
| Net sales | $ | 6,182 |  | $ | 6,182 |  | $ | 5,273 |  | $ | 5,273 |  |  |  |  |  |  |  |  |
| Operating profit |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| HVAC | $ | 429 |  | $ | 720 |  | $ | 435 |  | $ | 490 |  |  |  |  |  |  |  |  |
| Refrigeration | 97 |  | 99 |  | 108 |  | 111 |  |  |  |  |  |  |  |  |
| Fire & Security | 153 |  | 164 |  | 93 |  | 108 |  |  |  |  |  |  |  |  |
| Segment operating profit | 679 |  | 983 |  | 636 |  | 709 |  |  |  |  |  |  |  |  |
| Eliminations and other | (75) |  | (34) |  | (38) |  | (36) |  |  |  |  |  |  |  |  |
| General corporate expenses | (104) |  | (22) |  | (43) |  | (31) |  |  |  |  |  |  |  |  |
| Operating profit | $ | 500 |  | $ | 927 |  | $ | 555 |  | $ | 642 |  |  |  |  |  |  |  |  |
| Operating margin |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| HVAC | 9.4 | % |  | 15.9 | % |  | 12.0 | % |  | 13.5 | % |  |  |  |  |  |  |  |  |
| Refrigeration | 11.0 | % |  | 11.2 | % |  | 12.0 | % |  | 12.4 | % |  |  |  |  |  |  |  |  |
| Fire & Security | 17.2 | % |  | 18.5 | % |  | 10.7 | % |  | 12.4 | % |  |  |  |  |  |  |  |  |
| Total Carrier | 8.1 | % |  | 15.0 | % |  | 10.5 | % |  | 12.2 | % |  |  |  |  |  |  |  |  |

[0001783180-24-000042:8k_2_02:67]
9

[0001783180-24-000042:8k_2_02:68]
Carrier Global Corporation

[0001783180-24-000042:8k_2_02:69]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP)

[0001783180-24-000042:8k_2_02:70]
Operating Profit

[0001783180-24-000042:8k_2_02:71]
|  | (Unaudited) |
|  | Three Months Ended March 31, 2024 |
| (In millions) | HVAC |  | Refrigeration |  | Fire & Security |  | Eliminations and Other |  | General Corporate Expenses |  | Carrier |
| Net sales | $ | 4,541 |  |  | $ | 884 |  |  | $ | 887 |  |  | $ | (130) |  |  | $ | — |  |  | $ | 6,182 |  |
| Segment operating profit | $ | 429 |  |  | $ | 97 |  |  | $ | 153 |  |  | $ | (75) |  |  | $ | (104) |  |  | $ | 500 |  |
| Reported operating margin | 9.4 | % |  | 11.0 | % |  | 17.2 | % |  |  |  |  |  | 8.1 | % |
| Adjustments to segment operating profit: |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring costs | $ | 7 |  |  | $ | — |  |  | $ | 7 |  |  | $ | 1 |  |  | $ | — |  |  | $ | 15 |  |
| Amortization of acquired intangibles | 172 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 172 |  |
| Acquisition step-up amortization (1) | 111 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 111 |  |
| Acquisition/divestiture-related costs | 1 |  |  | 2 |  |  | 4 |  |  | — |  |  | 82 |  |  | 89 |  |
| Viessmann-related hedges | — |  |  | — |  |  | — |  |  | 86 |  |  | — |  |  | 86 |  |
| Gain on liability adjustment (2) | — |  |  | — |  |  | — |  |  | (46) |  |  | — |  |  | (46) |  |
| Total adjustments to operating profit | $ | 291 |  |  | $ | 2 |  |  | $ | 11 |  |  | $ | 41 |  |  | $ | 82 |  |  | $ | 427 |  |
| Adjusted operating profit | $ | 720 |  |  | $ | 99 |  |  | $ | 164 |  |  | $ | (34) |  |  | $ | (22) |  |  | $ | 927 |  |
| Adjusted operating margin | 15.9 | % |  | 11.2 | % |  | 18.5 | % |  |  |  |  |  | 15.0 | % |

[0001783180-24-000042:8k_2_02:72]
|  | (Unaudited) |
|  | Three Months Ended March 31, 2023 |
| (In millions) | HVAC |  | Refrigeration |  | Fire & Security |  | Eliminations and Other |  | General Corporate Expenses |  | Carrier |
| Net sales | $ | 3,622 |  |  | $ | 898 |  |  | $ | 869 |  |  | $ | (116) |  |  | $ | — |  |  | $ | 5,273 |  |
| Segment operating profit | $ | 435 |  |  | $ | 108 |  |  | $ | 93 |  |  | $ | (38) |  |  | $ | (43) |  |  | $ | 555 |  |
| Reported operating margin | 12.0 | % |  | 12.0 | % |  | 10.7 | % |  |  |  |  |  | 10.5 | % |
| Adjustments to segment operating profit: |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring costs | $ | (1) |  |  | $ | 3 |  |  | $ | 13 |  |  | $ | 2 |  |  | $ | — |  |  | $ | 17 |  |
| Amortization of acquired intangibles | 37 |  |  | — |  |  | 2 |  |  | — |  |  | — |  |  | 39 |  |
| Acquisition step-up amortization (1) | 11 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 11 |  |
| Acquisition/divestiture-related costs | — |  |  | — |  |  | — |  |  | — |  |  | 12 |  |  | 12 |  |
| TCC acquisition-related gain (3) | 8 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 8 |  |
| Total adjustments to operating profit | $ | 55 |  |  | $ | 3 |  |  | $ | 15 |  |  | $ | 2 |  |  | $ | 12 |  |  | $ | 87 |  |
| Adjusted operating profit | $ | 490 |  |  | $ | 111 |  |  | $ | 108 |  |  | $ | (36) |  |  | $ | (31) |  |  | $ | 642 |  |
| Adjusted operating margin | 13.5 | % |  | 12.4 | % |  | 12.4 | % |  |  |  |  |  | 12.2 | % |

[0001783180-24-000042:8k_2_02:73]
(1)  Amortization of the step-up to fair value of acquired inventory and backlog.

[0001783180-24-000042:8k_2_02:74]
(2) Gain associated with an adjustment to our tax-related liability owed to UTC.

[0001783180-24-000042:8k_2_02:75]
(3) The carrying value of our previously held TCC equity investments were recognized at fair value at the TCC acquisition date.

[0001783180-24-000042:8k_2_02:76]
10

[0001783180-24-000042:8k_2_02:77]
Carrier Global Corporation

[0001783180-24-000042:8k_2_02:78]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP) Results

[0001783180-24-000042:8k_2_02:79]
Net Income, Earnings Per Share and Effective Tax Rate

[0001783180-24-000042:8k_2_02:80]
|  | (Unaudited) |
|  | Three Months Ended March 31, 2024 |  |  |
| (In millions, except per share amounts) | Reported |  | Adjustments |  | Adjusted |  |  |  |  |  |  |
| Net sales | $ | 6,182 |  |  | $ | — |  |  | $ | 6,182 |  |  |  |  |  |  |  |
| Operating profit | $ | 500 |  |  | 427 |  | a | $ | 927 |  |  |  |  |  |  |  |
| Operating margin | 8.1 | % |  |  |  | 15.0 | % |  |  |  |  |  |  |
| Income from operations before income taxes | $ | 335 |  |  | 427 |  | a | $ | 762 |  |  |  |  |  |  |  |
| Income tax expense | $ | (46) |  |  | (131) |  | c | $ | (177) |  |  |  |  |  |  |  |
| Effective tax rate | 13.7 | % |  |  |  | 23.2 | % |  |  |  |  |  |  |
| Net income attributable to common shareowners | $ | 269 |  |  | $ | 296 |  |  | $ | 565 |  |  |  |  |  |  |  |
| Summary of Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring costs |  |  | $ | 15 |  | a |  |  |  |  |  |  |  |
| Amortization of acquired intangibles |  |  | 172 |  | a |  |  |  |  |  |  |  |
| Acquisition step-up amortization (1) |  |  | 111 |  | a |  |  |  |  |  |  |  |
| Acquisition/divestiture-related costs |  |  | 89 |  | a |  |  |  |  |  |  |  |
| Viessmann-related hedges |  |  | 86 |  | a |  |  |  |  |  |  |  |
| Gain on liability adjustment (2) |  |  | (46) |  | a |  |  |  |  |  |  |  |
| Total adjustments |  |  | $ | 427 |  |  |  |  |  |  |  |  |  |
| Tax effect on adjustments above |  |  | $ | (96) |  |  |  |  |  |  |  |  |  |
| Tax specific adjustments |  |  | (35) |  |  |  |  |  |  |  |  |  |
| Total tax adjustments |  |  | $ | (131) |  | c |  |  |  |  |  |  |  |
| Shares outstanding - Diluted | 913.0 |  |  |  |  | 913.0 |  |  |  |  |  |  |  |
| Earnings per share - Diluted | $ | 0.29 |  |  |  |  | $ | 0.62 |  |  |  |  |  |  |  |

[0001783180-24-000042:8k_2_02:81]
(1)  Amortization of the step-up to fair value of acquired inventory and backlog.

[0001783180-24-000042:8k_2_02:82]
(2) Gain associated with an adjustment to our tax-related liability owed to UTC.

[0001783180-24-000042:8k_2_02:83]
11

[0001783180-24-000042:8k_2_02:84]
Carrier Global Corporation

[0001783180-24-000042:8k_2_02:85]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP) Results

[0001783180-24-000042:8k_2_02:86]
Net Income, Earnings Per Share and Effective Tax Rate

[0001783180-24-000042:8k_2_02:87]
|  | (Unaudited) |
|  | Three Months Ended March 31, 2023 |  |  |
| (In millions, except per share amounts) | Reported |  | Adjustments |  | Adjusted |  |  |  |  |  |  |
| Net sales | $ | 5,273 |  |  | $ | — |  |  | $ | 5,273 |  |  |  |  |  |  |  |
| Operating profit | $ | 555 |  |  | 87 |  | a | $ | 642 |  |  |  |  |  |  |  |
| Operating margin | 10.5 | % |  |  |  | 12.2 | % |  |  |  |  |  |  |
| Income from operations before income taxes | $ | 509 |  |  | 87 |  | a | $ | 596 |  |  |  |  |  |  |  |
| Income tax expense | $ | (122) |  |  | (18) |  | c | $ | (140) |  |  |  |  |  |  |  |
| Effective tax rate | 24.0 | % |  |  |  | 23.5 | % |  |  |  |  |  |  |
| Net income attributable to common shareowners | $ | 373 |  |  | $ | 69 |  |  | $ | 442 |  |  |  |  |  |  |  |
| Summary of Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring costs |  |  | $ | 17 |  | a |  |  |  |  |  |  |  |
| Amortization of acquired intangibles |  |  | 39 |  | a |  |  |  |  |  |  |  |
| Acquisition step-up amortization (1) |  |  | 11 |  | a |  |  |  |  |  |  |  |
| Acquisition/divestiture-related costs |  |  | 12 |  | a |  |  |  |  |  |  |  |
| TCC acquisition-related gain (2) |  |  | 8 |  | a |  |  |  |  |  |  |  |
| Total adjustments |  |  | $ | 87 |  |  |  |  |  |  |  |  |  |
| Tax effect on adjustments above |  |  | $ | (18) |  |  |  |  |  |  |  |  |  |
| Total tax adjustments |  |  | $ | (18) |  | c |  |  |  |  |  |  |  |
| Shares outstanding - Diluted | 852.2 |  |  |  |  | 852.2 |  |  |  |  |  |  |  |
| Earnings per share - Diluted | $ | 0.44 |  |  |  |  | $ | 0.52 |  |  |  |  |  |  |  |

[0001783180-24-000042:8k_2_02:88]
(1) Amortization of the step-up to fair value of acquired inventory and backlog.

[0001783180-24-000042:8k_2_02:89]
(2) The carrying value of our previously held TCC equity investments were recognized at fair value at the TCC acquisition date.

[0001783180-24-000042:8k_2_02:90]
12

[0001783180-24-000042:8k_2_02:91]
Carrier Global Corporation

[0001783180-24-000042:8k_2_02:92]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP) Results

[0001783180-24-000042:8k_2_02:93]
Components of Changes in Net Sales

[0001783180-24-000042:8k_2_02:94]
| Three Months Ended March 31, 2024 Compared with Three Months Ended March 31, 2023 |
|  | (Unaudited) |
|  | Factors Contributing to Total % change in Net Sales |
|  | Organic |  | FX Translation |  | Acquisitions / Divestitures, net |  | Other |  | Total |
| HVAC | 2 | % |  | (1) | % |  | 24 | % |  | — | % |  | 25 | % |
| Refrigeration | (2) | % |  | — | % |  | — | % |  | — | % |  | (2) | % |
| Fire & Security | 7 | % |  | — | % |  | (5) | % |  | — | % |  | 2 | % |
| Consolidated | 2 | % |  | — | % |  | 15 | % |  | — | % |  | 17 | % |

[0001783180-24-000042:8k_2_02:95]
Historical Amounts of Amortization of Acquired Intangibles

[0001783180-24-000042:8k_2_02:96]
|  |  | (Unaudited) |  |  |
|  |  | Q1 |  | Q2 |  | Q3 |  | Q4 |  | FY |  | Q1 |  |  |  |  |
| (In millions) |  | 2023 |  | 2023 |  | 2023 |  | 2023 |  | 2023 |  | 2024 |  |  |  |  |
| HVAC |  | $ | 37 |  |  | $ | 36 |  |  | $ | 35 |  |  | $ | 35 |  |  | $ | 143 |  |  | $ | 172 |  |  |  |  |  |
| Fire & Security |  | 2 |  |  | 2 |  |  | 2 |  |  | — |  |  | 6 |  |  | — |  |  |  |  |  |
| Total Carrier |  | 39 |  |  | 38 |  |  | 37 |  |  | 35 |  | 149 |  |  | 172 |  |  |  |  |  |
| Associated tax effect |  | (12) |  |  | (11) |  |  | (11) |  |  | (11) |  |  | (45) |  |  | (46) |  |  |  |  |  |
| Net impact to adjusted results |  | $ | 27 |  |  | $ | 27 |  |  | $ | 26 |  |  | $ | 24 |  |  | $ | 104 |  |  | $ | 126 |  |  |  |  |  |

[0001783180-24-000042:8k_2_02:97]
Free Cash Flow Reconciliation

[0001783180-24-000042:8k_2_02:98]
|  |  | (Unaudited) |
|  |  | Q1 |  | Q2 |  | Q3 |  | Q4 |  | FY |  | Q1 |  |  |  |  |
| (In millions) |  | 2023 |  | 2023 |  | 2023 |  | 2023 |  | 2023 |  | 2024 |  |  |  |  |
| Net cash flows provided by (used in) operating activities |  | $ | 120 |  |  | $ | 384 |  |  | $ | 1,041 |  |  | $ | 1,062 |  |  | $ | 2,607 |  |  | $ | 40 |  |  |  |  |  |
| Less: Capital expenditures |  | 70 |  |  | 74 |  |  | 92 |  |  | 233 |  | 469 |  |  | 104 |  |  |  |  |  |
| Free cash flow |  | $ | 50 |  |  | $ | 310 |  |  | $ | 949 |  |  | $ | 829 |  |  | $ | 2,138 |  |  | $ | (64) |  |  |  |  |  |

[0001783180-24-000042:8k_2_02:99]
Net Debt Reconciliation

[0001783180-24-000042:8k_2_02:100]
|  |  | (Unaudited) |
| (In millions) |  | March 31, 2024 |  | December 31, 2023 |
| Long-term debt |  | $ | 15,647 |  |  | $ | 14,242 |  |
| Current portion of long-term debt |  | 1,248 |  |  | 51 |  |
| Less: Cash and cash equivalents |  | 1,313 |  |  | 10,015 |  |
| Net debt |  | $ | 15,582 |  |  | $ | 4,278 |  |

[0001783180-24-000042:8k_2_02:101]
13
