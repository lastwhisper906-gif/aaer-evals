# CARR note change history — 0001783180-23-000038 → 0001783180-23-000056


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-07-27):
[0001783180-23-000056:note_history:1]
COMMITMENTS AND CONTINGENT LIABILITIES
The Company is involved in various litigation, claims and administrative proceedings, including those related to environmental (including asbestos) and legal matters. In accordance with ASC 450, Contingencies, the Company records accruals for loss contingencies when it is probable that a liability has been incurred and the amount of the loss can be reasonably estimated. These accruals are generally based upon a range of possible outcomes. If no amount within the range is a better estimate than any other, the Company accrues the minimum amount. In addition, these estimates are reviewed periodically and adjusted to reflect additional information when it becomes available. The Company is unable to predict the final outcome of the following matters based on the information currently available, except as otherwise noted. However, the Company does not believe that the resolution of any of these matters will have a material adverse effect upon its results of operations, cash flows or financial condition.
  (was, 2023-04-26, similarity 0.9928):
[0001783180-23-000038:note_history:1]
COMMITMENTS AND CONTINGENT LIABILITIES
The Company is involved in various litigation, claims and administrative proceedings, including those related to environmental (including asbestos) and legal matters. In accordance with ASC 450, Contingencies, the Company records accruals for loss contingencies when it is probable that a liability will be incurred and the amount of the loss can be reasonably estimated. These accruals are generally based upon a range of possible outcomes. If no amount within the range is a better estimate than any other, the Company accrues the minimum amount. In addition, these estimates are reviewed periodically and adjusted to reflect additional information when it becomes available. The Company is unable to predict the final outcome of the following matters based on the information currently available, except as otherwise noted. However, the Company does not believe that the resolution of any of these matters will have a material adverse effect upon its results of operations, cash flows or financial condition.

- changed (2023-07-27):
[0001783180-23-000056:note_history:2]
| (In millions) |  | June 30,2023 |  | December 31,2022 |
| Environmental reserves included in Accrued liabilities |  | $ | 15 |  |  | $ | 24 |  |
| Environmental reserves included in Other long-term liabilities |  | 203 |  |  | 211 |  |
| Total Environmental reserves |  | $ | 218 |  |  | $ | 235 |  |
  (was, 2023-04-26, similarity 0.9794):
[0001783180-23-000038:note_history:2]
| (In millions) |  | March 31,2023 |  | December 31, 2022 |
| Environmental reserves included in Accrued liabilities |  | $ | 19 |  |  | $ | 24 |  |
| Environmental reserves included in Other long-term liabilities |  | 214 |  |  | 211 |  |
| Total Environmental reserves |  | $ | 233 |  |  | $ | 235 |  |

- changed (2023-07-27):
[0001783180-23-000056:note_history:3]
| (In millions) |  | June 30,2023 |  | December 31,2022 |
| Asbestos liabilities included in Accrued liabilities |  | $ | 16 |  |  | $ | 16 |  |
| Asbestos liabilities included in Other long-term liabilities |  | 207 |  |  | 212 |  |
| Total Asbestos liabilities |  | $ | 223 |  |  | $ | 228 |  |
| Asbestos-related recoveries included in Other assets, current |  | $ | 5 |  |  | $ | 5 |  |
| Asbestos-related recoveries included in Other assets |  | 89 |  |  | 90 |  |
| Total Asbestos-related recoveries |  | $ | 94 |  |  | $ | 95 |  |
  (was, 2023-04-26, similarity 0.9907):
[0001783180-23-000038:note_history:3]
| (In millions) |  | March 31,2023 |  | December 31,2022 |
| Asbestos liabilities included in Accrued liabilities |  | $ | 16 |  |  | $ | 16 |  |
| Asbestos liabilities included in Other long-term liabilities |  | 211 |  |  | 212 |  |
| Total Asbestos liabilities |  | $ | 227 |  |  | $ | 228 |  |
| Asbestos-related recoveries included in Other assets, current |  | $ | 5 |  |  | $ | 5 |  |
| Asbestos-related recoveries included in Other assets |  | 89 |  |  | 90 |  |
| Total Asbestos-related recoveries |  | $ | 94 |  |  | $ | 95 |  |

- changed (2023-07-27):
[0001783180-23-000056:note_history:4]
On August 12, 2020, several former employees of UTC or its subsidiaries filed a putative class action complaint (the "Complaint") in the United States District Court for the District of Connecticut against Raytheon Technologies Corporation, Carrier, Otis Worldwide Corporation ("Otis"), the former members of the UTC Board of Directors and the members of the Carrier and Otis Boards of Directors (Geraud Darnis, et al. v. Raytheon Technologies Corporation, et al.). The Complaint challenged the method by which UTC equity awards were converted to UTC, Carrier and Otis equity awards following the Separation and the Distribution. Defendants moved to dismiss the Complaint. Plaintiffs amended their Complaint on September 13, 2021 (the "Amended Complaint"). The Amended Complaint, with Raytheon Technologies Corporation, Carrier and Otis as the only defendants, asserted that the defendants are liable for breach of certain equity compensation plans and for breach of the implied covenant of good faith and fair dealing. The Amended Complaint also sought specific performance. The Company believes all plaintiffs' claims against it are without merit. Defendants moved to dismiss the Amended Complaint. On September 30, 2022, the court dismissed the case against all defendants, with prejudice. Plaintiffs appealed the dismissal to the United States Court of Appeals for the Second Circuit. Oral arguments on the appeal were held before the Second Circuit on June 29, 2023 and a decision is pending.
  (was, 2023-04-26, similarity 0.9394):
[0001783180-23-000038:note_history:4]
On August 12, 2020, several former employees of UTC or its subsidiaries filed a putative class action complaint (the "Complaint") in the United States District Court for the District of Connecticut against Raytheon Technologies Corporation ("Raytheon"), Carrier, Otis Worldwide Corporation ("Otis"), the former members of the UTC Board of Directors and the members of the Carrier and Otis Boards of Directors (Geraud Darnis, et al. v. Raytheon Technologies Corporation, et al.). The Complaint challenged the method by which UTC equity awards were converted to UTC, Carrier and Otis equity awards following the Separation and the Distribution. Defendants moved to dismiss the Complaint. Plaintiffs amended their Complaint on September 13, 2021 (the "Amended Complaint"). The Amended Complaint, with Raytheon, Carrier and Otis as the only defendants, asserted that the defendants are liable for breach of certain equity compensation plans and for breach of the implied covenant of good faith and fair dealing. The Amended Complaint also sought specific performance. The Company believes all plaintiffs' claims against it are without merit. Defendants moved to dismiss the Amended Complaint. On September 30, 2022, the court dismissed the case against all defendants, with prejudice. Plaintiffs appealed the dismissal to the United States Court of Appeals for the Second Circuit. Oral arguments on the appeal is scheduled to occur before the Second Circuit on June 29, 2023.

- changed (2023-07-27):
[0001783180-23-000056:note_history:5]
As of June 30, 2023, the Company, KFI and others have been named as defendants in more than 4,500 lawsuits filed by individuals in or removed to the federal courts of the United States alleging that the historic use of Aqueous Film Forming Foam ("AFFF") caused personal injuries and/or property damage. The Company, KFI and others have also been named as defendants in more than 500 lawsuits filed by several U.S. states, municipalities and water utilities in or removed to U.S. federal courts alleging that the historic use of AFFF caused contamination of property and water supplies. In December 2018, the U.S. Judicial Panel on Multidistrict Litigation transferred and consolidated all AFFF cases pending in the U.S. federal courts against the Company, KFI and others to the U.S. District Court for the District of South Carolina (the "MDL Proceedings"). The individual plaintiffs in the MDL Proceedings generally seek damages for alleged personal injuries, medical monitoring, diminution in property value and injunctive relief to remediate alleged contamination of water supplies. The U.S. state, municipal and water utility plaintiffs in the MDL Proceedings generally seek damages and costs related to the remediation of public property and water supplies.
  (was, 2023-04-26, similarity 0.9096):
[0001783180-23-000038:note_history:5]
As of March 31, 2023,  the Company and certain  of its subsidiaries, including Kidde-Fenwal, Inc. ("KFI"), have been named as defendants in more than 3,800 lawsuits filed by individuals in or removed to the federal courts of the United States alleging that the historic use of Aqueous Film Forming Foam ("AFFF") caused personal injuries and/or property damage. The Company and certain of its subsidiaries, including KFI, have also been named as a defendant in more than 370 lawsuits filed by several U.S. states, municipalities and water utilities in or removed to U.S. federal courts alleging that the historic use of AFFF caused contamination of property and water supplies. In December 2018, the U.S. Judicial Panel on Multidistrict Litigation transferred and consolidated all AFFF cases pending in the U.S. federal courts against the Company and others to the U.S. District Court for the District of South Carolina ("MDL Court") for pre-trial proceedings ("MDL Proceedings"). The individual plaintiffs in the MDL Proceedings generally seek damages for alleged personal injuries, medical monitoring, diminution in property value and injunctive relief to remediate alleged contamination of water supplies. The U.S. state, municipal and water utility plaintiffs in the MDL Proceedings generally seek damages and costs related to the remediation of public property and water supplies.

- added (2023-07-27):
[0001783180-23-000056:note_history:6]
AFFF is a firefighting foam, developed beginning in the late 1960s pursuant to U.S. military specification, used to extinguish certain types of hydrocarbon-fueled fires. The lawsuits identified above relate to Kidde Fire Fighting, Inc. which owned the National Foam business. Kidde Fire Fighting, Inc. was acquired by a UTC subsidiary in 2005 and merged into KFI in 2007. The National Foam business manufactured AFFF for sale to government (including the U.S. federal government) and non-government customers in the U.S. at a single facility located in West Chester, Pennsylvania (the "Pennsylvania Site"). In 2013, KFI divested the AFFF businesses to an unrelated third party. The Company acquired KFI as part of the Separation in April 2020.

- changed (2023-07-27):
[0001783180-23-000056:note_history:7]
The key components that contribute to AFFF's fire-extinguishing capabilities are known as fluorosurfactants. Neither the Company, nor KFI, nor any of the Company's subsidiaries involved in the AFFF litigation manufactured fluorosurfactants. Instead, the National Foam business purchased these substances from unrelated third parties for use in manufacturing AFFF. Plaintiffs in the MDL Proceedings allege that the fluorosurfactants used by various manufacturers in producing AFFF contained, or over time degraded into, compounds known as per- and polyfluoroalkyl substances (referred to collectively as "PFAS"), including perflourooctanesulfonic acid ("PFOS") and perflourooctanoic acid ("PFOA"). Plaintiffs further allege that, as a result of the use of AFFF, PFOS and PFOA were released into the environment and, in some instances, ultimately reached drinking water supplies.
  (was, 2023-04-26, similarity 0.6218):
[0001783180-23-000038:note_history:7]
The key components of AFFF that contribute to its fire-extinguishing capabilities are known as fluorosurfactants. Neither the Company nor any of its former or current subsidiaries, including National Foam/Angus Fire and KFI/KPL, respectively, manufactured fluorosurfactants; they instead purchased these substances from unrelated third parties to, in turn, manufacture AFFF. Plaintiffs in the MDL Proceedings allege that the fluorosurfactants used by various manufacturers in producing AFFF contained, or over time degraded into, compounds known as perflourooctane sulfonate ("PFOS") and/or perflourooctane acid ("PFOA"). Plaintiffs further allege that, as a result of the use of AFFF, PFOS and PFOA were released into the environment and, in some instances, ultimately reached drinking water supplies.

- changed (2023-07-27):
[0001783180-23-000056:note_history:8]
Plaintiffs in the MDL Proceedings allege that PFOS and PFOA contamination has resulted from the use of AFFF manufactured using a process known as ECF, and that this process was used exclusively by 3M. They also allege that PFOA contamination has resulted from the use of AFFF manufactured using a different process, known as telomerization, and that this process was used exclusively by the other AFFF manufacturers (including the National Foam business). Compounds containing PFOS and PFOA (as well as many other PFAS) have also been used for decades by many third parties in a number of different industries to manufacture firefighters’ protective outerwear, carpets, clothing, fabrics, cookware, food packaging, personal care products, cleaning products, paints, varnishes and other consumer and industrial products.
  (was, 2023-04-26, similarity 0.9294):
[0001783180-23-000038:note_history:8]
Plaintiffs in the MDL Proceedings allege that PFOS and PFOA contamination has resulted from the use of AFFF manufactured using a process known as ECF, and that this process was used exclusively by 3M. They also allege that PFOA contamination has resulted from the use of AFFF manufactured using a different process, known as telomerization, and that this process was used exclusively by the other AFFF manufacturers (including National Foam and Angus Fire). Compounds containing PFOS and PFOA (as well as many other per- and polyfluoroalkyl substances known collectively as "PFAS") have also been used for decades by many third parties in a number of different industries to manufacture firefighters’ protective outerwear, carpets, clothing, fabrics, cookware, food packaging, personal care products, cleaning products, paints, varnishes and other consumer and industrial products.

- added (2023-07-27):
[0001783180-23-000056:note_history:9]
Plaintiffs in the MDL Proceedings have named multiple defendants, including suppliers of chemicals and raw materials used to manufacture fluorosurfactants, fluorosurfactant manufacturers and AFFF manufacturers. The defendants in the MDL Proceedings moved for summary judgment on the government contractor defense, which potentially applies to AFFF sold to or used by the U.S. government. After full briefing and oral argument, on September 16, 2022, the MDL court declined to enter summary judgment for the defendants. The defense, however, remains available at any trial to which it applies.

- changed (2023-07-27):
[0001783180-23-000056:note_history:10]
On September 23, 2022, after completion of discovery, the MDL court selected one water provider case, the City of Stuart, FL v. 3M, et al., for a bellwether trial. That trial was scheduled to begin in early June 2023 but was postponed indefinitely. The MDL court ordered that the bellwether process for personal injury cases will begin in 2023. The court has not yet outlined details on that process or its timing.
  (was, 2023-04-26, similarity 0.8564):
[0001783180-23-000038:note_history:10]
On September 23, 2022, after completion of discovery, the MDL court selected one water provider case, the City of Stuart, FL v. 3M, et al., for a bellwether trial. That trial is scheduled for June 2023. The MDL court has ordered that the bellwether process for personal injury cases will begin in 2023. The court has not yet outlined details on that process or its timing.

- changed (2023-07-27):
[0001783180-23-000056:note_history:11]
Outside of the MDL Proceedings, the Company and other defendants also are party to six lawsuits in U.S. state courts brought by oil refining companies alleging product liability claims related to legacy sales of AFFF and seeking damages for the costs to replace the product and for property damage. In addition, the Company and other defendants are party to two actions related to the Pennsylvania Site in which the plaintiff water utility company seeks remediation costs related to the alleged contamination of the local water supply.
  (was, 2023-04-26, similarity 0.9869):
[0001783180-23-000038:note_history:11]
Outside of the MDL Proceedings, the Company and other defendants are also party to six lawsuits in U.S. state courts brought by oil refining companies alleging product liability claims related to legacy sales of AFFF and seeking damages for the costs to replace the product and for property damage. In addition, the Company and other defendants are party to two actions related to the Pennsylvania Site in which the plaintiff water utility company seeks remediation costs related to the alleged contamination of the local water supply.

- added (2023-07-27):
[0001783180-23-000056:note_history:12]
The Company, KFI and other defendants are also party to one action in Arizona state court brought by a firefighter claiming that occupational exposure to AFFF has caused certain personal injuries. The Company and KFI believe that they have meritorious defenses to the claims in the MDL Proceedings and the other AFFF lawsuits. Given the numerous factual, scientific and legal issues to be resolved relating to these claims, the Company is unable to assess the probability of liability or to reasonably estimate a range of possible loss at this time. There can be no assurance that any such future exposure will not be material in any period.

- added (2023-07-27):
[0001783180-23-000056:note_history:13]
On May 14, 2023, KFI filed a voluntary petition with the United States Bankruptcy Court for the District of Delaware seeking relief under Chapter 11 of the Bankruptcy Code after the Company determined that it would not provide financial support to KFI going forward, other than ensuring KFI has access to services necessary for the effective operation of its business. As a result, all litigation against KFI is automatically stayed. KFI filed an adversary complaint and motion in the Chapter 11 case seeking an order staying or enjoining all AFFF-related litigation against the Company, its other subsidiaries and RTX. KFI has also indicated to the bankruptcy court that it intends to pursue insurance coverage for AFFF-related liabilities and contractual indemnification for AFFF-related liabilities from the third party to which KFI sold National Foam.

- added (2023-07-27):
[0001783180-23-000056:note_history:14]
Deconsolidation Due to Bankruptcy

- added (2023-07-27):
[0001783180-23-000056:note_history:15]
As of May 14, 2023, the Company no longer controls KFI as their activities are subject to review and oversight by the bankruptcy court. Therefore, KFI was deconsolidated and their respective assets and liabilities were derecognized from the Company’s Unaudited Condensed Consolidated Financial Statements. Upon deconsolidation, the Company determined the fair value of its retained interest in KFI to be zero and will account for it prospectively using the cost method. As a result of these actions, the Company recognized a loss of $293 million in its Unaudited Condensed Consolidated Statements of Operations

- added (2023-07-27):
[0001783180-23-000056:note_history:16]
within Other income/(expense), net. In addition, the deconsolidation resulted in an investing cash outflow of $134 million in the Company's Unaudited Condensed Consolidated Statements of Cash Flows.

- added (2023-07-27):
[0001783180-23-000056:note_history:17]
In connection with the bankruptcy filing, KFI entered into several agreements with subsidiaries of the Company to ensure they have access to services necessary for the effective operation of their business. All post-deconsolidation activity between the Company and KFI are reported as third-party transactions recorded within the Company's Unaudited Condensed Consolidated Statements of Operations. Since the petition date, there were no material transactions between the Company and KFI.

- changed (2023-07-27):
[0001783180-23-000056:note_history:18]
Under the Tax Matters Agreement relating to the Separation, the Company is responsible to UTC for its share of the Tax Cuts and Jobs Act transition tax associated with foreign undistributed earnings as of December 31, 2017. As a result, liabilities of $75 million and $293 million are included within the accompanying Unaudited Condensed Consolidated Balance Sheet within Accrued Liabilities and Other Long-Term Liabilities as of June 30, 2023, respectively. This obligation is expected to be settled in annual installments ending in April 2026 with the next installment of $75 million due in 2024. The Company believes that the likelihood of incurring losses materially in excess of this amount is remote.
  (was, 2023-04-26, similarity 0.9934):
[0001783180-23-000038:note_history:18]
Under the Tax Matters Agreement relating to the Separation, the Company is responsible to UTC for its share of the Tax Cuts and Jobs Act transition tax associated with foreign undistributed earnings as of December 31, 2017. As a result, liabilities of $49 million and $368 million are included within the accompanying Unaudited Condensed Consolidated Balance Sheet within Accrued Liabilities and Other Long-Term Liabilities as of March 31, 2023, respectively. This obligation is expected to be settled in annual installments ending in April 2026 with the next installment of $49 million due in 2023. The Company believes that the likelihood of incurring losses materially in excess of this amount is remote.

- removed (2023-07-27):
[0001783180-23-000038:note_history:19]
AFFF is a firefighting foam, developed beginning in the late 1960s pursuant to U.S. military specification, used to extinguish certain types of hydrocarbon-fueled fires primarily at military bases and airports. AFFF was manufactured by several companies, including National Foam and Angus Fire. UTC subsidiaries first entered the AFFF business with their acquisition of National Foam and Angus Fire in 2005 as part of the acquisition of KFI and Kidde Products Limited ("KPL"). In 2013, KFI and KPL divested the National Foam and Angus Fire businesses to a third party. The Company acquired KFI and KPL as part of the Separation in April 2020. During the eight-year period of its operation by KFI, National Foam manufactured AFFF for sale to government (including the U.S. federal government) and non-government customers in the U.S. at a single facility located in

- removed (2023-07-27):
[0001783180-23-000038:note_history:20]
West Chester, Pennsylvania ("Pennsylvania Site"). During the same period, Angus Fire manufactured AFFF for sale outside the United States at a single facility located in Bentham, England.

- removed (2023-07-27):
[0001783180-23-000038:note_history:21]
Plaintiffs in the MDL Proceedings have named multiple defendants, including four suppliers of chemicals and raw materials used to manufacture fluorosurfactants, four fluorosurfactant manufacturers, two toll manufacturers of fluorosurfactants and seven current (including National Foam and Angus Fire) and former (including the Company and KFI) AFFF manufacturers.

- removed (2023-07-27):
[0001783180-23-000038:note_history:22]
The defendants moved for summary judgment on the government contractor defense, which potentially applies to AFFF sold to or used by the U.S. government. After full briefing and oral argument, on September 16, 2022, the MDL court declined to enter summary judgment for the defendants. The defense, however, remains available at any trial to which it applies.

- removed (2023-07-27):
[0001783180-23-000038:note_history:23]
The Company and its subsidiaries, including KFI, and other defendants are also party to one action in Arizona state court brought by a firefighter claiming that occupational exposure to AFFF has caused him certain personal injuries. The Company and its subsidiaries, including KFI, believe that they have meritorious defenses to the claims in the MDL Proceedings and the other AFFF lawsuits. Based on its 2013 agreement for the sale of National Foam and Angus Fire, the Company and its subsidiaries, including KFI, are pursuing indemnification against these claims from the purchaser and current owner of National Foam and Angus Fire. The Company and its subsidiaries, including KFI, are also pursuing insurance coverage for these claims. At this time, however, given the numerous factual, scientific and legal issues to be resolved relating to these claims, the Company is unable to assess the probability of liability or to reasonably estimate the damages, if any, to be allocated to the Company and its subsidiaries, including KFI, if one or more plaintiffs were to prevail in these cases. There can be no assurance that any such future exposure will not be material in any period.


## us-gaap:ScheduleOfEnvironmentalLossContingenciesBySiteTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-07-27):
[0001783180-23-000056:note_history:24]
| (In millions) |  | June 30,2023 |  | December 31,2022 |
| Environmental reserves included in Accrued liabilities |  | $ | 15 |  |  | $ | 24 |  |
| Environmental reserves included in Other long-term liabilities |  | 203 |  |  | 211 |  |
| Total Environmental reserves |  | $ | 218 |  |  | $ | 235 |  |
  (was, 2023-04-26, similarity 0.9794):
[0001783180-23-000038:note_history:24]
| (In millions) |  | March 31,2023 |  | December 31, 2022 |
| Environmental reserves included in Accrued liabilities |  | $ | 19 |  |  | $ | 24 |  |
| Environmental reserves included in Other long-term liabilities |  | 214 |  |  | 211 |  |
| Total Environmental reserves |  | $ | 233 |  |  | $ | 235 |  |


## us-gaap:ScheduleOfLossContingenciesByContingencyTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-07-27):
[0001783180-23-000056:note_history:25]
| (In millions) |  | June 30,2023 |  | December 31,2022 |
| Asbestos liabilities included in Accrued liabilities |  | $ | 16 |  |  | $ | 16 |  |
| Asbestos liabilities included in Other long-term liabilities |  | 207 |  |  | 212 |  |
| Total Asbestos liabilities |  | $ | 223 |  |  | $ | 228 |  |
| Asbestos-related recoveries included in Other assets, current |  | $ | 5 |  |  | $ | 5 |  |
| Asbestos-related recoveries included in Other assets |  | 89 |  |  | 90 |  |
| Total Asbestos-related recoveries |  | $ | 94 |  |  | $ | 95 |  |
  (was, 2023-04-26, similarity 0.9907):
[0001783180-23-000038:note_history:25]
| (In millions) |  | March 31,2023 |  | December 31,2022 |
| Asbestos liabilities included in Accrued liabilities |  | $ | 16 |  |  | $ | 16 |  |
| Asbestos liabilities included in Other long-term liabilities |  | 211 |  |  | 212 |  |
| Total Asbestos liabilities |  | $ | 227 |  |  | $ | 228 |  |
| Asbestos-related recoveries included in Other assets, current |  | $ | 5 |  |  | $ | 5 |  |
| Asbestos-related recoveries included in Other assets |  | 89 |  |  | 90 |  |
| Total Asbestos-related recoveries |  | $ | 94 |  |  | $ | 95 |  |


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2023-07-27):
[0001783180-23-000056:note_history:26]
Planned Portfolio Transformation

- added (2023-07-27):
[0001783180-23-000056:note_history:27]
On April 25, 2023, the Company announced that it entered into a Share Purchase Agreement (the “Agreement”) to acquire the climate solutions business (the "VCS Business") of Viessmann Group GmbH & Co. KG (“Viessmann”), a privately-held company, for approximately €12 billion. The VCS Business develops intelligent, integrated and sustainable technologies, including heat pumps, boilers, photovoltaic systems, home battery storage and digital solutions, primarily for residential customers in Europe. The transaction is expected to close around the end of 2023, subject to customary closing conditions and regulatory approvals. In addition, the Company also announced plans to exit its Fire & Security and Commercial Refrigeration businesses over the course of 2024. See Note 15 – Acquisitions and Note 16 - Divestitures for additional information.

- added (2023-07-27):
[0001783180-23-000056:note_history:28]
Deconsolidation of Kidde-Fenwal, Inc.

- added (2023-07-27):
[0001783180-23-000056:note_history:29]
On May 14, 2023, Kidde-Fenwal, Inc. ("KFI") filed a petition for voluntary reorganization under Chapter 11 of the United States Bankruptcy Code ("Chapter 11") in the United States Bankruptcy Court for the District of Delaware. KFI, an industrial fire detection and suppression business and an indirect wholly-owned subsidiary of the Company, has indicated that it intends to use the bankruptcy process to explore strategic alternatives, including the sale of KFI as a going concern. KFI has further stated that, during the Chapter 11 process, KFI expects that there will be no significant interruptions to its business operations. As of the petition date, KFI was deconsolidated and its respective assets and liabilities were derecognized from the Company's Unaudited Condensed Consolidated Financial Statements. See Note 19 - Commitments and Contingent Liabilities for additional information.

- changed (2023-07-27):
[0001783180-23-000056:note_history:30]
On February 6, 2022, the Company entered into a binding agreement to acquire a majority ownership interest in Toshiba Carrier Corporation (“TCC”), a variable refrigerant flow ("VRF") and light commercial HVAC joint venture between Carrier and Toshiba Corporation. The acquisition was completed on August 1, 2022. As a result, the assets, liabilities and results of operations of TCC are consolidated in the accompanying Unaudited Condensed Consolidated Financial Statements as of the
  (was, 2023-04-26, similarity 0.8276):
[0001783180-23-000038:note_history:30]
On February 6, 2022, the Company entered into a binding agreement to acquire a majority ownership interest in Toshiba Carrier Corporation (“TCC”), a variable refrigerant flow ("VRF") and light commercial HVAC joint venture between Carrier and Toshiba Corporation. The acquisition was completed on August 1, 2022. As a result, the assets, liabilities and results of operations of TCC are consolidated in the accompanying Unaudited Condensed Consolidated Financial Statements as of the date of acquisition and reported within the Company’s HVAC segment. Upon closing, Toshiba Corporation retained a 5% ownership interest in TCC. See Note 15 – Acquisitions for additional information.

- added (2023-07-27):
[0001783180-23-000056:note_history:31]
date of acquisition and reported within the Company’s HVAC segment. Upon closing, Toshiba Corporation retained a 5% ownership interest in TCC. See Note 15 – Acquisitions for additional information.

- changed (2023-07-27):
[0001783180-23-000056:note_history:32]
On April 3, 2020 (the Distribution Date"), United Technologies Corporation ("UTC"), since renamed RTX Corporation ("Raytheon Technologies Corporation" or "RTX"), completed the spin-off of Carrier into an independent, publicly traded company (the "Separation") through a pro-rata distribution (the "Distribution") on a one-for-one basis of all of the outstanding shares of common stock of Carrier to UTC shareowners who held shares of UTC common stock as of the close of business on March 19, 2020, the record date of the Distribution. In connection with the Separation, the Company issued an aggregate principal balance of $11.0 billion of debt and transferred approximately $10.9 billion of cash to UTC on February 27, 2020 and March 27, 2020. On April 1, 2020 and April 2, 2020, the Company received cash contributions totaling $590 million from UTC related to the Separation.
  (was, 2023-04-26, similarity 0.7644):
[0001783180-23-000038:note_history:32]
On April 3, 2020 (the Distribution Date"), United Technologies Corporation, since renamed Raytheon Technologies Corporation ("UTC"), completed the spin-off of Carrier into an independent, publicly traded company (the "Separation") through a pro-rata distribution (the "Distribution") on a one-for-one basis of all of the outstanding shares of common stock of Carrier to UTC shareowners who held shares of UTC common stock as of the close of business on March 19, 2020, the record date of the Distribution. In connection with the Separation, the Company issued an aggregate principal balance of $11.0 billion of debt and transferred approximately $10.9 billion of cash to UTC on February 27, 2020 and March 27, 2020. On April 1, 2020 and April 2, 2020, the Company received cash contributions totaling $590 million from UTC related to the Separation.

- changed (2023-07-27):
[0001783180-23-000056:note_history:33]
The Financial Accounting Standards Board ("FASB") Accounting Standards Codification ("ASC") is the sole source of authoritative U.S. GAAP other than SEC issued rules and regulations that apply only to SEC registrants. The FASB issues Accounting Standards Updates ("ASU") to communicate changes to the codification. The Company considers the applicability and impact of all ASUs. ASUs pending adoption were assessed and determined to be either not applicable or are not expected to have a material impact on the accompanying Unaudited Condensed Consolidated Financial Statements.
  (was, 2023-04-26, similarity 0.9965):
[0001783180-23-000038:note_history:33]
The Financial Accounting Standards Board ("FASB") Accounting Standards Codification ("ASC") is the sole source of authoritative U.S. GAAP other than SEC issued rules and regulations that apply only to SEC registrants. The FASB issues Accounting Standards Updates ("ASU") to communicate changes to the codification. The Company considers the applicability and impact of all ASUs. ASUs pending adoption were assessed and determined to be either not applicable or not expected to have a material impact on the accompanying Unaudited Condensed Consolidated Financial Statements.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2023-07-27):
[0001783180-23-000056:note_history:34]
DESCRIPTION OF THE BUSINESS 
Carrier Global Corporation (the "Company") is a global leader in intelligent climate and energy solutions with a focus on providing differentiated, digitally-enabled lifecycle solutions to its customers. The Company's portfolio includes industry-leading brands such as Carrier, Toshiba, Automated Logic, Carrier Transicold, Kidde, Edwards and LenelS2 that offer innovative heating, ventilating, air conditioning ("HVAC"), refrigeration, fire, security and building automation technologies to help make the world safer and more comfortable. The Company also provides a broad array of related building services, including audit, design, installation, system integration, repair, maintenance and monitoring. The Company's operations are classified into three segments: HVAC, Refrigeration and Fire & Security.
  (was, 2023-04-26, similarity 0.9149):
[0001783180-23-000038:note_history:34]
DESCRIPTION OF THE BUSINESS 
Carrier Global Corporation (the "Company") is the leading global provider of healthy, safe, sustainable and intelligent building and cold chain solutions with a focus on providing differentiated, digitally-enabled lifecycle solutions to its customers. The Company's portfolio includes industry-leading brands such as Carrier, Toshiba, Automated Logic, Carrier Transicold, Kidde, Edwards and LenelS2 that offer innovative heating, ventilating, air conditioning ("HVAC"), refrigeration, fire, security and building automation technologies to help make the world safer and more comfortable. The Company also provides a broad array of related building services, including audit, design, installation, system integration, repair, maintenance and monitoring. The Company's operations are classified into three segments: HVAC, Refrigeration and Fire & Security.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-07-27):
[0001783180-23-000056:note_history:35]
| (In millions) |  |  |  | June 30,2023 |  | December 31,2022 |
| 2.242% Notes due February 15, 2025 |  |  |  | $ | 1,200 |  |  | $ | 1,200 |  |
| 2.493% Notes due February 15, 2027 |  |  |  | 900 |  |  | 900 |  |
| 2.722% Notes due February 15, 2030 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.700% Notes due February 15, 2031 |  |  |  | 750 |  |  | 750 |  |
| 3.377% Notes due April 5, 2040 |  |  |  | 1,500 |  |  | 1,500 |  |
| 3.577% Notes due April 5, 2050 |  |  |  | 2,000 |  |  | 2,000 |  |
| Total long-term notes |  |  |  | 8,350 |  |  | 8,350 |  |
| Japanese Term Loan Facility |  |  |  | 374 |  |  | 404 |  |
| Other debt (including project financing obligations and finance leases) |  |  |  | 146 |  |  | 149 |  |
| Discounts and debt issuance costs |  |  |  | (81) |  |  | (61) |  |
| Total debt |  |  |  | 8,789 |  |  | 8,842 |  |
| Less: current portion of long-term debt |  |  |  | 134 |  |  | 140 |  |
| Long-term debt, net of current portion |  |  |  | $ | 8,655 |  |  | $ | 8,702 |  |
  (was, 2023-04-26, similarity 0.9942):
[0001783180-23-000038:note_history:35]
| (In millions) |  |  |  | March 31,2023 |  | December 31,2022 |
| 2.242% Notes due February 15, 2025 |  |  |  | $ | 1,200 |  |  | $ | 1,200 |  |
| 2.493% Notes due February 15, 2027 |  |  |  | 900 |  |  | 900 |  |
| 2.722% Notes due February 15, 2030 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.700% Notes due February 15, 2031 |  |  |  | 750 |  |  | 750 |  |
| 3.377% Notes due April 5, 2040 |  |  |  | 1,500 |  |  | 1,500 |  |
| 3.577% Notes due April 5, 2050 |  |  |  | 2,000 |  |  | 2,000 |  |
| Total long-term notes |  |  |  | 8,350 |  |  | 8,350 |  |
| Japanese Term Loan Facility |  |  |  | 408 |  |  | 404 |  |
| Other debt (including project financing obligations and finance leases) |  |  |  | 152 |  |  | 149 |  |
| Discounts and debt issuance costs |  |  |  | (60) |  |  | (61) |  |
| Total debt |  |  |  | 8,850 |  |  | 8,842 |  |
| Less: current portion of long-term debt |  |  |  | 142 |  |  | 140 |  |
| Long-term debt, net of current portion |  |  |  | $ | 8,708 |  |  | $ | 8,702 |  |

- changed (2023-07-27):
[0001783180-23-000056:note_history:36]
On July 15, 2022, the Company entered into a five-year, JPY 54 billion (approximately $400 million) senior unsecured term loan facility with MUFG Bank Ltd., as administrative agent and lender, and certain other lenders (the "Japanese Term Loan Facility"). Borrowings under the Japanese Term Loan Facility bear interest at a rate equal to the Tokyo Term Risk Free Rate plus 0.75%. In addition, the Japanese Term Loan Facility is subject to customary covenants including a covenant to maintain a maximum consolidated leverage ratio. The Company capitalized $2 million of deferred financing costs which are being amortized over its term. On July 25, 2022, the Company borrowed JPY 54 billion under the Japanese Term Loan Facility and used the proceeds to fund a portion of the TCC acquisition and to pay related fees and expenses.
  (was, 2023-04-26, similarity 0.6944):
[0001783180-23-000038:note_history:36]
On July 15, 2022, the Company entered into a five-year, JPY 54 billion (approximately $400 million) senior unsecured term loan facility with MUFG Bank Ltd., as administrative agent and lender, and certain other lenders (the "Japanese Term Loan Facility"). Borrowings under the Japanese Term Loan Facility bear interest at a rate equal to the Tokyo Term Risk Free Rate plus 0.75%. In addition, the Japanese Term Loan Facility is subject to customary covenants including a covenant to maintain a maximum consolidated leverage ratio. On July 25, 2022, the Company borrowed JPY 54 billion under the Japanese Term Loan Facility and used the proceeds to fund a portion of the TCC acquisition and to pay related fees and expenses.

- added (2023-07-27):
[0001783180-23-000056:note_history:37]
On May 19, 2023, the Company entered into a revolving credit agreement with JPMorgan Chase Bank, N.A., as administrative agent, and certain other lenders, permitting aggregate borrowings of up to $2.0 billion pursuant to an unsecured, unsubordinated revolving credit facility that matures in May 2028 (the "Revolving Credit Facility"). The Revolving Credit Facility supports the Company's commercial paper program and can be used for other general corporate purposes. Borrowings are available in U.S. Dollars and Euros. U.S. Dollar borrowings can bear interest at either a Term SOFR Rate plus 0.10% and a rating-based margin or, alternatively, at an alternate base rate plus a ratings-based margin. Euro borrowings bear interest at an adjusted EURIBOR rate plus a ratings-based margin. A ratings-based commitment fee is charged on unused commitments. Upon entering into the agreement, the Company terminated its existing revolving credit facility that was set to mature in April 2025. In addition, the Company capitalized $2 million of deferred financing costs which are being amortized over its term. As of June 30, 2023, there were no borrowings outstanding under the Revolving Credit Facility.

- changed (2023-07-27):
[0001783180-23-000056:note_history:38]
The Company has a $2.0 billion unsecured, unsubordinated commercial paper program, which can be used for general corporate purposes, including the funding of working capital and potential acquisitions. As of June 30, 2023, there were no borrowings outstanding under the commercial paper program.
  (was, 2023-04-26, similarity 0.9843):
[0001783180-23-000038:note_history:38]
The Company has a $2.0 billion unsecured, unsubordinated commercial paper program, which can be used for general corporate purposes, including the funding of working capital and potential acquisitions. As of March 31, 2023, there were no borrowings outstanding under the commercial paper program.

- changed (2023-07-27):
[0001783180-23-000056:note_history:39]
The Company is involved in long-term construction contracts in which it arranges project financing with certain customers. As a result, the Company issued $6 million and $21 million of debt during the six months ended June 30, 2023 and 2022, respectively. Long-term debt repayments associated with these financing arrangements during the six months ended June 30, 2023 and 2022 were $12 million and $12 million, respectively.
  (was, 2023-04-26, similarity 0.8897):
[0001783180-23-000038:note_history:39]
The Company is involved in long-term construction contracts in which it arranges project financing with certain customers. As a result, the Company issued $5 million and $14 million of debt during the three months ended March 31, 2023 and 2022, respectively. Long-term debt repayments associated with these financing arrangements during the three months ended March 31, 2023 and 2022 were $2 million and $8 million, respectively.

- changed (2023-07-27):
[0001783180-23-000056:note_history:40]
The Revolving Credit Facility, the indenture for the long-term notes and the Japanese Term Loan Facility contain affirmative and negative covenants customary for financings of these types, which, among other things, limit the Company's ability to incur additional liens, to make certain fundamental changes and to enter into sale and leaseback transactions. As of June 30, 2023, the Company was in compliance with the covenants under the agreements governing its outstanding indebtedness.
  (was, 2023-04-26, similarity 0.9907):
[0001783180-23-000038:note_history:40]
The Revolving Credit Facility, the indenture for the long-term notes and the Japanese Term Loan Facility contain affirmative and negative covenants customary for financings of these types, which, among other things, limit the Company's ability to incur additional liens, to make certain fundamental changes and to enter into sale and leaseback transactions. As of March 31, 2023, the Company was in compliance with the covenants under the agreements governing its outstanding indebtedness.

- removed (2023-07-27):
[0001783180-23-000038:note_history:41]
On February 10, 2020, the Company entered into a revolving credit agreement with various banks permitting aggregate borrowings of up to $2.0 billion pursuant to an unsecured, unsubordinated revolving credit facility that matures on April 3, 2025 (the "Revolving Credit Facility"). The Revolving Credit Facility supports the Company's commercial paper program and cash requirements. A commitment fee of 0.125% is charged on unused commitments. Borrowings under the Revolving Credit Facility are available in U.S. Dollars, Euros and Pounds Sterling. Pounds Sterling borrowings bear interest at a variable rate based on daily simple SONIA plus 0.0326%, Euro borrowings bear interest at EURIBOR rates and U.S. Dollar borrowings bear interest at LIBOR plus a ratings-based margin, which was 125 basis points as of March 31, 2023. As of March 31, 2023, there were no borrowings outstanding under the Revolving Credit Facility.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-07-27):
[0001783180-23-000056:note_history:42]
| (In millions) |  |  |  | June 30,2023 |  | December 31,2022 |
| 2.242% Notes due February 15, 2025 |  |  |  | $ | 1,200 |  |  | $ | 1,200 |  |
| 2.493% Notes due February 15, 2027 |  |  |  | 900 |  |  | 900 |  |
| 2.722% Notes due February 15, 2030 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.700% Notes due February 15, 2031 |  |  |  | 750 |  |  | 750 |  |
| 3.377% Notes due April 5, 2040 |  |  |  | 1,500 |  |  | 1,500 |  |
| 3.577% Notes due April 5, 2050 |  |  |  | 2,000 |  |  | 2,000 |  |
| Total long-term notes |  |  |  | 8,350 |  |  | 8,350 |  |
| Japanese Term Loan Facility |  |  |  | 374 |  |  | 404 |  |
| Other debt (including project financing obligations and finance leases) |  |  |  | 146 |  |  | 149 |  |
| Discounts and debt issuance costs |  |  |  | (81) |  |  | (61) |  |
| Total debt |  |  |  | 8,789 |  |  | 8,842 |  |
| Less: current portion of long-term debt |  |  |  | 134 |  |  | 140 |  |
| Long-term debt, net of current portion |  |  |  | $ | 8,655 |  |  | $ | 8,702 |  |
  (was, 2023-04-26, similarity 0.9942):
[0001783180-23-000038:note_history:42]
| (In millions) |  |  |  | March 31,2023 |  | December 31,2022 |
| 2.242% Notes due February 15, 2025 |  |  |  | $ | 1,200 |  |  | $ | 1,200 |  |
| 2.493% Notes due February 15, 2027 |  |  |  | 900 |  |  | 900 |  |
| 2.722% Notes due February 15, 2030 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.700% Notes due February 15, 2031 |  |  |  | 750 |  |  | 750 |  |
| 3.377% Notes due April 5, 2040 |  |  |  | 1,500 |  |  | 1,500 |  |
| 3.577% Notes due April 5, 2050 |  |  |  | 2,000 |  |  | 2,000 |  |
| Total long-term notes |  |  |  | 8,350 |  |  | 8,350 |  |
| Japanese Term Loan Facility |  |  |  | 408 |  |  | 404 |  |
| Other debt (including project financing obligations and finance leases) |  |  |  | 152 |  |  | 149 |  |
| Discounts and debt issuance costs |  |  |  | (60) |  |  | (61) |  |
| Total debt |  |  |  | 8,850 |  |  | 8,842 |  |
| Less: current portion of long-term debt |  |  |  | 142 |  |  | 140 |  |
| Long-term debt, net of current portion |  |  |  | $ | 8,708 |  |  | $ | 8,702 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2023-07-27):
[0001783180-23-000056:note_history:43]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
| (In millions) |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Sales to equity method investees included in Product sales |  | $ | 887 |  |  | $ | 787 |  |  | $ | 1,641 |  |  | $ | 1,411 |  |
| Purchases from equity method investees included in Cost of products sold |  | $ | 59 |  |  | $ | 91 |  |  | $ | 102 |  |  | $ | 201 |  |
  (was, 2023-04-26, similarity 0.8401):
[0001783180-23-000038:note_history:43]
|  |  | Three Months Ended March 31, |  |  |
| (In millions) |  | 2023 |  | 2022 |  |  |  |  |
| Sales to equity method investees included in Product sales |  | $ | 754 |  |  | $ | 624 |  |  |  |  |  |
| Purchases from equity method investees included in Cost of products sold |  | $ | 43 |  |  | $ | 110 |  |  |  |  |  |

- changed (2023-07-27):
[0001783180-23-000056:note_history:44]
| (In millions) |  | June 30,2023 |  | December 31,2022 |
| Receivables from equity method investees included in Accounts receivable, net |  | $ | 364 |  |  | $ | 154 |  |
| Payables to equity method investees included in Accounts payable |  | $ | 39 |  |  | $ | 44 |  |
  (was, 2023-04-26, similarity 0.9158):
[0001783180-23-000038:note_history:44]
| (In millions) |  | March 31,2023 |  | December 31, 2022 |
| Receivables from equity method investees included in Accounts receivable, net |  | $ | 260 |  |  | $ | 154 |  |
| Payables to equity method investees included in Accounts payable |  | $ | 24 |  |  | $ | 44 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-07-27):
[0001783180-23-000056:note_history:45]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
| (In millions) |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Sales Type |  |  |  |  |  |  |  |  |
| Product |  | $ | 3,754 |  |  | $ | 3,005 |  |  | $ | 6,955 |  |  | $ | 5,644 |  |
| Service |  | 462 |  |  | 383 |  |  | 883 |  |  | 714 |  |
| HVAC sales |  | 4,216 |  |  | 3,388 |  |  | 7,838 |  |  | 6,358 |  |
| Product |  | 858 |  |  | 925 |  |  | 1,645 |  |  | 1,792 |  |
| Service |  | 114 |  |  | 116 |  |  | 225 |  |  | 225 |  |
| Refrigeration sales |  | 972 |  |  | 1,041 |  |  | 1,870 |  |  | 2,017 |  |
| Product |  | 869 |  |  | 838 |  |  | 1,682 |  |  | 1,609 |  |
| Service |  | 63 |  |  | 49 |  |  | 119 |  |  | 96 |  |
| Fire & Security sales |  | 932 |  |  | 887 |  |  | 1,801 |  |  | 1,705 |  |
| Total segment sales |  | 6,120 |  |  | 5,316 |  |  | 11,509 |  |  | 10,080 |  |
| Eliminations and other |  | (128) |  |  | (105) |  |  | (244) |  |  | (215) |  |
| Net sales |  | $ | 5,992 |  |  | $ | 5,211 |  |  | $ | 11,265 |  |  | $ | 9,865 |  |
  (was, 2023-04-26, similarity 0.8555):
[0001783180-23-000038:note_history:45]
|  |  | Three Months Ended March 31, |  |  |
| (In millions) |  | 2023 |  | 2022 |  |  |  |  |
| Sales Type |  |  |  |  |  |  |  |  |
| Product |  | $ | 3,201 |  |  | $ | 2,639 |  |  |  |  |  |
| Service |  | 421 |  |  | 331 |  |  |  |  |  |
| HVAC sales |  | 3,622 |  |  | 2,970 |  |  |  |  |  |
| Product |  | 787 |  |  | 867 |  |  |  |  |  |
| Service |  | 111 |  |  | 109 |  |  |  |  |  |
| Refrigeration sales |  | 898 |  |  | 976 |  |  |  |  |  |
| Product |  | 813 |  |  | 771 |  |  |  |  |  |
| Service |  | 56 |  |  | 47 |  |  |  |  |  |
| Fire & Security sales |  | 869 |  |  | 818 |  |  |  |  |  |
| Total segment sales |  | 5,389 |  |  | 4,764 |  |  |  |  |  |
| Eliminations and other |  | (116) |  |  | (110) |  |  |  |  |  |
| Net sales |  | $ | 5,273 |  |  | $ | 4,654 |  |  |  |  |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-07-27):
[0001783180-23-000056:note_history:46]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
| (In millions) |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Sales Type |  |  |  |  |  |  |  |  |
| Product |  | $ | 3,754 |  |  | $ | 3,005 |  |  | $ | 6,955 |  |  | $ | 5,644 |  |
| Service |  | 462 |  |  | 383 |  |  | 883 |  |  | 714 |  |
| HVAC sales |  | 4,216 |  |  | 3,388 |  |  | 7,838 |  |  | 6,358 |  |
| Product |  | 858 |  |  | 925 |  |  | 1,645 |  |  | 1,792 |  |
| Service |  | 114 |  |  | 116 |  |  | 225 |  |  | 225 |  |
| Refrigeration sales |  | 972 |  |  | 1,041 |  |  | 1,870 |  |  | 2,017 |  |
| Product |  | 869 |  |  | 838 |  |  | 1,682 |  |  | 1,609 |  |
| Service |  | 63 |  |  | 49 |  |  | 119 |  |  | 96 |  |
| Fire & Security sales |  | 932 |  |  | 887 |  |  | 1,801 |  |  | 1,705 |  |
| Total segment sales |  | 6,120 |  |  | 5,316 |  |  | 11,509 |  |  | 10,080 |  |
| Eliminations and other |  | (128) |  |  | (105) |  |  | (244) |  |  | (215) |  |
| Net sales |  | $ | 5,992 |  |  | $ | 5,211 |  |  | $ | 11,265 |  |  | $ | 9,865 |  |
  (was, 2023-04-26, similarity 0.8555):
[0001783180-23-000038:note_history:46]
|  |  | Three Months Ended March 31, |  |  |
| (In millions) |  | 2023 |  | 2022 |  |  |  |  |
| Sales Type |  |  |  |  |  |  |  |  |
| Product |  | $ | 3,201 |  |  | $ | 2,639 |  |  |  |  |  |
| Service |  | 421 |  |  | 331 |  |  |  |  |  |
| HVAC sales |  | 3,622 |  |  | 2,970 |  |  |  |  |  |
| Product |  | 787 |  |  | 867 |  |  |  |  |  |
| Service |  | 111 |  |  | 109 |  |  |  |  |  |
| Refrigeration sales |  | 898 |  |  | 976 |  |  |  |  |  |
| Product |  | 813 |  |  | 771 |  |  |  |  |  |
| Service |  | 56 |  |  | 47 |  |  |  |  |  |
| Fire & Security sales |  | 869 |  |  | 818 |  |  |  |  |  |
| Total segment sales |  | 5,389 |  |  | 4,764 |  |  |  |  |  |
| Eliminations and other |  | (116) |  |  | (110) |  |  |  |  |  |
| Net sales |  | $ | 5,273 |  |  | $ | 4,654 |  |  |  |  |  |

- changed (2023-07-27):
[0001783180-23-000056:note_history:47]
| (In millions) |  | June 30,2023 |  | December 31,2022 |
| Contract assets, current |  | $ | 578 |  |  | $ | 537 |  |
| Contract assets, non-current (included within Other assets) |  | 8 |  |  | 6 |  |
| Total contract assets |  | 586 |  |  | 543 |  |
| Contract liabilities, current |  | (483) |  |  | (449) |  |
| Contract liabilities, non-current (included within Other long-term liabilities) |  | (170) |  |  | (174) |  |
| Total contract liabilities |  | (653) |  |  | (623) |  |
| Net contract assets (liabilities) |  | $ | (67) |  |  | $ | (80) |  |
  (was, 2023-04-26, similarity 0.9869):
[0001783180-23-000038:note_history:47]
| (In millions) |  | March 31, 2023 |  | December 31, 2022 |
| Contract assets, current |  | $ | 568 |  |  | $ | 537 |  |
| Contract assets, non-current (included within Other assets) |  | 6 |  |  | 6 |  |
| Total contract assets |  | 574 |  |  | 543 |  |
| Contract liabilities, current |  | (516) |  |  | (449) |  |
| Contract liabilities, non-current (included within Other long-term liabilities) |  | (174) |  |  | (174) |  |
| Total contract liabilities |  | (690) |  |  | (623) |  |
| Net contract assets (liabilities) |  | $ | (116) |  |  | $ | (80) |  |

- changed (2023-07-27):
[0001783180-23-000056:note_history:48]
The timing of revenue recognition, billings and cash collections results in contract assets and contract liabilities. Contract assets relate to the conditional right to consideration for any completed performance under a contract when costs are incurred in excess of billings under the percentage-of-completion methodology. Contract liabilities relate to payments received in advance of performance under a contract or when the Company has a right to consideration that is conditioned upon transfer of a good or service to a customer. Contract liabilities are recognized as revenue as (or when) the Company performs under the contract. 
The Company recognized revenue of $264 million during the six months ended June 30, 2023 that related to contract liabilities as of January 1, 2023. The Company expects a majority of its current contract liabilities at the end of the period to be recognized as revenue in the next 12 months.
  (was, 2023-04-26, similarity 0.769):
[0001783180-23-000038:note_history:48]
The timing of revenue recognition, billings and cash collections results in contract assets and contract liabilities. Contract assets relate to the conditional right to consideration for any completed performance under a contract when costs are incurred in excess of billings under the percentage-of-completion methodology. Contract liabilities relate to payments received in advance of performance under a contract or when the Company has a right to consideration that is conditioned upon transfer of a good or service to a customer. Contract liabilities are recognized as revenue as (or when) the Company performs under the contract. 
The Company recognized revenue of $178 million during the three months ended March 31, 2023 that related to contract liabilities as of January 1, 2023. The Company expects a majority of its current contract liabilities at the end of the period to be recognized as revenue in the next 12 months.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2023-07-27):
[0001783180-23-000038:note_history:49]
SUBSEQUENT EVENTS 
On April 25, 2023, the Company announced that it entered into a Share Purchase Agreement (the “Agreement”) to acquire the climate solutions business (the "Business") of Viessmann Group GmbH & Co. KG (“Viessmann”), a privately-held company, for approximately €12 billion. The Business develops intelligent, integrated and sustainable technologies, including heat pumps, boilers, photovoltaic systems, home battery storage and digital solutions, primarily for residential customers in Europe. Under the terms of the Agreement, 20% of the purchase price will be paid in Carrier common stock, issued directly to Viessmann and subject to long-term lock-up provisions, and 80% will be paid in cash, subject to working capital and other adjustments. The Company intends to finance the acquisition with a combination of cash on hand and debt financing and expects the transaction to close around the end of 2023, subject to customary closing conditions and regulatory approvals. On April 26, 2023, the Company entered into a forward contract with a total notional amount of €7 billion to mitigate the foreign currency risk of the Euro cash outflows associated with the acquisition.

- removed (2023-07-27):
[0001783180-23-000038:note_history:50]
On April 25, 2023, the Company announced plans to exit its Fire & Security and Commercial Refrigeration businesses over the course of 2024. Carrier expects to use the proceeds from these transactions to reduce leverage, advance the Company’s capital allocation priorities and for general corporate purposes. The planned exit is not expected to impact UTEC, Fire & Security’s controls business for residential HVAC customers or the Company’s Transicold transport refrigeration, Profroid mechanical systems or the Sensitech monitoring businesses.
