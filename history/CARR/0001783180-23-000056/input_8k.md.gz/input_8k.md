# CARR 8-K — 0001783180-23-000053 filed 2023-07-27

## item codes, every 8-K on or before 2023-07-27

- 2023-07-27 0001783180-23-000053 — 2.02, 9.01
- 2023-06-12 0000950142-23-001664 — 5.02
- 2023-05-25 0000950142-23-001541 — 1.01, 1.02, 2.03, 9.01
- 2023-04-26 0000950142-23-001205 — 1.01, 9.01
- 2023-04-25 0001783180-23-000036 — 2.02, 7.01, 9.01
- 2023-04-25 0000950142-23-001199 — 7.01, 8.01, 9.01
- 2023-04-21 0001783180-23-000032 — 5.07, 9.01
- 2023-02-07 0001783180-23-000010 — 2.02, 9.01
- 2022-10-27 0001783180-22-000054 — 2.02, 7.01, 9.01
- 2022-09-29 0000950142-22-002805 — 5.02, 9.01
- 2022-07-28 0001783180-22-000045 — 2.02, 9.01
- 2022-04-28 0001783180-22-000032 — 2.02, 9.01
- 2022-04-15 0001783180-22-000024 — 5.07, 9.01
- 2022-02-08 0001783180-22-000008 — 2.02, 9.01
- 2022-02-07 0000950142-22-000510 — 8.01, 9.01
- 2022-01-03 0000950142-22-000023 — 8.01, 9.01
- 2021-12-17 0001783180-21-000071 — 5.02, 7.01, 9.01
- 2021-11-23 0001783180-21-000068 — 5.03, 9.01
- 2021-10-28 0001783180-21-000062 — 2.02, 9.01
- 2021-08-27 0001783180-21-000056 — 8.01
- 2021-07-30 0001783180-21-000053 — 1.01
- 2021-07-29 0001783180-21-000049 — 2.02, 8.01, 9.01
- 2021-07-27 0000950142-21-002448 — 8.01, 9.01
- 2021-07-15 0000950142-21-002362 — 5.02, 9.01
- 2021-06-09 0000950142-21-001885 — 5.02, 9.01
- 2021-04-29 0001783180-21-000029 — 2.02, 9.01
- 2021-04-22 0001140361-21-013889 — 5.02, 9.01
- 2021-04-20 0001783180-21-000021 — 5.07, 9.01
- 2021-04-19 0000950142-21-001308 — 8.01, 9.01
- 2021-02-09 0001783180-21-000009 — 2.02, 9.01
- 2021-02-05 0001140361-21-003513 — 8.01, 9.01
- 2020-12-23 0001140361-20-029419 — 7.01, 9.01
- 2020-12-22 0001140361-20-029097 — 8.01
- 2020-12-14 0001140361-20-028246 — 5.03, 9.01
- 2020-12-07 0001140361-20-027515 — 1.01, 7.01, 9.01
- 2020-10-29 0001783180-20-000063 — 2.02, 9.01
- 2020-10-19 0001140361-20-023241 — 5.02, 7.01, 9.01
- 2020-09-23 0001140361-20-021220 — 8.01, 9.01
- 2020-09-22 0001140361-20-021124 — 8.01, 9.01
- 2020-07-30 0001783180-20-000045 — 2.02, 9.01
- 2020-06-19 0001140361-20-014325 — 1.01, 2.03, 9.01
- 2020-06-16 0001140361-20-013880 — 8.01, 9.01
- 2020-06-03 0001140361-20-012939 — 1.01, 9.01
- 2020-05-08 0001783180-20-000013 — 2.02, 9.01
- 2020-04-03 0001140361-20-007888 — 1.01, 5.02, 5.03, 5.05, 7.01, 9.01
- 2020-03-16 0001140361-20-005868 — 8.01, 9.01

## late-filing notifications on or before 2023-07-27

- none on or before 2023-07-27

## item 2.02 — earnings release, exhibit 99.1

[0001783180-23-000053:8k_2_02:1]
EX-99
2
a99-q22023earningsexhibit.htm
EX-99

[0001783180-23-000053:8k_2_02:2]
Document

[0001783180-23-000053:8k_2_02:3]
Exhibit 99

[0001783180-23-000053:8k_2_02:4]
Carrier Reports Second Quarter 2023 Results

[0001783180-23-000053:8k_2_02:5]
•Net sales up 15% versus second quarter 2022; organic sales up 6%

[0001783180-23-000053:8k_2_02:6]
•GAAP EPS of $0.23 and adjusted EPS of $0.79

[0001783180-23-000053:8k_2_02:7]
•Net cash inflows from operating activities were $384 million and free cash flow generation was $310 million

[0001783180-23-000053:8k_2_02:8]
•Increasing adjusted EPS guidance from $2.50 - $2.60 to $2.55 - $2.65 based on strong first half performance and despite the deconsolidation of Kidde-Fenwal, Inc. (KFI).

[0001783180-23-000053:8k_2_02:9]
PALM BEACH GARDENS, Fla., July 27, 2023 – Carrier Global Corporation (NYSE:CARR), global leader in intelligent climate and energy solutions, today reported strong financial results for the second quarter of 2023 and raised its full year revenue, adjusted operating margin and adjusted EPS guidance.

[0001783180-23-000053:8k_2_02:10]
“We delivered another quarter of strong financial performance led by double-digit growth in commercial and light commercial HVAC, global truck and trailer, aftermarket and controls which shows the strength of our execution, end-markets and backlog. Given our strong performance in the first half of 2023, we are now raising full year guidance for organic revenue growth, adjusted operating margin, and adjusted EPS,” said Carrier Chairman & CEO David Gitlin. “The more we learn about Viessmann Climate Solutions, the more excited we are for the impact of this game-changing combination. We continue to anticipate a close around year-end and expect the majority of the businesses we plan to exit to be in the market over the course of the next few months. After the completion of these portfolio actions, Carrier will become a pure play, high-growth global climate champion.”

[0001783180-23-000053:8k_2_02:11]
1

[0001783180-23-000053:8k_2_02:12]
Second Quarter 2023 Results

[0001783180-23-000053:8k_2_02:13]
Carrier’s second quarter sales of $6.0 billion were up 15% compared to the prior year and organic sales grew 6% over the same period. Organic sales strength continued in the HVAC segment with commercial HVAC up high-teens and North America residential and light commercial HVAC up 5% organically. Fire and Security sales were up 9% organically while Refrigeration sales were down 6% organically driven by lower volumes in container and commercial refrigeration only partially offset by strength in global truck and trailer demand.

[0001783180-23-000053:8k_2_02:14]
GAAP operating profit in the quarter of $489 million was down 40% from last year largely due to the one-time loss of $293 million associated with the deconsolidation of KFI following its Chapter 11 filing and the $111 million unrealized loss on the mark-to-market valuation of forward contracts associated with the Viessmann Climate Solutions acquisition. Adjusted operating profit of $964 million was up 12% compared to last year.

[0001783180-23-000053:8k_2_02:15]
Net income was $199 million and adjusted net income was $670 million. GAAP EPS was $0.23 and adjusted EPS was $0.79. Net cash flows generated in operating activities were $384 million and capital expenditures were $74 million, resulting in free cash flow of $310 million.

[0001783180-23-000053:8k_2_02:16]
Full-Year 2023 Guidance

[0001783180-23-000053:8k_2_02:17]
Carrier updated the following guidance for 2023, which now reflects the deconsolidation of KFI as of its Chapter 11 filing date of May 14, 2023:

[0001783180-23-000053:8k_2_02:18]
|  |  | Current Guidance | Prior Guidance |  |  |
|  |  | Over $22B | ~$22B |  |  |
| Sales |  | Organic* up MSD | Organic* up LSD-MSD |  |  |
|  |  | FX ~0% | FX ~0% |  |  |
|  |  | Acquisitions / Divestitures, net +~5% | Acquisitions +~6% |  |  |
| Adjusted Operating Margin * |  | 14.0% - 14.5% | ~14% |  |  |
|  | Includes ~50bps negative impact from TCC | Includes ~50bps negative impact from TCC |  |  |
| Adjusted EPS * |  | $2.55 - $2.65 | $2.50 - $2.60 |  |  |
| Free Cash Flow * |  | ~$1.9B | ~$1.9B |  |  |

[0001783180-23-000053:8k_2_02:19]
2

[0001783180-23-000053:8k_2_02:20]
*Note: When the company provides expectations for organic sales, adjusted operating profit, adjusted operating margin, adjusted EPS and free cash flow on a forward-looking basis, a reconciliation of the differences between the non-GAAP expectations and the corresponding GAAP measures generally is not available without unreasonable effort. See “Use and Definitions of Non-GAAP Financial Measures” below for additional information.

[0001783180-23-000053:8k_2_02:21]
Conference Call

[0001783180-23-000053:8k_2_02:22]
Carrier will host a webcast of its earnings conference call today, Thursday, July 27, 2023, at 7:30 a.m. ET. To access the webcast, visit the Events & Presentations section of the Carrier Investor Relations site at ir.carrier.com/news-and-events/events-and-presentations or to listen to the earnings call by phone, participants must pre-register at Carrier Earnings Call Registration. All registrants will receive dial-in information and a PIN allowing access to the live call.

[0001783180-23-000053:8k_2_02:23]
About Carrier

[0001783180-23-000053:8k_2_02:24]
Carrier Global Corporation, global leader in intelligent climate and energy solutions, is committed to creating solutions that matter for people and our planet for generations to come. From the beginning, we've led in inventing new technologies and entirely new industries. Today, we continue to lead because we have a world-class, diverse workforce that puts the customer at the center of everything we do. For more information, visit www.corporate.carrier.com or follow Carrier on social media at @Carrier.

[0001783180-23-000053:8k_2_02:25]
Cautionary Statement

[0001783180-23-000053:8k_2_02:26]
This communication contains statements which, to the extent they are not statements of historical or present fact, constitute "forward-looking statements" under the securities laws. These forward-looking statements are intended to provide management's current expectations or plans for Carrier's future operating and financial performance, based on assumptions currently believed to be valid. Forward-looking statements can be identified by the use of words such as "believe," "expect," "expectations," "plans," "strategy," "prospects," "estimate," "project," "target," "anticipate," "will," "should," "see," "guidance," "outlook," "confident," "scenario" and other words of similar meaning in connection with a discussion of future operating or financial performance. Forward-looking statements may include, among other things, statements relating to revised outlook and guidance, future sales, earnings, cash flow, results of operations, uses of cash, share repurchases, tax rates and other measures of financial performance or potential future plans, strategies or transactions of Carrier, Carrier's plans with respect to its indebtedness and other statements that are not historical facts. All forward-looking statements involve risks, uncertainties and other factors that may cause actual results to differ materially from those expressed or implied in the forward-looking statements. For additional information on identifying factors that may cause actual results to vary materially from those stated in forward-looking statements, see Carrier's reports on Forms 10-K, 10-Q and 8-K filed with or furnished to the U.S. Securities and Exchange Commission from time to time. Any forward-looking statement speaks only as of the date on which it is made, and Carrier assumes no obligation to update or revise such statement, whether as a result of new information, future events or otherwise, except as required by applicable law.

[0001783180-23-000053:8k_2_02:27]
CARR-IR

[0001783180-23-000053:8k_2_02:28]
3

[0001783180-23-000053:8k_2_02:29]
Contact:                        Investor Relations

[0001783180-23-000053:8k_2_02:30]
Sam Pearlstein

[0001783180-23-000053:8k_2_02:31]
561-365-2251

[0001783180-23-000053:8k_2_02:32]
Sam.Pearlstein@Carrier.com

[0001783180-23-000053:8k_2_02:33]
Media Inquiries

[0001783180-23-000053:8k_2_02:34]
Ashley Barrie

[0001783180-23-000053:8k_2_02:35]
561-365-1260

[0001783180-23-000053:8k_2_02:36]
Ashley.Barrie@Carrier.com

[0001783180-23-000053:8k_2_02:37]
4

[0001783180-23-000053:8k_2_02:38]
SELECTED FINANCIAL DATA, NON-GAAP MEASURES AND DEFINITIONS

[0001783180-23-000053:8k_2_02:39]
Following are tables that present selected financial data of Carrier Global Corporation (“Carrier”). Also included are reconciliations of non-GAAP measures to their most comparable GAAP measures.

[0001783180-23-000053:8k_2_02:40]
Use and Definitions of Non-GAAP Financial Measures

[0001783180-23-000053:8k_2_02:41]
Carrier Global Corporation (“Carrier”) reports its financial results in accordance with accounting principles generally accepted in the United States ("GAAP"). We supplement the reporting of our financial information determined under GAAP with certain non-GAAP financial information. The non-GAAP information presented provides investors with additional useful information, but should not be considered in isolation or as substitutes for the related GAAP measures. Moreover, other companies may define non-GAAP measures differently, which limits the usefulness of these measures for comparisons with such other companies. We encourage investors to review our financial statements and publicly filed reports in their entirety and not to rely on any single financial measure. A reconciliation of the non-GAAP measures to the corresponding amounts prepared in accordance with GAAP appears in the tables in this Appendix. The tables provide additional information as to the items and amounts that have been excluded from the adjusted measures.

[0001783180-23-000053:8k_2_02:42]
Organic sales, adjusted operating profit, adjusted operating margin, incremental margins / earnings conversion, earnings before interest, taxes and depreciation and amortization (“EBITDA”), adjusted EBITDA, adjusted net income, adjusted earnings per share (“EPS”), adjusted interest expense, net, adjusted effective tax rate and net debt are non-GAAP financial measures.

[0001783180-23-000053:8k_2_02:43]
Organic sales represents consolidated net sales (a GAAP measure), excluding the impact of foreign currency translation, acquisitions and divestitures completed in the preceding twelve months and other significant items of a nonoperational nature (hereinafter referred to as “other significant items”). Adjusted operating profit represents operating profit (a GAAP measure), excluding restructuring costs, amortization of acquired intangibles and other significant items. Adjusted operating margin represents adjusted operating profit as a percentage of net sales (a GAAP measure). Incremental margins / earnings conversion represents the year-over-year change in adjusted operating profit divided by the year-over-year change in net sales. EBITDA represents net income attributable to common shareholders (a GAAP measure), adjusted for interest income and expense, income tax expense, and depreciation and amortization. Adjusted EBITDA represents EBITDA, as calculated above, excluding non-service pension benefit, non-controlling interest in subsidiaries’ earnings from operations, restructuring costs and other significant items. Adjusted net income represents net income attributable to common shareowners (a GAAP measure), excluding restructuring costs, amortization of acquired intangibles and other significant items. Adjusted EPS represents diluted earnings per share (a GAAP measure), excluding restructuring costs, amortization of acquired intangibles and other significant items. Adjusted interest expense, net represents interest expense (a GAAP measure) and interest income (a GAAP measure), net excluding other significant items. The adjusted effective tax rate represents the effective tax rate (a GAAP measure), excluding restructuring costs, amortization of acquired intangibles and other significant items. Net debt represents long-term debt (a GAAP measure) less cash and cash equivalents (a GAAP measure). For the business segments, when applicable, adjustments of operating profit and operating margins represent operating profit, excluding restructuring, amortization of acquired intangibles and other significant items.

[0001783180-23-000053:8k_2_02:44]
Free cash flow is a non-GAAP financial measure that represents net cash flows provided by operating activities (a GAAP measure) less capital expenditures. Management believes free cash flow is a useful measure of liquidity and an additional basis for assessing Carrier’s ability to fund its activities, including the financing of acquisitions, debt service, repurchases of Carrier's common stock and distribution of earnings to shareowners.

[0001783180-23-000053:8k_2_02:45]
Orders are contractual commitments with customers to provide specified goods or services for an agreed upon price and may not be subject to penalty if cancelled.

[0001783180-23-000053:8k_2_02:46]
When we provide our expectations for organic sales, adjusted operating profit, adjusted operating margin, adjusted interest expense, net, adjusted effective tax rate, incremental margins/earnings conversion, EBITDA, adjusted EBITDA, adjusted EPS and free cash flow on a forward-looking basis, a reconciliation of the differences between the non-GAAP expectations and the corresponding GAAP measures (expected net sales, operating profit, operating margin, interest expense, effective tax rate, incremental operating margin, net income attributable to common shareowners, diluted EPS and net cash flows provided by operating activities) generally is not available without unreasonable effort due to potentially high variability, complexity and low visibility as to the items that would be excluded from the GAAP measure in the relevant future period, such as unusual gains and losses, the ultimate outcome of pending litigation, fluctuations in foreign currency exchange rates, the impact and timing of potential acquisitions and divestitures, future restructuring costs, and other structural changes or their probable significance. The variability of the excluded items may have a significant, and potentially unpredictable, impact on our future GAAP results.

[0001783180-23-000053:8k_2_02:47]
5

[0001783180-23-000053:8k_2_02:48]
Carrier Global Corporation

[0001783180-23-000053:8k_2_02:49]
Condensed Consolidated Statement of Operations

[0001783180-23-000053:8k_2_02:50]
|  | (Unaudited) |
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
| (In millions, except per share amounts) | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Net sales |  |  |  |  |  |  |  |
| Product sales | $ | 5,355 |  |  | $ | 4,662 |  |  | $ | 10,041 |  |  | $ | 8,832 |  |
| Service sales | 637 |  |  | 549 |  |  | 1,224 |  |  | 1,033 |  |
| Total Net sales | 5,992 |  |  | 5,211 |  |  | 11,265 |  |  | 9,865 |  |
| Costs and expenses |  |  |  |  |  |  |  |
| Cost of products sold | (3,769) |  |  | (3,363) |  |  | (7,227) |  |  | (6,361) |  |
| Cost of services sold | (468) |  |  | (401) |  |  | (905) |  |  | (764) |  |
| Research and development | (151) |  |  | (122) |  |  | (290) |  |  | (247) |  |
| Selling, general and administrative | (784) |  |  | (614) |  |  | (1,505) |  |  | (1,215) |  |
| Total Costs and expenses | (5,172) |  |  | (4,500) |  |  | (9,927) |  |  | (8,587) |  |
| Equity method investment net earnings | 52 |  |  | 101 |  |  | 96 |  |  | 159 |  |
| Other income (expense), net | (383) |  |  | 7 |  |  | (390) |  |  | 1,119 |  |
| Operating profit | 489 |  |  | 819 |  |  | 1,044 |  |  | 2,556 |  |
| Non-service pension (expense) benefit | — |  |  | (1) |  |  | — |  |  | (2) |  |
| Interest (expense) income, net | (67) |  |  | (61) |  |  | (113) |  |  | (109) |  |
| Income from operations before income taxes | 422 |  |  | 757 |  |  | 931 |  |  | 2,445 |  |
| Income tax (expense) benefit | (189) |  |  | (170) |  |  | (311) |  |  | (471) |  |
| Net income from operations | 233 |  |  | 587 |  |  | 620 |  |  | 1,974 |  |
| Less: Non-controlling interest in subsidiaries' earnings from operations | 34 |  |  | 14 |  |  | 48 |  |  | 22 |  |
| Net income attributable to common shareowners | $ | 199 |  |  | $ | 573 |  |  | $ | 572 |  |  | $ | 1,952 |  |
| Earnings per share |  |  |  |  |  |  |  |
| Basic | $ | 0.24 |  |  | $ | 0.68 |  |  | $ | 0.68 |  |  | $ | 2.30 |  |
| Diluted | $ | 0.23 |  |  | $ | 0.67 |  |  | $ | 0.67 |  |  | $ | 2.25 |  |
| Weighted-average number of shares outstanding |  |  |  |  |  |  |  |
| Basic | 836.0 |  |  | 845.7 |  |  | 835.5 |  |  | 849.5 |  |
| Diluted | 850.9 |  |  | 862.7 |  |  | 851.5 |  |  | 868.4 |  |

[0001783180-23-000053:8k_2_02:51]
6

[0001783180-23-000053:8k_2_02:52]
Carrier Global Corporation

[0001783180-23-000053:8k_2_02:53]
Condensed Consolidated Balance Sheet

[0001783180-23-000053:8k_2_02:54]
|  |  | (Unaudited) |
| (In millions) |  | June 30, 2023 |  | December 31, 2022 |
| Assets |  |  |  |  |
| Cash and cash equivalents |  | $ | 3,209 |  |  | $ | 3,520 |  |
| Accounts receivable, net |  | 3,212 |  |  | 2,833 |  |
| Contract assets, current |  | 578 |  |  | 537 |  |
| Inventories, net |  | 2,699 |  |  | 2,640 |  |
| Other assets, current |  | 443 |  |  | 349 |  |
| Total current assets |  | 10,141 |  |  | 9,879 |  |
| Future income tax benefits |  | 690 |  |  | 612 |  |
| Fixed assets, net |  | 2,262 |  |  | 2,241 |  |
| Operating lease right-of-use assets |  | 600 |  |  | 642 |  |
| Intangible assets, net |  | 1,181 |  |  | 1,342 |  |
| Goodwill |  | 9,927 |  |  | 9,977 |  |
| Pension and post-retirement assets |  | 32 |  |  | 26 |  |
| Equity method investments |  | 1,139 |  |  | 1,148 |  |
| Other assets |  | 312 |  |  | 219 |  |
| Total Assets |  | $ | 26,284 |  |  | $ | 26,086 |  |
| Liabilities and Equity |  |  |  |  |
| Accounts payable |  | $ | 2,956 |  |  | $ | 2,833 |  |
| Accrued liabilities |  | 2,661 |  |  | 2,610 |  |
| Contract liabilities, current |  | 483 |  |  | 449 |  |
| Current portion of long-term debt |  | 134 |  |  | 140 |  |
| Total current liabilities |  | 6,234 |  |  | 6,032 |  |
| Long-term debt |  | 8,655 |  |  | 8,702 |  |
| Future pension and post-retirement obligations |  | 350 |  |  | 349 |  |
| Future income tax obligations |  | 560 |  |  | 568 |  |
| Operating lease liabilities |  | 485 |  |  | 529 |  |
| Other long-term liabilities |  | 1,712 |  |  | 1,830 |  |
| Total Liabilities |  | 17,996 |  |  | 18,010 |  |
| Equity |  |  |  |  |
| Common stock |  | 9 |  |  | 9 |  |
| Treasury stock |  | (1,972) |  |  | (1,910) |  |
| Additional paid-in capital |  | 5,494 |  |  | 5,481 |  |
| Retained earnings |  | 6,129 |  |  | 5,866 |  |
| Accumulated other comprehensive loss |  | (1,691) |  |  | (1,688) |  |
| Non-controlling interest |  | 319 |  |  | 318 |  |
| Total Equity |  | 8,288 |  |  | 8,076 |  |
| Total Liabilities and Equity |  | $ | 26,284 |  |  | $ | 26,086 |  |

[0001783180-23-000053:8k_2_02:55]
7

[0001783180-23-000053:8k_2_02:56]
Carrier Global Corporation

[0001783180-23-000053:8k_2_02:57]
Condensed Consolidated Statement of Cash Flows

[0001783180-23-000053:8k_2_02:58]
|  |  |  |  | (Unaudited) |
|  |  |  | Six Months Ended June 30, |
| (In millions) |  |  |  |  | 2023 |  | 2022 |
| Operating Activities |  |  |  |  |  |  |  |
| Net income from operations |  |  |  |  | $ | 620 |  |  | $ | 1,974 |  |
| Adjustments to reconcile net income to net cash flows from operating activities: |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  |  |  | 273 |  |  | 155 |  |
| Deferred income tax provision |  |  |  |  | (110) |  |  | (17) |  |
| Stock-based compensation costs |  |  |  |  | 40 |  |  | 41 |  |
| Equity method investment net earnings |  |  |  |  | (96) |  |  | (159) |  |
| (Gain) loss on extinguishment of debt |  |  |  |  | — |  |  | (36) |  |
| (Gain) loss on sale of investments / deconsolidation |  |  |  |  | 276 |  |  | (1,119) |  |
| Changes in operating assets and liabilities |  |  |  |  |  |  |  |
| Accounts receivable, net |  |  |  |  | (406) |  |  | (483) |  |
| Contract assets, current |  |  |  |  | (40) |  |  | (224) |  |
| Inventories, net |  |  |  |  | (59) |  |  | (435) |  |
| Other assets, current |  |  |  |  | (105) |  |  | (37) |  |
| Accounts payable and accrued liabilities |  |  |  |  | 120 |  |  | 79 |  |
| Contract liabilities, current |  |  |  |  | 37 |  |  | 42 |  |
| Defined benefit plan contributions |  |  |  |  | (11) |  |  | (6) |  |
| Distributions from equity method investments |  |  |  |  | 10 |  |  | 15 |  |
| Other operating activities, net |  |  |  |  | (45) |  |  | 40 |  |
| Net cash flows provided by (used in) operating activities |  |  |  |  | 504 |  |  | (170) |  |
| Investing Activities |  |  |  |  |  |  |  |
| Capital expenditures |  |  |  |  | (144) |  |  | (122) |  |
| Investments in businesses, net of cash acquired |  |  |  |  | (56) |  |  | (38) |  |
| Disposition of businesses |  |  |  |  | 36 |  |  | 2,944 |  |
| Settlement of derivative contracts, net |  |  |  |  | (14) |  |  | (123) |  |
| Kidde-Fenwal, Inc. deconsolidation |  |  |  |  | (134) |  |  | — |  |
| Other investing activities, net |  |  |  |  | 16 |  |  | (16) |  |
| Net cash flows provided by (used in) investing activities |  |  |  |  | (296) |  |  | 2,645 |  |
| Financing Activities |  |  |  |  |  |  |  |
| Increase (decrease) in short-term borrowings, net |  |  |  |  | (19) |  |  | (22) |  |
| Issuance of long-term debt |  |  |  |  | 6 |  |  | 21 |  |
| Repayment of long-term debt |  |  |  |  | (12) |  |  | (1,127) |  |
| Repurchases of common stock |  |  |  |  | (62) |  |  | (1,014) |  |
| Dividends paid on common stock |  |  |  |  | (309) |  |  | (257) |  |
| Dividends paid to non-controlling interest |  |  |  |  | (41) |  |  | (22) |  |
| Other financing activities, net |  |  |  |  | (69) |  |  | (13) |  |
| Net cash flows provided by (used in) financing activities |  |  |  |  | (506) |  |  | (2,434) |  |
| Effect of foreign exchange rate changes on cash and cash equivalents |  |  |  |  | (13) |  |  | (41) |  |
| Net increase (decrease) in cash and cash equivalents and restricted cash |  |  |  |  | (311) |  |  | — |  |
| Cash, cash equivalents and restricted cash, beginning of period |  |  |  |  | 3,527 |  |  | 3,025 |  |
| Cash, cash equivalents and restricted cash, end of period |  |  |  |  | 3,216 |  |  | 3,025 |  |
| Less: restricted cash |  |  |  |  | 7 |  |  | 8 |  |
| Cash and cash equivalents, end of period |  |  |  |  | $ | 3,209 |  |  | $ | 3,017 |  |

[0001783180-23-000053:8k_2_02:59]
8

[0001783180-23-000053:8k_2_02:60]
Carrier Global Corporation

[0001783180-23-000053:8k_2_02:61]
Segment Net Sales and Operating Profit

[0001783180-23-000053:8k_2_02:62]
|  | (Unaudited) |
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| (In millions) | Reported |  | Adjusted |  | Reported |  | Adjusted |  | Reported |  | Adjusted |  | Reported |  | Adjusted |
| Net sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| HVAC | $ | 4,216 |  | $ | 4,216 |  | $ | 3,388 |  | $ | 3,388 |  | $ | 7,838 |  | $ | 7,838 |  | $ | 6,358 |  | $ | 6,358 |
| Refrigeration | 972 |  | 972 |  | 1,041 |  | 1,041 |  | 1,870 |  | 1,870 |  | 2,017 |  | 2,017 |
| Fire & Security | 932 |  | 932 |  | 887 |  | 887 |  | 1,801 |  | 1,801 |  | 1,705 |  | 1,705 |
| Segment sales | 6,120 |  | 6,120 |  | 5,316 |  | 5,316 |  | 11,509 |  | 11,509 |  | 10,080 |  | 10,080 |
| Eliminations and other | (128) |  | (128) |  | (105) |  | (105) |  | (244) |  | (244) |  | (215) |  | (215) |
| Net sales | $ | 5,992 |  | $ | 5,992 |  | $ | 5,211 |  | $ | 5,211 |  | $ | 11,265 |  | $ | 11,265 |  | $ | 9,865 |  | $ | 9,865 |
| Operating profit |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| HVAC | $ | 742 |  | $ | 791 |  | $ | 585 |  | $ | 613 |  | $ | 1,177 |  | $ | 1,281 |  | $ | 1,055 |  | $ | 1,091 |
| Refrigeration | 112 |  | 119 |  | 147 |  | 152 |  | 220 |  | 230 |  | 254 |  | 264 |
| Fire & Security | (157) |  | 137 |  | 134 |  | 135 |  | (64) |  | 245 |  | 1,352 |  | 252 |
| Segment operating profit | 697 |  | 1,047 |  | 866 |  | 900 |  | 1,333 |  | 1,756 |  | 2,661 |  | 1,607 |
| Eliminations and other | (146) |  | (35) |  | (16) |  | (16) |  | (184) |  | (71) |  | (40) |  | (40) |
| General corporate expenses | (62) |  | (48) |  | (31) |  | (22) |  | (105) |  | (79) |  | (65) |  | (50) |
| Operating profit | $ | 489 |  | $ | 964 |  | $ | 819 |  | $ | 862 |  | $ | 1,044 |  | $ | 1,606 |  | $ | 2,556 |  | $ | 1,517 |
| Operating margin |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| HVAC | 17.6 | % |  | 18.8 | % |  | 17.3 | % |  | 18.1 | % |  | 15.0 | % |  | 16.3 | % |  | 16.6 | % |  | 17.2 | % |
| Refrigeration | 11.5 | % |  | 12.2 | % |  | 14.1 | % |  | 14.6 | % |  | 11.8 | % |  | 12.3 | % |  | 12.6 | % |  | 13.1 | % |
| Fire & Security | (16.8) | % |  | 14.7 | % |  | 15.1 | % |  | 15.2 | % |  | (3.6) | % |  | 13.6 | % |  | 79.3 | % |  | 14.8 | % |
| Total Carrier | 8.2 | % |  | 16.1 | % |  | 15.7 | % |  | 16.5 | % |  | 9.3 | % |  | 14.3 | % |  | 25.9 | % |  | 15.4 | % |

[0001783180-23-000053:8k_2_02:63]
9

[0001783180-23-000053:8k_2_02:64]
Carrier Global Corporation

[0001783180-23-000053:8k_2_02:65]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP)

[0001783180-23-000053:8k_2_02:66]
Operating Profit

[0001783180-23-000053:8k_2_02:67]
|  | (Unaudited) |
|  | Three Months Ended June 30, 2023 |
| (In millions) | HVAC |  | Refrigeration |  | Fire & Security |  | Eliminations and Other |  | General Corporate Expenses |  | Carrier |
| Net sales | $ | 4,216 |  |  | $ | 972 |  |  | $ | 932 |  |  | $ | (128) |  |  | $ | — |  |  | $ | 5,992 |  |
| Segment operating profit | $ | 742 |  |  | $ | 112 |  |  | $ | (157) |  |  | $ | (146) |  |  | $ | (62) |  |  | $ | 489 |  |
| Reported operating margin | 17.6 | % |  | 11.5 | % |  | (16.8) | % |  |  |  |  |  | 8.2 | % |
| Adjustments to segment operating profit: |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring costs | $ | 3 |  |  | $ | 7 |  |  | $ | (1) |  |  | $ | — |  |  | $ | — |  |  | $ | 9 |  |
| Amortization of acquired intangibles | 36 |  |  | — |  |  | 2 |  |  | — |  |  | — |  |  | 38 |  |
| Acquisition step-up amortization (1) | 10 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 10 |  |
| Acquisition-related costs | — |  |  | — |  |  | — |  |  | — |  |  | 14 |  |  | 14 |  |
| Viessmann-related hedges | — |  |  | — |  |  | — |  |  | 111 |  |  | — |  |  | 111 |  |
| KFI deconsolidation | — |  |  | — |  |  | 293 |  |  | — |  |  | — |  |  | 293 |  |
| Total adjustments to operating profit | $ | 49 |  |  | $ | 7 |  |  | $ | 294 |  |  | $ | 111 |  |  | $ | 14 |  |  | $ | 475 |  |
| Adjusted operating profit | $ | 791 |  |  | $ | 119 |  |  | $ | 137 |  |  | $ | (35) |  |  | $ | (48) |  |  | $ | 964 |  |
| Adjusted operating margin | 18.8 | % |  | 12.2 | % |  | 14.7 | % |  |  |  |  |  | 16.1 | % |

[0001783180-23-000053:8k_2_02:68]
|  | (Unaudited) |
|  | Three Months Ended June 30, 2022 |
| (In millions) | HVAC |  | Refrigeration |  | Fire & Security |  | Eliminations and Other |  | General Corporate Expenses |  | Carrier |
| Net sales | $ | 3,388 |  |  | $ | 1,041 |  |  | $ | 887 |  |  | $ | (105) |  |  | $ | — |  |  | $ | 5,211 |  |
| Segment operating profit | $ | 585 |  |  | $ | 147 |  |  | $ | 134 |  |  | $ | (16) |  |  | $ | (31) |  |  | $ | 819 |  |
| Reported operating margin | 17.3 | % |  | 14.1 | % |  | 15.1 | % |  |  |  |  |  | 15.7 | % |
| Adjustments to segment operating profit: |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring costs | $ | 2 |  |  | $ | 6 |  |  | $ | 3 |  |  | $ | — |  |  | $ | 2 |  |  | $ | 13 |  |
| Amortization of acquired intangibles | 4 |  |  | — |  |  | 1 |  |  | — |  |  | — |  |  | 5 |  |
| Acquisition-related costs | — |  |  | — |  |  | — |  |  | — |  |  | 7 |  |  | 7 |  |
| Russia/Ukraine asset impairment | — |  |  | (1) |  |  | (3) |  |  | — |  |  | — |  |  | (4) |  |
| Charge resulting from legal matter | 22 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 22 |  |
| Total adjustments to operating profit | $ | 28 |  |  | $ | 5 |  |  | $ | 1 |  |  | $ | — |  |  | $ | 9 |  |  | $ | 43 |  |
| Adjusted operating profit | $ | 613 |  |  | $ | 152 |  |  | $ | 135 |  |  | $ | (16) |  |  | $ | (22) |  |  | $ | 862 |  |
| Adjusted operating margin | 18.1 | % |  | 14.6 | % |  | 15.2 | % |  |  |  |  |  | 16.5 | % |

[0001783180-23-000053:8k_2_02:69]
(1)  Amortization of the step-up to fair value of acquired inventory and backlog.

[0001783180-23-000053:8k_2_02:70]
10

[0001783180-23-000053:8k_2_02:71]
Carrier Global Corporation

[0001783180-23-000053:8k_2_02:72]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP)

[0001783180-23-000053:8k_2_02:73]
Operating Profit

[0001783180-23-000053:8k_2_02:74]
|  | (Unaudited) |
|  | Six Months Ended June 30, 2023 |
| (In millions) | HVAC |  | Refrigeration |  | Fire & Security |  | Eliminations and Other |  | General Corporate Expenses |  | Carrier |
| Net sales | $ | 7,838 |  |  | $ | 1,870 |  |  | $ | 1,801 |  |  | $ | (244) |  |  | $ | — |  |  | $ | 11,265 |  |
| Segment operating profit | $ | 1,177 |  |  | $ | 220 |  |  | $ | (64) |  |  | $ | (184) |  |  | $ | (105) |  |  | $ | 1,044 |  |
| Reported operating margin | 15.0 | % |  | 11.8 | % |  | (3.6) | % |  |  |  |  |  | 9.3 | % |
| Adjustments to segment operating profit: |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring costs | $ | 2 |  |  | $ | 10 |  |  | $ | 12 |  |  | $ | 2 |  |  | $ | — |  |  | $ | 26 |  |
| Amortization of acquired intangibles | 73 |  |  | — |  |  | 4 |  |  | — |  |  | — |  |  | 77 |  |
| Acquisition step-up amortization (1) | 21 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 21 |  |
| Acquisition-related costs | — |  |  | — |  |  | — |  |  | — |  |  | 26 |  |  | 26 |  |
| Viessmann-related hedges | — |  |  | — |  |  | — |  |  | 111 |  |  | — |  |  | 111 |  |
| TCC acquisition-related gain (2) | 8 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 8 |  |
| KFI deconsolidation | — |  |  | — |  |  | 293 |  |  | — |  |  | — |  |  | 293 |  |
| Total adjustments to operating profit | $ | 104 |  |  | $ | 10 |  |  | $ | 309 |  |  | $ | 113 |  |  | $ | 26 |  |  | $ | 562 |  |
| Adjusted operating profit | $ | 1,281 |  |  | $ | 230 |  |  | $ | 245 |  |  | $ | (71) |  |  | $ | (79) |  |  | $ | 1,606 |  |
| Adjusted operating margin | 16.3 | % |  | 12.3 | % |  | 13.6 | % |  |  |  |  |  | 14.3 | % |

[0001783180-23-000053:8k_2_02:75]
|  | (Unaudited) |
|  | Six Months Ended June 30, 2022 |
| (In millions) | HVAC |  | Refrigeration |  | Fire & Security |  | Eliminations and Other |  | General Corporate Expenses |  | Carrier |
| Net sales | $ | 6,358 |  |  | $ | 2,017 |  |  | $ | 1,705 |  |  | $ | (215) |  |  | $ | — |  |  | $ | 9,865 |  |
| Segment operating profit | $ | 1,055 |  |  | $ | 254 |  |  | $ | 1,352 |  |  | $ | (40) |  |  | $ | (65) |  |  | $ | 2,556 |  |
| Reported operating margin | 16.6 | % |  | 12.6 | % |  | 79.3 | % |  |  |  |  |  | 25.9 | % |
| Adjustments to segment operating profit: |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring costs | $ | 6 |  |  | $ | 6 |  |  | $ | 9 |  |  | $ | — |  |  | $ | 2 |  |  | $ | 23 |  |
| Amortization of acquired intangibles | 8 |  |  | — |  |  | 2 |  |  | — |  |  | — |  |  | 10 |  |
| Acquisition-related costs | — |  |  | — |  |  | — |  |  | — |  |  | 13 |  |  | 13 |  |
| Chubb gain | — |  |  | — |  |  | (1,112) |  |  | — |  |  | — |  |  | (1,112) |  |
| Russia/Ukraine asset impairment | — |  |  | 4 |  |  | 1 |  |  | — |  |  | — |  |  | 5 |  |
| Charge resulting from legal matter | 22 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 22 |  |
| Total adjustments to operating profit | $ | 36 |  |  | $ | 10 |  |  | $ | (1,100) |  |  | $ | — |  |  | $ | 15 |  | $ | 15 |  | $ | (1,039) |  |
| Adjusted operating profit | $ | 1,091 |  |  | $ | 264 |  |  | $ | 252 |  |  | $ | (40) |  |  | $ | (50) |  |  | $ | 1,517 |  |
| Adjusted operating margin | 17.2 | % |  | 13.1 | % |  | 14.8 | % |  |  |  |  |  | 15.4 | % |

[0001783180-23-000053:8k_2_02:76]
(1)  Amortization of the step-up to fair value of acquired inventory and backlog.

[0001783180-23-000053:8k_2_02:77]
(2)  The carrying value of our previously held TCC equity investments were recognized at fair value and subsequently adjusted.

[0001783180-23-000053:8k_2_02:78]
11

[0001783180-23-000053:8k_2_02:79]
Carrier Global Corporation

[0001783180-23-000053:8k_2_02:80]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP) Results

[0001783180-23-000053:8k_2_02:81]
Net Income, Earnings Per Share and Effective Tax Rate

[0001783180-23-000053:8k_2_02:82]
|  | (Unaudited) |
|  | Three Months Ended June 30, 2023 |  | Six Months Ended June 30, 2023 |
| (In millions, except per share amounts) | Reported |  | Adjustments |  | Adjusted |  | Reported |  | Adjustments |  | Adjusted |
| Net sales | $ | 5,992 |  |  | $ | — |  |  | $ | 5,992 |  |  | $ | 11,265 |  |  | $ | — |  |  | $ | 11,265 |  |
| Operating profit | $ | 489 |  |  | 475 |  | a | $ | 964 |  |  | $ | 1,044 |  |  | 562 |  | a | $ | 1,606 |  |
| Operating margin | 8.2 | % |  |  |  | 16.1 | % |  | 9.3 | % |  |  |  | 14.3 | % |
| Income from operations before income taxes | $ | 422 |  |  | 496 |  | a,b | $ | 918 |  |  | $ | 931 |  |  | 583 |  | a,b | $ | 1,514 |  |
| Income tax expense | $ | (189) |  |  | (25) |  | c | $ | (214) |  |  | $ | (311) |  |  | (43) |  | c | $ | (354) |  |
| Effective tax rate | 44.8 | % |  |  |  | 23.3 | % |  | 33.4 | % |  |  |  | 23.4 | % |
| Net income attributable to common shareowners | $ | 199 |  |  | $ | 471 |  |  | $ | 670 |  |  | $ | 572 |  |  | $ | 540 |  |  | $ | 1,112 |  |
| Summary of Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring costs |  |  | $ | 9 |  | a |  |  |  |  | $ | 26 |  | a |  |
| Amortization of acquired intangibles |  |  | 38 |  | a |  |  |  |  | 77 |  | a |  |
| Acquisition step-up amortization (1) |  |  | 10 |  | a |  |  |  |  | 21 |  | a |  |
| Acquisition-related costs |  |  | 14 |  | a |  |  |  |  | 26 |  | a |  |
| Viessmann-related hedges |  |  | 111 |  | a |  |  |  |  | 111 |  | a |  |
| TCC acquisition-related gain (2) |  |  | — |  | a |  |  |  |  | 8 |  | a |  |
| KFI deconsolidation |  |  | 293 |  | a |  |  |  |  | 293 |  | a |  |
| Bridge loan financing costs |  |  | 21 |  | b |  |  |  |  | 21 |  | b |  |
| Total adjustments |  |  | $ | 496 |  |  |  |  |  |  | $ | 583 |  |  |  |
| Tax effect on adjustments above |  |  | $ | (25) |  |  |  |  |  |  | $ | (43) |  |  |  |
| Total tax adjustments |  |  | $ | (25) |  | c |  |  |  |  | $ | (43) |  | c |  |
| Shares outstanding - Diluted | 850.9 |  |  |  |  | 850.9 |  |  | 851.5 |  |  |  |  | 851.5 |  |
| Earnings per share - Diluted | $ | 0.23 |  |  |  |  | $ | 0.79 |  |  | $ | 0.67 |  |  |  |  | $ | 1.31 |  |

[0001783180-23-000053:8k_2_02:83]
(1)  Amortization of the step-up to fair value of acquired inventory and backlog.

[0001783180-23-000053:8k_2_02:84]
(2)  The carrying value of our previously held TCC equity investments were recognized at fair value and subsequently adjusted.

[0001783180-23-000053:8k_2_02:85]
12

[0001783180-23-000053:8k_2_02:86]
Carrier Global Corporation

[0001783180-23-000053:8k_2_02:87]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP) Results

[0001783180-23-000053:8k_2_02:88]
Net Income, Earnings Per Share and Effective Tax Rate

[0001783180-23-000053:8k_2_02:89]
|  | (Unaudited) |
|  | Three Months Ended June 30, 2022 |  | Six Months Ended June 30, 2022 |
| (In millions, except per share amounts) | Reported |  | Adjustments |  | Adjusted |  | Reported |  | Adjustments |  | Adjusted |
| Net sales | $ | 5,211 |  |  | $ | — |  |  | $ | 5,211 |  |  | $ | 9,865 |  |  | $ | — |  |  | $ | 9,865 |  |
| Operating profit | $ | 819 |  |  | 43 |  | a | $ | 862 |  |  | $ | 2,556 |  |  | (1,039) |  | a | $ | 1,517 |  |
| Operating margin | 15.7 | % |  |  |  | 16.5 | % |  | 25.9 | % |  |  |  | 15.4 | % |
| Income from operations before income taxes | $ | 757 |  |  | 43 |  | a,b | $ | 800 |  |  | $ | 2,445 |  |  | (1,067) |  | a,b | $ | 1,378 |  |
| Income tax expense | $ | (170) |  |  | (13) |  | c | $ | (183) |  |  | $ | (471) |  |  | 195 |  | c | $ | (276) |  |
| Effective tax rate | 22.5 | % |  |  |  | 22.9 | % |  | 19.3 | % |  |  |  | 20.0 | % |
| Net income attributable to common shareowners | $ | 573 |  |  | $ | 30 |  |  | $ | 603 |  |  | $ | 1,952 |  |  | $ | (872) |  |  | $ | 1,080 |  |
| Summary of Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring costs |  |  | $ | 13 |  | a |  |  |  |  | $ | 23 |  | a |  |
| Amortization of acquired intangibles |  |  | 5 |  | a |  |  |  |  | 10 |  | a |  |
| Acquisition-related costs |  |  | 7 |  | a |  |  |  |  | 13 |  | a |  |
| Chubb gain |  |  | — |  | a |  |  |  |  | (1,112) |  | a |  |
| Russia/Ukraine asset impairment |  |  | (4) |  | a |  |  |  |  | 5 |  | a |  |
| Charge resulting from legal matter |  |  | 22 |  | a |  |  |  |  | 22 |  | a |  |
| Debt extinguishment (gain), net (1) |  |  | — |  | b |  |  |  |  | (28) |  | b |  |
| Total adjustments |  |  | $ | 43 |  |  |  |  |  |  | $ | (1,067) |  |  |  |
| Tax effect on adjustments above |  |  | $ | (8) |  |  |  |  |  |  | $ | 200 |  |  |  |
| Tax specific adjustments |  |  | (5) |  |  |  |  |  |  | (5) |  |  |  |
| Total tax adjustments |  |  | $ | (13) |  | c |  |  |  |  | $ | 195 |  | c |  |
| Shares outstanding - Diluted | 862.7 |  |  |  |  | 862.7 |  |  | 868.4 |  |  |  |  | 868.4 |  |
| Earnings per share - Diluted | $ | 0.67 |  |  |  |  | $ | 0.70 |  |  | $ | 2.25 |  |  |  |  | $ | 1.24 |  |

[0001783180-23-000053:8k_2_02:90]
(1)  The Company repurchased approximately $1.15 billion of aggregate principal senior notes on March 30, 2022 and recognized a net gain of $33 million and wrote-off $5 million of unamortized deferred financing costs in Interest (expense) income, net.

[0001783180-23-000053:8k_2_02:91]
13

[0001783180-23-000053:8k_2_02:92]
Carrier Global Corporation

[0001783180-23-000053:8k_2_02:93]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP) Results

[0001783180-23-000053:8k_2_02:94]
Components of Changes in Net Sales

[0001783180-23-000053:8k_2_02:95]
| Three Months Ended June 30, 2023 Compared with Three Months Ended June 30, 2022 |
|  | (Unaudited) |
|  | Factors Contributing to Total % change in Net Sales |
|  | Organic |  | FX Translation |  | Acquisitions / Divestitures, net |  | Other |  | Total |
| HVAC | 9 | % |  | (1) | % |  | 16 | % |  | — | % |  | 24 | % |
| Refrigeration | (6) | % |  | — | % |  | (1) | % |  | — | % |  | (7) | % |
| Fire & Security | 9 | % |  | (1) | % |  | — | % |  | (3) | % |  | 5 | % |
| Consolidated | 6 | % |  | — | % |  | 9 | % |  | — | % |  | 15 | % |

[0001783180-23-000053:8k_2_02:96]
| Six Months Ended June 30, 2023 Compared with Six Months Ended June 30, 2022 |
|  | (Unaudited) |
|  | Factors Contributing to Total % change in Net Sales |
|  | Organic |  | FX Translation |  | Acquisitions / Divestitures, net |  | Other |  | Total |
| HVAC | 7 | % |  | (1) | % |  | 17 | % |  | — | % |  | 23 | % |
| Refrigeration | (5) | % |  | (1) | % |  | (1) | % |  | — | % |  | (7) | % |
| Fire & Security | 9 | % |  | (2) | % |  | — | % |  | (1) | % |  | 6 | % |
| Consolidated | 5 | % |  | (1) | % |  | 10 | % |  | — | % |  | 14 | % |

[0001783180-23-000053:8k_2_02:97]
Historical Amounts of Amortization of Acquired Intangibles

[0001783180-23-000053:8k_2_02:98]
|  |  | (Unaudited) |
|  |  | Q1 |  | Q2 |  | Q3 |  | Q4 |  | FY |  |  |  |  |
| (In millions) |  | 2022 |  | 2022 |  | 2022 |  | 2022 |  | 2022 |  |  |  |  |
| HVAC |  | $ | 4 |  |  | $ | 4 |  |  | $ | 16 |  |  | $ | 22 |  |  | $ | 46 |  |  |  |  |  |
| Fire & Security |  | 1 |  |  | 1 |  |  | 1 |  |  | 1 |  |  | 4 |  |  |  |  |  |
| Total Carrier |  | 5 |  |  | 5 |  |  | 17 |  |  | 23 |  | 50 |  |  |  |  |  |
| Associated tax effect |  | (1) |  |  | (1) |  |  | (7) |  |  | (4) |  |  | (13) |  |  |  |  |  |
| Net impact to adjusted results |  | $ | 4 |  |  | $ | 4 |  |  | $ | 10 |  |  | $ | 19 |  |  | $ | 37 |  |  |  |  |  |

[0001783180-23-000053:8k_2_02:99]
14

[0001783180-23-000053:8k_2_02:100]
Free Cash Flow Reconciliation

[0001783180-23-000053:8k_2_02:101]
|  |  | (Unaudited) |
|  |  | Q1 |  | Q2 |  | Q3 |  | Q4 |  | FY |  | Q1 |  | Q2 |  |  |  |  |
| (In millions) |  | 2022 |  | 2022 |  | 2022 |  | 2022 |  | 2022 |  | 2023 |  | 2023 |  |  |  |  |
| Net cash flows provided by (used in) operating activities |  | $ | (202) |  |  | $ | 32 |  |  | $ | 790 |  |  | $ | 1,123 |  |  | $ | 1,743 |  |  | $ | 120 |  |  | $ | 384 |  |  |  |  |  |
| Less: Capital expenditures |  | 56 |  |  | 66 |  |  | 91 |  |  | 140 |  | 353 |  |  | 70 |  |  | 74 |  |  |  |  |  |
| Free cash flow |  | $ | (258) |  |  | $ | (34) |  |  | $ | 699 |  |  | $ | 983 |  |  | $ | 1,390 |  |  | $ | 50 |  |  | $ | 310 |  |  |  |  |  |

[0001783180-23-000053:8k_2_02:102]
Net Debt Reconciliation

[0001783180-23-000053:8k_2_02:103]
|  |  | (Unaudited) |
| (In millions) |  | June 30, 2023 |  | December 31, 2022 |
| Long-term debt |  | $ | 8,655 |  |  | $ | 8,702 |  |
| Current portion of long-term debt |  | 134 |  |  | 140 |  |
| Less: Cash and cash equivalents |  | 3,209 |  |  | 3,520 |  |
| Net debt |  | $ | 5,580 |  |  | $ | 5,322 |  |

[0001783180-23-000053:8k_2_02:104]
15
