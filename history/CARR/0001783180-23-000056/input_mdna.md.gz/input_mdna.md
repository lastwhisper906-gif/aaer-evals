# CARR MD&A — 0001783180-23-000056


## mdna

[0001783180-23-000056:mdna:1]
[same as prior period, unchanged from 0001783180-23-000038:mdna:1]

[0001783180-23-000056:mdna:2]
[same as prior period, unchanged from 0001783180-23-000038:mdna:2]

[0001783180-23-000056:mdna:3]
[same as prior period, unchanged from 0001783180-23-000038:mdna:3]

[0001783180-23-000056:mdna:4]
Carrier Global Corporation ("we" or "our") is a global leader in intelligent climate and energy solutions with a focus on providing differentiated, digitally-enabled lifecycle solutions to our customers. Our portfolio includes industry-leading brands such as Carrier, Toshiba, Automated Logic, Carrier Transicold, Kidde, Edwards and LenelS2 that offer innovative heating, ventilating and air conditioning ("HVAC"), refrigeration, fire, security and building automation technologies to help make the world safer and more comfortable. We also provide a broad array of related building services, including audit, design, installation, system integration, repair, maintenance and monitoring. Our operations are classified into three segments: HVAC, Refrigeration and Fire & Security.

[0001783180-23-000056:mdna:5]
[same as prior period, unchanged from 0001783180-23-000038:mdna:5]

[0001783180-23-000056:mdna:6]
[same as prior period, unchanged from 0001783180-23-000038:mdna:6]

[0001783180-23-000056:mdna:7]
[same as prior period, unchanged from 0001783180-23-000038:mdna:7]

[0001783180-23-000056:mdna:8]
Supply Chain Challenges

[0001783180-23-000056:mdna:9]
The ongoing global economic recovery from the COVID-19 pandemic has caused significant challenges for global supply chains resulting in inflationary cost pressures, component shortages and transportation delays. As a result, we have incurred incremental costs for commodities and components used in our products as well as component shortages that have negatively impacted our sales and results of operations. Inflationary cost pressures and supply chain challenges have begun to moderate, but continue to affect our results. We expect that these challenges will continue to impact our businesses for the foreseeable future.

[0001783180-23-000056:mdna:10]
[same as prior period, unchanged from 0001783180-23-000038:mdna:9]

[0001783180-23-000056:mdna:11]
Planned Portfolio Transformation

[0001783180-23-000056:mdna:12]
On April 25, 2023, we announced that we entered into a Share Purchase Agreement (the “Agreement”) to acquire the climate solutions business (the "VCS Business") of Viessmann Group GmbH & Co. KG (“Viessmann”), a privately-held company, for approximately €12 billion. The VCS Business develops intelligent, integrated and sustainable technologies, including heat pumps, boilers, photovoltaic systems, home battery storage and digital solutions, primarily for residential customers in Europe. The transaction is expected to close around the end of 2023, subject to customary closing conditions and regulatory approvals. In addition, we also announced plans to exit our Fire & Security and Commercial Refrigeration businesses over the course of 2024.

[0001783180-23-000056:mdna:13]
Deconsolidation of Kidde-Fenwal, Inc.

[0001783180-23-000056:mdna:14]
On May 14, 2023, Kidde-Fenwal, Inc. ("KFI") filed a petition for voluntary reorganization under Chapter 11 of the United States Bankruptcy Code ("Chapter 11") in the United States Bankruptcy Court for the District of Delaware. KFI, an industrial fire detection and suppression business and an indirect wholly-owned subsidiary of the Company, has indicated that it intends to use the bankruptcy process to explore strategic alternatives, including the sale of KFI as a going concern. KFI has further stated that, during the Chapter 11 process, KFI expects that there will be no significant interruptions to its business operations. As of the petition date, KFI was deconsolidated and its respective assets and liabilities were derecognized from the Company's Unaudited Condensed Consolidated Financial Statements.

[0001783180-23-000056:mdna:15]
[same as prior period, unchanged from 0001783180-23-000038:mdna:10]

[0001783180-23-000056:mdna:16]
[same as prior period, unchanged from 0001783180-23-000038:mdna:11]

[0001783180-23-000056:mdna:17]
[same as prior period, unchanged from 0001783180-23-000038:mdna:12]

[0001783180-23-000056:mdna:18]
[same as prior period, unchanged from 0001783180-23-000038:mdna:13]

[0001783180-23-000056:mdna:19]
[same as prior period, unchanged from 0001783180-23-000038:mdna:14]

[0001783180-23-000056:mdna:20]
[same as prior period, unchanged from 0001783180-23-000038:mdna:15]

[0001783180-23-000056:mdna:21]
[same as prior period, unchanged from 0001783180-23-000038:mdna:17]

[0001783180-23-000056:mdna:22]
The results of operations of TCC are included in our consolidated results since the acquisition date of August 1, 2022. Prior to the acquisition, we previously accounted for our minority ownership in TCC under the equity method of accounting and recognized our portion of earnings within Equity method investment in net earnings as part of operating expenses. As a result, prior period results may not be comparable to the current period. See Note 15 - Acquisitions in the Notes to the accompanying Unaudited Condensed Consolidated Financial Statements for additional information.

[0001783180-23-000056:mdna:23]
Three Months Ended June 30, 2023 Compared with the Three Months Ended June 30, 2022

[0001783180-23-000056:mdna:24]
[same as prior period, unchanged from 0001783180-23-000038:mdna:20]

[0001783180-23-000056:mdna:25]
|  |  | Three Months Ended June 30, |  |  |  |  |  |  |
| (In millions) |  | 2023 |  | 2022 |  | Period Change |  | % Change |  |  |  |  |  |  |
| Net sales |  | $ | 5,992 |  |  | $ | 5,211 |  |  | $ | 781 |  |  | 15 | % |  |  |  |  |  |  |
| Cost of products and services sold |  | (4,237) |  |  | (3,764) |  |  | (473) |  |  | 13 | % |  |  |  |  |  |  |
| Gross margin |  | 1,755 |  |  | 1,447 |  |  | 308 |  |  | 21 | % |  |  |  |  |  |  |
| Operating expenses |  | (1,266) |  |  | (628) |  |  | (638) |  |  | 102 | % |  |  |  |  |  |  |
| Operating profit |  | 489 |  |  | 819 |  |  | (330) |  |  | (40) | % |  |  |  |  |  |  |
| Non-operating income (expense), net |  | (67) |  |  | (62) |  |  | (5) |  |  | 8 | % |  |  |  |  |  |  |
| Income from operations before income taxes |  | 422 |  |  | 757 |  |  | (335) |  |  | (44) | % |  |  |  |  |  |  |
| Income tax expense |  | (189) |  |  | (170) |  |  | (19) |  |  | 11 | % |  |  |  |  |  |  |
| Net income from operations |  | 233 |  |  | 587 |  |  | (354) |  |  | (60) | % |  |  |  |  |  |  |
| Less: Non-controlling interest in subsidiaries' earnings from operations |  | 34 |  |  | 14 |  |  | 20 |  |  | 143 | % |  |  |  |  |  |  |
| Net income attributable to common shareowners |  | $ | 199 |  |  | $ | 573 |  |  | $ | (374) |  |  | (65) | % |  |  |  |  |  |  |

[0001783180-23-000056:mdna:26]
[same as prior period, unchanged from 0001783180-23-000038:mdna:22]

[0001783180-23-000056:mdna:27]
For the three months ended June 30, 2023, Net sales were $6.0 billion, a 15% increase compared with the same period of 2022. The components of the year-over-year change were as follows:

[0001783180-23-000056:mdna:28]
|  |  | Three Months Ended June 30, 2023 |  |  |  |  |  |  |
| Organic |  | 6 | % |  |  |  |  |  |  |
| Foreign currency translation |  | — | % |  |  |  |  |  |  |
| Acquisitions and divestitures, net |  | 9 | % |  |  |  |  |  |  |
| Total % change |  | 15 | % |  |  |  |  |  |  |

[0001783180-23-000056:mdna:29]
Organic sales for the three months ended June 30, 2023 increased by 6% compared with the same period of 2022. The organic increase was driven by our HVAC segment due to improved global end-markets in our Commercial HVAC business and pricing improvements in our North America residential and light commercial business. In addition, our Fire & Security segment benefited from price improvements and volume growth in each region. Refrigeration results decreased as each of the segment's businesses experienced challenges in certain end-markets during the quarter. Refer to "Segment Review" below for a discussion of Net sales by segment.

[0001783180-23-000056:mdna:30]
On August 1, 2022, the Commercial HVAC business acquired a majority ownership interest in TCC, a VRF and light commercial HVAC joint venture between Carrier and Toshiba Corporation. The results of TCC have been included in our Unaudited Condensed Consolidated Financial Statements since the date of acquisition. The transaction added 10% to Net sales during the three months ended June 30, 2023 and is included in Acquisitions and divestitures, net.

[0001783180-23-000056:mdna:31]
As of May 14, 2023, we no longer control KFI as their activities are subject to review and oversight by the bankruptcy court. Therefore, KFI was deconsolidated and their respective assets and liabilities were derecognized from our Unaudited Condensed Consolidated Financial Statements. The deconsolidation had a 1% impact on Net sales during the three months ended June 30, 2023 and is included in Acquisitions and divestitures, net.

[0001783180-23-000056:mdna:32]
[same as prior period, unchanged from 0001783180-23-000038:mdna:26]

[0001783180-23-000056:mdna:33]
For the three months ended June 30, 2023, gross margin was $1.8 billion, a 21% increase compared with the same period of 2022. The components were as follows:

[0001783180-23-000056:mdna:34]
|  |  | Three Months Ended June 30, |  |  |  |  |  |  |
| (In millions) |  | 2023 |  | 2022 |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 5,992 |  |  | $ | 5,211 |  |  |  |  |  |  |  |  |  |
| Cost of products and services sold |  | (4,237) |  |  | (3,764) |  |  |  |  |  |  |  |  |  |
| Gross margin |  | $ | 1,755 |  |  | $ | 1,447 |  |  |  |  |  |  |  |  |  |
| Percentage of net sales |  | 29.3 | % |  | 27.8 | % |  |  |  |  |  |  |  |  |

[0001783180-23-000056:mdna:35]
Gross margin increased by $308 million compared with the three months ended June 30, 2022. The main driver of the increase related to ongoing customer demand, pricing improvements and our continued focus on productivity initiatives. In addition, operating results associated with TCC since the date of acquisition further benefited gross margin during the period. These amounts were partially offset by the higher cost of commodities and components used in our products, certain supply chain constraints and freight costs. Although inflationary cost pressures have begun to moderate, they remain elevated and continue to impact the cost of products and services sold in each of our segments. Gross margin as a percentage of Net sales increased by 150 basis points compared with the same period of 2022.

[0001783180-23-000056:mdna:36]
[same as prior period, unchanged from 0001783180-23-000038:mdna:31]

[0001783180-23-000056:mdna:37]
For the three months ended June 30, 2023, operating expenses, including Equity method investment net earnings, were $1.3 billion, a 102% increase compared with the same period of 2022. The components were as follows:

[0001783180-23-000056:mdna:38]
|  |  | Three Months Ended June 30, |  |
| (In millions) |  | 2023 |  | 2022 |  |
| Selling, general and administrative |  | $ | (784) |  |  | $ | (614) |  |  |
| Research and development |  | (151) |  |  | (122) |  |  |
| Equity method investment net earnings |  | 52 |  |  | 101 |  |  |
| Other income (expense), net |  | (383) |  |  | 7 |  |  |
| Total operating expenses |  | $ | (1,266) |  |  | $ | (628) |  |  |
| Percentage of net sales |  | 21.1 | % |  | 12.1 | % |  |

[0001783180-23-000056:mdna:39]
For the three months ended June 30, 2023, Selling, general and administrative expenses were $784 million, a 28% increase compared with the same period of 2022. The increase is primarily due to higher compensation and other employee-related costs in the current period. In addition, incremental selling, general and administrative expenses associated with TCC since the date of acquisition and portfolio transformation-related costs further contributed to the increase. The current period also included $14 million of acquisition-related costs compared with $7 million during the three months ended June 30, 2022.

[0001783180-23-000056:mdna:40]
[same as prior period, unchanged from 0001783180-23-000038:mdna:35]

[0001783180-23-000056:mdna:41]
Investments over which we do not exercise control, but have significant influence, are accounted for using the equity method of accounting. For the three months ended June 30, 2023, Equity method investment net earnings were $52 million, a 49% decrease compared with the same period of 2022. The decrease was primarily driven by the increase in our ownership interest in TCC on August 1, 2022. As a result, TCC is no longer accounted for under the equity method of accounting since the date of acquisition. During the three months ended June 30, 2022, pre-acquisition equity earnings of TCC totaled $47 million which included a $27 million gain on the sale of two minority owned subsidiaries.

[0001783180-23-000056:mdna:42]
Other income (expense), net primarily includes the impact of gains and losses related to the sale of businesses or interests in our equity method investments, foreign currency gains and losses on transactions that are denominated in a currency other than an entity's functional currency and hedging-related activities. In connection with the proposed acquisition of the VCS Business, we recognized a $111 million loss during the three months ended June 30, 2023 on the mark-to-market valuation of our window forward contracts associated with the expected cash outflows of the Euro-denominated purchase price for the Business. In addition, we recognized a loss of $293 million on the deconsolidation of KFI due to its Chapter 11 filing. During the three months ended June 30, 2022, we recognized a $22 million charge resulting from a litigation matter and a $7 million gain on the sale of our interest in a cost method investment reported within our Refrigeration segment.

[0001783180-23-000056:mdna:43]
Non-Operating Income (Expense), net

[0001783180-23-000056:mdna:44]
For the three months ended June 30, 2023, Non-operating income (expense), net was $67 million, an 8% increase compared with the same period of 2022. The components were as follows:

[0001783180-23-000056:mdna:45]
|  |  | Three Months Ended June 30, |  |
| (In millions) |  | 2023 |  | 2022 |  |
| Non-service pension (expense) benefit |  | $ | — |  |  | $ | (1) |  |  |
| Interest expense |  | $ | (94) |  |  | $ | (68) |  |  |
| Interest income |  | 27 |  |  | 7 |  |  |
| Interest (expense) income, net |  | $ | (67) |  |  | $ | (61) |  |  |
| Non-operating income (expense), net |  | $ | (67) |  |  | $ | (62) |  |  |

[0001783180-23-000056:mdna:46]
Non-operating income (expense), net includes the results from activities other than normal business operations such as interest expense, interest income and the non-service components of pension and post-retirement obligations. Interest expense is affected by the amount of debt outstanding and the interest rates on that debt. For the three months ended June 30, 2023, Interest expense was $94 million, a 38% increase compared with the same period of 2022. In connection with the proposed acquisition of the VCS Business, we entered into several financing arrangements and capitalized $42 million of deferred financing costs in the current period. During the three months ended June 30, 2023, we amortized $21 million of deferred financing costs in Interest expense, of which $19 million related to our senior unsecured bridge term loan facility ("the Bridge Loan").

[0001783180-23-000056:mdna:47]
[same as prior period, unchanged from 0001783180-23-000038:mdna:43]

[0001783180-23-000056:mdna:48]
|  |  | Three Months Ended June 30, |  |  |  |
|  |  | 2023 |  | 2022 |  |  |  |  |  |  |  |
| Effective tax rate |  | 44.8 | % |  | 22.5 | % |  |  |  |  |  |  |  |

[0001783180-23-000056:mdna:49]
We account for income tax expense in accordance with ASC 740, which requires an estimate of the annual effective income tax rate for the full year to be applied to the respective interim period, taking into account year-to-date amounts and projected results for the full year. The effective tax rate was 44.8% for the three months ended June 30, 2023 compared with 22.5% for the three months ended June 30, 2022. The year-over-year increase was primarily driven by the non-deductible losses of $293 million on the deconsolidation of KFI due to its Chapter 11 filing and the $111 million loss on the mark-to-market valuation of our window forward contracts associated with the expected cash outflows of the Euro-denominated purchase price of the VCS Business.

[0001783180-23-000056:mdna:50]
33

[0001783180-23-000056:mdna:51]
Six Months Ended June 30, 2023 Compared with the Six Months Ended June 30, 2022

[0001783180-23-000056:mdna:52]
The following represents our consolidated net sales and operating results:

[0001783180-23-000056:mdna:53]
|  |  | Six Months Ended June 30, |  |  |  |  |  |  |
| (In millions) |  | 2023 |  | 2022 |  | Period Change |  | % Change |  |  |  |  |  |  |
| Net sales |  | $ | 11,265 |  |  | $ | 9,865 |  |  | $ | 1,400 |  |  | 14 | % |  |  |  |  |  |  |
| Cost of products and services sold |  | (8,132) |  |  | (7,125) |  |  | (1,007) |  |  | 14 | % |  |  |  |  |  |  |
| Gross margin |  | 3,133 |  |  | 2,740 |  |  | 393 |  |  | 14 | % |  |  |  |  |  |  |
| Operating expenses |  | (2,089) |  |  | (184) |  |  | (1,905) |  |  | 1,035 | % |  |  |  |  |  |  |
| Operating profit |  | 1,044 |  |  | 2,556 |  |  | (1,512) |  |  | (59) | % |  |  |  |  |  |  |
| Non-operating income (expense), net |  | (113) |  |  | (111) |  |  | (2) |  |  | 2 | % |  |  |  |  |  |  |
| Income from operations before income taxes |  | 931 |  |  | 2,445 |  |  | (1,514) |  |  | (62) | % |  |  |  |  |  |  |
| Income tax expense |  | (311) |  |  | (471) |  |  | 160 |  |  | (34) | % |  |  |  |  |  |  |
| Net income from operations |  | 620 |  |  | 1,974 |  |  | (1,354) |  |  | (69) | % |  |  |  |  |  |  |
| Less: Non-controlling interest in subsidiaries' earnings from operations |  | 48 |  |  | 22 |  |  | 26 |  |  | 118 | % |  |  |  |  |  |  |
| Net income attributable to common shareowners |  | $ | 572 |  |  | $ | 1,952 |  |  | $ | (1,380) |  |  | (71) | % |  |  |  |  |  |  |

[0001783180-23-000056:mdna:54]
Net Sales

[0001783180-23-000056:mdna:55]
For the six months ended June 30, 2023, Net sales were $11.3 billion, a 14% increase compared with the same period of 2022. The components of the year-over-year change were as follows:

[0001783180-23-000056:mdna:56]
|  |  |  |  | Six Months Ended June 30, 2023 |  |  |  |  |
| Organic |  |  |  | 5 | % |  |  |  |  |
| Foreign currency translation |  |  |  | (1) | % |  |  |  |  |
| Acquisitions and divestitures, net |  |  |  | 10 | % |  |  |  |  |
| Total % change |  |  |  | 14 | % |  |  |  |  |

[0001783180-23-000056:mdna:57]
Organic sales for the six months ended June 30, 2023 increased by 5% compared with the same period of 2022. The organic increase was primarily driven by our Fire & Security segment due to price improvements and volume growth in each region. In addition, improved global end-markets in our Commercial HVAC business and pricing improvements in our North America residential and light commercial business further benefited our results. Refrigeration results decreased as each of the segment's businesses experienced challenges in certain end-markets during the quarter. Refer to "Segment Review" below for a discussion of Net sales by segment.

[0001783180-23-000056:mdna:58]
On August 1, 2022, the Commercial HVAC business acquired a majority ownership interest in TCC, a VRF and light commercial HVAC joint venture between Carrier and Toshiba Corporation. The results of TCC have been included in our Unaudited Condensed Consolidated Financial Statements since the date of acquisition. The transaction added 11% to Net sales during the six months ended June 30, 2023 and is included in Acquisitions and divestitures, net.

[0001783180-23-000056:mdna:59]
As of May 14, 2023, we no longer control KFI as their activities are subject to review and oversight by the bankruptcy court. Therefore, KFI was deconsolidated and their respective assets and liabilities were derecognized from our Unaudited Condensed Consolidated Financial Statements. The deconsolidation had a 1% impact on Net sales during the six months ended June 30, 2023 and is included in Acquisitions and divestitures, net.

[0001783180-23-000056:mdna:60]
34

[0001783180-23-000056:mdna:61]
Gross Margin

[0001783180-23-000056:mdna:62]
For the six months ended June 30, 2023, gross margin was $3.1 billion, a 14% increase compared with the same period of 2022. The components were as follows:

[0001783180-23-000056:mdna:63]
|  |  |  |  | Six Months Ended June 30, |  |  |  |  |
| (In millions) |  |  |  |  |  | 2023 |  | 2022 |  |  |  |  |
| Net sales |  |  |  |  |  | $ | 11,265 |  |  | $ | 9,865 |  |  |  |  |  |
| Cost of products and services sold |  |  |  |  |  | (8,132) |  |  | (7,125) |  |  |  |  |  |
| Gross margin |  |  |  |  |  | $ | 3,133 |  |  | $ | 2,740 |  |  |  |  |  |
| Percentage of net sales |  |  |  |  |  | 27.8 | % |  | 27.8 | % |  |  |  |  |

[0001783180-23-000056:mdna:64]
Gross margin increased by $393 million compared with the six months ended June 30, 2022. The main driver of the increase related to ongoing customer demand, pricing improvements and our continued focus on productivity initiatives. In addition, operating results associated with TCC since the date of acquisition further benefited gross margin during the period. These amounts were partially offset by the higher cost of commodities and components used in our products, certain supply chain constraints and freight costs. Although inflationary cost pressures have begun to moderate, they remain elevated and continue to impact the cost of products and services sold in each of our segments. While pricing improvements more than offset inflationary impacts and supply chain challenges, gross margin as a percentage of Net sales remained flat compared with the same period of 2022.

[0001783180-23-000056:mdna:65]
Operating Expenses

[0001783180-23-000056:mdna:66]
For the six months ended June 30, 2023, operating expenses, including Equity method investment net earnings, were $2.1 billion, a 1,035% increase compared with the same period of 2022. The components were as follows:

[0001783180-23-000056:mdna:67]
|  |  | Six Months Ended June 30, |
| (In millions) |  | 2023 |  | 2022 |
| Selling, general and administrative |  | $ | (1,505) |  |  | $ | (1,215) |  |
| Research and development |  | (290) |  |  | (247) |  |
| Equity method investment net earnings |  | 96 |  |  | 159 |  |
| Other income (expense), net |  | (390) |  |  | 1,119 |  |
| Total operating expenses |  | $ | (2,089) |  |  | $ | (184) |  |
| Percentage of net sales |  | 18.5 | % |  | 1.9 | % |

[0001783180-23-000056:mdna:68]
For the six months ended June 30, 2023, Selling, general and administrative expenses were $1.5 billion, a 24% increase compared with the same period of 2022. The increase is primarily due to higher compensation and other employee-related costs during the current period. In addition, incremental selling, general and administrative expenses associated with TCC since the date of acquisition and portfolio transformation-related costs further contributed to the increase. The current period also included $26 million of acquisition-related costs compared with $13 million during the six months ended June 30, 2022.

[0001783180-23-000056:mdna:69]
Research and development costs relate to new product development and new technology innovation. Due to the variable nature of program development schedules, year-over-year spending levels can fluctuate. In addition, we continue to invest to prepare for future energy efficiency and refrigerant regulation changes and in digital controls technologies.

[0001783180-23-000056:mdna:70]
Investments over which we do not exercise control, but have significant influence, are accounted for using the equity method of accounting. For the six months ended June 30, 2023, Equity method investment net earnings were $96 million, a 40% decrease compared with the same period of 2022. The decrease was primarily driven by the increase in our ownership interest in TCC on August 1, 2022. As a result, TCC is no longer accounted for under the equity method of accounting since the date of acquisition. During the six months ended June 30, 2022, pre-acquisition equity earnings of TCC totaled $67 million which  included a $27 million gain on the sale of two minority owned subsidiaries.

[0001783180-23-000056:mdna:71]
Other income (expense), net primarily includes the impact of gains and losses related to the sale of businesses or interests in our equity method investments, foreign currency gains and losses on transactions that are denominated in a currency other than an entity's functional currency and hedging-related activities. In connection with the proposed acquisition of the VCS Business, we recognized a $111 million loss during the six months ended June 30, 2023 on the mark-to-market valuation of our window forward contracts associated with the expected cash outflows of the Euro-denominated purchase price. In addition, we recognized a loss of $293 million on the deconsolidation of KFI due to its Chapter 11 filing. During the six months ended June 30, 2022, we completed the Chubb Sale and recognized a net gain on the sale of $1.1 billion. In addition, we recognized a $22 million charge resulting from a litigation matter and a $7 million gain on the sale of our interest in a cost method investment reported within our Refrigeration segment.

[0001783180-23-000056:mdna:72]
Non-Operating Income (Expense), net

[0001783180-23-000056:mdna:73]
For the six months ended June 30, 2023, Non-operating income (expense), net was $113 million, a 2% increase compared with the same period of 2022. The components were as follows:

[0001783180-23-000056:mdna:74]
|  |  | Six Months Ended June 30, |
| (In millions) |  | 2023 |  | 2022 |
| Non-service pension (expense) benefit |  | $ | — |  |  | $ | (2) |  |
| Interest expense |  | $ | (165) |  |  | $ | (155) |  |
| Interest income |  | 52 |  |  | 46 |  |
| Interest (expense) income, net |  | $ | (113) |  |  | $ | (109) |  |
| Non-operating income (expense), net |  | $ | (113) |  |  | $ | (111) |  |

[0001783180-23-000056:mdna:75]
Non-operating income (expense), net includes the results from activities other than normal business operations such as interest expense, interest income and the non-service components of pension and post-retirement obligations. Interest expense is affected by the amount of debt outstanding and the interest rates on that debt. For the six months ended June 30, 2023, Interest expense was $165 million, a 6% increase compared with the same period of 2022. In connection with the proposed acquisition of the VCS Business, we entered into several financing arrangements and capitalized $42 million of deferred financing costs in the current period. During the six months ended June 30, 2023, we amortized $22 million of deferred financing costs in Interest expense, of which $19 million related to our Bridge Loan. During the six months ended June 30, 2022, we completed tender offers to repurchase approximately $1.15 billion aggregate principal of our 2.242% Notes due 2025 and 2.493% Notes due 2027. Upon settlement, we wrote off $5 million of unamortized deferred financing costs in Interest expense and recognized a net gain of $33 million in Interest income.

[0001783180-23-000056:mdna:76]
Income Taxes

[0001783180-23-000056:mdna:77]
|  |  |  | Six Months Ended June 30, |  |  |
|  |  |  |  |  | 2023 |  | 2022 |  |  |  |  |
| Effective tax rate |  |  |  |  | 33.4 | % |  | 19.3 | % |  |  |  |  |

[0001783180-23-000056:mdna:78]
We account for income tax expense in accordance with ASC 740, which requires an estimate of the annual effective income tax rate for the full year to be applied to the respective interim period, taking into account year-to-date amounts and projected results for the full year. The effective tax rate was 33.4% for the six months ended June 30, 2023 compared with 19.3% for the six months ended June 30, 2022.  The year-over-year increase was primarily driven by the non-deductible losses of $293 million on the deconsolidation of KFI due to its Chapter 11 filing and the $111 million loss on the mark-to-market valuation of our window forward contracts associated with the expected cash outflows of the Euro-denominated purchase price of the VCS Business. In addition, the six months ended June 30, 2022 included a lower effective tax rate on the $1.1 billion Chubb gain compared with our U.S. statutory rate and a favorable tax adjustment of $32 million associated with foreign tax credits generated and utilized in the prior year.

[0001783180-23-000056:mdna:79]
36

[0001783180-23-000056:mdna:80]
[same as prior period, unchanged from 0001783180-23-000038:mdna:47]

[0001783180-23-000056:mdna:81]
[same as prior period, unchanged from 0001783180-23-000038:mdna:48]

[0001783180-23-000056:mdna:82]
[same as prior period, unchanged from 0001783180-23-000038:mdna:49]

[0001783180-23-000056:mdna:83]
[same as prior period, unchanged from 0001783180-23-000038:mdna:50]

[0001783180-23-000056:mdna:84]
[same as prior period, unchanged from 0001783180-23-000038:mdna:51]

[0001783180-23-000056:mdna:85]
[same as prior period, unchanged from 0001783180-23-000038:mdna:52]

[0001783180-23-000056:mdna:86]
Three Months Ended June 30, 2023 Compared with Three Months Ended June 30, 2022

[0001783180-23-000056:mdna:87]
Summary performance for each of our segments is as follows:

[0001783180-23-000056:mdna:88]
|  |  | Net Sales |  | Operating Profit |  | Operating Profit Margin |
|  |  | Three Months Ended June 30, |  | Three Months Ended June 30, |  | Three Months Ended June 30, |
| (In millions) |  | 2023 |  | 2022 |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| HVAC |  | $ | 4,216 |  |  | $ | 3,388 |  |  | $ | 742 |  |  | $ | 585 |  |  | 17.6 | % |  | 17.3 | % |
| Refrigeration |  | 972 |  |  | 1,041 |  |  | 112 |  |  | 147 |  |  | 11.5 | % |  | 14.1 | % |
| Fire & Security |  | 932 |  |  | 887 |  |  | (157) |  |  | 134 |  |  | (16.8) | % |  | 15.1 | % |
| Total segment |  | $ | 6,120 |  |  | $ | 5,316 |  |  | $ | 697 |  |  | $ | 866 |  |  | 11.4 | % |  | 16.3 | % |

[0001783180-23-000056:mdna:89]
[same as prior period, unchanged from 0001783180-23-000038:mdna:55]

[0001783180-23-000056:mdna:90]
For the three months ended June 30, 2023, Net sales in our HVAC segment were $4.2 billion, a 24% increase compared with the same period of 2022. The components of the year-over-year change were as follows:

[0001783180-23-000056:mdna:91]
|  |  | Net Sales |
| Organic |  | 9 | % |
| Foreign currency translation |  | (1) | % |
| Acquisitions and divestitures, net |  | 16 | % |
| Total % change in Net sales |  | 24 | % |

[0001783180-23-000056:mdna:92]
The organic increase in Net sales of 9% was driven by continued strong results in the segment. Increased sales in our Commercial HVAC business (up 19%) benefited from pricing improvements and ongoing customer demand in our end-markets. The business saw strong growth in North America and continued improvements in Asia after COVID-19 related lockdowns. Growth in Europe moderated as economic conditions and inflationary cost pressures impacted end-market demand. Higher sales in our North America residential and light commercial business (up 5%) were primarily driven by pricing improvements and improved mix associated with regulatory changes effective as of the beginning of 2023. These amounts were partially offset by volume reductions in North America residential end-markets. Results in our Global Comfort Solutions business (down 10%) were primarily driven by lower demand in certain European end-markets.

[0001783180-23-000056:mdna:93]
On August 1, 2022, the Commercial HVAC business acquired a majority ownership interest in TCC, a VRF and light commercial HVAC joint venture between Carrier and Toshiba Corporation. The results of TCC have been included in our Unaudited Condensed Consolidated Financial Statements since the date of acquisition. The transaction added 16% to Net sales during the three months ended June 30, 2023 and is included in Acquisitions and divestitures, net.

[0001783180-23-000056:mdna:94]
For the three months ended June 30, 2023, Operating profit in our HVAC segment was $0.7 billion, a 27% increase compared with the same period of 2022. The components of the year-over-year change were as follows:

[0001783180-23-000056:mdna:95]
|  |  | Operating Profit |
| Operational |  | 13 | % |
| Acquisitions and divestitures, net |  | 16 | % |
| Amortization of acquired intangibles |  | (5) | % |
| Other |  | 3 | % |
| Total % change in Operating profit |  | 27 | % |

[0001783180-23-000056:mdna:96]
The operational profit increase of 13% was primarily attributable to pricing improvements and ongoing customer demand in certain end-markets compared with the prior year. These benefits more than offset the higher costs for commodities and components used in our products and freight and logistics costs. Lower earnings from equity method investments impacted operational profit due to the increase in our ownership interest in TCC on August 1, 2022. As a result, TCC is no longer accounted for under the equity method of accounting since the date of acquisition. Inflationary cost pressures have begun to moderate, but continue to impact our operating profit.

[0001783180-23-000056:mdna:97]
[same as prior period, unchanged from 0001783180-23-000038:mdna:64]

[0001783180-23-000056:mdna:98]
For the three months ended June 30, 2023, Net sales in our Refrigeration segment were $972 million, a 7% decrease compared with the same period of 2022. The components of the year-over-year change were as follows:

[0001783180-23-000056:mdna:99]
|  |  | Net Sales |
| Organic |  | (6) | % |
| Foreign currency translation |  | — | % |
| Acquisitions and divestitures, net |  | (1) | % |
| Total % change in Net sales |  | (7) | % |

[0001783180-23-000056:mdna:100]
Organic Net sales decrease 6% compared to the prior year as each of the segment's businesses experienced challenges in certain end-markets during the period. Results for Commercial refrigeration decreased (down 19%) compared with the prior year, primarily driven by lower volumes in Europe as economic conditions and inflationary cost pressures impacted end-market demand. In addition, lower volumes in Asia were partially offset by pricing improvements. Transport refrigeration sales were flat compared to the prior year as pricing improvements and strong end-market demand in the U.S. and Europe were offset by continued weakness in container end-markets.

[0001783180-23-000056:mdna:101]
For the three months ended June 30, 2023, Operating profit in our Refrigeration segment was $112 million, a 24% decrease compared with the same period of 2022. The components of the year-over-year change were as follows:

[0001783180-23-000056:mdna:102]
|  |  | Operating Profit |
| Operational |  | (22) | % |
| Foreign currency translation |  | — | % |
| Acquisitions and divestitures, net |  | (1) | % |
| Restructuring |  | (1) | % |
| Total % change in Operating profit |  | (24) | % |

[0001783180-23-000056:mdna:103]
The decrease in operational profit of 22% was primarily driven by volume reductions in certain end-markets compared with the prior year. In addition, the higher costs of commodities and components used in our products further impacted segment results. These amounts were partially offset by pricing improvements and favorable productivity initiatives during the period. Inflationary cost pressures have begun to moderate, but continue to impact our operating profit.

[0001783180-23-000056:mdna:104]
[same as prior period, unchanged from 0001783180-23-000038:mdna:71]

[0001783180-23-000056:mdna:105]
For the three months ended June 30, 2023, Net sales in our Fire & Security segment were $932 million, a 5% increase compared with the same period of 2022. The components of the year-over-year change were as follows:

[0001783180-23-000056:mdna:106]
|  |  | Net Sales |
| Organic |  | 9 | % |
| Foreign currency translation |  | (1) | % |
| KFI deconsolidation |  | (3) | % |
| Total % change in Net sales |  | 5 | % |

[0001783180-23-000056:mdna:107]
The organic increase in Net sales of 9% was primarily driven by pricing improvements and volume growth compared with the prior year. Sales grew in all three regions including strong commercial and residential results in the Americas. Growth in Europe moderated as economic conditions and inflationary cost pressures impacted end-market demand. Results in Asia normalized after a strong COVID-19 related recovery. Global industrial sales benefited segment results due to pricing improvements and strong demand. The segment continues to be impacted by ongoing supply chain constraints for certain components used in our products.

[0001783180-23-000056:mdna:108]
For the three months ended June 30, 2023, Operating profit in our Fire & Security segment was a loss of  $157 million, a 217% decrease compared with the same period of 2022. The components of the year-over-year change were as follows:

[0001783180-23-000056:mdna:109]
|  |  | Operating Profit |
| Operational |  | 10 | % |
| Foreign currency translation |  | (2) | % |
| Restructuring |  | 3 | % |
| KFI deconsolidation |  | (228) | % |
| Total % change in Operating profit |  | (217) | % |

[0001783180-23-000056:mdna:110]
The increase in operational profit of 10% was primarily driven by pricing improvements, volume growth and lower freight and logistics costs compared to the prior year. These amounts were partially offset by the higher costs of commodities and components used in our products. In addition, higher inventory-related reserves resulting from supply chain constraints further impacted segment results. Inflationary cost pressures have moderated, but continue to impact our operating profit.

[0001783180-23-000056:mdna:111]
As of May 14, 2023, we no longer control KFI as their activities are subject to review and oversight by the bankruptcy court. Therefore, KFI was deconsolidated and their respective assets and liabilities were derecognized from our Unaudited Condensed Consolidated Financial Statements. As a result, we recognized a loss on deconsolidation of $293 million during the three months ended June 30, 2023.

[0001783180-23-000056:mdna:112]
Six Months Ended June 30, 2023 Compared with Six Months Ended June 30, 2022

[0001783180-23-000056:mdna:113]
| Summary performance for each of our segments is as follows: |
|  | Net Sales |  | Operating Profit |  | Operating Profit Margin |
|  | Six Months Ended June 30, |  | Six Months Ended June 30, |  | Six Months Ended June 30, |
| (In millions) | 2023 |  | 2022 |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| HVAC | $ | 7,838 |  |  | $ | 6,358 |  |  | $ | 1,177 |  |  | $ | 1,055 |  |  | 15.0 | % |  | 16.6 | % |
| Refrigeration | 1,870 |  |  | 2,017 |  |  | 220 |  |  | 254 |  |  | 11.8 | % |  | 12.6 | % |
| Fire & Security | 1,801 |  |  | 1,705 |  |  | (64) |  |  | 1,352 |  |  | (3.6) | % |  | 79.3 | % |
| Total segment | $ | 11,509 |  |  | $ | 10,080 |  |  | $ | 1,333 |  |  | $ | 2,661 |  |  | 11.6 | % |  | 26.4 | % |

[0001783180-23-000056:mdna:114]
HVAC Segment

[0001783180-23-000056:mdna:115]
For the six months ended June 30, 2023, Net sales in our HVAC segment were $7.8 billion, a 23% increase compared with the same period of 2022. The components of the year-over-year change were as follows:

[0001783180-23-000056:mdna:116]
|  |  | Net Sales |
| Organic |  | 7 | % |
| Foreign currency translation |  | (1) | % |
| Acquisitions and divestitures, net |  | 17 | % |
| Total % change in Net sales |  | 23 | % |

[0001783180-23-000056:mdna:117]
The organic increase in Net sales of 7% was driven by continued strong results in the segment. Increased sales in our Commercial HVAC business (up 16%) benefited from pricing improvements and ongoing customer demand in our end-markets. The business saw strong growth in all regions including Europe and Asia as current economic conditions and inflationary cost pressures moderated from the prior year. Higher sales in our North America residential and light commercial business (up 2%) were primarily driven by pricing improvements and improved mix associated with regulatory changes effective as of the beginning of 2023. These amounts were partially offset by volume reductions in North America residential end-markets. In addition, increased sales in our Global Comfort Solutions business (up 1%) were primarily driven by growth in Asia partially offset by lower demand in certain European end-markets.

[0001783180-23-000056:mdna:118]
On August 1, 2022, the Commercial HVAC business acquired a majority ownership interest in TCC, a VRF and light commercial HVAC joint venture between Carrier and Toshiba Corporation. The results of TCC have been included in our Unaudited Condensed Consolidated Financial Statements since the date of acquisition. The transaction added 17% to Net sales during the six months ended June 30, 2023 and is included in Acquisitions and divestitures, net.

[0001783180-23-000056:mdna:119]
For the six months ended June 30, 2023, Operating profit in our HVAC segment was $1.2 billion, a 12% increase compared with the same period of 2022. The components of the year-over-year change were as follows:

[0001783180-23-000056:mdna:120]
|  |  |  | Operating Profit |
| Operational |  |  | 4 | % |
| Foreign currency translation |  |  | (1) | % |
| Acquisitions and divestitures, net |  |  | 13 | % |
| Amortization of acquired intangibles |  |  | (6) | % |
| Other |  |  | 2 | % |
| Total % change in Operating profit |  |  | 12 | % |

[0001783180-23-000056:mdna:121]
The operational profit increase of 4% was primarily attributable to pricing improvements and ongoing customer demand in certain end-markets compared with the prior year. These benefits more than offset the higher costs for commodities and components used in our products and freight and logistics costs. Lower earnings from equity method investments impacted operational profit due to the increase in our ownership interest in TCC on August 1, 2022. As a result, TCC is no longer accounted for under the equity method of accounting since the date of acquisition. Inflationary cost pressures have begun to moderate, but continue to impact our operating profit.

[0001783180-23-000056:mdna:122]
40

[0001783180-23-000056:mdna:123]
Refrigeration Segment

[0001783180-23-000056:mdna:124]
For the six months ended June 30, 2023, Net sales in our Refrigeration segment were $1.9 billion, a 7% decrease compared with the same period of 2022. The components of the year-over-year change were as follows:

[0001783180-23-000056:mdna:125]
|  |  | Net Sales |
| Organic |  | (5) | % |
| Foreign currency translation |  | (1) | % |
| Acquisitions and divestitures, net |  | (1) | % |
| Total % change in Net sales |  | (7) | % |

[0001783180-23-000056:mdna:126]
Organic Net sales decreased 5% compared to the prior year as each of the segment's businesses experienced challenges in certain end-markets during the period. Results for Commercial refrigeration decreased (down 17%) compared with the prior year, primarily driven by lower volumes in Europe as economic conditions and inflationary cost pressures impacted end-market demand. In addition, lower volumes in Asia were partially offset by pricing improvements. Transport refrigeration sales were flat compared to the prior year as pricing improvements and strong end-market demand in the U.S. and Europe offset continued weakness in container end-markets.

[0001783180-23-000056:mdna:127]
For the six months ended June 30, 2023, Operating profit in our Refrigeration segment was $220 million, a 13% decrease  compared with the same period of 2022. The components of the year-over-year change were as follows:

[0001783180-23-000056:mdna:128]
|  |  |  | Operating Profit |
| Operational |  |  | (20) | % |
| Foreign currency translation |  |  | (1) | % |
| Restructuring |  |  | (2) | % |
| Other |  |  | 10 | % |
| Total % change in Operating profit |  |  | (13) | % |

[0001783180-23-000056:mdna:129]
The decrease in operational profit of 20% was primarily driven by volume reductions in certain end-markets compared with the prior year. In addition, the higher costs of commodities and components used in our products further impacted segment results. These amounts were partially offset by pricing improvements, favorable productivity initiatives and lower selling, general and administrative costs. Inflationary cost pressures have begun to moderate, but continue to impact our operating profit. Amounts reported in Other represent a $24 million gain on the sale of a business within Transport refrigeration.

[0001783180-23-000056:mdna:130]
Fire & Security Segment

[0001783180-23-000056:mdna:131]
For the six months ended June 30, 2023, Net sales in our Fire & Security segment were $1.8 billion, a 6% increase compared with the same period of 2022. The components of the year-over-year change were as follows:

[0001783180-23-000056:mdna:132]
|  |  | Net Sales |
| Organic |  | 9 | % |
| Foreign currency translation |  | (2) | % |
| KFI deconsolidation |  | (1) | % |
| Total % change in Net sales |  | 6 | % |

[0001783180-23-000056:mdna:133]
The organic increase in Net sales of 9% was primarily driven by pricing improvements and volume growth compared with the prior year. Sales grew in all three regions including strong commercial and residential results in the Americas. Growth in Europe moderated as economic conditions and inflationary cost pressures impacted end-market demand. Results in Asia normalized after a strong COVID-19 related recovery. Global industrial sales benefited segment results due to pricing improvements and strong demand. The segment continues to be impacted by ongoing supply chain constraints for certain components used in our products.

[0001783180-23-000056:mdna:134]
For the six months ended June 30, 2023, Operating profit in our Fire & Security segment was a loss of $64 million, a 105% decrease compared with the same period of 2022. The components of the year-over-year change were as follows:

[0001783180-23-000056:mdna:135]
|  |  | Operating Profit |
| Operational |  | 1 | % |
| Foreign currency translation |  | (1) | % |
| KFI deconsolidation |  | (23) | % |
| Chubb gain |  | (82) | % |
| Total % change in Operating profit |  | (105) | % |

[0001783180-23-000056:mdna:136]
The increase in operational profit of 1% was primarily driven by pricing improvements, volume growth and lower freight and logistics costs compared to the prior year. These amounts were offset by the higher costs of commodities and components used in our products. In addition, higher inventory-related reserves resulting from supply chain challenges further impacted segment results. Inflationary cost pressures have moderated, but continue to impact our operating profit.

[0001783180-23-000056:mdna:137]
As of May 14, 2023, we no longer control KFI as their activities are subject to review and oversight by the bankruptcy court. Therefore, KFI was deconsolidated and their respective assets and liabilities were derecognized from our Unaudited Condensed Consolidated Financial Statements. As a result, we recognized a loss on deconsolidation of $293 million during the six months ended June 30, 2023.

[0001783180-23-000056:mdna:138]
[same as prior period, unchanged from 0001783180-23-000038:mdna:78]

[0001783180-23-000056:mdna:139]
[same as prior period, unchanged from 0001783180-23-000038:mdna:79]

[0001783180-23-000056:mdna:140]
As of June 30, 2023, we had cash and cash equivalents of $3.2 billion, of which approximately 45% was held by our foreign subsidiaries. We manage our worldwide cash requirements by reviewing available funds and the cost effectiveness with which we can access funds held by foreign subsidiaries. On occasion, we are required to maintain cash deposits in connection with contractual obligations related to acquisitions, divestitures or other legal obligations. As of June 30, 2023 and December 31, 2022, the amount of such restricted cash was approximately $7 million and $39 million, respectively.

[0001783180-23-000056:mdna:141]
We maintain a $2.0 billion unsecured, unsubordinated commercial paper program which can be used for general corporate purposes, including the funding of working capital and potential acquisitions. In addition, we maintain a $2.0 billion revolving credit agreement with various banks (the "Revolving Credit Facility") that matures in May 2028 which supports our commercial paper borrowing program and can be used for other general corporate purposes. A ratings-based commitment fee is charged on unused commitments. As of June 30, 2023, we had no borrowings outstanding under our commercial paper program and our Revolving Credit Facility.

[0001783180-23-000056:mdna:142]
[same as prior period, unchanged from 0001783180-23-000038:mdna:83]

[0001783180-23-000056:mdna:143]
[same as prior period, unchanged from 0001783180-23-000038:mdna:84]

[0001783180-23-000056:mdna:144]
[same as prior period, unchanged from 0001783180-23-000038:mdna:85]

[0001783180-23-000056:mdna:145]
| (In millions) |  | June 30,2023 |  | December 31,2022 |
| Cash and cash equivalents |  | $ | 3,209 |  |  | $ | 3,520 |  |
| Total debt |  | $ | 8,789 |  |  | $ | 8,842 |  |
| Total equity |  | $ | 8,288 |  |  | $ | 8,076 |  |
| Net debt (total debt less cash and cash equivalents) |  | $ | 5,580 |  |  | $ | 5,322 |  |
| Total capitalization (total debt plus total equity) |  | $ | 17,077 |  |  | $ | 16,918 |  |
| Net capitalization (total debt plus total equity less cash and cash equivalents) |  | $ | 13,868 |  |  | $ | 13,398 |  |
| Total debt to total capitalization |  | 51 | % |  | 52 | % |
| Net debt to net capitalization |  | 40 | % |  | 40 | % |

[0001783180-23-000056:mdna:146]
[same as prior period, unchanged from 0001783180-23-000038:mdna:87]

[0001783180-23-000056:mdna:147]
Our short-term obligations primarily consist of current maturities of long-term debt. Our long-term obligations primarily consist of long-term notes with maturity dates ranging between 2025 and 2050. Interest payments related to long-term Notes are expected to approximate $249 million per year, reflecting an approximate weighted-average interest rate of 2.86%. Any borrowings from the Revolving Credit Facility are subject to variable interest rates. See Note 5 – Borrowings and Lines of Credit in the Notes to the accompanying Unaudited Condensed Consolidated Financial Statements for additional information regarding the terms of our long-term debt obligations.

[0001783180-23-000056:mdna:148]
On March 15, 2022, we commenced tender offers to repurchase up to $1.15 billion aggregate principal of our 2.242% Notes due 2025 and 2.493% Notes due 2027 (together, the "Senior Notes"). The tender offers included payment of applicable accrued and unpaid interest up to the settlement date, along with a fixed spread for early repayment. Based on participation, we elected to settle the tender offers on March 30, 2022. The aggregate principal amount of Senior Notes validly tendered and accepted was approximately $1.15 billion and included $800 million of Notes due 2025 and $350 million of Notes due 2027. Upon settlement, we recognized a net gain of $33 million and wrote off $5 million of unamortized deferred financing costs during the three months ended March 31, 2022.

[0001783180-23-000056:mdna:149]
On July 15, 2022, we entered into a five-year, JPY 54 billion (approximately $400 million) senior unsecured term loan facility with MUFG Bank Ltd., as administrative agent and lender, and certain other lenders (the "Japanese Term Loan Facility"). Borrowings bear interest at a rate equal to the Tokyo Term Risk Free Rate plus 0.75%. In addition, it is subject to customary covenants including a covenant to maintain a maximum consolidated leverage ratio. On July 25, 2022, we borrowed JPY 54 billion under the Japanese Term Loan Facility and used the proceeds to fund a portion of the TCC acquisition and to pay related fees and expenses.

[0001783180-23-000056:mdna:150]
The Revolving Credit Facility, the Japanese Term Loan Facility and the indentures for the long-term notes contain affirmative and negative covenants customary for financings of these types, which among other things, limit our ability to incur additional liens, to make certain fundamental changes and to enter into sale and leaseback transactions. As of June 30, 2023, we were compliant with the covenants under the agreements governing our outstanding indebtedness.

[0001783180-23-000056:mdna:151]
The following table presents our credit ratings and outlook as of June 30, 2023:

[0001783180-23-000056:mdna:152]
| Rating Agency |  | Long-term Rating (1) |  | Short-term Rating |  | Outlook (2) (3) |
| Standards & Poor's ("S&P") |  | BBB |  | A2 |  | Stable |
| Moody's Investors Service Inc. ("Moody's") |  | Baa3 |  | P3 |  | Positive |
| Fitch Ratings ("Fitch") |  | BBB- |  | F3 |  | Stable |

[0001783180-23-000056:mdna:153]
[same as prior period, unchanged from 0001783180-23-000038:mdna:95]

[0001783180-23-000056:mdna:154]
(2) S&P revised its outlook to stable from positive on April 25, 2023.

[0001783180-23-000056:mdna:155]
[same as prior period, unchanged from 0001783180-23-000038:mdna:97]

[0001783180-23-000056:mdna:156]
Planned Portfolio Transformation

[0001783180-23-000056:mdna:157]
On April 25, 2023, we announced that we entered into an Agreement to acquire the VCS Business for approximately €12 billion. Under the terms of the Agreement, 20% of the purchase price will be paid in Carrier common stock, issued directly to Viessmann and subject to long-term lock-up provisions, and 80% will be paid in cash. We intend to finance the acquisition with a combination of cash on hand and new debt financing and expect the transaction to close around the end of 2023. In addition, we also announced plans to exit our Fire & Security and Commercial Refrigeration businesses over the course of 2024.

[0001783180-23-000056:mdna:158]
In connection with the planned acquisition, we entered into commitment letters with JPMorgan Chase Bank, N.A., BofA Securities, Inc. and Bank of America, N.A. to provide an €8.2 billion Bridge Loan. Proceeds from the Bridge Loan are expected to be used to fund a portion of the Euro-denominated purchase price of the Business if other debt financing is not secured by the acquisition date. On May 19, 2023, the aggregate principal amount of the Bridge Loan was reduced by €2.3 billion upon entering into a senior unsecured delayed draw term loan credit agreement.

[0001783180-23-000056:mdna:159]
On May 19, 2023, we entered into a senior unsecured delayed draw term loan credit agreement with JPMorgan Chase Bank, N.A., as administrative agent and certain other lenders that permits aggregate borrowings of up to €2.3 billion (the "Delayed Draw Facility"). Proceeds from the Delayed Draw Facility are expected to be used to fund a portion of the Euro-denominated purchase price of the Business. In addition, we entered into a 364-day, $500 million, senior unsecured revolving credit agreement with JPMorgan Chase Bank, N.A., as administrative agent and certain other lenders (the "Revolver") on May 19, 2023. Proceeds from the Revolver become available upon closing the purchase of the Business.

[0001783180-23-000056:mdna:160]
[same as prior period, unchanged from 0001783180-23-000038:mdna:98]

[0001783180-23-000056:mdna:161]
[same as prior period, unchanged from 0001783180-23-000038:mdna:99]

[0001783180-23-000056:mdna:162]
During the three months ended June 30, 2023, we did not repurchase any shares of common stock. During the six months ended June 30, 2023, we repurchased 1.4 million shares of common stock for an aggregate purchase price of $62 million. As a result, we have approximately $2.1 billion remaining under the current authorization at June 30, 2023.

[0001783180-23-000056:mdna:163]
[same as prior period, unchanged from 0001783180-23-000038:mdna:101]

[0001783180-23-000056:mdna:164]
We paid dividends on common stock during the six months ended June 30, 2023, totaling $309 million. In June 2023, the Board of Directors declared a dividend of $0.185 per share of common stock payable on August 10, 2023 to shareowners of record at the close of business on June 23, 2023.

[0001783180-23-000056:mdna:165]
[same as prior period, unchanged from 0001783180-23-000038:mdna:103]

[0001783180-23-000056:mdna:166]
|  |  | Six Months Ended June 30, |
| (In millions) |  | 2023 |  | 2022 |
| Net cash flows provided by (used in): |  |  |  |  |
| Operating activities |  | $ | 504 |  |  | $ | (170) |  |
| Investing activities |  | (296) |  |  | 2,645 |  |
| Financing activities |  | (506) |  |  | (2,434) |  |
| Effect of foreign exchange rate changes on cash and cash equivalents |  | (13) |  |  | (41) |  |
| Net increase (decrease) in cash and cash equivalents and restricted cash |  | $ | (311) |  |  | $ | — |  |

[0001783180-23-000056:mdna:167]
Cash flows from operating activities primarily represent inflows and outflows associated with our operations. Primary activities include net income from operations adjusted for non-cash transactions, working capital changes and changes in other assets and liabilities. The year-over-year increase in net cash provided by operating activities was primarily driven by a more moderate

[0001783180-23-000056:mdna:168]
increase in working capital balances compared with the prior period. Prior year working capital balances increased due to higher safety stock and supply chain constraints.

[0001783180-23-000056:mdna:169]
Cash flows from investing activities primarily represent inflows and outflows associated with long-term assets. Primary activities include capital expenditures, acquisitions, divestitures and proceeds from the sale of fixed assets. During the six months ended June 30, 2023, net cash used in investing activities was $296 million. The primary drivers of the outflow related to $144 million of capital expenditures and $134 million related to the deconsolidation of KFI. In addition, we settled working capital and other transaction-related items associated with the acquisition of TCC and invested in several businesses. These amounts totaled $56 million, net of cash acquired and were partially offset by the proceeds from the sale of a business during the period. During the six months ended June 30, 2022, net cash provided by investing activities was $2.6 billion. The primary driver of the inflow related to the net proceeds from the Chubb Sale. This amount was partially offset by the acquisition of several businesses and minority-owned businesses, which totaled $38 million, net of cash acquired and $122 million of capital expenditures.

[0001783180-23-000056:mdna:170]
Cash flows from financing activities primarily represent inflows and outflows associated with equity or borrowings. During the six months ended June 30, 2023, net cash used in financing activities was $506 million. The primary driver of the outflow related to the payment of $309 million in dividends to our common shareowners. In addition, we paid $62 million to repurchase shares of our common stock. During the six months ended June 30, 2022, net cash used in financing activities was $2.4 billion. The primary driver of the outflow related to the settlement of our tender offers for $1.15 billion. In addition, we paid $257 million in dividends to our common shareowners and paid $1.0 billion to repurchase shares of our common stock.
