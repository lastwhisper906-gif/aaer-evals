# CARR notes — 0001783180-23-000056


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001783180-23-000056:notes:1]
DESCRIPTION OF THE BUSINESS 
Carrier Global Corporation (the "Company") is a global leader in intelligent climate and energy solutions with a focus on providing differentiated, digitally-enabled lifecycle solutions to its customers. The Company's portfolio includes industry-leading brands such as Carrier, Toshiba, Automated Logic, Carrier Transicold, Kidde, Edwards and LenelS2 that offer innovative heating, ventilating, air conditioning ("HVAC"), refrigeration, fire, security and building automation technologies to help make the world safer and more comfortable. The Company also provides a broad array of related building services, including audit, design, installation, system integration, repair, maintenance and monitoring. The Company's operations are classified into three segments: HVAC, Refrigeration and Fire & Security.

[0001783180-23-000056:notes:2]
[same as prior period, unchanged from 0001783180-23-000038:notes:2]


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001783180-23-000056:notes:3]
BASIS OF PRESENTATION
The Unaudited Condensed Consolidated Financial Statements include all accounts of the Company and its wholly-owned and majority-owned subsidiaries in which it has control. Inter-company accounts and transactions have been eliminated. Related party transactions between the Company and its equity method investees have not been eliminated. Non-controlling interest represents a non-controlling investor's interests in the results of subsidiaries that the Company controls and consolidates.

[0001783180-23-000056:notes:4]
Planned Portfolio Transformation

[0001783180-23-000056:notes:5]
On April 25, 2023, the Company announced that it entered into a Share Purchase Agreement (the “Agreement”) to acquire the climate solutions business (the "VCS Business") of Viessmann Group GmbH & Co. KG (“Viessmann”), a privately-held company, for approximately €12 billion. The VCS Business develops intelligent, integrated and sustainable technologies, including heat pumps, boilers, photovoltaic systems, home battery storage and digital solutions, primarily for residential customers in Europe. The transaction is expected to close around the end of 2023, subject to customary closing conditions and regulatory approvals. In addition, the Company also announced plans to exit its Fire & Security and Commercial Refrigeration businesses over the course of 2024. See Note 15 – Acquisitions and Note 16 - Divestitures for additional information.

[0001783180-23-000056:notes:6]
Deconsolidation of Kidde-Fenwal, Inc.

[0001783180-23-000056:notes:7]
On May 14, 2023, Kidde-Fenwal, Inc. ("KFI") filed a petition for voluntary reorganization under Chapter 11 of the United States Bankruptcy Code ("Chapter 11") in the United States Bankruptcy Court for the District of Delaware. KFI, an industrial fire detection and suppression business and an indirect wholly-owned subsidiary of the Company, has indicated that it intends to use the bankruptcy process to explore strategic alternatives, including the sale of KFI as a going concern. KFI has further stated that, during the Chapter 11 process, KFI expects that there will be no significant interruptions to its business operations. As of the petition date, KFI was deconsolidated and its respective assets and liabilities were derecognized from the Company's Unaudited Condensed Consolidated Financial Statements. See Note 19 - Commitments and Contingent Liabilities for additional information.

[0001783180-23-000056:notes:8]
[same as prior period, unchanged from 0001783180-23-000038:notes:4]

[0001783180-23-000056:notes:9]
On February 6, 2022, the Company entered into a binding agreement to acquire a majority ownership interest in Toshiba Carrier Corporation (“TCC”), a variable refrigerant flow ("VRF") and light commercial HVAC joint venture between Carrier and Toshiba Corporation. The acquisition was completed on August 1, 2022. As a result, the assets, liabilities and results of operations of TCC are consolidated in the accompanying Unaudited Condensed Consolidated Financial Statements as of the

[0001783180-23-000056:notes:10]
date of acquisition and reported within the Company’s HVAC segment. Upon closing, Toshiba Corporation retained a 5% ownership interest in TCC. See Note 15 – Acquisitions for additional information.

[0001783180-23-000056:notes:11]
[same as prior period, unchanged from 0001783180-23-000038:notes:6]

[0001783180-23-000056:notes:12]
[same as prior period, unchanged from 0001783180-23-000038:notes:7]

[0001783180-23-000056:notes:13]
[same as prior period, unchanged from 0001783180-23-000038:notes:8]

[0001783180-23-000056:notes:14]
On April 3, 2020 (the Distribution Date"), United Technologies Corporation ("UTC"), since renamed RTX Corporation ("Raytheon Technologies Corporation" or "RTX"), completed the spin-off of Carrier into an independent, publicly traded company (the "Separation") through a pro-rata distribution (the "Distribution") on a one-for-one basis of all of the outstanding shares of common stock of Carrier to UTC shareowners who held shares of UTC common stock as of the close of business on March 19, 2020, the record date of the Distribution. In connection with the Separation, the Company issued an aggregate principal balance of $11.0 billion of debt and transferred approximately $10.9 billion of cash to UTC on February 27, 2020 and March 27, 2020. On April 1, 2020 and April 2, 2020, the Company received cash contributions totaling $590 million from UTC related to the Separation.

[0001783180-23-000056:notes:15]
[same as prior period, unchanged from 0001783180-23-000038:notes:10]

[0001783180-23-000056:notes:16]
The Financial Accounting Standards Board ("FASB") Accounting Standards Codification ("ASC") is the sole source of authoritative U.S. GAAP other than SEC issued rules and regulations that apply only to SEC registrants. The FASB issues Accounting Standards Updates ("ASU") to communicate changes to the codification. The Company considers the applicability and impact of all ASUs. ASUs pending adoption were assessed and determined to be either not applicable or are not expected to have a material impact on the accompanying Unaudited Condensed Consolidated Financial Statements.


## us-gaap:InventoryDisclosureTextBlock

[0001783180-23-000056:notes:17]
[same as prior period, unchanged from 0001783180-23-000038:notes:12]

[0001783180-23-000056:notes:18]
[same as prior period, unchanged from 0001783180-23-000038:notes:13]

[0001783180-23-000056:notes:19]
| (In millions) |  | June 30,2023 |  | December 31,2022 |
| Raw materials |  | $ | 841 |  |  | $ | 884 |  |
| Work-in-process |  | 291 |  |  | 230 |  |
| Finished goods |  | 1,567 |  |  | 1,526 |  |
| Inventories, net |  | $ | 2,699 |  |  | $ | 2,640 |  |

[0001783180-23-000056:notes:20]
The Company performs periodic assessments utilizing customer demand, production requirements and historical usage rates to determine the existence of excess and obsolete inventory and records necessary provisions to reduce such inventories to the lower of cost or estimated net realizable value. Raw materials, work-in-process and finished goods are net of valuation reserves of $241 million and $190 million as of June 30, 2023 and December 31, 2022, respectively.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001783180-23-000056:notes:21]
GOODWILL AND INTANGIBLE ASSETS The Company records goodwill as the excess of the purchase price over the fair value of the net assets acquired in a business combination. Goodwill is tested and reviewed annually for impairment on July 1 or whenever there is a material change in events or circumstances that indicates that the fair value of the reporting unit may be less than its carrying value. 
The changes in the carrying amount of goodwill were as follows:

[0001783180-23-000056:notes:22]
| (In millions) |  |  | HVAC |  | Refrigeration |  | Fire & Security |  | Total |
| Balance as of December 31, 2022 |  |  | $ | 6,392 |  |  | $ | 1,197 |  |  | $ | 2,388 |  |  | $ | 9,977 |  |
| Acquisitions / divestitures |  |  | (11) |  |  | (4) |  |  | — |  |  | (15) |  |
| Foreign currency translation |  |  | (22) |  |  | (4) |  |  | (9) |  |  | (35) |  |
| Balance as of June 30, 2023 |  |  | $ | 6,359 |  |  | $ | 1,189 |  |  | $ | 2,379 |  |  | $ | 9,927 |  |

[0001783180-23-000056:notes:23]
[same as prior period, unchanged from 0001783180-23-000038:notes:19]

[0001783180-23-000056:notes:24]
[same as prior period, unchanged from 0001783180-23-000038:notes:20]

[0001783180-23-000056:notes:25]
|  |  | June 30, 2023 |  | December 31, 2022 |
| (In millions) |  | Gross Amount |  | Accumulated Amortization |  | Net Amount |  | Gross Amount |  | Accumulated Amortization |  | Net Amount |
| Amortized: |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 1,408 |  |  | $ | (754) |  |  | $ | 654 |  |  | $ | 1,431 |  |  | $ | (720) |  |  | $ | 711 |  |
| Patents and trademarks |  | 388 |  |  | (202) |  |  | 186 |  |  | 401 |  |  | (191) |  |  | 210 |  |
| Service portfolios and other |  | 932 |  |  | (655) |  |  | 277 |  |  | 953 |  |  | (595) |  |  | 358 |  |
|  |  | 2,728 |  |  | (1,611) |  |  | 1,117 |  |  | 2,785 |  |  | (1,506) |  |  | 1,279 |  |
| Unamortized: |  |  |  |  |  |  |  |  |  |  |  |  |
| Trademarks and other |  | 64 |  |  | — |  |  | 64 |  |  | 63 |  |  | — |  |  | 63 |  |
| Intangible assets, net |  | $ | 2,792 |  |  | $ | (1,611) |  |  | $ | 1,181 |  |  | $ | 2,848 |  |  | $ | (1,506) |  |  | $ | 1,342 |  |

[0001783180-23-000056:notes:26]
[same as prior period, unchanged from 0001783180-23-000038:notes:22]

[0001783180-23-000056:notes:27]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
| (In millions) |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Amortization expense of Intangible assets |  | $ | 61 |  |  | $ | 20 |  |  | $ | 125 |  |  | $ | 41 |  |


## us-gaap:DebtDisclosureTextBlock

[0001783180-23-000056:notes:28]
BORROWINGS AND LINES OF CREDIT 
Long-term debt consisted of the following:

[0001783180-23-000056:notes:29]
| (In millions) |  |  |  | June 30,2023 |  | December 31,2022 |
| 2.242% Notes due February 15, 2025 |  |  |  | $ | 1,200 |  |  | $ | 1,200 |  |
| 2.493% Notes due February 15, 2027 |  |  |  | 900 |  |  | 900 |  |
| 2.722% Notes due February 15, 2030 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.700% Notes due February 15, 2031 |  |  |  | 750 |  |  | 750 |  |
| 3.377% Notes due April 5, 2040 |  |  |  | 1,500 |  |  | 1,500 |  |
| 3.577% Notes due April 5, 2050 |  |  |  | 2,000 |  |  | 2,000 |  |
| Total long-term notes |  |  |  | 8,350 |  |  | 8,350 |  |
| Japanese Term Loan Facility |  |  |  | 374 |  |  | 404 |  |
| Other debt (including project financing obligations and finance leases) |  |  |  | 146 |  |  | 149 |  |
| Discounts and debt issuance costs |  |  |  | (81) |  |  | (61) |  |
| Total debt |  |  |  | 8,789 |  |  | 8,842 |  |
| Less: current portion of long-term debt |  |  |  | 134 |  |  | 140 |  |
| Long-term debt, net of current portion |  |  |  | $ | 8,655 |  |  | $ | 8,702 |  |

[0001783180-23-000056:notes:30]
Japanese Term Loan Facility

[0001783180-23-000056:notes:31]
On July 15, 2022, the Company entered into a five-year, JPY 54 billion (approximately $400 million) senior unsecured term loan facility with MUFG Bank Ltd., as administrative agent and lender, and certain other lenders (the "Japanese Term Loan Facility"). Borrowings under the Japanese Term Loan Facility bear interest at a rate equal to the Tokyo Term Risk Free Rate plus 0.75%. In addition, the Japanese Term Loan Facility is subject to customary covenants including a covenant to maintain a maximum consolidated leverage ratio. The Company capitalized $2 million of deferred financing costs which are being amortized over its term. On July 25, 2022, the Company borrowed JPY 54 billion under the Japanese Term Loan Facility and used the proceeds to fund a portion of the TCC acquisition and to pay related fees and expenses.

[0001783180-23-000056:notes:32]
Revolving Credit Facility

[0001783180-23-000056:notes:33]
On May 19, 2023, the Company entered into a revolving credit agreement with JPMorgan Chase Bank, N.A., as administrative agent, and certain other lenders, permitting aggregate borrowings of up to $2.0 billion pursuant to an unsecured, unsubordinated revolving credit facility that matures in May 2028 (the "Revolving Credit Facility"). The Revolving Credit Facility supports the Company's commercial paper program and can be used for other general corporate purposes. Borrowings are available in U.S. Dollars and Euros. U.S. Dollar borrowings can bear interest at either a Term SOFR Rate plus 0.10% and a rating-based margin or, alternatively, at an alternate base rate plus a ratings-based margin. Euro borrowings bear interest at an adjusted EURIBOR rate plus a ratings-based margin. A ratings-based commitment fee is charged on unused commitments. Upon entering into the agreement, the Company terminated its existing revolving credit facility that was set to mature in April 2025. In addition, the Company capitalized $2 million of deferred financing costs which are being amortized over its term. As of June 30, 2023, there were no borrowings outstanding under the Revolving Credit Facility.

[0001783180-23-000056:notes:34]
Commercial Paper Program

[0001783180-23-000056:notes:35]
The Company has a $2.0 billion unsecured, unsubordinated commercial paper program, which can be used for general corporate purposes, including the funding of working capital and potential acquisitions. As of June 30, 2023, there were no borrowings outstanding under the commercial paper program.

[0001783180-23-000056:notes:36]
Project Financing Arrangements

[0001783180-23-000056:notes:37]
The Company is involved in long-term construction contracts in which it arranges project financing with certain customers. As a result, the Company issued $6 million and $21 million of debt during the six months ended June 30, 2023 and 2022, respectively. Long-term debt repayments associated with these financing arrangements during the six months ended June 30, 2023 and 2022 were $12 million and $12 million, respectively.

[0001783180-23-000056:notes:38]
Debt Covenants

[0001783180-23-000056:notes:39]
The Revolving Credit Facility, the indenture for the long-term notes and the Japanese Term Loan Facility contain affirmative and negative covenants customary for financings of these types, which, among other things, limit the Company's ability to incur additional liens, to make certain fundamental changes and to enter into sale and leaseback transactions. As of June 30, 2023, the Company was in compliance with the covenants under the agreements governing its outstanding indebtedness.

[0001783180-23-000056:notes:40]
Tender Offers

[0001783180-23-000056:notes:41]
On March 15, 2022, the Company commenced tender offers to purchase up to $1.15 billion ("Aggregate Tender Cap") aggregate principal of the Company's 2.242% Notes due 2025 and 2.493% Notes due 2027 (together, the "Senior Notes"). The tender offers included payment of applicable accrued and unpaid interest up to the settlement date, along with a fixed spread for early repayment. Based on participation, the Company elected to settle the tender offers on March 30, 2022. The aggregate principal amount of Senior Notes validly tendered and accepted was approximately $1.15 billion, which included $800 million of Notes due 2025 and $350 million of Notes due 2027. As a result, the Company recognized a net gain of $33 million and wrote off $5 million of unamortized deferred financing costs within Interest (expense) income, net on the accompanying Unaudited Condensed Consolidated Statement of Operations during the three months ended March 31, 2022.


## us-gaap:FairValueDisclosuresTextBlock

[0001783180-23-000056:notes:42]
[same as prior period, unchanged from 0001783180-23-000038:notes:38]

[0001783180-23-000056:notes:43]
[same as prior period, unchanged from 0001783180-23-000038:notes:39]

[0001783180-23-000056:notes:44]
[same as prior period, unchanged from 0001783180-23-000038:notes:40]

[0001783180-23-000056:notes:45]
[same as prior period, unchanged from 0001783180-23-000038:notes:41]

[0001783180-23-000056:notes:46]
[same as prior period, unchanged from 0001783180-23-000038:notes:42]

[0001783180-23-000056:notes:47]
In the normal course of business, the Company is exposed to certain risks arising from business operations and economic factors, including foreign currency and commodity price risk. These exposures are managed through operational strategies and the use of undesignated hedging contracts. The Company's derivative assets and liabilities are measured at fair value on a recurring basis using internal models based on observable market inputs, such as forward, interest, contract and discount rates with changes in fair value reported in Other income (expense), net in the accompanying Unaudited Condensed Consolidated Statement of Operations.

[0001783180-23-000056:notes:48]
In connection with the TCC acquisition, the Company funded a portion of the Yen-denominated purchase price with cash on hand by entering into cross currency swaps with SMBC Capital Markets, Inc., as syndication swap arranger, and certain other financial institutions. The cross currency swaps are measured at fair value on a recurring basis using observable market inputs, such as forward, discount and interest rates as well as credit default swap spreads. The Company designated the cross currency swaps as a partial hedge of its investment in certain subsidiaries whose functional currency is the Japanese Yen in order to manage foreign currency translation risk. As a result, changes in the fair value of the swaps are recorded in Equity in the accompanying Unaudited Condensed Consolidated Balance Sheet.

[0001783180-23-000056:notes:49]
[same as prior period, unchanged from 0001783180-23-000038:notes:45]

[0001783180-23-000056:notes:50]
In connection with the proposed acquisition of the VCS Business, the Company entered into window forward contracts with Bank of America N.A. and JPMorgan Chase Bank N.A. to mitigate the foreign currency risk of the expected cash outflows associated with the Euro-denominated purchase price. The instruments have an aggregate notional amount of €7 billion and a settlement window between November 28, 2023 and February 27, 2024. The window forward contracts are measured at fair value on a recurring basis using observable market inputs, such as forward, discount and interest rates with changes in fair value reported in Other income (expense), net in the accompanying Unaudited Condensed Consolidated Statement of Operations. During the three months ended June 30, 2023, the Company recognized a $111 million loss on the mark-to-market valuation of its window forward contracts.

[0001783180-23-000056:notes:51]
[same as prior period, unchanged from 0001783180-23-000038:notes:46]

[0001783180-23-000056:notes:52]
| (In millions) |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |
| June 30, 2023 |  |  |  |  |  |  |  |  |
| Derivative assets (1)(3) |  | $ | 18 |  |  | $ | — |  |  | $ | 18 |  |  | $ | — |  |
| Derivative liabilities (2)(3) |  | $ | (176) |  |  | $ | — |  |  | $ | (176) |  |  | $ | — |  |
| December 31, 2022 |  |  |  |  |  |  |  |  |
| Derivative assets (1) (3) |  | $ | 28 |  |  | $ | — |  |  | $ | 28 |  |  | $ | — |  |
| Derivative liabilities (2) (3) |  | $ | (48) |  |  | $ | — |  |  | $ | (48) |  |  | $ | — |  |

[0001783180-23-000056:notes:53]
[same as prior period, unchanged from 0001783180-23-000038:notes:48]

[0001783180-23-000056:notes:54]
[same as prior period, unchanged from 0001783180-23-000038:notes:49]

[0001783180-23-000056:notes:55]
(3) Includes cross currency swaps and window forward contracts.

[0001783180-23-000056:notes:56]
[same as prior period, unchanged from 0001783180-23-000038:notes:51]

[0001783180-23-000056:notes:57]
|  |  | June 30, 2023 |  | December 31, 2022 |  |
| (In millions) |  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  |
| Total long-term Notes (1) |  | $ | 8,350 |  |  | $ | 6,943 |  |  | $ | 8,350 |  |  | $ | 6,832 |  |  |

[0001783180-23-000056:notes:58]
[same as prior period, unchanged from 0001783180-23-000038:notes:53]

[0001783180-23-000056:notes:59]
The fair value of the Company's long-term debt is measured based on observable market inputs which are considered Level 1 within the fair value hierarchy. The carrying value of cash and cash equivalents, accounts receivable, accounts payable and short-term borrowings approximate fair value due to the short-term nature of these accounts and would be classified as Level 1 in the fair value hierarchy. The Company's financing leases and project financing obligations, included in Long-term debt and Current portion of long-term debt on the accompanying Unaudited Condensed Consolidated Balance Sheet, approximate fair value and are classified as Level 3 in the fair value hierarchy.


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0001783180-23-000056:notes:60]
ASC 820, Fair Value Measurement ("ASC 820"), defines fair value as the price that would be received if an asset is sold or the price paid to transfer a liability in an orderly transaction between market participants at the measurement date. ASC 820 also establishes a three-level fair value hierarchy that prioritizes information used in developing assumptions when pricing an asset or liability as follows:

[0001783180-23-000056:notes:61]
The remaining portion of the Yen-denominated purchase price was funded by the Japanese Term Loan Facility. The carrying value of the facility is translated on a recurring basis using the exchange rate at the end of the applicable period and approximates its fair value. The Company designated the Japanese Term Loan Facility as a partial hedge of its investment in certain subsidiaries whose functional currency is the Japanese Yen in order to manage foreign currency translation risk. As a result, changes in the carrying value of the Japanese Term Loan Facility associated with foreign exchange rate movements are recorded in Equity in the Unaudited Condensed Consolidated Balance Sheet.
In connection with the proposed acquisition of the VCS Business, the Company entered into window forward contracts with Bank of America N.A. and JPMorgan Chase Bank N.A. to mitigate the foreign currency risk of the expected cash outflows associated with the Euro-denominated purchase price. The instruments have an aggregate notional amount of €7 billion and a settlement window between November 28, 2023 and February 27, 2024. The window forward contracts are measured at fair value on a recurring basis using observable market inputs, such as forward, discount and interest rates with changes in fair value reported in Other income (expense), net in the accompanying Unaudited Condensed Consolidated Statement of Operations. During the three months ended June 30, 2023, the Company recognized a $111 million loss on the mark-to-market valuation of its window forward contracts.The fair value of the Company's long-term debt is measured based on observable market inputs which are considered Level 1 within the fair value hierarchy. The carrying value of cash and cash equivalents, accounts receivable, accounts payable and short-term borrowings approximate fair value due to the short-term nature of these accounts and would be classified as Level 1 in the fair value hierarchy. The Company's financing leases and project financing obligations, included in Long-term debt and Current portion of long-term debt on the accompanying Unaudited Condensed Consolidated Balance Sheet, approximate fair value and are classified as Level 3 in the fair value hierarchy.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001783180-23-000056:notes:62]
[same as prior period, unchanged from 0001783180-23-000038:notes:56]

[0001783180-23-000056:notes:63]
[same as prior period, unchanged from 0001783180-23-000038:notes:57]

[0001783180-23-000056:notes:64]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
| (In millions) |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Defined benefit plans |  | $ | 5 |  |  | $ | 2 |  |  | $ | 11 |  |  | $ | 6 |  |
| Defined contribution plans |  | $ | 29 |  |  | $ | 28 |  |  | $ | 66 |  |  | $ | 66 |  |
| Multi-employer pension plans |  | $ | 4 |  |  | $ | 3 |  |  | $ | 8 |  |  | $ | 6 |  |

[0001783180-23-000056:notes:65]
[same as prior period, unchanged from 0001783180-23-000038:notes:59]

[0001783180-23-000056:notes:66]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
| (In millions) |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Service cost |  | $ | 4 |  |  | $ | 4 |  |  | $ | 8 |  |  | $ | 9 |  |
| Interest cost |  | 8 |  |  | 4 |  |  | 16 |  |  | 8 |  |
| Expected return on plan assets |  | (8) |  |  | (6) |  |  | (16) |  |  | (13) |  |
| Amortization of prior service credit |  | 1 |  |  | — |  |  | 1 |  |  | 1 |  |
| Recognized actuarial net (gain) loss |  | (1) |  |  | 3 |  |  | (1) |  |  | 5 |  |
| Net periodic pension expense (benefit) |  | $ | 4 |  |  | $ | 5 |  |  | $ | 8 |  |  | $ | 10 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001783180-23-000056:notes:67]
[same as prior period, unchanged from 0001783180-23-000038:notes:61]

[0001783180-23-000056:notes:68]
[same as prior period, unchanged from 0001783180-23-000038:notes:62]

[0001783180-23-000056:notes:69]
[same as prior period, unchanged from 0001783180-23-000038:notes:63]

[0001783180-23-000056:notes:70]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
| (In millions) |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Equity compensation costs - equity settled |  | $ | 18 |  |  | $ | 20 |  |  | $ | 40 |  |  | $ | 41 |  |
| Equity compensation costs - cash settled (1) |  | 1 |  |  | (11) |  |  | 2 |  |  | (17) |  |
| Total stock-based compensation expense |  | $ | 19 |  |  | $ | 9 |  |  | $ | 42 |  |  | $ | 24 |  |

[0001783180-23-000056:notes:71]
[same as prior period, unchanged from 0001783180-23-000038:notes:65]


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001783180-23-000056:notes:72]
PRODUCT WARRANTIES
In the ordinary course of business, the Company provides standard warranty coverage on its products. Provisions for these amounts are established at the time of sale and estimated primarily based on product warranty terms and historical claims experience. In addition, the Company incurs discretionary costs to service its products in connection with specific product performance issues. Provisions for these amounts are established when they are known and estimable. The Company assesses the adequacy of its initial provisions and will make adjustments as necessary based on known or anticipated claims or as new information becomes available that suggests it is probable that future costs will be different than estimated amounts. Amounts associated with these provisions are classified on the accompanying Unaudited Condensed Consolidated Balance Sheet as Accrued liabilities or Other long-term liabilities based on their anticipated settlement date.

[0001783180-23-000056:notes:73]
[same as prior period, unchanged from 0001783180-23-000038:notes:67]

[0001783180-23-000056:notes:74]
|  |  | Six Months Ended June 30, |
| (In millions) |  | 2023 |  | 2022 |
| Balance as of January 1, |  | $ | 552 |  |  | $ | 524 |  |
| Warranties, performance guarantees issued and changes in estimated liability |  | 117 |  |  | 84 |  |
| Settlements made |  | (92) |  |  | (78) |  |
| Other |  | (2) |  |  | (5) |  |
| Balance as of June 30, |  | $ | 575 |  |  | $ | 525 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001783180-23-000056:notes:75]
EQUITY 
The authorized number of shares of common stock of Carrier is 4,000,000,000 shares of $0.01 par value. As of June 30, 2023 and December 31, 2022, 880,570,371 and 876,487,480 shares of common stock were issued, respectively, which includes 43,490,981 and 42,103,995 shares of treasury stock, respectively.

[0001783180-23-000056:notes:76]
[same as prior period, unchanged from 0001783180-23-000038:notes:70]

[0001783180-23-000056:notes:77]
[same as prior period, unchanged from 0001783180-23-000038:notes:71]

[0001783180-23-000056:notes:78]
During the six months ended June 30, 2023, the Company repurchased 1.4 million shares of common stock for an aggregate purchase price of $62 million. As a result, the Company has approximately $2.1 billion remaining under the current authorization at June 30, 2023.

[0001783180-23-000056:notes:79]
[same as prior period, unchanged from 0001783180-23-000038:notes:73]

[0001783180-23-000056:notes:80]
A summary of changes in the components of Accumulated other comprehensive income (loss) for the three and six months ended June 30, 2023 is as follows:

[0001783180-23-000056:notes:81]
| (In millions) |  | Foreign Currency Translation |  | Defined Benefit Pension and Post-retirement Plans |  |  |  |  |  | Accumulated Other Comprehensive Income (Loss) |
| Balance as of December 31, 2022 |  | $ | (1,604) |  |  | $ | (84) |  |  |  |  |  |  | $ | (1,688) |  |
| Other comprehensive income (loss) before reclassifications, net |  | 52 |  |  | — |  |  |  |  |  |  | 52 |  |
| Amounts reclassified, pre-tax |  | — |  |  | — |  |  |  |  |  |  | — |  |
| Tax expense (benefit) reclassified |  | — |  |  | — |  |  |  |  |  |  | — |  |
| Balance as of March 31, 2023 |  | $ | (1,552) |  |  | $ | (84) |  |  |  |  |  |  | $ | (1,636) |  |
| Other comprehensive income (loss) before reclassifications, net |  | (55) |  |  | — |  |  |  |  |  |  | (55) |  |
| Amounts reclassified, pre-tax |  | — |  |  | — |  |  |  |  |  |  | — |  |
| Tax expense (benefit) reclassified |  | — |  |  | — |  |  |  |  |  |  | — |  |
| Balance as of June 30, 2023 |  | $ | (1,607) |  |  | $ | (84) |  |  |  |  |  |  | $ | (1,691) |  |

[0001783180-23-000056:notes:82]
A summary of changes in the components of Accumulated other comprehensive income (loss) for the three and six months ended June 30, 2022 is as follows:

[0001783180-23-000056:notes:83]
| (In millions) |  | Foreign Currency Translation |  | Defined Benefit Pension and Post-retirement Plans |  |  |  |  |  | Accumulated Other Comprehensive Income (Loss) |
| Balance as of December 31, 2021 |  | $ | (505) |  |  | $ | (484) |  |  |  |  |  |  | $ | (989) |  |
| Other comprehensive income (loss) before reclassifications, net |  | (61) |  |  | (4) |  |  |  |  |  |  | (65) |  |
| Amounts reclassified, pre-tax |  | — |  |  | 3 |  |  |  |  |  |  | 3 |  |
| Tax expense (benefit) reclassified |  | — |  |  | (1) |  |  |  |  |  |  | (1) |  |
| Chubb divestiture |  | (574) |  |  | 329 |  |  |  |  |  |  | (245) |  |
| Balance as of March 31, 2022 |  | $ | (1,140) |  |  | $ | (157) |  |  |  |  |  |  | $ | (1,297) |  |
| Other comprehensive income (loss) before reclassifications, net |  | (480) |  |  | — |  |  |  |  |  |  | (480) |  |
| Amounts reclassified, pre-tax |  | — |  |  | 3 |  |  |  |  |  |  | 3 |  |
| Tax expense (benefit) reclassified |  | — |  |  | (1) |  |  |  |  |  |  | (1) |  |
| Balance as of June 30, 2022 |  | $ | (1,620) |  |  | $ | (155) |  |  |  |  |  |  | $ | (1,775) |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001783180-23-000056:notes:84]
[same as prior period, unchanged from 0001783180-23-000038:notes:78]

[0001783180-23-000056:notes:85]
[same as prior period, unchanged from 0001783180-23-000038:notes:79]

[0001783180-23-000056:notes:86]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
| (In millions) |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Sales Type |  |  |  |  |  |  |  |  |
| Product |  | $ | 3,754 |  |  | $ | 3,005 |  |  | $ | 6,955 |  |  | $ | 5,644 |  |
| Service |  | 462 |  |  | 383 |  |  | 883 |  |  | 714 |  |
| HVAC sales |  | 4,216 |  |  | 3,388 |  |  | 7,838 |  |  | 6,358 |  |
| Product |  | 858 |  |  | 925 |  |  | 1,645 |  |  | 1,792 |  |
| Service |  | 114 |  |  | 116 |  |  | 225 |  |  | 225 |  |
| Refrigeration sales |  | 972 |  |  | 1,041 |  |  | 1,870 |  |  | 2,017 |  |
| Product |  | 869 |  |  | 838 |  |  | 1,682 |  |  | 1,609 |  |
| Service |  | 63 |  |  | 49 |  |  | 119 |  |  | 96 |  |
| Fire & Security sales |  | 932 |  |  | 887 |  |  | 1,801 |  |  | 1,705 |  |
| Total segment sales |  | 6,120 |  |  | 5,316 |  |  | 11,509 |  |  | 10,080 |  |
| Eliminations and other |  | (128) |  |  | (105) |  |  | (244) |  |  | (215) |  |
| Net sales |  | $ | 5,992 |  |  | $ | 5,211 |  |  | $ | 11,265 |  |  | $ | 9,865 |  |

[0001783180-23-000056:notes:87]
[same as prior period, unchanged from 0001783180-23-000038:notes:81]

[0001783180-23-000056:notes:88]
[same as prior period, unchanged from 0001783180-23-000038:notes:82]

[0001783180-23-000056:notes:89]
| (In millions) |  | June 30,2023 |  | December 31,2022 |
| Contract assets, current |  | $ | 578 |  |  | $ | 537 |  |
| Contract assets, non-current (included within Other assets) |  | 8 |  |  | 6 |  |
| Total contract assets |  | 586 |  |  | 543 |  |
| Contract liabilities, current |  | (483) |  |  | (449) |  |
| Contract liabilities, non-current (included within Other long-term liabilities) |  | (170) |  |  | (174) |  |
| Total contract liabilities |  | (653) |  |  | (623) |  |
| Net contract assets (liabilities) |  | $ | (67) |  |  | $ | (80) |  |

[0001783180-23-000056:notes:90]
The timing of revenue recognition, billings and cash collections results in contract assets and contract liabilities. Contract assets relate to the conditional right to consideration for any completed performance under a contract when costs are incurred in excess of billings under the percentage-of-completion methodology. Contract liabilities relate to payments received in advance of performance under a contract or when the Company has a right to consideration that is conditioned upon transfer of a good or service to a customer. Contract liabilities are recognized as revenue as (or when) the Company performs under the contract. 
The Company recognized revenue of $264 million during the six months ended June 30, 2023 that related to contract liabilities as of January 1, 2023. The Company expects a majority of its current contract liabilities at the end of the period to be recognized as revenue in the next 12 months.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0001783180-23-000056:notes:91]
[same as prior period, unchanged from 0001783180-23-000038:notes:85]


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001783180-23-000056:notes:92]
[same as prior period, unchanged from 0001783180-23-000038:notes:86]

[0001783180-23-000056:notes:93]
[same as prior period, unchanged from 0001783180-23-000038:notes:87]

[0001783180-23-000056:notes:94]
|  | Three Months Ended June 30, |  | Six Months Ended June 30, |
| (In millions) | 2023 |  | 2022 |  | 2023 |  | 2022 |
| HVAC | $ | 3 |  |  | $ | 2 |  |  | $ | 2 |  |  | $ | 6 |  |
| Refrigeration | 7 |  |  | 6 |  |  | 10 |  |  | 6 |  |
| Fire & Security | (1) |  |  | 3 |  |  | 12 |  |  | 9 |  |
| Total Segment | 9 |  |  | 11 |  |  | 24 |  |  | 21 |  |
| General corporate expenses | — |  |  | 2 |  |  | 2 |  |  | 2 |  |
| Total restructuring costs | $ | 9 |  |  | $ | 13 |  |  | $ | 26 |  |  | $ | 23 |  |
| Cost of sales | $ | 3 |  |  | $ | 5 |  |  | $ | 9 |  |  | $ | 7 |  |
| Selling, general and administrative | 6 |  |  | 8 |  |  | 17 |  |  | 16 |  |
| Total restructuring costs | $ | 9 |  |  | $ | 13 |  |  | $ | 26 |  |  | $ | 23 |  |

[0001783180-23-000056:notes:95]
[same as prior period, unchanged from 0001783180-23-000038:notes:89]

[0001783180-23-000056:notes:96]
|  |  | Six Months Ended June 30, |
| (In millions) |  | 2023 |  | 2022 |
| Balance as of January 1, |  | $ | 24 |  |  | $ | 54 |  |
| Net pre-tax restructuring costs |  | 26 |  |  | 23 |  |
| Utilization, foreign exchange and other |  | (19) |  |  | (34) |  |
| Balance as of June 30, |  | $ | 31 |  |  | $ | 43 |  |

[0001783180-23-000056:notes:97]
During the six months ended June 30, 2023 and 2022, charges associated with restructuring initiatives related to cost reduction efforts. Amounts recognized primarily related to severance due to workforce reductions and exit costs due to the consolidation of field operations. As of June 30, 2023, the Company had $31 million accrued for costs associated with its announced restructuring initiatives, all of which is expected to be paid within one year.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001783180-23-000056:notes:98]
INCOME TAXES
The Company accounts for income tax expense in accordance with ASC 740, Income Taxes ("ASC 740"), which requires an estimate of the annual effective income tax rate for the full year to be applied to the respective interim period, taking into account year-to-date amounts and projected results for the full year. The effective tax rate was 44.8% for the three months ended June 30, 2023 compared with 22.5% for the three months ended June 30, 2022. The year-over-year increase was primarily driven by the non-deductible losses of $293 million on the deconsolidation of KFI due to its Chapter 11 filing and the $111 million loss on the mark-to-market valuation of the Company's window forward contracts associated with the expected cash outflows of the Euro-denominated purchase price of the VCS Business.

[0001783180-23-000056:notes:99]
The effective tax rate was 33.4% for the six months ended June 30, 2023 compared with 19.3% for the six months ended June 30, 2022. The year-over-year increase was primarily driven by the non-deductible losses of $293 million on the deconsolidation of KFI due to its Chapter 11 filing and the $111 million loss on the mark-to-market valuation of the Company's window forward contracts associated with the expected cash outflows of the Euro-denominated purchase price of the VCS Business.  In addition, the six months ended June 30, 2022 included a lower effective tax rate on the $1.1 billion Chubb gain compared with the Company's U.S. statutory rate and a favorable tax adjustment of $32 million associated with foreign tax credits generated and utilized in the prior year.

[0001783180-23-000056:notes:100]
[same as prior period, unchanged from 0001783180-23-000038:notes:93]

[0001783180-23-000056:notes:101]
The Company conducts business globally and files income tax returns in U.S. federal, state and foreign jurisdictions. In certain jurisdictions, the Company's operations were included in UTC's combined tax returns for the periods through the Distribution. The U.S. Internal Revenue Service ("IRS") is currently auditing UTC's 2017 and 2018 tax years and this audit could conclude within the next twelve months. In the normal course of business, the Company is subject to examination by taxing authorities throughout the world, including Australia, Belgium, Canada, China, Czech Republic, France, Germany, Hong Kong, India, Italy, Mexico, the Netherlands, Singapore, the United Kingdom and the United States. The Company is no longer subject to U.S. federal income tax examination for years prior to 2017 and, with few exceptions, is no longer subject to state, local and foreign income tax examinations for tax years prior to 2013.

[0001783180-23-000056:notes:102]
In the ordinary course of business, there is inherent uncertainty in quantifying the Company's income tax positions. The Company assesses its income tax positions and records tax benefits for all years subject to examination based upon management’s evaluation of the facts, circumstances and information available at the reporting date. The Company believes that it is reasonably possible that a net decrease in unrecognized tax benefits of $55 million to $70 million may occur within 12 months as a result of additional uncertain tax positions, the Separation, the revaluation of uncertain tax positions arising from examinations, appeals, court decisions and/or the expiration of tax statutes.


## us-gaap:EarningsPerShareTextBlock

[0001783180-23-000056:notes:103]
[same as prior period, unchanged from 0001783180-23-000038:notes:96]

[0001783180-23-000056:notes:104]
[same as prior period, unchanged from 0001783180-23-000038:notes:97]

[0001783180-23-000056:notes:105]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
| (In millions, except per share amounts) |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Net income attributable to common shareowners |  | $ | 199 |  |  | $ | 573 |  |  | $ | 572 |  |  | $ | 1,952 |  |
| Basic weighted-average number of shares outstanding |  | 836.0 |  |  | 845.7 |  |  | 835.5 |  |  | 849.5 |  |
| Stock awards and equity units (share equivalent) |  | 14.9 |  |  | 17.0 |  |  | 16.0 |  |  | 18.9 |  |
| Diluted weighted-average number of shares outstanding |  | 850.9 |  |  | 862.7 |  |  | 851.5 |  |  | 868.4 |  |
| Antidilutive shares excluded from computation of diluted earnings per share |  | 5.9 |  |  | 4.5 |  |  | 5.6 |  |  | 2.9 |  |
| Earnings Per Share |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.24 |  |  | $ | 0.68 |  |  | $ | 0.68 |  |  | $ | 2.30 |  |
| Diluted |  | $ | 0.23 |  |  | $ | 0.67 |  |  | $ | 0.67 |  |  | $ | 2.25 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001783180-23-000056:notes:106]
[same as prior period, unchanged from 0001783180-23-000038:notes:99]

[0001783180-23-000056:notes:107]
[same as prior period, unchanged from 0001783180-23-000038:notes:100]

[0001783180-23-000056:notes:108]
[same as prior period, unchanged from 0001783180-23-000038:notes:101]

[0001783180-23-000056:notes:109]
[same as prior period, unchanged from 0001783180-23-000038:notes:102]

[0001783180-23-000056:notes:110]
[same as prior period, unchanged from 0001783180-23-000038:notes:103]

[0001783180-23-000056:notes:111]
The excess purchase price over the estimated fair value of the net assets acquired was recognized as goodwill and totaled $876 million, which is not deductible for tax purposes. Accounts receivable and current liabilities were stated at their historical carrying value, which approximates fair value given the short-term nature of these assets and liabilities. The estimate of fair value for inventory and fixed assets was based on an assessment of the acquired assets' condition as well as an evaluation of the current market value of such assets. The sale agreement included several customary provisions to settle working capital and other transaction-related items as of the date of sale. During 2022, the parties finalized these amounts in accordance with the terms of the sale agreement and the Company paid an additional $41 million to Toshiba Corporation in 2023. In addition, the parties finalized amounts related to pension funding levels during the year which resulted in the Company receiving $12 million from Toshiba Corporation.

[0001783180-23-000056:notes:112]
[same as prior period, unchanged from 0001783180-23-000038:notes:105]

[0001783180-23-000056:notes:113]
[same as prior period, unchanged from 0001783180-23-000038:notes:106]

[0001783180-23-000056:notes:114]
The valuation of intangible assets was determined using an income approach methodology including the multi-period excess earnings method and the relief from royalty method. Key assumptions used in estimating future cash flows included projected revenue growth rates, EBIT margins, discount rates, customer attrition rates and royalty rates among others. The projected future cash flows are discounted to present value using an appropriate discount rate. As of June 30, 2023, the Company finalized the process of allocating the purchase price and valuing the acquired assets and liabilities except for certain amounts associated with income taxes.

[0001783180-23-000056:notes:115]
The Company previously accounted for its minority ownership in TCC under the equity method of accounting. In connection with the transaction, the carrying value of the Company's previously held TCC equity investments were recognized at fair value at the date of acquisition using an income approach methodology. As a result, the Company recognized a $696 million non-cash gain within Other income (expense), net on the accompanying Unaudited Condensed Consolidated Statement of Operations. In addition, the assets, liabilities and results of operations of TCC are consolidated in the accompanying Unaudited Condensed Consolidated Financial Statements as of the date of acquisition and reported within the Company's HVAC segment. The Company incurred $29 million of acquisition-related costs during 2022, of which $13 million was recognized during the six months ended June 30, 2022 and included within Selling, general and administrative on the accompanying Unaudited Condensed Consolidated Statement of Operations. The Company has not included pro forma financial information required under ASC 805 as the pro forma impact was not significant.

[0001783180-23-000056:notes:116]
Announced Acquisition

[0001783180-23-000056:notes:117]
On April 25, 2023, the Company announced that it entered into an Agreement to acquire the VCS Business, a privately-held company, for approximately €12 billion. The VCS Business develops intelligent, integrated and sustainable technologies, including heat pumps, boilers, photovoltaic systems, home battery storage and digital solutions, primarily for residential customers in Europe. Under the terms of the Agreement, 20% of the purchase price will be paid in Carrier common stock, issued directly to Viessmann and subject to long-term lock-up provisions, and 80% will be paid in cash, subject to working capital and other adjustments. The Company intends to finance the acquisition with a combination of cash on hand and new debt financing and expects the transaction to close around the end of 2023, subject to customary closing conditions and regulatory approvals.

[0001783180-23-000056:notes:118]
On April 25, 2023, the Company entered into commitment letters with JPMorgan Chase Bank, N.A., BofA Securities, Inc. and Bank of America, N.A. to provide a €8.2 billion aggregate principal, senior unsecured bridge term loan facility (the "Bridge Loan"). Proceeds from the Bridge Loan are expected to be used to fund a portion of the Euro-denominated purchase price of the VCS Business if other debt financing is not secured by the acquisition date. The Company capitalized $36 million of deferred financing costs associated with the Bridge Loan which are being amortized over the commitment period. On May 19, 2023, the aggregate principal amount of the Bridge Loan was reduced by €2.3 billion upon entering into a senior unsecured delayed draw term loan credit agreement. As a result, the Company accelerated the amortization on $10 million of deferred financing costs during the period in Interest expense.

[0001783180-23-000056:notes:119]
On May 19, 2023, the Company entered into a senior unsecured delayed draw term loan credit agreement with JPMorgan Chase Bank, N.A., as administrative agent and certain other lenders that permits aggregate borrowings of up to €2.3 billion (the "Delayed Draw Facility"). Proceeds from the Delayed Draw Facility are expected to be used to fund a portion of the Euro-denominated purchase price of the VCS Business. The Company capitalized $4 million of deferred financing costs associated with the Delayed Draw Facility which will be amortized over the term once the facility is drawn upon. In addition, the Company entered into a 364-day, $500 million, senior unsecured revolving credit agreement with JPMorgan Chase Bank, N.A., as administrative agent and certain other lenders (the "Revolver") on May 19, 2023. Proceeds from the Revolver become available upon closing the purchase of the VCS Business.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001783180-23-000056:notes:120]
DIVESTITURES
Sale of Chubb Fire & Security Business

[0001783180-23-000056:notes:121]
On January 3, 2022, the Company completed the Chubb Sale for net proceeds of $2.9 billion. Chubb, which was reported within the Company’s Fire & Security segment, delivered essential fire safety and security solutions from design and installation to monitoring, service and maintenance across more than 17 countries around the globe. The sale agreement included several customary provisions to settle working capital and other transaction-related items as of the date of sale. The parties finalized these amounts in accordance with the terms of the sale agreement during 2022. During the six months ended June 30, 2022, the Company recognized a net gain on the sale of $1.1 billion, which is included in Other income (expense), net on the accompanying Unaudited Condensed Consolidated Statement of Operations.

[0001783180-23-000056:notes:122]
Planned Portfolio Transformation
On April 25, 2023, the Company announced plans to exit its Fire & Security and Commercial Refrigeration businesses over the course of 2024. Carrier expects to use the proceeds from these transactions to reduce leverage, advance the Company’s capital allocation priorities and for general corporate purposes. The planned exit is not expected to impact UTEC, Fire & Security’s controls business for residential HVAC customers or the Sensitech monitoring businesses.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001783180-23-000056:notes:123]
[same as prior period, unchanged from 0001783180-23-000038:notes:111]

[0001783180-23-000056:notes:124]
[same as prior period, unchanged from 0001783180-23-000038:notes:112]

[0001783180-23-000056:notes:125]
[same as prior period, unchanged from 0001783180-23-000038:notes:113]

[0001783180-23-000056:notes:126]
[same as prior period, unchanged from 0001783180-23-000038:notes:114]

[0001783180-23-000056:notes:127]
[same as prior period, unchanged from 0001783180-23-000038:notes:115]

[0001783180-23-000056:notes:128]
[same as prior period, unchanged from 0001783180-23-000038:notes:116]

[0001783180-23-000056:notes:129]
|  |  | Net Sales |  | Operating Profit |
|  |  | Three Months Ended June 30, |  | Three Months Ended June 30, |
| (In millions) |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| HVAC |  | $ | 4,216 |  |  | $ | 3,388 |  |  | $ | 742 |  |  | $ | 585 |  |
| Refrigeration |  | 972 |  |  | 1,041 |  |  | 112 |  |  | 147 |  |
| Fire & Security |  | 932 |  |  | 887 |  |  | (157) |  |  | 134 |  |
| Total segment |  | 6,120 |  |  | 5,316 |  |  | 697 |  |  | 866 |  |
| Eliminations and other |  | (128) |  |  | (105) |  |  | (146) |  |  | (16) |  |
| General corporate expenses |  | — |  |  | — |  |  | (62) |  |  | (31) |  |
| Total Consolidated |  | $ | 5,992 |  |  | $ | 5,211 |  |  | $ | 489 |  |  | $ | 819 |  |

[0001783180-23-000056:notes:130]
|  |  | Net Sales |  | Operating Profit |
|  |  | Six Months Ended June 30, |  | Six Months Ended June 30, |
| (In millions) |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| HVAC |  | $ | 7,838 |  |  | $ | 6,358 |  |  | $ | 1,177 |  |  | $ | 1,055 |  |
| Refrigeration |  | 1,870 |  |  | 2,017 |  |  | 220 |  |  | 254 |  |
| Fire & Security |  | 1,801 |  |  | 1,705 |  |  | (64) |  |  | 1,352 |  |
| Total segment |  | 11,509 |  |  | 10,080 |  |  | 1,333 |  |  | 2,661 |  |
| Eliminations and other |  | (244) |  |  | (215) |  |  | (184) |  |  | (40) |  |
| General corporate expenses |  | — |  |  | — |  |  | (105) |  |  | (65) |  |
| Total Consolidated |  | $ | 11,265 |  |  | $ | 9,865 |  |  | $ | 1,044 |  |  | $ | 2,556 |  |

[0001783180-23-000056:notes:131]
Geographic external sales are attributed to the geographic regions based on their location of origin. With the exception of the U.S. presented in the table below, there were no individually significant countries with sales exceeding 10% of total sales during the six months ended June 30, 2023 and 2022.

[0001783180-23-000056:notes:132]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
| (In millions) |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| United States |  | $ | 3,389 |  |  | $ | 3,171 |  |  | $ | 6,249 |  |  | $ | 5,955 |  |
| International: |  |  |  |  |  |  |  |  |
| Europe |  | 1,205 |  |  | 1,119 |  |  | 2,401 |  |  | 2,164 |  |
| Asia Pacific |  | 1,194 |  |  | 713 |  |  | 2,227 |  |  | 1,365 |  |
| Other |  | 204 |  |  | 208 |  |  | 388 |  |  | 381 |  |
| Net sales |  | $ | 5,992 |  |  | $ | 5,211 |  |  | $ | 11,265 |  |  | $ | 9,865 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001783180-23-000056:notes:133]
RELATED PARTIES
Equity Method Investments

[0001783180-23-000056:notes:134]
The Company sells products to and purchases products from unconsolidated entities accounted for under the equity method and, therefore, these entities are considered to be related parties. Amounts attributable to equity method investees are as follows:

[0001783180-23-000056:notes:135]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
| (In millions) |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Sales to equity method investees included in Product sales |  | $ | 887 |  |  | $ | 787 |  |  | $ | 1,641 |  |  | $ | 1,411 |  |
| Purchases from equity method investees included in Cost of products sold |  | $ | 59 |  |  | $ | 91 |  |  | $ | 102 |  |  | $ | 201 |  |

[0001783180-23-000056:notes:136]
The Company had receivables from and payables to equity method investees as follows:

[0001783180-23-000056:notes:137]
| (In millions) |  | June 30,2023 |  | December 31,2022 |
| Receivables from equity method investees included in Accounts receivable, net |  | $ | 364 |  |  | $ | 154 |  |
| Payables to equity method investees included in Accounts payable |  | $ | 39 |  |  | $ | 44 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001783180-23-000056:notes:138]
COMMITMENTS AND CONTINGENT LIABILITIES
The Company is involved in various litigation, claims and administrative proceedings, including those related to environmental (including asbestos) and legal matters. In accordance with ASC 450, Contingencies, the Company records accruals for loss contingencies when it is probable that a liability has been incurred and the amount of the loss can be reasonably estimated. These accruals are generally based upon a range of possible outcomes. If no amount within the range is a better estimate than any other, the Company accrues the minimum amount. In addition, these estimates are reviewed periodically and adjusted to reflect additional information when it becomes available. The Company is unable to predict the final outcome of the following matters based on the information currently available, except as otherwise noted. However, the Company does not believe that the resolution of any of these matters will have a material adverse effect upon its results of operations, cash flows or financial condition.

[0001783180-23-000056:notes:139]
Environmental Matters

[0001783180-23-000056:notes:140]
The Company’s operations are subject to environmental regulation by various authorities. The Company has accrued for the costs of environmental remediation activities, including but not limited to investigatory, remediation, operating and maintenance costs and performance guarantees. The most likely cost to be incurred is accrued based on an evaluation of currently available facts with respect to individual sites, including the technology required to remediate, current laws and regulations and prior remediation experience.

[0001783180-23-000056:notes:141]
The outstanding liabilities for environmental obligations are as follows:

[0001783180-23-000056:notes:142]
| (In millions) |  | June 30,2023 |  | December 31,2022 |
| Environmental reserves included in Accrued liabilities |  | $ | 15 |  |  | $ | 24 |  |
| Environmental reserves included in Other long-term liabilities |  | 203 |  |  | 211 |  |
| Total Environmental reserves |  | $ | 218 |  |  | $ | 235 |  |

[0001783180-23-000056:notes:143]
For sites with multiple responsible parties, the Company considers its likely proportionate share of the anticipated remediation costs and the ability of other parties to fulfill their obligations in establishing a provision for these costs. Accrued environmental liabilities are not reduced by potential insurance reimbursements and are undiscounted.

[0001783180-23-000056:notes:144]
Asbestos Matters

[0001783180-23-000056:notes:145]
The Company has been named as a defendant in lawsuits alleging personal injury as a result of exposure to asbestos allegedly integrated into certain Carrier products or business premises. While the Company has never manufactured asbestos and no longer incorporates it into any currently-manufactured products, certain products that the Company no longer manufactures contained components incorporating asbestos. A substantial majority of these asbestos-related claims have been dismissed without payment or have been covered in full or in part by insurance or other forms of indemnity. Additional cases were litigated and settled without any insurance reimbursement. The amounts involved in asbestos-related claims were not material individually or in the aggregate in any period.

[0001783180-23-000056:notes:146]
The Company's asbestos liabilities and related insurance recoveries are as follows:

[0001783180-23-000056:notes:147]
| (In millions) |  | June 30,2023 |  | December 31,2022 |
| Asbestos liabilities included in Accrued liabilities |  | $ | 16 |  |  | $ | 16 |  |
| Asbestos liabilities included in Other long-term liabilities |  | 207 |  |  | 212 |  |
| Total Asbestos liabilities |  | $ | 223 |  |  | $ | 228 |  |
| Asbestos-related recoveries included in Other assets, current |  | $ | 5 |  |  | $ | 5 |  |
| Asbestos-related recoveries included in Other assets |  | 89 |  |  | 90 |  |
| Total Asbestos-related recoveries |  | $ | 94 |  |  | $ | 95 |  |

[0001783180-23-000056:notes:148]
The amounts recorded for asbestos-related liabilities are based on currently available information and assumptions that the Company believes are reasonable and are made with input from outside actuarial experts. These amounts are undiscounted and exclude the Company’s legal fees to defend the asbestos claims, which are expensed as incurred. In addition, the Company has recorded insurance recovery receivables for probable asbestos-related recoveries.

[0001783180-23-000056:notes:149]
UTC Equity Awards Conversion Litigation

[0001783180-23-000056:notes:150]
On August 12, 2020, several former employees of UTC or its subsidiaries filed a putative class action complaint (the "Complaint") in the United States District Court for the District of Connecticut against Raytheon Technologies Corporation, Carrier, Otis Worldwide Corporation ("Otis"), the former members of the UTC Board of Directors and the members of the Carrier and Otis Boards of Directors (Geraud Darnis, et al. v. Raytheon Technologies Corporation, et al.). The Complaint challenged the method by which UTC equity awards were converted to UTC, Carrier and Otis equity awards following the Separation and the Distribution. Defendants moved to dismiss the Complaint. Plaintiffs amended their Complaint on September 13, 2021 (the "Amended Complaint"). The Amended Complaint, with Raytheon Technologies Corporation, Carrier and Otis as the only defendants, asserted that the defendants are liable for breach of certain equity compensation plans and for breach of the implied covenant of good faith and fair dealing. The Amended Complaint also sought specific performance. The Company believes all plaintiffs' claims against it are without merit. Defendants moved to dismiss the Amended Complaint. On September 30, 2022, the court dismissed the case against all defendants, with prejudice. Plaintiffs appealed the dismissal to the United States Court of Appeals for the Second Circuit. Oral arguments on the appeal were held before the Second Circuit on June 29, 2023 and a decision is pending.

[0001783180-23-000056:notes:151]
Aqueous Film Forming Foam Litigation

[0001783180-23-000056:notes:152]
As of June 30, 2023, the Company, KFI and others have been named as defendants in more than 4,500 lawsuits filed by individuals in or removed to the federal courts of the United States alleging that the historic use of Aqueous Film Forming Foam ("AFFF") caused personal injuries and/or property damage. The Company, KFI and others have also been named as defendants in more than 500 lawsuits filed by several U.S. states, municipalities and water utilities in or removed to U.S. federal courts alleging that the historic use of AFFF caused contamination of property and water supplies. In December 2018, the U.S. Judicial Panel on Multidistrict Litigation transferred and consolidated all AFFF cases pending in the U.S. federal courts against the Company, KFI and others to the U.S. District Court for the District of South Carolina (the "MDL Proceedings"). The individual plaintiffs in the MDL Proceedings generally seek damages for alleged personal injuries, medical monitoring, diminution in property value and injunctive relief to remediate alleged contamination of water supplies. The U.S. state, municipal and water utility plaintiffs in the MDL Proceedings generally seek damages and costs related to the remediation of public property and water supplies.

[0001783180-23-000056:notes:153]
AFFF is a firefighting foam, developed beginning in the late 1960s pursuant to U.S. military specification, used to extinguish certain types of hydrocarbon-fueled fires. The lawsuits identified above relate to Kidde Fire Fighting, Inc. which owned the National Foam business. Kidde Fire Fighting, Inc. was acquired by a UTC subsidiary in 2005 and merged into KFI in 2007. The National Foam business manufactured AFFF for sale to government (including the U.S. federal government) and non-government customers in the U.S. at a single facility located in West Chester, Pennsylvania (the "Pennsylvania Site"). In 2013, KFI divested the AFFF businesses to an unrelated third party. The Company acquired KFI as part of the Separation in April 2020.

[0001783180-23-000056:notes:154]
The key components that contribute to AFFF's fire-extinguishing capabilities are known as fluorosurfactants. Neither the Company, nor KFI, nor any of the Company's subsidiaries involved in the AFFF litigation manufactured fluorosurfactants. Instead, the National Foam business purchased these substances from unrelated third parties for use in manufacturing AFFF. Plaintiffs in the MDL Proceedings allege that the fluorosurfactants used by various manufacturers in producing AFFF contained, or over time degraded into, compounds known as per- and polyfluoroalkyl substances (referred to collectively as "PFAS"), including perflourooctanesulfonic acid ("PFOS") and perflourooctanoic acid ("PFOA"). Plaintiffs further allege that, as a result of the use of AFFF, PFOS and PFOA were released into the environment and, in some instances, ultimately reached drinking water supplies.

[0001783180-23-000056:notes:155]
Plaintiffs in the MDL Proceedings allege that PFOS and PFOA contamination has resulted from the use of AFFF manufactured using a process known as ECF, and that this process was used exclusively by 3M. They also allege that PFOA contamination has resulted from the use of AFFF manufactured using a different process, known as telomerization, and that this process was used exclusively by the other AFFF manufacturers (including the National Foam business). Compounds containing PFOS and PFOA (as well as many other PFAS) have also been used for decades by many third parties in a number of different industries to manufacture firefighters’ protective outerwear, carpets, clothing, fabrics, cookware, food packaging, personal care products, cleaning products, paints, varnishes and other consumer and industrial products.

[0001783180-23-000056:notes:156]
Plaintiffs in the MDL Proceedings have named multiple defendants, including suppliers of chemicals and raw materials used to manufacture fluorosurfactants, fluorosurfactant manufacturers and AFFF manufacturers. The defendants in the MDL Proceedings moved for summary judgment on the government contractor defense, which potentially applies to AFFF sold to or used by the U.S. government. After full briefing and oral argument, on September 16, 2022, the MDL court declined to enter summary judgment for the defendants. The defense, however, remains available at any trial to which it applies.

[0001783180-23-000056:notes:157]
On September 23, 2022, after completion of discovery, the MDL court selected one water provider case, the City of Stuart, FL v. 3M, et al., for a bellwether trial. That trial was scheduled to begin in early June 2023 but was postponed indefinitely. The MDL court ordered that the bellwether process for personal injury cases will begin in 2023. The court has not yet outlined details on that process or its timing.

[0001783180-23-000056:notes:158]
Outside of the MDL Proceedings, the Company and other defendants also are party to six lawsuits in U.S. state courts brought by oil refining companies alleging product liability claims related to legacy sales of AFFF and seeking damages for the costs to replace the product and for property damage. In addition, the Company and other defendants are party to two actions related to the Pennsylvania Site in which the plaintiff water utility company seeks remediation costs related to the alleged contamination of the local water supply.

[0001783180-23-000056:notes:159]
The Company, KFI and other defendants are also party to one action in Arizona state court brought by a firefighter claiming that occupational exposure to AFFF has caused certain personal injuries. The Company and KFI believe that they have meritorious defenses to the claims in the MDL Proceedings and the other AFFF lawsuits. Given the numerous factual, scientific and legal issues to be resolved relating to these claims, the Company is unable to assess the probability of liability or to reasonably estimate a range of possible loss at this time. There can be no assurance that any such future exposure will not be material in any period.

[0001783180-23-000056:notes:160]
On May 14, 2023, KFI filed a voluntary petition with the United States Bankruptcy Court for the District of Delaware seeking relief under Chapter 11 of the Bankruptcy Code after the Company determined that it would not provide financial support to KFI going forward, other than ensuring KFI has access to services necessary for the effective operation of its business. As a result, all litigation against KFI is automatically stayed. KFI filed an adversary complaint and motion in the Chapter 11 case seeking an order staying or enjoining all AFFF-related litigation against the Company, its other subsidiaries and RTX. KFI has also indicated to the bankruptcy court that it intends to pursue insurance coverage for AFFF-related liabilities and contractual indemnification for AFFF-related liabilities from the third party to which KFI sold National Foam.

[0001783180-23-000056:notes:161]
Deconsolidation Due to Bankruptcy

[0001783180-23-000056:notes:162]
As of May 14, 2023, the Company no longer controls KFI as their activities are subject to review and oversight by the bankruptcy court. Therefore, KFI was deconsolidated and their respective assets and liabilities were derecognized from the Company’s Unaudited Condensed Consolidated Financial Statements. Upon deconsolidation, the Company determined the fair value of its retained interest in KFI to be zero and will account for it prospectively using the cost method. As a result of these actions, the Company recognized a loss of $293 million in its Unaudited Condensed Consolidated Statements of Operations

[0001783180-23-000056:notes:163]
within Other income/(expense), net. In addition, the deconsolidation resulted in an investing cash outflow of $134 million in the Company's Unaudited Condensed Consolidated Statements of Cash Flows.

[0001783180-23-000056:notes:164]
In connection with the bankruptcy filing, KFI entered into several agreements with subsidiaries of the Company to ensure they have access to services necessary for the effective operation of their business. All post-deconsolidation activity between the Company and KFI are reported as third-party transactions recorded within the Company's Unaudited Condensed Consolidated Statements of Operations. Since the petition date, there were no material transactions between the Company and KFI.

[0001783180-23-000056:notes:165]
Income Taxes

[0001783180-23-000056:notes:166]
Under the Tax Matters Agreement relating to the Separation, the Company is responsible to UTC for its share of the Tax Cuts and Jobs Act transition tax associated with foreign undistributed earnings as of December 31, 2017. As a result, liabilities of $75 million and $293 million are included within the accompanying Unaudited Condensed Consolidated Balance Sheet within Accrued Liabilities and Other Long-Term Liabilities as of June 30, 2023, respectively. This obligation is expected to be settled in annual installments ending in April 2026 with the next installment of $75 million due in 2024. The Company believes that the likelihood of incurring losses materially in excess of this amount is remote.

[0001783180-23-000056:notes:167]
Other

[0001783180-23-000056:notes:168]
The Company has other commitments and contingent liabilities related to legal proceedings, self-insurance programs and matters arising in the ordinary course of business. The Company accrues for contingencies generally based upon a range of possible outcomes. If no amount within the range is a better estimate than any other, the Company accrues the minimum amount.

[0001783180-23-000056:notes:169]
In the ordinary course of business, the Company is also routinely a defendant in, party to or otherwise subject to many pending and threatened legal actions, claims, disputes and proceedings. These matters are often based on alleged violations of contract, product liability, warranty, regulatory, environmental, health and safety, employment, intellectual property, tax and other laws. In some of these proceedings, claims for substantial monetary damages are asserted against the Company and could result in fines, penalties, compensatory or treble damages or non-monetary relief. The Company does not believe that these matters will have a material adverse effect upon its results of operations, cash flows or financial condition.
