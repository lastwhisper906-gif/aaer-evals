# CARR MD&A — 0001783180-22-000048


## mdna

[0001783180-22-000048:mdna:1]
[same as prior period, unchanged from 0001783180-22-000034:mdna:1]

[0001783180-22-000048:mdna:2]
[same as prior period, unchanged from 0001783180-22-000034:mdna:2]

[0001783180-22-000048:mdna:3]
[same as prior period, unchanged from 0001783180-22-000034:mdna:3]

[0001783180-22-000048:mdna:4]
Carrier is the leading global provider of healthy, safe, sustainable and intelligent building and cold chain solutions. Our portfolio includes industry-leading brands such as Carrier, Automated Logic, Carrier Transicold, Kidde, Edwards and LenelS2 that offer innovative HVAC, refrigeration, fire, security and building automation technologies to help make the world safer and more comfortable. We also provide a broad array of related building services, including audit, design, installation, system integration, repair, maintenance and monitoring. Our operations are classified into three segments: HVAC, Refrigeration and Fire & Security.

[0001783180-22-000048:mdna:5]
[same as prior period, unchanged from 0001783180-22-000034:mdna:5]

[0001783180-22-000048:mdna:6]
[same as prior period, unchanged from 0001783180-22-000034:mdna:6]

[0001783180-22-000048:mdna:7]
[same as prior period, unchanged from 0001783180-22-000034:mdna:7]

[0001783180-22-000048:mdna:8]
[same as prior period, unchanged from 0001783180-22-000034:mdna:8]

[0001783180-22-000048:mdna:9]
In February 2022, Russian forces initiated a military action against Ukraine. As a result, the European Union, United States, the United Kingdom and other countries have imposed sanctions that have increased global economic and political uncertainty. We operate in Russia through a Russia-based subsidiary and a joint venture which represents less than 1% of our total assets and revenue. On March 10, 2022, we announced that we were suspending business operations in Russia, honoring existing contractual obligations in a manner that fully complies with all sanctions and trade controls imposed. As of June 30, 2022, we plan to cease all operations in Russia this year. While neither Russia nor Ukraine constitute a material portion of our business, the conflict could lead to disruption, instability and volatility in global markets and industries that could negatively impact our results of operations. We continue to monitor the evolving impacts of this conflict and its effect on the global economy and geopolitical landscape.

[0001783180-22-000048:mdna:10]
[same as prior period, unchanged from 0001783180-22-000034:mdna:10]

[0001783180-22-000048:mdna:11]
[same as prior period, unchanged from 0001783180-22-000034:mdna:11]

[0001783180-22-000048:mdna:12]
[same as prior period, unchanged from 0001783180-22-000034:mdna:12]

[0001783180-22-000048:mdna:13]
[same as prior period, unchanged from 0001783180-22-000034:mdna:13]

[0001783180-22-000048:mdna:14]
On January 3, 2022, we completed the Chubb Sale for net proceeds of $2.9 billion. Chubb, which was reported within our Fire & Security segment, delivered essential fire safety and security solutions from design and installation to monitoring, service and

[0001783180-22-000048:mdna:15]
[same as prior period, unchanged from 0001783180-22-000034:mdna:25]

[0001783180-22-000048:mdna:16]
maintenance across more than 17 countries around the globe. During the three months ended March 31, 2022, we recognized a gain on the sale of $1.1 billion. The sale agreement included several customary provisions to settle working capital and other transaction-related items as of the date of sale. As of June 30, 2022, both parties are in the process of finalizing these amounts in accordance with established timelines.

[0001783180-22-000048:mdna:17]
[same as prior period, unchanged from 0001783180-22-000034:mdna:16]

[0001783180-22-000048:mdna:18]
[same as prior period, unchanged from 0001783180-22-000034:mdna:17]

[0001783180-22-000048:mdna:19]
[same as prior period, unchanged from 0001783180-22-000034:mdna:18]

[0001783180-22-000048:mdna:20]
[same as prior period, unchanged from 0001783180-22-000034:mdna:19]

[0001783180-22-000048:mdna:21]
[same as prior period, unchanged from 0001783180-22-000034:mdna:20]

[0001783180-22-000048:mdna:22]
As a result of the Chubb Sale, we do not own any shares of Chubb common stock and no longer consolidate Chubb in our financial statements as of January 3, 2022. Therefore, this Management’s Discussion and Analysis of Financial Condition and Results of Operations only includes the financial results of Chubb in periods prior to the date of sale. As a result, prior period results may not be comparable to the current period. See Note 16 - Divestitures in the Notes to the Unaudited Condensed Consolidated Financial Statements for additional information.

[0001783180-22-000048:mdna:23]
Three Months Ended June 30, 2022 Compared with the Three Months Ended June 30, 2021

[0001783180-22-000048:mdna:24]
[same as prior period, unchanged from 0001783180-22-000034:mdna:23]

[0001783180-22-000048:mdna:25]
|  |  | For the Three Months Ended June 30, |  |  |  |  |  |  |
| (In millions) |  | 2022 |  | 2021 |  | Period Change |  | % Change |  |  |  |  |  |  |
| Net sales |  | $ | 5,211 |  |  | $ | 5,440 |  |  | $ | (229) |  |  | (4) | % |  |  |  |  |  |  |
| Cost of products and services sold |  | (3,764) |  |  | (3,821) |  |  | 57 |  |  | (1) | % |  |  |  |  |  |  |
| Gross margin |  | 1,447 |  |  | 1,619 |  |  | (172) |  |  | (11) | % |  |  |  |  |  |  |
| Operating expenses |  | (628) |  |  | (836) |  |  | 208 |  |  | (25) | % |  |  |  |  |  |  |
| Operating profit |  | 819 |  |  | 783 |  |  | 36 |  |  | 5 | % |  |  |  |  |  |  |
| Non-operating income (expenses), net |  | (62) |  |  | (52) |  |  | (10) |  |  | 19 | % |  |  |  |  |  |  |
| Income from operations before income taxes |  | 757 |  |  | 731 |  |  | 26 |  |  | 4 | % |  |  |  |  |  |  |
| Income tax expense |  | (170) |  |  | (234) |  |  | 64 |  |  | (27) | % |  |  |  |  |  |  |
| Net income from operations |  | 587 |  |  | 497 |  |  | 90 |  |  | 18 | % |  |  |  |  |  |  |
| Less: Non-controlling interest in subsidiaries' earnings from operations |  | 14 |  |  | 10 |  |  | 4 |  |  | 40 | % |  |  |  |  |  |  |
| Net income attributable to common shareowners |  | $ | 573 |  |  | $ | 487 |  |  | $ | 86 |  |  | 18 | % |  |  |  |  |  |  |

[0001783180-22-000048:mdna:26]
[same as prior period, unchanged from 0001783180-22-000034:mdna:26]

[0001783180-22-000048:mdna:27]
For the three months ended June 30, 2022, Net sales were $5.2 billion, a 4% decrease compared with the same period of 2021. The components of the year-over-year change were as follows:

[0001783180-22-000048:mdna:28]
|  |  | For the Three Months Ended June 30, 2022 |  |  |  |  |  |  |
| Organic |  | 7 | % |  |  |  |  |  |  |
| Foreign currency translation |  | (3) | % |  |  |  |  |  |  |
| Acquisitions and divestitures, net |  | (8) | % |  |  |  |  |  |  |
| Total % change |  | (4) | % |  |  |  |  |  |  |

[0001783180-22-000048:mdna:29]
Organic sales for the three months ended June 30, 2022 increased by 7% compared with the same period of 2021. We continue to benefit from strong demand for energy-efficient, digital products and healthy building solutions as well as pricing improvements across each of our segments. The organic increase was primarily driven by our HVAC segment with continued strong demand and pricing improvements in our North America residential and light commercial business and improved global end-markets in our Commercial HVAC business. Strong results in our Refrigeration segment were primarily driven by pricing improvements and higher volumes. Pricing improvements in our Fire & Security segment were the primary driver of growth compared with the prior year while supply chain and logistic constraints continue to be challenging. Refer to "Segment Review" below for a discussion of Net sales by segment.

[0001783180-22-000048:mdna:30]
[same as prior period, unchanged from 0001783180-22-000034:mdna:30]

[0001783180-22-000048:mdna:31]
For the three months ended June 30, 2022, gross margin was $1.4 billion, an 11% decrease compared with the same period of  2021. The components were as follows:

[0001783180-22-000048:mdna:32]
|  |  | For the Three Months Ended June 30, |  |  |  |  |  |  |
| (In millions) |  | 2022 |  | 2021 |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 5,211 |  |  | $ | 5,440 |  |  |  |  |  |  |  |  |  |
| Cost of products and services sold |  | (3,764) |  |  | (3,821) |  |  |  |  |  |  |  |  |  |
| Gross margin |  | $ | 1,447 |  |  | $ | 1,619 |  |  |  |  |  |  |  |  |  |
| Percentage of net sales |  | 27.8 | % |  | 29.8 | % |  |  |  |  |  |  |  |  |

[0001783180-22-000048:mdna:33]
The decrease in gross margin was primarily driven by the Chubb Sale which contributed $152 million of gross margin during the three months ended June 30, 2021 with a 20 basis point impact on gross margin as a percentage of Net sales. In addition, each of our segments continued to be impacted by the higher cost of commodities and components used in our products, certain supply chain constraints and higher freight costs. However, these impacts were more than offset by strong demand, pricing improvements and our continued focus on productivity initiatives. Although pricing improvements more than offset inflationary impacts and supply chain challenges, gross margin as a percentage of Net sales decreased by 200 basis points compared with the same period of 2021.

[0001783180-22-000048:mdna:34]
[same as prior period, unchanged from 0001783180-22-000034:mdna:34]

[0001783180-22-000048:mdna:35]
For the three months ended June 30, 2022, operating expenses, including Equity method investment net earnings, were $628

[0001783180-22-000048:mdna:36]
million, a 25% decrease compared with the same period of 2021. The components were as follows:

[0001783180-22-000048:mdna:37]
|  |  | For the Three Months Ended June 30, |  |  |  |  |  |  |
| (In millions) |  | 2022 |  | 2021 |  |  |  |  |  |  |  |  |
| Selling, general and administrative |  | $ | (614) |  |  | $ | (813) |  |  |  |  |  |  |  |  |  |
| Research and development |  | (122) |  |  | (125) |  |  |  |  |  |  |  |  |  |
| Equity method investment net earnings |  | 101 |  |  | 87 |  |  |  |  |  |  |  |  |  |
| Other income (expense), net |  | 7 |  |  | 15 |  |  |  |  |  |  |  |  |  |
| Total operating expenses |  | $ | (628) |  |  | $ | (836) |  |  |  |  |  |  |  |  |  |
| Percentage of net sales |  | 12.1 | % |  | 15.4 | % |  |  |  |  |  |  |  |  |

[0001783180-22-000048:mdna:38]
For the three months ended June 30, 2022, Selling, general and administrative expenses were $614 million, a 24% decrease compared with the same period of 2021. The decrease is primarily due to the Chubb Sale on January 3, 2022. In addition, lower restructuring charges and the benefit provided by changes in the fair value of cash-settled equity awards further contributed to the decrease. In addition, the three months ended June 30, 2021 included $3 million of costs related to the Separation and $12 million of costs related to the Chubb Sale.

[0001783180-22-000048:mdna:39]
[same as prior period, unchanged from 0001783180-22-000034:mdna:39]

[0001783180-22-000048:mdna:40]
Investments over which we do not exercise control, but have significant influence, are accounted for using the equity method of accounting. For the three months ended June 30, 2022, Equity method investment net earnings were $101 million, a 16% increase compared with the same period of 2021. The increase was primarily related to a $27 million gain on the sale of two minority owned subsidiaries within one of our joint ventures partially offset by the higher cost of commodities and components.

[0001783180-22-000048:mdna:41]
Other income (expense), net primarily includes the impact of gains and losses related to the sale of businesses or interests in our equity method investments, foreign currency gains and losses on transactions that are denominated in a currency other than an entity's functional currency and hedging-related activities. During the three months ended June 30, 2022, we recognized a $22 million charge resulting from a litigation matter and a $7 million gain on the sale of our interest in a cost method investment reported within our Refrigeration segment.

[0001783180-22-000048:mdna:42]
[same as prior period, unchanged from 0001783180-22-000034:mdna:42]

[0001783180-22-000048:mdna:43]
For the three months ended June 30, 2022, Non-operating income (expenses), net was $62 million, a 19% increase compared with the same period of 2021. The components were as follows:

[0001783180-22-000048:mdna:44]
|  |  | For the Three Months Ended June 30, |  |  |
| (In millions) |  | 2022 |  | 2021 |  |  |  |  |
| Non-service pension (expense) benefit |  | $ | (1) |  |  | $ | 19 |  |  |  |  |  |
| Interest expense |  | $ | (68) |  |  | $ | (75) |  |  |  |  |  |
| Interest income |  | 7 |  |  | 4 |  |  |  |  |  |
| Interest (expense) income, net |  | $ | (61) |  |  | $ | (71) |  |  |  |  |  |
| Non-operating income (expenses), net |  | $ | (62) |  |  | $ | (52) |  |  |  |  |  |

[0001783180-22-000048:mdna:45]
Non-operating income (expenses), net includes the results from activities other than normal business operations such as interest expense, interest income and the non-service components of pension and post-retirement obligations. For the three months ended June 30, 2022, Interest expense was $68 million, a 9% decrease compared with the same period of 2021. The decrease

[0001783180-22-000048:mdna:46]
was primarily driven by the repayment of $1.15 billion aggregate principal 2.242% Notes due 2025 and 2.493% Notes due 2027 during the three months ended March 31, 2022.

[0001783180-22-000048:mdna:47]
[same as prior period, unchanged from 0001783180-22-000034:mdna:46]

[0001783180-22-000048:mdna:48]
|  |  | For the Three Months Ended June 30, |  |  |  |
|  |  | 2022 |  | 2021 |  |  |  |  |  |  |  |
| Effective tax rate |  | 22.5 | % |  | 32.0 | % |  |  |  |  |  |  |  |

[0001783180-22-000048:mdna:49]
The Company accounts for income tax expense in accordance with ASC 740, which requires an estimate of the annual effective income tax rate for the full year to be applied to the respective interim period, taking into account year-to-date amounts and projected results for the full year. The effective tax rate was 22.5% for the three months ended June 30, 2022 compared with 32.0% for the three months ended June 30, 2021. The year-over-year decrease was primarily driven by a combined tax benefit of $15 million related to re-organizations in Australia, Canada and the United Kingdom recorded during the three months ended June 30, 2022 as well as the absence of a $43 million deferred tax charge recorded during the three months ended June 30, 2021 associated with a tax rate increase in the United Kingdom enacted on June 10, 2021 with an effective date of April 2023.

[0001783180-22-000048:mdna:50]
Six Months Ended June 30, 2022 Compared with the Six Months Ended June 30, 2021

[0001783180-22-000048:mdna:51]
The following represents our consolidated net sales and operating results:

[0001783180-22-000048:mdna:52]
|  |  | For the Six Months Ended June 30, |  |  |  |  |  |  |
| (In millions) |  | 2022 |  | 2021 |  | Period Change |  | % Change |  |  |  |  |  |  |
| Net sales |  | $ | 9,865 |  |  | $ | 10,139 |  |  | $ | (274) |  |  | (3) | % |  |  |  |  |  |  |
| Cost of products and services sold |  | (7,125) |  |  | (7,126) |  |  | 1 |  |  | — | % |  |  |  |  |  |  |
| Gross margin |  | 2,740 |  |  | 3,013 |  |  | (273) |  |  | (9) | % |  |  |  |  |  |  |
| Operating expenses |  | (184) |  |  | (1,659) |  |  | 1,475 |  |  | (89) | % |  |  |  |  |  |  |
| Operating profit |  | 2,556 |  |  | 1,354 |  |  | 1,202 |  |  | 89 | % |  |  |  |  |  |  |
| Non-operating income (expenses), net |  | (111) |  |  | (127) |  |  | 16 |  |  | (13) | % |  |  |  |  |  |  |
| Income from operations before income taxes |  | 2,445 |  |  | 1,227 |  |  | 1,218 |  |  | 99 | % |  |  |  |  |  |  |
| Income tax expense |  | (471) |  |  | (338) |  |  | (133) |  |  | 39 | % |  |  |  |  |  |  |
| Net income from operations |  | 1,974 |  |  | 889 |  |  | 1,085 |  |  | 122 | % |  |  |  |  |  |  |
| Less: Non-controlling interest in subsidiaries' earnings from operations |  | 22 |  |  | 18 |  |  | 4 |  |  | 22 | % |  |  |  |  |  |  |
| Net income attributable to common shareowners |  | $ | 1,952 |  |  | $ | 871 |  |  | $ | 1,081 |  |  | 124 | % |  |  |  |  |  |  |

[0001783180-22-000048:mdna:53]
Net Sales

[0001783180-22-000048:mdna:54]
For the six months ended June 30, 2022, Net sales were $9.9 billion, a 3% decrease compared with the same period of 2021. The components of the year-over-year change were as follows:

[0001783180-22-000048:mdna:55]
|  |  |  |  | For the Six Months Ended June 30, 2022 |  |  |  |  |
| Organic |  |  |  | 9 | % |  |  |  |  |
| Foreign currency translation |  |  |  | (3) | % |  |  |  |  |
| Acquisitions and divestitures, net |  |  |  | (9) | % |  |  |  |  |
| Total % change |  |  |  | (3) | % |  |  |  |  |

[0001783180-22-000048:mdna:56]
Organic sales for the six months ended June 30, 2022 increased by 9% compared with the same period of 2021. We continue to benefit from strong demand for energy-efficient, digital products and healthy building solutions as well as pricing improvements across each of our segments. The organic increase was primarily driven by our HVAC segment with continued

[0001783180-22-000048:mdna:57]
strong demand in our North America residential and light commercial business and improved global end-markets in our Commercial HVAC business. Pricing improvements in our Fire & Security segment were the primary driver of growth compared with the prior year while supply chain and logistic constraints continue to be challenging. Refrigeration results were flat as strong second quarter results offset ongoing supply chain and logistic constraints. Refer to "Segment Review" below for a discussion of Net sales by segment.

[0001783180-22-000048:mdna:58]
Gross Margin

[0001783180-22-000048:mdna:59]
For the six months ended June 30, 2022, gross margin was $2.7 billion, a 9% decrease compared with the same period of 2021. The components were as follows:

[0001783180-22-000048:mdna:60]
|  |  |  |  | For the Six Months Ended June 30, |  |  |  |  |
| (In millions) |  |  |  |  |  | 2022 |  | 2021 |  |  |  |  |
| Net sales |  |  |  |  |  | $ | 9,865 |  |  | $ | 10,139 |  |  |  |  |  |
| Cost of products and services sold |  |  |  |  |  | (7,125) |  |  | (7,126) |  |  |  |  |  |
| Gross margin |  |  |  |  |  | $ | 2,740 |  |  | $ | 3,013 |  |  |  |  |  |
| Percentage of net sales |  |  |  |  |  | 27.8 | % |  | 29.7 | % |  |  |  |  |

[0001783180-22-000048:mdna:61]
The decrease in gross margin was primarily driven by the Chubb Sale, which contributed $322 million of gross margin during the six months ended June 30, 2021 with a 10 basis point impact on gross margin as a percentage of Net sales. In addition, each of our segments continued to be impacted by the higher cost of commodities and components used in our products, certain supply chain constraints and higher freight costs. However, these impacts were more than offset by strong demand, pricing improvements and our continued focus on productivity initiatives. Although pricing improvements offset inflationary impacts and supply chain challenges, gross margin as a percentage of Net sales decreased by 190 basis points compared with the same period of 2021.

[0001783180-22-000048:mdna:62]
Operating Expenses

[0001783180-22-000048:mdna:63]
For the six months ended June 30, 2022, operating expenses, including Equity method investment net earnings, were $184 million, a 89% decrease compared with the same period of 2021. The components were as follows:

[0001783180-22-000048:mdna:64]
|  |  |  |  | For the Six Months Ended June 30, |  |  |  |  |
| (In millions) |  |  |  |  |  | 2022 |  | 2021 |  |  |  |  |
| Selling, general and administrative |  |  |  |  |  | $ | (1,215) |  |  | $ | (1,556) |  |  |  |  |  |
| Research and development |  |  |  |  |  | (247) |  |  | (246) |  |  |  |  |  |
| Equity method investment net earnings |  |  |  |  |  | 159 |  |  | 125 |  |  |  |  |  |
| Other income (expense), net |  |  |  |  |  | 1,119 |  |  | 18 |  |  |  |  |  |
| Total operating expenses |  |  |  |  |  | $ | (184) |  |  | $ | (1,659) |  |  |  |  |  |
| Percentage of net sales |  |  |  |  |  | 1.9 | % |  | 16.4 | % |  |  |  |  |

[0001783180-22-000048:mdna:65]
For the six months ended June 30, 2022, Selling, general and administrative expenses were $1.2 billion, a 22% decrease compared with the same period of 2021. The decrease is primarily due to the Chubb Sale on January 3, 2022. In addition, lower restructuring charges and the benefit provided by changes in the fair value of cash-settled equity awards further contributed to the decrease. In addition, the six months ended June 30, 2021 included $19 million of costs related to the Separation and $15 million of costs related to the Chubb Sale.

[0001783180-22-000048:mdna:66]
Research and development costs relate to new product development and new technology innovation. Due to the variable nature of program development schedules, year-over-year spending levels can fluctuate. In addition, we continue to invest to prepare for future energy efficiency and refrigerant regulation changes as well as digital controls technologies.

[0001783180-22-000048:mdna:67]
Investments over which we do not exercise control, but have significant influence, are accounted for using the equity method of accounting. For the six months ended June 30, 2022, Equity method investment net earnings were $159 million, a 27% increase compared with the same period of 2021. The increase was primarily related to a $27 million gain on the sale of two minority

[0001783180-22-000048:mdna:68]
owned subsidiaries within one of our joint ventures. In addition, higher earnings in HVAC joint ventures in Asia and North America further benefited earnings.

[0001783180-22-000048:mdna:69]
Other income (expense), net primarily includes the impact of gains and losses related to the sale of businesses or interests in our equity method investments, foreign currency gains and losses on transactions that are denominated in a currency other than an entity's functional currency and hedging-related activities. During the six months ended June 30, 2022, we completed the Chubb Sale and recognized a net gain on the sale of $1.1 billion. In addition, we recognized a $22 million charge resulting from a litigation matter and a $7 million gain on the sale of our interest in a cost method investment reported within our Refrigeration segment.

[0001783180-22-000048:mdna:70]
Non-Operating Income (Expenses), net

[0001783180-22-000048:mdna:71]
For the six months ended June 30, 2022, Non-operating income (expenses), net was $111 million, a 13% increase compared with the same period of 2021. The components were as follows:

[0001783180-22-000048:mdna:72]
|  |  |  |  | For the Six Months Ended June 30, |
| (In millions) |  |  |  |  |  | 2022 |  | 2021 |
| Non-service pension (expense) benefit |  |  |  |  |  | $ | (2) |  |  | $ | 37 |  |
| Interest expense |  |  |  |  |  | $ | (155) |  |  | $ | (171) |  |
| Interest income |  |  |  |  |  | 46 |  |  | 7 |  |
| Interest (expense) income, net |  |  |  |  |  | $ | (109) |  |  | $ | (164) |  |
| Non-operating income (expenses), net |  |  |  |  |  | $ | (111) |  |  | $ | (127) |  |

[0001783180-22-000048:mdna:73]
Non-operating income (expenses), net includes the results from activities other than normal business operations such as interest expense, interest income and the non-service components of pension and post-retirement obligations. For the six months ended June 30, 2022, Interest expense was $155 million, a 9% decrease compared with the same period of 2021. During the six months ended June 30, 2022, we completed tender offers to repurchase approximately $1.15 billion aggregate principal of our 2.242% Notes due 2025 and 2.493% Notes due 2027. Upon settlement, we wrote off $5 million of unamortized deferred financing costs in Interest expense and recognized a net gain of $33 million in Interest income. During the six months ended June 30, 2021, we incurred a make-whole premium of $17 million and wrote-off $2 million of unamortized deferred financing costs in Interest expense as a result of the redemption of our $500 million 1.923% Notes originally due in February 2023.

[0001783180-22-000048:mdna:74]
Income Taxes

[0001783180-22-000048:mdna:75]
|  |  |  | For the Six Months Ended June 30, |  |  |
|  |  |  |  |  | 2022 |  | 2021 |  |  |  |  |
| Effective tax rate |  |  |  |  | 19.3 | % |  | 27.5 | % |  |  |  |  |

[0001783180-22-000048:mdna:76]
The Company accounts for income tax expense in accordance with ASC 740, which requires an estimate of the annual effective income tax rate for the full year to be applied to the respective interim period, taking into account year-to-date amounts and projected results for the full year. The effective tax rate was 19.3% for the six months ended June 30, 2022 compared with 27.5% for the six months ended June 30, 2021. The year-over-year decrease was primarily driven by a lower effective tax rate on the Chubb gain compared with our U.S. statutory rate and a favorable tax adjustment of $32 million associated with foreign tax credits generated and expected to be utilized in the current year. The six months ended June 30, 2021 included a $43 million deferred tax charge associated with a tax rate increase in the United Kingdom enacted on June 10, 2021 with an effective date of April 2023, partially offset by the recognition of a favorable tax adjustment of $21 million resulting from the re-organization of a German subsidiary.

[0001783180-22-000048:mdna:77]
[same as prior period, unchanged from 0001783180-22-000034:mdna:50]

[0001783180-22-000048:mdna:78]
We have three operating segments:

[0001783180-22-000048:mdna:79]
•The HVAC segment provides products, controls, services and solutions to meet the heating, cooling and ventilation needs of residential and commercial customers while enhancing building performance, health, energy efficiency and sustainability.

[0001783180-22-000048:mdna:80]
•The Refrigeration segment includes transport refrigeration and monitoring products, services and digital solutions for trucks, trailers, shipping containers, intermodal and rail, as well as commercial refrigeration products.

[0001783180-22-000048:mdna:81]
•The Fire & Security segment provides a wide range of residential, commercial and industrial technologies designed to help protect people and property.

[0001783180-22-000048:mdna:82]
We determine our segments based on how our Chief Executive Officer, who is the Chief Operating Decision Maker (the "CODM"), allocates resources, assesses performance and makes operational decisions. The CODM allocates resources and evaluates the financial performance of each of our segments based on Net sales and Operating profit. Adjustments to reconcile segment reporting to the consolidated results are included in Note 17 - Segment Financial Data.

[0001783180-22-000048:mdna:83]
Three Months Ended June 30, 2022 Compared with Three Months Ended June 30, 2021

[0001783180-22-000048:mdna:84]
Summary performance for each of our segments is as follows:

[0001783180-22-000048:mdna:85]
|  |  | Net Sales |  | Operating Profit |  | Operating Profit Margin |
|  |  | For the Three Months Ended June 30, |  | For the Three Months Ended June 30, |  | For the Three Months Ended June 30, |
| (In millions) |  | 2022 |  | 2021 |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| HVAC |  | $ | 3,388 |  |  | $ | 3,120 |  |  | $ | 585 |  |  | $ | 573 |  |  | 17.3 | % |  | 18.4 | % |
| Refrigeration |  | 1,041 |  |  | 1,021 |  |  | 147 |  |  | 123 |  |  | 14.1 | % |  | 12.0 | % |
| Fire & Security |  | 887 |  |  | 1,403 |  |  | 134 |  |  | 148 |  |  | 15.1 | % |  | 10.5 | % |
| Total segment |  | $ | 5,316 |  |  | $ | 5,544 |  |  | $ | 866 |  |  | $ | 844 |  |  | 16.3 | % |  | 15.2 | % |

[0001783180-22-000048:mdna:86]
[same as prior period, unchanged from 0001783180-22-000034:mdna:53]

[0001783180-22-000048:mdna:87]
For the three months ended June 30, 2022, Net sales in our HVAC segment were $3.4 billion, a 9% increase compared with the same period of 2021. The components of the year-over-year change were as follows:

[0001783180-22-000048:mdna:88]
|  |  | Net Sales |
| Organic |  | 8 | % |
| Foreign currency translation |  | (1) | % |
| Acquisitions and divestitures, net |  | 2 | % |
| Total % change in Net sales |  | 9 | % |

[0001783180-22-000048:mdna:89]
The organic increase in Net sales of 8% was driven by continued strong results across each of the segment's businesses. Increased sales in our North America residential and light commercial business (14%) were primarily driven by pricing improvements during the period. Increased sales in our Commercial HVAC business (2%) benefited from pricing improvements and ongoing customer demand in our end-markets. The business saw growth in each region, although sales in China decreased as a result of a resurgence of COVID-19 cases and additional restrictions imposed. While current demand remains strong, supply chain and logistics constraints continue to be challenging, negatively impacting our sales and results of operations. In addition, results for 2021 reflected a significant rebound in demand after initial weakness associated with the COVID-19 pandemic.

[0001783180-22-000048:mdna:90]
On June 1, 2021, the Commercial HVAC business acquired a 70% controlling interest in Guangdong Giwee Group and its subsidiaries ("Giwee") and subsequently acquired the remaining 30% ownership interest on September 7, 2021. Giwee is a China-based manufacturer offering a portfolio of HVAC products including variable refrigerant flow, modular chillers and light commercial air conditioners. The results of Giwee have been included in our Unaudited Condensed Consolidated Financial

[0001783180-22-000048:mdna:91]
Statements since the date of acquisition. The transaction added 2% to Net sales during the three months ended June 30, 2022. Refer to Note 15 - Acquisitions for additional information.

[0001783180-22-000048:mdna:92]
For the three months ended June 30, 2022, Operating profit in our HVAC segment was $585 million, a 2% increase compared with the same period of 2021. The components of the year-over-year change were as follows:

[0001783180-22-000048:mdna:93]
|  |  | Operating Profit |
| Operational |  | 4 | % |
| Foreign currency translation |  | (1) | % |
| Acquisitions and divestitures, net |  | 1 | % |
| Restructuring |  | 1 | % |
| Other |  | (3) | % |
| Total % change in Operating profit |  | 2 | % |

[0001783180-22-000048:mdna:94]
The operational profit increase of 4% was primarily driven by pricing improvements compared with the prior year. Higher earnings from equity method investments in North America and Asia also benefited operational profit and included a $27 million gain on the sale of two minority owned subsidiaries within one of our joint ventures. In addition, productivity initiatives and lower selling, general and administrative costs provided further benefits. These amounts were partially offset by the higher costs of commodities and components used in our products and higher freight and logistic costs compared with the prior year.

[0001783180-22-000048:mdna:95]
Acquisitions and divestitures, net primarily related to the acquisition of Giwee. The transaction added 1% to Operating profit during the three months ended June 30, 2022. In addition, amounts reported in Other includes a $22 million charge resulting from a litigation matter.

[0001783180-22-000048:mdna:96]
[same as prior period, unchanged from 0001783180-22-000034:mdna:62]

[0001783180-22-000048:mdna:97]
For the three months ended June 30, 2022, Net sales in our Refrigeration segment were $1.0 billion, a 2% increase compared with the same period of 2021. The components of the year-over-year change were as follows:

[0001783180-22-000048:mdna:98]
|  |  | Net Sales |
| Organic |  | 9 | % |
| Foreign currency translation |  | (7) | % |
| Total % change in Net sales |  | 2 | % |

[0001783180-22-000048:mdna:99]
The organic increase in Net sales of 9% was driven by strong demand across each of the segment's businesses. Commercial refrigeration sales increased (8%) primarily due to pricing improvements and higher volumes compared with the prior year. These amounts were partially offset by continued supply chain constraints. Transport refrigeration sales increased (9%) primarily due to pricing improvements and higher volumes associated with component availability during the period. The business saw growth in each region, although sales in China decreased as a result of a resurgence of COVID-19 cases and additional restrictions imposed. The three months ended June 30, 2021 reflected a significant rebound in demand associated with the cyclical decline that began in late 2019 as well as the demand for global transportation and COVID-19 vaccine-related cargo monitoring. While current demand remains strong, supply chain and logistics constraints continue to be challenging, negatively impacting our sales and results of operations.

[0001783180-22-000048:mdna:100]
For the three months ended June 30, 2022, Operating profit in our Refrigeration segment was $147 million, a 20% increase compared with the same period of 2021. The components of the year-over-year change were as follows:

[0001783180-22-000048:mdna:101]
|  |  | Operating Profit |
| Operational |  | 24 | % |
| Foreign currency translation |  | (8) | % |
| Restructuring |  | (2) | % |
| Other |  | 6 | % |
| Total % change in Operating profit |  | 20 | % |

[0001783180-22-000048:mdna:102]
The increase in operational profit of 24% was primarily attributable to pricing improvements compared with the prior year. Higher volumes and favorable productivity initiatives further benefited operational profit. In addition, segment results also reflected lower selling, general and administrative costs during the period. These amounts were partially offset by the higher costs of commodities and components used in our products and higher freight and logistic costs. Amounts reported in Other primarily represent a $7 million gain on the sale of our interest in a cost method investment.

[0001783180-22-000048:mdna:103]
[same as prior period, unchanged from 0001783180-22-000034:mdna:69]

[0001783180-22-000048:mdna:104]
For the three months ended June 30, 2022, Net sales in our Fire & Security segment were $887 million, a 37% decrease compared with the same period of 2021. The components of the year-over-year change were as follows:

[0001783180-22-000048:mdna:105]
|  |  | Net Sales |
| Organic |  | 3 | % |
| Foreign currency translation |  | (2) | % |
| Acquisitions and divestitures, net |  | (38) | % |
| Total % change in Net sales |  | (37) | % |

[0001783180-22-000048:mdna:106]
The organic increase in Net sales of 3% was primarily driven by pricing improvements compared with the prior year. The segment primarily saw growth in both residential and commercial sales in the Americas and Europe as sales in China decreased as a result of a resurgence of COVID-19 cases and additional restrictions imposed. Global industrial sales also benefited segment results. While current demand remains strong, supply chain constraints continue to be challenging, negatively impacting our sales and results of operations. In addition, results for 2021 reflected a significant rebound in demand after initial weakness associated with the COVID-19 pandemic.

[0001783180-22-000048:mdna:107]
Acquisitions and divestitures, net primarily relates to the prior year results of our Chubb business, the sale of which was completed on January 3, 2022. During the three months ended June 30, 2021, Net sales in our Fire & Security segment were $1.4 billion, which included $554 million from our Chubb business. Absent the results of Chubb, Net sales increased 4% from $849 million to $887 million.

[0001783180-22-000048:mdna:108]
For the three months ended June 30, 2022, Operating profit in our Fire & Security segment was $134 million, a 9% decrease compared with the same period of 2021. The components of the year-over-year change were as follows:

[0001783180-22-000048:mdna:109]
|  |  | Operating Profit |
| Operational |  | (7) | % |
| Foreign currency translation |  | (2) | % |
| Acquisitions and divestitures, net |  | (6) | % |
| Restructuring |  | 4 | % |
| Other |  | 2 | % |
| Total % change in Operating profit |  | (9) | % |

[0001783180-22-000048:mdna:110]
The decrease in operational profit of 7% was primarily attributable to the higher costs of commodities and components used in our products and higher freight and logistics costs. In addition, unfavorable mix and lower volumes further impacted results compared with the prior year. These amounts were partially offset by pricing improvements.

[0001783180-22-000048:mdna:111]
Acquisitions and divestitures, net primarily relates to the prior year results of our Chubb business, the sale of which was completed on January 3, 2022. Amounts reported during the three months ended June 30, 2021 include $12 million of transaction costs associated with the divestiture.

[0001783180-22-000048:mdna:112]
Six Months Ended June 30, 2022 Compared with Six Months Ended June 30, 2021

[0001783180-22-000048:mdna:113]
| Summary performance for each of our segments is as follows: |
|  | Net Sales |  | Operating Profit |  | Operating Profit Margin |
|  | For the Six Months Ended June 30, |  | For the Six Months Ended June 30, |  | For the Six Months Ended June 30, |
| (In millions) | 2022 |  | 2021 |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| HVAC | $ | 6,358 |  |  | $ | 5,606 |  |  | $ | 1,055 |  |  | $ | 938 |  |  | 16.6 | % |  | 16.7 | % |
| Refrigeration | 2,017 |  |  | 2,026 |  |  | 254 |  |  | 250 |  |  | 12.6 | % |  | 12.3 | % |
| Fire & Security | 1,705 |  |  | 2,707 |  |  | 1,352 |  |  | 298 |  |  | 79.3 | % |  | 11.0 | % |
| Total segment | $ | 10,080 |  |  | $ | 10,339 |  |  | $ | 2,661 |  |  | $ | 1,486 |  |  | 26.4 | % |  | 14.4 | % |

[0001783180-22-000048:mdna:114]
HVAC Segment

[0001783180-22-000048:mdna:115]
For the six months ended June 30, 2022, Net sales in our HVAC segment were $6.4 billion, a 13% increase compared with the same period of 2021. The components of the year-over-year change were as follows:

[0001783180-22-000048:mdna:116]
|  |  | Net Sales |
| Organic |  | 12 | % |
| Foreign currency translation |  | (1) | % |
| Acquisitions and divestitures, net |  | 3 | % |
| Other |  | (1) | % |
| Total % change in Net sales |  | 13 | % |

[0001783180-22-000048:mdna:117]
The organic increase in Net sales of 12% was driven by continued strong results across each of the segment's businesses. Increased sales in our North America residential and light commercial business (19%) were driven by pricing improvements and strong end-market demand. Increased sales in our Commercial HVAC business (5%) benefited from pricing improvements and ongoing customer demand in our end-markets. The business saw growth in each region, although sales in China decreased as a result of a resurgence of COVID-19 cases and additional restrictions imposed. While current demand remains strong, supply chain and logistics constraints continue to be challenging, negatively impacting our sales and results of operations. In addition, results for 2021 reflected a significant rebound in demand after initial weakness associated with the COVID-19 pandemic.

[0001783180-22-000048:mdna:118]
On June 1, 2021, the Commercial HVAC business acquired a 70% controlling interest in Giwee and subsequently acquired the remaining 30% ownership interest on September 7, 2021. The results of Giwee have been included in our Unaudited Condensed Consolidated Financial Statements since the date of acquisition. The transaction added 3% to Net sales during the six months ended June 30, 2022. Refer to Note 15 - Acquisitions for additional information.

[0001783180-22-000048:mdna:119]
For the six months ended June 30, 2022, Operating profit in our HVAC segment was $1.1 billion, a 12% increase compared with the same period of 2021. The components of the year-over-year change were as follows:

[0001783180-22-000048:mdna:120]
|  |  |  | Operating Profit |
| Operational |  |  | 14 | % |
| Foreign currency translation |  |  | (1) | % |
| Restructuring |  |  | 1 | % |
| Other |  |  | (2) | % |
| Total % change in Operating profit |  |  | 12 | % |

[0001783180-22-000048:mdna:121]
36

[0001783180-22-000048:mdna:122]
The operational profit increase of 14% was primarily attributable to pricing improvements compared with the prior year. Higher earnings from equity method investments in North America and Asia also benefited operational profit and included a $27 million gain on the sale of two minority owned subsidiaries within one of our joint ventures. In addition, productivity initiatives and lower selling, general and administrative costs provided further benefits. These amounts were partially offset by the higher costs of commodities and components used in our products and higher freight and logistic costs. Amounts reported in Other includes a $22 million charge resulting from a litigation matter.

[0001783180-22-000048:mdna:123]
Refrigeration Segment

[0001783180-22-000048:mdna:124]
For the six months ended June 30, 2022, Net sales in our Refrigeration segment were $2.0 billion, no change compared with the same period of 2021. The components of the year-over-year change were as follows:

[0001783180-22-000048:mdna:125]
|  |  | Net Sales |
| Organic |  | 5 | % |
| Foreign currency translation |  | (5) | % |
| Total % change in Net sales |  | — | % |

[0001783180-22-000048:mdna:126]
The organic increase in Net sales of 5% was driven by strong demand across each of the segment's businesses. Commercial refrigeration sales increased (6%) primarily due to pricing improvements and strong demand compared with the prior year. These amounts were partially offset by continued supply chain constraints. Transport refrigeration sales increased (4%) primarily due to priceing improvements and higher volumes associated with component availability during the period. The six months ended June 30, 2021 reflected a significant rebound in demand associated with the cyclical decline that began in late 2019 as well as the demand for global transportation and COVID-19 vaccine-related cargo monitoring. While current demand remains strong, supply chain and logistics constraints continue to be challenging, negatively impacting our sales and results of operations.

[0001783180-22-000048:mdna:127]
For the six months ended June 30, 2022, Operating profit in our Refrigeration segment was $254 million, a 2% increase compared with the same period of 2021. The components of the year-over-year change were as follows:

[0001783180-22-000048:mdna:128]
|  |  |  | Operating Profit |
| Operational |  |  | 7 | % |
| Foreign currency translation |  |  | (6) | % |
| Other |  |  | 1 | % |
| Total % change in Operating profit |  |  | 2 | % |

[0001783180-22-000048:mdna:129]
The increase in operational profit of 7% was primarily attributable to pricing improvements compared with the prior year. Higher volumes and favorable productivity initiatives further benefited operational profit. In addition, segment results also reflected lower selling, general and administrative costs during the period. These amounts were partially offset by the higher costs of commodities and components used in our products and higher freight and logistic costs. Amounts reported in Other primarily represent a $7 million gain on the sale of our interest in a cost method investment.

[0001783180-22-000048:mdna:130]
Fire & Security Segment

[0001783180-22-000048:mdna:131]
For the six months ended June 30, 2022, Net sales in our Fire & Security segment were $1.7 billion, a 37% decrease compared with the same period of 2021. The components of the year-over-year change were as follows:

[0001783180-22-000048:mdna:132]
|  |  | Net Sales |
| Organic |  | 4 | % |
| Foreign currency translation |  | (2) | % |
| Acquisitions and divestitures, net |  | (39) | % |
| Total % change in Net sales |  | (37) | % |

[0001783180-22-000048:mdna:133]
The organic increase in Net sales of 4% was primarily driven by pricing improvements compared with the prior year. The segment primarily saw growth in both residential and commercial sales in the Americas and Europe as sales in China decreased as a result of a resurgence of COVID-19 cases and additional restrictions imposed. Global industrial sales also benefited

[0001783180-22-000048:mdna:134]
37

[0001783180-22-000048:mdna:135]
segment results. While current demand remains strong, supply chain constraints continue to be challenging, negatively impacting our sales and results of operations. In addition, results for 2021 reflected a significant rebound in demand after initial weakness associated with the COVID-19 pandemic.

[0001783180-22-000048:mdna:136]
Acquisitions and divestitures, net primarily relates to the prior year results of our Chubb business, the sale of which was completed on January 3, 2022. During the six months ended June 30, 2021, Net sales in our Fire & Security segment were $2.7 billion, which included $1.1 billion from our Chubb business. Absent the results of Chubb, Net sales increased 6% from $1.6 billion to $1.7 billion.

[0001783180-22-000048:mdna:137]
For the six months ended June 30, 2022, Operating profit in our Fire & Security segment was $1.4 billion, a 354% increase compared with the same period of 2021. The components of the year-over-year change were as follows:

[0001783180-22-000048:mdna:138]
|  |  |  | Operating Profit |
| Operational |  |  | (7) | % |
| Foreign currency translation |  |  | (2) | % |
| Acquisitions and divestitures, net |  |  | (15) | % |
| Restructuring |  |  | 4 | % |
| Other |  |  | 374 | % |
| Total % change in Operating profit |  |  | 354 | % |

[0001783180-22-000048:mdna:139]
The decrease in operational profit of 7% was primarily attributable to the higher costs of commodities and components used in our products and higher freight and logistics costs. In addition, unfavorable mix and lower volumes further impacted results compared with the prior year. These amounts were partially offset by pricing improvements.

[0001783180-22-000048:mdna:140]
Acquisitions and divestitures, net primarily relates to the prior year results of our Chubb business, the sale of which was completed on January 3, 2022. Amounts reported during the six months ended June 30, 2021 include $15 million of transaction costs associated with the divestiture. Amounts reported in Other represent the net gain on the Chubb Sale of $1.1 billion.

[0001783180-22-000048:mdna:141]
[same as prior period, unchanged from 0001783180-22-000034:mdna:79]

[0001783180-22-000048:mdna:142]
[same as prior period, unchanged from 0001783180-22-000034:mdna:80]

[0001783180-22-000048:mdna:143]
As of June 30, 2022, we had cash and cash equivalents of $3.0 billion, of which approximately 29% was held by our foreign subsidiaries. We manage our worldwide cash requirements by reviewing available funds and the cost effectiveness with which we can access funds held by foreign subsidiaries. On occasion, we are required to maintain cash deposits in connection with contractual obligations related to acquisitions, divestitures or other legal obligations. As of June 30, 2022 and December 31, 2021, the amount of such restricted cash was approximately $8 million and $39 million, respectively.

[0001783180-22-000048:mdna:144]
We maintain a $2.0 billion unsecured, unsubordinated commercial paper program which can be used for general corporate purposes, including working capital and potential acquisitions. In addition, we maintain our $2.0 billion Revolving Credit Facility that matures on April 3, 2025 which supports our commercial paper borrowing program and cash requirements. The Revolving Credit Facility has a commitment fee of 0.125% that is charged on unused commitments. Borrowings under the Revolving Credit Facility are available in U.S. Dollars, Euros and Pounds Sterling and bear interest at a variable interest rate plus a ratings-based margin, which was 125 basis points as of June 30, 2022. As of June 30, 2022, we had no borrowings outstanding under our commercial paper program and our Revolving Credit Facility.

[0001783180-22-000048:mdna:145]
[same as prior period, unchanged from 0001783180-22-000034:mdna:83]

[0001783180-22-000048:mdna:146]
[same as prior period, unchanged from 0001783180-22-000034:mdna:84]

[0001783180-22-000048:mdna:147]
The Revolving Credit Facility and the indentures for the long-term notes contain affirmative and negative covenants customary for financings of these types, which among other things, limit our ability to incur additional liens, to make certain fundamental changes and to enter into sale and leaseback transactions. As of June 30, 2022, we were in compliance with the covenants under the agreements governing our outstanding indebtedness.

[0001783180-22-000048:mdna:148]
The following table presents our credit ratings and outlook as of June 30, 2022:

[0001783180-22-000048:mdna:149]
| Rating Agency |  | Long-term Rating (1) |  | Short-term Rating |  | Outlook (2) |
| Standards & Poor's ("S&P") |  | BBB |  | A2 |  | Positive |
| Moody's Investor Services, Inc. ("Moody's") |  | Baa3 |  | P3 |  | Stable |
| Fitch Ratings ("Fitch") |  | BBB- |  | F3 |  | Stable |

[0001783180-22-000048:mdna:150]
[same as prior period, unchanged from 0001783180-22-000034:mdna:88]

[0001783180-22-000048:mdna:151]
(2) S&P revised its outlook to positive from stable on May 20, 2022.

[0001783180-22-000048:mdna:152]
[same as prior period, unchanged from 0001783180-22-000034:mdna:90]

[0001783180-22-000048:mdna:153]
| (In millions) |  | June 30,2022 |  | December 31,2021 |
| Cash and cash equivalents |  | $ | 3,017 |  |  | $ | 2,987 |  |
| Total debt |  | $ | 8,567 |  |  | $ | 9,696 |  |
| Total equity |  | $ | 6,992 |  |  | $ | 7,094 |  |
| Net debt (total debt less cash and cash equivalents) |  | $ | 5,550 |  |  | $ | 6,709 |  |
| Total capitalization (total debt plus total equity) |  | $ | 15,559 |  |  | $ | 16,790 |  |
| Net capitalization (total debt plus total equity less cash and cash equivalents) |  | $ | 12,542 |  |  | $ | 13,803 |  |
| Total debt to total capitalization |  | 55 | % |  | 58 | % |
| Net debt to net capitalization |  | 44 | % |  | 49 | % |

[0001783180-22-000048:mdna:154]
[same as prior period, unchanged from 0001783180-22-000034:mdna:92]

[0001783180-22-000048:mdna:155]
Our short-term obligations primarily consist of current maturities of long-term debt. Our long-term obligations primarily consist of long-term notes with maturity dates ranging between 2025 and 2050. Interest payments related to long-term Notes are expected to approximate $247 million per year, reflecting an approximate weighted-average interest rate of 2.95%. Any borrowings from the Revolving Credit Facility are subject to variable interest rates. See Note 5 – Borrowings and Lines of Credit in the Notes to the Unaudited Condensed Consolidated Financial Statements for additional information regarding the terms of our long-term debt obligations.

[0001783180-22-000048:mdna:156]
On March 15, 2022, we commenced tender offers to repurchase up to $1.15 billion aggregate principal of our 2.242% Notes due 2025 and 2.493% Notes due 2027. The tender offers included payment of applicable accrued and unpaid interest up to the settlement date, along with a fixed spread for early repayment. Based on participation, we elected to settle the tender offers on March 30, 2022. The aggregate principal amount of Senior Notes validly tendered and accepted was approximately $1.15 billion and included $800 million of Notes due 2025 and $350 million of Notes due 2027. Upon settlement, we recognized a net gain of $33 million and wrote off $5 million of unamortized deferred financing costs during the three months ended March 31, 2022.

[0001783180-22-000048:mdna:157]
39

[0001783180-22-000048:mdna:158]
[same as prior period, unchanged from 0001783180-22-000034:mdna:95]

[0001783180-22-000048:mdna:159]
On January 3, 2022, we completed the Chubb Sale for net proceeds of $2.9 billion. Consistent with our capital allocation strategy, the net proceeds will be used to fund investments in organic and inorganic growth initiatives and capital returns to shareowners as well as for general corporate purposes. The sale agreement included several customary provisions to settle working capital and other transaction-related items as of the date of sale. As of June 30, 2022, both parties are in the process of finalizing these amounts in accordance with established timelines.

[0001783180-22-000048:mdna:160]
During the three months ended June 30, 2022, we acquired consolidated businesses and minority-owned businesses. The aggregate cash paid for acquisitions, net of cash acquired, totaled $38 million and was funded through cash on hand. See Note 15 – Acquisitions for additional information.

[0001783180-22-000048:mdna:161]
On February 6, 2022, we entered into a binding agreement to acquire a majority ownership interest in TCC for approximately $900 million. The transaction is expected to close in early August, subject to customary closing conditions, including regulatory approvals. Upon closing, Toshiba Corporation will retain a 5% ownership interest in TCC. The acquisition is expected to be funded through a combination of cash on hand and a $400 million Yen denominated term loan.

[0001783180-22-000048:mdna:162]
[same as prior period, unchanged from 0001783180-22-000034:mdna:99]

[0001783180-22-000048:mdna:163]
We may purchase our outstanding common stock from time to time subject to market conditions and at our discretion in the open market or through one or more other public or private transactions and subject to compliance with our obligations under certain tax agreements. In July 2021, our Board of Directors approved a $1.75 billion increase to our existing $350 million share repurchase program authorizing the repurchase of up to $2.1 billion of our outstanding common stock. During the six months ended June 30, 2022, we repurchased 22.7 million shares of our common stock for an aggregate purchase price of $1.0 billion, which includes shares repurchased under the ASR Agreement. As of June 30, 2022, we have approximately $557 million remaining under the current authorization.

[0001783180-22-000048:mdna:164]
[same as prior period, unchanged from 0001783180-22-000034:mdna:103]

[0001783180-22-000048:mdna:165]
We paid dividends on common stock during the six months ended June 30, 2022, totaling $257 million. On June 9, 2022, the Board of Directors declared a dividend of $0.15 per share of common stock payable on August 10, 2022 to shareowners of record at the close of business on June 23, 2022.

[0001783180-22-000048:mdna:166]
[same as prior period, unchanged from 0001783180-22-000034:mdna:105]

[0001783180-22-000048:mdna:167]
|  |  | For the Six Months Ended June 30, |
| (In millions) |  | 2022 |  | 2021 |
| Net cash flows provided by (used in): |  |  |  |  |
| Operating activities |  | $ | (170) |  |  | $ | 745 |  |
| Investing activities |  | 2,645 |  |  | (301) |  |
| Financing activities |  | (2,434) |  |  | (898) |  |
| Effect of foreign exchange rate changes on cash and cash equivalents |  | (41) |  |  | (2) |  |
| Net increase (decrease) in cash and cash equivalents and restricted cash |  | $ | — |  |  | $ | (456) |  |

[0001783180-22-000048:mdna:168]
[same as prior period, unchanged from 0001783180-22-000034:mdna:107]

[0001783180-22-000048:mdna:169]
Cash flows from investing activities primarily represent inflows and outflows associated with long-term assets. Primary activities include capital expenditures, acquisitions, divestitures and proceeds from the sale of fixed assets. During the six months ended June 30, 2022, net cash provided by investing activities was $2.6 billion. The primary driver of the inflow related to the net proceeds from the Chubb Sale. This amount was partially offset by the acquisition of several businesses and minority-owned businesses, which totaled $38 million, net of cash acquired and $122 million of capital expenditures. During the six months ended June 30, 2021, net cash used in investing activities was $301 million. The primary drivers of the outflow related

[0001783180-22-000048:mdna:170]
40

[0001783180-22-000048:mdna:171]
to the acquisition of several businesses and investment in a joint venture, which totaled $167 million, net of cash acquired and $132 million of capital expenditures.

[0001783180-22-000048:mdna:172]
Cash flows from financing activities primarily represent inflows and outflows associated with equity or borrowings. During the six months ended June 30, 2022, net cash used in financing activities was $2.4 billion. The primary driver of the outflow related to the settlement of our tender offers for $1.15 billion. In addition, we paid $257 million in dividends to our common shareowners and paid $1.0 billion to repurchase shares of our common stock. During the six months ended June 30, 2021, net cash used in financing activities was $898 million. The primary driver of the outflow related to the redemption of long-term notes of $500 million. In addition, we paid $209 million in dividends to our common shareowners and paid $130 million to repurchase shares of our common stock.
