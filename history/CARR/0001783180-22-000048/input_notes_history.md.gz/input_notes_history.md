# CARR note change history — 0001783180-22-000034 → 0001783180-22-000048


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-07-28):
[0001783180-22-000048:note_history:1]
COMMITMENTS AND CONTINGENT LIABILITIES
The Company is involved in various litigation, claims and administrative proceedings, including those related to environmental (including asbestos) and legal matters. In accordance with ASC 450, Contingencies, the Company records accruals for loss contingencies when it is probable that a liability will be incurred and the amount of the loss can be reasonably estimated. These accruals are generally based upon a range of possible outcomes. If no amount within the range is a better estimate than any other, the Company accrues the minimum amount. In addition, these estimates are reviewed periodically and adjusted to reflect additional information when it becomes available. The Company is unable to predict the final outcome of the following matters based on the information currently available, except as otherwise noted. However, the Company does not believe that the resolution of any of these matters will have a material adverse effect upon the Company's competitive position, results of operations, cash flows or financial condition.
  (was, 2022-04-28, similarity 0.9833):
[0001783180-22-000034:note_history:1]
COMMITMENTS AND CONTINGENT LIABILITIES
The Company is involved in various litigation, claims and administrative proceedings, including those related to environmental and legal matters (including asbestos). In accordance with ASC 450, Contingencies, the Company records accruals for loss contingencies when it is probable that a liability will be incurred and the amount of the loss can be reasonably estimated. These accruals are generally based upon a range of possible outcomes. If no amount within the range is a better estimate than any other, the Company accrues the minimum amount. In addition, these estimates are reviewed periodically and adjusted to reflect additional information when it becomes available. The Company is unable to predict the final outcome of the following matters based on the information currently available, except as otherwise noted. However, the Company does not believe that the resolution of any of these matters will have a material adverse effect upon the Company's competitive position, results of operations, cash flows or financial condition.

- changed (2022-07-28):
[0001783180-22-000048:note_history:2]
| (In millions) |  | June 30,2022 |  | December 31, 2021 |
| Environmental reserves included in Accrued liabilities |  | $ | 29 |  |  | $ | 29 |  |
| Environmental reserves included in Other long-term liabilities |  | 187 |  |  | 191 |  |
| Total Environmental reserves |  | $ | 216 |  |  | $ | 220 |  |
  (was, 2022-04-28, similarity 0.9832):
[0001783180-22-000034:note_history:2]
| (In millions) |  | March 31,2022 |  | December 31, 2021 |
| Environmental reserves included in Accrued liabilities |  | $ | 29 |  |  | $ | 29 |  |
| Environmental reserves included in Other long-term liabilities |  | 189 |  |  | 191 |  |
| Total Environmental reserves |  | $ | 218 |  |  | $ | 220 |  |

- changed (2022-07-28):
[0001783180-22-000048:note_history:3]
| (In millions) |  | June 30,2022 |  | December 31,2021 |
| Asbestos liabilities included in Accrued liabilities |  | $ | 17 |  |  | $ | 17 |  |
| Asbestos liabilities included in Other long-term liabilities |  | 215 |  |  | 220 |  |
| Total Asbestos liabilities |  | $ | 232 |  |  | $ | 237 |  |
| Asbestos-related recoveries included in Other assets, current |  | $ | 5 |  |  | $ | 5 |  |
| Asbestos-related recoveries included in Other assets |  | 92 |  |  | 93 |  |
| Total Asbestos-related recoveries |  | $ | 97 |  |  | $ | 98 |  |
  (was, 2022-04-28, similarity 0.9907):
[0001783180-22-000034:note_history:3]
| (In millions) |  | March 31,2022 |  | December 31,2021 |
| Asbestos liabilities included in Accrued liabilities |  | $ | 17 |  |  | $ | 17 |  |
| Asbestos liabilities included in Other long-term liabilities |  | 219 |  |  | 220 |  |
| Total Asbestos liabilities |  | $ | 236 |  |  | $ | 237 |  |
| Asbestos-related recoveries included in Other assets, current |  | $ | 5 |  |  | $ | 5 |  |
| Asbestos-related recoveries included in Other assets |  | 92 |  |  | 93 |  |
| Total Asbestos-related recoveries |  | $ | 97 |  |  | $ | 98 |  |

- changed (2022-07-28):
[0001783180-22-000048:note_history:4]
On August 12, 2020, several former employees of UTC or its subsidiaries filed a putative class action complaint (the "Complaint") in the United States District Court for the District of Connecticut against Raytheon Technologies Corporation, Carrier, Otis, the former members of the UTC Board of Directors and the members of the Carrier and Otis Boards of Directors (Geraud Darnis, et al. v. Raytheon Technologies Corporation, et al.). The Complaint challenges the method by which UTC equity awards were converted to UTC, Carrier and Otis equity awards following the Separation and the Distribution. Defendants moved to dismiss the Complaint. Plaintiffs amended their Complaint on September 13, 2021 (the "Amended Complaint"). The Amended Complaint, now with Raytheon, Carrier and Otis as the only defendants, asserts that the defendants are liable for breach of certain equity compensation plans and for breach of the implied covenant of good faith and fair dealing. The Amended Complaint also seeks specific performance. Carrier believes that the claims against the Company are without merit. Defendants moved to dismiss the Amended Complaint on October 13, 2021. The motion to dismiss was fully briefed as of December 3, 2021 and the court held oral argument on the motion on July 14, 2022.
  (was, 2022-04-28, similarity 0.9528):
[0001783180-22-000034:note_history:4]
On August 12, 2020, several former employees of UTC or its subsidiaries filed a putative class action complaint (the "Complaint") in the United States District Court for the District of Connecticut against Raytheon Technologies Corporation, Carrier, Otis, the former members of the UTC Board of Directors and the members of the Carrier and Otis Boards of Directors (Geraud Darnis, et al. v. Raytheon Technologies Corporation, et al.). The Complaint challenges the method by which UTC equity awards were converted to UTC, Carrier and Otis equity awards following the Separation and the Distribution. Defendants moved to dismiss the Complaint. Plaintiffs amended their Complaint on September 13, 2021 ("the Amended Complaint"). The Amended Complaint, now with Raytheon, Carrier and Otis as the only defendants, asserts that the defendants are liable for breach of certain equity compensation plans and for breach of the implied covenant of good faith and fair dealing. The Amended Complaint also seeks specific performance. Carrier believes that the claims against the Company are without merit. Defendants moved to dismiss the Amended Complaint on October 13, 2021. The motion was fully briefed as of December 3, 2021. The court has not scheduled arguments or decided the motion.

- changed (2022-07-28):
[0001783180-22-000048:note_history:5]
As of June 30, 2022, the Company has been named as a defendant in more than 2,400 lawsuits filed by individuals in or removed to the federal courts of the United States alleging that the historic use of Aqueous Film Forming Foam ("AFFF") caused personal injuries and/or property damage. The Company has also been named as a defendant in more than 200 lawsuits filed by several U.S. states, municipalities and water utilities in or removed to U.S. federal courts alleging that the historic use of AFFF caused contamination of property and water supplies. In December 2018, the U.S. Judicial Panel on Multidistrict Litigation transferred and consolidated all AFFF cases pending in the U.S. federal courts against the Company and others to the U.S. District Court for the District of South Carolina ("MDL Court") for pre-trial proceedings ("MDL Proceedings"). The individual plaintiffs in the MDL Proceedings generally seek damages for alleged personal injuries, medical monitoring and diminution in property value and injunctive relief to remediate alleged contamination of water supplies. The U.S. state, municipal and water utility plaintiffs in the MDL Proceedings generally seek damages and costs related to the remediation of public property and water supplies.
  (was, 2022-04-28, similarity 0.9964):
[0001783180-22-000034:note_history:5]
As of March 31, 2022, the Company has been named as a defendant in more than 2,200 lawsuits filed by individuals in or removed to the federal courts of the United States alleging that the historic use of Aqueous Film Forming Foam ("AFFF") caused personal injuries and/or property damage. The Company has also been named as a defendant in more than 160 lawsuits filed by several U.S. states, municipalities and water utilities in or removed to U.S. federal courts alleging that the historic use of AFFF caused contamination of property and water supplies. In December 2018, the U.S. Judicial Panel on Multidistrict Litigation transferred and consolidated all AFFF cases pending in the U.S. federal courts against the Company and others to the U.S. District Court for the District of South Carolina ("MDL Court") for pre-trial proceedings ("MDL Proceedings"). The individual plaintiffs in the MDL Proceedings generally seek damages for alleged personal injuries, medical monitoring and diminution in property value and injunctive relief to remediate alleged contamination of water supplies. The U.S. state, municipal and water utility plaintiffs in the MDL Proceedings generally seek damages and costs related to the remediation of public property and water supplies.

- changed (2022-07-28):
[0001783180-22-000048:note_history:6]
General liability discovery in the MDL Proceedings continues. Preliminary stage discovery in ten "bellwether" water provider cases was concluded and three of these cases were selected for tier two site-specific discovery. That discovery is ongoing. The MDL Court previously established a briefing schedule with respect to certain aspects of the government contractor defense, potentially applicable to AFFF sold to or used by the U.S. government or other customers requiring product manufactured to meet military specification, with briefing to conclude at the end of January 2022 with a hearing to follow in late March. In late March, the MDL Court postponed the planned hearing and called for briefing on additional elements of the government contractor defense. Briefing was completed as of July 1, 2022. An oral argument is now scheduled on August 19, 2022.
  (was, 2022-04-28, similarity 0.9472):
[0001783180-22-000034:note_history:6]
General liability discovery in the MDL Proceedings continues. Preliminary stage discovery in ten "bellwether" water provider cases was concluded and three of these cases were selected for tier two site-specific discovery. That discovery is ongoing. The MDL Court previously established a briefing schedule with respect to certain aspects of the government contractor defense, potentially applicable to AFFF sold to or used by the U.S. government or other customers requiring product manufactured to meet military specification, with briefing to conclude at the end of January 2022 with a hearing to follow in late March. In late March the MDL Court postponed the planned hearing and called for briefing on additional elements of the government contractor defense. Briefing will continue through July 1, 2022.

- changed (2022-07-28):
[0001783180-22-000048:note_history:7]
Under the Tax Matters Agreement relating to the Separation, the Company is responsible to UTC for its share of the Tax Cuts and Jobs Act ("TCJA") transition tax associated with foreign undistributed earnings as of December 31, 2017. As a result, liabilities of $34 million and $383 million are included within the accompanying Unaudited Condensed Consolidated Balance Sheet within Accrued Liabilities and Other Long-Term Liabilities as of June 30, 2022, respectively. This obligation is expected to be settled in annual installments ending in April 2026 with the next installment of $34 million due in 2023. The Company believes that the likelihood of incurring losses materially in excess of this amount is remote.
  (was, 2022-04-28, similarity 0.9271):
[0001783180-22-000034:note_history:7]
Under the Tax Matters Agreement relating to the Separation, the Company is responsible to UTC for its share of the Tax Cuts and Jobs Act ("TCJA") transition tax associated with foreign undistributed earnings as of December 31, 2017. As a result, a liability of $417 million is included within the accompanying Unaudited Condensed Consolidated Balance Sheet within Other Long-Term Liabilities as of March 31, 2022. This obligation is expected to be settled in annual installments ending in April 2026 with the next installment of $34 million due in 2023. The Company believes that the likelihood of incurring losses materially in excess of this amount is remote.


## us-gaap:ScheduleOfEnvironmentalLossContingenciesBySiteTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-07-28):
[0001783180-22-000048:note_history:8]
| (In millions) |  | June 30,2022 |  | December 31, 2021 |
| Environmental reserves included in Accrued liabilities |  | $ | 29 |  |  | $ | 29 |  |
| Environmental reserves included in Other long-term liabilities |  | 187 |  |  | 191 |  |
| Total Environmental reserves |  | $ | 216 |  |  | $ | 220 |  |
  (was, 2022-04-28, similarity 0.9832):
[0001783180-22-000034:note_history:8]
| (In millions) |  | March 31,2022 |  | December 31, 2021 |
| Environmental reserves included in Accrued liabilities |  | $ | 29 |  |  | $ | 29 |  |
| Environmental reserves included in Other long-term liabilities |  | 189 |  |  | 191 |  |
| Total Environmental reserves |  | $ | 218 |  |  | $ | 220 |  |


## us-gaap:ScheduleOfLossContingenciesByContingencyTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-07-28):
[0001783180-22-000048:note_history:9]
| (In millions) |  | June 30,2022 |  | December 31,2021 |
| Asbestos liabilities included in Accrued liabilities |  | $ | 17 |  |  | $ | 17 |  |
| Asbestos liabilities included in Other long-term liabilities |  | 215 |  |  | 220 |  |
| Total Asbestos liabilities |  | $ | 232 |  |  | $ | 237 |  |
| Asbestos-related recoveries included in Other assets, current |  | $ | 5 |  |  | $ | 5 |  |
| Asbestos-related recoveries included in Other assets |  | 92 |  |  | 93 |  |
| Total Asbestos-related recoveries |  | $ | 97 |  |  | $ | 98 |  |
  (was, 2022-04-28, similarity 0.9907):
[0001783180-22-000034:note_history:9]
| (In millions) |  | March 31,2022 |  | December 31,2021 |
| Asbestos liabilities included in Accrued liabilities |  | $ | 17 |  |  | $ | 17 |  |
| Asbestos liabilities included in Other long-term liabilities |  | 219 |  |  | 220 |  |
| Total Asbestos liabilities |  | $ | 236 |  |  | $ | 237 |  |
| Asbestos-related recoveries included in Other assets, current |  | $ | 5 |  |  | $ | 5 |  |
| Asbestos-related recoveries included in Other assets |  | 92 |  |  | 93 |  |
| Total Asbestos-related recoveries |  | $ | 97 |  |  | $ | 98 |  |


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2022-07-28):
[0001783180-22-000048:note_history:10]
On April 3, 2020, United Technologies Corporation, since renamed Raytheon Technologies Corporation ("UTC"), completed the spin-off of the Company into an independent, publicly traded company (the "Separation") through a pro-rata distribution (the "Distribution") on a one-for-one basis of all of the outstanding shares of common stock of the Company to UTC shareowners who held shares of UTC common stock as of the close of business on March 19, 2020, the record date of the Distribution. The Company incurred separation-related costs including employee-related costs, costs to establish certain stand-alone functions, information technology systems, professional service fees and other costs associated with becoming an independent, publicly traded company. These costs are primarily recorded in Selling, general and administrative in the Unaudited Condensed Consolidated Statement of Operations and totaled $3 million and $19 million for the three and six months ended June 30, 2021, respectively.
  (was, 2022-04-28, similarity 0.947):
[0001783180-22-000034:note_history:10]
On April 3, 2020, United Technologies Corporation, since renamed Raytheon Technologies Corporation ("UTC"), completed the spin-off of the Company into an independent, publicly traded company (the "Separation") through a pro-rata distribution (the "Distribution") on a one-for-one basis of all of the outstanding shares of common stock of the Company to UTC shareowners who held shares of UTC common stock as of the close of business on March 19, 2020, the record date of the Distribution. The Company incurred separation-related costs including employee-related costs, costs to establish certain stand-alone functions, information technology systems, professional service fees and other costs associated with becoming an independent, publicly traded company. These costs are primarily recorded in Selling, general and administrative in the Unaudited Condensed Consolidated Statement of Operations and totaled $16 million for the three months ended March 31, 2021.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2022-07-28):
[0001783180-22-000048:note_history:11]
DESCRIPTION OF THE BUSINESS 
Carrier Global Corporation is the leading global provider of healthy, safe, sustainable and intelligent building and cold chain solutions. The Company's portfolio includes industry-leading brands such as Carrier, Automated Logic, Carrier Transicold, Kidde, Edwards and LenelS2 that offer innovative heating, ventilating, air conditioning ("HVAC"), refrigeration, fire, security and building automation technologies to help make the world safer and more comfortable. The Company also provides a broad array of related building services, including audit, design, installation, system integration, repair, maintenance and monitoring.
  (was, 2022-04-28, similarity 0.997):
[0001783180-22-000034:note_history:11]
DESCRIPTION OF THE BUSINESS 
Carrier Global Corporation is a leading global provider of healthy, safe, sustainable and intelligent building and cold chain solutions. The Company's portfolio includes industry-leading brands such as Carrier, Automated Logic, Carrier Transicold, Kidde, Edwards and LenelS2 that offer innovative heating, ventilating, air conditioning ("HVAC"), refrigeration, fire, security and building automation technologies to help make the world safer and more comfortable. The Company also provides a broad array of related building services, including audit, design, installation, system integration, repair, maintenance and monitoring.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-07-28):
[0001783180-22-000048:note_history:12]
| (In millions) |  |  |  | June 30,2022 |  | December 31,2021 |
| 2.242% Notes due February 15, 2025 |  |  |  | $ | 1,200 |  |  | $ | 2,000 |  |
| 2.493% Notes due February 15, 2027 |  |  |  | 900 |  |  | 1,250 |  |
| 2.722% Notes due February 15, 2030 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.700% Notes due February 15, 2031 |  |  |  | 750 |  |  | 750 |  |
| 3.377% Notes due April 5, 2040 |  |  |  | 1,500 |  |  | 1,500 |  |
| 3.577% Notes due April 5, 2050 |  |  |  | 2,000 |  |  | 2,000 |  |
| Total long-term Notes |  |  |  | 8,350 |  |  | 9,500 |  |
| Other debt (including project financing obligations and finance leases) |  |  |  | 279 |  |  | 267 |  |
| Discounts and debt issuance costs |  |  |  | (62) |  |  | (71) |  |
| Total debt |  |  |  | 8,567 |  |  | 9,696 |  |
| Less: current portion of long-term debt |  |  |  | 269 |  |  | 183 |  |
| Long-term debt, net of current portion |  |  |  | $ | 8,298 |  |  | $ | 9,513 |  |
  (was, 2022-04-28, similarity 0.9938):
[0001783180-22-000034:note_history:12]
| (In millions) |  |  |  | March 31,2022 |  | December 31,2021 |
| 2.242% Notes due February 15, 2025 |  |  |  | $ | 1,200 |  |  | $ | 2,000 |  |
| 2.493% Notes due February 15, 2027 |  |  |  | 900 |  |  | 1,250 |  |
| 2.722% Notes due February 15, 2030 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.700% Notes due February 15, 2031 |  |  |  | 750 |  |  | 750 |  |
| 3.377% Notes due April 5, 2040 |  |  |  | 1,500 |  |  | 1,500 |  |
| 3.577% Notes due April 5, 2050 |  |  |  | 2,000 |  |  | 2,000 |  |
| Total Long-term notes |  |  |  | 8,350 |  |  | 9,500 |  |
| Other debt (including project financing obligations and finance leases) |  |  |  | 275 |  |  | 267 |  |
| Discounts and debt issuance costs |  |  |  | (64) |  |  | (71) |  |
| Total debt |  |  |  | 8,561 |  |  | 9,696 |  |
| Less: current portion of long-term debt |  |  |  | 256 |  |  | 183 |  |
| Long-term debt, net of current portion |  |  |  | $ | 8,305 |  |  | $ | 9,513 |  |

- changed (2022-07-28):
[0001783180-22-000048:note_history:13]
On February 10, 2020, the Company entered into a revolving credit agreement with various banks permitting aggregate borrowings of up to $2.0 billion pursuant to an unsecured, unsubordinated revolving credit facility that matures on April 3, 2025 (the "Revolving Credit Facility"). The Revolving Credit Facility supports the Company's commercial paper program and cash requirements of the Company. A commitment fee of 0.125% is charged on unused commitments. Borrowings under the Revolving Credit Facility are available in U.S. Dollars, Euros and Pounds Sterling and bear interest at a variable interest rate plus a ratings-based margin, which was 125 basis points as of June 30, 2022. As of June 30, 2022, there were no borrowings outstanding under the Revolving Credit Facility.
  (was, 2022-04-28, similarity 0.9733):
[0001783180-22-000034:note_history:13]
On February 10, 2020, the Company entered into a revolving credit agreement with various banks permitting aggregate borrowings of up to $2.0 billion pursuant to an unsecured, unsubordinated revolving credit facility that matures on April 3, 2025 (the "Revolving Credit Facility"). The Revolving Credit Facility supports the Company's commercial paper program and cash requirements of the Company. A commitment fee of 0.125% is charged on unused commitments. Borrowings under the Revolving Credit Facility are available in U.S. Dollars, Euros and Pounds Sterling and bear interest at a variable interest rate plus a ratings-based margin, which was 125 basis points as of March 31, 2022. As of March 31, 2022, there were no borrowings outstanding under the Revolving Credit Facility.

- added (2022-07-28):
[0001783180-22-000048:note_history:14]
The Company has a $2.0 billion unsecured, unsubordinated commercial paper program, which can be used for general

- changed (2022-07-28):
[0001783180-22-000048:note_history:15]
corporate purposes, including the funding of working capital and potential acquisitions. As of June 30, 2022, there were no borrowings outstanding under the commercial paper program.
  (was, 2022-04-28, similarity 0.6638):
[0001783180-22-000034:note_history:15]
The Company has a $2.0 billion unsecured, unsubordinated commercial paper program, which can be used for general corporate purposes, including the funding of working capital and potential acquisitions. As of March 31, 2022, there were no borrowings outstanding under the commercial paper program.

- changed (2022-07-28):
[0001783180-22-000048:note_history:16]
The Company is involved in several long-term construction contracts in which it arranges project financing with certain customers. As a result, the Company issued $21 million and $71 million of debt during the six months ended June 30, 2022 and 2021, respectively. Long-term debt repayments associated with these financing arrangements during the six months ended June 30, 2022 and 2021 were $12 million and $83 million, respectively.
  (was, 2022-04-28, similarity 0.8918):
[0001783180-22-000034:note_history:16]
The Company is involved in several long-term construction contracts in which it arranges project financing with certain customers. As a result, the Company issued $14 million and $46 million of debt during the three months ended March 31, 2022 and 2021, respectively. Long-term debt repayments associated with these financing arrangements during the three months ended March 31, 2022 and 2021 were $8 million and $53 million, respectively.

- changed (2022-07-28):
[0001783180-22-000048:note_history:17]
The Revolving Credit Facility and the indenture for the long-term Notes contain affirmative and negative covenants customary for financings of these types, which, among other things, limit the Company's ability to incur additional liens, to make certain fundamental changes and to enter into sale and leaseback transactions. As of June 30, 2022, the Company was in compliance with the covenants under the agreements governing its outstanding indebtedness.
  (was, 2022-04-28, similarity 0.99):
[0001783180-22-000034:note_history:17]
The Revolving Credit Facility and the indenture for the Long-term notes contain affirmative and negative covenants customary for financings of these types, which, among other things, limit the Company's ability to incur additional liens, to make certain fundamental changes and to enter into sale and leaseback transactions. As of March 31, 2022, the Company was in compliance with the covenants under the agreements governing its outstanding indebtedness.

- changed (2022-07-28):
[0001783180-22-000048:note_history:18]
On March 15, 2022, the Company commenced tender offers to purchase up to $1.15 billion ("Aggregate Tender Cap") aggregate principal of the Company's 2.242% Notes due 2025 and 2.493% Notes due 2027 (together, the "Senior Notes"). The tender offers included payment of applicable accrued and unpaid interest up to the settlement date, along with a fixed spread for early repayment. Based on participation, the Company elected to settle the tender offers on March 30, 2022. The aggregate principal amount of Senior Notes validly tendered and accepted was approximately $1.15 billion, which included $800 million of Notes due 2025 and $350 million of Notes due 2027. As a result, the Company recognized a net gain of $33 million and wrote off $5 million of unamortized deferred financing costs within Interest (expense) income, net on the accompanying Unaudited Condensed Consolidated Statement of Operations during the three months ended March 31, 2022.
  (was, 2022-04-28, similarity 0.9632):
[0001783180-22-000034:note_history:18]
On March 15, 2022, the Company commenced tender offers to purchase up to $1.15 billion ("Aggregate Tender Cap") aggregate principal of the Company's 2.242% Notes due 2025 and 2.493% Notes due 2027 (together, the "Senior Notes"). The tender offers included payment of applicable accrued and unpaid interest up to the settlement date, along with a fixed spread for early repayment. Based on participation, the Company elected to settle the tender offers on March 30, 2022. The aggregate principal amount of Senior Notes validly tendered and accepted was approximately $1.15 billion, which included $800 million of Notes due 2025 and $350 million of Notes due 2027. Upon settlement, the Company recognized a net gain of $33 million and wrote off $5 million of unamortized deferred financing costs within Interest (expense) income, net on the accompanying Unaudited Condensed Consolidated Statement of Operations.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-07-28):
[0001783180-22-000048:note_history:19]
| (In millions) |  |  |  | June 30,2022 |  | December 31,2021 |
| 2.242% Notes due February 15, 2025 |  |  |  | $ | 1,200 |  |  | $ | 2,000 |  |
| 2.493% Notes due February 15, 2027 |  |  |  | 900 |  |  | 1,250 |  |
| 2.722% Notes due February 15, 2030 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.700% Notes due February 15, 2031 |  |  |  | 750 |  |  | 750 |  |
| 3.377% Notes due April 5, 2040 |  |  |  | 1,500 |  |  | 1,500 |  |
| 3.577% Notes due April 5, 2050 |  |  |  | 2,000 |  |  | 2,000 |  |
| Total long-term Notes |  |  |  | 8,350 |  |  | 9,500 |  |
| Other debt (including project financing obligations and finance leases) |  |  |  | 279 |  |  | 267 |  |
| Discounts and debt issuance costs |  |  |  | (62) |  |  | (71) |  |
| Total debt |  |  |  | 8,567 |  |  | 9,696 |  |
| Less: current portion of long-term debt |  |  |  | 269 |  |  | 183 |  |
| Long-term debt, net of current portion |  |  |  | $ | 8,298 |  |  | $ | 9,513 |  |
  (was, 2022-04-28, similarity 0.9938):
[0001783180-22-000034:note_history:19]
| (In millions) |  |  |  | March 31,2022 |  | December 31,2021 |
| 2.242% Notes due February 15, 2025 |  |  |  | $ | 1,200 |  |  | $ | 2,000 |  |
| 2.493% Notes due February 15, 2027 |  |  |  | 900 |  |  | 1,250 |  |
| 2.722% Notes due February 15, 2030 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.700% Notes due February 15, 2031 |  |  |  | 750 |  |  | 750 |  |
| 3.377% Notes due April 5, 2040 |  |  |  | 1,500 |  |  | 1,500 |  |
| 3.577% Notes due April 5, 2050 |  |  |  | 2,000 |  |  | 2,000 |  |
| Total Long-term notes |  |  |  | 8,350 |  |  | 9,500 |  |
| Other debt (including project financing obligations and finance leases) |  |  |  | 275 |  |  | 267 |  |
| Discounts and debt issuance costs |  |  |  | (64) |  |  | (71) |  |
| Total debt |  |  |  | 8,561 |  |  | 9,696 |  |
| Less: current portion of long-term debt |  |  |  | 256 |  |  | 183 |  |
| Long-term debt, net of current portion |  |  |  | $ | 8,305 |  |  | $ | 9,513 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- added (2022-07-28):
[0001783180-22-000048:note_history:20]
|  |  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
| (In millions) |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Sales to equity method investees included in Product sales |  | $ | 787 |  |  | $ | 652 |  |  | $ | 1,411 |  |  | $ | 1,120 |  |
| Purchases from equity method investees included in Cost of products sold |  | $ | 91 |  |  | $ | 98 |  |  | $ | 201 |  |  | $ | 174 |  |

- changed (2022-07-28):
[0001783180-22-000048:note_history:21]
| (In millions) |  | June 30,2022 |  | December 31, 2021 |
| Receivables from equity method investees included in Accounts receivable, net |  | $ | 315 |  |  | $ | 150 |  |
| Payables to equity method investees included in Accounts payable |  | $ | 57 |  |  | $ | 51 |  |
  (was, 2022-04-28, similarity 0.9816):
[0001783180-22-000034:note_history:21]
| (In millions) |  | March 31,2022 |  | December 31, 2021 |
| Receivables from equity method investees included in Accounts receivable, net |  | $ | 228 |  |  | $ | 150 |  |
| Payables to equity method investees included in Accounts payable |  | $ | 49 |  |  | $ | 51 |  |

- removed (2022-07-28):
[0001783180-22-000034:note_history:22]
|  |  |  |  | For the Three Months Ended March 31, |
| (In millions) |  |  |  |  |  | 2022 |  | 2021 |
| Sales to equity method investees included in Product sales |  |  |  |  |  | $ | 624 |  |  | $ | 468 |  |
| Purchases from equity method investees included in Cost of products sold |  |  |  |  |  | $ | 110 |  |  | $ | 75 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-07-28):
[0001783180-22-000048:note_history:23]
|  |  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
| (In millions) |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Sales Type |  |  |  |  |  |  |  |  |
| Product |  | $ | 3,005 |  |  | $ | 2,757 |  |  | $ | 5,644 |  |  | $ | 4,904 |  |
| Service |  | 383 |  |  | 363 |  |  | 714 |  |  | 702 |  |
| HVAC sales |  | 3,388 |  |  | 3,120 |  |  | 6,358 |  |  | 5,606 |  |
| Product |  | 925 |  |  | 915 |  |  | 1,792 |  |  | 1,807 |  |
| Service |  | 116 |  |  | 106 |  |  | 225 |  |  | 219 |  |
| Refrigeration sales |  | 1,041 |  |  | 1,021 |  |  | 2,017 |  |  | 2,026 |  |
| Product |  | 838 |  |  | 1,012 |  |  | 1,609 |  |  | 1,931 |  |
| Service |  | 49 |  |  | 391 |  |  | 96 |  |  | 776 |  |
| Fire & Security sales |  | 887 |  |  | 1,403 |  |  | 1,705 |  |  | 2,707 |  |
| Total segment sales |  | 5,316 |  |  | 5,544 |  |  | 10,080 |  |  | 10,339 |  |
| Eliminations and other |  | (105) |  |  | (104) |  |  | (215) |  |  | (200) |  |
| Net sales |  | $ | 5,211 |  |  | $ | 5,440 |  |  | $ | 9,865 |  |  | $ | 10,139 |  |
  (was, 2022-04-28, similarity 0.8023):
[0001783180-22-000034:note_history:23]
|  |  |  |  | For the Three Months Ended March 31, |
| (In millions) |  |  |  |  |  | 2022 |  | 2021 |
| Sales Type |  |  |  |  |  |  |  |  |
| Product |  |  |  |  |  | $ | 2,639 |  |  | $ | 2,147 |  |
| Service |  |  |  |  |  | 331 |  |  | 339 |  |
| HVAC sales |  |  |  |  |  | 2,970 |  |  | 2,486 |  |
| Product |  |  |  |  |  | 867 |  |  | 892 |  |
| Service |  |  |  |  |  | 109 |  |  | 113 |  |
| Refrigeration sales |  |  |  |  |  | 976 |  |  | 1,005 |  |
| Product |  |  |  |  |  | 771 |  |  | 919 |  |
| Service |  |  |  |  |  | 47 |  |  | 385 |  |
| Fire & Security sales |  |  |  |  |  | 818 |  |  | 1,304 |  |
| Total segment sales |  |  |  |  |  | 4,764 |  |  | 4,795 |  |
| Eliminations and other |  |  |  |  |  | (110) |  |  | (96) |  |
| Net sales |  |  |  |  |  | $ | 4,654 |  |  | $ | 4,699 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-07-28):
[0001783180-22-000048:note_history:24]
The Company accounts for revenue in accordance with ASC 606: Revenue from Contracts with Customers. Revenue is recognized when control of a good or service promised in a contract (i.e. performance obligation) is transferred to a customer. Control is obtained when a customer has the ability to direct the use of and obtain substantially all of the remaining benefits from that good or service. A significant portion of the Company's performance obligations are recognized at a point-in-time when control of the product transfers to the customer, which is generally at the time of shipment. The remaining portion of the Company’s performance obligations are recognized over time as the customer simultaneously obtains control as the Company performs work under a contract, or if the product being produced for the customer has no alternative use and the Company has a contractual right to payment.The timing of revenue recognition, billings and cash collections results in contract assets and contract liabilities. Contract assets relate to the conditional right to consideration for any completed performance under a contract when costs are incurred in excess of billings under the percentage-of-completion methodology. Contract liabilities relate to payments received in advance of performance under a contract or when the Company has a right to consideration that is conditioned upon transfer of a good or service to a customer. Contract liabilities are recognized as revenue as (or when) the Company performs under the contract.
  (was, 2022-04-28, similarity 0.9997):
[0001783180-22-000034:note_history:24]
The Company accounts for revenue in accordance with ASC 606: Revenue from Contracts with Customers. Revenue is recognized when control of a good or service promised in a contract (i.e., performance obligation) is transferred to a customer. Control is obtained when a customer has the ability to direct the use of and obtain substantially all of the remaining benefits from that good or service. A significant portion of the Company's performance obligations are recognized at a point-in-time when control of the product transfers to the customer, which is generally at the time of shipment. The remaining portion of the Company’s performance obligations are recognized over time as the customer simultaneously obtains control as the Company performs work under a contract, or if the product being produced for the customer has no alternative use and the Company has a contractual right to payment.The timing of revenue recognition, billings and cash collections results in contract assets and contract liabilities. Contract assets relate to the conditional right to consideration for any completed performance under a contract when costs are incurred in excess of billings under the percentage-of-completion methodology. Contract liabilities relate to payments received in advance of performance under a contract or when the Company has a right to consideration that is conditioned upon transfer of a good or service to a customer. Contract liabilities are recognized as revenue as (or when) the Company performs under the contract.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-07-28):
[0001783180-22-000048:note_history:25]
REVENUE RECOGNITION 
The Company accounts for revenue in accordance with ASC 606: Revenue from Contracts with Customers. Revenue is recognized when control of a good or service promised in a contract (i.e. performance obligation) is transferred to a customer. Control is obtained when a customer has the ability to direct the use of and obtain substantially all of the remaining benefits from that good or service. A significant portion of the Company's performance obligations are recognized at a point-in-time when control of the product transfers to the customer, which is generally at the time of shipment. The remaining portion of the Company’s performance obligations are recognized over time as the customer simultaneously obtains control as the Company performs work under a contract, or if the product being produced for the customer has no alternative use and the Company has a contractual right to payment.
  (was, 2022-04-28, similarity 0.9995):
[0001783180-22-000034:note_history:25]
REVENUE RECOGNITION 
The Company accounts for revenue in accordance with ASC 606: Revenue from Contracts with Customers. Revenue is recognized when control of a good or service promised in a contract (i.e., performance obligation) is transferred to a customer. Control is obtained when a customer has the ability to direct the use of and obtain substantially all of the remaining benefits from that good or service. A significant portion of the Company's performance obligations are recognized at a point-in-time when control of the product transfers to the customer, which is generally at the time of shipment. The remaining portion of the Company’s performance obligations are recognized over time as the customer simultaneously obtains control as the Company performs work under a contract, or if the product being produced for the customer has no alternative use and the Company has a contractual right to payment.

- changed (2022-07-28):
[0001783180-22-000048:note_history:26]
|  |  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
| (In millions) |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Sales Type |  |  |  |  |  |  |  |  |
| Product |  | $ | 3,005 |  |  | $ | 2,757 |  |  | $ | 5,644 |  |  | $ | 4,904 |  |
| Service |  | 383 |  |  | 363 |  |  | 714 |  |  | 702 |  |
| HVAC sales |  | 3,388 |  |  | 3,120 |  |  | 6,358 |  |  | 5,606 |  |
| Product |  | 925 |  |  | 915 |  |  | 1,792 |  |  | 1,807 |  |
| Service |  | 116 |  |  | 106 |  |  | 225 |  |  | 219 |  |
| Refrigeration sales |  | 1,041 |  |  | 1,021 |  |  | 2,017 |  |  | 2,026 |  |
| Product |  | 838 |  |  | 1,012 |  |  | 1,609 |  |  | 1,931 |  |
| Service |  | 49 |  |  | 391 |  |  | 96 |  |  | 776 |  |
| Fire & Security sales |  | 887 |  |  | 1,403 |  |  | 1,705 |  |  | 2,707 |  |
| Total segment sales |  | 5,316 |  |  | 5,544 |  |  | 10,080 |  |  | 10,339 |  |
| Eliminations and other |  | (105) |  |  | (104) |  |  | (215) |  |  | (200) |  |
| Net sales |  | $ | 5,211 |  |  | $ | 5,440 |  |  | $ | 9,865 |  |  | $ | 10,139 |  |
  (was, 2022-04-28, similarity 0.8023):
[0001783180-22-000034:note_history:26]
|  |  |  |  | For the Three Months Ended March 31, |
| (In millions) |  |  |  |  |  | 2022 |  | 2021 |
| Sales Type |  |  |  |  |  |  |  |  |
| Product |  |  |  |  |  | $ | 2,639 |  |  | $ | 2,147 |  |
| Service |  |  |  |  |  | 331 |  |  | 339 |  |
| HVAC sales |  |  |  |  |  | 2,970 |  |  | 2,486 |  |
| Product |  |  |  |  |  | 867 |  |  | 892 |  |
| Service |  |  |  |  |  | 109 |  |  | 113 |  |
| Refrigeration sales |  |  |  |  |  | 976 |  |  | 1,005 |  |
| Product |  |  |  |  |  | 771 |  |  | 919 |  |
| Service |  |  |  |  |  | 47 |  |  | 385 |  |
| Fire & Security sales |  |  |  |  |  | 818 |  |  | 1,304 |  |
| Total segment sales |  |  |  |  |  | 4,764 |  |  | 4,795 |  |
| Eliminations and other |  |  |  |  |  | (110) |  |  | (96) |  |
| Net sales |  |  |  |  |  | $ | 4,654 |  |  | $ | 4,699 |  |

- changed (2022-07-28):
[0001783180-22-000048:note_history:27]
| (In millions) |  | June 30, 2022 |  | December 31, 2021 |
| Contract assets, current |  | $ | 712 |  |  | $ | 503 |  |
| Contract assets, non-current (included within Other assets) |  | 6 |  |  | 70 |  |
| Total contract assets |  | 718 |  |  | 573 |  |
| Contract liabilities, current |  | (444) |  |  | (415) |  |
| Contract liabilities, non-current (included within Other long-term liabilities) |  | (169) |  |  | (165) |  |
| Total contract liabilities |  | (613) |  |  | (580) |  |
| Net contract assets |  | $ | 105 |  |  | $ | (7) |  |
  (was, 2022-04-28, similarity 0.9907):
[0001783180-22-000034:note_history:27]
| (In millions) |  | March 31, 2022 |  | December 31, 2021 |
| Contract assets, current |  | $ | 655 |  |  | $ | 503 |  |
| Contract assets, non-current (included within Other assets) |  | 15 |  |  | 70 |  |
| Total contract assets |  | 670 |  |  | 573 |  |
| Contract liabilities, current |  | (426) |  |  | (415) |  |
| Contract liabilities, non-current (included within Other long-term liabilities) |  | (169) |  |  | (165) |  |
| Total contract liabilities |  | (595) |  |  | (580) |  |
| Net contract assets |  | $ | 75 |  |  | $ | (7) |  |

- changed (2022-07-28):
[0001783180-22-000048:note_history:28]
The timing of revenue recognition, billings and cash collections results in contract assets and contract liabilities. Contract assets relate to the conditional right to consideration for any completed performance under a contract when costs are incurred in excess of billings under the percentage-of-completion methodology. Contract liabilities relate to payments received in advance of performance under a contract or when the Company has a right to consideration that is conditioned upon transfer of a good or service to a customer. Contract liabilities are recognized as revenue as (or when) the Company performs under the contract. 
The Company recognized revenue of $221 million during the six months ended June 30, 2022 that related to contract liabilities as of January 1, 2022. The Company expects a majority of its current contract liabilities at the end of the period to be recognized as revenue in the next 12 months.
  (was, 2022-04-28, similarity 0.769):
[0001783180-22-000034:note_history:28]
The timing of revenue recognition, billings and cash collections results in contract assets and contract liabilities. Contract assets relate to the conditional right to consideration for any completed performance under a contract when costs are incurred in excess of billings under the percentage-of-completion methodology. Contract liabilities relate to payments received in advance of performance under a contract or when the Company has a right to consideration that is conditioned upon transfer of a good or service to a customer. Contract liabilities are recognized as revenue as (or when) the Company performs under the contract. 
The Company recognized revenue of $157 million during the three months ended March 31, 2022 that related to contract liabilities as of January 1, 2022. The Company expects a majority of its current contract liabilities at the end of the period to be recognized as revenue in the next 12 months.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2022-07-28):
[0001783180-22-000048:note_history:29]
SUBSEQUENT EVENTS 
On July 15, 2022, the Company entered into a five-year, JPY 54 billion (approximately $400 million) senior unsecured term loan facility with MUFG Bank Ltd., as administrative agent and lender, and certain other lenders (the "Japanese Term Loan Facility"). Borrowings under the Japanese Term Loan Facility bear interest at a rate equal to the Tokyo Term Risk Free Rate plus 0.75%. In addition, the Japanese Term Loan Facility is subject to customary covenants including a covenant to maintain a maximum consolidated leverage ratio during its term. The Company expects to designate the Japanese Term Loan Facility as a partial hedge of its investment in certain Yen-functional currency subsidiaries in order to manage foreign currency translation risk. As a result, changes in the fair value of the Japanese Term Loan Facility associated with foreign exchange rate movements will be recorded in Equity in the Unaudited Condensed Consolidated Balance Sheet.

- added (2022-07-28):
[0001783180-22-000048:note_history:30]
On July 25, 2022, the Company borrowed JPY 54 billion under the Japanese Term Loan Facility and intends to use the proceeds to fund a portion of the planned acquisition of TCC and to pay related fees and expenses. The Company expects to fund the remaining portion of the Yen denominated purchase price for the planned acquisition of TCC with cash on hand by entering into cross currency swaps with SMBC Capital Markets, Inc. as syndication swap arranger, and certain other financial institutions. The Company expects to designate the cross currency swaps as a partial hedge of its investment in certain Yen-functional currency subsidiaries in order to manage foreign currency translation risk. As a result, changes in the fair value of the swaps will be recorded in Equity in the Unaudited Condensed Consolidated Balance Sheet.
